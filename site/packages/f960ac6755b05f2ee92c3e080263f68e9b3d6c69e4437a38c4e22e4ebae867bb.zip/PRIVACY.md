# Privacy Policy

**Supabase Expert Plugin**
Last updated: March 9, 2025

## Data Collection

This plugin does **not** collect, store, transmit, or process any personal data, usage data, telemetry, analytics, or any other information from users. It operates entirely within the user's local environment.

## What This Plugin Does

This plugin provides instructional guidance, code examples, SQL templates, and security best practices for Supabase development. It does not:

- Connect to any external servers or APIs
- Send or receive data over the network
- Store any user information locally or remotely
- Track usage, behavior, or analytics
- Access credentials, tokens, or API keys
- Collect any form of personally identifiable information (PII)

## Third-Party Services

This plugin does not integrate with or send data to any third-party services.

## Security

The bundled scripts (`audit-rls.sql` and `security-check.sh`) run entirely within the user's local environment. They read local files and query local or user-connected databases only. No data from these scripts is transmitted externally.

## Disclaimer

THIS PLUGIN IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.

THE AUTHOR(S) SHALL NOT BE HELD LIABLE FOR ANY CLAIM, DAMAGES, LOSSES, DATA LOSS, SECURITY BREACHES, SERVICE DISRUPTIONS, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE USE OF THIS PLUGIN OR ANY CODE, SQL, SCRIPTS, OR RECOMMENDATIONS IT PROVIDES.

ALL GUIDANCE, CODE EXAMPLES, SQL MIGRATIONS, SECURITY RECOMMENDATIONS, AND AUDIT SCRIPTS ARE FOR EDUCATIONAL AND DEVELOPMENT PURPOSES ONLY. USERS ARE SOLELY RESPONSIBLE FOR REVIEWING, TESTING, AND VALIDATING ALL GENERATED CODE BEFORE DEPLOYING TO PRODUCTION ENVIRONMENTS.

**USE AT YOUR OWN RISK.**

## Changes to This Policy

Any updates to this privacy policy will be reflected in this file and the "Last updated" date above.

## Contact

For questions about this privacy policy, open an issue at: https://github.com/asim266/supabase-expert/issues
