# Supabase Expert - Claude Code Plugin

A Claude Code skill that provides expert guidance for building secure, performant Supabase applications.

## What It Does

- **RLS Policy Design** - Generates secure Row Level Security policies with proper `auth.uid()` checks, `TO` clauses, `WITH CHECK`, and performance indexes
- **Security Auditing** - Reviews Supabase projects for common vulnerabilities (exposed service_role keys, `getSession()` misuse, `user_metadata` role checks)
- **Storage Setup** - Creates private/public buckets with mime type restrictions, size limits, ownership-based RLS, and signed URL generation
- **Auth Flows** - Guides SSR setup with `@supabase/ssr`, middleware, OAuth callbacks, MFA, and custom claims
- **Migrations** - Best practices for `supabase db diff`, type generation, and migration workflows

## Installation

```
/plugin marketplace add your-username/supabase-expert
/plugin install supabase-expert
```

## Triggers On

Any mention of: `supabase`, `rls`, `row level security`, `supabase auth`, `supabase storage`, `storage.objects`, `service_role`, `anon key`, `createClient`, `supabase-js`, database migrations, or RLS policies.

## Bundled Scripts

- `scripts/audit-rls.sql` - SQL query to audit RLS status across all tables
- `scripts/security-check.sh` - Shell script to scan projects for common Supabase security issues

## Disclaimer

This plugin is provided "as is" without warranty of any kind, express or implied. The guidance, code examples, SQL migrations, and security recommendations are for educational and development purposes only. Always review and test generated code thoroughly before deploying to production. The author(s) accept no responsibility or liability for any damages, data loss, security breaches, or other issues arising from the use of this plugin. **Use at your own risk.**

## License

MIT
