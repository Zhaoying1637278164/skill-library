# Changelog

## [1.0.0] - 2025-03-09

### Added
- Supabase expert skill with RLS policy design guidance
- Security auditing checklist and best practices
- Storage setup with bucket RLS patterns
- Auth flow guidance (SSR, OAuth, MFA, custom claims)
- Migration workflow best practices
- Edge Function patterns
- `audit-rls.sql` script for RLS status auditing
- `security-check.sh` script for project security scanning
- Reference guides for RLS, Auth, and Storage
