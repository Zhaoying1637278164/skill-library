# unity-perf

A Claude Code plugin for **Unity / C# game client development**: performance
optimization, zero-GC engineering, and code standards & review.

Written for teams shipping mobile titles, so the guidance is concrete about the
things that actually break on device: thermal throttling, IL2CPP and hot-update
interpreter constraints, PSS budgets on low-end hardware, and the Canvas rebuild
storms behind most UI stutter.

## Skills

| Skill | Triggers on | What it does |
| :---- | :---------- | :----------- |
| `unity-performance` | stutter, frame drops, low FPS, overheating, GC allocation, memory leaks, DrawCalls, overdraw, slow loading, build size, profiling, crash rates — or just "optimize X" | Sets non-negotiable acceptance targets, then walks profiling → diagnosis → fix → verification. 12 reference files cover profiling, engine/rendering, UGUI + TMP, memory & GC internals, C# hot paths, Span/SIMD, Jobs/Burst/DOTS, IL2CPP tricks, benchmarking, baseline anti-patterns, and on-device acceptance plus live-ops triage. |
| `csharp-zero-gc` | "make X zero-GC", zero allocation, GC spikes, per-frame allocation budgets, object pooling, GC regression guards | Produces an *engineering plan*, not a one-off fix: commitment tiers, acceptance criteria, a zero-alloc pattern library, library selection, and Analyzer + CI guardrails so the result survives six months of commits. |
| `code-standards` | coding standards, "write it to spec", cohesion & coupling, design pattern selection, naming conventions, design-dimension code review | Two modes — define standards while writing, or run a multi-perspective review protocol. Primary language is C#/Unity; reference files also carry Go, C++, Java and Lua rules. |

Each skill uses progressive disclosure: `SKILL.md` holds the doctrine and the
protocol, and the `references/` files are loaded only when a specific topic
comes up.

## Install

```bash
/plugin marketplace add tianzhiying/Unity-perf
/plugin install unity-perf@gqy-plugins
```

Then start a new session (or run `/reload-plugins`) and the skills load
automatically — Claude picks them up from the task context, so you usually
don't need to invoke anything by hand. To call one explicitly:

```
/unity-perf:unity-performance
/unity-perf:csharp-zero-gc
/unity-perf:code-standards
```

### Try it without installing

```bash
git clone https://github.com/tianzhiying/Unity-perf.git
claude --plugin-dir ./Unity-perf
```

## Requirements

Claude Code only. No MCP servers, no hooks, no binaries, no network calls —
this plugin is entirely Markdown, so it collects no data and runs no code.

## Also works with Codex

The repo ships a `.codex-plugin/plugin.json` manifest alongside the Claude Code
one, so the same skill set can be loaded by Codex-compatible hosts.

## Development

`plugin.config.json` is the single source of truth for both manifests; they are
generated from it. After editing it, regenerate and validate:

```bash
claude plugin validate . --strict
```

## License

MIT — see [LICENSE](LICENSE).
