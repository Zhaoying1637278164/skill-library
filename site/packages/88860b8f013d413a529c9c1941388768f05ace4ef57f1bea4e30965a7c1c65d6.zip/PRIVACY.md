# Privacy Policy

**Laravel AI Starter** is a Claude Code plugin that runs entirely on your local machine.

## Data Collection

This plugin does **not** collect, store, transmit, or share any personal data, usage data, or telemetry.

## What the plugin does

- Creates files and directories on your local filesystem
- Runs CLI commands locally (composer, npm, artisan, git, gh)
- Reads and writes `.env` files locally
- Optionally creates a GitHub repository using your existing `gh` CLI authentication

## Third-party services

The plugin may install packages that connect to third-party services (OpenAI, Stripe). These connections are configured by you and governed by the respective service's privacy policy:

- OpenAI: https://openai.com/privacy
- Stripe: https://stripe.com/privacy

## Contact

For questions, open an issue at https://github.com/maj0rr/laravel-ai-starter/issues