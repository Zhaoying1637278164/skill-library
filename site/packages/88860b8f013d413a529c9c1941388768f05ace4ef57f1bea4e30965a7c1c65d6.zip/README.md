# Laravel AI Starter

A Claude Code plugin that creates new Laravel projects fully configured for AI-assisted development.

## Installation

```
/plugin install gh:maj0rr/laravel-ai-starter
```

## Usage

```
/laravel-ai-starter:new-laravel-project
```

Or with a project name:

```
/laravel-ai-starter:new-laravel-project my-app
```

## What it does

The skill guides you through creating a complete Laravel project with:

### Setup (automated)
- Laravel + Livewire + Pest via `laravel new`
- MySQL database + `.env` configuration
- Laravel Boost (guidelines, skills, MCP)
- IDE Helper + Debugbar
- Larastan (Level 5) + PHPStan Baseline
- Laravel Simplifier Plugin
- Spatie Boost Guidelines
- Codex Agent configuration (AGENTS.md)
- AI Guidelines for clean code
- `preventLazyLoading()` in development
- HTTPS via Herd
- GitHub CI workflow fix (PHP 8.4)

### Optional
- **Login** -- Livewire auth with seeded admin user
- **VitePress** -- Documentation site under `/docs`
- **GitHub Repository** -- Private repo with initial commit

### Feature Integrations (post-setup wizard)
- **OpenAI** -- `openai-php/laravel` with `GenerateAiTextAction`
- **Filament** -- Admin panel with CRUD, dashboard, widgets
- **Laravel Cashier / Stripe** -- Payments, subscriptions, invoices

## Guidelines included

The plugin installs coding guidelines under `.ai/guidelines/`:

| Guideline | Description |
|---|---|
| actions.md | Action classes with `execute()` method |
| code-style.md | Enums, no defensive coding, lazy loading prevention |
| controllers.md | Always use `$request->validated()` |
| naming.md | Class suffix conventions |
| routing.md | No inline logic in routes |
| testing.md | Pest conventions, test coverage requirements |
| documentation.md | Feature docs under `.documentation/` |
| filament.md | Smoke tests, FilaCheck (only with Filament) |

## Documentation templates

- **deployment-laravel-cloud.md** -- Step-by-step guide for deploying to Laravel Cloud

## Requirements

- [Laravel Herd](https://herd.laravel.com) (or manually specify project directory)
- PHP 8.4+
- Composer
- Node.js + npm
- MySQL
- `gh` CLI (optional, for GitHub repo creation)

## License

MIT