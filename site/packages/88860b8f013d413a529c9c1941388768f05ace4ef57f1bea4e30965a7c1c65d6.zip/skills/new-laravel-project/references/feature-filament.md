# Feature: Filament Admin-Panel

Installiere Filament (Panel Builder) — Composer löst die passende Version automatisch auf:

```bash
composer require filament/filament
php artisan filament:install --panels
```

Das erstellt einen `AdminPanelProvider` unter `app/Providers/Filament/AdminPanelProvider.php`.

Prüfe ob der Provider in `bootstrap/providers.php` registriert ist, falls nicht ergänze ihn.

Admin-User erstellen (interaktiv — der Nutzer wird nach Name, E-Mail und Passwort gefragt):

```bash
php artisan make:filament-user
```

Falls in Schritt 5 bereits ein Admin-Seeder erstellt wurde, den bestehenden User auch für Filament nutzbar machen. Dazu sicherstellen, dass das User-Model das `FilamentUser` Interface implementiert:

```php
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;

class User extends Authenticatable implements FilamentUser
{
    public function canAccessPanel(Panel $panel): bool
    {
        return true; // In Production einschränken z.B. per Rolle oder E-Mail
    }
}
```

Filament-Guideline kopieren (nur bei Filament):

```bash
cp ${CLAUDE_SKILL_DIR}/templates/guidelines/filament.md .ai/guidelines/filament.md
```

Frontend neu bauen:

```bash
npm install
npm run build
```

Pint laufen lassen:

```bash
vendor/bin/pint
```

Dokumentation unter `.documentation/filament-admin.md` erstellen:

```markdown
# Filament Admin-Panel

## Zugang

Das Admin-Panel ist erreichbar unter `/admin`.

## Admin-User erstellen

\`\`\`bash
php artisan make:filament-user
\`\`\`

## Resources erstellen

Für jedes Eloquent-Model eine Filament-Resource erstellen:

\`\`\`bash
php artisan make:filament-resource ModelName --generate
\`\`\`

Das erstellt automatisch:
- List-Page (Tabelle)
- Create-Page (Formular)
- Edit-Page (Formular)

## Widgets erstellen

\`\`\`bash
php artisan make:filament-widget StatsOverview --stats-overview
\`\`\`

## Konfiguration

Der Panel-Provider liegt unter `app/Providers/Filament/AdminPanelProvider.php`.
Dort können Navigation, Theme, Middleware und weitere Einstellungen angepasst werden.

## Dokumentation

Offizielle Docs: https://filamentphp.com/docs
```

Falls VitePress eingerichtet ist, Sidebar-Eintrag hinzufügen.

Danach committen:

```bash
git add -A
git commit -m "Add Filament admin panel"
```

Falls GitHub-Repo erstellt wurde:

```bash
git push
```
