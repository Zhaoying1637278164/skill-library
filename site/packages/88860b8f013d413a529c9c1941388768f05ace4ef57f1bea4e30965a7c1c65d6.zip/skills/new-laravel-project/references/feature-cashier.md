# Feature: Laravel Cashier / Stripe

Frage den Nutzer nach seinen Stripe-Keys:

> **Stripe API-Keys eingeben** (optional, können auch später in `.env` gesetzt werden)
>
> Du findest deine Keys unter: https://dashboard.stripe.com/apikeys
> Für die Entwicklung die **Test-Keys** verwenden (beginnen mit `pk_test_` und `sk_test_`)

Installiere Laravel Cashier:

```bash
composer require laravel/cashier
```

Publiziere und führe die Migrations aus:

```bash
php artisan vendor:publish --tag="cashier-migrations"
php artisan migrate
```

Füge den `Billable` Trait zum User-Model hinzu:

```php
use Laravel\Cashier\Billable;

class User extends Authenticatable
{
    use Billable;
}
```

Setze die Stripe-Keys in `.env` (vom Nutzer eingegeben oder leer):

```
STRIPE_KEY=<eingegebener-publishable-key>
STRIPE_SECRET=<eingegebener-secret-key>
STRIPE_WEBHOOK_SECRET=
CASHIER_CURRENCY=eur
```

**`.env.example` aktualisieren** — trage die Platzhalter ein, damit andere Entwickler wissen welche Variablen erwartet werden:

```
STRIPE_KEY=
STRIPE_SECRET=
STRIPE_WEBHOOK_SECRET=
CASHIER_CURRENCY=eur
```

Publiziere die Cashier-Config:

```bash
php artisan vendor:publish --tag="cashier-config"
```

Pint laufen lassen:

```bash
vendor/bin/pint
```

Dokumentation unter `.documentation/stripe-payments.md` erstellen:

```markdown
# Stripe Zahlungen (Laravel Cashier)

## Konfiguration

Stripe-Keys in `.env` setzen:

\`\`\`
STRIPE_KEY=pk_test_...
STRIPE_SECRET=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
CASHIER_CURRENCY=eur
\`\`\`

Keys findest du unter: https://dashboard.stripe.com/apikeys

## Webhook einrichten

Für Production einen Webhook in Stripe erstellen:
1. Stripe Dashboard → Developers → Webhooks
2. Endpoint-URL: `https://deine-domain.com/stripe/webhook`
3. Events auswählen (mindestens: `customer.subscription.*`, `invoice.*`)
4. Webhook-Secret in `.env` als `STRIPE_WEBHOOK_SECRET` setzen

Für lokale Entwicklung:

\`\`\`bash
stripe listen --forward-to https://<projektname>.test/stripe/webhook
\`\`\`

## Subscriptions erstellen

\`\`\`php
$user->newSubscription('default', 'price_xxx')->create($paymentMethod);
\`\`\`

## Einmalzahlungen

\`\`\`php
$user->charge(1000, $paymentMethod); // 10,00 EUR
\`\`\`

## Rechnungen

\`\`\`php
$invoices = $user->invoices();
$user->downloadInvoice($invoiceId);
\`\`\`

## Dokumentation

Offizielle Docs: https://laravel.com/docs/billing
Stripe Docs: https://docs.stripe.com
```

Falls VitePress eingerichtet ist, Sidebar-Eintrag hinzufügen.

Danach committen:

```bash
git add -A
git commit -m "Add Laravel Cashier / Stripe integration"
```

Falls GitHub-Repo erstellt wurde:

```bash
git push
```
