# Feature: OpenAI-Integration

Installiere das offizielle OpenAI PHP-Paket:

```bash
composer require openai-php/laravel
```

Publiziere die Config:

```bash
php artisan vendor:publish --provider="OpenAI\Laravel\ServiceProvider"
```

Frage den Nutzer nach seinem OpenAI API-Key:

> **OpenAI API-Key eingeben** (optional, kann auch später in `.env` gesetzt werden)
>
> Du findest deinen Key unter: https://platform.openai.com/api-keys
> Falls du noch keinen hast: Account erstellen → API Keys → "Create new secret key"

Falls der Nutzer einen Key eingibt, setze ihn direkt in `.env`:

```
OPENAI_API_KEY=<eingegebener-key>
OPENAI_ORGANIZATION=
```

Falls der Nutzer keinen Key hat oder überspringen möchte, setze die Werte leer:

```
OPENAI_API_KEY=
OPENAI_ORGANIZATION=
```

Der Key landet nur in `.env` (ist in `.gitignore`, wird nicht committed).

**`.env.example` aktualisieren** — trage die Platzhalter ein, damit andere Entwickler wissen welche Variablen erwartet werden:

```
OPENAI_API_KEY=
OPENAI_ORGANIZATION=
```

Erstelle eine Action als zentrale Schnittstelle für OpenAI-Aufrufe:

**`app/Actions/GenerateAiTextAction.php`:**

```php
<?php

namespace App\Actions;

use OpenAI\Laravel\Facades\OpenAI;

class GenerateAiTextAction
{
    /**
     * @param string $prompt Der Prompt für die KI
     * @param string $model Modell-ID — bei Bedarf anpassen (z.B. 'gpt-4o')
     */
    public function execute(string $prompt, string $model = 'gpt-4o-mini'): string
    {
        $response = OpenAI::chat()->create([
            'model' => $model,
            'messages' => [
                ['role' => 'user', 'content' => $prompt],
            ],
        ]);

        return $response->choices[0]->message->content;
    }
}
```

Erstelle einen Test dazu:

**`tests/Feature/Actions/GenerateAiTextActionTest.php`:**

```php
<?php

use App\Actions\GenerateAiTextAction;
use OpenAI\Laravel\Facades\OpenAI;
use OpenAI\Responses\Chat\CreateResponse;

test('it generates text via OpenAI', function () {
    OpenAI::fake([
        CreateResponse::fake([
            'choices' => [
                ['message' => ['content' => 'Generated text']],
            ],
        ]),
    ]);

    $action = new GenerateAiTextAction();
    $result = $action->execute('Write a greeting');

    expect($result)->toBe('Generated text');
});
```

Dokumentation unter `.documentation/openai-integration.md` erstellen:

```markdown
# OpenAI-Integration

## Konfiguration

API-Key in `.env` setzen:

\`\`\`
OPENAI_API_KEY=sk-...
\`\`\`

## Verwendung

Die zentrale Action für OpenAI-Aufrufe:

\`\`\`php
$action = new GenerateAiTextAction();
$text = $action->execute('Schreibe eine Begrüßung');
\`\`\`

Für andere Modelle:

\`\`\`php
$text = $action->execute('Prompt', 'gpt-4o');
\`\`\`

## Erweitern

Für neue AI-Features eigene Actions erstellen die `GenerateAiTextAction` als Referenz nutzen oder direkt die OpenAI Facade verwenden.
```

Falls VitePress eingerichtet ist, Sidebar-Eintrag hinzufügen.

Danach committen:

```bash
git add -A
git commit -m "Add OpenAI integration with GenerateAiTextAction"
```

Falls GitHub-Repo erstellt wurde:

```bash
git push
```
