---
name: new-laravel-project
description: Create a new Laravel project fully configured for AI-assisted development with Boost, Claude Code, Codex, guidelines, and Pint. Use this skill whenever the user wants to start a new Laravel project, scaffold a Laravel app, set up a fresh Laravel codebase, or asks about creating a new web project with Laravel — even if they don't mention Boost or AI tooling specifically.
argument-hint: "[project-name]"
disable-model-invocation: true
effort: high
allowed-tools: Bash Read Write Edit Glob Grep AskUserQuestion TaskCreate TaskUpdate
---

# New Laravel Project Setup

Erstelle ein neues Laravel-Projekt, vollständig konfiguriert für AI-gestützte Entwicklung.

## Was wird installiert (Überblick)

| Kategorie | Tools |
|---|---|
| Framework | Laravel + Livewire, Pest, MySQL |
| Code-Qualität | Pint, Larastan (Level 5), IDE Helper, Debugbar |
| AI-Tooling | Laravel Boost + MCP, Simplifier Plugin, Codex Agent (AGENTS.md) |
| Guidelines | Actions, Code-Style, Controllers, Naming, Routing, Testing, Documentation |
| Optional | VitePress Docs, Login/Auth, OpenAI, Filament, Stripe/Cashier |

## Fehlerbehandlung

Falls ein Schritt fehlschlägt, informiere den Nutzer über den Fehler und frage ob du es erneut versuchen oder den Schritt überspringen sollst. Fahre nicht blind mit dem nächsten Schritt fort — ein fehlgeschlagener Schritt kann Folgefehler verursachen.

## Herd-Verzeichnis ermitteln

Ermittle das Herd-Verzeichnis dynamisch:

```bash
HERD_DIR=$(herd paths 2>/dev/null | head -1 || echo "$HOME/Herd")
```

Falls `herd paths` nicht verfügbar ist, frage den Nutzer nach dem gewünschten Verzeichnis. Nutze das ermittelte Verzeichnis als `<HERD_DIR>` in allen folgenden Schritten.

## Guideline-Templates

Die Guidelines für neue Projekte liegen als Templates unter `${CLAUDE_SKILL_DIR}/templates/guidelines/`. Kopiere diese Dateien in das neue Projekt nach `.ai/guidelines/`. Falls Boost bereits Guidelines erstellt hat, merge die Templates intelligent — keine Duplikate, bestehende Boost-Guidelines nicht überschreiben.

Verfügbare Templates:
- [actions.md](templates/guidelines/actions.md) — Action-Klassen mit `execute()`
- [code-style.md](templates/guidelines/code-style.md) — Defensive Programmierung, Actions vs Events
- [controllers.md](templates/guidelines/controllers.md) — `$request->validated()` statt `input()`
- [naming.md](templates/guidelines/naming.md) — Klassen-Suffix nach Funktion
- [routing.md](templates/guidelines/routing.md) — Keine Inline-Logik in Routes
- [testing.md](templates/guidelines/testing.md) — Pest-Konventionen, Factories, Tests sind Pflicht
- [documentation.md](templates/guidelines/documentation.md) — Feature-Doku unter `.documentation/`

Bedingte Guidelines (nur kopieren wenn das Feature installiert wurde):
- [filament.md](templates/guidelines/filament.md) — Smoke Tests, FilaCheck, Panel-Konfiguration (nur bei Filament)

## Dokumentations-Templates

Zusätzlich liegt unter `${CLAUDE_SKILL_DIR}/templates/documentation/` eine Deployment-Anleitung:
- [deployment-laravel-cloud.md](templates/documentation/deployment-laravel-cloud.md) — Schritt-für-Schritt Deployment auf Laravel Cloud

Kopiere diese Datei in `.documentation/` im neuen Projekt. Falls VitePress eingerichtet wird, füge einen Sidebar-Eintrag in der VitePress-Config hinzu.

---

## Ablauf

Führe die folgenden Schritte **der Reihe nach** aus.

### Fortschrittsanzeige

Nutze **TaskCreate** und **TaskUpdate** für die Fortschrittsanzeige. Erstelle zu Beginn (nach Schritt 1) alle Schritte als Tasks. Setze jeden Task auf `in_progress` bevor du ihn startest und auf `completed` wenn er fertig ist.

Optionale Schritte (VitePress, GitHub) nur als Task anlegen wenn sie gewählt wurden.

Erstelle diese Tasks (VitePress nur wenn gewählt, GitHub ist kein Task):

| subject | activeForm |
|---|---|
| Projekt erstellen | Erstelle Laravel-Projekt mit Livewire, Pest und Boost |
| Datenbank + Umgebung | Erstelle MySQL-Datenbank, konfiguriere .env und aktiviere RefreshDatabase |
| Composer konfigurieren | Passe Setup-Script an und installiere Dev-Pakete |
| Larastan + PHPStan | Installiere Larastan und generiere PHPStan Baseline |
| AI-Tooling einrichten | Konfiguriere Simplifier, Guidelines und Codex Agent |
| VitePress einrichten | Installiere VitePress und erstelle Dokumentationsstruktur |
| Build + Tests | Führe npm build, Pint und Tests aus |

Halte den Text-Output zwischen den Schritten minimal. Die Tasks zeigen den Fortschritt.

### Schritt 1: Eingaben sammeln

Falls `$ARGUMENTS` leer ist, frage den Nutzer nach:

1. **Projektname** (kebab-case, z.B. `my-app`)
2. **Soll es einen Mitgliederbereich bzw. Login geben?** (ja/nein)
3. **VitePress-Dokumentation einrichten?** (ja/nein) — Dokumentation unter `/docs` erreichbar, nur für eingeloggte Nutzer

Falls `$ARGUMENTS` gesetzt ist, verwende es als Projektnamen und frage nur nach Login und VitePress.

### Schritt 2: Voraussetzungen prüfen

```bash
which laravel && which composer && which php && which npm && which herd
```

Falls etwas fehlt, informiere den Nutzer und brich ab.

### Schritt 3: Laravel-Projekt erstellen

```bash
cd <HERD_DIR>
laravel new <projektname> \
  --livewire \
  --pest \
  --database mysql \
  --boost \
  --no-interaction
```

**Login:**
- ja → Livewire Starter bringt Auth bereits mit, keine zusätzliche Konfiguration nötig
- nein → Zusätzlich `--no-authentication` an den Befehl anhängen

Kein Teams-Support. Kein `--using` Flag — `--livewire` ist ein eigenes Flag.

Das `--boost` Flag installiert automatisch:
- Laravel Boost mit Guidelines, Skills und MCP
- `boost:update` im `post-update-cmd` in `composer.json`
- Ein `setup` Script in `composer.json`

Der Livewire Starter erstellt eine `.github/workflows/tests.yml`. Diese muss angepasst werden:

1. PHP-Matrix auf `['8.4']` reduzieren (Symfony 8 / Laravel 13 braucht mindestens 8.4)
2. Den "Add Flux Credentials" Step entfernen (nicht benötigt ohne Flux)

### Schritt 4: Ins Projektverzeichnis wechseln

```bash
cd <HERD_DIR>/<projektname>
```

Ab hier alle Befehle im Projektverzeichnis ausführen.

### Schritt 5: Datenbank und .env konfigurieren

MySQL-Datenbank erstellen. Bei Herd immer `127.0.0.1` als Host verwenden:

```bash
mysql -u root -h 127.0.0.1 -e "CREATE DATABASE IF NOT EXISTS \`<projektname_underscored>\`;"
```

Projektname in Underscore-Schreibweise für den DB-Namen: `my-project` → `my_project`.

Projektname in Title Case für APP_NAME: `mein-projekt` → `"Mein Projekt"`, `example` → `"Example"`.

`.env` anpassen (Herd-Defaults):

```
APP_NAME="<projektname_title_case>"
APP_URL=https://<projektname>.test

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=<projektname_underscored>
DB_USERNAME=root
DB_PASSWORD=
```

Dann: `php artisan migrate`

**Falls Login gewählt wurde**, erstelle einen Admin-User im `database/seeders/UserSeeder.php` (nur für lokale Entwicklung):

```php
<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        if (! app()->environment('local')) {
            return;
        }

        if (User::where('email', 'admin@example.com')->exists()) {
            return;
        }

        $user = new User();
        $user->name = 'Admin';
        $user->email = 'admin@example.com';
        $user->password = Hash::make('password');
        $user->save();
    }
}
```

Registriere den UserSeeder in `database/seeders/DatabaseSeeder.php`:

```php
$this->call([
    UserSeeder::class,
]);
```

Dann seeden:

```bash
php artisan db:seed
```

Lazy Loading in Development verhindern. In `app/Providers/AppServiceProvider.php` in der `boot()`-Methode hinzufügen:

```php
use Illuminate\Database\Eloquent\Model;

Model::preventLazyLoading(! app()->isProduction());
```

Seite per HTTPS absichern (Herd TLS-Zertifikat):

```bash
herd secure <projektname>
```

### Schritt 6: RefreshDatabase aktivieren

In `tests/Pest.php` ist `RefreshDatabase` standardmässig auskommentiert. Aktiviere es:

```php
pest()->extend(TestCase::class)
    ->use(RefreshDatabase::class)
    ->in('Feature');
```

### Schritt 7: Setup-Script anpassen

Boost legt in `composer.json` ein `setup`-Script an, typischerweise:

```json
"setup": [
    "@php artisan migrate --force",
    "npm install",
    "npm run build"
]
```

Prüfe ob dieses Script existiert (`composer.json` → `scripts.setup`). Falls ja, passe es an. Falls nein, erstelle es.

**Falls VitePress gewählt wurde**, ergänze `"npm run docs:build"` nach `"npm run build"` im bestehenden `setup`-Script.

Prüfe auch ob `boost:update` im `post-update-cmd` vorhanden ist, falls nicht ergänze es:

```json
"post-update-cmd": [
    "@php artisan vendor:publish --tag=laravel-assets --ansi --force",
    "@php artisan boost:update --ansi"
]
```

### Schritt 8: Dev-Pakete installieren

```bash
composer require barryvdh/laravel-ide-helper --dev
composer require barryvdh/laravel-debugbar --dev
composer require spatie/boost-spatie-guidelines --dev
```

IDE Helper generieren:

```bash
php artisan ide-helper:generate
php artisan ide-helper:models --nowrite
php artisan ide-helper:meta
```

### Schritt 9: Larastan installieren

```bash
composer require larastan/larastan --dev
```

Erstelle `phpstan.neon`:

```neon
includes:
    - vendor/larastan/larastan/extension.neon

parameters:
    paths:
        - app/
    level: 5
```

PHPStan Baseline generieren (falls Fehler vorhanden):

```bash
./vendor/bin/phpstan analyse --generate-baseline --allow-empty-baseline
```

### Schritt 10: Laravel Simplifier Plugin

**Nur wenn `.claude/settings.local.json` noch nicht existiert** (Boost erstellt diese oft bereits), erstelle sie. Falls sie existiert, nur prüfen ob `enabledPlugins.laravel-simplifier@laravel` gesetzt ist und ggf. ergänzen.

```json
"enabledPlugins": {
    "laravel-simplifier@laravel": true
}
```

### Schritt 11: Guidelines und Dokumentation kopieren

Kopiere alle Dateien aus `${CLAUDE_SKILL_DIR}/templates/guidelines/` nach `.ai/guidelines/` im neuen Projekt — **außer** `filament.md` (wird nur in Schritt 16 kopiert wenn Filament installiert wird). Falls Boost bereits Guidelines erstellt hat, merge intelligent.

Kopiere `${CLAUDE_SKILL_DIR}/templates/documentation/deployment-laravel-cloud.md` nach `.documentation/deployment-laravel-cloud.md`. Falls VitePress eingerichtet wird, füge einen Sidebar-Eintrag dafür hinzu.

### Schritt 12: Codex Agent konfigurieren

Erstelle `AGENTS.md` im Projektroot:

```markdown
# Codex Agent Instructions

- Follow all guidelines in `.ai/guidelines/`
- Follow all rules in `CLAUDE.md`
- Run `vendor/bin/pint` before committing PHP changes
- Run `php artisan test --parallel` before committing
- Use Pest for testing, never PHPUnit directly
- Use factories for test data
- Follow Laravel conventions over custom solutions
```

### Schritt 13: VitePress einrichten (nur wenn in Schritt 1 gewählt)

**Diesen Schritt überspringen wenn der Nutzer VitePress nicht gewählt hat.**

#### 13a: VitePress installieren

```bash
npm install -D vitepress
```

#### 13b: Dokumentationsverzeichnis erstellen

Erstelle `.documentation/.vitepress/config.mts`:

```ts
import { defineConfig } from 'vitepress'

export default defineConfig({
    title: '<Projektname> Docs',
    description: 'Interne Dokumentation',

    base: '/docs/',
    outDir: '../public/docs',
    ignoreDeadLinks: true,

    themeConfig: {
        nav: [
            { text: 'Home', link: '/' },
        ],

        sidebar: [
            {
                text: 'Erste Schritte',
                collapsed: false,
                items: [
                    { text: 'Übersicht', link: '/' },
                ],
            },
        ],

        search: {
            provider: 'local',
        },

        outline: {
            level: [2, 3],
            label: 'Auf dieser Seite',
        },

        docFooter: {
            prev: 'Zurück',
            next: 'Weiter',
        },
    },
})
```

#### 13c: Startseite erstellen

Erstelle `.documentation/index.md`:

```markdown
# <Projektname> Dokumentation

Willkommen zur internen Dokumentation.

## Erste Schritte

Diese Dokumentation wird mit [VitePress](https://vitepress.dev) generiert und ist unter `/docs` erreichbar.

### Dokumentation bearbeiten

Markdown-Dateien liegen unter `.documentation/`. Nach Änderungen:

\`\`\`bash
npm run docs:build
\`\`\`

### Neue Seiten hinzufügen

1. Markdown-Datei unter `.documentation/` anlegen
2. Eintrag in `.documentation/.vitepress/config.mts` Sidebar hinzufügen
3. `npm run docs:build` ausführen
```

#### 13d: Build-Script in package.json hinzufügen

In `package.json` unter `scripts` hinzufügen:

```json
"docs:build": "vitepress build .documentation"
```

#### 13e: Controller erstellen

Erstelle den Controller der die statischen Docs-Dateien ausliefert:

**`app/Http/Controllers/ViewDocumentationController.php`:**

```php
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Response;

class ViewDocumentationController
{
    public function __invoke(Request $request, string $path = 'index.html'): BinaryFileResponse
    {
        Gate::authorize('viewDocumentation');

        $file = realpath(public_path("docs/{$path}"));
        $docsRoot = public_path('docs');

        abort_unless($file && str_starts_with($file, $docsRoot), Response::HTTP_NOT_FOUND);

        // Verzeichnis-URLs auf index.html auflösen
        if (is_dir($file)) {
            $file = rtrim($file, '/') . '/index.html';
        }

        abort_unless(file_exists($file), Response::HTTP_NOT_FOUND);

        return response()->file($file);
    }
}
```

#### 13f: ServiceProvider für Gate erstellen

Erstelle `app/Providers/DocumentationServiceProvider.php`:

```php
<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class DocumentationServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Gate::define('viewDocumentation', function ($user) {
            // Alle authentifizierten Nutzer haben Zugriff.
            // Einschränken z.B. per E-Mail oder Rolle:
            // return in_array($user->email, ['admin@example.com']);
            return true;
        });
    }
}
```

Registriere den Provider in `bootstrap/providers.php`:

```php
App\Providers\DocumentationServiceProvider::class,
```

#### 13g: Route registrieren

In `routes/web.php` hinzufügen.

**Falls Login gewählt wurde** (Auth vorhanden):

```php
Route::get('/docs/{path?}', \App\Http\Controllers\ViewDocumentationController::class)
    ->where('path', '.*')
    ->middleware(['auth']);
```

**Falls kein Login** (keine Auth-Middleware verfügbar):

```php
Route::get('/docs/{path?}', \App\Http\Controllers\ViewDocumentationController::class)
    ->where('path', '.*');
```

Passe in diesem Fall auch den `DocumentationServiceProvider` an — das Gate soll ohne Auth-Check funktionieren:

```php
Gate::define('viewDocumentation', function (?$user) {
    return true;
});
```

#### 13h: .gitignore ergänzen

In `.gitignore` hinzufügen:

```
/public/docs
```

#### 13i: Docs bauen

```bash
npm run docs:build
```

---

### Schritt 14: Abschluss

Ausführen:

```bash
npm install
npm run build
```

Falls VitePress eingerichtet wurde, auch `npm run docs:build` ausfuehren.

```bash
vendor/bin/pint
php artisan test --parallel
```

Wechsle ins Projektverzeichnis:

```bash
cd <HERD_DIR>/<projektname>
```

Ermittle die installierte Laravel-Version:

```bash
php artisan --version
```

Zeige die Erfolgsmeldung. Baue sie dynamisch zusammen je nach gewählten Optionen:

- Immer: URL, Dir, Laravel-Version, Livewire, MySQL, Larastan, IDE Helper, Debugbar, Boost, Codex, Simplifier, Pint + Tests
- Falls VitePress: zusätzlich Docs-URL und "VitePress Docs"
- Falls Login: zusätzlich Login-Zeile mit Credentials

**Beispiel ohne Login, ohne VitePress:**

```
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   Project "<projektname>" is ready to go!                    ║
║                                                              ║
║   URL:  https://<projektname>.test                           ║
║   Dir:  <HERD_DIR>/<projektname>                             ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║   <laravel-version> + Livewire   Larastan Level 5            ║
║   MySQL konfiguriert             IDE Helper + Debugbar       ║
║   Laravel Boost + MCP            Codex-ready (AGENTS.md)     ║
║   Simplifier Plugin              Pint + Tests bestanden      ║
║                                                              ║
║   Happy coding!                                              ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

**Beispiel mit Login und VitePress:**

```
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   Project "<projektname>" is ready to go!                    ║
║                                                              ║
║   URL:   https://<projektname>.test                          ║
║   Docs:  https://<projektname>.test/docs                     ║
║   Dir:   <HERD_DIR>/<projektname>                            ║
║                                                              ║
║   Login: admin@example.com / password                        ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║   <laravel-version> + Livewire   Larastan Level 5            ║
║   MySQL konfiguriert             IDE Helper + Debugbar       ║
║   Laravel Boost + MCP            Codex-ready (AGENTS.md)     ║
║   Simplifier Plugin              VitePress Docs              ║
║   Pint + Tests bestanden                                     ║
║                                                              ║
║   Happy coding!                                              ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

### Schritt 15: GitHub-Repository erstellen (optional)

Nach der Erfolgsmeldung den Nutzer fragen:

> **GitHub-Repository erstellen?** (ja/nein) — erstellt ein privates Repo und pushed den initialen Commit

**Falls ja:**

Prüfe ob `gh` CLI verfügbar ist:

```bash
which gh
```

Falls nicht vorhanden, informiere den Nutzer dass er die GitHub CLI installieren muss und überspringe diesen Schritt.

Falls vorhanden:

Prüfe zuerst dass `.gitignore` korrekt ist (`.env`, `node_modules`, `vendor` etc. müssen enthalten sein):

```bash
git init
git add .
git status
```

Falls `git status` sensible Dateien zeigt (`.env`, Credentials), brich ab und korrigiere `.gitignore`. Andernfalls:

```bash
git commit -m "Initial project setup"
gh repo create <projektname> --private --source=. --push
```

Zeige dem Nutzer die Repo-URL:

```
GitHub-Repository erstellt: https://github.com/<owner>/<projektname>
```

---

### Schritt 16: Wie geht es weiter?

Nach GitHub (oder nach der Erfolgsmeldung wenn kein GitHub gewählt wurde), zeige dem Nutzer eine Liste optionaler Feature-Integrationen:

> **Möchtest du direkt mit einem Feature starten?**
> Wähle mit **Enter** oder **Leertaste** aus, dann **Submit** zum Bestätigen. Mehrfachauswahl möglich.
>
> 1. OpenAI-Integration (KI-generierte Texte, Chat, etc.)
> 2. Filament Admin-Panel (Admin-Bereich mit CRUD, Dashboard, Widgets)
> 3. Laravel Cashier / Stripe (Zahlungen, Subscriptions, Rechnungen)
> 4. Nein, ich starte selbst

Der Nutzer kann eine oder mehrere Optionen wählen. Führe die gewählten Integrationen nacheinander aus. Nach jeder Integration einen Commit erstellen.

---

#### Feature: OpenAI-Integration

Lies `${CLAUDE_SKILL_DIR}/references/feature-openai.md` und führe die dortigen Schritte aus.

---

#### Feature: Filament Admin-Panel

Lies `${CLAUDE_SKILL_DIR}/references/feature-filament.md` und führe die dortigen Schritte aus.

---

#### Feature: Laravel Cashier / Stripe

Lies `${CLAUDE_SKILL_DIR}/references/feature-cashier.md` und führe die dortigen Schritte aus.
