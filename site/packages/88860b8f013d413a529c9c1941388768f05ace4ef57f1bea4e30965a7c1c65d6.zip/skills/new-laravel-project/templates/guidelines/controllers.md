# Controllers

## Validierte Daten verwenden

- In Controllern **immer** `$request->validated()` verwenden, **niemals** `$request->input()`
- Wenn ein FormRequest existiert, sind die Daten bereits validiert — nutze das
- Einzelne Felder: `$request->validated('field_name')`

### Schlecht

```php
public function __invoke(UpdateSettingRequest $request): RedirectResponse
{
    $campaignId = (int) $request->input('campaign_id');
    $isEnabled = (bool) $request->input('is_enabled');
}
```

### Gut

```php
public function __invoke(UpdateSettingRequest $request): RedirectResponse
{
    $campaignId = (int) $request->validated('campaign_id');
    $isEnabled = (bool) $request->validated('is_enabled');
}
```
