# Actions

## Methodennamen

- Die öffentliche Methode einer Action heißt **immer** `execute()` — nicht `executeForClient()`, `executeForTeam()`, `executeForTeamAndType()` etc.
- Bei unterschiedlichen Signaturen: eine einzige `execute()`-Methode mit passenden Parametern
- Actionname beschreibt den Kontext: `DeleteScheduledCampaignsForClientAction`

### Schlecht

```php
class DeleteAutomatedCampaignsAction
{
    public function executeForClient(Client $client): void { ... }
    public function executeForTeamAndCampaign(Team $team, Campaign $campaign): void { ... }
}
```

### Gut

```php
class DeleteScheduledCampaignsForClientAction
{
    public function execute(Client $client): void { ... }
}

class DeleteAutomatedCampaignsForTeamAction
{
    public function execute(Team $team, Campaign $campaign): void { ... }
}
```
