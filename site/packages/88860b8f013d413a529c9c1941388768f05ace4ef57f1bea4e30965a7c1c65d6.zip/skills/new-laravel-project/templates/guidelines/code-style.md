# Code-Stil & Patterns

## Nicht zu defensiv programmieren

- Prüfungen nur dort einbauen, wo sie tatsächlich gebraucht werden
- Typisches KI-Antipattern: Zu viele Null-Checks, Status-Prüfungen und Fallbacks, die in der Praxis nie eintreten

### Schlecht

```php
// Zu viele defensive Checks, die unnötig sind
if ($client->email === null) {
    return false;
}

if ($client->unsubscribed_from_all_at !== null) {
    return false;
}

if ($client->deactivated_at !== null) {
    return false;
}
```

### Besser

Nur die Prüfungen einbauen, die durch die Business-Logik tatsächlich erforderlich sind. Im Zweifel beim Team nachfragen.

## Events vs. Actions

- Vor dem Einsatz von Events genau überlegen, ob eine Action nicht der bessere Weg ist
- Events nur verwenden, wenn es wirklich lose Kopplung braucht (mehrere unabhängige Listener)
- Im Zweifelsfall: **Actions bevorzugen** — sie sind expliziter und einfacher zu debuggen

### Eher nicht

```php
// Im Controller:
ClientCreatedEvent::dispatch($client);

// Irgendwo ein Listener, der schwer zu finden ist
```

### Besser

```php
// Im Controller — explizit und nachvollziehbar:
$scheduleAction->execute($client);
```

## Eine fachliche Wahrheit

- Fachliche Regeln und Berechnungen sollen genau eine zentrale Wahrheit haben
- Bestehende Berechnungslogik nicht an anderer Stelle nochmal nachbauen
- Wenn dieselbe Logik an mehreren Stellen gebraucht wird: in eine Action oder klar benannte Klasse ziehen und wiederverwenden

## Deutsche Umlaute korrekt verwenden

- Im Frontend immer echte Umlaute schreiben: `ä`, `ö`, `ü`, `ß` — niemals `ae`, `oe`, `ue`, `ss`
- Gilt für alle nutzersichtbaren Texte: Labels, Buttons, Fehlermeldungen, Platzhalter, Überschriften
- Dateien müssen UTF-8-kodiert sein (Laravel-Standard)

### Schlecht

```
Rueckgaengig machen
Aenderungen uebernehmen
Gruesse
```

### Gut

```
Rückgängig machen
Änderungen übernehmen
Grüße
```

## PHP Enums statt hardcoded Strings

- Immer PHP Enums verwenden statt hardcoded Strings für Status, Rollen, Typen etc.
- Enums in der Datenbank, in Blade-Templates, in Tests und in der Business-Logik nutzen
- Enum-Keys in TitleCase: `Active`, `Pending`, `Monthly`

### Schlecht

```php
// Hardcoded Strings überall verstreut
$user->role = 'admin';
if ($order->status === 'pending') { ... }
```

### Gut

```php
enum UserRole: string
{
    case Admin = 'admin';
    case User = 'user';
}

enum OrderStatus: string
{
    case Pending = 'pending';
    case Completed = 'completed';
}

$user->role = UserRole::Admin;
if ($order->status === OrderStatus::Pending) { ... }
```

## Migrations nicht verketten

- Artisan-Migration-Befehle **niemals** mit `&&` oder `;` verketten
- Jeden Befehl einzeln ausführen — sonst können identische Timestamps entstehen

### Schlecht

```bash
php artisan make:migration create_orders_table && php artisan make:migration create_order_items_table
```

### Gut

```bash
php artisan make:migration create_orders_table
php artisan make:migration create_order_items_table
```

## Lazy Loading in Development verhindern

- In `AppServiceProvider::boot()` Lazy Loading im Development verhindern
- Hilft N+1-Probleme frühzeitig zu erkennen

```php
public function boot(): void
{
    Model::preventLazyLoading(! app()->isProduction());
}
```

## Code-Qualität mit Simplifier

- Bei größeren Code-Änderungen oder nach längeren Arbeitssessions den Laravel Simplifier laufen lassen (`/simplify`)
- Der Simplifier reduziert unnötige Komplexität, verbessert Lesbarkeit und räumt Diffs auf
- Erinnere den Entwickler regelmäßig daran, `/simplify` auszuführen, um das Projekt sauber zu halten
