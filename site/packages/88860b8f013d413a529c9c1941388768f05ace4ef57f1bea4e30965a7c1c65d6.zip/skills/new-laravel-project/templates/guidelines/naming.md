# Namenskonventionen

## Klassen-Suffix nach Funktion

Jede Klasse trägt ein Suffix, das ihre Funktion beschreibt:

- `Controller` — z.B. `ListClientsController`
- `Action` — z.B. `ResolveNextScheduleDateAction`
- `Rule` — z.B. `UniqueClientEmailRule`
- `Event` — z.B. `ClientCreatedEvent`
- `Listener` — z.B. `ClientListener`
- `Job` — z.B. `SendCampaignMailsJob`
- `Data` — z.B. `ClientData`
- `Request` — z.B. `StoreClientRequest`
- `Resource` — z.B. `ClientResource`
- `Policy` — z.B. `ClientPolicy`

**Ausnahme:** Models tragen kein Suffix. Ein Model heißt einfach `Client`, nicht `ClientModel`.
