# Testing

## Tests ausführen

- Tests immer mit `php artisan test --parallel` ausführen
- Nach dem Fixen einzelner Tests darf gezielt eine Datei getestet werden: `php artisan test --parallel tests/path/to/File.php`
- Vor einem Commit immer die vollständige Testsuite laufen lassen

## Test-Syntax: `test()` statt `it()`

- Immer `test('it ...',` verwenden, **nicht** `it('...',`
- Beispiel: `test('it can create a post', function () { ... });`

## Keine Helper-Funktionen in Tests

- **Keine** Helper-Funktionen, Utility-Funktionen oder wiederverwendbare Closures in Testdateien definieren
- Jeder Test muss vollständig und ausführlich geschrieben sein — alles inline, nichts abstrahiert
- Duplikation in Tests ist ausdrücklich gewünscht — Lesbarkeit und Wartbarkeit schlagen DRY

### Schlecht

```php
function createUser(): User
{
    return User::factory()->create();
}

test('it can update profile', function () {
    $user = createUser();
});
```

### Gut

```php
test('it can update profile', function () {
    $user = User::factory()->create();
});
```

## Pest-Laravel Hilfsfunktionen statt $this->

- In Pest Feature-Tests immer die Funktionen aus `Pest\Laravel` verwenden, **nicht** `$this->` Aufrufe
- Bevorzugt: `be($user)->post('/path', [...])`

### Gut

```php
use function Pest\Laravel\be;
use function Pest\Laravel\post;

test('it can create a post', function () {
    $user = User::factory()->create();

    be($user)->post('/posts', [
        'title' => 'Test',
    ]);
});
```

## Keine `route()` Helper in Tests

- In Tests **keine** `route()`-Funktion verwenden
- URLs/Pfade direkt als String angeben

## Factories statt manueller Model-Erstellung

- In Tests **immer** Factories verwenden, um Models zu erstellen
- Niemals `Model::create([...])` oder `new Model()` mit manuellen Attributen in Tests
- Keine Hilfsmethoden in Factories (z.B. `->disabled()`, `->premium()`)

## beforeEach / afterEach vermeiden

- Kein `beforeEach` / `afterEach` für fachliches Setup
- Alles direkt in den jeweiligen Test schreiben
- `beforeEach` nur für rein technisches Setup (z.B. `actingAs`)

## Tests sind Pflicht

- Jedes neue Feature muss mit Tests abgedeckt werden
- Bevorzugt Unit-Tests für Business-Logik (Actions, Services, Rules)
- Feature-Tests für HTTP-Endpoints und Controller-Flows
- Bei Frontend-relevanten Features zusätzlich Tests schreiben, die das Verhalten aus Nutzersicht abbilden (z.B. Formulare, Redirects, Validierung)
- Keine Funktionalität ohne zugehörigen Test mergen

## Test-Abdeckung

Jedes Feature muss folgende Szenarien abdecken:

- **Happy Path** — der Normalfall funktioniert
- **Ungültige Eingaben** — Validierung greift korrekt
- **Nicht autorisierter Zugriff** — unangemeldete/unbefugte Nutzer werden abgewiesen
- **Grenzfälle** — leere Listen, maximale Werte, Sonderzeichen

### Beispiel

```php
// Happy Path
test('it can create a post', function () { ... });

// Validierung
test('it requires a title to create a post', function () { ... });

// Autorisierung
test('it rejects unauthenticated users', function () { ... });

// Grenzfall
test('it handles empty body gracefully', function () { ... });
```
