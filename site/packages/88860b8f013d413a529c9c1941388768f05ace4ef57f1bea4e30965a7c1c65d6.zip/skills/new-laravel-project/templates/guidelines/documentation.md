# Dokumentation

## Grundsatz

- Neue Features müssen dokumentiert werden
- Dokumentation ist Teil der Definition of Done — ein Feature ohne Doku ist nicht fertig
- Dokumentation soll aktuell gehalten werden — veraltete Doku ist schlimmer als keine Doku

## Wo dokumentieren

- Feature-Dokumentation liegt unter `.documentation/` im Projektroot
- Jedes Feature oder fachliches Thema bekommt eine eigene Markdown-Datei
- Dateinamen in kebab-case: `user-management.md`, `email-campaigns.md`

## Was dokumentieren

- **Was** das Feature tut (fachliche Beschreibung)
- **Wie** es benutzt wird (API-Endpoints, Konfiguration, UI-Flows)
- **Warum** bestimmte Entscheidungen getroffen wurden (Architektur-Entscheidungen, Trade-offs)
- Relevante Kontext-Informationen die nicht aus dem Code ersichtlich sind

## Was NICHT dokumentieren

- Selbsterklärender Code (keine PHPDoc-Blöcke für triviale Getter/Setter)
- Implementation-Details die sich häufig ändern — der Code ist die Wahrheit
- Automatisch generierte API-Docs (dafür gibt es Tools)

## Bei Änderungen

- Wenn ein Feature geändert wird, die zugehörige Doku mitaktualisieren
- Veraltete Abschnitte entfernen statt auskommentieren

## Hinweis für KI-gestützte Entwicklung

- Bei jedem neuen Feature prüfen ob eine Dokumentation unter `.documentation/` existiert
- Falls nicht, eine neue Markdown-Datei anlegen und das Feature dokumentieren
- Falls ja, die bestehende Dokumentation aktualisieren
- Die Dokumentation gehört unter `.documentation/` — nicht in Code-Kommentare, nicht in README.md
