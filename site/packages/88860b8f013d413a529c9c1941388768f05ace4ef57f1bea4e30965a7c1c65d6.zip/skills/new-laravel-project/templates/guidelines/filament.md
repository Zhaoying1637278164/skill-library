# Filament

## Smoke Tests für alle Resources

- Für jede Filament-Resource müssen Smoke Tests existieren
- Mindestens: List-Page lädt, Create-Page lädt, Edit-Page lädt
- In Pest-Tests `Livewire::test()` verwenden, nicht `livewire()`

### Beispiel

```php
use Livewire\Livewire;
use App\Filament\Resources\UserResource\Pages\ListUsers;
use App\Filament\Resources\UserResource\Pages\CreateUser;

test('it can render the users list page', function () {
    Livewire::test(ListUsers::class)->assertSuccessful();
});

test('it can render the create user page', function () {
    Livewire::test(CreateUser::class)->assertSuccessful();
});
```

## Keine View-Page oder Infolist ohne Anweisung

- View-Pages und Infolists nur erstellen wenn explizit gefordert
- Standard: List + Create + Edit reichen für die meisten Resources

## FilaCheck

- Falls `laraveldaily/filacheck` installiert ist, nach jeder Änderung an Filament-Dateien ausführen:

```bash
vendor/bin/filacheck --fix
```

- FilaCheck vor den Pest-Tests laufen lassen

## Panel-Konfiguration

- Alle Panel-Einstellungen im `AdminPanelProvider` zentralisieren
- Navigation, Theme, Middleware und Widgets dort konfigurieren
- Keine Panel-Konfiguration in anderen Service Providern verstreuen
