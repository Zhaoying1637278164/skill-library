# Routing

## Keine Inline-Logik in Routes

- Route-Dateien sollen ausschließlich Routing enthalten — keine Business-Logik, keine Closures mit Funktionalität
- Jede Route verweist auf einen Controller oder eine Invokable Action
- Routes sollen auf einen Blick lesbar sein

### Schlecht

```php
Route::post('/users', function (Request $request) {
    $validated = $request->validate(['name' => 'required', 'email' => 'required|email']);
    $user = User::create($validated);
    Mail::to($user)->send(new WelcomeMail($user));

    return redirect('/users');
});
```

### Gut

```php
Route::post('/users', StoreUserController::class);
```

## Route-Dateien clean halten

- Routen logisch gruppieren (z.B. nach Feature oder Resource)
- Middleware über Gruppen zuweisen, nicht pro Route
- Keine auskommentierten Routen stehen lassen
