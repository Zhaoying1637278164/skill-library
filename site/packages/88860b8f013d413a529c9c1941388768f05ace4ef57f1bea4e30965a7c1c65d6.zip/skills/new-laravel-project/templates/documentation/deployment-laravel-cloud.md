# Deployment auf Laravel Cloud

Schritt-für-Schritt-Anleitung um das Projekt auf [Laravel Cloud](https://cloud.laravel.com) live zu bringen.

## Voraussetzungen

- GitHub-Repository mit dem Projekt
- Laravel Cloud Account ([cloud.laravel.com](https://cloud.laravel.com))

## 1. Application erstellen

1. Im Laravel Cloud Dashboard auf **+ New application** klicken
2. Git-Provider (GitHub) verbinden und autorisieren
3. Repository auswählen
4. Application-Name und **Region** festlegen
5. Application erstellen

## 2. MySQL-Datenbank anlegen

1. In der Environment-Ansicht auf **Add database** klicken
2. **Neuen Cluster erstellen** oder bestehenden verwenden
3. Konfigurieren:
   - **Cluster-Name** vergeben
   - **Instance Size** wählen (Flex für den Start)
   - **Storage** festlegen (5 GB reicht zum Start)
   - **Region** muss mit dem Compute-Cluster übereinstimmen
4. Datenbank im Cluster erstellen

Die Umgebungsvariablen (`DB_HOST`, `DB_USERNAME`, `DB_PASSWORD`, `DB_DATABASE`) werden automatisch injiziert.

### SSL-Verbindung aktivieren

Folgende Umgebungsvariable setzen:

```
MYSQL_ATTR_SSL_CA="/etc/ssl/certs/ca-certificates.crt"
```

## 3. Umgebungsvariablen konfigurieren

Im Environment unter **Environment Variables** mindestens setzen:

```
APP_NAME="Projektname"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://deine-domain.com
```

Weitere je nach Bedarf (Mail, S3, etc.).

## 4. Scheduler / Cron aktivieren

1. Im Environment den **App Compute Cluster** öffnen
2. **Scheduler** auf "Enabled" setzen
3. Speichern und deployen

Laravel Cloud führt dann automatisch `schedule:run` jede Minute aus.

**Wichtig bei mehreren Replicas:** In `routes/console.php` bzw. `app/Console/Kernel.php` die Methode `->onOneServer()` an geplante Tasks hängen, damit sie nicht mehrfach laufen:

```php
Schedule::command('some:command')->daily()->onOneServer();
```

## 5. Deployment

1. Im Environment auf **Deploy** klicken
2. Laravel Cloud baut und deployed automatisch
3. Zero-Downtime-Deployment ist Standard

Jedes Mal wenn du auf den gewählten Branch pushst, wird automatisch deployed.

## Checkliste vor Go-Live

- [ ] Umgebungsvariablen gesetzt (APP_ENV=production, APP_DEBUG=false)
- [ ] MySQL-Datenbank erstellt und verbunden
- [ ] SSL-Umgebungsvariable gesetzt
- [ ] Scheduler aktiviert
- [ ] Migrations laufen (`php artisan migrate` wird beim Deploy ausgeführt)
- [ ] Domain konfiguriert (optional)
