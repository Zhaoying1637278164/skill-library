# ClickUp Plugin

Connect your ClickUp workspace to your favorite AI coding tools. Manage tasks, track time, search your workspace, and more — without switching context.

## Install

### Claude Code

From the terminal:
```bash
claude plugin marketplace add clickup/clickup-plugin
claude plugin install clickup@clickup-plugin-marketplace
```

Or from inside Claude Code:
```
/plugin marketplace add clickup/clickup-plugin
/plugin install clickup@clickup-plugin-marketplace
```

### Cursor

Install from the [Cursor Marketplace](https://cursor.com/marketplace) — search for **ClickUp**.

### Other clients (Agent Plugins standard)

This repo also ships a portable [Agent Plugins](https://agent-plugins.org/) package (root `plugin.json` + `mcp.json`), so it works in any client that supports the open standard — including OpenAI Codex, GitHub Copilot / VS Code, Kiro, and Cursor. Follow your client's plugin install flow and point it at this repository.

## What's Included

### MCP Server

The plugin connects to ClickUp's hosted MCP server, giving your AI assistant access to your workspace.

[See the list of supported tools](https://developer.clickup.com/docs/mcp-tools).

#### Authentication

On first use, you'll be prompted to authorize with your ClickUp account via OAuth.

#### Troubleshooting

**OAuth not triggering?** Make sure your editor supports remote MCP servers with OAuth (Cursor 0.42+).

**MCP not loading?** Try installing manually:
```json
{
  "mcpServers": {
    "clickup": {
      "type": "http",
      "url": "https://mcp.clickup.com/mcp"
    }
  }
}
```
Or the stdio fallback:

```json
{
  "mcpServers": {
    "clickup": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.clickup.com/mcp"]
    }
  }
}
```

### Skills

The plugin includes three skills — workflow playbooks the assistant follows for jobs that take more than one tool call. Each activates on a plain-language request, previews anything it plans to create, and waits for your approval before writing to your workspace.

- **task-decomposition** — "break this down": turns a goal or oversized task into a small set of ordered subtasks with dependencies.
- **daily-standup** — "run my standup": drafts a standup from your open work, asks what changed, writes your answers back to the tasks, and gives you the summary to share.
- **repeat-project** — "set this up for the new client": rebuilds a finished project for the next run, swapping in the new details and shifting every date onto the new schedule.

Skills live in `skills/<name>/SKILL.md` and are discovered automatically — no configuration needed.

## Links

- [ClickUp MCP Docs](https://developer.clickup.com/docs/connect-an-ai-assistant-to-clickups-mcp-server)
