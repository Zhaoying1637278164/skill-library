# Beeceptor Claude Plugin

Mock, inspect, and test HTTP APIs from Claude Code without leaving your editor.

This repository contains the Beeceptor Claude plugin source for
[Beeceptor](https://beeceptor.com). It bundles the Beeceptor MCP connection plus
Claude-native skills, commands, and agents for:

- Creating mock APIs from natural-language descriptions
- Inspecting live request history for debugging
- Configuring CRUD routes, weighted failures, latency, and stateful flows

## What is included

| Component | Path | Purpose |
|-----------|------|---------|
| Plugin manifest | `.claude-plugin/plugin.json` | Claude plugin metadata and namespace |
| Marketplace manifest | `.claude-plugin/marketplace.json` | Marketplace metadata kept with the plugin source |
| MCP config | `.mcp.json` | Connects Claude to Beeceptor over HTTP MCP |
| Skills | `skills/` | Reusable Beeceptor workflows Claude can invoke automatically |
| Commands | `commands/` | Manual one-shot workflows for common tasks |
| Agents | `agents/` | Specialized helpers for full mock setup and chaos testing |

## MCP transport

The plugin uses:

```json
{
  "mcpServers": {
    "beeceptor": {
      "type": "http",
      "url": "https://mcp.beeceptor.com/mcp"
    }
  }
}
```

This points directly at the Beeceptor production MCP endpoint.

## Included workflows

### Skills

- `mock-api-designer`: turn route specs into live Beeceptor rules
- `request-inspector`: inspect and summarize captured traffic

### Commands

- `create-crud-mock`: scaffold a REST resource quickly
- `inspect-recent-requests`: review the latest calls hitting an endpoint

### Agents

- `api-mock-setup`: build an end-to-end mock API from a description
- `chaos-tester`: add weighted failures, delays, and retry scenarios

## Beeceptor MCP capabilities exposed

The plugin is designed around the current Beeceptor MCP implementation:

- Endpoint selection and provisioning
- Rule CRUD, reorder, bulk replace, weighted rules, callouts, and CRUD routes
- Request history inspection and cleanup
- Stateful mocking helpers and state data management
- Endpoint settings management
- Template syntax reference for Handlebars and Faker helpers

 
