---
name: inspect-recent-requests
description: Fetch and summarize the most recent requests captured by the active Beeceptor endpoint.
---

# Inspect Recent Requests

1. Call `endpoint_list` to confirm the active endpoint.
2. Call `request_history_list` with a reasonable default limit of 20 unless the
   user specifies another value.
3. For each relevant entry, summarize timestamp, method, path, matched rule,
   and response status.
4. If the user points to a specific request, call `request_history_get`.
5. Flag requests where no rule matched and suggest the most likely fix.

