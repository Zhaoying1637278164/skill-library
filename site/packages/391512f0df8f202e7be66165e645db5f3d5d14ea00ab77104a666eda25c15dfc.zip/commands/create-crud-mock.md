---
name: create-crud-mock
description: Scaffold a CRUD mock for a REST resource on Beeceptor.
---

# Create CRUD Mock

1. Ask for the resource path and ID field name if they are not already given.
2. Call `endpoint_list` to confirm the active endpoint.
3. Call `rule_create_crud` for the resource path.
4. Call `endpoint_info` to fetch the live mock base URL.
5. Return curl examples for list, get, create, update, and delete operations.

