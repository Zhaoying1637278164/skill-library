---
name: mock-api-designer
description: Design and build a complete mock API on Beeceptor from a route list or service description.
---

# Mock API Designer

Use this skill when the user wants a live Beeceptor mock without manually
editing rules in the dashboard.

## When to use

- The backend is not ready and a frontend or integration team needs a mock API.
- The user has a route table and wants Beeceptor to stand up realistic
  responses.
- The user needs CRUD routes, dynamic data, chaos responses, or proxy callouts.

## Workflow

1. Call `endpoint_list` to inspect existing endpoints and the current selection.
2. If no suitable endpoint exists, call `endpoint_create_free`.
3. Call `rule_list` before creating or changing rules.
4. Call `syntax_info` before using Handlebars or Faker helpers. Do not guess.
5. Create rules in this order:
   - `rule_create_crud` for full REST resources
   - `rule_create_weighted` for multi-outcome or chaos behavior
   - `rule_create_callout` for forward/proxy workflows
   - `rule_create` for standard mock responses
6. Call `endpoint_info` after setup and return the live mock base URL.

## Response rules

- Prefer `templated: true` with `{{faker '...'}}` and `{{body '...'}}` in the
  response body.
- Keep JSON bodies pretty-printed with 2-space indentation.
- Set `Content-Type: application/json; charset=utf-8` for JSON responses.
- Keep response headers as static strings only.
- Use realistic `delay` values when simulating latency.

## Output

Return:

- The selected endpoint name
- The `mockBaseUrl`
- A concise summary of rules created
- Any caveats about rule priority, state, or existing rules

