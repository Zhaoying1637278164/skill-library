---
name: request-inspector
description: Inspect and analyze Beeceptor request history to debug client integrations and rule mismatches.
---

# Request Inspector

Use this skill to analyze real HTTP traffic captured by a Beeceptor endpoint.

## When to use

- A client call hit Beeceptor but the response or rule match was unexpected.
- The user wants to inspect headers, payloads, timestamps, or matched rules.
- The user needs to verify request sequencing for a stateful mock flow.

## Workflow

1. Call `endpoint_list` to confirm the active endpoint.
2. Call `request_history_list` with a practical limit.
3. For suspicious entries, call `request_history_get` to inspect full request
   and response details.
4. Summarize:
   - What was called
   - Which rule matched, or whether no rule matched
   - Relevant header and payload anomalies
   - Recommended next actions
5. Use `request_history_delete` or `request_history_purge` only if the user
   explicitly asks.

## Output

Return a concise debug summary with method, path, timestamps, matched rule
status, and likely root cause.

