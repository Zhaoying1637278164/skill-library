# Impulse MCP Plugin

Train, deploy, and predict with [Impulse](https://impulselabs.ai) ML models
directly from Claude Code and Cowork.

This plugin connects Claude to Impulse's hosted MCP gateway
(`https://api.impulselabs.ai`) - it doesn't bundle its own server, so tool
updates on Impulse's side are available immediately with no plugin update
needed.

## Install

```
/plugin marketplace add anthropics/claude-plugins-community
/plugin install impulse@claude-community
```

When prompted, you can leave the Impulse Gateway URL and API key fields at
their defaults - see [Setup](#setup) below for how authentication works.

## Setup

Impulse authenticates via OAuth by default - no API key required. The first
time Claude calls an Impulse tool that needs authenticated access, it opens
your browser to sign in (or sign up) with Impulse; approve access and you're
authenticated from then on.

If you'd rather use a static API key instead of OAuth:

1. Sign up or log in at <https://app.impulselabs.ai>.
2. Create an API key at <https://app.impulselabs.ai/api-keys>.
3. Run `/plugin configure impulse` and paste the key in.

Either way, ask Claude to call `impulse_auth_status` to confirm - it should
show `mode=authenticated`.

## What you can do

- `impulse_chat` - describe what you want to build; Impulse trains through
  its own pipeline rather than local scripts.
- `impulse_dataset_upload_base64` - upload a dataset.
- `impulse_session_snapshot` / `impulse_session_wait` - check on a running
  session without resending your prompt.
- `impulse_session_artifacts` - list and download trained models,
  predictions, and reports.
- `impulse_model_deploy` / `impulse_model_predict` - deploy a trained model
  and run predictions against it.
- `impulse_usage_summary` / `impulse_billing_status` - check usage and plan
  status.

## Privacy

This plugin sends your prompts, dataset content, and tool-call data to
Impulse's hosted gateway (`https://api.impulselabs.ai`) to run the requested
training, deployment, and prediction workflows. Authentication (OAuth token
or API key) is sent to Impulse on each request and isn't shared with
Anthropic or any other third party. See the
[Impulse Privacy Policy](https://www.impulselabs.ai/privacy-policy) for
details on what's collected and how it's used.

## Support

- Documentation: <https://impulselabs.ai>
- Issues with this plugin: [open a GitHub issue](https://github.com/impulse-ai/impulse-mcp-plugin/issues)

## License

MIT - see [LICENSE](LICENSE).
