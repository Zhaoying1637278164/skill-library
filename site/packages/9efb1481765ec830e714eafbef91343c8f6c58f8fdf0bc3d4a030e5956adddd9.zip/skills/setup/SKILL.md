---
description: Walk the user through authenticating with Impulse so Impulse MCP tools work. Use this when the user first installs the plugin, asks how to set up Impulse, or when an Impulse tool call fails with an auth-required/401 error.
---

# Impulse setup

Impulse authenticates via OAuth by default - no API key required. If you see
an `auth_required` or `invalid_token` error from any `impulse_*` tool,
Claude should prompt the user to sign in through their browser as part of
the tool call. Have them approve access there; once they're back, retry the
tool call.

If OAuth isn't available in this environment, or the user prefers a static
key, walk them through this instead:

1. **Sign up or log in** at <https://app.impulselabs.ai> if they don't
   already have an Impulse account.
2. **Create an API key** at <https://app.impulselabs.ai/api-keys>. Give it a
   name like "Claude Code".
3. **Configure the plugin** with that key:
   ```
   /plugin configure impulse
   ```
   Paste the key into the `api_key` field when prompted. It's stored in the
   OS keychain (or `~/.claude/.credentials.json` if no keychain is
   available), never written to a plain config file.
4. **Verify it worked** by calling `impulse_auth_status`. A successful
   response shows `mode=authenticated` (`auth_source=api_key` or
   `auth_source=bearer token`). If it still shows `mode=guest` or an error,
   the key wasn't picked up - re-run `/plugin configure impulse` and confirm
   there's no leading/trailing whitespace in the pasted key.

Once authenticated, the user can start with `impulse_chat` to describe what
they want to build (train a model, run a prediction, etc.) - Impulse trains
through its own pipeline, not by writing local training scripts.
