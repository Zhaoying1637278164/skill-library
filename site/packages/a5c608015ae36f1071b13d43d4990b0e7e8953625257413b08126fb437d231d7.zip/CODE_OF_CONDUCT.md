# Code of Conduct

## Our standards

This project follows the [Contributor Covenant](https://www.contributor-covenant.org/) v2.1.

### Examples of behavior that contributes to a positive environment

- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologizing to those affected by our mistakes
- Focusing on what is best for the overall community

### Examples of unacceptable behavior

- Sexualized language or imagery, sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, personal attacks
- Public or private harassment
- Publishing others' private information without explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the maintainers at ignacio@work-smart.ai.

All complaints will be reviewed and investigated promptly and fairly. Maintainers will respect the privacy and security of the reporter of any incident.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1, available at [https://www.contributor-covenant.org/version/2/1/code_of_conduct.html](https://www.contributor-covenant.org/version/2/1/code_of_conduct.html).
