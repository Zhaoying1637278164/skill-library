# RTL Chat Fixer

Fix jumbled text when mixing RTL languages with English in chat. Ensures clean, readable mixed-direction output.

## Supported Languages

Hebrew, Arabic, Persian, Urdu, Pashto, Sindhi, Kurdish (Sorani), Yiddish, Dhivehi.

## Formatting Rules

When responding in a mix of RTL and English:

1. **One English term per line max** — never stack multiple LTR terms on one line
2. **English at line ends** — place LTR terms at line boundaries for clean rendering
3. **Short paragraphs** — minimize direction-switching confusion
4. **Backtick all code** — wrap code, paths, and technical terms in backticks
5. **No markdown lists in mixed content** — use prose instead; lists get jumbled
6. **No tables for mixed content** — markdown tables are the worst BiDi case; use short labelled paragraphs
7. **No brackets around LTR terms** — parentheses or quotes around an English term inside RTL text flip to the wrong side

## Configuration

None required. Activates automatically when RTL text is detected in the conversation.

## Best Practices

- Break lines before inserting English terms into RTL text
- Use fenced code blocks to isolate longer LTR content
- If a response is mostly English with a few RTL words, standard LTR formatting is fine
- Test each line reads naturally in its dominant direction
- In Cowork/agent mode, keep file paths, branch names and command output in code blocks or on their own line — they are LTR-dense and jumble worst

## Execution Model
**Plan:** Detect Hebrew/RTL content in user messages.
**Act:** Apply BiDi formatting rules to response text.
**Verify:** Ensure rendered output is readable with minimal LTR/RTL mixing per line.

**Impact Level:** Low (formatting only, no external actions)
**Approval Gates:** None required — read-only text formatting.
