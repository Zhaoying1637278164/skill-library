#!/usr/bin/env python3
"""Post-process Docling extraction: generic figure/table cleanup and renumbering.

Works with ANY PDF — no hardcoded mappings. Automatically:
  1. Skips tiny artifacts (< 100px in either dimension)
  2. Detects misclassified images (caption says "Table X") and moves to tables
  3. Detects captionless tables following a captioned table on the same page
     and merges them horizontally (Docling often splits multi-part tables)
  4. Uses CAPTION-BASED numbering: "Figure 3: ..." → image_3.png, "Table 2: ..." → table_2.png
     Uncaptioned items get sequential numbers starting after the highest captioned number.

Usage:
    python postprocess_figures.py [workspace_dir]
"""

import json
import os
import re
import shutil
import sys
from PIL import Image

MIN_DIM = 100  # skip images smaller than this in either dimension


def parse_figure_num(caption):
    """Extract figure number from caption like 'Figure 3: ...' or 'Fig. 3: ...'"""
    m = re.match(r"(?:Figure|Fig\.?)\s*(\d+)", caption, re.IGNORECASE)
    return int(m.group(1)) if m else None


def parse_table_num(caption):
    """Extract table number from caption like 'Table 2: ...'"""
    m = re.match(r"Table\s*(\d+)", caption, re.IGNORECASE)
    return int(m.group(1)) if m else None


def is_table_caption(caption):
    """Check if an image's caption indicates it's actually a table."""
    return bool(re.match(r"Table\s*\d+", caption.strip(), re.IGNORECASE))


def main():
    workspace = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
    figures_dir = os.path.join(workspace, "figures")

    with open(os.path.join(workspace, "images.json")) as f:
        images = json.load(f)
    with open(os.path.join(workspace, "tables.json")) as f:
        tables = json.load(f)

    print(f"[postprocess] Input: {len(images)} images, {len(tables)} tables")

    # ── STEP 1: Classify images ──
    sorted_img_keys = sorted(images.keys(), key=lambda k: int(re.search(r"\d+", k).group()))

    real_images = []      # (old_key, meta) — genuine figures
    reclassed_tables = [] # (old_key, meta) — images that are actually tables

    for key in sorted_img_keys:
        meta = images[key]
        w, h = meta.get("width", 0), meta.get("height", 0)
        caption = meta.get("caption", "")

        # Skip tiny artifacts
        if w < MIN_DIM or h < MIN_DIM:
            print(f"  SKIP {key}: tiny artifact ({w}x{h})")
            continue

        # Detect misclassified tables (image with "Table N" caption)
        if is_table_caption(caption):
            reclassed_tables.append((key, meta))
            print(f"  RECLASS {key} → table (caption: {caption[:60]})")
            continue

        real_images.append((key, meta))

    # ── STEP 2: Handle tables ──
    sorted_tbl_keys = sorted(tables.keys(), key=lambda k: int(re.search(r"\d+", k).group()))

    # Group tables: captionless tables on the same page after a captioned table
    # are likely parts of the same table split by Docling → merge horizontally
    table_groups = []
    current_group = None

    for key in sorted_tbl_keys:
        meta = tables[key]
        caption = meta.get("caption", "").strip()
        page_no = meta.get("page_no", 0)

        if caption:
            if current_group:
                table_groups.append(current_group)
            current_group = [(key, meta)]
        else:
            if current_group:
                prev_page = current_group[-1][1].get("page_no", -1)
                if page_no == prev_page:
                    current_group.append((key, meta))
                    print(f"  MERGE {key} into group (same page {page_no}, no caption)")
                else:
                    table_groups.append(current_group)
                    current_group = [(key, meta)]
            else:
                current_group = [(key, meta)]

    if current_group:
        table_groups.append(current_group)

    # Add reclassified images as additional table groups
    for key, meta in reclassed_tables:
        table_groups.append([(key, meta)])

    # Sort table groups by page number
    table_groups.sort(key=lambda g: g[0][1].get("page_no", 0))

    # ── STEP 3: Write to temp dir ──
    tmp_dir = os.path.join(figures_dir, "_tmp")
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.makedirs(tmp_dir)

    # ── Process images: caption-based numbering ──
    # First pass: assign numbers from captions (e.g., "Figure 3: ..." → image_3)
    captioned_imgs = {}   # paper_num → (old_key, meta)
    uncaptioned_imgs = [] # (old_key, meta) — no figure number in caption

    for old_key, meta in real_images:
        caption = meta.get("caption", "")
        fig_num = parse_figure_num(caption)
        if fig_num is not None:
            captioned_imgs[fig_num] = (old_key, meta)
        else:
            uncaptioned_imgs.append((old_key, meta))

    # Second pass: assign sequential numbers for uncaptioned images
    max_fig = max(captioned_imgs.keys()) if captioned_imgs else 0
    next_fig = max_fig + 1
    for old_key, meta in uncaptioned_imgs:
        captioned_imgs[next_fig] = (old_key, meta)
        next_fig += 1

    # Write image files with caption-based numbering
    new_images = {}
    for fig_num in sorted(captioned_imgs.keys()):
        old_key, meta = captioned_imgs[fig_num]
        new_key = f"image_{fig_num}"
        old_path = os.path.join(figures_dir, f"{old_key}.png")
        if os.path.exists(old_path):
            shutil.copy2(old_path, os.path.join(tmp_dir, f"{new_key}.png"))
            new_meta = meta.copy()
            new_meta["image_path"] = f"workspace/figures/{new_key}.png"
            new_images[new_key] = new_meta
            caption = meta.get("caption", "")
            label = f"Fig {fig_num}" if parse_figure_num(caption) else "uncaptioned"
            print(f"  {old_key} → {new_key} ({label})")

    # ── Process tables: caption-based numbering ──
    captioned_tbls = {}   # paper_num → (group, caption, page_no)
    uncaptioned_tbls = [] # (group,)

    for group in table_groups:
        # Find caption from first captioned item in group
        caption = ""
        page_no = 0
        for _, meta in group:
            c = meta.get("caption", "").strip()
            if c:
                caption = c
                page_no = meta.get("page_no", 0)
                break
            page_no = meta.get("page_no", page_no)

        tbl_num = parse_table_num(caption)
        if tbl_num is not None:
            captioned_tbls[tbl_num] = (group, caption, page_no)
        else:
            uncaptioned_tbls.append((group, caption, page_no))

    # Assign sequential numbers for uncaptioned tables
    max_tbl = max(captioned_tbls.keys()) if captioned_tbls else 0
    next_tbl = max_tbl + 1
    for group, caption, page_no in uncaptioned_tbls:
        captioned_tbls[next_tbl] = (group, caption, page_no)
        next_tbl += 1

    # Write table files with caption-based numbering
    new_tables = {}
    for tbl_num in sorted(captioned_tbls.keys()):
        group, caption, page_no = captioned_tbls[tbl_num]
        new_key = f"table_{tbl_num}"

        if len(group) == 1:
            old_key, meta = group[0]
            old_path = os.path.join(figures_dir, f"{old_key}.png")
            if os.path.exists(old_path):
                shutil.copy2(old_path, os.path.join(tmp_dir, f"{new_key}.png"))
            new_meta = meta.copy()
            new_meta["table_path"] = f"workspace/figures/{new_key}.png"
            if caption:
                new_meta["caption"] = caption
            new_tables[new_key] = new_meta
            src = "image" if old_key.startswith("image_") else "table"
            label = f"Table {tbl_num}" if parse_table_num(caption) else "uncaptioned"
            print(f"  {old_key} ({src}) → {new_key} ({label})")
        else:
            # Multi-part table — merge horizontally
            parts = []
            for old_key, meta in group:
                old_path = os.path.join(figures_dir, f"{old_key}.png")
                if os.path.exists(old_path):
                    parts.append(Image.open(old_path))

            if parts:
                gap = 10
                total_w = sum(p.width for p in parts) + gap * (len(parts) - 1)
                max_h = max(p.height for p in parts)
                merged = Image.new("RGB", (total_w, max_h), (255, 255, 255))
                x_offset = 0
                for p in parts:
                    merged.paste(p, (x_offset, 0))
                    x_offset += p.width + gap
                merged.save(os.path.join(tmp_dir, f"{new_key}.png"))
                for p in parts:
                    p.close()

                new_tables[new_key] = {
                    "caption": caption,
                    "page_no": page_no,
                    "table_path": f"workspace/figures/{new_key}.png",
                    "width": total_w,
                    "height": max_h,
                    "figure_aspect": round(total_w / max_h, 2) if max_h > 0 else 1,
                }
                part_keys = [k for k, _ in group]
                label = f"Table {tbl_num}" if parse_table_num(caption) else "uncaptioned"
                print(f"  {' + '.join(part_keys)} → {new_key} (merged {len(parts)} parts, {label})")

    # ── STEP 4: Replace files ──
    for fn in os.listdir(figures_dir):
        full = os.path.join(figures_dir, fn)
        if fn.endswith(".png") and os.path.isfile(full):
            os.remove(full)

    for fn in os.listdir(tmp_dir):
        if fn.endswith(".png"):
            shutil.move(os.path.join(tmp_dir, fn), os.path.join(figures_dir, fn))
    shutil.rmtree(tmp_dir)

    # ── STEP 5: Update dimensions from actual files ──
    for key in list(new_images.keys()):
        fpath = os.path.join(figures_dir, f"{key}.png")
        if os.path.exists(fpath):
            with Image.open(fpath) as img:
                new_images[key]["width"] = img.size[0]
                new_images[key]["height"] = img.size[1]
                new_images[key]["figure_aspect"] = round(img.size[0] / img.size[1], 2) if img.size[1] > 0 else 1
    for key in list(new_tables.keys()):
        fpath = os.path.join(figures_dir, f"{key}.png")
        if os.path.exists(fpath):
            with Image.open(fpath) as img:
                new_tables[key]["width"] = img.size[0]
                new_tables[key]["height"] = img.size[1]
                new_tables[key]["figure_aspect"] = round(img.size[0] / img.size[1], 2) if img.size[1] > 0 else 1

    # ── STEP 6: Save metadata ──
    with open(os.path.join(workspace, "images.json"), "w") as f:
        json.dump(new_images, f, indent=2)
    with open(os.path.join(workspace, "tables.json"), "w") as f:
        json.dump(new_tables, f, indent=2)

    print(f"\n=== Final: {len(new_images)} images, {len(new_tables)} tables ===")
    for fn in sorted(os.listdir(figures_dir), key=lambda f: (f.split("_")[0], int(re.search(r"\d+", f).group()) if re.search(r"\d+", f) else 0)):
        if fn.endswith(".png"):
            sz = os.path.getsize(os.path.join(figures_dir, fn))
            with Image.open(os.path.join(figures_dir, fn)) as img:
                print(f"  {fn}: {img.size[0]}x{img.size[1]}, {sz // 1024}K")


if __name__ == "__main__":
    main()
