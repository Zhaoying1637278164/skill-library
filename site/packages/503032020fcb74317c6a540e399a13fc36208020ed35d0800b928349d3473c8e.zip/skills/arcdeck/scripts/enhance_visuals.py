#!/usr/bin/env python3
"""Visual Enhancer v2 — Rich programmatic diagrams for every text-only slide.

Reads slide_plan_refined.json for content-aware diagram generation.
Adds process flows, cycle diagrams, comparison boxes, stats callouts,
timelines, hierarchy trees, icon grids, and quote callouts.
"""

import json
import math
import os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_SHAPE_TYPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn

WORKSPACE = os.environ.get("ARCDECK_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
SLIDE_W = Inches(13.33)
SLIDE_H = Inches(7.5)

# ─── Color Palette ───
PALETTES = {
    "blue": {
        "primary": RGBColor(0x1A, 0x56, 0xDB),
        "secondary": RGBColor(0x3B, 0x82, 0xF6),
        "light": RGBColor(0x93, 0xBB, 0xFD),
        "bg": RGBColor(0xEF, 0xF6, 0xFF),
        "dark": RGBColor(0x1E, 0x3A, 0x5F),
    },
    "teal": {
        "primary": RGBColor(0x0D, 0x94, 0x88),
        "secondary": RGBColor(0x14, 0xB8, 0xA6),
        "light": RGBColor(0x5E, 0xEA, 0xD4),
        "bg": RGBColor(0xF0, 0xFD, 0xFA),
        "dark": RGBColor(0x13, 0x4E, 0x4A),
    },
    "purple": {
        "primary": RGBColor(0x7C, 0x3A, 0xED),
        "secondary": RGBColor(0xA7, 0x8B, 0xFA),
        "light": RGBColor(0xC4, 0xB5, 0xFD),
        "bg": RGBColor(0xF5, 0xF3, 0xFF),
        "dark": RGBColor(0x4C, 0x1D, 0x95),
    },
    "amber": {
        "primary": RGBColor(0xD9, 0x77, 0x06),
        "secondary": RGBColor(0xF5, 0x9E, 0x0B),
        "light": RGBColor(0xFD, 0xE6, 0x8A),
        "bg": RGBColor(0xFF, 0xFB, 0xEB),
        "dark": RGBColor(0x92, 0x40, 0x0E),
    },
    "rose": {
        "primary": RGBColor(0xE1, 0x1D, 0x48),
        "secondary": RGBColor(0xFB, 0x72, 0x85),
        "light": RGBColor(0xFD, 0xA4, 0xAF),
        "bg": RGBColor(0xFF, 0xF1, 0xF2),
        "dark": RGBColor(0x9F, 0x12, 0x39),
    },
}

GRAY = RGBColor(0x94, 0xA3, 0xB8)
GRAY_LIGHT = RGBColor(0xE2, 0xE8, 0xF0)
GRAY_BG = RGBColor(0xF8, 0xFA, 0xFC)
DARK_TEXT = RGBColor(0x1E, 0x29, 0x3B)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
ACCENT_RED = RGBColor(0xEF, 0x44, 0x44)
ACCENT_GREEN = RGBColor(0x22, 0xC5, 0x5E)

# Track which palette each slide uses for variety
_palette_idx = 0
_palette_names = list(PALETTES.keys())


def next_palette():
    global _palette_idx
    p = PALETTES[_palette_names[_palette_idx % len(_palette_names)]]
    _palette_idx += 1
    return p


# ─── Shape Helpers ───

def _set_anchor_ctr(shape):
    try:
        bodyPr = shape._element.txBody.find(qn("a:bodyPr"))
        if bodyPr is not None:
            bodyPr.set("anchor", "ctr")
    except Exception:
        pass


def _set_no_line(shape):
    shape.line.fill.background()


def _add_shadow(shape, blur=40000, dist=23000, alpha=25000):
    try:
        spPr = shape._element.spPr
        effectLst = OxmlElement("a:effectLst")
        outerShdw = OxmlElement("a:outerShdw")
        outerShdw.set("blurRad", str(blur))
        outerShdw.set("dist", str(dist))
        outerShdw.set("dir", "5400000")
        outerShdw.set("rotWithShape", "0")
        srgbClr = OxmlElement("a:srgbClr")
        srgbClr.set("val", "000000")
        a = OxmlElement("a:alpha")
        a.set("val", str(alpha))
        srgbClr.append(a)
        outerShdw.append(srgbClr)
        effectLst.append(outerShdw)
        spPr.append(effectLst)
    except Exception:
        pass


def _rounded_rect(slide, left, top, w, h, text, fill, text_color=WHITE,
                  font_size=10, bold=True, border=None, shadow=True, sublabel=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, w, h)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    if border:
        shape.line.color.rgb = border
        shape.line.width = Pt(1.5)
    else:
        _set_no_line(shape)

    _set_anchor_ctr(shape)
    tf = shape.text_frame
    tf.word_wrap = True
    tf.auto_size = None

    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.color.rgb = text_color
    run.font.bold = bold
    p.alignment = PP_ALIGN.CENTER

    if sublabel:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = sublabel
        r2.font.size = Pt(max(7, font_size - 2))
        r2.font.color.rgb = text_color
        r2.font.bold = False
        p2.alignment = PP_ALIGN.CENTER

    if shadow:
        _add_shadow(shape)
    return shape


def _arrow_shape(slide, left, top, w, h, color):
    s = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, left, top, w, h)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    _set_no_line(s)
    return s


def _circle(slide, left, top, size, text, fill, text_color=WHITE, font_size=9):
    s = slide.shapes.add_shape(MSO_SHAPE.OVAL, left, top, size, size)
    s.fill.solid()
    s.fill.fore_color.rgb = fill
    _set_no_line(s)
    _set_anchor_ctr(s)
    tf = s.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.color.rgb = text_color
    run.font.bold = True
    p.alignment = PP_ALIGN.CENTER
    _add_shadow(s)
    return s


def _connector(slide, x1, y1, x2, y2, color=GRAY_LIGHT, width=2):
    c = slide.shapes.add_connector(1, x1, y1, x2, y2)
    c.line.color.rgb = color
    c.line.width = Pt(width)
    return c


def _thin_bar(slide, left, top, w, h, color):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, w, h)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    _set_no_line(s)
    return s


# ─── Diagram Renderers ───

def draw_process_flow(slide, items, y_center, x_start=None, x_end=None, pal=None):
    """Horizontal process flow with large rounded boxes and chevron arrows."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return

    x_start = x_start or Inches(0.6)
    x_end = x_end or (SLIDE_W - Inches(0.6))
    total_w = x_end - x_start

    # Size boxes to fill available width — bigger and more readable
    arrow_w = Inches(0.5)
    box_w = int((total_w - (n - 1) * arrow_w) / n)
    box_h = Inches(1.8)
    content_w = n * box_w + (n - 1) * arrow_w
    x = x_start + max(0, (total_w - content_w) // 2)
    y = y_center - box_h // 2

    colors = [pal["primary"], pal["secondary"], ACCENT_GREEN, pal["primary"], pal["secondary"]]
    for i, item in enumerate(items):
        label = item.get("label", f"Step {i+1}")
        sublabel = item.get("sublabel", "")
        color = colors[i % len(colors)]

        # Card background
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x, y, box_w, box_h
        )
        card.fill.solid()
        card.fill.fore_color.rgb = WHITE
        _set_no_line(card)
        _add_shadow(card, blur=25000, dist=12000, alpha=15000)

        # Top color accent bar
        _thin_bar(slide, x, y, box_w, Inches(0.06), color)

        # Number circle
        circle_sz = Inches(0.4)
        _circle(slide, x + box_w // 2 - circle_sz // 2, y + Inches(0.15),
                circle_sz, str(i + 1), color, font_size=14)

        # Label text
        label_box = slide.shapes.add_textbox(
            x + Inches(0.08), y + Inches(0.6),
            box_w - Inches(0.16), Inches(0.5))
        tf = label_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        run = p.add_run()
        run.text = label
        run.font.size = Pt(12)
        run.font.color.rgb = color
        run.font.bold = True
        p.alignment = PP_ALIGN.CENTER

        # Sublabel
        if sublabel:
            sub_box = slide.shapes.add_textbox(
                x + Inches(0.08), y + Inches(1.1),
                box_w - Inches(0.16), Inches(0.6))
            tf2 = sub_box.text_frame
            tf2.word_wrap = True
            p2 = tf2.paragraphs[0]
            r2 = p2.add_run()
            r2.text = sublabel
            r2.font.size = Pt(9)
            r2.font.color.rgb = DARK_TEXT
            p2.alignment = PP_ALIGN.CENTER

        x += box_w
        if i < n - 1:
            # Arrow between boxes
            ay = y + box_h // 2 - Inches(0.1)
            _arrow_shape(slide, x + Inches(0.05), ay,
                        arrow_w - Inches(0.1), Inches(0.2), pal["light"])
            x += arrow_w


def draw_cycle(slide, items, center_x, center_y, radius=None, pal=None):
    """Circular cycle diagram with connecting arrows — centered on slide."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return

    radius = radius or Inches(1.05)
    node_w = Inches(1.6)
    node_h = Inches(0.7)
    colors = [pal["primary"], pal["secondary"], ACCENT_GREEN, pal["dark"]]

    positions = []
    for i in range(n):
        angle = -math.pi / 2 + (2 * math.pi * i / n)
        x = center_x + int(radius * math.cos(angle)) - node_w // 2
        y = center_y + int(radius * math.sin(angle)) - node_h // 2
        positions.append((x, y))

    # Connecting arrows between nodes
    for i in range(n):
        j = (i + 1) % n
        x1 = positions[i][0] + node_w // 2
        y1 = positions[i][1] + node_h // 2
        x2 = positions[j][0] + node_w // 2
        y2 = positions[j][1] + node_h // 2
        dx, dy = x2 - x1, y2 - y1
        length = math.sqrt(dx * dx + dy * dy)
        if length > 0:
            shrink = min(node_w, node_h) * 0.65
            x1 += int(dx * shrink / length)
            y1 += int(dy * shrink / length)
            x2 -= int(dx * shrink / length)
            y2 -= int(dy * shrink / length)
        _connector(slide, x1, y1, x2, y2, color=pal["light"], width=2)

    # Nodes as rounded rectangles (more readable than circles)
    for i, item in enumerate(items):
        label = item.get("label", f"Node {i+1}")
        sublabel = item.get("sublabel", "")
        color = colors[i % len(colors)]
        _rounded_rect(slide, positions[i][0], positions[i][1],
                      node_w, node_h, label, color,
                      font_size=10, sublabel=sublabel)

    # Center label
    ctr_w = Inches(1.0)
    ctr_h = Inches(0.5)
    ctr = slide.shapes.add_shape(
        MSO_SHAPE.OVAL, center_x - ctr_w // 2, center_y - ctr_h // 2,
        ctr_w, ctr_h
    )
    ctr.fill.solid()
    ctr.fill.fore_color.rgb = pal["bg"]
    ctr.line.color.rgb = pal["primary"]
    ctr.line.width = Pt(2)
    _set_anchor_ctr(ctr)
    tf = ctr.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = "Iterate"
    run.font.size = Pt(9)
    run.font.color.rgb = pal["dark"]
    run.font.bold = True
    p.alignment = PP_ALIGN.CENTER


def draw_comparison(slide, items, y_start, x_start=None, pal=None):
    """Side-by-side comparison cards with thick left border accent."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return

    x_start = x_start or Inches(0.6)
    total_w = SLIDE_W - 2 * x_start
    gap = Inches(0.18)
    card_w = int((total_w - (n - 1) * gap) / n)
    card_h = Inches(2.4)
    border_w = Inches(0.06)

    for i, item in enumerate(items):
        label = item.get("label", f"Option {i+1}")
        sublabel = item.get("sublabel", "")
        tone = item.get("tone", "neutral")

        if tone == "positive":
            accent_color = pal["primary"]
        elif tone == "negative":
            accent_color = GRAY
        else:
            accent_color = pal["secondary"]

        x = x_start + i * (card_w + gap)

        # Left color border
        _thin_bar(slide, x, y_start, border_w, card_h, accent_color)

        # Card body
        card = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, x + border_w, y_start,
            card_w - border_w, card_h
        )
        card.fill.solid()
        card.fill.fore_color.rgb = GRAY_BG
        _set_no_line(card)
        _add_shadow(card, blur=25000, dist=12000, alpha=15000)

        tf = card.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.12)
        tf.margin_top = Inches(0.12)

        # Label
        p = tf.paragraphs[0]
        run = p.add_run()
        run.text = label
        run.font.size = Pt(13)
        run.font.color.rgb = accent_color
        run.font.bold = True
        p.alignment = PP_ALIGN.LEFT
        p.space_after = Pt(6)

        # Sublabel lines
        for line in sublabel.split("\n"):
            p2 = tf.add_paragraph()
            r2 = p2.add_run()
            r2.text = line.strip()
            r2.font.size = Pt(10)
            r2.font.color.rgb = DARK_TEXT
            p2.alignment = PP_ALIGN.LEFT
            p2.space_before = Pt(3)


def draw_stats(slide, items, y_start, x_start=None, pal=None):
    """Row of bold stat cards with large numbers."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return

    x_start = x_start or Inches(0.6)
    total_w = SLIDE_W - 2 * x_start
    gap = Inches(0.25)
    box_w = int((total_w - (n - 1) * gap) / n)
    box_h = Inches(2.2)

    colors = [pal["primary"], pal["secondary"], ACCENT_GREEN, pal["primary"]]
    for i, item in enumerate(items):
        label = item.get("label", "Metric")
        number = item.get("sublabel", "0")
        x = x_start + i * (box_w + gap)
        color = colors[i % len(colors)]

        # Card background
        bg = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x, y_start, box_w, box_h
        )
        bg.fill.solid()
        bg.fill.fore_color.rgb = WHITE
        _set_no_line(bg)
        _add_shadow(bg, blur=35000, dist=18000, alpha=20000)

        tf = bg.text_frame
        tf.word_wrap = True
        _set_anchor_ctr(bg)

        # Big number
        p = tf.paragraphs[0]
        run = p.add_run()
        run.text = str(number)
        run.font.size = Pt(40)
        run.font.color.rgb = color
        run.font.bold = True
        p.alignment = PP_ALIGN.CENTER
        p.space_after = Pt(4)

        # Label below number
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = label
        r2.font.size = Pt(11)
        r2.font.color.rgb = DARK_TEXT
        p2.alignment = PP_ALIGN.CENTER

        # Top accent bar
        _thin_bar(slide, x, y_start, box_w, Inches(0.05), color)


def draw_timeline(slide, items, y_center, x_start=None, x_end=None, pal=None):
    """Horizontal timeline with numbered markers and labels."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return

    x_start = x_start or Inches(1.0)
    x_end = x_end or (SLIDE_W - Inches(1.0))
    total_w = x_end - x_start

    # Draw horizontal line
    line_y = y_center
    _thin_bar(slide, x_start, line_y - Pt(2), total_w, Pt(4), pal["light"])

    step = total_w // (n - 1) if n > 1 else 0
    marker_size = Inches(0.35)
    label_w = Inches(1.6)

    for i, item in enumerate(items):
        label = item.get("label", f"Step {i+1}")
        sublabel = item.get("sublabel", "")
        x = x_start + i * step if n > 1 else x_start + total_w // 2

        # Marker circle
        _circle(slide, x - marker_size // 2, line_y - marker_size // 2,
                marker_size, str(i + 1), pal["primary"], font_size=9)

        # Label below
        lbl = _rounded_rect(
            slide, x - label_w // 2, line_y + Inches(0.3),
            label_w, Inches(0.5), label, pal["bg"],
            text_color=pal["dark"], font_size=9, bold=True,
            border=pal["light"], shadow=False, sublabel=sublabel
        )


def draw_hierarchy(slide, items, y_start, x_center=None, pal=None):
    """Top-down tree: root -> children."""
    pal = pal or next_palette()
    if not items:
        return

    x_center = x_center or (SLIDE_W // 2)
    root = items[0]
    children = root.get("children", [item.get("label", "") for item in items[1:]])
    if not children and len(items) > 1:
        children = [item.get("label", "") for item in items[1:]]

    root_w = Inches(2.2)
    root_h = Inches(0.55)
    root_x = x_center - root_w // 2

    # Root node
    _rounded_rect(slide, root_x, y_start, root_w, root_h,
                  root.get("label", "Root"), pal["primary"],
                  font_size=11, sublabel=root.get("sublabel", ""))

    # Children
    n = len(children)
    if n == 0:
        return

    child_w = Inches(1.7)
    child_h = Inches(0.45)
    total_children_w = n * child_w + (n - 1) * Inches(0.15)
    child_x_start = x_center - total_children_w // 2
    child_y = y_start + root_h + Inches(0.5)

    colors = [pal["secondary"], pal["primary"], pal["secondary"], pal["primary"]]
    for i, child_label in enumerate(children):
        cx = child_x_start + i * (child_w + Inches(0.15))
        color = colors[i % len(colors)]

        # Connector line
        _connector(slide,
                   x_center, y_start + root_h,
                   cx + child_w // 2, child_y,
                   color=pal["light"], width=2)

        _rounded_rect(slide, cx, child_y, child_w, child_h,
                      child_label if isinstance(child_label, str) else str(child_label),
                      color, font_size=9, bold=True)


def draw_quote_callout(slide, text, y_start, pal=None):
    """Large quote box with accent bar."""
    pal = pal or next_palette()
    x_start = Inches(1.5)
    w = SLIDE_W - 2 * x_start
    h = Inches(1.0)

    # Accent bar
    _thin_bar(slide, x_start - Inches(0.08), y_start, Inches(0.06), h, pal["primary"])

    # Quote box
    box = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, x_start, y_start, w, h
    )
    box.fill.solid()
    box.fill.fore_color.rgb = pal["bg"]
    box.line.color.rgb = pal["light"]
    box.line.width = Pt(1)
    _set_anchor_ctr(box)

    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    run.font.size = Pt(13)
    run.font.color.rgb = pal["dark"]
    run.font.italic = True
    p.alignment = PP_ALIGN.LEFT


def draw_accent_sidebar(slide, pal=None):
    """Thin vertical accent bar on left side."""
    pal = pal or next_palette()
    _thin_bar(slide, Inches(0.08), Inches(0.9), Inches(0.06), Inches(5.0), pal["primary"])


def draw_icon_grid(slide, items, y_start, x_start=None, pal=None):
    """Grid of labeled boxes with icons/numbers."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return

    x_start = x_start or Inches(0.8)
    total_w = SLIDE_W - 2 * x_start
    cols = min(n, 4)
    rows = math.ceil(n / cols)
    gap = Inches(0.12)
    box_w = int((total_w - (cols - 1) * gap) / cols)
    box_h = Inches(0.7)

    colors = [pal["primary"], pal["secondary"], ACCENT_GREEN, pal["primary"]]
    for i, item in enumerate(items):
        row = i // cols
        col = i % cols
        x = x_start + col * (box_w + gap)
        y = y_start + row * (box_h + gap)
        label = item.get("label", "")
        sublabel = item.get("sublabel", "")
        color = colors[i % len(colors)]

        # Icon circle
        icon_size = Inches(0.3)
        _circle(slide, x + Inches(0.08), y + (box_h - icon_size) // 2,
                icon_size, str(i + 1), color, font_size=8)

        # Label box
        lbl_x = x + Inches(0.45)
        lbl_w = box_w - Inches(0.55)
        lbl = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, lbl_x, y, lbl_w, box_h
        )
        lbl.fill.solid()
        lbl.fill.fore_color.rgb = pal["bg"]
        lbl.line.color.rgb = pal["light"]
        lbl.line.width = Pt(1)
        _set_anchor_ctr(lbl)

        tf = lbl.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        run = p.add_run()
        run.text = label
        run.font.size = Pt(9)
        run.font.color.rgb = pal["dark"]
        run.font.bold = True
        p.alignment = PP_ALIGN.LEFT

        if sublabel:
            p2 = tf.add_paragraph()
            r2 = p2.add_run()
            r2.text = sublabel
            r2.font.size = Pt(7)
            r2.font.color.rgb = GRAY
            p2.alignment = PP_ALIGN.LEFT


# ─── Additional Layout Renderers ───

def draw_radial(slide, items, center_x, center_y, pal=None):
    """Central node with satellite nodes around it."""
    pal = pal or next_palette()
    n = len(items)
    if n < 2:
        return

    center_item = items[0]
    satellites = items[1:]
    n_sat = len(satellites)

    # Center node (larger)
    center_size = Inches(1.1)
    _rounded_rect(slide, center_x - center_size // 2, center_y - center_size // 2,
                  center_size, center_size, center_item.get("label", "Center"),
                  pal["primary"], font_size=10,
                  sublabel=center_item.get("sublabel", ""))

    # Satellite nodes
    radius = Inches(1.5)
    sat_size = Inches(0.85)
    for i, item in enumerate(satellites):
        angle = -math.pi / 2 + (2 * math.pi * i / n_sat)
        sx = center_x + int(radius * math.cos(angle)) - sat_size // 2
        sy = center_y + int(radius * math.sin(angle)) - sat_size // 2

        # Connector
        _connector(slide, center_x, center_y,
                   sx + sat_size // 2, sy + sat_size // 2,
                   color=pal["light"], width=1)

        color = [pal["secondary"], ACCENT_GREEN, pal["primary"], pal["secondary"]]
        _rounded_rect(slide, sx, sy, sat_size, sat_size,
                      item.get("label", ""), color[i % len(color)],
                      font_size=8, sublabel=item.get("sublabel", ""))


def draw_matrix(slide, items, y_start, x_start=None, pal=None):
    """Grid layout of labeled cells."""
    pal = pal or next_palette()
    n = len(items)
    cols = 2 if n <= 4 else 3
    rows = math.ceil(n / cols)

    x_start = x_start or Inches(0.8)
    total_w = SLIDE_W - 2 * x_start
    gap = Inches(0.12)
    cell_w = int((total_w - (cols - 1) * gap) / cols)
    cell_h = Inches(0.55)

    colors = [pal["primary"], pal["secondary"], ACCENT_GREEN, pal["primary"]]
    for i, item in enumerate(items):
        r = i // cols
        c = i % cols
        x = x_start + c * (cell_w + gap)
        y = y_start + r * (cell_h + gap)
        color = colors[i % len(colors)]

        _rounded_rect(slide, x, y, cell_w, cell_h,
                      item.get("label", ""), color,
                      font_size=9, sublabel=item.get("sublabel", ""))


def draw_stacked_list(slide, items, y_start, x_start=None, pal=None):
    """Numbered feature rows with label and description."""
    pal = pal or next_palette()
    n = len(items)
    x_start = x_start or Inches(0.6)
    total_w = SLIDE_W - 2 * x_start
    row_h = Inches(0.6)
    gap = Inches(0.1)
    num_size = Inches(0.42)

    for i, item in enumerate(items):
        y = y_start + i * (row_h + gap)
        color = [pal["primary"], pal["secondary"]][i % 2]

        # Number circle
        _circle(slide, x_start, y + (row_h - num_size) // 2,
                num_size, str(i + 1), color, font_size=11)

        # Row card
        bar_x = x_start + num_size + Inches(0.15)
        bar_w = total_w - num_size - Inches(0.15)
        bar = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, bar_x, y, bar_w, row_h
        )
        bar.fill.solid()
        bar.fill.fore_color.rgb = WHITE
        bar.line.color.rgb = pal["light"]
        bar.line.width = Pt(1)
        _set_anchor_ctr(bar)

        tf = bar.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.15)

        # Label (bold) + sublabel
        p = tf.paragraphs[0]
        run_label = p.add_run()
        run_label.text = item.get("label", "")
        run_label.font.size = Pt(12)
        run_label.font.color.rgb = color
        run_label.font.bold = True

        sublabel = item.get("sublabel", "")
        if sublabel:
            run_sep = p.add_run()
            run_sep.text = "  —  "
            run_sep.font.size = Pt(11)
            run_sep.font.color.rgb = GRAY

            run_sub = p.add_run()
            run_sub.text = sublabel
            run_sub.font.size = Pt(11)
            run_sub.font.color.rgb = DARK_TEXT

        p.alignment = PP_ALIGN.LEFT


def draw_funnel(slide, items, y_start, x_center=None, pal=None):
    """Narrowing funnel stages."""
    pal = pal or next_palette()
    n = len(items)
    x_center = x_center or (SLIDE_W // 2)
    max_w = Inches(8.0)
    min_w = Inches(3.0)
    row_h = Inches(0.45)
    gap = Inches(0.06)

    colors = [pal["secondary"], pal["primary"], pal["primary"], pal["dark"]]
    for i, item in enumerate(items):
        w_frac = 1.0 - (i / max(n - 1, 1)) * 0.6
        w = int(max_w * w_frac)
        y = y_start + i * (row_h + gap)
        x = x_center - w // 2
        color = colors[i % len(colors)]

        _rounded_rect(slide, x, y, w, row_h,
                      item.get("label", ""), color,
                      font_size=9, sublabel=item.get("sublabel", ""))


def draw_split_panel(slide, items, y_start, pal=None):
    """Two side-by-side panels with colored backgrounds and bullet content."""
    pal = pal or next_palette()
    if len(items) < 2:
        return

    x_start = Inches(0.6)
    total_w = SLIDE_W - 2 * x_start
    gap = Inches(0.25)
    panel_w = int((total_w - gap) / 2)
    panel_h = Inches(2.4)

    for idx, item in enumerate(items[:2]):
        x = x_start + idx * (panel_w + gap)
        color = pal["primary"] if idx == 0 else pal["secondary"]

        # Full panel background
        panel = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x, y_start, panel_w, panel_h
        )
        panel.fill.solid()
        panel.fill.fore_color.rgb = color
        _set_no_line(panel)
        _add_shadow(panel, blur=30000, dist=15000, alpha=18000)

        tf = panel.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.2)
        tf.margin_top = Inches(0.15)
        tf.margin_right = Inches(0.15)

        # Title
        p = tf.paragraphs[0]
        run = p.add_run()
        run.text = item.get("label", "")
        run.font.size = Pt(14)
        run.font.color.rgb = WHITE
        run.font.bold = True
        p.alignment = PP_ALIGN.LEFT
        p.space_after = Pt(8)

        # Sublabel lines
        for line in item.get("sublabel", "").split("\n"):
            if not line.strip():
                continue
            p2 = tf.add_paragraph()
            r2 = p2.add_run()
            r2.text = line.strip()
            r2.font.size = Pt(11)
            r2.font.color.rgb = RGBColor(0xE8, 0xEE, 0xF8)
            p2.alignment = PP_ALIGN.LEFT
            p2.space_before = Pt(4)


def draw_banner_quote(slide, items, y_start, pal=None):
    """Full-width banner with large quote text and bold accent styling."""
    pal = pal or next_palette()
    if not items:
        return
    label = items[0].get("label", "")
    sublabel = items[0].get("sublabel", "")

    x_start = Inches(0.6)
    w = SLIDE_W - 2 * x_start
    h = Inches(2.0)

    # Full background banner
    banner = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, x_start, y_start, w, h
    )
    banner.fill.solid()
    banner.fill.fore_color.rgb = pal["primary"]
    _set_no_line(banner)
    _add_shadow(banner, blur=40000, dist=20000, alpha=20000)
    _set_anchor_ctr(banner)

    tf = banner.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0.5)
    tf.margin_right = Inches(0.5)

    # Label line (bold, white, large)
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = label
    run.font.size = Pt(18)
    run.font.color.rgb = WHITE
    run.font.bold = True
    p.alignment = PP_ALIGN.CENTER
    p.space_after = Pt(8)

    # Sublabel (lighter, slightly smaller)
    if sublabel:
        p2 = tf.add_paragraph()
        r2 = p2.add_run()
        r2.text = sublabel
        r2.font.size = Pt(13)
        r2.font.color.rgb = pal["light"]
        r2.font.italic = True
        p2.alignment = PP_ALIGN.CENTER

    # Decorative left accent bar
    _thin_bar(slide, x_start, y_start, Inches(0.07), h, pal["secondary"])


def draw_callout_cards(slide, items, y_start, x_start=None, pal=None):
    """Large callout cards with icon-style number, bold title, and description."""
    pal = pal or next_palette()
    n = len(items)
    if n == 0:
        return
    cols = min(n, 3)

    x_start = x_start or Inches(0.6)
    total_w = SLIDE_W - 2 * x_start
    gap = Inches(0.2)
    card_w = int((total_w - (cols - 1) * gap) / cols)
    card_h = Inches(2.2)

    colors = [pal["primary"], pal["secondary"], ACCENT_GREEN, pal["primary"]]
    for i, item in enumerate(items):
        c = i % cols
        x = x_start + c * (card_w + gap)
        color = colors[i % len(colors)]

        # Card background
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, x, y_start,
            card_w, card_h)
        card.fill.solid()
        card.fill.fore_color.rgb = WHITE
        _set_no_line(card)
        _add_shadow(card, blur=30000, dist=15000, alpha=18000)

        # Top accent bar
        _thin_bar(slide, x, y_start, card_w, Inches(0.05), color)

        # Number circle
        circle_sz = Inches(0.45)
        circle = _circle(slide, x + Inches(0.15), y_start + Inches(0.15),
                        circle_sz, str(i + 1), color, font_size=14)

        # Label text
        label_box = slide.shapes.add_textbox(
            x + Inches(0.12), y_start + Inches(0.7),
            card_w - Inches(0.24), Inches(0.5))
        tf = label_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        run = p.add_run()
        run.text = item.get("label", "")
        run.font.size = Pt(13)
        run.font.color.rgb = color
        run.font.bold = True
        p.alignment = PP_ALIGN.LEFT

        # Sublabel text
        if item.get("sublabel"):
            sub_box = slide.shapes.add_textbox(
                x + Inches(0.12), y_start + Inches(1.2),
                card_w - Inches(0.24), Inches(0.9))
            tf2 = sub_box.text_frame
            tf2.word_wrap = True
            p2 = tf2.paragraphs[0]
            r2 = p2.add_run()
            r2.text = item.get("sublabel", "")
            r2.font.size = Pt(10)
            r2.font.color.rgb = DARK_TEXT
            p2.alignment = PP_ALIGN.LEFT


# Layout type to renderer mapping
LAYOUT_RENDERERS = {
    "process_flow": lambda slide, items, y, pal: draw_process_flow(slide, items, y + Inches(0.8), pal=pal),
    "timeline": lambda slide, items, y, pal: draw_timeline(slide, items, y + Inches(0.8), pal=pal),
    "cycle": lambda slide, items, y, pal: draw_cycle(slide, items, SLIDE_W // 2, y + Inches(1.3), pal=pal),
    "comparison": lambda slide, items, y, pal: draw_comparison(slide, items, y, pal=pal),
    "stats_callout": lambda slide, items, y, pal: draw_stats(slide, items, y, pal=pal),
    "hierarchy": lambda slide, items, y, pal: draw_hierarchy(slide, items, y, pal=pal),
    "icon_grid": lambda slide, items, y, pal: draw_icon_grid(slide, items, y, pal=pal),
    "icon_row": lambda slide, items, y, pal: draw_icon_grid(slide, items, y, pal=pal),
    "radial": lambda slide, items, y, pal: draw_radial(slide, items, SLIDE_W // 2, y + Inches(1.3), pal=pal),
    "matrix": lambda slide, items, y, pal: draw_matrix(slide, items, y, pal=pal),
    "stacked_list": lambda slide, items, y, pal: draw_stacked_list(slide, items, y, pal=pal),
    "funnel": lambda slide, items, y, pal: draw_funnel(slide, items, y, pal=pal),
    "split_panel": lambda slide, items, y, pal: draw_split_panel(slide, items, y, pal=pal),
    "before_after": lambda slide, items, y, pal: draw_split_panel(slide, items, y, pal=pal),
    "banner_quote": lambda slide, items, y, pal: draw_banner_quote(slide, items, y, pal=pal),
    "equation_highlight": lambda slide, items, y, pal: draw_banner_quote(slide, items, y, pal=pal),
    "callout_cards": lambda slide, items, y, pal: draw_callout_cards(slide, items, y, pal=pal),
    "quote_callout": lambda slide, items, y, pal: draw_banner_quote(slide, items, y, pal=pal),
}


# ─── Content-Aware Visual Element Mapping ───
# Fallback mapping when slide_plan_refined.json doesn't have visual_element
VISUAL_PLAN = [
    {
        "match": "Three Core Mechanisms",
        "type": "process_flow",
        "position": "bottom",
        "items": [
            {"label": "Discourse\nParser", "sublabel": "RST trees"},
            {"label": "Commitment\nBuilder", "sublabel": "Global contract"},
            {"label": "Narrative\nRefinement", "sublabel": "Critique loop"},
        ],
    },
    {
        "match": "Contributions",
        "type": "callout_cards",
        "position": "bottom",
        "items": [
            {"label": "ArcDeck Framework", "sublabel": "First discourse-driven slide generation"},
            {"label": "Global Commitments", "sublabel": "Closed-loop narrative refinement"},
            {"label": "ArcBench Dataset", "sublabel": "100 curated paper-slide pairs"},
        ],
    },
    {
        "match": "Related Work",
        "type": "comparison",
        "position": "bottom",
        "items": [
            {"label": "Prior Methods", "sublabel": "Raw-text summarization\nSection-level isolation\nNo discourse guidance", "tone": "negative"},
            {"label": "Multi-Agent", "sublabel": "Iterative refinement\nTemplate/code synthesis\nNo global contract", "tone": "neutral"},
            {"label": "ArcDeck", "sublabel": "RST discourse trees\nGlobal commitments\nNarrative refinement", "tone": "positive"},
        ],
    },
    {
        "match": "Refinement Loop",
        "type": "cycle",
        "position": "right",
        "items": [
            {"label": "Slide\nPlanner"},
            {"label": "Narrative\nCritic"},
            {"label": "Narrative\nJudge"},
            {"label": "Slide\nReviser"},
        ],
    },
    {
        "match": "Slide Generation Stage",
        "type": "timeline",
        "position": "bottom",
        "items": [
            {"label": "Final Outline", "sublabel": "From refinement"},
            {"label": "Visual Matching", "sublabel": "Figures + tables"},
            {"label": "Deck Constructor", "sublabel": "Layout + content"},
            {"label": "Aesthetics Refiner", "sublabel": "Polish + format"},
            {"label": "PPTX Render", "sublabel": "Final output"},
        ],
    },
    {
        "match": "ArcBench Dataset",
        "type": "stats_callout",
        "position": "bottom",
        "items": [
            {"label": "Candidate\nPairs", "sublabel": "994"},
            {"label": "Curated\nTest Set", "sublabel": "100"},
            {"label": "Top-Tier\nVenues", "sublabel": "6"},
            {"label": "Min Figures\nper Paper", "sublabel": "3+"},
        ],
    },
    {
        "match": "Conclusion",
        "type": "radial",
        "position": "bottom",
        "items": [
            {"label": "ArcDeck", "sublabel": "Narrative-driven"},
            {"label": "RST\nDiscourse", "sublabel": "Trees"},
            {"label": "Global\nCommitments", "sublabel": "Contract"},
            {"label": "Multi-Agent\nRefinement", "sublabel": "Loop"},
            {"label": "ArcBench", "sublabel": "Benchmark"},
        ],
    },
]


# ─── Slide Analysis ───

def get_slide_text(slide):
    texts = []
    for shape in slide.shapes:
        if shape.has_text_frame:
            texts.append(shape.text_frame.text)
    return " ".join(texts)


def get_slide_title(slide):
    for shape in slide.shapes:
        if shape.has_text_frame:
            t = shape.text_frame.text.strip()
            if t and len(t) < 60 and not t.isdigit():
                return t
    return ""


def has_images(slide):
    for shape in slide.shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            return True
        if hasattr(shape, "image"):
            try:
                _ = shape.image
                return True
            except Exception:
                pass
    return False


def find_visual_plan(slide_title, slide_text):
    """Find the matching visual plan for this slide."""
    for plan in VISUAL_PLAN:
        match = plan["match"].lower()
        if match in slide_title.lower() or match in slide_text.lower()[:200]:
            return plan
    return None


# ─── Position Helpers ───

def _y_for_position(position):
    """Return Y coordinate based on visual position setting."""
    positions = {
        "bottom": Inches(4.5),
        "center": Inches(3.2),
        "right": Inches(3.5),
        "full": Inches(2.5),
    }
    return positions.get(position, Inches(4.5))


# ─── Main Enhancer ───

def load_slide_plan_visuals(workspace):
    """Load visual_element specs from slide_plan_refined.json.

    Returns both the list of slides and a title-keyed lookup dict for
    matching PPTX slides (whose indices differ due to title/TOC/divider slides).
    """
    plan_path = os.path.join(workspace, "slide_plan_refined.json")
    if not os.path.exists(plan_path):
        return [], {}
    try:
        with open(plan_path) as f:
            plan = json.load(f)
        slides = plan.get("slides", [])
        # Build title-based lookup: normalize subsection titles for fuzzy matching
        title_map = {}
        for s in slides:
            ve = s.get("visual_element")
            if ve and ve.get("layout") and ve.get("items"):
                subsec = (s.get("subsection") or "").strip().lower()
                if subsec:
                    title_map[subsec] = ve
        return slides, title_map
    except Exception:
        return [], {}


def _find_visual_by_title(title, text, title_map):
    """Find a visual_element from the plan by matching slide title/text to subsection."""
    if not title_map:
        return None
    title_lower = title.strip().lower()
    text_lower = (text or "").strip().lower()[:500]  # Search full slide text too

    # Exact match on title
    if title_lower in title_map:
        return title_map[title_lower]

    for subsec, ve in title_map.items():
        # Substring match: title or full text contains subsection name
        if subsec in title_lower or title_lower in subsec:
            return ve
        if subsec in text_lower:
            return ve
        # Word overlap match: at least 2 significant words in common
        title_words = set(w for w in title_lower.split() if len(w) > 3)
        subsec_words = set(w for w in subsec.split() if len(w) > 3)
        overlap = title_words & subsec_words
        if len(overlap) >= 2:
            return ve
    return None


def enhance_slide(slide, slide_idx, layout_name, prs, plan_slides=None, title_map=None):
    """Add visual enhancement to a single slide based on content.

    Priority:
    1. visual_element from slide_plan_refined.json matched by title (LLM-designed)
    2. Fallback VISUAL_PLAN matching (hardcoded content matching)
    3. Accent sidebar for unmatched text-only slides
    """
    if layout_name not in ("T1_TextOnly", "T14_2Text"):
        return None

    if has_images(slide):
        return None

    title = get_slide_title(slide)
    text = get_slide_text(slide)
    pal = next_palette()

    # Priority 1: Check slide_plan_refined.json by title matching
    ve = _find_visual_by_title(title, text, title_map)
    if ve and ve.get("layout") and ve.get("items"):
        layout = ve["layout"]
        items = ve["items"]
        position = ve.get("position", "bottom")
        y = _y_for_position(position)

        renderer = LAYOUT_RENDERERS.get(layout)
        if renderer:
            try:
                renderer(slide, items, y, pal)
                return f"{layout} ({len(items)} items) [planned]"
            except Exception as e:
                print(f"    Warning: renderer '{layout}' failed: {e}")

    # Priority 2: Fallback VISUAL_PLAN matching
    plan = find_visual_plan(title, text)
    if plan:
        items = plan["items"]
        position = plan.get("position", "bottom")
        layout = plan["type"]
        y = _y_for_position(position)

        renderer = LAYOUT_RENDERERS.get(layout)
        if renderer:
            try:
                renderer(slide, items, y, pal)
                return f"{layout} ({len(items)} items) [fallback]"
            except Exception as e:
                print(f"    Warning: renderer '{layout}' failed: {e}")

    # Priority 3: Default accent sidebar
    draw_accent_sidebar(slide, pal)
    return "accent sidebar"


def main():
    global _palette_idx
    _palette_idx = 0

    pptx_path = os.path.join(WORKSPACE, "output.pptx")
    print(f"[enhance v3] Loading: {pptx_path}")
    prs = Presentation(pptx_path)

    # Load visual elements from slide plan
    plan_slides, title_map = load_slide_plan_visuals(WORKSPACE)
    if plan_slides:
        print(f"[enhance v3] Loaded {len(plan_slides)} slide plans, {len(title_map)} with visual elements")
    else:
        print("[enhance v3] No slide plan found, using fallback matching")

    enhancements = []
    for i, slide in enumerate(prs.slides):
        layout_name = slide.slide_layout.name
        result = enhance_slide(slide, i, layout_name, prs, plan_slides, title_map)
        if result:
            enhancements.append((i + 1, layout_name, result))
            print(f"  Slide {i+1:2d} [{layout_name:15s}]: + {result}")

    prs.save(pptx_path)
    sz = os.path.getsize(pptx_path)
    print(f"\n[enhance v3] Saved: {pptx_path} ({sz // 1024}K)")
    print(f"[enhance v3] Enhanced {len(enhancements)} / {len(prs.slides)} slides")
    for s, l, r in enhancements:
        print(f"  [{s:2d}] {r}")


if __name__ == "__main__":
    main()
