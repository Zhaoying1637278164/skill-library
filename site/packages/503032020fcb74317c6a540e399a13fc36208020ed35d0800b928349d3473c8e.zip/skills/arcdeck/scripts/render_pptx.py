#!/usr/bin/env python3
"""ArcDeck PPTX Renderer v4 — Template-free, programmatic rendering.

Creates modern academic presentations from slide_plan_refined.json
without requiring an external PPTX template file. All slides are built
entirely from shapes, text boxes, and images using python-pptx.

Design: "Clean Academic" — white backgrounds, dark navy accents,
blue highlights, minimal professional typography.
"""

import json
import os
import re
import shutil
from pathlib import Path
from typing import List, Tuple, Optional
from zipfile import ZipFile

from lxml import etree
from PIL import Image
from pptx import Presentation
from pptx.util import Pt, Inches, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_SHAPE_TYPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn


# ─── Configuration ───

WORKSPACE = os.environ.get("ARCDECK_WORKSPACE", os.path.dirname(os.path.abspath(__file__)))
FIGURES_DIR = os.path.join(WORKSPACE, "figures")


# ─── Design Constants ───

SLIDE_W = Emu(12192000)   # 13.333" (16:9)
SLIDE_H = Emu(6858000)    # 7.5"
MARGIN_L = Inches(0.6)
MARGIN_R = Inches(0.6)
CONTENT_W = Inches(12.133)  # 13.333 - 0.6 - 0.6

# Colors — "Clean Academic" palette
CLR_PRIMARY   = RGBColor(0x1B, 0x2A, 0x4A)  # Deep navy
CLR_ACCENT    = RGBColor(0x25, 0x63, 0xEB)  # Vivid blue
CLR_ACCENT_LT = RGBColor(0x93, 0xBB, 0xFD)  # Light blue
CLR_TEXT      = RGBColor(0x1E, 0x29, 0x3B)  # Near-black
CLR_TEXT_MID  = RGBColor(0x64, 0x74, 0x8B)  # Medium gray
CLR_TEXT_LT   = RGBColor(0x94, 0xA3, 0xB8)  # Light gray
CLR_WHITE     = RGBColor(0xFF, 0xFF, 0xFF)  # White
CLR_BG_LIGHT  = RGBColor(0xF8, 0xFA, 0xFC)  # Near-white
CLR_DIVIDER   = RGBColor(0xE2, 0xE8, 0xF0)  # Divider gray

# Typography
FONT_NAME      = "Calibri"
TITLE_SIZE     = 24
BODY_SIZE      = 16
SUB_SIZE       = 13
REF_SIZE       = 9
PART_NUM_SIZE  = 10

# Layout positions
ACCENT_BAR_W = Inches(0.05)
TITLE_Y      = Inches(0.25)
TITLE_H      = Inches(0.65)
UNDERLINE_Y  = Inches(0.95)
UNDERLINE_W  = Inches(2.0)
UNDERLINE_H  = Inches(0.025)
BODY_TOP     = Inches(1.2)
BODY_H       = Inches(3.0)    # Shorter to leave room for visual diagrams
REF_Y        = Inches(7.0)


# ─── LaTeX Parsing ───

LATEX_COLOR_MAP = {
    "red": (255, 0, 0), "blue": (0, 0, 255), "green": (0, 128, 0),
    "black": (0, 0, 0), "white": (255, 255, 255), "orange": (255, 165, 0),
    "yellow": (255, 255, 0), "purple": (128, 0, 128), "gray": (128, 128, 128),
    "grey": (128, 128, 128), "brown": (165, 42, 42),
}


def _find_matching_brace(s, start):
    depth = 1
    i = start + 1
    while i < len(s) and depth > 0:
        if s[i] == "{": depth += 1
        elif s[i] == "}": depth -= 1
        i += 1
    return i - 1 if depth == 0 else -1


def _parse_latex(s):
    """Parse \\textbf{} and \\textcolor{}{} → [(text, bold, color_or_none)]."""
    if not s:
        return []
    PATS_BF = ("\\textbf{", "textbf{", "extbf{")
    PATS_TC = ("\\textcolor{", "textcolor{", "extcolor{")
    out = []
    i = 0
    while i < len(s):
        idx_bf, len_bf = len(s), 0
        for pat in PATS_BF:
            pos = s.find(pat, i)
            if pos != -1 and pos < idx_bf:
                idx_bf, len_bf = pos, len(pat)
        idx_tc, len_tc = len(s), 0
        for pat in PATS_TC:
            pos = s.find(pat, i)
            if pos != -1 and pos < idx_tc:
                idx_tc, len_tc = pos, len(pat)
        nxt = min(idx_bf, idx_tc)
        if nxt > i:
            plain = s[i:nxt].rstrip("\t")
            if plain.strip():
                out.append((plain, False, None))
            i = nxt
            continue
        if nxt == len(s):
            break
        if idx_bf <= idx_tc:
            ob = nxt + len_bf - 1
            cb = _find_matching_brace(s, ob)
            if cb == -1:
                i = nxt + 1; continue
            for txt, bold, color in _parse_latex(s[ob+1:cb]):
                out.append((txt, True, color))
            i = cb + 1
        else:
            ob = nxt + len_tc - 1
            cb = _find_matching_brace(s, ob)
            if cb == -1:
                i = nxt + 1; continue
            color_name = s[ob+1:cb].strip().lower()
            no = cb + 1
            if no < len(s) and s[no] == "{":
                cc = _find_matching_brace(s, no)
                if cc != -1:
                    rgb = LATEX_COLOR_MAP.get(color_name)
                    use_color = RGBColor(*rgb) if rgb else None
                    for txt, bold, color in _parse_latex(s[no+1:cc]):
                        out.append((txt, bold, use_color or color))
                    i = cc + 1
                else:
                    i = no + 1
            else:
                i = cb + 1
    if i < len(s):
        remaining = s[i:]
        if remaining.strip():
            out.append((remaining, False, None))
    return out


def _set_run_style(run, font_size, bold=False, color=None, font_name=FONT_NAME):
    """Apply full styling to a text run."""
    run.font.size = Pt(font_size)
    run.font.name = font_name
    run.font.bold = bold
    if color:
        try:
            run.font.color.rgb = color
        except (AttributeError, TypeError):
            _set_run_color_xml(run, color)


def _set_run_color_xml(run, color):
    """Set run color via XML fallback."""
    try:
        rPr = run.font._element
        for child in list(rPr.iterchildren()):
            if child.tag == qn("a:solidFill"):
                rPr.remove(child)
        sf = OxmlElement("a:solidFill")
        srgb = OxmlElement("a:srgbClr")
        if isinstance(color, RGBColor):
            r = (color._color >> 16) & 0xFF
            g = (color._color >> 8) & 0xFF
            b = color._color & 0xFF
        elif isinstance(color, (list, tuple)):
            r, g, b = color[0], color[1], color[2]
        else:
            return
        srgb.set("val", f"{r:02X}{g:02X}{b:02X}")
        sf.append(srgb)
        rPr.append(sf)
    except Exception:
        pass


# ─── Text Frame Helpers ───

def _clear_text_frame(tf):
    """Remove all content from a text frame."""
    if tf.paragraphs:
        tf.paragraphs[0].text = ""
        while len(tf.paragraphs) > 1:
            p = tf._element.p_lst[-1]
            p.getparent().remove(p)
    else:
        tf.clear()


def _set_bullet_format(para, level):
    """Set bullet character and indentation for a paragraph."""
    p_el = para._p
    pPr = p_el.find(qn("a:pPr"))
    if pPr is None:
        pPr = OxmlElement("a:pPr")
        p_el.insert(0, pPr)

    pPr.set("lvl", str(level))

    if level == 0:
        pPr.set("marL", "457200")     # 0.5"
        pPr.set("indent", "-228600")  # -0.25" hanging
        char = "\u2022"  # •
    else:
        pPr.set("marL", "914400")     # 1.0"
        pPr.set("indent", "-228600")  # -0.25" hanging
        char = "\u2013"  # –

    # Remove existing bullet elements
    for tag in ("a:buChar", "a:buAutoNum", "a:buBlip", "a:buNone"):
        existing = pPr.find(qn(tag))
        if existing is not None:
            pPr.remove(existing)

    buChar = OxmlElement("a:buChar")
    buChar.set("char", char)
    pPr.append(buChar)

    buFont = OxmlElement("a:buFont")
    buFont.set("typeface", "Arial")
    pPr.append(buFont)


def _set_no_bullet(para):
    """Remove bullet from paragraph."""
    p_el = para._p
    pPr = p_el.find(qn("a:pPr"))
    if pPr is None:
        pPr = OxmlElement("a:pPr")
        p_el.insert(0, pPr)
    for tag in ("a:buChar", "a:buBlip", "a:buAutoNum", "a:buFont", "a:buSzPct"):
        existing = pPr.find(qn(tag))
        if existing is not None:
            pPr.remove(existing)
    pPr.insert(0, OxmlElement("a:buNone"))
    pPr.set("marL", "0")
    pPr.set("indent", "0")


def _write_formatted_para(para, segments, font_size, default_color=CLR_TEXT):
    """Write [(text, bold, color)] segments into a paragraph."""
    segments = [(t, b, c) for t, b, c in segments if t]
    if not segments:
        return
    for run in list(para.runs):
        run._element.getparent().remove(run._element)
    for text, bold, color in segments:
        run = para.add_run()
        run.text = text
        _set_run_style(run, font_size, bold=bold,
                       color=color if color else default_color)


def _set_text_frame_columns(tf, num_cols):
    """Set text frame to multi-column layout."""
    for c in tf._element.getchildren():
        if c.tag.split("}")[-1] == "bodyPr":
            c.set("numCol", str(num_cols))
            return


def _fill_bullets(tf, bullets, font_size=BODY_SIZE, sub_size=SUB_SIZE):
    """Fill text frame with bullet items (level 0 + level 1 sub-bullets)."""
    _clear_text_frame(tf)
    first = True
    for b in (bullets or []):
        if first:
            p = tf.paragraphs[0]
            first = False
        else:
            p = tf.add_paragraph()
        p.level = 0
        _set_bullet_format(p, 0)

        raw = (b.get("text") or "").strip()
        segs = _parse_latex(raw)
        if segs:
            _write_formatted_para(p, segs, font_size)
        else:
            run = p.add_run()
            run.text = raw
            _set_run_style(run, font_size, color=CLR_TEXT)

        for sub in (b.get("sub") or []):
            sp = tf.add_paragraph()
            sp.level = 1
            _set_bullet_format(sp, 1)
            raw_sub = str(sub).strip()
            segs_sub = _parse_latex(raw_sub)
            if segs_sub:
                _write_formatted_para(sp, segs_sub, sub_size, default_color=CLR_TEXT_MID)
            else:
                run = sp.add_run()
                run.text = raw_sub
                _set_run_style(run, sub_size, color=CLR_TEXT_MID)


def _fill_body(tf, slide_info, template_id):
    """Fill body text frame with bullets or paragraph text."""
    bullets = slide_info.get("bullets") or []
    paragraph_text = (slide_info.get("paragraph") or "").strip()

    if paragraph_text and not bullets:
        _clear_text_frame(tf)
        p = tf.paragraphs[0] if tf.paragraphs else tf.add_paragraph()
        _set_no_bullet(p)
        segs = _parse_latex(paragraph_text)
        if segs:
            _write_formatted_para(p, segs, BODY_SIZE)
        else:
            run = p.add_run()
            run.text = paragraph_text
            _set_run_style(run, BODY_SIZE, color=CLR_TEXT)
    else:
        word_count = sum(len((b.get("text") or "").split()) for b in bullets)
        line_count = sum(1 + len(b.get("sub", [])) for b in bullets)
        if template_id == "T4_ImageTop" and (word_count > 60 or line_count > 4):
            _set_text_frame_columns(tf, 2)
        _fill_bullets(tf, bullets)


# ─── Template-Free Presentation Setup ───

def _create_presentation():
    """Create a clean PPTX with properly named blank slide layouts.

    Renames the 9 default layouts to match ArcDeck template names so
    enhance_visuals.py can identify slides by layout name.
    """
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    # Map default layout indices to our template names
    layout_names = [
        "Title Slide",      # 0: Title Slide
        "Mulu",             # 1: was Title and Content
        "dan_mulu",         # 2: was Section Header
        "T1_TextOnly",      # 3: was Two Content
        "T14_2Text",        # 4: was Comparison
        "T4_ImageTop",      # 5: was Title Only
        "T5_TwoImages2",   # 6: was Blank
        "T2_ImageRight",   # 7: was Content with Caption
        "Last_page",        # 8: was Picture with Caption
    ]

    for i, name in enumerate(layout_names):
        if i >= len(prs.slide_layouts):
            break
        layout = prs.slide_layouts[i]
        cSld = layout._element.find(qn("p:cSld"))
        if cSld is not None:
            cSld.set("name", name)
            # Clear all placeholder shapes (we draw everything manually)
            spTree = cSld.find(qn("p:spTree"))
            if spTree is not None:
                for sp in list(spTree.findall(qn("p:sp"))):
                    nvSpPr = sp.find(qn("p:nvSpPr"))
                    if nvSpPr is not None:
                        nvPr = nvSpPr.find(qn("p:nvPr"))
                        if nvPr is not None and nvPr.find(qn("p:ph")) is not None:
                            spTree.remove(sp)

    # Clear slide master placeholders too (prevents ghost text)
    master = prs.slide_masters[0]
    m_cSld = master._element.find(qn("p:cSld"))
    if m_cSld is not None:
        m_spTree = m_cSld.find(qn("p:spTree"))
        if m_spTree is not None:
            for sp in list(m_spTree.findall(qn("p:sp"))):
                nvSpPr = sp.find(qn("p:nvSpPr"))
                if nvSpPr is not None:
                    nvPr = nvSpPr.find(qn("p:nvPr"))
                    if nvPr is not None and nvPr.find(qn("p:ph")) is not None:
                        m_spTree.remove(sp)

    return prs


# Map template IDs to layout names (for slides.add_slide)
LAYOUT_NAME_MAP = {
    "T1_TextOnly":    "T1_TextOnly",
    "T4_ImageTop":    "T4_ImageTop",
    "T2_ImageRight":  "T2_ImageRight",
    "T3_ImageLeft":   "T2_ImageRight",   # shares layout (enhance only cares about T1/T14)
    "T5_TwoImages2":  "T5_TwoImages2",
    "T11_ImageRight2": "T5_TwoImages2",
    "T12_ImageLeft2":  "T5_TwoImages2",
    "T14_2Text":      "T14_2Text",
}


# ─── Shape Helpers ───

def _add_accent_bar(slide):
    """Thin navy accent strip on the left edge."""
    bar = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(0), ACCENT_BAR_W, SLIDE_H
    )
    bar.fill.solid()
    bar.fill.fore_color.rgb = CLR_PRIMARY
    bar.line.fill.background()
    spTree = slide.shapes._spTree
    spTree.remove(bar.element)
    spTree.insert(2, bar.element)


def _add_title_bar(slide, text, slide_number=None):
    """Add slide title with blue underline and optional part number."""
    # Title text
    txBox = slide.shapes.add_textbox(MARGIN_L, TITLE_Y, CONTENT_W, TITLE_H)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    _set_run_style(run, TITLE_SIZE, bold=True, color=CLR_PRIMARY)
    p.alignment = PP_ALIGN.LEFT

    # Accent underline
    line = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        MARGIN_L, UNDERLINE_Y, UNDERLINE_W, UNDERLINE_H
    )
    line.fill.solid()
    line.fill.fore_color.rgb = CLR_ACCENT
    line.line.fill.background()

    # Part number (top-right)
    if slide_number is not None:
        num_box = slide.shapes.add_textbox(
            Inches(12.2), Inches(0.25), Inches(0.8), Inches(0.3)
        )
        tf_n = num_box.text_frame
        p_n = tf_n.paragraphs[0]
        run_n = p_n.add_run()
        run_n.text = f"{slide_number:02d}"
        _set_run_style(run_n, PART_NUM_SIZE, color=CLR_TEXT_LT)
        p_n.alignment = PP_ALIGN.RIGHT


def _add_body_tf(slide, left, top, width, height):
    """Create a text box and return its text frame."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    return tf


def _add_reference(slide, ref_text):
    """Add small reference citation at bottom-right."""
    if not ref_text or not ref_text.strip():
        return
    ref_box = slide.shapes.add_textbox(MARGIN_L, REF_Y, CONTENT_W, Inches(0.3))
    tf = ref_box.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = ref_text.strip()
    _set_run_style(run, REF_SIZE, color=CLR_TEXT_LT)
    p.alignment = PP_ALIGN.RIGHT


# ─── Image Helpers ───

def _resolve_visuals(slide_info):
    """Resolve image/table names to file paths."""
    paths = []
    for name in slide_info.get("images", []) + slide_info.get("tables", []):
        key = name.replace(".png", "")
        fpath = os.path.join(FIGURES_DIR, f"{key}.png")
        if os.path.exists(fpath):
            paths.append(fpath)
        else:
            print(f"  [WARN] Visual not found: {fpath}")
    return paths


def _insert_image(slide, img_path, left, top, max_w, max_h):
    """Insert image preserving aspect ratio within given bounds."""
    with Image.open(img_path) as img:
        iw, ih = img.size
    aspect = iw / ih

    # Fit within bounds
    box_aspect = max_w / max_h
    if box_aspect > aspect:
        h = max_h
        w = int(h * aspect)
    else:
        w = max_w
        h = int(w / aspect)

    x = left + (max_w - w) // 2
    y = top + (max_h - h) // 2

    pic = slide.shapes.add_picture(str(img_path), x, y, width=w, height=h)
    return pic


# ─── T1→T14 Auto-Pairing ───

def _is_t1_textonly(s):
    return (s.get("template_id") == "T1_TextOnly"
            and not s.get("images") and not s.get("tables"))


def _pair_t1_to_t14(slides):
    """Merge consecutive T1_TextOnly slides in same section into T14_2Text.

    Skip pairing when either slide has a visual_element — those need to stay
    as individual T1 slides so their diagrams render properly.
    """
    out = []
    i = 0
    while i < len(slides):
        cur = slides[i]
        nxt = slides[i+1] if i + 1 < len(slides) else None
        if (nxt
                and _is_t1_textonly(cur)
                and _is_t1_textonly(nxt)
                and cur.get("section") == nxt.get("section")
                and not cur.get("visual_element")
                and not nxt.get("visual_element")):
            out.append({
                "section": cur["section"],
                "template_id": "T14_2Text",
                "columns": [
                    {"subsection": cur.get("subsection", ""),
                     "bullets": cur.get("bullets", []),
                     "paragraph": cur.get("paragraph", "")},
                    {"subsection": nxt.get("subsection", ""),
                     "bullets": nxt.get("bullets", []),
                     "paragraph": nxt.get("paragraph", "")},
                ],
                "images": [], "tables": [],
            })
            i += 2
        else:
            out.append(cur)
            i += 1
    return out


# ─── Slide Renderers ───

def _render_title_slide(slide, metadata):
    """Title slide: navy lower block, title above, author info below."""
    # Navy block in lower half
    bg = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(3.75), SLIDE_W, Inches(3.75)
    )
    bg.fill.solid()
    bg.fill.fore_color.rgb = CLR_PRIMARY
    bg.line.fill.background()
    spTree = slide.shapes._spTree
    spTree.remove(bg.element)
    spTree.insert(2, bg.element)

    # Title text (on white area)
    txBox = slide.shapes.add_textbox(
        Inches(1.0), Inches(1.0), Inches(11.333), Inches(2.5)
    )
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = metadata.get("title", "")
    _set_run_style(run, 32, bold=True, color=CLR_PRIMARY)
    p.alignment = PP_ALIGN.LEFT

    # Accent line at boundary
    accent = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(1.0), Inches(3.85), Inches(3.0), Inches(0.04)
    )
    accent.fill.solid()
    accent.fill.fore_color.rgb = CLR_ACCENT
    accent.line.fill.background()

    # Author
    auth_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(4.2), Inches(11.333), Inches(0.6)
    )
    tf_a = auth_box.text_frame
    tf_a.word_wrap = True
    p_a = tf_a.paragraphs[0]
    run_a = p_a.add_run()
    run_a.text = metadata.get("author", "")
    _set_run_style(run_a, 16, color=CLR_WHITE)

    # Organization
    org_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(5.0), Inches(11.333), Inches(0.5)
    )
    tf_o = org_box.text_frame
    tf_o.word_wrap = True
    p_o = tf_o.paragraphs[0]
    run_o = p_o.add_run()
    run_o.text = metadata.get("organization", "")
    _set_run_style(run_o, 14, color=CLR_ACCENT_LT)

    # Date
    date_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(5.6), Inches(11.333), Inches(0.4)
    )
    tf_d = date_box.text_frame
    p_d = tf_d.paragraphs[0]
    run_d = p_d.add_run()
    run_d.text = metadata.get("publish date", "")
    _set_run_style(run_d, 14, color=CLR_ACCENT_LT)


def _render_toc(slide, sections):
    """Table of contents with accent dots."""
    # Header
    h_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(0.8), Inches(11.333), Inches(0.8)
    )
    tf_h = h_box.text_frame
    p_h = tf_h.paragraphs[0]
    run_h = p_h.add_run()
    run_h.text = "Contents"
    _set_run_style(run_h, 28, bold=True, color=CLR_PRIMARY)

    # Thin line under header
    line = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(1.0), Inches(1.7), Inches(2.0), Inches(0.025)
    )
    line.fill.solid()
    line.fill.fore_color.rgb = CLR_ACCENT
    line.line.fill.background()

    # Section list
    for i, sec in enumerate(sections):
        y = Inches(2.2 + i * 0.72)

        # Accent dot
        dot = slide.shapes.add_shape(
            MSO_SHAPE.OVAL,
            Inches(1.2), y + Inches(0.12), Inches(0.14), Inches(0.14)
        )
        dot.fill.solid()
        dot.fill.fore_color.rgb = CLR_ACCENT
        dot.line.fill.background()

        # Number
        num_box = slide.shapes.add_textbox(
            Inches(1.55), y, Inches(0.5), Inches(0.45)
        )
        tf_n = num_box.text_frame
        p_n = tf_n.paragraphs[0]
        run_n = p_n.add_run()
        run_n.text = f"{i+1:02d}"
        _set_run_style(run_n, 14, bold=True, color=CLR_ACCENT)

        # Section name
        sec_box = slide.shapes.add_textbox(
            Inches(2.2), y, Inches(9.8), Inches(0.45)
        )
        tf_s = sec_box.text_frame
        p_s = tf_s.paragraphs[0]
        run_s = p_s.add_run()
        run_s.text = sec
        _set_run_style(run_s, 20, color=CLR_TEXT)


def _render_divider(slide, section, number):
    """Full-bleed navy section divider."""
    bg = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(0), SLIDE_W, SLIDE_H
    )
    bg.fill.solid()
    bg.fill.fore_color.rgb = CLR_PRIMARY
    bg.line.fill.background()
    spTree = slide.shapes._spTree
    spTree.remove(bg.element)
    spTree.insert(2, bg.element)

    # Part label
    part_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(2.5), Inches(11.333), Inches(0.5)
    )
    tf_p = part_box.text_frame
    p_p = tf_p.paragraphs[0]
    run_p = p_p.add_run()
    run_p.text = f"PART {number:02d}"
    _set_run_style(run_p, 14, bold=True, color=CLR_ACCENT)

    # Section title
    title_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(3.1), Inches(11.333), Inches(1.5)
    )
    tf_t = title_box.text_frame
    tf_t.word_wrap = True
    p_t = tf_t.paragraphs[0]
    run_t = p_t.add_run()
    run_t.text = section
    _set_run_style(run_t, 36, bold=True, color=CLR_WHITE)

    # Accent line
    accent = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(1.0), Inches(4.8), Inches(3.0), Inches(0.04)
    )
    accent.fill.solid()
    accent.fill.fore_color.rgb = CLR_ACCENT
    accent.line.fill.background()


def _render_last(slide):
    """Thank you / closing slide."""
    bg = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(0), SLIDE_W, SLIDE_H
    )
    bg.fill.solid()
    bg.fill.fore_color.rgb = CLR_PRIMARY
    bg.line.fill.background()
    spTree = slide.shapes._spTree
    spTree.remove(bg.element)
    spTree.insert(2, bg.element)

    txBox = slide.shapes.add_textbox(
        Inches(2), Inches(2.5), Inches(9.333), Inches(2.0)
    )
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = "Thank You"
    _set_run_style(run, 44, bold=True, color=CLR_WHITE)
    p.alignment = PP_ALIGN.CENTER

    # Accent line
    accent = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(5.5), Inches(4.7), Inches(2.333), Inches(0.04)
    )
    accent.fill.solid()
    accent.fill.fore_color.rgb = CLR_ACCENT
    accent.line.fill.background()


# ─── Content Slide Renderers ───

def _render_t1(slide, slide_info, slide_number):
    """T1_TextOnly — title + body + reference. Visual element space at bottom."""
    _add_accent_bar(slide)
    _add_title_bar(slide, slide_info.get("subsection", ""), slide_number)
    body_tf = _add_body_tf(slide, MARGIN_L, BODY_TOP, CONTENT_W, BODY_H)
    _fill_body(body_tf, slide_info, "T1_TextOnly")
    _add_reference(slide, slide_info.get("reference", ""))


def _render_t4(slide, slide_info, slide_number):
    """T4_ImageTop — wide image across top, body below."""
    _add_accent_bar(slide)
    _add_title_bar(slide, slide_info.get("subsection", ""), slide_number)

    visuals = _resolve_visuals(slide_info)
    body_top = BODY_TOP

    if visuals:
        _insert_image(slide, visuals[0],
                       MARGIN_L, BODY_TOP, CONTENT_W, Inches(3.0))
        body_top = Inches(4.4)

    body_tf = _add_body_tf(slide, MARGIN_L, body_top, CONTENT_W, Inches(2.8))
    _fill_body(body_tf, slide_info, "T4_ImageTop")
    _add_reference(slide, slide_info.get("reference", ""))


def _render_t2(slide, slide_info, slide_number):
    """T2_ImageRight — body left, image right."""
    _add_accent_bar(slide)
    _add_title_bar(slide, slide_info.get("subsection", ""), slide_number)

    visuals = _resolve_visuals(slide_info)

    if visuals:
        body_tf = _add_body_tf(slide, MARGIN_L, BODY_TOP, Inches(6.0), Inches(5.5))
        _insert_image(slide, visuals[0],
                       Inches(7.0), BODY_TOP, Inches(5.833), Inches(5.5))
    else:
        body_tf = _add_body_tf(slide, MARGIN_L, BODY_TOP, CONTENT_W, Inches(5.5))

    _fill_body(body_tf, slide_info, "T2_ImageRight")
    _add_reference(slide, slide_info.get("reference", ""))


def _render_t3(slide, slide_info, slide_number):
    """T3_ImageLeft — image left, body right."""
    _add_accent_bar(slide)
    _add_title_bar(slide, slide_info.get("subsection", ""), slide_number)

    visuals = _resolve_visuals(slide_info)

    if visuals:
        _insert_image(slide, visuals[0],
                       MARGIN_L, BODY_TOP, Inches(5.833), Inches(5.5))
        body_tf = _add_body_tf(slide, Inches(6.8), BODY_TOP, Inches(6.033), Inches(5.5))
    else:
        body_tf = _add_body_tf(slide, MARGIN_L, BODY_TOP, CONTENT_W, Inches(5.5))

    _fill_body(body_tf, slide_info, "T3_ImageLeft")
    _add_reference(slide, slide_info.get("reference", ""))


def _render_t5(slide, slide_info, slide_number):
    """T5_TwoImages2 — two images top, body below."""
    _add_accent_bar(slide)
    _add_title_bar(slide, slide_info.get("subsection", ""), slide_number)

    visuals = _resolve_visuals(slide_info)
    body_top = BODY_TOP

    if len(visuals) >= 2:
        img_w = Inches(5.9)
        img_h = Inches(3.0)
        _insert_image(slide, visuals[0], MARGIN_L, BODY_TOP, img_w, img_h)
        _insert_image(slide, visuals[1], Inches(6.933), BODY_TOP, img_w, img_h)
        body_top = Inches(4.4)
    elif len(visuals) == 1:
        _insert_image(slide, visuals[0], MARGIN_L, BODY_TOP, CONTENT_W, Inches(3.0))
        body_top = Inches(4.4)

    body_tf = _add_body_tf(slide, MARGIN_L, body_top, CONTENT_W, Inches(2.8))
    _fill_body(body_tf, slide_info, "T5_TwoImages2")
    _add_reference(slide, slide_info.get("reference", ""))


def _render_t14(slide, slide_info, slide_number):
    """T14_2Text — two-column layout from merged T1 slides."""
    _add_accent_bar(slide)

    # Section title bar
    _add_title_bar(slide, slide_info.get("section", ""), slide_number)

    cols = slide_info.get("columns", [])
    left = cols[0] if len(cols) > 0 else {}
    right = cols[1] if len(cols) > 1 else {}

    col_w = Inches(5.6)

    # ── Left column ──
    lt_box = slide.shapes.add_textbox(MARGIN_L, BODY_TOP, col_w, Inches(0.4))
    tf_lt = lt_box.text_frame
    p_lt = tf_lt.paragraphs[0]
    run_lt = p_lt.add_run()
    run_lt.text = left.get("subsection", "")
    _set_run_style(run_lt, 16, bold=True, color=CLR_ACCENT)

    lb_tf = _add_body_tf(slide, MARGIN_L, Inches(1.65), col_w, Inches(4.8))
    _fill_t14_column(lb_tf, left)

    # Vertical divider
    div = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(6.466), BODY_TOP, Inches(0.018), Inches(5.5)
    )
    div.fill.solid()
    div.fill.fore_color.rgb = CLR_DIVIDER
    div.line.fill.background()

    # ── Right column ──
    rt_box = slide.shapes.add_textbox(Inches(6.8), BODY_TOP, col_w, Inches(0.4))
    tf_rt = rt_box.text_frame
    p_rt = tf_rt.paragraphs[0]
    run_rt = p_rt.add_run()
    run_rt.text = right.get("subsection", "")
    _set_run_style(run_rt, 16, bold=True, color=CLR_ACCENT)

    rb_tf = _add_body_tf(slide, Inches(6.8), Inches(1.65), col_w, Inches(4.8))
    _fill_t14_column(rb_tf, right)


def _fill_t14_column(tf, col_data):
    """Fill a T14 column with bullets or paragraph."""
    bullets = col_data.get("bullets") or []
    para = (col_data.get("paragraph") or "").strip()
    if para and not bullets:
        _clear_text_frame(tf)
        p = tf.paragraphs[0] if tf.paragraphs else tf.add_paragraph()
        _set_no_bullet(p)
        segs = _parse_latex(para)
        if segs:
            _write_formatted_para(p, segs, BODY_SIZE)
        else:
            run = p.add_run()
            run.text = para
            _set_run_style(run, BODY_SIZE, color=CLR_TEXT)
    else:
        _fill_bullets(tf, bullets)


# Renderer dispatch table
RENDERERS = {
    "T1_TextOnly":    _render_t1,
    "T4_ImageTop":    _render_t4,
    "T2_ImageRight":  _render_t2,
    "T3_ImageLeft":   _render_t3,
    "T5_TwoImages2":  _render_t5,
    "T11_ImageRight2": _render_t5,
    "T12_ImageLeft2":  _render_t5,
    "T14_2Text":      _render_t14,
}


# ─── Theme Color Extraction ───

def _pick_theme_color(image_paths):
    """Extract representative theme color from figures."""
    import numpy as np
    all_pixels = []
    for path in image_paths[:3]:
        if not os.path.exists(path):
            continue
        with Image.open(path) as img:
            img = img.convert("RGB").resize((100, 100))
            pixels = np.array(img).reshape(-1, 3)
            mx = pixels.max(axis=1)
            mn = pixels.min(axis=1)
            v = mx / 255.0
            s = np.where(mx == 0, 0, (mx - mn) / mx)
            mask = (v > 0.1) & (v < 0.95) & (s > 0.15)
            filtered = pixels[mask]
            if len(filtered) > 0:
                all_pixels.append(filtered)
    if not all_pixels:
        return "2563EB"
    combined = np.vstack(all_pixels)
    quantized = (combined // 32) * 32 + 16
    keys = (quantized[:, 0].astype(np.uint32) << 16
            | quantized[:, 1].astype(np.uint32) << 8
            | quantized[:, 2].astype(np.uint32))
    unique, counts = np.unique(keys, return_counts=True)
    best = unique[np.argmax(counts)]
    r, g, b = (best >> 16) & 255, (best >> 8) & 255, best & 255
    v = max(r, g, b) / 255.0
    if v > 0.5:
        factor = 0.5 / v
        r, g, b = int(r * factor), int(g * factor), int(b * factor)
    return f"{r:02X}{g:02X}{b:02X}"


def _apply_theme_color(pptx_in, pptx_out, color_hex, target_key="dk2"):
    """Patch PPTX theme XML to set a theme color."""
    NS = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
    hexval = color_hex.lstrip("#").upper()
    with ZipFile(pptx_in, "r") as zin, ZipFile(pptx_out, "w") as zout:
        theme_paths = [p for p in zin.namelist()
                       if p.startswith("ppt/theme/") and p.endswith(".xml")]
        for name in zin.namelist():
            data = zin.read(name)
            if name in theme_paths:
                try:
                    root = etree.fromstring(data)
                    clr = root.find(".//a:clrScheme", namespaces=NS)
                    if clr is not None:
                        for el in clr:
                            if not isinstance(el.tag, str):
                                continue
                            tag = etree.QName(el).localname.lower()
                            if tag == target_key:
                                for child in list(el):
                                    el.remove(child)
                                srgb = etree.Element(f"{{{NS['a']}}}srgbClr")
                                srgb.set("val", hexval)
                                el.insert(0, srgb)
                    data = etree.tostring(root, xml_declaration=True,
                                          encoding="UTF-8", standalone="yes")
                except Exception:
                    pass
            zout.writestr(name, data)


# ─── Main ───

def main():
    # Load slide plan
    plan_path = os.path.join(WORKSPACE, "slide_plan_refined.json")
    with open(plan_path) as f:
        plan = json.load(f)

    # T1→T14 auto-pairing
    original_count = len(plan["slides"])
    plan["slides"] = _pair_t1_to_t14(plan["slides"])
    paired = original_count - len(plan["slides"])
    print(f"[plan] T1→T14 pairs: {paired}  ({original_count} → {len(plan['slides'])} slides)")

    # Create template-free presentation
    prs = _create_presentation()
    print("[template] Created template-free 16:9 presentation")

    # ─── Title Slide ───
    title_slide = prs.slides.add_slide(prs.slide_layouts.get_by_name("Title Slide"))
    _render_title_slide(title_slide, plan["metadata"])
    print("[slide] Title Slide")

    # ─── Table of Contents ───
    seen = set()
    sections = []
    for s in plan["slides"]:
        sec = s["section"]
        if sec not in seen:
            seen.add(sec)
            sections.append(sec)

    toc_slide = prs.slides.add_slide(prs.slide_layouts.get_by_name("Mulu"))
    _render_toc(toc_slide, sections)
    print(f"[slide] TOC ({len(sections)} sections)")

    # ─── Content Slides ───
    current_section = None
    section_counter = 0
    slide_number = 0

    for slide_info in plan["slides"]:
        # Section divider
        if slide_info["section"] != current_section:
            current_section = slide_info["section"]
            section_counter += 1
            div_slide = prs.slides.add_slide(prs.slide_layouts.get_by_name("dan_mulu"))
            _render_divider(div_slide, current_section, section_counter)
            print(f"[slide] Section divider: {current_section}")

        slide_number += 1
        template_id = slide_info.get("template_id", "T1_TextOnly")
        if template_id == "T19_2Text":
            template_id = "T14_2Text"

        # Get layout name (for enhance_visuals.py to read)
        layout_name = LAYOUT_NAME_MAP.get(template_id, "T1_TextOnly")
        try:
            layout = prs.slide_layouts.get_by_name(layout_name)
        except KeyError:
            layout = prs.slide_layouts.get_by_name("T1_TextOnly")
            template_id = "T1_TextOnly"

        slide = prs.slides.add_slide(layout)

        # Render content
        renderer = RENDERERS.get(template_id, _render_t1)
        renderer(slide, slide_info, slide_number)

        vis_count = len(_resolve_visuals(slide_info))
        vis_str = f" +{vis_count} visuals" if vis_count else ""
        print(f"  [{slide_number:02d}] {template_id}: {slide_info.get('subsection', '')}{vis_str}")

    # ─── Last Page ───
    last_slide = prs.slides.add_slide(prs.slide_layouts.get_by_name("Last_page"))
    _render_last(last_slide)
    print("[slide] Thank you page")

    # ─── Save ───
    output_path = os.path.join(WORKSPACE, "output.pptx")
    prs.save(output_path)
    total_slides = len(prs.slides)
    print(f"\n[saved] {output_path}")

    # ─── Apply Theme Color ───
    if os.path.isdir(FIGURES_DIR):
        image_files = sorted([
            os.path.join(FIGURES_DIR, f)
            for f in os.listdir(FIGURES_DIR)
            if f.startswith("image_") and f.endswith(".png")
        ])
        if image_files:
            try:
                import numpy as np
                theme_hex = _pick_theme_color(image_files)
                themed_path = os.path.join(WORKSPACE, "output_themed.pptx")
                _apply_theme_color(output_path, themed_path, theme_hex)
                shutil.move(themed_path, output_path)
                print(f"[theme] Applied: #{theme_hex}")
            except ImportError:
                print("[theme] numpy not available, skipping")
            except Exception as e:
                print(f"[theme] Error: {e}")

    # ─── Summary ───
    sz = os.path.getsize(output_path)
    print(f"\n{'='*50}")
    print(f"OUTPUT: {output_path}")
    print(f"  Total slides:     {total_slides}")
    print(f"  Title + TOC:      2")
    print(f"  Section dividers: {section_counter}")
    print(f"  Content slides:   {len(plan['slides'])}")
    print(f"  Thank you:        1")
    print(f"  T1→T14 pairs:     {paired}")
    print(f"  File size:        {sz // 1024}K")


if __name__ == "__main__":
    main()
