#!/usr/bin/env python3
"""Extract high-resolution figures and tables from PDF using Docling.

Usage:
    python extract_docling.py <pdf_path> [workspace_dir]

If workspace_dir is not provided, uses the script's own directory.
"""

import json
import os
import sys
from pathlib import Path

from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.datamodel.base_models import InputFormat
from docling_core.types.doc import ImageRefMode, PictureItem, TableItem
from docling_core.types.doc.document import BoundingBox
from PIL import Image as PILImage

# High-res: 10x scale gives ~4000px wide figures for crisp slides
IMAGES_SCALE = 10.0


def main():
    if len(sys.argv) < 2:
        print("Usage: python extract_docling.py <pdf_path> [workspace_dir]")
        sys.exit(1)

    pdf_path = sys.argv[1]
    workspace = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.abspath(__file__))
    figures_dir = os.path.join(workspace, "figures")
    os.makedirs(figures_dir, exist_ok=True)

    print(f"[docling] Converting PDF: {pdf_path}")
    print(f"[docling] Output: {figures_dir}")
    print(f"[docling] Scale: {IMAGES_SCALE}x (high-res)")
    pipeline_options = PdfPipelineOptions(
        generate_page_images=True,
        generate_picture_images=True,
        generate_table_images=True,
        images_scale=IMAGES_SCALE,
    )
    converter = DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
    )
    conv_res = converter.convert(pdf_path)
    doc = conv_res.document
    print(f"[docling] Pages: {len(doc.pages)}")
    print(f"[docling] Pictures: {len(doc.pictures)}")
    print(f"[docling] Tables: {len(doc.tables)}")

    # --- Save page images ---
    for page_no, page in doc.pages.items():
        page_img_path = os.path.join(figures_dir, f"page_{page.page_no}.png")
        with open(page_img_path, "wb") as fp:
            page.image.pil_image.save(fp, format="PNG")
        print(f"  page_{page.page_no}: {page.image.pil_image.size}")

    # --- Extract pictures (figures) using bounding box cropping ---
    images = {}
    for i, picture in enumerate(doc.pictures):
        page_no = picture.prov[0].page_no
        page = doc.pages[page_no]
        full_img = page.image.pil_image
        page_size = page.size
        page_w_pt, page_h_pt = page_size.width, page_size.height
        scale = full_img.width / page_w_pt

        bbox = picture.prov[0].bbox
        pad = 1
        padded_bbox = BoundingBox(
            l=bbox.l - pad, r=bbox.r + pad,
            b=bbox.b - pad, t=bbox.t + pad,
            coord_origin=bbox.coord_origin,
        )
        tl_bbox = padded_bbox.to_top_left_origin(page_height=page_h_pt)
        pil_box = tl_bbox.scaled(scale=scale).as_tuple()
        left, top, right, bottom = pil_box
        cropped = full_img.crop((left, top, right, bottom))

        img_idx = i + 1
        out_path = os.path.join(figures_dir, f"image_{img_idx}.png")
        cropped.save(out_path)

        caption = picture.caption_text(doc)
        print(f"  image_{img_idx}: page {page_no}, {cropped.size}, caption={caption[:80]}")

        images[f"image_{img_idx}"] = {
            "caption": caption,
            "page_no": page_no,
            "image_path": f"workspace/figures/image_{img_idx}.png",
            "width": cropped.size[0],
            "height": cropped.size[1],
            "figure_aspect": round(cropped.size[0] / cropped.size[1], 2) if cropped.size[1] > 0 else 1,
        }

    # --- Extract tables ---
    tables = {}
    table_counter = 0
    for element, _level in doc.iterate_items():
        if isinstance(element, TableItem):
            table_counter += 1
            out_path = os.path.join(figures_dir, f"table_{table_counter}.png")
            table_img = element.get_image(doc)
            table_img.save(out_path, "PNG")

            caption = element.caption_text(doc)
            print(f"  table_{table_counter}: {table_img.size}, caption={caption[:80]}")

            tables[f"table_{table_counter}"] = {
                "caption": caption,
                "page_no": element.prov[0].page_no if element.prov else 0,
                "table_path": f"workspace/figures/table_{table_counter}.png",
                "width": table_img.size[0],
                "height": table_img.size[1],
                "figure_aspect": round(table_img.size[0] / table_img.size[1], 2) if table_img.size[1] > 0 else 1,
            }

    # --- Save metadata ---
    with open(os.path.join(workspace, "images.json"), "w") as f:
        json.dump(images, f, indent=2)
    with open(os.path.join(workspace, "tables.json"), "w") as f:
        json.dump(tables, f, indent=2)

    # --- Clean up page images (only needed temporarily for cropping) ---
    removed = 0
    for fn in os.listdir(figures_dir):
        if fn.startswith("page_") and fn.endswith(".png"):
            os.remove(os.path.join(figures_dir, fn))
            removed += 1
    if removed:
        print(f"[cleanup] Removed {removed} page images")

    print(f"\n[done] {len(images)} images, {len(tables)} tables")
    print(f"[done] Saved to {figures_dir}")

    # List final files
    for fn in sorted(os.listdir(figures_dir)):
        if fn.endswith(".png"):
            sz = os.path.getsize(os.path.join(figures_dir, fn))
            print(f"  {fn}: {sz // 1024}K")


if __name__ == "__main__":
    main()
