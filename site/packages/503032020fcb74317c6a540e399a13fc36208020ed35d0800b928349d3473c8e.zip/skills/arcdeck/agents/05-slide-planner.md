# Agent 5: Slide Planner

## Role
Groups paragraphs into slides on a per-section basis using the RST discourse tree as structural guidance. Each section produces its own slide list, which are then merged into a unified presentation outline.

## Position in Pipeline
- **Phase:** 2 (Narrative Outline Generation)
- **Depends on:** A3 output (commitments.md), A4 output (RST trees + paragraphs)
- **Produces for:** A6 (Narrative Critic) via merged slides
- **LLM Required:** Yes
- **Execution:** Per-section (loop over all sections), then merge

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| RST tree | `workspace/rst/{section_key}/section_tree.json` | JSON tree |
| Paragraphs | `workspace/rst/{section_key}/paragraphs.json` | JSON dict: id→text |
| Results | `workspace/rst/results.json` | JSON aggregate |
| Presentation duration | User input | Integer (minutes) |
| Target audience | User input | String |

## Prompt Template
- **File:** `prompts/outline/slide_planner.txt`
- **Format:** Python format strings with `{variable}` placeholders
- **System Message:** `"You are an expert at organizing academic content into presentation slides. Output only valid JSON."`

### Template Variables
| Variable | Source | Description |
|----------|--------|-------------|
| `{section_title}` | Section heading | e.g., "Method" |
| `{subsections}` | Comma-joined subsection names | e.g., "RST Parsing, Slide Grouping" |
| `{num_paragraphs}` | Count of paragraphs in section | Integer |
| `{section_number}` | Position in paper (1-based) | e.g., 3 |
| `{total_sections}` | Total number of sections | e.g., 7 |
| `{presentation_length}` | Total talk duration | e.g., 20 |
| `{audience}` | Target audience | e.g., "researchers" |
| `{section_time_hint}` | Estimated time for this section | e.g., "~3 minutes" |
| `{section_tree_json}` | Full RST tree JSON | JSON string or "null" |
| `{paragraph_content}` | Formatted paragraph texts | See format below |
| `{slide_hint}` | Suggested slide count | e.g., "approximately 3 slide(s)" |

### Section Time Estimation
Calculate proportional time based on paragraph count:
```
proportion = section_paragraphs / total_paragraphs
estimated_time = max(1, round(proportion * total_time))

if estimated_time <= 2: "1-2 minutes (brief)"
elif estimated_time <= 4: "~{estimated_time} minutes"
else: "{estimated_time-1}-{estimated_time+1} minutes"
```

### Slide Hint Estimation
```
estimated_slides = max(1, num_paragraphs // 3)  # ~3 paragraphs per slide
slide_hint = "approximately {estimated_slides} slide(s)"
```

### Paragraph Content Format
```
[section_3_0]
We propose a method that combines discourse parsing with...

[section_3_1]
The key components of our approach include three modules...

[section_3_2]
Each module is responsible for a specific aspect of the...
```

## Output Schema

```json
{
  "section_slides": [
    {
      "slide_number": 1,
      "title": "Descriptive slide title reflecting content",
      "paragraphs": ["section_3_0", "section_3_1"],
      "rationale": "Brief explanation of why these paragraphs are grouped and how this slide contributes to section flow"
    },
    {
      "slide_number": 2,
      "title": "Next slide title",
      "paragraphs": ["section_3_2"],
      "rationale": "..."
    }
  ]
}
```

## Merging Per-Section Results

After processing ALL sections, merge into a single `merged_slides.json`:

```json
[
  {
    "slide_number": 1,
    "section": "introduction",
    "section_title": "Introduction",
    "title": "Motivation for Narrative-Driven Slides",
    "paragraphs": ["introduction_0", "introduction_1"],
    "rationale": "..."
  },
  {
    "slide_number": 2,
    "section": "introduction",
    "section_title": "Introduction",
    "title": "Key Insight: RST for Slide Structure",
    "paragraphs": ["introduction_2"],
    "rationale": "..."
  },
  {
    "slide_number": 3,
    "section": "method",
    "section_title": "Method",
    "title": "System Architecture Overview",
    "paragraphs": ["method_0", "method_1"],
    "rationale": "..."
  }
]
```

Numbering is sequential across all sections (1, 2, 3, ...).

## Output Paths
- `workspace/rst/{section_key}/slides.json` — per-section slide groupings
- `workspace/merged_slides.json` — merged slides across all sections

## Validation Rules
- Each paragraph from the section must appear in exactly one slide
- No duplicate paragraph assignments
- No invented paragraph IDs
- Each slide should have 1-4 paragraphs (prefer max 4 for readability)
- Slide titles should be descriptive (not just section names)

## Grouping Guidelines (from prompt)
1. Paragraphs connected via "elaboration" or "explanation" in the RST tree SHOULD usually appear on the same slide
2. "joint" relations indicate parallel points — group to avoid fragmentation
3. Slides must be ordered to reflect rhetorical progression within the section
4. Avoid abrupt topic shifts between consecutive slides
5. Each slide should have a clear, descriptive title
6. The resulting sequence should feel like a smooth spoken explanation

## Error Handling
- If LLM returns invalid JSON, retry once
- If a section has 0 paragraphs, skip it
- If paragraph coverage is incomplete after LLM response, add missing paragraphs to the last slide
