# Agent 13: PPTX Builder

## Role
Assembles the final PowerPoint presentation from the refined slide plan using **PptxGenJS** (Node.js). A single script (`generate_pptx.js`) handles all rendering: text with LaTeX formatting, images with aspect-ratio preservation, and programmatic visual element diagrams -- no template PPTX needed.

Claude Code runs the script, verifies the output, and optionally generates speaker notes.

## Position in Pipeline
- **Phase:** 8 (PPTX Assembly)
- **Depends on:** A12 output (`slide_plan_refined.json`), A2 output (`figures/*.png`)
- **Produces for:** User (final output)
- **LLM Required:** No (script execution only; optional Yes for speaker notes)

## Inputs

| Input | Source | Format |
|-------|--------|--------|
| `workspace/slide_plan_refined.json` | A12 (Design Refiner) | JSON with polished slides |
| `workspace/figures/*.png` | A2 (Asset Extractor) | Extracted figure/table images |

No template PPTX is needed -- the script creates slides programmatically from scratch.

## Design Principles

The renderer follows these aesthetic guidelines (inspired by Anthropic's PPTX skill):

- **Color palette:** "Ocean Gradient" -- `065A82` (deep blue primary), `1C7293` (teal secondary), `0891B2` (accent), `21295C` (midnight for dark slides)
- **Font pairing:** Georgia (headers, 36-44pt bold) + Calibri (body, 14-16pt)
- **Layout:** LAYOUT_WIDE (13.33" x 7.5") widescreen
- **Dark/light sandwich:** Dark backgrounds for title + conclusion slides, light for content
- **1 figure per page max:** Slides with 2+ visuals are split into separate pages
- **Aspect-ratio preservation:** Reads actual PNG/JPEG pixel dimensions from file headers, scales to fit without stretching
- **Wide image layout:** Images with AR > 1.5 go full-width below text; tall/square images go side-by-side with text
- **No decorative circles/ovals:** All visual element renderers use only rectangles and text
- **No accent lines under titles:** Uses whitespace and background color for separation

## Execution Steps

### Step 1: Install Dependencies (first run only)

```bash
cd workspace && npm install pptxgenjs
```

### Step 2: Generate PPTX

```bash
cd workspace && node generate_pptx.js
```

Or with the script from the skill repo:

```bash
cd workspace && node ../arcdeck-skill/scripts/generate_pptx.js
```

**What the script does:**

1. **Loads** `slide_plan_refined.json` and reads metadata (title, authors, organization).
2. **Splits multi-visual slides:** Any slide with 2+ images/tables is split -- first visual stays with bullets, extras become dedicated full-page figure slides.
3. **Creates presentation:** Sets LAYOUT_WIDE, applies Ocean Gradient palette.
4. **Renders slides in order:**
   - **Title Slide** -- dark background (`21295C`), large title, authors, organization
   - **TOC Slide** -- section list extracted from slide sections
   - **Section Dividers** -- dark background with section name
   - **Content Slides** -- based on whether slide has images or visual_element:
     - **Image slides:** Layout chosen by aspect ratio
       - Wide images (AR > 1.5): full-width text above, full-width image below
       - Tall/square: text on left, image on right
     - **Visual element slides:** Text on left (60% width), diagram on right (40%)
     - **Text-only slides:** Full-width bullets (fallback, rare)
   - **Last Slide** -- dark background with "Thank You" and contact info
5. **Parses LaTeX in bullets:** `\textbf{...}` -> bold, `\textcolor{color}{...}` -> colored+bold
6. **Renders visual elements** as programmatic shapes (rectangles + text only):
   - Each renderer creates distinct visual output (no two types look alike)
   - Uses accent colors from the Ocean Gradient palette
7. **Writes** `workspace/output.pptx`

### Step 3: Verify Output

1. Check that `workspace/output.pptx` exists.
2. Report file size and slide count.
3. Log which visual element types were rendered.

### Step 4: Speaker Notes (Optional)

If the user requested speaker notes:

1. Read `workspace/slide_plan_refined.json` for slide content.
2. Read `workspace/markdown.md` for paper context.
3. For each slide, generate a conversational speaker script:
   - 3-6 sentences per slide (50-150 words).
   - Conference talk style -- clear, engaging.
   - Do NOT read bullet points verbatim.
   - Reference figures naturally: "As you can see in the figure..."
   - Reference visual elements: "The diagram illustrates..."
   - Factual only -- no claims beyond paper content.
4. Save to `workspace/speaker_notes.json`

## Visual Element Renderers

All renderers use only **RECTANGLE shapes and text** -- no circles, ovals, or badges.

| Layout | Rendered As |
|--------|-------------|
| `process_flow` | Large cards with top accent bars, labels and sublabels |
| `cycle` | Cards arranged with arrow indicators showing circular flow |
| `comparison` | Side-by-side tinted panels with tone-based coloring (green=positive, red=negative, blue=neutral) |
| `stats_callout` | Big-number cards with accent-colored top bars |
| `timeline` | Horizontal sequence of labeled cards |
| `hierarchy` | Root card with connector lines to child cards |
| `stacked_list` | Numbered rows with accent index squares and descriptions |
| `split_panel` / `before_after` | Two contrasting side-by-side panels |
| `callout_cards` | Grid of white cards with accent-colored left borders, 13pt labels + 10pt sublabels |
| `banner_quote` | Full-width navy banner with 18pt white bold text |
| `matrix` | Grid of categorized cells |
| `radial` | Central card + satellite cards |
| `funnel` | Narrowing horizontal bars |
| `pyramid` | Layered structure |
| `icon_row` | Row of labeled cards |
| `progress_bar` | Segmented progress indicators |
| `equation_highlight` | Large centered concept box |

## LaTeX Text Parsing

The script parses LaTeX formatting in bullet text into PptxGenJS rich text arrays:

- `\textbf{term}` -> `{ text: "term", options: { bold: true } }`
- `\textcolor{blue}{good result}` -> `{ text: "good result", options: { bold: true, color: "0000FF" } }`
- `\textcolor{red}{bad result}` -> `{ text: "bad result", options: { bold: true, color: "CC0000" } }`

Within a single bullet point, all LaTeX segments share one paragraph:
- Only the first segment gets `bullet: true`
- Only the last segment gets `breakLine: true`
- This prevents mid-sentence bullet splitting

## Output
- `workspace/output.pptx` -- final presentation
- `workspace/speaker_notes.json` -- speaker notes (if requested)

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `pptxgenjs` not found | Run `cd workspace && npm install pptxgenjs` |
| Images not inserted | Check `workspace/figures/` contains the referenced PNG files |
| Small output file (<100K) | Likely missing images -- verify figure extraction completed |
| Slides look cramped | Check bullet count per slide (should be 3-5 max) |
| Image distorted | Verify `fitImg()` can read the PNG/JPEG headers (check file format) |

## Dependencies

Node.js packages (installed in workspace/):
- `pptxgenjs` -- PPTX creation (text, shapes, images, charts)

No Python dependencies needed for this phase. No template PPTX needed.

## PptxGenJS Pitfalls (from Anthropic PPTX Skill)

- **NEVER use "#" with hex colors** -- causes file corruption: use `"FF0000"` not `"#FF0000"`
- **NEVER encode opacity in hex color strings** -- 8-char colors corrupt the file; use `opacity` property
- **Use `bullet: true`** -- NEVER unicode symbols like "bullet" (creates double bullets)
- **Use `breakLine: true`** between array items for multi-line text
- **NEVER reuse option objects** across calls -- PptxGenJS mutates objects in-place
- **Avoid `lineSpacing` with bullets** -- use `paraSpaceAfter` instead
