# Agent 10: Slide Composer

## Role
Holistic slide plan creation — simultaneously matches figures to slides, selects templates, writes content, and designs visual elements. This is the first agent in the aesthetic pipeline: it transforms the narrative outline into a concrete, visually-rich slide plan.

Claude Code executes this agent directly — no external API calls. Read all inputs, reason about layout and content, and produce `slide_plan.json`.

## Position in Pipeline
- **Phase:** 6 (Slide Composition)
- **Depends on:** A8 output (`final_outline.json`), A9 output (`images_filtered.json`, `tables_filtered.json`), A3 output (`commitments.md`), A4 output (`rst/*/paragraphs.json`), A1 output (`markdown.md`)
- **Produces for:** A11 (Design Critic)
- **LLM Required:** Yes (Claude Code itself)

## Inputs

| Input | Source | Format |
|-------|--------|--------|
| `workspace/final_outline.json` | A8 (Narrative Judge) | JSON array of slide groupings |
| `workspace/images_filtered.json` | A9 (Image/Table Filter) | JSON dict of filtered images with captions, dims |
| `workspace/tables_filtered.json` | A9 (Image/Table Filter) | JSON dict of filtered tables with captions, dims |
| `workspace/commitments.md` | A3 (Commitment Builder) | Markdown with metadata + guidance |
| `workspace/rst/*/paragraphs.json` | A4 (Discourse Parser) | JSON dict mapping paragraph_id → text |
| `workspace/markdown.md` | A1 (PDF Preprocessor) | Full paper text |

## Step-by-Step Instructions

### Step 1: Read and Understand All Inputs

1. Read `workspace/final_outline.json`. Each entry has: `slide_number`, `section`, `section_title`, `title`, `paragraphs[]` (paragraph IDs), `rationale`.
2. Read `workspace/images_filtered.json`. Each entry has: `caption`, `page_no`, `image_path`, `width`, `height`, `figure_aspect`.
3. Read `workspace/tables_filtered.json`. Same structure as images.
4. Read `workspace/commitments.md`. Extract from the Snapshot section:
   - `title` — paper title
   - `author` — author names
   - `publish date` — publication venue/year
   - `organization` — affiliations
5. Read all `workspace/rst/*/paragraphs.json` files. Build a lookup: `paragraph_id → full_text`.
6. Skim `workspace/markdown.md` for any additional context.

### Step 2: Match Figures to Slides

Match each image/table to the slide whose content best aligns with the visual's caption and page context.

For each slide in `final_outline.json`:

1. Expand paragraph IDs to full text using the paragraph lookup.
2. For each image/table in `images_filtered.json` and `tables_filtered.json`:
   a. Read the **caption** — this describes what the figure shows.
   b. Read the **page_no** — figures near paragraphs on the same page are more likely related.
   c. Compare caption keywords/concepts against the slide's paragraph text.
3. Assign visuals by **caption-to-content relevance**:
   - A figure matches if its caption describes the same concept, method, or result as the slide's paragraphs.
   - Figures numbered close to the paper section (e.g., Figure 3 in Section 3) get priority for slides from that section.
   - If a figure's caption mentions a specific method/dataset/metric, match it to the slide discussing that topic.
4. Rules:
   - Each image/table can be assigned to **at most one slide** (no duplicates).
   - Prefer the most specific match (e.g., "RST discourse tree" matches a slide about discourse parsing, not a general overview slide).
   - If multiple slides could use the same figure, assign to the one where it's most central to the message.
   - Track which images/tables remain unassigned after the first pass.

### Step 3: Select Templates

For each slide, select a template based on its assigned visuals:

```
No visuals assigned → T1_TextOnly (+ visual_element required)

1 visual:
  aspect >= 1.6 (wide)  → T4_ImageTop
  aspect <= 1.0 (tall)  → T2_ImageRight or T3_ImageLeft (alternate for variety)
  otherwise             → T2_ImageRight or T3_ImageLeft

2 visuals:
  Both small            → T11_ImageRight2 or T12_ImageLeft2
  Both similar size     → T5_TwoImages2
  Need comparison       → T6_2x2_TopImage or T7_2x2_BottomImage

3 visuals → T10_3Img_BottomTextTop
4 visuals → T9_4Img_2x2Grid
```

**Variety rule:** Do not use the same template for two consecutive slides. Alternate T2/T3, T11/T12 placement.

### Step 4: Write Content

For each slide:

1. Read the full paragraph texts for this slide's paragraph IDs.
2. Distill into **3-5 top-level bullets** (default) or **1 paragraph** (for narrative-heavy slides like introduction/conclusion).
3. Rules:
   - Use the paper's actual terminology — do not paraphrase into generic language.
   - Each bullet: 1-2 lines, focused on a single point.
   - Sub-bullets: 0-2 per top bullet, providing supporting detail.
   - Image/table slides (T2-T12): max 4 top-level bullets.
   - Text-only slides (T1): max 5 top-level bullets.
   - **Exactly one** of `bullets` or `paragraph` must be non-empty (never both).

### Step 5: Design Visual Elements (T1_TextOnly slides only)

For every slide with `template_id: "T1_TextOnly"`, design a `visual_element`:

1. **Choose layout type** based on the content relationship:

| Content Pattern | Layout Type |
|----------------|-------------|
| Sequential steps, pipeline, method flow | `process_flow` |
| Iterative process, feedback loop | `cycle` |
| Comparing methods, systems, approaches | `comparison` |
| Key metrics, dataset statistics, numbers | `stats_callout` |
| Chronological phases, evolution | `timeline` |
| Taxonomy, breakdown, categories | `hierarchy` |
| Central concept with satellite ideas | `radial` |
| Grid categorization (2x2, 3x3) | `matrix` |
| Filtering, selection, narrowing | `funnel` |
| Feature list, numbered steps | `stacked_list` |
| Before/after contrast | `before_after` |
| Multiple contributions or cards | `callout_cards` |
| Hierarchical layers (abstract→concrete) | `pyramid` |
| Key formula or core insight | `equation_highlight` |
| Capabilities, tools, components in a row | `icon_row` |
| Problem vs. solution contrast | `split_panel` |
| Phase progression, completion status | `progress_bar` |
| Key finding, thesis statement | `banner_quote` |

2. **Create items** (3-5 entries):
   - `label`: 1-3 words, **must use paper-specific terminology** (method names, concept names, metric names — NOT "Step 1", "Point A").
   - `sublabel`: 1-8 words, concrete detail from the paper.
   - For `comparison`: add `tone` field — `"positive"` (proposed/better), `"negative"` (prior/worse), `"neutral"`.
   - For `stats_callout`: sublabel should be the actual number/metric from the paper.
   - For `hierarchy`: add `children` array.

3. **Set position**: `"bottom"` (default), `"right"`, or `"full"`.

4. **Variety rule:** No two consecutive T1 slides may use the same layout type.

### Step 6: Assemble and Save

Build the output JSON and save to `workspace/slide_plan.json`.

## Output Schema

```json
{
  "metadata": {
    "title": "Paper Title",
    "author": "Author Names",
    "publish date": "Venue Year",
    "organization": "Affiliations"
  },
  "slides": [
    {
      "section": "Introduction",
      "subsection": "Slide Title (max 5 words)",
      "template_id": "T1_TextOnly",
      "bullets": [
        {
          "text": "Top-level bullet point using paper terminology",
          "sub": ["Supporting detail 1", "Supporting detail 2"]
        }
      ],
      "paragraph": "",
      "images": [],
      "tables": [],
      "reference": "",
      "visual_element": {
        "layout": "process_flow",
        "position": "bottom",
        "items": [
          {"label": "Discourse Parsing", "sublabel": "RST tree per section"},
          {"label": "Commitment Building", "sublabel": "Global narrative contract"},
          {"label": "Slide Planning", "sublabel": "Paragraph-to-slide grouping"}
        ]
      }
    },
    {
      "section": "Method",
      "subsection": "Pipeline Overview",
      "template_id": "T4_ImageTop",
      "bullets": [
        {
          "text": "14-agent pipeline from PDF to polished slides",
          "sub": ["3 phases: content extraction, narrative structuring, visual rendering"]
        }
      ],
      "paragraph": "",
      "images": ["image_2.png"],
      "tables": [],
      "reference": "[1,2]",
      "visual_element": null
    }
  ]
}
```

## Validation Rules

1. Every slide has exactly one of `bullets` (non-empty array) or `paragraph` (non-empty string).
2. Every `T1_TextOnly` slide has a non-null `visual_element` with `layout`, `position`, and `items`.
3. Every non-T1 slide has `visual_element: null`.
4. All image filenames in `images` arrays exist in `images_filtered.json`.
5. All table filenames in `tables` arrays exist in `tables_filtered.json`.
6. No image/table is assigned to more than one slide.
7. No two consecutive slides share the same `template_id`.
8. No two consecutive T1 slides share the same `visual_element.layout`.
9. Visual element items have 3-5 entries.
10. Visual element labels use paper-specific terms, not generic placeholders.

## Output Path
- `workspace/slide_plan.json`
