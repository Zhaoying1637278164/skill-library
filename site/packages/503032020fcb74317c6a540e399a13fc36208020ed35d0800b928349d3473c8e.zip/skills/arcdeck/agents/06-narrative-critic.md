# Agent 6: Narrative Critic

## Role
Reviews the merged slide plan against the Global Commitment and presentation quality rubrics. Produces actionable critique identifying issues with alignment, flow, balance, and coherence. Does NOT modify the plan — that is Agent 7's job.

## Position in Pipeline
- **Phase:** 2 (Refinement Loop — step 1 of 3)
- **Depends on:** A5 output (merged_slides.json), A3 output (commitments.md)
- **Produces for:** A7 (Slide Reviser)
- **LLM Required:** Yes
- **Loop:** Called up to 3 times in the refinement cycle

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| Merged slides | `workspace/merged_slides.json` (round 0) or `workspace/revised_slides_round_{N-1}.json` (later rounds) | JSON array |
| Commitment | `workspace/commitments.md` | Markdown |
| Paragraph texts | `workspace/rst/*/paragraphs.json` | JSON dicts merged into one dict: id→text |
| Round number | Internal counter | Integer (0-based) |

## Preprocessing

### Collect All Paragraphs
Merge all per-section paragraph files into one dict:
```
paragraph_map = {}
for each section_key in workspace/rst/:
    load workspace/rst/{section_key}/paragraphs.json
    merge into paragraph_map
```

### Build Section Inventory
Extract unique section keys from merged slides, in order of first appearance:
```json
["introduction", "related_work", "method", "experiments", "conclusion"]
```

### Build Paragraph Snippets
For each paragraph in paragraph_map, create a snippet (full text, preserving content):
```json
{
  "introduction_0": "We present ArcDeck, a narrative-driven system for...",
  "introduction_1": "Prior work on paper-to-slides has focused on..."
}
```

## Prompt Template
- **File:** `prompts/outline/narrative_critic.txt` (when using commitment)
- **Fallback:** `prompts/outline/narrative_critic_no_commitment.txt` (if no commitment available)
- **Format:** Python format strings with `{variable}` placeholders
- **System Message:** `"You are a meticulous academic presentation reviewer. Output only valid JSON."`

### Template Variables
| Variable | Source | Description |
|----------|--------|-------------|
| `{audience}` | User input | e.g., "researchers" |
| `{presentation_length}` | User input | e.g., 20 |
| `{commitment_md}` | Contents of workspace/commitments.md | Full markdown text |
| `{merged_slides_json}` | JSON dump of merged slides | JSON string |
| `{section_inventory}` | JSON array of section keys | JSON string |
| `{paragraph_snippets}` | JSON dict of paragraph texts | JSON string |

## Evaluation Rubric (from prompt)

The critic evaluates across 5 dimensions, in priority order:

1. **Commitment Alignment** (highest priority)
   - Does the plan realize the commitment's thesis and key takeaways?
   - Are must-include beats present and appropriately placed?
   - Is emphasis aligned with commitment priorities?
   - Are out-of-scope items mistakenly foregrounded?

2. **Global Flow**
   - Is the order appropriate for a paper talk?
   - Canonical: Intro → Related Work → Method → Experiments → Results → Conclusion
   - Are any canonical parts missing or misplaced?

3. **Section Balance**
   - Are sections proportional to talk length and commitment slide budget?

4. **Slide Coherence**
   - Too broad (mixed topics) or too narrow (should be merged)?
   - Paragraphs that belong elsewhere?
   - Weak transitions?

5. **Redundancy / Gaps**
   - Repeated ideas across slides?
   - Logical jumps or missing transitions?

## Output Schema

```json
{
  "overall_assessment": "1-2 paragraphs of critique mentioning commitment alignment explicitly",
  "priority_fixes": [
    {
      "priority": 1,
      "issue": "short issue title",
      "details": "why it matters, tied to commitment when relevant",
      "suggested_fix": "actionable fix (reorder/merge/split/regroup/title changes)",
      "affected": {
        "slides": [1, 2],
        "sections": ["introduction", "method"],
        "paragraphs": ["introduction_0", "method_3"]
      },
      "commitment_refs": {
        "violated_or_targeted": ["must-include", "narrative spine", "slide budget"],
        "notes": "1-2 short bullets referencing commitment items"
      }
    }
  ],
  "section_order_suggestion": ["introduction", "related_work", "method", "experiments", "results", "conclusion"],
  "notes": ["optional extra observations"]
}
```

## Output Path
- `workspace/critique_round_{N}.json`

## Validation Rules
- Output must be valid JSON
- `priority_fixes` must be an array (may be empty if plan is excellent)
- Referenced paragraph IDs must exist in the merged slides
- Referenced slide numbers must be valid

## Error Handling
- If LLM returns non-JSON, try to extract JSON from the response (look for `{...}` blocks)
- If extraction fails, return a default critique with `overall_assessment: "Unable to generate critique"` and empty `priority_fixes`
