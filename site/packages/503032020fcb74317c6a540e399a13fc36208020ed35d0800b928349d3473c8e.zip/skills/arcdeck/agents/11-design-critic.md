# Agent 11: Design Critic

## Role
Reviews `slide_plan.json` for aesthetic quality using CARP+ design principles. Produces a scored evaluation with specific, actionable fix instructions. This is the visual counterpart to A6 (Narrative Critic) — it ensures the presentation looks professional, varied, and visually communicative.

Claude Code executes this agent directly. Read the slide plan, evaluate each slide and the deck as a whole, and produce `design_critique.json`.

## Position in Pipeline
- **Phase:** 7 (Aesthetic Critique-Refine)
- **Depends on:** A10 output (`slide_plan.json`), A3 output (`commitments.md`)
- **Produces for:** A12 (Design Refiner)
- **LLM Required:** Yes (Claude Code itself)

## Inputs

| Input | Source | Format |
|-------|--------|--------|
| `workspace/slide_plan.json` | A10 (Slide Composer) | JSON with metadata + slides array |
| `workspace/commitments.md` | A3 (Commitment Builder) | Markdown with content priorities |

## Evaluation Framework: CARP+ Design Principles

Review every slide and the deck globally against these 7 criteria:

### 1. Contrast (Weight: 15%)
- Do visual elements stand out from the background?
- Are titles clearly distinguishable from body text?
- Is there sufficient variety between adjacent slides (different templates, different diagrams)?
- **Fail signals:** Two consecutive slides look identical; visual element blends into text.

### 2. Alignment (Weight: 10%)
- Are template choices consistent within each section?
- Do visual element types match the content they represent?
- Are bullet structures parallel (similar grammatical structure)?
- **Fail signals:** Random template switching within a section; `comparison` layout used for sequential content.

### 3. Repetition (Weight: 10%)
- Is there a consistent visual language across the deck?
- Are section patterns predictable (divider → content → content)?
- Is terminology consistent (same concept always called the same thing)?
- **Fail signals:** Mixed terminology for same concept; inconsistent bullet depth across similar slides.

### 4. Proximity (Weight: 15%)
- Are related items grouped together in visual elements?
- Is information density balanced (3-5 items per visual, 3-5 bullets per slide)?
- Are slides neither too sparse (1-2 bullets) nor too dense (6+ bullets)?
- **Fail signals:** Visual element has 7+ items; slide has only 1 bullet; unrelated items grouped.

### 5. Content-Visual Alignment (Weight: 25%)
- Do visual element labels use **actual paper terminology** (method names, dataset names, metric names)?
- Are stats_callout numbers **real values from the paper** (not placeholders)?
- Do comparison items reference **actual systems/methods** by name?
- Does the diagram type correctly represent the content relationship?
- **Fail signals:** Generic labels ("Step 1", "Method A", "Point 1"); placeholder numbers; wrong diagram type for content.

### 6. Variety (Weight: 15%)
- No two consecutive slides use the same template?
- No two consecutive T1 slides use the same visual element layout?
- Is image placement alternated (T2/T3, T11/T12)?
- Are different visual element types used across the deck (at least 4 unique layouts)?
- **Fail signals:** Consecutive `process_flow` layouts; all T1 slides use same diagram; only T4 used for images.

### 7. Information Design (Weight: 10%)
- Is the right diagram type chosen for each content type?
  - Sequential steps → `process_flow` or `timeline` (not `comparison`)
  - Method comparison → `comparison` or `split_panel` (not `process_flow`)
  - Quantitative results → `stats_callout` (not `callout_cards`)
  - Key finding → `banner_quote` or `equation_highlight` (not `stacked_list`)
- Do visual elements communicate information or just decorate?
- **Fail signals:** Decorative-only diagrams; mismatched diagram type; visual element that doesn't add to understanding.

## Scoring

Rate each criterion on a 1-10 scale. Compute weighted overall score:

```
overall_score = 0.15*contrast + 0.10*alignment + 0.10*repetition + 0.15*proximity
              + 0.25*content_visual + 0.15*variety + 0.10*info_design
```

### Decision Logic
- `overall_score >= 8.0` AND no high-severity issues → `decision: "pass"`
- Otherwise → `decision: "refine"`

### Severity Levels
- **high** — Must fix. Generic labels, wrong diagram type, missing visual element, duplicate consecutive layouts.
- **medium** — Should fix. Suboptimal template choice, could use better terminology, slightly too many/few bullets.
- **low** — Nice to have. Minor wording improvement, optional variety enhancement.

## Step-by-Step Instructions

1. Read `workspace/slide_plan.json`.
2. Read `workspace/commitments.md` for content priorities and key terms.
3. **Per-slide review:** For each slide, check all 7 criteria. Record issues with category, severity, description, and specific fix instruction.
4. **Global review:** Check deck-level patterns — template variety, layout variety, section consistency, information density distribution.
5. Compute scores and overall decision.
6. Save to `workspace/design_critique.json`.

## Output Schema

```json
{
  "scores": {
    "contrast": 8,
    "alignment": 7,
    "repetition": 9,
    "proximity": 7,
    "content_visual_alignment": 6,
    "variety": 8,
    "information_design": 7
  },
  "overall_score": 7.3,
  "decision": "refine",
  "slide_critiques": [
    {
      "slide_index": 3,
      "subsection": "Three Core Mechanisms",
      "issues": [
        {
          "category": "content_visual_alignment",
          "severity": "high",
          "description": "Visual element labels use generic 'Step 1', 'Step 2', 'Step 3' instead of paper-specific terms",
          "fix": "Replace with actual mechanism names: 'RST Discourse Parsing', 'Commitment Contract', 'Critique-Revise-Judge Loop'"
        },
        {
          "category": "proximity",
          "severity": "medium",
          "description": "Only 2 bullets — slide feels sparse",
          "fix": "Add 1-2 more bullets covering the paragraph content about multi-agent coordination"
        }
      ]
    },
    {
      "slide_index": 5,
      "subsection": "Refinement Loop",
      "issues": [
        {
          "category": "variety",
          "severity": "high",
          "description": "Uses process_flow layout, same as slide 4",
          "fix": "Change to cycle layout — better represents the iterative critic-revise-judge loop"
        }
      ]
    }
  ],
  "global_issues": [
    {
      "category": "variety",
      "severity": "medium",
      "description": "Only 3 unique visual element layouts used across 8 T1 slides",
      "fix": "Introduce at least 2 more layout types — consider stats_callout for experiment results, hierarchy for RST taxonomy"
    }
  ],
  "summary": "Strong narrative structure but visual elements need paper-specific enrichment. Key issues: generic labels (3 slides), consecutive layout duplication (1 pair), sparse bullet counts (2 slides)."
}
```

## Validation Rules

1. Output must be valid JSON.
2. `slide_critiques` must reference valid slide indices (0-based).
3. Every issue must have `category`, `severity`, `description`, and `fix`.
4. `severity` must be one of: `"high"`, `"medium"`, `"low"`.
5. `category` must be one of the 7 CARP+ criteria (snake_case).
6. `decision` must be `"pass"` or `"refine"`.
7. `overall_score` must be between 1.0 and 10.0.
8. `summary` is a 1-3 sentence overview of key findings.

## Output Path
- `workspace/design_critique.json`
