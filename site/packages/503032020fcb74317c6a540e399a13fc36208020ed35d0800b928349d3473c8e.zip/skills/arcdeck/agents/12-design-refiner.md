# Agent 12: Design Refiner

## Role
Applies design critique fixes, enriches visual elements with paper-specific content, polishes formatting, and produces the final refined slide plan. This is the last LLM-driven agent before PPTX rendering.

Claude Code executes this agent directly. Read the slide plan + design critique + source content, apply all fixes, and produce `slide_plan_refined.json`.

## Position in Pipeline
- **Phase:** 7 (Aesthetic Critique-Refine, continued)
- **Depends on:** A10 output (`slide_plan.json`), A11 output (`design_critique.json`), A1 output (`markdown.md`), A4 output (`rst/*/paragraphs.json`)
- **Produces for:** A13 (PPTX Builder)
- **LLM Required:** Yes (Claude Code itself)

## Inputs

| Input | Source | Format |
|-------|--------|--------|
| `workspace/slide_plan.json` | A10 (Slide Composer) | JSON with slides array |
| `workspace/design_critique.json` | A11 (Design Critic) | JSON with issues + fixes |
| `workspace/markdown.md` | A1 (PDF Preprocessor) | Full paper text |
| `workspace/rst/*/paragraphs.json` | A4 (Discourse Parser) | Paragraph ID → text mapping |

## Step-by-Step Instructions

### Step 1: Load All Inputs

1. Read `workspace/slide_plan.json` — this is the base to refine.
2. Read `workspace/design_critique.json` — contains scored issues with fix instructions.
3. Read all `workspace/rst/*/paragraphs.json` — build paragraph lookup for content enrichment.
4. Read `workspace/markdown.md` — for extracting specific numbers, method names, dataset details.

### Step 2: Apply Design Critique Fixes

Process each issue from `design_critique.json`:

**High-severity (MUST fix):**
- Apply the exact fix described in the issue's `fix` field.
- If the fix involves changing a visual element layout, also update the items to match the new layout type.
- If the fix involves replacing generic labels, find the correct paper-specific terms from the paragraph text or markdown.

**Medium-severity (SHOULD fix):**
- Apply if the fix is straightforward and improves quality.
- Skip only if applying it would conflict with a high-severity fix.

**Low-severity (OPTIONAL):**
- Apply if time permits and no risk of degradation.

Track all applied fixes for the summary.

### Step 3: Visual Element Enrichment

For every T1_TextOnly slide with a `visual_element`:

**A. Label Quality Check**
- Every `label` must be a paper-specific term: method name, concept name, metric name, system name.
- Replace any generic labels ("Step 1", "Point A", "Method A", "Item 1") with actual terms from the paper.
- Labels: 1-3 words maximum.

**B. Sublabel Enrichment**
- Every `sublabel` should add concrete detail from the paper.
- For `stats_callout`: sublabel must be an **actual number** from the paper (e.g., "994", "7.5%", "100 curated").
- For `comparison`: sublabel should describe a specific characteristic of that system/method.
- For `process_flow`: sublabel should name the specific output or action at that stage.
- Sublabels: 1-8 words maximum.

**C. Tone Assignment (comparison only)**
- `"positive"` — for the proposed method/approach (renders as blue).
- `"negative"` — for prior work, baselines, limitations (renders as gray).
- `"neutral"` — for equal/objective items (renders as secondary blue).

**D. Layout Appropriateness**
If the content doesn't match the current layout type, change it:

| If content is about... | But layout is... | Change to... |
|----------------------|-----------------|-------------|
| Sequential steps | `comparison` | `process_flow` |
| Method comparison | `process_flow` | `comparison` |
| Iterative loop | `stacked_list` | `cycle` |
| Key metrics | anything else | `stats_callout` |
| Taxonomy | `process_flow` | `hierarchy` |

**E. Variety Enforcement**
- Scan all T1 slides in order. If two consecutive T1 slides have the same layout, change the second one.
- Ensure at least 4 unique layout types across the deck.

### Step 4: Bullet Refinement

For every slide:

**A. Count Check**
- T1_TextOnly: 3-5 top-level bullets with 1-3 sub-bullets each.
- Image slides (T2-T12): 3-4 top-level bullets with 0-2 sub-bullets each.
- If fewer than minimum: extract additional points from paragraph text.
- If more than maximum: merge or drop least important bullets.

**B. Content Quality**
- Bullets should use paper terminology, not generic paraphrases.
- Each bullet conveys one clear point.
- Sub-bullets provide supporting detail, not restatement.
- EITHER `bullets` OR `paragraph` — never both (clear the unused field).

### Step 5: LaTeX Formatting

Apply sparingly — less is more:

**Allowed commands (ONLY these three):**
- `\textbf{term}` — bold key terms, model names, concept names. 2-4 words max. Max 2-4 per slide.
- `\textcolor{blue}{phrase}` — genuinely positive outcomes, improvements. 2-5 words max. Max 1-2 per slide.
- `\textcolor{red}{phrase}` — genuinely negative aspects, limitations. 2-5 words max. Max 1-2 per slide.

**Rules:**
- Bold is preferred over color.
- Do NOT format entire bullets — only key terms within bullets.
- Do NOT use any other LaTeX (no `\(`, no Greek letters, no math symbols, no superscripts).
- Do NOT use `\textcolor` for neutral content — only for genuinely positive (blue) or negative (red).

**Examples:**
- Good: `"\textbf{ArcDeck} achieves \textcolor{blue}{state-of-the-art} results on slide generation"`
- Bad: `"\textbf{ArcDeck achieves state-of-the-art results on slide generation}"` (entire bullet bolded)
- Bad: `"Achieves $7.5\%$ improvement"` (math mode not allowed)

### Step 6: Reference Processing

For each slide's `reference` field:

- **Keep:** Citation-style references like `"[1,2,3]"` or `"Smith et al., 2023"`.
- **Remove:** Internal references like `"Fig. 1"`, `"Table 1"`, `"Section 3.1"`, `"Appendix A"`.
- If only internal references remain, set `reference` to `""`.

### Step 7: Title Shortening

For each slide's `subsection` field:
- Maximum 5 words.
- Must be content-specific (not generic like "Method" or "Experiments").
- Good: "RST Discourse Parsing", "Critique-Revise-Judge Loop", "Dataset & Evaluation"
- Bad: "Our Method Overview", "Experimental Results Section", "Background and Related Work"

### Step 8: Save Output

Save the refined slide plan to `workspace/slide_plan_refined.json`. Same schema as `slide_plan.json`.

## Output Schema

Same as `slide_plan.json`:

```json
{
  "metadata": {
    "title": "...",
    "author": "...",
    "publish date": "...",
    "organization": "..."
  },
  "slides": [
    {
      "section": "...",
      "subsection": "...",
      "template_id": "T1_TextOnly",
      "bullets": [
        {
          "text": "\\textbf{ArcDeck} reconstructs narrative structure via RST discourse trees",
          "sub": ["Builds per-section trees linking paragraphs by rhetorical relations"]
        }
      ],
      "paragraph": "",
      "images": [],
      "tables": [],
      "reference": "[1,2]",
      "visual_element": {
        "layout": "process_flow",
        "position": "bottom",
        "items": [
          {"label": "RST Parsing", "sublabel": "Discourse tree per section"},
          {"label": "Commitment Builder", "sublabel": "Global narrative contract"},
          {"label": "Slide Planner", "sublabel": "Paragraph groupings"},
          {"label": "Refinement Loop", "sublabel": "Critique-judge-revise (3 rounds)"}
        ]
      }
    }
  ]
}
```

## Validation Rules

1. Every slide has exactly one of `bullets` (non-empty array) or `paragraph` (non-empty string).
2. Every `T1_TextOnly` slide has a non-null `visual_element`.
3. Every non-T1 slide has `visual_element: null`.
4. No two consecutive T1 slides share the same `visual_element.layout`.
5. Visual element items have 3-5 entries with paper-specific labels.
6. LaTeX uses only `\textbf{}`, `\textcolor{blue}{}`, `\textcolor{red}{}`.
7. No math symbols, Greek letters, or other LaTeX commands.
8. Slide titles (`subsection`) are max 5 words.
9. References are citation-style only (no internal "Fig./Table/Section" refs).
10. All image/table filenames reference files that exist in the workspace.

## Output Path
- `workspace/slide_plan_refined.json`
