# Agent 4: Discourse Parser

## Role
Constructs a hierarchical RST (Rhetorical Structure Theory) discourse tree for each paper section. Each tree captures how paragraphs relate to each other (elaboration, contrast, evidence, etc.), enabling discourse-guided slide grouping downstream.

## Position in Pipeline
- **Phase:** 2 (Narrative Outline Generation)
- **Depends on:** A1 output (workspace/markdown.md)
- **Produces for:** A5 (Slide Planner)
- **LLM Required:** Yes
- **Execution:** Per-section (loop over all sections in the paper)

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| Paper markdown | `workspace/markdown.md` | Plain text |

## Preprocessing Steps (before LLM calls)

### Step 1: Split Markdown into Sections
1. Split at `## ` headings (level-2 headers)
2. Group subsections (e.g., `### 3.1`, `### 3.2`) under their parent section
3. Remove the "References" section and everything below it
4. Create a section key for each: slugify the heading (e.g., "Related Work" → `related_work`)

### Step 2: Clean Text for RST Parsing
For each section's text:
- Remove code blocks (``` ... ```)
- Remove image references (`![...](...)`), links (`[text](url)`)
- Remove bold/italic markers (`**`, `*`, `__`, `_`)
- Strip inline LaTeX
- Normalize whitespace

### Step 3: Split into Paragraphs
For each section:
1. Split cleaned text at double-newline boundaries
2. Skip paragraphs shorter than 20 characters
3. Name each paragraph: `{section_key}_{index}` (e.g., `introduction_0`, `introduction_1`)
4. Save to `workspace/rst/{section_key}/paragraphs.json`

Paragraph JSON format:
```json
{
  "introduction_0": "We present ArcDeck, a narrative-driven system...",
  "introduction_1": "Prior work on paper-to-slides conversion...",
  "introduction_2": "Our key insight is that rhetorical structure..."
}
```

### Step 4: Skip sections with fewer than 2 paragraphs
RST requires at least 2 EDUs (paragraphs) to build a tree. For single-paragraph sections, create a trivial tree with just that paragraph as root.

## Prompt Template
- **File:** `prompts/outline/section_rst.txt`
- **Format:** Python format strings with `{variable}` placeholders
- **System Message:** `"You are an expert RST discourse parser. Output only valid RS3 XML."`

### Template Variables
| Variable | Source | Description |
|----------|--------|-------------|
| `{section_title}` | Section heading text | e.g., "Introduction" |
| `{subsections}` | Comma-separated subsection names | e.g., "Background, Motivation" |
| `{paragraph_input}` | Formatted paragraph content | See format below |

### Paragraph Input Format
```
[introduction_0]
We present ArcDeck, a narrative-driven system for converting academic papers...

[introduction_1]
Prior work on paper-to-slides conversion has focused on extractive summarization...

[introduction_2]
Our key insight is that rhetorical structure theory provides...
```

## Output Schema

```json
{
  "root": "gK",
  "groups": {
    "gK": {
      "type": "multinuc",
      "relation": "joint",
      "left": "gA",
      "right": "introduction_2"
    },
    "gA": {
      "type": "rst",
      "relation": "elaboration",
      "nucleus": "introduction_0",
      "satellite": "introduction_1"
    }
  }
}
```

### Group Node Types

**A) Nucleus-Satellite (type="rst"):**
```json
{
  "type": "rst",
  "relation": "<rst_relation>",
  "nucleus": "<child_id>",
  "satellite": "<child_id>"
}
```

**B) Multinuclear (type="multinuc"):**
```json
{
  "type": "multinuc",
  "relation": "<multinuc_relation>",
  "left": "<child_id>",
  "right": "<child_id>"
}
```

A `<child_id>` is either a paragraph name (leaf) or a group ID like `"g1"`.

## RST Relation Inventory (Closed Set)

| Relation | Type | Meaning | Slide Implication |
|----------|------|---------|-------------------|
| `elaboration` | Nucleus-Satellite | Adds detail/examples | Group together |
| `explanation` | Nucleus-Satellite | Clarifies why/how | Group together |
| `context` | Nucleus-Satellite | Background/definitions | Introductory content |
| `purpose` | Nucleus-Satellite | Goal/motivation | Often introductory |
| `evaluation` | Nucleus-Satellite | Assessment/judgment | May deserve own slide |
| `organization` | Nucleus-Satellite | Meta-structural framing | Topic sentence |
| `joint` | Multinuclear | Equal importance, parallel | Can share a slide |
| `same-unit` | Multinuclear | One unit split across paragraphs | Must stay together |

## Validation Rules

After receiving the LLM response, validate the tree:

1. **JSON parses** — must be valid JSON
2. **Root exists** — `root` value must be a key in `groups`
3. **Complete coverage** — every paragraph name must appear exactly once as a leaf
4. **Tree structure** — connected and acyclic; every non-root group referenced as a child exactly once
5. **Valid relations** — only from the 8 allowed relations listed above
6. **Valid types** — only `"rst"` or `"multinuc"`
7. **Correct fields** — RST groups have `nucleus`+`satellite`, multinuc groups have `left`+`right`

### If Validation Fails
- Retry the LLM call once (same prompt)
- If second attempt also fails, create a simple fallback tree:
  - Chain all paragraphs in a linear `joint` tree

## Output Paths
- `workspace/rst/{section_key}/paragraphs.json` — paragraph name→text mapping
- `workspace/rst/{section_key}/section_tree.json` — RST tree JSON
- `workspace/rst/results.json` — aggregate results for all sections:
  ```json
  {
    "introduction": {
      "title": "Introduction",
      "subsections": ["Background", "Motivation"],
      "success": true,
      "paragraphs": 5
    },
    "method": { ... }
  }
  ```

## Execution Summary

```
For each section in the paper:
  1. Clean text, split into paragraphs, name them
  2. Save paragraphs.json
  3. Format prompt with section_title, subsections, paragraph_input
  4. Call LLM with system message
  5. Parse JSON response
  6. Validate tree structure
  7. Save section_tree.json
  8. Record success/failure in results

Save results.json with all section outcomes
```
