# Agent 3: Commitment Builder

## Role
Generates a "Global Commitment" — a structured contract document that defines the thesis, key takeaways, narrative spine, and slide budget for the presentation. This document is the authoritative guideline that ALL downstream agents must follow.

## Position in Pipeline
- **Phase:** 2 (Narrative Outline Generation)
- **Depends on:** A1 output (workspace/markdown.md)
- **Produces for:** A5 (Slide Planner), A6 (Narrative Critic), A8 (Narrative Judge), A11 (Slide Deck Constructor)
- **LLM Required:** Yes

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| Paper markdown | `workspace/markdown.md` | Plain text (full paper) |
| Presentation duration | User input | Integer (minutes) |
| Target audience | User input | String |

## Prompt Template
- **File:** `prompts/outline/commitment_builder_lite.txt`
- **Format:** Standalone text — data is appended after the prompt template
- **System Message:** `"You are CommitmentBuilder. Output ONLY the Markdown content for commitments.md. Do not wrap in code fences."`

### Prompt Assembly

```
[contents of prompts/outline/commitment_builder_lite.txt]

PAPER MARKDOWN (INPUT 1):
[contents of workspace/markdown.md]

TALK CONSTRAINTS (INPUT 2):
- Presentation length (minutes): {duration}
- Target audience: '{audience}'
```

Note: The prompt template itself has NO template variables — the paper markdown and constraints are simply appended after the template text.

## LLM Call Parameters
- **Temperature:** 0.1 (low creativity, factual extraction)
- **Max tokens:** 4096
- **Expected output length:** 250-500 words of Markdown

## Output Format
Plain Markdown with exactly these 5 required section headings:

```markdown
# commitments.md

## 0) Snapshot
- Title: ...
- Authors: ...
- Venue/year: ...
- One-line gist: ...
- Paper type: ...

## 1) Talk contract
- Target audience: ...
- Assumed prerequisites: ...
- Talk goal: ...
- Presentation length: ...
- Target slide count: ...
- Must-include: ...
- Must-avoid: ...

## 2) Core content
- Thesis: ...
- Key takeaways: ...
- Core contributions: ...
- Out-of-scope: ...

## 3) Narrative spine
1. ...
2. ...
(5-7 ordered steps)

## 4) Section plan (light)
| Section | Purpose | Priority | Suggested slides |
|---------|---------|----------|-----------------|
```

## Output Path
- `workspace/commitments.md`

## Validation Rules
1. Output must contain all 5 section headings: `## 0)` through `## 4)`
2. Must not be empty or less than 100 characters
3. Narrative spine should have 5-7 numbered items
4. Section plan table must be present
5. No hallucinated numbers or results — if unknown, should say "UNKNOWN"

## Error Handling
- If LLM returns empty or malformed output, retry once with lower temperature (0.05)
- If still fails, create a minimal commitment with just the paper title and default structure

## Example Output (abbreviated)

```markdown
# commitments.md

## 0) Snapshot
- Title: ArcDeck: Narrative-Driven Paper-to-Slide Generation
- Authors: Zhang et al.
- Venue/year: [venue]
- One-line gist: Multi-agent system using RST discourse parsing to generate coherent slides from papers

## 1) Talk contract
- Target audience: researchers
- Talk goal: inform
- Presentation length: 20 minutes
- Target slide count: 15-20
- Must-include: RST discourse parsing, commitment-driven approach, ArcBench evaluation
- Must-avoid: implementation details of PDF parsing, template CSS

## 2) Core content
- Thesis: RST discourse relations + global commitment contract produce more coherent slides than flat summarization
- Key takeaways:
  - Discourse-guided slide grouping preserves narrative structure
  - Multi-agent refinement loop (critic/reviser/judge) improves quality
  - ArcBench provides first standardized evaluation for paper-to-slides
...
```
