# Agent 8: Narrative Judge

## Role
Evaluates whether the revised slide plan is "good enough" to proceed to slide generation, or should re-enter the critique-revise loop. The judge is a strict evaluator that primarily checks alignment with the Global Commitment.

## Position in Pipeline
- **Phase:** 2 (Refinement Loop — step 3 of 3)
- **Depends on:** A7 output (revised slides), A3 output (commitments.md), A6 output (critique)
- **Produces for:** Decision: either back to A6 (loop) or forward to A11 (proceed)
- **LLM Required:** Yes
- **Loop:** Called up to 3 times in the refinement cycle

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| Revised slides | `workspace/revised_slides_round_{N}.json` | JSON array |
| Commitment | `workspace/commitments.md` | Markdown |
| Paragraph texts | All `workspace/rst/*/paragraphs.json` merged | JSON dict: id→text |
| Critique | `workspace/critique_round_{N}.json` | JSON (optional) |
| Round number | Internal counter | Integer |

## Preprocessing

### Collect Used Paragraphs
Extract all paragraph IDs referenced in the merged slides, preserving order and deduplicating.

### Build Snippets
For each used paragraph, create a text snippet from the paragraph map.

### Build Section Inventory
Extract unique section keys from slides in order of first appearance.

## Prompt Template
- **File:** `prompts/outline/narrative_judge.txt` (when using commitment)
- **Fallback:** `prompts/outline/narrative_judge_no_commitment.txt`
- **Format:** Python format strings with `{variable}` placeholders
- **System Message:** `"You are a strict evaluator of academic slide plans. Output only valid JSON."`

### Template Variables
| Variable | Source | Description |
|----------|--------|-------------|
| `{audience}` | User input | e.g., "researchers" |
| `{presentation_length}` | User input | e.g., 20 |
| `{commitment_md}` | Contents of commitments.md | Full markdown |
| `{merged_slides_json}` | JSON dump of revised slides | JSON string |
| `{section_inventory}` | JSON array of section keys | JSON string |
| `{paragraph_snippets}` | JSON dict of paragraph texts | JSON string |
| `{commentary_json}` | JSON dump of critique or "null" | From A6 output |
| `{pass_score_threshold}` | Score threshold for passing | Default: 7.5 |

## Evaluation Rubric (from prompt)

The judge evaluates strictly across 6 dimensions:

**A) Commitment Alignment (highest priority)**
- Thesis and key takeaways realized?
- Must-hit beats present and correctly placed?
- Emphasis consistent with commitment priorities?
- Out-of-scope items incorrectly foregrounded?

**B) Global Narrative Flow**
- Follows commitment narrative spine and/or canonical progression?
- Smooth, motivated transitions between sections?
- Each major section prepares audience for the next?

**C) Section Balance and Pacing**
- Time allocated proportionally to importance?
- Any sections overweighted or underdeveloped?

**D) Slide-Level Coherence**
- Each slide expresses a single, focused idea?
- Paragraph groupings internally coherent?

**E) Redundancy, Gaps, Missing Transitions**
- Concepts unnecessarily repeated?
- Missing conceptual bridges?
- Slide titles and ordering signal transitions?

**F) Coverage Sanity**
- No invented paragraph IDs
- Each paragraph used exactly once
- No obvious missing or dangling content

## Output Schema

```json
{
  "decision": "pass",
  "score": 8.2,
  "confidence": 0.85,
  "summary": "3-6 sentence judgement focusing on commitment alignment, narrative flow, coherence, and readiness",
  "must_fix": [
    {
      "severity": "high",
      "issue": "short title",
      "details": "why this issue disrupts commitment alignment, flow, or structure",
      "action": "concrete guidance for the reviser",
      "affected": {
        "slides": [3, 4],
        "sections": ["method"],
        "paragraphs": ["method_2"]
      },
      "commitment_refs": {
        "violated_or_targeted": ["must-hit beat", "thesis/takeaway"],
        "notes": "1-2 bullets referencing commitment items"
      }
    }
  ],
  "green_flags": [
    "Strong introduction setup with clear thesis statement",
    "Good balance between method and results sections"
  ],
  "suggested_next_steps": [
    "Merge slides 3-4 to improve method flow",
    "Add transition slide before experiments"
  ]
}
```

## Decision Logic

```
IF any high-severity must_fix items exist:
    decision = "revise"
ELIF score >= pass_score_threshold (default 7.5):
    decision = "pass"
ELSE:
    decision = "revise"
```

## Output Path
- `workspace/judgement_round_{N}.json`

## Loop Control

After receiving the judge's decision:

```
IF decision == "pass":
    Copy revised_slides_round_{N}.json → workspace/final_outline.json
    EXIT refinement loop → proceed to Phase 6

ELIF round_number >= 2 (max 3 rounds reached):
    Copy revised_slides_round_{N}.json → workspace/final_outline.json
    EXIT refinement loop with warning

ELSE:
    Feed judge feedback to next round:
    - A6 receives current slides for next critique
    - A7 receives judge's must_fix items
    INCREMENT round_number
    CONTINUE loop
```

## Validation Rules
- Output must be valid JSON
- `decision` must be either `"pass"` or `"revise"`
- `score` must be a number between 0 and 10
- `must_fix` must be an array
- Referenced paragraph IDs and slide numbers must exist in the input

## Error Handling
- If LLM returns empty → treat as `decision: "pass"` with score 0 (force proceed)
- If JSON parsing fails → retry once, then force proceed
- Always save the raw LLM response for debugging
