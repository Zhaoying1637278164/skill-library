# Agent 2: Asset Extractor

## Role
Extracts visual assets (figures, tables) and bibliographic references from the PDF paper. Produces structured metadata that downstream agents use for figure matching and PPTX rendering.

## Position in Pipeline
- **Phase:** 1 (Preprocessing)
- **Depends on:** A1 output (markdown.md), original PDF
- **Produces for:** A9 (Image Filter), A10 (Figure Matcher), A11 (Constructor), A13 (Renderer)
- **LLM Required:** No

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| PDF file | User input | File path |
| Paper markdown | workspace/markdown.md | Plain text |

## Execution Steps

### Step 1: Extract Figures
1. Extract all figure images from the PDF
2. Save each as `workspace/figures/image_{N}.png` (numbered from 1)
3. For each image, record metadata:
   - `caption`: Figure caption text (from PDF or nearby text)
   - `page_no`: Page number where figure appears
   - `image_path`: Relative path to saved image file
   - `width`, `height`: Image dimensions in pixels
   - `figure_aspect`: width / height ratio

### Step 2: Extract Tables
1. Identify all tables in the PDF
2. For each table, save a rendered image: `workspace/figures/table_{N}.png`
3. Record metadata:
   - `caption`: Table caption text
   - `page_no`: Page number
   - `table_path`: Relative path to saved table image
   - `width`, `height`: Dimensions

### Step 3: Extract References
1. Find the "References" section in `workspace/markdown.md`
2. Parse into two dictionaries:
   - `numbered`: Maps reference numbers to full citation text
     ```json
     {"1": "Smith et al., Deep Learning...", "2": "Jones, 2023..."}
     ```
   - `citations`: Maps "Author et al., Year" patterns to full text
     ```json
     {"Smith et al., 2022": "Smith et al., Deep Learning..."}
     ```

## Output Schema

### `workspace/images.json`
```json
{
  "image_1": {
    "caption": "Figure 1: System overview...",
    "page_no": 3,
    "image_path": "workspace/figures/image_1.png",
    "width": 800,
    "height": 600,
    "figure_aspect": 1.33
  }
}
```

### `workspace/tables.json`
```json
{
  "table_1": {
    "caption": "Table 1: Comparison results...",
    "page_no": 7,
    "table_path": "workspace/figures/table_1.png",
    "width": 600,
    "height": 400,
    "figure_aspect": 1.5
  }
}
```

### `workspace/references.json`
```json
{
  "numbered": {"1": "full ref text", "2": "full ref text"},
  "citations": {"Author et al., 2023": "full ref text"}
}
```

## Output Paths
- `workspace/figures/image_*.png` — Figure images
- `workspace/figures/table_*.png` — Table images
- `workspace/images.json` — Image metadata
- `workspace/tables.json` — Table metadata
- `workspace/references.json` — Reference dictionary

## Validation
- At least 1 figure or table should be extracted from a typical paper
- All image files referenced in metadata must exist on disk
- References dict should have at least a few entries for a typical paper
- Caption text should not be empty (if it is, mark as "Unknown caption")

## Scripts

```bash
# Step 1-2: Extract figures and tables via Docling (high-res, 10x scale)
python scripts/extract_docling.py <pdf_path> workspace/

# Step 1-2 (post): Clean up artifacts, reclassify misdetected tables, merge split tables, renumber
python scripts/postprocess_figures.py workspace/
```

The postprocess script automatically:
- Skips tiny artifacts (< 100px)
- Moves images whose captions say "Table X" into the tables collection
- Merges consecutive captionless tables on the same page (Docling splits multi-part tables)
- Renumbers everything cleanly as image_1..N, table_1..M

## Notes
- If figure extraction fails, create placeholder metadata with empty captions
- Tables may be extracted as images OR as structured data — images are preferred for slides
- Reference parsing handles both numbered `[1]` and author-year `(Smith et al., 2023)` formats
