# ArcDeck Agent Overview

## The 13 Agents

ArcDeck decomposes paper-to-slides generation into 13 specialized agents across 3 phases. Each agent is described in its own `.md` file that Claude Code reads and executes. The pipeline produces visually rich slides with no text-only pages -- every slide gets either extracted figures or programmatic visual elements (diagrams, flowcharts, comparison boxes, stats callouts, timelines, hierarchies) rendered via PptxGenJS (Node.js).

Agents 10-13 are designed as **Claude Code skill instructions** -- Claude Code acts as the LLM directly, with no external API calls needed for these phases.

### Execution DAG

```
                         +---- PDF ----+
                         |             |
                        [A1]         [A2]
                    Preprocessor   Asset Extractor
                    (Markdown)     (Docling: figures,
                         |          tables, refs)
                    markdown.md        |
                         |             |
                         v             |
                        [A3]           |
                  Commitment Builder   |
                         |             |
                    commitments.md     |
                         |             |
                         v             |
                   +----[A4]----+      |
                   |  Discourse  |     |
                   |   Parser    |     |
                   | (per section)|    |
                   +-----+-------+    |
                         |             |
                    RST Trees          |
                         |             |
                         v             |
                   +----[A5]----+      |
                   |   Slide     |     |
                   |  Planner    |     |
                   |(per section)|     |
                   +-----+-------+    |
                         |             |
                  Draft Slide Outline  |
                         |             |
              +----------+----------+  |
              |  REFINEMENT LOOP    |  |
              |  (max 3 rounds)     |  |
              |                     |  |
              |   +----[A6]----+    |  |
              |   |  Narrative  |    |  |
              |   |   Critic    |    |  |
              |   +-----+-------+   |  |
              |         |           |  |
              |   +----[A7]----+    |  |
              |   |   Slide     |    |  |
              |   |  Reviser    |    |  |
              |   +-----+-------+   |  |
              |         |           |  |
              |   +----[A8]----+    |  |
              |   |  Narrative  |    |  |
              |   |   Judge     |    |  |
              |   +-----+-------+   |  |
              |         |           |  |
              |    pass? --- YES ---+  |
              |         | NO           |
              |         +-- loop ------+
              |                        |
              +----- Final Outline ----+
                         |             |
                         |             v
                         |        +---[A9]----+
                         |        | Image/Table|
                         |        | Filter +   |
                         |        | Gap Detect |
                         |        +-----+------+
                         |              |
                         v              v
                    +----[A10]-------------------+
                    |  Slide Composer             |
                    |  (figure matching + templates|
                    |   + content + visual elements)|
                    +------------+----------------+
                                 |
                            slide_plan.json
                                 |
                    +----[A11]---+----------------+
                    |  Design Critic              |
                    |  (CARP+ aesthetic review)    |
                    +------------+----------------+
                                 |
                          design_critique.json
                                 |
                    +----[A12]---+----------------+
                    |  Design Refiner             |
                    |  (apply fixes + enrich +    |
                    |   format + polish)          |
                    +------------+----------------+
                                 |
                       slide_plan_refined.json
                                 |
                    +----[A13]---+----------------+
                    |  PPTX Builder               |
                    |  (generate_pptx.js via      |
                    |   PptxGenJS, no template)   |
                    +------------+----------------+
                                 |
                            output.pptx
```

### Visual Element Types (Rendered by A13 via PptxGenJS)

All renderers use **rectangles and text only** -- no circles, ovals, or decorative badges.

| Type | Description | Used For |
|------|------------|----------|
| `process_flow` | Large cards with top accent bars, labels + sublabels | Pipelines, methods, stages |
| `cycle` | Cards with arrow indicators showing circular flow | Feedback loops, iterative processes |
| `comparison` | Side-by-side tinted panels with tone-based coloring | Prior vs. proposed, method comparison |
| `stats_callout` | Big-number cards with accent-colored top bars | Dataset stats, key metrics |
| `timeline` | Horizontal sequence of labeled cards | Chronological phases, stages |
| `hierarchy` | Root card with connector lines to child cards | Taxonomies, component breakdowns |
| `matrix` | Grid of categorized cells | 2x2/3x3 categorization |
| `radial` | Central card + satellite cards | Central concept + related ideas |
| `funnel` | Narrowing horizontal bars | Filtering, selection pipelines |
| `stacked_list` | Numbered rows with accent index squares + descriptions | Feature lists, numbered steps |
| `split_panel` | Two contrasting side-by-side panels | Problem vs. solution |
| `before_after` | Left-right contrast panels | Before/after comparison |
| `callout_cards` | Grid of white cards with accent left borders, 13pt labels | Multiple contributions |
| `pyramid` | Layered structure | Hierarchical layers |
| `equation_highlight` | Large centered concept box | Key insight or formula |
| `icon_row` | Row of labeled cards | Capabilities, components |
| `progress_bar` | Segmented progress indicators | Phase progression |
| `banner_quote` | Full-width navy banner with 18pt white bold text | Key finding, thesis |

## Agent Summary Table

| # | Agent | Phase | LLM? | Key Input | Key Output |
|---|-------|-------|------|-----------|------------|
| A1 | PDF Preprocessor | 1 | No | PDF file | markdown.md |
| A2 | Asset Extractor | 1 | No | PDF file (Docling) | images.json, tables.json, references.json |
| A3 | Commitment Builder | 2 | Yes | markdown + constraints | commitments.md |
| A4 | Discourse Parser | 2 | Yes | section paragraphs | RST tree JSON per section |
| A5 | Slide Planner | 2 | Yes | RST tree + paragraphs | slide groupings JSON |
| A6 | Narrative Critic | 2 | Yes | merged slides + commitment | critique JSON |
| A7 | Slide Reviser | 2 | Yes | slides + critique + judge | revised slides JSON |
| A8 | Narrative Judge | 2 | Yes | slides + commitment + critique | judgement JSON |
| A9 | Image/Table Filter | 3 | Yes | raw content + images + tables | filtered visuals + visual gaps |
| A10 | **Slide Composer** | 3 | Yes (Claude) | outline + filtered visuals + commitments + paragraphs | slide_plan.json |
| A11 | **Design Critic** | 3 | Yes (Claude) | slide_plan + commitments | design_critique.json |
| A12 | **Design Refiner** | 3 | Yes (Claude) | slide_plan + critique + paragraphs | slide_plan_refined.json |
| A13 | **PPTX Builder** | 3 | No | refined plan + figures | output.pptx |

## Critical Dependencies

| Agent | Depends On | Produces For |
|-------|-----------|-------------|
| A1 | PDF file | A2, A3, A4 |
| A2 | A1 | A9, A13 |
| A3 | A1 | A5, A6, A8, A10, A11 |
| A4 | A1 | A5, A10, A12 |
| A5 | A3, A4 | A6 |
| A6 | A5/A7, A3 | A7 |
| A7 | A6, A8 | A8 |
| A8 | A7, A3, A6 | A6 (loop) or A10 |
| A9 | A1, A2 | A10 |
| A10 | Final Outline, A9, A3, A4 | A11 |
| A11 | A10, A3 | A12 |
| A12 | A10, A11, A1, A4 | A13 |
| A13 | A12, figure files | output.pptx |

## Aesthetic Pipeline (Agents 10-13)

The aesthetic pipeline uses a **Compose → Critique → Refine → Render** pattern:

1. **A10 (Slide Composer)** holistically creates the slide plan — matching figures, selecting templates, writing content, and designing visual elements in a single pass.
2. **A11 (Design Critic)** reviews the plan using CARP+ design principles (Contrast, Alignment, Repetition, Proximity, Content-Visual Alignment, Variety, Information Design).
3. **A12 (Design Refiner)** applies the critic's fixes, enriches visual elements with paper-specific content, adds LaTeX formatting, and produces the final refined plan.
4. **A13 (PPTX Builder)** renders the plan into a PowerPoint file using `generate_pptx.js` (PptxGenJS) -- a single Node.js script that handles text, images, and visual element diagrams with no template dependency.

This ensures every slide has visual content — either extracted figures/tables or programmatic diagrams — and that the overall design is aesthetically coherent.

## Data Formats Between Agents

All intermediate data uses JSON (except commitments.md which is Markdown and the final output which is .pptx). Each agent's `.md` file specifies exact input/output schemas. Key artifacts:

- `slide_plan.json` — A10 output: templates + content + visual_element specs
- `design_critique.json` — A11 output: scored evaluation with fix instructions
- `slide_plan_refined.json` — A12 output: polished plan ready for rendering
