# Agent 9: Image/Table Filter

## Role
Filters the extracted images and tables from the PDF, keeping only those that are relevant and high-quality for the presentation. Removes irrelevant, decorative, or low-quality visuals. Keeps at most 5 images and 5 tables. Also identifies slides that will need programmatic visual elements (diagrams, infographics) because they lack matching figures.

## Position in Pipeline
- **Phase:** 3 (Slide Generation)
- **Depends on:** A1 output (markdown.md), A2 output (images.json, tables.json), final_outline.json
- **Produces for:** A10 (Figure Matcher), A11 (Slide Deck Constructor)
- **LLM Required:** Yes

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| Raw content | `workspace/markdown.md` or structured outline | JSON/text |
| Image metadata | `workspace/images.json` | JSON dict |
| Table metadata | `workspace/tables.json` | JSON dict |
| Final outline | `workspace/final_outline.json` | JSON (for slide count estimation) |

## Prompt Template
- **File:** `prompts/pipeline/image_table_filter_agent.yaml`
- **Format:** Jinja2 template (`{{ variable }}` syntax)
- **System Message:** From the yaml `system_prompt` field:
  > "You are an assistant that reviews a presentation deck's JSON layout (json_content), along with corresponding image_information and table_information. Your task is to filter out any image or table entries that are irrelevant..."

### Template Variables (Jinja2)
| Variable | Source | Description |
|----------|--------|-------------|
| `{{ json_content }}` | Paper outline / raw content | JSON string of the paper content structure |
| `{{ image_information }}` | Contents of images.json | JSON string of image metadata |
| `{{ table_information }}` | Contents of tables.json | JSON string of table metadata |

### Prompt Assembly
1. Load the yaml file
2. Read `system_prompt` field -> use as system message
3. Read `template` field -> render Jinja2 with the three variables
4. The rendered template becomes the user message

## Filtering Criteria (from prompt)
1. Read through the full paper content described in json_content
2. Examine each image/table entry
3. Decide relevance based on caption alignment with paper topics and sections
4. Keep only "important" entries (relevant to topics/sections/discussions)
5. **Maximum 5 images and 5 tables** in output
6. Prefer high-resolution images (filter out tiny artifacts < 100px)
7. Prefer images with clear captions over unlabeled ones

## Output Schema

```json
{
  "image_information": {
    "image_1": {
      "caption": "Figure 1: System overview showing the three-phase pipeline",
      "page_no": 3,
      "image_path": "workspace/figures/image_1.png",
      "width": 800,
      "height": 600,
      "figure_aspect": 1.33
    }
  },
  "table_information": {
    "table_1": {
      "caption": "Table 1: Evaluation results on ArcBench",
      "page_no": 8,
      "table_path": "workspace/figures/table_1.png",
      "width": 600,
      "height": 400,
      "figure_aspect": 1.5
    }
  },
  "visual_gap_sections": [
    "Related Work",
    "Refinement Loop",
    "Conclusion"
  ]
}
```

The `visual_gap_sections` field identifies paper sections that have no matching images/tables and will need programmatic visual elements in A11.

## Output Paths
- `workspace/images_filtered.json` -- filtered image metadata
- `workspace/tables_filtered.json` -- filtered table metadata

## Validation Rules
- Output must be valid JSON with `image_information` and `table_information` keys
- Each key maps to a dict (may be empty)
- Maximum 5 entries per category
- All referenced image/table files must exist in workspace/figures/
- If output has no entries at all, that's acceptable (paper may have no relevant visuals)

## Error Handling
- If LLM returns non-JSON, try to extract JSON from the response
- If extraction fails, use original unfiltered images/tables (up to 5 each)
- Never fail the pipeline because of filter issues -- fallback to passthrough
