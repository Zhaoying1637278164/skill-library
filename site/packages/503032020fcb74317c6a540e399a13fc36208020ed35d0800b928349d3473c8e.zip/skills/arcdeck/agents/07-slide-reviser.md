# Agent 7: Slide Reviser

## Role
Revises the merged slide plan based on feedback from the Narrative Critic (A6) and, in subsequent rounds, from the Narrative Judge (A8). The reviser may reorder slides, rename titles, move paragraphs between slides, split or merge slides, and adjust section assignments — all while preserving complete paragraph coverage.

## Position in Pipeline
- **Phase:** 2 (Refinement Loop — step 2 of 3)
- **Depends on:** A6 output (critique), A8 output (judge feedback from prior round)
- **Produces for:** A8 (Narrative Judge)
- **LLM Required:** Yes
- **Loop:** Called up to 3 times in the refinement cycle

## Inputs
| Input | Source | Format |
|-------|--------|--------|
| Merged slides | `workspace/merged_slides.json` (round 0) or `workspace/revised_slides_round_{N-1}.json` (later) | JSON array |
| Critique | `workspace/critique_round_{N}.json` | JSON |
| Judge feedback | `workspace/judgement_round_{N-1}.json` (null for round 0) | JSON or null |
| Paragraph texts | All `workspace/rst/*/paragraphs.json` merged | JSON dict: id→text |
| Section titles | From `workspace/rst/results.json` | List of (key, title) tuples |

## Preprocessing

### Format Section Inventory
```
1. introduction : Introduction
2. related_work : Related Work
3. method : Method
...
```

### Format Current Slides
```
- Slide 1 [introduction] Motivation for Narrative-Driven Slides :: ["introduction_0", "introduction_1"]
- Slide 2 [introduction] Key Insight: RST for Structure :: ["introduction_2"]
- Slide 3 [method] System Architecture :: ["method_0", "method_1"]
...
```

### Format Paragraph Snippets
```
[introduction_0] We present ArcDeck, a narrative-driven system for converting...
[introduction_1] Prior work on paper-to-slides conversion has focused on...
[method_0] The system architecture consists of three main phases...
```

## Prompt Template
- **File:** `prompts/outline/slide_reviser.txt`
- **Format:** Python format strings with `{variable}` placeholders
- **System Message:** `"You are an expert at organizing academic content into presentation slides. Output only valid JSON."`

### Template Variables
| Variable | Source | Description |
|----------|--------|-------------|
| `{audience}` | User input | e.g., "researchers" |
| `{presentation_length}` | User input | e.g., 20 |
| `{section_inventory}` | Formatted section list | Numbered list with keys and titles |
| `{current_slides}` | Formatted slide list | One line per slide with section, title, paragraphs |
| `{paragraph_snippets}` | Formatted paragraph texts | [id] text format |
| `{commentary_json}` | JSON dump of critique or "null" | From A6 output |
| `{judge_feedback_json}` | JSON dump of judge feedback or "null" | From A8 output (prior round) |
| `{min_paras}` | Minimum paragraphs per slide | Default: 1 |
| `{max_paras}` | Maximum paragraphs per slide | Default: 5 |

## Feedback Application Rules (from prompt)
1. If judge_feedback_json has `must_fix` items → MUST address ALL of them
2. Then address high-severity issues from judge (flow/coherence/redundancy/pacing)
3. Then address critic's critique
4. If critic and judge conflict → prefer judge unless it clearly harms flow

## Output Schema

```json
{
  "slides": [
    {
      "slide_number": 1,
      "section": "introduction",
      "section_title": "Introduction",
      "title": "Motivation: Why Narrative Matters",
      "paragraphs": ["introduction_0", "introduction_1"],
      "rationale": "Brief explanation of changes made based on critic/judge feedback and why this improves flow"
    }
  ]
}
```

## Output Path
- `workspace/revised_slides_round_{N}.json`

## Hard Constraints
1. Use ONLY paragraph IDs from the input — do NOT invent new IDs
2. Every paragraph ID must appear EXACTLY ONCE across all slides (no omissions, no duplicates)
3. Prefer 1-5 paragraphs per slide (exceptions only for coherence)
4. Output JSON only — no markdown, no commentary

## Post-Processing: Validation and Repair

After receiving the LLM response, validate paragraph coverage:

### Validation
1. Check all paragraph IDs exist in the known set
2. Check no duplicates (each ID appears exactly once)
3. Check no missing paragraphs

### Auto-Repair (if validation fails)
1. **Remove duplicates:** Keep first occurrence of each paragraph ID
2. **Append missing paragraphs:** Add any missing paragraph IDs to the last slide
3. Re-number slides sequentially (1, 2, 3, ...)

### Fill Section Titles
For any slide missing `section_title`, look up the section key in the results.json section title mapping.

## Error Handling
- If LLM returns empty/null → keep current slides unchanged, mark revision as failed
- If JSON parsing fails → try to extract JSON from response, fallback to current slides
- If validation still fails after auto-repair → log errors but proceed with best-effort slides
