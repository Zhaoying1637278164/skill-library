# RST Relation Taxonomy Reference

Rhetorical Structure Theory (RST) defines how discourse units (paragraphs) relate to each other in a hierarchical tree. ArcDeck uses a closed set of 8 relations.

## Two Group Types

### Nucleus-Satellite (type="rst")
One unit (nucleus) is more central; the other (satellite) supports it.
```json
{
  "type": "rst",
  "relation": "elaboration",
  "nucleus": "paragraph_id",
  "satellite": "paragraph_id"
}
```

### Multinuclear (type="multinuc")
Both units have equal importance.
```json
{
  "type": "multinuc",
  "relation": "joint",
  "left": "paragraph_id",
  "right": "paragraph_id"
}
```

## Relation Inventory (Closed Set)

### Nucleus-Satellite Relations

| Relation | Meaning | Example | Slide Implication |
|----------|---------|---------|-------------------|
| `elaboration` | Adds detail, examples, implementation, or extra info to the nucleus | "Method X works by..." followed by "Specifically, step 1..." | Group together on same slide |
| `explanation` | Clarifies why or how something described in the nucleus works | "We use attention..." followed by "This is because attention captures..." | Group together on same slide |
| `context` | Provides background, setting, or definitions needed for the nucleus | "Related work has explored..." followed by "Our approach differs in..." | Introductory content |
| `purpose` | States the explicit goal, aim, or motivation for the nucleus | "We aim to solve X" followed by "To achieve this, we propose..." | Often introductory |
| `evaluation` | Provides judgment, assessment, strength, or limitation | "The model achieves 95%..." followed by "However, it struggles with..." | May deserve its own slide |
| `organization` | Provides a roadmap or meta-structural framing | "This section is organized as follows..." | Topic sentence for the section |

### Multinuclear Relations

| Relation | Meaning | Example | Slide Implication |
|----------|---------|---------|-------------------|
| `joint` | Parallel or list-like points at the same level of importance | "Contribution 1: ..." and "Contribution 2: ..." | Can share a slide |
| `same-unit` | Two adjacent paragraphs that are literally one unit split across boundaries | Split due to formatting, not meaning | Must stay together on same slide |

## Tree Structure Rules

1. **Binary tree:** Each group has exactly 2 children
2. **Rooted:** One root group covers all paragraphs
3. **Complete coverage:** Every paragraph appears exactly once as a leaf
4. **Acyclic:** No cycles — each non-root group is a child exactly once
5. **~N-1 groups:** For N paragraphs, expect approximately N-1 groups

## Slide Grouping Heuristics

Based on the relation type, paragraphs should be grouped as follows:

| Relation | Grouping Rule |
|----------|---------------|
| elaboration | Group nucleus + satellite on same slide |
| explanation | Group nucleus + satellite on same slide |
| joint | Can share slide if ≤4 paragraphs total |
| purpose | Often starts a slide (introductory) |
| context | Often starts a slide (background) |
| evaluation | May warrant its own slide (especially if long) |
| organization | Usually a topic sentence — include with what follows |
| same-unit | MUST stay together (never split across slides) |

## Example Tree

For a section with 5 paragraphs:
```json
{
  "root": "g4",
  "groups": {
    "g1": {
      "type": "rst",
      "relation": "elaboration",
      "nucleus": "method_0",
      "satellite": "method_1"
    },
    "g2": {
      "type": "rst",
      "relation": "explanation",
      "nucleus": "method_2",
      "satellite": "method_3"
    },
    "g3": {
      "type": "multinuc",
      "relation": "joint",
      "left": "g1",
      "right": "g2"
    },
    "g4": {
      "type": "rst",
      "relation": "context",
      "nucleus": "g3",
      "satellite": "method_4"
    }
  }
}
```

This tree suggests:
- Slide 1: method_0 + method_1 (elaboration group)
- Slide 2: method_2 + method_3 (explanation group)
- method_4 provides context — could be introductory or combined
