# Slide Template Types Reference

ArcDeck uses 12 base slide templates (T1-T12) plus 2 derived types (T14, T19), combined with **8 programmatic visual element types** for a total of 20+ unique slide appearances. The PowerPoint canvas is **13.3 in x 7.5 in** (16:9 aspect ratio).

## Template Library

### Text-Only Templates (Enhanced with Visual Elements)

| ID | Name | Description | Visual Enhancement |
|----|------|-------------|-------------------|
| `T1_TextOnly` | Text Only | Full-width title + body text | Always paired with a `visual_element` (diagram, chart, infographic) |
| `T14_2Text` | Two-Column Text | Two text columns side by side | Can have accent sidebar or bottom diagram |

### Single-Image Templates

| ID | Name | Description | Use When |
|----|------|-------------|----------|
| `T2_ImageRight` | Image Right | Text/bullets left, image right | 1 tall/square image (aspect <= 1.0) + <=4 bullets |
| `T3_ImageLeft` | Image Left | Image left, text/bullets right | Mirror of T2 -- alternate with T2 for variety |
| `T4_ImageTop` | Image Top | Wide image spanning top, text below | 1 wide image (aspect >= 1.6) or table |

### Dual-Image Templates

| ID | Name | Description | Use When |
|----|------|-------------|----------|
| `T5_TwoImages2` | Two Images Top | 2 images side-by-side on top, text below | Two images of similar size |
| `T11_ImageRight2` | Two Images Right | 2 images stacked on right, text left | 2 small images + text |
| `T12_ImageLeft2` | Two Images Left | 2 images stacked on left, text right | Mirror of T11 |

### Grid Templates

| ID | Name | Description | Use When |
|----|------|-------------|----------|
| `T6_2x2_TopImage` | 2x2 Top Image | Top: 2 images, bottom: 2 text blocks | 2 images + 2 text explanations |
| `T7_2x2_BottomImage` | 2x2 Bottom Image | Top: 2 text, bottom: 2 images | 2 text + 2 images |
| `T8_2x2_AltTextImg` | 2x2 Alternating | Diagonal layout | Alternating comparison |
| `T9_4Img_2x2Grid` | 4 Images Grid | 4 images in 2x2 grid | Four images to compare |
| `T10_3Img_BottomTextTop` | 3 Images Bottom | Text top, 3 images below | Text + 3 square images |

## Programmatic Visual Elements

These are rendered as python-pptx shapes on top of template layouts, primarily for T1_TextOnly slides. Every text-only slide gets one of these to eliminate plain bullet-only slides.

### Visual Element Types (18 layouts)

| Type | Shape | Best For | Example |
|------|-------|----------|---------|
| `process_flow` | Horizontal rounded boxes + arrows | Pipelines, methods, stages | PDF -> Parse -> Plan -> Render |
| `cycle` | Circular nodes with connecting lines | Iterative processes, feedback loops | Critic -> Judge -> Reviser -> repeat |
| `comparison` | Side-by-side colored boxes with headers | Comparing approaches, prior vs. proposed | Prior Methods vs. ArcDeck |
| `stats_callout` | Row of big-number accent boxes | Dataset stats, key metrics | 994 pairs, 100 curated, 6 venues |
| `timeline` | Horizontal labeled steps | Chronological phases | Phase 1 -> Phase 2 -> Phase 3 |
| `hierarchy` | Top-down tree of boxes + connectors | Taxonomies, breakdowns | RST Relations taxonomy |
| `matrix` | Grid of categorized cells | 2x2/3x3 categorization | Feature comparison grid |
| `radial` | Central node + satellite nodes | Central concept + related ideas | Core algorithm + extensions |
| `funnel` | Narrowing horizontal bars | Filtering, selection pipelines | 1000 papers -> 100 filtered -> 10 selected |
| `stacked_list` | Numbered rows with descriptions | Feature lists, numbered steps | Step-by-step methodology |
| `split_panel` | Two contrasting side-by-side panels | Problem vs. solution | Before/after contrast |
| `before_after` | Left-right contrast panels | Before/after comparison | (alias for split_panel) |
| `callout_cards` | Grid of small cards with accent tops | Multiple contributions | Key contributions list |
| `pyramid` | Layered triangular structure | Hierarchical layers | Abstract -> Concrete layers |
| `equation_highlight` | Large centered concept box | Key insight or formula | (alias for quote_callout) |
| `icon_row` | Row of icon circles + labels | Capabilities, components | (alias for icon_grid) |
| `progress_bar` | Segmented progress indicators | Phase progression | Pipeline completion status |
| `banner_quote` | Quote box with accent sidebar | Key finding, thesis | (alias for quote_callout) |

### Visual Element Selection Guide

```
Content type -> Diagram type:
|-- Sequential steps/pipeline     -> process_flow
|-- Iterative/cyclic process      -> cycle
|-- Comparing methods/systems     -> comparison
|-- Quantitative data/metrics     -> stats_callout
|-- Chronological phases          -> timeline
|-- Categories/taxonomy           -> hierarchy
|-- Central concept + satellites  -> radial
|-- Grid categorization           -> matrix
|-- Filtering/selection           -> funnel
|-- Feature list/numbered steps   -> stacked_list
|-- Problem vs. solution          -> split_panel
|-- Before/after contrast         -> before_after
|-- Multiple contributions        -> callout_cards
|-- Hierarchical layers           -> pyramid
|-- Key formula/core insight      -> equation_highlight
|-- Capabilities/components       -> icon_row
|-- Phase progression             -> progress_bar
|-- Key finding/thesis            -> banner_quote
```

### Visual Element Positioning

| Position | Placement | Works With |
|----------|-----------|-----------|
| `bottom` | Below text body (y=5.0in to 6.5in) | T1_TextOnly, T14_2Text |
| `right` | Beside text (x=8.5in to 12.5in) | T1_TextOnly |
| `full` | Uses all available empty space | T1_TextOnly |

### Color System

5 rotating palettes ensure visual variety across slides:

```
Palette 1 (Blue):   primary=#2B5FA6, secondary=#4A90D9, light=#EBF0F9
Palette 2 (Teal):   primary=#0D7377, secondary=#14A3A8, light=#E6F5F5
Palette 3 (Purple): primary=#6B3FA0, secondary=#9B6FD0, light=#F0EBF9
Palette 4 (Amber):  primary=#B8860B, secondary=#DAA520, light=#FDF5E6
Palette 5 (Rose):   primary=#C2185B, secondary=#E91E63, light=#FCE4EC
```

Additional constants:
```
ACCENT_RED  = #E84D4D  (Highlights, warnings)
ACCENT_GREEN = #2EA05F (Positive results)
GRAY        = #9E9E9E  (Neutral/baseline)
DARK_TEXT   = #2D3A4A  (Text on light backgrounds)
```

For `comparison` type, item `tone` field controls color:
- `"positive"` -> palette primary (blue by default) -- proposed/better
- `"negative"` -> gray -- prior/baseline/limitation
- `"neutral"` -> palette secondary -- neutral/equal

### Visual Element Item Rules

| Rule | Constraint |
|------|-----------|
| Item count | 3-5 items (max 6 for icon_row/callout_cards) |
| Label length | 1-3 words, paper-specific terminology |
| Sublabel length | 1-8 words, concrete detail |
| stats_callout sublabel | Actual number from paper (e.g., "994", "7.5%") |
| comparison tone | Required: "positive", "negative", or "neutral" |
| hierarchy children | Array of child labels |

## CARP+ Design Principles

The aesthetic pipeline (Agents 11-12) evaluates slide plans using these principles:

| Principle | Weight | What to Check |
|-----------|--------|---------------|
| **Contrast** | 15% | Visual elements stand out, variety between adjacent slides |
| **Alignment** | 10% | Template choices consistent within sections, visual types match content |
| **Repetition** | 10% | Consistent visual language, predictable section patterns |
| **Proximity** | 15% | Related items grouped, balanced information density (3-5 items) |
| **Content-Visual Alignment** | 25% | Paper-specific labels, real numbers, correct diagram types |
| **Variety** | 15% | No consecutive same template/layout, 4+ unique layouts in deck |
| **Information Design** | 10% | Right diagram for right content type |

## Template Selection Decision Tree

```
Has images or tables?
|-- NO -> T1_TextOnly + visual_element (ALWAYS)
|         (auto-pair consecutive T1s into T14_2Text)
|
+-- YES -> How many visuals?
          |-- 1 visual
          |   |-- Wide (aspect >= 1.6)? -> T4_ImageTop
          |   +-- Tall/Square (aspect <= 1.0)? -> T2 or T3
          |       (alternate for variety)
          |
          |-- 2 visuals
          |   |-- Both small? -> T11 or T12
          |   |-- Both similar? -> T5_TwoImages2
          |   +-- Need comparison? -> T6/T7/T8
          |
          |-- 3 visuals -> T10_3Img_BottomTextTop
          |
          +-- 4 visuals -> T9_4Img_2x2Grid
```

## Visual Element Selection Guide

```
Content type -> Diagram type:
|-- Sequential steps/pipeline -> process_flow
|-- Iterative/cyclic process -> cycle
|-- Comparing methods/systems -> comparison
|-- Quantitative data/metrics -> stats_callout
|-- Chronological phases -> timeline
|-- Categories/taxonomy -> hierarchy
|-- Feature list/capabilities -> icon_grid
|-- Key finding/contribution -> quote_callout
```

## Content Constraints per Template

| Template | Max Bullets | Max Images | Max Tables | Visual Element |
|----------|------------|-----------|-----------|---------------|
| T1 | 5 | 0 | 0 | Required |
| T2 | 4 | 1 | 0 | None |
| T3 | 4 | 1 | 0 | None |
| T4 | 5 | 1 | 1 | None |
| T5 | 4 | 2 | 0 | None |
| T6 | 2 blocks | 2 | 0 | None |
| T7 | 2 blocks | 2 | 0 | None |
| T8 | 2 blocks | 2 | 0 | None |
| T9 | 0 | 4 | 0 | None |
| T10 | 1 block | 3 | 0 | None |
| T11 | 4 | 2 | 0 | None |
| T12 | 4 | 2 | 0 | None |
| T14 | 2 columns | 0 | 0 | Optional (accent sidebar) |

## T1->T14 Auto-Pairing

When two consecutive slides both use `T1_TextOnly` in the same section:
1. Merge them into a single `T14_2Text` slide
2. Left column: content from first slide
3. Right column: content from second slide
4. Title: combined or from first slide
5. Visual elements from both slides are combined or the more impactful one is kept

## Font Size Defaults

| Element | Size |
|---------|------|
| Slide title | 24pt |
| Top-level bullets | 18pt |
| Sub-bullets | 14pt |
| Paragraph text | 16pt |
| Reference citations | 10pt |
| Visual element labels | 9-11pt |
| Visual element sublabels | 8-9pt |
| Stats callout numbers | 24pt |
| Stats callout labels | 9pt |
