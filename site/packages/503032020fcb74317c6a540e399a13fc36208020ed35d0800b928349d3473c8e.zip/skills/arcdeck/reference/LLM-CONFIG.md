# LLM Configuration Reference

## Supported Providers

ArcDeck agents that require LLM calls support three providers:

### OpenAI (default)
```
Provider: openai
Models: gpt-4o (default), gpt-4o-mini, gpt-5
API Key: OPENAI_API_KEY environment variable
Base URL: https://api.openai.com/v1 (default)
```

### Anthropic
```
Provider: anthropic
Models: claude-sonnet-4-6, claude-opus-4-6
API Key: ANTHROPIC_API_KEY environment variable
```

### vLLM (self-hosted)
```
Provider: vllm
Models: any model served by vLLM
API Key: not required (local server)
Base URL: http://127.0.0.1:8000/v1 (default)
```

## Default Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| temperature | 0.1 | Low creativity — factual extraction tasks |
| max_tokens | 4096 | Sufficient for all agent outputs |

## Per-Agent Settings

Most agents use the same model and temperature. Exceptions:

| Agent | Notes |
|-------|-------|
| A3 (Commitment Builder) | Uses system message specific to commitment format |
| A4 (Discourse Parser) | May benefit from higher max_tokens for complex sections |
| A11 (Constructor) | Needs high max_tokens (~8K) for full slide plan output |
| A12 (Refiner) | Needs high max_tokens (~8K) for refined plan output |

## System Messages

Each agent has a specific system message. These are defined in the agent .md files:

| Agent | System Message |
|-------|---------------|
| A3 | "You are CommitmentBuilder. Output ONLY the Markdown content for commitments.md. Do not wrap in code fences." |
| A4 | "You are an expert RST discourse parser. Output only valid RS3 XML." |
| A5, A7 | "You are an expert at organizing academic content into presentation slides. Output only valid JSON." |
| A6 | "You are a meticulous academic presentation reviewer. Output only valid JSON." |
| A8 | "You are a strict evaluator of academic slide plans. Output only valid JSON." |
| A9-A12, A14 | Defined in their respective YAML prompt files under `system_prompt` |

## JSON Extraction from LLM Responses

LLM responses often contain JSON wrapped in code fences or with surrounding text. Extract JSON using these strategies:

1. **Code fences first:** Look for ` ```json ... ``` ` blocks
2. **Raw JSON:** Look for `{ ... }` starting from the first `{` to the last `}`
3. **Fallback:** Try parsing the entire response as JSON

## Token Budget Estimates

| Agent | Input Tokens | Output Tokens | Total Cost (GPT-4o) |
|-------|-------------|---------------|---------------------|
| A3 | 5K-10K | 500-1K | ~$0.02 |
| A4 (×N sections) | 2K-5K | 500-1.5K | ~$0.01/section |
| A5 (×N sections) | 3K-8K | 1K-3K | ~$0.02/section |
| A6 | 5K-12K | 1K-2K | ~$0.03 |
| A7 | 5K-12K | 2K-4K | ~$0.03 |
| A8 | 5K-12K | 500-1.5K | ~$0.02 |
| A9 | 3K-8K | 500-1K | ~$0.01 |
| A10 | 3K-8K | 1K-2K | ~$0.02 |
| A11 | 10K-20K | 3K-6K | ~$0.05 |
| A12 | 10K-20K | 3K-6K | ~$0.05 |
| A14 | 8K-15K | 2K-4K | ~$0.04 |
| **Total** | **~80K-200K** | **~20K-45K** | **$0.10-$0.35** |
