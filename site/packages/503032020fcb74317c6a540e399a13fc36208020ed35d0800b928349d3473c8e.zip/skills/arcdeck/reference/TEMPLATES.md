# Template Visual Guide

## PowerPoint Template Themes

ArcDeck supports 8 visual themes for the base PPTX template. Each theme defines color schemes, fonts, and master slide layouts.

### Theme Selection
| Theme | Style | Best For |
|-------|-------|----------|
| 1 (default) | Clean, professional blue | General academic talks |
| 2 | Dark with accent colors | Technical/engineering talks |
| 3 | Light minimal | Design-focused presentations |
| 4 | Corporate blue-gray | Industry presentations |
| 5 | Warm tones | Social science / humanities |
| 6 | High contrast | Large venue presentations |
| 7 | Modern gradient | Startup / pitch presentations |
| 8 | Classic academic | Traditional conference talks |

### Template Contents
Each theme PPTX contains:
- Title slide layout
- Section header layout
- 12 content layouts (T1-T12 matching the template IDs)
- Reference/bibliography slide layout
- Blank slide layout

## Layout Previews

### T1_TextOnly
```
┌─────────────────────────┐
│  Title                  │
├─────────────────────────┤
│                         │
│  • Bullet point 1       │
│    - Sub-bullet          │
│  • Bullet point 2       │
│  • Bullet point 3       │
│                         │
└─────────────────────────┘
```

### T2_ImageRight
```
┌─────────────────────────┐
│  Title                  │
├──────────────┬──────────┤
│              │          │
│  • Bullet 1  │  ┌────┐  │
│  • Bullet 2  │  │IMG │  │
│  • Bullet 3  │  └────┘  │
│              │          │
└──────────────┴──────────┘
```

### T3_ImageLeft
```
┌─────────────────────────┐
│  Title                  │
├──────────┬──────────────┤
│          │              │
│  ┌────┐  │  • Bullet 1  │
│  │IMG │  │  • Bullet 2  │
│  └────┘  │  • Bullet 3  │
│          │              │
└──────────┴──────────────┘
```

### T4_ImageTop
```
┌─────────────────────────┐
│  Title                  │
├─────────────────────────┤
│  ┌───────────────────┐  │
│  │    WIDE IMAGE      │  │
│  └───────────────────┘  │
│  • Bullet 1  • Bullet 2 │
└─────────────────────────┘
```

### T5_TwoImages2
```
┌─────────────────────────┐
│  Title                  │
├────────────┬────────────┤
│  ┌──────┐  │  ┌──────┐  │
│  │ IMG1 │  │  │ IMG2 │  │
│  └──────┘  │  └──────┘  │
├────────────┴────────────┤
│  Text content below     │
└─────────────────────────┘
```

### T14_2Text (auto-paired)
```
┌─────────────────────────┐
│  Title                  │
├────────────┬────────────┤
│            │            │
│  • Bullet  │  • Bullet  │
│  • Bullet  │  • Bullet  │
│  • Bullet  │  • Bullet  │
│            │            │
└────────────┴────────────┘
```

## Font Specifications

| Element | Size | Weight |
|---------|------|--------|
| Slide title | 24pt | Bold |
| Top-level bullets | 18pt | Regular |
| Sub-bullets | 14pt | Regular |
| Paragraph text | 16pt | Regular |
| References | 10pt | Regular |
| Slide numbers | 8pt | Regular |
