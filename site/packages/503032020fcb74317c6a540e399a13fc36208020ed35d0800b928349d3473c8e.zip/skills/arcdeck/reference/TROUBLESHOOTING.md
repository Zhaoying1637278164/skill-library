# Troubleshooting Guide

## Common Issues

### Phase 1: PDF Preprocessing

**Problem:** PDF extraction returns very short text (< 500 chars)
- **Cause:** PDF may be scanned/image-based, or has unusual encoding
- **Fix:** Try an alternative PDF extraction method. OCR-based extraction may be needed for scanned papers.

**Problem:** No figures extracted
- **Cause:** Figures may be embedded as vector graphics or non-standard format
- **Fix:** Check if the PDF has extractable images. May need to screenshot pages and crop manually.

### Phase 2: Commitment Building

**Problem:** Commitment output missing required sections
- **Cause:** LLM may not follow the exact heading structure
- **Fix:** Re-run with a reminder to include all 5 sections (0-4). Check that the prompt template was loaded correctly.

**Problem:** Commitment contains hallucinated numbers/results
- **Cause:** LLM generating plausible-sounding but false claims
- **Fix:** Verify all numbers against the source paper. The prompt explicitly says "Do NOT invent facts or numbers."

### Phase 3: Discourse Parsing

**Problem:** RST tree validation fails
- **Cause:** LLM may produce invalid tree structure (cycles, missing paragraphs, wrong relation types)
- **Fix:**
  1. Retry the LLM call (often fixes on second attempt)
  2. If still failing, create a simple linear tree: chain paragraphs with `joint` relations
  3. Check that paragraph names match exactly (case-sensitive)

**Problem:** Section has too few paragraphs for RST parsing
- **Cause:** Some sections may have only 1 paragraph after splitting
- **Fix:** Sections with < 2 paragraphs are skipped for RST. Create a trivial single-paragraph "tree."

### Phase 4: Slide Planning

**Problem:** Too many or too few slides generated
- **Cause:** LLM may not follow the slide_hint guidance
- **Fix:** Adjust the slide_hint in the prompt. Rule of thumb: ~3 paragraphs per slide. You can also set min/max slides per section.

**Problem:** Paragraphs missing from slide assignments
- **Cause:** LLM dropped some paragraph IDs
- **Fix:** Auto-repair by appending missing paragraphs to the last slide. Run validation after each section.

### Phase 5: Refinement Loop

**Problem:** Judge never passes (stuck in loop)
- **Cause:** Judge's pass threshold (7.5) may be too strict for the content
- **Fix:** The loop is capped at 3 rounds. After 3 rounds, proceed anyway with the best available plan.

**Problem:** Critic and judge give contradictory feedback
- **Cause:** Different evaluation perspectives
- **Fix:** The reviser prompt specifies: "If critic and judge conflict, prefer the judge." This is by design.

**Problem:** Paragraphs get duplicated or lost during revision
- **Cause:** LLM makes errors in paragraph ID handling
- **Fix:** Auto-repair is applied after each revision: remove duplicates (keep first), append missing to last slide.

### Phase 6: Visual Processing

**Problem:** No images pass the filter
- **Cause:** Image captions don't match paper content well enough
- **Fix:** If all images are filtered out, fall back to using the original unfiltered set (up to 5).

**Problem:** Figure matcher assigns wrong images to sections
- **Cause:** Captions may be ambiguous or missing
- **Fix:** Run the caption fixer sub-agent first, then re-run figure matching.

### Phase 7-8: Slide Construction & Refinement

**Problem:** Invalid template_id in slide plan
- **Cause:** LLM generated a template name not in the valid set
- **Fix:** Default to `T1_TextOnly` for any invalid template_id.

**Problem:** Hallucinated image filenames
- **Cause:** LLM referenced images that don't exist
- **Fix:** Remove any referenced file that doesn't exist on disk, change template to `T1_TextOnly`.

**Problem:** Both bullets AND paragraph filled for a slide
- **Cause:** LLM violated the mutually exclusive rule
- **Fix:** Keep whichever is non-empty. If both present, keep bullets and clear paragraph.

**Problem:** Fewer than 3 bullets on a slide
- **Cause:** LLM generated insufficient content
- **Fix:** The refiner (A12) should add bullets from raw_content. If still <3 after refining, it's acceptable for very short subsections.

### Phase 9: PPTX Rendering

**Problem:** PPTX file is empty or corrupted
- **Cause:** Template PPTX may be missing or layout names don't match
- **Fix:** Ensure the template PPTX exists and has all required layouts. Check that python-pptx or PptxGenJS is installed.

**Problem:** Images not appearing in slides
- **Cause:** File paths in slide plan don't match actual file locations
- **Fix:** Verify all image paths resolve correctly. May need to adjust relative vs absolute paths.

**Problem:** LaTeX formatting showing as raw text
- **Cause:** LaTeX not being parsed during rendering
- **Fix:** The renderer must parse `\textbf{}`, `\textcolor{blue}{}`, `\textcolor{red}{}` and convert to PowerPoint formatting. All other LaTeX should be stripped.

## General Tips

1. **Save all intermediate files** — enables debugging at any pipeline step
2. **Check the LLM raw response** — saved as `*_raw_response.txt` files
3. **Verify JSON structure** — most errors come from malformed JSON in LLM responses
4. **Paragraph ID consistency** — IDs must match exactly across all agents (case-sensitive, underscore-separated)
5. **Token limits** — if responses are truncated, increase max_tokens for that agent
6. **Rate limiting** — if making many LLM calls (N sections × multiple agents), consider adding delays

## Re-running Individual Phases

You can re-run any phase independently if its inputs are available:
- Phase 2 (Commitment): Only needs `workspace/markdown.md`
- Phase 3 (Discourse): Only needs `workspace/markdown.md`
- Phase 5 (Refinement): Needs `workspace/merged_slides.json` + `workspace/commitments.md` + paragraph files
- Phase 7 (Construction): Needs `workspace/final_outline.json` + figure mapping + commitment
- Phase 8 (Refinement): Needs `workspace/slide_plan.json` + raw content
