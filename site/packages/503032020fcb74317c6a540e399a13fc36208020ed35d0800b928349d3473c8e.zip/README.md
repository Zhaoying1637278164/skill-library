# ArcDeck — Claude Code Plugin

Convert academic PDF papers into polished, narrative-driven PowerPoint presentations using 13 specialized AI agents orchestrated by Claude Code.

Based on Rhetorical Structure Theory (RST) discourse parsing with a multi-agent critique-revise-judge refinement loop and CARP+ aesthetic design principles. Every slide is visually rich — text-only slides get programmatic diagrams and charts rendered via PptxGenJS (Node.js).

**Paper:** [Narrative-Driven Paper-to-Slide Generation via ArcDeck](https://arxiv.org/abs/2604.11969)

**Official Website:** https://arcdeck.org

**Official GitHub Repository:** https://github.com/RehgLab/ArcDeck

## Installation

### From Plugin Directory

```bash
claude --plugin-dir ./
```

### From Marketplace

```
/plugins install arcdeck
```

## Usage

Once installed, invoke the skill:

```
/arcdeck:arcdeck paper.pdf
```

### Full Options

```
/arcdeck:arcdeck paper.pdf --audience researchers --duration 20 --template ocean --speaker-notes
```

### Arguments

| Argument | Description | Default |
|----------|-------------|---------|
| `<pdf_path>` | Path to the input PDF paper | *(required)* |
| `--audience <type>` | Target audience: `researchers`, `students`, `industry`, `general` | `researchers` |
| `--duration <minutes>` | Target talk length in minutes | `20` |
| `--template <theme>` | Presentation theme: `ocean`, `minimal`, `dark`, `warm` | `ocean` |
| `--speaker-notes` | Generate speaker notes for each slide | off |

### Presentation Themes

| Theme | Style | Colors |
|-------|-------|--------|
| `ocean` | Ocean Gradient — navy/teal/cyan | `#065A82` `#1C7293` `#0891B2` |
| `minimal` | Clean Minimal — white/coral accent | `#E63946` `#457B9D` `#2A9D8F` |
| `dark` | Dark Mode — charcoal/violet accent | `#7F5AF0` `#2CB67D` `#FF6B6B` |
| `warm` | Warm Academic — cream/terracotta | `#C45B3E` `#5B8A72` `#D4A84B` |

## Prerequisites

- **Python 3.10+** with `docling` installed (PDF extraction)
- **Node.js 18+** with `pptxgenjs` (PPTX rendering)
- **LLM API key**: `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` set in environment

Install Python dependencies:
```bash
pip install docling Pillow
```

Node.js dependency is installed automatically in the workspace during execution.

## How It Works

ArcDeck runs a 13-agent pipeline across 9 phases:

| Phase | Agents | Purpose |
|-------|--------|---------|
| 0 | — | Setup & user input |
| 1 | A1-A2 | PDF preprocessing & asset extraction (Docling) |
| 2 | A3 | Commitment building (global narrative contract) |
| 3 | A4 | RST discourse parsing (per-section) |
| 4 | A5 | Slide planning (RST-guided grouping) |
| 5 | A6-A8 | Narrative refinement loop (critique-revise-judge, up to 3 rounds) |
| 6 | A9-A10 | Visual asset filtering & slide composition |
| 7 | A11-A12 | Aesthetic critique-refine (CARP+ design principles) |
| 8 | A13 | PPTX assembly via PptxGenJS |

Agents A10-A13 are **Claude Code native** — Claude Code acts as the LLM directly with no external API calls.

## Plugin Structure

```
arcdeck-plugin/
├── .claude-plugin/
│   └── plugin.json              # Plugin manifest
├── skills/
│   └── arcdeck/
│       ├── SKILL.md             # Main skill definition
│       ├── agents/              # 13 agent specifications (A1-A13)
│       ├── prompts/             # Prompt templates (outline + pipeline)
│       ├── reference/           # Reference docs (RST, templates, troubleshooting)
│       └── scripts/             # Pipeline scripts (Python + Node.js)
└── README.md
```

## Output

Generated files are saved under `workspace/` in the current directory:

| File | Description |
|------|-------------|
| `workspace/output.pptx` | Final PowerPoint presentation |
| `workspace/speaker_notes.json` | Speaker notes (if requested) |
| `workspace/slide_plan_refined.json` | Final slide plan (JSON) |
| `workspace/figures/` | Extracted figures and tables |

## Citation

```bibtex
@article{ozden2026arcdeck,
  title     = {Narrative-Driven Paper-to-Slide Generation via ArcDeck},
  author    = {Ozden, Tarik Can and VS, Sachidanand and Horoz, Furkan
               and Kara, Ozgur and Kim, Junho and Rehg, James M.},
  journal   = {arXiv preprint arXiv:2604.11969},
  year      = {2026}
}
```

## License

MIT

## Contact

For feedback, improvements, or support: tozden2@illinois.edu
