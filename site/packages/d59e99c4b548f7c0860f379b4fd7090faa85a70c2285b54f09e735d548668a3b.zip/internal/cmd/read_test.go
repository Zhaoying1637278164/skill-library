package cmd

import (
	"bytes"
	"encoding/json/v2"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/178inaba/cflio/internal/pageref"
	"github.com/178inaba/cflio/internal/sidecar"
)

// pageResponse renders a GET /pages/{id} body with the given storage value.
func pageResponse(t *testing.T, body, webui string) string {
	t.Helper()

	payload, err := json.Marshal(map[string]any{
		"id":      "123456",
		"status":  "current",
		"title":   "Some Page",
		"version": map[string]any{"number": 7},
		"body":    map[string]any{"storage": map[string]any{"representation": "storage", "value": body}},
		"_links":  map[string]any{"webui": webui},
	})
	if err != nil {
		t.Fatalf("Marshal() error = %v", err)
	}
	return string(payload)
}

// runRead runs `read`, leaving --output off when outPath is empty so the
// default naming is exercised.
func runRead(t *testing.T, arg, outPath string, extra ...string) (cflioRun, error) {
	t.Helper()

	args := []string{"read"}
	if outPath != "" {
		args = append(args, "--output", outPath)
	}
	args = append(args, extra...)
	return runCflio(t, append(args, arg)...)
}

func TestReadWritesTheBodyByteForByte(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	// No trailing newline, entities left encoded, a macro intact: the file
	// has to match the API's bytes exactly or the round-trip is not lossless.
	body := `<p>a &amp; b &lt;c&gt;</p><ac:structured-macro ac:name="info"><ac:rich-text-body><p>note</p></ac:rich-text-body></ac:structured-macro>`

	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		if got := r.URL.Query().Get("body-format"); got != "storage" {
			t.Errorf("body-format = %q, want storage", got)
		}
		_, _ = w.Write([]byte(pageResponse(t, body, testPageWebUI)))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	run, err := runRead(t, testPageURL, path)
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	written, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	if string(written) != body {
		t.Errorf("file = %q, want it byte-identical to the API's body %q", written, body)
	}
	if strings.Contains(run.stdout, "&amp;") || strings.Contains(run.stdout, "structured-macro") {
		t.Errorf("output = %q, want the body kept off stdout", run.stdout)
	}
	for _, want := range []string{"Some Page", "7", path, sidecar.Path(path)} {
		if !strings.Contains(run.stdout, want) {
			t.Errorf("output = %q, want it to mention %q", run.stdout, want)
		}
	}
}

func TestReadWritesTheSidecar(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", testPageWebUI)))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	if _, err := runRead(t, testPageURL, path); err != nil {
		t.Fatalf("read error = %v", err)
	}

	meta, err := sidecar.Load(path)
	if err != nil {
		t.Fatalf("sidecar.Load() error = %v", err)
	}
	want := sidecar.Meta{
		PageID:  "123456",
		Version: 7,
		Title:   "Some Page",
		Status:  "current",
		PageURL: testPageURL,
	}
	// Subtype is a pointer, so comparing the structs would compare addresses.
	// That it is recorded at all is the part that matters here; the values it
	// takes are TestReadRecordsThePageSubtype's.
	if meta.Subtype == nil {
		t.Error("sidecar records no subtype")
	}
	meta.Subtype = nil
	if meta != want {
		t.Errorf("sidecar = %+v, want %+v", meta, want)
	}
}

func TestReadByPageIDStillProducesAnUpdatableSidecar(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", testPageWebUI)))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	if _, err := runRead(t, "123456", path); err != nil {
		t.Fatalf("read error = %v", err)
	}

	meta, err := sidecar.Load(path)
	if err != nil {
		t.Fatalf("sidecar.Load() error = %v", err)
	}
	// The URL is what `update` resolves a profile from, so an ID-only read
	// still has to produce one.
	if meta.PageURL != testPageURL {
		t.Errorf("page_url = %q, want it built from the profile site and the API link", meta.PageURL)
	}
}

func TestReadFallsBackWhenTheAPIReturnsNoWebLink(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", "")))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	if _, err := runRead(t, "123456", path); err != nil {
		t.Fatalf("read error = %v", err)
	}

	meta, err := sidecar.Load(path)
	if err != nil {
		t.Fatalf("sidecar.Load() error = %v", err)
	}
	want := testSite + "/pages/viewpage.action?pageId=123456"
	if meta.PageURL != want {
		t.Errorf("page_url = %q, want the page-id fallback %q", meta.PageURL, want)
	}
}

func TestReadDefaultsTheOutputPathToThePageID(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", testPageWebUI)))
	})

	dir := t.TempDir()
	t.Chdir(dir)

	if _, err := runRead(t, "123456", ""); err != nil {
		t.Fatalf("read error = %v", err)
	}
	if _, err := os.Stat(filepath.Join(dir, "123456.xml")); err != nil {
		t.Errorf("Stat(123456.xml) error = %v, want the default output file", err)
	}
}

func TestReadJSONOutputCarriesMetadataNotTheBody(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>secret body</p>", testPageWebUI)))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	run, err := runRead(t, testPageURL, path, "--format", "json")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal([]byte(run.stdout), &got); err != nil {
		t.Fatalf("Unmarshal(output) error = %v; output = %q", err, run.stdout)
	}
	if got["title"] != "Some Page" || got["page_id"] != "123456" {
		t.Errorf("output = %v, want the page metadata", got)
	}
	if strings.Contains(run.stdout, "secret body") {
		t.Errorf("output = %q, want the body kept off stdout", run.stdout)
	}
}

func TestReadRejectsUnrecognizedArguments(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, neverCalled(t, "for an unparseable argument"))

	// A short link whose token is too long to decode; the ones that do are
	// TestReadResolvesAShortLink's.
	if _, err := runRead(t, "https://example.atlassian.net/wiki/x/AbCdEfGhIjKlM", ""); err == nil {
		t.Fatal("read error = nil, want an error for a short link")
	}
}

func TestReadResolvesAShortLink(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		// QOIB encodes 123456, so the decoded ID has to reach the request.
		if want := "/api/v2/pages/123456"; !strings.HasSuffix(r.URL.Path, want) {
			t.Errorf("request path = %q, want it to end with %q", r.URL.Path, want)
		}
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", testPageWebUI)))
	})

	// Reaching the API at all means the host in the short link selected the
	// profile, exactly as a full page URL's would.
	path := filepath.Join(t.TempDir(), "page.xml")
	if _, err := runRead(t, "https://example.atlassian.net/wiki/x/QOIB", path); err != nil {
		t.Fatalf("read error = %v", err)
	}
}

func TestReadFromAnUnregisteredSiteNamesTheHost(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, neverCalled(t, "for an unregistered site"))

	_, err := runRead(t, "https://unknown.atlassian.net/wiki/spaces/DEV/pages/1/T", "")
	if err == nil {
		t.Fatal("read error = nil, want an error")
	}
	for _, want := range []string{"unknown.atlassian.net", "example", "cflio auth login"} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("error = %q, want it to contain %q", err, want)
		}
	}
}

func TestReadDropsAStaleSidecarBeforeWritingTheBody(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	// A sidecar from a previous read of a different page. If it survived a
	// failed read of page 123456, the file would hold one page's body next
	// to another page's metadata, and `update` would write it to the wrong
	// page.
	path := filepath.Join(t.TempDir(), "page.xml")
	stale := sidecar.Meta{
		PageID:  "999",
		Version: 3,
		Title:   "Some Other Page",
		Status:  "current",
		PageURL: testSite + "/spaces/DEV/pages/999/Other",
	}
	if err := sidecar.Write(path, stale); err != nil {
		t.Fatalf("sidecar.Write() error = %v", err)
	}

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>new</p>", testPageWebUI)))
	})

	if _, err := runRead(t, "123456", path); err != nil {
		t.Fatalf("read error = %v", err)
	}

	meta, err := sidecar.Load(path)
	if err != nil {
		t.Fatalf("sidecar.Load() error = %v", err)
	}
	if meta.PageID != "123456" {
		t.Errorf("sidecar page_id = %q, want the newly read page", meta.PageID)
	}
}

func TestReadMarkdownConvertsTheBodyAndWritesNoSidecar(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	body := `<h1>Release notes</h1><p>Ping <ac:link><ri:user ri:account-id="acc-123"/></ac:link>.</p>`

	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == bulkUsersPath {
			// The mention resolves to nothing, so the rendering below is the
			// fallback one.
			_, _ = w.Write([]byte(`{"results":[]}`))
			return
		}
		// The conversion itself is local: the page request still asks for the
		// storage representation, whatever the reference lookups do.
		if got := r.URL.Query().Get("body-format"); got != "storage" {
			t.Errorf("body-format = %q, want storage", got)
		}
		_, _ = w.Write([]byte(pageResponse(t, body, testPageWebUI)))
	})

	path := filepath.Join(t.TempDir(), "page.md")
	run, err := runRead(t, testPageURL, path, "--markdown")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	written, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	want := "# Release notes\n\nPing @acc-123.\n"
	if string(written) != want {
		t.Errorf("file = %q, want the converted Markdown %q", written, want)
	}

	// No sidecar means `update` refuses the file, which is the only thing
	// keeping a converted body from being written back over the page.
	if _, err := os.Stat(sidecar.Path(path)); !os.IsNotExist(err) {
		t.Errorf("Stat(%s) = %v, want no sidecar in Markdown mode", sidecar.Path(path), err)
	}
	if strings.Contains(run.stdout, "Sidecar:") {
		t.Errorf("output = %q, want no sidecar line", run.stdout)
	}
	if !strings.Contains(run.stdout, fmt.Sprintf("%d bytes", len(written))) {
		t.Errorf("output = %q, want it to count the %d converted bytes", run.stdout, len(written))
	}
}

// The paths the reference lookups hit. The client is built against a /wiki
// base, so the test server sees them prefixed.
const (
	bulkUsersPath = "/wiki/rest/api/user/bulk"
	searchPath    = "/wiki/rest/api/search"
)

// referencesBody names a person and two pages: one in another space, one in
// this page's own space, which storage writes without a space key.
const referencesBody = `<p>Ping <ac:link><ri:user ri:account-id="acc-1"/></ac:link>, ` +
	`see <ac:link><ri:page ri:space-key="OPS" ri:content-title="Runbook"/></ac:link> ` +
	`and <ac:link><ri:page ri:content-title="Onboarding"/></ac:link>.</p>`

func TestReadMarkdownResolvesMentionsAndPageLinks(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	var searchedCQL []string
	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case bulkUsersPath:
			_, _ = w.Write([]byte(`{"results":[{"accountId":"acc-1","displayName":"Ada Lovelace"}]}`))
		case searchPath:
			cql := r.URL.Query().Get("cql")
			searchedCQL = append(searchedCQL, cql)
			if strings.Contains(cql, `space = "OPS"`) {
				_, _ = w.Write([]byte(`{"results":[{"content":{"id":"777","type":"page","title":"Runbook"}}],"totalSize":1}`))
				return
			}
			_, _ = w.Write([]byte(`{"results":[{"content":{"id":"888","type":"page","title":"Onboarding"}}],"totalSize":1}`))
		default:
			_, _ = w.Write([]byte(pageResponse(t, referencesBody, testPageWebUI)))
		}
	})

	path := filepath.Join(t.TempDir(), "page.md")
	if _, err := runRead(t, testPageURL, path, "--markdown"); err != nil {
		t.Fatalf("read error = %v", err)
	}

	written, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}

	// The same-space link is resolved against the space the page itself is
	// in, which is DEV — the key its web link carries.
	want := "Ping @Ada Lovelace, see [Runbook](" + testSite + "/spaces/OPS/pages/777) " +
		"and [Onboarding](" + testSite + "/spaces/DEV/pages/888).\n"
	if string(written) != want {
		t.Errorf("file = %q, want the resolved Markdown %q", written, want)
	}

	// One query per space, not one per link.
	if len(searchedCQL) != 2 {
		t.Errorf("search requests = %d (%v), want one per space", len(searchedCQL), searchedCQL)
	}

	// A resolved link is only worth emitting if cflio can follow it, which is
	// the whole reason the URL is looked up rather than assembled from the
	// space key and title the body carries.
	_, link, ok := strings.Cut(string(written), "](")
	if !ok {
		t.Fatalf("file = %q, want a Markdown link", written)
	}
	target, _, _ := strings.Cut(link, ")")
	ref, err := pageref.Parse(target)
	if err != nil {
		t.Fatalf("pageref.Parse(%q) error = %v, want the emitted link to be readable", target, err)
	}
	if ref.PageID != "777" {
		t.Errorf("parsed page id = %q, want the resolved page 777", ref.PageID)
	}
}

// A link to a page in the same space names no space key, so it can only be
// resolved against the space the page itself is in. When the API returns no
// web link, there is no key to resolve against and the reference falls back
// rather than being looked up in the wrong space.
func TestReadMarkdownLeavesSameSpaceLinksAloneWithoutASpaceKey(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	body := `<p>See <ac:link><ri:page ri:content-title="Onboarding"/></ac:link>.</p>`
	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == searchPath {
			t.Error("a same-space link was searched for with no space to search in")
		}
		_, _ = w.Write([]byte(pageResponse(t, body, "")))
	})

	path := filepath.Join(t.TempDir(), "page.md")
	run, err := runRead(t, testPageURL, path, "--markdown")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	written, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	if want := "See Onboarding.\n"; string(written) != want {
		t.Errorf("file = %q, want the unresolved fallback %q", written, want)
	}

	// Dropping the reference before any lookup leaves the same open question a
	// failed request does — whether the page exists is simply unknown — so it
	// is reported the same way rather than passing for an unresolvable link.
	if want := "Unchecked: 1"; !strings.Contains(run.stdout, want) {
		t.Errorf("output = %q, want it to contain %q", run.stdout, want)
	}
}

// The report is triggered by a reference being dropped, not by the page
// lacking a web link: references that name their own space are resolvable
// without one.
func TestReadMarkdownReportsNothingWhenEveryPageRefNamesItsSpace(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	body := `<p>See <ac:link><ri:page ri:space-key="OPS" ri:content-title="Runbook"/></ac:link>.</p>`
	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == searchPath {
			_, _ = w.Write([]byte(`{"results":[{"content":{"id":"777","type":"page","title":"Runbook"}}],"totalSize":1}`))
			return
		}
		_, _ = w.Write([]byte(pageResponse(t, body, "")))
	})

	run, err := runRead(t, testPageURL, filepath.Join(t.TempDir(), "page.md"), "--markdown")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}
	if strings.Contains(run.stdout, "Unchecked") {
		t.Errorf("output = %q, want nothing reported when no reference was dropped", run.stdout)
	}
}

// A reference that cannot be resolved is an ordinary outcome — the person or
// page may be deleted, or invisible to this token — so it degrades the
// rendering rather than failing the read. A lookup that failed outright is a
// different thing: whether the reference was resolvable is unknown, and the
// output has to say so or the fallback reads as a settled answer.
func TestReadMarkdownFallsBackWhenResolutionFails(t *testing.T) {
	page := pageResponse(t, referencesBody, testPageWebUI)
	failEveryLookup := func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == bulkUsersPath || r.URL.Path == searchPath {
			w.WriteHeader(http.StatusInternalServerError)
			_, _ = w.Write([]byte(`{"message":"boom"}`))
			return
		}
		_, _ = w.Write([]byte(page))
	}

	t.Run("text output", func(t *testing.T) {
		isolateConfig(t)
		seedProfile(t, "example", testSite)
		startAPI(t, failEveryLookup)

		path := filepath.Join(t.TempDir(), "page.md")
		run, err := runRead(t, testPageURL, path, "--markdown")
		if err != nil {
			t.Fatalf("read error = %v, want a failed lookup not to fail the read", err)
		}

		written, err := os.ReadFile(path)
		if err != nil {
			t.Fatalf("ReadFile() error = %v", err)
		}
		want := "Ping @acc-1, see Runbook and Onboarding.\n"
		if string(written) != want {
			t.Errorf("file = %q, want the unresolved fallback %q", written, want)
		}

		// One mention plus the two spaces' worth of page links: every
		// reference the body makes went unanswered.
		if want := "Unchecked: 3"; !strings.Contains(run.stdout, want) {
			t.Errorf("output = %q, want it to contain %q", run.stdout, want)
		}
		// The count is its own report: nothing about the conversion degraded.
		if strings.Contains(run.stdout, "Degraded:") {
			t.Errorf("output = %q, want a failed lookup kept out of the degradation report", run.stdout)
		}
	})

	t.Run("json output", func(t *testing.T) {
		isolateConfig(t)
		seedProfile(t, "example", testSite)
		startAPI(t, failEveryLookup)

		run, err := runRead(t, testPageURL, filepath.Join(t.TempDir(), "page.md"),
			"--markdown", "--format", "json")
		if err != nil {
			t.Fatalf("read error = %v, want a failed lookup not to fail the read", err)
		}

		var got map[string]any
		if err := json.Unmarshal([]byte(run.stdout), &got); err != nil {
			t.Fatalf("Unmarshal(output) error = %v; output = %q", err, run.stdout)
		}
		if got["unchecked_count"] != float64(3) {
			t.Errorf("unchecked_count = %v, want 3", got["unchecked_count"])
		}
	})
}

// A lookup that ran and matched nothing is a settled answer, not an incomplete
// resolution: the account or the page is gone, and the fallback is correct.
func TestReadMarkdownReportsNothingWhenEveryLookupSucceeds(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case bulkUsersPath:
			_, _ = w.Write([]byte(`{"results":[]}`))
		case searchPath:
			_, _ = w.Write([]byte(`{"results":[],"totalSize":0}`))
		default:
			_, _ = w.Write([]byte(pageResponse(t, referencesBody, testPageWebUI)))
		}
	})

	run, err := runRead(t, testPageURL, filepath.Join(t.TempDir(), "page.md"),
		"--markdown", "--format", "json")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal([]byte(run.stdout), &got); err != nil {
		t.Fatalf("Unmarshal(output) error = %v; output = %q", err, run.stdout)
	}
	if _, ok := got["unchecked_count"]; ok {
		t.Errorf("output = %v, want unchecked_count omitted when every lookup answered", got)
	}
}

// Storage mode writes the API's bytes back untouched, so there is nothing to
// resolve and no reason to spend a request finding out.
func TestReadSkipsResolutionWithoutMarkdown(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == bulkUsersPath || r.URL.Path == searchPath {
			t.Errorf("storage mode looked references up at %s", r.URL.Path)
		}
		_, _ = w.Write([]byte(pageResponse(t, referencesBody, testPageWebUI)))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	if _, err := runRead(t, testPageURL, path); err != nil {
		t.Fatalf("read error = %v", err)
	}
}

func TestReadMarkdownDefaultsTheOutputPathToAMarkdownFile(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", testPageWebUI)))
	})

	dir := t.TempDir()
	t.Chdir(dir)

	if _, err := runRead(t, "123456", "", "--markdown"); err != nil {
		t.Fatalf("read error = %v", err)
	}
	if _, err := os.Stat(filepath.Join(dir, "123456.md")); err != nil {
		t.Errorf("Stat(123456.md) error = %v, want the default output file", err)
	}
	// The extensions differ so reading a page both ways leaves two files
	// rather than one overwriting the other.
	if _, err := os.Stat(filepath.Join(dir, "123456.xml")); !os.IsNotExist(err) {
		t.Errorf("Stat(123456.xml) = %v, want the storage default left untouched", err)
	}
}

func TestReadMarkdownDropsAStaleSidecar(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	// Converting over a file that was previously read in storage mode must
	// not leave the old sidecar behind: `update` would then send Markdown to
	// the page it names.
	path := filepath.Join(t.TempDir(), "page.md")
	stale := sidecar.Meta{
		PageID:  "123456",
		Version: 7,
		Title:   "Some Page",
		Status:  "current",
		PageURL: testPageURL,
	}
	if err := sidecar.Write(path, stale); err != nil {
		t.Fatalf("sidecar.Write() error = %v", err)
	}

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>hi</p>", testPageWebUI)))
	})

	if _, err := runRead(t, "123456", path, "--markdown"); err != nil {
		t.Fatalf("read error = %v", err)
	}
	if _, err := os.Stat(sidecar.Path(path)); !os.IsNotExist(err) {
		t.Errorf("Stat(%s) = %v, want the stale sidecar removed", sidecar.Path(path), err)
	}
}

func TestReadMarkdownReportsWhatItCouldNotConvert(t *testing.T) {
	body := `<p>text</p>` +
		`<ac:structured-macro ac:name="jira"><ac:parameter ac:name="key">A-1</ac:parameter></ac:structured-macro>` +
		`<ac:structured-macro ac:name="jira"><ac:parameter ac:name="key">A-2</ac:parameter></ac:structured-macro>` +
		`<ac:adf-extension><ac:adf-node type="panel"/></ac:adf-extension>`

	t.Run("text output", func(t *testing.T) {
		isolateConfig(t)
		seedProfile(t, "example", testSite)

		startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
			_, _ = w.Write([]byte(pageResponse(t, body, testPageWebUI)))
		})

		run, err := runRead(t, "123456", filepath.Join(t.TempDir(), "page.md"), "--markdown")
		if err != nil {
			t.Fatalf("read error = %v", err)
		}
		// The reader decides whether to re-read in storage mode from this
		// line, before opening the file.
		if want := "Degraded: 3 (adf-extension, jira)"; !strings.Contains(run.stdout, want) {
			t.Errorf("output = %q, want it to contain %q", run.stdout, want)
		}
	})

	t.Run("json output", func(t *testing.T) {
		isolateConfig(t)
		seedProfile(t, "example", testSite)

		startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
			_, _ = w.Write([]byte(pageResponse(t, body, testPageWebUI)))
		})

		run, err := runRead(t, "123456", filepath.Join(t.TempDir(), "page.md"),
			"--markdown", "--format", "json")
		if err != nil {
			t.Fatalf("read error = %v", err)
		}

		var got map[string]any
		if err := json.Unmarshal([]byte(run.stdout), &got); err != nil {
			t.Fatalf("Unmarshal(output) error = %v; output = %q", err, run.stdout)
		}
		if got["unsupported_count"] != float64(3) {
			t.Errorf("unsupported_count = %v, want 3", got["unsupported_count"])
		}
		if fmt.Sprint(got["unsupported"]) != "[adf-extension jira]" {
			t.Errorf("unsupported = %v, want the distinct names sorted", got["unsupported"])
		}
		if _, ok := got["sidecar_path"]; ok {
			t.Errorf("output = %v, want no sidecar_path in Markdown mode", got)
		}
	})
}

func TestReadMarkdownReportsNothingWhenTheConversionIsClean(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(pageResponse(t, "<p>plain</p>", testPageWebUI)))
	})

	run, err := runRead(t, "123456", filepath.Join(t.TempDir(), "page.md"),
		"--markdown", "--format", "json")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	var got map[string]any
	if err := json.Unmarshal([]byte(run.stdout), &got); err != nil {
		t.Fatalf("Unmarshal(output) error = %v; output = %q", err, run.stdout)
	}
	for _, key := range []string{"unsupported", "unsupported_count"} {
		if _, ok := got[key]; ok {
			t.Errorf("output = %v, want %q omitted for a faithful conversion", got, key)
		}
	}
}

func TestReadWritesNothingWhenTheAPIFails(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)

	startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusNotFound)
		_, _ = w.Write([]byte(`{"errors":[{"title":"Not Found"}]}`))
	})

	path := filepath.Join(t.TempDir(), "page.xml")
	if _, err := runRead(t, testPageURL, path); err == nil {
		t.Fatal("read error = nil, want an error")
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Errorf("Stat(%s) = %v, want no file written on failure", path, err)
	}
}

// imageBody references one attachment and one image sourced from a URL, so a
// test can assert what the flag changes and what it leaves alone.
const imageBody = `<p><ac:image><ri:attachment ri:filename="main.png"/></ac:image></p>` +
	`<p><ac:image ac:alt="Diagram"><ri:url ri:value="https://example.com/d.png"/></ac:image></p>`

// readAttachmentsAPI counts the attachment requests a read made, so a test can
// assert that an unreferenced attachment cost nothing and that a body with no
// image asked for no listing at all. downloads is attachmentsAPI's own counter
// rather than a second tally of the same requests, which would drift from it
// the moment the download path changes shape.
type readAttachmentsAPI struct {
	listings  int
	downloads *int
}

// newReadAttachmentsAPI serves the page body alongside the listing and the
// downloads, reusing the listing and transfer handler the `attachments` tests
// use so the two paths cannot drift apart.
func newReadAttachmentsAPI(t *testing.T, body string, attachments ...attachment) (*readAttachmentsAPI, http.HandlerFunc) {
	t.Helper()

	downloads, serveAttachments := attachmentsAPI(t, attachments...)
	counts := &readAttachmentsAPI{downloads: downloads}
	return counts, func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/attachments"):
			counts.listings++
			serveAttachments(w, r)
		case strings.HasSuffix(r.URL.Path, "/download"):
			serveAttachments(w, r)
		default:
			_, _ = w.Write([]byte(pageResponse(t, body, testPageWebUI)))
		}
	}
}

// The storage body is never rewritten, so there is nothing for a downloaded
// file to be linked from. Naming both flags is what tells the caller which one
// to drop.
func TestReadAttachmentsWithoutMarkdownIsRejectedBeforeAnyRequest(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)
	startAPI(t, neverCalled(t, "despite --attachments without --markdown"))

	dir := t.TempDir()
	_, err := runRead(t, testPageURL, filepath.Join(dir, "page.xml"), "--attachments", filepath.Join(dir, "assets"))
	if err == nil {
		t.Fatal("read error = nil, want --attachments to be refused without --markdown")
	}
	for _, want := range []string{"--attachments", "--markdown"} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("error = %q, want it to name %q", err, want)
		}
	}
}

func TestReadMarkdownDownloadsOnlyTheAttachmentsTheBodyReferences(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)
	counts, handler := newReadAttachmentsAPI(t, imageBody,
		attachment{title: "main.png", mediaType: "image/png", size: len(pngBytes)},
		attachment{title: "unused.pdf", mediaType: "application/pdf", size: 12},
	)
	startAPI(t, handler)

	t.Chdir(t.TempDir())
	if _, err := runRead(t, testPageURL, "page.md", "--markdown", "--attachments", "./assets"); err != nil {
		t.Fatalf("read error = %v", err)
	}

	written, err := os.ReadFile("page.md")
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	want := "![main.png](./assets/main.png)\n\n![Diagram](https://example.com/d.png)\n"
	if string(written) != want {
		t.Errorf("file = %q, want %q", written, want)
	}

	downloaded, err := os.ReadFile(filepath.Join("assets", "main.png"))
	if err != nil {
		t.Fatalf("ReadFile(assets/main.png) error = %v", err)
	}
	if !bytes.Equal(downloaded, pngBytes) {
		t.Errorf("downloaded = %v, want the bytes the API served", downloaded)
	}

	// The page holds it, the body does not reference it: `attachments
	// download` is the command for pulling that one.
	if _, err := os.Lstat(filepath.Join("assets", "unused.pdf")); !os.IsNotExist(err) {
		t.Errorf("Lstat(assets/unused.pdf) error = %v, want the unreferenced attachment left alone", err)
	}
	if *counts.downloads != 1 {
		t.Errorf("downloads = %d, want only the referenced attachment fetched", *counts.downloads)
	}
}

// A fetch that fails is the same kind of outcome as a mention whose lookup
// failed: the rendering degrades to what the body carries, the read still
// succeeds, and the count says the answer is missing rather than settled.
func TestReadMarkdownFallsBackWhenAnAttachmentCannotBeFetched(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)
	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/attachments"):
			_, _ = w.Write([]byte(`{"results":[{"id":"att1","title":"main.png","mediaType":"image/png",` +
				`"fileSize":11,"downloadLink":"/rest/api/content/123456/child/attachment/att1/download"}],"_links":{}}`))
		case strings.HasSuffix(r.URL.Path, "/download"):
			w.WriteHeader(http.StatusInternalServerError)
		default:
			_, _ = w.Write([]byte(pageResponse(t, imageBody, testPageWebUI)))
		}
	})

	t.Chdir(t.TempDir())
	run, err := runRead(t, testPageURL, "page.md", "--markdown", "--attachments", "./assets", "--format", "json")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	written, err := os.ReadFile("page.md")
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	if !strings.HasPrefix(string(written), "main.png\n") {
		t.Errorf("file = %q, want the filename text a failed fetch degrades to", written)
	}

	var result readResult
	if err := json.Unmarshal([]byte(run.stdout), &result); err != nil {
		t.Fatalf("Unmarshal(%q) error = %v", run.stdout, err)
	}
	if result.UncheckedCount != 1 {
		t.Errorf("unchecked_count = %d, want the failed fetch counted", result.UncheckedCount)
	}

	// The transfer took its half-written file with it.
	if _, err := os.Lstat(filepath.Join("assets", "main.png")); !os.IsNotExist(err) {
		t.Errorf("Lstat(assets/main.png) error = %v, want no file left behind", err)
	}
}

// A body with no image has nothing to resolve, so the listing is a request
// worth not making and the directory a side effect worth not having.
func TestReadMarkdownWithNoImageAsksForNothingAndCreatesNothing(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)
	counts, handler := newReadAttachmentsAPI(t, "<p>plain</p>",
		attachment{title: "main.png", mediaType: "image/png", size: len(pngBytes)},
	)
	startAPI(t, handler)

	t.Chdir(t.TempDir())
	if _, err := runRead(t, testPageURL, "page.md", "--markdown", "--attachments", "./assets"); err != nil {
		t.Fatalf("read error = %v", err)
	}

	if counts.listings != 0 {
		t.Errorf("listings = %d, want no attachment request for a body with no image", counts.listings)
	}
	if _, err := os.Lstat("assets"); !os.IsNotExist(err) {
		t.Errorf("Lstat(assets) error = %v, want the directory left uncreated", err)
	}
}

// Unlike `attachments download`, which refuses the whole run on a collision, a
// read cannot fail over one: it would make re-reading a page depend on the
// state of a directory. The existing file is kept and linked instead, which
// makes the second read of the same page cheap and non-destructive.
func TestReadMarkdownKeepsAFileAlreadyAtTheDestination(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)
	counts, handler := newReadAttachmentsAPI(t, imageBody,
		attachment{title: "main.png", mediaType: "image/png", size: len(pngBytes)},
	)
	startAPI(t, handler)

	t.Chdir(t.TempDir())
	if err := os.Mkdir("assets", 0o755); err != nil {
		t.Fatalf("Mkdir() error = %v", err)
	}
	const existing = "not the attachment"
	if err := os.WriteFile(filepath.Join("assets", "main.png"), []byte(existing), 0o644); err != nil {
		t.Fatalf("WriteFile() error = %v", err)
	}

	if _, err := runRead(t, testPageURL, "page.md", "--markdown", "--attachments", "./assets"); err != nil {
		t.Fatalf("read error = %v", err)
	}

	kept, err := os.ReadFile(filepath.Join("assets", "main.png"))
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	if string(kept) != existing {
		t.Errorf("file = %q, want the existing file left as it was", kept)
	}
	if *counts.downloads != 0 {
		t.Errorf("downloads = %d, want the existing file reused rather than fetched", *counts.downloads)
	}

	written, err := os.ReadFile("page.md")
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	if !strings.Contains(string(written), "![main.png](./assets/main.png)") {
		t.Errorf("file = %q, want it to link the kept file", written)
	}
}

// The listing is what says which filenames the page holds, so when it cannot
// be had no reference has an answer — and nothing has been decided about the
// directory yet, so it is not created either.
func TestReadMarkdownCountsEveryImageUncheckedWhenTheListingFails(t *testing.T) {
	isolateConfig(t)
	seedProfile(t, "example", testSite)
	startAPI(t, func(w http.ResponseWriter, r *http.Request) {
		switch {
		case strings.HasSuffix(r.URL.Path, "/attachments"):
			w.WriteHeader(http.StatusInternalServerError)
		case strings.HasSuffix(r.URL.Path, "/download"):
			t.Errorf("unexpected download of %s after the listing failed", r.URL.Path)
		default:
			_, _ = w.Write([]byte(pageResponse(t, imageBody, testPageWebUI)))
		}
	})

	t.Chdir(t.TempDir())
	run, err := runRead(t, testPageURL, "page.md", "--markdown", "--attachments", "./assets", "--format", "json")
	if err != nil {
		t.Fatalf("read error = %v", err)
	}

	var result readResult
	if err := json.Unmarshal([]byte(run.stdout), &result); err != nil {
		t.Fatalf("Unmarshal(%q) error = %v", run.stdout, err)
	}
	if result.UncheckedCount != 1 {
		t.Errorf("unchecked_count = %d, want the one referenced attachment counted", result.UncheckedCount)
	}
	if _, err := os.Lstat("assets"); !os.IsNotExist(err) {
		t.Errorf("Lstat(assets) error = %v, want the directory left uncreated", err)
	}
}

// TestReadRecordsThePageSubtype pins what makes `plantuml set` able to tell a
// live doc from a classic page offline. The API omits the field for a classic
// page, and the sidecar has to record that as an answer rather than as a gap.
func TestReadRecordsThePageSubtype(t *testing.T) {
	for _, tt := range []struct {
		name string
		// field is what the page response carries, spliced in as JSON.
		field string
		want  string
	}{
		{name: "live doc", field: `"subtype": "live",`, want: "live"},
		{name: "classic page", field: `"subtype": "",`, want: ""},
		{name: "field absent", field: "", want: ""},
	} {
		t.Run(tt.name, func(t *testing.T) {
			isolateConfig(t)
			seedProfile(t, "example", testSite)
			startAPI(t, func(w http.ResponseWriter, _ *http.Request) {
				response := pageResponse(t, "<p>body</p>", testPageWebUI)
				_, _ = w.Write([]byte("{" + tt.field + strings.TrimPrefix(response, "{")))
			})

			out := filepath.Join(t.TempDir(), "page.xml")
			if _, err := runRead(t, "123456", out); err != nil {
				t.Fatalf("read error = %v", err)
			}

			meta, err := sidecar.Load(out)
			if err != nil {
				t.Fatalf("sidecar.Load() error = %v", err)
			}
			// Recorded in every case, the absent field included: what the API
			// reported is an answer, and only a sidecar written before cflio
			// asked has none.
			if meta.Subtype == nil {
				t.Fatal("sidecar records no subtype")
			}
			if *meta.Subtype != tt.want {
				t.Errorf("subtype = %q, want %q", *meta.Subtype, tt.want)
			}
		})
	}
}
