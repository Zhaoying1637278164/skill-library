package format

import (
	"cmp"
	"encoding/xml"
	"html"
	"maps"
	"slices"
	"sort"
	"strconv"
	"strings"
	"unicode"

	"github.com/178inaba/cflio/internal/plantuml"
)

// PageRef names a page the way storage links to one: by space key and title,
// with no page ID anywhere in the body.
type PageRef struct {
	SpaceKey string
	Title    string
}

// Options carries the reference resolution ToMarkdown cannot do itself. The
// converter is a pure function, so looking a name or a URL up — which needs
// the API — happens in the command layer and arrives here as data. A zero
// Options is valid: every reference falls back to what the body already
// carries.
type Options struct {
	// UserNames maps an Atlassian account ID to a display name.
	UserNames map[string]string
	// PageURLs maps a link target to the page's URL.
	PageURLs map[PageRef]string
	// AttachmentPaths maps an attachment's filename to the destination an
	// image of it links to. It holds what the caller wants written into the
	// link, which is not necessarily the path it wrote the file to: the
	// caller builds a link out of forward slashes, and on Windows the file
	// went to a path built out of backslashes.
	AttachmentPaths map[string]string
}

// Refs are the references a body makes that ToMarkdown cannot render without
// an Options filled in from the API. Every slice is deduplicated and sorted,
// so the requests a caller builds from them are deterministic.
type Refs struct {
	// AccountIDs are the ri:user targets.
	AccountIDs []string
	// Pages are the ri:page targets. SpaceKey is empty for a link to a page
	// in the same space, which is how storage writes one — and that empty key
	// is what Options.PageURLs has to be keyed by for the lookup to hit.
	Pages []PageRef
	// Attachments are the filenames the page's own images are sourced from.
	// A filename is all storage carries, and it is also what the attachment
	// listing identifies a file by, so it is what Options.AttachmentPaths is
	// keyed by too.
	Attachments []string
}

// References collects what a caller has to resolve for ToMarkdown to render
// names, URLs and image paths instead of identifiers. It walks for the same
// targets link and image render, through the same accessors; the kinds worth
// resolving are listed in collectTarget and imageAttachment, which those two
// renderers have to be kept in step with.
//
// Parsing the body twice — once here, once in ToMarkdown — is the price of
// keeping the converter a pure function. Returning the references from the
// conversion instead would cost the same parse plus a discarded render, since
// the resolution has to be in hand before the rendering that uses it.
func References(storage string) Refs {
	accountIDs := make(map[string]struct{})
	pages := make(map[PageRef]struct{})
	attachments := make(map[string]struct{})

	var walk func(nodes []*node)
	walk = func(nodes []*node) {
		for _, n := range nodes {
			if n.space == "ac" {
				switch n.local {
				case "link":
					collectTarget(riChild(n), accountIDs, pages)
				case "image":
					// Like collectTarget, a source carrying no filename is
					// dropped: nothing could match it.
					if a := imageAttachment(riChild(n)); a != nil && a.attr["filename"] != "" {
						attachments[a.attr["filename"]] = struct{}{}
					}
				}
			}
			walk(n.children)
		}
	}
	walk(parseStorage(storage).children)

	return Refs{
		AccountIDs: slices.Sorted(maps.Keys(accountIDs)),
		Pages: slices.SortedFunc(maps.Keys(pages), func(a, b PageRef) int {
			return cmp.Or(cmp.Compare(a.SpaceKey, b.SpaceKey), cmp.Compare(a.Title, b.Title))
		}),
		Attachments: slices.Sorted(maps.Keys(attachments)),
	}
}

// collectTarget records the resource a link names, if it is one that
// resolving would change the rendering of. A target carrying no identifier is
// dropped: the lookup could not match, and the renderer already falls back.
//
// The kinds handled here are the ones link consults Options for; an image's
// attachment is collected through imageAttachment instead. Teaching link to
// resolve a further kind means adding it here too, or the resolution it now
// expects will never be looked up.
func collectTarget(target *node, accountIDs map[string]struct{}, pages map[PageRef]struct{}) {
	if target == nil {
		return
	}

	switch target.local {
	case "user":
		if id := target.attr["account-id"]; id != "" {
			accountIDs[id] = struct{}{}
		}
	case "page":
		if title := target.attr["content-title"]; title != "" {
			pages[PageRef{SpaceKey: target.attr["space-key"], Title: title}] = struct{}{}
		}
	}
}

// Result is a conversion and what it could not represent.
type Result struct {
	Markdown string
	// Unsupported names the macros and extensions that became placeholders,
	// deduplicated and sorted; UnsupportedCount counts every occurrence. A
	// reader decides from these whether the rendering can be trusted, without
	// having to read the whole file first.
	Unsupported      []string
	UnsupportedCount int
}

// ToMarkdown converts a storage-format body to Markdown for reading. It never
// fails: unknown input degrades in structure, never in content, so an element
// this converter has never seen still yields the text inside it.
func ToMarkdown(storage string, opts Options) Result {
	r := &renderer{opts: opts}

	// Assembled in one pass: appending the trailing newline afterwards would
	// copy the whole body a second time, and this tool exists for the pages
	// where that is worth avoiding.
	var out strings.Builder
	for i, b := range r.blocks(parseStorage(storage).children) {
		if i > 0 {
			out.WriteString("\n\n")
		}
		out.WriteString(b.text)
	}
	if out.Len() > 0 {
		// Unlike the storage path, which writes the API's bytes back
		// verbatim, nothing here has to survive a byte comparison.
		out.WriteByte('\n')
	}

	result := Result{Markdown: out.String()}
	for name, count := range r.unsupported {
		result.Unsupported = append(result.Unsupported, name)
		result.UnsupportedCount += count
	}
	sort.Strings(result.Unsupported)
	return result
}

// node is a parsed storage element, or a run of text when name is empty.
// Attributes are keyed by local name: storage prefixes them (ac:, ri:) but
// never reuses one local name for two meanings on the same element.
type node struct {
	space    string
	local    string
	attr     map[string]string
	text     string
	children []*node
}

func (n *node) isText() bool { return n.local == "" }

// child returns the first child with the given prefix and name, or nil.
func (n *node) child(space, local string) *node {
	if n == nil {
		return nil
	}
	for _, c := range n.children {
		if c.space == space && c.local == local {
			return c
		}
	}
	return nil
}

// newStorageDecoder configures a decoder for storage XHTML.
//
// Storage format is a fragment, not a document: it uses undeclared ac:/ri:
// prefixes and HTML entities like &nbsp;. Non-strict mode with the HTML
// entity table copes with both, and also closes stray tags so malformed
// markup does not discard the rest of the body. It is what makes CDATA
// sections survive, too: an HTML5 parser reads <![CDATA[…]]> as a bogus
// comment and drops every code macro's body.
//
// xml.HTMLAutoClose is deliberately NOT set: it treats every element whose
// local name is an HTML void element as self-closing, which swallows
// Confluence's <ac:link>…</ac:link> — the wrapper around every mention and
// page link — and drops everything after it.
func newStorageDecoder(storage string) *xml.Decoder {
	decoder := xml.NewDecoder(strings.NewReader(storage))
	decoder.Strict = false
	decoder.Entity = xml.HTMLEntity
	return decoder
}

// parseStorage builds the element tree. Rendering Markdown needs look-ahead
// that a token stream cannot give: a table's header separator depends on its
// first row, and a list item's indentation on what nests under it.
func parseStorage(storage string) *node {
	decoder := newStorageDecoder(storage)

	root := &node{}
	stack := []*node{root}
	for {
		token, err := decoder.Token()
		if err != nil {
			// EOF, or a document too broken to recover from. Either way,
			// render what was parsed rather than losing the whole page.
			break
		}

		parent := stack[len(stack)-1]
		switch t := token.(type) {
		case xml.CharData:
			parent.children = append(parent.children, &node{text: string(t)})
		case xml.StartElement:
			element := &node{
				space: strings.ToLower(t.Name.Space),
				local: strings.ToLower(t.Name.Local),
			}
			if len(t.Attr) > 0 {
				element.attr = make(map[string]string, len(t.Attr))
				for _, a := range t.Attr {
					element.attr[a.Name.Local] = a.Value
				}
			}
			parent.children = append(parent.children, element)
			stack = append(stack, element)
		case xml.EndElement:
			if len(stack) > 1 {
				stack = stack[:len(stack)-1]
			}
		}
	}
	return root
}

// block is one Markdown block. isList marks a list so a nested one can hang
// directly under its parent item instead of being pushed a blank line away.
type block struct {
	text   string
	isList bool
}

func joinBlocks(blocks []block) string {
	texts := make([]string, 0, len(blocks))
	for _, b := range blocks {
		texts = append(texts, b.text)
	}
	return strings.Join(texts, "\n\n")
}

type renderer struct {
	opts        Options
	unsupported map[string]int
}

// unrepresentable records an element that became a placeholder.
func (r *renderer) unrepresentable(name string) {
	if r.unsupported == nil {
		r.unsupported = make(map[string]int)
	}
	r.unsupported[name]++
}

// blocks renders a node's children as a sequence of blocks. Inline children
// accumulate into a paragraph that is flushed when a block child arrives, so
// text sitting directly inside a container survives alongside its siblings.
func (r *renderer) blocks(nodes []*node) []block {
	var out []block
	var paragraph strings.Builder

	flush := func() {
		if text := strings.TrimSpace(paragraph.String()); text != "" {
			out = append(out, block{text: escapeBlockStarts(text)})
		}
		paragraph.Reset()
	}

	var walk func(nodes []*node)
	walk = func(nodes []*node) {
		for _, n := range nodes {
			switch rendered, isBlock := r.block(n); {
			case isBlock:
				flush()
				out = append(out, rendered...)
			case n.isText() || isInlineElement(n):
				paragraph.WriteString(r.inlineNode(n))
			default:
				// An element this converter does not know: drop the tag and
				// keep the children. Losing body text is the worst outcome
				// available, and storage is full of non-macro ac: elements
				// (layouts, inline comment markers) whose children are
				// ordinary content.
				walk(n.children)
			}
		}
	}
	walk(nodes)
	flush()

	return out
}

func isInlineElement(n *node) bool {
	switch n.space {
	case "":
		switch n.local {
		case "strong", "b", "em", "i", "code", "s", "del", "strike",
			"u", "sub", "sup", "span", "time", "br", "a", "img":
			return true
		}
	case "ac":
		switch n.local {
		case "link", "image", "emoticon":
			return true
		}
	}
	return false
}

// block renders a block-level element, reporting whether it recognised one.
// Recognition and rendering are the same switch on purpose: a second list of
// block tag names would silently disagree with this one, and an element
// missing from it degrades into the unknown-element path without a word.
func (r *renderer) block(n *node) ([]block, bool) {
	if n.space == "ac" {
		switch n.local {
		case "structured-macro":
			return r.macro(n), true
		case "adf-extension":
			return r.adfExtension(n), true
		case "task-list":
			return r.taskList(n), true
		}
		return nil, false
	}
	if n.space != "" {
		return nil, false
	}

	switch n.local {
	case "p":
		if text := strings.TrimSpace(r.inlineChildren(n)); text != "" {
			return []block{{text: escapeBlockStarts(text)}}, true
		}
		return nil, true
	case "h1", "h2", "h3", "h4", "h5", "h6":
		if text := strings.TrimSpace(r.inlineChildren(n)); text != "" {
			level, _ := strconv.Atoi(n.local[1:])
			return []block{{text: strings.Repeat("#", level) + " " + text}}, true
		}
		return nil, true
	case "hr":
		return []block{{text: "---"}}, true
	case "ul", "ol":
		return r.list(n), true
	case "table":
		return r.table(n), true
	case "blockquote":
		return quote(r.blocks(n.children)), true
	case "pre":
		return []block{{text: fence("", rawText(n))}}, true
	case "div", "dl", "dt", "dd":
		// Containers with no Markdown of their own, recognised anyway so
		// they end the paragraph they interrupt. Splicing them into the
		// surrounding text like an unknown inline element would run the
		// words of two blocks together, which loses content as surely as
		// dropping it — pasted HTML brings these in regularly.
		return r.blocks(n.children), true
	}
	return nil, false
}

func (r *renderer) list(n *node) []block {
	var items []string
	for _, child := range n.children {
		if child.space != "" || child.local != "li" {
			continue
		}

		marker := "- "
		if n.local == "ol" {
			marker = strconv.Itoa(len(items)+1) + ". "
		}
		items = append(items, r.listItem(child, marker))
	}
	return listBlock(items)
}

func listBlock(items []string) []block {
	if len(items) == 0 {
		return nil
	}
	return []block{{text: strings.Join(items, "\n"), isList: true}}
}

// listItem renders one item under marker. li may be nil: a task can arrive
// without an ac:task-body, and this converter is contracted never to fail on
// input it did not expect.
func (r *renderer) listItem(li *node, marker string) string {
	var body strings.Builder
	for i, b := range r.blocks(li.childNodes()) {
		if i > 0 {
			if b.isList {
				body.WriteString("\n")
			} else {
				body.WriteString("\n\n")
			}
		}
		body.WriteString(b.text)
	}

	lines := strings.Split(body.String(), "\n")
	indent := strings.Repeat(" ", len(marker))
	for i, line := range lines {
		switch {
		case i == 0:
			lines[i] = strings.TrimRight(marker+line, " ")
		case line != "":
			lines[i] = indent + line
		}
	}
	return strings.Join(lines, "\n")
}

func (r *renderer) taskList(n *node) []block {
	var items []string
	for _, task := range n.children {
		if task.space != "ac" || task.local != "task" {
			continue
		}

		marker := "- [ ] "
		if strings.TrimSpace(rawText(task.child("ac", "task-status"))) == "complete" {
			marker = "- [x] "
		}
		items = append(items, r.listItem(task.child("ac", "task-body"), marker))
	}
	return listBlock(items)
}

// table renders a Markdown table. Structure degrades where Markdown cannot
// follow — colspan and rowspan are dropped, block content inside a cell is
// flattened — but every cell's text is emitted, and a table is never replaced
// by a placeholder.
func (r *renderer) table(n *node) []block {
	rows := tableRows(n)
	if len(rows) == 0 {
		return nil
	}

	columns := len(tableCells(rows[0]))
	header := make([]string, columns)
	body := rows
	if isHeaderRow(rows[0]) {
		header = r.rowCells(rows[0])
		body = rows[1:]
	}

	lines := []string{tableLine(pad(header, columns)), tableLine(repeat("---", columns))}
	for _, row := range body {
		lines = append(lines, tableLine(pad(r.rowCells(row), columns)))
	}
	return []block{{text: strings.Join(lines, "\n")}}
}

// tableRows collects the rows of a table, seeing through thead/tbody/tfoot.
func tableRows(n *node) []*node {
	var rows []*node
	for _, child := range n.children {
		switch {
		case child.space != "":
		case child.local == "tr":
			rows = append(rows, child)
		case child.local == "thead" || child.local == "tbody" || child.local == "tfoot":
			rows = append(rows, tableRows(child)...)
		}
	}
	return rows
}

func tableCells(row *node) []*node {
	var cells []*node
	for _, child := range row.children {
		if child.space == "" && (child.local == "td" || child.local == "th") {
			cells = append(cells, child)
		}
	}
	return cells
}

func isHeaderRow(row *node) bool {
	cells := tableCells(row)
	if len(cells) == 0 {
		return false
	}
	for _, cell := range cells {
		if cell.local != "th" {
			return false
		}
	}
	return true
}

func (r *renderer) rowCells(row *node) []string {
	cells := tableCells(row)
	texts := make([]string, 0, len(cells))
	for _, cell := range cells {
		// A cell is one Markdown table cell however much structure it holds,
		// so blocks collapse to spaces and pipes are escaped rather than
		// ending the cell early.
		text := strings.TrimSpace(collapseSpace(joinBlocks(r.blocks(cell.children))))
		texts = append(texts, strings.ReplaceAll(text, "|", `\|`))
	}
	return texts
}

// pad lengthens a row to the table's column count. Rows are never truncated:
// an extra cell renders outside the table but keeps its text.
func pad(cells []string, columns int) []string {
	for len(cells) < columns {
		cells = append(cells, "")
	}
	return cells
}

func repeat(cell string, columns int) []string {
	cells := make([]string, columns)
	for i := range cells {
		cells[i] = cell
	}
	return cells
}

func tableLine(cells []string) string {
	return "| " + strings.Join(cells, " | ") + " |"
}

// macro renders the macros this converter understands and degrades the rest.
func (r *renderer) macro(n *node) []block {
	name := n.attr["name"]
	switch name {
	case "code":
		return []block{{text: fence(macroParameter(n, "language"), rawText(n.child("ac", "plain-text-body")))}}
	case "plantumlcloud":
		// Falling through to the placeholder when the source will not decode
		// is the whole fallback: the degrade path below is what counts a
		// macro, so a fence never reaches it and needs no bookkeeping of its
		// own. The other parameters — filename, toolbar, revision — are render
		// configuration rather than content, like the code macro's wrap.
		if source, ok := plantUMLSource(n); ok {
			return []block{{text: fence("plantuml", source)}}
		}
	case "expand":
		return r.expand(n)
	case "toc":
		// A table of contents carries no content of its own: Confluence builds
		// it from the page's headings when the page is viewed, and those
		// headings are already in this output. What storage holds is render
		// configuration — levels, outline, style — so dropping the macro loses
		// nothing. Returning no blocks at all is what keeps the surrounding
		// ones joined as if it had never been there.
		return nil
	case "info", "note", "warning", "tip", "panel":
		return r.panel(n, name)
	}

	if name == "" {
		name = "unnamed"
	}
	r.unrepresentable(name)

	// The placeholder marks the macro, but ac:rich-text-body is storage
	// declaring "this part is body text" — dropping it would silently delete
	// everything an excerpt or a section wraps. Parameters and plain-text
	// bodies are macro configuration, so they stay out.
	return r.placeholder("[unsupported macro: "+name+"]", n.child("ac", "rich-text-body"))
}

// placeholder marks an element this converter cannot represent and keeps
// whatever body text it wraps.
func (r *renderer) placeholder(text string, body *node) []block {
	return append([]block{{text: text}}, r.blocks(body.childNodes())...)
}

// expand renders a collapsible section as the <details> block GitHub-flavoured
// Markdown understands. The opening tag, the body and the closing tag stay
// separate blocks so the "\n\n" they are joined with leaves the blank lines
// GitHub needs to read the body as Markdown rather than as literal text.
func (r *renderer) expand(n *node) []block {
	open := "<details>"
	// <summary> is raw HTML, so the title needs HTML entities rather than the
	// backslash escaping escapeText applies to paragraph text.
	if title := macroParameter(n, "title"); title != "" {
		open += "\n<summary>" + html.EscapeString(title) + "</summary>"
	}

	blocks := append([]block{{text: open}}, r.blocks(n.child("ac", "rich-text-body").childNodes())...)
	return append(blocks, block{text: "</details>"})
}

func (r *renderer) panel(n *node, kind string) []block {
	heading := strings.ToUpper(kind[:1]) + kind[1:]
	if title := macroParameter(n, "title"); title != "" {
		heading += ": " + escapeText(title)
	}

	blocks := []block{{text: "**" + heading + "**"}}
	blocks = append(blocks, r.blocks(n.child("ac", "rich-text-body").childNodes())...)
	return quote(blocks)
}

// adfExtension degrades a new-editor blob. Its ac:adf-node subtree is a
// parameter tree rather than markup, so it is not rendered; ac:adf-fallback
// is the editor's own rendering of the same content and is.
func (r *renderer) adfExtension(n *node) []block {
	r.unrepresentable("adf-extension")

	return r.placeholder("[unsupported adf-extension]", n.child("ac", "adf-fallback"))
}

// childNodes is nil-safe so callers can reach into a body element that may
// not be there.
func (n *node) childNodes() []*node {
	if n == nil {
		return nil
	}
	return n.children
}

// plantUMLSource decodes the diagram source a plantumlcloud macro carries,
// reporting false for anything that will not come all the way through. Which
// payloads are readable, and how, belongs to internal/plantuml, which owns the
// encoder too, so the two directions cannot drift apart; all this does is read
// the two parameters and degrade the failure into the placeholder path.
func plantUMLSource(n *node) (string, bool) {
	source, err := plantuml.Source(macroParameter(n, "compressed"), macroParameter(n, "data"))
	if err != nil {
		return "", false
	}
	return source, true
}

func macroParameter(n *node, name string) string {
	for _, child := range n.children {
		if child.space == "ac" && child.local == "parameter" && child.attr["name"] == name {
			return strings.TrimSpace(rawText(child))
		}
	}
	return ""
}

func quote(blocks []block) []block {
	text := joinBlocks(blocks)
	if text == "" {
		return nil
	}

	lines := strings.Split(text, "\n")
	for i, line := range lines {
		if line == "" {
			lines[i] = ">"
			continue
		}
		lines[i] = "> " + line
	}
	return []block{{text: strings.Join(lines, "\n")}}
}

func (r *renderer) inlineChildren(n *node) string {
	var out strings.Builder
	for _, child := range n.childNodes() {
		out.WriteString(r.inlineNode(child))
	}
	return out.String()
}

func (r *renderer) inlineNode(n *node) string {
	if n.isText() {
		return escapeText(collapseSpace(n.text))
	}

	if n.space == "ac" {
		switch n.local {
		case "link":
			return r.link(n)
		case "image":
			return r.image(n)
		case "emoticon":
			return emoticon(n)
		}
	}
	if n.space == "" {
		switch n.local {
		case "strong", "b":
			return emphasize("**", r.inlineChildren(n))
		case "em", "i":
			return emphasize("*", r.inlineChildren(n))
		case "s", "del", "strike":
			return emphasize("~~", r.inlineChildren(n))
		case "code":
			return codeSpan(collapseSpace(rawText(n)))
		case "br":
			return "\n"
		case "a":
			return r.anchor(n)
		case "img":
			return "![" + escapeText(n.attr["alt"]) + "](" + n.attr["src"] + ")"
		}
	}

	// Underline, sub/superscript, colour spans and anything unrecognised:
	// CommonMark has no equivalent, so the markup goes and the text stays.
	return r.inlineChildren(n)
}

func (r *renderer) anchor(n *node) string {
	text := strings.TrimSpace(r.inlineChildren(n))
	href := n.attr["href"]
	switch {
	case href == "":
		return text
	case text == "":
		return "[" + escapeText(href) + "](" + href + ")"
	default:
		return "[" + text + "](" + href + ")"
	}
}

// link renders <ac:link>. Storage names its targets rather than addressing
// them, so an unresolved target renders as text: a URL built here from a
// space key and a title is not a form pageref.Parse accepts, which would make
// it a link cflio itself cannot follow.
//
// The target kinds resolved from Options are the ones collectTarget gathers;
// the two are kept in step by hand.
func (r *renderer) link(n *node) string {
	body := r.linkBody(n)

	target := riChild(n)
	if target == nil {
		// An anchor-only link, which names no resource of its own.
		return body
	}

	switch target.local {
	case "user":
		id := target.attr["account-id"]
		if name := r.opts.UserNames[id]; name != "" {
			return "@" + escapeText(name)
		}
		return "@" + escapeText(id)
	case "page":
		title := target.attr["content-title"]
		text := body
		if text == "" {
			text = escapeText(title)
		}
		if url := r.opts.PageURLs[PageRef{SpaceKey: target.attr["space-key"], Title: title}]; url != "" {
			return "[" + text + "](" + url + ")"
		}
		return text
	case "attachment":
		if body != "" {
			return body
		}
		return escapeText(target.attr["filename"])
	}
	return body
}

// emoticon renders <ac:emoticon>, which carries its own text: the emoji
// itself on newer pages, a shortname otherwise. It is worth keeping because
// an emoticon is often a cell's entire content — a tick in a status column —
// and it is the one thing that would vanish without leaving a placeholder to
// count.
func emoticon(n *node) string {
	if fallback := n.attr["emoji-fallback"]; fallback != "" {
		return escapeText(fallback)
	}
	if shortname := n.attr["emoji-shortname"]; shortname != "" {
		return escapeText(shortname)
	}
	if name := n.attr["name"]; name != "" {
		return ":" + escapeText(name) + ":"
	}
	return ""
}

// riChild returns the ri: element naming what a link or an image points at.
func riChild(n *node) *node {
	for _, child := range n.children {
		if child.space == "ri" {
			return child
		}
	}
	return nil
}

func (r *renderer) linkBody(n *node) string {
	if plain := n.child("ac", "plain-text-link-body"); plain != nil {
		return escapeText(collapseSpace(rawText(plain)))
	}
	return strings.TrimSpace(r.inlineChildren(n.child("ac", "link-body")))
}

// image renders <ac:image>. An attachment has no URL the converter could put
// here — it is fetched, not linked — so unless the caller downloaded it and
// said where to, the filename is what is kept, and it is also what
// `cflio attachments download --pattern` selects the file by.
func (r *renderer) image(n *node) string {
	source := riChild(n)

	// The resolution is a prefix rather than a branch of the switch below:
	// what it does not answer falls through to the rendering that has always
	// applied, so an image imageAttachment excludes degrades exactly as it
	// did before there was anything to resolve.
	if attachment := imageAttachment(source); attachment != nil {
		if dest := r.opts.AttachmentPaths[attachment.attr["filename"]]; dest != "" {
			return "![" + escapeText(cmp.Or(n.attr["alt"], attachment.attr["filename"])) +
				"](" + linkDestination(dest) + ")"
		}
	}

	if source != nil {
		switch source.local {
		case "url":
			return "![" + escapeText(n.attr["alt"]) + "](" + source.attr["value"] + ")"
		case "attachment":
			return escapeText(source.attr["filename"])
		}
	}
	return escapeText(n.attr["alt"])
}

// imageAttachment narrows an <ac:image>'s source, as riChild returned it, to
// the attachment a download could resolve — nil for an image sourced from a
// URL, or for an attachment carrying a nested content identifier.
//
// The nested identifier is why this is an accessor and not an inline check: it
// names a file on a different page (<ri:page>) or blog post (<ri:blog-post>),
// and a filename is all the rest of the pipeline carries, so a caller that
// listed this page's attachments would match the name against the wrong
// content's file. Any ri: child is excluded rather than those two by name, so
// an identifier kind storage adds later cannot slip through as this page's
// file. References and image both go through here so neither can start
// disagreeing about which images have a file. It takes the source rather than
// the image for the reason collectTarget does: the caller has already
// resolved it.
func imageAttachment(source *node) *node {
	if source == nil || source.local != "attachment" || riChild(source) != nil {
		return nil
	}
	return source
}

// linkDestination renders a link target that is a local path rather than a
// URL. A space or a bracket in it would end the destination early — Confluence
// names screenshots with spaces routinely — so those go in the angle-bracket
// form CommonMark provides for the purpose, which needs only its own
// delimiters escaped. The path is left as it is otherwise: it is meant to be
// opened as a file, and percent-encoding it would be a form no file reader
// takes.
func linkDestination(dest string) string {
	if !strings.ContainsAny(dest, " ()<>") {
		return dest
	}
	return "<" + destinationEscaper.Replace(dest) + ">"
}

var destinationEscaper = strings.NewReplacer(`\`, `\\`, "<", `\<`, ">", `\>`)

// rawText concatenates the text under a node without touching it, for CDATA
// bodies that have to come out byte-identical.
func rawText(n *node) string {
	if n == nil {
		return ""
	}
	if n.isText() {
		return n.text
	}
	// A code macro's body is one CDATA run, so the decoder hands it over as a
	// single text child. Returning it directly saves copying what is often
	// the largest string on the page.
	if len(n.children) == 1 && n.children[0].isText() {
		return n.children[0].text
	}

	var out strings.Builder
	for _, child := range n.children {
		out.WriteString(rawText(child))
	}
	return out.String()
}

// collapseSpace squeezes whitespace runs to a single space, the way an HTML
// renderer would. A leading or trailing space is kept: it separates this text
// from the inline markup next to it. Non-breaking spaces collapse too, so the
// empty <p>&nbsp;</p> paragraphs Confluence leaves behind disappear.
func collapseSpace(s string) string {
	var out strings.Builder
	pending := false
	for _, r := range s {
		if unicode.IsSpace(r) {
			pending = true
			continue
		}
		if pending {
			out.WriteByte(' ')
			pending = false
		}
		out.WriteRune(r)
	}
	if pending {
		out.WriteByte(' ')
	}
	return out.String()
}

// textEscaper covers the characters that would otherwise be read as Markdown
// syntax. Underscore is deliberately absent: identifiers like read_page_body
// are everywhere in the pages this mode exists to make readable, CommonMark
// does not emphasise intra-word underscores, and escaping every one costs
// more legibility than it buys correctness.
var textEscaper = strings.NewReplacer(
	`\`, `\\`,
	"`", "\\`",
	"*", `\*`,
	"[", `\[`,
	"]", `\]`,
	"<", `\<`,
)

func escapeText(s string) string { return textEscaper.Replace(s) }

// escapeBlockStarts protects a paragraph whose text would otherwise open a
// list, a heading or a quote. It applies to paragraphs only — the markers this
// converter emits itself are syntax, not text.
func escapeBlockStarts(text string) string {
	lines := strings.Split(text, "\n")
	for i, line := range lines {
		lines[i] = escapeLineStart(line)
	}
	return strings.Join(lines, "\n")
}

func escapeLineStart(line string) string {
	if line == "" {
		return line
	}
	switch line[0] {
	case '#', '>', '-', '+':
		return `\` + line
	}

	digits := 0
	for digits < len(line) && line[digits] >= '0' && line[digits] <= '9' {
		digits++
	}
	if digits > 0 && digits < len(line) && (line[digits] == '.' || line[digits] == ')') {
		return line[:digits] + `\` + line[digits:]
	}
	return line
}

func emphasize(marker, text string) string {
	if strings.TrimSpace(text) == "" {
		return text
	}
	return marker + text + marker
}

func codeSpan(text string) string {
	ticks := strings.Repeat("`", longestBacktickRun(text)+1)
	if strings.HasPrefix(text, "`") || strings.HasSuffix(text, "`") {
		return ticks + " " + text + " " + ticks
	}
	return ticks + text + ticks
}

// fence wraps a code body, widening the fence past any backtick run inside so
// the body cannot end it early.
func fence(language, body string) string {
	marker := strings.Repeat("`", max(longestBacktickRun(body)+1, 3))
	return marker + language + "\n" + body + "\n" + marker
}

func longestBacktickRun(s string) int {
	longest, run := 0, 0
	for _, r := range s {
		if r != '`' {
			run = 0
			continue
		}
		run++
		if run > longest {
			longest = run
		}
	}
	return longest
}
