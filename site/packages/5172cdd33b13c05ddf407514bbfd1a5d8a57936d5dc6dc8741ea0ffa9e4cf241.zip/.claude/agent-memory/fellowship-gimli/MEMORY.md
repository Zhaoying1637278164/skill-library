# Gimli Memory Index

- [Verify Dispatch State](feedback_verify_dispatch_state.md) — Quest-log dispatch lines can lag disk by a release; check `wc -l`/`git log` before building
