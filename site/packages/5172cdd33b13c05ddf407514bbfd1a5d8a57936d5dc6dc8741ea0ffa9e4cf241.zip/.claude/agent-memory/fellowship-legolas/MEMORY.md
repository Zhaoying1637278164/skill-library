# Legolas Memory Index

- [Transcript Scan Noise Classes](project_transcript_scan_noise.md) — which status-line false positives are guarded vs accepted v1 noise in session-end scanning
