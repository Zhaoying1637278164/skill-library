---
name: opus-4-8-possibilities
status: reference
created: 2026-05-30
author: gandalf-research
type: research
---

# Claude Opus 4.8 — Possibilities for Fellowship (Designer / Developer)

Research brief, 2026-05-30. Opus 4.8 released **2026-05-28** (`claude-opus-4-8`),
~41 days after 4.7. Model-level facts below are from Anthropic primary sources;
benchmark specifics and subagent caps from secondary write-ups are flagged
**[unverified]**.

## 1. What's actually new (verified vs Anthropic sources)

- **Context / output:** 1M-token context by default (API/Bedrock/Vertex; 200k on
  Foundry), 128k max output. **Unchanged from 4.7.**
- **Honesty / self-verification:** ~**4× less likely than 4.7 to let flaws in its
  own code pass unremarked.** More likely to flag uncertainty, less likely to make
  unsupported claims. (The headline claim.)
- **Computer-use / browser:** **84% on Online-Mind2Web** — strongest computer-use /
  browser-agent model Anthropic has tested, ahead of 4.7 and GPT-5.5. The single
  biggest jump.
- **Agentic reliability:** better long-horizon coding, **fewer compactions + better
  compaction recovery**, **better tool triggering** (less likely to skip a required
  tool call). Fewer steps for the same result.
- **Effort parameter:** default now **`high`** on all surfaces incl. Claude Code.
  Adaptive thinking only; temp/top_p/top_k still unsupported.
- **Fast mode (research preview, API only):** `speed:"fast"` → up to **2.5× output
  tokens/sec**, same weights. **$10/$50 per MTok** vs $30/$150 on 4.6/4.7 fast tier
  (~3× cheaper). Waitlisted; not on Bedrock/Vertex/Foundry; switching speed busts
  prompt cache.
- **Standard pricing:** held flat vs 4.7 ($5 in / $25 out per MTok per secondary
  sources — **[unverified]** against doc pages).
- **API niceties:** mid-conversation `role:"system"` messages (append instructions
  late without restating the system prompt → preserves cache hits); **prompt-cache
  minimum lowered to 1,024 tokens**; documented `stop_details` refusal categories.
- **Dynamic Workflows (research preview):** Claude writes a JS orchestration script
  the runtime runs in the background — subagents attack from independent angles
  while others adversarially refute until convergence; resumable across multi-day
  runs. Capped **16 concurrent / 1,000 total subagents per run [unverified]**. Aimed
  at codebase-scale migrations end-to-end with the test suite as the bar.
- **No new modality.** Vision exists; no new image/video capability announced.
  "Design" gains are inference from better visual reasoning + computer-use, not a
  stated feature.

**[unverified]** SWE-bench 88.6%, USAMO 96.7%, Terminal-Bench 74.6 (trailing GPT-5.5
78.2) — single secondary blog, not confirmed against the official system card.

## 2. For developers — newly practical

- Longer unattended autonomous runs (fewer compactions + recovery + tool-triggering
  reliability) — the babysitting failure mode of 4.7 eases.
- Whole-repo reasoning at 1M now trustworthy *through* compaction (the window isn't
  new; staying-on-task is).
- Self-verifying code agents — the 4×-fewer-unflagged-flaws result.
- Computer-use reliable enough to **gate** on, not just demo (84% Online-Mind2Web).
- Cheaper agentic loops (1,024-token cache floor + mid-conversation system messages;
  fast mode where available).

## 3. For designers (mostly inference — flagged)

- Stronger visual reasoning + computer-use jump *implies* better work-from-screenshot
  critique and design-to-code fidelity — but no design/vision benchmark was
  published. Extrapolation.
- The genuinely new lever is **computer-use reliability**: driving a browser/Figma to
  audit a *rendered* UI (spacing, contrast, focus order, live a11y against the running
  app) becomes viable where 4.7 was too flaky. An agentic gain applied to design, not
  a new vision model.

## 4. Implications for Fellowship

**Materially stronger:**
1. **Pippin browser-verification (Mode 4).** Biggest win. The archived
   `2026-04-12-browser-verification-spec.md` routes Mode 4 to **sonnet**
   ("checklist work, not judgment"). The computer-use jump means an Opus-4.8 walk can
   do *judgment-bearing* end-to-end testing — explore, not just tick a checklist.
   Reconsider that sonnet routing for hard/exploratory flows.
2. **Validation contract / adversarial validators.** The 2026-05-30 contract rests on
   fresh-context validators scoring assertions adversarially. 4×-fewer-unflagged-flaws
   + better honesty raises the floor on their core job. Design unchanged; execution
   improves.
3. **Per-dispatch model routing.** Fast mode + flat `effort=high` give Gandalf two new
   dials. Checklist-tier dispatches are the obvious fast-mode candidates.

**Newly worth building (conceptually):**
4. **Dynamic-Workflows-backed orchestration mode** — Fellowship *already is*
   orchestrator + fresh-context workers + adversarial refutation; Dynamic Workflows is
   Anthropic shipping that exact pattern as a managed runtime. It **validates** the
   architecture more than it obsoletes it. Research-preview / API-only → watch and
   prototype, don't adopt. Candidate: a codebase-scale-migration quest type.

**Changes little for Fellowship:** 1M context (unchanged; our fresh-context discipline
already assumed it); Arwen/Bilbo/Sam (no announced capability maps); no new modality →
no model-level design-tool integration unlocked.

## Ranked shortlist (why now = 4.8)

1. **Pippin browser-verify on Opus 4.8 for hard/exploratory flows** — 84%
   Online-Mind2Web makes agentic computer-use reliable enough to gate releases.
2. **Lean the validation contract on 4.8's honesty gains; demand uncertainty-flagging
   in validator dispatch** — 4×-fewer-unflagged-flaws is exactly the validator job.
3. **Fast-mode routing tier for checklist dispatches** — 2.5× speed, ~3× cheaper.
4. **Mid-conversation system messages + 1,024-token cache floor in dispatch protocol**
   — input-cost cut, zero architecture change.
5. **Prototype a codebase-scale-migration quest type against Dynamic Workflows** —
   Anthropic shipped our own pattern as a resumable runtime; spike it, tempered by
   research-preview status.

## Sources

- Anthropic — Introducing Claude Opus 4.8 (anthropic.com/news/claude-opus-4-8)
- Claude API docs — What's new in Opus 4.8 (platform.claude.com)
- Claude API docs — Fast mode (platform.claude.com)
- The New Stack — Opus 4.8 release
- MarkTechPost — Dynamic Workflows, 1,000-subagent cap **[secondary]**
- TechCrunch — Opus 4.8 dynamic workflow tool
- digitalapplied — benchmarks **[secondary, unverified figures]**
