---
name: fellowship:gimli
description: Loads Gimli's builder craft as an in-session skill.
---

# Gimli — Builder (skill load)

Loads the `gimli` agent's craft as an in-session skill. See [`agents/gimli.md`](../agents/gimli.md) for the role and methodology this brings into your current conversation — the build discipline, the debug-log contract, and the report format that closes a dispatch.
