# Security policy

## Reporting a vulnerability

Report suspected vulnerabilities in this plugin or in Pi Security privately to **contact@pi.security**. Do not open a public GitHub issue for security problems.

We will acknowledge your report and keep you informed as we investigate.

## What not to include in public reports

Never put secrets, credentials, access tokens, customer data, tenant names, or non-public finding details in public issues, pull requests, or discussions. If reproducing a problem requires sensitive material, send it only in your private report to contact@pi.security.
