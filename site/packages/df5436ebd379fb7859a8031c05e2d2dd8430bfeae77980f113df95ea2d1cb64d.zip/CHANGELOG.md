# Changelog

## 0.1.1

- Bound secure-development guidance to one playbook lookup for a stable task.
- Surface missing or adjacent playbook coverage and continue from current repository evidence without retrying, rephrasing, or using generic tenant knowledge as a fallback.
- Reserve one short generic lookup for genuinely necessary threat-model context.

## 0.1.0

Initial release.

- Remote HTTP MCP connector for Pi Security's hosted server (`https://mcp.pi.security/mcp`), authenticated via OAuth.
- Six skills: `investigate-finding`, `review-security-posture`, `remediation-guidance`, `security-design-review`, `ingest-markdown-report`, `secure-development-playbook`.
- Setup, security, and usage documentation.
