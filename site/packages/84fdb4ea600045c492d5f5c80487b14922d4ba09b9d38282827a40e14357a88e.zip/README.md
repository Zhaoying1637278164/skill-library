# Arkas for Claude

Arkas is a personal knowledge library for saving, reading, searching, and connecting material worth keeping. This plugin connects Claude Code and Cowork to the official Arkas remote MCP server and adds workflows for research, curation, and collaborative writing.

## What it includes

- The remote MCP connector at `https://arkas.app/mcp`.
- OAuth-based, revocable access to a whole library, a folder, or a note.
- Skills for researching a library, capturing and organizing knowledge, and safely collaborating on notes.
- An explicit setup skill for connection and authentication problems.

## Requirements

- An Arkas account.
- Network access to `https://arkas.app`.
- Claude Code or Cowork with plugin and remote MCP support.

## Local testing

From the root of the standalone plugin repository:

```bash
claude plugin validate . --strict
claude --plugin-dir .
```

When developing from the private Arkas monorepo, use `./claude-plugin` instead
of `.` in those commands.

In Claude Code, run `/mcp`, connect `arkas`, and complete the browser authorization flow. Review the library or folder scope and requested permissions before approving.

## Example requests

- “Search my Arkas library for notes about local-first software and synthesize the main disagreements.”
- “Save this link in Lecturas and create a short note with the three ideas I should revisit.”
- “Review this shared note and leave suggestions without modifying the text directly.”

## Privacy and support

- Documentation: https://arkas.app/integrations/mcp
- Privacy: https://arkas.app/privacy
- Terms: https://arkas.app/terms
- Support: https://arkas.app/support

Never paste Arkas access tokens into chat or commit them to this repository.
