# Anthropic plugin submission checklist

Public repository: `https://github.com/juanakin-git/arkas-claude-plugin`

## Before submission

1. Verify that all files are publicly readable without authentication.
2. Run `claude plugin validate . --strict` from a clean clone.
3. Test installation, OAuth, every skill, and representative read and write MCP calls.
4. Submit the public GitHub URL through one of Anthropic's plugin forms:
   - `https://claude.ai/admin-settings/directory/submissions/plugins/new`
   - `https://platform.claude.com/plugins/submit`

The plugin and the Connectors Directory listing intentionally reference the same MCP endpoint. Claude deduplicates the tools when both are installed.
