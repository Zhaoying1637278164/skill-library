---
description: Connect and authenticate the Arkas MCP server. Use when Arkas tools are unavailable, disconnected, unauthorized, or need initial setup.
disable-model-invocation: true
---

# Connect Arkas

1. Check whether the Arkas MCP server is connected and whether its tools are available.
2. If authentication is required, open the MCP connection flow and ask the user to sign in to Arkas in the browser.
3. Tell the user to review the selected library or folder scope and the requested read, comment, suggest, write, or organize permissions before approving.
4. After authorization, call the Arkas access-scope tool and summarize the effective scope and permissions.
5. If authorization fails, direct the user to disconnect and reconnect Arkas. Never ask the user to paste an access token into chat.
