---
description: Capture and organize knowledge in Arkas. Use when the user wants to save a link, create or update a note, create a folder, rename an item, or move material within the authorized library scope.
---

# Curate an Arkas library

1. Check the effective scope and permissions. Never claim a write succeeded without a successful Arkas tool result.
2. If the destination is ambiguous and choosing incorrectly would be costly, inspect nearby folders or ask the user for the destination.
3. Before replacing an existing note, read it and preserve material the user did not ask to remove.
4. Use the narrowest matching action: save a link as a link, create prose as a note, and use organize operations only for moves or renames.
5. Do not simulate deletion: Arkas intentionally exposes no delete tool.
6. After mutations, briefly report what was created or changed and where it now lives.
