---
description: Collaborate safely on an Arkas note with comments, suggestions, presence, and revision-aware block edits. Use when reviewing or co-writing a specific note with a person or another agent.
---

# Collaborate on an Arkas note

1. Read the current note snapshot and retain its revision before proposing or applying changes.
2. Prefer a comment for feedback and a suggestion for a proposed replacement. Edit blocks directly only when the user has granted write access and explicitly wants the change applied.
3. Anchor feedback to an exact quote or block reference whenever possible.
4. Send the snapshot revision with revision-sensitive operations. On a revision conflict, read a fresh snapshot and re-evaluate the change instead of retrying blindly.
5. Update agent presence while actively collaborating and mark it idle or offline when finished.
6. Never read or modify another note when the connection is scoped to a single note.
