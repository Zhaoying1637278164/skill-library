<!-- ref: add/error-handling/nextjs.md
     loaded-by: add/SKILL.md
     prereq: Stack = nextjs. Do not invoke this file directly — it is loaded at runtime by the templatecentral:add skill. -->
## Next.js — Error Handling

### Step 0 — Verify context

Look for `<!-- templateCentral: nextjs@` on line 1 of `AGENTS.md`.

If found → proceed to Step 1.

If not found → invoke `templatecentral:migrate`. Once complete, re-check for
the marker.
- Marker now present → proceed to Step 1.
- Still absent (user chose to stop) → exit. Do not generate any files.

**1. Global Error Handler (Already Present)**

The template includes `src/lib/errors/handle-api-error.ts`. Enhance it to include field-level details:

```ts
// src/lib/errors/handle-api-error.ts
import { APIError } from '@/integrations/error';
import { logError } from '@/lib/errors/error-log-handler';
import { NextResponse } from 'next/server';
import { z, ZodError } from 'zod';

const STATUS_MESSAGES: Record<number, string> = {
  400: 'Invalid request',
  401: 'Authentication required',
  403: 'Access denied',
  404: 'Resource not found',
  408: 'Request timed out',
  409: 'Conflict',
  429: 'Too many requests',
  500: 'Internal server error',
  502: 'Service temporarily unavailable',
  503: 'Service temporarily unavailable',
};

interface ErrorResponseBody {
  error: string;
  details?: {
    fieldErrors?: Record<string, string[] | undefined>;
    code?: string;
  };
}

export const handleApiError = (
  label: string,
  error: unknown,
  fieldErrors?: Record<string, string[] | undefined>
): NextResponse<ErrorResponseBody> => {
  logError(label, error);

  if (error instanceof APIError) {
    const status = error.statusCode;
    const message = STATUS_MESSAGES[status] ?? label;
    const response: ErrorResponseBody = { error: message };

    if (fieldErrors) {
      response.details = { fieldErrors };
    }

    return NextResponse.json(response, { status });
  }

  if (error instanceof ZodError) {
    const fieldErrors = z.flattenError(error).fieldErrors;
    return NextResponse.json(
      {
        error: 'Validation failed',
        details: { fieldErrors, code: 'VALIDATION_ERROR' },
      },
      { status: 400 }
    );
  }

  return NextResponse.json(
    { error: label },
    { status: 500 }
  );
};
```

**2. API Route Example with Validation**

```ts
// src/app/api/projects/route.ts
import { handleApiError } from '@/lib/errors';
import { withLogging } from '@/lib/utils/with-logging';
import { NextResponse } from 'next/server';
import { z } from 'zod';

const CreateProjectSchema = z.object({
  name: z.string().min(1, 'Name is required').max(100, 'Name must be under 100 characters'),
  description: z.string().max(500).optional(),
});

export const POST = withLogging(async (request) => {
  try {
    const body = await request.json();
    const parsed = CreateProjectSchema.safeParse(body);

    if (!parsed.success) {
      // ZodError branch derives fieldErrors itself — no third argument needed
      return handleApiError('Failed to create project', parsed.error);
    }

    // Your logic here: const [project] = await db.insert(projects).values(parsed.data).returning()
    const project = { id: '1', ...parsed.data };

    return NextResponse.json({ data: project }, { status: 201 });
  } catch (error) {
    return handleApiError('Failed to create project', error);
  }
});
```

**2b. Dynamic Route with Unauthorized Access (404 Pattern)**

Rule #9: Return 404 for both missing resources AND unauthorized access (never reveal whether resource exists):

```ts
// src/app/api/projects/[id]/route.ts
import { auth } from '@/lib/auth';
import { handleApiError } from '@/lib/errors';
import { type RouteContext, withLogging } from '@/lib/utils/with-logging';
import { NextResponse } from 'next/server';

export const GET = withLogging<RouteContext<{ id: string }>>(async (request, { params }) => {
  try {
    const { id } = await params;
    const session = await auth.api.getSession({ headers: request.headers });

    // Check project exists AND user has access
    // replace with real DB lookup
    const project = { id, name: 'Sample', ownerId: 'user-1' };

    // Return 404 for BOTH missing AND unauthorized (same response)
    // Never say "you don't have access" — could reveal resource exists
    if (!project || project.ownerId !== session?.user?.id) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    return NextResponse.json({ data: project });
  } catch (error) {
    return handleApiError('Failed to fetch project', error);
  }
});
```

**3. Error Boundary Components**

Both boundaries below render the same failure state, so it lives in one component. Keeping it separate also makes the fallback renderable in isolation — a Storybook story or a test can mount it without throwing anything:

```tsx
// src/components/layout/error-fallback.tsx
'use client';

import { Button } from '@/components/ui/button';

interface ErrorFallbackProps {
  error: Error;
  onReset: () => void;
}

export function ErrorFallback({ error, onReset }: ErrorFallbackProps) {
  return (
    <div
      role="alert"
      className="flex min-h-screen flex-col items-center justify-center gap-4 p-6 text-center"
    >
      <h1 className="text-2xl font-bold">Something went wrong</h1>
      <p className="text-muted-foreground max-w-md text-sm">
        {process.env.NODE_ENV === 'development'
          ? error.message
          : 'An unexpected error occurred. Please try again later.'}
      </p>
      <Button type="button" onClick={onReset}>
        Reload page
      </Button>
    </div>
  );
}
```

Class-based `ErrorBoundary` for catching synchronous React render errors:

```tsx
// src/components/layout/error-boundary.tsx
'use client';

import { Component, type ErrorInfo, type ReactNode } from 'react';
import { logError } from '@/lib/errors/error-log-handler';
import { ErrorFallback } from './error-fallback';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  // getDerivedStateFromError only updates state — reporting belongs here, or every
  // caught render error is swallowed and never reaches the logger.
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    logError('ErrorBoundary caught an error', error);
    if (process.env.NODE_ENV === 'development') {
      console.error('Component stack:', errorInfo.componentStack);
    }
  }

  render() {
    if (this.state.error) {
      if (this.props.fallback) return this.props.fallback;

      return (
        <ErrorFallback error={this.state.error} onReset={() => window.location.reload()} />
      );
    }

    return this.props.children;
  }
}
```

Functional `AsyncErrorBoundary` for catching unhandled promise rejections:

```tsx
// src/components/layout/error-boundary-async.tsx
'use client';

import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { ErrorFallback } from './error-fallback';

interface AsyncErrorBoundaryProps {
  children: ReactNode;
}

export function AsyncErrorBoundary({ children }: AsyncErrorBoundaryProps) {
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      const reason: unknown = event.reason;
      setError(reason instanceof Error ? reason : new Error('An error occurred'));
    };

    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    return () => window.removeEventListener('unhandledrejection', handleUnhandledRejection);
  }, []);

  if (error) {
    return <ErrorFallback error={error} onReset={() => window.location.reload()} />;
  }

  return <>{children}</>;
}
```

## Validate

```bash
# Test API route with validation error
curl -X POST http://localhost:3000/api/projects \
  -H "Content-Type: application/json" \
  -d '{"name": ""}'

# Expected 400 response:
# {
#   "error": "Validation failed",
#   "details": {
#     "fieldErrors": {
#       "name": ["Name is required"]
#     },
#     "code": "VALIDATION_ERROR"
#   }
# }

pnpm test
pnpm build

# Test error boundary (client-side)
pnpm dev
# Trigger unhandled error in browser console, verify error boundary displays
```

### Next.js Error Boundary Tests

> **Deps not in scaffold**: Run `pnpm add -D @testing-library/react @testing-library/jest-dom jsdom` first. Also add `environment: 'jsdom'` to `vitest.config.ts` test options (or use the inline `@vitest-environment jsdom` comment).

```typescript
// test/error-boundary.test.tsx
// @vitest-environment jsdom
import '@testing-library/jest-dom';
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { ErrorBoundary } from '@/components/layout/error-boundary';

describe('ErrorBoundary', () => {
  it('displays fallback UI when render error occurs', () => {
    const ThrowComponent = () => {
      throw new Error('Test error');
    };

    render(
      <ErrorBoundary>
        <ThrowComponent />
      </ErrorBoundary>
    );

    // In development, error message is shown
    if (process.env.NODE_ENV === 'development') {
      expect(screen.getByText(/Test error/)).toBeInTheDocument();
    } else {
      // In production, generic message is shown
      expect(screen.getByText(/unexpected error/i)).toBeInTheDocument();
    }
  });

  it('shows reload button', () => {
    const ThrowComponent = () => {
      throw new Error('Test');
    };

    render(
      <ErrorBoundary>
        <ThrowComponent />
      </ErrorBoundary>
    );

    expect(screen.getByRole('button', { name: /reload/i })).toBeInTheDocument();
  });
});
```

## After Writing Code

Dispatch in order:
1. the build utility — load it with: `cat "<skill-dir>/../build/SKILL.md"` — validate compilation
2. the review utility — load it with: `cat "<skill-dir>/../review/SKILL.md"` — check code standards