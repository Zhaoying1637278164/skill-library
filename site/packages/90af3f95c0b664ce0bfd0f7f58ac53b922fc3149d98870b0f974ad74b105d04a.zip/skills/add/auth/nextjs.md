<!-- ref: add/auth/nextjs.md
     loaded-by: add/SKILL.md
     prereq: Stack = Next.js. Do not invoke this file directly — it is loaded at runtime by the templatecentral:add skill. -->
## Next.js

Add authentication to a Next.js project scaffolded from templateCentral. Uses **better-auth** — a TypeScript-first auth library with full type safety, SSO, and email/password support.

### Prerequisites

Requires a project scaffolded with `templatecentral:scaffold`. See Step 0.

> **Security requirement**: meet the Next.js floor in `.claude/rules/nextjs.md` — two separate high-severity advisories have shipped fixes for Turbopack `proxy.ts`/middleware auth bypasses (an RSC prefetch bypass, and a July 2026 single-locale middleware bypass), so an outdated pin can silently defeat the auth this skill sets up. Verify `package.json` → `next` before proceeding.

### Files this skill creates

```
src/
├── lib/
│   ├── auth.ts                                        ← better-auth server config (verbatim — do not generate)
│   └── auth-client.ts                                 ← better-auth client config (verbatim — do not generate)
├── proxy.ts                                           ← route protection middleware (verbatim — do not generate)
└── app/
    ├── api/
    │   └── auth/
    │       └── [...all]/
    │           └── route.ts
    ├── (public)/
    │   └── login/
    │       └── page.tsx
    └── dashboard/           ← only if not already created by scaffold
        ├── layout.tsx
        └── (overview)/
            └── page.tsx
src/features/
└── auth/
    ├── components/
    │   ├── login-card.tsx
    │   ├── login-button.tsx
    │   ├── signout-button.tsx
    │   └── index.ts
    └── index.ts
```

### Files this skill modifies

```
.env.example                         ← adds BETTER_AUTH_SECRET, BETTER_AUTH_URL, NEXT_PUBLIC_APP_NAME, NEXT_PUBLIC_APP_URL
.env.local                           ← same vars (fill actual values)
src/lib/constants/routes.ts          ← adds PAGE_ROUTES.LOGIN (HOME and DASHBOARD already exist from scaffold)
AGENTS.md                            ← adds auth architecture notes
```

> **`providers.tsx` does NOT need modification** — better-auth manages session state via `authClient.useSession()`; no `SessionProvider` wrapper is required.

### Steps

#### Step 0 — Verify context

Look for `<!-- templateCentral: nextjs@` on line 1 of `AGENTS.md`.

If found → proceed to Step 1.

If not found → invoke `templatecentral:migrate`. Once complete, re-check for
the marker.
- Marker now present → proceed to Step 1.
- Still absent (user chose to stop) → exit. Do not generate any files.

#### 1. Install better-auth

```bash
pnpm add better-auth
```

#### 2. Write `src/lib/auth.ts` (verbatim — do not generate)

Security-critical file. Write exactly as shown.

```ts
import { betterAuth } from 'better-auth';
import { nextCookies } from 'better-auth/next-js';

if (!process.env.BETTER_AUTH_SECRET) {
  throw new Error('BETTER_AUTH_SECRET environment variable is required — generate with: openssl rand -base64 32');
}

export const auth = betterAuth({
  appName: process.env.NEXT_PUBLIC_APP_NAME ?? 'My App',
  baseURL: process.env.BETTER_AUTH_URL,
  secret: process.env.BETTER_AUTH_SECRET,

  emailAndPassword: {
    enabled: true,
    // SSO only in prod; dev can sign up
    disableSignUp: process.env.NODE_ENV === 'production',
    // OWASP: without MFA, treat <15 chars as weak — this config has no MFA enabled
    minPasswordLength: 15,
    autoSignIn: true,
  },

  socialProviders: {
    // --- Add your SSO providers here ---
    // Uncomment and supply env vars for each provider you want to enable.
    //
    // google: {
    //   clientId: process.env.GOOGLE_CLIENT_ID!,
    //   clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    // },
    // github: {
    //   clientId: process.env.GITHUB_CLIENT_ID!,
    //   clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    // },
    // microsoft: {
    //   clientId: process.env.MICROSOFT_CLIENT_ID!,
    //   clientSecret: process.env.MICROSOFT_CLIENT_SECRET!,
    //   tenantId: 'common', // or a specific tenant ID for single-tenant apps
    // },
  },

  session: {
    // 30 days (standard) — elevated sessions reduce to 43200 (12h) + 30-min inactivity; high-assurance use 28800 (8h) + 15-min inactivity
    expiresIn: 30 * 24 * 60 * 60,
    // refresh after 1 day of activity
    updateAge: 24 * 60 * 60,
    // freshAge: 43200,            // uncomment for high-assurance flows — forces re-auth after this period (see note below)
    cookieCache: {
      enabled: true,
      // 5-minute client-side cache
      maxAge: 5 * 60,
    },
  },

  advanced: {
    defaultCookieAttributes: {
      sameSite: 'lax',
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
    },
  },

  // must be last
  plugins: [nextCookies()],
});
```

> `freshAge` is measured from session `createdAt`, not last activity. If you uncomment a short `freshAge` (e.g. 43200 for elevated-assurance flows), users must re-authenticate after that period regardless of activity — this is the intended behavior for high-security flows.

> **Database**: Without a `database` option, better-auth falls back to an in-memory adapter — accounts and sessions live in server process memory only. This is **not** a persistent stateless-cookie mode: everything is lost on every restart/redeploy, and it does not work across multiple instances (serverless, multi-replica deployments). The JWE-encrypted `cookieCache` is only a short-lived (5-minute) read-through cache in front of this store, not a replacement for it. Add a database adapter after running `templatecentral:add` (database) before anything beyond quick local prototyping. The Drizzle adapter is a separate package (`@better-auth/drizzle-adapter` — install alongside `drizzle-orm`). See [better-auth database docs](https://www.better-auth.com/docs/concepts/database).

> **Password hashing**: better-auth's default hasher is scrypt, not argon2id. To use argon2id instead, install `@node-rs/argon2` and override `emailAndPassword.password.hash`/`.verify`:
> ```ts
> import { hash, verify, type Options } from '@node-rs/argon2';
>
> const opts: Options = { memoryCost: 65536, timeCost: 3, parallelism: 4, outputLen: 32, algorithm: 2 };
>
> emailAndPassword: {
>   // ...other options
>   password: {
>     hash: (password) => hash(password, opts),
>     verify: ({ hash: h, password }) => verify(h, password, opts),
>   },
> },
> ```

#### 3. Write `src/lib/auth-client.ts` (verbatim — do not generate)

```ts
import { createAuthClient } from 'better-auth/react';

export const authClient = createAuthClient({
  baseURL: process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000',
});
```

#### 4. Write `src/proxy.ts` (verbatim — do not generate)

Security-critical file. Write exactly as shown.

```ts
import { getSessionCookie } from 'better-auth/cookies';
import { API_ROUTES, PAGE_ROUTES } from '@/lib/constants/routes';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

const PUBLIC_PATHS = new Set<string>([PAGE_ROUTES.HOME, PAGE_ROUTES.LOGIN]);
const PUBLIC_API_PREFIXES = ['/api/auth', API_ROUTES.HEALTH];

function isApiRoute(pathname: string): boolean {
  return pathname.startsWith('/api/');
}

function isPublicRoute(pathname: string): boolean {
  return (
    PUBLIC_PATHS.has(pathname) ||
    PUBLIC_API_PREFIXES.some((p) => pathname.startsWith(p))
  );
}

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Short-circuit for public routes that are not the login page
  if (isPublicRoute(pathname) && pathname !== PAGE_ROUTES.LOGIN) {
    return NextResponse.next();
  }

  // Optimistic check ONLY. getSessionCookie reads the cookie's presence with no
  // database call — this avoids a DB/session round-trip at the routing layer on every
  // request, keeping proxy latency low. It gates routing and redirects; it does NOT
  // validate the session (a forged cookie passes). The authoritative check MUST run
  // server-side in the protected layout (see step 8).
  const hasSession = getSessionCookie(req) != null;

  // Handle /login: redirect users who appear signed in to the dashboard, allow others through
  if (pathname === PAGE_ROUTES.LOGIN) {
    if (hasSession) {
      return NextResponse.redirect(new URL(PAGE_ROUTES.DASHBOARD, req.url));
    }
    return NextResponse.next();
  }

  // Protected routes: require a session cookie (authoritative validation happens in the layout)
  if (!hasSession) {
    if (isApiRoute(pathname)) {
      return new Response(null, { status: 401 });
    }
    return NextResponse.redirect(new URL(PAGE_ROUTES.LOGIN, req.url));
  }

  return NextResponse.next();
}

// Never configure a single-entry `i18n.locales` list — a high-severity security
// advisory covers exactly that shape: a single-locale list under Turbopack can skip
// the proxy entirely, so every auth check here silently stops running. If you add
// i18n routing, re-verify the proxy still executes on every matched path.
// See the Next.js floor in .claude/rules/nextjs.md.
export const config = {
  matcher: [
    '/((?!_next/static|_next/image|.*\\.(?:svg|png|jpg|jpeg|gif|ico|webp)$).*)',
  ],
};
```

#### 5. Create `src/app/api/auth/[...all]/route.ts`

```ts
import { auth } from '@/lib/auth';
import { toNextJsHandler } from 'better-auth/next-js';

export const { GET, POST } = toNextJsHandler(auth);
```

#### 6. Add `PAGE_ROUTES.LOGIN` to `src/lib/constants/routes.ts`

Add `LOGIN` to the existing `PAGE_ROUTES` object. `HOME` and `DASHBOARD` are already present from the scaffold — do not add them again:

```ts
export const PAGE_ROUTES = {
  // ... existing HOME: '/' and DASHBOARD: '/dashboard' entries
  LOGIN: '/login',
} as const;
```

#### 7. Create `src/app/(public)/login/page.tsx`

```tsx
import { LoginCard } from '@/features/auth';

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center">
      <LoginCard />
    </main>
  );
}
```

#### 8. Create `src/app/dashboard/layout.tsx` (skip if already exists)

> If `src/app/dashboard/layout.tsx` already exists (present when scaffolded with templateCentral), **add the authoritative session check below to it** — do not rely on `proxy.ts` alone. The proxy does only an optimistic cookie-presence check (no session validation); `/dashboard` is genuinely protected only once this server-side check is in the layout. Every protected route group needs one.

```tsx
import { auth } from '@/lib/auth';
import { Navbar } from '@/components/layout/navbar';
import { SiteFooter } from '@/components/layout/site-footer';
import { PAGE_ROUTES } from '@/lib/constants/routes';
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  // Authoritative gate. proxy.ts only checks cookie presence to keep routing fast; this
  // verifies the session's signature and, when the cookie cache is cold, revalidates it
  // against the store. Without this, a forged cookie would pass the proxy and reach
  // protected content. Note: with `cookieCache.enabled: true` (maxAge 5 min) this can be
  // served from the signed cookie without touching the store, so revocation and lockout
  // take effect only after that window — set `cookieCache.enabled: false` in
  // src/lib/auth.ts for high-assurance flows that need immediate revocation.
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session) {
    redirect(PAGE_ROUTES.LOGIN);
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}
```

#### 9. Create `src/app/dashboard/(overview)/page.tsx` (skip if already exists)

> **Skip this step** if `src/app/dashboard/(overview)/page.tsx` already exists — present when the project was scaffolded with templateCentral. The existing page shows the `ExampleList` component; the cleanup utility (`cat "<skill-dir>/../cleanup/SKILL.md"`) cleans it up when the user is ready.

If creating fresh (non-scaffold project):

```tsx
export default function DashboardPage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold">Dashboard</h1>
    </div>
  );
}
```

#### 10. Create `src/features/auth/` components

**`src/features/auth/components/login-button.tsx`** — SSO sign-in:

```tsx
'use client';

import { authClient } from '@/lib/auth-client';
import type { ComponentProps } from 'react';

import { Button } from '@/components/ui/button';

interface LoginButtonProps extends ComponentProps<typeof Button> {
  provider: 'google' | 'github' | 'microsoft';
  callbackURL?: string;
  label?: string;
}

export function LoginButton({
  provider,
  callbackURL = '/dashboard',
  label = 'Sign in',
  ...buttonProps
}: LoginButtonProps) {
  return (
    <Button
      onClick={() => authClient.signIn.social({ provider, callbackURL })}
      {...buttonProps}
    >
      {label}
    </Button>
  );
}
```

**`src/features/auth/components/signout-button.tsx`:**

```tsx
'use client';

import { authClient } from '@/lib/auth-client';
import { useRouter } from 'next/navigation';
import type { ComponentProps } from 'react';

import { Button } from '@/components/ui/button';

interface SignOutButtonProps extends ComponentProps<typeof Button> {
  redirectTo?: string;
}

export function SignOutButton({
  redirectTo = '/',
  children = 'Sign out',
  ...buttonProps
}: SignOutButtonProps) {
  const router = useRouter();

  async function handleSignOut() {
    await authClient.signOut();
    router.push(redirectTo);
  }

  return (
    <Button onClick={handleSignOut} {...buttonProps}>
      {children}
    </Button>
  );
}
```

**`src/features/auth/components/login-card.tsx`:**

```tsx
'use client';

import { authClient } from '@/lib/auth-client';
import { isDev } from '@/lib/constants/env';
import { PAGE_ROUTES } from '@/lib/constants/routes';
import { useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import { CustomCard } from '@/components/widgets/custom-card';

// better-auth's email validator rejects single-label domains — 'dev@local' fails with
// INVALID_EMAIL on both sign-in and sign-up. Use a dotted domain.
const DEV_EMAIL = 'dev@dev.local';
// eslint-disable-next-line sonarjs/no-hardcoded-passwords -- isDev-gated dev-only login, not a real credential
const DEV_PASSWORD = 'dev-password-local';

export function LoginCard() {
  const router = useRouter();

  async function handleDevLogin() {
    const { error } = await authClient.signIn.email({
      email: DEV_EMAIL,
      password: DEV_PASSWORD,
    });

    if (error) {
      // First run: account does not exist yet — create it (autoSignIn: true signs in immediately)
      const { error: signUpError } = await authClient.signUp.email({
        email: DEV_EMAIL,
        password: DEV_PASSWORD,
        name: 'Dev User',
      });
      if (signUpError) {
        console.error('Dev login failed:', signUpError.message);
        return;
      }
    }

    router.push(PAGE_ROUTES.DASHBOARD);
  }

  return (
    <CustomCard header="Sign in" className="w-full max-w-sm">
      <div className="flex flex-col gap-3">
        {/* Add SSO provider buttons here — import LoginButton and render one per provider */}
        {isDev && (
          <Button onClick={handleDevLogin} variant="outline">
            Dev login (bypass auth)
          </Button>
        )}
      </div>
    </CustomCard>
  );
}
```

**`src/features/auth/components/index.ts`:**

```ts
export { LoginButton } from './login-button';
export { LoginCard } from './login-card';
export { SignOutButton } from './signout-button';
```

**`src/features/auth/index.ts`:**

```ts
export * from './components';
```

#### 11. Update `.env.example` and `.env.local`

Add to both files:

```
# Auth — REQUIRED: generate secret with: openssl rand -base64 32
# WARNING: BETTER_AUTH_SECRET must be set in production — sessions are insecure without it
BETTER_AUTH_URL=http://localhost:3000
BETTER_AUTH_SECRET=

# App — used by auth.ts (appName) and auth-client.ts (baseURL)
NEXT_PUBLIC_APP_NAME=My App
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Auth Providers (uncomment and fill for your provider)
# Google
# GOOGLE_CLIENT_ID=
# GOOGLE_CLIENT_SECRET=

# GitHub
# GITHUB_CLIENT_ID=
# GITHUB_CLIENT_SECRET=

# Microsoft Entra ID
# MICROSOFT_CLIENT_ID=
# MICROSOFT_CLIENT_SECRET=

# Rate limiting (only if using the @upstash/ratelimit example — Redis.fromEnv() reads these)
# UPSTASH_REDIS_REST_URL=
# UPSTASH_REDIS_REST_TOKEN=
```

#### 12. Update project `AGENTS.md`

Add under `## Architecture Decisions`:

```markdown
- Auth via better-auth with `proxy.ts` route protection (`export async function proxy`); dev bypass with email/password when `isDev`
- `authClient` (src/lib/auth-client.ts) handles client-side session via `authClient.useSession()` — no SessionProvider needed
- Route groups: `(public)/` for public pages, `dashboard/` for authenticated pages
- Sessions: in-memory (non-persistent, single-instance) by default; add database adapter (via templatecentral:add (database)) before anything beyond local prototyping
```

#### 13. Session usage patterns

**Server Component or API route:**

```ts
import { auth } from '@/lib/auth';
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';

const session = await auth.api.getSession({ headers: await headers() });
if (!session) redirect(PAGE_ROUTES.LOGIN);

const { user } = session;
// user.id, user.name, user.email, user.image
```

**Unauthenticated API response (never JSON — information-disclosure risk):**

```ts
if (!session) return new Response(null, { status: 401 });
```

**Client Component hook:**

```tsx
'use client';

import { authClient } from '@/lib/auth-client';

export function UserAvatar() {
  const { data: session, isPending } = authClient.useSession();

  if (isPending) return <Skeleton />;
  if (!session) return null;

  return <Avatar name={session.user.name} image={session.user.image} />;
}
```

#### 14. Adding an SSO provider

Uncomment the relevant block in `src/lib/auth.ts` and add credentials to `.env.local`. Then add a `<LoginButton provider="..." />` in `src/features/auth/components/login-card.tsx`.

| Provider | Config key | Required env vars | Callback URL |
|----------|------------|-------------------|--------------|
| Google | `google` | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | `/api/auth/callback/google` |
| GitHub | `github` | `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET` | `/api/auth/callback/github` |
| Microsoft | `microsoft` | `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET` | `/api/auth/callback/microsoft` |

Full provider list: https://www.better-auth.com/docs/authentication/social-sign-on

> **OIDC provider (token issuer)**: If your project needs to act as an OIDC provider (issuing tokens to third-party clients), use `@better-auth/oauth-provider` — the `oidc-provider` plugin is deprecated for removal in an upcoming release, so migrate to `@better-auth/oauth-provider`. See: https://www.better-auth.com/docs/plugins/oauth-provider

### Rate Limiting (Required for Production)

Industry best practice: max 3 auth attempts per 15 minutes. better-auth does not include built-in rate limiting — add it at the infrastructure layer (CDN/WAF/API Gateway) or in `proxy.ts` middleware using `@upstash/ratelimit` (Redis-backed, edge-compatible):

```bash
pnpm add @upstash/ratelimit @upstash/redis
```

In `src/proxy.ts`, add a rate-limit check at the **top of `proxy()`**, before the public-route short-circuit. Placement matters: every `/api/auth/*` endpoint matches `PUBLIC_API_PREFIXES` (`/api/auth`), so the short-circuit returns `NextResponse.next()` before the auth call ever runs — a limiter placed after it would be unreachable.

```typescript
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// Max 3 attempts per 15 minutes, per client IP
const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(3, '15 m'),
  prefix: 'auth:credentials',
});

// Every credential-accepting auth endpoint, not just sign-in: sign-up, password
// reset and forgot-password are equally brute-forceable and all sit under the
// /api/auth public prefix.
const RATE_LIMITED_AUTH_PATHS = [
  '/api/auth/sign-in',
  '/api/auth/sign-up',
  '/api/auth/forget-password',
  '/api/auth/reset-password',
];

// TRUST_PROXY = number of trusted proxy hops (1 = ALB → App, 2 = ALB →
// Traefik → App); empty/unset = X-Forwarded-For is not trusted.
// Returns null when no trustworthy client IP can be derived.
function getRateLimitKey(req: NextRequest): string | null {
  const hops = Number(process.env.TRUST_PROXY);
  if (!hops) return null;
  const entries = (req.headers.get('x-forwarded-for') ?? '')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
  // Take the right-most entry that is not a trusted hop: each trusted proxy
  // appends exactly one entry, so with one hop the client IP is the last
  // entry, with two hops the second-to-last. Anything further left is
  // client-forgeable.
  return entries[entries.length - hops] ?? null;
}

// At the top of proxy(), immediately after `const { pathname } = req.nextUrl;`
// and BEFORE the isPublicRoute() short-circuit (which would otherwise return
// NextResponse.next() for /api/auth/* and skip this check entirely):
if (RATE_LIMITED_AUTH_PATHS.some((p) => req.nextUrl.pathname.startsWith(p))) {
  // Fail closed when no trustworthy client IP exists (TRUST_PROXY unset or
  // header missing): all such requests share one bucket, keeping the endpoint
  // throttled instead of wide open. Fix the deployment topology — never fall
  // back to a client-supplied header.
  const key = getRateLimitKey(req) ?? 'untrusted';
  const { success } = await ratelimit.limit(key);
  if (!success) return new Response(null, { status: 429 });
}
```

> **TRUST_PROXY required**: Only trust `X-Forwarded-For` if your deployment topology has a controlled reverse proxy (ALB, Traefik). Without a proxy, any client can forge `X-Forwarded-For` to bypass rate limits. Set `TRUST_PROXY` to the number of trusted proxy hops — `TRUST_PROXY=1` for one-hop (ALB → App), `TRUST_PROXY=2` for two-hop (ALB → Traefik → App); leave it empty/unset when there is no proxy (headers not trusted). See the scaffold's `src/lib/utils/request-origin.ts` for the same convention.

For simpler setups without Redis, use `next-rate-limit` with in-memory state (not suitable for multi-instance deployments).

### Security Rules

- NEVER return JSON from `proxy.ts` for unauthorized API routes — use `new Response(null, { status: 401 })`. JSON responses create information-disclosure vectors.
- NEVER remove `disableSignUp: process.env.NODE_ENV === 'production'` — open registration in production is a security risk unless intentional.
- NEVER remove the `isDev` guard on the dev login button — it must only render in development.
- NEVER hardcode secrets — always environment variables.
- NEVER expose `BETTER_AUTH_SECRET` in `NEXT_PUBLIC_*` vars — exposed to every browser.
- Always generate `BETTER_AUTH_SECRET` with `openssl rand -base64 32` — never use a weak or predictable value.
- **Rate limiting is mandatory for production** — add rate limiting on auth endpoints before going live.
- **Password hashing**: better-auth's default hasher is scrypt, not argon2id — override `emailAndPassword.password.hash`/`.verify` with `@node-rs/argon2` (see Step 2) to match this project's argon2id-everywhere standard.
- **Breached-password check**: current password-hygiene guidance recommends rejecting passwords found in known-breach lists at creation/change time, in addition to the length floor — check candidates against a blocklist (e.g. the Have I Been Pwned k-anonymity range API) in the sign-up flow before calling `authClient.signUp.email()`.

### After Writing Code

Dispatch in order:
1. the build utility — load it with: `cat "<skill-dir>/../build/SKILL.md"` — validate compilation
2. the review utility — load it with: `cat "<skill-dir>/../review/SKILL.md"` — check code standards

---
