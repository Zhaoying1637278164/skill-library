<!-- ref: add/test/fastapi.md
     loaded-by: add/SKILL.md
     prereq: Stack = FastAPI. Do not invoke this file directly — it is loaded at runtime by the templatecentral:add skill. -->
## FastAPI

Guide for writing tests in a FastAPI project scaffolded from templateCentral.

**Policy**: Same-change pytest for new/changed API code (root `AGENTS.md`, `code-standards/`).

### Prerequisites

Requires a project scaffolded with `templatecentral:scaffold`. See Step 0.

### Steps

#### Step 0 — Verify context

Look for `<!-- templateCentral: fastapi@` on line 1 of `AGENTS.md`.

If found → proceed to context check below.

If not found → invoke `templatecentral:migrate`. Once complete, re-check for
the marker.
- Marker now present → proceed to context check below.
- Still absent (user chose to stop) → exit. Do not generate any files.

**Context check:** Confirm `src/api/routers/` contains at least one `.py` file.

If not found → ⛔ STOP. Tell the user: "No routers found. Run
`templatecentral:add` (endpoint) first, then return here."

If found → proceed to the sections below.

### Test Structure

Tests mirror `src/`:

```
test/
├── conftest.py           # Shared fixtures (TestClient) — created by scaffold
├── factories/            # Factory functions for test data
│   └── models.py
└── test_api/             # API endpoint tests
    └── test_<endpoint>.py
```

Add directories as needed: `test_services/` (business logic), `test_models/` (domain models), `test_utils/` (utilities).

### Fixtures

The scaffold generates `test/conftest.py` with a `client` fixture:

```python
"""Root conftest — shared fixtures available to all tests."""

from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient

from app import app


@pytest.fixture
def client() -> Generator[TestClient]:
    """FastAPI test client."""
    with TestClient(app) as client:
        yield client
```

Extend it for database tests by overriding dependencies:

```python
# test/conftest.py — add after the existing client fixture

@pytest.fixture
def db_client() -> Generator[TestClient]:
    """TestClient with a clean in-memory database for each test."""
    from database.session import get_db
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy.pool import StaticPool
    from database.base import Base

    # StaticPool + check_same_thread=False are mandatory here: SQLite's
    # in-memory database lives inside a single connection, and TestClient
    # runs the app in a different thread. The default pool hands that thread
    # a fresh, empty database and every test fails with "no such table".
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    TestSession = sessionmaker(bind=engine)
    session = TestSession()
    app.dependency_overrides[get_db] = lambda: session

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()
    session.close()
```

### Test File Layout

1. Module docstring
2. Imports (stdlib → third-party → local)
3. File-local fixtures
4. Test functions

### Naming

- Functions: `test_<subject>_<scenario>`
- Always provide a one-line docstring describing expected behavior.

```python
@pytest.mark.unit
def test_example_rejects_invalid_payload(client: TestClient) -> None:
    """POST /example with missing required field returns 422."""
    response = client.post("/example", json={})
    assert response.status_code == 422
    errors = response.json()["detail"]
    assert any("name" in str(e) for e in errors)
```

### Factories

Create factory functions in `test/factories/` with sensible defaults:

```python
def create_example_request(
    name: str = "World",
    repeat_count: int = 1,
) -> dict:
    """Create an example request payload with camelCase keys (matching API contract)."""
    return {"name": name, "repeatCount": repeat_count}
```

> **Why camelCase keys**: `BaseSchema` uses `alias_generator=to_camel`, so the API expects camelCase JSON. Factory return values must use camelCase keys (e.g., `"repeatCount"`) even though Python params use snake_case.

Rules:
- Sensible defaults; composable; use real constants where appropriate.
- Create new factories when objects have many fields or are reused with variations.
- Always use **camelCase keys** in factory dicts — they represent the API's JSON contract.

### Assertions

- One main concept per test.
- Assert before and after when testing mutations.
- Use `pytest.raises(..., match="...")` for exceptions — always include `match`.

### Parametrize

Use for tests that differ only by input/output:

```python
@pytest.mark.parametrize(
    "age, expected",
    [(54, False), (55, True), (65, True)],
    ids=["below-55", "at-55", "at-65"],
)
def test_is_eligible(age: int, expected: bool) -> None:
    """Eligibility check based on age."""
    assert is_eligible(age) == expected
```

### Mocking

- **Prefer real objects** via factories.
- Use `monkeypatch` over `unittest.mock.patch`.
- Mock only for uncontrollable side effects (network, filesystem, time).

### Running Tests

```bash
python -m pytest test/                    # All tests
python -m pytest test/ -m unit            # Unit tests only
python -m pytest test/ -m end_to_end      # E2E tests only
python -m pytest test/test_api/           # API tests only
```

### Independence

- No shared mutable state; each test constructs its own data.
- Tests should pass in any order or in isolation.

### Rules

- NEVER share mutable state between tests — each test constructs its own data
- NEVER use `unittest.mock.patch` when `monkeypatch` is available — prefer pytest idioms
- NEVER mock what you own — use real objects via factories; mock only external side effects
- NEVER depend on test execution order — tests must pass in any order or in isolation

## After Writing Code

Dispatch in order:
1. the build utility — load it with: `cat "<skill-dir>/../build/SKILL.md"` — validate compilation
2. the review utility — load it with: `cat "<skill-dir>/../review/SKILL.md"` — check code standards