<!-- ref: tc-write-skill/implementation.md
     loaded-by: tc-write-skill/SKILL.md
     prereq: Skill authoring checklist. Do not invoke this file directly — it is loaded at runtime by the /tc-write-skill skill. -->

# Write a templateCentral Skill

1. **Read CONVENTIONS.md** (repo-relative — run from the repo root):
   ```
   cat skills/CONVENTIONS.md
   ```

2. **Determine file type:**
   - Registered skill (`SKILL.md` at skill root)? → Enforce constraints (Section 3)
   - Reference file? → Enforce header format (Section 4)

3. **If SKILL.md (registered skill):**
   - Description ≤ 150 characters (count carefully)
   - Body ≤ 30 lines (excluding frontmatter)
   - No inline implementation content
   - Only: detection logic, routing table, `cat` commands
   - Add `when_to_use:` if the description alone doesn't capture all trigger contexts
   - Add `disable-model-invocation: true` for scaffold/migrate/cleanup-scope skills
   - Add `allowed-tools:` with tightest scope needed (e.g. `Bash(pnpm *)` not `Bash`) — Least Agency principle (OWASP Agentic ASI02: Tool Misuse & Exploitation)

4. **If reference file:**
   - First line: `<!-- ref: ... loaded-by: ... prereq: ... -->`
   - End `prereq:` with: "Do not invoke this file directly."
   - Check nesting level (Section 2): 2-level or 3-level?

5. **Check for duplicates:**
   - Does this skill/content already exist elsewhere?
   - Can it be merged into an existing registered skill?

6. **After writing:**
   - Run `/tc-audit` to verify compliance
