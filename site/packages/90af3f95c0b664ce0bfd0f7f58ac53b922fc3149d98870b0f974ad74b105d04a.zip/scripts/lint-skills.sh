#!/usr/bin/env bash
# scripts/lint-skills.sh — mechanical pattern checks for templateCentral skills
#
# Run locally:  bash scripts/lint-skills.sh
# Run in CI:    bash scripts/lint-skills.sh
#
# HOW TO ADD A NEW CHECK
# 1. Write a check_* function following the pattern below.
# 2. Add a comment explaining WHY the pattern is banned and when to revisit it.
# 3. Call the function in the "Run all checks" section at the bottom.
# 4. If it's ecosystem-era (tied to a specific stack version), mark it ECOSYSTEM-ERA
#    so future maintainers know to revisit it when the stack upgrades.
#
# TIMELESS checks: always wrong regardless of stack version.
# ECOSYSTEM-ERA checks: correct for the current stack; review on major upgrades.

set -euo pipefail

SKILLS_DIR="${1:-skills}"
FAILED=0

# HARNESS_SCHEMA_VERSION — the AGENTS.md line-1 marker (`<!-- templateCentral: <stack>@X.Y.Z -->`)
# is a MIGRATION SCHEMA FLOOR, not the plugin's semver. migrate Phase 0 reads it as
# "@<this> or later → no migration needed". It must stay PINNED at the version where the
# current harness structure was established, and only bump when the harness structure changes
# in a breaking way (a major release). Do NOT bump it every plugin release — that would make
# every existing project falsely report "needs migration". Contrast with `templatecentral_version`
# in harness.json, which tracks plugin semver and is checked against plugin.json separately.
#
# v5.0.0 — seeded project skills moved from flat `.claude/skills/<name>.md` to directory form
# `.claude/skills/<name>/SKILL.md`. Flat skill files are silently ignored by Claude Code
# (flat files only work under `.claude/commands/`). Projects seeded before v5.0.0 must run
# `templatecentral:migrate` to convert their flat skill files to the directory layout.
HARNESS_SCHEMA_VERSION="5.0.0"

fail() { echo "FAIL: $*"; FAILED=1; }
pass() { echo "OK:   $*"; }
header() { echo ""; echo "── $* ──"; }

# ── TIMELESS ──────────────────────────────────────────────────────────────────

check_no_cve_identifiers() {
  # CVE IDs drift — advisories get patched, re-scored, or superseded.
  # Skills must not reference CVE-XXXX-NNNNN. Use "security advisory" language instead.
  header "CVE identifiers"
  local matches
  matches=$(grep -rn 'CVE-[0-9]\{4\}-[0-9]\+' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "CVE identifiers found — replace with 'security advisory' language"
  else
    pass "No CVE identifiers"
  fi
}

check_no_jurisdiction_specific() {
  # templateCentral is industry- and country-neutral.
  # Known jurisdiction-specific framework names must not appear in skills.
  # ADD TO THIS LIST when a new jurisdiction-specific term is discovered.
  # Remove from this list only if the project explicitly targets that jurisdiction.
  # audit/implementation.md is excluded — it names these patterns in its C6 check and changelog.
  # Added: GDPR, CCPA, FISMA (previously only audited in CI). MAS TRM, FedRAMP, NIST SP 800-63
  # were already present. TIMELESS.
  header "Jurisdiction-specific content"
  local pattern='GDPR|CCPA|FISMA|IM8|MAS TRM|GCC2\.0|NRIC|SingPass|MyInfo|PDPA|HIPAA|PCI.DSS|SOC 2|FedRAMP|DISA STIG|NIST SP 800-63'
  local matches
  matches=$(grep -rEn "$pattern" "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' | grep -v 'CONVENTIONS.md' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Jurisdiction-specific content found — skills must be country/industry neutral"
  else
    pass "No jurisdiction-specific content"
  fi
}

check_no_hardcoded_secrets() {
  # Real secret values must never appear in skill code examples.
  # Safe: placeholders (<your-secret>), change-me strings, env refs (${VAR}), comments (#).
  # grep -E replaces grep -P: PCRE silently no-ops on stock macOS BSD grep; POSIX ERE is portable.
  # Negative lookaheads emulated via grep -v pipes. TIMELESS.
  # Keywords extended: added better_auth_secret, private_key, access_token (previously only in CI job).
  header "Hardcoded secrets"
  local matches
  matches=$(grep -rniE '(secret|api_key|password|database_url|better_auth_secret|private_key|access_token)[[:space:]]*=[[:space:]]*.{8,}' "$SKILLS_DIR/" 2>/dev/null \
    | grep -vE '=[[:space:]]*[<$'"'"'\\]' \
    | grep -vi 'change.me\|change-me\|your[-_]\|example\|placeholder\|changeme' \
    | grep -vE '=[[:space:]]*[a-zA-Z_]+[[(.]' \
    | grep -vE '=[[:space:]]*await ' \
    | grep -vE '=[[:space:]]*[A-Z_]{4,}' \
    | grep -v 'postgresql://\|mysql://\|mongodb://\|https://\|http://' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Potential hardcoded secrets — use placeholder syntax (e.g. <your-secret>)"
  else
    pass "No hardcoded secrets"
  fi
}

check_no_comment_narration() {
  # Change-narration comments rot once the change is no longer recent — same doctrine as
  # comments.md, applied here to scripts/*.sh and bash fences in skill markdown.
  header "Change-narration comments"
  local patterns="skills/scaffold/shared/comment-hygiene-patterns.txt"
  if [[ ! -f "$patterns" ]]; then
    fail "Missing $patterns"
    return
  fi
  # This check blocks CI (lint-patterns has no bypass label), so — like the CI gate seeded into
  # scaffolded projects — it reads only the first 10 (anchored keyword) lines, never the last 3
  # (date/ticket/issue-ref), which false-positive on legitimate terms like UTF-8/SHA-256/RFC-7231.
  local strict_patterns
  strict_patterns=$(mktemp)
  head -n 10 "$patterns" > "$strict_patterns"
  local matches="" f line stripped md_file in_bash

  for f in scripts/*.sh; do
    [[ -f "$f" ]] || continue
    while IFS= read -r line; do
      if [[ "$line" =~ ^[[:space:]]*# ]]; then
        stripped=$(printf '%s' "$line" | sed -E 's@^[[:space:]]*#[[:space:]]?@@')
        if [[ -n "$stripped" ]] && grep -qEf "$strict_patterns" <<< "$stripped"; then
          matches="$matches
$f: $stripped"
        fi
      fi
    done < "$f"
  done

  while IFS= read -r -d '' md_file; do
    in_bash=0
    while IFS= read -r line; do
      case "$line" in
        '```bash') in_bash=1; continue ;;
        '```') in_bash=0; continue ;;
      esac
      [[ "$in_bash" -eq 1 ]] || continue
      if [[ "$line" =~ ^[[:space:]]*# ]]; then
        stripped=$(printf '%s' "$line" | sed -E 's@^[[:space:]]*#[[:space:]]?@@')
        if [[ -n "$stripped" ]] && grep -qEf "$strict_patterns" <<< "$stripped"; then
          matches="$matches
$md_file: $stripped"
        fi
      fi
    done < "$md_file"
  done < <(find "$SKILLS_DIR" -name '*.md' -print0)
  rm -f "$strict_patterns"

  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Change-narration comments found — state WHAT the code does now, not what changed"
  else
    pass "No change-narration comments"
  fi
}

check_no_ghost_agent_names() {
  # Ghost agent / skill names that must never appear as invocations in skill files.
  #
  # OLD shared-*-agent names (pre-v4.0):
  #   shared-(build|review|test|update|cleanup)-agent → de-registered; use cat-path contract
  #   fastapi-scaffold / nestjs-scaffold / nextjs-scaffold / vite-react-scaffold → templatecentral:scaffold
  #   templatecentral:shared-migrate → templatecentral:migrate
  #   shared-migrate-database → templatecentral:migrate
  #   templatecentral:shared-audit → templatecentral:audit
  #   shared-code-standards / <stack>-code-standards → templatecentral:standards
  #   nextjs-add-auth → templatecentral:add (auth)
  #
  # DE-REGISTERED utility names (v5.0 cat-path sweep):
  #   templatecentral:build / templatecentral:test / templatecentral:review / templatecentral:cleanup
  #   are NOT registered skills — their SKILL.md files have no `name:` frontmatter and cannot be
  #   invoked as skills. The correct form is: cat "$HOME/.claude/plugins/marketplaces/templatecentral/skills/<name>/SKILL.md"
  #   Use compact table form: `<name> utility (cat skills/<name>/SKILL.md via plugin root)`
  #
  # Repo-internal project skills (not shipped to installed projects, live in .claude/skills/):
  #   templatecentral:audit and templatecentral:write-skill are not valid references from
  #   shipped skills/ — the correct forms are /tc-audit and /tc-write-skill.
  #
  # Still LEGITIMATE (shipped registered skills): templatecentral:scaffold, :add, :migrate, :standards
  # (these are registered skills with `name:` frontmatter and resolve correctly).
  #
  # Exclusions:
  #   audit/implementation.md — documents forbidden names in its own checklist items
  #   CONVENTIONS.md — may explain naming history
  #   This script itself (lint-skills.sh) — names appear only as banned-pattern strings
  header "Ghost agent / skill names"
  local matches
  # shellcheck disable=SC2016  # literal backticks/colons are regex content, not shell expansions
  matches=$(grep -rEn \
    '`shared-(build|review|test|update|cleanup)-agent`|templatecentral:(fastapi|nestjs|nextjs|vite-react)-scaffold|templatecentral:shared-migrate|`shared-migrate-database`|templatecentral:shared-audit|`shared-code-standards`|`(fastapi|nestjs|nextjs|vite-react)-code-standards`|`nextjs-add-auth`|templatecentral:(build|test|review|cleanup|audit|write-skill)' \
    "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    | grep -v 'CONVENTIONS\.md' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Ghost agent/skill name — templatecentral:(build|test|review|cleanup) are de-registered utilities (load via cat-path). templatecentral:audit / :write-skill moved to repo-internal project skills /tc-audit / /tc-write-skill (.claude/skills/) and must not be referenced from shipped skills/. Registered shipped skills (invoke normally): templatecentral:scaffold, :add, :migrate, :standards"
  else
    pass "No ghost agent/skill names"
  fi
}

check_skillmd_description_length() {
  # SKILL.md description: lines longer than 150 chars are truncated in the Claude Code skill picker,
  # causing the skill's purpose to be invisible to the user. Registered SKILL.md (has name:) only —
  # utility SKILL.md files without name: are loading stubs, not displayed. TIMELESS.
  header "SKILL.md description length (<=150 chars)"
  local bad=""
  for f in "$SKILLS_DIR"/*/SKILL.md; do
    grep -q '^name:' "$f" || continue
    local desc len
    desc=$(grep '^description:' "$f" | head -1 | sed 's/^description:[[:space:]]*//')
    len=${#desc}
    [ "$len" -gt 150 ] && bad+="$f ($len chars)"$'\n'
  done
  if [[ -n "$bad" ]]; then
    printf "%s" "$bad"
    fail "SKILL.md description exceeds 150 chars — shorten it so it displays fully in the skill picker"
  else
    pass "All registered SKILL.md descriptions <=150 chars"
  fi
}

check_ref_file_headers() {
  # Every reference .md file under skills/ (except SKILL.md and CONVENTIONS.md) must begin with
  # a <!-- ref: --> comment so agents know the file's load path and purpose without reading the body.
  # Missing headers cause agents to silently skip context about how to load the file. TIMELESS.
  header "Ref file <!-- ref: --> headers"
  local bad=""
  while IFS= read -r f; do
    local firstline
    firstline=$(head -1 "$f")
    [[ "$firstline" == "<!-- ref:"* ]] || bad+="$f"$'\n'
  done < <(find "$SKILLS_DIR" -name '*.md' ! -name 'SKILL.md' ! -name 'CONVENTIONS.md' 2>/dev/null)
  if [[ -n "$bad" ]]; then
    printf "%s" "$bad"
    fail "Ref file missing <!-- ref: --> on line 1 — add a ref header following CONVENTIONS.md §2"
  else
    pass "All ref files have <!-- ref: --> headers"
  fi
}

check_skillmd_body_length() {
  # Registered SKILL.md bodies must be <=30 lines (CONVENTIONS §3). TIMELESS.
  # A long body bloats the skill picker tooltip and forces agents to read unnecessary prose
  # before they can delegate to the appropriate ref file.
  header "SKILL.md body length (<=30 lines)"
  local bad=""
  for f in "$SKILLS_DIR"/*/SKILL.md; do
    grep -q '^name:' "$f" || continue
    local total body fm_end
    fm_end=$(awk '/^---$/{c++; if(c==2){print NR; exit}}' "$f")
    total=$(wc -l < "$f")
    body=$((total - fm_end))
    [ "$body" -gt 30 ] && bad+="$f ($body lines)"$'\n'
  done
  if [[ -n "$bad" ]]; then
    printf "%s" "$bad"
    fail "SKILL.md body exceeds 30 lines — move prose into an implementation.md ref file"
  else
    pass "All registered SKILL.md bodies <=30 lines"
  fi
}

check_nesting_depth() {
  # Skills nested more than 3 directory levels under skills/ are unreachable by templateCentral's
  # ref-file loader and indicate a structure drift from CONVENTIONS.md §1. TIMELESS.
  # With default SKILLS_DIR="skills": NF>5 catches skills/a/b/c/d/file.md (4+ dirs deep).
  header "Nesting depth (<=3 levels under skills/)"
  local bad
  bad=$(find "$SKILLS_DIR" -name '*.md' ! -name 'SKILL.md' ! -name 'CONVENTIONS.md' \
    | awk -F'/' -v base="$(echo "$SKILLS_DIR" | awk -F'/' '{print NF}')" 'NF > base + 4' \
    2>/dev/null || true)
  if [[ -n "$bad" ]]; then
    printf "%s\n" "$bad"
    fail "File nested >3 levels under skills/ — restructure to match CONVENTIONS.md §1"
  else
    pass "No files nested >3 levels under skills/"
  fi
}

# ── ECOSYSTEM-ERA ──────────────────────────────────────────────────────────────

check_no_version_pins() {
  # SSOT policy: version pins belong only in .claude/rules/*.md, not in SKILL.md files.
  # EXCEPTION: shadcn@latest is the official shadcn CLI invocation, not a version pin.
  # Catches: scoped npm pins (@org/pkg@version), unscoped npm pins (pkg@X.Y.Z),
  # and Python exact pins (pkg==X.Y). Exclusions:
  #   templateCentral: schema markers (<!-- templateCentral: stack@X.Y.Z -->)
  #   "packageManager" field: corepack requires an exact version in this field by design
  #   ":<space>stack@version" prose (drift-check example output, schema version references)
  # REVISIT: if the SSOT policy changes, remove this check.
  header "Version pins in skills (SSOT)"
  local found=0
  while IFS= read -r match; do
    # Skip shadcn@latest — CLI tool invocation, not a dependency pin
    [[ "$match" =~ shadcn@latest ]] && continue
    echo "$match"
    found=1
  done < <(
    {
      grep -rn '@[a-zA-Z][a-zA-Z0-9_/@-]*@[0-9^~><]' "$SKILLS_DIR/" 2>/dev/null || true
      grep -rEn '[a-zA-Z0-9_-]+@[0-9]+\.[0-9]+\.[0-9]+' "$SKILLS_DIR/" 2>/dev/null \
        | grep -v 'templateCentral:' \
        | grep -v '"packageManager"' \
        | grep -vE ':[[:space:]]+[a-zA-Z][a-zA-Z0-9_-]*@[0-9]' \
        || true
      grep -rEn '[a-zA-Z0-9_-]+[=]{2}[0-9]+\.[0-9]+' "$SKILLS_DIR/" 2>/dev/null || true
    } | sort -u
  )
  if [[ $found -eq 1 ]]; then
    fail "Version pins found — move floors/pins to .claude/rules/*.md"
    FAILED=1
  else
    pass "No version pins in skills"
  fi
}

check_no_bcrypt() {
  # Project standard is argon2id (OWASP/NIST SP 800-63B recommendation).
  # REVISIT: if the project standard changes, update this check.
  # audit/implementation.md is excluded — it references bcrypt in its own checklist items.
  header "bcrypt references"
  local matches
  matches=$(grep -rn '\bbcrypt\b' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "bcrypt found — project standard is argon2id"
  else
    pass "No bcrypt references"
  fi
}

check_no_deprecated_zod_flatten() {
  # Zod v4 deprecated error.flatten() — use z.flattenError(error) instead.
  # REVISIT: if the project ever drops to Zod v3, remove this check.
  # audit/implementation.md is excluded — it references .flatten() in its own checklist items.
  header "Deprecated Zod .flatten()"
  local matches
  matches=$(grep -rn '\.flatten()' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail ".flatten() is deprecated in Zod v4 — use z.flattenError()"
  else
    pass "No deprecated .flatten() calls"
  fi
}

check_no_middleware_ts() {
  # Next.js 16 replaced middleware.ts with proxy.ts for auth/proxy patterns.
  # REVISIT: if Next.js reintroduces middleware.ts, remove or adjust this check.
  # Excluded files are meta-documents (audit checklist, migration guides, scaffold templates)
  # that legitimately reference middleware.ts to explain the deprecation.
  header "middleware.ts references"
  local matches
  matches=$(grep -rn 'middleware\.ts' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    | grep -v 'migrate/general/implementation' \
    | grep -v 'scaffold/nextjs/source-files' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "middleware.ts found — Next.js 16 uses proxy.ts"
  else
    pass "No middleware.ts references"
  fi
}

check_no_pragma_or_expires_headers() {
  # Pragma: no-cache and Expires: 0 are HTTP/1.0 relics — deprecated in HTTP/1.1+.
  # Cache-Control is sufficient. These headers add noise without benefit.
  # REVISIT: if a target environment requires HTTP/1.0 compat, reconsider.
  header "Deprecated HTTP/1.0 cache headers"
  local matches
  matches=$(grep -rEn "Pragma: no-cache|Expires: 0" "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Deprecated HTTP/1.0 headers found — Cache-Control is sufficient"
  else
    pass "No deprecated HTTP/1.0 cache headers"
  fi
}

check_no_zod_string_format_methods() {
  # Zod v4 deprecated chained string-format methods: .string().url(), .string().datetime(),
  # .string().email(), .string().uuid(). Use top-level z.url(), z.iso.datetime(), z.email(), z.uuid() instead.
  # ECOSYSTEM-ERA: correct for Zod v4+. Revisit if the project downgrades to Zod v3.
  # audit/implementation.md is excluded — it may reference these in checklist items.
  header "Deprecated Zod v4 string format methods"
  local matches
  matches=$(grep -rEn 'z\.string\(\)\.(url|datetime|email|uuid)\(' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Deprecated Zod string-chained format method — use top-level z.url(), z.iso.datetime(), z.email(), z.uuid()"
  else
    pass "No deprecated Zod string format methods"
  fi
}

check_no_jest_apis_in_skills() {
  # All Node scaffold stacks (NestJS, Next.js, Vite+React) use Vitest — not Jest.
  # jest.fn(), jest.spyOn(), and jest-e2e.json must not appear in skill code examples.
  # ECOSYSTEM-ERA: correct for NestJS 11+ (Vitest default). Revisit if the project adopts Jest.
  # audit/implementation.md is excluded — it may reference these patterns in checklist items.
  header "Jest APIs in skill code examples"
  local matches
  matches=$(grep -rEn 'jest\.(fn|spyOn|mock|clearAllMocks|resetAllMocks|restoreAllMocks)\(|jest-e2e\.json' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Jest API found in skill code example — all Node stacks use Vitest (vi.fn(), vi.spyOn())"
  else
    pass "No Jest APIs in skill code examples"
  fi
}

check_no_globals_jest_in_vitest_projects() {
  # All Node scaffold stacks use Vitest with globals: false — eslint-globals-jest is not needed.
  # Adding ...globals.jest to an ESLint config in a Vitest project is misleading and unused.
  # ECOSYSTEM-ERA: correct for NestJS 11+ / Vite+React (Vitest default). Revisit if Jest is re-adopted.
  # audit/implementation.md is excluded — it may reference this in checklist items.
  header "globals.jest in ESLint config templates"
  local matches
  matches=$(grep -rn 'globals\.jest' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "globals.jest found in ESLint template — Node stacks use Vitest with globals: false; remove globals.jest"
  else
    pass "No globals.jest in ESLint config templates"
  fi
}

check_no_zod_deprecated_message_key() {
  # Zod v4 custom error params use { error: '...' }, not { message: '...' }.
  # { message: '...' } is the Zod v3 form — still accepted but deprecated in v4 and will be removed.
  # Broadened from specific method list to any z.<method>({ message: — catches z.string(), z.number(),
  # z.object(), etc. that were missed by the narrower pattern. ECOSYSTEM-ERA: correct for Zod v4.
  # audit/implementation.md is excluded — it may reference this pattern in checklist items.
  header "Deprecated Zod v3 message key in validators"
  local matches
  matches=$(grep -rEn "z\.[a-z]+\([[:space:]]*\{[[:space:]]*message:" "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Zod validator uses deprecated { message: '...' } — use { error: '...' } for custom error messages in Zod v4"
  else
    pass "No deprecated Zod v3 message key in validators"
  fi
}

check_no_sync_secret_comparison() {
  # Comparing stored secrets (hashes, tokens) with == or === is not timing-safe.
  # Use a constant-time function (e.g. crypto.timingSafeEqual, argon2.verify).
  # NOTE: password === confirmPassword in Zod refine() is safe — both are user inputs,
  #       there is no stored value and no timing oracle. This check targets stored values.
  # REVISIT: if a safe wrapper is introduced, refine the pattern.
  header "Unsafe stored-secret comparison"
  local matches
  matches=$(grep -rEn '\b(storedHash|passwordHash|hashedPassword|sessionToken|accessToken|refreshToken)\s*(===|==)\s*' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Timing-unsafe comparison of stored secret — use a constant-time compare function"
  else
    pass "No unsafe stored-secret comparisons"
  fi
}

check_no_mypy_in_postToolUse() {
  # pyright is 2-5x faster than mypy with near-complete spec conformance.
  # mypy in PostToolUse adds 45+ seconds per edit on real projects.
  # REVISIT: if mypy regains a speed advantage or pyright has correctness regressions, update.
  header "mypy in PostToolUse hook"
  local postToolUse_files
  postToolUse_files=$(grep -rln '"PostToolUse"' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  local mypy_in_postToolUse=""
  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    if grep -A15 '"PostToolUse"' "$file" 2>/dev/null | grep -q 'mypy'; then
      mypy_in_postToolUse="$mypy_in_postToolUse\n$file"
    fi
  done <<< "$postToolUse_files"
  if [[ -n "$mypy_in_postToolUse" ]]; then
    printf '%b\n' "$mypy_in_postToolUse"
    fail "mypy in PostToolUse — use pyright instead (2-5x faster, community standard as of May 2026)"
  else
    pass "No mypy in PostToolUse hook"
  fi
}

check_no_tanstack_isLoading() {
  # TanStack Query v5 renamed isLoading to isPending on useQuery()/useMutation() destructuring.
  # isLoading still exists as a derived bool on the query object but has different semantics
  # (true when fetching WITH existing data; isPending is true when there is no data yet).
  # Using isLoading instead of isPending causes the loading state to not show on first render.
  # ECOSYSTEM-ERA: correct for TanStack Query v5+. Revisit if the project pins to TQ v4.
  header "TanStack Query v5 isLoading usage"
  local hits
  hits=$(grep -rn '{ .*isLoading.*} = use\(Query\|Mutation\)\|isPending\s*:\s*isLoading\b' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    || true)
  if [[ -n "$hits" ]]; then
    echo "$hits"
    fail "TanStack Query v5: use isPending (not isLoading) from useQuery/useMutation destructuring"
  else
    pass "No TanStack Query isLoading usage"
  fi
}

check_no_tanstack_isInitialLoading() {
  # TanStack Query v5 deprecated isInitialLoading (alias for isLoading && isLoading) and removed
  # it in v6. Using it causes a runtime error once projects upgrade to v6.
  # ECOSYSTEM-ERA: correct for TanStack Query v5+. Retire when v6 is the project baseline.
  header "TanStack Query v5 isInitialLoading usage"
  local hits
  hits=$(grep -rn '\bisInitialLoading\b' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    || true)
  if [[ -n "$hits" ]]; then
    echo "$hits"
    fail "TanStack Query v5: isInitialLoading is deprecated (removed in v6); use isPending instead"
  else
    pass "No TanStack Query isInitialLoading usage"
  fi
}

check_no_starlette_startup_events() {
  # Starlette 1.0.0 removed on_startup/on_shutdown event handlers and add_event_handler().
  # FastAPI 0.136.x requires lifespan= context manager exclusively.
  # ECOSYSTEM-ERA: correct for Starlette ≥1.0.0 / FastAPI ≥0.128.0.
  header "Starlette 1.0 deprecated startup events"
  local hits
  hits=$(grep -rn '@app\.on_event\|add_event_handler\|on_startup=\|on_shutdown=' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    | grep -v 'standards/code-standards' \
    || true)
  if [[ -n "$hits" ]]; then
    echo "$hits"
    fail "Starlette 1.0: use lifespan= context manager — on_startup/on_shutdown/add_event_handler removed"
  else
    pass "No Starlette deprecated startup events"
  fi
}

check_no_bare_pytest_invocation() {
  # A bare `pytest ...` invocation resolves via PATH — if the caller's shell doesn't have the
  # project .venv activated (a documented, real failure mode: the same class of bug fixed in the
  # scaffold's lefthook commands), it silently runs a different/system pytest or fails
  # with "command not found." `python -m pytest` always resolves via the active Python, matching
  # the `python -m pyright` convention already used everywhere else in the FastAPI skills.
  # TIMELESS: tied to the venv-based invocation convention (skills/test/implementation.md).
  header "Bare pytest invocation (must use python -m pytest)"
  local matches
  matches=$(grep -rEn '(^|[^-.a-zA-Z])pytest[[:space:]]+(test/|-[a-zA-Z])' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'python -m pytest' \
    | grep -v 'audit/implementation' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Bare 'pytest ...' invocation — use 'python -m pytest' so it resolves via the active venv (see skills/test/implementation.md)"
  else
    pass "No bare pytest invocation"
  fi
}

check_no_fastapi_orjson_response() {
  # ORJSONResponse and UJSONResponse deprecated in FastAPI 0.130+.
  # Native JSON serialization now uses Pydantic's Rust-based serializer.
  # ECOSYSTEM-ERA: correct for FastAPI ≥0.130.0.
  header "Deprecated FastAPI ORJSONResponse/UJSONResponse"
  local hits
  hits=$(grep -rn 'ORJSONResponse\|UJSONResponse' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    || true)
  if [[ -n "$hits" ]]; then
    echo "$hits"
    fail "FastAPI 0.130+: ORJSONResponse/UJSONResponse deprecated — use standard JSONResponse"
  else
    pass "No deprecated FastAPI ORJSONResponse/UJSONResponse"
  fi
}

check_no_env_api_base_url_fallback() {
  # Vite+React code-standards rule: NEVER use `ENV.API_BASE_URL ?? ''` — use `getApiBaseUrl()`.
  # The fallback '' silently returns empty string when the env var is missing, hiding config errors.
  # getApiBaseUrl() throws at startup so misconfiguration is caught immediately.
  # ECOSYSTEM-ERA: Vite 8 / React 19 stack. Revisit if ENV helper API changes.
  header "ENV.API_BASE_URL ?? '' anti-pattern in Vite skills"
  local matches
  matches=$(grep -rn "API_BASE_URL ?? ''" "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    | grep -v 'code-standards' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Use getApiBaseUrl() not ENV.API_BASE_URL ?? '' — see code-standards/vite-react.md"
  else
    pass "No ENV.API_BASE_URL ?? '' anti-pattern"
  fi
}

check_no_postToolUse_full_test_suite() {
  # PostToolUse hooks are feedback-only and cannot block execution.
  # Full test suites (pnpm test, pytest, etc.) belong in Stop hooks, not PostToolUse.
  # Running tests on every file edit is slow and masks real TypeScript feedback.
  # TIMELESS: PostToolUse semantic is feedback-only by design in Claude Code.
  header "Full test suite in PostToolUse hook"
  local matches
  matches=$(grep -rn '"PostToolUse"' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'audit/implementation' \
    || true)
  # Check if any PostToolUse block is followed by a test command within 15 lines
  local postToolUse_files
  postToolUse_files=$(grep -rln '"PostToolUse"' "$SKILLS_DIR/" 2>/dev/null | grep -v 'audit/implementation' || true)
  local test_in_postToolUse=""
  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    # Find lines with pnpm test or pytest inside a PostToolUse context
    if grep -A15 '"PostToolUse"' "$file" 2>/dev/null | grep -qE '"(pnpm test|pytest|npm test|yarn test)'; then
      test_in_postToolUse="$test_in_postToolUse\n$file"
    fi
  done <<< "$postToolUse_files"
  if [[ -n "$test_in_postToolUse" ]]; then
    printf '%b\n' "$test_in_postToolUse"
    fail "Full test suite in PostToolUse — use Stop hook for tests; PostToolUse should run tsc --noEmit only"
  else
    pass "No full test suite in PostToolUse hook"
  fi
}

check_harness_version_matches_plugin() {
  # Scaffold source-files.md embed "templatecentral_version" in the harness.json template they write.
  # If this version drifts from plugin.json on a version bump, scaffolded projects report the wrong generator version.
  # ECOSYSTEM-ERA: tied to the current plugin semver scheme; revisit if versioning strategy changes.
  header "harness.json templatecentral_version matches plugin.json"
  local plugin_json=".claude-plugin/plugin.json"
  if [[ ! -f "$plugin_json" ]]; then
    pass "No plugin.json found — skipping harness version check"
    return
  fi
  local plugin_version
  plugin_version=$(grep '"version"' "$plugin_json" | grep -oE '"[0-9]+\.[0-9]+\.[0-9]+"' | tr -d '"' | head -1)
  local mismatches
  mismatches=$(grep -rn '"templatecentral_version"' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v "\"$plugin_version\"" \
    || true)
  if [[ -n "$mismatches" ]]; then
    echo "$mismatches"
    fail "templatecentral_version in harness.json template does not match plugin.json ($plugin_version) — update scaffold and migrate source-files.md"
  else
    pass "templatecentral_version matches plugin.json ($plugin_version)"
  fi
}

check_agents_marker_not_drifted_to_semver() {
  # The AGENTS.md line-1 marker (`<!-- templateCentral: <stack>@X.Y.Z -->`) is a migration schema
  # floor, NOT plugin semver. Legitimate values: @1.0.0 (migrate light-adoption / legacy examples)
  # and @HARNESS_SCHEMA_VERSION (full current harness). The failure mode this guards against is a
  # well-meaning "version bump" pushing a marker UP to the plugin semver (e.g. 4.5.0), which would
  # break migrate Phase 0's floor logic. Rule: every marker version must be <= HARNESS_SCHEMA_VERSION.
  # ECOSYSTEM-ERA: tied to the current plugin semver scheme; the floor marker and schema version concept may evolve.
  header "AGENTS.md schema marker not drifted above HARNESS_SCHEMA_VERSION ($HARNESS_SCHEMA_VERSION)"
  local drifted=""
  local line ver
  # Match only the marker comment; ignore prose mentions of "@4.0.0 through @4.x" etc.
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    ver=$(echo "$line" | grep -oE '@[0-9]+\.[0-9]+\.[0-9]+' | head -1 | tr -d '@')
    [[ -z "$ver" ]] && continue
    # If sorting {ver, floor} by version puts ver last AND they differ, ver > floor → drift.
    if [[ "$(printf '%s\n%s\n' "$ver" "$HARNESS_SCHEMA_VERSION" | sort -V | tail -1)" == "$ver" \
       && "$ver" != "$HARNESS_SCHEMA_VERSION" ]]; then
      drifted+="$line"$'\n'
    fi
  done < <(grep -rnoE '<!-- templateCentral: [a-z<>-]+@[0-9]+\.[0-9]+\.[0-9]+' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$drifted" ]]; then
    echo "$drifted"
    fail "AGENTS.md schema marker exceeds HARNESS_SCHEMA_VERSION ($HARNESS_SCHEMA_VERSION) — the marker is a migration floor, not plugin semver; revert it, or bump HARNESS_SCHEMA_VERSION deliberately if the harness structure changed"
  else
    pass "All AGENTS.md schema markers <= @$HARNESS_SCHEMA_VERSION"
  fi
}

check_seeded_skills_scope_tools() {
  # Seeded project skills (*-verify, *-migrate) embedded in scaffold templates are written into
  # every scaffolded project. They must declare allowed-tools: with no bare Bash token — bare Bash
  # grants unrestricted shell access (opposite of least-agency). Mixed tool lists like
  # "Read, Edit, Write, Bash(pnpm *), Grep, Glob" are accepted; bare "Bash" (not followed by '(')
  # is rejected. TIMELESS: least-agency (OWASP Agentic ASI02) — seeded skills scope their tools.
  header "Seeded project skills declare scoped allowed-tools"
  local files bad
  files=$(grep -rlE '^name: [a-z][a-z-]*-(verify|migrate)$' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -z "$files" ]]; then
    pass "No seeded *-verify/*-migrate skills found"
    return
  fi
  # shellcheck disable=SC2086  # word-splitting is intentional: $files is newline-separated paths
  bad=$(awk '
    /^name: [a-z][a-z-]*-(verify|migrate)$/ { inblock=1; nm=$2; has_tools=0; bare_bash=0; ln=FNR; next }
    inblock && /^allowed-tools:/ {
      has_tools=1
      if ($0 ~ /Bash[^(]/ || $0 ~ /Bash$/) { bare_bash=1 }
      next
    }
    inblock && /^---[[:space:]]*$/ {
      if (!has_tools) print FILENAME":"ln": "nm" - missing allowed-tools"
      else if (bare_bash) print FILENAME":"ln": "nm" - bare Bash in allowed-tools (must be scoped, e.g. Bash(pnpm *))"
      inblock=0
    }
  ' $files 2>/dev/null || true)
  if [[ -n "$bad" ]]; then
    echo "$bad"
    fail "Seeded skill missing scoped allowed-tools — add e.g. 'allowed-tools: Bash(pnpm *)' to its frontmatter"
  else
    pass "All seeded project skills declare scoped allowed-tools"
  fi
}

check_no_unscoped_bash_grant() {
  # An allowed-tools: line that grants bare 'Bash' (not 'Bash(...)') hands the skill unrestricted
  # shell access — the opposite of least-agency. Every Bash grant must be scoped to a command prefix.
  # TIMELESS: OWASP Agentic ASI02 (Tool Misuse) — never grant unscoped Bash.
  header "No unscoped Bash in allowed-tools grants"
  local hits
  # Match allowed-tools lines mentioning Bash where Bash is NOT immediately followed by '('.
  hits=$(grep -rnE '^allowed-tools:.*\bBash\b' "$SKILLS_DIR/" 2>/dev/null | grep -vE 'Bash\(' || true)
  if [[ -n "$hits" ]]; then
    echo "$hits"
    fail "Unscoped 'Bash' in allowed-tools — scope it (e.g. Bash(pnpm *), Bash(git *))"
  else
    pass "No unscoped Bash grants"
  fi
}

check_seeded_skill_paths_are_directories() {
  # A Claude Code skill is a DIRECTORY with SKILL.md as the entrypoint — flat
  # .claude/skills/<name>.md files are silently ignored (flat files are only valid under
  # .claude/commands/). A seeding instruction that writes the flat form ships a skill that never
  # loads, and nothing at scaffold time catches it. Concrete flat paths (next-verify.md,
  # <stack>-verify.md, next-migrate.md, ...) are banned; the generic '<name>.md' placeholder in
  # explanatory prose is allowed — it documents the anti-pattern.
  # ECOSYSTEM-ERA: skill-discovery rule per current Claude Code docs (directory + SKILL.md entrypoint).
  header "Seeded project skills use directory form (.claude/skills/<name>/SKILL.md)"
  local hits
  hits=$(grep -rnE '\.claude/skills/[a-zA-Z<][a-zA-Z<>-]*-(verify|migrate)\.md' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$hits" ]]; then
    echo "$hits"
    fail "Flat .claude/skills/<name>.md seeding path found — skills are directories; use .claude/skills/<name>/SKILL.md (flat files only work under .claude/commands/)"
  else
    pass "No flat .claude/skills/<name>.md seeding paths"
  fi
}

check_scaffold_seeds_complete_harness() {
  # The shared harness kit (skills/scaffold/shared/harness-kit.md) is the single source of truth
  # for the complete harness: all 7 hook events, the permissions.deny secret-Read block,
  # skillListingBudgetFraction, the 8 .claude/hooks/ script bodies, stop_hook_active guard,
  # CONSTITUTION.md, FUTURE.md, harness.json step, .agents symlink, and the shared AGENTS.md tail.
  # Each of the 4 scaffold source-files.md and migrate/general/implementation.md must reference
  # the kit (contain 'scaffold/shared/harness-kit.md'). The kit itself must contain every universal
  # harness element. This structure keeps the harness enforceable from one file rather than 5.
  # TIMELESS: these are the load-bearing enforcement hooks; their presence is non-negotiable.
  header "Scaffold/migrate templates seed the complete harness"

  local kit="$SKILLS_DIR/scaffold/shared/harness-kit.md"
  local scaffolds=(
    "$SKILLS_DIR/scaffold/fastapi/source-files.md"
    "$SKILLS_DIR/scaffold/nestjs/source-files.md"
    "$SKILLS_DIR/scaffold/nextjs/source-files.md"
    "$SKILLS_DIR/scaffold/vite-react/source-files.md"
  )
  local migrate="$SKILLS_DIR/migrate/general/implementation.md"

  # (a) The kit must contain all universal harness tokens:
  local kit_tokens=(
    '"PreToolUse"' '"UserPromptSubmit"' '"PostToolUse"' '"PostToolUseFailure"'
    '"Stop"' '"SubagentStop"' '"SessionStart"'
    'skillListingBudgetFraction' '"Read(.env)"' '"Read(**/.env)"'
    'protect-files.sh' 'block-no-verify.sh' 'user-prompt-guard'
    'post-edit-typecheck.sh' 'post-tool-failure.sh' 'stop-checks.sh'
    'subagent-stop.sh' 'session-context.sh'
    'stop_hook_active' '--no-verify' 'AKIA'
    'node' 'python3'
    # Content-authoring token, not just a path reference: catches the class of bug where a
    # seeded file's path is wired into settings.json/harness.json/protect-files.sh everywhere
    # but the kit never actually authors its content — a scaffolded project ends up with every
    # consumer pointing at a file that's never created, and verify-harness.sh then hard-fails
    # on MISSING for every fresh scaffold. This exact gap shipped once in comment-hygiene-patterns.txt.
    '[Ww][Aa][Ss][[:space:]]'
  )
  local missing="" tok
  if [[ ! -f "$kit" ]]; then
    missing+="$kit — file not found"$'\n'
  else
    for tok in "${kit_tokens[@]}"; do
      grep -qF -- "$tok" "$kit" || missing+="$kit — missing harness element: $tok"$'\n'
    done
  fi

  # (b) Each scaffold source-files.md and migrate must reference the shared kit:
  local f
  for f in "${scaffolds[@]}" "$migrate"; do
    [[ -f "$f" ]] || { missing+="$f — file not found"$'\n'; continue; }
    # Form-agnostic: matches the legacy absolute path and the <skill-dir>-relative form.
    grep -qF 'shared/harness-kit.md' "$f" || \
      missing+="$f — does not reference shared/harness-kit.md"$'\n'
    # Each scaffold also seeds a *-verify skill:
    grep -qF -- '-verify/SKILL.md' "$f" || \
      missing+="$f — missing stack verify-skill seeding (-verify/SKILL.md)"$'\n'
  done

  if [[ -n "$missing" ]]; then
    echo "$missing"
    fail "Harness check failed — kit must contain all universal tokens; all 4 scaffolds + migrate must reference scaffold/shared/harness-kit.md; each scaffold must seed a *-verify/SKILL.md"
  else
    pass "Shared harness kit contains all universal tokens; all scaffold/migrate files reference it"
  fi
}

check_migrate_hook_inventory_matches_kit() {
  # migrate/general/implementation.md enumerates the kit's hooks by name in prose (Step 4d),
  # separate from the kit's own authoring blocks — a hook added to the kit without updating
  # that list leaves every migrated project short a hook.
  header "migrate hook inventory matches harness-kit.md"
  local kit="$SKILLS_DIR/scaffold/shared/harness-kit.md"
  local migrate="$SKILLS_DIR/migrate/general/implementation.md"
  if [[ ! -f "$kit" || ! -f "$migrate" ]]; then
    fail "Missing $kit or $migrate"
    return
  fi
  local hooks missing="" h
  hooks=$(grep -oE '^\*\*`\.claude/hooks/[a-zA-Z0-9_-]+' "$kit" | sed -E 's#.*/##' | sort -u)
  for h in $hooks; do
    grep -qF -- "$h" "$migrate" || missing+="migrate is missing hook: $h"$'\n'
  done
  grep -qF -- '.claude/comment-hygiene-patterns.txt' "$migrate" || \
    missing+="migrate does not mention .claude/comment-hygiene-patterns.txt"$'\n'
  if [[ -n "$missing" ]]; then
    echo "$missing"
    fail "migrate's hook/file inventory has drifted from harness-kit.md — update skills/migrate/general/implementation.md Step 4d"
  else
    pass "migrate's hook inventory covers every hook + file authored in harness-kit.md"
  fi
}

check_duplicated_iam_blocks_match() {
  # The AWS IAM session/config modules exist in two independently-loaded flows: the add-database
  # leaf that installs them and the migrate-database leaf that retrofits them.
  # Deduplicating by cross-catting is the wrong trade here — the add leaves are 232/517-line
  # from-scratch install guides, so a migrate flow would pay their full token cost to reuse ~70
  # lines, and risks re-running the install steps. Duplicating the block costs nothing at runtime
  # (each flow loads exactly one copy) and only risks silent drift — which this check removes.
  # The add leaf is canonical; the migrate copy must match it byte for byte. Security-critical:
  # these blocks carry sslmode=verify-full / rejectUnauthorized + CA-bundle settings, where a
  # one-sided edit silently downgrades TLS on the migrate path only.
  # TIMELESS: enforces the invariant, not any particular stack version.
  header "Duplicated IAM session/config blocks match their canonical source"
  if ! command -v python3 >/dev/null 2>&1; then
    pass "skipped (python3 not available)"
    return
  fi
  local out
  out=$(python3 - "$SKILLS_DIR" <<'PY'
import sys
root = sys.argv[1]

# (label, canonical file, canonical anchor, copy file, copy anchor, fence language)
PAIRS = [
    ("FastAPI IAM session.py",
     "add/database/python/sqlalchemy-iam.md", "### A4. Create `src/database/session.py`",
     "migrate/database/fastapi.md", "### Step 2 — Replace `src/database/session.py`", "python"),
    ("FastAPI IAM alembic/env.py",
     "add/database/python/sqlalchemy-iam.md", "### A6. Update `alembic/env.py`",
     "migrate/database/fastapi.md", "### Step 4 — Update `alembic/env.py`", "python"),
    ("NestJS IAM KyselyService",
     "add/database/typescript/nestjs-kysely.md", "Replace the entire contents of `kysely.service.ts` with:",
     "migrate/database/nestjs.md", "### Step 4 — Create `src/database/kysely.service.ts` (IAM variant)", "typescript"),
    ("NestJS IAM envSchema fields",
     "add/database/typescript/nestjs-kysely.md", "Add IAM fields to `envSchema`",
     "migrate/database/nestjs.md", "### Step 10 — Update `src/config/env.config.ts`", "typescript"),
    ("NestJS IAM serviceConfig mapping",
     "add/database/typescript/nestjs-kysely.md", "Then map the validated fields into `serviceConfig`",
     "migrate/database/nestjs.md", "Then map the validated fields into `serviceConfig`", "typescript"),
]

def fence_after(path, anchor, lang):
    try:
        lines = open(path, encoding="utf-8").read().split("\n")
    except OSError:
        return None
    start = next((i for i, l in enumerate(lines) if anchor in l), None)
    if start is None:
        return None
    i = start + 1
    while i < len(lines):
        if lines[i].strip() == '```' + lang:
            j = i + 1
            while j < len(lines) and not lines[j].startswith('```'):
                j += 1
            return "\n".join(lines[i + 1:j])
        i += 1
    return None

bad = []
for label, ca_f, ca_a, cp_f, cp_a, lang in PAIRS:
    ca_p, cp_p = root + "/" + ca_f, root + "/" + cp_f
    a, b = fence_after(ca_p, ca_a, lang), fence_after(cp_p, cp_a, lang)
    if a is None:
        bad.append("%s: canonical anchor/fence not found in %s (%r)" % (label, ca_f, ca_a))
    elif b is None:
        bad.append("%s: copy anchor/fence not found in %s (%r)" % (label, cp_f, cp_a))
    elif a != b:
        bad.append("%s: %s has drifted from canonical %s" % (label, cp_f, ca_f))
for x in bad:
    print(x)
PY
)
  if [[ -n "$out" ]]; then
    echo "$out"
    fail "Duplicated IAM block drifted — the add/ leaf is canonical; re-copy it into the migrate/ leaf"
  else
    pass "All duplicated IAM blocks match their canonical source"
  fi
}

check_yaml_fences_parse() {
  # A seeded lefthook.yml/ci.yml is authored as a ```yaml fence in prose docs — nothing else
  # ever parses it before it reaches a real project. A shell variable assignment that spans
  # physical lines inside a `run: |` block scalar silently breaks YAML indentation rules
  # without any syntax error in the shell itself, so this must parse the fence content, not
  # just lint the shell inside it. TIMELESS: catches this bug class regardless of cause.
  header "Seeded \`\`\`yaml fences parse as valid YAML"
  if ! command -v python3 >/dev/null 2>&1 || ! python3 -c 'import yaml' >/dev/null 2>&1; then
    pass "skipped (python3/PyYAML not available)"
    return
  fi
  local out
  out=$(python3 - "$SKILLS_DIR" <<'PY'
import os, sys, yaml
root = sys.argv[1]
bad = []
for dp, _, fs in os.walk(root):
    for f in fs:
        if not f.endswith('.md'): continue
        p = os.path.join(dp, f)
        lines = open(p, encoding='utf-8').read().split('\n')
        i = 0
        while i < len(lines):
            if lines[i].strip() == '```yaml':
                start = i + 1
                j = start
                while j < len(lines) and lines[j].strip() != '```':
                    j += 1
                try:
                    list(yaml.safe_load_all('\n'.join(lines[start:j])))
                except Exception as e:
                    bad.append(f"{p}:{start+1}-{j}: {str(e).splitlines()[0]}")
                i = j + 1
            else:
                i += 1
for b in bad: print(b)
PY
)
  if [[ -n "$out" ]]; then
    echo "$out"
    fail "Seeded yaml fence(s) fail to parse — check block-scalar (run: |) indentation"
  else
    pass "All seeded yaml fences parse"
  fi
}

check_no_absolute_plugin_path() {
  # References load via the <skill-dir> placeholder (the tool-provided skill directory at invocation),
  # never an absolute install path, and never ${CLAUDE_SKILL_DIR} (empty in agent-run bash — only
  # populated for CC !-injection, not the agent-run cat blocks used here). See CONVENTIONS.md §1.
  # TIMELESS: skills must be portable across Agent-Skills tools; the install path is never hardcoded.
  header "No absolute plugin-path or \${CLAUDE_SKILL_DIR} references"
  local matches
  matches=$(grep -rnE 'plugins/marketplaces/templatecentral|CLAUDE_SKILL_DIR' "$SKILLS_DIR/" 2>/dev/null | grep -v 'CONVENTIONS.md' || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Use the <skill-dir> placeholder (CONVENTIONS.md §1), not an absolute plugin path or \${CLAUDE_SKILL_DIR}."
  else
    pass "No absolute plugin-path / \${CLAUDE_SKILL_DIR} references (all use <skill-dir>)"
  fi
}

check_no_toplevel_command_in_hooks() {
  # Hook commands that read the bash command from top-level `d.command` (or Python d.get('command'))
  # instead of `d.tool_input.command` will silently get an empty string — the check never fires.
  # For Bash tool events, the command lives at tool_input.command, not at the top level.
  # TIMELESS: Claude Code hook stdin schema places tool input under tool_input; this is by design.
  header "Top-level d.command access in hook commands (should be d.tool_input.command)"
  local matches
  matches=$(grep -rn 'd\.command\|d\[.command.\]\|d\.get(.command.' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'tool_input' \
    | grep -v 'audit/implementation' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Hook reads bash command from top-level d.command — use d.tool_input.command (or d.get('tool_input',{}).get('command','') in Python)"
  else
    pass "No top-level d.command access in hook commands"
  fi
}

check_hook_command_uses_args_array() {
  # Simple hook commands (single interpreter + script path, no shell metacharacters) should use
  # the args[] exec form ("command": ["bash", ".claude/hooks/x.sh"]) instead of a shell string
  # ("command": "bash .claude/hooks/x.sh") — array form invokes via execve() with no shell
  # interpolation, so it can't be hijacked by injection. Scoped to .claude/hooks/ references only;
  # every "command": key in skills/ is a hook definition (verified — no unrelated JSON matches).
  # TIMELESS: args[] exec form has been supported since v2.1.139; this is a security best practice,
  # not a version-gated feature.
  header "Hook commands use args[] exec form, not shell strings"
  local matches
  matches=$(grep -rn '"command": "[^"]*\.claude/hooks/' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail 'Hook command uses a shell string — use array exec form: "command": ["bash", ".claude/hooks/x.sh"]'
  else
    pass "All hook commands use args[] exec form"
  fi
}

check_owasp_llm_sections_complete() {
  # add/ai-security/implementation.md must cover all 10 OWASP LLM Top 10 v2.0 sections.
  # A missing section leaves a gap in AI security guidance — agents won't know to guard against it.
  # TIMELESS: LLM01-LLM10 are stable section names; the guidance may evolve but the structure is fixed.
  header "OWASP LLM Top 10 v2.0 completeness in ai-security skill"
  local ai_sec="$SKILLS_DIR/add/ai-security/implementation.md"
  local missing=""
  if [[ ! -f "$ai_sec" ]]; then
    fail "add/ai-security/implementation.md not found"
    return
  fi
  for n in 01 02 03 04 05 06 07 08 09 10; do
    if ! grep -q "### LLM${n}" "$ai_sec" 2>/dev/null; then
      missing="$missing LLM${n}"
    fi
  done
  if [[ -n "$missing" ]]; then
    fail "add/ai-security/implementation.md is missing OWASP LLM Top 10 sections:$missing"
  else
    pass "All LLM01-LLM10 sections present"
  fi
}

check_skilldir_refs_resolve() {
  # Every concrete <skill-dir>/<path> reference must resolve to a real file, so the cat-routing
  # contract (CONVENTIONS §1/§8 "every reference file referenced in a cat command actually exists")
  # cannot silently break when a ref file is moved or renamed. Placeholder refs (containing <, >, or |
  # — e.g. <skill-dir>/<stack>/config-files.md) are skipped. TIMELESS: this is the core load mechanism.
  header "<skill-dir> references resolve to real files"
  if ! command -v python3 >/dev/null 2>&1; then
    pass "skipped (python3 not available)"
    return
  fi
  local out
  out=$(python3 - "$SKILLS_DIR" <<'PY'
import os, re, sys
root = sys.argv[1]
def owning(p):
    d = os.path.dirname(p)
    while d.startswith(root):
        if os.path.exists(os.path.join(d, "SKILL.md")): return d
        nd = os.path.dirname(d)
        if nd == d: break
        d = nd
    return None
# Tight char class: matches a concrete path and stops cleanly at backtick/quote/paren/space and
# at placeholder markers (<stack>, <path>, |), so doc placeholders are skipped without a filter.
tok = re.compile(r'<skill-dir>(/[A-Za-z0-9._/*{}-]+)')
bad = []
for dp, _, fs in os.walk(root):
    for f in fs:
        if not f.endswith('.md'): continue
        p = os.path.join(dp, f)
        try: t = open(p, encoding='utf-8').read()
        except Exception: continue
        for m in tok.finditer(t):
            rel = m.group(1).lstrip('/')
            base = owning(p)
            if base and not os.path.exists(os.path.join(base, rel)):
                bad.append(p + ': <skill-dir>/' + rel)
for b in bad: print(b)
PY
)
  if [[ -n "$out" ]]; then
    echo "$out"
    fail "Broken <skill-dir> reference(s) — target file does not exist (CONVENTIONS §8)"
  else
    pass "All concrete <skill-dir> references resolve"
  fi
}

check_ref_header_prereq_suffix() {
  # CONVENTIONS §4: a ref file's prereq must state how it is loaded — ending with
  # "— it is loaded at runtime by the templatecentral:<skill> skill" (or noting it is a
  # de-registered agent utility). The bare "Do not invoke this file directly." form drifted
  # across 12 files; this locks the full form so routing intent stays self-documenting. TIMELESS.
  header "Ref-header prereq carries the §4 'loaded at runtime by' clause"
  local bad=""
  while IFS= read -r f; do
    local head6
    head6=$(head -6 "$f")
    [[ "$head6" == *"<!-- ref:"* ]] || continue
    [[ "$head6" == *"prereq:"* ]] || continue
    if ! grep -qF 'loaded at runtime by the templatecentral:' <<<"$head6" \
       && ! grep -qiE 'de-registered|agent utilit|catted directly' <<<"$head6"; then
      bad+="$f"$'\n'
    fi
  done < <(find "$SKILLS_DIR" -name '*.md' 2>/dev/null)
  if [[ -n "$bad" ]]; then
    printf "%s" "$bad"
    fail "Ref-header prereq missing the §4 'loaded at runtime by the templatecentral:<skill> skill' clause"
  else
    pass "All ref-header prereqs carry the §4 'loaded at runtime by' clause"
  fi
}

check_no_bare_nextjs_route_handlers() {
  # Next.js scaffold wires check-route-logging.mjs into `pnpm check`, which fails the build
  # on any bare `export async function GET/POST/...` App Router handler — every skill example
  # must wrap handlers in withLogging() instead. Catches examples that regress to the bare form
  # (found in four files during the 2026-07 audit: the database + auth-logging skills had drifted
  # from the pattern add/endpoint/nextjs.md documents).
  # TIMELESS: tied to the scaffold's own enforced convention (scripts/check-route-logging.mjs).
  header "Bare Next.js route handler exports (must be wrapped in withLogging)"
  local matches
  matches=$(grep -rEn 'export[[:space:]]+(async[[:space:]]+)?function[[:space:]]+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)[[:space:]]*\(' "$SKILLS_DIR/" 2>/dev/null \
    | grep -v 'check-route-logging' \
    | grep -v 'audit/implementation' \
    | grep -v 'nextjs-backend-extraction' \
    || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "Bare Next.js route handler export — wrap it in withLogging() (see add/endpoint/nextjs.md); pnpm check's check-route-logging.mjs fails the build on this pattern"
  else
    pass "No bare Next.js route handler exports"
  fi
}

check_no_husky() {
  # The git-hook layer is lefthook (harness-kit Step B2) — the single source for ALL stacks,
  # since it installs from Node OR Python (Husky is Node-only and cannot run in a FastAPI scaffold).
  # A stray husky reference means a scaffold drifted back to a contradictory dual-hook setup.
  # TIMELESS: lefthook is the harness design SSOT.
  header "No husky references (lefthook is the git-hook SSOT)"
  local matches
  matches=$(grep -rn 'husky' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "husky reference found — the git-hook layer is lefthook (harness-kit Step B2). Remove husky."
  else
    pass "No husky references (lefthook only)"
  fi
}

check_lefthook_prepare_has_fallback() {
  # lefthook's "install" CLI command has no graceful skip when .git is absent (verified against
  # lefthook's own Go source — unlike husky, which checks existsSync('.git') and no-ops). Every
  # TS scaffold's Dockerfile `deps` stage runs `pnpm i`/`npm ci` before `.git` exists in the build
  # context (dockerignored), which fires the "prepare" script and hard-fails the install unless it
  # tolerates a non-zero exit. A bare "lefthook install" prepare script (missing `|| true`) breaks
  # every Docker build derived from it.
  # TIMELESS: lefthook's install-command behavior is a fixed property of the tool, not ecosystem drift.
  header "lefthook prepare script has Docker-safe fallback"
  local matches
  matches=$(grep -rn '"prepare":[[:space:]]*"lefthook install"' "$SKILLS_DIR/" 2>/dev/null || true)
  if [[ -n "$matches" ]]; then
    echo "$matches"
    fail "prepare script runs bare 'lefthook install' with no fallback — breaks Docker builds (.git absent in build context). Use \"lefthook install || true\"."
  else
    pass "All lefthook prepare scripts tolerate a missing .git"
  fi
}

# ── RUN ALL CHECKS ─────────────────────────────────────────────────────────────

echo "=== templateCentral skill lint ==="
echo "Checking: $SKILLS_DIR/"
echo ""
echo "TIMELESS"
check_no_cve_identifiers
check_no_jurisdiction_specific
check_no_hardcoded_secrets
check_no_ghost_agent_names
check_no_comment_narration
check_owasp_llm_sections_complete
check_skillmd_description_length
check_ref_file_headers
check_skillmd_body_length
check_nesting_depth
check_seeded_skills_scope_tools
check_no_unscoped_bash_grant
check_seeded_skill_paths_are_directories
check_no_toplevel_command_in_hooks
check_hook_command_uses_args_array
check_scaffold_seeds_complete_harness
check_migrate_hook_inventory_matches_kit
check_duplicated_iam_blocks_match
check_yaml_fences_parse
check_no_absolute_plugin_path
check_skilldir_refs_resolve
check_ref_header_prereq_suffix
check_no_husky
check_lefthook_prepare_has_fallback
check_no_bare_nextjs_route_handlers
check_no_postToolUse_full_test_suite
check_no_bare_pytest_invocation
echo ""
echo "ECOSYSTEM-ERA"
check_no_version_pins
check_no_bcrypt
check_no_deprecated_zod_flatten
check_no_middleware_ts
check_no_pragma_or_expires_headers
check_no_jest_apis_in_skills
check_no_globals_jest_in_vitest_projects
check_no_sync_secret_comparison
check_no_zod_string_format_methods
check_no_zod_deprecated_message_key
check_no_mypy_in_postToolUse
check_no_env_api_base_url_fallback
check_no_tanstack_isLoading
check_no_tanstack_isInitialLoading
check_no_starlette_startup_events
check_no_fastapi_orjson_response
check_harness_version_matches_plugin
check_agents_marker_not_drifted_to_semver
echo ""

if [[ $FAILED -ne 0 ]]; then
  echo "=== LINT FAILED — fix the above before pushing ==="
  exit 1
fi

echo "=== All checks passed ==="
