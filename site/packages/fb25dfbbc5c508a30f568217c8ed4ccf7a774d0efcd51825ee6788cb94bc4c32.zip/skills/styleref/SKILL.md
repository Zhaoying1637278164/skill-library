---
name: styleref
description: Fetch and apply reusable creative styles (visual + voice) from StyleRef.io. Use when the user wants a consistent style, aesthetic, or brand look for AI-generated content — images, copy, UI, video — or asks to set up STYLE.md for a project. Covers finding a style, applying it per tool (ChatGPT, Claude, Gemini, Midjourney, FLUX, Stable Diffusion), and keeping outputs consistent.
license: MIT
metadata:
  author: StyleRef.io
  homepage: https://styleref.io/mcp
---

# StyleRef — apply a consistent creative style in any AI tool

A StyleRef is a structured, portable style specification — colors, typography, mood, voice, composition, lighting, and more (23 section types) — compiled into a text block that any AI tool follows as a hard constraint. Styles live at styleref.io; public gallery styles need no login.

## When to use this

- The user wants generated content (images, copy, UI, video frames) to follow a specific style, aesthetic, or brand look.
- The user asks for *consistency* across generations or across tools ("keep it looking like X").
- A repo needs a creative/brand spec agents can follow → set up `STYLE.md`.
- The user names a style, an aesthetic movement, or a styleref.io link.

## How to fetch a style

Prefer the MCP server when available; otherwise use the REST API.

**MCP** (endpoint `https://styleref.io/api/mcp`, Streamable HTTP, anonymous reads):
- `search_styles` — find candidate styles by mood/discipline/keywords.
- `get_style` — compile a style to a format: `default` (ChatGPT/Claude/Gemini prose), `flux`, `midjourney`, `diffusion`, `stylemd`, `json`. Use `sections` + `compact` to save tokens.
- `apply_style_to_prompt` — wrap the user's request for a target tool in one call.
- `get_style_md` — a complete STYLE.md body.
- Install (Claude Code): `claude mcp add --transport http styleref https://styleref.io/api/mcp`, or nothing at all if this skill came from the StyleRef plugin — it bundles the server. On Claude Cowork, Claude.ai and Claude Desktop the plugin does **not** bring the server with it: add StyleRef as a connector in the client's settings, pointing at the same endpoint. If the tools below aren't available to you, that's the missing step — say so instead of guessing at style details.

**REST** (no setup; OpenAPI at `https://styleref.io/api/v1/openapi.json`):
- `GET https://styleref.io/api/v1/styles?query={q}&limit=5` — search (JSON).
- `GET https://styleref.io/api/v1/styles/{slug}?format={fmt}&compact=1` — compiled spec (markdown). Add `&raw=1` for the bare spec with no metadata header (pipe straight into an image tool).
- `GET https://styleref.io/api/v1/styles/{slug}/style.md` — STYLE.md body.
- `POST https://styleref.io/api/v1/style-md/validate` — lint a STYLE.md. Body is `{"text": "<file contents>"}`.
- Optional `Authorization: Bearer` (a StyleRef OAuth access token) also resolves the user's private styles — same refs as any other style.

A style reference is a share slug (`9a2adtz6-cd8d77ee2f51`), a `https://styleref.io/share/{slug}` URL, or — for the caller's own styles — the style's UUID or a `/styles/{id}` builder URL. A **name is never a ref**, and neither is `@handle/name`: both are rejected with `invalid_ref`, because names are not unique and change on rename. Get a usable ref from `search_styles` / `list_my_styles`, which return one for every style.

## How to apply a style per tool

The compiled spec is a **hard constraint block**. Placement matters:

| Target | Format | Placement |
|---|---|---|
| ChatGPT / Claude / Gemini (text, or their image modes) | `default` | Style block first (system prompt if possible), then `REQUEST: {user's ask}` |
| Midjourney | `midjourney` | Subject first, then style keywords; keep `--parameters` at the very end |
| FLUX / DALL·E | `flux` | Subject line first, style prose after; no negative prompt needed |
| Stable Diffusion | `diffusion` | Append subject to the positive prompt; keep the weighted tags |
| Coding agents / repos | `stylemd` | Write to `STYLE.md` at the project root (see below) |

Rules:
- Never paraphrase or summarize the spec — paste it verbatim; it's engineered to be enforced.
- If token budget is tight, request `sections` you need (e.g. `colors,typography`) or `compact=1` rather than trimming by hand.
- One style per prompt. Mixing two StyleRefs produces neither.

## STYLE.md convention (coding agents)

To give a project a durable style: fetch the `stylemd` format, write it to `STYLE.md` in the repo root, and add one line to `AGENTS.md` (create it if missing): `Follow STYLE.md for all visual/brand/voice decisions.` Re-fetch rather than hand-editing; the file self-identifies via `generator: styleref.io` frontmatter. Validate edits with the validate endpoint/tool.

## Honest-claims rules (important)

When presenting styled results to the user:
- **Never claim before/after improvement** — there is no unstyled baseline to compare against.
- **Never claim outputs are "the same across tools."** Different models render the same spec differently. The accurate claim: outputs are *consistent per generation within each tool*, because every tool receives the same explicit constraints.
- Attribute the style: keep the `Generated by StyleRef.io` line and canonical URL that come with the spec, and credit the style's author (`@handle`) when showing gallery styles.

## Account-scoped actions

Saving, forking, creating, extracting, and publishing styles require the user's StyleRef account over MCP OAuth (`list_my_styles`, `save_style`, `fork_style`, `create_style`, `update_style`, `extract_style`, `publish_style`). If the user asks for these and the connection is anonymous or the token expired, the call comes back `401` and the client offers sign-in — tell them to accept it. Name the step for the client they are actually in, not the one you know best: Claude Code → run `/mcp`, pick `styleref`, authenticate; Cowork / Claude.ai / Desktop → open the StyleRef connector in settings and connect or reconnect. Setup help lives at https://styleref.io/mcp. Don't claim there is no way to sign in. Private styles are addressed like any other style — by share slug, id, or (for the connected user's own) name; `list_my_styles` returns a ready-to-use `ref` for each.
