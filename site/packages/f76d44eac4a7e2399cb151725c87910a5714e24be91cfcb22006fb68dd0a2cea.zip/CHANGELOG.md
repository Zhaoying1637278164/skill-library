# Changelog

## 2.0.0 — 2026-09-08

Brought the plugin in line with the current Postproxy MCP server (now ~64 tools).

- New `/postproxy:dm` — read and send direct messages, react, and privately reply to comments on Facebook/Messenger, Instagram, Telegram, and Bluesky.
- New `/postproxy:google-business` — edit a Google Business Profile listing (info, hours, photos, attributes, categories, services, food menus, action links) and reply to reviews.
- New `/postproxy:summary` — one-call activity snapshot with an awaiting-reply backlog.
- Added matching skills for every command, including the previously command-only `comments` and `queues`.
- `/postproxy:publish` — threads (X/Threads/Bluesky), per-platform options, placements, sandboxed media uploads, and `post_delete_on_platform`.
- `/postproxy:profiles` — placements, follower/engagement stats, and profile-group filtering.
- `/postproxy:setup` — profile groups and a connect-a-new-account flow.
- `/postproxy:analytics` — multi-post stats and placement-aware profile stats (incl. Google Business).
- Fixed the queue pause parameter (`enabled: false`) in `/postproxy:queues`.

## 1.0.0 — 2026-06-01

Initial release.

- Claude Code plugin with HTTP transport (no local install required)
- 5 slash commands: `/postproxy:setup`, `/postproxy:publish`, `/postproxy:profiles`, `/postproxy:analytics`, `/postproxy:history`
- Secure API key storage via system keychain (`userConfig`)
- MCP server auto-start on plugin enable
