---
description: Manage a Google Business Profile via Postproxy. Use when the user wants to edit their Google business listing (name, description, hours, photos, attributes, services, food menus, action links) or read and reply to Google reviews.
---

Manage a Google Business Profile location — the business **listing** itself, not posts (posts go through `/postproxy:publish`).

**Resolve the location first:**
1. Call `profiles_list` and pick the `google_business` profile if it isn't known.
2. Call `profiles_placements` — each location is returned as a full path `accounts/X/locations/Y`. That's the `location_id` every tool needs.

**Read before you write.** Google's updates are field-masked and replace named fields wholesale (no merge). Fetch the current object, edit it, patch it back. Confirm destructive edits.

- **Business info:** `google_business_location_get` → `google_business_location_update`. The `fields` list names exactly what's being replaced; anything named but omitted is **cleared**. Categories are resource names (`categories/gcid:...`) resolved via `google_business_categories_list` (needs `region_code`; `filter` searches by display name).
- **Hours:** `google_business_hours_update` — each named block (`regularHours`/`specialHours`/`moreHours`) is replaced entirely.
- **Attributes:** **always** call `google_business_attributes_available` first (valid set + value types depend on category/region), then `google_business_attributes_update` matching each `valueType` (BOOL→`values`, URL→`uriValues`, ENUM→`repeatedEnumValue`). Read with `google_business_attributes_get`.
- **Media:** `google_business_media_list`; `google_business_media_create` fetches from a **public https URL** (min 250×250, ≤5MB); `google_business_media_delete` by resource name.
- **Action links:** `google_business_place_action_links_list` / `_create` / `_update` / `_delete`; accepted `place_action_type` varies by category.
- **Services & food menus:** `google_business_service_list_get`/`_update` and `google_business_food_menus_get`/`_update` are **full replacements** gated on `metadata.canModifyServiceList` / `canHaveFoodMenus` (422 = unsupported for this location).

**Reviews** (profile-scoped, not on a post):
- `profile_comments_list` (optional `placement_id` filters to one location); reviews sync twice daily (06:00 & 18:00 UTC). Inspect one with `profile_comments_get`.
- Reply only — `profile_comments_create` with `parent_id` (the review) + `text`; no top-level comments; publishes async (`pending`→`published`/`failed`).
- `profile_comments_delete` removes **only your reply**; the review itself can't be deleted.
