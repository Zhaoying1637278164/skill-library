---
description: Manage comments on posts published via Postproxy. Use when the user wants to list, reply to, hide, delete, or like comments on a post on Instagram, Facebook, Threads, YouTube, or LinkedIn.
---

Manage comments on a published post. (For Google Business **reviews**, use `/postproxy:google-business` — reviews live on a location, not a post.)

**Listing comments:**
1. If no post ID is given, call `history_list` and show recent posts so the user can pick one.
2. Call `comments_list` with the post ID and `profile_id` (identifies which platform's comments to read). It returns paginated top-level comments with nested replies. Display: Author | Comment | Date | Reply count. Use `comments_get` to expand one comment and its replies.

**Replying** — `comments_create` with `post_id`, `profile_id`, `text`, and `parent_id` (the comment to reply to; omit to comment on the post itself). Supported on Instagram, Facebook, Threads, YouTube, LinkedIn. Publishes asynchronously.

**Hiding** — `comments_hide` / `comments_unhide`. Instagram, Facebook, Threads only.

**Deleting** — `comments_delete`. Instagram, Facebook, YouTube, LinkedIn (not Threads). Confirm before deleting.

**Liking** — `comments_like` / `comments_unlike`. Facebook only.

Comment IDs can be a Postproxy ID or the platform's external ID. Always show the post ID and profile ID in use so the user can verify the right post.
