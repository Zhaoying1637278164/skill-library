---
description: Show performance stats for a post or a social media profile. Use when the user asks about engagement, impressions, likes, or follower growth.
---

Determine what to show based on $ARGUMENTS:

- **Post stats** — call `post_stats` with `post_ids` (up to 50). It returns every matching snapshot (trends over time); optionally filter by `profiles` (comma-separated hashids or network names) and a `from`/`to` timespan. Show impressions, likes, comments, shares per platform.
- **Profile stats** — call `profiles_list` to find the profile, then `profiles_stats` for the daily follower/engagement series. `placement_id` (from `profiles_placements`) is **required** for Facebook, LinkedIn, Telegram, and Google Business; omit for the others. Fields are platform-native; Google Business is per-location (impressions/clicks/calls/directions/conversations, no follower count).
- **Empty** — ask: a specific post (post ID) or a profile? For an account-wide snapshot, use `/postproxy:summary`.

Format numbers with thousands separators. Highlight the best-performing platform.
