---
description: Verify Postproxy connection and show connected social media profiles. Use on first install, when troubleshooting authentication, or when connecting a new social media account.
---

Check the Postproxy connection and show the user what's available:

1. Call `auth_status` to verify the API key is working. Show workspace name and API key status.
2. Call `profile_groups_list` for the groups (brands/clients) the key can reach, then `profiles_list` for the connected profiles. Display profiles as a table: Platform | Profile name | Profile ID.
3. If auth fails, tell the user to check their API key at app.postproxy.dev/settings/api.

**Connecting a new account:** call `profile_groups_initialize_connection` with the `profile_group_id` and `platform`. For Bluesky also pass `identifier` + `app_password`; for Telegram pass the `bot_token` from @BotFather. It returns a URL for the user to open to finish the connect flow; re-run setup afterward to confirm.
