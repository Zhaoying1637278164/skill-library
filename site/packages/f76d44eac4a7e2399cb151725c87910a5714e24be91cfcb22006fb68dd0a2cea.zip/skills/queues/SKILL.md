---
description: Manage Postproxy posting queues. Use when the user wants to list, create, update, pause, or delete recurring posting queues, or check a queue's next available slot.
---

Manage posting queues — queues auto-schedule posts into recurring weekly timeslots with priority-based ordering.

**Listing** — `queues_list` (optional `profile_group_id`). Display: Name | Profile group | Timeslots/week | Next slot | Status (active/paused). Use `queues_get` for one queue's timeslots and post count.

**Creating** — `queues_create`:
1. Ask for a name and which profile group (`profiles_list` surfaces the `profile_group_id`).
2. Collect weekly timeslots — each is a `day` (0 = Sunday … 6 = Saturday) and a 24-hour `time` (`HH:MM`).
3. Ask for an IANA `timezone` (default UTC) and optional `jitter` (0–60 min random offset for natural timing).

**Updating** — `queues_update` with the queue ID and only the fields to change:
- Rename/describe via `name`/`description`; change `timezone` or `jitter`.
- Pause with `enabled: false`, resume with `enabled: true`.
- Add a slot: `{ "day": 1, "time": "09:00" }`; remove one: `{ "id": 42, "_destroy": true }`. Changing timezone or timeslots rearranges all queued posts.

**Next slot** — `queues_next_slot` shows the upcoming publish time.

**Deleting** — `queues_delete`. Warn that queued posts keep their content but lose the queue reference (they won't auto-publish).

To add a post to a queue, use `/postproxy:publish` with a `queue_id`.
