---
description: Create and publish a social media post via Postproxy. Use when the user wants to post, schedule, queue, draft, edit, thread, or delete content across social media platforms.
---

Guide the user through publishing a post.

1. If profiles aren't known, call `profiles_list`. `profiles` accepts profile hashids or bare platform names (`linkedin`, `instagram`, `twitter`, …). For a specific page/org/board/channel/location, resolve it via `profiles_placements`.
2. Ask which profiles to post to and for the content. Watch platform limits: X plain text ≤ 280 chars (a URL costs 50 credits); Bluesky ≤ 300 graphemes; Telegram 4,096 / 1,024 with media; Google Business ≤ 1,500 chars, 1 image, no video.
3. Media: pass URLs or local file paths in `media`. In a sandboxed/remote environment, use `upload_create` to get a temporary upload URL, POST the file bytes to it, then pass the returned URL in `media`.
4. Choose timing:
   - **Now** — `post_publish` with `profiles` + `content`.
   - **Draft** — `post_publish` with `draft: true` (activate later with `post_publish_draft`).
   - **Scheduled** — `post_publish` with `schedule` (ISO 8601).
   - **Queue** — `queues_list`, then `post_publish` with `queue_id` (+ optional `queue_priority` high/medium/low). Don't combine `queue_id` with `schedule`.
5. **Threads** (X, Threads, Bluesky only) go in the `thread` array. Per-network options (YouTube `privacy_status`/`title`, TikTok flags, Pinterest `board_id`, Telegram `chat_id`/`parse_mode`, Google Business `cta_action_type`) go in a `platforms` object.
6. Use `require_confirmation: true` for a dry run. Show the returned post ID + status; suggest `/postproxy:history` to track it.

**Editing** — `post_update` (drafts, or scheduled 5+ min out). Only send changed fields; `profiles`/`media`/`thread` are full replacements, `platforms` merges.

**Deleting** — `post_delete` (add `delete_on_platform: true` to also remove from platforms), or `post_delete_on_platform` to remove from platforms while keeping the Postproxy record (Facebook/Threads/X/LinkedIn/Pinterest/YouTube only — not Instagram/TikTok). Confirm first.
