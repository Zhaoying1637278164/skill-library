---
description: List connected social media accounts in Postproxy. Use when the user asks which platforms are connected, wants to see their accounts or placements, or wants follower/engagement stats for a profile.
---

Show the user their connected profiles.

**Listing** — call `profiles_list` and display a markdown table:

| Platform | Name | Profile ID |
|----------|------|------------|
| ...      | ...  | ...        |

To scope to one brand/client, call `profile_groups_list` and pass its `id` as `profile_group_id`. If empty, point the user to `/postproxy:setup` to connect an account.

**Placements** — `profiles_placements` lists a profile's sub-destinations: Facebook pages, LinkedIn profile + organizations, Pinterest boards, Telegram channels, Google Business locations (returned as `accounts/X/locations/Y` paths).

**Stats** — `profiles_stats` returns the daily follower/engagement series. `placement_id` (from `profiles_placements`) is **required** for Facebook, LinkedIn, Telegram, and Google Business; omit for the others. Fields are platform-native; Google Business is per-location (impressions/clicks/calls/directions/conversations, no follower count). For an account-wide snapshot, use `/postproxy:summary`.
