---
description: Show recent social media post activity from Postproxy. Use when the user asks what was posted recently or wants to check post statuses.
---

Call `history_list` (default limit applies). Display results as a markdown table:

| Date | Platforms | Content preview | Status |
|------|-----------|-----------------|--------|
| ...  | ...       | first 60 chars  | ...    |

If the user wants details on a specific post, call `post_status` with the post ID.
