---
description: Send and manage direct messages via Postproxy. Use when the user wants to read or send DMs, reply in a chat, react to a message, or privately reply to a comment on Facebook/Messenger, Instagram, Telegram, or Bluesky.
---

Manage direct messages. DMs are supported on **Facebook (Messenger), Instagram, Telegram, and Bluesky** — not the other networks.

**Listing chats:**
1. If a profile isn't known, call `profiles_list` and pick a DM-capable profile.
2. Call `dm_chats_list` with the profile ID. Display: Participant | Last message | Direction | When (newest first).

**Reading a chat:**
- Call `dm_messages_list` with the chat ID (a Postproxy hashid or the platform's `external_conversation_id`). Show newest-first with direction and status. When an inbound message carries `tapped_action`, read its `payload`/`title` instead of digging through `platform_data` — that's the participant tapping a quick reply or button you sent.

**Sending a message:**
1. Use an existing chat ID, or call `dm_chat_create` with `participant_external_id` to find-or-create a chat (idempotent).
2. Call `dm_message_send` with the chat ID and **either** `body` **or** one `media` attachment (never both; media isn't supported on Bluesky).
   - Interactive elements `quick_replies` / `buttons` / `card` are **Facebook + Instagram only** (rejected on Telegram and Bluesky). On Instagram, quick replies can't be mixed with media or buttons.
   - `reply_to_external_id` and `reply_markup` are **Telegram only**.
   - Outside Meta's **24h window**, `tag: HUMAN_AGENT` (Facebook/Instagram) extends it to 7 days, but only for a human agent replying to the participant's own inquiry — never marketing or automation, or Meta may suspend the account's messaging.

**Editing** (`dm_message_edit`) is **Telegram only** — pass `body` and/or `reply_markup` (`{}` clears the keyboard).

**Reacting** (`dm_message_react` / `dm_message_unreact`) is **Facebook Messenger + Instagram only**; a second react replaces the previous one.

**Archiving** (`dm_chat_archive` / `dm_chat_unarchive`) is **Bluesky only** (mute/unmute).

**Private replies to comments** (`dm_comment_private_reply`) are **Instagram + Facebook Page comments only**: DMs the comment author, bypasses the 24h window (comments up to 7 days old), auto-creates a chat, and works **once per comment, ever**. No media.

Use `dm_message_get` / `dm_chat_get` to inspect a single message or chat by hashid or external ID. Always confirm the profile and conversation before sending.
