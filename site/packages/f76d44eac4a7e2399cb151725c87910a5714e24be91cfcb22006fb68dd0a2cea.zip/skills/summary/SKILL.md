---
description: Show an account activity summary via Postproxy. Use when the user asks "what's the status?", wants an overview of recent posting/engagement, or wants to know what comments, reviews, or DMs are awaiting a reply.
---

Answer "what's happening across my accounts?" in one call.

1. Choose the window: `24h` (default), `7d`, or `30d` — or pass explicit `from`/`to` dates.
2. Optionally scope to one profile group via `profile_groups_list` → `profile_group_id`; omit to cover everything the key can reach.
3. Call `summary_get`.

Render a per-network dashboard:
- **Published / failed / next scheduled** posts (a multi-network post counts once; `by_platform` counts per-network deliveries).
- **Engagement** totals — lifetime-to-date for posts published in the window, not engagement earned during it; `null` when insights are off.
- **Received**: comments, reviews, DM volume (`dms` is `null` when DMs are off).
- **Awaiting reply**: unanswered comments/reviews and DM chats whose newest message is inbound, plus how many are near the 24h Meta window. Backlog counts always look back 30 days regardless of window (`window.backlog_from`).

Prefer this over separate `history_list` / comments / DM calls. Route follow-ups to `/postproxy:comments`, `/postproxy:google-business` (reviews), or `/postproxy:dm`.
