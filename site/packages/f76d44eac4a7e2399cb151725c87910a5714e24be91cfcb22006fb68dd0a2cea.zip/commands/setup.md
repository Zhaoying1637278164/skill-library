---
description: Verify Postproxy connection, show connected profiles and groups, and connect a new social media account.
allowed-tools: mcp__postproxy__auth_status, mcp__postproxy__profiles_list, mcp__postproxy__profile_groups_list, mcp__postproxy__profile_groups_initialize_connection
---

Check the Postproxy connection and show the user what's available:

1. Call `auth_status` to verify the API key is working. Show workspace info and API key status.
2. Call `profile_groups_list` to show the profile groups (brands/clients) the key can reach, then `profiles_list` for the connected social media profiles. Display profiles as a table: Platform | Profile name | Profile ID.
3. If auth fails, tell the user to check their API key at app.postproxy.dev/settings/api.

**Connecting a new account** (if the user asks, or has no profiles yet):
- Call `profile_groups_initialize_connection` with the `profile_group_id` and the `platform` (e.g. `instagram`, `linkedin`, `bluesky`, `telegram`). For Bluesky also pass `identifier` + `app_password`; for Telegram pass the `bot_token` from @BotFather.
- It returns a URL — tell the user to open it to finish the OAuth/connect flow, then re-run `/postproxy:setup` to confirm the new profile appears.
