---
description: Send and manage direct messages (DMs) via Postproxy — list chats, read and send messages, react, and send private replies to comments. Works on Facebook/Messenger, Instagram, Telegram, and Bluesky.
allowed-tools: mcp__postproxy__profiles_list, mcp__postproxy__dm_chats_list, mcp__postproxy__dm_chat_create, mcp__postproxy__dm_chat_get, mcp__postproxy__dm_chat_archive, mcp__postproxy__dm_chat_unarchive, mcp__postproxy__dm_messages_list, mcp__postproxy__dm_message_send, mcp__postproxy__dm_message_get, mcp__postproxy__dm_message_edit, mcp__postproxy__dm_message_react, mcp__postproxy__dm_message_unreact, mcp__postproxy__dm_comment_private_reply, mcp__postproxy__history_list
---

Manage direct messages. DMs are supported on **Facebook (Messenger), Instagram, Telegram, and Bluesky**. Determine intent from $ARGUMENTS:

**Listing chats** (default if no clear action):
1. If a profile isn't specified, call `profiles_list` and let the user pick a DM-capable profile.
2. Call `dm_chats_list` with the profile ID. Display: Participant | Last message | Direction | When. Newest activity first.
3. Ask what to do: open a chat, send a message, or reply to a comment.

**Reading a chat:**
- Call `dm_messages_list` with the chat ID (accepts a Postproxy hashid or the platform's `external_conversation_id`). Show messages newest-first with direction (inbound/outbound) and status. If an inbound message carries `tapped_action`, surface its `payload`/`title` — that's the user tapping a quick reply or button you sent.

**Sending a message:**
1. Resolve the chat: use an existing chat ID, or call `dm_chat_create` with the participant's platform ID (`participant_external_id`) to find-or-create one.
2. Call `dm_message_send` with the chat ID and **either** `body` (text) **or** a single `media` attachment — never both. Messages deliver asynchronously (status `pending`).
   - **Facebook & Instagram only:** attach `quick_replies` (up to 13 chips), `buttons` (up to 3), or a rich `card`. On Instagram, quick replies can't be combined with media or buttons.
   - **Telegram only:** `reply_to_external_id` to thread under a message, and `reply_markup` for inline keyboards.
   - Outside Meta's **24h messaging window**, a human agent replying to the participant's own inquiry may pass `tag: HUMAN_AGENT` (Facebook/Instagram only, extends to 7 days). Never use it for promotional or automated content — Meta can suspend the account's messaging.

**Editing a sent message** (Telegram only):
- Call `dm_message_edit` with the message ID and new `body` and/or `reply_markup` (pass `{}` to clear the keyboard). Facebook/Instagram don't allow outbound edits.

**Reacting to a message** (Facebook Messenger & Instagram only):
- Call `dm_message_react` (`reaction` name or `emoji`; a second react replaces the first). Undo with `dm_message_unreact`.

**Archiving a chat** (Bluesky only):
- Call `dm_chat_archive` to mute, `dm_chat_unarchive` to unmute.

**Privately replying to a comment** (Instagram & Facebook Page comments only):
- Call `dm_comment_private_reply` with `post_id`, `comment_id`, `profile_id`, and `text`. This is Meta "Private Replies" — it DMs the comment author, bypasses the 24h window (comments up to 7 days old), and auto-creates a chat. Only **one private reply per comment, ever**; no media. Use `history_list` to find the post if needed.

Always show the profile and chat/participant being used so the user can confirm the right conversation.

$ARGUMENTS can be a profile name/ID or a chat ID to jump straight in, e.g. `/postproxy:dm instagram`
