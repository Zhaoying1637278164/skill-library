---
description: Show an activity summary across all connected accounts — posts, engagement, comments, reviews, and DMs, plus what's awaiting your reply.
allowed-tools: mcp__postproxy__summary_get, mcp__postproxy__profiles_list, mcp__postproxy__profile_groups_list
---

Give the user a one-call activity snapshot. Determine the scope from $ARGUMENTS:

1. Pick the time window: `24h` (default), `7d`, or `30d`. If the user gives explicit dates, pass `from`/`to` instead.
2. Optionally scope to one profile group — call `profile_groups_list` to resolve a `profile_group_id`. Omit to cover every group the API key can reach.
3. Call `summary_get` with the chosen window/range and optional `profile_group_id`.

Present it as a dashboard, per network where useful:
- **Published / failed / next scheduled** — post counts (a post to three networks counts once; `by_platform` counts per-network deliveries).
- **Engagement totals** — note this is lifetime-to-date for posts published in the window, not engagement earned during it. `null` means insights are off for the account.
- **Received** — comments, reviews, and DM volume.
- **Awaiting your reply** — unanswered comments and reviews, and DM chats whose newest message is inbound (call out how many are near their 24h Meta window). These backlog counts look back 30 days regardless of the window (`window.backlog_from`).

Prefer this over calling `history_list` / comments / DM tools separately. Point the user to `/postproxy:comments`, `/postproxy:google-business` (reviews), or `/postproxy:dm` to act on the backlog.

$ARGUMENTS can be a window like `7d` or `30d`, e.g. `/postproxy:summary 7d`
