---
description: Manage Postproxy posting queues — list, create, update schedules, pause, and delete queues for recurring social media publishing.
allowed-tools: mcp__postproxy__queues_list, mcp__postproxy__queues_get, mcp__postproxy__queues_create, mcp__postproxy__queues_update, mcp__postproxy__queues_delete, mcp__postproxy__queues_next_slot, mcp__postproxy__profiles_list
---

Manage posting queues. Determine intent from $ARGUMENTS:

**Listing queues** (default if no clear action):
- Call `queues_list` and display: Name | Profile group | Timeslots/week | Next slot | Status (active/paused).
- Suggest actions: create a new queue, update a queue, or check the next slot.

**Creating a queue:**
1. Ask for a name and which profile group to use (call `profiles_list` if the `profile_group_id` isn't known).
2. Ask for weekly timeslots — each is a `day` (0 = Sunday … 6 = Saturday) and a 24-hour `time` (`HH:MM`), e.g. Mon/Wed/Fri at 09:00.
3. Ask for an IANA `timezone` (default UTC) and optional `jitter` (0–60 min random offset for natural timing).
4. Call `queues_create` with the collected parameters.

**Updating a queue** (rename, change timeslots, pause/resume):
- Call `queues_update` with the queue ID and only the changed fields. To pause, set `enabled: false`; to resume, `enabled: true`.
- Add a timeslot with `{ "day": 1, "time": "09:00" }`; remove one with `{ "id": 42, "_destroy": true }`. Changing timezone or timeslots rearranges all queued posts.

**Checking the next slot:**
- Call `queues_next_slot` with the queue ID and show the upcoming publish time.

**Deleting a queue:**
- Call `queues_delete`. Warn that existing queued posts will remain but won't publish automatically.

$ARGUMENTS can be a queue name or ID to jump straight to its details, e.g. `/postproxy:queues`
