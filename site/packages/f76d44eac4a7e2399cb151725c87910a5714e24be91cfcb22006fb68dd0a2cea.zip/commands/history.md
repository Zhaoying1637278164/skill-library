---
description: Show recent social media post activity from Postproxy
allowed-tools: mcp__postproxy__history_list, mcp__postproxy__post_status
---

Call `history_list` (default limit applies). Display results as a markdown table:

| Date | Platforms | Content preview | Status |
|------|-----------|-----------------|--------|
| ...  | ...       | first 60 chars  | ...    |

If the user wants details on a specific post, call `post_status` with the post ID.
