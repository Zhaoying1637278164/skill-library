---
description: Show performance stats for a post or a social media profile
allowed-tools: mcp__postproxy__post_stats, mcp__postproxy__profiles_list, mcp__postproxy__profiles_placements, mcp__postproxy__profiles_stats
---

Determine what to show based on $ARGUMENTS:

- **Post stats** — if $ARGUMENTS has one or more post IDs, call `post_stats` with `post_ids` (up to 50). It returns every matching snapshot so you can show trends; optionally filter by `profiles` (comma-separated hashids or network names) and a `from`/`to` timespan. Show impressions, likes, comments, shares per platform.
- **Profile stats** — if $ARGUMENTS is "overview" or a profile name/ID, call `profiles_list` to find the profile, then `profiles_stats` for the daily follower/engagement series. `placement_id` (from `profiles_placements`) is **required** for Facebook, LinkedIn, Telegram, and Google Business; omit for the others. Fields are platform-native; Google Business is per-location (impressions, website clicks, call clicks, directions, conversations — no follower count).
- **Empty** — ask whether they want stats for a specific post (give a post ID) or a profile. For an account-wide snapshot across posts, comments, reviews, and DMs, point them to `/postproxy:summary`.

Format numbers with thousands separators. Highlight the best-performing platform.
