---
description: List connected social media accounts in Postproxy, their placements, and follower/engagement stats.
allowed-tools: mcp__postproxy__profiles_list, mcp__postproxy__profiles_placements, mcp__postproxy__profiles_stats, mcp__postproxy__profile_groups_list
---

Show the user their connected profiles. Determine intent from $ARGUMENTS:

**Listing profiles** (default):
1. Call `profiles_list` and display a markdown table:

   | Platform | Name | Profile ID |
   |----------|------|------------|
   | ...      | ...  | ...        |

2. To scope to one brand/client, call `profile_groups_list` and pass its `id` as `profile_group_id` to `profiles_list`.
3. If the list is empty, tell the user to connect profiles (see `/postproxy:setup` to start a connection).

**Showing placements** — call `profiles_placements` with a profile ID to list its sub-destinations: Facebook pages, LinkedIn personal profile + organizations, Pinterest boards, Telegram channels, or Google Business locations. (Google Business locations come back as `accounts/X/locations/Y` paths.)

**Showing follower/engagement stats** — call `profiles_stats` with a profile ID for the daily snapshot series. `placement_id` (from `profiles_placements`) is **required** for Facebook, LinkedIn, Telegram, and Google Business; omit it for Instagram/Threads/YouTube/X/TikTok/Pinterest/Bluesky. Stats fields are platform-native (not normalized); Google Business is per-location (impressions, clicks, calls, directions, conversations — no follower count).

$ARGUMENTS can be a profile name/ID to jump to its placements or stats.
