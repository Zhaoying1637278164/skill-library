---
description: Manage comments on posts published via Postproxy — list, reply, hide, delete, and like comments across Instagram, Facebook, Threads, YouTube, and LinkedIn.
allowed-tools: mcp__postproxy__comments_list, mcp__postproxy__comments_get, mcp__postproxy__comments_create, mcp__postproxy__comments_delete, mcp__postproxy__comments_hide, mcp__postproxy__comments_unhide, mcp__postproxy__comments_like, mcp__postproxy__comments_unlike, mcp__postproxy__history_list
---

Manage comments on a post. Determine intent from $ARGUMENTS:

**Listing comments** (default if no clear action):
1. If a post ID is not in $ARGUMENTS, call `history_list` and show recent posts so the user can pick one.
2. Call `comments_list` with the post ID and profile ID. Display as a table: Author | Comment | Date | Reply count.
3. Ask what to do: reply, hide, delete, or done.

**Replying to a comment:**
- Call `comments_create` with the post ID, profile ID, parent_id (the comment to reply to), and the reply text.

**Hiding a comment** (Instagram, Facebook, Threads):
- Call `comments_hide`. To undo, call `comments_unhide`.

**Deleting a comment** (Instagram, Facebook, YouTube, LinkedIn):
- Call `comments_delete`. Confirm before deleting.

**Liking a comment** (Facebook only):
- Call `comments_like`. To undo, call `comments_unlike`.

**Google Business reviews** are not post comments — they live on a location. Manage them with `/postproxy:google-business`.

Always show the post ID and profile ID being used so the user can verify the right post is selected.

$ARGUMENTS can be a post ID to jump straight to listing its comments, e.g. `/postproxy:comments abc123`
