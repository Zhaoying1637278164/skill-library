---
description: Create and publish a social media post via Postproxy. Also handles drafts, edits to scheduled posts, threads, per-platform options, and post deletion.
allowed-tools: mcp__postproxy__profiles_list, mcp__postproxy__profiles_placements, mcp__postproxy__post_publish, mcp__postproxy__post_update, mcp__postproxy__post_publish_draft, mcp__postproxy__post_delete, mcp__postproxy__post_delete_on_platform, mcp__postproxy__upload_create, mcp__postproxy__queues_list, mcp__postproxy__post_status
---

Guide the user through publishing a post, or handle an edit/draft/delete if $ARGUMENTS mentions one.

**Publishing a new post:**
1. If profiles are not yet known, call `profiles_list` and show them. `profiles` accepts profile hashids or bare platform names (e.g. `linkedin`, `instagram`, `twitter`).
2. Ask which profiles to post to (if not specified in $ARGUMENTS). To target a specific page/org/board/channel/location, call `profiles_placements` (Facebook pages, LinkedIn orgs, Pinterest boards, Telegram channels, Google Business locations).
3. Ask for content (if not in $ARGUMENTS). Remind about platform limits: X/Twitter plain text ≤ 280 chars (X with a URL costs 50 credits); Bluesky ≤ 300 graphemes; Telegram 4,096 chars text-only / 1,024 with media; Google Business ≤ 1,500 chars, 1 image, no video.
4. Media: pass URLs or local file paths in `media` (absolute, relative, or `~`). In a sandboxed/remote environment where local paths aren't reachable, use `upload_create` to get a temporary upload URL, POST the bytes to it, then pass the returned URL in `media`.
5. Ask: publish now, save as draft, schedule for a specific time, or add to a queue?
   - Now: call `post_publish` with `profiles` and `content`.
   - Draft: `post_publish` with `draft: true`. Show the post ID to activate later.
   - Scheduled: ask for datetime, `post_publish` with `schedule` (ISO 8601).
   - Queue: `queues_list` to show queues, then `post_publish` with `queue_id` (optionally `queue_priority`: high/medium/low). Don't combine `queue_id` with `schedule`.
6. For a **thread** (X/Twitter, Threads, and Bluesky only), pass the follow-up posts in `thread`.
7. For per-network customization (e.g. YouTube `privacy_status`/`title`, TikTok options, Pinterest `board_id`, Telegram `chat_id`/`parse_mode`, Google Business `cta_action_type`), pass a `platforms` object.
8. Use `require_confirmation: true` for a dry run that returns a summary without publishing. Show the returned post ID and status; suggest `/postproxy:history` to track it.

**Editing a draft or scheduled post** (drafts, or scheduled 5+ min before publish):
- Call `post_update` with the post ID and only the fields to change. `profiles`, `media`, and `thread` are full replacements (send an empty `media` array to clear all); `platforms` is merged.

**Activating a draft:** `post_publish_draft` with the post ID.

**Deleting a post:**
- `post_delete` removes it from Postproxy; pass `delete_on_platform: true` to also remove it from every published platform first.
- To remove from platforms **without** deleting the Postproxy record, use `post_delete_on_platform` (optionally scoped by `post_profile_id`, `profile_id`, or `network`). Supported on Facebook, Threads, X, LinkedIn, Pinterest, YouTube — **not** Instagram or TikTok. Confirm before deleting.

$ARGUMENTS can be the post content passed directly, e.g. `/postproxy:publish Hello from Claude!`
