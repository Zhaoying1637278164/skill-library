---
description: Manage a Google Business Profile via Postproxy — edit location info, hours, photos, attributes, services, food menus, and action links, and reply to reviews.
allowed-tools: mcp__postproxy__profiles_list, mcp__postproxy__profiles_placements, mcp__postproxy__google_business_location_get, mcp__postproxy__google_business_location_update, mcp__postproxy__google_business_hours_update, mcp__postproxy__google_business_attributes_available, mcp__postproxy__google_business_attributes_get, mcp__postproxy__google_business_attributes_update, mcp__postproxy__google_business_categories_list, mcp__postproxy__google_business_media_list, mcp__postproxy__google_business_media_create, mcp__postproxy__google_business_media_delete, mcp__postproxy__google_business_place_action_links_list, mcp__postproxy__google_business_place_action_link_create, mcp__postproxy__google_business_place_action_link_update, mcp__postproxy__google_business_place_action_link_delete, mcp__postproxy__google_business_service_list_get, mcp__postproxy__google_business_service_list_update, mcp__postproxy__google_business_food_menus_get, mcp__postproxy__google_business_food_menus_update, mcp__postproxy__profile_comments_list, mcp__postproxy__profile_comments_get, mcp__postproxy__profile_comments_create, mcp__postproxy__profile_comments_delete
---

Manage a Google Business Profile location. This edits the business **listing** itself (not posts published to it — use `/postproxy:publish` for posts).

**First, resolve the location:**
1. If not known, call `profiles_list` and pick the `google_business` profile.
2. Call `profiles_placements` with that profile ID. Each location comes back as a full resource path `accounts/X/locations/Y` — that's the `location_id` every tool below needs.

**Golden rule — read before you write.** Google's updates are field-masked and replace named fields wholesale (they do NOT merge). Always fetch the current object first, edit it, then patch it back. Confirm destructive edits with the user.

**Business info** (name, description, website, phones, category, address):
- Read with `google_business_location_get`, then `google_business_location_update` with a `fields` list naming exactly what you're replacing — anything named there but omitted from the payload is **cleared**. Category values are resource names like `categories/gcid:...`; resolve them via `google_business_categories_list` (needs `region_code`; use `filter` to search by display name).

**Opening hours:**
- Read from `google_business_location_get`, then `google_business_hours_update`. Each block you name in `fields` (`regularHours`, `specialHours`, `moreHours`) is replaced entirely.

**Attributes** (payments, accessibility, service options, social links):
- **Always** call `google_business_attributes_available` first — valid attributes and their value types depend on the category/region. Then `google_business_attributes_update`, matching each attribute's `valueType` (BOOL → `values:[true]`, URL → `uriValues`, ENUM → `repeatedEnumValue`). Read current values with `google_business_attributes_get`.

**Photos & videos:**
- `google_business_media_list` to view. `google_business_media_create` adds media from a **public https URL Google can fetch** (min 250×250, max 5MB; use category COVER/LOGO only to change the header/logo). `google_business_media_delete` removes by resource name.

**Action links** ("Book online", "Order online", etc.):
- `google_business_place_action_links_list` to view; `..._create` / `..._update` / `..._delete` to manage. Accepted `place_action_type` values vary by category.

**Services** (`google_business_service_list_get` / `_update`) and **food menus** (`google_business_food_menus_get` / `_update`):
- Both are **full replacements** — read the current list, edit it, send it back complete. Gated on `metadata.canModifyServiceList` / `canHaveFoodMenus`; a 422 means the location doesn't support it.

**Reviews:**
- Reviews live on the location, so list them with `profile_comments_list` (profile ID, optional `placement_id` to filter to one location). They sync from Google twice daily (06:00 & 18:00 UTC).
- You can only **reply** to an existing review — call `profile_comments_create` with `parent_id` (the review) and `text`. Top-level comments aren't allowed. Replies publish asynchronously (`pending` → `published`/`failed`).
- `profile_comments_delete` removes **only your reply** — Google doesn't let businesses delete the review itself.

$ARGUMENTS can name the profile or the task, e.g. `/postproxy:google-business update hours`
