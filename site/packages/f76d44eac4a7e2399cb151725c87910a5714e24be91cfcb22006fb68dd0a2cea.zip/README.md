# Postproxy

Run your whole social presence from your AI agent — publish and schedule posts, manage queues, reply to comments and DMs, handle Google Business listings and reviews, and pull analytics — across Instagram, Facebook, Threads, TikTok, X, YouTube, LinkedIn, Pinterest, Bluesky, Telegram, and Google Business. One API, all platforms.

Postproxy is a standard [MCP](https://modelcontextprotocol.io) server, so it works anywhere MCP does. This repo packages it as a **Claude Code plugin** (with slash commands and skills), but the same server drops into **Cursor, Windsurf, VS Code, or any MCP client** just as easily.

## Install

### Claude Code

```
claude plugin install github:postproxy/postproxy-claude-plugin
```

You'll be prompted for your Postproxy API key once. It's stored in your system keychain — not in any config file. This adds the `/postproxy:*` commands and skills listed below.

### Cursor, Windsurf & other MCP clients

Add the hosted Postproxy MCP server to your client's MCP config (for Cursor that's `~/.cursor/mcp.json` or a project `.cursor/mcp.json`):

```json
{
  "mcpServers": {
    "postproxy": {
      "url": "https://mcp.postproxy.dev/mcp?api_key=YOUR_API_KEY"
    }
  }
}
```

Prefer a local stdio process over the hosted endpoint? Use the npm package instead:

```json
{
  "mcpServers": {
    "postproxy": {
      "command": "npx",
      "args": ["-y", "postproxy-mcp"],
      "env": { "POSTPROXY_API_KEY": "YOUR_API_KEY" }
    }
  }
}
```

In these clients there are no slash commands — just ask the agent in plain language ("post this to LinkedIn and Instagram", "reply to the latest Google review", "what's awaiting a reply?") and it calls the right tools.

Get your API key at [app.postproxy.dev/settings/api](https://app.postproxy.dev/settings/api).

## What you can do

The full toolset is available in every client. In Claude Code these slash commands wrap it; elsewhere, just ask in natural language.

| Command | What it does |
|---------|-------------|
| `/postproxy:setup` | Verify your connection, list accounts and groups, and connect a new account |
| `/postproxy:publish` | Create and publish a post — instant, scheduled, queued, draft, or thread |
| `/postproxy:profiles` | See connected profiles, their placements, and follower/engagement stats |
| `/postproxy:analytics` | View engagement stats for posts and profiles |
| `/postproxy:summary` | Activity snapshot — posts, engagement, and what's awaiting a reply |
| `/postproxy:history` | Review recent posting activity |
| `/postproxy:comments` | List, reply to, hide, delete, or like comments on a post |
| `/postproxy:dm` | Read and send direct messages; reply privately to comments |
| `/postproxy:google-business` | Edit your Google Business listing and reply to reviews |
| `/postproxy:queues` | Manage recurring posting queues — create, update, pause |

## Usage

Examples below use the Claude Code slash commands; in Cursor and other clients, phrase the same thing in plain language.

**Publish to multiple platforms at once:**
```
/postproxy:publish Our new feature is live — check it out at postproxy.dev
```
The agent asks which profiles to post to, then handles the publish. Platform-specific formatting (character limits, media requirements) is handled automatically.

**Schedule a post:**
```
/postproxy:publish
```
Walks you through content, platform selection, and timing — including adding to a queue or scheduling for a specific time.

**Check what's connected:**
```
/postproxy:setup
```
Shows your workspace status and all connected social accounts in a table.

**Reply to DMs and comments:**
```
/postproxy:dm
```
Read chats and send direct messages on Facebook/Messenger, Instagram, Telegram, and Bluesky — or privately reply to a commenter on Instagram and Facebook.

**Manage your Google Business Profile:**
```
/postproxy:google-business update hours
```
Edit your listing (info, hours, photos, attributes, services, menus, action links) and reply to Google reviews.

**See what needs your attention:**
```
/postproxy:summary 7d
```
A one-call snapshot of posts, engagement, and the comments, reviews, and DMs awaiting a reply.

## How it works

Postproxy is a hosted MCP server. Your client — Claude Code, Cursor, Windsurf, or anything else that speaks MCP — connects over HTTP (or over stdio via the npm package); there's nothing per-platform to install on your side.

Postproxy handles OAuth flows, token refresh, rate limits, and per-platform format differences. Your agent sends one request; Postproxy handles the rest.

> "Great tool — the best I could find! And honestly, the best support ever! Thanks, Postproxy" — Murilo Bevervanso, Founder of Vendedor Global

## Supported platforms

Instagram · Facebook · Threads · TikTok · X · YouTube · LinkedIn · Pinterest · Bluesky · Telegram · Google Business

## Links

- [Postproxy](https://postproxy.dev) — sign up, pricing, docs
- [MCP server](https://github.com/postproxy/postproxy-mcp) — source code
- [MCP Documentation](https://postproxy.dev/automation/mcp-server/) - API Reference
- [MCP Guide](https://postproxy.dev/how-to/mcp-social-media-publishing/) — full MCP integration guide
- [Automation & AI solutions](https://postproxy.dev/solutions/automation/) — n8n, Zapier, agent pipelines
