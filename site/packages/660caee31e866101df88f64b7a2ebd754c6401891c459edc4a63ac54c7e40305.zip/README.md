# Accelerate AI Toolkit

Every WordPress analytics plugin shows you numbers. None of them tell you what to change, help you change it safely, and report back on whether it worked.

This toolkit closes that loop. Ask your [Accelerate](https://www.accelerateplugin.com/) site what to fix. It diagnoses the problem, recommends a test, creates it for you, and tracks the result. One conversation, from insight to action to outcome.

> Built for marketers, not developers. No dashboards. No spreadsheets. No code.

---

## What a session looks like

You open Claude Code and ask:

> *"Which landing page needs the most work?"*

The toolkit pulls your real traffic data, finds the page with the worst bounce-to-conversion ratio, explains why it's underperforming, and proposes 2-3 testable improvements. You say "set up that A/B test" and it creates the test, applies your brand's design standards, and confirms before publishing. A week later, you ask "did it work?" and get a clear verdict with the numbers behind it.

**More things you can ask:**

- *"How is my site doing this week?"* - performance snapshot, not a wall of charts
- *"What should I do first?"* - prioritised recommendations backed by your data
- *"What's driving the traffic spike right now?"* - real-time investigation
- *"Should I personalise content for visitors from Google?"* - audience analysis with a clear yes/no
- *"Which campaign is converting best this month?"* - attribution breakdown, first-touch vs last-touch

---

## Install

```bash
claude plugin install accelerate-ai-toolkit
```

Then connect your site:

```
/accelerate-connect
```

The command walks you through generating a WordPress Application Password and saving it securely. Run `/accelerate-status` to verify the connection, then ask your first question.

<details>
<summary><strong>Requirements</strong></summary>

- WordPress 6.9+ with [Accelerate](https://www.accelerateplugin.com/) 4.1+ (Abilities feature enabled). Accelerate bundles the WordPress connector -- no separate plugin is needed.
- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) or [Codex CLI](https://github.com/openai/codex)
- Node.js 18+
- See [installation guide](./docs/installation.md) for full prerequisites and troubleshooting

**Note:** Some recent versions of the WordPress connector use a different address than the toolkit expects. If this affects your site, `/accelerate-connect` will detect it automatically and walk you through the fix.

</details>

<details>
<summary><strong>Install from source</strong></summary>

```bash
git clone https://github.com/humanmade/accelerate-ai-toolkit.git
cd accelerate-ai-toolkit
claude plugin install ./
```

For Codex CLI: run `codex`, open `/plugins`, choose "Install from local path".

</details>

---

## How it works

The toolkit is not a wrapper around your analytics API. It's 16 purpose-built skills that compose raw data into decisions:

| Workflow | What it does |
|----------|-------------|
| **Review** | Site performance snapshot: visitors, bounce rate, top pages, traffic breakdown |
| **Diagnose** | Root-cause analysis: why a page is bouncing, where traffic is mismatched |
| **Opportunities** | The front door: synthesises everything into 3 ranked next actions |
| **Optimize landing page** | Deep-dive on one page: engagement metrics, 2-3 testable improvements, A/B test hand-off |
| **Test** | Full A/B test lifecycle: plan, create, monitor, review, declare a winner |
| **Design** | Make a new on-brand version of a block or a fresh section on demand — offers to A/B test it, never forces |
| **Evolve** | Supervised multi-round optimization: generate bold versions, test, review the applied result, repeat |
| **Personalize** | Audience creation and content personalization: by referrer, geography, behaviour, device |
| **Content plan** | Proposes upcoming posts grounded in what's actually working on your site |
| **Realtime** | What's happening right now: concurrent visitors, trending content, spike investigation |
| **Campaigns** | Attribution analysis: source breakdown, UTM performance, channel comparison |
| **Learn** | Self-optimising loop: reads your A/B test results, learns what works on your site, tailors future suggestions |

A **router skill** reads your question and sends it to the right workflow automatically. For complex investigations ("why did conversions drop last month?"), a specialised **analyst agent** runs multi-step research across several data sources and reports back with findings, interpretation, and concrete next steps.

Every workflow that creates or changes something (A/B tests, personalization rules, audiences) asks for your explicit confirmation first. Nothing ships without your say-so.

---

## Supported agents

The skills are vendor-agnostic — they live in a shared `/skills/` directory and load in any agent that reads markdown skill files. **Claude Code is the path we support and actively use.** The others ship standards-correct manifests and are **in testing** — they should work, but we haven't verified every one end-to-end. If a connection doesn't come up on one of them, that's exactly the feedback we'd love: [open an issue](https://github.com/humanmade/accelerate-ai-toolkit/issues).

| Agent | Status |
|---|---|
| **Claude Code** | ✅ Supported — primary, actively used |
| Codex CLI | 🧪 In testing |
| Cursor | 🧪 In testing |
| Gemini CLI | 🧪 In testing |
| GitHub Copilot | 🧪 In testing |
| Hermes | 🧪 In testing |

Two things have to work on any agent: the **skills** must load, and the toolkit must reach your site through the **WordPress connection** (an MCP server). Skills auto-load everywhere; the connection is wired differently per agent — `/accelerate-connect` handles it, and [`docs/harness-support.md`](./docs/harness-support.md) is the full per-agent reference. See [ROADMAP.md](./internal/ROADMAP.md) for what's next.

---

## Documentation

- [Installation guide](./docs/installation.md)
- [Harness support (Codex, Cursor, Gemini, Copilot, Hermes)](./docs/harness-support.md)
- [Authentication & security](./docs/authentication.md)
- [All 42 Accelerate capabilities](./docs/ability-reference.md)
- [Adding your own skills](./docs/skill-development.md)
- [Design standards for A/B test variants](./docs/design-standards.md)
- [Gutenberg markup pre-flight](./docs/block-runner.md)

---

Built by [Human Made](https://humanmade.com/) · MIT License
