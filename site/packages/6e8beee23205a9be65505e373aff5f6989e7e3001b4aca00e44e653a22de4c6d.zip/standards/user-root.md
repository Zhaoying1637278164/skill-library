---
standard: user-root
version: 0.7.0
description: One declared user-root tree and the clauses used to score its layout
---

# User Root

## Context

Applies to personal, org, client, department, and industry user roots. This is the layout authority, not a plugin layout or a procedure that authorizes changing a populated directory. Instruction quality is governed by `standards/instruction-quality.md`; formatting and archives by `standards/conventions.md`.

## C1 Identification

The constitution's Workspace Model (`wiser/AGENTS.md`) owns root identification. Its declaration is in root `AGENTS.md`: `type:`, a Provides block, the Wiser constitution citation, Onboarding state lines, and the declared-directory table. A folder set never identifies a user root. The frontmatter also carries `root:` and `layout:`, the latter this standard's current tree version (3). Increment that integer when this standard changes the tree; a version difference is a converge input, never permission to re-onboard. `skills/Housekeeping/` owns layout migration on a declared Wiser user root and is callable any time to bring its shelves and filing declarations into conformance with this standard. A missing layout version on an already-declared Wiser root is drift, not foreign identity.

That integer is the root **contract** version: the tree above, and whatever else this standard requires of a root before it counts as current. Increment it equally when a row of the table below requires something a tree change does not cover. One integer and no minor part; a row says whether it is required or advisory, so severity lives in the row and not in the number.

The table states, per integer, what a root must carry to reach it, which primitive brings it there, and whether the row is required or advisory. A session compares the owning root's stamp with the integer above; on a mismatch it reads the rows between the two, reports what is owed, and names the primitive that owes it. It converges nothing on its own. Where every row between the two is advisory it says so, rather than calling the root behind. Where a row names more than one owner the integer advances only once every owner has certified its part, and a partial completion is reported as partial rather than as current.

| Contract | What a root must carry | Who brings it there | Required or advisory |
|---|---|---|---|
| 1 | No record. This standard declared 2 in its first commit and no commit in this repository introduces `layout: 1`. Nothing is reconstructed here | - | - |
| 2 | The C3 declared directories, their routers, and the C2 to C11 clauses as this standard now states them, less the `memory/knowledge/` router cell that row 3 owns. Those clauses are otherwise unchanged since 2026-09-10, so an installed copy carrying no git history scores this row from the text in front of it | `skills/Onboard Root/` at instantiation, `skills/Housekeeping/` afterwards | required |
| 3 | C12 Set registration and the C3 `memory/knowledge/` router cell, both of which entered this standard on 2026-09-15 without moving the integer and therefore bound no root by number; and the stamp read as this contract rather than as the tree alone | `skills/Housekeeping/` for the router cell, which is a tree change; the Sets row per C12, which Housekeeping names and hands off, is written by `skills/Knowledge Set Onboarding/` and updated by `skills/Knowledge Curation/`, and is owed only where C12 scores the root anything: a root with **neither a set nor a row** takes C12's vacuous case, owes those two nothing, and is not held short of this contract by a certification for work that does not exist. A set without a row, or a row naming no set directory, is C12's absent or misfiled and is still owed | required |

## C2 One tree

All five types use C3. Type changes speaker, prompt sheets, competitors offer, and close intensity, never the directory set. Empty roots instantiate the template; populated roots require a cited plan.

## C3 Declared directories

The root's Work Directories table projects these rows. A first-use row is present when declared and unused, even if its directory does not yet exist. A ships row requires the path and the named router at instantiation. For a populated conversion, absent shipped paths become cited plan items rather than a template overlay.

| Directory | Holds | Ships or first-use |
|-----------|-------|--------------------|
| `work/` | Projects with a written completion condition at `work/<slug>/`. Unsure defaults here. Router: `work/AGENTS.md` | ships, with router |
| `programs/` | Standing concerns without a completion condition at `programs/<slug>/`. Programs contain their projects at `programs/<slug>/<project>/`. Router: `programs/AGENTS.md` | ships, with router, no slug folders |
| `sites/` | One envelope per domain wrapping `site/` (the kit), named for the registrable host, lowercase, no scheme, no `www` unless `www` is a distinct property. Envelope internals belong to Webmaster | declared always; created on first use, never empty |
| `sources/` | Classified originals, as received. Do not edit in place. Router: `sources/AGENTS.md` | ships, with router |
| `inbox/` | Unclassified captures | ships |
| `memory/` | Bound files for about, voice, design, and competitors only when bound. Provides binds files, never this directory | ships bound stubs |
| `memory/knowledge/<set>/` | Knowledge sets, never bound by Provides. Router: `memory/knowledge/AGENTS.md` | first use; empty `memory/knowledge/` may ship |
| `shared/` | This root's own skills, playbooks, experts, templates, tools, and connectors, each in its family directory. Never under memory | first use; declared row |
| `zBuilds/` | Root-meta playbooks, `builds.md`, Housekeeping plans at `zBuilds/playbooks/housekeeping.plan.md` | first use; declared row |
| `work/onboarding/` | Onboarding records for every type. Router: `work/onboarding/AGENTS.md` | ships |
| `work/zArchive/` | Archive home for work deliverables | created at onboard; declared |

A directory not in this table is not a root home. Plays file with their work, per `standards/play.md`. Work-subject playbooks stay with that work; root-changing playbooks use C8.

## C4 Work versus programs

Work has an end. A program does not.

A slug with a written completion condition files at `work/<slug>/`, or under its program at `programs/<slug>/<project>/`. A standing concern with no completion condition files at `programs/<slug>/`. Unsure is work.

Each slug's `AGENTS.md` states that completion condition or standing concern. An unresolved work condition is recorded as awaiting its owner, not invented. Moving a slug between work and programs is a Housekeeping plan gated by System Expert. The work and programs routers project this clause.

## C5 Inbox versus sources

Inbox is the drop zone for unclassified captures. Sources is classified originals, as received, for every type. A supplied original edited in place or filed as output is misfiled.

## C6 Bound memory versus knowledge

Provides binds about, voice, design to files. Competitors is bound only after confirmation per the constitution's Workspace Model. Knowledge sets live at `memory/knowledge/<set>/`; Provides does not bind that path. Mixing knowledge-set content into bound files is a defect. This clause gives Housekeeping a finding to hand off, not a bound-memory write.

## C7 Shared overlay

This root's own primitives live under `shared/` in the six families C3 names, never under memory. They must not reuse a composed plugin primitive's name, compared case-insensitively per `standards/primitives.md` Names. Score no-shadow against the composed plugin family indexes; unknown inventory is an absent proof, not a guessed pass. Credentials never live under `shared/`. A connector here is this root's; the gateway loads extra connector directories with `--connectors` (`gateway/SETUP.md`). A tool here is this root's local operation, not a plugin tool, and does not install into the plugin.

## C8 Root meta

The silent playbook home for a run that changes the root is `zBuilds/playbooks/`, not delivery. Root-meta actions live in `zBuilds/builds.md`. A root-changing Housekeeping plan is `zBuilds/playbooks/housekeeping.plan.md` when that directory exists; a target without it uses the caller's named gate directory. An absent ordinary plan home does not change this root-meta classification; Housekeeping owns bootstrap authority and recovery accounting.

## C9 Sites first use

The Work Directories table must have a first cell exactly `sites/`, backticked. Prose elsewhere is not a declaration. Declare the row for every type; do not create an empty directory. Site Author Context and Stand-up (`skills/Site Author/SKILL.md`) consume this row. Webmaster owns envelope internals.

## C10 Records

Every type keeps run-record, verification, audit, close-report, operating-file, extraction, evidence, and draft under `work/onboarding/`. OPER is `work/onboarding/operating-file.md`. SRC_DIR is `sources`. Retire `todos/current.md` and `work/onboarding-*.md` prefixed files. This fixes record placement; type still determines which records a run produces. Inbox remains the drop zone.

## C11 Archives

Create `work/zArchive/` at onboard for work deliverables. Memory replacement uses beside-the-file `zArchive/` per `standards/conventions.md` Archives. A run snapshot is additional recovery, not a replacement for that rule.

## C12 Set registration

Every knowledge set carries a row in the Sets table of `memory/knowledge/AGENTS.md`, whatever path created it. A set is a directory at `memory/knowledge/<set>/` holding `set.yaml`; `memory/knowledge/store/` is the shared store and is never a set. The row's Set cell is the directory name.

Score absent when a set has no row, and misfiled when a row names no set directory. A root with neither a set nor a row scores present per Scoring's vacuous case; `memory/knowledge/` need not exist, and an empty one is not a finding.

The Sets table and the note beneath it are one record. Open items that `skills/Knowledge Curation/` is told to update live in that note, never in a table cell.

This clause gives Housekeeping a finding to hand off, not a knowledge write. The row's content belongs to the two skills that own it, `skills/Knowledge Set Onboarding/` which writes the row and `skills/Knowledge Curation/` which updates it; Housekeeping names the set, names which of the two receives it, and writes nothing under `memory/knowledge/`.

## C13 Classifier refusal

Optional, and absent by default. A root may declare that no session which has resolved it as owning sends anything to a classifier, the routing ask included. The declaration is one line in the root's `AGENTS.md` frontmatter, `classifier_refusal:`, and its absence is not drift: a root that has not written it has made no statement, and both an absent line and a `no` leave the classifier behaving as `wiser/AGENTS.md` `## Classifier` describes. **The line's value is the refusal, not its presence.** The template writes it `no`, so a root instantiated from the template carries the line and refuses nothing; a root refuses when the value says so. A reader that treats any present line as a refusal reads every new root as refusing, which is the error this sentence exists to stop. **And a root that refuses is refusing sending, not configuring the gateway.** The gateway may have a classifier attached for other roots in the same workspace; what this clause governs is what a session owned by this root sends, which is nothing. `skills/Housekeeping/` proposes the line where the root asks for it and never writes it unasked. **No C1 contract row scores this clause, and that is decided rather than missing.** The contract integer states what a root must carry; this clause requires a root to carry nothing, so a root satisfies it by doing nothing and there is nothing for a row to score. A row that requires nothing cannot be satisfied by doing nothing, which is a contradiction a stamp comparison surfaces as a failure. **Do not add one, and do not read the absence as an oversight.**

## Scoring

Score each clause present, absent, or misfiled and name the observed paths. Present means every applicable obligation holds, including conditional absence on first-use paths. Absent means required declaration, path, discriminator, or proof is missing. Misfiled means observed material or a declaration contradicts the clause; it outranks absent in an aggregate cell. No applicable object and no contradictory object is present (vacuous), not proof of a complete root. Empty scores missing required obligations but takes instantiate, never Housekeeping. Each converge row cites a clause, names its consumers, and separates structural repair from the identity or memory handoff.
