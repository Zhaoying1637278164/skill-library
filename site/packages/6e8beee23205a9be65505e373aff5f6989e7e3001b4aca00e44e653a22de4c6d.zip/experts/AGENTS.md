# Experts

Personas that carry a perspective and judge work through it; `standards/primitives.md` owns the type's definition, invocation rules, frontmatter, and the classifier seam every new typed file here, and any file whose seam changes, declares in its Context. The directory is flat, and the index below is grouped by category.

An expert owns a skill when its Context carries one line of this fixed form, paths only, outside any code block:

```
Owns: `skills/A/`, `skills/B/`
```

The line starts at the left margin, carries nothing but the paths, backticked and separated by a comma and a space, each naming a directory in `skills/` and none twice, and is never wrapped; a code block is a run of three or more backticks or tildes, indented by at most three spaces, closed by a run at least as long of the same character; a backtick run followed by more backticks on its line is a code span, not a fence, and a comment is not read. Each path names a directory holding a `SKILL.md`, a readable regular file in that exact spelling, resolved through a symlink where one stands in its place; a directory that holds none is an error, not a skill passed over. Only a heading at column 0 opens Context: an indented heading and a setext heading open nothing, so a declaration under one counts as outside Context. An `Owns:` line anywhere outside Context, or either keyword in a Context line that is not its declaration, is an error. A skill an expert only routes to, or draws a boundary against, is not owned by it. A skill no expert owns says so in its own Context, `Stands alone: <reason>`, one such line, at the left margin, with a reason. Every skill is one or the other once declared, and a skill carrying neither has no declared owner yet; an expert may own nothing, and its row below says so. The row for each expert lists what it owns and where its gate sits when not at the end, and that makes this index the routing table the constitution's Precedence and routing names. The skills index projects the inverse as its Owner column.

<!-- generated:index -->

### Design

| Expert | Description | Owns |
|--------|-------------|------|
| `Creative Director/EXPERT.md` | Direct visual design before it is made and judge it against its brief once it exists, enforcing intentionality and catching generic AI-design patterns, and return direction or a verdict whose findings each name what they fail and the fix that clears it | `skills/Color Palette Design/`, `skills/Component Design/`, `skills/Designer/`, `skills/Typography Design/`, `skills/Design System/`, `skills/Marketing Page Design/`, `skills/Create Presentation/`, `skills/Visualizer/`, `skills/Media Generator/`, `skills/Headshot Normalizer/`; a standalone component is gated at the caller's request; Media Generator and Headshot Normalizer take its direction before the first billed call, in the same context, and its read of the result after, in a second |

### Knowledge

| Expert | Description | Owns |
|--------|-------------|------|
| `Knowledge Expert/EXPERT.md` | Judge what a knowledge set should hold and how far to trust it, deciding whether a source belongs, what a candidate node deserves, when a set needs rebuilding rather than updating, and whether it is ready to be recalled from, and sequence the knowledge skills accordingly | `skills/Knowledge Set Onboarding/`, `skills/Knowledge Curation/`, `skills/Knowledge Recall/` |

### Marketing

| Expert | Description | Owns |
|--------|-------------|------|
| `Conversion Advisor/EXPERT.md` | Diagnose why a site's visitors are not converting and return prioritized changes, each carrying its evidence, predicted effect, and effort | None: it judges a live site's readings, not a skill's output; a leaking funnel routes here from Funnel Design |
| `Marketing Strategist/EXPERT.md` | Recommend a marketing strategy grounded in the business model and audience psychology, with channels prioritized, the funnel specified, and success metrics made measurable | `skills/Funnel Design/`, `skills/List Hygiene/` |

### Operations

| Expert | Description | Owns |
|--------|-------------|------|
| `IT Expert/EXPERT.md` | Judge a proposed DNS, zone, hosting, or credential change for its blast radius, its rollback, and its timing, and sequence Zone Publisher for a change worth seeing whole before it goes live | `skills/Zone Publisher/`; its gate runs on the plan, before anything would be written |

### Research

| Expert | Description | Owns |
|--------|-------------|------|
| `Research Expert/EXPERT.md` | Judge what a finding rests on, its sources, its coverage, and whether a figure was measured or read, sequence the research skills for a question, and gate research before it enters a memory file or a deliverable | `skills/Deep Research/`, `skills/External Research/`, `skills/Internal Research/`, `skills/Knowledge Map/`, `skills/Data Analysis/` |

### Strategy

| Expert | Description | Owns |
|--------|-------------|------|
| `Problem Solver/EXPERT.md` | Analyze a complex problem from first principles and return a recommendation with its assumptions, constraints, and failure modes named | None: it judges a problem, not a skill's output |

### System

| Expert | Description | Owns |
|--------|-------------|------|
| `Connector Advisor/EXPERT.md` | Classify how to build a proposed connector and return an approved plan with its auth route, modules, privileges, actions, and verification | `skills/Set Up Connectors/`, `skills/Connect Account/`, `skills/Connection Troubleshooter/`, `skills/Connector Author/`; Connector Author is gated on the plan, before the skill writes, with no default end-of-skill gate after; Set Up Connectors, Connect Account, and Connection Troubleshooter take no expert gate, the person attaching and pasting the project key into the instituted file is the setup gate, the person is the connect gate and a diagnosis names one next step |
| `System Expert/EXPERT.md` | Judge whether a change to a root is the right change, where a proposed capability belongs and in which family, and whether a missing capability is a gap to declare or a build to file, and sequence the system skills accordingly | `skills/Play Author/`, `skills/Playbook Author/`, `skills/Onboard Root/`, `skills/Onboard Plugin Root/`, `skills/Scope Plugin Bench/`, `skills/Housekeeping/`, `skills/Classifier Trial/`; its gate runs in the same context before the skill, on a change to a root, a new root included, never on the file the skill produces; a Play or Playbook for a user's own work takes no gate before the draft |

### Web

| Expert | Description | Owns |
|--------|-------------|------|
| `Webmaster/EXPERT.md` | Judge a site's findability, broken URLs, content vs code, and publish safety, sequence a kit envelope or foreign-site work, and gate a change before it goes live | `skills/Site Author/`, `skills/SEO Assets/`, `skills/Cloudflare Pages/`, `skills/Vercel Deploy/`; Job 3 in a second context gates Stand-up, Wrap, Upgrade, a Cloudflare Pages deploy (and a create or add-domain that is part of it), and Vercel Deploy deployment creation before publish, not after every file write; content-only edits take Job 3 for a new URL, slug change, or redirect; Check and host list/get operations, including deployment lists, have no gate; SEO Assets keeps the per-artifact second-context gate |

### Writing

| Expert | Description | Owns |
|--------|-------------|------|
| `Ghost Writer/EXPERT.md` | Judge a prose deliverable as its intended reader; the default review gate before writing ships | `skills/Content Author/`, `skills/Proposal Author/`, `skills/Speech Writing/`, `skills/Create Presentation/`, `skills/Build Concepts/`, `skills/Categorize Content/`, `skills/Transcript Summary/`, `skills/Build Voice/` |

<!-- /generated:index -->
