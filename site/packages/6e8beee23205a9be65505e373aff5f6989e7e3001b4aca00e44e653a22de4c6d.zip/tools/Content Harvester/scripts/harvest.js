#!/usr/bin/env node
/**
 * Content Harvester - turns one harvest request into a candidate bundle.
 *
 * Usage:
 *   node scripts/harvest.js help
 *   node scripts/harvest.js sample
 *   node scripts/harvest.js validate --request <path>
 *   node scripts/harvest.js run --request <path> [--output <dir>] [--dry-run]
 *
 * The rules this file follows are stated once, in
 * system/templates/Script Contract.md.
 */

// Node built-ins, this tool's own files, and tools/lib/.
import { execFileSync } from 'node:child_process';
import { accessSync, constants, existsSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { basename, dirname, isAbsolute, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

import { installAuthorised, parsedInstallFlag, writeConsent } from '../../lib/consent.js';

const HERE = fileURLToPath(import.meta.url);
const SCRIPT_DIR = dirname(HERE);
const TOOL_DIR = resolve(SCRIPT_DIR, '..');

// Installed packages' own manifests. An interrupted install leaves
// node_modules/ behind with nothing in it, so the directory proves nothing.
const DEP_MARKERS = [
  join(TOOL_DIR, 'node_modules', 'fast-xml-parser', 'package.json'),
  join(TOOL_DIR, 'node_modules', 'undici', 'package.json')
];

const COMMANDS = new Set(['run', 'validate', 'sample']);

const USAGE = `Content Harvester - turns one harvest request into a candidate bundle

Usage:
  node scripts/harvest.js help
  node scripts/harvest.js sample
  node scripts/harvest.js validate --request <path>
  node scripts/harvest.js run --request <path> [--output <dir>] [--dry-run]

Commands:
  run              Collect, rank, filter, deduplicate, and write the bundle
  validate         Check a request's structure; fetches nothing
  sample           Print a starter request to stdout
  help             Print this message

Options:
  --request <path> Harvest request JSON, absolute, outside this tool directory.
                   Required by run and validate.
  --output <dir>   Write the bundle here instead of the directory the request
                   names. Absolute, and must resolve outside this tool
                   directory.
  --dry-run        Validate and plan the run; fetch nothing, write nothing.
  --install Authorise the first install in this copy of the plugin.
          Without it, the first command that needs a package this
          copy has not installed reports what it would fetch, and
          from where, and stops. That answer covers every later
          tool in this copy. WISER_ALLOW_INSTALL=1 does the same
          for an unattended run.
  --help, -h       Print this message

Success prints one JSON object to stdout. Errors go to stderr with exit 1.`;

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

// Arguments. Parsed first so help costs nothing: no install, no request file.
const argv = process.argv.slice(2);
const command = argv[0] ?? 'help';

if (command === 'help' || argv.includes('--help') || argv.includes('-h')) {
  process.stdout.write(`${USAGE}\n`);
  process.exit(0);
}

if (!COMMANDS.has(command)) {
  fail(`Error: unknown command "${command}". Run "node scripts/harvest.js help" for usage.`);
}

const VALUE_FLAGS = new Set(['--request', '--output']);
const BARE_FLAGS = new Set([
  '--install','--dry-run', '--help', '-h']);

// The position after each value flag belongs to that flag. A path that opens
// with a dash is a value, not a flag.
const valuePositions = new Set();
for (let index = 1; index < argv.length; index += 1) {
  if (VALUE_FLAGS.has(argv[index])) valuePositions.add(index + 1);
}

// An unrecognized flag is refused rather than ignored: a silently dropped
// option returns a bundle that looks finished and is not what was asked for.
for (let index = 1; index < argv.length; index += 1) {
  const option = argv[index];
  if (valuePositions.has(index)) continue;
  if (option.startsWith('-') && !VALUE_FLAGS.has(option) && !BARE_FLAGS.has(option)) {
    fail(`Error: unknown option "${option}". Run "node scripts/harvest.js help" for usage.`);
  }
}

const install = parsedInstallFlag(argv, VALUE_FLAGS);

function flag(name) {
  const index = argv.indexOf(name);
  if (index === -1) return undefined;
  const value = argv[index + 1];
  // A SECOND OCCURRENCE IS A USAGE MISTAKE, NOT A PREFERENCE.
  //
  // First-wins silently discarded the rest. Round 12 drove two --file paths at
  // this tool and got a clean, confident, correct-looking object about ONE of
  // them, exit 0, with no signal that the other had been dropped -- which the
  // Script Contract forbids by name. Round 11 fixed this class in Browser
  // Control's switch reader; data-join, data-chart, tag-audit and video-edit
  // already refused. This is the same refusal, in the tools the fix missed.
  // Flags that are documented as repeatable are read somewhere other than here.
  if (argv.indexOf(name, index + 1) !== -1) {
    fail(`Error: ${name} was given more than once and takes one value. Run "node scripts/harvest.js help" for usage.`);
  }
  if (value === undefined || value.startsWith('--')) {
    fail(`Error: ${name} needs a value. Run "node scripts/harvest.js help" for usage.`);
  }
  return value;
}

const dryRun = argv.includes('--dry-run');

/**
 * The canonical form of a path, following symbolic links wherever the path
 * exists. Resolving a name is not opening the file it names, so this runs
 * before anything is read, installed, fetched, or written.
 *
 * `resolve` normalizes lexically and follows nothing on disk, so a symbolic
 * link, a link in any parent component, and a relative spelling are three
 * strings a lexical comparison does not match. The output directory does not
 * exist yet, so a path whose leaf is absent is canonicalized through the
 * deepest ancestor that does exist and the missing components joined back on: a
 * symbolic link standing in for any ancestor cannot hide where the bundle
 * lands.
 *
 * Absence is the only reason to keep walking. Any other refusal from the
 * filesystem, an unreadable ancestor or a loop of symbolic links, means the
 * real path cannot be known, and a screen that cannot know where a write lands
 * refuses rather than falling back to comparing the caller's spelling.
 */
function canonical(label, candidate) {
  const absolute = resolve(candidate);
  const missing = [];
  let head = absolute;

  for (;;) {
    try {
      const real = realpathSync(head);
      return missing.length === 0 ? real : join(real, ...missing);
    } catch (error) {
      if (error.code !== 'ENOENT' && error.code !== 'ENOTDIR') {
        fail(`Error: ${label} could not be resolved to a real path at ${head}. Confirm every folder on the way is readable by this account and that no symbolic link on it points at itself.`);
      }
      const parent = dirname(head);
      if (parent === head) return absolute;
      missing.unshift(basename(head));
      head = parent;
    }
  }
}

/**
 * True when `target` names this tool's own directory or something beneath it,
 * decided by identity rather than by spelling.
 *
 * `realpathSync` preserves whatever case the caller wrote, so on a
 * case-insensitive volume a variant spelling of this directory canonicalizes to
 * a string carrying none of its prefix even though it names that very
 * directory, and the name test alone let a whole bundle be written into this
 * directory. Device and inode are a directory's own identity, which no spelling
 * reaches, so every existing ancestor of `target` is compared that way as well.
 * A directory that does not exist yet has no inode of its own, which is why the
 * walk climbs to the deepest ancestor that does: that ancestor is where the
 * write lands.
 */
function insideToolDirectory(target) {
  const root = canonical('this tool directory', TOOL_DIR);
  if (target === root || target.startsWith(root + sep)) return true;

  let rootId;
  try {
    rootId = statSync(root);
  } catch {
    return false;
  }

  let head = target;
  for (;;) {
    try {
      const id = statSync(head);
      if (id.dev === rootId.dev && id.ino === rootId.ino) return true;
    } catch {
      // Absent, so it carries no identity of its own; its parent still decides.
    }
    const parent = dirname(head);
    if (parent === head) return false;
    head = parent;
  }
}

// A path the caller named on the command line, resolved once and returned, so
// that what is opened or written below is the path this cleared rather than the
// spelling the caller used.
function callerPath(name, value) {
  if (!isAbsolute(value)) {
    fail(`Error: ${name} must be absolute; got "${value}". A relative path resolves against whichever directory the caller happened to be in.`);
  }
  const target = canonical(name, value);
  if (insideToolDirectory(target)) {
    fail(`Error: ${name} resolves inside this tool directory (${canonical('this tool directory', TOOL_DIR)}). Scripts read and write only in a work directory in the owning root; pass that path instead.`);
  }
  return target;
}

// request.js imports Node built-ins and nothing else, so it loads above the
// dependency check. That ordering is the point: every path screen below has to
// run before the first-run install, or a caller who names this tool's own
// directory pays for an install and only then gets refused. It is dynamic for
// symmetry with the imports below, which cannot be static.
const { loadRequest, sampleRequest, validateRequest } = await import('./lib/request.js');

const FEED_TYPES = new Set(['rss', 'substack_rss', 'reddit_rss']);
const DEFAULT_USER_AGENT = 'Content Harvester/0.1.0';
const DEFAULT_TIMEOUT_MS = 15000;

if (command === 'sample') {
  process.stdout.write(`${JSON.stringify(sampleRequest(), null, 2)}\n`);
  process.exit(0);
}

const requestPathArg = flag('--request');

if (!requestPathArg) {
  fail(`Error: --request is required for ${command}. Run "node scripts/harvest.js help" for usage.`);
}

// Screened before the file is opened, and loadRequest is handed the screened
// path rather than the caller's spelling.
const { request, requestPath } = loadRequest(callerPath('--request', requestPathArg), fail);
const problems = validateRequest(request);

if (problems.length > 0) {
  fail(`Error: ${requestPath} is not a valid harvest request:\n- ${problems.join('\n- ')}`);
}

if (command === 'validate') {
  process.stdout.write(`${JSON.stringify({ ok: true, name: request.name, sources: activeSources(request).length })}\n`);
  process.exit(0);
}

// run.
const startedAt = new Date();
const runId = startedAt.toISOString().replace(/[:.]/g, '-');
// Canonicalized, and this value is what writeArtifacts is handed below, so the
// directory that gets created is the one this screen cleared. Comparing
// resolved strings alone refused only the direct spelling, which left a case
// variant and a symlinked ancestor writing the bundle into the very directory
// the refusal names.
const outputDirectory = canonical('the output directory', join(resolveOutputBase(), runId));

if (insideToolDirectory(outputDirectory)) {
  fail(`Error: the output directory resolves inside this tool directory (${canonical('this tool directory', TOOL_DIR)}). Scripts write only to a work directory in the owning root; pass that path as --output, or set output.directory in the request to a path outside this directory.`);
}

// A dry run fetches nothing and writes nothing, so it answers here, above the
// install, on a copy that has never had one.
if (dryRun) {
  process.stdout.write(`${JSON.stringify({
    ok: true,
    dry_run: true,
    request: request.name,
    sources_requested: activeSources(request).length,
    output_directory: outputDirectory
  })}\n`);
  process.exit(0);
}

// Whether this process can create files in a directory. Used only to tell an
// unwritable install location apart from a failed install, per Output and errors.
function isWritable(dir) {
  try { accessSync(dir, constants.W_OK); return true; } catch { return false; }
}

// Consent before an install, per the Script Contract's Dependencies clause.
//
// A tool used to install its packages on its own account the first time it was
// called, then tell the caller to run the command again. That is two problems:
// several hundred megabytes could arrive on a machine without anyone agreeing
// to it, and the work then took two runs to do once.
//
// A script cannot ask. Nothing here reads stdin, deliberately, so a run with
// nobody watching fails rather than waiting forever for an answer. So the
// script reports and stops, and whoever is driving it does the asking: the
// report names the packages, the hosts they come from, and the size where it is
// large enough to matter, which is what a person needs in order to answer.
// `--install` on the same command authorises it and the run then COMPLETES
// rather than demanding a re-run. WISER_ALLOW_INSTALL=1 authorises it for an
// unattended run, so automation does not acquire a new way to fail.
// Whether THIS RUN will ask for a browser, which is what the consent report has
// to describe. A tool that CAN drive a browser is not the same as a run that
// WILL: `deck-export scaffold` and `web-screenshot check` are both commands of
// browser tools that fetch none.
const WILL_FETCH_BROWSER = false;

function installPlan() {
  let names = [];
  try {
    names = Object.keys(JSON.parse(readFileSync(join(TOOL_DIR, 'package.json'), 'utf8')).dependencies || {});
  } catch { /* the report degrades to a generic list; the refusal still stands */ }
  const browser = names.includes('playwright');
  // A browser tool's authorised run makes TWO fetches, to two different places,
  // and this report used to fold them into one clause that was wrong about both
  // halves: `from registry.npmjs.org and cdn.playwright.dev into <TOOL_DIR>`
  // read as though the Chromium build landed in this directory, which it does
  // not, and it omitted the Microsoft fallback host that the browser message a
  // few lines down gets right. An egress allowlist built from that sentence is
  // short by a host and a disk-space estimate built from it looks in the wrong
  // place. So `hosts` is now only what NPM contacts -- which is the whole truth
  // for the clause it sits in -- and the browser fetch is a sentence of its own
  // with its own hosts and its own destination.
  return {
    list: names.length ? names.join(', ') : 'the packages package.json declares',
    hosts: 'registry.npmjs.org',
    // KEYED ON THIS RUN, not on the tool. Round 8 found this promising a browser
    // download on `deck-export scaffold --install`, which makes none; round 9
    // found the hedge that replaced it naming "a survey" as an example of a
    // command that fetches no browser, which `check --install` had just
    // falsified in the same commit. `WILL_FETCH_BROWSER` is set by each entry
    // script from the command it is actually running, so the report describes
    // this run rather than the tool's general capabilities.
    size: browser && WILL_FETCH_BROWSER
      ? ' This run then fetches the Chromium build, several hundred megabytes, from cdn.playwright.dev, or from playwright.download.prss.microsoft.com when Playwright falls back. That build does NOT land here: it goes wherever Playwright keeps browser builds on this machine, which tools/AGENTS.md names for each platform.'
      : ''
  };
}

// `what` is 'packages' or 'browser'. Round 6 found the browser case reported the
// package case: a tool whose packages are installed and whose browser build is
// not is a real state -- every machine that ran a browser tool before the
// installer existed is in it -- and the report a person answers must not open
// "this tool is not installed yet", nor name a registry fetch and an npm cache
// write that this install will not make.
function requireInstallConsent(what) {
  if (installAuthorised(HERE, install)) {
    writeConsent(HERE, 'Content Harvester', install);
    return;
  }
  if (what === 'browser') {
    fail(
      `Error: this tool's packages are installed but the Chromium build they drive is not, and this copy of the plugin has not authorised an install. The plugin asks once, on the first install in this copy. Installing fetches that build from cdn.playwright.dev, or playwright.download.prss.microsoft.com when Playwright falls back, several hundred megabytes, into wherever Playwright keeps browser builds on this machine. No package is fetched and npm is not run. tools/AGENTS.md lists every write an install makes and names where the build lands. Re-run the same command with --install to authorise it, or set WISER_ALLOW_INSTALL=1 for an unattended run. Nothing is read from stdin, so this is the only way to answer.`
    );
  }
  const { list, hosts, size } = installPlan();
  fail(
    `Error: this tool is not installed yet and this copy of the plugin has not authorised an install. The plugin asks once, on the first install in this copy. Installing fetches ${list} from ${hosts} into ${TOOL_DIR}, and npm writes its own cache outside this plugin.${size} tools/AGENTS.md lists every write an install makes. Re-run the same command with --install to authorise it, or set WISER_ALLOW_INSTALL=1 for an unattended run. Nothing is read from stdin, so this is the only way to answer.`
  );
}

// Dependencies. Runs after every path screen above, so a run this tool must
// refuse is refused without an install, and before every package import below.

if (DEP_MARKERS.some((marker) => !existsSync(marker))) {
  requireInstallConsent('packages');
  process.stderr.write('First run: installing dependencies in this tool directory.\n');
  try {
    const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    // stderr only: npm output on stdout would break the empty-stdout-on-failure rule.
    execFileSync(npm, ['ci'], { cwd: TOOL_DIR, stdio: ['ignore', 'ignore', 'inherit'] });
  } catch {
    // Two different failures arrive here and they have different fixes, so the
    // Script Contract's Output and errors clause requires telling them apart:
    // an unwritable tool directory is not a broken install, and telling someone
    // to run "npm ci" by hand where they cannot write cannot succeed.
    if (!isWritable(TOOL_DIR)) {
      fail(`Error: cannot install dependencies because ${TOOL_DIR} is not writable. This tool installs its dependencies into its own directory on the run that authorises it with --install, so that directory has to be writable. Install this plugin somewhere you own, or make that directory writable, then run the command again.`);
    }
    fail(`Error: npm ci failed in ${TOOL_DIR}. Confirm Node 18 or newer, then that package-lock.json is present and matches package.json, which is what npm ci requires and will not resolve around. Delete node_modules there and run "npm ci" by hand to see npm's own message. A lockfile that is missing or out of step with the manifest is a defect in this copy of the plugin, not something a re-run fixes.`);
  }
  const stillMissing = DEP_MARKERS.find((marker) => !existsSync(marker));
  if (stillMissing) {
    fail(`Error: npm ci finished but ${stillMissing} is still missing. Check that package.json lists every package this script imports.`);
  }
}

// Proxy-mediated sandboxes set HTTPS_PROXY; Node fetch does not honor it alone.
{
  const server =
    process.env.HTTPS_PROXY ||
    process.env.https_proxy ||
    process.env.HTTP_PROXY ||
    process.env.http_proxy ||
    '';
  if (typeof server === 'string' && server.trim() !== '') {
    const undici = await import('undici');
    if (typeof undici.setGlobalDispatcher === 'function' && undici.ProxyAgent) {
      undici.setGlobalDispatcher(new undici.ProxyAgent(server.trim()));
    }
  }
}

// The packages import only below this line, and only dynamically. A static
// import would reach fast-xml-parser before the check above and crash instead
// of installing.
const { collectFeed } = await import('./adapters/rss.js');
const { collectManualUrls, collectUrl } = await import('./adapters/urls.js');
const { clusterCandidates, dedupeCandidates } = await import('./lib/dedupe.js');
const { filterCandidates } = await import('./lib/filter.js');
const { rankCandidates } = await import('./lib/rank.js');
const { writeArtifacts } = await import('./lib/render.js');

const context = {
  requestTopics: request.topics || [],
  discoveredAt: startedAt.toISOString(),
  userAgent: request.user_agent || DEFAULT_USER_AGENT,
  timeoutMs: Number(request.timeout_ms || DEFAULT_TIMEOUT_MS)
};

const collected = await collectSources(request, context);
const ranked = rankCandidates(collected.candidates, request);
const filtered = filterCandidates(ranked, request);
const clusters = clusterCandidates(filtered.accepted);
const deduped = dedupeCandidates(filtered.accepted);
const finishedAt = new Date();

const bundle = {
  schema_version: 1,
  run: {
    id: runId,
    name: request.name,
    consumer: request.consumer,
    timebox: request.timebox,
    topics: request.topics || []
  },
  candidates: deduped.accepted,
  clusters,
  rejected: [...collected.rejected, ...filtered.rejected, ...deduped.rejected],
  errors: collected.errors
};

const status = {
  ok: true,
  reason: 'completed',
  started_at: startedAt.toISOString(),
  finished_at: finishedAt.toISOString(),
  sources_requested: activeSources(request).length,
  sources_completed: collected.sourcesCompleted,
  sources_failed: collected.sourcesFailed,
  candidate_count: bundle.candidates.length,
  rejected_count: bundle.rejected.length,
  error_count: bundle.errors.length,
  output_directory: outputDirectory
};

let writtenDir;

try {
  writtenDir = writeArtifacts(bundle, status, outputDirectory, request.output || {});
} catch (error) {
  fail(`Error: could not write the bundle to ${outputDirectory}: ${error.code || 'write failed'}. Pass a writable work directory as --output.`);
}

process.stdout.write(`${JSON.stringify({
  ok: true,
  candidate_count: bundle.candidates.length,
  rejected_count: bundle.rejected.length,
  error_count: bundle.errors.length,
  output_directory: writtenDir
})}\n`);

async function collectSources(harvestRequest, runContext) {
  const candidates = [];
  const rejected = [];
  const errors = [];
  let sourcesCompleted = 0;
  let sourcesFailed = 0;

  for (const source of activeSources(harvestRequest)) {
    try {
      if (FEED_TYPES.has(source.type)) {
        candidates.push(...await collectFeed(source, runContext));
      } else if (source.type === 'url') {
        candidates.push(...await collectUrl(source, runContext));
      } else if (source.type === 'manual_urls') {
        const result = await collectManualUrls(source, runContext);
        candidates.push(...result.candidates);
        errors.push(...result.errors);
      } else {
        rejected.push({
          reason: 'unsupported_adapter_type',
          source: sourceLabel(source),
          adapter_type: source.type
        });
      }
      sourcesCompleted++;
    } catch (error) {
      sourcesFailed++;
      errors.push({
        source: sourceLabel(source),
        adapter_type: source.type,
        message: error.message,
        retryable: Boolean(error.retryable),
        ...(error.reason ? { reason: error.reason } : {})
      });
    }
  }

  return { candidates, rejected, errors, sourcesCompleted, sourcesFailed };
}

function activeSources(harvestRequest) {
  return (harvestRequest.sources || []).filter((source) => source.enabled !== false);
}

function sourceLabel(source) {
  return source.source || source.name || 'Unnamed source';
}

function resolveOutputBase() {
  // A flag the caller typed, so it is held to the same absoluteness the help
  // text states and screened before it is joined with anything.
  const override = flag('--output');
  if (override) return callerPath('--output', override);

  // output.directory is a field in the caller's own request file and is
  // documented as relative to it, so it resolves against the request's
  // canonical directory rather than against the current one. The joined result
  // is screened by the caller of this function.
  const declared = request.output?.directory;
  if (!declared) return join(dirname(requestPath), 'generated_output', request.name);

  return resolve(dirname(requestPath), declared);
}
