# Third-party notice: Content Harvester

This tool installs the 9 packages below on the machine that calls it, into this tool's own directory on the first run that authorizes it with `--install`. **This repository redistributes none of them.**

Versions and licenses are read from this tool's `package-lock.json`, on 2026-09-02.

| Package | Version | License | |
|---------|---------|---------|--|
| `@nodable/entities` | 3.0.0 | MIT | required |
| `anynum` | 1.0.1 | MIT | required |
| `fast-xml-builder` | 1.3.0 | MIT | required |
| `fast-xml-parser` | 5.10.1 | MIT | required |
| `is-unsafe` | 2.0.0 | MIT | required |
| `path-expression-matcher` | 1.6.2 | MIT | required |
| `strnum` | 2.4.1 | MIT | required |
| `undici` | 6.28.0 | MIT | required |
| `xml-naming` | 0.3.0 | MIT | required |
