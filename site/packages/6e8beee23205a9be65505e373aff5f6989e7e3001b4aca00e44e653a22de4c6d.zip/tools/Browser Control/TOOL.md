---
name: Browser Control
type: tool
category: automation
description: Drives a persistent Chromium session to read, navigate, and act on pages that need a real browser, answering every command with the page state that followed
version: 0.7.2
---

# Browser Control

A run of one command acts on a browser that is already open and returns what the page became.

## Context

Use when the work needs a real browser: a form to fill, a workflow behind a sign-in, content a page builds in JavaScript, a layout to look at, or any sequence of act-then-check steps against a live site.

Do not use when a plain fetch of a static page would answer, when the question is answerable without a page at all, or when a connector already covers the platform and declares the action this job needs; a connector is faster, survives redesigns, and does not need a window. Reaching a platform through its own site instead of its connector, including where that connector declares no such action, is a last resort, not a shortcut.

This tool holds a session and drives it. Deciding what to do with a page belongs to the skill or expert that called it.

Classifier seam: none.

## Quick Start

```bash
node scripts/browser.js help
```

Usage text, with nothing installed and nothing configured.

```bash
node scripts/browser.js session start --profile [absolute dir]
node scripts/browser.js navigate --url [address]
node scripts/browser.js snapshot --format interactive
node scripts/browser.js session stop
```

If this copy of the plugin has not yet authorized an install, `session start` reports what it would install and stops; `--install` on that run is the answer, and later tools in this copy install without asking. Every command prints one JSON object:

```
{"url":"[address]","title":"[page title]"}
```

Anything else, see Troubleshooting.

## Driving a Session

A page is not a function call. It redraws, it redirects, it shows a consent banner over the thing you meant to click, and it answers a click with a different page than the one you predicted. Every command here therefore returns the page state after the action, so that checking costs one read instead of one round trip.

- **Snapshot before acting.** Read the page before the first action and after anything that could change it. `--format interactive` numbers what can be clicked or typed into; act by index rather than by a selector guessed from a screenshot.
- **One action, then one check.** Never chain actions on the strength of what the page looked like two steps ago. A stale index is the single most common failure, and a fresh snapshot costs less than an action aimed at the wrong element.
- **Verify against the page, not the exit code.** `check` exits 0 whenever the assertion ran; whether it held is the `passed` field. A caller that reads only the exit code will report a failed assertion as a pass.
- **Never repeat an action that just failed.** Snapshot, work out what the page actually shows, and try a different route. After two failed routes, one more only when the snapshot shows an untried route; three failed routes, or no untried route, is the stop, and there is no fourth.
- **Hand a human what only a human can do.** A sign-in, a CAPTCHA, a second factor, or an operating-system dialog cannot be driven from here. Say what is blocking and let the person act in the window; a signed-in session stays in the profile directory afterwards.
- **Report what the page did.** Close with what was found, where, and what was changed on the site. An automation whose effects nobody can name is not finished.

**Who picks the element.** The caller does, from the interactive snapshot: read `snapshot --format interactive`, choose the index, and act by it. `select option` is not this pick: it needs a selector, and the snapshot lines do not carry one. Nothing here puts the pick to a classifier.

The pattern that reads a site-specific playbook before improvising travels with the root that owns the site, not with this tool; a shared root ships no account's navigation notes.

## Dependencies

| Dependency | Needed for | Present when |
|------------|------------|--------------|
| The Chromium build Playwright drives | `session start` | `npm run check:chromium` exits 0 with `"chromiumLaunch":true` |

Playwright and its Chromium build install once, into `tools/lib/browser-runtime/` and Playwright's cache (`tools/AGENTS.md`). Presence is a **trial launch** via the shared browser runtime at `tools/lib/browser-runtime/`, not a path on disk. A missing OS library is shimmed where a compiler is present, or named with one next step (`tools/AGENTS.md`). The runtime also forwards `HTTPS_PROXY` / `HTTP_PROXY` into Chromium. Install steps are never written here. `tools/AGENTS.md` lists every write.

## Session State

This tool reads no credentials and takes no `--env`. What it keeps instead is a browser profile: cookies, storage, and sign-ins, in the directory passed as `--profile [absolute dir]` when a session starts.

Resolve that directory in the owning root, per `standards/conventions.md`. This tool never picks a location and never falls back to one, because a machine-wide default would silently pool one person's sign-ins across every root they work in.

- The directory holds live session material. It belongs where the owning root keeps its own state, and it is never shared between roots.
- `--unattended` additionally denies geolocation, microphone, and camera by default, so a permission prompt cannot stall a run nobody is watching. Attended runs leave them at the site default.
- Native browser prompts (save-password bubbles, autofill, translate bars, restore-session nags) are suppressed in the profile before launch, because nothing on the page can dismiss them. JavaScript dialogs are a different surface and are handled at runtime by `dialog`.

## Usage

One entry script, one command per line, subcommands where a command has modes.

| Command | Purpose |
|---------|---------|
| `session start\|stop\|status\|restart` | Manage the browser host; `start` and `restart` need `--profile` |
| `navigate` | Go to `--url`, or `back`, `forward`, `reload`; `--wait` sets what counts as arrived |
| `snapshot` | Read the page: `--format accessibility\|text\|html\|interactive` |
| `click` | Click by `--index`, `--selector`, `--text`, or `--coords`; `--button`, `--count`, `--delay`, `--force` |
| `type` | Enter `--text` into a target, or press `--key`. **Read the per-command options below before using it**: the default replaces the field |
| `wait` | Block on `--selector`, `--text`, `--time`, or `--network` |
| `scroll` | `--to top\|bottom\|[selector]`, `--by [px]`, or `--infinite` |
| `mouse hover\|move\|drag\|wheel` | Pointer actions a click cannot express |
| `select list\|option` | Read or set a dropdown |
| `frame list\|switch\|main\|current` | Move in and out of an iframe |
| `tabs list\|new\|switch\|close` | Manage tabs |
| `dialog accept\|dismiss\|prompt\|off\|status` | Standing answer for JavaScript dialogs |
| `check` | Assert element state; the verdict is `passed` |
| `console start\|stop` | Capture page console output |
| `network start\|stop\|block\|unblock` | Capture requests, or abort ones matching `--pattern` |
| `emulate set\|reset` | Viewport, device viewport, or geolocation |
| `execute` | Run `--code` in the page and return its value |
| `screenshot` | Write a PNG to `--output` |
| `download` | Save `--url` to `--output`, or click `--selector` into `--output-dir` |
| `upload` | Attach `--file` to `--selector`; needs `--confirm` |
| `cookies list\|get\|set\|delete\|clear` | Cookie metadata and page-state cookies; `--domain`, `--path`, `--expires` |
| `storage list\|get\|set\|delete\|clear` | Local or session storage; `--session` picks session |
| `trace start\|stop\|status` | Record a replayable trace for debugging a failed run |

A trace is a zip that Playwright's own trace viewer opens; it replays the run with a screenshot, the page state, and the network activity at every step, which is what makes a run that failed once diagnosable afterwards.

Per-command options. Each belongs to the one command named and is refused elsewhere:

| Command | Option | Effect | Default |
|---------|--------|--------|---------|
| `navigate` | `--wait` | What counts as arrived: `load`, `domcontentloaded`, `networkidle`, `commit` | `load` |
| `click` | `--button` | Which mouse button | `left` |
| `click` | `--count` | How many clicks; 2 is a double click | 1 |
| `click` | `--delay` | Milliseconds held between press and release | None |
| `click` | `--force` | Skip the actionability wait and click anyway. Not reached by `--coords` | Off |
| `type` | `--delay` | Changes what the command does, not just its speed. See the note below | None, which replaces |
| `type` | `--clear` | Empty the field before writing | Off |
| `type` | `--submit` | Press Enter after the text is written | Off |
| `cookies set` | `--domain` | The cookie's domain | The current page's hostname |
| `cookies set` | `--path` | The cookie's path | `/` |
| `cookies set` | `--expires` | A number of days from now. Not seconds, not a Unix timestamp: `--expires 7` is one week | None, which makes a session cookie |
| `cookies list` | `--domain` | Keep only cookies whose domain contains this string | None, which returns all |
| `storage` | `--session` | Use `sessionStorage` instead of `localStorage`, on every subcommand | Off, which is `localStorage` |
| `check` | `--assert` | Which assertion to run: `exists`, `count`, `visible`, `hidden`, `enabled`, `disabled`, `checked`, `unchecked`, `text`, `value` | None; required |
| `wait` | `--hidden` | Wait for `--selector` to disappear rather than appear | Off, which waits for it to appear |
| `screenshot` | `--fullpage` | Capture the whole scrollable page, not just the viewport | Off, which captures the viewport |
| `select option` | `--value`, `--label` | Choose the option by its value attribute or by its visible text; `--index` picks by position | None; one of the three is required |
| `frame switch` | `--src`, `--name` | Choose the iframe by a substring of its `src` or by its `name`; `--index` picks by position | None; one of the three is required |
| `mouse drag` | `--from` | The selector the drag starts at; `--to` is where it ends | None; both required |
| `emulate set` | `--device`, `--viewport`, `--geolocation` | Emulate a named device, a `WxH` viewport, or a `lat,long` position | None; one of the three is required |

`type` replaces by default, and this is the one thing to get right.

- `type --text` with no `--delay` calls `fill`, which discards whatever the field already held and writes the new text.
- `type --text --delay [ms]` types at the **caret**, character by character, firing the key handlers a live typeahead or autocomplete listens for. On a field nothing has focused yet the caret sits at the start, so the text lands **in front of** the existing contents rather than after them.
- `type --text --delay 0` also types at the caret, with no pause between keystrokes. Zero is a real delay, not an absent one.
- To replace deliberately while still firing key handlers, pass `--clear` with `--delay`.
- `--key` presses one key and applies no typing option. It refuses `--text`, `--selector`, `--index`, `--clear`, `--delay` and `--submit` by name rather than accepting and ignoring them. `--timeout` and the other cross-cutting options still apply.

Three commands name a thing and they do not agree. This is a known inconsistency, kept rather than repaired because renaming either spelling would break callers of a published tool for a gain that is only tidiness. It is written down here so a reader can predict it instead of discovering it:

| Command | Flag | What it names |
|---------|------|---------------|
| `storage get\|set\|delete` | `--key` | The identifier of a stored item |
| `cookies get\|set\|delete` | `--name` | The identifier of a cookie |
| `type` | `--key` | A keyboard key to press, such as `Enter` or `Tab`. Not an identifier at all |

Passing the wrong one is refused by name, so the cost is a retry rather than a wrong result.

Numeric options are parsed whole. A value the parser cannot read completely is refused rather than truncated, so `--expires 7days` fails instead of quietly meaning 7, and a value outside a flag's range is refused by name.

| Range | Flags |
|-------|-------|
| 1 to 65535 | `--port` |
| 1 or greater | `--count`, `--max`, `--expires` (days) |
| 0 or greater | `--delay`, `--timeout`, `--index`, `--time`, `--expect` on the `count` assertion |
| Any whole number, negative included | `--by` and `--delta`, where a negative scrolls upward |

Cross-cutting options, which apply to every command that takes one:

| Option | Effect | Default |
|--------|--------|---------|
| `--profile [dir]` | Where session state lives, absolute, resolved in the owning root | None; required by `session start` and `session restart` |
| `--port [n]` | Host port | 4390 |
| `--headless` | No visible window | Off |
| `--unattended` | Deny geolocation, microphone, and camera by default | Off |
| `--confirm` | Opt in to a destructive command | Off; nothing runs without it |
| `--output [file]`, `--output-dir [dir]` | Where an artifact is written, absolute, outside this tool | None |
| `--file [path]` | A file `upload` attaches to a form, absolute, outside this tool | None; required by `upload` |
| `--timeout [ms]` | Per-action budget where the command takes one | 5000 to 30000 by command |
| `--help`, `-h` | Print usage and exit | Off |

## Destructive Actions

| Command | Effect | Undoable? |
|---------|--------|-----------|
| `cookies delete` / `cookies clear` | Removes one cookie or all cookies in the profile for matching sites | No; re-auth or re-accept is the only path back |
| `storage delete` / `storage clear` | Removes one key or all keys from local or session storage on the current origin | No for that origin's stored state |
| `upload` | Attaches a local file to a form control and may trigger a real server-side write when the form submits | Depends on the site; treat as a real upload |

Each of these requires `--confirm`. The gate is checked before anything is read, sent, or opened. An agent never supplies `--confirm` on its own initiative.

## What This Tool Will Not Do

- **No cookie command exports a value.** `cookies list` and `cookies get` return name, domain, path, expiry, flags, and the value's length; the value itself is a live credential and neither prints it. There is no export. **Two other paths do carry values out, and the heading above used to deny it.** `execute` runs whatever code it is handed, so `--code "document.cookie"` returns whatever that page's script could read anyway (never an HttpOnly cookie, which is most session cookies); that is the price of an ungated evaluator and it is stated at the `execute` paragraph below. And a trace zip records raw `Cookie` and `Set-Cookie` headers, HttpOnly included. Chromium's own profile store under `--profile` is where cookie values live, and `cookies set` and `cookies delete` change what is in it. `storage get` does return a named key's value, because stored page state is ordinary data and the caller has named exactly what it wants; `storage list` still returns keys alone rather than dumping everything a page has saved.
- **Sign-ins are not injected.** `cookies set` is for page state such as a consent or locale cookie. Authenticate by having the person sign in in the visible window; the profile keeps it.
- **Nothing is overwritten.** A screenshot, download, or trace whose target path already exists is refused, not replaced.
- **Locale, timezone, and touch emulation are not offered.** They are fixed when the context is created and cannot be changed on a live session; a command that appeared to set them would be reporting a change that never happened.

`execute` runs whatever code it is handed, in a page carrying the profile's sign-ins. It is the widest surface here and it is not gated, because its effect is entirely the caller's own code and a gate that fires on every call teaches the caller to ignore it. Blast radius is the caller's to name before running it. That includes credential material: `--code "document.cookie"` returns what any script on that page could read, which is every non-HttpOnly cookie. It cannot reach an HttpOnly cookie, and most session cookies are HttpOnly.

## Script Contract

Every script in this tool follows `system/templates/Script Contract.md`; what a user meets when running it is `tools/RUNNING.md`. The sections here state what the commands do; the contract states how every script behaves getting there.

Two scripts ship. `scripts/browser.js` is the only one a caller runs. `scripts/server.js` is the session host it starts, which holds the browser open so that separate invocations act on the same page; it takes no instruction from anywhere but loopback and is not run by hand.

## Output

Success is one JSON object on stdout and exit 0. Most commands return the page's `url` and `title` after the action, plus whatever they were asked for: `content` for a snapshot, `passed` for a check, `result` for executed code, a written path for an artifact.

`check` is the one to read carefully. It exits 0 when the assertion ran and reports the verdict in `passed`; an assertion that did not hold is a finding to report, never something to work around by loosening the assertion.

Failure prints to stderr, leaves stdout empty, and exits 1. Files are written where a command's `--output` or `--output-dir` names, and an authorized install also writes what `tools/AGENTS.md` lists.

## Troubleshooting

The stops every tool shares, an unknown flag, the install consent, an install that fails, and a path that is relative or inside this tool, are in `tools/RUNNING.md`; the rows below are this tool's own.

| Message | Cause | Fix |
|---------|-------|-----|
| `Chromium cannot launch` / `chromiumLaunch:false` | Binary missing, launch blocked, or OS library gap | Follow the `remediation` line from `npm run check:chromium` |
| `no browser host answering on port [n]` | No session, or it was started on another port | `session status`, then `session start --profile [dir]` |
| `a browser host is already running on port [n]` | A session from earlier work | `session stop`, or pass a different `--port` |
| `session [start\|restart] needs --profile` | No location was resolved | Resolve a work directory in the owning root; do not guess one. `restart` resolves it before it stops anything, so a refusal leaves the running session standing |
| `already exists and this tool never overwrites a file` | The artifact path is taken | Name a path that does not exist yet |
| `needs --confirm` | A destructive command was run without opting in | Re-run with `--confirm` once the effect is intended |
| `element index [n] is not in the current list` | The page changed since the last interactive snapshot | Snapshot again and use the new index |
| `no element matched this selector` | The element is absent, or is inside an iframe | `snapshot --format interactive`, and `frame list` if the content sits in an iframe |
| `the browser host did not come up` | The browser could not launch or the host process died | Confirm `npm run check:chromium` (read `remediation` if launch fails), then retry with `--headless` to rule out a blocked window |

## Success

- `help` prints usage to stdout and exits 0 on a copy with no `node_modules/` and no session.
- `session start --profile [dir]` exits 0, and `session status` then reports that host and profile.
- `session restart` resolves `--profile` before it stops anything: one that names none, or names a relative path or a file, exits 1 with the running session still answering `session status`. When the selected profile is not the live one, Chromium opens it in a throwaway headless launch before the stop, so a profile Chromium rejects (a `Default` entry that is a file, another browser's lock) exits 1 naming the profile and the reason, with the running session still answering; when the selected profile is the live one that opening is impossible, the stop is unavoidable, and a replacement that then fails says so and prints the last lines of the host's own error log, kept at `host-stderr.log` inside the profile.
- A page command with no session running exits 1 naming the port and the start command, stdout empty.
- Every destructive command run without `--confirm` exits 1 naming the missing confirmation, before it reads a file or contacts the host.
- No *cookie command* prints a value, but `execute` returns whatever its code reads, and `execute --code "document.cookie"` returns cookie values to stdout. **Three paths this tool writes hold credential material, and a verifier should treat all three as such rather than checking around them**: the `--profile` directory, which is a live Chromium profile and exists to keep sign-ins; a trace zip from `trace stop --output`, which records request and response headers including `Cookie` and `Set-Cookie`; and the session token at `~/.wiser/browser-control/<port>.token`, which is what authorizes a caller to drive a signed-in browser. All three have rows in `tools/AGENTS.md`. **All three are now written for their owner only** -- the profile directory `0700`, the trace file and the token `0600` -- because a gate round found a trace holding an `HttpOnly` session cookie in plaintext in a world-readable file, and the profile directory open to every other account on the machine, while only the token had ever been given a mode. The trace is the one worth saying twice, because a trace's whole purpose is to be handed to someone else. **This list is the scope of the claim, not a license to skip the rest**: a path added later is credential-bearing until someone checks it.
- A caller-named path that is relative, inside this tool directory, or already taken is refused rather than written.
- Acting on an element found by an interactive snapshot changes the page, and the next snapshot shows it.
