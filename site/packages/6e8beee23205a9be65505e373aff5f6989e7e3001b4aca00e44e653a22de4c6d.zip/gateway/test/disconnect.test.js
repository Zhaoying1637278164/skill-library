import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { confirmCall, createTestGateway, putActive } from './fake-provider.js';

/**
 * The teardown tool.
 *
 * **Its unit is the credential, not the module.** `hydrateFromProvider` writes one
 * provider account into every module of its toolkit that has no grant of its own,
 * measured at five modules on one account, so a teardown scoped to the named module
 * would revoke a credential the others were running on and leave their rows ACTIVE
 * against an account that no longer exists — the stale-row defect this build removes,
 * recreated by the tool built to remove it.
 */

const KIT = 'fake-acct-shared';

/** Two modules of one service on ONE provider account, which is what hydration makes. */
async function shared(options = {}) {
  const made = await createTestGateway(options);
  made.fake.auth.setStatus(KIT, 'ACTIVE');
  for (const module of ['repos', 'issues']) {
    made.store.putConnection({
      id: `conn-${module}`,
      service: 'github',
      module,
      privilege: 'write',
      provider: 'catalog',
      provider_account_id: KIT,
      scopes: [],
      status: 'ACTIVE',
      created: new Date().toISOString(),
      updated: new Date().toISOString(),
    });
  }
  return made;
}

const rows = (store) => store.listConnections().map((r) => `${r.service}/${r.module}`).sort();

/** A confirm with an account id answers the stop for that same call. */
function callDisconnect(gw, args) {
  if (args && args.confirm === true && args.provider_account_id !== undefined) return confirmCall(gw, args);
  return gw.callTool('disconnect', args);
}

// ------------------------------------------------------- the stop, before anything

test('an unconfirmed call stops, and the stop names every module the credential ends', async () => {
  const { gw, store } = await shared();
  const r = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(r.status, 'needs_confirmation');
  assert.equal(r.provider_account_id, KIT);
  assert.deepEqual(r.modules_ending.map((m) => `${m.service}/${m.module}`).sort(),
    ['github/issues', 'github/repos']);
  // The account is rendered through Session 1's escaper, and the module list rides the
  // description, which that function escapes too.
  assert.match(r.summary, /provider_account_id="fake-acct-shared"/);
  assert.match(r.summary, /ending github\/repos, github\/issues/);
  assert.match(r.summary, /removes 2 local records/);
  assert.equal(r.risk, 'destructive');
  // Nothing happened.
  assert.deepEqual(rows(store), ['github/issues', 'github/repos']);
});

test('the stop is enforced, not advisory: confirmation is not a manifest field here', async () => {
  // Witness 14: `confirmation` lives inside `execute` and a top-level tool is not on
  // that path, so this tool implements its own or it has none.
  const { gw, store, fake } = await shared();
  await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(await fake.auth.status({ providerAccountId: KIT }), 'ACTIVE',
    'the credential was revoked without an approval');
  assert.equal(rows(store).length, 2);
});

// ---------------------------------------------------------------- a clean teardown

test('a confirmed teardown revokes once and removes every row on that credential', async () => {
  const { gw, store, fake, home } = await shared();
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'disconnected');
  assert.deepEqual(r.steps.map((s) => s.step), ['revoke', 'delete']);
  assert.equal(r.steps.every((s) => s.ok), true);
  assert.deepEqual(r.removed.map((m) => `${m.service}/${m.module}`).sort(),
    ['github/issues', 'github/repos']);
  assert.deepEqual(rows(store), [], 'a sibling row survived a credential that is gone');
  assert.equal(await fake.auth.status({ providerAccountId: KIT }), 'ABSENT');

  const audit = readFileSync(`${home}/audit.jsonl`, 'utf8').trim().split('\n').map(JSON.parse);
  const last = audit.at(-1);
  assert.equal(last.op, 'disconnect');
  assert.equal(last.status, 'disconnected');
  assert.equal(last.provider_account_id, KIT);
  assert.equal('input' in last, false);
});

// ------------------------------------------------------------------ the refusals

test('a provider that refuses the revoke removes nothing, and says what each step did', async () => {
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 400, ok: false }, { step: 'delete', status: 500, ok: false }],
  });
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'teardown_incomplete');
  assert.equal(r.reason, 'not_absent_after_revoke');
  assert.equal(r.provider_status, 'ACTIVE');
  assert.deepEqual(r.steps.map((s) => s.ok), [false, false]);
  assert.deepEqual(rows(store), ['github/issues', 'github/repos'], 'rows went on a refused revoke');
});

test('absence is verified and never inferred: a revoke that reports success but leaves the account removes nothing', async (t) => {
  // The whole reason Session 2 added ABSENT. A revoke returning `supported: true` with
  // every step ok is not evidence the credential is gone; the provider saying it is gone
  // is. The post-revoke reading is driven directly here rather than through the fake's
  // own bookkeeping, because the fake correctly ties its deletion to the delete step and
  // so cannot express a provider that disagrees with its own success.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ACTIVE');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.notEqual(r.status, 'disconnected');
  assert.equal(r.reason, 'not_absent_after_revoke');
  assert.equal(r.provider_status, 'ACTIVE');
  assert.equal(rows(store).length, 2);
});

test('an adapter with no revoke is a missing capability, not a failure to report', async () => {
  const { gw, store } = await shared();
  const provider = gw.authProvider;
  delete provider.revoke;
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'needs_provider_capability');
  assert.equal(r.capability, 'revoke');
  assert.equal(rows(store).length, 2);
});

test('an adapter answering supported: false reports how, and removes nothing', async () => {
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({ supported: false, how: 'delete the file', steps: [] });
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'needs_provider_capability');
  assert.equal(r.how, 'delete the file');
  assert.equal(rows(store).length, 2);
});

test('a grant absent locally is said plainly rather than reported as a success that removed nothing', async () => {
  const { gw } = await createTestGateway();
  const r = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(r.status, 'needs_connect');
  assert.equal(r.reason, 'nothing_to_disconnect');
});

test('a readonly caller is denied by a policy rule, not by a metadata field', async () => {
  const { gw, store } = await shared({ role: 'readonly' });
  const r = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(r.status, 'denied');
  assert.equal(rows(store).length, 2);
  // And denied before any stop is composed, so a readonly caller never sees the summary.
  assert.equal(r.summary, undefined);
});

test('a repeated disconnect finds nothing to do the second time', async () => {
  const { gw } = await shared();
  const first = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(first.status, 'disconnected');
  const second = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(second.status, 'needs_connect');
  assert.equal(second.reason, 'nothing_to_disconnect');
});

// --------------------------------------------------- the approval and its binding

test('a confirmed call carrying no account id is refused', async () => {
  const { gw, store } = await shared();
  const r = await callDisconnect(gw, { service: 'github', module: 'repos', confirm: true });
  assert.equal(r.status, 'invalid_arguments');
  assert.equal(r.field, 'provider_account_id');
  assert.equal(rows(store).length, 2);
});

test('a reconnect between the stop and the confirmed call refuses audibly', async () => {
  const { gw, store } = await shared();
  const stop = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(stop.status, 'needs_confirmation');

  // A reconnect installs a different account id on that row.
  store.putConnection({
    id: 'conn-repos', service: 'github', module: 'repos', privilege: 'write',
    provider: 'catalog', provider_account_id: 'fake-acct-different', scopes: [],
    status: 'ACTIVE', created: new Date().toISOString(), updated: new Date().toISOString(),
  });

  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: stop.provider_account_id, confirm: true,
  });
  assert.equal(r.status, 'denied');
  assert.equal(r.rule.reason, 'account_changed');
  assert.equal(rows(store).length, 2, 'the reconnected row was touched');
});

test('a reconnect DURING the provider round trip cannot take the new row, within one process', async () => {
  // The window question 6 was really about: the binding check above happens before the
  // revoke, and the reconnect can land while the provider call is in flight. The delete
  // filters on the APPROVED account id, so the reconnected row carries a different id
  // and is skipped whether or not anything checks. Proved rather than reasoned.
  //
  // **This is one interleaving in one process, and the scope is the point.** The store
  // is an unlocked read-modify-write, so two gateway processes can still lose an update
  // and erase the reconnected row. That race predates this tool and is recorded at
  // `src/store.js`; an earlier version of this test's name claimed "by construction",
  // which claimed more than one process can establish.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome(({ providerAccountId }) => {
    // Mid-teardown: somebody reconnects `repos` onto a fresh account.
    store.putConnection({
      id: 'conn-repos', service: 'github', module: 'repos', privilege: 'write',
      provider: 'catalog', provider_account_id: 'fake-acct-reconnected', scopes: [],
      status: 'ACTIVE', created: new Date().toISOString(), updated: new Date().toISOString(),
    });
    fake.auth.removeAccount(providerAccountId);
    return {
      supported: true,
      steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
    };
  });
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'disconnected');
  // Only the sibling still on the approved credential went. The reconnected row stands.
  assert.deepEqual(r.removed.map((m) => `${m.service}/${m.module}`), ['github/issues']);
  assert.deepEqual(rows(store), ['github/repos']);
  assert.equal(store.getConnection({ service: 'github', module: 'repos' }).provider_account_id,
    'fake-acct-reconnected');
});

// ------------------------------------------- the scope caveat Session 2 handed on

test('a provider error after the revoke leaves every row alone', async () => {
  // providers/AGENTS.md: an error object is a transport or provider failure and not a
  // grant state. It must not read as absence, because absence is what removes rows.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  fake.auth.status = async () => ({ status: 503, error: { code: 'vendor_error', endpoint: '/x', method: 'GET' } });
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'vendor_error');
  assert.deepEqual(r.removed, []);
  assert.equal(rows(store).length, 2);
});

test('an INACTIVE account after the revoke is not absence, so nothing is removed', async (t) => {
  // The inverse of today's defect and the easy mistake while fixing today's defect: a
  // grant that is merely suspended is coming back, and its rows must survive.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'INACTIVE');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.reason, 'not_absent_after_revoke');
  assert.equal(r.provider_status, 'INACTIVE');
  assert.equal(rows(store).length, 2);
});

test('every non-absent word leaves the rows alone, so the gate is ABSENT and not "not ACTIVE"', async (t) => {
  // Both directions: the four stopped words and ACTIVE all withhold removal; ABSENT is
  // the only word that permits it.
  for (const word of ['ACTIVE', 'EXPIRED', 'FAILED', 'INACTIVE', 'INITIATED']) {
    const { gw, store, fake } = await shared();
    fake.auth.setRevokeOutcome({
      supported: true,
      steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
    });
    t.mock.method(fake.auth, 'status', async () => word);
    const r = await callDisconnect(gw, {
      service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
    });
    assert.notEqual(r.status, 'disconnected', `${word} permitted a removal`);
    assert.equal(rows(store).length, 2, `${word} removed a row`);
    t.mock.restoreAll();
  }
  // And the control: ABSENT does permit it, so the assertions above are not passing
  // because removal is unreachable.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ABSENT');
  const ok = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(ok.status, 'disconnected');
  assert.deepEqual(rows(store), []);
});

test('a module no connector declares is a connector gap, not a teardown', async () => {
  const { gw } = await createTestGateway();
  const r = await callDisconnect(gw, { service: 'github', module: 'nosuchmodule' });
  assert.equal(r.status, 'needs_connector');
});

test('arguments that are not identifiers are refused before anything is read', async () => {
  const { gw } = await shared();
  for (const args of [
    { service: 'github/../x', module: 'repos' },
    { service: 'github', module: '' },
    { service: 'github', module: 'repos', provider_account_id: '' },
    { service: 'github', module: 'repos', confirm: 'yes' },
  ]) {
    const r = await callDisconnect(gw, args);
    assert.equal(r.status, 'invalid_arguments', JSON.stringify(args));
  }
});

// --------------------------------------------- findings from the adversarial review

test('a module the policy denies cannot be ended through a sibling that shares its credential', async () => {
  // The policy is written per service and module, and this tool acts on the credential.
  // Calling through a permitted module would otherwise end a denied one. It is this
  // build's own lesson committed again, at a third unit, and caught by review.
  const { gw, store, fake } = await shared({
    policy: {
      roles: ['runtime', 'readonly'],
      default_role: 'runtime',
      rules: [
        { role: 'runtime', op: 'disconnect', module: 'issues', effect: 'deny' },
        { role: '*', effect: 'allow' },
      ],
    },
  });
  const r = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(r.status, 'denied');
  assert.equal(r.reason, 'bound_module_denied');
  assert.equal(r.module, 'issues');
  assert.equal(rows(store).length, 2);
  assert.equal(await fake.auth.status({ providerAccountId: KIT }), 'ACTIVE',
    'the credential was revoked despite a denied sibling');
});

test('the same call is permitted once no bound module is denied, so the denial above is not blanket', async () => {
  const { gw, store } = await shared({
    policy: {
      roles: ['runtime', 'readonly'],
      default_role: 'runtime',
      rules: [
        { role: 'runtime', op: 'disconnect', module: 'nosuchmodule', effect: 'deny' },
        { role: '*', effect: 'allow' },
      ],
    },
  });
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'disconnected');
  assert.deepEqual(rows(store), []);
});

test('an account that reads absent after a FAILED teardown fails closed and removes nothing', async (t) => {
  // providers/AGENTS.md records that ABSENT means absent within the scope this
  // credential can see: a project change or a visibility restriction also answers 404.
  // If the teardown's own final step failed, the two readings cannot be told apart.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 500, ok: false }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ABSENT');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'teardown_incomplete');
  assert.equal(r.reason, 'absent_but_teardown_failed');
  assert.equal(rows(store).length, 2);
});

test('the measured API_KEY case still passes: a refused revoke POST with a successful DELETE', async (t) => {
  // The control for the clause above. Measured at the vendor 2026-09-19: a custom
  // API_KEY toolkit refuses the revoke POST with 400 and the DELETE does the work.
  // Failing closed on any failed step would have broken the case the build cares about.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 400, ok: false }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ABSENT');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'disconnected');
  assert.deepEqual(rows(store), []);
});

test('an adapter that throws is a vendor error, not a missing capability', async () => {
  // Four situations wore one status word until review separated them: a caller told to
  // report a broken connector cannot tell that the right move was to retry.
  const { gw, store, fake } = await shared();
  fake.auth.revoke = async () => { throw new Error('socket hang up'); };
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'vendor_error');
  assert.equal(r.method, 'revoke');
  assert.equal(rows(store).length, 2);
});

test('a readonly caller is denied on a module the MANIFEST declares read', async () => {
  // The first version of this test wrote `privilege: 'read'` into a github/repos row,
  // but authorization reads the manifest and that module is declared write, so the
  // pre-existing readonly-plus-write rule denied it and the disconnect-specific rule
  // could have been deleted unnoticed. `github/users` is declared read.
  const { gw, store, fake } = await createTestGateway({ role: 'readonly' });
  fake.auth.setStatus(KIT, 'ACTIVE');
  store.putConnection({
    id: 'conn-users', service: 'github', module: 'users', privilege: 'read',
    provider: 'catalog', provider_account_id: KIT, scopes: [], status: 'ACTIVE',
    created: new Date().toISOString(), updated: new Date().toISOString(),
  });
  const r = await callDisconnect(gw, { service: 'github', module: 'users' });
  assert.equal(r.status, 'denied');
  assert.equal(r.rule.op, 'disconnect', 'denied by some other rule than the one for this tool');
  assert.equal(rows(store).length, 1);
});

test('a status answer that overtakes a teardown does not resurrect the row it removed', async (t) => {
  // Before disconnect, nothing removed a row, so this interleaving could not happen.
  // The new tool created it in an old function. connect_status captures the row, awaits
  // the provider, and wrote it back unconditionally.
  const { gw, store, fake } = await shared();
  let removeDuringCheck = null;
  t.mock.method(fake.auth, 'status', async () => {
    if (removeDuringCheck) { removeDuringCheck(); removeDuringCheck = null; }
    return 'ACTIVE';
  });
  removeDuringCheck = () => { store.deleteConnection({ providerAccountId: KIT }); };
  const r = await gw.connectStatus({ service: 'github', module: 'repos' });
  assert.equal(r.status, 'needs_connect');
  assert.equal(r.reason, 'removed_while_checking');
  assert.deepEqual(rows(store), [], 'a revoked credential was given a fresh ACTIVE row');
});

test('an ordinary connect_status still records an ACTIVE grant, so the guard is not refusing everything', async (t) => {
  // Starting from INITIATED and asserting the transition, because starting ACTIVE and
  // counting rows passes whether or not a write happened.
  const { gw, store, fake } = await shared();
  store.putConnection({
    ...store.getConnection({ service: 'github', module: 'repos' }), status: 'INITIATED',
  });
  assert.equal(store.getConnection({ service: 'github', module: 'repos' }).status, 'INITIATED');
  t.mock.method(fake.auth, 'status', async () => 'ACTIVE');
  const r = await gw.connectStatus({ service: 'github', module: 'repos' });
  assert.equal(r.status, 'connected');
  assert.equal(store.getConnection({ service: 'github', module: 'repos' }).status, 'ACTIVE',
    'the guard blocked an ordinary write');
});

// ------------------------------------------- findings from the second review round

test('a bound row whose module no longer resolves is denied, not authorized as privilege-less', async () => {
  // Passing `undefined` privilege made every privilege rule skip, so an admin binding
  // left behind by a retired module sailed past the runtime/admin denial.
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus(KIT, 'ACTIVE');
  for (const [module, privilege] of [['repos', 'write'], ['retired_module', 'admin']]) {
    store.putConnection({
      id: `conn-${module}`, service: 'github', module, privilege,
      provider: 'catalog', provider_account_id: KIT, scopes: [], status: 'ACTIVE',
      created: new Date().toISOString(), updated: new Date().toISOString(),
    });
  }
  const r = await callDisconnect(gw, { service: 'github', module: 'repos' });
  assert.equal(r.status, 'denied');
  assert.equal(r.reason, 'bound_module_denied');
  assert.equal(r.module, 'retired_module');
  assert.equal(rows(store).length, 2);
  assert.equal(await fake.auth.status({ providerAccountId: KIT }), 'ACTIVE');
});

test('an adapter reporting no steps has established nothing, so nothing is removed', async (t) => {
  // `{ supported: true, steps: [] }` plus an ABSENT reading deleted every row until the
  // second review round: the original ambiguity returning through the gate built for it.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({ supported: true, steps: [] });
  t.mock.method(fake.auth, 'status', async () => 'ABSENT');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'teardown_incomplete');
  assert.equal(r.reason, 'no_teardown_evidence');
  assert.equal(rows(store).length, 2);
});

test('hydration does not resurrect a credential this process just revoked', async () => {
  // Hydration writes an ACTIVE row for any module of a toolkit lacking its own grant,
  // from a listing it may have captured before the revoke. Checking whether a row
  // exists cannot catch this, because writing missing rows is what hydration is for.
  const { gw, store, fake } = await shared();
  const done = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(done.status, 'disconnected');
  assert.deepEqual(rows(store), []);

  // A listing that still carries the revoked account, as a delayed response would.
  fake.auth.listAccounts = async () => [{ id: KIT, toolkit: 'GITHUB', status: 'ACTIVE' }];
  await gw.hydrateFromProvider();
  assert.deepEqual(rows(store), [], 'the stale rows this tool removes came straight back');
});

test('hydration still works for an account that was never revoked, so the guard is narrow', async () => {
  const { gw, store, fake } = await createTestGateway();
  fake.auth.listAccounts = async () => [{ id: 'ca_fresh', toolkit: 'GITHUB', status: 'ACTIVE' }];
  await gw.hydrateFromProvider();
  assert.ok(rows(store).length > 0, 'the guard blocked an ordinary hydration');
});

test('a NON-ACTIVE status answer that overtakes a teardown does not resurrect the row either', async (t) => {
  // The first fix guarded only the ACTIVE branch; the other branch wrote the captured
  // record back unconditionally, so a delayed INACTIVE put the deleted row back.
  const { gw, store, fake } = await shared();
  let removeDuringCheck = null;
  t.mock.method(fake.auth, 'status', async () => {
    if (removeDuringCheck) { removeDuringCheck(); removeDuringCheck = null; }
    return 'INACTIVE';
  });
  removeDuringCheck = () => { store.deleteConnection({ providerAccountId: KIT }); };
  const r = await gw.connectStatus({ service: 'github', module: 'repos' });
  assert.equal(r.status, 'needs_connect');
  assert.deepEqual(rows(store), [], 'a removed row was written back with a non-ACTIVE status');
});

test('a non-ACTIVE status still updates an ordinary row, so that guard is narrow too', async (t) => {
  const { gw, store, fake } = await shared();
  t.mock.method(fake.auth, 'status', async () => 'EXPIRED');
  await gw.connectStatus({ service: 'github', module: 'repos' });
  assert.equal(store.getConnection({ service: 'github', module: 'repos' }).status, 'EXPIRED');
});

test('a status check that cannot be made is unknown state, not a credential that is still there', async (t) => {
  // Found by the cold verification of the instructions, not by a review of the code:
  // a reader told "the credential is still there" retries, and retrying against a state
  // nobody could read is the one thing the same instruction says not to do.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => { throw new Error('socket hang up'); });
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'teardown_incomplete');
  assert.equal(r.reason, 'absence_unverified');
  assert.equal(r.provider_status, null);
  assert.equal(rows(store).length, 2);
});

test('a provider that answers ACTIVE is still reported as still there, so the two stay distinct', async (t) => {
  const { gw, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ACTIVE');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.reason, 'not_absent_after_revoke');
  assert.equal(r.provider_status, 'ACTIVE');
});

test('a finished teardown says what it established, not only that it finished', async (t) => {
  // Found by Refine's cold discoverability test: `disconnected` alone reads as "the
  // credential is dead", and for the measured API_KEY case it means only that the
  // provider has forgotten it. The revoke POST is refused there and the DELETE, which
  // is the step the gate requires, does the work.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 400, ok: false }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ABSENT');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'disconnected');
  assert.equal(r.credential_revoked, 'unknown', 'a refused revoke read as a completed cutoff');
  // The rows still go: nothing here points at the credential any more, which is right.
  assert.deepEqual(rows(store), []);
});

test('a teardown whose every step succeeded says so, so the two are distinguishable', async (t) => {
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ABSENT');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.credential_revoked, 'yes');
  assert.deepEqual(rows(store), []);
});

test("the teardown's own error survives a later check that also fails", async (t) => {
  // Found by exercising a teardown that fails at the provider, in Refine. The adapter
  // reports a failed final call as an error alongside `supported: true`; absence is
  // still worth checking, but when that check also failed its error was the only one
  // reported and the teardown's own was dropped.
  const { gw, store, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    status: 500,
    error: { code: 'vendor_error', endpoint: '/connected_accounts/x', method: 'DELETE' },
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 500, ok: false }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ACTIVE');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.status, 'teardown_incomplete');
  assert.deepEqual(r.teardown_error, { http_status: 500, endpoint: '/connected_accounts/x', method: 'DELETE' });
  assert.equal(r.provider_status, 'ACTIVE', 'the later reading is reported too, not instead');
  assert.equal(rows(store).length, 2);
});

test('a teardown with no error of its own carries none, so the field means something', async (t) => {
  const { gw, fake } = await shared();
  fake.auth.setRevokeOutcome({
    supported: true,
    steps: [{ step: 'revoke', status: 200, ok: true }, { step: 'delete', status: 200, ok: true }],
  });
  t.mock.method(fake.auth, 'status', async () => 'ACTIVE');
  const r = await callDisconnect(gw, {
    service: 'github', module: 'repos', provider_account_id: KIT, confirm: true,
  });
  assert.equal(r.teardown_error, null);
});

// ------------------------------- a record that outlived the connector that made it

/** The real orphaned row, copied field for field from the live store on 2026-09-20. */
function orphanedRow(store, overrides = {}) {
  store.putConnection({
    id: '0db63f37-1cf8-4ec4-b858-aca64eb51bc4',
    service: 'pagespeed',
    module: 'insights',
    privilege: 'read',
    provider: 'catalog',
    provider_account_id: 'ca_orphan_fixture',
    scopes: [],
    status: 'ACTIVE',
    created: '2026-09-19T23:41:08.492Z',
    updated: '2026-09-19T23:44:11.882Z',
    ...overrides,
  });
}

test('a record whose connector was retired can still be taken down, and the stop says so', async () => {
  // Found in Refine by trying the tool on a real orphan. Retiring a connector leaves
  // its grant live at the provider and its row here pointing at nothing, which is how
  // a row is orphaned; refusing on `undeclared` meant the tool built to clear stale
  // rows could not clear the one kind the tree actually produces.
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(store);
  assert.equal(gw.lookupModule('pagespeed', 'insights'), null, 'the fixture must be undeclared');

  const stop = await callDisconnect(gw, { service: 'pagespeed', module: 'insights' });
  assert.equal(stop.status, 'needs_confirmation');
  assert.equal(stop.provider_account_id, 'ca_orphan_fixture');
  assert.match(stop.summary, /nothing declares pagespeed\/insights any more/);
  assert.deepEqual(stop.modules_ending.map((m) => `${m.service}/${m.module}`), ['pagespeed/insights']);

  const done = await callDisconnect(gw, {
    service: 'pagespeed', module: 'insights',
    provider_account_id: 'ca_orphan_fixture', confirm: true,
  });
  assert.equal(done.status, 'disconnected');
  assert.equal(done.credential_revoked, 'yes');
  assert.deepEqual(rows(store), []);
});

test('an orphaned record carrying no usable privilege is refused, and the vendor is never called', async () => {
  // A store row is not a manifest: manifest.js validates privilege against
  // read|write|admin and a row has been through nothing. Policy matching is strict
  // equality, so "ADMIN" or "" matches no privilege rule and would slip past a
  // privilege-specific denial. Found by adversarial review before this saw a real
  // account.
  for (const privilege of [null, undefined, '', 'ADMIN', 'Read', 'superuser', 7, ['write']]) {
    const { gw, store, fake } = await createTestGateway();
    fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
    let revokes = 0;
    const original = fake.auth.revoke.bind(fake.auth);
    fake.auth.revoke = async (a) => { revokes += 1; return original(a); };
    orphanedRow(store, { privilege });
    const r = await callDisconnect(gw, {
      service: 'pagespeed', module: 'insights',
      provider_account_id: 'ca_orphan_fixture', confirm: true,
    });
    assert.equal(r.status, 'denied', `privilege ${JSON.stringify(privilege)} was accepted`);
    assert.equal(r.reason, 'orphaned_record_without_privilege');
    assert.equal(revokes, 0, 'the vendor was called for an unauthorizable row');
    assert.equal(rows(store).length, 1);
  }
  // The control: a valid stored privilege is accepted, so the loop is not refusing all.
  const ok = await createTestGateway();
  ok.fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(ok.store, { privilege: 'read' });
  const stop = await callDisconnect(ok.gw, { service: 'pagespeed', module: 'insights' });
  assert.equal(stop.status, 'needs_confirmation');
});

test('an orphaned record naming an unknown provider is refused rather than sent to the catalog', async () => {
  // providerFor sends everything that is not exactly `local-file` to the catalog
  // adapter, so a row naming nothing would have revoked against the catalog on no
  // evidence it belonged there. Adversarial review, P1.
  for (const provider of [null, undefined, '', 'nango', 'Catalog', 'made-up', 42]) {
    const { gw, store, fake } = await createTestGateway();
    fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
    let revokes = 0;
    const original = fake.auth.revoke.bind(fake.auth);
    fake.auth.revoke = async (a) => { revokes += 1; return original(a); };
    orphanedRow(store, { provider });
    const r = await callDisconnect(gw, {
      service: 'pagespeed', module: 'insights',
      provider_account_id: 'ca_orphan_fixture', confirm: true,
    });
    assert.equal(r.status, 'denied', `provider ${JSON.stringify(provider)} was accepted`);
    assert.equal(r.reason, 'orphaned_record_without_provider');
    assert.equal(revokes, 0, 'the vendor was called for a row naming an unknown provider');
    assert.equal(rows(store).length, 1);
  }
  // The control: both supported providers are accepted as far as the stop.
  for (const provider of ['catalog', 'local-file']) {
    const { gw, store, fake } = await createTestGateway();
    fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
    orphanedRow(store, { provider });
    const stop = await callDisconnect(gw, { service: 'pagespeed', module: 'insights' });
    assert.equal(stop.status, 'needs_confirmation', `provider ${provider} was refused`);
  }
});

test('an orphaned record is still held to every gate: readonly, the binding, and absence', async (t) => {
  const readonly = await createTestGateway({ role: 'readonly' });
  readonly.fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(readonly.store);
  const denied = await callDisconnect(readonly.gw, { service: 'pagespeed', module: 'insights' });
  assert.equal(denied.status, 'denied', 'an orphan let a readonly caller through');

  const bound = await createTestGateway();
  bound.fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(bound.store);
  const wrong = await callDisconnect(bound.gw, {
    service: 'pagespeed', module: 'insights', provider_account_id: 'ca_something_else', confirm: true,
  });
  assert.equal(wrong.status, 'denied');
  assert.equal(wrong.rule.reason, 'account_changed');

  const absent = await createTestGateway();
  absent.fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(absent.store);
  t.mock.method(absent.fake.auth, 'status', async () => 'ACTIVE');
  const notGone = await callDisconnect(absent.gw, {
    service: 'pagespeed', module: 'insights', provider_account_id: 'ca_orphan_fixture', confirm: true,
  });
  assert.equal(notGone.status, 'teardown_incomplete');
  assert.equal(rows(absent.store).length, 1, 'an orphan skipped the absence gate');
});

test('a service that is undeclared AND has no record is still needs_connector', async () => {
  // The guard that was there before is not relaxed; it now fires on the case it was for.
  const { gw } = await createTestGateway();
  const r = await callDisconnect(gw, { service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'undeclared');
});

test('a sibling orphan naming an unknown provider blocks the teardown from either direction', async () => {
  // Adversarial review, round two. Bindings are collected by account id alone, so two
  // orphaned rows can share an account while naming different providers. Validating
  // only the requested row and then deleting account-wide removed a row whose provider
  // the gateway had explicitly refused to establish.
  for (const entry of [['pagespeed', 'insights'], ['retired', 'thing']]) {
    const { gw, store, fake } = await createTestGateway();
    fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
    let revokes = 0;
    const original = fake.auth.revoke.bind(fake.auth);
    fake.auth.revoke = async (a) => { revokes += 1; return original(a); };
    orphanedRow(store);                                             // provider: catalog
    orphanedRow(store, { id: 'other', service: 'retired', module: 'thing', provider: 'made-up' });
    const r = await callDisconnect(gw, {
      service: entry[0], module: entry[1],
      provider_account_id: 'ca_orphan_fixture', confirm: true,
    });
    assert.equal(r.status, 'denied', `entering through ${entry.join('/')} was permitted`);
    assert.equal(revokes, 0, 'the vendor was called despite a sibling of unknown provider');
    assert.equal(rows(store).length, 2, 'a row of unknown provider was removed');
  }
  // The control: two orphans both naming a supported provider do tear down together.
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(store);
  orphanedRow(store, { id: 'other', service: 'retired', module: 'thing' });
  const ok = await callDisconnect(gw, {
    service: 'pagespeed', module: 'insights',
    provider_account_id: 'ca_orphan_fixture', confirm: true,
  });
  assert.equal(ok.status, 'disconnected');
  assert.deepEqual(rows(store), []);
});

test('a declared sibling is covered by its manifest, not by the stored provider check', async () => {
  // A declared module has been through manifest.js; its row's provider field is not
  // what authorizes it, and requiring one there would refuse ordinary teardowns.
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(store);
  store.putConnection({
    id: 'declared', service: 'github', module: 'repos', privilege: 'write',
    provider: 'nonsense-but-declared', provider_account_id: 'ca_orphan_fixture',
    scopes: [], status: 'ACTIVE',
    created: new Date().toISOString(), updated: new Date().toISOString(),
  });
  const r = await callDisconnect(gw, {
    service: 'pagespeed', module: 'insights',
    provider_account_id: 'ca_orphan_fixture', confirm: true,
  });
  assert.equal(r.status, 'disconnected');
  assert.deepEqual(rows(store), []);
});

// -------------------- connect_status on a record that outlived its connector

test('an orphaned catalog row reading ACTIVE is refreshed to ABSENT and is not connected', async () => {
  // The measured pagespeed/insights case, 2026-09-20: teardown returned
  // teardown_incomplete / absent_but_teardown_failed, the row survived, and
  // connect_status refused on undeclared so the row kept reading ACTIVE.
  const { gw, store, fake, home } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ABSENT');
  orphanedRow(store);
  assert.equal(gw.lookupModule('pagespeed', 'insights'), null, 'the fixture must be undeclared');
  assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }).status, 'ACTIVE');

  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'orphaned_record');
  assert.equal(r.provider_status, 'ABSENT');
  assert.equal(r.service, 'pagespeed');
  assert.equal(r.module, 'insights');
  const row = store.getConnection({ service: 'pagespeed', module: 'insights' });
  assert.equal(row.status, 'ABSENT');
  assert.equal(row.id, '0db63f37-1cf8-4ec4-b858-aca64eb51bc4');
  assert.equal(row.privilege, 'read');
  assert.equal(row.provider, 'catalog');
  assert.equal(row.provider_account_id, 'ca_orphan_fixture');
  assert.equal(row.created, '2026-09-19T23:41:08.492Z');

  const audit = readFileSync(`${home}/audit.jsonl`, 'utf8').trim().split('\n').map(JSON.parse);
  const last = audit.at(-1);
  assert.equal(last.op, 'connectStatus');
  assert.equal(last.status, 'needs_connector');
  assert.equal(last.privilege, 'read');
});

test('an orphaned catalog row whose provider still says ACTIVE is still not connected', async () => {
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(store, { privilege: 'write' });
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.notEqual(r.status, 'connected');
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'orphaned_record');
  assert.equal(r.provider_status, 'ACTIVE');
  const row = store.getConnection({ service: 'pagespeed', module: 'insights' });
  assert.equal(row.status, 'ACTIVE');
  assert.equal(row.privilege, 'write');
});

test('an orphan whose provider answers nothing readable is not reported as refreshed', async (t) => {
  // Adversarial review round two: `orphaned_record` promises in three documents that
  // the row now matches the provider, and this is the one orphan path that cannot
  // deliver that. Returning `orphaned_record` here told a reader the row had been
  // checked when nobody had successfully asked. It gets its own reason instead.
  const { gw, store, fake } = await createTestGateway();
  orphanedRow(store);
  // Not an error object, which would be vendor_error: an answer with no status in it.
  t.mock.method(fake.auth, 'status', async () => ({}));
  // Captured rather than compared against the fixture literal, because putConnection
  // stamps `updated` with the time it ran, so the fixture never holds the value it
  // was given. The first version of this test asserted that literal and failed, which
  // is the test working: an assertion about a fixture has to be true of the fixture.
  const before = store.getConnection({ service: 'pagespeed', module: 'insights' });
  assert.equal(before.status, 'ACTIVE', 'the row starts stale and ACTIVE');

  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'orphaned_status_unreadable');
  assert.equal(r.provider_status, undefined, 'there is no provider status to carry');

  // The row is untouched, which is the whole point: it is as stale as it was.
  const after = store.getConnection({ service: 'pagespeed', module: 'insights' });
  assert.deepEqual(after, before, 'nothing was written, not even a new updated stamp');
});

test('an orphaned record carrying no usable privilege is refused by connect_status, and the vendor is never called', async () => {
  for (const privilege of ['ADMIN', '', null, undefined]) {
    const { gw, store, fake } = await createTestGateway();
    fake.auth.setStatus('ca_orphan_fixture', 'ABSENT');
    let statuses = 0;
    const original = fake.auth.status.bind(fake.auth);
    fake.auth.status = async (a) => { statuses += 1; return original(a); };
    orphanedRow(store, { privilege });
    const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
    assert.equal(r.status, 'denied', `privilege ${JSON.stringify(privilege)} was accepted`);
    assert.equal(r.reason, 'orphaned_record_without_privilege');
    assert.equal(statuses, 0, 'the vendor was called for an unauthorizable row');
    assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }).status, 'ACTIVE',
      'a denied status check rewrote the row');
  }
});

test('an orphaned record naming an unknown provider is refused by connect_status rather than sent to the catalog', async () => {
  for (const provider of ['catalogue', '', null, undefined]) {
    const { gw, store, fake } = await createTestGateway();
    fake.auth.setStatus('ca_orphan_fixture', 'ABSENT');
    let statuses = 0;
    const original = fake.auth.status.bind(fake.auth);
    fake.auth.status = async (a) => { statuses += 1; return original(a); };
    orphanedRow(store, { provider });
    const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
    assert.equal(r.status, 'denied', `provider ${JSON.stringify(provider)} was accepted`);
    assert.equal(r.reason, 'orphaned_record_without_provider');
    assert.equal(statuses, 0, 'the vendor was called for a row naming an unknown provider');
    assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }).status, 'ACTIVE');
  }
});

test('a local-file orphan is refused with its own reason, and no status call is made', async () => {
  let statuses = 0;
  const localFileProvider = {
    name: 'local-file',
    isConfigured: () => true,
    setupText: () => 'fixture',
    async status() { statuses += 1; return 'INACTIVE'; },
    async unwrap() { return { supported: false }; },
    async revoke() { return { supported: false, how: 'delete the file', steps: [] }; },
  };
  const { gw, store } = await createTestGateway({ localFileProvider });
  orphanedRow(store, { provider: 'local-file' });
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'orphaned_local_file_record');
  assert.equal(statuses, 0, 'local-file status was called without file and variables');
  assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }).status, 'ACTIVE',
    'a refused local-file guess rewrote the row');
});

test('undeclared with no row at all is still needs_connector with reason undeclared', async () => {
  const { gw, fake } = await createTestGateway();
  let statuses = 0;
  const original = fake.auth.status.bind(fake.auth);
  fake.auth.status = async (a) => { statuses += 1; return original(a); };
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'undeclared');
  assert.equal(statuses, 0);
});

test('undeclared with a row carrying no provider_account_id is not an orphan', async () => {
  const { gw, store, fake } = await createTestGateway();
  let statuses = 0;
  const original = fake.auth.status.bind(fake.auth);
  fake.auth.status = async (a) => { statuses += 1; return original(a); };
  orphanedRow(store, { provider_account_id: null });
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'undeclared');
  assert.equal(statuses, 0);
  assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }).status, 'ACTIVE');
});

test('an orphan status answer that overtakes a teardown does not resurrect the row', async (t) => {
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ABSENT');
  orphanedRow(store);
  let removeDuringCheck = null;
  t.mock.method(fake.auth, 'status', async () => {
    if (removeDuringCheck) { removeDuringCheck(); removeDuringCheck = null; }
    return 'ABSENT';
  });
  removeDuringCheck = () => { store.deleteConnection({ service: 'pagespeed', module: 'insights' }); };
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'removed_while_checking');
  assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }), null,
    'a removed orphan was written back');
});

test('an orphan status answer that overtakes a rebound does not overwrite the new binding', async (t) => {
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ABSENT');
  orphanedRow(store);
  let rebindDuringCheck = null;
  t.mock.method(fake.auth, 'status', async () => {
    if (rebindDuringCheck) { rebindDuringCheck(); rebindDuringCheck = null; }
    return 'ABSENT';
  });
  rebindDuringCheck = () => {
    const row = store.getConnection({ service: 'pagespeed', module: 'insights' });
    store.putConnection({ ...row, provider_account_id: 'ca_someone_else' });
  };
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'needs_connector');
  assert.equal(r.reason, 'rebound_while_checking');
  const row = store.getConnection({ service: 'pagespeed', module: 'insights' });
  assert.equal(row.provider_account_id, 'ca_someone_else');
  assert.equal(row.status, 'ACTIVE', 'the rebound row was overwritten with the old reading');
});

test('a provider error on an orphan is not a grant status and leaves the row alone', async () => {
  const { gw, store, fake } = await createTestGateway();
  fake.auth.setStatus('ca_orphan_fixture', 'ACTIVE');
  orphanedRow(store);
  fake.auth.status = async () => ({ status: 503, error: { code: 'vendor_error', endpoint: '/x', method: 'GET' } });
  const r = await gw.connectStatus({ service: 'pagespeed', module: 'insights' });
  assert.equal(r.status, 'vendor_error');
  assert.equal(store.getConnection({ service: 'pagespeed', module: 'insights' }).status, 'ACTIVE');
});
