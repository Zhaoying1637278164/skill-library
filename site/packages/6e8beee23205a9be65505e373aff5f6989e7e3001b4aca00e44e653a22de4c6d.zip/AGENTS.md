---
root: wiser
---

# Wiser

The general knowledge-work plugin: the skills, experts, tools, connectors, and standards that a knowledge worker uses for agentic work, in their own voice, on their own material.

**This file is this root's constitution.** Where a primitive cites "the constitution", it means this file. The chain, the sequence of `AGENTS.md` files a session loads, starts here: load it before the first read or write under this root. The words this root uses with a fixed meaning are defined in `GLOSSARY.md`.

This root is a capability product, owned by EffectiveSC.

## What this root is

An authoring tree, not a working folder. Nothing here is anyone's work product; everything here is the capability that such work uses. Output belongs in the working folder a session attaches, never in this root.

## Writes

In use this root is read-only, with one exception: a tool writes its own dependencies, and a browser tool also writes a browser build whose location depends on the platform and on `PLAYWRIGHT_BROWSERS_PATH`. `tools/AGENTS.md` lists every one of them and where each lands. The gateway's writes sit outside this plugin and are listed in `gateway/AGENTS.md`. The classifier session binding sits outside this plugin and is listed in `hooks/AGENTS.md`.

Three install bases. This plugin copy holds a tool's own packages. The owning root holds work product. Person-scoped machine files that have no root context, including model weights, land in `models/` under the platform user-config directory `gateway/SETUP.md` names, never in this plugin, never in a root, never in the connector key file. An explicit absolute path still wins. A destination that is the key file is refused by the tool. A root path on an explicit `--model-cache` is the calling agent's refusal; the tool does not know the composed roots. A knowledge-set recipe names a file inside that folder; primitives name no model. **Roots do not receive models or libraries that have no root context.** `tools/AGENTS.md` is the inventory for those writes; do not restate the OS paths here.

Never write to another root composed in the same workspace, whatever its permissions look like on disk. A workspace that happens to compose a root is not permission to edit it.

## Workspace Model

The attached working folder is the **owning root**: the personal, org, client, department, or industry folder the user attached for this work. Its own `AGENTS.md` declares its `type` and a **Provides** block binding abstract keys to files. **A root is identified by that declaration, never by its folder name.** Before the first read or write under any path in the working folder, load that directory's `AGENTS.md`, or the nearest ancestor's if it has none; absence is never permission.

**Abstract keys and the Provides block.** Primitives do not name files; they request keys, and the owning root's Provides block binds each key to a file.

- The keys are `voice`, `about`, `design`, `secrets:<platform>` and `competitors`. **Whether a key is required or optional is the primitive's own declaration**, made in its Inputs: `about` and `design` are optional to most that request them and `voice` is required to every one. `competitors` is the exception this file owns, and is optional to all of them for the reason below.
- An **unscoped** key resolves in the root that owns the output. A **scoped** key, written `voice:org` or `voice:client`, resolves in the root of that type.
- More than one plausible root, or none: ask. Never hunt.

**When a key is unbound.**

- A **required** key unbound: stop and ask.
- An **optional** key unbound: name what degraded, and proceed.
- `competitors` is optional and is bound only where a competitive set has been confirmed. Unbound means there is no confirmed set, so work that names, ranks, or differentiates against another party says so and proceeds. **Never invent a set to finish the sentence.**
- **A heading that says its content is not yet defined is unavailable on its own.** The answered headings around it are used.
- **A bound file counts as unavailable when no heading is answered.** Name the degradation the same way, and never invent what it would have said.

**Secrets.** Account access to an outside platform is the gateway: a primitive names an action id, a missing grant is `needs_connect`, and the vendor token never lives in a root. The one local file that path needs is the auth provider's project key, once per person on this machine, at the platform user-config path `gateway/SETUP.md` names, never under a composed root and never under `--home`. A person reaches that file by the named ask **set up connectors**, not by inventing a `mkdir` recipe. A local-file connector (a service the catalog does not cover) reads one bound file via `--secret <service>=<abs file>` or a Provides `secrets:<platform>` path the root names; there is no default directory in any root, and `memory/secrets/` is not one. Unbound and no `--secret`: stop and ask. **A secret's contents never enter the conversation, a log, a commit, or another file.**

**This plugin is read-only in use, apart from what a tool installs for itself.** Never write under this root during a session. Outputs land in the working folder, in the directories that folder's own `AGENTS.md` declares. What a tool installs for itself lands where `tools/AGENTS.md` lists, including person-scoped model weights outside every root. Nothing else writes here.

**Determining the owning root.** The candidates are the composed roots whose own `AGENTS.md` declares a `type:`. Where exactly one root is a candidate it is the owning root and nothing is asked. Where several are, or none is, the rule above is in force: ask, never hunt, and ask **once, early, before the first read or write under any of them**, then state the answer for the session so it is not resolved again at the first write. A root declaring no `type:` is not a candidate; that absence does not make it a write destination either, and what it does mean is the write-mode clause below.

**The owning root's contract version.** A session that has resolved the owning root reads that root's `layout:` against C1 of `standards/user-root.md`, and reports a mismatch at that point rather than at the first write. C1 owns what the comparison means, what a mismatch owes, and which primitive owes it; this clause is only the moment it happens, and C1 governs what the session may do about it. A standard that is absent or unreadable is reported as such, never as a pass. A person asks for this comparison by name with **update root**.

**Write mode.** A session either uses this root or authors it. The two differ in what may be written, never in where the session is standing.

**The root a session loaded its governing constitution from is not a destination for that session's work product**, whatever that root's folder name or position in the workspace, and including when it is the working directory. This is `Irreversibles` read as the rule it already is: *during a session that uses it*. The root identifies itself, so no token is needed and none is added.

The clause governs **work product only**. Three writes are therefore unaffected, named here so a reader need not infer them: what a tool installs for itself, which `Writes` states and `tools/AGENTS.md` inventories; `skills/Onboard Root/` writing into an `empty` or `populated-undeclared` destination, which is how an owning root comes to exist at all; and `skills/Housekeeping/` installing local filing routers in a foreign tree, which declares no identity there.

Authoring this root is entered by **the operator's authorization for a named phase and a named target**. An Active Playbook is the *record* of that authorization and never the grant: a row a session set Active itself grants nothing, and a Playbook may be Active and forbid these writes in the same sentence.

**Where this holds.** These clauses bind a session that has loaded this chain. A host that never loads it never receives them, and nothing written in this file can change that. Where the chain did not load, the rules still hold; they are simply not delivered, and the session cannot be expected to have derived them.

## Behavioral Core

Binding on any work done through this root.

- Ambiguous requests get a clarifying question; uncertain interpretations get stated and confirmed. A pure question gets an answer, never execution. Said alone, `thoughts?` is that question: it asks what you make of where the work stands, and authorizes none of it.
- For non-trivial work, state the approach, the alternatives considered, and the confidence in it before executing.
- Challenge flaws, weak evidence, and better alternatives; defer to sound reasoning, new context, or an explained trade-off. **Do not auto-defer on pushback**: restate unless the point was addressed.
- Execute what the host can execute. Never hand the user steps you could run yourself; where the host cannot act, say so and hand off the smallest possible step.
- **A review runs in a context that did not produce the work.** Delegate it, handing over the work and the reviewing primitive, never the reasoning that produced the work. On a host with one context, a new chat given exactly that is the context.
- **Three things a primitive names are absent**: a capability its `gaps` frontmatter declares, which is the authoritative statement of what is missing whether or not a path names it; a connector this root still does not ship, which remains a gap, or a named action whose grant is not connected, where `needs_connect` is the stop and `skills/Connect Account/` is the next human turn, with a reading only such an action could fetch labeled per `standards/conventions.md` unless the host retrieves it or the user hands it over, or the gateway is not attached to this harness or a gateway call returned `needs_provider`, where `skills/Set Up Connectors/` is the next human turn; and a tool that cannot run, for want of a system dependency or after its install was authorized. A tool that stops for consent is asking a question, and the answer is `--install` on the same command, or `WISER_ALLOW_INSTALL=1` for an unattended run; until it is answered the step that needs the tool waits, and nothing is produced in its place. Where a step depends on something absent, or on a tool that stopped, say which step cannot run and what it would have produced, name the gap, produce nothing in its place, carry no later step forward on a result that never returned, and let whatever does not depend on it still run; where a mention only routes work away to something absent, that route is closed and nothing else stops. A run that stopped this way, and said so, has done its work.

Guard rails, binding for any shared artifact:

- Never modify the thing being tested to make a test pass. A failing test found a problem; report it.
- Fixes flow toward the root cause, never toward accommodating a problem elsewhere.
- Before modifying anything shared, name its consumers. Unable to name them, look harder first.
- **A bug is existing behavior that is wrong; missing infrastructure is behavior that does not exist yet.** Report gaps; never bridge them by degrading a component.

## Irreversibles

**A secret's contents never enter the conversation, a log, a commit, or another file.**

**Nothing is ever written under this root during a session that uses it**, nor to the top level of any root. Authoring this root is separate work, and Working under this root says how it is planned. Output lands in the working folder, in the directories that folder's own `AGENTS.md` declares. The one exception is what a tool installs for itself, per that tool's own contract, and some of that lands outside this root. **The complete list for tools is in `tools/AGENTS.md`; the gateway's is in `gateway/AGENTS.md`.** Neither is restated here, because a write inventory kept in two places goes stale in one of them, as the summary that used to stand in this sentence did, naming the Linux compatibility shims as a write outside this root after they had been moved inside the tool that builds them.

**Nothing is deleted or overwritten without naming what is being lost first.** Where a root's own `AGENTS.md` declares an archive home, a file is archived there before it is replaced; where none is declared, including in this root, the Archives rule of `standards/conventions.md` says where it goes instead.

## Precedence and routing

A workspace usually composes this root alongside an owning root and any context roots. They are peers on disk and not peers in process.

- **This root governs how work is done:** which skill or expert owns a task, what a deliverable must satisfy, which standards bind.
- **The owning root governs what the work is about and where it lands:** voice, about, design, domain routing, and filing.
- Read this root first, then the owning root, then context roots as the task needs.
- Where they conflict on **how** work is done, this root wins. Where they conflict on **facts, voice, or filing**, the owning root wins.
- Do not invent parallel rules in a workspace. If a rule seems missing, it is in the chain: find it rather than restating it.

Routing has two doors. An ask that names its output, a deliverable some skill's description in `skills/AGENTS.md` yields, enters at that skill, and the expert whose row in `experts/AGENTS.md` owns the skill is its gate: at the end, in a second context, before the output ships or the requester declines the review, unless that row places the gate elsewhere or says none runs after: a gate before the skill runs is the one reading this rule adds before a draft and the row says for which asks, and one on a change to a root has no decline, where every other is declined as a gate at the end is; where none runs after, the skill's own review job is the file's gate. Until a skill's owner is declared, the skill's own file names its gate. Where two experts own one skill, both gates run in that second context, in the order the skill's own file states. An ask that does not name its output enters at the expert whose row's description covers it, which sequences the skills the work needs. `experts/AGENTS.md` is the routing table: each expert's row lists the skills its `Owns:` line names, so a session routes from those rows before reading the skills index whole. Load the file you route to; naming it is not loading it. `tools/AGENTS.md` indexes the tools those primitives call, and says what a tool installs and when. `connectors/AGENTS.md` indexes the connectors the gateway loads. Where a classifier is attached, a further step can sit in front of this table for an ask that is not a named one, under the conditions `## Classifier` below states in full; where they do not hold, the table is read as it is.

The named ask **update root** (also "update this root", "check root", and "is this root current") enters `skills/Housekeeping/` against the owning root, which compares that root's `layout:` with C1 of `standards/user-root.md` and proposes a clause-cited plan. C1 owns what that comparison means and what it reports. **The plan is applied only on a separate approval**, per that skill: the ask buys the comparison and the proposal, never the change.

The named ask **set up connectors** (also "setup connectors" and "enable connectors") enters `skills/Set Up Connectors/`. It is the path for a new harness, a new machine, or a new OS user. It does not grant a vendor account; that remains Connect Account. The phrase "install connectors" routes here too and is not a tool `--install`; the gateway installs nothing.

The named ask **wrap up** enters `skills/Playbook Author/` and runs its Hand Off, which readies this session's Playbooks for the next one and owns what it commits and hands over.

This plugin is the base: a domain plugin loads beside it, may assume it is present, and references its primitives and standards rather than duplicating them, and nothing here references a domain plugin. Where a skill, expert or tool belongs is decided in this order. Whatever a skill, expert or tool here needs for the work its description already covers belongs here: a primitive it sequences, calls, owns or is gated by; one that sets up a connector it calls; and, for a change a skill here writes to a live system, one that answers a question the expert gating that change names and leaves open. Otherwise, one whose steps are a specialist practice's own, steps a person follows only while practising it, belongs outside this plugin, in a domain plugin. Otherwise, what is general belongs here, and what changes with a sector, in its steps and not merely its audience, belongs in the domain plugin. A connector ships here, beside the gateway that loads it, whichever plugin's work it serves.

## Classifier

A classifier is an optional first-party service the gateway serves when one is attached. Nothing here changes when none is: every step below has the primitive's own path as its else, and that path is what runs today.

**Named asks are not routed.** They stay the closed set this root already names, each handled before any call is made.

**The app puts an ask to `wiser.route.ask` only where the harness runs plugin hooks, a classifier is attached, and the session's binding names one owning root that does not refuse**, before the model starts, through `hooks/`. `hooks/AGENTS.md` states the binding and the remaining stops. A confident answer is the file to load. Where the ask names its output, the routed file is confirmed to yield that output before it is loaded, and an ask is never diverted to a file that does not. Otherwise, and on a harness with no hooks, the table is read as today and the model does not make this call.

**Which primitives may put a judgment to the classifier is `standards/primitives.md` Invocation's.** Where one does, the answer is data rather than the primitive's judgment, and it is taken only as the typed file that asks for it says: against the threshold that file names, or by the acceptance test that file writes for an answer that carries none. A tool's output says which path settled the judgment, as any tool result is data. `needs_subscription`, `unavailable`, and an answer the file does not accept are each the primitive's own step, as that primitive writes it.

**Where the owning root declares the refusal, nothing is sent.** A session that has resolved that root as owning sends nothing to a classifier, the routing ask included, and routing reads the table as today.

## Standards

`standards/` is binding on work in this root, not advisory.

| Standard | Owns |
|----------|------|
| `standards/primitives.md` | The four primitive types, how they invoke one another, the typed-file frontmatter, and the classifier seam a new typed file declares, and any file whose seam changes |
| `standards/instruction-quality.md` | How instructions are written and judged; the sole home of Elegance |
| `standards/conventions.md` | Formatting, dates, naming, working files, root layout, archives, sourcing, evidence labels |
| `standards/play.md` | The Play format |
| `standards/playbook.md` | The Playbook format |
| `standards/script-contract.md` | What every script a tool ships must do, and the clauses that bind a connector module; a user reads `tools/RUNNING.md` |
| `standards/user-root.md` | The declared user-root tree, the clauses that score it, and the root contract version C1 owns |
| `standards/plugin-root.md` | The declared plugin-root tree, base or domain, the clauses that score it, and the current tree version C1 owns |

Each family's `AGENTS.md` carries an index of that family, maintained by hand (`standards/primitives.md`).

## What this root does not carry

Stated here so a reader is not left hunting for it. This root ships skills, experts, tools, a local gateway, and the connectors under `connectors/`. A primitive that still names a service this release does not ship, or a grant that is not connected, says so at the step and declares the lost capability in its `gaps` frontmatter. **`system/GAPS.md` collects every declared gap in one place.** Account access is the gateway; the named ask **set up connectors** is how a person attaches it on a new harness or machine. `gateway/SETUP.md` is the recipe that skill prints from.

## Working under this root

Work that changes this root is planned as a Playbook, per `standards/playbook.md`.

`system/templates/` holds the root templates a new working folder is created from, and `skills/Onboard Root/` is what reads them. Everything under `system/templates/` is inert: a template's `AGENTS.md` and declarations belong to the copy it will become, not to this chain.
