/**
 * Endpoint paths below omit the vendor's `/v3` segment on purpose.
 *
 * The proxy resolves a relative endpoint against the toolkit's configured base
 * URL, and this toolkit's base already ends in `/v3`. Proved live 2026-09-19
 * against the vendor's own envelope: `/v3/appendix/user_data` returned the
 * vendor's `40400 Not Found` (the doubled segment), while `/appendix/user_data`
 * reached a real route and was answered by the vendor's auth layer. The same
 * pair held for `dataforseo_labs/locations_and_languages`. `cloudflare` ships
 * the identical shape, sending `/zones/...` against a base carrying
 * `/client/v4`. Do not restore the prefix to match the vendor's docs URLs; the
 * docs give the full URL, this field gives only the tail.
 *
 * An absolute URL is not the alternative: the proxy accepts one but does not
 * inject the toolkit's credentials into it, so it returns the vendor's 401.
 */
async function proxyData(ctx, request) {
  const res = await ctx.proxy(request);
  return res && typeof res === 'object' && Object.hasOwn(res, 'data') ? res.data : res;
}

function invalidArguments(field) {
  return { status: 'invalid_arguments', field };
}

function extraKey(input, allowed) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return invalidArguments('input');
  const extra = Object.keys(input).find((key) => !allowed.includes(key));
  return extra === undefined ? null : invalidArguments(extra);
}

function isNonEmptyString(value, max) {
  if (typeof value !== 'string' || !value.trim()) return false;
  // Code points, not UTF-16 code units, because that is what the published maxLength
  // means. `standards/script-contract.md` Published input schema states the rule; this
  // counted `value.length` until 2026-09-20 and refused a 351-emoji keyword the
  // manifest's maxLength of 700 admits.
  if (max !== undefined && [...value].length > max) return false;
  return true;
}

function isBareDomain(value) {
  return typeof value === 'string' && value.trim() !== '' && !value.includes('://') && !value.includes('/');
}

function isAbsHttpUrl(value) {
  if (typeof value !== 'string' || !value.trim()) return false;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function isBacklinksTarget(value) {
  if (typeof value !== 'string' || !value.trim()) return false;
  if (value.includes('://')) return isAbsHttpUrl(value);
  return !value.includes(' ');
}

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const ORDER_BY = /^[a-z_.]+,(asc|desc)$/;
const ITEM_TYPES = new Set(['organic', 'paid', 'featured_snippet', 'local_pack']);
const BACKLINKS_STATUS = new Set(['all', 'live', 'lost']);

function firstInvalid(checks) {
  for (const check of checks) {
    if (check) return check;
  }
  return null;
}

function requireLocation(input) {
  const hasCode = Object.hasOwn(input, 'location_code');
  const hasName = Object.hasOwn(input, 'location_name');
  if (hasCode === hasName) return invalidArguments(hasCode ? 'location_name' : 'location_code');
  if (hasCode && !Number.isInteger(input.location_code)) return invalidArguments('location_code');
  if (hasName && !isNonEmptyString(input.location_name)) return invalidArguments('location_name');
  return null;
}

function optionalLocation(input) {
  const hasCode = Object.hasOwn(input, 'location_code');
  const hasName = Object.hasOwn(input, 'location_name');
  if (hasCode && hasName) return invalidArguments('location_name');
  if (hasCode && !Number.isInteger(input.location_code)) return invalidArguments('location_code');
  if (hasName && !isNonEmptyString(input.location_name)) return invalidArguments('location_name');
  return null;
}

function requireLanguage(input) {
  const hasCode = Object.hasOwn(input, 'language_code');
  const hasName = Object.hasOwn(input, 'language_name');
  if (hasCode === hasName) return invalidArguments(hasCode ? 'language_name' : 'language_code');
  if (hasCode && !isNonEmptyString(input.language_code)) return invalidArguments('language_code');
  if (hasName && !isNonEmptyString(input.language_name)) return invalidArguments('language_name');
  return null;
}

function optionalLanguage(input) {
  const hasCode = Object.hasOwn(input, 'language_code');
  const hasName = Object.hasOwn(input, 'language_name');
  if (hasCode && hasName) return invalidArguments('language_name');
  if (hasCode && !isNonEmptyString(input.language_code)) return invalidArguments('language_code');
  if (hasName && !isNonEmptyString(input.language_name)) return invalidArguments('language_name');
  return null;
}

function optionalBoolean(input, field) {
  if (!Object.hasOwn(input, field)) return null;
  return typeof input[field] === 'boolean' ? null : invalidArguments(field);
}

function optionalLimit(input) {
  if (!Object.hasOwn(input, 'limit')) return null;
  return Number.isInteger(input.limit) && input.limit >= 1 && input.limit <= 1000 ? null : invalidArguments('limit');
}

function optionalOffset(input) {
  if (!Object.hasOwn(input, 'offset')) return null;
  return Number.isInteger(input.offset) && input.offset >= 0 ? null : invalidArguments('offset');
}

const FILTER_OPERATORS = new Set([
  'regex', 'not_regex', '<', '<=', '>', '>=', '=', '<>',
  'in', 'not_in', 'match', 'not_match', 'ilike', 'not_ilike',
  'like', 'not_like', 'has', 'has_not',
]);

const SERP_OPERATOR_TOKENS = [
  'allinanchor:', 'allintext:', 'allintitle:', 'allinurl:',
  'cache:', 'define:', 'definition:', 'filetype:', 'id:',
  'inanchor:', 'info:', 'intext:', 'intitle:', 'inurl:',
  'link:', 'site:',
];

function keywordHasSerpOperator(keyword) {
  const texts = [String(keyword).toLowerCase()];
  try {
    texts.push(decodeURIComponent(keyword).toLowerCase());
  } catch {
    // One round of URL decoding; a malformed escape is checked as given.
  }
  return texts.some((text) => SERP_OPERATOR_TOKENS.some((token) => text.includes(token)));
}

const ARRAY_OPERAND = new Set(['in', 'not_in']);
const STRING_OPERAND = new Set(['regex', 'not_regex', 'match', 'not_match', 'ilike', 'not_ilike', 'like', 'not_like']);
const FILTER_STRING_MAX = 1000;

function isFilterOperand(operator, operand) {
  if (ARRAY_OPERAND.has(operator)) {
    return Array.isArray(operand) && operand.length >= 1 && operand.every((item) => typeof item === 'string' || typeof item === 'number');
  }
  if (STRING_OPERAND.has(operator)) return typeof operand === 'string' && operand.length >= 1 && operand.length <= FILTER_STRING_MAX;
  if (operator === 'has' || operator === 'has_not') return typeof operand === 'string' || typeof operand === 'number';
  return (typeof operand === 'string' && operand.length <= FILTER_STRING_MAX) || typeof operand === 'number' || typeof operand === 'boolean' || operand === null;
}

function isFilterCondition(value) {
  return (
    Array.isArray(value) &&
    value.length === 3 &&
    isNonEmptyString(value[0]) &&
    typeof value[1] === 'string' &&
    FILTER_OPERATORS.has(value[1]) &&
    isFilterOperand(value[1], value[2])
  );
}

function isFilterLogical(value) {
  return value === 'and' || value === 'or';
}

function countFilterConditions(value) {
  if (isFilterCondition(value)) return 1;
  if (!Array.isArray(value)) return 0;
  let count = 0;
  for (let index = 0; index < value.length; index += 2) {
    count += countFilterConditions(value[index]);
  }
  return count;
}

function isFilterExpression(value) {
  if (isFilterCondition(value)) return true;
  if (!Array.isArray(value) || value.length === 0 || value.length % 2 === 0) return false;
  if (typeof value[0] === 'string') return false;
  for (let index = 0; index < value.length; index += 1) {
    if (index % 2 === 1) {
      if (!isFilterLogical(value[index])) return false;
    } else if (!isFilterExpression(value[index])) {
      return false;
    }
  }
  return true;
}

function optionalFilters(input) {
  if (!Object.hasOwn(input, 'filters')) return null;
  const value = input.filters;
  if (!isFilterExpression(value)) return invalidArguments('filters');
  if (countFilterConditions(value) > 8) return invalidArguments('filters');
  return null;
}

function optionalOrderBy(input) {
  if (!Object.hasOwn(input, 'order_by')) return null;
  const value = input.order_by;
  if (!Array.isArray(value) || value.length > 3) return invalidArguments('order_by');
  return value.every((item) => typeof item === 'string' && ORDER_BY.test(item))
    ? null
    : invalidArguments('order_by');
}

function requireKeywords(input, { max, itemMax } = {}) {
  const value = input.keywords;
  if (!Array.isArray(value) || value.length < 1 || value.length > max) return invalidArguments('keywords');
  if (!value.every((item) => isNonEmptyString(item, itemMax))) return invalidArguments('keywords');
  return null;
}

function optionalDate(input, field) {
  if (!Object.hasOwn(input, field)) return null;
  return typeof input[field] === 'string' && DATE.test(input[field]) ? null : invalidArguments(field);
}

function taskFrom(input, keys) {
  const task = {};
  for (const key of keys) {
    if (Object.hasOwn(input, key)) task[key] = input[key];
  }
  return task;
}

async function postTask(ctx, endpoint, task) {
  return proxyData(ctx, { endpoint, method: 'POST', body: [task] });
}

function livePost(endpoint, allowed, validate) {
  return async (input, ctx) => {
    const extra = extraKey(input, allowed);
    if (extra) return extra;
    const invalid = validate(input);
    if (invalid) return invalid;
    return postTask(ctx, endpoint, taskFrom(input, allowed));
  };
}

const LOCATION_LANGUAGE = ['location_code', 'location_name', 'language_code', 'language_name'];
const PAGE = ['limit', 'offset', 'filters', 'order_by'];

export const modules = {
  research: {
    serp: livePost(
      '/serp/google/organic/live/advanced',
      ['keyword', ...LOCATION_LANGUAGE, 'device', 'depth'],
      (input) => firstInvalid([
        isNonEmptyString(input.keyword, 700) ? null : invalidArguments('keyword'),
        keywordHasSerpOperator(input.keyword) ? invalidArguments('keyword') : null,
        requireLocation(input),
        requireLanguage(input),
        Object.hasOwn(input, 'device') && !['desktop', 'mobile'].includes(input.device)
          ? invalidArguments('device')
          : null,
        Object.hasOwn(input, 'depth') && !(
          Number.isInteger(input.depth) &&
          input.depth >= 10 &&
          input.depth <= 200 &&
          input.depth % 10 === 0
        )
          ? invalidArguments('depth')
          : null,
      ]),
    ),
    keyword_ideas: livePost(
      '/dataforseo_labs/google/keyword_ideas/live',
      ['keywords', ...LOCATION_LANGUAGE, 'limit', 'offset', 'include_serp_info', 'filters', 'order_by', 'closely_variants'],
      (input) => firstInvalid([
        requireKeywords(input, { max: 200 }),
        requireLocation(input),
        requireLanguage(input),
        optionalLimit(input),
        optionalOffset(input),
        optionalBoolean(input, 'include_serp_info'),
        optionalFilters(input),
        optionalOrderBy(input),
        optionalBoolean(input, 'closely_variants'),
      ]),
    ),
    related_keywords: livePost(
      '/dataforseo_labs/google/related_keywords/live',
      ['keyword', ...LOCATION_LANGUAGE, 'depth', 'limit', 'offset', 'filters', 'order_by', 'include_serp_info'],
      (input) => firstInvalid([
        isNonEmptyString(input.keyword) ? null : invalidArguments('keyword'),
        requireLocation(input),
        requireLanguage(input),
        Object.hasOwn(input, 'depth') && !(Number.isInteger(input.depth) && input.depth >= 0 && input.depth <= 4)
          ? invalidArguments('depth')
          : null,
        optionalLimit(input),
        optionalOffset(input),
        optionalFilters(input),
        optionalOrderBy(input),
        optionalBoolean(input, 'include_serp_info'),
      ]),
    ),
    search_volume: livePost(
      '/keywords_data/google_ads/search_volume/live',
      ['keywords', ...LOCATION_LANGUAGE, 'date_from', 'date_to', 'search_partners'],
      (input) => firstInvalid([
        requireKeywords(input, { max: 1000, itemMax: 80 }),
        optionalLocation(input),
        optionalLanguage(input),
        optionalDate(input, 'date_from'),
        optionalDate(input, 'date_to'),
        optionalBoolean(input, 'search_partners'),
      ]),
    ),
    keyword_difficulty: livePost(
      '/dataforseo_labs/google/bulk_keyword_difficulty/live',
      ['keywords', ...LOCATION_LANGUAGE],
      (input) => firstInvalid([
        requireKeywords(input, { max: 1000 }),
        requireLocation(input),
        requireLanguage(input),
      ]),
    ),
    search_intent: livePost(
      '/dataforseo_labs/google/search_intent/live',
      ['keywords', 'language_code'],
      (input) => firstInvalid([
        requireKeywords(input, { max: 1000 }),
        isNonEmptyString(input.language_code) ? null : invalidArguments('language_code'),
      ]),
    ),
    ranked_keywords: livePost(
      '/dataforseo_labs/google/ranked_keywords/live',
      ['target', ...LOCATION_LANGUAGE, ...PAGE, 'item_types', 'load_rank_absolute'],
      (input) => firstInvalid([
        isBareDomain(input.target) ? null : invalidArguments('target'),
        requireLocation(input),
        requireLanguage(input),
        optionalLimit(input),
        optionalOffset(input),
        optionalFilters(input),
        optionalOrderBy(input),
        Object.hasOwn(input, 'item_types') && !(
          Array.isArray(input.item_types) &&
          input.item_types.every((item) => typeof item === 'string' && ITEM_TYPES.has(item))
        )
          ? invalidArguments('item_types')
          : null,
        optionalBoolean(input, 'load_rank_absolute'),
      ]),
    ),
    competitors: livePost(
      '/dataforseo_labs/google/competitors_domain/live',
      ['target', ...LOCATION_LANGUAGE, 'limit', 'offset', 'filters', 'exclude_top_domains', 'intersecting_domains'],
      (input) => firstInvalid([
        isBareDomain(input.target) ? null : invalidArguments('target'),
        requireLocation(input),
        requireLanguage(input),
        optionalLimit(input),
        optionalOffset(input),
        optionalFilters(input),
        optionalBoolean(input, 'exclude_top_domains'),
        Object.hasOwn(input, 'intersecting_domains') && !(
          Array.isArray(input.intersecting_domains) &&
          input.intersecting_domains.length <= 20 &&
          input.intersecting_domains.every(isBareDomain)
        )
          ? invalidArguments('intersecting_domains')
          : null,
      ]),
    ),
    async locations(input, ctx) {
      const extra = extraKey(input, ['country']);
      if (extra) return extra;
      if (Object.hasOwn(input, 'country') && (typeof input.country !== 'string' || !/^[A-Za-z]{2}$/.test(input.country))) {
        return invalidArguments('country');
      }
      const data = await proxyData(ctx, {
        endpoint: '/dataforseo_labs/locations_and_languages',
        method: 'GET',
      });
      if (!Object.hasOwn(input, 'country')) return data;
      if (!data || typeof data !== 'object' || !Array.isArray(data.tasks)) return data;
      const needle = input.country.toLowerCase();
      return {
        ...data,
        tasks: data.tasks.map((task, index) => {
          if (index !== 0 || !task || typeof task !== 'object' || !Array.isArray(task.result)) return task;
          return {
            ...task,
            result: task.result.filter((row) => String(row?.country_iso_code ?? '').toLowerCase() === needle),
          };
        }),
      };
    },
  },
  backlinks: {
    summary: livePost(
      '/backlinks/summary/live',
      ['target', 'include_subdomains', 'backlinks_status_type'],
      (input) => firstInvalid([
        isBacklinksTarget(input.target) ? null : invalidArguments('target'),
        optionalBoolean(input, 'include_subdomains'),
        Object.hasOwn(input, 'backlinks_status_type') && !BACKLINKS_STATUS.has(input.backlinks_status_type)
          ? invalidArguments('backlinks_status_type')
          : null,
      ]),
    ),
    referring_domains: livePost(
      '/backlinks/referring_domains/live',
      ['target', ...PAGE, 'include_subdomains', 'backlinks_status_type'],
      (input) => firstInvalid([
        isBacklinksTarget(input.target) ? null : invalidArguments('target'),
        optionalLimit(input),
        optionalOffset(input),
        optionalFilters(input),
        optionalOrderBy(input),
        optionalBoolean(input, 'include_subdomains'),
        Object.hasOwn(input, 'backlinks_status_type') && !BACKLINKS_STATUS.has(input.backlinks_status_type)
          ? invalidArguments('backlinks_status_type')
          : null,
      ]),
    ),
    anchors: livePost(
      '/backlinks/anchors/live',
      ['target', ...PAGE, 'backlinks_status_type'],
      (input) => firstInvalid([
        isBacklinksTarget(input.target) ? null : invalidArguments('target'),
        optionalLimit(input),
        optionalOffset(input),
        optionalFilters(input),
        optionalOrderBy(input),
        Object.hasOwn(input, 'backlinks_status_type') && !BACKLINKS_STATUS.has(input.backlinks_status_type)
          ? invalidArguments('backlinks_status_type')
          : null,
      ]),
    ),
  },
};
