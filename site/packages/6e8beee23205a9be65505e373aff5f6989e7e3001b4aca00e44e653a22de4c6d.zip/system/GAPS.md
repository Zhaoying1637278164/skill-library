# Gaps

What this plugin does not do, declared by the primitive that names it.

A gap is a capability this root does not provide that a primitive's own body names as missing (`standards/primitives.md`). This file collects every declared `gaps` entry, by hand, and is corrected whenever a primitive's gaps change.

**This file carries capability gaps only.** What the operator plans to build is a separate record and is not a user's business, so nothing about future work appears here. **A gap names the capability that is missing, never where that capability went.**

Counted 2026-09-24: 36 gaps across 23 primitives. Bullet count: `/usr/bin/grep -E '^- ' wiser/system/GAPS.md | wc -l` returns 36, and the same count derived from the primitives' own `gaps:` frontmatter returns 36. Verify each bullet against its primitive's frontmatter in both directions.

Seven were removed on 2026-09-20 because the capability had shipped and the declaration outlived it: `page-speed readings` on Conversion Advisor and Webmaster, now `google-apis.insights.run`; `keyword research` and `keyword and backlink data source` on Webmaster and `keyword research` on SEO Assets, now `connectors/dataforseo/`; and `automated site crawling` on Webmaster and SEO Assets, now `tools/site-crawl/`. Each primitive's body said the same thing and was corrected with it, which is the half that changes behaviour: an expert that declares a reading absent declines to fetch one it can get.

## Experts

### Knowledge Expert

- hosted-unspecified, so hosted lookup, ingest and export stop before a source is read
- a stated meaning for each typed relation, so a stored link cannot be checked against what its type claims

### IT Expert

- a security review of an infrastructure change, which this expert names as a question and does not answer

### Research Expert

- primary research, the interviews, surveys and experiments no primitive in this root performs

### Ghost Writer

- news-desk judgment on a piece written for a journalist, whether it is a story and what a desk would need from it
- crisis judgment on a piece written during an unfolding incident

### Marketing Strategist

- earned media strategy, reporter targeting, and whether something is a story
- crisis communications judgment

## Skills

### Knowledge Curation

- hosted-unspecified, so hosted lookup, ingest and export stop before a source is read

### Content Author

- recorded script for podcast, video, or voice-over
- news-desk judgment on a press piece, whether it is a story and what a desk would need from it
- crisis judgment on a statement or Q&A issued during an unfolding incident
- whether a story is worth pitching, and to whom

### Designer

- application screen assembly (dashboard, settings, admin panel)
- brand mark and logo creation

### Funnel Design

- earned media judgment, whether something is a story and who to pitch it to

### Knowledge Recall

- hosted-unspecified, so hosted lookup, ingest and export stop before a source is read

- temporal filtering of recall by a date, so an as-of question is answered from the facts the set dates rather than filtered by the engine

### Knowledge Set Onboarding

- hosted-unspecified, so hosted lookup, ingest and export stop before a source is read


### Marketing Page Design

- news judgment, whether an announcement is a story at all

### Media Generator

- judgment of a generated clip's motion, which no expert in this root carries; the clip is judged by its still frame

### Onboard Root

- judgment on whether a recorded competitor set names a competitor rather than describing one

### Playbook Author

- the trade-offs beside a recommendation at a session stop, so an open decision is put with one course and its reason rather than with the alternatives weighed
- a starting prompt delivered without being asked for, so a cold resume is assembled by hand wherever the wrap up is declined

### Proposal Author

- news-desk and targeting judgment on a pitch written for a journalist

### Site Author

- a site whose engine is not the shipped kit
- application, authenticated, or database-backed sites
- creating a nested git repository for the site

### Speech Writing

- crisis judgment on remarks delivered during an unfolding incident

### Typography Design

- right-to-left and CJK typography, which need script-specific knowledge this skill does not carry

### Vercel Deploy

- read or modify environment variables
- delete a Vercel project

### Zone Publisher

- Cloudflare redirect rules API (Page Rules successor / Rulesets)

## Tools

### knowledge-memory

- hosted-unspecified, so hosted lookup, ingest and export stop before a source is read

- temporal filtering of recall by a date, so an as-of question is answered from the facts the set dates rather than filtered by the engine

### Transcribe Audio

- Speaker labeling, which would say which speaker said each turn
