# Connecting {{SERVICE_TITLE}}

What you do, on which side, to make `{{SERVICE}}.*` actions run. The Connect Account skill walks this in its own turn; this file is what it reads.

## On the platform's side, first

Only if the platform needs something prepared before the grant: an API token made with named permissions, an application approved by an organisation owner, a plan that includes API access. Numbered steps, in the platform's own vocabulary, ending with the narrowest grant that serves this module. If nothing needs preparing, say "Nothing to prepare" and why.

**If you mention a blueprint here, carry this sentence verbatim**, from
`connectors/shared-text.md`, which says why it is worded exactly this way and what it cost to
learn. Say more after it if this connector needs it; do not state the rule differently.

> **One blueprint per toolkit, not per module**, and for a toolkit the provider already ships there is nothing to prepare: the gateway creates the blueprint on the first connect that finds none. A second blueprint on one toolkit makes every module on that toolkit unconnectable until it is removed, with a `vendor_error` naming the toolkit and the count.

## Through the gateway

1. Say "Connect {{SERVICE_TITLE}}" and name the module.
2. The skill runs `start_connect` and hands you a link, or a file path if this connector uses the local-file provider.
3. For a link: open it in your own browser and approve at the platform, or paste the token into the provider's hosted page. For a file: write the named variables into that file yourself. In neither case does anything get typed into the conversation, and a skill that asks for that is wrong.
4. The skill runs `connect_status`. On `ACTIVE`, the gateway writes a connection record and the module's actions run from then on.

## The other route

This template covers both: a hosted link (`catalog`) and a bound file (`local-file`). Keep the steps for the one this connector uses. Rewrite this heading as "The route this connector does not use" and name the unused path, so a person is not offered it. A personal token in chat is never a route. The GitHub connector is the worked example.

## Revoking

**This section is a projection of `connectors/shared-text.md`, and the only thing you edit in it
is the slot.** Every shipped guide on the `catalog` route carries this text byte for byte;
`gateway/test/guide-conformance.test.js` fails when one diverges. Replace `{VENDOR ROUTE}` with
one to three sentences saying what a person does at this vendor to revoke or rotate the
credential, ending in a period, and change nothing else. A rule that applies to every connector
belongs in the source, not here.

**Revoke through the gateway.** `disconnect`, with this service and any of its modules, revokes the credential at the provider and removes every local record of it.

- **It ends every module bound to that credential and not only the one you name.** It stops first and lists them in `modules_ending`. **That list is what you approve**: if anything else is bound to the credential before you answer, nothing is revoked and it stops again with the new list. The answer reports what was actually removed.
- **If someone wants one of those modules kept, their request cannot be met as asked, and saying so is the answer.** The credential is the unit; there is no way to end part of one. Two routes work. Either agree that both end, or first connect the module they want kept on a credential of its own, `start_connect` for that service and module and then `connect_status`, and only then run `disconnect`, **naming a module still on the old credential**, checking that `modules_ending` no longer lists the one you moved. **Do not approve the teardown hoping it spares one**, and do not take the vendor route instead, which is broader rather than narrower.
- **The vendor route below does not reach the same set, and may reach further.** `disconnect` acts on one provider account, and that account is what defines its scope; `modules_ending` reports the local bindings known to it when it asks. Rolling or deleting a credential at the vendor acts on everything that credential authorises, which can include modules bound to a different provider account, other machines, and other people. **`modules_ending` does not describe the vendor route**; before taking it, work out what else uses that credential.
- **It acts on one credential.** A service connected more than once needs one `disconnect` per credential. **`list_connections` shows what this machine has recorded and nothing more**: it cannot establish that no credential for this service remains at the provider, because discovery lists only ACTIVE accounts, skips a toolkit holding more than one, and fetches a single page. To be sure a service is gone, check at the vendor. Do not read one teardown, or an empty listing, as removing a service entirely.
- **Revoking is not scoped to this workspace.** The credential lives at the provider, and the store is per person rather than per workspace, so ending it can end access from another machine or another workspace using the same grant. Settle that before approving.
- **It removes nothing locally unless the provider confirms the credential is gone**, so a grant that is merely suspended keeps its records.
- **A finished teardown says what it established, in `credential_revoked`.** `yes` means every step the provider reported succeeded. **`unknown` means the provider's record of the credential is gone and an earlier step failed**, so the credential may still work at the vendor even though nothing here points at it any more. Removing the local rows is right either way; **`unknown` is not a completed cutoff**, and the vendor route below is what finishes it.

**At the vendor instead**, if you would rather, or if `disconnect` answers `needs_provider_capability`, meaning this provider will not revoke this credential for you. {VENDOR ROUTE} Afterwards run `connect_status` for each module you revoked and read what it returns: it asks the provider and records the answer, so the row stops reading ACTIVE only once the provider agrees, and a provider error leaves it unchanged. A `how` field on the gateway's answer is the adapter's own words; where it names a route this guide does not list, the two disagree and that is worth reporting rather than following.

**If this connector uses the `local-file` provider, delete everything above and say so instead.**
That adapter holds no grant, always refuses `revoke`, and never reports `ABSENT`, so `disconnect`
cannot take its credential down and no record of it is ever removed. `connectors/usebouncer/auth.md`
is the worked example, and the gate exempts a connector serving no `catalog` module by reading its
manifest. Promising a gateway teardown a connector cannot perform is the defect this template
exists to prevent.

## Last connected

Not yet.

This section records only whether a connect has ever succeeded, as `Yes.` or `Not yet.`
**Do not record a date, an account, a machine, a harness, a decision, or a vendor response
here.** That is build evidence and it belongs in this repo's build workspace, not in a
guide a stranger installs from. A decision not to connect is not a connect either, so the
answer stays `Not yet.` Decided 2026-09-20 after twenty of twenty-six shipped guides were
found carrying one operator's state.
