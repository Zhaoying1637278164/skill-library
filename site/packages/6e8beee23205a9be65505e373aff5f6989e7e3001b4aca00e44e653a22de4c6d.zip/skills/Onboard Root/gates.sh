#!/usr/bin/env bash
# gates.sh: the mechanical gate harness for the onboard-root revision.
#
# Contract: the gate table in full-path.md beside this script, and the personal
# path in SKILL.md. Where this script and that table disagree, the table is what
# gets fixed first.
#
# Runs on macOS bash 3.2. No associative arrays, no mapfile/readarray, no
# ${var,,}. BSD-compatible flags only. Never writes to the root being checked.
#
#   gates.sh <root path>              run every gate
#   gates.sh --gate G6 <root path>    run one gate
#   gates.sh --json <root path>       one JSON object per line, plus a summary
#   gates.sh --short <root path>      the personal-path file gates only; chosen on its
#                                     own for a personal root with no run record
#   gates.sh --list                   list the gates and exit
#
# Exit 0 only when every gate passes. Exit 1 when any gate fails or skips
# in a way that is not a pass. Exit 2 on a usage error.

set -u

PROG=$(basename "$0")
US=$(printf '\037')
LC_ALL=C
export LC_ALL

usage() {
  cat <<USAGE
usage: $PROG [--json] [--gate <id>] <root path>

  --gate <id>   run a single gate (G0 G1 G2 G3 G4 G5a G5b G5c G6 G6b G7 G8
                G9 G10 G11 G11b G12 G13 G13b G14 G15 G16 G17 G18 G19 G20 G21)
  --json        print one JSON object per gate, then a summary object
  --short       run the personal-path file gates only (automatic for a personal
                root that keeps no run record)
  --list        list the gates and exit
USAGE
}

# ---------------------------------------------------------------- arguments

JSON=0
SHORT=0
ONE_GATE=""
ROOT=""

while [ $# -gt 0 ]; do
  case "$1" in
    --json) JSON=1; shift ;;
    --short) SHORT=1; shift ;;
    --gate)
      if [ $# -lt 2 ]; then echo "$PROG: --gate needs an id" >&2; exit 2; fi
      ONE_GATE="$2"; shift 2 ;;
    --gate=*) ONE_GATE="${1#--gate=}"; shift ;;
    --list) LIST_ONLY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    --) shift; break ;;
    -*) echo "$PROG: unknown option $1" >&2; usage >&2; exit 2 ;;
    *)
      if [ -n "$ROOT" ]; then echo "$PROG: more than one root given" >&2; exit 2; fi
      ROOT="$1"; shift ;;
  esac
done

LIST_ONLY=${LIST_ONLY:-0}

# The gate registry. id|short name|function. Order is the run order.
GATES='G0|The substantive floor|gate_G0
G1|Scope recorded|gate_G1
G2|Extraction complete and duplicates proved|gate_G2
G3|Copy established|gate_G3
G4|Evidence packages are evidence|gate_G4
G5a|Read-back coverage|gate_G5a
G5b|Read-back disposition|gate_G5b
G5c|Negative claims enumerated|gate_G5c
G6|The forward gate|gate_G6
G6b|The forward gate coverage floor|gate_G6b
G7|Deferrals are named|gate_G7
G8|Exactness claims used a second mechanism|gate_G8
G9|Headings answered|gate_G9
G10|Registers used as defined|gate_G10
G11|Label vocabulary is closed|gate_G11
G11b|Figure tables carry their provenance|gate_G11b
G12|The interview covered its classes|gate_G12
G13|Traits are checkable|gate_G13
G13b|The routing table resolves the deliverables|gate_G13b
G14|Voice authority|gate_G14
G15|Audit ran independently|gate_G15
G16|Findings disposed of, disputes preserved|gate_G16
G17|The close is in the root|gate_G17
G18|No placeholder token survives|gate_G18
G19|Paths resolve|gate_G19
G20|Operating file and close report|gate_G20
G21|Layout stamp agrees with C1|gate_G21'

if [ "$LIST_ONLY" = "1" ]; then
  printf '%s\n' "$GATES" | awk -F'|' '{printf "%-5s %s\n", $1, $2}'
  exit 0
fi

if [ -z "$ROOT" ]; then usage >&2; exit 2; fi
if [ ! -d "$ROOT" ]; then
  echo "$PROG: root not a directory: $ROOT" >&2
  exit 2
fi
# Strip a trailing slash so rel() is stable.
case "$ROOT" in
  */) ROOT="${ROOT%/}" ;;
esac

# Resolve the root once here rather than inside under_root, which several
# callers invoke inside command substitutions and pipelines: a value assigned
# in a subshell dies with it, so the root was resolved again on every call.
# under_root keeps its own guard, so a root that cannot be entered still
# refuses there with the same reason.
ROOT_PHYS=$(CDPATH= cd -P "$ROOT" 2>/dev/null && pwd -P) || ROOT_PHYS=""

TMPD=$(mktemp -d "${TMPDIR:-/tmp}/gates.XXXXXX") || exit 2
trap 'rm -rf "$TMPD"' EXIT INT TERM

# ---------------------------------------------------------------- the tree

# standards/user-root.md C10 fixes records for every type. Type controls close intensity.
ROOT_TYPE=""
if [ -f "$ROOT/AGENTS.md" ]; then
  ROOT_TYPE=$(awk 'NR==1 && $0!="---" {exit} NR>1 && $0=="---" {exit} /^type:[[:space:]]/ {sub(/^type:[[:space:]]*/,""); sub(/[[:space:]]+$/,""); print; exit}' "$ROOT/AGENTS.md")
fi
[ -n "$ROOT_TYPE" ] || ROOT_TYPE=unknown

case "$ROOT_TYPE" in
  personal|org|client|department|industry)
    ONB="$ROOT/work/onboarding"
    RUNREC="$ONB/run-record.md"
    VERIF="$ONB/verification.md"
    AUDIT="$ONB/audit.md"
    OPER="$ONB/operating-file.md"
    CLOSE="$ONB/close-report.md"
    EXTRACT_DIR="$ONB/extraction"
    EVID_DIR="$ONB/evidence"
    SRC_DIR="$ROOT/sources"
    ;;
  *)
    # Only `--gate G21` reports a missing declaration as SKIP. A full-suite
    # run, or any other `--gate`, still requires a recognized type and never
    # runs other gates on an unidentified root.
    if [ "$ONE_GATE" != "G21" ]; then
      echo "$PROG: $ROOT/AGENTS.md declares no recognized type: (personal, org, client, department, industry)" >&2
      echo "$PROG: a root is identified by its declaration, never by its folder name; fix the declaration and re-run" >&2
      exit 2
    fi
    ;;
esac


rel() {
  case "$1" in
    "$ROOT"/*) printf '%s' "${1#$ROOT/}" ;;
    *) printf '%s' "$1" ;;
  esac
}

# Count of supplied documents. A run with none is the research-first, nothing-
# handed-over case, where extraction records cannot exist and the three gates
# that read them have nothing to be true or false about. The Tier section
# already settled how to report that: a gate that does not apply records why
# and passes, because a skip is not a pass and a correct root that can never
# exit clean from its own harness teaches the implementer to stop running it.
# The distinction that matters: no documents means not applicable, documents
# with no extraction records means failed.
source_count() {
  [ -d "$SRC_DIR" ] || { echo 0; return; }
  list_any "$SRC_DIR" 2>/dev/null | wc -l | tr -d ' '
}
MEM="$ROOT/memory"
SECRETS="$MEM/secrets"
AGENTS="$ROOT/AGENTS.md"

# ---------------------------------------------------------- the personal path
#
# A personal root onboarded on SKILL.md's personal path keeps no records: its
# `## Onboarding` section says which path ran and carries one state line per
# key. That root has nothing for the record gates to read, and a harness that
# failed it for records it was told not to keep would teach the user to stop
# running the harness. So the file gates run and the record gates do not.
# A personal root with no run record is on that path; --short says so
# explicitly. A run record present means the full path ran, and then the
# whole suite applies whatever the section says.
onb_section() {
  [ -f "$AGENTS" ] || return 0
  section_body "$AGENTS" "## Onboarding" 2>/dev/null
}
onb_state() {
  # $1 = key. The first word after `- <key>:` in the ## Onboarding section,
  # trailing punctuation stripped: `complete.` is complete.
  onb_section | grep -E "^[[:space:]]*-[[:space:]]*$1:" | head -1 \
    | sed -E "s/^[[:space:]]*-[[:space:]]*$1:[[:space:]]*//" | awk '{print $1}' | sed -E 's/[.,;:]+$//'
}
if [ "$SHORT" = "0" ] && [ "$ROOT_TYPE" = "personal" ] && [ ! -f "$RUNREC" ]; then
  SHORT=1
fi

if [ "$SHORT" = "1" ]; then
  if [ "$ROOT_TYPE" != "personal" ]; then
    echo "$PROG: the personal path is for a personal root; this root declares type $ROOT_TYPE" >&2
    exit 2
  fi
  if [ -f "$RUNREC" ]; then
    echo "$PROG: $(rel "$RUNREC") exists, so the full path ran; --short does not apply" >&2
    exit 2
  fi
  GATES='G9|Headings answered|gate_G9
G10|Registers used as defined|gate_G10
G11|Label vocabulary is closed|gate_G11
G11b|Figure tables carry their provenance|gate_G11b
G13|Traits are checkable|gate_G13
G13b|The routing table resolves the deliverables|gate_G13b
G14|Voice authority|gate_G14
G17|The close is in the root|gate_G17
G18|No placeholder token survives|gate_G18
G19|Paths resolve|gate_G19
G21|Layout stamp agrees with C1|gate_G21'
fi

# The subject's own name, read from the root declaration. G5a's proper-noun
# clause uses it: a sentence whose only proper noun is the subject itself is
# structural prose, not a claim about anything a deliverable would act on.
ROOTNAME=$(sed -n 's/^root:[[:space:]]*//p' "$AGENTS" 2>/dev/null | head -1)
[ -n "$ROOTNAME" ] || ROOTNAME=$(basename "$ROOT")

# A path a record names is content the run wrote, and a gate must not follow it
# out of the root: an absolute one, one that walks out with .., or one reached
# through symlinks whose final destination is outside, would have a gate read
# another root's file and take what it found as this root's evidence. Link-ness
# is not the test and neither is spelling: a link that stays inside the root is
# legitimate, a trailing slash hides a leaf from -L, and one hop is not the
# chain, so every hop is followed to the end and the destination is resolved
# before it is compared, because a textual prefix is not containment.
# Sets _ur_why to the reason on a refusal, so a caller can say which it was.
under_root() {
  _ur_why="leaves the root"
  case "$1" in "") _ur_why="is empty"; return 1 ;; /*) return 1 ;; esac
  _ur_p=$1
  while :; do case "$_ur_p" in */) _ur_p=${_ur_p%/} ;; *) break ;; esac; done
  [ -n "$_ur_p" ] || { _ur_why="is empty"; return 1; }
  [ -n "${ROOT_PHYS:-}" ] || ROOT_PHYS=$(CDPATH= cd -P "$ROOT" 2>/dev/null && pwd -P) || { _ur_why="cannot be resolved"; return 1; }
  _ur_root=$ROOT_PHYS
  if [ -d "$ROOT/$_ur_p" ]; then
    _ur_res=$(CDPATH= cd -P "$ROOT/$_ur_p" 2>/dev/null && pwd -P) || { _ur_why="cannot be resolved"; return 1; }
  else
    case "$_ur_p" in */*) _ur_par=${_ur_p%/*} ;; *) _ur_par=. ;; esac
    _ur_d=$(CDPATH= cd -P "$ROOT/$_ur_par" 2>/dev/null && pwd -P) || {
      # The parent does not exist or cannot be entered, so nothing can be
      # resolved and nothing can escape either: the caller's own existence
      # test is what reports it, and it reports it truthfully.
      return 0
    }
    _ur_res=$_ur_d/${_ur_p##*/}
    # Follow the whole chain, not one hop. A bound file linked to a link to a
    # file in another root was certified as contained by the single-hop form.
    # The counter ends a loop; forty is far past any legitimate depth.
    _ur_n=0
    while [ -L "$_ur_res" ]; do
      _ur_n=$((_ur_n + 1))
      if [ "$_ur_n" -gt 40 ]; then _ur_why="resolves through a symlink loop"; return 1; fi
      _ur_t=$(readlink "$_ur_res") || { _ur_why="cannot be resolved"; return 1; }
      case "$_ur_t" in
        /*) _ur_res=$_ur_t ;;
        *)  case "$_ur_t" in */*) _ur_tp=${_ur_t%/*} ;; *) _ur_tp=. ;; esac
            _ur_hd=$(CDPATH= cd -P "${_ur_res%/*}" 2>/dev/null && cd -P "$_ur_tp" 2>/dev/null && pwd -P) || { _ur_why="cannot be resolved"; return 1; }
            _ur_res=$_ur_hd/${_ur_t##*/} ;;
      esac
    done
  fi
  # Canonicalize before comparing. A textual prefix is not containment: an
  # absolute link target such as /root/../elsewhere/x.md begins with the root
  # and resolves outside it. Only the relative branch above walks its heads
  # through cd -P, so resolve the destination's own directory the same way.
  case "$_ur_res" in */*) _ur_rp=${_ur_res%/*} ;; *) _ur_rp=/ ;; esac
  [ -n "$_ur_rp" ] || _ur_rp=/
  _ur_rd=$(CDPATH= cd -P "$_ur_rp" 2>/dev/null && pwd -P) || { _ur_why="cannot be resolved"; return 1; }
  case "$_ur_rd" in */) _ur_res=$_ur_rd${_ur_res##*/} ;; *) _ur_res=$_ur_rd/${_ur_res##*/} ;; esac
  case "$_ur_res" in "$_ur_root"|"$_ur_root"/*) return 0 ;; *) _ur_why="leaves the root"; return 1 ;; esac
}

# md files in a collection directory, scaffolding excluded.
list_md() {
  [ -d "$1" ] || return 0
  find "$1" -type f -name '*.md' ! -name 'AGENTS.md' ! -name '.*' 2>/dev/null | sort
}

# every file in a source directory, scaffolding excluded.
list_any() {
  [ -d "$1" ] || return 0
  find "$1" -type f ! -name 'AGENTS.md' ! -name '.*' ! -name '.DS_Store' 2>/dev/null | sort
}

# bound files: the markdown files under memory/, never the credential store.
bound_files() {
  [ -d "$MEM" ] || return 0
  find "$MEM" -type f -name '*.md' 2>/dev/null | grep -v "^$MEM/secrets/" | sort
}

# ---------------------------------------------------------------- awk library

# Emit a bound file with its provenance-preamble lines blanked, line numbers
# preserved. The preamble documents the register, label and anchor grammars by
# writing them out literally, so any gate that greps a bound file for those
# grammars reads the documentation as content. G5a and G5c skipped it inline
# from the start; the first real root showed G10 did not, and reported the
# template's own `(Firsthand: <person who observed it>)` as a register naming
# no person, four times.
nonblank_count_stdin() {
  # grep -c prints its count and exits 1 when that count is zero. A `||`
  # fallback here appends a second number and every arithmetic test on the
  # result then errors. Assign, then default, which is what the rest of this
  # script does.
  _n=$(grep -c '[^[:space:]]' 2>/dev/null); [ -n "$_n" ] || _n=0; printf '%s' "$_n"
}

strip_preamble() {
  awk '
    /<!--[ \t]*provenance-preamble[ \t]*-->/ { inpre=1; print ""; next }
    /<!--[ \t]*\/provenance-preamble[ \t]*-->/ { inpre=0; print ""; next }
    { if (inpre) print ""; else print }
  ' "$1"
}

AWK_LIB='
function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
function isrow(line){ return (trim(line) ~ /^\|/) }
function is_sep(line,   t){
  t=trim(line)
  if(t !~ /^\|/) return 0
  if(t !~ /-/) return 0
  gsub(/[|: \t-]/,"",t)
  return (t=="")
}
function ncells(line, arr,   n,i){
  line=trim(line)
  sub(/^\|/,"",line); sub(/\|[ \t]*$/,"",line)
  n=split(line,arr,"|")
  for(i=1;i<=n;i++) arr[i]=trim(arr[i])
  return n
}
function slug(s,   t){
  t=tolower(s)
  gsub(/[^a-z0-9]+/,"-",t)
  gsub(/^-+/,"",t)
  gsub(/-+$/,"",t)
  return t
}
'

# table_get FILE SECTION "Col,Col,Col"
#   Prints one line per data row: lineno US v1 US v2 ...
#   SECTION is a "## " heading text, or "" for any table in the file.
#   The header row is matched by its column names, never by line number.
#   Exit 3 when no table in that section carries all the named columns.
table_get() {
  [ -f "$1" ] || return 4
  awk -v SEC="$2" -v COLS="$3" "$AWK_LIB"'
  BEGIN{ nc=split(COLS,want,","); US=sprintf("%c",31) }
  { L[NR]=$0 }
  END{
    sec=""; hdr=0; found=0
    for(i=1;i<=NR;i++){
      line=L[i]
      if(line ~ /^#+([ \t]|$)/){
        if(line ~ /^## /) sec=trim(substr(line,4))
        hdr=0
        continue
      }
      if(SEC!="" && sec!=SEC) continue
      if(hdr==0){
        if(isrow(line) && i<NR && is_sep(L[i+1])){
          m=ncells(line,c); split("",col,":")
          for(j=1;j<=m;j++) col[c[j]]=j
          ok=1
          for(j=1;j<=nc;j++) if(!(want[j] in col)) ok=0
          if(ok){ hdr=1; found=1; i++ }
        }
        continue
      }
      if(!isrow(line)){ hdr=0; continue }
      if(is_sep(line)) continue
      m=ncells(line,c)
      out=i
      for(j=1;j<=nc;j++){
        v=""
        if(col[want[j]]<=m) v=c[col[want[j]]]
        gsub(/\037/,"",v)
        out=out US v
      }
      print out
    }
    if(!found) exit 3
  }' "$1"
}

# section_body FILE "## Heading"  -> the lines under it, to the next heading
# of the same or higher level.
section_body() {
  [ -f "$1" ] || return 4
  awk -v H="$2" '
  function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
  BEGIN{ hl=0; while(substr(H,hl+1,1)=="#") hl++; inb=0 }
  {
    t=trim($0)
    if(t ~ /^#+([ \t]|$)/){
      l=0; while(substr(t,l+1,1)=="#") l++
      if(inb && l>hl){ print $0; next }
      if(inb) inb=0
      if(t==H){ inb=1 }
      next
    }
    if(inb) print $0
  }' "$1"
}

# has_heading FILE "## Heading"
has_heading() {
  [ -f "$1" ] || return 1
  awk -v H="$2" '
  function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
  { if(trim($0)==H){ found=1; exit } }
  END{ exit (found?0:1) }' "$1"
}

# kv FILE key  -> the value after the first "key:" line
kv() {
  [ -f "$1" ] || return 1
  awk -v K="$2" '
  function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
  {
    idx=index($0,":")
    if(idx>0){
      k=trim(substr($0,1,idx-1))
      if(k==K){ print trim(substr($0,idx+1)); exit }
    }
  }' "$1"
}

# has_key FILE key -> 0 when the key line is present at all
has_key() {
  [ -f "$1" ] || return 1
  awk -v K="$2" '
  function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
  {
    idx=index($0,":")
    if(idx>0 && trim(substr($0,1,idx-1))==K){ found=1; exit }
  }
  END{ exit (found?0:1) }' "$1"
}

nonblank_count() { awk 'NF{n++} END{print n+0}' "$1" 2>/dev/null || echo 0; }

# ---------------------------------------------------------------- reporting

G_FAILS=""
G_NOTES=""
G_SKIP=""

add_fail() { G_FAILS="${G_FAILS}$1
"; }
add_note() { G_NOTES="${G_NOTES}$1
"; }
set_skip() { G_SKIP="$1"; }

# missing_file FILE label -> 0 when present, else records a failure
need_file() {
  if [ -f "$1" ]; then return 0; fi
  add_fail "$(rel "$1"): missing (required by this gate)"
  return 1
}

json_escape() {
  # With an argument, escapes it. With none, escapes stdin. Multiple lines
  # are joined with "; ".
  if [ $# -gt 0 ]; then
    printf '%s' "$1" | _json_esc
  else
    _json_esc
  fi
}

_json_esc() {
  awk '
  BEGIN{ ORS="" }
  {
    s=$0
    gsub(/\\/,"\\\\",s)
    gsub(/"/,"\\\"",s)
    gsub(/\t/,"\\t",s)
    gsub(/\r/,"",s)
    if(NR>1) printf "; "
    printf "%s", s
  }'
}

# The owner's declared name, lower-cased, for the gates that accept it as a
# person regardless of its shape. Set here, after kv is defined.
OWNER_LC=$(kv "$AGENTS" "root" 2>/dev/null | tr 'A-Z' 'a-z')

PASS_N=0; FAIL_N=0; SKIP_N=0

report_gate() {
  gid="$1"; gname="$2"; status="$3"
  detail=""
  if [ "$status" = "fail" ]; then
    detail="$G_FAILS"
  elif [ "$status" = "skip" ]; then
    detail="$G_SKIP"
  else
    detail="$G_NOTES"
  fi
  if [ "$JSON" = "1" ]; then
    d=$(printf '%s' "$detail" | sed '/^$/d' | json_escape)
    printf '{"gate":"%s","status":"%s","name":"%s","detail":"%s"}\n' \
      "$gid" "$status" "$(printf '%s' "$gname" | json_escape)" "$d"
  else
    case "$status" in
      pass) printf 'PASS %-4s %s\n' "$gid" "$gname" ;;
      fail) printf 'FAIL %-4s %s\n' "$gid" "$gname" ;;
      skip) printf 'SKIP %-4s %s\n' "$gid" "$gname" ;;
    esac
    if [ "$status" = "fail" ]; then
      printf '%s' "$G_FAILS" | sed '/^$/d' | sed 's/^/       /'
    fi
    if [ "$status" = "skip" ]; then
      printf '%s\n' "$G_SKIP" | sed '/^$/d' | sed 's/^/       reason: /'
    fi
    if [ -n "$G_NOTES" ]; then
      printf '%s' "$G_NOTES" | sed '/^$/d' | sed 's/^/       note: /'
    fi
  fi
}

run_gate() {
  gid="$1"; gname="$2"; gfn="$3"
  G_FAILS=""; G_NOTES=""; G_SKIP=""
  "$gfn"
  if [ -n "$G_SKIP" ]; then
    status=skip; SKIP_N=$((SKIP_N+1))
  elif [ -n "$G_FAILS" ]; then
    status=fail; FAIL_N=$((FAIL_N+1))
  else
    status=pass; PASS_N=$((PASS_N+1))
  fi
  report_gate "$gid" "$gname" "$status"
}

# ================================================================ the gates

# ---- G0 The substantive floor -------------------------------------------
# Required classes per key, from gates.md. key;class,class,...
# `what-was-bought` is a commercial class and only a client root has bought
# anything. A personal root onboarding someone's own notes is not a purchased
# engagement, so the other four types owe `what-this-root-is-for` in its place.
# Round 4 of the pre-push gate found this table applied to every type.
if [ "$ROOT_TYPE" = "client" ]; then
  G0_ABOUT='what-was-bought,who-confirms,hard-constraints'
else
  G0_ABOUT='what-this-root-is-for,who-confirms,hard-constraints'
fi
G0_TABLE="about;$G0_ABOUT
voice;register-decision,register-confirmation
design;design-source
competitors;set,set-confirmed-by,set-date"

# The key lines this harness reads out of the run record, and the span the
# grammar declares each one in: G1's names in the key block above the first
# heading below title level, the vantages under `## Copy vantages`, the four
# close keys under `## Per-key close`.
#
# A duplicate is refused where a reader would resolve it wrongly, which is
# inside the span that declares it. Outside that span the same word is prose:
# an interview answered per domain is not a second `about`, and the confirmer's
# `name:` is not a second `name`, because kv takes the first line in the file
# and the declaration is above them both. Round 17 refused the first of those
# and round 18 was still refusing the second.
#
# Where the reader is file-scoped, the declaration being in its span is not
# enough: an earlier line elsewhere would be the one kv returns. That is
# checked by asking kv both ways and refusing a disagreement.
G1_KEYS='type name destination tier research-branch consent competitors-offer'
VANTAGE_KEYS='vantage-1 vantage-2'
PERKEY_KEYS='about voice design competitors'

perkey_value() {
  # $1 = key. Reads only the ## Per-key close section of run-record.md.
  [ -f "$RUNREC" ] || return 1
  strip_comments < "$RUNREC" > "$TMPD/runrec-plain.md" 2>/dev/null
  section_body "$TMPD/runrec-plain.md" "## Per-key close" > "$TMPD/perkey.txt" 2>/dev/null
  kv "$TMPD/perkey.txt" "$1"
}

claims_located_count() {
  # ONLY_FILE in the environment, optional: the only bound file that may satisfy
  # this class, set by the caller for the competitors key. A competitor set
  # recorded in another memory file is not recorded where downstream work
  # resolves the key, which is the whole of what this count is asked to prove.
  # $1 key, $2 class. A located row only counts when the claim actually
  # reached a bound file: it carries an anchor, names a bound file, and that
  # file contains that anchor. Counting rows alone let a key close complete on
  # detached bookkeeping while its headings said Not available.
  awk -v K="$1" -v C="$2" -v US="$US" '
  BEGIN{ n=0 }
  {
    split($0,f,US)
    if(f[2]!=K) next
    if(f[3]!=C) next
    if(f[4]!="located" && f[4]!="located-elsewhere-and-citation-corrected") next
    anch=f[5]; bf=f[6]
    if(anch=="" || anch=="-") next
    if(bf=="" || bf=="-") next
    print anch US bf
    n++
  }' "$TMPD/g0-claims.txt" | while IFS="$US" read -r anch bf; do
    [ -n "$anch" ] || continue
    id=$(printf '%s' "$anch" | tr -d '[]')
    bfp=$(printf '%s' "$bf" | tr -d '`' | sed 's#^\./##')
    case "$bfp" in
      # add_fail cannot be called from here: this loop is on the right of a pipe
      # inside a command substitution, so G_FAILS would be assigned in a subshell
      # and discarded twice over, which is the hazard the G13 comment below names.
      # The escape is written down and gate_G0 reports it after the counting.
      memory/*.md) under_root "$bfp" || { printf '%s|%s\n' "$bfp" "$_ur_why" >> "$TMPD/g0-escapes.txt"; continue; } ;;
      *) continue ;;                 # a bound file, not the record itself
    esac
    if [ -n "${ONLY_FILE:-}" ] && [ "$bfp" != "$ONLY_FILE" ]; then continue; fi
    [ -f "$ROOT/$bfp" ] || continue
    # An anchor inside a comment is not in the file as far as anything reading
    # it is concerned. A fenced one is visible text and counts: this check asks
    # whether the anchor is there, not whether it is a declaration.
    strip_comments < "$ROOT/$bfp" 2>/dev/null | grep -qF "[$id]" || continue
    printf 'x\n'
  done | wc -l | tr -d ' '
}

gate_G0() {
  need_file "$RUNREC" || return
  need_file "$VERIF" || return
  rm -f "$TMPD/g0-escapes.txt"
  if ! has_heading "$RUNREC" "## Per-key close"; then
    add_fail "$(rel "$RUNREC"): no '## Per-key close' section"
    return
  fi
  plain_file "$VERIF" "verification.md"
  plain_file "$AGENTS" "this root's AGENTS.md"
  if table_get "$VERIF" "Claims" "Key,Class,Outcome,Anchor,Bound file" > "$TMPD/g0-claims.txt" 2>/dev/null; then :; else
    add_fail "$(rel "$VERIF"): no '## Claims' table carrying the columns Key, Class, Outcome, Anchor, Bound file"
    return
  fi
  for _row in $(printf '%s\n' "$G0_TABLE" | awk -F';' '$1!="" { print $1 }'); do
    case " $PERKEY_KEYS " in
      *" $_row "*) ;;
      *) add_fail "gates.sh: required classes are listed for '$_row', which is not a close key; the two lists have drifted and those classes are checked on nothing" ;;
    esac
  done
  for key in $PERKEY_KEYS; do
    classes=$(printf '%s\n' "$G0_TABLE" | awk -F';' -v k="$key" '$1==k { print $2; exit }')
    if [ -z "$classes" ]; then
      add_fail "gates.sh: close key '$key' has no required classes; the two lists have drifted and this key is checked by nothing"
      continue
    fi
    val=$(perkey_value "$key")
    if [ -z "$val" ]; then
      # A key that was never offered has nothing to close. The competitors
      # offer is made for every client root, for an org root when the requester
      # wants a set on record, and for the other three when the requester asks,
      # so what decides is `competitors-offer` and not the type: a missing line
      # is the recorded answer only where that field reads `not-offered`. G1 still requires the
      # competitors-offer field itself to be present and non-empty.
      if [ "$key" = "competitors" ] && printf '%s' "$(kv "$RUNREC" "competitors-offer")" | grep -q '^not-offered'; then
        add_note "competitors: the offer was not made, so no per-key close line is owed"
        continue
      fi
      add_fail "$(rel "$RUNREC"): '## Per-key close' has no line for key '$key'"
      continue
    fi
    if [ "$key" = "competitors" ] && [ "$val" = "unbound" ]; then
      # Unbound is the answer to a declined or deferred offer. Where the offer
      # was accepted there is a set to record, so unbound would skip the
      # competitor classes on a key that owes them.
      case "$(kv "$RUNREC" "competitors-offer")" in
        not-now|no) add_note "competitors: unbound: the offer was declined or deferred, so the competitor classes are not applicable" ;;
        yes)        add_fail "$(rel "$RUNREC"): 'competitors-offer: yes' but the per-key close reads unbound; an accepted offer closes complete, provisional or blocked" ;;
        not-offered:*) add_fail "$(rel "$RUNREC"): the offer was never made, so no competitors line is owed; unbound is the answer to a declined offer" ;;
        *)          add_fail "$(rel "$RUNREC"): 'competitors: unbound' but competitors-offer does not record a declined or deferred offer" ;;
      esac
      continue
    fi
    [ "$val" = "complete" ] || continue
    if [ "$key" = "competitors" ]; then
      # A competitor set is only recorded where the key resolves. Anchors in
      # another memory file are not that, and neither is an unbound key.
      # Comments go from the whole file before the section is cut out, and both
      # readers of this section read the same stripped copy: stripping for one
      # and not the other let a commented-out heading disagree with the
      # binding beneath it. Everything else a renderer hides is refused rather
      # than filtered, by plain_file.
      strip_comments < "$AGENTS" > "$TMPD/agents-plain.md" 2>/dev/null
      prov=$(awk -v H="## Provides" '
        function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
        trim($0)==H { n++ } END { print n+0 }' "$TMPD/agents-plain.md" 2>/dev/null)
      [ "${prov:-0}" -eq 1 ] || add_fail "$(rel "$AGENTS"): 'competitors: complete' but the file carries ${prov:-0} '## Provides' sections; it carries exactly one"
      # Three spaces is where a list item stops being a list item, so past it
      # the line is code and binds nothing. Matching any indent is what let an
      # indented example count as the binding.
      # `-competitors:` is not a list item; a marker needs a space after it
      comp_bind_n=$(section_body "$TMPD/agents-plain.md" "## Provides" 2>/dev/null | grep -cE '^ {0,3}-[[:space:]]+competitors:' || true)
      comp_bind_ok=$(section_body "$TMPD/agents-plain.md" "## Provides" 2>/dev/null | grep -cE '^ {0,3}-[[:space:]]+competitors:[[:space:]]*memory/competitors\.md[[:space:]]*$' || true)
      if [ "${comp_bind_n:-0}" -ne 1 ] || [ "${comp_bind_ok:-0}" -ne 1 ]; then
        add_fail "$(rel "$AGENTS"): 'competitors: complete' but Provides carries ${comp_bind_n:-0} competitors binding(s), of which ${comp_bind_ok:-0} bind memory/competitors.md; it carries exactly one, and that one"
      fi
      plain_file "$ROOT/memory/competitors.md" "the file a competitor set resolves in" keep-comments
      # Whether the located text actually names a competitor is not something
      # this harness can decide, and it stops pretending it can.
      #
      # Rounds 25 to 28 tried both ways. A blocklist of empty shapes needed one
      # more spelling every round: `[Not available]`, with its anchor, in a
      # list, behind a blockquote, as a link reference definition, the anchors
      # alone, `N/A`, `TBD`, `[Verified]`. Then an allowlist, matching a word
      # the record itself called the set, which reviewers broke in both
      # directions at once: the interview names the confirmer and the date
      # because the template tells it to, so `Confirmed by Jane Doe, 2026-01-15`
      # passed with no competitor named, while `SAP`, `IBM` and `GE` are under
      # any sane length floor and a correct root could not close.
      #
      # Both were proxies for a judgment. What is mechanical is checked above:
      # the binding is there as a plain list item, the file is plain text with
      # comments filtered, and all three required classes anchor in that file.
      # What is not mechanical is declared, here and in the skill frontmatter
      # and in system/GAPS.md, rather than approximated by a grep that a
      # reviewer breaks every round.
      add_note "whether memory/competitors.md names a competitor rather than describing one is not mechanically checked; G0 checks the binding, the file's plainness and the three anchors, and the close report is where a person confirms the set is real"
    fi
    oldifs="$IFS"; IFS=','
    for cls in $classes; do
      IFS="$oldifs"
      if [ "$key" = "competitors" ]; then
        n=$(ONLY_FILE=memory/competitors.md claims_located_count "$key" "$cls")
      else
        n=$(claims_located_count "$key" "$cls")
      fi
      if [ "$n" -lt 1 ]; then
        if [ "$key" = "competitors" ]; then
          add_fail "$(rel "$VERIF"): key 'competitors' closes complete but '## Claims' has no located row for required class '$cls' whose anchor appears in memory/competitors.md, which is where the key resolves"
        else
          add_fail "$(rel "$VERIF"): key '$key' closes complete but '## Claims' has no located row for required class '$cls' whose anchor appears in the bound file it names"
        fi
      fi
      IFS=','
    done
    IFS="$oldifs"
  done
  # The escapes the counting loop could only write down, reported here, where
  # add_fail is in the gate's own shell and survives.
  if [ -s "$TMPD/g0-escapes.txt" ]; then
    sort -u "$TMPD/g0-escapes.txt" | while IFS= read -r esc; do
      printf '%s\n' "$esc"
    done > "$TMPD/g0-escapes-uniq.txt"
    while IFS= read -r esc; do
      [ -n "$esc" ] || continue
      add_fail "$(rel "$VERIF") names bound file '${esc%%|*}', which ${esc#*|}"
    done < "$TMPD/g0-escapes-uniq.txt"
  fi
}

# ---- G1 Scope recorded ---------------------------------------------------
gate_G1() {
  need_file "$RUNREC" || return
  for k in $G1_KEYS; do
    if ! has_key "$RUNREC" "$k"; then
      add_fail "$(rel "$RUNREC"): key line '$k:' missing"
      continue
    fi
    v=$(kv "$RUNREC" "$k")
    if [ -z "$v" ]; then
      add_fail "$(rel "$RUNREC"): key line '$k:' has an empty value"
      continue
    fi
    case "$k" in
      tier)
        case "$v" in full|core) ;; *) add_fail "$(rel "$RUNREC"): tier '$v' is not full or core" ;; esac ;;
      research-branch)
        case "$v" in research-first|interview-first|no-research) ;;
          *) add_fail "$(rel "$RUNREC"): research-branch '$v' is not one of research-first, interview-first, no-research" ;; esac ;;
      competitors-offer)
        case "$v" in
          yes|not-now|no) ;;
          not-offered:*)
            rest=$(printf '%s' "$v" | sed 's/^not-offered:[[:space:]]*//')
            case "$rest" in
              "")       add_fail "$(rel "$RUNREC"): competitors-offer 'not-offered:' names no type" ;;
              client)   add_fail "$(rel "$RUNREC"): competitors-offer 'not-offered: client' but the offer is made for every client root; record yes, not-now or no" ;;
              personal|org|department|industry) ;;
              *)        add_fail "$(rel "$RUNREC"): competitors-offer 'not-offered: $rest' names no root type" ;;
            esac
            [ "$rest" = "$ROOT_TYPE" ] || [ "$rest" = "" ] || [ "$rest" = "client" ] || \
              add_fail "$(rel "$RUNREC"): competitors-offer 'not-offered: $rest' but this root declares type $ROOT_TYPE" ;;
          *) add_fail "$(rel "$RUNREC"): competitors-offer '$v' is not one of yes, not-now, no, 'not-offered: <type>'" ;;
        esac ;;
    esac
  done
}

# ---- G2 Extraction complete and duplicates proved ------------------------
lead_number() { printf '%s' "$1" | awk '{print $1}'; }

gate_G2() {
  if [ ! -d "$EXTRACT_DIR" ]; then
    if [ "$(source_count)" -eq 0 ]; then
      add_note "no documents were supplied, so there is nothing to extract and this gate does not apply; the close report names it"
    else
      add_fail "$(rel "$EXTRACT_DIR") does not exist, but $(source_count) document(s) sit under $(rel "$SRC_DIR"); every source carries an extraction record"
    fi
    return
  fi
  n=0
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    n=$((n+1))
    r=$(rel "$f")
    em=$(kv "$f" "extract-measure"); cm=$(kv "$f" "check-measure")
    emech=$(kv "$f" "extract-mechanism"); cmech=$(kv "$f" "check-mechanism")
    if [ -z "$em" ]; then add_fail "$r: extract-measure missing or empty"; fi
    if [ -z "$cm" ]; then add_fail "$r: check-measure missing or empty"; fi
    if [ -n "$em" ] && [ -n "$cm" ]; then
      a=$(lead_number "$em"); b=$(lead_number "$cm")
      case "$a" in ''|*[!0-9.]*) add_fail "$r: extract-measure '$em' does not lead with a number" ; a="" ;; esac
      case "$b" in ''|*[!0-9.]*) add_fail "$r: check-measure '$cm' does not lead with a number" ; b="" ;; esac
      if [ -n "$a" ] && [ -n "$b" ] && [ "$a" != "$b" ]; then
        add_fail "$r: extract-measure ($a) and check-measure ($b) disagree"
      fi
    fi
    if [ -z "$emech" ]; then add_fail "$r: extract-mechanism missing or empty"; fi
    if [ -z "$cmech" ]; then add_fail "$r: check-mechanism missing or empty"; fi
    if [ -n "$emech" ] && [ "$emech" = "$cmech" ]; then
      add_fail "$r: extract-mechanism and check-mechanism are the same mechanism ('$emech')"
    fi
  done < <(list_md "$EXTRACT_DIR")
  if [ "$n" -eq 0 ]; then
    set_skip "$(rel "$EXTRACT_DIR") holds no extraction records"
  fi
}

# ---- G3 Copy established -------------------------------------------------
vantage_mech() { printf '%s' "$1" | awk -F'->' '{print $1}' | sed 's/[[:space:]]*$//'; }
vantage_count() { printf '%s' "$1" | awk -F'->' '{print $2}' | grep -oE '[0-9]+' | head -1; }

gate_G3() {
  need_file "$RUNREC" || return
  v1=$(kv "$RUNREC" "vantage-1")
  v2=$(kv "$RUNREC" "vantage-2")
  r=$(rel "$RUNREC")
  if [ -z "$v1" ]; then add_fail "$r: vantage-1 missing or empty"; fi
  if [ -z "$v2" ]; then add_fail "$r: vantage-2 missing or empty"; fi
  [ -n "$v1" ] && [ -n "$v2" ] || return
  if [ "$v2" = "single-vantage-host" ]; then
    if [ ! -f "$CLOSE" ]; then
      add_fail "$(rel "$CLOSE"): missing: vantage-2 is single-vantage-host and the close report must say so"
    elif ! grep -q "single-vantage-host" "$CLOSE" 2>/dev/null; then
      add_fail "$(rel "$CLOSE"): vantage-2 is single-vantage-host but the close report does not say so"
    fi
    return
  fi
  m1=$(vantage_mech "$v1"); m2=$(vantage_mech "$v2")
  c1=$(vantage_count "$v1"); c2=$(vantage_count "$v2")
  if [ -z "$m1" ] || [ -z "$m2" ]; then
    add_fail "$r: a vantage line does not read '<mechanism> -> <n> files'"
  elif [ "$m1" = "$m2" ]; then
    add_fail "$r: vantage-1 and vantage-2 name the same mechanism ('$m1')"
  fi
  if [ -z "$c1" ] || [ -z "$c2" ]; then
    add_fail "$r: a vantage line carries no file count"
  elif [ "$c1" != "$c2" ]; then
    add_fail "$r: vantage file counts disagree ($c1 vs $c2)"
  fi
}

# ---- G4 Evidence packages are evidence -----------------------------------
gate_G4() {
  if [ ! -d "$EVID_DIR" ]; then
    tierv=$(kv "$RUNREC" "tier" 2>/dev/null)
    if [ "$tierv" = "core" ]; then
      # the onboarding phases make per-angle packages a full-tier artifact, and the Tier
      # section retires G4 with them. A skip is not a pass, so without this a
      # correctly run core-tier root could never exit 0 from its own harness.
      add_note "tier: core, so per-angle evidence packages and this gate do not apply; the close report names it"
    else
      set_skip "$(rel "$EVID_DIR") does not exist: no evidence packages to check"
    fi
    return
  fi
  n=0
  : > "$TMPD/g4-rows.txt"
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    n=$((n+1))
    r=$(rel "$f")
    for k in angle retrieval-mechanism; do
      v=$(kv "$f" "$k")
      [ -n "$v" ] || add_fail "$r: '$k:' missing or empty"
    done
    # Quotations
    if table_get "$f" "Quotations" "Row,Quote,URL,Retrieved" > "$TMPD/g4q.txt" 2>/dev/null; then
      if [ ! -s "$TMPD/g4q.txt" ]; then
        add_fail "$r: '## Quotations' table has no data rows"
      fi
      while IFS="$US" read -r ln row quote url retrieved; do
        [ -n "$ln" ] || continue
        printf '%s\t%s\t%s\n' "$row" "$r" "$ln" >> "$TMPD/g4-rows.txt"
        echo "$row" | grep -qE '^E[0-9]+$' || add_fail "$r line $ln: quotation Row '$row' is not an E<n> id"
        [ -n "$url" ] || add_fail "$r line $ln: quotation row $row carries no URL"
        echo "$retrieved" | grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}' || \
          add_fail "$r line $ln: quotation row $row has no YYYY-MM-DD Retrieved date ('$retrieved')"
      done < "$TMPD/g4q.txt"
    else
      add_fail "$r: no '## Quotations' table with the columns Row, Quote, URL, Retrieved"
    fi
    # Values
    if table_get "$f" "Values" "Row,Value,File,Line" > "$TMPD/g4v.txt" 2>/dev/null; then
      if [ ! -s "$TMPD/g4v.txt" ]; then
        add_fail "$r: '## Values' table has no data rows"
      fi
      while IFS="$US" read -r ln row value vfile vline; do
        [ -n "$ln" ] || continue
        printf '%s\t%s\t%s\n' "$row" "$r" "$ln" >> "$TMPD/g4-rows.txt"
        echo "$row" | grep -qE '^E[0-9]+$' || add_fail "$r line $ln: value Row '$row' is not an E<n> id"
        [ -n "$vfile" ] || add_fail "$r line $ln: value row $row names no file"
        # A value read from a file has a line; a value read from a page has a
        # place on the page. Both are locators and both let someone re-find
        # it. What does not is "n/a" or a dash, which is the disguise this
        # clause exists to catch.
        vlow=$(printf '%s' "$vline" | tr 'A-Z' 'a-z' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        case "$vlow" in
          ''|'-'|'n/a'|'na'|'none'|'various'|'unknown')
            add_fail "$r line $ln: value row $row has no locator ('$vline'); a value carries the line it was read from, or the named place on the page" ;;
        esac
      done < "$TMPD/g4v.txt"
    else
      add_fail "$r: no '## Values' table with the columns Row, Value, File, Line"
    fi
    # Not retrieved
    if table_get "$f" "Not retrieved" "Item,Reason" > "$TMPD/g4n.txt" 2>/dev/null; then
      [ -s "$TMPD/g4n.txt" ] || add_fail "$r: '## Not retrieved' table has no data rows"
      while IFS="$US" read -r ln item reason; do
        [ -n "$ln" ] || continue
        [ -n "$item" ] && [ -n "$reason" ] || add_fail "$r line $ln: '## Not retrieved' row has an empty cell"
      done < "$TMPD/g4n.txt"
    else
      add_fail "$r: no '## Not retrieved' table with the columns Item, Reason"
    fi
    # (P) spot checks: the rows must exist and each must name an outcome.
    if table_get "$f" "Spot checks" "Outcome" > "$TMPD/g4s.txt" 2>/dev/null; then
      sc=$(wc -l < "$TMPD/g4s.txt" | tr -d ' ')
      if [ "$sc" -lt 3 ]; then
        add_fail "$r: '## Spot checks' carries $sc rows, three are required"
      fi
      while IFS="$US" read -r ln outcome; do
        [ -n "$ln" ] || continue
        [ -n "$outcome" ] || add_fail "$r line $ln: spot-check row names no outcome"
      done < "$TMPD/g4s.txt"
    else
      add_fail "$r: no '## Spot checks' table with an Outcome column (P clause: rows must exist and name an outcome)"
    fi
  done < <(list_md "$EVID_DIR")
  if [ "$n" -eq 0 ]; then
    set_skip "$(rel "$EVID_DIR") holds no evidence packages"
    return
  fi
  # E ids unique across every package in the run.
  if [ -s "$TMPD/g4-rows.txt" ]; then
    while IFS= read -r dup; do
      [ -n "$dup" ] || continue
      where=$(awk -F'\t' -v d="$dup" '$1==d{printf "%s line %s; ", $2, $3}' "$TMPD/g4-rows.txt")
      add_fail "evidence row id '$dup' is not unique across packages: $where"
    done < <(awk -F'\t' '{print $1}' "$TMPD/g4-rows.txt" | sort | uniq -d)
  fi
}

# ---- G5a Read-back coverage ---------------------------------------------
verif_row_ids() {
  # every Row id in ## Claims and ## Negative claims
  { table_get "$VERIF" "Claims" "Row" 2>/dev/null
    table_get "$VERIF" "Negative claims" "Row" 2>/dev/null
  } | awk -v US="$US" '{ split($0,f,US); if(f[2]!="") print f[2] }' | sort -u
}

gate_G5a() {
  if [ ! -d "$MEM" ]; then
    set_skip "$(rel "$MEM") does not exist: no bound files to read back"
    return
  fi
  bf=$(bound_files | wc -l | tr -d ' ')
  if [ "$bf" -eq 0 ]; then
    set_skip "$(rel "$MEM") holds no bound markdown files"
    return
  fi
  need_file "$VERIF" || return
  verif_row_ids > "$TMPD/g5a-rows.txt"

  # Forward: every anchor in a bound file has a row.
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    while IFS= read -r hit; do
      [ -n "$hit" ] || continue
      ln=$(printf '%s' "$hit" | awk -F: '{print $1}')
      anchor=$(printf '%s' "$hit" | sed 's/^[0-9]*://')
      id=$(printf '%s' "$anchor" | tr -d '[]')
      if ! grep -qx "$id" "$TMPD/g5a-rows.txt" 2>/dev/null; then
        add_fail "$r line $ln: anchor [$id] has no row in verification.md '## Claims' or '## Negative claims'"
      fi
    done < <(grep -onE '\[V[0-9]+\]' "$f" 2>/dev/null | sort -u -t: -k1,1n -k2,2)
  done < <(bound_files)

  # Backward: every candidate load-bearing sentence carries an anchor.
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    while IFS= read -r msg; do
      [ -n "$msg" ] || continue
      add_fail "$r $msg"
    done < <(awk -v rootname="$ROOTNAME" "$AWK_LIB"'
    BEGIN{
      nr=split(tolower(rootname),RW,/[^a-z0-9'\'']+/)
      for(q=1;q<=nr;q++) if(RW[q]!="") ROOTW[RW[q]]=1
      no=split("the this that these those a an it its their his her our your my we they he she there here what when where which who whom whose how why if unless because although though while after before since until once every each all both any some no none one two three four five next last other another such same both either neither not never do does did is are was were be been being has have had can could might must shall should would about above across against among around at by for from in into of off on onto over per through to under upon with within without and or but so yet for nor as than then thus hence therefore however moreover furthermore instead rather still also only just even",OP," ")
      for(q=1;q<=no;q++) OPENER[OP[q]]=1
    }
    { L[NR]=$0 }
    END{
      inpre=0
      for(i=1;i<=NR;i++){
        line=L[i]
        if(line ~ /<!--[ \t]*provenance-preamble[ \t]*-->/){ inpre=1; continue }
        if(line ~ /<!--[ \t]*\/provenance-preamble[ \t]*-->/){ inpre=0; continue }
        if(inpre) continue
        t=trim(line)
        if(t=="") continue
        if(t ~ /^#/) continue                      # heading
        if(t ~ /^\|/) continue                     # table row: G11b and G13b own tables
        if(t ~ /^\*.*\*$/) continue                # prompt line
        if(is_sep(t)) continue                     # table separator
        if(isrow(t) && i<NR && is_sep(L[i+1])) continue   # table header
        n=split(line,S,/\. /)
        # A dotted abbreviation is not a full stop. Splitting on ". " cuts
        # "e.g. Example Ltd." in half and reports the orphan as an unanchored
        # sentence while the anchor sits on the other half. Rejoin any
        # fragment whose last token is a dotted abbreviation or a single
        # initial, which is what the split left behind when it ate the dot.
        k=1
        while(k<n){
          nw=split(S[k],AW,/[ \t]+/)
          lastw=AW[nw]
          if(lastw ~ /^[A-Za-z](\.[A-Za-z])+$/ || lastw ~ /^[A-Z]$/ || lastw ~ /^(Mr|Mrs|Ms|Dr|Prof|Inc|Ltd|Co|St|No|vs|etc|Jr|Sr)$/){
            S[k]=S[k] ". " S[k+1]
            for(m=k+1;m<n;m++) S[m]=S[m+1]
            n--
          } else k++
        }
        # an anchor written after the full stop belongs to the sentence
        # before it, so pull it back before testing.
        for(k=2;k<=n;k++){
          tmp=S[k]
          while(match(tmp,/^[ \t]*\[V[0-9]+\]/)){
            S[k-1]=S[k-1] " " substr(tmp,RSTART,RLENGTH)
            tmp=substr(tmp,RSTART+RLENGTH)
          }
          S[k]=tmp
        }
        for(k=1;k<=n;k++){
          s=trim(S[k])
          if(s=="") continue
          low=tolower(s)
          cand=0
          # The spec names five claim triggers, not three. Phase 3 of the skill:
          # "a number, a proper noun, a quotation, a prohibition, or a comparative".
          if(s ~ /[0-9]/) cand=1
          # The trigger is "a number", not "a digit". A figure spelled out in
          # words is still a figure, and F20 in the catalog is an auditor
          # missing exactly that.
          if(low ~ /(^|[^a-z])(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|dozen|half|quarter|third|twice|thrice)([^a-z]|$)/) cand=1
          if(index(s,"\"")>0) cand=1
          if(low ~ /must not|never|may not|forbidden|prohibited|do not|not permitted/) cand=1
          # A declared absence has nothing to read back against.
          if(s ~ /\[Not available:/) continue
          # Proper noun: a capitalized word that is not the first word of the
          # sentence, and that is not part of the root name. A sentence whose
          # only proper noun is the subject itself is structural prose, not a
          # claim; anything load-bearing names a person, a competitor, a
          # document or a place as well. Over-flags rather than under-flags: a
          # false positive costs one anchor, a false negative costs an
          # unread claim.
          body=s
          sub(/^[-*+][ \t]+/,"",body)             # strip a list marker
          sub(/^[0-9]+\.[ \t]+/,"",body)          # strip an ordered marker
          nb=split(body,W,/[ \t]+/)
          # Word 1 is capitalized in every sentence, so it is tested against a
          # stoplist of ordinary sentence openers instead of being skipped.
          # Skipping it let "Nakamura chairs the review board" close unread.
          if(nb>=1){
            w1=W[1]
            gsub(/^[("\x27`\[]+/,"",w1)
            gsub(/[)"\x27`\].,;:!?]+$/,"",w1)
            if(w1 ~ /^[A-Z][A-Za-z\x27-]+$/ && !OPENER[tolower(w1)] \
               && !(ROOTW[tolower(w1)] && index(tolower(s),tolower(rootname))>0)) cand=1
          }
          for(w=2;w<=nb;w++){
            word=W[w]
            gsub(/^[("'\''`\[]+/,"",word)
            gsub(/[)"'\''`\].,;:!?]+$/,"",word)
            if(word !~ /^[A-Z][A-Za-z'\''-]+$/) continue
            if(ROOTW[tolower(word)] && index(tolower(s),tolower(rootname))>0) continue
            cand=1; break
          }
          # Comparative: closed marker list plus the "-er than" construction.
          # Bare "than" is deliberately absent: "rather than" is not a claim.
          # This awk does not honor \b. Written with explicit boundaries, and
          # verified against the platform rather than assumed.
          if(low ~ /(^|[^a-z])(more|less|fewer|greater|larger|smaller|higher|lower|better|worse|stronger|weaker|faster|slower|outperform|outperforms|outpace|outpaces|outsell|outsells|lead|leads|leading|largest|biggest|smallest|highest|lowest|best|worst|most|least|only|top|dominant|rank|ranks|ranked|ranking|versus|first|second|third|ahead|behind|premier|foremost|unmatched|unrivalled|unrivaled)([^a-z]|$)/) cand=1
          if(low ~ /ahead of|[a-z]er than/) cand=1
          if(!cand) continue
          if(s ~ /\[V[0-9]+\]/) continue
          disp=s
          if(length(disp)>90) disp=substr(disp,1,90) "..."
          printf "line %d: candidate load-bearing sentence carries no [V<n>] anchor: %s\n", i, disp
        }
      }
    }' "$f")
  done < <(bound_files)
}

# ---- G5b Read-back disposition ------------------------------------------
gate_G5b() {
  need_file "$VERIF" || return
  ok=0
  if table_get "$VERIF" "Claims" "Row,Anchor,Outcome,Label,Search" > "$TMPD/g5b.txt" 2>/dev/null; then
    ok=1
    while IFS="$US" read -r ln row anchor outcome label search; do
      [ -n "$ln" ] || continue
      case "$outcome" in
        located|located-elsewhere-and-citation-corrected|not-located) ;;
        *) add_fail "$(rel "$VERIF") line $ln: row $row Outcome '$outcome' is not one of located, located-elsewhere-and-citation-corrected, not-located" ; continue ;;
      esac
      if [ "$outcome" = "not-located" ] && [ "$anchor" != "-" ] && [ -n "$anchor" ]; then
        if [ "$label" != "Unverified" ]; then
          add_fail "$(rel "$VERIF") line $ln: row $row is not-located with anchor $anchor but Label is '$label', not Unverified"
        fi
        if [ -z "$search" ] || [ "$search" = "-" ]; then
          add_fail "$(rel "$VERIF") line $ln: row $row is not-located with anchor $anchor but Search is empty"
        fi
      fi
    done < "$TMPD/g5b.txt"
  else
    add_fail "$(rel "$VERIF"): no '## Claims' table with the columns Row, Anchor, Outcome, Label, Search"
  fi
  if table_get "$VERIF" "Negative claims" "Row,Outcome" > "$TMPD/g5bn.txt" 2>/dev/null; then
    ok=1
    while IFS="$US" read -r ln row outcome; do
      [ -n "$ln" ] || continue
      case "$outcome" in
        located|located-elsewhere-and-citation-corrected|not-located) ;;
        *) add_fail "$(rel "$VERIF") line $ln: negative row $row Outcome '$outcome' is not one of the three permitted values" ;;
      esac
    done < "$TMPD/g5bn.txt"
  else
    add_fail "$(rel "$VERIF"): no '## Negative claims' table with the columns Row, Outcome"
  fi
  [ "$ok" = "1" ] || true
}

# ---- G5c Negative claims enumerated -------------------------------------
NEG_GRAMMAR='not attributed|unattributed|does not say|does not contain|does not state|no such|nowhere|never said|never stated|never attributed'

gate_G5c() {
  if [ ! -d "$MEM" ]; then
    set_skip "$(rel "$MEM") does not exist: no bound files to scan"
    return
  fi
  need_file "$VERIF" || return
  # negative rows, keyed by anchor
  if table_get "$VERIF" "Negative claims" "Row,Anchor,All containers,Second reader,Outcome" > "$TMPD/g5c-neg.txt" 2>/dev/null; then :; else
    add_fail "$(rel "$VERIF"): no '## Negative claims' table with the columns Row, Anchor, All containers, Second reader, Outcome"
    : > "$TMPD/g5c-neg.txt"
  fi
  if table_get "$VERIF" "Claims" "Row,Anchor,Label" > "$TMPD/g5c-claims.txt" 2>/dev/null; then :; else
    : > "$TMPD/g5c-claims.txt"
  fi

  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    while IFS= read -r rec; do
      [ -n "$rec" ] || continue
      ln=$(printf '%s' "$rec" | awk -v US="$US" '{split($0,f,US); print f[1]}')
      anchor=$(printf '%s' "$rec" | awk -v US="$US" '{split($0,f,US); print f[2]}')
      isproh=$(printf '%s' "$rec" | awk -v US="$US" '{split($0,f,US); print f[3]}')
      snip=$(printf '%s' "$rec" | awk -v US="$US" '{split($0,f,US); print f[4]}')
      if [ -z "$anchor" ]; then
        add_fail "$r line $ln: negative claim carries no [V<n>] anchor: $snip"
        continue
      fi
      negrow=$(awk -v US="$US" -v a="$anchor" '{split($0,f,US); if(f[3]==a || f[3]=="["a"]" || f[2]==a) print $0}' "$TMPD/g5c-neg.txt" | head -1)
      if [ -z "$negrow" ]; then
        add_fail "$r line $ln: anchor [$anchor] on a negative claim has no row in '## Negative claims'"
        continue
      fi
      nrow=$(printf '%s' "$negrow" | awk -v US="$US" '{split($0,f,US); print f[2]}')
      allc=$(printf '%s' "$negrow" | awk -v US="$US" '{split($0,f,US); print f[4]}')
      second=$(printf '%s' "$negrow" | awk -v US="$US" '{split($0,f,US); print f[5]}')
      outcome=$(printf '%s' "$negrow" | awk -v US="$US" '{split($0,f,US); print f[6]}')
      if [ "$allc" != "yes" ]; then
        lbl=$(awk -v US="$US" -v a="$anchor" '{split($0,f,US); if(f[3]==a || f[3]=="["a"]") print f[4]}' "$TMPD/g5c-claims.txt" | head -1)
        if [ "$outcome" = "not-located" ] && [ "$lbl" = "Unverified" ]; then
          :
        else
          add_fail "$(rel "$VERIF"): negative row $nrow (anchor $anchor) has 'All containers: $allc' and is not a not-located claim labeled Unverified"
        fi
      fi
      if [ "$isproh" = "1" ] && { [ "$second" = "-" ] || [ -z "$second" ]; }; then
        add_fail "$(rel "$VERIF"): negative row $nrow (anchor $anchor) anchors a prohibition but 'Second reader' is '-'"
      fi
    done < <(awk -v US="$US" -v NEG="$NEG_GRAMMAR" "$AWK_LIB"'
    { L[NR]=$0 }
    END{
      inpre=0
      for(i=1;i<=NR;i++){
        line=L[i]
        if(line ~ /<!--[ \t]*provenance-preamble[ \t]*-->/){ inpre=1; continue }
        if(line ~ /<!--[ \t]*\/provenance-preamble[ \t]*-->/){ inpre=0; continue }
        if(inpre) continue
        t=trim(line)
        if(t=="") continue
        if(t ~ /^#/) continue
        if(t ~ /^\*.*\*$/) continue
        if(is_sep(t)) continue
        if(isrow(t) && i<NR && is_sep(L[i+1])) continue
        n=split(line,S,/\. /)
        for(k=2;k<=n;k++){
          tmp=S[k]
          while(match(tmp,/^[ \t]*\[V[0-9]+\]/)){
            S[k-1]=S[k-1] " " substr(tmp,RSTART,RLENGTH)
            tmp=substr(tmp,RSTART+RLENGTH)
          }
          S[k]=tmp
        }
        for(k=1;k<=n;k++){
          s=trim(S[k]); if(s=="") continue
          low=tolower(s)
          if(low !~ NEG) continue
          anchor=""
          if(match(s,/\[V[0-9]+\]/)) anchor=substr(s,RSTART+1,RLENGTH-2)
          proh=0
          if(low ~ /must not|never|may not|forbidden|prohibited|do not/) proh=1
          disp=s; if(length(disp)>90) disp=substr(disp,1,90) "..."
          printf "%d%s%s%s%d%s%s\n", i, US, anchor, US, proh, US, disp
        }
      }
    }' "$f")
  done < <(bound_files)
}

# ---- G6 The forward gate -------------------------------------------------
F15_DISGUISE='not present in source|no prohibitions in source|none found|nothing to disposition|n/a'

where_resolves() {
  # $1 = Where cell for an in-bound-file row. Prints an error, or nothing.
  w="$1"
  path=$(printf '%s' "$w" | awk -F'#' '{print $1}' | sed 's/[[:space:]]*$//' | sed 's/^[[:space:]]*//' | tr -d '`')
  anchor=$(printf '%s' "$w" | sed 's/^[^#]*#//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
  if [ -z "$path" ]; then printf '%s' "Where names no file"; return; fi
  case "$w" in
    *'#'*) ;;
    *) printf '%s' "Where '$w' carries no #anchor-or-heading"; return ;;
  esac
  if ! under_root "$path"; then printf '%s' "Where names '$path', which $_ur_why"; return; fi
  target="$ROOT/$path"
  if [ ! -f "$target" ]; then printf '%s' "Where names '$path', which does not exist under the root"; return; fi
  if [ -z "$anchor" ]; then printf '%s' "Where '$w' carries an empty anchor"; return; fi
  if awk -v A="$anchor" "$AWK_LIB"'
    BEGIN{ la=tolower(A); sa=slug(A); found=0 }
    {
      if(index(tolower($0),la)>0) found=1
      t=trim($0)
      if(t ~ /^#+([ \t])/){
        h=t; sub(/^#+[ \t]+/,"",h)
        if(slug(h)==sa) found=1
      }
    }
    END{ exit (found?0:1) }' "$target"; then
    return
  fi
  printf '%s' "Where anchor '$anchor' is not in $path"
}

gate_G6() {
  if [ ! -d "$EXTRACT_DIR" ]; then
    if [ "$(source_count)" -eq 0 ]; then
      add_note "no documents were supplied, so there is no must-reach list and this gate does not apply; the close report names it"
    else
      add_fail "$(rel "$EXTRACT_DIR") does not exist, but $(source_count) document(s) sit under $(rel "$SRC_DIR"); the forward gate needs a must-reach list per source"
    fi
    return
  fi
  n=0
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    n=$((n+1))
    r=$(rel "$f")
    if table_get "$f" "Must-reach list" "Item,Kind,Text,Disposition,Where" > "$TMPD/g6.txt" 2>/dev/null; then :; else
      add_fail "$r: no '## Must-reach list' table with the columns Item, Kind, Text, Disposition, Where"
      continue
    fi
    if [ ! -s "$TMPD/g6.txt" ]; then
      add_fail "$r: '## Must-reach list' has no rows"
      continue
    fi
    while IFS="$US" read -r ln item kind text disp where; do
      [ -n "$ln" ] || continue
      low=$(printf '%s %s' "$text" "$where" | tr 'A-Z' 'a-z')
      if printf '%s' "$low" | grep -qE "$F15_DISGUISE"; then
        add_fail "$r line $ln: row $item disposes of a must-reach item as absent from its own source (F15 disguise grammar)"
      fi
      # Version 4 closed the operating-file escape: downstream work loads
      # bound files and does not load the todo list, so a prohibition or a
      # compliance flag routed to the operating file reproduces F15 exactly
      # while satisfying the disposition check. Those two kinds discharge
      # only in-bound-file; commercial, person and review-note take either.
      case "$kind" in
        prohibition|compliance)
          if [ "$disp" = "in-operating-file" ]; then
            add_fail "$r line $ln: row $item is kind $kind and disposes in-operating-file; prohibition and compliance items discharge only to a bound file, because downstream work does not load the operating file"
          fi
          ;;
      esac
      case "$disp" in
        in-bound-file)
          err=$(where_resolves "$where")
          [ -z "$err" ] || add_fail "$r line $ln: row $item $err"
          ;;
        in-operating-file)
          oid=$(printf '%s' "$where" | grep -oE 'O[0-9]+' | head -1)
          if [ -z "$oid" ]; then
            add_fail "$r line $ln: row $item is in-operating-file but Where '$where' names no O<n> item"
          elif [ ! -f "$OPER" ]; then
            add_fail "$r line $ln: row $item points at $(rel "$OPER"), which is missing"
          elif ! grep -qE "(^|[^A-Za-z0-9])$oid([^0-9]|$)" "$OPER"; then
            add_fail "$r line $ln: row $item points at $oid, which is not in $(rel "$OPER")"
          fi
          ;;
        *)
          add_fail "$r line $ln: row $item Disposition '$disp' is not in-bound-file or in-operating-file"
          ;;
      esac
    done < "$TMPD/g6.txt"
  done < <(list_md "$EXTRACT_DIR")
  [ "$n" -gt 0 ] || set_skip "$(rel "$EXTRACT_DIR") holds no extraction records"
}

# ---- G6b The forward gate's coverage floor ------------------------------
# Widened in round 1. A reviewer showed that a constraint worded outside the
# list ("Only regulator-cleared claims may appear") is invisible to the floor as
# well as to the row check, so the count is satisfied without the item ever
# existing. Widening narrows that hole. It cannot close it: no keyword list is
# the set of all prohibitions. run-log.md states the residual rather than
# claiming this gate catches omission in general.
CONSTRAINT_GRAMMAR='must not|may not|must only|may only|only |never|not permitted|permitted only|prohibited|forbidden|do not|cannot|shall not|no [a-z]+ may|restricted|require[sd]? approval|sign-?off|approval|cleared|clearance|embargo|compliance|regulat|legal|confidential|under nda|not for|internal only|do not share|fee|retainer|term of|pricing|priced|invoice|scope of work|deliverable count|review note|reviewer|comment|tracked change|redline|struck out'

gate_G6b() {
  if [ ! -d "$SRC_DIR" ]; then
    add_note "no documents were supplied, so there is no coverage floor to meet and this gate does not apply; the close report names it"
    return
  fi
  if [ ! -d "$EXTRACT_DIR" ]; then
    if [ "$(source_count)" -eq 0 ]; then
      add_note "no documents were supplied, so there is no coverage floor to meet and this gate does not apply; the close report names it"
    else
      add_fail "$(rel "$EXTRACT_DIR") does not exist, but $(source_count) document(s) sit under $(rel "$SRC_DIR"); the coverage floor needs an extraction record per source"
    fi
    return
  fi
  n=0
  while IFS= read -r s; do
    [ -n "$s" ] || continue
    n=$((n+1))
    srel=$(rel "$s")
    # Headings are excluded from the floor. A section heading such as
    # "## 5. Claims and sign-off" matches the constraint grammar without being
    # a must-reach item, and counting it would demand a row for a heading.
    # Excluding a false match is honest; writing a row to satisfy a counter is
    # the bookkeeping failure this suite exists to catch.
    want=$(grep -av '^[[:space:]]*#' "$s" 2>/dev/null | grep -aciE "$CONSTRAINT_GRAMMAR")
    [ -n "$want" ] || want=0
    # Find the extraction record whose source: key names this file.
    rec=""
    base=$(basename "$s")
    while IFS= read -r e; do
      [ -n "$e" ] || continue
      sv=$(kv "$e" "source")
      [ -n "$sv" ] || continue
      sv=$(printf '%s' "$sv" | tr -d '`' | sed 's#^\./##')
      if [ "$sv" = "$srel" ] || [ "$(basename "$sv")" = "$base" ]; then
        rec="$e"; break
      fi
    done < <(list_md "$EXTRACT_DIR")
    if [ -z "$rec" ]; then
      add_fail "$srel: no extraction record under $(rel "$EXTRACT_DIR") carries 'source: $srel'"
      continue
    fi
    got=0
    if table_get "$rec" "Must-reach list" "Item,Kind" > "$TMPD/g6b.txt" 2>/dev/null; then
      got=$(awk -v US="$US" '
        { split($0,f,US); k=tolower(f[3])
          if(k=="prohibition"||k=="compliance"||k=="commercial"||k=="review-note") n++ }
        END{ print n+0 }' "$TMPD/g6b.txt")
    else
      add_fail "$(rel "$rec"): no '## Must-reach list' table with the columns Item, Kind"
      continue
    fi
    if [ "$got" -lt "$want" ]; then
      add_fail "$(rel "$rec"): $got must-reach rows of kind prohibition/compliance/commercial/review-note, but $srel has $want lines matching the constraint grammar"
    fi
  done < <(list_any "$SRC_DIR")
  [ "$n" -gt 0 ] || add_note "no documents were supplied, so there is no coverage floor to meet and this gate does not apply; the close report names it"
}

# ---- G7 Deferrals are named ---------------------------------------------
gate_G7() {
  need_file "$OPER" || return
  if table_get "$OPER" "" "Item,Status,Blocker,Attempt" > "$TMPD/g7.txt" 2>/dev/null; then :; else
    add_fail "$(rel "$OPER"): no table with the columns Item, Status, Blocker, Attempt"
    return
  fi
  while IFS="$US" read -r ln item status blocker attempt; do
    [ -n "$ln" ] || continue
    case "$status" in
      gating|blocking) ;;
      *) continue ;;
    esac
    if ! printf '%s' "$blocker" | grep -qE '^(person|credential|capability): .+'; then
      add_fail "$(rel "$OPER") line $ln: row $item is $status but Blocker '$blocker' does not match '^(person|credential|capability): .+'"
    fi
    if [ -z "$attempt" ] || [ "$attempt" = "-" ]; then
      add_fail "$(rel "$OPER") line $ln: row $item is $status but records no Attempt"
    fi
  done < "$TMPD/g7.txt"
}

# ---- G8 Exactness claims used a second mechanism ------------------------
gate_G8() {
  need_file "$VERIF" || return
  if table_get "$VERIF" "Claims" "Row,Mechanism,Exactness,Second mechanism,Label" > "$TMPD/g8.txt" 2>/dev/null; then :; else
    add_fail "$(rel "$VERIF"): no '## Claims' table with the columns Row, Mechanism, Exactness, Second mechanism, Label"
    return
  fi
  while IFS="$US" read -r ln row mech exact second label; do
    [ -n "$ln" ] || continue
    [ "$exact" = "yes" ] || continue
    [ "$label" = "Unverified" ] && continue
    if [ -z "$second" ] || [ "$second" = "-" ]; then
      add_fail "$(rel "$VERIF") line $ln: row $row is Exactness yes with an empty 'Second mechanism' and Label '$label'"
    elif [ "$second" = "$mech" ]; then
      add_fail "$(rel "$VERIF") line $ln: row $row is Exactness yes but 'Second mechanism' repeats Mechanism ('$mech')"
    fi
  done < "$TMPD/g8.txt"
}

# ---- G9 Headings answered ------------------------------------------------
gate_G9() {
  if [ ! -d "$MEM" ]; then
    set_skip "$(rel "$MEM") does not exist: nothing to check"
    return
  fi
  bf=$(bound_files | wc -l | tr -d ' ')
  if [ "$bf" -eq 0 ]; then
    set_skip "$(rel "$MEM") holds no bound markdown files"
    return
  fi
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    # (a) prompt lines
    while IFS= read -r hit; do
      [ -n "$hit" ] || continue
      add_fail "$r line ${hit%%:*}: a prompt line survives (^\\*.*\\*\$)"
    done < <(strip_preamble "$f" | grep -nE '^\*.*\*$' 2>/dev/null)
    # (b) and (c). The prompt-line scan above strips the preamble; this one
    # must too, or fenced instruction reads as a section body. strip_preamble
    # blanks its lines rather than removing them, so line numbers still match.
    strip_preamble "$f" > "$TMPD/g9body.txt"
    while IFS= read -r msg; do
      [ -n "$msg" ] || continue
      add_fail "$r $msg"
    done < <(awk "$AWK_LIB"'
    { L[NR]=$0 }
    END{
      seenhead=0
      for(i=1;i<=NR;i++){
        t=trim(L[i])
        if(t !~ /^#+([ \t]|$)/) continue
        lvl=0; while(substr(t,lvl+1,1)=="#") lvl++
        title = (seenhead==0 && lvl==1)   # the document title carries no body
        seenhead=1
        # find the next non-blank line
        j=i+1
        while(j<=NR && trim(L[j])=="") j++
        if(j>NR){
          if(!title) printf "line %d: heading \"%s\" has an empty body\n", i, t
          continue
        }
        if(trim(L[j]) ~ /^#+([ \t]|$)/){
          # A deeper heading is structure, not an empty section: the parent
          # holds children rather than prose, and each child is checked on its
          # own pass. Only a sibling or shallower heading means nothing here.
          nlvl=0; while(substr(trim(L[j]),nlvl+1,1)=="#") nlvl++
          if(nlvl>lvl) continue
          if(!title) printf "line %d: heading \"%s\" is followed by another heading with no body\n", i, t
          continue
        }
        if(title) continue
        # (c) a body that is one bare sentence carrying no label, no anchor
        # and no register parenthetical is an unlabeled deferral.
        k=j; nb=0; body=""
        while(k<=NR && trim(L[k]) !~ /^#+([ \t]|$)/){
          if(trim(L[k])!=""){ nb++; body=body " " trim(L[k]) }
          k++
        }
        body=trim(body)
        ns=split(body,SS,/\. /)
        if(ns==1 && body ~ /\.$/) ns=1
        if(nb<=1 && ns<=1 \
           && body !~ /\[(Verified|Estimated|Unverified|Not available)/ \
           && body !~ /\[V[0-9]+\]/ \
           && body !~ /\([^)]*\.[A-Za-z0-9]+\)/ \
           && body !~ /\(E[0-9]+/ \
           && body !~ /\((Firsthand|Secondhand|Public statement|Research inference)/){
          d=body; if(length(d)>70) d=substr(d,1,70) "..."
          printf "line %d: heading \"%s\" is answered by a bare sentence with no bracketed label: %s\n", i, t, d
        }
      }
    }' "$TMPD/g9body.txt")
  done < <(bound_files)
}

# ---- G10 Registers used as defined --------------------------------------
DOC_GRAMMAR='\.pdf|\.docx|\.pptx|\.md|deck|document|report|guide|memo|slide'
# A person name: at least two capitalized parts, joined by a space or a
# hyphen. This is a whitelist on purpose. The document blacklist above can
# always be evaded by naming a document without a document word in it, so the
# firsthand payload has to positively look like an observer.
PERSON_GRAMMAR="(^|[^A-Za-z])[A-Z][a-z]+([ -][A-Z][a-z']+)+"
# The head noun of a role, a body, or a document. A two-capitalized-word phrase
# ending in one of these is a title or a thing, not an observer. This is a
# blacklist and it is deliberately a second line of defense behind the person
# registry, not the primary check.
NONPERSON_TAIL='(Director|Owner|Manager|Lead|Head|Officer|Chief|Counsel|Partner|Partnership|Analyst|Executive|Coordinator|Specialist|Adviser|Advisor|President|Secretary|Treasurer|Board|Council|Committee|Panel|Group|Team|Department|Division|Review|Summary|Brief|Report|Meeting|Minutes|Session|Workshop|Update|Notes|Note|Log|Register|Record|Series|Programme|Program|Project|Account|Relations|Communications|Marketing|Compliance|Legal|Operations|Function|Practice|Unit|Office|Desk|Bureau|Agency|Authority|Trust|Fund|Holdings|Ventures|Labs|Studio|Works|Outlook|Steward|Insights|Analytics)s?$'

build_person_registry() {
  : > "$TMPD/people.txt"
  # People named in the must-reach lists, and people named in the interview's
  # who-confirms answer. Both are records the run had to write anyway.
  if [ -d "$EXTRACT_DIR" ]; then
    while IFS= read -r e; do
      [ -n "$e" ] || continue
      table_get "$e" "" "Item,Kind,Text" 2>/dev/null | awk -v US="$US" '
        { split($0,f,US); if(tolower(f[3])=="person") print f[4] }'
    done < <(find "$EXTRACT_DIR" -type f -name '*.md' ! -name 'AGENTS.md' 2>/dev/null | sort) \
      >> "$TMPD/people.txt"
  fi
  if [ -f "$RUNREC" ]; then
    section_body "$RUNREC" "### Who confirms and on what basis" 2>/dev/null >> "$TMPD/people.txt"
  fi
  # Second readers are people the run named as people, so they count too.
  if [ -f "$VERIF" ]; then
    table_get "$VERIF" "Negative claims" "Row,Second reader" 2>/dev/null | awk -v US="$US" '
      { split($0,f,US); if(f[3]!="" && f[3]!="-") print f[3] }' >> "$TMPD/people.txt"
    # A person named as having run a check is a person this run recorded. On a
    # root with supplied documents the must-reach person rows carry everyone;
    # a research-first root has no extraction records at all, and the reader
    # who did the read-back was reachable nowhere, so every Firsthand register
    # naming them failed. The mechanism columns are where that run wrote them.
    table_get "$VERIF" "Claims" "Row,Mechanism,Second mechanism" 2>/dev/null | awk -v US="$US" '
      { split($0,f,US); if(f[3]!="" && f[3]!="-") print f[3]; if(f[4]!="" && f[4]!="-") print f[4] }' \
      >> "$TMPD/people.txt"
  fi
  # On the personal path the only recorded person is the root's owner, whose
  # name is the root's `root:` declaration and its title line, and every
  # firsthand fact in the files is what that person said.
  if [ "$SHORT" = "1" ]; then
    kv "$AGENTS" "root" >> "$TMPD/people.txt" 2>/dev/null || :
    grep -m1 -E '^# ' "$AGENTS" 2>/dev/null | sed 's/^# //' >> "$TMPD/people.txt" || :
  fi
  # Reduce the registry to NAMES. Matching a payload against raw prose let
  # "Marketing Director" pass because that title sits inside a sentence about a
  # person. A name is compared to a name.
  grep -oE "$PERSON_GRAMMAR" "$TMPD/people.txt" 2>/dev/null \
    | sed 's/^[^A-Za-z]*//' | grep -vE "$NONPERSON_TAIL" | sort -u > "$TMPD/people-names.txt" || :
  mv "$TMPD/people-names.txt" "$TMPD/people.txt"
}

gate_G10() {
  build_person_registry
  if [ ! -d "$MEM" ]; then
    set_skip "$(rel "$MEM") does not exist: nothing to check"
    return
  fi
  bf=$(bound_files | wc -l | tr -d ' ')
  if [ "$bf" -eq 0 ]; then
    set_skip "$(rel "$MEM") holds no bound markdown files"
    return
  fi
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    while IFS= read -r hit; do
      [ -n "$hit" ] || continue
      ln=${hit%%:*}
      tok=$(printf '%s' "$hit" | sed 's/^[0-9]*://')
      name=$(printf '%s' "$tok" | sed 's/^(//' | awk -F: '{print $1}')
      payload=$(printf '%s' "$tok" | sed 's/^([^:)]*//' | sed 's/^://' | sed 's/)$//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
      case "$tok" in
        *:*) ;;
        *) add_fail "$r line $ln: register '$tok' carries no payload"; continue ;;
      esac
      if [ -z "$payload" ]; then
        add_fail "$r line $ln: register '($name: )' has an empty payload"
        continue
      fi
      case "$name" in
        Firsthand)
          # Round 1 replaced a document blacklist with a name-shape test, and
          # round 2 showed a shape test is not a person test: "Category Review",
          # "Review Board" and "Account Owner" all have the shape. No regex
          # separates a person from a title-cased document, so the payload is
          # checked against the people this run actually recorded: the person
          # rows of the must-reach lists and the interview's who-confirms
          # answer. An observer nobody wrote down is not an observer.
          if [ "$SHORT" = "1" ] && [ -n "$OWNER_LC" ] && [ "$(printf '%s' "$payload" | cut -d, -f1 | sed 's/[[:space:]]*$//' | tr 'A-Z' 'a-z')" = "$OWNER_LC" ]; then
            # The root's owner, by the name the root declares, whatever its
            # shape: a mononym or a non-Latin name is a person all the same.
            :
          elif printf '%s' "$payload" | tr 'A-Z' 'a-z' | grep -qE "$DOC_GRAMMAR"; then
            add_fail "$r line $ln: (Firsthand: $payload) names a document as the observer"
          elif ! printf '%s' "$payload" | grep -qE "$PERSON_GRAMMAR"; then
            add_fail "$r line $ln: (Firsthand: $payload) does not name a person who observed it; firsthand names an observer, never a document or a role alone"
          elif printf '%s' "$payload" | grep -qE "$NONPERSON_TAIL"; then
            add_fail "$r line $ln: (Firsthand: $payload) names a role, a body, or a document, not the person who observed it"
          elif [ -s "$TMPD/people.txt" ]; then
            pn=$(printf '%s' "$payload" | grep -oE "$PERSON_GRAMMAR" | sed 's/^[^A-Za-z]*//' | head -1)
            if [ -n "$pn" ] && ! grep -qixF "$pn" "$TMPD/people.txt"; then
              add_fail "$r line $ln: (Firsthand: $payload) names '$pn', who is not recorded as a person anywhere in this run; a firsthand observer appears in the must-reach person rows or in who-confirms"
            fi
          else
            add_fail "$r line $ln: (Firsthand: $payload) cannot be checked because no person was recorded anywhere in this run; who-confirms is a mandatory interview class and every named person belongs in a must-reach row"
          fi
          ;;
        'Research inference')
          if ! printf '%s' "$payload" | grep -qE 'E[0-9]+'; then
            add_fail "$r line $ln: (Research inference: $payload) names no E<n> evidence row"
          fi
          ;;
      esac
    done < <(strip_preamble "$f" | grep -onE '\((Firsthand|Secondhand|Public statement|Research inference)[^)]*\)' 2>/dev/null)
  done < <(bound_files)
}

# ---- G11 Label vocabulary is closed --------------------------------------
gate_G11() {
  if [ ! -d "$MEM" ]; then
    set_skip "$(rel "$MEM") does not exist: nothing to check"
    return
  fi
  bf=$(bound_files | wc -l | tr -d ' ')
  if [ "$bf" -eq 0 ]; then
    set_skip "$(rel "$MEM") holds no bound markdown files"
    return
  fi
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    while IFS= read -r hit; do
      [ -n "$hit" ] || continue
      ln=${hit%%:*}
      tok=$(printf '%s' "$hit" | sed 's/^[0-9]*://')
      head=$(printf '%s' "$tok" | sed 's/^\[//' | sed 's/\]$//' | awk -F: '{print $1}' | sed 's/[[:space:]]*$//')
      case "$head" in
        Verified|Estimated|Unverified|'Not available') continue ;;
        Competitor) continue ;;
      esac
      add_fail "$r line $ln: label token '[$head]' is outside the standard's four (Verified, Estimated, Unverified, Not available)"
    done < <(strip_preamble "$f" | grep -onE '\[[A-Z][A-Za-z ]*(:[^]]*)?\]' 2>/dev/null)
  done < <(bound_files)
}

# ---- G11b Figure tables carry their provenance ---------------------------
# A figures heading is one the template marks with an <!-- figures --> comment
# (on the heading line or immediately under it) or whose text names figures.
# Any table carrying a Figure column is treated as a figures table as well, so
# a table that lost its Label column is still caught.
gate_G11b() {
  if [ ! -d "$MEM" ]; then
    set_skip "$(rel "$MEM") does not exist: nothing to check"
    return
  fi
  bf=$(bound_files | wc -l | tr -d ' ')
  if [ "$bf" -eq 0 ]; then
    set_skip "$(rel "$MEM") holds no bound markdown files"
    return
  fi
  found_any=0
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    r=$(rel "$f")
    out=$(awk "$AWK_LIB"'
    BEGIN{
      nreq=split("Figure,Unit,Denominator,Tool,Window,Label,Source",req,",")
    }
    { L[NR]=$0 }
    END{
      figs=0; hdr=0
      for(i=1;i<=NR;i++){
        line=L[i]; t=trim(line)
        if(t ~ /^#+([ \t]|$)/){
          hdr=0; figs=0
          h=t; sub(/^#+[ \t]*/,"",h)
          if(tolower(h) ~ /figure/) figs=1
          if(line ~ /<!--[ \t]*figures[ \t]*-->/) figs=1
          j=i+1
          while(j<=NR && trim(L[j])=="") j++
          if(j<=NR && trim(L[j]) ~ /<!--[ \t]*figures[ \t]*-->/) figs=1
          heading=t
          continue
        }
        if(hdr==0){
          if(isrow(line) && i<NR && is_sep(L[i+1])){
            m=ncells(line,c); split("",col,":")
            for(k=1;k<=m;k++) col[c[k]]=k
            istable = figs
            if("Figure" in col) istable=1
            if(!istable) continue
            print "TABLE"
            miss=""
            for(k=1;k<=nreq;k++) if(!(req[k] in col)) miss=miss (miss==""?"":", ") req[k]
            if(miss!="") printf "line %d: figures table under \"%s\" is missing the column(s): %s\n", i, heading, miss
            hdr=1; ncols=m
            i++
            continue
          }
          continue
        }
        if(!isrow(line)){ hdr=0; continue }
        if(is_sep(line)) continue
        m=ncells(line,c)
        for(k=1;k<=nreq;k++){
          if(!(req[k] in col)) continue
          v = (col[req[k]]<=m) ? c[col[req[k]]] : ""
          if(v=="") printf "line %d: figures table under \"%s\" has an empty %s cell\n", i, heading, req[k]
        }
      }
    }' "$f")
    if printf '%s' "$out" | grep -q '^TABLE$'; then found_any=1; fi
    while IFS= read -r msg; do
      [ -n "$msg" ] || continue
      [ "$msg" = "TABLE" ] && continue
      add_fail "$r $msg"
    done <<G11BEOF
$out
G11BEOF
  done < <(bound_files)
  if [ "$found_any" -eq 0 ] && [ -z "$G_FAILS" ]; then
    if [ "$SHORT" = "1" ]; then add_note "no figures heading under memory; not applicable on the personal path"; else set_skip "no figures heading and no table with a Figure column under $(rel "$MEM")"; fi
  fi
}

# ---- G12 The interview covered its classes -------------------------------
gate_G12() {
  need_file "$RUNREC" || return
  if [ "$ROOT_TYPE" = "client" ]; then
    G12_FIRST="What was bought"
  else
    G12_FIRST="What this root is for"
  fi
  prev_ln=0
  for h in "$G12_FIRST" "Who confirms and on what basis" "Contradictions" "What the outputs are for"; do
    if ! has_heading "$RUNREC" "### $h"; then
      add_fail "$(rel "$RUNREC"): '### $h' missing"
      continue
    fi
    this_ln=$(sed 's/^[[:space:]]*//; s/[[:space:]]*$//' "$RUNREC" 2>/dev/null | grep -n -F -x "### $h" | head -1 | cut -d: -f1)
    if [ -n "$this_ln" ] && [ "$this_ln" -lt "$prev_ln" ]; then
      add_fail "$(rel "$RUNREC"): '### $h' is out of order; the table gives these four in one order and the record has to keep it"
    fi
    [ -z "$this_ln" ] || prev_ln="$this_ln"
    section_body "$RUNREC" "### $h" > "$TMPD/g12.txt"
    nb=$(nonblank_count "$TMPD/g12.txt")
    if [ "$nb" -eq 0 ]; then
      add_fail "$(rel "$RUNREC"): '### $h' has an empty body"
      continue
    fi
    if grep -qE '^[[:space:]]*Deferred:' "$TMPD/g12.txt"; then
      if [ "$h" = "What the outputs are for" ]; then
        add_fail "$(rel "$RUNREC"): '### What the outputs are for' is deferred, which is not permitted"
      fi
      conseq=$(grep -E '^[[:space:]]*Deferred:' "$TMPD/g12.txt" | head -1 | sed 's/^[[:space:]]*Deferred:[[:space:]]*//')
      words=$(printf '%s' "$conseq" | wc -w | tr -d ' ')
      if [ "$words" -lt 3 ]; then
        add_fail "$(rel "$RUNREC"): '### $h' defers with no consequence ('Deferred: $conseq')"
      fi
    fi
  done
  offer=$(kv "$RUNREC" "competitors-offer")
  if [ "$offer" = "yes" ]; then
    if ! has_heading "$RUNREC" "### Competitor set"; then
      add_fail "$(rel "$RUNREC"): competitors-offer is yes but '### Competitor set' is missing"
    else
      section_body "$RUNREC" "### Competitor set" > "$TMPD/g12c.txt"
      nb=$(nonblank_count "$TMPD/g12c.txt")
      [ "$nb" -gt 0 ] || add_fail "$(rel "$RUNREC"): '### Competitor set' has an empty body"
    fi
    # (P) mechanical clause: every name in the competitor evidence angle
    # appears in memory/competitors.md.
    comp="$MEM/competitors.md"
    angle=""
    if [ -d "$EVID_DIR" ]; then
      while IFS= read -r e; do
        [ -n "$e" ] || continue
        a=$(kv "$e" "angle")
        if printf '%s' "$a" | tr 'A-Z' 'a-z' | grep -q 'competit'; then angle="$e"; break; fi
      done < <(list_md "$EVID_DIR")
    fi
    if [ -z "$angle" ]; then
      add_note "no evidence package with a competitor angle: the competitor-name clause did not run"
    elif [ ! -f "$comp" ]; then
      add_fail "$(rel "$comp"): missing, but a competitor evidence angle exists"
    else
      names=""
      for colname in Name Competitor Names; do
        if table_get "$angle" "" "$colname" > "$TMPD/g12n.txt" 2>/dev/null; then
          names=$(awk -v US="$US" '{split($0,f,US); if(f[2]!="") print f[2]}' "$TMPD/g12n.txt" | sort -u)
          [ -n "$names" ] && break
        fi
      done
      if [ -z "$names" ]; then
        add_note "$(rel "$angle") has no Name/Competitor column: the competitor-name clause is not mechanical here"
      else
        while IFS= read -r nm; do
          [ -n "$nm" ] || continue
          if ! grep -qiF "$nm" "$comp"; then
            add_fail "$(rel "$comp"): competitor '$nm' from $(rel "$angle") appears nowhere in the file"
          fi
        done <<G12EOF
$names
G12EOF
      fi
    fi
  fi
}

# ---- G13 Traits are checkable (M clause) --------------------------------
BARE_ADJ='measured|institutional|aspirational|sensory|warm|authoritative|playful|professional|engaging|compelling'

gate_G13() {
  VOICE="$MEM/voice.md"
  need_file "$VOICE" || return
  if [ "$SHORT" = "1" ] && [ "$(onb_state voice)" != "complete" ]; then
    add_note "voice closed '$(onb_state voice)' on the personal path; the voice file is not checked until it closes complete"
    return
  fi
  while IFS= read -r hit; do
    [ -n "$hit" ] || continue
    ln=${hit%%:*}
    txt=$(printf '%s' "$hit" | sed 's/^[0-9]*://' | sed 's/^[[:space:]]*//')
    [ ${#txt} -gt 90 ] && txt=$(printf '%s' "$txt" | cut -c1-90)
    words=$(printf '%s' "$txt" | tr 'A-Z' 'a-z' | awk -v L="$BARE_ADJ" '
      { n=split(L,a,"|"); out=""
        for(i=1;i<=n;i++) if($0 ~ "(^|[^a-z])" a[i] "([^a-z]|$)") out = out (out==""?"":", ") a[i]
        print out }')
    add_fail "$(rel "$VOICE") line $ln: closed-list adjective(s) '$words' used as a bare trait: $txt"
  done < <(grep -nEi "(^|[^A-Za-z])($BARE_ADJ)([^A-Za-z]|\$)" "$VOICE" 2>/dev/null)
}

# ---- G13b The routing table resolves the root's deliverables ------------
gate_G13b() {
  VOICE="$MEM/voice.md"
  need_file "$VOICE" || return
  if [ "$SHORT" = "1" ] && [ "$(onb_state voice)" != "complete" ]; then
    add_note "voice closed '$(onb_state voice)' on the personal path; the voice file is not checked until it closes complete"
    return
  fi
  if [ "$SHORT" = "1" ]; then
    has_heading "$VOICE" "## Routing Table" || add_fail "$(rel "$VOICE"): '## Routing Table' is missing"
    add_note "no run record on the personal path, so the table is not checked against an outputs list"
    return
  fi
  need_file "$RUNREC" || return
  if ! has_heading "$VOICE" "## Routing Table"; then
    add_fail "$(rel "$VOICE"): '## Routing Table' is missing"
  fi
  if ! has_heading "$RUNREC" "### What the outputs are for"; then
    add_fail "$(rel "$RUNREC"): '### What the outputs are for' is missing, so no output type can be routed"
    return
  fi
  section_body "$RUNREC" "### What the outputs are for" > "$TMPD/g13b-out.txt"
  if grep -qE '^[[:space:]]*Deferred:' "$TMPD/g13b-out.txt"; then
    add_note "'### What the outputs are for' is deferred; the routing clause did not run (G12 carries that failure)"
    return
  fi
  # output types: list items, and nothing else. The prose splitter this comment
  # used to describe was withdrawn, because a gate cannot parse prose; a body with
  # no list item is reported as naming no output type rather than guessed at.
  awk '
  function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
  {
    t=trim($0)
    if(t=="") next
    if(t ~ /^[-*+][ \t]/ || t ~ /^[0-9]+[.)][ \t]/){
      sub(/^[-*+][ \t]+/,"",t); sub(/^[0-9]+[.)][ \t]+/,"",t)
      items[++ni]=t
    }
  }
  END{
    for(i=1;i<=ni;i++) print items[i]
  }' "$TMPD/g13b-out.txt" | sed 's/[.;:]*$//' | sed 's/^[Tt]he //' > "$TMPD/g13b-types.txt"

  # The answer is a list, one output type per line, because this gate reads it
  # as a list. Version 4 let it be prose and split on punctuation; the first
  # real root answered in a sentence and the split produced eight "output
  # types", among them "see memory/voice.md" and "todos/current.md", each
  # reported as an unrouted deliverable. A gate cannot parse prose, and a
  # routing table checked against garbage is worse than one not checked.
  if [ ! -s "$TMPD/g13b-types.txt" ]; then
    add_fail "$(rel "$RUNREC"): '### What the outputs are for' names no output type as a list item; write one output type per line as a dash list, because the routing table is checked row by row against it"
    return
  fi
  if ! has_heading "$VOICE" "## Routing Table"; then return; fi
  section_body "$VOICE" "## Routing Table" > "$TMPD/g13b-rt.txt"
  awk "$AWK_LIB"'
  { L[NR]=$0 }
  END{
    for(i=1;i<=NR;i++){
      if(!isrow(L[i])) continue
      if(is_sep(L[i])) continue
      if(i<NR && is_sep(L[i+1])) continue
      m=ncells(L[i],c)
      if(m>=1 && c[1]!="") print tolower(c[1])
    }
  }' "$TMPD/g13b-rt.txt" > "$TMPD/g13b-rows.txt"
  while IFS= read -r ot; do
    [ -n "$ot" ] || continue
    otl=$(printf '%s' "$ot" | tr 'A-Z' 'a-z')
    if ! awk -v t="$otl" 'index($0,t)>0 || index(t,$0)>0 {found=1} END{exit(found?0:1)}' "$TMPD/g13b-rows.txt"; then
      add_fail "$(rel "$VOICE"): '## Routing Table' has no row for the output type '$ot'"
    fi
  done < "$TMPD/g13b-types.txt"
}

# ---- G14 Voice authority -------------------------------------------------
gate_G14() {
  VOICE="$MEM/voice.md"
  need_file "$VOICE" || return
  if [ "$SHORT" = "1" ] && [ "$(onb_state voice)" != "complete" ]; then
    add_note "voice closed '$(onb_state voice)' on the personal path; the voice file is not checked until it closes complete"
    return
  fi
  for k in voice-authority-name voice-authority-basis voice-confirmation-date; do
    v=$(kv "$VOICE" "$k")
    if [ -z "$v" ]; then
      add_fail "$(rel "$VOICE"): '$k:' missing or empty"
    fi
  done
  # An identifiable but unqualified confirmer is the residual risk F17 names,
  # so the name has to be a person and the basis has to say something the name
  # does not. "name: account owner / basis: account owner" passed before.
  van=$(kv "$VOICE" "voice-authority-name")
  vab=$(kv "$VOICE" "voice-authority-basis")
  if [ -n "$van" ]; then
    if [ "$SHORT" = "1" ] && [ -n "$OWNER_LC" ] && [ "$(printf '%s' "$van" | tr 'A-Z' 'a-z')" = "$OWNER_LC" ]; then
      : # the root's owner, by the declared name, whatever its shape
    elif ! printf '%s' "$van" | grep -qE "$PERSON_GRAMMAR"; then
      add_fail "$(rel "$VOICE"): 'voice-authority-name: $van' does not name a person; a role is not an authority anyone can identify"
    elif printf '%s' "$van" | grep -qE "$NONPERSON_TAIL"; then
      add_fail "$(rel "$VOICE"): 'voice-authority-name: $van' names a role or a body, not a person. An identifiable but unqualified confirmer is the residual risk, and an unidentifiable one is worse"
    else
      build_person_registry
      if [ -s "$TMPD/people.txt" ]; then
        vpn=$(printf '%s' "$van" | grep -oE "$PERSON_GRAMMAR" | sed 's/^[^A-Za-z]*//' | head -1)
        if [ -n "$vpn" ] && ! grep -qixF "$vpn" "$TMPD/people.txt"; then
          add_fail "$(rel "$VOICE"): 'voice-authority-name: $van' is not recorded as a person anywhere in this run; the confirming authority appears in who-confirms or in a must-reach person row"
        fi
      fi
    fi
    # On the personal path the owner is the authority on their own voice and
    # no domain of authority is owed; the basis only has to say more than the
    # name. The first confirmed personal voice failed here for saying exactly
    # that in words the domain list does not contain.
    owner=$(kv "$AGENTS" "root" 2>/dev/null | tr 'A-Z' 'a-z')
    if [ "$SHORT" = "1" ] && [ -n "$owner" ] && [ "$(printf '%s' "$van" | tr 'A-Z' 'a-z')" = "$owner" ]; then
      lab=$(printf '%s' "$vab" | tr 'A-Z' 'a-z')
      if [ -z "$vab" ] || [ "$lab" = "$owner" ]; then
        add_fail "$(rel "$VOICE"): 'voice-authority-basis' is empty or repeats the name; say that this is the owner's own voice"
      else
        add_note "the root's owner is the authority on their own voice; no domain of authority is owed"
      fi
    elif [ -n "$vab" ]; then
      lan=$(printf '%s' "$van" | tr 'A-Z' 'a-z')
      lab=$(printf '%s' "$vab" | tr 'A-Z' 'a-z')
      if [ "$lan" = "$lab" ]; then
        add_fail "$(rel "$VOICE"): 'voice-authority-basis' repeats the name and records no basis for authority in any domain"
      elif printf '%s' "$lab" | grep -qF "$lan"; then
        add_fail "$(rel "$VOICE"): 'voice-authority-basis' only restates the name and records no basis for authority in any domain"
      else
        # A basis has to name what the authority rests on, not assert that it
        # exists. "she signs off" and "is the right person" are assertions.
        nw=$(printf '%s' "$vab" | wc -w | tr -d ' ')
        if [ "${nw:-0}" -lt 6 ]; then
          add_fail "$(rel "$VOICE"): 'voice-authority-basis: $vab' is too thin to be a basis; name the domain and what the authority rests on"
        elif ! printf '%s' "$lab" | grep -qE "(sign-?off|approv|owns|accountab|responsib|authorit|mandate|named in|appointed|delegat|holds|remit|per the|under the|section|brief|contract|policy|role of|as the)"; then
          add_fail "$(rel "$VOICE"): 'voice-authority-basis: $vab' asserts authority without naming what it rests on"
        fi
      fi
    fi
  fi
  d=$(kv "$VOICE" "voice-confirmation-date")
  if [ -n "$d" ] && ! printf '%s' "$d" | grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}'; then
    add_fail "$(rel "$VOICE"): voice-confirmation-date '$d' is not a YYYY-MM-DD date"
  fi
  basis=$(kv "$VOICE" "voice-authority-basis")
  fb=$(kv "$VOICE" "voice-authority-fallback")
  if printf '%s %s' "$basis" "$fb" | tr 'A-Z' 'a-z' | grep -q 'fallback'; then
    s=$(kv "$VOICE" "voice-authority-fallback-signoff")
    [ -n "$s" ] || add_fail "$(rel "$VOICE"): the authority is a fallback but 'voice-authority-fallback-signoff:' is missing or empty"
  fi
  add_note "the archiving of rejected attempts is not mechanical and is not checked here"
}

# ---- G15 Audit ran independently ----------------------------------------
gate_G15() {
  need_file "$AUDIT" || return
  ic=$(kv "$AUDIT" "independent-context")
  rv=$(kv "$AUDIT" "reviewers")
  case "$ic" in
    yes|no) ;;
    '') add_fail "$(rel "$AUDIT"): 'independent-context:' missing or empty" ;;
    *) add_fail "$(rel "$AUDIT"): independent-context '$ic' is not yes or no" ;;
  esac
  [ -n "$rv" ] || add_fail "$(rel "$AUDIT"): 'reviewers:' missing or empty"
  if [ "$ic" = "no" ]; then
    if [ ! -f "$CLOSE" ]; then
      add_fail "$(rel "$CLOSE"): missing: independent-context is no and the close report must say so"
    else
      section_body "$CLOSE" "## Audit disposition" > "$TMPD/g15.txt"
      nb=$(nonblank_count "$TMPD/g15.txt")
      if [ "$nb" -eq 0 ]; then
        add_fail "$(rel "$CLOSE"): '## Audit disposition' is empty but independent-context is no"
      elif ! grep -qi 'independen' "$TMPD/g15.txt"; then
        add_fail "$(rel "$CLOSE"): '## Audit disposition' does not record that the audit was not independent"
      fi
    fi
  fi
}

# Containers a claim can hide in. A rejection has to name at least one place it
# was looked for, which is what distinguishes a search from an assertion that one
# happened, and a place is a container, a URL, a file or an evidence row: the
# check below counts all four and requires one, not two containers.
CONTAINER_GRAMMAR='body|main text|heading|section|notes?|speaker note|comment|footnote|endnote|tracked change|revision|appendix|header|footer|caption|alt text|metadata|margin|annotation|slide|transcript|attachment|table|figure|chart|abstract|summary|title|index|glossary'

# ---- G16 Findings disposed of, disputes preserved -----------------------
gate_G16() {
  need_file "$AUDIT" || return
  if table_get "$AUDIT" "Findings" "Finding,Disposition,Deciding check,Where checker looked,Bound file entry" > "$TMPD/g16.txt" 2>/dev/null; then :; else
    add_fail "$(rel "$AUDIT"): no '## Findings' table with the columns Finding, Disposition, Deciding check, Where checker looked, Bound file entry"
    return
  fi
  while IFS="$US" read -r ln fid disp deciding looked bound; do
    [ -n "$ln" ] || continue
    if [ -z "$deciding" ] || [ "$deciding" = "-" ]; then
      add_fail "$(rel "$AUDIT") line $ln: finding $fid has an empty 'Deciding check'"
    fi
    case "$disp" in
      accepted) ;;
      rejected)
        if [ -z "$looked" ] || [ "$looked" = "-" ]; then
          add_fail "$(rel "$AUDIT") line $ln: finding $fid is rejected with an empty 'Where checker looked'"
        else
          # Rejecting a finding costs a real search. Searching every container
          # the format has is the run's obligation and is wider than a gate can
          # count: what this checks is that the cell names at least one place,
          # a container, a URL, a file or an evidence row, not merely that the
          # producer asserts a search happened. Round 2 found this recorded as
          # fixed while the gate still tested non-empty.
          # A rejection has to name where the checker looked, specifically
          # enough that someone else can go there. Round 2 established that
          # non-empty is not enough. The count was containers-only until the
          # first real root, whose research-first audit rejected findings by
          # naming evidence files and re-fetched URLs: entirely specific, and
          # zero container words, so thirteen honest rejections failed. A
          # place is now any of the four things a checker can actually name.
          ncont=$(printf '%s' "$looked" | tr 'A-Z' 'a-z' \
            | grep -oE "(^|[^a-z])($CONTAINER_GRAMMAR)([^a-z]|\$)" \
            | sed 's/^[^a-z]*//; s/[^a-z]*$//' | sort -u | wc -l | tr -d ' ')
          nurl=$(printf '%s' "$looked" | grep -oE 'https?://[^ ,;)]+' | sort -u | wc -l | tr -d ' ')
          nfile=$(printf '%s' "$looked" | grep -oE '[A-Za-z0-9_./-]+\.(md|txt|pdf|docx?|pptx?|csv|html?)' | sort -u | wc -l | tr -d ' ')
          nrow=$(printf '%s' "$looked" | grep -oE '\b[EVA][0-9]+\b' | sort -u | wc -l | tr -d ' ')
          nplace=$(( ${ncont:-0} + ${nurl:-0} + ${nfile:-0} + ${nrow:-0} ))
          if [ "$nplace" -lt 1 ]; then
            add_fail "$(rel "$AUDIT") line $ln: finding $fid is rejected but 'Where checker looked' names no place: a rejection names a container, a file, a URL or an evidence row, not that the producer looked"
          fi
        fi
        ;;
      disputed)
        # Trailing punctuation is not part of the path. "memory/design.md,
        # \"Source Assets\" section" named a real file and failed as missing.
        p=$(printf '%s' "$bound" | tr -d '`' | awk '{print $1}' | awk -F'#' '{print $1}' | sed 's/[.,;:]*$//')
        if [ -z "$p" ]; then
          add_fail "$(rel "$AUDIT") line $ln: finding $fid is disputed but 'Bound file entry' names no file"
          continue
        fi
        if ! under_root "$p"; then
          add_fail "$(rel "$AUDIT") line $ln: finding $fid is disputed but '$p' $_ur_why"
          continue
        fi
        t="$ROOT/$p"
        if [ ! -f "$t" ]; then
          add_fail "$(rel "$AUDIT") line $ln: finding $fid is disputed but '$p' does not exist under the root"
        elif ! awk -v id="$fid" 'index($0,"(Disputed:")>0 && index($0,id)>0 {f=1} END{exit(f?0:1)}' "$t"; then
          add_fail "$(rel "$AUDIT") line $ln: finding $fid is disputed but $p carries no '(Disputed: ... $fid' entry"
        fi
        ;;
      *)
        add_fail "$(rel "$AUDIT") line $ln: finding $fid Disposition '$disp' is not accepted, rejected or disputed"
        ;;
    esac
  done < "$TMPD/g16.txt"
}

# ---- preamble_body ------------------------------------------------------
# preamble_body FILE -> every line above the first section heading
# The grammar puts the run record's key lines at the top of the file, above
# `## Copy vantages`. That is the span kv resolves them in, because kv takes
# the first line in the file and nothing precedes the preamble.
#
# The grammar's sections are `##`; a leading `#` is the document's title, which
# nothing forbids. Round 19 found this stopped at any heading, so a titled
# record had an empty preamble and every duplicate in it went unseen. The
# preamble ends where the first section begins.
preamble_body() {
  [ -f "$1" ] || return 1
  awk '
  function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
  { t=trim($0); if(t ~ /^#{2,}([ \t]|$)/) exit; print }' "$1"
}

# strip_comments: drop HTML comments from stdin, and the trailing CR with them.
#
# Comments only. Round 23 added script and style regions here and a reviewer
# showed the cost: with no fence state, a visible `<script>` inside a fenced
# example was eaten, and a closing tag carrying an attribute was not a closer,
# so the rest of the file went with it. Containers are refused by plain_file
# now, so nothing else needs filtering, and a filter with no state cannot be
# wrong about what encloses what.
#
# This is the whole of the filtering this harness does, and it is deliberately
# small. Text inside an HTML comment is not in the file as far as anything
# reading it is concerned, and the rule for finding it is closed: it starts at
# `<!--` and ends at `-->`.
#
# Rounds 19 through 21 tried to filter the rest of what a renderer hides, and
# each round shipped a gap in exactly the part of the grammar it had just
# added: a fence toggle that any tilde could close, then a fence rule that
# missed indented code, then an HTML-block rule that ended `<script>` at a
# blank line and read an autolink as a tag. That is a Markdown implementation,
# and this harness has no business being one. See plain_file for what
# replaced it.
strip_comments() {
  awk '
  {
    line=$0
    sub(/\r$/, "", line)
    if(inc){
      k=index(line,"-->")
      if(k==0) next
      line=substr(line,k+3); inc=0
    }
    while(1){
      k=index(line,"<!--")
      if(k==0) break
      head=substr(line,1,k-1); tail=substr(line,k+4)
      e=index(tail,"-->")
      if(e==0){ line=head; inc=1; break }
      line=head substr(tail,e+3)
    }
    print line
  }'
}

# plain_file FILE WHAT
# The records this harness reads are plain text, and this refuses one that is
# not. No fence, no raw HTML tag or declaration, no HTML comment, no line
# indented four columns counting a tab as four.
#
# Rounds 19 to 23 tried five times to tell a declaration apart from an example.
# Each version knew the constructs the round before had named and not the next
# one: a tilde closing a backtick, indented code, a script ending at a blank
# line, an autolink read as a tag, a fence at the content column of a list
# item, a comment mid-line, a comment-hidden decoy heading disabling the guard
# for the real section below, and finally `pre`, `textarea`, `div`, `CDATA` and
# a processing instruction, which is CommonMark's HTML-block types 1 and 6 with
# two of six members handled. Every one of those was a partial Markdown
# implementation missing its next construct.
#
# This has no state at all. It does not pair a fence with its closer, track
# nesting, or care what order anything comes in, because it never has to decide
# what a construct contains: a line that could open one fails the file. Five
# templates carry none of these, and the message names what to remove.
plain_file() {
  # $3, optional: "keep-comments", for a file the root writes prose in. The
  # shipped competitor template carries six HTML comments of its own, so
  # refusing them there left no compliant way to finish it. Containers are
  # still refused: uncovering that file entirely, which is what round 25 did,
  # let a competitor set written inside a fence, a div or a pre close the key.
  _f=$1; _what=$2; _keep=${3:-}
  [ -f "$_f" ] || return 0
  _bad=$(awk -v KEEP="$_keep" '
  function width(s,   i,c,n){ n=0
    for(i=1;i<=length(s);i++){ c=substr(s,i,1)
      if(c==" ") n++; else if(c=="\t") n+=4-(n%4); else break }
    return n }
  # a byte-order mark ahead of a fence made the fence invisible to this
  BEGIN{ bom=sprintf("%c%c%c",239,187,191) }
  {
    line=$0; sub(/\r$/,"",line)
    if(NR==1 && substr(line,1,3)==bom) line=substr(line,4)

    if(KEEP=="keep-comments"){
      # Comments are the root own provenance markers in this file, so they come
      # out of the line before anything else reads it. Otherwise `<!--` reads as
      # a declaration and the shipped template is refused, which is the defect
      # round 24 found. Containers are still refused below, because round 25
      # uncovered this file entirely and a set written inside a fence, a div or
      # a pre closed the key.
      if(inc){ k=index(line,"-->"); if(k==0) next; line=substr(line,k+3); inc=0 }
      while(1){
        k=index(line,"<!--"); if(k==0) break
        head=substr(line,1,k-1); tail=substr(line,k+4)
        e=index(tail,"-->")
        if(e==0){ line=head; inc=1; break }
        line=head substr(tail,e+3)
      }
    } else if(index(line,"<!--")>0){
      # only `<!--` opens a comment. A bare `-->` is an arrow in prose, and
      # calling it a comment named a construct the writer had not written.
      print NR ": an HTML comment"; exit
    }

    if(line ~ /^[ \t]*$/) next
    ind=width(line)
    body=line; sub(/^[ \t]+/,"",body)

    # A construct opens at the content column of whatever contains it, and a
    # container can contain a container. Round 24 stripped one list marker for
    # the fence test only; round 25 stripped one for every test and still could
    # not see a fence or a tag behind `>` or behind a second marker. So every
    # marker comes off, list and blockquote alike, until none is left.
    quoted=0; rest=""
    while(1){
      if(body ~ /^>[ \t]?/){ quoted=1; sub(/^>[ \t]?/,"",body); sub(/^[ \t]+/,"",body); continue }
      if(body ~ /^([-*+]|[0-9]{1,9}[.)])[ \t]/){
        sub(/^([-*+]|[0-9]{1,9}[.)])[ \t]/,"",body)
        rest=body; sub(/^[ \t]+/,"",body); continue }
      break
    }

    if(ind<=3 && (substr(body,1,3)=="```" || substr(body,1,3)=="~~~")){ print NR ": a code fence"; exit }
    if(ind<=3 && body ~ /^<[!?\/]/){ print NR ": a raw HTML declaration"; exit }
    if(ind<=3 && body ~ /^<[A-Za-z][A-Za-z0-9-]*([ \t>\/]|$)/){ print NR ": a raw HTML tag"; exit }
    # measured after the markers, or `-     value` is code to a reader and a
    # plain line to this. The marker loop eats the whitespace, so what it ate
    # is measured too.
    if(ind>=4 || width(rest)>=4){ print NR ": a line indented four columns or more"; exit }
    # A blockquote is quoted prose to a reader and a live line to kv and
    # table_get, which read the text after the marker. The records this harness
    # reads do not quote, so they do not get to carry one.
    if(quoted){ print NR ": a blockquote"; exit }
  }' "$_f" 2>/dev/null)
  [ -n "$_bad" ] || return 0
  add_fail "$(rel "$_f"): line $_bad; $_what is read as plain text, and a declaration written inside a fence, a comment, raw HTML or indented code cannot be told from the real thing"
}

# dup_keys FILE KEYSET MESSAGE [REPORT_AS]
# Counts a key the way kv counts it: the text before the first colon on the
# raw line, trimmed. Only the keys in KEYSET, because a duplicate is ambiguous
# where something asks for it and nowhere else, and a rule that counts every
# colon-shaped line refuses two citations as a repeated `https` key.
dup_keys() {
  _f=$1; _keys=$2; _msg=$3; _as=${4:-$1}
  [ -f "$_f" ] || return 0
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    n=${line%%"$US"*}; k=${line#*"$US"}
    add_fail "$(rel "$_as"): key $k: appears $n times; $_msg"
  done < <(awk -v KEYS="$_keys" '
    function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
    BEGIN{ n=split(KEYS,a," "); for(i=1;i<=n;i++) want[a[i]]=1 }
    {
      idx=index($0,":")
      if(idx>0){ k=trim(substr($0,1,idx-1)); if(k in want) print k }
    }' "$_f" 2>/dev/null | sort | uniq -c \
      | awk -v US="$US" '$1 > 1 { print $1 US $2 }')
}

# The record answers a file-scoped key once, in the section that declares it.
# Three ways to break that, and kv resolves the wrong line in every one:
# twice inside the span, once inside and again above it, or nowhere inside
# while present somewhere else. Round 19 found only the first two were checked,
# so a key declared outside its span, or a span left empty, turned the guard
# off rather than narrowing it.
#
# These take presence from has_key rather than a non-empty value, because a key
# line with an empty value is present and is what kv would return.

# span_answered_earlier FILE SPANFILE KEYSET SPANNAME
span_answered_earlier() {
  _f=$1; _sp=$2; _keys=$3; _span=$4
  [ -f "$_f" ] && [ -f "$_sp" ] || return 0
  for _k in $_keys; do
    has_key "$_sp" "$_k" || continue
    _sv=$(kv "$_sp" "$_k" 2>/dev/null)
    _fv=$(kv "$_f" "$_k" 2>/dev/null)
    [ "$_fv" = "$_sv" ] && continue
    add_fail "$(rel "$_f"): key $_k: answered above $_span as '$_fv'; kv takes that line and never reaches the one under $_span"
  done
}

# declared_outside_span FILE SPANFILE KEYSET SPANNAME
# Only for keys a gate reads file-scoped: kv reaches outside the span and
# perkey_value does not, so a stray line elsewhere is a declaration for one and
# invisible to the other.
declared_outside_span() {
  _f=$1; _sp=$2; _keys=$3; _span=$4
  [ -f "$_f" ] || return 0
  for _k in $_keys; do
    has_key "$_f" "$_k" || continue
    has_key "$_sp" "$_k" && continue
    add_fail "$(rel "$_f"): key $_k: answered outside $_span, which is where the record declares it; kv takes whichever line comes first and no gate reads the section that should hold it"
  done
}

controlled_sections_unique() {
  # Ambiguity is refused where a reader would resolve it wrongly, so this asks
  # the same questions the readers ask, over the same spans they read.
  #
  # Rounds 14 to 16 fixed what this guard matched and never checked what it
  # covered. Round 17 found the repair had become a third matcher, agreeing
  # with neither parser. Round 18 found the fix for that had scoped only the
  # per-key close: the file-scoped names were still counted over the whole
  # record, so the confirmer's `name:` in the mandatory `### Who confirms and
  # on what basis` was refused, though kv reads the declaration above it and is
  # never confused. Outside the span that declares a key, the same word is
  # prose.
  #
  # Headings are matched the way section_body matches them, over the whole
  # file, because has_heading and section_body both scan the whole file. Feed
  # each loop by redirection: a pipe would run add_fail in a subshell and every
  # failure it recorded would be discarded with it.
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    n=${line%%"$US"*}; h=${line#*"$US"}
    add_fail "$(rel "$1"): $h appears $n times; a heading appears once or the record is ambiguous"
  done < <(awk '
    function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
    { t=trim($0); if(t ~ /^#+([ \t]|$)/) print t }' "$1" 2>/dev/null | sort | uniq -c \
      | awk -v US="$US" '$1 > 1 { c=$1; $1=""; sub(/^ /,""); print c US $0 }')

  preamble_body "$1" > "$TMPD/uniq-preamble.txt" 2>/dev/null
  dup_keys "$TMPD/uniq-preamble.txt" "$G1_KEYS" \
    "kv reads the first and the rest are read by nothing" "$1"
  declared_outside_span "$1" "$TMPD/uniq-preamble.txt" "$G1_KEYS" "the key block above the first section"

  section_body "$1" "## Copy vantages" > "$TMPD/uniq-vantage.txt" 2>/dev/null
  dup_keys "$TMPD/uniq-vantage.txt" "$VANTAGE_KEYS" \
    "kv reads the first and the rest are read by nothing" "$1"
  span_answered_earlier "$1" "$TMPD/uniq-vantage.txt" "$VANTAGE_KEYS" "'## Copy vantages'"
  declared_outside_span "$1" "$TMPD/uniq-vantage.txt" "$VANTAGE_KEYS" "'## Copy vantages'"

  section_body "$1" "## Per-key close" > "$TMPD/uniq-perkey.txt" 2>/dev/null
  dup_keys "$TMPD/uniq-perkey.txt" "$PERKEY_KEYS" \
    "the per-key close resolves the first and the rest are read by nothing" "$1"
}

gate_G17() {
  if [ ! -f "$AGENTS" ]; then
    add_fail "$(rel "$AGENTS"): missing"
    return
  fi
  if ! has_heading "$AGENTS" "## Onboarding"; then
    add_fail "$(rel "$AGENTS"): no '## Onboarding' section; the template ships one and the close rewrites it"
    return
  fi
  onb_section > "$TMPD/g17.txt"
  if grep -qi '^Not onboarded' "$TMPD/g17.txt"; then
    add_fail "$(rel "$AGENTS"): '## Onboarding' still reads as the template shipped it: not onboarded"
    return
  fi
  if [ "$SHORT" = "1" ]; then
    # The personal path: the state lines are the whole record. One per key,
    # a date, and an open key naming what it waits on.
    grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}' "$TMPD/g17.txt" || add_fail "$(rel "$AGENTS"): '## Onboarding' carries no YYYY-MM-DD date"
    for key in about voice design; do
      v=$(onb_state "$key")
      line=$(grep -E "^[[:space:]]*-[[:space:]]*$key:" "$TMPD/g17.txt" | head -1)
      case "$v" in
        "") add_fail "$(rel "$AGENTS"): '## Onboarding' has no line for key '$key'" ;;
        complete) ;;
        provisional)
          printf '%s' "$line" | grep -qi 'owner' || add_fail "$(rel "$AGENTS"): '$key: provisional' names no owner" ;;
        blocked)
          printf '%s' "$line" | grep -qiE 'person|credential|capability' || add_fail "$(rel "$AGENTS"): '$key: blocked' names no blocker as a person, a credential, or a capability" ;;
        *) add_fail "$(rel "$AGENTS"): '$key: $v' is not complete, provisional or blocked" ;;
      esac
    done
    return
  fi
  # The full path: the state lines match the run record's per-key close.
  need_file "$RUNREC" || return
  controlled_sections_unique "$RUNREC"
  plain_file "$RUNREC" "the run record"
  if ! has_heading "$RUNREC" "## Per-key close"; then
    add_fail "$(rel "$RUNREC"): no '## Per-key close' section"
    return
  fi
  missing=0
  for key in $PERKEY_KEYS; do
    v=$(perkey_value "$key")
    if [ -z "$v" ]; then
      if [ "$key" = "competitors" ] && printf '%s' "$(kv "$RUNREC" "competitors-offer")" | grep -q '^not-offered'; then
        continue
      fi
      add_fail "$(rel "$RUNREC"): '## Per-key close' has no line for key '$key'"
      missing=1
      continue
    fi
    case "$v" in
      complete|provisional|blocked) ;;
      unbound)
        # The grammar allows `unbound` for competitors and for no other key, and
        # only where the offer was declined or deferred rather than accepted.
        if [ "$key" != "competitors" ]; then
          add_fail "$(rel "$RUNREC"): per-key close '$key: unbound' is allowed only for competitors"; missing=1
        else
          case "$(kv "$RUNREC" "competitors-offer")" in
            not-now|no) ;;
            yes)        add_fail "$(rel "$RUNREC"): 'competitors-offer: yes' but 'competitors: unbound'; an accepted offer has a set to close"; missing=1 ;;
            not-offered:*) add_fail "$(rel "$RUNREC"): the offer was never made, so no competitors line is owed"; missing=1 ;;
            *)          add_fail "$(rel "$RUNREC"): 'competitors: unbound' but competitors-offer records no declined or deferred offer"; missing=1 ;;
          esac
        fi
        ;;
      *) add_fail "$(rel "$RUNREC"): per-key close '$key: $v' is not complete, provisional, blocked or unbound"; missing=1; continue ;;
    esac
    a=$(onb_state "$key")
    line=$(grep -E "^[[:space:]]*-[[:space:]]*$key:" "$TMPD/g17.txt" | head -1)
    if [ -z "$a" ]; then
      add_fail "$(rel "$AGENTS"): '## Onboarding' has no line for key '$key', which the run record closes '$v'"
    elif [ "$a" != "$v" ]; then
      add_fail "$(rel "$AGENTS"): '## Onboarding' says '$key: $a' but the run record closes '$key: $v'"
    else
      case "$v" in
        provisional) printf '%s' "$line" | grep -qi 'owner' || add_fail "$(rel "$AGENTS"): '$key: provisional' names no owner" ;;
        blocked) printf '%s' "$line" | grep -qiE 'person|credential|capability' || add_fail "$(rel "$AGENTS"): '$key: blocked' names no blocker as a person, a credential, or a capability" ;;
      esac
    fi
  done
}

# ---- G18 No placeholder token survives ----------------------------------
gate_G18() {
  hits=$(grep -rInE '\[name\]|\[Competitor\]' "$ROOT" 2>/dev/null | awk -F: '{print $1":"$2}' | sort -u)
  [ -n "$hits" ] || return
  while IFS= read -r h; do
    [ -n "$h" ] || continue
    file=${h%%:*}
    ln=${h##*:}
    case "$file" in
      "$SECRETS"/*) add_fail "$(rel "$file") line $ln: a placeholder token survives in the credential store"; continue ;;
    esac
    r=$(rel "$file")
    if [ "$file" = "$CLOSE" ]; then
      add_note "$r line $ln: placeholder token in the close report (where exceptions are listed)"
      continue
    fi
    if [ -f "$CLOSE" ] && grep -qF "$r" "$CLOSE" 2>/dev/null; then
      add_note "$r line $ln: placeholder token, listed as an exception in the close report"
      continue
    fi
    add_fail "$r line $ln: a placeholder token ([name] or [Competitor]) survives and is not listed as an exception in the close report"
  done <<G18EOF
$hits
G18EOF
}

# ---- G19 Paths resolve ---------------------------------------------------
gate_G19() {
  ran=0
  if [ -d "$MEM" ] && [ "$(bound_files | wc -l | tr -d ' ')" -gt 0 ]; then
    ran=1
    while IFS= read -r f; do
      [ -n "$f" ] || continue
      r=$(rel "$f")
      while IFS= read -r rec; do
        [ -n "$rec" ] || continue
        ln=${rec%%:*}
        tok=$(printf '%s' "$rec" | sed 's/^[0-9]*://')
        [ -n "$tok" ] || continue
        if ! under_root "$tok"; then
          add_fail "$r line $ln: path '$tok' $_ur_why"
          continue
        fi
        target="$ROOT/$tok"
        if [ ! -e "$target" ]; then
          add_fail "$r line $ln: path '$tok' does not resolve under the root"
        fi
      done < <(awk '
      function trim(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
      function clean(t){
        gsub(/^[("\[<]+/,"",t)
        gsub(/[)"\]>.,;:!?]+$/,"",t)
        return t
      }
      function emit(t,   lt){
        t=clean(t)
        if(t=="") return
        if(index(t,"://")>0) return
        if(index(t,"/")==0) return
        if(t ~ /[ \t]/) return
        lt=tolower(t)
        if(lt=="n/a" || lt=="and/or" || lt=="he/she" || lt=="yes/no" || lt=="either/or") return
        if(t ~ /^[0-9]+\/[0-9]+$/) return
        if(t !~ /^[A-Za-z0-9._~\/-]+$/) return
        if(t !~ /[A-Za-z0-9]/) return
        # This gate asks one question: does a path this root names exist in
        # this root? So only a root-relative path is its business. The first
        # real root showed the old any-token-with-a-slash rule reporting
        # thirty-two failures, none of them a path: bare domains
        # (example.com/pages/about-us), slashed word pairs
        # (plain/minimal, one/two/three), and references to the
        # standards of the composed plugin (standards/conventions.md), which
        # correctly do not resolve under a client root and never should.
        if(t !~ /^(\.\/)?(memory|work|sources|todos|inbox|zArchive)\//) return
        seen[t]=1
        print NR ":" t
      }
      {
        line=$0
        # html comments are markers, not prose: they hold no paths
        while(match(line,/<!--.*-->/)) line=substr(line,1,RSTART-1) " " substr(line,RSTART+RLENGTH)
        if(index(line,"<!--")>0) line=substr(line,1,index(line,"<!--")-1)
        # backticked spans first, then the line with them removed
        rest=line
        while(match(rest,/`[^`]+`/)){
          span=substr(rest,RSTART+1,RLENGTH-2)
          emit(span)
          rest=substr(rest,1,RSTART-1) " " substr(rest,RSTART+RLENGTH)
        }
        n=split(rest,W,/[ \t]+/)
        for(i=1;i<=n;i++) emit(W[i])
      }' "$f" | sort -u -t: -k1,1n -k2,2)
    done < <(bound_files)
  else
    add_note "no bound files under $(rel "$MEM"): the path clause did not run"
  fi

  if [ -d "$SECRETS" ]; then
    n=0
    while IFS= read -r cf; do
      [ -n "$cf" ] || continue
      n=$((n+1)); ran=1
      keys=$(grep -cE '^[A-Za-z_][A-Za-z0-9_]*=' "$cf" 2>/dev/null); [ -n "$keys" ] || keys=0
      empty=$(grep -cE '^[A-Za-z_][A-Za-z0-9_]*=[[:space:]]*$' "$cf" 2>/dev/null); [ -n "$empty" ] || empty=0
      add_note "$(rel "$cf"): key lines=$keys, empty values=$empty"
      if [ "$keys" -lt 1 ]; then
        add_fail "$(rel "$cf"): carries no KEY= lines (the key list is empty)"
      fi
      # An unfilled credential file is legitimate; an unfilled credential file
      # nobody owns is not. Empty values above zero pass only when the root's
      # operating file carries a row whose Blocker names this credential.
      if [ "$empty" -gt 0 ]; then
        cfbase=$(basename "$cf")
        cfstem=${cfbase%.*}
        owned=0
        if [ -f "$OPER" ]; then
          if grep -qiE "(person|credential|capability):[^|]*($(printf '%s' "$cfstem" | sed 's/[][\.*^$/]/\\&/g'))" "$OPER" 2>/dev/null; then
            owned=1
          else
            while IFS= read -r kn; do
              [ -n "$kn" ] || continue
              if grep -qiE "(person|credential|capability):[^|]*$kn" "$OPER" 2>/dev/null; then
                owned=1; break
              fi
            done < <(grep -oE '^[A-Za-z_][A-Za-z0-9_]*' "$cf" 2>/dev/null | sort -u)
          fi
        fi
        if [ "$owned" = "1" ]; then
          add_note "$(rel "$cf"): $empty empty value(s), owned by an operating row naming the credential"
        elif [ "$SHORT" = "1" ]; then
          # The personal path writes no operating file at all: SKILL.md says
          # "the state lines are the record". So there is no row for this clause
          # to find and the failure was unsatisfiable rather than earned, at
          # both ends of the range that first recorded it. Name the credential
          # here instead, which is what the row would have carried.
          _g19keys=$(grep -E '^[A-Za-z_][A-Za-z0-9_]*=[[:space:]]*$' "$cf" 2>/dev/null \
            | sed 's/=.*//' | sort -u | tr '\n' ' ' | sed 's/ *$//')
          add_note "$(rel "$cf"): $empty empty value(s), unowned: ${_g19keys}. The personal path keeps no operating file to carry the row, so the credential is named here"
        else
          add_fail "$(rel "$cf"): $empty empty value(s) and no $(rel "$OPER") row whose Blocker names this credential"
        fi
      fi
    done < <(find "$SECRETS" -type f ! -name '.*' 2>/dev/null | sort)
    [ "$n" -gt 0 ] || add_note "$(rel "$SECRETS") holds no credential files"
  else
    add_note "no $(rel "$SECRETS") directory: the credential clause did not run"
  fi

  if [ "$ran" = "0" ]; then
    set_skip "no bound files and no credential store: nothing to resolve"
  fi
}

# ---- G20 Operating file and close report --------------------------------
gate_G20() {
  if need_file "$OPER"; then
    if table_get "$OPER" "" "Item,Owner,Status,Result and date" > "$TMPD/g20.txt" 2>/dev/null; then
      while IFS="$US" read -r ln item owner status result; do
        [ -n "$ln" ] || continue
        ol=$(printf '%s' "$owner" | tr 'A-Z' 'a-z' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        case "$ol" in
          ''|'-'|'the requester'|'requester'|'the client'|'tbd'|'whoever asked')
            add_fail "$(rel "$OPER") line $ln: row $item Owner '$owner' is not a named person or role" ;;
        esac
        case "$status" in
          gating|blocking|needed|done) ;;
          *) add_fail "$(rel "$OPER") line $ln: row $item Status '$status' is not gating, blocking, needed or done" ;;
        esac
        if [ "$status" = "done" ]; then
          if [ -z "$result" ] || [ "$result" = "-" ]; then
            add_fail "$(rel "$OPER") line $ln: row $item is done but 'Result and date' is empty"
          elif ! printf '%s' "$result" | grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}'; then
            add_fail "$(rel "$OPER") line $ln: row $item is done but 'Result and date' carries no YYYY-MM-DD date"
          fi
        fi
      done < "$TMPD/g20.txt"
    else
      add_fail "$(rel "$OPER"): no table with the columns Item, Owner, Status, Result and date"
    fi
  fi
  if need_file "$CLOSE"; then
    for h in "## Tier" "## Type and scope" "## Destination" "## Per-key close" \
             "## Open headings" "## Gates that failed" "## Audit disposition" "## Outstanding"; do
      if ! has_heading "$CLOSE" "$h"; then
        add_fail "$(rel "$CLOSE"): heading '$h' is missing"
        continue
      fi
      section_body "$CLOSE" "$h" > "$TMPD/g20c.txt"
      nb=$(nonblank_count "$TMPD/g20c.txt")
      [ "$nb" -gt 0 ] || add_fail "$(rel "$CLOSE"): heading '$h' has an empty body"
    done
  fi
}

# ---- G21 Layout stamp agrees with C1 ------------------------------------
# Keep every occurrence, including empty values, so duplicate keys cannot
# disappear in command substitution. Only the declaration frontmatter counts.
g21_scalar() {
  awk -v key="$1" '
    NR == 1 { sub(/\r$/, ""); if ($0 != "---") exit; next }
    { sub(/\r$/, "") }
    /^---[[:space:]]*$/ { exit }
    $0 ~ "^" key ":[[:space:]]*" {
      sub("^" key ":[[:space:]]*", ""); sub(/[[:space:]]*$/, "")
      print "value:" $0
    }
  ' "$AGENTS"
}

gate_G21() {
  local declared_type missing standard expected observed fields count
  if [ ! -f "$AGENTS" ]; then
    set_skip "not a declared Wiser user root: AGENTS.md missing (type, Provides, Wiser constitution citation unavailable)"
    return
  fi
  declared_type=$(g21_scalar type)
  missing=""
  case "$declared_type" in
    value:personal|value:org|value:client|value:department|value:industry) ;;
    *) missing="recognized frontmatter type" ;;
  esac
  if ! grep -qE '^## Provides[[:space:]]*$' "$AGENTS"; then
    missing="${missing}${missing:+, }Provides block"
  fi
  if ! grep -qiF 'Wiser constitution' "$AGENTS"; then
    missing="${missing}${missing:+, }Wiser constitution citation"
  fi
  if [ -n "$missing" ]; then
    set_skip "not a declared Wiser user root: missing $missing"
    return
  fi

  standard="$(dirname "$0")/../../standards/user-root.md"
  if [ ! -r "$standard" ]; then
    add_fail "layout authority unreadable or missing: $standard"
    return
  fi
  # Count mentions, not lines: two declarations on one line are ambiguous too.
  expected=$(awk '
    /^## C1 / { sections++; c=1; next }
    /^## / { c=0 }
    c {
      line=$0
      while (match(line, /current tree version/)) {
        mentions++
        line=substr(line, RSTART+RLENGTH)
        if (line !~ /^ \([0-9]+\)/) bad=1
        else {
          value=line; sub(/^ \(/, "", value); sub(/\).*/, "", value)
        }
      }
    }
    END {
      if (sections != 1 || mentions != 1 || bad || value == "") exit 1
      print value
    }
  ' "$standard") || {
    add_fail "layout authority $standard: expected exactly one C1 current tree version (N); missing, ambiguous, or malformed authority"
    return
  }
  fields=$(g21_scalar layout)
  count=$(printf '%s\n' "$fields" | grep -c '^value:')
  if [ "$count" != "1" ]; then
    add_fail "layout: expected $expected; observed $count frontmatter layout declarations (missing or duplicate)"
    return
  fi
  observed=${fields#value:}
  case "$observed" in
    ''|*[!0-9]*) add_fail "layout: expected $expected; observed '$observed' is not a nonnegative integer"; return ;;
  esac
  # Compare decimal spellings without arithmetic overflow or octal parsing.
  if [ "$(printf '%s' "$observed" | sed 's/^0*//')" != "$(printf '%s' "$expected" | sed 's/^0*//')" ]; then
    add_fail "layout: expected $expected from C1; observed $observed"
    return
  fi
  add_note "layout: expected $expected from C1; observed $observed; stamp agreement only, not every C-clause"
}

# ================================================================== driver

MATCHED=0
while IFS='|' read -r gid gname gfn; do
  [ -n "$gid" ] || continue
  if [ -n "$ONE_GATE" ] && [ "$ONE_GATE" != "$gid" ]; then continue; fi
  MATCHED=1
  run_gate "$gid" "$gname" "$gfn"
done <<DRIVEREOF
$GATES
DRIVEREOF

if [ -n "$ONE_GATE" ] && [ "$MATCHED" = "0" ]; then
  echo "$PROG: no such gate: $ONE_GATE" >&2
  exit 2
fi

TOTAL=$((PASS_N+FAIL_N+SKIP_N))
if [ "$JSON" = "1" ]; then
  printf '{"summary":true,"root":"%s","total":%d,"pass":%d,"fail":%d,"skip":%d,"exit":%d}\n' \
    "$(json_escape "$ROOT")" "$TOTAL" "$PASS_N" "$FAIL_N" "$SKIP_N" \
    "$( [ "$FAIL_N" -eq 0 ] && [ "$SKIP_N" -eq 0 ] && echo 0 || echo 1 )"
else
  echo
  printf '%d gates run: %d passed, %d failed, %d skipped  (root: %s)\n' \
    "$TOTAL" "$PASS_N" "$FAIL_N" "$SKIP_N" "$ROOT"
fi

if [ "$FAIL_N" -eq 0 ] && [ "$SKIP_N" -eq 0 ]; then exit 0; fi
exit 1
