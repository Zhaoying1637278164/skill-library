# Site Kit A contract

`check` walks this file. It is not a tool. Every file in the kit exists to satisfy a line here. Copy this file into `kit/KIT.md` beside the Astro tree. Expand later copies the proven tree into `wiser/skills/Site Author/kit/`.

Prep copy, 2026-09-09, from the Webmaster Playbook Context. This file is the live contract. `check` walks it.

## Engine (v1)

Astro, MIT, static by default. Markdown for articles. MDX allowed where a page needs one island. Tailwind CSS plus `@tailwindcss/typography`. Content Collections with typed schemas. Official sitemap and RSS integrations. Pagefind. One layout. One `src/styles/tokens.css`. Copy-paste islands only where needed; no shadcn library in v1.

## Not v1

Next.js as primary. Astro SSR / authenticated areas. A Node API, queue, or database. Payload / Sanity / Strapi. Tina. Vercel as the kit default. Nested git as default.

## kit.json

Required at the kit-folder root, the envelope's `site/`. Invoke `check` on the envelope; it walks `site/`. Schema:

```json
{
  "kitVersion": "0.1.0",
  "domain": "example-a.test",
  "siteUrl": "http://127.0.0.1:4321",
  "collections": {
    "pages": true,
    "articles": true,
    "authors": true,
    "sections": false,
    "issues": false
  }
}
```

`siteUrl` is required at stand-up, no trailing path, no trailing slash. Solve uses `http://127.0.0.1:4321` on the site being fetched so canonical and OG match the preview. `kitVersion` is this contract's version. `check` fails if it disagrees with this file's current version.

`nav` and `footer` are optional site-owned keys, like `domain`, `siteUrl`, and `collections`, and Upgrade preserves them. The template does not set them. Each, when present, is an array of `{ "label": string, "href": string }`: `label` a non-empty string, `href` a string starting with `/` (a site path), `https://`, or `mailto:`. `check` fails a present key that is not that array. A content job may change those two keys and nothing else in `kit.json`. Absent `nav` leaves the header as Home and RSS. Absent `footer` renders no footer.

`siteName`, also optional and site-owned, is a non-empty string naming the site. When set, it is the `WebSite` name in the JSON-LD, the RSS channel title and the `llms.txt` heading; when absent, those use the index page's title, as before.

## Required SEO slots

Stand-up fails `check` without every row.

| Slot | Where it lives |
|------|----------------|
| `SITE_URL` | `kit.json` `siteUrl`, required at stand-up, no trailing path |
| Title | per-page frontmatter, unique, emitted in `<title>` |
| Meta description | per-page frontmatter, required, emitted as `meta name="description"` |
| Canonical | `SITE_URL` + path, `trailingSlash: 'never'` in the kit, sites do not change this |
| Open Graph | `og:title`, `og:description`, `og:type`, `og:url`; `og:image` from article hero or `public/images/og-default.png` |
| JSON-LD | WebSite + Organization on every page (Organization facts from bound `about` or omitted and labelled, never invented); Article on article routes |
| `robots.txt` | emitted at `/robots.txt` from `kit.json` `siteUrl` (not a static `public/` file) |
| `llms.txt` | emitted at `/llms.txt`, canonical pages only, URLs from `kit.json` `siteUrl` |
| Sitemap | Astro sitemap integration, drafts excluded |
| RSS | articles collection; omitted by `check` only when articles are disabled |
| Redirects | `public/_redirects`; a published slug is not deleted without a row |
| Drafts | `draft: true` excluded from sitemap, RSS, and canonical index |

Routes build as `<slug>.html` (`build.format: 'file'`), so a static host serves them at the slashless URL the canonical names; the default `<slug>/index.html` is redirected to a trailing slash by Cloudflare Pages. A top-level `404.html` ships from `src/pages/404.astro`, marked `noindex` and left out of Pagefind's index; without it Cloudflare Pages serves the homepage for every missing path. The page id `404` is reserved: `check` fails a `src/content/pages/404.md`. `vercel.json` at the kit root and `public/vercel.json` both turn on Vercel's `cleanUrls` with `trailingSlash: false`, which Vercel needs to serve `<slug>.html` at the slashless URL. The first covers an upload of `site/`, the second lands at the root of `dist/`. Cloudflare Pages ignores both. `check` fails a site missing any of the three, so an older site is told to run Upgrade.

A missing description in frontmatter fails `check` rather than shipping an empty meta tag. Empty `pubDate` on an article fails `check`.

## Content vs code

| Agents and content jobs may change | They may not |
|---|---|
| `src/content/**` | `src/components/**`, `src/layouts/**`, `src/pages/**` (routes) |
| `public/images/**` | `astro.config.mjs`, `package.json`, `package-lock.json` |
| `public/llms.txt` when SEO Assets writes it | `src/styles/**`, except `src/styles/tokens.css` when `skills/Designer/` has already gated that token update. Any other write under `src/styles/**` is refused |
| `public/fonts/**` only within a Designer-gated token update | `.github/**`, `KIT.md` copies |
| `kit.json` keys `nav` and `footer`, and `siteName`, only | any other key in `kit.json` |

A request to add a component or edit `astro.config.mjs` is refused. A request to add `src/content/articles/hello.md` with required frontmatter succeeds.

A token update changes the values in `tokens.css`'s `@theme` block and may replace one of the two font slots. The font-source comment is the first statement in the file and may become one `@import url(...)` line loading the site's web fonts from a remote host. The self-hosted slot sits after `@plugin "@tailwindcss/typography";` and before `@theme`, and may become `@font-face` rules whose `src` is `url("/fonts/<file>")` pointing at files in `public/fonts/`. `@font-face` cannot precede `@import`, which is why that slot is separate. A site uses one mechanism or the other. Self-hosting keeps every font request on the site's own origin, and those files are written only within the Designer-gated token update. `check` requires every `url()` inside an `@font-face` rule to be a root-relative `/fonts/` path whose file is present under `public/fonts/`, and it names the file when that path is missing. An absolute `url()` (`http:`, `https:`, or `//`) fails: a font-face must load from `/fonts/` on the site's own origin, and a remote font belongs in the font-source `@import`, if at all. Any other path fails. Where `public/fonts/` holds a `.woff2`, `.woff`, `.ttf`, or `.otf` file, it must also hold a licence file whose name matches licence, license, or OFL, or `check` fails because font files ship without their licence. A remote `@import` with no `@font-face`, and a site that uses no web fonts, still pass. The base and utilities layers below the `@theme` block are kit code: a token update never edits them, and Upgrade replaces them. The role tokens (`--color-title`, `--color-heading`, `--color-meta`, `--color-nav`, `--font-title`, `--font-heading`, `--title-style`, `--text-prose`) default to the palette tokens, so a site that sets only `--color-paper`, `--color-ink` and `--color-link` needs nothing else. The kit's prose colours sit in the utilities layer, beside `@tailwindcss/typography`'s own, so the tokens reach body text and headings on a dark palette as well as a light one. Until 2026-09-24 they sat in the base layer, which the typography plugin's defaults outrank, so prose text rendered in the plugin's slate whatever `--color-ink` said. `check` fails a `tokens.css` that still sets prose colours in the base layer. Upgrade replaces `tokens.css` with the kit defaults, as it replaces every kit file present in the template, so a customised site reapplies its token update after Upgrade; only then do body text and headings show its own ink. Header and footer navigation links carry a 44px minimum target.

## Collections

`pages`, `articles`, `authors` always in the schema. An author may set `type: Organization` for an organisation byline; it defaults to `Person` in the Article JSON-LD. `sections` / `issues` exist in the schema and stay disabled unless stand-up is magazine. A brochure and a magazine are one kit.

## Frontmatter for articles

`title`, `description`, `pubDate`, `author`, `tags`, `draft`. Hero image optional.

## Replication, check, upgrade

`check` compares `kitVersion` to this file, and **fails if a `.git` exists in the envelope or kit folder** (nested git is never the silent default). Fail if any required SEO slot is missing.

`upgrade` archives every kit-owned file it will replace, per `standards/conventions.md` (a `zArchive/` next to the file, except that a file under `src/` archives to `zArchive/src/<its path>/` at the kit root, because a `zArchive/` inside `src/pages/` would build as routes; unless that root declares git history as recovery **and** the site is in a committed current repo), then copies kit code files over and refuses to merge `src/content/**`, `public/images/**` and `public/fonts/**`. Two sites on the same `kitVersion` are maintainable as a class; a site that failed `check` is a foreign site until it is upgraded or declared foreign.

Paths in this contract are relative to `site/`. Envelope `AGENTS.md`, `memory/`, `builds.md`, and Playbooks are outside Upgrade. Kit-owned means everything except `src/content/**`, `public/images/**` and `public/fonts/**`. Those three trees stay byte-identical across Upgrade.

## Git and hosting

Content is file-backed, not CMS-backed. Git is optional plumbing, not the content model. **Never connect the envelope or owning Wiser root to a host.** Host payload is `site/` or `site/dist/`; envelope `memory/` stays local.

No `git init` by default. The kit writes a site `.gitignore` (`node_modules/`, `dist/`, `.astro/`). A site with no git is not a failed stand-up.

Live host is not this contract. Which host is named? Cloudflare Pages, or the requester called the site simple and did not call it managed: load `skills/Cloudflare Pages/`. Vercel, or the requester called the site managed and did not call it simple: load `skills/Vercel Deploy/`. Both hosts, or the requester called it both simple and managed, or the named host disagrees with the word: ask, and do not pick. Neither a host nor simple or managed is stated: ask which it is, and do not pick one. No answer: do not load either. The upload is the kit folder only.

## Optional kit furniture, not jobs

`public/admin/` for Sveltia. Commented `CODEOWNERS`. A path-guard workflow. None are required to pass `check`.

## System dependencies

Node 22.12 or newer (Astro 7's floor). The 2026-09-08 Playbook said 18; current stable Astro 7.3.2 requires `>=22.12.0`. The host runs `npm install` and `npm run dev` in the envelope's `site/` folder. Not wrapped as a Wiser tool.

## Stand-up rules this contract encodes

- Owning root `AGENTS.md` must declare `sites/`. Otherwise stop and name the missing declaration.
- Domain folder is an envelope at `sites/<domain>/`, or `work/<slug>/sites/<domain>/` when it dies with existing work. The root and that work subject must declare `sites/`. The host is lowercase, no scheme, no `www` unless `www` is a distinct property. The kit lives in `site/`.
- A current envelope has `site/kit.json`. A domain-folder `kit.json` without it is the Milestone 1 to 3 shape. Did the requester declare it foreign? Yes: leave it untouched. No, or they do not say: wrap to the envelope. Do not write the current kit until that wrap runs. Neither file means foreign. Stand-up refuses all existing folders and leaves them untouched.
- Do not `git init`.
- First-party kit only. No vendored theme (not AstroWind, not AstroPaper, not a named magazine starter).

## How `check` walks this file

1. Invoke Check on the envelope. Confirm the envelope and kit folder have no nested `.git`; walk `site/` for steps 2 to 5.
2. Read `kit.json`. `kitVersion` matches this file. `siteUrl` has no trailing path or slash. When `nav` or `footer` is present, it is an array of `{label, href}` as this file's kit.json section states.
3. Confirm `trailingSlash: 'never'` in the Astro config.
4. Confirm collections schema includes `pages`, `articles`, `authors`, and disabled `sections` / `issues` unless magazine.
5. For every content file in `pages` and `articles`, required frontmatter is present. Articles: `title`, `description`, `pubDate`, `author`, `tags`, `draft`. `src/styles/tokens.css` carries the kit's `@layer base` and `@layer utilities` blocks, sets its prose colours in the utilities block, and sets none in the base block. An `@font-face` `url()` in that file is a `/fonts/` path on this site whose file exists under `public/fonts/`, a file with `@font-face` rules carries no remote `@import`, no `@import` or `@font-face` rule uses a CSS escape, and a `.woff2`, `.woff`, `.ttf`, or `.otf` there ships with a licence file.
6. After `npm run dev` or `build` plus preview, fetch `/`, one article route, sitemap, RSS (if articles enabled), `/llms.txt`, `/robots.txt`. Homepage `<head>` carries title, meta description, canonical, `og:title`, `og:description`, `og:url`, JSON-LD WebSite + Organization. Canonical and `og:url` use `kit.json` `siteUrl`. Article route additionally carries Article JSON-LD. Drafts are absent from sitemap, RSS, and canonical index.
