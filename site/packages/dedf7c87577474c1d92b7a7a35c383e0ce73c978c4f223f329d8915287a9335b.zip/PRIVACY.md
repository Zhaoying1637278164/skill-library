# Privacy

Shipshape is a file-organisation plugin for Claude Cowork. This page explains what it touches and what it doesn't, in plain terms.

## What it accesses

Only the files and folders on your own computer that you explicitly scope it to (a single folder, a handful of named folders, or the entire local drive, your choice each run). It reaches your computer through Cowork's own device-linking feature, the same mechanism any Cowork session uses to read or write local files, nothing separate or additional is installed.

## What it never touches

OS files, system directories, and anything Cowork's device tools mark as protected are excluded at every scope, along with app-managed folders (mail data files, notebook apps, editor/IDE configuration, browser profiles). See `skills/declutter/references/safety-rules.md` in the plugin source for the exact rules.

## What it sends elsewhere

Nothing. Shipshape makes no external network calls, uses no third-party APIs, and has no MCP connectors. There is no account to create and no API key to configure. All the analysis Claude does happens using Claude's own capabilities within your Cowork session; the plugin itself is just skill instructions, it isn't separate software phoning home.

## What it stores, and where

Each run writes a small log to a `.shipshape` folder inside the location you scoped, on your own computer, so a run can be undone later, even in a different chat. This log records file paths, sizes, and timestamps for files it moved, nothing about their contents. Nothing is uploaded off your device, nothing is retained by Claude or Anthropic beyond the normal handling of any Cowork conversation.

## Deletion

Shipshape never permanently deletes a file during a normal run. What the plan calls "delete" is a move to a trash folder inside the scoped location, reversible until you explicitly ask to empty it.

## Contact

Questions about this plugin's data handling: tony.fisk2340@gmail.com.
