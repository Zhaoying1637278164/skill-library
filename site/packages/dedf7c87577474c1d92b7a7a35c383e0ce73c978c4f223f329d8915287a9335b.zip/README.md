# Shipshape

A Cowork plugin that scans a linked computer's cluttered folders (or the whole drive), learns how you already organise your information, asks a few questions before it assumes anything, then proposes a topic based file structure built from what's actually in there (never a generic template) and reorganises the files once you approve, in whole or in part.

## What it does

Point it at Downloads, Desktop, Documents, the entire drive, or anywhere else that's gotten away from you. It scans for scale first, reads whatever structure you already have for clues about how you like things organised, reports back what it found, and asks a short round of questions about how you actually use the computer before it designs anything. Only then does it propose a structure and show you the whole plan as a page broken into approvable sections, you can wave through all of it or just the parts you're ready for. Nothing gets touched until you say which.

Nothing is ever hard-deleted during that run. What the plan calls "delete" (old installers, confirmed duplicates, stale backups) is actually moved into a trash folder it keeps track of, so the whole run can be undone later, including in a completely different chat that has no memory of the original one. Say "undo the last cleanup" or "rewind the Car folder" and it reverses exactly that, in reverse order, checking nothing else has touched the files since. Permanently emptying the trash is a separate, later, explicit action, that's the only point anything is actually deleted for good.

## Requirements

- Cowork with a computer linked (Settings > Link to this computer, or start a task from the desktop app with a computer selected)
- Nothing else. No accounts, no API keys, no external services.

## Installing

Accept the plugin file from the chat where it was shared, or install it from wherever your team distributes `.plugin` files.

## Using it

Say something like "organise my downloads folder" or "my desktop is a mess, help me clean it up." The skill will ask what's in scope (one folder, several, or the whole drive), scan it, tell you what it found, ask a few questions about how you actually work before designing anything, then show you the full plan broken into sections you can approve individually or all at once. Nothing moves or gets touched until you've said which parts to proceed with, and it finishes by asking if you want anything undone.

### Example prompts

- **"Organise my downloads folder"** — the fastest, smallest starting point. Scopes to Downloads, scans it, asks a couple of quick questions, shows a plan, executes what you approve.
- **"My whole computer's a mess, sort it out by topic"** — scopes to the entire local drive. Shipshape confirms that scope back to you plainly before scanning, since it's a much bigger job, then works through the same staged process.
- **"Undo the last cleanup"** — reverses the most recent run, moving everything back to where it was, checking nothing else has touched the files since.
- **"Rewind just the Car folder from that last run"** — a scoped undo, only reverses the entries that were filed under Car, leaves the rest of that run in place.

## License

Source-available, non-commercial, see `LICENSE`. You're free to install and use this plugin; reselling or redistributing it as part of a paid product needs permission first.

## Privacy

See `PRIVACY.md` for exactly what this plugin accesses, stores, and never touches. Short version: nothing leaves your computer, there are no accounts or external services, and nothing is permanently deleted without a separate, explicit step.

## Support

Found a bug, or something behaved unexpectedly? Open an issue on this repo, that's the best way to get it looked at. For anything you'd rather not post publicly, email tony.fisk2340@gmail.com.

## Maintained by

Anthony Fisk (tony.fisk2340@gmail.com). This is a solo-maintained project, not an open-contribution one, given the license below, pull requests aren't accepted, but bug reports and feature suggestions via Issues are always welcome.

## Notes

- Scope can be a single folder up to the entire local drive, your call. It never wanders outside whatever you scoped, and never scans unprompted.
- OS files, system directories, and anything the device tools mark as protected are never touched, at any scope. Same for app-managed folders (mail data files, notebook apps, editor/IDE config directories, browser profiles).
- Nothing is silently deleted to resolve an ambiguous duplicate, you're always shown the pair and asked. The one exception is a byte-identical file sitting in both Downloads and its real home, that's auto-resolved (Downloads copy trashed) without spending a question on it, but it's still listed in the plan and still only trashed once you approve.
- A folder that looks like it belongs to someone else on the same computer (a partner, family member, housemate) gets asked about up front, not silently skipped and mentioned only at the end.
- The plan is approvable in pieces, not just all-or-nothing, tell it to go ahead with some sections and hold the rest, and you'll see a fresh plan page before every run, no exceptions, even a small repeat cleanup.
- It won't ask you fifty questions about individual files. Folders that already look organised on purpose move together as one unit, and genuinely ambiguous leftovers are capped and parked in a Review folder rather than turned into an endless round of prompts.
- Files that live in cloud storage but aren't actually downloaded to this device yet (OneDrive Files On-Demand, iCloud Drive's "Optimise Mac Storage," Dropbox or Google Drive smart sync) are detected up front, never guessed at mid-run, and listed separately in the plan with a note on how to make them available locally if you want them included next time.
- Every run leaves a log on disk under a `.shipshape` folder at the root you scoped it to, that's what makes undo and scoped rewind possible later, and it's also what a real permanent-delete step reads from if you ever ask it to empty the trash.
- "Empty the trash" defaults to just the most recent run, not everything Shipshape has ever cleared out, say explicitly if you want it to go back further.
