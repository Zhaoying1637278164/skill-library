---
name: undo
description: Reverses a previous Shipshape declutter run, in whole or scoped to just one folder or phase, by replaying its on-disk manifest backwards, and can permanently empty the trash a run left behind. Use when the user says things like "undo the last cleanup", "undo what shipshape did", "put those files back", "rewind [a folder]", "that wasn't right, can you reverse it", or "empty the shipshape trash".
---

# Shipshape: undo and rewind

This works even in a session that has no memory of the original run, because everything it needs lives on disk under `.shipshape/` at the root of whatever folder was originally scoped. Read `../declutter/references/manifest-format.md` first, this skill only makes sense in terms of that format.

## 1. Find the run(s)

List `.shipshape/runs/` under the relevant root (ask the user which folder/root if it isn't obvious, same as the declutter skill does). Files ending `.undone` are already reversed, skip those unless the user is specifically asking about one. If there's more than one eligible run, show them (by date and the phase labels inside) and ask which one, default to the most recent if the user just says "undo the last cleanup."

If no `.shipshape` folder or no eligible runs exist, say so plainly, there's nothing to undo.

## 2. Scope the undo

Ask, if not already clear from the request: the whole run, or just entries matching a phase/folder (filter the manifest's `phase` field, or filter by `dst` prefix for "just undo what went into Car"). Show a quick count of how many files that scope covers before proceeding, so the user isn't approving a number they can't see.

## 3. Confirm before reversing

State plainly what will happen: files move back to where they were, trashed files come back out of trash, nothing is permanently deleted by this step. Get an explicit go-ahead, same bar as the declutter skill, "yes" or "go ahead" counts, silence does not.

## 4. Reverse it

Write a script (Python via `device_bash`) that reads the manifest, filters to the requested scope, and processes matching lines in strict reverse order (last logged, first undone). For each:

- Check the file at `dst` still exists and, where practical, matches the logged size. If it doesn't match, or `src` is already occupied by something else, don't force it, skip that entry and record it as a conflict to report back.
- Move it back to `src`, creating parent folders as needed.
- Track success/skip/error per entry, same as the original execution log.

If the whole run was requested and every entry succeeded, write the `.undone` marker next to that run's manifest. If it was a scoped/partial undo, don't mark the run as done, only whole-run reversals get marked, so the remaining entries stay available to undo later.

## 5. Report

Real numbers: files restored, conflicts skipped and why, and if it was a full run, that it's now marked undone. If there were conflicts, name the specific files so the user can decide manually rather than burying it in a total.

## Emptying trash permanently

A separate, rarer request ("empty the trash", "permanently delete what we cleared out", "I'm confident now, actually delete those installers"). This is the only situation in the whole plugin that calls `device_request_delete_permission`.

1. Default the scope to just the most recent run's trash folder: list it, total it up (file count, size). Only widen to older runs, a stated age, or everything under `.shipshape/trash/` when the user explicitly asks for that broader scope, a plain "empty the trash" means the latest run only.
2. Confirm the total with the user explicitly, this is the one irreversible action in the whole workflow, say that plainly.
3. Call `device_request_delete_permission` scoped to the trash folder, with a short honest reason.
4. Delete, and for any run whose trash is now fully emptied, note that its `.undone`-style trash restore is no longer possible, but the manifest's `move` entries (non-trash) are unaffected and still undoable.
