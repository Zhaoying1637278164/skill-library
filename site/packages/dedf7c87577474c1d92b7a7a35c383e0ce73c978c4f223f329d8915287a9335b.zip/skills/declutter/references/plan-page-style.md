# Building the stage 6 plan page

This is the self-contained fallback for producing a good-looking, usable plan page without depending on anything outside this plugin. If this session has a fuller design skill available for artifacts, prefer that for extra polish, but everything required to produce a page the user will actually want to reopen mid-cleanup is here.

## Structure

A single self-contained HTML file (inline all CSS and JS, no external requests), with these sections in order:

1. **Header**: what was scoped, when, and a one-line scale summary (files scanned, rough size).
2. **Proposed structure**: the topic tree as a nested list, indented to show hierarchy. Name folders the way a person would say them out loud.
3. **Duplicates table**: columns for the file, where each copy sits, size, and which copy is proposed to keep. Include the Downloads auto-resolve cases from `categorization-heuristics.md` here too, marked as already resolved, not as a question.
4. **Not moved**: cloud-only placeholders (with the reason and the fix), anything parked in Review, anything needing a decision only the user can make.
5. **Action plan**: a phased, time-boxed checklist (see below), one section per phase or top-level folder, each independently labelled so a section can be approved on its own.

## Making sections independently approvable

Give each phase or top-level folder its own `<section>` with a clear heading and a short "what happens if you approve this" line. Don't bury this in prose, a user should be able to scan headings alone and know what each section will do.

## Checklist and progress

Render the action plan as checkboxes, one per operation or small batch, grouped under phase headings. Track checked state in a plain JavaScript object in memory (or `localStorage` wrapped in try/catch, since this page may be reopened later), never assume a backend. This is a static file, so keep all logic client side and dependency free, no external scripts.

## Look and feel

Keep it plain and legible over decorative: system font stack (`-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`) is enough, no need to load a web font for this. Use a single accent color for headings, checkboxes, and section borders, and a neutral gray for body text and table lines, both light enough to read the tree structure at a glance and to keep tables scannable. Respect the viewer's light/dark preference with a `prefers-color-scheme` media query rather than assuming light: define text and background colors for both, don't just leave a transparent background.

## Guide lines for the tree

Simple nested `<ul>` markup styled with a left border on each nesting level reads clearly as a folder tree without needing custom SVG or a diagram library, keep it to plain CSS.
