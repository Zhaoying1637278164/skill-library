# Safety rules

These are the rules that make this skill trustworthy to run on someone else's computer. Follow them exactly, they are not suggestions to weigh against convenience.

## Nothing is hard-deleted during a normal run

A normal execution never calls a true delete. Anything the plan calls "delete" is a move to `.shipshape/trash/run-<timestamp>/` instead, preserving the original relative path. This needs no special permission at all, since it's just another move, and it means the whole run stays undoable afterward, including in a later session. See `manifest-format.md` for the exact layout.

True, permanent deletion only happens when the user explicitly asks to empty the trash, and it defaults to a narrow scope: just the most recent Shipshape run's trash, not the full accumulated history sitting under `.shipshape/trash/`. A plain "empty the trash" or "delete what we cleaned up" means that latest run only, say so plainly before doing it. Only widen the scope, older runs too, an age cutoff, everything, when the user actually asks for that explicitly. That, and only that, calls `device_request_delete_permission`, scoped to the trash folder, with a short honest reason. If it's declined or unavailable, leave the trash in place and tell the user.

Removing an empty folder shell left behind after moving its contents out (stage 7's cleanup pass) also needs this same permission on some platforms (`rmdir`/`os.rmdir` can return "operation not permitted" on a connected folder until it's granted), even though nothing inside it is being deleted, just the empty shell. Request it once per session, scoped to the root being cleaned, with the honest reason "removing folder shells left empty by moves, no file contents are being deleted." The grant is session-scoped and does not carry over to a future session, expect to request it again next time even against the same computer.

## Cloud-only and placeholder files (OneDrive, iCloud Drive, Dropbox, Google Drive, etc.)

Any of these sync clients can leave a file listed in a folder without its actual bytes present on disk yet ("Files On-Demand" on Windows, "Optimise Mac Storage" for iCloud Drive, Dropbox/Google Drive "Smart Sync" or "available online only"). A file in that state looks completely normal in a directory listing, same name, same reported size, but a real read or move fails, and it fails the same way every time, not as a transient glitch. Treat this as an expected, cross-platform condition to plan for, not a one-off error to patch around when it happens.

`device_list_dir` can flag `cloudOnly: true` for some of these on macOS, but it's a heuristic and doesn't cover every provider or platform (notably, it does not currently catch Windows OneDrive placeholders), so don't rely on the flag alone to decide a file is safe to touch.

**Do a real read-probe before trusting any file is movable**, as part of stage 2's scan, not as a surprise mid-execution:

1. For the files that are actual candidates for the plan (skip this for files that are obviously staying put), run one batched script via `device_bash` that opens each and reads a small chunk (a few KB is enough), rather than the whole file. Do this as one script covering many files, not one `device_bash` call per file.
2. Any file that raises on that read (on Windows this surfaces as `OSError: [Errno 22] Invalid argument`, other platforms may differ) is a cloud-only placeholder for this purpose, whatever the underlying provider. Tally them separately from the ordinary inventory: count and rough size, so stage 4's report can name them explicitly ("also found 19 files, ~340MB, that are cloud-only and not downloaded to this device yet").
3. Never put a cloud-only file into the executable plan for move or trash. List them in their own clearly labelled section of the stage 5/6 plan ("Not moved: cloud-only files") with a one-line explanation and the relevant fix for whichever provider looks likely (Windows/OneDrive: right-click the file or folder, "Always keep on this device"; iCloud Drive: right-click, "Download Now", or turn off "Optimise Mac Storage" for that folder; Dropbox/Google Drive: right-click, "Make available offline" / "Available offline"). Offer to re-probe just that list once the user says they've synced them, rather than requiring a whole new run.
4. Even with the pre-flight probe, keep stage 7's execution script defensive: catch a read/move failure on any single file, log it as skipped with the reason, and continue the rest of the batch. One placeholder file must never abort or stall the whole run.

## Never touch app-managed folders

These belong to a specific application's internal bookkeeping. Moving or renaming them can break the app, not just misplace a file. Leave in place, don't even propose moving them in the plan:

- Mail data files (`.pst`, `.ost`) and their containing folder
- Notebook app folders (OneNote notebooks, similar)
- Office/app template folders (Custom Office Templates, etc.)
- Editor and tool config directories (`.git`, `.vscode`, `.idea`, `node_modules`, shell profile dotfiles, IDE project metadata like `.idea/workspace.xml`)
- Browser profile and cache folders
- Anything `device_list_dir` reports as `protected`

## Never delete a file you weren't asked to touch

The plan can propose deletions (dead installers, confirmed duplicates, old backups), but each category should be visible in the plan the user approved, not decided silently mid-execution. If a file turns up during execution that wasn't in the approved plan, leave it and note it rather than making a new call on the fly.

## Never delete something to resolve ambiguity

If two files might be duplicates but you're not fully sure (different sizes, similar but not identical names, different modification patterns), that's a "show the user, let them decide" case, not a "pick one" case. The one exception is showing which copy you'd recommend keeping, recommending is fine, silently deleting the other is not.

## Park, don't guess

Any file you can't place with real confidence goes into a "Review" folder inside its original location, not into whichever topic folder seems closest. A wrong guess costs the user more trust than an unsorted file does. Say so plainly in the summary rather than hiding the miss.

## Verify after executing

After running the reorganisation script, always independently re-list the source folders and confirm the result matches what was planned; don't trust the script's own success log alone. Check for folders left empty by the moves and clean those up, but never remove a folder that still has anything in it, including a lone `desktop.ini` type system file, check for real content specifically.

## Idempotent by default

Write the execution script so it's safe to re-run: skip a file that's already gone (already moved), skip a move whose destination already exists rather than overwriting, and keep a running log of moved / deleted / skipped / errored so a partial run can be picked up rather than redone from scratch.

## Never expose sensitive content in the summary

Confirming a file was filed ("moved your driver's licence into ID Documents") is fine. Reading out or summarizing what's inside a health, ID, or financial document is not, unless the user directly asks about that document's contents.
