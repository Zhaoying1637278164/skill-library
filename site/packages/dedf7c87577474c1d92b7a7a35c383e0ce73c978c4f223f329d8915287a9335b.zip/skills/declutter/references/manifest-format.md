# Manifest format

The on-disk record that makes a run undoable, including from a future session that has no memory of this conversation. Both the `declutter` skill (writes it) and the `undo` skill (reads and reverses it) depend on this exact layout. Don't improvise a different shape.

## Layout, under the scoped root (the folder the user granted access to)

```
<root>/.shipshape/
  runs/
    run-2026-09-08T103015Z.jsonl   # one file per execution, append-only while running
    run-2026-09-08T103015Z.undone  # empty marker file, created once a run is fully reversed
  trash/
    run-2026-09-08T103015Z/
      Downloads/OldInstaller.exe   # original relative path, preserved exactly
      ...
```

Use one `runs/run-<UTC ISO 8601 with colons stripped>.jsonl` file per execution. Never share a run file across two separate approved plans, undo needs to be able to reverse one run cleanly without touching another.

## Manifest line format

One JSON object per line (JSONL, not a single JSON array, so a crashed run is still partially readable). Fields:

```json
{"op": "move", "src": "Downloads/Statements20240630.pdf", "dst": "OneDrive/Documents/02 Finance/Bank Statements/Statements20240630.pdf", "phase": "Phase 1: money and admin", "ts": "2026-09-08T10:31:02Z", "size": 2762575}
{"op": "trash", "src": "Downloads/ChromeSetup.exe", "dst": ".shipshape/trash/run-2026-09-08T103015Z/Downloads/ChromeSetup.exe", "phase": "Phase 0: dead weight", "ts": "2026-09-08T10:31:03Z", "size": 12411832}
```

- `op`: `"move"` for a real reorganisation move, `"trash"` for what the plan called a delete, `"skip"` for a planned item that couldn't be carried out (a cloud-only placeholder file, a permission error, a conflict) — log these too, with a `reason` field, so a run's manifest is a complete record of what was attempted, not just what succeeded; the `undo` skill ignores `skip` lines, `"mkdir"` only if a directory was created and is meaningful to reverse (usually not needed, undo can recreate parents automatically)
- `src` / `dst`: paths relative to the scoped root, always forward-slash separated regardless of OS, never absolute paths (a manifest must stay valid if the drive letter or mount point changes between sessions)
- `phase`: the human readable label from the approved plan (a phase name or topic folder name), this is what makes scoped rewind possible, "undo everything filed under Car" is a filter on this field
- `ts`: UTC ISO 8601
- `size`: bytes, used by undo as a sanity check before restoring (if the file at `dst` doesn't match the logged size, something else touched it since, flag rather than silently restore)

## Reversing

Reverse entries in strict reverse order (last line first) within the run. For `op: move`, restore by moving `dst` back to `src`. For `op: trash`, restore by moving the file from inside `.shipshape/trash/run-.../` back to `src`. In both cases, before restoring: if `src` now has something else at it, don't overwrite, report the conflict and skip that one entry, leave everything else in the run to proceed normally.

Once every entry in a run has been successfully reversed (or explicitly skipped with the user's acknowledgement), write the `run-<timestamp>.undone` marker file next to the manifest, empty is fine, its existence is the signal. Never process the same run twice without the user asking again after a `.undone` marker exists, if they do, treat it as a fresh explicit request and say clearly that this run was already undone once.

## Emptying trash for real

Only when the user explicitly asks (e.g. "empty the trash", "permanently delete what we cleared out"): default the scope to just the most recent run's folder under `.shipshape/trash/`, only widen to older runs, a stated age, or everything when the user explicitly asks for that broader scope. Confirm the total with the user, call `device_request_delete_permission` scoped to the trash folder, then delete. This is the only point in the whole workflow that calls a true delete.
