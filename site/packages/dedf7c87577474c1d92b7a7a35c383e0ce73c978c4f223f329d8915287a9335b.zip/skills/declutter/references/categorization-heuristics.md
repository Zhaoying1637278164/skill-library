# Categorization heuristics

Patterns that hold up across a typical personal or small business computer. Use these to sort a scan quickly, not as a rigid taxonomy, always let the user's actual files override the pattern.

## Near-certain junk (propose deleting, still show the total before acting)

- Installer files: `*Setup.exe`, `*Installer.exe`, `*.msi`, especially ones for apps clearly already installed and in use
- Old dated backup archives (`*.zip` with a date in the name, months or years old)
- Orphaned metadata files left behind by an installer (`.winmd`, stray `.tmp`)
- Known sample/demo datasets bundled with software (e.g. a stock "Financial Sample.xlsx", a default Office template file never touched)
- Redundant shortcut files pointing at the same destination (multiple `.ica`/`.rdp`/`.url` files for one session, keep one)

## Duplicates

Two signals, either is enough to flag (not necessarily to auto-resolve):
- Identical file size and very similar name (`Statement.pdf` and `Statement (1).pdf`)
- Identical file size and identical name in two different folders

Always show duplicates as a table for the user to confirm, don't silently pick a winner on documents (financial, legal, ID). It's fine to silently prefer the non-Downloads copy when proposing which one to keep, Downloads is treated as a landing zone, not a home.

**One case resolves automatically, without spending a question on it:** an exact duplicate, identical name and identical size, where one copy sits in `Downloads` and the same file already exists somewhere else. Asking about these costs a question for no real decision, Downloads isn't a home. Auto-resolve to keep the non-Downloads copy and trash the Downloads copy. Still put each one on its own line in the plan's duplicates table so it's visible, just not phrased as a question, and it's still only trashed once stage 6's plan is approved and still sitting in the trash afterward, fully reversible, this shortcut skips the question, never the approval gate. Anything less exact (different size, similar-but-not-identical name, only one copy anywhere) stays a real question, don't stretch the auto-resolve to cover those.

## Financial and admin

Bank/brokerage statements, payslips, insurance policies, tax and invoice trackers, budget spreadsheets, ID documents, consent/privacy forms. These are exactly the files a person will search for under stress later (tax time, a claim, an application), so they earn a properly named folder even if there are only two or three of them. Watch for near-identical filename patterns without an obvious label (a run of dated PDFs with no other name) — these are very often payslips or statements once you check the date cadence, not something to leave unsorted.

## Sensitive content

Health records, ID documents, anything clearly personal-and-private in nature: file these into a clearly labelled private subfolder (do not editorialize the label, "Health" or "ID Documents" is enough). Never summarize their contents back to the user beyond the filename, never delete them without being asked, and never let them be the item that ends up in a generic "Misc" bucket.

## Someone else's files

If a folder or set of files is clearly labelled as belonging to another person sharing the same drive (a partner, a family member, a housemate), don't just quietly leave it and mention it in the closing summary, raise it as one of stage 4's clarifying questions, before anything is designed: name what you found and ask whether to leave it completely alone (the default if they don't say otherwise) or include it in this pass. Whatever they say, carry it into the plan. Never reorganise someone else's stuff on your own judgement call.

## Business / project files

Loose notes, briefs, and assets that share a name, client, or product with an existing folder almost always belong inside that folder, not a new one. Look for the existing folder first before creating a new topic. A folder of scattered files with a consistent internal naming scheme (a client name, a project codename) is a strong signal that folder should become one topic in the new structure, keep it intact rather than splitting it apart.

## Media and photos

Split screenshots (utility, low emotional value, safe to batch-move) from actual photos (personal, never auto-delete, never assume what an unlabelled set is). An unlabelled folder of real photos (camera roll style filenames, a burst of images and videos from one date) should be flagged for the user to name, not guessed at.

## App-managed folders, leave alone

See `safety-rules.md`, this list overlaps but the rule is stronger there: never move contents out of a folder an application manages internally.

## Grouping and question budget: don't ask 50 questions

Most people organise at least some of their own mess on purpose, even if it doesn't look like it at first glance. Respect that before treating individual files inside it as ambiguous.

**Detect atomic groups before asking about anything inside them.** A folder (or a flat run of files) reads as an intentional group when it shares any of: a consistent naming pattern (a client name, project codename, or numbering scheme), a single tight date range, a matching file-type mix that makes sense together (a project's docs + assets), or an existing subfolder structure that's clearly been maintained by hand. Once a folder reads this way, treat it as one atomic unit for the whole workflow: it moves or stays together, as a whole, to wherever it fits topically (or to Review as a whole, if the group's topic itself is unclear). Never ask a separate question about each file inside an atomic group, and never split its contents across multiple destinations without the user explicitly asking for that split. At most, ask one question about the group as a whole ("this looks like your Q3 coaching materials, all one project, file it all under Coaching/Q3?").

**Cap individual clarifying questions at a hard 10.** Across a whole run, ask no more than 10 clarifying questions total for genuinely ambiguous items, using AskUserQuestion's batching (several related categories in one call, multi-select where the choices repeat) rather than one call per file. Once that budget is spent, stop asking: send anything left over straight to Review and say plainly in the report how many were parked that way and why, so nothing gets silently guessed, it's just surfaced as a list instead of a question. A single Review folder the user skims once beats fifty pop-up questions.

**Ask about the pattern, never about a handful of named files.** A question shaped like "what should I do with `Report_final.docx`, `Notes_v2.pdf`, and `IMG_4471.jpg`?" is exactly the failure mode to avoid, it doesn't scale (the next run just has different filenames) and it burns the question budget three files at a time. Instead, name the trait the files share and ask once about the whole category, so one answer resolves every file that matches it, now and on future runs. These are examples of categories worth asking about when they come up, not a mandatory checklist, and not the only categories that can exist:

1. **Numeric or date-only filenames with no other context** (`01-02-2026`, `261230`, `IMG_4471`) — treat as a dated catch-all/inbox, group by the source folder they came from, or route them individually to Review?
2. **Version-looking duplicates** (`Report_final`, `Report_final2`, `Report (1)`) — keep the most recent and trash the rest, keep the whole set together as-is, or flag each group individually?
3. **Generic auto-named files** (`Untitled.pdf`, `Screenshot 2026-03-01`) — default the batch to Review, or guess a placement from source folder/context?
4. **Old but not obviously junk** (an inactive project, old subscription paperwork) — archive into an "Old/Inactive" area by default, or file normally and let recency sort itself out?
5. **Mixed-purpose folders** (photos, invoices, and app exports all dumped together) — split contents out by type/topic, or keep the folder intact as one unit?

**Raise the bar for what counts as "ambiguous" in the first place.** A lone file that clearly matches a near-certain-junk or duplicate pattern from this document doesn't need a question, it goes straight into its category (still shown in the plan, never silently deleted). Reserve actual questions for the cases that genuinely need a human call, phrased at the pattern level as above: an unlabelled photo/video set, a run of conflicting document versions, a naming convention with no obvious meaning, or a whole folder whose organisation is unclear.
