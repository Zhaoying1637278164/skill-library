---
name: declutter
description: Scans a linked computer's messy folders (Downloads, Desktop, Documents, a named folder, or the entire local drive), learns how the user actually organises their information, and proposes a topic based file structure for the user to review and selectively approve before anything is touched. Use when the user says things like "organize my files", "clean up my downloads", "declutter my laptop", "sort my files", "tidy up my desktop/folders", "my files are a mess", or "help me organize my computer".
---

# Shipshape: file declutter and reorganisation

Run this as a guided, multi-turn project, not a single tool call. The deliverable is trust: the user is handing over write access, and eventually delete access, to their own files, so every stage earns that back by showing its work before acting on it.

Work through these eight stages in order. Do not skip ahead, in particular never propose a structure before stage 4's questions are answered, and never touch a file before stage 6's approval.

**Progress tracking:** if using TaskCreate to show progress, create all eight tasks up front, titled exactly "Stage 1: Scope the job" through "Stage 8: Final check and undo", in that order, even for a stage that resolves in one quick question rather than a long tool sequence. Don't skip creating a task for a fast stage and don't renumber around it, the numbers shown to the user must always match this document's 1-8, a shifted or skipped number is a bug even if the work itself was done correctly.

**Standing rule, applies at every stage, no exceptions:** OS files, system directories, and anything `device_list_dir` reports as `protected` are never touched, never listed as candidates, never included in size or mess counts as if they were fair game. This holds regardless of scope, even if the user asks for "the entire drive." Read `references/safety-rules.md` in full before stage 2, not just skimmed, it also covers app-managed folders (mail data files, notebook apps, editor/IDE config, browser profiles) which follow the same never-touch rule even though they aren't OS-owned.

## 1. Scope the job

Ask (AskUserQuestion when the user is present and responsive) what's in scope: a single folder, a handful of named folders, or the entire local drive. If they're unsure, suggest starting with Downloads, it's almost always the worst offender and the fastest visible win, with the option to expand scope in a later pass. If the folder isn't yet connected, use `device_request_folder_access` with a one line reason before listing anything.

"Entire local drive" is a valid answer, but confirm it back plainly ("that'll include everything under your user folder, I'll skip anything OS or app-owned as I go") so the user knows what they actually just agreed to before the scan starts.

## 2. Scan for scale, not yet for structure

Use `device_list_dir` (recursive where the tree is shallow enough, plain listing plus targeted follow ups where it's deep) across the scoped location. Build a real inventory, don't estimate: file counts, rough total size, an approximate split between "obvious clutter" and "already-organised," and anything that reads as sensitive (IDs, health, financial) so it's handled carefully later. This pass is about scale and mess, not yet about sorting individual files.

Once you know which files are actual candidates for moving or trashing later, read `references/safety-rules.md`'s cloud-only section and run its read-probe on those candidates (one batched `device_bash` script, not one call per file). Cloud sync clients (OneDrive, iCloud Drive, Dropbox, Google Drive and similar) can list a file that isn't actually downloaded to this device yet, and a normal read or move fails on it every time, not just occasionally. Tally these separately from the rest of the inventory now, so they show up as their own line in stage 4's report instead of surfacing as a surprise failure mid-execution.

## 3. Read the existing structure before proposing a new one

Before designing anything, look at what the scan turned up for signals of how this particular person already organises information: a per-client or per-property folder pattern, a date-based archive, a naming convention repeated across many files, a folder that's clearly a work-in-progress project. This is the single most useful thing the scan produces, it tells you the shape of the structure to propose, rather than reaching for a generic template. If good structure already exists somewhere, plan to extend it, not replace it.

Form a short working theory ("looks like you file by client," "looks like everything's dumped flat with no structure at all yet") to carry into the next stage rather than silently assuming it.

## 4. Report back, then ask before designing

Tell the user plainly what the scan found: the scale of it, the split between clutter and already-organised, anything sensitive that'll need careful handling, and the organisational pattern you think you're seeing (or the fact there isn't one yet). Then ask questions, informed by what you just found, to understand priorities before proposing anything:

- What do they actually use this computer for, day to day, that the structure should optimise for finding quickly?
- Are there distinct streams of work (a job, a side project, family admin, a hobby) that should stay clearly separated rather than blended?
- Anything time-sensitive or high-stakes they'd want prioritised in this pass (tax time coming up, a move, a specific project) versus stuff that can just be tidied whenever?
- Does the pattern you think you spotted in stage 3 actually match how they think about it, or did you read it wrong?
- If the scan turned up a folder or set of files that reads as clearly belonging to someone else on the same computer (a partner, family member, housemate), ask now whether to leave it completely alone (the default) or include it in this pass, don't just note it in the closing summary without having asked.

Use AskUserQuestion for concrete choices, plain conversation for open ones. This stage is what turns a generic sort into one that fits how this specific person actually works, don't shortcut it even when the answer feels obvious from the file names alone.

## 5. Design the structure

Now propose the topic based folder tree, grounded in the files you actually found and shaped by what you learned in stages 3 and 4. Name folders the way a person would say them out loud, not how a filesystem would ("Car/Insurance", not "automotive_ins_docs"). Call out explicitly, as a visible list, not buried in the tree:

- Duplicate files found (same name and size, or same name in two different places) and which copy you'd keep
- Anything you can't confidently place (goes to a Review folder, never guessed)
- Anything that needs a decision only the user can make (an unnamed photo set, two conflicting versions of the same file)
- Cloud-only files found in stage 2's probe, listed as their own "not moved" section with the reason and how to fix it, never folded silently into the rest

Before treating any individual file as needing a question, read `references/categorization-heuristics.md`'s grouping section: a folder or file run that already reads as an intentional group (consistent naming, one date range, hand-maintained structure) moves as one atomic unit, never file-by-file.

**Hard cap: ask at most 10 clarifying questions this run.** Route anything beyond that straight to Review rather than asking, say plainly in the report how many were parked that way and why, don't quietly keep going past the cap.

**Ask about patterns, not files.** Never phrase a question around a small named batch of specific files ("what should I do with X.doc, Y.doc, and Z.doc?"). If several files share a trait, ask one question about the category so a single answer resolves all of them at once, the same way the "atomic group" rule above resolves a whole folder with one question. `references/categorization-heuristics.md` has the shape to write these in, with worked examples, read it before drafting stage 5's questions.

## 6. Present the plan as a page, get explicit, selective approval

**This stage is never skipped, on any run.** Publish a fresh plan page every single time, before a single file is touched, even when: it's a repeat or routine run, the changes are small, the user already discussed or approved individual items conversationally back in stage 4 or 5, or a plan page was shown earlier in this same session for a different batch. Per-item clarifying answers resolve ambiguity about *what a file is*; they are not the same thing as approving *the batch of operations about to run*, and don't substitute for it. If you catch yourself thinking "they basically already approved this, I can skip straight to stage 7," that's the exact moment this rule is there for.

Publish the plan as a self-contained page (the Artifact tool, if one is available) rather than a wall of chat text. Read `references/plan-page-style.md` for exactly how to build it, structure, sections, checklist behaviour, look and feel, it's written to be enough on its own, this plugin doesn't depend on any other skill being installed to produce a good page. If this session happens to have a fuller design skill for artifacts available, it's fine to lean on that too for extra polish, but never treat it as required. Structure the page in clearly separable, independently labelled sections (by phase, or by top level folder), not one undifferentiated block, so the user can approve some of it and hold back the rest, rather than being forced into an all-or-nothing yes. Include the proposed tree, the duplicates table, the cloud-only "not moved" section when there is one, and a phased, time-boxed action plan they can tick through, since this is a page they'll want to reopen mid-cleanup, not a one-off. If no Artifact tool is available, present the same structure clearly in chat, still broken into separable sections, still every run.

After presenting it, ask directly: approve all of it, or only some sections? Do not move or delete a single file before the user has clearly said which parts to proceed with. "I like the plan, go ahead" approves everything; "do the finance and car folders but hold off on the media stuff" approves a subset, execute only that subset in stage 7 and say plainly what's still pending approval.

## 7. Execute, gated, and always reversible

Nothing in a normal run is ever hard-deleted. "Delete" in the plan means moved to a trash folder inside the scoped root, never `rm`. That means execution needs no special permission for the ordinary case, and every run can be undone later, even in a future session, because the record of what happened lives on the user's disk, not in this conversation.

Read `references/manifest-format.md` before writing the execution script, it defines the on-disk log format both this skill and the `undo` skill depend on. Follow it exactly, undo cannot work if the manifest is inconsistent.

1. Create `.shipshape/trash/run-<timestamp>/` and `.shipshape/runs/` under the scoped root if they don't exist.
2. Write the reorganisation as a script (Python via `device_bash` handles unicode filenames and spacing far more reliably than shell globbing), covering only the approved section(s) from stage 6. For every file: a real move goes to its new home in the proposed structure; a "delete" goes instead to `.shipshape/trash/run-<timestamp>/<original relative path>`, preserving the original relative path so it can be restored exactly. Make it idempotent: skip a file if it's already gone, skip a move if the target already exists, never overwrite. Wrap each file's operation so one failure (a cloud-only placeholder that slipped past stage 2's probe, a permission error) is caught, logged as a `skip` with the reason, and the script moves on rather than aborting the batch.
3. As each operation happens, append a line to `.shipshape/runs/run-<timestamp>.jsonl` per the manifest format, including the phase/topic label from the plan. This is what makes both whole-run undo and scoped rewind ("just undo what went into Car") possible later.
4. Run it, then independently verify: list what's left in the source location, confirm nothing unexpected remains, check for now-empty folders left behind and remove those (never remove a folder that still has content).

True permanent deletion is a separate, rare, later action, only when the user explicitly asks to empty the trash (see the `undo` skill), and only that action calls `device_request_delete_permission`.

## 8. Final check, and close the loop on undo

Report back with real numbers (files moved, files trashed, space that *would* be reclaimed once trash is emptied), any sections still pending approval from stage 6, and the specific open items from stage 5 that still need the user's call (unnamed photo sets, conflicting file versions, anything parked in Review, cloud-only files still waiting to be synced). Then ask directly, every time, whether they want anything undone before moving on, don't wait to be asked. Nothing is permanent yet, trash isn't emptied automatically, so this is a real, low-stakes offer, not a formality.

## Tone

Keep the user's own language for their folders and topics, don't impose generic ones. If this is a repeat run for the same user (a second declutter pass), stages 3 and 4 should go faster and need fewer questions, most of the structure will already exist, so mostly it's routing new clutter into the existing system rather than designing from scratch.
