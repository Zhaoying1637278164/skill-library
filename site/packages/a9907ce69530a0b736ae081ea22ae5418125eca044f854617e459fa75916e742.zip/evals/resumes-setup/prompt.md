/setup
