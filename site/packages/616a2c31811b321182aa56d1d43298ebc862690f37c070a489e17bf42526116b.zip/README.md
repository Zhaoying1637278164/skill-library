# LeadLens for Laravel

LeadLens is a plugin for Claude that helps it review Laravel and PHP backend pull requests the way an experienced backend team lead does. It focuses on the problems that actually break production: authorization gaps, mass assignment, SQL injection, N+1 and unbounded queries, unsafe PostgreSQL migrations on large tables, missing transactions and race conditions on money or status changes, non-idempotent queue jobs, external calls without timeouts, and behavior changes that no test would catch.

Every finding is classified as **Blocker**, **Major**, **Minor**, or **Question**, points to an exact file and line, describes a concrete failure scenario, and proposes a fix. The review ends with a clear verdict and a list of what was actually checked. When you say the review is for a teammate, LeadLens also writes a short, friendly summary you can paste into the pull request.

## What is included

| Component | Where it works | What it does |
|---|---|---|
| `pr-review` skill | Claude (web, desktop, mobile), Cowork, Claude Code | The review workflow, severity rules, and output format |
| Reference checklists | Loaded by the skill when relevant | Security, database and migrations, queues and integrations, architecture, testing |
| `pr-reviewer` agent | Claude Code | An independent reviewer subagent that reviews a branch or diff without editing it |

## Usage

In any Claude app, share a diff, changed files, or a pull request and ask:

- "Review this PR before I merge it."
- "Is this migration safe to run on a 50 million row table?"
- "Review this for my junior developer and write a friendly summary."

In Claude Code, you can also ask Claude to delegate to the reviewer agent:

- "Use the pr-reviewer agent to review this branch against main."

## Project conventions win

If your repository has its own rules (`CONTRIBUTING.md`, `CLAUDE.md`, `project_brain.md`, or ADRs under `docs/adr/`), the skill reads them first, and they override the defaults in the checklists.

## What this plugin runs and sends

LeadLens contains only Markdown instructions. It has no hooks, no MCP servers, no scripts, and no network calls, and it sends no data anywhere. In Claude Code, the `pr-reviewer` agent may run your project's own local tooling (`git diff`, `php artisan test`, Pest or PHPUnit, PHPStan, Pint) to verify its findings. It is instructed never to run migrations against a real database, modify files, commit, or push.

See the full [Privacy Policy](PRIVACY.md).

## Support and security

- Questions, bugs, and feature requests: [GitHub Issues](https://github.com/absalomovutkirbek-arch/leadlens-laravel/issues)
- Security vulnerabilities: report privately as described in [SECURITY.md](SECURITY.md)

## License

MIT. See [LICENSE](LICENSE).
