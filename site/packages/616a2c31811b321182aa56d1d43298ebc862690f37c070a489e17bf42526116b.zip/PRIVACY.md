# Privacy Policy — LeadLens for Laravel

Last updated: September 26, 2026

LeadLens for Laravel ("the plugin") is a plugin for Claude that helps review Laravel and PHP pull requests. This policy describes what data the plugin handles.

## Summary

The plugin collects no data, stores no data, and sends no data anywhere. It has no backend service, no connectors, no MCP servers, no hooks, no scripts, no analytics, and no network calls.

## What the plugin consists of

The plugin contains only Markdown instructions: one skill with reference checklists, and one agent definition for Claude Code. These instructions tell Claude how to review code. They run entirely inside the user's own Claude session.

## Data the plugin handles

- **Code and diffs you share.** When you ask Claude to review code, Claude reads the code, diffs, or files you provide in your conversation, or, in Claude Code, files in your local repository. The plugin does not ask for personal data. If your code happens to contain personal data, it stays within your Claude conversation and your own machine.
- **Local tools in Claude Code.** The `pr-reviewer` agent may run your project's own local tools (for example git, your test suite, PHPStan, and Pint) on your machine to verify findings. Their output stays in your session.

The plugin's author does not receive, see, or store any of this data.

## Data collection, retention, and sharing

- Collection: none.
- Retention: none. The plugin has no service that could retain data.
- Sharing with third parties: none.
- Access to Claude memory, chat history, or uploaded files beyond what you share for the review: none.

Your conversations with Claude are governed by Anthropic's own privacy policy: https://www.anthropic.com/legal/privacy

## Children

The plugin is a professional developer tool and is not intended for users under 18.

## Changes

If a future version of the plugin changes how data is handled, this policy will be updated before that version is published, and the change will be visible in this repository's history.

## Contact

Questions about this policy: open an issue at https://github.com/absalomovutkirbek-arch/leadlens-laravel/issues
