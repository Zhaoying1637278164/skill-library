# Security Policy

## Reporting a vulnerability

Please do not report security issues in public GitHub issues.

Report them privately through GitHub's private vulnerability reporting: open the repository's **Security** tab and select **Report a vulnerability**, or go to https://github.com/absalomovutkirbek-arch/leadlens-laravel/security/advisories/new

Include what you found, the steps to reproduce it, and the version of the plugin (from `.claude-plugin/plugin.json`).

## What to expect

- Acknowledgement within 3 business days.
- An initial assessment within 7 business days.
- A fix released as a new plugin version as soon as practical, with credit to the reporter if they wish.

## Scope

The plugin contains only Markdown instructions and runs no code of its own. Relevant reports include instructions that could lead Claude to take unsafe actions, to disclose data it should not, or to run commands the README does not disclose.
