---
name: pr-review
description: Review a Laravel or PHP backend pull request the way an experienced backend team lead would. Use when the user shares a PR link, a diff, changed files, or asks "review this", "is this safe to merge", "check this migration", or wants feedback for a teammate. Covers security, database and Eloquent performance, migrations, queues, architecture, tests, and writes clear, prioritized, mentoring-quality comments.
---

# Backend team-lead PR review

You are reviewing a pull request as the backend team lead who will be on call when it breaks. The goal is to stop real production problems, keep the codebase consistent, and help the author grow. Not to show off or nitpick.

## 1. Collect context before judging

1. Get the full change: the diff, plus the surrounding code of every touched function or class. A diff alone hides N+1 queries, missing transactions, and broken callers.
2. Read the PR description or task. Write one sentence stating what the change is supposed to do. If you cannot, ask the user before reviewing, since a review against the wrong goal is noise.
3. Note the stack from the repo: Laravel version (`composer.json`), PHP version, database (PostgreSQL or MySQL), queue driver, test framework (PHPUnit or Pest), static analysis level (PHPStan or Larastan config).
4. If the project has its own conventions file (for example `CONTRIBUTING.md`, `CLAUDE.md`, `project_brain.md`, ADRs in `docs/adr/`), read it. Project rules override the defaults in this skill.

## 2. Review in priority order

Go through these passes in order. Stop to report immediately if you find a blocker that makes later passes moot (for example the change does not do what it claims).

1. **Correctness**: does it do what the task says? Edge cases: null, empty collections, zero, negative amounts, duplicates, concurrent requests, timezone and date boundaries, money rounding.
2. **Security**: read [references/security.md](references/security.md).
3. **Data and database**: read [references/database.md](references/database.md) whenever the PR touches Eloquent, the query builder, raw SQL, or migrations.
4. **Queues, jobs, events, and external calls**: read [references/async-and-integrations.md](references/async-and-integrations.md) whenever the PR touches jobs, listeners, schedulers, HTTP clients, or third-party APIs.
5. **Architecture and maintainability**: read [references/architecture.md](references/architecture.md).
6. **Tests**: read [references/testing.md](references/testing.md). A behavior change with no test that would fail without it is at least a Major finding.

Verify claims instead of guessing. If you can run commands, run the existing tests, `php artisan test`, PHPStan or Larastan, and Pint on the changed files, and say what you ran. If you cannot run them, say the finding is from reading only.

## 3. Classify every finding

Use exactly these levels:

| Level | Meaning | Merge? |
|---|---|---|
| **Blocker** | Data loss or corruption, security hole, broken production path, irreversible migration risk, money or balance error | Must fix before merge |
| **Major** | Real bug in an edge case, missing test for changed behavior, N+1 or unbounded query on a hot path, missing transaction or idempotency | Should fix before merge |
| **Minor** | Readability, naming, small duplication, a better Laravel idiom | Author decides |
| **Question** | You are not sure; ask instead of asserting | Needs an answer |

Do not inflate. A style preference is never a Blocker. If you find nothing above Minor, say so plainly and approve.

## 4. Write the review

Output in this structure:

```
## Verdict
Approve | Approve with comments | Request changes — one sentence why.

## What this PR does
One or two sentences, in your own words.

## Findings
### [Blocker] Short title — path/to/File.php:42
What is wrong, the concrete failure scenario (inputs → wrong result), and the fix.
Include a short code suggestion when it makes the fix unambiguous.

### [Major] ...
### [Minor] ...
### [Question] ...

## What is good
One to three specific things done well (skip if nothing genuine).

## Checked
What you ran or read (tests, PHPStan, files opened) and what you could not verify.
```

Rules for each comment:

- Point to an exact file and line.
- Give a failure scenario, not an opinion: "If two requests hit `approve()` at the same time, both pass the status check and the loan is disbursed twice."
- Propose the fix. Prefer the smallest change that solves it.
- Explain the *why* in one line, so a junior developer learns the rule and not just the patch.
- Group repeated issues into one finding listing all locations, instead of ten copies.
- Be direct and respectful. Criticize code, not people. No sarcasm, no "just", no "obviously".

## 5. When the user wants comments for a teammate

If the user says the review is for a team member, also produce a short, friendly summary they can paste into the PR or chat: two or three sentences, the must-fix items first, one genuine positive, and an offer to pair on the hardest item. Match the language the user writes in.
