# Architecture and maintainability

Follow the project's existing architecture first. Only suggest structural changes when the current PR makes a real problem worse, and mark them Minor unless they cause bugs.

## Placement of logic
- Controllers stay thin: validate (Form Request), authorize, call one service or action, return a response or Resource.
- Business rules live in one place (service, action, domain class). Flag rules duplicated across controller, job, and command.
- In Hexagonal or Clean Architecture projects: domain code does not import Eloquent, `Request`, facades, or HTTP clients; infrastructure implements interfaces (ports) defined in the domain; dependency direction points inward.
- Framework-agnostic logic receives dependencies through the constructor, not through facades or `app()` calls deep inside, so it can be unit-tested.

## Types and contracts
- New code has parameter, return, and property types. Arrays with meaning become DTOs or value objects when they cross a layer boundary.
- Enums (PHP 8.1+) replace magic strings and integers for statuses.
- New code passes the project's PHPStan or Larastan level without new baseline entries. Adding to the baseline to hide a new error is a Major finding.
- Nullable returns are handled by every caller.

## API design
- Responses go through API Resources, so internal columns are not exposed by accident.
- Breaking changes to response shape, status codes, or field names are versioned or coordinated with consumers.
- Errors return consistent status codes and a stable error format; validation errors are 422, authorization 403, missing 404.
- List endpoints are paginated.

## Readability
- Names describe intent (`approveLoanApplication`, not `process`).
- Functions do one thing; deeply nested conditions become early returns.
- Comments explain *why*, not *what*. Remove commented-out code and leftover debug calls (`dd`, `dump`, `ray`, `Log::debug` spam).
- Config values and magic numbers are named constants or config entries.

## Scope of the PR
- The PR does one thing. Unrelated refactors mixed into a feature make review and rollback harder; suggest splitting them.
- Very large PRs (roughly more than 400 changed lines of logic) get a recommendation to split, with a proposed split.
- Significant design decisions (new pattern, new dependency, new service) should have an ADR or a short note in the PR.
