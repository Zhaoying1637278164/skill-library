# Security checklist (Laravel / PHP)

Check each item that applies to the changed code. Most real incidents come from the first five.

## Authorization
- Every new route, controller action, Livewire action, or API endpoint is covered by a Policy, Gate, `authorize()`, or middleware. Authentication alone is not authorization.
- Route model binding does not leak other tenants' or customers' records: the query is scoped to the current user, branch, or organization (global scope or explicit `where`).
- IDs taken from the request body (not the route) are re-checked for ownership before use.
- Admin-only actions are not reachable by changing a URL or a hidden form field.

## Mass assignment and input
- No `$request->all()` or `$request->input()` passed straight to `create()`, `update()`, or `fill()`. Use `$request->validated()` or `safe()->only([...])`.
- Models do not set `$guarded = []` unless every write path uses validated data.
- Validation rules exist for every new input, including types, max lengths, `exists:` checks, and enum values.
- Money and quantities are validated as decimal strings or integers in minor units, never as floats.

## Injection
- No user input inside `DB::raw()`, `whereRaw()`, `orderByRaw()`, `selectRaw()`, or string-built SQL without bindings.
- Dynamic column or sort names are checked against an allow-list, since bindings cannot protect identifiers.
- No user input reaches PHP functions that run operating-system commands, Laravel's Process facade when it is given one combined command string, dynamic code evaluation, or PHP object deserialization. Pass command arguments as an array and use JSON for untrusted data.
- File paths built from user input are normalized and restricted to a known base directory.
- Blade uses `{{ }}`; any `{!! !!}` output is justified and sanitized.

## Secrets and sensitive data
- No credentials, tokens, keys, or internal hostnames committed. Config reads from `config()` backed by `.env`, not `env()` outside config files.
- Logs, exceptions, and API responses do not contain passwords, tokens, full card or account numbers, national IDs, or full personal records. Use `$hidden` on models and API Resources to shape output.
- Sensitive columns that must be stored are encrypted (`encrypted` cast) where the project requires it.

## Sessions, tokens, and external input
- Webhooks verify a signature or shared secret and reject replays (timestamp or nonce).
- Signed URLs are used for links that grant access without login, with a short expiry.
- Rate limiting exists on login, OTP, password reset, and any expensive or enumerable endpoint.
- File uploads validate MIME type and size, are stored outside the public web root or with random names, and are never executed.
- Outbound HTTP to URLs influenced by users is restricted to known hosts (SSRF).

## Financial and regulated operations
- State changes on balances, payments, loans, or limits run inside a transaction with a row lock (`lockForUpdate()`) or an atomic conditional update, so concurrent requests cannot double-spend.
- Operations that can be retried are idempotent (idempotency key or unique constraint).
- Every state change on regulated data leaves an audit record: who, when, old value, new value.
