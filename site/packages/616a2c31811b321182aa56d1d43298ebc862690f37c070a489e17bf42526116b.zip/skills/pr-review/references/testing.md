# Testing checklist

## Is the change covered?
- Every behavior change has at least one test that would fail without the change. Ask: "if I revert the production code, which test goes red?" If none, it is a Major finding.
- Bug fixes include a regression test that reproduces the original bug.
- Both the happy path and the important failure paths are tested: validation errors, unauthorized user (403), other tenant's record (404 or 403), missing record, external service failure.

## Test quality
- Tests assert outcomes (database state, response body, dispatched jobs, sent notifications), not implementation details such as which private method was called.
- Feature tests use `RefreshDatabase` or `LazilyRefreshDatabase`; tests do not depend on each other's order or on existing seed data.
- Factories create only what the test needs; states make intent readable (`->approved()`, `->overdue()`).
- External calls are faked: `Http::fake()` with `Http::preventStrayRequests()`, `Queue::fake()`, `Bus::fake()`, `Event::fake()`, `Notification::fake()`, `Mail::fake()`, `Storage::fake()`.
- Time-dependent logic freezes time (`$this->travelTo()`, `Carbon::setTestNow()`), and tests boundary dates (end of month, leap day, timezone midnight).
- Money calculations are tested with rounding edge cases.
- Concurrency-sensitive code (balances, status transitions) has at least one test showing that a second attempt is rejected or is a no-op.

## Code generated with AI assistance
- Treat it like any other code, with extra attention to: invented methods or packages that do not exist in the installed versions, tests that only assert the mock returns what it was told to return, and broad `try/catch` blocks that swallow errors.
- Tests must exercise the real code path, not re-implement the logic inside the test.

## Tooling to run when possible
- `php artisan test` (or `vendor/bin/pest` / `vendor/bin/phpunit`) on the affected test files first, then the full suite if feasible.
- `vendor/bin/phpstan analyse` on changed files.
- `vendor/bin/pint --test` on changed files.
- Report what was run, what passed, and what could not be run.
