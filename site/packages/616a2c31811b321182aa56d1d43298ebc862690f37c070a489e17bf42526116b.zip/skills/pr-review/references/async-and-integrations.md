# Queues, jobs, schedulers, and external integrations

## Jobs
- **Idempotent**: running the job twice must not double-charge, double-send, or duplicate rows. Use a unique constraint, a status check with an atomic update, or `ShouldBeUnique` / `WithoutOverlapping` where it fits.
- **Serialized payload**: pass model IDs or models (`SerializesModels`), not large arrays or collections. A model deleted before the job runs throws `ModelNotFoundException`; decide whether `$deleteWhenMissingModels = true` is correct.
- `$tries`, `$backoff`, `$timeout`, and `retryUntil()` are set deliberately. The job `$timeout` must be shorter than the queue connection's `retry_after`, or the job can run twice in parallel.
- `failed()` handles the final failure: log with context, alert, or mark the record so it is not stuck in a pending state forever.
- Heavy jobs are on a dedicated queue so they cannot starve urgent ones.
- Batches and chains: a failure in the middle leaves the data in a known state.

## Scheduler
- Tasks that must not overlap use `withoutOverlapping()`; on multiple servers, also `onOneServer()` with a shared cache lock store.
- Long tasks use `runInBackground()` so they do not delay other scheduled tasks.
- Time-based logic states its timezone explicitly.

## External HTTP calls
- Every call has a timeout (`Http::timeout()` and `connectTimeout()`); the default can hang a worker.
- Retries (`retry()`) only on safe or idempotent operations, with backoff, and only on retryable errors (timeouts, 5xx, 429), not on 4xx.
- Responses are checked (`throw()` or `successful()`) before use; the code handles unexpected shapes and missing fields.
- Requests and responses are logged at a level that helps debugging, with secrets and personal data masked.
- For critical partners, consider a circuit breaker or a fallback so one slow partner does not take the whole service down.
- Base URLs and credentials come from config, not hardcoded; test code uses `Http::fake()` and `Http::preventStrayRequests()`.

## Events and listeners
- Listeners that do slow work implement `ShouldQueue`.
- Events fired inside a transaction use `ShouldDispatchAfterCommit` or equivalent, so listeners do not act on rolled-back data.
- Model observers are not relied on for critical logic that bulk updates would skip.

## Caching and Redis
- Cache keys include every dimension that changes the value (tenant, user, locale, version).
- Invalidation is explicit on write; TTLs are set.
- `Cache::lock()` is used for cross-process mutual exclusion, and the lock is released in `finally` or with `block()` / `get()` callbacks.
