# Database, Eloquent, and migration checklist

## Queries
- **N+1**: any relation accessed inside a loop, a Blade `@foreach`, or an API Resource must be eager loaded (`with()`, `load()`, `loadMissing()`). Suggest `Model::preventLazyLoading()` in non-production environments if the project does not use it.
- **Unbounded reads**: no `->get()` or `->all()` on tables that grow (transactions, logs, events, customers). Use pagination, `chunkById()`, `lazyById()`, or `cursor()`.
- `chunk()` while updating the same column it filters on skips rows; use `chunkById()`.
- Select only needed columns on wide tables and in hot paths.
- Aggregates are done in SQL (`count()`, `sum()`, `withCount()`, `withSum()`), not by loading collections and counting in PHP.
- `whereHas()` on large tables can produce slow correlated subqueries; consider a join or `whereIn` with a subquery and check the plan.
- Filters and sorts on large tables are backed by an index. If unsure, ask for `EXPLAIN (ANALYZE, BUFFERS)` output on production-like data.
- `LIKE '%term%'` on a large table will not use a B-tree index; PostgreSQL needs `pg_trgm` with a GIN index, or full-text search.

## Writes and consistency
- Multi-step writes that must succeed together are in `DB::transaction()`.
- No external HTTP calls, emails, or queued jobs dispatched *inside* a transaction that might roll back. Use `DB::afterCommit()`, `->afterCommit()` on the job, or `ShouldDispatchAfterCommit`.
- Read-then-write on the same row under concurrency uses `lockForUpdate()` or an atomic update (`where('status', 'pending')->update([...])` and check the affected row count).
- Uniqueness is enforced by a database unique index, not only by validation.
- Bulk updates on many rows use a single `update()` or `upsert()` in batches, not one query per model; remember that bulk operations skip model events and observers.
- Money uses `decimal`/`numeric` columns or integer minor units and a decimal library or `bcmath` in PHP, never `float`.

## Migrations
Assume the table is large and production is live.

- **Locking (PostgreSQL)**:
  - Adding an index on a big table: `CREATE INDEX CONCURRENTLY`, which in Laravel needs a raw statement and the migration's `$withinTransaction = false`.
  - Adding a column with a volatile default, changing a column type, or adding `NOT NULL` to an existing column can rewrite or scan the whole table under an `ACCESS EXCLUSIVE` lock. Prefer: add nullable column → backfill in batches → add a `CHECK ... NOT VALID` constraint → `VALIDATE CONSTRAINT` → then set `NOT NULL`.
  - Adding a foreign key on a large table: add it `NOT VALID`, then validate separately.
  - Suggest `SET lock_timeout` for risky DDL so a blocked migration fails fast instead of queuing all traffic behind it.
- **Backwards compatibility**: code from the previous release must still work while the migration runs and during rollback. Renaming or dropping a column needs expand → migrate → contract over separate deploys.
- **Data backfills** belong in a separate command or job with batching and progress, not in a schema migration that runs inside a deploy.
- `down()` is either correct or explicitly marked irreversible; it must never silently drop data the `up()` did not create.
- Enum or status changes: check every place that reads the old values (queries, jobs, reports).
- Partitioned tables: new indexes and constraints must be created on the parent so every partition gets them; unique constraints must include the partition key.

## Replicas and pooling
- Reads that must see a write just made in the same request use the write connection (`sticky` option or `onWriteConnection()`), since replicas can lag.
- Long-running reads on a replica can be cancelled by replication conflicts; long reports should be batched.
- With PgBouncer in transaction pooling mode, avoid session state: `SET` without `LOCAL`, session advisory locks, `LISTEN`, and prepared statements unless the pooler supports them.
