# claude-skill-bb

A [Claude Code](https://claude.com/claude-code) skill that teaches Claude to use [`lite-bb`](https://github.com/key4ng/lite-bb) (`bb`) for Bitbucket operations — the `gh` equivalent for Bitbucket Cloud and Server/Data Center.

## What it does

Without this skill, Claude has no knowledge of the `bb` CLI and falls back to verbose `curl` REST API calls when working with Bitbucket repos. With this skill, Claude:

- Uses `bb` commands instead of `gh` or `curl` when it detects a Bitbucket remote
- Suggests `pip install lite-bb` and `bb auth login` for setup
- Knows the correct flags for every command (e.g., `--line-type` for inline comments)
- Handles both Bitbucket Cloud and Server/Data Center

## Install

```bash
/plugin install https://github.com/key4ng/claude-skill-bb
```

Or via the lite-bb marketplace:

```bash
/plugin marketplace add https://github.com/key4ng/lite-bb
/plugin install lite-bb
```

## Coverage

The skill covers the full `bb` CLI surface:

| Area | Commands |
|------|----------|
| **Auth** | `bb auth login`, `logout`, `status` |
| **Pull Requests** | `list`, `view`, `create`, `edit`, `merge`, `close`, `reopen`, `checkout`, `diff` |
| **Code Review** | `bb pr review --approve/--request-changes/--comment`, `bb pr comment` with inline `--path --line --line-type` |
| **Repos** | `bb repo list`, `view`, `clone`, `create` |
| **Search** | `bb search code` with `--extension`, `--filename` filters |
| **Raw API** | `bb api` with `-X`, `-F`, `--input`, `-q`, `--raw` flags |

## When does it trigger?

The skill activates when:

- The user mentions Bitbucket, `bb`, or `lite-bb`
- The git remote points to `bitbucket.org` or a Bitbucket Server instance
- The user asks to create, review, merge, or manage PRs in a Bitbucket context

## Eval results

Tested on a Bitbucket Server repo with no `bb` project context:

| Eval | With Skill | Without Skill |
|------|-----------|--------------|
| List & Create PR | 5/5 (100%) | 0/5 (0%) |
| Review PR with inline comments | 4/4 (100%) | 1/4 (25%) |
| Search + CI checks + squash merge | 5/5 (100%) | 1/5 (20%) |
| **Overall** | **14/14 (100%)** | **2/14 (15%)** |

Without the skill, Claude falls back entirely to `curl` REST API calls and has no knowledge of `bb`.

## Prerequisites

Install the `bb` CLI:

```bash
pip install lite-bb
```

Then authenticate:

```bash
bb auth login
```

## Author

**Keyang Ru** — [github.com/key4ng](https://github.com/key4ng)

## License

MIT
