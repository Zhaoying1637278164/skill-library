---
name: store-ready
description: Make the mobile app in this repository store-ready on AppFoyer — derive data-collection facts from the build files, draft the privacy policy, terms, support and account-deletion pages plus app-ads.txt, and hand the developer a review link. Use when the developer says "make this app store-ready", asks for a privacy policy / account-deletion URL / app-ads.txt for their app, asks "is this app store-ready?", asks for a specific flavor or package id to be made store-ready, or asks to wire the published links into the app.
---

# Store-ready (AppFoyer)

You draft; the developer publishes. There is **no publish tool** and you must never try to work
around that. Everything you write lands in a draft slot and becomes public only when the developer
clicks Publish on the review screen. Say this plainly every time you hand off.

Only **derived facts** leave this machine: app name, platform, application/bundle id, SDK and
permission *names*, and the developer's confirmed answers. Never send file contents, source code,
secrets, keystores or `.env` values. Never read or print `APPFOYER_API_KEY`. The one file that
does leave is the app's **own launcher/store icon** (step 5b) — it is a public store asset — and
only through the upload URL `set_icon` returns.

## Which mode

| Developer says | Mode |
|---|---|
| "Make this app store-ready", "I need a privacy policy / deletion URL / app-ads.txt", "…for com.acme.app.pro" | **Draft** (below) |
| "Is this app store-ready?", "what's missing for the store?" | **Audit**: steps 1–2 (including flavor detection, 1b), then `get_checklist` for each matching existing app — a flavor with no app is itself the finding. No writes. |
| "Wire the store-ready links into the app", "add the privacy link to settings" | **Wire**: see the last section. Requires published pages. |
| "Update the app icon", "change the address to weather-radar" | **Icon / address only**: steps 1 and 3 to find the app(s), then 5b or 5c. No facts, no questions, no drafts. A named address is tried as given; changing an existing custom one still needs the developer's yes. |

If a tool call fails with `missing_scope` or an HTTP 401, stop and tell the developer to create or
re-export an agent key at the connect URL in the error. Do not retry. Also stop, without retrying, on:

- `terms_required` (HTTP 403) — the developer must sign in to the dashboard and accept the current
  Terms of Service; then run again.
- `app_locked` — the developer made the app read-only; they unlock it in Settings.
- `app_frozen` — the subscription lapsed; only renewing the plan clears it. Never tell them to "unlock" it.
- `-32029` / HTTP 429 — the write budget is spent. Wait the `retryAfter` seconds once, then continue;
  if it happens again, stop and say how far you got.

Send one JSON-RPC message per request; batches are refused.

A JSON-RPC **validation error** (`-32602`, e.g. "Too big … <=102400" on `markdown`) means nothing
was written. Treat it like a `too_large` result: shorten the draft and re-send once.

## Draft mode

### 1. Detect platform and identity — from files, never by asking

Read only build, manifest and store-metadata files: `build.gradle(.kts)`, `settings.gradle`,
`gradle/libs.versions.toml`, `AndroidManifest.xml`, `res/values/strings.xml`, `Podfile`, `Podfile.lock`,
`Package.swift`, `*.xcodeproj/project.pbxproj`, `Info.plist` and other `*.plist` config files,
`*.entitlements`, `PrivacyInfo.xcprivacy`, `*.storekit`, `*.xcconfig`, `pubspec.yaml`, `flavorizr.yaml`,
`flutter_launcher_icons.yaml`, `package.json`, `app.json`, `app.config.js|ts` (literal values only, never run it),
`eas.json`, fastlane `Appfile`/`Deliverfile`
and `fastlane/metadata/**`, store listing texts (`appstore/`, `playstore/`, `metadata/`), `LICENSE`,
`README*`. Do not open source files, `.env*`, keystores or CI secrets.

**Identify the framework first** — native, Flutter, React Native (bare or Expo) or Kotlin
Multiplatform — because each keeps the package id, bundle id and app name in different files
(`android/app/…`, `ios/Runner.xcodeproj`, `app.json` / `app.config.*`, `composeApp/`, `iosApp/Configuration/*.xcconfig`).
The table and the per-framework rules are in `references/frameworks.md`; for a cross-platform app
derive the Android package id **and** the iOS bundle id separately, each with its file:line — they
often differ.

Derive: platform, app name, application/bundle id, proposed Android store URL, **and the build's
product flavors** (Gradle `productFlavors`, Xcode targets/schemes with their own bundle id, Flutter
flavors, Expo/EAS variants). Details: `references/sdk-map.md`.

### 1b. Flavors — one shipped flavor is one app

A flavor that ships to a store under its **own application/bundle id** is its own store listing, so
it needs its own pages, its own `/account-deletion` and its own `app-ads.txt` — one AppFoyer app per
flavor. Build types (`debug`, `staging`, an `applicationIdSuffix` on a non-shipped variant) are
**not** flavors: never make an app for one.

- **The developer's prompt named package ids** ("make the pro and enterprise flavors store-ready",
  `com.acme.app.pro com.acme.app.lite`) → use exactly those and ask nothing about the selection.
  An id that matches no flavor in the build is an error: say which ids you found and stop. Do not
  substitute the closest one.
- **Flavors found, none named** → list them (flavor name, application id, source) and ask which to
  make store-ready with the multi-select question in `references/questions.md` (Round 0). The
  default selection is every flavor with a distinct application id that is not a debug/staging
  variant.
- **No flavors** → one app, exactly as before. Do not ask the question.
- **Non-standard layouts** — the app name set in Gradle (`resValue`, `manifestPlaceholders`), a
  `sourceSets` block that moves a flavor's folders, several `flavorDimensions` (e.g. brand × env,
  where only the production environment ships): follow `references/sdk-map.md` → "Three non-standard
  layouts". Apply each only when it is in the Gradle file; a plain build skips all three.

Facts are derived **per flavor**: shared facts (the `main` source set and plain `implementation`
lines) plus that flavor's own (`<flavor>Implementation` / `<flavor>Api` dependencies,
`src/<flavor>/AndroidManifest.xml`, `src/<flavor>/res/values/strings.xml`, its `.xcconfig` or
target-level settings). A free flavor's ad SDK is a fact about the free flavor only — never write it
into the paid flavor's privacy policy. Each flavor also gets its own proposed store URL, built from
its own application id.

### 2. Derive data-collection facts

Map dependencies and permissions to `account | analytics | ads | crash | location | purchases | none`
with `references/sdk-map.md`. Keep the **file and line** for every fact. Usage-description keys
and permissions with no `dataCollection` bucket (Face ID, camera, notifications…) are still
permission facts — keep them with file:line for the privacy page's permissions section. README
prose ("sign in with Google") is a hint for question defaults, never a fact on its own.

In the same pass, list the **SDK ids** the build contains (`references/sdk-map.md` §SDK ids) — they
feed the store-form answers in step 8. Keep the file:line for each. An SDK in the build with no id
there is still named to the developer, as "not covered by the store-form answers".

### 3. Check for an existing app (re-runs)

Call `list_apps`. Match **per selected flavor**, in this order: the application id inside the Play
URL (`…details?id=<applicationId>`), then the app name. A match is a **re-run** for that flavor:
call `get_app`, diff your fact list against `dataCollection`, and continue with `update_app` +
drafts for the pages the diff touches only. Unmatched flavors are new apps. A flavor set is often
half and half — re-run two, create one — so decide this one flavor at a time, never for the batch.

### 4. Show facts, then ask the gaps — interactively

Print the fact list with sources first (plain text, so the developer can read it). Then ask with
the **`AskUserQuestion` tool** — selectable options, proposed defaults pre-filled as the first
option, "Other" for free text — in at most two rounds of ≤ 4 questions each, exactly as laid out
in `references/questions.md`. If the tool is not available in this agent, fall back to the plain
numbered list in the same file. Wait for the answers. Nothing has been sent yet.

### 5. `create_app` / `create_apps` (or `update_app`)

Send the confirmed values once. One new app → `create_app`. Two or more (a flavor set) →
**`create_apps`**, up to 10 per call, one entry per flavor with that flavor's own name, facts and
store URLs (`storeUrlIos`, and `storeUrlsAndroid` — a list, one URL per Android store) and its
`sdks`; split a longer set across calls. On a re-run, send `sdks` with `update_app` — it replaces
the whole list and changes nothing public. Every app is created unpublished, scored and
limit-checked on its own.

Also send **`description`**: one or two plain sentences (one line, ≤ 300 characters) on what the
app does, taken from the repo — README, store metadata (`fastlane/metadata`, `Info.plist`
display strings), the app's own strings. Never invent features; if the repo says nothing, leave it
out. It appears only on the developer's dashboard Overview, never on the public site. Per flavor,
say what sets that flavor apart. On a re-run, fix it with `update_app` (`null` clears it).

`create_apps` answers with `created`, `failed` and `skipped` — report all three. A failed entry
never discards the others: keep drafting for what was created, show every reason for what was not.
If the result carries `publishLimit`, the plan has fewer free slots than the flavors you just
created: say the numbers plainly (`remaining` of `limit`), keep drafting all of them, and let the
developer choose which to publish or upgrade. Never drop a flavor on your own to fit the plan.

Outcomes per entry:

- **`quota` present** → the app exists but cannot be published (plan limit). Say, in one sentence,
  that it was created unpublished and give `dashboardUrl`. **Keep drafting** — the drafts are
  useful once the developer upgrades or frees a slot.
- **`content_rejected`** → print every reason with its `field`, `matched` and `fix`, ask the
  developer what to change, and stop. Never retry with a tweaked name on your own.
- **`too_many_apps`** → tell the developer to delete an app in the dashboard; stop.

### 5b. `set_icon` — the app's own icon, found in the repository

For each app (flavor) you created, or on a re-run whose `get_app` says `hasIcon: false`. On a re-run
with an icon already set, replace it only if the developer asked. Find the icon **for that
platform, that flavor**, first match wins:

**Android** (the manifest's `android:icon`, e.g. `@mipmap/ic_launcher`, names the resource; a
flavor's `src/<flavor>/…` overrides `src/main/…`)
1. `src/<flavor|main>/ic_launcher-playstore.png` — Android Studio's 512×512 Play icon.
2. `fastlane/metadata/android/<locale>/images/icon.png` — the Play listing icon.
3. The largest raster of that resource: `res/mipmap-xxxhdpi/<name>.png|.webp`, then `xxhdpi`,
   `xhdpi`. Use the square one, not `<name>_round`. `mipmap-anydpi-v26/*.xml` is an adaptive vector
   icon and cannot be uploaded — skip it and use the PNG/WebP fallback beside it.

**iOS** (the target's `ASSETCATALOG_COMPILER_APPICON_NAME` in `project.pbxproj` names the set,
default `AppIcon`; each flavor target can name its own)
1. `**/*.xcassets/<AppIcon>.appiconset/Contents.json` → the file of the `ios-marketing` 1024×1024
   entry, or the single `universal` 1024 entry (Xcode 14+), otherwise the largest `size × scale`.
2. `fastlane/metadata/**/app_icon.png`, if present.

**Cross-platform:** Flutter — `image_path` in `flutter_launcher_icons.yaml` / `pubspec.yaml`, else
the native paths under `android/` and `ios/`; Expo — `expo.icon` in `app.json`; React Native — the
native paths; Kotlin Multiplatform — the Android app module's `src/main/res` (or `src/androidMain/res`)
and the `.xcassets` in the iOS app folder. For a `both` app prefer the Play 512 icon, then the iOS marketing icon.

Before uploading check it with `file` / `sips -g pixelWidth -g pixelHeight` (or `identify`): PNG,
JPEG or WebP, square, at most `maxBytes` (512 KB). If it is larger — a 1024 iOS icon often is —
**copy it to a temp directory** and downscale the copy (`sips -Z 512 <in> --out "$TMPDIR/appfoyer-icon.png"`,
or `magick <in> -resize 512x512 <out>`); never write into the repository. No usable raster at all
(only vectors, or not square) → say so, give the dashboard's Settings as the place to upload, and go on.

Then call `set_icon`, replace `<path-to-icon>` in the returned `curl` and run it. `{"ok":true}` is
done; on `413` downscale and call `set_icon` again; on `404 invalid_token` call `set_icon` again
(the URL is single use and lasts ten minutes); on `415` it is not a real PNG/JPEG/WebP. Tell the
developer which file you uploaded. The icon goes live at once — it has no draft step.

### 5c. `set_slug` — a custom address on Pro / Advanced

Only when the app still has its random `app-…` address (`slug` equals `baseSlug`). If it already
has a custom one, leave it unless the developer asks to change it — and then only with their yes
and `replaceCustom: true`, because the old address is released at once and any store listing or
build that names it breaks.

Build candidates from the app's **English name**, per flavor: `res/values/strings.xml` `app_name`
(or `values-en/` when the default locale is not English), `CFBundleDisplayName` in
`en.lproj/InfoPlist.strings`, then `Info.plist`, then `fastlane/metadata/android/en-US/title.txt` /
`fastlane/metadata/en-US/name.txt`. No English name → transliterate the name to ASCII
(`Izahlı Lüğət` → `izahli-luget`). Lowercase, words joined by single hyphens, 4–32 characters,
`a-z 0-9 -` only. Drop words the server refuses so you do not waste an attempt on them: brand and
store names (`google`, `apple`, `play`, `facebook`, `whatsapp`, bank or payment names…), structural
words (`login`, `verify`, `support`, `secure`, `official`, `account`), the `app-` prefix, and
fillers like `the`. A flavor's candidate carries its flavor word (`weather-now-pro`).

Candidate order: the full name (`weather-now`), then without fillers, then `+ -app`, then the
developer's short name + the app name (`acme-weather`), then `+ -android` / `-ios` for a
platform-specific app. For each, `check_slug` first (it writes nothing), then `set_slug` with the
first available one:

- `not_in_plan` → Free account: **skip the step without retrying**, one line to the developer
  that a custom address comes with Pro.
- `retry: true` (`taken`, `brand`, `structural`, `reserved`, `invalid`) → read `fix`, move to the
  next candidate, **at most 5 attempts per app in total**. After the fifth, list what you tried with
  each reason and ask the developer for an address.
- `replaces_custom_slug` → ask the developer; never add `replaceCustom` on your own.

Report the new `url`. The permanent `app-…` address keeps serving the same site. Use the new URL in the
paste table of step 8.

### 6. Draft the five pages with `set_page`

With several flavors, do this for **each app in turn**, with that flavor's own fact list, name and
store URLs. Never reuse one flavor's draft for another by search-and-replacing the name: the data
facts, the permissions and the store links are what differ, and they are the content that matters.

Start from the **template text** in `get_app` → `pages[*].markdown` (it already contains the
disclaimer block and the `{{variables}}` filled from Settings — keep both). Edit it into a page
about *this* app:

- Privacy: list each provider found in step 2 by name with its purpose and a link to the
  vendor's privacy policy; state the permissions and why the app needs them; keep the
  account-deletion section pointing at the app's own `/account-deletion`.
- Terms: purchases/subscriptions only if the fact exists and the developer answered question 7;
  keep the "not legal advice / your responsibility" clause.
- Support: the confirmed support email and the store URLs; no other contact addresses.
- Account deletion: keep the request-form wording; describe what deleting an account does *in
  this app* only if the developer told you.
- Home: one paragraph, the store badges (declared store URLs only).

Constraints, verbatim: **Markdown only, no HTML, no images, no forms.** Links: only the app's own
site, `mailto:` to the declared support email, the declared store listings and well-known SDK
policy pages are clickable — everything else is printed as text, so don't add them. Never write
"Download" labels pointing outside the stores. Do not invent retention periods, legal bases,
company addresses or DPO names — write `[confirm: …]` and move on.

`set_page` returns `advisory.reasons`. If non-empty, fix what each `fix` says and re-send **once**.
If a reason remains, leave it — the developer will see it on the review screen.

### 7. `set_ad_lines` — only with an ads fact and publisher lines

`app-ads.txt` has **no draft step**: on a published app the file is live the moment you send it.
Send only lines the developer confirmed, and say it is live. If the developer gave publisher lines, send them as-is. If they said "later", skip and say where
to add them (Dashboard → app-ads.txt). Remind them to set the site as the developer website in the
store listing — AdMob crawls the hostname of that URL.

### 8. `request_publish` and stop

Print the `reviewUrl` and, verbatim: **"Nothing is public yet. Review each page and click
Publish."** Then print the paste table:

| Console field | URL |
|---|---|
| Google Play → App content → Privacy policy | `<site>/privacy` |
| Google Play → App content → Data deletion | `<site>/account-deletion` |
| App Store Connect → App Privacy → Privacy Policy URL | `<site>/privacy` |
| App Store Connect → App Information → Support URL | `<site>/support` |

If the app was already published and you changed its icon or address in 5b/5c, say so: those
two are live now, unlike the drafts.

Then call **`get_store_forms`** and print the draft answers for the store questionnaires the app's
platform needs — Google Play *Data safety* and/or App Store *App Privacy*: one line per data type
(category → type, collected/shared or linked/tracking, purposes, sources), then every `confirms`
note, every `mismatches` entry and each `sdkNotes` basis. Say plainly that these are drafts to check,
built from vendor documentation, and that the developer enters them in the console themselves. A
mismatch means the privacy policy and the form disagree: offer to fix the facts with `update_app`
and redraft the privacy page. Give `storeFormsUrl` for the same answers in the dashboard.

Those fields live in the store consoles; you cannot fill them. With several flavors, call
`request_publish` for each app and print one table **per flavor**, headed by its application id —
the consoles are per listing, and pasting one flavor's URLs into another's listing is a store
rejection waiting to happen.

Then offer one last choice with `AskUserQuestion` (or plain text): **"Show me each draft here"**
or **"I'll review in the dashboard"**. On the first, print every draft's Markdown in full, one
page per message, and repeat the review URL at the end. Publishing itself always happens on the
review screen — it shows the rendered page next to the live one with the moderation result, which
a terminal cannot. Do not open a browser, do not poll, do not call anything else.

## Wire mode (after publishing)

1. `list_apps` → `get_app`. If the pages you need are not `published`, stop and point at the review URL.
2. Find where the app already shows or should show a privacy / terms / support link: an
   About/Settings screen, `strings.xml` / `Localizable.strings` URL constants, an existing
   hard-coded policy URL, the store metadata files under `fastlane/metadata`.
3. Propose a diff. Apply it **only on an explicit yes**. Never commit, never push.

## Never

- Publish, or ask the developer for the key so you can "do it manually".
- Create an app for a build type (`debug`, `staging`) or for a flavor the developer did not select.
- Share one flavor's facts, pages or store links with another flavor.
- Send file contents or source, run builds, or modify the repository in Draft/Audit mode. The
  app's own icon through `set_icon` is the only file that leaves; a resized copy goes to a temp dir.
- Replace a custom address the developer already has without their yes, or keep retrying slugs
  past five attempts or after `not_in_plan`. Never respell a brand (`paypa1`) to get past the check.
- Claim a store will accept the pages, or that `app-ads.txt` is verified with any ad network.
- Present a store-form answer as verified, or fill a gap the vendor's documentation leaves open
  from your own knowledge — say it is open.
- Present the drafts as legal advice.
