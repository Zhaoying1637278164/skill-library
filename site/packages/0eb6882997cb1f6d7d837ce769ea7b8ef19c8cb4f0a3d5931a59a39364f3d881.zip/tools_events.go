package fpmcpserver

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"github.com/fingerprintjs/fingerprint-mcp-server/internal/schema"
	"github.com/fingerprintjs/fingerprint-mcp-server/internal/utils"
	"github.com/fingerprintjs/go-sdk/v8"
	"github.com/modelcontextprotocol/go-sdk/mcp"
)

// GetEventInput defines the input schema for the get_event tool
type GetEventInput struct {
	EventID  string   `json:"event_id" jsonschema:"The unique identifier of the event to retrieve. Accepts both identification and Automation Intelligence (edge) event IDs."`
	Products []string `json:"products,omitempty" jsonschema:"Optional list of product fields to include in the response. If omitted all products are returned."`
}

// GetEventOutput defines the output schema for the get_event tool.
// Use `ref` tag to reference OpenAPI schemas, `description` tag for inline descriptions.
//
// Event is `any` rather than fingerprint.Event because the payload is passed
// through schema.ReadableTimestamps on the way out, which rewrites epoch
// milliseconds as RFC3339 and so no longer matches the SDK's integer fields.
type GetEventOutput struct {
	Event any `json:"event" ref:"Event"`
}

type SearchEventsOutput struct {
	Events any `json:"events" ref:"EventSearch"`
}

// envelopeOutputSchema builds the slim top-level output schema shared by the
// event tools: an object with a single required, object-typed key. The full
// per-event shape is exposed via the fingerprint://schemas/event resource, so
// the tool definition advertises only this envelope instead of embedding the
// ~48KB Event schema (which makes these tools large enough to be dropped by
// size-capped clients). The handlers still return the complete event payload as
// structured content; the envelope is permissive (additionalProperties: true)
// so the full result always validates.
func envelopeOutputSchema(key, description string) json.RawMessage {
	b, err := json.Marshal(map[string]any{
		"type": "object",
		"properties": map[string]any{
			key: map[string]any{"type": "object", "description": description},
		},
		"required":             []string{key},
		"additionalProperties": true,
	})
	if err != nil {
		panic(err) // static inputs, cannot fail
	}
	return b
}

var getEventOutputSchema = envelopeOutputSchema("event",
	"The event. An identification event has identification.visitor_id, browser and device details, geolocation, and the full smart signal set. An Automation Intelligence (edge) event has only request and IP derived fields (ip_info, proxy, vpn, bot_info, url, tags, timestamp) and no visitor_id. Full shape: fingerprint://schemas/event resource.")

var searchEventsOutputSchema = envelopeOutputSchema("events",
	"Result set: an events array of matching events, plus optional pagination_key and total_hits. Each event has the shape in the fingerprint://schemas/event resource; edge results carry no visitor_id and no device details.")

func (a *App) requireFingerprintClient(_ context.Context, reqExtra *mcp.RequestExtra) (*fingerprint.Client, error) {
	var apiKey string
	if a.cfg.PublicMode {
		apiKey = reqExtra.TokenInfo.Extra[tokenExtraServerApiKey].(string)
	} else {
		apiKey = a.cfg.ServerAPIKey
	}
	if apiKey == "" {
		return nil, errors.New("server API key is required")
	}

	var region string
	if a.cfg.PublicMode {
		region = reqExtra.TokenInfo.Extra[tokenExtraRegionKey].(string)
	} else {
		region = a.cfg.Region
	}
	if region == "" {
		return nil, errors.New("server API region is required")
	}

	var fpRegion fingerprint.Region
	switch region {
	case "eu":
		fpRegion = fingerprint.RegionEU
	case "ap":
		fpRegion = fingerprint.RegionAsia
	case "us":
		fpRegion = fingerprint.RegionUS
	default:
		return nil, fmt.Errorf("unknown region %s, must be one of: us, eu, ap", region)
	}

	fpOpts := []fingerprint.ConfigOption{
		fingerprint.WithAPIKey(apiKey),
		fingerprint.WithRegion(fpRegion),
		fingerprint.WithHTTPClient(&http.Client{
			Transport: &iiTransport{
				base:    http.DefaultTransport,
				version: a.version,
				appName: a.appName,
			},
		}),
	}
	if a.cfg.ServerAPIURL != "" {
		fpOpts = append(fpOpts, fingerprint.WithBaseURL(a.cfg.ServerAPIURL))
	}

	client := fingerprint.New(
		fpOpts...,
	)

	return client, nil
}

func (a *App) registerGetEventTool(_ context.Context) error {
	// Register the get_event tool
	addTool(a, &mcp.Tool{
		Name:         "get_event",
		Description:  "Retrieves a single Fingerprint event by event_id. Fingerprint has two kinds of event, both reachable through this tool: an identification event, collected by the JS Agent or a mobile SDK, returns identification.visitor_id, browser and device details, geolocation, and the full smart signal set; an Automation Intelligence (edge) event, observed server-side with no client agent, returns only request and IP derived fields (ip_info, proxy, vpn, bot_info, url, tags, timestamp). An edge event has no visitor_id and no device-derived signals, so read the returned fields rather than assuming either kind. For schema, see mcp resource fingerprint://schemas/event",
		OutputSchema: getEventOutputSchema,
		InputSchema:  schema.PatchProductsEnum(schema.SchemaFromStruct(GetEventInput{})),
		Annotations: &mcp.ToolAnnotations{
			DestructiveHint: utils.Ptr(false),
			IdempotentHint:  true,
			OpenWorldHint:   utils.Ptr(false),
			ReadOnlyHint:    true,
			Title:           "Get Event",
		},
	}, func(ctx context.Context, req *mcp.CallToolRequest, input GetEventInput) (*mcp.CallToolResult, *GetEventOutput, error) {
		fpClient, err := a.requireFingerprintClient(ctx, req.Extra)
		if err != nil {
			return nil, nil, err
		}
		if input.EventID == "" {
			return nil, nil, errors.New("event_id is required")
		}

		// Call Fingerprint API
		event, _, err := fpClient.GetEvent(ctx, input.EventID)
		if err != nil {
			return nil, nil, wrapFPError("failed to get event", err)
		}

		schema.FilterProducts(event, input.Products)
		schema.StripAdditionalProperties(event)

		return nil, &GetEventOutput{Event: schema.ReadableTimestamps(*event)}, nil
	})

	return nil
}

func (a *App) registerSearchEventsTool(_ context.Context) error {
	// Register the search_events tool
	addTool(a, &mcp.Tool{
		Name:         "search_events",
		Description:  "Retrieves events matching provided criteria. The two kinds of Fingerprint event are searched separately and never mixed in one response: omit `source` for identification events (JS Agent or mobile SDK), or pass source: [\"edge\"] for Automation Intelligence (edge) events, and search twice to cover both. An identification event returns identification.visitor_id, browser and device details, geolocation, and the full smart signal set. An edge event returns only request and IP derived fields (ip_info, proxy, vpn, bot_info, url, tags, timestamp): no visitor_id, no device details. Edge events are only searchable for the last 7 days. Output can be large so consider only choosing products that you need and setting the limit to a dozen events or so. For schema of every individual event, see mcp resource fingerprint://schemas/event",
		OutputSchema: searchEventsOutputSchema,
		InputSchema:  schema.PatchProductsEnum(schema.SearchEventsInputSchema),
		Annotations: &mcp.ToolAnnotations{
			DestructiveHint: utils.Ptr(false),
			IdempotentHint:  true,
			OpenWorldHint:   utils.Ptr(false),
			ReadOnlyHint:    true,
			Title:           "Search Event History",
		},
	}, func(ctx context.Context, req *mcp.CallToolRequest, input schema.SearchEventInput) (*mcp.CallToolResult, *SearchEventsOutput, error) {
		fpClient, err := a.requireFingerprintClient(ctx, req.Extra)
		if err != nil {
			return nil, nil, err
		}

		if input.Limit == nil {
			input.Limit = utils.Ptr(int32(10))
		} else if *input.Limit < 1 {
			return nil, nil, fmt.Errorf("limit must be greater than zero")
		}

		// Call Fingerprint API
		searchReq, err := schema.SearchEventInputToRequest(&input)
		if err != nil {
			return nil, nil, err
		}
		events, _, err := fpClient.SearchEvents(ctx, searchReq)
		if err != nil {
			return nil, nil, wrapFPError("failed to search events", err)
		}

		for i := range events.Events {
			schema.FilterProducts(&events.Events[i], input.Products)
		}
		schema.StripAdditionalProperties(events)

		return nil, &SearchEventsOutput{Events: schema.ReadableTimestamps(*events)}, nil
	})

	return nil
}

// wrapFPError surfaces the Fingerprint API error envelope to the MCP client.
//
// We lead with a parsed "action: code: message" line for human readability, then
// append the full response body verbatim. Including the body matters because
// any field the API ships beyond {code, message} (per-error details, retry
// hints, doc links, etc.) reaches the LLM tool call without further code
// changes here — the surface of this wrapper is the API surface for new
// fields. The SDK's err.Error() alone gives only HTTP status text or, on
// strict-enum decode failure, the unmarshal complaint; neither carries that.
//
// Two extraction paths cover the same envelope: AsErrorResponse for codes the
// SDK enum already knows (snake_case v4), and a raw body parse for codes the
// enum rejects (v3-style PascalCase or codes added after this SDK version).
func wrapFPError(action string, err error) error {
	var apiErr interface {
		error
		Body() []byte
	}
	if !errors.As(err, &apiErr) {
		return fmt.Errorf("%s: %w", action, err)
	}
	body := apiErr.Body()

	if er, ok := fingerprint.AsErrorResponse(err); ok && er.Error.Message != "" {
		return newFPAPIError(action, string(er.Error.Code), er.Error.Message, body, err)
	}
	if code, msg := parseFPErrorBody(body); msg != "" {
		return newFPAPIError(action, code, msg, body, err)
	}
	return fmt.Errorf("%s: %w", action, err)
}

func newFPAPIError(action, code, message string, body []byte, original error) error {
	text := fmt.Sprintf("%s: %s", action, message)
	if code != "" {
		text = fmt.Sprintf("%s: %s: %s", action, code, message)
	}
	if compact := compactJSON(body); compact != "" {
		text = text + "\n" + compact
	}
	return &fpAPIError{msg: text, err: original}
}

// compactJSON returns body re-serialized without whitespace if it parses as
// JSON; empty string otherwise (so non-JSON bodies don't get appended raw).
func compactJSON(body []byte) string {
	if len(body) == 0 {
		return ""
	}
	var buf bytes.Buffer
	if err := json.Compact(&buf, body); err != nil {
		return ""
	}
	return buf.String()
}

// fpAPIError carries the human-readable "action: code: message" text on the
// surface while keeping the underlying SDK error reachable via errors.As /
// errors.Is, so logs and downstream type-checks aren't blinded by the rewrite.
type fpAPIError struct {
	msg string
	err error
}

func (e *fpAPIError) Error() string { return e.msg }
func (e *fpAPIError) Unwrap() error { return e.err }

func parseFPErrorBody(body []byte) (code, message string) {
	var b struct {
		Error struct {
			Code    string `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
	}
	if json.Unmarshal(body, &b) != nil {
		return "", ""
	}
	return b.Error.Code, b.Error.Message
}

// iiTransport is an http.RoundTripper that appends the "ii" query parameter
// to every outgoing request, reporting the MCP server version to the backend.
type iiTransport struct {
	base    http.RoundTripper
	version string
	appName string
}

func (t *iiTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	r := req.Clone(req.Context())
	q := r.URL.Query()
	q.Add("ii", t.appName+"/"+t.version)
	r.URL.RawQuery = q.Encode()
	return t.base.RoundTrip(r)
}
