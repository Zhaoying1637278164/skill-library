package fpmcpserver

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"net/url"
	"slices"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/fingerprintjs/fingerprint-mcp-server/config"
	"github.com/lestrrat-go/jwx/v2/jwa"
	"github.com/lestrrat-go/jwx/v2/jwk"
	"github.com/lestrrat-go/jwx/v2/jwt"
	"github.com/modelcontextprotocol/go-sdk/mcp"
)

// --- Group 1: ListTools ---

func TestListTools_PrivateMode_BothKeys(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ServerAPIKey:     "test-server-key",
		ServerAPIURL:     fpAPI.server.URL + "/v4",
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	if len(names) != 15 {
		t.Errorf("expected 15 tools, got %d: %v", len(names), names)
	}
}

// TestToolDefinitionSizeUnderLimit guards against re-introducing oversized tool
// definitions. Some MCP clients silently drop a tool whose definition exceeds a
// per-tool size budget; in the incident that motivated this guard, search_events
// (~70KB) was dropped while get_event (~50KB) survived. Keep every tool well
// under that zone so a future schema change can't silently re-trigger the drop.
func TestToolDefinitionSizeUnderLimit(t *testing.T) {
	const maxToolBytes = 40 * 1024

	session := setupStdioServer(t, &config.Config{
		ServerAPIKey:     "test-server-key",
		ManagementAPIKey: "test-mgmt-key",
		Region:           "us",
	})

	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}
	if len(result.Tools) == 0 {
		t.Fatal("no tools registered")
	}

	for _, tool := range result.Tools {
		b, err := json.Marshal(tool)
		if err != nil {
			t.Fatalf("marshal tool %q: %v", tool.Name, err)
		}
		if len(b) > maxToolBytes {
			t.Errorf("tool %q definition is %d bytes, over the %d-byte guard; oversized tool definitions get dropped by some MCP clients, slim its input or output schema", tool.Name, len(b), maxToolBytes)
		}
	}
}

func TestListTools_PrivateMode_ServerKeyOnly(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	expected := []string{"get_current_time", "get_event", "search_events", "list_tools", "call_tool"}
	if len(names) != len(expected) {
		t.Errorf("expected %d tools, got %d: %v", len(expected), len(names), names)
	}
	for _, e := range expected {
		if !slices.Contains(names, e) {
			t.Errorf("expected tool %q not found in %v", e, names)
		}
	}
}

func TestListTools_PrivateMode_MgmtKeyOnly(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	expected := []string{
		"get_current_time",
		"list_environments", "create_environment", "update_environment", "delete_environment",
		"list_api_keys", "get_api_key", "create_api_key", "update_api_key", "delete_api_key",
		"list_tools", "call_tool", "call_write_tool",
	}
	if len(names) != len(expected) {
		t.Errorf("expected %d tools, got %d: %v", len(expected), len(names), names)
	}
	for _, e := range expected {
		if !slices.Contains(names, e) {
			t.Errorf("expected tool %q not found in %v", e, names)
		}
	}
}

func TestListTools_PrivateMode_ReadOnly(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ServerAPIKey:     "test-server-key",
		ServerAPIURL:     fpAPI.server.URL + "/v4",
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
		ReadOnly:         true,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	expected := []string{"get_current_time", "get_event", "search_events", "list_environments", "list_api_keys", "get_api_key", "list_tools", "call_tool"}
	if len(names) != len(expected) {
		t.Errorf("expected %d tools, got %d: %v", len(expected), len(names), names)
	}
	for _, e := range expected {
		if !slices.Contains(names, e) {
			t.Errorf("expected tool %q not found in %v", e, names)
		}
	}
}

func TestListTools_PrivateMode_ToolsFilter(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ServerAPIKey:     "test-server-key",
		ServerAPIURL:     fpAPI.server.URL + "/v4",
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
		Tools:            []string{"get_event", "create_environment", "delete_api_key"},
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	expected := []string{"get_event", "create_environment", "delete_api_key"}
	if len(names) != len(expected) {
		t.Errorf("expected %d tools, got %d: %v", len(expected), len(names), names)
	}
	for _, e := range expected {
		if !slices.Contains(names, e) {
			t.Errorf("expected tool %q not found in %v", e, names)
		}
	}
}

func TestListTools_PrivateMode_ToolsOverridesReadOnly(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ServerAPIKey:     "test-server-key",
		ServerAPIURL:     fpAPI.server.URL + "/v4",
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
		ReadOnly:         true,
		Tools:            []string{"get_event", "create_environment"},
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	expected := []string{"get_event", "create_environment"}
	if len(names) != len(expected) {
		t.Errorf("expected %d tools, got %d: %v", len(expected), len(names), names)
	}
	for _, e := range expected {
		if !slices.Contains(names, e) {
			t.Errorf("expected tool %q not found in %v", e, names)
		}
	}
}

func TestListTools_PublicMode(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
	})

	token := signFpjsJWT(t, privKey, "srvKey-mgmtKey-us", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	if len(names) != 15 {
		t.Errorf("expected 15 tools in public mode, got %d: %v", len(names), names)
	}
}

func TestListTools_Stdio(t *testing.T) {
	session := setupStdioServer(t, &config.Config{
		ServerAPIKey:     "test-server-key",
		ManagementAPIKey: "test-mgmt-key",
	})

	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}

	names := toolNames(result)
	if len(names) != 15 {
		t.Errorf("expected 15 tools, got %d: %v", len(names), names)
	}
}

// --- Group 2: Authentication ---

func TestAuth_PrivateMode_ValidToken(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        "secret",
		ServerAPIKey:     "test-server-key",
		ServerAPIURL:     fpAPI.server.URL + "/v4",
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})

	session := mustConnectMCPClient(t, ts.URL, "secret")
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}
	if len(result.Tools) != 15 {
		t.Errorf("expected 15 tools but got %d", len(result.Tools))
	}
}

func TestAuth_PrivateMode_InvalidToken(t *testing.T) {
	ts := setupTestServer(t, &config.Config{
		ServerAPIKey: "test-server-key",
		Region:       "us",
		AuthToken:    "secret",
	})

	_, err := tryConnectMCPClient(t, ts.URL, "wrong")
	if err == nil {
		t.Fatal("expected connection to fail with invalid token")
	}
	if !strings.Contains(err.Error(), "Unauthorized") {
		t.Errorf("expected Unauthorized error, got: %v", err)
	}
}

func TestAuth_PrivateMode_NoToken(t *testing.T) {
	ts := setupTestServer(t, &config.Config{
		ServerAPIKey: "test-server-key",
		Region:       "us",
		AuthToken:    "secret",
	})

	// Empty token — authRoundTripper skips the Authorization header
	_, err := tryConnectMCPClient(t, ts.URL, "")
	if err == nil {
		t.Fatal("expected connection to fail without token")
	}
	if !strings.Contains(err.Error(), "Unauthorized") {
		t.Errorf("expected Unauthorized error, got: %v", err)
	}
}

func TestAuth_PublicMode_AllEmpty(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
	})

	// "--" means all parts empty → should be rejected
	token := signFpjsJWT(t, privKey, "--", fpjsJWTIssuer)
	_, err := tryConnectMCPClient(t, ts.URL, token)
	if err == nil {
		t.Fatal("expected connection to fail with all-empty token")
	}
	if !strings.Contains(err.Error(), "Unauthorized") {
		t.Errorf("expected Unauthorized error, got: %v", err)
	}
}

func TestAuth_PublicMode_PartialToken_ServerOnly(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		ServerAPIURL: fpAPI.server.URL + "/v4",
	})

	token := signFpjsJWT(t, privKey, "srvKey--us", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)
	// Event tools should work
	result := mustCallTool(t, session, "get_event", map[string]any{"event_id": "test-123"})
	if result.IsError {
		t.Errorf("get_event should succeed with server key: %v", extractTextContent(t, result))
	}

	// Management tools should fail (no mgmt key)
	result2 := mustCallTool(t, session, "list_environments", map[string]any{})
	if !result2.IsError {
		t.Error("list_environments should fail without mgmt key")
	}
}

func TestAuth_PublicMode_PartialToken_MgmtOnly(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:       true,
		JwtPublicKey:     pubPEM,
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	token := signFpjsJWT(t, privKey, "-mgmtKey-us", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)

	// Management tools should work
	result := mustCallTool(t, session, "list_environments", map[string]any{})
	if result.IsError {
		t.Errorf("list_environments should succeed with mgmt key: %v", extractTextContent(t, result))
	}

	// Event tools should fail (no server key)
	result2 := mustCallTool(t, session, "get_event", map[string]any{"event_id": "test-123"})
	if !result2.IsError {
		t.Error("get_event should fail without server key")
	}
}

func TestAuth_PublicMode_InvalidToken(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
	})

	// Not a JWT at all
	_, err := tryConnectMCPClient(t, ts.URL, "not-a-jwt")
	if err == nil {
		t.Fatal("expected connection to fail with invalid token")
	}

	// JWT with wrong subject format (no dashes)
	token := signFpjsJWT(t, privKey, "nodashes", fpjsJWTIssuer)
	_, err = tryConnectMCPClient(t, ts.URL, token)
	if err == nil {
		t.Fatal("expected connection to fail with invalid subject format")
	}
}

func generateES256KeyPEM(t *testing.T) (privateKey *ecdsa.PrivateKey, publicKeyPEM string) {
	t.Helper()
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatalf("generating ES256 key: %v", err)
	}
	pubJWK, err := jwk.FromRaw(&priv.PublicKey)
	if err != nil {
		t.Fatalf("creating JWK from public key: %v", err)
	}
	pem, err := jwk.EncodePEM(pubJWK)
	if err != nil {
		t.Fatalf("encoding public key to PEM: %v", err)
	}
	return priv, string(pem)
}

func signFpjsJWT(t *testing.T, privateKey *ecdsa.PrivateKey, subject, issuer string) string {
	t.Helper()
	token, err := jwt.NewBuilder().
		Subject(subject).
		Issuer(issuer).
		Expiration(time.Now().Add(time.Hour)).
		Build()
	if err != nil {
		t.Fatalf("building JWT: %v", err)
	}
	signed, err := jwt.Sign(token, jwt.WithKey(jwa.ES256, privateKey))
	if err != nil {
		t.Fatalf("signing JWT: %v", err)
	}
	return string(signed)
}

func TestAuth_PublicMode_FpjsJWT_InvalidIssuer(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
	})

	token := signFpjsJWT(t, privKey, "srvKey-mgmtKey-us", "https://evil.example.com")
	_, err := tryConnectMCPClient(t, ts.URL, token)
	if err == nil {
		t.Fatal("expected connection to fail with invalid issuer")
	}
}

func TestAuth_PublicMode_FpjsJWT_InvalidSignature(t *testing.T) {
	_, pubPEM := generateES256KeyPEM(t)
	otherKey, _ := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
	})

	// Sign with a different key than what the server expects
	token := signFpjsJWT(t, otherKey, "srvKey-mgmtKey-us", fpjsJWTIssuer)
	_, err := tryConnectMCPClient(t, ts.URL, token)
	if err == nil {
		t.Fatal("expected connection to fail with invalid signature")
	}
}

// --- Group 3: Event Tools ---

func TestGetEvent_Success(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "get_event", map[string]any{"event_id": "test-event-123"})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	// Verify the mock received the request
	req := fpAPI.lastRequest()
	if req.Path != "/v4/events/test-event-123" {
		t.Errorf("expected path /v4/events/test-event-123, got %s", req.Path)
	}

	// Verify auth header
	authHeader := req.Header.Get("Authorization")
	if authHeader != "Bearer test-server-key" {
		t.Errorf("expected Authorization 'Bearer test-server-key', got %q", authHeader)
	}
}

func TestGetEvent_EmptyEventID(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "get_event", map[string]any{"event_id": ""})

	if !result.IsError {
		t.Error("expected error for empty event_id")
	}
	text := extractTextContent(t, result)
	if !strings.Contains(text, "event_id is required") {
		t.Errorf("expected 'event_id is required' error, got: %s", text)
	}
}

func TestGetEvent_APIError(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	fpAPI.overrideStatus = 404
	fpAPI.overrideBody = `{"error": {"code": "EventNotFound", "message": "event not found"}}`

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "get_event", map[string]any{"event_id": "nonexistent"})

	if !result.IsError {
		t.Fatal("expected error for 404 API response")
	}
	text := extractTextContent(t, result)
	for _, want := range []string{"EventNotFound", "event not found"} {
		if !strings.Contains(text, want) {
			t.Errorf("error %q missing %q (structured API error body must be surfaced, not just the HTTP status)", text, want)
		}
	}
}

// TestSearchEvents_APIError covers both wrapping paths and the full-body
// surfacing contract.
//
// Most rows use snake_case codes — that matches what API v4 actually ships,
// and the SDK's typed ErrorCode enum decodes them, so wrapFPError surfaces
// them via the structured fingerprint.AsErrorResponse model. Trailing rows
// use codes the enum rejects (PascalCase from API v3, or codes added after
// this SDK version) to lock in the body-parse fallback. One row carries an
// extra field beyond {code, message} to pin that future API additions reach
// the MCP client without code changes here.
//
// CORE-200 is the first row: retention-window detail must reach the client.
//
// Each row's wantInText must also appear in the *raw body* line that
// wrapFPError appends, not just the parsed leader — the body is what
// future-proofs us against new fields.
func TestSearchEvents_APIError(t *testing.T) {
	cases := []struct {
		name       string
		status     int
		code       string
		message    string
		extraJSON  string // appended inside the "error" object before serialization
		wantInText []string
	}{
		// Structured-model path (snake_case codes matching the SDK enum).
		{
			name:       "400 retention window (CORE-200)",
			status:     400,
			code:       "request_cannot_be_parsed",
			message:    "start is older than the retention window",
			wantInText: []string{"request_cannot_be_parsed", "retention window"},
		},
		{
			name:       "403 secret api key required",
			status:     403,
			code:       "secret_api_key_required",
			message:    "secret API key in header is missing or empty",
			wantInText: []string{"secret_api_key_required", "missing or empty"},
		},
		{
			name:       "403 secret api key not found",
			status:     403,
			code:       "secret_api_key_not_found",
			message:    "no fingerprint workspace found for specified secret API key",
			wantInText: []string{"secret_api_key_not_found", "no fingerprint workspace found"},
		},
		{
			name:       "403 wrong region",
			status:     403,
			code:       "wrong_region",
			message:    "server and workspace region differ",
			wantInText: []string{"wrong_region", "region differ"},
		},
		{
			name:       "403 subscription not active",
			status:     403,
			code:       "subscription_not_active",
			message:    "fingerprint workspace is not active",
			wantInText: []string{"subscription_not_active", "workspace is not active"},
		},
		{
			name:       "429 too many requests",
			status:     429,
			code:       "too_many_requests",
			message:    "the limit on secret API key requests per second has been exceeded",
			wantInText: []string{"too_many_requests", "limit", "exceeded"},
		},
		// Body-parse fallback. PascalCase is what API v3 emits (and what the
		// raw production curl returned earlier in this investigation); the SDK
		// enum rejects it, so AsErrorResponse comes back false and we depend
		// on the *GenericOpenAPIError.Body() path to recover the message.
		{
			name:       "403 v3-style PascalCase code (fallback)",
			status:     403,
			code:       "TokenNotFound",
			message:    "secret key is not found",
			wantInText: []string{"TokenNotFound", "secret key is not found"},
		},
		{
			name:       "400 unknown future code (fallback)",
			status:     400,
			code:       "code_added_after_this_sdk_version",
			message:    "this client cannot decode the enum but the message must still surface",
			wantInText: []string{"code_added_after_this_sdk_version", "must still surface"},
		},
		// Pins the full-body contract: any future field on the error envelope
		// (here a synthetic retry hint) must reach the MCP client unchanged.
		{
			name:       "400 with extra field (future-proofing)",
			status:     400,
			code:       "request_cannot_be_parsed",
			message:    "invalid start time, the start time cannot be older than 90 days",
			extraJSON:  `,"retry_after_seconds":42,"docs_url":"https://docs.fingerprint.com/errors/retention"`,
			wantInText: []string{"request_cannot_be_parsed", "older than 90 days", "retry_after_seconds", "42", "docs.fingerprint.com/errors/retention"},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			fpAPI := newMockFingerprintAPI()
			defer fpAPI.close()
			fpAPI.overrideStatus = tc.status
			fpAPI.overrideBody = fmt.Sprintf(`{"error":{"code":%q,"message":%q%s}}`, tc.code, tc.message, tc.extraJSON)

			ts := setupTestServer(t, &config.Config{
				AuthToken:    defaultAuthToken,
				ServerAPIKey: "test-server-key",
				ServerAPIURL: fpAPI.server.URL + "/v4",
				Region:       "us",
			})

			session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
			limit := 1
			result := mustCallTool(t, session, "search_events", map[string]any{"limit": limit})

			if !result.IsError {
				t.Fatalf("expected error for %d response", tc.status)
			}
			text := extractTextContent(t, result)
			for _, want := range tc.wantInText {
				if !strings.Contains(text, want) {
					t.Errorf("error %q missing %q", text, want)
				}
			}
		})
	}
}

func TestGetEvent_PublicMode_KeyExtraction(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		ServerAPIURL: fpAPI.server.URL + "/v4",
	})

	// JWT subject "testKey-mgmt-us" → server key should be "testKey"
	token := signFpjsJWT(t, privKey, "testKey-mgmt-us", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)
	result := mustCallTool(t, session, "get_event", map[string]any{"event_id": "evt-1"})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	req := fpAPI.lastRequest()
	authHeader := req.Header.Get("Authorization")
	if authHeader != "Bearer testKey" {
		t.Errorf("expected server API key 'Bearer testKey' from token, got %q", authHeader)
	}
}

func TestSearchEvents_Success(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	limit := 10
	result := mustCallTool(t, session, "search_events", map[string]any{"limit": limit})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}
}

// Confirms RFC3339 input is converted to the UnixMilli query params the
// Server API expects.
func TestSearchEvents_RFC3339Window(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	// Time-relative so the test stays inside the 90 day retention window
	// regardless of when it runs.
	startTime := time.Now().Add(-7 * 24 * time.Hour).UTC().Truncate(time.Second)
	endTime := time.Now().UTC().Truncate(time.Second)
	startStr := startTime.Format(time.RFC3339)
	endStr := endTime.Format(time.RFC3339)

	result := mustCallTool(t, session, "search_events", map[string]any{
		"limit": 10,
		"start": startStr,
		"end":   endStr,
	})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	q, err := url.ParseQuery(fpAPI.lastRequest().RawQuery)
	if err != nil {
		t.Fatalf("parse upstream query: %v", err)
	}

	wantStart := strconv.FormatInt(startTime.UnixMilli(), 10)
	if got := q.Get("start"); got != wantStart {
		t.Errorf("upstream start param = %q, want %q", got, wantStart)
	}
	wantEnd := strconv.FormatInt(endTime.UnixMilli(), 10)
	if got := q.Get("end"); got != wantEnd {
		t.Errorf("upstream end param = %q, want %q", got, wantEnd)
	}
}

// Confirms source=edge reaches the Server API query end-to-end.
func TestSearchEvents_SourceEdge(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "search_events", map[string]any{
		"limit":  10,
		"source": []string{"edge"},
	})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	q, err := url.ParseQuery(fpAPI.lastRequest().RawQuery)
	if err != nil {
		t.Fatalf("parse upstream query: %v", err)
	}
	if got := q.Get("source"); got != "edge" {
		t.Errorf("upstream source param = %q, want %q", got, "edge")
	}
}

// TestSearchEvents_InvalidStart locks the AI-actionable error contract
// end-to-end: a non-RFC3339 start surfaces an MCP error result whose text
// names the field and tells the AI what format to use.
func TestSearchEvents_InvalidStart(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "search_events", map[string]any{
		"limit": 10,
		"start": "yesterday",
	})

	if !result.IsError {
		t.Fatalf("expected error result, got success")
	}
	msg := extractTextContent(t, result)
	for _, want := range []string{"start", "RFC3339", "yesterday"} {
		if !strings.Contains(msg, want) {
			t.Errorf("error text %q missing %q", msg, want)
		}
	}
}

func TestSearchEvents_ZeroLimit(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	// Rejected either at protocol level, when the SDK validates limit=0 against
	// minimum:1 before the handler runs, or by the handler's own guard.
	result, err := callTool(t, session, "search_events", map[string]any{"limit": 0})
	if err == nil && !result.IsError {
		t.Error("expected error for zero limit")
	}
}

// Confirms an omitted limit succeeds and defaults to 10 on the upstream query,
// matching the documented schema default.
func TestSearchEvents_DefaultLimit(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "search_events", map[string]any{})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	q, err := url.ParseQuery(fpAPI.lastRequest().RawQuery)
	if err != nil {
		t.Fatalf("parse upstream query: %v", err)
	}
	if got := q.Get("limit"); got != "10" {
		t.Errorf("upstream limit param = %q, want %q", got, "10")
	}
}

func TestGetEvent_PublicMode_InvalidRegion(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		ServerAPIURL: fpAPI.server.URL + "/v4",
	})

	// JWT subject "srvKey-mgmt-xx" → region "xx" is invalid
	token := signFpjsJWT(t, privKey, "srvKey-mgmt-xx", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)
	result := mustCallTool(t, session, "get_event", map[string]any{"event_id": "evt-1"})

	if !result.IsError {
		t.Fatal("expected error for invalid region")
	}
	text := extractTextContent(t, result)
	if !strings.Contains(text, "unknown region") {
		t.Errorf("expected 'unknown region' error, got: %s", text)
	}
}

// --- Group 4: Management Tools ---

func TestListEnvironments_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "list_environments", map[string]any{})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	// Verify the mock received the correct auth header
	req := mgmtAPI.lastRequest()
	authHeader := req.Header.Get("Authorization")
	if authHeader != "Bearer test-mgmt-key" {
		t.Errorf("expected Authorization 'Bearer test-mgmt-key', got %q", authHeader)
	}
	apiVersion := req.Header.Get("X-API-Version")
	if apiVersion != "2025-11-20" {
		t.Errorf("expected X-API-Version '2025-11-20', got %q", apiVersion)
	}
}

func TestCreateEnvironment_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "create_environment", map[string]any{
		"name":        "Staging",
		"description": "Staging env",
	})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	// Verify mock received the request body
	req := mgmtAPI.lastRequest()
	if !strings.Contains(req.Body, `"name":"Staging"`) {
		t.Errorf("expected request body to contain name, got: %s", req.Body)
	}
}

func TestCreateEnvironment_EmptyName(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "create_environment", map[string]any{"name": ""})

	if !result.IsError {
		t.Error("expected error for empty name")
	}
	text := extractTextContent(t, result)
	if !strings.Contains(text, "name is required") {
		t.Errorf("expected 'name is required' error, got: %s", text)
	}
}

func TestDeleteEnvironment_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "delete_environment", map[string]any{"id": "env-1"})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	text := extractTextContent(t, result)
	if !strings.Contains(text, "deleted successfully") {
		t.Errorf("expected success message, got: %s", text)
	}
}

func TestListAPIKeys_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "list_api_keys", map[string]any{})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}
}

func TestGetAPIKey_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "get_api_key", map[string]any{"id": "key-1"})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}
}

func TestCreateAPIKey_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "create_api_key", map[string]any{
		"type": "secret",
		"name": "New Key",
	})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	// Verify mock received the request body
	req := mgmtAPI.lastRequest()
	if !strings.Contains(req.Body, `"type":"secret"`) {
		t.Errorf("expected request body to contain type, got: %s", req.Body)
	}
	if !strings.Contains(req.Body, `"name":"New Key"`) {
		t.Errorf("expected request body to contain name, got: %s", req.Body)
	}
}

func TestDeleteAPIKey_Success(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	result := mustCallTool(t, session, "delete_api_key", map[string]any{"id": "key-1"})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	text := extractTextContent(t, result)
	if !strings.Contains(text, "deleted successfully") {
		t.Errorf("expected success message, got: %s", text)
	}
}

func TestMgmtTool_PublicMode_KeyExtraction(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:       true,
		JwtPublicKey:     pubPEM,
		ManagementAPIURL: mgmtAPI.server.URL,
	})

	// JWT subject "srv-mgmtTestKey-us" → mgmt key should be "mgmtTestKey"
	token := signFpjsJWT(t, privKey, "srv-mgmtTestKey-us", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)
	result := mustCallTool(t, session, "list_environments", map[string]any{})

	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	req := mgmtAPI.lastRequest()
	authHeader := req.Header.Get("Authorization")
	if authHeader != "Bearer mgmtTestKey" {
		t.Errorf("expected mgmt API key 'Bearer mgmtTestKey' from token, got %q", authHeader)
	}
}

func TestMgmtTool_PublicMode_NoMgmtKey(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)

	ts := setupTestServer(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
	})

	// JWT subject "srvKey--us" → no mgmt key
	token := signFpjsJWT(t, privKey, "srvKey--us", fpjsJWTIssuer)
	session := mustConnectMCPClient(t, ts.URL, token)
	result := mustCallTool(t, session, "list_environments", map[string]any{})

	if !result.IsError {
		t.Error("expected error when no mgmt key in token")
	}
	text := extractTextContent(t, result)
	if !strings.Contains(text, "management API key is required") {
		t.Errorf("expected 'management API key is required' error, got: %s", text)
	}
}

// --- Group 5: HTTP Endpoints ---

func TestHealthEndpoint(t *testing.T) {
	ts := setupTestServer(t, &config.Config{
		AuthToken: defaultAuthToken,
	})

	resp, err := http.Get(ts.URL + "/health")
	if err != nil {
		t.Fatalf("health request failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected 200, got %d", resp.StatusCode)
	}
}

const challengeToken = "test-challenge-token"

func fetchChallenge(t *testing.T, configured string) (*http.Response, string) {
	t.Helper()

	ts := setupTestServer(t, &config.Config{
		AuthToken:                defaultAuthToken,
		OpenAIAppsChallengeToken: configured,
	})

	// No Authorization header: the portal's probe is unauthenticated.
	resp, err := http.Get(ts.URL + "/.well-known/openai-apps-challenge")
	if err != nil {
		t.Fatalf("challenge request failed: %v", err)
	}
	t.Cleanup(func() { resp.Body.Close() })

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	return resp, string(body)
}

func TestOpenAIAppsChallenge(t *testing.T) {
	resp, body := fetchChallenge(t, challengeToken)

	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected 200, got %d", resp.StatusCode)
	}
	if body != challengeToken {
		t.Errorf("body must be the bare token, got %q", body)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "text/plain; charset=utf-8" {
		t.Errorf("expected text/plain, got %q", ct)
	}
}

// A token routed through YAML or a secret file picks up whitespace, and any of
// it in the body fails verification.
func TestOpenAIAppsChallenge_TrimsSurroundingWhitespace(t *testing.T) {
	resp, body := fetchChallenge(t, "  "+challengeToken+"\n")

	if resp.StatusCode != http.StatusOK {
		t.Errorf("expected 200, got %d", resp.StatusCode)
	}
	if body != challengeToken {
		t.Errorf("expected the trimmed token, got %q", body)
	}
}

func TestOpenAIAppsChallenge_NotConfigured(t *testing.T) {
	for name, configured := range map[string]string{
		"unset":           "",
		"whitespace only": " \n",
	} {
		t.Run(name, func(t *testing.T) {
			resp, _ := fetchChallenge(t, configured)

			if resp.StatusCode != http.StatusNotFound {
				t.Errorf("expected 404 with no usable token, got %d", resp.StatusCode)
			}
		})
	}
}

// Registered as an exact path, not a subtree, so the token is not served from
// anywhere else. A subtree pattern or a catch-all route would hand it out under
// arbitrary paths.
func TestOpenAIAppsChallenge_ExactPathOnly(t *testing.T) {
	ts := setupTestServer(t, &config.Config{
		AuthToken:                defaultAuthToken,
		OpenAIAppsChallengeToken: challengeToken,
	})

	for name, path := range map[string]string{
		"trailing slash": "/.well-known/openai-apps-challenge/",
		"subpath":        "/.well-known/openai-apps-challenge/extra",
		"case variant":   "/.well-known/OpenAI-Apps-Challenge",
	} {
		t.Run(name, func(t *testing.T) {
			resp, err := http.Get(ts.URL + path)
			if err != nil {
				t.Fatalf("challenge request failed: %v", err)
			}
			defer resp.Body.Close()

			if resp.StatusCode != http.StatusNotFound {
				t.Errorf("expected 404 outside the exact path, got %d", resp.StatusCode)
			}
		})
	}
}

// The portal probes with GET (and Go's method pattern answers HEAD alongside it).
// Anything else is not the portal, so it gets a 405 rather than the token.
func TestOpenAIAppsChallenge_GETOnly(t *testing.T) {
	ts := setupTestServer(t, &config.Config{
		AuthToken:                defaultAuthToken,
		OpenAIAppsChallengeToken: challengeToken,
	})

	for method, want := range map[string]int{
		http.MethodGet:    http.StatusOK,
		http.MethodHead:   http.StatusOK,
		http.MethodPost:   http.StatusMethodNotAllowed,
		http.MethodPut:    http.StatusMethodNotAllowed,
		http.MethodDelete: http.StatusMethodNotAllowed,
	} {
		t.Run(method, func(t *testing.T) {
			req, err := http.NewRequest(method, ts.URL+"/.well-known/openai-apps-challenge", nil)
			if err != nil {
				t.Fatalf("build request: %v", err)
			}
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				t.Fatalf("challenge request failed: %v", err)
			}
			defer resp.Body.Close()

			if resp.StatusCode != want {
				t.Errorf("expected %d for %s, got %d", want, method, resp.StatusCode)
			}
		})
	}
}

func TestCORS_Options_PublicMode(t *testing.T) {
	ts := setupTestServer(t, &config.Config{
		PublicMode: true,
	})

	req, _ := http.NewRequest(http.MethodOptions, ts.URL+"/mcp", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("OPTIONS request failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusNoContent {
		t.Errorf("expected 204, got %d", resp.StatusCode)
	}

	if origin := resp.Header.Get("Access-Control-Allow-Origin"); origin != "*" {
		t.Errorf("expected CORS origin *, got %q", origin)
	}

	allowHeaders := resp.Header.Get("Access-Control-Allow-Headers")
	if !strings.Contains(allowHeaders, "Authorization") {
		t.Errorf("expected Authorization in allowed headers, got %q", allowHeaders)
	}
}

func TestCORS_Options_PrivateMode(t *testing.T) {
	ts := setupTestServer(t, &config.Config{})

	req, _ := http.NewRequest(http.MethodOptions, ts.URL+"/mcp", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("OPTIONS request failed: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusNoContent {
		t.Errorf("expected 204, got %d", resp.StatusCode)
	}

	allowHeaders := resp.Header.Get("Access-Control-Allow-Headers")
	if strings.Contains(allowHeaders, "Authorization") {
		t.Errorf("expected Authorization NOT in allowed headers for private mode, got %q", allowHeaders)
	}
}

// A browser client can only send Mcp-Session-Id if preflight allows it, and
// that header is what correlates a client's requests. Stateless doesn't issue
// one, so gating the allow-list on STATELESS would silently shut browser
// clients out of the correlation.
func TestCORS_AllowsSessionIDHeader(t *testing.T) {
	ts := setupTestServer(t, &config.Config{PublicMode: true})

	req, _ := http.NewRequest(http.MethodOptions, ts.URL+"/mcp", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("OPTIONS request failed: %v", err)
	}
	defer resp.Body.Close()

	allowHeaders := resp.Header.Get("Access-Control-Allow-Headers")
	if !strings.Contains(allowHeaders, "Mcp-Session-Id") {
		t.Errorf("expected Mcp-Session-Id in allowed headers, got %q", allowHeaders)
	}
}

// Clients from spec 2026-07-28 on mirror the JSON-RPC method and the target
// tool/prompt/resource into these headers, so a browser client can't complete
// a preflight without them.
func TestCORS_AllowsRoutingHeaders(t *testing.T) {
	ts := setupTestServer(t, &config.Config{PublicMode: true})

	req, _ := http.NewRequest(http.MethodOptions, ts.URL+"/mcp", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("OPTIONS request failed: %v", err)
	}
	defer resp.Body.Close()

	allowHeaders := resp.Header.Get("Access-Control-Allow-Headers")
	for _, h := range []string{"Mcp-Method", "Mcp-Name"} {
		if !strings.Contains(allowHeaders, h) {
			t.Errorf("expected %s in allowed headers, got %q", h, allowHeaders)
		}
	}
}

// TestLoggingMiddleware_ResourceAndPromptFields verifies that the middleware
// extracts resource_uri from resources/read requests and prompt_name from
// prompts/get requests and includes them in the structured log line, mirroring
// the existing tool_name extraction. Covers both happy and failure paths.
func TestLoggingMiddleware_ResourceAndPromptFields(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	handler := newCaptureHandler()
	logger := slog.New(handler)

	cfg := &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
	}
	ts := setupTestServerWithLogger(t, cfg, logger)

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	// Static schema resource — no upstream API call needed.
	const resourceURI = "fingerprint://schemas/event"
	if _, err := session.ReadResource(context.Background(), &mcp.ReadResourceParams{URI: resourceURI}); err != nil {
		t.Fatalf("ReadResource(%s) failed: %v", resourceURI, err)
	}

	// Discover an embedded prompt name at runtime so the test isn't coupled to
	// a specific SKILL filename. registerPrompts walks skills/**/SKILL.md.
	promptsList, err := session.ListPrompts(context.Background(), &mcp.ListPromptsParams{})
	if err != nil {
		t.Fatalf("ListPrompts failed: %v", err)
	}
	if len(promptsList.Prompts) == 0 {
		t.Fatal("expected at least one embedded prompt; check skills/ directory")
	}
	promptName := promptsList.Prompts[0].Name
	if _, err := session.GetPrompt(context.Background(), &mcp.GetPromptParams{Name: promptName}); err != nil {
		t.Fatalf("GetPrompt(%s) failed: %v", promptName, err)
	}

	// Failure path: a URI that matches no registered resource or template
	// makes the SDK return a protocol error, exercising the "MCP method failed"
	// branch. The resource_uri attr should still be present on that log line.
	const badURI = "fingerprint://does-not-exist/abc"
	_, _ = session.ReadResource(context.Background(), &mcp.ReadResourceParams{URI: badURI})

	records := handler.snapshot()

	// Assert the new fields populate on the started, completed, and failed
	// records so a regression that touches only one branch (e.g. someone
	// adds a new field on completed but forgets started) fails the test.
	var sawResourceStarted, sawResourceCompleted bool
	var sawPromptStarted, sawPromptCompleted bool
	var sawResourceFailed bool
	for _, r := range records {
		attrs := recordAttrs(r)
		switch {
		case r.Message == "MCP method started" && attrs["method"] == "resources/read" && attrs["resource_uri"] == resourceURI:
			sawResourceStarted = true
		case r.Message == "MCP method completed" && attrs["method"] == "resources/read" && attrs["resource_uri"] == resourceURI:
			sawResourceCompleted = true
		case r.Message == "MCP method started" && attrs["method"] == "prompts/get" && attrs["prompt_name"] == promptName:
			sawPromptStarted = true
		case r.Message == "MCP method completed" && attrs["method"] == "prompts/get" && attrs["prompt_name"] == promptName:
			sawPromptCompleted = true
		case r.Message == "MCP method failed" && attrs["method"] == "resources/read" && attrs["resource_uri"] == badURI:
			sawResourceFailed = true
		}
	}
	if !sawResourceStarted {
		t.Errorf("expected MCP method started with method=resources/read and resource_uri=%q", resourceURI)
	}
	if !sawResourceCompleted {
		t.Errorf("expected MCP method completed with method=resources/read and resource_uri=%q", resourceURI)
	}
	if !sawPromptStarted {
		t.Errorf("expected MCP method started with method=prompts/get and prompt_name=%q", promptName)
	}
	if !sawPromptCompleted {
		t.Errorf("expected MCP method completed with method=prompts/get and prompt_name=%q", promptName)
	}
	if !sawResourceFailed {
		t.Errorf("expected MCP method failed with method=resources/read and resource_uri=%q", badURI)
	}
	if t.Failed() {
		for _, r := range records {
			t.Logf("  %s %v", r.Message, recordAttrs(r))
		}
	}
}

// signFpjsJWTWithSubID mints a Fingerprint-issued JWT carrying the
// urn:fingerprint:sub_id claim, which surfaces as Event.SubscriptionID on
// analytics events.
func signFpjsJWTWithSubID(t *testing.T, privateKey *ecdsa.PrivateKey, subject, subID string) string {
	t.Helper()
	builder := jwt.NewBuilder().
		Subject(subject).
		Issuer(fpjsJWTIssuer).
		Expiration(time.Now().Add(time.Hour))
	if subID != "" {
		builder = builder.Claim(claimSubscriptionID, subID)
	}
	token, err := builder.Build()
	if err != nil {
		t.Fatalf("building JWT: %v", err)
	}
	signed, err := jwt.Sign(token, jwt.WithKey(jwa.ES256, privateKey))
	if err != nil {
		t.Fatalf("signing JWT: %v", err)
	}
	return string(signed)
}

// A pre-2026-07-28 client names itself in the initialize params and nowhere
// else: no _meta, and the session is not carrying the params yet while the
// initialize call is still in flight. The SDK client handshakes with
// server/discover now, so no other test exercises this path, and without it
// the analytics middleware silently stops attributing every current client.
func TestAnalytics_LegacyInitializeCarriesClientName(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)
	emitter := newRecordingEmitter()

	ts := setupTestServerWithEmitter(t, &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		Transport:    "streamable-http",
	}, emitter)

	const subID = "sub_legacy_init"
	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", subID)

	body := `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"legacy-client","version":"3"}}}`
	req, err := http.NewRequest(http.MethodPost, ts.URL+"/mcp", strings.NewReader(body))
	if err != nil {
		t.Fatalf("building request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	req.Header.Set("Authorization", "Bearer "+token)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("initialize: %v", err)
	}
	defer resp.Body.Close()
	if _, err := io.ReadAll(resp.Body); err != nil {
		t.Fatalf("reading initialize response: %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("initialize status = %d, want 200", resp.StatusCode)
	}

	var found bool
	for _, ev := range emitter.snapshot() {
		if ev.Type != "mcp_method_called" || ev.Properties["method"] != "initialize" {
			continue
		}
		found = true
		if got := ev.Properties["client_name"]; got != "legacy-client" {
			t.Errorf("client_name=%v, want legacy-client", got)
		}
		if got := ev.Properties["client_version"]; got != "3" {
			t.Errorf("client_version=%v, want 3", got)
		}
	}
	if !found {
		t.Error("no mcp_method_called event for initialize")
	}
}

func TestAnalytics_PublicMode_EmitsEvent(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	privKey, pubPEM := generateES256KeyPEM(t)
	emitter := newRecordingEmitter()

	cfg := &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		Transport:    "streamable-http",
	}
	ts := setupTestServerWithEmitter(t, cfg, emitter)

	// Public-mode JWT carries serverKey-mgmtKey-region in the subject and the
	// subscription_id as a custom claim.
	const subID = "sub_test_xyz"
	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", subID)

	session := mustConnectMCPClient(t, ts.URL, token)

	// The handshake is implicit on Connect. Drive a tools/list to land an event.
	if _, err := session.ListTools(context.Background(), &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("ListTools: %v", err)
	}

	events := emitter.snapshot()
	if len(events) == 0 {
		t.Fatal("expected at least one analytics event, got 0")
	}

	methods := map[string]bool{}
	var sawHandshakeWithClientName bool
	for _, ev := range events {
		if ev.Type != "mcp_method_called" || ev.SubscriptionID != subID {
			continue
		}
		method, _ := ev.Properties["method"].(string)
		if method == "" {
			t.Errorf("event missing method property: %+v", ev.Properties)
			continue
		}
		methods[method] = true
		if ev.Properties["transport"] != "streamable-http" {
			t.Errorf("%s: transport=%v, want streamable-http", method, ev.Properties["transport"])
		}
		if _, ok := ev.Properties["duration_ms"]; !ok {
			t.Errorf("%s: missing duration_ms property", method)
		}
		// The handshake is the method that carries client_name/client_version.
		if method == "initialize" || method == "server/discover" {
			if ev.Properties["client_name"] != "test-client" {
				t.Errorf("%s: client_name=%v, want test-client", method, ev.Properties["client_name"])
			}
			sawHandshakeWithClientName = true
		}
	}
	if !methods["initialize"] && !methods["server/discover"] {
		t.Errorf("expected an mcp_method_called event for the handshake, got methods=%v", methods)
	}
	if !methods["tools/list"] {
		t.Errorf("expected an mcp_method_called event with method=tools/list, got methods=%v", methods)
	}
	if !sawHandshakeWithClientName {
		t.Errorf("expected the handshake event to carry client_name in Properties")
	}
}

// The inspector and the analytics event are the two halves of the same
// request, and nothing links them unless both report the client's session id.
// This is what makes an inspected request attributable to the client that
// named itself on the handshake.
func TestAnalytics_SessionIDMatchesTheInspectedRequest(t *testing.T) {
	const sessionID = "N7QHUFURVHGG3X4OAOOPEHPNVY"

	ins := newRecordingInspector()
	emitter := newRecordingEmitter()
	privKey, pubPEM := generateES256KeyPEM(t)
	cfg := &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		Transport:    "streamable-http",
	}
	ts := setupTestServerWithInspectorAndEmitter(t, cfg, ins, emitter)

	// Analytics are gated on a subscription id, so this needs a real public-mode JWT.
	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", "sub_test_xyz")

	client := mcp.NewClient(&mcp.Implementation{Name: "test-client", Version: "v0.0.1"}, nil)
	transport := &mcp.StreamableClientTransport{
		Endpoint: ts.URL + "/mcp",
		HTTPClient: &http.Client{
			Transport: &authRoundTripper{
				token: token,
				base: &headerRoundTripper{
					headers: map[string]string{"Mcp-Session-Id": sessionID},
					base:    http.DefaultTransport,
				},
			},
		},
	}
	session, err := client.Connect(context.Background(), transport, nil)
	if err != nil {
		t.Fatalf("failed to connect MCP client: %v", err)
	}
	t.Cleanup(func() { session.Close() })

	if _, err := session.ListTools(context.Background(), &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("ListTools: %v", err)
	}

	// The inspector sees it as a header, which is how it reaches the edge payload.
	var inspectedSession bool
	for _, info := range ins.snapshot() {
		if info.Header.Get("Mcp-Session-Id") == sessionID {
			inspectedSession = true
			break
		}
	}
	if !inspectedSession {
		t.Error("expected the inspector to see Mcp-Session-Id on at least one request")
	}

	// And the analytics event reports the same value, which is the join.
	events := emitter.snapshot()
	if len(events) == 0 {
		t.Fatal("expected at least one analytics event, got 0")
	}
	for _, ev := range events {
		if ev.Type != "mcp_method_called" {
			continue
		}
		if got := ev.Properties["mcp_session_id"]; got != sessionID {
			t.Errorf("%v: mcp_session_id=%v, want %s", ev.Properties["method"], got, sessionID)
		}
	}
}

// The inspector has to see the JSON-RPC method so it can skip work for
// methods that carry no signal, and it has to do that without eating the body
// the handler still needs.
func TestInspector_SeesMCPMethodAndClientNameAndLeavesTheBodyIntact(t *testing.T) {
	ins := newRecordingInspector()
	privKey, pubPEM := generateES256KeyPEM(t)
	cfg := &config.Config{PublicMode: true, JwtPublicKey: pubPEM, Transport: "streamable-http"}
	ts := setupTestServerWithInspector(t, cfg, ins, nil)

	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", "sub_test_xyz")
	client := mcp.NewClient(&mcp.Implementation{Name: "test-client", Version: "v0.0.1"}, nil)
	transport := &mcp.StreamableClientTransport{
		Endpoint:   ts.URL + "/mcp",
		HTTPClient: &http.Client{Transport: &authRoundTripper{token: token, base: http.DefaultTransport}},
	}
	session, err := client.Connect(context.Background(), transport, nil)
	if err != nil {
		t.Fatalf("failed to connect MCP client: %v", err)
	}
	t.Cleanup(func() { session.Close() })

	// The handler only answers this if the body survived the peek.
	res, err := session.ListTools(context.Background(), &mcp.ListToolsParams{})
	if err != nil {
		t.Fatalf("ListTools: %v", err)
	}
	if len(res.Tools) == 0 {
		t.Fatal("expected tools back, got none")
	}

	seen := map[string]bool{}
	for _, info := range ins.snapshot() {
		seen[info.MCPMethod] = true
	}
	if !seen["initialize"] && !seen["server/discover"] {
		t.Errorf("inspector never saw the handshake method, saw %v", seen)
	}
	if !seen["tools/list"] {
		t.Errorf("inspector never saw MCPMethod=\"tools/list\", saw %v", seen)
	}
	// GET and DELETE carry no body, so they must report unknown rather than
	// inheriting a method from a previous request.
	for _, info := range ins.snapshot() {
		if info.Method != http.MethodPost && info.MCPMethod != "" {
			t.Errorf("%s carried MCPMethod=%q, want empty", info.Method, info.MCPMethod)
		}
		if info.Method != http.MethodPost && info.ClientName != "" {
			t.Errorf("%s carried ClientName=%q, want empty", info.Method, info.ClientName)
		}
	}

	// The SDK client marshals mcp.MetaKeyClientInfo itself, so an upstream rename
	// fails here rather than silently reporting no client.
	named := map[string]bool{}
	for _, info := range ins.snapshot() {
		if info.ClientName != "" {
			named[info.MCPMethod] = true
			if info.ClientName != "test-client" {
				t.Errorf("%s carried ClientName=%q, want \"test-client\"", info.MCPMethod, info.ClientName)
			}
		}
	}
	if !named["tools/list"] {
		t.Errorf("tools/list carried no ClientName, named methods: %v", named)
	}
}

func TestPeek_ResolvesClientName(t *testing.T) {
	const metaKey = "io.modelcontextprotocol/clientInfo"
	cases := []struct {
		name string
		body string
		want string
	}{
		{"legacy initialize", `{"method":"initialize","params":{"clientInfo":{"name":"claude-code"}}}`, "claude-code"},
		{"discover via meta", `{"method":"server/discover","params":{"_meta":{"` + metaKey + `":{"name":"claude-code"}}}}`, "claude-code"},
		{"tool call via meta", `{"method":"tools/call","params":{"_meta":{"` + metaKey + `":{"name":"cursor-vscode"}},"name":"get_current_time"}}`, "cursor-vscode"},
		{"params wins over meta", `{"method":"initialize","params":{"clientInfo":{"name":"real"},"_meta":{"` + metaKey + `":{"name":"relay"}}}}`, "real"},
		{"meta without client info", `{"method":"tools/list","params":{"_meta":{"progressToken":1}}}`, ""},
		{"no params", `{"method":"ping"}`, ""},
		{"hostile params shape", `{"method":"ping","params":5}`, ""},
		{"spaces are kept", `{"method":"initialize","params":{"clientInfo":{"name":"openai-mcp (Agent Builder)"}}}`, "openai-mcp (Agent Builder)"},
		{"non-ascii is kept", `{"method":"initialize","params":{"clientInfo":{"name":"клиент"}}}`, "клиент"},
		{"empty name", `{"method":"initialize","params":{"clientInfo":{"name":""}}}`, ""},
		{"newline injects a log line", `{"method":"initialize","params":{"clientInfo":{"name":"a\nlevel=ERROR fake"}}}`, ""},
		{"tab", `{"method":"initialize","params":{"clientInfo":{"name":"a\tb"}}}`, ""},
		{"null byte", `{"method":"initialize","params":{"clientInfo":{"name":"a\u0000"}}}`, ""},
		{"at the cap", `{"method":"initialize","params":{"clientInfo":{"name":"` + strings.Repeat("a", maxClientNameLen) + `"}}}`, strings.Repeat("a", maxClientNameLen)},
		{"over the cap", `{"method":"initialize","params":{"clientInfo":{"name":"` + strings.Repeat("a", maxClientNameLen+1) + `"}}}`, ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodPost, "/mcp", strings.NewReader(tc.body))
			if got := peekMCPRequest(r).clientName(); got != tc.want {
				t.Errorf("clientName() = %q, want %q", got, tc.want)
			}
			rest, err := io.ReadAll(r.Body)
			if err != nil {
				t.Fatalf("reading body back: %v", err)
			}
			if string(rest) != tc.body {
				t.Errorf("body after peek = %q, want %q", rest, tc.body)
			}
		})
	}

	t.Run("GET carries no body", func(t *testing.T) {
		r := httptest.NewRequest(http.MethodGet, "/mcp", nil)
		peek := peekMCPRequest(r)
		if peek.Method != "" || peek.clientName() != "" {
			t.Errorf("GET gave method=%q client=%q, want both empty", peek.Method, peek.clientName())
		}
	})
}

func TestPeek_LargeBodyReportsUnknown(t *testing.T) {
	const metaKey = "io.modelcontextprotocol/clientInfo"
	body := `{"method":"tools/call","params":{"name":"search_events","arguments":{"q":"` +
		strings.Repeat("x", mcpMethodPeekBytes) + `"},"_meta":{"` + metaKey + `":{"name":"claude-code"}}}}`

	r := httptest.NewRequest(http.MethodPost, "/mcp", strings.NewReader(body))
	peek := peekMCPRequest(r)
	if peek.Method != "" {
		t.Errorf("MCPMethod = %q, want empty past the peek window", peek.Method)
	}
	if got := peek.clientName(); got != "" {
		t.Errorf("clientName() = %q, want empty past the peek window", got)
	}
	rest, err := io.ReadAll(r.Body)
	if err != nil {
		t.Fatalf("reading body back: %v", err)
	}
	if string(rest) != body {
		t.Errorf("body after peek was %d bytes, want %d", len(rest), len(body))
	}
}

// Hand-POSTed: the SDK client handshakes with server/discover and can no longer
// produce a 2025-06-18 initialize.
func TestInspector_SeesClientNameFromLegacyInitialize(t *testing.T) {
	ins := newRecordingInspector()
	privKey, pubPEM := generateES256KeyPEM(t)
	cfg := &config.Config{PublicMode: true, JwtPublicKey: pubPEM, Transport: "streamable-http"}
	ts := setupTestServerWithInspector(t, cfg, ins, nil)

	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", "sub_legacy_inspect")
	body := `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"legacy-client","version":"3"}}}`
	req, err := http.NewRequest(http.MethodPost, ts.URL+"/mcp", strings.NewReader(body))
	if err != nil {
		t.Fatalf("building request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	req.Header.Set("Authorization", "Bearer "+token)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("initialize: %v", err)
	}
	defer resp.Body.Close()
	if _, err := io.ReadAll(resp.Body); err != nil {
		t.Fatalf("reading initialize response: %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("initialize status = %d, want 200", resp.StatusCode)
	}

	var found bool
	for _, info := range ins.snapshot() {
		if info.MCPMethod != "initialize" {
			continue
		}
		found = true
		if info.ClientName != "legacy-client" {
			t.Errorf("ClientName = %q, want legacy-client", info.ClientName)
		}
	}
	if !found {
		t.Error("inspector never saw the legacy initialize")
	}
}

// Asserting the tool result matters: a name-only assertion still passes with a
// truncated body.
func TestInspector_LeavesTheBodyIntactOnAClientNamedCall(t *testing.T) {
	ins := newRecordingInspector()
	privKey, pubPEM := generateES256KeyPEM(t)
	cfg := &config.Config{PublicMode: true, JwtPublicKey: pubPEM, Transport: "streamable-http"}
	ts := setupTestServerWithInspector(t, cfg, ins, nil)

	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", "sub_tool_call")
	client := mcp.NewClient(&mcp.Implementation{Name: "test-client", Version: "v0.0.1"}, nil)
	transport := &mcp.StreamableClientTransport{
		Endpoint:   ts.URL + "/mcp",
		HTTPClient: &http.Client{Transport: &authRoundTripper{token: token, base: http.DefaultTransport}},
	}
	session, err := client.Connect(context.Background(), transport, nil)
	if err != nil {
		t.Fatalf("failed to connect MCP client: %v", err)
	}
	t.Cleanup(func() { session.Close() })

	res, err := session.CallTool(context.Background(), &mcp.CallToolParams{Name: "get_current_time"})
	if err != nil {
		t.Fatalf("CallTool: %v", err)
	}
	if res.IsError {
		t.Fatalf("get_current_time returned an error result: %+v", res.Content)
	}

	var found bool
	for _, info := range ins.snapshot() {
		if info.MCPMethod != "tools/call" {
			continue
		}
		found = true
		if info.ClientName != "test-client" {
			t.Errorf("ClientName = %q, want test-client", info.ClientName)
		}
	}
	if !found {
		t.Error("inspector never saw the tools/call")
	}
}

func TestAnalytics_PrivateMode_EmitsNothing(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	emitter := newRecordingEmitter()

	cfg := &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
		Transport:    "streamable-http",
		// PublicMode left false. There's no JWT path, so the middleware
		// never sees a subscription_id and the analytics gate stays shut.
	}
	ts := setupTestServerWithEmitter(t, cfg, emitter)

	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	if _, err := session.ListTools(context.Background(), &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("ListTools: %v", err)
	}

	if got := len(emitter.snapshot()); got != 0 {
		t.Errorf("private mode should emit 0 events, got %d", got)
		for _, ev := range emitter.snapshot() {
			t.Logf("  type=%s sub=%s props=%v", ev.Type, ev.SubscriptionID, ev.Properties)
		}
	}
}

func TestAnalytics_PublicMode_NoSubID_EmitsNothing(t *testing.T) {
	privKey, pubPEM := generateES256KeyPEM(t)
	emitter := newRecordingEmitter()

	cfg := &config.Config{
		PublicMode:   true,
		JwtPublicKey: pubPEM,
		Transport:    "streamable-http",
	}
	ts := setupTestServerWithEmitter(t, cfg, emitter)

	// Mint a JWT WITHOUT the subscription_id claim. The auth path still
	// succeeds (subID is optional), but with no user identifier the analytics
	// gate stays closed and no event leaves the process.
	token := signFpjsJWTWithSubID(t, privKey, "test-server-key-test-mgmt-key-us", "")

	session := mustConnectMCPClient(t, ts.URL, token)
	if _, err := session.ListTools(context.Background(), &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("ListTools: %v", err)
	}

	if got := len(emitter.snapshot()); got != 0 {
		t.Errorf("missing sub_id should result in 0 emitted events, got %d", got)
	}
}

// --- Group: request inspector hook ---

func TestRequestInspector_ReceivesHeadersAndRemoteAddr(t *testing.T) {
	ins := newRecordingInspector()
	cfg := &config.Config{
		AuthToken: defaultAuthToken,
		Transport: "streamable-http",
	}
	ts := setupTestServerWithInspector(t, cfg, ins, nil)

	// Connect a real MCP client that sends a custom header on every request
	// so we can verify headers arrive verbatim.
	client := mcp.NewClient(&mcp.Implementation{Name: "test-client", Version: "v0.0.1"}, nil)
	transport := &mcp.StreamableClientTransport{
		Endpoint: ts.URL + "/mcp",
		HTTPClient: &http.Client{
			Transport: &authRoundTripper{
				token: defaultAuthToken,
				base: &headerRoundTripper{
					headers: map[string]string{"X-Inspect-Fixture": "fixture-value-123"},
					base:    http.DefaultTransport,
				},
			},
		},
	}
	session, err := client.Connect(context.Background(), transport, nil)
	if err != nil {
		t.Fatalf("failed to connect MCP client: %v", err)
	}
	t.Cleanup(func() { session.Close() })

	if _, err := session.ListTools(context.Background(), &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("ListTools: %v", err)
	}

	infos := ins.snapshot()
	if len(infos) == 0 {
		t.Fatal("expected the inspector to see at least one request, got 0")
	}
	var sawPost bool
	for i, info := range infos {
		if got := info.Header.Get("Authorization"); got != "Bearer "+defaultAuthToken {
			t.Errorf("request %d: Authorization=%q, want %q", i, got, "Bearer "+defaultAuthToken)
		}
		if got := info.Header.Get("X-Inspect-Fixture"); got != "fixture-value-123" {
			t.Errorf("request %d: X-Inspect-Fixture=%q, want %q", i, got, "fixture-value-123")
		}
		if info.Method == "" {
			t.Errorf("request %d: Method is empty", i)
		}
		if info.Method == http.MethodPost {
			sawPost = true
		}
		if info.URL == nil || info.URL.Path != "/mcp" {
			t.Errorf("request %d: URL=%v, want path /mcp", i, info.URL)
		}
		if info.RemoteIP != "127.0.0.1" {
			t.Errorf("request %d: RemoteIP=%q, want 127.0.0.1", i, info.RemoteIP)
		}
		if info.RemotePort <= 0 || info.RemotePort > 65535 {
			t.Errorf("request %d: RemotePort=%d, want a valid TCP port", i, info.RemotePort)
		}
	}
	if !sawPost {
		t.Error("expected at least one POST request to be inspected (MCP messages are POSTed)")
	}

	// Method and URL arrive verbatim, query string included. A raw
	// unauthenticated POST is enough to prove it: the hook fires before
	// auth, so the 401 outcome doesn't matter.
	resp, err := http.Post(ts.URL+"/mcp?fixture=query-123", "application/json", strings.NewReader("{}"))
	if err != nil {
		t.Fatalf("POST /mcp with query: %v", err)
	}
	resp.Body.Close()
	infos = ins.snapshot()
	last := infos[len(infos)-1]
	if last.Method != http.MethodPost {
		t.Errorf("raw request: Method=%q, want POST", last.Method)
	}
	if last.URL == nil || last.URL.Path != "/mcp" || last.URL.RawQuery != "fixture=query-123" {
		t.Errorf("raw request: URL=%v, want path /mcp with query fixture=query-123", last.URL)
	}

	// The hook is scoped to the MCP endpoint: /health must not fire it.
	before := len(ins.snapshot())
	healthResp, err := http.Get(ts.URL + "/health")
	if err != nil {
		t.Fatalf("GET /health: %v", err)
	}
	healthResp.Body.Close()
	if got := len(ins.snapshot()); got != before {
		t.Errorf("/health should not fire the inspector: records went %d -> %d", before, got)
	}
}

func TestRequestInspector_FiresOnFailedAuth(t *testing.T) {
	ins := newRecordingInspector()
	cfg := &config.Config{
		AuthToken: defaultAuthToken,
		Transport: "streamable-http",
	}
	ts := setupTestServerWithInspector(t, cfg, ins, nil)

	if _, err := tryConnectMCPClient(t, ts.URL, "wrong-token"); err == nil {
		t.Fatal("expected connection with a bad token to fail")
	}

	// The inspector wraps outside auth, so rejected requests are still seen.
	infos := ins.snapshot()
	if len(infos) == 0 {
		t.Fatal("inspector should see requests that fail authentication, got 0 records")
	}
	if got := infos[0].Header.Get("Authorization"); got != "Bearer wrong-token" {
		t.Errorf("Authorization=%q, want %q", got, "Bearer wrong-token")
	}
}

func TestRequestInspector_FailOpen(t *testing.T) {
	capture := newCaptureHandler()
	ins := &recordingInspector{err: errors.New("audit backend unavailable")}
	cfg := &config.Config{
		AuthToken: defaultAuthToken,
		Transport: "streamable-http",
	}
	ts := setupTestServerWithInspector(t, cfg, ins, slog.New(capture))

	// Every Inspect call fails, but requests must still be served.
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)
	if _, err := session.ListTools(context.Background(), &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("requests must succeed when the inspector fails (fail-open): %v", err)
	}
	if len(ins.snapshot()) == 0 {
		t.Error("inspector should still have been invoked")
	}

	// The failure must be surfaced in the server log.
	var saw bool
	for _, r := range capture.snapshot() {
		if r.Message != "request inspector failed" {
			continue
		}
		saw = true
		attrs := recordAttrs(r)
		if got := fmt.Sprint(attrs["err"]); !strings.Contains(got, "audit backend unavailable") {
			t.Errorf("err attr = %q, want it to contain %q", got, "audit backend unavailable")
		}
		if got := fmt.Sprint(attrs["remote_ip"]); got != "127.0.0.1" {
			t.Errorf("remote_ip attr = %q, want 127.0.0.1", got)
		}
	}
	if !saw {
		t.Error("expected a 'request inspector failed' log line")
	}
}

func TestRequestInspector_Stdio_NeverFires(t *testing.T) {
	ins := newRecordingInspector()
	app, err := New(&config.Config{Transport: "stdio"}, &opts{inspector: ins})
	if err != nil {
		t.Fatalf("failed to create app: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	t.Cleanup(cancel)

	if err := app.registerTools(ctx); err != nil {
		t.Fatalf("failed to register tools: %v", err)
	}

	serverTransport, clientTransport := mcp.NewInMemoryTransports()
	go func() {
		_ = app.server.Run(ctx, serverTransport)
	}()

	client := mcp.NewClient(&mcp.Implementation{Name: "test-client", Version: "v0.0.1"}, nil)
	session, err := client.Connect(ctx, clientTransport, nil)
	if err != nil {
		t.Fatalf("failed to connect to stdio server: %v", err)
	}
	t.Cleanup(func() { session.Close() })

	if _, err := session.ListTools(ctx, &mcp.ListToolsParams{}); err != nil {
		t.Fatalf("ListTools: %v", err)
	}

	if got := len(ins.snapshot()); got != 0 {
		t.Errorf("stdio transport must never fire the inspector, got %d records", got)
	}
}

func TestRequestInspector_ClosedOnRunExit(t *testing.T) {
	ins := newRecordingInspector()

	// An unsupported transport makes Run fail fast after setup; the deferred
	// drain must still close the inspector on that exit path.
	err := Run(context.Background(), &config.Config{Transport: "bogus"},
		WithLogger(slog.New(slog.DiscardHandler)),
		WithRequestInspector(ins),
	)
	if err == nil {
		t.Fatal("expected Run to fail with an unsupported transport")
	}
	if got := ins.closeCount(); got != 1 {
		t.Errorf("inspector Close calls = %d, want 1 (Run must drain the inspector on every exit path)", got)
	}
}

func TestSplitRemoteAddr(t *testing.T) {
	tests := []struct {
		addr     string
		wantIP   string
		wantPort int
	}{
		{"203.0.113.7:54321", "203.0.113.7", 54321},
		{"[2001:db8::1]:443", "2001:db8::1", 443},
		{"1.2.3.4:http", "1.2.3.4", 0},
		{"garbage", "garbage", 0},
		{"", "", 0},
	}
	for _, tt := range tests {
		ip, port := splitRemoteAddr(tt.addr)
		if ip != tt.wantIP || port != tt.wantPort {
			t.Errorf("splitRemoteAddr(%q) = (%q, %d), want (%q, %d)", tt.addr, ip, port, tt.wantIP, tt.wantPort)
		}
	}
}

// --- Group: get_current_time ---

func TestGetCurrentTime_UTC(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "get_current_time", map[string]any{})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	var out GetCurrentTimeOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse output: %v", err)
	}

	parsed, err := time.Parse(time.RFC3339, out.UTC)
	if err != nil {
		t.Fatalf("utc %q is not RFC3339: %v", out.UTC, err)
	}
	if parsed.Location() != time.UTC {
		t.Errorf("expected utc to be in UTC, got %v", parsed.Location())
	}
	if delta := time.Since(parsed); delta < 0 || delta > time.Minute {
		t.Errorf("utc %q is not close to now (delta %v)", out.UTC, delta)
	}
	if out.Unix != parsed.Unix() {
		t.Errorf("unix %d does not match utc %q (%d)", out.Unix, out.UTC, parsed.Unix())
	}
	if out.Local != "" || out.Timezone != "" {
		t.Errorf("expected no local/timezone without a request, got local=%q timezone=%q", out.Local, out.Timezone)
	}
}

func TestGetCurrentTime_WithTimezone(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "get_current_time", map[string]any{"timezone": "America/New_York"})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	var out GetCurrentTimeOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse output: %v", err)
	}

	if out.Timezone != "America/New_York" {
		t.Errorf("expected timezone echoed as America/New_York, got %q", out.Timezone)
	}
	local, err := time.Parse(time.RFC3339, out.Local)
	if err != nil {
		t.Fatalf("local %q is not RFC3339: %v", out.Local, err)
	}
	// The instant must match utc; only the wall-clock offset differs.
	utc, err := time.Parse(time.RFC3339, out.UTC)
	if err != nil {
		t.Fatalf("utc %q is not RFC3339: %v", out.UTC, err)
	}
	if !local.Equal(utc) {
		t.Errorf("local %q and utc %q are not the same instant", out.Local, out.UTC)
	}
}

func TestGetCurrentTime_InvalidTimezone(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "get_current_time", map[string]any{"timezone": "Not/AZone"})
	if !result.IsError {
		t.Error("expected error for invalid timezone")
	}
	if text := extractTextContent(t, result); !strings.Contains(text, "invalid timezone") {
		t.Errorf("expected 'invalid timezone' error, got: %s", text)
	}
}

// Mcp-Session-Id is entirely client-controlled and lands in log lines and, for
// embedders, in an analytics property and the request inspector's payload. The
// spec restricts it to visible ASCII, so anything outside that is dropped
// rather than recorded.
func TestSessionID_RejectsValuesOutsideTheSpec(t *testing.T) {
	cases := []struct {
		name string
		id   string
		want bool
	}{
		{"typical id", "N7QHUFURVHGG3X4OAOOPEHPNVY", true},
		{"punctuation is visible ascii", "sess-1234_ab.cd", true},
		{"lowest and highest allowed", "!~", true},
		{"empty", "", false},
		{"space", "sess 1234", false},
		{"newline injects a log line", "sess\nlevel=ERROR fake", false},
		{"carriage return", "sess\r\n", false},
		{"tab", "sess\t1234", false},
		{"null byte", "sess\x00", false},
		{"del character", "sess\x7f", false},
		{"non-ascii", "sessión", false},
		{"at the cap", strings.Repeat("a", maxSessionIDLen), true},
		{"over the cap", strings.Repeat("a", maxSessionIDLen+1), false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := validSessionID(tc.id); got != tc.want {
				t.Errorf("validSessionID(%q) = %v, want %v", tc.id, got, tc.want)
			}
		})
	}
}

// --- Group: list_tools / call_tool ---

func TestListToolsTool_NamesTheProxyForEachTool(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ServerAPIKey:     "test-server-key",
		ServerAPIURL:     fpAPI.server.URL + "/v4",
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "list_tools", map[string]any{})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	var out ListToolsOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse output: %v", err)
	}

	listed := map[string]ListedTool{}
	for _, tool := range out.Tools {
		listed[tool.Name] = tool
	}

	wantRead := []string{"get_current_time", "get_event", "search_events", "list_environments", "list_api_keys", "get_api_key"}
	wantWrite := []string{"create_environment", "update_environment", "create_api_key", "update_api_key"}
	// Deletes are listed but never proxied, and the proxies list themselves so a
	// conversation whose catalog predates one can still discover it exists.
	wantDirect := []string{"delete_environment", "delete_api_key", "list_tools", "call_tool", "call_write_tool"}

	if len(out.Tools) != len(wantRead)+len(wantWrite)+len(wantDirect) {
		t.Errorf("expected %d tools listed, got %d: %v", len(wantRead)+len(wantWrite)+len(wantDirect), len(out.Tools), toolNamesFromListing(out))
	}
	for _, name := range wantDirect {
		tool, ok := listed[name]
		if !ok {
			t.Errorf("expected proxy %q to be listed", name)
			continue
		}
		if tool.RunWith != "direct" {
			t.Errorf("expected proxy %q to be run_with direct, got %q", name, tool.RunWith)
		}
	}
	for _, name := range wantRead {
		tool, ok := listed[name]
		if !ok {
			t.Errorf("expected %q to be listed", name)
			continue
		}
		if tool.Mutating || tool.RunWith != "call_tool" {
			t.Errorf("expected %q to be read-only and run with call_tool, got mutating=%v run_with=%q", name, tool.Mutating, tool.RunWith)
		}
	}
	for _, name := range wantWrite {
		tool, ok := listed[name]
		if !ok {
			t.Errorf("expected write tool %q to be listed", name)
			continue
		}
		if !tool.Mutating || tool.RunWith != "call_write_tool" {
			t.Errorf("expected %q to be mutating and run with call_write_tool, got mutating=%v run_with=%q", name, tool.Mutating, tool.RunWith)
		}
	}
	for _, tool := range out.Tools {
		if tool.InputSchema != nil {
			t.Errorf("expected no input schema without tool_name, got one for %q", tool.Name)
		}
	}
}

func TestListToolsTool_ReturnsInputSchemaForNamedTool(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "list_tools", map[string]any{"tool_name": "get_current_time"})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	var out ListToolsOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse output: %v", err)
	}
	if len(out.Tools) != 1 || out.Tools[0].Name != "get_current_time" {
		t.Fatalf("expected only get_current_time, got %v", out.Tools)
	}
	if out.Tools[0].InputSchema == nil {
		t.Fatal("expected an input schema when tool_name is given")
	}
	if _, ok := out.Tools[0].InputSchema["properties"]; !ok {
		t.Errorf("expected the input schema to carry properties, got %v", out.Tools[0].InputSchema)
	}
}

func TestCallTool_RunsDispatchedTool(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "call_tool", map[string]any{
		"tool_name": "get_current_time",
		"arguments": map[string]any{"timezone": "America/New_York"},
	})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	var out GetCurrentTimeOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse dispatched output: %v", err)
	}
	if out.Timezone != "America/New_York" || out.Local == "" {
		t.Errorf("expected the dispatched tool to honour its arguments, got %+v", out)
	}
}

func toolErrorCode(t *testing.T, result *mcp.CallToolResult) string {
	t.Helper()
	var body struct {
		Error struct {
			Code    string `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
	}
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &body); err != nil {
		t.Fatalf("expected a {code, message} error body, got %q", extractTextContent(t, result))
	}
	return body.Error.Code
}

func TestCallTool_RefusesWriteTools(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	// create_environment is registered and callable directly, but must not be
	// reachable through call_tool, which hides the real tool name from the
	// client and so escapes any per-tool approval prompt.
	result := mustCallTool(t, session, "call_tool", map[string]any{
		"tool_name": "create_environment",
		"arguments": map[string]any{"name": "should-not-happen"},
	})
	if !result.IsError {
		t.Fatal("expected call_tool to refuse a write tool")
	}
	if code := toolErrorCode(t, result); code != "tool_is_mutating" {
		t.Errorf("expected tool_is_mutating, got %q", code)
	}
}

func TestCallTool_RejectsUnknownTool(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "call_tool", map[string]any{"tool_name": "no_such_tool"})
	if !result.IsError {
		t.Fatal("expected call_tool to reject an unknown tool")
	}
	if code := toolErrorCode(t, result); code != "tool_not_found" {
		t.Errorf("expected tool_not_found, got %q", code)
	}
}

func TestListToolsTool_ReturnsInputSchemaForWriteTool(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	// Write tools leave InputSchema unset and let AddTool infer it, so the
	// listing has to derive it rather than read it back off the tool.
	result := mustCallTool(t, session, "list_tools", map[string]any{"tool_name": "create_environment"})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}

	var out ListToolsOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse output: %v", err)
	}
	if len(out.Tools) != 1 {
		t.Fatalf("expected one tool, got %v", out.Tools)
	}
	if !out.Tools[0].Mutating || out.Tools[0].RunWith != "call_write_tool" {
		t.Errorf("expected create_environment to be mutating and run with call_write_tool, got %+v", out.Tools[0])
	}
	if out.Tools[0].InputSchema == nil {
		t.Fatal("expected an input schema for a write tool")
	}
	if _, ok := out.Tools[0].InputSchema["properties"]; !ok {
		t.Errorf("expected the input schema to carry properties, got %v", out.Tools[0].InputSchema)
	}
}

func TestCallWriteTool_RunsWriteTool(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "call_write_tool", map[string]any{
		"tool_name": "create_environment",
		"arguments": map[string]any{"name": "dispatched-env"},
	})
	if result.IsError {
		t.Fatalf("expected the write proxy to dispatch, got error: %v", extractTextContent(t, result))
	}
}

func TestCallWriteTool_RefusesReadOnlyTools(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "call_write_tool", map[string]any{"tool_name": "get_current_time"})
	if !result.IsError {
		t.Fatal("expected call_write_tool to refuse a read-only tool")
	}
	if code := toolErrorCode(t, result); code != "tool_is_read_only" {
		t.Errorf("expected tool_is_read_only, got %q", code)
	}
}

func TestCallWriteTool_NotRegisteredWithoutWriteTools(t *testing.T) {
	fpAPI := newMockFingerprintAPI()
	defer fpAPI.close()

	// Read-only mode registers no mutating tools, so the write proxy has
	// nothing to run and must not be offered.
	ts := setupTestServer(t, &config.Config{
		AuthToken:    defaultAuthToken,
		ServerAPIKey: "test-server-key",
		ServerAPIURL: fpAPI.server.URL + "/v4",
		Region:       "us",
		ReadOnly:     true,
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}
	if names := toolNames(result); slices.Contains(names, "call_write_tool") {
		t.Errorf("expected no call_write_tool when nothing mutating is registered, got %v", names)
	}
}

func toolNamesFromListing(out ListToolsOutput) []string {
	names := make([]string, 0, len(out.Tools))
	for _, tool := range out.Tools {
		names = append(names, tool.Name)
	}
	return names
}

func TestCallTool_RefusesProxies(t *testing.T) {
	ts := setupTestServer(t, &config.Config{AuthToken: defaultAuthToken})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "call_tool", map[string]any{"tool_name": "list_tools"})
	if !result.IsError {
		t.Fatal("expected call_tool to refuse proxying another proxy")
	}
	if code := toolErrorCode(t, result); code != "tool_must_be_called_directly" {
		t.Errorf("expected tool_must_be_called_directly, got %q", code)
	}
}

func TestListToolsTool_FallsBackToDirectWhenProxyNotServed(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	// A deploy can serve a mutating tool without serving call_write_tool, and
	// naming a proxy that is not registered would send the model nowhere.
	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
		Tools:            []string{"create_api_key", "list_tools", "call_tool"},
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	if names := toolNames(mustListTools(t, session)); slices.Contains(names, "call_write_tool") {
		t.Fatalf("expected call_write_tool not to be served, got %v", names)
	}

	result := mustCallTool(t, session, "list_tools", map[string]any{"tool_name": "create_api_key"})
	if result.IsError {
		t.Fatalf("expected success, got error: %v", extractTextContent(t, result))
	}
	var out ListToolsOutput
	if err := json.Unmarshal([]byte(extractTextContent(t, result)), &out); err != nil {
		t.Fatalf("failed to parse output: %v", err)
	}
	if len(out.Tools) != 1 {
		t.Fatalf("expected one tool, got %v", out.Tools)
	}
	if out.Tools[0].RunWith != "direct" {
		t.Errorf("expected run_with direct when call_write_tool is not served, got %q", out.Tools[0].RunWith)
	}
}

func TestCallWriteTool_RefusesDeleteTools(t *testing.T) {
	mgmtAPI := newMockManagementAPI()
	defer mgmtAPI.close()

	ts := setupTestServer(t, &config.Config{
		AuthToken:        defaultAuthToken,
		ManagementAPIKey: "test-mgmt-key",
		ManagementAPIURL: mgmtAPI.server.URL,
		Region:           "us",
	})
	session := mustConnectMCPClient(t, ts.URL, defaultAuthToken)

	result := mustCallTool(t, session, "call_write_tool", map[string]any{
		"tool_name": "delete_api_key",
		"arguments": map[string]any{"id": "should-not-happen"},
	})
	if !result.IsError {
		t.Fatal("expected call_write_tool to refuse a delete tool")
	}
	if code := toolErrorCode(t, result); code != "tool_must_be_called_directly" {
		t.Errorf("expected tool_must_be_called_directly, got %q", code)
	}
}

func mustListTools(t *testing.T, session *mcp.ClientSession) *mcp.ListToolsResult {
	t.Helper()
	result, err := session.ListTools(context.Background(), nil)
	if err != nil {
		t.Fatalf("ListTools failed: %v", err)
	}
	return result
}
