# Product Requirement Documents (PRDs)

One PRD per future feature with scope >1 day. Written BEFORE implementing.

## Structure

Problem → Users → Goals → Non-goals → Requirements (Must/Should/Won't) → Open questions.

## Index

| # | Title | Status |
|---|---|---|
| 0001 | [Private plugin (onboarding tutorials add-on)](0001-private-plugin.md) | Draft |
| 0002 | [Rico plugin (aggressive refactor add-on)](0002-rico-plugin.md) | Draft |
| 0003 | [More stacks (Astro, SvelteKit, Tauri, Remix)](0003-more-stacks.md) | Draft |
| 0004 | [Skipper Memory MVP](0004-skipper-memory-mvp.md) | Draft |
| 0005 | [Skipper Platform — Stage 1 (Shared Fresh Memory)](0005-skipper-platform-stage1.md) | Draft |
| 0006 | [SDD verification & evidence pipeline (la mitad trasera)](0006-sdd-verification-evidence-pipeline.md) | In progress (Phase A shipped) |
