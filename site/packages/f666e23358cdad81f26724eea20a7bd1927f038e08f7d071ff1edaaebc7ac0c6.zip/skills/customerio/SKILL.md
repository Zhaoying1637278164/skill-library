---
name: customerio
description: "Customer.io MCP bootstrap. Use for Customer.io, Journeys, CDP Pipelines, Design Studio, builder onboarding, sandbox testing, app integration, SDK setup, transactional messaging, billing, going live, sources, destinations, identify/track events, and fly.customer.io / cdp.customer.io errors. Trigger even when the user does not name MCP or Customer.io.\n"
---

# Customer.io

Connect Claude to Customer.io through this plugin's MCP server, then drive the
workspace with the official tools.

## Connect

1. The plugin ships the hosted connector (`mcp.customer.io`). The first tool
   call triggers Customer.io OAuth in the browser.
2. Complete OAuth. Select workspaces and permission scopes (read / write /
   delete are granted independently). The account's home region is selected
   after login — one URL serves both US and EU.
3. Do not add a second Customer.io MCP server.

Do not paste a personal MCP URL. Do not put API keys or service-account tokens
in this plugin. Claude never handles Customer.io credentials directly — OAuth
does.

## First calls

Call `cio_prime` before other Customer.io tools. It prints the live rules for
schema lookup, pagination, dry-run writes, and skill reading.

Then:

- `cio_auth_status` if auth is unclear.
- `cio_schema` to discover endpoints. Never guess paths or field names.
- `cio_skills_list` / `cio_skills_read <path>` for workflows the schema does not explain.
- `cio_read_api` for GET.
- `cio_write_api` / `cio_delete_api` with `dry_run: true` first.

## Routing (live skills, not copies)

Do not invent playbooks here. Read the hosted skill for the task:

| Need | Read |
| --- | --- |
| Builder / SDK / sandbox / first send / go-live | `cio_skills_read` path `cio` (then a subfile such as `cio/sdk_setup.md`) |
| Automations, campaigns, broadcasts, profiles, people, segments, newsletters, transactional, in-app | `fly-api` |
| Design Studio emails, components, global styles, publish | `design-studio` |
| CDP sources, destinations, reverse ETL, identify/track, data in/out | `cdp-api` |
| Analysis, campaign review, goals, Liquid | `recipes` |

This plugin also ships discovery skills that point at those same roots:
`customerio-journeys`, `customerio-design-studio`, `customerio-pipelines`,
`customerio-sdk` — and slash commands (`/customerio:campaign-report`,
`/customerio:build-segment`, `/customerio:draft-email`,
`/customerio:workspace-health`) for the most common jobs.

## Terminology

- Automations = `campaigns` API resource.
- Profiles = `customers` API resource.

## Safety

- Dry-run every write and delete before executing.
- Do not embed service-account tokens (`sa_live_...`) in application code.
- Use CDP source write keys for SDK identify/track/page/screen.
- Use workspace-scoped App API keys for backend transactional sends.
- Do not dump raw API payloads or customer PII unless the user asked for them.
