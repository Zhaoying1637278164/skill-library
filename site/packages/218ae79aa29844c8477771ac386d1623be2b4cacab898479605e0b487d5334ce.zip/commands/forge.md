---
description: Evidence-first coding loop — classify risk, verify baseline, implement, run multi-tier verification cascade, and spawn adversarial reviewers before presenting code
argument-hint: <task-description>
allowed-tools:
- Read
- Edit
- Write
- Bash
- Glob
- Grep
- Agent
- TaskCreate
- TaskUpdate
- TaskList
---

# /forge

Run the full Forge Loop for a task. Follow all phases in order. Do not skip phases.

---

## Phase 1 — Size

Classify the task as **Small**, **Medium**, or **Large** based on the description and files likely touched.

| Size | Criteria |
|------|----------|
| Small | Typo, rename, config tweak, one-liner |
| Medium | Bug fix, feature addition, targeted refactor |
| Large | New feature, multi-file architecture, auth/crypto/payments, OR any 🔴 file |

Any 🔴 file found in Phase 2 **automatically escalates** the task to Large.

---

## Phase 2 — Classify

Rate every file the task will touch before writing any code.

| Rating | When to use |
|--------|-------------|
| 🔴 | Filename or content contains: `auth`, `jwt`, `token`, `crypto`, `hash`, `password`, `payment`, `charge`, `invoice`, `migration`, `schema`, `delete`, `drop`, public API, `webhook`, `signature`, `secret` |
| 🟡 | Existing business logic files, service files, repository files, controller files, state management, SQL queries |
| 🟢 | Test files, documentation, config files, new files being created from scratch, CSS/style files |

Output the classification before doing anything else:

```
📁 Risk classification:
  🔴 src/webhooks/payments.ts — payment processing
  🟡 src/services/order.service.ts — business logic
  🟢 src/webhooks/payments.test.ts — test file

Task size escalated to Large (🔴 file present).
Adversarial review: 3 reviewers.
```

---

## Phase 3 — Baseline Capture

Run the full verification cascade (see Phase 5) **before touching any code**. Record results in a baseline table.

If the baseline is already broken: note the pre-existing failures and proceed. Forge is not responsible for them, but must not make them worse.

---

## Phase 4 — Implement

Edit files following existing codebase patterns.

**If `git diff` already shows unstaged edits**: skip directly to Phase 5 — the user has already made changes.

---

## Phase 5 — Verify Cascade

Run all applicable tiers after implementation:

### Tier 1 — Always run
- IDE diagnostics on changed files and their importers via `ide-get_diagnostics` if available; otherwise language server / compiler stderr
- Syntax and parse check

### Tier 2 — If tooling exists
Run in order: **build/compile → type checker → linter → tests**

### Tier 3 — If Tiers 1–2 yield no runtime signal
Write a 3–5 line throwaway smoke script, run it, delete it.

If Tier 3 is infeasible (e.g., iOS lib, infra requiring credentials): **document why explicitly**. Silent skipping is not acceptable.

---

## Phase 6 — Adversarial Review

Spawn `forge-reviewer` sub-agents in parallel:

| Task size | Reviewers |
|-----------|-----------|
| Medium | 1 reviewer |
| Large or any 🔴 file | 3 reviewers in parallel |

If real issues are found: fix them → re-run Tier 2 + review. Maximum **2 adversarial rounds**.

After 2 rounds, any remaining findings are listed as known issues with Confidence: Low.

---

## Phase 7 — Evidence Bundle

Output a structured markdown report:

```
## 🔨 Forge Evidence Bundle

**Task**: <task-id> | **Size**: S/M/L | **Risk**: 🟢/🟡/🔴

### Baseline (before changes)
| Check        | Result        | Command              |
|--------------|---------------|----------------------|
| diagnostics  | ✅ 0 errors   | ide-get_diagnostics  |
| build        | ✅ exit 0     | npm run build        |
| types        | ✅ exit 0     | npm run type-check   |
| tests        | ✅ N passed   | npm test             |

### After Changes
| Check        | Result        | Command              |
|--------------|---------------|----------------------|
| diagnostics  | ✅ 0 errors   | ide-get_diagnostics  |
| build        | ✅ exit 0     | npm run build        |
| types        | ✅ exit 0     | npm run type-check   |
| tests        | ✅ N passed   | npm test             |

### Regressions
None detected.  ← or list them

### Adversarial Review
| Reviewer | Findings                                               |
|----------|--------------------------------------------------------|
| sonnet   | <finding> (<confidence>) — **fixed** / listed          |
| haiku    | No issues                                              |
| opus     | No issues                                              |

**Issues fixed before presenting**: <list or "none">
**Files changed**: <list>
**Confidence**: High / Medium / Low — <one-line reason>
**Rollback**: `git revert HEAD` or `git checkout <pre-sha> -- <file>`
```

**Confidence rules:**
- **High** — all tiers passed, no regressions, reviewers found zero issues or only issues you fixed
- **Medium** — most checks passed but: a reviewer concern addressed without certainty, missing test coverage for changed path, or blast radius not fully verifiable
- **Low** — a check failed you could not fix, or a reviewer raised something you cannot disprove. Must state what would raise confidence.

---

## Phase 8 — Commit

Auto-commit with a structured message. Capture the pre-commit SHA for rollback reference.

---

## Phase 9 — Session File

Save a session record to `implementations/<task-id>.md` in the repo root, containing the Evidence Bundle and any notes.

---

## Failure Handling

| Failure | Action |
|---------|--------|
| Verify fails after 2 fix attempts | `git checkout HEAD -- {files}` to revert; report exactly what broke |
| Reviewer finds issues after 2 review rounds | List as known findings; Confidence: Low; state what would raise it |
| Baseline already broken | Note pre-existing failures; proceed; ensure no new failures added |
| No runtime signal (Tiers 1–2 static only) | Write 3–5 line smoke script; run it; delete it |
| Tier 3 infeasible | Document why explicitly; silent skip is not acceptable |
