---
description: Run the Forge verification cascade on currently changed files and output an Evidence Bundle
allowed-tools:
- Read
- Bash
- Glob
- Grep
- TaskCreate
- TaskUpdate
---

# /forge-verify

Run the Forge verification cascade on currently changed files. No implementation phase — useful for verifying changes made manually or by another tool.

---

## Step 1 — Detect Changed Files

```bash
git diff --name-only          # unstaged changes
git diff --cached --name-only # staged changes
```

Combine both lists. If there are no changed files, report "No changed files detected" and stop.

---

## Step 2 — Classify Risk

Rate each changed file:

| Rating | When to use |
|--------|-------------|
| 🔴 | Filename or content contains: `auth`, `jwt`, `token`, `crypto`, `hash`, `password`, `payment`, `charge`, `invoice`, `migration`, `schema`, `delete`, `drop`, public API, `webhook`, `signature`, `secret` |
| 🟡 | Existing business logic files, service files, repository files, controller files, state management, SQL queries |
| 🟢 | Test files, documentation, config files, new files, CSS/style files |

Output the classification:

```
📁 Risk classification:
  🔴 src/webhooks/payments.ts — payment processing
  🟡 src/services/order.service.ts — business logic
  🟢 src/webhooks/payments.test.ts — test file
```

---

## Step 3 — Verification Cascade

### Tier 1 — Always run
- IDE diagnostics on changed files and their importers via `ide-get_diagnostics` if available; otherwise language server / compiler stderr
- Syntax and parse check

### Tier 2 — If tooling exists
Run in order: **build/compile → type checker → linter → tests**

### Tier 3 — If Tiers 1–2 yield no runtime signal
Write a 3–5 line throwaway smoke script, run it, delete it.

If Tier 3 is infeasible: **document why explicitly**. Silent skipping is not acceptable.

---

## Step 4 — Evidence Bundle

Output the structured report:

```
## 🔨 Forge Evidence Bundle

**Source**: forge-verify | **Risk**: 🟢/🟡/🔴

### Verification Results
| Check        | Result        | Command              |
|--------------|---------------|----------------------|
| diagnostics  | ✅ 0 errors   | ide-get_diagnostics  |
| build        | ✅ exit 0     | npm run build        |
| types        | ✅ exit 0     | npm run type-check   |
| tests        | ✅ N passed   | npm test             |

**Files verified**: <list>
**Confidence**: High / Medium / Low — <one-line reason>
```

**Confidence rules:**
- **High** — all tiers passed, no failures
- **Medium** — most checks passed; one tier skipped or incomplete
- **Low** — one or more checks failed. Must state what failed and what would fix it.

Do not claim a check passed without a real tool call result in this response. Show the command, the exit code, and a snippet of output — or do not make the claim.
