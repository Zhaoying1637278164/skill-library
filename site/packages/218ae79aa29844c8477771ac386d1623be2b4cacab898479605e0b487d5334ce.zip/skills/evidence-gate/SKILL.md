---
name: forge-evidence-gate
description: Use when about to assert that a build passed, tests passed, types are clean, or linting succeeded — before writing that claim. Requires real tool call evidence; blocks prose assertions.
---

# forge:evidence-gate

## Core Rule

**If you have not run the command in this response, you cannot say it passed.**

"Build passed ✅" with no Bash call is a hallucination. Show the command, show the exit code, show the output snippet — or do not make the claim.

## What Counts as Evidence

A claim is valid only when the same response contains a tool call that produced the result. Evidence requirements:

| Claim | Required evidence |
|-------|-------------------|
| "Build passed" | Bash call showing `exit 0` + build output |
| "Tests passed" | Bash call with test runner output + pass count |
| "Types are clean" | Bash call with type checker output showing 0 errors |
| "Linting passed" | Bash call with linter output showing 0 violations |
| "Diagnostics clean" | `ide-get_diagnostics` call showing 0 errors |

## What Is NOT Evidence

- Remembering a previous run from earlier in the conversation
- Assuming the baseline still holds after code changes
- "I didn't change anything that would affect the build"
- Inferring success from partial output

## Correct Pattern

```
Running build to confirm...
[Bash: npm run build]
→ exit 0, output: "Build complete in 3.2s"

Build passed ✅
```

## Blocked Pattern

```
The build should still pass since I only changed the validation logic.

Build passed ✅  ← BLOCKED — no tool call, no evidence
```

If you cannot run the verification command right now, write: "I have not verified this — run `<command>` to confirm."
