---
name: forge-risk-classify
description: Use when about to edit, create, or delete files as part of an implementation task — before writing any code. Rates each file's risk level and adjusts the task size accordingly.
---

# forge:risk-classify

Rate every file the task will touch before writing any code. Output the classification, then proceed.

## Classification Rules

| Rating | Criteria |
|--------|----------|
| 🔴 | Filename or content contains: `auth`, `jwt`, `token`, `crypto`, `hash`, `password`, `payment`, `charge`, `invoice`, `migration`, `schema`, `delete`, `drop`, public API, `webhook`, `signature`, `secret` |
| 🟡 | Existing business logic files, service files, repository files, controller files, state management, SQL queries |
| 🟢 | Test files, documentation, config files, new files being created from scratch, CSS/style files |

Any 🔴 file **escalates the task to Large** and triggers **3 adversarial reviewers**.

## Output Format

```
📁 Risk classification:
  🔴 src/webhooks/payments.ts — payment processing
  🟡 src/services/order.service.ts — business logic
  🟢 src/webhooks/payments.test.ts — test file

Task size escalated to Large (🔴 file present).
Adversarial review: 3 reviewers.
```

Output this block before touching any files.
