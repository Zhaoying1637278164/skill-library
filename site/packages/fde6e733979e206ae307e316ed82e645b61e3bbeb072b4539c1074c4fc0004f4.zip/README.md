# Socialinsider for Claude Code

Social media analytics inside Claude Code. Connects Claude to your
[Socialinsider](https://www.socialinsider.io) account so it can pull post metrics, engagement
rates, audience growth and competitive benchmarks across Instagram, Facebook, TikTok, YouTube,
LinkedIn and X — then reason over them.

## Install

```bash
/plugin marketplace add socialinsiderio/socialinsider-claude-plugin
/plugin install socialinsider@socialinsider
```

On first use, Claude opens a browser window to sign in to Socialinsider. There is no API key to
paste and nothing to configure — authentication is OAuth 2.1 with PKCE, handled by the remote
server at `https://mcp.socialinsider.io/mcp`.

An active Socialinsider subscription with analytics access is required. See
[socialinsider.io](https://www.socialinsider.io) or contact your Account Manager.

## Skills

| Skill | What it does |
| :--- | :--- |
| `/socialinsider:profile-audit` | Performance audit for one profile — trend, aggregates, format mix, top posts, recommendations |
| `/socialinsider:competitor-benchmark` | Side-by-side benchmark of a brand against its competitors, normalised by follower count |
| `/socialinsider:campaign-recap` | Campaign or content-pillar wrap-up, measured against the profile's own baseline |

Each skill is model-invoked as well, so plain requests like "how did our Instagram do last month"
or "how do we compare to our competitors on TikTok" trigger the right one automatically.

## Tools

The plugin bundles the Socialinsider MCP server, which exposes 19 tools.

**Discovery and context**

- `socialinsider_get_date_context` — current date plus pre-calculated date ranges as millisecond
  timestamps. Always called first by the skills; the source of truth for "last month".
- `socialinsider_list_profiles`, `socialinsider_list_brands`, `socialinsider_list_campaigns`
- `socialinsider_resolve_campaign` — fuzzy-match a campaign name against the real tags
- `socialinsider_profile_search` — look up a profile by URL or handle before tracking it

**Analytics (read-only)**

- `socialinsider_get_profile_data` — daily followers, engagement rate, reach, impressions
- `socialinsider_get_posts_summary` — aggregate totals, averages and post-type breakdown
- `socialinsider_get_top_posts` — top-N posts ranked server-side by a chosen metric
- `socialinsider_count_posts` — post counts across a whole project in one call
- `socialinsider_get_posts` — individual posts with per-post metrics, paginated
- `socialinsider_get_instagram_stories` — Stories for owned, authorised business accounts

**Account management (write)**

`socialinsider_create_project`, `socialinsider_create_project_with_brands`,
`socialinsider_create_brand`, `socialinsider_remove_brand`, `socialinsider_add_profile`,
`socialinsider_add_profile_to_brand`, `socialinsider_remove_profile`.

These modify your Socialinsider account and can consume your subscription's profile limit. Claude
states exactly what will change and waits for your confirmation before calling any of them.

## Data and privacy

The plugin talks only to `https://mcp.socialinsider.io`. Requests are scoped to the account you
authenticate as, and analytics tools are read-only. Full policy:
[socialinsider.io/privacy-policy](https://www.socialinsider.io/privacy-policy).

## Development

```bash
git clone git@github.com:socialinsiderio/socialinsider-claude-plugin.git
claude --plugin-dir ./socialinsider-claude-plugin
claude plugin validate ./socialinsider-claude-plugin --strict
```

The MCP server itself lives in
[socialinsiderio/socialinsider-mcp-server](https://github.com/socialinsiderio/socialinsider-mcp-server).

## Support

Issues with the plugin: open a GitHub issue. API access and billing: your Socialinsider Account
Manager or [socialinsider.io/contact](https://www.socialinsider.io/contact). API reference:
[api-docs.socialinsider.io](https://api-docs.socialinsider.io).

## License

MIT — see [LICENSE](./LICENSE).
