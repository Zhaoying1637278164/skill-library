---
description: Turn the latest AEO audit into a prioritized, ordered fix list with the reason each item matters.
argument-hint: "[website name or domain]"
---

Build a prioritized AEO fix list for the AI-Advisors workspace.

Target: $ARGUMENTS (if empty, use the only tracked website, or ask which one when
there is more than one).

Steps:

1. `list_websites` to resolve the target to a website id.
2. `get_aeo_audit` for the latest score, sub-scores and open recommendations.
3. `get_advisor_recommendations` to cross-check against the workspace's own
   prioritization.
4. `get_visibility_summary` so findings can be tied to answers actually being
   lost, rather than presented as abstract hygiene.

Then produce an ordered list grouped by the layered order in the `aeo-audits`
skill: crawler access first, then server-side rendering, then entity and
structured data, then content shape. Within each group, order by weighted score
impact.

For each item give: what is wrong, where, why it blocks AI citation, and what a
fix looks like concretely. Mark any item that cannot be tied to a specific
losing prompt or blocked crawler as hygiene rather than implying a return.

If the user asks you to implement fixes in a codebase you have access to, do
that as ordinary work in that repository. This plugin's tools are read-only and
cannot change a site.
