---
description: Summarize what changed in AI search for a tracked website this week and what to focus on next.
argument-hint: "[website name or domain]"
---

Give the weekly AI search read for the AI-Advisors workspace.

Target: $ARGUMENTS (if empty, use the only tracked website, or ask which one when
there is more than one).

Steps:

1. `list_websites` to resolve the target to a website id.
2. `get_weekly_read` for the workspace's own cross-source weekly narrative.
3. `get_advisor_recommendations` for the current prioritized actions.
4. `get_ai_traffic` and `get_search_performance` for the traffic side of the
   week, if the question touches volume rather than only visibility.

Report what changed, what it most plausibly follows from, and the two or three
things worth doing next. Keep causal language proportionate to the evidence: a
week-over-week move on a small sample is a candidate explanation, not a cause.
Note explicitly when a week has no meaningful change, rather than manufacturing
a narrative.
