---
description: Pull a current AI search visibility report for a tracked website and summarize what is winning, what is losing, and why.
argument-hint: "[website name or domain] [days]"
---

Produce an AI search visibility report from the AI-Advisors workspace.

Target: $ARGUMENTS (if empty, use the only tracked website, or ask which one when
there is more than one).

Steps:

1. `list_websites` to resolve the target to a website id.
2. `get_visibility_summary` for that id, using the requested window if one was
   given (default 30 days).
3. For the two or three weakest prompts that still have a meaningful number of
   executions, call `get_prompt_answers` to see which engines missed the brand
   and which domains were cited instead.
4. `get_citations_summary` to see which sources dominate the topic overall.

Then report:

- Prompts won, prompts lost, and prompts where the brand is mentioned but never
  cited, kept as three separate counts.
- Notable movement since the previous period, ignoring any prompt whose
  execution count is too low to support a claim.
- Who is being cited in the answers the brand loses.
- Two or three specific, evidenced next actions.

Follow the `ai-search-visibility` skill for interpretation rules. State windows
and sample sizes explicitly, and do not report a delta for a prompt with no
prior period.
