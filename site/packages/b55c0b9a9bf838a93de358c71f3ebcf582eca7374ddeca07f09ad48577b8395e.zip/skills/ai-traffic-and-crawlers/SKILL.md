---
name: ai-traffic-and-crawlers
description: Interpret AI-Advisors traffic data - visits referred from AI assistants, AI crawler activity, paid versus organic AI traffic, and how AI numbers reconcile against Google Search Console, Bing and GA4. Use when asked how much traffic AI is sending, whether AI crawlers are visiting a site, why AI numbers disagree with analytics, or whether AI traffic converts.
---

# AI traffic and crawlers

Two different populations arrive from AI platforms and they are counted
separately, because they are not the same thing and mixing them produces
nonsense:

- **AI referral visits** are humans who clicked through from an AI assistant.
- **Bot or crawler visits** are the engines themselves fetching pages.

`get_ai_traffic` returns both, plus the paid and organic split and conversions.
`get_search_performance` returns classic search alongside it (Google Search
Console and Bing), which is the right denominator for "is AI replacing search".

## The structural fact about crawler data

A browser JavaScript tracking snippet **cannot see AI crawlers**, because AI
crawlers do not execute JavaScript. This is deductive, not a tuning problem. A
site tracked only by a client-side snippet will show a near-empty crawler table
no matter how heavily it is actually being crawled.

So before drawing any conclusion from a low crawl count, establish where the
data came from. Server-side collection - middleware, a Cloudflare Worker, or a
CMS plugin - is what can see crawlers. If the workspace has only the snippet
installed, the correct statement is "we cannot see crawler activity from this
site yet", never "AI crawlers are not visiting".

Crawler identity is also checked against operators' published IP ranges, and the
result is deliberately three-valued: verified, unverified, or not checkable. A
non-match never means spoofed. Published IP lists go stale and some operators
publish nothing at all, so **unverified means not proven, not proven false**.
Report it that way.

## Paid versus organic AI traffic

Clicks from ChatGPT ads carry an `oppref` marker, so paid AI visits can be
separated from organic ones. Two cautions:

- Paid clicks often arrive with the referrer stripped. The marker alone is
  sufficient to classify them, which is why paid counts can exist where referrer
  data does not.
- Click counts reported by an ad platform and visits recorded on the site will
  never match exactly. Some share of clicks never reaches the page. Present the
  gap as a capture rate, not as missing data or a tracking fault.

## Reconciling with other analytics

AI-Advisors is an overlay on conventional analytics, not a replacement for it,
and the two systems count different things:

- **AI share of traffic** divides AI referral visits by GA4 sessions. Those come
  from separate systems with separate filters, so the ratio can be unusable. A
  value above 100% is impossible by definition, since AI referrals are a subset
  of sessions, and the product deliberately shows a dash rather than a wrong
  number. Treat a dash as "these two sources disagree", commonly a lagging sync
  or GA4 filtering traffic the snippet still sees.
- **Search Console and Bing report on different cadences.** Google is daily;
  Bing query and page data is weekly and Saturday-dated, and Bing reports no
  average position for clicks at all. Never put a Bing weekly figure and a
  Google daily figure in the same trend line.

## Answering "is AI sending us traffic"

Give the absolute number first, then the share, then the trend, and name the
window. Volumes are usually small in absolute terms today, and a large
percentage change on a small base is the most common way this data gets
misreported. If conversions are available, lead with those instead: a small
number of AI-referred visits that convert is a stronger finding than a large
number that does not.

## Related

- Why engines cite or ignore the site: the `aeo-audits` skill.
- Which answers the brand appears in: the `ai-search-visibility` skill.
