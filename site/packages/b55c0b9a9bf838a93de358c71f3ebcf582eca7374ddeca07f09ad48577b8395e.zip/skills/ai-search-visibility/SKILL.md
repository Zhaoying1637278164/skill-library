---
name: ai-search-visibility
description: Read and interpret AI search visibility data from AI-Advisors - which tracked prompts mention or cite the brand across ChatGPT, Claude, Gemini and Perplexity, who wins the answers you lose, and what the numbers do and do not prove. Use when asked about AI visibility, brand mentions in AI answers, citation share, share of voice, or competitor presence in AI search.
---

# AI search visibility

AI-Advisors runs a fixed set of **tracked prompts** against several AI answer
engines on a schedule, then analyzes each answer for brand mentions, sentiment,
and citations. This skill covers how to read that data without overstating it.

## The mental model

This is not keyword rank tracking. There is no single "position" for a brand in
an AI answer. Each run of a prompt is a sample of a non-deterministic system, so
every number here is a rate over samples, not a measurement of a fixed state.

Three different things are measured, and they fail independently:

| Signal | Question it answers | What a zero means |
|---|---|---|
| **Mention** | Did the answer name the brand at all? | The engine does not associate you with this question. |
| **Citation** | Did the answer link to the brand's own domain? | You may be named but you are not the source. |
| **Competitor citation** | Whose pages did the answer link to instead? | Someone else owns the answer. |

A prompt with mentions but no citations is an **authority and source problem**.
A prompt with neither is a **relevance problem**. They need different fixes, so
never collapse them into one "visibility is low" statement.

## Workflow

1. `list_websites` to get the website id. Most workspaces track one site, but
   never assume - the id is required by nearly every other tool.
2. `get_visibility_summary` for the per-prompt table: `visibility_pct`,
   `prev_visibility_pct`, `executions`, `your_citations`,
   `competitor_citations`. Default window is 30 days, max 90.
3. `get_prompt_answers` with a `prompt_id` for the raw evidence behind one row:
   per platform, mention, sentiment, cited domains, the sub-queries the engine
   ran (query fan-out), and an excerpt of the answer.
4. `get_citations_summary` when the question is about sources rather than
   prompts: which domains the engines keep citing for this topic.

Always drill into step 3 before making a claim about *why* a prompt is losing.
The fan-out sub-queries in particular show what the engine actually searched
for, which is often not the phrasing of the tracked prompt.

## Reading the numbers honestly

- **Check `executions` before believing a delta.** These are small samples. A
  prompt with 4 executions moving from 25% to 50% is one answer changing its
  mind, not a trend. Say so rather than reporting the percentage move.
- **Period-over-period needs a prior period.** `prev_visibility_pct` is null for
  newly tracked prompts. Report the current value and say there is no baseline
  yet; do not render a delta of zero.
- **Visibility is per prompt, so the average across prompts is nearly
  meaningless** unless the prompt set is deliberately balanced. Prefer "you win
  6 of 20 tracked prompts" over "30% visibility".
- **Engines disagree, and that is signal.** Being cited on one engine and absent
  on another usually points at a retrieval or index difference, not at content
  quality. Look at which engines before recommending a content rewrite.
- **Sentiment on zero mentions is not neutral sentiment, it is no data.**

## Turning it into advice

Rank the losses by how winnable they are, not by how much they hurt:

1. Prompts where the brand is mentioned but never cited, and a competitor's page
   is cited instead. The engine already knows you belong in the answer, so this
   is the shortest path to a citation.
2. Prompts where the cited pages are weak (forums, listicles, outdated posts).
3. Prompts where established, authoritative sources own the answer. These are
   real but slow, and should be named as such.

`get_advisor_recommendations` returns the workspace's own prioritized list
across modules and is a good cross-check against your reading of the data.

## Related

- Site-side causes of missing citations: the `aeo-audits` skill.
- Whether AI answers actually send traffic: the `ai-traffic-and-crawlers` skill.
