---
name: aeo-audits
description: Interpret and act on AI-Advisors AEO (Answer Engine Optimization) audit findings - crawler access, server-side rendering, structured data and entity graphs, content freshness and direct answers. Use when asked why a site is not cited by AI engines, how to make a site retrievable by AI crawlers, what an AEO score means, or which audit findings to fix first.
---

# AEO audits

AEO is the site side of AI search: whether an answer engine can **reach** your
pages, **parse** them, and **trust** them enough to cite. Visibility data tells
you which answers you lose; the audit tells you which of those losses are your
own site's fault.

## Getting the data

- `get_aeo_audit` returns the latest audit for a website: overall score, the
  technical / content / authority sub-scores, and the open recommendations.
- `get_advisor_recommendations` folds AEO findings in with the other modules,
  which is the better call when the user asks "what should we do next" rather
  than "what is wrong with the site".

Scores are weighted, so a one-point drop in a high-impact check outranks several
low-impact ones. Read the recommendation list, not just the number.

## The four failure modes, in the order they matter

### 1. The crawler never arrived

Crawler access is binary and it gates everything else. Fixing content on a page
no engine can fetch changes nothing.

AI crawlers fall into tiers that call for different decisions:

| Tier | Examples | Correct posture |
|---|---|---|
| Training crawlers | `GPTBot`, `ClaudeBot`, `CCBot` | Fine to block. Blocking costs you no citations. |
| Index crawlers | `OAI-SearchBot`, `Claude-SearchBot`, `PerplexityBot`, `GoogleOther` | **Must be allowed.** These build the index answers are drawn from. |
| User-initiated fetches | `ChatGPT-User`, `Claude-User`, `Perplexity-User` | **Must be allowed**, and at the firewall layer too, not just robots.txt. |

The common and expensive mistake is blocking a whole `*bot*` pattern, or letting
a WAF or bot-management rule silently challenge tier 2 and 3 agents. A firewall
block does not appear in robots.txt, so a site can look perfectly configured and
still be invisible. When the audit reports a bot-access finding, check the
firewall as well as the file.

### 2. The content was not in the HTML

Most AI crawlers do not execute JavaScript. A page that renders its content
client side is, to them, an empty shell with a nav bar. This is the single most
common cause of "we rank in Google but never get cited".

Verify by fetching the page the way a crawler would - request the raw HTML and
check that the H1, the brand name, the primary content and any JSON-LD are all
present in the response body, not injected later. If they are missing, the fix
is server-side rendering or prerendering for those routes, and no amount of
content work substitutes for it.

### 3. The entity was not resolvable

Answer engines work on entities, not strings. Structured data helps when it
connects your entity to ones the engine already knows:

- `Organization` or `Person` schema with a `sameAs` array pointing at
  authoritative profiles. An encyclopedic anchor such as Wikidata or Wikipedia
  carries far more weight than a set of social links.
- `@id` connectivity, so `Article` references `Person` references `Organization`
  instead of three disconnected islands.
- `FAQPage` and `Article` markup where the page genuinely is one.

Schema that describes an entity nothing else references is decoration. The value
is in the connection.

### 4. The page did not answer the question

Retrieval gets you considered; the shape of the content gets you quoted.

- Lead with a direct answer in the first paragraph under a question-shaped
  heading. Engines lift self-contained passages.
- Keep a visible, accurate last-updated date. Freshness is bucketed, and content
  older than roughly six months is discounted for anything time-sensitive.
- Attribute data and claims. Cited sources are more quotable than assertions.

## Prioritizing

Work strictly in the order above. Crawler access, then rendering, then entity,
then content. Each layer is a precondition for the next, so fixing content while
tier 2 crawlers are blocked produces no measurable change and wastes the
strongest evidence you have that the work was worth doing.

When presenting a plan, group by that order and say what each fix is expected to
move. If a recommendation cannot be tied to a specific losing prompt or a
specific blocked crawler, say that it is hygiene rather than implying a return.

## Related

- Which answers you are actually losing: the `ai-search-visibility` skill.
- Whether crawlers are reaching the site in practice: the
  `ai-traffic-and-crawlers` skill.
