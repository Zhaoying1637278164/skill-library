---
name: ai-advisors-setup
description: Set up and verify the AI-Advisors connection - create the API token, configure it, and confirm the tools respond. Use when the plugin is first installed, when a tool returns an authentication or rate-limit error, or when the user asks how to connect AI-Advisors.
---

# Setting up AI-Advisors

The plugin talks to a remote MCP server at `https://app.ai-advisors.ai/api/mcp`.
It needs one credential: a read-only personal access token from the user's own
AI-Advisors workspace.

## Getting a token

Walk the user through this. You cannot create the token for them, and you should
never ask them to paste it into the conversation.

1. Sign in at https://app.ai-advisors.ai
2. Go to **Settings > MCP Access**
3. Create a token, giving it a recognizable name such as "Claude Code"
4. Copy it. It starts with `aia_` and is shown **once**; it is stored only as a
   hash, so a lost token has to be replaced rather than recovered.

Tokens are read-only, scoped to the workspace that created them, and revocable
from the same screen at any time. Creating one requires an admin or owner role,
and MCP access is available on every paid plan.

## Configuring it

The token is a plugin setting, not an environment variable. Claude Code prompts
for it on install; it is stored in secure storage and sent as an `Authorization`
header. If it was skipped or needs replacing, the user can set it through the
plugin's configuration in `/plugin`.

Do not write the token into a project file, a shell profile, or `.mcp.json` in a
repository. If a user offers to paste it into the chat, tell them to put it in
the plugin setting instead.

## Verifying

Call `list_websites`. A successful call returns the websites tracked in the
workspace, which confirms the token, the transport and the scoping all work in
one step.

## When something fails

| Symptom | Cause | Fix |
|---|---|---|
| `unauthorized` or a 401 | Token missing, mistyped, or revoked | Re-enter it in the plugin configuration, or create a new one |
| `rate_limited` | Per-token call ceiling reached | Wait for the window named in the message; batch questions rather than looping tool calls |
| `list_websites` returns nothing | Workspace has no website set up yet | Finish onboarding at https://app.ai-advisors.ai first |
| A data tool returns an empty result | That module has no data yet for this website | Report it as "not collected yet", not as a zero measurement |

An empty result is not an error, and the difference matters when reporting.
Several tools legitimately return nothing on a new workspace: prompts have to be
tracked before visibility exists, an audit has to be run before findings exist,
and crawler data needs server-side collection installed.
