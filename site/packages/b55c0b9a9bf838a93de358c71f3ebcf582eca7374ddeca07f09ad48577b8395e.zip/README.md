# AI-Advisors plugin for Claude

See how AI answer engines represent your brand, without leaving Claude.

This plugin connects Claude to your [AI-Advisors](https://www.ai-advisors.ai)
workspace and adds the domain knowledge needed to read the data properly. Ask
which AI answers you are losing, why a page is never cited, or whether AI search
is sending traffic, and get an answer grounded in your own measurements rather
than a guess.

## What is included

**A read-only MCP connector** to `https://app.ai-advisors.ai/api/mcp`, exposing
eleven tools: `list_websites`, `get_visibility_summary`, `list_tracked_prompts`,
`get_prompt_answers`, `get_citations_summary`, `get_aeo_audit`,
`get_ai_traffic`, `get_search_performance`, `get_brand_accuracy`,
`get_advisor_recommendations` and `get_weekly_read`. Every tool is read-only.
The plugin cannot create, change or delete anything in your workspace.

**Three skills** that teach Claude how to interpret the data:

- `ai-search-visibility` - mentions versus citations, sample sizes, who wins the
  answers you lose
- `aeo-audits` - crawler access tiers, server-side rendering, entity graphs, and
  the order to fix them in
- `ai-traffic-and-crawlers` - AI referral traffic, crawler visibility, and how
  the numbers reconcile against Search Console, Bing and GA4

**Three commands:** `/ai-advisors:visibility-report`, `/ai-advisors:aeo-fixes`,
`/ai-advisors:weekly-read`.

**One subagent:** `ai-visibility-auditor`, a read-only researcher that sweeps
every data source for one website and returns a single evidenced report.

## Requirements

- An AI-Advisors account on any paid plan, with MCP access enabled
- Admin or owner role in the workspace, to create a token
- At least one website set up and tracking

## Install

```
/plugin marketplace add AI-Advisors/ai-advisors-plugin
/plugin install ai-advisors@ai-advisors
```

Claude Code will prompt for your API token during install.

To get one: sign in at https://app.ai-advisors.ai, open
**Settings > MCP Access**, and create a token. It starts with `aia_` and is
shown once. Tokens are read-only, scoped to your workspace, and revocable from
the same screen.

Then verify with:

```
/ai-advisors:visibility-report
```

## Example prompts

- "Which of our tracked prompts do we lose in AI search, and who gets cited
  instead?"
- "Our AEO score dropped this month. What changed and what should we fix first?"
- "Are AI crawlers actually reaching our docs, and is AI search sending us any
  traffic that converts?"

## Privacy Policy

Full policy: https://www.ai-advisors.ai/privacy

**What this plugin sends.** Your API token, as an `Authorization` header, plus
the parameters of the tool being called (a website id, a prompt id, a lookback
window). No conversation content, file contents, or other context from your
Claude session is transmitted.

**What it receives.** Marketing measurement data from your own workspace: AI
visibility and citation metrics, AEO audit findings and recommendations, AI
referral and crawler traffic, and search performance. This is data AI-Advisors
already holds on your behalf.

**Storage and retention.** The plugin stores nothing locally beyond your token,
which Claude Code keeps in secure storage. Server side, only a SHA-256 hash of
the token is retained, along with the token name, creation time and last-used
time so you can identify stale tokens. Tool calls are rate limited per token.
Workspace data retention follows the AI-Advisors privacy policy.

**Third parties.** The plugin talks only to `app.ai-advisors.ai`. AI-Advisors
does not sell your data. Subprocessors are listed in the privacy policy.

**Your controls.** Revoke a token at any time from **Settings > MCP Access**;
revocation takes effect on the next call. Uninstalling the plugin removes the
stored token from Claude Code. For deletion or access requests, contact
privacy@ai-advisors.ai.

## Support

- Documentation: https://www.ai-advisors.ai/integrations/mcp-server
- Support: hello@ai-advisors.ai
- Security reports: security@ai-advisors.ai (see [SECURITY.md](SECURITY.md))

## License

MIT. See [LICENSE](LICENSE).
