# Security

## Reporting a vulnerability

Email **security@ai-advisors.ai** with a description, reproduction steps, and
the impact you believe it has. We aim to acknowledge reports within three
business days and will keep you updated while we investigate.

Please do not open a public GitHub issue for a security report.

## Scope

This repository contains the AI-Advisors plugin: configuration, skills, commands
and a subagent definition. It contains no credentials and no server code.

The plugin connects to the AI-Advisors MCP server at
`https://app.ai-advisors.ai/api/mcp`. Reports about that service, the web
application, or token handling are in scope for the same address.

## How credentials are handled

The plugin holds one credential: a personal access token created by the user in
their own AI-Advisors workspace. It is declared as a sensitive plugin setting,
so Claude Code stores it in secure storage and sends it as an `Authorization`
header over HTTPS. It is never written to this repository.

Server side, only a SHA-256 hash of the token is stored. Tokens are read-only,
scoped to the issuing workspace, rate limited, and revocable from
**Settings > MCP Access**.
