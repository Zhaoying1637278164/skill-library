# Mathbox

`mathbox` is a plugin for Codex and Claude Code containing ten reusable Agent
Skills and optional local tools for sustained, auditable mathematical research.

The toolbox separates research, verification, computation, literature work,
manuscript integration, and proofreading so that each workflow has a clear
evidence standard and stopping condition. The canonical distribution is the
`mathbox` plugin; each bundled skill remains independently installable for
hosts or environments that need a standalone Agent Skill.

These are research workflows and safeguards, not a computer algebra system or
a replacement for mathematical review.

## What changes in v3

Mathbox can now carry a research goal through successive attempts, retain the
mathematical reason each route failed, reconcile parallel or delayed returns,
and detect when a claim statement, proof input, computation result, or other
supporting artifact has changed.

| Capability | Result |
|---|---|
| `research-program` | Executes distinct proof, counterexample, source and computation routes from explicit checkpoints; preserves partial results and reconciles sibling returns |
| `research-state` | Records exact claim revisions, optional statement bindings, transitive dependencies, hashed evidence, separate review provenance, and program/run lifecycle |
| Dependency impact and handoff | Shows active review conditions, stale evidence, downstream blockers, route-only context, unresolved parallel state, and the next executable research routes |
| Bounded experiment runner | Records actual argv, input and scientific-result hashes, bounded logs, finite scope, and optional POSIX memory/CPU/affinity limits |
| Repository retrofit | Detects aliased research roles, ambiguous live files, computation records, cache conventions, and migration material that needs review or quarantine |
| Executable regression gate | Checks package contracts, synthetic fixture inventory, and state/experiment/inspector/cache behavior; mathematical task evaluation remains separate |

The optional ledger lives in the research project's `.mathbox/` directory. It
is an append-only, versioned record with generated views. Existing Markdown
projects and the eight specialist skills continue to work without it. Ledger
labels such as `proof-recorded` and `source-recorded` describe mechanically
current evidence; they do not certify a proof or replace a project's promotion
policy.

In v3.1, human-facing ledger and repository-inspector reports open with a brief
view; complete Markdown and JSON remain available on demand. The ledger also
supports prevalidated batches of distinct events and a read-only query for
claims affected by a pinned file. Repository setup now keeps mutable progress
out of root instructions and old checkpoint prose out of the live dashboard.
For an existing repository, `research-init` now provides a reviewed,
[pin-aware migration workflow](skills/research-init/references/existing-repo-migration.md)
for its instructions and live research state; it does not rewrite ledger events
or turn historical prose into proof automatically.
Program closeout now links one checked synthesis to route records, while a
program-level history entry point keeps growing route indexes out of routine
context; small projects may retain a flat index.

```text
$mathbox:research-init Plan a migration of this repository's AGENTS.md and live status; preserve history and inspect ledger pins before editing.
```

Start a sustained investigation with:

```text
$mathbox:research-program Pursue this conjecture through distinct proof and counterexample routes. Preserve the original goal, execute the promising approaches, and continue after failed attempts.
```

For an existing ledger:

```text
$mathbox:research-state Check which claims depend on Lemma K, which evidence is stale, and what to attack next.
```

See the [v3 design and migration rationale](docs/design-v3.md),
[ledger command contract](skills/research-state/references/ledger.md), and
[experiment runner](skills/computation-audit/references/runner.md).

## Quick start

### Claude Code: install the plugin

From a Claude Code session, add this repository as a marketplace and install
the bundle:

```text
/plugin marketplace add nidrissi/mathbox
/plugin install mathbox@mathbox
```

Start a new session, run `/skills`, and try:

```text
/mathbox:proof-audit Audit the proof of Lemma 3.2 and isolate the first unproved implication.
```

Claude namespaces plugin skills with the plugin name. The repository root is
also the plugin root, so a source checkout can be tested without installation:

```bash
git clone https://github.com/nidrissi/mathbox.git
claude --plugin-dir ./mathbox
```

### Codex: install the plugin

Install `mathbox` from Codex's plugin directory. The repository is a native
Codex plugin through `.codex-plugin/plugin.json`; the Claude manifest also
provides the explicit skill inventory used by OpenAI's skills-only conversion
path. Both hosts therefore load the same canonical directories under `skills/`
without duplicated packages.

Start a new session, run `/skills`, and try the namespaced plugin skill:

```text
$mathbox:proof-audit Audit the proof of Lemma 3.2 and isolate the first unproved implication.
```

If the plugin directory listing is not yet available, Codex's built-in skill
installer can install the component skills directly from the repository:

```text
$skill-installer Install every skill under skills/ from https://github.com/nidrissi/mathbox.
```

That fallback is a standalone skill installation, not a `mathbox` plugin
installation, so its explicit invocations use bare names such as
`$proof-audit`.

### Standalone or single-skill installation

Requirements are Git, a host with Agent Skills support, and Python 3.10+ only for
the optional bundled helper scripts. This compatibility path installs bare
skills rather than the `mathbox` plugin. The helpers use the standard library.

Clone the repository somewhere stable:

```bash
git clone https://github.com/nidrissi/mathbox.git \
  "$HOME/.local/share/mathbox"
toolbox_dir="$HOME/.local/share/mathbox"
skills_dir="$toolbox_dir/skills"
```

To install only `proof-audit`, link it into the host you use:

```bash
# Codex
mkdir -p "$HOME/.agents/skills"
ln -s "$skills_dir/proof-audit" "$HOME/.agents/skills/proof-audit"

# Claude Code
mkdir -p "$HOME/.claude/skills"
ln -s "$skills_dir/proof-audit" "$HOME/.claude/skills/proof-audit"
```

To link all ten skills for both hosts:

```bash
mkdir -p "$HOME/.agents/skills" "$HOME/.claude/skills"

for skill_file in "$skills_dir"/*/SKILL.md; do
  skill_dir=${skill_file%/SKILL.md}
  skill_name=${skill_dir##*/}
  ln -s "$skill_dir" "$HOME/.agents/skills/$skill_name"
  ln -s "$skill_dir" "$HOME/.claude/skills/$skill_name"
done
```

These commands do not overwrite an existing skill with the same name. On
native Windows, use WSL or copy the selected directories instead of creating
symlinks. Standalone invocations use `$proof-audit` in Codex and `/proof-audit`
in Claude Code; plugin-installed invocations use `$mathbox:proof-audit` in
Codex and `/mathbox:proof-audit` in Claude Code.

The `mathbox` plugin skills use the mathematical software already available in
your project. Installing the plugin or its standalone component skills does not
install SageMath, LaTeX, or other project dependencies.

## Included plugin skills

| Plugin skill | Purpose | Selection |
|---|---|---|
| [`mathbox:research-program`](skills/research-program/) | Pursue or close out a substantial program across distinct routes, preserving compact current state | matching sustained research or closeout request |
| [`mathbox:research-state`](skills/research-state/) | Track claim revisions, evidence freshness and dependency impact | existing ledger or tracking request |
| [`mathbox:research-init`](skills/research-init/) | Initialize or migrate a mathematical research repository's agent architecture | explicit request |
| [`mathbox:research-attempt`](skills/research-attempt/) | Pursue one bounded proof, counterexample, reduction, source, or computation route | explicit request |
| [`mathbox:proof-audit`](skills/proof-audit/) | Adversarially audit an existing claim or proof and isolate the exact gap | automatic |
| [`mathbox:literature-check`](skills/literature-check/) | Verify or locally cache an external result, citation, notation translation, or bounded novelty claim | automatic |
| [`mathbox:computation-audit`](skills/computation-audit/) | Design, run, or audit a claim-supporting mathematical computation | automatic |
| [`mathbox:manuscript-integrate`](skills/manuscript-integrate/) | Integrate an already validated result into an authoritative LaTeX manuscript | explicit request |
| [`mathbox:proofread-math`](skills/proofread-math/) | Conservatively proofread mathematical prose and LaTeX | automatic |
| [`mathbox:research-retrospective`](skills/research-retrospective/) | Reconcile project state and select the next bounded research routes | explicit request |

“Explicit request” is a portable routing boundary expressed in the skill's
description and body, not a host-specific frontmatter switch. “Automatic” means
that a matching task may select the skill without naming it. The program and
state skills use normal automatic discovery within their specific trigger
boundaries. Existing explicit-only invocation policies are preserved.
Every plugin skill can still be invoked by name: use `$mathbox:skill-name` in Codex or
`/mathbox:skill-name` in Claude Code. Bare `$skill-name` and `/skill-name`
forms refer only to standalone installations.

## Choosing a skill

| The task is primarily… | Use |
|---|---|
| setting up the research repository, revising its agent architecture, or migrating its history across programs | `mathbox:research-init` |
| pursuing a substantial goal across successive approaches, or closing out one program or phase | `mathbox:research-program` |
| checking evidence freshness, dependency impact or a ledger handoff | `mathbox:research-state` |
| developing new mathematics along one controlled route | `mathbox:research-attempt` |
| deciding whether an existing argument is correct as written | `mathbox:proof-audit` |
| checking exactly what an external source proves | `mathbox:literature-check` |
| obtaining or assessing finite computational evidence | `mathbox:computation-audit` |
| transferring a validated result into the live paper | `mathbox:manuscript-integrate` |
| correcting grammar, typography, LaTeX, references, or forced local typos | `mathbox:proofread-math` |
| reviewing the project portfolio and deciding what to try next, read-only | `mathbox:research-retrospective` |

Important boundaries:

- A bounded computation is evidence only for its stated range, not a universal
  proof.
- A proof audit reconstructs the claimed object independently before accepting
  a computation or derivation performed on a convenient substitute. Coverage
  claims must match the actual iterator and absolute grading, not only samples
  or parity checks.
- Proofreading does not authorize changing an argument. Use the
  `mathbox:proof-audit` plugin skill to diagnose an existing proof or
  `mathbox:research-attempt` to develop a new one.
- The `mathbox:manuscript-integrate` plugin skill transfers mathematics that
  has already been validated; it does not make conjectural work
  publication-ready.
- A failed literature search supports only a bounded search report, not a claim
  of global novelty. Novelty checks use equivalent and historical terminology
  and follow citation chains to primary sources where available.

## Local literature cache

When a research repository authorizes retaining source material,
`literature-check` can reuse PDFs and extracted text from the project's ignored
`.research-cache/literature/` directory. Records are content-addressed by the
PDF's SHA-256 and searchable without a database; tracked literature ledgers keep
only bibliographic metadata, hashes, and extraction status. The bundled helper
uses `pdftotext` opportunistically when it is installed, and never fetches
sources or handles credentials itself.

Keep a tracked `/.research-cache/` rule in the project's own `.gitignore`. The
helper also writes an internal ignore rule as a fallback, refuses to write any
artifact Git would track — including one already in the index — and reports
whether coverage comes from a project rule or only from its own, so a missing
project rule stays visible rather than silently satisfied. Lookups
(`find`, `show`, `verify`) never create or modify the cache.

Other research-facing skills route any new question about what an external
mathematical source proves through `literature-check`; this ensures they share
the same exact-version, cache-first, and evidence rules. Proofreading checks
citation syntax only, and repository initialization inventories literature
policy without performing substantive source verification.

## Updating and pinning

The `mathbox` plugin can be updated through the host's plugin manager. For a
manual standalone installation, pull the checkout:

```bash
git -C "$HOME/.local/share/mathbox" pull --ff-only
```

For a reproducible setup, check out a release tag or commit before linking the
skills.

## Repository structure

```text
mathbox/
├── .codex-plugin/
│   └── plugin.json                       # Codex package and presentation metadata
├── .claude-plugin/
│   ├── marketplace.json                  # Claude marketplace catalog
│   └── plugin.json                       # root plugin metadata and skill list
├── assets/
│   └── mathbox.svg                       # Codex square icon and logo
├── AGENTS.md                             # shared contributor instructions
├── README.md
└── skills/
    └── <skill-name>/
        ├── SKILL.md                       # canonical workflow contract
        ├── agents/openai.yaml             # OpenAI presentation metadata
        ├── evals/                         # behavior and routing probes
        ├── references/                    # supporting material
        ├── assets/                        # optional templates or data
        └── scripts/                       # optional deterministic helpers
```

There is only one copy of each skill. The Codex manifest points to `skills/`,
the Claude manifest lists each directory beneath it explicitly, and every skill
remains independently installable. Relative resource links therefore continue
to work when a skill is copied, linked, loaded by Claude, or converted by
OpenAI.

Canonical skill folders and `SKILL.md` names are intentionally bare (for
example, `proof-audit`) so they remain portable Agent Skills. Installing the
bundle as a plugin exposes them under the `mathbox:` namespace.

The `SKILL.md` frontmatter uses only the portable required Agent Skills fields
`name` and `description`. OpenAI uses `agents/openai.yaml` for host-specific
presentation and invocation policy; other hosts ignore it.

## Verification

```bash
python3 scripts/check.py
```

This runs static package checks and the executable regression suites, using
only the Python standard library. `--static` skips execution. CI runs the same
gate on Python 3.10 and 3.13. The [evaluation protocol](evals/README.md) separates
routing, mathematical behavior and software correctness; the
[v3 validation report](docs/validation-v3.md) records what was actually tested.

The computation validator now rejects an unfilled template as evidence. Use
`validate_manifest.py TEMPLATE --template` only for scaffolds. Complete version 1
records remain supported; the optional runner emits version 2 records.

## Contributing

Keep each skill focused on one job. Update its instructions, supporting files,
behavioral evals, and routing evals together when its contract changes. If a
skill is added, renamed, or removed, update the tables in this README in the
same change.

Repository-wide contribution and validation instructions are in
[`AGENTS.md`](AGENTS.md).

Useful upstream references:

- [Build plugins for ChatGPT and Codex](https://learn.chatgpt.com/docs/build-plugins)
- [Submit a Claude Code plugin to OpenAI](https://developers.openai.com/plugins/guides/submit-claude-plugin)
- [Create plugins for Claude Code](https://code.claude.com/docs/en/plugins)
- [Agent Skills specification](https://agentskills.io/specification)

## License

[MIT](LICENSE) © 2026 Najib Idrissi-Kaïtouni.
