# Mokaru for Claude

Official Claude plugin for [Mokaru](https://mokaru.ai), a job search and resume platform. It connects Claude to your Mokaru account so you can search jobs, tailor your resume to a specific role with AI, and manage your application pipeline in conversation.

The plugin bundles Mokaru's hosted MCP server plus four skills that teach Claude the workflows and the pitfalls.

> This plugin does **not** submit job applications for you. It finds roles, prepares tailored resumes, and tracks what you sent. You open the apply link and complete the application yourself.

## What you can ask for

> "Search Mokaru for senior product manager roles in Amsterdam posted this week, remote-friendly. Save the top three to my tracker and tailor a resume for each."

> "Show me the resume I tailored for the Acme role and give me a link to export it."

> "I just earned my AWS Solutions Architect certification, credential AWS-SAP-12345. Add it to my certificates and mention it in my summary."

> "Which applications are at interview stage, and which have gone quiet for more than two weeks?"

## Requirements

| | |
|---|---|
| Account | Free at [mokaru.ai](https://mokaru.ai) |
| Plan | **Plus.** Connecting and OAuth are free; tool calls return `403` on a Free account |
| Client | Claude Code, Claude Cowork, or any MCP client supporting streamable HTTP with OAuth |

## Install

```bash
claude plugin marketplace add anthropics/claude-plugins-community
claude plugin install mokaru@claude-community
```

Then run `/mcp`, pick **mokaru**, and complete the sign-in that opens in your browser. There is no API key to copy or paste.

To run it straight from this repository instead:

```bash
git clone https://github.com/VNDCK/Mokaru-MCP.git
claude --plugin-dir ./Mokaru-MCP
```

[SETUP.md](SETUP.md) covers the connection flow and what each error code means.

## Tools

71 tools, grouped by what they touch:

| Group | Tools | Read-only |
|---|---|---|
| Jobs | 1 | 1 |
| Applications | 6 | 2 |
| Resumes | 7 | 3 |
| Resume sharing | 3 | 1 |
| Cover letters | 5 | 2 |
| Profile | 2 | 1 |
| Profile sections | 43 | 10 |
| Contacts | 4 | 1 |

Profile sections is the largest group because each section (experience, education, skills, certificates, projects, awards, publications, interests, summaries, custom sections) has its own list, create, update, and delete tool rather than one write-anything endpoint.

Every tool carries a `title` and an explicit `readOnlyHint` or `destructiveHint`. The 21 read-only tools run without a per-call confirmation; the 50 that write or delete always prompt you first. Reads and writes are never combined in one tool.

Full parameter reference: [docs.mokaru.ai/integrations/mcp-tools](https://docs.mokaru.ai/integrations/mcp-tools).

## Skills

The tools alone leave a lot of room for an agent to guess wrong. These skills encode the parts that matter:

| Skill | Covers |
|---|---|
| `job-search` | Searching, cursor pagination, presenting apply links, and that applying is the user's own step |
| `tailor-resume` | AI auto-prep, why `409` means "still tailoring" rather than an error, and reviewing AI output before trusting it |
| `application-tracker` | Pipeline summaries, status updates, ISO-8601 date handling, closed postings |
| `resume-content` | That item ids come only from the list tools, and that omitting `cvId` writes to the base resume instead of the tailored one |

## Authentication

The server at `https://api.mokaru.ai/mcp` uses OAuth 2.1 with PKCE and Dynamic Client Registration ([RFC 7591](https://datatracker.ietf.org/doc/html/rfc7591)). Your client discovers the metadata at `/.well-known/oauth-authorization-server`, registers itself, and opens a Mokaru consent screen. Tokens are held by your client; nothing is stored in this repository or in the plugin config.

Details: [docs.mokaru.ai/integrations/mcp-oauth](https://docs.mokaru.ai/integrations/mcp-oauth).

## What is in this repository

The plugin wrapper only. The MCP server is hosted by Mokaru and its source is not part of this repo.

```
.claude-plugin/plugin.json   manifest
.mcp.json                    points at https://api.mokaru.ai/mcp over streamable HTTP
SETUP.md                     connection guide and error-code reference
skills/                      job-search, tailor-resume, application-tracker, resume-content
```

## Privacy

Full policy: [mokaru.ai/legal/privacy-policy](https://mokaru.ai/legal/privacy-policy), which has a dedicated section on AI agent integrations over MCP.

What applies when you use this plugin:

- **Collected** - the Mokaru account data that the tools you invoke read or write: resumes, applications, profile, contacts. Plus request metadata for rate limiting and abuse prevention.
- **Not collected** - your Claude conversation, chat history, memory, or local files. No tool reads them.
- **Shared** - AI tailoring runs through the AI providers listed in the policy. Nothing is sold.
- **Retention** - your data stays in your Mokaru account until you delete it or close the account.
- **Contact** - [privacy@mokaru.ai](mailto:privacy@mokaru.ai)

## Support

| | |
|---|---|
| Documentation | [docs.mokaru.ai/integrations/mcp](https://docs.mokaru.ai/integrations/mcp) |
| Support | [support@mokaru.ai](mailto:support@mokaru.ai) |
| Security | [security@mokaru.ai](mailto:security@mokaru.ai), 48-hour response, safe harbor for good-faith research |
| Issues | [github.com/VNDCK/Mokaru-MCP/issues](https://github.com/VNDCK/Mokaru-MCP/issues) |

## License

MIT for this wrapper, see [LICENSE](LICENSE). The Mokaru service itself is governed by its [terms of service](https://mokaru.ai/legal/terms-of-service).
