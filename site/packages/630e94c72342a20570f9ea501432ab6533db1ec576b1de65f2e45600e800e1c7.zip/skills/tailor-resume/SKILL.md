---
description: Tailors a Mokaru resume to a specific job with AI, producing a job-specific copy without touching the base resume. Use when the user wants their CV rewritten, optimized, or matched for a particular role or job posting.
---

# Tailoring a resume to a job

`mokaru_tailor_resume` starts Mokaru's AI auto-prepare. It duplicates the user's default resume and rewrites the copy for one specific job: keyword alignment, rephrased experience bullets, a focused summary.

The base resume is never modified. Each tailored resume is a separate resume in the account.

## Running it

The job description is what drives the result. Supply it one of two ways:

- Pass `jobListingId` from a `mokaru_search_jobs` result and Mokaru pulls the description itself.
- Paste the description text directly when the job did not come from Mokaru's database.

Tailoring is a Plus feature and takes roughly half a minute. While it runs, resume tools for that resume return `409`. That is the expected in-progress signal: wait a few seconds and retry rather than treating it as an error.

`mokaru_create_application` with the auto-prepare option does the same tailoring as part of saving a job to the tracker. Use that when the user wants both in one step.

## After it finishes

1. `mokaru_list_resumes` to find the new resume.
2. `mokaru_get_resume` to read what the AI produced.
3. Show the user what changed before they rely on it. AI rewriting can overstate things, and it is their name on the document.

To hand them a file, call `mokaru_export_resume_pdf`. It returns a link that opens the export view in the Mokaru web app; the user clicks Export there. The tool does not return PDF bytes.

## Editing a tailored resume afterwards

Per-section tools accept an optional `cvId`. Pass the tailored resume's id to edit that resume. Omit it and the edit lands on the base resume instead, which is rarely what the user meant after tailoring.
