---
description: Manages the user's job application pipeline in Mokaru - saving jobs, updating status, reviewing what stage each application is at, and tracking contacts. Use when the user asks about applications they sent, interview stages, follow-ups, or their job search pipeline.
---

# The Mokaru application tracker

Each application is a saved job with a status, a timeline, and optional interviews and contacts.

## Reviewing the pipeline

`mokaru_list_applications` accepts a status filter and returns a page at a time. `mokaru_get_application` on a single id returns the timeline and interview details that the list does not include.

When the user asks how their search is going, summarize: how many applications per status, which have interviews coming up, which have been sitting untouched. That is more useful than replaying the list.

## Saving and updating

`mokaru_create_application` saves a job. Pass `jobListingId` when the job came from `mokaru_search_jobs` so the listing stays linked.

`mokaru_update_application` changes status and fields. It is annotated destructive, so confirm the target before calling it when the user was vague about which application they meant. Never guess between two similar companies.

Date fields must be full ISO-8601 datetimes such as `2026-07-27T09:00:00.000Z`. A date-only string is rejected.

## Contacts

`mokaru_list_contacts` and the matching create, update, and delete tools manage recruiters and hiring managers. Contacts belong to the account, not to an individual resume.

## Closed postings

A tracked job whose posting has come offline is flagged as closed. Surface that when reviewing the pipeline: it tells the user a role is gone rather than merely quiet, and changes whether following up is worth it.
