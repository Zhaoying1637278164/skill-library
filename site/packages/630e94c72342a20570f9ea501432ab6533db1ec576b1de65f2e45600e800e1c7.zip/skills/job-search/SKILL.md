---
description: Searches the Mokaru job database and presents matches with apply links. Use when the user is looking for jobs, vacancies, or roles, or asks what is open in a location, industry, or work arrangement.
---

# Searching jobs on Mokaru

`mokaru_search_jobs` queries the Mokaru job database. It is read-only and takes a free-text query plus optional filters for location, work arrangement, employment type, and posting recency.

## How to run a search

1. If the user's request is vague ("find me something"), read `mokaru_get_profile` first and derive the query from their job titles and skills. Say which titles you searched for.
2. Search. Pagination is cursor-based: pass `nextCursor` from the previous response to get more, and stop when `hasMore` is false.
3. Present each match with company, title, location, and the `applyLink`.

## This plugin does not apply for the user

There is no tool that submits an application. `applyLink` points at the employer's own posting, and the user completes the application themselves.

When the user says "apply to this one", do two things: save it with `mokaru_create_application` so it lands in their tracker, and give them the `applyLink`. Be explicit that they still have to open the link. Do not imply the application was sent.

## Dateless postings

Some sources publish no posting date. Those results carry an estimated-date flag rather than a real one. Do not present an estimated date as the posting date. If the user is filtering on recency, mention that a subset of listings has no reliable date.

## Result volume

Return a useful shortlist, not the whole response. If a search returns dozens of matches, summarize the top ones against what the user actually asked for and offer to show more.
