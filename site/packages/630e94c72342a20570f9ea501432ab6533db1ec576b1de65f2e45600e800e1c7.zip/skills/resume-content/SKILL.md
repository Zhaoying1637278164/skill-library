---
description: Reads and edits the content of a Mokaru resume - experience, education, skills, certificates, projects, awards, publications, interests, summaries, and custom sections. Use when the user wants to add, correct, or remove something on their CV or career profile.
---

# Editing resume content on Mokaru

Career content lives in per-section tools: experiences, education, skills, certificates, projects, awards, publications, interests, summaries, and custom sections. Each has list, create, update, and delete variants.

## Item ids come from the list tools only

`mokaru_get_profile` returns content without item ids. To update or delete anything, call the matching `mokaru_list_*` tool first and take the id from there. Skipping that step produces a `404`.

## Which resume you are editing

Every per-section tool accepts an optional `cvId`:

- **Omitted** - the edit applies to the base resume, the user's canonical CV.
- **Set** - the edit applies to that specific resume, for example one produced by tailoring.

This distinction matters because a resume copies the base resume's content at the moment it is created. Editing the base afterwards does not propagate to resumes that already exist. If the user says "fix that typo in my Acme CV", pass the Acme resume's `cvId`, or the fix lands on the wrong document.

Contacts are the exception: they belong to the account and take no `cvId`.

## Conventions worth knowing

- Dates must be full ISO-8601 datetimes. A date-only string is rejected.
- On update tools, pass `null` to clear an optional field. Omitting the field leaves it unchanged.
- Update and delete tools are annotated destructive and will prompt the user. Confirm which item you are about to change when more than one could match.

## Custom sections

Custom sections are two levels: the section definition, then its items. Create the section first, then add items with `mokaru_create_custom_section_item` using the section's id.

## Resumes themselves

`mokaru_list_resumes`, `mokaru_get_resume`, `mokaru_create_resume`, `mokaru_duplicate_resume`, and `mokaru_update_resume` manage resumes as documents: their name, design settings, and existence. `mokaru_update_resume` is the tool for renaming or restyling, not for content.
