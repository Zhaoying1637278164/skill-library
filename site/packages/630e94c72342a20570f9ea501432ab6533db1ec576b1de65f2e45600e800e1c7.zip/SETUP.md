---
name: mokaru-setup
description: Connects this plugin's Mokaru MCP server to the user's Mokaru account. Use when Mokaru tools are unavailable, return 401 or 403, or the user has just installed the plugin.
---

# Connecting Mokaru

The Mokaru MCP server at `https://api.mokaru.ai/mcp` uses OAuth. There is no API key to paste and nothing to install: the browser handles authorization.

## What the user needs first

1. A Mokaru account at [mokaru.ai](https://mokaru.ai).
2. An active **Plus plan**. MCP access is a Plus feature. Connecting and authorizing are free, but tool calls return `403` on a Free account.
3. Ideally some content in the account: a resume with experience and skills. An empty account connects fine, but most tools have nothing to work with.

## Connecting

In Claude Code, run `/mcp`, select **mokaru**, and follow the browser flow. `claude mcp login mokaru` does the same thing from the shell.

The browser opens a Mokaru login and consent screen. After approving, the tools become available in the session.

## Diagnosing failures

| Symptom | Cause | Fix |
|---|---|---|
| Server flagged as needing authentication | No token yet, or the stored refresh token was rejected | Run `/mcp` and pick Re-authenticate |
| Every tool returns `403` | Account is not on Plus | Upgrade at [mokaru.ai/pricing](https://mokaru.ai/pricing) |
| `409` on a resume tool | Auto-prepare is still tailoring that resume | Wait a few seconds and retry |
| `429` | Per-account rate limit | Back off. Do not retry in a loop |

Do not add an `Authorization` header to the server config. If the server rejects a manually supplied header, the client reports a failed connection instead of falling back to OAuth.

For the full setup reference across clients, see [docs.mokaru.ai/integrations/mcp-clients](https://docs.mokaru.ai/integrations/mcp-clients).
