#!/usr/bin/env node
// Copyright (c) JFrog Ltd. 2026
// Licensed under the Apache License, Version 2.0
// https://www.apache.org/licenses/LICENSE-2.0
//
// JFrog Agent Guard activation check.
//
// Silent gate used by Step 0 of the jfrog-mcp-management skill. Determines
// whether the JFrog Agent Guard is enabled for the current environment.
//
// Contract:
//   - exit 0 -> Agent Guard ENABLED  (skill may proceed)
//   - exit 2 -> Agent Guard DISABLED (registry off, or _JF_AGENT_GUARD_FORCE_DISABLE)
//   - exit 1 -> status UNKNOWN: no credentials, timeout, network/DNS error.
//               Not sure if Enabled or not.
//   - a single human-readable reason line is written to stdout for
//     diagnostics only; Step 0 keys off the EXIT CODE, not the text.
//
// Set JF_AGENT_GUARD_DEBUG=true for verbose tracing on stderr.

import { execFileSync } from "node:child_process";
import process from "node:process";

const SETTINGS_PATH =
  "/ml/core/api/v1/administration/account-settings/mcp_gateway_plugin_enabled";
// Self-hosted JPDs serve the same API behind `/bridge-client`. Tried ONLY
// after the root path 404s, so SaaS still costs exactly one request.
const BRIDGE_CLIENT_PREFIX = "/bridge-client";
const REQUEST_TIMEOUT_MS = 5000;

const debugEnabled = process.env.JF_AGENT_GUARD_DEBUG === "true";
const debug = (message) => {
  if (debugEnabled) console.error(`[jfrog-agent-guard] ${message}`);
};

// New JFROG_* env vars take precedence over the legacy JF_* names.
const env = (newName, oldName) =>
  process.env[newName] ?? (oldName ? process.env[oldName] : undefined);

const GATE_DONE = Symbol("gateDone");

const enabled = (reason) => {
  process.stdout.write(`Enabled: ${reason}\n`);
  process.exitCode = 0;
  throw GATE_DONE;
};

const unknown = (reason) => {
  process.stdout.write(`Unknown: ${reason}\n`);
  process.exitCode = 1;
  throw GATE_DONE;
};

// Reachable platform that reports the MCP registry turned off. Distinct exit
// code so the skill can tell this definitive answer apart from an undetermined
// status.
const registryDisabled = (reason) => {
  process.stdout.write(`RegistryDisabled: ${reason}\n`);
  process.exitCode = 2;
  throw GATE_DONE;
};

// Exactly one positional argv[2]. Extras (argv[3..]), flags, and URLs are
// ALWAYS caller bugs — stop the gate immediately so a multi-JPD setup does
// not report the wrong platform's state. Everything else is treated as a
// candidate jf config server id — including hostname-shaped values and ids
// with spaces — because a text pattern cannot separate a real jf id from
// an MCP package name. jf config is the source of truth (see
// resolveCredentials).
function readGateServerId() {
  const extra = process.argv.slice(3);
  if (extra.length > 0) {
    unknown(
      `expected zero or one positional jf config server id, got extra ` +
        `argument(s) ${JSON.stringify(extra)} — the gate accepts only ` +
        `\`<SERVER_ID>\` positionally, with no flags or additional values ` +
        `after it`,
    );
  }
  const raw = process.argv[2];
  if (raw === undefined) return undefined;
  const id = String(raw).trim();
  if (!id) return undefined;
  if (id.startsWith("-")) {
    unknown(
      `expected a jf config server id (positional), got flag ` +
        `${JSON.stringify(id)} — pass \`<SERVER_ID>\` positionally, not as \`--server\``,
    );
  }
  if (/:\/\//.test(id)) {
    unknown(
      `expected a jf config server id (positional), got URL ` +
        `${JSON.stringify(id)} — do not derive an id from \`JFROG_URL\` / \`JF_URL\``,
    );
  }
  return id;
}

// Resolve credentials from Path A (environment variables) or Path B
// (the default JFrog CLI configuration). Returns { baseUrl, token, source }
// or null when neither path yields a usable URL + access token.
function resolveCredentials() {
  const explicitServerId = readGateServerId();
  // When the caller names a specific server, honor it or stop. Do not fall
  // back to env credentials or the default jf server, that would check a
  // different JPD in a multi-server setup when the named id is wrong (typo,
  // MCP package name, unknown id).
  if (explicitServerId) {
    const fromCli = resolveFromCliConfig(explicitServerId);
    if (fromCli) return fromCli;
    unknown(
      `server id ${JSON.stringify(explicitServerId)} is not configured in ` +
        `\`jf config\` (or \`jf\` is unavailable) — refusing to check a different JPD`,
    );
  }

  // Path A — environment variables.
  const envUrl = env("JFROG_URL", "JF_URL");
  const envToken = env("JFROG_ACCESS_TOKEN", "JF_ACCESS_TOKEN");
  if (envUrl && envToken) {
    debug("Using credentials from environment variables (Path A).");
    return { baseUrl: envUrl, token: envToken, source: "environment variables" };
  }
  debug(
    "Environment credentials incomplete; trying JFrog CLI config (Path B).",
  );

  // Path B — default server from the local JFrog CLI configuration.
  return resolveFromCliConfig(undefined);
}

function resolveFromCliConfig(serverId) {
  // `jf config export [server ID]` emits the server as a base64-encoded JSON
  // blob containing url, accessToken, and serverId. An optional server ID may
  // be passed; without it the CLI's default server is used. We use the CLI
  // rather than reading ~/.jfrog/jfrog-cli.conf.v6 directly because newer CLIs
  // do not persist the access token in that file (and the platform URL may be
  // stored only as an /artifactory-suffixed URL there, which is wrong for
  // /ml/core).
  const exportArgs = serverId ? ["config", "export", serverId] : ["config", "export"];
  let exported;
  try {
    exported = execFileSync("jf", exportArgs, {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      timeout: 2000,
    }).trim();
  } catch (error) {
    debug(
      `'jf config export' failed (jf not on PATH or no server configured): ${error?.message}`,
    );
    return null;
  }

  let cfg;
  try {
    cfg = JSON.parse(Buffer.from(exported, "base64").toString("utf8"));
  } catch (error) {
    debug(`Could not decode the jf config export token: ${error?.message}`);
    return null;
  }

  // `url` is the platform/JPD root — the base the /ml/core settings path needs.
  const baseUrl = cfg?.url;
  const token = cfg?.accessToken;
  if (!baseUrl) {
    debug("Exported JFrog CLI config has no platform URL.");
    return null;
  }
  if (!token) {
    debug("Exported JFrog CLI config has no access token (bearer auth needed).");
    return null;
  }

  const id = cfg?.serverId ?? "default";
  return { baseUrl, token, source: `JF CLI config (server '${id}')` };
}

/** Drops the internal `notFound` marker from a fetchSetting() result. */
function strip({ notFound, ...result }) {
  return result;
}

async function isGatewayPluginEnabled(baseUrl, token) {
  // Normalize to the platform root: drop trailing slashes and a trailing
  // `/artifactory` segment. Users commonly export JFROG_URL as
  // `https://myco.jfrog.io/artifactory`, but the settings path lives under
  // `/ml/core` off the platform root — without this, Path A would build
  // `.../artifactory/ml/core/...` and 404 into a false "unknown" (exit 1).
  const root = baseUrl.replace(/\/+$/, "").replace(/\/artifactory$/, "");

  const rootResult = await fetchSetting(root + SETTINGS_PATH, token);
  if (!rootResult.notFound) return strip(rootResult);

  // Root 404 -> possibly self-hosted. Each attempt gets its OWN timeout
  // budget: a reused AbortController would start the retry already spent.
  debug(`Root ${SETTINGS_PATH} returned 404; retrying behind ${BRIDGE_CLIENT_PREFIX}.`);
  const bridgeResult = await fetchSetting(
    root + BRIDGE_CLIENT_PREFIX + SETTINGS_PATH,
    token,
  );
  // Bridge may only UPGRADE the verdict; anything else keeps the root result.
  if (bridgeResult.ok || bridgeResult.registryOff) return strip(bridgeResult);
  return strip(rootResult);
}

// One HTTP attempt against a fully-built settings URL. `notFound` marks the
// 404 that triggers the `/bridge-client` retry; callers strip it before
// returning so the result shape main() sees is unchanged.
async function fetchSetting(url, token) {
  debug(`Fetching gateway plugin setting from ${url}`);

  // Trade-off: we use a direct fetch() rather than `jf api` (the pattern other
  // scripts in this repo use for authenticated JFrog REST calls) because this
  // gate keys off exact HTTP status codes — 200+value:false vs 401/403 vs
  // unreachable each map to a different exit code — and parsing `jf api`'s
  // "[Warn] ... returned NNN" / "Http Status: NNN" stderr convention for that
  // is brittle. The cost: this call does NOT inherit any corporate-proxy or
  // custom-CA settings baked into the user's `jf` config, so an env that only
  // works through jf's transport can surface here as an unreachable/timeout
  // (exit 1). If that becomes common, switch to `jf api` and parse its status.
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${token}`,
      },
      signal: controller.signal,
    });
    if (!response.ok) {
      debug(`Settings request returned HTTP ${response.status}.`);
      // Non-OK (incl. 401/403) means an auth/permission/transport problem, NOT
      // a deliberately-disabled registry — report unknown (exit 1) rather than
      // claiming disabled. Only HTTP 200 + value:false is "disabled".
      return {
        ok: false,
        notFound: response.status === 404,
        reason: `settings endpoint returned HTTP ${response.status}`,
      };
    }
    const data = await response.json();
    // Be tolerant about where and how the flag is carried, so a shape/casing
    // change on the platform side can't turn a genuinely-enabled registry into
    // a false "disabled" (exit 1). The endpoint URL already names the setting
    // (`.../mcp_gateway_plugin_enabled`), so the body may arrive as any of:
    //   - `{ settings: { mcpGatewayPluginEnabled: <bool|{value}> } }` (wrapped);
    //   - the same at the top level, un-wrapped;
    //   - `{ value: <bool> }` (bare wrapper, key implied by the URL);
    //   - a bare boolean `true` / `false`.
    // Casing: the path segment is snake_case while JFrog JSON bodies are
    // typically camelCase — accept either.
    const unwrap = (v) =>
      v !== null && typeof v === "object" ? v?.value : v;
    const container = data?.settings ?? data;
    const named =
      container?.mcpGatewayPluginEnabled ??
      container?.mcp_gateway_plugin_enabled;
    // `named` first (explicit key), then the bare wrapper / bare boolean forms.
    const value =
      typeof data === "boolean"
        ? data
        : named !== undefined
          ? unwrap(named)
          : unwrap(container);
    debug(`Settings response indicates gateway plugin enabled=${value}.`);
    if (value === true) return { ok: true };
    if (value === false) {
      return {
        ok: false,
        registryOff: true,
        reason: "mcp gateway plugin setting returned false",
      };
    }
    return {
      ok: false,
      reason: "settings endpoint returned an invalid gateway-plugin setting",
    };
  } catch (error) {
    const reason =
      error?.name === "AbortError" ? "timeout" : error?.message ?? "unknown error";
    debug(`Settings request failed: ${reason}`);
    return { ok: false, reason: `settings endpoint unreachable (${reason})` };
  } finally {
    clearTimeout(timeout);
  }
}

async function main() {
  // Manual overrides bypass credential resolution and the network call
  // entirely. Checked first, in this order, so a conflicting config fails
  // safe (disabled) rather than silently favoring enablement.
  const forceDisabled =
    env("_JF_AGENT_GUARD_FORCE_DISABLE") === "true";
  const forceEnabled =
    env("JF_AGENT_GUARD_FORCE_ENABLE") === "true";
  if (forceDisabled) {
    registryDisabled("forced via _JF_AGENT_GUARD_FORCE_DISABLE");
    return;
  }
  if (forceEnabled) {
    enabled("forced via JF_AGENT_GUARD_FORCE_ENABLE");
    return;
  }

  const creds = resolveCredentials();
  if (!creds) {
    unknown(
      "JFROG_URL/JF_URL + access token not set and no default JF CLI config found",
    );
    return;
  }

  const result = await isGatewayPluginEnabled(creds.baseUrl, creds.token);
  if (result.ok) {
    enabled(`via ${creds.source}`);
    return;
  }
  if (result.registryOff) {
    registryDisabled(result.reason);
    return;
  }
  unknown(result.reason);
}

try {
  await main();
} catch (error) {
  if (error === GATE_DONE) {
    // Intentional halt after a diagnostic write. Lets stdout drain.
  } else {
    // Last-resort guard: any unexpected throw must NOT leak a stack trace to the
    // user (the skill's Step 0 is silent). Downgrade to the safe "unknown" exit.
    debug(`Unexpected error: ${error?.stack ?? error?.message ?? error}`);
    try {
      unknown("unexpected error");
    } catch (halt) {
      if (halt !== GATE_DONE) throw halt;
    }
  }
}
