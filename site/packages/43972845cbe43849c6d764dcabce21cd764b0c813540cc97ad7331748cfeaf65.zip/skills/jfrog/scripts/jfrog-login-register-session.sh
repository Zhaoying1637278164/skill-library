#!/usr/bin/env bash
# jfrog-login-register-session.sh — Verify a JFrog server and start a web login session
#
# Pings the server, generates a session UUID, and registers it with
# the Access API for browser-based authentication (bootstrap HTTP via
# `jf api --url`).
#
# Usage:
#   bash jfrog-login-register-session.sh <platform-url>
#
# Arguments:
#   platform-url  — Full JFrog Platform URL (e.g. https://mycompany.jfrog.io)
#
# Output (stdout, one key=value per line):
#   SESSION_UUID=<uuid>
#   VERIFY_CODE=<last 4 chars of uuid>
#
# Exit codes:
#   0 — Session registered successfully
#   1 — Missing arguments or prerequisites
#   2 — Server not reachable (ping failed)
#   3 — Session registration request failed

set -euo pipefail

# Parameter expansion so a stripped PATH (tests) still resolves this file.
_this="${BASH_SOURCE[0]}"
SCRIPT_DIR="${_this%/*}"
[[ "$SCRIPT_DIR" == "$_this" ]] && SCRIPT_DIR="."
unset _this

JFROG_PLATFORM_URL="${1:-}"

if [[ -z "$JFROG_PLATFORM_URL" ]]; then
  echo "Usage: bash $0 <platform-url>" >&2
  exit 1
fi

JFROG_PLATFORM_URL="${JFROG_PLATFORM_URL%/}"

if ! command -v jf &>/dev/null; then
  echo "ERROR: jf is not installed" >&2
  exit 1
fi

# shellcheck source=lib/jf-api-http-status.sh
. "$SCRIPT_DIR/lib/jf-api-http-status.sh"

# `jf api` was added in JFrog CLI 2.100.0 and every request below depends on it.
# Check it explicitly: on an older CLI the ping fails with an unknown-command
# error that carries no HTTP status, which would otherwise be reported as an
# unreachable server and send the user looking at the network instead of the CLI.
if ! jf api --help >/dev/null 2>&1; then
  echo "ERROR: this jf ($(jf --version 2>/dev/null || echo 'version unknown')) does not support 'jf api'," >&2
  echo "which this login flow requires (JFrog CLI 2.100.0 or later)." >&2
  echo "Upgrade the JFrog CLI, then retry. See references/jfrog-cli-install-upgrade.md." >&2
  exit 1
fi

if ! command -v uuidgen &>/dev/null; then
  echo "ERROR: uuidgen is not installed" >&2
  exit 1
fi

TMPERR="$(mktemp)"
trap 'rm -f "$TMPERR"' EXIT

# Verify server is reachable (unauthenticated ping).
# Flags before the path — jf api 2.120+ treats `jf api <path> --url …` as
# extra positional args ("Wrong number of arguments").
if ! jf api --url "$JFROG_PLATFORM_URL" /artifactory/api/system/ping >/dev/null 2>"$TMPERR"; then
  PING_CODE=$(jf_api_http_status "$TMPERR")
  echo "ERROR: Server not reachable at ${JFROG_PLATFORM_URL} (HTTP ${PING_CODE})" >&2
  exit 2
fi

# Generate session UUID
SESSION_UUID=$(uuidgen | tr '[:upper:]' '[:lower:]')
VERIFY_CODE=${SESSION_UUID: -4}

# Register the session with the Access API
: >"$TMPERR"
if ! jf api --url "$JFROG_PLATFORM_URL" \
  -X POST \
  -H "Content-Type: application/json" \
  -d "{\"session\":\"${SESSION_UUID}\"}" \
  /access/api/v2/authentication/jfrog_client_login/request >/dev/null 2>"$TMPERR"; then
  REG_CODE=$(jf_api_http_status "$TMPERR")
  echo "ERROR: Session registration failed (HTTP ${REG_CODE})" >&2
  exit 3
fi

echo "SESSION_UUID=${SESSION_UUID}"
echo "VERIFY_CODE=${VERIFY_CODE}"
