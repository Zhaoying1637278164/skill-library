# PostgreSQL → DSQL Type Mapping

Semantic type conversion guidance that complements `dsql_lint`. The linter handles
mechanical detection (SERIAL, arrays); this file covers COLLATE rules, precision
behavior, and storage decisions that require architectural choices.

For the authoritative list of supported types, run `dsql_lint(sql=..., fix=true)` or
consult [DSQL Supported Data Types](https://docs.aws.amazon.com/aurora-dsql/latest/userguide/working-with-postgresql-compatibility-supported-data-types.html).

## Table of Contents

1. [COLLATE — C Collation Rules](#collate--c-collation-rules)
2. [NUMERIC Precision and Scale](#numeric-precision-and-scale)
3. [JSON and JSONB](#json-and-jsonb)
4. [Types Mapped to TEXT by dsql_lint](#types-mapped-to-text-by-dsql_lint)
5. [Quick Conversion Template](#quick-conversion-template)

---

## COLLATE — C Collation Rules

DSQL uses C collation database-wide. Per-column `COLLATE` clauses are **not** supported —
`CREATE TABLE t (name varchar COLLATE "C")` returns error `COLLATE clause not supported`.

`dsql_lint(fix=true)` auto-strips explicit `COLLATE` clauses (rule `collation`, fix status `fixed`).

**Application-visible consequences of C collation:**

- `ORDER BY text_col` sorts by raw byte value (uppercase before lowercase, accented characters after ASCII)
- `LIKE 'abc%'` works correctly for ASCII prefixes
- Non-ASCII ordering: `ä` sorts after `z`, not after `a` as in locale-aware collations
- Use `lower(col)` for case-insensitive comparisons

```sql
-- PostgreSQL (en_US.UTF-8): apple, Banana, cherry
-- DSQL (C collation):       Banana, apple, cherry
SELECT name FROM items ORDER BY name;

-- Case-insensitive sort:
SELECT name FROM items ORDER BY lower(name);
```

**Migration action:** Remove all explicit `COLLATE "C"` clauses (the linter handles this).
Warn users that ORDER BY behavior changes for mixed-case or non-ASCII data.

---

## NUMERIC Precision and Scale

DSQL accepts PostgreSQL's bounds for explicitly declared `NUMERIC(p,s)`: precision `p` **MUST**
be from 1 through 1000, and scale `s` **MUST** be from -1000 through 1000. Scale **MAY**
exceed precision or be negative.

A bare `NUMERIC` defaults to `NUMERIC(18,6)` in DSQL; it does not retain PostgreSQL's
unconstrained `NUMERIC` behavior. During migration, you **MUST** choose explicit `(p,s)` bounds
when source values may not fit that default.

Preserve valid explicit `NUMERIC(p,s)` declarations during migration; no DSQL-specific narrowing
is required:

```sql
CREATE TABLE measurements (
  exact_fraction NUMERIC(1000,1000),
  lower_bound_scale NUMERIC(1,-1000),
  rounded_thousands NUMERIC(10,-3),
  fractional_only NUMERIC(3,5)
);
```

**MONEY type:** Convert to `numeric(19,4)` — preserves monetary precision.

---

## JSON and JSONB

Both `json` and `jsonb` are storable column types in DSQL. Prefer `jsonb` for queryable
structured data — it stores parsed binary form, is faster for `->`/`->>`/`@>` operators, and
deduplicates keys. Use `json` only when you need to preserve exact input formatting and key
ordering.

| PostgreSQL Type | DSQL Column Type | Notes                                                                |
| --------------- | ---------------- | -------------------------------------------------------------------- |
| JSON            | json or jsonb    | Prefer `jsonb` for queryable data; keep `json` if exact text matters |
| JSONB           | jsonb            | Direct equivalent                                                    |

```sql
CREATE TABLE config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settings jsonb,
  raw_payload jsonb
);

SELECT settings -> 'key' FROM config;
SELECT settings @> '{"a":1}' FROM config;
SELECT settings ? 'key' FROM config;
```

**Arrays:** DSQL does not support array column types (e.g. `text[]`, `int[]`). Serialize
arrays as `jsonb` and use `jsonb_array_elements_text(col)` to expand at query time.

---

## Types Mapped to TEXT by dsql_lint

`dsql_lint` maps these types to TEXT. Use runtime casts for type-specific operations:

| Type Category           | Runtime Alternative                                       |
| ----------------------- | --------------------------------------------------------- |
| INET/CIDR/MACADDR       | Cast `::inet` at query time for network operations        |
| TSVECTOR/TSQUERY        | Use OpenSearch/Elasticsearch for full-text search         |
| Geometric (POINT, etc.) | Store lat/lng as separate numeric columns, or use geohash |
| XML                     | Parse in application layer                                |
| BIT/VARBIT              | Use application logic for bit operations                  |

---

## Quick Conversion Template

```sql
-- Before (PostgreSQL)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    name TEXT,
    balance MONEY,
    preferences JSONB,
    tags TEXT[],
    ip_address INET,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- After (DSQL) — run dsql_lint first for SERIAL/array/index fixes;
-- foreign keys are preserved, then follow references/foreign-keys.md
CREATE TABLE users (
    id bigint GENERATED BY DEFAULT AS IDENTITY (CACHE 1) PRIMARY KEY,
    email varchar(255) NOT NULL,
    name text,
    balance numeric(19,4),
    preferences jsonb,
    tags jsonb,          -- array column types not supported; serialize as jsonb
    ip_address text,
    created_at timestamptz DEFAULT now()
);
```
