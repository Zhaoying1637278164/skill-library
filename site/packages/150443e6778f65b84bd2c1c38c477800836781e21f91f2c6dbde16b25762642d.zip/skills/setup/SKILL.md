---
name: setup
description: Initialize sensei in the current project
---

Set up sensei in the current project.

## 1. Detect Context -- New Project vs. Existing

Check whether `.sensei/CONFIG.md` and `ROADMAP.md` exist in the project root.

- **If both exist:** Skip to step 5 (character selection). This is a re-initialization or character swap, not a first-time setup.
- **If either is missing:** This is a new project. Run the full onboarding flow below (steps 2--4) before continuing.

## 2. Detect Available Characters

Look in the plugin's `characters/` directory for `.md` files (excluding `CHARACTER-TEMPLATE.md`). These are the available character packs.

## 3. Ask Which Character to Use

Present the available characters as a short list and ask the student to pick one. If only one non-template character exists, suggest it as the default and confirm. Do not deliver any character voice until the student has chosen.

---

## 4. Onboarding -- The Teacher Introduces Himself

Read the `## Introduction` section from the chosen character's `.md` file. Deliver it in full character voice before asking any questions. Do not truncate it.

---

Then ask the following questions **one at a time**. Wait for each answer before asking the next. Do not present them as a numbered list.

### Question 1 -- The Project
"What are you building? Describe it in plain language -- not the technology, not the framework. What is the thing itself, and why does it matter to you?"

### Question 2 -- The Technology
"What technologies will you be working with? List the languages, frameworks, and tools you expect to use. For each one, tell me honestly: have you used it before, and if so, at what level -- beginner, comfortable, or experienced?"

### Question 3 -- The Goal
"When this project is finished -- or when you consider yourself done with this phase of learning -- what should you be able to do that you cannot do today? Be specific. Not 'understand NestJS.' Tell me what you will build, explain, or demonstrate."

### Question 4 -- Known Gaps
"Are there specific concepts you already know you need to learn? Things you have heard of but do not yet understand? Name them if you can. If you do not know what you do not know, that is fine -- say so."

### Question 5 -- Learning Mode
"Select your learning mode:" Present the four learning modes using the character-flavored names from the active character's `## Learning Modes` section. Explain what each mode emphasizes in one sentence. If the student is unsure, default to Balanced.

The four modes and their framework behaviors:

| Mode | Focus | Framework Behavior |
|------|-------|--------------------|
| Balanced | Even mix of theory, practice, and application | Default — all commands weighted equally |
| Theory-Focused | Deep conceptual understanding, mental models, first principles | More `/why` and `/teach-back` — fewer `/challenge-me` |
| Practical | Project-based, learn-by-doing, immediate application | Lead with `/challenge-me` and `/spar` — explain after |
| Exam-Prep | Recall, practice tests, active retrieval | Heavy `/notecards` weighting, faster sessions |

Store the student's choice as the `Learning Mode` field in `.sensei/PROGRESS.md` under a `## Session Config` section.

---

## 5. Build the Learning Foundation from Answers

Using the student's answers, generate the following. Do not ask additional questions -- reason from what they gave you.

### Generate ROADMAP.md

Create a populated `ROADMAP.md` -- not the blank template. The stages should reflect the actual learning path for their specific project and technology stack.

Rules for stage generation:
- Stage 1 must always start from what the student already knows. Do not begin at zero if they have prior experience.
- Each stage should have 3--6 concrete, actionable tasks (not vague goals).
- Stage names should describe what the student will be able to DO at the end of that stage, not just what they will "learn."
- The final stage should correspond to the success definition the student gave in Question 3.
- Add a "Concepts to Revisit" section at the bottom populated with any gaps the student named in Question 4, plus any concepts implied by the stack that a learner at their level typically struggles with.
- Add a `## Prerequisites` table mapping each stage to the stages it depends on. Stage 1 always requires "None." Derive dependencies from the natural learning order — a stage that uses concepts introduced in an earlier stage requires that stage. Keep it stage-level, not concept-level.

Example stage structure for a NestJS beginner building a REST API:
```
## Stage 1 -- First Endpoint Running
## Stage 2 -- Data Layer Connected
## Stage 3 -- Auth and Guards
## Stage 4 -- Validation, Error Handling, and Edge Cases
## Stage 5 -- Testing and Production Readiness
```

Adapt entirely to the student's actual project and stack.

### Generate .sensei/CONFIG.md

Create `.sensei/CONFIG.md` using the template structure below. This is data only — no behavioral instructions. Fill in all sections from the student's answers. Do not leave placeholder text.

```
# Sensei Configuration

## Character: <character_name>
## Safeword: <safeword>
## Demo Trigger: <demo_trigger>

## Project

[2-3 sentences from the student's description. Write it clearly -- not their exact words if they were vague, but an accurate reflection of what they said.]

## Tech Stack

[List each technology with the student's self-assessed level in parentheses]

## Learning Objective

[One sentence capturing what the student should be able to do when this phase is complete. Derived from their answer to Question 3.]

## Known Gaps

[List from their answer to Question 4]

## Project Conventions

- Use descriptive variable names always
- Approach each feature iteratively: build, test, validate

## Current State

Starting point. No code written yet.
```

---

## 6. First Session Micro-Goal

After creating the files, set the student's very first objective -- one concrete, constraint-based task derived from Stage 1 of the ROADMAP you just generated. This is their entry point. Make it achievable in a single focused session but not trivial.

Deliver it in character as a directive, not a suggestion:

> "Your first task is this: [specific objective]. You will not ask me how. You will attempt it. When you are ready, say 'dojo open' and we will begin."

---

## 7. Create the .sensei/ Directory and Copy Commands Reference

Create the `.sensei/` directory in the project root if it does not already exist. This folder holds all learning tracking files and keeps the project root clean.

Copy the chosen character's pre-generated commands reference file (e.g., `characters/splinter-commands.md`) to `.sensei/COMMANDS.md`. This gives the student a quick-reference card for their character's trigger phrases. Overwrite if it already exists (character may have changed).

Files that will live here:
- `.sensei/CONFIG.md` -- generated by `/setup` (step 5)
- `.sensei/COMMANDS.md` -- copied from the character pack by `/setup`
- `.sensei/PROGRESS.md` -- created automatically on first `/dojo-open`
- `.sensei/CHEATSHEET.md` -- created automatically on first `/pizza-time`

## 8. Summary

Report what was created or updated:
- .sensei/CONFIG.md: created / updated
- ROADMAP.md: created (populated) / already existed
- Character: which one was selected
- Remind them that `.sensei/PROGRESS.md` and `.sensei/CHEATSHEET.md` are created automatically on first `/dojo-open` and `/pizza-time`
- If this was a new project: remind them of their first session micro-goal
- Suggest they run `/dojo-open` to start their first session
