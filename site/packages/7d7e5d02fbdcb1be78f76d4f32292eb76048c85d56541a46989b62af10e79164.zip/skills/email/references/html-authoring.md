# Import-HTML schreiben — die zwingenden Regeln

Diese Regeln gelten, **wann immer du HTML erzeugst, das durch `email-content-import` geht**: beim
Bearbeiten von vorhandenem E-Mail-HTML und wenn du fremdes HTML importfähig machst. Sie sind nicht optional — der Importer verwandelt nur
HTML, das sie einhält, verlässlich in bearbeitbare Bausteine zurück.

Für den anderen Weg — eine bestehende E-Mail über die Bausteinwerkzeuge ändern — gelten sie
**nicht**: dort wird nichts konvertiert, und was ein Baustein annimmt, steht in `blocks/`.

Generiere ausschließlich E-Mail-HTML. Die HTML-Importer-API des Editors ist für E-Mail-Templates
optimiert, nicht für Landingpages oder allgemeine Webseiten.

## Inhalt

- 1. Grundgerüst
- 2. Grid-System: Zeilen und Spalten
- 3. Block-Klassen des Editors
- 4. CSS, Bilder und Ressourcen
- 5. KlickTipp-Variablen: Dynamische Inhalte
- 6. Pflicht-Footer
- 7. Valides HTML
- 8. Import-Qualitätscheck

## 1. Grundgerüst

Verwende ausnahmslos dieses Basis-Gerüst. Die HTML-Importer-API des Editors verlangt valides HTML mit
`DOCTYPE`, `html`, `body` und einem expliziten `<meta charset="UTF-8">` im `head`. Das
`http-equiv`-Meta darf zusätzlich enthalten sein, ersetzt aber nicht das kurze UTF-8-Meta-Tag.

```html
<!DOCTYPE html>
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" lang="de">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>*{box-sizing:border-box}body{margin:0;padding:0}</style>
</head>
<body class="body" style="margin:0;padding:0;background-color:#ffffff">
  <table class="nl-container" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#ffffff">
    <tbody>
      <tr>
        <td align="center">
          </td>
      </tr>
    </tbody>
  </table>
</body>
</html>
```

## 2. Grid-System: Zeilen und Spalten

- Jede Zeile muss in folgendem Format stehen:

```html
<table class="row-content stack" align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:600px;margin:0 auto">
```

- Spalten in der Zeile müssen als `<td>` mit der Klasse `column` und `column-[1-6]` definiert werden.
- Unterstütze bis zu 6 Spalten pro Zeile.
- Steuere Spaltenbreiten über `width`, z. B. `width="50%"`, `width="33.3333%"`, `width="25%"`.
- Nutze `stack` auf `row-content`, damit Spalten auf Mobilgeräten responsiv umbrechen können.
- Nutze die Klasse `pad` auf inneren `<td>`-Elementen, wenn Padding im KlickTipp-Editor
  steuerbar bleiben soll.
- Für leere Spalten immer einen `empty_block` einfügen, damit die Grid-Struktur für
  Drag-and-Drop erhalten bleibt.
- Beispiel:

```html
<td class="column column-1" width="100%" style="font-weight:400;text-align:left;vertical-align:top;border:0">
```

Wichtige Layout-Klassen:

- `nl-container`: äußerster Haupt-Wrapper der gesamten E-Mail.
- `row`: optionale äußere Zeilenklasse.
- `row-content stack`: innere horizontale Zeile mit responsivem Stacking.
- `column column-[1-6]`: Spalten innerhalb einer Zeile.
- `pad`: innerer Abstand eines Blocks, möglichst auf dem inneren `<td>`.

Layout-Sicherheitsregeln:

- Für importkritische Tests bevorzugt 1- oder 2-Spalten-Layouts verwenden.
- 3-Spalten-Layouts nur mit sehr kurzen Texten verwenden.
- 4- bis 6-Spalten-Layouts nur für sehr kleine, einfache Elemente verwenden; keine großen Zahlen,
  langen Labels oder mehrzeiligen Texte in engen Spalten.
- Wenn Labels wie "Import", "Segment" oder "Automatisierung" umbrechen könnten, auf 2 Spalten
  reduzieren oder die Inhalte untereinander setzen.
- Keine Schriftgrößen verwenden, die in engen Spalten zu harten Umbrüchen führen. In schmalen
  Spalten maximal ca. 14–18px für Text oder Zahlen nutzen.

## 3. Block-Klassen des Editors

Verpacke jedes inhaltliche Element in eine eigene `<table>` mit der exakten Editor-Block-Klasse, da es
sonst nicht editierbar ist.

Generiere nur statisches E-Mail-HTML. Kein JavaScript, keine dynamisch gerenderten Inhalte, keine
interaktiven Skripte und keine Nicht-HTML-E-Mail-Formate wie `.eml`.

Verfügbare Content-Blocks:

- `heading_block`: Überschriften mit `h1`, `h2`, `h3` usw.
- `paragraph_block`: Normaler Fließtext und Textabsätze.
- `image_block`: Bilder und animierte GIFs; `src` muss eine absolute öffentliche HTTPS-URL sein.
- `button_block`: Call-to-Action-Buttons. Wenn robuste E-Mail-Kompatibilität gefordert ist,
  optional mit Microsoft-Outlook-VML innerhalb des Blocks arbeiten.
- `video_block`: Video-Link-Block mit Vorschaubild und Play-Button-Logik; nur mit öffentlicher
  Video-/Preview-URL nutzen.
- `list_block`: Geordnete Listen mit `<ol>` und ungeordnete Listen mit `<ul>`.
- `table_block`: Klassische Daten-Tabellen.
- `social_block`: Social-Media-Icon-Leisten, z. B. Facebook, X, Instagram, LinkedIn.
- `menu_block`: Navigationsmenüs, z. B. Header-Links. Nur sparsam verwenden, weil Menüs laut
  Editor-Dokumentation beim HTML-Import nicht vollständig unterstützt sind.
- `icons_block`: Icon-Sammlungen oder kleine Icon-Grids.
- `divider_block`: Horizontale Trennlinien. Nur bei Bedarf verwenden, weil Dividers laut
  Editor-Dokumentation beim HTML-Import nicht vollständig unterstützt sind.
- `spacer_block`: Vertikaler Leerraum oder unsichtbare Abstände.
- `html_block`: Benutzerdefinierter HTML/CSS-Code, z. B. QR-Codes oder simple statische
  Spezialelemente. Kein JavaScript und keine dynamischen Skripte verwenden.
- `empty_block`: Pflicht für leere Spalten, damit die Grid-Struktur im Drag-and-Drop-Editor
  stabil bleibt.

Import-Sicherheitsstufen für Editor-Elemente:

- Sehr gut per HTML-Import geeignet: `heading_block`, `paragraph_block`, `image_block`,
  `button_block`, `list_block`, `spacer_block`, einfache `empty_block`-Platzhalter.
- Meist importierbar, aber nicht immer als identisches natives Widget: `table_block`,
  `social_block`, `icons_block`, `html_block`, statische GIPHY-/Sticker-GIFs als `image_block`.
- Mit Vorsicht per HTML-Import verwenden: `video_block`, `divider_block`, `menu_block`.
- Ausgeschlossen für diese Skill-Version: KI-Copywriter, Countdown und VCard. Diese Elemente
  nicht generieren und nicht per HTML-Import simulieren.
- GIPHY und Sticker können als KlickTipp-Add-ons tendenziell funktionieren. Per HTML-Import
  aber nur als fertige statische GIF-/Sticker-Bild-URL verwenden, nicht als natives
  Add-on-Widget erwarten.
- Die reine Klasse wie `video_block` oder `icons_block` garantiert nicht, dass der HTML Importer
  daraus ein vollwertiges natives Editor-Widget baut. Der Importer mappt vorhandenes HTML auf
  naheliegende Strukturen; er erstellt keine komplexe Widget-Konfiguration.
- Für "bullet proof" Importvorlagen nur die sehr gut geeigneten Elemente verwenden. Spezielle
  Editor-Elemente anschließend im KlickTipp-Editor ergänzen.

FAQ-Abgleich für Testvorlagen:

- Muss funktionieren und soll aktiv getestet werden: valides statisches E-Mail-HTML mit
  `DOCTYPE`, `html`, `body`, `<meta charset="UTF-8">`, Inline-CSS, öffentlich erreichbaren
  Bildern/Ressourcen, Text, Titel, Bild, Button, einfache Listen, einfache Spalten und Spacer.
- Soll aktiv getestet werden, aber mit erwartbarer Nachbearbeitung: Tabellen, Social-Links,
  einfache Icon-/Badge-Abschnitte, statische HTML-Boxen, GIPHY-/Sticker-GIFs als normale
  Bildmodule.
- Nicht als stabilen HTML-Import erwarten: Landingpage-HTML, dynamisch per JavaScript erzeugtes
  HTML, private/intern gehostete Ressourcen, Background-Images, Divider, Menüs, unsupported Tags
  mit komplexem Verhalten.
- Merge Tags und dynamische Inhalte werden beim Import nicht interpretiert oder
  gemappt. Sie dürfen für KlickTipp als statischer Text oder `href` enthalten sein und müssen
  nach Import/Speichern im KlickTipp-Kontext verifiziert werden.
- Unsupported Tags brechen den Import nicht zwingend, können aber unvorhersehbar oder suboptimal
  gemappt werden. Für Team-Tests solche Elemente bewusst als Grenzfall kennzeichnen.

Beispiele für Block-Wrapper:

Text:

```html
<table class="paragraph_block block-1" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Überschrift:

```html
<table class="heading_block block-2" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Bild:

```html
<table class="image_block block-3" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Bilder benötigen absolute HTTPS-URLs.

Bild- und Video-Vorschaubilder dürfen keine reinen Placeholder mit Sonderzeichen im Text sein.
Verwende ASCII-Text oder echte Preview-Bilder. Unicode-Symbole wie Play-Icons können in
generierten Placeholder-Bildern oder im Import als Fragezeichen erscheinen.

Für robuste Video-Imports bevorzugt ein verlinktes `image_block` mit echtem HTTPS-Vorschaubild
verwenden und den Video-Link in `href` setzen. `video_block` nicht für bullet-proof
Importvorlagen verwenden, außer der Fall wurde in KlickTipp bereits
verifiziert.

Tabellen können beim HTML-Import in mehrere Textmodule zerlegt werden. Die Inhalte und
Platzhalter bleiben dabei erhalten, aber es ist nicht garantiert, dass daraus ein vollwertig
natives `table_block`-Widget im Editor entsteht. Für robuste Vorlagen Tabellen einfach halten und
nur für echte Datenübersichten verwenden.

GIPHY- und Sticker-Regeln:

- Für den HTML-Import keine GIPHY-API-URL wie `https://api.giphy.com/v1/gifs/random?...` direkt
  in `img src` verwenden.
- Wenn GIPHY genutzt werden soll, muss die API vor der HTML-Ausgabe aufgelöst werden. Danach nur
  eine direkte HTTPS-Bild-URL aus dem Response-Objekt verwenden, z. B. aus
  `data.images.original.url`, `data.images.fixed_width.url` oder einer anderen passenden
  `images`-Variante.
- GIPHY Random nutzt `GET /v1/gifs/random`; Sticker Random nutzt `GET /v1/stickers/random`. Beide
  benötigen einen API-Key und können optional u. a. über `tag` und `rating` eingeschränkt werden.
- API-Keys niemals im finalen E-Mail-HTML ausgeben.
- Für robuste Newsletter bevorzugt kuratierte, markenkonforme GIF-/Sticker-URLs oder native
  GIPHY-/Sticker-Add-ons im Editor verwenden.
- GIPHY-/Sticker-Bilder immer als `image_block` mit absoluter öffentlicher HTTPS-URL einbauen und
  einen sinnvollen `alt`-Text setzen.
- Wenn kein bereits verifizierter GIF-/Sticker-Link vorhanden ist, keinen zufälligen
  GIPHY-Inhalt erfinden. Stattdessen einen statischen Platzhalter oder einen normalen Bildblock
  nutzen.

GIPHY-/Sticker-Testfälle:

- Test A: Ein normales GIF als `image_block` importieren und prüfen, ob es als Bildmodul
  erscheint, sichtbar bleibt und animiert.
- Test B: Einen Sticker/GIF mit transparenter oder stickerartiger Optik als `image_block`
  importieren und prüfen, ob Transparenz/Animation erhalten bleibt.
- Test C: Optional das native GIPHY-/Sticker-Add-on im Editor manuell verwenden und separat
  dokumentieren. Dies ist kein HTML-Import-Test, sondern Add-on-Verhalten im Editor.
- Nicht testen: API-Key im HTML, API-Endpoint als `img src`, JavaScript-basierte GIPHY-Auswahl
  im E-Mail-HTML.

Button:

```html
<table class="button_block block-4" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Trennlinie nur verwenden, wenn sie wirklich benötigt wird. Die Editor-Dokumentation nennt Dividers als
nicht vollständig unterstützt beim Import. Wenn eine optische Trennung reicht, bevorzuge Padding,
Abstand oder eine einfache Border an einem bestehenden editierbaren Block. Wenn ein Divider
explizit gewünscht ist, verwende:

```html
<table class="divider_block block-5" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Spacer:

```html
<table class="spacer_block block-6" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Liste:

```html
<table class="list_block block-7" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Tabelle:

```html
<table class="table_block block-8" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Social:

```html
<table class="social_block block-9" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

Leere Spalte:

```html
<table class="empty_block block-1" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation">
```

## 4. CSS, Bilder und Ressourcen

- Verwende vor allem Inline-CSS direkt an den Elementen, die importiert werden sollen.
- CSS im `<style>`-Tag nur für minimale globale Defaults nutzen.
- Keine externen Stylesheets verwenden. Externes CSS kann nur funktionieren, wenn es
  öffentlich gehostet ist, ist aber nicht garantiert.
- Bilder und andere Ressourcen müssen öffentlich im Internet erreichbar sein. Keine privaten,
  lokalen, passwortgeschützten oder Intranet-only-URLs verwenden.
- Bilder werden beim Import nicht in den Dateimanager des Editors hochgeladen, sondern von der
  Original-URL referenziert.
- Keine Background-Images für wichtige Inhalte verwenden. Die Editor-Dokumentation nennt Background-Images
  als nicht vollständig unterstützt beim Import.
- Keine komplexen Navigationsstrukturen generieren. Ein einfaches `menu_block` nur verwenden, wenn
  ein Menü ausdrücklich gewünscht ist, weil Menüs laut Editor-Dokumentation nicht vollständig unterstützt
  sind.
- Der Importer mappt nur vorhandene Struktur und Styles. Er verbessert keine Gestaltung und
  ergänzt keine fehlenden Styles.
- Kleine manuelle Designkorrekturen nach dem Import können nötig sein. Generiere deshalb einfache,
  robuste Tabellenstrukturen statt komplexer Sonderlayouts.
- Der HTML-Import ist nicht identisch mit dem nativen JSON-Format des Editors. Nicht jedes Element aus der
  linken Editor-Leiste ist sinnvoll per HTML vorzuerzeugen.
- Wenn ein Element Plugin- oder Editor-Logik braucht, z. B. KI-Copywriter, Countdown oder VCard,
  im HTML maximal einen statischen Platzhalter oder Hinweisbereich erzeugen und das eigentliche
  Element nach dem Import im Editor einfügen.
- GIPHY und Sticker sind die Ausnahme unter den Add-on-nahen Elementen: Als natives Add-on nicht
  per HTML erzwingen, aber als bereits aufgelöste, öffentliche direkte HTTPS-Bild-URL aktiv per
  `image_block` testen und generieren.

## 5. KlickTipp-Variablen: Dynamische Inhalte

Nutze für Personalisierung und Links ausschließlich die KlickTipp-Syntax. Erfinde keine eigenen
Platzhalter.

Verwende bevorzugt diese bekannten Stammsatz-Felder und Systemlinks:

Personenbezogene Daten:

- `%Subscriber:CustomFieldFirstName%` für Vorname
- `%Subscriber:CustomFieldLastName%` für Nachname
- `%Subscriber:CustomFieldBirthday%` für Geburtstag
- `%Subscriber:CustomFieldAge%` für Alter

Kontaktdaten:

- `%Subscriber:EmailAddress%` für E-Mail-Adresse
- `%Subscriber:CustomFieldPhone%` für Telefon allgemein
- `%Subscriber:CustomFieldMobilePhone%` für Telefon mobil
- `%Subscriber:CustomFieldPrivatePhone%` für Telefon privat
- `%Subscriber:CustomFieldFax%` für Fax
- `%Subscriber:CustomFieldWebsite%` für Website oder URL

Adressdaten:

- `%Subscriber:CustomFieldStreet1%` für Straße 1
- `%Subscriber:CustomFieldStreet2%` für Straße 2
- `%Subscriber:CustomFieldZip%` für Postleitzahl
- `%Subscriber:CustomFieldCity%` für Stadt
- `%Subscriber:CustomFieldState%` für Bundesland
- `%Subscriber:CustomFieldCountry%` für Land

Unternehmensdaten und Sales:

- `%Subscriber:CustomFieldCompanyName%` für Firma
- `%Subscriber:CustomFieldLeadValue%` für Lead-Wert

Technische Subscriber-IDs:

- `%Subscriber:SubscriberID%` für interne System-ID
- `%Subscriber:SubscriberKey%` für eindeutigen Subscriber-Schlüssel
- `%Subscriber:FullContact%` für den vollständigen Kontakt

Abonnement- und E-Mail-Status:

- `%Subscriber:OptInDate%` für Datum der Anmeldung
- `%Subscriber:SubscriptionStatus%` für aktuellen Abo-Status
- `%Subscriber:SubscriptionIP%` für IP-Adresse bei Anmeldung
- `%Subscriber:SubscriptionDate%` für Zeitpunkt der Anmeldung
- `%Subscriber:UnsubscriptionDate%` für Zeitpunkt der Abmeldung
- `%Subscriber:UnsubscriptionIP%` für IP-Adresse bei Abmeldung
- `%Subscriber:BounceType%` für Bounce-Art

SMS-Eigenschaften:

- `%Subscriber:SubscriptionSMS%` für Handynummer für SMS
- `%Subscriber:SMSSubscriptionStatus%` für SMS-Abo-Status
- `%Subscriber:SMSSubscriptionDate%` für SMS-Anmeldedatum
- `%Subscriber:SMSUnsubscriptionDate%` für SMS-Abmeldedatum
- `%Subscriber:SMSBounceType%` für SMS-Bounce-Grund

Funktionale Systemlinks für `href` und Buttons:

- `%Link:WebBrowser%` für E-Mail im Browser öffnen
- `%Link:SubscriberInfo%` für gesetzliche Selbstauskunft
- `%Link:SubscriberUpdate%` für Aktualisierung der eigenen Daten
- `%Link:ChangeEmailAddress%` für Änderung der E-Mail-Adresse
- `%User:AffiliateURL%` für persönlichen Affiliate-Link des Users
- `%Link:NoTrack(URL)%` für Links ohne Klick-Tracking, z. B.
  `%Link:NoTrack(https://klicktipp.com)%`

Allgemeine Custom Fields nur verwenden, wenn der User den exakten Feldnamen oder die ID vorgibt:

- Muster: `%Subscriber:CustomField[NAME]%`

Link-Regeln:

- Systemlinks immer direkt in `href="..."` oder als Button-URL verwenden.
- Normale externe Links in Buttons oder Textlinks dürfen direkt als `https://...` verwendet
  werden, sofern Tracking gewünscht ist.
- Für Links ohne Klick-Tracking immer `%Link:NoTrack(https://example.com)%` verwenden.
- Keine frei erfundenen Link-Platzhalter wie `{{unsubscribe}}`, `[unsubscribe]` oder
  `%Unsubscribe%` verwenden.
- Keine leeren `href`-Attribute ausgeben. Wenn kein Ziel bekannt ist, einen passenden
  KlickTipp-Systemlink oder eine realistische absolute HTTPS-URL verwenden.

Der Importer interpretiert und mappt Merge Tags und dynamische Inhalte beim HTML-Import nicht. Für
KlickTipp dürfen diese Variablen trotzdem als statischer Text oder `href` im HTML stehen, müssen
nach dem Import aber im KlickTipp-Editor gespeichert und verifiziert werden.

## 6. Pflicht-Footer

Jede generierte E-Mail muss am Ende einen Paragraph-Block enthalten, der die gesetzlichen
KlickTipp-Pflichtvariablen beinhaltet. Ohne diese schlägt die spätere Speicherung fehl.

Zwingend integrieren:

- `%User:Signature%`
- `%Link:SubscriberInfo%` als `href`
- `%Link:Unsubscribe%` als `href`

Empfohlen im Footer, wenn passend:

- `%Link:SubscriberUpdate%` als Link zum Aktualisieren der Daten
- `%Link:ChangeEmailAddress%` als Link zum Ändern der E-Mail-Adresse
- `%Link:WebBrowser%` als Link zur Browseransicht, meist im Preheader oder Header

Beispiel:

```html
<p>%User:Signature%<br><a href="%Link:SubscriberInfo%">Selbstauskunft</a> | <a href="%Link:Unsubscribe%">Abmelden</a></p>
```

## 7. Valides HTML

Die Ausgabe ist ausnahmslos valides, wohlgeformtes HTML. Der Importer parst den Code: ein
struktureller Fehler erzeugt keine Fehlermeldung, sondern stillschweigend falsch verschachtelte,
verschluckte oder nicht mehr editierbare Blöcke.

Struktur:

- Jedes Element wird geschlossen, in der Reihenfolge, in der es geöffnet wurde. Keine überkreuzten
  Tags, kein offenes `<td>`, `<tr>` oder `<table>`.
- Void-Elemente stehen ohne Endtag: `<img>`, `<br>`, `<meta>`, `<hr>`. Kein `</img>`, kein `</br>`.
- Tabellen immer vollständig verschachtelt: `table > tbody > tr > td`. Kein Inhalt direkt in
  `<table>` oder `<tr>`, kein Text außerhalb eines `<td>`.
- Jede Block-Tabelle wird in derselben `<td>` geschlossen, in der sie geöffnet wurde. Keine
  Tabelle über Zellgrenzen hinweg „durchziehen".
- `<p>` und `<h1>`–`<h6>` nicht ineinander verschachteln. `<li>` nur direkt in `<ul>` oder `<ol>`.
- Genau ein `<html>`, ein `<head>`, ein `<body>`. Kein Inhalt zwischen `</head>` und `<body>`.

Attribute:

- Jeder Attributwert steht in doppelten Anführungszeichen. Keine unquotierten Werte, kein Attribut
  zweimal am selben Element.
- `id`-Werte sind eindeutig. `block-[n]`-Nummern innerhalb einer Spalte fortlaufend und nicht
  doppelt.
- Keine Event-Attribute wie `onclick` und kein Skriptinhalt in Attributen.

Zeichen und Entities:

- `&` als `&amp;`, `<` als `&lt;`, `>` als `&gt;` — insbesondere in URLs mit mehreren
  Query-Parametern, also `?utm_source=nl&amp;utm_medium=email`.
- Anführungszeichen innerhalb eines Attributwerts als `&quot;` bzw. `&#39;`.
- Umlaute und Sonderzeichen als echte UTF-8-Zeichen passend zum `<meta charset="UTF-8">`, nicht als
  numerische Entities auf Verdacht und nie als kaputte Mojibake-Sequenz.
- KlickTipp-Variablen bleiben unverändert: `%…%` ist HTML-neutral und wird nicht escaped.

Selbstprüfung vor der Ausgabe:

- Öffnende und schließende Tags durchzählen, vor allem `table`, `tbody`, `tr`, `td`.
- Das gesamte Dokument lesen, nicht nur die geänderten Zeilen. Ein Fragment kann für sich valide
  wirken und die Verschachtelung des Dokuments trotzdem brechen.
- Bei Zweifeln die einfachere Struktur ausgeben, die sicher valide ist, statt eine komplexe, die es
  vielleicht ist.

Beim Bearbeiten gilt das ebenso: war die Vorlage bereits invalide, wird nur die Wohlgeformtheit
minimal repariert — Tag schließen, Verschachtelung geradeziehen, `&` escapen — und die Reparatur
benannt. Das ist eine erzwungene Korrektur, kein Redesign.

## 8. Import-Qualitätscheck

Prüfe vor Ausgabe:

- `DOCTYPE` ist vorhanden.
- `<html>` und `<body>` sind vorhanden.
- `<meta charset="UTF-8">` steht im `head`.
- HTML ist statisch und valide: alle Elemente geschlossen, nichts überkreuzt, jede Tabelle als
  `table > tbody > tr > td` verschachtelt, alle Attributwerte gequotet, `&` in URLs als `&amp;`.
- Alle Bilder nutzen öffentliche absolute HTTPS-URLs.
- Wichtige Styles sind inline.
- Keine externen Stylesheets, kein JavaScript, keine Background-Images, keine komplexen Menüs.
- Jeder Inhaltsblock liegt in einer passenden Editor-Block-Tabelle.
- Leere Spalten enthalten einen `empty_block`.
- Padding-relevante innere Tabellenzellen nutzen möglichst die Klasse `pad`.
- Schmale Mehrspalten-Abschnitte sind auf Umbrüche geprüft; bei Zweifeln 1- oder
  2-Spalten-Layout verwenden.
- Video-Inhalte verwenden ein echtes öffentliches Preview-Bild oder werden als normaler
  Bild-Link umgesetzt.
- Keine editor-nativen Widgets per HTML erzwingen, die nach dem Import besser manuell eingefügt
  werden sollten.
- Der Pflicht-Footer mit `%User:Signature%`, `%Link:SubscriberInfo%` und `%Link:Unsubscribe%` ist
  vorhanden.
- Bei einer Bearbeitung: außerhalb der beauftragten Inhaltsänderungen ist keine Zeile verändert —
  Struktur, Klassen, Attribute und Styles sind identisch zur Vorlage.
- Falls über die HTML-Importer-API getestet wird, muss der Request Body als `text/html`
  gesendet werden.
