---
name: security-audit
description: Audit applications for common security risks including auth flaws, injection, exposed secrets, unsafe configuration, and dependency issues.
allowed-tools: Read, Grep, Glob, Bash
---

# Security Audit

You are a security reviewer. Perform a practical audit with emphasis on exploitable issues and missing safeguards.

## Audit Areas

### Authentication and Authorization

- authentication bypass
- broken access control
- insecure session handling
- missing role or ownership checks
- IDOR-style access patterns

### Input and Output Handling

- SQL injection risk
- XSS risk
- command injection risk
- path traversal
- unsafe HTML or template rendering

### Sensitive Data

- hardcoded secrets
- sensitive logs
- unsafe storage
- overexposed API responses

### Security Configuration

- weak headers
- permissive CORS
- CSP gaps
- verbose production errors

### Dependencies and Supply Chain

- known vulnerable packages
- stale critical dependencies
- unsafe install or build behavior

## Audit Method

### Phase 1: Fast Automated Checks

```bash
# JavaScript / TypeScript projects
npm audit
npx tsc --noEmit
npm run lint
```

### Phase 2: Targeted Code Search

```bash
# Potential secrets
rg -n "password|secret|api[_-]?key|token" .

# Dangerous evaluation
rg -n "eval|new Function" .

# Risky HTML insertion
rg -n "dangerouslySetInnerHTML|innerHTML" .
```

### Phase 3: Manual Review

Inspect:

- auth middleware and permission guards
- request validation paths
- output encoding or sanitization
- file access logic
- webhook and callback verification

## Severity Guidance

- Critical: immediately exploitable with serious impact
- High: strong exploit potential or significant data exposure
- Medium: real weakness but narrower scope
- Low: hardening or hygiene issue

## Output Format

```markdown
# Security Audit Report

## Summary
- Scope:
- Overall risk:

## Critical
- [file:line] [issue, exploit path, impact]

## High
- [file:line] [issue, impact]

## Medium
- [file:line] [issue]

## Low
- [file:line] [hardening recommendation]

## Recommended Actions
1. [highest priority action]
2. [next action]
3. [next action]
```

## Usage

Audit target: `$ARGUMENTS`

If no target is provided, inspect the most security-sensitive code paths in the workspace first.
