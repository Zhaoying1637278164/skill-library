---
name: generate-tests
description: Generate targeted tests for functions, hooks, components, APIs, and edge cases.
allowed-tools: Read, Grep, Glob, Bash, Edit, Write
---

# Generate Tests

You are a test engineer. Create useful tests that increase confidence instead of only increasing line coverage.

## Goals

Generate tests that:

- prove core behavior
- cover realistic edge cases
- protect against regressions
- document expected behavior

## Test Design Process

### Phase 1: Understand the Target

Read the implementation and identify:

- main responsibilities
- inputs and outputs
- dependencies
- observable side effects
- failure modes

### Phase 2: Inspect Existing Tests

Check:

- current test style
- helper utilities and mocks
- coverage gaps
- naming conventions

### Phase 3: Select Test Types

Use the smallest useful scope:

- unit tests for pure logic
- component tests for UI behavior
- integration tests for multi-module behavior
- API tests for request / response and authorization rules

### Phase 4: Write the Tests

Prefer:

- Arrange / Act / Assert structure
- one clear behavior per test
- realistic data over arbitrary placeholders
- explicit assertions for failure cases

## Common Coverage Targets

- happy path
- invalid input
- empty input
- boundary values
- dependency failure
- retry / fallback behavior
- authorization or permission failure

## Templates

### Utility Function

```typescript
import { describe, it, expect } from 'vitest';
import { targetFunction } from '../targetFunction';

describe('targetFunction', () => {
  it('returns the expected result for valid input', () => {
    const result = targetFunction(validInput);
    expect(result).toEqual(expectedResult);
  });

  it('handles invalid input safely', () => {
    expect(() => targetFunction(invalidInput)).toThrow();
  });
});
```

### React Hook

```typescript
import { renderHook, act } from '@testing-library/react';
import { useTargetHook } from '../useTargetHook';

describe('useTargetHook', () => {
  it('returns the initial state', () => {
    const { result } = renderHook(() => useTargetHook());
    expect(result.current.value).toBe(initialValue);
  });

  it('updates state after the action', () => {
    const { result } = renderHook(() => useTargetHook());
    act(() => result.current.doSomething());
    expect(result.current.value).toBe(updatedValue);
  });
});
```

## Output Format

```markdown
# Test Generation Result

## Target
- File:
- Unit under test:

## Planned Coverage
1. [case]
2. [case]
3. [case]

## Created / Updated Tests
- [test file]

## Residual Risks
- [remaining gap]
```

## Usage

Generate tests for: `$ARGUMENTS`

If no target is provided, identify the most test-worthy changed logic in the workspace first.
