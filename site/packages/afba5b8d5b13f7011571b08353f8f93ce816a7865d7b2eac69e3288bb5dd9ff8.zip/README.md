# DrillSpark Workflow Toolkit

Public plugin scaffold for Claude Code official marketplace submission.

This plugin packages a focused set of reusable skills for:

- workflow and business-process analysis
- Mermaid diagram quality checks
- code review
- test generation
- web application security review

## Status

Current status: `submission scaffold`

What is already done:

- plugin root created
- plugin manifest created
- initial public skill set selected
- manifest validation passed
- session-only load passed
- local install / uninstall smoke test passed in the source workspace

What is still required before official submission:

- test install in a clean Claude Code environment
- tighten any skill text that still assumes internal workflows
- submit the plugin to the official marketplace

## Included Skills

- `business-analysis`
- `code-review`
- `generate-tests`
- `mermaid-validator`
- `security-audit`

## Local Validation

From the plugin repository root:

```bash
claude plugin validate .
```

Session-only load:

```bash
claude -p --plugin-dir . -- "List the available plugin skills and summarize each in one line."
```

Direct invocation example:

```text
/drillspark-workflow-toolkit:mermaid-validator Review Mermaid diagrams in the current workspace and report structural issues.
```

If the current workspace already defines skills with the same names, Claude Code may expose this plugin's skills with a namespace prefix such as:

```text
/drillspark-workflow-toolkit:mermaid-validator
```

## Submission Positioning

Recommended public positioning:

- audience: engineering, product, and operations teams
- primary value: repeatable workflows for analysis, review, and implementation support
- differentiator: combines software engineering skills with workflow analysis skills in one package

## License

License: `Apache-2.0`

This plugin scaffold now includes a plugin-scoped Apache 2.0 license file.

Publication assumptions confirmed for this package:

- Apache-2.0 may be used for the plugin package
- DrillSpark branding may be used for the plugin package

Repository:

- `https://github.com/jackasser/drillspark-workflow-toolkit`

Support:

- `https://github.com/jackasser/drillspark-workflow-toolkit/issues`
