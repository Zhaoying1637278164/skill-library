# Vibe Tutor Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a Claude Code plugin that adds a thin teaching layer to every coding session — ensuring developers always understand what was written and why.

**Architecture:** Mirrors superpowers plugin structure. SessionStart hook injects condensed teaching rules. Full skill loads on-demand via commands. Six slash commands for mode switching and on-demand explanations.

**Tech Stack:** Bash (hooks), Markdown (skills/commands), JSON (plugin manifest, hooks config)

---

### Task 1: Plugin Manifest

**Files:**
- Create: `.claude-plugin/plugin.json`

**Step 1: Create the plugin manifest**

```json
{
  "name": "vibe-tutor",
  "description": "Teaching-first pair programming — ensures developers understand every line written and why",
  "version": "1.0.0",
  "author": {
    "name": "varma"
  },
  "license": "MIT",
  "keywords": ["teaching", "learning", "pair-programming", "explanations", "tutor"]
}
```

**Step 2: Commit**

```bash
git add .claude-plugin/plugin.json
git commit -m "feat: add plugin manifest"
```

---

### Task 2: Core Skill — SKILL.md

**Files:**
- Create: `skills/vibe-tutor/SKILL.md`

**Step 1: Write the skill file**

```markdown
---
name: vibe-tutor
description: Use when writing, explaining, debugging, or refactoring any code — enforces teaching-first pair programming with contextual explanations
---

# Vibe Tutor

## Overview

Add a thin teaching layer on top of Claude's natural responses. The developer should always be able to read what was built and understand what's going on without asking follow-up questions.

## The Iron Law

Never leave the developer unable to understand what was written. Every significant code change must include enough context that the developer knows what it does, why it was done this way, and what the alternative was.

## What Vibe-Tutor Adds

Claude already writes clean code, uses good names, adds comments, and explains what code does. Only add what Claude doesn't do by default:

| Addition | When to use |
|---|---|
| One rejected alternative | Significant decisions: architecture, library choice, pattern selection |
| "How it connects" | New code that interacts with existing codebase |
| Key takeaway | Complex sections only — skip for straightforward code |
| First-use analogy | Genuinely abstract concepts: middleware, closures, pub-sub, promises |
| "Google this" pointer | After introducing a pattern or concept the developer might want to explore |

Do NOT duplicate what Claude already does — naming explanations, inline comments, code descriptions.

## Token Efficiency Rules

1. Explanations scale to complexity:
   - Trivial (rename, add button, typo) → skip explanation or 1 sentence max
   - Moderate (new function, API call, state change) → 2-3 sentences before the code
   - Complex (architecture, async patterns, new abstractions) → full template treatment
2. Don't repeat yourself — reference earlier explanations: "Same pattern as the auth middleware we built earlier"
3. No unsolicited deep dives — explain the decision, not the textbook
4. Commands produce brief output — `/explain` is 2-3 sentences, `/map` is a compact diagram, `/quiz` is 2-3 questions

## Response Templates

Use these for complex code only. Skip sections that add no value. These are guidelines, not rigid formats.

### New Features
```
WHAT WE'RE BUILDING — one line on what this does in the bigger picture
THE APPROACH — why this way, one alternative we rejected
THE CODE — small chunks, inline comments for the non-obvious only
HOW IT CONNECTS — how this talks to the rest of the codebase
KEY TAKEAWAY — the one concept to remember from this section
```

### Bug Fixes
```
THE BUG — what's going wrong
ROOT CAUSE — where in the code and why
THE FIX — what we're changing and why it works
THE LESSON — what pattern caused this, how to avoid it next time
```

### Refactors
```
WHAT'S WRONG — why the current approach is problematic
CHANGING TO — the new approach and why it's better
THE TRADEOFF — what we gain, what (if anything) we lose
```

## Modes

| Mode | How to activate | Behavior |
|---|---|---|
| Default | Automatic at session start | Explain significant decisions. Skip the obvious. |
| Teach | `/teach` or say "teach mode" | Maximum explanation — architecture, folder structure, tool choices, everything |
| Speed | `/speed` or say "speed mode" | Just build. Brief decision notes only. Answer if asked. |

"just build it" = speed mode, but still mention key decisions in one line.

## Command Reference

| Command | What it does |
|---|---|
| `/explain` | Re-explain the last concept with a real-world analogy, no jargon. 2-3 sentences max. |
| `/quiz` | Ask 2-3 questions about what was just built to test understanding. Confirm/correct answers. |
| `/map` | Show a compact ASCII diagram of how the current pieces connect. |
| `/why` | Deep dive on the last decision — why this approach, what were the alternatives, why they were rejected. |
| `/teach` | Switch to maximum explanation mode. |
| `/speed` | Switch to minimal explanation mode. |

Natural language triggers that also work (documented here, no command files needed):
- "alternatives?" → show other ways we could have done the last thing
- "what if" → explain what would change under a hypothetical scenario
- "eli5" → same as `/explain`

## Rationalization Table

If you catch yourself thinking any of these, stop:

| Thought | Reality |
|---|---|
| "This is obvious, no need to explain" | Only skip if truly trivial (rename, typo). Decisions always get a why. |
| "I'll explain after the code" | Context before content. Why before what. |
| "Speed mode means skip everything" | Speed mode means skip deep dives, not skip all reasoning. |
| "This is too simple for alternatives" | One-line alternatives are cheap and prevent hidden assumptions. |
| "The user didn't ask for explanation" | Default mode includes brief explanations. Only `/speed` suppresses. |
| "I already explained this pattern" | Good — reference it, don't re-explain. |

## Interaction Style

- Conversational, not preachy — like a smart coworker explaining over coffee
- Honest about complexity — if something is genuinely complicated, say so
- Analogies for abstract concepts — especially promises, closures, middleware, caching
- "Google this" pointers — after a new concept, suggest what to search for deeper understanding
- Don't over-explain the obvious — if someone asks "add a button", don't explain what buttons are
```

**Step 2: Commit**

```bash
git add skills/vibe-tutor/SKILL.md
git commit -m "feat: add core vibe-tutor skill"
```

---

### Task 3: SessionStart Hook

**Files:**
- Create: `hooks/hooks.json`
- Create: `hooks/session-start`
- Create: `hooks/run-hook.cmd`

**Step 1: Create hooks.json**

```json
{
  "hooks": {
    "SessionStart": [
      {
        "matcher": "startup|resume|clear|compact",
        "hooks": [
          {
            "type": "command",
            "command": "'${CLAUDE_PLUGIN_ROOT}/hooks/run-hook.cmd' session-start",
            "async": false
          }
        ]
      }
    ]
  }
}
```

**Step 2: Create session-start script**

This injects the condensed teaching preamble (~200 words) into every session. It does NOT read the full SKILL.md — that loads on-demand. The preamble is hardcoded in the script for minimal overhead.

```bash
#!/usr/bin/env bash
set -euo pipefail

escape_for_json() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\r'/\\r}"
    s="${s//$'\t'/\\t}"
    printf '%s' "$s"
}

preamble="You are pair-programming with a developer who wants to understand what's being built. This is not optional — it shapes every response.

CORE RULES:
1. Before writing complex code, briefly state: what problem we're solving, the approach, and one alternative we rejected.
2. Write code in small logical chunks. After each, explain non-obvious logic.
3. For significant decisions, name one rejected alternative and why.
4. First time using an abstract concept (middleware, closures, pub-sub), give a one-line analogy.
5. Flag tradeoffs honestly: what we gain, what we give up.
6. After introducing a new pattern or concept, suggest what to Google for deeper understanding.

SKIP: Don't over-explain the obvious. Don't repeat explanations from earlier in the session. Don't duplicate what you'd normally say anyway.

SCALE TO COMPLEXITY:
- Trivial changes → skip or 1 sentence
- Moderate changes → 2-3 sentences before the code
- Complex changes → full structured explanation

MODES (user switches anytime):
- Default: explain significant decisions, skip the obvious
- /teach: maximum explanation for everything
- /speed: just build, brief decision notes only
- 'just build it': speed mode but still mention key decisions

COMMANDS: /explain, /quiz, /map, /why, /teach, /speed

The vibe-tutor skill has full details — invoke it when a command is used."

preamble_escaped=$(escape_for_json "$preamble")
session_context="<VIBE_TUTOR>\n${preamble_escaped}\n</VIBE_TUTOR>"

cat <<EOF
{
  "additional_context": "${session_context}",
  "hookSpecificOutput": {
    "hookEventName": "SessionStart",
    "additionalContext": "${session_context}"
  }
}
EOF

exit 0
```

**Step 3: Create run-hook.cmd (cross-platform wrapper)**

Copy the exact polyglot wrapper from superpowers — it's platform infrastructure, not custom logic.

```
: << 'CMDBLOCK'
@echo off
if "%~1"=="" (
    echo run-hook.cmd: missing script name >&2
    exit /b 1
)
set "HOOK_DIR=%~dp0"
if exist "C:\Program Files\Git\bin\bash.exe" (
    "C:\Program Files\Git\bin\bash.exe" "%HOOK_DIR%%~1" %2 %3 %4 %5 %6 %7 %8 %9
    exit /b %ERRORLEVEL%
)
if exist "C:\Program Files (x86)\Git\bin\bash.exe" (
    "C:\Program Files (x86)\Git\bin\bash.exe" "%HOOK_DIR%%~1" %2 %3 %4 %5 %6 %7 %8 %9
    exit /b %ERRORLEVEL%
)
where bash >nul 2>nul
if %ERRORLEVEL% equ 0 (
    bash "%HOOK_DIR%%~1" %2 %3 %4 %5 %6 %7 %8 %9
    exit /b %ERRORLEVEL%
)
exit /b 0
CMDBLOCK

# Unix: run the named script directly
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_NAME="$1"
shift
exec bash "${SCRIPT_DIR}/${SCRIPT_NAME}" "$@"
```

**Step 4: Make scripts executable**

```bash
chmod +x hooks/session-start hooks/run-hook.cmd
```

**Step 5: Commit**

```bash
git add hooks/
git commit -m "feat: add SessionStart hook for always-on teaching preamble"
```

---

### Task 4: Commands

**Files:**
- Create: `commands/explain.md`
- Create: `commands/quiz.md`
- Create: `commands/map.md`
- Create: `commands/why.md`
- Create: `commands/teach.md`
- Create: `commands/speed.md`

**Step 1: Create all six command files**

Each follows the same pattern — a frontmatter block with description, then a one-line instruction to invoke the skill.

`commands/explain.md`:
```markdown
---
description: "Re-explain the last concept or code with a real-world analogy, no jargon"
disable-model-invocation: true
---

Invoke the vibe-tutor skill. The user wants an /explain — re-explain the last concept or code block using a real-world analogy, plain english, zero jargon. 2-3 sentences max.
```

`commands/quiz.md`:
```markdown
---
description: "Test understanding of what was just built with 2-3 questions"
disable-model-invocation: true
---

Invoke the vibe-tutor skill. The user wants a /quiz — ask 2-3 questions about what was just built to test their understanding. After they answer, confirm what's correct and gently correct what's not.
```

`commands/map.md`:
```markdown
---
description: "Show how all the current pieces connect with an ASCII architecture diagram"
disable-model-invocation: true
---

Invoke the vibe-tutor skill. The user wants a /map — show a compact ASCII diagram of how the current codebase pieces connect. Focus on the parts relevant to what we've been working on.
```

`commands/why.md`:
```markdown
---
description: "Deep dive on the last decision — alternatives considered and why they were rejected"
disable-model-invocation: true
---

Invoke the vibe-tutor skill. The user wants a /why — deep dive on the last significant decision. Explain what alternatives were considered, why each was rejected, and why the chosen approach wins.
```

`commands/teach.md`:
```markdown
---
description: "Switch to maximum explanation mode — explain everything in detail"
disable-model-invocation: true
---

Invoke the vibe-tutor skill. The user is switching to teach mode. From now on, explain everything in detail: architecture decisions, folder structure, tool choices, patterns, and how things connect. Acknowledge the mode switch.
```

`commands/speed.md`:
```markdown
---
description: "Switch to minimal explanation mode — just build, answer if asked"
disable-model-invocation: true
---

Invoke the vibe-tutor skill. The user is switching to speed mode. From now on, just build with brief decision notes only. Skip deep explanations. Answer questions if asked but don't volunteer detail. Acknowledge the mode switch.
```

**Step 2: Commit**

```bash
git add commands/
git commit -m "feat: add slash commands — /explain, /quiz, /map, /why, /teach, /speed"
```

---

### Task 5: README and LICENSE

**Files:**
- Create: `README.md`
- Create: `LICENSE`

**Step 1: Write README.md**

```markdown
# Vibe Tutor

A Claude Code plugin that turns every coding session into a teaching opportunity.

## What It Does

Adds a thin layer on top of Claude's natural responses so you always understand what was written and why — without burning excessive tokens or getting lecture-style explanations.

**What it adds (that Claude doesn't do by default):**
- One rejected alternative for significant decisions
- "How it connects" context for new code
- Key takeaways for complex sections
- First-use analogies for abstract concepts
- "Google this" pointers for deeper learning

**What it doesn't do:**
- Re-explain things Claude already explains well (naming, inline comments, code descriptions)
- Add walls of text before every code block
- Slow you down when you want to move fast

## Commands

| Command | What it does |
|---|---|
| `/explain` | Re-explain the last concept simply, with an analogy |
| `/quiz` | Test your understanding with 2-3 questions |
| `/map` | ASCII diagram of how pieces connect |
| `/why` | Deep dive on the last decision and alternatives |
| `/teach` | Maximum explanation mode |
| `/speed` | Minimal explanation mode |

## Modes

- **Default** — explains significant decisions, skips the obvious
- **Teach** — explains everything in detail (`/teach`)
- **Speed** — just builds, brief notes only (`/speed`)

Say "just build it" for speed mode that still mentions key decisions.

## Install

```bash
claude plugin add /path/to/vibe-tutor
```

## License

MIT
```

**Step 2: Create LICENSE (MIT)**

Standard MIT license file.

**Step 3: Commit**

```bash
git add README.md LICENSE
git commit -m "docs: add README and MIT license"
```

---

### Task 6: Test the Plugin

**Step 1: Verify hook output**

```bash
cd /path/to/vibe-tutor
CLAUDE_PLUGIN_ROOT="$(pwd)" bash hooks/session-start
```

Expected: Valid JSON with `additional_context` and `hookSpecificOutput` containing the teaching preamble wrapped in `<VIBE_TUTOR>` tags.

**Step 2: Verify JSON is valid**

```bash
CLAUDE_PLUGIN_ROOT="$(pwd)" bash hooks/session-start | python3 -m json.tool
```

Expected: Pretty-printed valid JSON, no parse errors.

**Step 3: Install plugin locally and test in a new Claude session**

```bash
claude plugin add /Users/varma/vibe-tutor
```

Start a new Claude Code session. Verify:
- Teaching preamble appears in session context
- `/explain`, `/quiz`, `/map`, `/why`, `/teach`, `/speed` are recognized as commands
- Default mode adds brief explanations to code
- `/speed` suppresses explanations
- `/teach` increases explanation depth

**Step 4: Commit any fixes**

```bash
git add -A
git commit -m "fix: adjustments from manual testing"
```

---

## Summary

| Task | Files | Description |
|---|---|---|
| 1 | `.claude-plugin/plugin.json` | Plugin manifest |
| 2 | `skills/vibe-tutor/SKILL.md` | Core teaching skill |
| 3 | `hooks/*` (3 files) | SessionStart hook for always-on injection |
| 4 | `commands/*` (6 files) | Slash commands |
| 5 | `README.md`, `LICENSE` | Documentation |
| 6 | — | Manual testing |
