# Vibe Tutor — Design Document

## North Star

"I can read what was built and understand what's going on without asking follow-up questions."

Not a textbook. Just enough context that the developer is never lost staring at code they don't recognize.

## What It Is

A Claude Code plugin that adds a thin teaching layer on top of Claude's natural responses. It ensures every coding interaction includes just enough explanation that the developer understands what was written and why — without burning excessive tokens or repeating what Claude already says.

## Architecture: Mirror Superpowers

```
vibe-tutor/
├── .claude-plugin/
│   └── plugin.json
├── hooks/
│   ├── hooks.json
│   ├── session-start
│   └── run-hook.cmd
├── skills/
│   └── vibe-tutor/
│       └── SKILL.md
├── commands/
│   ├── explain.md
│   ├── quiz.md
│   ├── map.md
│   ├── why.md
│   ├── teach.md
│   └── speed.md
├── LICENSE
└── README.md
```

### How It Loads

1. **SessionStart hook** injects a condensed preamble (~200 words) into every session
2. **Full SKILL.md** loads only when a command triggers it or it's explicitly invoked
3. **Commands** are thin wrappers that invoke the skill with a specific directive

## The Teaching Layer — What Vibe-Tutor Actually Adds

Claude already writes clean code, uses good names, adds comments, and explains what code does. Vibe-tutor only adds what Claude doesn't do by default:

| What vibe-tutor adds | When |
|---|---|
| One rejected alternative | Significant decisions (architecture, library choice, pattern) |
| "How it connects" | New code that interacts with existing codebase |
| Key takeaway | Complex sections only |
| First-use analogy | Genuinely abstract concepts (middleware, closures, pub-sub) |
| "Google this" pointer | After introducing a new pattern or concept |

Everything else — naming, inline comments, code structure — Claude handles naturally. Don't duplicate it.

## Token Efficiency Rules

1. **Hook preamble under 250 words** — full skill loads on-demand only
2. **Explanations scale to complexity:**
   - Trivial (rename, add button) → skip or 1 sentence
   - Moderate (new function, API call) → 2-3 sentences before the code
   - Complex (architecture, async, new patterns) → full template
3. **Don't repeat yourself** — reference earlier explanations: "Same pattern as the auth middleware"
4. **No unsolicited deep dives** — explain the decision, not the textbook
5. **Commands are brief** — `/explain` is 2-3 sentences, `/map` is a compact diagram, `/quiz` is 2-3 questions

Target: ~30-50% more tokens than a no-explanation session in default mode. `/speed` brings it to near-normal.

## Response Templates

### New Features (complex code only)
```
WHAT WE'RE BUILDING — brief description in the bigger picture
THE APPROACH — why this way, one alternative we rejected
THE CODE — small chunks, inline comments for the non-obvious
HOW IT CONNECTS — how this talks to the rest of the codebase
KEY TAKEAWAY — the one concept to remember
```

### Bug Fixes
```
THE BUG — what's going wrong
ROOT CAUSE — where and why
THE FIX — what we're changing and why it works
THE LESSON — what pattern caused this, how to avoid it
```

### Refactors
```
WHAT'S WRONG — why the current approach is problematic
CHANGING TO — the new approach and why it's better
THE TRADEOFF — what we gain, what we lose
```

Templates are guidelines, not rigid formats. Skip sections that add no value.

## Modes

| Mode | Trigger | Behavior |
|---|---|---|
| Default | Session start | Explain significant decisions, skip the obvious |
| Teach | `/teach` or "teach mode" | Explain everything — architecture, folder structure, tool choices |
| Speed | `/speed` or "speed mode" | Just build. Brief decision notes only. Answer if asked |

"just build it" = speed mode but still mention key decisions in 1 line.

## Commands

| Command | Behavior |
|---|---|
| `/explain` | Re-explain last concept with analogy, no jargon, 2-3 sentences |
| `/quiz` | 2-3 questions about what was just built |
| `/map` | Compact ASCII diagram of how pieces connect |
| `/why` | Deep dive on last decision and its alternatives |
| `/teach` | Switch to maximum explanation mode |
| `/speed` | Switch to minimal explanation mode |

Natural language triggers (`alternatives?`, `what if`, `eli5`) are documented in the skill but don't need command files.

## SessionStart Hook Preamble (injected every session)

Condensed rules (~200 words):
- Pair-programming with someone who wants to understand what's being built
- Before writing complex code: what problem, the approach, one rejected alternative
- Code in small chunks, explain non-obvious logic after each
- For significant decisions, name one rejected alternative
- First-use analogies for abstract concepts only
- Flag tradeoffs: what we gain, what we give up
- Don't over-explain the obvious. Don't repeat earlier explanations.
- Modes: teach / default / speed
- Commands: /explain, /quiz, /map, /why, /teach, /speed

## SKILL.md Structure

```yaml
---
name: vibe-tutor
description: Use when writing, explaining, debugging, or refactoring any code — enforces teaching-first pair programming with contextual explanations
---
```

Body sections:
1. Overview
2. The Iron Law — never leave the developer unable to understand what was written
3. What Vibe-Tutor Adds (the thin layer table)
4. Token Efficiency Rules
5. Response Templates (new features, bug fixes, refactors)
6. Modes and Switching
7. Command Reference
8. Rationalization Table (excuse-busting)
9. Interaction Style — conversational, honest about complexity, analogies for abstract concepts

## Rationalization Table

| Thought | Reality |
|---|---|
| "This is obvious, no need to explain" | Only skip if it's truly trivial (rename, typo fix). Decisions always get a why. |
| "I'll explain after the code" | Context before content. Why before what. |
| "Speed mode means skip everything" | Speed mode means skip deep dives, not skip all reasoning |
| "This is too simple for alternatives" | One-line alternatives are cheap and prevent hidden assumptions |
| "The user didn't ask for explanation" | Default mode includes brief explanations. Only /speed suppresses. |
| "I already explained this pattern" | Good — reference it, don't re-explain it |
