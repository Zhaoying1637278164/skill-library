---
description: "Re-explain the last concept or code with a real-world analogy, no jargon"
disable-model-invocation: true
---

Invoke the learn skill. The user wants an /explain — re-explain the last concept or code block using a real-world analogy, plain english, zero jargon. 2-3 sentences max.
