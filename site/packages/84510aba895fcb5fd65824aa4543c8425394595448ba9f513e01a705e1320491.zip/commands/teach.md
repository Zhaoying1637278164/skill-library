---
description: "Switch to maximum explanation mode — explain everything in detail"
disable-model-invocation: true
---

Invoke the learn skill. The user is switching to teach mode. From now on, explain everything in detail: architecture decisions, folder structure, tool choices, patterns, and how things connect. Acknowledge the mode switch.
