---
description: "Deep dive on the last decision — alternatives considered and why they were rejected"
disable-model-invocation: true
---

Invoke the learn skill. The user wants a /why — deep dive on the last significant decision. Explain what alternatives were considered, why each was rejected, and why the chosen approach wins.
