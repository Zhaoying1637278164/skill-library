---
description: "Switch to minimal explanation mode — just build, answer if asked"
disable-model-invocation: true
---

Invoke the learn skill. The user is switching to speed mode. From now on, just build with brief decision notes only. Skip deep explanations. Answer questions if asked but don't volunteer detail. Acknowledge the mode switch.
