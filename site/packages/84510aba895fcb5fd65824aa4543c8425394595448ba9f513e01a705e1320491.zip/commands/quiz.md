---
description: "Test understanding of what was just built with 2-3 questions"
disable-model-invocation: true
---

Invoke the learn skill. The user wants a /quiz — ask 2-3 questions about what was just built to test their understanding. After they answer, confirm what's correct and gently correct what's not.
