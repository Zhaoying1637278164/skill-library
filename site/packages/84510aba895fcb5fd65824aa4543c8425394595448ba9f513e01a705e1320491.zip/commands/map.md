---
description: "Show how all the current pieces connect with an ASCII architecture diagram"
disable-model-invocation: true
---

Invoke the learn skill. The user wants a /map — show a compact ASCII diagram of how the current codebase pieces connect. Focus on the parts relevant to what we've been working on.
