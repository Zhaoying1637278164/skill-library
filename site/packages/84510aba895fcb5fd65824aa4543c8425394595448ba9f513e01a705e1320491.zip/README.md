# Learn

A Claude Code plugin that turns every coding session into a teaching opportunity.

## What It Does

Adds a thin layer on top of Claude's natural responses so you always understand what was written and why — without burning excessive tokens or getting lecture-style explanations.

**What it adds (that Claude doesn't do by default):**
- One rejected alternative for significant decisions
- "How it connects" context for new code
- Key takeaways for complex sections
- First-use analogies for abstract concepts
- "Google this" pointers for deeper learning

**What it doesn't do:**
- Re-explain things Claude already explains well (naming, inline comments, code descriptions)
- Add walls of text before every code block
- Slow you down when you want to move fast

## Commands

| Command | What it does |
|---|---|
| `/explain` | Re-explain the last concept simply, with an analogy |
| `/quiz` | Test your understanding with 2-3 questions |
| `/map` | ASCII diagram of how pieces connect |
| `/why` | Deep dive on the last decision and alternatives |
| `/teach` | Maximum explanation mode |
| `/speed` | Minimal explanation mode |

## Modes

- **Default** — explains significant decisions, skips the obvious
- **Teach** — explains everything in detail (`/teach`)
- **Speed** — just builds, brief notes only (`/speed`)

Say "just build it" for speed mode that still mentions key decisions.

## Install

```bash
claude plugin add /path/to/learn
```

## License

MIT
