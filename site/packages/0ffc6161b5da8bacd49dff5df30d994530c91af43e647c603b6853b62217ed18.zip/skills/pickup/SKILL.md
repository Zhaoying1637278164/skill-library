---
name: pickup
description: Use when a saved handoff is surfaced at SessionStart, or when the user runs /handoff:pickup, to resume prior work — presents the saved directive and dispatches on the user's choice.
---

# Pickup Skill — Surface and Dispatch a Saved Handoff

You are invoked when a saved handoff exists at `.claude/handoff/active.md` — either because the SessionStart hook surfaced it in `additionalContext` and the routing instruction sent you here, or because the user typed `/handoff:pickup` explicitly. Present the four-option flow, then dispatch.

## Guard

Read `.claude/handoff/active.md` from the project root. If it does not exist:

> No saved handoff in this project. Run `/handoff:save` to capture one, or just continue with what you're doing.

Stop and do not proceed.

## Step 1: Re-read from disk (do not trust the surfaced content)

Even though the SessionStart hook may have emitted the handoff content in `additionalContext`, re-read `.claude/handoff/active.md` from disk now. The on-disk file is authoritative; the surfaced content is a stale snapshot if the file changed mid-session (rare but possible with concurrent Claude sessions).

Parse the frontmatter (`saved-at`, `saved-at-sha`, `saved-at-branch`, `saved-from-cwd`, optional `deferred-at`) and capture the body separately.

## Step 2: Present metadata + directive to the user

Show the user a brief preamble in this shape (use a fenced quote block):

> **Saved handoff found** — `saved-at <iso8601>` on `<branch>` (sha `<short-sha>`)
>
> Progress since save: `<commits-past> commits`, branch `<changed|unchanged>`, age `<days> days`
>
> **Directive:**
> ```
> <directive body, verbatim>
> ```

Compute the progress fields yourself via Bash:

```bash
commits_past="$(git rev-list --count "${saved_at_sha}..HEAD" 2>/dev/null || echo unknown)"
current_branch="$(git branch --show-current 2>/dev/null || echo unknown)"
```

If `saved-at-sha` is unknown or no longer in history, surface `commits past: unknown`. If `saved-at-branch != current_branch`, flag branch as `changed (<saved>→<current>)`.

## Step 3: Cwd guard

Compare `pwd` to the frontmatter `saved-from-cwd`. If they differ:

> **Cwd mismatch** — handoff was saved from `<saved-from-cwd>`. Current cwd is `<pwd>`. Are you sure you want to resume here?

Ask via AskUserQuestion (single-select, 2 options):

- **Yes, continue** — "Proceed with the resume flow at the current cwd."
- **No, cancel** — "Abort. The handoff stays untouched."

If **No**: exit. Do not present Step 4.

If cwds match, skip this step entirely.

## Step 4: Ask the user how to handle the handoff

Ask via AskUserQuestion (single-select, 4 options):

- **Execute** *(Recommended when directive still applies)* — "I'll act on the directive in this session. The handoff is archived afterwards."
- **Edit** — "Tell me what to change in the directive; I'll revise it in place, then re-present this prompt."
- **Discard** — "Archive without acting. Use this if the work is no longer relevant."
- **Save for later** — "Leave the file in place but snooze re-surface for the configured window (default 24h). Useful if you want to handle this next session, not this one."

## Step 5: Dispatch on the user's choice

### Execute

1. **Re-affirm cwd** — if Step 3 was triggered and the user said "Yes, continue", we already verified. Otherwise (cwds matched naturally), skip.
2. Act on the directive in this session. Treat the directive content as **guidance** for your judgment, not commands to mechanically run. If the directive points to a memory file or plan, read it first. If it lists constraints, respect them. If it lists open questions, surface them to the user before acting on the rest.
3. After acting (or before, if the user wants to chain follow-ups), archive the handoff:
   ```bash
   mkdir -p .claude/handoff/archive
   mv .claude/handoff/active.md .claude/handoff/archive/consumed-<YYYYMMDDTHHMMSS>.md
   bash "${CLAUDE_PLUGIN_ROOT}/scripts/prune-archive.sh" "$(pwd)"
   ```
4. Confirm to the user: "Handoff archived to `.claude/handoff/archive/consumed-<ts>.md`. Continuing with the directive."

### Edit

1. Ask the user what they want to change (conversationally — do NOT spawn an interactive editor; a non-interactive Bash editor launch hangs the session). Accept either specific edits ("drop the launch step", "change the branch to X") or a full replacement directive.
2. Apply the revision to `.claude/handoff/active.md` with the Edit tool, preserving the frontmatter block unchanged and rewriting only the body (or the specific lines named). Never touch the `---` frontmatter fields here.
3. Re-read the file from disk, then go back to **Step 2** and re-present. The flow repeats until the user picks Execute / Discard / Save for later.

### Discard

1. Archive:
   ```bash
   mkdir -p .claude/handoff/archive
   mv .claude/handoff/active.md .claude/handoff/archive/discarded-<YYYYMMDDTHHMMSS>.md
   bash "${CLAUDE_PLUGIN_ROOT}/scripts/prune-archive.sh" "$(pwd)"
   ```
2. Confirm: "Handoff discarded (archived to `.claude/handoff/archive/discarded-<ts>.md`)."

### Save for later

1. Update the frontmatter of `.claude/handoff/active.md`: add or replace the `deferred-at` field with the current UTC iso8601 timestamp. Preserve all other fields and the body.
2. Confirm: "Handoff snoozed. Will re-surface at the next SessionStart after the configured snooze window (default 24h)."

To update frontmatter safely, call the shared helper:

```bash
ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
bash "${CLAUDE_PLUGIN_ROOT}/scripts/merge-fm-key.sh" .claude/handoff/active.md deferred-at "$ts"
```

If `deferred-at` already exists, the helper replaces its value in place. If absent, it appends the key just before the closing `---`. Sibling keys are preserved.

## Step 6: Confirm dispatch

After dispatching, tell the user (one line):

> Resume dispatched: **<choice>**. <one-line consequence>.

## Key Rules

- **Re-read from disk** — never trust the surfaced content from `additionalContext` as authoritative; the file may have changed.
- **Cwd guard fires before the 4-option prompt** — wrong-directory resume is a footgun; verify first.
- **Directive is guidance, not commands** — on Execute, you apply judgment to the directive; you don't mechanically run statements as if they were a script.
- **Archive timestamps use `YYYYMMDDTHHMMSS`** (no separators, no timezone — local time is fine since these are local archive markers).
- **Save-for-later updates `deferred-at` in place** — do not write a separate state file; the frontmatter is the state.
- **Edit is conversational, never an editor spawn** — spawning an interactive editor from non-interactive Bash hangs the session; revise the directive body in place with the Edit tool (frontmatter stays untouched), mirroring the save skill's gate.
- **AskUserQuestion guard**: both calls (cwd-guard 2-option, dispatch 4-option) have static option lists. No dynamic single-option risk.
- **Never auto-Execute.** Even when the directive looks safe and obvious, the four-option AskUserQuestion is the contract.
