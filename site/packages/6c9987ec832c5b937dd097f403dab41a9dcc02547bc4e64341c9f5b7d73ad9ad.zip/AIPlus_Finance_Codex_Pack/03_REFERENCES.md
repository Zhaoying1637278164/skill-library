# 借鉴资源与核验记录

检索日期：2026-09-30。星数为本次检索时GitHub页面显示的近似值，可能存在缓存；子目录使用主仓库星数。不等于实时排名。

## 如何使用这份资源表

“代码候选”只是许可证和功能层面的初选，不表示已验证可直接嵌入。开发前仍需确认源码目录、接口、依赖、版本及测试。商业产品和方法文章只作为学习来源。没有为64款各找到一套现成成熟代码，尤其中国税务与复杂合并不能用国外项目直接代替。

## GitHub、产品、方法

### REF-G01｜[Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)

**星数：**25.9k（主仓库）　**许可/性质：**Apache-2.0

**参考角色：**方法与规则结构

**学什么：**月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

**不能误用：**只借鉴方法和经审查的说明文件；不是离线计算引擎。GAAP/SOX框架不得直接宣称符合中国制度。

**核验范围：**已读取官方主仓库及finance README；未逐个执行skills。

### REF-G02｜[ERPNext](https://github.com/frappe/erpnext)

**星数：**39.7k　**许可/性质：**GPL-3.0

**参考角色：**业务流程参考

**学什么：**采购、销售、库存、资产、会计等业务对象及单据关系。

**不能误用：**本方案只作流程与产品观察，不复制GPL代码构建受限源码产品，也不让个人用户部署完整ERP。

**核验范围：**已读取官方仓库概览；未逐模块试跑。

### REF-G03｜[Actual Budget](https://github.com/actualbudget/actual)

**星数：**29.2k　**许可/性质：**MIT

**参考角色：**本地产品形态；代码候选

**学什么：**本地优先、文件保存、个人财务操作体验。

**不能误用：**是个人理财产品；借鉴本地体验，不把信封预算当作企业预算方法。复用组件须核查实际耦合和依赖。

**核验范围：**已读取官方仓库。

### REF-G04｜[Frappe Books](https://github.com/frappe/books)

**星数：**5.0k　**许可/性质：**AGPL-3.0

**参考角色：**离线会计产品参考

**学什么：**离线会计软件的台账、单据和报表组织方式。

**不能误用：**主要看交互与流程。AGPL不禁止商用，但源码义务需要审查；不作为本项目默认代码底座。

**核验范围：**已读取官方仓库；未安装。

### REF-G05｜[OpenRefine](https://github.com/OpenRefine/OpenRefine)

**星数：**12.0k　**许可/性质：**BSD-3-Clause

**参考角色：**数据整理方法；代码候选

**学什么：**把数据整理变成可检查、可复用的处理过程。

**不能误用：**优先借鉴处理流程，不移植整套Java应用；联网补全和外部服务不进入本地版默认流程。

**核验范围：**已读取官方仓库及官网；未试跑。

### REF-G06｜[Evidence](https://github.com/evidence-dev/evidence)

**星数：**7.0k　**许可/性质：**MIT

**参考角色：**数据报告方法；代码候选

**学什么：**用SQL和Markdown组织含数据、图表与解释的报告。

**不能误用：**借鉴报告结构，不要求每个小工具部署Evidence服务。商业版/云服务不等于MIT代码范围。

**核验范围：**已读取官方仓库。

### REF-G07｜[Anthropic Financial Services](https://github.com/anthropics/financial-services)

**星数：**38.2k　**许可/性质：**Apache-2.0

**参考角色：**财务工作流方法

**学什么：**GL Reconciler、Month-End Closer等参考工作流，把准备、核对、解释与复核分开。

**不能误用：**不是可直接交付的离线财务应用；金融投资等模型不等于中国企业会计实现。

**核验范围：**已读取官方仓库概览和工作流描述；未运行agents。

### REF-G08｜[DataComPy](https://github.com/capitalone/datacompy)

**星数：**659　**许可/性质：**Apache-2.0

**参考角色：**Python比较库；方法参考

**学什么：**按键比较两份表格并组织差异结果。

**不能误用：**星数较低但任务贴合。不是一对多银行核销引擎。首个TypeScript工具只借鉴比较方法，不强塞Python依赖。

**核验范围：**已读取官方仓库；未执行比较测试。

### REF-G09｜[pdfplumber](https://github.com/jsvine/pdfplumber)

**星数：**10.8k　**许可/性质：**MIT

**参考角色：**本地PDF解析代码候选

**学什么：**提取PDF文本、几何信息和表格。

**不能误用：**优先文本型PDF；不能把它单独宣传为扫描件OCR。后续若采用Python，须独立打包本地运行组件。

**核验范围：**已读取官方仓库；未做样本提取测试。

### REF-G10｜[invoice2data](https://github.com/invoice-x/invoice2data)

**星数：**2.2k　**许可/性质：**MIT

**参考角色：**模板化单据抽取参考

**学什么：**以模板把文档字段转为结构化数据。

**不能误用：**本地解析路径优先；不启用云OCR，不复用外国税务规则，不承诺中国发票真伪查验。

**核验范围：**已读取官方仓库；未验证中国单据。

### REF-E01｜[Tauri](https://github.com/tauri-apps/tauri)

**星数：**111.5k　**许可/性质：**MIT / Apache-2.0

**参考角色：**桌面封装候选

**学什么：**把Web界面交付为桌面应用。

**不能误用：**需要按平台构建与实测；WebView依赖、签名和安装体验必须验证，不能仅凭开发页面声称双击即用。

**核验范围：**已读取官方仓库；未构建安装包。

### REF-E02｜[ExcelJS](https://github.com/exceljs/exceljs)

**星数：**15.5k　**许可/性质：**MIT

**参考角色：**Excel读写候选

**学什么：**工作簿导入导出、格式与表格处理。

**不能误用：**具体版本支持范围需实施前验证。不得默认当作Excel完整公式计算器，不承诺xls、宏或密码文件支持。

**核验范围：**已读取官方仓库元信息；尚未做文件格式兼容性测试。

### REF-E03｜[Plotly.js](https://github.com/plotly/plotly.js)

**星数：**18.4k　**许可/性质：**MIT

**参考角色：**本地可视化候选

**学什么：**趋势、比较、瀑布等交互图表。

**不能误用：**生产版静态资源必须随应用分发，禁用CDN加载；财务符号和口径自己定义。

**核验范围：**已读取官方仓库。

### REF-E04｜[DuckDB](https://github.com/duckdb/duckdb)

**星数：**41.8k　**许可/性质：**MIT

**参考角色：**可选本地分析引擎

**学什么：**嵌入式数据聚合与查询。

**不能误用：**不是首款工具的强制依赖。扩展、网络数据源和自动下载需明确限制。

**核验范围：**已读取官方仓库。

### REF-P01｜[Numeric](https://www.numeric.io/)

**星数：**—　**许可/性质：**商业产品；无代码授权

**参考角色：**异常优先的财务产品设计

**学什么：**先呈现需要处理的异常，再提供规则、来源和复核。

**不能误用：**看公开功能和演示，不复制品牌界面资产，不接入其云服务。

**核验范围：**已读取官方首页能力描述；未登录试用。

### REF-P02｜[FloQast](https://www.floqast.com/)

**星数：**—　**许可/性质：**商业产品；无代码授权

**参考角色：**月结工作流与复核

**学什么：**准备动作、证据、状态和人工确认分离。

**不能误用：**本地个人版不做组织审批/团队权限。公开描述并非第三方验证的效果证据。

**核验范围：**已读取官方首页及演示入口说明。

### REF-P03｜[Lucanet xP&A（原Causal方向）](https://www.lucanet.com/en/solutions/extended-planning-and-analysis/)

**星数：**—　**许可/性质：**商业产品；无代码授权

**参考角色：**驱动式计划与情景比较

**学什么：**把数量、价格、人员等驱动与时间、情景假设分开。

**不能误用：**Causal官网说明已加入Lucanet；借鉴可见假设和模型结构，不照搬企业云部署。

**核验范围：**已读取Causal官网与Lucanet官方解决方案页。

### REF-P04｜[IBCS](https://www.ibcs.com/ibcs-version-2-0/)

**星数：**—　**许可/性质：**标准/方法资料；逐项核查使用条件

**参考角色：**报告表达方法

**学什么：**统一报表表达和比较语义，让数字、情景和变化关系清晰。

**不能误用：**学习原则，不复制标准文档、付费模板或认证标志；不宣称产品已获认证。

**核验范围：**已读取官方标准介绍；未做逐条合规认证。

### REF-P05｜[Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)

**星数：**—　**许可/性质：**官方产品文档；方法参考

**参考角色：**核对与异常处理

**学什么：**导入不同来源，按规则匹配，解释和处理未匹配项。

**不能误用：**学流程不买云产品；首版只做确定性匹配，预测匹配为后续独立研究。

**核验范围：**已读取官方功能文档。

### REF-M01｜[CFI Driver-Based Planning Guide](https://corporatefinanceinstitute.com/resources/fpa/driver-based-planning-guide/)

**星数：**—　**许可/性质：**教学文章；方法参考

**参考角色：**驱动式预算

**学什么：**明确驱动因素、假设和情景，再计算结果。

**不能误用：**不复制受版权保护的课程模板；预测结果不是准确性承诺。

**核验范围：**已读取官方文章。

### REF-M02｜[Wall Street Prep 13-Week Cash Flow](https://www.wallstreetprep.com/knowledge/demystifying-the-13-week-cash-flow-model-in-excel/)

**星数：**—　**许可/性质：**教学文章；方法参考

**参考角色：**短期现金预测

**学什么：**按周组织预计收款和付款，滚动更新余额。

**不能误用：**不把利润直接当现金，不重新分发课程收费模板。

**核验范围：**已读取官方文章。

### REF-M03｜[Claude Academy — Build financial models](https://academy.claude.com/use-cases/build-financial-models)

**星数：**—　**许可/性质：**官方案例；方法参考

**参考角色：**情景模型与可编辑底稿

**学什么：**假设、计算、情景和敏感性分别呈现。

**不能误用：**案例涉及联网数据服务，不是本地架构。仅借鉴建模过程，不复用示例投资判断。

**核验范围：**已读取官方案例；未执行其模型。

### REF-L01｜[ERPNext GPL-3.0 license text](https://github.com/frappe/erpnext/blob/develop/license.txt)

**星数：**—　**许可/性质：**GPL-3.0许可原文

**参考角色：**许可证核查

**学什么：**核查分发目标代码时的对应源码及通知义务。

**不能误用：**商业化前按实际组合方式和版本复核，不把GPL解释为禁止收费。

**核验范围：**已读取官方仓库许可原文。

## YouTube案例

核验了可见标题、搜索索引/简介或官方配套页面，未逐分钟审阅；不据此承诺教程代码可商用、全部步骤仍兼容，或视频完成了离线打包。部分YouTube页面抓取受限，但保留可核验的标题和链接。

### V01｜[Turn An Excel Sheet Into An Interactive Dashboard Using Python (Streamlit)](https://www.youtube.com/watch?v=Sb0A9i6d320)

**来源：**Coding Is Fun / Sven Bosau

**建议观察：**从表格到筛选、指标和图表的最小闭环。

**对应工具：**B02、E05、M05。

**配套参考：**[https://github.com/Sven-Bo/streamlit-sales-dashboard](https://github.com/Sven-Bo/streamlit-sales-dashboard)。

### V02｜[Power Query for Beginners: Automate Your Excel Work in 25 Mins](https://www.youtube.com/watch?v=x7mzOYEn0XA)

**来源：**Leila Gharani

**建议观察：**把重复整理过程固化为规则，下次换表继续使用。

**对应工具：**D01、D03、D06。

### V03｜[How To Automate Your Finances with Python — Full Tutorial](https://www.youtube.com/watch?v=wqBlmAWqa6A)

**来源：**Tech With Tim

**建议观察：**观察一份数据如何进入完整应用；场景偏个人财务。

**对应工具：**E05、T02。

**配套参考：**[https://github.com/techwithtim/AutomateFinancesWithPython](https://github.com/techwithtim/AutomateFinancesWithPython)。

### V04｜[How To: 13 Week Cash Flow Template](https://www.youtube.com/watch?v=LauI-j6Vgkc)

**来源：**GrowthLab相关现金流模板案例

**建议观察：**观察周度收付款和余额的工作方式。

**对应工具：**T03。

**配套参考：**[https://www.growthlabfinancial.com/10-steps-to-a-13-week-cash-flow](https://www.growthlabfinancial.com/10-steps-to-a-13-week-cash-flow)。

### V05｜[Predicting Matches with Transaction Matching Assistance](https://www.youtube.com/watch?v=UkrWtMSGRbw)

**来源：**Oracle官方文档配套视频

**建议观察：**观察候选匹配与人工判断的交互；不作为首版必须加AI的理由。

**对应工具：**D02、R03、T01。

**配套参考：**[https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/videos.html](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/videos.html)。

### V06｜[Create Self-Service BI Power BI Dashboards with Zebra BI](https://www.youtube.com/watch?v=Ad-STSkGDq0&vl=en)

**来源：**Zebra BI相关案例

**建议观察：**观察实际与预测比较、用户筛选和解释的组织方式。

**对应工具：**B02、M05、F05。

**配套参考：**[https://help.zebrabi.com/kb/power-bi/](https://help.zebrabi.com/kb/power-bi/)。

## 产品演示补充

FloQast官网链接了[AI Agents Demo Library](https://www.floqast.com/ai-agents/ai-agents-demo-library)，包括租赁、债务、佣金等任务演示的入口说明。本次只读到首页的演示描述，演示子页受限，没有逐个观看。

## 把方法转成产品的流程

先用自己的话写清输入、计算、输出和异常；再标明借鉴来源；随后独立写中国财务口径规则和虚构金标准数据；最后让Codex实现确定性软件。不能把skills里的一段提示词直接当成可靠会计引擎，也不能把AI生成的代码视为自动摆脱上游许可证约束。
