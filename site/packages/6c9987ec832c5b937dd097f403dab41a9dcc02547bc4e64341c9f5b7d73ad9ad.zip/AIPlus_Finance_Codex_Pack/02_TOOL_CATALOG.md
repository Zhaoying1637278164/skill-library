# 64款独立工具候选目录

以下输入、输出和边界均为AI+产品设计建议，不是上游项目现成功能。借鉴关联代表建议研究方向，具体源码路径尚需开发前查证。所有项目均未实现。

每款默认：业务数据本地处理；使用虚构样本；输出可追溯底稿；核心结果可重复计算；实际可用性须验收。

## 会计核算与月结（6款）

### C01｜个人月结工作台

**形态：**个人工作台　**建议阶段：**第二批

**输入：**月结任务模板、期间、截止日及本机证据文件。

**用户拿走的结果：**本期任务表、未完成事项、证据索引和归档包。

**首版核心规则：**复制上期模板；标识依赖与完成状态；保留变更记录。

**明确不做：**不接企业审批、不给团队多人协作承诺。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G07 Anthropic Financial Services](https://github.com/anthropics/financial-services)：财务工作流方法。GL Reconciler、Month-End Closer等参考工作流，把准备、核对、解释与复核分开。
- [REF-P02 FloQast](https://www.floqast.com/)：月结工作流与复核。准备动作、证据、状态和人工确认分离。

### C02｜计提与冲回助手

**形态：**单点工具　**建议阶段：**第二批

**输入：**费用依据、计提期间、科目和冲回规则。

**用户拿走的结果：**计提冲回计划与分录底稿。

**首版核心规则：**金额依据可追溯；跨月冲回不得重复；已确认版本可保留。

**明确不做：**不自动入账、不替用户决定应否计提。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G07 Anthropic Financial Services](https://github.com/anthropics/financial-services)：财务工作流方法。GL Reconciler、Month-End Closer等参考工作流，把准备、核对、解释与复核分开。

### C03｜待摊费用计划器

**形态：**单点工具　**建议阶段：**首批

**输入：**费用金额、起止期间及摊销规则。

**用户拿走的结果：**月度摊销计划、本期底稿、剩余余额。

**首版核心规则：**日/月口径显式选择；尾差有归属；变更从指定期间生效。

**明确不做：**不自动判断资产资本化政策。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G04 Frappe Books](https://github.com/frappe/books)：离线会计产品参考。离线会计软件的台账、单据和报表组织方式。

### C04｜科目余额检查器

**形态：**单点工具　**建议阶段：**第二批

**输入：**科目余额表、科目属性和检查规则。

**用户拿走的结果：**异常余额、期间变化及追溯清单。

**首版核心规则：**方向、空科目、借贷平衡和期初期末变动分别核验。

**明确不做：**异常仅为复核线索，不宣称账务正确性保证。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-P01 Numeric](https://www.numeric.io/)：异常优先的财务产品设计。先呈现需要处理的异常，再提供规则、来源和复核。

### C05｜手工分录底稿生成与校验器

**形态：**单点工具　**建议阶段：**第二批

**输入：**分录模板、业务明细、科目映射。

**用户拿走的结果：**可复核分录底稿和错误清单。

**首版核心规则：**借贷平衡、必填项、期间和映射完整性检查。

**明确不做：**不直接连接财务系统入账。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G04 Frappe Books](https://github.com/frappe/books)：离线会计产品参考。离线会计软件的台账、单据和报表组织方式。

### C06｜总账与明细账核对助手

**形态：**单点工具　**建议阶段：**第二批

**输入：**总账余额、明细账及组织科目期间映射。

**用户拿走的结果：**科目级差异和组成明细。

**首版核心规则：**统一粒度后核对；保留期初、发生额、期末的解释链。

**明确不做：**不能用明细缺失时的强行调平代替核查。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G07 Anthropic Financial Services](https://github.com/anthropics/financial-services)：财务工作流方法。GL Reconciler、Month-End Closer等参考工作流，把准备、核对、解释与复核分开。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

## 收入与应收（5款）

### R01｜合同开票回款台账

**形态：**个人工作台　**建议阶段：**第二批

**输入：**用户录入或导入的合同、开票与回款记录。

**用户拿走的结果：**合同状态、剩余待开票及待回款清单。

**首版核心规则：**以用户指定关联键连接；未能关联记录单独展示。

**明确不做：**不开发合同审批、开票接口或CRM。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G03 Actual Budget](https://github.com/actualbudget/actual)：本地产品形态；代码候选。本地优先、文件保存、个人财务操作体验。

### R02｜收入确认排程器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**合同期间金额及已确定的确认政策。

**用户拿走的结果：**分期收入计划、累计与剩余明细。

**首版核心规则：**政策是用户输入；调整版本留痕；金额总量守恒。

**明确不做：**不自动作履约义务和收入确认专业判断。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### R03｜回款核销核对助手

**形态：**单点工具　**建议阶段：**第二批

**输入：**应收单据、收款记录及匹配规则。

**用户拿走的结果：**已匹配、部分匹配、未分配记录。

**首版核心规则：**首版限定明确关联与人工指定分配；保留核销依据。

**明确不做：**不得宣称自动解决全部一对多和多对多。

**建议借鉴：**

- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-P01 Numeric](https://www.numeric.io/)：异常优先的财务产品设计。先呈现需要处理的异常，再提供规则、来源和复核。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

### R04｜应收账龄与逾期分析器

**形态：**分析看板　**建议阶段：**首批

**输入：**应收未结明细、核销信息及截止日。

**用户拿走的结果：**账龄分布、逾期名单、客户汇总和底稿。

**首版核心规则：**区分账龄和逾期；截止日与起算口径可见；负余额单列。

**明确不做：**不把简单逾期自动等同信用风险结论。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。

### R05｜坏账准备测算器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**应收分组、账龄与用户批准的损失参数。

**用户拿走的结果：**准备金额测算、参数表和变动说明底稿。

**首版核心规则：**分组、例外、参数版本和尾差可追溯。

**明确不做：**不承诺模型自动满足预期信用损失准则。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

## 采购与应付（4款）

### P01｜采购收货发票三单核对器

**形态：**单点工具　**建议阶段：**第二批

**输入：**采购订单、收货明细和发票明细。

**用户拿走的结果：**数量单价金额差异、缺单与未关联清单。

**首版核心规则：**统一单位与单据层级；拆分交付需可解释关联。

**明确不做：**不做采购审批与供应商门户。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

### P02｜应付款到期排程器

**形态：**单点工具　**建议阶段：**第二批

**输入：**应付余额、到期日和用户选择的付款安排。

**用户拿走的结果：**分周付款清单与计划余额。

**首版核心规则：**原始到期日与拟付款日分开；排程改变留痕。

**明确不做：**不发起银行付款、不作自动融资决策。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-M02 Wall Street Prep 13-Week Cash Flow](https://www.wallstreetprep.com/knowledge/demystifying-the-13-week-cash-flow-model-in-excel/)：短期现金预测。按周组织预计收款和付款，滚动更新余额。

### P03｜预付款核销助手

**形态：**单点工具　**建议阶段：**第二批

**输入：**预付款、后续发票或结算记录。

**用户拿走的结果：**已核销和未核销余额、账龄与缺口清单。

**首版核心规则：**按合同供应商核对；冲销不能超过待核销额。

**明确不做：**不擅自推断无明确依据的核销关系。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

### P04｜供应商对账单核对与生成器

**形态：**单点工具　**建议阶段：**第二批

**输入：**本方往来明细与供应商对账单。

**用户拿走的结果：**供应商往来对账底稿和待确认项目。

**首版核心规则：**分别列示期初、采购/费用、付款、期末。

**明确不做：**不自动向外部供应商发送邮件。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。

## 费用与薪酬（5款）

### E01｜报销规则检查器

**形态：**单点工具　**建议阶段：**第二批

**输入：**报销明细和公司自定标准。

**用户拿走的结果：**超标、重复候选、缺失字段及复核清单。

**首版核心规则：**规则来源和版本明确；相似不能直接认定重复。

**明确不做：**不替代审批或认定舞弊。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-P01 Numeric](https://www.numeric.io/)：异常优先的财务产品设计。先呈现需要处理的异常，再提供规则、来源和复核。

### E02｜工资表变动核对器

**形态：**单点工具　**建议阶段：**第二批

**输入：**两期工资明细及员工稳定标识。

**用户拿走的结果：**新增离职、项目变动和差额明细。

**首版核心规则：**敏感信息本机处理；人员标识优先于姓名。

**明确不做：**首版不实现个税与社保法定自动计算。

**建议借鉴：**

- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。

### E03｜人工成本分摊器

**形态：**单点工具　**建议阶段：**第二批

**输入：**人工成本、部门项目和分摊依据。

**用户拿走的结果：**分摊明细、汇总和未分配清单。

**首版核心规则：**依据可见；总额守恒；尾差规则固定。

**明确不做：**不自动确定工时真实性或成本归属政策。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

### E04｜提成与奖金测算器

**形态：**单点工具　**建议阶段：**第二批

**输入：**业绩、分档规则、封顶和调整项。

**用户拿走的结果：**个人测算明细、规则命中说明。

**首版核心规则：**阶梯/全额累进等算法需明示；允许批准后的手工调整。

**明确不做：**不作劳动合同或法定薪酬判断。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-P02 FloQast](https://www.floqast.com/)：月结工作流与复核。准备动作、证据、状态和人工确认分离。

### E05｜费用结构分析看板

**形态：**分析看板　**建议阶段：**第二批

**输入：**费用明细、组织和科目映射。

**用户拿走的结果：**部门科目趋势、结构和异常明细。

**首版核心规则：**统一含税/不含税与金额单位；聚合可追溯。

**明确不做：**预算比较由B02处理，不另复制一套同功能商品。

**建议借鉴：**

- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。
- [REF-P04 IBCS](https://www.ibcs.com/ibcs-version-2-0/)：报告表达方法。统一报表表达和比较语义，让数字、情景和变化关系清晰。

## 成本与存货（5款）

### K01｜成本分摊测算器

**形态：**单点工具　**建议阶段：**第二批

**输入：**待分摊成本、成本对象和分配因子。

**用户拿走的结果：**对象成本明细及分摊检查表。

**首版核心规则：**直接成本和分摊成本区分；零分母阻断；尾差守恒。

**明确不做：**第一版不做多层制造成本系统。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

### K02｜标准与实际成本差异分析器

**形态：**单点工具　**建议阶段：**第二批

**输入：**标准及实际数量单价、对象映射。

**用户拿走的结果：**价格用量等因素差异及桥接表。

**首版核心规则：**明确选用分解公式和交叉项；因素之和回到总差额。

**明确不做：**不可隐藏无法解释的残差。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-M01 CFI Driver-Based Planning Guide](https://corporatefinanceinstitute.com/resources/fpa/driver-based-planning-guide/)：驱动式预算。明确驱动因素、假设和情景，再计算结果。

### K03｜存货库龄与周转分析器

**形态：**分析看板　**建议阶段：**第二批

**输入：**库存、入出库日期和价值/数量。

**用户拿走的结果：**库龄区间、周转指标和滞留明细。

**首版核心规则：**没有批次追踪时显示估算口径；单位换算显式。

**明确不做：**不把库龄自动视为减值金额。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。

### K04｜存货盘点差异核对器

**形态：**单点工具　**建议阶段：**第二批

**输入：**账面库存和实盘清单。

**用户拿走的结果：**盘盈盘亏、错码错单位和待复核记录。

**首版核心规则：**按仓库物料批次粒度核对；重复盘点不能静默覆盖。

**明确不做：**不生成未经复核的自动调整凭证。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。

### K05｜存货跌价准备测算器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**存货账面价值与用户确认的可变现净值依据。

**用户拿走的结果：**测算底稿、分组汇总及变化表。

**首版核心规则：**估计参数、测算日和例外依据留痕。

**明确不做：**不自动判断可变现净值或作合规保证。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

## 资产与租赁（4款）

### A01｜固定资产折旧与无形资产摊销计划器

**形态：**单点工具　**建议阶段：**第二批

**输入：**资产原值、启用日、残值和指定方法。

**用户拿走的结果：**逐期折旧摊销和净值计划。

**首版核心规则：**按用户政策确定起止期；累计不越界；尾差解释。

**明确不做：**税法折旧与会计折旧不自动混同。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G04 Frappe Books](https://github.com/frappe/books)：离线会计产品参考。离线会计软件的台账、单据和报表组织方式。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

### A02｜资产台账与盘点助手

**形态：**个人工作台　**建议阶段：**第二批

**输入：**资产清单、责任人、位置和盘点记录。

**用户拿走的结果：**账实差异、位置变化和盘点底稿。

**首版核心规则：**资产唯一标识稳定；历史盘点不覆盖。

**明确不做：**不开发扫码设备集成或企业资产审批。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G03 Actual Budget](https://github.com/actualbudget/actual)：本地产品形态；代码候选。本地优先、文件保存、个人财务操作体验。

### A03｜资产处置测算器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**原值累计折旧、处置对价和用户输入税费。

**用户拿走的结果：**处置损益试算及分录底稿。

**首版核心规则：**可见公式；处置日与折旧截止日一致。

**明确不做：**不自动决定税率或审批处置。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### A04｜租赁测算底稿助手

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**现金流、期限、折现率和已选会计政策。

**用户拿走的结果：**付款现值和摊销计划、变更底稿。

**首版核心规则：**起付时点、计息期间及变更方式显式。

**明确不做：**首版不宣称覆盖全部租赁准则、豁免和复杂变更。

**建议借鉴：**

- [REF-P02 FloQast](https://www.floqast.com/)：月结工作流与复核。准备动作、证据、状态和人工确认分离。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

## 资金与融资（6款）

### T01｜银行对账与余额调节助手

**形态：**单点工具　**建议阶段：**第二批

**输入：**银行流水、银行存款日记账和截止余额。

**用户拿走的结果：**未达账项、匹配底稿与余额调节表。

**首版核心规则：**未达项目分类可复核；日记账及银行两侧平衡解释。

**明确不做：**不访问银行账户、不发起交易。

**建议借鉴：**

- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。
- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

### T02｜个人资金日报工作台

**形态：**个人工作台　**建议阶段：**第二批

**输入：**账户余额、收付款明细和自定分类。

**用户拿走的结果：**资金日报、账户变化和收支明细。

**首版核心规则：**余额口径与时间点一致；内部划转单列避免重复。

**明确不做：**不提供银行实时连接或团队资金审批。

**建议借鉴：**

- [REF-G03 Actual Budget](https://github.com/actualbudget/actual)：本地产品形态；代码候选。本地优先、文件保存、个人财务操作体验。
- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。

### T03｜13周资金预测器

**形态：**单点工具　**建议阶段：**首批

**输入：**期初资金及预期收付款事项。

**用户拿走的结果：**每周现金余额、缺口和情景对比。

**首版核心规则：**按现金日期归周；版本保留；预测与实际分开。

**明确不做：**不以利润替代现金流，不自动承诺预测准确。

**建议借鉴：**

- [REF-M02 Wall Street Prep 13-Week Cash Flow](https://www.wallstreetprep.com/knowledge/demystifying-the-13-week-cash-flow-model-in-excel/)：短期现金预测。按周组织预计收款和付款，滚动更新余额。
- [REF-P03 Lucanet xP&A（原Causal方向）](https://www.lucanet.com/en/solutions/extended-planning-and-analysis/)：驱动式计划与情景比较。把数量、价格、人员等驱动与时间、情景假设分开。

### T04｜借款还本付息计划器

**形态：**单点工具　**建议阶段：**第二批

**输入：**本金、期限、利率、付息规则及变更。

**用户拿走的结果：**逐期本息和余额计划。

**首版核心规则：**利率日数基础、频率和提前还款明确。

**明确不做：**不自动解释合同法律条款或接银行系统。

**建议借鉴：**

- [REF-P02 FloQast](https://www.floqast.com/)：月结工作流与复核。准备动作、证据、状态和人工确认分离。
- [REF-M03 Claude Academy — Build financial models](https://academy.claude.com/use-cases/build-financial-models)：情景模型与可编辑底稿。假设、计算、情景和敏感性分别呈现。

### T05｜融资方案成本比较器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**多方案本金、利息、费用和现金时点。

**用户拿走的结果：**总成本、现金流与有效成本比较底稿。

**首版核心规则：**相同币种期间口径；IRR无解多解提示。

**明确不做：**只做参数测算，不给个人贷款推荐。

**建议借鉴：**

- [REF-M03 Claude Academy — Build financial models](https://academy.claude.com/use-cases/build-financial-models)：情景模型与可编辑底稿。假设、计算、情景和敏感性分别呈现。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### T06｜外币敞口与汇兑试算器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**外币余额、历史和期末手工输入汇率。

**用户拿走的结果：**币种敞口、汇兑变化和敏感性底稿。

**首版核心规则：**报价方向一致；汇率日期及来源字段必填。

**明确不做：**不联网抓汇率、不提供套保交易建议。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

## 税务管理（4款）

### X01｜票账勾稽检查器

**形态：**单点工具　**建议阶段：**第二批

**输入：**用户导出的发票明细与账务数据。

**用户拿走的结果：**票账差异、重复候选与未关联清单。

**首版核心规则：**含税、不含税、税额分列；红字与作废状态显式。

**明确不做：**不验真、不自动开票、不连接税务平台。

**建议借鉴：**

- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-G10 invoice2data](https://github.com/invoice-x/invoice2data)：模板化单据抽取参考。以模板把文档字段转为结构化数据。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

### X02｜税会差异底稿助手

**形态：**个人工作台　**建议阶段：**专业复核后

**输入：**用户确认的差异事项、期间、依据和金额。

**用户拿走的结果：**差异台账、变动及转回底稿。

**首版核心规则：**法定依据字段、规则版本与适用期必填。

**明确不做：**海外资料仅参考底稿流程；中国规则需另行核实。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### X03｜纳税调整试算器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**用户批准的调整规则和财务数据。

**用户拿走的结果：**调整明细、计算式和异常清单。

**首版核心规则：**规则版本和地区主体适用性显式；公式确定性执行。

**明确不做：**无核验依据的税率/限额不得内置默认值。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-E02 ExcelJS](https://github.com/exceljs/exceljs)：Excel读写候选。工作簿导入导出、格式与表格处理。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### X04｜申报数据多表核对器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**用户导出的申报数据、账表和核对规则。

**用户拿走的结果：**跨表差异及待确认底稿。

**首版核心规则：**只核对指定勾稽关系，不推断未知表单语义。

**明确不做：**不自动申报、不承诺税务合规。

**建议借鉴：**

- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

## 预算与预测（5款）

### B01｜业务驱动预算模拟器

**形态：**单点工具　**建议阶段：**第二批

**输入：**数量单价、人力等驱动与假设。

**用户拿走的结果：**基准乐观保守情景和模型明细。

**首版核心规则：**假设与计算分离；公式可查看；手工覆盖留痕。

**明确不做：**不固定所有公司统一预算方法。

**建议借鉴：**

- [REF-M01 CFI Driver-Based Planning Guide](https://corporatefinanceinstitute.com/resources/fpa/driver-based-planning-guide/)：驱动式预算。明确驱动因素、假设和情景，再计算结果。
- [REF-P03 Lucanet xP&A（原Causal方向）](https://www.lucanet.com/en/solutions/extended-planning-and-analysis/)：驱动式计划与情景比较。把数量、价格、人员等驱动与时间、情景假设分开。
- [REF-M03 Claude Academy — Build financial models](https://academy.claude.com/use-cases/build-financial-models)：情景模型与可编辑底稿。假设、计算、情景和敏感性分别呈现。

### B02｜预算实际差异分析器

**形态：**分析看板　**建议阶段：**首批

**输入：**预算、实际及科目组织映射。

**用户拿走的结果：**差额差异率、重要差异清单和明细。

**首版核心规则：**收入费用有利方向配置；零预算不强算百分比。

**明确不做：**不自动编造业务变化原因。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。
- [REF-P04 IBCS](https://www.ibcs.com/ibcs-version-2-0/)：报告表达方法。统一报表表达和比较语义，让数字、情景和变化关系清晰。

### B03｜滚动预测工作台

**形态：**个人工作台　**建议阶段：**第二批

**输入：**历史实际、剩余期间预测与调整。

**用户拿走的结果：**全年展望、已关闭期间和版本快照。

**首版核心规则：**实际替换预测有记录；冻结版本不被覆盖。

**明确不做：**不做企业多人填报审批和自动系统集成。

**建议借鉴：**

- [REF-P03 Lucanet xP&A（原Causal方向）](https://www.lucanet.com/en/solutions/extended-planning-and-analysis/)：驱动式计划与情景比较。把数量、价格、人员等驱动与时间、情景假设分开。
- [REF-M01 CFI Driver-Based Planning Guide](https://corporatefinanceinstitute.com/resources/fpa/driver-based-planning-guide/)：驱动式预算。明确驱动因素、假设和情景，再计算结果。
- [REF-G03 Actual Budget](https://github.com/actualbudget/actual)：本地产品形态；代码候选。本地优先、文件保存、个人财务操作体验。

### B04｜人员编制与人工预算测算器

**形态：**单点工具　**建议阶段：**第二批

**输入：**岗位人数、入离职时间和薪资假设。

**用户拿走的结果：**按月人数及人工成本预算。

**首版核心规则：**假设税费参数用户提供；空岗与实岗区分。

**明确不做：**不替代工资实算，也不内置未核验社保税法。

**建议借鉴：**

- [REF-P03 Lucanet xP&A（原Causal方向）](https://www.lucanet.com/en/solutions/extended-planning-and-analysis/)：驱动式计划与情景比较。把数量、价格、人员等驱动与时间、情景假设分开。
- [REF-M01 CFI Driver-Based Planning Guide](https://corporatefinanceinstitute.com/resources/fpa/driver-based-planning-guide/)：驱动式预算。明确驱动因素、假设和情景，再计算结果。

### B05｜预算预测版本与假设对比器

**形态：**单点工具　**建议阶段：**第二批

**输入：**两个独立预算或预测版本。

**用户拿走的结果：**新增删除变化项、假设变化和结果桥接。

**首版核心规则：**同一粒度可比；口径变更与数值变更分别展示。

**明确不做：**不是B03的一个按钮换名；需支持独立文件对比。

**建议借鉴：**

- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-P03 Lucanet xP&A（原Causal方向）](https://www.lucanet.com/en/solutions/extended-planning-and-analysis/)：驱动式计划与情景比较。把数量、价格、人员等驱动与时间、情景假设分开。

## 经营分析与决策（5款）

### M01｜客户产品项目盈利分析器

**形态：**分析看板　**建议阶段：**第二批

**输入：**收入成本费用和分配规则。

**用户拿走的结果：**多维毛利贡献、明细及分摊说明。

**首版核心规则：**维度可配置，不拆三款同质商品；成本口径透明。

**明确不做：**无成本依据时不得把收入称利润。

**建议借鉴：**

- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。

### M02｜量价结构差异分析器

**形态：**单点工具　**建议阶段：**第二批

**输入：**两期业务量单价与组合明细。

**用户拿走的结果：**可回勾总变化的因素桥接与瀑布图。

**首版核心规则：**分解约定明确；新退出项目单列；显示交叉残差。

**明确不做：**不把数学分解当作已验证业务因果。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-P04 IBCS](https://www.ibcs.com/ibcs-version-2-0/)：报告表达方法。统一报表表达和比较语义，让数字、情景和变化关系清晰。

### M03｜盈亏平衡与定价模拟器

**形态：**单点工具　**建议阶段：**第二批

**输入：**销量、单价、单位变动成本和固定成本。

**用户拿走的结果：**盈亏平衡点、利润情景及敏感性。

**首版核心规则：**固定与变动成本假设可见；有效范围提示。

**明确不做：**不作市场需求或竞争价格预测。

**建议借鉴：**

- [REF-M01 CFI Driver-Based Planning Guide](https://corporatefinanceinstitute.com/resources/fpa/driver-based-planning-guide/)：驱动式预算。明确驱动因素、假设和情景，再计算结果。
- [REF-M03 Claude Academy — Build financial models](https://academy.claude.com/use-cases/build-financial-models)：情景模型与可编辑底稿。假设、计算、情景和敏感性分别呈现。

### M04｜投资回报测算器

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**项目现金流、贴现率、期限和情景。

**用户拿走的结果：**净现值、回收期及IRR敏感性底稿。

**首版核心规则：**期初期末时点一致；无解多解与非现金项目说明。

**明确不做：**不提供证券推荐或自动投资决策。

**建议借鉴：**

- [REF-M03 Claude Academy — Build financial models](https://academy.claude.com/use-cases/build-financial-models)：情景模型与可编辑底稿。假设、计算、情景和敏感性分别呈现。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### M05｜经营月报生成器

**形态：**分析看板　**建议阶段：**第二批

**输入：**经过核对的经营指标及人工注释。

**用户拿走的结果：**含指标、图表、明细和事实描述的本地报告。

**首版核心规则：**模板事实描述绑定具体数字；原因由人补充。

**明确不做：**不使用云AI读取实数，不编造经营原因。

**建议借鉴：**

- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。
- [REF-P04 IBCS](https://www.ibcs.com/ibcs-version-2-0/)：报告表达方法。统一报表表达和比较语义，让数字、情景和变化关系清晰。

## 财务报表与合并（5款）

### F01｜资产负债表与利润表编制助手

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**科目余额/发生额、报表映射和调整底稿。

**用户拿走的结果：**两张报表及科目到报表项目追溯表。

**首版核心规则：**采用用户确认的中国报表模板和符号规则。

**明确不做：**不能仅凭科目名猜映射，也不声称编出全部三表。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G04 Frappe Books](https://github.com/frappe/books)：离线会计产品参考。离线会计软件的台账、单据和报表组织方式。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### F02｜现金流量表底稿助手

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**现金收支明细、分类和必要调整。

**用户拿走的结果：**现金流量表辅助底稿和待分类清单。

**首版核心规则：**现金/非现金区分；分类依据和人工调整可追溯。

**明确不做：**不能只凭余额表自动还原准确现金流量表。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G04 Frappe Books](https://github.com/frappe/books)：离线会计产品参考。离线会计软件的台账、单据和报表组织方式。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### F03｜财务报表勾稽检查器

**形态：**单点工具　**建议阶段：**首批

**输入：**资产负债表、利润表、现金流量表及核对规则。

**用户拿走的结果：**勾稽结果、差额、原始单元格和规则说明。

**首版核心规则：**区分确定等式和提示性检查；不成立需显示原因。

**明确不做：**不把勾稽通过宣传为报表已审计或无错。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G07 Anthropic Financial Services](https://github.com/anthropics/financial-services)：财务工作流方法。GL Reconciler、Month-End Closer等参考工作流，把准备、核对、解释与复核分开。

### F04｜集团往来核对与抵销底稿助手

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**集团内部往来、主体映射和人工批准的抵销规则。

**用户拿走的结果：**往来差异、指定抵销底稿和来源明细。

**首版核心规则：**主体/期间/币种一致；首次限定简单内部往来。

**明确不做：**不宣称完整合并系统；不覆盖复杂股权、商誉、未实现利润。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### F05｜财报分析看板

**形态：**分析看板　**建议阶段：**第二批

**输入：**多期已确认财务报表及口径说明。

**用户拿走的结果：**财务结构、偿债盈利现金指标和变化明细。

**首版核心规则：**指标公式和数据来源可见；非可比期间提示。

**明确不做：**不是业务明细盈利分析，亦不提供投资评级。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G06 Evidence](https://github.com/evidence-dev/evidence)：数据报告方法；代码候选。用SQL和Markdown组织含数据、图表与解释的报告。
- [REF-P04 IBCS](https://www.ibcs.com/ibcs-version-2-0/)：报告表达方法。统一报表表达和比较语义，让数字、情景和变化关系清晰。

## 内控与审计（4款）

### U01｜凭证异常筛查器

**形态：**单点工具　**建议阶段：**第二批

**输入：**凭证明细及用户定义风险检查规则。

**用户拿走的结果：**异常候选、命中规则和来源明细。

**首版核心规则：**只标记线索；保留规则版本；未命中不等于无风险。

**明确不做：**不认定舞弊，不生成审计结论。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-P01 Numeric](https://www.numeric.io/)：异常优先的财务产品设计。先呈现需要处理的异常，再提供规则、来源和复核。

### U02｜审计抽样助手

**形态：**单点工具　**建议阶段：**专业复核后

**输入：**总体、抽样方法、参数和随机种子。

**用户拿走的结果：**样本、总体检查和可重复抽样记录。

**首版核心规则：**明确统计/非统计性质；随机种子记录；总体缺失提示。

**明确不做：**不自动保证样本充分适当或满足全部审计准则。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。

**发布门槛：**明确适用主体/期间/政策版本；中国规则依据另行查证；人工专业复核及金标准案例通过之前不发布合规能力承诺。

### U03｜询证函批量生成器

**形态：**单点工具　**建议阶段：**第二批

**输入：**往来对象余额、用户模板和抬头资料。

**用户拿走的结果：**本机生成的询证函及发送登记空表。

**首版核心规则：**对象与金额逐项核对；模板版本可追溯。

**明确不做：**不自动发函、不代替函证控制程序。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。

### U04｜个人内控检查底稿工作台

**形态：**个人工作台　**建议阶段：**第二批

**输入：**检查清单、证据文件和人工评价。

**用户拿走的结果：**检查底稿、证据索引和未完成事项。

**首版核心规则：**证据路径可追踪；事实和评价分开。

**明确不做：**不等于企业GRC、SOX认证或独立鉴证。

**建议借鉴：**

- [REF-G01 Anthropic Knowledge Work Plugins / Finance](https://github.com/anthropics/knowledge-work-plugins/tree/main/finance)：方法与规则结构。月结清单、分录底稿、账户核对、财务报表、差异分析与审计支持的工作步骤。
- [REF-P02 FloQast](https://www.floqast.com/)：月结工作流与复核。准备动作、证据、状态和人工确认分离。

## 通用数据工具（6款）

### D01｜Excel多文件合并拆分整理器

**形态：**单点工具　**建议阶段：**第二批

**输入：**本机文件、表头规则和拆分条件。

**用户拿走的结果：**统一表格、分拆文件及处理日志。

**首版核心规则：**保留来源文件页签行号；列映射可预览；规则可保存。

**明确不做：**不执行任意用户代码，不静默丢弃错误行。

**建议借鉴：**

- [REF-G05 OpenRefine](https://github.com/OpenRefine/OpenRefine)：数据整理方法；代码候选。把数据整理变成可检查、可复用的处理过程。
- [REF-E02 ExcelJS](https://github.com/exceljs/exceljs)：Excel读写候选。工作簿导入导出、格式与表格处理。

### D02｜双表核对助手

**形态：**单点工具　**建议阶段：**首批

**输入：**两份xlsx/CSV表、匹配键和比较规则。

**用户拿走的结果：**匹配差异、两侧缺失、歧义与无效记录底稿。

**首版核心规则：**重复键不强配；金额十进制；规则和来源可导出。

**明确不做：**不做一对多核销、模糊AI匹配或自动记账。

**建议借鉴：**

- [REF-G08 DataComPy](https://github.com/capitalone/datacompy)：Python比较库；方法参考。按键比较两份表格并组织差异结果。
- [REF-P05 Oracle Transaction Matching](https://docs.oracle.com/en/cloud/saas/account-reconcile-cloud/suarc/admin_trans_match_about.html)：核对与异常处理。导入不同来源，按规则匹配，解释和处理未匹配项。
- [REF-E02 ExcelJS](https://github.com/exceljs/exceljs)：Excel读写候选。工作簿导入导出、格式与表格处理。

### D03｜科目往来部门映射管理器

**形态：**个人工作台　**建议阶段：**第二批

**输入：**原始编码名称、目标字典和版本。

**用户拿走的结果：**映射表、未映射清单和冲突说明。

**首版核心规则：**主键与名称分开；多义映射人工确认；版本可导出。

**明确不做：**不是企业MDM，不做远程实时同步。

**建议借鉴：**

- [REF-G05 OpenRefine](https://github.com/OpenRefine/OpenRefine)：数据整理方法；代码候选。把数据整理变成可检查、可复用的处理过程。
- [REF-G02 ERPNext](https://github.com/frappe/erpnext)：业务流程参考。采购、销售、库存、资产、会计等业务对象及单据关系。

### D04｜文本型PDF表格提取器

**形态：**单点工具　**建议阶段：**第二批

**输入：**文本型PDF及用户选定表格范围。

**用户拿走的结果：**可校验表格、原文页码和导出文件。

**首版核心规则：**预览后确认；分页表头显式处理；保留来源。

**明确不做：**扫描件OCR和所有版式自动识别不在首版。

**建议借鉴：**

- [REF-G09 pdfplumber](https://github.com/jsvine/pdfplumber)：本地PDF解析代码候选。提取PDF文本、几何信息和表格。
- [REF-G10 invoice2data](https://github.com/invoice-x/invoice2data)：模板化单据抽取参考。以模板把文档字段转为结构化数据。

### D05｜Excel公式体检器

**形态：**单点工具　**建议阶段：**第二批

**输入：**xlsx工作簿及用户选定检查范围。

**用户拿走的结果：**公式错误标记、模式不一致及硬编码候选。

**首版核心规则：**静态检查与真正重算分开标示；避免把正常例外当错。

**明确不做：**不承诺复刻Excel计算引擎或修复全部公式。

**建议借鉴：**

- [REF-G07 Anthropic Financial Services](https://github.com/anthropics/financial-services)：财务工作流方法。GL Reconciler、Month-End Closer等参考工作流，把准备、核对、解释与复核分开。
- [REF-E02 ExcelJS](https://github.com/exceljs/exceljs)：Excel读写候选。工作簿导入导出、格式与表格处理。

### D06｜财务数据质量体检器

**形态：**单点工具　**建议阶段：**第二批

**输入：**财务表格、字段字典和质量规则。

**用户拿走的结果：**缺失重复类型异常、质量汇总和问题行。

**首版核心规则：**只诊断不修改原始数据；允许保存规则重复检查。

**明确不做：**不是D01的同功能再包装；交付独立检查报告。

**建议借鉴：**

- [REF-G05 OpenRefine](https://github.com/OpenRefine/OpenRefine)：数据整理方法；代码候选。把数据整理变成可检查、可复用的处理过程。
- [REF-P01 Numeric](https://www.numeric.io/)：异常优先的财务产品设计。先呈现需要处理的异常，再提供规则、来源和复核。
