# "Zhixing Dojo" Learning Plugin — Design Document

> A Claude Code plugin that helps you learn new knowledge and technologies from
> scratch and *truly master* them (rather than "having read about them").
> Version: design draft v1.0 | Date: 2026-07-15 | Status: design phase, not yet built

> **Historical note** — This is the original design document, translated from
> Chinese. It captures the plan as designed; the implementation has since evolved
> in places: the hook-based architecture below was replaced by a hookless,
> write-as-you-go design (v0.6), all questioning now defaults to multiple-choice
> (v0.4.1), a one-time `/setup` skill was added (v0.7), commands shipped under the
> `/zhixing-dojo:*` namespace rather than `/dojo:*`, and the wuxia rank names
> became Bronze → Diamond tiers (v0.7.1). See [CHANGELOG.md](../CHANGELOG.md).

---

## Contents

1. [Background and the problems to solve](#1-background-and-the-problems-to-solve)
2. [Research: why popular teachers are popular](#2-research-why-popular-teachers-are-popular)
3. [Existing learning plugins and our differentiation](#3-existing-learning-plugins-and-our-differentiation)
4. [Design philosophy: the seven teaching principles](#4-design-philosophy-the-seven-teaching-principles)
5. [World and style](#5-world-and-style)
6. [Core feature design](#6-core-feature-design)
7. [The full lesson flow (the core learning loop)](#7-the-full-lesson-flow-the-core-learning-loop)
8. [Multimodal content standards](#8-multimodal-content-standards)
9. [The memory system: mastery model and spaced repetition](#9-the-memory-system-mastery-model-and-spaced-repetition)
10. [Gamification and simulation](#10-gamification-and-simulation)
11. [Technical architecture](#11-technical-architecture)
12. [MVP roadmap](#12-mvp-roadmap)
13. [Risks and design red lines](#13-risks-and-design-red-lines)

---

## 1. Background and the problems to solve

**Pain point 1: read it, forget it.** Online tutorials are one-way reading. It feels
like understanding while you read, and it's gone the next day. Cognitive science
settled this long ago: retention from passive re-reading is far below retention from
active retrieval — between "I think I get it" and "I actually get it" stands an act
of self-produced output.

**Pain point 2: the AI era demands deeper foundations.** AI can produce mountains of
code and content for you, but **the ability to accept or reject AI output cannot be
outsourced**. You need foundations solid enough to judge whether what AI wrote meets
the standard. The learning goal is therefore not merely "can do", but the top of
Bloom's taxonomy — **can evaluate**: seeing what is wrong, and what falls short, in
someone else's (including AI's) work.

**Pain point 3: text alone struggles with abstraction.** Working memory is limited;
explaining abstract concepts in prose alone carries a brutal cognitive load. Dual
coding with visuals, story analogies, and interactive animations offloads abstraction
onto visual and narrative channels.

**So this plugin is not "another tutorial generator" — it is a complete training
system:**

| Pain point | Design answer |
|------------|---------------|
| Read it, forget it | Active-recall checks + spaced-repetition queue + Feynman teach-back |
| Can't audit AI output | The original **Bug Hunt**: audit AI-style artifacts seeded with planted flaws |
| Text can't carry abstraction | Analogy stories + mermaid diagrams + single-file interactive HTML animations |
| Learning without felt reality | Simulation missions: role-play of real work scenarios |
| Giving up halfway | Mastery-gated progression + streaks + ranks + a stage map |

---

## 2. Research: why popular teachers are popular

Summary of research on 3Blue1Brown, the Feynman technique, Khan Academy, Yongle Li,
Brilliant, Duolingo, Fireship, and the cognitive-science literature:

| Teacher | Core techniques | Why it works |
|---------|-----------------|--------------|
| **3Blue1Brown** | Opens with a concrete puzzle, definitions last; every symbol has a visual counterpart | Raise the question before the answer — motivation drives attention; visuals lower working-memory load |
| **Feynman technique** | Explain in plain words to a beginner; where you stall is the gap | Retrieval practice + metacognition; "think I know" is exposed instantly |
| **Khan Academy** | Knowledge split into <10-minute pieces; no advancing without mastery, unlimited retries without penalty | Progress by understanding, not by calendar; no accumulating holes |
| **Yongle Li** | "Phenomenon → principle → elevation"; everyday analogies + rigorous derivation + humor | New knowledge docks onto lived experience; authority dissolved lowers the psychological bar |
| **Brilliant** | No lectures — a problem every screen or two; wrong answers get guided hints, not answers | Active solving beats passive watching for retention; "I figured it out" builds a positive loop |
| **Duolingo** | Streaks (loss aversion), instant XP, 3-5 minute lessons | Long goals become a daily habit loop of prompt → action → instant reward |
| **Fireship** | Hard time caps force information density; real runnable code + humor | A tiny opening cost produces the "one more" effect; humor holds the emotional curve |
| **Cognitive science** | Active recall, spaced repetition, deliberate practice, dual coding, Bloom layering, load control | "Effortful retrieval" strengthens memory (desirable difficulty) |

**Cross-case commonalities (the methodological bedrock of this plugin):**

1. Concrete before abstract — problem/phenomenon/code first, definition second
2. Active production > passive reception — say it, do it, test it
3. Instant feedback loops — correction and reward within seconds
4. Small grains, low thresholds — one concept at a time, 15-25 minutes per lesson
5. Mastery-gated progression — no advancing past what you haven't passed; unlimited retries; holes get backfilled
6. Emotional design — surprise openings, humor, accomplishment, streaks
7. Docking onto lived experience — analogies + visualization lower cognitive load

---

## 3. Existing learning plugins and our differentiation

Representative learning-oriented projects surveyed in the Claude Code ecosystem:

| Project | Structure & approach | Worth borrowing | Shortfall (our opening) |
|---------|----------------------|-----------------|--------------------------|
| **claude-teacher-plugin** | 15 commands + 5 hooks; student profile, quizzes, flashcards, roadmap; spaced repetition (interval doubles on success) | The complete profile→teach→test→track loop; hooks for archive load/save | Too many commands to learn; text-only content; no simulation, no multimodality |
| **socrates-skill** | Single-file SKILL.md; five-step Socratic questioning; iron rule "never give the answer" | The hint-ladder design; lightweight | No persistent progress, no curriculum |
| **anki-claude-code skill** | SKILL.md + reference/ progressive disclosure; card science encoded (atomic, one fact per card) | reference/ organization of method details; card science | Depends on external Anki; memory only, no understanding |
| **Khanmigo / ChatGPT Study Mode** | System-prompt layer: no answers + hint ladders + placement first + knowledge checks | The answer-constraint mechanics are all promptable | Generic products: no personal long-term state, no code-lab environment |

**This plugin's differentiation (its own style — no cloning):**

1. **The Bug Hunt** — an original mode answering the "audit AI output" need directly:
   the plugin generates AI-style artifacts with planted flaws; the learner reviews
   them as the acceptance gatekeeper. No existing plugin has this.
2. **A multimodal content pipeline** — hard concepts escalate automatically to story
   scripts or single-file interactive HTML animations (exploiting Claude Code's
   ability to write runnable HTML directly), not text-only tutorials.
3. **Simulation missions** — role-play of real work scenarios (production incidents,
   code reviews, technical interviews) that put knowledge into situations with
   consequences.
4. **A small, sharp command surface** — 6 core commands covering the whole flow,
   versus a 15-command sprawl.
5. **A unified world** — one dojo narrative runs through every mode; the emotional
   curve is designed, not an accident of stacked commands.

---

## 4. Design philosophy: the seven teaching principles

These seven principles go into the plugin's core SKILL.md and constrain all generated
teaching content:

1. **Hook first**: every lesson must open with a concrete puzzle, counter-intuitive
   phenomenon, or real incident. Opening with a definition is forbidden.
2. **Attempt before instruction**: before any concept is explained, the learner
   tries to answer/predict/do. Being wrong is a designed step, not an accident.
3. **One concept at a time**: each lesson teaches exactly one core concept and
   completes a full learning loop within 15-25 minutes.
4. **Dual coding required**: every core concept ships with at least one non-text
   expression (analogy story / mermaid diagram / interactive animation / runnable
   experiment).
5. **Hint ladders, never spoon-feeding**: wrong answers in practice get progressively
   narrower hints (clarify the question → name the relevant concept → give a
   direction → give a fragment), with the answer shown and explained only after at
   most three levels.
6. **Tested means learned**: every lesson ends with an active-recall check layered by
   Bloom's taxonomy; misses automatically enter the spaced-repetition queue.
7. **Evaluation is the destination**: a topic's final gate is not "can solve
   problems" but "can audit" — only passing the Bug Hunt counts as true mastery.

---

## 5. World and style

**Name: Zhixing Dojo (zhixing-dojo)** — from *zhi xing he yi*, "knowing and doing as
one": knowledge counts as mastered only once action has tested it.

**World**: the learner is a newly admitted disciple; each topic is a mountain; each
knowledge point is a stage on the mountain path. A fixed cast gives long-term
learning companionship and emotional memory:

| Character | Role | Appears in | Persona |
|-----------|------|------------|---------|
| **The Master** | Lead teacher | Explanations, Q&A | Yongle Li-style: rigorous but grounded, loves everyday analogies, occasionally self-deprecating |
| **A-Dai** | Slow, earnest junior apprentice | Feynman teach-back | Sincere but dim; keeps asking "why"; the learner must actually teach him |
| **The Grandmaster** | Examiner | Chapter Boss Battles | Strict, spare with words; sets integrative problems |
| **The Phantom** | Bug Hunt's master of disguise | Bug Hunt | Produces convincing but flawed artifacts; mocks those who find nothing, salutes those who catch him |

**Style red lines:**

- The world is seasoning, not the main course. Narrative dressing appears only in
  openings, settles, and character lead-ins; explanation prose stays clear and
  professional — no kung-fu theatrics inside technical content.
- A `--plain` mode: one switch in the profile turns off all narrative dressing,
  leaving only the teaching skeleton — respecting moments when the theater doesn't
  land.
- Humor density calibrated to Fireship / Yongle Li: 1-2 beats per lesson, in service
  of memory anchors, never joke-spam.

---

## 6. Core feature design

Six commands (skills) covering onboarding → learning → testing → review → auditing →
overview:

### 6.1 `/dojo:learn [topic]` — enter the dojo / continue training

The main entrance, handling three cases:

- **New topic**: placement dialogue (3-5 questions: existing base, purpose, daily
  time budget, preferred analogy domains) → generate the topic's **knowledge tree**
  (chapters → stages, with dependency edges) → save to the archive → start the
  first stage.
- **Continuing**: read the archive; if the review queue has due cards, insert a
  5-minute quick review first (spaced repetition outranks new content), then
  continue to the next uncleared stage.
- **No argument**: list all topics in progress with their status and let the
  learner choose.

### 6.2 `/dojo:map` — the learning map

Render the topic's knowledge tree in mermaid: cleared stages (star counts), current
position, locked stages, dependency edges at a glance. Also show streak days, rank,
and review-queue backlog. This is the "checkable outline" progress-visualization
satisfaction of coding-interview-university.

### 6.3 `/dojo:quiz [topic/chapter]` — the sparring grounds (checks)

- Normally: Bloom-layered mini-tests over the given scope (1-2 questions each for
  recall → comprehension → application → analysis); misses enter the review queue
  tagged with an error type (concept confusion / boundary conditions / plain
  forgetting).
- When a chapter completes, it automatically becomes a **Boss Battle**: the
  Grandmaster sets an integrative applied problem (a situated design/debugging
  challenge); passing raises the whole chapter's stars.
- Question rule: wrong options must come from real, common misconceptions (drawing
  first on the learner's own mistake history — "aimed at *your* misconceptions").

### 6.4 `/dojo:review` — review (spaced repetition)

Clear the due review queue. Not dry flashcards — three randomized forms: rapid-fire
Q&A / A-Dai asks and you answer / 30-second applied mini-scenarios. Intervals double
on success; failure resets the interval and re-teaches (see section 9).

### 6.5 `/dojo:teach` — teach-back (Feynman mode)

The learner lectures **A-Dai**. A-Dai's behavior rules:

- Zero pretend-understanding: any vague phrasing gets "what does that mean?"
- Analogy testing: he pushes your analogy to its extreme to see where it fails
  ("but by your logic, wouldn't X contradict…?")
- At the end A-Dai recites what he "learned"; errors in his recitation mean you
  didn't teach it clearly — stall points auto-generate a gap list, and the
  corresponding stages go back into the furnace.

### 6.6 `/dojo:hunt [topic/chapter]` — the Bug Hunt (auditor training) ★ signature

Directly trains the ability to evaluate AI output:

1. **The Phantom**, drawing on what you've learned, generates an "AI-style
   artifact" — a piece of code / a technical design / an architecture sketch — with
   1-4 **planted flaws** (count undisclosed).
2. Flaws are tiered: obvious errors (syntax/factual) → hidden errors (boundary
   conditions, concurrency, misused APIs) → higher-order problems (runs fine but
   violates best practice / performance traps / security risks) — plus the
   occasional **clean round** (a genuinely flawless artifact: daring to say "no
   issues" is also an audit skill).
3. The learner delivers a review: locations, why each is wrong, suggested fixes.
4. Settle: missed plants are explained one by one and enter the review queue;
   flagging non-existent "bugs" (false positives) also scores — an auditor must
   neither miss nor cry wolf.

Passing a chapter's Bug Hunt is required for that chapter's highest star rating.

---

## 7. The full lesson flow (the core learning loop)

One stage = one lesson = 15-25 minutes = one complete learning loop. This is the
heart of the plugin's quality, fixed in the `learn` skill:

```
① Hook (1-2 min)
   A concrete puzzle / counter-intuitive phenomenon / real incident.
   E.g. learning TCP → "Why does a phone call open with three wasted lines —
   'Hello?' 'Hello!' 'OK, so…'?"

② Your Turn (2-3 min)
   The learner guesses/predicts/tries. Right or wrong, proceed — the answer is
   planted now and paid off during the explanation.

③ Explain (5-8 min)
   One concept, one non-text expression (analogy/diagram/animation/experiment,
   chosen per section 8). Fixed Yongle-Li three-act structure:
   phenomenon → principle → elevation (its links to what's already learned).

④ Hands-On (3-5 min)
   Programming: predict-then-run experiments (guess the output, actually run it,
   study the difference).
   Non-programming: tweak parameters in the interactive animation, or a small
   scenario judgment.

⑤ Check (3-4 min)
   2-4 Bloom-layered questions. Wrong answers walk the hint ladder (max three
   levels); misses enter the review queue.

⑥ Settle (30 sec)
   XP + mastery update + map lights up + a teaser hook for the next stage
   (serialization — "to be continued").
```

A stage whose check wasn't passed doesn't unlock the next stage (Khan-style
mastery gating), but the learner can explicitly say "skip" — the plugin respects it
while marking the stage "unresolved" on the map and weighting it heavier in review.

---

## 8. Multimodal content standards

The concrete landing of "not text-only". The Explain step picks its form by
**concept type**; the rules go into `reference/content-formats.md`:

| Concept type | Preferred form | Examples |
|--------------|----------------|----------|
| Process / sequence / state change | **mermaid** (sequenceDiagram / stateDiagram) | TCP handshake, event loop, state machines |
| Multi-party interaction, mechanisms with "motives" | **Story script**: personified dialogue | The handshake as two stutterers on the phone; Raft election as a tribe choosing a chief |
| Continuous change / spatial structure / parameter sensitivity | **Single-file interactive HTML animation**: self-contained, no CDNs, sliders/buttons, learn by fiddling | Hash-collision visualizer, gradient-descent ball, B+ tree split animation |
| Verifiable behavior (programming) | **Predict-then-run experiment**: real runnable code, predict before running | Closure traps, float precision, race conditions |
| Hierarchy / classification / comparison | Tables + mermaid mind maps | Lock types compared, HTTP version history |

**HTML animation standards** (`reference/animation-guide.md`):

- Single file, self-contained (CSS/JS inline), double-click to open; rendered as an
  Artifact where Claude Code supports it.
- Interactivity required: at least one slider/button that lets the learner change a
  parameter and watch — only a *playable* picture offloads cognitive load; a
  play-only animation is worth less than a static diagram.
- The animation serves exactly the current concept; nothing unrelated on screen
  (cognitive-load principle).
- Generated animations are stored in the topic's asset directory and can be
  reopened during review.

**Story standards** (`reference/story-guide.md`):

- Character motives must map to the concept's real constraints (the stutterer's
  "afraid you didn't hear me" *is* the unreliable channel); skin-deep costume
  without constraint mapping is banned.
- Every story ends with a "story ↔ terminology" table, landing the narrative in
  rigorous terms — the story is scaffolding; terminology is the deliverable.

---

## 9. The memory system: mastery model and spaced repetition

### 9.1 The mastery model (0-5 stars per knowledge point)

| Stars | Meaning | Earned by |
|-------|---------|-----------|
| ☆ 0 | Unseen | — |
| ★ 1 | Studied | Completed the stage's learning loop |
| ★ 2 | Can solve | Check passed (Bloom recall + comprehension) |
| ★ 3 | Can apply | All application/analysis questions correct in `/quiz`, or used correctly in a simulation (the in-lesson check caps at ★ 2) |
| ★ 4 | Can explain | Feynman teach-back passed (A-Dai's recitation error-free) |
| ★ 5 | Can audit | Caught the related plant in a Bug Hunt |

Stars decay: knowledge points past their review interval dim on the map (a visual
nudge) and relight after a passed review.

### 9.2 Spaced repetition

- Algorithm: simplified SM-2. Initial interval 1 day; doubles on success
  (1→2→4→8→16→32, capped at 60); failure resets to 1 day and triggers a micro
  re-lesson.
- Queue injection: the SessionStart hook checks due cards; before any `/dojo:*`
  command, a backlog of ≥5 prompts a "review debt" notice; `/dojo:learn` inserts a
  5-minute quick review before new content (old knowledge before new).
- Card science (borrowing the Anki ecosystem's rules): one card one fact, atomic,
  self-contained, prefer "why / what happens if" over bare recitation.

---

## 10. Gamification and simulation

### 10.1 Gamification (a Duolingo-style habit loop, used with restraint)

- **XP and ranks**: XP at every settle; rank names follow wuxia cultivation stages
  (Fresh to the Jianghu → First Small Wins → Finding the Groove → Mastery Through
  Integration → Perfected Craft → Summit of the Peak), computed per topic.
- **Streaks**: consecutive learning days, announced by the SessionStart hook.
  One broken day can be repaired with a "Retreat Token" (1 per month) — loss
  aversion without manufactured anxiety.
- **Achievement badges**: few and meaningful — "Golden Eyes" (correctly judging a
  clean round has no flaws), "True Teacher" (a teach-back passed in one go),
  "Sky Mender" (clearing a 20-card backlog).
- **Red line**: rewards appear only at settles, never interrupting the middle of a
  learning loop; no daily-task checklists and their attendance pressure.

### 10.2 Simulation (where "immersive realism" lands)

Chapter Boss Battles and topic finals use **situated simulation**, not test papers:

- **Incident on call**: you're the newly hired engineer; production is down (cache
  stampede / deadlock / memory leak). The Grandmaster plays your anxious lead,
  feeding new clues as you ask; you localize and fix within the dialogue. Every
  knowledge point you use counts toward mastery.
- **The review meeting**: the Phantom submits a PR / design doc; you are the
  reviewer — the Bug Hunt embedded in a real workflow.
- **The interview room**: a simulated technical interview; the Grandmaster probes to
  the edge of your knowledge — the edge *is* the gap list.
- Simulation scripts follow `reference/simulation-guide.md`: scripts must pace
  **staged information disclosure** (never all conditions up front), because that is
  how information actually arrives in real work.

---

## 11. Technical architecture

### 11.1 Directory layout (per the official plugin spec)

```
zhixing-dojo/
├── .claude-plugin/
│   └── plugin.json                # manifest: name "zhixing-dojo"
├── skills/
│   ├── learn/
│   │   ├── SKILL.md               # the main loop (placement, tree, lesson loop)
│   │   └── reference/
│   │       ├── teaching-method.md # the seven principles + per-step playbook
│   │       ├── content-formats.md # multimodal selection rules
│   │       ├── animation-guide.md # HTML animation standards
│   │       └── story-guide.md     # story standards
│   ├── map/SKILL.md               # learning-map rendering
│   ├── quiz/
│   │   ├── SKILL.md               # checks + Boss Battles
│   │   └── reference/quiz-guide.md    # Bloom question standards, distractor design
│   ├── review/SKILL.md            # spaced repetition
│   ├── teach/SKILL.md             # Feynman teach-back (A-Dai's rules inline)
│   └── hunt/
│       ├── SKILL.md               # the Bug Hunt
│       └── reference/
│           ├── bug-taxonomy.md    # planted-flaw taxonomy (tiered)
│           └── simulation-guide.md# simulation script standards (shared with Boss Battles)
├── agents/
│   ├── animator.md                # animator: builds single-file HTML per the guide
│   └── phantom.md                 # the Phantom: generates flawed artifacts in an
│                                  #   isolated context (if the main conversation
│                                  #   planted the bugs itself, it would "know the
│                                  #   answers" and leak them through tone)
├── hooks/
│   └── hooks.json                 # SessionStart: load archive + announce streak
│                                  #   + check review queue
│                                  # Stop: remind about unsettled progress
└── scripts/
    ├── load-profile.sh            # for hooks: read archive, emit context summary
    └── due-cards.sh               # for hooks: count due review cards
```

Design notes:

- **Skills lead, agents assist**: all teaching flows live in skills (the
  master-and-student interaction needs full conversational context); only two jobs
  go to subagents — animation generation (large outputs, isolated to avoid flooding)
  and the Phantom's problem-setting (**must** be isolated: a main conversation that
  plants its own bugs "knows the answers" and its hinting tone leaks them; the
  subagent hands back only the artifact and a sealed answer key).
- **reference/ progressive disclosure**: SKILL.md stays a <100-line flow skeleton;
  method details live in reference files loaded on demand, controlling context cost.

### 11.2 Data persistence (`${CLAUDE_PLUGIN_DATA}`)

The official persistent data directory keeps learning state across sessions and
projects:

```
${CLAUDE_PLUGIN_DATA}/
├── profile.json          # learner profile: base, goals, time budget, analogy
│                         #   preferences, plain-mode switch, streak, retreat tokens
├── topics/
│   └── <topic-slug>/
│       ├── syllabus.json # knowledge tree: chapters → stages, dependency edges,
│       │                 #   per-stage star ratings
│       ├── mistakes.json # mistake history: question, error type, timestamp
│       │                 #   (fuel for targeted questioning)
│       └── assets/       # generated animations (HTML), story texts (reopenable)
├── review-queue.json     # global review queue: cards, current interval, due time
└── achievements.json     # achievements and ranks
```

A `syllabus.json` stage node:

```json
{
  "id": "tcp-handshake",
  "title": "TCP three-way handshake",
  "chapter": "Connection management",
  "deps": ["tcp-overview"],
  "stars": 3,
  "last_reviewed": "2026-07-14",
  "skipped": false
}
```

### 11.3 Hook design

- **SessionStart**: `load-profile.sh` reads the profile + due-card count and injects
  it as context — the effect is opening a session to "streak 12 days | 3 cards due |
  last stopped at Connection Management stage 2".
- **Stop**: when a session ends with unwritten progress (star changes, new
  mistakes), remind to write the archive back.
- No high-frequency hooks (PostToolUse etc.) — a teaching plugin must not disturb
  the user's normal coding sessions.

### 11.4 Where course content comes from

Content is generated by the model on the fly, constrained by three layers of quality
control:

1. **Knowledge tree first**: generate the global outline first (learner can confirm
   and adjust), then expand stage by stage — no fragmentary drift.
2. **Standards constrain generation**: all content generation follows the
   reference/ standards (hook openings, mandatory dual coding, question rules) —
   never freestyle.
3. **Optional external anchors**: during placement the learner can supply
   authoritative material (official docs URL, textbook chapters); the knowledge tree
   aligns to that body's structure, cutting hallucination risk — in the spirit of
   teachyourselfcs's "few, authoritative resources".

---

## 12. MVP roadmap

| Version | Contents | What it validates |
|---------|----------|-------------------|
| **v0.1 The core loop** | plugin.json + `learn` (placement, knowledge tree, full lesson loop) + `map` + `quiz` + persistence + SessionStart hook | Does the loop actually feel better than "reading a tutorial"? Knowledge-tree quality |
| **v0.2 The memory system** | `review` spaced repetition + `teach` teach-back + streak/XP/ranks + Stop hook | Next-day return rate; does the review loop ease "read it, forget it"? |
| **v0.3 Multimodality** | animator subagent + animation/story standards fully on + asset directory | Do animations/stories visibly help with hard concepts? |
| **v0.4 The auditor** | `hunt` Bug Hunt + phantom subagent + Boss Battle simulation scripts + achievements | Plant quality (hidden enough, and cleanly explainable) |

End each phase with a real-topic field test (pick a technology you genuinely want to
learn as the first pilot; tune as you go).

---

## 13. Risks and design red lines

| Risk | Mitigation |
|------|------------|
| Factual errors in generated teaching content | Anchor to authoritative material at placement; plant answers generated and cross-checked by an isolated subagent; encourage the learner to challenge explanations at any time (challenging *is* the training goal) |
| Gamification becomes noise | Rewards only at settle points; `--plain` one-switch bare mode |
| The world upstages the content | Narrative only in openings/settles/character lead-ins; explanation prose stays professional |
| Review-queue pileups breed frustration | At ≥20 cards, auto-trigger "Sky Mender mode": keep only the 10 most critical by forgetting probability; the rest downgrade to optional |
| Lessons too long to sustain | Hard 15-25 minute cap per stage; any step can "checkpoint" and resume next time |
| Context bloat (archives grow with long courses) | Archives split across files, loaded on demand; syllabus stores structure and stars only, never full lesson text |

---

## Appendix: the design in one sentence

> **Swap "reading tutorials" for "entering the dojo": every concept starts as a
> puzzle, gets explained through stories and animations, and forces you to do it
> with your hands, say it with your mouth, and audit it with your eyes — until you
> have earned the right to grade AI's output.**
