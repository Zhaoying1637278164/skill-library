# Changelog

## 0.7.2

- Star-rule conflict resolved: the mastery model's ★3 row could be read as granting
  3 stars from the in-lesson check's application/analysis questions, contradicting
  the lesson loop's settle rule (check passed → ★2). Unified on the settle rule:
  the in-lesson check caps a stage at ★2; ★3 comes only from `/quiz` or the chapter
  Boss Battle. Each star now names exactly one gateway (lesson → ★2, quiz/Boss → ★3,
  teach → ★4, hunt → ★5).

## 0.7.1

- Rank tiers replace belt ranks: 🥉 Bronze (<25%) → 🥈 Silver (<50%) → 🥇 Gold
  (<75%) → 💠 Platinum (<100%) → 💎 Diamond (100%), by total stars / max stars.

## 0.7.0 — Skill-craft tightening

After studying Matt Pocock's skill-writing principles:

- `/setup`: one-time archive + preferences bootstrap (language, analogy domains,
  pace, narrative style); other skills drop onboarding boilerplate and redirect to
  `/setup` when the archive is missing.
- Descriptions rewritten to the trigger formula: identity sentence + one trigger per
  branch, leading word front-loaded.
- Invocation audit: `/setup` and `/map` carry `disable-model-invocation` — zero
  context load in unrelated sessions.
- Completion criteria on every lesson-loop step (guards against premature
  completion).
- Positive-phrasing pass: the Bug Hunt's answer-key rules restated as "the key stays
  sealed until…" instead of a list of prohibitions.
- Authoritative anchors asked by default when building a knowledge tree; model
  knowledge is the named fallback.
- Topic `goal` moved from profile.json into each topic's syllabus.json.

## 0.6.0 — Hookless redesign

- SessionStart/Stop hooks removed: zero footprint outside the dojo's own commands.
- Persistence became write-as-you-go: streak updates when work starts;
  misses/cards/stars hit disk the moment they occur.
- `/learn` keeps a lesson `checkpoint.json` (interrupted lessons resume); `/hunt`
  marks finished rounds with `result.json`.

## 0.5.0 — English for a global audience

- All skills, references, agents, scripts, demo UI, and README translated to
  English; lessons are delivered in the learner's language (stored in
  profile.json).
- Localized flavor over literal translation: belt ranks, Retreat Token, and a
  globally legible cast (Master, A-Dai, Grandmaster, Phantom).

## 0.4.1

- All questioning defaults to multiple-choice (placement, guesses, predictions,
  checks, review cards) with MCQ guardrails: no option-elimination hints,
  "why not X?" follow-ups, option reshuffling on repeated cards.

## 0.4.0 — The auditor

- `/hunt` Bug Hunt: audit a Phantom-generated artifact with 1-4 planted bugs or a
  clean round; misses and false positives both count; caught bugs raise stages to
  5 stars.
- phantom subagent with the sealed answer key (no-leak design).
- Planted-bug taxonomy (T1 obvious / T2 hidden / T3 runs-but-costly).
- Simulation script standards for Boss Battles (three acts, clue table, rubric).
- Achievements system.

## 0.3.0 — The multimodal system

- animator subagent: self-contained interactive single-file HTML animations
  (mandatory tunable control, visual↔term mapping panel, light/dark theme).
- Asset library with per-topic `assets/index.json`; failed reviews reopen old
  assets.
- Reference implementation: `examples/gradient-descent.html`.

## 0.2.0 — The memory system

- `/review`: dedicated spaced-repetition sessions (interval doubling, micro-relesson
  on failure, Backlog Rescue mode).
- `/teach`: Feynman teach-back with apprentice A-Dai; passing raises a stage to
  4 stars.
- Stop-hook save reminder (later replaced in 0.6.0).

## 0.1.0 — The core lesson loop

- `/learn`: placement interview → knowledge tree → the six-step lesson loop
  (Hook → Your Turn → Explain → Hands-On → Check → Settle).
- `/map`: mermaid learning map with mastery stars.
- `/quiz`: Bloom-layered checks + chapter Boss Battles.
- Multimodal explanation standards; persistent state under
  `${CLAUDE_PLUGIN_DATA}`.
