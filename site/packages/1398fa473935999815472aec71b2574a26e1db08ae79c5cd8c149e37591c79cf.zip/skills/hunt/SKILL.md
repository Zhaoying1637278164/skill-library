---
name: hunt
description: Bug Hunt — audit an AI-style artifact with planted flaws. Use when the user wants to practice reviewing AI output, or to earn a stage's 5th star.
argument-hint:
- topic or chapter
---

# /hunt — Bug Hunt (auditor training)

The dojo's summit stage: the **Phantom** (phantom subagent) produces a convincing
"AI-generated" artifact; the user audits it as the reviewer of record. A reviewer must
neither miss real flaws nor cry wolf — and in the occasional **clean round** (a
genuinely flawless artifact), daring to sign off "no issues" is itself the skill.

Data directory: `${CLAUDE_PLUGIN_DATA}` (fallback `~/.claude/plugins/data/zhixing-dojo`).
If profile.json is missing, point the user to `/zhixing-dojo:setup` and stop.
Round files live in `topics/<topic-slug>/hunts/<YYYYMMDD>-<chapter-slug>/`
(the artifact file + answer-key.json). Learner-facing output follows profile.json
`language`.

## The sealed key (this skill's lifeline)

1. The Phantom plants bugs in isolation and seals the answers in answer-key.json.
2. **The key stays sealed until the user confirms their final review.** While it is
   sealed, everything you know about the round is the artifact file itself — present
   it as-is, let the user's own analysis drive the round, and meet interim guesses
   with neutral acknowledgments ("noted — keep going"). A host who knows the answers
   leaks them through tone; staying ignorant is what keeps the game honest.
3. Your first read of answer-key.json is the moment grading begins.

## Flow

1. **Scope**: read syllabus.json. Entry requirement: the target chapter has
   `boss_cleared: true` (you must be able to apply before you can audit). If not met,
   say what's missing and point to `/zhixing-dojo:quiz`. If a previous round's
   directory has an artifact but no `result.json`, that round was interrupted —
   offer to resume it instead of generating a new one.
2. **Summon the Phantom**: invoke the phantom subagent via the Agent tool with its
   full input contract (see agents/phantom.md): the chapter's knowledge points,
   excerpts from mistakes.json, priority stages (stars < 5), the artifact genre
   (by topic: code module / design doc / config / SQL), the tier definitions from
   [reference/bug-taxonomy.md](reference/bug-taxonomy.md), the learner's language,
   and both output paths.
3. **Set the scene**: show the artifact (from the artifact file alone — the key is
   sealed). Brief the audit task:
   - For each problem: its **location**, **why it's wrong**, and **how to fix it**;
   - "No issues — ship it" is a legal verdict: clean rounds exist;
   - No time limit; for code, "run it and see" is allowed (Bash) — real reviewers do
     exactly that.
4. **Collect the verdict**: when the user finishes, confirm "is this your final
   review?" — only then grade.
5. **Grade** (now read answer-key.json):
   - **Caught**: location right and reasoning essentially correct (wording doesn't
     matter, key points do) → XP +100 per bug.
   - **Missed**: debrief each one — why it's wrong, why it looked right
     (plausible_because), how to fix; every missed knowledge point becomes a review
     card (interval_days: 1) and a mistakes.json entry (error_type per quiz-guide),
     written immediately as each debrief lands (write as you go; no batch saves).
   - **False positive**: flagged something that isn't wrong → explain why it's
     actually correct (often the deeper gap); also becomes a review card. Mild style
     opinions don't count as false positives — grade only correctness claims.
   - **Clean round**: user declares "no issues" → pass, achievement "Golden Eyes";
     user reported flaws → debrief them all as false positives.
6. **Settle & write back**:
   - Stages whose planted bug was caught rise to stars 5 ("can audit").
   - All bugs caught with zero false positives → achievement "Flawless Hunt".
   - Every stage in the chapter at stars 5 → the chapter gets `hunt_cleared: true`,
     achievement "Pinnacle" (first time); achievements go to achievements.json
     ({id, name, date, detail}, dedupe before appending).
   - Update profile.json streak and last_study_date the moment the review dialogue
     begins (same rules as /learn), not at the end.
   - Write `result.json` into the round's directory (verdict, caught/missed/false
     positives) — its presence marks the round finished.
   - If stages below 5 stars remain, mention another round is available — the
     Phantom will aim at exactly those points.

## Style

- The Phantom appears only at scene-set and debrief (a line or two: mocking those who
  find nothing, saluting those who catch him). During the review the host is the
  Master, strictly neutral.
- With plain_mode true, drop the Phantom persona, keep every mechanism.
- Every miss and false positive in the debrief ends with "here's how you'll spot it
  next time".
