# Planted-Bug Taxonomy

The shared standard for the Phantom's planting and /hunt's grading. When summoning the
phantom, excerpt the tier definitions and the "good bug" criteria into its prompt.

## Tiers

| Tier | Definition | Typical examples |
|------|------------|------------------|
| **T1 Obvious** | Hard errors visible against docs or common knowledge | Calling a nonexistent API, factual errors ("HTTP is a stateful protocol"), swapped argument order, wrong return type |
| **T2 Hidden** | Passes basic testing, fails under specific conditions | Boundary conditions (empty input, off-by-one, overflow), race conditions, unreleased resources, swallowed exceptions, timezone/unit confusion, float equality with ==, stale cache never invalidated |
| **T3 Runs-but-costly** | Runs fine with correct output, but buries long-term cost | N+1 queries, full table scans with no index, SQL injection / privilege escalation exposure, hardcoded secrets, misleading names or comments (the comment says one thing, the code does another), broken retry strategy (no backoff, retrying non-idempotent calls) |

## The "good bug" criteria (self-check every plant)

1. **Lands on a learned point**: every bug maps to a node_id in the chapter — this
   tests the course, not trivia.
2. **Explainable in one sentence**: a bug you can't debrief cleanly is a bad bug.
3. **Looks right**: it needs a plausible_because — AI and humans genuinely make this
   mistake this way (same source as quiz-guide's classic misconceptions). Random
   nonsense isn't a planted bug; it's noise.
4. **No word games**: no typos, no near-twin variable names (`data`/`date`) — this is
   not spot-the-difference; no bugs depending on context the artifact doesn't show.
5. **A definite fix exists**: one clearly correct alternative — never a matter of
   taste.

## Mix guidance

- 1-4 bugs per round; roughly 1 round in 5 is clean; mix tiers within a round
  (e.g. 1×T1 + 2×T2), never all one tier.
- Early chapters lean T1+T2; later chapters — or once the learner has earned a
  Flawless Hunt — raise the T2+T3 share.
- Plant preferentially in stages below 5 stars and in weak spots from mistakes.json —
  the Bug Hunt is also a targeted strike.
- **A clean round must be genuinely flawless**: prefer conservative and simple over
  accidentally planting a bug you didn't notice. A wrongly accused clean round
  destroys the training's credibility.

## Genre selection

Pick the artifact genre by topic nature, rotating across rounds:

| Genre | Fits | Where bugs hide |
|-------|------|-----------------|
| Code module | Languages, frameworks, algorithms | Logic, boundaries, concurrency, resource management |
| Design document | Architecture, system design | Capacity estimates, single points of failure, consistency assumptions, cost |
| Config file | Ops, middleware | Timeout/retry values, insecure defaults, resource limits |
| SQL / queries | Databases | Indexes, locks, isolation levels, aggregation traps |
| Review reply | Any topic (advanced play) | An "AI review of someone else's code" whose own comments are a mix of right and wrong |
