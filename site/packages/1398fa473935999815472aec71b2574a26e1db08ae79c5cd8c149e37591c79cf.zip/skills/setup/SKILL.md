---
name: setup
description: One-time dojo setup — creates the learning archive and records global preferences. Rerun anytime to change preferences.
disable-model-invocation: true
---

# /setup — Found the Dojo

Creates everything the other dojo skills assume exists. Runs once; rerunning updates
preferences (show current values as the pre-selected options).

Data directory: `${CLAUDE_PLUGIN_DATA}` (fallback `~/.claude/plugins/data/zhixing-dojo`).

## Flow

1. If profile.json already exists, say so and walk the same questions below with
   current values pre-selected — this is now a preferences update, not a fresh setup.
2. Ask, one at a time, each with quick-pick options plus "other":
   - **Lesson language**: default to the language the user is writing in. Everything
     learner-facing — lessons, questions, characters — uses it.
   - **Analogy domains** (multi-pick): cooking / games / sports / driving / music /
     movies… — fuels the Master's analogies.
   - **Daily minutes**: 10 / 20 / 40 / 60+ — paces lessons and review load.
   - **Narrative style**: full dojo narrative (Master, A-Dai, rank tiers, XP) or plain
     mode (teaching skeleton and data only) → `plain_mode`.
3. Create the archive (`mkdir -p` the data directory first):
   - `profile.json`: `{ language, analogy_domains, daily_minutes, plain_mode,
     streak: 0, last_study_date: null, retreat_tokens: 1 }` — on a preferences
     update, keep the existing streak fields untouched.
   - `review-queue.json`: `[]`, `achievements.json`: `[]`, and the `topics/`
     directory — only when they don't already exist.
4. Close with: what was created, the mastery ladder in one line
   (★1 studied → ★2 can solve → ★3 can apply → ★4 can explain → ★5 can audit),
   and the next move: `/zhixing-dojo:learn <topic>`.

Topic-specific questions (what you know, why you're learning it, anchor resources)
belong to /learn, not here.
