---
name: review
description: Spaced-repetition review of dojo material. Use when the user wants to review, or to clear due cards.
argument-hint:
- topic
---

# /review — Review Grounds (spaced repetition)

Data directory: `${CLAUDE_PLUGIN_DATA}` (fallback `~/.claude/plugins/data/zhixing-dojo`).
If profile.json is missing, point the user to `/zhixing-dojo:setup` and stop.
Learner-facing output follows profile.json `language`.

## Flow

1. **Read the queue**: from review-queue.json take cards with due ≤ today, oldest due
   first; with an argument, only that topic's cards.
   - No due cards → report queue status (total cards, next due date), suggest
     `/zhixing-dojo:learn` for new material, and stop.
   - Due cards exist → begin. Update profile.json last_study_date and streak now
     (same rules as /learn) — write as you go; nothing waits for the end.
2. **Backlog Rescue**: with ≥ 20 due cards, keep only the 10 longest-unreviewed as
   required, mark the rest optional and push their due to tomorrow. Tell the user
   once — encouraging, never scolding the backlog.
3. **Card by card**: one at a time, all as **multiple-choice** (per quiz-guide:
   distractors from real misconceptions; reshuffle option order on every reappearance,
   swap distractors when needed), rotating three forms within a session:
   - **Rapid Fire**: the card's question plus four options, answerable in 30 seconds.
   - **A-Dai's Confusion**: junior apprentice A-Dai voices two or three of his candidate
     understandings and the user picks the right one ("So… are X and Y the same thing?
     I figure either A… or B…") — the options *are* A-Dai's understandings.
   - **Mini Scenario**: a 2-3 sentence concrete situation, four judgments/actions to
     choose from.
4. **Grade and write back** (each card on the spot, same rules as teaching-method.md):
   - Correct: interval_days doubles (1→2→4→8→16→32, capped at 60), due = today +
     new interval.
   - Wrong: interval_days resets to 1, due = tomorrow; give a 1-2 sentence
     **micro-relesson**; append the miss to the topic's mistakes.json (error_type per
     quiz-guide).
   - Same knowledge point wrong 3 reviews in a row → mark `never-got-it`, recommend
     relearning the stage via `/zhixing-dojo:learn`, and push the card's due past the
     relearn.
   - **Reopen assets**: if the missed point has entries in the topic's
     assets/index.json, prefer reusing them for the micro-relesson — replay the
     animation, rerun the experiment, reread the story. Faster than a fresh
     explanation and consistent with the original mental model.
5. **Settle**:
   - Report: cards cleared, accuracy, when the next batch comes due; a restrained
     word of praise if the queue is fully cleared. XP: +20 per correct card.
   - Clearing ≥ 10 due cards in one session → achievement "Sky Mender"
     (achievements.json, dedupe before appending; include in the report).

## Rules

- The hint ladder does not apply here: reviews test retrieval — if the answer won't
  come, reveal it, micro-relesson, reset the interval, keep the pace brisk
  (≤ 1 minute per card).
- Cards are self-contained; never depend on the session they came from.
- With plain_mode true, drop the A-Dai form (use Rapid Fire and Mini Scenario only)
  and the narrative reporting.
- This skill teaches nothing new and never touches syllabus.json stars.
