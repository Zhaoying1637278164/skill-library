---
name: map
description: The learning map — knowledge tree with mastery stars, streak, rank tier, and review backlog.
argument-hint:
- topic
disable-model-invocation: true
---

# /map — The Learning Map

Data directory: `${CLAUDE_PLUGIN_DATA}` (fallback `~/.claude/plugins/data/zhixing-dojo`).
If profile.json is missing, point the user to `/zhixing-dojo:setup` and stop.
Learner-facing output follows profile.json `language`.

## Flow

1. Read profile.json and each topic's syllabus.json under topics/. With an argument,
   show only that topic; with several topics and no argument, render a compact
   chapter-level view of each and let the user pick one to expand.
2. Render the knowledge tree as a mermaid flowchart:
   - One node per stage, labeled `Stage name ★★★★☆` (stars rendered from `stars`,
     5 is full mastery).
   - Dependencies as edges; chapters as subgraphs.
   - Node states: cleared (stars ≥ 2) green; the current stage (next to learn)
     highlighted; dependency-locked gray; skipped ones flagged ⚠ unresolved.
3. Below the map, one status line:
   `🔥 streak N days | rank | 📮 M review cards due | topic progress x/y stages`.
   - Rank tier from total stars / max stars: <25% 🥉 Bronze, <50% 🥈 Silver,
     <75% 🥇 Gold, <100% 💠 Platinum, 100% 💎 Diamond.
   - If achievements.json has entries, add one badge-wall line:
     `🏅 First Steps · True Teacher · Flawless Hunt …` (names only; expand detail
     only if asked).
4. One action suggestion (first match wins): ≥ 5 cards due → suggest
   `/zhixing-dojo:review` to pay down the review debt; a chapter fully stars ≥ 2 and
   boss not fought → suggest `/zhixing-dojo:quiz` for the Boss Battle; a chapter with
   boss_cleared and stages below 5 stars → suggest `/zhixing-dojo:hunt` to push for
   5 stars; any stage at stars = 3 → suggest `/zhixing-dojo:teach` for 4 stars;
   otherwise name the next stage.

Read-only: this skill never modifies archive files. With profile.json
`plain_mode: true`, drop ranks and narrative — just the diagram and numbers.
