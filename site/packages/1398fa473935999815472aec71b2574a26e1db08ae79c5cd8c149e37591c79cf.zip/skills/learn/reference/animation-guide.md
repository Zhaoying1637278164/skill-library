# Animation Guide (caller's view)

Animations are produced by the **animator subagent** (agents/animator.md — its spec is
built into its system prompt). This file covers: when an animation is worth it, how to
invoke, and how assets get registered.

## When to animate

Animations cost more than any other form. Use one only when **all three** hold:

1. The concept is of the "continuous change / spatial structure / parameter
   sensitivity" kind (see the table in content-formats.md);
2. Neither a mermaid diagram nor a story can carry it (a static picture can't show
   the *process of change* itself);
3. The concept has one clear **tunable parameter** whose turning reveals an essential
   difference (learning rate, load factor, window size…). No such knob → no animation.

At most one animation per stage. When in doubt, choose the static diagram — wrong
restraint beats wrong spectacle.

## Invoking the animator

Delegate via the Agent tool. The prompt must carry the full input contract:

- Concept name and 2-4 core points (what the learner should *see*);
- Learner context: `analogy_domains` from profile.json, plus any analogy or character
  names already used in this lesson — the animation must speak the same mental model,
  not invent a second one;
- **The learner's language** (from profile.json) — all on-screen text uses it;
- Output file absolute path:
  `<data-dir>/topics/<topic-slug>/assets/<node-id>-<short-slug>.html`;
- Optional: the path of an existing animation as a style reference — prefer one from
  the topic's assets/index.json; otherwise the plugin's own reference implementation
  `examples/gradient-descent.html` (in the plugin install directory).

When the subagent returns the file path and its suggested predict-then-verify action,
use it in the Hands-On step: have the learner **predict first** ("what do you think
happens when you push X past…?"), then open the animation to verify. A path with no
prediction task is a wasted animation.

## Asset registry (animations, stories, experiments alike)

Each topic's `assets/` directory keeps an `index.json`; register every asset the
moment it's created:

```json
{
  "node_id": "gradient-descent",
  "type": "animation",          // animation | story | experiment
  "file": "gradient-descent-lr.html",
  "title": "How the learning rate decides success",
  "created": "2026-07-16"
}
```

- Story scripts: save the story plus its story↔terminology table as
  `assets/<node-id>-story.md` and register it (type: story).
- Predict-then-run code: save as `assets/<node-id>-lab.<ext>` and register
  (type: experiment).
- Why register: reviews and relearning can **reopen old assets** — replay the
  animation, rerun the experiment, reread the story. Faster than regenerating, and
  consistent with the mental model formed the first time.
