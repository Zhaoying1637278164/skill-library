# Multimodal Content Selection

The Explain step (③) picks its form by **concept type**. First match the concept to a
row below, then generate in that form. One primary form per concept — never pile on.

| Concept type | Preferred form | Examples |
|--------------|----------------|----------|
| Process / sequence / state change | mermaid diagram (sequenceDiagram / stateDiagram / flowchart) | TCP handshake, event loop, state machines |
| Multi-party interaction with "motives" | Story script (personified dialogue) | Three-way handshake as two stutterers on the phone; Raft election as a tribe choosing a chief |
| Continuous change / spatial structure / parameter sensitivity | Single-file interactive HTML animation | Hash collisions, gradient-descent ball, B+ tree splits |
| Verifiable behavior (programming) | Predict-then-run experiment | Closure traps, float precision, race conditions |
| Hierarchy / classification / comparison | Table + mermaid mind map | Lock types compared, HTTP version history |

## mermaid rules

- One diagram, one concept; ≤ 10 nodes; labels use words the learner already knows.
- Give sequence-diagram participants memorable names ("client Cleo", "server Sam")
  and keep those names consistent with the story and prose.

## Story script rules

- **Character motives must map to real constraints of the concept**: the stutterer's
  "afraid the other side didn't hear me" *is* the unreliable channel. Skin-deep
  costumes with no constraint mapping are forbidden.
- ≤ 15 lines of dialogue; ≤ 3 characters.
- Every story ends with a **story ↔ terminology table** that lands the narrative in
  rigorous terms. The story is scaffolding; the terminology is the deliverable.

## Interactive HTML animation rules

Animations are not written inline in the main conversation — **delegate to the
animator subagent** (when they're worth it, the invocation contract, and asset
registration live in [animation-guide.md](animation-guide.md)). Key points:

- Only animate when the concept has a meaningful **tunable parameter** (turning the
  knob reveals the essence); at most one animation per stage.
- After generation, guide the learner through a predict-then-verify action — never
  just drop a file path.
- Store in the topic's `assets/` and register in index.json; render as an Artifact
  where supported, otherwise tell the user to open it in a browser.

## Predict-then-run experiment rules

- 10-20 lines, genuinely runnable, containing only the trap relevant to this stage.
- Flow: show the code → learner predicts the output (multiple-choice) → run it with
  Bash → teach from the difference.
- A wrong prediction is the teachable moment: the gap *is* the concept's core.
- Store experiment code in `assets/` (named `<node-id>-lab.<ext>`) and register it
  in index.json so reviews can re-run it.
