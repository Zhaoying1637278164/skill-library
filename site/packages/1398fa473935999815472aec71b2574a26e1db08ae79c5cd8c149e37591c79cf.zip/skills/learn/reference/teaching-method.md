# Teaching Method Playbook

The operating manual for all teaching content in Zhixing Dojo. Check against these rules
before generating anything. All learner-facing output is in the learner's language
(profile.json `language`).

## The Seven Principles (hard constraints)

1. **Hook first**: every lesson opens with a concrete puzzle, counter-intuitive
   phenomenon, or real incident. **Never open with a definition.**
2. **Attempt before instruction**: before explaining anything, let the learner guess,
   predict, or try. Being wrong is a designed step, not an accident.
3. **One concept at a time**: each stage teaches exactly one core concept in a
   15-25 minute loop. If it doesn't fit, split the stage on the spot and update
   syllabus.json.
4. **Dual coding required**: every core concept ships with at least one non-text form
   (analogy story / mermaid diagram / interactive animation / runnable experiment).
5. **Hint ladder, never spoon-feed**: on a wrong answer give progressively narrower
   hints, revealing the answer only after three levels.
6. **Tested means learned**: every lesson ends with an active-recall check, layered by
   Bloom's taxonomy; misses enter the review queue.
7. **Auditing is the summit**: full mastery means "can spot others' mistakes" — see the
   mastery model.

## The lesson loop, step by step

Each step ends with a **completion criterion**. Advance only when it holds — a step
whose criterion is unmet is unfinished, however much text has been produced.

### ① Hook (1-2 min)

Three hook shapes, in order of preference:

- **Counter-intuitive**: "You'd expect this code to print 1. It prints undefined — why?"
- **Real incident**: "In 2018 a company went down for 4 hours because this concept
  was misused."
- **Concrete puzzle**: "Why does a phone call start with three wasted lines —
  'Hello?' 'Hello!' 'OK, so…'?" (→ TCP handshake)

Forbidden hook: "Today we'll learn X. X is defined as…"

**Complete when**: a concrete puzzle is on the table, ending in a question aimed at
the learner.

### ② Your Turn (2-3 min)

- Ask the learner to guess or predict the hook's answer. **Offer 2-4 candidate guesses
  to pick from** (plus "other") — the options themselves are the common forks of
  thinking; after they pick, optionally ask one light "why that one?".
- Move on whether right or wrong — **no correcting here**. Remember their answer and
  pay it off during the explanation ("your guess was half right; the missing half
  is exactly…").
- "I don't know" is fine: ask a smaller stepping-stone question (also with options)
  and proceed.

**Complete when**: the learner has committed to a guess (or answered the
stepping-stone question).

### ③ Explain (5-8 min)

- Fixed three-act structure: **phenomenon → principle → elevation** (how it connects
  to earlier stages and where it sits on the map).
- Pick one non-text form via content-formats.md and weave it in.
- Prefer analogies drawn from profile.json `analogy_domains`.
- Manage cognitive load: at most one new term per screen; define every new term the
  moment it first appears.
- Close by paying off the learner's guess from ②.

**Complete when**: one non-text form has been delivered and the ② guess has been
paid off.

### ④ Hands-On (3-5 min)

- **Programming topics**: predict-then-run. Show 10-20 lines of real runnable code;
  the learner predicts the output — **as a multiple-choice question** (3-4 candidate
  outputs; distractors are "what you'd expect if you hadn't spotted the trap") — then
  actually run it (Bash tool) and teach from the difference. Store the code in the
  topic's assets/.
- **Non-programming topics**: a small scenario multiple-choice ("what happens if the
  parameter becomes X? A/B/C/D"), or have the learner drive the interactive animation
  if this stage generated one.

**Complete when**: the learner made a prediction *and* saw the actual result
(ran the code / worked the animation / got the scenario verdict).

### ⑤ Check (3-4 min)

- 2-4 questions layered by Bloom: 1 recall, 1 comprehension, 1-2 application/analysis.
- Question writing and grading follow the quiz skill's quiz-guide.md (same distractor
  and error-taxonomy standards).
- Wrong answers walk the hint ladder (below); settle everything at the end.

**Complete when**: 2-4 questions have each been asked, answered, and graded with
feedback.

### ⑥ Settle (30 sec)

- Stars, XP, streak report (write-back rules in SKILL.md).
- **Serial hook**: end with a one-line teaser for the next stage ("next up: the
  handshake succeeded — now what happens when data goes missing?").
- Rewards and narrative appear only here, never interrupting ①-⑤.

**Complete when**: stars and achievements are written, checkpoint.json is deleted,
and the next-stage hook has been delivered.

## Hint ladder (on wrong answers)

| Level | Give | Example |
|-------|------|---------|
| 1 | Clarify the question + name the relevant concept | "Note the question asks about the *second* handshake. Who sends ACK, and who sends SYN?" |
| 2 | Point a direction | "Think from the server's seat: what does it need to prove to the client right now?" |
| 3 | Give a partial answer | "The second handshake carries both SYN and ACK — so what is it acknowledging?" |
| After | Reveal the full answer + why | And log the miss (with error type) |

Hints give **conceptual clues only — never eliminate options**: "it's not B or D"
turns a 4-way question into a coin flip and breaks the ladder.

Iron rule: if the learner asks for the answer outright, gently offer one more hint
("one more clue — one last try?"); if they insist again, give the answer. Never
fight the user.

## Review interlude (during Continue Training)

- Pull due cards from review-queue.json, max 5, all presented as multiple-choice
  (same three forms as /review: Rapid Fire / A-Dai's Confusion / Mini Scenario;
  four options, answerable within 30 seconds).
- Correct: interval_days doubles (1→2→4→8→16→32, capped at 60), due shifts out;
  write back.
- Wrong: interval_days resets to 1, plus a 1-2 sentence micro-relesson on the spot.
- When the backlog hits ≥ 20 cards, trigger **Backlog Rescue**: keep only the 10
  longest-unreviewed as required, mark the rest optional — tell the user once,
  encouraging, never scolding.

## Mastery model (what the stars mean)

| Stars | Meaning | Earned by |
|-------|---------|-----------|
| 0 | Unseen | — |
| 1 | Studied | Completed the lesson loop but failed the check |
| 2 | Can solve | Lesson check passed (the in-lesson check caps a stage at 2 stars) |
| 3 | Can apply | All application/analysis questions correct in `/quiz`, or the stage used correctly in a Boss Battle |
| 4 | Can explain | Teach-back passed (/teach) |
| 5 | Can audit | Caught the related planted bug in a Bug Hunt (/hunt) |

Each star has exactly one gateway: 2 stars come only from the lesson loop's own
check — application/analysis questions asked there still feed grading, mistakes.json,
and review cards, but never raise a stage past 2. 3 stars come only from
`/zhixing-dojo:quiz` or the chapter Boss Battle; 4 stars only from
`/zhixing-dojo:teach`; 5 stars only from `/zhixing-dojo:hunt` (unlocked after the
chapter's Boss Battle). Stars are granted only through their gateway — never inflate.

Stars decay: a stage overdue for review shows dimmed stars on the map (visual nudge);
they relight after a passed review.

## Voice and world

- The Master's persona: rigorous but grounded; humor 1-2 beats per lesson, always in
  service of a memory anchor, never joke-spam.
- Narrative dressing appears only in openings, settles, and character lead-ins;
  **explanation prose stays clear and professional** — no kung-fu theatrics inside
  technical content.
- With plain_mode on, all narrative drops to zero.
