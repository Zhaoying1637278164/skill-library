# Question & Grading Standards

Shared by /quiz and the /learn check step (⑤). All questions in the learner's language.

## Bloom-layered questions

| Level | Tests | Example stem |
|-------|-------|--------------|
| Recall | Key facts, terms | "Which flags does the second handshake carry?" |
| Comprehension | Explain in own words, judge true/false | "Why isn't a two-way handshake enough? One sentence." |
| Application | Use in a new situation | "The client sends SYN then goes offline. What happens on the server?" |
| Analysis | Decompose, find causes, compare | "Which step in this packet capture is abnormal, and what could cause it?" |

- **Default to multiple-choice throughout**: single-answer with four options (A-D);
  use multi-select only for "several are true" points and label it clearly as
  multi-select. Respect a learner who asks to answer freely.
- Application/analysis levels use **scenario multiple-choice**: the stem sets a
  concrete situation; the options are 4 actions/judgments/causes, where distractors
  are choices that *would* be right in a different situation but not this one —
  testing judgment, not memory.
- Stems must be **self-contained**: no "the code mentioned earlier"; the question
  alone is answerable.
- Prefer "why / what happens if" over bare term recitation.

## Distractor design

- Distractors must come from **real, common misconceptions**, never filler. Three
  sources by priority:
  1. This learner's own history in mistakes.json (same misconception, new clothes);
  2. Classic misunderstandings of the concept ("HTTPS encrypts, so SQL injection
     isn't a concern");
  3. Boundary traps (off-by-one, empty input, concurrent timing).
- Distractor debriefs: feedback explains *why that option is wrong and under what
  circumstances someone would believe it*.

## Error taxonomy (error_type in mistakes.json)

| Type | Meaning | Follow-up |
|------|---------|-----------|
| `concept-confusion` | Mixed A up with B | Review card becomes an A-vs-B contrast |
| `boundary` | Missed an edge condition | Review card uses a boundary scenario |
| `forgot` | Learned it, plainly forgot | Normal card, spaced repetition |
| `never-got-it` | Never truly understood | Recommend relearning the stage — don't just issue a card |

## Grading & feedback rhythm

- One question at a time, feedback immediately after each answer — never batch
  answers to the end (instant feedback loop).
- Correct: one-line reinforcement + brief acknowledgment, no confetti. Occasionally
  (once per session) follow a correct answer with "and why not X?" — the follow-up
  that catches lucky guesses, multiple-choice's known weak spot.
- Wrong: walk the hint ladder (clarify → direction → partial → answer), letting the
  learner retry at each level. **Hints give conceptual clues, never option
  elimination** — "it's not B or D" collapses four options into a coin flip and
  breaks the ladder.
- Dialogue-driven stages (Boss Battle investigation, teach-back, bug-hunt reviews)
  are not multiple-choice; they follow their own rubrics.

## Review card rules (card science)

- One card, one fact — atomic.
- Self-contained: never depends on the conversation it was born in.
- Cards are also presented as multiple-choice; content priority:
  why / what-happens-if > scenario judgment > term discrimination.
- **Reshuffle option order every time a card reappears, swapping distractors when
  needed** — otherwise spaced repetition teaches "the answer is C" instead of the
  knowledge (the #1 trap of multiple-choice review).
- No list questions ("name five features of X") — split into separate cards.
