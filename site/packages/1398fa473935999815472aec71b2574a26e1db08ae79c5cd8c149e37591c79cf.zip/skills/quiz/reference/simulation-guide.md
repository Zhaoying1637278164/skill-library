# Simulation Script Standards (Boss Battles)

A Boss Battle is not a test paper — it puts knowledge into a situation with
consequences. The heart of script quality is **staged disclosure**: real work never
hands you all the information at once; the learner earns the next clue by asking the
right question.

## Three-act structure

1. **Act I · Symptoms** (the opening gives only this): a concrete, urgent, incomplete
   situation. E.g. "3 AM page: API P99 jumped from 80ms to 6s. You're on call."
   Phenomena only — zero causal hints.
2. **Act II · Investigation** (3-6 rounds): the learner asks questions and requests
   data; the Grandmaster releases clues from the clue table.
   - Each clue is designed to **eliminate a class of hypotheses** ("CPU is normal"
     rules out compute bottlenecks); the learner should be able to say what each clue
     eliminated.
   - When a question misses, the Grandmaster answers only what was asked ("Logs?
     Nothing unusual."), never steering; only after 2 stalled rounds give one
     directional nudge (counts toward the verdict).
   - If the learner leaps to a conclusion without investigating, the Grandmaster asks
     "based on what?" — grounded intuition earns a verifying clue, ungrounded
     guessing earns nothing.
3. **Act III · Resolution**: after localization, demand a treatment plan (stop the
   bleeding first or fix the root? at what cost?), and close with one "how do we
   prevent recurrence?".

## Fix before the curtain rises (never changed mid-scene)

- Root cause: which 1-2 node_ids of this chapter it maps to;
- Clue table: 4-6 clues, each annotated with "what hypothesis class it eliminates"
  and its trigger (which question releases it);
- Red herrings: 1-2 plausible-looking but irrelevant phenomena (real incidents always
  have them);
- Verdict rubric: the knowledge points that must be covered (≥ 70% of chapter stages)
  plus the key decision points.

## Verdict

- **Pass**: root cause localized + reasonable treatment + the investigation shows
  correct use of the knowledge (lucky guess with no reasoning → fail; the Grandmaster
  notes "that was luck").
- Track each knowledge point's usage: stages used correctly rise to stars 3; misused
  or unused ones enter the gap list and the review queue.
- Each directional nudge drops the passing grade one notch (pass → barely passed)
  without changing pass/fail itself.

## Grandmaster style

- Spare with words: ≤ 3 sentences per turn; clues arrive as data/phenomena, not
  explanations.
- Pressure without cruelty: time pressure is narrative ("the boss just @-ed you"),
  never a real timer.
- On a pass, one sentence naming the learner's best investigative move; on a fail,
  name the link where they got stuck.
- With plain_mode, drop the narrative pressure; keep the three acts and clue table.

## Length control

One Boss Battle runs 15-25 minutes (one lesson's worth). The usual overrun cause is
an oversized clue table — 4-6 is the cap; split complex topics into two battles
(each chapter its own boss), never a mini-series.
