---
name: quiz
description: Checks on learned dojo material. Use when the user wants to be quizzed, or to take a chapter Boss Battle.
argument-hint:
- topic or chapter
---

# /quiz — Sparring Grounds (checks & Boss Battles)

Question writing, grading, the hint ladder, and error taxonomy all follow
[reference/quiz-guide.md](reference/quiz-guide.md) — read it first. Boss Battles
additionally follow [reference/simulation-guide.md](reference/simulation-guide.md).

Data directory: `${CLAUDE_PLUGIN_DATA}` (fallback `~/.claude/plugins/data/zhixing-dojo`).
If profile.json is missing, point the user to `/zhixing-dojo:setup` and stop.
Learner-facing output follows profile.json `language`.

## Flow

1. **Scope**: read syllabus.json. With an argument, locate that chapter/topic; without
   one, default to recently studied stages with stars ≥ 1. Only test what has been
   studied (stars ≥ 1) — unlearned stages never enter questions.
2. **Mode**:
   - Every stage in the target chapter has stars ≥ 2 and the chapter has no Boss
     Battle cleared yet → **Boss Battle mode**.
   - Otherwise → **Regular check mode**.
3. **Write as you go** (no session hook exists — never defer saves to the end):
   update profile.json last_study_date and streak the moment questioning starts
   (same rules as /learn); write each miss to mistakes.json and review-queue.json
   immediately after the question is graded; write star changes to syllabus.json
   the moment they're earned. The settle step only reports — everything is already
   on disk.

## Regular check mode

- 5-8 questions covering the scoped stages; Bloom mix: recall 30%, comprehension 30%,
  application/analysis 40%.
- **Targeted strikes**: read mistakes.json first; the learner's past error patterns
  get priority (same concept, new situation).
- One question at a time, instant feedback after each answer (correct → one-line
  reinforcement; wrong → hint ladder per quiz-guide.md).
- Star rules (written to syllabus.json as soon as a stage's questions are all
  graded): stages with all application/analysis questions correct rise to stars 3;
  recall + comprehension all correct rise to 2.
- Misses (written immediately per question): append to mistakes.json (with error
  type) and create review cards in review-queue.json (interval_days: 1, due:
  tomorrow). A knowledge point already in the queue gets its interval reset instead
  of a duplicate card.

## Boss Battle mode (chapter exam)

Hosted by the **Grandmaster** (strict, spare with words). Not a test paper — a
**scenario simulation** (three-act script, staged clue disclosure, and rubric all in
simulation-guide.md):

1. Pick one of three script types by topic nature:
   - **Incident on call**: the learner is a newly hired engineer; production is
     failing in ways tied to this chapter. The Grandmaster plays the boss, disclosing
     information **in stages** (symptoms first; the next clue arrives only when the
     learner asks the right question). Locate the cause and propose the fix.
   - **Design review**: the Grandmaster presents a plan/code using this chapter's
     knowledge; the learner reviews it, naming problems and improvements.
   - **Rapid-fire chain**: for non-engineering topics — 8 consecutive questions, each
     answer feeding the next.
2. Verdict: covering ≥ 70% of the chapter's stages with correct key decisions → pass.
3. Settle write-backs:
   - Pass: every stage used correctly in the simulation rises to stars 3; the chapter
     gets `boss_cleared: true` in syllabus.json; report XP +300 with one restrained
     Grandmaster remark, and point to `/zhixing-dojo:hunt` as the gateway to 5-star
     "can audit".
   - Fail: no stars lost; name the gap stages, recommend relearning, and queue the
     gaps for review.

## Shared rules

- Hint-ladder iron rule matches /learn: at most three hints before the answer; if the
  user insists on the answer, give it.
- With plain_mode true, drop the Grandmaster persona and narrative — questions and
  settle data only.
- This skill teaches nothing new; if the learner clearly has no grasp of a stage,
  recommend relearning it via `/zhixing-dojo:learn`.
