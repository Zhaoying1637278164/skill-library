# Zhixing Dojo

A Claude Code plugin for **truly mastering** new topics from scratch — not just
"having read about them". *Zhixing* (知行) is from the Chinese ideal of "knowing and
doing as one": nothing counts as learned until it's tested.

> Swap "reading tutorials" for "entering the dojo": every concept starts as a puzzle,
> gets taught through stories and animations, and forces you to do it, explain it, and
> audit it — until you've earned the right to grade AI's work.

## Why

- **Tutorials evaporate.** Passive reading feels like understanding and is gone by
  tomorrow. Retention comes from retrieval — being made to produce, not re-read.
- **The AI era raises the bar.** AI can write the code, but *judging* AI output can't
  be outsourced. The goal isn't "can do" — it's "can audit": seeing what's wrong in
  work that looks right.
- **Text alone can't carry hard concepts.** Working memory is small; stories, diagrams,
  and interactive animations carry what prose can't.

## Quick start

```bash
# Install from the marketplace (inside Claude Code):
/plugin marketplace add donald-ada/zhixing-dojo
/plugin install zhixing-dojo@zhixing-dojo

# Or run directly from a local clone:
claude --plugin-dir /path/to/zhixing-dojo

/zhixing-dojo:setup        # once: create the archive, pick language & preferences
/zhixing-dojo:learn TCP    # start learning anything
```

The plugin's instructions are in English; **lessons happen in your language** — chosen
once during setup and remembered.

## Commands

| Command | What it does |
|---------|--------------|
| `/zhixing-dojo:setup` | One-time archive & preferences bootstrap (rerun to change preferences) |
| `/zhixing-dojo:learn [topic]` | Placement → knowledge tree → the six-step lesson loop |
| `/zhixing-dojo:map [topic]` | Knowledge tree with stars, streak, rank tier, review backlog |
| `/zhixing-dojo:quiz [scope]` | Bloom-layered checks; becomes the chapter **Boss Battle** when a chapter is ready |
| `/zhixing-dojo:review [topic]` | Spaced-repetition session over due cards |
| `/zhixing-dojo:teach [stage]` | Feynman teach-back: you teach apprentice A-Dai until he truly gets it |
| `/zhixing-dojo:hunt [scope]` | **Bug Hunt**: audit an AI-style artifact seeded with planted flaws |

## How a lesson works

Each stage of the knowledge tree is one concept, taught in a fixed 15-25 minute loop:

```
① Hook        a puzzle, incident, or paradox — never a definition
② Your Turn   you guess first; being wrong is part of the design
③ Explain     phenomenon → principle → elevation, always with a non-text form:
              mermaid diagram, story script, interactive animation, or experiment
④ Hands-On    predict-then-run code, or drive the animation
⑤ Check       2-4 multiple-choice questions layered by Bloom's taxonomy
⑥ Settle      stars, XP, streak — and a hook for the next stage
```

Interaction is **multiple-choice throughout** (guesses, predictions, checks, review
cards) with guardrails that keep it honest: hints give concepts and never eliminate
options, correct answers occasionally get a "why not X?" follow-up, and repeated
cards reshuffle their options. Dialogue-driven modes (Boss Battles, teach-back,
Bug Hunt reviews) stay free-form — their value *is* your output.

## The mastery ladder

Progress is mastery-gated (no advancing past what you haven't passed), and every
star has exactly one gateway:

| Stars | Meaning | Gateway |
|-------|---------|---------|
| ★ 1 | Studied | `/learn` lesson loop completed |
| ★ 2 | Can solve | Check passed |
| ★ 3 | Can apply | Application questions or Boss Battle |
| ★ 4 | Can explain | `/teach` teach-back passed |
| ★ 5 | Can audit | `/hunt` caught the related planted bug |

Topic rank tiers by total stars: 🥉 Bronze → 🥈 Silver → 🥇 Gold → 💠 Platinum →
💎 Diamond (every stage at five stars). Milestones earn achievements — First Steps,
Unbroken Week, Sky Mender, True Teacher, Golden Eyes, Flawless Hunt, Pinnacle…

## What makes it different

- **Memory is a system, not a hope.** Every miss becomes a spaced-repetition card
  (intervals double on success, reset with a micro-relesson on failure); overdue
  stars dim on the map; a backlog triggers rescue mode instead of guilt.
- **The Feynman gate.** A stage isn't "understood" until you've taught it to A-Dai —
  a junior apprentice with zero pretend-understanding who stress-tests your analogies
  and exposes every hand-wave in his closing recap.
- **The Bug Hunt.** The Phantom subagent generates a merge-ready-looking artifact
  with 1-4 planted flaws (or none — clean rounds exist), sealing the answer key into
  a file the host may not read until your review is final: tone-leaks are
  structurally impossible. Misses *and* false positives count.
- **Boss Battles are simulations.** Chapter exams play as staged incidents — symptoms
  first, clues earned by asking the right questions, red herrings included — scored
  against a rubric fixed before the curtain rises.
- **Multimodal by rule, not whim.** Concept types map to forms: sequences get
  diagrams, mechanisms with motives get story scripts, parameter-sensitive ideas get
  single-file interactive animations (see
  [examples/gradient-descent.html](examples/gradient-descent.html)), verifiable
  behavior gets predict-then-run experiments.
- **Anchored to real sources.** Knowledge trees align to official docs or textbooks
  by default; model knowledge is the named fallback, not the silent default.

## Design principles

- **Zero footprint outside the dojo.** No hooks: nothing is injected into — and no
  script runs after — sessions unrelated to learning. `/setup` and `/map` are
  user-invoked only, costing no context anywhere else.
- **Write as you go.** Every answer, star, and card hits disk the moment it happens;
  an interrupted lesson keeps a checkpoint and resumes where it stopped.
- **Progressive disclosure.** Each SKILL.md is a lean playbook; method details live
  in `reference/` files loaded only when needed.
- **Personas serve memory, never volume.** The Master, A-Dai, the Grandmaster, and
  the Phantom appear at openings, verdicts, and settles — explanations stay
  professional, and `plain_mode` turns the theater off entirely.

## Layout

```
.claude-plugin/plugin.json      # plugin manifest
skills/
  setup/                        # one-time archive & preferences bootstrap
  learn/                        # main lesson loop + teaching method & content formats
  map/                          # the learning map
  quiz/                         # checks & Boss Battles + question standards
  review/                       # spaced-repetition sessions
  teach/                        # Feynman teach-back (apprentice A-Dai)
  hunt/                         # Bug Hunt + planted-bug taxonomy
agents/animator.md              # animator subagent (interactive HTML animations)
agents/phantom.md               # Phantom subagent (bug-seeded artifacts, sealed answers)
examples/gradient-descent.html  # animation reference implementation (learning rate)
docs/learning-plugin-design.md  # original design document
```

Learning state persists in `${CLAUDE_PLUGIN_DATA}` (fallback
`~/.claude/plugins/data/zhixing-dojo`) across sessions and projects.

## More

- Version history: [CHANGELOG.md](CHANGELOG.md)
- Original design document: [docs/learning-plugin-design.md](docs/learning-plugin-design.md)
