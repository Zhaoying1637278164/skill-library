#!/usr/bin/env python3
#
# detection-secrets.py — ce qui est un secret, à un seul endroit.
#
# Jusqu'à la 0.3.4, deux listes différentes vivaient dans deux hooks, et
# aucune ne se trompait dans le même sens : pre-edit-guard ignorait
# backend.env, *.pem et ~/.ssh ; protect-secrets ne connaissait ni « secret »
# ni « token » employés seuls, ni la forme YAML, ni une clé PEM, ni une clé
# privée passée à from_key("0x…").
#
# Appelé par :
#   pre-edit-guard.sh    detection-secrets.py fichier   (Write, Edit, Read)
#   protect-secrets.sh   detection-secrets.py valeur    (Bash, Monitor, Write, Edit)
#   analyse-commande.py  importé : est_fichier_de_secrets, valeur_secrete
#
# Entrée : le JSON du hook sur stdin. Sortie : un mot sur stdout.
#   fichier → SECRET | OK
#   valeur  → rien, ou « <où>\t<nom> » (où = commande | fichier | edition)
# Toute panne sort en code 3 : le hook appelant refuse l'action.
#
# Il reste un rappel mécanique, pas un audit : ne jamais lire son silence comme
# la preuve qu'il n'y a pas de secret.

import json
import os
import re
import sys
import unicodedata

# --- Fichiers de secrets ---------------------------------------------------------

MODELES = re.compile(r"[._-](example|sample|template|dist|tmpl|tpl|defaults?)$")
# ~/.claude.json porte en clair les jetons des serveurs MCP ; .git-credentials,
# gh/hosts.yml et .docker/config.json portent ceux de git, de gh et de Docker.
NOMS_EXACTS = {".env", ".envrc", "credentials", "credentials.json", "keystore.json", "wallet.json",
               "private_key.txt", "secret.key", ".netrc", ".pypirc", ".pgpass",
               "id_rsa", "id_ed25519", "id_ecdsa", "id_dsa", ".claude.json", ".git-credentials",
               # Seconde relecture de la 0.4.0 : wallets et fichiers d'identifiants courants.
               "keypair.json", "wallet.dat", "secrets.toml", "secrets.json", "secrets.yml", "secrets.yaml",
               "application_default_credentials.json"}
# .npmrc : celui du dossier personnel porte le jeton de « npm login » ; celui
# d'un projet (registry=…, save-exact=true) n'est un fichier de secrets que s'il
# porte un jeton en clair (_authToken=npm_…, pas ${NPM_TOKEN}). Jusqu'à la
# passe 3, tout .npmrc était refusé en lecture comme en écriture.
NPMRC_JETON = re.compile(r"(?im)^\s*(?://[^\s=]*:)?_(?:auth|authToken|password)\s*=\s*(\S+)")
DOSSIER_PERSONNEL = re.compile(r"/(?:Users|home)/[^/]+|/root|/var/root")
# Du code source n'est pas un fichier de secrets, même rangé sous wallet/ ou
# nommé mnemonic.py : Read, cat et git add en étaient refusés.
CODE_SOURCE = re.compile(r"\.(py|pyi|js|mjs|cjs|ts|tsx|jsx|go|rs|rb|java|kt|swift|c|h|cpp|hpp|cs|php|sh|md|"
                         r"html|css|scss|vue|svelte|sql|ipynb|lock|txt\.tpl)$")
# Copies horodatées d'un .env (sauvegardes/env-20260101-120000, env.local-…).
COPIE_D_ENV = re.compile(r"env(\.[a-z]+)?-\d{8}-\d{6}(-\d+)?")
EXTENSIONS = (".pem", ".key", ".p12", ".pfx", ".keystore", ".jks")
SSH_PERMIS = {"config", "authorized_keys", "known_hosts", "known_hosts.old", "environment.example"}


def est_fichier_de_secrets(chemin):
    """Comparé comme macOS (APFS) compare les noms : chemin normalisé, forme
    NFKC, casse repliée (« .ENV », « wallet.jſon »). Les modèles sans valeur
    (.env.example, *.template) et les clés publiques (.pub) restent libres.
    Un lien vers un fichier de secrets en est un : jusqu'à la relecture de la
    0.4.0, Read, Write et Grep passaient par un lien nommé « notes »."""
    if not chemin or not isinstance(chemin, str):
        return False
    if par_le_nom(chemin) or npmrc_porte_un_jeton(chemin):
        return True
    try:
        if os.path.islink(chemin) or os.path.exists(chemin):
            reel = os.path.realpath(chemin)
            return reel != os.path.abspath(chemin) and (par_le_nom(reel) or npmrc_porte_un_jeton(reel))
    except (OSError, ValueError):
        pass
    return False


def npmrc_porte_un_jeton(chemin):
    """Un .npmrc du dossier personnel (par son nom), ou un .npmrc de projet qui
    porte une valeur d'authentification en clair (par son contenu)."""
    try:
        chemin = os.path.expanduser(os.path.expandvars(chemin))      # ~/.npmrc, $HOME/.npmrc, ${HOME}/.npmrc
        if os.path.basename(os.path.normpath(unicodedata.normalize("NFKC", chemin).casefold())) != ".npmrc":
            return False
        parent = os.path.dirname(os.path.abspath(chemin))
        if DOSSIER_PERSONNEL.fullmatch(parent) or os.path.normcase(parent) == os.path.normcase(os.path.expanduser("~")):
            return True
        with open(chemin, encoding="utf-8", errors="replace") as h:
            texte = h.read(200_000)
    except (OSError, ValueError):
        return False
    return any(not GABARIT.search(m.group(1)) and not FACTICE.match(m.group(1)) for m in NPMRC_JETON.finditer(texte))


def par_le_nom(chemin):
    p = os.path.normpath(unicodedata.normalize("NFKC", chemin).casefold())
    parties = p.split(os.sep)
    b = parties[-1]
    if b.endswith(".pub") or MODELES.search(b):
        return False
    if b in NOMS_EXACTS or b.startswith((".env.", ".claude.json.")) or b.endswith(".env") or ".env." in b:
        return True
    if re.match(r"\.env[~_-]", b) or COPIE_D_ENV.fullmatch(b):
        return True                                 # .env~, .env-prod, .env_local, copies horodatées
    if (len(parties) >= 2 and parties[-2] == "gh" and b == "hosts.yml") or \
            (len(parties) >= 2 and parties[-2] == ".docker" and b == "config.json"):
        return True
    if b.endswith(EXTENSIONS) or b.endswith("-keypair.json"):
        return True
    if CODE_SOURCE.search(b):
        return False
    if "mnemonic" in b or "seed-phrase" in b or "seed_phrase" in b:
        return True
    if ".ssh" in parties[:-1] and b not in SSH_PERMIS and not b.startswith("known_hosts"):
        return True                                 # clés privées ssh (id_*, ou nommées librement)
    if "keystore" in parties[:-1] or "keystores" in parties[:-1]:
        return True                                 # keystore/, ~/.foundry/keystores/
    if len(parties) >= 3 and parties[-3:-1] == [".config", "solana"] and b.endswith(".json"):
        return True                                 # ~/.config/solana/id.json : la clé en clair
    if len(parties) >= 2 and parties[-2] == ".kube" and b == "config":
        return True
    if b == "environ" and "proc" in parties[:-1]:
        return True                                 # /proc/<pid>/environ, /proc/<pid>/task/<tid>/environ : l'environnement d'un processus
    return False


# --- Valeurs secrètes ---------------------------------------------------------

# Un nom qui annonce un secret…
SENSIBLE = re.compile(r"(priv(ate)?[_-]?key|secret|api[_-]?key|access[_-]?token|auth[_-]?token|"
                      r"refresh[_-]?token|(^|[_-])token$|bearer|mnemonic|seed[_-]?phrase|"
                      r"pass[_-]?phrase|password|passwd|wallet[_-]?key|signing[_-]?key|ntfy[_-]?topic|"
                      r"keypair|(^|[_-])[ps]k$)", re.I)
# … sauf s'il désigne autre chose que la valeur (CLIENT_SECRET_FILE, API_KEY_HEADER).
PAS_UNE_VALEUR = re.compile(r"[_-](name|file|path|dir|id|ids|arn|url|uri|env|var|header|field|type|"
                            r"len|length|hash|prefix|suffix|count|enabled|set|present|ok|regex|pattern)$", re.I)
# pk, sk : un identifiant Django (pk="<uuid>") ou une clé composite DynamoDB
# ("pk": "USER#…", "sk": "PROFILE#…") portent ces noms sans rien de secret.
# Sous ces deux noms courts seuls, la valeur doit avoir la matière d'une clé :
# 20 caractères ou plus de base58, base64, hexadécimal ou JWT (avec ses
# points), ni UUID ni « # » (passe 3 : ces identifiants étaient refusés ; sa
# relecture : une clé Mapbox « sk.eyJ… », un JWT, une clé de 24 caractères
# passaient sous une règle trop étroite).
NOM_COURT_DE_CLE = re.compile(r"(?i)(?:.*[_-])?[ps]k$")
MATIERE_DE_CLE = re.compile(r"[A-Za-z0-9+/=_.-]{20,}")
UUID = re.compile(r"(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")

# (?<![\w.-]) : le nom commence au début d'un mot. Sans cela, chaque caractère
# d'un long mot (bytecode hexadécimal) relançait la recherche jusqu'au bout de
# la fenêtre : 600 Ko prenaient 25 s, et un hook qui dépasse son délai laisse
# passer l'action (relecture de la 0.4.0).
CITE = re.compile(r"(?<![\w.-])(?P<n>[A-Za-z_][\w.-]*)[\"']?\s*(?::=|=>|[:=])\s*(?P<q>[\"'])(?P<v>(?:(?!(?P=q)).){0,4000}?)(?P=q)")
# La valeur nue s'arrête aussi sur un guillemet : echo "API_SECRET=…" >> .env,
# docker run -e "…", - "…" d'un docker-compose.
NUE = re.compile(r"(?<![\w.-])(?P<n>[A-Za-z_][\w.-]*)[\"']?\s*[:=]\s*(?P<v>[^\s\"'#;,&|)}\]]+)(?=\s|$|[#;,&|)}\]\"'])")

GABARIT = re.compile(r"""
      \$\{[^}]*\}? | \$\([^)]*\) | \{\{[^}]*\}\} | \$[A-Za-z_]\w*
    | <[^>]+>      | %\([^)]*\)s | \{[A-Za-z_]\w*\} | [()]
    | ^(?:os\.|process\.|env\.|import\b)
""", re.I | re.X)
FACTICE = re.compile(r"^(?:x{3,}|\.{3,}|\*{3,}|-{3,}|none|null|nil|true|false|"
                     r"your[_-]|my[_-]|the[_-]|test|dummy|fake|sample|example|"
                     r"placeholder|changeme|change[_-]me|todo|fixme|"
                     r"remplacer|remplir|votre[_-]|vos[_-]|a[_-]definir|"
                     r"redacted|hidden|masked)", re.I)
A_REMPLIR = re.compile(r"^[A-Z][A-Z_]*_[A-Z_]+$")


def ressemble_a_un_secret(v, entre_guillemets):
    v = v.strip()
    if v.startswith("eyJ") and len(v) >= 20:
        return True                                 # jeton JWT
    if len(v) < 16 or GABARIT.search(v) or FACTICE.match(v) or A_REMPLIR.match(v):
        return False
    if re.search(r"[*\\^]", v):
        return False                                # une expression régulière, pas une valeur
    if v.startswith(("/", "./", "../", "~/")) or re.match(r"https?://", v):
        return False
    if re.fullmatch(r"[\w.-]+(/[\w.-]+)+", v) and re.search(r"\.[A-Za-z0-9]{1,5}$", v):
        return False                                # config/client_secret.json
    mots = v.split()
    if len(mots) >= 8:
        return all(m.isalpha() for m in mots)       # phrase de récupération
    if len(mots) > 1:
        return False
    if not entre_guillemets:
        # Sans guillemets, dans du code, c'est souvent un nom de variable.
        if re.fullmatch(r"[A-Za-z_]\w*(\.[A-Za-z_]\w*)+", v):
            return False                            # settings.api_secret
        if re.fullmatch(r"[a-z_][a-z0-9_]*", v) and "_" in v:
            return False                            # exchange_api_secret
        if re.fullmatch(r"[A-Z_][A-Z0-9_]*", v) and "_" in v:
            return False                            # NOM_DE_CONSTANTE
    return any(c.isalpha() for c in v)


HEX64 = re.compile(r"(?<![0-9A-Za-z])0x[0-9a-fA-F]{64}(?![0-9a-fA-F])")
HEX64_NU = re.compile(r"(?<![0-9A-Za-z])[0-9a-fA-F]{64}(?![0-9A-Za-z])")
NOM_AVANT = re.compile(r"(?<![\w.-])(?P<n>--?[\w-]+|[A-Za-z_][\w.-]*)[\"']?\s*(?:=>|:=|[:=(,\[]|\s)\s*[\"']?\s*$")
NOM_DE_HASH = re.compile(r"(hash|_id|id|digest|root|salt|sig|signature|nonce|(^|[_-])tx|expected|attendu)$", re.I)
CLE_DANS_LE_NOM = re.compile(r"key|priv|(^|[_-])pk($|[_-])|^pk|secret|signer|wallet|mnemonic|seed|"
                             r"account|credential", re.I)
CONTEXTE_HASH = re.compile(r"hash|\btx|txn|transaction|digest|sha|block|root|salt|condition|question|"
                           r"market|topic|event|sig|nonce|merkle|parent|collection|position|asset|order|"
                           r"receipt|\.log\b|logs?/|polygonscan|etherscan|explorer", re.I)
PEM = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
CONVERSION = re.compile(r"(?i)fromhex|unhexlify|hexbytes|decode_hex|to_bytes|bytes")


def cle_0x(ligne, contexte=""):
    """Une clé privée 0x + 64 hexa. Un hash (transaction, condition_id…) a la
    même forme : on regarde le nom qui la précède, puis la ligne, puis les
    lignes au-dessus (en-tête d'un tableau, nom de la liste qui s'ouvre). Sans
    rien qui parle de hash, la valeur est traitée comme une clé.
    64 hexa SANS 0x : une clé seulement sous un nom de clé (from_key, key, pk),
    pas une somme sha256 affichée seule."""
    for m in HEX64.finditer(ligne):
        if len(set(m.group(0)[2:].lower())) <= 1:
            continue                                # 0x000…0, 0xfff…f
        avant = NOM_AVANT.search(ligne[:m.start()])
        nom = (avant.group("n").split(".")[-1] if avant else "")
        if nom and NOM_DE_HASH.search(nom):
            continue
        if nom and CLE_DANS_LE_NOM.search(nom):
            return nom
        if CONTEXTE_HASH.search(ligne) and not CLE_DANS_LE_NOM.search(ligne):
            continue
        if not nom and CONTEXTE_HASH.search(contexte) and not CLE_DANS_LE_NOM.search(ligne):
            continue                                # élément d'une liste de condition_id, ligne de tableau
        return nom or "0x…"
    for m in HEX64_NU.finditer(ligne):
        if len(set(m.group(0).lower())) <= 1:
            continue
        avant = NOM_AVANT.search(ligne[:m.start()])
        nom = (avant.group("n").split(".")[-1] if avant else "")
        if CONVERSION.fullmatch(nom):
            # from_key(bytes.fromhex("…")) : le nom de clé est avant la conversion.
            cle = CLE_DANS_LE_NOM.search(ligne[:m.start()])
            nom = cle.group(0) if cle else ""
        if nom and CLE_DANS_LE_NOM.search(nom) and not NOM_DE_HASH.search(nom):
            return nom
    return None


# Jetons portés par une URL ou un en-tête, quel que soit le nom.
JETON_URL = re.compile(r"api\.telegram\.org/bot\d+:[\w-]{30,}"
                       r"|discord(?:app)?\.com/api/webhooks/\d+/[\w-]{40,}"
                       r"|(?:alchemy\.com|infura\.io|quiknode\.pro|quicknode\.com)\S*/v[23]/[\w-]{24,}"
                       r"|\bBearer\s+(?!\$|\{|<)[\w.~+/=-]{20,}", re.I)
# Jetons reconnaissables à leur préfixe, quel que soit le nom qui les porte.
JETON_PREFIXE = re.compile(r"(?<![\w-])(gh[pousr]_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{22,}|glpat-[\w-]{20,}"
                           r"|xox[abprs]-[\w-]{10,}|sk-ant-[\w-]{20,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}"
                           r"|AKIA[0-9A-Z]{16}|AIza[\w-]{35}|npm_[A-Za-z0-9]{36})(?![\w-])")
# Mot de passe écrit dans une URL : schéma://utilisateur:motdepasse@hôte.
URL_MDP = re.compile(r"(?i)\b[a-z][a-z0-9+.-]*://[^\s:/@'\"]+:(?P<p>[^\s@/'\"]+)@")
MDP_FACTICES = {"password", "passwd", "pass", "pwd", "secret", "motdepasse", "mot_de_passe", "changeme", "admin",
                "root", "user", "postgres", "mysql", "guest"}
# 64 octets écrits en tableau : la forme d'une clé Solana (Keypair.fromSecretKey).
TABLEAU64 = re.compile(r"\[\s*(?:\d{1,3}\s*,\s*){63}\d{1,3}\s*,?\s*\]")
CONTEXTE_CLE = re.compile(r"(?i)secret|keypair|priv|signer|wallet|from_?bytes|fromSeed")


def mdp_solide(mdp):
    """devpass, tiger, localpw (docker-compose de développement, exemples de
    la doc) restent libres : 10 caractères et deux familles au moins."""
    familles = sum(bool(re.search(r, mdp)) for r in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
    return len(mdp) >= 16 or (len(mdp) >= 10 and familles >= 2)


FAUX_EXPRES = re.compile(r"(?i)fake|test|mauvais|faux|wrong|invalid|bad|dummy|example|x{3,}")
# Phrase de récupération sans guillemets : le nom suivi de 11 mots ou plus.
PHRASE = re.compile(r"(?i)(mnemonic|seed[_-]?phrase|recovery[_-]?phrase)[\"']?\s*[:=]\s*[\"']?"
                    r"([a-z]+(?:\s+[a-z]+){10,})")


def valeur_secrete(texte):
    """Le nom qui porte un secret dans le texte, ou None."""
    if not texte or not isinstance(texte, str):
        return None
    if PEM.search(texte):
        return "clé PEM"
    for m in JETON_URL.finditer(texte):
        jeton = m.group(0).split()[-1]
        if not FAUX_EXPRES.search(jeton):
            return "jeton dans une URL"             # un jeton exprès faux d'un essai reste libre
    for m in JETON_PREFIXE.finditer(texte):
        if not FAUX_EXPRES.search(m.group(0)):
            return "jeton"
    for m in URL_MDP.finditer(texte):
        mdp = m.group("p")
        if not (GABARIT.search(mdp) or FACTICE.match(mdp) or mdp.lower() in MDP_FACTICES) and mdp_solide(mdp):
            return "mot de passe dans une URL"
    for m in TABLEAU64.finditer(texte):
        ligne = texte[texte.rfind("\n", 0, m.start()) + 1:m.start()]
        if CONTEXTE_CLE.search(ligne) and all(int(x) < 256 for x in re.findall(r"\d+", m.group(0))):
            return "clé en tableau d'octets"
    m = PHRASE.search(texte)
    if m and not FACTICE.match(m.group(2)):
        return m.group(1)
    # "api_secret":⏎ "valeur" : la valeur JSON passée à la ligne suivante.
    texte = re.sub(r'("\s*:)[ \t]*\n[ \t]*(?=")', r"\1 ", texte)
    lignes = texte.splitlines()
    for k, ligne in enumerate(lignes):
        nom = cle_0x(ligne, "\n".join(lignes[max(0, k - 5):k]))
        if nom:
            return nom
        # Fenêtres de 4000 caractères qui se chevauchent : une ligne JSON géante
        # ne cache plus sa fin.
        for debut in range(0, max(1, len(ligne)), 3800):
            morceau = ligne[debut:debut + 4000]
            for motif, cite in ((CITE, True), (NUE, False)):
                for m in motif.finditer(morceau):
                    n = m.group("n").split(".")[-1]
                    v = m.group("v").strip()
                    if SENSIBLE.search(n) and not PAS_UNE_VALEUR.search(n) and ressemble_a_un_secret(v, cite) \
                            and (not NOM_COURT_DE_CLE.fullmatch(n)
                                 or (MATIERE_DE_CLE.fullmatch(v) and not UUID.fullmatch(v))):
                        return n
    return None


def entree():
    d = json.loads(sys.stdin.buffer.read().decode("utf-8", "replace"))
    t = d.get("tool_input") if isinstance(d, dict) else None
    return d, (t if isinstance(t, dict) else {})


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    d, ti = entree()
    if mode == "fichier":
        print("SECRET" if est_fichier_de_secrets(ti.get("file_path") or ti.get("notebook_path") or "") else "OK")
    elif mode == "valeur":
        for ou, cle in (("commande", "command"), ("fichier", "content"), ("edition", "new_string"),
                        ("edition", "new_source")):
            nom = valeur_secrete(ti.get(cle) or "")
            if nom:
                print(f"{ou}\t{nom[:40]}")
                return
    else:
        raise SystemExit(3)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        sys.exit(3)
