# Discipline de code

## Avant de coder
- TOUJOURS lire et comprendre le code existant avant de le modifier
- Vérifier que la feature demandée n'existe pas déjà dans le projet
- Comprendre les dépendances entre les fichiers avant de toucher à quoi que ce soit

## Nouvelle feature
- Faire valider à l'utilisateur le *quoi* en une ligne métier (« le bot coupe tout après 3 pertes »), jamais le *comment* — le comment, Claude le décide (voir `communication-style.md`, « Qui décide quoi »)
- Après implémentation, tester la feature ET vérifier que l'existant marche encore

## Git — ceinture de sécurité
- Faire un commit AVANT de commencer à modifier du code (snapshot de l'état actuel)
- Faire un commit APRÈS chaque fix ou feature qui fonctionne
- Messages de commit clairs et en français : "fix: le bot ne s'arrête plus après 3 pertes" ou "ajout: alerte quand drawdown > 10%"
- Si un changement casse quelque chose et que le fix n'est pas évident : mettre d'abord l'état cassé à l'abri (commit sur une branche, ou stash), revenir au commit précédent, l'annoncer en une ligne — un reset sans abri effacerait le travail non commité
