---
description: Explica qué cubre un seguro o una aseguradora en España con la base de conocimiento de IAseguro
argument-hint: "[seguro o aseguradora, p. ej.: hogar de MAPFRE, ¿cubre daños por agua?]"
---

Explica las coberturas con el conector de IAseguro, siguiendo el skill
`explicar-coberturas`.

Pregunta del usuario: $ARGUMENTS

Llama a la tool `detalle_<línea>` que corresponda (con la aseguradora si la
nombra) y responde a la pregunta concreta con los datos devueltos.
