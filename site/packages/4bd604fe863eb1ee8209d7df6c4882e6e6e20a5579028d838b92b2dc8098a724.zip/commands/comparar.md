---
description: Compara precios de un seguro en España con IAseguro (vida, coche, hogar, decesos, viaje, mascotas, moto, patinete, RC)
argument-hint: "[seguro y datos, p. ej.: coche Seat León 2020, 35 años, 15 de carnet, CP 46001, todo riesgo]"
---

Compara precios de seguros en España con el conector de IAseguro, siguiendo el
skill `comparar-seguros`.

Petición del usuario: $ARGUMENTS

Si falta la línea de seguro o algún dato obligatorio de su tool `cotizar_*`,
pregúntalo en una sola tanda antes de cotizar. Presenta las opciones más
baratas, recuerda que los precios son orientativos e incluye el enlace a
IAseguro del resultado.
