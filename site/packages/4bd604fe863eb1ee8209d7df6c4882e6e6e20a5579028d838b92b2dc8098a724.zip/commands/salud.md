---
description: Encuentra seguros de salud en España que encajen con tus preferencias (cuadro médico, reembolso, dental, maternidad, copago)
argument-hint: "[preferencias, p. ej.: cuadro médico con dental y sin copago]"
---

Recomienda seguros de salud en España con el conector de IAseguro, siguiendo el
skill `seguros-de-salud`.

Preferencias del usuario: $ARGUMENTS

Si no ha indicado modalidad ni ninguna necesidad (maternidad, dental, copago),
pregúntaselas antes de llamar a `recomendar_salud`. No preguntes por su historial
médico: la comparación no lo necesita.
