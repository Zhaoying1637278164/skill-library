<img src="assets/icon.png" width="72" height="72" align="right" alt="IAseguro">

# IAseguro for Claude

**Compare insurance prices in Spain without leaving Claude.** IAseguro is an
independent insurance comparison service for Spain. Its engine estimates prices
from 20+ insurers, ranks them from cheapest to most expensive, matches private
health plans to your preferences and explains what each policy covers.

Lines: **life · health · car · home · funeral · travel · pet · motorbike ·
e-scooter · personal liability**.

<p align="center">
  <img src="assets/screenshots/pet-quotes.png" width="32%" alt="Pet insurance quotes ranked by price">
  <img src="assets/screenshots/health-plans.png" width="32%" alt="Health insurance plans matched to preferences">
  <img src="assets/screenshots/car-quotes-dark.png" width="32%" alt="Car insurance quotes in dark mode">
</p>

## Install

**Claude Code**

```text
/plugin marketplace add iaseguro/claude-plugin
/plugin install iaseguro@iaseguro
```

**Cowork** — *Customize → Plugins → Add marketplace* → `iaseguro/claude-plugin`
→ install **IAseguro**.

**Claude.ai, Claude Desktop and mobile (chat)** — plugins are not used in chat;
add the connector instead: *Customize → Connectors → Add custom connector*, URL
`https://mcp.iaseguro.com/mcp/claude`, no authentication. Available on every
plan, including Free.

**Claude Desktop, one click** — download
[`iaseguro.mcpb`](https://iaseguro.com/descargas/iaseguro.mcpb) and double-click
it (or drag it into *Settings → Extensions*). It is a thin local bridge to the
same connector; source in [`desktop-extension/`](desktop-extension/).

## What's inside

| Component | Name | What it does |
| --- | --- | --- |
| Connector (remote MCP) | `iaseguro` | 21 read-only tools, no login. In claude.ai and Claude Desktop results render as interactive cards (MCP Apps) that follow Claude's light and dark themes. |
| Skill | `comparar-seguros` | Collects only the data each quote needs, runs the right `cotizar_*` tool and presents the cheapest options. |
| Skill | `seguros-de-salud` | Health plans by preference (provider network, reimbursement, dental, maternity, co-payment). Never asks for medical history. |
| Skill | `explicar-coberturas` | Answers "what does this policy cover?" from IAseguro's knowledge base. |
| Command | `/iaseguro:comparar` | Compare prices for one line of insurance. |
| Command | `/iaseguro:salud` | Find health plans that fit your preferences. |
| Command | `/iaseguro:coberturas` | Explain the coverage of a policy or insurer. |
| Agent | `revision-seguros` | Reviews several policies at once (e.g. car + home + life) and estimates the total yearly saving. |

### Tools

| Tool | Purpose |
| --- | --- |
| `cotizar_vida`, `cotizar_coche`, `cotizar_hogar`, `cotizar_decesos`, `cotizar_viaje`, `cotizar_mascota`, `cotizar_moto`, `cotizar_patinete`, `cotizar_rc` | Indicative quotes from several insurers for life, car, home, funeral, travel, pet, motorbike, e-scooter and liability insurance, cheapest first. |
| `recomendar_salud` | Private health plans that match the user's preferences, cheapest first. |
| `detalle_vida`, `detalle_salud`, `detalle_coche`, `detalle_hogar`, `detalle_decesos`, `detalle_viaje`, `detalle_mascota`, `detalle_moto`, `detalle_patinete`, `detalle_rc` | Coverages, options and limits per insurer or product, with an indicative "from" price. |
| `consultar_disponibilidad` | Lines of insurance that can be compared right now. |

All tools are annotated `readOnlyHint: true`: they calculate and read, they
never write, buy or contact anyone.

## Example prompts

- *"I'm 38, live in Madrid (28015) and don't smoke. How much would a €150,000 life insurance for my mortgage cost?"*
- *"Busco un seguro de salud con cuadro médico que incluya dentista. ¿Cuál me sale más barato?"*
- *"Compárame el todo riesgo con franquicia para mi Seat León de 2020. Tengo 35 años y vivo en Valencia."*
- *"¿Qué cubre el seguro de hogar de MAPFRE? ¿Incluye los daños por agua?"*
- *"Revisa mis seguros de coche, hogar y vida y dime cuánto podría ahorrar al año."*

## Data and privacy

- No account, no login, no phone number, no sales calls.
- Tool inputs (for example date of birth, postcode and insured amount for life
  insurance) are used to calculate the estimate and are **not stored** with
  your identity. Health comparisons use coverage preferences only, never
  medical data.
- For usage metrics the server records the tool name, argument **names** (not
  values), the first two digits of the postcode, the insured amount, the
  insurer queried, the result and its duration, the client's user agent and a
  pseudonymous hash of IP address + user agent. Web server logs keep the source
  IP for about 52 days for security.
- IAseguro never receives the rest of your conversation or your Claude account
  data.
- Links to iaseguro.com and to insurers' websites carry UTM parameters to
  measure visits. Results are ranked by price only; if you buy through
  IAseguro the insurer may pay a commission, which never changes the ranking.

Privacy policy: <https://iaseguro.com/privacidad> · Contact: <info@iaseguro.com>

## Disclaimer

Prices are **indicative estimates** based on market tariffs, not binding
offers: each insurer sets the final premium and conditions after its own
questionnaire. IAseguro does not sell policies inside Claude and this is not
personalised financial, legal or medical advice. Coverage of Spanish risks
only.

## Support

- Documentation: <https://iaseguro.com/claude>
- Issues: <https://github.com/iaseguro/claude-plugin/issues>
- Email: <info@iaseguro.com>

---

## En español

**Compara seguros en España sin salir de Claude.** IAseguro es un comparador
independiente: calcula precios orientativos de más de 20 aseguradoras, los
ordena de más barato a más caro, recomienda seguros de salud según tus
preferencias y explica qué cubre cada póliza.

- **Claude Code:** `/plugin marketplace add iaseguro/claude-plugin` y
  `/plugin install iaseguro@iaseguro`.
- **Cowork:** Personalizar → Plugins → Añadir marketplace →
  `iaseguro/claude-plugin`.
- **claude.ai, Claude Desktop y móvil:** Personalizar → Conectores → Añadir
  conector personalizado con la URL `https://mcp.iaseguro.com/mcp/claude` (sin
  autenticación).

Los precios son estimaciones orientativas; el precio final lo confirma cada
aseguradora. Guía completa: <https://iaseguro.com/claude>.

## License

[MIT](LICENSE) © 2026 IAseguro
