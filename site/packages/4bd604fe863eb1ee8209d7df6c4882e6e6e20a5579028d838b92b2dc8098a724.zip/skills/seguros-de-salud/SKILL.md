---
name: seguros-de-salud
description: Recomienda y compara seguros de salud privados en España con IAseguro (Adeslas, Sanitas, DKV, Asisa, AXA, MAPFRE…) — cuadro médico, reembolso o mixta, con o sin copago, dental y maternidad. Úsalo cuando el usuario busque un seguro médico o de salud, pregunte cuál le conviene, cuánto cuesta o qué cubre uno concreto ("seguro médico barato con dentista", "¿qué seguro de salud me conviene?", "private health insurance in Spain").
---

# Seguros de salud en España

Tools del conector `iaseguro`:

- `recomendar_salud`: opciones que encajan con las preferencias del usuario,
  ordenadas de más barata a más cara, con precio "desde €/mes" orientativo por
  persona.
- `detalle_salud`: coberturas de una aseguradora o producto concreto
  (modalidad, maternidad, dental, copago, suma asegurada).

## Flujo

1. **Pregunta las preferencias** si el usuario no las ha dado, en una sola
   tanda:
   - Modalidad: *cuadro médico* (red de médicos concertados, lo más económico),
     *reembolso* (libre elección de médico; la aseguradora devuelve un % del
     gasto) o *mixta*.
   - ¿Necesita maternidad? ¿Quiere dental? ¿Prefiere sin copago (sin pagar por
     cada acto médico)?

   Si responde que le da igual, usa cuadro médico como punto de partida y dilo.

2. **Llama una vez a `recomendar_salud`** con `modality`
   (`cuadro-medico` | `reembolso` | `mixta`) y `maternity`, `dental`, `noCopay`
   (`si` | `no`). Si el resultado indica que faltan preferencias, pregúntalas.
   Vuelve a llamarla solo si cambian las preferencias.

3. **Presenta el resultado.**
   - Con tarjetas en pantalla (claude.ai, Claude Desktop): 1-2 frases
     destacando la más barata y por qué encaja.
   - Solo texto (Claude Code, Cowork): lista las opciones con aseguradora,
     producto, modalidad, precio "desde" y lo que la hace encajar.
   - Aclara que el precio es orientativo: el definitivo depende de la edad, la
     provincia y el cuestionario de salud de la aseguradora.
   - Incluye el enlace a IAseguro del resultado; no inventes URLs.

4. **Preguntas sobre un producto o compañía concretos** ("¿qué cubre el seguro
   de salud de Sanitas?", "¿Adeslas incluye dental?"): llama a `detalle_salud`
   con `insurer` y, si lo nombra, `product`.

## Privacidad y límites

- **No preguntes por diagnósticos, historial médico, medicación ni
  enfermedades previas**: la comparación no los necesita. Si el usuario los
  menciona, no los repitas ni los uses; explica que las preexistencias y los
  periodos de carencia los valora la aseguradora en su cuestionario al
  contratar.
- No es consejo médico ni asesoramiento vinculante. No contrates ni pidas
  datos de pago.

Responde en el idioma del usuario.
