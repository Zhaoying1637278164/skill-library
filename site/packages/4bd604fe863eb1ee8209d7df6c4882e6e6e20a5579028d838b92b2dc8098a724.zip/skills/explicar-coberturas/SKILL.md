---
name: explicar-coberturas
description: Explica qué cubre un seguro en España con la base de conocimiento de IAseguro — coberturas, garantías, límites y exclusiones de pólizas de vida, salud, coche, hogar, decesos, viaje, mascotas, moto, patinete y responsabilidad civil, en general o de una aseguradora concreta. Úsalo cuando pregunten "qué cubre", "qué incluye", "qué garantías tiene", "¿cubre X?" o "qué diferencia hay entre" seguros o productos, aunque no nombren a IAseguro.
---

# Explicar coberturas de seguros

Tools del conector `iaseguro`: `detalle_vida`, `detalle_salud`,
`detalle_coche`, `detalle_hogar`, `detalle_decesos`, `detalle_viaje`,
`detalle_mascota`, `detalle_moto`, `detalle_patinete` y `detalle_rc`. No
necesitan datos personales.

## Flujo

1. Identifica la línea de seguro y, si la nombra, la aseguradora o el producto.
2. Llama a `detalle_<línea>` con `insurer` (y `product` en salud) si el usuario
   los nombra; si la pregunta es genérica, llámala sin filtros y resume lo
   común a las opciones.
3. Responde **a la pregunta concreta** con los datos devueltos: si preguntan
   "¿cubre los daños por agua?", di explícitamente si están cubiertos y con qué
   límite. Si el dato no aparece en el resultado, dilo en vez de suponerlo.
4. Presentación:
   - Con tarjetas en pantalla (claude.ai, Claude Desktop): resume en 2-3 frases
     lo relevante para la pregunta.
   - Solo texto (Claude Code, Cowork): usa viñetas breves por producto.
   - Los precios "desde" son orientativos.
5. Para comparar entre aseguradoras, llama a la tool una vez por compañía (o sin
   filtro) y presenta las diferencias en una tabla.
6. Si después quiere precio, sigue con el skill `comparar-seguros` (o
   `seguros-de-salud` para salud).

Las condiciones exactas son las del condicionado de cada aseguradora: no des
consejo legal. Responde en el idioma del usuario.
