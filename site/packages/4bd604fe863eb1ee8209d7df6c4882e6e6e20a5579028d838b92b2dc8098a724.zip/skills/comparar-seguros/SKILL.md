---
name: comparar-seguros
description: Compara precios de seguros en España con IAseguro — vida, coche, hogar, decesos, viaje, mascotas, moto, patinete eléctrico y responsabilidad civil. Úsalo cuando el usuario quiera saber cuánto cuesta o cuánto pagaría por un seguro, pida una cotización o presupuesto, quiera comparar aseguradoras o encontrar el seguro más barato ("cuánto cuesta", "compárame", "qué seguro es más barato", "how much is car insurance in Spain"), aunque no nombre a IAseguro. Para seguros de salud usa el skill seguros-de-salud.
---

# Comparar precios de seguros en España

IAseguro es un comparador independiente de seguros para España. Su motor calcula
precios **orientativos** de varias aseguradoras a partir de tarifas de mercado y
los ordena de más barato a más caro (no cobra por posicionar a nadie). No son
ofertas vinculantes: el precio final lo fija cada aseguradora.

Las tools vienen del conector `iaseguro` de este plugin:
`cotizar_vida`, `cotizar_coche`, `cotizar_hogar`, `cotizar_decesos`,
`cotizar_viaje`, `cotizar_mascota`, `cotizar_moto`, `cotizar_patinete`,
`cotizar_rc` y `consultar_disponibilidad`.

## Flujo

1. **Identifica la línea de seguro.** Si es salud, sigue el skill
   `seguros-de-salud`. Si la línea no está en la lista o el riesgo está fuera de
   España, dilo y ofrece las que sí están (en caso de duda, llama a
   `consultar_disponibilidad`).

2. **Reúne solo los datos que pide la tool** (su input schema es la referencia):

   | Línea | Datos necesarios |
   | --- | --- |
   | Vida | fecha de nacimiento, código postal, capital, si fuma |
   | Coche | fecha de nacimiento del conductor, código postal, años de carnet, modalidad (terceros, terceros ampliado, todo riesgo con franquicia, todo riesgo), marca y año; modelo, valor y CV opcionales |
   | Hogar | piso o casa, propietario o inquilino, m², código postal, nivel (esencial, completo, premium) |
   | Decesos | fecha de nacimiento, código postal, prima nivelada o natural |
   | Viaje | zona (España, Europa, mundo, mundo con EE. UU.), viaje puntual o anual, nivel, días si es puntual, nº de viajeros |
   | Mascotas | perro o gato, edad, nivel (responsabilidad civil, completo, premium), si es raza PPP |
   | Moto | modalidad, fecha de nacimiento, años de carnet, código postal, cilindrada |
   | Patinete | nivel (responsabilidad civil o completo); valor opcional |
   | Responsabilidad civil | individual o familiar, capital |

   - Pregunta lo que falte **en una sola tanda**. Fechas en formato
     `AAAA-MM-DD`; importes, años y m² como texto numérico (`"150000"`).
   - Si el usuario da la edad y no la fecha, usa una fecha aproximada (1 de
     enero del año que corresponda) y díselo.
   - Si da una ciudad, usa su código postal principal solo si es inequívoco; si
     no, pregúntalo.
   - No pidas datos que la tool no necesita: nombre, DNI, teléfono, correo,
     matrícula ni historial médico.

3. **Llama una vez** a `cotizar_<línea>`. Si el usuario cambia un dato
   relevante, vuelve a llamarla; si solo pregunta por una opción ya mostrada,
   responde con texto.

4. **Presenta el resultado.**
   - Si la interfaz muestra la comparativa como tarjetas (claude.ai, Claude
     Desktop), no la repitas: 1-2 frases con la opción más barata y el rango de
     precios.
   - Si solo hay texto (Claude Code, Cowork), muestra una tabla corta con las
     3-5 más baratas: aseguradora, producto, €/mes y €/año, e indica cuántas
     ofertas hay en total.
   - Recuerda siempre que son **estimaciones orientativas**: la prima final la
     fija la aseguradora tras su cuestionario.
   - Incluye el enlace a IAseguro que trae el resultado para ver la comparativa
     completa y contratar. No inventes URLs.

5. **Límites.** No contrates ni pidas datos de pago. No des asesoramiento
   personalizado vinculante: si piden una recomendación, explica diferencias
   objetivas (precio, coberturas, franquicias) y deja la decisión al usuario.

Responde en el idioma del usuario (los datos del conector vienen en español).
