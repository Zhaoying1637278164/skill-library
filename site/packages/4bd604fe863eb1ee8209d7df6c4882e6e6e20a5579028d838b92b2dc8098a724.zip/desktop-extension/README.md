# IAseguro for Claude Desktop (MCPB)

One-click Claude Desktop extension that connects Claude to IAseguro, an
independent insurance comparison service for Spain: indicative quotes from 20+
insurers for life, health, car, home, funeral, travel, pet, motorbike,
e-scooter and liability insurance, health plans matched to your preferences and
coverage details per insurer.

## How it works

`server/index.js` is a thin stdio ↔ Streamable HTTP bridge. Claude Desktop runs
it locally and every MCP request (`tools/list`, `tools/call`, `resources/list`,
`resources/read`) is forwarded unchanged to IAseguro's remote MCP server at
`https://mcp.iaseguro.com/mcp/claude`. Tools, results and the interactive cards
(MCP Apps) are exactly those of the remote connector. The extension stores
nothing on your computer and needs no account, API key or configuration.

All 21 tools are read-only: `cotizar_*` (price comparisons), `recomendar_salud`
(health plans), `detalle_*` (coverages) and `consultar_disponibilidad`.

## Install

Download `iaseguro.mcpb` from <https://iaseguro.com/claude> and double-click it,
or drag it into Claude Desktop (*Settings → Extensions*).

## Build from source

```bash
npm run pack   # npm ci --omit=dev + mcpb pack → iaseguro.mcpb
```

## Privacy Policy

IAseguro's privacy policy: <https://iaseguro.com/privacidad> (section "Si usas
IAseguro desde ChatGPT o Claude").

- **Data collection:** only the arguments Claude sends to each tool (for
  example date of birth, postcode and insured amount for a life quote; coverage
  preferences — never medical data — for health plans). No other conversation
  content and no Claude account data.
- **Usage and storage:** arguments are used to compute the estimate and are not
  stored with your identity. For usage metrics the server records the tool
  name, argument names (not values), the first two digits of the postcode, the
  insured amount, the insurer queried, the result and its duration, the user
  agent and a pseudonymous hash of IP address + user agent.
- **Third-party sharing:** product analytics (PostHog, EU). Nothing is sold.
  Links to insurers' websites carry UTM parameters.
- **Retention:** web server logs with the source IP are kept for about 52 days;
  pseudonymous usage metrics are kept while they are useful to measure and
  improve the service.
- **Contact:** <info@iaseguro.com>

## Disclaimer

Prices are indicative estimates based on market tariffs, not binding offers:
each insurer sets the final premium. Not personalised financial, legal or
medical advice.

## License

MIT © 2026 IAseguro
