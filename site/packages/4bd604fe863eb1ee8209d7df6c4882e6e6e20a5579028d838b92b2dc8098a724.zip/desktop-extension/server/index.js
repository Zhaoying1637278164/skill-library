#!/usr/bin/env node
/**
 * IAseguro — Claude Desktop extension (MCPB).
 *
 * A thin stdio ↔ Streamable HTTP bridge to IAseguro's remote MCP server
 * (https://mcp.iaseguro.com/mcp/claude). Claude Desktop starts this process
 * locally and talks to it over stdio; every request is forwarded unchanged to
 * the remote server, so tools, results and interactive cards (MCP Apps) are
 * exactly the ones the remote connector serves. Nothing is stored locally.
 *
 * Only these MCP methods are bridged: tools/list, tools/call, resources/list,
 * resources/read. All tools are read-only.
 */
import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js'
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import {
  CallToolRequestSchema,
  ListResourcesRequestSchema,
  ListToolsRequestSchema,
  ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js'

const VERSION = '1.0.0'
const REMOTE_URL = process.env.IASEGURO_MCP_URL || 'https://mcp.iaseguro.com/mcp/claude'
const USER_AGENT = `iaseguro-mcpb/${VERSION} (Claude Desktop)`

const FALLBACK_INSTRUCTIONS =
  'IAseguro compares indicative insurance prices and coverages in Spain. Prices are estimates, not binding offers.'

/** @type {Client | null} */
let remote = null
/** @type {Promise<Client> | null} */
let connecting = null

/** Connects (once) to the remote server; a failed attempt is retried on the next request. */
function getRemote() {
  if (remote) return Promise.resolve(remote)
  if (!connecting) {
    connecting = (async () => {
      const client = new Client({ name: 'iaseguro-desktop-extension', version: VERSION })
      const transport = new StreamableHTTPClientTransport(new URL(REMOTE_URL), {
        requestInit: { headers: { 'User-Agent': USER_AGENT } },
      })
      await client.connect(transport)
      remote = client
      return client
    })().finally(() => {
      connecting = null
    })
  }
  return connecting
}

/**
 * Runs a request against the remote server. If the connection dropped (network
 * change, server restart), reconnects once and retries.
 * @template T
 * @param {(client: Client) => Promise<T>} fn
 * @returns {Promise<T>}
 */
async function forward(fn) {
  try {
    return await fn(await getRemote())
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    // MCP protocol errors (invalid params, unknown tool…) are not connection problems.
    if (/MCP error -3\d{4}/.test(message)) throw error
    remote = null
    return fn(await getRemote())
  }
}

async function main() {
  // Reuse the remote server's instructions when it is reachable at startup.
  let instructions = FALLBACK_INSTRUCTIONS
  try {
    instructions = (await getRemote()).getInstructions() || FALLBACK_INSTRUCTIONS
  } catch (error) {
    console.error('[iaseguro] remote server not reachable yet, will retry on first request:', error)
  }

  const server = new Server(
    { name: 'iaseguro', version: VERSION },
    { capabilities: { tools: {}, resources: {} }, instructions },
  )

  server.setRequestHandler(ListToolsRequestSchema, (request) =>
    forward((client) => client.listTools(request.params)),
  )
  server.setRequestHandler(CallToolRequestSchema, (request) =>
    forward((client) => client.callTool(request.params)),
  )
  server.setRequestHandler(ListResourcesRequestSchema, (request) =>
    forward((client) => client.listResources(request.params)),
  )
  server.setRequestHandler(ReadResourceRequestSchema, (request) =>
    forward((client) => client.readResource(request.params)),
  )

  await server.connect(new StdioServerTransport())
}

main().catch((error) => {
  console.error('[iaseguro] fatal:', error)
  process.exit(1)
})
