import type { DownloadODataServiceMetadataInput, DownloadODataServiceMetadataOutput } from '../types/index.js';

import path from 'node:path';
import fs from 'node:fs';
import { isAppStudio } from '@sap-ux/btp-utils';
import type { BackendSystem } from '@sap-ux/store';
import { getServiceMetadata, findSystem } from './services/sap-system.js';

const EMPTY_PARAMS: DownloadODataServiceMetadataOutput['parameters'] = {
    host: '',
    servicePath: '',
    metadataFilePath: ''
};

/**
 * Downloads OData service metadata from a SAP system and saves it as metadata.xml.
 *
 * @param params - Input parameters containing sapSystemQuery, servicePath and appPath.
 * @returns A promise resolving to the execution output with host, servicePath, client and metadataFilePath.
 */
export async function downloadODataServiceMetadata(
    params: DownloadODataServiceMetadataInput
): Promise<DownloadODataServiceMetadataOutput> {
    const sapSystemQuery = String(params.sapSystemQuery ?? '').trim();
    const servicePath = String(params.servicePath ?? '').trim();

    // Check if we're in AppStudio - if so, this tool should not be used
    // Service Center MCP should be used instead for BAS/Destination scenarios
    if (isAppStudio()) {
        return {
            status: 'Error',
            message:
                'This tool is not supported in SAP Business Application Studio. Please use the Service Center MCP server tool to retrieve service metadata when working with destinations.',
            parameters: EMPTY_PARAMS,
            appPath: params.appPath,
            changes: [],
            timestamp: new Date().toISOString()
        };
    }

    if (!fs.existsSync(params.appPath) || !fs.statSync(params.appPath).isDirectory()) {
        return {
            status: 'Error',
            message:
                `appPath does not exist or is not a directory: ${params.appPath}. Create the directory before calling this tool ` +
                `(e.g. on Unix: \`mkdir -p ${params.appPath}\`, on Windows: \`mkdir "${params.appPath}"\`). This tool does not create directories.`,
            parameters: EMPTY_PARAMS,
            appPath: params.appPath,
            changes: [],
            timestamp: new Date().toISOString()
        };
    }

    if (!servicePath) {
        return {
            status: 'Error',
            message: 'Missing required parameter: servicePath must be provided',
            parameters: EMPTY_PARAMS,
            appPath: params.appPath,
            changes: [],
            timestamp: new Date().toISOString()
        };
    }

    const metadataFilePath = path.join(params.appPath, 'metadata.xml');
    if (fs.existsSync(metadataFilePath)) {
        return {
            status: 'Error',
            message:
                `A metadata.xml already exists at '${metadataFilePath}'. ` +
                `This tool is only for downloading metadata when generating a new Fiori app. ` +
                `To refresh service metadata for an existing app, use the \`search_docs\` tool with query \`"update service metadata"\` to find the correct CLI workflow.`,
            parameters: EMPTY_PARAMS,
            appPath: params.appPath,
            changes: [],
            timestamp: new Date().toISOString()
        };
    }

    try {
        const findResult = await findSystem(sapSystemQuery || servicePath);
        if (!findResult.system) {
            return {
                status: 'Error',
                message: findResult.message ?? 'The requested system could not be found',
                parameters: EMPTY_PARAMS,
                appPath: params.appPath,
                changes: [],
                timestamp: new Date().toISOString()
            };
        }
        const foundSystem = findResult.system;

        // At this point, foundSystem should be a BackendSystem (VSCode only)
        const metadata = await getServiceMetadata(foundSystem as BackendSystem, servicePath);
        fs.writeFileSync(metadataFilePath, metadata, 'utf-8');

        const backend = foundSystem as BackendSystem;
        const host = backend.url;
        const client = backend.client;

        return {
            status: 'Success',
            message: 'Service metadata downloaded successfully.',
            changes: [],
            parameters: {
                host,
                client,
                servicePath,
                metadataFilePath
            },
            appPath: params.appPath,
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        return {
            status: 'Error',
            message: `Could not fetch metadata for service '${servicePath}': ${reason}`,
            parameters: EMPTY_PARAMS,
            appPath: params.appPath,
            changes: [],
            timestamp: new Date().toISOString()
        };
    }
}
