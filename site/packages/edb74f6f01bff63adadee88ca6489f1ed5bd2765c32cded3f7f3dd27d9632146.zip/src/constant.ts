export const LATEST_UI5_VERSION = '1.136.7';
export const ADD_PAGE = 'add-page';
export const DELETE_PAGE = 'delete-page';
export const CREATE_CONTROLLER_EXTENSION_FUNCTIONALITY_ID = 'create-controller-extension';
export const EXTENSION_FILE_NAME_PATTERN = /^[A-Za-z][A-Za-z0-9_-]*$/;

// Telemetry event names
export const TELEMETRY_MCP_SERVER_INITIALIZED = 'mcp-server-initialized';
export const TELEMETRY_MCP_LIST_TOOLS = 'mcp-list-tools';
