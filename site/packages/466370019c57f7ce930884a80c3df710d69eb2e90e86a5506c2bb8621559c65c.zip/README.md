# Saleshandy Plugin for Claude Code

This plugin brings Saleshandy prospecting and enrichment into Claude Code. It connects to Saleshandy's hosted MCP server at `https://mcp.saleshandy.com/mcp`. You sign in via your browser once; there are no API keys to manage.

You don't have to memorize commands. Just describe what you want in plain language, and Claude routes the request to the right Saleshandy workflow automatically.

## What's in the box

The plugin ships **two workflows**, each available via natural language *or* an explicit slash command.

### Discover and enroll

Describe an ideal customer profile and Claude searches Lead Finder, optionally enriches the matches, and (if you want) enrolls them into a sequence step.

Just say things like:
- *"Find HR managers at 51–200 employee SaaS companies in the EU"*
- *"Get me 20 fintech CTOs with phones"*
- *"Show me marketing directors at Series B startups"*

Or invoke explicitly with `/saleshandy:discover-and-enroll <ICP description> [--phone]`.

### Enrich leads

Paste a LinkedIn URL, a company domain, or "Name at Company". Claude reveals the verified email (and optionally phone).

Just say things like:
- *"Enrich https://linkedin.com/in/<linkedin-handle>"*
- *"What's the email for <name> at <company.com>?"*
- *"Look up <company.com> — include phones"*

Or invoke explicitly with `/saleshandy:enrich-leads <linkedin_url | domain | "Name at company.com"> [--phone]`.

## Prerequisites

- A [Saleshandy](https://www.saleshandy.com) account (free signup; you'll authenticate via your browser the first time you run a workflow).
- Lead Finder credits on that account — enrichment is metered (~1 credit per email reveal, ~7 credits per email + phone reveal, ~0.1 credit per company enrichment).
- A recent version of Claude Code (skills require a current build; update with `claude update` if your install is older than a few weeks).

## Install

Inside Claude Code, add the Saleshandy marketplace and install the plugin:

```text
/plugin marketplace add saleshandy/saleshandy-plugin
/plugin install saleshandy@saleshandy-plugin
```

Or do it in one step from your shell:

```bash
claude plugin marketplace add saleshandy/saleshandy-plugin
claude plugin install saleshandy@saleshandy-plugin
```

To pin a specific release, append a tag to the marketplace URL:

```text
/plugin marketplace add https://github.com/saleshandy/saleshandy-plugin.git#v1.0.0
```

### Updating

Once installed, pull the latest published version with:

```text
/plugin marketplace update saleshandy-plugin
```

### Local development

If you're working on the plugin from a checkout, point the marketplace at the directory:

```text
/plugin marketplace add /absolute/path/to/saleshandy-plugin
/plugin install saleshandy@saleshandy-plugin
```

## Authentication

The hosted MCP server uses OAuth 2.0 (RFC 9728 + RFC 7591 dynamic client registration). The first time you trigger a Saleshandy workflow (whether by natural language or by typing a `/saleshandy:*` command):

1. Claude Code discovers the OAuth endpoints from the MCP server and registers itself as a client.
2. Your browser opens Saleshandy's sign-in page.
3. You sign in and approve the `mcp:read` scope.
4. Claude Code stores the token in its local config.

Subsequent runs reuse the token. To revoke access, sign out of Saleshandy or remove the stored credentials from Claude Code's auth UI.

## How it behaves

The plugin is conservative about anything that changes Saleshandy state. `add_leads_to_sequence` always shows a preview and waits for an explicit confirmation from you. The model does not pick the sequence or the step — those are always your choices.

- Sage search is capped at 1 call per turn and 6 per conversation. `discover-and-enroll` does not fan out to find more results; it surfaces `payload.resultUrl` so you can refine in the Saleshandy web app.
- Enrichment jobs are async (30 seconds to a few minutes). The plugin returns the `requestId` and asks you to check back rather than blocking. The 15-second cooldown on `get_enrichment_status` is respected.
- Lead Finder results and enrichment fields are displayed only when the API actually returns them. Missing fields are omitted, not filled in.
- **Personal email reveals are not supported.** Enrichment only returns verified *work* emails. If you ask for a personal/gmail/non-work email, the plugin will not attempt it and will direct you to request it at [my.saleshandy.com/v2/leads/people/total](https://my.saleshandy.com/v2/leads/people/total) instead.

## Layout

```
saleshandy-plugin/
├── .claude-plugin/
│   ├── plugin.json          # plugin manifest
│   └── marketplace.json     # marketplace catalog (this repo IS the marketplace)
├── commands/                # explicit slash-command surface
│   ├── enrich-leads.md
│   └── discover-and-enroll.md
├── skills/                  # natural-language surface (model-invoked)
│   ├── discover-and-enroll/
│   │   └── SKILL.md
│   └── enrich-leads/
│       └── SKILL.md
├── .mcp.json                # registers the hosted Saleshandy MCP server (OAuth auto-discovery)
├── CONTRIBUTING.md
├── LICENSE
└── README.md
```

## Troubleshooting

- **OAuth flow doesn't open a browser** — Claude Code's MCP OAuth requires a recent version with HTTP transport + dynamic client registration support. Update Claude Code if the flow stalls.
- **`401` after sign-in** — your Saleshandy session may have expired. Re-trigger a Saleshandy workflow and Claude Code will re-authenticate.
- **"Tool not found: mcp__saleshandy__..."** — the MCP server isn't reachable. Check that `https://mcp.saleshandy.com/mcp` is accessible from your network.
- **Sage search returns 0 results, refining doesn't help** — that's the answer. The plugin won't auto-retry. Use the `payload.resultUrl` from the response to refine in the Saleshandy web app.
- **Enrichment stuck at `in-progress` forever** — large batches can take a few minutes. Note the `requestId` and check back; don't keep re-running the command.

## Contributing

Found a bug or have a feature request? Open an issue on [GitHub](https://github.com/saleshandy/saleshandy-plugin/issues). For development and release workflow, see [CONTRIBUTING.md](./CONTRIBUTING.md).

## License

MIT — see [LICENSE](./LICENSE).
