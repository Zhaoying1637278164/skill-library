---
name: enrich-leads
description: Reveal verified work email (and optionally phone) for a person or company via Saleshandy Lead Finder. Use whenever the user pastes a LinkedIn profile URL, a LinkedIn company URL, a company domain (e.g. "acme.com"), or a "FirstName LastName at company.com" / "Name, Company" string and asks to enrich, reveal, look up, get the email for, get the phone for, or find contact info for them. Auto-detects person vs company input. Mention `--phone` or "include phone" / "with phones" for phone reveal (~7 credits/lead vs ~1 for email-only; company enrichment is ~0.1 credit/company).
---

# enrich-leads

The user has asked to enrich a person or company. Execute the workflow in `${CLAUDE_PLUGIN_ROOT}/commands/enrich-leads.md` — read it first, then run it.

Treat the user's natural-language message as the equivalent of `$ARGUMENTS` in that file. Apply every rule in the command verbatim:

- **Parse input into the right bucket** (LinkedIn person URL → `enrich_contacts`, LinkedIn company URL or bare domain → `enrich_companies`, "Name at company.com" → `enrich_contacts` with `full_name_with_company`).
- **Never enrich a raw email address** — the API has no email-lookup path. Tell the user, and offer to enrich the company domain or route through `discover-and-enroll` instead.
- **Personal email reveals are not supported** — if the user asks for a personal/non-work email (gmail, yahoo, etc.), do not run enrichment. Tell them this is currently unsupported and direct them to request it at https://my.saleshandy.com/v2/leads/people/total. Saleshandy Lead Finder only returns verified work emails.
- **Default `reveal_phone: false`** unless the user said `--phone`, "include phone", "with phone", or similar.
- **Don't poll in a tight loop** — first poll ~10s after kickoff, respect the 15s cooldown, and surface the `requestId` if it's still in-progress after ~30–60s.
- **Don't fabricate fields** — show only what `payload.results` returned. Skip missing fields rather than writing "N/A".
- **Always surface `creditsCharged`** so the user sees what the operation cost.

The user does not need to type a slash command — your job is to recognize the intent and run this workflow.
