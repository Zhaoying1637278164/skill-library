---
name: discover-and-enroll
description: ICP-driven prospecting via Saleshandy Lead Finder. Use whenever the user asks to find, search, discover, source, get, or list prospects, leads, contacts, or people matching a natural-language description — e.g. "find HR managers at fintech SaaS", "get me CTOs in 51-200 employee SaaS companies", "show me marketing directors at series B startups", "I need 20 sales leaders in EU". Also handles "get emails for [people description]" and "find phone numbers for [ICP]". Wraps natural-language Lead Finder search, async enrichment (with credit-cost gating), and optional gated enrollment into a Saleshandy sequence step.
---

# discover-and-enroll

The user has asked to discover prospects matching an ICP and possibly enroll them into a sequence. Execute the workflow in `${CLAUDE_PLUGIN_ROOT}/commands/discover-and-enroll.md` — read it first, then run it end-to-end.

Treat the user's natural-language message as the equivalent of `$ARGUMENTS` in that file. Apply every gate in the command verbatim:

- **At most 1 `sage_search` call per user turn, 6 per conversation.** No fan-out.
- **Ask before revealing contacts** when the query is discovery-style and returns more than 3 results (each reveal costs credits). Auto-reveal only on explicit contact-intent phrasing or ≤3 leads.
- **Never pick the sequence or step yourself.** If the user wants to enroll, always present `list_sequences` and `list_sequence_steps` and wait for explicit picks.
- **Don't poll enrichment in a tight loop** — respect the 15s cooldown and the `throttled: true` signal.
- **Don't fabricate leads** — show only what `payload.results` returned, and surface `payload.resultUrl` for the user to refine in the Saleshandy web app.

The user does not need to type a slash command — your job is to recognize the intent and run this workflow.
