---
description: Reveal verified work email (and optionally phone) for a person or company. Detects LinkedIn URL, domain, or "Name at Company" input.
argument-hint: <linkedin_url | domain | "FirstName LastName at company.com">  [--phone]
allowed-tools: mcp__saleshandy__enrich_contacts, mcp__saleshandy__enrich_companies, mcp__saleshandy__get_enrichment_status, mcp__saleshandy__get_enrichment_result
---

# /saleshandy:enrich-leads

Reveal verified contact/company data via Saleshandy Lead Finder. **One command, smart input routing** — figure out whether the user pasted a person or a company, then call the right enrichment tool, poll, and present.

## Input parsing (do this first, no guessing)

Parse `$ARGUMENTS` into a list of inputs (newline- or comma-separated). For each input, pick exactly ONE bucket:

| Pattern | Bucket | Tool | Shape |
|---|---|---|---|
| `https://linkedin.com/in/<slug>` (or `linkedin.com/in/...`) | person | `enrich_contacts` | `linkedin_url[]` |
| `https://linkedin.com/company/<slug>` | company | `enrich_companies` | `linkedin_url[]` |
| Bare domain (`acme.com`) or full URL (`https://acme.com`) — no `@` and no `/in/` | company | `enrich_companies` | `company_domain[]` (strip protocol/path → `acme.com`) |
| `"FirstName LastName at example.com"` or `"FirstName LastName, Acme"` (where `example.com` is a domain) | person | `enrich_contacts` | `full_name_with_company[]` with `{ first_name, last_name, company_domain }` |
| Raw email like `name@company.com` | **AMBIGUOUS — DO NOT enrich directly.** | — | Tell the user the API doesn't accept email-only lookups. Offer two options: (a) enrich the company domain, or (b) run `/saleshandy:discover-and-enroll` for "people at <that-company.com>" to get lead IDs first. Wait for their pick. |
| Personal email reveal request (e.g. "personal email for X", "non-work email") | **NOT SUPPORTED.** | — | Saleshandy Lead Finder only reveals **verified work emails**. Tell the user this is not supported via the plugin and direct them to request it at https://my.saleshandy.com/v2/leads/people/total. Do not attempt the enrichment. |

If parsing fails or the input is empty, ask the user for one of the supported formats (don't fabricate fields).

## Flags

- `--phone` — sets `reveal_phone: true` on `enrich_contacts` (~7 credits/lead vs ~1 for email-only). Default is email-only. Only applies to the contacts call. If the user has phone-mixed and email-mixed intent across a batch, ask before splitting.
- Company enrichment via `enrich_companies` costs ~0.1 credit per company. Cheap enough to run without an extra confirmation prompt, but always surface `creditsCharged` afterwards.

## Execution

1. **Group inputs**: build a contacts batch and a companies batch from the parsed inputs (max 100 combined per call for each). If both buckets are non-empty, call them in parallel — they return separate `requestId`s.
2. **Surface the requestIds** to the user immediately. They're how the user (or you) can resume later.
3. **Poll status** with `get_enrichment_status` for each requestId:
   - First poll: ~10s after kickoff is fine.
   - The tool itself enforces a 15s cooldown per requestId. If the response comes back with `throttled: true`, that means you polled too fast — wait the `retryAfterMs` it tells you, don't retry sooner.
   - Status is `in-progress` | `completed` | `failed`.
   - If still `in-progress` after a couple of polls (~30-60s), STOP polling, surface the requestId, tell the user "still running, I'll fetch results when you ask me to check on `<requestId>`". Do NOT block.
4. **Fetch results** with `get_enrichment_result` once status is `completed`.
5. **Failed** → report failure plainly, don't retry.

## Presentation

- For people: name, title, company, **email**, **phone** (if `--phone`), location. Skip fields the API didn't return — don't write "N/A" or guess.
- For companies: name, domain, industry, size, location, technologies if returned.
- Always mention `creditsCharged` so the user sees what the operation cost.
- If the same batch had both contacts and companies, show two sections.

## Don'ts

- Don't enrich raw email addresses — the API has no email-lookup path. Always ask first or route through `discover-and-enroll`.
- Don't attempt personal email reveals (gmail/yahoo/non-work). The API only returns verified work emails — redirect the user to https://my.saleshandy.com/v2/leads/people/total.
- Don't fabricate fields. Show only what's in `payload.results`.
- Don't poll in a tight loop. Respect the 15s cooldown and the `throttled: true` signal.
