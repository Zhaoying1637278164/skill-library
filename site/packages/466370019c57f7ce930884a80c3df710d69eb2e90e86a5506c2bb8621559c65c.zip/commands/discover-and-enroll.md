---
description: ICP-driven prospecting — natural-language search, enrich, and (optionally) enroll into a sequence step.
argument-hint: <natural-language ICP description> [--phone]  e.g. "fintech CTOs in EU at 51-200 employee SaaS companies"
allowed-tools: mcp__saleshandy__sage_search, mcp__saleshandy__enrich_contacts, mcp__saleshandy__get_enrichment_status, mcp__saleshandy__get_enrichment_result, mcp__saleshandy__list_sequences, mcp__saleshandy__list_sequence_steps, mcp__saleshandy__add_leads_to_sequence
---

# /saleshandy:discover-and-enroll

End-to-end prospecting flow:

```
sage_search → enrich_contacts → poll → get_enrichment_result → add_leads_to_sequence (gated)
```

Naturally spans **multiple turns** because enrichment is async (30s–several minutes). Don't block waiting.

## Step 1 — Search (sage_search)

Parse `$ARGUMENTS`:
- The natural-language query is everything that isn't a flag.
- `--phone` flag → set `reveal_phone: true` in step 2 (~7 credits/lead instead of ~1). Natural-language equivalents like "with phones", "include phones", "email and phone" also count.
- **Detect contact-intent:** if the query phrasing explicitly asks for contact info (e.g. "get me emails for...", "reveal contacts for...", "find email/phone for...", "I need contact info for...") set `contactIntent = true`. If the query is just discovery ("find HRs in technical firms", "show me CTOs at SaaS companies"), `contactIntent = false`.
- If the query portion is empty, ask the user for an ICP description.

Call `sage_search` once with the query.

**HARD CAPS — do not violate:**
- **At most 1 `sage_search` call per user turn.** No fan-out, no "let me try a broader query too", no parallel searches.
- A small result count IS the answer. 0, 1, 5 results — surface what came back plus `payload.resultUrl` and STOP. Don't retry to "find more".

After the call:
- Save `payload.conversationId` for any user-driven refinement ("now narrow to Series B"). Pass it back as `conversationId` on the next call.
- Surface `payload.resultUrl` near the top as a markdown link: "View full results on Saleshandy".
- Show all entries from `payload.results` (up to 25). Don't fabricate.
- Briefly relay `payload.agentMessage` so the user sees how the query was interpreted.

## Step 2 — Enrich (default: ask first; auto only in narrow cases)

Decide whether to ask or auto-reveal using this rule:

| Situation | Action |
|---|---|
| `contactIntent` is true (user explicitly asked for contact info) | **Auto-reveal.** No question. The user's intent is already clear. |
| `payload.results.length ≤ 3` | **Auto-reveal.** Tiny batch — credits are negligible and asking is friction. |
| Otherwise (the common case after a discovery query) | **Ask first.** "Reveal emails for these `<N>` leads (~`<N>` credits)? Email-only, or include phone (~`<7N>` credits)?" Wait for explicit confirmation. |

This keeps the workflow snappy when intent is unambiguous, but defaults to confirmation when the user just searched discovery-style and a 25-lead reveal would silently burn 25 credits.

Once you have a green light (auto or confirmed):

1. Collect the `id` values from `payload.results[].id` (numeric Lead Finder IDs). If the user named a smaller subset ("just the top 5", "only the ones at Acme"), respect that.
2. Call `enrich_contacts` with `lead_id: [...]` and `reveal_phone` per `--phone` / NL phrasing (default `false`).
3. Capture the `requestId`. Surface it briefly (one line) so the user can reference it later — don't make it the focus.
4. Poll with `get_enrichment_status`:
   - First poll ~10s after kickoff.
   - The tool throttles to 15s/requestId. If you get `throttled: true`, wait `retryAfterMs` before retrying — don't spin.
   - If still `in-progress` after ~30–60s of polling, STOP, surface the requestId, tell the user "still revealing — ask me to check on `<requestId>` and I'll pick up where we left off." Don't block.
5. When `completed`, call `get_enrichment_result` and display the revealed leads (name, title, company, email, phone if requested, location). Mention `creditsCharged` so the user sees what it cost.
6. If `failed`, report plainly and stop. Don't auto-retry.

## Step 3 — Offer enrollment

After enriched results are on screen, ask: **"Want to enroll these into a sequence?"** Destinations are always a user choice.

If the user says yes:

**HARD GATE — DO NOT pick the sequence or step yourself. Both are user choices, every time.**

1. Call `list_sequences` and present the active sequences (id + title). Ask "Which sequence?". Wait. Never default to the only/newest sequence.
2. Call `list_sequence_steps` and present each step as `Step <number> — <channel>` (e.g. `Step 1 — Email`, `Step 2 — LinkedIn Connection Request`). Read the channel from the response's `typeLabel` field and humanize it (split camelCase, keep product names like LinkedIn / WhatsApp correctly cased). Never translate the numeric `type` yourself, and never list bare step numbers without a channel. Ask "Which step?" and wait — don't default to step 1.
3. Show a preview: "Enrolling N leads into `<sequence>` › step `<n>`. Proceed?" — wait for explicit "yes".
4. Only then, call `add_leads_to_sequence` with `leadIds`, `sequenceId`, `stepId`, and optional `newTags` if the user mentioned a tag (e.g. "tag them as Q2 Outbound").

If the user says no, end cleanly — they have the enriched data, they can use it however.

**Reminder:** `add_leads_to_sequence` silently skips leads whose work email wasn't revealed. If any in the batch failed enrichment, warn the user — those won't enroll.

## Don'ts

- Don't auto-reveal a large discovery-style batch. The default is to ask. Only auto-reveal on explicit contact-intent or ≤3 leads.
- Don't keep asking when intent is clear. If the user said "get me emails for top 5 HRs at Acme", that's explicit — just enrich.
- Don't fan out sage_search — one call per turn even if the user says "search across multiple regions".
- Don't bypass the sequence/step picker. Even if it feels obvious from context, ask.
- Don't poll enrichment in a tight loop. Respect the 15s cooldown.
- Don't fabricate leads. Use only `payload.results` entries verbatim.
