# Contributing

Thanks for your interest in improving the Saleshandy plugin for Claude Code. This document covers local development and the release workflow.

## Local development

The plugin is plain Markdown — no TypeScript, no build step. Edit a command file under `commands/` (explicit slash-command surface) or a `skills/<name>/SKILL.md` file (natural-language, model-invoked surface) and it takes effect on the next invocation.

Skills reference the corresponding command file as the workflow source of truth. When you change workflow logic, edit `commands/<name>.md` — the matching skill picks it up automatically because it instructs the model to read `${CLAUDE_PLUGIN_ROOT}/commands/<name>.md`. Update the skill's `description` only when trigger phrasing changes (e.g. you want it to fire on a new natural-language pattern).

To install the plugin from a local checkout for testing, run from outside the repo:

```text
/plugin marketplace add /absolute/path/to/saleshandy-plugin
/plugin install saleshandy@saleshandy-plugin
```

To pull in changes after editing locally:

```text
/plugin marketplace update saleshandy-plugin
```

Validate the manifest before committing:

```bash
claude plugin validate .
```

## Filing issues

- Bugs and feature requests: [GitHub Issues](https://github.com/saleshandy/saleshandy-plugin/issues)
- Include the Claude Code version (`claude --version`), the command you ran, and the relevant output.

## Pull requests

- Keep changes scoped — one command or fix per PR where possible.
- Update the relevant command file's frontmatter and the README's *What's in the box* section if you change behavior. If trigger phrasing changes, also update the matching skill's `description`.
- Do not introduce a build step or TypeScript. The plugin is intentionally Markdown-only.

## Releasing a new version

The repo *is* the marketplace, so a release is just a commit on `main`.

1. Make your changes (commands, `.mcp.json`, etc.).
2. Bump `version` in **both** files, keeping them in sync:
   - `.claude-plugin/plugin.json`
   - `.claude-plugin/marketplace.json` (the entry inside `plugins[]`, and the top-level `metadata.version`)
3. Validate locally:

   ```bash
   claude plugin validate .
   ```

4. Commit, push, and tag:

   ```bash
   git commit -am "release v1.1.0"
   git tag v1.1.0
   git push && git push --tags
   ```

Users receive the new version on their next `/plugin marketplace update saleshandy-plugin`.

### Versioning policy

Follow [Semantic Versioning](https://semver.org):

| Change | Bump |
|---|---|
| Bug fix, doc tweak, no behavior change | patch (`1.0.0` → `1.0.1`) |
| New command, new optional flag, additive behavior | minor (`1.0.1` → `1.1.0`) |
| Removed command, renamed flag, breaking argument change | major (`1.1.0` → `2.0.0`) |

### Release checklist

- [ ] Versions in `plugin.json` and `marketplace.json` match
- [ ] `claude plugin validate .` passes
- [ ] README *What's in the box* reflects any new/renamed commands or skills
- [ ] Skill `description` fields cover the natural-language phrasing you want to trigger on
- [ ] Tag matches the version (`v1.1.0` for `1.1.0`)
