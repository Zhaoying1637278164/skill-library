# Transitrix Ingest Skill

The **front door** of a Transitrix repository: it turns raw organisational material — interviews, policies, org charts, spreadsheets, notes — into `field`-zone artefacts and typed `canon` *candidates*, at scale, and routes everything through a human review gate. It is the operational counterpart to the onboarding skill's per-layer extraction prompts: the part that converts documents, scores source trust, runs the validators, and stages a review queue.

This directory is the **`ingest` skill** within the `transitrix` plugin (the plugin root is [`transitrix/`](../../), which carries the shared [`.claude-plugin/plugin.json`](../../.claude-plugin/plugin.json) manifest, with one `skills/<name>/` directory per skill). Invoked as `/transitrix:ingest`.

> **Status — operational.** Beyond the agent-facing protocol ([`SKILL.md`](SKILL.md)), JSON schemas ([`schemas/`](schemas/)), and the `_intake/` convention ([`templates/_intake.README.md`](templates/_intake.README.md)), the deterministic CLI ([`@transitrix/ingest-cli`](../../../packages/ingest-cli/)) implements all subcommands and is covered by a no-API-key integrity test (see [Roadmap](#roadmap)). The skill's Step 0 pre-check still stops cleanly if the CLI is not installed in a given environment.

---

## The one rule

**Propose, never write admitted canon.** The skill emits `field` artefacts and canon *candidates*, runs them through the existing validators, and produces a review queue. It never writes **admitted** canon (anything carrying an admission record). Admission stays a deliberate, auditable human gate (`admitted_by`). A hallucinated element or relation reaching canon unreviewed is the worst-case failure; every design choice here exists to prevent it. The `canon/unresolved/` holding area ([SKILL.md Step 7](SKILL.md)) is the one place the pipeline parks data under the `canon/` path — and the skill only ever writes `proposed` (non-admitted) entries there; promoting one to *admitted-but-untyped* (an accurate object whose only gap is its TYPE, [CONTRACT §13.1](../../../notations/CONTRACT.md)) is the human gate's act, so the rule holds.

## Catalogue federation

Use `/transitrix:ingest` with “join the decision-log network”, “pin this catalogue”,
“recognise local elements”, or “promote TERM-9”. The
[catalogue workflow](references/catalogue-federation.md) covers L0 adoption, L1
pins, L2 recognition, and L3 promotion. It stages proposals for review and provides
the binding command for a human to run after acceptance. Local IDs stay unchanged;
central admission and catalogue publication remain the central maintainer's work.

## Two axes of trust, never merged

- **`source_quality`** — trust in the *source* (signed policy → `authoritative`; meeting note → `single_source`). A closed ordinal label on the field artefact's admission record ([CONTRACT §11.2](../../../notations/CONTRACT.md)). The skill proposes it from document type; a human confirms.
- **`extraction_confidence`** — "did the model read the document correctly". A separate review flag on each candidate. It surfaces in the review queue and is **never** folded into `source_quality`, and **never** persisted into canon ([CONTRACT §11.8](../../../notations/CONTRACT.md)).

## What it ships

- [`SKILL.md`](SKILL.md) — the agent-facing, agent-neutral protocol: a seven-step pipeline (`scaffold-intake → convert → privacy-scan → admit-source → emit-candidates → validate → review-queue`) plus the hard constraints.
- [`schemas/`](schemas/) — JSON Schemas for the artefacts the pipeline produces: a `field` artefact ([`field-artefact.schema.json`](schemas/field-artefact.schema.json)), a canon candidate ([`candidate.schema.json`](schemas/candidate.schema.json)), the review queue ([`review-queue.schema.json`](schemas/review-queue.schema.json)), and the privacy gate report ([`privacy-report.schema.json`](schemas/privacy-report.schema.json)).
- [`templates/_intake.README.md`](templates/_intake.README.md) — the documentation the CLI drops into an adopter's `_intake/` folder describing the `inbox → processing → processed` flow.

---

## Why the deterministic logic is a Node CLI

All heavy logic — Markitdown conversion, coverage-profile read, validator pass, field-artefact + candidate emission, the `_intake/` moves — lives in a CLI (`@transitrix/ingest-cli`), not in this `SKILL.md`. The CLI is **Node** (`.mjs`), chosen by the following balance:

| Criterion | Node CLI | Python CLI |
|---|---|---|
| Consistency with the repo's deterministic guarantees | The canonical validators (`scripts/check-notations.mjs`, `scripts/check-skill-cheatsheet.mjs`) are already Node — "deterministic guarantees never depend on the runtime" is established on Node. | diverges from the validators |
| Adopter delivery (`.github/skills/`) + invocation | `npx`-able, no per-adopter virtualenv | needs a Python env on the adopter machine |
| "No native deps" | pure JS | PyYAML is an external dependency |
| Office → Markdown (Markitdown is a Python tool) | shelled out to the `markitdown` CLI inside the `convert` command only — a single, isolated point of contact | imported natively |

Python in this repo is used **only in the onboarding skill's tests**, not in shipped deterministic logic. Markitdown stays a shell-out from one subcommand; the rest of the pipeline is pure Node and behaves identically under either agent.

### CLI resolution — a standalone package

The CLI is resolved as a **standalone package** — not vendored per skill and not referenced by a repo-relative sibling path. A sibling-path reference would dangle when only this skill directory ships into a Copilot `.github/skills/ingest/` install; a standalone package is the single versioned source for both skills and both agents. Pre-1.0 the install is local (`npm install -g ./packages/ingest-cli` → `transitrix-ingest`); once the package ships from its own tooling repo at the ~1.0 extraction, `npm install -g @transitrix/ingest-cli` (or `npx @transitrix/ingest-cli <command>`) becomes the equivalent shorthand. Both forms invoke the same binary.

---

## Portability — Claude + GitHub Copilot

One shared `SKILL.md` in the converged **Agent Skills** format. Claude auto-loads it as `/transitrix:ingest`; Copilot picks the same directory up from `.github/skills/ingest/` or `~/.copilot/skills/ingest/`. The skill stays portable because:

- all heavy logic is in the CLI, not in agent-specific tool calls;
- `SKILL.md` is agent-neutral — it references the CLI and the procedure, with no Claude-only or Copilot-only assumptions;
- the skill directory is self-contained — prompts and schemas live in the bundle, never referenced from a sibling skill.

---

## The `_intake/` convention (skill-local in v0)

`_intake/` is an **operational** folder at the organisation root — *not a zone*. Zones (`canon/`, `field/`, `codex/`) stay parallel; `_intake/` sits beside them as the pipeline workspace, with `inbox/ → processing/ → processed/`. The admitted `field` artefact lives in `field/` (with its admission record and `source_quality`); the original raw file is retained in `_intake/processed/` so the artefact is traceable to its source.

In v0 this convention is **skill-local** — documented here and in [`templates/_intake.README.md`](templates/_intake.README.md), deliberately *not* yet reserved in the methodology `MANIFEST.md` / `CONTRACT.md`. Whether `_intake/` becomes a reserved org-structure convention is a separate proposal, taken once the skill stabilises.

---

## Roadmap

| Increment | Contents |
|---|---|
| **Skeleton** ✓ landed | `SKILL.md`, JSON schemas, `_intake/` convention, plugin wiring. |
| **CLI** ✓ landed | `@transitrix/ingest-cli` — the deterministic subcommands (`scaffold-intake`, `convert`, `admit-source`/`field-artefact`/`codex-artefact`, `emit-candidates`, `validate`, `review-queue`) + the forked extraction prompts in `prompts/`. |
| **Tests + CI** ✓ landed | A no-API-key integrity test (bundle + dry CLI run on a fixture) and a weekly LLM-drive, plus a workflow — mirroring the onboarding skill's test harness. |
| **Zero information loss** ✓ landed | `extensions:` carry-through + `canon/unresolved/` emission (CONTRACT §12/§13). `emit-candidates` carries `extensions:` onto candidates and parks untyped objects in `canon/unresolved/`; `validate` enforces `EXT-002`; `repo-check` reports the holding count; typed canon walkers skip the holding area (`UNRES-004`). Covered by Part O of the integrity test. |
| **Privacy gate** ✓ landed | Step 2b `privacy-scan`: rule-based fail-closed pre-admission gate with six PII/medical detection categories, a narrow business-contact allowlist, `CLEAN`/`STRIPPED`/`REJECTED`/`ERROR` outcomes, and a per-run `privacy-report.yaml`. `@transitrix/ingest-cli privacy-scan` is implemented; `admit-source --zone field` refuses to proceed without a passing, content-matching scan record. |

---

## What this skill does NOT do

- It does **not** write **admitted** canon. It emits candidates and a review queue; a human admits. Zero information loss without guessing: schema-undefined fields ride along in an `extensions:` bag ([CONTRACT §12](../../../notations/CONTRACT.md)) and standalone objects whose TYPE is unknown are parked in the shared, committed `canon/unresolved/` holding area ([CONTRACT §13](../../../notations/CONTRACT.md), [SKILL.md Step 7](SKILL.md)) — type resolution is a separate axis from admission, so such an object can even be admitted-accurate while still untyped.
- It does **not** ship the methodology canon. It reads the published specs (via `WebFetch`).
- It does **not** fold `extraction_confidence` into `source_quality`, or persist either extraction-confidence value into canon.
- It does **not** emit TYPEs or REL kinds outside the adopter's coverage profile — out-of-profile material is flagged for review, never silently emitted or dropped.
- It does **not** auto-admit or move data between zones. `derived_from` is a citation, not a migration.
- It does **not** bypass the privacy gate. No document reaches `admit-source` unless `privacy-scan` exits `CLEAN` or `STRIPPED`. Disabling the gate requires an explicit adopter decision in `transitrix.yaml`.
