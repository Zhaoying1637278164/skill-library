# Changelog

## 1.3.1 — correct the documented loop limits
- **Fixes a false claim in 1.3.0.** `/dispatch-board:loop` and the README stated a "72-hour cap" on a single `/loop` run. That is wrong. The real constraints, per Claude Code's scheduled-task docs: recurring tasks **expire 7 days after creation**, ticks fire **only while Claude Code is running and idle**, there is **no catch-up for missed fires**, and a recurring tick can be **up to 30 minutes late** (jitter).
- Documents the three local overnight substrates and what each survives: `/loop` (the open session), `/background` (closing the terminal — daemon-backed, own worktree), and a Desktop scheduled task (a reboot). The cloud `/schedule` remains deliberately unused; all three of these are local.

## 1.3.0 — the board must tell the truth
- **Render time.** In-progress cards now show real elapsed time from `dispatched_at` — "running 4m", flipping to "⚠ no update for 2d — likely dead" past `stale_after_minutes` (board-level, default 30). Stuck cards join the "Needs you" rail; the header shows when `board.json` itself was last written. A dead card can no longer render as healthy activity.
- **Gate models consequence.** New per-card `risk`/`risk_why`/`risk_ack`: high-risk cards (secrets, network exposure, destructive/hard-to-reverse) ASK before firing, with the consequence phrased for a non-engineer. `risk_ack` may only be set after explicit human approval. Age-based ASK implemented (was documented in the skill but never coded).
- **Honest reasons.** done → "done", review → "finished — awaiting review" (previously both said "terminal/awaiting human", telling the human six finished cards needed them).
- **Pinned schema + lint.** `templates/SCHEMA.md` is the single arbiter of card fields (`description` ≠ `context`, both defined). The gate lints every card against it each tick — missing `activity`/`dispatched_at`/`description`, unknown fields — and `/triage` must repair lint before dispatching; `/status` surfaces it. Fields can no longer live only in prompt prose and silently stop existing.
- `/status` now runs the gate read-only for fresh verdicts instead of trusting stamped ones, and flags stuck cards in the terminal view too.
- Kanban server now sends `Last-Modified` so the freshness meta works.

## 1.2.0
- New command `/dispatch-board:kanban`: opens the live visualizer in the browser — copies `board.html` next to `board.json`, serves `.dispatch-board/` on localhost via a dependency-free Node static server (`scripts/serve-board.mjs`), reuses a running server, and hops ports if 8787 is taken. `DISPATCH_BOARD_PORT` / `DISPATCH_BOARD_NO_OPEN` env overrides.
- `/dispatch-board:status` now hints at the kanban view.
- Richer tickets: cards now carry `description` (what the ticket is), `model` (tier allotted), `activity` (what is happening right now), with `budget_tokens` surfaced as the ticket's size estimate. The visualizer renders all four; `/triage` keeps `activity`, `model`, and `spend_tokens` updated through the card's lifecycle.

## 1.1.2
- Fix `hooks/hooks.json` schema: events now live under the required top-level `hooks` key (they previously would not load); `${CLAUDE_PLUGIN_ROOT}` quoted.
- `/dispatch-board:init` no longer commits `.dispatch-board/` to the working branch — matches the side-ref design (gitignored, snapshotted to `refs/dispatch-board/state`).
- `/dispatch-board:triage` now stamps each card's latest `verdict`/`verdict_reason` so `/status` and the visualizer can render the ASK queue.
- Filled in author/homepage metadata; publish under `divi-vijayakumar/claude-dispatch-board`.

## 1.1.1
- Tagline: "Your AI eng manager for Claude Code — runs your plan on native loops, dispatches what's ready, and brings you the calls that need you."

## 1.1.0
- Renamed to **dispatch-board**; state dir is now `.dispatch-board/`, gate env var `DISPATCH_GATE_MODULE`.
- Ticket-lifecycle command: `/dispatch-board:triage` (was `tick`).
- **Side-ref state tracking:** board/plan history is snapshotted to a local git ref (`refs/dispatch-board/state`) instead of HEAD — retros stay intact, your working branch and PRs stay clean, nothing is pushed. Hard fallback: any hook failure logs and skips; it never touches HEAD, index, or working tree.
- `.dispatch-board/` is gitignored on the working branch by init.
- Self-contained kanban visualizer at `visualizers/board.html` (verdict-colored, worktree-aware, triage rail).

## 1.0.0

- Initial release.
- Consequence gate (`scripts/gate.mjs`): per-card FIRE / ASK / SILENT verdicts, pluggable via `DISPATCH_GATE_MODULE`.
- Commands: `/dispatch-board:init`, `:tick`, `:loop`, `:status`.
- Worker subagents: implementer, reviewer, researcher (tier-routed).
- Skills: dispatch-gate (the verdict contract), retro (plan-vs-actual from git history).
- Auto-commit hook for the append-only `.dispatch-board/` retro trail; session-start note.
- Native long-running via `/loop` + `/goal` (no cron, no external scheduler).
- Local-first: state never leaves the machine; the only egress is your chosen model provider.
