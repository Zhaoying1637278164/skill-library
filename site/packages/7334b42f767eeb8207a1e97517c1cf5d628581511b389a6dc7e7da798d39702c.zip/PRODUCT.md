# dispatch-board — Product

**Your AI eng manager for Claude Code. It runs your plan on native loops, dispatches what's ready, and brings you the calls that need you.**

This document is the product definition: what dispatch-board is, who it's for, the promises it makes, and how each piece of the plugin exists to keep one of those promises. The README covers installation and mechanics; this covers *why*.

---

## The problem

Letting an AI agent work unattended — overnight, or while you're in meetings — fails in two characteristic ways:

1. **It burns tokens on work that stopped being valid.** The plan moved, a dependency changed, a card went stale — and the agent kept going, because nothing re-asked whether the work still made sense.
2. **It makes calls that were yours to make.** Credentials get written, network exposure changes, a working system gets touched — silently, because nothing distinguished a consequential card from a trivial one.

And when you come back, a third failure hides the first two: **the board lies.** A card that died two days ago sits in In-Progress, colored green. A tool you can't trust while away is a tool you can't walk away from — which was its entire job.

## Who it's for

- **The engineer** who wants Claude Code to execute a multi-card plan without babysitting every step.
- **The non-technical PM** who opens the kanban, reads the columns, and *believes them*. They never open `gate.mjs`. Every promise below is written for the person who only sees the rendered board.

## What it is (and is not)

dispatch-board is **Claude-native**: no hosted control plane, no external orchestrator, no database service, no third-party board backend. The orchestrator *is* your Claude Code session; the board is a JSON file in your repo; the loop is Claude Code's native `/loop`; the workers are subagents. The optional kanban view runs as a temporary localhost process that displays state — Claude Code remains the only agent runtime and orchestrator.

It is **not** a standalone multi-agent platform with a web app (that's the Vibe-Kanban-style architecture — a separate brain that shells out to Claude). The board-with-columns part is a commodity. The product is the promises below.

---

## The four promises

### 1. Invalid work never burns tokens — the gate runs every cycle

Most agent boards are dispatch-and-run: fire a task, let it finish. dispatch-board re-evaluates **every card on every tick** and returns one of three verdicts:

- **FIRE** — valid, in scope, worth the tokens *right now*. Dispatch.
- **ASK** — uncertain or consequential. A human looks first. ASK cards accumulate into the escalation queue that greets you in the morning.
- **SILENT** — not ready (deps unmet), or invalidated by a plan change. Quietly drop back to backlog instead of burning tokens.

The cheapest token is the one you never spend on invalid work.

The shipped gate (`scripts/gate.mjs`) is a transparent heuristic — plan drift, staleness, budget, dependencies, blocked, risk — and it is **pluggable**: point `DISPATCH_GATE_MODULE` at your own module exporting `verdict(card, ctx)` and the harness uses your brain without changing anything else. The three-verdict contract is the interface; how you reach a verdict is yours.

### 2. Consequence escalates before it happens — the risk field

"Deps met and in budget" is not the same as "safe to run." Every card carries a `risk` field set at creation: **high** if it touches secrets or credentials, changes network exposure, is destructive or hard to reverse, or could break a currently-working system. High-risk cards **ASK before they fire**, regardless of deps and budget, and stay asked until a human explicitly acks (`risk_ack` — the dispatcher is forbidden from setting it itself).

Just as important is *how* it asks. An ASK is a question to a possibly non-technical human, so it must state the **product consequence and the decision needed**, never the implementation dilemma:

> ❌ "pin ca_file or default to tls_verify;0?"
> ✅ "the video feed would be encrypted but not authenticated — anyone on the LAN could impersonate the camera. OK for quick-start, or require the stronger setup?"

The gate escalates in language the person reading the standup can act on. That's what makes the ASK queue a blockers section instead of a second engineering inbox.

### 3. The board cannot lie — time outranks stamps

The invariant, enforced in code: **nothing renders that isn't derived from a field that exists, and live time always outranks stored claims.**

- Every in-progress card shows real elapsed time from `dispatched_at`: "▸ running 4m — writing tests." Past `stale_after_minutes` (default 30) it flips to "⚠ no update for 2d — likely dead" and **joins the Needs-you rail** — even if its last stamped verdict said everything was fine. A dead card can never render as healthy activity.
- An in-progress card with no timestamp at all is treated as unaccountable, not healthy: "cannot tell if alive" → ASK.
- Finished work says so: done cards say "done," review cards say "finished — awaiting review." No inverted trust signals.
- The header shows when `board.json` itself was last written, so you can tell whether the board is being maintained at all.
- The schema is pinned in one place (`templates/SCHEMA.md` — including the deliberate split between `description`, the human-facing line, and `context`, the agent-facing input) and the gate **lints every card against it on every tick**. Missing `activity`, missing `dispatched_at`, unknown fields — surfaced immediately, and the triage cycle must repair them before dispatching. A field that lives only in prompt prose does not exist; lint is what keeps prose and reality converged.

Known boundary, stated honestly: lint catches *absent* fields every tick, but a present-yet-outdated `activity` line is only bounded by the stale timer. The board can't lie; it can be wrong for at most `stale_after_minutes`.

### 4. Local-first, history-complete, zero churn

State never leaves your machine and never clutters your git history. `.dispatch-board/` is gitignored on your working branch; a PostToolUse hook snapshots its full timeline to a local ref (`refs/dispatch-board/state`) on every edit — never pushed, never touching HEAD, your index, or your working tree, and failing safe (any hook error logs and skips rather than blocking a tick). The only network egress is the model API call Claude Code already makes. No telemetry, no board sync, no third-party service.

That side-ref is not just hygiene — it's what makes **retros** possible: the retro skill reconstructs plan-vs-actual from the ref history (how the plan drifted, which cards the gate ASK'd or silenced and whether that was right in hindsight, where tokens were wasted) and turns it into tuning recommendations. `DECISIONS.md` doubles as the plain-English record of every judgment call — why a card was invalidated, who approved which risk — readable in a standup by someone who doesn't know what RTSPS is.

---

## The surface

| You do | It does |
|---|---|
| `/dispatch-board:init <problem>` | Writes a living `PLAN.md` (append-only, revisioned), seeds `board.json` with small cards — each with a human-facing description, a token size estimate, a model tier, and a risk assessment set at creation. |
| `/dispatch-board:triage` | One gated cycle: lint-repair → gate every card → dispatch FIRE cards to scoped subagents → collect results → append the ASK queue. One tick per invocation, by design. |
| `/dispatch-board:status` | Terminal standup: columns, spend vs budget, fresh gate verdicts (never trusts stamps), stuck-card flags, the ASK queue, lint findings. |
| `/dispatch-board:kanban` | The live board in your browser: verdict-colored cards, per-card description / model / size / activity, running-vs-stuck time, and the triage rail — everything that needs a human, in one place. Localhost only, dependency-free. |
| `/dispatch-board:loop 10m` | Overnight mode: native `/loop` re-ticks triage on an interval, `/goal` sets the stop condition ("stop when nothing is dispatchable without human input"). The loop decides *when* to tick; the gate decides *what* fires. |

Workers are three scoped subagents — **implementer** (writes, verifies its own card, proposes follow-up cards), **reviewer** (read-only pass/fail against the plan's success criteria), **researcher** (read-only briefings, noise kept out of the main thread) — each with its own context, model tier, and per-card token budget. Agents write back to the backlog blackboard-style: they *propose* cards; only the tick appends them, and only the gate fires them.

## The morning after (the intended experience)

You gave it a problem at 11pm. At 9am you open `/dispatch-board:status` and read:

- **What shipped** — done cards, each with its one-line outcome and actual spend vs estimate.
- **What's running** — with real ages, so "running 6m" and "stuck 4h" are different colors.
- **What needs you** — the ASK queue: a high-risk card waiting for your go-ahead, phrased as a consequence; a card the plan-drift check pulled back; a blocked card with the blocker named.

That queue *is* your standup. You answer the two or three calls that were genuinely yours, ack or redirect, and the board goes back to work.

## Design principles

1. **Claude-native or not at all.** Every mechanism is a primitive Claude Code already ships (subagents, hooks, `/loop`, plain files). The moment this needs its own hosted service or a second decision-making brain outside the session, it's a different product.
2. **The gate is the product; the board is the commodity.** Anything that draws columns competes on columns. This competes on the per-card, every-cycle FIRE/ASK/SILENT verdict.
3. **Write for the reader who believes the pixels.** Every rendered signal must be derivable from data that exists. Truthful-but-alarming beats confident-but-wrong, always.
4. **Escalate consequence, not uncertainty.** Humans in the loop are a scarce resource; spend them on decisions only humans can make, phrased so they can make them.
5. **Legible defaults, pluggable brains.** The shipped gate is deliberately simple and fully open; the contract (`verdict(card, ctx)`) is where smarter, private judgment plugs in.
6. **Append-only memory.** Plans are revised, never rewritten; decisions are logged, never deleted. The retro is a first-class artifact, not an afterthought.

## Version arc

- **1.0** — the core idea: consequence-gated dispatch (FIRE/ASK/SILENT), pluggable gate, scoped workers, native loop.
- **1.1** — zero-churn state: the side-ref retro trail; rename to dispatch-board.
- **1.2** — the human surface: one-command live kanban; tickets carry description, size, model, and a live activity line.
- **1.3** — *the board must tell the truth*: rendered time from real timestamps, stuck-card escalation, honest terminal reasons, the risk field (consequence modeled in the gate, asked in PM language), and the pinned, lint-enforced schema.

## License

MIT.
