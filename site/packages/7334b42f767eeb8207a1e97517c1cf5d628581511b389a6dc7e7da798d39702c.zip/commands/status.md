---
description: Render the board, per-card spend, and the current ASK queue.
---

Read `.dispatch-board/board.json` and `.dispatch-board/PLAN.md`, then run the gate read-only for FRESH verdicts (never trust stamped ones — they age):
`node ${CLAUDE_PLUGIN_ROOT}/scripts/gate.mjs .dispatch-board/board.json .dispatch-board/PLAN.md`

Print:

1. The board as columns: Backlog / Ready / In-Progress / Review / Done, one line per card (`id  title  agent/model  spend/budget`). For every in-progress card, show its age from `dispatched_at` ("running 4m"); if it exceeds `stale_after_minutes` (default 30), flag it "⚠ stuck <age> — likely dead" — a dead card shown as healthy is the worst lie this tool can tell.
2. Total token spend so far vs. total budget, and the current plan revision.
3. The ASK queue from the fresh gate output: every ASK card with its reason — this includes stuck cards and unacked high-risk cards.
4. Any `lint` findings from the gate, so schema drift is visible to the human too.

Read-only. Do not dispatch or modify state.

End with a one-line hint: `/dispatch-board:kanban` opens this board live in the browser.
