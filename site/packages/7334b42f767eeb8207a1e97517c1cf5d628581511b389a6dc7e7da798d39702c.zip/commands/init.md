---
description: Bootstrap the harness in this repo — create the running plan and an empty board from one problem statement.
argument-hint: "<problem statement>"
---

You are bootstrapping the dispatch-board harness for this project.

1. Read `${CLAUDE_PLUGIN_ROOT}/templates/PLAN.md`, `DECISIONS.md`, and `board.json`.
2. Create a `.dispatch-board/` directory in the project root, and add `.dispatch-board/` to the project's `.gitignore` if not already there — its history is snapshotted to a local ref (`refs/dispatch-board/state`) by the state hook, never to the working branch.
3. Write `.dispatch-board/PLAN.md` filled in from the user's problem: "$ARGUMENTS".
   - Include: goal, constraints, success criteria, and an initial implementation approach.
   - This is a LIVING document. Every later change to the plan is appended with a timestamp, never overwritten — that history is what makes retros possible.
4. Write `.dispatch-board/DECISIONS.md` (empty log with header).
5. Write `.dispatch-board/board.json` seeded with the first few cards decomposed from the plan. Every card uses the schema in the template (id, title, description, column, agent, model, context, deps, budget_tokens, activity, dispatched_at, plan_rev). New cards start in "backlog".
   - `description`: one or two sentences — what the ticket is and what done looks like.
   - `budget_tokens`: the ticket's size estimate. Size cards honestly (a 1–5 min task ≈ 50k–150k tokens).
   - `model`: the cheapest tier that can do the job (haiku for research/lookups, sonnet for implementation/review; reserve bigger tiers for genuinely hard cards).
   - `activity`: null until dispatched — the dispatcher keeps it updated with what is happening.
   - `risk` + `risk_why`: set at creation. `high` if the card touches secrets/credentials, changes network exposure, is destructive or hard to reverse, or could break a currently-working system. Write `risk_why` as the consequence in plain product language a non-engineer can act on ("generates credentials and writes them to a file — confirm .gitignore covers it before this runs"). High-risk cards are escalated by the gate BEFORE they fire.
   The full field contract is `${CLAUDE_PLUGIN_ROOT}/templates/SCHEMA.md` — the gate lints every card against it on every tick.
6. Do NOT commit `.dispatch-board/` to the working branch — the PostToolUse state hook snapshots it to `refs/dispatch-board/state` automatically.
7. Print the rendered board (run `/dispatch-board:status`).

Keep cards small (1–5 minutes of focused agent work each). Prefer more small cards over few large ones.
