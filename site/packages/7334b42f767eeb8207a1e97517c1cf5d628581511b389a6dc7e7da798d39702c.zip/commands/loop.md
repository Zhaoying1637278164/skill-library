---
description: Run the board on Claude Code's native loop — tick on an interval until the board is drained, leaving the ASK queue for the human. Local, no cron.
argument-hint: "[interval e.g. 10m]"
---

Drive the harness with Claude Code's native loop instead of an external scheduler.

Set the run's stop condition, then start the heartbeat:

```
/goal Every Ready card has been dispatched or moved to Backlog by the gate, In-Progress is empty, and the only cards left for a human are in the ASK queue. Stop when no card is dispatchable without human input.
/loop ${ARGUMENTS:-10m} /dispatch-board:triage
```

Notes for whoever runs this:
- `/loop` re-runs `/dispatch-board:triage` on the given interval **locally** and is cycle-aware — each tick can see what the last one did. It stops when you stop it (or when the `/goal` evaluator says the run is complete).
- Each tick still runs the gate, so ASK/SILENT cards are never dispatched — the loop just decides *when* to tick, the gate decides *what* fires.
- Watch the first two or three cycles before walking away; a misconfigured tick is cheap to catch early and expensive to discover at cycle 40.

## What `/loop` actually guarantees — read before running overnight

`/loop` is **session-scoped**, and its real limits matter for an unattended run:

- **Ticks fire only while Claude Code is running and idle.** Closing the terminal or letting the session exit stops them.
- **Recurring tasks expire 7 days after creation** — the task fires one final time, then deletes itself. Re-launch to go longer.
- **No catch-up for missed fires.** If a tick comes due while Claude is busy, it fires once when Claude next goes idle — not once per missed interval.
- **Jitter:** a recurring tick can fire up to 30 minutes after its scheduled time (up to half the interval when running more often than hourly).
- Starting a fresh conversation clears the loop; `claude --resume` / `--continue` restores it if it hasn't expired.

### Choosing an overnight substrate

| You need | Use | Survives |
|---|---|---|
| Polling while you're at the desk | `/loop 10m /dispatch-board:triage` | the open session only |
| A run that outlives the terminal | `/background` (alias `/bg`) — carries the `/loop` task into a background session with its own worktree, kept alive by the local supervisor daemon | closing the terminal |
| A run that outlives a reboot | a Desktop scheduled task (local, persists across restarts, 1-minute minimum) | machine restart |

All three run **on your machine**. The cloud `/schedule` is still deliberately not used — it would break the local-only guarantee.
