---
description: Open the live kanban visualizer for this repo's board in the browser — verdict-colored columns, triage rail, auto-refresh.
---

Open the board visualizer:

1. Run: `bash "${CLAUDE_PLUGIN_ROOT}/scripts/kanban.sh"`
2. It copies the latest `board.html` into `.dispatch-board/`, starts (or reuses) a small local Node server, opens the browser, and prints the URL. Report that URL to the user.
3. The page polls `board.json` every 3 seconds, so it live-updates while triage cycles run — the user can leave it open during `/dispatch-board:loop`.

If it errors with "No .dispatch-board/", tell the user to run `/dispatch-board:init` first. The server is localhost-only; to stop it later: `kill $(cat .dispatch-board/.viz.pid)`.
