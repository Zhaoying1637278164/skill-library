---
description: Run one dispatch cycle — re-evaluate every card through the gate, then dispatch what should fire.
---

You are the dispatcher. Run exactly ONE cycle:

1. Read `.dispatch-board/board.json` and `.dispatch-board/PLAN.md`. Note the current plan revision number.
2. Run the gate over the board:
   `node ${CLAUDE_PLUGIN_ROOT}/scripts/gate.mjs .dispatch-board/board.json .dispatch-board/PLAN.md`
   The gate returns, per card, a verdict — FIRE, ASK, or SILENT — plus a reason, and a `lint` list where a card violates the pinned schema (`${CLAUDE_PLUGIN_ROOT}/templates/SCHEMA.md`).
   (If the user has set `DISPATCH_GATE_MODULE` to a custom gate, the script uses it for verdicts; lint always runs.)
   **Repair every lint finding on the board THIS tick, before dispatching** — backfill `description`, `activity`, `dispatched_at`, `model`; rename or drop unknown fields. A field the board doesn't hold is a lie the kanban will tell the human.
3. Act on verdicts:
   - **FIRE**: dispatch the card. Spawn the subagent named in `card.agent` (implementer / reviewer / researcher) with ONLY the scoped context in `card.context` plus the relevant slice of the plan. Move the card to "in-progress", stamp `dispatched_at` and `plan_rev`. Respect `card.budget_tokens`; pick the cheapest model tier that can do the job and record it in `card.model`. Set `card.activity` to a short present-tense line of what is happening (e.g. "implementer writing rate-limiter middleware").
   - **ASK**: do NOT dispatch. Add the card + the gate's reason to an "ASK queue" you print at the end for the human. This is the overnight escalation path. Phrase every ASK as a product consequence + decision a non-engineer can act on (see "Writing ASK reasons" in SCHEMA.md), not an implementation dilemma. When the human explicitly approves a high-risk card, set `risk_ack: true` and log the approval in DECISIONS.md — never set it yourself.
   - **SILENT**: leave the card as-is. If the reason is "plan drifted — card invalid", move it to "backlog" and note why in DECISIONS.md.
4. Collect any completed subagent results, move those cards to "review", update their `activity` to a one-line outcome (e.g. "done — tests green, awaiting review") and add reported spend to `spend_tokens`. New cards they proposed land in "backlog" (assign `risk`/`risk_why` per SCHEMA.md as they land). **Refresh `dispatched_at` on any card whose state you just updated** — it means "last time anything actually happened", and it is what tells the human "running 4m" vs "stuck 2 days".
5. Stamp each card's latest gate result onto it (`verdict`, `verdict_reason`) so `/dispatch-board:status` and the visualizer can show the ASK queue, then save `board.json`. The state hook auto-commits it. If you changed the plan, append (never overwrite) to PLAN.md and bump the plan revision.
6. Print: the rendered board, the ASK queue, and cycle token spend.

Do NOT loop. One tick per invocation — the caller (you interactively, or the overnight runner) decides when to tick again.
