# v1.4 Implementation Plan — Phase 1: Clickable, truthful card detail

Derived from `docs/SPEC-1.4.md` (§19 Phase 1, §20 acceptance criteria, §22 adopted
recommendations). Local-only document; not published.

## Scope decision

**v1.4 ships spec Phase 1 only.** Phases map to releases: 1.4 = Phase 1 (drawer +
events + ASK), 1.5 = Phase 2 (review + execution actions), 1.6 = Phase 3A/3B (loop
control via Monitor + IDE handoff), 1.7 = Phase 4 (merge controls). Rationale: the
drawer needs real-world feedback before the control plane lands on it, and Phase 1
requires zero new platform dependencies (Monitors stay out until 1.6).

**Exit criterion (from spec):** a user can inspect and modify a not-yet-running card
and answer an ASK entirely from the board.

## Adopted spec recommendations (§22)

- Server applies **deterministic** card-input edits directly (event + projection);
  Claude is required only for judgment and runtime actions.
- No Channels dependency. No Monitor in this release.
- No dynamic self-paced loop changes.
- Nothing merges automatically.
- Disconnected board = local edits and notes only.

## Phase-1 honesty contract (no Monitor yet)

There is no automatic event delivery in 1.4. The delivery contract is:
**events are applied at the next triage tick** (or via `/dispatch-board:apply-event`).
Event states used in 1.4: `RECEIVED → APPLIED | REJECTED`. The UI shows
"recorded — applies next tick" and never an applied state before Claude acknowledges.
The connection indicator states are: `board server connected` / `disconnected`, and
`last tick <age>` — no claim about a live Claude session (that's 1.6 capability
detection; overpromising it now would violate the truth invariant).

## Deliberate deviations from the spec (Phase 1 simplifications)

1. **Lifecycle statuses:** keep the v1.3 five columns + verdict in 1.4. The full
   11-status enum (VERIFYING, READY_TO_MERGE, …) only becomes meaningful with
   evidence bundles and merge controls (Phases 2/4). The drawer shows
   column + verdict + blocked/risk, which is every state that exists today.
   Schema bumps to v2 (not the spec's v4); v3/v4 land with later phases.
2. **Evidence bundle:** Review tab in 1.4 is read-only over what v1.3 has
   (activity outcome, spend, verdict history, DECISIONS.md excerpts). The full
   bundle schema is Phase 2.
3. **`decision.answered` is two-step:** the answer is recorded instantly
   (deterministic), but its *application* (moving cards, `risk_ack`, plan edits)
   is judgment → Claude at next tick.

## Work breakdown

### M0 — Schema v2 + migration
- `board.json` gains `schema_version: 2`; cards gain `revision`, `input_revision`,
  `input_hash` (sha256 over execution-relevant fields: context, deps, budget,
  model, risk, test_commands), `decisions: []` (or board-level `decisions[]` keyed
  by card — decide at implementation; board-level preferred for cross-card asks).
- Decision object per spec §10: id, card_id, status, question, consequence,
  options (id/label/consequence), recommendation, custom_answer_allowed, blocks,
  scope_hash (= input_hash of the card at ask time), answered_by/answer/answered_at.
- Migration: pure function `migrate(board) -> boardV2`, run by gate.mjs, server,
  and prompts on load; idempotent; v1 boards upgrade in place on first write.
- SCHEMA.md v2: add new fields + event log section; gate lint updated (unknown-field
  list, decision shape checks).
- Tests: migration idempotence; hash stability (key order independence); lint.

### M1 — Board server (evolve `scripts/serve-board.mjs` → `scripts/board-server.mjs`)
- Keep: static serving, loopback-only bind, Last-Modified, `x-dispatch-board` marker.
- Add REST (JSON only, no shell, allowlisted event types):
  `GET /api/bootstrap|board|cards/:id|events?after=|runtime`,
  `GET /api/stream` (SSE: board-changed, event-appended),
  `PATCH /api/cards/:id/inputs` (expected_revision required → 409 with diff on
  mismatch; validates types/lengths; applies to board.json; appends event;
  bumps revision + input_hash; clears verdict + unacked approvals; fs watch).
  `POST /api/decisions/:id/answer` (records answer, appends event, state RECEIVED).
- Security (spec §16): random capability token per start printed to launcher →
  cookie exchange; Origin/Host validation; no CORS; body size caps; reject unknown
  fields; never render user text as HTML server-side.
- Single-writer rules: server is sole writer of `events.jsonl`; board.json writes
  (server for deterministic edits, Claude during ticks) guarded by
  `.dispatch-board/.lock` (create-excl with stale timeout) + card `revision`
  check. triage.md gets the lock protocol.
- kanban.sh: launches new server; `--api-off` env to fall back to static-only.
- Tests: API happy paths, 409 conflict, auth rejection, traversal (regression),
  lock contention, event append atomicity (concurrent PATCHes).

### M2 — Drawer UI (board.html)
- Whole card clickable → right-side drawer; deep link `#card=<id>`; ESC closes;
  keyboard navigable; refresh preserves selection.
- Tabs: **Overview** (outcome, why, status+verdict+reason, deps/downstream, revisions,
  agent/model), **Inputs** (read + edit mode), **Activity** (age line, activity,
  dispatched_at, spend bar), **Decisions** (open + resolved), **History** (from
  events.jsonl filtered by card).
- Footer: one state-derived primary action (Save inputs / Answer decision) +
  labeled secondary menu; destructive actions separated + confirm.
- All strings escaped (existing `esc()` everywhere); no innerHTML of raw user text
  inside attribute contexts without quoting audit.
- Tests: extend DOM-stub render harness — drawer opens by id, tab content, primary
  action derivation, deep-link restore, "no field renders that isn't in schema."

### M3 — Input editing flow
- Structured fields only (no raw JSON textarea): description, context, constraints→
  (Phase 1: context/description/deps/budget_tokens/model/risk/risk_why/priority).
- Save → PATCH with expected_revision; on 409 show yours/current/changed-fields +
  reload-and-reapply. On success show what was invalidated (verdict cleared,
  risk approval cleared) — *before* save via a preview note.
- Gate change: verdict entries carry `input_hash`; gate ignores/flags stamped
  verdicts whose hash ≠ current (belt for the server's suspenders).

### M4 — ASK as first-class decisions
- triage.md: for every ASK verdict, materialize/refresh a decision object
  (question, consequence in product language, options with consequences,
  recommendation + rationale, blocks list, scope_hash). Gate lint: ASK card
  without an open decision object = lint finding.
- Drawer Decisions tab + Needs-you rail items open the answer form:
  recommended option first, alternatives, custom answer (if allowed),
  "edit the card instead" escape hatch.
- Answer → recorded event → chip "recorded — applies next tick". Re-ask
  prevention: triage must not re-open a decision whose scope_hash matches an
  answered one.

### M5 — Command/prompt updates
- `triage.md` step 0: **drain events** — read events.jsonl entries after the last
  applied marker, apply each (inputs already applied by server → just acknowledge;
  decision answers → apply judgment: move cards, set risk_ack, log to
  DECISIONS.md), mark APPLIED/REJECTED with reason. Then the normal tick.
- New `commands/apply-event.md` (`/dispatch-board:apply-event <event-id|all>`) —
  fixed entry point, validates the event, applies exactly once (idempotency:
  applied-event ledger in runtime state).
- New `commands/decide.md` (`/dispatch-board:decide DEC-014 backfill-first`) —
  terminal parity with the drawer.
- `status.md`: show pending (unapplied) events count + oldest age.
- SessionStart note mentions pending events if any exist.

### M6 — Hardening, docs, release
- XSS pass (all new sinks), CSP `<meta>` on board.html, body-size and array caps.
- Full test run: gate suite, migration suite, server API suite, render suite,
  kanban.sh e2e (reuse/port-hop/traversal regressions).
- Docs: README (drawer + honest "applies next tick" wording, updated screenshots
  or ASCII), SCHEMA.md v2, CHANGELOG 1.4.0, PRODUCT.md surface table row.
- `claude plugin validate --strict`; bump plugin.json to 1.4.0; merge v1.4 → main;
  tag. Community catalog picks it up via CI pin bump + version bump.

## Sequencing & sizing

M0 → M1 → M2 → M3 → M4 → M5 → M6, roughly 4–5 working sessions:
S1 = M0+M1 (foundation, all server tests green), S2 = M2 (drawer render-tested),
S3 = M3+M4 (edit + decide loops), S4 = M5 + first end-to-end dogfood on a real
board, S5 = M6 polish + release. Dogfood gate before release: run a real
mini-project via the board only (no terminal card edits) — the exit criterion,
performed literally.

## Risks

1. **board.json write contention** (server PATCH vs Claude tick) — mitigated by
   lock file + per-card revision + server-side 409; test explicitly. Worst case:
   a lost tick write surfaces as a 409 to the user, never silent clobber.
2. **XSS via card text into drawer HTML** — single `esc()` chokepoint + audit +
   CSP meta. New attribute-context sinks are the danger; test with hostile strings.
3. **Prompt-drift** (triage forgetting to drain events) — same failure class 1.3
   fixed with lint: status and session-note surface pending-event count, so
   undrained events are visible, not silent.
4. **Scope creep toward Phase 2** — the Review tab will tempt evidence work;
   the deviation list above is the fence. Anything needing new evidence = 1.5.
5. **Schema churn** — v2 now, v3 (evidence) in 1.5, v4 (automation) in 1.6;
   migrations stay pure functions chained v1→v2→v3→v4 so any old board upgrades.

## Non-goals for 1.4 (from spec §4 + phasing)

Loop control from the board, Monitor transport, IDE handoff, evidence bundles,
diff viewer, merge controls, line comments, statuses beyond the current five
columns, secret storage of any kind.
