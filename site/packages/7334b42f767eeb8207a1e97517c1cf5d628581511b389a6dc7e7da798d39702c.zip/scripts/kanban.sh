#!/usr/bin/env bash
# Open the live kanban visualizer for this repo's board.
# Copies the latest board.html next to board.json, starts (or reuses) a tiny
# local Node server, and opens the browser. Localhost only, nothing leaves the machine.
#   DISPATCH_BOARD_PORT     override the starting port (default 8787)
#   DISPATCH_BOARD_NO_OPEN  set to 1 to print the URL instead of opening a browser
set -u
[ -d .dispatch-board ] || { echo "No .dispatch-board/ in this directory — run /dispatch-board:init first." >&2; exit 1; }
[ -f .dispatch-board/board.json ] || { echo "No board.json yet — run /dispatch-board:init first." >&2; exit 1; }

PLUGIN_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cp -f "$PLUGIN_ROOT/visualizers/board.html" .dispatch-board/board.html

PORT="${DISPATCH_BOARD_PORT:-8787}"
for _ in 1 2 3 4 5 6 7 8 9 10; do
  HDR="$(curl -sf -o /dev/null -w '%{header_json}' "http://localhost:$PORT/board.html" 2>/dev/null)" && {
    case "$HDR" in
      *x-dispatch-board*) break ;;                 # our server already running — reuse
      *) PORT=$((PORT + 1)); continue ;;           # port taken by something else — try next
    esac
  }
  # port free — start our server on it
  nohup node "$PLUGIN_ROOT/scripts/serve-board.mjs" .dispatch-board "$PORT" >/dev/null 2>&1 &
  echo $! > .dispatch-board/.viz.pid
  sleep 0.5
  break
done

URL="http://localhost:$PORT/board.html"
if [ "${DISPATCH_BOARD_NO_OPEN:-0}" != "1" ]; then
  case "$(uname)" in
    Darwin) open "$URL" ;;
    Linux) xdg-open "$URL" >/dev/null 2>&1 || true ;;
  esac
fi
echo "$URL"
exit 0
