#!/usr/bin/env bash
# Persist .dispatch-board/ history to a dedicated LOCAL ref (refs/dispatch-board/state).
# Retros stay fully intact; your working branch, PRs, and remote stay clean.
# Hard fallback: any failure logs and skips — it never blocks a tick and never
# writes to HEAD, your index, or your working tree.
set -u
REF="refs/dispatch-board/state"
skip() { [ -d .dispatch-board ] && echo "$(date -u +%FT%TZ) commit-state skipped: $1" >>".dispatch-board/.hook.log" 2>/dev/null; exit 0; }

[ -d .dispatch-board ] || exit 0
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || exit 0

GITDIR="$(git rev-parse --git-dir 2>/dev/null)" || skip "no git dir"
TMP_INDEX="$GITDIR/.dispatch-board-index"
rm -f "$TMP_INDEX"

# stage ONLY the board state into a throwaway index — real index/HEAD untouched.
# -f because .dispatch-board is gitignored on your working branch (see init).
GIT_INDEX_FILE="$TMP_INDEX" git add -f .dispatch-board >/dev/null 2>&1 || skip "add"
TREE="$(GIT_INDEX_FILE="$TMP_INDEX" git write-tree 2>/dev/null)" || skip "write-tree"
rm -f "$TMP_INDEX"
[ -n "$TREE" ] || skip "empty-tree"

PARENT="$(git rev-parse --verify --quiet "$REF" 2>/dev/null)"
if [ -n "$PARENT" ]; then
  # nothing changed since last snapshot → no empty commit
  [ "$TREE" = "$(git rev-parse --verify --quiet "$REF^{tree}" 2>/dev/null)" ] && exit 0
  COMMIT="$(git commit-tree "$TREE" -p "$PARENT" -m "dispatch-board: state @ $(date -u +%FT%TZ)" 2>/dev/null)" || skip "commit-tree"
else
  COMMIT="$(git commit-tree "$TREE" -m "dispatch-board: state @ $(date -u +%FT%TZ)" 2>/dev/null)" || skip "commit-tree"
fi
[ -n "$COMMIT" ] || skip "empty-commit"
git update-ref "$REF" "$COMMIT" 2>/dev/null || skip "update-ref"
exit 0
