#!/usr/bin/env node
// Default consequence gate. Reads a board + plan, prints per-card verdicts as JSON.
// Swap the brain without touching the harness: set DISPATCH_GATE_MODULE to an ES module
// exporting `verdict(card, ctx) -> { verdict, reason }`.
// Lint (schema conformance, templates/SCHEMA.md) always runs and is NOT replaceable —
// it is the harness keeping the board honest, independent of how verdicts are reached.
import { readFileSync } from "node:fs";

const [, , boardPath, planPath] = process.argv;
if (!boardPath || !planPath) {
  console.error("usage: gate.mjs <board.json> <PLAN.md>");
  process.exit(2);
}
const board = JSON.parse(readFileSync(boardPath, "utf8"));
const plan = readFileSync(planPath, "utf8");
const planRev = (plan.match(/plan_rev:\s*(\d+)/) || [])[1] * 1 || 0;
const budget = board.run_budget_tokens ?? Infinity;
const totalSpend = board.cards.reduce((s, c) => s + (c.spend_tokens || 0), 0);
const doneIds = new Set(board.cards.filter((c) => c.column === "done").map((c) => c.id));
const staleMs = (board.stale_after_minutes ?? 30) * 60000;
const ctx = { plan, planRev, board, totalSpend, budget, staleMs };

const age = (ms) =>
  ms < 90e3 ? Math.round(ms / 1e3) + "s"
  : ms < 5.4e6 ? Math.round(ms / 6e4) + "m"
  : ms < 1.728e8 ? Math.round(ms / 3.6e6) + "h"
  : Math.round(ms / 8.64e7) + "d";

function defaultVerdict(card, ctx) {
  const depsMet = (card.deps || []).every((d) => doneIds.has(d));
  if (card.column === "done") return { verdict: "SILENT", reason: "done" };
  if (card.column === "review") return { verdict: "SILENT", reason: "finished — awaiting review" };
  if (!depsMet) return { verdict: "SILENT", reason: "dependencies not in Done" };
  if (card.blocked) return { verdict: "ASK", reason: "card flagged blocked" };
  if (card.column === "in-progress" && card.plan_rev != null && card.plan_rev < ctx.planRev)
    return { verdict: "SILENT", reason: "plan drifted — card invalid, return to backlog" };
  if (card.column === "in-progress") {
    if (!card.dispatched_at)
      return { verdict: "ASK", reason: "in-progress with no dispatch timestamp — cannot tell if it is alive; stamp dispatched_at or return it to backlog" };
    const idle = Date.now() - Date.parse(card.dispatched_at);
    if (idle > ctx.staleMs)
      return { verdict: "ASK", reason: `no update for ${age(idle)} — likely dead; restart it or return it to backlog` };
  }
  if (card.risk === "high" && !card.risk_ack)
    return { verdict: "ASK", reason: `high-risk: ${card.risk_why || "unspecified — see card; confirm before this runs"}` };
  if ((card.spend_tokens || 0) > (card.budget_tokens || Infinity))
    return { verdict: "ASK", reason: "card over its token budget" };
  if (ctx.totalSpend + (card.budget_tokens || 0) > ctx.budget)
    return { verdict: "ASK", reason: "would exceed run budget" };
  return { verdict: "FIRE", reason: "ready, in scope, in budget" };
}

// --- lint: the pinned schema (templates/SCHEMA.md), enforced every tick ---
const KNOWN = new Set(["id","title","description","column","agent","model","context","deps",
  "budget_tokens","spend_tokens","activity","blocked","dispatched_at","plan_rev",
  "risk","risk_why","risk_ack","priority","branch","verdict","verdict_reason"]);
const COLUMNS = new Set(["backlog","ready","in-progress","review","done"]);
function lint(card) {
  const p = [];
  for (const f of ["id", "title", "column", "agent", "context"]) if (card[f] == null) p.push(`missing ${f}`);
  if (!card.description) p.push("missing description — the human-facing line; `context` is agent input, not a substitute");
  if (card.column != null && !COLUMNS.has(card.column)) p.push(`unknown column "${card.column}"`);
  if (card.column === "in-progress") {
    if (!card.dispatched_at) p.push("in-progress but no dispatched_at — age/staleness cannot be shown");
    if (!card.activity) p.push("in-progress but no activity — the board cannot say what is happening");
    if (!card.model) p.push("in-progress but no model recorded");
  }
  if (card.risk === "high" && !card.risk_why) p.push("risk=high but no risk_why — the human cannot act on it");
  for (const k of Object.keys(card)) if (!KNOWN.has(k)) p.push(`unknown field "${k}" — not in templates/SCHEMA.md`);
  return p;
}

let gate = defaultVerdict;
if (process.env.DISPATCH_GATE_MODULE) {
  const mod = await import(process.env.DISPATCH_GATE_MODULE);
  gate = mod.verdict;
}

const out = board.cards.map((c) => {
  const entry = { id: c.id, ...gate(c, ctx) };
  const problems = lint(c);
  if (problems.length) entry.lint = problems;
  return entry;
});
console.log(JSON.stringify(out, null, 2));
