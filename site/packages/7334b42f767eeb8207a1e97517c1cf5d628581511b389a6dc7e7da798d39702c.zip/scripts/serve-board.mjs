#!/usr/bin/env node
// Tiny static server for the kanban visualizer — serves .dispatch-board/ on localhost.
// No deps; node is already required by the gate. Usage: serve-board.mjs [dir] [port]
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize } from "node:path";

const dir = process.argv[2] || ".dispatch-board";
const port = Number(process.argv[3] || 8787);
const types = { ".html": "text/html; charset=utf-8", ".json": "application/json" };

createServer(async (req, res) => {
  const raw = decodeURIComponent((req.url || "/").split("?")[0]);
  const path = normalize(raw).replace(/^(\.\.[/\\]|[/\\])+/g, ""); // no escaping the dir
  const file = join(dir, path === "" || path === "." ? "board.html" : path);
  try {
    const [data, st] = await Promise.all([readFile(file), stat(file)]);
    res.writeHead(200, { "content-type": types[extname(file)] || "application/octet-stream", "cache-control": "no-store", "x-dispatch-board": "1", "last-modified": st.mtime.toUTCString() });
    res.end(data);
  } catch {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("not found");
  }
}).listen(port, "127.0.0.1", () => {
  console.log(`dispatch-board visualizer: http://localhost:${port}/board.html`);
});
