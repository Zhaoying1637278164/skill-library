#!/usr/bin/env bash
[ -f .dispatch-board/board.json ] && echo "dispatch-board active — board at .dispatch-board/board.json. Run /dispatch-board:status to view, /dispatch-board:triage to dispatch." || true
exit 0
