# Board schema — the single source of truth

Every consumer of `board.json` — the gate (`scripts/gate.mjs`), the visualizer
(`visualizers/board.html`), and the command prompts — reads THIS file's field set.
The gate lints every card against it on every tick; a field that exists only in
prompt prose does not exist. Add a field here first, then teach the consumers.

## Board-level

| Field | Type | Written by | Meaning |
|---|---|---|---|
| `project` | string | init | Display name. |
| `run_budget_tokens` | number | init | Total token budget for the run. |
| `stale_after_minutes` | number (default 30) | init | An in-progress card with no update for longer than this is presumed dead → gate ASKs, kanban flags it "stuck". |
| `cards` | array | init/triage | The tickets. |

## Card

| Field | Type | Written by | Read by | Meaning |
|---|---|---|---|---|
| `id` | string | init | all | Stable id (e.g. `C4`). |
| `title` | string | init | human | Short imperative title. |
| `description` | string | init | **human** | 1–2 sentences: what this ticket is, what done looks like. Human-facing — NOT the same as `context`. |
| `context` | string | init | **agent** | The scoped input handed to the subagent. Agent-facing — NOT the same as `description`. |
| `column` | enum | triage | all | `backlog` \| `ready` \| `in-progress` \| `review` \| `done`. |
| `agent` | string | init | triage | Worker: `implementer` \| `reviewer` \| `researcher` (or `human`). |
| `model` | string | triage | human | Tier actually allotted at dispatch (`haiku`/`sonnet`/…). |
| `deps` | string[] | init | gate | Card ids that must be Done first. |
| `budget_tokens` | number | init | gate, human | Ticket size estimate. |
| `spend_tokens` | number | triage | gate, human | Tokens spent so far. |
| `activity` | string\|null | **triage, every tick a card moves or reports** | **human** | Present-tense sentence: what is happening right now ("implementer writing rate-limiter middleware"), or the one-line outcome once finished. This is the PM's main signal — the gate lints in-progress cards that lack it. |
| `dispatched_at` | ISO string\|null | triage, **refreshed on every progress update** | gate, kanban | Last time anything actually happened. Drives "running 4m" vs "stuck 2d". |
| `plan_rev` | number\|null | triage | gate | Plan revision the card was dispatched under (drift detection). |
| `blocked` | bool | triage | gate | Hard external blocker → ASK. |
| `risk` | `"low"`\|`"high"` | **init, at creation** | gate | High = touches secrets/credentials, changes network exposure, destructive or hard to reverse, or could break a currently-working system. |
| `risk_why` | string | init | **human** | The consequence in plain product language a non-engineer can act on: "generates credentials and writes them to a file — confirm .gitignore covers it before this runs". Required when `risk` is high. |
| `risk_ack` | bool | triage (only after explicit human approval) | gate | Human confirmed this specific risk. Unacked high-risk cards ASK instead of firing, regardless of deps/budget. |
| `priority` | `"P0"`\|`"P1"`\|`"P2"` (optional) | init | human | Display priority. |
| `branch` | string (optional) | triage | human | Working branch, if any. |
| `verdict` | string | triage (from gate output) | status, kanban | Last gate verdict — what the rendered board colors mean. |
| `verdict_reason` | string | triage (from gate output) | **human** | Last gate reason, verbatim. |

## Writing ASK reasons

An ASK is a question to a possibly non-technical human. State the **product
consequence and the decision needed**, never the implementation dilemma.
Bad: "pin ca_file or default to tls_verify;0?" Good: "the video feed would be
encrypted but not authenticated — anyone on the LAN could impersonate the
camera. OK for quick-start, or require the stronger setup?"
