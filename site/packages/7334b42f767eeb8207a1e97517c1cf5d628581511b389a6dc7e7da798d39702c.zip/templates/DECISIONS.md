# Decisions & Retros

<!-- APPEND ONLY. Record why cards were invalidated/re-scoped, and paste retros here. -->
