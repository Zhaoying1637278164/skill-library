# Implementation Plan

plan_rev: 0

## Goal
<one paragraph: what "done" looks like>

## Constraints
- <hard constraints: stack, deadlines, what not to touch>

## Success criteria
- [ ] <verifiable check 1>
- [ ] <verifiable check 2>

## Approach
<current best approach — the how>

---
## Revision log
<!-- APPEND ONLY. Never rewrite above; log every change here with a timestamp and bump plan_rev. -->
- rev 0 — <date> — initial plan.
