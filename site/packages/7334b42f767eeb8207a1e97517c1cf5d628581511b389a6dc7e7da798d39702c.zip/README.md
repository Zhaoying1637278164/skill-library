# dispatch-board

**Your AI eng manager for Claude Code. It runs your plan on native loops, dispatches what's ready, and brings you the calls that need you.**

Claude-native. No hosted control plane, no external orchestrator, no database service. `dispatch-board` runs *inside* Claude Code — it doesn't wrap or drive Claude from the outside, it *is* Claude Code doing the orchestrating, using the loop, subagents, and hooks that already ship. (The optional kanban view runs as a temporary localhost process; it displays state and never orchestrates.)

Give it a problem. It writes a living plan and a git-tracked board, dispatches scoped subagents, and — the part nothing else does — re-evaluates every card on every cycle and decides: **FIRE** (do it), **ASK** (a human should look first), or **SILENT** (not ready, or the plan moved and this card is now invalid). It runs overnight on Claude Code's native `/loop`, tracks token spend, and every morning you get a standup: what shipped, what's running, what needs you.

## Why not just use a kanban board?

The board is the commodity part — plenty of tools draw columns. The idea here is the **gate**: a per-card consequence verdict that runs continuously, so an unattended run neither burns tokens on stale work nor silently drops decisions you needed to make. The **ASK queue is your standup's blockers section.**

## vs. external orchestrators (e.g. Vibe Kanban)

Different architecture, on purpose:

- **External orchestrators** are a separate app that treats Claude Code as one interchangeable subprocess it shells out to. The brain lives outside Claude, in its own server + UI + database.
- **dispatch-board** has no outside brain. The orchestrator *is* your Claude Code session; the board is a file in your repo; the loop is `/loop`. Nothing to run but Claude.

If you want a standalone multi-agent app with a web UI, use one of those. If you want the gate, native, with zero extra processes — this.

## Install

```
/plugin marketplace add divi-vijayakumar/claude-dispatch-board
/plugin install dispatch-board@dispatch-board
```

## Quickstart

```
/dispatch-board:init  Build an auth rate-limiter with Redis, ship with tests
/dispatch-board:triage     # one gated dispatch cycle
/dispatch-board:status   # board, spend, and the ASK queue (your standup)
/dispatch-board:kanban   # open the live kanban view in your browser
```

## How it works (all native Claude Code primitives)

| Piece | Mechanism |
|---|---|
| Workers | subagents in `agents/` (implementer / reviewer / researcher), each scoped, own context, own model tier |
| Board + plan | plain files in `.dispatch-board/` — `board.json`, append-only `PLAN.md`, `DECISIONS.md` |
| Agents write to backlog | blackboard pattern — subagents return proposed cards, the tick appends them |
| The dispatcher | `/dispatch-board:triage` runs the gate, dispatches only FIRE cards with scoped context |
| Retro trail | a PostToolUse hook snapshots `.dispatch-board/` to a local ref (`refs/dispatch-board/state`) on every edit — full history, **zero churn on your working branch**, nothing pushed |
| Live kanban view | `/dispatch-board:kanban` — self-contained `board.html` served on localhost by a tiny Node server, verdict-colored, polls every 3s |
| Long-running | native `/loop` re-ticks locally; `/goal` sets the stop condition — no cron |
| Cost control | per-card `budget_tokens`, model-tier routing, and the gate refusing invalid work |

## The gate is pluggable — bring your own brain

The shipped gate (`scripts/gate.mjs`) is a transparent heuristic: plan drift, age ("no update for 2d — likely dead" beats a green card lying to you), budget, dependencies, blocked — and a per-card `risk` field set at creation, so cards that touch secrets, change network exposure, or could break a working system **ASK the human before they fire**, with the consequence stated in plain product language. It also lints every card against the pinned schema (`templates/SCHEMA.md`) on every tick, so the board can only render fields that actually exist. Good enough to run a real board, fully open.

To swap in a smarter gate — consequence-weighted or learned — point an env var at your own module. It never has to live in this repo:

```
export DISPATCH_GATE_MODULE=/path/to/your/gate.mjs
# exports:  verdict(card, ctx) -> { verdict: "FIRE"|"ASK"|"SILENT", reason: string }
```

The harness depends only on the three-verdict contract, not on how you reach the verdict. See `skills/dispatch-gate/SKILL.md`.

## Long-running (native loop, local)

No cron, no wrapper:

```
/dispatch-board:loop 10m
```

Sets a `/goal` stop condition and runs `/loop 10m /dispatch-board:triage` — a local, cycle-aware heartbeat that ticks until nothing's left a human hasn't been asked about. Each tick still runs the gate, so ASK/SILENT cards never dispatch.

`/loop` is session-scoped: ticks fire only while Claude Code is running and idle, recurring tasks expire after 7 days, and there's no catch-up for fires missed while Claude was busy. To outlive the terminal, `/background` moves the loop into a daemon-backed session with its own worktree; to outlive a reboot, use a local Desktop scheduled task. All are local — the cloud `/schedule` is deliberately not used, as it would break the local-only guarantee. See `/dispatch-board:loop` for the full comparison.

## Running it in Antigravity

Antigravity is a VS Code fork, so install the Claude Code extension inside it and use the normal flow above — gate, subagents, `/loop`, `/goal` all work, because it's Claude Code hosted in Antigravity's window. It does **not** install into Antigravity's native (Gemini) agent, which has its own plugin format and won't read Claude Code slash commands. Run it from the Claude Code panel.

## Local-first

State never leaves your machine, and it never clutters your git history: `.dispatch-board/` is gitignored on your working branch, and its full timeline lives on a local ref (`refs/dispatch-board/state`) that is never pushed unless you opt in. `.dispatch-board/` lives in your repo; the gate is local Node; the loop and hooks are local. The only egress is your chosen model provider's API — the same call Claude Code already makes. No telemetry, no board sync, no third-party service.

## License

MIT. See `LICENSE`. Changes in `CHANGELOG.md`. Product definition — what this is, who it's for, and the promises it makes — in `PRODUCT.md`.
