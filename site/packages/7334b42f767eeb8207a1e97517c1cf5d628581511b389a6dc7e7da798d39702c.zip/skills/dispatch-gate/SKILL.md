---
name: dispatch-gate
description: The consequence-gated dispatch contract at the heart of the harness. Use this whenever you need to decide whether an in-flight or ready board card should be dispatched, escalated to the human, or left alone — i.e. on every tick, or whenever the plan changes and existing cards may have gone stale. Explains the FIRE/ASK/SILENT verdict model, the default heuristic gate, and how to swap in a custom gate (e.g. a consequence-weighted model) without changing the harness.
---

# Dispatch Gate

Most agent boards are **dispatch-and-run**: they fire a task and let it finish. This harness's one real idea is a gate that runs **every cycle** and asks, per card: given what's true right now, should this be acted on?

## The verdict model

The gate returns one of three verdicts per card, plus a human-readable reason:

- **FIRE** — dispatch (or keep running). The card is valid, in scope, and worth the tokens now.
- **ASK** — do not dispatch. Something is uncertain or consequential enough that a human should look first. ASK cards accumulate into the escalation queue the overnight run leaves for the morning.
- **SILENT** — leave it. Either it isn't ready (deps unmet), or it has been invalidated by a plan change and should quietly drop back to backlog rather than burn tokens.

The point of ASK/SILENT is cost and safety: **the cheapest token is the one you never spend on invalid work.**

## The default gate (shipped)

`scripts/gate.mjs` implements a transparent heuristic over signals any project has:

- **Plan drift** — was the card dispatched under an older plan revision than the current one? → SILENT (invalid, return to backlog).
- **Age** — in-progress with no update (`dispatched_at`) for longer than the board's `stale_after_minutes` (default 30)? → ASK "no update for 2d — likely dead". A dead card must never render as healthy.
- **Risk** — `risk: "high"` without a human `risk_ack`? → ASK with the card's `risk_why`, *before* it ever fires, regardless of deps and budget. This is the consequence part of the consequence gate: cards that touch secrets, change network exposure, or could break a working system escalate in plain product language a non-engineer can act on.
- **Budget** — has the card blown past `budget_tokens`, or would firing push total spend over the run budget? → ASK.
- **Dependencies** — are the card's `deps` all in Done? If not → SILENT (not ready).
- **Blocked** — flagged blocked → ASK.
- Terminal columns get distinct, honest reasons: done → "done"; review → "finished — awaiting review".
- Otherwise, ready + in-scope → **FIRE**.

This is deliberately simple and legible. It is good enough to run a real board, and it contains no proprietary logic.

## Lint — the schema is enforced, not suggested

Alongside verdicts, the gate emits a `lint` list per card that violates the pinned schema (`templates/SCHEMA.md`): missing `description`, in-progress without `activity`/`dispatched_at`/`model`, high-risk without `risk_why`, unknown fields. The triage tick must repair lint before dispatching. Lint always runs — a custom `DISPATCH_GATE_MODULE` replaces the verdict brain only. A field that lives only in prompt prose does not exist; lint is what keeps the rendered board telling the truth.

## Swapping in a custom gate

The gate is a pure function with a fixed contract, so you can replace the brain without touching the harness. Set `DISPATCH_GATE_MODULE` to the path of an ES module exporting:

```js
// verdict(card, ctx) -> { verdict: "FIRE" | "ASK" | "SILENT", reason: string }
export function verdict(card, ctx) { /* ... */ }
```

`ctx` gives you `{ plan, planRev, board, totalSpend, budget, staleMs }`. Return the same shape as the default. This is where a consequence-weighted or learned gate plugs in — it stays in your own private module and never needs to live in this repo. The harness only depends on the three-verdict contract, not on how you reach the verdict.
