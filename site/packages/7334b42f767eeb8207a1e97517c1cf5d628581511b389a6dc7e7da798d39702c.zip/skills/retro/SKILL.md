---
name: retro
description: Closes the learning loop the other agent boards skip. Use this after a run, a milestone, or an overnight session to produce a plan-vs-actual retro — what the plan said, what actually happened, where the gate fired/asked/silenced, and what to change. Trigger whenever the user asks for a retro, a post-mortem, "what happened overnight", or wants to tune the board or the gate thresholds.
---

# Retro

Because the plan and board are git-tracked and append-only, the full history is recoverable. This skill turns that history into a retro.

## Steps

1. Establish the window (since last retro tag, since a date, or the last overnight run).
2. Reconstruct plan-vs-actual:
   - `git log -p refs/dispatch-board/state -- .dispatch-board/PLAN.md` → how the plan changed and when (each bump is a revision).
   - `git log -p refs/dispatch-board/state -- .dispatch-board/board.json` → card lifecycles: when each was dispatched, to which agent, spend, and terminal column.
   - `.dispatch-board/DECISIONS.md` → why cards were invalidated or re-scoped.
3. Summarize, in prose:
   - **Delta**: where actual work diverged from the original plan, and why.
   - **Gate behavior**: which cards were ASK'd or SILENCED, and whether that was right in hindsight (false stops vs. saves).
   - **Cost**: spend by agent and by card size; where tokens were wasted.
   - **Tuning**: concrete changes — card sizing, budgets, agent/model assignment, and gate thresholds (or, if a custom gate is in use, what signal it missed).
4. Append the retro to `.dispatch-board/DECISIONS.md` and tag the ref state `retro-<date>` (the retro itself appends to DECISIONS.md, which the hook snapshots).

Keep it honest and specific. The value is the tuning recommendations, not a narrative.
