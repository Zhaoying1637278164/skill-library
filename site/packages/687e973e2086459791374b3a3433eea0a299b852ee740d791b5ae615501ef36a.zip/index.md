---
title: Home
nav_order: 0
permalink: /
---

> **Looking for the official Claude Code guide?** See [Anthropic's Claude Code documentation](https://docs.anthropic.com/en/docs/claude-code/overview).
> This is a community plugin to help you proactively master Claude Code.

# Claude Code Guide

A community guide to **Claude Code** — setup, best practices, automation, and effective workflows.

<p><em>Find this useful? Star the repo to follow updates and show support!</em>
<iframe src="https://ghbtns.com/github-btn.html?user=OriNachum&repo=claude-code-guide&type=star&count=true&size=large" frameborder="0" scrolling="0" width="170" height="30" title="Star on GitHub" style="vertical-align: middle;"></iframe></p>

**New!** Enable proactive learning with **Game Mode** — `/guide:game-mode on`

> **Plugin available** — Install this guide as a Claude Code plugin:
>
> ```shell
> /plugin marketplace add OriNachum/claude-code-guide
> /plugin install guide@claude-code-guide
> ```
>
> After installing, restart Claude Code or run `/reload-plugins` if the skills don't appear.
> Already installed? Update with `/plugin update guide@claude-code-guide`.

<img width="384" alt="Claude Code Guide overview" src="https://github.com/user-attachments/assets/5330f813-6539-4e15-bb94-0e1994edd94c" />

## What's Inside

- **[Getting Started](getting-started)** — Environment setup, first session, model selection, best practices, and auto memory
- **[Automation](automation)** — Hooks, skills, and sub agents — the three automation mechanisms
- **[Configuration & Extensions](configuration)** — CLAUDE.md, plugins, marketplace, MCP, and built-in tools
- **[Integrations](integrations)** — Claude Agent SDK, GitHub Actions, and other integration methods
- **[User Stories](user-stories)** — Narrative walkthroughs of real-world scenarios

## About This Guide

This is a community-maintained resource. It is **not** an official Anthropic product.

The guide is packaged as a Claude Code plugin with seven skills:

- **`/guide:onboard`** — Interactive getting-started walkthrough
- **`/guide:ask`** — Ask any question about Claude Code features
- **`/guide:introspect`** — Audit lifecycle coverage, find gaps, and improve your development environment
- **`/guide:game-mode`** — Gamified usage tracker with levels
- **`/guide:level-up`** — Feature roadmap and personalized coaching
- **`/guide:migrate-to-claude`** — Migrate configs from other AI coding assistants
- **`/guide:visualize-setup`** — Interactive dashboard of skills, MCP servers, and setup

<img width="600" alt="Plugin in action" src="https://github.com/user-attachments/assets/3643154f-00e9-4793-886e-e49adfee54ef" />

> **Listen to this guide** — [NotebookLM audio overview](https://notebooklm.google.com/notebook/61c00692-3e07-4cac-887a-3360520d8f94) provides an AI-generated audio reflection of the guide content.
>
> **Featured on** — [AI Tool Review](https://aitoolreview.ai/guides/) lists this guide among its curated Claude Code resources.

*⭐ Find this useful? Star the repo to follow updates and show support!* <a href="https://github.com/OriNachum/claude-code-guide/stargazers"><img src="https://img.shields.io/github/stars/OriNachum/claude-code-guide?style=social" alt="GitHub stars"></a>

## License

This project is licensed under [CC BY 4.0](https://github.com/OriNachum/claude-code-guide/blob/main/LICENSE).

The license covers the **original contributions** in this repository — including user stories, site styling, organizational structure, analogies, and the way knowledge is framed and presented. It does **not** cover the underlying Claude Code product or its official documentation, which remain the property of Anthropic, PBC. This project does not claim ownership over Anthropic's features, APIs, or documentation.

Any party that incorporates original content from this repository — whether text, structure, or presentation — must provide attribution as required by CC BY 4.0.
