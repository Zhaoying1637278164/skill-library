# sabotage — design

**Date:** 2026-08-22
**Status:** approved, pre-implementation
**Scope:** v1

## Thesis

Generation got 10x cheaper. Verification did not. The most-cited developer
frustration with AI coding is code that is "almost right, but not quite"
(66% of Stack Overflow's 2025 respondents), with 45% reporting that
debugging AI-generated code takes longer than writing it themselves.

Agents make this worse in a specific, measurable way: they write tests that
execute lines without asserting behavior. Line coverage rises while real
verification falls, so the one metric teams rely on has become actively
misleading.

Mutation testing is the only measure immune to this, because it asks the
only question that matters: *if the code were wrong, would anything notice?*
It has existed since the 1970s and never achieved adoption for three
reasons — it is brutally slow, its output is thousands of unreadable
surviving mutants, and it tells you a test is missing without telling you
what to write. All three are human-labor problems that an agent dissolves.

`sabotage` breaks your code on purpose and reports which tests failed to
notice, then writes the test that catches it and proves that it does.

## Non-goals (v1)

- Any language other than JavaScript/TypeScript.
- Wrapping or handing off to StrykerJS (`--deep` mode).
- A CI / PR-gate hook. This is v1.1 and is cheap once the engine works.
- Any hosted service, dashboard, score history, or account.
- Monorepo-aware target selection beyond "it works if the test command works."
- Exhaustive mutation. We optimize for signal, not completeness.

## Approach

**Chosen: agent-driven surgical mutator.** The plugin adds no dependency to
the user's project. It selects a small set of semantically meaningful
sabotages, applies them one at a time to source, runs the project's existing
test command, records the result, and reverts.

Three reasons this beats wrapping an existing engine:

1. **Zero install.** Works on any repo that has a working test command. For a
   marketplace plugin whose pitch is "run one command," this is the single
   largest adoption lever. It is a hard constraint, not a preference.
2. **Signal over exhaustiveness.** A traditional engine emits thousands of
   mutants of which the large majority are noise. An agent choosing ~20
   plausible-bug mutations produces output a human acts on immediately.
3. **It reads as a bug report, not a metric.** "I made `isAdmin()` return true
   unconditionally and all 847 tests still passed" lands where "mutation
   score: 61%" does not.

It also dissolves the equivalent-mutant problem, because the agent only
proposes mutations that represent a real behavior change.

**Rejected: wrap StrykerJS.** Requires installing `@stryker-mutator/core` plus
a runner plugin into the user's project and authoring a config file. Slow and
noisy. Faster to a first demo, but inherits precisely the three properties
that prevented mutation testing from ever catching on.

**Rejected for v1: hybrid.** Ship the custom mutator with an optional
`--deep` handoff to Stryker when already installed. Correct eventually; YAGNI
now. Two engines to maintain and a split story.

**Accepted cost.** Mutation selection is model judgment, so a run is not
exhaustive and not identical run-to-run. Mitigated by recording every
mutation to a replayable manifest: any given run is reproducible and
re-verifiable even though the next run may choose differently.

## Architecture

A run has five phases.

### 1. Preflight

- Detect the test command from `package.json` scripts, or from a vitest/jest
  config file.
- Detect the runner (vitest / jest / node:test / unknown).
- Run the full suite once to establish a baseline.
- **The baseline must be green.** If it is red, abort with the count of
  already-failing tests and an explanation: otherwise every sabotage appears
  to survive and every downstream result is meaningless.
- Record baseline wall-clock duration; this sets the mutation budget.
- Collect line coverage as JSON from the runner.

### 2. Target selection

Rank candidates and take the top N. See "Target selection" below.

### 3. Sabotage loop

For each mutation:

1. Apply the edit to the source file.
2. Run the **scoped** test command.
3. Record `killed` (suite went red) or `survived` (suite stayed green).
4. Revert, always, in a `finally`, verified by hash.

**Scoping is where the speed comes from.** Both major runners select tests by
dependency, so only tests that transitively import the mutated module run
(verified against current docs, 2026-08-22):

- Jest: `jest --findRelatedTests <file> --json`
- Vitest: `vitest related <file> --run --reporter=json`

`--run` is mandatory for Vitest; without it the process enters watch mode and
hangs the run. Unknown runners fall back to the full suite.

**Kill detection must not rely on the exit code.** A suite that runs zero
tests also exits non-zero, and reading that as "killed" would report false
confidence — precisely the failure this tool exists to catch. So we parse the
runner's JSON output and apply:

- `testsRun > 0 && testsFailed > 0`  -> **killed**
- `testsRun > 0 && testsFailed == 0` -> **survived**
- `testsRun == 0`                    -> **scoping miss**: retry once against the
  full suite; if still zero, drop the mutant and log it. Never counted either way.

Do **not** pass `--passWithNoTests`; we need the zero-test case to stay
distinguishable.

**Budget.** `N = clamp(120s / scoped_suite_duration, 8, 30)`, targeting a
default run of roughly two minutes. `audit` raises the ceiling to 600s.

### 4. Report

See "Output" below.

### 5. Fix

Offered after the report, not run automatically. See "The fix loop" below.

## Source safety

This tool deliberately writes bugs into a working tree. If it ever leaves
`isAdmin()` returning `true` on disk, the project is finished. Safety is
therefore a correctness requirement, not a nicety.

- Require a clean git working tree. `--allow-dirty` requires explicit opt-in
  and prints what it is risking.
- Record original file bytes to an on-disk journal at `.sabotage/journal.json`
  **before** any edit.
- Restore by exact byte replacement. **Never `git checkout`**, which would
  destroy unrelated work in a dirty tree.
- Verify restoration by SHA-256 before proceeding to the next mutant. A
  mismatch is a hard error that stops the run.
- Trap `SIGINT` and `SIGTERM` and restore before exit, so Ctrl-C mid-run is
  always safe.
- Ship `/sabotage restore`, which replays the journal if the process is
  hard-killed.
- Add `.sabotage/` to the user's `.gitignore` on first run.

## Target selection

We hunt **inside the covered region**. Mutating uncovered code teaches
nothing — it is obviously untested. The finding that matters is code with
high coverage and no real assertions, which is the fake-test thesis exactly.

Rank by:

- **Consequence.** Auth and permission checks, money, deletion, validation,
  limits and expiry. Name heuristics (`isAdmin`, `canEdit`, `hasAccess`,
  `discount`, `refund`, `charge`, `delete`, `purge`, `validate`, `sanitize`,
  `quota`, `expiry`) plus the agent reading the file.
- **Has coverage.** Uncovered lines are filtered out entirely.
- **Decision density.** Branches, comparisons, boolean logic. Pure
  pass-through functions are not meaningfully mutable.
- **Recency.** Recently-changed files score higher; AI-written code is recent
  code.

This produces the headline finding nearly for free: *this file is at 100%
coverage, nine sabotages survived, one was caught.*

## Mutation catalog

**Tier 1 — mechanical.** Deterministic, reliable, reproducible; the backbone
of every run.

- Boundary flips: `<` <-> `<=`, `>` <-> `>=` (the classic off-by-one).
- Negation: insert/remove `!`; `===` <-> `!==`.
- Unconditional `true` / `false` returned from a predicate.
- Stripped fallbacks: `?? default` -> `?? undefined`; remove `|| default`.
- Swapped arithmetic: `+` <-> `-`, `*` <-> `/`.
- Emptied returns: `null`, `[]`, `0`, `""`.
- Swallowed errors: replace `throw` with a no-op.
- Disabled guard clauses: force an early-return guard never to fire.
- Off-by-one on indices and slices.

**Tier 2 — semantic.** Agent-chosen, and the differentiator. The agent reads
the function and asks what bug a tired human or a confident AI would
plausibly write here: checking the wrong user's id, applying the discount
before tax rather than after, returning the unfiltered list, comparing
against the wrong bound.

Each run is mostly Tier 1 with a handful of Tier 2. Tier 1 gives
reproducibility; Tier 2 gives the findings people remember.

## Equivalent-mutant guard

Some mutations genuinely do not change behavior. False positives here would
destroy trust quickly.

**Rule: every reported survivor must be accompanied by a concrete input that
produces demonstrably wrong output.** If the agent cannot name one, the
mutant is dropped as equivalent.

This single requirement filters the primary noise source and simultaneously
improves the report — the reader gets `applyDiscount(100, 0.2)` returns `100`,
expected `80` rather than "mutant survived at line 42."

## The fix loop

The core failure mode is an over-fit test: the agent sees the mutant and
writes `expect(discount(100)).not.toBe(0)`, which kills the mutant and is
worthless. The defense is ordering — **the agent never sees the mutation.**

### Phase 1 — translate the mutant into a behavioral gap

The finding is restated as a missing verification, not as a diff. Not "we
flipped `<` to `<=` on line 12" but "nothing in the suite verifies behavior at
the `maxRetries` boundary." Derived from the mutant; the exact edit never
enters context.

### Phase 2 — state the contract, then write the test

From the clean function, its call sites, its types and its neighbours, the
agent writes the behavior contract in plain English first, then writes the
test against that contract. Conventions (framework, assertion style,
fixtures, naming) are read from an adjacent test file.

### Phase 3 — the triple gate

All three are machine-verified:

1. **Passes on clean code.**
2. **Fails on the mutant** — proves it closes the gap.
3. **Kills at least one sibling mutation it was not written for.** We generate
   2-3 further mutations of the same function and require the new test to
   catch at least one. A test written to the real contract naturally catches
   related breakage; an anti-mutant assertion catches only its own mutant.
   This is the anti-overfit check and it is nearly free, since the engine
   already exists.

### Phase 4 — style gate

Run the repo's linter. Reject the fingerprints of fake tests: a sole
`toBeDefined()` assertion, `.not.toBe(<mutant value>)`, `expect(true)`,
snapshot-only assertions. It would be absurd for this tool to emit the thing
it detects.

### Phase 5 — present, never silently commit

Show the diff and accept in batch. Re-running must not duplicate tests:
check for an equivalent existing test by target and name before adding.

### Failure handling

**If a test cannot clear all three gates after one retry, no test is
shipped.** The finding is reported as an honest gap — the contract plus the
breaking input — and left for a human. An admitted gap costs nothing; a bad
test costs the entire thesis.

## Surface

Three commands.

| Command | Behavior |
|---|---|
| `/sabotage` | Default run. Scoped to the diff against the default branch; falls back to `HEAD~1`, then to risk-ranked hot spots if neither yields changed source files. ~2 minutes. |
| `/sabotage audit` | Full sweep. Produces the headline number. Longer. |
| `/sabotage restore` | Replays the journal after a hard kill. |

Fixing is not a separate command. The run reports, then offers.

## Output

```
sabotage — 14 mutations, 9 survived

src/auth/permissions.ts          (100% line coverage)
  ✗ isAdmin() returns true for every user — 847 tests still passed
      breaks on:  isAdmin({ role: 'guest' })  →  true
  ✗ canEdit() ignores ownerId entirely — 847 tests still passed
      breaks on:  canEdit(userB, postOwnedByA)  →  true

src/billing/discount.ts          (94% line coverage)
  ✗ applyDiscount() ignores the rate — 847 tests still passed
      breaks on:  applyDiscount(100, 0.2)  →  100, expected 80
  ✓ caught — negative rate still throws

9 of 14 sabotages went unnoticed. Your suite is at 91% line coverage.
```

Four rules:

1. Lead with the **consequence**, never the mutation operator.
2. Always print coverage beside the filename. The juxtaposition *is* the
   product.
3. Always print the concrete breaking input. This doubles as the
   equivalent-mutant guard.
4. Always show at least one caught line when one exists, so the report reads
   as fair rather than as doom.

## Packaging

```
.claude-plugin/plugin.json     manifest
commands/                      three slash commands
skills/                        agent judgment: mutation selection,
                               contract writing, anti-fake-test style rules
scripts/                       deterministic engine: runner detection,
                               coverage parsing, journal, apply/revert,
                               hash verification, signal traps
```

Implemented in Node, with **zero runtime dependencies**. No MCP server, no
backend, no signup, and nothing installed into the user's project. This
constraint is a competitive advantage and is therefore a hard rule.

**Name:** `sabotage`. Free in the community marketplace, a verb, self-describing,
and carrying no expiry date the way "slop" and "vibe" do.

## Testing strategy

A fixture family is the acceptance suite:

- A project with genuinely good tests (expect most mutants killed).
- A project at 100% coverage with entirely fake tests (expect most survived).
- A project whose suite is already red (expect a clean abort).
- A project with no git (expect degraded-but-safe operation).
- A project with a dirty tree (expect refusal without `--allow-dirty`).

Safety properties get real tests, not assertions of intent:

- `kill -9` mid-run leaves a journal that `restore` fully replays.
- `SIGINT` leaves a clean tree.
- A hash mismatch on restore is a hard error that halts the run.

**Meta-test:** sabotage runs against its own test suite, and every survivor
gets fixed. This is a genuine quality ratchet and the best line in the README.

## Risks

- **Model-selected mutations vary run-to-run.** Mitigated by the replayable
  manifest; accepted as the cost of signal over exhaustiveness.
- **Slow suites.** Scoped runs and the mutant budget bound this, but a repo
  whose scoped suite takes minutes will have a poor first experience. Detect
  and warn during preflight.
- **Generated tests that pass all gates and are still mediocre.** The triple
  gate raises the floor; it does not guarantee excellence. Phase 5 keeps a
  human in the loop.
- **Runner diversity.** Flags are verified for Jest and Vitest. `node:test`,
  Bun, and custom harnesses fall back to the full suite, which is correct but
  slow. Detect the runner in preflight and warn when falling back.
