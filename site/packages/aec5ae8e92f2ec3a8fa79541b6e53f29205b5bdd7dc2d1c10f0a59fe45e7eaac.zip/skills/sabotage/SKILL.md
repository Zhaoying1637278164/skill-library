---
name: sabotage
description: Use when running mutation testing to prove a test suite actually catches bugs, or when asked to check for fake tests, verify test quality, or find tests that pass even when the code is broken.
allowed-tools: Bash(node ${CLAUDE_PLUGIN_ROOT}/scripts/sabotage.js *), Bash(node ${CLAUDE_PLUGIN_ROOT}/scripts/restore.js)
---

# sabotage

You break the code on purpose and report which tests failed to notice.

## Scope and budget

When invoked directly (as `/sabotage:sabotage`, or auto-triggered) with no
scope given, default to the diff against recent changes:

1. Scope: the diff against the default branch; fall back to `HEAD~1`; fall
   back to risk-ranked hot spots if neither yields changed source files.
2. Budget: 120000ms (the default).

`/sabotage:sabotage-audit` overrides both of these for a full-suite sweep:
every covered file ranked by consequence, with `SABOTAGE_BUDGET_MS=600000`.

Working tree: sabotage refuses to run against uncommitted changes to tracked
files, since that work has no other copy if a restore ever fails. If it
refuses, relay the message verbatim and let the user decide whether to
re-run with `--allow-dirty`. Never add that flag yourself.

## Phase 1 — find targets

Get the ranked targets first:

```
node ${CLAUDE_PLUGIN_ROOT}/scripts/sabotage.js targets
```

This prints `budget`, `targets` (ranked, highest consequence first) and
`coveragePercent`. Mutate only files that appear in `targets`, and write **at
most `budget` mutations** into the manifest — that is how many this suite can
afford inside the time budget. `SABOTAGE_BUDGET_MS` raises it;
`/sabotage:sabotage-audit` sets it to 600000.

**If `targets` exits 2, coverage is unavailable — this is normal.** It happens
for every `node:test` repo (including sabotage's own), and for any project
missing a coverage provider. Do not stop, and do not try to install anything.
Fall back:

1. Read the message. If it names a missing provider, say so in your final
   report as a one-line suggestion; do not install it yourself.
2. Choose targets by reading the source instead: the consequence heuristic
   still applies — auth and permissions, money, deletion, validation, limits
   and expiry — plus files with real branching. Prefer files that have a
   neighbouring test file, since code with no test at all is uninteresting:
   the finding that matters is covered code with no real assertions.
3. There is no coverage ranking and no `budget` in this mode. Use 8 to 12
   mutations, and say in your report that coverage was unavailable so the
   `(N% line coverage)` column is missing.

For each target, write mutations into a manifest:

```json
{ "mutations": [{
  "file": "/abs/path/src/auth/permissions.js",
  "find": "u.id === p.ownerId",
  "replace": "true",
  "symbol": "canEdit",
  "consequence": "canEdit() ignores ownerId entirely",
  "breaksOn": "canEdit(userB, postOwnedByA)  →  true"
}]}
```

`find` MUST appear exactly once in the file — the engine rejects ambiguous
matches. Include the surrounding context needed to make it unique.

**Tier 1 — mechanical.** Boundary flips (`<`/`<=`, `>`/`>=`), negation
(`!`, `===`/`!==`), unconditional `true`/`false` from predicates, stripped
`?? default` and `|| default` fallbacks, swapped arithmetic, emptied returns
(`null`, `[]`, `0`, `""`), `throw` replaced by a no-op, guard clauses forced
never to fire, off-by-one on indices and slices.

**Tier 2 — semantic.** Read the function and ask what bug a tired human or a
confident AI would plausibly write: checking the wrong user's id, applying the
discount before tax rather than after, returning the unfiltered list.

Most of a run is Tier 1. Two or three Tier 2 mutations produce the findings
people remember.

## Phase 2 — run the sabotage

Write the manifest to a file and run it:

```
node ${CLAUDE_PLUGIN_ROOT}/scripts/sabotage.js <mutations.json>
```

**Before anything else runs, sabotage checks the working tree.** If it refuses
because tracked files have uncommitted changes, relay the message
verbatim — including the files it names — and stop there. **Never pass
`--allow-dirty` on the user's behalf.** That flag exists so a human can
knowingly accept the risk that, if a restore ever fails, their uncommitted
work has no other copy anywhere; an agent that adds it silently defeats the
entire point of the check. Report the refusal and let the user decide whether
to re-run with `--allow-dirty` themselves.

This is where preflight happens. It refuses to run against a red or empty
suite; if it refuses, relay the message verbatim and stop. A red baseline makes
every result meaningless, because every mutation "survives" trivially.

It prints the human report and writes machine-readable results to
`.sabotage/last-run.json`.

**Always surface the skipped count.** A skipped mutation was never scored, so
it says nothing either way. Report it explicitly — "12 of 14 mutations were
skipped, so this run verified almost nothing" — and never let a run with
findings imply that the skipped ones were fine. If `findings` is empty, the run
measured NOTHING: report that, and never as a clean result.

If the run exits **70**, a file was left sabotaged. Relay the message verbatim
and run `node ${CLAUDE_PLUGIN_ROOT}/scripts/restore.js` before anything else.

## Phase 3 — the equivalent-mutant rule

**Every survivor you report MUST carry a concrete input that produces
demonstrably wrong output.** If you cannot name one, the mutation does not
change behavior — drop it. This is not optional; false positives destroy trust
faster than missed findings.

Write `applyDiscount(100, 0.2)` returns `100`, expected `80` — never
"mutant survived at line 42".

## Phase 4 — writing the killing test

**You must never see the mutation while writing the test.** Restate the
survivor as a missing verification — "nothing in the suite verifies behavior at
the `maxRetries` boundary" — then work only from the clean function.

1. Read the clean function, its call sites, its types and its neighbours.
2. State the behavior contract in plain English.
3. Read an adjacent test file for conventions: framework, assertion style,
   fixtures, naming.
4. Write the test against the contract, not against the mutation.

Then run the triple gate. Write the spec to a file and run:

```json
{
  "testFile": "/abs/path/src/auth/permissions.test.js",
  "mutation": { "file": "...", "find": "...", "replace": "..." },
  "siblings": [
    { "file": "...", "find": "...", "replace": "..." },
    { "file": "...", "find": "...", "replace": "..." }
  ]
}
```

```
node ${CLAUDE_PLUGIN_ROOT}/scripts/sabotage.js gate <gate.json>
```

`testFile` is **required** and must be the file holding the new test. Every
gate run is scoped to it, so only the new test can pass or fail. Without that
scoping any pre-existing failing test in the repo supplies the "kill" and an
over-fit assertion sails through gate 3.

**A sibling is 2–3 FURTHER mutations of the same function** — a different
boundary, a different branch, a different emptied return in the very code the
new test claims to cover. Not another function, not another file. A sibling
from elsewhere makes gate 3 arbitrary: passing it proves nothing and failing it
tells you nothing. Check `skippedSiblings` in the verdict: if every sibling was
skipped, gate 3 never actually ran — fix the siblings and re-run, do not treat
it as a rejection.

All three must pass: the test passes on clean code, fails on the mutant, and
kills a sibling it was not written for.

Exit codes:

- **0** all three gates passed.
- **1** the gate ran and the test was rejected — rewrite it against the
  contract, not against the mutation.
- **2** the gate spec itself was bad: a stale `find` that no longer matches, a
  missing `testFile`, or a scoped run that executed 0 tests (wrong path, or the
  runner does not collect that file). Regenerate the spec; do not touch the
  test.
- **3** `baselineRed` — the project's own suite is already failing on clean
  source. **Do not rewrite the test.** Report the red suite and stop; until it
  is green no gate result means anything.
- **4** the working tree had uncommitted changes to tracked files and
  `--allow-dirty` was not passed. Relay the message verbatim, including the
  files it names, and let the user decide — never add `--allow-dirty`
  yourself.
- **70** a file may still be sabotaged. Run
  `node ${CLAUDE_PLUGIN_ROOT}/scripts/restore.js` immediately, then relay the
  message verbatim.

## Phase 5 — style

Reject your own test if it contains a sole `toBeDefined()` assertion,
`.not.toBe(<the mutant value>)`, `expect(true)`, or a snapshot as its only
assertion. These are the fingerprints of the fake tests you are hunting.

## Failure handling

**If a test cannot clear all three gates after one retry, ship no test.**
Report the honest gap — the contract plus the breaking input — and leave it for
a human. An admitted gap costs nothing. A bad test costs the whole thesis.

## Never

- Never commit or write into test files without showing the diff first.
- Never leave a mutation on disk. If a run is interrupted, run
  `node ${CLAUDE_PLUGIN_ROOT}/scripts/restore.js` immediately.
- Never report a mutation score as the headline. Lead with the consequence.
