import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { openJournal } from '../scripts/lib/journal.js'
import { tripleGate, GateSpecError } from '../scripts/lib/verify-test.js'
import { detectRunner, fullCommand, testCommandFor } from '../scripts/lib/runner.js'
import { run } from '../scripts/lib/exec.js'

const here = dirname(fileURLToPath(import.meta.url))
const cli = join(here, '..', 'scripts', 'sabotage.js')
const SRC = 'export const isAdmin = (u) => u.role === "admin"\n'

function scratch () {
  const dir = mkdtempSync(join(tmpdir(), 'sab-'))
  const file = join(dir, 'a.js')
  writeFileSync(file, SRC)
  return { dir, file }
}

const json = (run, failed) => ({ stdout: JSON.stringify({ numTotalTests: run, numFailedTests: failed }) })
const green = async () => json(5, 0)

// Scripts the SCOPED runner by call order: clean, mutant, sibling.
const scripted = (...verdicts) => {
  let i = 0
  return async () => {
    const v = verdicts[Math.min(i++, verdicts.length - 1)]
    return v === 'pass' ? json(5, 0) : v === 'fail' ? json(5, 1) : json(0, 0)
  }
}

const setup = () => {
  const { dir, file } = scratch()
  return {
    det: { runner: 'vitest' },
    journal: openJournal(dir),
    testFile: join(dir, 'a.test.js'),
    mutation: { file, find: 'u.role === "admin"', replace: 'true' },
    siblings: [{ file, find: '"admin"', replace: '"ADMIN"' }],
    runFull: green
  }
}

test('a good test passes all three gates', async () => {
  const r = await tripleGate({ ...setup(), runTests: scripted('pass', 'fail', 'fail') })
  assert.deepEqual(
    { passesClean: r.passesClean, failsMutant: r.failsMutant, killsSibling: r.killsSibling, ok: r.ok },
    { passesClean: true, failsMutant: true, killsSibling: true, ok: true }
  )
})

test('a test that fails on clean code is rejected', async () => {
  const r = await tripleGate({ ...setup(), runTests: scripted('fail', 'fail', 'fail') })
  assert.equal(r.passesClean, false)
  assert.equal(r.ok, false)
})

test('a test that does not fail on the mutant is rejected', async () => {
  const r = await tripleGate({ ...setup(), runTests: scripted('pass', 'pass', 'fail') })
  assert.equal(r.failsMutant, false)
  assert.equal(r.ok, false)
})

test('an over-fit test that kills only its own mutant is rejected', async () => {
  const r = await tripleGate({ ...setup(), runTests: scripted('pass', 'fail', 'pass') })
  assert.equal(r.killsSibling, false)
  assert.equal(r.ok, false)
})

test('gates never leave a mutation on disk', async () => {
  const s = setup()
  await tripleGate({ ...s, runTests: scripted('pass', 'fail', 'fail') })
  assert.equal(readFileSync(s.mutation.file, 'utf8'), SRC)
})

test('an empty sibling list fails gate 3 rather than vacuously passing it', async () => {
  const r = await tripleGate({ ...setup(), siblings: [], runTests: scripted('pass', 'fail', 'fail') })
  assert.equal(r.killsSibling, false)
  assert.equal(r.ok, false)
})

test('a sibling that cannot be applied is skipped, never crashes the gate, and leaves no mutation on disk', async () => {
  const s = setup()
  const badSibling = { file: s.mutation.file, find: 'NOPE_NOT_PRESENT_IN_SOURCE', replace: 'x' }
  const r = await tripleGate({ ...s, siblings: [badSibling], runTests: scripted('pass', 'fail', 'fail') })
  assert.equal(r.killsSibling, false)
  assert.equal(r.ok, false)
  assert.equal(readFileSync(s.mutation.file, 'utf8'), SRC)
})

test('a skipped sibling is reported with its reason, so "all malformed" is not read as "not killed"', async () => {
  const s = setup()
  const badSibling = { file: s.mutation.file, find: 'NOPE_NOT_PRESENT_IN_SOURCE', replace: 'x' }
  const r = await tripleGate({ ...s, siblings: [badSibling], runTests: scripted('pass', 'fail', 'fail') })
  assert.equal(r.skippedSiblings.length, 1)
  assert.deepEqual(r.skippedSiblings[0].sibling, badSibling)
  assert.match(r.skippedSiblings[0].reason, /not present/)
})

test('a sibling that ran and simply did not fail is NOT listed as skipped', async () => {
  const r = await tripleGate({ ...setup(), runTests: scripted('pass', 'fail', 'pass') })
  assert.deepEqual(r.skippedSiblings, [])
  assert.equal(r.killsSibling, false)
})

test('the sibling loop stops at the first sibling killed, never mutating the rest', async () => {
  const { dir, file } = scratch()
  let siblingCalls = 0
  const runTests = async () => {
    // 1st call: clean (survives). 2nd: mutant (killed). 3rd+: any sibling run -> killed.
    if (siblingCalls === 0) { siblingCalls++; return json(5, 0) }
    if (siblingCalls === 1) { siblingCalls++; return json(5, 1) }
    siblingCalls++
    return json(5, 1)
  }
  const r = await tripleGate({
    det: { runner: 'vitest' },
    journal: openJournal(dir),
    testFile: join(dir, 'a.test.js'),
    mutation: { file, find: 'u.role === "admin"', replace: 'true' },
    siblings: [
      { file, find: '"admin"', replace: '"ADMIN"' },
      { file, find: 'isAdmin', replace: 'isAdminX' }
    ],
    runTests,
    runFull: green
  })
  assert.equal(r.killsSibling, true)
  assert.equal(r.ok, true)
  // clean + mutant + exactly ONE sibling run = 3 calls total, never a 4th for the second sibling.
  assert.equal(siblingCalls, 3)
})

// ---------------------------------------------------------------- attribution

test('every gate run is handed the test file, never left to the full suite', async () => {
  const s = setup()
  const seen = []
  await tripleGate({
    ...s,
    runTests: async (testFile) => { seen.push(testFile); return json(5, seen.length === 1 ? 0 : 1) }
  })
  assert.equal(seen.length, 3, 'clean, mutant, sibling')
  assert.ok(seen.every(f => f === s.testFile), `every run must be scoped to ${s.testFile}, got ${seen}`)
})

test('a gate spec with no testFile throws rather than silently running the full suite', async () => {
  const s = setup()
  delete s.testFile
  await assert.rejects(
    () => tripleGate({ ...s, runTests: scripted('pass', 'fail', 'fail') }),
    (err) => err instanceof GateSpecError && /testFile/.test(err.message)
  )
})

test('a scoped run that executes zero tests is an error, never a rejection', async () => {
  // testsRun === 0 means nothing was measured. Reporting that as passesClean:false
  // would tell the agent to rewrite a test that was never actually run.
  await assert.rejects(
    () => tripleGate({ ...setup(), runTests: scripted('none') }),
    (err) => err instanceof GateSpecError && /0 tests/.test(err.message)
  )
})

test('an already-red suite is reported as baselineRed, not as a rejected test', async () => {
  const r = await tripleGate({
    ...setup(),
    runFull: async () => json(9, 3),
    runTests: scripted('pass', 'fail', 'fail')
  })
  assert.equal(r.baselineRed, true)
  assert.equal(r.ok, false)
  assert.equal(r.passesClean, false, 'no gate ran, so nothing may be claimed about the test')
})

test('a red baseline never applies a mutation, even though gate 1 runs first to attribute a bad test correctly', async () => {
  // Gate 1 runs BEFORE gate 0 (that is the fix this suite guards), so the
  // scoped runner IS invoked once here — for the clean check that tells a
  // broken new test apart from a red baseline. What must never happen is a
  // mutation gate (2 or 3) running once gate 0 finds the baseline red: those
  // are the only calls that touch disk, so the invariant that matters is
  // "at most the one clean-check call, and no mutation ever applied".
  const s = setup()
  let scopedRuns = 0
  await tripleGate({
    ...s,
    runFull: async () => json(9, 3),
    runTests: async () => { scopedRuns++; return json(5, 0) }
  })
  assert.equal(scopedRuns, 1, 'exactly gate 1\'s clean check — gate 0 short-circuits before any mutation gate runs')
  assert.equal(readFileSync(s.mutation.file, 'utf8'), SRC)
})

// ------------------------------------------------- end-to-end, a real runner
//
// The C1 regression. `gate-scoped` holds an over-fit test next to a
// pre-existing genuine test that IS sensitive to the sibling mutation. A gate
// that measures the whole suite therefore sees a failure and waves the over-fit
// test through; a gate scoped to the test file under judgement does not.

const gx = join(here, 'fixtures', 'gate-scoped')
const gxSrc = join(gx, 'src', 'permissions.js')
const gateSpec = {
  testFile: join(gx, 'src', 'overfit.test.js'),
  mutation: { file: gxSrc, find: "user.role === 'admin'", replace: 'true' },
  siblings: [{ file: gxSrc, find: "'admin'", replace: "'ADMIN'" }]
}

test('C1: the over-fit test is rejected because gate 3 is scoped to the new test file', async () => {
  const spec = join(mkdtempSync(join(tmpdir(), 'sab-g-')), 'g.json')
  writeFileSync(spec, JSON.stringify(gateSpec))
  const proc = spawnSync(process.execPath, [cli, 'gate', spec], { cwd: gx, encoding: 'utf8' })

  const verdict = JSON.parse(proc.stdout)
  assert.equal(verdict.baselineRed, false)
  assert.equal(verdict.passesClean, true)
  assert.equal(verdict.failsMutant, true)
  assert.equal(verdict.killsSibling, false, 'the over-fit test does not catch the sibling')
  assert.equal(verdict.ok, false)
  assert.equal(proc.status, 1, 'the gate ran and rejected the test')
  assert.equal(readFileSync(gxSrc, 'utf8'), 'export const isAdmin = (user) => user.role === \'admin\'\n')
})

test('C1: a whole-suite gate WOULD have been fooled — which is why it is scoped', async () => {
  // Identical fixture and identical over-fit test, with runTests deliberately
  // ignoring testFile and running the whole suite: the pre-C1 behaviour.
  const det = detectRunner(gx)
  const whole = () => run(['node', '--test', gateSpec.testFile, join(gx, 'src', 'existing.test.js')], gx)
  const r = await tripleGate({
    det,
    journal: openJournal(mkdtempSync(join(tmpdir(), 'sab-j-'))),
    ...gateSpec,
    runTests: whole,
    runFull: whole
  })
  assert.equal(r.killsSibling, true, 'the PRE-EXISTING test supplies the kill, not the new one')
  assert.equal(r.ok, true, 'this is the bug: an over-fit test passes the anti-overfit gate')
  assert.equal(readFileSync(gxSrc, 'utf8'), 'export const isAdmin = (user) => user.role === \'admin\'\n')
})

test('the node runner scopes to the file itself, and full/scoped really differ', () => {
  const det = detectRunner(gx)
  assert.equal(det.runner, 'node')
  assert.deepEqual(testCommandFor(det, gateSpec.testFile), ['node', '--test', gateSpec.testFile])
  assert.deepEqual(fullCommand(det), ['npm', 'test'])
})

// ------------------------------------------------------------------- the CLI

test('the gate CLI reports a malformed primary mutation instead of crashing', () => {
  const spec = join(mkdtempSync(join(tmpdir(), 'sab-g-')), 'g.json')
  writeFileSync(spec, JSON.stringify({
    testFile: gateSpec.testFile,
    mutation: { file: gxSrc, find: 'NOT_PRESENT_AT_ALL', replace: 'x' },
    siblings: []
  }))
  const proc = spawnSync(process.execPath, [cli, 'gate', spec], { cwd: gx, encoding: 'utf8' })

  assert.equal(proc.status, 2, 'bad input must exit 2, not 1 and not a crash')
  assert.match(proc.stderr, /cannot run the gate/)
  assert.ok(!/\bat \w+ \(/.test(proc.stderr), 'must not emit a raw stack trace')
  assert.equal(readFileSync(gxSrc, 'utf8'), 'export const isAdmin = (user) => user.role === \'admin\'\n')
})

test('the gate CLI refuses a spec with no testFile, naming what is missing', () => {
  const { dir } = scratch()
  const spec = join(dir, 'g.json')
  writeFileSync(spec, JSON.stringify({ mutation: { file: gxSrc, find: 'x', replace: 'y' }, siblings: [] }))
  const proc = spawnSync(process.execPath, [cli, 'gate', spec], { cwd: gx, encoding: 'utf8' })

  assert.equal(proc.status, 2)
  assert.match(proc.stderr, /testFile/)
})

test('the gate CLI reports a red baseline with its own exit code, not "rewrite the test"', () => {
  // A scratch project whose own suite fails on clean source.
  const dir = mkdtempSync(join(tmpdir(), 'sab-red-'))
  writeFileSync(join(dir, 'package.json'), JSON.stringify({
    name: 'fx-red-gate', type: 'module', scripts: { test: 'node --test *.test.js' }
  }))
  writeFileSync(join(dir, 'src.js'), 'export const isAdmin = (u) => u.role === "admin"\n')
  writeFileSync(join(dir, 'broken.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "test('already failing', () => { assert.equal(1, 2) })\n")
  writeFileSync(join(dir, 'new.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "import { isAdmin } from './src.js'\n" +
    "test('isAdmin is true only for admins', () => { assert.equal(isAdmin({ role: 'admin' }), true) })\n")
  const spec = join(dir, 'g.json')
  writeFileSync(spec, JSON.stringify({
    testFile: join(dir, 'new.test.js'),
    mutation: { file: join(dir, 'src.js'), find: 'u.role === "admin"', replace: 'true' },
    siblings: [{ file: join(dir, 'src.js'), find: '"admin"', replace: '"ADMIN"' }]
  }))

  const proc = spawnSync(process.execPath, [cli, 'gate', spec], { cwd: dir, encoding: 'utf8' })
  assert.equal(proc.status, 3, 'a red repo is not a rejected test')
  assert.equal(JSON.parse(proc.stdout).baselineRed, true)
  assert.match(proc.stderr, /already red/)
})

// ------------------------------------------------------- gate 1 before gate 0
//
// The defect this pair guards: gate 0 used to run first, over the WHOLE suite
// — which includes the freshly-written test itself. So a simply-wrong new
// test (the single most common failure here, and exactly what gate 1 exists
// to catch) made the whole-suite run fail, got misreported as
// `baselineRed: true`, and exited 3 — steering the agent to "fix the failing
// suite" instead of rewriting its own bad test. Gate 1 must run first: it is
// already scoped to `testFile`, so a bad new test is attributed correctly.

test('a broken new test on an otherwise-green project exits 1, never 3 — it is a rejected test, not a red baseline', () => {
  const dir = mkdtempSync(join(tmpdir(), 'sab-brokennew-'))
  writeFileSync(join(dir, 'package.json'), JSON.stringify({
    name: 'fx-broken-new', type: 'module', scripts: { test: 'node --test *.test.js' }
  }))
  writeFileSync(join(dir, 'src.js'), 'export const isAdmin = (u) => u.role === "admin"\n')
  // A genuine, PASSING, unrelated test already in the suite — the rest of the
  // project really is green.
  writeFileSync(join(dir, 'existing.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "import { isAdmin } from './src.js'\n" +
    "test('isAdmin is true for an admin', () => { assert.equal(isAdmin({ role: 'admin' }), true) })\n")
  // The new test is simply wrong: it asserts the opposite of what the source
  // actually does, so it fails on clean, unmutated source.
  writeFileSync(join(dir, 'new.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "import { isAdmin } from './src.js'\n" +
    "test('isAdmin is wrongly asserted false for an admin', () => { assert.equal(isAdmin({ role: 'admin' }), false) })\n")
  const spec = join(dir, 'g.json')
  writeFileSync(spec, JSON.stringify({
    testFile: join(dir, 'new.test.js'),
    mutation: { file: join(dir, 'src.js'), find: 'u.role === "admin"', replace: 'true' },
    siblings: [{ file: join(dir, 'src.js'), find: '"admin"', replace: '"ADMIN"' }]
  }))

  const proc = spawnSync(process.execPath, [cli, 'gate', spec], { cwd: dir, encoding: 'utf8' })
  const verdict = JSON.parse(proc.stdout)
  assert.equal(verdict.passesClean, false, 'gate 1 must catch the broken test itself')
  assert.equal(verdict.baselineRed, false, 'the whole suite failing BECAUSE of the new test is not a red baseline')
  assert.equal(verdict.ok, false)
  assert.equal(proc.status, 1, 'the gate ran and rejected the test — exit 1, not exit 3')
  assert.doesNotMatch(proc.stderr, /already red/, 'must not steer the agent to "fix the failing suite" instead')
  assert.equal(readFileSync(join(dir, 'src.js'), 'utf8'), 'export const isAdmin = (u) => u.role === "admin"\n',
    'gate 1 rejecting the test must never reach a mutation gate')
})

test('a genuinely red pre-existing suite still exits 3 even though the new test itself is valid — the case gate 0 exists for', () => {
  const dir = mkdtempSync(join(tmpdir(), 'sab-genuinered-'))
  writeFileSync(join(dir, 'package.json'), JSON.stringify({
    name: 'fx-genuine-red', type: 'module', scripts: { test: 'node --test *.test.js' }
  }))
  writeFileSync(join(dir, 'src.js'), 'export const isAdmin = (u) => u.role === "admin"\n')
  // An UNRELATED pre-existing test that is simply broken, with nothing to do
  // with isAdmin or the new test below.
  writeFileSync(join(dir, 'unrelated.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "test('unrelated invariant that is already broken', () => { assert.equal(2 + 2, 5) })\n")
  // The new test is entirely valid: it passes clean, and would fail its mutant.
  writeFileSync(join(dir, 'new.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "import { isAdmin } from './src.js'\n" +
    "test('isAdmin is true only for admins', () => { assert.equal(isAdmin({ role: 'admin' }), true) })\n")
  const spec = join(dir, 'g.json')
  writeFileSync(spec, JSON.stringify({
    testFile: join(dir, 'new.test.js'),
    mutation: { file: join(dir, 'src.js'), find: 'u.role === "admin"', replace: 'true' },
    siblings: [{ file: join(dir, 'src.js'), find: '"admin"', replace: '"ADMIN"' }]
  }))

  const proc = spawnSync(process.execPath, [cli, 'gate', spec], { cwd: dir, encoding: 'utf8' })
  const verdict = JSON.parse(proc.stdout)
  assert.equal(verdict.baselineRed, true, 'gate 1 passing does not excuse a genuinely red wider suite')
  assert.equal(verdict.ok, false)
  assert.equal(proc.status, 3, 'still the baseline-red exit code, not a rejected test')
  assert.match(proc.stderr, /already red/)
  assert.equal(readFileSync(join(dir, 'src.js'), 'utf8'), 'export const isAdmin = (u) => u.role === "admin"\n',
    'a red baseline must never let a mutation gate touch disk')
})
