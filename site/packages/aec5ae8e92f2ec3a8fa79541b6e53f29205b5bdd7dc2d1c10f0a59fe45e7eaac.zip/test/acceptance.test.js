import { test } from 'node:test'
import assert from 'node:assert/strict'
import { writeFileSync, readFileSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { run } from '../scripts/lib/exec.js'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const fx = (n) => join(root, 'test', 'fixtures', n)
const cli = join(root, 'scripts', 'sabotage.js')

const FIND = "user.role === 'admin'"

// Read at MODULE LOAD, before any test in this file has run the CLI against the
// fixture. Reading it inside the last test would compare the fixture against
// whatever an earlier test left behind, so a run that failed to restore would
// pass vacuously. The assertion below makes the snapshot non-vacuous: if it is
// already mutated at load time, this file fails loudly instead of enshrining it.
const pristine = new Map(
  ['fake-tests', 'good-tests', 'red-suite'].map(
    (n) => [n, readFileSync(join(fx(n), 'src', 'permissions.js'))]
  )
)
for (const [name, bytes] of pristine) {
  assert.ok(bytes.includes(FIND), `fixture ${name} is not pristine at module load: ${FIND} is missing`)
}

function manifestFor (dir, mutations) {
  const file = join(dir, 'src', 'permissions.js')
  const path = join(mkdtempSync(join(tmpdir(), 'sab-m-')), 'm.json')
  writeFileSync(path, JSON.stringify({ mutations: mutations ?? [{
    file, find: FIND, replace: 'true',
    symbol: 'isAdmin', consequence: 'isAdmin() returns true for every user',
    breaksOn: "isAdmin({ role: 'guest' })  →  true"
  }] }))
  return path
}

const lastRun = (dir) => JSON.parse(readFileSync(join(dir, '.sabotage', 'last-run.json'), 'utf8'))

test('fake tests let the sabotage survive', async () => {
  const dir = fx('fake-tests')
  await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(lastRun(dir).findings[0].status, 'survived')
})

test('good tests kill the sabotage', async () => {
  const dir = fx('good-tests')
  await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(lastRun(dir).findings[0].status, 'killed')
})

test('the human report leads with the consequence', async () => {
  const dir = fx('fake-tests')
  const { stdout } = await run(['node', cli, manifestFor(dir)], dir)
  assert.match(stdout, /isAdmin\(\) returns true for every user/)
})

test('a red suite aborts before mutating anything', async () => {
  const dir = fx('red-suite')
  const { stderr, code } = await run(['node', cli, manifestFor(dir)], dir)
  assert.notEqual(code, 0)
  assert.match(stderr, /already failing/)
})

test('C4: a run where every mutation was skipped never reports a clean bill of health', async () => {
  const dir = fx('good-tests')
  const file = join(dir, 'src', 'permissions.js')
  // Both mutations are unapplicable, so nothing is scored and nothing is measured.
  const manifest = manifestFor(dir, [
    { file, find: 'NOT_PRESENT_ANYWHERE', replace: 'x', consequence: 'never applied' },
    { file, find: 'ALSO_NOT_PRESENT', replace: 'y', consequence: 'never applied either' }
  ])
  const { stdout } = await run(['node', cli, manifest], dir)

  assert.ok(!/caught by your suite/i.test(stdout), stdout)
  assert.match(stdout, /NOTHING WAS VERIFIED/)
  assert.match(stdout, /0 mutations scored, 2 skipped/)
  assert.equal(lastRun(dir).findings.length, 0)
  assert.equal(lastRun(dir).skipped.length, 2)
})

test('the fixture source is left byte-identical after every run', () => {
  for (const [name, before] of pristine) {
    assert.deepEqual(readFileSync(join(fx(name), 'src', 'permissions.js')), before, `fixture ${name} was not restored`)
  }
})
