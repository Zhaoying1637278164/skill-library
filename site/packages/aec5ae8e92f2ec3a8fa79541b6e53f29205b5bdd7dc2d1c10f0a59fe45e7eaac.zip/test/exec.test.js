import { test } from 'node:test'
import assert from 'node:assert/strict'
import { run } from '../scripts/lib/exec.js'

test('a binary that cannot launch resolves instead of crashing', async () => {
  const result = await run(['definitely-not-a-real-binary-xyz', '--help'], process.cwd())
  assert.equal(result.code, 127)
  assert.match(result.stderr, /ENOENT|not found|spawn/i)
})

test('the spawned command never inherits our own node:test context', async () => {
  // A node:test child that sees NODE_TEST_CONTEXT reports over an internal V8
  // side channel and writes NOTHING to stdout, which downstream reads as
  // "0 tests ran" — a scoping miss on every mutation.
  const before = process.env.NODE_TEST_CONTEXT
  process.env.NODE_TEST_CONTEXT = 'child-v8'
  try {
    const result = await run(['node', '-e', 'console.log(String(process.env.NODE_TEST_CONTEXT))'], process.cwd())
    assert.equal(result.stdout.trim(), 'undefined')
  } finally {
    if (before === undefined) delete process.env.NODE_TEST_CONTEXT
    else process.env.NODE_TEST_CONTEXT = before
  }
})

test('the rest of the environment is passed through untouched', async () => {
  process.env.SABOTAGE_EXEC_PROBE = 'kept'
  try {
    const result = await run(['node', '-e', 'console.log(String(process.env.SABOTAGE_EXEC_PROBE))'], process.cwd())
    assert.equal(result.stdout.trim(), 'kept')
  } finally {
    delete process.env.SABOTAGE_EXEC_PROBE
  }
})
