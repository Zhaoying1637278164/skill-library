import { test } from 'node:test'
import assert from 'node:assert/strict'
import { rankTargets, CONSEQUENCE_PATTERNS } from '../scripts/lib/targets.js'

const coverage = new Map([
  ['/repo/src/auth/permissions.js', new Set([1, 2, 3])],
  ['/repo/src/utils/format.js', new Set([1, 2, 3])],
  ['/repo/src/billing/discount.js', new Set([1, 2])],
  ['/repo/src/dead.js', new Set()]
])

test('ranks consequence-bearing files above neutral ones', () => {
  const ranked = rankTargets({ coverage, changedFiles: [] })
  const names = ranked.map(t => t.file)
  assert.ok(names.indexOf('/repo/src/auth/permissions.js') < names.indexOf('/repo/src/utils/format.js'))
})

test('excludes files with no covered lines', () => {
  const ranked = rankTargets({ coverage, changedFiles: [] })
  assert.equal(ranked.some(t => t.file === '/repo/src/dead.js'), false)
})

test('recently changed files are boosted', () => {
  const plain = rankTargets({ coverage, changedFiles: [] })
  const boosted = rankTargets({ coverage, changedFiles: ['/repo/src/utils/format.js'] })
  const scoreOf = (list) => list.find(t => t.file === '/repo/src/utils/format.js').score
  assert.ok(scoreOf(boosted) > scoreOf(plain))
})

test('every target explains why it was chosen', () => {
  const top = rankTargets({ coverage, changedFiles: [] })[0]
  assert.ok(Array.isArray(top.reasons) && top.reasons.length > 0)
})

test('consequence patterns cover auth, money and deletion', () => {
  const joined = CONSEQUENCE_PATTERNS.map(p => p.source).join('|')
  for (const word of ['admin', 'discount', 'delete']) {
    assert.ok(new RegExp(word).test(joined), `missing consequence keyword: ${word}`)
  }
})
