import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseResult, classify } from '../scripts/lib/result.js'

const jestJson = JSON.stringify({ numTotalTests: 12, numFailedTests: 3 })
const vitestJson = JSON.stringify({ numTotalTests: 12, numFailedTests: 0 })
const emptyJson = JSON.stringify({ numTotalTests: 0, numFailedTests: 0 })

test('parses jest counts', () => {
  assert.deepEqual(parseResult('jest', jestJson), { testsRun: 12, testsFailed: 3 })
})

test('parses vitest counts', () => {
  assert.deepEqual(parseResult('vitest', vitestJson), { testsRun: 12, testsFailed: 0 })
})

test('tolerates log noise around the json payload', () => {
  const noisy = 'warn: something\n' + jestJson + '\nDone in 2s\n'
  assert.deepEqual(parseResult('jest', noisy), { testsRun: 12, testsFailed: 3 })
})

test('unparseable output is a no-tests result, never a kill', () => {
  assert.deepEqual(parseResult('jest', 'total garbage'), { testsRun: 0, testsFailed: 0 })
})

test('a failing test means the mutant was killed', () => {
  assert.equal(classify({ testsRun: 12, testsFailed: 3 }), 'killed')
})

test('all green means the mutant survived', () => {
  assert.equal(classify({ testsRun: 12, testsFailed: 0 }), 'survived')
})

test('zero tests run is a scoping miss, NOT a kill', () => {
  assert.equal(classify(parseResult('jest', emptyJson)), 'no-tests')
})

test('a decoy json blob before the summary does not win', () => {
  const stdout = '{"numTotalTests":5,"numFailedTests":5}\n' + vitestJson + '\n'
  assert.deepEqual(parseResult('vitest', stdout), { testsRun: 12, testsFailed: 0 })
})

test('a decoy AFTER a real-looking blob still resolves to the last summary', () => {
  const stdout = '{"numTotalTests":5,"numFailedTests":0}\n{"numTotalTests":20,"numFailedTests":7}\n'
  assert.deepEqual(parseResult('jest', stdout), { testsRun: 20, testsFailed: 7 })
})

test('a pretty-printed summary with a nested object still parses', () => {
  const stdout = 'noise\n{\n  "numTotalTests": 12,\n  "numFailedTests": 3,\n  "meta": { "x": 1 }\n}\n'
  assert.deepEqual(parseResult('jest', stdout), { testsRun: 12, testsFailed: 3 })
})

test('a NESTED numTotalTests in a trailing blob never beats a real summary', () => {
  const stdout = '{"numTotalTests":20,"numFailedTests":0}\n{"debug":{"numTotalTests":999,"numFailedTests":999}}'
  assert.deepEqual(parseResult('jest', stdout), { testsRun: 20, testsFailed: 0 })
})

test('a trailing nested blob cannot hide a real kill as no-tests', () => {
  const stdout = '{"numTotalTests":20,"numFailedTests":7}\nOTHER: {"meta":{"numTotalTests":0,"numFailedTests":0}}'
  assert.deepEqual(parseResult('jest', stdout), { testsRun: 20, testsFailed: 7 })
})

test('braces inside a string literal do not desynchronise the scan', () => {
  const stdout = '{"msg":"got { and } here","numTotalTests":9,"numFailedTests":2}'
  assert.deepEqual(parseResult('jest', stdout), { testsRun: 9, testsFailed: 2 })
})

test('an unmatched brace in earlier noise does not swallow the real summary', () => {
  const stdout = 'CRASH {{{ partial\n{"numTotalTests":11,"numFailedTests":0}'
  assert.deepEqual(parseResult('jest', stdout), { testsRun: 11, testsFailed: 0 })
})

test('parses the node:test tap reporter summary', () => {
  const stdout = 'ok 1 - passes\nnot ok 2 - fails\n# tests 2\n# pass 1\n# fail 1\n'
  assert.deepEqual(parseResult('node', stdout), { testsRun: 2, testsFailed: 1 })
})

test('parses the node:test default reporter summary', () => {
  const stdout = '✔ passes (0.4ms)\n✖ fails (0.3ms)\nℹ tests 2\nℹ pass 1\nℹ fail 1\n'
  assert.deepEqual(parseResult('node', stdout), { testsRun: 2, testsFailed: 1 })
})

test('a green node:test run classifies as survived', () => {
  const stdout = 'ℹ tests 14\nℹ pass 14\nℹ fail 0\n'
  assert.equal(classify(parseResult('node', stdout)), 'survived')
})

test('unrecognised node output is no-tests, never a kill', () => {
  assert.deepEqual(parseResult('node', 'total garbage'), { testsRun: 0, testsFailed: 0 })
})

test('node parsing does not disturb jest/vitest parsing', () => {
  assert.deepEqual(parseResult('jest', jestJson), { testsRun: 12, testsFailed: 3 })
})
