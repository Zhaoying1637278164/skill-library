import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { openJournal } from '../scripts/lib/journal.js'
import { runSabotageLoop } from '../scripts/lib/loop.js'

const SRC = 'export const isAdmin = (u) => u.role === "admin"\n'

function scratch () {
  const dir = mkdtempSync(join(tmpdir(), 'sab-'))
  const file = join(dir, 'a.js')
  writeFileSync(file, SRC)
  return { dir, file }
}

const json = (run, failed) => JSON.stringify({ numTotalTests: run, numFailedTests: failed })
const survives = async () => ({ stdout: json(10, 0), code: 0, ms: 50 })
const kills = async () => ({ stdout: json(10, 2), code: 1, ms: 50 })
const noTests = async () => ({ stdout: json(0, 0), code: 1, ms: 50 })

const mutationFor = (file) => ({
  file, find: 'u.role === "admin"', replace: 'true',
  symbol: 'isAdmin', consequence: 'isAdmin() returns true for every user',
  breaksOn: "isAdmin({ role: 'guest' })  →  true"
})

test('records a survivor when the suite stays green', async () => {
  const { dir, file } = scratch()
  const { findings } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: survives, runFull: survives
  })
  assert.equal(findings[0].status, 'survived')
})

test('records a kill when the suite goes red', async () => {
  const { dir, file } = scratch()
  const { findings } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: kills, runFull: kills
  })
  assert.equal(findings[0].status, 'killed')
})

test('ALWAYS restores the file, even when the mutant survives', async () => {
  const { dir, file } = scratch()
  await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: survives, runFull: survives
  })
  assert.equal(readFileSync(file, 'utf8'), SRC)
})

test('restores the file even when the runner throws', async () => {
  const { dir, file } = scratch()
  const explode = async () => { throw new Error('runner crashed') }
  await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: explode, runFull: explode
  })
  assert.equal(readFileSync(file, 'utf8'), SRC)
})

test('a scoping miss retries the full suite, and is never scored as a kill', async () => {
  const { dir, file } = scratch()
  const { findings, skipped } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: noTests, runFull: noTests
  })
  assert.equal(findings.length, 0)
  assert.equal(skipped.length, 1)
})

test('a scoping miss that the full suite catches is scored normally', async () => {
  const { dir, file } = scratch()
  const { findings } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: noTests, runFull: kills
  })
  assert.equal(findings[0].status, 'killed')
})

test('a finding carries the real test count from the run that judged it', async () => {
  const { dir, file } = scratch()
  const { findings } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [mutationFor(file)], runScoped: survives, runFull: survives
  })
  assert.equal(findings[0].testsRun, 10, 'must be the count the runner actually reported')
})

test('a mutation the loop cannot apply is skipped with a reason, never scored', async () => {
  const { dir, file } = scratch()
  const { findings, skipped } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal: openJournal(dir),
    mutations: [{ file, find: 'NOT_IN_THE_SOURCE', replace: 'x' }],
    runScoped: survives, runFull: survives
  })
  assert.equal(findings.length, 0)
  assert.equal(skipped.length, 1)
  assert.match(skipped[0].reason, /not present/)
})

test('an apply that fails AFTER truncating the file still restores it before moving on', async () => {
  // applyMutation records the pristine bytes and then writes. Simulate the
  // write failing halfway (ENOSPC on a real disk) by handing the loop a journal
  // whose record() succeeds and a mutate step that damages the file and throws.
  const { dir, file } = scratch()
  const journal = openJournal(dir)

  const halfWritten = {
    file,
    get find () {
      // Reading `find` is the first thing applyMutation does after readFileSync;
      // record() has not run yet, so record it ourselves, wreck the file, and
      // then make the find fail so applyMutation throws with the entry in place.
      journal.record(file)
      writeFileSync(file, '')          // truncated, exactly the ENOSPC shape
      return 'NOT_IN_THE_TRUNCATED_FILE'
    },
    replace: 'x'
  }

  const { findings, skipped } = await runSabotageLoop({
    det: { runner: 'vitest' }, journal,
    mutations: [halfWritten], runScoped: survives, runFull: survives
  })

  assert.equal(findings.length, 0)
  assert.equal(skipped.length, 1)
  assert.equal(readFileSync(file, 'utf8'), SRC, 'the truncated file must be put back')
  assert.deepEqual(journal.pending(), [], 'and its journal entry released')
})
