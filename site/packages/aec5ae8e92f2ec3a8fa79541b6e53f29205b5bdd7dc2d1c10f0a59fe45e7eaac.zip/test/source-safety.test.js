import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { run } from '../scripts/lib/exec.js'

// These exercise the CLI end to end (spawned as a real process, per the exit
// code contract), against temp git repos built fresh under the OS tmpdir --
// never against the sabotage repo itself, and never against test/fixtures/*
// (those live INSIDE the sabotage repo, so their own cleanliness would depend
// on whatever this repo's own working tree happens to look like while it is
// being developed).

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const cli = join(root, 'scripts', 'sabotage.js')

// Documented in scripts/lib/source-safety.js, next to the check that returns
// it: distinct from EXIT_OK/EXIT_REJECTED/EXIT_BAD_INPUT/EXIT_BASELINE_RED
// (0/1/2/3, the gate's codes) and from journal.js's EXIT_RESTORE_FAILED (70).
const EXIT_DIRTY_TREE = 4

function git (cwd, args) {
  execFileSync('git', args, { cwd, stdio: 'pipe' })
}

function commitAll (cwd, message) {
  git(cwd, ['add', '-A'])
  git(cwd, ['-c', 'user.email=sabotage-test@example.com', '-c', 'user.name=Sabotage Test', 'commit', '-q', '-m', message])
}

// A minimal, REAL node:test project -- no node_modules, no root package
// dependency, just `node --test`. Built from scratch rather than reused from
// test/fixtures/* so every temp repo is its own git root.
function project (name) {
  const dir = mkdtempSync(join(tmpdir(), `sab-safety-${name}-`))
  mkdirSync(join(dir, 'src'), { recursive: true })
  mkdirSync(join(dir, 'test'), { recursive: true })
  writeFileSync(join(dir, 'package.json'), JSON.stringify({
    name: `fx-${name}`, type: 'module', scripts: { test: 'node --test test/*.test.js' }
  }))
  writeFileSync(join(dir, 'src', 'calc.js'), 'export const add = (a, b) => a + b\n')
  writeFileSync(join(dir, 'test', 'calc.test.js'), [
    "import { test } from 'node:test'",
    "import assert from 'node:assert/strict'",
    "import { add } from '../src/calc.js'",
    "test('adds numbers', () => { assert.equal(add(2, 3), 5) })",
    ''
  ].join('\n'))
  return dir
}

function gitProject (name) {
  const dir = project(name)
  git(dir, ['init', '-q'])
  commitAll(dir, 'init')
  return dir
}

function manifestFor (dir) {
  const file = join(dir, 'src', 'calc.js')
  const path = join(dir, 'manifest.json')
  writeFileSync(path, JSON.stringify({
    mutations: [{
      file, find: 'a + b', replace: 'a - b',
      symbol: 'add', consequence: 'add() subtracts instead of adding',
      breaksOn: 'add(2, 3)  →  -1'
    }]
  }))
  return path
}

const lastRun = (dir) => JSON.parse(readFileSync(join(dir, '.sabotage', 'last-run.json'), 'utf8'))

// ---------------------------------------------------------------- 1. clean

test('a clean tracked tree proceeds', async () => {
  const dir = gitProject('clean')
  const { code } = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(code, 0)
  assert.equal(lastRun(dir).findings[0].status, 'killed')
})

// --------------------------------------------------- 2 & 3. dirty / --allow-dirty
//
// Built once and shared between these two tests: `--allow-dirty` must proceed
// on the EXACT tree that was refused a moment ago, not a freshly-dirtied one.

let dirtyDir

test('a modified tracked file is refused, naming the file, with a distinct exit code', async () => {
  dirtyDir = gitProject('dirty')
  const calc = join(dirtyDir, 'src', 'calc.js')
  writeFileSync(calc, readFileSync(calc, 'utf8') + '// local edit, never committed\n')

  const { code, stderr } = await run(['node', cli, manifestFor(dirtyDir)], dirtyDir)

  assert.equal(code, EXIT_DIRTY_TREE)
  assert.notEqual(code, 0)
  assert.notEqual(code, 1)   // gate: rejected
  assert.notEqual(code, 2)   // gate: bad input
  assert.notEqual(code, 3)   // gate: baseline red
  assert.match(stderr, /REFUSING TO RUN/)
  assert.match(stderr, /src\/calc\.js/)
  // Refused before anything ran: the uncommitted edit is untouched, not
  // reverted-then-reapplied.
  assert.match(readFileSync(calc, 'utf8'), /local edit/)
})

test('--allow-dirty proceeds on that same dirty tree and prints the file it is risking', async () => {
  const calc = join(dirtyDir, 'src', 'calc.js')
  const { code, stderr } = await run(['node', cli, manifestFor(dirtyDir), '--allow-dirty'], dirtyDir)

  assert.equal(code, 0)
  assert.match(stderr, /--allow-dirty/)
  assert.match(stderr, /src\/calc\.js/)
  assert.equal(lastRun(dirtyDir).findings[0].status, 'killed')
  // The pre-existing uncommitted edit survives the run: sabotage restores
  // exactly what it mutated, nothing more.
  assert.match(readFileSync(calc, 'utf8'), /local edit/)
})

// ------------------------------------------------------------ 4. untracked

test('untracked files alone do not count as dirty', async () => {
  const dir = gitProject('untracked')
  writeFileSync(join(dir, 'NOTES.txt'), 'scratch notes, never `git add`ed\n')

  const { code } = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(code, 0)
})

// --------------------------------------------------------- 5. .sabotage/

test('a pre-existing .sabotage/ directory does not itself make the tree dirty', async () => {
  const dir = gitProject('scratch-dir')
  mkdirSync(join(dir, '.sabotage'), { recursive: true })
  writeFileSync(join(dir, '.sabotage', 'marker'), 'from a prior run\n')
  // Simulate a project that, before this check existed, committed .sabotage/
  // by accident and now has a further UNCOMMITTED change inside it -- a
  // tracked, modified path under .sabotage/, not merely an untracked one.
  // This exercises the explicit .sabotage/ exclusion, not just the
  // untracked-file rule (which would already let a merely-untracked .sabotage/
  // through on its own).
  commitAll(dir, 'accidentally committed .sabotage/ before the gitignore fix')
  writeFileSync(join(dir, '.sabotage', 'marker'), 'modified after commit, still uncommitted')

  const { code } = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(code, 0)
})

// ------------------------------------------------------------- 6. no git

test('a non-git directory proceeds with a warning rather than refusing', async () => {
  const dir = project('no-git')   // deliberately no `git init`
  const { code, stderr } = await run(['node', cli, manifestFor(dir)], dir)

  assert.equal(code, 0)
  assert.match(stderr, /no git repository/i)
  assert.match(stderr, /journal/i)
  assert.equal(lastRun(dir).findings[0].status, 'killed')
})

// -------------------------------------------------------- 7. fresh .gitignore

test('.gitignore gains .sabotage/ on first run, and a second run does not duplicate it', async () => {
  const dir = gitProject('gitignore-fresh')
  assert.ok(!existsSync(join(dir, '.gitignore')))

  const first = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(first.code, 0)
  assert.match(first.stderr, /added `\.sabotage\/` to \.gitignore/)
  const afterFirst = readFileSync(join(dir, '.gitignore'), 'utf8')
  assert.match(afterFirst, /^\.sabotage\/\s*$/m)

  // Run again. The tree is still clean: .gitignore and manifest.json are
  // untracked (never committed), and .sabotage/ is now actually ignored
  // rather than merely untracked.
  const second = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(second.code, 0)
  assert.ok(!/added `\.sabotage\/` to \.gitignore/.test(second.stderr), 'a second run must not re-announce a gitignore edit')

  const afterSecond = readFileSync(join(dir, '.gitignore'), 'utf8')
  assert.equal(afterSecond, afterFirst, 'a second run must not modify an already-correct .gitignore')
  const occurrences = (afterSecond.match(/^\.sabotage\/\s*$/gm) ?? []).length
  assert.equal(occurrences, 1, `expected exactly one .sabotage/ entry, got:\n${afterSecond}`)
})

// ----------------------------------------------------- 8. existing .gitignore

test('an existing .gitignore keeps its content intact when .sabotage/ is appended', async () => {
  const dir = gitProject('gitignore-existing')
  writeFileSync(join(dir, '.gitignore'), 'node_modules/\n*.log\n')

  const { code, stderr } = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(code, 0)
  assert.match(stderr, /added `\.sabotage\/` to \.gitignore/)

  const content = readFileSync(join(dir, '.gitignore'), 'utf8')
  assert.match(content, /node_modules\//)
  assert.match(content, /\*\.log/)
  assert.match(content, /^\.sabotage\/\s*$/m)
})

test('appending to a .gitignore with no trailing newline inserts a newline first, never clobbering it', async () => {
  const dir = gitProject('gitignore-no-trailing-newline')
  writeFileSync(join(dir, '.gitignore'), 'node_modules/')   // deliberately no trailing newline

  const { code } = await run(['node', cli, manifestFor(dir)], dir)
  assert.equal(code, 0)

  const content = readFileSync(join(dir, '.gitignore'), 'utf8')
  assert.equal(content, 'node_modules/\n.sabotage/\n')
})

// =====================================================================
// I3 gap closure: the cwd-subtree check above (`git status --porcelain --
// .`) only ever sees changes inside cwd's own subtree. A manifest's
// `mutation.file`, or a gate spec's `spec.mutation.file` / `spec.siblings[]
// .file`, can name a path ANYWHERE on disk -- so a file with uncommitted
// work OUTSIDE that subtree used to be mutated with no protection at all.
// These tests reproduce that gap and confirm the second, precise per-target
// check (`checkTargetSafety` in scripts/lib/source-safety.js) now closes it.
// =====================================================================

// A git repo shaped exactly like the reported repro: `pkg/` is a full,
// runnable node:test project of its own -- this is what `cwd` will be for
// these tests -- and `other/` is a sibling directory in the SAME repo that
// `pkg/`'s own cwd-subtree check cannot see at all.
function subprojectGitProject (name) {
  const dir = mkdtempSync(join(tmpdir(), `sab-safety-sub-${name}-`))
  const pkg = join(dir, 'pkg')
  mkdirSync(join(pkg, 'src'), { recursive: true })
  mkdirSync(join(pkg, 'test'), { recursive: true })
  writeFileSync(join(pkg, 'package.json'), JSON.stringify({
    name: `fx-${name}`, type: 'module', scripts: { test: 'node --test test/*.test.js' }
  }))
  writeFileSync(join(pkg, 'src', 'calc.js'), 'export const add = (a, b) => a + b\n')
  writeFileSync(join(pkg, 'test', 'calc.test.js'), [
    "import { test } from 'node:test'",
    "import assert from 'node:assert/strict'",
    "import { add } from '../src/calc.js'",
    "test('adds numbers', () => { assert.equal(add(2, 3), 5) })",
    ''
  ].join('\n'))
  mkdirSync(join(dir, 'other'), { recursive: true })
  writeFileSync(join(dir, 'other', 'lib.js'), 'export const helper = (x) => x * 2\n')
  git(dir, ['init', '-q'])
  commitAll(dir, 'init')
  return { root: dir, pkg, other: join(dir, 'other') }
}

// A one-mutation manifest naming an arbitrary target file, written into
// `manifestDir` (always the directory these tests spawn the CLI with as cwd).
function manifestForFile (manifestDir, file, find, replace) {
  const path = join(manifestDir, 'manifest.json')
  writeFileSync(path, JSON.stringify({
    mutations: [{
      file, find, replace,
      symbol: 'x', consequence: 'x behaves differently', breaksOn: 'x(1)'
    }]
  }))
  return path
}

// ----------------------------------------- 1 & 2. out-of-subtree manifest target
//
// Built once and shared between these two tests, same as the dirtyDir pair
// above: `--allow-dirty` must proceed on the EXACT dirty target just refused.

let outsidePkg, outsideLib

test('a manifest targeting a dirty tracked file OUTSIDE the cwd subtree is refused, naming that file (the reported gap)', async () => {
  const { pkg, other } = subprojectGitProject('outside')
  outsidePkg = pkg
  outsideLib = join(other, 'lib.js')
  writeFileSync(outsideLib, readFileSync(outsideLib, 'utf8') + '// uncommitted edit, outside pkg/\n')

  // Sanity check on the premise: the cwd-subtree check alone sees nothing --
  // this is exactly the bypass being closed.
  const subtreeOnly = await run(['git', 'status', '--porcelain', '--', '.'], outsidePkg)
  assert.equal(subtreeOnly.stdout.trim(), '', 'the dirty file must be invisible to the subtree check')

  const manifest = manifestForFile(outsidePkg, outsideLib, 'x * 2', 'x / 2')
  const { code, stderr } = await run(['node', cli, manifest], outsidePkg)

  assert.equal(code, EXIT_DIRTY_TREE)
  assert.match(stderr, /REFUSING TO RUN/)
  assert.match(stderr, /other\/lib\.js/)
  assert.match(stderr, /about to write bugs into/)
  // Refused before anything ran: the uncommitted edit is untouched.
  assert.match(readFileSync(outsideLib, 'utf8'), /uncommitted edit/)
})

test('--allow-dirty proceeds past that same out-of-subtree dirty target and names it', async () => {
  const manifest = manifestForFile(outsidePkg, outsideLib, 'x * 2', 'x / 2')
  const { code, stderr } = await run(['node', cli, manifest, '--allow-dirty'], outsidePkg)

  assert.equal(code, 0)
  assert.match(stderr, /--allow-dirty/)
  assert.match(stderr, /other\/lib\.js/)
  // The pre-existing uncommitted edit survives the run.
  assert.match(readFileSync(outsideLib, 'utf8'), /uncommitted edit/)
})

// --------------------------------------------------- 3. no false positive

test('a dirty file elsewhere that is NOT a mutation target causes no refusal', async () => {
  const { pkg, other } = subprojectGitProject('unrelated-dirty')
  const lib = join(other, 'lib.js')
  writeFileSync(lib, readFileSync(lib, 'utf8') + '// uncommitted, unrelated to this manifest\n')

  // The manifest targets a file INSIDE pkg/'s own clean subtree -- never lib.js.
  const manifest = manifestForFile(pkg, join(pkg, 'src', 'calc.js'), 'a + b', 'a - b')
  const { code } = await run(['node', cli, manifest], pkg)

  assert.equal(code, 0)
  assert.equal(lastRun(pkg).findings[0].status, 'killed')
})

// ------------------------------------------- 4. gate path: mutation + sibling

function gateTargetProject (name) {
  const dir = mkdtempSync(join(tmpdir(), `sab-safety-gate-${name}-`))
  mkdirSync(join(dir, 'gatepkg'), { recursive: true })
  mkdirSync(join(dir, 'other'), { recursive: true })
  writeFileSync(join(dir, 'gatepkg', '.keep'), '')
  writeFileSync(join(dir, 'other', 'primary.js'), 'export const isAdmin = (u) => u.role === "admin"\n')
  writeFileSync(join(dir, 'other', 'sibling.js'), 'export const helper = (x) => x + 1\n')
  git(dir, ['init', '-q'])
  commitAll(dir, 'init')
  return {
    root: dir,
    cwd: join(dir, 'gatepkg'),
    primary: join(dir, 'other', 'primary.js'),
    sibling: join(dir, 'other', 'sibling.js')
  }
}

function gateSpecFor (root, mutationFile, siblingFile) {
  const path = join(root, 'gate.json')
  writeFileSync(path, JSON.stringify({
    testFile: join(root, 'new.test.js'),
    mutation: { file: mutationFile, find: 'x', replace: 'y' },
    siblings: [{ file: siblingFile, find: 'x', replace: 'y' }]
  }))
  return path
}

test('the gate CLI refuses when spec.mutation.file is dirty, outside the cwd subtree', async () => {
  const { root, cwd: gcwd, primary, sibling } = gateTargetProject('mutation-dirty')
  writeFileSync(primary, readFileSync(primary, 'utf8') + '// uncommitted\n')

  const spec = gateSpecFor(root, primary, sibling)
  const { code, stderr } = await run(['node', cli, 'gate', spec], gcwd)

  assert.equal(code, EXIT_DIRTY_TREE)
  assert.match(stderr, /REFUSING TO RUN/)
  assert.match(stderr, /other\/primary\.js/)
})

test('the gate CLI refuses when only a SIBLING file is dirty, even though the primary mutation target is clean', async () => {
  const { root, cwd: gcwd, primary, sibling } = gateTargetProject('sibling-dirty')
  writeFileSync(sibling, readFileSync(sibling, 'utf8') + '// uncommitted\n')

  const spec = gateSpecFor(root, primary, sibling)
  const { code, stderr } = await run(['node', cli, 'gate', spec], gcwd)

  assert.equal(code, EXIT_DIRTY_TREE)
  assert.match(stderr, /REFUSING TO RUN/)
  assert.match(stderr, /other\/sibling\.js/)
})

// ---------------------------------------------------- 5. untracked target

test('an untracked mutation target outside the cwd subtree still does not count as dirty', async () => {
  const { pkg, other } = subprojectGitProject('untracked-outside')
  const scratch = join(other, 'scratch.js')
  writeFileSync(scratch, 'export const helper = (x) => x + 1\n')   // never `git add`ed

  const manifest = manifestForFile(pkg, scratch, 'x + 1', 'x - 1')
  const { code } = await run(['node', cli, manifest], pkg)

  assert.equal(code, 0)
})
