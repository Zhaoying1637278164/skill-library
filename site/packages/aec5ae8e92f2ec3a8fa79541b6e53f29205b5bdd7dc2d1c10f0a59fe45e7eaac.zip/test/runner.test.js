import { test } from 'node:test'
import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { detectRunner, fullCommand, scopedCommand, testCommandFor } from '../scripts/lib/runner.js'

const here = dirname(fileURLToPath(import.meta.url))
const fx = (n) => join(here, 'fixtures', n)

test('detects vitest from devDependencies', () => {
  assert.equal(detectRunner(fx('pkg-vitest')).runner, 'vitest')
})

test('detects jest from devDependencies', () => {
  assert.equal(detectRunner(fx('pkg-jest')).runner, 'jest')
})

test('returns unknown when no runner is present', () => {
  assert.equal(detectRunner(fx('pkg-none')).runner, 'unknown')
})

// ------------------------------------------------------- which signal wins
//
// pkg-vitest and pkg-jest satisfy BOTH signals at once, so neither of them can
// tell the two branches apart. These fixtures isolate one signal each.

test('the test script alone is enough to detect a runner', () => {
  // vitest named in the script, absent from dependencies.
  assert.equal(detectRunner(fx('pkg-script-vitest')).runner, 'vitest')
})

test('a dependency alone is enough when there is no test script', () => {
  const det = detectRunner(fx('pkg-dep-jest'))
  assert.equal(det.runner, 'jest')
  assert.equal(det.testCommand, null, 'no script means no npm test to fall back on')
})

test('when the script and the dependencies disagree, the SCRIPT wins', () => {
  // A repo mid-migration: vitest is still installed but the suite runs jest.
  // Detecting vitest here would parse jest output with the wrong parser and
  // report every mutation as a scoping miss.
  assert.equal(detectRunner(fx('pkg-conflict')).runner, 'jest')
})

test('detects node:test from a real package.json', () => {
  const det = detectRunner(fx('pkg-node'))
  assert.equal(det.runner, 'node')
  assert.deepEqual(det.testCommand, ['npm', 'test'])
})

test('detectRunner returns only what callers actually use', () => {
  assert.deepEqual(Object.keys(detectRunner(fx('pkg-vitest'))).sort(), ['runner', 'testCommand'])
})

// ------------------------------------------------------------------ commands

test('vitest scoped command includes --run and json reporter', () => {
  const cmd = scopedCommand(detectRunner(fx('pkg-vitest')), ['src/a.ts'])
  assert.ok(cmd.includes('--run'), 'must include --run or vitest hangs in watch mode')
  assert.ok(cmd.includes('related'))
  assert.ok(cmd.join(' ').includes('--reporter=json'))
})

test('jest scoped command uses findRelatedTests and json', () => {
  const cmd = scopedCommand(detectRunner(fx('pkg-jest')), ['src/a.ts'])
  assert.ok(cmd.includes('--findRelatedTests'))
  assert.ok(cmd.includes('--json'))
})

test('unknown runner cannot scope', () => {
  assert.equal(scopedCommand(detectRunner(fx('pkg-none')), ['src/a.ts']), null)
})

test('fullCommand returns null for unknown runner', () => {
  assert.equal(fullCommand(detectRunner(fx('pkg-none'))), null)
})

test('no command ever passes --passWithNoTests', () => {
  const det = detectRunner(fx('pkg-vitest'))
  assert.ok(!fullCommand(det).join(' ').includes('passWithNoTests'))
  assert.ok(!scopedCommand(det, ['a.ts']).join(' ').includes('passWithNoTests'))
  assert.ok(!testCommandFor(det, 'a.test.ts').join(' ').includes('passWithNoTests'))
})

test('node runner honours the project test script rather than bare node --test', () => {
  const det = { runner: 'node', testCommand: ['npm', 'test'] }
  assert.deepEqual(fullCommand(det), ['npm', 'test'])
})

test('node runner falls back to node --test when no script exists', () => {
  const det = { runner: 'node', testCommand: null }
  assert.deepEqual(fullCommand(det), ['node', '--test'])
})

// ------------------------------------------------------ single-file scoping

test('testCommandFor scopes vitest to one test file, with --run', () => {
  const cmd = testCommandFor(detectRunner(fx('pkg-vitest')), '/repo/src/a.test.ts')
  assert.deepEqual(cmd, ['npx', 'vitest', 'related', '/repo/src/a.test.ts', '--run', '--reporter=json'])
})

test('testCommandFor scopes jest to one test file', () => {
  const cmd = testCommandFor(detectRunner(fx('pkg-jest')), '/repo/src/a.test.ts')
  assert.deepEqual(cmd, ['npx', 'jest', '--findRelatedTests', '/repo/src/a.test.ts', '--json'])
})

test('testCommandFor runs the node:test file directly, NOT the project script', () => {
  // fullCommand deliberately prefers `npm test`; that runs the whole suite,
  // which is precisely what the gate must not do.
  const det = detectRunner(fx('pkg-node'))
  assert.deepEqual(testCommandFor(det, '/repo/test/a.test.js'), ['node', '--test', '/repo/test/a.test.js'])
})

test('testCommandFor returns null rather than degrading to the full suite', () => {
  assert.equal(testCommandFor(detectRunner(fx('pkg-none')), '/repo/a.test.ts'), null)
  assert.equal(testCommandFor(detectRunner(fx('pkg-vitest')), undefined), null)
})
