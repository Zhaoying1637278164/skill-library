import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { openJournal } from '../scripts/lib/journal.js'
import { applyMutation, revertMutation, MutationError } from '../scripts/lib/mutate.js'

const SRC = 'export const canEdit = (u, p) => u.id === p.ownerId\n'

function scratch (src = SRC) {
  const dir = mkdtempSync(join(tmpdir(), 'sab-'))
  const file = join(dir, 'a.js')
  writeFileSync(file, src)
  return { dir, file }
}

test('applies a unique find/replace', () => {
  const { dir, file } = scratch()
  const m = { file, find: 'u.id === p.ownerId', replace: 'true' }
  applyMutation(openJournal(dir), m)
  assert.match(readFileSync(file, 'utf8'), /=> true/)
})

test('revert returns the file to its original bytes', () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)
  const j = openJournal(dir)
  const m = { file, find: 'u.id === p.ownerId', replace: 'true' }
  applyMutation(j, m)
  revertMutation(j, m)
  assert.deepEqual(readFileSync(file), before)
})

test('rejects a find string that appears more than once', () => {
  const { dir, file } = scratch('const a = x > 1\nconst b = x > 1\n')
  assert.throws(
    () => applyMutation(openJournal(dir), { file, find: 'x > 1', replace: 'x >= 1' }),
    MutationError
  )
})

test('rejects a find string that appears zero times', () => {
  const { dir, file } = scratch()
  assert.throws(
    () => applyMutation(openJournal(dir), { file, find: 'nope', replace: 'x' }),
    MutationError
  )
})

test('a rejected mutation leaves the file untouched', () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)
  try { applyMutation(openJournal(dir), { file, find: 'nope', replace: 'x' }) } catch {}
  assert.deepEqual(readFileSync(file), before)
})

test('a replacement containing $& is written LITERALLY, not expanded', () => {
  // String.prototype.replace expands $&, $`, $' and $1 inside the replacement
  // even when the pattern is a plain string. A mutation whose replacement holds
  // any of them would silently write something other than what was asked for —
  // straight into the user's source.
  const { dir, file } = scratch('const label = greeting\n')
  applyMutation(openJournal(dir), { file, find: 'greeting', replace: '"$& $` $\' $1"' })
  assert.equal(readFileSync(file, 'utf8'), 'const label = "$& $` $\' $1"\n')
})

test('a find string containing $ is matched literally too', () => {
  const { dir, file } = scratch('const cost = $total * 2\n')
  applyMutation(openJournal(dir), { file, find: '$total * 2', replace: '0' })
  assert.equal(readFileSync(file, 'utf8'), 'const cost = 0\n')
})
