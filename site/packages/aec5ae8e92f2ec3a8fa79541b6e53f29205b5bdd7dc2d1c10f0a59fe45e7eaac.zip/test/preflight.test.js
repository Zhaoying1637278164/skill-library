import { test } from 'node:test'
import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { preflight, PreflightError, budgetFor } from '../scripts/lib/preflight.js'

const here = dirname(fileURLToPath(import.meta.url))
const vitestFixture = join(here, 'fixtures', 'pkg-vitest')

const green = async () => ({ stdout: JSON.stringify({ numTotalTests: 40, numFailedTests: 0 }), code: 0, ms: 4000 })
const red = async () => ({ stdout: JSON.stringify({ numTotalTests: 40, numFailedTests: 12 }), code: 1, ms: 4000 })
const empty = async () => ({ stdout: JSON.stringify({ numTotalTests: 0, numFailedTests: 0 }), code: 1, ms: 100 })

test('accepts a green baseline', async () => {
  const result = await preflight(vitestFixture, { runTests: green })
  assert.equal(result.det.runner, 'vitest')
  assert.equal(result.baselineMs, 4000)
})

test('aborts on a red baseline and names the failure count', async () => {
  await assert.rejects(
    () => preflight(vitestFixture, { runTests: red }),
    (err) => err instanceof PreflightError && /12/.test(err.message)
  )
})

test('aborts when the suite runs no tests at all', async () => {
  await assert.rejects(() => preflight(vitestFixture, { runTests: empty }), PreflightError)
})

test('budget scales inversely with suite duration', () => {
  assert.equal(budgetFor(4000, 120000), 30)   // fast suite -> clamped at the ceiling
  assert.equal(budgetFor(60000, 120000), 8)   // slow suite -> clamped at the floor
  assert.equal(budgetFor(10000, 120000), 12)
})
