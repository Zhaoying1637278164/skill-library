import { test } from 'node:test'
import assert from 'node:assert/strict'
import { formatReport } from '../scripts/lib/report.js'

const findings = [
  { file: 'src/auth/permissions.js', symbol: 'isAdmin', status: 'survived',
    consequence: 'isAdmin() returns true for every user', breaksOn: "isAdmin({ role: 'guest' })  →  true" },
  { file: 'src/auth/permissions.js', symbol: 'canEdit', status: 'killed',
    consequence: 'canEdit() ignores ownerId entirely', breaksOn: 'canEdit(userB, postA)  →  true' }
]
const coverageByFile = new Map([['src/auth/permissions.js', 100]])
const out = () => formatReport({ findings, totalTests: 847, coverageByFile })

test('leads with the consequence, never the mutation operator', () => {
  assert.match(out(), /isAdmin\(\) returns true for every user/)
  assert.ok(!/find|replace|operator/i.test(out()))
})

test('prints coverage beside the filename', () => {
  assert.match(out(), /src\/auth\/permissions\.js\s+\(100% line coverage\)/)
})

test('prints the concrete breaking input for survivors', () => {
  assert.match(out(), /breaks on:\s+isAdmin\(\{ role: 'guest' \}\)/)
})

test('shows caught findings so the report reads as fair', () => {
  assert.match(out(), /✓ caught/)
})

test('summary juxtaposes survivors against coverage', () => {
  assert.match(out(), /1 of 2 sabotages went unnoticed/)
})

// ------------------------------------------------------------------ honesty
//
// C4. "Every sabotage was caught by your suite" is a claim about mutations that
// were actually SCORED. Attaching it to an empty findings list turns a run in
// which nothing was measured into a clean bill of health.

const skipped = [
  { mutation: { file: 'src/a.js' }, reason: 'find string not present in src/a.js: x > 1' },
  { mutation: { file: 'src/b.js' }, reason: 'no tests exercised this code' }
]

test('a run where every mutation was skipped NEVER claims the suite caught anything', () => {
  const report = formatReport({ findings: [], skipped, totalTests: 0, coverageByFile: new Map() })
  assert.ok(!/caught by your suite/i.test(report), report)
  assert.ok(!/nothing survived/i.test(report), report)
  assert.match(report, /NOTHING WAS VERIFIED/)
  assert.match(report, /0 mutations scored, 2 skipped/)
})

test('a fully-skipped run names why each mutation was skipped', () => {
  const report = formatReport({ findings: [], skipped, totalTests: 0, coverageByFile: new Map() })
  assert.match(report, /src\/a\.js — find string not present/)
  assert.match(report, /src\/b\.js — no tests exercised this code/)
})

test('an empty manifest says nothing was run, not that everything was caught', () => {
  const report = formatReport({ findings: [], skipped: [], totalTests: 0, coverageByFile: new Map() })
  assert.ok(!/caught by your suite/i.test(report), report)
  assert.match(report, /No mutations were run/)
})

test('a genuinely all-caught run — findings, none survived — says so', () => {
  const allCaught = [
    { file: 'src/a.js', status: 'killed', consequence: 'a() ignores its argument' },
    { file: 'src/a.js', status: 'killed', consequence: 'a() never throws' }
  ]
  const report = formatReport({ findings: allCaught, skipped: [], totalTests: 40, coverageByFile: new Map() })
  assert.match(report, /Every scored sabotage was caught by your suite/)
  assert.match(report, /0 of 2 sabotages went unnoticed/)
})

test('a partial run does not let skipped mutations disappear from the headline', () => {
  const report = formatReport({ findings, skipped, totalTests: 847, coverageByFile })
  assert.match(report, /sabotage — 2 mutations, 1 survived/)
  assert.match(report, /2 further mutations skipped/)
  assert.match(report, /2 mutations skipped \(not scored\)/)
  assert.match(report, /never scored, so this run says nothing about them/)
})

test('skipped defaults to empty so a caller that omits it still formats', () => {
  assert.match(formatReport({ findings, totalTests: 847, coverageByFile }), /2 mutations, 1 survived/)
})
