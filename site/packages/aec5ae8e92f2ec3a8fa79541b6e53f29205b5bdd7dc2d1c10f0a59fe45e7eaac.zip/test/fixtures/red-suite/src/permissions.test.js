import { test, expect } from 'vitest'
import { isAdmin } from './permissions.js'

test('isAdmin is true only for admins', () => {
  expect(isAdmin({ role: 'admin' })).toBe(true)
})

test('this test is deliberately broken', () => {
  expect(isAdmin({ role: 'guest' })).toBe(true)
})
