import { test } from 'node:test'
import assert from 'node:assert/strict'
import { isAdmin } from './permissions.js'

// DELIBERATELY over-fit. It is written against the mutant value rather than the
// contract, which is the exact shape SKILL.md tells the agent to reject on
// sight. It kills its own mutant (isAdmin -> true) and nothing else.
test('isAdmin does not return true for a guest', () => {
  assert.notEqual(isAdmin({ role: 'guest' }), true)
})
