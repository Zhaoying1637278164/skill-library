import { test } from 'node:test'
import assert from 'node:assert/strict'
import { isAdmin } from './permissions.js'

// A PRE-EXISTING, genuine test that lives in the suite already. It is sensitive
// to the sibling mutation ('admin' -> 'ADMIN'). If gate 3 measured the whole
// suite, THIS test would supply the kill and the over-fit test next door would
// be waved through the anti-overfit gate.
test('isAdmin is true for an admin', () => {
  assert.equal(isAdmin({ role: 'admin' }), true)
})
