import { test, expect } from 'vitest'
import { isAdmin, canEdit } from './permissions.js'

test('isAdmin is true only for admins', () => {
  expect(isAdmin({ role: 'admin' })).toBe(true)
  expect(isAdmin({ role: 'guest' })).toBe(false)
})

test('canEdit requires ownership', () => {
  expect(canEdit({ id: 1 }, { ownerId: 1 })).toBe(true)
  expect(canEdit({ id: 2 }, { ownerId: 1 })).toBe(false)
})
