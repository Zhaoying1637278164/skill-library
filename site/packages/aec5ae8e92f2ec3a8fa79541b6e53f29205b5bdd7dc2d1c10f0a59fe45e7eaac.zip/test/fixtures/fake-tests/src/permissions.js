export const isAdmin = (user) => user.role === 'admin'
export const canEdit = (user, post) => user.id === post.ownerId
