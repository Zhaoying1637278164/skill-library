import { test, expect } from 'vitest'
import { isAdmin, canEdit } from './permissions.js'

test('isAdmin works', () => {
  expect(isAdmin({ role: 'admin' })).toBeDefined()
})

test('canEdit works', () => {
  expect(canEdit({ id: 1 }, { ownerId: 1 })).toBeDefined()
})
