import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseCoverage, coveragePercent, coverageCommand } from '../scripts/lib/coverage.js'

// Istanbul shape, emitted by both jest --coverage and vitest --coverage.
const istanbul = {
  '/repo/src/a.js': {
    statementMap: { 0: { start: { line: 3 } }, 1: { start: { line: 7 } }, 2: { start: { line: 9 } } },
    s: { 0: 5, 1: 0, 2: 2 }
  }
}

test('maps covered statement lines per file', () => {
  const cov = parseCoverage(istanbul)
  assert.deepEqual([...cov.get('/repo/src/a.js')].sort((x, y) => x - y), [3, 9])
})

test('excludes lines with zero hits', () => {
  assert.equal(parseCoverage(istanbul).get('/repo/src/a.js').has(7), false)
})

test('an empty report yields an empty map', () => {
  assert.equal(parseCoverage({}).size, 0)
})

test('computes a per-file coverage percentage', () => {
  // 2 of 3 statements covered -> 67%
  assert.equal(coveragePercent(istanbul).get('/repo/src/a.js'), 67)
})

test('a file with no statements is 0%, not NaN', () => {
  const empty = { '/repo/src/b.js': { statementMap: {}, s: {} } }
  assert.equal(coveragePercent(empty).get('/repo/src/b.js'), 0)
})

test('coverage command requests json for vitest', () => {
  const cmd = coverageCommand({ runner: 'vitest' }, '/repo/.sabotage/coverage').join(' ')
  assert.ok(cmd.includes('--coverage'))
  assert.ok(cmd.includes('json'))
  assert.ok(cmd.includes('--run'))
})

test('coverage command requests json for jest', () => {
  const cmd = coverageCommand({ runner: 'jest' }, '/repo/.sabotage/coverage').join(' ')
  assert.ok(cmd.includes('--coverage'))
  assert.ok(cmd.includes('json'))
})

test('the coverage output directory is PINNED on the command line', () => {
  // Both runners let a config file move the reports directory. If it moves we
  // read a stale coverage-final.json, or none, and blame the user's setup.
  const out = '/repo/.sabotage/coverage'
  assert.ok(coverageCommand({ runner: 'vitest' }, out).includes(`--coverage.reportsDirectory=${out}`))
  assert.ok(coverageCommand({ runner: 'jest' }, out).includes(`--coverageDirectory=${out}`))
})

test('coverage is unsupported for node:test and unknown runners', () => {
  assert.equal(coverageCommand({ runner: 'node' }, '/tmp/x'), null)
  assert.equal(coverageCommand({ runner: 'unknown' }, '/tmp/x'), null)
})
