import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { openJournal, journalPath } from '../scripts/lib/journal.js'

function scratch () {
  const dir = mkdtempSync(join(tmpdir(), 'sab-'))
  const file = join(dir, 'a.js')
  writeFileSync(file, 'export const isAdmin = (u) => u.role === "admin"\n')
  return { dir, file }
}

test('restores exact original bytes after a mutation', () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)
  const j = openJournal(dir)
  j.record(file)
  writeFileSync(file, 'export const isAdmin = () => true\n')
  j.restore(file)
  assert.deepEqual(readFileSync(file), before)
})

test('writes a journal to disk so a hard kill is recoverable', () => {
  const { dir, file } = scratch()
  const j = openJournal(dir)
  j.record(file)
  assert.ok(existsSync(journalPath(dir)))
  const saved = JSON.parse(readFileSync(journalPath(dir), 'utf8'))
  assert.equal(saved.entries.length, 1)
})

test('a fresh journal replays a crashed run', () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)
  openJournal(dir).record(file)
  writeFileSync(file, 'BROKEN\n')       // simulate the process dying mid-mutation
  openJournal(dir).restoreAll()          // a new process replays the journal
  assert.deepEqual(readFileSync(file), before)
})

test('restoreAll clears the journal when it succeeds', () => {
  const { dir, file } = scratch()
  const j = openJournal(dir)
  j.record(file)
  j.restoreAll()
  assert.equal(existsSync(journalPath(dir)), false)
})

test('recording the same file twice keeps the ORIGINAL bytes', () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)
  const j = openJournal(dir)
  j.record(file)
  writeFileSync(file, 'MUTATED ONCE\n')
  j.record(file)                         // must not overwrite the pristine copy
  j.restore(file)
  assert.deepEqual(readFileSync(file), before)
})

test('a restore that cannot write fails LOUDLY, never silently', async () => {
  const { dir, file } = scratch()
  const j = openJournal(dir)
  j.record(file)

  // Point the journal at an unwritable destination, then run the real CLI.
  const jp = journalPath(dir)
  const saved = JSON.parse(readFileSync(jp, 'utf8'))
  saved.entries[0].file = join(dir, 'no-such-dir', 'a.js')
  writeFileSync(jp, JSON.stringify(saved))

  const cli = fileURLToPath(new URL('../scripts/restore.js', import.meta.url))
  const proc = spawnSync(process.execPath, [cli], { cwd: dir, encoding: 'utf8' })

  assert.notEqual(proc.status, 0, 'must exit non-zero when restore fails')
  assert.match(proc.stderr, /FAILED TO RESTORE/)
  assert.match(proc.stderr, /no-such-dir/, 'must name the file it could not restore')
})

test('an uncaught exception still restores the file', () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)
  const journalMod = fileURLToPath(new URL('../scripts/lib/journal.js', import.meta.url))
  const script = `
    import { openJournal } from ${JSON.stringify(journalMod)}
    import { writeFileSync } from 'node:fs'
    const j = openJournal(process.cwd())
    j.installSignalTraps()
    j.record(${JSON.stringify(file)})
    writeFileSync(${JSON.stringify(file)}, 'MUTATED\\n')
    throw new Error('boom')
  `
  const child = join(dir, 'crash.mjs')
  writeFileSync(child, script)
  spawnSync(process.execPath, [child], { cwd: dir, encoding: 'utf8' })

  assert.deepEqual(readFileSync(file), before, 'a crash must not leave a mutation on disk')
})

// -------------------------------------------------------- C2 / C3: clear()
//
// Every journal entry is the ONLY surviving copy of a user's original bytes:
// the file on disk still holds the mutant. clear() reads like ordinary cleanup
// and is not.

test('clear() REFUSES to delete a journal that still holds entries', () => {
  const { dir, file } = scratch()
  const j = openJournal(dir)
  j.record(file)
  writeFileSync(file, 'MUTATED\n')

  const outcome = j.clear()
  assert.equal(outcome.ok, false)
  assert.deepEqual(outcome.pending, [file])
  assert.ok(existsSync(journalPath(dir)), 'the only copy of the original bytes must survive')
  assert.match(outcome.message, /REFUSING TO DELETE/)

  // and the recovery record still works
  openJournal(dir).restoreAll()
  assert.equal(readFileSync(file, 'utf8'), 'export const isAdmin = (u) => u.role === "admin"\n')
})

test('clear() removes an empty journal, so the happy path stays a no-op', () => {
  const { dir, file } = scratch()
  const j = openJournal(dir)
  j.record(file)
  j.restore(file)
  assert.equal(j.clear().ok, true)
  assert.equal(existsSync(journalPath(dir)), false)
})

test('a stale journal from a hard-killed run is reported, never quietly discarded', async () => {
  const { dir, file } = scratch()
  const before = readFileSync(file)

  // A previous run died with this file mutated.
  openJournal(dir).record(file)
  writeFileSync(file, 'STILL MUTATED\n')

  const { refuseIfJournalPending } = await import('../scripts/lib/journal.js')
  const outcome = refuseIfJournalPending(openJournal(dir), dir)
  assert.equal(outcome.ok, false)
  assert.match(outcome.message, /REFUSING TO RUN/)
  assert.match(outcome.message, new RegExp(file.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))

  assert.ok(existsSync(journalPath(dir)), 'the recovery record must still be there')
  openJournal(dir).restoreAll()
  assert.deepEqual(readFileSync(file), before)
})

test('a run REFUSES to start while a previous journal is outstanding', () => {
  const { dir, file } = scratch()
  writeFileSync(join(dir, 'package.json'), JSON.stringify({
    name: 'fx-stale', type: 'module', scripts: { test: 'node --test *.test.js' }
  }))
  // A green suite, so that a refusal here can only be the journal check.
  writeFileSync(join(dir, 'a.test.js'),
    "import { test } from 'node:test'\nimport assert from 'node:assert/strict'\n" +
    "test('green', () => { assert.equal(1, 1) })\n")
  const other = join(dir, 'b.js')
  writeFileSync(other, 'export const x = 1\n')

  // A hard-killed run left `other` mutated with only the journal to recover it.
  openJournal(dir).record(other)
  writeFileSync(other, 'export const x = 999\n')

  const manifest = join(dir, 'm.json')
  writeFileSync(manifest, JSON.stringify({ mutations: [{ file, find: '"admin"', replace: '"ADMIN"' }] }))

  const cli = fileURLToPath(new URL('../scripts/sabotage.js', import.meta.url))
  const proc = spawnSync(process.execPath, [cli, manifest], { cwd: dir, encoding: 'utf8' })

  assert.equal(proc.status, 70, 'the tree may still be sabotaged — not a plain failure')
  assert.match(proc.stderr, /REFUSING TO RUN/)
  assert.match(proc.stderr, /restore/)
  assert.ok(existsSync(journalPath(dir)), 'the stale journal must NOT be deleted')
  assert.equal(readFileSync(other, 'utf8'), 'export const x = 999\n', 'and nothing else touched')
})

test('the restore CLI names every file it put back', () => {
  const { dir, file } = scratch()
  const j = openJournal(dir)
  j.record(file)
  writeFileSync(file, 'MUTATED\n')

  const cli = fileURLToPath(new URL('../scripts/restore.js', import.meta.url))
  const proc = spawnSync(process.execPath, [cli], { cwd: dir, encoding: 'utf8' })

  assert.equal(proc.status, 0)
  assert.match(proc.stdout, new RegExp(file.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
  assert.equal(readFileSync(file, 'utf8'), 'export const isAdmin = (u) => u.role === "admin"\n')
})
