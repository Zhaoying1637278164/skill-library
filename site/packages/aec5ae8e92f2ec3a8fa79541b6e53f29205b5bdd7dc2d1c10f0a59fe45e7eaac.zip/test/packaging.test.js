import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, existsSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')

test('plugin manifest exists and names the plugin sabotage', () => {
  const manifest = JSON.parse(readFileSync(join(root, '.claude-plugin/plugin.json'), 'utf8'))
  assert.equal(manifest.name, 'sabotage')
  assert.ok(manifest.description.length > 40)
})

// commands/sabotage.md was deleted on purpose: it registered as
// `sabotage:sabotage`, the exact same name the skill registers as, and the
// command silently won that collision — so the 194-line SKILL.md (the
// equivalent-mutant rule, the never-see-the-mutation rule, the gate exit
// codes) never loaded for anyone who ran /sabotage:sabotage. Its content was
// folded into skills/sabotage/SKILL.md instead. This replaces the old
// 'all three commands exist' test, which encoded that collision as a
// requirement.
test('the audit and restore commands exist; the shadowing sabotage command is gone', () => {
  for (const name of ['sabotage-audit', 'sabotage-restore']) {
    assert.ok(existsSync(join(root, 'commands', `${name}.md`)), `missing command: ${name}`)
  }
  assert.ok(
    !existsSync(join(root, 'commands', 'sabotage.md')),
    'commands/sabotage.md must not exist — it shadowed the skill of the same name and made SKILL.md unreachable'
  )
})

test('no command shadows a skill — they share one namespace', () => {
  const skillsRoot = join(root, 'skills')
  const claimedNames = new Set()

  for (const entry of readdirSync(skillsRoot, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue
    claimedNames.add(entry.name)

    const skillPath = join(skillsRoot, entry.name, 'SKILL.md')
    if (!existsSync(skillPath)) continue
    const frontmatter = readFileSync(skillPath, 'utf8').match(/^---\n([\s\S]*?)\n---/)?.[1] ?? ''
    const nameLine = frontmatter.match(/^name:\s*(.+)$/m)
    if (nameLine) claimedNames.add(nameLine[1].trim())
  }

  const commandNames = readdirSync(join(root, 'commands'))
    .filter((file) => file.endsWith('.md'))
    .map((file) => file.replace(/\.md$/, ''))

  for (const name of commandNames) {
    assert.ok(
      !claimedNames.has(name),
      `commands/${name}.md shadows a skill named "${name}" — a command and a skill ` +
        'with the same name resolve to the same registered name, and the command wins'
    )
  }
})

test('the skill exists and carries frontmatter', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /^---\nname: sabotage\n/)
  assert.match(skill, /description:/)
})

test('ZERO RUNTIME DEPENDENCIES — the hard rule from the spec', () => {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
  assert.deepEqual(pkg.dependencies ?? {}, {})
  assert.deepEqual(pkg.devDependencies ?? {}, {})
})

test('the skill states the equivalent-mutant rule', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /concrete input/i)
})

test('the skill forbids showing the mutation when writing a test', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /never see the mutation|without seeing the mutation/i)
})

test('the skill requires a testFile in the gate spec', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /"testFile"/)
  assert.match(skill, /scoped to it/i)
})

test('the skill defines a sibling as another mutation of the SAME function', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /2–3 FURTHER mutations of the same function/i)
})

test('the skill gives a fallback for a targets run that cannot get coverage', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /If `targets` exits 2/)
  assert.match(skill, /reading the source instead/i)
})

test('the skill tells the agent to surface skipped counts', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /surface the skipped count/i)
  assert.match(skill, /measured NOTHING/)
})

test('the skill documents the budget and every gate exit code', () => {
  const skill = readFileSync(join(root, 'skills/sabotage/SKILL.md'), 'utf8')
  assert.match(skill, /at\s+most `budget` mutations/)
  for (const code of ['0', '1', '2', '3', '70']) {
    assert.match(skill, new RegExp(`\\*\\*${code}\\*\\*`), `gate exit code ${code} is undocumented`)
  }
})
