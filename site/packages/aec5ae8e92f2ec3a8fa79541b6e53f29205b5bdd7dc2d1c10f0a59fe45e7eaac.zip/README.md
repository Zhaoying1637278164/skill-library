# sabotage

**Mutation testing for AI-written code.**

Coverage tells you a line ran — not that anything would notice if it were wrong.
Sabotage breaks your code on purpose — makes `isAdmin()` return true, zeroes out
a discount, flips a boundary — then runs your suite. Any test that still passes
is decorative. Then it writes the test that catches it, and proves that it does.

## Why

Agents write tests that execute lines without asserting behavior. Coverage goes
up while real verification goes down, so the metric most teams trust has become
actively misleading. Mutation testing is the only measure immune to that,
because it asks the only question that matters: *if the code were wrong, would
anything notice?*

## Install

```
claude plugin marketplace add malek0x1/sabotage
claude plugin install sabotage@malek0x1
```

Once sabotage is accepted into the community catalog, this becomes
`claude plugin install sabotage@claude-community`.

Requires Node.js >=22.6.0. Zero dependencies — nothing is added to your project.

## Use

- `/sabotage:sabotage` — check what you just changed (~2 minutes)
- `/sabotage:sabotage-audit` — sweep the whole codebase
- `/sabotage:sabotage-restore` — undo an interrupted run

## We eat our own cooking

Sabotage runs against its own test suite, and every survivor gets fixed.
