---
description: Restore any source files left mutated by an interrupted sabotage run
---

Run `node ${CLAUDE_PLUGIN_ROOT}/scripts/restore.js` from the repository root and
report exactly which files were restored.
