---
description: Full-suite sabotage sweep across the whole codebase
---

Run the sabotage workflow across the whole codebase rather than the diff.

1. Load the `sabotage` skill and follow it exactly.
2. Scope: all covered files, ranked by consequence.
3. Budget: set `SABOTAGE_BUDGET_MS=600000`.
4. Working tree: sabotage refuses to run against uncommitted changes to
   tracked files, since that work has no other copy if a restore ever fails.
   If it refuses, relay the message verbatim and let the user decide whether
   to re-run with `--allow-dirty`. Never add that flag yourself.
