#!/usr/bin/env node
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { preflight, budgetFor } from './lib/preflight.js'
import { openJournal, restoreOrReport, refuseIfJournalPending, writeStderr, EXIT_RESTORE_FAILED } from './lib/journal.js'
import { runSabotageLoop } from './lib/loop.js'
import { detectRunner, fullCommand, scopedCommand, testCommandFor } from './lib/runner.js'
import { run } from './lib/exec.js'
import { formatReport } from './lib/report.js'
import { checkSourceSafety, checkTargetSafety } from './lib/source-safety.js'

// Exit codes. Anything that writes to stdout sets process.exitCode and returns
// rather than calling process.exit(): on a macOS pipe, process.exit() truncates
// an unflushed stdout at 64KB, and `targets` emits one coveragePercent entry per
// covered file — a repo with ~900 covered files produces unparseable JSON.
const EXIT_OK = 0
const EXIT_REJECTED = 1        // the thing ran and the answer was "no"
const EXIT_BAD_INPUT = 2       // we could not run at all; fix the input
const EXIT_BASELINE_RED = 3    // the project's own suite is red; nothing to judge against
// EXIT_DIRTY_TREE (4) lives in source-safety.js, next to the check that returns it.

const cwd = process.cwd()
const rawArgv = process.argv.slice(2)
const allowDirty = rawArgv.includes('--allow-dirty')
const argv = rawArgv.filter((a) => a !== '--allow-dirty')
const command = argv[0]
const totalMs = process.env.SABOTAGE_BUDGET_MS ? Number(process.env.SABOTAGE_BUDGET_MS) : 120000

async function runTargets () {
  const { coverageCommand, parseCoverage, coveragePercent } = await import('./lib/coverage.js')
  const { rankTargets } = await import('./lib/targets.js')

  const det = detectRunner(cwd)
  const outDir = join(cwd, '.sabotage', 'coverage')
  const cmd = coverageCommand(det, outDir)
  if (!cmd) {
    writeStderr(
      `sabotage: coverage is not supported for runner "${det.runner}".\n` +
      '  Skip Phase 1 and choose targets by reading the source instead.'
    )
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  mkdirSync(outDir, { recursive: true })
  const result = await run(cmd, cwd)
  const finalPath = join(outDir, 'coverage-final.json')

  // Never read this file unguarded. The overwhelmingly common failure is a
  // missing coverage provider, and an ENOENT stack trace tells the user
  // nothing about how to fix it.
  if (!existsSync(finalPath)) {
    const hint = det.runner === 'vitest'
      ? '  Most likely: the coverage provider is not installed. Try `npm i -D @vitest/coverage-v8`.'
      : '  Most likely: the coverage provider could not run. Check your jest coverage config.'
    writeStderr([
      `sabotage: the coverage run produced no ${finalPath}.`,
      `  Command: ${cmd.join(' ')}`,
      `  Exit code: ${result.code}`,
      hint,
      result.stderr ? '  Runner said:\n' + result.stderr.trim().split('\n').slice(-8).map(l => '    ' + l).join('\n') : ''
    ].filter(Boolean).join('\n'))
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  let raw
  try {
    raw = JSON.parse(readFileSync(finalPath, 'utf8'))
  } catch (err) {
    writeStderr(`sabotage: ${finalPath} is not valid JSON — ${err.message}`)
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  const changed = await run(['git', 'diff', '--name-only', 'HEAD~1'], cwd)
  const changedFiles = changed.stdout.split('\n').filter(Boolean).map(f => join(cwd, f))

  const percentages = Object.fromEntries(coveragePercent(raw))
  mkdirSync(join(cwd, '.sabotage'), { recursive: true })
  writeFileSync(join(cwd, '.sabotage', 'coverage.json'), JSON.stringify(percentages))

  console.log(JSON.stringify({
    // How many mutations this run can afford. Derived from how long the suite
    // actually took here; the coverage run is the slowest shape of the suite,
    // so this is a conservative ceiling. SABOTAGE_BUDGET_MS moves it.
    budget: budgetFor(result.ms, totalMs),
    targets: rankTargets({ coverage: parseCoverage(raw), changedFiles }).slice(0, 20),
    coveragePercent: percentages
  }, null, 2))
  process.exitCode = EXIT_OK
}

async function runGate (specPath) {
  const { tripleGate } = await import('./lib/verify-test.js')

  // Cheapest check, and the most likely to stop a run, so it goes before even
  // validating the spec argument.
  const safety = await checkSourceSafety(cwd, { allowDirty })
  if (!safety.ok) {
    writeStderr(safety.message)
    process.exitCode = safety.exitCode
    return
  }
  for (const msg of safety.messages) writeStderr(msg)

  if (!specPath) {
    writeStderr('sabotage: gate needs a spec file: sabotage.js gate <gate.json>')
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  let spec
  try {
    spec = JSON.parse(readFileSync(specPath, 'utf8'))
  } catch (err) {
    writeStderr(`sabotage: cannot read the gate spec — ${err.message}`)
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  // The precise safety check: exactly the files this gate run will mutate —
  // the primary mutation plus every sibling — wherever on disk they live, not
  // just cwd's own subtree (which `checkSourceSafety` above already covers).
  // Must run before any mutation is applied, so it goes here, right after the
  // spec is parsed and before the journal or preflight machinery starts.
  const gateTargets = [spec.mutation?.file, ...(spec.siblings ?? []).map((s) => s?.file)]
  const targetSafety = await checkTargetSafety(cwd, gateTargets, { allowDirty, hasGit: safety.hasGit })
  if (!targetSafety.ok) {
    writeStderr(targetSafety.message)
    process.exitCode = targetSafety.exitCode
    return
  }
  for (const msg of targetSafety.messages) writeStderr(msg)

  const det = detectRunner(cwd)
  const journal = openJournal(cwd)

  const outstanding = refuseIfJournalPending(journal, cwd)
  if (!outstanding.ok) {
    writeStderr(outstanding.message)
    process.exitCode = EXIT_RESTORE_FAILED
    return
  }
  journal.installSignalTraps()

  if (!spec.testFile) {
    writeStderr(
      'sabotage: cannot run the gate — the spec has no "testFile".\n' +
      '  Every gate run is scoped to the new test file, so the spec must name it:\n' +
      '  { "testFile": "...", "mutation": {...}, "siblings": [...] }'
    )
    process.exitCode = EXIT_BAD_INPUT
    return
  }
  if (!testCommandFor(det, spec.testFile)) {
    writeStderr(
      `sabotage: cannot run the gate — runner "${det.runner}" cannot be scoped to a single test file.\n` +
      '  A gate that cannot attribute a failure to the new test is not a gate, so this never\n' +
      '  falls back to the full suite.'
    )
    process.exitCode = EXIT_BAD_INPUT
    return
  }
  const full = fullCommand(det)
  if (!full) {
    writeStderr(`sabotage: cannot run the gate — no test command for runner "${det.runner}".`)
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  let verdict
  try {
    verdict = await tripleGate({
      det,
      journal,
      testFile: spec.testFile,
      mutation: spec.mutation,
      siblings: spec.siblings ?? [],
      runTests: (testFile) => run(testCommandFor(det, testFile), cwd),
      runFull: () => run(full, cwd)
    })
  } catch (err) {
    // NEVER journal.clear() here. The gate may have died with a mutation on
    // disk, and the journal is the only copy of the original bytes. Put the
    // source back first; a failure to do so is its own exit code, not "your
    // spec was bad".
    const outcome = restoreOrReport(journal, cwd)
    writeStderr(`sabotage: cannot run the gate — ${err.message}`)
    if (!outcome.ok) {
      writeStderr(outcome.message)
      process.exitCode = EXIT_RESTORE_FAILED
      return
    }
    process.exitCode = EXIT_BAD_INPUT
    return
  }

  const cleared = journal.clear()
  if (!cleared.ok) {
    // clear() already wrote the loud message. A gate that finished with entries
    // still outstanding left source mutated; say so with the code that means it.
    process.exitCode = EXIT_RESTORE_FAILED
    return
  }

  console.log(JSON.stringify(verdict, null, 2))
  if (verdict.baselineRed) {
    writeStderr(
      'sabotage: the project\'s own suite is already red on clean source.\n' +
      '  Do NOT rewrite the test — fix the failing suite first. Until it is green,\n' +
      '  no gate result means anything.'
    )
    process.exitCode = EXIT_BASELINE_RED
    return
  }
  process.exitCode = verdict.ok ? EXIT_OK : EXIT_REJECTED
}

async function runManifest (manifestPath) {
  // Cheapest check, and the most likely to stop a run, so it goes before even
  // reading the manifest.
  const safety = await checkSourceSafety(cwd, { allowDirty })
  if (!safety.ok) {
    writeStderr(safety.message)
    process.exitCode = safety.exitCode
    return
  }
  for (const msg of safety.messages) writeStderr(msg)

  let manifest
  try {
    manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
  } catch (err) {
    writeStderr(`sabotage: cannot read the mutation manifest — ${err.message}`)
    process.exitCode = EXIT_BAD_INPUT
    return
  }
  const mutations = manifest.mutations ?? []

  // The precise safety check: exactly the files this run will mutate,
  // wherever on disk they live, not just cwd's own subtree (which
  // `checkSourceSafety` above already covers). Must run before any mutation
  // is applied, so it goes here, right after the manifest is parsed and
  // before the journal or preflight machinery starts.
  const manifestTargets = mutations.map((m) => m?.file)
  const targetSafety = await checkTargetSafety(cwd, manifestTargets, { allowDirty, hasGit: safety.hasGit })
  if (!targetSafety.ok) {
    writeStderr(targetSafety.message)
    process.exitCode = targetSafety.exitCode
    return
  }
  for (const msg of targetSafety.messages) writeStderr(msg)

  // FIRST, before anything runs. An outstanding journal means a previous run
  // died with source still mutated, and preflight would otherwise measure its
  // "green baseline" against a sabotaged tree.
  const journal = openJournal(cwd)
  const outstanding = refuseIfJournalPending(journal, cwd)
  if (!outstanding.ok) {
    writeStderr(outstanding.message)
    process.exitCode = EXIT_RESTORE_FAILED
    return
  }
  journal.installSignalTraps()

  // Preflight failures are expected user-facing outcomes, not crashes.
  let det, budget
  try {
    ({ det, budget } = await preflight(cwd, { totalMs }))
  } catch (err) {
    writeStderr(err.message)
    process.exitCode = EXIT_REJECTED
    return
  }

  if (mutations.length > budget) {
    writeStderr(
      `sabotage: this manifest holds ${mutations.length} mutations but the budget for this ` +
      `suite is ${budget}. The run will take roughly ${Math.round(mutations.length / budget * 100)}% ` +
      'of the time budget.'
    )
  }

  const { findings, skipped } = await runSabotageLoop({
    det,
    journal,
    mutations,
    runScoped: (files) => run(scopedCommand(det, files) ?? fullCommand(det), cwd),
    runFull: () => run(fullCommand(det), cwd)
  })

  const cleared = journal.clear()   // refuses, loudly, if anything is still sabotaged

  // Machine-readable result for the skill; human report for the terminal.
  mkdirSync(join(cwd, '.sabotage'), { recursive: true })
  writeFileSync(join(cwd, '.sabotage', 'last-run.json'), JSON.stringify({ findings, skipped, budget }, null, 2))

  let coverageByFile = new Map()
  const covPath = join(cwd, '.sabotage', 'coverage.json')
  if (existsSync(covPath)) {
    coverageByFile = new Map(Object.entries(JSON.parse(readFileSync(covPath, 'utf8'))))
  }

  // Fallback only: each finding now carries its own real testsRun from loop.js.
  const totalTests = findings.length ? (findings[0].testsRun ?? 0) : 0
  console.log(formatReport({ findings, skipped, totalTests, coverageByFile }))
  process.exitCode = cleared.ok ? EXIT_OK : EXIT_RESTORE_FAILED
}

if (!command) {
  writeStderr('usage: sabotage.js <mutations.json> | targets | gate <gate.json>')
  process.exitCode = EXIT_BAD_INPUT
} else if (command === 'targets') {
  await runTargets()
} else if (command === 'gate') {
  await runGate(argv[1])
} else {
  await runManifest(command)
}
