#!/usr/bin/env node
import { openJournal, journalPath, restoreOrReport, writeStderr, EXIT_RESTORE_FAILED } from './lib/journal.js'
import { existsSync } from 'node:fs'

const cwd = process.cwd()
if (!existsSync(journalPath(cwd))) {
  console.log('sabotage: nothing to restore — no journal found.')
} else {
  const journal = openJournal(cwd)
  const pending = journal.pending()
  const outcome = restoreOrReport(journal, cwd)
  if (!outcome.ok) {
    writeStderr(outcome.message)
    process.exitCode = EXIT_RESTORE_FAILED
  } else {
    console.log(outcome.message)
    for (const file of pending) console.log('  ' + file)
  }
}
