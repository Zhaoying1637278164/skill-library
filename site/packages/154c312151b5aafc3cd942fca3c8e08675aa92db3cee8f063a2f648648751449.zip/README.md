# Orbit Claude Code Plugin

Discover APIs using Postman Orbit, an agent-friendly search API designed for AI-powered app design.

## What is Orbit?

Orbit is Postman's API discovery service built specifically for AI agent consumption. Unlike browsing an API catalog in a browser, Orbit returns compact, structured payloads with `evaluateGuide` fields that tell agents exactly what each API endpoint can and can't do. This lets agents make integration decisions without trial-and-error.

## Install

```bash
claude plugin marketplace add Postman-Devrel/orbit-claudecode-plugin
claude plugin install orbit@orbit-marketplace
```

The plugin bundles Orbit's MCP server, so there's nothing else to configure -- no API
key, no `claude mcp add`. Installing the plugin wires up the `search` and `integrate`
tools, and the skill drives them.

Then run `/orbit:discover <capability>` in a new session.

To hack on it locally without installing, point Claude Code at a checkout:

```bash
claude --plugin-dir ./orbit-claudecode-plugin
```

## Usage

```
/orbit:discover payment processing for subscriptions
```

Search for multiple capabilities at once:

```
/orbit:discover send transactional email, geocode addresses, payment processing
```

## What you get

For each matching API, Orbit returns:

- **Name**, **description**, and **provider** of the endpoint
- **Method** and **URL** for the API call
- **evaluateGuide** -- structured guidance covering:
  - What the endpoint does
  - What it's best used for
  - What it does not support

Once you've picked endpoints, Orbit can also generate a **task brief** -- the auth
requirements, base URLs, ordered request steps, and gotchas needed to write the
integration.

## Design process

Orbit works best when you use it at the start of a project to build an API blueprint before writing code. Here's the workflow:

1. **Describe what you're building.** Tell your agent the app you want to create, including the key capabilities it needs (payments, auth, email, etc.). You don't need to know which APIs exist yet.

2. **Let the agent query Orbit.** The agent breaks your description into capability queries, hits the Orbit API for each one, and returns candidate endpoints with their evaluateGuide breakdowns.

3. **Read the gaps.** The evaluateGuide's "Not supported" lines are the most valuable part. They tell you what each API can't do, so you can identify missing capabilities before you've written any integration code.

4. **Iterate.** Use those gaps as your next round of queries. "Find me APIs that handle payment refunds" or "I need an auth provider that supports token refresh." Each round narrows the design.

5. **Get the task brief.** Once the endpoint set is settled, the agent sends the selected endpoints plus your task to Orbit's integrate endpoint and gets back a brief covering auth, base URLs, and the request sequence -- the implementation plan, before you write code.

The goal is to make API selection decisions intentionally at design time, not discover limitations mid-sprint after you've already integrated half the stack.

## How it works

The plugin is a thin workflow layer over Orbit's MCP server:

| | Provided by |
|---|---|
| `search` / `integrate` tools, request + response schemas | Orbit's MCP server (bundled) |
| Capability decomposition, gap analysis, iteration | This plugin's skill |

Keeping the API contract on the server side means Orbit can change its parameters
without breaking installed copies of the plugin. If the MCP server is ever
unreachable, the skill falls back to the documented REST endpoints in
[references/orbit-api.md](skills/discover/references/orbit-api.md).

## Orbit vs postman:search

| | Orbit (`orbit:discover`) | Postman Search (`postman:search`) |
|---|---|---|
| **Designed for** | AI agents | Human browsing |
| **Payloads** | Compact, structured | Rich, detailed |
| **evaluateGuide** | Yes -- agent decision support | No |
| **Best when** | Starting a project, need to find APIs for capabilities | Exploring collections, workspaces, documentation |

## Links

- [Orbit documentation](https://www.buildwithorbit.ai/)
- [Orbit API reference](https://www.buildwithorbit.ai/api-reference)
- [Claude Code Plugins](https://docs.anthropic.com/en/docs/claude-code/plugins)
