# Changelog

## 1.0.0 (2026-04-24)

### Added
- Initial release
- 6 skills: setup, remember, recall, reflect, contradict, session
- 1 agent: velixar-librarian for memory curation
- End-of-turn hook for proactive memory storage
- MCP integration with `velixar-mcp-server` (40 tools, 5 resources, 18 prompts)
- Configurable tool tiers (9 / 21 / 40 tools)
