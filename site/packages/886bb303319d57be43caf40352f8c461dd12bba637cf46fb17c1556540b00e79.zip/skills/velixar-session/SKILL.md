---
name: velixar-session
description: Consolidate the current session into persistent memory. Summarizes what was accomplished, decisions made, and open questions. Run this before ending a long coding session.
---

# Session Consolidation

Capture the key outcomes of the current session for future recall.

## Steps

1. **Review the conversation**: Look back through what was discussed and accomplished in this session.

2. **Identify key items to preserve**:
   - **Decisions made**: What was decided and why
   - **Code changes**: What was built, modified, or fixed
   - **Open questions**: What was left unresolved
   - **New conventions**: Any patterns or standards established
   - **Bugs found**: Issues discovered even if not yet fixed
   - **Context for next session**: What someone needs to know to continue this work

3. **Store the session summary**: Create a session summary memory using `velixar_store` with:
   - Tag: `session-summary`
   - Content: A structured summary covering all the key items above

4. **Store individual important facts**: For each significant decision or fact that should persist beyond the session, store it as a separate memory with appropriate tags.

5. **Use session tools**: If `velixar_session_save` is available, call it with the session summary.

6. **Report to the user**: Show what was stored and suggest they can recall it next session with `/velixar:reflect`.

Keep summaries factual and specific. "We refactored the auth module" is less useful than "Refactored auth module to use middleware pattern, moved JWT validation from route handlers to express middleware in src/middleware/auth.ts".
