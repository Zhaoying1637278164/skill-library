---
name: velixar-setup
description: Set up Velixar persistent memory for this Claude Code session. Run this to verify your API key is working and see what cognitive tools are available.
argument-hint: "[api-key]"
---

# Velixar Setup

Help the user get Velixar persistent memory working.

## Steps

1. **Check if the Velixar MCP server is connected.** Look for velixar tools in the available MCP tools (e.g., `velixar_store`, `velixar_search`). If the server is not connected, tell the user:
   - They need a Velixar API key from https://app.velixarai.com/settings/api-keys
   - The plugin should have prompted for the key at install time, but they can reconfigure with `/plugin`

2. **Test the connection.** Call the `velixar_health` tool to verify connectivity. If that is unavailable, try a simple `velixar_search` with a generic query.

3. **Report status.** Tell the user:
   - Whether the MCP server is connected
   - How many Velixar tools are available (tier 1 = 9 core, tier 2 = 21, tier 3 = all 40)
   - Available commands: `/velixar:remember` to store, `/velixar:recall` to search, `/velixar:reflect` for a briefing, `/velixar:session` to consolidate

4. **If this is a first-time setup**, store a memory noting that this workspace has been set up with Velixar, including the date and any project context visible from the current directory.

Do NOT store any API keys or secrets in memory. Only store non-sensitive project context.
