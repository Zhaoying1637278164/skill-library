---
name: velixar-remember
description: Store important context in persistent memory. Use when the user makes a decision, states a preference, describes architecture, encounters a bug fix, or establishes a convention that should be remembered across sessions. Also use when the user says "remember this", "save this", "note this down", or "don't forget".
---

# Remember Context

When you identify something worth remembering, store it in Velixar memory using the `velixar_store` MCP tool.

## What to Remember

Store these kinds of information proactively:
- **Decisions**: "We chose Postgres over MongoDB because..."
- **Preferences**: "User prefers functional components over class components"
- **Architecture**: "The auth flow uses JWT with refresh tokens stored in httpOnly cookies"
- **Bug fixes**: "The race condition in the worker was fixed by adding a mutex on the shared state"
- **Conventions**: "All API responses use camelCase, all DB columns use snake_case"
- **Environment details**: "Production uses Node 20, staging uses Node 18"

## How to Store

1. Write a clear, self-contained memory. It should make sense without the current conversation context.
2. Choose appropriate tags: use lowercase, hyphenated terms like `architecture`, `decision`, `preference`, `bug-fix`, `convention`, `deployment`.
3. Choose the right tier:
   - Tier 0 (pinned): Critical facts that should always surface (core architecture, key constraints)
   - Tier 1 (session): Active context for current work
   - Tier 2 (semantic): Long-term knowledge (default — use this most often)
   - Tier 3 (org): Team-wide knowledge
4. Before storing, do a quick search to check if this fact already exists. If it does, update the existing memory rather than creating a duplicate.

## When Invoked with Arguments

If the user runs `/velixar:remember <text>`, store the provided text as a memory with appropriate tags inferred from the content.

Content to remember: $ARGUMENTS
