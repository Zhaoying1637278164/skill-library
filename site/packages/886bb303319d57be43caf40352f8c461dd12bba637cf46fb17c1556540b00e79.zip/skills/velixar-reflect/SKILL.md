---
name: velixar-reflect
description: Generate a cognitive briefing for the current session. Shows your identity profile, recent themes, and any contradictions. Run at the start of a session to orient yourself.
---

# Session Reflection

Generate a comprehensive cognitive briefing by pulling together multiple sources of context.

## Steps

1. **Identity Profile**: Fetch the user's identity profile using `velixar_identity`. Show name, role, domains, preferences, and goals.

2. **Recent Themes**: Use `velixar_search` or `velixar_list` to fetch the 10 most recent memories. Identify and summarize the key themes.

3. **Knowledge Graph**: If `velixar_graph_traverse` is available, fetch top entities to show the structure of the user's knowledge space.

4. **Contradictions**: Call `velixar_contradictions` to check for any unresolved contradictions or conflicting information.

5. **Present the Briefing**:

```
## Session Briefing

### Who You Are
[Identity summary]

### Recent Focus Areas
[Themes from recent memories]

### Knowledge Structure
[Top entities and relationships]

### Attention Needed
[Contradictions or stale information that needs review]
```

Keep the briefing concise. This is orientation, not a data dump.
