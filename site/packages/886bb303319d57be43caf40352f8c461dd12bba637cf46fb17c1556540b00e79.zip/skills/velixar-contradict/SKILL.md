---
name: velixar-contradict
description: Detect contradictions between current information and stored memories. Use when the user states a fact that might conflict with previously stored knowledge, when reviewing decisions that may have changed, or when the user says something that contradicts earlier context.
---

# Contradiction Detection

When you encounter information that might contradict stored memories, check for conflicts.

## When to Activate

- The user states a technical fact that seems different from what you recall
- A decision is being discussed that reverses a previous decision
- Configuration or architecture details differ from stored context
- The user explicitly asks to check for contradictions

## Process

1. **Identify the claim**: Extract the specific factual assertion from the current context.
2. **Search memory**: Use `velixar_search` to look for related memories that might conflict.
3. **Check contradictions**: If available, use `velixar_contradictions` to surface known conflicts.
4. **Evaluate**: Determine whether this is:
   - A genuine contradiction (old fact is now wrong)
   - An evolution (things changed intentionally)
   - A different context (both facts are true in different situations)
5. **Report clearly**:
   - State what the current claim is
   - State what the stored memory says
   - Explain the nature of the conflict
   - Ask the user how to resolve it: update the old memory, store both as context-dependent, or dismiss

## Important

Do NOT silently ignore contradictions. The whole point of this skill is to surface conflicts so the user can make informed decisions. Even if you are uncertain whether something is truly contradictory, flag it and let the user decide.

If invoked with arguments, check this specific claim: $ARGUMENTS
