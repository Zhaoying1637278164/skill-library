---
name: velixar-recall
description: Search persistent memory for relevant context. Use this to find past decisions, conventions, architecture notes, or anything previously stored.
argument-hint: "<search query>"
---

# Recall from Memory

Search Velixar memory to find relevant context from past sessions.

## Search Strategy

1. **Start with a semantic search** using the user's query via the `velixar_search` MCP tool.
2. **If results are sparse** (fewer than 3 results), try:
   - Rephrasing the query with synonyms
   - Searching for related concepts
   - Using `velixar_multi_search` with 2-3 query variations
3. **Present results clearly**:
   - Show the most relevant memories with their content and relevance score
   - Group related memories together
   - Note the creation date so the user knows how current the information is
   - If memories seem outdated or contradictory, flag this explicitly

## When Invoked

Search for: $ARGUMENTS

If no arguments provided, ask the user what they want to recall.
