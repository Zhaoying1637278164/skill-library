# Velixar Plugin for Claude Code

Persistent cognitive memory for Claude Code. Remember decisions, recall context across sessions, detect contradictions, and build a knowledge graph.

## What It Does

Velixar gives Claude a long-term memory that persists across sessions. Instead of starting fresh every conversation, Claude can recall your architecture decisions, coding conventions, bug fixes, and preferences — building a knowledge graph of your project over time.

## Quick Start

### 1. Get Your API Key

Sign up at [velixarai.com](https://velixarai.com) and go to **Settings > API Keys**.

### 2. Install the Plugin

```
/plugin install velixar
```

You'll be prompted for your API key during installation.

### 3. Verify Setup

```
/velixar:setup
```

## Skills

| Command | Type | Description |
|---------|------|-------------|
| `/velixar:setup` | Manual | Verify connection and see available tools |
| `/velixar:remember <text>` | Auto + Manual | Store decisions, preferences, and architecture in memory |
| `/velixar:recall <query>` | Manual | Search past memories |
| `/velixar:reflect` | Manual | Get a session briefing with identity, themes, and contradictions |
| `/velixar:contradict` | Auto | Detects when current info conflicts with stored memories |
| `/velixar:session` | Manual | Consolidate current session into memory before ending |

**Auto** skills activate automatically when relevant context is detected. **Manual** skills are invoked with slash commands.

## Agent

| Agent | Description |
|-------|-------------|
| `velixar-librarian` | Curate, deduplicate, and audit your memory store |

## Auto-Behaviors

- **Smart Remember**: Claude proactively stores important decisions and architecture details
- **Contradiction Detection**: Automatically flags when current information conflicts with stored memories
- **End-of-Turn Review**: After each response, Claude considers whether anything important should be stored

## Configuration

| Setting | Description | Default |
|---------|-------------|---------|
| API Key | Your Velixar API key (`vlx_...`) | Required |
| Tool Tier | `1` = 9 core, `2` = 21, `3` = all 40 tools | `2` |

## Tool Tiers

- **Tier 1** (9 tools): Store, search, list, update, delete, identity, session resume, health, capabilities
- **Tier 2** (21 tools): + Multi-search, graph traversal, contradictions, timeline, patterns, coverage check, export, import, distill
- **Tier 3** (40 tools): + Batch operations, audit trail, simulation, prediction, advanced graph, security controls

## Pricing

| Plan | Price | Memories | Retrievals/mo |
|------|-------|----------|---------------|
| Free | $0 | 1,000 | 10,000 |
| Pro | $29/mo | 50,000 | 500,000 |
| Enterprise | Custom | Unlimited | Unlimited |

Full pricing at [velixarai.com/pricing](https://velixarai.com/pricing)

## Links

- [Website](https://velixarai.com)
- [Documentation](https://docs.velixarai.com)
- [API Reference](https://docs.velixarai.com/api-reference)
- [GitHub](https://github.com/VelixarAi)

## License

MIT
