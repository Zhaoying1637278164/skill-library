# Canonical formats

The exact shape of every file in `docs/engagement/`. Loaded on demand from
`greenfield-delivery`, not on every engagement: these matter when writing or
reading one of these files, and cost context on every turn that does not.

**The header rows are load-bearing.** Readers match them verbatim and stop
rather than falling back to column position, so a reordered or renamed
column is a malformed file, not a variation. `scripts/test_docs.py` feeds
every example below through the production parser, so an example that stops
parsing fails the build.

`test-cases.md` is not here — its format lives in `business-test-cases`,
beside the standard for writing the cases themselves.

---

### `engagement.md` — canonical format

This is the contract every other skill reads. The block names and field names
below are load-bearing; do not rename them.

```markdown
# Engagement: <Client Name>

- **Started:** YYYY-MM-DD
- **Shape:** <e.g. Fixed-scope greenfield MVP, 6 weeks>
- **Primary contact:** <name, role>
- **Slack channel:** #<client>-delivery

## Tracker
- type: jira
- site: acme.atlassian.net
- project: ACME
- epic: ACME-142

## Progress reporting
- narrative: confluence
- space: ACME
- page: Delivery Status
- dashboard: <url>

## Repository
- url: https://github.com/<org>/<repo>
- default branch: main
```

For an Azure DevOps engagement, the two middle blocks instead read:

```markdown
## Tracker
- type: azure-devops
- org: https://dev.azure.com/acme
- project: ACME
- epic: 4821

## Progress reporting
- narrative: ado-wiki
- wiki: ACME.wiki
- page: /Delivery Status
- dashboard: <url>
```

`narrative` is one of `confluence`, `ado-wiki`, or `repo-markdown`.

#### Fields not known at setup

`epic:` and `dashboard:` cannot exist when `/new-engagement` runs — the epic is
created at gate 1, the dashboard later. Write them as `(pending)`:

```markdown
- epic: (pending)
- dashboard: (pending)
```

**Never invent a value for `epic:`.** `/sync-tracker` parents work items under
it, so a plausible-looking but wrong ID attaches client work to an unrelated
ticket in a live project — and it looks like it succeeded.

| Field | Filled by | When |
|---|---|---|
| `epic:` | `/gate requirements` | Immediately after creating the epic |
| `dashboard:` | You | Once the tracker dashboard exists |

Any skill that reads a `(pending)` field must **stop and say so** rather than
guess or proceed without it.

---

### `signoffs.md` — canonical format

```markdown
# Sign-offs

| Gate | Artifact | Commit | Approved by | Date | Evidence |
|---|---|---|---|---|---|
| Requirements | requirements.md | a1b2c3d | Jane Doe, CTO | 2026-07-17 | <slack permalink> |
```

`Commit` is the SHA the artifact was approved at — the field that makes the
record defensible. It has its own column because it is the one fact that must
be machine-readable: `/dashboard` re-checks each approval against it.

Rows are appended by `/gate` on approval.

### `decisions.md` — canonical format

The working decisions made **between** gates. Optional on a solo engagement;
on a team it is the answer to "why is it like this?", which is the question
everyone asks in week eight and when someone joins mid-engagement.

```markdown
# Decisions — <Client>

| ID | Date | Decision | Why | Instead of | Decided by |
|---|---|---|---|---|---|
| D1 | 2026-08-20 | Reuse the existing auth service | Their team already operates it; a second one doubles the on-call surface | Building our own, which the design left open | R. Mensah and the delivery team, on the Thursday call |
```

| Column | Rule |
|---|---|
| `ID` | `D<n>`, unique. Never renumber — append, as with `R<n>` and `T<n>` |
| `Date` | When it was decided, not when it was written down |
| `Decision` | What was decided, in one line |
| `Why` | **Never blank.** The reason is the whole artifact |
| `Instead of` | What was rejected. `nothing considered` if there genuinely was no alternative |
| `Decided by` | Who was in the room — so the next person knows who to ask |

**This is not `design.md`.** They differ by *lifecycle*, not by subject:

| | `design.md` | `decisions.md` |
|---|---|---|
| When | At gate 2 | Any time |
| Signed | Yes, against a commit | No |
| Drift-checked | Yes — `/conform` `G3` | No |
| Changing it | A change-order conversation | Append a new row |

A decision that *changes the approved design* does not belong here — that is an
amendment to `design.md` and needs the client to re-approve it. This file is for
decisions the signed baseline left open.

**Append-only.** A decision that gets reversed gets a **new row** saying so,
referencing the one it replaces. Editing the original destroys the thing the
file exists for: that a choice was made, on a date, for a reason that seemed
good at the time.

**Do not record a decision without its `Why`.** A log of what was decided and
not why is a list of arbitrary-looking constraints, and the next team deletes
them.

### `tasks.md` — canonical format

Produced at gate 2. Read by `/sync-tracker`, `/status-report`, and `/dashboard`.

```markdown
# Tasks — <Client>

Produced at gate 2 from the approved `requirements.md`.

| ID | Task | Req | Owner | Status | Item |
|---|---|---|---|---|---|
| T1 | Add CSV export to the order list | R8 | Priya Nair | done | NWT-104 |
| T2 | Add scheduled export job | R9 | Sam Okoro | in-progress | NWT-105 |
| T3 | Add refund endpoint | R9 | Priya Nair | blocked | NWT-106 |
| T4 | Add order list pagination | R7 | (unassigned) | todo | (pending) |
```

| Column | Rule |
|---|---|
| `ID` | `T<n>`, unique. Never renumber — append, as with `R<n>` |
| `Task` | `<verb> <object>` per `tracker-conventions` |
| `Req` | Exactly one `R<n>` or `N<n>`. Never blank. `none` if deliberately unlinked |
| `Owner` | Who is doing it. **Written by `/sync-tracker` from the tracker, not by hand.** `(unassigned)` if nobody is — never blank |
| `Status` | Exactly one of `todo`, `in-progress`, `blocked`, `done`, `dropped` |
| `Item` | Tracker work item ID, or `(pending)` before `/sync-tracker` creates it |

**The header row is load-bearing.** Readers match it exactly and do not fall
back to column position. A reordered header must stop the reader, not produce
a plausible misreading.

**`Req` is never blank.** A blank cell conflates "deliberately unlinked" with
"not filled in". Write `none` for the first; a blank cell is a malformed row.

**`Owner` is derived, not authored.** The tracker owns assignment — the team
already changes it there, and a second copy maintained by hand goes stale within
a week and becomes something everyone learns to disbelieve. `/sync-tracker`
pulls it across with the status. On a solo engagement it will read your name or
`(unassigned)` throughout, and costs nothing.

**`dropped` rather than deleting the row.** Deleting silently shrinks the
denominator, so completion jumps with nothing recording that scope was cut. On
a fixed-scope engagement that is a change-order conversation, so it stays
visible.

---

### `knowledge/` — what is true, never what was agreed

`docs/engagement/knowledge/` holds what the team learns about the **client's
world**: their vocabulary, how their systems behave, who to ask. It is not part
of the signed record and no gate approves it.

**Nothing in here is a commitment.** That is the whole constraint, and it is
what stops this folder becoming the failure it usually becomes. A note reading
"they'd like exports to be faster" is a *requirement* — it belongs in
`requirements.md` behind a gate, where the client approves it against a commit.
Left in a knowledge file it will be read by an agent, built, and billed, with
nobody having agreed to anything. Scope arriving through a side door is exactly
what the gates exist to prevent, and a free-form notes folder is the side door.

The test for whether a note belongs here: **would it still be true if the
engagement were cancelled?** Their ERP returning `200` on failure would still be
true. "They want a mobile app" would not.

Two files. Add more only when something genuinely does not fit either.

#### `knowledge/glossary.md`

The client's words, so the code and the conversation use the same ones.

```markdown
# Glossary — <Client>

| Term | What it means here | Not |
|---|---|---|
| Collection | Where a consignment is picked up from | The delivery address |
| Job | One consignment moving from collection to drop-off | A driver's whole day |
| Dispatcher | Staff member who assigns jobs. Never abbreviated to "DP" in the UI | The driver |
```

**`Not` is the column that earns its place.** A term is rarely misunderstood in
isolation; it is misunderstood against the term next to it, and that is the
confusion which reaches identifiers, UI labels and client meetings.

Take terms from the client's own words. **Do not invent one** because the code
needs a name — if the client has no word for it, that is worth asking about,
and the answer is often that the concept does not exist for them.

#### `knowledge/environment.md`

How to actually reach their systems, and who to ask when it breaks. Free-form,
with headings. The things that live in one person's head and stop the
engagement when they are on leave.

**No credentials, ever.** Names of systems, names of people, the shape of the
access request — never a password, token, or key. `build-standards` forbids
secrets in the repository and this file is in the repository.
