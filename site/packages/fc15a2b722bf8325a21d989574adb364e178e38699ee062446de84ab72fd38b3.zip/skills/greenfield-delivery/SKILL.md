---
name: greenfield-delivery
description: Use when working on a client greenfield engagement - starting one, moving through a delivery gate, writing requirements or design documents, syncing work to a tracker, or handing off. Defines the gate sequence and routes to the right skill for each step.
---

# Greenfield Delivery

A methodology for greenfield client engagements. This skill is the
spine: it holds the gate sequence and routes to the skill that does the work.

## First: read the engagement config

Every engagement has `docs/engagement/engagement.md`. **Read it before doing
anything else.** It names the client, the tracker, the progress-reporting
surface, and the repository. Skills that act on a tracker will act on the wrong
project without it.

If it does not exist, this is not yet an engagement — run `/new-engagement`.

### The canonical formats

`engagement.md`, `signoffs.md`, `decisions.md` and `tasks.md` each have an exact
shape that every other skill reads — **see `reference/formats.md`, beside this
file.** Read it before writing or editing any of them; the header rows are
matched verbatim and a reordered column is a malformed file, not a variation.

(`test-cases.md` is in `business-test-cases`.)

### How approval actually works

**Nothing here collects an approval.** No button, no workflow, no integration.
A person asks the client, the client answers in whatever channel they already
use, and a person writes down what happened. That is deliberate: an approval
the tooling generated would be an approval nobody gave.

The sequence, every gate:

1. **Commit the artifact.** Uncommitted changes at the moment of approval make
   the recorded SHA meaningless.
2. **Draft the ask** — short, naming what approval means and what is being
   approved. **Show it to the user; never send it yourself.**
3. **They send it.** Slack, email, a meeting agenda, a Jira or Confluence
   comment — the client's existing channel, not a new one.
4. **The client replies.**
5. **You record it** in `signoffs.md`: gate, artifact, **commit SHA**, who
   approved, the date, and a link to their reply.

### What counts as approval

**An unambiguous yes, from someone with the authority to give it, against a
named version.** All three parts matter:

| | Counts | Does not count |
|---|---|---|
| Clarity | "Approved", "yes, go ahead", 👍 on the request | "Looks good so far", "no objections", silence |
| Authority | The person named in `engagement.md` as primary contact, or someone they delegate to in writing | Anyone who happens to be in the channel |
| Version | A reply to the request naming *this* commit | A yes given before the last edit |

**Silence is never approval.** Neither is "no objections" — plenty of people
raise objections only once something ships. If you are unsure whether what you
received is a yes, it is not one; ask again plainly.

### Conditional approval is not approval

"Yes, but change R3" is extremely common, and it is a **no** with instructions.
Make the change, commit it, and ask again against the new commit. Recording the
first reply against the original SHA would attach their approval to a document
they explicitly asked you to change.

### If the approval was verbal

It happens — a meeting, a call, a corridor. Record it, and record it honestly:

| Gate | Artifact | Commit | Approved by | Date | Evidence |
|---|---|---|---|---|---|
| Requirements | requirements.md | a1b2c3d | R. Mensah, Ops Director | 2026-08-20 | Verbal, on the Thursday call — confirmation requested by email, not yet received |

Then **follow up in writing the same day** and update the row when the reply
lands. A verbal approval is real but not evidence, and the difference only
matters on the day it is disputed — which is the day you cannot fix it.

**Never write an evidence link that does not exist**, and never record an
approval you expect to receive.

## The gate sequence

| Gate | Artifact | Client action | Skill |
|---|---|---|---|
| 0. Discovery *(optional)* | `discovery.md` | Agrees problem and commercial shape | `discovery` |
| 1. Requirements | `requirements.md` | 👍 — **scope baseline** | `requirements-gate` |
| 2. Design | `design.md`, `CLAUDE.md`, `AGENTS.md`, `tasks.md`, `test-cases.md` | 👍 — architecture agreed | `architecture-design` |
| 3. Build | working software; `tasks.md` worked down | demos, visible progress | `build-loop`, `build-standards` |
| 4. Handoff | README, runbook, delivery record | acceptance | `handoff` |

`tasks.md` is **produced at gate 2** — breaking the approved requirements into
a task list is a design output. Gate 3 works that list down; `/sync-tracker`
translates it into tracker work items.

`test-cases.md` is produced at gate 2 for the same reason and from the same
source: it is written against requirements the client has already **approved**,
so the cases are pinned to the signed baseline rather than to a document still
moving. Gate 3 runs them as the work lands, and gate 4 uses their results as
acceptance evidence. See `business-test-cases`.

## The non-negotiable rule

**Gates are sequential, and each requires recorded client approval before the
next begins.**

Approval is recorded in `docs/engagement/signoffs.md` as a row containing the
artifact, the **commit SHA** it was approved at, who approved, the date, and a
link to the evidence (usually a Slack permalink).

The commit SHA is what makes the record worth having. "The client approved the
requirements" is not defensible; "the client approved `requirements.md` at
`a1b2c3d` on 2026-08-12, per this Slack message" is.

### When asked to skip a gate

Say so plainly, in a sentence, and ask for the prior approval to be recorded
first. Do not quietly proceed. The gate sequence is what converts "the AI built
the wrong thing" from your problem into a signed-off change order — a
skipped gate removes that protection precisely when it is most needed.

If the client has genuinely approved out of band, record the approval in
`signoffs.md` with the evidence, then continue.

## Scope discipline

Anything not in the approved `requirements.md` is a change request. When work
in flight drifts outside it:

1. Name the drift explicitly.
2. Say whether it is a change request or a clarification within scope.
3. If it is a change request, it goes back through gate 1 — a new numbered
   requirement, re-approved, re-recorded.

Do not absorb scope silently. Absorbed scope is unbilled work and it destroys
the margin on a fixed-scope engagement.

## Routing

| Working on | Use |
|---|---|
| Scoping conversation, estimate | `discovery` |
| Acceptance criteria | `requirements-gate` |
| Architecture, stack, `CLAUDE.md` | `architecture-design` |
| Working a task with an agent, and reviewing what it produced | `build-loop` |
| Code standards, stack, definition of done | `build-standards` |
| Test cases a business user can run and accept | `business-test-cases` |
| Automating those cases, and reading run results back | `qe` |
| Work item titles, criteria, estimates | `tracker-conventions` |
| Jira / Confluence specifics | `tracker-jira` |
| Azure DevOps / Wiki specifics | `tracker-azure-devops` |
| Client-facing status page | `progress-reporting` |
| Delivery package | `handoff` |

## Commands

Every command in this plugin. **This list is what an agent reads to learn what
exists**, so an omission here is a capability nobody uses — `/approve` was
missing while this same skill described the procedure it performs.

| Command | Does |
|---|---|
| `/new-engagement` | Scaffold `docs/engagement/`, write `engagement.md` |
| `/gate <name>` | Run a gate end to end, up to the sign-off request |
| `/approve <gate>` | Draft an approval request, or record an approval that arrived |
| `/import-artifact` | Bring in a document or Confluence page as a gate artifact |
| `/sync-tracker` | Push `tasks.md` into the tracker; pull status and assignee back |
| `/qe` | Generate Gherkin from the test cases, or read run results back |
| `/status-report` | Regenerate the client-facing status page |
| `/conform` | Check the engagement record against the rules |
| `/dashboard` | Serve a read-only local view of engagement state |
| `/handoff` | Assemble the delivery package |
