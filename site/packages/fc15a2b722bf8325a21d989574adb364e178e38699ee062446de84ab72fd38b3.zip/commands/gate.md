---
description: Run a delivery gate end to end - produce the artifact, review it, prepare sign-off, record approval
argument-hint: discovery | requirements | design | build | handoff
---

# Gate

**Reads:** `signoffs.md` — absent means no gate is approved yet, which blocks `design`, `build` and `handoff`.

Each input names what happens when it is absent. An input with no
stated behaviour is one this command will guess at.

Run one gate of the delivery sequence. Use the `greenfield-delivery` skill for
the sequence, and the skill for this specific gate for the content standard.

## 1. Check the prerequisite

Read `docs/engagement/signoffs.md`. **The blocking predecessor must be recorded
as approved.**

| Running | Blocking predecessor |
|---|---|
| `discovery` | none — this is the first gate |
| `requirements` | none. Discovery is optional and may have been skipped; even when run, it gates the commercial shape, not the scope baseline |
| `design` | **Requirements** |
| `build` | **Design** |
| `handoff` | **Design** (build has no single sign-off; coverage is verified in `/handoff`) |

Only `design`, `build`, and `handoff` can be blocked. Do not block
`discovery` or `requirements` waiting for a sign-off that will never exist.

When the predecessor is missing, stop and say so in a sentence:

> Requirements aren't recorded as approved in `signoffs.md` yet. If the client
> approved out of band, tell me and I'll record it with the evidence — otherwise
> we should close gate 1 first.

Do not proceed on an assumption of approval. The sign-off record is what makes
the scope baseline defensible, and a gate run without it produces work with no
protection behind it.

## 2. Produce the artifact

| Gate | Artifact | Skill |
|---|---|---|
| discovery | `discovery.md` | `discovery` |
| requirements | `requirements.md` | `requirements-gate` |
| design | `design.md` + `CLAUDE.md` + `AGENTS.md` + `tasks.md` + `test-cases.md` | `architecture-design`, `business-test-cases` |
| build | working software; `tasks.md` worked down; `test-cases.md` run | `build-loop`, `build-standards`, `business-test-cases` |
| handoff | README, runbook, record | `handoff` |

## 3. Review before the client sees it

For requirements and design, run the `spec-reviewer` subagent. Fix what it
finds, or say explicitly why a finding is being accepted.

**Open questions must be empty** before an artifact goes for sign-off. An
artifact with open questions cannot serve as a baseline — the questions are
precisely where disputes will occur later.

## 4. Commit, then prepare the sign-off

Commit the artifact first, so the sign-off can reference a real SHA.

Draft the approval request. Keep it short, state what approval means, and make
the ask unambiguous.

**Send it in the channel the client already uses** — the Slack channel named in
`engagement.md`, an email, a meeting agenda, or a comment on the Confluence page
if that is where they live. A new channel for approvals is a channel they will
not check.

**Show it to the user before it goes. Never send it on their behalf.**

## 5. Record the approval

**The approval usually arrives days after this command runs. When it does, use
`/approve <gate>`** — it records the row with the same checks, and re-running
this whole command to write one line is the wrong shape.

If it arrives while you are still here, `/approve` is still the procedure: its
steps 4 to 8 are the judgement, the row, and the tracker follow-through. The
rules for judging the reply are in `greenfield-delivery` →
**What counts as approval**, and the row format is in the same skill.

**Whichever route you take, the artifact must be committed first.** If it has
uncommitted changes at the moment of approval, stop and say so — committing
first is what makes the recorded SHA mean anything.

## 6. Tracker follow-through

**This happens when the approval is recorded, which is `/approve` step 8 — not
here.** The tracker work depends on the client having actually approved, and
that is usually days after this command runs.

If the approval arrives immediately and you record it in step 5 above, do the
step-8 table now. Otherwise leave it: `/approve` owns it, and `epic:
(pending)` correctly blocks `/sync-tracker` until then.
