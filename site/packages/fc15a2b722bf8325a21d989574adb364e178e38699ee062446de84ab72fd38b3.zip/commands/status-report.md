---
description: Regenerate the client-facing status page for business stakeholders
argument-hint: none
---

# Status Report

**Reads:** `engagement.md` — stops if the `## Progress reporting` block is incomplete · `signoffs.md`, `tasks.md`, `requirements.md` — absent means that section of the report says so rather than being omitted.

Each input names what happens when it is absent. An input with no
stated behaviour is one this command will guess at.

Regenerate the narrative status page business stakeholders read. Use the
`progress-reporting` skill for the content standard.

## 1. Read the config

From `docs/engagement/engagement.md`, the `## Progress reporting` block gives
the target:

| `narrative` | Write to |
|---|---|
| `confluence` | The named page in the client's Confluence space |
| `ado-wiki` | The named markdown page in the client's ADO Wiki |
| `repo-markdown` | `docs/engagement/status.md` |

### Stop if the target is not fully specified

This command writes to a **client-visible surface**. Writing a status page into
the wrong client's Confluence space or wiki is a confidentiality incident, not
a bug — and it will look like it succeeded.

Stop and ask if any of these hold:

- `engagement.md` is missing, or has no `## Progress reporting` block
- `narrative:` is unset, `(pending)`, or not one of the three values above
- The target identifier for that surface is missing — `space:` and `page:` for
  Confluence, `wiki:` and `page:` for ADO Wiki

**Never fall back to a different surface** because the configured one looks
unavailable. A missing Confluence space means stop, not write to the repo
instead.

### Cross-check the client before writing

**Nothing can derive this, so do not try.** There is no way to tell from the
file that Confluence space `ACME` belongs to the same client as Jira site
`acme.atlassian.net`; an instruction to "confirm they correspond" gets skipped
or answered by guessing, and guessing yes is the failure this exists to stop.

What is executable:

1. Read the host or organization from `## Tracker` and the target from
   `## Progress reporting`, and **print both, side by side, to the user**
2. If the tracker is Jira and `narrative:` is `ado-wiki` — or the tracker is
   ADO and `narrative:` is `confluence` — **stop.** That mismatch is derivable
   and it is almost always a copied file
3. Otherwise **ask the user to confirm the two belong to the same client**, and
   wait. Do not treat silence as confirmation

Anyone running several engagements at once will eventually copy an
`engagement.md` between them. A person reading two identifiers side by side
catches that in a second; no amount of instruction to "confirm" does.

## 2. Gather

| Source | For |
|---|---|
| `signoffs.md` | Which gates are approved, and when |
| `tasks.md` | What is in progress — canonical format in `greenfield-delivery/reference/formats.md` |
| Live tracker | Current item states, blockers |
| `requirements.md` | Requirement count, for coverage |

Query the tracker for live state rather than trusting `tasks.md` — the point of
regenerating is to be current.

**If the tracker cannot be reached, say so on the page.** Build it from
`tasks.md`, and state that the item states are as of its last sync rather than
live. Silently falling back turns a stale page into one that looks current,
which is worse than a page that admits its age — the client makes decisions on
this.

## 3. Write

Follow the structure in `progress-reporting`. Four questions, in order:

1. Are we on track?
2. What has been agreed so far?
3. What is happening right now?
4. What needs a decision from the client?

**Lead with the answer.** First sentence is on track, at risk, or blocked.

**No internal shorthand** — no requirement numbers, no item IDs, no component
names the client has not heard. Write outcomes in the client's words.

**Report honestly.** If something slipped, say it slipped and why. A page that
reports green until the week before delivery destroys the trust the whole gate
process exists to build.

Include a link to the tracker dashboard for anyone who wants item-level detail.
If `dashboard:` is still `(pending)`, omit the link rather than inventing a URL,
and say it is missing — the dashboard is the half of progress
reporting that stays current without anyone running a command, so it is worth
setting up early.

## 4. Show before publishing

Show the page content to the user before writing it to a client-visible
surface. This is a client-facing artifact — it goes out under your name,
and it should not be published without a human reading it first.

## 5. Confirm

Say where it was written.

**"What changed since the last update" requires the last update.** Nothing here
stores it, so read the page you are about to overwrite *before* writing, and
diff against that. **If you could not read it, say this is a full restatement
rather than a summary of changes** — do not describe changes you inferred from
the tasks that moved, which is a different claim and reads as fact.
