---
description: Assemble the engagement delivery package and record for client acceptance
argument-hint: none
---

# Handoff

**Reads:** `requirements.md` — stops if missing · `signoffs.md` — stops if it has no approved Requirements row · `test-cases.md` — absent means every requirement is **unverified**, never met · `decisions.md` — absent means the record says no decisions were **recorded**, never that none were made · `design.md` — absent means the record cites the requirements baseline alone and says the design document is missing.

Each input names what happens when it is absent. An input with no
stated behaviour is one this command will guess at.

Close out the engagement. Use the `handoff` skill for the content standard.

## 1. Confirm there is a baseline to verify against

Coverage verification is the point of this gate, and it is meaningless without
an approved baseline. Stop and say so if:

- `requirements.md` is missing or has no requirements table
- `signoffs.md` has no approved Requirements row

Without those, you cannot state what was agreed, so you cannot state what was
delivered. Say:

> There's no approved `requirements.md` recorded in `signoffs.md`, so there's
> no baseline to verify delivery against. I can still assemble the README and
> runbook, but the delivery record would assert completeness nobody agreed a
> definition for. How do you want to handle it?

**Do not produce a delivery package that implies verified coverage when no
baseline exists.** That is the one output of this plugin a client may rely on
contractually.

## 2. Verify requirement coverage

**Read `docs/engagement/test-cases.md` first.** It is the evidence for "met" —
a requirement is met because its cases ran and passed, not because someone
asserts it. Use `business-test-cases` for how to read the results.

Walk the requirements table. For each numbered requirement, determine whether
it is:

- **Met** — its test cases ran and passed
- **Unverified** — the software may well be correct, but its cases were never
  run, or were `blocked`. **This is not "met".** Those are different words in
  an acceptance conversation, and the record uses the true one
- **Descoped** — with a recorded change request
- **Outstanding** — not done

**A requirement with no test cases at all is unverified**, not met. It can be
assumed correct; it cannot be accepted against evidence, and saying so at
handoff is far cheaper than being asked for the evidence later.

Report the outstanding list plainly, in full, before proceeding.

**A requirement that is silently absent is the most expensive thing to discover
after acceptance.** Do not describe partial work as complete, and do not round
"mostly working" up to done.

## 3. Produce the package

| Artifact | Standard |
|---|---|
| `README.md` | A developer new to the project can run it without asking |
| Runbook | Whoever is on call can operate it — name the failure modes you know about |
| `CLAUDE.md` / `AGENTS.md` | Reflect the codebase **as delivered**, not as designed |
| Engagement record | Assembled from existing artifacts |

## 4. Update `CLAUDE.md` to reality

If the build diverged from the design and `CLAUDE.md` was not updated, update
it now. It is what the client's team and their agents will rely on after you
leave — a `CLAUDE.md` describing a system that was not built is worse than
none.

## 5. Assemble the record

| Component | Source |
|---|---|
| What was agreed | `requirements.md`, `design.md` |
| When, and by whom | `signoffs.md` with commit SHAs |
| **Why it is like this** | `decisions.md` — each decision with the alternative it beat |
| What was built | git history |
| How it tracked | tracker export |

**`decisions.md` is the component the client's team will use most and the one
easiest to leave out.** The other rows describe what was agreed and what
shipped; this is the only one that says *why*, and after you leave it is what
stops somebody reverting a deliberate choice they assumed was arbitrary. A
handoff without it hands over a system whose constraints have to be
rediscovered by breaking them.

**If `decisions.md` is missing or empty, say the record contains no recorded
decisions.** Do not write that none were made — every engagement makes them,
and the difference is between an honest gap and a false claim.

No service is needed. Git plus markdown plus a tracker export is a complete,
verifiable record.

## 6. Close the tracker

Close the epic. Export the work-item history into the record.

## 7. Name the retainer boundary

If the engagement rolls into support, say explicitly that this engagement is
closed and the next is separate scope. Handoff blurring into unbilled ongoing
work is the most common way a fixed-scope engagement ends up unprofitable after
it appeared to succeed.
