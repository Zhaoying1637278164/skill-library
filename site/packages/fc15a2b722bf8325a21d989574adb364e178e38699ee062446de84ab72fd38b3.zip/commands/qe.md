---
description: Generate Gherkin feature files from the business test cases, or read run results back
argument-hint: generate | results <path to cucumber.json>
---

# QE

**Reads:** `test-cases.md` — stops if missing.

Each input names what happens when it is absent. An input with no
stated behaviour is one this command will guess at.

Use the `qe` skill for the reasoning. This command is the mechanics.

## 1. Check the inputs

Read `docs/engagement/test-cases.md`.

**If it does not exist, stop and say so.** There is nothing to generate from —
test cases come from approved requirements at the Design gate. Offer the
`business-test-cases` skill; do not write feature files from `requirements.md`
directly, and do not invent scenarios.

**If no argument was given, stop and ask** which of `generate` or `results` is
wanted. They are not interchangeable: one writes feature files, the other
rewrites the engagement record.

## 2. Generate

```
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/features.py" generate --root . --out features/
```

One file per requirement, each scenario tagged with its case ID, its
requirement, and its mode.

It **refuses to generate from a file with row-level problems** rather than
silently dropping the rows it could not read — a suite that looks complete
while missing cases is the failure this step is guarding against. Report the
problems and fix `test-cases.md` first.

Generated files carry a "do not edit" banner. Say so when reporting: a change
made in a `.feature` file is lost at the next regeneration and disagrees with
the document the client accepts against.

## 3. Read results back

```
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/features.py" results --root . --report <cucumber.json>
```

**This writes to `docs/engagement/test-cases.md`.** It is the one command here
that does. Say what changed and how many rows.

Report the "automated but absent from the report" line verbatim if it appears.
Those are cases with a feature file and no step definitions behind them, and
they are invisible in a runner summary that reports only what it ran.

**Never edit a `Result` cell by hand to match what you expect.** A result is a
record that something was executed. If the runner did not report a case, it did
not run — say that rather than filling it in.

## 4. Then check it

Run `/conform`.

`C1`, `C2` and `C3` are the rules this pipeline moves. **What each one means,
and the states `C3` distinguishes, are defined in the `qe` skill under
"Checking it" — there and only there.** Naming a count here would be one more
thing to keep in step. `conform.py` implements them; the
skill explains them; this command runs them. Three copies of one rule is how
they end up saying different things about the same run, which is what happened
to the approval rules.

Report what it says, including any rule that could not be checked.
