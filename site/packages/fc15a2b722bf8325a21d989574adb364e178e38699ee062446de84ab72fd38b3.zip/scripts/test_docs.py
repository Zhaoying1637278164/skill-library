"""The plugin IS its markdown. These tests check the markdown.

Everything else in this suite tests Python. But nobody using this runs the
Python directly — they read a skill, follow the format it documents, and let
the tooling read the result. So the contract that actually matters is between
the *documentation* and the *parser*, and nothing was checking it.

The failure this prevents is quiet and total: someone improves a table in a
SKILL.md, the parser now disagrees with the documentation, and every artifact
produced by following the docs is unreadable to `/dashboard` and `/conform` —
which report it as a parse problem, blaming the user for doing what they were
told.

Two contracts are checked here:

1. **Every canonical format example in the docs actually parses.** If the
   skill shows it, the parser must accept it.
2. **Every vocabulary the docs teach matches the vocabulary the code enforces**
   — headers, statuses, results, modes, and the gate prerequisite table.
"""

from __future__ import annotations

import json
import re
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import conform  # noqa: E402
from dashboard import parse  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DOCS = sorted(
    list(ROOT.glob("skills/*/SKILL.md"))
    # Supporting files too. The canonical formats moved out of the spine into
    # skills/greenfield-delivery/reference/formats.md, and a glob that only
    # reached SKILL.md would have quietly stopped feeding those examples
    # through the parser — the docs-to-parser contract still passing while
    # checking nothing.
    + list(ROOT.glob("skills/*/reference/*.md"))
    + list(ROOT.glob("commands/*.md"))
    + list(ROOT.glob("docs/*.md"))
    + [ROOT / "README.md", ROOT / "AGENTS.md"]
)


def _tables(text: str, header: tuple) -> list:
    """Every markdown table in `text` whose header row is exactly `header`.

    Returned as text blocks ready to hand to the real parser — the point is to
    feed the docs' own examples through the production code path, not through a
    re-implementation that could agree with the docs while the parser does not.
    """
    want = "| " + " | ".join(header) + " |"
    found, lines = [], text.splitlines()
    for index, line in enumerate(lines):
        if " ".join(line.split()) != " ".join(want.split()):
            continue
        block = [line]
        for following in lines[index + 1:]:
            if following.strip().startswith("|"):
                block.append(following)
            else:
                break
        found.append("\n".join(block) + "\n")
    return found


class TestDocumentedExamplesParse(unittest.TestCase):
    """Whatever the docs show, the parser must accept."""

    def _check(self, header, parser, label):
        seen = 0
        for path in DOCS:
            text = path.read_text(encoding="utf-8")
            for block in _tables(text, header):
                seen += 1
                with self.subTest(doc=str(path.relative_to(ROOT)), kind=label):
                    parsed = parser(block)
                    self.assertTrue(parsed.header_ok,
                                    f"{path.name}: documented header is not the canonical one")
                    self.assertEqual(
                        parsed.problems, (),
                        f"{path.name} documents a {label} example the parser rejects: "
                        + "; ".join(p.message for p in parsed.problems),
                    )
        # A silent zero would make this whole class vacuous — if the tables are
        # ever renamed or reformatted, this must fail rather than pass having
        # checked nothing.
        self.assertGreater(seen, 0, f"found no {label} examples in the docs to check")

    def test_tasks_examples(self):
        self._check(parse.TASKS_HEADER, parse.parse_tasks, "tasks.md")

    def test_signoff_examples(self):
        self._check(parse.SIGNOFFS_HEADER, parse.parse_signoffs, "signoffs.md")

    def test_test_case_examples(self):
        self._check(parse.TESTS_HEADER, parse.parse_test_cases, "test-cases.md")


class TestDocumentedVocabularyMatchesTheCode(unittest.TestCase):
    """The words the docs teach must be the words the code accepts."""

    # The spine and the reference it points at, read as one document: a rule
    # documented in either is documented, and which file holds it is a context
    # -economy decision rather than a contract change.
    SPINE = (
        (ROOT / "skills" / "greenfield-delivery" / "SKILL.md").read_text(encoding="utf-8")
        + (ROOT / "skills" / "greenfield-delivery" / "reference" / "formats.md")
        .read_text(encoding="utf-8")
    )
    CASES = (ROOT / "skills" / "business-test-cases" / "SKILL.md").read_text(encoding="utf-8")

    def test_task_statuses(self):
        # The spine documents these as a backticked list in the column rules.
        for status in parse.TASK_STATUSES:
            self.assertIn(f"`{status}`", self.SPINE,
                          f"parser accepts {status!r} but the spine never mentions it")

    def test_no_status_is_documented_that_the_parser_rejects(self):
        documented = set(re.findall(r"`(todo|in-progress|blocked|done|dropped|complete|wip|open)`",
                                    self.SPINE))
        self.assertTrue(
            documented <= parse.TASK_STATUSES,
            f"the spine documents statuses the parser rejects: {documented - parse.TASK_STATUSES}",
        )

    def test_test_results_and_modes(self):
        for value in parse.TEST_RESULTS:
            self.assertIn(f"`{value}`", self.CASES,
                          f"parser accepts result {value!r} but the skill never mentions it")
        for value in parse.TEST_MODES:
            self.assertIn(f"`{value}`", self.CASES,
                          f"parser accepts mode {value!r} but the skill never mentions it")

    def test_headers_are_quoted_in_the_docs_exactly_as_the_parser_wants(self):
        for header, doc in (
            (parse.TASKS_HEADER, self.SPINE),
            (parse.SIGNOFFS_HEADER, self.SPINE),
            (parse.TESTS_HEADER, self.CASES),
        ):
            row = "| " + " | ".join(header) + " |"
            self.assertIn(row, doc, f"the canonical header is not documented verbatim: {row}")


class TestGatePrerequisitesAgree(unittest.TestCase):
    """`commands/gate.md` states which gate blocks which, in a table a human
    reads. `conform.BLOCKED_BY` states the same thing in code. They were
    written separately and nothing made them agree — so a change to either
    would leave the checker enforcing a rule the command does not describe."""

    def test_the_table_in_gate_md_matches_the_checker(self):
        text = (ROOT / "commands" / "gate.md").read_text(encoding="utf-8")
        documented = {}
        for line in text.splitlines():
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) != 2:
                continue
            gate = cells[0].strip("`").lower()
            if gate not in ("discovery", "requirements", "design", "build", "handoff"):
                continue
            blocker = re.sub(r"[^a-zA-Z ]", "", cells[1]).strip().lower()
            if blocker.startswith("none"):
                continue
            # "**Requirements**" -> "requirements"; "**Design** (build has..." -> "design"
            first = blocker.split()[0] if blocker.split() else ""
            if first in ("discovery", "requirements", "design", "build", "handoff"):
                documented[gate] = first
        self.assertEqual(
            documented, conform.BLOCKED_BY,
            "commands/gate.md and conform.BLOCKED_BY disagree about gate order",
        )


class TestTheRepoUsesItsOwnVocabulary(unittest.TestCase):
    """`/import-artifact` told the reader to look for "stated non-goals".

    The canonical section is `## Out of scope`. A reader following the command
    goes looking for a heading that does not exist in the format they are
    required to produce, and the check that enforces it (`conform` R3's
    out-of-scope handling) does not know the word either. Synonyms for
    canonical names are how a documented format quietly becomes two formats.
    """

    # Term the repo uses -> synonym that must not appear instead.
    FORBIDDEN = {"non-goal": "Out of scope"}
    SHIPPED = ("skills/*/SKILL.md", "skills/*/reference/*.md", "commands/*.md",
               "docs/USAGE.md", "README.md", "AGENTS.md")

    def test_no_shipped_file_uses_a_synonym_for_a_canonical_section(self):
        for pattern in self.SHIPPED:
            for path in sorted(ROOT.glob(pattern)):
                text = path.read_text(encoding="utf-8").lower()
                for synonym, canonical in self.FORBIDDEN.items():
                    with self.subTest(path=path.name, synonym=synonym):
                        # `in` on the text, assert on a bool: assertNotIn
                        # against a whole document prints the whole document.
                        self.assertFalse(
                            synonym in text,
                            f"{path.relative_to(ROOT)} says {synonym!r}; the "
                            f"canonical name is {canonical!r}")


class TestCommandsPointAtWhereTheFormatsActuallyLive(unittest.TestCase):
    """The canonical formats moved out of the spine into
    `reference/formats.md` when the spine was halved. Every command that
    referenced them was updated except `/import-artifact`, which kept telling
    the reader the shapes are "what greenfield-delivery defines".

    The spine no longer contains them, so that reader either reads the spine
    and finds nothing, or invents a shape. Both end in a file the parsers
    refuse.
    """

    def test_no_command_says_the_spine_defines_the_formats(self):
        for path in sorted((ROOT / "commands").glob("*.md")):
            text = path.read_text(encoding="utf-8")
            with self.subTest(command=path.stem):
                self.assertNotIn(
                    "`greenfield-delivery` defines", text,
                    f"/{path.stem} says the spine defines the formats; they "
                    "live in greenfield-delivery/reference/formats.md")

    def test_the_file_it_points_at_exists(self):
        self.assertTrue(
            (ROOT / "skills" / "greenfield-delivery" / "reference"
             / "formats.md").exists())


class TestEachConformRuleIsExplainedOnce(unittest.TestCase):
    """`C3` had three states, explained in three places.

    The approval rules were deduplicated to a single source after four copies
    drifted apart. `C3` was the same defect left standing: `conform.py`
    implements it, `qe/SKILL.md` explains it, and `commands/qe.md` explained it
    again in different words. `C3` is the rule most likely to be edited —
    it deliberately does not fire while a suite is being wired up, and that
    exception is exactly the kind of thing one copy loses.

    The skill owns the explanation; the command runs the check and points at
    it. Same shape as `/approve` deferring to the spine.
    """

    EXPLAINS = ("stays quiet", "three states", "fires once", "does **not** fire")

    def test_only_one_shipped_file_explains_when_c3_fires(self):
        explaining = []
        for pattern in ("skills/*/SKILL.md", "commands/*.md", "docs/USAGE.md"):
            for path in sorted(ROOT.glob(pattern)):
                text = path.read_text(encoding="utf-8")
                if "C3" in text and any(p in text for p in self.EXPLAINS):
                    explaining.append(str(path.relative_to(ROOT)))
        self.assertEqual(
            explaining, ["skills/qe/SKILL.md"],
            "C3's behaviour should be explained in the qe skill and nowhere "
            f"else; found it in {explaining}",
        )

    def test_the_command_still_points_somewhere(self):
        # Deleting the explanation must not leave the command silent about
        # where the rules are defined.
        text = (ROOT / "commands" / "qe.md").read_text(encoding="utf-8")
        self.assertIn("`qe` skill", text)


class TestApprovalsAreRecordedByApprove(unittest.TestCase):
    """`/approve` was added because approval arrives days after the gate runs.

    `/import-artifact` still routed an out-of-band approval to `/gate`, which
    would re-run the whole gate to write one row — and, worse, skip the
    judgement `/approve` exists to make: they approved THEIR document, not the
    imported one, and whether the reply still covers what is now in the record
    is exactly the question.
    """

    def test_no_command_routes_recording_an_approval_to_gate(self):
        for path in sorted((ROOT / "commands").glob("*.md")):
            if path.stem in ("gate", "approve"):
                continue
            text = path.read_text(encoding="utf-8")
            with self.subTest(command=path.stem):
                self.assertNotIn(
                    "let `/gate` do it", text,
                    f"/{path.stem} routes an approval to /gate; /approve "
                    "records approvals")


class TestAgentsMdDoesNotRestateTheRouting(unittest.TestCase):
    """AGENTS.md carried its own gate-to-skill table — a fifth statement of
    something the spine, `/gate` and the skills already agree on.

    It had already drifted: Build routed to `build-standards` alone, while the
    spine and `/gate` route Build to `build-loop` and `build-standards`. An
    agent that read this file instead of the spine skipped the skill
    describing how a task is actually worked, and nothing would have said so.

    The fix is the one applied to the approval rules: one source, pointers
    everywhere else. This test keeps the table from growing back.
    """

    GATES = ("discovery", "requirements-gate", "architecture-design",
             "build-standards", "build-loop", "handoff")

    def test_it_does_not_enumerate_the_gate_skills(self):
        text = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
        # The spine is the one skill AGENTS.md should send you to, plus any
        # named in prose explaining WHY the table is gone.
        table_rows = [line for line in text.splitlines()
                      if line.strip().startswith("|")
                      and "skills/" in line and "SKILL.md" in line]
        self.assertEqual(
            table_rows, [],
            "AGENTS.md is restating the gate routing; the spine owns it",
        )

    def test_it_still_sends_the_reader_to_the_spine(self):
        # Removing the table must not leave an agent with nowhere to go.
        text = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
        self.assertIn("skills/greenfield-delivery/SKILL.md", text)


class TestNoConsultingFirmFraming(unittest.TestCase):
    """The plugin was written for one consulting firm and open-sourced.

    The README and AGENTS.md were rewritten at that point; the skills were not,
    and sixteen references to "the firm" survived across ten of them — a
    standard belonging to an organisation the reader does not work for, and in
    one case a TODO addressed to it. The re-test caught the TODO; the rest was
    the same defect, unflagged.

    Whoever installs this has a team, or is one person. Either way there is no
    firm, and text that assumes one reads as somebody else's internal document.
    """

    SHIPPED = ("skills/*/SKILL.md", "skills/*/reference/*.md", "commands/*.md",
               "docs/USAGE.md", "README.md", "AGENTS.md")

    def test_no_shipped_file_refers_to_the_firm(self):
        offenders = []
        for pattern in self.SHIPPED:
            for path in sorted(ROOT.glob(pattern)):
                for number, line in enumerate(
                        path.read_text(encoding="utf-8").splitlines(), 1):
                    lowered = line.lower()
                    if "the firm" in lowered or "firm's" in lowered:
                        offenders.append(
                            f"{path.relative_to(ROOT)}:{number} {line.strip()}")
        self.assertEqual(
            offenders, [],
            "consulting-firm framing survives in shipped files:\n  "
            + "\n  ".join(offenders))


class TestNothingShipsWithAnUnfinishedMarker(unittest.TestCase):
    """`tracker-conventions` shipped "**TODO - confirm the firm's scale.**"

    Two things were wrong with it. It is a note the author left for himself,
    published to everyone who installs the plugin, in a section a reader goes
    to for an answer. And it addressed "the firm" — the consulting framing
    that was removed everywhere else, leaving this one pointing at an
    organisation the reader does not belong to.

    A marker at the START of a line is the author talking to himself. The word
    used mid-sentence is ordinary prose — `build-loop` discusses leaving a TODO
    in code as a smell, and must keep saying so.
    """

    MARKERS = ("TODO", "TBD", "FIXME", "XXX")
    SHIPPED = ("skills/*/SKILL.md", "skills/*/reference/*.md", "commands/*.md",
               "docs/USAGE.md", "README.md", "AGENTS.md")

    def test_no_shipped_line_begins_with_an_unfinished_marker(self):
        checked = 0
        for pattern in self.SHIPPED:
            for path in sorted(ROOT.glob(pattern)):
                checked += 1
                for number, line in enumerate(
                        path.read_text(encoding="utf-8").splitlines(), 1):
                    bare = line.strip().lstrip("*_->#| ").upper()
                    for marker in self.MARKERS:
                        if bare.startswith(marker):
                            self.fail(
                                f"{path.relative_to(ROOT)}:{number} ships an "
                                f"unfinished {marker} marker: {line.strip()!r}")
        self.assertGreater(checked, 10, "the shipped-file globs matched nothing")

    def test_the_word_is_still_allowed_in_prose(self):
        # Guard against over-correcting into a check that bans the vocabulary.
        text = (ROOT / "skills" / "build-loop" / "SKILL.md").read_text(
            encoding="utf-8")
        self.assertIn("TODO", text)


class TestOverlappingSkillsNameTheirBoundary(unittest.TestCase):
    """A skill is selected by its description alone.

    Two pairs described the same territory. `business-test-cases` opened "Use
    when writing or reviewing business test cases" and `qe` opened "Use when
    automating business test cases" — for a model routing "help me with the
    test cases", those are the same sentence. `tracker-conventions` and both
    tracker skills all offered "creating epics, stories". When two
    descriptions match a request equally, which skill loads is arbitrary, and
    the wrong one gives confidently wrong advice: `qe` will happily invent
    business scenarios, and `tracker-jira` will happily invent conventions.

    Semantic overlap cannot be measured here. What can be checked is that each
    skill in a known-overlapping pair states the boundary and names the
    sibling to use instead — which is the thing that makes routing decidable.
    """

    # Pairs that genuinely cover adjacent territory, and so must each say
    # where they stop.
    NEIGHBOURS = {
        "business-test-cases": ("qe",),
        "qe": ("business-test-cases",),
        "tracker-conventions": ("tracker-jira", "tracker-azure-devops"),
        "tracker-jira": ("tracker-conventions",),
        "tracker-azure-devops": ("tracker-conventions",),
    }

    def _description(self, skill):
        path = ROOT / "skills" / skill / "SKILL.md"
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith("description:"):
                return line[len("description:"):].strip()
        self.fail(f"{skill} has no description")

    def test_each_overlapping_skill_names_the_one_to_use_instead(self):
        for skill, siblings in self.NEIGHBOURS.items():
            description = self._description(skill)
            for sibling in siblings:
                with self.subTest(skill=skill, sibling=sibling):
                    self.assertIn(
                        sibling, description,
                        f"{skill} covers territory next to {sibling} but does "
                        "not say where it stops, so routing between them is "
                        "arbitrary",
                    )

    def test_the_named_siblings_exist(self):
        # A description pointing at a skill that was renamed sends the reader
        # nowhere, and nothing else would catch it.
        for skill, siblings in self.NEIGHBOURS.items():
            for sibling in siblings:
                with self.subTest(sibling=sibling):
                    self.assertTrue((ROOT / "skills" / sibling / "SKILL.md").exists())

    def test_no_two_skills_open_with_the_same_clause(self):
        # The opening clause is what a router matches on hardest. Two skills
        # sharing one is the collision in its most literal form.
        openings = {}
        for path in sorted((ROOT / "skills").glob("*/SKILL.md")):
            skill = path.parent.name
            opening = self._description(skill).split(" - ")[0].split(",")[0].lower()
            with self.subTest(skill=skill):
                self.assertNotIn(
                    opening, openings,
                    f"{skill} and {openings.get(opening)} both open with "
                    f"{opening!r}",
                )
            openings[opening] = skill


class TestHandoffAssemblesTheWholeRecord(unittest.TestCase):
    """/handoff assembled the record from requirements, sign-offs, git history
    and the tracker — and left out `decisions.md`, the only source that says
    WHY the system is the way it is.

    That omission is invisible at handoff and expensive afterwards: the
    client's team inherits a set of deliberate constraints with no reasons
    attached, and rediscovers them by breaking them. `decisions.md` is also
    the artifact this methodology added on purpose, so leaving it out of the
    delivery package means the engagement never delivers the thing that
    distinguishes it.
    """

    def setUp(self):
        self.text = (ROOT / "commands" / "handoff.md").read_text(encoding="utf-8")

    def _assembly_table(self):
        section = self.text.split("## 5. Assemble the record")[1].split("## ")[0]
        return {cells[1].strip()
                for line in section.splitlines()
                if line.strip().startswith("|")
                and len(cells := line.strip().strip("|").split("|")) >= 2}

    def test_the_record_includes_why_the_system_is_like_this(self):
        self.assertTrue(
            any("decisions.md" in source for source in self._assembly_table()),
            "the delivery record has no source for WHY — add decisions.md to "
            "the assembly table in /handoff",
        )

    def test_an_absent_decisions_file_is_reported_not_claimed_empty(self):
        # "no decisions were made" is false in every engagement. The honest
        # sentence is that none were recorded, and the two read very
        # differently in an acceptance meeting.
        self.assertIn("no recorded", self.text.lower().replace("\n", " "))

    def test_every_source_of_the_record_is_a_declared_input_or_external(self):
        # A component assembled from a file /handoff never declared reading is
        # a file it will guess at — the same defect the Reads: declaration
        # exists to prevent, one level up.
        block = re.search(r"\*\*Reads:\*\*(.+?)\.\n\n", self.text, re.S)
        self.assertIsNotNone(block, "/handoff has no **Reads:** declaration")
        declared = set(re.findall(r"`([a-z-]+\.md)`", block.group(1)))
        for source in self._assembly_table():
            for artifact in re.findall(r"`([a-z-]+\.md)`", source):
                with self.subTest(artifact=artifact):
                    self.assertIn(
                        artifact, declared,
                        f"/handoff assembles the record from {artifact} but "
                        "does not declare reading it",
                    )


class TestTheDesignGateArtifactListAgrees(unittest.TestCase):
    """Four files state what gate 2 produces, and nothing made them agree.

    `TestGatePrerequisitesAgree` pins gate ORDER across two sources; the
    artifact LIST was pinned nowhere, so USAGE.md sat at four artifacts while
    the spine, the command and the skill had moved to five. A reader following
    USAGE.md produces no `AGENTS.md`, and every non-Claude tool in the client's
    repo then has no pointer to the conventions.

    Design is the only gate that produces more than one or two files, which is
    the only reason this list is worth a test of its own.
    """

    ARTIFACT = re.compile(r"`([A-Za-z0-9/_.-]+\.md)`")

    def _from_row(self, path, prefix, column):
        """The artifacts in `column` of the first table row starting `prefix`.

        The column index differs per table — these are four hand-written
        tables in four files, not one generated one, which is the whole
        reason they could drift apart.
        """
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not stripped.startswith(prefix):
                continue
            cells = stripped.strip("|").split("|")
            found = {a.rsplit("/", 1)[-1]
                     for a in self.ARTIFACT.findall(cells[column])}
            self.assertTrue(found, f"no artifacts in column {column} of {prefix!r}")
            return found
        self.fail(f"no row starting {prefix!r} in {path.name}")

    def _expected(self):
        return self._from_row(ROOT / "commands" / "gate.md", "| design |", 1)

    def test_the_spine_agrees_with_the_command(self):
        self.assertEqual(
            self._from_row(ROOT / "skills" / "greenfield-delivery" / "SKILL.md",
                           "| 2. Design |", 1),
            self._expected())

    def test_the_skill_that_runs_the_gate_agrees(self):
        text = (ROOT / "skills" / "architecture-design" / "SKILL.md").read_text(
            encoding="utf-8")
        listed = {a.rsplit("/", 1)[-1] for a in self.ARTIFACT.findall(
            text.split("## ")[0])}
        self.assertEqual(listed, self._expected())

    def test_usage_agrees_in_its_summary_table(self):
        self.assertEqual(
            self._from_row(ROOT / "docs" / "USAGE.md", "| **2. Design**", 2),
            self._expected())

    def test_usage_agrees_in_its_per_gate_table(self):
        # The second, detailed table further down the same file. It drifted
        # independently of the summary table above it.
        text = (ROOT / "docs" / "USAGE.md").read_text(encoding="utf-8")
        heading = "\n# Gate 2 \u2014 Design\n"
        self.assertIn(heading, text, "USAGE.md lost its Gate 2 section heading")
        section = text.split(heading)[1].split("\n---")[0]
        rows = {m for line in section.splitlines() if line.strip().startswith("| `")
                for m in self.ARTIFACT.findall(line.split("|")[1])}
        self.assertEqual(rows, self._expected())

    def test_the_prose_count_matches_the_list(self):
        # "Produces four things" over a five-row table is the same defect one
        # step earlier: a reader who trusts the number stops reading at four.
        words = {3: "three", 4: "four", 5: "five", 6: "six"}
        n = len(self._expected())
        for path, phrase in (
            (ROOT / "docs" / "USAGE.md", "Produces %s things"),
            (ROOT / "skills" / "architecture-design" / "SKILL.md",
             "Produces %s artifacts"),
        ):
            with self.subTest(path=path.name):
                # `in` on the text, but assert on a bool: assertIn against a
                # whole document prints the whole document on failure, and a
                # failure nobody can read is a failure nobody acts on.
                self.assertTrue(
                    (phrase % words[n]) in path.read_text(encoding="utf-8"),
                    f"{path.name} should say {phrase % words[n]!r} — gate 2 "
                    f"produces {n} artifacts")


class TestReadmeCountsAreTrue(unittest.TestCase):
    """The README states counts about itself. Counts rot silently — it claimed
    290 tests when there were 314, in the one document whose argument is that
    it is precise about what has been verified."""

    README = (ROOT / "README.md").read_text(encoding="utf-8")

    def _claimed(self, noun):
        m = re.search(r"(\d+)\s+" + noun, self.README)
        self.assertIsNotNone(m, f"the README no longer states a {noun} count")
        return int(m.group(1))

    def test_skill_command_and_agent_counts(self):
        for noun, path, pattern in (
            ("skills", "skills", "*/SKILL.md"),
            ("commands", "commands", "*.md"),
            ("subagents", "agents", "*.md"),
        ):
            with self.subTest(noun=noun):
                self.assertEqual(self._claimed(noun),
                                 len(list((ROOT / path).glob(pattern))))

    def test_the_test_count_is_a_floor_that_holds(self):
        # Stated as a floor ("over N"), not an exact figure. An exact count
        # needs a README edit on every commit that adds a test, and the one
        # that gets forgotten is how it came to claim 290 when there were 314.
        # A floor cannot rot upward — it can only become an understatement,
        # and this fails if the suite ever shrinks below it.
        defined = 0
        for path in (ROOT / "scripts").glob("test_*.py"):
            defined += len(re.findall(r"^\s+def test_", path.read_text(encoding="utf-8"), re.M))
        m = re.search(r"over (\d+) tests", self.README)
        self.assertIsNotNone(m, "the README no longer states a test floor")
        floor = int(m.group(1))
        self.assertGreaterEqual(
            defined, floor,
            f"the README claims over {floor} tests; only {defined} are defined",
        )


class TestCrossReferencesResolve(unittest.TestCase):
    """A pointer into a skill must land on a section that exists.

    Consolidating the approval rules replaced three copies with three pointers,
    and a pointer is only better than a copy if it resolves. The most expensive
    defect found in this repo was the same shape from the other direction: the
    met-versus-unverified distinction was written in `skills/handoff` while
    `commands/handoff.md` — the file that actually executes — never mentioned
    it. A reference nobody can follow is worse than a duplicate, because a
    duplicate at least still says the thing.
    """

    # `skill-name` → **Section Name**, with the arrow optionally at a line end.
    POINTER = re.compile(r"`([a-z][a-z-]+)`\s*→\s*\*\*([^*]+)\*\*")

    def test_every_skill_section_pointer_names_a_real_heading(self):
        seen = 0
        for path in sorted(list((ROOT / "commands").glob("*.md"))
                           + list((ROOT / "docs").glob("*.md"))
                           + list((ROOT / "skills").glob("*/SKILL.md"))):
            text = path.read_text(encoding="utf-8")
            for skill, section in self.POINTER.findall(text):
                target = ROOT / "skills" / skill / "SKILL.md"
                with self.subTest(source=path.name, skill=skill, section=section):
                    self.assertTrue(target.exists(),
                                    f"{path.name} points at skill {skill!r}, which does not exist")
                    headings = re.findall(r"^#{1,6}\s+(.+?)\s*$",
                                          target.read_text(encoding="utf-8"), re.M)
                    normalised = [h.replace("`", "").strip() for h in headings]
                    self.assertIn(
                        section.strip(), normalised,
                        f"{path.name} points at {skill} \u2192 {section!r}, "
                        f"which is not a heading in that skill",
                    )
                    seen += 1
        # A silent zero would make this vacuous the moment the pointer syntax
        # changes — the exact way the /gate coverage test failed before.
        self.assertGreater(seen, 0, "found no skill-section pointers to check")

    def test_every_supporting_file_pointer_resolves(self):
        # The other half. Moving the formats out of the spine left six
        # references to `<skill>/reference/<file>.md` scattered across the
        # commands; a typo in any of them sends a reader to a file that is not
        # there, which is the failure this whole class exists to catch.
        seen = 0
        for path in sorted(list((ROOT / "commands").glob("*.md"))
                           + list((ROOT / "docs").glob("*.md"))
                           + list((ROOT / "skills").glob("*/SKILL.md"))
                           + list((ROOT / "skills").glob("*/reference/*.md"))):
            text = path.read_text(encoding="utf-8")
            for ref in re.findall(r"`([a-z][a-z-]+/reference/[a-z-]+\.md)`", text):
                with self.subTest(source=path.name, ref=ref):
                    self.assertTrue((ROOT / "skills" / ref).exists(),
                                    f"{path.name} points at skills/{ref}, which does not exist")
                    seen += 1
        self.assertGreater(seen, 0, "found no supporting-file pointers to check")


class TestPluginMetadata(unittest.TestCase):
    """The two JSON files and the README's install line must agree.

    They drifted: the marketplace was still named `greenfield-dev` from when
    this was a private dev marketplace, so anyone adding
    `Abhisrajput/greenfield-delivery` got a marketplace called "greenfield-dev"
    — and "dev" reads as internal on a public listing. Nothing checked it,
    because nothing reads these files except the plugin system.
    """

    MARKET = json.loads((ROOT / ".claude-plugin" / "marketplace.json")
                        .read_text(encoding="utf-8"))
    PLUGIN = json.loads((ROOT / ".claude-plugin" / "plugin.json")
                        .read_text(encoding="utf-8"))
    README = (ROOT / "README.md").read_text(encoding="utf-8")

    def test_the_two_version_numbers_agree(self):
        # The same version is declared in two files. Bumping one and not the
        # other is silent — the plugin system reads one, humans read the other.
        self.assertEqual(self.MARKET["plugins"][0]["version"], self.PLUGIN["version"])

    def test_the_marketplace_is_named_after_the_repository_users_add(self):
        match = re.search(r"/plugin marketplace add \S+/(\S+)", self.README)
        self.assertIsNotNone(match, "the README does not show an install command")
        self.assertEqual(
            self.MARKET["name"], match.group(1),
            "the marketplace name does not match the repository the README "
            "tells people to add",
        )

    def test_the_readme_installs_the_plugin_that_is_declared(self):
        self.assertIn(f"/plugin install {self.PLUGIN['name']}", self.README)
        self.assertEqual(self.MARKET["plugins"][0]["name"], self.PLUGIN["name"])

    def test_nothing_still_calls_itself_internal_or_dev(self):
        # The exact class of leftover that shipped here.
        for field in (self.MARKET["name"], self.MARKET["description"],
                      self.PLUGIN["name"], self.PLUGIN["description"]):
            self.assertNotRegex(field, r"\b(internal|dev|private|wip|test)\b",
                                f"plugin metadata still reads as unreleased: {field!r}")


class TestEverythingIsDiscoverable(unittest.TestCase):
    """A command nobody can find is a command nobody runs. `/qe` shipped
    without a README entry and nothing noticed — check.sh validates that
    commands are well-formed, not that a reader could ever learn they exist."""

    def test_every_command_appears_in_the_readme_command_table(self):
        # Asserted against the TABLE, not the whole file. The first version
        # searched the README for "`/gate`" anywhere, and passed only because
        # an unrelated sentence elsewhere happened to mention it in backticks.
        # Rewriting that sentence broke the test while the command table — the
        # thing it was meant to check — had not changed at all. A test that
        # passes for a reason it does not name will eventually fail for one
        # too.
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        rows = [line for line in readme.splitlines()
                if line.startswith("| `/")]
        self.assertTrue(rows, "no command table found in the README")
        documented = {row.split("`")[1].split()[0].lstrip("/") for row in rows}
        for path in sorted((ROOT / "commands").glob("*.md")):
            with self.subTest(command=path.stem):
                self.assertIn(
                    path.stem, documented,
                    f"/{path.stem} exists but is not in the README's command table",
                )

    def test_every_command_appears_in_the_spine(self):
        # The README is for people; the SPINE is what an agent reads to learn
        # what exists. Coverage was enforced on the README alone, and the
        # spine listed five of ten — omitting /approve while describing, in
        # the same file, the approval procedure /approve performs. An
        # unlisted command is a capability nobody invokes.
        spine = (ROOT / "skills" / "greenfield-delivery" / "SKILL.md").read_text(encoding="utf-8")
        listed = {m for m in re.findall(r"\|\s*`/([a-z-]+)", spine)}
        self.assertTrue(listed, "the spine no longer has a command table")
        for path in sorted((ROOT / "commands").glob("*.md")):
            with self.subTest(command=path.stem):
                self.assertIn(path.stem, listed,
                              f"/{path.stem} exists but the spine never lists it")

    def test_every_skill_is_routed_from_the_spine(self):
        # The routing table is how an agent picks a skill. A skill missing
        # from it is one the model will rarely load, however good it is — `qe`
        # was absent entirely.
        spine = (ROOT / "skills" / "greenfield-delivery" / "SKILL.md").read_text(encoding="utf-8")
        routed = set(re.findall(r"\|\s*`([a-z][a-z-]+)`\s*\|", spine))
        for skill_dir in sorted((ROOT / "skills").iterdir()):
            if not skill_dir.is_dir() or skill_dir.name == "greenfield-delivery":
                continue  # the spine does not route to itself
            with self.subTest(skill=skill_dir.name):
                self.assertIn(skill_dir.name, routed,
                              f"skill {skill_dir.name!r} is in no routing row")

    def test_the_spine_stays_short_enough_to_load_every_turn(self):
        # AGENTS.md: "keep skills short — length is a cost paid on every
        # engagement." The spine is the most-loaded file in the plugin and had
        # grown to 331 lines, roughly 190 of them reference material. The
        # formats now live in reference/formats.md, loaded on demand. This is
        # a ratchet, not a target: it fails if the router starts reabsorbing
        # material that belongs beside it.
        spine = (ROOT / "skills" / "greenfield-delivery" / "SKILL.md")
        lines = len(spine.read_text(encoding="utf-8").splitlines())
        self.assertLess(lines, 200,
                        f"the spine is {lines} lines; move reference material to "
                        "skills/greenfield-delivery/reference/ and leave a pointer")

    def test_every_skill_is_referenced_from_outside_itself(self):
        # A skill nothing routes to is one the model will rarely load.
        others = [p for p in DOCS if "/skills/" not in str(p)] + list(
            ROOT.glob("skills/*/SKILL.md"))
        for skill_dir in sorted((ROOT / "skills").iterdir()):
            if not skill_dir.is_dir():
                continue
            name = skill_dir.name
            with self.subTest(skill=name):
                refs = [p for p in others
                        if p.parent.name != name
                        and f"`{name}`" in p.read_text(encoding="utf-8")]
                self.assertTrue(refs, f"skill {name!r} is referenced from nowhere")


class TestEveryDeclaredInputIsGuarded(unittest.TestCase):
    """Per input, not per file.

    `check.sh` greps each command for a stop phrase and passes on one hit. That
    proves *a* guard exists, not that *each input* is guarded — /sync-tracker
    passed with five guards on the `## Tracker` block and on `epic:` while
    having none for a missing `tasks.md`, the file it exists to read.

    Two ways of computing this from prose were tried and both produced noise:
    an artifact a command *creates* needs no guard, and a guard written as
    "Stop and say so if:" over a bulleted list puts the artifact on a different
    line from the stop word. A noisy check is worse than a crude one, because
    people learn to ignore it.

    So the declaration is the contract. Each command states what it reads and
    what it does when each input is absent — **stop is one answer and a stated
    degradation is an equally good one.** `/status-report` should say "no tasks
    yet", not refuse. What is not acceptable is no answer, because that is
    precisely the input the command will guess at.
    """

    ARTIFACT = re.compile(r"`([a-z-]+\.md)`")

    def _declaration(self, path):
        m = re.search(r"\*\*Reads:\*\*(.+?)\.\n\n", path.read_text(encoding="utf-8"), re.S)
        self.assertIsNotNone(m, f"/{path.stem} has no **Reads:** declaration")
        return m.group(1)

    def test_every_command_declares_what_it_reads(self):
        for path in sorted((ROOT / "commands").glob("*.md")):
            with self.subTest(command=path.stem):
                self.assertIn("**Reads:**", path.read_text(encoding="utf-8"),
                              f"/{path.stem} does not say which inputs it reads, so "
                              "nothing can check they have defined behaviour")

    def test_every_declared_input_states_what_happens_when_it_is_absent(self):
        checked = 0
        for path in sorted((ROOT / "commands").glob("*.md")):
            declaration = self._declaration(path)
            # Segments are separated by a middot; each may cover several
            # artifacts that share one behaviour.
            for segment in declaration.split("·"):
                artifacts = self.ARTIFACT.findall(segment)
                if not artifacts:
                    continue
                checked += len(artifacts)
                with self.subTest(command=path.stem, reads=", ".join(artifacts)):
                    self.assertIn(
                        "—", segment,
                        f"/{path.stem} declares it reads {', '.join(artifacts)} "
                        "without saying what happens when absent",
                    )
        self.assertGreater(checked, 0, "no declared inputs found to check")

    def test_a_command_that_reads_nothing_says_so(self):
        # Silence and "reads nothing" must not look alike. /new-engagement
        # creates the record and reads none of it, and that is worth stating
        # rather than leaving as an empty declaration.
        decl = self._declaration(ROOT / "commands" / "new-engagement.md")
        self.assertIn("nothing", decl.lower())


class TestEveryCommandDocumentsItsRefusal(unittest.TestCase):
    """Every command must say what it refuses to do, and name the artifact it
    refuses on.

    An earlier version of this test demanded one exact phrasing — a bolded
    "**If ... stop**" — and failed four commands that document refusals
    perfectly well in other words. `status-report.md` has a whole heading
    reading "Stop if the target is not fully specified"; `gate.md` says "When
    the predecessor is missing, stop and say so". Asserting a template rather
    than the property would have pushed good prose toward a house style for no
    gain, which is the kind of test that makes people stop writing prose.

    So this checks the two things that actually matter: a refusal exists, and
    it is about something concrete."""

    REFUSAL = re.compile(
        r"stop and (say|ask)|stop if|stop,|must stop|do not (proceed|invent|"
        r"guess|fall back|configure|produce|post|publish|overwrit)",
        re.IGNORECASE,
    )

    def test_every_command_states_a_refusal(self):
        for path in sorted((ROOT / "commands").glob("*.md")):
            with self.subTest(command=path.name):
                text = path.read_text(encoding="utf-8")
                self.assertRegex(
                    text, self.REFUSAL,
                    f"{path.name} never says what it refuses to do",
                )

    def test_every_command_names_an_artifact_or_input_it_depends_on(self):
        # A refusal with nothing concrete attached ("do not guess") tells the
        # reader nothing about when it fires.
        for path in sorted((ROOT / "commands").glob("*.md")):
            with self.subTest(command=path.name):
                text = path.read_text(encoding="utf-8")
                self.assertRegex(
                    text, r"`(docs/engagement/[a-z-]+\.md|engagement\.md|"
                          r"signoffs\.md|requirements\.md|tasks\.md|test-cases\.md)`",
                    f"{path.name} names no engagement artifact, so its guards "
                    "cannot be about anything specific",
                )


if __name__ == "__main__":
    unittest.main()
