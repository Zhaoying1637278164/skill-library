"""Tests for the Gherkin generator and the result import.

The properties worth pinning here are all about a suite being unable to claim
more than it verified.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import features  # noqa: E402
from dashboard import parse  # noqa: E402

HEADER = (
    "| ID | Req | Mode | Scenario | Given | When | Then | Result |\n"
    "|---|---|---|---|---|---|---|---|\n"
)
REQS = (
    "## Functional\n\n"
    "| ID | Requirement | Acceptance criteria |\n|---|---|---|\n"
    "| R1 | Submit orders | It works |\n"
)


def _cases(*rows):
    return parse.parse_test_cases(HEADER + "".join(rows))


class TestGeneration(unittest.TestCase):
    def test_scenario_carries_its_case_id_as_a_tag(self):
        # Results map back by tag, never by scenario text — text must stay free
        # to improve without silently breaking the mapping.
        out = features.generate(
            _cases("| TC1 | R1 | automated | Submit | Ready | They submit | It appears | not run |\n"),
            parse.parse_requirements(REQS),
        )
        feature = out["r1.feature"]
        self.assertIn("@TC1 @R1 @automated", feature)
        self.assertIn("Scenario: Submit", feature)
        self.assertIn("Given Ready", feature)
        self.assertIn("When They submit", feature)
        self.assertIn("Then It appears", feature)

    def test_generated_files_say_they_are_generated(self):
        out = features.generate(
            _cases("| TC1 | R1 | manual | S | G | W | T | not run |\n"),
            parse.parse_requirements(REQS),
        )
        self.assertIn("do not edit", out["r1.feature"])

    def test_a_requirement_absent_from_requirements_md_is_named_not_invented(self):
        # The rule everywhere in this repo: never invent an identifier or a
        # title. A feature titled with a plausible guess is worse than one
        # saying it does not know.
        out = features.generate(
            _cases("| TC1 | R9 | manual | S | G | W | T | not run |\n"),
            parse.parse_requirements(REQS),
        )
        self.assertIn("(not in requirements.md)", out["r9.feature"])

    def test_one_file_per_requirement(self):
        out = features.generate(
            _cases(
                "| TC1 | R1 | manual | A | G | W | T | not run |\n",
                "| TC2 | R1 | manual | B | G | W | T | not run |\n",
                "| TC3 | N1 | manual | C | G | W | T | not run |\n",
            ),
            parse.parse_requirements(REQS),
        )
        self.assertEqual(sorted(out), ["n1.feature", "r1.feature"])
        self.assertIn("Scenario: A", out["r1.feature"])
        self.assertIn("Scenario: B", out["r1.feature"])


class TestResultsCannotOverclaim(unittest.TestCase):
    """Every case here is a way a runner report could be read as a pass when
    nothing was proved."""

    def _report(self, tag, steps):
        return [{"uri": "f.feature", "name": "F", "elements": [
            {"name": "S", "tags": [{"name": "@" + tag}], "steps": steps}]}]

    def test_all_steps_passed_is_a_pass(self):
        found = features.results_from_report(
            self._report("TC1", [{"result": {"status": "passed"}}] * 3))
        self.assertEqual(found, {"TC1": "pass"})

    def test_any_failed_step_is_a_fail(self):
        found = features.results_from_report(self._report("TC1", [
            {"result": {"status": "passed"}}, {"result": {"status": "failed"}}]))
        self.assertEqual(found, {"TC1": "fail"})

    def test_an_undefined_step_is_not_run_rather_than_pass(self):
        # A step nobody implemented has proved nothing. Cucumber reports the
        # scenario without a failure, which is exactly how this reads as green
        # if you only look for "failed".
        found = features.results_from_report(
            self._report("TC1", [{"result": {"status": "undefined"}}]))
        self.assertEqual(found, {"TC1": "not run"})

    def test_an_empty_scenario_is_not_run_rather_than_pass(self):
        # An empty scenario trivially has no failing step. `all()` over an
        # empty list is True, so the naive implementation calls this a pass.
        found = features.results_from_report(self._report("TC1", []))
        self.assertEqual(found, {"TC1": "not run"})

    def test_a_scenario_without_a_case_tag_is_ignored(self):
        report = [{"uri": "f.feature", "name": "F", "elements": [
            {"name": "S", "tags": [{"name": "@smoke"}],
             "steps": [{"result": {"status": "passed"}}]}]}]
        self.assertEqual(features.results_from_report(report), {})


class TestOutlineRowsFoldByWorstVerdict(unittest.TestCase):
    """Cucumber emits one element per Scenario Outline example row, all
    carrying the outline's tags. Last-write-wins recorded `pass` for a run
    containing a failure — a genuinely failing test written into the
    engagement record as passing, which /conform then believed."""

    def _report(self, *statuses_per_element, tags=("@TC1",)):
        return [{"uri": "f.feature", "name": "F", "elements": [
            {"name": f"row{i}", "tags": [{"name": t} for t in tags],
             "steps": [{"result": {"status": st}}]}
            for i, st in enumerate(statuses_per_element)]}]

    def test_a_failing_row_survives_a_later_passing_row(self):
        self.assertEqual(
            features.results_from_report(self._report("failed", "passed")),
            {"TC1": "fail"})

    def test_the_answer_does_not_depend_on_row_order(self):
        # The defect was invisible in one direction: [passed, failed] already
        # reported fail. Only the reverse lied.
        a = features.results_from_report(self._report("failed", "passed"))
        b = features.results_from_report(self._report("passed", "failed"))
        self.assertEqual(a, b)

    def test_a_not_run_row_beats_a_passing_one(self):
        # An undefined step means nobody implemented it. A sibling row passing
        # does not make the unimplemented one verified.
        self.assertEqual(
            features.results_from_report(self._report("undefined", "passed")),
            {"TC1": "not run"})

    def test_all_passing_still_passes(self):
        self.assertEqual(
            features.results_from_report(self._report("passed", "passed")),
            {"TC1": "pass"})

    def test_every_tag_on_a_scenario_is_recorded(self):
        # A scenario tagged @TC1 @TC2 covers both. Taking only the first left
        # TC2 looking merely un-run rather than reported.
        found = features.results_from_report(
            self._report("failed", tags=("@TC1", "@TC2")))
        self.assertEqual(found, {"TC1": "fail", "TC2": "fail"})


class TestApplyingResults(unittest.TestCase):
    def test_only_reported_rows_are_touched(self):
        text = HEADER + (
            "| TC1 | R1 | automated | A | G | W | T | not run |\n"
            "| TC2 | R1 | manual | B | G | W | T | not run |\n"
        )
        updated, changed = features.apply_results(text, {"TC1": "pass"})
        self.assertEqual(changed, 1)
        parsed = parse.parse_test_cases(updated)
        by_id = {c.id: c for c in parsed.cases}
        self.assertEqual(by_id["TC1"].result, "pass")
        # A manual case the runner never mentioned keeps its own result. An
        # import must not quietly claim a person ran something.
        self.assertEqual(by_id["TC2"].result, "not run")

    def test_the_rewritten_file_still_parses(self):
        text = HEADER + "| TC1 | R1 | automated | A | G | W | T | not run |\n"
        updated, _ = features.apply_results(text, {"TC1": "fail"})
        parsed = parse.parse_test_cases(updated)
        self.assertEqual(parsed.problems, ())
        self.assertEqual(parsed.cases[0].result, "fail")
        self.assertEqual(parsed.cases[0].mode, "automated")

    def test_an_unknown_result_value_is_never_written(self):
        # apply_results writes whatever the mapper produced; the mapper is the
        # only thing that decides vocabulary. If these ever diverge the file
        # stops parsing, so pin that they agree.
        self.assertTrue(set(features._CUCUMBER_TO_RESULT.values())
                        <= parse.TEST_RESULTS)


class TestGeneratorRefusesBadInput(unittest.TestCase):
    def test_generate_refuses_a_file_with_unreadable_rows(self, ):
        import tempfile, shutil  # noqa: E401
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        root = Path(tmp)
        (root / "docs" / "engagement").mkdir(parents=True)
        # One good row, one with a bad mode.
        (root / "docs" / "engagement" / "test-cases.md").write_text(
            HEADER
            + "| TC1 | R1 | automated | A | G | W | T | not run |\n"
            + "| TC2 | R1 | sometimes | B | G | W | T | not run |\n"
        )
        # Generating anyway would produce a suite missing TC2 while looking
        # complete — the exact failure the refusal exists to prevent.
        self.assertEqual(features.main(["generate", "--root", str(root),
                                        "--out", str(root / "features")]), 1)
        self.assertFalse((root / "features").exists())


class TestMalformedReportsAreRefusedNotCrashed(unittest.TestCase):
    """`results_from_report` trusted the shape of every nested value.

    JSON validity is checked at load; SHAPE is not. Cucumber JSON is emitted
    by cucumber-js, behave, godog, karate and others, and a runner configured
    with the wrong formatter produces valid JSON of the wrong shape. That
    reached this function and raised AttributeError — a traceback tells the
    person nothing about which of those things to change.

    Refusing the whole report rather than skipping the bad parts is the same
    rule `generate` already follows: a partially-read report would write
    verdicts into the engagement record from a file we could not fully parse,
    and those verdicts are what /conform and the handoff then believe.
    """

    def _refuses(self, report):
        with self.assertRaises(ValueError) as caught:
            features.results_from_report(report)
        self.assertIn("report", str(caught.exception).lower())
        return str(caught.exception)

    def test_a_bare_scalar_is_refused(self):
        self._refuses(5)

    def test_a_non_list_features_value_is_refused(self):
        self._refuses({"features": "oops"})

    def test_a_feature_that_is_not_an_object_is_refused(self):
        self._refuses(["not a feature"])

    def test_a_non_list_elements_value_is_refused(self):
        self._refuses([{"uri": "f.feature", "elements": {}}])

    def test_an_element_that_is_not_an_object_is_refused(self):
        self._refuses([{"uri": "f.feature", "elements": ["nope"]}])

    def test_a_tag_that_is_not_an_object_is_refused(self):
        self._refuses([{"uri": "f.feature", "elements": [
            {"name": "S", "tags": ["@TC1"], "steps": []}]}])

    def test_a_step_that_is_not_an_object_is_refused(self):
        self._refuses([{"uri": "f.feature", "elements": [
            {"name": "S", "tags": [{"name": "@TC1"}], "steps": ["passed"]}]}])

    def test_the_message_names_the_offending_shape(self):
        # "Malformed report" alone sends someone to read 4000 lines of JSON.
        message = self._refuses({"features": "oops"})
        self.assertIn("features", message)

    def test_a_well_formed_report_is_unaffected(self):
        found = features.results_from_report([{"uri": "f.feature", "elements": [
            {"name": "S", "tags": [{"name": "@TC1"}],
             "steps": [{"result": {"status": "passed"}}]}]}])
        self.assertEqual(found, {"TC1": "pass"})

    def test_main_reports_a_malformed_report_without_a_traceback(self):
        import json, tempfile, shutil  # noqa: E401
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        root = Path(tmp)
        (root / "docs" / "engagement").mkdir(parents=True)
        (root / "docs" / "engagement" / "test-cases.md").write_text(
            HEADER + "| TC1 | R1 | automated | A | G | W | T | not run |\n")
        report = root / "r.json"
        report.write_text(json.dumps({"features": "oops"}))
        self.assertEqual(
            features.main(["results", "--root", str(root),
                           "--report", str(report)]), 1)


class TestOptionParsingDoesNotCrashOnATrailingFlag(unittest.TestCase):
    """`args[args.index(name) + 1]` raises IndexError when the flag is last.

    `--root` with no value is a typo anyone makes, and the answer to a typo is
    a sentence, not a stack trace.
    """

    def test_a_trailing_root_is_reported(self):
        self.assertEqual(features.main(["generate", "--root"]), 2)

    def test_a_trailing_report_is_reported(self):
        self.assertEqual(features.main(["results", "--report"]), 2)


if __name__ == "__main__":
    unittest.main()
