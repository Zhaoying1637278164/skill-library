# Sign-offs

| Gate | Artifact | Commit | Approved by | Date | Evidence |
|---|---|---|---|---|---|
| Requirements | requirements.md | a1b2c3d | R. Mensah, Ops Director | 2026-08-20 | https://example.invalid/1 |
| Design | design.md | b2c3d4e | R. Mensah, Ops Director | 2026-08-25 | https://example.invalid/2 |
