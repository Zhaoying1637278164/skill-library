# Range Roofing Portal plugin

Ask Claude, ChatGPT or Codex about your commercial roofs using the Range Roofing client portal: properties, roof sections, deficiencies, projects, warranties, invoices, budgets, weather alerts and uploaded documents. The plugin is read-only and returns only what your portal account can already see.

This repository is the plugin package. The MCP server it points at runs at `https://rangeroof-portal-mcp.onrender.com/mcp` and signs you in with your portal email and password over OAuth.

## Install

**ChatGPT / Codex** — add this repository as a marketplace, then install the plugin:

```
codex plugin marketplace add thebutler202510/rangeroof-portal-plugin
codex plugin install rangeroof-portal@rangeroof
```

In ChatGPT, open Settings → Apps & Connectors → Advanced → Developer mode, then add a marketplace with the same repository and install Range Roofing Portal from it.

**Claude Code:**

```
claude plugin marketplace add thebutler202510/rangeroof-portal-plugin
claude plugin install rangeroof-portal@rangeroof
```

**Claude (web / desktop):** Settings → Connectors → Add custom connector → `https://rangeroof-portal-mcp.onrender.com/mcp`.

## What is inside

| Path | Purpose |
|---|---|
| `plugin.json`, `mcp.json` | Portable Agent Plugins manifest and MCP declaration |
| `.codex-plugin/plugin.json`, `.mcp.json` | Codex / ChatGPT plugin manifest and MCP declaration |
| `.claude-plugin/plugin.json` | Claude Code plugin manifest |
| `.agents/plugins/marketplace.json`, `.claude-plugin/marketplace.json` | Marketplace catalogs so the repo can be added directly |
| `skills/` | Eight workflows: budget review, coverage check, portfolio briefing, warranty check, invoice review, roof life forecast, owner report, storm impact |
| `assets/` | Logo and composer icon |

## Skills

- **budget-review** — a defensible roofing budget for one property and fiscal year.
- **coverage-check** — test an uploaded insurance policy against open deficiencies, clause by clause, with the weather that could have caused them.
- **portfolio-briefing** — a one-page standing briefing: risk, work in flight, weather, expiring coverage, money owed.
- **warranty-check** — whether any warranty may cover a specific deficiency, from the warranty documents' own text.
- **invoice-review** — reconcile an invoice against the project record, change orders, reports and photos.
- **roof-life-forecast** — a multi-year replacement and major-repair forecast with a cost per year.
- **owner-report** — an owner-facing report for a period.
- **storm-impact** — which roofs a storm on a date could have damaged, and what has been found since.

Every skill tells the assistant to cite the document and page for anything it takes from a document, to use figures exactly as returned, and to end with a "What I could not determine" section.

## Documents

- Setup and usage: https://rangeroof-portal-mcp.onrender.com/docs
- Privacy policy: https://rangeroof-portal-mcp.onrender.com/privacy
- Terms: https://rangeroof-portal-mcp.onrender.com/terms
- Support: support@rangeroof.com
