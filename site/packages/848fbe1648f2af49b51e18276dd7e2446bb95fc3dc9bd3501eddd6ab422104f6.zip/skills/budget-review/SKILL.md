---
name: budget-review
description: Build a defensible roofing budget for one property and one fiscal year from its roof sections, open deficiencies, past spend and existing budget items. Use when someone asks what to budget for a roof, a property or next year.
---

# Budget review

Goal: recommend a roofing budget for the fiscal year the user names, at the property they name, with every line traced back to a roof section, a deficiency or a past cost. If the user names the property by address, find its id with `list_properties` first.

Call these Range Roofing Portal tools, in this order:

1. `get_property` — name, address and buildings, for context.
2. `get_roof_sections` — install year, planned replace year, condition score, square footage, replacement budget and open deficiency cost per section.
3. `list_deficiencies` with status `open` — the work already documented, with priority and estimated cost.
4. `get_capex_timeline` — the replacement years already planned.
5. `get_spend_by_year` — what this roof has actually cost, including the current year.
6. `list_budget_items` for the fiscal year — what is already budgeted, so nothing is double-counted.
7. `list_deferred_deficiencies` — what was deferred before, how long it has been open and what it has cost since.
8. `list_projects` — work in progress or recently finished that changes the picture.

Then produce:

- (a) a recommended budget table with one row per line item: section or deficiency, scope, cost, source;
- (b) a split between capital replacement and operating repair, stating the threshold used;
- (c) sections to watch in the following two years, with the age and score that put them there;
- (d) anything already budgeted that now looks wrong, and why.

Rules: cite the tool or document every figure came from; use figures exactly as returned; never invent a clause, figure, date, document or name; finish with a section headed "What I could not determine".
