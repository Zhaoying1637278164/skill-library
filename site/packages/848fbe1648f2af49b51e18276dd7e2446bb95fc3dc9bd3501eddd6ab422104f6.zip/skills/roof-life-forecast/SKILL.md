---
name: roof-life-forecast
description: Forecast the next several years of roof replacement and major repair across one property or a whole portfolio, ranked by urgency with a cost per year. Use when someone asks how long roofs will last, when to replace, or for a multi-year capital plan.
---

# Roof life forecast

Goal: forecast the next N years (default 5) of roof replacement and major repair across the property or portfolio the user names, ranked by urgency, with a cost for each year.

Call these Range Roofing Portal tools, in this order:

1. `list_properties` — the scope, with building counts.
2. `get_roof_sections` for each property — install year, planned replace year, condition score, square footage and replacement budget.
3. `list_deficiencies` with status `open` — where accumulated defects shorten the section's remaining life.
4. `list_service_tickets` — repeat leaks on the same section are the strongest signal of end of life.
5. `get_capex_timeline` — the replacement years already planned.
6. `get_financial_summary` and `list_budget_items` — what is funded already.

Then produce: a year-by-year table of sections due for replacement or major repair, with the reason (age, score, deficiencies, leaks) and cost; the total per year; the sections most likely to move earlier and why; and what is already budgeted against each year.

Rules: use figures exactly as returned and name the tool each came from; never invent a year or cost; finish with a section headed "What I could not determine".
