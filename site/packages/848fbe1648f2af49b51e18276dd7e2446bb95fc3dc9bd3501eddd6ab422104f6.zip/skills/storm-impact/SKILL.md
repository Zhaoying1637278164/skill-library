---
name: storm-impact
description: Assess which properties a storm on a given date could have damaged, and what has been found or done at them since. Use when someone asks about hail, wind or a storm date and their roofs.
---

# Storm impact

Goal: work out which roofs the weather of the date the user names could have damaged, and whether anything was found or done afterwards.

Call these Range Roofing Portal tools, in this order:

1. `list_weather_alerts` with `days_back` large enough to reach the date (maximum 730). Keep only alerts whose window contains or touches the date; record each alert's type, severity and dates.
2. `list_properties` with limit 200 — to name the properties the alerts sit over.
3. `list_deficiencies` with status `open` for each affected property — anything raised on or after the date is the strongest evidence of impact, so note the dates.
4. `get_roof_sections` for each affected property — an old or low-scoring section is the one a storm finds first.
5. `list_service_tickets` for each affected property — leaks reported since the date.
6. `list_projects` for each affected property — repairs started since the date.
7. `get_property_history` for the worst affected — the sequence of events.

Then produce: the alerts that matched, with dates and severity; the properties under them, ranked by exposure (section age and score); what was found afterwards at each, with dates; what was done; and which properties have had no inspection since the event and should be looked at.

Rules: use dates and figures exactly as returned; never invent an event; finish with a section headed "What I could not determine".
