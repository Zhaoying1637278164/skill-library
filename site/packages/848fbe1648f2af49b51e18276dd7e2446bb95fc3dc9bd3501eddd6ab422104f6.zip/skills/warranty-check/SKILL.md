---
name: warranty-check
description: Decide whether any warranty on a property may cover a specific deficiency or leak, from the warranty records and the warranty documents' own text. Use when someone asks if something is under warranty or what a warranty excludes.
---

# Warranty check

Goal: decide whether any warranty on the property may cover the deficiency or problem the user describes. Say "likely covered", "likely excluded" or "unclear". The manufacturer or contractor decides, not you.

Call these Range Roofing Portal tools, in this order:

1. `list_deficiencies` — locate the deficiency, its roof section and the date it was raised.
2. `get_roof_sections` — the section's install year and system, which decides which warranty applies.
3. `list_warranties` — every warranty on the property: type, start and end dates, coverage and the section or building it names.
4. `list_documents` filtered to warranties, then `get_document_text` for each candidate — read the term, the covered items and the exclusions; page through when `truncated` is true.
5. `search_documents` scoped to the property for "exclusion", "wind", "ponding", "workmanship", "notice", "transfer" — to find the deciding clauses with page numbers.

Then answer: which warranty applies and why; whether it is still in term, with the dates; the clause that covers or excludes the problem, with document title and page; the notice or claim procedure it requires; and what would void it.

Rules: cite document title and page; use dates and figures exactly as returned; never invent a clause; finish with a section headed "What I could not determine".
