---
name: owner-report
description: Write an owner-facing report on a property or portfolio for a period - work done, money spent, open issues, weather, and what is coming. Use when someone asks for a quarterly, annual or board report on their roofs.
---

# Owner report

Goal: write an owner-facing report on the property or portfolio the user names, for the period they name. Convert the period into explicit from and to dates (YYYY-MM-DD) before calling anything, and state those dates at the top of the report.

Call these Range Roofing Portal tools, in this order:

1. `list_properties` — the scope.
2. `get_property_history` for each property, limited to the period — inspections, work, tickets and alerts in order.
3. `get_financial_summary` and `get_spend_by_year` — spend in the period and replacement value.
4. `list_projects` — work completed or in progress in the period, with dates.
5. `list_deficiencies` — what is open at period end, with cost.
6. `list_invoices` for the period — what was billed.
7. `list_weather_alerts` covering the period — what the weather did.
8. `list_upcoming_events` — what is scheduled next.

Then write, in plain language for an owner: a summary paragraph; work completed with dates and cost; spend versus the prior period where the data allows; open issues ranked by cost; weather events and their effect; what is scheduled in the next 90 days; and recommended decisions.

Rules: use figures exactly as returned; give dates for everything that happened; never invent; finish with a section headed "What I could not determine".
