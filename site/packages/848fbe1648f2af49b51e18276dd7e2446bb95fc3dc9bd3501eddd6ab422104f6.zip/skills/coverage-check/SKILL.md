---
name: coverage-check
description: Test an insurance policy held in the portal against the open deficiencies at one property, clause by clause, with the weather events that could have caused them. Use when someone asks whether damage or a deficiency might be covered.
---

# Coverage check

Goal: determine whether a policy document may cover any open deficiency at a property. You are reading a policy, not deciding a claim. Say "likely covered", "likely excluded" or "unclear", never "covered".

Find the property with `list_properties` and the policy with `list_documents` or `search_documents` if the user has not given ids.

Call these Range Roofing Portal tools, in this order:

1. `get_property` — address, buildings and roof sections, for context.
2. `list_deficiencies` with status `open` — the items to test, with priority, estimated cost and the section each sits on.
3. `list_documents` — confirm the policy row and its document type.
4. `get_document_text` for the policy — page through with `page_from` and `page_to` whenever the response reports `truncated: true`.
5. `search_documents` scoped to the property, once each for "exclusion", "hail", "wind", "wear and tear", "deductible", "roof", "notice of loss" — to land on the clauses directly and get their page numbers.
6. `list_weather_alerts` with `days_back` 730 — the hail and wind events that could be the cause.
7. `list_projects` and `get_property_history` — prior repairs, which an insurer will read as either maintenance or a prior claim.

Then, for each open deficiency, state likely covered / likely excluded / unclear, and give the policy clause that decides it with its page number, and the weather event that supports it with its date. Close with the deductible, the notice deadline and any proof-of-loss requirement found, each with a page number.

Rules: cite document title and page for anything taken from a document; use figures exactly as returned; never invent a clause, figure, date, document or name; finish with a section headed "What I could not determine". This is not legal or insurance advice.
