---
name: invoice-review
description: Judge whether an invoice matches the work the portal has a record of - the project, its progress reports, change orders, photos and any service agreement - and list what does not reconcile. Use when someone asks to check, review or explain an invoice.
---

# Invoice review

Goal: judge whether the invoice the user names matches the work the portal has a record of, and list anything that does not reconcile. Find the invoice with `list_invoices` if the user gives a number rather than an id.

Call these Range Roofing Portal tools, in this order:

1. `get_invoice_context` — the invoice, its property, the project it bills, change orders and progress reports.
2. `get_document_text` for the invoice document — the line items, quantities and amounts as written.
3. `get_project` — scope, milestones, work days and signed documents.
4. `list_service_agreements` — whether the work falls under an agreement with fixed pricing or included services.
5. `get_inspection_photos` — before and after photos that evidence the work.

Then produce: a line-by-line reconciliation table (invoice line, matching record, match / mismatch / unverified); totals compared; change orders billed without a signed record; work billed with no progress report or photo; and a short list of questions to put to Range Roofing before paying.

Rules: cite document title and page for anything from a document; use amounts exactly as returned; never invent; finish with a section headed "What I could not determine".
