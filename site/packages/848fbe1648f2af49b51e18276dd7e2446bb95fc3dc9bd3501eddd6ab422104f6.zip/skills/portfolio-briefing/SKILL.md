---
name: portfolio-briefing
description: A one-page standing briefing on a whole roofing portfolio - open risk, work in flight, weather, expiring coverage and money owed. Use when someone asks for a status update, a summary of their properties, or what needs attention this month.
---

# Portfolio briefing

Goal: brief the reader on the current state of their portfolio: what is at risk, what is being done about it, and what needs a decision this month. Range staff may name a company; client users get their own.

Call these Range Roofing Portal tools, in this order:

1. `whoami` — confirm whose portfolio this is and whether the account sees one company or all of them.
2. `list_properties` with limit 200 — the portfolio, with building counts and open deficiency counts and costs.
3. `list_deficiencies` with status `open` for each property, worst first by open deficiency cost; stop after the top ten properties and say so.
4. `list_projects` — work in progress, with stage and dates.
5. `list_weather_alerts` with `days_back` 30 — active and recent alerts, and which properties they sit over.
6. `list_warranties` and `list_service_agreements` — flag anything expiring inside the next 90 days.
7. `list_invoices` from 90 days ago — recent billing and anything outstanding.

Then write: (a) a three-sentence headline; (b) the top risks ranked by open cost, each naming its property and the date the deficiency was raised; (c) work in flight with expected dates; (d) coverage expiring within 90 days with exact expiry dates; (e) billing to note; (f) the three decisions to put in front of the reader this month.

Rules: use figures exactly as returned and name the tool each came from; give a date for anything that happened; never invent; finish with a section headed "What I could not determine".
