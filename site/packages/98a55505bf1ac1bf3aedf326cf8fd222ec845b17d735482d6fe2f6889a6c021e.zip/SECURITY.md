# Security

Do not include credentials, OAuth tokens, customer data, email exports, or production logs in bug reports.

For connection help, use https://help.slashy.com. Security reports should be sent through the security contact published on Slashy's website or privacy documentation.

When reporting an MCP issue, include the host, approximate timestamp, tool name, and sanitized error message. Remove email addresses, message bodies, calendar details, attachments, and authentication values.
