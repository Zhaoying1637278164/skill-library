# Disclaimer

This skill (`claude-blog-assistant`) is an independent open-source orchestrator that wraps the `AgriciDaniel/claude-blog` plugin. **It is not affiliated with, endorsed by, or sponsored by Agrici Daniel, the claude-blog plugin maintainers, AgriciDaniel's other plugins (`claude-seo`, etc.), or any related entity.**

## What this skill is

This skill is a conductor layer that orchestrates publicly available sub-skills from `AgriciDaniel/claude-blog` into an opinionated 8-step blog publishing lifecycle (Mode 1) and a retroactive post-quality audit (Mode 2). The skill does not redistribute, copy, or modify `claude-blog`'s source code. It requires `claude-blog` installed alongside as a hard dependency.

## Frameworks and attribution

The 8-step lifecycle synthesizes mainstream blog publishing best practices from multiple sources (HubSpot, Google SEO Starter Guide, Surfer SEO, Clearscope, etc.). No single framework is the proprietary source.

The Mode 2 scoring rubric uses the 5-category 100-point system from `claude-blog:blog-analyze`. This rubric is the work of the `claude-blog` plugin author (Agrici Daniel), not the author of this skill. Cited descriptively under nominative fair use.

The `humanizer` skill (`https://github.com/blader/humanizer`) is referenced as an optional dependency. The humanizer's pattern catalog (29 AI-writing patterns) is based on the Wikipedia "Signs of AI writing" page maintained by WikiProject AI Cleanup. The humanizer skill author (blader) holds the skill's MIT license; the underlying pattern catalog is public-domain Wikipedia content.

## Trademarks

The following are referenced descriptively only:

- `AgriciDaniel/claude-blog` (the plugin name, GitHub username)
- `blader/humanizer` (the skill name, GitHub username)
- `Anthropic`, `Claude`, `Claude Code` (Anthropic's products and platform)
- `OpenCode` (the open-source CLI that also runs Claude skills)
- Surfer SEO, Clearscope, Ahrefs, HubSpot, SEMrush (third-party content-audit tools cited as references)

This skill does not use any of these marks as branding, product names, or logos. References are descriptive.

## Limitation of liability

This skill is provided "as is" under the MIT License. The skill author makes no warranty as to:

- The accuracy of the framework definitions, sub-skill names, or platform character limits cited (these change over time; users should verify against current sources)
- Fitness for a particular purpose
- Commercial outcomes from applying the skill's audit recommendations or lifecycle gates
- Compatibility with future versions of `claude-blog`, `humanizer`, or Claude Code itself

**The skill author is not a legal advisor and the contents of this skill do not constitute legal advice.** If you intend to commercialize work derived from this skill (sell content audit services, sell consulting based on the 8-step lifecycle, etc.), consult independent legal counsel about appropriate use and attribution.

## Sub-skill name accuracy

This skill references `claude-blog` sub-skills by their exact name (verified against the plugin source at the time of publication). Sub-skill names may change over time. If a sub-skill invocation fails, the most likely cause is a name drift in upstream `claude-blog`. Open an issue on this skill's GitHub repo if you find a name drift; pull requests welcome.

## Reporting concerns

If you are an authorized representative of `AgriciDaniel/claude-blog`, `blader/humanizer`, or any third-party tool referenced in this skill, and you have concerns about how this skill references your work, open an issue on the skill's GitHub repository or contact the skill author through the contact methods listed in the README. The skill author will respond and adjust attribution, naming, or content in good faith.
