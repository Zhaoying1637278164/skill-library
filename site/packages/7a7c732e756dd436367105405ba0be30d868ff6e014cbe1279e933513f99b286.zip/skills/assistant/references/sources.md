# Sources & Attribution

This skill orchestrates publicly available sub-skills from the `AgriciDaniel/claude-blog` plugin. The orchestrator codifies an 8-step lifecycle that synthesizes mainstream blog publishing best practices from multiple sources. Frameworks and methodologies cited descriptively under nominative fair use where applicable.

## Required dependency (the orchestrator wraps this)

- **`AgriciDaniel/claude-blog`** — `https://github.com/AgriciDaniel/claude-blog`. MIT license. 28 sub-skills. This skill is a hard dependency; install `claude-blog` before installing this orchestrator.

## Optional dependency

- **`blader/humanizer`** — `https://github.com/blader/humanizer`. MIT license. Used in Step 3 (humanize). Optional; if absent, Step 3 is labeled "no humanizer pass ran" and the lifecycle continues.

## Verified online sources

All URLs below were fetched and confirmed accessible during preparation of this skill. URLs change over time; if a link 404s, fall back to the framework descriptions in this `/references/` folder.

### Plugin and skill ecosystem

| URL | What's there | Verified |
| --- | ------------ | -------- |
| `https://github.com/AgriciDaniel/claude-blog` | Plugin source, 28 sub-skills, MIT license. | 2026-05-11 |
| `https://github.com/blader/humanizer` | Humanizer skill source, MIT license. | 2026-05-11 |

### Blog publishing lifecycle references

| URL | What's there | Verified |
| --- | ------------ | -------- |
| `https://developers.google.com/search/docs/fundamentals/seo-starter-guide` | Google's official on-page SEO baseline. Source of truth for title / meta / heading patterns. | 2026-05-11 |
| `https://developers.google.com/search/docs/appearance/structured-data/article` | Google's Article structured data documentation. Source of truth for `Article` / `BlogPosting` schema. | 2026-05-11 |
| `https://schema.org/BlogPosting` | Schema.org canonical `BlogPosting` definition. | 2026-05-11 |
| `https://blog.hubspot.com/marketing/how-to-start-a-blog` | HubSpot's 9-step setup + 18-step writing process (mainstream publishing reference). | 2026-05-11 |

### Content audit / scoring methodology references

| URL | What's there | Verified |
| --- | ------------ | -------- |
| `https://docs.surferseo.com/en/articles/9463956-content-score-in-content-audit-explained` | Surfer SEO Content Audit scoring methodology. Reference for Mode 2 scoring approaches. | 2026-05-11 |
| `https://www.clearscope.io/support/how-does-clearscope-grade-your-content` | Clearscope grading dimensions (Term Coverage, Importance Scoring, AI Term Presence, Typical Usage). | 2026-05-11 |

### Platform character limit references

| URL | What's there | Verified |
| --- | ------------ | -------- |
| `https://authoredup.com/blog/linkedin-character-limit` | LinkedIn 2026 character limit data + 372k-post engagement-window study. | 2026-05-11 |

## URLs explicitly NOT used (verified broken or wrong)

| URL | Why not used | Verified |
| --- | ------------ | -------- |
| `https://backlinko.com/hub/seo/on-page` | 404 Not Found. Working alternative is `https://backlinko.com/on-page-seo` if Backlinko is desired. | 2026-05-11 |

## Caveats and labeled-uncertain claims

The following claims appear in this skill's lifecycle or platform-specs reference. They are labeled as community-popular practices, NOT officially confirmed:

| Claim | Status |
| ----- | ------ |
| "LinkedIn link in first comment lifts reach via 360Brew penalty avoidance" | Unverified. AuthoredUp's 372k-post study confirms character-cap data but does NOT confirm the comment-link penalty as fact. The 360Brew feed-ranker mechanism is not officially documented by LinkedIn. Treat as soft recommendation, not gospel. |
| "Tuesday-Thursday 7-8 AM / 12 PM is the optimal LinkedIn posting time" | Community observation based on multiple engagement-time analyses. Not officially confirmed by LinkedIn. |
| "1-2 niche hashtags outperform generic hashtags on X" | Unverified by X officially; evidence-based across multiple practitioner analyses. |
| "Threads tone rewards personal voice over insight density" | Community observation, not officially confirmed by Meta. |

If a user asks for justification of any of these claims, label them as community practice and link the strongest available evidence.

## Frameworks (attribution)

The 8-step lifecycle in this skill synthesizes mainstream blog publishing best practices. No single framework is the source. Attribution by step:

| Step | Source attribution |
| ---- | ------------------ |
| 1. Brief | Synthesized from HubSpot, Ahrefs, Surfer briefing patterns. |
| 2. Draft | Synthesized from claude-blog plugin (`blog-write`) + mainstream answer-first formatting conventions. |
| 3. Humanize | Synthesized from the `humanizer` skill's pattern catalog (based on Wikipedia "Signs of AI writing"). |
| 4. SEO check | Synthesized from Google's SEO Starter Guide + claude-blog plugin (`blog-seo-check`). |
| 5. Schema | Synthesized from Google's Article structured data documentation + schema.org canonical definitions. |
| 6. Analyze | Wraps the `claude-blog:blog-analyze` 5-category 100-point rubric directly. |
| 7. Repurpose | Synthesized from platform-specific character limits and community-popular practices. See `references/repurpose-platform-specs.md`. |
| 8. Final QA | Synthesized from mainstream pre-publish QA patterns (HubSpot, Ahrefs). |

## Reporting issues

If a framework is misrepresented or a URL has gone stale, open an issue on the skill's GitHub repo. Pull requests welcome.
