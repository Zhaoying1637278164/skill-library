# The 8-Step Blog Publishing Lifecycle

> Reference card for the lifecycle this skill enforces in Mode 1 (Ship new post) and audits in Mode 2 (Score existing post).

## Why 8 steps

Mainstream blog publishing guides (HubSpot, Ahrefs, Backlinko, Search Engine Journal) describe publishing as 5 phases: plan → structure → write → optimize → promote. This skill expands that into 8 steps to surface gates that mainstream guides leave implicit:

- **Humanize** is broken out as a named step because AI-detection tools and Google's helpful-content updates (2024-2026) made voice cleanup a load-bearing gate.
- **Schema (JSON-LD)** is broken out because AI search citation pressure (Google AI Overviews, ChatGPT browsing, Perplexity) now rewards structured data more than classical SEO did.
- **Final QA** is broken out because the analyze step is automated scoring; QA is the human read-through.

## The 8 steps

### Step 1: Brief

Define the post before drafting:
- Topic angle (what's the one thing this post is about?)
- Target audience (vertical, role, sophistication)
- Primary keyword (real SERP data, not intuition)
- 3-5 secondary keywords
- Buyer's question this post answers (the search intent)
- Outline (H2 structure with one-line description per H2)
- Sources (where receipts will come from)
- Internal linking zones (which existing posts will link here / be linked from)

**Sub-skill:** `claude-blog:blog-brief` writes the brief to a markdown file. Brief MD location is the user's choice; common pattern is `<your-content-folder>/blog-briefs/<slug>-brief.md`.

**Gate:** the user reviews and approves the brief before any drafting begins. No silent skip.

### Step 2: Draft

Generate the post from the approved brief:
- Answer-first formatting (TL;DR or definition sentence in the first 100 words)
- Key Takeaways box near the top
- Citation capsules (year anchor + inline citation + retrieval date)
- FAQ section where applicable
- Internal linking zones populated
- H1 + H2/H3 hierarchical, descriptive

**Sub-skill:** `claude-blog:blog-write` produces the draft using the brief as input.

### Step 3: Humanize

Voice cleanup pass:
- Strip AI-vocabulary tells (delve, leverage, seamless, intricate, robust, ensure, furthermore, moreover, holistic, paradigm, synergy, vibrant, tapestry, testament, pivotal, crucial)
- Remove em-dash overuse (replace with commas, colons, periods, parentheses)
- Kill rule-of-three padding (force 2 or 1 if the third item doesn't carry weight)
- Drop sycophantic / sales-deck tone
- Replace vague attributions with named sources
- Vary sentence length (mix short with long)

**Sub-skill:** `humanizer` (`https://github.com/blader/humanizer`). Optional dependency. If not installed, this step is labeled "no humanizer pass ran" and the lifecycle continues.

### Step 4: SEO check (on-page)

Validate the post for classical on-page SEO + AEO/GEO:
- Title: 50-60 chars, unique, target keyword near front
- Meta description: <160 chars, unique, target keyword included
- H1 single, H2/H3 hierarchical, descriptive
- Internal links with descriptive anchor text
- Image alt text on every image
- Passage-level citability (any 1-2 sentence excerpt stands alone as a complete answer)
- Named entities anchored early (brand, person, key concepts in the first 200 words)

**Sub-skill:** `claude-blog:blog-seo-check`. Blog-native, tightly coupled to `blog-write` output.

### Step 5: Schema (JSON-LD)

Generate structured data so search engines and AI search engines can ingest the post correctly:
- `Article` or `BlogPosting` always (with `author`, `datePublished`, `dateModified`, `headline`, `image`)
- `BreadcrumbList` always
- `FAQPage` if the post has a "Frequently Asked Questions" h2 with 2+ Q/A pairs

**Sub-skill:** `claude-blog:blog-schema` generates the JSON-LD inline or as a separate file ready for injection into the post's `<head>` or rendering layer.

### Step 6: Analyze (mandatory)

End-of-pipeline check. Returns a 5-category 100-point score:
- Content quality: 30 points
- SEO: 25 points
- E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness): 15 points
- Technical (heading hierarchy, schema, internal links, alt text): 15 points
- AI citation readiness: 15 points

**Sub-skill:** `claude-blog:blog-analyze`. NON-NEGOTIABLE. Never skip silently. If running is expensive or slow, ask the user, do not skip.

### Step 7: Repurpose (optional, on request)

Generate platform-specific drafts for LinkedIn, X (Twitter), Threads, email, YouTube description, etc. Only invoke if the user wants repurpose drafts.

**Sub-skill:** `claude-blog:blog-repurpose`. See `references/repurpose-platform-specs.md` for platform character limits and community-popular practices.

### Step 8: Final QA

Short human read-through:
- All artifacts present (draft, schema, repurpose drafts if requested)
- Final read for tone, claim integrity, CTA placement
- Verify all links resolve
- Verify all named sources are real and cited correctly

This step is not a sub-skill; it's a human-in-the-loop check.

## Cross-reference

- For framework definitions of each sub-skill, see the `AgriciDaniel/claude-blog` plugin source: `https://github.com/AgriciDaniel/claude-blog`.
- For Mode 2 (score existing post) scoring rubric, see `references/mode-2-audit-rubric.md`.
- For repurpose platform specs, see `references/repurpose-platform-specs.md`.
