# Mode 2 Audit Rubric — Score Existing Post

> Reference card for the scoring rubric used in Mode 2 (Score existing post). The rubric aligns with `claude-blog:blog-analyze` rather than inventing a new one.

## Why align with `claude-blog:blog-analyze`

The `AgriciDaniel/claude-blog` plugin already ships a 5-category 100-point scoring rubric in its `blog-analyze` sub-skill. The orchestrator wraps that scoring rather than reinventing one. Three benefits:

1. **Consistency.** A user running Mode 1 (ship) and Mode 2 (score) sees the same score format. The Step 6 analyze in Mode 1 and the Mode 2 audit produce comparable outputs.
2. **No drift.** When `blog-analyze` updates its rubric, this skill picks up the change automatically.
3. **Less surface area.** Fewer rubrics to document, debug, and explain.

## The 5-category 100-point rubric

| Category | Points | What's scored |
| -------- | ------ | ------------- |
| Content quality | 30 | Depth, originality, specificity, claim-evidence balance, audience fit, answer-first formatting. |
| SEO | 25 | Title, meta description, H1/H2 hierarchy, keyword placement, internal links, anchor text. |
| E-E-A-T | 15 | Experience signals, expertise signals, authoritativeness signals (named sources, citations), trustworthiness signals (about page link, named author, contact info). |
| Technical | 15 | Schema presence, alt text coverage, heading hierarchy correctness, page metadata, mobile rendering. |
| AI citation readiness | 15 | Passage-level citability, named entity anchoring, definition sentences, stat capsules with sources. |

Total: 100 points.

## Lifecycle compliance overlay

In addition to the 100-point score, Mode 2 outputs a per-step lifecycle compliance check:

| Step | What to check on a published post |
| ---- | --------------------------------- |
| 1. Brief | Inferred from the post's coherence. Does the post have one clear angle and one clear primary keyword? PRESENT / WEAK / MISSING. |
| 2. Draft quality | Per-attribute: answer-first formatting present? Key Takeaways box present? Citation capsules present? FAQ section where applicable? |
| 3. Humanizer pass | Scan for AI-tells: em dashes, AI vocab words, rule-of-three padding, sycophantic tone, vague attributions. PRESENT / MISSING / UNKNOWN. |
| 4. SEO check | Title length, meta description length, H1/H2 hierarchy, internal link count, alt text coverage. |
| 5. Schema (JSON-LD) | Fetch page source if URL provided. Check for Article / BlogPosting, BreadcrumbList, FAQPage. PRESENT / MISSING / partial. |
| 6. Analyze score | The 100-point score from above. |
| 7. Repurpose drafts | Out of scope for public-post audit (drafts live in author workspace). Mark N/A. |
| 8. Final QA notes | Manual flags: broken claims, dead links, missing CTAs, mismatched tone. |

## Output format

```
Mode 2 — Score existing post

Input: <URL or pasted post text>

Score (claude-blog:blog-analyze rubric):
  Content quality:    X / 30
  SEO:                X / 25
  E-E-A-T:            X / 15
  Technical:          X / 15
  AI citation:        X / 15
  Total:              X / 100

Lifecycle compliance:
  1. Brief evidence:       PRESENT / WEAK / MISSING
  2. Draft quality:        per-attribute scores
  3. Humanizer pass:       PRESENT / MISSING / UNKNOWN
  4. SEO check signals:    title / meta / H1-H2 / internal links / alt text per-item
  5. Schema (JSON-LD):     PRESENT / MISSING / partial
  6. Analyze score:        X / 100 (matches above)
  7. Repurpose drafts:     N/A
  8. Final QA notes:       freeform flags

Top retrofit list (prioritized by impact-to-effort ratio):
  1. <highest-leverage fix> — which category it targets, before/after, expected lift
  2. <next fix>
  3. <next fix>
```

## Retrofit list selection logic

Always output 3-5 retrofit recommendations, ranked by impact-to-effort.

### Selection rules

1. At least one fix targets the lowest-scoring category.
2. At least one fix targets a MISSING lifecycle step (if any are MISSING).
3. Fixes that cost minutes to apply (meta description rewrite, alt text addition, schema injection) rank ahead of fixes that cost hours (rewriting the whole post for E-E-A-T signals).
4. Each fix cites the specific line(s) or section(s) of the post to change, with a before/after example using the post's actual copy.

### What NEVER to do

- Fabricate the post's actual copy. If you don't have the actual text, ask the user to paste it before producing before/after examples.
- Recommend fabricated stats or named entities in fixes. If a fix says "add a case study here," recommend the user supply real numbers, do not invent them.
- Use the audit output to recommend deletion of the post unless lifecycle compliance is < 30 / 100 AND the post has zero traffic. Otherwise prefer retrofit over delete.

## Cross-reference

- 8-step lifecycle definition: `references/8-step-lifecycle.md`
- Sub-skill map: `references/sub-skill-map.md`
- Sources: `references/sources.md`
