# Repurpose Platform Specs

> Reference card for the platform-specific specs used in Step 7 (Repurpose). Character limits and community-popular practices, with verification status on each claim.

## LinkedIn

| Spec | Value | Verified |
| ---- | ----- | -------- |
| Hard post body cap | 3,000 characters | Verified via AuthoredUp 2024 study + LinkedIn official docs. |
| "See more" mobile fold | ~140 characters | Verified via AuthoredUp study. The hook must work above this fold. |
| Engagement sweet spot | 1,301-2,500 characters | Verified via AuthoredUp 372k-post study (2024). |
| Maximum hashtags | No hard cap, but 2-3 is the community-popular convention | Community lore, not officially confirmed. |
| Link in first comment | Popular practice among practitioners; many report it lifts reach | NOT officially confirmed by LinkedIn. The mechanism is rumored to be a body-link penalty in the 360Brew feed-ranker; this remains unverified. Treat as a soft recommendation, not gospel. |
| Bold formatting | LinkedIn renders `**bold**` on paste from Markdown | Verified via direct testing. |
| Emoji support | Yes, but emojis in the first 140 chars can affect distribution | Community observation, not officially confirmed. |
| Posting time | Tuesday-Thursday, 7-8 AM or 12 PM audience local time | Community-popular convention based on engagement-time analyses (multiple sources). |

**Source:** `https://authoredup.com/blog/linkedin-character-limit` (verified live, 372k-post study).

## X (Twitter)

| Spec | Value | Verified |
| ---- | ----- | -------- |
| Free account tweet | 280 characters per tweet | Verified, official X documentation. |
| Premium long-form | 25,000 characters (Premium subscribers) | Verified, official X documentation. |
| Threading | Multi-tweet threads supported; each tweet is its own 280-char unit | Verified. |
| Engagement window | First 30 minutes after posting drive most reach | Community observation, varies by audience. |
| Hashtags | 1-2 niche hashtags outperform generic ones (#AI, #Marketing) | Community lore, evidence-based but not officially confirmed. |
| Media attachments | Up to 4 images per tweet OR 1 video | Verified, official X documentation. |

## Threads

| Spec | Value | Verified |
| ---- | ----- | -------- |
| Main post body | 500 characters | Verified, official Threads / Meta documentation. |
| Text attachments | Up to 10,000 characters per attachment | Verified, shipped September 2025. |
| Posting time | 8-10 AM or 6-8 PM audience local time | Community observation, not officially confirmed. |
| Tone | Conversational; rewards personal voice over insight density | Community observation. |

## Email (newsletter / broadcast)

| Spec | Value | Verified |
| ---- | ----- | -------- |
| Subject line | 30-50 characters for desktop preview; 30 chars max for mobile preview | Community-popular convention. |
| Preheader | 40-90 characters; complements subject line | Community-popular convention. |
| Body length | Highly platform-dependent (Substack vs Beehiiv vs Mailchimp differ) | No single canonical answer. |
| Plain-text vs HTML | Plain text often higher engagement; HTML supports branding | Trade-off, depends on audience. |

## YouTube description

| Spec | Value | Verified |
| ---- | ----- | -------- |
| Hard cap | 5,000 characters | Verified, official YouTube documentation. |
| First 100-150 chars | Visible above the fold; treat as the hook | Verified. |
| Timestamps | Drive YouTube's chapter feature when formatted correctly | Verified. |
| Links | Allowed; first link is the primary CTA | Verified. |

## How to use this card in Step 7

When `claude-blog:blog-repurpose` generates platform drafts, verify each draft against the specs above. Common failure modes:

- LinkedIn draft over 3,000 chars (hard cap violation)
- X tweets over 280 chars (per-tweet basis)
- Threads post over 500 chars
- LinkedIn hook below the 140-char "see more" fold
- LinkedIn body containing a bare link (many practitioners report this penalizes reach; recommend moving to first comment)

Per-platform claims that are unverified or not officially confirmed by the platform should be labeled as such in the audit output if the user asks for justification. Do not assert them as fact.

## Cross-reference

- 8-step lifecycle: `references/8-step-lifecycle.md`
- Sub-skill map: `references/sub-skill-map.md`
- Sources: `references/sources.md`
