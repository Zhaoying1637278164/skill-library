# Sub-Skill Map — `AgriciDaniel/claude-blog`

> Reference card for which `claude-blog` sub-skills this orchestrator invokes, plus the broader sub-skill catalog for advanced workflows.

## Core sub-skills used in the 8-step lifecycle

| Sub-skill | When invoked | What it does |
| --------- | ------------ | ------------ |
| `claude-blog:blog-brief` | Step 1 | Generates a content brief (topic angle, audience, keyword target, outline, sources). |
| `claude-blog:blog-write` | Step 2 | Writes the draft from the approved brief. Answer-first formatting, Key Takeaways box, citation capsules, FAQ section. |
| `claude-blog:blog-seo-check` | Step 4 | On-page SEO validation: title, meta, H1/H2 hierarchy, internal links, alt text, passage-level citability. |
| `claude-blog:blog-schema` | Step 5 | Generates JSON-LD: Article / BlogPosting, BreadcrumbList, FAQPage where applicable. |
| `claude-blog:blog-analyze` | Step 6 | End-of-pipeline scoring: 5-category 100-point rubric (Content 30 / SEO 25 / E-E-A-T 15 / Technical 15 / AI citation 15). |
| `claude-blog:blog-repurpose` | Step 7 (optional) | Generates platform drafts for LinkedIn, X, Threads, email, YouTube description, etc. |

## Other sub-skills in the plugin (advanced workflows)

The `AgriciDaniel/claude-blog` plugin includes 28 sub-skills. This orchestrator uses 6. Others worth knowing about for advanced workflows:

| Sub-skill | Use case |
| --------- | -------- |
| `blog-rewrite` | Rewrite an existing post (for refresh, retrofit, or tone change). |
| `blog-outline` | Standalone outline generator (when the brief is already done elsewhere). |
| `blog-geo` | GEO (Generative Engine Optimization) check — passage citability for AI search engines. |
| `blog-factcheck` | Fact-check claims in a draft against source material. |
| `blog-persona` | Persona alignment check (does the draft speak to the named persona?). |
| `blog-cluster` | Cluster / pillar architecture analysis (how does this post fit a content cluster?). |
| `blog-cannibalization` | Detect keyword cannibalization across existing posts. |
| `blog-strategy` | High-level content strategy questions. |
| `blog-calendar` | Editorial calendar generation. |
| `blog-image` | Image prompt generation or alt text. |
| `blog-chart` | Chart generation for data-driven posts. |
| `blog-flow` | Reading-flow check (heading transitions, paragraph rhythm). |
| `blog-multilingual` / `blog-translate` / `blog-localize` | Multi-language and localization. |
| `blog-locale-audit` | Locale-specific compliance check. |
| `blog-taxonomy` | Category and tag taxonomy. |
| `blog-notebooklm` / `blog-audio` | Audio adaptation. |
| `blog-google` | Google-specific signals (Knowledge Panel, sitelinks). |
| `blog-audit` | Full-site health assessment. |

## Sub-skill name accuracy

This orchestrator references each sub-skill by its EXACT name from the plugin source. Common naming gotcha:

- The on-page SEO sub-skill is named `blog-seo-check` (not `blog-seo`). Using the wrong name silently fails on invocation.

Verify sub-skill names against the live plugin source at `https://github.com/AgriciDaniel/claude-blog` if naming changes.

## Hard dependency check

At the start of each invocation, the orchestrator verifies `AgriciDaniel/claude-blog` is installed. If absent, the orchestrator aborts with an install message rather than attempting fallback behavior. See `SKILL.md` "Requirements" section.

## Optional dependencies

- `humanizer` (`https://github.com/blader/humanizer`): used in Step 3. If absent, Step 3 is labeled "no humanizer pass ran" and the lifecycle continues.
- `hormozi-offer-audit`: companion skill for offer audit. Not invoked by this skill; mentioned in companion-skills section for posts that pitch an offer.
- `cialdini-influence-audit`: companion skill for persuasion audit. Not invoked by this skill; mentioned for posts heavy on persuasion mechanics.
