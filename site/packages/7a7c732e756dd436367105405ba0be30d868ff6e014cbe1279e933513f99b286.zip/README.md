# claude-skill-blog-assistant

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![Built for Claude](https://img.shields.io/badge/Built%20for-Claude-D97757)](https://claude.com)
[![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)](#)
[![Requires: claude-blog](https://img.shields.io/badge/Requires-claude--blog-success)](https://github.com/AgriciDaniel/claude-blog)

**Full write-up:** [ericforte.com/blog/3-claude-code-skills-i-built](https://www.ericforte.com/blog/3-claude-code-skills-i-built)

> A dual-mode Claude skill that wraps `AgriciDaniel/claude-blog` into a complete publishing lifecycle. **Mode 1 (Ship):** walk through the 8-step lifecycle to publish a new post. **Mode 2 (Score):** audit an existing published post against the same 8-step checklist and return a prioritized retrofit list.

This skill REQUIRES `AgriciDaniel/claude-blog` installed alongside. It adds the orchestration, audit gates, dual-mode routing, and retrofit logic that `claude-blog` does not include by itself.

---

## What this skill adds to `claude-blog`

`claude-blog` is a plugin with 28 sub-skills for every part of blog publishing (brief, write, SEO check, schema, analyze, repurpose, and more). Each sub-skill works standalone. You invoke whatever you need.

`claude-blog-assistant` does NOT replace `claude-blog`. It REQUIRES it. The value-add is the conductor layer:

| `claude-blog` (the plugin) | `claude-blog-assistant` (this skill) |
| -------------------------- | ----------------------------- |
| 28 individual sub-skills, each one-shot | 8-step lifecycle order with gates between steps |
| You decide what to invoke and when | One entry point routes you to Mode 1 (ship) or Mode 2 (score) |
| No opinion on ordering | Opinionated order: brief → write → humanize → SEO check → schema → analyze → repurpose → final QA |
| `blog-analyze` is optional | `blog-analyze` is mandatory in this lifecycle; never silently skipped |
| Brief and draft are separate sub-skills | Brief-approval gate forces user review before drafting (prevents wasted writes) |
| No "score existing post" workflow | Mode 2 retroactively audits any published post and outputs a prioritized retrofit list |
| Sub-skills don't talk to each other | Cross-skill integration: invokes `humanizer` in Step 3; cross-references `hormozi-offer-audit` and `cialdini-influence-audit` for offer/persuasion work |
| No platform-specific repurpose guidance baked in | Repurpose step uses verified platform specs (LinkedIn 3,000 cap, X 280, Threads 500) with unverified claims explicitly labeled |
| Each sub-skill invocation is silent | Audit-gate visibility: every sub-skill announced before firing, so you can stop or redirect mid-flow |

**Plain version:** if you only need to write a single post and you know which sub-skill you want, just use `claude-blog` directly. If you want a full publishing lifecycle from idea to ship, OR you want to retroactively score posts you already published, this skill adds the conductor.

---

## Why this skill exists

Most blog publishing workflows online are written-by-hand checklists. They tell you to "write a brief, draft, edit, optimize." They do not enforce order. They do not gate on quality. They do not score after the fact.

`claude-blog` gives you the parts. `claude-blog-assistant` gives you the assembly. The 8-step lifecycle exists because each gate catches a real failure mode the author has seen at least once. Skip the brief and you ship a post that drifts off topic. Skip the humanizer and you ship AI-tells. Skip the analyze and you accumulate SEO debt that compounds across the blog.

Mode 2 (score existing post) exists because authors accumulate published posts that were shipped before the lifecycle was in place. You don't want to rewrite them all. You want to know which ones need retrofit and in what order. Mode 2 returns a prioritized retrofit list.

---

## Install

This skill REQUIRES `AgriciDaniel/claude-blog` installed alongside as a hard dependency on every surface. Skills do not sync across surfaces (per [Anthropic's Agent Skills docs](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview#cross-surface-availability)). Install on each surface where you want to run this skill.

### Claude Code (CLI)

Two paths. Use git clone today; the plugin marketplace listing is pending Anthropic approval.

**Option A: git clone (works today).**

Step 1: install the required `claude-blog` dependency (standalone skill, not a plugin):

```bash
git clone https://github.com/AgriciDaniel/claude-blog.git ~/.claude/skills/claude-blog
```

Step 2: clone this plugin and load it with `--plugin-dir`:

```bash
git clone https://github.com/johnericforte/claude-skill-blog-assistant.git ~/claude-plugins/claude-blog-assistant
claude --plugin-dir ~/claude-plugins/claude-blog-assistant
```

To verify the plugin loaded, run `/help` in Claude Code. You should see `claude-blog-assistant:assistant` listed.

**Option B: Plugin marketplace (pending Anthropic approval).** Once the listing lands:

```
/plugin install claude-blog-assistant
```

You will still need to install `AgriciDaniel/claude-blog` separately (Step 1 above). The marketplace listing does not bundle the upstream plugin.

### claude.ai (web) / Claude Desktop

ZIP both `skills/assistant/` from this repo AND the full `AgriciDaniel/claude-blog` repo. Upload both via **Settings → Features → Skills** on claude.ai. The skills sync to Claude Desktop through your account. Requires a Pro, Max, Team, or Enterprise plan with code execution enabled. See [Anthropic's docs](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) for plan requirements and limits.

### Invocation (Claude Code)

Once loaded in Claude Code, invoke the skill with the plugin-namespaced name:

```
/claude-blog-assistant:assistant
```

### Optional dependency: `humanizer`

Recommended for Step 3 (voice cleanup):

```bash
git clone https://github.com/blader/humanizer.git ~/.claude/skills/humanizer
```

`humanizer` is a standalone skill (not a plugin), so it installs to the standard `~/.claude/skills/` directory.

### Auto-install offer (lazy install path)

You can also install this plugin first and let it offer to install the dependencies for you on first invocation. When you invoke the skill, it checks for `claude-blog` (required) and `humanizer` (optional). If either is missing, it asks you for permission before running `git clone`, then prompts you to restart Claude Code to load the newly installed skills.

No skill is installed without your explicit yes. Decline at any time. If you decline `claude-blog`, the orchestrator aborts. If you decline `humanizer`, Step 3 (humanize) is skipped and labeled accordingly.

---

## Quick start

Once installed, invoke the skill via Claude:

```
Use the claude-blog-assistant:assistant skill.
```

The skill will ask you which mode you want:

```
This skill has two modes:

  1. Ship new post: walk through the 8-step lifecycle to publish a new post.
  2. Score existing post: audit a published post and output a prioritized retrofit list.

Which mode? (1 or 2)
```

Pick the mode. For Mode 1, the skill walks you through 8 steps with announcements before each gate. For Mode 2, paste a URL or the post text and the skill returns the audit + retrofit list.

---

## Demo

### Mode 1: Ship new post

```
You: Use claude-blog-assistant. Mode 1. Topic: "How to pick the right CRM for a 5-person consulting firm." Audience: solo consultants and small services teams.

Skill: Running `claude-blog:blog-brief` now...
  → Brief written to /<your-content-folder>/blog-briefs/how-to-pick-the-right-crm-brief.md
  → Stop here. Review the brief, then reply "approved" to continue.

You: approved

Skill: Running `claude-blog:blog-write` now...
  → Draft generated using approved brief.
  → Continue to Step 3 (humanize)? (yes / no)

You: yes

Skill: Running `humanizer` now...
  → Voice pass complete. 4 em dashes replaced. 2 AI-vocab tells removed.
  → Continue to Step 4 (SEO check)? (yes / no)

You: yes

[... continues through Steps 4-8, with announcements + gate confirmations at each step]

Final output:
  - Draft (final): /<your-content-folder>/posts/how-to-pick-the-right-crm.md
  - Schema JSON-LD: /<your-content-folder>/posts/how-to-pick-the-right-crm.schema.json
  - Repurpose drafts: /<your-content-folder>/blog-briefs/how-to-pick-the-right-crm-{LINKEDIN,X,THREADS}.md
  - Lifecycle audit score: 87 / 100
```

### Mode 2: Score existing post

```
You: Use claude-blog-assistant. Mode 2. URL: https://example.com/blog/my-old-post-from-2024

Skill: Running `claude-blog:blog-analyze` on the post text now...
  → Score: 64 / 100

Score:
  Content quality:    20 / 30
  SEO:                14 / 25
  E-E-A-T:            8 / 15
  Technical:          10 / 15
  AI citation:        12 / 15

Lifecycle compliance:
  1. Brief evidence:       PRESENT (post has one clear angle and named keyword)
  2. Draft quality:        WEAK (no Key Takeaways box, no citation capsules)
  3. Humanizer pass:       MISSING (5 em dashes found, 3 AI-vocab tells)
  4. SEO check signals:    title length OK, meta description over 160 chars, no internal links
  5. Schema (JSON-LD):     MISSING (no Article or BreadcrumbList found in page source)
  6. Analyze score:        64 / 100
  7. Repurpose drafts:     N/A
  8. Final QA notes:       two dead outbound links

Top retrofit list (prioritized by impact-to-effort ratio):
  1. Add JSON-LD schema (Article + BreadcrumbList). Cost: 15 minutes. Lift: +6 SEO points + AI citation readiness.
  2. Run `humanizer` skill on the post body and replace 5 em dashes + 3 AI-vocab tells. Cost: 10 minutes. Lift: stops the post reading as AI-generated.
  3. Trim meta description to <160 chars. Cost: 2 minutes. Lift: SERP click-through.
  4. Add 3-5 internal links to related posts. Cost: 5 minutes. Lift: SEO + bounce rate.
  5. Add Key Takeaways box near the top. Cost: 10 minutes. Lift: +4 Content quality points + readability.
```

---

## Use cases

- Solo creator shipping weekly blog posts and wanting a consistent quality bar
- Agency content team standardizing publishing across multiple writers
- DevRel or technical writer needing SEO + AEO/GEO optimization built in
- B2B SaaS marketing publishing pillar posts plus supporting cluster articles
- Newsletter operator turning archive content into evergreen blog posts
- Indie founder doing content marketing solo and needing lifecycle gates as a forcing function
- Anyone with a backlog of older posts who needs to know which ones to retrofit first

---

## How it works

Mode 1 walks the user through 8 steps. Each step is announced before firing. The user can stop or redirect at any gate.

| Step | Sub-skill | Gate |
| ---- | --------- | ---- |
| 1. Brief | `claude-blog:blog-brief` | User reviews and approves before drafting |
| 2. Draft | `claude-blog:blog-write` | Continue confirmation |
| 3. Humanize | `humanizer` (optional dependency) | Continue confirmation |
| 4. SEO check | `claude-blog:blog-seo-check` | Continue confirmation |
| 5. Schema (JSON-LD) | `claude-blog:blog-schema` | Continue confirmation |
| 6. Analyze | `claude-blog:blog-analyze` | MANDATORY; never silently skipped |
| 7. Repurpose | `claude-blog:blog-repurpose` | Optional, only on user request |
| 8. Final QA | (human read-through) | User signs off |

Mode 2 takes a URL or pasted post text, runs `claude-blog:blog-analyze` plus a lifecycle compliance check, and outputs the retrofit list ranked by impact-to-effort.

The full mechanic, sub-skill mapping, and retrofit selection logic live in [`SKILL.md`](./SKILL.md). Reference cards for each piece live in [`references/`](./references/).

---

## Companion skills

- **[`humanizer`](https://github.com/blader/humanizer)**: optional but recommended. Strips AI vocabulary, em-dash overuse, rule-of-three padding, and other AI-writing tells. Invoked automatically in Step 3 if installed.
- **[`hormozi-offer-audit`](https://github.com/johnericforte/claude-skill-hormozi-offer-audit)**: audit-first companion skill for posts that pitch an offer (sales pages, lead magnets, pricing tier walkthroughs). Pair the claude-blog-assistant lifecycle with a Hormozi offer audit on the post's CTA and pricing claims.
- **[`cialdini-influence-audit`](https://github.com/johnericforte/claude-skill-cialdini-influence-audit)**: audit-first companion skill for posts heavy on persuasion (CTAs, conversion copy, opt-in sequences). Pair the claude-blog-assistant lifecycle with a Cialdini influence audit on the post's persuasion mechanics.

This skill does not auto-invoke the companions. It mentions them by name when applicable.

---

## FAQ

**Is this a replacement for `claude-blog`?**

No. This skill REQUIRES `claude-blog`. It is a conductor layer on top of `claude-blog`'s individual sub-skills. Without `claude-blog` installed, this skill aborts at startup with an install message.

**What if I only want to use one `claude-blog` sub-skill (like just the brief)?**

Use `claude-blog` directly. This skill is for the full lifecycle. If you want to invoke a single sub-skill, you don't need the conductor.

**Why is the brief step gated on user approval?**

Drafting without an approved brief produces drift. The brief defines the angle, audience, keyword target, and outline. Locking those in before drafting saves rewrites later. The gate is a forcing function, not a suggestion.

**Why is `blog-analyze` mandatory?**

It's the end-of-pipeline check. Posts shipped without it accumulate SEO and quality debt that compounds across the blog. Making it non-skippable means every post that exits the lifecycle has a known score.

**What does Mode 2 do that I can't do with `claude-blog:blog-analyze` directly?**

`blog-analyze` returns a score. Mode 2 returns a score PLUS a lifecycle compliance check (which of the 8 steps were skipped or weak) PLUS a prioritized retrofit list ranked by impact-to-effort. The retrofit list is the value-add.

**Does this work with tools other than Claude Code?**

The skill is written in the Claude Code skill format (`SKILL.md` + frontmatter). It also works in OpenCode, which uses the same skill format. For other tools, you may need to adapt the format manually.

**Can I use this for commercial work?**

Yes. The skill is MIT-licensed. So is `claude-blog`. So is `humanizer`. You can use the full stack on client work, agency content production, and any other commercial application.

**Why is the "LinkedIn link in first comment" labeled as unverified?**

The character-limit data from AuthoredUp's 372k-post study is verified. The mechanism behind the alleged comment-link reach boost (a 360Brew penalty for body links) is NOT officially confirmed by LinkedIn. Many practitioners report it works. This skill labels it as a popular practice rather than gospel so users can make their own call.

**What if `humanizer` is not installed?**

Step 3 is labeled "no humanizer pass ran" and the lifecycle continues. The skill ships the draft as-is. You can install `humanizer` later and re-run Step 3 manually.

---

## Sources & attribution

This skill orchestrates publicly available sub-skills from `AgriciDaniel/claude-blog`. The 8-step lifecycle synthesizes mainstream blog publishing best practices from multiple sources. Frameworks and methodologies cited descriptively under nominative fair use where applicable.

**Required dependency:**

- [`AgriciDaniel/claude-blog`](https://github.com/AgriciDaniel/claude-blog): MIT license, 28 sub-skills.

**Optional dependency:**

- [`blader/humanizer`](https://github.com/blader/humanizer): MIT license, used in Step 3.

**Verified online references:**

- [Google SEO Starter Guide](https://developers.google.com/search/docs/fundamentals/seo-starter-guide)
- [Google Article structured data](https://developers.google.com/search/docs/appearance/structured-data/article)
- [Schema.org BlogPosting](https://schema.org/BlogPosting)
- [Surfer SEO Content Audit scoring](https://docs.surferseo.com/en/articles/9463956-content-score-in-content-audit-explained)
- [Clearscope grading dimensions](https://www.clearscope.io/support/how-does-clearscope-grade-your-content)
- [AuthoredUp LinkedIn character-limit study](https://authoredup.com/blog/linkedin-character-limit)

Full source list, caveats on unverified claims, and the verification status of every framework definition: [`references/sources.md`](./references/sources.md).

---

## Contributing

Pull requests welcome. Especially:

- Bug fixes for sub-skill name drift (claude-blog sub-skill names may change over time)
- Additional worked examples in `references/examples/`
- Platform-spec updates as LinkedIn / X / Threads change character limits or algorithm patterns
- Mode 2 audit rubric improvements

For framework misattribution or breaking changes in `claude-blog`, open an issue.

---

## Author

Built by **Eric Forte**, AI Automation Engineer for GoHighLevel Marketing Agencies.

- Website: [ericforte.com](https://www.ericforte.com)
- Blog: [ericforte.com/blog](https://www.ericforte.com/blog)
- LinkedIn: [@johnericforte](https://www.linkedin.com/in/johnericforte/)

---

## License

[MIT](./LICENSE) © 2026 Eric Forte
