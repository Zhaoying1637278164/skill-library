# FinSharpe MCP

One Claude Code plugin that bundles FinSharpe's six hosted MCP servers for Indian
capital-markets work, plus eight research and advisory skills that know how to use them.
Install the whole stack with a single command instead of pasting six connector URLs.

## Install

The repo is public on GitHub, so anyone running **Claude Code** can add it with the
`owner/repo` shorthand — no registration, no form, no marketplace listing required. A
public repo containing `.claude-plugin/marketplace.json` *is* the marketplace.

Run these in Claude Code (the CLI, or the Claude Code interface inside the desktop app):

```text
/plugin marketplace add FinSharpe/finsharpe-plugin
/plugin install finsharpe@finsharpe
/reload-plugins
```

- **`marketplace add FinSharpe/finsharpe-plugin`** — registers this repo as a
  marketplace. Because the repo is public, no auth is needed to add it. (For a private
  fork, use the full git URL and ensure git access via `gh auth login`, the OS keychain,
  or an SSH key in `ssh-agent`.)
- **`install finsharpe@finsharpe`** — installs the `finsharpe` plugin from the
  `finsharpe` marketplace, registers its six MCP servers from `.mcp.json`, and loads the
  skills under `skills/`.
  (`plugin-name@marketplace-name` — they share the name here, so it reads doubled.)
- **`reload-plugins`** — activates the servers in the current session.

Verify the six servers connected with `/mcp`, and that the skills are listed with `/skills`.

> **Note on "Claude desktop app":** this plugin system is a **Claude Code** feature.
> The same commands work in Claude Code whether you run it in the terminal or inside the
> desktop app. The Claude.ai / desktop *chat* app's Connectors panel is a separate
> mechanism that does not read this plugin format — there you would still add each server
> URL as an individual connector.

## Servers

| Server | Purpose |
| --- | --- |
| `finsharpe-gpt` | FinSharpeGPT (tradekit) — endpoint discovery, scanners, symbol resolution, market overview, stock & MF reports. |
| `finsharpe-filings` | Semantic retrieval over Indian-listed-company filings — concall transcripts, investor presentations, and annual reports. |
| `finsharpe-fno` | Options analytics for the Indian F&O market — option chain, payoff and greeks, market-wide positioning, FII/DII flows, strategy screener. |
| `finsharpe-screener` | Equity and mutual-fund screening — strategies, columns, industries, and symbol/scheme resolution. |
| `finsharpe-quant` | Portfolio quant — covariance, efficient frontier, return/risk metrics, and optimizers (HRP, HERC, NCO, risk budgeting, etc.). |
| `finsharpe-backtesting` | Signal and optimizer backtests, walk-forward cross-validation, and run comparison/inspection. |

## Skills

Eight skills ship under `skills/`. Each is a `SKILL.md` that Claude loads on demand when the
request matches its description, so you rarely need to invoke them by name.

| Skill | What it does |
| --- | --- |
| `stock-analyst` | Single-stock research workflow for NSE names: fundamentals, scores, technicals, ownership, filings, red-flag screen, and 2-3 way comparisons. |
| `mf-analyst` | Mutual-fund scheme notes and category scans: holdings history, manager behaviour, TRI benchmark check, overlap. |
| `etf-analyst` | ETF and index-fund analysis: tracking error and difference, iNAV premium/discount, liquidity, AUM, international-ETF risks. |
| `portfolio-xray` | Whole-portfolio diagnosis: concentration, fund overlap, quality screen, risk contributions, cost drag, gap to target allocation. |
| `market-summary` | Morning brief, end-of-day wrap, weekly note, or event commentary from market overview, breadth, FII/DII flows, and derivatives positioning. |
| `client-communications` | Client-facing emails, review summaries, and explainer notes with the right tone and compliance posture. |
| `finsharpe-report-studio` | Renders branded or white-labelled PDF, Word, deck, and workbook deliverables to the FinSharpe design system. |
| `system-instructions-builder` | Turns a recurring workflow into a reusable SKILL.md, Project instructions, system prompt, or agent spec in house conventions. |

Skills refer to tools as `server:tool` (for example `finsharpe-gpt:resolve_symbols`), matching
the server names in `.mcp.json`.

## Cowork

The same bundle ships as a `.plugin` file for Cowork — install that artifact directly
instead of going through the marketplace.

## Authentication

All six servers sit behind OAuth. On first use, run `/mcp`, pick a server, and choose
**Authenticate** — Claude Code opens the browser login, stores the token, and reconnects.
No credentials go in the repo.

If you are given a static API token instead, add a `headers` block to that server's entry
in `.mcp.json`:

```json
{
  "mcpServers": {
    "finsharpe-quant": {
      "type": "http",
      "url": "https://finsharpe-quant-production.up.railway.app/mcp",
      "headers": {
        "Authorization": "Bearer ${FINSHARPE_API_TOKEN}"
      }
    }
  }
}
```

Tokens come from environment variables (`${FINSHARPE_API_TOKEN}` is expanded at runtime)
and are never hardcoded into the repo. Set `FINSHARPE_API_TOKEN` in your shell or
environment before launching Claude Code.

## Privacy

See [PRIVACY.md](./PRIVACY.md) for how the plugin and its hosted MCP servers handle data.

---

### Community marketplace (optional)

This plugin's name is kebab-case (`finsharpe`), so it's eligible for Anthropic's public
**community** marketplace. Submission is a separate, optional step done through an in-app
form — it is not required for anyone to install from this repo. Once approved and synced,
users could instead install with:

```text
/plugin marketplace add anthropics/claude-plugins-community
/plugin install finsharpe@claude-community
```

To submit, run `claude plugin validate` locally first, then use the Console form at
[platform.claude.com/plugins/submit](https://platform.claude.com/plugins/submit) (for
individual authors) or the claude.ai form at
`claude.ai/admin-settings/directory/submissions/plugins/new` (requires a Team/Enterprise
org with directory-management access).
