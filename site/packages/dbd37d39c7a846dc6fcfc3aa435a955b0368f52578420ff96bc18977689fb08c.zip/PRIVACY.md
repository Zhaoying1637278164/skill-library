# Privacy Policy — FinSharpe MCP plugin

_Last updated: 19 June 2026_

This policy describes how the **FinSharpe MCP** Claude Code plugin handles data. It
covers the plugin distributed in this repository and the hosted MCP services it connects
to. It does not cover Claude Code itself or the Claude client, which are governed by
Anthropic's own policies.

## What the plugin is

The plugin is a thin configuration bundle: plugin and marketplace manifests, a set of MCP
server definitions (`.mcp.json`), and documentation. It contains no application code, no
telemetry, and no analytics. Installing or enabling the plugin does not, by itself,
transmit any data.

## Data the plugin stores

None on your machine beyond the configuration files themselves. The plugin does not write
logs, profiles, identifiers, or usage data locally.

## Data sent to FinSharpe services

When you invoke one of the bundled MCP tools, Claude Code sends your request over HTTPS to
the corresponding FinSharpe-hosted MCP server:

| Server | Endpoint |
| --- | --- |
| finsharpe-gpt | `https://finsharpe-mcp.up.railway.app/mcp` |
| finsharpe-filings | `https://finsharpe-mcp.up.railway.app/filings/mcp` |
| finsharpe-screener | `https://finsharpe-screener-mcp-production.up.railway.app/mcp` |
| finsharpe-quant | `https://finsharpe-quant-production.up.railway.app/mcp` |
| finsharpe-backtesting | `https://finsharpe-bactesting-production.up.railway.app/mcp` |

Each request carries the tool arguments you (or Claude on your behalf) provide — for
example, ticker symbols, screening criteria, portfolio inputs, or filing search queries.
These services are hosted on Railway. As with any HTTP service, the servers and their
hosting provider may process and log standard request data such as the request payload,
timestamp, and originating IP address for the purpose of operating, securing, and
improving the service. FinSharpe does not use this data for advertising and does not sell
it.

## Authentication tokens

The servers are open HTTP today and require no credentials. If a server is later placed
behind authentication, you supply a token via the `FINSHARPE_API_TOKEN` environment
variable, which is sent only as an `Authorization` header to the server you configure.
The token lives in your own environment; it is never hardcoded in this repository and the
plugin never persists it.

## Third parties

- **Anthropic / Claude Code** — the client that runs the plugin and routes your requests.
- **Railway** — the platform hosting the FinSharpe MCP servers.

These parties process data under their own privacy terms.

## Your choices

- Disable or uninstall the plugin at any time with `/plugin` to stop all requests.
- Disable an individual server by removing its entry from `.mcp.json`.
- Avoid sending data you do not want processed by a hosted service.

## Contact

For privacy questions or requests regarding data handled by the FinSharpe MCP services,
contact FinSharpe at the address listed on the project homepage:
<https://github.com/FinSharpe/finsharpe-plugin>.
