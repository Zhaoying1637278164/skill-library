---
name: market-summary
description: 'Produce a data-grounded Indian market summary at any cadence: morning brief, end-of-day wrap, weekly note, or event-driven commentary. Pulls the market overview, advance-decline breadth, institutional (FII/DII) flows and derivatives positioning from the FinSharpe MCP toolkit and composes it for the chosen audience and channel. Use this skill whenever the user asks "what''s happening in the market", "market update", "how did markets do today/this week", "morning brief", "FII flows", "market positioning", or wants market commentary drafted for clients or a newsletter — even a casual "kya chal raha hai market mein". Do NOT use for single-stock news (stock-analyst) or fund questions (mf-analyst).'
---

# Market Summary

A market summary is only worth sending if every number in it is real and dated. This skill
fetches first, writes second, and always states what window the data covers.

## House rules (non-negotiable)

- **Fetch before writing.** Never compose market commentary from memory; index levels, breadth
  and flows change daily and a stale number presented as current is worse than no number.
- Every figure carries its as-of date/time. Never imply real-time data; say "as of [date] close"
  or "latest available".
- No predictions stated as fact, no recommendations, no guaranteed-return language. "Positioning
  suggests" and "historically has coincided with" are fine; "markets will" is not.
- INR; lakh/crore. No em dashes.

## Workflow

### 1. Fetch the picture
Pull in parallel, scaled to the ask:
- **Overview and breadth**: `finsharpe-gpt:get_market_overview` — index summary and
  advance-decline data. Breadth vs headline divergence is often the actual story.
- **Institutional flows**: `finsharpe-fno:opstra_institutional_flows` — what FIIs and DIIs
  bought/sold and how they are positioned.
- **Positioning and volatility**: `finsharpe-fno:opstra_market_positioning` — open interest and
  volatility read for context on how the move is being traded.
- **Sector/cross-section colour** (weekly notes): `finsharpe-gpt:get_analytics` on sector or
  index groups (`find_predefined_groups`) for leaders/laggards over the window.

If a fetch fails, write the summary from what succeeded and state what is missing. Do not fill
the gap from memory.

### 2. Find the story
A summary is not a data dump. Identify the one or two things that actually characterise the
period: breadth confirming or diverging from the headline index, a flow reversal, positioning
extremes, a sector rotation. Lead with that; the numbers support it.

### 3. Compose for the audience and channel

**Formats:**
- **Morning/EOD brief (internal or personal use)**: 5-8 tight lines. Headline move, breadth,
  flows, positioning note, what to watch today.
- **Client WhatsApp update**: hand the facts to **client-whatsapp-comms** — it owns tone and the
  anti-AI-tell pass. Give it the fetched facts, not a finished report to shrink.
- **Newsletter / weekly note paragraph(s)**: 150-300 words of prose, mechanism-led, figures
  inline. No bullet walls.
- **Briefing PDF**: structure the content and hand to **finsharpe-report-studio** for rendering.

Default when unspecified: the short brief, in chat.

### 4. Sanity pass before presenting
- Do all figures trace to this session's payloads? (Spot-check the headline numbers.)
- Is every figure dated?
- Does the summary make any implicit forecast? Rephrase to positioning/observation language.

## Recurring-use note
If the user asks for this "every morning" or similar, point out this works well as a scheduled
task/automation with this skill as the instruction set, and offer to draft that setup via
**system-instructions-builder**.
