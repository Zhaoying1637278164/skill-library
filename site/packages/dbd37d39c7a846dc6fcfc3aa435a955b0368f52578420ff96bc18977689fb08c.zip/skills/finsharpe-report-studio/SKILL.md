---
name: finsharpe-report-studio
description: 'Render white-labelled, brand-consistent FinSharpe deliverables: IPS, financial plan report, risk-profile summary, allocation and product one-pagers, review decks, plus research deliverables (equity research notes, MF and ETF reports, portfolio X-ray reports, market briefings from the analysis skills), all built to the FinSharpe design system (cream, forest green, gold; Fraunces / Inter / IBM Plex Mono) with optional white-labelling to a partner''s branding. Use this skill whenever the user wants to "produce the report", "make it look professional", "brand this", "white-label it", "build the client PDF / deck", or turn any planning or analysis output into a polished document. Trigger it as the final stage after ips-builder or any analysis skill, whenever a FinSharpe-branded PDF, Word doc, deck or workbook is the deliverable. It owns palette, fonts, layout, cover pages, PDF build settings, the research provenance footer, and the no-em-dash house style.'
---

# FinSharpe Report Studio

Final stage. Takes the structured content from any upstream skill and renders it as a polished,
brand-consistent, white-labelled deliverable. It owns look and feel; upstream skills own content.

Two branding modes:
- **FinSharpe-branded**: the default house identity (palette, type, logo lockup).
- **White-label**: swap in a partner or client-firm identity (their logo, name, and optionally
  their colours/fonts) while keeping FinSharpe's layout quality. Ask which mode before building,
  and collect the partner assets (logo, firm name, colour overrides) if white-labelling.

## Inputs
Structured content from upstream. Two families:
- **Advisory chain**: `ips.json`, `asset_allocation.json`, `product_selection.json`,
  `risk_profile.json`, `client_record.json`, or any subset.
- **Research chain**: structured notes from stock-analyst, mf-analyst, etf-analyst,
  portfolio-xray, or market-summary (their section templates map directly to report sections).
If handed loose content, structure it first, then render.

## Workflow

### 1. Read the design system and confirm branding mode
Read `references/design-system.md` now. It holds the palette, typography, layout grid, component
patterns, cover-page spec, chart styling, and the technical build settings. Then confirm with the
user: FinSharpe-branded or white-label, and which document(s) to produce.

### 2. Pick the format and the underlying skill
Choose the deliverable format and delegate the mechanics to the matching document skill, applying
the FinSharpe design tokens throughout:
- IPS, financial plan report, review note -> a formal document. Use the **docx** skill for Word
  or the **pdf** skill (HTML + Playwright) for PDF. Prefer PDF for signed client deliverables.
- One-pagers, allocation and product summaries, review decks -> **pptx** for a deck, or an
  HTML-to-PDF one-pager via the **pdf**/**frontend-design** skills.
- Workbooks (goal projections, allocation model, cash-flow schedule) -> the **xlsx** skill, using
  Calibri, and run `recalc.py` after every workbook build so formulas are evaluated.
Always read the relevant SKILL.md before building, since those skills carry environment-specific
constraints.

### 3. Apply the design system
Enforce, without exception:
- Palette: cream canvas `#F7F2E7`, forest green `#1E3A2B`, gold `#C29A3B` (plus the neutrals and
  data-viz ramp in the reference). In white-label mode, substitute the partner primary/accent but
  keep the layout, spacing and type hierarchy.
- Typography: Fraunces for headings, Inter for body, IBM Plex Mono for numeric/data; Calibri for
  Excel. Fallbacks in the reference if a font is unavailable.
- Layout: generous margins, clear hierarchy, one idea per section, tables and charts styled per
  the reference. Cover page with client name, document title, date, adviser/firm lockup, and a
  confidentiality line.
- Charts: use the FinSharpe chart styling (palette-consistent, minimal chrome, mono data labels).

### 4. Build, then quality-check
- PDF: render with Playwright using the `--no-sandbox` flag (required in this environment).
- Workbook: run `recalc.py` after building; never present a workbook with unevaluated formulas.
- Proofread for house style: NO em dashes anywhere in the output. INR throughout; lakh/crore in
  client-facing figures. Consistent number formatting via IBM Plex Mono.
- Confirm every required IPS/report section from the upstream content is present and nothing was
  dropped in rendering.
- Confirm the SEBI disclosure block and the no-guarantee/risk language survived into the final
  document (they must appear in any advice deliverable).

### 5. Present
Save final files to the outputs location and present them to the user. Give a one-line summary of
what was produced and the branding mode used. Do not bury the deliverable under a long postamble;
the user needs the file.

## Deliverable catalogue (typical requests)
- Investment Policy Statement (branded PDF, signature-ready).
- Financial Plan Report (cover, executive summary, profile, goals, risk, allocation, products,
  projections, disclosures).
- Risk Profile Summary (one to two pages).
- Asset Allocation one-pager (matrix + chart + rationale).
- Recommended Products sheet (by sleeve).
- Goal projection / cash-flow workbook (xlsx, Calibri, recalc'd).
- Portfolio review deck (pptx).
- Equity research note / stock comparison (branded PDF, factual-analysis footer).
- Mutual fund or ETF analysis report (branded PDF).
- Portfolio X-ray report (branded PDF; treat as PII, confidentiality line mandatory).
- Market briefing (one to two page PDF, dated prominently).

## Research-report specifics
Research deliverables carry, in addition to the design system:
- A **provenance footer** on the cover or first page: "All figures sourced from FinSharpe
  analytics and exchange/NSE filings as of [date]." Every report states its data as-of date.
- The **AI-usage disclosure** line (per house policy for client-facing PDFs).
- The **factual-analysis statement**: this report contains factual analysis only; no investment
  recommendations, price targets, or ratings. Verify the upstream content actually complies
  before rendering; if a recommendation slipped in, flag it, do not render it.
- Past-performance caveat wherever return figures appear.

## Guardrails
- Content fidelity: never alter numbers, recommendations, or disclosures while styling. If content
  looks wrong, flag it to the user; do not silently edit the plan.
- Disclosures are mandatory in any advice deliverable: the fiduciary, risk, no-guarantee, grievance
  and (if applicable) AI-usage statements must appear.
- White-labelling swaps identity, not substance or compliance language.
- Confidentiality line on every client document; treat all client data as PII.

## House style (enforced here for the whole pipeline)
No em dashes. INR. Fraunces / Inter / IBM Plex Mono (Calibri for Excel). FinSharpe palette unless
white-labelled. Playwright `--no-sandbox` for PDF. `recalc.py` after every workbook build.
