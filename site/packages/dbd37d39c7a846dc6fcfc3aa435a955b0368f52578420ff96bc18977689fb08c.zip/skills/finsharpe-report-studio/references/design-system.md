# FinSharpe Design System (design-system.md)

Brand tokens, typography, layout and build settings for all FinSharpe deliverables. In white-label
mode, substitute the partner's primary and accent colours and logo while keeping this layout,
spacing and type hierarchy.

## Colour palette
Core:
- Cream canvas (background): `#F7F2E7`
- Forest green (primary, headings, rules): `#1E3A2B`
- Gold (accent, highlights, key figures): `#C29A3B`

Supporting neutrals (derive as needed, keep muted and warm):
- Ink / body text: a near-black warm grey (e.g. `#23271F`)
- Muted text / captions: a soft green-grey (e.g. `#6B7168`)
- Hairline / borders: a low-contrast warm grey (e.g. `#D8D0BE`)
- Surface / card on cream: a slightly lighter cream or white with a hairline border

Data-visualisation ramp (palette-consistent, ordered for series): forest green, gold, a muted
teal, a warm clay, a soft olive, a deep sand. Keep charts low-chrome; avoid rainbow palettes.
Positive/negative in tables: use forest green for positive, a restrained brick red for negative,
never neon.

## Typography
- Headings: Fraunces (serif, high-contrast, distinctive). Use for titles, section heads, cover.
- Body: Inter (clean sans). Use for paragraphs, tables, captions.
- Data / numbers: IBM Plex Mono. Use for all figures, tables of numbers, weights, returns, so
  columns align and numerals read cleanly.
- Excel only: Calibri throughout (workbook house font).

Fallbacks if a font is unavailable in the environment: Fraunces -> Georgia/serif; Inter ->
Helvetica/Arial/sans-serif; IBM Plex Mono -> Menlo/Consolas/monospace. Install the real fonts when
possible for fidelity.

Hierarchy guidance: large Fraunces title on cover; section heads in forest green Fraunces; body in
Inter at comfortable size with generous line height; numeric callouts in gold IBM Plex Mono.

## Layout
- Generous margins and whitespace; do not crowd. One idea per section.
- Clear hierarchy: title, section head, sub-head, body, caption.
- Tables: hairline borders, forest-green header row (cream or white text), mono numerals,
  right-aligned figures, zebra striping optional and subtle.
- Cover page: client name, document title, date, adviser/firm lockup (logo + name), and a
  confidentiality line ("Private and confidential. Prepared for [client].").
- Footer on content pages: firm name, page number, document version, and a short disclaimer line.
- Charts: palette-consistent, minimal gridlines, direct labels where possible, mono data labels,
  a short descriptive title. No 3D, no heavy backgrounds.

## Component patterns
- Executive summary box: cream card with a gold left rule and forest-green heading.
- Key-figure callouts: gold IBM Plex Mono numeral with an Inter caption beneath.
- Goal table: goal, present cost, target year, future value, priority, funding status.
- Allocation matrix: asset class, target %, band, role; pair with a donut or stacked bar in the
  data-viz ramp.
- Disclosure block: set slightly smaller, in muted text, but fully legible; never hide it.

## Technical build settings
- PDF: render HTML with Playwright using the `--no-sandbox` flag (required in this environment).
  Embed fonts. Check that page breaks do not split tables or the signature block awkwardly.
- Workbooks: build with the xlsx skill, Calibri font, then run `recalc.py` after every build so
  all formulas evaluate before presenting. Never ship a workbook with unevaluated formulas.
- Decks: pptx skill, apply the palette and fonts to the master/layout.

## House style (non-negotiable)
- NO em dashes anywhere in any output. Use commas, colons, parentheses or periods.
- Currency INR. Client-facing figures in lakh / crore convention; keep raw values in data files.
- Numbers in IBM Plex Mono for alignment.
- Sober, precise, plain language. Avoid hype and guarantees.

## White-label mode
- Replace: logo lockup, firm name, and (if provided) primary + accent colours and heading/body
  fonts.
- Keep: layout grid, spacing, table and chart styling quality, disclosure completeness, and the
  no-em-dash house style.
- Never white-label away the compliance language (fiduciary, risk, no-guarantee, grievance
  redressal, AI disclosure). Branding changes identity, not substance.
