---
name: system-instructions-builder
description: 'Turn a recurring FinSharpe task or workflow into a reusable instruction artifact: a Claude skill (SKILL.md), Claude Project instructions, an API system prompt, or a FinSharpeGPT agent spec — written in FinSharpe house conventions (anti-fabrication, no recommendations, SEBI compliance language, MCP-tool delegation, design system references). Use this skill whenever the user says "turn this into a skill", "make a prompt for this", "write system instructions", "I keep doing this manually", "build an agent for X", "make this repeatable", or wants to capture a workflow from the current conversation into something reusable. Also use it to review or tighten an existing prompt or skill. Do NOT use for one-off task execution — this skill builds the instructions, it does not perform the underlying task.'
---

# System Instructions Builder

Converts workflows into instruction artifacts that another Claude session (or the FinSharpeGPT
platform) can execute consistently. The core belief: a good instruction set encodes **judgment
and house rules**, and delegates **mechanics** to tools. If the instructions restate what an MCP
tool description already says, they are too long; if they omit the thresholds, ordering, and
prohibitions the user applies by hand, they are too short.

## Step 1: Identify the source material

Most requests arrive in one of three states:
- **A workflow just happened in this conversation** ("turn this into a skill"). Extract from the
  transcript: tools called and their order, corrections the user made, output format that was
  finally accepted. User corrections are the highest-value content — each one is a rule the
  instructions must encode.
- **A described workflow** ("I want an agent that does X"). Interview for: trigger conditions,
  inputs, tool routing, decision points, output format, failure handling. Ask the sharp
  questions (what should it refuse to do? what does "done" look like?) but batch them; do not
  drip one question per turn.
- **An existing artifact to improve**. Read it, identify what is vague, duplicated, or
  mechanics-restating, and propose targeted edits rather than a rewrite unless asked.

## Step 2: Pick the artifact type

| Ask sounds like | Build |
|---|---|
| "skill", reusable across chats, has workflow + rules | **Claude skill** (SKILL.md, optionally references/) |
| "project instructions", a persistent workspace context | **Project instructions** (single markdown block) |
| "system prompt", for API / FinSharpeGPT backend | **API system prompt** (role + rules + tool policy) |
| an autonomous multi-step worker on the platform | **Agent spec** (goal, tools, loop, stop conditions, output contract) |

If unclear, ask once, with the trade-off stated in one line each.

## Step 3: Draft to the house template

Every artifact, regardless of type, carries these sections (rename to fit the format):

1. **Role/purpose** — one paragraph, outcome-focused.
2. **Triggering** (skills only) — pushy description with explicit trigger phrases AND explicit
   "do NOT use for" exclusions naming the neighbouring skill that handles them. Under-triggering
   is the default failure mode; write against it.
3. **House rules block** — include the FinSharpe non-negotiables relevant to the task:
   - Anti-fabrication: every number traces to a fetched payload; missing data stated as missing.
   - No recommendations, price targets, ratings, or guaranteed-return language in analysis
     outputs; SEBI compliance and AI-usage disclosure on client-facing deliverables.
   - INR; lakh/crore client-facing. No em dashes anywhere.
   - Design system and rendering belong to finsharpe-report-studio; instruct hand-off, not
     re-implementation.
4. **Workflow** — numbered steps, imperative voice. Name exact MCP tools
   (`server:tool` form) at each step; state parallelism where fetches are independent;
   state the resolve-before-fetch rule (never guess symbols/scheme codes).
5. **Decision points and thresholds** — the numbers the user applies by hand (flag levels,
   caps, defaults). These are the artifact's real value; hunt for them in the interview.
6. **Output contract** — exact structure/template of the deliverable.
7. **Failure handling** — what to do when a tool fails, data is missing, or inputs are
   ambiguous (default: state the gap, do not fill it silently).

Style: imperative, explain *why* a rule exists in one clause where it prevents drift, no filler.
Keep SKILL.md bodies under ~150 lines; push bulk reference material to `references/`.

## Step 4: Pressure-test before delivering

Walk one realistic input through the draft mentally and check:
- Could a fresh session execute this without asking the user anything the artifact should answer?
- Does any step depend on knowledge only in the current conversation? Inline it.
- Do the description's trigger phrases match how the user actually talks? (Reuse their words
  from this conversation.)
- Are the "do NOT use" boundaries stated for adjacent skills?

Offer to run a live test: execute the draft on a sample input in this session and refine from
what breaks. For full eval loops and packaging into a `.skill` file, use **skill-creator**.

## Step 5: Deliver

Present the artifact as a file (not pasted prose) so it can be saved/installed directly. State
in one line what it does and where its boundaries are.
