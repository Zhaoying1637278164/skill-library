---
name: client-communications
description: 'Draft any client-facing communication for the FinSharpe advisory practice across channels: emails (onboarding, review invitations, market commentary, fee/renewal notes, difficult conversations like drawdowns or delays), review-meeting summaries, portfolio explainer notes for non-finance audiences, and broadcast vs individual messages — with the right tone, compliance posture, and none of the tells that make a message read as AI-written. Use this skill whenever the user wants to "write to a client", "draft an email", "explain this to the client", "send a review summary", "inform clients about", handle an unhappy client, or make any client-facing draft "sound more human" — even when the channel isn''t named. For short WhatsApp messages specifically, this skill routes to client-whatsapp-comms which owns that channel. Do NOT use for internal notes, marketing copy for the platform, or branded PDF deliverables (finsharpe-report-studio).'
---

# Client Communications

The umbrella for client-facing writing in the advisory practice. One channel already has a
dedicated owner: **short WhatsApp messages route to client-whatsapp-comms** (read and follow
that skill; do not reimplement its tone system here). This skill owns everything else: email,
review summaries, explainers, and hard conversations.

## Before drafting: three facts

Infer sensibly from context and state assumptions rather than stalling; ask only if the core
purpose is unclear.

1. **Purpose** — inform, invite, explain, reassure, apologise, or ask. A message trying to do
   three of these does none well; split it or pick the lead purpose.
2. **Audience scope** — one client, a segment, or the whole book. Broadcasts must contain
   nothing that reads as personalised advice to an individual; individual messages may reference
   their holdings and plan.
3. **Emotional temperature** — routine, sensitive (fees, underperformance, errors), or hot
   (angry client, missed commitment). Temperature drives structure more than channel does.

## Channel conventions

**Email**: subject line that states the point (not "Update"); first sentence carries the news;
2-4 short paragraphs; one clear next step if any; sign-off matches the relationship. A client
email is not a report — if it needs sections and tables, the content belongs in a PDF
deliverable (report-studio) with a short covering email.

**Review-meeting summary** (post-meeting email or note): what was reviewed, what was decided,
what each side will do by when, and anything the client asked to be recorded. Decisions and
action items are the substance; performance numbers only as discussed in the meeting and only
from real data — never reconstruct figures from memory (pull from the actual review pack).

**Explainer notes** (portfolio concepts for non-finance readers): one idea per note, everyday
Indian-context analogies, INR/lakh/crore, no jargon without a one-line plain meaning. Test:
would the client's parent follow it?

**WhatsApp**: route to client-whatsapp-comms.

## Difficult conversations (the temperature-hot playbook)

For drawdown letters, error admissions, fee increases, delayed deliverables, or an unhappy
client:
- **Lead with the fact, not the cushion.** Burying the news after two paragraphs of warmth
  reads as evasive. State what happened in the first two sentences.
- **Own without grovelling.** One clean acknowledgment beats three apologies. If it was an
  error, say what happened, what the impact was, what has been fixed, and what prevents
  recurrence.
- **Context is not excuse.** Market context for a drawdown is legitimate; it goes after the
  acknowledgment of the client's experience, not in place of it.
- **Never promise outcomes to smooth the moment.** No "markets will recover", no guaranteed
  timelines you don't control. Offer the next concrete step and a specific time to talk.
- Offer 2-3 strategy-distinct drafts for hot messages (e.g., "brief and factual" vs "fuller
  context"), since the right approach is a judgment call the adviser owns.

## Compliance posture (applies to every draft)

- No guaranteed-return language, ever, in any channel.
- Broadcasts: commentary and what-FinSharpe-is-doing framing; nothing constituting individual
  advice.
- Individual advice references should tie back to the client's documented plan/IPS ("in line
  with the allocation we agreed"), not ad-hoc tips.
- If a draft drifts into a specific buy/sell instruction, flag it to the user as a compliance
  judgment call rather than silently softening it.
- Any performance figure quoted must come from real data in context or fetched via the FinSharpe
  toolkit; never approximate a client's returns.

## The anti-AI-tell pass (run on every draft)

Same discipline as client-whatsapp-comms, adapted for longer forms:
- Cut throat-clearing openers ("I hope this email finds you well", "I wanted to reach out to").
  Warmth comes from specificity, not stock phrases.
- No em dashes (house style) and no essay connectors ("moreover", "furthermore") in client mail.
- Vary sentence length; perfectly balanced paragraphs read as generated.
- One closing question maximum, and only if a real answer is needed.
- No reflexive "Please don't hesitate to reach out!" — a specific offer ("call me Thursday
  after 4 if you want to walk through it") lands better and reads human.

## Delivery

Present drafts as ready-to-send plain text. For email, include the subject line. When multiple
strategic approaches exist, label each with what it prioritises so the adviser can choose.
