---
name: etf-analyst
description: 'Analyse ETFs and index funds the way passive vehicles must be analysed: tracking error and tracking difference against the underlying index, market price vs iNAV premium/discount, on-exchange liquidity and impact cost, AUM viability, expense ratio, and the special risks of international ETFs in India (unit-creation suspensions under overseas investment limits, wide premiums). Use this skill whenever the user asks about an ETF, index fund, "passive fund", tracking error, premium/discount, "ETF vs index fund", gold or silver ETFs, or international ETFs like MAHKTECH/MON100 — even if they call it just "a fund", if the vehicle is passive this skill applies. Do NOT use for actively managed mutual funds (mf-analyst) or single stocks (stock-analyst).'
---

# ETF Analyst

Passive vehicles fail differently from active funds. An active fund is judged on manager skill;
an ETF is judged on **replication quality** and **exchange microstructure**. Analysing an ETF
with an active-fund lens (returns leaderboards, manager commentary) misses everything that
actually goes wrong. This skill enforces the correct lens.

## House rules (non-negotiable)

- Every number traces to a fetched payload; missing data is stated as missing, never estimated.
- No recommendations, no "best ETF", no guaranteed-return language.
- INR; lakh/crore client-facing. No em dashes. State the data as-of date.

## The ETF evaluation checklist

Work through all six, in this order, reporting each:

### 1. What exactly does it hold?
Resolve the scheme (`finsharpe-gpt:get_scheme_details` / `finsharpe-screener:resolve_mf_schemes`)
and identify the underlying index and replication method (full replication vs sampling; physical
vs any synthetic exposure). The index methodology matters more than the AMC brand: two "Nifty
Next 50" ETFs are near-identical; two "momentum" ETFs may track very different indices.

### 2. Tracking difference and tracking error
Pull returns for the ETF and its TRI index (`screen_mutual_funds` / `get_analytics` as
available). Report:
- **Tracking difference**: ETF return minus TRI index return per period (the cost investors
  actually bear; usually close to expense ratio plus friction).
- **Tracking error**: volatility of that gap (consistency of replication).
Compare against the index, always TRI, never the price index.

### 3. Premium/discount to iNAV
An ETF bought 2% above iNAV loses 2% before the index moves. Check where market price sits vs
NAV/iNAV if the data is available; if not available in the toolkit, say so explicitly and advise
checking the exchange's iNAV feed before transacting. Flag categories where chronic premiums
occur (see international ETFs below).

### 4. Liquidity and impact cost
On-exchange volume and bid-ask behaviour determine real transaction cost, especially for large
orders. Small AUM plus thin volume means wide spreads. Report AUM and note that for sizeable
allocations the index-fund route may execute cleaner than an illiquid ETF.

### 5. Cost stack
Expense ratio vs category peers, plus the implicit costs already covered (tracking difference,
spread, premium). For "ETF vs index fund" questions, frame it as: ETF = lower TER + exchange
frictions + intraday tradability; index fund = slightly higher TER + NAV execution + SIP
convenience. Which dominates depends on the user's transaction pattern; present the trade-off,
do not pick for them.

### 6. Structural/regulatory risks
- **International ETFs**: when industry-wide overseas investment limits are hit, AMCs suspend
  fresh unit creation; the ETF then trades like a closed-end fund and can run to double-digit
  premiums over iNAV. Anyone buying at a premium is exposed to the premium collapsing
  independently of the index. Always check and disclose this for any international ETF.
- **Commodity ETFs** (gold/silver): note custody/expense structure and tracking vs domestic
  landed price, not international spot.

## Output

```
# [ETF name] — Passive Vehicle Note
Data as of [date]. Underlying index: [index, TRI]. AUM: [x]. TER: [x].
## Replication quality   (tracking difference, tracking error)
## Trading reality       (premium/discount, liquidity, impact cost)
## Cost stack
## Structural notes      (creation limits, category-specific risks)
```

For comparisons across 2-3 ETFs on the same index, align metrics in one table; the decision
usually reduces to tracking difference + liquidity, and the table should make that visible.
For a branded PDF, hand off to **finsharpe-report-studio**.
