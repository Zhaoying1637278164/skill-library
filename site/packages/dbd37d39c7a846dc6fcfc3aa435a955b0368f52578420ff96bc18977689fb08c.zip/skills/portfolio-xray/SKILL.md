---
name: portfolio-xray
description: 'Diagnose an existing portfolio of stocks and/or mutual funds: parse the holdings, resolve every symbol and scheme, then run the full X-ray — concentration (stock, sector, market-cap, AMC), fund overlap, quality and red-flag screen on underlying names, per-asset risk contributions via the quant toolkit, cost drag, and gap versus a target allocation if one exists. Use this skill whenever the user shares a list of holdings (typed, pasted, or in a file/statement) and asks any whole-portfolio question: "review my portfolio", "what''s wrong with this portfolio", "am I too concentrated", "analyse these holdings", "X-ray this", "check overlap in my funds", or a prospect''s incoming portfolio during onboarding. Do NOT use for building a fresh allocation from scratch (asset-allocation-architect) or single-security questions (stock-analyst / mf-analyst / etf-analyst).'
---

# Portfolio X-Ray

Diagnosis of what a portfolio **is**, as distinct from designing what it **should be**
(asset-allocation-architect owns that). The X-ray answers: what am I actually holding, where is
the risk concentrated, what is it costing, and what quietly contradicts the owner's intent.

## House rules (non-negotiable)

- Every number traces to a fetched payload. Never estimate a holding's fundamentals or a fund's
  composition from memory.
- No buy/sell recommendations and no price targets. Findings are stated as facts and gaps; what
  to do about them is an advisory conversation, not an X-ray output.
- Treat all holdings data as PII. INR; lakh/crore. No em dashes. State the data as-of date.

## Workflow

### 1. Parse and resolve the holdings
Accept holdings in any form (typed list, pasted statement text, CSV/XLSX upload — read the file
via the appropriate skill first). Normalise into: instrument, type (stock/MF/ETF), quantity or
amount, and weight. Then resolve everything:
- Stocks: `finsharpe-gpt:resolve_symbols` / `finsharpe-screener:resolve_equity_symbols`
- MF/ETF: `finsharpe-screener:resolve_mf_schemes` / `finsharpe-gpt:get_scheme_details`
List anything that failed to resolve and confirm with the user before analysing — a mis-resolved
symbol poisons every downstream number.

If weights are missing, compute them from current values where fetchable; otherwise ask. Never
assume equal weights silently.

### 2. Look through the funds
For each MF/ETF holding, pull the latest portfolio via `finsharpe-gpt:mf_portfolio_history`.
Build the **look-through portfolio**: effective stock-level exposure = direct holdings + weighted
fund holdings. All concentration analysis runs on the look-through, not the surface holdings —
a portfolio of five "different" funds can be one bet in disguise.

### 3. Run the six diagnostic passes

1. **Concentration**: top-5/top-10 effective stock weights; sector weights; market-cap split
   (large/mid/small); single-AMC exposure across funds.
2. **Overlap**: pairwise weight-based overlap between funds (sum of min weights per common
   stock); flag pairs above ~40% as effectively duplicated exposure.
3. **Quality and red flags**: run the underlying top holdings through FinSharpe scores
   (`get_analytics`) and the red-flag screen used by stock-analyst (negative PAT growth,
   leverage, pledging). Report which portfolio weight sits in flagged names.
4. **Risk contributions**: for the material positions, use the quant toolkit —
   `finsharpe-quant:compute_covariance_matrix` then `compute_risk_contributions` — to show
   which positions drive portfolio volatility. Weight and risk contribution often diverge;
   that divergence is a headline finding.
5. **Cost drag**: weighted expense ratio; flag Regular plans where Direct exists, and expensive
   funds hugging their benchmark.
6. **Intent gap** (if a risk profile or target allocation exists in context): current vs target
   by asset class and band breaches. If no target exists, skip — do not invent one.

### 4. Compose the X-ray

```
# Portfolio X-Ray — [client/label]
Data as of [date]. Holdings as provided on [date]. [N] instruments, [x] resolved.
## What you actually hold      (look-through summary, cap/sector split)
## Concentration findings
## Overlap findings
## Quality screen              (weight in flagged names, with the flags)
## Risk decomposition          (top risk contributors vs their weights)
## Cost                        ## Gap vs target (if applicable)
## Summary of findings         (numbered facts, no prescriptions)
```

For an interactive version use `finsharpe-gpt:render_portfolio_report`. For a branded client PDF,
hand the structured content to **finsharpe-report-studio**.

## Judgment notes
- Depth scales with the ask: "quick look" gets passes 1-2 and a paragraph; a prospect onboarding
  X-ray gets all six.
- If the portfolio is small (2-3 instruments), skip the quant machinery and say why.
- Findings language: "62% of effective equity sits in financials" — never "you should trim
  financials". The line between diagnosis and advice is the compliance boundary of this skill.
