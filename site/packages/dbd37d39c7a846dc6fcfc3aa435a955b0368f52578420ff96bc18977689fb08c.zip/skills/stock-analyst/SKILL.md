---
name: stock-analyst
description: 'Run the full FinSharpe single-stock research workflow for any NSE-listed company: resolve the symbol, pull fundamentals, scores, technicals and institutional ownership from the FinSharpe MCP toolkit, check recent filings, run the red-flag screen (PAT growth, leverage, pledging, cash conversion), and produce a factual research note or branded report. Also handles head-to-head stock comparisons (2-3 names, aligned metrics, no winner declared). Use this skill whenever the user names a stock and wants analysis, research, a deep dive, a "view", fundamentals, a health check, red flags, "what''s going on with X", or a comparison like "X vs Y" — even if they don''t say "research" or "report" explicitly. Do NOT use for portfolio-level questions (portfolio-xray), mutual funds or ETFs (mf-analyst / etf-analyst), or options positioning (that is F&O analysis).'
---

# Stock Analyst

Single-stock research the FinSharpe way: every number fetched, every claim traceable, no
recommendations. The output is a factual research note, not a tip.

## House rules (non-negotiable)

- **Anti-fabrication**: every number in the output must trace to a fetched tool payload. Never
  recall, estimate, or interpolate a figure. If a data point is unavailable, write "not available"
  and move on. This rule exists because a single fabricated number destroys the credibility of the
  whole note and creates regulatory risk for a SEBI-registered adviser.
- **No recommendations**: no buy/sell/hold, no price targets, no ratings, no guaranteed-return
  language. Describe what the data shows; the reader draws conclusions.
- INR denomination; lakh/crore for client-facing figures. No em dashes anywhere.
- State the as-of date of the data prominently.

## Workflow

### 1. Resolve the symbol
Call `finsharpe-gpt:resolve_symbols` with the user's input (name, ticker, or fuzzy text). Never
guess a ticker. If resolution is ambiguous, show the candidates and ask.

### 2. Fetch in parallel
Pull these in the same turn where the tools allow:
- **Fundamentals and scores**: `finsharpe-gpt:get_analytics` for the stock (fundamentals,
  FinSharpe scores, performance/ranking context). Use `search_analytics` first if unsure which
  table holds what you need.
- **Screening context**: `finsharpe-screener:screen_equities` filtered to the stock's industry
  for peer context (valuation and growth percentiles within the industry, not absolutes in a
  vacuum).
- **Institutional footprint**: `finsharpe-gpt:mf_stock_ownership` — which funds hold it and
  whether they are adding or trimming.
- **Filings**: `finsharpe-filings:search_filings` for the last 2-3 quarters — results, concalls,
  credit rating actions, pledge disclosures, resignations, order wins. Pull full text via
  `get_filing_text` only for filings that look material.

### 3. Run the red-flag screen
Check each explicitly and report findings (including clean passes):
- Negative or decelerating PAT growth (YoY and TTM)
- Leverage: debt/equity trend, interest coverage
- Promoter pledging (any pledge is worth naming; rising pledge is a headline flag)
- Cash conversion: CFO vs PAT divergence over 2-3 years
- Receivables/inventory growing faster than revenue
- Auditor changes, rating downgrades, key-person exits (from filings)
A red flag is a fact to report with its source, not a verdict.

### 4. Compose the note
Structure (adapt depth to the ask; a quick question gets a paragraph, "deep dive" gets the full
note):

```
# [Company] ([SYMBOL]) — Research Note
Data as of [date]. Sources: FinSharpe analytics, NSE filings.
## Snapshot          (what the company does, market cap tier, industry position)
## Fundamentals      (growth, margins, returns — with peer percentile context)
## Ownership & flows (institutional holders, direction of change)
## Red-flag screen   (each check, pass or flag, with the number behind it)
## Recent filings    (material events, dated)
## What to watch     (upcoming triggers: results date, pending orders, rating reviews)
```

### 5. Comparison mode (when asked "X vs Y")
Same fetches for each name, then present aligned metrics in one table using identical row labels.
Contrast factually ("A grows faster; B carries less debt"). Never declare a winner and never
recommend one over the other.

### 6. Render (optional)
- For an interactive report, call `finsharpe-gpt:render_stock_report`.
- For a branded PDF deliverable, hand the structured note to **finsharpe-report-studio** — it owns
  the design system and disclosure blocks. Do not restyle by hand.

## When data conflicts
If two payloads disagree (e.g., screener vs analytics on a ratio), report both with their sources
rather than silently picking one. Payload discrepancies are information.
