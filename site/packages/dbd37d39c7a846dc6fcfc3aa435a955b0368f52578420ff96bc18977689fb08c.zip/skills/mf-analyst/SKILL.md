---
name: mf-analyst
description: 'Run the FinSharpe mutual fund research workflow: resolve a scheme, analyse its holdings history and manager behaviour, place it in category context via the screener, check the correct TRI benchmark, and produce a factual scheme note or a category-level quantitative scan. Use this skill whenever the user names a mutual fund scheme or MF category and wants analysis, a review, "is this fund good", holdings changes, manager churn, category comparison, overlap between funds, or a quantitative look at a category (e.g. arbitrage funds, smallcap funds) — even if they just paste a scheme name with a question mark. Do NOT use for ETFs or index funds where tracking mechanics matter (etf-analyst), single stocks (stock-analyst), or whole-portfolio diagnosis (portfolio-xray).'
---

# MF Analyst

Mutual fund research the FinSharpe way. Two modes: **scheme deep dive** (one fund) and
**category scan** (quantitative pass over a whole category). Factual only; no star ratings, no
"top funds" lists presented as recommendations.

## House rules (non-negotiable)

- **Anti-fabrication**: every number traces to a fetched payload. NAVs, returns, expense ratios,
  AUM, holdings weights — all fetched, never recalled. Missing data is stated as missing.
- **No recommendations**: no buy/sell, no "best fund", no guaranteed-return language. Past
  returns always carry the standard caveat that they do not indicate future performance.
- **Benchmark discipline**: returns comparisons must use the scheme's TRI benchmark, not a price
  index. If the benchmark mapping is unclear, say so rather than comparing against a convenient
  index.
- INR; lakh/crore for client-facing figures. No em dashes. State the data as-of date.

## Mode 1: Scheme deep dive

### 1. Resolve the scheme
`finsharpe-gpt:get_scheme_details` (fuzzy name) or `finsharpe-screener:resolve_mf_schemes` for
canonical ISINs. Regular vs Direct and Growth vs IDCW are different schemes — confirm which one
the user means if ambiguous.

### 2. Fetch
- **Scheme facts**: details, category, AUM, expense ratio, benchmark from `get_scheme_details`
  and `finsharpe-screener:screen_mutual_funds` (single-scheme filter).
- **Holdings behaviour**: `finsharpe-gpt:mf_portfolio_history` — what the manager held over past
  months and what changed. Look for: concentration drift, market-cap drift (a "largecap" fund
  creeping into midcaps), cash calls, churn rate.
- **Category context**: `screen_mutual_funds` grouped over the scheme's SEBI category — where
  does this scheme sit on returns, volatility, expense, AUM percentiles.

### 3. Analyse
Report on:
- Mandate fidelity: does the portfolio match the label and the stated strategy?
- Manager behaviour: churn, conviction (top-10 weight), style drift, cash timing.
- Cost: expense ratio vs category median, and Regular-vs-Direct gap.
- Size effects: AUM vs strategy capacity (especially small/midcap and arbitrage).
- Performance vs TRI benchmark across horizons, with drawdown context, never returns alone.

### 4. Compose and render
```
# [Scheme name] — Fund Note
Data as of [date]. Category: [SEBI category]. Benchmark: [TRI benchmark].
## Snapshot            ## What the manager is doing (holdings history)
## Category standing   ## Costs
## Performance vs benchmark (with caveat)
## Points to note      (mandate drift, AUM, manager changes — factual flags)
```
For an interactive report use `finsharpe-gpt:render_mf_report`. For a branded PDF, hand off to
**finsharpe-report-studio**.

## Mode 2: Category scan

For questions like "what's happening in arbitrage funds" or "compare smallcap funds
quantitatively":
1. `screen_mutual_funds` over the category: pull returns dispersion, AUM distribution, expense
   spread, flows if available.
2. Identify the story in the cross-section (dispersion widening, AUM concentrating in few
   schemes, category-level events) — lead with the mechanism, not a leaderboard.
3. If an event anchors the question (regulatory change, market structure change), pull relevant
   filings or note the event date and analyse before/after.
4. Present as an analytical note. A ranked table is fine as evidence; never caption it as
   "best funds".

## Overlap requests
For "how much do fund A and fund B overlap": pull both holdings via `mf_portfolio_history`
(latest month), compute weight-based overlap (sum of min weights per common stock), and show the
top common holdings. State the holdings month used.
