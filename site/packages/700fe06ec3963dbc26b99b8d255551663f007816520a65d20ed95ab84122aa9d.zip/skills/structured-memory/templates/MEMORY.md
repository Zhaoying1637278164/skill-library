# Project Memory

Structured memory index. Each entry points to a memory file with full context.
Keep this file under 200 lines — Claude Code loads the first 200 at session start.

## User
- [user-role.md](user-role.md) — Operator background, expertise, and preferences

## Feedback
<!-- Add feedback memories as they accumulate -->

## Project
<!-- Add project memories as work evolves -->

## Reference
<!-- Add reference pointers to external systems -->
