---
name: user-role-backend-engineer
description: Operator is a senior backend engineer, new to frontend — tailor explanations accordingly
type: user
---

Senior backend engineer with 8 years of Go experience. Currently learning React
for the first time while working on the dashboard frontend. Frame frontend concepts
in terms of backend analogues when possible (components as handlers, state as
in-memory cache, props as function arguments).

Comfortable with: concurrency, API design, database optimization, infrastructure.
Needs support with: JSX syntax, React lifecycle, CSS layout, component composition.
