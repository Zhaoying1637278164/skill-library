import * as React from "react";

/**
 * URL grammar for the wiki page slot.
 *
 * Paperclip registers a single route segment per page slot
 * (`<Route path=":pluginRoutePath" />`), so we cannot add nested routes.
 * Hash routing is the only feasible per-page URL scheme that survives
 * back/forward, copy-link, and external linking.
 *
 * | URL                                              | View                |
 * | ------------------------------------------------ | ------------------- |
 * | /{prefix}/llm-wiki                               | Landing             |
 * | /{prefix}/llm-wiki#concepts/transformer          | Page                |
 * | /{prefix}/llm-wiki#@concepts                     | Folder              |
 * | /{prefix}/llm-wiki?q=attention                   | Search              |
 * | /{prefix}/llm-wiki?q=attention#concepts/foo      | Search + page open  |
 * | /{prefix}/llm-wiki?view=setup                    | Setup walkthrough   |
 *
 * The `@` prefix on hashes is reserved for folder views and is therefore
 * not a valid leading character for a page slug.
 */

export type WikiTarget =
  | { kind: "landing" }
  | { kind: "page"; slug: string }
  | { kind: "folder"; folder: string }
  | { kind: "search"; query: string }
  | { kind: "setup" };

export type WikiLocation =
  | { kind: "landing" }
  | { kind: "page"; slug: string }
  | { kind: "folder"; folder: string }
  | { kind: "search"; query: string; slug: string | null }
  | { kind: "setup" };

/**
 * Resolve the active Company prefix.
 *
 * The plugin SDK types `PluginHostContext.companyPrefix` as
 * `string | null`, but Paperclip's dashboard mounts the
 * `dashboardWidget` slot with `<PluginSlotOutlet context={{ companyId
 * }} />` — only `companyId` is passed, so `companyPrefix` arrives as
 * `undefined` for that slot type. Other slot types (sidebar, page,
 * detailTab) pass it correctly.
 *
 * Rather than special-casing the dashboard widget, this helper reads
 * the value from the first path segment of `window.location` whenever
 * the context-supplied value is missing. Paperclip's company-scoped
 * routes are always `/{prefix}/...`; the only non-prefix top-level
 * segment is `instance` (instance settings), which we explicitly
 * exclude.
 *
 * Upstream: file `ui/src/pages/Dashboard.tsx:311` should pass the
 * full slot context (companyPrefix, projectId, …), matching how
 * sidebar / page / detailTab outlets are mounted elsewhere. Until
 * that lands, this fallback keeps every link working.
 */
export function resolveCompanyPrefix(
  fromContext: string | null | undefined,
): string | null {
  if (fromContext) return fromContext;
  if (typeof window === "undefined") return null;
  const seg = window.location.pathname.split("/").filter(Boolean)[0];
  return seg && seg !== "instance" ? seg : null;
}

export function wikiHref(
  companyPrefix: string | null | undefined,
  target: WikiTarget,
): string {
  // Guard against both null and undefined — the SDK type says null but
  // the dashboard widget's slot context omits the field entirely.
  if (companyPrefix === null || companyPrefix === undefined) return "#";
  const base = `/${companyPrefix}/llm-wiki`;
  switch (target.kind) {
    case "landing":
      return base;
    case "page":
      return `${base}#${encodeURIComponent(target.slug)}`;
    case "folder":
      return `${base}#@${encodeURIComponent(target.folder)}`;
    case "search":
      return `${base}?q=${encodeURIComponent(target.query)}`;
    case "setup":
      return `${base}?view=setup`;
  }
}

export function parseWikiLocation(): WikiLocation {
  if (typeof window === "undefined") return { kind: "landing" };
  const params = new URLSearchParams(window.location.search);
  if (params.get("view") === "setup") return { kind: "setup" };
  const q = params.get("q");
  const rawHash = window.location.hash.replace(/^#/, "");
  let slug = "";
  try {
    slug = rawHash ? decodeURIComponent(rawHash) : "";
  } catch {
    slug = rawHash;
  }
  if (q !== null && q.length > 0) {
    const splitSlug = slug && !slug.startsWith("@") ? slug : null;
    return { kind: "search", query: q, slug: splitSlug };
  }
  if (slug.startsWith("@")) {
    return { kind: "folder", folder: slug.slice(1) };
  }
  if (slug.length > 0) {
    return { kind: "page", slug };
  }
  return { kind: "landing" };
}

export function useWikiLocation(): WikiLocation {
  const [loc, setLoc] = React.useState<WikiLocation>(() => parseWikiLocation());
  React.useEffect(() => {
    function onChange(): void {
      setLoc(parseWikiLocation());
    }
    window.addEventListener("hashchange", onChange);
    window.addEventListener("popstate", onChange);
    return () => {
      window.removeEventListener("hashchange", onChange);
      window.removeEventListener("popstate", onChange);
    };
  }, []);
  return loc;
}

/**
 * Imperatively navigate to a wiki target. Used by components that need to
 * update the URL outside of an `<a href>` (form submits, keyboard handlers).
 *
 * Pushes a history entry so back/forward work, then dispatches popstate so
 * any mounted `useWikiLocation()` consumers re-read. The native popstate
 * event is not fired by `pushState` itself — we synthesise it.
 */
export function navigateTo(
  companyPrefix: string | null,
  target: WikiTarget,
): void {
  if (typeof window === "undefined") return;
  const href = wikiHref(companyPrefix, target);
  window.history.pushState({}, "", href);
  window.dispatchEvent(new PopStateEvent("popstate"));
}
