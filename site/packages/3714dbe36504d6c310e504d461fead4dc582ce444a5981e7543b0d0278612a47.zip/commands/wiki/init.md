---
description: Initialize a personal global LLM Wiki or one in this project.
argument-hint: "[--global] [--wiki-dir <name>] [--raw-dir <name>]"
---

Initialize a new LLM Wiki. Use the `llm-wiki` skill to:

1. Open `skills/llm-wiki/references/retrieval-setup.md` and ask its setup questions in one grouped interaction: global or project scope, wiki/raw paths, model-cache location, graph usage, and agent-memory integration. Treat `--global` as selecting `~/wiki/` and `~/wiki/raw/` unless I supplied other paths.
2. Explain that initialization installs and verifies the complete local runtime through `uv`: pinned FastEmbed, sqlite-vec, PyYAML, the `BAAI/bge-small-en-v1.5` model, the parse cache, and vectors for every existing section. No API key, provider consent, per-query fee, or outbound wiki/query text is involved.
3. After I answer, run the initializer against the selected location. For a project wiki, use `python "${CLAUDE_PLUGIN_ROOT}/skills/llm-wiki/scripts/init_wiki.py" "<absolute-project-root>"`. For the standard global layout, use `python "${CLAUDE_PLUGIN_ROOT}/skills/llm-wiki/scripts/init_wiki.py" "<absolute-home-directory>" --wiki-dir wiki --raw-dir wiki/raw`. Never run it against the plugin directory. Do not report setup complete unless its runtime JSON says `"status": "ready"`.
4. Walk me through the bootstrapped `SCHEMA.md`, set its location block to the selected paths, and ask whether I want to customize page types, tags, or workflow conventions.
5. Propose the matching agent-memory integration using `references/agent-memory-integration.md`: global instructions with a stable user-level path for a global wiki, or project instructions with relative paths for a project wiki. Show the exact addition and ask whether to append, create, or skip. Never write without approval.
6. Do not ingest a source yet. This command only completes an informed setup.

Arguments (if any): $ARGUMENTS
