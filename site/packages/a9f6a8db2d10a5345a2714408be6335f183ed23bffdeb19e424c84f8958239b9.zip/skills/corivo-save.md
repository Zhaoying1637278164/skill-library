---
description: 保存记忆到 Corivo 数据库
allowed-tools: Bash, AskUserQuestion
---

# Corivo 保存记忆

将重要信息保存到 Corivo 记忆数据库，供未来对话检索使用。

## 使用时机

当用户说以下内容时，考虑保存记忆：
- "保存这个"
- "记住"
- "记下来"
- "不要忘了"
- 需要长期保留的重要信息

## 支持的记忆类型

| 性质 (nature) | 说明 | 示例 |
|--------------|------|------|
| 事实 | 客观可验证的信息 | 用户生日、服务器配置、API 密钥 |
| 知识 | 学习到的概念 | React hooks 原理、API 用法、部署流程 |
| 决策 | 做出的技术选择 | 使用 PostgreSQL、选择 TypeScript |
| 指令 | 用户偏好 | 代码风格、命名习惯、周报格式 |

## 记忆格式

```
性质 · 领域 · 标识
```

### 性质 (nature) - 必选
- `事实` - 客观事实
- `知识` - 学习内容
- `决策` - 技术选择
- `指令` - 用户偏好

### 领域 (domain) - 必选
- `self` - 关于用户本人
- `people` - 关于其他人
- `project` - 关于项目
- `asset` - 资产/资源
- `knowledge` - 知识领域

## 执行步骤

0. **检测 Corivo 是否安装**：
   ```bash
   which corivo || echo "NOT_INSTALLED"
   ```

   - 如果返回 `NOT_INSTALLED`：提示用户安装
     ```
     [corivo] 首次使用需要安装 Corivo：

     npm install -g corivo
     corivo init

     安装完成后，继续对话即可。
     ```

   - 如果已安装：继续下一步

1. **检测数据库是否初始化**：
   ```bash
   corivo status --no-password 2>&1 | grep "未初始化"
   ```

   - 如果未初始化：提示用户
     ```
     [corivo] 数据库未初始化，请运行：corivo init
     ```

   - 如果已初始化：继续下一步

2. **确认保存内容**：向用户确认要保存的内容

3. **确定记忆类型**：根据内容选择合适的性质和领域

4. **执行保存命令**：
   ```bash
   corivo save --content "{content}" --annotation "{nature} · {domain} · {tag}" --no-password
   ```

5. **标注来源**：保存成功后回复 `[corivo] 已记录：{简要内容}`

## 示例对话

```
用户: 我叫晓力，是产品经理
Claude: 我来保存这个信息：
       性质：事实（关于用户的基本信息）
       领域：self（关于用户本人）

       [执行 corivo save]
       [corivo] 已记录：用户个人信息
```

```
用户: 我们决定用 React 而不是 Vue
Claude: 我来记录这个技术决策：
       性质：决策（技术选择）
       领域：project（项目相关）

       [执行 corivo save]
       [corivo] 已记录：前端框架选择 React
```

## 注意事项

- 避免保存临时信息（如"今天天气不错"）
- 避免保存过于琐碎的内容
- 重要信息优先保存
- 保存前先征得用户确认
- 所有命令自动添加 `--no-password` 跳过密码输入
