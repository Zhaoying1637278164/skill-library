#!/bin/sh
# long-comment-ok: documents three runtime layouts this shim must resolve across.
# Dispatch shim for the Carta hooks Go binary. Invoked by a plugin's
# hooks.json as `dispatch.sh <subcommand>`; forwards "$@" (subcommand +
# whatever else Claude Code appends) to the resolved native binary and
# passes stdin/stdout through untouched.
#
# Resolves the binary from "$here/bin/hooks-<os>-<arch>[.exe]", relative to
# THIS script's own path (not $PWD, which Claude Code does not guarantee).
# That single relative lookup covers both layouts that carry a bin/ sibling:
#   1. Published:  the publish pipeline injects dispatch.sh + bin/ side by side
#      into <plugin>/hooks/ — see scripts/pipeline/pipeline.py inject_hook_binaries
#   2. Monorepo:   tools/hooks/dispatch.sh run straight from a checkout, for
#      staff exercising hooks without a publish, where bin/ is checked in
#      alongside this script
#
# A third layout carries no bin/ sibling: a clone-based install copies the
# plugin dir verbatim, with no publish step. The second lookup below walks up
# to a sibling "marketplaces/" clone and tries its tools/hooks/bin/ instead.
#
# A fourth layout is a plain monorepo checkout (or a git worktree of one), where
# this script runs from plugins/<name>/hooks/ and the binary is committed at
# <repo>/tools/hooks/bin/. The third lookup walks up looking for that path, so
# --plugin-dir users and clone installs resolve a binary instead of silently
# failing open with every hook disabled.
#
# Fail-open is PER SUBCOMMAND, not a blanket PreToolUse allow: an event with
# no allow/deny concept (SessionStart, UserPromptSubmit) must not emit a
# PreToolUse-shaped payload, and vice versa. The shapes below match the Go
# binary's own generic fail-open in tools/hooks/internal/hookio (see
# hookio.PreToolUseAllow / hookio.SessionStartOK / hookio.UserPromptSubmitOK),
# so a missing/non-executable binary behaves identically to a handler error.
set -eu

here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
subcommand="${1:-}"

os=$(uname -s)
arch=$(uname -m)
case "$os" in
    Darwin) os=darwin ;;
    Linux) os=linux ;;
    MINGW* | MSYS* | CYGWIN*) os=windows ;;
    *) os="" ;;
esac
case "$arch" in
    arm64 | aarch64) arch=arm64 ;;
    *) arch=amd64 ;;
esac

bin=""
if [ -n "$os" ]; then
    candidate="$here/bin/hooks-${os}-${arch}"
    [ "$os" = windows ] && candidate="${candidate}.exe"
    if [ -x "$candidate" ]; then
        bin="$candidate"
    fi
fi

# Case 3: walk up looking for a "marketplaces" dir next to an ancestor (a
# sibling of the cache dir a plugin install copies from). Bounded to 8 levels.
if [ -z "$bin" ] && [ -n "$os" ]; then
    walk="$here"
    depth=0
    while [ "$depth" -lt 8 ] && [ "$walk" != "/" ]; do
        parent=$(dirname -- "$walk")
        sibling="$parent/marketplaces"
        if [ -d "$sibling" ]; then
            for mkt in "$sibling"/*/tools/hooks/bin; do
                [ -d "$mkt" ] || continue
                candidate="$mkt/hooks-${os}-${arch}"
                [ "$os" = windows ] && candidate="${candidate}.exe"
                if [ -x "$candidate" ]; then
                    bin="$candidate"
                    break
                fi
            done
            break
        fi
        walk="$parent"
        depth=$((depth + 1))
    done
fi

# Case 4: a monorepo checkout or a git worktree of one — this script sits at
# plugins/<name>/hooks/ and the binary is committed at <repo>/tools/hooks/bin/.
# Same 8-level bound as case 3; checks "$here" itself first so tools/hooks/
# also resolves when run straight from the source dir.
if [ -z "$bin" ] && [ -n "$os" ]; then
    walk="$here"
    depth=0
    while [ "$depth" -lt 8 ] && [ "$walk" != "/" ]; do
        candidate="$walk/tools/hooks/bin/hooks-${os}-${arch}"
        [ "$os" = windows ] && candidate="${candidate}.exe"
        if [ -x "$candidate" ]; then
            bin="$candidate"
            break
        fi
        walk=$(dirname -- "$walk")
        depth=$((depth + 1))
    done
fi

if [ -n "$bin" ]; then
    exec "$bin" "$@"
fi

# No binary resolved — fail open with the shape the invoking event requires.
case "$subcommand" in
    capture-model | inject-context | prune-session-data)
        # SessionStart: no allow/deny concept, but Claude Code expects the
        # hookSpecificOutput envelope back (hookio.SessionStartOK).
        printf '%s' '{"hookSpecificOutput":{"hookEventName":"SessionStart"}}'
        exit 0
        ;;
    capture-active-skill | inject-instrumentation)
        # PreToolUse: must explicitly allow, or Claude Code blocks the tool call.
        printf '%s' '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow"}}'
        exit 0
        ;;
    cache-commands | track-corporation)
        # PostToolUse: silently best-effort, but still expects the envelope back.
        printf '%s' '{"hookSpecificOutput":{"hookEventName":"PostToolUse"}}'
        exit 0
        ;;
    capture-model-switch)
        # PostModelSwitch: fires async, cannot block, but still expects the
        # hookSpecificOutput envelope back (hookio.PostModelSwitchOK).
        printf '%s' '{"hookSpecificOutput":{"hookEventName":"PostModelSwitch"}}'
        exit 0
        ;;
    capture-slash-skill)
        # UserPromptSubmit: silently best-effort, no stdout contract.
        exit 0
        ;;
    *)
        # Unknown subcommand: mirror the Go binary's own behavior for an
        # unregistered handler name — diagnostic on stderr, empty stdout,
        # exit 0 (no registered event to fail open into).
        echo "dispatch.sh: no hooks binary found for ${os:-unknown os}/${arch}, and unknown subcommand '$subcommand'" >&2
        exit 0
        ;;
esac
