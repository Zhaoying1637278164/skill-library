# Spec To Tools

Use this when the input is an OpenAPI document, Swagger spec, Postman collection, endpoint list, or product brief.

It also applies when the "spec" is really one of these:

- SDK docs that link out to source repos
- runtime / RPC documentation
- example applications
- architecture notes with concrete commands, configs, and method names

## Extract First

Before writing code, pull out:

- base URL and authentication scheme
- the actual integration target the finished app should call
- main entities and identifiers
- read operations vs write operations
- pagination, filters, and search parameters
- user-specific inputs the host must provide
- confirmation or safety requirements
- rate limits, async jobs, and polling behavior
- common error shapes
- whether the docs actually publish an end-user API or mainly document a builder workflow

If a detail is missing, do not invent it. Leave a TODO or ask for the smallest missing piece.

## Find The Real Integration Target

Prefer the nearest executable product surface over explanatory documentation.

Ask these questions early:

- What will the finished app actually call?
- Is there a concrete service contract such as REST, GraphQL, JSON-RPC, gRPC, webhook delivery, or a stable CLI protocol?
- Is the target hosted, self-hosted, customer-provided, or only available through a local example stack?
- If the source is an SDK or example project, does it expose a service that clients use after the builder sets it up?

Useful rule of thumb:

- If users can point the app at a running thing, build the client for that thing.
- If no running thing exists yet, only then consider a builder or reference assistant.

## Decide The App Type Early

Choose one of these before naming tools:

- **Product client**: the source exposes a real callable product surface, even if it is self-hosted or example-backed.
- **Execution assistant**: the docs expose quote/build/submit flows and host or wallet handoff matters.
- **Builder assistant**: the docs mostly explain how to build on top of a network, SDK, or runtime.

Builder assistants are valid outcomes, but they are the fallback, not the default. If the docs mostly point to SDK repos and example stacks, first check whether those repos produce a runnable interface that the app can call.

## Map Endpoints To Model-Facing Tools

Do not default to one tool per endpoint. Instead, group endpoints by user intent.

Before implementation, write down the proposed toolset explicitly:

- tool name
- what the user would ask for that should trigger it
- key inputs
- key outputs
- whether it reads, prepares, or writes
- whether it depends on a live target, wallet, signer, or host callback

Treat this as a required checkpoint. If the proposed toolset is weak, too docs-oriented, too endpoint-shaped, or not clearly tied to user intent, revise it before writing code.

When choosing the first implementation:

- optimize for the primary user workflow first
- keep the toolset as small as possible while still making that workflow work end to end
- prefer app-specific high-value actions over broad protocol coverage when the source makes the important workflow obvious
- avoid schema or discovery tools unless they are needed to support the chosen workflow
- only mirror the wider API surface if the user asked for broad coverage

Good mappings:

- several lookup endpoints -> `search_*` or `get_*`
- multiple list and detail calls -> `resolve_*` then `get_*`
- quote + build + submit endpoints -> `get_*_quote`, `build_*`, `submit_*`
- create side effects -> preview/build first, then explicit submit after confirmation
- standard runtime interfaces -> wrap the standard methods first, then add extension hooks or custom methods
- SDK + example repo + config + RPC docs -> `list_*_resources`, `get_*_overview`, `get_*_quickstart`, `get_*_rpc_surface`, `get_*_defaults`
- example-backed transactional app -> one health/connectivity tool, a few read tools for key state, one write tool for the main action, and one verification tool for the outcome

Less useful mappings:

- raw REST verbs as tool names
- exposing every transport detail directly to the model
- returning unnormalized upstream payloads when only 20 percent of the fields matter
- choosing a docs-summary tool surface when a real client could be built instead
- inventing public user actions that are not actually documented by the source
- building a large first-pass toolset before proving the primary user workflow

## Preamble Rubric

A strong preamble usually includes:

- `## Role`
- `## Capabilities`
- `## Workflow`
- `## Rules`

For execution apps, spell out:

- when confirmation is required
- which tool comes first
- which tool hands off to the wallet or host
- what must be preserved exactly between steps

## Output Shape Rubric

Return the minimum stable JSON the model needs for the next step.

Good result shapes often include:

- a top-level echo of the key input
- normalized identifiers
- concise summaries
- arrays of candidate objects
- `requires_selection`, `selection_reason`, or `next_step_hint` when ambiguity remains

When the host must take over (sign a transaction, sign typed data, simulate a batch), return a structured `ToolReturn` envelope rather than a prose `SYSTEM_NEXT_ACTION` field. The runtime resolves the route, splices wallet-callback artifacts into the next tool's args, and injects the continuation prompt — see [host-routes.md](host-routes.md) for the full shape.

```rust
use aomi_sdk::{RouteStep, ToolReturn};

ToolReturn::with_routes(value, [
    RouteStep::on_return("evm_commit_message", typed_data)
        .bind_as("signature")
        .prompt("Suggested next step: sign the typed data."),
    RouteStep::on_bound_event("submit_my_order", submit_template, "signature")
        .prompt("Wallet signed — submit the order now."),
])
```

The route's structured fields are the contract; the runtime never parses prose.

Avoid:

- leaking auth credentials
- giant raw payloads
- mixed naming conventions from multiple upstream APIs
- claiming success before the final submit step succeeds

## Suggested Build Loop

1. Read the spec and summarize the app contract.
2. Identify the concrete service or runtime target.
3. Propose the tool surface in concrete user-facing terms.
4. Scaffold or patch `lib.rs`, `client.rs`, and `tool.rs`.
5. Normalize auth, models, and errors in `client.rs`.
6. Implement small, strongly typed tools.
7. Build and test.
8. If the target is available, verify a short end-to-end scenario:
   - connectivity
   - key read
   - key write when applicable
   - post-write verification
9. Update docs or examples if the repo includes them.

## Current OpenAPI Pipeline

The current `aomi-build` Rust CLI has a staged OpenAPI path. Use it when the input is a public OpenAPI/Swagger spec:

```bash
aomi-build gen-specs <platform> --from-url <url>     # or --source all|well-known|apis-guru|github
aomi-build gen-client <platform> --force             # progenitor client
aomi-build gen-tool <platform> --all --force         # mechanical tool stubs
aomi-build compile --app <platform>
```

`aomi-build new-app <platform> --from-url <url>` is the one-shot orchestrator for the same stages plus a cargo build.

Default mode is **app-local**:

- editable source spec: `apps/<platform>/openapi.yaml`
- generated debug spec: `apps/<platform>/openapi.preprocessed.yaml`
- generated Rust client: `apps/<platform>/src/client/`
- curated app layer: `apps/<platform>/src/lib.rs` and `apps/<platform>/src/tool.rs`

Use `--shared` only when the same generated client will be reused by multiple apps. Shared mode moves specs to `ext/specs/<platform>.yaml` and clients to `ext/src/<platform>/`.

Important rules:

- Edit `openapi.yaml`, not `openapi.preprocessed.yaml`; the preprocessed file is overwritten by `gen-client` and exists to debug progenitor failures.
- `gen-tool` names tools from `operationId` and can produce endpoint-shaped stubs. Treat those stubs as scaffolding, not final UX.
- `progenitor-client` and the generated client's dependency markers belong in `Cargo.toml`; match the generated client's `reqwest` version.
- Use `aomi-build test-schema <platform>` for live schema conformance. It is GET-only by default; pass `--write` only against safe sandbox/testnet APIs.
- Use `aomi-build tighten-spec <platform> --in-place` when loose `additionalProperties: true` schemas make generated responses too untyped.

If the app is brand new in `aomi-sdk`, validate it with `cargo run -p aomi-sdk --features cli --bin aomi-build -- compile --app <name>`. A direct `cargo build --manifest-path apps/<name>/Cargo.toml` is still the fastest crate-level compile check when debugging package errors. After bumping `sdk/Cargo.toml` `package.version`, all apps must be rebuilt because the host enforces an exact-match SDK version gate.
