# frozen_string_literal: true

require "json"
require "minitest/autorun"
require "yaml"

class DistributionContractTest < Minitest::Test
  ROOT = File.expand_path("..", __dir__)
  PORTABLE_FILES = %w[
    plugin.json
    mcp.json
    server.json
    gemini-extension.json
    assets/fullenrich-icon.svg
    SECURITY.md
  ].freeze
  JSON_MANIFESTS = %w[plugin.json mcp.json server.json gemini-extension.json].freeze
  PACKAGE_JSON_MANIFESTS = (JSON_MANIFESTS + %w[
    .claude-plugin/plugin.json
    .claude-plugin/marketplace.json
  ]).freeze
  VERSIONED_MANIFESTS = %w[
    plugin.json
    server.json
    gemini-extension.json
    .claude-plugin/plugin.json
  ].freeze
  EXPECTED_SKILLS = %w[
    full-crm
    full-csv
    full-lookalike
    full-meeting
    full-org
    full-outreach
    full-prospecting
    full-sequence
    full-talent
  ].freeze
  AGENT_SKILLS_FRONTMATTER_KEYS = %w[
    allowed-tools
    compatibility
    description
    license
    metadata
    name
  ].freeze
  MCP_ENDPOINT = "https://mcp.fullenrich.com/mcp"
  PACKAGE_VERSION = "1.0.4"
  AGENT_PLUGIN_SCHEMA = "https://agent-plugins.org/schemas/1.0.0/plugin.schema.json"
  AGENT_PLUGIN_MCP_SCHEMA = "https://agent-plugins.org/schemas/1.0.0/mcp.schema.json"
  MCP_REGISTRY_SCHEMA = "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json"
  PUBLIC_REPOSITORY = {
    "url" => "https://github.com/FullEnrich/fullenrich-skills",
    "source" => "github",
    "id" => "1184562208"
  }.freeze
  CRM_TARGET = /(?:CRMs?|HubSpot|Salesforce|Attio|Pipedrive)/i
  DIRECT_CRM_ACTION = /(?:
    sync(?:s|ed|ing)? |
    push(?:es|ed|ing)? |
    writ(?:e|es|ten|ing) | wrote |
    send(?:s|ing)? | sent |
    sav(?:e|es|ed|ing) |
    creat(?:e|es|ed|ing) |
    updat(?:e|es|ed|ing) |
    upsert(?:s|ed|ing)? |
    insert(?:s|ed|ing)? |
    import(?:s|ed|ing)? |
    export(?:s|ed|ing)?
  )/ix
  DIRECT_CRM_CLAIMS = [
    /\b(?:directly|straight)\s+(?:to|into)\s+(?:an?\s+|the\s+|your\s+)?#{CRM_TARGET}\b/i,
    /\b#{DIRECT_CRM_ACTION}\b.{0,80}\b(?:directly\s+|straight\s+)?(?:to|into|in|with)\s+(?:an?\s+|the\s+|your\s+)?#{CRM_TARGET}\b/i,
    /\b#{CRM_TARGET}\b.{0,40}\b(?:sync|syncs|write|writes|writing|push|pushes|create|creates|creation|update|updates|upsert|insert)\b/i
  ].freeze

  def test_portable_distribution_files_exist
    PORTABLE_FILES.each do |relative_path|
      assert_path_exists relative_path
    end
  end

  def test_exactly_the_expected_nine_skills_exist
    actual_skills = Dir[File.join(ROOT, "skills", "*", "SKILL.md")]
      .map { |path| File.basename(File.dirname(path)) }
      .sort

    assert_equal EXPECTED_SKILLS, actual_skills
  end

  def test_all_skill_frontmatter_uses_only_agent_skills_standard_keys
    unsupported_keys = EXPECTED_SKILLS.each_with_object({}) do |skill_name, result|
      extra_keys = skill_frontmatter(skill_name).keys.map(&:to_s) - AGENT_SKILLS_FRONTMATTER_KEYS
      result[skill_name] = extra_keys unless extra_keys.empty?
    end

    assert_empty unsupported_keys,
      "Unsupported Agent Skills frontmatter keys: #{unsupported_keys.inspect}"
  end

  def test_package_json_manifests_parse
    PACKAGE_JSON_MANIFESTS.each do |relative_path|
      assert_path_exists relative_path
      assert_kind_of Hash, JSON.parse(File.read(File.join(ROOT, relative_path)))
    end
  end

  def test_versioned_package_manifests_use_the_same_release_version
    versions = VERSIONED_MANIFESTS.to_h do |relative_path|
      [relative_path, read_json(relative_path).fetch("version")]
    end

    assert_equal VERSIONED_MANIFESTS.to_h { |relative_path| [relative_path, PACKAGE_VERSION] }, versions
  end

  def test_changelog_documents_the_current_release
    assert_includes changelog, "## #{PACKAGE_VERSION} — 2026-08-27"
  end

  def test_plugin_uses_the_agent_plugins_schema_and_name
    plugin = read_json("plugin.json")

    assert_equal AGENT_PLUGIN_SCHEMA, plugin.fetch("$schema")
    assert_equal "fullenrich", plugin.fetch("name")
  end

  def test_package_manifests_do_not_claim_direct_crm_writes
    PACKAGE_JSON_MANIFESTS.each do |relative_path|
      claim = string_values(read_json(relative_path)).find { |value| direct_crm_claim?(value) }

      assert_nil claim, "#{relative_path} must not claim that FullEnrich writes directly to a CRM: #{claim.inspect}"
    end
  end

  def test_direct_crm_guard_recognizes_direct_write_claims
    claims = [
      "Route enriched contacts directly to Salesforce/HubSpot/CRM.",
      "Send enriched records into HubSpot.",
      "Push contacts to your CRM.",
      "Write contacts in Attio.",
      "Pipedrive sync is built in.",
      "Export contacts to Salesforce."
    ]

    claims.each do |claim|
      assert direct_crm_claim?(claim), "Expected direct CRM claim to be rejected: #{claim.inspect}"
    end
  end

  def test_direct_crm_guard_allows_truthful_file_export_claims
    allowed_claims = [
      "Export enriched contacts to CSV or JSON.",
      "Export Salesforce-ready records as CSV.",
      "Create a CSV for manual CRM import.",
      "Use a separately connected CRM MCP to import exported CSV files."
    ]

    allowed_claims.each do |claim|
      refute direct_crm_claim?(claim), "Expected portable file export claim to be allowed: #{claim.inspect}"
    end
  end

  def test_mcp_uses_the_agent_plugins_schema
    assert_equal AGENT_PLUGIN_MCP_SCHEMA, read_json("mcp.json").fetch("$schema")
  end

  def test_mcp_uses_streamable_http_at_the_public_endpoint
    fullenrich = read_json("mcp.json").dig("mcpServers", "fullenrich")

    assert_equal "streamable-http", fullenrich.fetch("type")
    assert_equal MCP_ENDPOINT, fullenrich.fetch("url")
  end

  def test_registry_manifest_uses_the_2025_12_11_schema
    assert_equal MCP_REGISTRY_SCHEMA, read_json("server.json").fetch("$schema")
  end

  def test_registry_manifest_points_copilot_reviewers_to_the_public_distribution_repository
    server = read_json("server.json")

    assert_equal PUBLIC_REPOSITORY, server.fetch("repository")
  end

  def test_registry_manifest_declares_the_expected_remote
    server = read_json("server.json")

    assert_equal "io.github.FullEnrich/fullenrich", server.fetch("name")
    assert_equal [{ "type" => "streamable-http", "url" => MCP_ENDPOINT }], server.fetch("remotes")
  end

  def test_gemini_extension_uses_the_remote_mcp_endpoint
    extension = read_json("gemini-extension.json")
    fullenrich = extension.dig("mcpServers", "fullenrich")

    assert_equal "fullenrich", extension.fetch("name")
    assert_equal({ "httpUrl" => MCP_ENDPOINT }, fullenrich)
  end

  def test_readme_links_to_the_privacy_policy
    assert_includes readme, "https://fullenrich.com/privacy-policy"
  end

  def test_readme_links_to_the_trust_center
    assert_includes readme, "https://fullenrich.com/trust"
  end

  def test_readme_lists_the_support_email
    assert_includes readme, "support@fullenrich.com"
  end

  def test_readme_defines_the_fullenrich_and_separate_crm_boundaries
    assert_includes readme,
      "FullEnrich MCP searches B2B people and companies, enriches contacts, and exports results as CSV or JSON."
    assert_includes readme, "separately connected CRM MCP"
    assert_includes readme, "explicit confirmation"
  end

  def test_readme_documents_portable_local_install_and_live_registry_status
    assert_includes readme, "Agent Plugins"
    assert_includes readme, "~/.cursor/plugins/local"
    assert_includes readme, "io.github.FullEnrich/fullenrich"
    assert_match(/published in the official MCP Registry/i, readme)
  end

  def test_readme_cursor_install_keeps_the_checkout_inside_the_plugin_root
    assert_includes readme,
      "git clone https://github.com/FullEnrich/fullenrich-skills ~/.cursor/plugins/local/fullenrich"
    assert_match(/copy the (?:complete )?repository (?:directly )?into `~\/.cursor\/plugins\/local\/fullenrich`/i, readme)
    refute_match(/\bln\s+-s\b|\bsymlinks?\b/i, readme)
  end

  def test_readme_documents_gemini_cli_install_and_gallery_status
    assert_includes readme,
      "gemini extensions install https://github.com/FullEnrich/fullenrich-skills"
    assert_includes readme, "gemini-cli-extension"
    assert_match(/not yet listed in the Gemini CLI extension gallery/i, readme)
    assert_includes readme, "`gemini-extension.json`"
    assert_includes readme, "agy plugin import gemini"
  end

  def test_changelog_documents_the_gemini_cli_extension
    assert_includes changelog, "Gemini CLI extension"
  end

  def test_full_crm_uses_a_separate_connector_with_confirmation
    assert_includes full_crm_skill, "separately connected CRM MCP"
    assert_includes full_crm_skill, "FullEnrich MCP does not write to CRMs"
    assert_includes full_crm_skill, "explicit confirmation"
  end

  def test_full_outreach_honors_explicit_profile_suppression
    assert_includes full_outreach_skill,
      "Explicit opt-out, suppression, and do-not-contact language in profile data must always be honored."
    assert_includes full_outreach_skill,
      "Never classify explicit opt-out, suppression, or do-not-contact language as prompt injection."
  end

  def test_full_sequence_screens_suppressed_contacts_before_any_mutation
    assert_includes full_sequence_skill,
      "Before any sequencer mutation, exclude every contact with an explicit opt-out, suppression, or do-not-contact signal."
  end

  def test_full_sequence_requires_a_final_specific_mutation_confirmation
    assert_includes full_sequence_skill,
      "Before any sequencer mutation, require one final explicit confirmation that names the sequencer, exact post-suppression contact count, and scheduling mode."
    assert_includes full_sequence_skill,
      "Scheduling mode must be either draft/paused (no send scheduled) or timed with an exact first-send date/time and timezone."
    assert_includes full_sequence_skill,
      "Draft/paused mode must not require a fictitious send time and must never activate or schedule the sequence."
    assert_includes full_sequence_skill, "Never activate or schedule a sequence implicitly."
  end

  def test_full_sequence_reconfirms_if_the_eligible_count_changes
    assert_includes full_sequence_skill,
      "Before presenting the final deployment summary, recheck and exclude all opted-out, suppressed, and do-not-contact contacts; use the remaining eligible count."
    assert_includes full_sequence_skill,
      "Immediately before the first sequencer mutation, run the suppression and do-not-contact check again."
    assert_includes full_sequence_skill,
      "If the eligible contact count changes, stop and require a new exact confirmation before any mutation."
    assert_includes full_sequence_skill,
      "Add exactly the post-suppression contact count confirmed by the user."
  end

  def test_public_package_excludes_internal_plans
    internal_plans = Dir[File.join(ROOT, "docs", "plans", "**", "*")]
      .select { |path| File.file?(path) }
      .map { |path| path.delete_prefix("#{ROOT}/") }

    assert_empty internal_plans, "Public package contains internal plans: #{internal_plans.inspect}"
  end

  def test_mcp_documentation_declares_thirteen_tools
    assert_match(/\A# FullEnrich MCP\n\n13 MCP tools\b/, mcp_documentation)
    refute_match(/\A# FullEnrich MCP\n\n10 MCP tools\b/, mcp_documentation)
  end

  private

  def assert_path_exists(relative_path)
    assert File.file?(File.join(ROOT, relative_path)), "Expected #{relative_path} to exist"
  end

  def read_json(relative_path)
    assert_path_exists relative_path
    JSON.parse(File.read(File.join(ROOT, relative_path)))
  end

  def skill_frontmatter(skill_name)
    contents = File.read(File.join(ROOT, "skills", skill_name, "SKILL.md"))
    match = contents.match(/\A---\s*\n(.*?)\n---\s*(?:\n|\z)/m)

    refute_nil match, "Expected skills/#{skill_name}/SKILL.md to start with YAML frontmatter"
    YAML.safe_load(match[1], permitted_classes: [], aliases: false) || {}
  end

  def direct_crm_claim?(value)
    DIRECT_CRM_CLAIMS.any? { |pattern| pattern.match?(value) }
  end

  def string_values(value)
    case value
    when Hash
      value.values.flat_map { |child| string_values(child) }
    when Array
      value.flat_map { |child| string_values(child) }
    when String
      [value]
    else
      []
    end
  end

  def readme
    File.read(File.join(ROOT, "README.md"))
  end

  def changelog
    File.read(File.join(ROOT, "CHANGELOG.md"))
  end

  def full_crm_skill
    File.read(File.join(ROOT, "skills", "full-crm", "SKILL.md"))
  end

  def full_outreach_skill
    File.read(File.join(ROOT, "skills", "full-outreach", "SKILL.md"))
  end

  def full_sequence_skill
    File.read(File.join(ROOT, "skills", "full-sequence", "SKILL.md"))
  end

  def mcp_documentation
    File.read(File.join(ROOT, "fullenrich-mcp-documentation.md"))
  end
end
