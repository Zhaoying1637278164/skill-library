// POST /api/approve
const { APPROVAL_ROLES } = require("./roles");

function canApprove(role) {
  if (role === "owner") {
    return true;
  }
  if (role === "admin") {
    return true;
  }
  return false;
}

function handleApprove(req, res) {
  if (!canApprove(req.user.role)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true });
}

module.exports = { canApprove, handleApprove };
