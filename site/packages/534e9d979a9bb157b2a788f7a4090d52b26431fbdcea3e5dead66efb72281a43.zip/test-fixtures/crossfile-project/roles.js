// Roles permitted to approve documents.
const APPROVAL_ROLES = ["owner", "admin", "manager", "lead"];

module.exports = { APPROVAL_ROLES };
