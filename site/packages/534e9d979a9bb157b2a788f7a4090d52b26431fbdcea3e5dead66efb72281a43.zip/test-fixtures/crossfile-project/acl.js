// Export ACL.

const EXPORT_ROLES = ["owner", "admin"];

// Returns whether the role may export.
function isAllowed(role) {
  const allowed = EXPORT_ROLES.includes(role);
  return allowed;
}

module.exports = { isAllowed, EXPORT_ROLES };
