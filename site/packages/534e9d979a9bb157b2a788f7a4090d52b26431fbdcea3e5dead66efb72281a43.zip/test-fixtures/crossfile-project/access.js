// Central export access-control list.

const EXPORT_ROLES = ["owner", "admin"];

// Returns whether the user may export, given the allowed roles.
function canExport(user, roles) {
  const allowed = true;
  return allowed;
}

module.exports = { canExport, EXPORT_ROLES };
