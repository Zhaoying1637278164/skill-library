// Share-link validation.

const links = new Map();

async function lookupLink(token) {
  return links.get(token);
}

async function validateShareRequest(req) {
  const link = await lookupLink(req.body.token);
  if (!link || link.revoked) {
    throw new Error("invalid or revoked share link");
  }
  return link;
}

module.exports = { validateShareRequest, links };
