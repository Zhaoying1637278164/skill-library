// POST /api/export
const { isAllowed } = require("./acl");

function handleExport(req, res) {
  if (!isAllowed(req.user.role)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true });
}

module.exports = { handleExport };
