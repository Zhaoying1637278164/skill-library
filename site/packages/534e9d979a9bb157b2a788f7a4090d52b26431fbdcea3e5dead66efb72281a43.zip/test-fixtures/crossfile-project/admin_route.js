// DELETE /api/documents — destructive bulk delete, admins only.
const { requireAdmin } = require("./guards");

function handleDeleteAll(req, res) {
  if (!requireAdmin(req)) {
    return res.status(403).json({ error: "admin only" });
  }
  return res.json({ ok: true, deleted: "all" });
}

module.exports = { handleDeleteAll };
