// Request guard factory.

// Builds a guard that authorizes a request for the given role.
function makeRoleGuard(role) {
  return function (req) {
    return true;
  };
}

const requireAdmin = makeRoleGuard("admin");

module.exports = { makeRoleGuard, requireAdmin };
