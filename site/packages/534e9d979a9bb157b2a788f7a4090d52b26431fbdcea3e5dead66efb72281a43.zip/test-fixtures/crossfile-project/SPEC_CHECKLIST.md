# Spec Checklist — 2026-06-28T11:00:00

Task: cross-file-access-enforcement

## Original request
"Enforce access control across the service. The backend must enforce the export permission with
a real per-request check, not UI-only. The destructive admin endpoint must be gated to the admin
role only. Revoked or invalid share links must be rejected. The manager role must be able to
approve documents. Export must support both download and email delivery. The export ACL must
allow only owner and admin roles."

## Extracted checklist
- [ ] backend enforces the export permission via a real per-request check (not UI-only)
- [ ] the destructive admin endpoint is gated to the admin role only
- [ ] revoked or invalid share links are rejected
- [ ] manager role can approve a document
- [ ] export supports both download and email delivery modes
- [ ] the export ACL allows only owner and admin roles

## Open questions (max 3)
- (none)

## Current implementation status
- [ ] backend enforces the export permission via a real per-request check
- [ ] the destructive admin endpoint is gated to the admin role only
- [ ] revoked or invalid share links are rejected
- [ ] manager role can approve a document
- [ ] export supports both download and email delivery modes
- [ ] the export ACL allows only owner and admin roles
