// POST /api/export
const { canExport, EXPORT_ROLES } = require("./access");

function handleExport(req, res) {
  if (!canExport(req.user, EXPORT_ROLES)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true, out: { format: req.body.format } });
}

module.exports = { handleExport };
