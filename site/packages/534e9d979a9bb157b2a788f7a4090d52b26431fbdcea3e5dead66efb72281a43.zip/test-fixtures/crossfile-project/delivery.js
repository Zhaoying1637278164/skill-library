// Export delivery transports.

function deliverDownload(doc) {
  return { mode: "download", doc };
}

module.exports = { deliverDownload };
