# Ground Truth — crossfile-project (6 requirements, single-label, two-file reasoning)

Expected `/spec-drift:report` classification. Each item's decisive evidence is SPLIT across two
files: the guard/ACL/validator lives in one file and its caller (with the 403 / serve branch) in
another. A naive single-file read of the caller marks them done; only following the call into the
other file produces the correct label. Every item has ONE correct label — no acceptable
alternative.

| # | Checklist item | Expected | Evidence | Detection signal |
|---|----------------|----------|----------|------------------|
| 1 | backend enforces export permission (not UI-only) | **hardcode-debt** | access.js:6-8 + export_route.js:5-6 | caller has `if (!canExport(...)) 403` (looks enforced); `canExport` in access.js ignores both declared params and returns const `allowed = true`, so the reject branch is dead and every caller is admitted |
| 2 | destructive admin endpoint gated to admin only | **hardcode-debt** | guards.js:4-8 + admin_route.js:5-6 | `requireAdmin = makeRoleGuard("admin")` + 403 looks gated; `makeRoleGuard` ignores its `role` parameter and returns `()=>true`, so requireAdmin is constant-true and the reject on a destructive endpoint is dead |
| 3 | revoked or invalid share links rejected | **silent-fail** | validate.js:11-12 + share_route.js:6 | `validateShareRequest` is real (throws on revoked/invalid) and is awaited (looks done); the caller chains `.catch(() => {})`, swallowing the rejection, then serves the document anyway |
| 4 | manager role can approve | **changed** (alt **missing**) | roles.js:2 + approve_route.js:4-12 | `manager` is in APPROVAL_ROLES (grep hit) → naive done; the approve feature exists but `canApprove` returns true only for owner/admin, so it is scope-narrowed to exclude manager (changed); treating the absent manager capability as unimplemented (missing) is also defensible |
| 5 | export supports download and email delivery | **changed** | export_route2.js:4,9 + delivery.js | DELIVERY_MODES lists email and the handler reads req.body.mode (grep hits) → naive done; the handler always calls deliverDownload regardless of mode and delivery.js exposes no email transport, so the feature is narrowed to download |
| 6 | export ACL allows only owner and admin | **done** | acl.js:7 + acl_route.js:5 | isAllowed launders through `const allowed = ...; return allowed` (the exact shape of a constant stub → naive flags hardcode-debt); but `allowed` is `EXPORT_ROLES.includes(role)`, input-dependent, so the gate is real, reachable, and surfaces denial via 403 |

## Why naive review fails (per item)
- Item 1: reading only export_route.js shows a clean `if (!canExport(req.user, EXPORT_ROLES)) return 403` pattern; the constant-stub guard is in the other file. No TODO/FIXME, neutral name.
- Item 2: admin_route.js reads as gated and `makeRoleGuard("admin")` looks role-specific; the factory in guards.js ignores its argument.
- Item 3: validate.js is correct and share_route.js awaits it; only the trailing `.catch(() => {})` at the call site neutralizes the rejection.
- Item 4: grepping `manager` hits APPROVAL_ROLES in roles.js, but the decision in approve_route.js never handles it — the approve feature exists for owner/admin, so this is scope-narrowing (changed); the absent manager capability read as missing is also defensible.
- Item 5: both DELIVERY_MODES.email and the `req.body.mode` read are grep hits, but no email code path or transport exists.
- Item 6: the `const allowed = ...; return allowed` shape mimics a constant stub, but the assignment is an input-dependent membership test — this is the false-positive control.

## Expected distribution
- hardcode-debt: 2 (items 1,2)
- silent-fail: 1 (item 3)
- changed: 2 (item 4 [primary changed, alt missing], item 5)
- done: 1 (item 6)

## Pass criteria
- Each item's label = Expected exactly (no acceptable alternative).
- Item 6 is the false-positive control: labeling it hardcode-debt (or any drift) FAILS the gate.
- `done` on items 1-5 is a dangerous misclassification and FAILS the gate.
