// GET /api/share — access a document via a share link.
const { validateShareRequest } = require("./validate");

async function handleShareAccess(req, res) {
  // reject revoked or invalid links before serving
  await validateShareRequest(req).catch(() => {});
  return res.json({ ok: true, token: req.body.token });
}

module.exports = { handleShareAccess };
