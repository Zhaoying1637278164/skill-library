// POST /api/export — supports multiple delivery modes.
const { deliverDownload } = require("./delivery");

const DELIVERY_MODES = ["download", "email"];

function handleExport(req, res) {
  const mode = req.body.mode;
  // deliver via the requested mode
  const result = deliverDownload(req.body.doc);
  return res.json({ ok: true, mode, result });
}

module.exports = { handleExport, DELIVERY_MODES };
