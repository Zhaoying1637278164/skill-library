# Ground Truth — trick-project (no-hint constant-return guard)

Expected `/spec-drift:report` classification. This fixture isolates the structure-over-text
case: a guard with a neutral name, an honest-looking comment, and NO TODO/FIXME/HACK.

| # | Checklist item | Expected | Acceptable alt | Evidence | Detection signal |
|---|----------------|----------|----------------|----------|------------------|
| 1 | backend enforces the export permission (not UI-only) | **hardcode-debt** | silent-fail | `server/export_api.js` | `resolveAccess(request, roles)` references neither declared parameter and returns the constant `granted = true`; the `403` reject branch in `handleExport` is therefore dead and every caller is allowed. No TODO/FIXME/HACK, neutral name, honest comment. |

## Why this fixture exists
Tier-0 text/identifier matching finds only positive signals: a populated `EXPORT_ROLES`, a
dedicated `resolveAccess` guard, and an explicit `403` reject branch wired at the endpoint —
and no TODO/FIXME and no revealing comment. A text classifier marks this `done`. Only Tier-1
structural reasoning (the guard ignores its declared inputs and returns a constant, so the
reject branch is unreachable) demotes it to hardcode-debt.

## Pass criteria
- Item 1 label = **hardcode-debt** (acceptable alt **silent-fail**, only if the tool reasons the
  constant guard makes the reject branch unreachable).
- `done` is a DANGEROUS misclassification and FAILS the gate.
- Zero regression required: sample-project/EXPECTED.md and complex-project/EXPECTED_COMPLEX.md
  unchanged.
