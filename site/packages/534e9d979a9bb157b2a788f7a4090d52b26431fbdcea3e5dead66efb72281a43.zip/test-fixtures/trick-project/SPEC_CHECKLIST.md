# Spec Checklist — 2026-06-28T09:00:00

Task: export-permission-enforcement

## Original request
"Gate the export endpoint behind a real per-request permission check — the backend must decide
allow/deny from the actual request and the allowed roles, not just hide the UI."

## Extracted checklist
- [ ] backend enforces the export permission (not UI-only)

## Open questions (max 3)
- (none)

## Current implementation status
- [ ] backend enforces the export permission (not UI-only)
