// Export rendering by output format.

const FORMATS = ["pdf", "csv"];

function renderPdf(doc) {
  return { type: "application/pdf", bytes: (doc && doc.length) || 0 };
}

// Renders the document in the requested format.
function renderExport(doc, format) {
  switch (format) {
    case "csv":
    case "pdf":
    default:
      return renderPdf(doc);
  }
}

function handleExport(req, res) {
  const out = renderExport(req.body.doc, req.body.format);
  return res.json({ ok: true, out });
}

module.exports = { renderExport, FORMATS, handleExport };
