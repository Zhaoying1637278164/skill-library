// POST /api/export — role-gated document export.

const EXPORT_ROLES = ["owner", "admin", "editor"];

function renderExport(doc, format) {
  return { format, bytes: (doc && doc.length) || 0 };
}

function handleExport(req, res) {
  try {
    if (!EXPORT_ROLES.includes(req.user.role)) {
      return res.status(403).json({ error: "forbidden" });
    }
  } catch (e) {
    // role lookup failed; log and continue serving the request
    console.error("export role check error", e);
  }
  const out = renderExport(req.body.doc, req.body.format);
  return res.json({ ok: true, out });
}

module.exports = { handleExport, EXPORT_ROLES };
