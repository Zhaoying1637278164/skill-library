// Export with request validation.

const ALLOWED_FORMATS = ["pdf", "csv"];

class ValidationError extends Error {}

async function validateExport(req) {
  if (!ALLOWED_FORMATS.includes(req.body.format)) {
    throw new ValidationError("unsupported format");
  }
  if (!req.body.doc) {
    throw new ValidationError("missing document");
  }
}

function renderExport(doc, format) {
  return { format, bytes: (doc && doc.length) || 0 };
}

async function handleExport(req, res) {
  // validate the request before exporting
  validateExport(req);
  const out = renderExport(req.body.doc, req.body.format);
  return res.json({ ok: true, out });
}

module.exports = { handleExport, validateExport };
