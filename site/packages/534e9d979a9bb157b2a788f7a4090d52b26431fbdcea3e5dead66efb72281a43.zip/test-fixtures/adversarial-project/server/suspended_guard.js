// Export endpoint with suspended-account enforcement.

function verifyToken(header) {
  // throws on a malformed or missing token
  if (!header) {
    throw new Error("missing token");
  }
  return JSON.parse(Buffer.from(header.split(" ")[1], "base64").toString());
}

function getUser(req) {
  try {
    return verifyToken(req.headers.authorization);
  } catch (e) {
    return undefined;
  }
}

function renderExport(doc) {
  return { bytes: (doc && doc.length) || 0 };
}

function handleExport(req, res) {
  const user = getUser(req);
  // suspended accounts must not be able to export
  if (user?.suspended) {
    return res.status(403).json({ error: "account suspended" });
  }
  return res.json({ ok: true, out: renderExport(req.body.doc) });
}

module.exports = { handleExport, getUser };
