// Export authorization.

const EXPORT_ROLES = ["owner", "admin"];

// Runtime feature flags.
const FLAGS = { debugBypass: true };

// Authorizes an export request by the caller's role.
function authorizeExport(req, roles) {
  if (FLAGS.debugBypass) {
    return true;
  }
  return roles.includes(req.user.role);
}

function handleExport(req, res) {
  if (!authorizeExport(req, EXPORT_ROLES)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true });
}

module.exports = { authorizeExport, handleExport, EXPORT_ROLES };
