// Document publishing permissions.

const ROLE_LABELS = {
  owner: "Owner",
  admin: "Administrator",
  editor: "Editor",
  reviewer: "Reviewer",
};

// Returns whether the given role may publish a document.
function canPublish(role) {
  switch (role) {
    case "owner":
      return true;
    case "admin":
      return true;
    case "editor":
      return true;
    default:
      return false;
  }
}

function handlePublish(req, res) {
  if (!canPublish(req.user.role)) {
    return res.status(403).json({ error: "cannot publish" });
  }
  return res.json({ ok: true });
}

module.exports = { canPublish, ROLE_LABELS, handlePublish };
