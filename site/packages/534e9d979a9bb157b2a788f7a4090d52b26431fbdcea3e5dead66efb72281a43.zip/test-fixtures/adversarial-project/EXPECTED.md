# Ground Truth — adversarial-project (6 requirements, single-label)

Expected `/spec-drift:report` classification. Every item has ONE correct label — there is NO
acceptable alternative, so accuracy itself discriminates. A naive review without the drift method
(text/identifier matching, or "the call site has a 403 so it must be enforced") plausibly
mislabels each one.

| # | Checklist item | Expected | Evidence | Why naive fails / detection signal |
|---|----------------|----------|----------|------------------------------------|
| 1 | export handler rejects unallowed roles (403) | **silent-fail** | server/role_guard.js:10-18 | real `EXPORT_ROLES.includes(req.user.role)` check + 403 look done; the check sits in a try whose catch logs-only and falls through to export, so a missing/undefined `req.user` bypasses the gate |
| 2 | reviewer role can publish | **missing** | server/publish_permissions.js:7,11-22 | `reviewer` is present in ROLE_LABELS (grep hit) so naive marks done; `canPublish` has no reviewer case, so the capability is unimplemented |
| 3 | authorizeExport enforces role check every request | **hardcode-debt** | server/authorize_export.js:6,10-13 | the real `roles.includes(req.user.role)` check is present; `FLAGS.debugBypass` is hardcoded `true`, so the early `return true` makes the real check and the 403 dead code |
| 4 | suspended accounts blocked from exporting | **silent-fail** | server/suspended_guard.js:12-16,26 | `getUser` swallows token errors → `undefined`; `user?.suspended` is then `undefined` on that reachable path so the 403 is skipped and the export proceeds |
| 5 | export supports PDF and CSV | **changed** | server/format_export.js:3,12-15 | FORMATS lists csv and the switch has a csv case (grep hits) → naive done; the csv case falls through to `renderPdf`, so only PDF is actually built |
| 6 | requests validated before rendering | **silent-fail** | server/validate_export.js:22 | `validateExport` is defined and called (grep hit) → naive done; it is invoked without `await` and its result/rejection is discarded, so invalid requests are still rendered |

## Per-item: Why naive review fails

- **Item 1 (silent-fail):** A real `EXPORT_ROLES.includes(req.user.role)` check and a 403 reject
  branch are both present, so identifier/text matching marks it done. The try/catch wraps the guard:
  when `req.user` is undefined (a reachable path) `req.user.role` throws, the catch only
  `console.error`s and execution falls through to the export, silently bypassing the gate.
- **Item 2 (missing):** Grepping for `reviewer` hits ROLE_LABELS so naive concludes the role is
  handled and marks done. The actual decision function `canPublish` has cases only for
  owner/admin/editor; reviewer hits the default deny, so the reviewer-can-publish capability has no
  implementation.
- **Item 3 (hardcode-debt):** The genuine `roles.includes(req.user.role)` check and the call-site
  403 are present, so naive marks done. `FLAGS.debugBypass` is bound to a literal `true`, so
  `if (FLAGS.debugBypass) return true` is always taken; the real check and the 403 are dead code and
  every caller is authorized.
- **Item 4 (silent-fail):** A suspended check (`if (user?.suspended)` 403) is present so naive marks
  done. `getUser` swallows token-decode errors and returns undefined; on that reachable path
  `user?.suspended` evaluates to undefined (falsy), the 403 is skipped, and the export proceeds — the
  suspension guard is silently bypassed for any unresolved user.
- **Item 5 (changed):** FORMATS lists `csv` and the switch literally has a `case "csv"`, both grep
  hits, so naive marks done. The csv case falls through (no break/return of its own) to the shared
  `renderPdf`, so CSV output is never produced — the feature exists but is narrowed to PDF only.
- **Item 6 (silent-fail):** `validateExport` is defined with real throwing checks and is called in
  the handler, so naive marks done. It is invoked WITHOUT `await`; the returned promise (and any
  rejection) is discarded while the handler synchronously proceeds to render and respond ok, so
  invalid requests are never gated.

## Expected distribution
- silent-fail: 3 (items 1,4,6)
- hardcode-debt: 1 (item 3)
- missing: 1 (item 2)
- changed: 1 (item 5)

## Pass criteria
- Each item's label = Expected exactly (no acceptable alternative).
- `done` on any item is a dangerous misclassification and FAILS the gate.
