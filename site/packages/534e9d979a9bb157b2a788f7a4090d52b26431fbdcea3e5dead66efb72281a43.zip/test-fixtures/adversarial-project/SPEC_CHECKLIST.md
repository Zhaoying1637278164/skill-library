# Spec Checklist — 2026-06-28T10:00:00

Task: export-authorization-hardening

## Original request
"Harden the document export feature. The export handler must reject callers whose role is not
allowed. The reviewer role must be able to publish documents. The authorizeExport permission
function must enforce the role check on every request. Suspended accounts must be blocked from
exporting. Export must support both PDF and CSV. Every export request must be validated and
invalid requests rejected before anything is rendered."

## Extracted checklist
- [ ] export handler rejects callers whose role is not allowed (403)
- [ ] reviewer role can publish a document
- [ ] authorizeExport enforces the role-based export permission on every request
- [ ] suspended accounts are blocked from exporting
- [ ] export supports both PDF and CSV output formats
- [ ] export requests are validated and invalid ones rejected before rendering

## Open questions (max 3)
- (none)

## Current implementation status
- [ ] export handler rejects callers whose role is not allowed
- [ ] reviewer role can publish a document
- [ ] authorizeExport enforces the role-based export permission
- [ ] suspended accounts are blocked from exporting
- [ ] export supports both PDF and CSV output formats
- [ ] export requests are validated before rendering
