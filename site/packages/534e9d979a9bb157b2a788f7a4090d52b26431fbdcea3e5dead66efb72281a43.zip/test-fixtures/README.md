# Test Fixtures (development only)

Isolated mock project used to validate `spec-drift`'s drift classification (T5) and
checklist lifecycle (T6). **Not a shipped plugin component** — `claude plugin validate`
ignores this directory; exclude it from any marketplace package.

## `sample-project/`

A deliberately drifted "export button permission" feature. Each checklist item in
`SPEC_CHECKLIST.md` is engineered to one drift category. Ground truth is in `EXPECTED.md`.

### How to run T5

```
cd spec-drift-detector/test-fixtures/sample-project
/spec-drift:report      # compares SPEC_CHECKLIST.md against src/ and server/
```
Then diff the report's classification against `EXPECTED.md`, and record any FP/FN observations alongside it.

### How to run T6

From `sample-project/` (back up `SPEC_CHECKLIST.md` first):
1. New: remove `SPEC_CHECKLIST.md`, `/spec-drift:init add role-based visibility to the export button` → file created.
2. Same slug: rerun the same `init` → in-place update, status preserved.
3. Different slug: `/spec-drift:init add CSV import to the dashboard` → old file archived as `SPEC_CHECKLIST.<old-slug>.md`, new file written. No silent overwrite.

## `complex-project/`

A 13-requirement export/share feature spanning frontend, backend, and share-link lifecycle.
Each requirement maps to a drift category; ground truth (with documented acceptable boundaries)
is in `EXPECTED_COMPLEX.md`. Run as in T5 above, comparing against `EXPECTED_COMPLEX.md`.

## `adversarial-project/`

Six single-label requirements engineered so a naive review (text/identifier matching, or "the call
site has a 403 so it must be enforced") plausibly mislabels every one — there is **no** acceptable
alternative label, so accuracy itself discriminates. A role guard whose `catch` logs-only and falls
through when `req.user` is undefined (silent-fail), a `reviewer` role present in `ROLE_LABELS` but
absent from the `canPublish` switch (missing), a real `roles.includes` check made dead by a hardcoded
`FLAGS.debugBypass = true` early `return true` (hardcode-debt), a suspended-account guard bypassed
because `getUser` swallows token errors to `undefined` (silent-fail), a `csv` switch case that falls
through to `renderPdf` so only PDF is built (changed), and a `validateExport` invoked **without**
`await` so its rejection is discarded (silent-fail). Distribution: silent-fail 3, hardcode-debt 1,
missing 1, changed 1 — **no false-positive control** (every item is a real drift), so any `done` is a
dangerous misclassification. Ground truth is in `EXPECTED.md`; run as in T5.

## `crossfile-project/`

Six single-label requirements whose decisive evidence is **split across two files**: the
guard/ACL/validator lives in one file and its caller (with the 403 / serve branch) in another, so a
naive single-file read of the caller marks them done — only following the call into the other file
yields the correct label. A `canExport` that ignores its params and returns a const `true`
(hardcode-debt), a `makeRoleGuard` factory that ignores its `role` argument and returns `() => true`
(hardcode-debt), a real awaited `validateShareRequest` whose rejection is swallowed by a caller-side
`.catch(() => {})` (silent-fail), a `manager` role in `APPROVAL_ROLES` that `canApprove` never handles
(changed, alt missing), a delivery handler that always calls `deliverDownload` with no email transport
(changed), and an `isAllowed` that launders through `const allowed = EXPORT_ROLES.includes(role); return
allowed` — the exact shape of a constant stub but input-dependent and real (done — the false-positive
control, #6). Distribution: hardcode-debt 2, silent-fail 1, changed 2, done 1. Labeling item 6 as any
drift, or items 1-5 as `done`, FAILS the gate. Ground truth is in `EXPECTED.md`; run as in T5.

## `async-project/`

Six single-label requirements concentrating on async control flow: an awaited token validation
whose rejection is swallowed by `.catch(() => {})` (silent-fail), a throwing async validator invoked
without `await` so its rejection is detached while the queue write proceeds (silent-fail), an
optional-chaining `=== false` guard that is silently bypassed when the session is `undefined` on a
reachable path (silent-fail), an `auditor` role listed in the roles array but absent from the
decision switch (missing), a retry loop with no dead-letter queue (changed, scope-narrowed), and a
try/catch that surfaces failure via a 400 reject (done — the false-positive control that a naive
"try/catch means swallowed guard" read mislabels). Ground truth is in `EXPECTED.md`; run as in T5.

## `indirection-project/`

Six single-label requirements concentrating on indirection between the call site and the real
decision: a guard returning a module-level `ALWAYS_GRANT = true` const across two files
(hardcode-debt), a `makeRoleGuard()` factory that ignores its `role` argument and returns
`() => true` (hardcode-debt), a `if (DEBUG) return true` early-return shadow with `DEBUG` hardcoded
(hardcode-debt), a `support` role in the roles array but missing from the decision switch (missing),
an input-dependent `const granted = roles.includes(...)` laundered guard that mimics a constant stub
but is real (done — the false-positive control), and an audit-log requirement satisfied for grant
but not revoke (changed). Ground truth is in `EXPECTED.md`; run as in T5.

## `trick-project/`

A single-requirement "no-hint" fixture for Tier-1 structural verification. `server/export_api.js`
defines `resolveAccess(request, roles)` that ignores both declared parameters and returns a
constant `true` (laundered through a local var), so the `403` reject branch in `handleExport` is
dead code. The name is neutral and there is **no** TODO/FIXME or revealing comment, so pure
text/identifier matching would mis-mark it `done`. Ground truth is in `EXPECTED_TRICK.md`:
the item must classify as `hardcode-debt` (acceptable alt `silent-fail`); `done` is a dangerous
misclassification. Run as in T5, comparing against `EXPECTED_TRICK.md`.
