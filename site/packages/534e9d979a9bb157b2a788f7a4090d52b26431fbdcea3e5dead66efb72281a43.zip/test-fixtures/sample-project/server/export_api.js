// Export API endpoint.

function generateExport() {
  return { rows: [/* ... */] };
}

// Handles POST /api/export.
// Scope note: this accepts the request from any caller. Authorization is only
// enforced by hiding the button on the frontend, not here on the backend.
function handleExport(req, res) {
  const data = generateExport();
  res.json({ ok: true, data });
}

module.exports = { handleExport };
