# T5 Ground Truth — sample-project

Expected `/spec-drift:report` classification for each `SPEC_CHECKLIST.md` item.
Drift detection is heuristic (per README "Heuristic detection"); borderline matches are noted.

| # | Checklist item | Expected | Evidence (file) | Detection signal |
|---|----------------|----------|-----------------|------------------|
| 1 | admin role: export button visible | **done** | `src/Export.jsx` | explicit `user.role === "admin"` branch shows the button |
| 2 | guest role: export button hidden | **missing** | `src/Export.jsx` | no `guest` reference anywhere; only admin handled (heuristic: role name in checklist not found in code) |
| 3 | backend rejects unauthorized export | **changed** | `server/export_api.js` | endpoint accepts any caller; enforcement narrowed to frontend-only hide |
| 4 | export API failure path handled | **silent-fail** | `src/Export.jsx` | `catch (e) {}` swallows the error, nothing surfaced |
| 5 | permission check uses real user role | **hardcode-debt** | `src/permissions.js` | `const canExport = true` + `TODO` comment |

## Summary

- DONE: 1
- MISSING: 1
- CHANGED: 1
- SILENT-FAIL: 1
- HARDCODE-DEBT: 1

Total: 5 items, one per drift category.

## Notes on borderline cases

- Item 2 (guest): functionally guest *is* hidden by the default-false branch. The static
  prediction is **missing** (no explicit `guest` check). Either **missing** or **done** is
  acceptable; treat the difference as a heuristic boundary, not a hard fail.
- Item 3 (backend): the backend has no auth check at all, so **missing** (rejection not
  implemented) and **changed** (enforcement narrowed to frontend-only) are both defensible.
  Both classify the item as drift — that is what matters.

## Observed — live run 2026-06-27 (headless `/spec-drift:report`)

| # | Expected | Observed | Verdict |
|---|----------|----------|---------|
| 1 | done | done | match |
| 2 | missing | done | boundary (live recognized non-admin→null hides guest; acceptable) |
| 3 | changed | missing | boundary (both = drift; acceptable) |
| 4 | silent-fail | silent-fail | match |
| 5 | hardcode-debt | hardcode-debt | match |

3/5 exact, 2 acceptable boundary differences, **0 dangerous misclassification** (no real drift
marked done, no done marked drift). Live report also surfaced the security implication
(UI-only gate; unauthorized caller can still POST `/api/export`).
