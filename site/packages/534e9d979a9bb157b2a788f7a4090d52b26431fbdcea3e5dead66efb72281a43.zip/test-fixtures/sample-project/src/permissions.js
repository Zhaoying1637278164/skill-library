// Permission helper for the export feature.

export function canExport(user) {
  // TODO: wire real permission check to user.role and the backend policy
  const canExport = true; // hardcoded for now so the button always enables
  return canExport;
}
