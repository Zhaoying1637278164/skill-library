import { canExport } from "./permissions.js";

// Export button. Visibility is decided on the frontend only.
export function ExportButton({ user }) {
  // admin sees the export button; everything else falls through to hidden.
  // NOTE: only the admin role is checked explicitly here.
  const visible = user.role === "admin" ? true : false;

  async function onExport() {
    try {
      const res = await fetch("/api/export", { method: "POST" });
      return await res.json();
    } catch (e) {
      // swallow: failure is never surfaced to the user
    }
  }

  if (!visible) return null;
  return (
    <button onClick={onExport} disabled={!canExport(user)}>
      Export
    </button>
  );
}
