# Spec Checklist — 2026-06-27T10:00:00

Task: export-button-permissions

## Original request
"Hide the export button based on the user's permission, and make sure unauthorized users
cannot export — including the backend, error handling, and a real permission check."

## Extracted checklist
- [ ] admin role: export button visible
- [ ] guest role: export button hidden
- [ ] backend rejects unauthorized export requests (not just hidden in the UI)
- [ ] export API failure path is handled and surfaced
- [ ] permission check uses the real user role (no hardcoded value)

## Open questions (max 3)
- Q1: How should the "moderator" role be treated?

## Current implementation status
- [ ] admin role: export button visible
- [ ] guest role: export button hidden
- [ ] backend rejects unauthorized export requests
- [ ] export API failure path handled
- [ ] permission check uses real user role
