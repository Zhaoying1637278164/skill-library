// POST /api/webhooks/send — signs and sends an outbound webhook.
const { loadSigningKey } = require("./keystore");

function sign(payload, key) {
  return key + ":" + JSON.stringify(payload).length;
}

async function handleSend(req, res) {
  let key;
  try {
    key = await loadSigningKey(req.body.tenantId);
  } catch (e) {
    // no key means we cannot sign; reject rather than send unsigned
    return res.status(400).json({ error: "signing key unavailable" });
  }
  const signature = sign(req.body.payload, key);
  return res.json({ ok: true, signature });
}

module.exports = { handleSend };
