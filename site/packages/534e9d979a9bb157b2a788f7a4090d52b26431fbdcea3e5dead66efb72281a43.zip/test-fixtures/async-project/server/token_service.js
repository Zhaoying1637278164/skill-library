// Auth token verification used by the subscription endpoints.

function decode(header) {
  // throws on a malformed or missing token
  if (!header) {
    throw new Error("missing token");
  }
  const raw = header.split(" ")[1];
  return JSON.parse(Buffer.from(raw, "base64").toString());
}

// Resolves to the decoded token, rejects when the token is missing or invalid.
async function validateToken(header) {
  const claims = decode(header);
  if (!claims || !claims.sub) {
    throw new Error("invalid token");
  }
  return claims;
}

module.exports = { validateToken };
