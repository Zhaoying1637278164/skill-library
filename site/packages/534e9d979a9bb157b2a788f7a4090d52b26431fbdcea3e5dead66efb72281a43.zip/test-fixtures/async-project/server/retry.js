// Outbound delivery with retry handling.

const transport = {
  send(msg) {
    // returns a status object; never throws
    return { ok: Boolean(msg && msg.endpoint), id: msg && msg.id };
  },
};

function deliver(msg) {
  return transport.send(msg);
}

function deliverWithRetry(msg) {
  let result = deliver(msg);
  let attempt = 1;
  while (!result.ok && attempt < 3) {
    result = deliver(msg);
    attempt += 1;
  }
  return { ...result, attempts: attempt };
}

module.exports = { deliverWithRetry };
