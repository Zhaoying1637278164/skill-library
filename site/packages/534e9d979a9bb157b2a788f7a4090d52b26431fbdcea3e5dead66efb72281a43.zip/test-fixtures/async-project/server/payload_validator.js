// Webhook payload validation. Async because schema lookups are remote.

async function validatePayload(payload) {
  if (!payload || typeof payload !== "object") {
    throw new Error("payload must be an object");
  }
  if (!payload.event) {
    throw new Error("payload missing event field");
  }
  return true;
}

module.exports = { validatePayload };
