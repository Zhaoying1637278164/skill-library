// POST /api/webhooks — accepts and queues incoming webhook deliveries.
const { validatePayload } = require("./payload_validator");

const queue = [];

function enqueue(payload) {
  queue.push(payload);
  return queue.length;
}

function handleWebhook(req, res) {
  // validate the payload before it is enqueued
  validatePayload(req.body);
  const depth = enqueue(req.body);
  return res.json({ ok: true, depth });
}

module.exports = { handleWebhook, queue };
