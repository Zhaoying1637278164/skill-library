// Signing-key lookup for outbound webhooks.

const KEYS = { acme: "k-acme-001" };

async function loadSigningKey(tenantId) {
  const key = KEYS[tenantId];
  if (!key) {
    throw new Error("no signing key for tenant " + tenantId);
  }
  return key;
}

module.exports = { loadSigningKey };
