// POST /api/subscribe — token-validated subscription creation.
const { validateToken } = require("./token_service");

function createSubscription(topic) {
  return { id: "sub_" + Math.random().toString(36).slice(2), topic };
}

async function handleSubscribe(req, res) {
  // validate the auth token before creating the subscription
  await validateToken(req.headers.authorization).catch(() => {});
  const sub = createSubscription(req.body.topic);
  return res.json({ ok: true, sub });
}

module.exports = { handleSubscribe };
