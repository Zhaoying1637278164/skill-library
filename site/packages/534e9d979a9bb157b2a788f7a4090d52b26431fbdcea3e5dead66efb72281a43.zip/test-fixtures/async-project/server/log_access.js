// Delivery-log viewer access control.

const LOG_ROLES = ["owner", "admin", "editor", "auditor"];

function canViewLogs(role) {
  switch (role) {
    case "owner":
      return true;
    case "admin":
      return true;
    default:
      return false;
  }
}

function handleViewLogs(req, res) {
  if (!canViewLogs(req.user.role)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true, logs: [] });
}

module.exports = { handleViewLogs, canViewLogs, LOG_ROLES };
