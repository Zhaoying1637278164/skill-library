// Subscription endpoint that blocks unverified email accounts.

function verifySession(cookie) {
  // throws when the session cookie is missing or tampered
  if (!cookie) {
    throw new Error("no session");
  }
  return JSON.parse(Buffer.from(cookie, "base64").toString());
}

function getSession(req) {
  try {
    return verifySession(req.headers.cookie);
  } catch (e) {
    return undefined;
  }
}

function handleSubscribe(req, res) {
  const session = getSession(req);
  // users with an unverified email must not be allowed to subscribe
  if (session?.user?.emailVerified === false) {
    return res.status(403).json({ error: "email not verified" });
  }
  return res.json({ ok: true, topic: req.body.topic });
}

module.exports = { handleSubscribe, getSession };
