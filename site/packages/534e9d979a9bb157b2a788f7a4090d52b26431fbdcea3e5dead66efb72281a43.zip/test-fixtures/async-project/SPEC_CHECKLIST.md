# Spec Checklist — 2026-06-28T12:00:00

Task: delivery-service-hardening

## Original request
"Harden the notification delivery service. Subscription requests must validate the auth token and
reject invalid tokens before a subscription is created. Incoming webhook payloads must be validated
and invalid payloads rejected before they are enqueued. Users whose email is unverified must be
blocked from subscribing. The auditor role must be able to view delivery logs. Failed deliveries
must be retried and, once retries are exhausted, moved to a dead-letter queue. Outbound webhooks
must be signed and requests with no available signing key rejected before sending."

## Extracted checklist
- [ ] subscription validates the auth token and rejects invalid tokens before subscribing
- [ ] incoming webhook payloads are validated and invalid ones rejected before enqueue
- [ ] users with an unverified email are blocked from subscribing
- [ ] the auditor role can view delivery logs
- [ ] failed deliveries are retried and then moved to a dead-letter queue
- [ ] outbound webhooks are signed and requests without a signing key are rejected before sending

## Open questions (max 3)
- (none)

## Current implementation status
- [ ] subscription validates the auth token and rejects invalid tokens before subscribing
- [ ] incoming webhook payloads are validated and invalid ones rejected before enqueue
- [ ] users with an unverified email are blocked from subscribing
- [ ] the auditor role can view delivery logs
- [ ] failed deliveries are retried and then moved to a dead-letter queue
- [ ] outbound webhooks are signed and requests without a signing key are rejected before sending
