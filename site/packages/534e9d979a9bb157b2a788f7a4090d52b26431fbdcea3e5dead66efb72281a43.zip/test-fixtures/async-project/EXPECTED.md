# Ground Truth — async-project (6 requirements, single-label, async/await focus)

Expected `/spec-drift:report` classification. Every item has exactly ONE correct label — there is
NO acceptable alternative, so accuracy itself discriminates. This project concentrates on async
control flow: awaited-but-swallowed rejections, fire-and-forget promises, and optional-chaining
bypasses that a naive review reads as "validation is present, so it is done."

| # | Checklist item | Expected | Evidence | Why naive fails / detection signal |
|---|----------------|----------|----------|------------------------------------|
| 1 | subscription validates token, rejects invalid before subscribing | **silent-fail** | server/auth_subscribe.js:10 | `validateToken(...)` is real and is `await`ed (grep hits both), so naive marks done; the awaited call is suffixed with `.catch(() => {})`, swallowing every rejection, then `createSubscription` runs regardless — invalid tokens still subscribe |
| 2 | webhook payloads validated, invalid rejected before enqueue | **silent-fail** | server/enqueue.js:15-16 | `validatePayload(req.body)` is defined (throwing) and called before `enqueue` (grep hits) → naive done; it is async and invoked WITHOUT `await`, so the returned promise and its rejection are discarded while `enqueue` runs synchronously — invalid payloads are queued |
| 3 | unverified-email users blocked from subscribing | **silent-fail** | server/verify_email.js:18-20 | a real `if (session?.user?.emailVerified === false) 403` guard is present → naive done; `getSession` returns `undefined` on a verify failure (reachable), so `session?.user?.emailVerified` is `undefined`, `=== false` is false, the 403 is skipped and the user subscribes |
| 4 | auditor role can view delivery logs | **missing** | server/log_access.js:3,5-12 | `auditor` is listed in LOG_ROLES (grep hit) so naive marks done; `canViewLogs` only returns true for owner/admin, auditor hits the default `return false`, so the auditor-can-view-logs capability is unimplemented |
| 5 | failed deliveries retried then moved to dead-letter queue | **changed** | server/retry.js:14-21 | a real retry loop exists and `deliverWithRetry` is exported (grep hits) → naive done; after retries are exhausted the final failing result is simply returned — there is no dead-letter queue, so the feature is narrowed to retry-only |
| 6 | outbound webhooks signed; no-key requests rejected before send | **done** | server/webhook_sign.js:11-19 | the try/catch around `loadSigningKey` looks like a swallowed-guard so naive may flag silent-fail; but the catch RETURNS a 400 reject (failure surfaced, not swallowed) and signing is reachable on the happy path only — the guard is real and enforced |

## Per-item: why naive review fails
- **Item 1 (silent-fail):** `await validateToken(...)` reads as a correctly-awaited guard, but the
  trailing `.catch(() => {})` neutralizes the rejection on the same line; execution always falls
  through to `createSubscription`.
- **Item 2 (silent-fail):** the call is present and ordered before `enqueue`, but the missing
  `await` turns a throwing validator into a detached unhandled promise; the synchronous `enqueue`
  has already run by the time it rejects.
- **Item 3 (silent-fail):** the optional-chaining guard is correct for a resolved session, but the
  reachable `undefined` session path makes the strict `=== false` comparison false, silently
  bypassing the block.
- **Item 4 (missing):** `auditor` appears only in the LOG_ROLES array, never in the decision
  `switch`; the decision path has no auditor case.
- **Item 5 (changed):** retries are genuinely implemented; the dead-letter half of the requirement
  has no code path at all, so the requirement is implemented but scope-narrowed.
- **Item 6 (done):** the false-positive control — a try/catch that surfaces failure via a 400 is
  enforcement, not a swallowed guard; labeling it silent-fail (or any drift) is wrong.

## Expected distribution
- silent-fail: 3 (items 1,2,3)
- missing: 1 (item 4)
- changed: 1 (item 5)
- done: 1 (item 6)

## Pass criteria
- Each item's label = Expected exactly (no acceptable alternative).
- Item 6 is the false-positive control: any drift label on it FAILS the gate.
- `done` on items 1-5 is a dangerous misclassification and FAILS the gate.
