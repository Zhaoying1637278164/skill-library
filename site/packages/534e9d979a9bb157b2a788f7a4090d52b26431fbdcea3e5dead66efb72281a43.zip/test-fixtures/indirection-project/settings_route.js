// POST /admin/settings — update workspace settings.
const { canEditSettings, SETTINGS_ROLES } = require("./settings_acl");

function handleSettings(req, res) {
  if (!canEditSettings(req.user, SETTINGS_ROLES)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true, saved: req.body });
}

module.exports = { handleSettings };
