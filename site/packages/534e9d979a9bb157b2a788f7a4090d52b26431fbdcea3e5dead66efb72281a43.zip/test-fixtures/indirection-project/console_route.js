// GET /admin/console — entry point to the admin console.
const { hasConsoleAccess, CONSOLE_ROLES } = require("./console_access");

function handleConsole(req, res) {
  if (!hasConsoleAccess(req.user, CONSOLE_ROLES)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true, panel: "console" });
}

module.exports = { handleConsole };
