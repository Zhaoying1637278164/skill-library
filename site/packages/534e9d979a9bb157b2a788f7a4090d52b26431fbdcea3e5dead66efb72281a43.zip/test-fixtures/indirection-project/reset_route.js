// POST /admin/users/:id/reset-password — password reset.

const RESET_ROLES = ["owner", "admin", "support"];

function canResetPassword(role) {
  switch (role) {
    case "owner":
    case "admin":
      return true;
    default:
      return false;
  }
}

function handleReset(req, res) {
  if (!canResetPassword(req.user.role)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true, reset: req.params.id });
}

module.exports = { handleReset, canResetPassword, RESET_ROLES };
