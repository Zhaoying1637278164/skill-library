# Spec Checklist — 2026-06-28T13:00:00

Task: admin-console-access-control

## Original request
"Lock down the admin console. The backend must enforce console access with a real per-request
permission check. The destructive tenant-delete endpoint must be gated to the admin role only.
Only the owner and billing roles may manage billing. Only owner and admin may edit workspace
settings. The support role must be able to reset user passwords. Both granting and revoking
console access must be recorded in the audit log."

## Extracted checklist
- [ ] backend enforces console access via a real per-request permission check
- [ ] the destructive tenant-delete endpoint is gated to the admin role only
- [ ] only owner and billing roles may manage billing
- [ ] the support role can reset user passwords
- [ ] only owner and admin roles may edit workspace settings
- [ ] both granting and revoking access are recorded in the audit log

## Open questions (max 3)
- (none)

## Current implementation status
- [ ] backend enforces console access via a real per-request permission check
- [ ] the destructive tenant-delete endpoint is gated to the admin role only
- [ ] only owner and billing roles may manage billing
- [ ] the support role can reset user passwords
- [ ] only owner and admin roles may edit workspace settings
- [ ] both granting and revoking access are recorded in the audit log
