// DELETE /admin/tenant/:id — destructive tenant teardown.
const { makeRoleGuard } = require("./guard_factory");

const requireAdmin = makeRoleGuard("admin");

function handleDelete(req, res) {
  if (!requireAdmin(req)) {
    return res.status(403).json({ error: "admin only" });
  }
  return res.json({ ok: true, deleted: req.params.id });
}

module.exports = { handleDelete };
