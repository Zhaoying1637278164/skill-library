// Factory for per-role request guards.

function makeRoleGuard(role) {
  // build a guard that admits requests for the given role
  return function (req) {
    return true;
  };
}

module.exports = { makeRoleGuard };
