// Console access grant/revoke with audit logging.

const store = {
  grant(userId, role) {
    return { userId, role, state: "granted" };
  },
  revoke(userId) {
    return { userId, state: "revoked" };
  },
};

const auditLog = {
  entries: [],
  record(entry) {
    this.entries.push(entry);
  },
};

function grantAccess(userId, role) {
  store.grant(userId, role);
  auditLog.record({ action: "grant", userId, role });
}

function revokeAccess(userId) {
  return store.revoke(userId);
}

module.exports = { grantAccess, revokeAccess, auditLog };
