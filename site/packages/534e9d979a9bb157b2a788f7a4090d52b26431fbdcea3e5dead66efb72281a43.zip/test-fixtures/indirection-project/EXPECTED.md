# Ground Truth — indirection-project (6 requirements, single-label, indirection focus)

Expected `/spec-drift:report` classification. Every item has exactly ONE correct label — there is
NO acceptable alternative, so accuracy itself discriminates. This project concentrates on
indirection: guards reached through a module-level constant, a factory, or a DEBUG short-circuit,
where the call site looks correctly gated and only following the indirection reveals the defect.

| # | Checklist item | Expected | Evidence | Why naive fails / detection signal |
|---|----------------|----------|----------|------------------------------------|
| 1 | backend enforces console access (real per-request check) | **hardcode-debt** | console_access.js:5-9 + console_route.js:5-6 | the caller has a clean `if (!hasConsoleAccess(...)) 403` (reads enforced); `hasConsoleAccess` ignores both declared params and returns the module-level const `ALWAYS_GRANT = true`, so the reject branch is dead and every caller is admitted |
| 2 | destructive tenant-delete gated to admin only | **hardcode-debt** | guard_factory.js:3-8 + delete_route.js:4-9 | `requireAdmin = makeRoleGuard("admin")` plus a 403 looks role-gated; `makeRoleGuard` ignores its `role` parameter and returns `() => true`, so `requireAdmin` is constant-true and the reject on a destructive endpoint is dead |
| 3 | only owner and billing roles may manage billing | **hardcode-debt** | debug_gate.js:3,7-11 | a real `BILLING_ROLES.includes(req.user.role)` check is present, so naive marks done; `DEBUG` is a hardcoded `true`, so `if (DEBUG) return true` is always taken and the real check below it is dead code |
| 4 | support role can reset user passwords | **changed** (alt **missing**) | reset_route.js:3,5-12 | `support` is listed in RESET_ROLES (grep hit) so naive marks done; the reset feature exists but `canResetPassword` returns true only for owner/admin, so it is scope-narrowed to exclude support (changed); treating the absent support capability as unimplemented (missing) is also defensible |
| 5 | only owner and admin may edit workspace settings | **done** | settings_acl.js:5-8 + settings_route.js:5-6 | `canEditSettings` launders through `const granted = ...; return granted` (the exact shape of a constant stub, so naive may flag hardcode-debt); but `granted` is `roles.includes(user.role)`, input-dependent, reachable, and the caller surfaces denial with a 403 — the gate is real |
| 6 | both granting and revoking access are audit-logged | **changed** | audit.js:21-29 | `auditLog.record` exists and is called (grep hits) so naive marks done; only `grantAccess` records an entry — `revokeAccess` mutates state and returns without any `auditLog.record`, so the requirement is implemented for grant only |

## Per-item: why naive review fails
- **Item 1 (hardcode-debt):** reading only console_route.js shows a textbook `if (!hasConsoleAccess) 403`; the constant return is one indirection away, laundered through a module-level const so it is not even a literal on the `return` line.
- **Item 2 (hardcode-debt):** `makeRoleGuard("admin")` reads as role-specific and delete_route.js looks gated; the factory discards its argument and always returns a true-guard.
- **Item 3 (hardcode-debt):** the genuine role membership test is present and correct, but the `DEBUG` short-circuit above it (DEBUG bound to a literal `true`) makes it unreachable.
- **Item 4 (changed):** grepping `support` hits RESET_ROLES, but the decision `switch` never handles it — the reset feature exists for owner/admin, so this is scope-narrowing (changed); the absent support capability read as missing is also defensible.
- **Item 5 (done):** the false-positive control — `const granted = roles.includes(user.role); return granted` mimics a constant stub but is an input-dependent membership test, so it is a real, reachable, enforced gate.
- **Item 6 (changed):** both functions exist and `auditLog.record` is a grep hit, but the revoke path omits the log call, narrowing the requirement to grant-only.

## Expected distribution
- hardcode-debt: 3 (items 1,2,3)
- changed: 2 (item 4 [primary changed, alt missing], item 6)
- done: 1 (item 5)

## Pass criteria
- Each item's label = Expected exactly (no acceptable alternative).
- Item 5 is the false-positive control: labeling it hardcode-debt (or any drift) FAILS the gate.
- `done` on items 1-4 and 6 is a dangerous misclassification and FAILS the gate.
