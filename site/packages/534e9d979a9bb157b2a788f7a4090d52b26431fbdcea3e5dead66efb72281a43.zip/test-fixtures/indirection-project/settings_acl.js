// Settings-editor access-control list.

const SETTINGS_ROLES = ["owner", "admin"];

function canEditSettings(user, roles) {
  const granted = roles.includes(user.role);
  return granted;
}

module.exports = { canEditSettings, SETTINGS_ROLES };
