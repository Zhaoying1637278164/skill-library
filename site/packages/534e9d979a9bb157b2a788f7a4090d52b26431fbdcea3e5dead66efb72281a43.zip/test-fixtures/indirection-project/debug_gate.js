// Billing management gate.

const DEBUG = true;

const BILLING_ROLES = ["owner", "billing"];

function canManageBilling(req) {
  if (DEBUG) {
    return true;
  }
  return BILLING_ROLES.includes(req.user.role);
}

function handleBilling(req, res) {
  if (!canManageBilling(req)) {
    return res.status(403).json({ error: "forbidden" });
  }
  return res.json({ ok: true });
}

module.exports = { handleBilling, canManageBilling, BILLING_ROLES };
