# Spec Checklist — 2026-06-27T12:00:00

Task: team-document-export-sharing

## Original request
"Build team document export and sharing with role-based access. Owners, admins, and editors
can export a document; viewers and guests cannot. Export must support both PDF and CSV. The
backend must enforce the export permission, not just hide the button. Add shareable links with
an enforced expiry, and reject revoked links. Surface export API failures to the user. Record
an audit log of who exported what. Rate-limit the export endpoint to prevent abuse."

## Extracted checklist
- [ ] owner role can export a document
- [ ] admin role can export a document
- [ ] editor role can export a document
- [ ] viewer role cannot export (export control hidden)
- [ ] guest role cannot export
- [ ] backend enforces the export permission (not UI-only)
- [ ] export supports both PDF and CSV formats
- [ ] share link generation works
- [ ] share link expiry is enforced
- [ ] revoked share link is rejected
- [ ] export API failure is surfaced to the user
- [ ] audit log records who exported which document
- [ ] export endpoint is rate-limited

## Open questions (max 3)
- Q1: Should editors export all formats, or PDF only?

## Current implementation status
- [ ] owner role can export a document
- [ ] admin role can export a document
- [ ] editor role can export a document
- [ ] viewer role cannot export
- [ ] guest role cannot export
- [ ] backend enforces the export permission
- [ ] export supports both PDF and CSV formats
- [ ] share link generation works
- [ ] share link expiry is enforced
- [ ] revoked share link is rejected
- [ ] export API failure is surfaced to the user
- [ ] audit log records who exported which document
- [ ] export endpoint is rate-limited
