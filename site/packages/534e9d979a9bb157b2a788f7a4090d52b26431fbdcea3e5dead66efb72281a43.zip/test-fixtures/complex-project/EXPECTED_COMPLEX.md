# Ground Truth — complex-project (13 requirements)

Expected `/spec-drift:report` classification. Detection is heuristic; some items have a
documented acceptable boundary (noted). "Dangerous" = a real drift reported as `done`, or a
real `done` reported as drift.

| # | Checklist item | Expected | Acceptable alt | Evidence |
|---|----------------|----------|----------------|----------|
| 1 | owner can export | **done** | — | `permissions.js` EXPORT_ROLES includes owner; `ExportPanel.jsx` allowed |
| 2 | admin can export | **done** | — | EXPORT_ROLES includes admin |
| 3 | editor can export | **done** | — | EXPORT_ROLES includes editor |
| 4 | viewer cannot export (hidden) | **done** | — | `ExportPanel.jsx` `role === "viewer" → null` |
| 5 | guest cannot export | **missing** | done | no `guest` reference; only falls through default-null |
| 6 | backend enforces permission | **missing** | changed | `export_api.js` no role check; comment admits UI-only |
| 7 | export supports PDF and CSV | **changed** | missing | only PDF wired; CSV requested but not built |
| 8 | share link generation | **done** | — | `share.js` createShareLink returns token |
| 9 | share link expiry enforced | **hardcode-debt** | missing | `expiresInDays = 9999` hardcoded + TODO; never enforced |
| 10 | revoked share link rejected | **silent-fail** | done | revoked check exists but wrapped in error-swallowing try/catch |
| 11 | export API failure surfaced | **silent-fail** | — | `ExportPanel.jsx` empty `catch (e) {}` |
| 12 | audit log records exporter | **missing** | — | no audit code; comment admits not implemented |
| 13 | export endpoint rate-limited | **hardcode-debt** | missing | `exportRateLimitOk` returns hardcoded `true` + TODO |

## Expected distribution
- done: 5 (items 1,2,3,4,8)
- missing: 3 (items 5,6,12)
- changed: 1 (item 7)
- silent-fail: 2 (items 10,11)
- hardcode-debt: 2 (items 9,13)

## Pass criteria (per run)
- Each item's label = Expected OR its Acceptable-alt.
- **Zero dangerous misclassification**: no item among {6,7,9,10,11,12,13} (real drift) labeled `done`;
  no item among {1,2,3,4,8} (real done) labeled as a drift category.

## Pass criteria (across 10 runs)
- Per-item modal label is stable (majority agreement).
- Dangerous-misclassification count across all 10 runs = 0.
