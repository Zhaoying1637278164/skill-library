// POST /api/export — generate an export for a document.

function renderExport(doc, format) {
  return { format, bytes: 0 };
}

function handleExport(req, res) {
  const { format, doc } = req.query;
  // Accepts any authenticated caller. The user's role is NOT checked here;
  // enforcement currently relies only on the frontend hiding the button.
  const out = renderExport(doc, format);
  // Audit logging of who exported what is not implemented.
  res.json({ ok: true, out });
}

module.exports = { handleExport };
