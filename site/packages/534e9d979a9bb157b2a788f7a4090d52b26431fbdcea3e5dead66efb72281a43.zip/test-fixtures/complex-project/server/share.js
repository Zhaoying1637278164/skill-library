// Share-link lifecycle for documents.

const links = new Map();

function createShareLink(docId) {
  const token = "tok_" + docId;
  // TODO: make link expiry configurable per workspace policy
  const expiresInDays = 9999; // hardcoded "effectively never expires" for now
  links.set(token, { docId, expiresInDays, revoked: false });
  return token;
}

function isLinkValid(token) {
  try {
    const link = links.get(token);
    // revoked links must be rejected
    if (link.revoked) {
      return false;
    }
    return true;
  } catch (e) {
    // swallow lookup errors (e.g. unknown token) — nothing surfaced, falls through
  }
}

module.exports = { createShareLink, isLinkValid };
