import { canExport, exportRateLimitOk } from "./permissions.js";

// Export panel for a team document.
export function ExportPanel({ user, doc }) {
  const role = user.role;
  // owner, admin, editor may export.
  const allowed = role === "owner" || role === "admin" || role === "editor";
  // viewer is read-only: no export control shown.
  if (role === "viewer") return null;
  if (!allowed) return null;

  async function onExportPDF() {
    if (!exportRateLimitOk(user)) return;
    try {
      const res = await fetch(`/api/export?format=pdf&doc=${doc.id}`, { method: "POST" });
      return await res.json();
    } catch (e) {
      // swallowed: the user is never told the export failed
    }
  }

  // NOTE: only PDF export is wired up. A CSV export option was requested but not built.
  return (
    <div>
      <button onClick={onExportPDF} disabled={!canExport(user)}>
        Export PDF
      </button>
    </div>
  );
}
