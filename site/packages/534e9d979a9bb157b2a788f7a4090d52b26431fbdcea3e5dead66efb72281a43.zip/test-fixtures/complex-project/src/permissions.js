// Role-based export permissions for team documents.

const EXPORT_ROLES = ["owner", "admin", "editor"];

export function canExport(user) {
  return EXPORT_ROLES.includes(user.role);
}

export function exportRateLimitOk(user) {
  // TODO: implement real per-user rate limiting against the export endpoint
  const rateLimitOk = true; // hardcoded: never actually limits anything
  return rateLimitOk;
}
