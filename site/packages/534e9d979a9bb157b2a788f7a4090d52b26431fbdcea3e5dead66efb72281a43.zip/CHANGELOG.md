# Changelog

All notable changes to the `spec-drift` plugin are documented in this file. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project adheres to
[Semantic Versioning](https://semver.org/).

**Semver policy:** classification-semantics changes (label output) = **major**; feature
additions = **minor**; documentation / rule false-positive fixes = **patch**.

## [1.0.0] - 2026-07-05

First public release. Everything below was developed unpublished and ships as a single version.

### Added

- Requirement extraction skill and `/spec-drift:init`: records the user's request as an explicit
  checklist in `SPEC_CHECKLIST.md` (functional and implicit requirements, open questions).
- Drift detection skill and `/spec-drift:report` / `/spec-drift:check`: classifies every
  checklist item as `missing` / `changed` / `silent-fail` / `hardcode-debt` / `done` using
  read-only static analysis (Grep-first scanning, no subagents).
- `--base <ref>` scoped detection: audits only files changed versus a validated git ref
  (metacharacter rejection, `git rev-parse` verification, single-argument passing, full-scan
  fallback on unresolvable refs).
- Tier 1 structural verification for guard-shaped code: constant-stub, swallowed-guard, and
  implicit-fallthrough detection, with an optional ast-grep rule bundle
  (`skills/drift-detection/rules/`) as an accelerator over the default Grep+Read path.
- Multi-task lifecycle: `.spec-drift/index.md` task index (byte-identical rebuilds),
  `/spec-drift:list`, and `/spec-drift:switch`.
- `verified-at` incremental re-verification: done items carry a commit receipt so unchanged
  evidence is skipped on later reports; full algorithm in
  `skills/drift-detection/references/verified-at.md`.
- Opt-in `--verify-runtime` runtime tier (Tier 2): explicit interactive consent, fixed
  seven-literal test-command allowlist, no-network sandbox, downgrade-only evidence mapping;
  full procedure in `skills/drift-detection/references/runtime-tier.md`.
- CI gate example (`.github/workflows/spec-drift.yml.example`): static-only headless report on
  pull requests, gating merges only on `missing` / `silent-fail` counts, with fork secret
  isolation.
- `SessionStart` hook that echoes a fixed reminder string.

### Changed

- Spec unification and skill diet (P3-A): the `verified-at` algorithm and the Tier 2 procedure
  moved from `SKILL.md` into Level-3 reference docs under `skills/drift-detection/references/`;
  the skill body keeps only invariants plus pointers (24.4 KB → 13.8 KB), and the `report` /
  `check` commands summarize behavior in one breath and reference the skill instead of restating
  the procedures.

### Security

- No file or request contents are ever turned into a shell command; the plugin is static-only
  by default and writes only `SPEC_CHECKLIST.md` (and `.spec-drift/index.md` where applicable).
- All git plumbing is read-only with validated single-argument inputs: shas matched as
  lowercase hex, paths charset-whitelisted and passed only after a literal `--`.
- `verified-at` markers are trusted only after each evidence path is proven tracked
  (`git ls-files --error-unmatch`) and present at the recorded sha (`git cat-file -e`), closing
  the untracked-file blindness of `git diff`; any uncertainty falls back to a full re-scan.
- Tier 2 hard gates: exact `--verify-runtime` token, orchestrator-obtained consent (headless and
  non-interactive contexts abort to static), fixed allowlist, sandbox with no network and a
  bounded timeout, never an unsandboxed fallback, and downgrade-only evidence.
