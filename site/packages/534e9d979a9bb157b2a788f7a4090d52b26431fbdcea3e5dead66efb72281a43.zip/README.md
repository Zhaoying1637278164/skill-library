# Spec Drift Detector

**English** | [한국어](./README.ko.md)

Catch the gap between what you asked for and what actually got built.

Long Claude Code sessions drift. A request like *"hide the button based on permissions"*
turns into *"admins covered, other roles skipped, one error silently swallowed, one value
hardcoded for now"* — and the session still reports **"done."** Spec Drift Detector makes
that gap visible: it extracts an explicit requirement checklist at the start of a task and
compares it against the real files when completion is claimed.

The plugin namespace is `spec-drift`, so its commands are `/spec-drift:init`,
`/spec-drift:check`, `/spec-drift:report`, `/spec-drift:list`, and `/spec-drift:switch`.

## How it works

1. **Extract** — at the start of a task, the `requirement-extraction` skill turns the
   request into a checklist in `SPEC_CHECKLIST.md` (functional requirements plus the
   commonly-forgotten implicit ones: all roles, all UI states, all API failure paths).
2. **Track** — `SPEC_CHECKLIST.md` is the single source of truth for the active task. Multiple
   concurrent tasks are indexed in `.spec-drift/index.md`; starting a new task auto-archives the
   previous checklist (by task slug) instead of silently overwriting it, and `/spec-drift:list`
   and `/spec-drift:switch` move between them.
3. **Detect** — when "done" is claimed, the `drift-detection` skill compares the checklist
   against the actual files and classifies each item as **missing**, **changed**,
   **silent-fail**, **hardcode-debt**, or **done**. Classification is **control-flow aware**
   (Tier 1): a constant-return guard, or a real check trapped inside a swallowed `catch`, is
   caught structurally — not by comments or identifier names. An optional `ast-grep` rule bundle
   accelerates this when `sg` is installed, but the default Grep+Read path never depends on it.

Everything is plain Markdown and **static by default**. The plugin reads your request and
your files; it never evaluates file contents as code and never builds shell commands out of
untrusted input. The **only** way it ever runs anything is the opt-in `--verify-runtime` flag,
which is default off and requires explicit interactive consent before it runs your project's
existing test suite once in a sandbox. (See [Security](#security).)

## Installation

Submission to the community plugin directory is in progress — the plugin is not yet listed.
Until it is listed, install locally from a checkout.

### Local install (current)

Clone the repo, then point Claude Code at the checkout — the repo root **is** the plugin:

```
git clone https://github.com/h102-log/spec-drift-detector-plan.git
claude --plugin-dir spec-drift-detector-plan
```

Or, from inside the checkout, point at the current directory:

```
claude --plugin-dir .
```

Use `/reload-plugins` to pick up edits during a session.

### From the community marketplace (after publishing)

Once the plugin is accepted into the community marketplace, this becomes the one-line install:

```
/plugin marketplace add anthropics/claude-plugins-community
/plugin install spec-drift@claude-community
```

> Not active yet — the submission is under review; `spec-drift` appears in `claude-community`
> once approved.
> `add` takes the marketplace **repo path** (`anthropics/claude-plugins-community`);
> `install` takes the **marketplace name** (`claude-community`).

## Commands

### `/spec-drift:init`

Start a requirement checklist for the current task. Reads the most recent task request (or a
description you pass as an argument), extracts functional and implicit requirements, and
writes `SPEC_CHECKLIST.md`. Surfaces up to three clarifying questions for genuinely ambiguous
scope.

```
/spec-drift:init
/spec-drift:init add role-based visibility to the export button
```

### `/spec-drift:check`

Show mid-task progress. Lists items still unimplemented and highlights the ones most at risk
of being dropped given the current work. Pass `--base <ref>` to scope the scan to the files
changed versus that ref.

```
/spec-drift:check
/spec-drift:check --base main
```

```
[Progress 2/5] 3 items still unimplemented.
At-risk items: guest role enforcement, API failure path
```

### `/spec-drift:report`

Generate a full drift report comparing `SPEC_CHECKLIST.md` against the actual files, grouped
by severity, with corrective follow-ups. Run it when completion is claimed. Pass `--base <ref>`
to scope the audit to the files changed versus that ref (`git diff --name-only <ref>...HEAD`):
faster and lower token use on large projects, at the cost of only auditing the diff. The ref is
validated first and the command falls back to a full scan if it does not resolve.

```
/spec-drift:report
/spec-drift:report --base main
```

Items already marked done carry a `verified-at: <sha>` receipt. On a later report, items whose
evidence files have not changed since that commit are skipped, so re-runs only re-scan what moved.
This composes with `--base` (the two scopes intersect).

### `/spec-drift:list`

List every tracked task with its live progress count, reading `.spec-drift/index.md` (or
discovering the checklists on disk when no index exists). The active task is marked.

```
/spec-drift:list
```

### `/spec-drift:switch`

Switch the active task to another tracked checklist by its slug: the current `SPEC_CHECKLIST.md`
is archived and the requested one is promoted in place. No checklist is ever silently overwritten.

```
/spec-drift:switch <task-slug>
```

## Skills (model-invoked)

Two skills run automatically when Claude judges them relevant, based on their `description`:

- **`requirement-extraction`** — triggers when a new task is described or when you ask to
  capture requirements. Writes `SPEC_CHECKLIST.md`.
- **`drift-detection`** — triggers when a completion is claimed ("done", "finished") or when
  you ask to audit completion. Produces the drift report.

The commands above invoke the same logic explicitly when you want deterministic control.

A `SessionStart` hook also prints a one-line reminder at the beginning of each session so the
workflow is discoverable. The hook only echoes a static string; it does not run analysis,
read your code, or take any action on its own.

## Example

### `SPEC_CHECKLIST.md` produced by `/spec-drift:init`

```markdown
# Spec Checklist — 2026-06-24T14:32:00

## Original request
"Hide the export button based on the user's permission."

## Extracted checklist
- [ ] admin role: button visible
- [ ] user role: button hidden
- [ ] guest role: button hidden
- [ ] hidden control is also rejected by the backend (not just hidden in the UI)
- [ ] API success and failure paths both handled

## Open questions (max 3)
- Q1: How should the "moderator" role be treated?
- Q2: Should a hidden button show an explanation, or nothing at all?

## Current implementation status
- [ ] admin role: button visible
- [ ] user role: button hidden
- [ ] guest role: button hidden
- [ ] backend rejection for unauthorized roles
- [ ] API success/failure paths
```

### Drift report produced by `/spec-drift:report`

```
Drift report — SPEC_CHECKLIST.md vs implementation

MISSING (1)
  - guest role: button hidden  (no role check found for guest)

CHANGED (1)
  - backend rejection: UI hides the button, but the endpoint still
    accepts the call from unauthorized roles (frontend-only enforcement)

HARDCODE-DEBT (1)
  - permission check: components/Export.tsx returns `canExport = true`
    with a "TODO: wire real permission" comment

DONE (2)
  - admin role: button visible
  - user role: button hidden

Summary: 2/5 requirements satisfied. 3 drift items need attention.

Next steps:
  1. Add guest handling to the visibility check.
  2. Enforce the permission on the backend endpoint, not just the UI.
  3. Replace the hardcoded `canExport = true` with the real check.
```

## Security

This plugin is intentionally low-risk and is **static by default**:

- It reads your task request and your source files and reasons about them.
- It writes exactly one Markdown file, `SPEC_CHECKLIST.md`.
- By default it never executes your project, never evaluates file contents as code (no
  `eval`/`exec`), never deserializes untrusted data, and never builds shell command strings from
  file or request content.
- `--verify-runtime` is the single opt-in exception that executes anything. It is **default off**;
  it requires explicit interactive consent **before any execution**; it aborts to static-only in any
  non-interactive or headless context (so it never auto-runs in CI); it runs **only** inside a
  sandbox with no network and a bounded timeout (never unsandboxed); and it runs only your project's
  **existing** test command, chosen from a fixed allowlist (`npm test` / `pnpm test` / `yarn test` /
  `pytest` / `go test ./...` / `cargo test` / `bundle exec rspec`) — never a command built from your
  file or request contents, and never the app itself. If consent is declined, no allowlisted command
  is detected, or the sandbox cannot be established, it falls back to static-only.
- The only shell commands it ever runs are read-only git plumbing, in exactly two situations.
  (a) When you explicitly pass `--base <ref>`, it runs `git diff --name-only` and `git rev-parse`
  to scope the audit to the files changed versus that ref. (b) When a done `- [x]` item carries a
  `verified-at: <sha>` marker **and** the project is a git repository, it runs read-only
  `git rev-parse`, `git ls-files`, `git cat-file`, and `git diff` to decide whether that item's
  evidence is unchanged since `<sha>` and can therefore be skipped. Every ref, sha, and path is
  charset-validated — rejected on whitespace or shell metacharacters (`;`, `|`, `&`, `$`, backtick,
  `<`, `>`, `(`, `)`, quotes, newline) — and passed as a single argument (paths only after a
  literal `--`), never interpolated into a larger command string. Any validation failure, an
  unresolvable sha, or the absence of git falls back to a full re-scan (fail-safe). Shell commands
  run **only** when a `--base` ref is given or a `verified-at` marker is present; with neither, the
  plugin runs no shell commands at all.
- The bundled `SessionStart` hook only echoes a fixed reminder string — no interpolation, no
  file access, no project execution.
- No secrets or tokens are stored or required.

## Benchmarks — does it actually help?

A controlled comparison holds the base model fixed and varies only the **method**:

- **Plugin** — the drift-detection method (Grep + targeted Read + Tier-1 control-flow reasoning),
  five categories.
- **No plugin** — an ordinary code review with no checklist taxonomy (binary done / not-done).
- **Category names only** — the five labels handed over with no method (a handicapped baseline).

Seven fixtures (43 requirements, single-label adversarial cases plus false-positive controls) ×
3 methods × 5 trials = **105 runs / 215 item-judgments per method**, each judgment scored
**objectively against a ground-truth `EXPECTED.md`** (not self-graded). "Dangerous miss" = a real
drift waved through as *done*; "false alarm" = a real *done* flagged as drift.

| Method | Categorizes drift? | Dangerous miss | False alarm | Category accuracy (strict / lenient) |
|---|---|---|---|---|
| **Plugin** (drift method) | yes — 5 categories | **4.5%** | **0%** | **82.3% / 94.0%** |
| No plugin (ordinary review) | no — done/not-done only | 7.7% | 0% | — |
| Category names only | yes | 5.2% | 2.2% | 60.0% / 72.1% |

Versus an ordinary review the plugin **roughly halves dangerous misses (7.7% → 4.5%)** and, unlike a
plain review, tells you *which kind* of drift each gap is. Versus merely knowing the five labels, the
method lifts category accuracy from 60% to 82%.

### Where it helps (and where it doesn't)

| Scenario | Plugin strict | Plugin danger-miss | No-plugin danger-miss | Baseline strict |
|---|---|---|---|---|
| Direct / simple | 60% | 0% | 0% | 60% |
| Complex multi-file | 84.6% | 0% | 0% | 83.1% |
| Hidden constant stub (no hints) | 100% | 0% | 0% | 0% |
| Adversarial control-flow | 86.7% | 10% | 16.7% | 50% |
| Cross-file references | 83.3% | 0% | 8% | 53.3% |
| Async error paths | 83.3% | 0%† | 20% | 50% |
| Indirection (factory / const) | 86.7% | 0% | 0% | 46.7% |

† Async plugin danger-miss read 16% in the original v3 run; a 105-run blind re-bench (2026-07-05,
base model Opus 4.8) re-measured it as **0/25** — every async silent-fail was flagged as drift in all
5 trials — while the no-plugin 20% and plugin strict 83.3% reproduced the v3 figures exactly. Only
this cell is updated; the other rows remain the original v3 measurement.

**Use it when** drift can hide behind indirection — a guard whose real decision lives in another
file, a factory that ignores its arguments, a module-level constant, a stub with no revealing
comment, or a check swallowed in a `catch`. These are exactly the rows where the method pulls far
ahead (indirection 86.7% vs 46.7%, cross-file 83.3% vs 53.3% while a plain review misses 8%, hidden
stub 100% vs 0%).

**Skip it when** the task is small, single-file and direct — there the plugin and an ordinary review
find the same things (the simple scenario ties at 60%).

**Honest limits.** N is small (43 items × 5 trials; on a 6-item fixture one or two calls swing a
percentage). The base model is strong, so a plain review is already fairly safe — these gaps are a
conservative lower bound. In a 105-run re-bench the plugin flagged every async silent-fail (0
dangerous misses across the async trials, versus 20% without it); async *category precision* is still
imperfect (strict 83.3%, mostly missing↔changed confusions), so it stays the scenario to review most
carefully. All plugin numbers are the static Grep+Read
path (`sg` was blocked locally, matching real local use). Full data and methodology:
[`docs/BENCHMARK_REPORT.md`](./docs/BENCHMARK_REPORT.md).

## Limitations

- **Precision over recall.** The extractor deliberately keeps the checklist short and
  high-signal. It will miss some requirements rather than flood you with a 100-item list.
- **Heuristic detection.** Drift classification relies on textual and control-flow pattern
  matching (role names, swallowed-error patterns, constant-return guards, `TODO`/`FIXME`,
  hardcoded literals), optionally accelerated by an `ast-grep` rule bundle when `sg` is present.
  It can produce false positives and false negatives. Treat the report as a prompt for review,
  not a proof. A 7-fixture benchmark of the static path is in
  [`docs/BENCHMARK_REPORT.md`](./docs/BENCHMARK_REPORT.md).
- **Runtime verification is opt-in.** By default it does not run your app or tests, so it cannot
  confirm that code actually behaves correctly at runtime — only that the requirement appears to be
  addressed in the source. With the opt-in `--verify-runtime` flag, after explicit consent, it runs
  your project's **existing** test suite (auto-detected from a fixed allowlist, never built from your
  file contents) once inside a no-network, time-bounded sandbox, and never starts the app. A failing
  mapped test can downgrade a `done` item to drift, but a passing test never promotes one.
- **Multiple tasks, one active.** `SPEC_CHECKLIST.md` is the active task; starting a new task
  (a different slug) auto-archives the previous one to `SPEC_CHECKLIST.<slug>.md` and indexes
  them all in `.spec-drift/index.md`. Nothing is silently overwritten; use `/spec-drift:list`
  and `/spec-drift:switch` to move between tasks.
- **gitRef scoping audits only the diff.** Passing `--base <ref>` limits the audit to files
  changed versus that ref (`git diff --name-only <ref>...HEAD`) — faster and lower token use,
  but it only audits the changed files; items whose evidence lies outside the diff keep their
  previously recorded status. Omit `--base` for a full scan.

## Committing the checklist

Whether `SPEC_CHECKLIST.md` (and the `.spec-drift/` registry) belong in version control
depends on how you use the plugin:

- **Local-only use.** If the checklist is just a scratchpad for your own sessions, keep it out
  of git. Add both to `.gitignore`:

  ```
  SPEC_CHECKLIST*.md
  .spec-drift/
  ```

- **CI gate.** If you enable the GitHub Actions gate (below), `SPEC_CHECKLIST.md` **must** be
  committed — the workflow reads it from the checked-out repository. If it is absent the gate
  skips itself and does not block the merge (see
  [`docs/ci-integration.md`](./docs/ci-integration.md)).

- **Team collaboration.** Commit only the `SPEC_CHECKLIST*.md` files; `.spec-drift/index.md` is
  derived and rebuilt on demand, so committing it is optional and conflict-free.

## Continuous integration (optional)

A ready-to-enable GitHub Actions workflow ships as
[`.github/workflows/spec-drift.yml.example`](./.github/workflows/spec-drift.yml.example) (inert
until you rename it). On each pull request it runs `/spec-drift:report --base <base>` in headless
mode (static-only — never `--verify-runtime`), posts the drift report as a single upserted PR
comment, and **blocks the merge only when a `missing` or `silent-fail` item is found**
(`changed`/`hardcode-debt` are reported but never block). Fork PRs run without secrets and the gate
self-skips. See [`docs/ci-integration.md`](./docs/ci-integration.md) for setup.

## Contributing

Issues and pull requests are welcome on the
[repository](https://github.com/h102-log/spec-drift-detector-plan). From the repository root
(which is the plugin root), run `claude plugin validate . --strict` before submitting changes.

## License

MIT — see [LICENSE](./LICENSE).
