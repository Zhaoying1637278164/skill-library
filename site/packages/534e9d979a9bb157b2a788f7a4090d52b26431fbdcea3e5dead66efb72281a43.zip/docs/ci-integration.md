# CI integration: spec-drift PR gate

This guide explains how to run spec-drift automatically on every pull request, post
the drift report as a PR comment, and block a merge only when it matters.

The plugin ships an INERT example workflow at
`.github/workflows/spec-drift.yml.example`. It ends in `.example` on purpose:
GitHub Actions only runs files named `*.yml` / `*.yaml`, so as committed it never
runs -- not on this plugin's own repository and not on yours. You enable it by
renaming it in your own project.

## What the gate does

On each pull request the workflow:

1. Checks out your repository with full history (`fetch-depth: 0`) so the PR base
   commit is available locally.
2. Runs `/spec-drift:report --base <PR base sha>` in headless Claude Code. The
   `--base` scoping audits only the files changed in the PR, exactly like running
   the command locally.
3. Posts the drift report as a single PR comment (updated in place on later pushes,
   not duplicated).
4. Fails the check ONLY when there are `missing` or `silent-fail` items. `changed`
   and `hardcode-debt` items appear in the comment but never block the merge.

This is the same static analysis the plugin performs by default. The workflow does
NOT pass `--verify-runtime`, so no project code is executed in CI.

## How to enable

From the root of YOUR project:

```
cp .github/workflows/spec-drift.yml.example .github/workflows/spec-drift.yml
git add .github/workflows/spec-drift.yml
git commit -m "Enable spec-drift PR gate"
```

Renaming (dropping `.example`) is the single switch that makes the workflow active.
To disable it again, delete or re-suffix the file. (Even if it were renamed on this
plugin's own repository, it would only invoke the read-only `/spec-drift:report`;
no project code is executed.)

You also need a `SPEC_CHECKLIST.md` in the repository (created by
`/spec-drift:init`). If it is absent the gate skips itself and does not block.

## Required secret and model auth

The workflow authenticates Claude Code with an API key:

- Add a repository secret named `ANTHROPIC_API_KEY`
  (Settings -> Secrets and variables -> Actions -> New repository secret).

If your organization uses a cloud provider instead of the Anthropic API, set the
corresponding environment in the `Run spec-drift report` step instead of
`ANTHROPIC_API_KEY`:

- Amazon Bedrock: `CLAUDE_CODE_USE_BEDROCK=1` plus your AWS credentials/region.
- Google Vertex AI: `CLAUDE_CODE_USE_VERTEX=1` plus your GCP credentials/project.

Consult the Claude Code docs for the exact variables for your provider.

## Required permissions

The workflow declares least-privilege permissions:

```
permissions:
  contents: read
  pull-requests: write
```

`pull-requests: write` is required to post the report comment via the built-in
`GITHUB_TOKEN`. If your organization sets the default workflow token to read-only,
enable write under Settings -> Actions -> General -> Workflow permissions, or keep
the per-workflow `permissions:` block as shipped (it overrides the default).

## Blocking vs. non-blocking

| Classification | In PR comment | Blocks merge |
| :-- | :-- | :-- |
| missing | yes | yes |
| silent-fail | yes | yes |
| changed | yes | no |
| hardcode-debt | yes | no |
| done | yes | no |

The gate decision is driven by structured integer counts returned by the report
(via `--json-schema`), not by parsing report text, so it is stable across wording
changes. If the structured payload is missing or the counts are not plain
integers, the job fails closed rather than passing silently.

## Security notes

- Static by default: the workflow never passes `--verify-runtime`, so project code
  is not executed in CI. It is pure read-only analysis plus read-only git plumbing.
- Bash is restricted to `Bash(git:*)`, so no arbitrary shell can run; no command is
  ever built from file or PR contents.
- The PR base is the GitHub-controlled base `sha` (a 40-char hex string, not
  attacker-injectable). It is passed through an environment variable (`BASE_SHA`)
  and IS referenced inside the `-p` prompt string, but it is re-validated hex-only
  by the `drift-detection` skill before any git command uses it, so prompt/command
  injection via the ref is not possible.
- The workflow uses `pull_request`, NOT `pull_request_target`. Pull requests from
  forks therefore run in the fork's context WITHOUT your repository secrets, so the
  Claude step has no API key and the gate is skipped for fork PRs. This is
  intentional: untrusted code from a fork never gains access to your secrets. Do not
  switch to `pull_request_target` to "fix" this -- that would expose secrets to
  untrusted code. Run the gate on trusted (same-repo) branches, or require a
  maintainer to re-run after review.
- The gate fails closed: if the structured payload is missing (`jq -e`) or the
  `missing`/`silent-fail` counts are not plain integers, or if the CLI/auth fails
  (`set -euo pipefail`), the job errors rather than passing the merge silently.
- The PR comment is publicly visible and contains model-generated report text
  (item names, file paths, and short evidence identifiers -- not full file dumps).
  Do NOT store secrets in `SPEC_CHECKLIST.md`.
- `Edit`/`Write` are allowed only so `/spec-drift:report` can update
  `SPEC_CHECKLIST.md`; nothing is committed or pushed in CI.
- Optional supply-chain hardening: pin the actions to commit SHAs instead of the
  major tags shipped here (`actions/checkout@v4`, `actions/setup-node@v4`,
  `actions/github-script@v7`). This is not required for correct operation.
