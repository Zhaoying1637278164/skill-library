# spec-drift-detector — 다음 작업 백로그 (Next Steps)

> `IMPROVEMENT_PLAN.md`(전체 로드맵)의 **다음 실행 단위**를 구체적 작업으로 분해한 문서.
> P0·P1·P2·**P3-A·P3-B는 완료**. 이 문서는 **P3-C 잔여(마켓 제출)·P3-D·P3-E**를 정의한다.
> 근거: 2026-07-05 P3-A/B 실행 결과 + P3-C 중간 상태(제출 직전 중단 지점).

---

## 0. 현재 상태 (P0~P3-B 완료 — 요약)

상세 근거는 `VERIFICATION_REPORT.md`(부모 repo 루트)·`CHANGELOG.md`·git 히스토리에 보존.

| 단계 | 내용 | 검증 |
| :-- | :-- | :-- |
| P0 | `--base <ref>` gitRef 스코핑(셸 메타문자 거부·rev-parse·단일 인자) + 타겟 읽기(Grep 선행→50~100줄 Read, 서브에이전트 금지) | 회귀 0, validate PASS |
| P1-A | Tier 1 구조 검증(constant-stub / swallowed-guard / implicit-fallthrough) + ast-grep 규칙 번들(선택 가속기) + trick fixture | sample 5/5·complex 13/13·trick 정답, 위험 오분류 0 |
| P1-B/C | 다중 task 인덱스(`.spec-drift/index.md`) + `list`/`switch` + `verified-at` 증분 재검증(untracked 맹점 방어) | 수명주기·증분·보안·회귀 0 |
| P2-A/B | opt-in `--verify-runtime`(플래그+동의+allowlist+샌드박스, downgrade-only) + CI 게이트 예시 | A-security 0·A-regression 0, YAML PASS |
| 벤치 v3 | 105-run 객관 채점: plugin dm 4.5%(naive 7.7%)·오탐 0%·strict 82.3%·일관성 96.3% | `docs/BENCHMARK_REPORT.md` |
| **P3-A** | SKILL.md 다이어트 24,425→**13,778B**(≤14KB): verified-at·Tier 2 상세를 `references/verified-at.md`(7,400B)·`references/runtime-tier.md`(6,668B)로 verbatim 분리, 본문은 불변식 4종+명령형 포인터. report.md 7,025→4,764B(3중 사본 절 삭제)·check.md 5,513→5,260B(preserve/drop 계약·보안 문단 유지). 분류/Tier 1/패턴 표 byte-identical | validate --strict PASS, 픽스처 5런(sample·trick×1·complex×3) **위험 오분류 0**, complex 3런 라벨 완전 동일, README 신규 상충 0 |
| **P3-B** | `CHANGELOG.md` 신설(Keep a Changelog, semver 정책 1줄, P0~P3-A 통합 `[1.0.0] - 2026-07-05` 엔트리). 버전 **1.0.0 유지** — plugin.json 무변경 | validate PASS, 버전 표기 일치 |

**커밋 상태**: `2a418ed`(P3-A)·`448c978`(P3-B) — 브랜치 `fix/usability-pre-marketplace`, **미푸시**.
**워킹트리 미커밋 변경(P3-C 1차분, 커밋 대기)**: README EN/KO 설치 절 "리뷰 대기" 문구 4곳
(EN L40·L68 / KO L38·L66 상당) + 본 문서 갱신.

### 결정 확정 (§구 6 — 전부 해소)

1. **배포 경로**: community 제출 — 단 **PR 아님**. `anthropics/claude-plugins-community`는
   read-only 미러로 PR 자동 클로즈. 제출은 **폼**(`clau.de/plugin-directory-submission`) →
   자동 보안 스캔 → Anthropic 내부 리뷰 → 승인 시 nightly sync로 등재.
2. **버전**: **1.0.0 유지**(최초 공개 논리) — 완료(P3-B).
3. **B3 리네이밍**: **생략**(2026-07-05 실행 단계에서 '승인'→'생략' 변경) — 현행
   `h102-log/spec-drift-detector-plan` 유지, 제출도 현행명 기준. plugin.json·README URL 무변경.

---

## 1. P3-C 잔여 — 마켓 제출 (B2 해소)

- **담당**: `manager-git` (C-1·C-2·C-5), 사용자 (C-3), `manager-docs` (C-4)
- **현황**: gh CLI 설치 완료(`C:\Program Files\GitHub CLI\gh.exe`, **미인증** — 리네이밍 생략으로
  현재 불필요. push는 git credential(GCM)로 동작, 기존 푸시 이력 있음).

### C-1. P3-C 1차 커밋

워킹트리 변경(README 리뷰 대기 문구 + 본 문서) 커밋.
제안 메시지: `docs: 마켓 제출 준비 — README 리뷰 대기 문구 + 백로그 갱신 (P3-C)`

### C-2. main 머지 + 푸시

- 로컬 `main`(41b56f2, 낡음)을 `origin/main`(db4852a)으로 먼저 동기(ff).
- `fix/usability-pre-marketplace` → `main` 머지. 기존 관행은 GitHub PR 경유(#1~#4,
  merge commit) — 로컬 `--no-ff` 머지가 동형. 웹 PR(#5)로 해도 무방(택1).
- `main` + 브랜치 푸시. ※ 사용자 승인 기득(2026-07-05 "main 머지 + 푸시").

### C-3. 제출 폼 (사용자 액션 — 자동화 불가)

`clau.de/plugin-directory-submission` 제출. 입력 정보는 §4 패키지 참조.
제출 후 자동 보안 스캔 + 내부 리뷰 대기(기간 미상).

### C-4. 승인 후 README 마무리

- EN/KO "리뷰 대기/not yet listed" 문구 4곳 제거, 커뮤니티 설치 절을 기본 설치로 승격
  (`/plugin marketplace add anthropics/claude-plugins-community` +
  `/plugin install spec-drift@claude-community`), 로컬 설치는 개발용으로 격하.
- 신규 환경에서 한 줄 설치 실동작 + `/spec-drift:init` 즉시 사용 확인 → 커밋·푸시.

### C-5. 부모 repo 서브모듈 포인터 갱신

`C:\Users\bhy99\proj\plugin`에서 서브모듈 포인터 커밋(관행: "chore: … 반영 + 서브모듈 포인터 갱신").

**수용 기준**: README "리뷰 대기" 안내 제거(C-4), 한 줄 설치가 신규 환경에서 실동작, 설치 후
`/spec-drift:init` 즉시 사용 가능.
**리스크**: 보안 스캔/리뷰 반려 — 반려 사유 기반 수정 후 재제출(반려 시 이 문서에 항목 추가).

## 2. P3-D. 사용 문서 보강 — SPEC_CHECKLIST 취급 가이드 + 보안 절 정정

- **담당**: `manager-docs`
- **작업**:
  1. README EN/KO에 "체크리스트를 커밋해야 하나?" 절 추가:
     - 로컬 전용 → `.gitignore`에 `SPEC_CHECKLIST*.md`·`.spec-drift/` 예시.
     - CI 게이트 → 커밋 필요(게이트는 체크리스트 부재 시 self-skip 명시).
     - 팀 협업 시 인덱스 byte-identical 재빌드라 머지 친화적 — 1줄.
  2. **(P3-A 스윕에서 발견)** README §Security 정정: "`--base` 없으면 셸 명령을 전혀 실행하지
     않는다" 문구는 P1 `verified-at` plumbing(`rev-parse`·`ls-files`·`cat-file`·`diff`) 도입
     이후 부정확 — "읽기 전용 git plumbing은 `--base` 또는 `verified-at` 마커 존재 시에만"으로
     교정(EN L226-231 상당 + KO 대응).
- **수용 기준**: EN/KO 동기, `docs/ci-integration.md`와 상충 없음.
- **순서 주의**: C-4와 같은 README 편집 — **C-4 완료 후 착수**(충돌 방지).

## 3. P3-E. 품질 잔여 — ✅ E-1·E-2·E-4 완료, E-3 CI 대체 (2026-07-05)

> **E-1 결과**: Tier 1 "Reachability" 불릿에 호출측 무력화 3형(awaited+trailing `.catch` /
> **missing `await`** / `?.`+강비교 바이패스) + FP 이중 보호(표면화 catch=집행, 품질≠요구사항)
> 명시. SKILL.md 14,282B(캡 −54B, Efficient scanning·Scoped detection 산문 상쇄 조임).
> 검증 11런: async 사후 3런 silent-fail recall **9/9·dm 0**(베이스라인 3런도 dm 0 — v3의
> 16%는 당시 조건, 현 조건 미재현), 회귀 5픽스처 위험 0 — adversarial #6(missing await)·
> crossfile #3(call-site `.catch`) 정확, crossfile #6 FP 컨트롤 통과. **잔여**: async #6
> 오탐 1/3런(sign 품질을 hardcode-debt로 — 베이스라인 동률, 편집 비유발; 2/3런은 신규
> advisory 문구 인용하며 done). 추가 문구는 픽스처 과적합 리스크로 중단.
> **E-2 결과**: `.github/workflows/os-smoke.yml` 신설 — ubuntu/macos matrix,
> golden-corpus(sg 설치, 키 불요) + plugin-smoke(한글 경로 헤드리스 report,
> `ANTHROPIC_API_KEY` 시크릿 없으면 self-skip). **E-3**: 로컬 sg/jq 부재 → CI
> golden-corpus가 sg 경로 상시 커버로 대체, 105-run sg 재벤치는 보류.
> **E-4 결과(async recall 재검증, 2026-07-05)**: 현 SKILL.md로 async-project 독립 블라인드
> 5런(EXPECTED 미열람) — silent-fail recall(#1·2·3) **15/15·dm 0**, item-6 FP **0/5**(E-1
> 잔여 1/3 미재현), **일관성 100%**(5런 라벨 완전 동일), strict 83.3%. 수용기준 async dm
> ≤10% **충족(0%)**. 확인: v3 "16%"는 **baseline 모델** 수치(벤치 L44/L114 — plugin은 애초
> dm 0%), 즉 shipping plugin은 목표 이미 달성. **잔여 #4 missing↔changed 계통 오분류(5/5)**:
> 비위험(둘 다 드리프트 플래그, done 아님) — auditor가 LOG_ROLES 배열엔 있으나 canViewLogs
> 결정 경로 부재라 missing↔changed는 실체적 경계. SKILL.md 편집 **보류**(과적합·behavior-
> preservation 리스크; E-1 중단 사유와 동일).

- **담당**: `expert-testing`
- **작업** (기존 정의 유지):
  1. ✅ **async recall 보강 — 재검증 완료(E-4)**: v3 "16%"는 baseline 수치, plugin은 이미
     dm 0%. 5런 재측정 dm 0%·sf-recall 15/15·일관 100% → SKILL.md **무편집**(과적합 회피).
     잔여 #4 missing↔changed는 비위험 한계로 수용. 상세는 위 E-4 결과 블록.
  2. **2차 OS 스모크**(T7 잔여): Linux/macOS에서 init→report→archive→한글 경로 실측.
     GitHub Actions matrix(ubuntu/macos) 자동화 권장.
  3. **sg 활성 벤치**(선택): ast-grep 설치 환경에서 v3 동일 코퍼스 재측정 — 폴백 대비 delta.
- **수용 기준**: async dangerous-miss 16% → ≤10%, 타 시나리오 무회귀(FP 컨트롤 3개 오탐 0 유지).
  OS 스모크는 체크리스트 생성·rename·한글 경로 PASS.

---

## 4. 제출 정보 패키지 (C-3 폼 입력용)

| 항목 | 값 |
| :-- | :-- |
| Plugin name | `spec-drift` (displayName: Spec Drift Detector) |
| Version / License | 1.0.0 / MIT |
| Repository | `https://github.com/h102-log/spec-drift-detector-plan` (기본 브랜치 `main`, C-2 후) |
| Author | bh102 (`https://github.com/h102-log`) |
| Description | plugin.json `description` 그대로 (drift 감지: 요구사항 체크리스트 vs 실제 구현, missing/changed/silent-fail/hardcode-debt 분류) |
| Keywords | spec, drift, requirements, validation, checklist, completion, static-analysis |
| 검증 근거 | `claude plugin validate . --strict` PASS · 벤치 v3 105-run(위험 오분류 4.5%, 오탐 0%) · 픽스처 게이트 5런 위험 0 · `CHANGELOG.md` [1.0.0] |
| 보안 요지 | 기본 정적 전용(파일 실행·eval 없음). 유일 실행 예외 = opt-in `--verify-runtime`(대화형 동의 + 무네트워크 샌드박스 + 고정 allowlist 7종, downgrade-only). git plumbing은 읽기 전용·검증된 단일 인자(`--` 후 경로). 훅은 고정 문자열 echo 1개 |

## 5. 실행 순서·병렬성

1. **C-1 → C-2** (커밋·머지·푸시) — 순차, 선행 필수.
2. **C-3** (사용자 폼 제출) → 리뷰 대기.
3. 대기 중 병행 가능: **P3-E**(E-1 SKILL.md·E-2 CI matrix — README 무접촉).
4. 승인 후: **C-4 → C-5 → P3-D** (셋 다 README/포인터 — 순차).

## 6. 공통 검증 (전 항목)

- 기본 경로 라벨 회귀 0: `EXPECTED.md` / `EXPECTED_COMPLEX.md` / `EXPECTED_TRICK.md` 대조.
- `claude plugin validate . --strict` PASS.
- README EN/KO 동기 유지, 보안 절 서술과 실제 동작 일치.
- 커밋·푸시는 사용자 지시 후(현행 관행 유지). SKILL.md는 14,336B 캡 유지.
