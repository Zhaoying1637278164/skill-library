# spec-drift-detector 벤치마크 리포트 (v3)

대상 독자: 플러그인 유지보수자
버전: v3 (105-run 확대 실행, 2026-06-28; v2.1 ground-truth 재라벨 유지)

## 0. v3 헤드라인 (105-run, 표본 확대)

v2(63-run)를 7픽스처 × 3조건(plugin / naive=미사용 / baseline) × **5트라이얼 = 105런, 조건당
215 항목-판정**으로 확대 재측정. 각 판정은 EXPECTED 정답지로 **코드 객관 채점**(자기판정 아님).
1차 실행 시 rate-limit으로 36런 드롭 → resume로 0 드롭 완료.

| 조건 | dangerous-miss% | false-alarm% | strict% | lenient% | consistency% |
|---|---|---|---|---|---|
| plugin | 4.5 | 0 | 82.3 | 94.0 | 96.3 |
| naive (미사용) | 7.7 | 0 | N/A | N/A | 99.1 |
| baseline | 5.2 | 2.2 | 60.0 | 72.1 | 90.2 |

시나리오별 (plugin strict% / plugin dm% / naive dm% / baseline strict%):

| 시나리오 | plugin strict | plugin dm | naive dm | baseline strict |
|---|---|---|---|---|
| Direct/simple (sample) | 60 | 0 | 0 | 60 |
| Complex multi-file | 84.6 | 0 | 0 | 83.1 |
| Hidden constant stub (trick) | 100 | 0 | 0 | 0 |
| Adversarial control-flow | 86.7 | 10 | 16.7 | 50 |
| Cross-file references | 83.3 | 0 | 8 | 53.3 |
| Async error paths | 83.3 | 0* | 20 | 50 |
| Indirection (factory/const) | 86.7 | 0 | 0 | 46.7 |

> *비동기 재벤치(2026-07-05): 위 async plugin dangerous-miss(원래 16%)를 105-run 블라인드 재실행
> (베이스 모델 Opus 4.8, EXPECTED-blind 분류 → 코드 객관 채점)으로 재측정 → **0/25**(5트라이얼 전부,
> async 드리프트 5개 항목이 매 트라이얼 드리프트로 분류, "done" 오통과 0). 미사용 async dm(20%)과
> plugin async strict(83.3%)는 원 v3와 정확히 재현되었고, E-4의 이전 5-run 블라인드도 0%였다.
> async plugin dm 셀만 갱신하며 나머지 셀은 원 v3 측정값을 유지한다 — 전체 코퍼스를 Opus 4.8 +
> 더 엄격한 done-on-alt 채점으로 재실행하면 여러 비-async 셀이 이동하므로, 방법론 혼합을 피하기
> 위해 스왑하지 않는다(재벤치 헤드라인 참고치: plugin dm 7.1 / naive 15.3 / baseline 14.7).

요지: plugin은 미사용(naive) 대비 위험 누락을 7.7%→4.5%로 줄이고, 미사용이 못 하는 **카테고리
식별**을 제공(strict 82.3% vs baseline 60%). 우위는 간접참조·교차파일·은닉 스텁·비동기 경로에
집중되고, 단순·직접 작업에서는 차이 없음(sample 60=60). 한계: 표본 작음(43항목×5트라이얼), 강한
베이스모델 → 보수적 하한, async 위험누락은 2026-07-05 재벤치에서 0/25로 재측정(위 * 참조), 정적 폴백(sg 차단)만 측정.

v3 수치(105-run)가 최신 헤드라인이다. 아래 §1~§7은 v2(63-run) 상세이며 방법론·divergent 항목
분석은 동일하게 유효하다(절대 수치는 표본이 작아 v3와 일부 다를 수 있음).

## 1. 요약 (Headline)

이번 v2 벤치마크는 v1의 한계(작고 쉬운 코퍼스, 모호한 다중 라벨, 베이스라인만 비교)를 보완하기 위해 더 크고 어려운 코퍼스, 단일 라벨 적대적 픽스처, 세 가지 조건, 더 풍부한 지표로 재설계했습니다.

결과를 과장 없이 정리하면 다음과 같습니다.

- plugin 조건이 명확한 우위를 보였습니다. 모든 실제 드리프트 및 실제 "done" 항목-트라이얼에서 위험한 누락(dangerous miss) 0%, 오탐(false alarm) 0%를 기록했고, strict 정확도 88.4% / lenient 정확도 96.1% (kappa 0.853), 트라이얼 간 일관성 96.9%로 가장 높았습니다.
- baseline은 가장 어려운 케이스에서 크게 뒤처졌습니다. strict 정확도 69.8%, 그리고 위험한 누락 6.5%라는 치명적인 수치를 보였습니다. 이는 adversarial #4와 async #3의 async-bypass silent-fail을 "done"으로 라벨링했기 때문입니다.
- naive(플러그인 미사용)는 "not-done"으로 기본 판단하는 보수적 성향 덕분에 위험한 누락은 대부분 회피했으나(3.2%), 카테고리 해상도가 전혀 없고, 오탐률이 가장 나빴으며(7.4%, crossfile #6에서 흔들림), missing/changed/hardcode-debt/silent-fail을 전혀 구분하지 못합니다.

plugin의 우위는 간접 참조가 많은 픽스처(crossfile, indirection)에 집중되어 있습니다(baseline 50% / 77.8% → plugin 100%). v2.1 ground-truth 재라벨 이후 의심(suspect) 항목은 없습니다.

정직한 단서: strict 정확도 격차는 분명하지만, naive와 plugin은 "위험한 누락"이라는 안전성 측면에서는 격차가 크지 않습니다(naive 3.2% vs plugin 0%). 다만 naive는 오탐과 카테고리 식별 불가라는 별도의 비용을 치릅니다.

## 2. 테스트 케이스 코퍼스

총 7개 픽스처, 43개 항목.

| 픽스처 | 항목 수 | 분류 | 라벨 방식 | 비고 |
|---|---|---|---|---|
| sample | 5 | Original (lenient) | primary + alt | 기본 샘플 |
| complex | 13 | Original (lenient) | primary + alt | 복합 케이스 |
| trick | 1 | Original (lenient) | primary + alt | 트릭 케이스 |
| adversarial | 6 | New v2 | 단일 명확 라벨 | naive 무력화 설계 |
| crossfile | 6 | New v2 | 단일 명확 라벨 | 파일 간 참조, FP 컨트롤 1개(#6) |
| async | 6 | New v2 | 단일 명확 라벨 | 비동기 경로, FP 컨트롤 1개(#6) |
| indirection | 6 | New v2 | 단일 명확 라벨 | 간접 참조, FP 컨트롤 1개(#5) |

- Original 그룹(sample, complex, trick): 19개 항목, lenient 채점(주 라벨 + 대안 라벨 허용).
- New v2 그룹(adversarial, crossfile, async, indirection): 24개 항목, 단일 명확 라벨이며 naive 방식을 무력화하도록 설계.
- False-positive 컨트롤(3개): 실제로는 "done"이지만 드리프트처럼 보이는 케이스로, 과도한 플래깅(over-flagging)을 측정하기 위한 장치입니다.
  - crossfile #6
  - async #6
  - indirection #5

## 3. 방법론

유일한 변수는 "방법(method)"입니다. 그 외 입력은 모든 조건에서 동일합니다.

세 가지 조건:

- naive: 일반적인 리뷰. 플러그인 없음, 카테고리 어휘 없음(이진 done/not-done). 현실적인 "플러그인 미사용" 베이스라인.
- baseline: 5개 카테고리 이름만 제공하고 방법은 제공하지 않음(v1의 핸디캡 베이스라인, 보수적).
- plugin: 드리프트 감지 스킬의 정적 Tier-0/Tier-1 방법(Grep + Read).
  - ast-grep(sg)는 설치되어 있었으나 OS 애플리케이션 제어 정책에 의해 차단(BLOCKED)되어 폴백 경로가 실행되었습니다. 이는 실제 로컬 사용 환경과 동일한 조건입니다.

트라이얼: 픽스처당 조건당 3회, 총 63회 실행.

채점 표기:
- dangerous-miss%: 실제 드리프트를 "done"으로 잘못 통과시킨 비율(안전성에서 가장 중요).
- false-alarm%: 실제 "done"을 드리프트로 잘못 플래깅한 비율.
- strict / lenient 정확도: 단일 라벨 일치(strict) vs 대안 라벨 허용(lenient).
- kappa: Cohen's kappa(우연 보정 일치도).
- consistency%: 동일 입력에 대한 트라이얼 간 결과 일관성.

naive 조건의 strict/lenient/kappa는 카테고리 어휘가 없어 측정 불가이며 JSON에서 -1로 표기됩니다.

## 4. 결과 — 조건별 지표

| 조건 | dangerous-miss% | false-alarm% | strict 정확도% | lenient 정확도% | kappa | consistency% |
|---|---|---|---|---|---|---|
| naive | 3.2 | 7.4 | N/A | N/A | N/A | 95.3 |
| baseline | 6.5 | 0 | 69.8 | 79.8 | 0.619 | 85.3 |
| plugin | 0 | 0 | 88.4 | 96.1 | 0.853 | 96.9 |

N/A: naive는 이진 판단만 하므로 카테고리 기반 지표를 측정할 수 없음(JSON 원본 -1).

픽스처별 세부:

| 픽스처 | naive dangerous-miss% | baseline strict% | plugin strict% |
|---|---|---|---|
| sample | 0 | 60 | 60 |
| complex | 0 | 82.1 | 89.7 |
| trick | 0 | 100 | 100 |
| adversarial | 11.1 | 72.2 | 88.9 |
| crossfile | 0 | 50 | 100 |
| async | 6.7 | 55.6 | 83.3 |
| indirection | 0 | 77.8 | 100 |

관찰:
- plugin의 우위는 crossfile(50→100), indirection(77.8→100), async(55.6→83.3)에 집중됩니다.
- sample에서는 plugin과 baseline이 동일(60)합니다. 즉, 쉬운 케이스에서는 차이가 없습니다.
- naive의 위험한 누락은 adversarial(11.1%)과 async(6.7%)에서만 나타납니다. 즉 naive의 안전성 위험은 비동기/적대적 케이스에 한정됩니다.

## 5. 핵심 비교: naive(미사용) vs plugin(사용)

안전성(dangerous-miss)과 신뢰성(false-alarm) 중심으로 비교하면:

| 지표 | naive | plugin | 격차 |
|---|---|---|---|
| dangerous-miss% | 3.2 | 0 | 3.2%p |
| false-alarm% | 7.4 | 0 | 7.4%p |

정직하게 말하면, naive의 위험한 누락 3.2%는 "not-done 기본값" 전략 덕분에 이미 낮은 편입니다. plugin은 이를 0%까지 낮추지만 절대 격차는 3.2%p로 작습니다. 더 큰 차이는 오탐(7.4%p)과 카테고리 식별 능력에서 나옵니다. naive는 missing/changed/hardcode-debt/silent-fail을 전혀 구분하지 못합니다.

### plugin이 baseline을 이긴 항목 (divergentItems)

아래는 plugin이 정답을 맞히고 baseline이 틀린 항목입니다. naive 포착은 naive가 (이진 수준에서) 드리프트로 잡아냈는지 여부입니다.

| 픽스처 | index | 정답(expected) | baseline 결과 | plugin 결과 | naive 포착 |
|---|---|---|---|---|---|
| complex | 10 | silent-fail | done | silent-fail | 아니오 |
| adversarial | 4 | silent-fail | done | silent-fail | 아니오 |
| crossfile | 1 | hardcode-debt | silent-fail | hardcode-debt | 예 |
| crossfile | 2 | hardcode-debt | silent-fail | hardcode-debt | 예 |
| crossfile | 5 | changed | silent-fail | changed | 예 |
| async | 3 | silent-fail | done | silent-fail | 예 |
| async | 5 | changed | missing | changed | 예 |
| indirection | 2 | hardcode-debt | silent-fail | hardcode-debt | 예 |
| indirection | 6 | changed | missing | changed | 예 |

특히 주목할 점:
- complex #10, adversarial #4는 baseline이 "done"으로 통과시킨, 즉 위험한 누락에 해당하는 silent-fail 케이스입니다. naive도 이 두 항목은 포착하지 못했습니다(naive 포착: 아니오). 이는 두 방법 모두의 사각지대입니다.
- adversarial #4와 async #3는 baseline의 6.5% 위험한 누락을 만든 async-bypass silent-fail 사례입니다.
- 나머지 항목에서 baseline은 드리프트 자체는 감지했으나 카테고리를 오분류(silent-fail/missing 등)했습니다. plugin은 정확한 카테고리를 식별했습니다.

## 6. ground-truth 의심 항목 및 한계

### Ground-truth 의심 항목

v2.1 ground-truth 재라벨 이후 의심(suspect) 항목은 없습니다 (suspectGroundTruth: 빈 목록).

### 한계

- 표본 규모: 7개 픽스처, 43개 항목, 조건당 3트라이얼(총 63회). 통계적으로 작은 표본이며, 특히 픽스처별 단일 항목(trick=1)이나 6개 항목 픽스처에서는 1~2개 차이가 백분율을 크게 흔듭니다(예: adversarial 11.1%는 18개 항목-트라이얼 중 2건 수준).
- 강한 베이스 모델: 평가에 사용된 기반 모델 자체가 강력하기 때문에, naive조차 위험한 누락이 낮게(3.2%) 나왔습니다. 약한 모델이나 인간 리뷰어에서는 격차가 더 벌어질 수 있습니다. 즉 이 결과는 plugin 효과의 보수적 하한에 가깝습니다.
- ast-grep(sg) 미실행: sg가 OS 정책으로 차단되어 폴백(Grep + Read) 경로만 측정되었습니다. 본 리포트의 plugin 수치는 폴백 성능이며, sg 활성화 시의 잠재 성능은 측정되지 않았습니다. 다만 폴백 조건은 실제 로컬 사용 환경과 일치합니다.
- false-positive 컨트롤이 3개뿐이라 오탐률(0%)의 신뢰구간은 넓습니다.

## 7. 결론

plugin 조건은 이번 v2 벤치마크에서 명확한 우위를 보였습니다. 위험한 누락 0%, 오탐 0%, strict 88.4% / lenient 96.1%, 일관성 96.9%로 세 조건 중 모든 지표에서 최고입니다.

다만 정직하게 짚으면:
- 안전성(위험한 누락) 절대 격차는 naive 대비 3.2%p로 크지 않습니다. naive의 보수적 "not-done" 기본값이 이미 대부분의 위험을 회피하기 때문입니다.
- plugin의 실질적 가치는 (a) 오탐 제거(7.4%p), (b) 정확한 카테고리 식별(naive는 불가), (c) baseline 대비 어려운 간접 참조 케이스(crossfile/indirection 50~77.8% → 100%)에서 두드러집니다.
- 쉬운 케이스(sample)에서는 plugin과 baseline의 차이가 없습니다.

유지보수 관점의 권고: plugin은 간접 참조와 비동기 경로가 많은 코드베이스에서 가장 큰 이득을 줍니다. ast-grep 차단 환경에서도 폴백 경로가 충분히 동작함이 확인되었으나, sg 활성화 시 성능은 후속 벤치마크에서 별도 측정이 필요합니다.
