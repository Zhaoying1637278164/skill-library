# spec-drift-detector 개선 계획 — 3개 에이전트 팀 구성

> 예상 문제점 3개 범주를 각각 전담하는 에이전트 팀을 구성하고, 각 팀이 문제를 어떻게 해결할지
> 전략과 단계별 실행 로드맵을 정리한 문서. 코드 변경 없는 설계 문서다.

---

## 1. 배경 (Context)

`spec-drift-detector`는 Claude Code 플러그인으로, 긴 세션에서 발생하는 **요구사항 표류(drift)** —
사용자가 요청한 것과 실제로 구현된 것 사이의 간극 — 을 잡아낸다.

### 현재 구조

| 구성 요소 | 내용 |
| :-- | :-- |
| **skills** | `requirement-extraction` (요청 → `SPEC_CHECKLIST.md` 체크리스트 생성), `drift-detection` (체크리스트 vs 실제 파일 비교 → missing / changed / silent-fail / hardcode-debt / done 분류) |
| **commands** | `/spec-drift:init`, `/spec-drift:check`, `/spec-drift:report` |
| **hook** | SessionStart 정적 echo 1줄 (분석·파일접근·실행 없음) |
| **설계 원칙** | 정적 분석 전용, **정밀도 우선(precision over recall)**, 런타임 미실행, 보안 저위험 |

### 탐색 중 확인한 중요 사실

사용자가 지적한 **"경직된 작업 관리 / 매번 수동 리셋"** 문제는 `requirement-extraction/SKILL.md`에
**이미 slug 기반 자동 archive 로직이 존재**한다.

- 같은 task(slug 일치) → `SPEC_CHECKLIST.md`를 in-place 갱신(기록 보존)
- 다른 task(slug 불일치) → 기존 파일을 `SPEC_CHECKLIST.<old-slug>.md`로 보관 후 신규 생성
- 절대 조용히 덮어쓰지 않음

따라서 이 항목은 "신규 구현"이 아니라 **"다중 동시 task 인덱싱 / 전환"** 보강으로 범위를 좁힌다.

### 핵심 제약

> **세 팀 모두 플러그인의 보안 자세(기본 정적 분석, 런타임 실행 금지)를 보존한다.**
> 런타임 검증은 반드시 opt-in + 샌드박스로만 도입한다.

---

## 2. 3개 에이전트 팀 구성 (개요)

| 팀 | 담당 문제 범주 | 리드 | 구성원 |
| :-- | :-- | :-- | :-- |
| **T1 탐지 엔진 강화팀** | ① 정적 분석·휴리스틱 한계 (낮은 recall, 런타임 미검증 "눈속임 코드", 작업 관리) | `manager-quality` | `expert-refactoring`, `expert-testing`, `expert-debug`, `builder-skill` |
| **T2 플랫폼 최적화팀** | ② Claude Code 연동 한계 (lossy compaction, 토큰 급증·사용량 만료) | `expert-performance` | `builder-skill`, `builder-plugin`, `manager-strategy` |
| **T3 엔터프라이즈 통합팀** | ③ 실무 괴리 (다중 브랜치·협업, git 히스토리/gitRef diff 부재) | `manager-git` | `expert-backend`, `expert-devops`, `manager-strategy` |

각 팀은 독립 문제 범주를 소유하므로 **병렬 실행 가능**하다. 단 공유 상태 스키마(`.spec-drift/`)는
Phase 0에서 `manager-strategy`가 먼저 합의한다(아래 로드맵 참조).

---

## 3. T1 — 탐지 엔진 강화팀

**담당**: 정적 분석·휴리스틱 엔진 자체의 기술적 한계
**리드**: `manager-quality` / **구성원**: `expert-refactoring`, `expert-testing`, `expert-debug`, `builder-skill`

### 3.1 낮은 recall → 요구사항 누락

| 해결책 | 내용 | 담당 |
| :-- | :-- | :-- |
| **2단 체크리스트** | 기본은 현행 고신호 "core" 리스트로 정밀도 유지. `--exhaustive` 플래그 시 경계조건·예외처리·동시성·입력검증 카테고리를 별도 "extended" 섹션으로 확장. **기본 노출하지 않아** 알림 피로 방지. | `builder-skill` |
| **recall self-audit 패스** | completeness critic 패턴: 1차 추출 후 2차 추출이 요청을 적대적으로 재독해 "빠진 경계/예외 요구사항은 무엇인가?"를 질문 → core 리스트를 깨지 않고 누락만 보완. | `requirement-extraction/SKILL.md` 보강 |
| **카테고리 템플릿** | 현행 권한/UI/API 외에 boundary·error·concurrency·validation 템플릿을 추출기가 참조하도록 추가. | `builder-skill` |

**원칙**: 정밀도 우선 철학을 버리지 않는다. 기본값은 그대로 두고, recall은 **opt-in 확장**으로만 제공한다.

### 3.2 런타임 미검증 → "눈속임 코드" 미탐지 (핵심 난제)

정적 전용 설계(보안 보장)를 깨지 않도록 **계층형 검증(tiered verification)** 을 도입한다.

| Tier | 내용 | 보안 영향 | 담당 |
| :-- | :-- | :-- | :-- |
| **Tier 0 (현행)** | 텍스트/식별자 매칭 (역할명, 엔드포인트, 컴포넌트명 등) | 없음 | — |
| **Tier 1 신규 — AST 구조 검증** | 변수명·주석이 아닌 **실제 제어흐름**을 검증. 예: role 체크가 swallowed catch 안에 갇혀 있지 않고 도달 가능한지, 상수(`return true`)가 아닌 실제 로직인지. drift-detection을 텍스트→구조 매칭으로 승격. | 없음 (정적 유지) | `expert-refactoring` (+ `moai-tool-ast-grep`) |
| **Tier 2 신규 — 런타임 검증 (opt-in)** | `--verify-runtime` 플래그 + Claude Code Bash 샌드박스에서 프로젝트의 **기존 테스트**를 실행, 결과를 체크리스트 항목에 매핑. 깨진 로직은 테스트 실패로 드러나 "눈속임" 탐지. **명시적 동의 필요**(정적 보장을 깨므로). | 정적 보장 변경 → opt-in·샌드박스 한정 | `expert-testing` (+ `moai-foundation-claude` 샌드박스) |

**의미적 껍데기(shell) 탐지**: `expert-debug`가 "증거가 주석/이름뿐이고 대응 로직이 없는" 경우를
플래그한다. 예: `canExport`라는 함수가 실제로는 상수만 반환. 현행 hardcode-debt / silent-fail 분류를
ast-grep 규칙으로 강화하여, 식별자 존재 **AND** 구조 로직 존재 **AND** swallowed 블록 밖에 있을 때만
`done`으로 판정한다.

### 3.3 작업 관리 보강 (이미 부분 해결됨)

기존 slug-archive 로직 위에 다중 동시 task 지원을 더한다.

- **다중 동시 task 인덱스**: `.spec-drift/index.md`에 모든 task slug + 상태를 기록 → 여러 체크리스트
  공존. → `builder-skill`
- **신규 커맨드**: `/spec-drift:list` (전 task 목록), `/spec-drift:switch <slug>` (활성 task 전환).
  → `builder-command` (로드맵 단계)
- **task 전환 자동 감지**: 신규 요청 slug가 발산하면 추출기가 task 전환을 감지·안내.

---

## 4. T2 — 플랫폼 최적화팀

**담당**: Claude Code 플랫폼 환경 연동 시 발생하는 한계
**리드**: `expert-performance` / **구성원**: `builder-skill`, `builder-plugin`, `manager-strategy`

### 4.1 Lossy compaction → 컨텍스트 유실 → 검증 품질 저하

| 해결책 | 내용 | 담당 |
| :-- | :-- | :-- |
| **디스크 영속 강제** | 플러그인의 본질적 방어는 체크리스트가 디스크에 영속되어 압축을 견디는 것 → 이를 강화·강제한다. | — |
| **증거 앵커링** | check/report가 찾은 증거를 `file:line` 앵커로 상태 섹션에 기록 → 압축 후에도 기억이 아닌 **파일 앵커**에서 재유도 → 오탐 감소. | `expert-performance` |
| **PreCompact 훅** | 압축 직전 현재 체크리스트 상태를 디스크에 flush. | `builder-plugin` (+ `moai-foundation-claude` hooks) |
| **기억 의존 금지 하드룰** | drift-detection은 **항상 파일을 새로 읽어** 동작하고 대화 기억에 의존하지 않음을 SKILL.md에 하드룰로 명시. | `drift-detection/SKILL.md` |

### 4.2 토큰 급증 / 서브에이전트 남용 / 사용량 조기 만료

| 해결책 | 내용 | 담당 |
| :-- | :-- | :-- |
| **서브에이전트 fan-out 금지** | drift-detection은 in-context에서 Grep/Read/ast-grep만 사용. 시스템 프롬프트를 중복 주입하는 서브에이전트를 호출하지 않음을 SKILL.md에 명시. | `expert-performance` |
| **Progressive disclosure** | drift 패턴표·ast-grep 규칙 등 무거운 참조는 Level 3 번들 파일로 분리, 필요 시 on-demand 로딩. | `builder-skill` |
| **타겟 읽기** | 식별자를 Grep으로 먼저 찾고, 매칭 구간(50~100줄)만 Read. 전체 파일 읽기 금지. | `file-reading-optimization` 규칙 적용 |
| **스캔 범위 상한** | 거대 프로젝트는 변경된 파일만 스캔(T3의 git diff와 연계) → 토큰 상한 확보. | T3 연계 |

---

## 5. T3 — 엔터프라이즈 통합팀

**담당**: 실무 엔터프라이즈 환경과의 괴리
**리드**: `manager-git` / **구성원**: `expert-backend`, `expert-devops`, `manager-strategy`

### 5.1 다중 브랜치 / 동시 협업 미통합

| 해결책 | 내용 | 담당 |
| :-- | :-- | :-- |
| **브랜치별 체크리스트 스코핑** | `.spec-drift/<branch>/`에 저장하거나 헤더에 `Branch:` / `BaseRef:`를 기록 → 단일 파일 sync가 깨지는 문제를 네임스페이싱으로 해결. | `manager-git` + `expert-backend` |
| **머지 인지 조정** | `/spec-drift:reconcile`로 브랜치 간 체크리스트 상태 비교 (스트레치 목표). | `manager-git` |
| **git 친화 포맷** | 결정적 정렬 + 1줄 1항목 → 동시 편집 시 머지 충돌 최소화. | `expert-backend` |

### 5.2 git 히스토리 / gitRef diff 부재

| 해결책 | 내용 | 담당 |
| :-- | :-- | :-- |
| **gitRef 스코프 drift 탐지** | `/spec-drift:report --base <ref>` → `git diff --name-only <base>...HEAD`가 가리키는 파일만 감사. `manager-git`이 diff 제공, drift-detection이 소비. **T2 토큰 문제도 동시 해결**(범위 한정). | `manager-git` |
| **히스토리 인지 상태** | 항목별 마지막 검증 커밋 SHA(`verified-at: <sha>`)를 기록 → 재report 시 해당 파일이 그 SHA 이후 변경된 항목만 재스캔(증분 검증). | `manager-git` + `expert-backend` |
| **CI 통합** | PR에서 Claude Code headless로 `/spec-drift:report` 실행 → drift 리포트를 PR 코멘트로 게시, MISSING / silent-fail 발생 시 머지 차단. 로컬 가이드라인을 엔터프라이즈 게이트로 승격. | `expert-devops` (+ `moai-foundation-claude` headless) |

---

## 6. 교차 시너지 (Cross-team)

- **T3 → T2**: gitRef 스코핑이 곧 스캔 범위 한정 → 토큰 바운딩에 직접 기여.
- **T1 → T2**: ast-grep 구조 검증은 전체 파일 읽기 대신 구조 질의 → 토큰·속도 동시 이득.
- **공통**: 세 팀 모두 정적 기본 + 런타임 opt-in 보안 자세를 보존한다.

---

## 7. 실행 로드맵 (단계·우선순위·마일스톤)

### Phase 0 — 공통 기반
`manager-strategy`가 세 팀이 공유하는 `.spec-drift/` 상태 스키마를 정의한다
(인덱스 / `file:line` 앵커 / `Branch:` / `verified-at:` 필드 통합).

### Phase 1 — P0 (저위험·병렬, 보안 불변)
| 팀 | 작업 |
| :-- | :-- |
| T1 | ast-grep 구조 검증(Tier 1), recall 카테고리 템플릿 |
| T2 | progressive disclosure + 타겟 읽기 + 서브에이전트 금지 룰 + PreCompact 훅 |
| T3 | `--base` gitRef 스코프 리포트, 브랜치 네임스페이싱 |

> **마일스톤 M1**: gitRef 스코프 + 타겟 읽기 → 토큰·실무 동시 개선(최대 효과 구간).

### Phase 2 — P1~P2 (opt-in·고위험)
| 팀 | 작업 |
| :-- | :-- |
| T1 | 런타임 검증 Tier(샌드박스, opt-in) |
| T3 | CI headless 게이트 + PR 코멘트 |
| T1 / T3 | 다중 체크리스트 인덱스 + `list` / `switch` / `reconcile` 커맨드 |

> **마일스톤 M2**: 의미적 "눈속임 코드" 탐지(ast-grep + 런타임) 완성.

### Phase 3 — 하드닝
문서화, test-fixtures 확장, `claude plugin validate . --strict` 통과.

### 우선순위 요약
| 우선순위 | 항목 | 효과 |
| :-- | :-- | :-- |
| **P0** | gitRef 스코핑 + 타겟 읽기 | 토큰 + 실무 동시 해결 |
| **P1** | ast-grep 의미 검증 + 다중 체크리스트 | 탐지 품질 + 작업 관리 |
| **P2** | 런타임 Tier + CI 게이트 | 눈속임 코드 + 엔터프라이즈 강제 |

---

## 8. 재사용 자산

| 자산 | 용도 | 사용 팀 |
| :-- | :-- | :-- |
| `test-fixtures/sample-project/` + `EXPECTED.md`, `complex-project/` + `EXPECTED_COMPLEX.md` | 특성(characterization) 테스트 기준선 | T1 |
| `moai-tool-ast-grep` 스킬 | 구조 매칭 | T1 |
| `moai-foundation-claude` 스킬 | PreCompact 훅, headless, 샌드박스 | T2, T3 |
| `file-reading-optimization` 규칙 | 타겟 읽기 | T2 |
| `requirement-extraction/SKILL.md`의 기존 slug-archive 로직 | 교체가 아닌 **확장** | T1 |
| 기존 `VERIFICATION_REPORT.md` / `TEST_RUNBOOK` | 테스트 절차 베이스 | 전 팀 |

---

## 9. 검증 방법

| 팀 | 검증 |
| :-- | :-- |
| **T1** | test-fixtures를 `EXPECTED`와 비교. 상수 반환 guard 같은 "눈속임 코드" fixture를 추가해 의미 탐지 검증. |
| **T2** | complex-project에서 개선 전후 토큰 측정. 서브에이전트 미spawn·타겟 읽기 동작 확인. |
| **T3** | 2-브랜치 테스트 repo에서 `--base` 실행 → diff 범위로 스캔이 한정되는지 확인. headless CI 드라이런. |
| **문서/배포** | 서브모듈 루트 기준 `claude plugin validate . --strict` 통과. |

---

## 10. 요약

| 문제 범주 | 전담 팀 | 핵심 해결책 |
| :-- | :-- | :-- |
| ① 정적·휴리스틱 한계 | T1 탐지 엔진 강화팀 | 2단 체크리스트(recall opt-in) + 계층형 검증(ast-grep → 런타임) + 다중 task 인덱스 |
| ② Claude Code 연동 한계 | T2 플랫폼 최적화팀 | 디스크 영속·증거 앵커링·PreCompact 훅 + 서브에이전트 금지·타겟 읽기·범위 상한 |
| ③ 실무 괴리 | T3 엔터프라이즈 통합팀 | 브랜치 스코핑 + gitRef diff·증분 검증 + CI headless 게이트 |

> 모든 개선은 플러그인의 **정적 기본 / 런타임 opt-in** 보안 자세를 보존하며,
> P0(gitRef 스코핑 + 타겟 읽기)이 토큰과 실무 문제를 동시에 푸는 최대 효과 구간이다.
