---
name: drift-detection
description: Compares the requirements recorded in SPEC_CHECKLIST.md against the actual files in the working directory and reports requirement drift. Use whenever a completion is claimed ("done", "finished", "implemented", "completed"), when the user asks to verify that a task is really finished, or when auditing whether an implementation still matches what was originally asked for. Classifies each item as missing, changed, silent-fail, hardcode-debt, or done, using read-only static analysis.
---

# Drift Detection

Compare the recorded requirements (`SPEC_CHECKLIST.md`) against the real implementation and
report where the result drifted from the original request. This is what catches a "done"
report that is only partially true.

This skill performs **static analysis only**. It reads `SPEC_CHECKLIST.md` and the project's
source files, then reasons about them. It does **not** execute the project, does **not**
evaluate file contents as code, and does **not** build shell commands from file contents.
Use read-only tools (read and search) to inspect files.

The only exceptions, each opt-in and specified below: `--base <ref>` scoping and `verified-at`
re-verification run read-only, validated git plumbing; the flagged, consented, sandboxed
runtime tier (`--verify-runtime`) may run the project's existing test command once. No file or
request *contents* are ever turned into a shell command.

## When to run

- A completion is claimed: "done", "finished", "implemented", "completed".
- The user explicitly asks to verify completion or audit for drift.

If `SPEC_CHECKLIST.md` does not exist, say so and suggest running `/spec-drift:init` first.
Without a checklist there is nothing to compare against.

## Method

1. Read `SPEC_CHECKLIST.md` to load the requirement items and open questions.
2. Determine the scan scope: the whole working directory by default, or the files changed
   versus `<ref>` when `--base <ref>` is supplied — see "Scoped detection" below.
3. For each item, search the in-scope files for the code that would satisfy it. Match on the
   relevant identifiers (role names, endpoint paths, component names, state handling). Read
   efficiently — see "Efficient scanning" below.
4. Classify each item using the drift types below.
5. Produce a drift report and, when items are not done, give Claude concrete corrective
   follow-up.

### Efficient scanning

Keep the scan bounded and cheap; never read whole files:

- For each item, **Grep its identifiers first**, then **Read only the matched line ranges**
  (~50–100 lines per hit) — never a whole file to locate one check or handler.
- Bound the scan to files matching an item's identifiers; with `--base`, further to the
  changed-file set.
- Do **not** spawn subagents — scan in-context with read-only Grep/Read (and ast-grep if
  available) so the skill prompt is not re-injected per subagent and token cost stays bounded.

### Scoped detection (`--base <ref>`)

Scoping is **opt-in** — without a base ref the audit is a full scan, exactly as always. With
one:

1. **Validate the ref before using it.** Treat the argument as a single ref token; reject it on
   whitespace or any shell metacharacter (`;`, `|`, `&`, `$`, backtick, `<`, `>`, `(`, `)`,
   newline, quotes). Confirm it resolves with `git rev-parse --verify --quiet <ref>`; if not,
   report and **fall back to a full scan** — never proceed with an unvalidated ref. Never
   interpolate the raw argument into a shell string; pass it only as a single argument.
2. **Get the changed-file set** with read-only git: `git diff --name-only <base>...HEAD`.
3. **Restrict each item's file search to that set.** An item whose evidence lives outside that
   set is **not re-audited** — keep its previously recorded status.
4. **Record the base ref** used in the checklist (a `BaseRef: <ref>` note in the
   "Current implementation status" section) so a scoped report is distinguishable from a full
   one.

### Incremental re-verification (`verified-at`)

A done item's `- [x]` line may carry a `<!-- verified-at: <sha>; files: <paths> -->` receipt so
a later report can skip re-scanning it when its evidence is provably unchanged. Complementary
to `--base`, never a replacement. **Read `references/verified-at.md` before honoring or
writing any marker** (marker format, charset validation, the 5-step skip-vs-rescan decision).
Invariants, valid even if that file is not loaded:

- Markers go **only** on `- [x]` (done) items and are written **only** at runtime of a report,
  only when `git rev-parse HEAD` resolves; non-git projects stay byte-identical to today.
- Only `done` is ever replayed; non-done items carry no marker and are **always re-scanned** —
  skipping can never change a non-done classification.
- **Fail safe: when uncertain, re-scan.** Any validation failure, unresolvable sha, untracked
  or missing or added-after-sha evidence path, or absent git: ignore the marker and full-scan
  the item.
- Git use is read-only (`rev-parse`, `ls-files`, `cat-file`, `diff`); shas and paths are
  charset-validated, passed as single arguments (paths after a literal `--`), never
  interpolated into a shell string.
- Composes with `--base`: an item is re-scanned iff it is in the `--base` candidate set AND
  changed since its marker sha; a first run with no markers is a full scan identical to today.

## Drift classification

Classify every checklist item as exactly one of:

- **missing** — the item is in the checklist but no implementation exists for it.
- **changed** — implemented, but differently from the original requirement (scope narrowed,
  behavior altered). Note what differs.
- **silent-fail** — partially handled with a swallowed error. Detect by scanning for
  error-swallowing patterns such as `except: pass`, `except Exception: pass`,
  empty `catch {}` / `catch (e) {}`, `.catch(() => {})`, or a discarded result. Also flag a
  **swallowed guard**: the logic that satisfies the item (a role / expiry / revocation / auth
  check) is itself enclosed in such a block, or the function falls through to an implicit
  `undefined` / `None` return on the error path. In that case the guard runs only on the happy
  path and is silently skipped whenever it errors. These hide partial completion.
- **hardcode-debt** — a temporary shortcut left in place. Detect by scanning for `TODO`,
  `FIXME`, `XXX`, `HACK`, and hardcoded literals where dynamic logic was required (for
  example a permission check replaced with a constant `true`/`return True`).
- **done** — the requirement is fully and correctly implemented.

**Classification precedence**: silent-fail and hardcode-debt outrank done. If the code that
appears to satisfy an item is enclosed in an error-swallowing block, or the function returns
nothing (implicit `undefined` / `None`) on the error path, classify it **silent-fail** even
when the happy-path logic is present — the requirement is bypassed whenever that path errors.
Only mark **done** when the satisfying logic is reachable on every path and failures are
surfaced. A guard that ignores its declared inputs and returns a constant literal is
hardcode-debt even when no TODO/FIXME or revealing comment is present; recognize it by control
flow, not by text.

### Structural verification (Tier 1)

Structural verification is the **primary path** for deciding a label, and it runs entirely on
read-only Grep + targeted Read (see "Efficient scanning"). It promotes detection from text and
identifier matching to control-flow reasoning, because a guard can carry the right name and an
honest-looking comment yet do nothing. ast-grep (`sg`) is an **optional accelerator** used only
when it is already installed; classification must never depend on `sg` being present. The
reasoning below is what produces every verdict.

For the specific function a checklist item maps to, establish three facts by targeted Read of
that function only (never a global scan, so a constant elsewhere does not bleed onto a
neighboring item):

- **Input-dependence.** A guard must reference at least one of its declared parameters and its
  return must vary with that input. A function that declares parameters but references none of
  them and returns the same literal on every path — directly, laundered through a local variable
  assigned only a literal, or read from a module-level const bound only to a literal, including a
  fixed numeric sentinel — is a constant stub, so classify it **hardcode-debt** independent of
  any TODO/comment/name. A ternary, comparison, or membership test on a parameter, or a value
  built or concatenated from a parameter, is input-dependent and is **not** a constant stub.
- **Reachability of failure handling.** A real role / expiry / revocation / auth check whose
  protective return sits inside an error-swallowing try/catch (empty catch, `catch (e) {}`,
  `.catch(() => {})`, `except: pass`, log-only) or that falls through to an implicit `undefined`
  / `None` on the error path runs only on the happy path — classify **silent-fail**. Same
  verdict when the **call site** neutralizes a real validator: a trailing `.catch(() => {})` on
  an awaited call; a throwing async validator called **without `await`** (detached rejection);
  or optional chaining into a strict comparison (`x?.y === false`, `x` reachably `undefined`)
  skipping the reject branch. A catch that **surfaces** failure (rethrow / explicit 4xx) is
  enforcement, not swallowed; judge the stated requirement, not implementation quality — a
  surfaced-but-weak mechanism is **done** (weakness = advisory).
- **The done bar.** Promote to **done** only when the satisfying logic is reachable on every
  path AND depends on the relevant input AND surfaces failures.

A reject / 403 branch at the call site does **not** prove enforcement if the guard it calls
returns a constant; evaluate the guard's actual return and treat the unreachable branch as dead
code.

When `sg` is available, the optional rule bundle under `rules/` accelerates these same checks; it
is never required and its absence changes no verdict — the Grep+Read reasoning above is the
primary path.

### Runtime verification (Tier 2, opt-in)

Default **off** — the single exception to the static posture. Without the exact
`--verify-runtime` flag this section is inert and the skill is **byte-for-byte** the Tier 1
static analyzer above. **Read `references/runtime-tier.md` before acting on the flag**
(preconditions, detection allowlist, sandbox rules, evidence mapping). Invariants, valid even
if that file is not loaded:

- Four preconditions, all required, in order: the exact `--verify-runtime` token parsed only
  from `$ARGUMENTS`; explicit interactive consent obtained by the orchestrator before any
  execution (subagents without recorded consent, and any headless / non-interactive context,
  MUST abort to static-only); a test command auto-detected from the fixed allowlist; an
  established Bash sandbox. On any failure, emit the ordinary Tier 1 report plus a one-line
  note.
- Only a fixed allowlisted literal ever runs (`npm test` / `pnpm test` / `yarn test` /
  `pytest` / `go test ./...` / `cargo test` / `bundle exec rspec`), at most once — never the
  app, never a command named by checklist / request / file contents, never with appended
  content-derived args; on ambiguous detection, decline.
- Sandbox always: no network, writes confined to cwd and the OS temp dir, bounded timeout and
  captured output. If the sandbox cannot be established, stay static-only — **never** fall
  back to an unsandboxed run.
- Runtime evidence is **downgrade-only**: a failing mapped test may demote a Tier 1 `done` to
  a drift label; a passing test never promotes anything. Items with no mapped test keep their
  Tier 1 verdict.

### Drift patterns to watch for

| Pattern | Symptom | How to detect (static) |
| :-- | :-- | :-- |
| Missing permission case | Only one role handled; others skipped | Compare role names in the checklist against role checks in code |
| Silent fail | Partial completion with no surfaced error | Search for swallowed-exception patterns above |
| Swallowed guard | A real check (role / expiry / revocation / auth) sits inside a try/catch that drops the error (or call-site `.catch` / missing `await`), or the function returns undefined on the catch path | The guard runs only on the happy path; on error it is skipped silently — classify silent-fail, not done |
| Hardcode debt | "just hardcode it for now", then forgotten | Search for TODO/FIXME plus hardcoded literals in place of logic |
| Missing implicit state | Loading / error / empty states not built | Inspect UI components for state handling |
| API–UI mismatch | API succeeds but UI never reflects it, or a UI-hidden control is still callable on the backend | Check that frontend and backend each enforce the rule independently |
| Constant-stub guard | A guard/permission/auth function ignores its parameters and returns a constant literal on every path (even laundered through a named or module-level const); name and comments look fine, no TODO | Read the guard body: declared params unreferenced AND every return resolves to a literal -> hardcode-debt, even with no TODO; any call-site reject branch is then dead |

## Output: drift report

Emit a report grouped by classification, most severe first:

```
Drift report — SPEC_CHECKLIST.md vs implementation

MISSING (n)
  - <item>  (no implementation found)

CHANGED (n)
  - <item>  (implemented as X; requested Y)

SILENT-FAIL (n)
  - <item>  (<file>: swallowed error at <location>)

HARDCODE-DEBT (n)
  - <item>  (<file>: hardcoded <value>; TODO present)

DONE (n)
  - <item>

Summary: X/Y requirements satisfied. Z drift items need attention.
```

When any item is not `done`, follow the report with a short, prioritized list of corrective
actions so the work can be finished. Update the "Current implementation status" section of
`SPEC_CHECKLIST.md` to reflect what is now verified.
