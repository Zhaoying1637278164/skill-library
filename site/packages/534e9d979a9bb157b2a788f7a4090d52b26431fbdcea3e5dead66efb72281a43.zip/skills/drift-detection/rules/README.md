# Drift-detection ast-grep rule bundle (OPTIONAL)

This bundle is an OPTIONAL Level-3 accelerator. The ast-grep (`sg`) CLI is NOT
assumed to be installed and is absent in the reference environment for this
plugin. The primary, required path is the prose in
`skills/drift-detection/SKILL.md` under "Structural verification (Tier 1)",
which runs entirely on read-only Grep + targeted Read. No classification may
depend on `sg` being present; the absence of this bundle changes no verdict.

These rules exist only to make the same structural checks faster when `sg`
happens to be installed. They never run automatically and are never imported by
the skill.

## How to run (only when sg is installed)

```
sg scan --config skills/drift-detection/rules/sgconfig.yml <path>
```

## Rule to drift-class map

The rule `.yml` files live in `defs/` (kept separate from `sgconfig.yml` so the
config file is not itself scanned as a rule); `sgconfig.yml` points at them via
`ruleDirs: defs`.

| Rule file | Rule ids | Drift class |
| :-- | :-- | :-- |
| `defs/constant-stub-guard.yml` | `constant-stub-guard-js`, `constant-stub-guard-ts`, `constant-stub-guard-py` | hardcode-debt |
| `defs/swallowed-guard.yml` | `swallowed-guard-js`, `swallowed-guard-ts`, `swallowed-exception-py` | silent-fail |
| `defs/implicit-fallthrough.yml` | `implicit-fallthrough-js`, `implicit-fallthrough-ts`, `implicit-fallthrough-py` | silent-fail |

## Important caveat: candidates only

These rules surface CANDIDATES, not final verdicts. ast-grep cannot:

- assert that a function's declared parameters are unused on the return path;
- trace a module-level const back to a literal;
- prove full reachability of an error/edge path.

The LLM confirmation steps documented in SKILL.md (the Grep + targeted Read
reasoning) finalize each label. When `sg` is not available, those same steps
are the only thing that executes, and they produce every verdict on their own.

See `reference.md` for a per-rule explanation, the language(s) each rule
targets, the drift class it maps to, and how to fall back without `sg`.
