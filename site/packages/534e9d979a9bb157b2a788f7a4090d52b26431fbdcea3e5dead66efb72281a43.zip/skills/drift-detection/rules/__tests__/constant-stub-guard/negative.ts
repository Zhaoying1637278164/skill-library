// Genuine membership test on the parameter; return value is not a literal.
function resolveAccess(request: AccessRequest, roles: string[]) {
  return roles.includes(request.user.role);
}
export { resolveAccess };
