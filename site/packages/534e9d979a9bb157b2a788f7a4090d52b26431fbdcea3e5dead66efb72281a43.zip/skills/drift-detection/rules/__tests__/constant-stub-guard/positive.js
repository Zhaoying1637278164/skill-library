// Guard launders a literal through a local and ignores both params.
function resolveAccess(request, roles) {
  const granted = true;
  return granted;
}
module.exports = { resolveAccess };
