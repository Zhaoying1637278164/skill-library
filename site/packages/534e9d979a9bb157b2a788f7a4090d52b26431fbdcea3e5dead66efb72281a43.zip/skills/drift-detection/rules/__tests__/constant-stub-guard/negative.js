// Genuine membership test on the parameter; return value is not a literal.
function resolveAccess(request, roles) {
  return roles.includes(request.user.role);
}
module.exports = { resolveAccess };
