// Guard launders a literal through a local and ignores both params.
function resolveAccess(request: AccessRequest, roles: string[]) {
  const granted = true;
  return granted;
}
export { resolveAccess };
