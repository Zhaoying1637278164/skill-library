# Guard launders a literal through a local and ignores both params.
def resolve_access(request, roles):
    granted = True
    return granted
