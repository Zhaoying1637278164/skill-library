# Genuine membership test on the parameter; return value is not a literal.
def resolve_access(request, roles):
    return request.user.role in roles
