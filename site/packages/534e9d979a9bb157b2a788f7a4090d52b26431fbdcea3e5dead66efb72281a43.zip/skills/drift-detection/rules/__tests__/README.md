# ast-grep golden corpus (CI-ONLY)

This directory pins each of the three shipped ast-grep rule files in
`skills/drift-detection/rules/` to a known-good matching behavior. For every rule there is one
**positive** fixture that MUST produce at least one match and one **negative** fixture that MUST
produce zero matches. Together they lock the rules against silent over-matching (false positives
creeping onto input-dependent guards, denying catches, or fully-returning functions) and silent
under-matching (a rule edit that stops firing on the real defect) whenever the `.yml` files change.

## Why this is CI-ONLY (do not run locally here)

`sg` (ast-grep) is **BLOCKED by OS app-control policy** in the original development environment, so
the binary cannot execute there. These files are authored to run **only where `sg` is permitted**
(e.g. a CI runner). Do not expect `run-golden.sh` to execute in the dev sandbox.

The core drift-detection skill is **sg-independent**: per `rules/README.md`, the absence of `sg`
changes no verdict. This corpus tests only the optional rule accelerators, never the Tier-1
reasoning path exercised by `test-fixtures/`.

## What each fixture asserts

| Rule prefix | positive.js (MUST match >=1) | negative.js (MUST match 0) |
|---|---|---|
| `constant-stub-guard` | guard launders a literal through a local and returns it, ignoring params | return is `roles.includes(...)`, input-dependent |
| `swallowed-guard` | empty `catch (e) {}` plus a no-op `.catch(() => {})` | `catch` denies (`return false`); no no-op `.catch` |
| `implicit-fallthrough` | function body contains **zero** return statements | function returns on every path |

### Note on `implicit-fallthrough` coarseness

The shipped rule fires on the **absence of any return** in the function body (it is a candidate
surfacer, per `rules/README.md`). The positive fixture therefore contains **zero** return
statements and the negative contains at least one. Do not author a
"has-a-return-path-but-also-a-no-return-path" positive — the coarse rule would not catch it, and the
golden test must mirror the rule exactly as written.

## Requirements to run

- `sg` (ast-grep CLI) on `PATH`
- `jq` on `PATH`

## Running

```sh
chmod +x skills/drift-detection/rules/__tests__/run-golden.sh
skills/drift-detection/rules/__tests__/run-golden.sh
```

The runner loads the existing self-contained `rules/sgconfig.yml` (`ruleDirs: defs`, so all three
`defs/*.yml` rule files are active while the config itself is not scanned as a rule) and filters
JSON-stream output by `ruleId` prefix, so each fixture is
judged only against its target rule. Prefix matching tolerates the `-js` / `-ts` / `-py` rule-id
suffix. Any mismatch prints a `FAIL` line and the script exits non-zero (`GOLDEN CORPUS FAILED`);
on success it prints `GOLDEN CORPUS PASSED` and exits 0.

## CI integration

Wire this as a **separate, optional** job (e.g. job id `astgrep-golden`) that is gated on `sg`
availability and never blocks environments without it. See `docs/ci-integration.md` and the
`astgrep-golden` job in `.github/workflows/spec-drift.yml.example`.
