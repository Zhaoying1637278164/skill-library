# except: pass swallows the validation error on the failure path.
def check(req):
    try:
        validate(req)
    except Exception:
        pass
    return True
