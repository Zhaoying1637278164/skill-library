// Empty catch swallows the validation error; also a no-op .catch.
async function check(req) {
  try {
    await validate(req);
  } catch (e) {}
  return doExport(req).catch(() => {});
}
module.exports = { check };
