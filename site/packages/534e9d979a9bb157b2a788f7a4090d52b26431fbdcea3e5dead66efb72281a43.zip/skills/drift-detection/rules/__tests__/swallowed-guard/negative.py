# except returns a safe deny default instead of swallowing the error.
def check(req):
    try:
        validate(req)
    except Exception:
        return False  # deny on error
    return True
