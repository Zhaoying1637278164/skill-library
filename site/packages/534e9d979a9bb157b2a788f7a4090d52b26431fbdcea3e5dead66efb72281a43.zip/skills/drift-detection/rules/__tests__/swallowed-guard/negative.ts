// Catch propagates a deny decision instead of swallowing the error.
async function check(req: Request) {
  try {
    await validate(req);
  } catch (e) {
    return false; // deny on error
  }
  return true;
}
export { check };
