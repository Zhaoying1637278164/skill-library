// Empty catch swallows the validation error; also a no-op .catch.
async function check(req: Request) {
  try {
    await validate(req);
  } catch (e) {}
  await doExport(req).catch(() => {});
}
export { check };
