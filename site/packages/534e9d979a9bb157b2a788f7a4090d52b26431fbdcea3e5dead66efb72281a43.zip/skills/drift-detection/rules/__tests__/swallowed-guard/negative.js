async function check(req) {
  try {
    await validate(req);
  } catch (e) {
    return false; // deny on error
  }
  return true;
}
module.exports = { check };
