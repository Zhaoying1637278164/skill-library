#!/usr/bin/env sh
set -eu
HERE="$(cd "$(dirname "$0")" && pwd)"
RULES_DIR="$(cd "$HERE/.." && pwd)"
CFG="$RULES_DIR/sgconfig.yml"
# Call the ast-grep binary directly. The `sg` alias collides with the
# shadow-utils `sg` (set-group) command on Linux runners, so prefer `ast-grep`.
SG="${SG:-ast-grep}"
fail=0
# args: <rule-id-prefix> <fixture-dir> <extension>
# Scans <dir>/positive.<ext> (want >=1 match) and <dir>/negative.<ext> (want 0).
# The rule-id prefix is decoupled from the directory so a single fixture dir can
# be exercised for js/ts/py, and so the Python swallowed rule (swallowed-exception-py)
# can be matched with the `swallowed-exception` prefix while js/ts use `swallowed-guard`.
# sgconfig.yml maps *.js/*.ts/*.py to their languages, so each extension only ever
# triggers the same-language rule variant.
check() {
  rid="$1"; dir="$2"; ext="$3"
  pos="$HERE/$dir/positive.$ext"; neg="$HERE/$dir/negative.$ext"
  pc=$("$SG" scan -c "$CFG" --json=stream "$pos" 2>/dev/null | jq -c "select(.ruleId|startswith(\"$rid\"))" | wc -l | tr -d ' ')
  nc=$("$SG" scan -c "$CFG" --json=stream "$neg" 2>/dev/null | jq -c "select(.ruleId|startswith(\"$rid\"))" | wc -l | tr -d ' ')
  if [ "$pc" -lt 1 ]; then echo "FAIL $rid [$ext]: positive matched $pc (want >=1) $pos"; fail=1; else echo "ok   $rid [$ext] positive ($pc)"; fi
  if [ "$nc" -ne 0 ]; then echo "FAIL $rid [$ext]: negative matched $nc (want 0) $neg"; fail=1; else echo "ok   $rid [$ext] negative ($nc)"; fi
}
check constant-stub-guard  constant-stub-guard  js
check constant-stub-guard  constant-stub-guard  ts
check constant-stub-guard  constant-stub-guard  py
check swallowed-guard      swallowed-guard      js
check swallowed-guard      swallowed-guard      ts
check swallowed-exception  swallowed-guard      py
check implicit-fallthrough implicit-fallthrough js
check implicit-fallthrough implicit-fallthrough ts
check implicit-fallthrough implicit-fallthrough py
if [ "$fail" -ne 0 ]; then echo "GOLDEN CORPUS FAILED"; exit 1; fi
echo "GOLDEN CORPUS PASSED"
