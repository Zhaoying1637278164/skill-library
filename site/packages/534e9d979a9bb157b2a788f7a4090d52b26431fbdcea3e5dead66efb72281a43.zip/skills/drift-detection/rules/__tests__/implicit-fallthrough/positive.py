# Boolean guard that logs but never returns a decision -> implicit None.
def assert_can_export(user, roles):
    if user.role not in roles:
        print("not allowed")
