// Every path returns an explicit decision.
function assertCanExport(user: User, roles: string[]) {
  if (!roles.includes(user.role)) {
    return false;
  }
  return true;
}
export { assertCanExport };
