// Boolean guard that logs but never returns a decision -> implicit undefined.
function assertCanExport(user, roles) {
  if (!roles.includes(user.role)) {
    console.error("not allowed");
  }
}
module.exports = { assertCanExport };
