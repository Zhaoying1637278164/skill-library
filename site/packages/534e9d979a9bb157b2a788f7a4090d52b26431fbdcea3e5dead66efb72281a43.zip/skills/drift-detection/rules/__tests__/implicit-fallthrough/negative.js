function assertCanExport(user, roles) {
  if (!roles.includes(user.role)) {
    return false;
  }
  return true;
}
module.exports = { assertCanExport };
