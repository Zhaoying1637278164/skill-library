// Boolean guard that logs but never returns a decision -> implicit undefined.
function assertCanExport(user: User, roles: string[]) {
  if (!roles.includes(user.role)) {
    console.error("not allowed");
  }
}
export { assertCanExport };
