# Every path returns an explicit decision.
def assert_can_export(user, roles):
    if user.role not in roles:
        return False
    return True
