# Rule reference

Per-rule explanation for the OPTIONAL drift-detection ast-grep bundle. Read
this alongside `README.md`. Every rule is an accelerator only: the SKILL.md
"Structural verification (Tier 1)" Grep + targeted Read reasoning is the
primary, required path and produces every verdict on its own when `sg` is
absent.

Apply every check FUNCTION-SCOPED to the specific function a checklist item
maps to. Never run a global scan whose result bleeds onto a neighboring item.

---

## constant-stub-guard

- Files / ids: `defs/constant-stub-guard.yml` -> `constant-stub-guard-js`,
  `constant-stub-guard-ts`, `constant-stub-guard-py`
- Languages: JavaScript, TypeScript, Python
- Drift class: hardcode-debt

What it detects: a function the checklist maps to a guard / permission / auth /
decision role whose verdict is independent of its input. Both conditions must
hold: (a) the function declares parameters but its body references none of them
on the path that produces the return, and (b) every return resolves to a
constant literal -- directly (`return true`), laundered through a local bound
only to a literal (`const granted = true; return granted;`), or read from a
module-level const bound only to a literal. The numeric-sentinel variant counts
(`expiresInDays = 9999` where dynamic policy was required). Because the decision
never depends on the request/role/token/expiry it should evaluate, any reject
branch wired at the call site (`if (!resolveAccess(req)) return 403`) is dead
code and the gate admits everyone.

Must NOT fire when the return branches on input: a ternary, comparison, or
membership test on a parameter (`user.role === 'admin' ? true : false`,
`EXPORT_ROLES.includes(user.role)`), or a value built from input
(`'tok_' + docId`), is input-dependent.

ast-grep limit: cannot assert "declared parameters unused" or trace a
module-level const. The pattern matches the literal-return shape only.

Fallback without sg (SKILL.md grepFallback): (1) from the checklist item, Grep
the enforcement/predicate identifiers and Read ~30 lines around the call site to
find which function decides allow/deny; (2) Grep the guard definition and Read
only its body; (3) collect the declared parameter names and confirm whether any
appears on the return path -- if none, the guard ignores its input; (4) trace
every return to its source and mark constant only if it is a literal or a
literal-bound local/module const with no branch on input; (5) if both hold,
classify hardcode-debt and treat any call-site reject branch as dead.

---

## swallowed-guard

- Files / ids: `defs/swallowed-guard.yml` -> `swallowed-guard-js`,
  `swallowed-guard-ts`, `swallowed-exception-py`
- Languages: JavaScript, TypeScript, Python
- Drift class: silent-fail

What it detects: a real, input-dependent check (role / expiry / revocation /
auth) whose protective return sits inside a try whose catch swallows the error
(empty catch, `catch (e) {}`, `catch {}`, `.catch(() => {})`,
`.catch(() => null)`, `except: pass`, `except Exception: pass`, or log-only)
without re-raising or returning a safe deny default. On the error path the guard
is skipped silently. Because the happy-path logic is genuine and references the
input, text matching is tempted toward done; control flow shows the check is
bypassed on error.

ast-grep limit: matches the swallowing try/catch shape; it does not confirm
that the input-dependent decision lives inside the try. An optional `has`
constraint can require a role/expiry/revoked/auth check inside the body.

Fallback without sg (SKILL.md grepFallback): (1) Grep the guard region for
`try` / `catch` / `except` / `.catch(`; (2) Read the try and catch bodies
together; (3) confirm the input-dependent decision lives INSIDE the try and
references the relevant input; (4) inspect the catch/except body -- if it is
empty, only `pass`, or only logs, and neither returns a safe/deny default nor
re-raises, the function leaves the protected region without enforcing on error;
(5) classify silent-fail. constant-stub-guard must NOT fire here because the
return depends on input.

---

## implicit-fallthrough

- Files / ids: `defs/implicit-fallthrough.yml` -> `implicit-fallthrough-js`,
  `implicit-fallthrough-ts`, `implicit-fallthrough-py`
- Languages: JavaScript, TypeScript, Python
- Drift class: silent-fail

What it detects: a boolean guard (or a function whose callers treat its result
as allow/deny) with a reachable path that returns nothing -- implicit
`undefined` (JS/TS) or `None` (Python) -- typically when an `if` guards one
branch with no following return, or the catch path falls off the end.
Downstream `if (!guard())` then treats the missing return inconsistently, so the
protective decision is not reliably enforced on every path. Kept distinct from
swallowed-guard because one function can exhibit both a swallowing catch and an
implicit fall-through; flagging either independently is more robust and additive.

ast-grep limit: the rule fires on the absence of any `return` in the body
(`not has return`, `stopBy: end`); it cannot prove which specific path lacks a
return. The LLM decides whether the missing-return path is a real bypass.

Fallback without sg (SKILL.md grepFallback): (1) Read the full guard body
(small by design); (2) enumerate exit paths -- does every path end in an
explicit return of a decision; (3) if some path (after a try/catch, an unmatched
else, or end of function) falls off with no return, the function yields implicit
undefined/None there; (4) when the missing-return path is the error/edge path of
a check that should deny, classify silent-fail.

---

## The done gate (no positive rule)

There is no ast-grep rule for done. An item is done only when, for the mapped
function: constant-stub-guard does NOT fire (the body references its declared
input and the return varies with it), AND swallowed-guard does NOT fire (no
error-swallowing block bypasses the decision), AND implicit-fallthrough does NOT
fire (every path returns a decision). `sg` is only ever used to prove these
negatives; it is never required. Implement done as this conjunction in prose.
Never let a constant-true predicate elsewhere satisfy a separate
missing/changed item.
