# Incremental re-verification (verified-at) — full algorithm

Level-3 reference for the drift-detection skill. Read this before honoring or writing any
`verified-at` marker. The invariants in SKILL.md ("Incremental re-verification") govern; this
file is the procedure that implements them. This refinement is **complementary to** `--base`,
never a replacement for it. It only changes whether an already-`done` item is re-scanned; it
never changes any classification rule.

## The core invariant (read this first)

A `verified-at` marker is only ever attached to a
`- [x]` (done) item, and is only ever written at runtime. The single verdict it can cache and
replay is `done`. A `missing` / `changed` / `silent-fail` / `hardcode-debt` item carries no
marker and is **always re-scanned**, so incremental skipping can never alter a non-done
classification. The marker is a receipt: "this item was classified done at commit `<sha>` on the
basis of these files." If those files are byte-identical now, the done verdict still holds;
anything else is fully re-scanned and re-classified normally.

## The in-file marker

In the `## Current implementation status` section only, a verified item
carries a trailing HTML comment on the same `- [x]` line:
`<!-- verified-at: <sha>; files: <comma-and-space-separated paths> -->`. The pre-existing
`BaseRef: <ref>` note stays on its own plain line and is never merged with a marker. Before
treating a line's remainder as item text (for matching or for counting), strip a **single**
trailing `verified-at` comment anchored at end of line (and the spaces before it); strip only
that exact pattern, never arbitrary `<!-- ... -->`, so item text is never mangled. `- [ ]` and
non-done items carry no marker.

## Validation (the marker is file-sourced, so validate defensively)

Mirror the `--base` discipline with field-appropriate charsets:

- `<sha>`: accept only `^[0-9a-f]{7,40}$` (lowercase hex). Anything else: treat the marker as
  absent and full-scan the item.
- each `<path>`: reject if it contains whitespace or any of `; | & $` backtick `< > ( ) ' "` or a
  newline; also reject if it begins with `-`, begins with `/` or `~` or a drive letter, contains
  a backslash, or contains a `..` path segment. Allowed characters are alphanumerics plus
  `/ . - _`. A path failing validation: treat the marker as absent and full-scan the item.
- Never interpolate a sha or path into a larger shell string; pass each only as a single
  argument, and pass paths only after a literal `--`.

## Skip-vs-rescan, per item (read-only validated git)

1. Validate `<sha>` and every `<path>` as above. On any failure, or if git is unavailable or the
   cwd is not a repository, **ignore the marker and full-scan the item** (fail safe: never skip on
   uncertainty).
2. Resolve the sha with `git rev-parse --verify --quiet <sha>^{commit}` (single argument). If it
   does not resolve, ignore the marker and full-scan the item.
3. **Prove every evidence path is tracked AND existed at `<sha>` before any diff is trusted.** A
   `git diff --name-only` is **blind to untracked files**: an untracked evidence file produces empty
   output that is indistinguishable from an unchanged tracked file, so trusting an empty diff alone
   would replay a stale `done` for an item whose evidence was never committed (or was added after
   `<sha>`, or has since been deleted). To close this hole, for **each** listed `<path>` run two
   read-only checks, each with the path passed only as a single argument after a literal `--`:
   - **Tracked now:** `git ls-files --error-unmatch -- <path>` must succeed. A non-zero exit means
     the path is untracked (or absent), so the diff would be blind to it.
   - **Existed at the marker sha:** `git cat-file -e <sha>:<path>` must succeed. A non-zero exit
     means the path did not exist in that commit (newly added after `<sha>`, or unresolvable).

   If **either** check fails for **any** listed path (untracked, added after `<sha>`, deleted, or
   unresolvable), **ignore the `verified-at` marker and fully re-scan and re-classify the item**
   (fail safe: never skip on uncertainty). Only when **every** path passes **both** checks may the
   diff in step 4 be trusted.
4. With all paths proven tracked-and-present, decide with one read-only command:
   `git diff --name-only <sha> -- <path> [<path> ...]` (paths after `--`). Comparing the commit to
   the working tree (no second commit) catches committed and uncommitted changes to those **tracked**
   paths since `<sha>`; the step-3 gate is what guarantees the diff is not blind, since an untracked
   or newly-added path can never reach this command.
   - **Empty output** (evidence unchanged): SKIP the re-scan and report the item `done`, keeping
     its `- [x]` line and marker verbatim. This is the token saving; replaying the done receipt is
     safe because every evidence path is tracked, existed at `<sha>`, and is byte-identical to when
     the done verdict was produced.
   - **Non-empty output** (evidence changed): RE-SCAN and re-classify the item normally — it may
     stay done or drop to any drift label.
5. After a re-scan that yields a `done` verdict, record a fresh marker: sha from
   `git rev-parse HEAD` (single argument), files = **every** file the verdict actually depended on
   (the guard / implementation file and any call site or collaborator the reasoning consulted, so
   an out-of-band breaking change in a consulted file is caught next run). An item re-scanned to
   any non-done label drops its marker.

## Marker-writing gate (backward compatibility)

Only write `verified-at` markers when
`git rev-parse HEAD` resolves (the cwd is a repository). In a non-git project, write the status
section exactly as today (`- [x]` with no comment), so non-git projects stay byte-identical to
current behavior. Marker text lives only inside the `## Current implementation status` section
that is already rewritten today; it never alters the drift report text.

## Classification is unchanged

A replayed `done` was produced by a real classification at
`<sha>` over files that are byte-identical now, and a first run with no markers is a full scan
producing labels identical to today (the fixture guarantee). This refinement decides only whether
a done item is re-scanned, never the rules that produce a label.

## Composition with `--base` (they intersect; neither overrides)

`--base` is authoritative for
scope: an item whose evidence is entirely outside the `git diff --name-only <base>...HEAD`
candidate set keeps its previously recorded status (existing behavior, unchanged). For items
inside that candidate set, `verified-at` may further skip those unchanged since their sha. Net: an
item is re-scanned iff it is in the `--base` set AND changed since its `verified-at` sha; each
mechanism is independently sufficient to skip, and they never contradict. A first run with no
markers and no `--base` is a full scan with labels identical to today.

## Read-only posture recap

This refinement preserves the read-only static posture: no file or request *contents* are ever
turned into a shell command, and the only git plumbing used is `git rev-parse`, `git ls-files`,
`git cat-file`, and `git diff`, each read-only and with validated single-argument inputs (shas
matched as `^[0-9a-f]{7,40}$`, paths charset-whitelisted and passed only after a literal `--`).
