---
name: requirement-extraction
description: Extracts an explicit requirement checklist from a user's task request and writes it to SPEC_CHECKLIST.md so it can be verified later. Use at the START of a new coding task, whenever a user describes a feature to build, or when the user asks to capture, track, or pin down requirements before implementation begins. Pulls out stated functional requirements plus commonly-forgotten implicit ones (all permission roles, all UI states, all API success/failure paths) and surfaces up to three clarifying questions for genuinely ambiguous scope.
---

# Requirement Extraction

Turn a vague task request into an explicit, checkable list of requirements stored in
`SPEC_CHECKLIST.md`. This file becomes the single source of truth for the session and is
later compared against the real implementation by the `drift-detection` skill.

This skill performs **static analysis and text extraction only**. It reads the user's
request and writes one Markdown file. It never executes code, never evaluates user content,
and never runs shell commands built from request text.

## When to run

Run this when a new task begins:

- The user describes a feature, behavior, or fix to build.
- The user explicitly asks to start a checklist or capture requirements.
- A long task is starting and drift risk is high.

Each checklist carries a `Task:` identity in its header — a short kebab-case slug derived
from the request (for example, `export-button-rbac`). This slug, not an informal sense of
"the same task", is what decides overwrite behavior. Before writing, check for an existing
`SPEC_CHECKLIST.md`:

- **Same task** (its `Task:` slug matches the active `SPEC_CHECKLIST.md`) — update that file
  in place. Never recreate it from scratch, so the recorded status is preserved.
- **Reactivating an archived task** (the slug matches an existing `SPEC_CHECKLIST.<slug>.md`
  archive rather than the active file) — do not recreate an empty checklist. Reactivate that
  archive using switch semantics (archive the current active task under its own slug, restore
  the matching `SPEC_CHECKLIST.<slug>.md` to `SPEC_CHECKLIST.md`, rebuild the index), then
  update the now-active checklist in place so its prior tracking survives. See
  "Task-switch detection" below.
- **New task** (the slug matches neither the active file nor any archive) — archive the
  existing active file by renaming it to `SPEC_CHECKLIST.<existing-slug>.md` (refusing to
  overwrite if that archive name already exists), then write a fresh `SPEC_CHECKLIST.md` for
  the new task. Never silently overwrite; the previous task's tracking must survive.

## Task index maintenance

When more than one task exists in a project, a small runtime registry lists them. This index
is additive and optional: a project that only ever has one task never creates it and behaves
byte-for-byte exactly as before. Track this behavior only through the rules below; the index
is never a committed artifact.

- **Index file** — `.spec-drift/index.md`. It is a single Markdown table with four columns
  and one row per task: `A` (active marker column, `*` on exactly one row), `Task` (the task
  slug), `File` (the checklist file: `SPEC_CHECKLIST.md` for the active row,
  `SPEC_CHECKLIST.<slug>.md` for archived rows), and `Status` (the live `X/Y` done-count read
  from that checklist file on disk). There is deliberately no date column: dates cannot be
  recovered by a full-rebuild-from-disk write, so storing them would make the writers disagree
  and break the byte-identical guarantee. The literal `SPEC_CHECKLIST.md` and its `Task:`
  header are always the source of truth; the active marker is pinned to that row.

- **When to (re)build it** — only on a structural change, i.e. when an archive or
  reactivation happens (the same-task in-place update path never creates or touches the
  index). Building the index is always a **full rebuild from disk**, never a two-row patch:
  enumerate `SPEC_CHECKLIST.md` plus every `SPEC_CHECKLIST.*.md`, derive one row per file
  (slug from each file's `Task:` header, falling back to the `<slug>` component of the
  filename), compute each row's `Status` as the live `X/Y` done-count read from that file,
  set the active marker on the `SPEC_CHECKLIST.md` row, sort rows ascending by slug, and write
  the `A | Task | File | Status` table with single-space-padded cells (no column-width
  alignment padding) using the project's prevailing newline (match `SPEC_CHECKLIST.md`).
  Because every column is derived purely from disk state and no date is stored, a full rebuild
  guarantees completeness even when archives predating this feature already exist, and makes
  two runs over the same disk state produce byte-identical output.

- **Single-task projects are unaffected** — when only one slug ever exists, keep updating
  `SPEC_CHECKLIST.md` in place and never create `.spec-drift/index.md`. A project with no
  index is fully supported and behaves exactly as today.

## Task-switch detection

Before writing, compare the incoming request's slug with the current `SPEC_CHECKLIST.md`
`Task:` slug. There are three mutually exclusive cases, applied identically by the
`/spec-drift:init` command:

- **(a) Slug equals the active task** — update `SPEC_CHECKLIST.md` in place; the index is not
  touched.

- **(b) Slug matches an existing archived row** (`SPEC_CHECKLIST.<slug>.md` exists and is not
  the active file) — do not archive the active file and do not recreate an empty checklist;
  that would shadow the archive's prior tracking and create a duplicate-slug index. Instead
  reactivate it with switch semantics: confirm the archive target
  `SPEC_CHECKLIST.<active-slug>.md` does not already exist (abort and change nothing on
  collision), archive the current active file by renaming it to
  `SPEC_CHECKLIST.<active-slug>.md`, restore the matching `SPEC_CHECKLIST.<slug>.md` to
  `SPEC_CHECKLIST.md`, rebuild the index from disk, then update the now-active checklist in
  place. Announce it, for example: "Reactivated archived task <slug> (was <active-slug>,
  archived to SPEC_CHECKLIST.<active-slug>.md); updated .spec-drift/index.md."

- **(c) Slug is new** (matches neither the active task nor any archive) — confirm the archive
  target `SPEC_CHECKLIST.<active-slug>.md` does not already exist (abort and change nothing on
  collision), archive the current file by renaming it to `SPEC_CHECKLIST.<active-slug>.md`,
  rebuild the index from disk, then write a fresh `SPEC_CHECKLIST.md`. This preserves the
  never-silently-overwrite guarantee. Announce it, for example: "Detected task switch:
  <active-slug> -> <new>; archived <active-slug> to SPEC_CHECKLIST.<active-slug>.md and updated
  .spec-drift/index.md."

## Static and read-only posture

This skill writes only Markdown: the `SPEC_CHECKLIST` files and the `.spec-drift/index.md`
registry. It never executes the project, never runs git, and never builds a shell command
from request contents. All file operations (writes and renames) are described in prose only.

## Extraction method

Read the user's most recent task request and extract three groups.

### 1. Functional requirements (explicit)

Pull every concrete, stated requirement. These are usually phrased as outcomes the user
wants: "the button should be hidden", "only admins can do X", "it must reject Y". One
checklist item per distinct behavior. Keep each item testable.

### 2. Implicit requirements (commonly forgotten)

These are not stated but cause real bugs when skipped. Expand by category only when the
request touches that category:

- **Permissions / roles** — enumerate every role implied by the request, not just the one
  named. If the user says "admins see the button", also list the non-admin roles
  (user, guest, etc.) and the negative case (a hidden control must also be enforced on the
  backend, not just in the UI).
- **UI** — list every state the component needs: loading, error, empty, and populated.
- **API / data** — list both the success path and the failure path; a success-only
  implementation is a classic drift source.

Only add implicit items that, if missing, the user would notice. Favor **precision over
recall**: a short, high-signal list beats a 100-item list the user ignores.

### 3. Clarifying questions (ambiguous scope only)

Raise a question only when scope is genuinely unclear and a wrong guess would cause rework:

- Ambiguous scope ("handle permissions" — which roles count?).
- Unmentioned exception cases.
- Undefined success criteria.

**Hard limit: at most 3 questions.** Sort by importance and consider asking only the single
most important one first. Do not interrogate; unanswered questions stay in the checklist as
open items.

## Output: SPEC_CHECKLIST.md

Write `SPEC_CHECKLIST.md` in the project working directory. Set its `Task:` header to this
request's slug. Apply the three-case rule above: update in place for the same task; reactivate
the matching archive (switch-style, never recreating it empty) for a slug that matches an
archived row; or, for a genuinely new slug, archive the existing file to
`SPEC_CHECKLIST.<existing-slug>.md` (refusing to overwrite an existing archive of that name)
before writing a fresh one.

```markdown
# Spec Checklist — <ISO timestamp>
Task: <short-kebab-slug, e.g. export-button-rbac>

## Original request
"<the user's task request, quoted verbatim>"

## Extracted checklist
- [ ] <functional requirement 1>
- [ ] <functional requirement 2>
- [ ] <implicit requirement (e.g. guest role: button hidden AND backend-enforced)>

## Open questions (max 3)
- Q1: <highest-importance ambiguity>
- Q2: <next ambiguity>

## Current implementation status
- [ ] <each item above, status updated as work proceeds>
```

Use unchecked `- [ ]` for everything at creation time. The status is filled in later by the
two consumers, each of which writes the `## Current implementation status` section itself:
`/spec-drift:check` does a fast presence-based estimate mid-task, and `/spec-drift:report`
does the authoritative drift-classified update when completion is audited.

## Closing summary

After writing the file, report concisely, for example:
"Extracted N checklist items and M open questions. SPEC_CHECKLIST.md created."
