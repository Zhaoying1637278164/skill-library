---
description: List every spec-drift task (active and archived) with its file and a live done-count read from each checklist. Use to see all concurrent tasks in a project and which one is currently active.
---

# /spec-drift:list

Show every spec-drift task in the project — the active one and any archived ones — with its
checklist file and a freshly recomputed progress count.

## When to use

Run this when a project tracks more than one task and you want to see them all at once: which
slugs exist, which file each lives in, how far each has progressed, and which one is active.

## What it does

1. If `.spec-drift/index.md` exists, read it. Otherwise Glob `SPEC_CHECKLIST.md` plus any
   `SPEC_CHECKLIST.*.md` archives and lazily build an in-memory index view from disk (the
   migration path for projects archived before the index existed).
2. For each task, recompute its status live: `Y` is the number of `- [` items under the
   `## Extracted checklist` section, and `X` is the number of `- [x]` lines under the
   `## Current implementation status` section. Before counting a status line, strip a single
   trailing `<!-- verified-at: ... -->` comment (anchored at end of line) so the receipt
   comment never corrupts the count. Reconcile the active marker to whichever row's file is
   the literal `SPEC_CHECKLIST.md`, using that file's `Task:` header as the tie-breaking
   source of truth; never trust the stored `*` over the real file.
3. By default do not write the index back — this command is display-only, which keeps the
   index stable and merge-friendly. The stored `Status` is treated as a cache only and is
   never trusted; it is recomputed live from disk for display. Only if the index is
   structurally out of sync with disk (a missing row, an extra row, or the `*` on the wrong
   row) rebuild and rewrite the whole file from disk — a deterministic full rebuild over the
   `A | Task | File | Status` columns (no date column): rows sorted ascending by slug, written
   with single-space-padded cells (no column-width alignment padding) using the project's
   prevailing newline (match `SPEC_CHECKLIST.md`). This is byte-identical for identical disk
   state and matches exactly what `/spec-drift:init`, `/spec-drift:switch`, and the
   `requirement-extraction` skill write.
4. Render a table with columns `A | Task | File | Status`: the active marker, the slug, the
   checklist file, and the live `X/Y` count.

## Notes

This command performs read-only static analysis. The only file it may write is
`.spec-drift/index.md`, and only to repair structural drift between the index and disk. It
never runs the project, never runs git, and never classifies drift — use `/spec-drift:report`
for a drift audit. It is owned by the requirement-tracking side of the plugin and never reads
or writes the per-item verification receipts in `SPEC_CHECKLIST.md`.

## Output

A table of all tasks, for example:

```
| A | Task                          | File                                            | Status |
| * | export-button-permissions     | SPEC_CHECKLIST.md                               | 3/5    |
|   | team-document-export-sharing  | SPEC_CHECKLIST.team-document-export-sharing.md  | 13/13  |
```

This rendered table is display-only and may be column-aligned for readability. The on-disk
`.spec-drift/index.md` is always written with single-space-padded cells (no alignment padding),
never in this aligned form, so the file stays byte-identical across every writer.

Single-task case (no index, only `SPEC_CHECKLIST.md`): show one line for the active task with
its live count. No-checklist case: say none was found and suggest running `/spec-drift:init`.
