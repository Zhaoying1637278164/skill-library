---
description: Generate a full drift report comparing SPEC_CHECKLIST.md against the actual files, then feed the result back as corrective guidance. Run this when a completion is claimed or when you want to audit whether the implementation matches the original requirements.
---

# /spec-drift:report

Produce a drift report: requirements vs. the real implementation.

## When to use

Run this when "done"/"finished" is claimed, or any time you want to audit completion.

## Options

`--base <ref>` (optional, parsed from `$ARGUMENTS`) — scope the audit to the files changed
versus `<ref>` instead of scanning the whole working directory. Useful on large projects or to
audit just a branch's diff.

`--verify-runtime` (optional, exact literal token parsed from `$ARGUMENTS`) — **opt-in, default
off.** Tier 2: flag plus orchestrator-obtained interactive consent (headless aborts to static),
then the auto-detected allowlisted test command runs once in a no-network, time-bounded Bash
sandbox. Evidence only **downgrades** a static `done`, never upgrades; decline, no detected
command, or no sandbox falls back to the static report with a one-line note. Composes with
`--base`. Full procedure: the skill's "Runtime verification (Tier 2, opt-in)" section and its
`references/runtime-tier.md`.

```
/spec-drift:report
/spec-drift:report --base main
/spec-drift:report --verify-runtime
```

When `--base` is given, the report only audits files reported by
`git diff --name-only <ref>...HEAD`; items whose evidence lies outside that set keep their
previously recorded status, and a `BaseRef: <ref>` note is recorded in the checklist. The ref is
validated first — rejected on whitespace or shell metacharacters, and an unresolvable ref **falls
back to a full scan** (validation rules: the skill's "Scoped detection" section). When `--base`
is absent, the report does a full scan exactly as before.

### Incremental re-verification

The report reads per-item `verified-at` markers and skips re-scanning **only** `done` items whose
evidence is provably tracked, existed at the recorded sha, and unchanged since it; anything
uncertain is fully re-scanned (fail safe: never skip on uncertainty), every non-done item is
**always re-scanned** so a classification never changes, and it composes with — does not
replace — `--base`. Full algorithm: the skill's "Incremental re-verification (`verified-at`)"
section and its `references/verified-at.md`.

## What it does

1. Read `SPEC_CHECKLIST.md`.
2. Resolve scope: full working-directory scan by default, or the `--base <ref>` changed-file set
   when that option is supplied.
3. Apply the `drift-detection` skill to compare each requirement against the in-scope files.
   Scan efficiently: Grep each item's identifiers first, then Read only the matched line ranges
   (~50–100 lines) — never whole files — and do not spawn subagents for the scan.
4. Classify each item as missing, changed, silent-fail, hardcode-debt, or done.
5. Emit a grouped drift report and a prioritized list of corrective follow-ups.
6. Update the `## Current implementation status` section. In a git repository, record
   `verified-at: <HEAD-sha>; files: ...` on each item confirmed `- [x]` from concrete evidence; in
   a non-git cwd the status is written exactly as today, with no comment. Markers are runtime-only
   and never change the drift report text (marker rules: the skill's `references/verified-at.md`).
   The report does **not** read or write `.spec-drift/index.md`.

This command performs read-only static analysis only. It never executes the project, never
evaluates file contents as code, and never runs shell commands built from file or checklist
contents. The single runtime exception is the opt-in `--verify-runtime` flag — only after explicit
interactive consent, only inside a no-network, time-bounded Bash sandbox, and only a command
chosen from a fixed allowlist, never built from contents. The other exceptions are read-only git
plumbing with validated single-argument inputs (paths only after a literal `--`, never
interpolated): `--base` scoping (`git diff`, `git rev-parse`) with a metacharacter-rejected ref,
and the `verified-at` refinement (`git rev-parse`, `git ls-files --error-unmatch`, `git cat-file
-e`, `git diff --name-only`), which proves each evidence path is tracked and existed at the sha
before an empty diff is trusted, since `git diff` is blind to untracked files.

If `SPEC_CHECKLIST.md` does not exist, say so and suggest running `/spec-drift:init` first.

## Output

A drift report grouped by classification (most severe first) plus a one-line summary:
"X/Y requirements satisfied. Z drift items need attention." When items are not done, a short
prioritized fix list follows.
