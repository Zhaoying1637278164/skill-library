---
description: 'Switch the active spec-drift task: archive the current SPEC_CHECKLIST.md and promote an archived SPEC_CHECKLIST.<slug>.md to active, updating the index. Never overwrites silently.'
---

# /spec-drift:switch

Make a different, already-archived task the active one. The current active checklist is
archived under its own slug and the requested archived checklist is promoted back to
`SPEC_CHECKLIST.md`.

## When to use

Run this when a project has more than one task and you want to resume a different concurrent
task than the one currently active. Use `/spec-drift:list` first to see the available slugs.

## Argument

`<slug>` is parsed from `$ARGUMENTS`. Validate it as an anchored kebab-case slug matching
`^[a-z0-9]+(-[a-z0-9]+)*$`, at most 64 characters. Reject anything containing a path
separator (`/` or `\`), a dot, whitespace, a leading or trailing hyphen, or any shell
metacharacter — it becomes part of a filename. On invalid input, abort with a message and
change nothing.

## What it does

All preconditions are checked before any rename, so a failure leaves the working tree
untouched:

1. Determine the current active slug from `SPEC_CHECKLIST.md`'s `Task:` header. If
   `SPEC_CHECKLIST.md` is absent, abort. If the current slug already equals `<slug>`, report
   a no-op and stop.
2. Run the never-silently-overwrite pre-checks, aborting and changing nothing on any failure:
   confirm `SPEC_CHECKLIST.<slug>.md` exists (else report "no archived checklist for
   <slug>"); confirm the archive target `SPEC_CHECKLIST.<current-slug>.md` does not already
   exist (else report "archive collision: SPEC_CHECKLIST.<current-slug>.md already exists").
3. Only after both pre-checks pass, archive the current task by renaming `SPEC_CHECKLIST.md`
   to `SPEC_CHECKLIST.<current-slug>.md`.
4. Promote the requested task by renaming `SPEC_CHECKLIST.<slug>.md` to `SPEC_CHECKLIST.md`
   (its own `Task:` header already reads `<slug>`).
5. Rebuild `.spec-drift/index.md` from disk: a deterministic full rebuild with columns
   `A | Task | File | Status` (`Status` is the live `X/Y` done-count read from each file), the
   active marker on the `SPEC_CHECKLIST.md` row, rows sorted ascending by slug, and no date
   column. Write the table with single-space-padded cells (no column-width alignment padding)
   using the project's prevailing newline (match `SPEC_CHECKLIST.md`), so the bytes are
   identical to what `/spec-drift:init` and the `requirement-extraction` skill write for the
   same disk state. Lazily create the index here if it was absent.
6. Report the swap.

## Notes

This command performs static analysis only. Its sole operations are Markdown file renames and
the index write. It never runs the project, never runs git, and never evaluates file contents
as code. It is owned by the requirement-tracking side of the plugin and never reads or writes
the per-item verification receipts in `SPEC_CHECKLIST.md`.

## Output

A one-line confirmation, for example:
"Active task: <slug> (was <current-slug>, archived to SPEC_CHECKLIST.<current-slug>.md)."
