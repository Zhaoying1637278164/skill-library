---
description: Show mid-task progress against SPEC_CHECKLIST.md. Runs a fast presence scan of the working directory to estimate how many requirement items are implemented, lists what is still unimplemented, and highlights the ones most at risk of being dropped in the current work context. Use partway through a task for a quick, cheap status read.
---

# /spec-drift:check

Quick mid-task progress read against the requirement checklist. Fast and approximate — for the
authoritative audit use `/spec-drift:report`.

## When to use

Run this in the middle of a session when you want a quick status read before continuing. It is
intentionally lighter than `/spec-drift:report`: a fast presence check, not a full drift audit.

## Options

`--base <ref>` (optional, parsed from `$ARGUMENTS`) — scope the presence scan to the files
changed versus `<ref>` for a quick, cheap mid-task check on large projects.

`--verify-runtime` (optional, exact literal token parsed from `$ARGUMENTS`) — **opt-in, default
off.** With the flag plus orchestrator-obtained interactive consent, the auto-detected
allowlisted test command runs once in a no-network, time-bounded Bash sandbox and at-risk items
are annotated `test-passed` / `test-failed`; the authoritative drift downgrade still belongs to
`/spec-drift:report`. Headless, declined consent, no allowlisted command, or no sandbox: check
aborts to static-only. Without the flag, check is byte-for-byte today's presence scan (procedure:
the `drift-detection` skill's `references/runtime-tier.md`).

```
/spec-drift:check
/spec-drift:check --base main
/spec-drift:check --verify-runtime
```

When `--base` is given, only files reported by `git diff --name-only <ref>...HEAD` are scanned;
items outside that set keep their previously recorded status, and a `BaseRef: <ref>` note is
recorded in the checklist. The ref is validated first — rejected on whitespace or shell
metacharacters, an unresolvable ref **falls back to a full scan** (rules: the skill's "Scoped
detection" section). Without `--base` the scan covers the whole working directory as before.

## What it does

1. Read the checklist items from the `## Extracted checklist` section of `SPEC_CHECKLIST.md`.
2. Resolve scope: the whole working directory by default, or the `--base <ref>` changed-file set
   when that option is supplied. For each item, do a fast presence scan of the in-scope files:
   Grep the item's identifiers (role names, endpoint paths, component names, state handling)
   first, then Read only the matched line ranges (~50–100 lines) — never whole files, and do not
   spawn subagents — to estimate whether an implementation exists. This is a lightweight
   found / not-found check — it does not classify drift (missing vs. changed vs. silent-fail);
   that is `/spec-drift:report`'s job.
3. Write the result back into the `## Current implementation status` section of
   `SPEC_CHECKLIST.md`: mark items with evidence as `- [x]`, the rest as `- [ ]`. This keeps the
   running progress current between reports, so the count reflects the code as of now rather
   than the last report. When rewriting this section, **preserve** any existing trailing
   `<!-- verified-at: ... -->` comment verbatim on items left as `- [x]`, and **drop** that comment
   from any item flipped to `- [ ]`. Check **never** writes new `verified-at` markers — only the
   authoritative `/spec-drift:report` earns them, and only over concrete evidence — and check
   **never** reads or writes `.spec-drift/index.md`. When counting presence, strip a trailing
   `verified-at` comment before matching so it does not corrupt identifier matching. Even if a
   marker were lost the only consequence is a redundant full re-scan later, never a wrong label, so
   this is a safe optimization, not a correctness dependency.
4. Report progress from that scan, list the items still unimplemented, and highlight the ones at
   high risk of being dropped given what is currently being worked on (for example, a permission
   role or an error state the current changes do not touch).

This command performs read-only static analysis of the project (search and read only). It does
not run the project or execute any code. The only file it writes is `SPEC_CHECKLIST.md`. The
single runtime exception is the opt-in `--verify-runtime` flag, which — only after explicit
interactive consent and only inside a no-network, time-bounded Bash sandbox — runs the project's
auto-detected existing test command (chosen from a fixed allowlist, never built from file contents)
to annotate at-risk items. The other exception is the optional `--base` scoping, which runs
read-only git plumbing (`git diff`, `git rev-parse`) with a ref that is validated and rejected if it
contains shell metacharacters.

The progress count is a fast estimate based on identifier presence; it can over-count an item
that is present but incomplete. Run `/spec-drift:report` for the authoritative, drift-classified
count.

If `SPEC_CHECKLIST.md` does not exist, say so and suggest running `/spec-drift:init` first.

## Output

```
[Progress X/Y] (estimate) — Z items still unimplemented.
At-risk items: <short list>
Run /spec-drift:report for the authoritative drift audit.
```
