---
description: Start a requirement checklist for the current task. Reads the most recent task request, extracts an explicit checklist, and writes SPEC_CHECKLIST.md. Run this at the beginning of a feature or before implementation starts.
---

# /spec-drift:init

Begin requirement tracking for the current task.

## When to use

Run this when you want to explicitly start a checklist for a task you are about to work on.

## What it does

1. Read the most recent user task request in this session.
2. Apply the `requirement-extraction` skill to pull out functional and implicit
   requirements.
3. Derive a short kebab-case task slug for this request and use it as the checklist's
   `Task:` identity. If `SPEC_CHECKLIST.md` already exists, compare the new slug against the
   active file and every `SPEC_CHECKLIST.<slug>.md` archive, then take exactly one of three
   mutually exclusive paths (identical to the `requirement-extraction` skill's rule):
   - **(a) Slug equals the active task** — update `SPEC_CHECKLIST.md` in place and preserve
     its recorded status. Do not touch the index.
   - **(b) Slug matches an existing archive** (`SPEC_CHECKLIST.<slug>.md` exists) — do not
     archive the active file and write a fresh empty checklist; that would shadow the
     archived task's tracking and create a duplicate-slug index. Instead defer to switch
     semantics: confirm `SPEC_CHECKLIST.<active-slug>.md` does not already exist (abort and
     change nothing on collision), archive the current active file to
     `SPEC_CHECKLIST.<active-slug>.md`, restore the matching `SPEC_CHECKLIST.<slug>.md` to
     `SPEC_CHECKLIST.md`, rebuild the index from disk, then update that now-active checklist
     in place. Never recreate it empty.
   - **(c) Slug is new** (matches neither the active task nor any archive) — confirm the
     archive target `SPEC_CHECKLIST.<active-slug>.md` does not already exist (abort and change
     nothing on collision), rename the existing `SPEC_CHECKLIST.md` to
     `SPEC_CHECKLIST.<active-slug>.md`, rebuild the index from disk, then write a fresh
     `SPEC_CHECKLIST.md`.
   Never silently overwrite an existing checklist. Whenever an archive or reactivation happens
   (cases b and c), create or rebuild `.spec-drift/index.md` from disk: one row per
   `SPEC_CHECKLIST.md` and `SPEC_CHECKLIST.*.md` with columns `A | Task | File | Status`
   (`Status` is the live `X/Y` done-count read from each file), the active `SPEC_CHECKLIST.md`
   row marked with `*`, rows sorted ascending by slug, and no date column, written with
   single-space-padded cells (no column-width alignment padding) using the project's prevailing
   newline (match `SPEC_CHECKLIST.md`) so every writer produces byte-identical output for the
   same disk state. Single-task projects never create the index.
4. Surface up to 3 clarifying questions for genuinely ambiguous scope, importance-sorted.

This command performs static text extraction only. It does not run the project or execute
any code. Single-task projects never create `.spec-drift/index.md` and behave exactly as
before; a project without the index is fully supported.

## Optional argument

If `$ARGUMENTS` is provided, treat it as the requirement description to extract from instead
of the most recent message.

## Output

Report concisely, for example:
"Extracted N checklist items. M clarifying questions. SPEC_CHECKLIST.md created."
