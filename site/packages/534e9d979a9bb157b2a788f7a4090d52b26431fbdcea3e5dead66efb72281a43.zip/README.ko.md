# Spec Drift Detector

[English](./README.md) | **한국어**

요청한 것과 실제로 만들어진 것 사이의 간극을 잡아냅니다.

긴 Claude Code 세션은 드리프트(drift)합니다. *"권한에 따라 버튼을 숨겨줘"* 라는 요청이
*"admin은 처리됐고, 다른 역할은 빠졌고, 에러 하나는 조용히 삼켜졌고, 값 하나는 일단 하드코딩"*
으로 변해도 세션은 여전히 **"완료"** 라고 보고합니다. Spec Drift Detector는 그 간극을 드러냅니다.
작업 시작 시점에 명시적 요구사항 체크리스트를 추출하고, 완료가 선언될 때 실제 파일과 대조합니다.

플러그인 네임스페이스는 `spec-drift` 이므로 명령은 `/spec-drift:init`, `/spec-drift:check`,
`/spec-drift:report`, `/spec-drift:list`, `/spec-drift:switch` 입니다.

## 동작 방식

1. **추출(Extract)** — 작업 시작 시 `requirement-extraction` 스킬이 요청을 `SPEC_CHECKLIST.md`
   체크리스트로 변환합니다(기능 요구사항 + 흔히 잊는 암묵 요구사항: 모든 역할, 모든 UI 상태,
   모든 API 실패 경로).
2. **추적(Track)** — `SPEC_CHECKLIST.md` 가 활성 작업의 단일 진실 공급원이 됩니다. 동시 다중
   작업은 `.spec-drift/index.md` 에 인덱싱되며, 새 작업을 시작하면 이전 체크리스트를 조용히
   덮어쓰지 않고 작업 slug 기준으로 자동 아카이브합니다. `/spec-drift:list` 와 `/spec-drift:switch`
   로 작업 간 이동합니다.
3. **탐지(Detect)** — "완료"가 선언되면 `drift-detection` 스킬이 체크리스트를 실제 파일과 대조해
   각 항목을 **missing**, **changed**, **silent-fail**, **hardcode-debt**, **done** 으로 분류합니다.
   분류는 **제어흐름 인지(Tier 1)** 입니다 — 상수 반환 guard나, 에러를 삼키는 `catch` 안에 갇힌
   실제 체크를 주석·식별자 이름이 아니라 구조적으로 잡아냅니다. `sg` 설치 시 선택적 `ast-grep`
   규칙 번들이 이를 가속하지만, 기본 Grep+Read 경로는 결코 그것에 의존하지 않습니다.

모든 것은 순수 Markdown이며 **기본적으로 정적**입니다. 플러그인은 요청과 파일을 읽으며, 파일
내용을 코드로 평가하지 않고, 신뢰할 수 없는 입력으로 셸 명령을 조립하지 않습니다. 무언가를
실행하는 **유일한** 경로는 옵트인 `--verify-runtime` 플래그뿐이며, 이는 기본적으로 꺼져 있고,
프로젝트의 기존 테스트 스위트를 샌드박스에서 한 번 실행하기 전에 명시적 대화형 동의를 요구합니다.
([보안](#보안) 참조.)

## 설치

커뮤니티 플러그인 디렉터리 제출이 진행 중입니다 — 아직 등재 전입니다. 등재 전까지는
체크아웃에서 로컬로 설치하세요.

### 로컬 설치 (현재)

repo를 클론한 뒤 Claude Code가 체크아웃을 가리키게 합니다 — repo 루트가 곧 플러그인입니다:

```
git clone https://github.com/h102-log/spec-drift-detector-plan.git
claude --plugin-dir spec-drift-detector-plan
```

또는 체크아웃 내부에서 현재 디렉토리를 가리킵니다:

```
claude --plugin-dir .
```

세션 중 편집을 반영하려면 `/reload-plugins` 를 사용하세요.

### 커뮤니티 마켓플레이스에서 (게시 후)

플러그인이 커뮤니티 마켓플레이스에 등록되면 다음 한 줄 설치가 가능해집니다:

```
/plugin marketplace add anthropics/claude-plugins-community
/plugin install spec-drift@claude-community
```

> 아직 활성화되지 않았습니다 — 제출이 리뷰 중이며, 승인되면 `spec-drift` 가 `claude-community` 에
> 등재됩니다.
> `add` 는 마켓플레이스 **repo 경로**(`anthropics/claude-plugins-community`)를,
> `install` 은 마켓플레이스 **이름**(`claude-community`)을 받습니다.

## 명령

### `/spec-drift:init`

현재 작업의 요구사항 체크리스트를 시작합니다. 가장 최근 작업 요청(또는 인자로 전달한 설명)을
읽어 기능 및 암묵 요구사항을 추출하고 `SPEC_CHECKLIST.md` 를 작성합니다. 정말로 모호한 범위에
대해서는 최대 3개의 명확화 질문을 제시합니다.

```
/spec-drift:init
/spec-drift:init add role-based visibility to the export button
```

### `/spec-drift:check`

작업 중간 진척을 표시합니다. 아직 구현되지 않은 항목을 나열하고, 현재 작업 기준으로 누락 위험이
가장 큰 항목을 강조합니다. `--base <ref>` 를 전달하면 해당 ref 대비 변경된 파일로 스캔을
한정합니다.

```
/spec-drift:check
/spec-drift:check --base main
```

```
[Progress 2/5] 3 items still unimplemented.
At-risk items: guest role enforcement, API failure path
```

### `/spec-drift:report`

`SPEC_CHECKLIST.md` 를 실제 파일과 대조한 전체 드리프트 리포트를 심각도별로 그룹화해 생성하고,
수정 후속 작업을 제시합니다. 완료가 선언될 때 실행하세요. `--base <ref>` 를 전달하면 해당 ref
대비 변경된 파일(`git diff --name-only <ref>...HEAD`)로 감사 범위를 한정합니다 — 대규모
프로젝트에서 더 빠르고 토큰 사용이 적은 대신 diff만 감사합니다. ref는 먼저 검증되며, 해석되지
않으면 전체 스캔으로 폴백합니다.

```
/spec-drift:report
/spec-drift:report --base main
```

이미 done으로 표기된 항목은 `verified-at: <sha>` 영수증을 갖습니다. 이후 report 시 해당 커밋 이후
증거 파일이 바뀌지 않은 항목은 건너뛰므로, 재실행은 변경된 부분만 재스캔합니다. 이는 `--base` 와
함께 동작합니다(두 범위가 교집합).

### `/spec-drift:list`

추적 중인 모든 작업을 라이브 진척 카운트와 함께 나열합니다. `.spec-drift/index.md` 를 읽거나(인덱스가
없으면 디스크의 체크리스트를 직접 탐색) 표시하며, 활성 작업이 표시됩니다.

```
/spec-drift:list
```

### `/spec-drift:switch`

활성 작업을 slug로 지정한 다른 추적 체크리스트로 전환합니다: 현재 `SPEC_CHECKLIST.md` 를
아카이브하고 요청한 체크리스트를 제자리로 승격합니다. 어떤 체크리스트도 조용히 덮어쓰지 않습니다.

```
/spec-drift:switch <task-slug>
```

## 스킬 (모델 호출)

두 스킬은 `description` 에 근거해 Claude가 관련성이 있다고 판단하면 자동 실행됩니다:

- **`requirement-extraction`** — 새 작업이 기술되거나 요구사항 캡처를 요청할 때 발동합니다.
  `SPEC_CHECKLIST.md` 를 작성합니다.
- **`drift-detection`** — 완료가 선언("done", "finished")되거나 완료 감사를 요청할 때 발동합니다.
  드리프트 리포트를 생성합니다.

위 명령은 결정적 제어가 필요할 때 동일한 로직을 명시적으로 호출합니다.

또한 `SessionStart` hook이 각 세션 시작 시 워크플로 발견성을 위해 한 줄 알림을 출력합니다. 이
hook은 고정 문자열만 출력하며, 분석을 수행하거나 코드를 읽거나 스스로 어떤 동작도 하지 않습니다.

## 예시

### `/spec-drift:init` 가 생성한 `SPEC_CHECKLIST.md`

```markdown
# Spec Checklist — 2026-06-24T14:32:00

## Original request
"Hide the export button based on the user's permission."

## Extracted checklist
- [ ] admin role: button visible
- [ ] user role: button hidden
- [ ] guest role: button hidden
- [ ] hidden control is also rejected by the backend (not just hidden in the UI)
- [ ] API success and failure paths both handled

## Open questions (max 3)
- Q1: How should the "moderator" role be treated?
- Q2: Should a hidden button show an explanation, or nothing at all?

## Current implementation status
- [ ] admin role: button visible
- [ ] user role: button hidden
- [ ] guest role: button hidden
- [ ] backend rejection for unauthorized roles
- [ ] API success/failure paths
```

### `/spec-drift:report` 가 생성한 드리프트 리포트

```
Drift report — SPEC_CHECKLIST.md vs implementation

MISSING (1)
  - guest role: button hidden  (no role check found for guest)

CHANGED (1)
  - backend rejection: UI hides the button, but the endpoint still
    accepts the call from unauthorized roles (frontend-only enforcement)

HARDCODE-DEBT (1)
  - permission check: components/Export.tsx returns `canExport = true`
    with a "TODO: wire real permission" comment

DONE (2)
  - admin role: button visible
  - user role: button hidden

Summary: 2/5 requirements satisfied. 3 drift items need attention.

Next steps:
  1. Add guest handling to the visibility check.
  2. Enforce the permission on the backend endpoint, not just the UI.
  3. Replace the hardcoded `canExport = true` with the real check.
```

## 보안

이 플러그인은 의도적으로 위험이 낮으며 **기본적으로 정적**입니다:

- 작업 요청과 소스 파일을 읽고 추론합니다.
- 정확히 하나의 Markdown 파일, `SPEC_CHECKLIST.md` 만 작성합니다.
- 기본적으로 프로젝트를 실행하지 않고, 파일 내용을 코드로 평가(`eval`/`exec`)하지 않으며, 신뢰할
  수 없는 데이터를 역직렬화하지 않고, 파일·요청 내용으로 셸 명령 문자열을 만들지 않습니다.
- `--verify-runtime` 는 무언가를 실행하는 유일한 옵트인 예외입니다. **기본적으로 꺼져** 있고,
  **어떤 실행보다 먼저** 명시적 대화형 동의를 요구하며, 비대화형·헤드리스 환경에서는 정적 전용으로
  중단됩니다(따라서 CI에서 자동 실행되지 않습니다). 또한 네트워크 없는, 시간 제한이 있는 샌드박스
  **안에서만** 실행되며(샌드박스 없이는 절대 실행하지 않음), 프로젝트의 **기존** 테스트 명령만
  고정 허용 목록(`npm test` / `pnpm test` / `yarn test` / `pytest` / `go test ./...` / `cargo test`
  / `bundle exec rspec`)에서 골라 실행합니다 — 파일·요청 내용으로 만든 명령이 아니고, 앱 자체도
  아닙니다. 동의가 거부되거나, 허용 목록 명령이 감지되지 않거나, 샌드박스를 구성할 수 없으면 정적
  전용으로 폴백합니다.
- 실행하는 유일한 셸 명령은 읽기 전용 git plumbing이며, 정확히 두 가지 경우에만 실행됩니다.
  (a) `--base <ref>` 를 명시적으로 전달하면 해당 ref 대비 변경된 파일로 감사 범위를 좁히기 위해
  `git diff --name-only` 와 `git rev-parse` 를 실행합니다. (b) done `- [x]` 항목이
  `verified-at: <sha>` 마커를 지니고 **또한** 프로젝트가 git 저장소이면, 해당 항목의 증거가 `<sha>`
  이후 바뀌지 않아 건너뛸 수 있는지 판단하기 위해 읽기 전용 `git rev-parse`, `git ls-files`,
  `git cat-file`, `git diff` 를 실행합니다. 모든 ref·sha·경로는 문자셋 검증을 거쳐 — 공백이나 셸
  메타문자(`;`, `|`, `&`, `$`, 백틱, `<`, `>`, `(`, `)`, 따옴표, 개행)가 있으면 거부 — 단일 인자로만
  전달하며(경로는 리터럴 `--` 뒤에), 더 큰 명령 문자열에 끼워 넣지 않습니다. 검증 실패, 해석되지
  않는 sha, git 부재 시에는 전체 재스캔으로 폴백합니다(페일세이프). 셸 명령은 `--base` ref가
  주어지거나 `verified-at` 마커가 있을 때에**만** 실행되며, 둘 다 없으면 플러그인은 어떤 셸 명령도
  실행하지 않습니다.
- 번들된 `SessionStart` hook은 고정 알림 문자열만 출력합니다 — 보간 없음, 파일 접근 없음,
  프로젝트 실행 없음.
- 어떤 비밀값·토큰도 저장하거나 요구하지 않습니다.

## 벤치마크 — 실제로 도움이 되나?

베이스 모델을 고정하고 **방법(method)** 만 바꿔 비교합니다:

- **플러그인** — drift-detection 방법(Grep + 타겟 Read + Tier 1 제어흐름 추론), 5개 카테고리.
- **미사용** — 체크리스트 분류 체계 없는 일반 코드 리뷰(이진 done / not-done).
- **카테고리명만** — 5개 라벨만 주고 방법은 주지 않음(핸디캡 베이스라인).

7개 픽스처(요구사항 43개, 단일 라벨 적대적 케이스 + 오탐 컨트롤) × 3방법 × 5트라이얼 =
**105런 / 방법당 215 항목-판정**, 각 판정을 **정답지 `EXPECTED.md` 로 객관 채점**(자기판정 아님).
"위험 누락" = 실제 드리프트를 *done* 으로 통과, "오탐" = 실제 *done* 을 드리프트로 표기.

| 방법 | 드리프트 분류? | 위험 누락 | 오탐 | 카테고리 정확도(strict / lenient) |
|---|---|---|---|---|
| **플러그인**(drift 방법) | 예 — 5개 카테고리 | **4.5%** | **0%** | **82.3% / 94.0%** |
| 미사용(일반 리뷰) | 아니오 — done/not-done | 7.7% | 0% | — |
| 카테고리명만 | 예 | 5.2% | 2.2% | 60.0% / 72.1% |

일반 리뷰 대비 플러그인은 **위험 누락을 약 절반으로(7.7% → 4.5%)** 줄이고, 일반 리뷰와 달리 각
간극이 *어떤 종류* 의 드리프트인지 알려줍니다. 라벨만 아는 경우 대비 카테고리 정확도를 60% → 82%
로 끌어올립니다.

### 언제 유용한가 (그리고 언제 아닌가)

| 시나리오 | 플러그인 strict | 플러그인 위험누락 | 미사용 위험누락 | baseline strict |
|---|---|---|---|---|
| 직접 / 단순 | 60% | 0% | 0% | 60% |
| 복합 다중파일 | 84.6% | 0% | 0% | 83.1% |
| 은닉 상수 스텁(단서 없음) | 100% | 0% | 0% | 0% |
| 적대적 제어흐름 | 86.7% | 10% | 16.7% | 50% |
| 교차파일 참조 | 83.3% | 0% | 8% | 53.3% |
| 비동기 에러 경로 | 83.3% | 0%† | 20% | 50% |
| 간접 참조(factory/const) | 86.7% | 0% | 0% | 46.7% |

† 비동기 플러그인 위험누락은 원 v3에서 16%였으나, 105-run 블라인드 재벤치(2026-07-05, 베이스
모델 Opus 4.8)에서 **0/25**로 재측정 — 5트라이얼 모두 async silent-fail을 전부 드리프트로 포착 —
하고 미사용 20%·plugin strict 83.3%는 v3 수치를 그대로 재현했습니다. 이 셀만 갱신했으며, 나머지
행은 원 v3 측정값으로 유지합니다.

**유용한 경우** — 드리프트가 간접 참조 뒤에 숨을 때: 실제 결정이 다른 파일에 있는 guard, 인자를
무시하는 factory, 모듈 레벨 상수, 단서 없는 스텁, `catch` 에 삼켜진 체크. 방법이 크게 앞서는
구간입니다(간접참조 86.7% vs 46.7%, 교차파일 83.3% vs 53.3% — 일반 리뷰는 8% 누락, 은닉 스텁
100% vs 0%).

**굳이 안 써도 되는 경우** — 작고 단일 파일이며 직접적인 작업. 플러그인과 일반 리뷰가 같은 것을
찾습니다(단순 시나리오 60=60 동률).

**정직한 한계.** 표본이 작습니다(43항목 × 5트라이얼; 6항목 픽스처에서는 1~2건이 백분율을 흔듦).
베이스 모델이 강해 일반 리뷰도 이미 꽤 안전 → 이 격차는 보수적 하한입니다. 105-run 재벤치에서
플러그인은 async silent-fail을 전부 포착했습니다(async 트라이얼 위험누락 0, 미사용은 20%). 다만
async 카테고리 *정밀도*는 여전히 불완전(strict 83.3%, 대부분 missing↔changed 혼동)하므로 async는
가장 신중히 검토할 시나리오입니다. 모든
플러그인 수치는 정적 Grep+Read 경로(`sg` 로컬 차단, 실제 로컬 환경과 동일). 전체 데이터·방법론:
[`docs/BENCHMARK_REPORT.md`](./docs/BENCHMARK_REPORT.md).

## 한계

- **재현율보다 정밀도(Precision over recall).** 추출기는 의도적으로 체크리스트를 짧고 신호가
  강하게 유지합니다. 100개 항목으로 넘치게 하기보다 일부 요구사항을 놓치는 쪽을 택합니다.
- **휴리스틱 탐지.** 드리프트 분류는 텍스트·제어흐름 패턴 매칭(역할명, 삼킨 에러 패턴, 상수 반환
  guard, `TODO`/`FIXME`, 하드코딩 리터럴)에 의존하며, `sg` 가 있으면 선택적 `ast-grep` 규칙 번들이
  이를 가속합니다. 거짓 양성·거짓 음성이 생길 수 있습니다. 리포트는 증명이 아니라 검토를 위한
  단서로 다루세요. 정적 경로의 7-픽스처 벤치마크는
  [`docs/BENCHMARK_REPORT.md`](./docs/BENCHMARK_REPORT.md) 에 있습니다.
- **런타임 검증은 옵트인.** 기본적으로 앱이나 테스트를 실행하지 않으므로 코드가 실제로 올바르게
  동작하는지는 확인할 수 없고, 요구사항이 소스에서 다뤄진 것처럼 보이는지까지만 확인합니다. 옵트인
  `--verify-runtime` 플래그를 쓰면, 명시적 동의 후에, 프로젝트의 **기존** 테스트 스위트(고정 허용
  목록에서 자동 감지하며, 파일 내용으로 만들지 않음)를 네트워크 없는, 시간 제한이 있는 샌드박스에서
  한 번 실행하고, 앱은 결코 시작하지 않습니다. 매핑된 테스트가 실패하면 `done` 항목을 드리프트로
  강등할 수 있지만, 테스트 통과가 항목을 승격시키지는 않습니다.
- **다중 작업, 활성 하나.** `SPEC_CHECKLIST.md` 가 활성 작업입니다. 새 작업(다른 slug)을 시작하면
  이전 작업을 `SPEC_CHECKLIST.<slug>.md` 로 자동 아카이브하고 전부 `.spec-drift/index.md` 에
  인덱싱합니다. 어떤 것도 조용히 덮어쓰지 않으며, `/spec-drift:list` 와 `/spec-drift:switch` 로
  작업 간 이동합니다.
- **gitRef 스코핑은 diff만 감사.** `--base <ref>` 를 전달하면 해당 ref 대비 변경된
  파일(`git diff --name-only <ref>...HEAD`)로 감사를 한정합니다 — 더 빠르고 토큰 사용이 적지만
  변경된 파일만 감사하며, diff 밖에 증거가 있는 항목은 이전에 기록된 상태를 유지합니다. 전체
  스캔을 원하면 `--base` 를 생략하세요.

## 체크리스트 커밋 여부

`SPEC_CHECKLIST.md`(및 `.spec-drift/` 레지스트리)를 버전 관리에 포함할지는 플러그인 사용
방식에 따라 다릅니다:

- **로컬 전용.** 체크리스트가 본인 세션용 스크래치패드일 뿐이라면 git에서 제외하세요. 둘 다
  `.gitignore` 에 추가합니다:

  ```
  SPEC_CHECKLIST*.md
  .spec-drift/
  ```

- **CI 게이트.** 아래 GitHub Actions 게이트를 활성화한다면 `SPEC_CHECKLIST.md` 를 **반드시**
  커밋해야 합니다 — 워크플로가 체크아웃된 저장소에서 이를 읽기 때문입니다. 파일이 없으면 게이트는
  자체 skip하며 머지를 차단하지 않습니다([`docs/ci-integration.md`](./docs/ci-integration.md)
  참조).

- **팀 협업.** `SPEC_CHECKLIST*.md` 파일만 커밋하세요. `.spec-drift/index.md` 는 파생물이며
  필요할 때 재빌드되므로, 커밋 여부는 선택 사항이고 충돌이 없습니다.

## 지속적 통합 (CI, 선택)

바로 활성화 가능한 GitHub Actions 워크플로가
[`.github/workflows/spec-drift.yml.example`](./.github/workflows/spec-drift.yml.example) 로
번들됩니다(이름을 바꾸기 전까지는 비활성). 각 풀 리퀘스트에서 headless 모드로
`/spec-drift:report --base <base>` 를 실행하고(정적 전용 — `--verify-runtime` 미사용), 드리프트
리포트를 단일 업서트 PR 코멘트로 게시하며, **`missing` 또는 `silent-fail` 항목이 있을 때에만 머지를
차단**합니다(`changed`/`hardcode-debt` 는 코멘트만, 차단 안 함). fork PR은 시크릿 없이 실행되고
게이트는 자체 skip합니다. 설정은 [`docs/ci-integration.md`](./docs/ci-integration.md) 참조.

## 기여

이슈와 풀 리퀘스트를
[저장소](https://github.com/h102-log/spec-drift-detector-plan)에서 환영합니다. 저장소 루트(곧
플러그인 루트)에서 변경을 제출하기 전에 `claude plugin validate . --strict` 를 실행하세요.

## 라이선스

MIT — [LICENSE](./LICENSE) 참조.
