---
description: Serve a static build output on a local port, run Lighthouse against it for both desktop and mobile, then stop the server. Useful for auditing a production build without deploying anywhere.
argument-hint: "<build-dir> [port]"
allowed-tools: Bash(npx --yes serve *) Bash(npx --yes lighthouse *) Bash(lsof *) Bash(netstat *) Read
---

# Serve a local build and audit it

Spin up a short-lived static server for a build directory, run Lighthouse against `http://localhost:<port>`, save reports, and stop the server. This is the fastest way to audit a real production build without deploying.

## Inputs

`$ARGUMENTS` takes:

1. Static build directory. Common values: `./dist`, `./build`, `./out`, `./.output/public`.
2. Optional port number. Default `4173`.

If the build directory does not exist, ask the user to build first (`npm run build` or equivalent) and stop.

## Workflow

1. Verify the directory has something to serve:

Read the directory. If it is empty or has no `index.html`, warn that Lighthouse may not find a meaningful page to audit. A Next.js `.next` directory is not static output; use `next start` separately or export an `out` directory before using this command.

2. Build a timestamp: `YYYY-MM-DDTHHMMSS`.

3. Start a static server in the background. `npx serve` is simple and dependency-free:

```bash
npx --yes serve@14.2.3 -s <build-dir> -l <port> --no-clipboard > /tmp/serve-<ts>.log 2>&1 &
```

Record the PID printed by the shell ($! in bash) so it can be killed later.

4. Wait 2-3 seconds for the server to bind. Then confirm it is up:

```bash
curl -sSf http://localhost:<port>/ -o /dev/null -w "%{http_code}" 2>&1
```

If not 200, tail `/tmp/serve-<ts>.log` and report the error, then stop the server and exit.

5. Run Lighthouse desktop and mobile against `http://localhost:<port>/`:

```bash
npx --yes lighthouse@12.8.2 "http://localhost:<port>/" \
  --preset=desktop \
  --output=json \
  --output-path=./lighthouse-desktop-<ts>.json \
  --chrome-flags="--headless=new --no-sandbox" \
  --quiet

npx --yes lighthouse@12.8.2 "http://localhost:<port>/" \
  --form-factor=mobile \
  --output=json \
  --output-path=./lighthouse-mobile-<ts>.json \
  --chrome-flags="--headless=new --no-sandbox" \
  --quiet
```

6. Stop the static server:

```bash
kill <pid> 2>&1
```

On Windows, use `taskkill /PID <pid> /F` if kill is not available.

7. Parse both JSON reports and summarize Core Web Vitals (same format as `/web-vitals-auditor:lighthouse-audit`).

## Output format

```
Served <build-dir> on http://localhost:<port> for 45 seconds.

Desktop
- Performance score: 92 [pass]
- LCP: 1.6 s [pass]
- CLS: 0.02 [pass]
- TBT: 80 ms [pass]

Mobile
- Performance score: 71 [warn]
- LCP: 2.9 s [warn]
- CLS: 0.08 [pass]
- TBT: 340 ms [warn]

Reports saved:
- ./lighthouse-desktop-<ts>.json
- ./lighthouse-mobile-<ts>.json

Next: /web-vitals-auditor:vitals-diagnose ./lighthouse-mobile-<ts>.json
```

## Do not

- Do not leave the static server running after the audit. Always kill the PID. If kill fails, warn the user and print the PID.
- Do not run more than one pair of Lighthouse runs per invocation. This is a single audit, not a stress test.
- Do not serve a build that exposes `.env`, `.git`, or source maps with secrets. `npx serve` by default serves everything in the directory; confirm the build output is what the user intended.
