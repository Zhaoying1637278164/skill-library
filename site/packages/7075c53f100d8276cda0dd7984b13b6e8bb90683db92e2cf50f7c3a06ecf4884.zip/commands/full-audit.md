---
description: Run the full Web Vitals audit pass in one command. Chains doctor, lighthouse-audit, vitals-diagnose, bundle-analyze, image-audit, and font-audit into a single report against a URL and a local build. Use before shipping a release or landing a perf-related PR.
argument-hint: "<url> [build-dir]"
allowed-tools: Bash(node --version *) Bash(npm --version *) Bash(npx --yes lighthouse *) Bash(npx --yes serve *) Bash(chrome --version *) Bash(google-chrome --version *) Read Glob Grep
---

# Full Web Vitals audit

Run the plugin's auditor skills in sequence and produce one combined report. This is the "do everything" command. Use only when explicitly asked.

## Inputs

`$ARGUMENTS` takes:

1. URL to audit (required, must begin with `http://` or `https://`).
2. Build directory for static analysis (optional). Defaults to `./dist` if it exists, else `./.next`, else skip static analysis.

If no URL is given, ask and stop. Do not invent a URL.

## Workflow

Run each step. If a step fails, note it and continue.

### Step 1: Environment check (from `doctor`)

Same as `/web-vitals-auditor:doctor`. Report Node, Lighthouse (via npx), Chrome availability, bundler config detection.

### Step 2: Lighthouse desktop and mobile (from `lighthouse-audit`)

Same as `/web-vitals-auditor:lighthouse-audit <url>`. Produces two JSON reports with a timestamp. Parses and summarizes LCP, CLS, INP, TBT, TTI and the Performance score for each form factor.

### Step 3: Diagnose (from `vitals-diagnose`)

Same as `/web-vitals-auditor:vitals-diagnose ./lighthouse-mobile-<ts>.json`. Produces a prioritized fix list (top 5 failures by distance from the pass threshold).

### Step 4: Bundle analyze (from `bundle-analyze`), if build dir exists

Same as `/web-vitals-auditor:bundle-analyze <build-dir>`. Reports duplicate deps, oversized packages, missed tree-shaking, dead code.

Cross-reference heavy packages against `reference/bundler-optimizations.md` for library-specific fixes.

### Step 5: Image audit (from `image-audit`)

Same as `/web-vitals-auditor:image-audit ./src` (or `./`). Scans HTML, JSX, TSX, Vue for images missing dimensions, lazy loading, next-gen formats, or preload for the hero image.

### Step 6: Font audit (from `font-audit`)

Same as `/web-vitals-auditor:font-audit ./src` (or `./`). Detects missing `font-display: swap`, synchronous CSS loads, unused weights.

## Output format

```
Web Vitals full audit
=====================
URL:        https://example.com
Build dir:  ./.next  (Next.js detected)

Environment
-----------
Node:            20.14.0
Lighthouse:      12.8.2 (via npx)
Chrome:          system 128.0.6613.120

Lighthouse results
==================
Desktop  Perf 88   LCP 1.6s [pass]  CLS 0.04 [pass]  INP n/a  TBT 140ms [pass]  TTI 2.4s [pass]
Mobile   Perf 58   LCP 3.9s [warn]  CLS 0.18 [warn]  INP n/a  TBT 780ms [fail]  TTI 6.9s [warn]

Top mobile fixes (prioritized by distance from pass)
----------------------------------------------------
1. TBT 780ms [fail, 580ms over]: main-thread work dominated by one script. Split ./.next/static/chunks/main-<hash>.js (see bundle findings).
2. LCP 3.9s [warn, 1.4s over]: hero image /_next/image?url=/hero.png loads at position 1 without preload. Add rel=preload in <Head>.
3. CLS 0.18 [warn, 0.08 over]: hero section height not reserved. Add width/height or aspect-ratio to the hero image.

Bundle findings
---------------
Duplicate deps (3):       lodash (3 copies: 71KB x 3 = 213KB wasted)
Oversized packages:       moment.js (290KB with all locales) -> suggest dayjs (7KB)
Tree-shaking missed:      @mui/icons-material imported from barrel (400KB instead of per-icon)

Image findings
--------------
3 images missing dimensions (CLS risk)
1 hero image without preload
7 images served as .jpg that could be .webp or .avif

Font findings
-------------
2 @font-face declarations without font-display: swap (blocks render)
Google Fonts loaded synchronously in <head> (use <link rel="preconnect"> and font-display=swap)

Suggested next steps, in priority order
---------------------------------------
1. Fix TBT: code-split main.js, defer non-critical scripts. Largest single win.
2. Remove moment.js (migrate to dayjs): saves ~280KB on every page.
3. Dedupe lodash: saves 142KB.
4. Preload hero image + set dimensions on it. Fixes LCP and CLS in one shot.

Reference
---------
For library-specific bundle fixes, see `reference/bundler-optimizations.md`.
```

## Do not

- Do not audit a dev server (`localhost:3000` running `next dev`). Dev builds are not representative. If the URL points at a dev server, warn the user and suggest building and serving locally, or pointing at staging.
- Do not include the full output of each skill. Keep the combined report under 100 lines.
- Do not run a full audit multiple times in a row. One invocation = one audit.
- Do not modify any source file. All findings are suggestions; the user decides which to apply.
