---
description: Check the local performance-audit toolchain. Reports Node and npm version, whether Lighthouse can run, whether Chrome or Chromium is installed and reachable, and which bundler config is present in cwd. Use before running a Lighthouse audit to confirm the environment is ready.
allowed-tools: Bash(node --version *) Bash(npm --version *) Bash(npx --version *) Bash(npx lighthouse --version *) Bash(chrome --version *) Bash(google-chrome --version *) Bash(chromium --version *) Read Glob
---

# Performance audit environment check

Run a fixed diagnostic of the local performance-audit toolchain.

## Steps

1. Node and npm:

```bash
node --version 2>&1
npm --version 2>&1
npx --version 2>&1
```

Require Node 18 or later. If Node is missing, nothing else in this plugin will run.

2. Lighthouse (pinned to 12.8.2 by the plugin; this step only confirms npx can fetch it):

```bash
npx --yes lighthouse@12.8.2 --version 2>&1
```

This downloads the package on first run, so it may take 10 to 30 seconds. Report the printed version.

3. Chrome or Chromium (Lighthouse needs a Chromium browser; lighthouse CLI will use `puppeteer` bundled Chrome if nothing is on PATH):

```bash
google-chrome --version 2>&1 || chrome --version 2>&1 || chromium --version 2>&1
```

If no system Chrome or Chromium is available, report that Lighthouse cannot run until a supported Chrome/Chromium binary is installed or explicitly configured. The Lighthouse npm package does not guarantee a bundled browser.

4. Bundler configs in cwd (Read or Glob the following and report which ones exist):
   - `next.config.js`, `next.config.mjs`, `next.config.ts`
   - `vite.config.js`, `vite.config.ts`
   - `nuxt.config.js`, `nuxt.config.ts`
   - `webpack.config.js`, `webpack.config.cjs`, `webpack.config.ts`
   - `rollup.config.js`, `rollup.config.mjs`
   - `astro.config.mjs`

5. Performance budget or CI config in cwd:
   - `performance-budget.json`
   - `lighthouserc.json`, `lighthouserc.js`, `.lighthouserc.json`

## Output format

```
Performance audit environment
-----------------------------
Node:             v20.14.0
npm:              10.8.1
Lighthouse:       12.8.2 (cached by npx)
Chrome:           system Chrome 128.0.6613.120 (or "bundled Chromium will be used")
Bundler:          Next.js (next.config.mjs)
Budget:           performance-budget.json present

Next steps: environment looks healthy. Try:
- /web-vitals-auditor:lighthouse-audit <url>
- /web-vitals-auditor:bundle-analyze ./.next
- /web-vitals-auditor:image-audit ./src
```

If something is missing, print the exact error line and a one-line fix hint.

## Do not

- Do not run a full Lighthouse audit as part of doctor. That is the job of `lighthouse-audit`. Here we only confirm the tool can fetch.
- Do not print values from `.env` files or any secrets.
- Do not install or upgrade any tool. Report what is missing and the install command.
