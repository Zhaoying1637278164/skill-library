---
name: font-audit
description: Detect font-loading issues. Use this when the user asks to audit fonts, check for FOIT or FOUT, fix font-display issues, find synchronous font loads in CSS, or audit how many font weights are loaded. Scans CSS, HTML, JSX, TSX, and Vue files.
argument-hint: "[source-dir]"
allowed-tools: Read Grep Glob
---

# Audit font loading for performance issues

Scan the codebase for common font-loading antipatterns: missing `font-display: swap`, fonts loaded synchronously via blocking CSS, and many font weights imported but never used.

## Inputs

`$ARGUMENTS` is the source directory. Defaults to `./src` if it exists, otherwise `./`.

## File types to scan

- `*.css`
- `*.scss`
- `*.sass`
- `*.less`
- `*.html`
- `*.jsx`
- `*.tsx`
- `*.vue`
- `*.astro`
- `*.svelte`

## Detection steps

### 1. Missing font-display: swap

Find every `@font-face` block. For each, check if it contains `font-display:`. If absent, flag it.

Also flag blocks using `font-display: block`, which is equivalent to FOIT (invisible text while loading).

Grep pattern: `@font-face`. Capture the block (multiline, until closing `}`), then look for `font-display:`.

Severity: fail. FOIT causes invisible text and hurts LCP for text-led pages.

Fix: add `font-display: swap;` to each `@font-face` block. Or use `font-display: optional` if you prefer no swap flash.

### 2. Synchronous font loads in CSS

Find `@import url(...)` or `<link rel="stylesheet" href="...fonts...">` lines that load font CSS synchronously. These block render.

Grep patterns:

- `@import url("https://fonts.googleapis.com`
- `<link rel="stylesheet" href="https://fonts.googleapis.com`
- `<link rel="stylesheet" href=".*fonts.*"` (in general)

Severity: warn.

Fix for Google Fonts: add `preconnect` and load the stylesheet with `media="print" onload="..."` or use `rel="preload" as="style"` with a swap. Or self-host the fonts (best).

### 3. Many font weights imported unused

For each font family, list the weights loaded (`font-weight: <n>` in `@font-face` or `&family=<font>:wght@300;400;500;600;700` in a Google Fonts URL).

Then grep the source for `font-weight: <n>` usages. If a loaded weight is never used, flag it.

Severity: warn.

Typical finding: site loads weights 300, 400, 500, 600, 700 but only uses 400 and 700. Saves 60 to 180 KB by dropping the rest.

### 4. Missing preload for critical font

For each `@font-face` whose family is used in a top-level heading or body text, check the HTML head for `<link rel="preload" as="font" type="font/woff2" crossorigin href="<same-url>">`. If missing, suggest adding it.

Severity: info.

### 5. Font files not in woff2

List every font URL. Flag any that is not `.woff2`. TTF, OTF, and EOT are much larger.

Severity: warn.

## Output format

```
Font audit: ./src
Scanned: 38 stylesheets, 112 components

Fail: missing font-display: swap (3)
- src/styles/fonts.css:12  @font-face for "Inter" has no font-display
- src/styles/fonts.css:24  @font-face for "JetBrains Mono" has no font-display
- src/styles/fonts.css:36  @font-face for "Inter Italic" uses font-display: block (FOIT)

Warn: synchronous font loading (1)
- index.html:14  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter...">
  Fix: add preconnect and load with rel="preload" as="style" swap, or self-host.

Warn: unused font weights (2)
- Inter: weights 300, 500, 600 loaded but never used in CSS. Drop to weights 400 and 700. Saves approximately 120 KB.
- JetBrains Mono: only weight 400 used. Drop weights 500 and 700.

Warn: non-woff2 font files (2)
- src/assets/fonts/Inter-400.ttf  Convert to woff2. Saves approximately 60%.
- src/assets/fonts/Inter-700.ttf  Convert to woff2.

Info: font not preloaded (1)
- Inter 400 (body) is used above the fold but not preloaded.
  Add to index.html <head>:
  <link rel="preload" as="font" type="font/woff2" crossorigin href="/fonts/Inter-400.woff2">

Summary: 3 fail, 5 warn, 1 info.
```

## Example

User input:

```
/web-vitals-auditor:font-audit ./src
```

Steps taken:

1. Glob for CSS, SCSS, and component files under `./src`.
2. Extract every `@font-face` block. Check each for `font-display:`.
3. Grep for `@import url(...)` and `<link rel="stylesheet"` that point to font hosts.
4. For each family loaded, list weights. Then grep for usages of those weights.
5. Flag non-woff2 font files.
6. Print the grouped report.

### Sample fix for Google Fonts

Before:

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
```

After (non-blocking):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
  rel="preload"
  as="style"
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap">
<link
  rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap"
  media="print"
  onload="this.media='all'">
```

Or, self-hosted (preferred):

```css
@font-face {
  font-family: "Inter";
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url("/fonts/Inter-400.woff2") format("woff2");
}
```

## Do not

- Do not modify files. This is a read-only audit.
- Do not suggest `font-display: optional` as default. It can cause text to never swap on slow networks.
- Do not assume a weight is unused without grepping the entire source tree.
- Do not flag icon fonts (font-awesome, material-icons) for missing weights. They only use one weight.
- Do not recommend removing a font entirely without confirming with the user.
