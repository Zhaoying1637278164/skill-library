---
name: vitals-diagnose
description: Interpret a Lighthouse JSON result and prioritize concrete fixes. Use this when the user has a Lighthouse report and wants to know what to fix first, or when a previous lighthouse-audit run produced warnings or failures. Maps each failed metric (LCP, CLS, INP, TBT, TTI) to its likely root causes and a specific remediation.
argument-hint: "<path-to-lighthouse-report.json>"
allowed-tools: Read Grep Glob
---

# Diagnose a Lighthouse result and prioritize fixes

Read a Lighthouse JSON report, rank the failing metrics by impact, and map each failure to concrete remediations such as removing render-blocking CSS, resizing oversized images, cutting main-thread work, or deferring third-party scripts.

## Inputs

`$ARGUMENTS` is the path to a Lighthouse JSON report (the file produced by `--output=json`).

If `$ARGUMENTS` is empty, use Glob to find the newest file matching `./lighthouse-mobile-*.json` in the current directory. If none exists, ask the user for a path.

## Workflow

1. Read the JSON. Validate that `lighthouseVersion` and `audits` exist. If not, report that the file is not a Lighthouse report.
2. Extract the failing metrics based on the thresholds in `lighthouse-audit`. Order them by distance from the pass threshold, largest first.
3. For each failing metric, read the diagnostic audits listed below and extract their findings.
4. Produce a prioritized fix list. Each item names the metric it improves, the root cause, and a concrete change.

## Metric-to-audit map

### LCP (largest-contentful-paint)

Read these diagnostic audits:

- `largest-contentful-paint-element`: gets the selector of the LCP element.
- `render-blocking-resources`: CSS or JS in `<head>` that delays first paint.
- `uses-responsive-images`: LCP image served larger than the viewport needs.
- `modern-image-formats`: LCP image is JPEG or PNG instead of WebP or AVIF.
- `uses-optimized-images`: LCP image is not compressed.
- `prioritize-lcp-image`: hero image is not preloaded or has low `fetchpriority`.
- `server-response-time`: TTFB is above 600 ms.

### CLS (cumulative-layout-shift)

Read these diagnostic audits:

- `layout-shifts`: lists the elements that shifted, with shift scores.
- `unsized-images`: images without `width` and `height` attributes.
- `font-display`: fonts without `font-display: swap` cause FOIT shifts.
- `non-composited-animations`: animations that shift layout instead of running on the compositor.

### INP (interaction-to-next-paint)

INP is a field metric. Lighthouse navigation runs often do not produce an INP value. When INP is present in the report, it usually comes from a timespan run. The diagnostic audits that correlate with INP are the same ones that explain TBT and long tasks:

- `bootup-time`: time spent parsing and executing JS.
- `mainthread-work-breakdown`: time categories (script evaluation, style, layout, paint).
- `third-party-summary`: third-party scripts and their blocking time.
- `long-tasks`: tasks longer than 50 ms.

If the INP audit is missing from the report, say so and recommend measuring INP in production with the `web-vitals` JS library or CrUX.

### TBT (total-blocking-time)

Read these diagnostic audits:

- `mainthread-work-breakdown`
- `bootup-time`
- `unused-javascript`: JS delivered but not executed.
- `unused-css-rules`: CSS delivered but not applied.
- `duplicated-javascript`: modules included more than once.
- `legacy-javascript`: ES5 bundles shipped to modern browsers.

### TTI (interactive)

TTI shares root causes with TBT. Focus on `mainthread-work-breakdown` and `bootup-time`.

## Output format

Group findings by metric, ordered by impact. Each finding should include a file path or selector from the report when available, and the estimated savings Lighthouse reports.

```
Report: ./lighthouse-mobile-2026-04-17T120000.json
Failing metrics: LCP 3.9 s [warn], TBT 780 ms [fail], INP 420 ms [warn]

Priority 1: TBT 780 ms [fail]
Main cause: 1.9 s of main-thread script evaluation from third-party scripts.
Fixes:
- Defer analytics.vendor.com/loader.js (blocks 420 ms). Load after `load` event or use `async`.
- Remove duplicated lodash (saves 84 KB, 180 ms on low-end mobile). See bundle-analyze.
- Drop legacy ES5 bundles for modern browsers (saves 120 ms). Configure target to `es2020` in your bundler.

Priority 2: LCP 3.9 s [warn]
LCP element: <img src="/hero.jpg"> in the first fold.
Fixes:
- Serve the hero as AVIF or WebP (saves 240 KB, 0.6 s on 3G).
- Add `<link rel="preload" as="image" href="/hero.avif">` to the HTML head.
- Add explicit `width` and `height` to the `<img>` tag to reserve layout.

Priority 3: INP 420 ms [warn]
Main cause: long task of 340 ms on first click, from hydration of a large React tree.
Fixes:
- Split the route component with `React.lazy` to defer hydration of below-the-fold content.
- Move heavy computation off the main thread with a Web Worker, or chunk with `scheduler.yield()`.
```

## Example

User input:

```
/web-vitals-auditor:vitals-diagnose ./lighthouse-mobile-2026-04-17T120000.json
```

Steps taken:

1. Read the file. Confirm it is a valid Lighthouse JSON.
2. Check each metric against its threshold.
3. For every failing metric, read its diagnostic audits.
4. Produce the grouped fix list shown above.
5. If any fix points at a bundle problem, suggest `/web-vitals-auditor:bundle-analyze`. If it points at images, suggest `/web-vitals-auditor:image-audit`. If it points at fonts, suggest `/web-vitals-auditor:font-audit`.

## Do not

- Do not guess causes that are not in the report. If a diagnostic audit is missing, say so.
- Do not list every single Lighthouse suggestion. The point is to prioritize, so keep to the top three per metric.
- Do not propose fixes that require assumptions you cannot verify (for example, a specific CDN). Name the pattern and let the user pick the vendor.
- Do not rewrite code in this skill. Suggest changes, and let the user decide to edit.
