---
name: lighthouse-audit
description: Run Lighthouse against a URL in both desktop and mobile form factors and summarize Core Web Vitals. Use this when the user asks to audit a page, check Web Vitals, measure page speed, or score a URL against Lighthouse. Parses the JSON output and reports LCP, CLS, INP, TBT, and TTI with pass, warn, and fail thresholds.
argument-hint: "<url>"
allowed-tools: Bash(npx --yes lighthouse@12.8.2 *) Read Write Grep
---

# Run a Lighthouse audit and summarize Core Web Vitals

Run Lighthouse against a URL twice (desktop and mobile), save the JSON reports to the current directory with timestamped filenames, parse them, and produce a short table of Core Web Vitals with a pass, warn, or fail on each metric.

## Inputs

`$ARGUMENTS` is the URL to audit. It must begin with `http://` or `https://`.

If `$ARGUMENTS` is empty or does not look like a URL, ask the user for a URL and stop. Do not make up a default target.

## Workflow

1. Build a timestamp string in the form `YYYY-MM-DDTHHMMSS`. Use it to name two output files so repeated runs do not overwrite prior reports: `./lighthouse-desktop-<ts>.json` and `./lighthouse-mobile-<ts>.json`.
2. Announce the two commands about to run and the output paths.
3. Run the desktop audit. The `desktop` preset sets a desktop form factor plus desktop throttling.
4. Run the mobile audit. Lighthouse defaults to a mobile form factor. Pass `--form-factor=mobile` explicitly so the intent is clear.
5. Read both JSON files. Extract these audit IDs from `audits`:
   - `largest-contentful-paint` (LCP)
   - `cumulative-layout-shift` (CLS)
   - `interaction-to-next-paint` (INP). In standard navigation mode Lighthouse may not produce an INP value because INP requires recorded user interactions. If the audit is missing or its `numericValue` is null, mark INP as `n/a` and note that INP requires a timespan run or field data from CrUX.
   - `total-blocking-time` (TBT)
   - `interactive` (TTI)
6. Also extract `categories.performance.score` (0 to 1) for each run.
7. Produce the report in the format below.

## Exact commands

Desktop run:

```bash
npx --yes lighthouse@12.8.2 "<url>" \
  --preset=desktop \
  --output=json \
  --output-path=./lighthouse-desktop-<ts>.json \
  --chrome-flags="--headless=new --no-sandbox" \
  --quiet
```

Mobile run:

```bash
npx --yes lighthouse@12.8.2 "<url>" \
  --form-factor=mobile \
  --output=json \
  --output-path=./lighthouse-mobile-<ts>.json \
  --chrome-flags="--headless=new --no-sandbox" \
  --quiet
```

Replace `<url>` with the target and `<ts>` with the timestamp (for example `2026-04-17T120000`).

## Thresholds

Use these thresholds to label each metric. LCP, CLS, and INP thresholds come from Google's Core Web Vitals guidance. TBT thresholds come from Lighthouse's internal scoring. TTI is deprecated by Google but Lighthouse still reports a value; treat TTI as informational.

| Metric | Pass | Warn | Fail |
|---|---|---|---|
| LCP | less than or equal to 2.5 s | 2.5 s to 4.0 s | greater than 4.0 s |
| CLS | less than or equal to 0.1 | 0.1 to 0.25 | greater than 0.25 |
| INP | less than or equal to 200 ms | 200 ms to 500 ms | greater than 500 ms |
| TBT | less than or equal to 200 ms | 200 ms to 600 ms | greater than 600 ms |
| TTI | less than or equal to 3.8 s | 3.8 s to 7.3 s | greater than 7.3 s |
| Performance score | 90 to 100 | 50 to 89 | 0 to 49 |

## Output format

```
Lighthouse audit: <url>
Reports: ./lighthouse-desktop-<ts>.json and ./lighthouse-mobile-<ts>.json

Desktop
- Performance score: 92 [pass]
- LCP: 1.8 s [pass]
- CLS: 0.04 [pass]
- INP: 140 ms [pass]
- TBT: 120 ms [pass]
- TTI: 2.6 s [pass]

Mobile
- Performance score: 58 [warn]
- LCP: 3.9 s [warn]
- CLS: 0.18 [warn]
- INP: 420 ms [warn]
- TBT: 780 ms [fail]
- TTI: 6.9 s [warn]

Top failures (mobile)
1. TBT 780 ms [fail]. See vitals-diagnose for the fix list.
2. LCP 3.9 s [warn]. Likely culprit: large hero image or render-blocking CSS.
3. INP 420 ms [warn]. Likely culprit: heavy main-thread work on first interaction.
```

## Example

User input:

```
/web-vitals-auditor:lighthouse-audit https://example.com
```

Steps taken:

1. Pick a timestamp. Example: `2026-04-17T120000`.
2. Announce: "Running Lighthouse desktop and mobile against https://example.com. Reports will be saved to ./lighthouse-desktop-2026-04-17T120000.json and ./lighthouse-mobile-2026-04-17T120000.json."
3. Run:

```bash
npx --yes lighthouse@12.8.2 "https://example.com" \
  --preset=desktop \
  --output=json \
  --output-path=./lighthouse-desktop-2026-04-17T120000.json \
  --chrome-flags="--headless=new --no-sandbox" \
  --quiet
```

4. Run:

```bash
npx --yes lighthouse@12.8.2 "https://example.com" \
  --form-factor=mobile \
  --output=json \
  --output-path=./lighthouse-mobile-2026-04-17T120000.json \
  --chrome-flags="--headless=new --no-sandbox" \
  --quiet
```

5. Read both JSON files. Pull `audits.<id>.numericValue` for each metric and `categories.performance.score`. Apply the thresholds table above.
6. Print the table and the top three failures by distance from the pass threshold on mobile.
7. Suggest: "Run `/web-vitals-auditor:vitals-diagnose ./lighthouse-mobile-2026-04-17T120000.json` for a prioritized fix list."

## Do not

- Do not invent URLs. If the user did not give one, ask.
- Do not run Lighthouse in a loop or as a cron. This skill runs once per invocation.
- Do not skip the mobile run. Mobile is where most real users are, and desktop alone hides most regressions.
- Do not use `lighthouse@latest`. Pin the version so results are reproducible.
- Do not overwrite existing report files. Always include the timestamp in the output path.
- Do not pass `--preset=mobile`. It is not a valid Lighthouse preset. Mobile is the default form factor.
