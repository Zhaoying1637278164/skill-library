---
name: bundle-analyze
description: Analyze a Webpack, Vite, or Rollup build output for duplicated dependencies, unexpectedly large packages (lodash, moment, polyfills), and missing tree-shaking. Use this when the user asks to analyze a bundle, find what is bloating the bundle, check for duplicates, or reduce JS size.
argument-hint: "[build-output-dir]"
allowed-tools: Bash(npx source-map-explorer *) Bash(npx vite-bundle-visualizer *) Read Grep Glob
---

# Analyze a build bundle

Inspect the compiled output of a Webpack, Vite, or Rollup build. Identify duplicated dependencies, oversized packages, missing tree-shaking, and polyfills shipped to modern browsers.

## Inputs

`$ARGUMENTS` is the build output directory. Defaults:

- Vite: `./dist`
- Webpack (CRA, Next export): `./build` or `./dist`
- Rollup: `./dist`
- Next.js (app router): `./.next`

If `$ARGUMENTS` is empty, detect the build tool and default output:

1. Glob for `vite.config.*`. If present, bundler is Vite.
2. Glob for `webpack.config.*` or `craco.config.*`. If present, bundler is Webpack.
3. Glob for `rollup.config.*`. If present, bundler is Rollup.
4. Read `package.json`. If `next` is in dependencies, bundler is Next.js (Webpack or Turbopack).

If no bundler can be detected, ask the user.

## Workflow

1. Confirm the build directory exists and has JS files.
2. Confirm source maps exist (`.js.map` files). Warn if not: source-map-explorer needs them.
3. Run the analyzer for the bundler.
4. Read the analyzer output (JSON or HTML) and produce the structured report below.

## Exact commands

### Any bundler with source maps (preferred)

```bash
npx --yes source-map-explorer@2.5.3 "<build-dir>/**/*.js" \
  --json > bundle-report.json
```

If you want the interactive HTML report as well:

```bash
npx --yes source-map-explorer@2.5.3 "<build-dir>/**/*.js" \
  --html bundle-report.html
```

### Vite without source maps

```bash
npx --yes vite-bundle-visualizer@1.2.1 -o bundle-report.html
```

This opens an interactive treemap. Read the generated file to extract module sizes.

## What to look for

After the analyzer writes its output, read it and check for these patterns.

### 1. Duplicated dependencies

Look for the same package appearing in more than one chunk, or two versions of the same package.

Common causes:

- Two transitive deps pin different major versions. Fix with `resolutions` (Yarn) or `overrides` (npm).
- A monorepo with duplicated installs. Fix with `--legacy-peer-deps` carefully or switch to pnpm.
- Default webpack splitChunks is too permissive. Configure `splitChunks: { chunks: 'all' }`.

Report them as: `duplicated: <pkg> @ <version-a> (<chunk-1>, <size>) and @ <version-b> (<chunk-2>, <size>). Fix: <specific suggestion>.`

### 2. Oversized packages

Known offenders and their fixes:

| Package | Fix |
|---|---|
| `moment` | Switch to `date-fns` (tree-shakable) or `dayjs` (tiny). Moment ships locales by default. |
| `lodash` (whole) | Use `lodash-es` with per-method imports, or `just-*` single-purpose packages. |
| `core-js` polyfills | Configure your bundler to target modern browsers and drop unneeded polyfills. |
| `@babel/runtime` (large) | Check `browserslist` target. Too-old targets pull in large helpers. |
| `rxjs` (whole) | Import specific operators from `rxjs/operators`, not the root. |
| `three`, `chart.js` | Use the ESM entry points and only import the classes you need. |
| `aws-sdk` (v2) | Upgrade to AWS SDK v3, which ships per-client packages. |
| `@sentry/browser` with replay and tracing | Ship `@sentry/browser` only; add replay or tracing behind a dynamic import if needed. |

### 3. Missing tree-shaking

- Imports like `import _ from 'lodash'` or `import * as x from 'big-lib'` defeat tree-shaking.
- CommonJS re-exports (`module.exports = require('./foo')`) defeat tree-shaking.
- `sideEffects: true` in package.json keeps everything.

Grep the source for offending patterns:

```bash
# Example patterns. Run via Grep tool, not bash.
import _ from 'lodash'
import \* as
from 'moment'
```

### 4. Legacy polyfills shipped to modern browsers

If `browserslist` targets older than `last 2 versions, not dead, > 0.2%`, the bundler ships extra helpers and polyfills.

Check `package.json` or `.browserslistrc`. Recommend tightening the target unless the user explicitly supports IE.

## Output format

```
Build: ./dist
Bundler: Vite
Total JS: 812 KB (minified, 238 KB gzipped)

Top packages by size
1. moment 240 KB. Fix: replace with date-fns or dayjs. Saves approximately 200 KB.
2. lodash 88 KB. Imported as `import _ from 'lodash'`. Fix: switch to `lodash-es` with per-method imports or use `just-*` packages.
3. @aws-sdk/client-s3 72 KB. OK. This is the per-client SDK.
4. core-js 48 KB. Fix: raise the browserslist target to drop unused polyfills.

Duplicates
- lodash @ 4.17.21 (chunk main, 88 KB) and @ 4.17.20 (chunk vendor, 87 KB). Fix: add `"overrides": { "lodash": "4.17.21" }` to package.json.

Tree-shaking issues
- src/utils/helpers.ts: `import _ from 'lodash'` imports the full package.
- src/pages/home.tsx: `import * as charts from 'chart.js'` prevents tree-shaking.

Estimated savings if all fixes applied: 310 KB minified (85 KB gzipped).
```

## Example

User input:

```
/web-vitals-auditor:bundle-analyze ./dist
```

Steps taken:

1. Confirm `./dist` exists and has `.js` and `.js.map` files.
2. Run:

```bash
npx --yes source-map-explorer@2.5.3 "./dist/**/*.js" --json > bundle-report.json
```

3. Read `bundle-report.json`. Sort bundles by size, then sort modules within each bundle.
4. Grep the source for `import _ from 'lodash'`, `from 'moment'`, and `import \* as`.
5. Produce the structured report above.
6. If duplicates are found, suggest exact changes to `package.json`.

## Reference

When you identify a heavy package, consult `reference/bundler-optimizations.md` in the plugin root for the specific fix. It is a per-library catalog (lodash, moment, MUI, react-icons, Chart.js, D3, AWS SDK, Firebase, and more) plus framework-specific tips for Next.js, Vite, and Webpack. Read on-demand only when a specific library shows up as oversized.

## Do not

- Do not run the build for the user (`npm run build`, `vite build`). Assume the build is already produced. If the directory is empty, say so and ask the user to build first.
- Do not run bundle visualizers that open a browser window in a headless session. Always write a file.
- Do not guess package sizes. Numbers must come from the analyzer output.
- Do not recommend dropping a dependency without an alternative.
- Do not delete or modify `package.json`. This skill only reports. Edits belong to the user.
