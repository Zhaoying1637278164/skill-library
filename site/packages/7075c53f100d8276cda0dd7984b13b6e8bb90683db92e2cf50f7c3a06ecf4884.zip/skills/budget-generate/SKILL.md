---
name: budget-generate
description: Generate a performance-budget.json file for Lighthouse CI with reasonable defaults. Use this when the user asks to add performance budgets, set up Lighthouse CI budgets, enforce perf thresholds in CI, or create a budget config for their project.
argument-hint: "[framework-or-site-type]"
allowed-tools: Read Write Edit Glob
---

# Generate a performance-budget.json for Lighthouse CI

Write a `performance-budget.json` at the project root with budgets tuned for the site type. The file is consumed by Lighthouse CI (`lhci autorun`) or by the Lighthouse CLI via `--budget-path`.

## Inputs

`$ARGUMENTS` is an optional site-type hint. Examples:

- `marketing` (static or mostly-static landing pages)
- `blog`
- `ecommerce`
- `app` (logged-in SPA)
- `docs`

If `$ARGUMENTS` is empty, detect the site type:

1. Glob the project for `package.json`. Read `dependencies` and `devDependencies`.
   - If it includes `next`, `gatsby`, `astro`, `hugo`, or `@11ty/eleventy`, default to `marketing`.
   - If it includes `react-router-dom`, `@tanstack/react-router`, `vue-router`, or `@angular/router`, default to `app`.
   - If it includes `@docusaurus/core`, `vitepress`, or `mkdocs`, default to `docs`.
2. Otherwise ask the user.

## Workflow

1. Announce: "I will write performance-budget.json at the project root with <site-type> defaults."
2. If a file named `performance-budget.json` already exists, read it. Offer to merge rather than overwrite.
3. Write the file. Print the budgets you chose.

## Default budgets

These are mobile-first budgets. Desktop budgets are stricter and the user can adjust.

### marketing

```json
[
  {
    "path": "/*",
    "timings": [
      { "metric": "first-contentful-paint", "budget": 1800 },
      { "metric": "largest-contentful-paint", "budget": 2500 },
      { "metric": "speed-index", "budget": 3400 },
      { "metric": "total-blocking-time", "budget": 200 },
      { "metric": "interactive", "budget": 3800 },
      { "metric": "cumulative-layout-shift", "budget": 0.1 }
    ],
    "resourceSizes": [
      { "resourceType": "document", "budget": 30 },
      { "resourceType": "script", "budget": 170 },
      { "resourceType": "stylesheet", "budget": 60 },
      { "resourceType": "image", "budget": 250 },
      { "resourceType": "font", "budget": 100 },
      { "resourceType": "third-party", "budget": 160 },
      { "resourceType": "total", "budget": 900 }
    ],
    "resourceCounts": [
      { "resourceType": "script", "budget": 10 },
      { "resourceType": "stylesheet", "budget": 4 },
      { "resourceType": "font", "budget": 4 },
      { "resourceType": "third-party", "budget": 8 }
    ]
  }
]
```

### blog

Same as marketing, but raise `image` to 350 KB and `total` to 1100 KB, and raise `resourceCounts.script` to 12.

### ecommerce

```json
[
  {
    "path": "/*",
    "timings": [
      { "metric": "first-contentful-paint", "budget": 2200 },
      { "metric": "largest-contentful-paint", "budget": 3000 },
      { "metric": "speed-index", "budget": 4000 },
      { "metric": "total-blocking-time", "budget": 400 },
      { "metric": "interactive", "budget": 5000 },
      { "metric": "cumulative-layout-shift", "budget": 0.1 }
    ],
    "resourceSizes": [
      { "resourceType": "document", "budget": 50 },
      { "resourceType": "script", "budget": 350 },
      { "resourceType": "stylesheet", "budget": 80 },
      { "resourceType": "image", "budget": 450 },
      { "resourceType": "font", "budget": 120 },
      { "resourceType": "third-party", "budget": 350 },
      { "resourceType": "total", "budget": 1600 }
    ],
    "resourceCounts": [
      { "resourceType": "script", "budget": 18 },
      { "resourceType": "stylesheet", "budget": 6 },
      { "resourceType": "font", "budget": 6 },
      { "resourceType": "third-party", "budget": 15 }
    ]
  }
]
```

### app

```json
[
  {
    "path": "/*",
    "timings": [
      { "metric": "first-contentful-paint", "budget": 2500 },
      { "metric": "largest-contentful-paint", "budget": 3500 },
      { "metric": "speed-index", "budget": 4500 },
      { "metric": "total-blocking-time", "budget": 500 },
      { "metric": "interactive", "budget": 6000 },
      { "metric": "cumulative-layout-shift", "budget": 0.1 }
    ],
    "resourceSizes": [
      { "resourceType": "document", "budget": 40 },
      { "resourceType": "script", "budget": 500 },
      { "resourceType": "stylesheet", "budget": 100 },
      { "resourceType": "image", "budget": 300 },
      { "resourceType": "font", "budget": 100 },
      { "resourceType": "third-party", "budget": 250 },
      { "resourceType": "total", "budget": 1600 }
    ],
    "resourceCounts": [
      { "resourceType": "script", "budget": 25 },
      { "resourceType": "stylesheet", "budget": 6 },
      { "resourceType": "font", "budget": 4 },
      { "resourceType": "third-party", "budget": 10 }
    ]
  }
]
```

### docs

Same as blog.

## How budgets are used

A minimal `.lighthouserc.json` that consumes this file:

```json
{
  "ci": {
    "collect": {
      "url": ["http://localhost:3000/"],
      "numberOfRuns": 3,
      "settings": {
        "budgetPath": "./performance-budget.json"
      }
    },
    "assert": {
      "assertions": {
        "categories:performance": ["error", { "minScore": 0.9 }]
      }
    },
    "upload": {
      "target": "temporary-public-storage"
    }
  }
}
```

Run it in CI:

```bash
npx --yes @lhci/cli@0.15.1 autorun
```

## Example

User input:

```
/web-vitals-auditor:budget-generate app
```

Steps taken:

1. Announce: "I will write performance-budget.json at the project root with `app` defaults."
2. Check if `performance-budget.json` exists. If it does, show a diff and ask before overwriting.
3. Write the `app` JSON shown above.
4. Print: "Wrote performance-budget.json. To enforce it in CI, add a `.lighthouserc.json` as shown in the skill doc."

## Do not

- Do not silently overwrite an existing `performance-budget.json`. Always show the diff and ask.
- Do not set `minScore` higher than 0.9 by default. Setting it at 1.0 is aspirational and breaks CI on any regression, however small.
- Do not pick budgets without a site-type. Different sites have different floors.
- Do not put `interaction-to-next-paint` in `timings`. INP is a field metric from real users (CrUX); Lighthouse does not accept it as a lab budget timing. Use the CWV thresholds in the `vitals-diagnose` skill instead.
- The full valid `resourceType` enum is `document`, `script`, `stylesheet`, `image`, `font`, `media`, `other`, `third-party`, `total`. The default budgets above omit `media` and `other` because most sites do not need them; add them if you ship video or miscellaneous downloads.
- The full valid `timings` metric enum is `first-contentful-paint`, `largest-contentful-paint`, `speed-index`, `interactive`, `total-blocking-time`, `cumulative-layout-shift`, `max-potential-fid`, `first-meaningful-paint`, `first-cpu-idle`, `estimated-input-latency`. The last four are deprecated; prefer the first six.
