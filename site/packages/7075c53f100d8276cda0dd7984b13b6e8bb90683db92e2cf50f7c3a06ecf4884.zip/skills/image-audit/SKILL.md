---
name: image-audit
description: Scan HTML, JSX, TSX, and Vue files for unoptimized images. Use this when the user asks to audit images, find images hurting LCP, check for missing lazy loading, find images without dimensions, or look for hero images that are not preloaded.
argument-hint: "[source-dir]"
allowed-tools: Read Grep Glob
---

# Audit images in HTML, JSX, TSX, and Vue files

Scan the codebase for image usage patterns that hurt performance: missing `width` or `height` (causes layout shift), missing `loading="lazy"` (wastes bandwidth on below-the-fold), no next-gen format (AVIF or WebP), and a hero image that is not preloaded (hurts LCP).

## Inputs

`$ARGUMENTS` is the source directory. Defaults to `./src` if it exists, otherwise `./`.

## File types to scan

- `*.html`
- `*.jsx`
- `*.tsx`
- `*.vue`
- `*.astro`
- `*.svelte`

## Detection steps

Run these Grep passes. Each pass produces a finding category.

### 1. Missing width or height

Find `<img>` tags without both `width` and `height` attributes.

Grep for `<img ` and inspect each match. Report any match that does not have both `width` and `height` (or a `style` with `aspect-ratio`). For Next.js `<Image>` and similar framework components, they are safe if `width` and `height` are passed as props.

Severity: fail. This is a direct CLS cause.

### 2. Missing loading="lazy"

Find `<img>` or `<iframe>` tags without `loading="lazy"` or `loading="eager"`. Skip the first image on each page (likely hero, which should be eager).

Grep pattern: `<img ` and `<iframe `. For each match, check for `loading=`. If absent and the match is not in the first 20 lines of a page, flag it.

Severity: warn. Not every image needs lazy, but above-the-fold versus below-the-fold should be explicit.

### 3. No next-gen format

Find image URLs ending in `.jpg`, `.jpeg`, or `.png` in `src=`, `background-image`, or `url(...)`. Flag any that does not have a paired `<source type="image/avif">` or `<source type="image/webp">` in a `<picture>` element.

Severity: warn. AVIF or WebP saves 25 to 50% of bytes vs JPEG.

### 4. Hero image not preloaded

Find likely hero images (the first `<img>` on a page, or images with class names matching `hero`, `banner`, `cover`, `splash`, `above-the-fold`, or `lcp`).

For each candidate, check the corresponding HTML head or document head for `<link rel="preload" as="image" href="<same-src>">`. If missing, flag it.

Severity: warn. Preloading the LCP image can shave 300 to 800 ms on mobile.

### 5. Raw srcset missing

Find `<img src=`  references to large images (`.jpg`, `.png`, `.webp`, `.avif`) without a `srcset`. Skip icons and small UI images (below 100x100).

Severity: info. `srcset` prevents serving oversized images to small viewports.

## Output format

```
Image audit: ./src
Scanned: 147 files

Fail: missing dimensions (6)
- src/pages/Home.tsx:42  <img src="/hero.jpg" ...>  missing width and height
- src/components/ProductCard.tsx:18  <img src={product.image} ...>  missing width and height

Warn: missing loading="lazy" (14)
- src/components/Blog/Post.tsx:71  <img src="/assets/fig-3.png" ...>  likely below fold, add loading="lazy"

Warn: no next-gen format (9)
- public/hero.jpg (342 KB)  consider adding WebP or AVIF. Suggest a <picture> with <source type="image/avif">.

Warn: hero image not preloaded (1)
- src/pages/Home.tsx:42  Hero <img src="/hero.jpg">. Add to index.html:
  <link rel="preload" as="image" href="/hero.jpg">

Info: missing srcset (22)
- public/gallery/*.jpg 12 files. Consider generating srcset with your image pipeline.

Summary: 6 fail, 24 warn, 22 info.
```

## Example

User input:

```
/web-vitals-auditor:image-audit ./src
```

Steps taken:

1. Glob for `*.html`, `*.jsx`, `*.tsx`, `*.vue`, `*.astro`, `*.svelte` under `./src`.
2. For each file, run the Grep passes above.
3. For each finding, record the file path, line number, and the rule that fired.
4. Print the grouped report.
5. If more than five dimensions are missing, suggest adopting a framework `<Image>` component (Next.js `next/image`, Gatsby `gatsby-image`, Nuxt `nuxt-img`) which enforces dimensions.

### Sample patterns

Flag: `<img src="/hero.jpg" alt="Hero">` (missing width and height, and it is the hero)

Fix:

```html
<picture>
  <source srcset="/hero.avif" type="image/avif">
  <source srcset="/hero.webp" type="image/webp">
  <img
    src="/hero.jpg"
    alt="Hero"
    width="1200"
    height="630"
    fetchpriority="high">
</picture>
```

And in the `<head>`:

```html
<link rel="preload" as="image" href="/hero.avif" imagesrcset="/hero.avif">
```

## Do not

- Do not modify files. This is a read-only audit. Show fixes, let the user apply them.
- Do not flag a framework `<Image>` component as missing dimensions if the props contain width and height.
- Do not flag SVGs for missing width and height. Most inline SVGs have a viewBox, which is sufficient for layout.
- Do not flag icons smaller than 100x100 for missing lazy loading. The cost is negligible and can hurt perceived performance.
- Do not assume a format is missing without checking for a sibling `<source>` tag or `<picture>` wrapper.
