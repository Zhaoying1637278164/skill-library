#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const readJson = relativePath => JSON.parse(fs.readFileSync(path.join(root, relativePath), "utf8"));
const fail = message => {
  console.error(`FAIL: ${message}`);
  process.exitCode = 1;
};

const plugin = readJson(".claude-plugin/plugin.json");
const marketplace = readJson(".claude-plugin/marketplace.json");

for (const key of ["name", "version", "description", "license"]) {
  if (!plugin[key]) fail(`plugin.json is missing ${key}`);
}

if (plugin.author && plugin.author.email) {
  fail("plugin.json must not publish an author email");
}

if (!marketplace.name || !marketplace.owner || !Array.isArray(marketplace.plugins)) {
  fail("marketplace.json is missing required marketplace metadata");
}

const listing = marketplace.plugins.find(item => item.name === plugin.name && item.source === "./");
if (!listing) fail("marketplace.json must list this root plugin with source \"./\"");

if (listing?.version !== plugin.version) {
  fail("marketplace listing version must match plugin.json version");
}

for (const relativePath of [
  "README.md",
  "LICENSE",
  "PRIVACY.md",
  "hooks/hooks.json",
  "hooks/session-start.js",
  "hooks/post-tool-use.js"
]) {
  if (!fs.existsSync(path.join(root, relativePath))) fail(`required file missing: ${relativePath}`);
}

const hooks = readJson("hooks/hooks.json");
for (const eventName of ["SessionStart", "PostToolUse"]) {
  if (!hooks.hooks || !Array.isArray(hooks.hooks[eventName]) || hooks.hooks[eventName].length === 0) {
    fail(`hooks.json is missing ${eventName}`);
  }
}

const emailPattern = /mr\.mohit44@gmail\.com/i;
for (const relativePath of [".claude-plugin/plugin.json", "LICENSE", "PRIVACY.md"]) {
  if (emailPattern.test(fs.readFileSync(path.join(root, relativePath), "utf8"))) {
    fail(`personal email found in ${relativePath}`);
  }
}

if (!process.exitCode) console.log("plugin package checks passed");
