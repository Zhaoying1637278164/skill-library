#!/usr/bin/env node
const { spawnSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const SESSION_START_HOOK = path.join(__dirname, "..", "hooks", "session-start.js");
const POST_TOOL_USE_HOOK = path.join(__dirname, "..", "hooks", "post-tool-use.js");
const FIXTURES = path.join(__dirname, "fixtures");

const names = fs.readdirSync(FIXTURES).filter(n =>
  fs.statSync(path.join(FIXTURES, n)).isDirectory()
);

let pass = 0, fail = 0;
for (const name of names) {
  const cwd = path.join(FIXTURES, name);
  const expPath = path.join(cwd, ".expected-context");
  const expected = fs.existsSync(expPath) ? fs.readFileSync(expPath, "utf8").trim() : null;

  const result = spawnSync(process.execPath, [SESSION_START_HOOK], { cwd, encoding: "utf8" });
  if (result.status !== 0 || result.error) {
    console.log(`FAIL ${name}: hook crashed: ${result.error || result.stderr}`);
    fail++;
    continue;
  }

  const trimmed = result.stdout.trim();

  if (expected === "none") {
    if (trimmed === "") {
      console.log(`PASS ${name} (silent)`);
      pass++;
    } else {
      console.log(`FAIL ${name}: expected silent, got: ${trimmed.slice(0, 80)}`);
      fail++;
    }
    continue;
  }

  if (trimmed === "") {
    console.log(`FAIL ${name}: hook was silent but expected context`);
    fail++;
    continue;
  }

  try {
    const parsed = JSON.parse(trimmed);
    const ctx = parsed.hookSpecificOutput && parsed.hookSpecificOutput.additionalContext;
    if (!ctx) {
      console.log(`FAIL ${name}: missing additionalContext`);
      fail++;
      continue;
    }
    if (expected && !ctx.includes(expected)) {
      console.log(`FAIL ${name}: expected context to contain "${expected}"`);
      console.log(`  actual: ${ctx.slice(0, 160)}`);
      fail++;
      continue;
    }
    console.log(`PASS ${name}`);
    pass++;
  } catch (e) {
    console.log(`FAIL ${name}: invalid JSON: ${e.message}`);
    fail++;
  }
}

const postToolCases = [
  {
    name: "build command",
    input: { tool_name: "Bash", tool_input: { command: "npm run build" } },
    expected: "Build command detected"
  },
  {
    name: "lighthouse command with report path",
    input: { tool_name: "Bash", tool_input: { command: "npx --yes lighthouse@12.8.2 https://example.com --output-path=./audit.json" } },
    expected: "/web-vitals-auditor:vitals-diagnose ./audit.json"
  },
  {
    name: "unrelated command",
    input: { tool_name: "Bash", tool_input: { command: "git status --short" } },
    expected: null
  },
  {
    name: "other tool",
    input: { tool_name: "Read", tool_input: { command: "npm run build" } },
    expected: null
  }
];

for (const testCase of postToolCases) {
  const result = spawnSync(process.execPath, [POST_TOOL_USE_HOOK], {
    cwd: path.join(__dirname, ".."),
    encoding: "utf8",
    input: JSON.stringify(testCase.input)
  });

  if (result.status !== 0 || result.error) {
    console.log(`FAIL post-tool-use ${testCase.name}: hook crashed: ${result.error || result.stderr}`);
    fail++;
    continue;
  }

  const trimmed = result.stdout.trim();
  if (testCase.expected === null) {
    if (trimmed === "") {
      console.log(`PASS post-tool-use ${testCase.name} (silent)`);
      pass++;
    } else {
      console.log(`FAIL post-tool-use ${testCase.name}: expected silent, got: ${trimmed.slice(0, 100)}`);
      fail++;
    }
    continue;
  }

  try {
    const parsed = JSON.parse(trimmed);
    const ctx = parsed.hookSpecificOutput && parsed.hookSpecificOutput.additionalContext;
    if (!ctx || !ctx.includes(testCase.expected)) {
      console.log(`FAIL post-tool-use ${testCase.name}: expected context to contain "${testCase.expected}"`);
      fail++;
      continue;
    }
    console.log(`PASS post-tool-use ${testCase.name}`);
    pass++;
  } catch (e) {
    console.log(`FAIL post-tool-use ${testCase.name}: invalid JSON: ${e.message}`);
    fail++;
  }
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail > 0 ? 1 : 0);
