# Library-specific bundle optimizations

A lookup for the biggest bundle-size wins per library. Read this file from the `bundle-analyze` skill only when the analyzer identifies one of the listed packages as heavy in the output.

## Lodash

**Default size**: ~70 KB minified, more gzipped-dependent.

**Fix options**, best first:

1. Replace with `lodash-es` and use named imports. With a bundler that supports tree-shaking (Webpack 4+, Rollup, Vite, esbuild), this drops to per-function size.
2. Use `babel-plugin-lodash` to rewrite `import _ from 'lodash'` patterns to per-method imports automatically.
3. Replace common functions with native JS: `_.map` -> `Array.prototype.map`, `_.find` -> `Array.prototype.find`, `_.debounce` -> a 10-line local util.

**Anti-pattern to remove**: `import _ from 'lodash'` followed by `_.map(...)`. This imports the whole library.

## Moment.js

**Default size**: ~290 KB with all locales. Moment is deprecated by its maintainers.

**Fix options**, best first:

1. Replace with `date-fns`. 13 KB for common operations. Tree-shakes.
2. Replace with `dayjs`. ~7 KB core, similar API to moment for easy migration.
3. Replace with `Intl.DateTimeFormat` and `Intl.RelativeTimeFormat` for simple cases. Zero runtime cost.

**If you must keep moment**: use `moment-locales-webpack-plugin` to strip unused locales. Savings are typically 200 KB.

## Material-UI (MUI v4)

**Default size**: ~300 KB if imported by barrel.

**Fix options**:

1. Upgrade to MUI v5 or v6. v5 tree-shakes by default with named imports.
2. Use per-component imports: `import Button from '@material-ui/core/Button'` instead of `import { Button } from '@material-ui/core'`.
3. Use the `babel-plugin-import` to rewrite barrel imports at build time.

## React Icons

**Default size**: can balloon to 500 KB+ if imported carelessly.

**Fix**: always import from the per-pack entry, not the root.

```js
import { FiHome } from 'react-icons/fi'    // good: 1 icon
import { FiHome } from 'react-icons'       // bad: all icons
```

## Chart.js

**Default size**: ~180 KB.

**Fix options**:

1. Use Chart.js v3+ and the tree-shakable imports: register only the controllers, elements, scales, and plugins the app uses.
2. Replace with `lightweight-charts` (80 KB) for financial charts, or `apexcharts` for general charts.

## D3

**Default size**: all of d3 is ~270 KB.

**Fix**: import only the modules used. `d3-scale`, `d3-selection`, `d3-transition` etc. are separate npm packages.

```js
import { scaleLinear } from 'd3-scale'
import { select } from 'd3-selection'
```

## Polyfills (core-js, @babel/polyfill)

`@babel/polyfill` is deprecated. Use `core-js` directly.

**Fix**: configure `browserslist` properly so Babel and Autoprefixer generate output for the real target browsers. The default `> 0.5%, last 2 versions, not dead` pulls in polyfills for browsers no one uses.

A realistic modern target:

```
last 2 chrome versions
last 2 firefox versions
last 2 safari versions
last 2 edge versions
not ie 11
```

## AWS SDK (aws-sdk v2)

**Default size**: ~1 MB. Avoid in frontend code entirely.

**Fix**: migrate to AWS SDK v3. Per-service imports: `@aws-sdk/client-s3` is ~60 KB. Only pull the operations used.

If the SDK is in frontend code at all, consider whether it should move to a backend call instead. Frontend is rarely the right place for AWS SDK.

## Firebase

Firebase SDKs (pre v9) ship ~400 KB.

**Fix**: upgrade to v9 modular SDK. Tree-shakes per feature. Typical app drops to ~80 KB.

## React Router

Minor sizes but worth knowing:

- `react-router-dom` v6: ~13 KB. Small; no action needed.
- `react-router-dom` v5: ~18 KB. Still fine.

## Large CSS-in-JS runtimes

- `styled-components` v5: ~12 KB.
- `emotion` (`@emotion/styled`): ~8 KB.
- Both acceptable; neither dominates.

**If the bundle has a CSS-in-JS library but the app is mostly static CSS**: remove the library. This is a common accidental carry-over from starter templates.

## Translation / i18n libraries

- `i18next`: ~40 KB core. Tree-shakes.
- `react-intl`: ~30 KB core. Uses Intl.

**Common mistake**: shipping translation JSON for all languages in the main bundle. Load them async per route.

## Rich text editors

- `Draft.js`: ~210 KB.
- `Slate`: ~30 KB (much smaller than Draft).
- `TipTap` + ProseMirror: ~130 KB.

If the editor is only used on one page, ensure it is code-split. Route-level split is the first fix.

## Framework-specific tips

### Next.js

- Use `next/dynamic` with `{ ssr: false }` to lazy-load components that are not above the fold.
- Run `ANALYZE=true next build` with `@next/bundle-analyzer` configured.
- Consider React Server Components for content-heavy pages; they ship zero JS.

### Vite

- `rollup-plugin-visualizer` produces the same kind of report as `webpack-bundle-analyzer`.
- Use `build.chunkSizeWarningLimit: 500` to get warnings on large chunks.
- Vite 5 emits better chunks by default; upgrade if on v3.

### Webpack

- `webpack-bundle-analyzer` is the gold standard.
- `SplitChunksPlugin` comes with sensible defaults in Webpack 5.
- If using Webpack 4, check for `mode: 'development'` accidentally shipping to prod.

## What "large" means in context

Not every big library is a problem. Consider these before acting:

- The library runs only on one route and is code-split. Not in the main bundle. Fine.
- The library is part of a build-time or server-only path. Not in the browser bundle at all. Fine.
- The library replaces custom code that would be the same size or larger. Fine.

Only act when the library is in the main bundle, runs in every page load, and is realistic to replace or subset.
