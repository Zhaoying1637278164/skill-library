#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const cwd = process.cwd();

function has(rel) {
  try { return fs.existsSync(path.join(cwd, rel)); } catch { return false; }
}
function isDir(rel) {
  try { return fs.statSync(path.join(cwd, rel)).isDirectory(); } catch { return false; }
}

const findings = [];

if (has("lighthouserc.json") || has("lighthouserc.js") || has(".lighthouserc.json") || has(".lighthouserc.js")) {
  findings.push("- Lighthouse CI config detected. Use `/web-vitals-auditor:lighthouse-audit <url>` for a one-off audit, or `/web-vitals-auditor:budget-generate` to refresh the budget file.");
}

if (has("performance-budget.json")) {
  findings.push("- performance-budget.json detected. Use `/web-vitals-auditor:lighthouse-audit <url>` to test against the current budget.");
}

if (has("next.config.js") || has("next.config.cjs") || has("next.config.mjs") || has("next.config.ts")) {
  findings.push("- Next.js project detected. Use `/web-vitals-auditor:bundle-analyze ./.next` after a build to analyze the bundle, or `/web-vitals-auditor:image-audit ./` to scan for unoptimized images.");
}

if (has("vite.config.js") || has("vite.config.cjs") || has("vite.config.ts") || has("vite.config.mjs")) {
  findings.push("- Vite project detected. Use `/web-vitals-auditor:bundle-analyze ./dist` after a build to analyze the bundle.");
}

if (has("nuxt.config.js") || has("nuxt.config.cjs") || has("nuxt.config.ts") || has("nuxt.config.mjs")) {
  findings.push("- Nuxt project detected. Use `/web-vitals-auditor:bundle-analyze ./.nuxt` after a build to analyze the bundle.");
}

if (has("webpack.config.js") || has("webpack.config.cjs") || has("webpack.config.ts")) {
  findings.push("- Webpack config detected. Use `/web-vitals-auditor:bundle-analyze ./dist` after a build. For source-map-aware analysis, emit `.map` files.");
}

try {
  if (has("package.json")) {
    const pkg = JSON.parse(fs.readFileSync(path.join(cwd, "package.json"), "utf8"));
    const deps = Object.assign({}, pkg.dependencies || {}, pkg.devDependencies || {});
    if (deps["lighthouse"] || deps["@lhci/cli"]) {
      findings.push("- Lighthouse package in package.json. The plugin uses `npx lighthouse@12.8.2` directly so it does not depend on your local version, but your CI can reuse it.");
    }
  }
} catch {}

if (findings.length > 0) {
  const text = [
    "Web Vitals Auditor plugin is active. Detected in " + cwd + ":",
    findings.join("\n"),
    "Run `/web-vitals-auditor:doctor` to check Node, Chrome, and Lighthouse availability."
  ].join("\n\n");
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "SessionStart",
      additionalContext: text
    }
  }));
}
process.exit(0);
