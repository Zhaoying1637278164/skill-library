#!/usr/bin/env node
let input = "";
process.stdin.on("data", c => input += c);
process.stdin.on("end", () => {
  try {
    const data = JSON.parse(input);
    if (data.tool_name !== "Bash") return process.exit(0);
    const cmd = (data.tool_input && data.tool_input.command) || "";
    const notes = [];

    if (/\b(npm|pnpm|yarn)\s+run\s+build\b/.test(cmd) || /\bnext\s+build\b/.test(cmd) || /\bvite\s+build\b/.test(cmd) || /\bnuxt\s+build\b/.test(cmd)) {
      notes.push("Build command detected. If it completed successfully, run `/web-vitals-auditor:bundle-analyze ./dist` (or `./.next`, `./build`) to find duplicated packages, oversized deps, and missed tree-shaking. Run `/web-vitals-auditor:lighthouse-audit <url>` against a preview URL to baseline Web Vitals.");
    }
    if (/\bnpx\s+.*lighthouse\b/.test(cmd) || /\blighthouse\s+https?:\/\//.test(cmd)) {
      const jsonMatch = cmd.match(/--output-path[=\s]+([^\s]+)/);
      const reportPath = jsonMatch ? jsonMatch[1] : "the saved JSON report";
      notes.push(`Lighthouse command detected. If it saved a report, \`/web-vitals-auditor:vitals-diagnose ${reportPath}\` interprets the JSON and prioritizes fixes by failure distance from the pass threshold.`);
    }
    if (/\bnpm\s+run\s+(dev|start)\b/.test(cmd) || /\bnext\s+dev\b/.test(cmd)) {
      notes.push("Dev-server command detected. Lighthouse results from a dev build are not representative of production; always run `/web-vitals-auditor:lighthouse-audit` against a production build or staging URL.");
    }
    if (/\blhci\s+(collect|autorun|upload)\b/.test(cmd)) {
      notes.push("Lighthouse CI command detected. If the budget failed, `/web-vitals-auditor:budget-generate` can regenerate a reasonable baseline, and `/web-vitals-auditor:vitals-diagnose <report>` tells you which metric regressed.");
    }

    if (notes.length > 0) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: "PostToolUse", additionalContext: notes.join("\n") }
      }));
    }
  } catch (e) {}
  process.exit(0);
});
