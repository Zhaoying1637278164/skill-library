# Changelog

All notable changes to this plugin are documented here.

The format is based on Keep a Changelog, and this plugin uses semantic versioning.

## [1.1.0] - 2026-07-28

### Added

- A self-hosted Claude Code marketplace catalog for persistent GitHub installation.
- Fixture coverage for the PostToolUse hook and Vite config detection.
- Clear macOS and Windows installation paths for marketplace, directory, and ZIP use.

### Changed

- Reworked the README as an install and outcome-focused product guide.
- Corrected the static-server guidance: `.next` is not served as a static build.
- Corrected Chrome guidance: Lighthouse needs an installed or configured Chrome/Chromium binary.
- Hook messages now describe a detected command rather than incorrectly claiming it completed.

### Removed

- Personal email addresses from the plugin manifest, license, and privacy policy.

## [1.0.1] - 2026-04-19

### Added

- `PRIVACY.md` with data-handling disclosure for marketplace submission (Claude Code, local hooks, GitHub hosting, Anthropic product terms).

## [1.0.0] - 2026-04-18

### Added

- Initial release.
- Skill `lighthouse-audit`: run Lighthouse against a URL and summarize Core Web Vitals.
- Skill `vitals-diagnose`: interpret a Lighthouse result and prioritize fixes.
- Skill `budget-generate`: generate a performance-budget.json for Lighthouse CI.
- Skill `bundle-analyze`: analyze a Webpack, Vite, or Rollup build output.
- Skill `image-audit`: scan HTML, JSX, TSX, and Vue files for unoptimized images.
- Skill `font-audit`: detect common font-loading performance issues.
- Agent `perf-forensics`: performance diagnosis specialist.
- Agent `vitals-interpreter`: Lighthouse JSON interpreter.
- Command `doctor`: real toolchain check. Reports Node and npm versions, Lighthouse availability via npx, system Chrome or Chromium version, and which bundler config is present in cwd.
- Hook `session-start`: Node.js detector that inspects cwd for `next.config.*`, `vite.config.*`, `nuxt.config.*`, `webpack.config.*`, `lighthouserc.json`, `performance-budget.json`, or a `lighthouse` entry in `package.json`. Injects a one-line context note so Claude knows which skills apply.
- Command `serve-audit`: one-shot that serves a build directory on a local port with `npx serve`, runs desktop and mobile Lighthouse against it, saves timestamped JSON reports, and stops the server.
- Hook `post-tool-use`: PostToolUse hook that reacts to `npm/pnpm/yarn build`, `next build`, `vite build`, `nuxt build`, `lighthouse`, `lhci collect`, and suggests the next diagnostic or analysis skill.
- Tests: `tests/run.js` with fixture directories that invoke the SessionStart hook against synthetic cwds and assert expected output.
- CI: `.github/workflows/validate.yml` runs required-file checks, plugin.json parse, skill/agent/command frontmatter, hook script syntax, em-dash scan, and the hook fixture tests on every push and PR.
- Reference file `reference/bundler-optimizations.md`: per-library catalog of the biggest bundle-size wins (lodash, moment, MUI, react-icons, Chart.js, D3, AWS SDK, Firebase, and more) plus framework-specific tips for Next.js, Vite, and Webpack. Read by `bundle-analyze` on-demand only.
- Command `full-audit`: opt-in workflow command that chains doctor, lighthouse-audit, vitals-diagnose, bundle-analyze, image-audit, and font-audit into one combined report. Read-only.
