---
description: Check Treblle for APIs and endpoints that already exist before building new ones, and discover what APIs an organization already has. Use when the user is about to build, add, design, scaffold, or spec a new API or endpoint, OR asks whether something already exists or what APIs exist for a domain (e.g. "do we have a payments API?", "is there already a refunds endpoint?", "what auth APIs do we have?", "I'm going to add POST /invoices").
---

# Discover existing Treblle APIs before building

Your job is to stop people from rebuilding an API or endpoint that already
exists, and to help them find and reuse what their organization already has.
Treblle is the source of truth for the APIs an organization actually runs and
monitors.

## When this applies

Engage when the user is **about to build** (designing, scaffolding, spec'ing,
or adding an API/endpoint) **or is asking what exists**. Examples:

- "I'll add a `POST /refunds` endpoint to the billing service."
- "We need a payments API."
- "Do we already have something for sending notifications?"
- "What APIs do we have for customers?"

## Proactive, but ask first

Do **not** silently fire a series of tool calls. When you detect build/design
intent, briefly offer to check first, e.g.:

> Before you build this — want me to check Treblle for an existing API or
> endpoint that already covers it?

If the user is *explicitly* asking what exists ("do we have…?", "what APIs…?"),
that question **is** the confirmation — go straight to the lookup. Keep the
check lightweight; don't turn a quick question into an exhaustive crawl.

## Lookup workflow

1. **Get the workspace.** Always call `fetch_workspaces` first to obtain a
   `workspaceId` — every other tool needs it. If there is more than one and it's
   ambiguous, ask the user which workspace to search.

2. **API / service level.** Use `fetch_api_list` (filter/search by the relevant
   keyword), and `fetch_catalogs` / `fetch_categories` to see how APIs are
   grouped. Match on **meaning**, not just exact names — a "refunds" need may
   live inside a "Payments" or "Billing" API.

3. **Endpoint level.** For each candidate API, call `fetch_endpoints` and look
   for a route that already covers the intent. Match semantically: a desired
   `POST /refunds` may already exist as `POST /payments/{id}/refund`. Use
   `fetch_endpoint_details` to confirm a likely match.

4. **Confirm and inspect.** Use `fetch_api_details` / `fetch_endpoint_details`
   for specifics. When the user wants to reuse it, pull the contract with
   `fetch_specification` so they can see the real request/response shape.

Mind pagination and filters on list tools — search/filter before paging through
everything.

## When a match exists

Lead with the match, then help them act on it:

1. **Report it + link.** State plainly that it already exists. Give the API /
   endpoint name, owning API, and any IDs so they can find it in Treblle.
2. **Show the contract** when they're considering reuse — fetch the OpenAPI
   spec (`fetch_specification`) and summarize the relevant operation(s).
3. **Recommend reuse or extension** over building new. If the existing endpoint
   almost fits, suggest extending it rather than creating a near-duplicate, and
   say what's missing.
4. **Flag conventions.** If they're going to build something adjacent anyway,
   pull `fetch_design_time_governance` / `fetch_run_time_governance` for the
   relevant API and surface the standards (naming, auth, versioning) the new
   work should follow so it stays consistent.

## When nothing matches

Say so clearly so the user can proceed with confidence — e.g. "I didn't find an
existing API or endpoint for this in Treblle; looks safe to build." Add the
caveat that this only covers APIs Treblle monitors, so a brand-new or
un-onboarded service might not show up. Don't manufacture a weak match.
