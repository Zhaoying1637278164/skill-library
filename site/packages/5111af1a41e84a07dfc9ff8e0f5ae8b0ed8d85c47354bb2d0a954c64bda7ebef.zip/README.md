# Treblle plugin for Claude Code

A [Claude Code](https://code.claude.com) plugin that gives Claude **read-only** access to your [Treblle](https://treblle.com) data — APIs, requests, endpoints, customers, incidents, specifications, and governance reports.

Ask things like _"Which endpoints had the most errors this week?"_ or _"Show me the OpenAPI spec for my Payments API."_

This plugin is a thin wrapper around the published [`@treblle/mcp`](https://www.npmjs.com/package/@treblle/mcp) MCP server — Claude Code launches it on demand via `npx`, so there is no global install to manage.

---

## Install

### From the community marketplace

```
/plugin marketplace add anthropics/claude-plugins-community
/plugin install treblle@claude-community
```

After installing, run `/reload-plugins` (or restart Claude Code) to start the server.

---

## Authenticate

**Recommended: sign in with your browser, once.** In your terminal, run:

```bash
npx -y @treblle/mcp login
```

This opens the Treblle login page, captures your token via a localhost redirect, and caches it at `~/.treblle/credentials.json` (`0600`). From then on the plugin reads that cached token on every launch — no environment variables to manage. A cached token is reused until the API rejects it (a `401` clears it), at which point you re-run `login`.

> The server never opens a browser during the MCP handshake — that's why the browser sign-in is a one-time `login` command rather than something that happens when Claude Code starts the server. Run it before (or right after) installing the plugin, then `/reload-plugins`.

**Alternative — Developer Token (CI, agents, headless):** set a long-lived [Developer Token](https://treblle.com) as `TREBLLE_API_TOKEN` in the environment Claude Code runs in. The server inherits it and uses it ahead of any cached login.

If neither a token nor a cached login is present, the server exits immediately with a message telling you to sign in.

---

## Configuration

Set these in the environment Claude Code runs in.

| Variable | Default | Description |
| --- | --- | --- |
| `TREBLLE_API_TOKEN` | — | Developer Token. Takes precedence over cached/browser login. |
| `TREBLLE_BASE_URL` | `https://api.treblle.com` | Treblle Platform API base URL. |
| `TREBLLE_LOGIN_URL` | `https://auth.treblle.com/login` | Browser login page (used only by `login`). |
| `TREBLLE_LOOPBACK_PORT` | `3000` | Loopback port the `login` flow listens on. |
| `TREBLLE_LOGIN_TIMEOUT_MS` | `300000` | How long `login` waits for the browser flow. |

---

## Skills

The plugin ships a skill that Claude invokes automatically — you don't call it directly.

### `api-discovery` — don't rebuild an API that already exists

Before you build a new API or endpoint, Claude checks Treblle for one that already covers it. It triggers both when you're **designing** something ("I'll add a `POST /refunds` endpoint") and when you're **asking** what exists ("do we already have a payments API?").

- **Asks first** on design intent — offers to check Treblle rather than silently running tools. Explicit "does X exist?" questions go straight to the lookup.
- **Searches APIs and endpoints**, matching on meaning, not just names — a wanted `POST /refunds` may already live as `POST /payments/{id}/refund`.
- **On a match:** points you to the existing API/endpoint, shows its OpenAPI contract, recommends reuse or extension over building new, and surfaces the team's governance conventions to follow.
- **On no match:** says so clearly, with the caveat that it only covers APIs Treblle monitors.

You can also invoke it explicitly with `/treblle:api-discovery`.

---

## Tools

All tools are read-only. Call `fetch_workspaces` first to discover your workspaces, then pass the chosen `workspaceId` to every other tool.

| Tool | Description |
| --- | --- |
| `fetch_workspaces` | List workspaces the authenticated user can access. **Start here.** |
| `fetch_api_list` | List APIs in the workspace (filter, sort, paginate). |
| `fetch_api_details` | Full details for a single API by ID. |
| `fetch_api_requests` | Paginated HTTP requests for an API (filter by method, date, threat level, compliance, full-text). |
| `fetch_api_request_details` | Full details of a single request — headers, body, metadata, performance. |
| `fetch_customers` | Paginated customers for an API, with request counts and metrics. |
| `fetch_customer_details` | Full profile and metrics for a single customer by ID. |
| `fetch_categories` | API categories defined in the workspace. |
| `fetch_environments` | Environments in the workspace (Production, Staging, …). |
| `fetch_specification` | Raw content of an OpenAPI specification version by ID. |
| `fetch_endpoints` | List endpoints for an API (filter, sort, paginate). |
| `fetch_endpoint_details` | Full details for a single endpoint by ID. |
| `fetch_catalogs` | List API catalogs in the workspace. |
| `fetch_incidents` | List incidents (problems) for an API. |
| `fetch_incident_details` | Full details for a single incident by ID. |
| `fetch_design_time_governance` | Design-time governance report for an API. |
| `fetch_run_time_governance` | Run-time governance report for an API. |
| `fetch_workspace_people` | List people in the workspace (resolve names/emails to invitation IDs). |

---

## Requirements

- Node.js **>= 20** (Claude Code runs the server via `npx`).

---

## Links

- MCP server package: [`@treblle/mcp`](https://www.npmjs.com/package/@treblle/mcp)
- Treblle: [treblle.com](https://treblle.com)

## License

MIT
