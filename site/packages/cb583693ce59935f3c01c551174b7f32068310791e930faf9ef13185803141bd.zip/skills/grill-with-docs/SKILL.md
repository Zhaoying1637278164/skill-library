---
name: grill-with-docs
description: A relentless interview to sharpen a plan or design, which also creates docs (ADRs and glossary) as we go.
disable-model-invocation: true
argument-hint: "[plan or design]"
license: MIT
---

Call the Skill tool twice, for "grilling" and "domain-modeling".
