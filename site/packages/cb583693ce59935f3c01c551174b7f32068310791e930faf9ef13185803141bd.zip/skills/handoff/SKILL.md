---
name: handoff
description: Write the current conversation into a portable handoff document for another agent to pick up.
argument-hint: "What will the next session be used for?"
disable-model-invocation: true
license: MIT
---

Write a handoff document summarising the current conversation so a fresh agent can continue the work. Save to the temporary directory of the user's OS, outside the current workspace. Tell the user the file's absolute path, so they can open it in the next session or send it on.

Include a "suggested skills" section in the document, naming which skills the next agent should call the Skill tool for. Name a user-invoked skill as an instruction to tell the user to run `/name` (`$name` in Codex).

Do not duplicate content already captured in other artifacts (specs, plans, ADRs, issues, commits, diffs). Reference them by path or URL instead.

Redact any sensitive information, such as API keys, passwords, or personally identifiable information.

If the user passed arguments, treat them as a description of what the next session will focus on and tailor the doc accordingly.
