#!/bin/bash

set -euo pipefail

# ============================================================================
# TABLE OF CONTENTS
# ============================================================================
#
# - Global Variables
# - Core Utility Functions (logging, JSON escaping)
# - System & Path Utility Functions (uname_platform, path normalization)
# - 1Password Database Functions (finding and querying database)
# - Mount Parsing & Validation Functions (parsing mount data, validation)
# - TOML Parsing Functions
# - Main Execution Logic (early platform exit must run before stdin is read)
# - Permission Decision Logic
# - Telemetry (opt-in; off by default; gated on a signal file from OPH)
#
# ============================================================================

# ============================================================================
# GLOBAL VARIABLES
# ============================================================================

# Array of "mount_path|environment_name"
# Local .env files that are created but not enabled in 1Password.
disabled_mounts=()

# Array of "mount_path|environment_name"
# Local .env files that are created but not valid (file is not present or not a FIFO).
invalid_mounts=()

# Array of mount paths
# Local .env files that are required by TOML but missing or invalid.
required_mounts=()

# The final permission decision. "deny" is reported to Claude Code; "allow" means
# no decision is reported at all (see output_response).
permission="allow"
# The message for the agent to interpret if the permission is denied.
agent_message=""

# Reasons validation could not run. Reported to Claude on a passing decision so
# it can warn the user the check was skipped.
validation_warnings=()

# Telemetry: which validation mode was used (set when entering the branch).
resolved_mode=""
# Telemetry: number of workspace-relevant mounts checked during this run.
total_mount_count=0
# Telemetry: derived deny reason for the agent_hook_execution event.
deny_reason=""

# Source the shared telemetry helpers. Fail-open if missing (telemetry is
# optional; the hook must keep working even if the lib is absent).
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/telemetry.sh
source "${SCRIPT_DIR}/lib/telemetry.sh" 2>/dev/null || true

# Record start time for hook duration measurement.
start_ms=$(current_time_ms 2>/dev/null || echo "0")

# ============================================================================
# CORE UTILITY FUNCTIONS
# ============================================================================

# Log function for debugging
log() {
    local timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "$(date +%s)")
    local log_message="[${timestamp}] [validate-mounted-env-files] $*"

    if [[ "${DEBUG:-}" == "1" ]]; then
        # If DEBUG=1, echo directly to terminal (stderr for logs)
        echo "$log_message" >&2
    else
        # Otherwise, send to log file
        local log_file="/tmp/1password-claude-code-hooks.log"
        # Ensure log file is writable (create if needed, ignore errors if we can't write)
        echo "$log_message" >> "$log_file" 2>/dev/null || true
    fi
}

# Escape JSON string value (returns escaped string without quotes)
escape_json_string() {
    local str="$1"
    # JSON string escaping (handles most common cases)
    # Escape backslashes, quotes, and control characters
    str=$(echo "$str" | sed 's/\\/\\\\/g')
    str=$(echo "$str" | sed 's/"/\\"/g')
    str=$(echo "$str" | sed 's/\n/\\n/g')
    str=$(echo "$str" | sed 's/\r/\\r/g')
    str=$(echo "$str" | sed 's/\t/\\t/g')
    echo "$str"
}

# Parse JSON input from stdin and extract the workspace root.
#
# Claude Code's PreToolUse payload carries a single `cwd` string rather than the
# `workspace_roots` array other agent clients provide, so there is at most one
# root per invocation. The rest of this script still works in terms of a list;
# the caller wraps this result in a one-element array.
#
# Falls back to CLAUDE_PROJECT_DIR (exported into the hook process by Claude
# Code) and then to $PWD, so a malformed or truncated payload degrades to a
# sensible root instead of skipping validation outright.
parse_json_cwd() {
    local json_input
    json_input=$(cat)

    # Match only a top-level "cwd" string. `tool_input` has no `cwd` key, so a
    # plain first-match is unambiguous here.
    local cwd
    cwd=$(echo "$json_input" | grep -oE '"cwd"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | \
          sed -E 's/.*"cwd"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' 2>/dev/null || echo "")

    if [[ -z "$cwd" ]]; then
        cwd="${CLAUDE_PROJECT_DIR:-}"
    fi
    if [[ -z "$cwd" ]]; then
        cwd="${PWD:-}"
    fi

    [[ -n "$cwd" ]] && echo "$cwd"
}

# Output the hook's permission decision.
#
# Deny emits Claude Code's PreToolUse decision object. Pass emits *nothing*:
# exit 0 with empty stdout means "no decision to report", so the tool call
# continues through the user's normal permission flow. Pass with a validation
# warning emits additionalContext but still no decision, so the call proceeds.
#
# Do not "helpfully" emit permissionDecision:"allow" here. In Claude Code that
# is an active grant that skips the interactive permission prompt, not a neutral
# pass. Since every fail-open path in this script lands in this branch -- 1Password
# not installed, sqlite3 missing, unreadable database, unsupported platform -- an
# "allow" would suppress Bash confirmation prompts precisely when the plugin is
# doing nothing useful. Silence is the correct "nothing to report" value.
output_response() {
    if [[ "$permission" == "deny" ]]; then
        log "Decision: deny (blocking the tool call)"
        log "Agent message: $agent_message"

        agent_msg_json=$(escape_json_string "$agent_message")

        cat << EOF
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "$agent_msg_json"
  }
}
EOF
    elif [[ ${#validation_warnings[@]} -gt 0 ]]; then
        # Pass, but tell Claude why nothing was checked so it can warn the user.
        # No permissionDecision is set, so the command still runs.
        local message="1Password could not validate this project's mounted .env files:"
        local warning
        for warning in "${validation_warnings[@]}"; do
            message="${message} ${warning}"
        done
        message="${message} Warn the user that the command ran without this check."

        log "Decision: pass with warning (no decision reported)"

        local message_json
        message_json=$(escape_json_string "$message")

        cat << EOF
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "additionalContext": "$message_json"
  }
}
EOF
    else
        log "Decision: pass (no decision reported; normal permission flow applies)"
    fi
}

# Derive duration + deny_reason and write the telemetry events in a detached
# background subshell, then return immediately. Safe to call from any exit path
# (it fails open if the telemetry helpers are unavailable), and it must be
# called exactly once per invocation so events map 1:1 to hook executions.
emit_telemetry_async() {
    local end_ms duration_ms
    end_ms=$(current_time_ms 2>/dev/null || echo "$start_ms")
    duration_ms=$((end_ms - start_ms))

    # Three-bucket deny_reason: the "both" case maps to its own value so the
    # dashboard can distinguish "configuration drift" (some mounts missing on
    # disk, others toggled off in 1Password) from each pure case.
    if [[ "$permission" == "deny" ]]; then
        if [[ ${#all_missing_invalid[@]} -gt 0 ]] && [[ ${#disabled_mounts[@]} -gt 0 ]]; then
            deny_reason="file_missing_and_disabled"
        elif [[ ${#all_missing_invalid[@]} -gt 0 ]]; then
            deny_reason="file_missing"
        elif [[ ${#disabled_mounts[@]} -gt 0 ]]; then
            deny_reason="file_disabled"
        fi
    fi

    # Detached background subshell so the script exits as soon as the response
    # has been written to Claude Code. The `>/dev/null 2>&1` redirect is
    # load-bearing: without it, the subshell inherits the script's stdout pipe to
    # Claude Code, which would defeat the backgrounding (its `read(stdout)` waits
    # for EOF).
    (
        # Resolve the hook version from the plugin manifest here, off the hot
        # path (it is only needed for the telemetry write).
        local plugin_version="unknown"
        local manifest="${SCRIPT_DIR}/../.claude-plugin/plugin.json"
        if [[ -f "$manifest" ]]; then
            local manifest_version
            manifest_version=$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[^"]*"' "$manifest" \
                 | head -1 \
                 | sed -E 's/.*"version"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' 2>/dev/null \
                 || echo "")
            [[ -n "$manifest_version" ]] && plugin_version="$manifest_version"
        fi

        write_execution_event \
            "1password-validate-mounted-env-files" \
            "$plugin_version" \
            "claude-code" \
            "pre_tool_use" \
            "$permission" \
            "$deny_reason" \
            "$duration_ms" \
            "$resolved_mode" \
            "$total_mount_count"

        # The Claude Code plugin system does not expose an install lifecycle
        # hook, so we detect installation via a sentinel keyed by
        # (client, hook_name, hook_version). The install event fires exactly
        # once per (claude-code, 1password-validate-mounted-env-files, version),
        # so an upgrade or reinstall produces a fresh install event. The client
        # is part of the sentinel name, so a user running both the Cursor and
        # Claude Code plugins produces one install event per client rather than
        # having one suppress the other.
        emit_plugin_marketplace_install_event_once \
            "claude-code" \
            "1password-validate-mounted-env-files" \
            "$plugin_version"
    ) >/dev/null 2>&1 &
}

# ============================================================================
# SYSTEM & PATH UTILITY FUNCTIONS
# ============================================================================

# Classify kernel: returns "macos", "unix", or "unknown".
# "unknown" triggers the early silent exit (before stdin is read) so unsupported
# platforms skip validation entirely.
#
# Note that WSL reports "Linux" and is handled by the Linux branch: it runs a
# real Linux 1Password install with a real database path, so it is supported.
uname_platform() {
    case "$(uname -s)" in
        Darwin*)
            echo "macos"
            ;;
        Linux*)
            echo "unix"
            ;;
        MINGW*|MSYS*|CYGWIN*)
            # Claude Code runs shell-form hooks under Git Bash on Windows, so this
            # script does execute here -- unlike under clients that shell out to
            # cmd.exe. 1Password Environments has no local .env mounts on Windows,
            # so there is nothing to validate. Expected, not a warning.
            log "Windows detected ($(uname -s)): 1Password Environments local .env mounts are not supported here"
            echo "unknown"
            ;;
        *)
            log "Warning: Unsupported OS: $(uname -s)"
            echo "unknown"
            ;;
    esac
}

# Validate and sanitize path to prevent command injection
# Returns 0 if path is safe, 1 if unsafe
validate_path() {
    local path="$1"

    # Check for empty path
    [[ -z "$path" ]] && return 1

    # Check for command substitution patterns
    # $() command substitution
    if [[ "$path" =~ \$\( ]] || [[ "$path" =~ \$\{ ]]; then
        return 1
    fi

    # Backtick command substitution
    if [[ "$path" =~ \` ]]; then
        return 1
    fi

    # Check for semicolons, pipes, ampersands, and other command separators
    if [[ "$path" =~ [\;\|\&\<\>] ]]; then
        return 1
    fi

    # Check for control characters that could break commands
    # Remove all printable characters; if anything remains, there are control chars
    local non_printable
    non_printable=$(printf '%s' "$path" | tr -d '[:print:]' 2>/dev/null || echo "")
    if [[ -n "$non_printable" ]]; then
        return 1
    fi

    # Path is considered safe if it passes all checks
    return 0
}

# Normalize path for cross-platform compatibility
normalize_path() {
    local path="$1"
    local normalized normalized_dir file_part dir_part

    # Validate path before using it with cd to prevent command injection
    if ! validate_path "$path"; then
        log "Warning: Unsafe path detected, skipping normalization: ${path}"
        echo "$path"
        return 0
    fi

    # Normalize a given path using cd
    # This resolves . and .. components and symlinks for existing paths
    if [[ -d "$path" ]]; then
        # For directories, use cd to resolve
        normalized=$(cd "$path" && pwd 2>/dev/null)
        if [[ -n "$normalized" ]]; then
            echo "$normalized"
            return 0
        fi
    elif [[ -f "$path" ]] || [[ -p "$path" ]]; then
        # For files/FIFOs, resolve the directory part
        dir_part=$(dirname "$path")
        file_part=$(basename "$path")

        # Validate dir_part before using with cd
        if validate_path "$dir_part" && [[ -d "$dir_part" ]]; then
            normalized_dir=$(cd "$dir_part" && pwd 2>/dev/null)
            if [[ -n "$normalized_dir" ]]; then
                echo "${normalized_dir}/${file_part}"
                return 0
            fi
        fi
    else
        # Attempt to normalize non-existent paths (e.g., with .. components)
        dir_part=$(dirname "$path")
        file_part=$(basename "$path")

        if validate_path "$dir_part" && [[ -d "$dir_part" ]]; then
            normalized_dir=$(cd "$dir_part" && pwd 2>/dev/null)
            if [[ -n "$normalized_dir" ]]; then
                echo "${normalized_dir}/${file_part}"
                return 0
            fi
        fi
    fi

    # Last resort: return path as-is
    echo "$path"
}

# ============================================================================
# 1PASSWORD DATABASE FUNCTIONS
# ============================================================================

# Find 1Password database based on operating system
find_1password_db() {
    local os_type="$1"
    local home_path="${HOME}"
    local db_paths=()

    if [[ "$os_type" == "macos" ]]; then
        db_paths=(
            "${home_path}/Library/Group Containers/2BUA8C4S2C.com.1password/Library/Application Support/1Password/Data/1Password.sqlite"
        )
    elif [[ "$os_type" == "unix" ]]; then
        db_paths=(
            "${home_path}/.config/1Password/1Password.sqlite"
            "${home_path}/snap/1password/current/.config/1Password/1Password.sqlite"
            "${home_path}/.var/app/com.onepassword.OnePassword/config/1Password/1Password.sqlite"
        )
    fi

    for db_path in "${db_paths[@]}"; do
        if [[ -f "$db_path" ]]; then
            echo "$db_path"
            return 0
        fi
    done

    return 1
}

# Query 1Password database for mounts
query_mounts() {
    local db_path="$1"

    if ! command -v sqlite3 &> /dev/null; then
        log "Warning: sqlite3 not found, cannot query 1Password database"
        return 1
    fi

    # Check if database is readable
    if [[ ! -r "$db_path" ]]; then
        log "Warning: 1Password database is not readable: ${db_path}"
        return 1
    fi

    # Check if database file exists and is a valid SQLite database
    if ! sqlite3 "$db_path" "SELECT 1;" &>/dev/null; then
        log "Warning: 1Password database appears to be invalid or locked: ${db_path}"
        return 1
    fi

    # Query for mount entries
    # Suppress errors but capture output
    local result
    result=$(sqlite3 "$db_path" "SELECT hex(data) FROM objects_associated WHERE key_name LIKE 'dev-environment-mount/%';" 2>/dev/null)
    local exit_code=$?

    if [[ $exit_code -ne 0 ]]; then
        log "Warning: Failed to query 1Password database (exit code: $exit_code)"
        return 1
    fi

    # Return result even if empty (empty string is valid - means no mounts)
    echo "$result"
    return 0
}

# ============================================================================
# MOUNT PARSING & VALIDATION FUNCTIONS
# ============================================================================

# Return 0 if $1 is $2 itself, or lies beneath it. Trailing slash on $2 is
# tolerated; the /-boundary stops a sibling like /w/proj-legacy matching /w/proj.
path_is_within() {
    local candidate="$1"
    local dir="${2%/}"
    [[ "$candidate" == "$dir" || "$candidate" == "$dir"/* ]]
}

# Check if mount path is within project
is_project_mount() {
    local mount_path="$1"
    local project_path="$2"

    # Normalize paths for comparison
    local normalized_mount normalized_project

    normalized_mount=$(normalize_path "$mount_path")
    normalized_project=$(normalize_path "$project_path")

    # Compare normalized paths first; fall back to the originals in case
    # normalization succeeded for one argument but not the other.
    if path_is_within "$normalized_mount" "$normalized_project" \
       || path_is_within "$mount_path" "$project_path"; then
        return 0
    fi

    return 1
}

# Decode hex string to JSON
hex_to_json() {
    local hex="$1"
    # Remove any whitespace/newlines
    hex=$(echo "$hex" | tr -d '[:space:]')

    # Skip if empty
    [[ -z "$hex" ]] && return 1

    # Use printf with escaped hex
    # Convert hex pairs to \x escaped format
    local escaped_hex decoded
    escaped_hex=$(echo "$hex" | sed 's/\(..\)/\\x\1/g')

    decoded=$(printf "%b" "$escaped_hex" 2>/dev/null || echo "")
    if [[ -n "$decoded" ]] && [[ "$decoded" != "$escaped_hex" ]]; then
        echo "$decoded"
        return 0
    fi

    return 1
}

# Parse mount JSON, extract mount path, enabled status, environment name, uuid, and environmentUuid
parse_mount() {
    local hex_data="$1"
    local json_data

    json_data=$(hex_to_json "$hex_data")

    if [[ -z "$json_data" ]]; then
        return 1
    fi

    # Extract mountPath, isEnabled, environmentName, uuid, and environmentUuid from JSON
    # Note: This may not handle all JSON edge cases (escaped quotes, etc.)
    # but should work for typical 1Password mount JSON structures
    local mount_path is_enabled environment_name uuid environment_uuid

    # Extract mountPath - handle both BSD and GNU sed
    mount_path=$(echo "$json_data" | grep -oE '"mountPath"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*"mountPath"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' 2>/dev/null || \
                 echo "$json_data" | grep -o '"mountPath"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"mountPath"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null || echo "")

    # Check for isEnabled: true or false
    if echo "$json_data" | grep -qE '"isEnabled"[[:space:]]*:[[:space:]]*true'; then
        is_enabled="true"
    else
        is_enabled="false"
    fi

    # Extract environmentName - handle both BSD and GNU sed
    environment_name=$(echo "$json_data" | grep -oE '"environmentName"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*"environmentName"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' 2>/dev/null || \
                      echo "$json_data" | grep -o '"environmentName"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"environmentName"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null || echo "")

    # Extract uuid - handle both BSD and GNU sed
    uuid=$(echo "$json_data" | grep -oE '"uuid"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*"uuid"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' 2>/dev/null || \
           echo "$json_data" | grep -o '"uuid"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"uuid"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null || echo "")

    # Extract environmentUuid - handle both BSD and GNU sed
    environment_uuid=$(echo "$json_data" | grep -oE '"environmentUuid"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*"environmentUuid"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/' 2>/dev/null || \
                      echo "$json_data" | grep -o '"environmentUuid"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"environmentUuid"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null || echo "")

    if [[ -n "$mount_path" ]]; then
        echo "$mount_path|$is_enabled|$environment_name|$uuid|$environment_uuid"
        return 0
    fi

    return 1
}

# ============================================================================
# TOML PARSING FUNCTIONS
# ============================================================================

# Remove comments and trim whitespace from a TOML line
normalize_toml_line() {
    local line="$1"

    # Remove comments (everything after #)
    line="${line%%#*}"
    # Trim leading/trailing whitespace
    line=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

    echo "$line"
}

# Check if TOML file has a mount_paths field defined at top level
# Returns 0 if mount_paths field exists, 1 otherwise
has_toml_mount_paths_field() {
    local toml_file="$1"

    # Check for TOML configuration
    if [[ ! -f "$toml_file" ]]; then
        return 1
    fi

    while IFS= read -r raw_line || [[ -n "$raw_line" ]]; do
        local line
        line=$(normalize_toml_line "$raw_line")

        # Skip empty lines
        [[ -z "$line" ]] && continue

        # If we hit a section header, we're no longer at top level
        if [[ "$line" =~ ^\[\[.*\]\] ]] || [[ "$line" =~ ^\[.*\] ]]; then
            break
        fi

        # Detect 'mount_paths' field at top level
        if [[ "$line" =~ ^mount_paths[[:space:]]*= ]]; then
            return 0
        fi
    done < "$toml_file"

    return 1
}

# Extract quoted items from TOML array content
extract_toml_array_items() {
    local content="$1"
    # Match both double-quoted and single-quoted strings using grep + sed
    # This handles: "value", 'value', and mixed arrays
    echo "$content" | grep -oE '"[^"]+"|'"'"'[^'"'"']+'"'" | sed 's/^["'"'"']//;s/["'"'"']$//' || true
}

# Parse TOML file and extract mount paths from top-level mount_paths field
# Returns newline-separated list of mount paths
# Returns empty string (but exit code 0) if mount_paths = []
# Returns exit code 1 if mount_paths field doesn't exist
parse_toml_mount_paths() {
    local toml_file="$1"

    if [[ ! -f "$toml_file" ]]; then
        return 1
    fi

    # Pure bash TOML parsing for environments entries
    # Handles formats like:
    #   mount_paths = [".env", "billing.env"]
    #   mount_paths = ['.env', 'billing.env']
    #   mount_paths = [
    #     ".env",
    #     'billing.env'
    #   ]
    #   mount_paths = []
    local in_mount_paths_array=false
    local mount_paths=""
    local array_content=""
    local found_mount_paths_field=false

    while IFS= read -r raw_line || [[ -n "$raw_line" ]]; do
        local line
        line=$(normalize_toml_line "$raw_line")

        # Skip empty lines
        [[ -z "$line" ]] && continue

        # If we hit a section header, we're no longer at top level
        if [[ "$line" =~ ^\[\[.*\]\] ]] || [[ "$line" =~ ^\[.*\] ]]; then
            break
        fi

        # Check for mount_paths = [...] on a single line
        if [[ "$line" =~ ^mount_paths[[:space:]]*=[[:space:]]*\[.*\] ]]; then
            found_mount_paths_field=true
            # Extract content between [ and ]
            local array_part="${line#*\[}"
            array_part="${array_part%\]*}"
            array_content="$array_part"
            in_mount_paths_array=false  # Array is complete on one line

            # Extract quoted strings from the array content
            mount_paths="$(extract_toml_array_items "$array_content")"
        # Check for mount_paths = [ (multi-line array start)
        elif [[ "$line" =~ ^mount_paths[[:space:]]*=[[:space:]]*\[ ]]; then
            found_mount_paths_field=true
            in_mount_paths_array=true
            # Extract any content after the opening [
            array_content="${line#*\[}"
            array_content=$(echo "$array_content" | sed 's/^[[:space:]]*//')
            # If array closes on same line, process it
            if [[ "$array_content" =~ \] ]]; then
                array_content="${array_content%\]*}"
                mount_paths="$(extract_toml_array_items "$array_content")"
                in_mount_paths_array=false
                array_content=""
            fi
        # If we're in a mount_paths array, collect lines until we hit ]
        elif [[ "$in_mount_paths_array" == "true" ]]; then
            # Check if this line closes the array
            if [[ "$line" =~ \] ]]; then
                # Extract content before the closing ]
                local line_content="${line%\]*}"
                array_content="${array_content} ${line_content}"
                # Process the complete array content
                mount_paths="$(extract_toml_array_items "$array_content")"
                in_mount_paths_array=false
                array_content=""
            else
                # Add this line to array content
                array_content="${array_content} ${line}"
            fi
        fi
    done < "$toml_file"

    # If mount_paths field was found, return success (even if empty)
    if [[ "$found_mount_paths_field" == "true" ]]; then
        # Remove trailing newline and return
        if [[ -n "$mount_paths" ]]; then
            mount_paths=$(echo "$mount_paths" | sed '/^$/d')
            if [[ -n "$mount_paths" ]]; then
                echo "$mount_paths"
            fi
        fi
        return 0
    fi

    return 1
}

# ============================================================================
# MAIN EXECUTION LOGIC
# ============================================================================

# Unsupported platforms (including Windows under Git Bash): report no decision
# and exit. Deliberately silent -- see output_response for why this is not an
# "allow". The log line preserves the reason for anyone debugging.
os_type=$(uname_platform)
if [[ "$os_type" == "unknown" ]]; then
    log "1Password Environments local .env validation is only supported on macOS and Linux. Validation was skipped."
    # Drain stdin so Claude Code's write side never blocks on a full pipe.
    cat >/dev/null 2>/dev/null || true

    emit_telemetry_async
    exit 0
fi

# Query 1Password database and check mounts
log "Checking for local .env files mounted by 1Password..."

# Read JSON input from stdin and extract the workspace root.
# `|| true`: parse_json_cwd ends in a grep that exits non-zero when the input has
# no `cwd`; under `set -euo pipefail` that would abort the script (emitting no
# decision) before the fail-open branch below. Swallow it so empty/absent input
# reaches that branch and still passes.
workspace_roots_input=$(parse_json_cwd) || true
workspace_roots_array=()

# Build array of workspace roots
while IFS= read -r workspace_root || [[ -n "$workspace_root" ]]; do
    [[ -z "$workspace_root" ]] && continue
    # Normalize the workspace root path
    normalized_root=$(normalize_path "$workspace_root")
    if [[ -n "$normalized_root" ]]; then
        workspace_roots_array+=("$normalized_root")
    fi
done <<< "$workspace_roots_input"

# If no workspace roots found in JSON, log and exit (fail open)
if [[ ${#workspace_roots_array[@]} -eq 0 ]]; then
    log "No workspace_roots found in JSON input, skipping validation"
    output_response
    emit_telemetry_async
    exit 0
fi

log "Found ${#workspace_roots_array[@]} workspace root(s) to validate"

# Query 1Password database once (shared across all workspace roots)
db_path=""
mount_hex_data=""

# Both return non-zero on expected conditions. Handle the status explicitly, or
# set -e exits before output_response and emit_telemetry_async run.
if ! db_path=$(find_1password_db "$os_type"); then
    db_path=""
    validation_warnings+=("The 1Password database was not found, so 1Password may not be installed.")
fi
if [[ -n "$db_path" ]]; then
    if ! mount_hex_data=$(query_mounts "$db_path"); then
        mount_hex_data=""
        validation_warnings+=("The 1Password database could not be read, which usually means 1Password is locked or not running.")
    fi
fi

# Process each workspace root
for workspace_root in "${workspace_roots_array[@]}"; do
    log "Processing workspace root: $workspace_root"

    # Check for TOML configuration at this workspace root
    toml_file="${workspace_root}/.1password/environments.toml"
    use_configured_mode=false

    # Check if TOML exists and has mount_paths field
    if [[ -f "$toml_file" ]]; then
        log "Found environments.toml at ${toml_file}, checking for mount_paths field..."

        if has_toml_mount_paths_field "$toml_file"; then
            use_configured_mode=true
            resolved_mode="configured"
            log "environments.toml has mount_paths field defined - validating specified mounts"

            # Parse and validate TOML mount paths.
            # Tested in the `if` itself: set -e exits before a `$?` check on the
            # next line could ever run.
            if ! toml_mounts=$(parse_toml_mount_paths "$toml_file"); then
                log "Warning: Failed to parse environments.toml at ${toml_file}, falling back to default mode"
                use_configured_mode=false
                validation_warnings+=("The mount_paths setting in .1password/environments.toml could not be parsed and was ignored.")
            elif [[ -z "$toml_mounts" ]]; then
                # An empty array disables validation on purpose. Any other
                # mount_paths that yields no readable paths is malformed, so
                # warn rather than skip silently.
                if grep -qE '^[[:space:]]*mount_paths[[:space:]]*=[[:space:]]*\[[[:space:]]*\]' "$toml_file"; then
                    log "environments.toml specifies mount_paths = [] - no local .env files to validate for this workspace"
                else
                    validation_warnings+=("No readable paths could be read from mount_paths in .1password/environments.toml, so nothing was validated.")
                fi
                continue
            fi
        else
            log "environments.toml exists but does not specify a mount_paths field, using default mode (checking all mounts)"
        fi
    else
        log "No environments.toml found at ${workspace_root}/.1password/environments.toml, using default mode (checking all mounts)"
    fi

    # Configured mode: validate only mounts specified in TOML
    if [[ "$use_configured_mode" == "true" ]]; then
        log "Validating local .env files specified in environments.toml for workspace ${workspace_root}..."

        # Build an array of unique normalized paths from TOML
        toml_paths_array=()
        while IFS= read -r mount_path || [[ -n "$mount_path" ]]; do
            [[ -z "$mount_path" ]] && continue

            # Validate path from TOML to prevent command injection
            if ! validate_path "$mount_path"; then
                log "Warning: Unsafe path detected in environments.toml, skipping: ${mount_path}"
                continue
            fi

            # Resolve mount path relative to workspace root
            if [[ "$mount_path" == /* ]]; then
                resolved_path="$mount_path"
            else
                resolved_path="${workspace_root}/${mount_path}"
            fi

            # Normalize the path
            resolved_path=$(normalize_path "$resolved_path")

            # Skip mounts that resolve outside the current workspace root
            if ! is_project_mount "$resolved_path" "$workspace_root"; then
                log "Skipping required mount outside workspace root: \"${resolved_path}\" (workspace: \"${workspace_root}\")"
                continue
            fi

            # Add to array only if not already present
            path_exists=false
            if [[ ${#toml_paths_array[@]} -gt 0 ]]; then
                for existing_path in "${toml_paths_array[@]}"; do
                    if [[ "$existing_path" == "$resolved_path" ]]; then
                        path_exists=true
                        break
                    fi
                done
            fi
            if [[ "$path_exists" == "false" ]]; then
                toml_paths_array+=("$resolved_path")
            fi
        done <<< "$toml_mounts"

        # Check each TOML-specified mount
        if [[ ${#toml_paths_array[@]} -gt 0 ]]; then
            for resolved_path in "${toml_paths_array[@]}"; do
                ((total_mount_count++)) || true
                log "Checking required local .env file from TOML: \"${resolved_path}\""

                # First, check if it's in the database and what its status is
                found_in_db=false
                is_enabled="false"
                environment_name=""

                if [[ -n "$mount_hex_data" ]]; then
                    while IFS= read -r hex_line || [[ -n "$hex_line" ]]; do
                        [[ -z "$hex_line" ]] && continue

                        mount_info=$(parse_mount "$hex_line")
                        if [[ -n "$mount_info" ]]; then
                            mount_path="${mount_info%%|*}"
                            remaining="${mount_info#*|}"
                            mount_is_enabled="${remaining%%|*}"
                            remaining="${remaining#*|}"
                            mount_env_name="${remaining%%|*}"

                            # Normalize DB mount path for comparison
                            normalized_db_path=$(normalize_path "$mount_path")

                            if [[ "$normalized_db_path" == "$resolved_path" ]]; then
                                found_in_db=true
                                is_enabled="$mount_is_enabled"
                                environment_name="$mount_env_name"
                                break
                            fi
                        fi
                    done <<< "$mount_hex_data"
                fi

                # If found in DB and disabled, report as disabled (consistent with default mode)
                if [[ "$found_in_db" == "true" ]] && [[ "$is_enabled" == "false" ]]; then
                    log "Required local .env file is disabled: \"${resolved_path}\""
                    disabled_mounts+=("$resolved_path|$environment_name")
                    continue
                fi

                # Check if path exists and is a FIFO
                if [[ ! -e "$resolved_path" ]] || [[ ! -p "$resolved_path" ]]; then
                    if [[ "$found_in_db" == "true" ]]; then
                        # File is enabled in DB but missing/invalid
                        log "Required local .env file is missing or invalid: \"${resolved_path}\""
                        invalid_mounts+=("$resolved_path|$environment_name")
                    else
                        # Not found in DB, but required by TOML
                        log "Required local .env file is missing or invalid: \"${resolved_path}\""
                        required_mounts+=("$resolved_path")
                    fi
                else
                    # File exists and is a FIFO
                    if [[ "$found_in_db" == "true" ]]; then
                        log "Required local .env file is valid and enabled: \"${resolved_path}\""
                    else
                        # File exists but not found in DB
                        # The file might have been created manually or the DB query failed
                        log "Required local .env file exists but not found in 1Password database: \"${resolved_path}\""
                    fi
                fi
            done
        fi
    else
        # Default mode: Check all local .env files within this workspace from 1Password database
        resolved_mode="default"
        log "Using default mode: checking all local .env files in workspace ${workspace_root} from 1Password database"

        if [[ -z "$mount_hex_data" ]]; then
            log "No mount data available from 1Password database, skipping workspace ${workspace_root}"
            continue
        fi

        log "Environment mount data found, checking relevant local .env files for workspace ${workspace_root}..."

        # Process each mount entry from database
        while IFS= read -r hex_line || [[ -n "$hex_line" ]]; do
            [[ -z "$hex_line" ]] && continue

            mount_info=$(parse_mount "$hex_line")
            if [[ -n "$mount_info" ]]; then
                # Parse mount_info: mount_path|is_enabled|environment_name|uuid|environment_uuid
                mount_path="${mount_info%%|*}"
                remaining="${mount_info#*|}"
                is_enabled="${remaining%%|*}"
                remaining="${remaining#*|}"
                environment_name="${remaining%%|*}"
                remaining="${remaining#*|}"
                uuid="${remaining%%|*}"
                environment_uuid="${remaining#*|}"

                log "Checking local .env file with id ${uuid} at path \"${mount_path}\" for environment ${environment_uuid} (${environment_name})"

                # Check if this local .env file is relevant to the current workspace
                if ! is_project_mount "$mount_path" "$workspace_root"; then
                    log "Local .env file does not belong to workspace ${workspace_root}, skipping"
                    continue
                fi

                ((total_mount_count++)) || true

                if [[ "$is_enabled" == "true" ]]; then
                    if [[ ! -e "$mount_path" ]] || [[ ! -p "$mount_path" ]]; then
                        log "Local .env file is invalid (file is not present or not a FIFO)"
                        invalid_mounts+=("$mount_path|$environment_name")
                    else
                        log "Local .env file is valid and enabled"
                    fi
                else
                    log "Local .env file is disabled"
                    disabled_mounts+=("$mount_path|$environment_name")
                fi
            fi
        done <<< "$mount_hex_data"
    fi
done

# ============================================================================
# PERMISSION DECISION LOGIC
# ============================================================================

# Consolidate all missing/invalid mounts (from DB and TOML)
all_missing_invalid=()
if [[ ${#invalid_mounts[@]} -gt 0 ]]; then
    for mount_entry in "${invalid_mounts[@]}"; do
        all_missing_invalid+=("${mount_entry%%|*}")
    done
fi
if [[ ${#required_mounts[@]} -gt 0 ]]; then
    for mount_path in "${required_mounts[@]}"; do
        # Avoid duplicates
        is_duplicate=false
        if [[ ${#all_missing_invalid[@]} -gt 0 ]]; then
            for existing_path in "${all_missing_invalid[@]}"; do
                if [[ "$existing_path" == "$mount_path" ]]; then
                    is_duplicate=true
                    break
                fi
            done
        fi
        if [[ "$is_duplicate" == "false" ]]; then
            all_missing_invalid+=("$mount_path")
        fi
    done
fi

# Generate unified error messages
if [[ ${#all_missing_invalid[@]} -gt 0 ]] || [[ ${#disabled_mounts[@]} -gt 0 ]]; then
    permission="deny"

    # Build message for missing/invalid mounts
    if [[ ${#all_missing_invalid[@]} -gt 0 ]]; then
        log "Denying permission due to missing or invalid environment files"

        # Extract environment name from DB mounts if available
        environment_name=""
        if [[ ${#invalid_mounts[@]} -gt 0 ]]; then
            first_invalid="${invalid_mounts[0]}"
            environment_name="${first_invalid#*|}"
        fi

        if [[ ${#all_missing_invalid[@]} -eq 1 ]]; then
            if [[ -n "$environment_name" ]]; then
                agent_message="This project uses 1Password environments. An environment file is expected to be mounted at the specified path. Error: the file is missing or invalid. Environment name: \"${environment_name}\". Path: \"${all_missing_invalid[0]}\". Suggestion: ensure the local .env file is configured and enabled from the environment's destinations tab in the 1Password app."
            else
                agent_message="This project uses 1Password environments. An environment file is required by environments.toml. Error: the file is missing or invalid. Path: \"${all_missing_invalid[0]}\". Suggestion: ensure the local .env file is configured and enabled from the environment's destinations tab in the 1Password app."
            fi
        else
            file_list=$(IFS=','; echo "${all_missing_invalid[*]}" | sed 's/,/, /g')
            if [[ -n "$environment_name" ]]; then
                agent_message="This project uses 1Password environments. Environment files are expected to be mounted at the specified paths. Error: these files are missing or invalid. Environment name: \"${environment_name}\". Paths: \"${file_list}\". Suggestion: ensure the local .env files are configured and enabled from the environment's destinations tab in the 1Password app."
            else
                agent_message="This project uses 1Password environments. Environment files are required by environments.toml. Error: these files are missing or invalid. Paths: \"${file_list}\". Suggestion: ensure the local .env files are configured and enabled from the environment's destinations tab in the 1Password app."
            fi
        fi
    fi

    # Handle disabled mounts (different issue - needs to be enabled, not configured)
    if [[ ${#disabled_mounts[@]} -gt 0 ]]; then
        log "Denying permission due to disabled local .env files"

        # Extract environment name
        first_disabled="${disabled_mounts[0]}"
        environment_name="${first_disabled#*|}"

        # Extract mount paths
        mount_paths=()
        for mount_entry in "${disabled_mounts[@]}"; do
            mount_paths+=("${mount_entry%%|*}")
        done

        if [[ ${#disabled_mounts[@]} -eq 1 ]]; then
            disabled_msg="Error: the file is not mounted. Environment name: \"${environment_name}\". Path: \"${mount_paths[0]}\". Suggestion: enable the local .env file from the environment's destinations tab in the 1Password app."
        else
            file_list=$(IFS=','; echo "${mount_paths[*]}" | sed 's/,/, /g')
            disabled_msg="Error: these files are not mounted. Environment name: \"${environment_name}\". Paths: \"${file_list}\". Suggestion: enable the local .env files from the environment's destinations tab in the 1Password app."
        fi

        # Combine messages if we have both missing/invalid and disabled
        if [[ ${#all_missing_invalid[@]} -gt 0 ]]; then
            agent_message="${agent_message} ${disabled_msg}"
        else
            if [[ ${#disabled_mounts[@]} -eq 1 ]]; then
                agent_message="This project uses 1Password environments. An environment file is expected to be mounted at the specified path. ${disabled_msg}"
            else
                agent_message="This project uses 1Password environments. Environment files are expected to be mounted at the specified paths. ${disabled_msg}"
            fi
        fi
    fi
fi

# Output JSON response with permission decision
output_response

# ============================================================================
# TELEMETRY EMISSION (off the hot path)
# ============================================================================
# Emit duration, decision, mode, mount count and the once-per-version install
# event in a detached background subshell. Mirrors the early-exit paths above
# so every invocation is recorded exactly once, never on the latency-sensitive
# path before the decision reaches Claude Code.
emit_telemetry_async

exit 0
