# Claistore for Claude

Claistore connects Claude to authenticated WordPress, WooCommerce, and Shopify stores through the Model Context Protocol (MCP). It combines governed store tools with reusable skills for content, SEO, catalog, order, customer, and reporting workflows.

## Capabilities

- Audit and manage WordPress posts, pages, media, categories, tags, and SEO metadata.
- Review and operate WooCommerce products, inventory, orders, customers, coupons, and reports.
- Review Shopify products, inventory, orders, customers, and SEO data through the GraphQL Admin API.
- Apply reusable workflows for content cleanup, publishing, internal linking, order triage, catalog synchronization, and sales summaries.
- Keep credentials on Claistore's server and record authenticated operations in the workspace activity ledger.

## Installation

Install from the Claude community marketplace after approval:

```text
/plugin marketplace add anthropics/claude-plugins-community
/plugin install claistore@claude-community
```

For local testing:

```text
claude --plugin-dir ./claistore-claude-plugin
```

## Connect Claistore

1. Create or sign in to a Claistore workspace at [claistore.com](https://claistore.com).
2. Connect a WordPress, WooCommerce, or Shopify store from the Claistore Connections page.
3. In Claude Code, open `/mcp` and authenticate the `claistore` server with OAuth.
4. Ask Claude to inspect available connections before running a workflow.

Read operations can retrieve live store data. Write operations require the relevant workspace and connector permissions. Skills instruct Claude to inspect current records and request confirmation before consequential changes.

## Included skills

- Abandoned draft cleanup
- Broken content audit
- Bulk SEO publishing
- Category and tag cleanup
- Content refresh
- Customer insights
- Daily order triage
- FAQ page generation
- Featured image backfill
- Governed MCP access
- Internal linking pass
- Keyword article series
- Low-stock alert
- Meta-description backfill
- New-product announcement
- Order-status updates
- Price-drop campaign
- Product catalog synchronization
- SEO content writing
- Weekly blog calendar
- Weekly sales summary

## Security

This repository contains only the public Claude plugin package. It contains no Claistore application source, customer credentials, OAuth secrets, Firebase credentials, or store access tokens.

Review the [Claistore privacy policy](https://claistore.com/privacy) and [terms](https://claistore.com/terms) before connecting a production store.

## Support

Visit [claistore.com/support](https://claistore.com/support).

## License

MIT
