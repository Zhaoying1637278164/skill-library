---
name: content-refresh
description: Update and re-optimize aging posts. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Content refresh

## Workflow

Using Claistore, posts.list the oldest 10 published posts, seo.get each to check Yoast status, and for the weakest ones rewrite the intro and meta description, then posts.update with an improved seo object. Summarise what changed.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.

## Suggested schedule

First of each month
