---
name: internal-linking-pass
description: Add relevant internal links between posts. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Internal linking pass

## Workflow

Using Claistore, posts.list recent posts, read a few with posts.get, and suggest internal links between related articles. For approved suggestions, posts.update the content to add the links with natural anchor text.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
