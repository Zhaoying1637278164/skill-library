---
name: weekly-sales-summary
description: Email-ready summary of the week's performance. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Weekly sales summary

## Workflow

Using Claistore reports.sales and orders.list, produce a concise weekly summary: revenue, order count, top products, and week-over-week change. Format it so I can paste it into an email or Slack.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.

## Suggested schedule

Every Friday 5pm
