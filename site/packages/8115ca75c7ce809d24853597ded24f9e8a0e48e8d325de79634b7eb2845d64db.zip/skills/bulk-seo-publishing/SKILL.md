---
name: bulk-seo-publishing
description: Draft, image, and publish Yoast-green articles at scale. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Bulk SEO publishing

## Workflow

Using the Claistore tools, write a 2500-word SEO article for the keyword I give you following the seo-content-writer skill (call skills.get). Generate a unique feature image and media.upload it, resolve categories/tags (categories.list/create, tags.list/create), then posts.create as a draft with featured_media and the seo object. Report the post link.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
