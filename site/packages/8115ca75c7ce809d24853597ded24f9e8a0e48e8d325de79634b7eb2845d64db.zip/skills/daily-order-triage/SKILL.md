---
name: daily-order-triage
description: Review new orders and flag ones needing attention. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Daily order triage

## Workflow

Using Claistore, orders.list the processing and on-hold orders from the last 24 hours. Summarise them, flag any that look fraudulent or stuck, and suggest status updates. Do not change any order status without my confirmation.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.

## Suggested schedule

Every day 8am
