---
name: category-tag-cleanup
description: Organize taxonomy and fix Uncategorized posts. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Category & tag cleanup

## Workflow

Using Claistore, categories.list and tags.list the current taxonomy. Find posts in Uncategorized (posts.list) and assign them to the right category via posts.update, creating categories/tags where needed with categories.create/tags.create.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
