---
name: weekly-blog-calendar
description: Plan and draft next week's posts from a topic list. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Weekly blog calendar

## Workflow

Using Claistore, propose 5 blog post ideas for my niche with focus keywords, then draft the top one with the seo-content-writer skill and posts.create it as a draft. List the others for approval.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.

## Suggested schedule

Every Monday 9am
