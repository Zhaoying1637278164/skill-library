---
name: low-stock-alert
description: Surface products running low on inventory. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Low-stock alert

## Workflow

Using Claistore, run reports.stock and products.list to find products with low or out-of-stock inventory. Give me a prioritized list with current stock levels and suggested reorder actions.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.

## Suggested schedule

Every day 7am
