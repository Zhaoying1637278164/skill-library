---
name: faq-page-generator
description: Build an SEO FAQ page for a topic. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# FAQ page generator

## Workflow

Using Claistore, create an FAQ page for the topic I give you: research common questions, write concise answers with a focus keyword, and pages.create it as a draft with an SEO title and meta description.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
