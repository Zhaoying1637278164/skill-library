---
name: price-drop-campaign
description: Create coupons and an announcement post. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Price-drop campaign

## Workflow

Using Claistore, create a discount coupon with coupons.create for the products I specify, then draft an announcement blog post (posts.create) promoting the sale with a unique feature image. Confirm the coupon code and amount with me first.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
