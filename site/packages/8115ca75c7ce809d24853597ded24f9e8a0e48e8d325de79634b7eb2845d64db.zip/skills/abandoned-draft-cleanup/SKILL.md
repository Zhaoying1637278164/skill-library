---
name: abandoned-draft-cleanup
description: Review and finish or discard old drafts. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Draft cleanup

## Workflow

Using Claistore, posts.list drafts and summarise each. Recommend which to finish, which to merge, and which to discard. For approved ones, improve and posts.update. Do not publish without confirmation.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
