---
name: order-status-updates
description: Move a batch of orders to a new status. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Bulk order status updates

## Workflow

Using Claistore, orders.list the orders matching the criteria I give you, show them to me, and after I confirm, orders.update_status each to the requested status (e.g. completed).

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
