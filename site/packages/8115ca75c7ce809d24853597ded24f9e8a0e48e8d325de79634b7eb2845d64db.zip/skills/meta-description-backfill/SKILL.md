---
name: meta-description-backfill
description: Add missing Yoast meta descriptions. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Meta description backfill

## Workflow

Using Claistore, posts.list published posts and seo.get each to find ones missing a meta description. Write a 120–156 character description with the focus keyword and posts.update the seo.meta_description for each. Requires the Yoast bridge plugin.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
