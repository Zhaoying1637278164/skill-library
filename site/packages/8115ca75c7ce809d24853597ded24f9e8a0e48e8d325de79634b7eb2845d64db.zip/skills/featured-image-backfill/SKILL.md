---
name: featured-image-backfill
description: Generate and attach missing featured images. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Featured image backfill

## Workflow

Using Claistore, posts.list posts without a featured image. For each, generate a unique relevant image, media.upload it with keyword alt text, and posts.update featured_media. Never reuse the same image across posts.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
