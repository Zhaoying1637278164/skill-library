---
name: broken-content-audit
description: Find thin, duplicate, or unpublished content. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Content audit

## Workflow

Using Claistore, posts.list and pages.list all content and flag anything thin (short), duplicated, or stuck in draft. Give me a prioritized cleanup list; do not delete or change anything without confirmation.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
