---
name: keyword-article-series
description: Plan and draft a cluster of related articles. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Keyword article series

## Workflow

Using Claistore, take my seed keyword and propose a content cluster of 6 related article titles with focus keywords. Draft the pillar article with the seo-content-writer skill and posts.create it as a draft; list the rest for approval.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
