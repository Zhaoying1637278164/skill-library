---
name: governed-mcp-access
description: Scoped, audited AI access to your store. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Governed MCP access

## Workflow

Explain what Claistore tools you currently have access to (call connections.list and list your available tools), and how each action is logged. Then wait for my instruction.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
