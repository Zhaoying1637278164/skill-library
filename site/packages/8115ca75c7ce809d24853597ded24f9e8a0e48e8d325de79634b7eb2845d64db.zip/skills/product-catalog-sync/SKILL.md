---
name: product-catalog-sync
description: Update WooCommerce prices, stock, and descriptions in bulk. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Product catalog sync

## Workflow

Using the Claistore WooCommerce tools, update the products I specify: for each, products.update the price, stock_status, and description. List the products first with products.list and confirm changes before writing.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
