---
name: new-product-announcement
description: Turn a new product into a blog post. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# New product announcement

## Workflow

Using Claistore, products.list to find the new product I name, then write a launch blog post about it with the seo-content-writer skill, generate a feature image, and posts.create it as a draft linking to the product.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
