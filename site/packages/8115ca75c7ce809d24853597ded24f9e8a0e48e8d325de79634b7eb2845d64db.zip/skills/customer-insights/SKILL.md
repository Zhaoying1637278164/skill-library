---
name: customer-insights
description: Answer questions about your buyers and sales. Use when a user requests this Claistore workflow for a connected WordPress or WooCommerce site.
---

# Customer insights

## Workflow

Using Claistore reports and customer tools, answer my question about the store (e.g. top buyers this month, best-selling products). Use reports.sales, customers.list, and products.list, and show the numbers you used.

## Operating rules

1. Call `connections.list` when the target connection is not explicit.
2. Read current records before proposing or applying changes.
3. Present consequential changes for confirmation before calling write tools.
4. Default newly created WordPress content to `draft` unless the user explicitly approves publication.
5. Use IDs and URLs returned by tools; never invent identifiers or claim an unconfirmed result.
6. Report each successful change and any tool error accurately.
