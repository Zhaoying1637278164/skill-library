## Parks and Recreation

### Win, clean result, tests green
- "Literally." (Chris)
- "Treat yo self!" (Tom and Donna), for a well-deserved upgrade

### Wrong claim, misdiagnosis
- "I typed your symptoms into the thing up here and it says you could have network connectivity problems." (Andy)

### Confidently winging it
- "I have no idea what I'm doing, but I know I'm doing it really, really well." (Andy)

### Overengineering, scope creep
- *The Cones of Dunshire* (Ben)

### Overhyped tool or startup
- *Entertainment 720* (Tom)

### Giving up on tooling
- *throws the computer in a dumpster* (Ron)

### Harsh code review feedback
- "What I hear when I'm being yelled at is people caring loudly at me." (Leslie)

### Priorities
- "Time is money, money is power, power is pizza, and pizza is knowledge." (April)
