# Bootstrap mode — full guide

Read this file when running BOOTSTRAP mode (no `docs/overview.md` exists yet, but the project has code). Also runs in **Re-bootstrap** form when the catalog exists but `constitution.md` or `mission.md` is missing/empty (see end of this file).

Bootstrap runs **once** per project. After this, SYNC mode handles all incremental updates. Its single most important step is updating the project's agent memory file — `CLAUDE.md` and `AGENTS.md`, one real file plus a symlink — so that **future sessions automatically read the catalog** even when this skill doesn't trigger, on Claude Code and on Codex alike. Don't skip it.

## Three-phase flow

Bootstrap runs in three phases:

- **A — Auto-detect** (no user input): scan repo for tech stack, test framework, design system, README intro. Pre-fill what we can prove from files.
- **B — Interview user** (single batch): ask only the things we can't detect. Code Quality rules, Performance budgets, Mission users/value/metrics require user input.
- **C — Confirm and write**: show the populated docs to the user, get OK, then write the 4 project docs (overview, constitution, mission, roadmap) + the changelog bootstrap entry + per-feature specs, and update the agent memory file (`CLAUDE.md` + `AGENTS.md`).

`constitution.md` and `mission.md` MUST have real content before bootstrap completes. Use `_TBD: <prompt>_` markers if the user defers a section, but never blank fields and never fabricated content. Fabricated content propagates to every future session as if it were truth.

## Step 0 — Confirm with the user

Ask before scanning:

- "I'll create the spec catalog at `docs/overview.md` + `docs/constitution.md` + `docs/mission.md` + `docs/roadmap.md` + `docs/changelog/` (one file per entry) + `docs/specs/spec-<feature>.md` per feature. Continue?"
- **Initial bootstrap only** (no existing catalog): "Are there design docs I should pull from? (e.g. `specs/`, `plans/`, `docs/`, ADRs, RFCs)"

If the user has design docs, use them as the **primary source of feature intent and mission**. Code shows implementation; docs show intent. Combining both produces accurate plans, requirements, and validation criteria.

For **re-bootstrap** (catalog exists, only `constitution.md` or `mission.md` is missing): skip the design-docs question. The existing roadmap + spec catalog already supply that context — going back to external PRDs duplicates the source-of-truth and risks divergence. Pull from the catalog itself.

## Phase A — Auto-detect

Pull from the repo, no user questions yet.

### A1. Tech stack (constitution → Tech Stack)

Read whichever exists:

- `package.json` (Node) — `dependencies`, `devDependencies`, `engines`
- `Cargo.toml` (Rust)
- `pyproject.toml` / `requirements.txt` (Python)
- `go.mod` (Go)
- `composer.json` (PHP)
- `pubspec.yaml` (Flutter / Dart)
- `Gemfile` (Ruby)
- `Dockerfile` / `docker-compose.yml` (DBs, runtimes)

Extract: language + version, framework, DB, cache, queue, build tool, deploy target.

### A2. Test framework (constitution → Testing Standards)

Detect: jest, vitest, mocha, pytest, go test, cargo test, phpunit, flutter test. Look for coverage configs (`jest.config`, `vitest.config`, `.coveragerc`, `pytest.ini`).

Note: this only fills the "what test runner is in use" line. The user still has to provide the **rules** (required test types, coverage threshold, forbidden patterns) in Phase B.

### A3. Design system (constitution → UX Consistency)

Search dependencies for: shadcn-related packages, `@radix-ui/*`, `@mui/*`, `antd`, `chakra-ui`, `tailwindcss`, design tokens. Note what you find.

### A4. README intro (mission → Problem)

If `README.md` exists, pull the first paragraph after the title. Use it as a draft for `Mission > Problem` — but mark it as `(from README, please verify)` so the user knows it's not yet confirmed.

### A5. Entry-point scan (feature specs)

Identify entry points (where users interact with the system). Examples:

- HTTP routes / API handlers (`routes.ts`, `app.py`, `controllers/*.rb`)
- CLI commands (`cli.ts`, `bin/*`)
- Queue consumers / event handlers
- UI page routes (`pages/*`, `app/*/page.tsx`)
- Public exports of a library (`index.ts` / `lib.rs`)

**Cap on files read:**

- **Single-repo project:** max 15 entry-point files total
- **Monorepo / workspace:** max 15 files **per package**, mark packages exceeding this as `PARTIAL`
- A "package" = anything with its own `package.json` / `Cargo.toml` / `pyproject.toml` / `go.mod`. Apps in `apps/`, libs in `packages/`, services in `services/`.

Prioritization (when there are more than 15 candidates), in order until cap:

1. Files with the most public exports (these define the API surface)
2. Files referenced by the entry point (`main.ts`, `app.ts`, `routes.ts`)
3. Files with associated tests (tests prove invariants and feed Validation criteria)
4. Files modified most recently (active features matter more than dead code)
5. Files referenced in design docs

## Phase B — Interview user

Ask **all of these in one message** (don't drip-feed). Show what was auto-detected next to each section so the user knows what's already filled.

```
I've auto-filled the parts I could detect from the repo:
- Constitution > Tech Stack: <list from A1>
- Constitution > Testing Standards (test runner): <from A2>
- Constitution > UX Consistency (design system): <from A3>
- Mission > Problem (draft from README): <from A4>

To finish bootstrap I need answers to these:

CONSTITUTION
1. Code Quality — what rules/patterns to enforce beyond the linter?
   (e.g., "no `any` in new code", "public functions document failure modes",
   forbidden patterns, naming conventions)
2. Testing Standards — required test types and coverage rules?
   (e.g., "unit tests for every public function; integration tests for every endpoint;
   ≥80% line coverage on src/, blocking")
3. Performance Requirements — latency budgets, throughput targets, SLOs?
   Reply "skip" if no formal targets yet.

MISSION
4. Problem — does the README draft above capture it correctly? Edit if not.
5. Users — who uses this and in what role? List 1-3 personas.
6. Value proposition — one sentence: why use this over the alternative?
7. Success metrics — how do you know the mission is being served? 1-3 measurable outcomes.

(Reply "TBD" for any section I should defer — I'll mark it for later, never fabricate.)
```

If the user deflects ("just write something reasonable") — push back once: "Mission and Code Quality require your judgment, otherwise the catalog will mislead future sessions. Even one-line answers are fine." If they still defer, write `_TBD: <the question>_` for that field. Never invent content.

## Phase C — Confirm and write

### C1. Show the user the populated docs

Render `constitution.md` and `mission.md` in a single message for review:

> Here's what I'll write. Edit anything before I commit it.

Wait for OK or edits.

### C2. Create per-feature spec files

For each identified feature, create `docs/specs/spec-<feature_name>.md` using the format in `references/catalog-format.md`. Use kebab-case for the filename.

For each spec, fill the four content sections:

- **Plan**: pull from the design doc if linked; otherwise infer from code + tests in 3-5 bullets covering problem, approach, alternatives, non-goals. Mark `_TBD: design rationale not documented_` if you genuinely can't infer.
- **Requirement > Surface**: extract from the entry point.
- **Requirement > Invariants**: extract from tests first, code second. Skip what you can't prove. Tests describe contracts more reliably than implementations.
- **Validation**: convert each test case into a Given/When/Then or SHALL acceptance criterion. Each criterion SHALL trace to an Invariants bullet. If no tests exist for a feature, mark `_TBD: no tests yet — acceptance criteria need confirmation_`.

Once all specs are drafted, run them through the spec critique gate → [`catalog-format.md`](catalog-format.md) — **one batched reviewer for the whole set**, not one per spec (bootstrap can draft a dozen specs at once). Pass it every drafted spec, plus the constitution and mission drafts, and ask it to weight check 4 (silent guesses) heaviest: bootstrap specs are reverse-engineered from code, so invented invariants are the dominant failure. Fold its findings, then continue to C3. Bootstrap specs describe already-shipped code, so they keep no `Open questions` section — anything the reviewer raises that you can't prove from code or tests becomes a `_TBD:_` marker or a question for the user in C7, never a guess written as fact.

If a package's code is too complex for 15 files to capture meaningfully, mark the package's specs with a `PARTIAL` note in the index entry, like:

```markdown
- [billing-engine](specs/spec-billing-engine.md) — _PARTIAL_ — Core billing logic only. Edge cases in tax calculation not yet captured.
```

### C3. Create the roadmap

The roadmap holds only **unshipped** work. Bootstrapped features already exist in code (they shipped), so they do **not** go on the roadmap — they are captured by their specs (`Status: active`) and the `overview.md` index. The roadmap therefore starts essentially empty: only in-flight or planned work.

`Now`, `Next`, `Later` start empty unless the user mentions in-flight or upcoming work during the interview. If they do, capture it:

```markdown
## Now (≤3, each has a spec)
- **<feature-slug>** — <one-line summary> — _started <YYYY-MM-DD>_
```

An in-flight item captured here has no spec yet; write one before development continues. Keep the entry to the one-line shape above — the note about the missing spec goes in the conversation, not on the line.

### C4. Create the index

Write `docs/overview.md` listing project docs and all features. Use the format in `references/catalog-format.md`.

### C5. Initialize the changelog

Write `docs/changelog/<today>-bootstrap.md` (this also creates the `docs/changelog/` folder — the changelog is a folder of per-entry files, `YYYY-MM-DD-<slug>.md`, never a single `CHANGELOG.md`):

```markdown
### Bootstrapped
- Initial spec catalog created from existing code at commit `<short hash>`.
- Files scanned: <N>. Features identified: <M>. Marked PARTIAL: <list, or "none">.
- Constitution sections auto-filled: <list>. User-provided: <list>. TBD: <list, or "none">.
- Mission sections user-provided: <list>. TBD: <list, or "none">.
```

`docs/decisions/` and `docs/debugging/` are **not** created here. They come into existence when SYNC writes their first entry, and their `overview.md` links appear at the same moment. Do not create them empty, and do not mine git history for decision records — bootstrap infers nothing it cannot read off the code.

### C6. Update the agent memory file (DO NOT SKIP)

This is the highest-leverage step. Append a section so every future session reads the catalog before coding, even when this skill doesn't trigger:

```markdown
## Spec Catalog (source of truth)

This project follows Spec-Driven Development. The catalog lives at:

- `docs/overview.md` — index of project docs and feature specs
- `docs/constitution.md` — principles, tech stack, quality bars (gates implementation choices)
- `docs/mission.md` — problem, users, value, success metrics (gates feature scope)
- `docs/roadmap.md` — Now / Next / Later forward plan (shipped work leaves the roadmap)
- `docs/changelog/YYYY-MM-DD-<slug>.md` — deletions, renames, contract changes (one flat file per entry — never a single CHANGELOG.md)
- `docs/decisions/YYYY-MM-DD-<slug>.md` — decisions spanning ≥2 features or the constitution (created on first entry)
- `docs/debugging/YYYY-MM-DD-<slug>.md` — post-mortems for bugs whose root cause was not where the symptom pointed (created on first entry)
- `docs/specs/spec-<feature>.md` — per-feature Plan + Requirement + Validation

**Always read `docs/overview.md` at the start of every session** to load the source
of truth. Following this process is mandatory, not advisory: before writing,
modifying, or deleting code, walk these three gates in order. Each gate is a
STOP — do not proceed to the next until the current one clears, and do not
"use judgment" to skip a gate. (This is the *enforcement* order — roadmap first
because the iron-rule is the cheapest, hardest stop. It is independent of the
order READ mode reads files in, which only loads context.)

### Gate 1 — Roadmap (iron-rule)
Read `docs/roadmap.md`. EVERY unit of work — feature, refactor, **and bug fix** —
gets a roadmap entry before code is written. This gate's job is to block the
*assistant's own* "too small to track" rationalizing — that is how the roadmap
silently drifts from reality. If the work is not in `Now` / `Next` / `Later` (and has no spec yet — i.e. not already shipped),
STOP, surface it, and add it (`Now` or `Next`) first, then code. The user can
override — but urgency is not an override: "be quick" or "we demo in 5 minutes"
means work fast, not skip the gate (the entry costs seconds, so add it and move
fast). A real override is the user, aware of the rule, explicitly choosing to
proceed without it (e.g. a live hotfix); then do so, say so, and recommend a
retroactive roadmap + changelog entry. Quietly shipping off-roadmap — or skipping
because it felt small or rushed — is the violation.

### Gate 2 — Constitution
Read `docs/constitution.md`. STOP if the planned approach conflicts with
Tech Stack, Code Quality, Testing Standards, UX Consistency, or Performance
Requirements. Either change the approach, or ask the user to update the
constitution first (with reason + a changelog entry under
`### Constitution change`) before coding.

### Gate 3 — Spec invariants
Read the relevant `docs/specs/spec-<feature>.md`. STOP if the change would
break a documented invariant or acceptance criterion. Either confirm with
the user (it goes in the changelog under `### Contract changed`) or rethink.

### After the gates — implementation route
Once the gates clear, roadmap work is built one way — feature, refactor, or bug
fix alike:

1. In an **isolated git worktree** for that roadmap item, never in the main
   checkout (`git worktree add`, or the agent's built-in worktree tool). Not a git
   repo, or the user asks for an in-place edit: say which applies, then proceed.
   "It's one small edit" is not one of those cases.
2. **Implemented directly**, without handing off to other skills or plugins —
   unless the user asks for one; then follow it and say so.
3. **Following the plan document** if one exists (the spec's `Source plan`, or a
   `docs/` / `plans/` / `specs/` document): its task order is the route, the spec's
   `Validation` criteria are what the tests assert. Surface deviations; don't
   drift silently.
4. **Sync + commit inside the worktree, before merging** — see the commit gate
   below; the catalog belongs on the same branch as the code.

### Commit gate — SYNC before every commit
Before ANY `git commit` — whether you initiated it or the user asked for one —
the catalog must already reflect the change. So whenever a commit is requested
(or you are about to commit), FIRST run source-of-truth SYNC automatically, then
commit — do not ask, just sync then commit:

1. Reconcile each affected `docs/specs/spec-<feature>.md` with the diff.
2. Remove the shipped entry from `Now` (the roadmap holds only unshipped work).
3. Record removals / renames / contract changes / constitution changes as
   per-entry files `docs/changelog/YYYY-MM-DD-<slug>.md` (one flat file per
   date + feature; parallel sessions never conflict) — a constitution change
   also gets a `docs/decisions/YYYY-MM-DD-<slug>.md` record, and so does any
   decision spanning ≥2 specs or reversing an existing one; a bug fix meeting
   any of the skill's debugging triggers gets a `docs/debugging/YYYY-MM-DD-<slug>.md`
   entry (full trigger lists → skill references: `sync-guide.md`, `catalog-format.md`).
4. Commit the code **and** the catalog updates together.

Self-gating: this applies only because `docs/overview.md` exists. Skip the sync
only when there is genuinely nothing to reconcile (a pure internal refactor that
touches no spec) or the user explicitly overrides for this commit (e.g. a live
hotfix) — then proceed and recommend a retroactive sync. A commit that lands
code while the catalog still describes the old behavior is exactly the drift
this catalog exists to prevent.
```

Claude Code reads `CLAUDE.md`, Codex reads `AGENTS.md`. Keep **one** real file and make the other name a symlink to it, so the two can never drift apart:

- One of them already exists as a regular file → append the section to that one, then link the missing name to it (`ln -s CLAUDE.md AGENTS.md`, or `ln -s AGENTS.md CLAUDE.md`). Appending through an existing symlink writes to the real file and leaves the link intact, so re-running is safe.
- Neither exists → create `CLAUDE.md` with this section, then `ln -s CLAUDE.md AGENTS.md`.
- Both exist as regular files → append to both and tell the user they are now two separate copies that will drift; offer to collapse one into a symlink.

Run `ln -s` from the project root with a **relative** target, never an absolute path — an absolute link breaks for everyone who clones the repo. Never overwrite an existing memory file; always append. On a filesystem without symlinks (Windows without developer mode), write both files and say so — the user then owns keeping them in sync.

### C7. Show summary

Tell the user:

> Bootstrapped spec catalog with N features across M files.
> Constitution: <auto-filled sections / TBD sections>.
> Mission: <user-provided sections / TBD sections>.
> Roadmap: <N> items in flight (Now/Next/Later); shipped features live in their specs + overview.
> Areas marked PARTIAL: <list>.
> Updated the agent memory file to reference the catalog: <`CLAUDE.md`, with `AGENTS.md` symlinked to it | `AGENTS.md`, with `CLAUDE.md` symlinked to it | both `CLAUDE.md` and `AGENTS.md` as separate copies that will drift>.

## Re-bootstrap (catalog incomplete)

If `docs/overview.md` exists but `constitution.md` or `mission.md` is missing or empty, run only the missing pieces:

1. Skip A5 (specs already exist) and skip C2/C3/C4/C5 unless those files are also missing.
2. Run Phase A for the missing file's domain (tech stack + test runner + design system for constitution; README intro for mission).
3. Run Phase B targeted at the missing sections only.
4. Phase C writes only the missing file + a changelog entry `docs/changelog/<today>-bootstrap.md` under `### Bootstrapped (partial)` (append to that file if it already exists today).

Re-bootstrap blocks code changes until the catalog is complete. The "STOP, complete bootstrap first" gate exists because READ mode can't reason about constitution/roadmap conflicts when those files don't exist.

## Common pitfalls

- **Reading too many files.** The cap exists because spec quality drops when you skim too much. Stop at the cap and mark PARTIAL.
- **Inventing invariants from imagination.** If code/tests don't show it, don't claim it.
- **Fabricating constitution or mission content — including "common sense" rules.** Phase B requires user input; `_TBD:` is acceptable, invented principles are not (they propagate to every future session as truth). "No `any` types" sounds reasonable, but if the user actually allows `any`, that rule blocks legitimate work. Ask.
- **Skipping Phase C confirmation.** The user must see constitution + mission before they're written.
- **Forgetting the memory file.** Without this step, future sessions won't know the catalog exists, and SYNC mode will never get triggered.
- **Writing `CLAUDE.md` and `AGENTS.md` as two real files.** They drift, and the next session reads whichever its runtime picked. One real file, one symlink.
- **Bootstrapping a project that already has the catalog.** Check first — if `docs/overview.md` exists AND constitution/mission have content, switch to SYNC mode instead.
- **Creating `docs/decisions/` or `docs/debugging/` at bootstrap.** Both are created on first entry, by SYNC. An empty folder and a dead `overview.md` link teach the next session that the mechanism is decorative.
