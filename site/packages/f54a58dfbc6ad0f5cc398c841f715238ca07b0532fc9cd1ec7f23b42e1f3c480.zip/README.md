<div align="center">

<br>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://img.shields.io/badge/Claude_Code_Plugin-8B5CF6?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBvbHlnb24gcG9pbnRzPSIyMyA3IDEyIDIgMSA3IDEgMTcgMTIgMjIgMjMgMTciLz48cG9seWxpbmUgcG9pbnRzPSIxIDcgMTIgMTIgMjMgNyIvPjxsaW5lIHgxPSIxMiIgeTE9IjIyIiB4Mj0iMTIiIHkyPSIxMiIvPjwvc3ZnPg==">
  <img alt="Claude Code Plugin" src="https://img.shields.io/badge/Claude_Code_Plugin-8B5CF6?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IndoaXRlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBvbHlnb24gcG9pbnRzPSIyMyA3IDEyIDIgMSA3IDEgMTcgMTIgMjIgMjMgMTciLz48cG9seWxpbmUgcG9pbnRzPSIxIDcgMTIgMTIgMjMgNyIvPjxsaW5lIHgxPSIxMiIgeTE9IjIyIiB4Mj0iMTIiIHkyPSIxMiIvPjwvc3ZnPg==">
</picture>

# letmewatch

### Give Claude eyes for video.

[![Sponsor](https://readme.cash/i/4y5sxs7pbj.svg)](https://readme.cash/c/4y5sxs7pbj)

Extract key frames with scene detection.<br>
Claude sees every meaningful moment — and skips the rest.

<br>

<table>
<tr>
<td align="center"><strong>1</strong><br><sub>Skill</sub></td>
<td align="center"><strong>3</strong><br><sub>Commands</sub></td>
<td align="center"><strong>Scene<br>Detection</strong><br><sub>via ffmpeg</sub></td>
<td align="center"><strong>Audio</strong><br><sub>via whisper</sub></td>
</tr>
</table>

<br>

```
/plugin marketplace add BinyaminEden/letmewatch
```

<br>

[View on GitHub](https://github.com/BinyaminEden/letmewatch) · [Report Issue](https://github.com/BinyaminEden/letmewatch/issues)

</div>

---

## What it does

You send Claude a video. Claude **watches** it.

```
You: /letmewatch:video ~/Desktop/bug-recording.mov

Claude: Extracting frames... 15 scene changes detected.

        At 00m00s: The app loads with the dashboard view.
        At 00m12s: User clicks "Submit".
        At 00m13s: Loading spinner appears.
        At 00m18s: Error toast — "Failed to save" (500).
        At 00m23s: Form resets, user input is lost.

        The bug: API returns 500 on submit, and the form
        clears input instead of preserving it.
```

Instead of processing video natively, letmewatch uses **ffmpeg scene detection** — it only captures frames where the visuals actually change. No idle screens, no wasted frames.

- A 2-minute screen recording → ~15-20 frames
- Static moments → skipped entirely
- Every frame → timestamped (`frame_01m23s.jpg`)
- Audio → transcribed if whisper is installed

## Install

### 1. Install ffmpeg (required)

```bash
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt install ffmpeg

# Windows
winget install ffmpeg
# or: choco install ffmpeg
```

### 2. Install the plugin

**Via marketplace** (recommended):
```
/plugin marketplace add BinyaminEden/letmewatch
/plugin install letmewatch@letmewatch
```

**Via local clone:**
```bash
git clone https://github.com/BinyaminEden/letmewatch.git ~/letmewatch
# Then in Claude Code:
/plugin install --path ~/letmewatch
```

### 3. Optional: Audio transcription

```bash
# Standard
pip install openai-whisper

# Apple Silicon (faster)
pip install mlx-whisper
```

## Commands

| Command | What it does |
|---|---|
| `/letmewatch:video <path>` | Analyze a specific video file |
| `/letmewatch:video-last` | Analyze the most recent video in your configured folder |
| `/letmewatch:video-dir <path>` | Set/change where `video-last` looks for videos |

## How it works

### Scene detection

The plugin uses ffmpeg's scene detection filter to find frames where visuals change:

```
ffmpeg -vf "select='gt(scene,0.1)'" ...
```

This captures page navigations, modal dialogs, form submissions, error states, tab switches — any meaningful UI change. Static moments produce zero frames.

### Smart fallbacks

If scene detection finds fewer than 3 changes (e.g., a very static video or gradual scrolling), it automatically falls back to extracting frames at regular intervals:

| Video length | Interval |
|---|---|
| < 30 seconds | Every 2s |
| 30s – 3 min | Every 5s |
| > 3 min | Every 10s |

### Frame processing

- Resized to **720p JPEG** (~50-80KB each)
- Capped at **40 frames** per video
- Viewed in **batches of 8** to stay within context limits
- **Timestamped** in filenames for easy reference

### Audio transcription

If [whisper](https://github.com/openai/whisper) or [mlx-whisper](https://github.com/ml-explore/mlx-examples/tree/main/whisper) is installed, the plugin extracts and transcribes audio automatically. Claude sees both the visual frames and the spoken content.

## Configuration

**Video directory:** The first time you run `video-last`, it asks where your videos live and saves it to `~/.claude/video.conf`. Change it anytime with `video-dir`.

**Scene threshold:** Default is `0.1` (10% pixel change). Lower = more sensitive, higher = fewer frames.

## Use cases

- **Bug reports** — Record the bug, share the video, get a diagnosis with timestamps
- **UI review** — Show Claude your app flow, get design feedback
- **Code walkthroughs** — Record a tutorial, get a written summary
- **Screen recordings** — Anything you'd screenshot, but as a video

## License

MIT — [Binyamin Eden](https://github.com/BinyaminEden)
