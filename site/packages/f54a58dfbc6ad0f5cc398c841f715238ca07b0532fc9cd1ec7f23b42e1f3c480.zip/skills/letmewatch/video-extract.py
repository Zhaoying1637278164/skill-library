#!/usr/bin/env python3
"""Extract key frames from video for Claude analysis using ffmpeg scene detection."""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

THRESHOLD = 0.1
MAX_FRAMES = 40
BATCH_SIZE = 8


def run(cmd, capture=True, check=False):
    """Run a command and return stdout."""
    result = subprocess.run(cmd, capture_output=capture, text=True, check=check)
    return result.stdout.strip() if capture else None


def get_video_info(video_path):
    """Get video duration, resolution, and audio presence."""
    try:
        raw = run([
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_format", "-show_streams", video_path
        ])
        info = json.loads(raw)
    except (json.JSONDecodeError, subprocess.CalledProcessError):
        return None, None, False

    duration = None
    resolution = None
    has_audio = False

    fmt = info.get("format", {})
    duration = int(float(fmt.get("duration", 0)))

    for stream in info.get("streams", []):
        if stream.get("codec_type") == "video" and not resolution:
            resolution = f'{stream.get("width", "?")},{stream.get("height", "?")}'
        if stream.get("codec_type") == "audio":
            has_audio = True

    return duration, resolution, has_audio


def extract_scene_frames(video_path, work_dir, threshold):
    """Extract frames at scene changes using ffmpeg scene detection."""
    log_path = os.path.join(work_dir, "ffmpeg.log")

    with open(log_path, "w") as log_file:
        subprocess.run([
            "ffmpeg", "-y", "-i", video_path,
            "-vf", f"select='gt(scene,{threshold})',showinfo,scale=-1:720",
            "-vsync", "vfr", "-q:v", "5",
            os.path.join(work_dir, "scene_%04d.jpg")
        ], stderr=log_file, stdout=subprocess.DEVNULL)

    # Parse timestamps from showinfo output
    timestamps = []
    try:
        with open(log_path, "r") as f:
            for line in f:
                if "showinfo" in line:
                    match = re.search(r"pts_time:([0-9.]+)", line)
                    if match:
                        timestamps.append(float(match.group(1)))
    except IOError:
        pass

    return timestamps


def extract_interval_frames(video_path, work_dir, duration):
    """Fall back to extracting frames at regular intervals."""
    if duration < 30:
        interval = 2
    elif duration < 180:
        interval = 5
    else:
        interval = 10

    subprocess.run([
        "ffmpeg", "-y", "-i", video_path,
        "-vf", f"fps=1/{interval},scale=-1:720",
        "-q:v", "5",
        os.path.join(work_dir, "scene_%04d.jpg")
    ], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)

    timestamps = []
    frames = sorted(f for f in os.listdir(work_dir) if f.startswith("scene_") and f.endswith(".jpg"))
    for i, _ in enumerate(frames):
        timestamps.append(i * interval)

    return timestamps, interval


def extract_first_frame(video_path, work_dir):
    """Always grab the first frame."""
    subprocess.run([
        "ffmpeg", "-y", "-i", video_path,
        "-vf", "scale=-1:720", "-frames:v", "1", "-q:v", "5",
        os.path.join(work_dir, "first_frame.jpg")
    ], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)


def format_timestamp(seconds):
    """Convert seconds to MMmSSs format."""
    mins = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{mins:02d}m{secs:02d}s"


def transcribe_audio(video_path, work_dir):
    """Extract and transcribe audio if whisper is available."""
    audio_path = os.path.join(work_dir, "audio.wav")

    subprocess.run([
        "ffmpeg", "-y", "-i", video_path,
        "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
        audio_path
    ], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)

    if not os.path.exists(audio_path):
        return "none"

    # Try whisper
    if shutil.which("whisper"):
        print("Transcribing with whisper...")
        result = subprocess.run(
            ["whisper", audio_path, "--model", "small", "--output_format", "txt", "--output_dir", work_dir],
            stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL
        )
        transcript = os.path.join(work_dir, "audio.txt")
        if result.returncode == 0 and os.path.exists(transcript):
            return transcript

    # Try mlx_whisper
    if shutil.which("mlx_whisper"):
        print("Transcribing with mlx_whisper...")
        result = subprocess.run(
            ["mlx_whisper", audio_path, "--model", "mlx-community/whisper-small-mlx",
             "--output-format", "txt", "--output-dir", work_dir],
            stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL
        )
        transcript = os.path.join(work_dir, "audio.txt")
        if result.returncode == 0 and os.path.exists(transcript):
            return transcript

    print("No whisper installed — skipping transcription")
    print("Install with: pip install openai-whisper  OR  pip install mlx-whisper")
    return "none"


def main():
    if len(sys.argv) < 2:
        print("Usage: video-extract.py <video_path> [threshold]", file=sys.stderr)
        sys.exit(1)

    video_path = os.path.abspath(sys.argv[1])
    threshold = float(sys.argv[2]) if len(sys.argv) > 2 else THRESHOLD

    if not os.path.isfile(video_path):
        print(f"ERROR: File not found: {video_path}", file=sys.stderr)
        sys.exit(1)

    if not shutil.which("ffmpeg"):
        print("ERROR: ffmpeg not installed.", file=sys.stderr)
        print("  macOS:  brew install ffmpeg", file=sys.stderr)
        print("  Linux:  sudo apt install ffmpeg", file=sys.stderr)
        print("  Windows: winget install ffmpeg  OR  choco install ffmpeg", file=sys.stderr)
        sys.exit(1)

    # Create work directory
    work_dir = tempfile.mkdtemp(prefix="letmewatch-")

    # Get video info
    duration, resolution, has_audio = get_video_info(video_path)

    print("=== Video Info ===")
    print(f"File: {video_path}")
    print(f"Duration: {duration or 'unknown'}s")
    print(f"Resolution: {resolution or 'unknown'}")
    print(f"Audio: {'yes' if has_audio else 'none'}")
    print()

    # Step 1: First frame
    extract_first_frame(video_path, work_dir)

    # Step 2: Scene detection
    print(f"=== Extracting scene-change frames (threshold: {threshold}) ===")
    timestamps = extract_scene_frames(video_path, work_dir, threshold)
    scene_count = len(timestamps)
    print(f"Scene changes detected: {scene_count}")

    # Step 3: Fallback if too few
    if scene_count < 3:
        print("Too few scene changes, switching to interval extraction...")
        # Remove scene frames
        for f in os.listdir(work_dir):
            if f.startswith("scene_"):
                os.remove(os.path.join(work_dir, f))
        timestamps, interval = extract_interval_frames(video_path, work_dir, duration or 60)
        scene_count = len(timestamps)
        print(f"Interval frames extracted: {scene_count} (every {interval}s)")

    # Step 4: Cap at MAX_FRAMES
    scene_files = sorted(f for f in os.listdir(work_dir) if f.startswith("scene_") and f.endswith(".jpg"))
    if len(scene_files) > MAX_FRAMES:
        print(f"Capping at {MAX_FRAMES} frames...")
        for f in scene_files[MAX_FRAMES:]:
            os.remove(os.path.join(work_dir, f))
        scene_files = scene_files[:MAX_FRAMES]
        timestamps = timestamps[:MAX_FRAMES]

    # Step 5: Rename with timestamps
    frame_list = []

    first_frame = os.path.join(work_dir, "first_frame.jpg")
    if os.path.exists(first_frame):
        dest = os.path.join(work_dir, "frame_00m00s.jpg")
        os.rename(first_frame, dest)
        frame_list.append(dest)

    for i, scene_file in enumerate(scene_files):
        ts = timestamps[i] if i < len(timestamps) else 0
        name = f"frame_{format_timestamp(ts)}.jpg"

        # Skip duplicate at 00m00s
        if name == "frame_00m00s.jpg" and os.path.exists(os.path.join(work_dir, name)):
            os.remove(os.path.join(work_dir, scene_file))
            continue

        dest = os.path.join(work_dir, name)
        os.rename(os.path.join(work_dir, scene_file), dest)
        frame_list.append(dest)

    total_frames = len(frame_list)

    # Step 6: Audio transcription
    transcript = "none"
    if has_audio:
        print()
        print("=== Audio ===")
        transcript = transcribe_audio(video_path, work_dir)

    # Output summary
    print()
    print("=== Results ===")
    print(f"WORK_DIR={work_dir}")
    print(f"TOTAL_FRAMES={total_frames}")
    print(f"BATCHES={(total_frames + BATCH_SIZE - 1) // BATCH_SIZE}")
    print(f"TRANSCRIPT={transcript}")
    print()
    print("FRAMES:")
    for f in frame_list:
        print(f)


if __name__ == "__main__":
    main()
