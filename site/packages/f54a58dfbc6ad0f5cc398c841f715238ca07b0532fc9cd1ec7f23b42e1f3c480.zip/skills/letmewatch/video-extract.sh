#!/usr/bin/env bash
# video-extract.sh — Extract key frames from video for Claude analysis
# Uses ffmpeg scene detection to capture only meaningful visual changes
set -euo pipefail

VIDEO="$1"
THRESHOLD="${2:-0.1}"
MAX_FRAMES=40
BATCH_SIZE=8

# Resolve absolute path
if [[ "$VIDEO" != /* ]]; then
    VIDEO="$(pwd)/$VIDEO"
fi

if [[ ! -f "$VIDEO" ]]; then
    echo "ERROR: File not found: $VIDEO" >&2
    exit 1
fi

# Check ffmpeg
if ! command -v ffmpeg &>/dev/null; then
    echo "ERROR: ffmpeg not installed. Run: brew install ffmpeg" >&2
    exit 1
fi

# Create work directory
WORK_DIR=$(mktemp -d /tmp/letmewatch-XXXXXX)

# Get video info
DURATION=$(ffprobe -v quiet -show_entries format=duration -of csv=p=0 "$VIDEO" | cut -d. -f1)
HAS_AUDIO=$(ffprobe -v quiet -select_streams a -show_entries stream=codec_type -of csv=p=0 "$VIDEO" 2>/dev/null | head -1)
RESOLUTION=$(ffprobe -v quiet -select_streams v:0 -show_entries stream=width,height -of csv=p=0 "$VIDEO" 2>/dev/null)

echo "=== Video Info ==="
echo "File: $VIDEO"
echo "Duration: ${DURATION:-unknown}s"
echo "Resolution: ${RESOLUTION:-unknown}"
echo "Audio: ${HAS_AUDIO:-none}"
echo ""

# --- Step 1: Always grab first frame ---
ffmpeg -y -i "$VIDEO" -vf "scale=-1:720" -frames:v 1 -q:v 5 "$WORK_DIR/first_frame.jpg" 2>/dev/null || true

# --- Step 2: Scene detection ---
echo "=== Extracting scene-change frames (threshold: $THRESHOLD) ==="
ffmpeg -y -i "$VIDEO" \
    -vf "select='gt(scene,$THRESHOLD)',showinfo,scale=-1:720" \
    -vsync vfr -q:v 5 \
    "$WORK_DIR/scene_%04d.jpg" 2>"$WORK_DIR/ffmpeg.log" || true

# Parse timestamps from showinfo output
TIMESTAMPS=()
while IFS= read -r ts; do
    TIMESTAMPS+=("$ts")
done < <(grep "showinfo" "$WORK_DIR/ffmpeg.log" | grep -oE 'pts_time:[0-9.]+' | cut -d: -f2)

SCENE_COUNT=${#TIMESTAMPS[@]}
echo "Scene changes detected: $SCENE_COUNT"

# --- Step 3: Fallback to interval if too few scenes ---
USE_INTERVAL=false
if [[ $SCENE_COUNT -lt 3 ]]; then
    echo "Too few scene changes, switching to interval extraction..."
    rm -f "$WORK_DIR"/scene_*.jpg
    USE_INTERVAL=true

    DURATION_INT=${DURATION:-60}
    if [[ $DURATION_INT -lt 30 ]]; then
        INTERVAL=2
    elif [[ $DURATION_INT -lt 180 ]]; then
        INTERVAL=5
    else
        INTERVAL=10
    fi

    ffmpeg -y -i "$VIDEO" \
        -vf "fps=1/$INTERVAL,scale=-1:720" \
        -q:v 5 "$WORK_DIR/scene_%04d.jpg" 2>/dev/null || true

    TIMESTAMPS=()
    for f in "$WORK_DIR"/scene_*.jpg; do
        [[ -f "$f" ]] || continue
        idx=$(basename "$f" .jpg | sed 's/scene_0*//')
        [[ -z "$idx" ]] && idx=1
        ts=$(( (idx - 1) * INTERVAL ))
        TIMESTAMPS+=("$ts")
    done
    SCENE_COUNT=${#TIMESTAMPS[@]}
    echo "Interval frames extracted: $SCENE_COUNT (every ${INTERVAL}s)"
fi

# --- Step 4: Cap at MAX_FRAMES ---
if [[ $SCENE_COUNT -gt $MAX_FRAMES ]]; then
    echo "Capping at $MAX_FRAMES frames..."
    i=0
    for f in $(ls "$WORK_DIR"/scene_*.jpg | sort); do
        i=$((i + 1))
        [[ $i -gt $MAX_FRAMES ]] && rm -f "$f"
    done
    TIMESTAMPS=("${TIMESTAMPS[@]:0:$MAX_FRAMES}")
    SCENE_COUNT=$MAX_FRAMES
fi

# --- Step 5: Rename with timestamps ---
FRAME_LIST=()
if [[ -f "$WORK_DIR/first_frame.jpg" ]]; then
    mv "$WORK_DIR/first_frame.jpg" "$WORK_DIR/frame_00m00s.jpg"
    FRAME_LIST+=("$WORK_DIR/frame_00m00s.jpg")
fi

i=0
for f in $(ls "$WORK_DIR"/scene_*.jpg 2>/dev/null | sort); do
    [[ -f "$f" ]] || continue
    ts="${TIMESTAMPS[$i]:-0}"
    ts_int="${ts%%.*}"
    mins=$((ts_int / 60))
    secs=$((ts_int % 60))
    new_name=$(printf "frame_%02dm%02ds.jpg" "$mins" "$secs")

    # Skip if we already have a frame at 00m00s
    if [[ "$new_name" == "frame_00m00s.jpg" ]] && [[ -f "$WORK_DIR/frame_00m00s.jpg" ]]; then
        rm -f "$f"
        i=$((i + 1))
        continue
    fi

    mv "$f" "$WORK_DIR/$new_name"
    FRAME_LIST+=("$WORK_DIR/$new_name")
    i=$((i + 1))
done

TOTAL_FRAMES=${#FRAME_LIST[@]}

# --- Step 6: Audio transcription ---
TRANSCRIPT="none"
if [[ "${HAS_AUDIO:-}" == "audio" ]]; then
    echo ""
    echo "=== Audio ==="
    ffmpeg -y -i "$VIDEO" -vn -acodec pcm_s16le -ar 16000 -ac 1 "$WORK_DIR/audio.wav" 2>/dev/null || true

    if command -v whisper &>/dev/null; then
        echo "Transcribing with whisper..."
        whisper "$WORK_DIR/audio.wav" --model small --output_format txt --output_dir "$WORK_DIR" 2>/dev/null && TRANSCRIPT="$WORK_DIR/audio.txt" || echo "Transcription failed"
    elif command -v mlx_whisper &>/dev/null; then
        echo "Transcribing with mlx_whisper..."
        mlx_whisper "$WORK_DIR/audio.wav" --model mlx-community/whisper-small-mlx --output-format txt --output-dir "$WORK_DIR" 2>/dev/null && TRANSCRIPT="$WORK_DIR/audio.txt" || echo "Transcription failed"
    else
        echo "No whisper installed — skipping transcription"
        echo "Install with: pip install openai-whisper  OR  pip install mlx-whisper"
    fi
fi

# --- Output summary ---
echo ""
echo "=== Results ==="
echo "WORK_DIR=$WORK_DIR"
echo "TOTAL_FRAMES=$TOTAL_FRAMES"
echo "BATCHES=$(( (TOTAL_FRAMES + BATCH_SIZE - 1) / BATCH_SIZE ))"
echo "TRANSCRIPT=$TRANSCRIPT"
echo ""
echo "FRAMES:"
for f in "${FRAME_LIST[@]}"; do
    echo "$f"
done
