Change the video directory used by `/letmewatch:video-last`.

## Instructions

Show the current setting:

```
cat ~/.claude/video.conf 2>/dev/null || echo "Not configured yet"
```

If the user provided a path via `$ARGUMENTS`, use that. Otherwise ask them for the path.

Save it:

```
echo "<path>" > ~/.claude/video.conf
```

Confirm: "Video directory set to `<path>`. `/letmewatch:video-last` will now look here."
