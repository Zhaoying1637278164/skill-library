Analyze the video file at: $ARGUMENTS

Invoke the `letmewatch` skill to process this video. Use the extraction script at `${CLAUDE_PLUGIN_ROOT}/skills/letmewatch/video-extract.py` with the provided path.
