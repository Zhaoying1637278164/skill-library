Watch the most recently recorded video.

## Instructions

### 1. Find the video directory

Check for a configured video directory:

```
cat ~/.claude/video.conf 2>/dev/null
```

If the file exists and contains a path, use that directory.

If it does NOT exist, search common locations for video files:

```
find ~/Desktop ~/Movies ~/Downloads -maxdepth 2 -type f \( -name "*.mp4" -o -name "*.mov" -o -name "*.mkv" \) 2>/dev/null | head -10
```

Show the user what you found and ask them where their videos live. Once they tell you, save it:

```
echo "/their/chosen/path" > ~/.claude/video.conf
```

Tell them: "Saved. Next time `/letmewatch:video-last` will use this folder automatically. To change it, run `/letmewatch:video-dir`."

### 2. Find the most recent video

Find the newest video file in the configured directory:

```
find <VIDEO_DIR> -maxdepth 1 -type f \( -name "*.mp4" -o -name "*.mov" -o -name "*.mkv" -o -name "*.webm" \) -print0 | xargs -0 ls -t | head -1
```

If no videos found, tell the user.

### 3. Analyze

Tell the user which file you found (name + size + date). Then invoke the `letmewatch` skill to process it using `${CLAUDE_PLUGIN_ROOT}/skills/letmewatch/video-extract.py`.
