# Changelog

All notable changes to this project are documented in this file, reconstructed
from git history. Each line is traceable to a commit (short sha in parentheses).
Format loosely follows [Keep a Changelog](https://keepachangelog.com/).

## [3.3.2] - 2026-09-21

### Fixed
- `skills/section-by-section/SKILL.md` — the diagnosis block gains an `Elsewhere:` line, under `Does:`, for what other sections already answer that bears on the section under review. 3.3.1 told Diagnose to read the section against the section map and report nothing about it, which is the defect shape 3.3.1 set out to fix: an instruction producing nothing observable leaves no mark when it is skipped. Diagnose now names that line where it orders the comparison, rather than naming the rule abstractly
- the Also line's template said "other axes that fired" where the rule in Diagnose is "axes below" the one that gave the verdict. Two runs filed an axis above the verdict's, asserting a check had fired that had not

### Changed
- `docs/section-by-section/spec.md` — a section recording the 3.3.2 change and its validation
- `.claude-plugin/plugin.json` version 3.3.1 → 3.3.2

## [3.3.1] - 2026-09-21

### Fixed
- `skills/section-by-section/SKILL.md` — the instruction to test replacement text against the axes was skipped in production. It was an emphatic sentence inside the Write step that produced nothing observable, so its absence left no mark. A tested-text law now owns the rule once, above the loop and Assembly, and requires a `Tested:` block above any text the skill proposes for the file. Write, Assembly step 6 and Assembly step 7 each name that block in the same words, because naming the law alone fired at one step and not at another
- Diagnose reads the section against the section map before going down the axes. REMOVE on duplication, MERGE and SPLIT all depend on what the other sections say, and nothing asked for that comparison; runs that skipped it returned a clarity verdict on a section another section already owned
- redundancy's trigger covers "another section already says all of it", so a fully duplicated section stops there instead of also matching MERGE. The same boundary was tried as an added condition on MERGE and reverted: it made MERGE fire less often and cost the partial-overlap case

### Changed
- the `Tested:` block's template lists the axes one per line. A one-line template produced one-line blocks naming a single axis, whatever the surrounding prose asked for
- `docs/section-by-section/spec.md` — redundancy's trigger updated, and a section recording the 3.3.1 changes and how they were validated
- `.claude-plugin/plugin.json` version 3.3.0 → 3.3.1

## [3.3.0] - 2026-09-20

### Changed
- `skills/section-by-section/SKILL.md` — reviewed against itself, section by section, with the user closing all 40 verdicts. The separate verdict table is folded into the diagnosis ladder, which is now grouped by axis with a bullet per trigger; the numbered tests are gone, since each line's verdict already named it uniquely. Start collapses from five numbered steps to one setup exchange and one reply. The loop's steps become sub-headings and gain a flow diagram naming both user gates. Settle absorbs Interpret and answers five reply types, including a question and a catch-all reaction. Draft is renamed Write, because "draft" named the artifact, the step and the verb at once
- Assembly reorganised into three actor-marked groups; the two steps that resolve conflicts state their own resolution rather than restating the loop's
- `.claude-plugin/plugin.json` version 3.2.0 → 3.3.0

### Added
- `REPLACE` verdict — a wrong instruction previously had no verdict; every existing one preserved meaning or deleted it
- coherence and correctness axes. Correctness is judged only on evidence — an observation, or a failure the run itself hit — which is the first check to consume the observations the skill collects at Start
- progressive disclosure law beside the closure law: keep the file minimal, each thing where it is used, detail one level down
- the step the loop never named — write the replacement text, test it against the axes, show it, and file it only on the user's approval
- Assembly steps for resolving recorded gaps and for terminology drift

### Removed
- Hand-off's verdict counts and before/after line counts — both read the ledger back, and every gap and unreviewed section is already a row in it
- two of three prohibitions. "Never judge a section before Start closes" survives in meaning inside Start; the prohibition against dispatching or naming an independent review survives nowhere, since Hand-off no longer mentions one
- the body ceiling's coupling to the `efficient-md` skill. No ceiling replaces it: the description says shaping a file by how long it stays loaded is a separate pass, and an Assembly step that capped the body contradicted that boundary

### Fixed
- a coherence conflict now closes both sections, one on its verdict and one on KEEP, so the loop can record it and advance; previously the rung named no verdict at all
- a recorded GAP may carry drafted text once the user approves it, and takes a second row when it closes

## [3.2.0] - 2026-09-19

### Changed
- `skills/section-by-section/SKILL.md` — rewritten to the four-stage flow the user specified (Start → Section loop → Assembly → Hand-off). A closure law now opens the file: the skill proposes and only the user closes, so no verdict reaches the ledger that the user did not give. All eight verdicts stay and each gains a trigger, run as one ordered first-fit test inside Diagnose; REMOVE's trigger is narrowed to "the intent needs nothing this section says" so that it no longer swallows every MERGE case. Assembly changes no closed section on its own — each Assembly-time change is a proposal the user closes, with its own ledger row
- `skills/section-by-section/SKILL.md` frontmatter description rewritten to 483 characters, with its "Use when" trigger sentence and both redirects restored and the procedure text removed
- `docs/section-by-section/spec.md` — replaced. Supersedes the spec approved 2026-09-15; records the flow, the ordered test and its precedence, the closure law, the artifacts, the prohibitions, and the blank-context reading method used to validate it. Gate rulings SBS-GATE-1..3 ruled on the prior design and are kept as filed history
- README §Skills names the user as the one who closes each section
- `.claude-plugin/plugin.json` version 3.1.0 → 3.2.0

### Added
- `UNREVIEWED` marker — in a selected-sections run the untouched sections now carry a ledger row and a marker line in the draft, instead of passing through indistinguishable from sections closed KEEP
- the ledger opens with the intent anchor and the observation ids, so the two start-of-run closures leave a durable trace
- an Interpret step before the section closes, and a rule that the ledger's `reason` records the user's reason where it differs from the proposal's

## [3.1.0] - 2026-09-15

### Added
- `skills/section-by-section/SKILL.md` — reviews one existing skill or agent file with the user, section by section, testing each section against the file's stated intent and closing it with one of eight verdicts (KEEP, REMOVE, COMPRESS, REWORD, RESHAPE, MOVE, MERGE, SPLIT) plus HOLD and GAP markers; produces a draft and a verdict ledger, never edits the target; slash-only (`disable-model-invocation: true`); gated through author-agent, verdicts SBS-GATE-1..3 (`42bb650`)
- `docs/section-by-section/` — the design spec and the three filed gate rulings (`42bb650`)

### Changed
- README §Skills lists `section-by-section` and names it among the slash-command-only skills; `skills.sh.json` groups it under Writing for agents (`42bb650`)
- `.claude-plugin/plugin.json` version 3.0.1 → 3.1.0

### Debt
- `skills/efficient-md/SKILL.md` description still redirects "reviewing text that already exists" to "do that directly, no skill" (author-agent finding F7); accepted for a later gated pass, harmless while section-by-section is slash-only

## [3.0.1] - 2026-09-15

### Removed
- `evals/` — the behavioural fixture suite for the executor family and advisor-mode, the skill routing fixtures, the run records under `evals/runs/`, and `run-skill-routing.sh`; `.claude/workflows/agent-evals.js`, the runner for those fixtures (`26db95b`)

### Changed
- `release` skill: BEHAVIOR step 1 records that no fixture home exists; INTERNAL class is `.claude/` alone; E7 in `references/release-model.md` records the harness removal (`26db95b`)
- `author-agent` skill step (c): keeper findings are recorded as named fixture-debt, since no fixture home exists (`26db95b`)
- `.github/workflows/validate.yml`: JSON parse check covers `.claude-plugin/*.json` only (`26db95b`)
- README, CONTRIBUTING, `.gitignore`, `docs/executor-family/local-work.md` and `docs/executor-family/mechanical-work.md` no longer point at the removed files; the design docs keep their measurement history (`26db95b`)

## [3.0.0] - 2026-09-11

### Removed
- `skills/advisor-mode/references/ledger.md` and `skills/advisor-mode/references/absent.md` — the session ledger and the unattended/absence procedure leave advisor-mode; unattended rules are to return as a separately acquired skill (`0860182`, `53ce36e`)
- advisor-mode's mandatory session-open, bind, ledger, and close steps; Researcher is no longer part of Advisor routing (it stays for the product pipeline) (`0860182`)

### Added
- `docs/executor-family/design-decisions.md` — the executor-family design record, with rendering departures recorded for Advisor, Lead, Fast, Fast-Read, Smart, and Judge (`0860182`, `53ce36e`, `0512f74`)
- Named laws for Lead's work patterns: PLAN → Last Responsible Moment, CAMPAIGN → Value of Information, DIAGNOSE → Multiple Working Hypotheses, DELIVER → Fallacy of Composition (`53ce36e`)
- `workflows/sdd-task-loop.js`: TASK_RESULT status accepts `partial` (`0512f74`)

### Changed
- `advisor-mode` rewritten from the finalized spec: core laws in precedence order (earlier law wins), a User Authority section, judgment-based work classification with a Judge row, a per-hand dispatch table shared byte-for-byte with executor-lead, a cheapest-sufficient gate ladder, questions to the human typed as Approval / Escalation / Clarification, sections in the Advisor's loop order, five anti-patterns (`0860182`, `53ce36e`)
- `executor-lead`: skill layout and order; core and package laws with precedence; a frozen plan returns to Advisor unless integration needs judgment or delivery was asked; boundary stop covers unapproved irreversible actions and instruction-file edits; a rule for Lead's own context running out; five anti-patterns (`0860182`, `53ce36e`)
- `executor-judge`: verdicts PASS | FAIL | STOP; a fourth core law (judgment is expensive); bans in order of harm; action patterns; an explicit STOP-vs-FAIL line; a prior verdict counts only when the dispatch restates it, even when the judge is resumed (`0860182`, `53ce36e`, `0512f74`)
- `executor-smart`: skill layout; laws ordered by impact with "Judgment is expensive"; widened boundary stop; bulleted delegation rules with Fast and Fast-Read dispatch fields inline; blocked returns carry the evidence; description routes by judgment shape (`0860182`, `0512f74`)
- `executor-fast` and `executor-fast-read`: rewritten lean around execution/reporting and escalation; one-way doors cover every action; a failing VERIFY or not-reproduced REPRODUCE is reported, never a stop; a contradicted claim is a VERIFY result; executor-fast-read gains web tools (`0860182`, `0512f74`)
- `workflows/sdd-task-loop.js`: a haiku implementer's `partial` aborts to the advisor without escalating, and a merge that fails its gate says so in its abort message (`0512f74`)
- `scripts/executor-guard.sh` and `scripts/judge-dispatch-guard.sh`: deny messages tell executor-judge to return `VERDICT: STOP` instead of a STATUS field it no longer has (`f11cf24`)
- `.claude-plugin/plugin.json` and `.claude-plugin/marketplace.json` descriptions now present maddog as delegated intelligence, routing each task by the judgment it needs to executors holding only their role's authority, replacing "cheapest capable hand" and "by intelligence needed" (`d0aad1f`)
- `PHILOSOPHY.md` replaced by the six adopted principles; README, DESIGN.md, efficient-md, the review-agent checklist, and author-agent re-pointed, with author-agent's re-gate step restating prior rulings (`0860182`, `53ce36e`, `0512f74`)
- `docs/executor-family/local-work.md` and `docs/executor-family/mechanical-work.md` marked SUPERSEDED (`0860182`)

## [2.21.0] - 2026-09-10

### Added
- `docs/executor-family/local-work.md` — the smart tier's design doc and locked schema: governing sentence (grant or forbid, never coach), failure rows derived from judgment verbs, seven-field envelope with DECISIONS and DELEGATION LOG, tier-line table for laws shared with the fast hands. STATUS: ADOPTED on the filed after-run (no original fixture lost against the baseline).
- `scripts/conformance-check.py --hand smart` — refereeing the smart body against local-work.md; an unknown hand now stops with an error instead of reading the write column.
- `evals/runs/executor-smart-baseline.md` and `evals/runs/executor-smart-after.md` — filed baseline (old body, 9/13 originals) and after-run (new body, 11/13 originals, 16/22 core).

### Changed
- `executor-smart` is now a rendering of the locked schema: composition of seven kinds (no MODE line), stance / stop list / boundary-split cord up front, laws as bans with return-field teeth, no worked examples, one scope connective before the four cross-cutting laws, and the Agent tool added with a guard-enforced allowlist of executor-fast and executor-fast-read. Description gains three instances (a variant set, quantifying a claim, classifying a corpus) and one clause: it may sub-dispatch the fast hands for a slice whose decisions it has closed.
- `scripts/judge-dispatch-guard.sh` now also scopes executor-smart's dispatches to executor-fast and executor-fast-read.
- Authoring template (`.claude/skills/review-agent/references/agent-template.md`) admits the smart tier as schema-rendered from local-work.md; checker sentence lists `--hand read|write|smart`.
- `evals/executor-smart.json` v2: 20 fixtures re-keyed to the new laws; 11 added (tooth, cord, delegation, one-way doors, order of volatility, distilled).

## [2.20.0] - 2026-09-10

### Added
- `docs/executor-family/postmortems/2026-09-09-fast-tier.md` — the fast-tier postmortem for `executor-fast` and `executor-fast-read`, filed verbatim
- `.claude/skills/review-agent/references/checklist.md` gains dimension 9, ROUTING EDGES: for every router promising work to a hand under review (advisor-mode's dispatch contract and examples; any skill or agent dispatching that hand by name), checks the promise against the hand's own laws, one line per edge checked, one finding per refused promise; dimension 3 gains one sentence naming an example as a normative statement, checked against every law in the file the same way — ships via its own PR (#42, `feat/review-routing-edges`), gated ahead of and merged before this release
- `evals/executor-fast-read.json` gains a happy/trap pair for THE NULL HYPOTHESIS's absence rule (`fastread-verify-04`, `fastread-verify-05`: scoped absence resolves to CONTRADICTED, unscoped absence stays NO EVIDENCE) and a THE ANDON CORD trap (`fastread-andon-03`: two conflicting config files, both must be named)
- `evals/executor-fast.json` gains a TOTALITY, EFFECTIVE VALUE membership-doubt trap (`fast-transform-04`: a minified vendor file is a misfit, listed and left, never a stop), the write-hand pair to the new ANDON fixture (`fast-andon-04`), and a happy/trap pair for the write hand's new EXTRACT kind (`fast-extract-01`, `fast-extract-02`: copying a named log range preserves trailing whitespace and a misspelling verbatim, cleanup-tempting prompt included)

### Changed
- `docs/executor-family/mechanical-work.md`: the cord gains an "assumption that changes the work" trigger, with the misfit's own disposition — stays listed, left, never a stop — carried on TOTALITY's law line instead; the read hand's absence rule (D5') is a prohibition: nothing found is NO EVIDENCE, unless the dispatch states that a clean search of its named scope and patterns counts as CONTRADICTED (ledger E35); the write hand's stop-list line "no test proves the result" reads "no stated check decides done"; DIPLOMATIC TRANSCRIPTION's "reproduce bytes as-is" reads "reproduce text exactly as read or captured" and now binds the write hand too, via a new EXTRACT kind that copies lines, blocks, files, or log ranges to a named file; "credential or token" reads "secrets: credentials, keys, tokens, cookies, passwords" wherever it appears; every rendered law block opens with the kind(s) it binds, e.g. `(EDIT, IMPLEMENT, OPERATE)`; the return envelope (II.3) splits into a read-hand and a write-hand block, each keeping its own RESULT default (read: one line per item, file:line; write: paths changed and commands run with exit codes, EDIT/IMPLEMENT/OPERATE only)
- `agents/executor-fast.md`, `agents/executor-fast-read.md` re-rendered from the schema changes above, including the new EXTRACT law block and the per-hand envelope; `scripts/conformance-check.py`'s II.3 envelope check becomes per-hand, matching that split, with guards against a partial-field match or an unrecognized hand
- `skills/advisor-mode/SKILL.md`: an absence VERIFY dispatch now must name its scope and patterns and state that a clean search of them counts as CONTRADICTED, or the return is NO EVIDENCE; the cap sentence generalizes to "cap every return to the hand's return envelope; bulk goes to a file"; the extraction tie-break routes by what the return is for rather than sending over-cap extraction to the read hand; the two Gates examples that asked "is this referenced anywhere" now name scope and patterns

Harness: the `agent-evals` runs against the seven fixtures above are recorded
in `evals/runs/fast-tier-2.20.0.md`, not the gitignored `evals/last-run.md`.
Write-hand fixtures show no attributable regression against the shipped
2.19.0 body (9/24 candidate vs. 10/24 shipped, same day, five flipping on
noise re-run); `fast-extract-01`/`-02` are UNVERIFIED on either body, a
harness setup-fidelity defect at `.claude/workflows/agent-evals.js:214-220`,
not a law failure. Read-hand fixtures `fastread-verify-04`/`-05`:
`fastread-verify-04` passes (scoped, dispatch-stated); `fastread-verify-02`/`-05` fail identically on the shipped body (unscoped-absence overclaim, debt D-D).

## [2.19.0] - 2026-09-08

### Changed
- `plain-english` description gains one proactive trigger sentence, "Also use before asking the user to choose between options.", so the skill fires before the model asks the user to pick between options; reactive cues and the efficient-md redirect are unchanged
- Laws 1, 4, 6, and 7 each gain one sentence giving the reason behind the rule; law 3 gains a counter-example pairing "the decision lives upstream" with "the platform team decides this first"; law 8 loses its duplicate third sentence. Body grows from 291 to 356 words, longest sentence 23 words, no em-dashes
- `evals/plain-english.json` gains two routing fixtures: `plain-route-07` (proactive cue, expects `plain-english`; 5/5 on the new description, 0/5 on the old) and `plain-route-08` (dense design doc, expects `efficient-md`; 5/5), both non-core pending a second measured run; the harness note records `plain-route-04` as pre-existing flaky debt (23/30 old description, 25/35 new, every miss "none"), owned by mine-session's description

Gated over two executor-judge rounds (round 1: four REWORK findings; round 2: all APPLY), findings G1–G11 and H1–H4 filed in the author-agent packet; three full-fixture runs on the shipped text: one 8/8 with every fixture 5/5, one 8/8 with plain-route-04 at 4/5, one 7/8 with core plain-route-02 at 3/5 whose two misses were conversational replies rather than skill names; route-02 re-measured at 9/10 on both the old and the new description, one conversational stray each.

## [2.18.0] - 2026-09-07

### Added
- `evals/efficient-md.json` — seven routing fixtures for efficient-md's trigger boundary (one report-only; `emd-probe-02` non-gating because its misses are answer format, never a skill name)

### Changed
- `efficient-md` description rewritten to the description standard's four-slot shape: claims README, names `AGENTS.md` as the generic instruction file in place of `CLAUDE.md`, seven grouped trigger situations; the class table and `references/model.md` updated to match
- README's efficient-md bullet states the same scope as the description
- `references/warm.md` and `references/cold.md` gain an Anti-pattern paragraph, matching `hot.md` and `channel.md`
- `evals/plain-english.json`: `plain-route-05` and `plain-route-06` promoted to core on three measured runs (05: 4/5, 4/5, 5/5, one over-trigger on two of them; 06: 5/5 on all three)

### Fixed
- `SKILL.md` SHIP RULE step 5 restores "or absent", dropped in an earlier compaction, matching `references/model.md`

Gated over four judge rounds; rulings and routing runs cited in the release PR.
Debt: no `AGENTS.md` exists at this repo's root while the shipped HOT row names one; the release ritual has no citation-existence check for deleted references.

## [2.17.0] - 2026-09-06

### Added
- `docs/executor-family/mechanical-work.md` — the reasoning behind the cheap tier's design and the locked schema it renders from: eight failure rows, cross-cutting laws, the return envelope, and the mapping from rows to modes (`128244e`)
- `scripts/conformance-check.py` — checks that a rendered agent body carries the schema's locked text (each law's name and sentence, the cross-cutting laws, the stance, the stop list, the envelope) verbatim for its hand, and that its tools line matches (`b8648b7`, `b0e7cf3`)

### Changed
- `executor-fast` and `executor-fast-read` are now renderings of the locked schema in `docs/executor-family/mechanical-work.md`: seven kinds of action on `executor-fast` (EDIT, TRANSFORM, GATE, OPERATE, RECOVER, REPRODUCE, IMPLEMENT) and three on `executor-fast-read` (RECON, EXTRACT, VERIFY), each carrying its law by name and sentence; the return envelope (STATUS/BLOCKED-ON/RESULT/NOT DONE/NOTES) no longer carries a MODE line (`92a7e24`, `4b33b2d`)
- Mode DIAGNOSE is renamed REPRODUCE: the fast hand reproduces a reported failure and delivers that trigger, never a claimed cause (`92a7e24`, `128244e`)
- Both fast hands lose the Skill tool: `executor-fast` now holds Read, Write, Edit, Bash, Glob, Grep; `executor-fast-read` now holds Read, Glob, Grep (`92a7e24`, `4b33b2d`)
- `review-agent` gains a schema-rendered review tier: for a body carrying the locked schema text, conformance is checked by `scripts/conformance-check.py` first, and the reviewer's own judgment is then limited to the rendering — definitions, instance lists, connective prose, frontmatter; `author-agent`'s authoring loop learned the same split (`f9fbc33`, `e66fcf6`)
- Behavioural fixtures for both fast hands rewritten against the schema's laws, with happy and trap coverage per law; each fixture's `law` field now names the schema's law exactly as it appears on its LAW line — 33 fixtures in `evals/executor-fast.json`, 22 in `evals/executor-fast-read.json` (`e675160`)
- README's routing paragraph reworded for the read hand: it locates, quotes, or verifies, rather than "reproduces" — the read hand never reproduces a failure, only the write hand does (`4b33b2d`)
- `.gitignore` now excludes `__pycache__/` (`b8648b7`)
- The executor-family schema's locked spans were compressed to a 32-word-per-block budget, with three write-hand exceptions at 42 (the reproduction law, DISTILLED, ONE-WAY DOORS) and one read-hand exception at 33 (DISTILLED); every law keeps its substance, laws render as their own blocks after the kinds they bind, and no block carries a cross-reference. `executor-fast` is now 648 words and `executor-fast-read` 467, down from 1084 and 732. `scripts/conformance-check.py` now reads the schema's per-hand stop list and fails cleanly, rather than raising, on a body missing its `NOTES:` line.

Frontmatter descriptions of both agents are unchanged; routing between them is
unaffected.

## [2.16.0] - 2026-09-01

### Changed
- `executor-fast-read` loses the Write capability: it now holds exactly Read, Glob, Grep, Skill and changes nothing at all, resolving the contradiction between its read-only description and its one permitted write
- Bulk extraction that needs its result filed to disk now routes to `executor-fast`, which already holds Write

### Removed
- `scripts/executor-fast-read-write-guard.sh` and its `hooks/hooks.json` `Write` matcher — the hand's sole containment mechanism, no longer needed once it holds no Write tool

## [2.15.0] - 2026-09-01

### Added
- `executor-fast-read` — a read-only executor on the cheap tier holding no shell and no edit capability, available for reconnaissance, extraction, and verification tasks

### Changed
- `executor-fast` drops reconnaissance, extraction, and verification modes; now retains seven modes for analysis and implementation tasks
- Judge's dispatch allowlist now permits only `executor-fast-read` and `researcher`, closing a path by which the judge could hand a fix to a subordinate that writes
- New hook confines `executor-fast-read`'s writes to temporary locations, which is the sole containment for that hand
- Removed the "if the project defines its own executor agent, prefer it at the same tier" clause from `executor-fast`, `executor-smart`, and `executor-lead` — an assumption imported from another repository that does not hold generally; `agents/product-ux.md` still carries its own version of this clause, untouched this release
- The four product agents (`product-be`, `product-pm`, `product-ui`, `product-ux`) and `workflows/sdd-task-loop.js`'s brief-lint step had their reconnaissance/lint dispatches retargeted from `executor-fast` to `executor-fast-read`
- `skills/advisor-mode`: mechanical class splits into read hand (no shell, no edit capability) and write hand in structural contract; binding record notes mechanical names two; split test routes read-only tasks to read hand, change-or-run tasks to write hand

### Fixed
- Redirect check that denied `/dev/null` for write-denied agents, which was blocking ordinary reconnaissance for the lead and the judge

## [2.14.2] - 2026-08-31

### Fixed
- `scripts/executor-guard.sh`: command-segmentation bypass — a bare `&` (background operator) was not treated as a segment boundary, so commands after it were never examined; bare `&` now ends a segment in chain mode (with redirector exceptions), and segments whose leading word opens a subshell, brace group, or arithmetic construct are refused as unparseable. This does not close the whole class of hiding techniques: a wrapper command, command substitution, or an escaped or quoted leading word still hides the real command

## [2.14.1] - 2026-08-31

### Fixed
- `scripts/executor-guard.sh`: path-confinement bypass in recursive-delete check — paths reaching a protected location through `..`, through a symlink, through a trailing slash, through brace expansion, or through an unexpanded shell variable were treated as temporary and allowed; path resolution now happens before the check, temporary-location prefixes are anchored rather than matched anywhere in the string, and a path token carrying unexpanded shell syntax is refused
- `scripts/path-guard-lib.sh`: new shared library for path-confinement logic, enabling a second hook to reuse the validation

## [2.14.0] - 2026-08-30

### Added
- `skills.sh.json` — three groupings ("Session discipline", "Writing for agents", "Product pipeline") with `notGrouped: "bottom"` for ungrouped skills (`192eaca`)
- README install line `npx skills add Harish-here/maddog` for skills.sh discovery, alongside the existing plugin install (`192eaca`, `f663600`)

### Changed
- `release`, `author-agent`, `review-agent` skills marked `metadata.internal: true`, hiding them from skills.sh discovery (`192eaca`)
- release taxonomy classifies `skills.sh.json` as DOCS (`f49ceec`)

## [2.13.0] - 2026-08-30

### Added
- `DESIGN.md` 1.0.0 — the visual identity (black-and-white with amber and ink-blue accents; typography, text contrast, wording rules, versioning), linked from README and CLAUDE.md (`bcf0692`, `9296c04`, `cf1f229`)
- `assets/wordmark.txt` (figlet ansi_shadow MADDOG with a double-rule "Skills & Agents" band, 53×10) and `assets/wordmark-ascii.txt` (figlet slant fallback, 43×10); README masthead now carries the wordmark block with `# maddog` beneath (`cf1f229`)

### Changed
- release taxonomy classifies `DESIGN.md` and `assets/` as DOCS (`306efbe`); adversarial judge review of DESIGN.md and the lockup, two rounds, all findings applied before `cf1f229`

## [2.12.1] - 2026-08-30

### Added
- `PHILOSOPHY.md` — five design points, harness-neutral (`f4c4d7a`)

### Changed
- `README.md` — rewritten with a philosophy section and agents grouped by family (`f4c4d7a`)
- `CLAUDE.md` — rewritten under the efficient-md HOT law: pointers to PHILOSOPHY.md, README.md, CONTRIBUTING.md; publishing rule; three invariants (lead/judge no-edit, adapter set, .claude/ not a plugin surface); distribution mechanics verified against the plugin docs (`ecc93d8`, `feed37d`)
- `CONTRIBUTING.md` — stale pointer retargeted (`f4c4d7a`)
- `.claude/skills/release/SKILL.md`, `references/release-model.md` — `PHILOSOPHY.md` classed DOCS; `install.sh`, the E16 populated-fixture probe, and the symlink clause removed (gone since 2.11.0); release model revision bumped to 11 (`f4c4d7a`)
- `.claude-plugin/plugin.json`, `.claude-plugin/marketplace.json` — descriptions rewritten for adopters: what it does, not a list of component names (`6a95e31`)

## [2.12.0] - 2026-08-27

### Added
- `scripts/judge-dispatch-guard.sh` — a PreToolUse hook on the `Agent` tool denying `executor-judge` any dispatch target but `executor-fast` or `researcher`, including a dispatch naming no target at all (which runs the default general-purpose agent, holding every tool); payload field names confirmed against captured live payloads
- `evals/`: 16 behavioural fixtures covering the eight mode laws that had none — fast TRANSFORM/RECOVER, smart PORT/DECOMPOSE, lead CAMPAIGN/DELIVER, judge DESIGN-REVIEW/ADJUDICATE — one happy case and one trap each, all core
- `advisor-mode`: gains the named rule ONE TASK, ONE HAND — a task that already has a hand keeps it; a fresh dispatch is now the exception and must name its reason (class change, spent ceiling, half-full context, a rejected or failed return, or a long idle). Note: 2.11.1's prohibition on opening a fresh dispatch for resumable work did not bind in practice — this rule inverts the default instead of restating the prohibition

### Changed
- `agents/executor-fast.md`, `executor-smart.md`, `executor-lead.md`, `executor-judge.md`: all four descriptions rewritten against the description standard and the checklist's five-slot shape — family resident cost fell from 4,567 to about 3,380 characters while gaining positive claimants for debugging, git/operations work, migrations, splitting and authoring, which no description previously claimed; `executor-lead` fell from 1,786 to 861 characters, and all four are now under the 1,024-character cap

### Fixed
- `scripts/executor-guard.sh`: now denies the common file-writing Bash forms for lead and judge (glued redirects, inline interpreters, `git rm`/`git mv`), extends irreversible-command coverage to `executor-smart`, denies `git merge` and `git worktree remove`/`prune` for all four, catches the `+ref` force-push form and `find -delete` and `git branch --delete --force`, and matches the temp carve-out on a path component rather than a substring; a quote-handling bug in its command splitter that blocked legitimate searches containing a pipe is fixed
- `agents/executor-lead.md`: regains the precedence clause its satisficing law had lost
- `CLAUDE.md`, `README.md`: no longer claim enforcement the guards did not deliver

## [2.11.1] - 2026-08-27

### Fixed
- `advisor-mode`: the general resume rule was stated as a permission ("a dependency test decides whether B MAY resume A's agent"), so it never fired reliably — only the judge's resume (stated as an instruction) did; in one session, 19 dispatches produced exactly 1 resume, though 4 more passed the dependency test and were spawned fresh anyway. The Resume section's first paragraph now ends with an explicit prohibition: "Never open a fresh dispatch for work that passes the dependency test while that hand may still be resumed." (`f067e54`)
- `advisor-mode`: the ceilings paragraph never stated what its counts are measured against — "per class, never per session" read as either per-task or per-session; now explicit: "count per task chain, never per session." Replaced the token-budget numbers (which had silently replaced the hard counts on harnesses reporting spend in tokens, and which were meaningless without a context-window size the advisor never receives) with a softer, harness-agnostic brake: stop when the hand's context is half full, dispatch fresh after a long idle with prior findings supplied verbatim (`f067e54`)
- `advisor-mode`: the judge paragraph's long-idle rule is now stated once, in the general ceilings paragraph, instead of being duplicated with a judge-specific token number (`f067e54`)

## [2.11.0] - 2026-08-27

### Fixed
- `README.md`: the documented watchdog-setup command no longer globs blindly across every cached plugin version — it now picks the newest cache directory, avoiding a silent wrong-version pick once a second release ships (RULE finding)
- `SECURITY.md`: corrected the claim that `setup-watchdog.sh` is the only script touching the machine outside the repo — `tg-notify.sh` and `watchdog-resume.sh` also do, once wired up (RULE finding)
- `scripts/executor-guard.sh`: header comment no longer describes the deleted symlink-mode wiring path (RULE finding)
- `permissionMode: dontAsk` removed from `executor-fast`, `executor-smart`, `executor-lead`, `executor-judge` frontmatter — it only ever took effect under symlink installs, which no longer exist (RULE finding)

### Removed
- `install.sh` and the symlink install mode — plugin-only distribution now; the two-install-modes framing is gone from `README.md` and `CLAUDE.md` (`0fe22f2`)
- dead `hooks:` frontmatter blocks in `agents/executor-fast.md`, `agents/executor-lead.md`, `agents/executor-judge.md` — ignored under plugin installs already, and now unused since symlink mode is gone (`0fe22f2`)

### Added
- `scripts/setup-watchdog.sh` — optional, maintainer-run script that wires the watchdog LaunchAgent and Telegram notify script, since a plugin install can't do this automatically; extracted from `install.sh`'s watchdog/notify logic only (`0fe22f2`)

### Changed
- `README.md`, `SECURITY.md`, `skills/advisor-mode/references/absent.md`: symlink-mode references replaced with the opt-in watchdog-setup story (`0fe22f2`)

## [2.10.0] - 2026-08-27

### Changed
- `advisor-mode`: the binding record is no longer written to a file at session open — the advisor binds at session open and holds the record in context, writing it once as the ledger's first entry when a ledger opens; Own Hands' Write allowance no longer names a binding record file
- `advisor-mode`: Session Open gains a scope line — efficient-md governs artifacts, this skill's own contracts govern its own: dispatch prompts and returns follow the Dispatch Contract, the ledger follows `references/ledger.md`
- `advisor-mode`: Own Hands now permits the advisor to run a read-only command itself, both conditions required — it only reads, and it checks a claim in a return the advisor holds; previously reading a cited file:line was allowed but every command was forbidden, leaving command-only verification unsettled; the Survey bullet's blanket "No other command is yours" is removed, since it contradicted this exception
- `advisor-mode`: the Dispatch Contract gains three rules — name the authoritative source instead of pasting when a file is out of date, a dispatch authoring a markdown artifact names the artifact's class so a hand holding the Skill tool invokes efficient-md and any other hand is given the path to that class's reference, and every OUTPUT FORMAT heading carries its own ceiling (`OUTPUT FORMAT (< 600 words)`, the number set per task)
- `references/ledger.md`: BINDING RECORD and ROUTING PRECONDITION rewritten to match the binding-record change — bound at session open and held in context, written as the ledger's first entry once a ledger opens
- `executor-fast`, `executor-smart`: `Skill` added to `tools:`, with the law "Never invoke a skill the dispatch did not name" — the grant lets them invoke efficient-md when a dispatch names it, the prohibition stops a cheap hand pulling in skills nobody asked for
- `agent-evals`: the workflow moves from `workflows/` to `.claude/workflows/` — it is maintainer-only, invoked via `scriptPath`, and no longer part of the shipped set; `.gitignore`, `README`, `CLAUDE.md`, and `evals/author-agent.json` updated to match (`edb58cf`, `2e725dc`)

## [2.9.0] - 2026-08-26

### Changed
- `advisor-mode`: memory write is no longer a CLOSE obligation — a one-line candidate batch is presented at CLOSE and written only with the user's approval; a zero-memory session is steady state, not a failure (D1)
- `advisor-mode`: resume extended to every hand — a dependency test decides reuse, ceilings set per class (mechanical 2, local 4, iterated 2, web-perception 2 resumes, adversarial 3 rounds per artifact, with a token-spend override), and the judge gets three rounds per artifact with a tighter running-skill bound always winning (D2)
- `advisor-mode`: context overhead ruled tolerable at current levels — the existing laws (return cap, give-the-path, filed rulings, artifacts not conversation) stay as-is; the resume rule is the new saving lever (D3)
- `advisor-mode`: implementation detail removed from the body — the "nothing enforces this" disclaimer, the gate-filing mechanism's literal wording, the State section's unattended-procedure contents list, and the "guarantees live in tool restrictions" line; DELEGATION LOG stays named as a guaranteed family return slot, and the one-sentence definition of "unattended" stays resident in State (D4)
- `advisor-mode`: body cut from 2,621 words to 2,495 words. The cut removed justification and implementation detail. Every example and edge case survived. New Resume and Session Open sections were added (D5)
- `advisor-mode`: body restructured — the Budgets frame is dropped (Own Context and User Attention are top-level), Iterated Trigger folds into Routing, a new Session Open section covers efficient-md/survey/bind, and a new Resume section covers D2; the binding record is now written silently to the advisor's own scratchpad file at session open and stated only on request or when degraded/unbound (R-F15), and the Ledger section's opening narrative moves to `references/ledger.md` (D6)
- `advisor-mode`: body rewritten to a plain declarative standard — one rule per sentence, active voice, the doer named, no nested clauses, no parentheticals, at most one em-dash per sentence; every example and "the thought that means you are about to break this rule" line survives (D7)
- `references/ledger.md`: CLOSE's discharge condition now matches D1 — the surfacing batch plus any user-approved memory candidate while the user is present, the surfacing batch alone while absent
- `references/ledger.md`: the routing gate now keys on the binding record existing (the session-open scratchpad file, or the ledger's first entry), never on the record being spoken to the user; gains an Opening section carrying the ledger's open-trigger and departure-shape narrative moved from `SKILL.md`

### Added
- `evals/advisor-mode.json`: three behaviour fixtures pinning D1 and D2 — `memory-bar-close` (no memory write before approval), `resume-fresh-after-rejection`, and `resume-dependent-task-same-class`


## [2.8.0] - 2026-08-26

### Changed
- `advisor-mode`: description rewritten to the description-standard contract — "Use when …" triggers replace imperative second person and the restated body norms, and the family names it dropped so it stops contradicting "this table names no agents" (F8, F9)
- `advisor-mode`: the ledger now opens at the launch decision for a dispatch the user will not be present for, not after they have already left; USER PRESENCE flips only on the actual departure, so a scope call raised at launch still reaches the user attended (F1, F6)
- `absent.md` gains §6 MID-FLIGHT DEPARTURE — a user leaving mid-dispatch now opens the ledger and starts the watchdog/resume record without killing the running dispatch
- `advisor-mode`: Bind's `kept` class is stated Exempt rather than left unroutable — `kept` is never for sale and could never satisfy "name a hand for every class" (F3)
- `advisor-mode`: Survey now names reading agents' frontmatter `tools:` line alongside descriptions, matching what Bind's verification actually demands; Own Hands' Read allowance closes the same way Survey's does (F2, F5)
- `advisor-mode`: efficient-md's BIND invocation now cites the installed-skill list already in session context as its discovery evidence (F4)
- `advisor-mode`: Gates permits and requires glossing a finding ID in one plain-word line at first use per message, resolving the contradiction with plain-english's session-coined-label rule (F7)
- `advisor-mode`: the iterated buy-in test and the same-file dispatch rule each collapse to one statement, cutting their near-duplicate copies (F10, F11)
- `README.md`: Advisor row notes the one-time Survey as its sole exception to "never does mechanical work" (F13)

### Added
- `evals/advisor-mode.json`: behaviour fixtures pinning F1/F6, F3, and F7 against regression, no runner exists for behaviour fixtures (debt E24); hand-executed status is recorded in the release PR

## [2.7.0] - 2026-08-25

### Added
- `plain-english`: skill governing the wording of replies and questions to the user — answer first, explain every term the reader may not know, spell out session-coined labels at first use in each message, no coined terms or metaphors, full short active sentences, no "not X, but Y", say it once, one em-dash per sentence, caveats only when they change the decision, and a 2–5 sentence preamble before every question to the user. Session-wide use needs an invoke-first line in the user's CLAUDE.md; nothing shipped invokes it automatically.
- `evals/plain-english.json`: routing fixtures against efficient-md and mine-session for `evals/run-skill-routing.sh`, plus behaviour fixtures recorded as runner debt

## [2.6.0] - 2026-08-25

### Changed
- `advisor-mode`: OWN HANDS rewritten as WHEN / WHEN NOT closed lists — the advisor writes only the ledger, memory, and the handover file, reads only user-given material, its own references, and a return's cited line, and runs no command except the one BIND survey; the Coase cost clause and the "short synchronous probes" category are removed, and no enforcement hook is claimed (`6f374cc`)
- `advisor-mode`: GATES section replaces "never self-judge" — an independent verdict is bought only when the user is absent for the run, the act is irreversible, or a running skill names a judge; command-answerable questions are mechanical VERIFY; one re-gate per artifact, a second BLOCKED goes to the user; the routing table's adversarial example now shows an unattended-run prompt instead of self-review (`6f374cc`)
- `advisor-mode`: the decision ledger opens only when USER PRESENCE flips to absent and is prohibited while the user is present; attended decisions go to the surfacing batch and memory; CLOSE binds per package on those two acts and at session end on "dispatched anything → memory written", replacing the non-empty-ledger trigger (`6f374cc`)
- `advisor-mode`: LEDGER LAW body moved from SKILL.md into `references/ledger.md` (Law + Contract sections); `references/contract-decision-ledger.md` removed; `absent.md`'s move-the-ledger durability procedure replaced (the ledger is born on the durable path) (`6f374cc`)
- `advisor-mode`: `absent.md`'s watchdog, run-start/complete pings, resume-record writes, cheap-resume attempt, dispatch-start confirmation, and `unattended-start.sh` are now run by mechanical hands — the advisor's own-hands law admits no command but the BIND survey (`52383d8`, `5ab9f1d`)
- `advisor-mode`: Dispatch Contract's efficient-md clause restated — invoke-at-BIND kept as an unenforced obligation, plus two prohibitions (never inline what a path can carry; never accept an uncapped return); Bind, Dispatch Contract, Own Hands, Gates, The Ledger headings gain plain descriptors (`6f374cc`)
- `executor-lead` description, README, Iterated Trigger: an attended main-thread package stays with the advisor "while the advisor's own context suffices" — the "own decision ledger" qualifier is gone with the attended ledger (`6f374cc`)

## [2.5.2] - 2026-08-24

### Fixed
- `release`: the `maddog--vX.Y.Z` tag was modelled as a "directory submission pin" — Anthropic's docs say the directory CI re-pins on every push and that tag serves dependents' semver constraints (`plugin-dependencies.md`); E3/D2 corrected, new evidence E21
- `release`: SEAL now runs `claude plugin tag --push` beside the `vX.Y.Z` tag; the second-channel check is retired (L12: one mechanism in, one out)

## [2.5.1] - 2026-08-24

### Fixed
- `.claude-plugin`: `plugin.json` and `marketplace.json` descriptions now list the `efficient-md` skill, shipped since 2.5.0 but absent from both manifest texts

## [2.5.0] - 2026-08-18

### Added
- `efficient-md`: new skill — context-residency authoring doctrine (HOT/WARM/COLD/CHANNEL + HUMAN overlay classification, canonical model, per-class exemplar references), shipped initially as `skills/token-residency` (`84350a2`)
- `advisor-mode`: repo-specific decision-ledger contract split out of the generic doctrine into `skills/advisor-mode/references/contract-decision-ledger.md`, so no reader holds a contract citing law they cannot load (`84350a2`)

### Changed
- `token-residency` renamed to `efficient-md` (the handle optimizes for the person; the doctrine keeps its Token-Residency name in the references); description rewritten generic — no internal-only skill names in a shipped skill's routing text; inbound pointers added from `advisor-mode`'s DISPATCH CONTRACT and `author-agent`'s CREATE branch (`4a3c32d`)
- `author-agent`: prohibition-shaped all three rework-budget scope brakes — step 0's cost line must quote an exact count of covered rework rounds before a mid-loop thread or overage round may run; step 1's model-artifact build is prohibited until its own green-lit cost line exists; the covered-round unit is every gate-ruling request after the first, refusals included, closing the apply-with-cuts dodge (`599ae67`, `d72df67`)
- `efficient-md`: dropped the `references/evidence.md` research-table digest; primary-source pointers now ride each Grounding bullet inline (`f41e1f5`)

## [2.4.0] - 2026-08-17

### Added
- `advisor-mode`: THE LEDGER LAW — when/what/how-often contract for the session decision ledger: entries only at decision events, aggregated by event; rationale + reopen-condition per decision; citations as pointers, never restated content; prunable OPEN index; filed entries immutable (`8f81d18`)

### Changed
- `absent.md`: §1 LEDGER FILE → LEDGER DURABILITY — the ledger already exists per the core law; going unattended relocates it plus scratch-cited artifacts to a durable path and re-points citations, the sole sanctioned edit of a filed entry (`8f81d18`)

## [2.3.0] - 2026-08-17

### Added
- `release`: internal release-engineering skill (`/release`) encoding the six-phase ritual (DECLARE→SEAL), REMEDY incident lane, and twelve laws; locked design model committed alongside as its reference (`f736c6a`)

## [2.2.0] - 2026-08-17

### Removed
- `grind`, `grind-pro` skills — `advisor-mode`'s judgment-class routing supersedes the two thin dispatch skills; agents (`executor-fast`, `executor-smart`) unchanged (`849edbb`)

## [2.1.0] - 2026-08-17

### Changed
- `advisor-mode`: full SKILL.md rewrite — BIND contract-checked class binding with visible degradation, never silent substitution; routing redefined as six classes bonded by judgment (mechanical/local/iterated) or structural property (adversarial/web-perception/kept), each with a tier-matched temptation example; four-category own-hands charter (claim verification, state artifacts, session bootstrap, short synchronous probes); PURPOSE line added to the dispatch contract; proportional acceptance spot-checking; BIND and CLOSE stated as prohibitions, not procedures (`367b92d`)
- `absent.md`: channel discovery is per-session, never assumed, with a per-install-mode trigger — plugin installs ship no watchdog/notify script by default; symlink installs must confirm the watchdog LaunchAgent is actually bootstrapped, not just written (`367b92d`)
- `executor-lead`, README: iterated class gains the attended/context qualifier — buy lead only when the package must survive outside the advisor's own context (absence, parallelism with the main thread, context scarcity); an attended package held as the session's main thread stays with the advisor's own ledger (`dde6b4f`)

## [2.0.0] - 2026-08-16

### Changed
- Plugin and repository renamed `maddog-skills` → `maddog` (breaking for plugin
  installs: reinstall as `maddog@maddog`); the repo URL redirects from the old name.

## [1.9.0] - 2026-08-16

### Added
- `author-agent`: gated authoring loop skill, review-agent partition, routing eval (`6d5a602`)
- `mine-session`: session pattern-mining skill, core-aware routing harness (`91d9368`)

### Fixed
- Law, example, and return-contract hardening across the agent family (`ea780cd`)

### Docs
- Replaced model pins with tier words in `CLAUDE.md` (`c27a893`)

## [1.8.0] - 2026-08-16

### Chore
- Re-homed `review-agent` to `.claude/skills`, added an agent template, pruned dead links (`348b1cc`)

## [1.7.0] - 2026-08-15

### Added
- `review-agent`: TDD-built skill for agent-definition reviews, superseding the draft checklist doc (`abec4ed`)

### Fixed
- Judge return contract and triggers, guard hooks on lead/judge, smart claims routine reviews (`57cae76`)
- `advisor-mode`: absent liturgy header matches the broadened unattended trigger (`37e881d`)
- Applied PR #2 change-review findings (`dee7642`)

### Docs
- Drafted a checklist for reviewing agent definitions (`7dd1ada`)

## [1.6.0] - 2026-08-14

### Added
- Plugin-ready guard hook, portable dual-mode wiring (`113ef57`)
- `executor-lead` as judgment-with-memory; added `executor-judge` (`616da5d`)
- Widened the guard hook to `executor-lead` and `executor-judge` (`9d8fbd4`)
- Lean eval fixture sets for lead and judge, plus harness wiring (`a1ceb9f`)
- `advisor-mode`: three-budget core, 2x2 state model, absent liturgy (`7b9581e`)

### Docs
- Intelligence-budget doctrine documenting the five-role family (`4f61496`)

### Chore
- Plugin description updated to reflect the five-role manifest (`bda5158`)

## [1.5.1] - 2026-08-14

### Added
- `permissionMode: dontAsk` on both executor tiers (`c0b063b`)
- `PreToolUse` guard hook for irreversible commands on `executor-fast` (`3d106bb`)
- `NOTES CONTRACT` happy/trap eval pair for `executor-fast` (`93a0b14`)

### Fixed
- Reverted `executor-smart` to remove the Agent tool and the DELEGATE DOWN law; dropped two stale dispatching references (`7ef7490`, `61ef14a`)
- `executor-fast`: NOTES reports what you did, never what the data means (`b584732`)

### Docs
- README covering modes, delegation and evals (`33dbd10`)

## [1.5.0] - 2026-08-13

### Added
- `executor-fast` classified into eight modes, each with a named law (`73dde95`), later synthesised to four modes with per-task effort and a rebuilt delegation fixture (`db463c3`)
- `executor-smart` given six modes with named laws, plus autonomous delegation to `executor-fast` (`dc9add5`)
- `executor-fast`: stop-don't-guess elevated to a named law, the andon cord (`07cdd2f`)
- `agent-evals` workflow to run 39 behavioural fixtures against the real agents (`eddb251`, `9c811c7`), with effort pinned high and measured, not assumed (`44bb818`)
- `product-*`: closed the mockup-fidelity gaps in the product pipeline (`4f3c3cb`)

### Fixed
- `product-engineering`: unattended watchdog now spans EXECUTE+QA (`cefcdac`)

### Changed
- Executors refactored with a dispatch contract; audited dead weight cut (`e06fd9e`)

### Docs
- Added `CLAUDE.md` — repo orientation, install modes, validation model (`f30ab61`)

## [1.4.0] - 2026-08-11

### Added
- `product-engineering` pipeline extended to BE planning, execution, and QA -> PR (`dcbe6f3`)

### Fixed
- Baked the routing rule into descriptions — prefer a repo-local executor at the same tier (`7d30742`)
- Routed stateful choreography to smart and barred frozen plans from lead — eval-driven description fixes (`1eca87e`)

### Changed
- Renamed the `product-team` skill to `product-engineering` (`f31dfea`)

## [1.3.0] - 2026-08-10

### Added
- `product-team` planning pipeline — PM -> UX -> UI, three discipline agents plus researcher and an orchestrating skill (`43583f7`)

### Docs
- `advisor-mode`: launch-contract pointer, watchdog state carve-out, user doctrine edits (`0716163`)

## [1.2.0] - 2026-08-08

### Added
- `sdd-task-loop`: per-task implementer tier (`tasks[].model`, bounded, flagged-refuses-haiku) (`fff1c47`)
- `watchdog`: tmux auto-resume for session-limit pauses (script + launch-contract item 5) (`ce6d889`)
- `watchdog`: standing-mode resume state — tmux-hosted runs self-heal across host restarts, with crash-loop quarantine (`1c052db`)
- `sdd-task-loop`: escalation-on-red — haiku implementer failures retry once on sonnet before aborting (`6150d60`)

### Fixed
- `watchdog`: launch claude via interactive login shell — cron-stripped env lacks auth vars (`790ac65`)
- `sdd-task-loop` review fixes — fail-closed lint, `implementerAgent` param, up-front validation, blocked-only escalation with trace, parallel fall-through, discipline parameterization, null-review guards, tier polish (`0384952`)
- `watchdog` review fixes — lock breaker, scoped crash-loop guard, verified launch with REPL readiness poll, numeric guards, session param, HOME-templated plist + install wiring, unattended-runs docs (`d19dcd3`)

### Docs
- `watchdog` uses launchd, not cron — keychain auth needs the GUI session, live-tested; plist template (`c33bc6a`)
- `sdd-task-loop`: file-artifact briefs — copy-then-verify convention + lint existence check (`abc7443`)

### Chore
- Deduped agent frontmatter model keys; bumped plugin to 1.2.0 (`8ee340f`)

## [1.1.0] - 2026-08-07

### Added
- `sdd-task-loop` v2 workflow, telegram checkpoint pings, pinned executor model tiers (`733265b`)

## [1.0.0] - 2026-08-01

### Added
- Advisor-executor hierarchy — 3 agents, 3 skills, symlink installer (`ec639bc`, pre-`plugin.json`, folded into this release)
- Packaged as a Claude Code plugin with a self-hosted marketplace (`eb13491`)
