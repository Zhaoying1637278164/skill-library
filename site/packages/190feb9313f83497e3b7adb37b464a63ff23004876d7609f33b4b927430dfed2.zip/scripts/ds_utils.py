#!/usr/bin/env python3
"""
ds_utils.py — Shared utility library for Dataslayer marketing skills.

Every function here replaces ad-hoc logic that was previously scattered
across SKILL.md files and executed inconsistently by each skill/agent.

Usage from any skill:
    python scripts/ds_utils.py <command> [args...]

Or import as module:
    from ds_utils import strip_utm, aggregate_by_url, calculate_mrr

Commands:
    process-ga4-pages <input.tsv>    Strip UTMs, aggregate, classify pages
    process-sc-queries <input.tsv>   Classify queries into SEO buckets
    process-stripe-subs <input.tsv>  Calculate MRR, churn, risk tiers
    process-stripe-charges <input.tsv>  Payment failure analysis
    process-campaigns <input.tsv>    Detect paused campaigns, daily stats
    detect-conversion <input.tsv>    Find which GA4 event has real data
    validate <input.tsv> <source>    Validate MCP result integrity
"""

import csv
import json
import logging
import sys
import os
from collections import defaultdict
from datetime import datetime, timedelta
from urllib.parse import urlparse, parse_qs
from io import StringIO

# ═══════════════════════════════════════════════════════════════════════════
# LOGGING — writes to stderr so stdout stays clean for JSON output.
# Set DS_UTILS_DEBUG=1 to see debug messages.
# ═══════════════════════════════════════════════════════════════════════════
_log_level = logging.DEBUG if os.environ.get("DS_UTILS_DEBUG") else logging.WARNING
logging.basicConfig(
    stream=sys.stderr,
    level=_log_level,
    format="[ds_utils] %(levelname)s: %(message)s",
)
log = logging.getLogger("ds_utils")


# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION — Override via ds_utils_config.json or environment variables
# ═══════════════════════════════════════════════════════════════════════════

# Default configuration (works for most B2B SaaS sites)
_DEFAULT_CONFIG = {
    # URL patterns for content/blog pages (case-insensitive substring match)
    "blog_patterns": ["/blog/", "/articles/", "/posts/"],
    # URL patterns for app/internal pages to exclude from analysis
    "app_patterns": [
        "/usercodeapppanel", "/admin", "/dashboard",
        "/app/", "/login", "/signup", "/register",
        "/settings", "/account", "/billing"
    ],
    # Brand keywords for Search Console query classification (lowercase)
    "brand_keywords": [],
    # Default vertical for CPA benchmarks
    "default_vertical": "b2b_saas",
    # GA4 channel groupings
    "organic_channels": [
        "organic search", "organic social", "organic video"
    ],
    "paid_channels": [
        "paid search", "paid social", "cross-network",
        "paid video", "paid shopping", "display"
    ],
}

# Active configuration (merged from defaults + config file)
_config = dict(_DEFAULT_CONFIG)


def load_config(config_path: str = None) -> dict:
    """Load configuration from a JSON file.

    Searches in order:
    1. Explicit path (if provided)
    2. ./ds_utils_config.json (project root)
    3. ./scripts/ds_utils_config.json

    Any key present in the config file overrides the default.
    Missing keys keep their defaults. This means users only need
    to specify the values they want to change.

    Example ds_utils_config.json:
    {
        "blog_patterns": ["/blog/", "/recursos/", "/learn/"],
        "app_patterns": ["/admin", "/console/", "/workspace/"],
        "brand_keywords": ["dataslayer", "mycompany"],
        "default_vertical": "b2b_saas"
    }
    """
    global _config
    search_paths = [
        config_path,
        os.path.join(os.getcwd(), "ds_utils_config.json"),
        os.path.join(os.path.dirname(__file__), "ds_utils_config.json"),
    ]

    for path in search_paths:
        if path and os.path.exists(path):
            try:
                with open(path, "r") as f:
                    user_config = json.load(f)
                _config = {**_DEFAULT_CONFIG, **user_config}
                return _config
            except (json.JSONDecodeError, IOError):
                pass

    _config = dict(_DEFAULT_CONFIG)
    return _config


def get_config() -> dict:
    """Return the active configuration."""
    return dict(_config)


# Auto-load config on import
load_config()


# ═══════════════════════════════════════════════════════════════════════════
# 1. URL PROCESSING
# ═══════════════════════════════════════════════════════════════════════════

def strip_utm(url: str) -> str:
    """Strip UTM parameters and ad tracking params from a URL path.

    GA4 returns landingPagePlusQueryString with full UTM params:
      /blog/my-post?utm_source=google&utm_medium=cpc&hsa_acc=123456
    This function returns:
      /blog/my-post

    Also handles full URLs (https://...) by returning just the path.
    """
    if not url or url == "--":
        return url

    # Handle full URLs
    if url.startswith("http"):
        parsed = urlparse(url)
        return parsed.path.rstrip("/") or "/"

    # Handle paths with query strings
    return url.split("?")[0].rstrip("/") or "/"


def aggregate_by_url(rows: list[dict], url_field: str = "url",
                     metric_fields: list[str] = None) -> list[dict]:
    """Aggregate metrics by clean URL after stripping UTM params.

    Takes rows like:
      [{"url": "/blog/post?utm_source=google", "sessions": 50},
       {"url": "/blog/post?utm_medium=cpc", "sessions": 30}]

    Returns:
      [{"url": "/blog/post", "sessions": 80}]
    """
    aggregated = defaultdict(lambda: defaultdict(float))

    if metric_fields is None:
        # Auto-detect numeric fields
        if rows:
            metric_fields = [k for k, v in rows[0].items()
                             if k != url_field and _is_numeric(v)]

    for row in rows:
        clean_url = strip_utm(str(row.get(url_field, "")))
        for field in metric_fields:
            val = row.get(field, 0)
            aggregated[clean_url][field] += _to_float(val)

    result = []
    for url, metrics in aggregated.items():
        entry = {url_field: url}
        entry.update(metrics)
        result.append(entry)

    return sorted(result, key=lambda x: x.get(metric_fields[0], 0),
                  reverse=True) if metric_fields else result


def is_blog_path(url: str) -> bool:
    """Check if a URL path is a blog/content page.

    Uses blog_patterns from config. Override via ds_utils_config.json:
    {"blog_patterns": ["/blog/", "/recursos/", "/learn/", "/guides/"]}
    """
    clean = strip_utm(url).lower()
    return any(p in clean for p in _config["blog_patterns"])


def is_app_path(url: str) -> bool:
    """Check if a URL path is an app/internal page (should be excluded).

    Uses app_patterns from config. Override via ds_utils_config.json:
    {"app_patterns": ["/admin", "/console/", "/workspace/"]}
    """
    clean = strip_utm(url).lower()
    return any(p in clean for p in _config["app_patterns"])


# ═══════════════════════════════════════════════════════════════════════════
# 2. GA4 PAGE PROCESSING
# ═══════════════════════════════════════════════════════════════════════════

def process_ga4_pages(rows: list[dict],
                      url_field: str = "Landing page",
                      channel_field: str = "Session default channel group",
                      sessions_field: str = "Sessions") -> dict:
    """Process GA4 landing pages: strip UTMs, split by source, classify.

    Returns:
        {
            "pages": [...],           # All pages with source breakdown
            "organic_stars": [...],   # High organic traffic + conversion
            "zombies": [...],         # <50 sessions, 0 conversions
            "hidden_gems": [...],     # Low traffic, high conversion
            "traffic_no_conv": [...], # High traffic, no conversion
            "summary": {
                "total_pages": int,
                "total_sessions": int,
                "organic_sessions": int,
                "paid_sessions": int,
                "organic_pct": float,
                "paid_pct": float,
            }
        }
    """
    # Step 1: Aggregate by clean URL + channel
    page_data = defaultdict(lambda: {
        "total": 0, "organic": 0, "paid": 0,
        "referral": 0, "direct": 0, "other": 0,
        "conversions": 0
    })

    organic_channels = set(_config["organic_channels"])
    paid_channels = set(_config["paid_channels"])

    for row in rows:
        url = strip_utm(str(row.get(url_field, "")))
        channel = str(row.get(channel_field, "")).lower().strip()
        sessions = _to_float(row.get(sessions_field, 0))

        if is_app_path(url):
            continue

        page_data[url]["total"] += sessions

        if channel in organic_channels:
            page_data[url]["organic"] += sessions
        elif channel in paid_channels:
            page_data[url]["paid"] += sessions
        elif channel == "referral":
            page_data[url]["referral"] += sessions
        elif channel in {"direct", "(direct)"}:
            page_data[url]["direct"] += sessions
        else:
            page_data[url]["other"] += sessions

    # Step 2: Build page list
    pages = []
    for url, data in page_data.items():
        total = data["total"]
        organic_pct = (data["organic"] / total * 100) if total > 0 else 0
        paid_pct = (data["paid"] / total * 100) if total > 0 else 0

        pages.append({
            "url": url,
            "total_sessions": total,
            "organic_sessions": data["organic"],
            "paid_sessions": data["paid"],
            "referral_sessions": data["referral"],
            "direct_sessions": data["direct"],
            "other_sessions": data["other"],
            "organic_pct": round(organic_pct, 1),
            "paid_pct": round(paid_pct, 1),
            "conversions": data["conversions"],
            "conv_rate": 0.0,  # Set later if conversion data available
        })

    pages.sort(key=lambda x: x["total_sessions"], reverse=True)
    log.debug("process_ga4_pages: %d input rows → %d unique pages (app paths excluded)", len(rows), len(pages))

    # Step 3: Calculate summary
    total_sessions = sum(p["total_sessions"] for p in pages)
    organic_sessions = sum(p["organic_sessions"] for p in pages)
    paid_sessions = sum(p["paid_sessions"] for p in pages)

    summary = {
        "total_pages": len(pages),
        "total_sessions": total_sessions,
        "organic_sessions": organic_sessions,
        "paid_sessions": paid_sessions,
        "organic_pct": round(organic_sessions / total_sessions * 100, 1)
            if total_sessions > 0 else 0,
        "paid_pct": round(paid_sessions / total_sessions * 100, 1)
            if total_sessions > 0 else 0,
    }

    return {
        "pages": pages,
        "summary": summary,
    }


def classify_content(pages: list[dict],
                     star_min_sessions: int = 200,
                     star_min_conv_rate: float = 2.0,
                     star_max_paid_pct: float = 80.0,
                     zombie_max_sessions: int = 50,
                     gem_max_sessions: int = 500,
                     gem_min_conv_rate: float = 3.0,
                     high_traffic_min: int = 200,
                     low_conv_threshold: float = 0.5) -> dict:
    """Classify content pages into 4 categories.

    Categories:
    - organic_stars: High organic traffic + high conversion (>50% organic)
    - traffic_no_conv: High traffic + low conversion
    - hidden_gems: Low traffic + high conversion
    - zombies: <50 sessions, 0 conversions

    Returns dict with lists for each category + counts.
    """
    organic_stars = []
    traffic_no_conv = []
    hidden_gems = []
    zombies = []

    for page in pages:
        sessions = page.get("total_sessions", 0)
        organic = page.get("organic_sessions", 0)
        conv_rate = page.get("conv_rate", 0)
        conversions = page.get("conversions", 0)
        paid_pct = page.get("paid_pct", 0)

        if sessions < zombie_max_sessions and conversions == 0:
            zombies.append(page)
        elif (organic >= star_min_sessions
              and conv_rate >= star_min_conv_rate
              and paid_pct < star_max_paid_pct):
            organic_stars.append(page)
        elif sessions >= high_traffic_min and conv_rate < low_conv_threshold:
            traffic_no_conv.append(page)
        elif (sessions < gem_max_sessions
              and conv_rate >= gem_min_conv_rate
              and conversions >= 1):
            hidden_gems.append(page)

    return {
        "organic_stars": sorted(organic_stars,
                                key=lambda x: x.get("conversions", 0),
                                reverse=True),
        "traffic_no_conv": sorted(traffic_no_conv,
                                  key=lambda x: x.get("total_sessions", 0),
                                  reverse=True),
        "hidden_gems": sorted(hidden_gems,
                              key=lambda x: x.get("conv_rate", 0),
                              reverse=True),
        "zombies": zombies,
        "counts": {
            "organic_stars": len(organic_stars),
            "traffic_no_conv": len(traffic_no_conv),
            "hidden_gems": len(hidden_gems),
            "zombies": len(zombies),
            "zombie_pct": round(len(zombies) / len(pages) * 100, 1)
                if pages else 0,
        }
    }


def merge_conversions(pages: list[dict], conversion_rows: list[dict],
                      url_field: str = "Landing page",
                      event_field: str = "Event name",
                      count_field: str = "Event count") -> list[dict]:
    """Merge conversion data into page data by clean URL.

    Takes page list from process_ga4_pages and conversion rows from
    a separate GA4 query, matches by URL, and updates conv_rate.
    """
    # Aggregate conversions by clean URL
    conv_by_url = defaultdict(float)
    for row in conversion_rows:
        url = strip_utm(str(row.get(url_field, "")))
        count = _to_float(row.get(count_field, 0))
        conv_by_url[url] += count

    # Merge into pages
    for page in pages:
        url = page["url"]
        convs = conv_by_url.get(url, 0)
        page["conversions"] = convs
        total = page.get("total_sessions", 0)
        page["conv_rate"] = round(convs / total * 100, 2) if total > 0 else 0

    return pages


# ═══════════════════════════════════════════════════════════════════════════
# 3. SEARCH CONSOLE QUERY CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════════

def classify_queries(rows: list[dict],
                     query_field: str = "Search query",
                     impressions_field: str = "Impressions",
                     clicks_field: str = "Clicks",
                     ctr_field: str = "CTR",
                     position_field: str = "Average Position") -> dict:
    """Classify Search Console queries into 4 SEO buckets.

    - quick_wins: Position 4-15, impressions >200. One update from page 1.
    - ctr_problems: Position 1-10, CTR <3%. Fix title, not content.
    - ranking_drops: Requires previous period comparison (marked if available).
    - high_impression_low_ctr: >1000 impressions, CTR <1%. Intent mismatch.
    """
    quick_wins = []
    ctr_problems = []
    high_imp_low_ctr = []

    for row in rows:
        query = str(row.get(query_field, ""))
        impressions = _to_float(row.get(impressions_field, 0))
        clicks = _to_float(row.get(clicks_field, 0))
        ctr = _to_float(row.get(ctr_field, 0))
        position = _to_float(row.get(position_field, 0))

        # Normalize CTR to percentage.
        # MCP/Search Console returns CTR as percentage (e.g., 0.5 = 0.5%)
        # Only convert if value looks like a ratio (< 0.01 would be 1%)
        # Heuristic: if CTR < 1 AND clicks/impressions suggests it's a ratio
        if impressions > 0 and clicks > 0:
            calculated_ctr = clicks / impressions * 100
            # Use calculated CTR — more reliable than reported value
            ctr_pct = calculated_ctr
        elif ctr > 1:
            ctr_pct = ctr  # Already a percentage
        else:
            # Ambiguous — assume it's already a percentage (MCP default)
            ctr_pct = ctr

        entry = {
            "query": query,
            "impressions": impressions,
            "clicks": clicks,
            "ctr": round(ctr_pct, 2),
            "position": round(position, 1),
        }

        if 4 <= position <= 15 and impressions >= 200:
            quick_wins.append(entry)
        if position <= 10 and ctr_pct < 3 and impressions >= 100:
            ctr_problems.append(entry)
        if impressions >= 1000 and ctr_pct < 1:
            high_imp_low_ctr.append(entry)

    return {
        "quick_wins": sorted(quick_wins,
                             key=lambda x: x["impressions"], reverse=True),
        "ctr_problems": sorted(ctr_problems,
                               key=lambda x: x["impressions"], reverse=True),
        "high_impression_low_ctr": sorted(high_imp_low_ctr,
                                          key=lambda x: x["impressions"],
                                          reverse=True),
        "counts": {
            "quick_wins": len(quick_wins),
            "ctr_problems": len(ctr_problems),
            "high_impression_low_ctr": len(high_imp_low_ctr),
        }
    }
    log.debug("classify_queries: %d rows → %d quick wins, %d CTR problems",
              len(rows), len(quick_wins), len(ctr_problems))


# ═══════════════════════════════════════════════════════════════════════════
# 4. STRIPE / SUBSCRIPTION PROCESSING
# ═══════════════════════════════════════════════════════════════════════════

def calculate_mrr(subscriptions: list[dict],
                  amount_field: str = "Subscription plan amount",
                  interval_field: str = "Subscription plan interval",
                  status_field: str = "Subscription status",
                  count_field: str = "Subscription count") -> dict:
    """Calculate MRR from Stripe subscription data.

    Rules:
    - Monthly plans: amount as-is
    - Yearly plans: amount ÷ 12
    - Only count active/trialing subscriptions
    - Use base currency amount (NOT _eur fields — mixed currencies cause errors)
    """
    total_mrr = 0.0
    active_subs = 0
    by_plan = defaultdict(lambda: {"mrr": 0, "count": 0, "interval": ""})
    active_statuses = {"active", "trialing"}

    for row in subscriptions:
        status = str(row.get(status_field, "")).lower().strip()
        if status not in active_statuses:
            continue

        amount = _to_float(row.get(amount_field, 0))
        interval = str(row.get(interval_field, "")).lower().strip()
        count = int(_to_float(row.get(count_field, 1)))
        plan_name = str(row.get("Subscription plan name",
                                row.get("Plan", "Unknown")))

        if interval == "year":
            monthly_equiv = amount / 12
        elif interval == "month":
            monthly_equiv = amount
        elif interval == "week":
            monthly_equiv = amount * 4.33
        else:
            monthly_equiv = amount  # Assume monthly

        plan_mrr = monthly_equiv * count
        total_mrr += plan_mrr
        active_subs += count

        by_plan[plan_name]["mrr"] += plan_mrr
        by_plan[plan_name]["count"] += count
        by_plan[plan_name]["interval"] = interval

    log.debug("calculate_mrr: %d active subs, MRR=%.2f, %d plans",
              active_subs, total_mrr, len(by_plan))
    return {
        "total_mrr": round(total_mrr, 2),
        "active_subscriptions": active_subs,
        "by_plan": dict(by_plan),
    }


def calculate_churn(active: int, cancelled: int,
                    period_days: int = 30) -> dict:
    """Calculate churn rate and annualized churn.

    Formula: cancelled / (active + cancelled) in the period.
    Benchmarks:
    - <5% monthly: healthy SaaS
    - 5-10%: watch closely
    - >10%: critical
    - >50%: business survival issue
    """
    total = active + cancelled
    churn_rate = (cancelled / total * 100) if total > 0 else 0

    if churn_rate < 5:
        status = "Green"
        assessment = "Healthy"
    elif churn_rate < 10:
        status = "Amber"
        assessment = "Watch closely"
    elif churn_rate < 50:
        status = "Red"
        assessment = "Critical"
    else:
        status = "Red"
        assessment = "Business survival issue"

    return {
        "churn_rate": round(churn_rate, 1),
        "active": active,
        "cancelled": cancelled,
        "total_base": total,
        "status": status,
        "assessment": assessment,
        "annualized": round(min(churn_rate * (365 / period_days), 100), 1),
    }


def analyze_cancellations(rows: list[dict],
                          reason_field: str = "Subscription cancellation reason",
                          count_field: str = "Subscription count",
                          amount_field: str = "Subscription plan amount") -> dict:
    """Analyze cancellation reasons from Stripe data.

    IMPORTANT: Use subscription_cancellation_reason only.
    Do NOT use subscription_cancellation_feedback — it causes 502 errors.
    """
    total_cancellations = 0
    total_mrr_lost = 0
    no_reason_count = 0
    reasons = defaultdict(lambda: {"count": 0, "mrr_lost": 0})

    for row in rows:
        reason = str(row.get(reason_field, "--")).strip()
        count = int(_to_float(row.get(count_field, 1)))
        amount = _to_float(row.get(amount_field, 0))

        total_cancellations += count
        total_mrr_lost += amount * count

        if reason in ("--", "", "null", "None", "N/A"):
            no_reason_count += count
            reason = "No reason given"

        reasons[reason]["count"] += count
        reasons[reason]["mrr_lost"] += amount * count

    no_reason_pct = (no_reason_count / total_cancellations * 100
                     if total_cancellations > 0 else 0)

    # Sort by count descending
    sorted_reasons = sorted(reasons.items(),
                            key=lambda x: x[1]["count"], reverse=True)

    return {
        "total_cancellations": total_cancellations,
        "total_mrr_lost": round(total_mrr_lost, 2),
        "no_reason_pct": round(no_reason_pct, 1),
        "no_reason_is_critical": no_reason_pct > 90,
        "top_reasons": [
            {"reason": r, "count": d["count"],
             "mrr_lost": round(d["mrr_lost"], 2)}
            for r, d in sorted_reasons[:5]
        ],
    }


def analyze_payment_failures(rows: list[dict],
                             failure_code_field: str = None,
                             amount_field: str = None,
                             customer_field: str = None,
                             email_field: str = None,
                             date_field: str = "Date") -> dict:
    """Analyze Stripe failed charges.

    Benchmarks:
    - 5-10%: normal for SaaS
    - 15-20%: concerning
    - >20%: systemic problem

    Filters locally for failed charges (failure_code != "--").
    Groups by customer to find repeat failures.

    Auto-detects column names (MCP returns Title Case with spaces).
    """
    # Auto-detect column names from first row
    if rows:
        cols = list(rows[0].keys())
        if failure_code_field is None:
            failure_code_field = _find_col(cols, "failure_code", "Charge Failure Code")
        if amount_field is None:
            amount_field = _find_col(cols, "amount", "Charge Amount")
        if customer_field is None:
            customer_field = _find_col(cols, "customer_id", "Customer ID")
        if email_field is None:
            email_field = _find_col(cols, "email", "Customer Email")

    total_charges = len(rows)
    failed = []
    successful = 0

    for row in rows:
        code = str(row.get(failure_code_field, "--")).strip()
        if code in ("--", "", "null", "None"):
            successful += 1
            continue
        failed.append(row)

    failure_rate = (len(failed) / total_charges * 100
                    if total_charges > 0 else 0)

    # Group failures by customer
    by_customer = defaultdict(lambda: {
        "count": 0, "total_amount": 0, "codes": set(), "email": ""
    })
    for row in failed:
        cust = str(row.get(customer_field, "unknown"))
        by_customer[cust]["count"] += 1
        by_customer[cust]["total_amount"] += _to_float(row.get(amount_field, 0))
        by_customer[cust]["codes"].add(str(row.get(failure_code_field, "")))
        by_customer[cust]["email"] = str(row.get(email_field, ""))

    # Repeat failures (3+ = Red risk)
    repeat_failures = {k: v for k, v in by_customer.items() if v["count"] >= 3}
    single_failures = {k: v for k, v in by_customer.items()
                       if 1 <= v["count"] <= 2}

    # Benchmark assessment
    if failure_rate <= 10:
        status = "Green"
        assessment = "Within normal range"
    elif failure_rate <= 20:
        status = "Amber"
        assessment = "Concerning — monitor closely"
    else:
        status = "Red"
        assessment = "Systemic problem — immediate action needed"

    # Serialize sets for JSON output
    repeat_list = []
    for cust_id, data in sorted(repeat_failures.items(),
                                key=lambda x: x[1]["count"], reverse=True):
        repeat_list.append({
            "customer_id": cust_id,
            "email": data["email"],
            "failure_count": data["count"],
            "total_amount": round(data["total_amount"], 2),
            "failure_codes": list(data["codes"]),
        })

    return {
        "total_charges": total_charges,
        "failed_charges": len(failed),
        "successful_charges": successful,
        "failure_rate": round(failure_rate, 1),
        "status": status,
        "assessment": assessment,
        "mrr_at_risk": round(sum(v["total_amount"]
                                 for v in by_customer.values()), 2),
        "repeat_failures": repeat_list[:10],
        "single_failure_count": len(single_failures),
    }
    log.debug("analyze_payment_failures: %d total charges, %d failed (%.1f%%), %d repeat offenders",
              total_charges, failed_count, failure_rate, len(repeat_list))


# ═══════════════════════════════════════════════════════════════════════════
# 5. GOOGLE ADS / CAMPAIGN PROCESSING
# ═══════════════════════════════════════════════════════════════════════════

def detect_paused_campaigns(rows: list[dict],
                            date_field: str = "Date",
                            campaign_field: str = "Campaign",
                            impressions_field: str = "Impressions",
                            cost_field: str = "Cost",
                            conversions_field: str = "Conversions") -> dict:
    """Detect paused campaigns from daily trend data.

    A campaign is paused if it has 0 impressions for 3+ consecutive
    days at the END of the period.

    Returns active-days-only metrics (not misleading full-period averages).
    """
    # Group by campaign → date
    campaigns = defaultdict(lambda: defaultdict(lambda: {
        "impressions": 0, "cost": 0, "conversions": 0
    }))

    for row in rows:
        campaign = str(row.get(campaign_field, "Unknown"))
        date_str = str(row.get(date_field, ""))
        campaigns[campaign][date_str]["impressions"] += _to_float(
            row.get(impressions_field, 0))
        campaigns[campaign][date_str]["cost"] += _to_float(
            row.get(cost_field, 0))
        campaigns[campaign][date_str]["conversions"] += _to_float(
            row.get(conversions_field, 0))

    results = []
    for campaign_name, daily in campaigns.items():
        sorted_dates = sorted(daily.keys())
        if not sorted_dates:
            continue

        # Find last date with impressions > 0
        active_dates = [d for d in sorted_dates
                        if daily[d]["impressions"] > 0]
        inactive_tail = 0

        if active_dates:
            last_active = active_dates[-1]
            # Count 0-impression days after last active day
            last_active_idx = sorted_dates.index(last_active)
            inactive_tail = len(sorted_dates) - 1 - last_active_idx

        is_paused = inactive_tail >= 3
        active_days = len(active_dates)

        # Calculate metrics from active days only
        total_impressions = sum(daily[d]["impressions"] for d in active_dates)
        total_cost = sum(daily[d]["cost"] for d in active_dates)
        total_conversions = sum(daily[d]["conversions"] for d in active_dates)

        daily_avg_conv = (total_conversions / active_days
                          if active_days > 0 else 0)
        est_lost_conv = daily_avg_conv * inactive_tail if is_paused else 0

        cpa = (total_cost / total_conversions
               if total_conversions > 0 else 0)

        results.append({
            "campaign": campaign_name,
            "is_paused": is_paused,
            "days_paused": inactive_tail,
            "active_days": active_days,
            "total_days": len(sorted_dates),
            "last_active_date": active_dates[-1] if active_dates else None,
            "total_impressions": total_impressions,
            "total_cost": round(total_cost, 2),
            "total_conversions": total_conversions,
            "cpa": round(cpa, 2),
            "daily_avg_conversions": round(daily_avg_conv, 1),
            "est_conversions_lost": round(est_lost_conv, 0),
        })

    paused_count = sum(1 for c in results if c["is_paused"])
    log.debug("detect_paused_campaigns: %d campaigns, %d paused", len(results), paused_count)
    return {
        "campaigns": results,
        "any_paused": any(c["is_paused"] for c in results),
        "total_est_lost": sum(c["est_conversions_lost"] for c in results),
    }


def cpa_sanity_check(cpa: float, vertical: str = "b2b_saas") -> dict:
    """Check if CPA is suspiciously low for the vertical.

    B2B SaaS benchmarks:
    - CPA < €5:  Almost certainly tracking a soft event (page_view, scroll)
    - CPA < €10: Suspiciously low — likely form_submit, not real signup
    - CPA €10-30: Reasonable for trial signup
    - CPA €30-80: Normal for qualified lead
    - CPA > €100: High — check audience targeting
    """
    benchmarks = {
        "b2b_saas": {
            "suspicious_low": 10,
            "normal_low": 30,
            "normal_high": 80,
            "high": 100,
        },
        "ecommerce": {
            "suspicious_low": 2,
            "normal_low": 10,
            "normal_high": 50,
            "high": 80,
        },
        "b2c_saas": {
            "suspicious_low": 5,
            "normal_low": 15,
            "normal_high": 50,
            "high": 70,
        },
        "agency": {
            "suspicious_low": 15,
            "normal_low": 50,
            "normal_high": 150,
            "high": 200,
        },
        "education": {
            "suspicious_low": 5,
            "normal_low": 20,
            "normal_high": 60,
            "high": 100,
        },
        "fintech": {
            "suspicious_low": 10,
            "normal_low": 40,
            "normal_high": 120,
            "high": 180,
        },
        "healthcare": {
            "suspicious_low": 15,
            "normal_low": 50,
            "normal_high": 150,
            "high": 250,
        },
        "marketplace": {
            "suspicious_low": 3,
            "normal_low": 15,
            "normal_high": 50,
            "high": 80,
        },
        "media": {
            "suspicious_low": 1,
            "normal_low": 5,
            "normal_high": 20,
            "high": 40,
        },
    }

    bench = benchmarks.get(vertical, benchmarks["b2b_saas"])

    if cpa < bench["suspicious_low"]:
        return {
            "status": "Red",
            "assessment": f"CPA of €{cpa:.2f} is suspiciously low for "
                          f"{vertical}. The conversion action is likely "
                          f"tracking a soft event (form_submit, page_view), "
                          f"not a real signup. Audit the conversion action "
                          f"before trusting any campaign data.",
            "likely_issue": "conversion_tracking",
        }
    elif cpa < bench["normal_low"]:
        return {
            "status": "Amber",
            "assessment": f"CPA of €{cpa:.2f} is below typical range. "
                          f"Verify the conversion action is a real signup.",
            "likely_issue": "verify_tracking",
        }
    elif cpa < bench["normal_high"]:
        return {
            "status": "Green",
            "assessment": f"CPA of €{cpa:.2f} is within normal range.",
            "likely_issue": None,
        }
    else:
        return {
            "status": "Amber",
            "assessment": f"CPA of €{cpa:.2f} is above typical range. "
                          f"Check audience targeting and ad relevance.",
            "likely_issue": "audience_targeting",
        }


# ═══════════════════════════════════════════════════════════════════════════
# 6. CONVERSION EVENT DETECTION
# ═══════════════════════════════════════════════════════════════════════════

def detect_conversion_event(rows: list[dict],
                            event_field: str = "Event name",
                            count_field: str = "Event count") -> dict:
    """Detect which GA4 conversion event has real data.

    Fallback chain: sign_up → generate_lead → begin_trial → form_submit

    This should be called ONCE and the result passed to all skills/agents
    to ensure consistency. The biggest risk in cross-channel analysis is
    different agents using different conversion events.
    """
    event_counts = defaultdict(float)
    for row in rows:
        event = str(row.get(event_field, "")).strip()
        count = _to_float(row.get(count_field, 0))
        event_counts[event] += count

    fallback_chain = ["sign_up", "generate_lead", "begin_trial",
                      "form_submit"]

    selected = None
    for event in fallback_chain:
        if event_counts.get(event, 0) > 0:
            selected = event
            break

    all_events = {k: v for k, v in sorted(event_counts.items(),
                                           key=lambda x: x[1],
                                           reverse=True)
                  if v > 0}

    return {
        "selected_event": selected,
        "selected_count": event_counts.get(selected, 0) if selected else 0,
        "fallback_used": selected != "sign_up" if selected else True,
        "warning": (
            "No real signup event found. Using form_submit as fallback. "
            "This may inflate conversion numbers — verify that form_submit "
            "corresponds to actual signups, not contact forms or newsletters."
            if selected == "form_submit" else
            "No conversion events found with data. "
            "Conversion tracking may not be configured."
            if selected is None else None
        ),
        "all_events": all_events,
    }


# ═══════════════════════════════════════════════════════════════════════════
# 7. VALIDATION
# ═══════════════════════════════════════════════════════════════════════════

def validate_mcp_result(rows: list[dict], source: str,
                        expected_min_rows: int = 1) -> dict:
    """Validate that MCP results are usable.

    Checks:
    - Not empty
    - Has expected columns
    - Numeric fields are actually numeric
    - No obvious data corruption
    """
    issues = []
    status = "Green"

    if not rows:
        return {
            "valid": False,
            "status": "Red",
            "issues": [f"{source}: MCP returned 0 rows. "
                       "Data source may not be connected or date range "
                       "may be empty."],
        }

    if len(rows) < expected_min_rows:
        issues.append(
            f"{source}: Only {len(rows)} rows returned "
            f"(expected at least {expected_min_rows}). "
            "Results may be incomplete.")
        status = "Amber"

    # Check for all-zero numeric columns (skip text columns)
    if rows:
        for col in rows[0].keys():
            # Only check columns where >80% of non-blank values are pure numbers
            sample = rows[:100]
            non_blank = [r.get(col, "") for r in sample
                         if str(r.get(col, "")).strip() not in ("--", "", "null")]
            if not non_blank:
                continue
            numeric_count = sum(1 for v in non_blank
                                if isinstance(v, (int, float))
                                or (isinstance(v, str)
                                    and v.replace(".", "").replace("-", "").isdigit()))
            if numeric_count < len(non_blank) * 0.8:
                continue  # Skip text columns
            values = [_to_float(r.get(col, 0)) for r in rows]
            if all(v == 0 for v in values):
                issues.append(
                    f"{source}: Column '{col}' is all zeros. "
                    "May indicate a misconfigured metric or empty period.")
                status = "Amber"

    # Check for excessive "--" values
    if rows:
        for col in rows[0].keys():
            blank_count = sum(
                1 for r in rows
                if str(r.get(col, "")).strip() in ("--", "", "null", "None"))
            blank_pct = blank_count / len(rows) * 100
            if blank_pct > 90:
                issues.append(
                    f"{source}: Column '{col}' is {blank_pct:.0f}% blank. "
                    "Critical data gap.")
                status = "Red" if "reason" in col.lower() else status

    return {
        "valid": len(issues) == 0 or status != "Red",
        "status": status,
        "row_count": len(rows),
        "columns": list(rows[0].keys()) if rows else [],
        "issues": issues,
    }


def cross_validate_paid_vs_stripe(paid_conversions_per_day: float,
                                  stripe_new_subs_per_day: float) -> dict:
    """Cross-validate paid ad conversions against Stripe new subscriptions.

    If there's a large gap (e.g., 47 "conversions"/day but only 2-3 new
    Stripe subs/day), the conversion tracking is broken.

    This is the meta-check that invalidates all other analysis if it fails.
    """
    if paid_conversions_per_day == 0:
        return {
            "status": "Amber",
            "gap_ratio": 0,
            "assessment": "No paid conversions to compare.",
            "tracking_valid": None,
        }

    if stripe_new_subs_per_day == 0:
        return {
            "status": "Red",
            "gap_ratio": float('inf'),
            "assessment": f"Paid reports {paid_conversions_per_day:.0f} "
                          "conversions/day but Stripe shows 0 new "
                          "subscriptions. Conversion tracking is broken.",
            "tracking_valid": False,
        }

    ratio = paid_conversions_per_day / stripe_new_subs_per_day

    if ratio <= 1.5:
        return {
            "status": "Green",
            "gap_ratio": round(ratio, 1),
            "assessment": "Paid conversions align with Stripe subscriptions.",
            "tracking_valid": True,
        }
    elif ratio <= 3:
        return {
            "status": "Amber",
            "gap_ratio": round(ratio, 1),
            "assessment": f"Paid reports {ratio:.1f}x more conversions than "
                          "Stripe subs. Some conversions may be soft events. "
                          "Audit the conversion action.",
            "tracking_valid": False,
        }
    else:
        return {
            "status": "Red",
            "gap_ratio": round(ratio, 1),
            "assessment": f"Paid reports {ratio:.0f}x more conversions than "
                          "Stripe subs. The conversion action is almost "
                          "certainly tracking a non-signup event. All paid "
                          "performance data is unreliable until fixed.",
            "tracking_valid": False,
        }


# ═══════════════════════════════════════════════════════════════════════════
# 8. PERIOD COMPARISON
# ═══════════════════════════════════════════════════════════════════════════

def compare_periods(current: dict, previous: dict) -> dict:
    """Compare two period metric dicts and calculate % change.

    Returns a new dict with _change and _direction for each metric.
    """
    result = {}
    for key in current:
        curr_val = _to_float(current[key])
        prev_val = _to_float(previous.get(key, 0))

        result[key] = curr_val
        result[f"{key}_prev"] = prev_val

        if prev_val == 0:
            result[f"{key}_change"] = None
            result[f"{key}_direction"] = "new"
        else:
            pct = (curr_val - prev_val) / prev_val * 100
            result[f"{key}_change"] = round(pct, 1)
            if pct > 5:
                result[f"{key}_direction"] = "up"
            elif pct < -5:
                result[f"{key}_direction"] = "down"
            else:
                result[f"{key}_direction"] = "flat"

    return result


# ═══════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _find_col(columns: list[str], *candidates: str) -> str:
    """Find a column name from a list, trying multiple variants.

    MCP returns columns in Title Case with spaces (e.g., "Charge Failure Code")
    but skills may reference them as lowercase with underscores.
    Tries exact match first, then case-insensitive, then partial match.
    """
    for candidate in candidates:
        # Exact match
        if candidate in columns:
            return candidate
        # Case-insensitive match
        for col in columns:
            if col.lower().replace(" ", "_") == candidate.lower().replace(" ", "_"):
                return col
        # Partial match (candidate is substring)
        for col in columns:
            if candidate.lower().replace("_", " ") in col.lower():
                return col
    # No match found — return None so callers can handle gracefully
    return None


def _to_float(val) -> float:
    """Safely convert any value to float."""
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        val = val.strip().replace(",", "").replace("%", "")
        val = val.replace("€", "").replace("$", "").replace("£", "")
        try:
            return float(val)
        except (ValueError, TypeError):
            return 0.0
    return 0.0


def _is_numeric(val) -> bool:
    """Check if a value looks numeric (int, float, or string that parses as number)."""
    if isinstance(val, bool):
        return False
    if isinstance(val, (int, float)):
        return True
    if isinstance(val, str):
        cleaned = val.strip().replace(",", "").replace("%", "")
        cleaned = cleaned.replace("€", "").replace("$", "").replace("£", "")
        if cleaned in ("", "--", "null", "None"):
            return False
        try:
            float(cleaned)
            return True
        except ValueError:
            return False
    return False


def _read_mcp_file(filepath: str) -> list[dict]:
    """Read an MCP result file (JSON or TSV) into list of dicts.

    MCP returns results in two formats:
    1. JSON: {"result": {"result": [["Header1","Header2"],[val1,val2],...]}}
       or wrapped in: [{"type":"text","text":"...json..."}]
    2. TSV: tab-separated with headers in first row

    Handles both transparently.
    """
    csv.field_size_limit(10 * 1024 * 1024)  # 10 MB per field

    if not os.path.exists(filepath):
        log.error("File not found: %s", filepath)
        print(json.dumps({
            "error": f"File not found: {filepath}",
            "valid": False,
            "rows": 0,
            "hint": "Check the file path returned by the MCP. "
                    "The file may have been saved to a different location."
        }), file=sys.stderr)
        return []

    log.debug("Reading MCP file: %s", filepath)
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read().strip()

    if not content:
        log.warning("File is empty: %s", filepath)
        print(json.dumps({
            "error": f"File is empty: {filepath}",
            "valid": False,
            "rows": 0,
        }), file=sys.stderr)
        return []

    # Try JSON first (MCP native format)
    if content.startswith("[") or content.startswith("{"):
        try:
            data = json.loads(content)

            # Handle wrapped format: [{"type":"text","text":"..."}]
            if isinstance(data, list) and data and "text" in data[0]:
                data = json.loads(data[0]["text"])

            # Navigate to the array-of-arrays result
            result_data = None
            if isinstance(data, dict):
                if "result" in data and isinstance(data["result"], dict):
                    result_data = data["result"].get("result")
                elif "result" in data and isinstance(data["result"], list):
                    result_data = data["result"]

            if result_data and isinstance(result_data, list) and len(result_data) > 1:
                headers = [str(h) for h in result_data[0]]
                rows = []
                for row_data in result_data[1:]:
                    row_dict = {}
                    for i, val in enumerate(row_data):
                        if i < len(headers):
                            row_dict[headers[i]] = val
                    rows.append(row_dict)
                log.debug("Parsed JSON: %d rows, columns: %s", len(rows), headers)
                return rows

        except (json.JSONDecodeError, KeyError, IndexError):
            log.debug("JSON parse failed for %s, falling back to TSV", filepath)

    # Fall back to TSV
    rows = []
    reader = csv.DictReader(StringIO(content), delimiter="\t")
    for row in reader:
        rows.append(dict(row))
    log.debug("Parsed TSV: %d rows", len(rows))
    return rows


# Keep backward compatibility
_read_tsv = _read_mcp_file


# ═══════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    cmd = sys.argv[1]
    args = sys.argv[2:]
    log.debug("CLI invoked: cmd=%s, args=%s", cmd, args)

    if cmd == "process-ga4-pages" and args:
        rows = _read_tsv(args[0])
        result = process_ga4_pages(rows)
        if len(args) > 1:
            # Second file = conversion data
            conv_rows = _read_tsv(args[1])
            event_info = detect_conversion_event(conv_rows)
            # Filter to selected event
            selected = event_info["selected_event"]
            if selected:
                conv_filtered = [r for r in conv_rows
                                 if r.get("Event name", "") == selected]
                merge_conversions(result["pages"], conv_filtered)
            result["conversion_event"] = event_info
        classified = classify_content(result["pages"])
        result["classification"] = classified
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "process-sc-queries" and args:
        rows = _read_tsv(args[0])
        result = classify_queries(rows)
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "process-stripe-subs" and args:
        rows = _read_tsv(args[0])
        mrr = calculate_mrr(rows)
        print(json.dumps(mrr, indent=2, default=str))

    elif cmd == "process-stripe-charges" and args:
        rows = _read_tsv(args[0])
        result = analyze_payment_failures(rows)
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "process-campaigns" and args:
        rows = _read_tsv(args[0])
        result = detect_paused_campaigns(rows)
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "detect-conversion" and args:
        rows = _read_tsv(args[0])
        result = detect_conversion_event(rows)
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "validate" and len(args) >= 2:
        rows = _read_tsv(args[0])
        result = validate_mcp_result(rows, source=args[1])
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "compare-periods" and len(args) >= 2:
        current = json.loads(args[0])
        previous = json.loads(args[1])
        result = compare_periods(current, previous)
        print(json.dumps(result, indent=2, default=str))

    elif cmd == "cpa-check" and args:
        cpa = float(args[0])
        vertical = args[1] if len(args) > 1 else "b2b_saas"
        result = cpa_sanity_check(cpa, vertical)
        print(json.dumps(result, indent=2, default=str))

    else:
        print(f"Unknown command: {cmd}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # Return structured error instead of traceback — Claude can parse this
        print(json.dumps({
            "error": str(e),
            "error_type": type(e).__name__,
            "valid": False,
            "hint": "An unexpected error occurred. Check that the input "
                    "file format matches what the MCP returned."
        }))
        sys.exit(1)
