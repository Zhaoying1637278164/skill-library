#!/usr/bin/env python3
"""
test_ds_utils.py — Standalone test suite for ds_utils.py

Run with:
    python scripts/test_ds_utils.py

Uses no external test frameworks. Prints clear pass/fail results per section.
Exits 0 if all pass, 1 if any fail.
"""

import sys
import os
import json
import tempfile

# Ensure the scripts directory is importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ds_utils import (
    strip_utm, aggregate_by_url, is_blog_path, is_app_path,
    process_ga4_pages, classify_content, merge_conversions,
    classify_queries, calculate_mrr, calculate_churn,
    analyze_cancellations, analyze_payment_failures,
    detect_paused_campaigns, cpa_sanity_check,
    detect_conversion_event, validate_mcp_result,
    cross_validate_paid_vs_stripe, compare_periods,
    load_config, get_config,
    _find_col, _to_float, _is_numeric, _read_mcp_file,
)

# ---------------------------------------------------------------------------
# Test harness
# ---------------------------------------------------------------------------
_total_pass = 0
_total_fail = 0
_section_pass = 0
_section_fail = 0


def section(name):
    global _section_pass, _section_fail
    _section_pass = 0
    _section_fail = 0
    print(f"\n{'=' * 60}")
    print(f"  {name}")
    print(f"{'=' * 60}")


def end_section():
    global _total_pass, _total_fail
    _total_pass += _section_pass
    _total_fail += _section_fail
    status = "ALL PASS" if _section_fail == 0 else f"{_section_fail} FAILED"
    print(f"  -> {_section_pass} passed, {_section_fail} failed  [{status}]")


def check(description, condition):
    global _section_pass, _section_fail
    if condition:
        _section_pass += 1
        print(f"  [PASS] {description}")
    else:
        _section_fail += 1
        print(f"  [FAIL] {description}")


# ===================================================================
# A. URL PROCESSING
# ===================================================================
def test_url_processing():
    section("A. URL Processing")

    # strip_utm: basic UTM params
    check("strip_utm removes utm_source from path",
          strip_utm("/blog/seo-guide?utm_source=google&utm_medium=cpc") == "/blog/seo-guide")

    # strip_utm: hsa and gclid params
    check("strip_utm removes hsa_acc and gclid params",
          strip_utm("/pricing?utm_source=google&hsa_acc=123456&gclid=EAIaIQob") == "/pricing")

    # strip_utm: full URL
    check("strip_utm extracts path from full https URL",
          strip_utm("https://www.example.com/blog/post?utm_source=newsletter") == "/blog/post")

    # strip_utm: full URL root
    check("strip_utm returns / for root URL",
          strip_utm("https://www.example.com/") == "/")

    # strip_utm: empty string
    check("strip_utm returns empty for empty string",
          strip_utm("") == "")

    # strip_utm: dash (GA4 null marker)
    check("strip_utm returns '--' unchanged",
          strip_utm("--") == "--")

    # strip_utm: path with trailing slash and no query
    check("strip_utm strips trailing slash from clean path",
          strip_utm("/features/") == "/features")

    # strip_utm: root path only
    check("strip_utm returns / for bare /",
          strip_utm("/") == "/")

    # strip_utm: multiple UTM variants
    check("strip_utm handles utm_campaign + utm_term + utm_content",
          strip_utm("/landing/demo?utm_campaign=spring&utm_term=saas+tool&utm_content=cta1") == "/landing/demo")

    # is_blog_path: standard patterns
    check("is_blog_path detects /blog/ path",
          is_blog_path("/blog/how-to-track-conversions") is True)

    check("is_blog_path detects /articles/ path",
          is_blog_path("/articles/marketing-trends-2025") is True)

    check("is_blog_path rejects pricing page",
          is_blog_path("/pricing") is False)

    check("is_blog_path rejects homepage",
          is_blog_path("/") is False)

    # is_app_path: various patterns
    check("is_app_path detects /usercodeapppanel",
          is_app_path("/usercodeapppanel/reports") is True)

    check("is_app_path detects /dashboard",
          is_app_path("/dashboard/overview") is True)

    check("is_app_path detects /app/",
          is_app_path("/app/settings") is True)

    check("is_app_path detects /login",
          is_app_path("/login") is True)

    check("is_app_path rejects marketing page",
          is_app_path("/features/analytics") is False)

    end_section()


# ===================================================================
# B. GA4 PAGE PROCESSING
# ===================================================================
def test_ga4_page_processing():
    section("B. GA4 Page Processing")

    rows = [
        {"Landing page": "/blog/seo-tips?utm_source=google", "Session default channel group": "Organic Search", "Sessions": "320"},
        {"Landing page": "/blog/seo-tips?utm_medium=cpc", "Session default channel group": "Paid Search", "Sessions": "80"},
        {"Landing page": "/pricing", "Session default channel group": "Direct", "Sessions": "150"},
        {"Landing page": "/blog/analytics-guide", "Session default channel group": "Organic Search", "Sessions": "500"},
        {"Landing page": "/features", "Session default channel group": "Referral", "Sessions": "75"},
        {"Landing page": "/pricing", "Session default channel group": "Cross-network", "Sessions": "200"},
        {"Landing page": "/app/dashboard", "Session default channel group": "Direct", "Sessions": "1000"},
    ]

    result = process_ga4_pages(rows)

    check("process_ga4_pages returns pages list",
          "pages" in result and isinstance(result["pages"], list))

    check("process_ga4_pages returns summary",
          "summary" in result and isinstance(result["summary"], dict))

    # App paths should be excluded
    app_urls = [p["url"] for p in result["pages"]]
    check("App paths are excluded from results",
          "/app/dashboard" not in app_urls)

    # UTM variants should be aggregated
    seo_tips_pages = [p for p in result["pages"] if p["url"] == "/blog/seo-tips"]
    check("UTM variants aggregated into single row",
          len(seo_tips_pages) == 1 and seo_tips_pages[0]["total_sessions"] == 400)

    # organic_pct and paid_pct on aggregated page
    seo_page = seo_tips_pages[0]
    check("organic_pct calculated correctly (320/400 = 80%)",
          seo_page["organic_pct"] == 80.0)

    check("paid_pct calculated correctly (80/400 = 20%)",
          seo_page["paid_pct"] == 20.0)

    # Summary totals: 320+80 (seo-tips) + 150 (pricing direct) + 500 (analytics) + 75 (features) + 200 (pricing paid)
    # = 1325 total (app excluded)
    summary = result["summary"]
    check("Summary total_sessions is correct (1325)",
          summary["total_sessions"] == 1325)

    check("Summary organic_sessions correct (320+500 = 820)",
          summary["organic_sessions"] == 820)

    check("Summary paid_sessions correct (80+200 = 280)",
          summary["paid_sessions"] == 280)

    end_section()


# ===================================================================
# C. CONTENT CLASSIFICATION
# ===================================================================
def test_content_classification():
    section("C. Content Classification")

    pages = [
        # organic star: high organic sessions (>200), conv_rate >2%, paid_pct <80%
        {"url": "/blog/best-tools", "total_sessions": 800, "organic_sessions": 650,
         "paid_sessions": 50, "conv_rate": 3.5, "conversions": 28, "paid_pct": 6.25},
        # zombie: <50 sessions, 0 conversions
        {"url": "/blog/old-draft", "total_sessions": 12, "organic_sessions": 8,
         "paid_sessions": 0, "conv_rate": 0, "conversions": 0, "paid_pct": 0},
        # hidden gem: <500 sessions, conv_rate >3%, conversions >=1
        {"url": "/resources/calculator", "total_sessions": 120, "organic_sessions": 90,
         "paid_sessions": 10, "conv_rate": 5.0, "conversions": 6, "paid_pct": 8.3},
        # traffic_no_conv: >200 sessions, conv_rate <0.5%
        {"url": "/blog/industry-news", "total_sessions": 1500, "organic_sessions": 1200,
         "paid_sessions": 100, "conv_rate": 0.1, "conversions": 1, "paid_pct": 6.7},
        # zombie #2
        {"url": "/blog/test-page", "total_sessions": 5, "organic_sessions": 3,
         "paid_sessions": 0, "conv_rate": 0, "conversions": 0, "paid_pct": 0},
        # normal page — no special category
        {"url": "/pricing", "total_sessions": 600, "organic_sessions": 100,
         "paid_sessions": 400, "conv_rate": 1.5, "conversions": 9, "paid_pct": 66.7},
    ]

    result = classify_content(pages)

    check("organic_stars detected correctly",
          result["counts"]["organic_stars"] == 1 and
          result["organic_stars"][0]["url"] == "/blog/best-tools")

    check("organic_stars requires >50% organic (paid_pct <80%)",
          all(p["paid_pct"] < 80 for p in result["organic_stars"]))

    check("zombies detected correctly (2 pages)",
          result["counts"]["zombies"] == 2)

    zombie_urls = {z["url"] for z in result["zombies"]}
    check("zombie pages are correct",
          zombie_urls == {"/blog/old-draft", "/blog/test-page"})

    check("hidden_gems detected correctly",
          result["counts"]["hidden_gems"] == 1 and
          result["hidden_gems"][0]["url"] == "/resources/calculator")

    check("traffic_no_conv detected correctly",
          result["counts"]["traffic_no_conv"] == 1 and
          result["traffic_no_conv"][0]["url"] == "/blog/industry-news")

    check("zombie_pct calculated correctly (2/6 = 33.3%)",
          abs(result["counts"]["zombie_pct"] - 33.3) < 0.1)

    end_section()


# ===================================================================
# D. SEARCH CONSOLE CLASSIFICATION
# ===================================================================
def test_search_console_classification():
    section("D. Search Console Classification")

    rows = [
        # quick_win: position 4-15, impressions >=200
        {"Search query": "best analytics tool", "Impressions": "850", "Clicks": "42",
         "CTR": "4.9", "Average Position": "7.2"},
        # ctr_problem: position <=10, CTR <3%, impressions >=100
        {"Search query": "marketing dashboard", "Impressions": "1200", "Clicks": "15",
         "CTR": "1.25", "Average Position": "3.5"},
        # high_impression_low_ctr: impressions >=1000, CTR <1%
        {"Search query": "data visualization software", "Impressions": "5000", "Clicks": "20",
         "CTR": "0.4", "Average Position": "12.3"},
        # normal query — no bucket
        {"Search query": "dataslayer pricing", "Impressions": "50", "Clicks": "25",
         "CTR": "50", "Average Position": "1.2"},
        # quick_win + ctr_problem overlap
        {"Search query": "google sheets analytics", "Impressions": "900", "Clicks": "18",
         "CTR": "2.0", "Average Position": "6.1"},
    ]

    result = classify_queries(rows)

    check("quick_wins bucket populated",
          result["counts"]["quick_wins"] >= 1)

    # Verify "best analytics tool" is a quick_win (pos 7.2, 850 imp)
    qw_queries = {q["query"] for q in result["quick_wins"]}
    check("quick_wins includes position 7.2, 850 impressions query",
          "best analytics tool" in qw_queries)

    check("ctr_problems bucket populated",
          result["counts"]["ctr_problems"] >= 1)

    # "marketing dashboard" should be ctr_problem (pos 3.5, 1200 imp, CTR = 15/1200*100 = 1.25%)
    ctr_queries = {q["query"] for q in result["ctr_problems"]}
    check("ctr_problems includes low-CTR high-rank query",
          "marketing dashboard" in ctr_queries)

    check("high_impression_low_ctr bucket populated",
          result["counts"]["high_impression_low_ctr"] >= 1)

    # CTR calculation: uses clicks/impressions, not raw CTR field
    dashboard_entry = [q for q in result["ctr_problems"]
                       if q["query"] == "marketing dashboard"]
    if dashboard_entry:
        # 15/1200*100 = 1.25
        check("CTR calculated from clicks/impressions (1.25%)",
              abs(dashboard_entry[0]["ctr"] - 1.25) < 0.01)
    else:
        check("CTR calculated from clicks/impressions (1.25%)", False)

    end_section()


# ===================================================================
# E. MRR CALCULATION
# ===================================================================
def test_mrr_calculation():
    section("E. MRR Calculation")

    subs = [
        {"Subscription plan name": "Pro Monthly", "Subscription plan amount": "49",
         "Subscription plan interval": "month", "Subscription status": "active",
         "Subscription count": "10"},
        {"Subscription plan name": "Enterprise Annual", "Subscription plan amount": "1200",
         "Subscription plan interval": "year", "Subscription status": "active",
         "Subscription count": "5"},
        {"Subscription plan name": "Basic Monthly", "Subscription plan amount": "19",
         "Subscription plan interval": "month", "Subscription status": "active",
         "Subscription count": "25"},
        {"Subscription plan name": "Old Plan", "Subscription plan amount": "99",
         "Subscription plan interval": "month", "Subscription status": "canceled",
         "Subscription count": "3"},
    ]

    result = calculate_mrr(subs)

    # Monthly: Pro 49*10 = 490, Basic 19*25 = 475
    # Yearly: Enterprise 1200/12 * 5 = 500
    # Total active MRR: 490 + 500 + 475 = 1465
    check("Monthly plans calculated correctly",
          result["total_mrr"] == 1465.0)

    check("Yearly plans divide by 12",
          result["by_plan"]["Enterprise Annual"]["mrr"] == 500.0)

    check("Active subscriptions count excludes canceled",
          result["active_subscriptions"] == 40)

    check("Canceled subscriptions excluded from MRR",
          "Old Plan" not in result["by_plan"])

    check("by_plan breakdown has correct plans",
          len(result["by_plan"]) == 3)

    # Mixed: test with trialing included
    subs_trialing = [
        {"Subscription plan name": "Trial", "Subscription plan amount": "29",
         "Subscription plan interval": "month", "Subscription status": "trialing",
         "Subscription count": "2"},
    ]
    trial_result = calculate_mrr(subs_trialing)
    check("Trialing subscriptions included in MRR",
          trial_result["total_mrr"] == 58.0)

    end_section()


# ===================================================================
# F. CHURN CALCULATION
# ===================================================================
def test_churn_calculation():
    section("F. Churn Calculation")

    # Normal churn
    result = calculate_churn(active=950, cancelled=50, period_days=30)
    check("Normal churn rate = 5.0%",
          result["churn_rate"] == 5.0)

    # Zero active
    result_zero = calculate_churn(active=0, cancelled=0, period_days=30)
    check("Zero active accounts returns 0% churn",
          result_zero["churn_rate"] == 0)

    # Annualized rate
    result_ann = calculate_churn(active=900, cancelled=100, period_days=30)
    # churn_rate = 10%, annualized = 10 * (365/30) = 121.67 -> capped at 100
    check("Annualized rate capped at 100%",
          result_ann["annualized"] == 100.0)

    # Green status (<5%)
    result_green = calculate_churn(active=980, cancelled=20)
    check("Status Green for <5% churn",
          result_green["status"] == "Green")

    # Amber status (5-10%)
    result_amber = calculate_churn(active=920, cancelled=80)
    check("Status Amber for 5-10% churn",
          result_amber["status"] == "Amber")

    # Red status (>10%)
    result_red = calculate_churn(active=800, cancelled=200)
    check("Status Red for >10% churn",
          result_red["status"] == "Red")

    end_section()


# ===================================================================
# G. CANCELLATION ANALYSIS
# ===================================================================
def test_cancellation_analysis():
    section("G. Cancellation Analysis")

    rows = [
        {"Subscription cancellation reason": "too_expensive",
         "Subscription count": "15", "Subscription plan amount": "49"},
        {"Subscription cancellation reason": "missing_features",
         "Subscription count": "8", "Subscription plan amount": "29"},
        {"Subscription cancellation reason": "--",
         "Subscription count": "22", "Subscription plan amount": "19"},
        {"Subscription cancellation reason": "too_expensive",
         "Subscription count": "5", "Subscription plan amount": "99"},
    ]

    result = analyze_cancellations(rows)

    # Top reason sorting
    check("Top reason is 'No reason given' with count 22",
          result["top_reasons"][0]["reason"] == "No reason given" and
          result["top_reasons"][0]["count"] == 22)

    check("Second top reason is 'too_expensive' with count 20",
          result["top_reasons"][1]["reason"] == "too_expensive" and
          result["top_reasons"][1]["count"] == 20)

    # No-reason detection
    # total cancellations = 15+8+22+5 = 50, no_reason = 22
    check("No-reason percentage correct (22/50 = 44%)",
          abs(result["no_reason_pct"] - 44.0) < 0.1)

    # MRR lost: 15*49 + 8*29 + 22*19 + 5*99 = 735+232+418+495 = 1880
    check("MRR lost calculated correctly (1880)",
          result["total_mrr_lost"] == 1880.0)

    # Multiple reasons
    check("Multiple cancellation reasons tracked",
          len(result["top_reasons"]) == 3)

    end_section()


# ===================================================================
# H. PAYMENT FAILURE ANALYSIS
# ===================================================================
def test_payment_failure_analysis():
    section("H. Payment Failure Analysis")

    rows = [
        {"Charge Failure Code": "--", "Charge Amount": "49", "Customer ID": "cus_001", "Customer Email": "a@test.com", "Date": "2025-01-01"},
        {"Charge Failure Code": "card_declined", "Charge Amount": "49", "Customer ID": "cus_002", "Customer Email": "b@test.com", "Date": "2025-01-01"},
        {"Charge Failure Code": "card_declined", "Charge Amount": "29", "Customer ID": "cus_002", "Customer Email": "b@test.com", "Date": "2025-01-05"},
        {"Charge Failure Code": "card_declined", "Charge Amount": "29", "Customer ID": "cus_002", "Customer Email": "b@test.com", "Date": "2025-01-10"},
        {"Charge Failure Code": "insufficient_funds", "Charge Amount": "99", "Customer ID": "cus_003", "Customer Email": "c@test.com", "Date": "2025-01-02"},
        {"Charge Failure Code": "--", "Charge Amount": "99", "Customer ID": "cus_004", "Customer Email": "d@test.com", "Date": "2025-01-03"},
        {"Charge Failure Code": "--", "Charge Amount": "29", "Customer ID": "cus_005", "Customer Email": "e@test.com", "Date": "2025-01-04"},
        {"Charge Failure Code": "--", "Charge Amount": "49", "Customer ID": "cus_006", "Customer Email": "f@test.com", "Date": "2025-01-06"},
        {"Charge Failure Code": "expired_card", "Charge Amount": "19", "Customer ID": "cus_007", "Customer Email": "g@test.com", "Date": "2025-01-07"},
        {"Charge Failure Code": "--", "Charge Amount": "49", "Customer ID": "cus_008", "Customer Email": "h@test.com", "Date": "2025-01-08"},
    ]

    result = analyze_payment_failures(rows)

    # 5 failures out of 10 charges
    check("Failed vs successful charge filtering correct",
          result["failed_charges"] == 5 and result["successful_charges"] == 5)

    # Repeat offender: cus_002 has 3 failures
    check("Repeat offender detected (3+ failures)",
          len(result["repeat_failures"]) == 1 and
          result["repeat_failures"][0]["customer_id"] == "cus_002" and
          result["repeat_failures"][0]["failure_count"] == 3)

    # Failure rate: 5/10 = 50%
    check("Failure rate calculated correctly (50%)",
          result["failure_rate"] == 50.0)

    # Auto-detection of Title Case columns
    check("Auto-detected Title Case column names",
          result["total_charges"] == 10)

    # MRR at risk: all failed amounts sum: 49+29+29+99+19 = 225
    check("MRR at risk calculated correctly",
          result["mrr_at_risk"] == 225.0)

    end_section()


# ===================================================================
# I. CAMPAIGN PAUSE DETECTION
# ===================================================================
def test_campaign_pause_detection():
    section("I. Campaign Pause Detection")

    # Active campaign: has impressions on every day
    active_rows = [
        {"Date": "2025-01-01", "Campaign": "Brand Search", "Impressions": "500", "Cost": "50", "Conversions": "5"},
        {"Date": "2025-01-02", "Campaign": "Brand Search", "Impressions": "480", "Cost": "48", "Conversions": "4"},
        {"Date": "2025-01-03", "Campaign": "Brand Search", "Impressions": "510", "Cost": "51", "Conversions": "6"},
        {"Date": "2025-01-04", "Campaign": "Brand Search", "Impressions": "490", "Cost": "49", "Conversions": "5"},
        {"Date": "2025-01-05", "Campaign": "Brand Search", "Impressions": "520", "Cost": "52", "Conversions": "7"},
    ]

    result_active = detect_paused_campaigns(active_rows)
    brand = result_active["campaigns"][0]
    check("Active campaign is_paused=False",
          brand["is_paused"] is False)

    # Paused campaign: 0 impressions for last 4 days
    paused_rows = [
        {"Date": "2025-01-01", "Campaign": "Retargeting", "Impressions": "300", "Cost": "30", "Conversions": "3"},
        {"Date": "2025-01-02", "Campaign": "Retargeting", "Impressions": "280", "Cost": "28", "Conversions": "2"},
        {"Date": "2025-01-03", "Campaign": "Retargeting", "Impressions": "0", "Cost": "0", "Conversions": "0"},
        {"Date": "2025-01-04", "Campaign": "Retargeting", "Impressions": "0", "Cost": "0", "Conversions": "0"},
        {"Date": "2025-01-05", "Campaign": "Retargeting", "Impressions": "0", "Cost": "0", "Conversions": "0"},
        {"Date": "2025-01-06", "Campaign": "Retargeting", "Impressions": "0", "Cost": "0", "Conversions": "0"},
    ]

    result_paused = detect_paused_campaigns(paused_rows)
    retarg = result_paused["campaigns"][0]
    check("Paused campaign is_paused=True (4 trailing zero days)",
          retarg["is_paused"] is True)

    check("Paused campaign days_paused is 4",
          retarg["days_paused"] == 4)

    # Mixed active and paused
    mixed_rows = active_rows + paused_rows
    result_mixed = detect_paused_campaigns(mixed_rows)
    check("Mixed: any_paused is True when one campaign paused",
          result_mixed["any_paused"] is True)

    # est_conversions_lost: avg daily conv from active days * days paused
    # Retargeting: 2 active days, 5 total conversions, avg = 2.5/day, paused 4 days
    check("est_conversions_lost calculated for paused campaign",
          retarg["est_conversions_lost"] == round(2.5 * 4, 0))

    # active-days-only metrics
    check("Active days only counted for metrics (not full period)",
          retarg["active_days"] == 2 and retarg["total_days"] == 6)

    end_section()


# ===================================================================
# J. CPA SANITY CHECK
# ===================================================================
def test_cpa_sanity_check():
    section("J. CPA Sanity Check")

    # Green range for b2b_saas: normal_low=30 to normal_high=80
    result_green = cpa_sanity_check(45.0, "b2b_saas")
    check("Green range: CPA 45 for b2b_saas",
          result_green["status"] == "Green")

    # Red range: suspiciously low (<10 for b2b_saas)
    result_red = cpa_sanity_check(3.50, "b2b_saas")
    check("Red range: CPA 3.50 is suspiciously low for b2b_saas",
          result_red["status"] == "Red" and
          result_red["likely_issue"] == "conversion_tracking")

    # Amber range: above normal (>80 for b2b_saas)
    result_amber = cpa_sanity_check(95.0, "b2b_saas")
    check("Amber range: CPA 95 is above typical for b2b_saas",
          result_amber["status"] == "Amber" and
          result_amber["likely_issue"] == "audience_targeting")

    # Different vertical: ecommerce suspicious_low=2
    result_ecom = cpa_sanity_check(1.50, "ecommerce")
    check("Different vertical: ecommerce CPA 1.50 is Red",
          result_ecom["status"] == "Red")

    result_ecom_green = cpa_sanity_check(25.0, "ecommerce")
    check("Different vertical: ecommerce CPA 25 is Green",
          result_ecom_green["status"] == "Green")

    end_section()


# ===================================================================
# K. CONVERSION EVENT DETECTION
# ===================================================================
def test_conversion_event_detection():
    section("K. Conversion Event Detection")

    # Prefers sign_up
    rows_signup = [
        {"Event name": "sign_up", "Event count": "45"},
        {"Event name": "generate_lead", "Event count": "120"},
        {"Event name": "page_view", "Event count": "50000"},
    ]
    result = detect_conversion_event(rows_signup)
    check("Prefers sign_up when available",
          result["selected_event"] == "sign_up" and result["fallback_used"] is False)

    # Falls back to generate_lead when sign_up = 0
    rows_noleads = [
        {"Event name": "sign_up", "Event count": "0"},
        {"Event name": "generate_lead", "Event count": "85"},
        {"Event name": "page_view", "Event count": "30000"},
    ]
    result2 = detect_conversion_event(rows_noleads)
    check("Falls back to generate_lead when sign_up is 0",
          result2["selected_event"] == "generate_lead" and result2["fallback_used"] is True)

    # Falls back to form_submit with warning
    rows_form = [
        {"Event name": "form_submit", "Event count": "200"},
        {"Event name": "page_view", "Event count": "40000"},
    ]
    result3 = detect_conversion_event(rows_form)
    check("Falls back to form_submit with warning",
          result3["selected_event"] == "form_submit" and
          result3["warning"] is not None and "form_submit" in result3["warning"])

    # No events returns None with warning
    rows_none = [
        {"Event name": "page_view", "Event count": "50000"},
        {"Event name": "scroll", "Event count": "30000"},
    ]
    result4 = detect_conversion_event(rows_none)
    check("No conversion events returns None with warning",
          result4["selected_event"] is None and result4["warning"] is not None)

    end_section()


# ===================================================================
# L. CROSS-VALIDATION PAID vs STRIPE
# ===================================================================
def test_cross_validation():
    section("L. Cross-validation Paid vs Stripe")

    # Aligned (ratio <= 1.5)
    result_ok = cross_validate_paid_vs_stripe(5.0, 4.0)
    check("Aligned: ratio 1.25 is Green",
          result_ok["status"] == "Green" and result_ok["tracking_valid"] is True)

    # Mismatch (ratio > 3)
    result_bad = cross_validate_paid_vs_stripe(47.0, 3.0)
    check("Mismatch: ratio ~15.7 is Red",
          result_bad["status"] == "Red" and result_bad["tracking_valid"] is False)

    # Zero Stripe subs
    result_zero_stripe = cross_validate_paid_vs_stripe(10.0, 0.0)
    check("Zero Stripe subs returns Red",
          result_zero_stripe["status"] == "Red" and
          result_zero_stripe["tracking_valid"] is False)

    # Zero paid conversions
    result_zero_paid = cross_validate_paid_vs_stripe(0.0, 5.0)
    check("Zero paid conversions returns Amber",
          result_zero_paid["status"] == "Amber" and
          result_zero_paid["tracking_valid"] is None)

    end_section()


# ===================================================================
# M. PERIOD COMPARISON
# ===================================================================
def test_period_comparison():
    section("M. Period Comparison")

    current = {"sessions": 1200, "conversions": 50, "revenue": 5000}
    previous = {"sessions": 1000, "conversions": 48, "revenue": 0}

    result = compare_periods(current, previous)

    # Up direction (>5% change)
    check("Up direction for sessions (20% increase)",
          result["sessions_direction"] == "up" and result["sessions_change"] == 20.0)

    # Flat direction (within +/-5%)
    # conversions: (50-48)/48*100 = 4.17%
    check("Flat direction for conversions (4.17% change)",
          result["conversions_direction"] == "flat")

    # From zero (previous = 0)
    check("From zero: direction is 'new' when previous = 0",
          result["revenue_direction"] == "new" and result["revenue_change"] is None)

    # Down direction
    current_down = {"bounce_rate": 35}
    previous_down = {"bounce_rate": 50}
    result_down = compare_periods(current_down, previous_down)
    check("Down direction for bounce_rate (-30%)",
          result_down["bounce_rate_direction"] == "down")

    end_section()


# ===================================================================
# N. HELPERS
# ===================================================================
def test_helpers():
    section("N. Helpers")

    cols = ["Charge Failure Code", "Charge Amount", "Customer Email", "Date"]

    # _find_col: exact match
    check("_find_col exact match",
          _find_col(cols, "Charge Amount") == "Charge Amount")

    # _find_col: case-insensitive
    check("_find_col case-insensitive match",
          _find_col(cols, "charge_failure_code") == "Charge Failure Code")

    # _find_col: partial match
    check("_find_col partial match",
          _find_col(cols, "failure_code", "Charge Failure Code") == "Charge Failure Code")

    # _find_col: miss
    check("_find_col returns None for no match",
          _find_col(cols, "nonexistent_field") is None)

    # _to_float: various inputs
    check("_to_float with int", _to_float(42) == 42.0)
    check("_to_float with string number", _to_float("3.14") == 3.14)
    check("_to_float with currency", _to_float("$1,234.56") == 1234.56)
    check("_to_float with percentage", _to_float("75%") == 75.0)
    check("_to_float with non-numeric returns 0", _to_float("hello") == 0.0)
    check("_to_float with euro", _to_float("€99.50") == 99.5)

    # _is_numeric
    check("_is_numeric with int", _is_numeric(42) is True)
    check("_is_numeric with float", _is_numeric(3.14) is True)
    check("_is_numeric with numeric string", _is_numeric("100") is True)
    check("_is_numeric with text", _is_numeric("hello") is False)
    check("_is_numeric with '--'", _is_numeric("--") is False)
    check("_is_numeric with bool returns False", _is_numeric(True) is False)

    end_section()


# ===================================================================
# O. VALIDATION
# ===================================================================
def test_validation():
    section("O. Validation")

    # Valid data
    valid_rows = [
        {"Landing page": "/blog/post-1", "Sessions": "250", "Conversions": "5"},
        {"Landing page": "/pricing", "Sessions": "180", "Conversions": "12"},
        {"Landing page": "/features", "Sessions": "90", "Conversions": "3"},
    ]
    result = validate_mcp_result(valid_rows, "GA4")
    check("Valid data passes validation",
          result["valid"] is True and result["status"] == "Green")

    # Empty data
    result_empty = validate_mcp_result([], "GA4")
    check("Empty data fails validation",
          result_empty["valid"] is False and result_empty["status"] == "Red")

    # All-zero numeric column
    zero_rows = [
        {"Landing page": "/page-1", "Sessions": "0", "Conversions": "0"},
        {"Landing page": "/page-2", "Sessions": "0", "Conversions": "0"},
        {"Landing page": "/page-3", "Sessions": "0", "Conversions": "0"},
    ]
    result_zero = validate_mcp_result(zero_rows, "GA4")
    check("All-zero numeric columns flagged",
          len(result_zero["issues"]) > 0 and result_zero["status"] == "Amber")

    # Excessive blanks
    blank_rows = [{"reason": "--", "count": "5"}] * 20
    result_blank = validate_mcp_result(blank_rows, "Stripe")
    # "reason" column is 100% blank ("--") -> should be flagged
    has_blank_issue = any("blank" in issue.lower() for issue in result_blank["issues"])
    check("Excessive blanks flagged",
          has_blank_issue)

    end_section()


# ===================================================================
# P. CONFIGURATION
# ===================================================================
def test_configuration():
    section("P. Configuration")

    # Default config loads
    config = get_config()
    check("Default config loads and is a dict",
          isinstance(config, dict) and "blog_patterns" in config)

    check("Default config has expected blog_patterns",
          "/blog/" in config["blog_patterns"])

    # Config override changes is_blog_path behavior
    # Save a temp config file and load it
    tmp_config = {
        "blog_patterns": ["/recursos/", "/learn/"],
        "app_patterns": ["/internal/", "/admin-panel/"],
    }
    tmp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, "ds_utils_config.json")
    with open(tmp_path, "w") as f:
        json.dump(tmp_config, f)

    load_config(tmp_path)

    check("Config override changes is_blog_path behavior",
          is_blog_path("/recursos/articulo-1") is True and
          is_blog_path("/blog/post") is False)

    check("Config override changes is_app_path behavior",
          is_app_path("/internal/debug") is True and
          is_app_path("/dashboard/overview") is False)

    # Restore default config
    load_config("/nonexistent/path/that/will/fallback.json")

    # After restore, check defaults are back
    restored = get_config()
    check("get_config returns dict after restore",
          isinstance(restored, dict) and "/blog/" in restored["blog_patterns"])

    # Cleanup
    os.remove(tmp_path)
    os.rmdir(tmp_dir)

    end_section()


# ===================================================================
# Q. ERROR HANDLING
# ===================================================================
def test_error_handling():
    section("Q. Error Handling")

    # _read_mcp_file with nonexistent file
    import io
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    result = _read_mcp_file("/nonexistent/path/to/file.tsv")

    sys.stderr = old_stderr
    check("_read_mcp_file with nonexistent file returns []",
          result == [])

    # _read_mcp_file with empty content
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".tsv", delete=False)
    tmp.write("")
    tmp.close()

    sys.stderr = io.StringIO()
    result_empty = _read_mcp_file(tmp.name)
    sys.stderr = old_stderr

    check("_read_mcp_file with empty content returns []",
          result_empty == [])
    os.remove(tmp.name)

    # CLI doesn't crash on bad input (test via subprocess)
    import subprocess
    proc = subprocess.run(
        [sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "ds_utils.py"),
         "process-ga4-pages", "/nonexistent/file.tsv"],
        capture_output=True, text=True
    )
    check("CLI doesn't crash on bad input (exits without unhandled exception)",
          proc.returncode in (0, 1))

    end_section()


# ===================================================================
# MAIN
# ===================================================================
def main():
    print("=" * 60)
    print("  ds_utils.py — Comprehensive Test Suite")
    print("=" * 60)

    test_url_processing()
    test_ga4_page_processing()
    test_content_classification()
    test_search_console_classification()
    test_mrr_calculation()
    test_churn_calculation()
    test_cancellation_analysis()
    test_payment_failure_analysis()
    test_campaign_pause_detection()
    test_cpa_sanity_check()
    test_conversion_event_detection()
    test_cross_validation()
    test_period_comparison()
    test_helpers()
    test_validation()
    test_configuration()
    test_error_handling()

    print(f"\n{'=' * 60}")
    print(f"  FINAL RESULTS: {_total_pass} passed, {_total_fail} failed")
    print(f"{'=' * 60}")

    if _total_fail > 0:
        print(f"\n  FAILED: {_total_fail} test(s) did not pass.")
        sys.exit(1)
    else:
        print(f"\n  ALL {_total_pass} TESTS PASSED.")
        sys.exit(0)


if __name__ == "__main__":
    main()
