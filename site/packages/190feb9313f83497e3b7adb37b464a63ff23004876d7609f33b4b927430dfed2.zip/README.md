# Dataslayer Marketing Skills

**Marketing analysis skills with a real analysis engine.** Audit paid campaigns, find SEO opportunities, detect churn signals, and generate branded PDF reports — powered by 113 tested functions that handle the math deterministically.

Works with any data: connect the [Dataslayer MCP](https://dataslayer.ai/mcp) for automatic data fetching from 50+ platforms, or paste your own CSV/JSON manually.

Compatible with [Claude Desktop](https://claude.ai/download) (Cowork), [Claude Code](https://code.claude.com), Cursor, Windsurf, and any agent that supports the [Agent Skills spec](https://agentskills.io).

---

## Table of contents

- [Installation](#installation) — plugin vs individual skills, where and how
  - [Plugin install (Cowork)](#option-1--full-plugin-cowork-only)
  - [Individual skills (any plan)](#option-2--individual-skills-any-plan)
  - [Claude Code (terminal)](#option-3--claude-code-terminal)
- [Two ways to use](#two-ways-to-use-these-skills)
- [What is Dataslayer](#what-is-dataslayer)
- [Why this is different](#why-this-is-different-from-every-other-marketing-skills-repo)
- [Skills overview](#skills-overview)
- [ds-brain](#ds-brain)
- [ds-report-pdf](#ds-report-pdf)
- [ds-paid-audit](#ds-paid-audit)
- [ds-channel-report](#ds-channel-report)
- [ds-seo-weekly](#ds-seo-weekly)
- [ds-content-perf](#ds-content-perf)
- [ds-churn-signals](#ds-churn-signals)
- [Business context](#business-context-optional-but-recommended)
- [Quick start](#quick-start)
- [Supported platforms](#supported-platforms)
- [Contributing](#contributing)

---

## Installation

### Plugin vs individual skills — what's the difference?

| | **Plugin** (1 file, everything included) | **Individual skills** (1 file per skill) |
|---|---|---|
| **What you get** | All 7 skills + 4 agents + analysis engine | One skill at a time |
| **File** | [`dataslayer-marketing-skills.zip`](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/dataslayer-marketing-skills.zip) | See table below |
| **Where it works** | Claude Desktop with **Cowork** plan | claude.ai web, Claude Desktop (any plan) |
| **Upload path** | Customize → **Personal plugins → + → Upload plugin** | Customize → **Skills → + → Upload skill** |

> Don't know which to choose? If you have Cowork, use the **plugin** — it's one download and you get everything. If not, install the **individual skills** you need.

---

<a id="option-1"></a>

### Option 1 — Full plugin (Cowork only)

**Requires:** Claude Desktop with a [Cowork](https://claude.ai/cowork) plan.

1. **Download** [`dataslayer-marketing-skills.zip`](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/dataslayer-marketing-skills.zip)
2. Open Claude Desktop → click **Customize** in the left sidebar
3. Under **Personal plugins**, click the **+** button → **Upload plugin**

   ![Customize panel — click + next to Personal plugins](assets/plugin-install-personal-plugins.png)

4. Select the `.zip` file and click **Upload**

Done — all 7 skills, 4 agents, and the analysis engine are ready.

> **Note:** The file must have a `.zip` extension — `.plugin` is not accepted ([known issue](https://github.com/anthropics/claude-code/issues/28337)).

---

<a id="individual-install"></a>
<a id="option-2"></a>

### Option 2 — Individual skills (any plan)

**Works on:** claude.ai web and Claude Desktop — **no Cowork required**.

1. Download the skill you need from the table below
2. Go to **Customize → Skills → +** → **Upload skill**

   ![Skills section — click + then Upload skill](assets/skill-install-skills-menu.png)

3. Select the `.zip` file and click **Upload**
4. Repeat for each skill you want

| Skill | What it does | Download |
|---|---|---|
| **ds-brain** | Cross-functional strategic analysis across all channels | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-brain.zip) |
| **ds-paid-audit** | Audit Google Ads, Meta Ads, LinkedIn Ads campaigns | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-paid-audit.zip) |
| **ds-seo-weekly** | Weekly SEO performance and ranking opportunities | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-seo-weekly.zip) |
| **ds-content-perf** | Blog and content performance vs conversions | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-content-perf.zip) |
| **ds-channel-report** | Channel-by-channel performance report | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-channel-report.zip) |
| **ds-churn-signals** | Detect accounts at risk of churning | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-churn-signals.zip) |
| **ds-report-pdf** | Generate branded PDF reports for clients | [Download .zip](https://github.com/Dataslayer-AI/Marketing-skills/raw/main/individual-skills/ds-report-pdf.zip) |

> **Tip:** Each `.zip` contains exactly one skill. The "Upload skill" dialog only accepts one `SKILL.md` per file.

---

<a id="option-3"></a>

### Option 3 — Claude Code (terminal)

**Works on:** [Claude Code](https://code.claude.com), Cursor, Windsurf.

<details>
<summary><strong>Install with --plugin-dir (recommended for development)</strong></summary>

```bash
git clone https://github.com/Dataslayer-AI/Marketing-skills.git
claude --plugin-dir ./Marketing-skills
```

Skills are available immediately. Use `/reload-plugins` if you make changes.

</details>

<details>
<summary><strong>Install via marketplace</strong></summary>

```bash
/plugin marketplace add Dataslayer-AI/Marketing-skills
/plugin install dataslayer-marketing-skills@dataslayer-ai-marketing-skills
```

Run `/reload-plugins` after installing. Skills are namespaced — try `/dataslayer-marketing-skills:ds-paid-audit`.

</details>

<details>
<summary><strong>Manual copy (Claude Code / Cursor / Windsurf)</strong></summary>

```bash
git clone https://github.com/Dataslayer-AI/Marketing-skills.git .marketing-skills-tmp

cp -r .marketing-skills-tmp/skills/*  .claude/skills/
cp -r .marketing-skills-tmp/agents/*  .claude/agents/
cp .marketing-skills-tmp/scripts/ds_utils.py .claude/scripts/

rm -rf .marketing-skills-tmp
```

Restart Claude Code. Skills are auto-discovered — try `/ds-paid-audit`.

</details>

---

## Two ways to use these skills

### ⚡ Automatic mode — with Dataslayer MCP (recommended)

Connect the [Dataslayer MCP](https://dataslayer.ai/mcp) and the skills
fetch your live data automatically. No exports, no copy-pasting.

```
You:    "Audit my Google Ads campaigns"
Claude: [fetches live data from Google Ads, Meta, GA4...]
        "Your Europe campaign has a CPA of €84 vs your €52 target.
         Here are 3 specific actions to fix it this week."
```

**Setup:** [dataslayer.ai/mcp](https://dataslayer.ai/mcp) — takes ~5 minutes.
Requires a Dataslayer Advanced plan or higher.

### 📋 Manual mode — without any MCP

Don't have Dataslayer yet? The skills still work. Paste your data
(CSV, TSV, JSON, or a table in the chat) and get the same analysis,
same benchmarks, same recommendations.

```
You:    "Audit my Google Ads campaigns"
Claude: "I don't detect a Dataslayer MCP. You can set one up at
         dataslayer.ai/mcp for automatic data fetching.

         For now, paste or upload your campaign data and I'll
         run the same analysis. Required columns: campaign name,
         impressions, clicks, cost, conversions."
```

Same analysis engine. Same quality. Just less automation.

---

## What is Dataslayer

[Dataslayer](https://dataslayer.ai) is a marketing data integration platform trusted by 2,000+ companies worldwide. It connects 50+ marketing platforms — Google Ads, Meta Ads, LinkedIn Ads, GA4, Search Console, TikTok Ads, and more — to destinations like Google Sheets, Looker Studio, BigQuery, Snowflake, and Excel.

Built by [Softpoint](https://dataslayer.ai/about-us), Dataslayer is ISO 27001 and ISO 27701 certified, independently audited for security and privacy.

The [Dataslayer MCP](https://dataslayer.ai/mcp) is what makes these skills different: it gives Claude direct, live access to your marketing data — no exports, no copy-pasting, no stale CSVs.

---

## Why this is different from every other marketing skills repo

Other marketing skills repos give Claude generic instructions. These skills
include a tested analysis engine — `ds_utils.py` with 113 tests — that
handles UTM stripping, page classification, MRR calculation, campaign
pause detection, CPA sanity checks, and period comparison deterministically.

**The analysis is the product.** Whether data comes from Dataslayer MCP
automatically or from a CSV you paste manually, the same engine runs:
same benchmarks, same classifications, same actionable output.

With the Dataslayer MCP connected, it goes from good to effortless:
```
# Without Dataslayer MCP (still works):
You:    "Audit my Google Ads campaigns"
Claude: "Paste your campaign data — I need: campaign, spend, clicks, conversions"
You:    [pastes CSV]
Claude: "Your Europe campaign has a CPA of €84 vs your €52 target..."

# With Dataslayer MCP (zero friction):
You:    "Audit my Google Ads campaigns"
Claude: [fetches live data automatically]
        "Your Europe campaign has a CPA of €84 vs your €52 target..."
```

---

## Skills overview

| Skill | What it does | Output |
|-------|-------------|--------|
| [`ds-brain`](#ds-brain) | Full marketing intelligence — 4 parallel agents, all channels at once | Analysis |
| [`ds-report-pdf`](#ds-report-pdf) | Branded client PDF report, generated and executed automatically | PDF file |
| [`ds-paid-audit`](#ds-paid-audit) | Paid media deep-dive: CPA, audiences, budget waste, creative fatigue | Analysis |
| [`ds-channel-report`](#ds-channel-report) | Weekly cross-channel digest with anomaly detection | Analysis |
| [`ds-seo-weekly`](#ds-seo-weekly) | SEO opportunities: quick wins, CTR problems, ranking drops | Analysis |
| [`ds-content-perf`](#ds-content-perf) | Content that converts vs content that just gets traffic | Analysis |
| [`ds-churn-signals`](#ds-churn-signals) | Accounts about to cancel — before they hit the button | Analysis |

The repo also includes three development/QA tools (`ds-lint`, `ds-eval`, `ds-audit`) used for validating and testing skills. See [CONTRIBUTING.md](./CONTRIBUTING.md) for details.

---

## ds-brain

> **No other marketing skills repository does this today.**

`ds-brain` launches four specialized subagents simultaneously. While every other skill analyzes one channel at a time, `ds-brain` runs paid, organic, content, and retention in parallel — and then finds the connections between them.
```
You: "Give me the full picture"

Claude launches 4 agents at once:
├── ds-agent-paid     → Google Ads, Meta, LinkedIn data
├── ds-agent-organic  → Search Console, GA4 organic
├── ds-agent-content  → Blog performance, conversions by page
└── ds-agent-retention → At-risk accounts, MRR at risk

Claude synthesizes all four and finds cross-channel patterns:

"Your paid CPA improved 18% this month — but retention data shows
accounts acquired in the same period have a 34% lower activation rate.
The algorithm found cheaper traffic. It's the wrong audience.
Every euro saved in acquisition is being lost twice in churn.

This week's priority: pause the Europe PMax campaign and audit
audience signals before reactivating."
```

One command. Four agents running simultaneously. One clear priority for the week.

---

## ds-report-pdf

> **Turn any analysis into a client-ready PDF with a single command.**

`ds-report-pdf` fetches real data, analyzes it, writes Python code, executes it, and delivers a professional branded PDF — all automatically.

### Fully customizable in plain English

You never touch a config file unless you want to. Just tell Claude what you need:
```
"Generate the monthly report for Acme Corp.
Use their logo from https://acmecorp.com/logo.png,
brand color #1B2F6E, report in Spanish,
footer should say Prepared by Agency XYZ."
```
```
"Make it darker blue"
"Remove the retention section, not relevant for this client"
"Shorter — just 2 pages with the key numbers"
"Save these settings for Acme Corp"
```

Every preference is applied immediately and remembered for the rest of the session.

### What the PDF includes

- **Cover page** — client logo, brand colors, report period, agency footer
- **Executive summary** — top-line metrics in a scannable card grid
- **Channel performance** — tables with current vs previous period, color-coded changes
- **Key findings** — max 3, each with what happened, why it matters, what to do
- **Recommended actions** — numbered, prioritized, with expected impact
- **Page headers and footers** — client name, agency name, page numbers

### What you can customize

| Element | How to change it |
|---------|-----------------|
| Logo | "Use logo from [URL or file path]" |
| Brand color | "Use color #FF6B35" or "make it navy blue" |
| Language | "In Spanish" / "En français" / "Auf Deutsch" |
| Client name | "This report is for Acme Corp" |
| Agency name | "Prepared by Agency XYZ" |
| Date range | "Last month" / "Q1 2026" / "Last 30 days" |
| Channels | "Only Google Ads and organic" / "Add TikTok" |
| Sections | "Without the appendix" / "Add an executive summary" |
| Length | "Make it shorter" / "2 pages only" |
| Targets | "Our CPA target is €45" — shown as benchmark in tables |

### The agency workflow
```
Step 1: "Give me the full picture"
        → ds-brain analyzes everything in parallel

Step 2: "Generate the client report for Acme Corp"
        → ds-report-pdf produces the branded PDF

Step 3: Send the PDF directly to your client.
```

Two commands. Zero manual work. One PDF ready to send.

### Saving client settings

Once you have the right setup for a client, say:
```
"Save these settings for Acme Corp"
```

Claude writes `dataslayer-config.json` automatically. Next month:
```
"Monthly report for Acme Corp"
```

That's it. Logo, colors, language, channels — all remembered.

---

## ds-paid-audit

Deep-dive into paid media campaigns. Detects budget traps, audience mismatches, creative fatigue, and conversion tracking issues.
```
You: "Audit my paid campaigns"

Claude: [fetches Google Ads + Meta + LinkedIn via MCP]

"AUDIENCE MISMATCH IN PMAX EUROPE · Severity: High

What is happening: 'Pet Food & Supplies' audience is generating 39% of
conversions at a CPA of €124, vs your target of €52.

Why it matters: You are spending €1,800/month on users unlikely to be
your ICP, inflating your blended CPA by ~35%.

What to do: Add 'Pet Food & Supplies' as a negative audience signal.
Monitor for 7 days."
```

---

## ds-channel-report

Weekly cross-channel digest. Scans for anomalies (any metric moving ±25% week over week), forms hypotheses about the cause, and delivers a concise report with one clear "signal of the week."

---

## ds-seo-weekly

Classifies your Search Console data into four buckets before writing anything:

- **Quick wins** — queries ranking 4–15 with >200 impressions. One content update away from page 1.
- **CTR problems** — ranking 1–10 but CTR below 3%. Fix the title, not the content.
- **Ranking drops** — positions lost >5 places. Immediate investigation needed.
- **Conversion gaps** — high traffic pages with conversion rate below 0.5%.

---

## ds-content-perf

Separates content into four categories: stars (high traffic + high conversion), traffic without conversion, conversion without traffic (hidden gems), and neither. Tells you exactly what to publish next based on what the data shows actually converts.

---

## ds-churn-signals

Red / Amber / Green risk scoring for every active paid account. Surfaces MRR at risk before accounts cancel. Distinguishes between stated cancellation reason and real reason based on usage data.
```
"Stated reason: Too expensive
Usage data: 3 queries in 90 days, never ran a report
Real reason: Never got value. Price was the excuse, not the cause."
```

---

## Business context (optional but recommended)

Every skill tries to load `.agents/product-marketing-context.md` automatically. This file tells Claude about your product, targets, and channels — so it can give relevant analysis instead of asking you setup questions every time.

To set it up (from the repo root):
```bash
cp .agents/product-marketing-context.example.md .agents/product-marketing-context.md
# Edit the file with your details
```

Without this file, skills still work — they'll just ask a fallback question on the first run.

---

## Quick start
```
"Give me the full picture"
→ ds-brain (4 parallel agents, all channels)

"Generate the monthly report for my client"
→ ds-report-pdf (branded PDF, ready to send)

"Audit my paid campaigns"
→ ds-paid-audit

"Weekly marketing summary"
→ ds-channel-report

"What are my best SEO opportunities this week?"
→ ds-seo-weekly

"Which blog posts are driving the most trials?"
→ ds-content-perf

"Which accounts are about to cancel?"
→ ds-churn-signals
```

---

## Supported platforms

**Paid media (full audit support):** Google Ads, Meta Ads (Facebook/Instagram), LinkedIn Ads

**Paid media (basic metrics in cross-channel reports):** TikTok Ads, Reddit Ads

**Analytics:** Google Analytics 4, Google Search Console

**Retention:** Stripe (subscription health, payment failures, churn signals)

**Destinations:** Google Sheets, Looker Studio, BigQuery, Snowflake, Excel

Dataslayer connects 50+ platforms — the skills above cover the channels with dedicated analysis logic. Other channels connected via Dataslayer will appear in raw data fetches but won't have skill-specific audit logic.

Full connector list at [dataslayer.ai/connectors](https://dataslayer.ai/connectors)

---

## Contributing

Found a bug or want to add a skill? PRs and issues welcome.

See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

---

## License

MIT — use freely.

---

*Built by [Dataslayer](https://dataslayer.ai) — the marketing data platform for teams that run on data.*