#!/usr/bin/env python3
"""
Skill Linter — validates SKILL.md and agent .md files against the Claude Code spec.

Usage:
    python lint_skills.py [path_to_repo_root]

If no path is given, defaults to the parent of this script's directory (../../..).
"""

import os
import re
import sys
import yaml
from pathlib import Path

# ── Configuration ──────────────────────────────────────────────────────────────

VALID_FRONTMATTER_FIELDS_SKILL = {
    "name", "description", "model", "allowed-tools",
    "argument-hint", "disable-model-invocation", "user-invocable",
}
VALID_FRONTMATTER_FIELDS_AGENT = {
    "name", "description", "model", "allowed-tools", "skills",
}
VALID_MODELS = {"sonnet", "opus", "haiku"}
MAX_LINES = 500
MIN_DESCRIPTION_LENGTH = 80
NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$")
HARDCODED_PATH_PATTERN = re.compile(r"(/home/|/Users/|C:\\|/tmp/)[^\s\"'`]+")
MCP_MENTION_PATTERN = re.compile(r"mcp__|Dataslayer MCP|dataslayer", re.IGNORECASE)
BASH_MENTION_PATTERN = re.compile(r"Bash\(|bash tool|pip |python ", re.IGNORECASE)
ARGUMENTS_PATTERN = re.compile(r"\$ARGUMENTS|\$0|\$1")
SKILL_DIR_PATTERN = re.compile(r"\$\{CLAUDE_SKILL_DIR\}")
CONTEXT_INJECTION_PATTERN = re.compile(r"!`[^`]+`")

# Triggering phrases — descriptions should contain quoted phrases or "when the user"
TRIGGERING_PATTERN = re.compile(r'"[^"]{3,}"')
USER_TRIGGER_PATTERN = re.compile(r"when the user|activate when|use this skill when", re.IGNORECASE)


# ── Helpers ────────────────────────────────────────────────────────────────────

class LintResult:
    def __init__(self, file_path: str, file_type: str):
        self.file_path = file_path
        self.file_type = file_type  # "skill" or "agent"
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.passes: list[str] = []

    def error(self, msg: str):
        self.errors.append(msg)

    def warn(self, msg: str):
        self.warnings.append(msg)

    def ok(self, msg: str):
        self.passes.append(msg)

    @property
    def status(self) -> str:
        if self.errors:
            return "FAIL"
        if self.warnings:
            return "WARN"
        return "PASS"


def parse_frontmatter(content: str) -> tuple[dict | None, str]:
    """Extract YAML frontmatter and body from a markdown file."""
    if not content.startswith("---"):
        return None, content

    parts = content.split("---", 2)
    if len(parts) < 3:
        return None, content

    try:
        fm = yaml.safe_load(parts[1])
        if not isinstance(fm, dict):
            return None, content
        return fm, parts[2]
    except yaml.YAMLError:
        return None, content


def count_lines(content: str) -> int:
    return len(content.strip().split("\n"))


# ── Lint checks ────────────────────────────────────────────────────────────────

def lint_file(file_path: Path, file_type: str) -> LintResult:
    """Run all lint checks on a single file."""
    result = LintResult(str(file_path), file_type)
    content = file_path.read_text(encoding="utf-8")
    fm, body = parse_frontmatter(content)
    valid_fields = VALID_FRONTMATTER_FIELDS_SKILL if file_type == "skill" else VALID_FRONTMATTER_FIELDS_AGENT

    # ── 1. Frontmatter exists ──────────────────────────────────────────────
    if fm is None:
        result.error("No YAML frontmatter found (missing --- delimiters)")
        return result  # Can't check anything else
    result.ok("Frontmatter present")

    # ── 2. Name field ──────────────────────────────────────────────────────
    name = fm.get("name")
    if not name:
        result.error("Missing 'name' field in frontmatter")
    elif not NAME_PATTERN.match(str(name)):
        result.error(f"Invalid name '{name}' — must be [a-z0-9-], 2-64 chars, no leading/trailing hyphen")
    else:
        result.ok(f"Name '{name}' is valid")

    # ── 3. Description field ───────────────────────────────────────────────
    desc = fm.get("description", "")
    desc_str = str(desc).strip()
    if not desc_str:
        result.error("Missing 'description' field in frontmatter")
    elif len(desc_str) < MIN_DESCRIPTION_LENGTH:
        result.error(f"Description too short ({len(desc_str)} chars, min {MIN_DESCRIPTION_LENGTH})")
    else:
        result.ok(f"Description present ({len(desc_str)} chars)")

    # ── 4. Description quality (skills only) ───────────────────────────────
    if file_type == "skill" and desc_str:
        has_trigger_phrases = bool(TRIGGERING_PATTERN.search(desc_str))
        has_user_trigger = bool(USER_TRIGGER_PATTERN.search(desc_str))
        if has_trigger_phrases and has_user_trigger:
            result.ok("Description has triggering keywords and quoted phrases")
        elif has_user_trigger and not has_trigger_phrases:
            result.warn("Description mentions user triggers but has no quoted example phrases")
        elif not has_user_trigger:
            result.warn("Description lacks 'when the user says' / 'activate when' pattern")

    # ── 5. Invalid fields ──────────────────────────────────────────────────
    invalid = set(fm.keys()) - valid_fields
    if invalid:
        result.warn(f"Unknown frontmatter fields (will be ignored): {', '.join(sorted(invalid))}")
    else:
        result.ok("No unknown frontmatter fields")

    # ── 6. Model field ─────────────────────────────────────────────────────
    model = fm.get("model")
    if not model:
        result.warn("No 'model' field — will inherit from session (consider being explicit)")
    elif str(model) not in VALID_MODELS:
        result.error(f"Invalid model '{model}' — must be one of: {', '.join(sorted(VALID_MODELS))}")
    else:
        result.ok(f"Model '{model}' is valid")

    # ── 7. Allowed-tools ───────────────────────────────────────────────────
    allowed = fm.get("allowed-tools")
    needs_tools = bool(MCP_MENTION_PATTERN.search(content)) or bool(BASH_MENTION_PATTERN.search(content))
    if allowed:
        result.ok("allowed-tools defined")
    elif needs_tools:
        result.error("File references MCP/Bash tools but has no 'allowed-tools' in frontmatter")
    else:
        result.ok("No tool references found, allowed-tools not needed")

    # ── 8. Line count ──────────────────────────────────────────────────────
    lines = count_lines(content)
    if lines > MAX_LINES:
        result.warn(f"File has {lines} lines (recommended max {MAX_LINES})")
    else:
        result.ok(f"Line count OK ({lines} lines)")

    # ── 9. $ARGUMENTS without argument-hint ────────────────────────────────
    # Filter out $ARGUMENTS mentions inside tables (| ... |) and code blocks
    body_no_tables = re.sub(r"\|[^\n]*\|", "", body)
    body_no_code = re.sub(r"```[\s\S]*?```", "", body_no_tables)
    if ARGUMENTS_PATTERN.search(body_no_code):
        if not fm.get("argument-hint"):
            result.warn("Uses $ARGUMENTS but has no 'argument-hint' in frontmatter")
        else:
            result.ok("$ARGUMENTS used with matching argument-hint")

    # ── 10. ${CLAUDE_SKILL_DIR} usage ──────────────────────────────────────
    if file_type == "skill":
        # Check if body references local files/scripts
        refs_local = bool(re.search(r"scripts/|\.py|\.sh|\.js", body))
        uses_skill_dir = bool(SKILL_DIR_PATTERN.search(body))
        if refs_local and not uses_skill_dir:
            result.warn("References local scripts but doesn't use ${CLAUDE_SKILL_DIR} — may break if invoked from another directory")
        elif refs_local and uses_skill_dir:
            result.ok("Uses ${CLAUDE_SKILL_DIR} for local file references")

    # ── 11. Hardcoded paths ────────────────────────────────────────────────
    hardcoded = HARDCODED_PATH_PATTERN.findall(content)
    if hardcoded:
        examples = hardcoded[:3]
        result.error(f"Hardcoded absolute paths found: {', '.join(examples)}")
    else:
        result.ok("No hardcoded absolute paths")

    # ── 12. Context injection (skills only) ────────────────────────────────
    if file_type == "skill":
        if CONTEXT_INJECTION_PATTERN.search(body):
            result.ok("Uses dynamic context injection (!`command`)")
        else:
            result.warn("No dynamic context injection found — consider using !`command` for auto-loading context")

    # ── 13. disable-model-invocation for risky skills ──────────────────────
    if file_type == "skill":
        has_bash = bool(re.search(r"Bash\(", str(allowed or "")))
        has_write = bool(re.search(r"\bWrite\b", str(allowed or "")))
        is_disabled = fm.get("disable-model-invocation", False)
        if (has_bash or has_write) and not is_disabled:
            result.warn("Skill has Bash/Write permissions but disable-model-invocation is not set — Claude could invoke it automatically")

    return result


# ── Discovery ──────────────────────────────────────────────────────────────────

def find_files(repo_root: Path) -> list[tuple[Path, str]]:
    """Find all SKILL.md files and agent .md files."""
    files = []

    # Skills
    skills_dir = repo_root / "skills"
    if skills_dir.exists():
        for skill_md in skills_dir.rglob("SKILL.md"):
            files.append((skill_md, "skill"))

    # Agents
    agents_dir = repo_root / "agents"
    if agents_dir.exists():
        for agent_md in agents_dir.glob("*.md"):
            files.append((agent_md, "agent"))

    return sorted(files, key=lambda x: x[0].name)


# ── Output ─────────────────────────────────────────────────────────────────────

def print_results(results: list[LintResult]):
    """Print a formatted report of all lint results."""
    total = len(results)
    passed = sum(1 for r in results if r.status == "PASS")
    warned = sum(1 for r in results if r.status == "WARN")
    failed = sum(1 for r in results if r.status == "FAIL")

    # Summary table
    print("\n" + "=" * 72)
    print("  SKILL LINTER REPORT")
    print("=" * 72)
    print(f"\n  Files scanned: {total}")
    print(f"  Passed:  {passed}  |  Warnings: {warned}  |  Failed: {failed}")
    print()

    # Status table
    print(f"  {'File':<30} {'Type':<8} {'Status':<8} {'Errors':<8} {'Warns':<8}")
    print("  " + "-" * 62)
    for r in results:
        name = Path(r.file_path).stem
        parent = Path(r.file_path).parent.name
        display = f"{parent}/{name}" if name == "SKILL" else name
        icon = {"PASS": "OK", "WARN": "!!", "FAIL": "XX"}[r.status]
        print(f"  {display:<30} {r.file_type:<8} {icon:<8} {len(r.errors):<8} {len(r.warnings):<8}")

    # Detailed results
    print("\n" + "-" * 72)
    for r in results:
        if r.errors or r.warnings:
            print(f"\n  {r.file_path}")
            for e in r.errors:
                print(f"    [ERROR] {e}")
            for w in r.warnings:
                print(f"    [WARN]  {w}")

    # Overall verdict
    print("\n" + "=" * 72)
    if failed:
        print("  RESULT: FAIL — fix errors above before shipping")
    elif warned:
        print("  RESULT: PASS with warnings — review items above")
    else:
        print("  RESULT: ALL CLEAR")
    print("=" * 72 + "\n")

    return 1 if failed else 0


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    if len(sys.argv) > 1:
        repo_root = Path(sys.argv[1])
    else:
        # Default: three levels up from this script
        repo_root = Path(__file__).resolve().parent.parent.parent.parent

    if not repo_root.exists():
        print(f"Error: {repo_root} does not exist")
        sys.exit(1)

    files = find_files(repo_root)
    if not files:
        print(f"No SKILL.md or agent .md files found in {repo_root}")
        sys.exit(1)

    results = [lint_file(path, file_type) for path, file_type in files]
    exit_code = print_results(results)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
