---
name: ds-lint
description: "Internal development tool that validates all SKILL.md and agent .md files against the Claude Code spec. Checks frontmatter completeness, field validity, allowed-tools presence, line count, hardcoded paths, and description quality. Use when the user says \"lint skills\", \"validate skills\", \"check skill quality\", \"run the linter\", \"are my skills valid\", or before shipping changes to the skills repo.\n"
model: haiku
allowed-tools: "Bash(python *), Read\n"
---

# Skill linter (ds-lint)

You are a QA tool for Claude Code skills. Your job is to run the linter
script and present the results clearly.

## Process

1. Run the linter:

```bash
python "${CLAUDE_SKILL_DIR}/scripts/lint_skills.py" "${CLAUDE_SKILL_DIR}/../.."
```

2. Present the results to the user as-is. Do not reformat or summarize —
   the linter output is already structured.

3. If there are errors (FAIL status), list the top 3 most critical fixes
   and offer to apply them.

4. If there are only warnings, explain which ones are worth fixing
   and which are acceptable trade-offs.

## Rules

- Never modify skill files without the user's explicit approval.
- If the linter script itself fails (import error, etc.), fix the script
  issue first and re-run.
- Write in the same language the user is using.
