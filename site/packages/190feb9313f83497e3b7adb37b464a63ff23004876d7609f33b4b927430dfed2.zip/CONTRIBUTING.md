# Contributing to Dataslayer Skills

## How to add a skill

1. Create a folder under `skills/` with the skill name (e.g. `skills/ds-my-skill/`)
2. Add a `SKILL.md` file inside it following the structure below
3. If the skill needs supporting files (scripts, templates), add a `scripts/` subdirectory
4. Open a pull request with a short description of what the skill does

## How to add a subagent

1. Create a `.md` file under `agents/` (e.g. `agents/ds-agent-my-domain.md`)
2. Include YAML frontmatter with `name`, `description`, `model`, and `allowed-tools`
3. Subagents return structured findings only — no interpretation, no recommendations

## SKILL.md structure

```markdown
---
name: ds-skill-name
description: >
  What this skill does AND when to use it. Include exact phrases
  a user might say to trigger it. The description is the primary
  signal Claude uses for auto-invocation — be specific.
model: sonnet
allowed-tools: >
  Read,
  mcp__*__natural_to_data,
  mcp__*__check_task_id,
  mcp__*__get_available_connections_and_accounts_info_by_datasource,
  mcp__*__get_available_fields_by_datasource
argument-hint: [optional-argument]
---

# Skill title

Role paragraph — who Claude is when using this skill.

## Step 1 — Read context

Business context (auto-loaded):
!`cat .agents/product-marketing-context.md 2>/dev/null || echo "No context file found."`

## Step 2 — Get the data (dual mode: MCP automatic or manual)
## Step 3 — Analysis logic
## Step 4 — Output format

## Tone and output rules

## Related skills
```

## Subagent structure

Each subagent is a directory with an `AGENT.md` file:
`agents/ds-agent-domain/AGENT.md`

```markdown
---
name: ds-agent-domain
description: >
  What this subagent extracts and from which data sources.
model: sonnet
allowed-tools: >
  mcp__*__natural_to_data,
  mcp__*__check_task_id,
  mcp__*__get_available_connections_and_accounts_info_by_datasource,
  mcp__*__get_available_fields_by_datasource
---

# Subagent title

Role and instructions...
```

## Frontmatter field reference

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | Lowercase, numbers, hyphens only. Max 64 chars. Becomes `/slash-command`. |
| `description` | Yes | What + when + trigger keywords. Claude uses this for auto-invocation. |
| `model` | Recommended | `sonnet` for data extraction/analysis, `opus` for complex synthesis or code generation. |
| `allowed-tools` | Recommended | Tools Claude can use without permission prompts. Always include the Dataslayer MCP tools. |
| `argument-hint` | Optional | Hint shown during autocomplete (e.g. `[date-range]`, `[channel-filter]`). |
| `disable-model-invocation` | Optional | `true` for skills with side effects (PDF generation, file creation). |
| `context` | Optional | `fork` to run in isolated subagent context. |
| `agent` | Optional | Which subagent to use with `context: fork` (`Explore`, `Plan`, `general-purpose`, or custom). |

## Business context file

Skills auto-load `.agents/product-marketing-context.md` for business context
(product details, targets, channels). A template is at
`.agents/product-marketing-context.example.md`.

Skills must handle the case where this file doesn't exist using the pattern:
```
!`cat .agents/product-marketing-context.md 2>/dev/null || echo "No context file found."`
```

Always use `"No context file found."` as the fallback message — not an empty string.

## Rules

- Keep SKILL.md under 500 lines — move detailed docs to supporting files
- Every data fetch must go through Dataslayer MCP — never ask the user to paste data
- Output format must include specific numbers, never generic observations
- Related skills must only reference other skills in this repository
- Always include `allowed-tools` with the Dataslayer MCP tools the skill needs
- Use `${CLAUDE_SKILL_DIR}` for references to supporting files (not hardcoded paths)
- Use `!`command`` syntax for auto-loading context files (not manual "read file" steps)
- Use `$ARGUMENTS` when the skill accepts user parameters
- Do NOT use `version` in frontmatter — it is not an official Claude Code field
- Subagents return data only — the orchestrator skill handles interpretation
