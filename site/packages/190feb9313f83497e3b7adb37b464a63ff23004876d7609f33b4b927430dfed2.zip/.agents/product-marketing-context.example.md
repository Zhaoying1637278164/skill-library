# Product & marketing context

This file gives skills the business context they need to produce relevant
analysis. Copy this file to `product-marketing-context.md` (same directory)
and fill in your details.

Skills load this file automatically via context injection. If it doesn't
exist, skills will ask a fallback question instead.

---

## Company

- **Product:** [Your product name]
- **What it does:** [One sentence — e.g., "Marketing data integration platform for teams"]
- **Primary audience (ICP):** [e.g., "Marketing managers at B2B SaaS companies, 50-500 employees"]
- **Pricing model:** [e.g., "Monthly SaaS, plans from $29 to $299/month, annual option"]

## Key metrics and targets

- **Primary conversion event:** [e.g., "sign_up" in GA4]
- **Target CPA (paid):** [e.g., "€52"]
- **Target ROAS:** [e.g., "3.0x"]
- **Healthy weekly organic sessions:** [e.g., "5,000"]
- **Trial-to-paid conversion rate target:** [e.g., "12%"]
- **Acceptable monthly churn rate:** [e.g., "<5%"]

## Channels in use

- **Paid:** [e.g., "Google Ads (PMax Spain + PMax Europe), Meta Ads (retargeting only)"]
- **Organic:** [e.g., "Blog at /blog/, main site pages, Search Console connected"]
- **Retention data:** [e.g., "Stripe connected, no internal database yet"]

## Known context

Add anything that helps skills avoid wrong conclusions:

- [e.g., "PMax campaigns were paused in early March 2026 — this is intentional, not a bug"]
- [e.g., "The 'pomelli' queries in Search Console are not our brand — ignore them"]
- [e.g., "We use 'generate_lead' as our conversion event, not 'sign_up'"]
