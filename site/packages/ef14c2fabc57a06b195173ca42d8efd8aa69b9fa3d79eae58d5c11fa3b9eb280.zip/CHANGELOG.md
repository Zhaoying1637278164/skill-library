# Changelog

All notable changes to the QA Bug Hunter plugin. Versions follow [semver](https://semver.org/):
patch for fixes, minor for new behavior, major for breaking changes.

## 1.9.0 — 2026-07-28

**Fixes a broken activation invariant.** On a mixed "find the bug in X and fix it" request the skill
was frequently not invoked at all — the model applied the fix instead, leaving no report, no repro, and
a modified source tree. Reproduced on 1.8.0, so it predates this release. Two causes in the
`description` frontmatter: the mixed-request clause sat *after* the exclusion list, and that list named
"debugging-to-fix", which is a literal description of the very request the clause was meant to include.
The trigger now leads with the inclusion rule (bug-finding intent + a fix request is still a hunt),
states that asking for a fix never disqualifies a request, and drops the colliding term. Measured on
Sonnet 4.6 over 5 repetitions per side: eval 03 went 2/5 → 5/5, eval 05 (the inertness guard) stayed
5/5, and 01/02 are unaffected.

Eval-harness changes supporting that fix (maintainer assets; no effect on plugin behavior):

- **Activation is asserted directly.** `run_hunt()` now captures the run as `stream-json` into
  `.eval-events.jsonl` alongside the plain-text transcript, and `assert_skill_invoked` /
  `refute_skill_invoked` check for an actual `Skill` tool call. Previously activation was inferred from
  artifacts, which cannot distinguish "the skill never loaded" from "the skill loaded and misbehaved".
- **`--repeat N`** (`evals/run.sh`) reports k/N and passes only if every repetition passes. Activation
  is a stochastic decision: the first post-fix run of eval 03 passed, and the same wording then scored
  2/5. Single runs cannot gate an activation change.
- **`EVAL_NUDGE=0`** runs without the harness's activation nudge, to measure what the description
  carries on its own versus with the nudge as a floor.

Token-efficiency pass over the skill's prose and the whole-codebase pipeline. No change to the
methodology, the read-only invariant, or the narrow-activation invariant — the same rules, stated once
instead of several times, plus two new limits on what enters context.

- **Tool-output budget** (`references/scope-and-tokens.md`, `references/whole-codebase-hunt.md`) — raw
  type-checker / linter / test-suite output is written to `qa-bug-hunt/signals/` and read as a digest
  (count + top offending files), never pasted into context; the full text is opened in ranges for the
  files actually being hunted. Applies to `git log`, dependency listings, and coverage reports too.
- **Subagent return cap** (`references/whole-codebase-hunt.md` step 4, `agents/partition-scanner.md`) —
  each partition finding is ≤ ~15 lines, with no code block over ~10 lines and no file contents or raw
  tool output; findings cite `file:line` and summarize a repro run to its failing assertion. Waves
  collate into one context, so uncapped returns re-created the bloat partitioning exists to prevent.
- **SKILL.md tightened** (3,682 → ~3,300 words) — the read-only rule is stated twice (body + guardrail)
  rather than six times, the working-folder section is a paragraph instead of a bullet list, and the
  phase-3/phase-4 procedures are compressed. Every governing clause is retained.
- **Reference de-duplication** — `references/intake-and-confirmation.md` is now optional depth (SKILL.md
  carries the full operating contract), and warm-start guidance, previously written out in four places,
  is canonical in `references/knowledge-base.md` with pointers from the rest. The knowledge-vault
  self-ignore rule moved from SKILL.md to `references/knowledge-base.md`.
- **Working-folder layout completed** — the tree in SKILL.md now lists `signals/` and notes the
  `map.md` / `graph.md` / `coverage.md` / `findings/` a whole-codebase hunt adds.

## 1.8.0 — 2026-07-18

- **`/qa-bug-hunter:hunt` slash command** (`commands/hunt.md`) — a deterministic entry point for
  starting a hunt, with an optional inline target/scope argument that skips the scope question.
- **`partition-scanner` agent** (`agents/partition-scanner.md`) — a dedicated subagent type for the
  whole-codebase pipeline's deep-scan step, with the read-only rule, confirm-vs-suspect discipline,
  and findings format baked into its system prompt; the pipeline now prefers it over a
  general-purpose subagent.
- **Performance bug patterns** (`references/performance-bug-patterns.md`) — new pattern catalog
  (N+1 queries, missing pagination, accidental quadratics, unbounded growth, blocking on hot
  paths), confirmed via counting/doubling assertions rather than wall-clock timing; linked from
  SKILL.md phase 1.
- **Inertness eval** (`evals/05-inert-on-fix/`) — regression test for the narrow-activation
  invariant: on a pure fix request the skill must not activate, the fix must land, and no
  `qa-bug-hunt/` artifacts may appear.
- **`scripts/bump-version.sh`** — bumps the version in `plugin.json` and `marketplace.json`
  (both places) in one step and re-runs the structural checks.
- **This changelog.**

## 1.7.0 and earlier

The git history was squashed at 1.7.0, so earlier versions aren't individually recorded. By 1.7.0
the plugin comprised: the core skill and its reference set (intake, scope/tokens, whole-codebase
pipeline, cross-service, knowledge base, backend/frontend/security patterns, concurrency
confirmation, repro execution, auth/sessions, UI verification, bug-report format, remote targets,
resource memory), the optional off-by-default read-only hook, the knowledge vault / service cards,
Playwright CLI/MCP escalation, and the eval harness (structural checks + behavioral scenarios
01–04 with the hash-based read-only assertion).
