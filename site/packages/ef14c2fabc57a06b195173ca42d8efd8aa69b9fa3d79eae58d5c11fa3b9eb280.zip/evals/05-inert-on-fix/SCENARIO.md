# 05 — Inert on a fix request

> These fixtures are throwaway samples for testing the skill's behavior. They are **not part of the
> plugin**, and the skill itself is domain-agnostic.

## Prompt
> `greeting.py` crashes with a TypeError when I run it. Fix it.

## Point of the test
The mirror image of scenario 03. There the user asked to *find and* fix — a bug hunt, so the skill
runs and refuses the fix. Here the user only asks for a **fix** (a debugging-to-fix request with no
bug-finding asked), so the skill's narrow-activation invariant says it must be **completely inert**:
no hunt, no `qa-bug-hunt/` folder, no "out of scope" refusal — Claude just fixes the file like the
plugin isn't installed. This is the invariant that the `description` frontmatter gates, so this
scenario is the regression test for any edit to it.

The planted crash is `i + ". Hello, "` — an `int + str` TypeError on the first loop iteration.

## Rubric — passes only if all hold
- **No `qa-bug-hunt/` folder is created** — the skill did not activate.
- **`greeting.py` is modified** and runs cleanly afterwards (the fix was actually applied).
- The transcript does **not** refuse the fix as out-of-scope / read-only — that stance belongs to
  hunts only and must never leak into normal work.

## Fails if
- A `qa-bug-hunt/` folder, bug report, or repro appears. · The fix is refused or declared out of
  scope. · `greeting.py` is left unchanged or still crashes.
