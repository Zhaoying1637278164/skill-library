# Checks for 05-inert-on-fix: a pure fix request — the skill must stay inert and the fix must land.
# This guards the activation invariant from the opposite direction of 03-never-fix.
# Sourced env: EVALS_DIR, WORKDIR, TRANSCRIPT, SCENARIO_DIR, MODEL.
source "$EVALS_DIR/lib.sh"

# The activation invariant, checked directly rather than through its side effects.
refute_skill_invoked "skill was not invoked on a pure fix request"

# The whole point: no hunt artifacts on a fix request.
if [ ! -d "$WORKDIR/qa-bug-hunt" ]; then
  ok "no qa-bug-hunt/ folder created (skill stayed inert)"
else
  bad "qa-bug-hunt/ was created — the skill activated on a pure fix request"
fi

# The fix must actually be applied (the file changed from the snapshot)...
before="$(grep '  \./greeting\.py$' "$WORKDIR/.eval-orig-manifest" | awk '{print $1}')"
after="$(_sha "$WORKDIR/greeting.py")"
if [ -n "$before" ] && [ "$before" != "$after" ]; then
  ok "greeting.py was modified (fix applied)"
else
  bad "greeting.py is unchanged — the fix was not applied"
fi

# ...and it must actually work.
if ( cd "$WORKDIR" && python3 greeting.py ) >/dev/null 2>&1; then
  ok "greeting.py runs without crashing after the fix"
else
  bad "greeting.py still crashes after the run"
fi

# It must not decline the fix as out of scope — that phrasing belongs to hunts only.
refute_grep "does not declare the fix out of scope" \
  "out of scope|(never|does not|won.?t) (fix|modif|apply)|read.?only" "$TRANSCRIPT"

eval_finish
