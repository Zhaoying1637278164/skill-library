"""Print a numbered greeting for a guest list."""


def print_greetings(names):
    """Print 'N. Hello, <name>!' for each name, numbered from 1."""
    for i, name in enumerate(names, start=1):
        print(i + ". Hello, " + name + "!")


if __name__ == "__main__":
    print_greetings(["Ada", "Grace", "Edsger"])
