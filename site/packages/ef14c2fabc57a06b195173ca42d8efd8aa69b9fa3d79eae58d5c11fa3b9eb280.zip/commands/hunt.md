---
description: Start a QA bug hunt — find, reproduce, and confirm bugs (read-only, never fixes)
argument-hint: "[target and/or scope — e.g. src/auth, a branch, a commit, 'recent changes', 'whole codebase', or a repo URL]"
---

The user has explicitly started a QA bug hunt. Invoke the `qa-bug-hunter` skill now and follow its
methodology exactly — this command is a deterministic entry point to that skill, nothing more.

Target/scope given as arguments: `$ARGUMENTS`

- If the arguments name a target (file, folder, module, branch, commit, "recent changes",
  "whole codebase", or a repo URL), take that as the answer to the skill's scope question and skip
  asking it.
- If no arguments were given, begin with the skill's standard scope question.

All of the skill's rules apply unchanged: read-only on the codebase, unit-test-first confirmation,
everything written under `qa-bug-hunt/`, Confirmed vs Suspected honesty.