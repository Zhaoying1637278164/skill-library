#!/usr/bin/env bash
# scripts/bump-version.sh — bump the plugin version in every place it lives, keeping them in sync.
#
# MAINTAINER ONLY — not part of the plugin; the skill never runs this.
#
# Usage:
#   scripts/bump-version.sh 1.9.0        # set an explicit version
#   scripts/bump-version.sh patch|minor|major   # increment from the current plugin.json version
#
# Updates: .claude-plugin/plugin.json ("version") and .claude-plugin/marketplace.json (both
# metadata.version and the plugin entry's version). Reminds you to add a CHANGELOG.md entry.
# evals/check-structure.sh verifies the parity this script maintains.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PLUGIN="$ROOT/.claude-plugin/plugin.json"
MARKET="$ROOT/.claude-plugin/marketplace.json"

[ $# -eq 1 ] || { sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 2; }

cur="$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[0-9]+\.[0-9]+\.[0-9]+"' "$PLUGIN" \
       | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')"
[ -n "$cur" ] || { echo "✗ could not read current version from plugin.json"; exit 1; }

IFS=. read -r maj min pat <<<"$cur"
case "$1" in
  major) new="$((maj + 1)).0.0";;
  minor) new="$maj.$((min + 1)).0";;
  patch) new="$maj.$min.$((pat + 1))";;
  *)
    echo "$1" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$' || { echo "✗ '$1' is not X.Y.Z or patch/minor/major"; exit 2; }
    new="$1";;
esac

for f in "$PLUGIN" "$MARKET"; do
  sed -i '' -E "s/(\"version\"[[:space:]]*:[[:space:]]*\")[0-9]+\.[0-9]+\.[0-9]+(\")/\1$new\2/g" "$f"
done

echo "✓ $cur → $new  (plugin.json + marketplace.json ×2)"
grep -q "## $new" "$ROOT/CHANGELOG.md" 2>/dev/null \
  || echo "→ now add a '## $new' entry to CHANGELOG.md"
bash "$ROOT/evals/check-structure.sh" >/dev/null 2>&1 \
  && echo "✓ structural checks pass" \
  || { echo "✗ structural checks FAILED — run: bash evals/check-structure.sh"; exit 1; }
