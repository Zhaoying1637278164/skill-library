# Optional read-only enforcement (OFF by default)

This folder contains a hard read-only guard. **It is disabled by default and the plugin registers no
hook** — so QA Bug Hunter never blocks normal development, code-writing, or any other tool. The skill
is read-only on your code *by behavior* (it only writes repro tests under `qa-bug-hunt/`), and that
behavior only applies while you're actually running a bug hunt.

## Should you enable it?

Only if you run **dedicated bug-hunting-only sessions** and want a hard guarantee that nothing touches
your source. **Do not enable it for normal development:** a Claude Code hook is session-global, so once
active it blocks *every* file write outside `qa-bug-hunt/` for the whole session — including your own
feature/fix work — regardless of whether the bug-hunter skill is in use.

## Recommended: a dedicated hunt session (no rename, nothing left enabled)

Because the rename below flips the guard on for *every* session until you rename it back, the safer
pattern is a one-off session that carries the hook in its own settings file — your normal sessions
stay untouched:

```bash
cat > "${TMPDIR:-/tmp}/qa-hunt-settings.json" <<EOF
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit",
        "hooks": [
          { "type": "command",
            "command": "python3 $HOME/.claude/plugins/<path-to>/qa-bug-hunter/hooks/guard-readonly.py" }
        ]
      }
    ]
  }
}
EOF
claude --settings "${TMPDIR:-/tmp}/qa-hunt-settings.json"
```

Point the `command` at wherever this plugin is checked out or installed (any absolute path to
`hooks/guard-readonly.py` works). When that session ends, nothing is left enabled anywhere.

## Enable persistently (rename)

Rename the registration file and reload:

```bash
mv hooks/hooks.json.disabled hooks/hooks.json
# then /reload-plugins (CLI) or restart Claude Code
```

`guard-readonly.py` denies any Write/Edit/MultiEdit/NotebookEdit outside `<cwd>/qa-bug-hunt/`. It
guards the file-editing tools, not arbitrary shell redirections — a strong guard, not a sandbox. It
needs `python3` on PATH.

## Disable again

```bash
mv hooks/hooks.json hooks/hooks.json.disabled
# then reload / restart
```
