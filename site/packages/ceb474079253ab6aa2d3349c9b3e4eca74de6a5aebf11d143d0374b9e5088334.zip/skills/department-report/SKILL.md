---
name: department-report
description: Use to build a security-awareness report for one department in Phished. Triggers on "department report", "how is <department> doing", "risk report for the Sales department".
---

# Department report

Produce a security-awareness report scoped to a single department.

## Inputs

- Department name (required). Optional period (defaults to last 30 days).

## Steps

1. **Resolve the department** with `list-departments` (returns id, name, owner,
   location, managers). If the name is ambiguous, list close matches and ask.

2. **Pull the department's data:**
   - `get-departments-brs` — current Behavioural Risk Score for the department
     (and others, for benchmarking).
   - `list-recipients` — filter to this department (recipients carry a
     department field) for headcount and active status.
   - Per-recipient risk trend where useful: `get-recipient-brs-history`.
   - Training: `list-level-progression` and `list-training-progression`
     (org-wide academy progression) — scope to the department's recipients.
   - Simulation activity over the period: `list-organisation-events`
     (`period` in days) and, per person, `list-recipient-events`.

3. **Assemble the report:**
   - Headline risk posture and its trend over the period.
   - Simulation performance (click / report / compromise rates).
   - Training / awareness completion.
   - Comparison vs the org average (from `get-departments-brs` across depts).
   - The 3 most actionable findings.

4. **Present** a short narrative plus compact tables. Offer to format/export on
   request.

## Guardrails

- Aggregate by default; surface individual recipients only when asked and the
  group is small (respect PII limits).
- Every figure must be scoped to the requested department only.
