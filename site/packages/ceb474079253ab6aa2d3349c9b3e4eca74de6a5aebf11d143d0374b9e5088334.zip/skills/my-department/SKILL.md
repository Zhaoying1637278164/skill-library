---
name: my-department
description: Use to give a focused report for a single department the user names — a lightweight, department-scoped view. Triggers on "show me my department", "how is <department> doing", "report for the Marketing department".
---

# My department

Give a focused, single-department view. The user names the department they want
(any department), and this returns just that department's picture.

## Inputs

- The department name. If not given, ask which department, or list the available
  departments (`list-departments`) to choose from.

## Steps

1. **Resolve the department** with `list-departments`. If the name is ambiguous,
   show the close matches and let the user pick.

2. **Pull that department's data:**
   - `get-departments-brs` — the department's current Behavioural Risk Score and
     recent trend.
   - `list-recipients` filtered to this department — headcount, active status,
     and follow-up on specific people where useful.
   - Training: `list-level-progression` / `list-training-progression` scoped to
     the department's recipients.
   - Simulation activity: `list-organisation-events` (`period`) scoped to the
     department.

## Output

A single-department summary a department lead can act on this week: risk posture
+ trend, simulation performance, training completion, and the most useful next
actions. Keep it focused on the one department requested.
