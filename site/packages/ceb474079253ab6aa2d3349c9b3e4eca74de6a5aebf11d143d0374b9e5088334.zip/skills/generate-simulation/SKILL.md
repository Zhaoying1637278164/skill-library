---
name: generate-simulation
description: Use when the user wants to generate company-specific phishing simulation templates for Phished, grounded in a company's website and documentation. Triggers on "generate a simulation", "company-specific simulation", "make a phishing template for <company>".
---

# Generate company-specific phishing simulations

Produce realistic, tailored phishing-simulation templates for a specific
company, grounded in what that company actually looks like (website, tone,
brands, tools, suppliers, public docs), then optionally create them in Phished
via the MCP.

## Inputs to collect

- The target company: a name, a website URL, and/or paths/links to documentation.
- Primary language(s) of the audience.

## Steps

1. **Gather company context.** Fetch the website (about, contact, careers,
   login/portal pages) and read any supplied docs. Note brand, tone, products,
   internal/third-party tool names, suppliers, HR/finance processes, and recent
   announcements — these are your phishing hooks. Use only facts you actually
   read; do not invent details about the company.

2. **Check what's available in Phished** using these MCP tools:
   - `list-simulation-domains` — valid sending domains (you must use one).
   - `list-simulation-templates` / `get-simulation-template` — existing templates
     to match house style and avoid duplicates.
   - `list-landing-pages` / `get-landing-page` — reusable aftermath pages.

3. **Draft 3–5 scenarios.** For each: title, tactic/risk (credential harvest,
   attachment, MFA fatigue, invoice fraud, QR/quishing, spear-phishing), the
   pretext and why it's believable *for this company*, subject line, email body
   (in the audience language), and the teachable moment.

4. **Show the drafts and get approval before writing anything.**

5. **Create approved templates** with `create-simulation-template`. Required
   fields: `name`, `subject`, `sender_name`, `sender_email`, `domain` (from
   `list-simulation-domains`), `content` (HTML), `difficulty` (0–4),
   `languages` (array). Optional: `landing` (HTML), `countries`, `has_data_entry`,
   `has_qr_code`, `spear_phishing`, `has_attachment` + `attachment_name` /
   `attachment_type`. Create a landing page first with `create-landing-page` if
   you want to reference one.

6. **Optionally dry-run** with `send-simulation-template-test` (template_id +
   up to 50 recipient_ids) — this sends a test only, it does not launch a
   campaign. Confirm recipients explicitly first.

## Guardrails

- Authorized security-awareness training content only.
- No real credentials, secrets, or live malicious links.
- Never send tests to real recipients without explicit confirmation.
