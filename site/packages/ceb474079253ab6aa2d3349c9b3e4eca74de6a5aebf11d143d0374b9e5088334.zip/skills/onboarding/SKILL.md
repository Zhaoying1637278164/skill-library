---
name: onboarding
description: Use to onboard a new Phished organisation end to end — create and verify a domain, add recipients (or set up user provisioning), set up simulations, and set up the Academy. Triggers on "onboard a new customer", "set up Phished from scratch", "get us started on Phished".
---

# Onboarding a Phished organisation

Guide a new organisation through initial setup, in order. Confirm each phase is
complete before moving to the next, and never launch anything against real
recipients without explicit confirmation. All actions apply to the organisation
that owns the connected MCP token.

## Phase 1 — Domain (create, then verify)

1. Add the sending/reporting domain with `create-domain` (`domain`, a bare
   FQDN). A domain must be verified before it can be used.
2. Tell the user which **DNS TXT record** to publish, then confirm ownership
   with `validate-domain` (`domain`). Re-run until it passes — DNS can take time
   to propagate.
3. Check state any time with `list-domains` (shows validation status).

**Do not proceed to simulations until at least one domain is validated.**

## Phase 1b — Confirm email delivery is set up (whitelisting / DMI)

After the domain is verified, **ask the customer to confirm Phished's email
services can actually be delivered in their mail environment.** Without this,
simulation emails get throttled, quarantined, filtered, link-rewritten, or sent
to Junk. This is customer-side configuration — there is **no MCP tool** to set or
check it, so first ask **which mail platform** they use, then walk them through
the matching checklist and get explicit confirmation of each item.

- **Microsoft 365** → whitelisting baseline, or DMI (see below).
- **Google Workspace** → **DMI is required** (Google does not support traditional
  whitelisting — see below).
- **Another platform / a security gateway (SEG, API email security, endpoint)**
  → the equivalent allow-listing must be done there; point them at the Help
  Center's catch-all whitelisting guide and per-vendor bypass articles.

### Microsoft 365

> **First choice — DMI vs traditional whitelisting.** If all in-scope domains
> belong to a **single** Microsoft 365 / Entra environment, DMI (Direct Message
> Injection) may be preferred — see the DMI guide. If domains span **multiple**
> M365/Entra environments, traditional whitelisting (below) is required.

For **traditional Microsoft 365 whitelisting**, confirm all four baseline items:

1. **Connection Filtering bypass** configured in Microsoft Defender (allow-list
   Phished's sending IPs so connection filtering doesn't block them).
2. **Advanced Delivery** configured in Microsoft Defender for **third-party
   phishing simulations** (this is the Microsoft-sanctioned way to exempt
   simulation mail from filtering).
3. **Custom return path** enabled in Phished: **ZIR app → Simulations →
   Automated → Settings → Advanced tab → enable Custom return path.**
4. **Exchange allow-listing layer** for their setup:
   - **Exchange Online** — cloud-only Microsoft 365;
   - **Exchange Online + Exchange on-premises** — hybrid;
   - **Exchange on-premises** — fully on-premises.

**Optional tuning** (only if delivery still misbehaves after the baseline):
**Safe Links** / **Safe Attachments** exclusions if links/attachments are
rewritten or blocked, and check landing pages aren't blocked after a click.

Reference guides (Phished Help Center):
- Overview: *Configure Microsoft 365 whitelisting for Phished simulations and emails*
  — https://helpcenter.phished.io/hc/en-us/articles/34829984157341
- DMI alternative — https://helpcenter.phished.io/hc/en-us/articles/34700267401501
- Connection Filtering bypass — https://helpcenter.phished.io/hc/en-us/articles/34830712905885
- Advanced Delivery — https://helpcenter.phished.io/hc/en-us/articles/34830563061533
- Exchange Online mail-flow rules — https://helpcenter.phished.io/hc/en-us/articles/34831167188381
- Exchange on-premises mail-flow rules — https://helpcenter.phished.io/hc/en-us/articles/34831248119837
- Safe Links / Safe Attachments — https://helpcenter.phished.io/hc/en-us/articles/34833823590557

### Google Workspace (DMI required)

**Traditional whitelisting is not supported on Google Workspace — DMI (Direct
Message Injection) is the only supported delivery method.** DMI uses a Google
service account with domain-wide delegation to insert simulation (and Academy)
emails straight into user mailboxes. It requires that **all in-scope domains
belong to the same Google Workspace environment** (if they're spread across
multiple environments, route the customer to Phished Support).

Confirm the customer (a Google Workspace admin with Google Cloud Console access)
has completed:

1. **Create or choose a Google Cloud project.**
2. **Enable the Gmail API** (APIs & Services → Library → Gmail API → Enable).
3. **Create a service account** (IAM & Admin → Service Accounts).
4. **Create and download a JSON key** for that service account (store it
   securely — it grants mailbox-insert access).
5. **Configure domain-wide delegation** in the Google Admin Console (Security →
   Access and data control → API controls → Manage domain-wide delegation → Add
   new): enter the service account's **numeric Client ID** (not its email), add
   the OAuth scope **`https://www.googleapis.com/auth/gmail.insert`**, and
   Authorise.
6. **Enable DMI in the Phished ZIR app:** Simulations → Automated → Settings →
   Advanced tab → under *Control how simulations are sent* select **Google
   Workspace DMI**, upload the **JSON key file**, confirm, and set a **DMI error
   address** for injection-failure notifications.
7. **Test** a message injection from the ZIR app and confirm it lands in the
   target mailbox and isn't stripped/modified by any additional security layer
   (SEG, API email security, endpoint) — those may still need their own allow
   rules.

Reference guide: *Configure Direct Message Injection (DMI) for Google Workspace*
— https://helpcenter.phished.io/hc/en-us/articles/34700123540253

> Google Cloud / Admin Console navigation is controlled by Google and can change;
> if a step no longer matches, defer to Google's docs or the customer's Workspace
> admin.

Only move on once the customer confirms delivery is set up for their platform.

## Phase 2 — Recipients (upload, or set up provisioning)

Ask whether they want a **one-off upload** or ongoing **user provisioning**.
These are three distinct things — don't conflate them:

- **Upload (available via MCP):** create people with `create-recipient`
  (`email` on a validated domain, `firstname`, `lastname`; optional
  `phonenumber`, `function`, `department`, `location`, `language`,
  `send_notification`). For a batch, create departments/locations first (see
  below) so people land in the right units. Verify with `list-recipients`.

- **User provisioning (NOT available via MCP):** this is the automated recipient
  sync (SCIM-style push from an IdP, or on-premise AD). It is a **separate
  feature from SSO** and there is currently **no MCP tool for it** — the API
  endpoint exists (`POST` user-provisioning, which mints a provisioning token)
  but it isn't exposed through the Phished MCP. So set this up in the **Phished
  dashboard** (or via that API directly) to get the provisioning token, then
  configure the IdP/AD connector there. Note this as an MCP gap if the user
  expected to do it here.

- **SSO ≠ provisioning.** `create-sso-configuration` /
  `list-sso-configurations` / `get-sso-configuration` set up **login**
  (authentication), not recipient sync. Offer it separately if the user wants
  single sign-on; do not present it as a way to provision users.

Set up the org structure as needed: `create-department` / `list-departments`
and `create-location` (`name` + timezone `region`) / `list-locations`. Group
people for Academy targeting with `create-target-list` / `list-target-lists`.

## Phase 3 — Simulations

1. Review current config with `get-simulation-settings`; adjust with
   `update-simulation-settings`.
2. Confirm sending domains with `list-simulation-domains`.
3. Choose or create templates: `list-simulation-templates` /
   `get-simulation-template`, or `create-simulation-template` (see the
   `generate-simulation` skill for company-specific content). Add aftermath
   pages with `create-landing-page` if wanted.
4. **Dry-run** with `send-simulation-template-test` (template + up to 50
   recipient_ids) — a test only, not a campaign. Confirm recipients first.

## Phase 4 — Academy

1. Review with `get-academy-settings`; configure with `update-academy-settings`
   (`is_active`, reminder emails, `threat_alerts`, first/second/third reminder
   toggles).
2. Browse content with `list-academy-modules`.
3. Optionally brand the Academy emails: `create-email-branding-template`
   (`type`, `language` BCP-47, `title`, `content` HTML) and
   `list-email-branding-templates`.
4. Target the right audience with the target lists from Phase 2.

## Wrap-up

Summarise what's set up and what still needs the customer's action (e.g. a
domain still propagating DNS, provisioning still syncing). Point them at the
reporting skills (`periodic-report`, `department-report`) once data starts
flowing.
