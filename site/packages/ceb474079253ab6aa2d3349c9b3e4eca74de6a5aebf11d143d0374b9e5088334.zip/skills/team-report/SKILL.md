---
name: team-report
description: Use to build a security-awareness report for one team in Phished. Triggers on "team report", "how is <team> doing". Note the platform has no "team" entity — this maps to a location (or department).
---

# Team report

Produce a security-awareness report scoped to a single team.

> **Data-model note:** Phished has **no "team" entity**. The organisational
> units are **departments** and **locations**. Treat a "team" as a **location**
> by default (use `list-locations`), or as a department if that's what the user
> means. If it's ambiguous, ask whether they mean a location or a department
> before continuing, and state in the output which unit you reported on. If
> proper teams are needed, that's a platform/MCP gap to raise — not something
> this skill can invent.

## Inputs

- Team name (required). Optional period (defaults to last 30 days).

## Steps

1. **Resolve the unit.** `list-locations` (id, name, owner) for a location, or
   `list-departments` for a department. If the name doesn't clearly match one,
   list close matches and ask which unit is meant.

2. **Pull the unit's data:**
   - `list-recipients` — filter to recipients in that location/department.
   - `get-departments-brs` — BRS if the unit is a department; for a location,
     aggregate the BRS of its recipients via `get-recipient-brs`.
   - Training: `list-level-progression`, `list-training-progression` scoped to
     the unit's recipients.
   - Simulation activity: `list-organisation-events` (`period` in days) and
     per-person `list-recipient-events`.

3. **Assemble the report:** risk posture + trend, simulation performance
   (click / report / compromise), training completion, comparison vs the parent
   department and the org average, and the 3 most actionable findings.

4. **Present** a short narrative plus compact tables. State clearly which unit
   type (location/department) the numbers represent.

## Guardrails

- Aggregate by default; surface individuals only when asked and the group is
  small (respect PII limits).
- Every figure must be scoped to the requested unit only.
