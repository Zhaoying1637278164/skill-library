---
name: detect-new-in-risk-categories
description: Use to detect which recipients newly entered a risk category in Phished, where risk categories are recipient tags (e.g. "first-time clicker", "low BRS"). Triggers on "who's new in the high-risk group", "detect new risky users", "risk category changes since last week". Designed to run unattended on a schedule.
---

# Detect who is new in the risk categories

Identify recipients who have **newly entered** a risk category since the previous
evaluation, so the team can follow up.

> **Risk categories = recipient tags.** In Phished, risk categories are the
> **tags** assigned to recipients (e.g. "first-time clicker", "low BRS"). This
> skill works off those tags via `list-recipients-with-tags`, which returns each
> tag's **assignment and expiration dates** — that's how you tell who is *new*.

> **Scheduling:** Claude can't schedule itself. Run this on a cadence via a
> cloud routine (`/schedule`) or an external cron invoking
> `claude -p "use the detect-new-in-risk-categories skill"`. It is written to be
> safe to run repeatedly and unattended.

## Steps

1. **Pull the tagged population** with `list-recipients-with-tags` (paginate
   with `page`/`limit`; set `with_pii` only when you need identifiers to act on).
   Each entry carries its tags plus the tag **assignment date** and expiration.

2. **Determine "new".** A recipient is newly in a category if a tag's assignment
   date falls within the comparison window (default: since the last run; honour
   any window the user gives). Rely on the assignment dates rather than diffing
   full snapshots.

3. **Group by tag (category)**, most concerning first. For each recipient
   include the department (from `list-recipients`) and when they entered the
   category.

4. **Optional risk context.** If a numeric trend helps, add `get-recipient-brs`
   (current Behavioural Risk Score) or `get-recipient-brs-history`, and
   `get-departments-brs` for an org/department roll-up. This is supporting
   colour — the categories themselves are the tags.

## PII & output

- Summarise counts per tag/department by default. Only surface individual
  identifiers when the list is small and action is needed (respect the org's
  PII limits — no bulk personal-data dumps).
- Output a skimmable digest: newly-tagged counts per category, the notable new
  entries, one recommended follow-up. Suitable to drop into an inbox or channel.
