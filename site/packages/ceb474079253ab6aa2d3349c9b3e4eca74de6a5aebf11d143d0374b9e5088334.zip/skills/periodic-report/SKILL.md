---
name: periodic-report
description: Use for weekly / monthly / quarterly Phished reporting that the user can chat with, Power BI style. Triggers on "monthly report", "how did we do this quarter", "weekly security posture", followed by drill-down questions.
---

# Periodic reporting (chattable, Power BI style)

A conversational alternative to a Power BI dashboard: give a first answer for a
period, then keep answering drill-down follow-ups against the same data.

## Establish period & scope

- **Period:** week, month, or quarter (default: month if unclear). Convert to
  days for the event tools: week ≈ 7, month ≈ 30, quarter ≈ 90.
- **Scope:** whole organisation unless a department is named
  (`list-departments`) or a location (`list-locations`).

## Pull the data

- Simulation events for the period: `list-organisation-events` (`period` in
  days). For an explicit UTC window use `list-simulation-events`
  (`start_date` / `end_date`, ISO 8601). For long history use
  `list-organisation-events-history`.
- Risk: `get-departments-brs` for the current per-department Behavioural Risk
  Score (and org roll-up).
- Training: `list-level-progression` and `list-training-progression`.
- Activation / reporting-button engagement: `list-activation-reports`
  (filter by `start_date` / `end_date`).

## Behaviour

1. **Lead with an executive summary**, then supporting numbers as compact
   tables. Always show period-over-period change (▲/▼) — pull the previous
   period too so trends are explicit.
2. **Stay conversational.** After the summary, invite follow-ups and answer them
   against the data already pulled where possible (e.g. "break the quarter down
   by department", "why did click rate rise", "compare location A vs B"). Keep
   prior context so it feels like a live dashboard.
3. **Offer exports** (markdown/table) when the user wants to share a view.

## Guardrails

- Aggregate by default; respect PII limits when drilling into individuals.
- State the exact period and scope of every number so figures are never
  ambiguous.
