# phished (Claude plugin)

A Claude plugin that bundles the **Phished MCP server** with a set of reporting,
simulation and risk-detection **skills**.

Skills (not Claude-Code-only commands) are the unit here on purpose: the same
`skills/*/SKILL.md` files are portable across **Claude in its entirety** — the
Claude apps (claude.ai), Claude Code, and the API/Agent SDK. This repo packages
them (plus the MCP binding) as an installable plugin/marketplace; the individual
skills can equally be uploaded to claude.ai and used with the Phished MCP
connector there.

## What's inside

- **MCP server** — `https://mcp.phished.io/mcp` (declared in `.mcp.json`). The
  Phished API exposes ~100 tools; these skills call the relevant ones by name.
- **Skills:**

  | Skill | What it does | Key MCP tools |
  |---|---|---|
  | `onboarding` | End-to-end setup: domain (+verify), confirm email delivery (M365 whitelisting or Google Workspace DMI), recipients (upload; provisioning is dashboard-only), simulations, Academy | `create-domain`, `validate-domain`, `create-recipient`, `update-simulation-settings`, `update-academy-settings` |
  | `generate-simulation` | Company-specific simulations from a website + docs | `list-simulation-domains`, `create-simulation-template`, `create-landing-page`, `send-simulation-template-test` |
  | `detect-new-in-risk-categories` | Who newly entered a risk category — categories are recipient tags (run on a schedule) | `list-recipients-with-tags`, `list-recipients`, `get-recipient-brs` |
  | `department-report` | Report for one department | `list-departments`, `get-departments-brs`, `list-organisation-events`, `list-*-progression` |
  | `team-report` | Report for one "team" — see note | `list-locations`, `list-departments`, `list-organisation-events` |
  | `my-department` | Focused report for a single named department | `list-departments`, `get-departments-brs`, `list-recipients` |
  | `periodic-report` | Weekly/monthly/quarterly reporting you can chat with | `list-organisation-events`, `list-simulation-events`, `get-departments-brs`, `list-activation-reports` |

## Install / try in Claude Code

From this directory:

```bash
claude --plugin-dir .
```

Or via the marketplace this repo also is:

```
/plugin marketplace add Phished-BV/phished-claude-plugin
/plugin install phished@phished
```

## Use on claude.ai

Add the Phished MCP (`https://mcp.phished.io/mcp`) as a connector, then upload
the skill folders under `skills/` as Agent Skills. They reference the MCP tools
by name and work the same way.

## Important notes for two skills

- **`team-report` — there is no "team" entity in Phished.** The org units are
  **departments** and **locations**. The skill maps a "team" to a **location**
  (or department) and says so in its output. Real teams would be a platform/MCP
  gap to close.
- **`detect-new-in-risk-categories` — risk categories are recipient tags.** The
  skill reads `list-recipients-with-tags` and uses each tag's assignment date to
  find who newly entered a category. It's a *scheduled* job in spirit but Claude
  can't schedule itself — drive it with a cloud routine (`/schedule`) or external
  cron.

## Structure

```
.
├── .claude-plugin/
│   ├── plugin.json          # plugin manifest
│   └── marketplace.json     # makes this repo installable as a marketplace
├── .mcp.json                # Phished MCP server binding
├── skills/
│   ├── onboarding/SKILL.md
│   ├── generate-simulation/SKILL.md
│   ├── detect-new-in-risk-categories/SKILL.md
│   ├── department-report/SKILL.md
│   ├── team-report/SKILL.md
│   ├── my-department/SKILL.md
│   └── periodic-report/SKILL.md
└── README.md
```
