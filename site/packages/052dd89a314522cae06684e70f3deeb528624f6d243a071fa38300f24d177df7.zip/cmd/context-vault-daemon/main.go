// CLAUDE:SUMMARY context-vault daemon — TCP JSON-RPC server over localhost, sole writer to vault.db.
// CLAUDE:DEPENDS internal/vault
// CLAUDE:EXPORTS (binary)
package main

import (
	"bufio"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log/slog"
	"net"
	"os"
	"os/signal"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	"github.com/hazyhaar/context-vault/internal/vault"
	_ "modernc.org/sqlite"
)

const (
	listenAddr = "localhost:9743"
	dbRelPath  = ".claude/vault.db"
)

// ── JSON-RPC types ───────────────────────────────────────────────────────────

type jsonrpcRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}

type jsonrpcResponse struct {
	JSONRPC string    `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Result  any       `json:"result,omitempty"`
	Error   *rpcError `json:"error,omitempty"`
}

type rpcError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// ── Client tracking ──────────────────────────────────────────────────────────

type clientInfo struct {
	sessionID string
	role      string // "worker" or "supervisor"
	conn      net.Conn
	enc       *json.Encoder
}

type daemon struct {
	v       *vault.Vault
	db      *sql.DB
	mu      sync.RWMutex
	clients map[net.Conn]*clientInfo
}

func newDaemon(db *sql.DB) *daemon {
	d := &daemon{
		db:      db,
		clients: make(map[net.Conn]*clientInfo),
	}
	d.v = vault.New(db, func() string { return "" })
	return d
}

// CLAUDE:WARN takes mu.Lock — mutates d.clients map.
func (d *daemon) addClient(conn net.Conn, info *clientInfo) {
	d.mu.Lock()
	d.clients[conn] = info
	d.mu.Unlock()
}

// CLAUDE:WARN takes mu.Lock — deletes from d.clients, writes DB (agents SET connected=0). Triggers checkNoSupervisor broadcast if supervisor disconnects.
func (d *daemon) removeClient(conn net.Conn) {
	d.mu.Lock()
	info := d.clients[conn]
	delete(d.clients, conn)
	d.mu.Unlock()

	if info != nil && info.sessionID != "" {
		d.db.Exec(`UPDATE agents SET connected = 0, last_seen_at = unixepoch() WHERE session_id = ?`, info.sessionID)
		if info.role == "supervisor" {
			d.checkNoSupervisor()
		}
	}
}

// ── Connection handler ───────────────────────────────────────────────────────

func (d *daemon) handleConn(ctx context.Context, conn net.Conn) {
	defer conn.Close()
	remote := conn.RemoteAddr().String()
	slog.Info("client connected", "remote", remote)

	info := &clientInfo{conn: conn, enc: json.NewEncoder(conn)}
	d.addClient(conn, info)
	defer d.removeClient(conn)

	scanner := bufio.NewScanner(conn)
	scanner.Buffer(make([]byte, 1<<20), 1<<20)

	for scanner.Scan() {
		if ctx.Err() != nil {
			return
		}
		line := scanner.Bytes()
		if len(line) == 0 {
			continue
		}

		var req jsonrpcRequest
		if err := json.Unmarshal(line, &req); err != nil {
			slog.Warn("invalid json-rpc", "remote", remote, "err", err)
			continue
		}

		resp, postActions := d.handleRequest(&req, info)
		if resp != nil {
			if err := info.enc.Encode(resp); err != nil {
				slog.Warn("encode error", "remote", remote, "err", err)
				return
			}
		}
		for _, fn := range postActions {
			fn()
		}
	}
	if err := scanner.Err(); err != nil {
		slog.Info("client disconnected", "remote", remote, "err", err)
	} else {
		slog.Info("client disconnected", "remote", remote)
	}
}

// ── Request router ───────────────────────────────────────────────────────────

func (d *daemon) handleRequest(req *jsonrpcRequest, info *clientInfo) (*jsonrpcResponse, []func()) {
	// Per-request vault scoped to the client's session ID.
	// This ensures session_origin is set correctly on created entities.
	sv := d.v.WithSession(info.sessionID)

	switch req.Method {
	case "register":
		return d.handleRegister(req, info)
	case "vault/assume_role":
		return d.handleAssumeRole(req, info)
	case "vault/list_workers":
		return d.handleListWorkers(req), nil
	case "vault/get_context":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				Namespace string `json:"namespace"`
				Session   string `json:"session"`
			}
			json.Unmarshal(args, &p)
			return sv.GetContext(p.Namespace, p.Session)
		})
	case "vault/search_entities":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				Type      string `json:"type"`
				Namespace string `json:"namespace"`
				Query     string `json:"query"`
				Session   string `json:"session"`
				Limit     int    `json:"limit"`
			}
			json.Unmarshal(args, &p)
			return sv.SearchEntities(p.Type, p.Namespace, p.Query, p.Session, p.Limit)
		})
	case "vault/upsert_entity":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				ID          *int64          `json:"id"`
				Namespace   string          `json:"namespace"`
				Type        string          `json:"type"`
				Label       string          `json:"label"`
				Sensitivity int             `json:"sensitivity"`
				Meta        json.RawMessage `json:"meta"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.UpsertEntity(p.ID, p.Namespace, p.Type, p.Label, p.Sensitivity, p.Meta)
		})
	case "vault/todo_transition":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				ID     int64  `json:"id"`
				Status string `json:"status"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.TodoTransition(p.ID, p.Status)
		})
	case "vault/list_todos":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				Namespace   string `json:"namespace"`
				Session     string `json:"session"`
				IncludeDone bool   `json:"include_done"`
			}
			json.Unmarshal(args, &p)
			return sv.ListTodos(p.Namespace, p.Session, p.IncludeDone)
		})
	case "vault/create_relation":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				FromID int64  `json:"from_id"`
				ToID   int64  `json:"to_id"`
				Type   string `json:"type"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.CreateRelation(p.FromID, p.ToID, p.Type)
		})
	case "vault/delete_entity":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				ID int64 `json:"id"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.DeleteEntity(p.ID)
		})
	case "vault/add_steps":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				TodoID int64    `json:"todo_id"`
				Steps  []string `json:"steps"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.AddSteps(p.TodoID, p.Steps)
		})
	case "vault/step_done":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				TodoID int64  `json:"todo_id"`
				Step   string `json:"step"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.StepDone(p.TodoID, p.Step)
		})
	case "vault/get_entity":
		return d.callTool(req, func(args json.RawMessage) vault.Result {
			var p struct {
				ID int64 `json:"id"`
			}
			if err := json.Unmarshal(args, &p); err != nil {
				return vault.ErrorResult("invalid params: " + err.Error())
			}
			return sv.GetEntity(p.ID)
		})
	default:
		return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{Code: -32601, Message: "method not found: " + req.Method}}, nil
	}
}

func (d *daemon) callTool(req *jsonrpcRequest, fn func(json.RawMessage) vault.Result) (*jsonrpcResponse, []func()) {
	r := fn(req.Params)
	return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Result: r}, nil
}

// CLAUDE:WARN takes mu.Lock — mutates info.sessionID and info.role. Writes DB (INSERT/UPDATE agents). Restores role from agents table on reconnect — requested role may differ from effective role. Post-action pushes notify/role_restored.
func (d *daemon) handleRegister(req *jsonrpcRequest, info *clientInfo) (*jsonrpcResponse, []func()) {
	var p struct {
		SessionID string `json:"session_id"`
		Role      string `json:"role"`
	}
	if err := json.Unmarshal(req.Params, &p); err != nil {
		return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{Code: -32602, Message: "invalid params"}}, nil
	}
	if p.Role != "worker" && p.Role != "supervisor" {
		return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{Code: -32602, Message: "role must be 'worker' or 'supervisor'"}}, nil
	}

	// Check if session already exists in agents — restore its role
	effectiveRole := p.Role
	var existingRole string
	if err := d.db.QueryRow(`SELECT role FROM agents WHERE session_id = ?`, p.SessionID).Scan(&existingRole); err == nil {
		effectiveRole = existingRole
		d.db.Exec(`UPDATE agents SET connected = 1, last_seen_at = unixepoch() WHERE session_id = ?`, p.SessionID)
	} else {
		d.db.Exec(`INSERT INTO agents (session_id, role, connected, registered_at, last_seen_at) VALUES (?, ?, 1, unixepoch(), unixepoch())`,
			p.SessionID, effectiveRole)
	}

	d.mu.Lock()
	info.sessionID = p.SessionID
	info.role = effectiveRole
	d.mu.Unlock()

	// Post-response: notify client if their role was restored from agents table
	var post []func()
	if effectiveRole != p.Role {
		sessID := p.SessionID
		reqRole := p.Role
		effRole := effectiveRole
		post = append(post, func() {
			d.pushToSession(sessID, "notify/role_restored", map[string]any{
				"session_id":     sessID,
				"requested_role": reqRole,
				"restored_role":  effRole,
			})
		})
	}
	// Note: no checkNoSupervisor here — a worker registering doesn't need to be
	// told there's no supervisor. The alert fires on supervisor disconnect/downgrade.

	slog.Info("client registered", "session", p.SessionID, "role", effectiveRole)
	return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Result: map[string]string{"status": "registered", "role": effectiveRole}}, post
}

// CLAUDE:WARN takes mu.Lock (held for full duration) — supervisor singleton enforced via agents table. Disconnects old session_id from agents on session change. Post-action triggers checkNoSupervisor on downgrade.
func (d *daemon) handleAssumeRole(req *jsonrpcRequest, info *clientInfo) (*jsonrpcResponse, []func()) {
	var p struct {
		Role      string `json:"role"`
		SessionID string `json:"session_id"`
	}
	if err := json.Unmarshal(req.Params, &p); err != nil {
		return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{Code: -32602, Message: "invalid params"}}, nil
	}
	if p.Role != "worker" && p.Role != "supervisor" {
		return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{Code: -32602, Message: "role must be 'worker' or 'supervisor'"}}, nil
	}

	d.mu.Lock()
	defer d.mu.Unlock()

	// If caller provides a stable session_id, update the client identity
	if p.SessionID != "" && p.SessionID != info.sessionID {
		oldSess := info.sessionID
		d.db.Exec(`UPDATE agents SET connected = 0, last_seen_at = unixepoch() WHERE session_id = ?`, oldSess)
		info.sessionID = p.SessionID
		d.db.Exec(`INSERT INTO agents (session_id, role, connected, registered_at, last_seen_at) VALUES (?, ?, 1, unixepoch(), unixepoch())
			ON CONFLICT(session_id) DO UPDATE SET connected = 1, last_seen_at = unixepoch()`, p.SessionID, p.Role)
		slog.Info("client session changed", "from", oldSess, "to", p.SessionID)
	}

	// Singleton check: only one connected supervisor at a time
	if p.Role == "supervisor" {
		var existingSess string
		err := d.db.QueryRow(`SELECT session_id FROM agents WHERE role = 'supervisor' AND connected = 1 AND session_id != ?`, info.sessionID).Scan(&existingSess)
		if err == nil {
			return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{
				Code:    -32603,
				Message: fmt.Sprintf("supervisor already active (session %s)", existingSess),
			}}, nil
		}
	}

	oldRole := info.role
	info.role = p.Role

	// Persist role change in agents table
	d.db.Exec(`UPDATE agents SET role = ?, last_seen_at = unixepoch() WHERE session_id = ?`, p.Role, info.sessionID)

	// Post-response: alert if supervisor was downgraded and no supervisor remains
	var post []func()
	if oldRole == "supervisor" && p.Role != "supervisor" {
		post = append(post, d.checkNoSupervisor)
	}

	slog.Info("client role changed", "session", info.sessionID, "from", oldRole, "to", p.Role)
	return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Result: map[string]string{"status": "role_changed", "role": p.Role}}, post
}

func (d *daemon) handleListWorkers(req *jsonrpcRequest) *jsonrpcResponse {
	rows, err := d.db.Query(`SELECT session_id, role, registered_at, last_seen_at FROM agents WHERE connected = 1`)
	if err != nil {
		return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Error: &rpcError{Code: -32603, Message: err.Error()}}
	}
	defer rows.Close()

	workers := make([]map[string]any, 0)
	for rows.Next() {
		var sessID, role string
		var regAt, lastSeen int64
		if err := rows.Scan(&sessID, &role, &regAt, &lastSeen); err != nil {
			continue
		}
		workers = append(workers, map[string]any{
			"session_id":    sessID,
			"role":          role,
			"registered_at": regAt,
			"last_seen_at":  lastSeen,
		})
	}
	return &jsonrpcResponse{JSONRPC: "2.0", ID: req.ID, Result: map[string]any{"workers": workers}}
}

// checkNoSupervisor alerts all connected clients if no supervisor is active.
func (d *daemon) checkNoSupervisor() {
	var count int
	if err := d.db.QueryRow(`SELECT COUNT(*) FROM agents WHERE role = 'supervisor' AND connected = 1`).Scan(&count); err != nil {
		return
	}
	if count == 0 {
		d.pushToSession("", "notify/no_supervisor", map[string]any{
			"message": "no supervisor connected",
		})
	}
}

// ── Checkpoint watcher ───────────────────────────────────────────────────────

// CLAUDE:WARN launches as goroutine — polls vault.db every 3s. notifiedCreated/notifiedAnswered maps grow unbounded (no eviction). Watermarks based on unix timestamps, not row IDs.
func (d *daemon) watchCheckpoints(ctx context.Context) {
	answeredWM := time.Now().Unix() - 1
	createdWM := time.Now().Unix() - 1
	notifiedCreated := make(map[int64]bool)
	notifiedAnswered := make(map[int64]bool)
	ticker := time.NewTicker(3 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}

		// Poll answered checkpoints → route to the session that created them
		answered, err := d.v.PollAnsweredCheckpoints(answeredWM)
		if err != nil {
			slog.Warn("watch: poll answered error", "err", err)
		}
		for _, cp := range answered {
			if notifiedAnswered[cp.ID] {
				continue
			}
			notifiedAnswered[cp.ID] = true
			d.pushToSession(cp.SessionOrigin, "notify/checkpoint_answered", map[string]any{
				"checkpoint_id": cp.ID,
				"label":         cp.Label,
				"answer":        cp.Answer,
			})
			if cp.TsUpdated > answeredWM {
				answeredWM = cp.TsUpdated
			}
		}

		// Poll new blocking checkpoints (no answer) → route to supervisors
		created, err := d.v.PollNewCheckpoints(createdWM)
		if err != nil {
			slog.Warn("watch: poll created error", "err", err)
		}
		for _, cp := range created {
			if notifiedCreated[cp.ID] {
				continue
			}
			notifiedCreated[cp.ID] = true
			d.pushToRole("supervisor", "notify/checkpoint_created", map[string]any{
				"checkpoint_id": cp.ID,
				"label":         cp.Label,
				"question":      cp.Question,
				"source_session": cp.SessionOrigin,
			})
			if cp.TsCreated > createdWM {
				createdWM = cp.TsCreated
			}
		}
	}
}

// CLAUDE:WARN takes mu.RLock — writes to client connections (enc.Encode). If session is empty, broadcasts to ALL clients. Silent on encode errors (logs but continues).
func (d *daemon) pushToSession(session, method string, params map[string]any) {
	notif := map[string]any{"jsonrpc": "2.0", "method": method, "params": params}
	d.mu.RLock()
	defer d.mu.RUnlock()
	for _, ci := range d.clients {
		if session == "" || ci.sessionID == session {
			if err := ci.enc.Encode(notif); err != nil {
				slog.Warn("push failed", "session", ci.sessionID, "method", method, "err", err)
			}
		}
	}
}

// CLAUDE:WARN takes mu.RLock — writes to client connections (enc.Encode). Iterates all clients, sends to matching role. Silent on encode errors.
func (d *daemon) pushToRole(role, method string, params map[string]any) {
	notif := map[string]any{"jsonrpc": "2.0", "method": method, "params": params}
	d.mu.RLock()
	defer d.mu.RUnlock()
	for _, ci := range d.clients {
		if ci.role == role {
			if err := ci.enc.Encode(notif); err != nil {
				slog.Warn("push failed", "session", ci.sessionID, "role", role, "method", method, "err", err)
			}
		}
	}
}

// ── Main ─────────────────────────────────────────────────────────────────────

func main() {
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{Level: slog.LevelInfo})))

	projectDir := os.Getenv("PROJECT_DIR")
	if projectDir == "" {
		projectDir, _ = os.Getwd()
	}
	dbPath := filepath.Join(projectDir, dbRelPath)

	if err := os.MkdirAll(filepath.Dir(dbPath), 0700); err != nil {
		slog.Error("mkdirall", "err", err)
		os.Exit(1)
	}

	dsn := dbPath + "?_txlock=immediate&_pragma=busy_timeout(10000)&_pragma=journal_mode(WAL)&_pragma=foreign_keys(1)&_pragma=synchronous(NORMAL)"
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		slog.Error("open db", "err", err)
		os.Exit(1)
	}
	defer db.Close()
	db.SetMaxOpenConns(4)

	if _, err := db.Exec(vault.Schema); err != nil {
		slog.Error("schema", "err", err)
		os.Exit(1)
	}
	vault.Migrate(db)

	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	// Reset all sessions to disconnected on startup — no TCP connections exist yet.
	db.Exec(`UPDATE agents SET connected = 0`)

	d := newDaemon(db)

	// Start checkpoint watcher
	go d.watchCheckpoints(ctx)

	// WAL checkpoint goroutine
	go func() {
		ticker := time.NewTicker(2 * time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				db.Exec("PRAGMA wal_checkpoint(PASSIVE)")
			}
		}
	}()

	ln, err := net.Listen("tcp", listenAddr)
	if err != nil {
		slog.Error("listen", "addr", listenAddr, "err", err)
		os.Exit(1)
	}
	slog.Info("daemon listening", "addr", listenAddr, "db", dbPath)

	// Accept loop in goroutine — cancel ctx to stop
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				if ctx.Err() != nil {
					return // shutting down
				}
				slog.Warn("accept", "err", err)
				continue
			}
			go d.handleConn(ctx, conn)
		}
	}()

	<-ctx.Done()
	slog.Info("shutting down")
	ln.Close()

	// Give connections 2s to drain
	time.Sleep(2 * time.Second)
	fmt.Fprintln(os.Stderr, "daemon stopped")
}
