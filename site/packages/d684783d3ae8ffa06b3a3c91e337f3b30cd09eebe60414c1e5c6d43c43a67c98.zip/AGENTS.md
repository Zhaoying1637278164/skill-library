@./skills/parrot/SKILL.md
