# message-house Eval Suite

Setup populates `/foundation/brain.md` with a baseline PMM context (Sections 1–6) unless a test explicitly varies it, and checks `/context/skill-sessions.md` for the Learning Close row after each run.

## Eval 1 — Full source, complete Roof + Pillars

**Setup:** `/foundation/brain.md` fully populated — Section 1 (product name, tagline, use case, descriptions), Section 2 (ICP with target audience/user/buyer persona), Section 3 (positioning statement + 3 named differentiators), Section 5 (customer pain per differentiator), Section 6 (proof points and one real customer example per differentiator).

**Prompt:** "Build our message house."

**Expect:** Single deliverable with a complete Roof table (all 11 fields populated, none blank) and a 3-column Pillars table (Key value, Promise, Customer pain, Product promise, Product proof points, Customer examples — all populated from Sections 3/5/6). No `[MISSING]` tags. "Still needed" list absent or empty.

## Eval 2 — No brain, no pasted positioning output → block

**Setup:** No `/foundation/brain.md` file. No positioning-messaging output pasted in conversation.

**Prompt:** "Give me a message house for our product."

**Expect:** Skill blocks before building any table. Response redirects to `product-marketing-context` or `positioning-messaging` (BUILD mode), matching the Pre-flight gate language. No table is produced.

## Eval 3 — Partial brain: gaps flagged, never fabricated

**Setup:** `/foundation/brain.md` present with Section 3 positioning statement and one differentiator, but Section 2 (ICP/personas) empty, Section 6 proof points containing a literal placeholder ("xx% increase", "[customer]").

**Prompt:** "Build our message house."

**Expect:** Target audience, User persona, and Buyer persona rows marked `[MISSING — ...]`, not invented. The placeholder proof point is flagged `[MISSING — replace placeholder]`, not carried through as if it were a real stat. A "Still needed" list at the end enumerates every flagged field — count in the list matches count of `[MISSING]` cells in the tables.

## Eval 4 — More than 3 pillar candidates → forces ranking, never silently picks

**Setup:** `/foundation/brain.md` Section 3 contains 5 named differentiators, all with supporting Section 5/6 content.

**Prompt:** "Build our message house."

**Expect:** Skill does not silently choose 3 of the 5. It asks the user to rank or merge down to 3 before building the Pillars table. No table with more than 3 pillar columns is ever produced, and none is produced before the ranking question is resolved.

## Eval 5 — Pasted positioning-messaging output overrides stale brain

**Setup:** `/foundation/brain.md` Section 3 has an old positioning statement. User pastes a fresh `positioning-messaging` BUILD-mode output in the same message with a different positioning statement and updated pillars.

**Prompt:** "Here's our latest positioning: [pasted BUILD output]. Now build the message house."

**Expect:** Roof's Positioning statement row and the Pillars table reflect the pasted output, not the stale brain content. The one-line conflict note is surfaced to the user (e.g. "used your pasted positioning over the brain's older Section 3 statement").

## Eval 6 — Learning Close logs the canonical shape, no permission asked

**Setup:** Any successful run (e.g. Eval 1's setup).

**Expect:** After delivering the message house, the skill appends one entry to `/context/skill-sessions.md` matching the canonical Type A format from `product-marketing-context/.claude-plugin/skill-sessions-format.md` — exactly these fields, in this order: `type: execution`, `skill`, `session_date`, `pattern`, `source`. No additional fields (no `pillars_built`, `missing_fields`, or `missing_field_names` as separate keys — that detail belongs inside the free-text `pattern` line, e.g. "Built 3 pillars from brain; Target audience and Buyer persona both missing"). `source` is one of `surprised / wrong / missing / n.v.t.`, never a description of where the input data came from. Logged directly, without asking the user to confirm the log entry (only brain writes require confirmation, and this skill makes none). A run that omits `type: execution` fails this eval even if every other field is correct — `meta-synthesis` silently skips any entry without it.

## Eval 7 — End-to-end, single deliverable

**Setup:** Eval 1's fully-populated brain.

**Prompt:** "Build our message house."

**Expect:** Output arrives as one document containing both tables together, not split across multiple messages or a table-then-a-follow-up-message pattern. The skill does not attempt to also audit or rewrite the underlying positioning (that's `positioning-messaging`'s job) — it only reformats what it read.

## Eval 8 — /gaps returns the punch list only, no table

**Setup:** Eval 3's partial brain (some fields missing, one placeholder proof point).

**Prompt:** "/gaps"

**Expect:** Steps 0–1 run, but no Roof or Pillars table is produced. Response is just the "Still needed" list — same field names and count that Eval 3's full run would have produced under "Still needed." No Learning Close row is required to test here, but if one is logged it must still match the Step 6 shape.

## Eval 9 — /roof and /pillars build only their half

**Setup:** Eval 1's fully-populated brain.

**Prompt A:** "/roof"
**Expect A:** Only the Roof table is returned (Steps 0, 1, 2). No Pillars table, no pillar-selection question, even though Section 3 has 3 valid differentiators available.

**Prompt B:** "/pillars"
**Expect B:** Only the Pillars table is returned (Steps 0, 1, 3, 4). No Roof table. If more than 3 differentiators are present, the same ranking gate from Eval 4 still applies before the table is built.

## Eval 10 — /house matches default full-run behavior

**Setup:** Eval 1's fully-populated brain.

**Prompt:** "/house"

**Expect:** Identical output shape to Eval 1's plain-language prompt — full Roof + Pillars table, "Still needed" section (empty here), and a Learning Close row logged. Confirms the shortcut is not a different code path with different guarantees, just a faster entry point into the same Steps 0–6.

## Eval 11 — Cell formatting: multi-item fields are line-broken, not run together

**Setup:** Eval 1's fully-populated brain, with Key features containing 4 named features and Product proof points containing 3 items for at least one pillar.

**Prompt:** "Build our message house."

**Expect:** The Key features cell shows each feature on its own line (real line break, not comma-separated or packed onto one visual line), each prefixed with `•`. Every Product proof points cell with 2+ items does the same. Long description and any multi-sentence Pillar field (Customer pain, Product promise) break at sentence boundaries when more than one sentence is present, with no bullet character on those lines (they're prose, not a list). Customer examples show the quote on one line and the attribution on the line below it, not inline after an em dash, and neither line carries a bullet. No table cell contains 2+ distinct items or sentences run together on one line. No `-` or `*` appears as a bullet marker anywhere in the deliverable — `•` is the only bullet character used.

## Eval 12 — Emoji restraint: section headers only

**Setup:** Eval 1's fully-populated brain.

**Prompt:** "Build our message house."

**Expect:** Exactly three emoji markers appear in the output, one each on the Roof heading (🏠), the Value Pillars heading (🏛️), and — only if "Still needed" is non-empty — that heading (📋). Zero emoji appear inside any table cell, bullet, or the "Still needed" list items themselves. Re-run against Eval 3's partial-brain setup (non-empty "Still needed") to confirm the 📋 marker appears there and is absent when the list is empty (as in this eval's fully-populated case).

## Eval 13 — Key feature names are bolded, Benefits/proof points are not

**Setup:** Eval 1's fully-populated brain, Key features containing at least 3 named features, at least one pillar with 2+ Product proof points.

**Prompt:** "Build our message house."

**Expect:** Every Key features bullet has its feature name bolded (`**Name**`) before the em dash, with the explanation after it left plain. Benefits bullets and Product proof points bullets carry no bolding anywhere — they're outcome statements, not named things. A run where a Key features bullet is missing its bold, or where a Benefits/proof-points bullet is incorrectly bolded, fails this eval.

## Eval 14 — Description word limits are counted and enforced, not just stated

**Setup A (source within limit):** Brain Section 1 has a Short description under 25 words and a Long description under 150 words.
**Expect A:** Both ship as-is, unmodified in substance.

**Setup B (source over limit):** Brain Section 1 has a Short description of 35 words and a Long description of 180 words.
**Expect B:** Both are trimmed to fit under 25/150 words respectively before shipping — the skill does not ship an over-length draft, does not add a caveat instead of trimming, and does not mark either field `[MISSING]` solely for being over-length (that flag is reserved for absent source content, per Step 1). The trimmed version preserves the source's actual claims — no invented replacement sentences standing in for cut content.

**Setup C (no source at all):** Brain Section 1 has no Short description and no Long description, and nothing was pasted this session.
**Expect C:** Both fields are marked `[MISSING — ...]`, listed under "Still needed." This confirms Eval 14's word-count enforcement didn't get confused with Step 1's separate "no source" gap-flagging.
