---
name: run-multichannel-outreach
description: Build and run LinkedIn, Instagram and WhatsApp outreach in WarmySender - create the campaign, enroll prospects, start or pause it, publish LinkedIn posts and jobs, and check account health and throttle. Use when the user asks about LinkedIn connection requests or messages, Instagram DMs, WhatsApp sequences, multichannel outreach, or why a social account is sending slowly.
---

# Run LinkedIn, Instagram and WhatsApp outreach

WarmySender runs social outreach on the same pattern as email: you build the campaign,
enroll people, and the scheduler paces every action.

## The safety rule that shapes everything

A social account is far less forgiving than a mailbox - an account that trips a platform
limit can be lost for good. So:

- You never send a connection request, DM or message yourself. Starting a campaign only
  hands it to the scheduler.
- You can never raise a limit. Daily caps and the gradual ramp on a new account are fixed,
  and they always win over the user's preferred pace.
- A brand new account starts slow on purpose and climbs over weeks. "Slower than expected"
  is almost always the ramp working correctly, not a fault.

Connecting and disconnecting accounts is done by the user in WarmySender itself - that is
deliberately not something an agent does.

## LinkedIn

- `list_linkedin_accounts` and `get_linkedin_account_health` first. If a session has
  lapsed, the fix is for the user to reconnect in the app; nothing you do here will help.
- `create_linkedin_campaign` builds the sequence - typically a connection request, then a
  message after acceptance, then a follow-up. `enroll_in_linkedin_campaign` adds people.
- `start_linkedin_campaign`, `pause_linkedin_campaign`, `resume_linkedin_campaign`.
- `list_linkedin_campaigns`, `get_linkedin_campaign_stats` and
  `get_linkedin_campaign_throttle` for results. The throttle view is the honest answer to
  "why so few invites today".
- Content and hiring: `create_linkedin_post` / `publish_linkedin_post` / `delete_linkedin_post`,
  and `create_linkedin_job` / `publish_linkedin_job` / `close_linkedin_job` /
  `list_linkedin_job_applicants`.

A campaign runs exactly as the user configured it. Do not add "helpful" auto-skips or
auto-advances the user did not ask for - if a step should branch on acceptance, say so and
let them decide.

## Instagram

`list_instagram_accounts`, `get_instagram_account_health`, `create_instagram_campaign`,
`enroll_in_instagram_campaign`, then `start_instagram_campaign` /
`pause_instagram_campaign` / `resume_instagram_campaign`, with
`list_instagram_campaigns` and `get_instagram_campaign_stats` for results.

There is no profile search on Instagram - the user brings the handles, by import. If asked
to "find accounts in a niche", explain that and offer to work from a list they provide.

## WhatsApp

`list_whatsapp_accounts`, `get_whatsapp_account_health`, `create_whatsapp_campaign`,
`enroll_in_whatsapp_campaign`, `start_whatsapp_campaign` / `pause_whatsapp_campaign` /
`resume_whatsapp_campaign`, plus `list_whatsapp_campaigns` and
`get_whatsapp_campaign_stats`.

WhatsApp is the most consent-sensitive channel. Opt-out replies stop the sequence
automatically, and you should never propose messaging people who have not asked to hear
from the sender.

## Sequencing channels together

A sane multichannel order is LinkedIn first, then WhatsApp, then Instagram, with email
running alongside. Give each channel a few days before the next one opens - stacking three
channels on one person in one day reads as spam on every one of them.
