---
name: launch-cold-email-campaign
description: Build, launch and manage a cold email campaign in WarmySender - create the sequence, add or import prospects, enroll them, start or pause the campaign, and read results. Use when the user asks to set up cold outreach, write a follow-up sequence, enroll a list, check reply or bounce numbers, or pause and resume sending.
---

# Launch a cold email campaign

Use the WarmySender tools to take a campaign from idea to running, then keep an eye on it.

## What you can and cannot do

You can create the campaign, write the sequence, add prospects, enroll them, and start,
pause or resume sending. You never send an individual email yourself, and you can never
raise a sending limit. Starting a campaign hands it to WarmySender's scheduler, which
paces every message across the connected mailboxes inside safe daily caps and the gradual
warmup ramp. If the user asks for "all 5,000 today", explain that the scheduler decides
the daily pace and the campaign will simply take as many days as the caps require.

## Recommended order

1. **Check the workspace first.** `get_workspace_info` tells you the plan, the sending
   allowance and what is connected. `list_mailboxes` and `get_mailbox_health` show which
   mailboxes are actually ready to send. A campaign with no healthy mailbox will sit idle,
   so surface that before building anything.
2. **Create the campaign** with `create_campaign`. Ask for, or propose, the sequence:
   a first email plus two or three follow-ups is a sensible default. Space the follow-ups
   by two to four working days. Use `update_campaign` to revise steps, sending window,
   timezone or the mailboxes assigned to it.
3. **Get prospects in.** `create_prospect` for one, `bulk_create_prospects` for a list.
   Personalisation tokens such as `{{firstName}}` only render when that field is present,
   so check that first names and company names are actually populated before writing copy
   that leans on them.
4. **Verify the addresses** before enrolling a cold list. See the
   `protect-email-deliverability` skill - sending to unverified addresses is the fastest
   way to damage a sender's reputation.
5. **Enroll and start.** `enroll_prospects`, then `start_campaign`. Use `unenroll_prospects`
   to pull someone out and `pause_campaign` / `resume_campaign` to control sending.
6. **Read the results** with `list_campaigns`, `get_campaign` and `list_prospects`.
   `list_skipped_actions` explains why something did not go out - it is the first place
   to look when a campaign is running but the numbers are lower than expected.

## Writing the sequence

- One clear ask per email. Short beats clever.
- Follow-ups should add a new angle, not repeat the first email louder.
- Avoid a wall of links or images in the first touch.
- Only use a merge token when the underlying field is filled in for the whole list.

## Common questions

- **"Running but nothing sent"** - check the start date and sending window, then
  `list_skipped_actions`, then mailbox health.
- **"One list on several campaigns"** - the same list attached to several campaigns does
  not split the contacts between them; everyone gets enrolled in each. Use one campaign
  with A/B variants instead.
- **Suppressions** - `add_to_suppression_list` and `list_suppressions` keep people out of
  every campaign in the workspace. Honour any opt-out request immediately.
