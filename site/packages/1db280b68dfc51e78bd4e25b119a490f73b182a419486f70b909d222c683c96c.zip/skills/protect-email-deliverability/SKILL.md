---
name: protect-email-deliverability
description: Keep a sender's reputation healthy in WarmySender - verify email addresses before sending, configure and monitor email warmup, check mailbox health, manage tracking domains and suppression lists, and find B2B leads. Use when the user asks about bounces, spam placement, warmup settings or stats, verifying a list, a custom tracking domain, or sourcing new contacts.
---

# Protect deliverability

Everything here exists to keep messages landing in the inbox. Reputation is slow to build
and fast to lose, so bias towards the cautious option every time.

## Verify before you send

Bouncing a cold list is the quickest way to burn a sending domain.

- `verify_email` for a single address, `submit_verification_batch` for a list.
- `get_verification_result` and `list_verification_batches` to follow a batch,
  `cancel_verification_batch` to stop one, `create_list_from_verification` to turn the
  clean results straight into a prospect list.
- `get_verification_allowance` shows how much verification the plan has left.

Verification runs on the same paced allowance as everything else, so a very large list
takes time. That is the design, not a delay to work around.

There is no way to discover an address that a list does not contain. If the user asks the
agent to "find the email for this person", the honest answer is that they need a list that
already carries the addresses, or the leads database below.

## Warmup

Warmup quietly builds a mailbox's reputation by exchanging real conversations before real
campaigns start.

- `update_warmup_settings` for one mailbox, `bulk_update_warmup` across several.
- `get_warmup_stats` for how it is performing, `get_mailbox_health` and `list_mailboxes`
  for the state of each mailbox.

Guidance worth repeating to users:

- Leave warmup running while campaigns run, not just before them.
- A brand new mailbox needs weeks, not days. Raising the volume early is what causes the
  spam placement the user is trying to avoid.
- Warmup mail carries a reference tag in the subject so it can be filtered out of an inbox
  with an ordinary mail rule.
- If a mailbox shows as reconnecting or errored, that is usually a mail provider throttle
  or a lapsed connection - the fix is in the app, not in a setting change.

## Tracking domains

`add_tracking_domain`, `verify_tracking_domain`, `list_tracking_domains` and
`remove_tracking_domain`. A custom tracking domain on the sender's own brand keeps link
tracking off a shared host and is worth setting up before a first large campaign. After
adding one, the user needs to publish the DNS record it asks for, then verification will
pass.

## Suppressions

`add_to_suppression_list` and `list_suppressions`. Suppression is workspace-wide and
permanent by intent. Add anyone who asks out, anyone who complained, and any address that
hard bounced.

## Finding new contacts

`search_leads` searches the B2B leads database by criteria such as industry, role and
location. `save_leads` brings the results into the workspace and `export_leads` takes them
out. Leads are released on a daily pace rather than all at once - so plan a large build
over several days rather than expecting one bulk pull.

## Jobs

Anything long-running returns a job. `get_job_status` tells the user where it is instead
of guessing.
