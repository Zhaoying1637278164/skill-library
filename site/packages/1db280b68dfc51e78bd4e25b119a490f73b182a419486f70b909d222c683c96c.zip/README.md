<img src="assets/logo.png" alt="WarmySender" width="88" align="right">

# WarmySender plugin

**Run your outreach on autopilot with AI agents.**

Build, launch and manage cold email, LinkedIn, Instagram and WhatsApp campaigns, verify
email addresses, tune warmup and pull B2B leads — all in plain language, from the agent you
already use.

Your agent never sends a message, DM or invite itself, and it can never raise a limit.
Creating or launching a campaign simply writes it and hands it to WarmySender's scheduler,
which paces every email, LinkedIn, Instagram and WhatsApp action inside safe caps and the
gradual ramp — no matter whether a person or an agent started it. Connecting and
disconnecting accounts stays in the app.

## What the plugin ships

| Component | Contents |
|---|---|
| MCP server | `https://warmysender.com/mcp` — 75 tools across campaigns, prospects, warmup, mailboxes, LinkedIn, Instagram, WhatsApp, email verification, tracking domains, suppressions and B2B leads |
| Skills | `launch-cold-email-campaign`, `run-multichannel-outreach`, `protect-email-deliverability` |

## Install

### Cursor

Install **WarmySender** from the [Cursor Marketplace](https://cursor.com/marketplace), then
paste your WarmySender API key when Cursor asks for it (**Plugins → Configure**).

Create the key in WarmySender under **Settings → API Keys**.

### Claude Code

```bash
claude plugin install warmysender
```

### Any other MCP client

Point it at `https://warmysender.com/mcp` (streamable HTTP). Two ways to authenticate:

- **Sign in through the browser** — the server supports OAuth 2.1 with PKCE and dynamic
  client registration, so clients that speak it need no key at all.
- **API key** — send `Authorization: Bearer <your key>` with each request.

```json
{
  "mcpServers": {
    "warmysender": {
      "type": "http",
      "url": "https://warmysender.com/mcp"
    }
  }
}
```

## Capabilities

| Area | What your agent can do |
|---|---|
| Cold email | Create campaigns and sequences, add and import prospects, enroll and unenroll, start, pause and resume, read results |
| LinkedIn | Build and run connection and message sequences, publish posts and job listings, check account health and throttle |
| Instagram | Build and run DM sequences from a list of handles, check account health and stats |
| WhatsApp | Build and run message sequences with opt-out handling, check account health and stats |
| Email warmup | Configure warmup per mailbox or in bulk, read warmup performance and mailbox health |
| Email verification | Verify a single address or a batch, turn clean results into a list, check the remaining allowance |
| B2B leads | Search the leads database by industry, role and location, save and export results |
| Deliverability | Add and verify custom tracking domains, manage workspace suppression lists |

## Network and credentials

This plugin calls exactly one endpoint: `https://warmysender.com/mcp`. It reads no files
and runs no local code. The only credential it uses is the WarmySender API key you supply,
which is stored by your client — never in this repository.

## Links

- [WarmySender](https://warmysender.com)
- [Documentation](https://warmysender.com/documentation)
- [Tool reference](https://warmysender.com/mcp)
- [Connect your AI agent](https://warmysender.com/documentation/connect-your-ai-agent)
- Listed on the [MCP Registry](https://registry.modelcontextprotocol.io) as `com.warmysender/mcp`

## License

MIT — see [LICENSE](LICENSE).
