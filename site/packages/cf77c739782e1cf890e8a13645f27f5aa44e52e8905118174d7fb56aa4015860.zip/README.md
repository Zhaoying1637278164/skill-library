# inhabited-design

A [Claude Code](https://claude.com/claude-code) Agent Skill that turns *"build me X for
Y"* into a polished, target-user-rated web app, page, tool, or asset — where **every
design choice traces to a deterministic random sample drawn from an enumerated pool**,
not to model reach.

Each design input — framing, designer voice, inspiration seeds, hard constraint,
competitors, typography — is generated through **Verbalized Sampling (VS)**: the model
enumerates a candidate pool conditioned on the brief, verbalizes why each candidate fits
or fails, filters to the survivors, then draws a sample deterministically via an external
Bash gate. The framing sentence is the master conditioning variable, so the resulting
variance is coherent rather than noisy. Every pick is logged with its enumerated pool,
per-candidate reasoning, and millisecond RNG seed to `sampling.md` — fully auditable and
replayable with `random.Random(seed).sample(range(N), K)`.

## Why

Generative design tools collapse toward a trained attractor — the same cream-and-serif,
the same safe layout. This skill forces variance to come from a logged, replayable sample
instead of the model's default, and makes every borrowed element name the specific
sampled input it derived from. The result is output that reads as authored, not generic,
and an audit trail that proves it.

## How it works

A 14-step pipeline. Step 1 runs in the main conversation; Steps 2–14 run in dispatched
subagents that share state only through files. Six inputs are VS-sampled and locked to
`sampling.md` before any persona or design code is written:

| VS step | What's sampled |
|---|---|
| Framing (Steps 2–4) | The framing sentence — the master conditioning variable |
| Designer (Step 5) | Primary practitioner whose voice the build adopts |
| Seeds (Step 6) | Two inspiration seeds |
| Constraint (Step 7) | One or two hard constraints the critic enforces |
| Competitors (Step 8) | Two competitors plus converge/diverge judgment tables |
| Typography (Step 10) | Primary typeface, against a banned-canon list |

The build then runs through an adversarial **critic loop** (4-factor rubric: fits framing
/ fits sampled inputs / fits competitor judgment / fits axis manifestation, plus a slop
gate and constraint gate) and an **ICP loop** (7-factor target-user rubric: Usability,
Flare, Personality, Visual Design, Originality, Visual Impressiveness, Wow Factor) until
both converge. Photography is filled from stock (Unsplash/Pexels) at the end of every
iteration so the reviewer always sees real images in place.

Full depth lives in the protocol files under [`references/`](references/); `SKILL.md` is
the orchestration map.

## What you get

The deliverable is a single self-contained `index.html` (the converged build lands at
`.inhabited/final/index.html`). **That file *is* the design** — a high-fidelity,
reviewable artifact, not code wired into your application. Putting it into a real product
is a separate handoff: re-implement it in your framework, or feed the HTML to a
code-integration step.

Everything else the run produces — the seeded `sampling.md`, the personas, the inspiration
bank, downloaded reference images, screenshots, and every iteration — lives under a single
`.inhabited/` directory at the project root. Add it to your project's `.gitignore`.

## Installation

This repo is both a Claude Code **plugin marketplace** and the plugin it serves.

### Plugin marketplace (recommended — gives you updates)

```text
/plugin marketplace add Shimin-Zhang/inhabited-design
/plugin install inhabited-design@inhabited-design
/reload-plugins
```

Pull future updates with `/plugin marketplace update inhabited-design`. Installed as a
plugin, the skill is **namespaced** — invoke it as `/inhabited-design:inhabited-design`
(a manual install uses the bare `/inhabited-design`); the run-mode keyword is the
argument, e.g. `/inhabited-design:inhabited-design lite`.

> If `/plugin` isn't recognized, Claude Code is out of date — update it
> (`npm i -g @anthropic-ai/claude-code@latest`, or `brew upgrade claude-code`) and retry.

### Manual install

Copy just the skill directory into a skills path Claude Code scans:

```bash
git clone https://github.com/Shimin-Zhang/inhabited-design.git
cp -r inhabited-design/skills/inhabited-design ~/.claude/skills/   # personal
# or, per-project:
cp -r inhabited-design/skills/inhabited-design <your-project>/.claude/skills/
```

Then invoke it in a Claude Code session (see triggers below). Run modes (plugin installs prefix the namespace, e.g. `/inhabited-design:inhabited-design auto`):

- `/inhabited-design` — **interactive** (default): confirm every VS pick.
- `/inhabited-design semi-auto` — confirm only the framing + designer picks; the rest fire through.
- `/inhabited-design auto` — non-interactive: all picks fire through.
- `/inhabited-design lite` — budget single-pass (~200–350k tokens): framing + designer + typography, no critic loop, ICP capped at 2 iterations. A strong v1, not a guaranteed perfect score.

## Requirements

The pipeline needs one tool from each capability class — verify them before a run (it
preflights and stops if any is missing, rather than failing mid-pipeline):

- **A vision-capable model** — the pixel-verification gate judges rendered screenshots, so
  the driving model must be able to see images. Run on Opus or Sonnet; **it will not work
  on Haiku.**
- **A headless browser with screenshot-to-file** — Playwright MCP, Chrome DevTools MCP, or
  equivalent. Required for the pixel-verification gate (DOM-only review is blocked).
- **A web-search tool** — `WebSearch`, Brave Search MCP, or equivalent. Required for
  anti-defaults research and competitor/domain lookups.
- **A scripting runtime via Bash** — `python3` by default; node/ruby/any language works.
  Runs the deterministic sampling gate.

Budget ≈200k tokens per iteration × 3–5 iterations for a full run; use `lite` for a
cheaper single pass.

## When to use

- You want every design choice to trace to a deterministic random sample, not model reach
- You want full auditability: enumerated pool + verbalized reason + ms-seed per VS step
- The brief is high-stakes enough that you want to see and optionally veto each pick
- You want explicit competitor analysis as a formal constraint
- Typography is contentious and a reflex-ban list isn't enough

It triggers on phrases like *"iterate to a perfect score," "no canon," "really diversify
the inspiration," "use IFG/VS,"* or an explicit *"use inhabited-design."*

## When not to use

- One-off prototype, not shipping — the 14-step setup isn't worth it
- The brief has no aesthetic requirements (correctness matters, not craft)
- You just want it working, or have no ICP specificity
- Budget is tight — plan ≈200k tokens per iteration and 3–5 iterations to converge

## Repository layout

```
.claude-plugin/
  marketplace.json          Marketplace catalog (lists this one plugin)
  plugin.json               Plugin manifest
skills/
  inhabited-design/
    SKILL.md                Orchestration map — the 14-step pipeline and all hard gates
    references/             21 protocol files, one per discipline (source of truth per step)
LICENSE                     Apache License 2.0
NOTICE.md                   Attribution and inspirations
```

## The eval loop, generalized

Underneath the design vocabulary, the critic and ICP loops are an **eval harness**: a
decomposed rubric, a judge that scores against it, and a gate that won't pass until the
score stops moving. Here it grades a landing page. Pointed at a shipping AI feature, the
same loop is the day job at [**Wolf Peach Labs**](https://wolfpeachlabs.com) — *evals for
the AI features you're afraid to change*, where a moving score costs a good deal more than
it does on a wordmark.

## Acknowledgments

This skill is original work that draws conceptual inspiration from two frontend-design
skills (both Apache 2.0). No code from either is bundled here — see `NOTICE.md` for full
attribution.

- [**frontend-design**](https://github.com/anthropics/skills/tree/main/skills/frontend-design)
  by Anthropic, PBC — committing to craft and avoiding generic AI aesthetics.
- [**impeccable**](https://github.com/pbakaus/impeccable) by Paul Bakaus — committed
  design choices and a curated anti-pattern catalog.

It builds on the **Verbalized Sampling (VS)** method ([arXiv:2510.01171](https://arxiv.org/abs/2510.01171))
and the related **Intent Factored Generation (IFG)** method ([arXiv:2506.09659](https://arxiv.org/abs/2506.09659)).

## License

Licensed under the Apache License, Version 2.0. See [`LICENSE`](LICENSE) and
[`NOTICE.md`](NOTICE.md).

Copyright 2026 Shimin Zhang.
