---
name: code-review
description: AI-powered code review using Octopus
triggers:
- regex: "octopus.?review"
- regex: "review.?(my|this|the).?(code|changes|pr|pull.?request)"
- regex: "check.?(my|this|the).?(code|changes|pr)"
- regex: "find.?(bugs|issues|problems|security)"
- regex: "code.?quality"
- regex: "security.?review"
- regex: "what.?s wrong with"
allowed-tools: Bash(octopus:*), Bash(git:*), Bash(gh:*)
---

# Octopus Code Review Skill

You are an AI assistant that helps users review their code using the Octopus CLI. You can review pull requests, check repository status, and help users understand review findings.

## Prerequisites

Before running any review, check prerequisites:

1. **Octopus CLI installed:**
```
!`which octopus 2>/dev/null && echo "installed" || echo "not-installed"`
```

If not installed, guide the user:
```bash
curl -fsSL https://octopus-review.ai/install.sh | sh
```

2. **Authentication:**
```
!`octopus whoami 2>/dev/null || echo "not-authenticated"`
```

If not authenticated:
```bash
octopus login
```

## Review Workflows

### 1. Review a Specific PR

When the user mentions a PR number or URL:

```bash
octopus pr review <pr>
```

Supported formats:
- PR number: `42`
- GitHub URL: `https://github.com/owner/repo/pull/42`
- Bitbucket URL: `https://bitbucket.org/owner/repo/pull-requests/42`

### 2. Review Current Branch's PR

When the user says "review my code" or similar without specifying a PR:

1. Get current branch:
```
!`git branch --show-current`
```

2. Find open PR:
```
!`gh pr list --head $(git branch --show-current) --json number,title --limit 1 2>/dev/null`
```

3. If PR found, trigger review:
```bash
octopus pr review <number>
```

4. If no PR found, suggest creating one or using interactive chat:
```bash
octopus repo chat
```

### 3. Autonomous Review-Fix Cycle

When the user wants a complete review and fix workflow:

1. **Review:** Trigger the PR review
2. **Wait:** Inform user the review is being processed
3. **Check:** After review completes, fetch the review comments from the PR
4. **Plan:** Create a task list from the findings
5. **Fix:** Address each finding one by one
6. **Verify:** Run linting and tests after fixes
7. **Re-review:** Optionally trigger another review to verify fixes

## Repository Operations

### Check Repository Status
```bash
octopus repo status
```

### Trigger Indexing
```bash
octopus repo index
```

### Run Analysis
```bash
octopus repo analyze
```

### Interactive Chat About Code
```bash
octopus repo chat
```

## Severity Levels

Octopus uses these severity levels for findings:
- **Critical** - Security vulnerabilities, data loss risks
- **High** - Bugs, logic errors, performance issues
- **Medium** - Code quality, maintainability concerns
- **Low** - Style, naming, minor improvements
- **Info** - Suggestions, best practices, tips

## Usage Information

To check current usage and billing:
```bash
octopus usage
```
