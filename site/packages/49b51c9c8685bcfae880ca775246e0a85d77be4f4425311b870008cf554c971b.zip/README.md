# Octopus Claude Code Plugin

AI-powered code review in Claude Code, powered by [Octopus](https://octopus-review.ai).

## Features

- `/review` slash command for instant PR reviews
- Natural language triggers ("octopus review", "review my code")
- Autofix skill: scan open PRs for Octopus review comments, apply fixes, and push updates
- False positive handling with reactions and explanations
- Autonomous review-fix cycles
- Full integration with the Octopus platform (indexing, knowledge base, analysis)

## Prerequisites

### 1. Install Octopus CLI

```bash
# macOS / Linux
curl -fsSL https://octopus-review.ai/install.sh | sh

# Windows (PowerShell)
irm https://octopus-review.ai/install.ps1 | iex
```

### 2. Authenticate

```bash
octopus login
```

This opens your browser to authorize the CLI with your Octopus account.

Alternatively, use a token:

```bash
octopus login --token oct_your_api_token
```

### 3. Install the Plugin

From the Claude Code Plugin Marketplace:

```
claude plugin install octopus
```

Or from within Claude Code:

```
/plugin install octopus
```

## Usage

### Slash Command

```
/review
/review 42
/review https://github.com/owner/repo/pull/42
```

### Natural Language

Just ask Claude naturally:

- "Review my code"
- "Check this PR for security issues"
- "Octopus review my changes"

### Autofix

Fix unresolved review comments from Octopus:

- "Octopus autofix"
- "Octopus fix"

This scans your open PRs for unresolved `octopus-review[bot]` comments, presents them with a summary, and helps you fix them. Comments from other review tools (CodeRabbit, Greptile, etc.) are ignored.

For each comment the skill will:
- Apply the fix and reply in the thread
- React with a thumbs up for valid suggestions
- React with a thumbs down and explain for false positives
- Post a final summary tagging @octopus when done

### Other Commands

```bash
octopus repo status      # Check repository status
octopus repo index       # Trigger code indexing
octopus repo analyze     # Run AI analysis
octopus repo chat        # Interactive chat about codebase
octopus usage            # Check usage and billing
```

## Plugin Structure

```
.claude-plugin/
  plugin.json              # Plugin manifest
agents/
  code-reviewer.md         # Specialized code review agent
commands/
  review.md                # /review slash command
skills/
  autofix/
    SKILL.md               # Autofix skill (scan PRs, fix Octopus review comments)
  code-review/
    SKILL.md               # Code review skill (natural language triggers)
```

## Links

- [Octopus Website](https://octopus-review.ai)
- [Octopus CLI Documentation](https://octopus-review.ai/docs/cli)
- [GitHub](https://github.com/nicidob/octopus-claude-plugin)

## License

MIT
