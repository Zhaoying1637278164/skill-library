# Security Policy

## Reporting a vulnerability

If you believe you've found a security vulnerability in the `waldo-fyi` Claude Code plugin, please **do not** open a public issue or pull request.

Instead, email **security@waldo.fyi** with:

- A description of the issue
- Steps to reproduce
- Any proof-of-concept code or screenshots

We'll acknowledge your report within 2 business days and keep you updated on remediation.

## Scope

This policy covers the contents of this plugin (skills, commands, evals, MCP configuration). The Waldo MCP service itself (`https://mcp.waldo.fyi`) and the broader Waldo platform are covered by Waldo's main security policy at https://waldo.fyi.
