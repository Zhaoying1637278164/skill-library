# Changelog

All notable changes to vault-anything will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Fixed

- **Multi-project: grouped sub-repo discovery.** `detectSubRepos` now walks up to 3 levels deep, so repos nested under an intermediate folder (`parent/apps/sms`, `parent/packages/core`) are detected, not just those directly under the root. Discovery prunes at the first `.git` (never descends into a repo) and skips `node_modules`/build/dot directories. Each sub-repo is keyed by its path relative to the root, which matches the scanner's paths so incremental change detection and baselines work for grouped layouts. Flat layouts and existing `meta.json` baselines are unaffected.

### Added

- **`repoRoots` / `repoMaxDepth` config** (`.vault-anything.json`): explicitly list multi-project sub-repo paths (bypassing auto-discovery) or tune the auto-scan depth. Persists across `vault` and `vault-update` runs. When no git repo is found at the root or nested within it, `vault-update` now says so and points at `repoRoots` instead of silently reporting "up to date".

## [0.1.0] — 2026-06-01

First public release.

### Added

- **Plugin scaffolding**: manifest at `.claude-plugin/plugin.json`, MIT license, and docs (`README.md`, `CONTRIBUTING.md`).
- **Two skills**: `/vault-anything:vault` (full pipeline — scan → analyze → cluster → write → review) and `/vault-anything:vault-update` (incremental update via git diff and a raw-file hash manifest).
- **Two subagents**: `file-analyzer` (per-file summaries + the entity fields below) and `page-writer` (self-contained prose pages with wikilinks).
- **Deterministic core** (`packages/core/src/`, no LLM, no runtime dependencies): file scan with `.vaultignore`, framework / entry-point / import-map detection, dependency-aware batching, concept clustering, vault skeleton + Obsidian config generation, git and manifest diffing, and a quality reviewer (front matter, word count, broken wikilinks and section anchors, orphans, secret-leak detection).
- **Locale guides** (en, tr, de, es, fr) that control page-writer tone and conventions; technical terms stay in English.
- **Single-page index categories** — each folds every entity of a kind into one scannable page instead of a thin page per entity, built on a shared generic `clusterEntityIndex()` engine:
  - **API** (`api_index`) — endpoints the project serves (`handler`) or calls (`client`); the synchronous surface, doubling as a cross-service dependency map.
  - **Topics** (`topic_index`) — queues, topics, exchanges, channels, streams with producers/consumers; the asynchronous surface.
  - **Configuration** (`config_index`) — env vars, feature flags, constants, and secrets grouped by kind. Secrets are kept for audit but never carry a real value (only a redacted shape).
  - **Data Model** (`data_model_index`) — tables, ORM models, DTOs, enums with fields and relations.
  - **Integrations** (`integration_index`) — third-party SaaS, internal services, infra, and notable libraries.
  - **Jobs** (`job_index`) — cron jobs, queue workers, scheduled tasks.
  - **Permissions** (`permission_index`) — RBAC roles, scopes, permission strings.
- **Auto-derived categories**: architecture concepts and cross-cutting concerns from tag co-occurrence, and importance-scored reference pages (fan-in, tag diversity, exports, file size, `isCore`, entry-point status; top 15% capped at 25).
- **Project config file** `.vault-anything.json` (project root, optional): `flows` — the only way to get `01-Flows/` pages, since the tool never invents business flows — plus clustering overrides (`concepts`, `crossCutting`, `referenceRatio`, `maxRefPages`). See `.vault-anything.example.json`.
- **Incremental updates** (`vault-update`) that detect committed changes (`lastHash..HEAD`) and current uncommitted/untracked edits, map changed files back to the pages that reference them, and honor the scanner's ignore rules so tooling artifacts aren't mistaken for source.
- **Multi-project support**: point the tool at a parent directory of several repos for one combined vault whose API/Topics indexes bridge the services. When the parent isn't itself a git repo, each sub-repo is detected and diffed against its own recorded HEAD. The vault's `index.md` lists the contributing services and their analyzed file counts.
- **Secret leak detector** in the reviewer — flags high-confidence credential patterns (Stripe/GitHub/AWS keys, JWTs, URLs with embedded passwords) as hard issues, since the vault is committed.
- **Example project** `examples/hello-queue/`, **CI** (`.github/workflows/syntax-check.yml` validating `.mjs` syntax + the manifest), and issue/PR templates.

### Notes

- The workspace (`<project>/vault-anything/`) is a visible directory meant to be committed alongside code; only `raw/vault-review.json` is run-to-run noise worth gitignoring.
- Inputs validated and git invoked via `execFileSync` (argv arrays); `.vaultignore` patterns are regex-escaped — no shell-injection or ReDoS surface from workspace files.
