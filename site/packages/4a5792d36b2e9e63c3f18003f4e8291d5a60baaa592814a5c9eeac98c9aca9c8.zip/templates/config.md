# config_index page template

A **single** wiki page that catalogs every named configuration entity in the project: environment variables, feature flags, shared constants, and secrets. One page per project, not one page per entity — a project with 80 env vars gets one index, not 80 thin pages.

Specific entities are addressable via Obsidian section anchors: `[[Configuration#DATABASE_URL]]`, `[[Configuration#feature.payments.v2]]`.

## Section structure

The page is organized by **kind**. Each kind is a top-level section with its own table and (for secrets and notable cases) per-entity detail. Skip any section whose kind has no entries.

1. **Opening paragraph** — one paragraph describing how this project handles configuration overall (env vars at deploy time? config service? feature flag platform?). Lead with the system, not the technology.

2. **## Secrets** — render first if any exist. Start the section with a warning:

   > ⚠️ Values are intentionally redacted. The vault never stores real secret values.

   Then a table:

   | Name | Format | Read by | Notes |
   |------|--------|---------|-------|
   | DATABASE_URL | `postgres://****@host:5432/db` | [[main.go]], [[migrate.go]] | Rotation invalidates all running instances |
   | JWT_SECRET | `<64-char hex>` | [[authService.go]] | — |
   | STRIPE_KEY | `sk_live_****` | [[payment.go]] | Hardcoded in source — rotate at provider |

   For secrets with notable caveats (hardcoded leak detected, rotation procedure), add a per-entity H3 (`### DATABASE_URL`) with a paragraph below the table. Most secrets need only a table row.

3. **## Environment Variables**

   | Name | Default | Read by | Notes |
   |------|---------|---------|-------|
   | PORT | 8080 | [[main.go]] | — |
   | MAX_RETRIES | 3 | [[client.go]] | — |
   | LOG_LEVEL | info | (4 files) | — |

   Optional per-entity H3 sections only when an env var deserves discussion (deprecated, behavior-changing, security-relevant).

4. **## Feature Flags**

   | Name | Default | Read by | Status |
   |------|---------|---------|--------|
   | feature.payments.v2 | false | [[handler.go]] | Active migration |
   | feature.legacy_login | true | (no readers found) | Dead flag — remove |

   "Status" cell is judgment: active rollout, stale, blocked by something, etc. The file-analyzer's tags and isCore hints give clues. Omit the column if no useful status exists.

5. **## Shared Constants**

   | Name | Value | Defined in | Used by |
   |------|-------|------------|---------|
   | MAX_BATCH_SIZE | 100 | [[constants.go]] | (5 files) |
   | API_BASE_URL | https://api.example.com | [[client.go]] | (3 files) |

   Local constants (used in only one file) are filtered out by the clustering step — they don't appear here.

6. **## Caveats** (optional) — cross-cutting observations, e.g. *"three different files duplicate the database connection string as a const — should be a shared env var"*, or *"no schema validation on any env var; bad values fail silently at runtime"*.

7. **## Related Pages** — wikilinks to architectural concept pages (Configuration, Security), and to reference pages for files that hold central config logic.

## Notes

- The page title is always `Configuration`.
- Front matter `type: config_index`.
- If the project has no shared config entities at all, the page is not produced.
- Secrets always get a row even if they appear in just one file; everything else needs at least 2 file references.
- The vault reviewer scans this page like any other — never paste a real credential into the page even by accident. The `valueShape` field from the file-analyzer is what goes in the Format column.
- Each entity name in a table cell can become an Obsidian anchor target by giving it an H3 section. Use anchors only for entities that need extra discussion; pure table rows are fine without anchors.
