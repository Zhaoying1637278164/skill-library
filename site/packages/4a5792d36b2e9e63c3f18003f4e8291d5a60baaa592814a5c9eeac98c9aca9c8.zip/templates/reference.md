# reference page template

A page describing one high-fan-in file or component — a piece of code that many other parts of the system depend on, important enough to warrant its own page.

## Section structure

1. **Opening paragraph** — what this file is and why it matters. Name the file plainly; do not lead with "this file contains".
2. **## Why It Matters** — what makes this file load-bearing. Reference its fan-in (how many other files depend on it) and what would break if it were removed or changed carelessly.
3. **## What It Provides** — the public surface: exported functions, classes, types, constants. One short paragraph each, in the order someone reading the file would encounter them. Use wikilinks sparingly here — this section is about this file, not its neighbors.
4. **## Who Uses It** — the files and components that depend on this one. Group by their role (handlers, models, services) rather than listing every importer. Use wikilinks for files that have their own reference pages.
5. **## Caveats** — singletons, hidden global state, side effects, initialization order requirements. Anything that surprises someone reading this file for the first time. Omit if truly none.
6. **## Related Pages** — wikilinks to the architectural concepts this file implements, the flows it participates in, and adjacent reference files.

## Notes

- Reference pages are auto-generated for files with a fan-in at or above the configured threshold (default: 4).
- Keep the page about *this file*, not about the broader system. Higher-level perspective belongs in concept pages and service overviews.
- These pages double as targeted LLM context: someone debugging a specific file should be able to load this page alone and have a usable picture.
