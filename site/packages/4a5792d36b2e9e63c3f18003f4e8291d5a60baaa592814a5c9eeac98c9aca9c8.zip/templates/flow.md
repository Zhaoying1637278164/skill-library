# flow page template

A page describing one end-to-end business flow — what happens from trigger to outcome, which components are involved, where it can fail.

## Section structure

1. **Opening paragraph** — what this flow accomplishes from the user's perspective. Not "this code handles X" but "when a user does X, Y happens because of Z". Self-contained.
2. **## How It Works** — the flow as a connected narrative. Walk through the path from trigger to outcome in prose, not as a numbered list. Mention component names inline; link with wikilinks.
3. **## Step by Step** — when the flow has discrete phases that benefit from sequencing, list them here. Each step is a short paragraph (one to three sentences), not a single line. Prefer the prose narrative in "How It Works" when steps are tightly coupled.
4. **## Failure Cases** — what goes wrong and how the system reacts. Dead-letter queues, retries, fallbacks, error reporting. If the flow has no explicit failure handling, say so plainly.
5. **## Components Involved** — the key files, functions, or services that participate. One short paragraph each. Use wikilinks for components that have reference pages.
6. **## Related Pages** — wikilinks to related flows, architectural concepts, and cross-cutting concerns.

## Notes

- Flow pages are only generated when the user supplies `config.flows`. The clustering step does not invent flows from tags alone.
- A flow page should read as a story. If it reads as a checklist of code references, rewrite it.
