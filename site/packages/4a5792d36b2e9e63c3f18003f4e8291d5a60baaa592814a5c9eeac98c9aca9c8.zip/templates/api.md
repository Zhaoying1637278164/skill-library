# api_index page template

A **single** wiki page that lists every API endpoint the project serves or calls — its synchronous surface, the counterpart to the asynchronous Topics index. One page per project, not one page per endpoint; per-endpoint granularity lives inside this page as Obsidian section anchors.

This collapses what would otherwise be dozens of thin handler pages into one scannable index. Specific endpoints can still be linked via section anchors: `[[API#POST /auth/login]]`, `[[API#GET /users/{id}]]`.

The page captures two sides of every endpoint:
- **handlers** — files in this project that define/serve the endpoint
- **callers** — files that call it. An endpoint with callers but no handler is an **outbound dependency** — the project calls another service. This makes the page double as a cross-service dependency map in multi-project vaults.

## Section structure

1. **Opening paragraph** — one short paragraph naming what the project exposes (a public REST API? internal gRPC? GraphQL gateway?) and which protocols are involved. Note if the project is primarily a client of other services rather than a server. Skip if there are no endpoints.

2. **## Summary table** — every endpoint at a glance, served endpoints first:

   | Endpoint | Kind | Auth | Handler | Callers | Request → Response |
   |----------|------|------|---------|---------|--------------------|
   | POST /auth/login | rest | no | [[authentication.go]] | 2 | LoginRequest → TokenPair |
   | GET /users/{id} | rest | yes | [[users.go]] | 5 | — → User |
   | POST /internal/notify | rest | yes | (external) | 1 | NotifyRequest → — |

   The "Handler" cell is a wikilink for served endpoints, or `(external)` when the project only calls it. "Callers" is a file count in single-project mode and a service count in multi-project mode.

3. **## Outbound Dependencies** (optional) — render this section when the project calls endpoints it does not serve. List the external/other-service endpoints with which file makes the call. This is the project's outbound contract surface.

   | Endpoint | Called from | Purpose |
   |----------|-------------|---------|
   | GET user-service /internal/users/{id} | [[order_handler.go]] | enriches orders with user data |

4. **## Endpoints** — per-endpoint detail, one H3 (`###`) per endpoint that needs discussion. Heading text is the method + path (e.g. `### POST /auth/login`) so it becomes a stable anchor. Each section has a short paragraph (what it does), followed by:
   - **Handler:** wikilink to the serving file (omit for external endpoints)
   - **Callers:** wikilinks to caller files (or service names in multi-project)
   - **Auth:** whether authentication is required, and which guard/scope if known
   - **Request / Response:** the types carried, if visible
   - **Status codes:** notable codes returned, if known
   - **Notes:** anything unusual — missing auth on a sensitive route, no input validation, deprecated, rate-limited, etc. Omit when empty.

   Reserve H3 sections for endpoints that deserve discussion; pure table rows are fine for the rest. Order by importance: public/auth-sensitive endpoints first, or group by resource.

5. **## Caveats** (optional) — observations spanning many endpoints, e.g. *"no endpoint validates request bodies — bad input reaches handlers"* or *"auth is enforced per-handler rather than via shared middleware, so it is easy to forget"*.

6. **## Related Pages** — wikilinks to the HTTP API Layer architecture concept page, reference pages for central handler/router files, relevant flows, the Topics page (async counterpart), and the Permissions page if one exists.

## Notes

- The page title is always `API` (not parameterized — one index per project).
- Front matter `type: api_index`.
- If there are zero API endpoints in the project, no page is produced (the clustering step skips the category entirely).
- Tags should include `api`, the dominant protocol (`rest`, `graphql`, `grpc`), and `index`.
- Each endpoint's H3 heading becomes an Obsidian anchor, so `[[API#POST /auth/login]]` works from other pages. Keep the heading exactly `METHOD /path` for stable anchors.
- Flag auth-sensitive observations plainly — an endpoint that mutates data with `authRequired: false` is worth a Note, the same way the Configuration page flags hardcoded secrets.
