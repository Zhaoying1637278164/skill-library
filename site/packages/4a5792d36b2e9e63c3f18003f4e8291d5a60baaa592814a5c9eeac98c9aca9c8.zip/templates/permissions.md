# permission_index page template

A **single** wiki page that catalogs the project's authorization surface: RBAC roles, auth scopes, and permission strings. This is an audit counterpart to the secret catalog on the Configuration page — one place to see every role and scope, where it is declared, and where it guards access.

Specific permissions are addressable via Obsidian section anchors: `[[Permissions#admin]]`, `[[Permissions#orders:write]]`.

## Section structure

The page is organized by **kind**. Skip any section whose kind has no entries.

1. **Opening paragraph** — one paragraph on how authorization works in the project: middleware guards? decorator-based scopes? a central RBAC table? Note where enforcement actually happens.

2. **## Roles** — coarse-grained roles:

   | Role | Defined in | Guards |
   |------|------------|--------|
   | admin | [[rbac.go]] | [[user_handler.go]], [[settings_handler.go]] |
   | viewer | [[rbac.go]] | (read endpoints) |

3. **## Scopes** — fine-grained scopes/permissions enforced on routes:

   | Scope | Defined in | Guards |
   |-------|------------|--------|
   | orders:write | [[scopes.go]] | [[order_handler.go]] |
   | orders:read | [[scopes.go]] | [[order_handler.go]] |

4. **## Permission Strings** (optional) — ad-hoc permission checks not part of a formal scope system.

5. **## Caveats** (optional) — security-relevant observations: a role declared but never enforced (dead permission), an endpoint that mutates data without any guard, enforcement duplicated inconsistently across handlers. Flag these plainly, the same way the Configuration page flags secret issues.

6. **## Related Pages** — wikilinks to the API page (cross-link which endpoint requires which permission, e.g. `[[API#POST /orders]]`), the Authentication & Authorization architecture concept page, and relevant reference pages.

## Notes

- The page title is always `Permissions`.
- Front matter `type: permission_index`.
- If the project declares no roles, scopes, or permission strings, the page is not produced.
- This is an audit surface — prefer completeness. A role with definers but no guards (or vice versa) is itself worth noting.
- Tags should include `authorization`, `security`, `rbac`, and `index`.
- Each permission's H3 heading becomes an Obsidian anchor, so `[[Permissions#admin]]` works from other pages.
