# concept page template

A page describing one architectural concept — a recurring pattern or abstraction that appears across the codebase (e.g. "JWT Authentication", "Data Layer", "Middleware").

## Section structure

1. **Opening paragraph** — what this concept is and what problem it solves in this project. A reader who knows the general idea of, say, JWT should learn how this codebase uses it specifically. A reader who does not should be able to grasp the basics from this paragraph.
2. **## What Is It** — define the concept clearly. Brief background on the underlying idea (one paragraph), then transition to how this project uses it.
3. **## Role in the Platform** — where this concept fits architecturally. What other parts of the system depend on it. What problems it solves here that justify its existence.
4. **## How It Works** — the mechanics, in prose. Mention the key functions, structs, or types that implement the concept. Link with wikilinks where reference pages exist. Avoid pseudocode; describe the flow in plain language.
5. **## Where It's Used** — the parts of the codebase that depend on this concept. One short paragraph per area; cluster related files together rather than listing every one.
6. **## Caveats** — known limitations, deliberate trade-offs, things that surprise readers. If there are none, omit the section.
7. **## Related Pages** — wikilinks to flows that exercise this concept, related architectural concepts, and reference pages for key files.

## Notes

- Concept pages are auto-generated from tag co-occurrence patterns in file summaries. The page-writer is responsible for turning that mechanical clustering into a coherent narrative.
- A concept page should be useful as standalone LLM context — someone retrieving this page should be able to reason about the concept without also retrieving the source files.
