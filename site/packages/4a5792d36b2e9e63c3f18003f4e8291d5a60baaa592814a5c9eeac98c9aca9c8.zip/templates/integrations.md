# integration_index page template

A **single** wiki page that catalogs every external system the project depends on: third-party SaaS, other internal services, notable libraries, and infrastructure (databases, caches, brokers). This is the project's outbound dependency surface — "what does this talk to, and why?"

Specific systems are addressable via Obsidian section anchors: `[[Integrations#Stripe]]`, `[[Integrations#user-service]]`.

## Section structure

The page is organized by **kind**. Skip any section whose kind has no entries.

1. **Opening paragraph** — one paragraph naming the project's main external dependencies and the shape of them (mostly SaaS APIs? a mesh of internal services? heavy infra?).

2. **## Third-Party Services** — SaaS the project calls:

   | System | Via | Used by | Purpose |
   |--------|-----|---------|---------|
   | Stripe | stripe-go SDK | [[payment.go]] | payment processing |
   | SendGrid | HTTP API | [[mailer.go]] | transactional email |

3. **## Internal Services** — other services in the org the project calls. Include the base URL (credential-redacted) when known. In multi-project vaults this section links services together.

   | Service | Via | Used by | Purpose |
   |---------|-----|---------|---------|
   | user-service | HTTP /internal | [[order_handler.go]] | enrich orders with user data |

4. **## Infrastructure** (optional) — databases, caches, message brokers the project connects to.

5. **## Libraries** (optional) — notable non-trivial libraries worth documenting (not every import — the ones that shape architecture).

6. **## Caveats** (optional) — cross-cutting observations: a SaaS with no timeout/retry, a hardcoded internal URL, a dependency only one file knows how to talk to.

7. **## Related Pages** — wikilinks to the API page (outbound calls overlap), the Configuration page (integration credentials live there — cross-link e.g. Stripe to `[[Configuration#STRIPE_SECRET_KEY]]`), and relevant architecture concepts.

## Notes

- The page title is always `Integrations`.
- Front matter `type: integration_index`.
- If the project has no detected external dependencies, the page is not produced.
- Cross-link credentials to the Configuration page rather than restating them, and never paste a real secret here.
- Tags should include `integrations`, `dependencies`, and `index`.
- Each system's H3 heading becomes an Obsidian anchor, so `[[Integrations#Stripe]]` works from other pages.
