# cross_cutting page template

A page describing one cross-cutting concern — something that touches many parts of the codebase without belonging to any single layer (e.g. logging, error tracking, observability, containerization).

## Section structure

1. **Opening paragraph** — what this concern is and why it cuts across the system. Set up the rest of the page in two or three sentences.
2. **## Purpose** — what problem this addresses across the platform. Why it can't be localized to one component.
3. **## Where It's Used** — the parts of the codebase that participate. Cluster by service or layer rather than listing every file. Use wikilinks where reference pages exist.
4. **## Configuration** — how this concern is initialized, configured, or tuned. Environment variables, config files, central setup functions. If centralized config exists, point at it; if it's scattered, say so.
5. **## What It Collects / Provides** — for monitoring concerns: what metrics, traces, or logs are produced. For infrastructure concerns: what guarantees or facilities are made available. Concrete examples are valuable here.
6. **## Caveats** — gotchas, missing pieces, deliberately unhandled cases. Omit if none.
7. **## Related Pages** — wikilinks to related concerns, the architectural concepts that depend on this, and key reference files.

## Notes

- Cross-cutting pages are auto-generated from tag patterns. The clustering step picks tags that appear across files in many otherwise-unrelated areas.
- Keep these pages focused on the concern itself, not on individual integrations — those belong in the corresponding service or concept pages.
