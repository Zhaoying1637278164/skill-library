# data_model_index page template

A **single** wiki page that catalogs every persistent data structure in the project: database tables, ORM models, DTOs, and enums. One page per project, not one page per model — a service with 40 models gets one index, not 40 thin pages.

Specific entities are addressable via Obsidian section anchors: `[[Data Model#User]]`, `[[Data Model#OrderLineItem]]`.

## Section structure

The page is organized by **kind**. Each kind is a top-level section with its own table and optional per-entity detail. Skip any section whose kind has no entries.

1. **Opening paragraph** — one paragraph on how the project models data overall: which ORM or driver, whether tables map 1:1 to models, where DTOs sit relative to persistence. Lead with the domain, not the framework.

2. **## Tables** / **## Models** — the core persisted entities:

   | Entity | Defined in | Fields | Relations |
   |--------|------------|--------|-----------|
   | User | [[user.go]] | id, email, password_hash | hasMany Order |
   | Order | [[order.go]] | id, user_id, total | belongsTo User, hasMany OrderLineItem |

   For entities with notable structure (large field sets, polymorphic relations, soft-delete semantics), add a per-entity H3 (`### User`) with a paragraph below the table. Most entities need only a row.

3. **## DTOs** (optional) — request/response or transfer structures that are not persisted, when the project has a meaningful DTO layer.

4. **## Enums** (optional) — named enumerations and their values.

5. **## Relationships** (optional) — a short prose or table summary of the entity graph (who owns whom), useful when the model set is large enough that the per-row relations are hard to follow.

6. **## Caveats** (optional) — cross-cutting observations: missing indexes implied by query patterns, models duplicated across services, fields that look like they should be foreign keys but aren't, etc.

7. **## Related Pages** — wikilinks to the Data Layer architecture concept page, reference pages for central model/migration files, the API page (which often exposes these entities), and relevant flows.

## Notes

- The page title is always `Data Model`.
- Front matter `type: data_model_index`.
- If the project defines no shared data entities, the page is not produced.
- `fields` and `relations` are only populated for the file that defines an entity; reader/writer files are surfaced as additional usage context, not as field sources.
- Tags should include `data-model`, the ORM/database if known (`gorm`, `prisma`, `postgres`), and `index`.
- Each entity's H3 heading becomes an Obsidian anchor, so `[[Data Model#User]]` works from other pages.
