# topic_index page template

A **single** wiki page that lists every messaging entity (queue, topic, exchange, channel, stream) in the project. One page per project, not one page per entity — the per-entity granularity lives inside this page as Obsidian section anchors.

This collapses what would otherwise be 5-50 thin pages into one easily-scannable index. Specific entities can still be linked via section anchors: `[[Topics#forgot_password]]`, `[[Topics#user-events (kafka)]]`.

## Section structure

1. **Opening paragraph** — one short paragraph naming what the project uses messaging for and which platforms are involved (RabbitMQ + Kafka, or just SQS, etc.). Skip if there are no topics.

2. **## Summary table** — every entity at a glance:

   | Entity | Kind | Platform | Producers | Consumers | Payload |
   |--------|------|----------|-----------|-----------|---------|
   | forgot_password | queue | RabbitMQ | 1 | 1 | ForgotPasswordMessage |
   | user-events | topic | Kafka | 2 | 4 | UserEvent |
   | order_created | queue | SQS | 1 | 2 | OrderEvent |

   The Producers/Consumers cells are file counts in single-project mode and service counts in multi-project mode.

3. **## Entities** — per-entity detail, one H3 (`###`) per entity. Heading text is the entity name; the kind can be in parentheses if not "topic". Each section contains a short paragraph (purpose), followed by:
   - **Producers:** wikilinks to producer files (or service names in multi-project)
   - **Consumers:** wikilinks to consumer files (or service names)
   - **Payload:** the type or struct carried, if visible
   - **Notes:** anything unusual — dead-letter handling, retry policy, missing acknowledgement, hardcoded queue name leak, etc. Omit when empty.

   Order entities by fan-in (most-used first), or by category if the project has obvious groupings (events vs. commands vs. notifications).

4. **## Caveats** (optional) — observations that apply across many entities, e.g. *"all consumers use auto-ack — message loss is possible"* or *"queue names are duplicated as string literals in multiple files; consider centralizing"*.

5. **## Related Pages** — wikilinks to the messaging architecture concept page, any reference pages for producer/consumer files, and relevant flows.

## Notes

- The page title is always `Topics` (not parameterized — there's one index per project).
- Front matter `type: topic_index`.
- If there are zero messaging entities in the project, no page is produced (the clustering step skips the category entirely).
- Tags should include `messaging`, the dominant platform (`rabbitmq`, `kafka`, `sqs`), and `index`.
- Each entity's H3 heading becomes an Obsidian anchor, so `[[Topics#forgot_password]]` works from other pages.
