# job_index page template

A **single** wiki page that lists every scheduled or background task in the project: cron jobs, queue workers, daemons, and scheduled tasks. One page per project, not one page per job.

Specific jobs are addressable via Obsidian section anchors: `[[Jobs#cleanup-expired-tokens]]`, `[[Jobs#order-fulfillment-worker]]`.

## Section structure

1. **Opening paragraph** — one paragraph on how the project runs background work: an in-process scheduler? a worker pool consuming queues? external cron? Note what kicks the jobs off.

2. **## Summary table** — every job at a glance:

   | Job | Kind | Schedule / Trigger | Defined in | Purpose |
   |-----|------|--------------------|------------|---------|
   | cleanup-expired-tokens | cron | 0 2 * * * | [[scheduler.go]] | deletes expired reset tokens |
   | order-fulfillment-worker | worker | queue: orders | [[worker.go]] | processes placed orders |

   For cron-style jobs use the schedule; for workers/daemons use the trigger (which queue, on startup, etc.).

3. **## Jobs** — per-job detail, one H3 (`###`) per job that needs discussion. Each section has a short paragraph (what it does and why), followed by:
   - **Kind / Schedule:** how and when it runs
   - **Trigger:** what starts it (scheduler, queue message, startup hook)
   - **Defined in:** wikilink to the file
   - **Notes:** anything unusual — no idempotency on a retried worker, overlapping runs not guarded, long-running cron blocking the loop, etc. Omit when empty.

   Reserve H3 sections for jobs that deserve discussion; pure table rows are fine for simple ones.

4. **## Caveats** (optional) — observations spanning many jobs, e.g. *"no job records last-run state, so a missed window is silently skipped"*.

5. **## Related Pages** — wikilinks to the Topics page (queue-triggered workers pair with their topic — cross-link e.g. `[[Topics#orders]]`), relevant reference pages, and the Monitoring concept page if one exists.

## Notes

- The page title is always `Jobs`.
- Front matter `type: job_index`.
- If the project defines no background or scheduled work, the page is not produced.
- For queue-consuming workers, cross-link the topic they consume rather than restating the messaging detail.
- Tags should include `jobs`, `scheduling` or `background`, and `index`.
- Each job's H3 heading becomes an Obsidian anchor, so `[[Jobs#cleanup-expired-tokens]]` works from other pages.
