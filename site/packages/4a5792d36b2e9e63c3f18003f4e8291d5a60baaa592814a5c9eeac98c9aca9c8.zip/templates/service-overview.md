# service_overview page template

A page describing one whole service or project. Used in multi-project setups where each service has an overview page that orients the reader before diving into details.

## Section structure

The page-writer agent should produce these sections in this order. The wording can adapt to the source material — these are the slots, not the literal headings.

1. **Opening paragraph** — what this service does, why it exists, who depends on it. Self-contained: a reader who has never heard of the project should understand the rest of the page after this.
2. **## What It Does** — the service's primary responsibility in one to three paragraphs. Avoid implementation details; focus on behavior and boundaries.
3. **## Architecture** — how the service is structured at a high level. Mention key layers, the framework choice, the runtime model (HTTP server, message consumer, CLI, etc.).
4. **## Key Components** — the most important files or modules, each described in one paragraph. Prefer prose over bullet lists; link with wikilinks where reference pages exist.
5. **## How It Integrates** — what this service consumes (other services, message queues, databases) and what it provides (endpoints, events, public packages).
6. **## Related Pages** — wikilinks to architectural concepts, flows, and reference pages.

## Notes

- This page type is currently produced only when `config.serviceOverview` is supplied or in multi-project mode (Phase 2).
- Single-project setups generally do not need it; the `index.md` MoC page already plays a similar role.
