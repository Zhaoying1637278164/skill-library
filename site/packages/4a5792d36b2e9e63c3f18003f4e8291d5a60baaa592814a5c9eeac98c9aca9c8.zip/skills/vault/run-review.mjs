#!/usr/bin/env node
/**
 * run-review.mjs — Deterministic vault quality check.
 *
 * Usage:
 *   node run-review.mjs <vault-dir> [raw-dir]
 *
 * Outputs review results as JSON. Also writes raw/vault-review.json if raw-dir given.
 */

import { resolve, join } from 'path';
import { fileURLToPath } from 'url';
import { writeFileSync, mkdirSync } from 'fs';

const __dirname   = fileURLToPath(new URL('.', import.meta.url));
const PLUGIN_ROOT = resolve(__dirname, '../..');

const { reviewVault } = await import(`${PLUGIN_ROOT}/packages/core/src/vault-reviewer.mjs`);

const VAULT_DIR = process.argv[2] ? resolve(process.argv[2]) : null;
const RAW_DIR   = process.argv[3] ? resolve(process.argv[3]) : null;

if (!VAULT_DIR) {
  console.error('Usage: run-review.mjs <vault-dir> [raw-dir]');
  process.exit(1);
}

const result = reviewVault(VAULT_DIR);
result.reviewedAt = new Date().toISOString();

// Write to raw/ if provided
if (RAW_DIR) {
  mkdirSync(RAW_DIR, { recursive: true });
  writeFileSync(join(RAW_DIR, 'vault-review.json'), JSON.stringify(result, null, 2));
}

// Summary to stderr (human-readable), JSON to stdout (machine-readable)
process.stderr.write('\n' + result.summary + '\n');

// Strip summary from stdout JSON — it has formatting chars that complicate parsing
const { summary, ...jsonResult } = result;
console.log(JSON.stringify(jsonResult));
