#!/usr/bin/env node
/**
 * run-analyze.mjs — Phase 1: Scan project, detect metadata, write raw/ layer.
 *
 * Usage:
 *   node run-analyze.mjs <project-dir> <raw-dir> [project-name]
 *
 * Output:
 *   raw/<project-name>/scan-result.json    (with frameworks, entryPoints, importMap)
 *   raw/meta.json                          (lastCommitHash updated)
 *
 * Prints JSON to stdout with batches for file-analyzer agents.
 */

import { resolve, basename } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync } from 'fs';

const PLUGIN_ROOT = resolve(fileURLToPath(import.meta.url), '../../..');

const { scanProject }              = await import(`${PLUGIN_ROOT}/packages/core/src/scan.mjs`);
const { detectProjectMetadata }    = await import(`${PLUGIN_ROOT}/packages/core/src/detect-project.mjs`);
const { computeBatches, summarizeBatches } = await import(`${PLUGIN_ROOT}/packages/core/src/compute-batches.mjs`);
const { writeScanResult, writeRelationships, updateProjectMeta } = await import(`${PLUGIN_ROOT}/packages/core/src/write-raw.mjs`);
const { getCurrentHash, detectSubRepos } = await import(`${PLUGIN_ROOT}/packages/core/src/diff-update.mjs`);
const { loadProjectConfig, subRepoOptions } = await import(`${PLUGIN_ROOT}/packages/core/src/project-config.mjs`);

// ── Args ──────────────────────────────────────────────────────────────────────
const PROJECT_ROOT = process.argv[2] ? resolve(process.argv[2]) : resolve('.');
const RAW_DIR      = process.argv[3] ? resolve(process.argv[3]) : resolve(PROJECT_ROOT, 'vault-anything/raw');
const PROJECT_NAME = process.argv[4] ?? basename(PROJECT_ROOT);

mkdirSync(RAW_DIR, { recursive: true });

// ── Scan ──────────────────────────────────────────────────────────────────────
const { files, stats, languages } = scanProject(PROJECT_ROOT);

// ── Detect project metadata (deterministic) ──────────────────────────────────
let scanResult = {
  projectName: PROJECT_NAME,
  projectRoot: PROJECT_ROOT,
  description: '',
  languages,
  frameworks:  [],
  entryPoints: [],
  files,
  importMap:   {},
  stats,
  analyzedAt:  new Date().toISOString(),
};

scanResult = detectProjectMetadata(PROJECT_ROOT, scanResult);

writeScanResult(RAW_DIR, PROJECT_NAME, scanResult);
writeRelationships(RAW_DIR, PROJECT_NAME, []);

// ── Compute batches using detected import map ────────────────────────────────
const batches = computeBatches(files, scanResult.importMap);
const summary = summarizeBatches(batches);

// ── Save commit hash (null if project isn't under git — that's fine) ────────
const hash = getCurrentHash(PROJECT_ROOT);
// When the root isn't a git repo, it may still be a parent holding several
// sub-repos (multi-project run) — flat or grouped under apps/, packages/, etc.
// Detect them (honoring repoRoots/repoMaxDepth config) so we can report
// accurately and record per-repo baselines for incremental updates.
const subRepos = hash
  ? []
  : detectSubRepos(PROJECT_ROOT, subRepoOptions(loadProjectConfig(PROJECT_ROOT)));
updateProjectMeta(RAW_DIR, PROJECT_NAME, hash, subRepos);

// ── Output (parsed by SKILL.md) ───────────────────────────────────────────────
process.stdout.write(JSON.stringify({
  projectName:  PROJECT_NAME,
  projectRoot:  PROJECT_ROOT,
  rawDir:       RAW_DIR,
  files:        files.length,
  languages,
  frameworks:   scanResult.frameworks,
  entryPoints:  scanResult.entryPoints,
  description:  scanResult.description,
  stats,
  batches: batches.map(b => ({
    batchIndex:        b.batchIndex,
    fileCount:         b.files.length,
    totalLines:        b.totalLines,
    files:             b.files,
    importData:        b.importData,
    crossBatchImports: b.crossBatchImports,
  })),
  batchSummary: summary,
  commitHash:   hash,
  subRepos,
}));
