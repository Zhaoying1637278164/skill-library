#!/usr/bin/env node
/**
 * resolve-workspace.mjs — Resolves workspace paths for vault-anything.
 *
 * Usage:
 *   node resolve-workspace.mjs <project-dir> [--workspace <dir>]
 *
 * Prints JSON:
 *   { projectDir, projectName, workspaceDir, rawDir, vaultDir, exists }
 */

import { resolve, basename } from 'path';
import { existsSync } from 'fs';

const args = process.argv.slice(2);

// Parse args
let projectDir = null;
let workspaceDir = null;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--workspace' && args[i + 1]) {
    workspaceDir = resolve(args[++i]);
  } else if (!args[i].startsWith('--')) {
    projectDir = resolve(args[i]);
  }
}

projectDir   = projectDir ?? resolve('.');
const projectName  = basename(projectDir);

// Default workspace: <project>/vault-anything/ (visible, intended to be committed).
workspaceDir = workspaceDir ?? resolve(projectDir, 'vault-anything');

const rawDir       = resolve(workspaceDir, 'raw');
const vaultDir     = resolve(workspaceDir, 'vault');
const metaExists   = existsSync(resolve(rawDir, 'meta.json'));

process.stdout.write(JSON.stringify({
  projectDir,
  projectName,
  workspaceDir,
  rawDir,
  vaultDir,
  exists: metaExists,   // true = vault already analyzed before
}, null, 2));
