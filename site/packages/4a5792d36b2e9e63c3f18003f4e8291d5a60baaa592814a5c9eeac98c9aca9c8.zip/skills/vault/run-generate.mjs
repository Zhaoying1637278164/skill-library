#!/usr/bin/env node
/**
 * run-generate.mjs — Phase 2: Read raw/, cluster concepts, write vault/ skeleton.
 *
 * Usage:
 *   node run-generate.mjs <raw-dir> <vault-dir> <project-name>
 *
 * Output:
 *   vault/.obsidian/
 *   vault/index.md
 *   vault/<category>/<page>.md  (skeleton — page-writer agents fill content)
 *   raw/<project-name>/page-plan.json
 */

import { resolve, join } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync } from 'fs';

const __dirname   = fileURLToPath(new URL('.', import.meta.url));
const PLUGIN_ROOT = resolve(__dirname, '../..');

import { readFileSync, existsSync } from 'fs';

const { clusterConcepts, buildWikilinkMap } = await import(`${PLUGIN_ROOT}/packages/core/src/cluster-concepts.mjs`);
const { initVault, writePage, writeIndex }  = await import(`${PLUGIN_ROOT}/packages/core/src/write-vault.mjs`);
const { readFileSummaries, readUserFileContents, writePagePlan, readMeta } = await import(`${PLUGIN_ROOT}/packages/core/src/write-raw.mjs`);
const { detectSubRepos } = await import(`${PLUGIN_ROOT}/packages/core/src/diff-update.mjs`);
const { loadProjectConfig, subRepoOptions } = await import(`${PLUGIN_ROOT}/packages/core/src/project-config.mjs`);

// ── Args ──────────────────────────────────────────────────────────────────────
const RAW_DIR      = process.argv[2] ? resolve(process.argv[2]) : null;
const VAULT_DIR    = process.argv[3] ? resolve(process.argv[3]) : null;
const PROJECT_NAME = process.argv[4] ?? '';

if (!RAW_DIR || !VAULT_DIR || !PROJECT_NAME) {
  console.error('Usage: run-generate.mjs <raw-dir> <vault-dir> <project-name>');
  process.exit(1);
}

mkdirSync(VAULT_DIR, { recursive: true });

// ── Read raw layer ────────────────────────────────────────────────────────────
const summaries  = readFileSummaries(RAW_DIR, PROJECT_NAME);
const userFiles  = readUserFileContents(RAW_DIR);

// Read scan-result for entry points (used for importance scoring) and the
// project root (used to locate the optional project config file).
let entryPoints = [];
let projectRoot = null;
const scanResultPath = join(RAW_DIR, PROJECT_NAME, 'scan-result.json');
if (existsSync(scanResultPath)) {
  try {
    const scanResult = JSON.parse(readFileSync(scanResultPath, 'utf-8'));
    entryPoints = scanResult.entryPoints ?? [];
    projectRoot = scanResult.projectRoot ?? null;
  } catch {/* ignore */}
}

// Optional project config: `.vault-anything.json` at the project root supplies
// flow definitions and clustering overrides (concepts, crossCutting,
// referenceRatio, maxRefPages) plus sub-repo discovery (repoRoots,
// repoMaxDepth). Absent or malformed → default behavior.
const userConfig = loadProjectConfig(projectRoot);

// ── Cluster into page concepts ────────────────────────────────────────────────
const pages       = clusterConcepts(summaries, { entryPoints, ...userConfig });
const wikilinkMap = buildWikilinkMap(pages);

// ── Write page plan ───────────────────────────────────────────────────────────
writePagePlan(RAW_DIR, PROJECT_NAME, { pages, wikilinkMap, userFiles: userFiles.map(f => f.relPath) });

// ── Write vault skeleton ──────────────────────────────────────────────────────
initVault(VAULT_DIR);

let written = 0;
for (const page of pages) {
  const tags      = [...new Set(page.summaries.flatMap(s => s.tags ?? []))].slice(0, 6);
  const safeTitle = page.title.replace(/[\\/:*?"<>|]/g, '-');

  const content = [
    '---',
    `title: ${page.title}`,
    `tags: [${tags.join(', ')}]`,
    `category: ${page.category}`,
    `type: ${page.type}`,
    `updated: ${new Date().toISOString().slice(0, 10)}`,
    '---',
    '',
    `# ${page.title}`,
    '',
    '> _Skeleton — page-writer agent will fill this content._',
    '',
    '## Source Files',
    '',
    ...page.summaries.slice(0, 8).map(s =>
      `- ${s.filePath}${s.fanIn > 0 ? ` (fan-in: ${s.fanIn})` : ''}`
    ),
  ].join('\n');

  writePage(VAULT_DIR, page.category, safeTitle + '.md', content);
  written++;
}

// Multi-project: list contributing sub-repos (+ analyzed file counts) for the index.
let projects = [];
if (projectRoot) {
  try {
    projects = detectSubRepos(projectRoot, subRepoOptions(userConfig))
      .map(s => ({
        name:      s.name,
        fileCount: summaries.filter(x => (x.filePath || '').startsWith(`${s.name}/`)).length,
      }))
      .filter(p => p.fileCount > 0)
      .sort((a, b) => b.fileCount - a.fileCount);
  } catch {/* sub-repo probing is best-effort */}
}

const meta = readMeta(RAW_DIR);
writeIndex(VAULT_DIR, pages, {
  nodeCount: summaries.length,
  edgeCount: 0,
}, projects);

// ── Output ────────────────────────────────────────────────────────────────────
console.log(JSON.stringify({
  vaultDir:    VAULT_DIR,
  pagesWritten: written,
  categories:  [...new Set(pages.map(p => p.category))],
  pages:       pages.map(p => ({
    id:        p.id,
    title:     p.title,
    category:  p.category,
    type:      p.type,
    fileCount: p.filePaths?.length ?? 0,
    summaries: p.summaries,
  })),
  wikilinkMap,
  userFiles:   userFiles.map(f => f.relPath),
}));
