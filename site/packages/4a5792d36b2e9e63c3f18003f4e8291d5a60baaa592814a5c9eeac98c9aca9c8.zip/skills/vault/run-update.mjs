#!/usr/bin/env node
/**
 * run-update.mjs — Builds an incremental update plan.
 *
 * Usage:
 *   node run-update.mjs <project-dir> <raw-dir> <project-name>
 *
 * Outputs the update plan as JSON so SKILL.md can decide what to re-analyze.
 */

import { resolve, basename } from 'path';
import { fileURLToPath } from 'url';

const __dirname   = fileURLToPath(new URL('.', import.meta.url));
const PLUGIN_ROOT = resolve(__dirname, '../..');

const { buildUpdatePlan, summarizeUpdatePlan } = await import(`${PLUGIN_ROOT}/packages/core/src/diff-update.mjs`);

const PROJECT_ROOT = process.argv[2] ? resolve(process.argv[2]) : resolve('.');
const RAW_DIR      = process.argv[3] ? resolve(process.argv[3]) : null;
const PROJECT_NAME = process.argv[4] ?? basename(PROJECT_ROOT);

if (!RAW_DIR) {
  console.error('Usage: run-update.mjs <project-dir> <raw-dir> <project-name>');
  process.exit(1);
}

const plan = buildUpdatePlan(PROJECT_ROOT, RAW_DIR, PROJECT_NAME);

process.stderr.write(summarizeUpdatePlan(plan) + '\n');
console.log(JSON.stringify(plan));
