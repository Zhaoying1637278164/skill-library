#!/usr/bin/env node
/**
 * resolve-plugin-root.mjs — Finds the vault-anything plugin root.
 *
 * Resolution order (most reliable first):
 *   1. Self-relative — this script lives at <plugin>/skills/vault/, so go up 2 levels.
 *   2. CLAUDE_PLUGIN_ROOT — set by Claude Code when running inside a plugin.
 *   3. Symlinks at common Claude/Copilot skill paths.
 *   4. Common installation paths (version-agnostic glob over plugin cache).
 *
 * Prints the resolved path to stdout. Exits 1 if not found.
 */

import { existsSync, readdirSync } from 'fs';
import { resolve } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const MARKER = '.claude-plugin/plugin.json';

function check(dir) {
  return dir && existsSync(`${dir}/${MARKER}`) ? dir : null;
}

function resolveSymlink(linkPath) {
  try {
    const real = execSync(
      `realpath "${linkPath}" 2>/dev/null || readlink -f "${linkPath}" 2>/dev/null`,
      { encoding: 'utf-8' }
    ).trim();
    return real ? resolve(real, '../..') : null;
  } catch {
    return null;
  }
}

// Find any installed version of vault-anything in Claude's plugin cache.
function findInPluginCache(cacheDir) {
  try {
    if (!existsSync(cacheDir)) return null;
    // cache/vault-anything/vault-anything/<version>/
    const inner = `${cacheDir}/vault-anything/vault-anything`;
    if (!existsSync(inner)) return null;
    const versions = readdirSync(inner).sort().reverse(); // newest first
    for (const v of versions) {
      const candidate = `${inner}/${v}`;
      if (check(candidate)) return candidate;
    }
  } catch {/* ignore */}
  return null;
}

const HOME = process.env.HOME ?? '';

// Self-relative: this script lives at <plugin-root>/skills/vault/resolve-plugin-root.mjs
const SELF = resolve(fileURLToPath(import.meta.url), '../../..');

const candidates = [
  SELF,                                                            // Most reliable
  process.env.CLAUDE_PLUGIN_ROOT,
  resolveSymlink(`${HOME}/.agents/skills/vault`),
  resolveSymlink(`${HOME}/.copilot/skills/vault`),
  findInPluginCache(`${HOME}/.claude/plugins/cache`),
];

const found = candidates.find(c => check(c));

if (!found) {
  process.stderr.write(
    'Error: Cannot find vault-anything plugin root.\n' +
    'Make sure the plugin is installed or run from the plugin directory.\n'
  );
  process.exit(1);
}

process.stdout.write(found);
