---
name: Locale request / contribution
about: Request a new output language or contribute a locale guide
labels: locale
---

## Language

ISO 639-1 code (e.g. `ja` for Japanese, `pt` for Portuguese):

## Are you contributing or requesting?

- [ ] I'm contributing a new locale guide (PR coming).
- [ ] I'm requesting that someone create one.

## Notes

<!--
For contributions:
- Use locales/en.md as the template.
- Translate the prose guidance only; keep the structure.
- Specify that technical terms (JWT, RabbitMQ, etc.) stay in English.

For requests:
- If you have any guidance about idiomatic technical writing in this language, share it here.
- Bonus: link to good technical documentation in that language as reference.
-->
