---
name: Feature request
about: Suggest a new capability or improvement
labels: enhancement
---

## The problem

<!-- What use case isn't well-served today? What did you want to do and couldn't, or what was awkward? -->

## Proposed solution

<!-- Your idea for how this could work. If you've thought about the API or UX, describe it. -->

## Alternatives considered

<!-- Other ways this could be addressed, if any. -->

## Additional context

<!-- Examples, links to similar features in other tools, screenshots, etc. -->
