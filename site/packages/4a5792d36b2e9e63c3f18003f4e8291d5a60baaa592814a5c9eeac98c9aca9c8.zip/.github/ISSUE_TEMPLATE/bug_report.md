---
name: Bug report
about: Something didn't work the way you expected
labels: bug
---

## What happened

<!-- A clear description of what went wrong. -->

## What you expected

<!-- What you expected to happen instead. -->

## How to reproduce

1.
2.
3.

## Environment

- vault-anything version:
- Claude Code version:
- Node version (`node --version`):
- OS:
- Project type analyzed (Go / Node / Python / etc.):

## Logs / output

<!-- Paste the relevant Claude Code output, including any error messages. -->

```
```

## Additional context

<!-- Anything else that might help. -->
