## What this PR does

<!-- One or two sentences describing the change. -->

## Why

<!-- The problem this solves, or the use case it enables. Reference the issue if there is one. -->

Closes #

## Type of change

- [ ] Bug fix
- [ ] New feature (page type, locale, runner script, etc.)
- [ ] Documentation
- [ ] Refactor / internal improvement
- [ ] Other:

## Testing

<!--
For changes that affect the pipeline:
- Which project did you run it on?
- What did the vault output look like (page count, categories)?
- Did `node packages/core/src/...` smoke-test pass?

For doc-only changes: how did you verify accuracy?
-->

## Checklist

- [ ] Updated `CHANGELOG.md` under `## [Unreleased]`
- [ ] Updated `README.md` if user-facing behavior changed
- [ ] Updated relevant `agents/*.md` or `templates/*.md` if schema changed
- [ ] No backticks or code blocks in any generated wiki content (I tested or this is a code-only change)
