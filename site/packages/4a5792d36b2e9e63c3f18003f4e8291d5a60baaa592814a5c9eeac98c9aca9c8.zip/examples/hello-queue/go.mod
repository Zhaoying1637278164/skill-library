module example.com/hello-queue

go 1.22

require github.com/streadway/amqp v1.0.0
