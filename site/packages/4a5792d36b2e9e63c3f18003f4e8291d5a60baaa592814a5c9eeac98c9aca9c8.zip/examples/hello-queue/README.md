# hello-queue

A minimal Go demo project used to exercise vault-anything end-to-end.

It does one thing: receive `order_created` events from a RabbitMQ queue and log them. It exists so you can run `/vault-anything:vault examples/hello-queue` in a fresh Claude Code session and see a realistic small vault — concept pages, a Topics index page listing the queue, and reference pages for the most important files — without needing a real project to hand.

## Structure

- `cmd/main.go` — entry point. Bootstraps the queue connection and starts the consumer.
- `internal/queue/conn.go` — shared RabbitMQ connection singleton.
- `internal/queue/consumer.go` — consumes the `order_created` queue, hands each message to the handler.
- `internal/handler/order.go` — business logic: validate and log the order event.

This is intentionally tiny (4 files) so analysis is fast.
