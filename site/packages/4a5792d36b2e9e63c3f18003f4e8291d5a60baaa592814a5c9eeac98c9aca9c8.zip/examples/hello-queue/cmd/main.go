// Entry point for hello-queue. Connects to RabbitMQ and starts the order consumer.
package main

import (
	"log"

	"example.com/hello-queue/internal/queue"
)

func main() {
	if err := queue.Connect(); err != nil {
		log.Fatalf("connect: %v", err)
	}
	defer queue.Close()

	log.Println("hello-queue starting; consuming order_created")
	if err := queue.ConsumeOrders(); err != nil {
		log.Fatalf("consume: %v", err)
	}
}
