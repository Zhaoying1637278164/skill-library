// Order event handler — the business logic of hello-queue.
package handler

import "log"

// OrderEvent is the payload carried by the order_created queue.
type OrderEvent struct {
	OrderID    string  `json:"order_id"`
	CustomerID string  `json:"customer_id"`
	Total      float64 `json:"total"`
}

// HandleOrder validates and logs an order. In a real service this would
// persist the order, notify downstream systems, etc.
func HandleOrder(e OrderEvent) {
	if e.OrderID == "" || e.CustomerID == "" {
		log.Printf("rejecting incomplete order: %+v", e)
		return
	}
	log.Printf("received order %s for customer %s (total: %.2f)",
		e.OrderID, e.CustomerID, e.Total)
}
