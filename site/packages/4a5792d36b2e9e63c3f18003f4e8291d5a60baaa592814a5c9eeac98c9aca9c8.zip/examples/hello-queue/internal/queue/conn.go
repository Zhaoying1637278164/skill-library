// Shared RabbitMQ connection singleton.
package queue

import (
	"os"

	"github.com/streadway/amqp"
)

var conn *amqp.Connection

// Connect opens a connection to the broker using AMQP_URL.
func Connect() error {
	url := os.Getenv("AMQP_URL")
	if url == "" {
		url = "amqp://guest:guest@localhost:5672/"
	}
	c, err := amqp.Dial(url)
	if err != nil {
		return err
	}
	conn = c
	return nil
}

// Close terminates the shared connection.
func Close() {
	if conn != nil {
		_ = conn.Close()
	}
}

// Channel returns a new channel on the shared connection.
func Channel() (*amqp.Channel, error) {
	return conn.Channel()
}
