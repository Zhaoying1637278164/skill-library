// Consumer for the order_created queue.
package queue

import (
	"encoding/json"
	"log"

	"example.com/hello-queue/internal/handler"
)

const orderQueueName = "order_created"

// ConsumeOrders subscribes to the order_created queue and dispatches each
// message to the order handler. Auto-ack for simplicity.
func ConsumeOrders() error {
	ch, err := Channel()
	if err != nil {
		return err
	}
	defer ch.Close()

	q, err := ch.QueueDeclare(orderQueueName, true, false, false, false, nil)
	if err != nil {
		return err
	}

	msgs, err := ch.Consume(q.Name, "", true, false, false, false, nil)
	if err != nil {
		return err
	}

	for m := range msgs {
		var event handler.OrderEvent
		if err := json.Unmarshal(m.Body, &event); err != nil {
			log.Printf("invalid payload: %v", err)
			continue
		}
		handler.HandleOrder(event)
	}
	return nil
}
