# Examples

Demo projects used to exercise vault-anything end-to-end. Useful as smoke tests after changes, and as a quick way for new users to see what the plugin produces.

## hello-queue

A minimal Go RabbitMQ consumer (4 source files). Run:

```
/vault-anything:vault /path/to/vault-anything/examples/hello-queue
```

Expected output:
- 1 architecture concept page (Messaging & Events)
- 1 reference page (the connection singleton and possibly the consumer)
- 1 Topics index page (`06-Topics/Topics.md`) listing the `order_created` queue as a row

This is intentionally tiny — useful for verifying the pipeline works without spending tokens on a real codebase.
