# Contributing to vault-anything

Thanks for considering a contribution. This guide explains how the project is structured and what kinds of changes are most welcome.

## Project Layout

vault-anything is a Claude Code plugin. The pieces fit together like this:

- **`skills/<skill>/SKILL.md`** — the user-facing commands (`/vault-anything:vault`, `/vault-anything:vault-update`). These describe the high-level pipeline Claude follows.
- **`skills/<skill>/run-*.mjs`** — Node CLI scripts that do the deterministic work (scan, cluster, review, diff). Called by the SKILL.md via shell commands.
- **`agents/*.md`** — definitions for subagents (`file-analyzer`, `page-writer`) that Claude dispatches via the Agent tool.
- **`packages/core/src/*.mjs`** — reusable modules imported by the runner scripts.
- **`templates/<type>.md`** — section structure for each page type, used by the page-writer agent.
- **`locales/<code>.md`** — writing-style guides per language.

See `README.md` for the user-facing pipeline; see [Claude Code plugin docs](https://code.claude.com/docs/en/plugins.md) for the underlying conventions.

## Setting Up for Development

```bash
git clone https://github.com/burakolgun/vault-anything
cd vault-anything
pnpm install
```

To test locally, point Claude Code at your working copy:

```bash
claude --plugin-dir /path/to/your/vault-anything
```

Then inside Claude Code:

```
/vault-anything:vault /path/to/some/project
```

Changes to `.mjs` files take effect immediately. Changes to `SKILL.md` are picked up on a session reload (`/reload-plugins`).

## Types of Contributions

### Bug fixes

If something doesn't work, please open an issue first describing what you observed versus what you expected. Include the Node version, OS, and the commands you ran.

### New locales

Adding a writing guide for a new language is straightforward:

1. Copy `locales/en.md` to `locales/<code>.md` (use ISO 639-1 codes: `de`, `es`, `ja`, etc.).
2. Translate the prose guidance, keeping the structure intact.
3. Keep technical terms in English (JWT, RabbitMQ, etc.) — the guide should specify this for the target language.
4. Test with: `/vault-anything:vault <project> --lang <code>`.

### New page types

The current types are `flow`, `concept`, `cross_cutting`, `reference`, `service_overview`, and seven single-page indexes: `api_index`, `topic_index`, `config_index`, `data_model_index`, `integration_index`, `job_index`, `permission_index`.

Adding a new page type requires:

1. A template at `templates/<type>.md` describing the section structure.
2. Clustering logic in `packages/core/src/cluster-concepts.mjs` to decide when this type is produced and what data it carries.
3. Registering the type (and its dispatch payload field) in `agents/page-writer.md`.
4. Loading the new template in `skills/vault/SKILL.md` Phase 4 and `skills/vault-update/SKILL.md` Phase 4.
5. Documenting the new category in `README.md` and `CHANGELOG.md`.

If the new type is an **entity index** — many named entities (endpoints, models, jobs, ...) folded into one page — don't write a bespoke clustering function. Use the generic `clusterEntityIndex(summaries, opts)` helper in `cluster-concepts.mjs`: supply `field`, `keyOf`, `roleBuckets` (use `['*']` to collect every occurrence regardless of role), optional `initExtra`/`mergeExtra` for extra fields, and `toRow`/`toPage` builders. The existing index types are all ~25-line config objects over this helper and serve as templates. Also add the corresponding field to `agents/file-analyzer.md` so the analyzer emits it.

### Improvements to the runner scripts

The `packages/core/src/` modules are plain ESM, no build step. Keep them dependency-free where possible — they should run anywhere Node 18+ runs.

## Coding Style

- ESM only (`.mjs`, top-level `await` is fine).
- No external runtime dependencies in `packages/core/src/` unless absolutely necessary. Standard library is preferred.
- Two-space indentation, single quotes, trailing semicolons.
- Use `set -e` in any shell snippet inside SKILL.md.
- All user-visible strings in English. Localization happens at the page-writer agent level, not in the plugin's own output.

## Commit Messages

Conventional commits are preferred but not required. Keep the subject line under 72 characters and use the body to explain the why.

```
feat(cluster): support user-provided flow definitions

Closes #N
```

## Pull Requests

- Open a draft PR if you want feedback on direction before polishing.
- One conceptual change per PR. Multiple unrelated fixes are easier to review when split up.
- Include a description of what changed and why. Reference the issue if there is one.
- For changes that affect the pipeline (`run-*.mjs` outputs or SKILL.md flow), include a manual test transcript: which project you ran it on, what you observed.

## Issues

When reporting a bug or requesting a feature, please include:

- For bugs: the project type you were analyzing (Go, Node, Python, ...), the exact command, what happened, what you expected.
- For features: a short description of the use case and what the ideal behavior looks like.

## License

By contributing, you agree your contributions are licensed under the MIT License (see `LICENSE`).
