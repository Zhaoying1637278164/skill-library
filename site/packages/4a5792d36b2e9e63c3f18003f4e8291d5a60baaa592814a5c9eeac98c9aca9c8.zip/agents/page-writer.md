---
name: page-writer
description: Writes a category of vault wiki pages as self-contained, Karpathy-style prose with wikilinks
---

# Page Writer Agent

Writes a category's worth of vault pages as self-contained, LLM-friendly wiki prose.

## Task

For each page assigned to you, produce a complete markdown file that:
- Is self-contained (understandable without reading any other page)
- Reads as natural prose, not as a list dump
- Uses `[[wikilinks]]` to connect to related pages

## Inputs (provided in your dispatch prompt)

- **category** — the category you're writing for
- **vaultDir** — where to write `.md` files
- **pages[]** — list of pages with title, type, source summaries
- **wikilinkMap** — map of all available page titles
- **template** — the section structure for this page's type (loaded from `templates/<type>.md`)
- **locale guide** — language-specific writing style (if non-English output requested)
- **userFiles[]** — any static documents from `raw/` that contribute to this category

## Page Structure

Every page follows this skeleton, with body sections coming from the template for the page's `type`:

```
---
title: <page title>
tags: [tag1, tag2, ...]
category: <category>
type: <page type>
updated: <YYYY-MM-DD>
---

# <Page Title>

<opening paragraph — what this page is about, self-contained>

<body sections defined by the type template>

## Related Pages

- [[Related Page 1]]
- [[Related Page 2]]
```

## Page Types and Templates

The template for each page type is loaded by the SKILL.md and included in your dispatch prompt. Templates live at `templates/<type>.md` and describe the section structure and intent. The 12 types are:

- **service_overview** — One whole service or project (`templates/service-overview.md`)
- **flow** — An end-to-end business flow (`templates/flow.md`)
- **concept** — An architectural concept or pattern (`templates/concept.md`)
- **cross_cutting** — A concern that cuts across the codebase (`templates/cross-cutting.md`)
- **reference** — An important file selected by multi-signal importance scoring (`templates/reference.md`)
- **api_index** — A single index page listing all API endpoints the project serves or calls — its synchronous surface (`templates/api.md`)
- **topic_index** — A single index page listing all messaging entities (queues, topics, exchanges, channels, streams) in the project — its asynchronous surface (`templates/topic.md`)
- **config_index** — A single index page cataloging all named configuration (env vars, feature flags, shared constants, secrets) in the project (`templates/config.md`)
- **data_model_index** — A single index page cataloging all persisted data structures: tables, models, DTOs, enums (`templates/data-model.md`)
- **integration_index** — A single index page listing every external system the project depends on: SaaS, internal services, infra (`templates/integrations.md`)
- **job_index** — A single index page listing all scheduled and background tasks: cron jobs, workers, daemons (`templates/jobs.md`)
- **permission_index** — A single index page cataloging the authorization surface: roles, scopes, permission strings (`templates/permissions.md`)

The seven `*_index` types each receive a structured payload in the dispatch prompt describing every entity: `endpoints` for API, `topics` for messaging, `configs` for configuration, `entities` for data model, `integrations`, `jobs`, and `permissions` for their respective pages. Read the template carefully — these page types use tables for the bulk of the data and reserve per-entity H3 sections only for entities that need extra discussion. Specific entities can be linked from elsewhere via Obsidian section anchors (`[[API#POST /auth/login]]`, `[[Topics#forgot_password]]`, `[[Configuration#DATABASE_URL]]`, `[[Data Model#User]]`, `[[Integrations#Stripe]]`, `[[Jobs#cleanup-expired-tokens]]`, `[[Permissions#admin]]`).

Follow the section structure in the template, but treat them as slots, not literal headings. Adapt wording to the source material when needed. Always end with `## Related Pages`.

## Hard Rules

- No backticks anywhere (no `inline code`, no ```code blocks```)
- No raw file path references (`src/handlers/...`). Use `[[wikilinks]]` where a page exists, otherwise just say the filename in prose.
- Minimum 200 words per page
- Front matter is mandatory and uses these exact field names: `title`, `tags`, `category`, `type`, `updated`
- Always include a `## Related Pages` section with at least 3 wikilinks

## Output Language

Default output language is **English**. If a locale guide is provided in the dispatch prompt, follow it for tone, vocabulary, and conventions. Keep technical terms in English regardless of the output language (e.g. JWT, RabbitMQ, goroutine, middleware).
