---
layout: default
title: Privacy
description: How vault-anything handles your data.
permalink: /privacy/
---

# Privacy

vault-anything is a Claude Code plugin that runs **entirely on your machine**.

## What it does with your data

- **Reads** your local source files and any static documents you place under `raw/`.
- **Writes** the generated wiki to a local `vault/` directory in your workspace.

Output stays on disk, in your project, under your control.

## What it does not do

- No telemetry, analytics, or usage tracking.
- No network calls of its own — it has no backend, no servers, and no accounts.
- It does not collect, store, or transmit your code or documents anywhere.

## Code analysis and Claude

vault-anything builds its pages using Claude Code's own subagents (`file-analyzer` and `page-writer`). When you run it, the contents of the files being analyzed are sent to the Claude model **through Claude Code**, exactly as with any other Claude Code task. That processing is governed by [Anthropic's privacy policy and usage terms](https://www.anthropic.com/legal/privacy) — not by this plugin. The plugin itself adds no separate data collection.

## Secrets

Because the generated vault is meant to be committed, vault-anything actively **redacts secrets**: the analyzer never writes real credential values into the vault, and the reviewer flags any high-confidence credential pattern as a hard issue.

## Contact

Questions or concerns: [open an issue](https://github.com/burakolgun/vault-anything/issues).

_Last updated: 2026-06-01._
