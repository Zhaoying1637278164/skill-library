<div class="badges" markdown="1">
[![Release](https://img.shields.io/github/v/release/burakolgun/vault-anything?color=157878&label=release)](https://github.com/burakolgun/vault-anything/releases)
[![License](https://img.shields.io/github/license/burakolgun/vault-anything?color=157878)](https://github.com/burakolgun/vault-anything/blob/main/LICENSE)
![Claude Code plugin](https://img.shields.io/badge/Claude%20Code-plugin-157878)
![Node](https://img.shields.io/badge/node-%E2%89%A518-157878)
</div>

<p class="lead">Point Claude Code at a codebase and get back a self-contained, cross-linked Obsidian wiki — one that reads well for humans <em>and</em> drops straight into an LLM's context window.</p>

Inspired by Andrej Karpathy's idea of a "wiki for LLMs," vault-anything distills a project (and optionally its meeting notes, PRDs, and ADRs) into prose pages: architecture, APIs, data model, configuration, jobs, and more — each page independently readable and richly wikilinked.

## What you get

<div class="features">
  <div class="card">
    <h3>Structured, not dumped</h3>
    <p>Architecture concepts, cross-cutting concerns, importance-ranked references, plus single-page indexes for API, Topics, Config, Data Model, Integrations, Jobs, and Permissions.</p>
  </div>
  <div class="card">
    <h3>Cross-service bridges</h3>
    <p>Point it at a folder of repos for one combined vault. One service's endpoint and another's caller land on the same page — the API and Topics indexes become a dependency map.</p>
  </div>
  <div class="card">
    <h3>Git-aware updates</h3>
    <p>vault-update diffs committed and uncommitted changes (per sub-repo) and rewrites only the pages that reference what changed.</p>
  </div>
  <div class="card">
    <h3>Secret-safe by design</h3>
    <p>The reviewer flags credential patterns and the analyzer redacts real values — the vault is meant to be committed, so secrets never land in it.</p>
  </div>
  <div class="card">
    <h3>Config-driven</h3>
    <p>A tiny <code>.vault-anything.json</code> adds business-flow pages and tunes clustering. No config needed for sensible defaults.</p>
  </div>
  <div class="card">
    <h3>Obsidian-native</h3>
    <p>Ships an <code>.obsidian/</code> config with graph view and tags enabled. Open the vault folder and start navigating.</p>
  </div>
</div>

## See it in action

Run on a small Go messaging service, vault-anything produces:

```text
vault/
├── index.md                      # Map of Content (+ Projects table for multi-repo)
├── 02-Architecture/
│   ├── Messaging & Events.md
│   └── Email & Notifications.md
├── 04-Reference/
│   ├── rabbit_mq.go.md
│   └── mail_sender.go.md
└── 06-Topics/
    └── Topics.md
```

…where `Topics.md` is a single scannable index rather than dozens of thin pages:

| Entity | Kind | Platform | Producers | Consumers | Payload |
|--------|------|----------|-----------|-----------|---------|
| forgot_password | queue | RabbitMQ | 1 | 1 | reset-token JSON |
| user_activation | queue | RabbitMQ | 1 | 1 | activation JSON |
| forgot_password_fail | queue (DLQ) | RabbitMQ | 1 | 0 | failed message |

Specific entities stay addressable from any page via Obsidian anchors — `[[Topics#forgot_password]]`.

## Quickstart

Not on a plugin marketplace yet — clone and point Claude Code at it:

```bash
git clone https://github.com/burakolgun/vault-anything.git
claude --plugin-dir ./vault-anything
```

Then, inside any project:

```text
/vault-anything:vault            # generate the vault
/vault-anything:vault-update     # refresh it after code changes
```

## The categories

| | |
|---|---|
| **01 · Flows** | End-to-end business flows (opt-in via config) |
| **02 · Architecture** | Concept pages derived from tag patterns |
| **03 · Cross-Cutting** | Monitoring, security, CI/CD, error handling |
| **04 · Reference** | The most load-bearing files, importance-ranked |
| **05 · API** | Endpoints served and called — the synchronous surface |
| **06 · Topics** | Queues, topics, exchanges — the asynchronous surface |
| **07 · Config** | Env vars, flags, constants, secrets (redacted) |
| **08 · Data Model** | Tables, models, DTOs, enums with relations |
| **09 · Integrations** | Third-party SaaS, internal services, infra |
| **10 · Jobs** | Cron jobs, workers, scheduled tasks |
| **11 · Permissions** | RBAC roles, scopes, permission strings |

## Learn more

- [Full README &amp; usage guide](https://github.com/burakolgun/vault-anything#readme)
- [Configuration — `.vault-anything.json`](https://github.com/burakolgun/vault-anything#configuration)
- [Multi-project vaults](https://github.com/burakolgun/vault-anything#multi-project-a-parent-of-several-repos)
- [Releases](https://github.com/burakolgun/vault-anything/releases) · [Issues](https://github.com/burakolgun/vault-anything/issues)

---

MIT licensed · [Privacy](privacy/) · built as a [Claude Code](https://claude.com/product/claude-code) plugin.
