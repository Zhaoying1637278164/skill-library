# French Writing Guide

Writing style for page-writer agents when output language is `fr`.

## Language Rules

- Prose is **French**, neutral technical tone
- Technical terms stay in their conventional English form: JWT, RabbitMQ, GORM, goroutine, middleware, barrel, styled-components, context API, hook, singleton, fan-in, dead-letter queue, fanout exchange
- Common French equivalents are acceptable: *dépendance*, *couche*, *composant*, *service*, *flux*, *file d'attente*

## Page Structure

Every page must be **self-contained**: a first-time reader should understand it without jumping to any other page.

### Opening Paragraph
- 2-4 sentences in French
- Frame as *"X est utilisé pour résoudre Y en faisant Z"* — not *"Ce fichier fait X"*
- State why it exists, not just what it is

### Body Sections
- Prefer `##` headers, use `###` sparingly
- Minimize bullet lists — embed information in flowing French prose
- Use tables only for genuine comparisons

## Wikilinks

- Page titles verbatim: `[[JWT Authentication]]`, `[[Admin API (Go)]]` (page titles stay in English)
- For file references, prefer wikilinks when the page exists, otherwise just say the filename in prose
- No backticks anywhere
- Function and class names go in plain text: *TokenVerifyMiddleware*, *GenerateToken*

## What to Avoid

- ❌ "Ce fichier contient X" → ✅ "X est utilisé pour Y"
- ❌ Backticks: `fonction()` → ✅ plain text: fonction
- ❌ Code blocks → ✅ prose explanation
- ❌ "Comme mentionné ci-dessus/ci-dessous" (cross-reference assumptions)
- ❌ Raw paths: src/path/to/file.go → ✅ [[file.go]] or just the filename

## Style Notes

- Use impersonal constructions ("on utilise", "il est exécuté") or passive voice rather than first/second person
- Keep sentences relatively short for technical clarity — French prose can drift toward long sentences that hurt readability in documentation
