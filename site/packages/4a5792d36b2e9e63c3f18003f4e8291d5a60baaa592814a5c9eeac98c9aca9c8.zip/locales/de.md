# German Writing Guide

Writing style for page-writer agents when output language is `de`.

## Language Rules

- Prose is **German**, neutral technical tone
- Technical terms stay in their conventional English form: JWT, RabbitMQ, GORM, goroutine, middleware, barrel, styled-components, context API, hook, singleton, fan-in, dead-letter queue, fanout exchange
- Loanwords that already exist in German tech usage are acceptable: *Abhängigkeit*, *Schicht*, *Komponente*, *Dienst*, *Ablauf*, *Warteschlange*

## Page Structure

Every page must be **self-contained**: a first-time reader should understand it without jumping to any other page.

### Opening Paragraph
- 2-4 sentences in German
- Frame as *"X wird verwendet, um Y zu lösen, indem es Z tut"* — not *"Diese Datei macht X"*
- State why it exists, not just what it is

### Body Sections
- Prefer `##` headers, use `###` sparingly
- Minimize bullet lists — embed information in flowing German prose
- Use tables only for genuine comparisons

## Wikilinks

- Page titles verbatim: `[[JWT Authentication]]`, `[[Admin API (Go)]]` (page titles stay in English)
- For file references, prefer wikilinks when the page exists, otherwise just say the filename in prose
- No backticks anywhere
- Function and class names go in plain text: *TokenVerifyMiddleware*, *GenerateToken*

## What to Avoid

- ❌ "Diese Datei enthält X" → ✅ "X wird für Y verwendet"
- ❌ Backticks: `function()` → ✅ plain text: function
- ❌ Code blocks → ✅ prose explanation
- ❌ "Wie oben/unten erwähnt" (cross-reference assumptions)
- ❌ Raw paths: src/path/to/file.go → ✅ [[file.go]] or just the filename

## Style Notes

- Prefer the formal "Sie" form is **not** required — technical prose can be impersonal ("es wird ... verwendet")
- Compound nouns are natural in German; don't avoid them if they communicate clearly (e.g., *Authentifizierungsschicht*, *Nachrichtenwarteschlange*)
