# Turkish Writing Guide

Writing style for page-writer agents when output language is `tr`.

## Language Rules

- Prose is **Turkish**
- Technical terms stay in **English**: JWT, RabbitMQ, GORM, goroutine, middleware, barrel, styled-components, context API, hook, singleton, fan-in, dead-letter queue, fanout exchange
- Common loanwords are acceptable: *bağımlılık*, *katman*, *bileşen*, *servis*, *akış*, *kuyruk*

## Page Structure

Every page must be **self-contained**: a first-time reader should understand it without jumping to any other page.

### Opening Paragraph
- 2-4 sentences in Turkish
- Frame as *"X, Y sorununu çözmek için kullanılır"* — not *"Bu dosya X yapar"*
- State why it exists, not just what it is

### Body Sections
- Prefer `##` headers, use `###` sparingly
- Minimize bullet lists — embed information in flowing Turkish prose
- Use tables only for genuine comparisons

## Wikilinks

- Page titles verbatim: `[[JWT Kimlik Doğrulama]]`, `[[Admin API (Go)]]`
- For file references, prefer wikilinks when the page exists, otherwise just say the filename in prose
- No backticks anywhere
- Function and class names go in plain text: *TokenVerifyMiddleware*, *GenerateToken*

## What to Avoid

- ❌ "Bu dosya X içerir" → ✅ "X, Y amaçla kullanılır"
- ❌ Backticks: `fonksiyon()` → ✅ düz metin: fonksiyon
- ❌ Code blocks → ✅ prose açıklama
- ❌ "Yukarıda/aşağıda belirtildiği gibi" (cross-reference assumptions)
- ❌ Raw paths: src/path/to/file.go → ✅ [[file.go]] or just the filename
