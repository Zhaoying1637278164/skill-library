# English Writing Guide

Default writing style for vault-anything page-writer agents.

## Language Rules

- Prose is **English**, neutral technical tone
- Technical terms stay in their conventional form: JWT, RabbitMQ, GORM, goroutine, middleware, barrel, styled-components, context API, hook, singleton, fan-in, dead-letter queue, fanout exchange
- Avoid jargon-laden openings — start each page with a clear, plain-English sentence

## Page Structure

Every page must be **self-contained**: a first-time reader should understand it without jumping to any other page.

### Opening Paragraph
- 2-4 sentences
- Not *"This file does X"* — instead *"X is used to solve Y. It works by ..."*
- State why it exists, not just what it is

### Body Sections
- Prefer `##` headers, use `###` sparingly
- Minimize bullet lists — embed information in flowing prose
- Use tables only for genuine comparisons

## Wikilinks

- Page titles verbatim: `[[JWT Authentication]]`, `[[Admin API (Go)]]`
- For file references, prefer wikilinks when the page exists, otherwise just say the filename in prose
- No backticks anywhere
- Function and class names go in plain text: *TokenVerifyMiddleware*, *GenerateToken*

## What to Avoid

- ❌ "This file contains X" → ✅ "X is used for Y"
- ❌ Backticks: `function()` → ✅ plain text: function
- ❌ Code blocks → ✅ prose explanation
- ❌ "As mentioned above/below" (cross-reference assumptions)
- ❌ Raw paths: src/path/to/file.go → ✅ [[file.go]] or just the filename
