# Spanish Writing Guide

Writing style for page-writer agents when output language is `es`.

## Language Rules

- Prose is **Spanish**, neutral technical tone
- Technical terms stay in their conventional English form: JWT, RabbitMQ, GORM, goroutine, middleware, barrel, styled-components, context API, hook, singleton, fan-in, dead-letter queue, fanout exchange
- Common Spanish equivalents are acceptable: *dependencia*, *capa*, *componente*, *servicio*, *flujo*, *cola*

## Page Structure

Every page must be **self-contained**: a first-time reader should understand it without jumping to any other page.

### Opening Paragraph
- 2-4 sentences in Spanish
- Frame as *"X se utiliza para resolver Y haciendo Z"* — not *"Este archivo hace X"*
- State why it exists, not just what it is

### Body Sections
- Prefer `##` headers, use `###` sparingly
- Minimize bullet lists — embed information in flowing Spanish prose
- Use tables only for genuine comparisons

## Wikilinks

- Page titles verbatim: `[[JWT Authentication]]`, `[[Admin API (Go)]]` (page titles stay in English)
- For file references, prefer wikilinks when the page exists, otherwise just say the filename in prose
- No backticks anywhere
- Function and class names go in plain text: *TokenVerifyMiddleware*, *GenerateToken*

## What to Avoid

- ❌ "Este archivo contiene X" → ✅ "X se usa para Y"
- ❌ Backticks: `función()` → ✅ plain text: función
- ❌ Code blocks → ✅ prose explanation
- ❌ "Como se mencionó arriba/abajo" (cross-reference assumptions)
- ❌ Raw paths: src/path/to/file.go → ✅ [[file.go]] or just the filename

## Style Notes

- Use impersonal constructions ("se utiliza", "se ejecuta") rather than first or second person
- Active voice preferred where natural; avoid heavy nominal style typical of older academic Spanish
