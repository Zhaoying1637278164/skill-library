/**
 * vault-reviewer.mjs — Deterministic vault quality checks.
 *
 * Checks (no LLM required):
 *   - Required front matter fields
 *   - Minimum word count
 *   - Backtick / code block presence
 *   - Likely-English prose detection
 *   - Broken wikilinks (and broken section anchors)
 *   - Orphan pages
 *
 * LLM-based checks are defined in agents/vault-reviewer.md.
 */

import { readdirSync, readFileSync, existsSync } from 'fs';
import { join, basename } from 'path';

// ── Constants ─────────────────────────────────────────────────────────────────

const MIN_WORD_COUNT = 150;
const REQUIRED_FM    = ['title', 'tags', 'category', 'type'];

// ── Helpers ───────────────────────────────────────────────────────────────────

function listVaultPages(vaultDir) {
  const pages = [];
  if (!existsSync(vaultDir)) return pages;

  for (const entry of readdirSync(vaultDir, { withFileTypes: true })) {
    if (entry.name.startsWith('.') || entry.name === 'index.md') continue;
    if (!entry.isDirectory()) continue;

    const catDir = join(vaultDir, entry.name);
    for (const f of readdirSync(catDir)) {
      if (!f.endsWith('.md')) continue;
      const absPath = join(catDir, f);
      const content = readFileSync(absPath, 'utf-8');
      pages.push({
        relPath:  `${entry.name}/${f}`,
        title:    basename(f, '.md'),
        category: entry.name,
        content,
      });
    }
  }
  return pages;
}

function extractFrontMatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---/);
  if (!match) return {};
  const fm = {};
  for (const line of match[1].split('\n')) {
    const [key, ...rest] = line.split(':');
    if (key && rest.length) fm[key.trim()] = rest.join(':').trim();
  }
  return fm;
}

function extractWikilinks(content) {
  const links = [];
  const re = /\[\[([^\]]+)\]\]/g;
  let m;
  while ((m = re.exec(content)) !== null) links.push(m[1]);
  return links;
}

// Parses a wikilink body into its page target and optional section anchor.
// Handles aliases (`target|alias`) and anchors (`target#section`, `#section`).
function parseWikilink(raw) {
  const noAlias = raw.split('|')[0].trim();
  const hashIdx = noAlias.indexOf('#');
  if (hashIdx === -1) return { target: noAlias, anchor: null };
  return {
    target: noAlias.slice(0, hashIdx).trim(),
    anchor: noAlias.slice(hashIdx + 1).trim(),
  };
}

// Collects heading texts from a page body (for validating `#section` anchors).
// Normalized to lowercase so anchor matching is case-insensitive, as in Obsidian.
function extractHeadings(content) {
  const body = content.replace(/^---[\s\S]*?---\n/, '');
  const set = new Set();
  for (const m of body.matchAll(/^#{1,6}\s+(.+?)\s*$/gm)) {
    set.add(m[1].trim().toLowerCase());
  }
  return set;
}

function countWords(content) {
  const body = content.replace(/^---[\s\S]*?---\n/, '');
  return body.split(/\s+/).filter(w => w.length > 2).length;
}

function hasBacktick(content) {
  const body = content.replace(/^---[\s\S]*?---\n/, '');
  return /`[^`]+`/.test(body);
}

function hasCodeBlock(content) {
  return /```[\s\S]*?```/.test(content);
}

// Note: language detection removed — vault-anything is a global plugin and
// any output language is valid. The locale guide controls writing style.

// ── Secret leak detection ─────────────────────────────────────────────────────
// The vault is meant to be committed. If a page accidentally contains a real
// credential, we flag it as a hard issue. Patterns are intentionally conservative
// (some false negatives) — high-confidence signals only.
const SECRET_PATTERNS = [
  // Provider-specific high-confidence prefixes
  { re: /\bsk_live_[A-Za-z0-9]{20,}/g,          name: 'Stripe live secret key' },
  { re: /\bsk_test_[A-Za-z0-9]{20,}/g,          name: 'Stripe test secret key' },
  { re: /\bghp_[A-Za-z0-9]{30,}/g,              name: 'GitHub personal access token' },
  { re: /\bxoxb-[A-Za-z0-9-]{40,}/g,            name: 'Slack bot token' },
  { re: /\bxoxp-[A-Za-z0-9-]{40,}/g,            name: 'Slack user token' },
  { re: /AKIA[0-9A-Z]{16}/g,                    name: 'AWS access key ID' },
  // JWT — 3 base64 segments separated by dots
  { re: /\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,}/g, name: 'JWT' },
  // URL with embedded credentials
  { re: /\b(?:amqp|amqps|postgres|postgresql|mysql|mongodb|redis|rediss):\/\/[^/:@\s]+:[^/@\s]{6,}@[^/\s]+/g, name: 'URL with embedded credentials' },
];

function detectSecrets(content) {
  const findings = [];
  for (const { re, name } of SECRET_PATTERNS) {
    if (re.test(content)) findings.push(name);
    re.lastIndex = 0;
  }
  return findings;
}

// ── Main Reviewer ─────────────────────────────────────────────────────────────

/**
 * Runs deterministic quality checks on the vault.
 *
 * @param {string} vaultDir - vault/ directory
 * @returns {ReviewResult}
 */
export function reviewVault(vaultDir) {
  const pages    = listVaultPages(vaultDir);
  const issues   = [];
  const warnings = [];

  if (pages.length === 0) {
    return {
      totalPages:    0,
      issues:        [{ type: 'empty_vault', message: 'Vault is empty — no pages found.' }],
      warnings:      [],
      qualityScore:  0,
      passed:        false,
    };
  }

  const titleSet        = new Set(pages.map(p => p.title));
  const headingsByTitle = {};
  const incomingLinks   = {};

  for (const p of pages) {
    incomingLinks[p.title]   = 0;
    headingsByTitle[p.title] = extractHeadings(p.content);
  }

  for (const page of pages) {
    const fm    = extractFrontMatter(page.content);
    const links = extractWikilinks(page.content);
    const words = countWords(page.content);

    // 1. Required front matter fields
    for (const field of REQUIRED_FM) {
      if (!fm[field]) {
        issues.push({
          type:    'missing_frontmatter',
          page:    page.relPath,
          message: `Missing required field: "${field}"`,
        });
      }
    }

    // 2. Minimum word count
    if (words < MIN_WORD_COUNT) {
      warnings.push({
        type:    'short_page',
        page:    page.relPath,
        message: `${words} words (minimum ${MIN_WORD_COUNT})`,
      });
    }

    // 3. Backtick
    if (hasBacktick(page.content)) {
      issues.push({
        type:    'backtick',
        page:    page.relPath,
        message: 'Inline backtick detected — should be removed',
      });
    }

    // 4. Code block
    if (hasCodeBlock(page.content)) {
      issues.push({
        type:    'code_block',
        page:    page.relPath,
        message: 'Code block detected — should be removed',
      });
    }

    // 5. Secret leak — hard issue, vault is committed
    const leakedSecrets = detectSecrets(page.content);
    for (const kind of leakedSecrets) {
      issues.push({
        type:    'secret_leak',
        page:    page.relPath,
        message: `Possible ${kind} present in page content — must be redacted before commit`,
      });
    }

    // 6. Wikilink validation (anchor-aware)
    for (const raw of links) {
      const { target, anchor } = parseWikilink(raw);
      // A bare `[[#section]]` link points at the current page.
      const resolved = target === '' ? page.title : target;

      if (!titleSet.has(resolved)) {
        warnings.push({
          type:    'broken_link',
          page:    page.relPath,
          message: `[[${raw}]] page not found`,
        });
        continue;
      }

      // The page exists — it's a real incoming link (don't count self-links).
      if (resolved !== page.title) {
        incomingLinks[resolved] = (incomingLinks[resolved] ?? 0) + 1;
      }

      // If a section anchor was given, check it resolves to a heading.
      if (anchor && !(headingsByTitle[resolved] ?? new Set()).has(anchor.toLowerCase())) {
        warnings.push({
          type:    'broken_anchor',
          page:    page.relPath,
          message: `[[${raw}]] — section "#${anchor}" not found in [[${resolved}]]`,
        });
      }
    }
  }

  // 7. Orphan pages
  for (const [title, count] of Object.entries(incomingLinks)) {
    if (count === 0) {
      warnings.push({
        type:    'orphan',
        page:    title,
        message: 'No incoming links from other pages',
      });
    }
  }

  // Quality score — normalized by page count
  const n          = pages.length || 1;
  const issueScore = (issues.length / n) * 30;
  const warnScore  = (warnings.filter(w =>
    ['broken_link', 'broken_anchor', 'orphan', 'short_page'].includes(w.type)
  ).length / n) * 15;
  const qualityScore = Math.round(Math.max(0, 100 - issueScore - warnScore));

  return {
    totalPages: pages.length,
    issues,
    warnings,
    qualityScore,
    passed:  issues.length === 0,
    summary: buildSummary(pages, issues, warnings, qualityScore),
  };
}

function buildSummary(pages, issues, warnings, score) {
  const lines = [
    `Total pages:   ${pages.length}`,
    `Issues:        ${issues.length}`,
    `Warnings:      ${warnings.length}`,
    `Quality score: ${score}/100`,
  ];

  if (issues.length > 0) {
    lines.push('\nIssues (must fix):');
    for (const i of issues.slice(0, 5)) {
      lines.push(`  ✗ [${i.type}] ${i.page} — ${i.message}`);
    }
    if (issues.length > 5) lines.push(`  ... and ${issues.length - 5} more`);
  }

  if (warnings.length > 0) {
    lines.push('\nWarnings:');
    for (const w of warnings.slice(0, 5)) {
      lines.push(`  ⚠ [${w.type}] ${w.page} — ${w.message}`);
    }
    if (warnings.length > 5) lines.push(`  ... and ${warnings.length - 5} more`);
  }

  return lines.join('\n');
}
