/**
 * scan.mjs — Discovers project files, detects language and category.
 *
 * Output: ScanResult[]
 */

import { readdirSync, statSync, readFileSync, existsSync } from 'fs';
import { join, relative, extname, basename } from 'path';
import { createHash } from 'crypto';

// ── Constants ─────────────────────────────────────────────────────────────────

// Directories that are never project files:
//   - VCS: .git
//   - Build artifacts: dist, build, out, .next, .cache, .turbo, target, obj, coverage
//   - Dependency stores: node_modules, vendor, venv, .venv, __pycache__
//   - Test snapshots: __snapshots__
//   - vault-anything workspace (this plugin's own output)
const ALWAYS_IGNORE = new Set([
  'node_modules', '.git', 'dist', 'build', 'out', '.next', '.cache',
  '.turbo', 'target', 'obj', 'vendor', 'venv', '.venv', '__pycache__',
  'coverage', '__snapshots__',
  'vault-anything',
]);

// Hidden directories that are tool/IDE state, not project content.
// Detected by leading dot; ALWAYS_IGNORE handles the rest.
function isToolStateDir(name) {
  return name.startsWith('.') && name.length > 1;
}

/**
 * Whether a directory name should never be descended into — build artifacts,
 * VCS, dependency stores (ALWAYS_IGNORE) or tool/IDE state (leading dot).
 *
 * Exported so directory walks outside the scanner (e.g. sub-repo discovery in
 * diff-update) share exactly one set of skip rules.
 */
export function isIgnoredDirName(name) {
  return ALWAYS_IGNORE.has(name) || isToolStateDir(name);
}

const BINARY_EXTENSIONS = new Set([
  '.png','.jpg','.jpeg','.gif','.svg','.ico','.woff','.woff2','.ttf',
  '.eot','.mp3','.mp4','.pdf','.zip','.tar','.gz','.exe','.dll','.so',
  '.dylib','.bin','.dat','.db','.sqlite',
]);

const LANG_MAP = {
  '.go':    'go',
  '.ts':    'typescript',
  '.tsx':   'typescript',
  '.js':    'javascript',
  '.jsx':   'javascript',
  '.mjs':   'javascript',
  '.cjs':   'javascript',
  '.py':    'python',
  '.rs':    'rust',
  '.java':  'java',
  '.kt':    'kotlin',
  '.swift': 'swift',
  '.rb':    'ruby',
  '.php':   'php',
  '.cs':    'csharp',
  '.cpp':   'cpp',
  '.c':     'c',
  '.h':     'c',
  '.hpp':   'cpp',
  '.sh':    'shell',
  '.bash':  'shell',
  '.zsh':   'shell',
  '.yaml':  'yaml',
  '.yml':   'yaml',
  '.json':  'json',
  '.toml':  'toml',
  '.md':    'markdown',
  '.mdx':   'markdown',
  '.txt':   'text',
  '.env':   'env',
  '.html':  'html',
  '.css':   'css',
  '.scss':  'css',
  '.sass':  'css',
  '.less':  'css',
  '.sql':   'sql',
  '.graphql':'graphql',
  '.gql':   'graphql',
  '.proto': 'protobuf',
  '.tf':    'terraform',
  '.mod':   'gomod',
  '.sum':   'gosum',
};

const CATEGORY_MAP = {
  code:   new Set(['go','typescript','javascript','python','rust','java','kotlin',
                   'swift','ruby','php','csharp','cpp','c','shell']),
  config: new Set(['yaml','json','toml','env','gomod','gosum']),
  docs:   new Set(['markdown','text']),
  markup: new Set(['html','css']),
  infra:  new Set(['dockerfile','terraform']),
  data:   new Set(['sql','graphql','protobuf']),
};

function detectCategory(lang, filePath) {
  const fp = filePath.toLowerCase();
  if (fp.includes('dockerfile') || basename(fp) === 'dockerfile') return 'infra';
  if (fp.endsWith('.lock') || basename(fp).endsWith('.lock'))     return 'config';
  for (const [cat, langs] of Object.entries(CATEGORY_MAP)) {
    if (langs.has(lang)) return cat;
  }
  return 'other';
}

function detectLang(filePath) {
  const fp = filePath.toLowerCase();
  const ext = extname(fp);
  if (basename(fp) === 'dockerfile') return 'dockerfile';
  if (basename(fp).endsWith('.lock')) return 'lockfile';
  return LANG_MAP[ext] ?? 'unknown';
}

function countLines(filePath) {
  try {
    const content = readFileSync(filePath, 'utf-8');
    return content.split('\n').length;
  } catch {
    return 0;
  }
}

function contentHash(filePath) {
  try {
    const content = readFileSync(filePath);
    return createHash('sha256').update(content).digest('hex').slice(0, 16);
  } catch {
    return '';
  }
}

// ── .vaultignore Loading ────────────────────────────────────────────────────────

function loadIgnorePatterns(projectRoot) {
  const ignorePath = join(projectRoot, '.vaultignore');
  const patterns = [];
  if (existsSync(ignorePath)) {
    const lines = readFileSync(ignorePath, 'utf-8').split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#')) {
        patterns.push(trimmed);
      }
    }
  }
  return patterns;
}

// Escape every regex metacharacter so user-supplied glob patterns can't be
// interpreted as regex (no surprise matches, no ReDoS via "(.+)+" etc.),
// then re-introduce `*` as the only wildcard.
function globToRegExpSource(pattern) {
  return pattern
    .replace(/[.+?^${}()|[\]\\]/g, '\\$&')   // escape all regex metachars
    .replace(/\*/g, '.*');                   // * becomes the only wildcard
}

function matchesIgnore(relPath, patterns) {
  for (const pattern of patterns) {
    const regex = new RegExp('^' + globToRegExpSource(pattern) + '$');
    if (regex.test(relPath) || relPath.startsWith(pattern.replace('*', ''))) {
      return true;
    }
  }
  return false;
}

/**
 * Builds a predicate `(relPath) => boolean` indicating whether a project-relative
 * path is one the scanner would include. Mirrors the skip logic inside
 * `scanProject`'s walk (ALWAYS_IGNORE, hidden/tool-state directories,
 * `.vaultignore`, binary extensions) so that change detection and scanning agree
 * on what counts as a project file — otherwise `vault-update` reports tooling
 * artifacts (e.g. a sibling tool's `.cache/` or dot-state dirs) as code changes.
 *
 * `.vaultignore` is read once when the filter is created.
 */
export function createScanFilter(projectRoot) {
  const ignorePatterns = loadIgnorePatterns(projectRoot);
  return (relPath) => {
    const segments = relPath.split('/').filter(Boolean);
    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      if (ALWAYS_IGNORE.has(seg)) return false;
      // Hidden/tool-state directories are skipped at the directory level only
      // (a trailing dotfile like .gitignore is still a scannable file).
      if (i < segments.length - 1 && isToolStateDir(seg)) return false;
    }
    if (matchesIgnore(relPath, ignorePatterns)) return false;
    if (BINARY_EXTENSIONS.has(extname(relPath).toLowerCase())) return false;
    return true;
  };
}

// ── Main Scanner ────────────────────────────────────────────────────────────────

/**
 * Scans the project directory.
 *
 * @param {string} projectRoot - Project root directory to scan
 * @returns {{ files: ScanFile[], stats: ScanStats, languages: string[] }}
 */
export function scanProject(projectRoot) {
  const ignorePatterns = loadIgnorePatterns(projectRoot);
  const files = [];
  const langCounts = {};

  function walk(dir) {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      const fullPath = join(dir, entry.name);
      const relPath  = relative(projectRoot, fullPath);

      // Conventional ignore (build artifacts, VCS, dependency stores)
      if (ALWAYS_IGNORE.has(entry.name)) continue;

      // Skip hidden directories (tool/IDE state, dotfiles directories)
      // BUT only at the directory level — root-level dotfiles like .gitignore
      // are still scanned. This avoids walking into .claude, .vscode, .idea, etc.
      if (entry.isDirectory() && isToolStateDir(entry.name)) continue;

      // .vaultignore (user-defined patterns)
      if (matchesIgnore(relPath, ignorePatterns)) continue;

      if (entry.isDirectory()) {
        walk(fullPath);
        continue;
      }

      if (!entry.isFile()) continue;

      // Skip binary files
      const ext = extname(entry.name).toLowerCase();
      if (BINARY_EXTENSIONS.has(ext)) continue;

      const lang     = detectLang(fullPath);
      const category = detectCategory(lang, fullPath);
      const sizeLines = countLines(fullPath);
      const hash     = contentHash(fullPath);

      langCounts[lang] = (langCounts[lang] ?? 0) + 1;

      files.push({
        path:      relPath,
        absPath:   fullPath,
        language:  lang,
        category,
        sizeLines,
        hash,
      });
    }
  }

  walk(projectRoot);

  // Language list sorted by usage (most to least)
  const languages = Object.entries(langCounts)
    .filter(([lang]) => CATEGORY_MAP.code.has(lang))
    .sort(([, a], [, b]) => b - a)
    .map(([lang]) => lang);

  const stats = {
    total:    files.length,
    byCategory: files.reduce((acc, f) => {
      acc[f.category] = (acc[f.category] ?? 0) + 1;
      return acc;
    }, {}),
  };

  return { files, stats, languages };
}
