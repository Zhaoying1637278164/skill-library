/**
 * diff-update.mjs — Incremental update mechanism.
 *
 * Detects changes from two sources:
 *   1. Git diff (source code changes)
 *   2. Raw manifest diff (user static files)
 */

import { execSync, execFileSync } from 'child_process';
import { existsSync, readdirSync, readFileSync } from 'fs';
import { join } from 'path';
import { readMeta, diffRawManifest } from './write-raw.mjs';
import { createScanFilter, isIgnoredDirName } from './scan.mjs';
import { loadProjectConfig, subRepoOptions } from './project-config.mjs';

// A SHA-1 / SHA-256 commit hash. Anything else is rejected before being
// passed to a shell, eliminating command-injection risk via meta.json.
const COMMIT_HASH_RE = /^[0-9a-f]{7,64}$/i;

// Splits `--name-only` style git output into a clean list of paths.
function gitLines(output) {
  return output.split('\n').map(s => s.trim()).filter(Boolean);
}

// ── Git Diff ──────────────────────────────────────────────────────────────────

/**
 * Returns files changed since the last analyzed commit.
 * @param {string} projectRoot - project root directory
 * @param {string} lastHash    - lastCommitHash from meta.json
 * @returns {{ changedFiles: string[], currentHash: string }}
 */
/**
 * Collects changed files within a single git repo directory: committed changes
 * since `lastHash` (lastHash..HEAD) plus uncommitted work (tracked edits vs HEAD
 * and new untracked files). Paths are relative to `dir`.
 *
 * Returns `{ files, uncommittedCount, full }`. `full` signals the caller should
 * fall back to a full re-analysis (the recorded baseline is malformed/unusable).
 */
function repoChanges(dir, lastHash, currentHash) {
  const committed = new Set();

  // 1. Committed changes since the last analyzed commit (lastHash..HEAD).
  if (lastHash && lastHash !== currentHash) {
    // Reject anything that doesn't look like a git hash before it touches a
    // shell. The hash comes from meta.json, which is in the user's workspace
    // and could in principle be tampered with — validation closes the loop.
    if (!COMMIT_HASH_RE.test(lastHash)) {
      return { committed: [], uncommitted: [], full: true };
    }
    try {
      const output = execFileSync(
        'git', ['diff', `${lastHash}..HEAD`, '--name-only'],
        { cwd: dir, stdio: ['ignore', 'pipe', 'ignore'] }
      ).toString();
      for (const f of gitLines(output)) committed.add(f);
    } catch {
      // Invalid hash that passed regex (e.g. orphan commit) — full re-analysis.
      return { committed: [], uncommitted: [], full: true };
    }
  }

  // 2. Uncommitted work: tracked edits (staged + unstaged vs HEAD) plus new
  //    untracked files. This lets an edit-then-update flow work without an
  //    intermediate commit — otherwise nothing committed means nothing detected.
  let uncommitted = [];
  try {
    const tracked = execFileSync(
      'git', ['diff', 'HEAD', '--name-only'],
      { cwd: dir, stdio: ['ignore', 'pipe', 'ignore'] }
    ).toString();
    const untracked = execFileSync(
      'git', ['ls-files', '--others', '--exclude-standard'],
      { cwd: dir, stdio: ['ignore', 'pipe', 'ignore'] }
    ).toString();
    uncommitted = [...new Set([...gitLines(tracked), ...gitLines(untracked)])];
  } catch {/* best-effort: probing the working tree never blocks an update */}

  return { committed: [...committed], uncommitted, full: false };
}

export function getCodeChanges(projectRoot, lastHash, recordedSubRepos = [], subRepoOpts = {}) {
  let currentHash;
  try {
    currentHash = execSync('git rev-parse HEAD', {
      cwd: projectRoot,
      stdio: ['ignore', 'pipe', 'ignore'],
    }).toString().trim();
  } catch {
    // Root isn't a git repo. It may be a multi-project parent holding several
    // git sub-repos — diff each of those instead.
    return getSubRepoChanges(projectRoot, recordedSubRepos, subRepoOpts);
  }

  const r = repoChanges(projectRoot, lastHash, currentHash);
  if (r.full) return { changedFiles: ['__ALL__'], currentHash, uncommittedCount: 0, subRepos: [] };

  // Only count files the scanner would actually analyze — drops tooling
  // artifacts (dot-state dirs, build output, .vaultignore'd paths) that git
  // surfaces as untracked but that aren't project source.
  const keep = createScanFilter(projectRoot);
  const committed   = r.committed.filter(keep);
  const uncommitted = r.uncommitted.filter(keep);
  const changedFiles = [...new Set([...committed, ...uncommitted])];
  return { changedFiles, currentHash, uncommittedCount: uncommitted.length, subRepos: [] };
}

/**
 * Multi-project change detection: the root isn't a git repo but holds several
 * git sub-repos. Diffs each sub-repo against its recorded baseline (from
 * `meta.json`'s `subRepos`) plus its working tree, prefixing every path with
 * `<subRepo>/` so it matches the parent-relative paths the scanner produces.
 *
 * A sub-repo with no recorded baseline still has its uncommitted changes
 * detected; committed-delta detection for it begins once a full run records a
 * baseline. Returns the current sub-repo HEAD snapshot so the caller can persist
 * it as the next baseline.
 */
export function getSubRepoChanges(projectRoot, recordedSubRepos = [], subRepoOpts = {}) {
  const recorded = new Map((recordedSubRepos ?? []).map(s => [s.name, s.hash]));
  const subRepos = detectSubRepos(projectRoot, subRepoOpts);
  if (subRepos.length === 0) {
    // Neither a git root nor any nested repo within depth — incremental
    // detection can't work. `noReposFound` lets the skill explain why (and
    // point at the `repoRoots` override) rather than silently doing nothing.
    return { changedFiles: [], currentHash: null, uncommittedCount: 0, subRepos: [], noReposFound: true };
  }

  const keep = createScanFilter(projectRoot);
  const changed = new Set();
  let uncommittedCount = 0;
  for (const { name, hash: currentHash } of subRepos) {
    const r = repoChanges(join(projectRoot, name), recorded.get(name) ?? null, currentHash);
    // A malformed baseline in any one sub-repo forces a full rebuild — safe and rare.
    if (r.full) {
      return { changedFiles: ['__ALL__'], currentHash: null, uncommittedCount: 0, subRepos };
    }
    // Paths are prefixed with the sub-repo name so they match the scanner's
    // parent-relative paths, then filtered through the same ignore rules.
    for (const f of r.committed) {
      const p = `${name}/${f}`;
      if (keep(p)) changed.add(p);
    }
    for (const f of r.uncommitted) {
      const p = `${name}/${f}`;
      if (keep(p)) { changed.add(p); uncommittedCount++; }
    }
  }

  return { changedFiles: [...changed], currentHash: null, uncommittedCount, subRepos };
}

/**
 * Returns the current HEAD commit hash.
 */
export function getCurrentHash(projectRoot) {
  return headHash(projectRoot);
}

// Resolves a directory's current HEAD, or null if it isn't a usable git repo
// (no .git, no commits, detached/unborn HEAD). Never throws.
function headHash(dir) {
  try {
    return execSync('git rev-parse HEAD', {
      cwd: dir,
      stdio: ['ignore', 'pipe', 'ignore'],
    }).toString().trim();
  } catch {
    return null;
  }
}

/**
 * Detects git repositories nested under a multi-project parent directory.
 *
 * Used when the workspace root isn't itself a git repo but the projects under
 * it are. Walks the tree up to `maxDepth` levels deep, recording each directory
 * that contains a `.git` and **not descending into it** (a repo's own nested
 * repos/submodules aren't separate sub-projects). This finds both flat layouts
 * (`parent/service`) and grouped ones (`parent/apps/sms`, `parent/packages/core`).
 *
 * `name` is the path **relative to `projectRoot`** (e.g. `apps/sms`), which is
 * exactly the prefix the scanner uses for files inside that repo, so callers can
 * map changed paths and baselines without extra translation. A flat layout still
 * yields a flat `name` (`service`), keeping older `meta.json` baselines valid.
 *
 * @param {string} projectRoot
 * @param {object} [opts]
 * @param {number} [opts.maxDepth=3]      - how many directory levels to descend
 * @param {string[]|null} [opts.repoRoots] - explicit relative repo paths; when
 *   given, auto-discovery is skipped and only these are validated + hashed
 *   (the `repoRoots` escape hatch from `.vault-anything.json`)
 * @returns {Array<{ name: string, hash: string }>} empty if none found
 */
export function detectSubRepos(projectRoot, { maxDepth = 3, repoRoots = null } = {}) {
  // Explicit override: trust the user-listed paths, skip the walk entirely.
  if (repoRoots && repoRoots.length) {
    const out = [];
    for (const rel of repoRoots) {
      const name = String(rel).replace(/\\/g, '/').replace(/\/+$/, '');
      if (!name || !existsSync(join(projectRoot, name, '.git'))) continue;
      const hash = headHash(join(projectRoot, name));
      if (hash) out.push({ name, hash });
    }
    return out;
  }

  const depthLimit = Number.isInteger(maxDepth) && maxDepth > 0 ? maxDepth : 3;
  const subRepos = [];

  function walk(dir, relBase, depth) {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      if (!e.isDirectory() || isIgnoredDirName(e.name)) continue;
      const childRel = relBase ? `${relBase}/${e.name}` : e.name;
      const childDir = join(dir, e.name);
      if (existsSync(join(childDir, '.git'))) {
        const hash = headHash(childDir);
        // A directory with .git but no resolvable HEAD is skipped, not recursed:
        // it's a repo (just unusable), so its contents aren't separate projects.
        if (hash) subRepos.push({ name: childRel, hash });
        continue; // prune — never descend into a repository
      }
      if (depth < depthLimit) walk(childDir, childRel, depth + 1);
    }
  }

  walk(projectRoot, '', 1);
  return subRepos;
}

// ── Update Plan ───────────────────────────────────────────────────────────────

/**
 * Combines code and raw changes into a unified update plan.
 *
 * @param {string} projectRoot  - source code directory
 * @param {string} rawDir       - workspace raw/ directory
 * @param {string} projectName  - project name (looked up in meta.json)
 * @returns {UpdatePlan}
 */
export function buildUpdatePlan(projectRoot, rawDir, projectName) {
  const meta        = readMeta(rawDir);
  const projectMeta = meta.projects?.[projectName];
  const lastHash    = projectMeta?.lastCommitHash ?? null;

  // 1. Code changes. For multi-project roots, pass the recorded sub-repo
  //    baselines so each sub-repo can be diffed against its own last HEAD, plus
  //    the sub-repo discovery options (depth + repoRoots) from the project config.
  const subRepoOpts = subRepoOptions(loadProjectConfig(projectRoot));
  const { changedFiles, currentHash, uncommittedCount, subRepos, noReposFound } =
    getCodeChanges(projectRoot, lastHash, projectMeta?.subRepos ?? [], subRepoOpts);

  // 2. Raw manifest changes
  const rawDiff = diffRawManifest(rawDir, meta);

  // 3. Affected vault pages
  const affectedVaultPages = new Set();

  // 3a. From changed static files (their recorded affectsPages).
  for (const f of [...rawDiff.changed, ...rawDiff.removed]) {
    for (const page of (f.affectsPages ?? [])) {
      affectedVaultPages.add(page);
    }
  }

  // 3b. From changed code files: a page is affected if any of its source
  //     filePaths changed. page-plan.json (written by run-generate) carries
  //     filePaths + title per page. Skipped on full re-analysis (the skill
  //     rebuilds from scratch in that case).
  if (changedFiles.length > 0 && !changedFiles.includes('__ALL__')) {
    const changedSet = new Set(changedFiles);
    try {
      const planPath = join(rawDir, projectName, 'page-plan.json');
      if (existsSync(planPath)) {
        const pagePlan = JSON.parse(readFileSync(planPath, 'utf-8'));
        for (const page of (pagePlan.pages ?? [])) {
          if ((page.filePaths ?? []).some(fp => changedSet.has(fp))) {
            affectedVaultPages.add(page.title);
          }
        }
      }
    } catch {/* missing/corrupt page-plan — leave code-driven pages unmapped */}
  }

  // New raw files need a full generate (affectsPages not yet known)
  const hasNewRawFiles = rawDiff.added.length > 0;

  return {
    projectName,
    currentHash,
    lastHash,
    currentSubRepos: subRepos ?? [],
    noReposFound: noReposFound ?? false,
    codeChanges: {
      changedFiles,
      hasChanges:       changedFiles.length > 0,
      fullReanalyze:    changedFiles.includes('__ALL__'),
      uncommittedCount: uncommittedCount ?? 0,
    },
    rawChanges: {
      added:      rawDiff.added,
      changed:    rawDiff.changed,
      removed:    rawDiff.removed,
      hasChanges: rawDiff.added.length + rawDiff.changed.length + rawDiff.removed.length > 0,
    },
    affectedVaultPages: [...affectedVaultPages],
    requiresFullGenerate: hasNewRawFiles,
    meta,
  };
}

/**
 * Returns a human-readable summary of the update plan.
 */
export function summarizeUpdatePlan(plan) {
  const lines = [`\nUpdate plan — ${plan.projectName}`];

  // No git root and no nested repos within depth: code-change detection is off,
  // so "up to date" would be a lie. Tell the user how to fix it.
  if (plan.noReposFound && !plan.rawChanges.hasChanges) {
    lines.push('  ⚠ No git repository found at the root or nested within it.');
    lines.push('    Code-change detection is disabled — a full re-analysis is needed to refresh the vault.');
    lines.push('    If your repos are grouped (e.g. apps/sms, packages/core), list them in');
    lines.push('    .vault-anything.json → "repoRoots": ["apps/sms", "packages/core"].');
    return lines.join('\n');
  }

  if (!plan.codeChanges.hasChanges && !plan.rawChanges.hasChanges) {
    lines.push('  ✓ No changes detected, vault is up to date.');
    return lines.join('\n');
  }

  if (plan.codeChanges.hasChanges) {
    if (plan.codeChanges.fullReanalyze) {
      lines.push('  Code: Full re-analysis required');
    } else {
      const uc = plan.codeChanges.uncommittedCount;
      const suffix = uc > 0 ? ` (${uc} uncommitted)` : '';
      lines.push(`  Code: ${plan.codeChanges.changedFiles.length} file(s) changed${suffix}`);
      for (const f of plan.codeChanges.changedFiles.slice(0, 5)) {
        lines.push(`    · ${f}`);
      }
      if (plan.codeChanges.changedFiles.length > 5) {
        lines.push(`    ... and ${plan.codeChanges.changedFiles.length - 5} more`);
      }
    }
  }

  if (plan.rawChanges.hasChanges) {
    const { added, changed, removed } = plan.rawChanges;
    if (added.length)   lines.push(`  Raw: ${added.length} new static file(s)`);
    if (changed.length) lines.push(`  Raw: ${changed.length} changed static file(s)`);
    if (removed.length) lines.push(`  Raw: ${removed.length} removed static file(s)`);
  }

  if (plan.affectedVaultPages.length) {
    lines.push(`  Vault pages to update: ${plan.affectedVaultPages.length}`);
  }

  if (plan.requiresFullGenerate) {
    lines.push('  Note: New raw files detected — full vault regeneration needed');
  }

  return lines.join('\n');
}
