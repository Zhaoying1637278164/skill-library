/**
 * project-config.mjs — Loads the optional `.vault-anything.json` project config.
 *
 * Single source of truth for reading the per-project config file so the scan,
 * generate, and incremental-update paths all agree on its shape. Absent or
 * malformed → `{}` (callers fall back to defaults).
 */

import { existsSync, readFileSync } from 'fs';
import { join } from 'path';

/**
 * Reads `<projectRoot>/.vault-anything.json`.
 *
 * @param {string} projectRoot - directory the config lives next to
 * @returns {object} parsed config, or `{}` if missing/unreadable/malformed
 */
export function loadProjectConfig(projectRoot) {
  if (!projectRoot) return {};
  const configPath = join(projectRoot, '.vault-anything.json');
  if (!existsSync(configPath)) return {};
  try {
    return JSON.parse(readFileSync(configPath, 'utf-8'));
  } catch {
    console.error(`Warning: ignoring malformed ${configPath}`);
    return {};
  }
}

/**
 * Extracts the sub-repo discovery options from a loaded config.
 * Keeps the `{ maxDepth, repoRoots }` shape that `detectSubRepos` expects in
 * one place so every caller derives it identically.
 *
 * @param {object} config - result of `loadProjectConfig`
 * @returns {{ maxDepth: (number|undefined), repoRoots: (string[]|null) }}
 */
export function subRepoOptions(config = {}) {
  const repoRoots = Array.isArray(config.repoRoots) && config.repoRoots.length
    ? config.repoRoots
    : null;
  return { maxDepth: config.repoMaxDepth, repoRoots };
}
