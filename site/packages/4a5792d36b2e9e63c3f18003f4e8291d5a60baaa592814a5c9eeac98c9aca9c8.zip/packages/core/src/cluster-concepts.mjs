/**
 * cluster-concepts.mjs — Groups raw file summaries into wiki page specs.
 *
 * Input:  FileSummary[] (read from raw/<project>/file-summaries/)
 * Output: PageSpec[]
 *
 * Strategy:
 *   1. Architecture concepts: derived from tag co-occurrence patterns
 *   2. Cross-cutting concerns: tags appearing across many otherwise-unrelated files
 *   3. Reference pages: importance-scored top files (multi-signal, not just fan-in)
 *   4. Entity index pages (one each, via clusterEntityIndex):
 *        - API: endpoints the project serves/calls (synchronous surface)
 *        - Topics: messaging entities (queues, topics, exchanges — asynchronous surface)
 *        - Config: env vars, feature flags, constants, secrets
 *        - Data Model: tables, models, DTOs, enums
 *        - Integrations: third-party SaaS, internal services, infra (outbound deps)
 *        - Jobs: cron jobs, workers, scheduled tasks
 *        - Permissions: RBAC roles, scopes, permission strings
 *
 * Project-specific flows (e.g. "User Activation Flow") are NOT auto-generated.
 * Users can supply them via config.flows; otherwise no flow pages.
 */

const ARCHITECTURE_TAG_GROUPS = [
  { title: 'Authentication & Authorization', tags: ['authentication', 'jwt', 'oauth', 'security', 'auth'] },
  { title: 'Messaging & Events',             tags: ['messaging', 'event-handler', 'queue', 'rabbitmq', 'kafka', 'pubsub', 'amqp'] },
  { title: 'Email & Notifications',          tags: ['email', 'smtp', 'mail', 'notification', 'sms', 'templating'] },
  { title: 'Data Layer',                     tags: ['data-model', 'database', 'orm', 'gorm', 'sqlalchemy', 'prisma'] },
  { title: 'UI Components',                  tags: ['component', 'ui', 'react', 'vue', 'styled-components'] },
  { title: 'HTTP API Layer',                 tags: ['api-handler', 'rest', 'graphql', 'endpoint'] },
  { title: 'Middleware',                     tags: ['middleware', 'interceptor', 'guard'] },
  { title: 'State Management',               tags: ['state-management', 'context', 'store', 'redux'] },
  { title: 'Configuration',                  tags: ['configuration', 'config', 'environment'] },
  { title: 'Testing',                        tags: ['test', 'unit-test', 'integration-test', 'fixture'] },
];

const CROSS_CUTTING_TAG_GROUPS = [
  { title: 'Monitoring & Observability', tags: ['monitoring', 'logging', 'tracing', 'metrics', 'apm', 'observability'] },
  { title: 'Error Handling',             tags: ['error-handling', 'exception', 'recovery'] },
  { title: 'Security & TLS',             tags: ['security', 'tls', 'certificate', 'encryption'] },
  { title: 'Containerization',           tags: ['containerization', 'docker', 'kubernetes'] },
  { title: 'CI/CD',                      tags: ['ci-cd', 'pipeline', 'github-actions', 'workflow'] },
];

// ── Helpers ───────────────────────────────────────────────────────────────────

function tagsOf(summary) {
  return new Set(summary.tags ?? []);
}

function matchKeywords(summary, keywords) {
  const haystack = (
    summary.filePath + ' ' + (summary.summary || '') + ' ' +
    (summary.keyExports ?? []).join(' ')
  ).toLowerCase();
  return keywords.some(k => haystack.includes(k.toLowerCase()));
}

// ── Multi-signal Importance Scoring ──────────────────────────────────────────

/**
 * Computes an importance score for a file from multiple signals.
 * No magic threshold — pages are ranked and the top slice gets reference pages.
 */
function importanceScore(summary, entryPointSet) {
  let score = 0;

  // Fan-in: many other files depend on this one
  score += (summary.fanIn ?? 0) * 3;

  // Tag diversity: file touches multiple concerns
  score += (summary.tags?.length ?? 0) * 2;

  // Public API surface
  score += Math.min((summary.keyExports?.length ?? 0), 10) * 1;

  // LLM signal: the file-analyzer agent flagged this as load-bearing
  if (summary.isCore) score += 10;

  // Entry point bonus
  if (entryPointSet.has(summary.filePath)) score += 8;

  // Size bonus for substantial files
  if ((summary.sizeLines ?? 0) > 200) score += 2;

  // Messaging entity bonus: files participating in topics matter
  if ((summary.messagingEntities?.length ?? 0) > 0) score += 4;

  // API surface bonus: files defining or calling endpoints matter
  if ((summary.apiEndpoints?.length ?? 0) > 0) score += 4;

  return score;
}

// ── Generic Entity-Index Clustering ────────────────────────────────────────────

/**
 * Generic "collapse many entities into one index page" engine.
 *
 * Several categories share the same shape: each FileSummary carries an array of
 * named entities (messaging topics, config keys, API endpoints, ...), and we
 * want to fold every occurrence across files into a single index page rather
 * than emitting one thin page per entity. This helper owns that shared skeleton;
 * the per-category specifics are supplied via callbacks.
 *
 * @param {FileSummary[]} summaries
 * @param {object} opts
 * @param {string}   opts.field        - FileSummary array field to read (e.g. 'configEntities')
 * @param {function} opts.keyOf        - (entity) => dedupe key (entities sharing a key are merged)
 * @param {object}   opts.roleBuckets  - { bucketName: [accepted entity.role values] }. A role
 *                                        listed under multiple buckets lands in each (e.g. 'both').
 *                                        Use ['*'] to collect every occurrence regardless of role.
 * @param {function} [opts.initExtra]  - (entity) => initial extra-accumulator object for a new key
 * @param {function} [opts.mergeExtra] - (extra, entity, summary) => void, run for every occurrence
 * @param {function} opts.toRow        - (info) => row object, or null to drop the entity. `info` is
 *                                        { entity, buckets: {name: Set<filePath>}, extra }
 * @param {function} opts.toPage       - (rows, referencedFiles, summariesForPage) => PageSpec|null
 * @returns {PageSpec[]} at most one page
 */
function clusterEntityIndex(summaries, opts) {
  const { field, keyOf, roleBuckets, initExtra, mergeExtra, toRow, toPage } = opts;
  const bucketNames = Object.keys(roleBuckets);

  const map = new Map(); // key → { entity, buckets, extra }

  for (const s of summaries) {
    for (const entity of (s[field] ?? [])) {
      const key = keyOf(entity);

      if (!map.has(key)) {
        const buckets = {};
        for (const b of bucketNames) buckets[b] = new Set();
        map.set(key, { entity, buckets, extra: initExtra ? initExtra(entity) : {} });
      }
      const info = map.get(key);

      for (const b of bucketNames) {
        const accepted = roleBuckets[b];
        if (accepted.includes('*') || accepted.includes(entity.role)) info.buckets[b].add(s.filePath);
      }
      if (mergeExtra) mergeExtra(info.extra, entity, s);
    }
  }

  if (map.size === 0) return [];

  const rows = [];
  const referencedFiles = new Set();
  for (const info of map.values()) {
    const row = toRow(info);
    if (row === null || row === undefined) continue;
    for (const b of bucketNames) for (const f of info.buckets[b]) referencedFiles.add(f);
    rows.push(row);
  }

  if (rows.length === 0) return [];

  const summariesForPage = [...referencedFiles].map(fp => {
    const s = summaries.find(x => x.filePath === fp);
    return s ? { filePath: fp, summary: s.summary } : null;
  }).filter(Boolean);

  const page = toPage(rows, referencedFiles, summariesForPage);
  return page ? [page] : [];
}

// ── Config Entity Clustering ──────────────────────────────────────────────────

/**
 * Collects all configEntities into a single config_index page.
 *
 * Filters out entities that only appear in one file (those are local constants,
 * not shared config). Keeps secrets even if they appear once — they're
 * security-relevant either way. Entities are grouped by kind for the page.
 */
function clusterConfigEntities(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'configEntities',
    keyOf: e => `${e.name}|${e.kind ?? 'env'}`,
    roleBuckets: { readers: ['reader'], writers: ['writer'], definers: ['definer'] },
    initExtra: () => ({ defaultValue: undefined, valueShape: undefined }),
    mergeExtra: (extra, entity) => {
      const kind = entity.kind ?? 'env';
      // Secrets never carry a defaultValue. Non-secrets keep the first one seen.
      if (kind !== 'secret' && extra.defaultValue === undefined &&
          entity.defaultValue !== undefined && entity.defaultValue !== null) {
        extra.defaultValue = entity.defaultValue;
      }
      if (extra.valueShape === undefined && entity.valueShape) {
        extra.valueShape = entity.valueShape;
      }
    },
    toRow: (info) => {
      const kind = info.entity.kind ?? 'env';
      const allFiles = new Set([
        ...info.buckets.readers, ...info.buckets.writers, ...info.buckets.definers,
      ]);
      // Local-only constants are noise. Keep an entity if it's a secret (always
      // relevant for audit) or it appears in 2+ files (shared).
      if (kind !== 'secret' && allFiles.size < 2) return null;
      return {
        name:         info.entity.name,
        kind,
        readers:      [...info.buckets.readers],
        writers:      [...info.buckets.writers],
        definers:     [...info.buckets.definers],
        defaultValue: kind === 'secret' ? null : info.extra.defaultValue,
        valueShape:   info.extra.valueShape,
        isSecret:     kind === 'secret',
      };
    },
    toPage: (rows, referencedFiles, summariesForPage) => {
      // Group by kind so the page-writer can produce per-kind sections
      const byKind = { env: [], flag: [], const: [], secret: [] };
      for (const e of rows) (byKind[e.kind] ?? byKind.env).push(e);
      return {
        id:        `07-Config/Configuration`,
        title:     'Configuration',
        category:  '07-Config',
        type:      'config_index',
        filePaths: [...referencedFiles],
        configs: {
          total: rows.length,
          byKind: {
            secrets:   byKind.secret,
            envVars:   byKind.env,
            flags:     byKind.flag,
            constants: byKind.const,
          },
        },
        summaries: summariesForPage,
      };
    },
  });
}

// ── Topic Clustering ──────────────────────────────────────────────────────────

/**
 * Collects all messagingEntities into a single Topics index page.
 *
 * One entity = one row in the index, not one whole page. Specific entities can
 * still be linked via Obsidian section anchors like `[[Topics#forgot_password]]`.
 */
function clusterTopics(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'messagingEntities',
    keyOf: e => `${e.name}|${e.kind ?? 'topic'}`,
    roleBuckets: {
      producers: ['producer', 'publisher', 'both'],
      consumers: ['consumer', 'subscriber', 'both'],
    },
    initExtra: () => ({ platform: undefined, payloadTypes: new Set() }),
    mergeExtra: (extra, entity) => {
      if (entity.payloadType) extra.payloadTypes.add(entity.payloadType);
      if (entity.platform && !extra.platform) extra.platform = entity.platform;
    },
    toRow: (info) => ({
      name:         info.entity.name,
      kind:         info.entity.kind ?? 'topic',
      platform:     info.extra.platform,
      producers:    [...info.buckets.producers],
      consumers:    [...info.buckets.consumers],
      payloadTypes: [...info.extra.payloadTypes],
    }),
    toPage: (rows, referencedFiles, summariesForPage) => ({
      id:        `06-Topics/Topics`,
      title:     'Topics',
      category:  '06-Topics',
      type:      'topic_index',
      filePaths: [...referencedFiles],
      topics:    rows,
      summaries: summariesForPage,
    }),
  });
}

// ── API Endpoint Clustering ─────────────────────────────────────────────────────

/**
 * Collects all apiEndpoints into a single API index page — the project's
 * synchronous surface, the counterpart to the asynchronous Topics index.
 *
 * Each endpoint is keyed by `method|path`. The `handler` role marks files that
 * define/serve the endpoint; the `client` role marks files that call it (a
 * client-only endpoint signals an outbound dependency on another service). Both
 * sides are kept so the page can double as a cross-service dependency map.
 * Specific endpoints stay linkable via anchors like `[[API#POST /auth/login]]`.
 */
function clusterApiEndpoints(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'apiEndpoints',
    keyOf: e => `${e.method ?? ''}|${e.path ?? ''}`,
    roleBuckets: { handlers: ['handler'], callers: ['client'] },
    initExtra: () => ({
      kind: undefined, authRequired: undefined,
      requestType: undefined, responseType: undefined, statusCodes: new Set(),
    }),
    mergeExtra: (extra, entity) => {
      // Prefer the first non-empty value seen (handlers usually carry the contract).
      if (!extra.kind && entity.kind) extra.kind = entity.kind;
      if (extra.authRequired === undefined && entity.authRequired !== undefined) {
        extra.authRequired = entity.authRequired;
      }
      if (!extra.requestType && entity.requestType) extra.requestType = entity.requestType;
      if (!extra.responseType && entity.responseType) extra.responseType = entity.responseType;
      for (const c of (entity.statusCodes ?? [])) extra.statusCodes.add(c);
    },
    toRow: (info) => ({
      method:       info.entity.method,
      path:         info.entity.path,
      kind:         info.extra.kind ?? 'rest',
      authRequired: info.extra.authRequired,
      requestType:  info.extra.requestType,
      responseType: info.extra.responseType,
      statusCodes:  [...info.extra.statusCodes],
      handlers:     [...info.buckets.handlers],
      callers:      [...info.buckets.callers],
    }),
    toPage: (rows, referencedFiles, summariesForPage) => ({
      id:        `05-API/API`,
      title:     'API',
      category:  '05-API',
      type:      'api_index',
      filePaths: [...referencedFiles],
      endpoints: rows,
      summaries: summariesForPage,
    }),
  });
}

// ── Data Model Clustering ───────────────────────────────────────────────────────

/**
 * Collects all dataEntities (DB tables, ORM models, DTOs, enums) into a single
 * Data Model index page. Each entity carries its fields and relations, plus the
 * files that define and use it. Entities stay linkable via `[[Data Model#User]]`.
 */
function clusterDataEntities(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'dataEntities',
    keyOf: e => `${e.name}|${e.kind ?? 'model'}`,
    roleBuckets: { definers: ['definer'], readers: ['reader'], writers: ['writer'] },
    initExtra: () => ({ fields: new Set(), relations: new Map() }),
    mergeExtra: (extra, entity) => {
      for (const f of (entity.fields ?? [])) extra.fields.add(f);
      for (const r of (entity.relations ?? [])) {
        if (r && r.to) extra.relations.set(`${r.to}|${r.type ?? ''}`, r);
      }
    },
    toRow: (info) => ({
      name:      info.entity.name,
      kind:      info.entity.kind ?? 'model',
      definers:  [...info.buckets.definers],
      readers:   [...info.buckets.readers],
      writers:   [...info.buckets.writers],
      fields:    [...info.extra.fields],
      relations: [...info.extra.relations.values()],
    }),
    toPage: (rows, referencedFiles, summariesForPage) => {
      const byKind = { table: [], model: [], dto: [], enum: [] };
      for (const e of rows) (byKind[e.kind] ?? byKind.model).push(e);
      return {
        id:        `08-Data-Model/Data Model`,
        title:     'Data Model',
        category:  '08-Data-Model',
        type:      'data_model_index',
        filePaths: [...referencedFiles],
        entities: {
          total:  rows.length,
          byKind: { tables: byKind.table, models: byKind.model, dtos: byKind.dto, enums: byKind.enum },
        },
        summaries: summariesForPage,
      };
    },
  });
}

// ── Integration Clustering ───────────────────────────────────────────────────────

/**
 * Collects all integrations (third-party SaaS, other internal services,
 * notable libraries, infra) into a single Integrations index page — the
 * project's outbound dependency surface. Files that touch an integration are
 * collected regardless of role. Linkable via `[[Integrations#Stripe]]`.
 */
function clusterIntegrations(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'integrations',
    keyOf: e => `${e.name}|${e.kind ?? 'library'}`,
    roleBuckets: { usedBy: ['*'] },
    initExtra: () => ({ via: undefined, purpose: undefined, baseUrl: undefined }),
    mergeExtra: (extra, entity) => {
      if (!extra.via && entity.via) extra.via = entity.via;
      if (!extra.purpose && entity.purpose) extra.purpose = entity.purpose;
      if (!extra.baseUrl && entity.baseUrl) extra.baseUrl = entity.baseUrl;
    },
    toRow: (info) => ({
      name:    info.entity.name,
      kind:    info.entity.kind ?? 'library',
      via:     info.extra.via,
      purpose: info.extra.purpose,
      baseUrl: info.extra.baseUrl,
      usedBy:  [...info.buckets.usedBy],
    }),
    toPage: (rows, referencedFiles, summariesForPage) => {
      const byKind = { saas: [], 'internal-service': [], library: [], infra: [] };
      for (const e of rows) (byKind[e.kind] ?? byKind.library).push(e);
      return {
        id:        `09-Integrations/Integrations`,
        title:     'Integrations',
        category:  '09-Integrations',
        type:      'integration_index',
        filePaths: [...referencedFiles],
        integrations: {
          total:  rows.length,
          byKind: {
            saas:             byKind.saas,
            internalServices: byKind['internal-service'],
            libraries:        byKind.library,
            infra:            byKind.infra,
          },
        },
        summaries: summariesForPage,
      };
    },
  });
}

// ── Job Clustering ────────────────────────────────────────────────────────────────

/**
 * Collects all jobs (cron jobs, background workers, scheduled/daemon tasks) into
 * a single Jobs index page with schedule and trigger. Queue-triggered workers
 * pair naturally with the Topics page. Linkable via `[[Jobs#cleanup-expired-tokens]]`.
 */
function clusterJobs(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'jobs',
    keyOf: e => `${e.name}|${e.kind ?? 'worker'}`,
    roleBuckets: { definedIn: ['*'] },
    initExtra: () => ({ schedule: undefined, trigger: undefined, purpose: undefined }),
    mergeExtra: (extra, entity) => {
      if (!extra.schedule && entity.schedule) extra.schedule = entity.schedule;
      if (!extra.trigger && entity.trigger) extra.trigger = entity.trigger;
      if (!extra.purpose && entity.purpose) extra.purpose = entity.purpose;
    },
    toRow: (info) => ({
      name:      info.entity.name,
      kind:      info.entity.kind ?? 'worker',
      schedule:  info.extra.schedule,
      trigger:   info.extra.trigger,
      purpose:   info.extra.purpose,
      definedIn: [...info.buckets.definedIn],
    }),
    toPage: (rows, referencedFiles, summariesForPage) => ({
      id:        `10-Jobs/Jobs`,
      title:     'Jobs',
      category:  '10-Jobs',
      type:      'job_index',
      filePaths: [...referencedFiles],
      jobs:      rows,
      summaries: summariesForPage,
    }),
  });
}

// ── Permission Clustering ───────────────────────────────────────────────────────

/**
 * Collects all permissions (RBAC roles, auth scopes, permission strings) into a
 * single Permissions index page — the project's authorization surface, an audit
 * counterpart to the secret catalog on the Configuration page. The `definer`
 * role marks where a permission is declared; `guard` marks where it protects a
 * route/handler. Linkable via `[[Permissions#admin]]`.
 */
function clusterPermissions(summaries) {
  return clusterEntityIndex(summaries, {
    field: 'permissions',
    keyOf: e => `${e.name}|${e.kind ?? 'permission'}`,
    roleBuckets: { definers: ['definer'], guards: ['guard'] },
    toRow: (info) => ({
      name:     info.entity.name,
      kind:     info.entity.kind ?? 'permission',
      definers: [...info.buckets.definers],
      guards:   [...info.buckets.guards],
    }),
    toPage: (rows, referencedFiles, summariesForPage) => {
      const byKind = { role: [], scope: [], permission: [] };
      for (const e of rows) (byKind[e.kind] ?? byKind.permission).push(e);
      return {
        id:        `11-Permissions/Permissions`,
        title:     'Permissions',
        category:  '11-Permissions',
        type:      'permission_index',
        filePaths: [...referencedFiles],
        permissions: {
          total:  rows.length,
          byKind: { roles: byKind.role, scopes: byKind.scope, permissions: byKind.permission },
        },
        summaries: summariesForPage,
      };
    },
  });
}

// ── Main Clustering Function ───────────────────────────────────────────────────

/**
 * Groups FileSummary[] into PageSpec[].
 *
 * @param {FileSummary[]} summaries - file summaries read from raw/
 * @param {object}        config    - optional overrides
 * @param {string[]}      config.entryPoints     - entry-point file paths (from scan-result.json)
 * @param {Array}         config.flows           - user-supplied project flows
 * @param {Array}         config.concepts        - override default architecture concepts
 * @param {Array}         config.crossCutting    - override default cross-cutting topics
 * @param {number}        config.referenceRatio  - top fraction for reference pages (default 0.15)
 * @param {number}        config.maxRefPages     - hard cap on reference pages (default 25)
 * @returns {PageSpec[]}
 */
export function clusterConcepts(summaries, config = {}) {
  const pages = [];
  const entryPointSet = new Set(config.entryPoints ?? []);

  // ── 1. Project-specific Flows (only if user-supplied) ───────────────────
  for (const flow of (config.flows ?? [])) {
    const ftags   = new Set(flow.tags ?? []);
    const matched = summaries.filter(s =>
      (flow.keywords && matchKeywords(s, flow.keywords)) ||
      [...ftags].some(t => tagsOf(s).has(t))
    );
    if (matched.length === 0) continue;
    pages.push({
      id:        `01-Flows/${flow.title}`,
      title:     flow.title,
      category:  '01-Flows',
      type:      'flow',
      filePaths: [...new Set(matched.map(s => s.filePath))],
      summaries: matched.map(s => ({
        filePath: s.filePath, summary: s.summary, fanIn: s.fanIn ?? 0,
      })),
    });
  }

  // ── 2. Architecture Concepts (auto-derived from tags) ───────────────────
  const conceptGroups = config.concepts ?? ARCHITECTURE_TAG_GROUPS;
  for (const concept of conceptGroups) {
    const ctags   = new Set(concept.tags);
    const matched = summaries
      .filter(s => [...ctags].some(t => tagsOf(s).has(t)))
      .sort((a, b) => (b.fanIn ?? 0) - (a.fanIn ?? 0))
      .slice(0, 15);

    if (matched.length < 2) continue;

    pages.push({
      id:        `02-Architecture/${concept.title}`,
      title:     concept.title,
      category:  '02-Architecture',
      type:      'concept',
      filePaths: matched.map(s => s.filePath),
      summaries: matched.map(s => ({
        filePath: s.filePath, summary: s.summary, tags: s.tags, fanIn: s.fanIn ?? 0,
      })),
    });
  }

  // ── 3. Cross-Cutting Concerns ─────────────────────────────────────────────
  const crossGroups = config.crossCutting ?? CROSS_CUTTING_TAG_GROUPS;
  for (const item of crossGroups) {
    const ctags   = new Set(item.tags);
    const matched = summaries
      .filter(s => [...ctags].some(t => tagsOf(s).has(t)))
      .slice(0, 10);

    if (matched.length < 2) continue;

    pages.push({
      id:        `03-Cross-Cutting/${item.title}`,
      title:     item.title,
      category:  '03-Cross-Cutting',
      type:      'cross_cutting',
      filePaths: [...new Set(matched.map(s => s.filePath))],
      summaries: matched.map(s => ({ filePath: s.filePath, summary: s.summary })),
    });
  }

  // ── 4. Technical Reference (importance-scored, no magic threshold) ──────
  const referenceRatio = config.referenceRatio ?? 0.15;
  const maxRefPages    = config.maxRefPages ?? 25;
  const targetCount    = Math.max(3, Math.ceil(summaries.length * referenceRatio));
  const limit          = Math.min(targetCount, maxRefPages);

  const ranked = summaries
    .map(s => ({ summary: s, score: importanceScore(s, entryPointSet) }))
    .filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  for (const { summary: s, score } of ranked) {
    const name = s.filePath.split('/').pop();
    pages.push({
      id:           `04-Reference/${name}`,
      title:        name,
      category:     '04-Reference',
      type:         'reference',
      filePaths:    [s.filePath],
      primaryFile:  s.filePath,
      fanIn:        s.fanIn ?? 0,
      isCore:       s.isCore ?? false,
      score,
      summaries: [{
        filePath:   s.filePath,
        summary:    s.summary,
        keyExports: s.keyExports,
        tags:       s.tags,
      }],
    });
  }

  // ── 5. API Endpoints (synchronous surface) ────────────────────────────────
  const apiPages = clusterApiEndpoints(summaries);
  pages.push(...apiPages);

  // ── 6. Topics (messaging entities — asynchronous surface) ─────────────────
  const topicPages = clusterTopics(summaries);
  pages.push(...topicPages);

  // ── 7. Config Entities (env vars, flags, constants, secrets) ──────────────
  const configPages = clusterConfigEntities(summaries);
  pages.push(...configPages);

  // ── 8. Data Model (tables, models, DTOs, enums) ───────────────────────────
  pages.push(...clusterDataEntities(summaries));

  // ── 9. Integrations (third-party SaaS, internal services, infra) ──────────
  pages.push(...clusterIntegrations(summaries));

  // ── 10. Jobs (cron, workers, scheduled tasks) ─────────────────────────────
  pages.push(...clusterJobs(summaries));

  // ── 11. Permissions (roles, scopes, permission strings) ───────────────────
  pages.push(...clusterPermissions(summaries));

  return pages;
}

/**
 * Builds a wikilink map from page specs.
 * title → category/title
 */
export function buildWikilinkMap(pages) {
  return Object.fromEntries(pages.map(p => [p.title, p.id]));
}
