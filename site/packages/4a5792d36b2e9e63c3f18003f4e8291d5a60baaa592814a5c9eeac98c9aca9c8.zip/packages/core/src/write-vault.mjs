/**
 * write-vault.mjs — Vault file I/O and Obsidian config generation.
 */

import { mkdirSync, writeFileSync } from 'fs';
import { join } from 'path';

const OBSIDIAN_APP = {
  showInlineTitle: true,
  showLineNumber:  false,
};

const OBSIDIAN_GRAPH = {
  "collapse-filter": false,
  showTags:          true,
  showAttachments:   false,
  hideUnresolved:    false,
  showOrphans:       true,
};

/**
 * Creates the vault directory and writes .obsidian config files.
 */
export function initVault(vaultDir) {
  mkdirSync(vaultDir, { recursive: true });
  const obsDir = join(vaultDir, '.obsidian');
  mkdirSync(obsDir, { recursive: true });
  writeFileSync(join(obsDir, 'app.json'),   JSON.stringify(OBSIDIAN_APP,   null, 2));
  writeFileSync(join(obsDir, 'graph.json'), JSON.stringify(OBSIDIAN_GRAPH, null, 2));
}

/**
 * Writes a single markdown page into the vault.
 * Overwrites if the file already exists.
 */
export function writePage(vaultDir, category, filename, content) {
  const catDir = join(vaultDir, category);
  mkdirSync(catDir, { recursive: true });
  const fname = filename.endsWith('.md') ? filename : filename + '.md';
  writeFileSync(join(catDir, fname), content, 'utf-8');
}

/**
 * Writes the index.md (Map of Content) page.
 *
 * `projects` (optional) is `[{ name, fileCount }]` for multi-project vaults —
 * when more than one is present, a "Projects" table is rendered so readers can
 * see which services the combined vault covers.
 */
export function writeIndex(vaultDir, pages, graphStats, projects = []) {
  const { nodeCount, edgeCount } = graphStats;

  const byCategory = {};
  for (const p of pages) (byCategory[p.category] ??= []).push(p.title);

  const lines = [
    '---',
    'title: Wiki — Overview',
    'tags: [index, moc]',
    '---',
    '',
    '# Wiki',
    '',
    `> ${pages.length} pages · ${nodeCount} components · ${edgeCount} relationships`,
    '',
  ];

  if (projects.length > 1) {
    lines.push('## Projects', '', '| Project | Files |', '|---------|-------|');
    for (const p of projects) lines.push(`| ${p.name} | ${p.fileCount} |`);
    lines.push('');
  }

  for (const cat of Object.keys(byCategory).sort()) {
    lines.push(`## ${cat}`, '');
    for (const title of byCategory[cat]) {
      lines.push(`- [[${title}]]`);
    }
    lines.push('');
  }

  writeFileSync(join(vaultDir, 'index.md'), lines.join('\n'), 'utf-8');
}
