/**
 * detect-project.mjs — Deterministic project metadata detection.
 *
 * Replaces the previous project-scanner LLM agent: framework detection,
 * entry point detection, and import map can all be done with regex.
 * No LLM needed for these — they're mechanical lookups.
 */

import { readFileSync, existsSync } from 'fs';
import { join, dirname, resolve } from 'path';

// ── Framework Detection ──────────────────────────────────────────────────────

/**
 * Reads common manifest files and extracts framework/library names.
 */
export function detectFrameworks(projectRoot) {
  const frameworks = new Set();

  // package.json (Node.js / TypeScript / JavaScript)
  const pkgPath = join(projectRoot, 'package.json');
  if (existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(readFileSync(pkgPath, 'utf-8'));
      const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
      for (const name of Object.keys(deps)) frameworks.add(name);
    } catch {/* ignore parse errors */}
  }

  // go.mod (Go) — supports both `require (...)` blocks and single-line `require X v1.2.3`
  const goMod = join(projectRoot, 'go.mod');
  if (existsSync(goMod)) {
    const content = readFileSync(goMod, 'utf-8');
    // Single-line: `require github.com/foo/bar v1.2.3`
    for (const m of content.matchAll(/^\s*require\s+(\S+)\s+v[\d.]+/gm)) {
      frameworks.add(m[1]);
    }
    // Block: `\t github.com/foo/bar v1.2.3` inside a `require (...)` block
    for (const m of content.matchAll(/^\s+([a-zA-Z0-9._/-]+\/[a-zA-Z0-9._-]+)\s+v[\d.]+/gm)) {
      frameworks.add(m[1]);
    }
  }

  // pyproject.toml / requirements.txt (Python)
  const pyproject = join(projectRoot, 'pyproject.toml');
  if (existsSync(pyproject)) {
    const content = readFileSync(pyproject, 'utf-8');
    const matches = content.matchAll(/^([a-zA-Z0-9_-]+)\s*=/gm);
    for (const m of matches) {
      if (!['name','version','description','authors','license'].includes(m[1])) {
        frameworks.add(m[1]);
      }
    }
  }
  const reqTxt = join(projectRoot, 'requirements.txt');
  if (existsSync(reqTxt)) {
    const content = readFileSync(reqTxt, 'utf-8');
    for (const line of content.split('\n')) {
      const name = line.trim().split(/[=<>!~\s]/)[0];
      if (name && !name.startsWith('#')) frameworks.add(name);
    }
  }

  // Cargo.toml (Rust)
  const cargo = join(projectRoot, 'Cargo.toml');
  if (existsSync(cargo)) {
    const content = readFileSync(cargo, 'utf-8');
    const matches = content.matchAll(/^([a-zA-Z0-9_-]+)\s*=/gm);
    for (const m of matches) {
      if (!['name','version','edition','authors','license'].includes(m[1])) {
        frameworks.add(m[1]);
      }
    }
  }

  return [...frameworks].sort();
}

// ── Entry Point Detection ────────────────────────────────────────────────────

const ENTRY_PATTERNS = [
  // JavaScript / TypeScript
  'src/index.ts', 'src/index.js', 'src/index.tsx', 'src/index.jsx',
  'src/main.ts', 'src/main.js',
  'src/App.tsx', 'src/App.jsx',
  'pages/_app.js', 'pages/_app.tsx',
  'app/page.tsx', 'app/page.jsx',
  'index.js', 'index.ts',
  // Go
  'main.go',
  // Python
  'main.py', 'manage.py', 'app.py', 'wsgi.py', 'asgi.py', 'run.py', '__main__.py',
  // Rust
  'src/main.rs', 'src/lib.rs',
  // Ruby / PHP
  'config.ru', 'index.php',
];

export function detectEntryPoints(projectRoot, files) {
  const fileSet = new Set(files.map(f => f.path));
  const entries = [];

  for (const pattern of ENTRY_PATTERNS) {
    if (fileSet.has(pattern)) entries.push(pattern);
  }

  // Go: cmd/main.go OR cmd/<sub>/main.go
  for (const f of files) {
    if (/^cmd\/(?:[^/]+\/)?main\.go$/.test(f.path)) entries.push(f.path);
  }

  return entries;
}

// ── Project Description ──────────────────────────────────────────────────────

/**
 * Reads README and extracts a one-line description.
 */
export function detectDescription(projectRoot) {
  for (const name of ['README.md', 'README.rst', 'readme.md', 'README.txt']) {
    const p = join(projectRoot, name);
    if (!existsSync(p)) continue;
    const content = readFileSync(p, 'utf-8').slice(0, 3000);

    // Skip H1 heading, find first non-empty paragraph
    const lines = content.split('\n');
    let foundHeading = false;
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith('#')) {
        if (!foundHeading) { foundHeading = true; continue; }
        break; // next heading reached
      }
      // First text content
      return trimmed.replace(/[*_`]/g, '').slice(0, 200);
    }
  }
  return '';
}

// ── Import Map ────────────────────────────────────────────────────────────────

const IMPORT_PATTERNS = {
  go:         [/^\s*import\s+"([^"]+)"/gm, /^\s+"([^"]+)"/gm],
  javascript: [/^\s*import\s+(?:.+from\s+)?['"]([^'"]+)['"]/gm,
               /require\(['"]([^'"]+)['"]\)/gm],
  typescript: [/^\s*import\s+(?:.+from\s+)?['"]([^'"]+)['"]/gm,
               /require\(['"]([^'"]+)['"]\)/gm],
  python:     [/^\s*from\s+([^\s]+)\s+import/gm,
               /^\s*import\s+([^\s,]+)/gm],
  rust:       [/^\s*use\s+([^;:]+)/gm],
};

/**
 * Reads go.mod and extracts the module name. Returns null if not Go or no go.mod.
 */
function readGoModuleName(projectRoot) {
  const goMod = join(projectRoot, 'go.mod');
  if (!existsSync(goMod)) return null;
  try {
    const content = readFileSync(goMod, 'utf-8');
    const match = content.match(/^module\s+(\S+)/m);
    return match ? match[1] : null;
  } catch { return null; }
}

/**
 * Builds an import map: { sourcePath -> [project-internal target paths] }.
 * Heuristic resolution: relative imports become file paths, package-style
 * imports are dropped (external).
 */
export function buildImportMap(projectRoot, files) {
  const fileSet = new Set(files.map(f => f.path));
  const importMap = {};
  const goModule = readGoModuleName(projectRoot);

  for (const f of files) {
    importMap[f.path] = [];
    const patterns = IMPORT_PATTERNS[f.language];
    if (!patterns) continue;

    let content;
    try {
      content = readFileSync(join(projectRoot, f.path), 'utf-8');
    } catch { continue; }

    const found = new Set();
    for (const re of patterns) {
      const matches = content.matchAll(re);
      for (const m of matches) found.add(m[1]);
    }

    const fileDir = dirname(f.path);

    for (const imp of found) {
      const resolved = resolveImport(imp, fileDir, fileSet, f.language, goModule);
      if (resolved && fileSet.has(resolved)) {
        importMap[f.path].push(resolved);
      }
    }
    importMap[f.path] = [...new Set(importMap[f.path])];
  }
  return importMap;
}

function resolveImport(imp, fromDir, fileSet, language, goModule) {
  // Relative imports for JS/TS
  if (imp.startsWith('./') || imp.startsWith('../')) {
    const base = resolve('/' + fromDir, imp).slice(1); // strip leading /
    for (const ext of ['', '.js', '.ts', '.tsx', '.jsx', '.mjs',
                       '/index.js', '/index.ts']) {
      if (fileSet.has(base + ext)) return base + ext;
    }
  }
  // Relative for Python
  if (language === 'python' && imp.startsWith('.')) {
    const stripped = imp.replace(/^\.+/, '');
    const candidates = [
      stripped.replace(/\./g, '/') + '.py',
      stripped.replace(/\./g, '/') + '/__init__.py',
    ];
    for (const c of candidates) if (fileSet.has(c)) return c;
  }
  // Go imports
  if (language === 'go') {
    // Strip module prefix if present (e.g. "async-service/infra/rabbit_mq" → "infra/rabbit_mq")
    let rel = imp;
    if (goModule && imp.startsWith(goModule + '/')) {
      rel = imp.slice(goModule.length + 1);
    }
    // External package? Skip.
    if (rel.startsWith('github.com/') || rel.includes('.com/') || rel.startsWith('golang.org/')) {
      return null;
    }
    // Match against file paths: try files inside that directory
    for (const path of fileSet) {
      if (path.startsWith(rel + '/') && path.endsWith('.go')) return path;
      if (path === rel + '.go') return path;
    }
  }
  return null;
}

// ── Top-Level: enrich scan result ─────────────────────────────────────────────

/**
 * Enriches a scan result with description, frameworks, entry points, and import map.
 * Returns a new object (does not mutate input).
 */
export function detectProjectMetadata(projectRoot, scanResult) {
  return {
    ...scanResult,
    description: scanResult.description || detectDescription(projectRoot),
    frameworks:  scanResult.frameworks?.length ? scanResult.frameworks : detectFrameworks(projectRoot),
    entryPoints: scanResult.entryPoints?.length ? scanResult.entryPoints : detectEntryPoints(projectRoot, scanResult.files),
    importMap:   Object.keys(scanResult.importMap ?? {}).length ? scanResult.importMap : buildImportMap(projectRoot, scanResult.files),
  };
}
