/**
 * write-raw.mjs — Raw layer I/O (read and write).
 *
 * The raw layer holds two types of content:
 *   - Plugin-generated: raw/<project-name>/  (kebab-case project name)
 *   - User-provided:    raw/05-Meeting Notes/ (numeric prefix)
 */

import {
  mkdirSync, writeFileSync, readFileSync,
  existsSync, readdirSync,
} from 'fs';
import { join, relative, dirname } from 'path';
import { createHash } from 'crypto';

// ── Helpers ───────────────────────────────────────────────────────────────────

function ensureDir(dir) {
  mkdirSync(dir, { recursive: true });
}

function writeJson(filePath, data) {
  ensureDir(dirname(filePath));
  writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

function readJson(filePath) {
  if (!existsSync(filePath)) return null;
  try {
    return JSON.parse(readFileSync(filePath, 'utf-8'));
  } catch (err) {
    // Treat malformed JSON the same as "not found" — callers fall back to
    // empty schemas. Surface a warning on stderr so a corrupted file is
    // noticed instead of silently ignored.
    process.stderr.write(
      `[vault-anything] warning: ${filePath} is not valid JSON (${err.message}). ` +
      `Falling back to default. If this was hand-edited, fix the file.\n`
    );
    return null;
  }
}

function sha256(filePath) {
  try {
    const content = readFileSync(filePath);
    return 'sha256:' + createHash('sha256').update(content).digest('hex');
  } catch {
    return '';
  }
}

// ── Project folder (plugin-generated) ────────────────────────────────────────

/**
 * Writes raw/<project>/relationships.json
 */
export function writeRelationships(rawDir, projectName, relationships) {
  writeJson(join(rawDir, projectName, 'relationships.json'), relationships);
}

/**
 * Writes raw/<project>/page-plan.json
 */
export function writePagePlan(rawDir, projectName, pagePlan) {
  writeJson(join(rawDir, projectName, 'page-plan.json'), pagePlan);
}

/**
 * Writes raw/<project>/scan-result.json
 */
export function writeScanResult(rawDir, projectName, scanResult) {
  writeJson(join(rawDir, projectName, 'scan-result.json'), scanResult);
}

// ── Meta & Manifest ───────────────────────────────────────────────────────────

/**
 * Reads meta.json. Returns an empty schema if not found.
 */
export function readMeta(rawDir) {
  return readJson(join(rawDir, 'meta.json')) ?? {
    projects:    {},
    rawManifest: {},
  };
}

/**
 * Writes meta.json.
 */
export function writeMeta(rawDir, meta) {
  writeJson(join(rawDir, 'meta.json'), meta);
}

/**
 * Updates lastCommitHash and analyzedAt for a project in meta.json.
 *
 * For multi-project runs where the root isn't a git repo, `subRepos`
 * (an array of { name, hash }) records the HEAD of each detected sub-repo so a
 * future multi-project incremental update can diff each one independently.
 */
export function updateProjectMeta(rawDir, projectName, commitHash, subRepos = []) {
  const meta = readMeta(rawDir);
  meta.projects[projectName] = {
    lastCommitHash: commitHash,
    analyzedAt:     new Date().toISOString(),
    ...(subRepos.length ? { subRepos } : {}),
  };
  writeMeta(rawDir, meta);
}

// ── Raw Manifest (user static files) ─────────────────────────────────────────

/**
 * Returns true if the directory name uses a numeric prefix (user folder).
 * e.g. "05-Meeting Notes" → true, "auth-service" → false
 */
export function isUserDir(dirName) {
  return /^\d{2}-/.test(dirName);
}

/**
 * Lists all user-provided static files under raw/.
 * @returns {{ relPath: string, absPath: string, hash: string }[]}
 */
export function listUserFiles(rawDir) {
  const files = [];
  if (!existsSync(rawDir)) return files;

  for (const entry of readdirSync(rawDir, { withFileTypes: true })) {
    if (!entry.isDirectory() || !isUserDir(entry.name)) continue;
    walkUserDir(join(rawDir, entry.name), rawDir, files);
  }
  return files;
}

function walkUserDir(dir, rawDir, results) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      walkUserDir(full, rawDir, results);
    } else if (entry.isFile()) {
      results.push({
        relPath: relative(rawDir, full),
        absPath: full,
        hash:    sha256(full),
      });
    }
  }
}

/**
 * Diffs the raw manifest against current files on disk.
 * Returns added / changed / removed file lists.
 */
export function diffRawManifest(rawDir, meta) {
  const current  = listUserFiles(rawDir);
  const manifest = meta.rawManifest ?? {};

  const added   = [];
  const changed = [];
  const removed = [];

  const currentPaths = new Set(current.map(f => f.relPath));

  for (const file of current) {
    const existing = manifest[file.relPath];
    if (!existing) {
      added.push(file);
    } else if (existing.hash !== file.hash) {
      changed.push({ ...file, affectsPages: existing.affectsPages ?? [] });
    }
  }

  for (const relPath of Object.keys(manifest)) {
    if (!currentPaths.has(relPath)) {
      removed.push({ relPath, affectsPages: manifest[relPath].affectsPages ?? [] });
    }
  }

  return { added, changed, removed };
}

/**
 * Adds or updates a file entry in the raw manifest.
 */
export function updateRawManifest(rawDir, meta, relPath, hash, affectsPages) {
  meta.rawManifest[relPath] = {
    hash,
    affectsPages,
    ingestedAt: new Date().toISOString(),
  };
  writeMeta(rawDir, meta);
}

// ── Reading raw (for generate phase) ─────────────────────────────────────────

/**
 * Reads and merges all file-summary batches for a project.
 */
export function readFileSummaries(rawDir, projectName) {
  const dir = join(rawDir, projectName, 'file-summaries');
  if (!existsSync(dir)) return [];

  const all = [];
  for (const f of readdirSync(dir)) {
    if (!f.endsWith('.json')) continue;
    const batch = readJson(join(dir, f));
    if (Array.isArray(batch)) all.push(...batch);
  }
  return all;
}

/**
 * Reads the content of all user-provided static files.
 */
export function readUserFileContents(rawDir) {
  const files = listUserFiles(rawDir);
  return files.map(f => ({
    relPath: f.relPath,
    content: readFileSync(f.absPath, 'utf-8'),
    hash:    f.hash,
  }));
}
