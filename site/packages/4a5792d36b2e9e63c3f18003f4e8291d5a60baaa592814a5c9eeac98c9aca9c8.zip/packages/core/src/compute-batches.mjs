/**
 * compute-batches.mjs — Groups files into file-analyzer agent batches.
 *
 * Target: each batch fits within the agent context window,
 * and files with import dependencies are grouped together.
 */

// ── Constants ─────────────────────────────────────────────────────────────────

const MAX_LINES_PER_BATCH = 3000;   // Max total lines per batch
const MAX_FILES_PER_BATCH = 20;     // Max files per batch
const MIN_FILES_PER_BATCH = 2;      // Batches smaller than this are merged

// Categories excluded from analysis
const SKIP_CATEGORIES = new Set(['other']);

// ── Helpers ──────────────────────────────────────────────────────────────

function totalLines(files) {
  return files.reduce((s, f) => s + (f.sizeLines ?? 0), 0);
}

/**
 * Builds a dependency graph from importMap.
 * { filePath → Set<filePath> }
 */
function buildDependencyGraph(files, importMap) {
  const filePaths = new Set(files.map(f => f.path));
  const deps = {};

  for (const f of files) {
    deps[f.path] = new Set();
    const imports = importMap[f.path] ?? [];
    for (const imp of imports) {
      if (filePaths.has(imp)) {
        deps[f.path].add(imp);
      }
    }
  }
  return deps;
}

/**
 * Greedy cluster: put interdependent files in the same batch.
 * Simple approach: importers and importees go into the same group.
 */
function clusterByDependencies(files, importMap) {
  const deps  = buildDependencyGraph(files, importMap);
  const visited = new Set();
  const clusters = [];

  function collect(filePath, cluster) {
    if (visited.has(filePath)) return;
    visited.add(filePath);
    cluster.push(filePath);
    for (const dep of (deps[filePath] ?? [])) {
      collect(dep, cluster);
    }
  }

  // Process high fan-in files first (imported by many others)
  const sortedFiles = [...files].sort((a, b) => {
    const aFanIn = Object.values(deps).filter(d => d.has(a.path)).length;
    const bFanIn = Object.values(deps).filter(d => d.has(b.path)).length;
    return bFanIn - aFanIn;
  });

  for (const f of sortedFiles) {
    if (visited.has(f.path)) continue;
    const cluster = [];
    collect(f.path, cluster);
    clusters.push(cluster);
  }

  return clusters;
}

// ── Main Function ─────────────────────────────────────────────────────────────

/**
 * Splits file list into agent batches.
 *
 * @param {ScanFile[]}  files     - files from scanProject output
 * @param {ImportMap}   importMap - importMap from scan-result.json
 * @returns {Batch[]}
 */
export function computeBatches(files, importMap = {}) {
  // Filter out non-analyzable files
  const analyzable = files.filter(f => !SKIP_CATEGORIES.has(f.category));

  // Cluster files by dependency graph
  const clusters = clusterByDependencies(analyzable, importMap);

  const batches  = [];
  let current    = [];
  let currentLines = 0;

  function flush() {
    if (current.length === 0) return;
    batches.push([...current]);
    current = [];
    currentLines = 0;
  }

  for (const cluster of clusters) {
    const clusterFiles = cluster
      .map(path => analyzable.find(f => f.path === path))
      .filter(Boolean);

    const clusterLines = totalLines(clusterFiles);

    // Cluster too large — split into fixed-size chunks
    if (clusterLines > MAX_LINES_PER_BATCH || clusterFiles.length > MAX_FILES_PER_BATCH) {
      flush();
      // Split large cluster into fixed-size chunks
      for (let i = 0; i < clusterFiles.length; i += MAX_FILES_PER_BATCH) {
        batches.push(clusterFiles.slice(i, i + MAX_FILES_PER_BATCH));
      }
      continue;
    }

    // Current batch full — start a new one
    if (
      current.length > 0 &&
      (currentLines + clusterLines > MAX_LINES_PER_BATCH ||
       current.length + clusterFiles.length > MAX_FILES_PER_BATCH)
    ) {
      flush();
    }

    current.push(...clusterFiles);
    currentLines += clusterLines;
  }

  flush();

  // Merge small batches
  const merged = [];
  let pending = [];
  let pendingLines = 0;

  for (const batch of batches) {
    const batchLines = totalLines(batch);

    if (batch.length < MIN_FILES_PER_BATCH) {
      if (pendingLines + batchLines <= MAX_LINES_PER_BATCH &&
          pending.length + batch.length <= MAX_FILES_PER_BATCH) {
        pending.push(...batch);
        pendingLines += batchLines;
      } else {
        if (pending.length) {
          merged.push(pending);
          pending = [];
          pendingLines = 0;
        }
        pending.push(...batch);
        pendingLines = batchLines;
      }
    } else {
      if (pending.length) {
        merged.push(pending);
        pending = [];
        pendingLines = 0;
      }
      merged.push(batch);
    }
  }
  if (pending.length) merged.push(pending);

  // Build batch objects
  return merged.map((files, idx) => ({
    batchIndex: idx + 1,
    totalBatches: merged.length,
    files: files.map(f => ({
      path:      f.path,
      language:  f.language,
      category:  f.category,
      sizeLines: f.sizeLines ?? 0,
    })),
    totalLines: totalLines(files),
    importData: Object.fromEntries(
      files.map(f => [f.path, (importMap[f.path] ?? []).filter(
        imp => files.some(f2 => f2.path === imp) // intra-batch imports only
      )])
    ),
    crossBatchImports: Object.fromEntries(
      files.map(f => [f.path, (importMap[f.path] ?? []).filter(
        imp => !files.some(f2 => f2.path === imp) // cross-batch imports
      )])
    ),
  }));
}

/**
 * Summarizes the batch plan.
 */
export function summarizeBatches(batches) {
  const total = batches.reduce((s, b) => s + b.files.length, 0);
  const lines = batches.reduce((s, b) => s + b.totalLines, 0);
  return {
    totalBatches: batches.length,
    totalFiles:   total,
    totalLines:   lines,
    sizes: batches.map(b => b.files.length),
  };
}
