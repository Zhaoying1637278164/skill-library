## Overview

The `Utils.Evaluator` evaluates templates (`{{ data.x }}`, `{% code %}`), JavaScript expressions, and JSONLogic. The renderer (`packages/formio.js/src/utils/Evaluator.js`) extends the core evaluator with a cached underscore template compiler. The singleton is mutable — replace it with `registerEvaluator` to install a custom one (e.g., a sandboxed evaluator). Sourced from `packages/core/src/utils/Evaluator.ts` and `packages/formio.js/src/utils/Evaluator.js` in the Form.io source code.

**This module compiles strings into running code.** `evaluate`, `evaluator`, and template interpolation all execute whatever expression they are handed, so the expression source must be trusted — a form definition from your own project, or a literal in your app — never a submitted value, a query parameter, or a definition fetched from a host you do not control. Two consequences worth stating up front: `interpolateString` emits raw, unescaped output, so pair it with `Utils.sanitize` before rendering (see below); and `registerEvaluator` swaps the singleton **process-wide**, so any library that overrides it changes how every later template, condition, and formula is evaluated — call it once at your own bootstrap, and treat a dependency that calls it as a supply-chain concern.

## Imports

```ts
import { Utils, registerEvaluator } from '@formio/js/utils';
```

`Utils.Evaluator` is the SDK's mutable singleton; the top-level `registerEvaluator(custom)` export reassigns the SDK's internal reference so subsequent SDK calls (template interpolation, conditional evaluation, formulas) route through the override. (Note: `registerEvaluator` is a module-level export of `@formio/js/utils`, not a property of the `Utils` namespace.)

Caveat under ESM: `Utils.Evaluator` and named imports like `import { Evaluator } from '@formio/js/utils'` are snapshots captured at module load. After `registerEvaluator(custom)`, those existing references are not rebound — the swap is observable through SDK-internal call sites, not through references held by your code. Call `registerEvaluator` once at bootstrap, before any other SDK code reads `Utils.Evaluator`.

## API

`Utils.Evaluator` (instance of `DefaultEvaluator`):

- `Evaluator.evaluator(func: string | Function, ...params: string): Function` — compile a function from a string body and named params.
- `Evaluator.interpolateString(template: string, data: any, options?): string` — replace `{{ … }}` and `{% … %}` markers with values from `data`. Honors `options.noeval` to forbid `eval()` paths.
- `Evaluator.interpolate(template: string | Function, data: any, options?): any` — smart wrapper: strings go to `interpolateString`, functions are called with `data`. The renderer override caches compiled underscore templates by content hash.
- `Evaluator.evaluate(func, args?, ret?, interpolate?, context?, options?): any` — execute a function, code string, or JSONLogic expression. `args` becomes the variables in scope; `ret` is a variable name whose value to return; `context` is `this` inside the function.
- `Evaluator.execute(func, args, context?, options?): any` — call a previously compiled / function reference with `args`.

Template syntax (core `Evaluator.ts`):

- `{{ data.firstName }}` — variable interpolation, inserted raw (lodash `interpolate`); NOT HTML-escaped.
- `{{{ data.htmlField }}}` — HTML-escaped interpolation (lodash `escape`).
- `{% if (data.x) { %} … {% } %}` — code execution.
- `{{ data.method() }}` — function-call interpolation; suppressed when `options.noeval` is true.

Hot-swap helpers (`packages/core/src/utils/Evaluator.ts` and the renderer index re-export):

- `registerEvaluator(override: DefaultEvaluator): void` — top-level module export of `@formio/js/utils` (not a property of `Utils`). Install a custom evaluator (e.g., one that runs expressions in a Web Worker).
- `Utils.interpolate(template, data, options?)` — module-level convenience that delegates to `Utils.Evaluator.interpolate`.
- `Utils.evaluate(func, args?, ret?, interpolate?, context?, options?)` — module-level convenience that delegates to `Utils.Evaluator.evaluate`.

## Examples

### Install a sandboxed evaluator

Call `registerEvaluator(custom)` at bootstrap, before any other SDK code reads `Utils.Evaluator`. The override takes effect for subsequent SDK-internal evaluations (template interpolation, conditionals, formulas). Existing references held by application code are not retroactively rebound. Installing this one disables JavaScript expressions in the application's own form definitions too — `calculateValue`, `validate.custom`, and custom `logic` stop evaluating, because the renderer routes them through the same singleton. Adopt it for an application whose forms are JSONLogic-only, or narrow the check to the expressions you want refused.

```ts
import { registerEvaluator, DefaultEvaluator } from '@formio/js/utils';

class SandboxedEvaluator extends DefaultEvaluator {
  evaluate(func, args, ret, interpolate, context, options = {}) {
    // Reject any non-JSONLogic input.
    if (typeof func === 'string' || typeof func === 'function') {
      throw new Error('JavaScript expressions are disabled.');
    }
    return super.evaluate(func, args, ret, interpolate, context, options);
  }
}

registerEvaluator(new SandboxedEvaluator({ noeval: true }));
```

### Evaluate a JSONLogic expression

JSONLogic is data, not code — the shape to prefer for any rule that arrives at runtime rather than being written into the application.

```ts
import { Utils } from '@formio/js/utils';

const ok = Utils.Evaluator.evaluate({ '>=': [{ var: 'data.age' }, 18] }, { data: { age: 21 } });
console.log(ok); // true
```

### Interpolate a template string

The template is an authored literal in the application's own source. A template that arrives at runtime is not interpolated at all.

```ts
import { Utils } from '@formio/js/utils';

const greeting = Utils.Evaluator.interpolateString('Hello {{ data.firstName }}!', {
  data: { firstName: 'Alice' },
});
console.log(greeting); // "Hello Alice!"
```

### Evaluate a custom validation expression

The expression is an authored literal — the same `validate.custom` string you would write into one of your own form definitions. It is never a value read from a user, a submission, or a request.

```ts
import { Utils } from '@formio/js/utils';

const valid = Utils.Evaluator.evaluate('valid = data.age >= 18;', { data: { age: 21 } }, 'valid');
console.log(valid); // true
```

### Compile and reuse a function

The function body is an authored literal. `evaluator` is `new Function` with a friendlier signature, so a runtime string here is remote code execution.

```ts
import { Utils } from '@formio/js/utils';

const fn = Utils.Evaluator.evaluator('return data.first + " " + data.last;', 'data');
console.log(fn({ first: 'Ada', last: 'Lovelace' })); // "Ada Lovelace"
```

### `interpolateString` does NOT HTML-escape — pair it with `Utils.sanitize`

`Utils.Evaluator.interpolateString` substitutes `{{ … }}` values into the template **verbatim** — it does not HTML-escape user-supplied data. If you are rendering the interpolated output as HTML, run it through `Utils.sanitize` (which wraps DOMPurify with Form.io's defaults).

Use this pattern: `interpolateString` for value substitution → `sanitize` for HTML-safety.

```ts
import { Utils } from '@formio/js/utils';

const raw = Utils.Evaluator.interpolateString('<p>Hello {{ data.firstName }}</p>', {
  data: { firstName: '<img src=x onerror=alert(1)>' },
});
// raw === '<p>Hello <img src=x onerror=alert(1)></p>' — DANGEROUS to render as-is.

const safe = Utils.sanitize(raw, {});
console.log(safe.toString());
// '<p>Hello <img src="x"></p>' — the onerror handler is stripped.
```

The `{ noeval: true }` option controls only function-call interpolation (`{{ data.method() }}`); it does not affect HTML escaping. If you need plain-text output, call `String(value)` yourself, strip HTML with `Utils.removeHTML(raw)`, or write the marker as `{{{ … }}}`, which HTML-escapes the value on the way in.
