# ionden-skills

Three agent skills for Claude Code and OpenAI Codex. Each one loads only when a task needs it.

- `subagent-optimizer` audits Claude Code subagents and Codex custom agents. It sets a tight `tools` allowlist, removes keys that make Codex skip an agent, cuts prompt bloat, and picks a model and effort that fit the job. It reports first and edits nothing until you say so.
- `skill-optimizer` shortens a skill's `SKILL.md` without losing an instruction. It freezes every rule, command and threshold before rewriting, and a gate rejects any rewrite that drops one.
- `writing-tests-that-can-fail` keeps tests honest in any language: each test exercises real behaviour and fails on the bug it exists to catch.

## What runs

`subagent-optimizer` and `skill-optimizer` include Python scripts that the agent runs locally with `python3`. They read the agent and skill files you point them at. Before you approve anything, they write only to a working copy of the skill or to an output file you name. Once you approve a change, the agent edits the file you asked about in place: a subagent definition, whose version one of the scripts then bumps, or a skill's `SKILL.md`. The scripts make no network requests and install nothing. `writing-tests-that-can-fail` is instructions only.

## Privacy

The plugin collects no personal data and has no telemetry or analytics. It contacts no server of its own: the skills are instructions the agent reads in your session, and the scripts run on your machine, only when a skill's steps call for them. They read the files you point them at, or, if you name none, the default agent folders and the `[agents]` tables of your Codex config. Nothing they read or write is sent anywhere. `writing-tests-that-can-fail` may suggest installing a testing tool, such as a mutation tester, from its public package registry; that happens only if you run the command.

Source, evals and measured results: https://github.com/IonDen/skills
