---
description: Install heimdall dependencies (ffmpeg, whisper-cpp)
---

Run the heimdall setup script to install dependencies:

```bash
bash ${CLAUDE_PLUGIN_ROOT}/setup --host claude
```

This will:
1. Detect your OS (macOS / Linux)
2. Install ffmpeg and whisper-cpp
3. Run a self-test
4. Write a stamp file so future sessions skip the check
