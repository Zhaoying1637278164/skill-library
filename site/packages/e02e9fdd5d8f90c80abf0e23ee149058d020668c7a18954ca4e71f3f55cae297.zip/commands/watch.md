---
description: Analyze a video file — extract frames, transcribe audio, produce a structured report
argument-hint: <video-path>
---

Dispatch the `heimdall` agent to analyze the video file at `$ARGUMENTS`.

Use the Agent tool to spawn the heimdall subagent with this prompt:

> Analyze the video file at: $ARGUMENTS
>
> Run the full heimdall workflow: guard → overview extraction → batched frame reading → optional drill-down → synthesize report. Return the structured report as your final message.
