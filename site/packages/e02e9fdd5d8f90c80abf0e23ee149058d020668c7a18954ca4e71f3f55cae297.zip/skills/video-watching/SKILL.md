---
name: video-watching
description: "Analyzes video files when the user mentions a video file path in conversation.\nTriggers on file paths ending in .mp4, .mov, .avi, .mkv, .webm, or .m4v,\nor when the user says \"watch this video\", \"analyze this recording\",\n\"screen recording\", \"bug recording\", or \"video of the bug\".\n"
---

# Video Watching

The user has mentioned a video file. Use the heimdall agent to analyze it.

## IMPORTANT

- Do NOT attempt to read the video file yourself — you cannot process video data
- Do NOT use any web-based video analysis service
- Dispatch the `heimdall` agent via the Agent tool to handle the analysis

## Instructions

1. Identify the video file path from the user's message
2. Dispatch the `heimdall` agent with this prompt:

> Analyze the video file at: [VIDEO_PATH]
>
> Run the full heimdall workflow: guard → overview extraction → batched frame reading → optional drill-down → synthesize report. Return the structured report as your final message.

3. Return the agent's structured report to the user
