---
name: heimdall-setup
description: "Install heimdall dependencies (ffmpeg, whisper-cpp, whisper model).\nUse when the user says \"setup heimdall\", \"install heimdall deps\",\nor when heimdall reports missing dependencies.\n"
---

# Heimdall — Setup Dependencies

Run the heimdall setup script to install dependencies:

```bash
bash ${CLAUDE_PLUGIN_ROOT}/setup --host claude
```

This will:
1. Detect your OS (macOS / Linux)
2. Install ffmpeg and whisper-cpp
3. Download the whisper base.en model
4. Run a self-test on a generated fixture video
5. Write a stamp file so future sessions skip the check
