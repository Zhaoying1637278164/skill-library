---
name: heimdall-watch
description: "Analyze a video file — extract frames, transcribe audio, produce a structured report.\nUse when the user says \"watch this video\", \"analyze this recording\", \"screen recording\",\n\"bug recording\", provides a path ending in .mp4, .mov, .avi, .mkv, .webm, or .m4v,\nor asks to understand what happens in a video file.\n"
argument-hint: <video-path>
---

# Heimdall — Watch Video

Dispatch the `heimdall` agent to analyze the video file at `$ARGUMENTS`.

Use the Agent tool to spawn a subagent with this prompt:

> Analyze the video file at: $ARGUMENTS
>
> Run the full heimdall workflow:
> 1. Check deps: verify ffmpeg is installed (`which ffmpeg`). If missing, tell the user to run `/heimdall:setup`.
> 2. Overview extraction: `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/extract.py "<VIDEO_PATH>" --overview`
> 3. Read metadata.json, transcript.json, frame_transcript_map.json from the cache directory
> 4. Read frames in batches of 8-10 from the frames/ subdirectory
> 5. If interesting moments found (errors, state transitions), drill down: `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/extract.py "<VIDEO_PATH>" --detail --start <SEC> --end <SEC>`
> 6. Synthesize and return a structured bug report (or general video analysis)

Do NOT read the video file directly — use extract.py to process it.
