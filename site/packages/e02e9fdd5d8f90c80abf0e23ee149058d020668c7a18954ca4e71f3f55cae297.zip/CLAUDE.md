# Heimdall — Project Guide

## What is this?

A Claude Code plugin that analyzes video files (especially bug report screen recordings) by extracting frames, transcribing audio, and producing structured reports. All heavy work runs in a subagent to keep the main context clean.

## Architecture

- **`scripts/extract.py`** — Core engine. Standalone CLI tool (Python 3.8+, stdlib only). Takes a video path, extracts frames via ffmpeg, transcribes audio via whisper-cpp, correlates timestamps, outputs JSON.
- **`agents/heimdall.md`** — Subagent dispatched via Task tool. Runs the 5-phase workflow: guard → overview → batched read → drill-down → synthesize.
- **`commands/`** — Slash commands (`/heimdall:watch`, `/heimdall:setup`).
- **`skills/video-watching/`** — Auto-trigger skill for video file mentions.
- **`hooks/hooks.json`** — SessionStart hook for dependency checking.
- **`setup`** — Top-level installer (OS detection, ffmpeg + whisper-cpp install, self-test).

## File Layout

```
scripts/extract.py          # Core engine (~450 lines)
scripts/check-deps.sh       # Fast dependency check
scripts/install-deps.sh     # OS-aware dependency installer
scripts/generate-fixture.sh # Test fixture generator
setup                       # Top-level install script
agents/heimdall.md          # Subagent definition
commands/{watch,setup}.md   # Slash commands
skills/video-watching/      # Auto-trigger skill
hooks/hooks.json            # SessionStart hook
fixtures/                   # Test fixtures (.gitignored MP4s)
tests/                      # pytest test suite
```

## Testing

```bash
python3 -m pytest tests/ -v
```

Tests auto-generate `fixtures/selftest.mp4` via ffmpeg if missing.

## Coding Conventions

- **Python 3.8+** — no match/case, no walrus operator in critical paths
- **No external Python deps** — stdlib only for `extract.py`
- **Exit codes** — 0 success, 1 missing deps, 2 bad input, 3 extraction failed
- **Cache** — `~/.cache/heimdall/extractions/<sha256-12>/` with `full/` and `range_X_Y/` subdirs
- **Frame manifest** — every extraction writes `frames.json` (`[{file, timestamp_sec, scene_score, origin}]`) in the mode cache dir; it is the single source of frame timestamps for correlation (`correlate_frames_transcript` reads it — no uniform-interval assumption)
- **Extraction strategy** — auto by duration: `<60s` interval, `60s–30min` scene detection (two-pass ffmpeg: detect `lavfi.scene_score`, select above `--scene-threshold` ∪ 45s anchors under `--max-frames`, seek-extract), `>30min` keyframe-only; override with `--strategy`; `--detail` is always interval and requires both `--start` and `--end`
- **Transcript sharing** — extracted once per video (at hash dir level), shared across overview/detail passes
- **Whisper models** — pinned in `scripts/models.json` (name → sha256/url); downloads only via `scripts/download-model.sh`; no fallback models — missing model means transcription is skipped with `transcript_status: "skipped_no_model"`
