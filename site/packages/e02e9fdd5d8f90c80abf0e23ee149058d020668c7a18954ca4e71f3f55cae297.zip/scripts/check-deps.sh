#!/usr/bin/env bash
# Fast dependency check for heimdall.
# Used by SessionStart hook — must always exit 0 (advisory only).

set -euo pipefail

STAMP_FILE="${HOME}/.cache/heimdall/deps.ok"

# Stamp exists — deps were verified previously
if [[ -f "$STAMP_FILE" ]]; then
    exit 0
fi

missing=()

if ! command -v ffmpeg &>/dev/null; then
    missing+=("ffmpeg")
fi

if ! command -v whisper-cli &>/dev/null && ! command -v whisper-cpp &>/dev/null && ! command -v whisper &>/dev/null; then
    missing+=("whisper-cpp")
fi

if [[ ${#missing[@]} -eq 0 ]]; then
    # All deps present — write stamp
    mkdir -p "$(dirname "$STAMP_FILE")"
    touch "$STAMP_FILE"
    exit 0
fi

# Missing deps — output structured JSON for SessionStart hook
missing_json=$(printf '%s\n' "${missing[@]}" | python3 -c "import sys,json; print(json.dumps(sys.stdin.read().strip().split()))")
cat <<EOJSON
{
  "additionalContext": "heimdall: missing dependencies: ${missing[*]}. Run /heimdall:setup to install ffmpeg and whisper-cpp before using /heimdall:watch.",
  "missing": ${missing_json}
}
EOJSON
exit 0
