#!/usr/bin/env bash
# Generate a tiny test video for self-testing.
# Creates colored frames with text overlay and a sine wave audio track.
# Output: ~50-100KB MP4 suitable for automated testing.

set -euo pipefail

OUTPUT="${1:-fixtures/selftest.mp4}"
VARIANT="${2:-basic}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
OUTPUT_DIR="$(dirname "$OUTPUT")"

if [[ "$OUTPUT" != /* ]]; then
    OUTPUT="${SCRIPT_DIR}/../${OUTPUT}"
    OUTPUT_DIR="$(dirname "$OUTPUT")"
fi

mkdir -p "$OUTPUT_DIR"

if ! command -v ffmpeg &>/dev/null; then
    echo "ERROR: ffmpeg is required to generate test fixtures"
    exit 1
fi

if [[ "$VARIANT" == "scene" ]]; then
    echo "==> Generating scene-cut fixture: ${OUTPUT}"
    # 6 seconds, 320x240, 10fps. Static gray background; a filled red box
    # appears at t=3 -> exactly one synthetic scene cut at a known timestamp,
    # static before and after (exercises the anchor floor around the cut).
    # drawbox (not drawtext) keeps this freetype-free, like the basic fixture.
    ffmpeg -y -v quiet \
        -f lavfi -i "color=c=gray:size=320x240:d=6:r=10" \
        -f lavfi -i "sine=frequency=440:duration=6" \
        -vf "drawbox=x=80:y=60:w=160:h=120:color=red@1.0:t=fill:enable='gte(t,3)'" \
        -c:v libx264 -preset ultrafast -crf 30 \
        -c:a aac -b:a 32k \
        -shortest \
        "$OUTPUT"
else
    echo "==> Generating test fixture: ${OUTPUT}"
    # 5 seconds, 320x240, 10fps
    # - Frames cycle through red/green/blue (no text overlay — avoids freetype dep)
    # - Audio is a 440Hz sine wave
    ffmpeg -y -v quiet \
        -f lavfi -i "color=c=red:size=320x240:d=1.67:r=10[v1];color=c=green:size=320x240:d=1.67:r=10[v2];color=c=blue:size=320x240:d=1.66:r=10[v3];[v1][v2][v3]concat=n=3:v=1:a=0" \
        -f lavfi -i "sine=frequency=440:duration=5" \
        -c:v libx264 -preset ultrafast -crf 30 \
        -c:a aac -b:a 32k \
        -shortest \
        "$OUTPUT"
fi

echo "==> Generated: ${OUTPUT} ($(du -h "$OUTPUT" | cut -f1) bytes)"
