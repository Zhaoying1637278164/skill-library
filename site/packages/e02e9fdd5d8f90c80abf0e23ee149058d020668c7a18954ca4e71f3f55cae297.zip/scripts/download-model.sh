#!/usr/bin/env bash
# Download and verify a whisper GGML model, per scripts/models.json.
# Usage: download-model.sh <model-name> [--models-dir DIR] [--manifest FILE]
#
# Exit 0: model installed (or already present) and checksum-verified.
# Exit 1: unknown model, download failure, or checksum mismatch.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ $# -lt 1 ]]; then
    echo "usage: download-model.sh <model-name> [--models-dir DIR] [--manifest FILE]" >&2
    exit 1
fi

MODEL_NAME="$1"
shift
MODELS_DIR="${HOME}/.cache/heimdall/models"
MANIFEST="${SCRIPT_DIR}/models.json"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --models-dir) MODELS_DIR="$2"; shift 2 ;;
        --manifest) MANIFEST="$2"; shift 2 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

read_field() {
    MANIFEST="$MANIFEST" MODEL_NAME="$MODEL_NAME" FIELD="$1" python3 -c '
import json, os, sys
manifest = json.load(open(os.environ["MANIFEST"]))
entry = manifest.get(os.environ["MODEL_NAME"])
if entry is None:
    sys.exit("unknown model: {} (available: {})".format(
        os.environ["MODEL_NAME"], ", ".join(sorted(manifest))))
print(entry[os.environ["FIELD"]])
'
}

MODEL_FILE="$(read_field file)"
MODEL_URL="$(read_field url)"
MODEL_SHA="$(read_field sha256)"
TARGET="${MODELS_DIR}/${MODEL_FILE}"

sha256_of() {
    if command -v sha256sum &>/dev/null; then
        sha256sum "$1" | awk '{print $1}'
    else
        shasum -a 256 "$1" | awk '{print $1}'
    fi
}

if [[ -f "$TARGET" ]]; then
    if [[ "$(sha256_of "$TARGET")" == "$MODEL_SHA" ]]; then
        echo "==> Model ${MODEL_NAME} already present and verified"
        exit 0
    fi
    echo "==> Existing ${MODEL_FILE} fails checksum — re-downloading"
    rm -f "$TARGET"
fi

mkdir -p "$MODELS_DIR"
TMP="${TARGET}.part"

echo "==> Downloading ${MODEL_NAME} from ${MODEL_URL}"
# HEIMDALL_CURL_RETRY_DELAY exists so tests can fail fast; users get the 5s default.
if ! curl -L --fail --connect-timeout 30 --retry 5 --retry-delay "${HEIMDALL_CURL_RETRY_DELAY:-5}" \
        --retry-all-errors --retry-connrefused \
        -C - -o "$TMP" "$MODEL_URL"; then
    rm -f "$TMP"
    echo "ERROR: download failed for ${MODEL_NAME}" >&2
    exit 1
fi

ACTUAL_SHA="$(sha256_of "$TMP")"
if [[ "$ACTUAL_SHA" != "$MODEL_SHA" ]]; then
    rm -f "$TMP"
    echo "ERROR: checksum mismatch for ${MODEL_NAME}" >&2
    echo "  expected: ${MODEL_SHA}" >&2
    echo "  actual:   ${ACTUAL_SHA}" >&2
    exit 1
fi

mv "$TMP" "$TARGET"
echo "==> Model installed: ${TARGET}"
