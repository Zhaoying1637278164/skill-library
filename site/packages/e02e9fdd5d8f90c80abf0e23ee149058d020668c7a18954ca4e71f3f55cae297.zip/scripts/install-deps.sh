#!/usr/bin/env bash
# OS-aware dependency installer for heimdall.
# Called by the top-level setup script.

set -euo pipefail

detect_os() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)
            if grep -qi microsoft /proc/version 2>/dev/null; then
                echo "wsl"
            else
                echo "linux"
            fi
            ;;
        *) echo "unknown" ;;
    esac
}

install_macos() {
    echo "==> Detected macOS"

    if ! command -v brew &>/dev/null; then
        echo "ERROR: Homebrew not found. Install it from https://brew.sh"
        exit 1
    fi

    if ! command -v ffmpeg &>/dev/null; then
        echo "==> Installing ffmpeg..."
        brew install ffmpeg
    else
        echo "==> ffmpeg already installed"
    fi

    if ! command -v whisper-cli &>/dev/null && ! command -v whisper-cpp &>/dev/null && ! command -v whisper &>/dev/null; then
        echo "==> Installing whisper-cpp..."
        brew install whisper-cpp
    else
        echo "==> whisper-cpp already installed"
    fi
}

install_linux() {
    echo "==> Detected Linux"

    if command -v apt-get &>/dev/null; then
        if ! command -v ffmpeg &>/dev/null; then
            echo "==> Installing ffmpeg..."
            sudo apt-get update -qq && sudo apt-get install -y -qq ffmpeg
        else
            echo "==> ffmpeg already installed"
        fi

        if ! command -v whisper-cli &>/dev/null && ! command -v whisper-cpp &>/dev/null && ! command -v whisper &>/dev/null; then
            echo "==> whisper-cpp not available via apt. Building from source..."
            install_whisper_from_source
        else
            echo "==> whisper-cpp already installed"
        fi
    else
        echo "ERROR: apt-get not found. Please install ffmpeg and whisper-cpp manually."
        echo "  ffmpeg:     https://ffmpeg.org/download.html"
        echo "  whisper-cpp: https://github.com/ggerganov/whisper.cpp"
        exit 1
    fi
}

install_whisper_from_source() {
    local build_dir
    build_dir="$(mktemp -d "${TMPDIR:-/tmp}/whisper-cpp-build.XXXXXX")"
    # Reap the temp build dir on any early exit (e.g. a failed clone/build under
    # set -e); the success path removes it explicitly below. The :- default keeps
    # the final normal-exit firing a silent no-op under set -u.
    trap 'rm -rf "${build_dir:-}"' EXIT
    echo "==> Cloning whisper.cpp into ${build_dir}..."
    git clone --depth 1 https://github.com/ggerganov/whisper.cpp.git "$build_dir"
    cd "$build_dir"
    echo "==> Building whisper.cpp..."
    make -j"$(nproc 2>/dev/null || echo 4)"
    sudo cp main /usr/local/bin/whisper-cpp
    cd - >/dev/null
    rm -rf "$build_dir"
    echo "==> whisper-cpp installed to /usr/local/bin/whisper-cpp"
}

main() {
    local os
    os="$(detect_os)"

    case "$os" in
        macos) install_macos ;;
        linux|wsl) install_linux ;;
        *)
            echo "ERROR: Unsupported OS. Please install dependencies manually:"
            echo "  ffmpeg:      https://ffmpeg.org/download.html"
            echo "  whisper-cpp: https://github.com/ggerganov/whisper.cpp"
            exit 1
            ;;
    esac

    echo "==> Dependencies installed successfully"
}

main "$@"
