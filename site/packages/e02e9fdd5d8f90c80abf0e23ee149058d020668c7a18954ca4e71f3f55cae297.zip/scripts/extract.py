#!/usr/bin/env python3
"""
extract.py — Video frame and audio extraction for heimdall.

Standalone CLI tool: video → frames + transcript + correlation map.
No external Python dependencies (stdlib only).
Requires: ffmpeg (required), whisper-cpp (optional).
"""

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys

# Exit codes
EXIT_SUCCESS = 0
EXIT_MISSING_DEPS = 1
EXIT_BAD_INPUT = 2
EXIT_EXTRACTION_FAILED = 3


def build_parser():
    parser = argparse.ArgumentParser(
        description="Extract frames and transcript from a video file.",
        prog="extract.py",
    )
    parser.add_argument("video_path", metavar="VIDEO_PATH", help="Path to video file")

    time_group = parser.add_argument_group("time range")
    time_group.add_argument(
        "--start", type=float, default=None, help="Start time in seconds (default: 0)"
    )
    time_group.add_argument(
        "--end", type=float, default=None, help="End time in seconds (default: full duration)"
    )

    density_group = parser.add_argument_group("density")
    density_group.add_argument(
        "--fps", type=float, default=None, help="Frames per second (default: 0.5 overview, 3 detail)"
    )
    density_group.add_argument(
        "--max-frames", type=int, default=60, help="Hard frame cap (default: 60)"
    )
    density_group.add_argument(
        "--strategy",
        choices=["interval", "scene", "keyframe"],
        default=None,
        help="Frame extraction strategy (default: auto by duration)",
    )
    density_group.add_argument(
        "--scene-threshold",
        type=float,
        default=SCENE_THRESHOLD_DEFAULT,
        help="Scene-change score threshold for the scene strategy (default: 0.08)",
    )

    mode_group = parser.add_argument_group("modes")
    mode_group.add_argument(
        "--overview", action="store_true", help="Low-density pass for full video (default)"
    )
    mode_group.add_argument(
        "--detail", action="store_true", help="High-density pass for a time range"
    )
    mode_group.add_argument(
        "--no-audio", action="store_true", help="Skip whisper transcription"
    )
    mode_group.add_argument(
        "--model",
        default=None,
        help="Whisper model: name (base.en) or file path (default: auto-detect)",
    )

    output_group = parser.add_argument_group("output")
    output_group.add_argument(
        "--output-dir", default=None, help="Override default cache directory"
    )

    return parser


DEFAULT_CACHE_BASE = os.path.join(os.path.expanduser("~"), ".cache", "heimdall", "extractions")
DEFAULT_MODELS_DIR = os.path.join(os.path.expanduser("~"), ".cache", "heimdall", "models")

SCENE_THRESHOLD_DEFAULT = 0.08
ANCHOR_INTERVAL_SEC = 45.0
ANCHOR_SKIP_RADIUS_SEC = 22.5
DEDUPE_WINDOW_SEC = 1.0
# Hard ceiling on generated anchor positions, so an absurd or corrupt reported
# duration cannot spin the anchor loop. Anchors above the frame cap are thinned
# to max_frames anyway, so a large ceiling costs nothing.
MAX_ANCHOR_POSITIONS = 100000
STRATEGY_SCENE_MIN_SEC = 60.0
STRATEGY_SCENE_MAX_SEC = 1800.0  # 30 minutes


def compute_hash(video_path):
    """SHA256 hash of file content, first 12 hex chars."""
    sha = hashlib.sha256()
    with open(video_path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            sha.update(chunk)
    return sha.hexdigest()[:12]


def get_cache_dir(video_path, args):
    """Build cache directory path based on video hash and extraction mode.

    Structure:
      <base>/<hash>/full/          — overview extraction
      <base>/<hash>/range_<s>_<e>/ — detail extraction for time range
    """
    base = args.output_dir or DEFAULT_CACHE_BASE
    video_hash = compute_hash(video_path)
    hash_dir = os.path.join(base, video_hash)

    if args.detail and args.start is not None and args.end is not None:
        subdir = "range_{:.1f}_{:.1f}".format(args.start, args.end)
    else:
        subdir = "full"

    return os.path.join(hash_dir, subdir)


def is_cached(cache_dir):
    """Check if a complete previous extraction exists in cache_dir.

    frames.json is required: a pre-0.3.0 cache (or a partial extraction) that
    lacks the manifest is treated as a miss and re-extracted, so downstream
    consumers (correlation, the agent's mandatory frames.json read) always
    resolve.
    """
    metadata = os.path.join(cache_dir, "metadata.json")
    frames_dir = os.path.join(cache_dir, "frames")
    manifest = os.path.join(cache_dir, "frames.json")
    return (
        os.path.isfile(metadata)
        and os.path.isdir(frames_dir)
        and os.path.isfile(manifest)
    )


def extract_metadata(video_path, cache_dir):
    """Run ffprobe to get video metadata, write metadata.json."""
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_format", "-show_streams",
        video_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except FileNotFoundError:
        print("ERROR: ffmpeg/ffprobe not found", file=sys.stderr)
        sys.exit(EXIT_MISSING_DEPS)
    except subprocess.CalledProcessError as e:
        print("ERROR: ffprobe failed: {}".format(e.stderr), file=sys.stderr)
        sys.exit(EXIT_EXTRACTION_FAILED)

    probe = json.loads(result.stdout)

    # Find video stream
    video_stream = None
    has_audio = False
    for stream in probe.get("streams", []):
        if stream.get("codec_type") == "video" and video_stream is None:
            video_stream = stream
        if stream.get("codec_type") == "audio":
            has_audio = True

    if video_stream is None:
        print("ERROR: No video stream found in {}".format(video_path), file=sys.stderr)
        sys.exit(EXIT_BAD_INPUT)

    fmt = probe.get("format", {})
    duration = float(fmt.get("duration", 0))
    width = int(video_stream.get("width", 0))
    height = int(video_stream.get("height", 0))

    # Parse fps from r_frame_rate (e.g. "30/1")
    fps_str = video_stream.get("r_frame_rate", "0/1")
    fps_parts = fps_str.split("/")
    if len(fps_parts) == 2 and int(fps_parts[1]) != 0:
        fps = round(int(fps_parts[0]) / int(fps_parts[1]), 2)
    else:
        fps = 0

    metadata = {
        "duration_sec": round(duration, 2),
        "resolution": "{}x{}".format(width, height),
        "fps": fps,
        "codec": video_stream.get("codec_name", "unknown"),
        "has_audio": has_audio,
        "file_size_bytes": int(fmt.get("size", 0)),
    }

    os.makedirs(cache_dir, exist_ok=True)
    metadata_path = os.path.join(cache_dir, "metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)

    return metadata


def extract_frames(video_path, cache_dir, metadata, args):
    """Extract frames from video at configured fps, capped at max-frames."""
    duration = metadata["duration_sec"]
    fps = args.fps
    if fps is None:
        fps = 3.0 if args.detail else 0.5

    start = args.start
    end = args.end if args.end is not None else duration

    segment_duration = end - start
    if segment_duration <= 0:
        print("ERROR: Invalid time range: start={} end={}".format(start, end), file=sys.stderr)
        sys.exit(EXIT_BAD_INPUT)

    expected_frames = int(segment_duration * fps)
    num_frames = min(expected_frames, args.max_frames) if expected_frames > 0 else 1

    # Recalculate interval to distribute frames evenly within the cap
    if num_frames > 1:
        interval = segment_duration / num_frames
    else:
        interval = segment_duration

    frames_dir = os.path.join(cache_dir, "frames")
    os.makedirs(frames_dir, exist_ok=True)

    # Build ffmpeg filter for interval-based extraction
    # Scale down large frames to max 1280px wide (preserves aspect ratio)
    vf_filter = "fps=1/{},scale='min(1280,iw)':-2".format(interval)

    cmd = [
        "ffmpeg", "-y", "-v", "quiet",
        "-ss", str(start),
        "-t", str(segment_duration),
        "-i", video_path,
        "-vf", vf_filter,
        "-frames:v", str(num_frames),
        "-q:v", "2",
        os.path.join(frames_dir, "frame_%03d.jpg"),
    ]

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except FileNotFoundError:
        print("ERROR: ffmpeg not found", file=sys.stderr)
        sys.exit(EXIT_MISSING_DEPS)
    except subprocess.CalledProcessError as e:
        print("ERROR: ffmpeg frame extraction failed: {}".format(e.stderr), file=sys.stderr)
        sys.exit(EXIT_EXTRACTION_FAILED)

    # Count actual extracted frames
    extracted = sorted(
        f for f in os.listdir(frames_dir) if f.startswith("frame_") and f.endswith(".jpg")
    )

    manifest = []
    for i, frame_file in enumerate(extracted):
        manifest.append({
            "file": frame_file,
            "timestamp_sec": round(start + i * interval, 2),
            "scene_score": None,
            "origin": "interval",
        })
    write_frames_manifest(cache_dir, manifest)

    return {
        "frames_dir": frames_dir,
        "num_frames": len(extracted),
        "extraction_fps": round(1.0 / interval, 2) if interval > 0 else fps,
        "frame_files": extracted,
        "start": start,
        "interval": interval,
        "manifest": manifest,
    }


def write_frames_manifest(cache_dir, manifest):
    """Write frames.json — the canonical per-frame record for this extraction.

    manifest: list of {"file","timestamp_sec","scene_score","origin"} dicts in
    frame order. This is the single source of frame timestamps for correlation,
    written for every strategy (interval, scene, keyframe). Returns the path.
    """
    path = os.path.join(cache_dir, "frames.json")
    with open(path, "w") as f:
        json.dump(manifest, f, indent=2)
    return path


def parse_scene_metadata(text):
    """Parse ffmpeg metadata=print output into [(pts_time, scene_score), ...].

    Format is two lines per selected frame:
        frame:0    pts:30720   pts_time:3
        lavfi.scene_score=0.112500
    A frame line with no following score line is dropped.
    """
    results = []
    pending_ts = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("frame:"):
            pending_ts = None
            for tok in line.split():
                if tok.startswith("pts_time:"):
                    try:
                        pending_ts = float(tok.split(":", 1)[1])
                    except ValueError:
                        pending_ts = None
        elif line.startswith("lavfi.scene_score=") and pending_ts is not None:
            try:
                score = float(line.split("=", 1)[1])
            except ValueError:
                continue
            results.append((pending_ts, score))
            pending_ts = None
    return results


def detect_scenes(video_path, workdir):
    """Pass 1: run ffmpeg scene detection, return [(pts_time, score), ...].

    No images are written. Per-frame metadata is printed to a file inside
    workdir (not /tmp — sandbox-safe) and parsed. Returns [] on any failure.
    """
    os.makedirs(workdir, exist_ok=True)
    meta_path = os.path.join(workdir, "scene_meta.txt")
    # ffmpeg runs from workdir and writes to a bare relative filename, so the
    # metadata path is never interpolated into the -vf filter string. Otherwise
    # a workdir holding a filtergraph metacharacter (':', ',', '\\', "'", ...)
    # would break the filter and silently drop scene detection to the anchor
    # floor while still reporting strategy="scene". video_path is made absolute
    # so it still resolves from the changed working directory.
    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-i", os.path.abspath(video_path),
        "-vf", "select='gt(scene,0)',metadata=print:file=scene_meta.txt",
        "-f", "null", "-",
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, cwd=workdir)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print("WARNING: scene detection failed: {}".format(e), file=sys.stderr)
        return []
    if not os.path.isfile(meta_path):
        return []
    with open(meta_path) as f:
        candidates = parse_scene_metadata(f.read())
    os.remove(meta_path)
    return candidates


def select_evenly(items, k):
    """Return k items evenly spaced across `items`, keeping first and last.

    Deterministic. len(items) <= k returns a copy of items; k <= 0 returns [].
    """
    if k <= 0:
        return []
    if len(items) <= k:
        return list(items)
    if k == 1:
        return [items[0]]
    step = (len(items) - 1) / float(k - 1)
    return [items[int(round(i * step))] for i in range(k)]


def select_scene_frames(candidates, duration, max_frames,
                        threshold=SCENE_THRESHOLD_DEFAULT,
                        anchor_interval=ANCHOR_INTERVAL_SEC):
    """Select frame timestamps from scene candidates unioned with time anchors.

    candidates: [(timestamp, scene_score), ...] from detect_scenes.
    Returns [(timestamp, scene_score_or_None, origin), ...] sorted by timestamp,
    origin in {"scene","anchor"}, capped at max_frames.

    Rules (spec §3):
      - scene frames = candidates with score >= threshold.
      - anchors = one per anchor_interval, skipped when a scene frame lands
        within +/- anchor_interval/2 (static stretches still get coverage).
      - union > max_frames: keep all anchors, fill remaining slots with the
        highest-scoring scene frames (deterministic; ties broken by earliest ts).
      - anchors alone > max_frames (only via manual flags): thin anchors evenly.
      - collapse frames within DEDUPE_WINDOW_SEC, preferring a scene over an anchor.
    """
    scene_frames = [(ts, score) for (ts, score) in candidates if score >= threshold]
    scene_times = [ts for (ts, _) in scene_frames]

    skip_radius = anchor_interval / 2.0
    anchors = []
    # Anchor positions are 0, interval, 2*interval, ... strictly below duration:
    # an anchor exactly at (or past) the end maps to no decodable frame and would
    # only waste a selection slot. The count is capped so a bogus duration cannot
    # spin this loop. A non-finite or non-positive duration (a crafted container
    # reporting nan/inf, or a probe failure) yields no anchors — real scene
    # candidates above the threshold are still selected below.
    if math.isfinite(duration) and duration > 0:
        n_positions = min(int(duration // anchor_interval) + 1, MAX_ANCHOR_POSITIONS)
    else:
        n_positions = 0
    for i in range(n_positions):
        t = i * anchor_interval
        if t >= duration:
            break
        if not any(abs(t - st) <= skip_radius for st in scene_times):
            anchors.append(t)

    if len(anchors) > max_frames:
        selected = [(ts, None, "anchor") for ts in select_evenly(anchors, max_frames)]
    else:
        remaining = max_frames - len(anchors)
        top = sorted(scene_frames, key=lambda p: (-p[1], p[0]))[:remaining]
        selected = (
            [(ts, None, "anchor") for ts in anchors]
            + [(ts, score, "scene") for (ts, score) in top]
        )

    selected.sort(key=lambda p: p[0])

    deduped = []
    for item in selected:
        if deduped and abs(item[0] - deduped[-1][0]) < DEDUPE_WINDOW_SEC:
            if item[2] == "scene" and deduped[-1][2] == "anchor":
                deduped[-1] = item  # scene wins a near-collision with an anchor
            continue
        deduped.append(item)
    return deduped


def _extract_single_frame(video_path, timestamp, out_path):
    """Pass 2: extract one frame at `timestamp` (keyframe-seek + decode-forward).

    -ss before -i is a fast seek, frame-accurate enough for scene frames.
    Scales to <=1280px wide. Returns True on success.
    """
    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-ss", str(timestamp),
        "-i", video_path,
        "-frames:v", "1", "-q:v", "2",
        "-vf", "scale='min(1280,iw)':-2",
        out_path,
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        return os.path.isfile(out_path)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def extract_scene_frames(video_path, cache_dir, metadata, max_frames,
                         threshold=SCENE_THRESHOLD_DEFAULT):
    """Two-pass scene extraction: detect -> select -> extract -> manifest.

    Returns a frame_info dict shaped like extract_frames() (extraction_fps and
    interval are None; scene frames are non-uniform). A static video with no
    cut above threshold falls back to the anchor floor from select_scene_frames.
    """
    duration = metadata["duration_sec"]
    frames_dir = os.path.join(cache_dir, "frames")
    os.makedirs(frames_dir, exist_ok=True)

    candidates = detect_scenes(video_path, cache_dir)
    selected = select_scene_frames(candidates, duration, max_frames, threshold=threshold)

    manifest = []
    frame_files = []
    seq = 0
    for (ts, score, origin) in selected:
        candidate_name = "frame_{:03d}.jpg".format(seq + 1)
        if _extract_single_frame(video_path, ts, os.path.join(frames_dir, candidate_name)):
            seq += 1
            frame_files.append(candidate_name)
            manifest.append({
                "file": candidate_name,
                "timestamp_sec": round(ts, 2),
                "scene_score": round(score, 4) if score is not None else None,
                "origin": origin,
            })

    write_frames_manifest(cache_dir, manifest)
    return {
        "frames_dir": frames_dir,
        "num_frames": len(frame_files),
        "extraction_fps": None,
        "frame_files": frame_files,
        "start": 0,
        "interval": None,
        "manifest": manifest,
    }


def list_keyframe_timestamps(video_path):
    """Return sorted keyframe presentation timestamps (seconds) via ffprobe.

    -skip_frame nokey makes the decoder skip non-key frames, so this is cheap
    even for long videos. Returns [] on failure.
    """
    cmd = [
        "ffprobe", "-v", "quiet",
        "-select_streams", "v:0",
        "-skip_frame", "nokey",
        "-show_entries", "frame=pts_time",
        "-of", "csv=p=0",
        video_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []
    times = []
    for line in result.stdout.splitlines():
        tok = line.split(",")[0].strip()
        if not tok:
            continue
        try:
            times.append(float(tok))
        except ValueError:
            continue
    return sorted(times)


def extract_keyframes(video_path, cache_dir, metadata, max_frames):
    """Keyframe-only extraction for long videos: list keyframes, thin evenly to
    the cap, extract each. Returns a frame_info dict (origin="keyframe").
    """
    frames_dir = os.path.join(cache_dir, "frames")
    os.makedirs(frames_dir, exist_ok=True)

    timestamps = list_keyframe_timestamps(video_path)
    if len(timestamps) > max_frames:
        timestamps = select_evenly(timestamps, max_frames)

    manifest = []
    frame_files = []
    seq = 0
    for ts in timestamps:
        candidate_name = "frame_{:03d}.jpg".format(seq + 1)
        if _extract_single_frame(video_path, ts, os.path.join(frames_dir, candidate_name)):
            seq += 1
            frame_files.append(candidate_name)
            manifest.append({
                "file": candidate_name,
                "timestamp_sec": round(ts, 2),
                "scene_score": None,
                "origin": "keyframe",
            })

    write_frames_manifest(cache_dir, manifest)
    return {
        "frames_dir": frames_dir,
        "num_frames": len(frame_files),
        "extraction_fps": None,
        "frame_files": frame_files,
        "start": 0,
        "interval": None,
        "manifest": manifest,
    }


def _model_label(model_path):
    """Human label for a model file: ggml-base.en.bin -> base.en."""
    name = os.path.basename(model_path)
    if name.startswith("ggml-"):
        name = name[len("ggml-"):]
    if name.endswith(".bin"):
        name = name[: -len(".bin")]
    return name


def _resolve_model_value(value, models_dir):
    """Resolve a --model/env value to an existing file path, or None.

    A value containing a path separator (or naming an existing file) is
    treated as a filesystem path. Anything else is a canonical name:
    'base.en', 'ggml-base.en.bin' -> <models_dir>/ggml-base.en.bin.
    """
    if os.sep in value or os.path.isfile(value):
        return value if os.path.isfile(value) else None
    name = value
    if name.startswith("ggml-"):
        name = name[len("ggml-"):]
    if name.endswith(".bin"):
        name = name[: -len(".bin")]
    candidate = os.path.join(models_dir, "ggml-{}.bin".format(name))
    return candidate if os.path.isfile(candidate) else None


def resolve_whisper_model(model_arg, models_dir=None):
    """Resolve which whisper model to use.

    Precedence: --model arg > $HEIMDALL_WHISPER_MODEL > models-dir search
    (base.en preferred, else lexicographically first ggml-*.bin) > none.

    Returns (model_path, source) with source in {"flag", "env", "cache", "none"}.
    Raises ValueError when an explicitly requested model does not exist —
    an explicit request must never silently degrade.
    """
    if models_dir is None:
        models_dir = DEFAULT_MODELS_DIR

    if model_arg:
        path = _resolve_model_value(model_arg, models_dir)
        if path is None:
            raise ValueError(
                "--model {!r} not found (searched {})".format(model_arg, models_dir)
            )
        return path, "flag"

    env_value = os.environ.get("HEIMDALL_WHISPER_MODEL")
    if env_value:
        path = _resolve_model_value(env_value, models_dir)
        if path is None:
            raise ValueError(
                "HEIMDALL_WHISPER_MODEL={!r} not found (searched {})".format(
                    env_value, models_dir
                )
            )
        return path, "env"

    # A 'default' marker (written by ./setup --model) records the operator's
    # chosen model so auto-detection honors it instead of always preferring
    # base.en. A marker naming a missing file is ignored (fall through).
    default_marker = os.path.join(models_dir, "default")
    if os.path.isfile(default_marker):
        with open(default_marker) as f:
            marked = f.read().strip()
        if marked:
            path = _resolve_model_value(marked, models_dir)
            if path is not None:
                return path, "cache"

    preferred = os.path.join(models_dir, "ggml-base.en.bin")
    if os.path.isfile(preferred):
        return preferred, "cache"
    if os.path.isdir(models_dir):
        candidates = sorted(
            f
            for f in os.listdir(models_dir)
            if f.startswith("ggml-") and f.endswith(".bin")
        )
        if candidates:
            return os.path.join(models_dir, candidates[0]), "cache"
    return None, "none"


def _find_whisper_binary():
    """Find whisper-cpp binary, checking common names."""
    for name in ("whisper-cli", "whisper-cpp", "whisper"):
        try:
            subprocess.run([name, "--help"], capture_output=True, check=False)
            return name
        except FileNotFoundError:
            continue
    return None


def extract_transcript(video_path, hash_dir, metadata, no_audio=False, model_path=None):
    """Extract audio and transcribe with whisper-cpp.

    Transcript is per-video (not per-range), stored at hash_dir level.
    model_path is required for transcription — None skips (no silent fallback).
    Returns transcript dict or None if skipped/unavailable.
    """
    transcript_path = os.path.join(hash_dir, "transcript.json")

    # Reuse the cached transcript only if it was produced by the model now
    # requested. A model_path of None means "read whatever exists" (no model
    # is needed to return a file). Otherwise a mismatch — including a legacy
    # transcript that predates the whisper_model field — forces a re-transcribe
    # so the cache never silently degrades or misreports its producing model.
    if os.path.isfile(transcript_path):
        with open(transcript_path) as f:
            cached = json.load(f)
        if model_path is None or cached.get("whisper_model") == _model_label(model_path):
            return cached

    if no_audio or not metadata.get("has_audio", False):
        return None

    if model_path is None:
        print(
            "WARNING: No whisper model found — skipping transcription. "
            "Run ./setup or pass --model.",
            file=sys.stderr,
        )
        return None

    whisper_bin = _find_whisper_binary()
    if whisper_bin is None:
        print("WARNING: whisper-cpp not found, skipping transcription", file=sys.stderr)
        return None

    # Extract audio to WAV (16kHz mono, required by whisper)
    wav_path = os.path.join(hash_dir, "audio.wav")
    os.makedirs(hash_dir, exist_ok=True)

    cmd_audio = [
        "ffmpeg", "-y", "-v", "quiet",
        "-i", video_path,
        "-ar", "16000", "-ac", "1",
        "-c:a", "pcm_s16le",
        wav_path,
    ]
    try:
        subprocess.run(cmd_audio, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        print("WARNING: Audio extraction failed: {}".format(e.stderr), file=sys.stderr)
        return None

    # Run whisper-cpp with JSON output
    # whisper-cli (Homebrew 1.8+) takes audio as positional arg
    # older whisper-cpp/main uses -f flag
    whisper_out = os.path.join(hash_dir, "whisper_raw")
    if whisper_bin == "whisper-cli":
        cmd_whisper = [
            whisper_bin,
            "--output-json-full",
            "-of", whisper_out,
        ]
        cmd_whisper.extend(["-m", model_path])
        cmd_whisper.append(wav_path)
    else:
        cmd_whisper = [
            whisper_bin,
            "-f", wav_path,
            "--output-json-full",
            "-of", whisper_out,
        ]
        cmd_whisper.extend(["-m", model_path])
    try:
        subprocess.run(cmd_whisper, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        print("WARNING: whisper-cpp failed: {}".format(e.stderr), file=sys.stderr)
        return None

    # Parse whisper JSON output
    whisper_json_path = whisper_out + ".json"
    if not os.path.isfile(whisper_json_path):
        print("WARNING: whisper output file not found", file=sys.stderr)
        return None

    with open(whisper_json_path) as f:
        whisper_data = json.load(f)

    # Build structured transcript
    segments = []
    full_text_parts = []
    for item in whisper_data.get("transcription", []):
        text = item.get("text", "").strip()
        if not text:
            continue

        # whisper-cpp timestamps are in "HH:MM:SS.mmm" format
        start_ts = _parse_whisper_timestamp(item.get("timestamps", {}).get("from", "00:00:00.000"))
        end_ts = _parse_whisper_timestamp(item.get("timestamps", {}).get("to", "00:00:00.000"))

        segments.append({
            "start": round(start_ts, 2),
            "end": round(end_ts, 2),
            "text": text,
        })
        full_text_parts.append(text)

    transcript = {
        "segments": segments,
        "language": whisper_data.get("result", {}).get("language", "unknown"),
        "full_text": " ".join(full_text_parts),
        # The transcript is the source of truth for which model produced it,
        # so a later run can invalidate the cache on a model change and main()
        # can report the true model without re-deriving it.
        "whisper_model": _model_label(model_path),
    }

    with open(transcript_path, "w") as f:
        json.dump(transcript, f, indent=2)

    # Clean up WAV (large intermediate file)
    if os.path.isfile(wav_path):
        os.remove(wav_path)

    return transcript


def _parse_whisper_timestamp(ts_str):
    """Parse 'HH:MM:SS.mmm' to seconds."""
    try:
        parts = ts_str.split(":")
        hours = int(parts[0])
        minutes = int(parts[1])
        seconds = float(parts[2])
        return hours * 3600 + minutes * 60 + seconds
    except (ValueError, IndexError):
        return 0.0


def correlate_frames_transcript(frame_info, transcript, cache_dir):
    """Match each frame timestamp to the overlapping transcript segment.

    Frame timestamps come from the extraction manifest (frame_info["manifest"]),
    not a uniform interval — scene and keyframe frames are non-uniformly spaced.
    Writes frame_transcript_map.json to cache_dir. Shape is unchanged.
    """
    if transcript is None:
        map_path = os.path.join(cache_dir, "frame_transcript_map.json")
        with open(map_path, "w") as f:
            json.dump(None, f)
        return None

    segments = transcript.get("segments", [])
    manifest = frame_info["manifest"]

    correlation = []
    for entry in manifest:
        frame_ts = entry["timestamp_sec"]

        matching_segment = None
        for seg in segments:
            if seg["start"] <= frame_ts <= seg["end"]:
                matching_segment = {
                    "start": seg["start"],
                    "end": seg["end"],
                    "text": seg["text"],
                }
                break

        correlation.append({
            "frame": entry["file"],
            "timestamp_sec": round(frame_ts, 2),
            "transcript_segment": matching_segment,
        })

    map_path = os.path.join(cache_dir, "frame_transcript_map.json")
    with open(map_path, "w") as f:
        json.dump(correlation, f, indent=2)

    return correlation


def select_strategy(duration_sec, strategy_arg=None, detail=False):
    """Choose the frame-extraction strategy.

    Detail mode is always interval. An explicit --strategy wins. Otherwise auto
    by duration: <60s interval, 60s-30min scene, >30min keyframe.
    """
    if detail:
        return "interval"
    if strategy_arg:
        return strategy_arg
    if duration_sec < STRATEGY_SCENE_MIN_SEC:
        return "interval"
    if duration_sec <= STRATEGY_SCENE_MAX_SEC:
        return "scene"
    return "keyframe"


def main():
    parser = build_parser()
    args = parser.parse_args()

    video_path = os.path.abspath(args.video_path)

    # Validate input
    if not os.path.isfile(video_path):
        print("ERROR: Video file not found: {}".format(video_path), file=sys.stderr)
        return EXIT_BAD_INPUT

    # Check ffmpeg is available
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
    except FileNotFoundError:
        print("ERROR: ffmpeg not found. Run /heimdall:setup to install.", file=sys.stderr)
        return EXIT_MISSING_DEPS

    # Validate mode arguments. --detail must carry an explicit range: without
    # both --start and --end it falls through to the "full" cache subdir and
    # clobbers the overview extraction with high-density detail frames.
    if args.detail and (args.start is None or args.end is None):
        print("ERROR: --detail requires --start and --end to specify a time range", file=sys.stderr)
        return EXIT_BAD_INPUT

    # Overview mode: start defaults to 0. The sentinel None above only exists to
    # detect an omitted --start in detail mode.
    if args.start is None:
        args.start = 0.0

    # Default to overview if neither mode specified
    if not args.detail:
        args.overview = True

    # Apply mode defaults for fps
    if args.fps is None:
        args.fps = 3.0 if args.detail else 0.5

    # Resolve whisper model up front — explicit requests must not silently degrade
    try:
        model_path, model_source = resolve_whisper_model(args.model)
    except ValueError as e:
        print("ERROR: {}".format(e), file=sys.stderr)
        return EXIT_BAD_INPUT

    # Compute cache paths
    cache_dir = get_cache_dir(video_path, args)
    video_hash = compute_hash(video_path)
    # hash_dir is <base>/<hash>; cache_dir is its full/ or range_X_Y/ subdir.
    # The transcript lives at hash_dir level (shared across modes); frames and
    # correlation live in cache_dir.
    hash_dir = os.path.join(args.output_dir or DEFAULT_CACHE_BASE, video_hash)

    # Check cache. A hit is only reused when the requested strategy (and scene
    # threshold, for scene) matches what was cached; otherwise an explicit
    # --strategy / --scene-threshold override would silently return a stale
    # extraction produced under different settings.
    if is_cached(cache_dir):
        with open(os.path.join(cache_dir, "metadata.json")) as f:
            metadata = json.load(f)

        requested_strategy = select_strategy(
            metadata.get("duration_sec", 0), args.strategy, args.detail
        )
        cache_matches = metadata.get("extraction_strategy") == requested_strategy
        if requested_strategy == "scene":
            cache_matches = cache_matches and (
                metadata.get("scene_threshold") == args.scene_threshold
            )

        if cache_matches:
            transcript_path = os.path.join(hash_dir, "transcript.json")
            transcript = None
            if os.path.isfile(transcript_path):
                with open(transcript_path) as f:
                    transcript = json.load(f)

            map_path = os.path.join(cache_dir, "frame_transcript_map.json")
            correlation = None
            if os.path.isfile(map_path):
                with open(map_path) as f:
                    correlation = json.load(f)

            frames = sorted(
                f for f in os.listdir(os.path.join(cache_dir, "frames"))
                if f.startswith("frame_") and f.endswith(".jpg")
            )

            summary = {
                "status": "cached",
                "video_hash": video_hash,
                "cache_dir": cache_dir,
                "metadata": metadata,
                "num_frames": len(frames),
                "has_transcript": transcript is not None,
                "transcript_status": metadata.get("transcript_status"),
                "has_correlation": correlation is not None,
            }
            print(json.dumps(summary, indent=2))
            return EXIT_SUCCESS
        # Strategy/threshold changed since this cache was written — fall through
        # and re-extract with the requested settings.

    # Fresh extraction pipeline
    # 1. Probe metadata
    metadata = extract_metadata(video_path, cache_dir)

    # 2. Set end time from duration if not specified
    if args.end is None:
        args.end = metadata["duration_sec"]

    # 3. Extract frames using the chosen strategy
    strategy = select_strategy(metadata["duration_sec"], args.strategy, args.detail)
    if strategy == "scene":
        frame_info = extract_scene_frames(
            video_path, cache_dir, metadata, args.max_frames,
            threshold=args.scene_threshold,
        )
    elif strategy == "keyframe":
        frame_info = extract_keyframes(video_path, cache_dir, metadata, args.max_frames)
    else:
        frame_info = extract_frames(video_path, cache_dir, metadata, args)

    # 4. Transcribe (once per video, stored at hash_dir level)
    transcript = extract_transcript(
        video_path, hash_dir, metadata, no_audio=args.no_audio, model_path=model_path
    )

    # 5. Correlate frames with transcript
    correlation = correlate_frames_transcript(frame_info, transcript, cache_dir)

    # 6. Update metadata with extraction info
    if transcript is not None:
        transcript_status = "ok"
    elif args.no_audio or not metadata.get("has_audio", False):
        transcript_status = "skipped_no_audio"
    elif model_path is None:
        transcript_status = "skipped_no_model"
    else:
        transcript_status = "failed"

    metadata["extraction_strategy"] = strategy
    if strategy == "scene":
        metadata["scene_threshold"] = args.scene_threshold
    metadata["extraction_fps"] = frame_info["extraction_fps"]
    metadata["num_frames"] = frame_info["num_frames"]
    metadata["has_transcript"] = transcript is not None
    metadata["transcript_status"] = transcript_status
    # The transcript records its own producing model; trust it so a cache hit
    # from a different model can never be mislabeled here.
    metadata["whisper_model"] = (
        transcript.get("whisper_model") if transcript is not None else None
    )
    metadata["whisper_model_source"] = model_source
    with open(os.path.join(cache_dir, "metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)

    # Output summary to stdout
    summary = {
        "status": "extracted",
        "video_hash": video_hash,
        "cache_dir": cache_dir,
        "metadata": metadata,
        "num_frames": frame_info["num_frames"],
        "has_transcript": transcript is not None,
        "transcript_status": transcript_status,
        "has_correlation": correlation is not None,
    }
    print(json.dumps(summary, indent=2))
    return EXIT_SUCCESS


if __name__ == "__main__":
    sys.exit(main())
