"""Tests for whisper model resolution and labeling in extract.py."""

import importlib.util
import os

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


@pytest.fixture
def models_dir(tmp_path):
    """A models dir containing fake base.en and tiny.en model files."""
    d = tmp_path / "models"
    d.mkdir()
    (d / "ggml-base.en.bin").write_bytes(b"fake model")
    (d / "ggml-tiny.en.bin").write_bytes(b"fake model")
    return str(d)


class TestResolveWhisperModel:
    def test_flag_name(self, models_dir):
        path, source = extract.resolve_whisper_model("base.en", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"

    def test_flag_ggml_filename(self, models_dir):
        """--model ggml-base.en.bin resolves the same as base.en."""
        path, source = extract.resolve_whisper_model("ggml-base.en.bin", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"

    def test_flag_filesystem_path(self, models_dir, tmp_path):
        custom = tmp_path / "custom.bin"
        custom.write_bytes(b"model")
        path, source = extract.resolve_whisper_model(str(custom), models_dir=models_dir)
        assert path == str(custom)
        assert source == "flag"

    def test_flag_missing_raises(self, models_dir):
        with pytest.raises(ValueError):
            extract.resolve_whisper_model("large-v3", models_dir=models_dir)

    def test_flag_missing_path_raises(self, models_dir):
        with pytest.raises(ValueError):
            extract.resolve_whisper_model("/nonexistent/model.bin", models_dir=models_dir)

    def test_env_name(self, models_dir, monkeypatch):
        monkeypatch.setenv("HEIMDALL_WHISPER_MODEL", "tiny.en")
        path, source = extract.resolve_whisper_model(None, models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-tiny.en.bin")
        assert source == "env"

    def test_env_missing_raises(self, models_dir, monkeypatch):
        monkeypatch.setenv("HEIMDALL_WHISPER_MODEL", "nope")
        with pytest.raises(ValueError):
            extract.resolve_whisper_model(None, models_dir=models_dir)

    def test_flag_beats_env(self, models_dir, monkeypatch):
        monkeypatch.setenv("HEIMDALL_WHISPER_MODEL", "tiny.en")
        path, source = extract.resolve_whisper_model("base.en", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"

    def test_cache_prefers_base_en(self, models_dir, monkeypatch):
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        path, source = extract.resolve_whisper_model(None, models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "cache"

    def test_cache_lexicographic_without_base(self, tmp_path, monkeypatch):
        d = tmp_path / "m"
        d.mkdir()
        (d / "ggml-tiny.en.bin").write_bytes(b"x")
        (d / "ggml-small.en.bin").write_bytes(b"x")
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        path, source = extract.resolve_whisper_model(None, models_dir=str(d))
        assert path == os.path.join(str(d), "ggml-small.en.bin")
        assert source == "cache"

    def test_none_when_no_models(self, tmp_path, monkeypatch):
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        path, source = extract.resolve_whisper_model(
            None, models_dir=str(tmp_path / "does-not-exist")
        )
        assert path is None
        assert source == "none"

    def test_default_marker_selects_named_model(self, models_dir, monkeypatch):
        """A 'default' marker (written by setup --model) wins over the base.en preference."""
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        with open(os.path.join(models_dir, "default"), "w") as f:
            f.write("tiny.en\n")
        path, source = extract.resolve_whisper_model(None, models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-tiny.en.bin")
        assert source == "cache"

    def test_default_marker_missing_model_falls_through(self, models_dir, monkeypatch):
        """A marker naming an absent model file is ignored — never an error."""
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        with open(os.path.join(models_dir, "default"), "w") as f:
            f.write("small.en\n")  # no ggml-small.en.bin in this models_dir
        path, source = extract.resolve_whisper_model(None, models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "cache"

    def test_flag_beats_default_marker(self, models_dir, monkeypatch):
        """An explicit --model still overrides the default marker."""
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        with open(os.path.join(models_dir, "default"), "w") as f:
            f.write("tiny.en\n")
        path, source = extract.resolve_whisper_model("base.en", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"


class TestModelLabel:
    def test_canonical(self):
        assert extract._model_label("/x/ggml-base.en.bin") == "base.en"

    def test_quantized(self):
        assert extract._model_label("/x/ggml-base.en-q5_1.bin") == "base.en-q5_1"

    def test_custom_path(self):
        assert extract._model_label("/somewhere/custom.bin") == "custom"


class TestManifest:
    def test_manifest_valid_and_pinned(self):
        import json
        with open(os.path.join(SCRIPTS_DIR, "models.json")) as f:
            manifest = json.load(f)
        for name in ("base.en", "small.en"):
            entry = manifest[name]
            assert entry["file"] == "ggml-{}.bin".format(name)
            assert len(entry["sha256"]) == 64
            assert entry["size"] > 0
            assert entry["url"].startswith("https://huggingface.co/")


import json
import subprocess
import sys

EXTRACT_PY = os.path.join(SCRIPTS_DIR, "extract.py")


def _run_cli(video, out_dir, env_overrides, *extra_args):
    """Run extract.py in a subprocess with a controlled environment."""
    env = os.environ.copy()
    env.update(env_overrides)
    cmd = [sys.executable, EXTRACT_PY, video, "--output-dir", str(out_dir)] + list(extra_args)
    return subprocess.run(cmd, capture_output=True, text=True, env=env)


class TestModelCLI:
    def test_no_model_skips_with_status(self, selftest_mp4, tmp_path, mock_whisper_bin):
        """Empty HOME (no models dir) => transcription skipped, never a fallback."""
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {
                "HOME": str(home),
                "PATH": mock_whisper_bin + os.pathsep + os.environ["PATH"],
            },
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        assert summary["has_transcript"] is False
        assert summary["transcript_status"] == "skipped_no_model"
        assert summary["metadata"]["whisper_model"] is None
        assert summary["metadata"]["whisper_model_source"] == "none"
        assert "skipping transcription" in result.stderr.lower()

    def test_model_flag_records_truth(self, selftest_mp4, tmp_path, mock_whisper_bin):
        """--model <path> => transcript ok, real label recorded (not hardcoded 'base')."""
        home = tmp_path / "home"
        home.mkdir()
        model = tmp_path / "ggml-tiny.en.bin"
        model.write_bytes(b"fake model")
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {
                "HOME": str(home),
                "PATH": mock_whisper_bin + os.pathsep + os.environ["PATH"],
            },
            "--model", str(model),
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        assert summary["has_transcript"] is True
        assert summary["transcript_status"] == "ok"
        assert summary["metadata"]["whisper_model"] == "tiny.en"
        assert summary["metadata"]["whisper_model_source"] == "flag"

    def test_explicit_missing_model_exits_2(self, selftest_mp4, tmp_path):
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4, tmp_path / "out", {"HOME": str(home)}, "--model", "large-v3"
        )
        assert result.returncode == 2
        assert "not found" in result.stderr

    def test_env_missing_model_exits_2(self, selftest_mp4, tmp_path):
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {"HOME": str(home), "HEIMDALL_WHISPER_MODEL": "nope"},
        )
        assert result.returncode == 2
        assert "not found" in result.stderr

    def test_no_audio_status(self, selftest_mp4, tmp_path):
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4, tmp_path / "out", {"HOME": str(home)}, "--no-audio"
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        assert summary["transcript_status"] == "skipped_no_audio"

    def test_metadata_model_matches_transcript(self, selftest_mp4, tmp_path, mock_whisper_bin):
        """metadata.whisper_model is the transcript's own recorded model (single source of truth)."""
        home = tmp_path / "home"
        home.mkdir()
        model = tmp_path / "ggml-tiny.en.bin"
        model.write_bytes(b"fake model")
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {
                "HOME": str(home),
                "PATH": mock_whisper_bin + os.pathsep + os.environ["PATH"],
            },
            "--model", str(model),
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        hash_dir = os.path.dirname(summary["cache_dir"])
        with open(os.path.join(hash_dir, "transcript.json")) as f:
            transcript = json.load(f)
        assert summary["metadata"]["whisper_model"] == transcript["whisper_model"] == "tiny.en"


SETUP_SH = os.path.join(SCRIPTS_DIR, "..", "setup")


class TestSetupWritesDefaultMarker:
    """setup must persist the chosen model as the resolution default marker.

    A static check (parse + grep) rather than a full run — setup installs
    system deps and downloads a model, which is out of scope for unit tests.
    """

    def test_setup_is_valid_bash(self):
        result = subprocess.run(["bash", "-n", SETUP_SH], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr

    def test_setup_writes_default_marker(self):
        with open(SETUP_SH) as f:
            body = f.read()
        assert 'echo "$model" > "${CACHE_DIR}/models/default"' in body
