"""Tests for extract_metadata."""

import json
import os
import sys

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
sys.path.insert(0, SCRIPTS_DIR)
import importlib.util
spec = importlib.util.spec_from_file_location("extract", os.path.join(SCRIPTS_DIR, "extract.py"))
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestExtractMetadata:
    def test_basic_fields(self, selftest_mp4, tmp_path):
        """Metadata contains all required fields."""
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)

        assert "duration_sec" in metadata
        assert "resolution" in metadata
        assert "fps" in metadata
        assert "codec" in metadata
        assert "has_audio" in metadata
        assert "file_size_bytes" in metadata

    def test_duration_is_positive(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        assert metadata["duration_sec"] > 0

    def test_resolution_format(self, selftest_mp4, tmp_path):
        """Resolution should be WxH format."""
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        assert "x" in metadata["resolution"]
        parts = metadata["resolution"].split("x")
        assert len(parts) == 2
        assert int(parts[0]) > 0
        assert int(parts[1]) > 0

    def test_selftest_fixture_values(self, selftest_mp4, tmp_path):
        """selftest.mp4 is 320x240, ~5s, has audio."""
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        assert metadata["resolution"] == "320x240"
        assert 4.0 <= metadata["duration_sec"] <= 6.0
        assert metadata["has_audio"] is True
        assert metadata["codec"] == "h264"

    def test_writes_metadata_json(self, selftest_mp4, tmp_path):
        """Metadata JSON file is written to cache dir."""
        cache_dir = str(tmp_path / "cache")
        extract.extract_metadata(selftest_mp4, cache_dir)
        metadata_path = os.path.join(cache_dir, "metadata.json")
        assert os.path.isfile(metadata_path)
        with open(metadata_path) as f:
            data = json.load(f)
        assert data["resolution"] == "320x240"

    def test_missing_file_exits(self, tmp_path):
        """Nonexistent video should cause exit."""
        cache_dir = str(tmp_path / "cache")
        with pytest.raises(SystemExit):
            extract.extract_metadata("/nonexistent/video.mp4", cache_dir)
