"""Tests for extract_frames."""

import os
import sys
import types

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
sys.path.insert(0, SCRIPTS_DIR)
import importlib.util
spec = importlib.util.spec_from_file_location("extract", os.path.join(SCRIPTS_DIR, "extract.py"))
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def _make_args(**kwargs):
    defaults = {
        "fps": None,
        "max_frames": 60,
        "start": 0,
        "end": None,
        "overview": True,
        "detail": False,
        "no_audio": True,
        "output_dir": None,
    }
    defaults.update(kwargs)
    return types.SimpleNamespace(**defaults)


class TestExtractFrames:
    def test_creates_frames_directory(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(end=metadata["duration_sec"])
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)
        assert os.path.isdir(os.path.join(cache_dir, "frames"))

    def test_extracts_jpeg_files(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(end=metadata["duration_sec"])
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)
        assert frame_info["num_frames"] > 0
        for f in frame_info["frame_files"]:
            assert f.endswith(".jpg")
            fpath = os.path.join(cache_dir, "frames", f)
            assert os.path.isfile(fpath)
            assert os.path.getsize(fpath) > 0

    def test_max_frames_cap(self, selftest_mp4, tmp_path):
        """max-frames should cap the number of extracted frames."""
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(fps=10.0, max_frames=3, end=metadata["duration_sec"])
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)
        assert frame_info["num_frames"] <= 3

    def test_detail_mode_higher_fps(self, selftest_mp4, tmp_path):
        """Detail mode defaults to 3fps (vs 0.5 for overview)."""
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(detail=True, overview=False, start=0, end=2.0)
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)
        # With 3fps default and 2s window, expect ~6 frames
        assert frame_info["num_frames"] >= 2

    def test_start_end_range(self, selftest_mp4, tmp_path):
        """Extracting a subrange should produce fewer frames than full."""
        cache_dir_full = str(tmp_path / "full")
        cache_dir_range = str(tmp_path / "range")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir_full)

        args_full = _make_args(fps=2.0, end=metadata["duration_sec"])
        full_info = extract.extract_frames(selftest_mp4, cache_dir_full, metadata, args_full)

        args_range = _make_args(fps=2.0, start=1.0, end=3.0)
        range_info = extract.extract_frames(selftest_mp4, cache_dir_range, metadata, args_range)

        assert range_info["num_frames"] <= full_info["num_frames"]

    def test_frame_info_fields(self, selftest_mp4, tmp_path):
        """Frame info dict has expected keys."""
        cache_dir = str(tmp_path / "cache")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(end=metadata["duration_sec"])
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)
        assert "frames_dir" in frame_info
        assert "num_frames" in frame_info
        assert "extraction_fps" in frame_info
        assert "frame_files" in frame_info
        assert "start" in frame_info
        assert "interval" in frame_info
