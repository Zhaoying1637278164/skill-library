"""Tests for the frames.json manifest and manifest-driven correlation."""

import importlib.util
import json
import os
import types

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def _make_args(**kwargs):
    defaults = {
        "fps": None, "max_frames": 60, "start": 0, "end": None,
        "overview": True, "detail": False, "no_audio": True, "output_dir": None,
    }
    defaults.update(kwargs)
    return types.SimpleNamespace(**defaults)


class TestWriteFramesManifest:
    def test_writes_json_list(self, tmp_path):
        cache_dir = str(tmp_path / "c")
        os.makedirs(cache_dir)
        manifest = [
            {"file": "frame_001.jpg", "timestamp_sec": 1.0, "scene_score": None, "origin": "interval"},
        ]
        path = extract.write_frames_manifest(cache_dir, manifest)
        assert path == os.path.join(cache_dir, "frames.json")
        with open(path) as f:
            assert json.load(f) == manifest


class TestIntervalManifest:
    def test_interval_extraction_writes_manifest(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(end=metadata["duration_sec"])
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)

        assert "manifest" in frame_info
        manifest_path = os.path.join(cache_dir, "frames.json")
        assert os.path.isfile(manifest_path)
        with open(manifest_path) as f:
            manifest = json.load(f)

        assert len(manifest) == frame_info["num_frames"] == len(frame_info["manifest"])
        for entry in manifest:
            assert set(entry) == {"file", "timestamp_sec", "scene_score", "origin"}
            assert entry["origin"] == "interval"
            assert entry["scene_score"] is None
            assert entry["file"] in frame_info["frame_files"]
        timestamps = [e["timestamp_sec"] for e in manifest]
        assert timestamps == sorted(timestamps)


class TestManifestCorrelation:
    def test_correlation_reads_manifest_non_uniform(self, tmp_path):
        """The killer case: a frame at 40s (not start + i*interval) must map to
        the segment covering 40s. This proves the uniform-interval assumption
        is gone."""
        cache_dir = str(tmp_path / "c")
        os.makedirs(cache_dir)
        frame_info = {
            "manifest": [
                {"file": "frame_001.jpg", "timestamp_sec": 1.0, "scene_score": None, "origin": "interval"},
                {"file": "frame_002.jpg", "timestamp_sec": 40.0, "scene_score": 0.5, "origin": "scene"},
            ]
        }
        transcript = {
            "segments": [
                {"start": 0.0, "end": 2.0, "text": "hello"},
                {"start": 39.0, "end": 41.0, "text": "world"},
            ]
        }
        corr = extract.correlate_frames_transcript(frame_info, transcript, cache_dir)
        assert corr[0]["frame"] == "frame_001.jpg"
        assert corr[0]["transcript_segment"]["text"] == "hello"
        assert corr[1]["timestamp_sec"] == 40.0
        assert corr[1]["transcript_segment"]["text"] == "world"

        with open(os.path.join(cache_dir, "frame_transcript_map.json")) as f:
            assert json.load(f) == corr

    def test_correlation_none_transcript_writes_null(self, tmp_path):
        cache_dir = str(tmp_path / "c")
        os.makedirs(cache_dir)
        frame_info = {"manifest": [
            {"file": "frame_001.jpg", "timestamp_sec": 1.0, "scene_score": None, "origin": "interval"},
        ]}
        assert extract.correlate_frames_transcript(frame_info, None, cache_dir) is None
        with open(os.path.join(cache_dir, "frame_transcript_map.json")) as f:
            assert json.load(f) is None
