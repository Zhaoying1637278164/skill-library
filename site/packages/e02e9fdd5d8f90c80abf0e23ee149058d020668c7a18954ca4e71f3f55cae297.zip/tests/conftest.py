"""Shared pytest fixtures for heimdall tests."""

import json
import os
import subprocess
import stat
import sys

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "fixtures")
EXTRACT_PY = os.path.join(SCRIPTS_DIR, "extract.py")
GENERATE_FIXTURE = os.path.join(SCRIPTS_DIR, "generate-fixture.sh")


@pytest.fixture(scope="session")
def selftest_mp4():
    """Path to selftest.mp4, auto-generated if missing."""
    path = os.path.join(FIXTURES_DIR, "selftest.mp4")
    if not os.path.isfile(path):
        subprocess.run(
            ["bash", GENERATE_FIXTURE, path],
            check=True,
            capture_output=True,
        )
    return path


@pytest.fixture(scope="session")
def scene_mp4():
    """Path to a fixture with one synthetic scene cut at t=3.0, auto-generated."""
    path = os.path.join(FIXTURES_DIR, "selftest_scene.mp4")
    if not os.path.isfile(path):
        subprocess.run(
            ["bash", GENERATE_FIXTURE, path, "scene"],
            check=True,
            capture_output=True,
        )
    return path


@pytest.fixture
def tmp_output_dir(tmp_path):
    """Temporary output directory for extraction results."""
    out = tmp_path / "output"
    out.mkdir()
    return str(out)


@pytest.fixture
def mock_whisper_bin(tmp_path):
    """Create a fake whisper binary that outputs canned JSON.

    The mock is written under every canonical name (whisper-cli, whisper-cpp,
    whisper) so PATH-based discovery hits it even on machines that have a real
    whisper installed. `_find_whisper_binary` probes whisper-cli first, so a
    subprocess test that only prepends this dir to PATH would otherwise fall
    through to the system whisper-cli.

    Returns the path to the mock bin directory. Add it to PATH (or join a name
    onto it) to make the mock discoverable.
    """
    # Canned whisper output
    whisper_output = {
        "transcription": [
            {
                "timestamps": {"from": "00:00:00.000", "to": "00:00:02.500"},
                "text": "This is a test recording",
            },
            {
                "timestamps": {"from": "00:00:02.500", "to": "00:00:05.000"},
                "text": "showing a sample workflow",
            },
        ],
        "result": {"language": "en"},
    }

    bin_dir = tmp_path / "mock_bin"
    bin_dir.mkdir()

    mock_body = (
        '#!/usr/bin/env bash\n'
        '# Mock whisper binary for testing\n'
        'OUTPUT_FILE=""\n'
        'while [[ $# -gt 0 ]]; do\n'
        '    case "$1" in\n'
        '        -of) OUTPUT_FILE="$2"; shift 2 ;;\n'
        '        *) shift ;;\n'
        '    esac\n'
        'done\n'
        'if [[ -n "$OUTPUT_FILE" ]]; then\n'
        "    cat > \"${OUTPUT_FILE}.json\" <<'EOJSON'\n"
        + json.dumps(whisper_output, indent=2)
        + "\nEOJSON\n"
        "fi\n"
    )

    # Write the mock under every name _find_whisper_binary probes.
    for name in ("whisper-cli", "whisper-cpp", "whisper"):
        mock_script = bin_dir / name
        mock_script.write_text(mock_body)
        mock_script.chmod(mock_script.stat().st_mode | stat.S_IEXEC)

    return str(bin_dir)


@pytest.fixture
def run_extract(tmp_output_dir, tmp_path):
    """Helper to run extract.py with a temporary output directory.

    HOME is redirected to an empty temp dir so model resolution never
    sees the developer's real ~/.cache/heimdall/models — pipeline tests
    are deterministic regardless of machine state.
    """

    def _run(video_path, *extra_args, expect_fail=False):
        isolated_home = tmp_path / "home"
        isolated_home.mkdir(exist_ok=True)
        env = os.environ.copy()
        env["HOME"] = str(isolated_home)

        cmd = [
            sys.executable, EXTRACT_PY,
            video_path,
            "--output-dir", tmp_output_dir,
        ] + list(extra_args)

        result = subprocess.run(cmd, capture_output=True, text=True, env=env)

        if not expect_fail:
            assert result.returncode == 0, (
                "extract.py failed (exit {}): {}".format(result.returncode, result.stderr)
            )
            return json.loads(result.stdout)
        else:
            return result

    return _run


@pytest.fixture
def http_server(tmp_path):
    """Local HTTP server serving tmp files — keeps download tests network-free.

    Yields (serve_dir, base_url); files written into serve_dir are served
    at base_url/<name>.
    """
    import re

    serve_dir = tmp_path / "serve"
    serve_dir.mkdir()
    proc = subprocess.Popen(
        [
            # -u: unbuffered stdout so http.server's "Serving HTTP on ... port N"
            # banner flushes immediately. Without it, CPython block-buffers the
            # banner (it prints then calls serve_forever without flushing), and
            # the readline() below blocks forever.
            sys.executable, "-u", "-m", "http.server", "0",
            "--bind", "127.0.0.1", "--directory", str(serve_dir),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        # http.server announces its port on the first stdout line
        line = proc.stdout.readline()
        match = re.search(r"port (\d+)", line)
        assert match, "http.server did not announce a port: {!r}".format(line)
        base_url = "http://127.0.0.1:{}".format(match.group(1))
        yield serve_dir, base_url
    finally:
        proc.terminate()
        proc.wait()
