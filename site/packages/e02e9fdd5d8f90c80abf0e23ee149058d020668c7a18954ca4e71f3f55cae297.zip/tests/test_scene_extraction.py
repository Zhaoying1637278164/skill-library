"""Tests for scene-detection extraction (fixture, parser, selection, e2e)."""

import importlib.util
import json
import os

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestSceneFixture:
    def test_fixture_generates(self, scene_mp4):
        assert os.path.isfile(scene_mp4)
        assert os.path.getsize(scene_mp4) > 0

    def test_fixture_metadata(self, scene_mp4, tmp_path):
        md = extract.extract_metadata(scene_mp4, str(tmp_path / "c"))
        assert md["resolution"] == "320x240"
        assert 5.5 <= md["duration_sec"] <= 6.5
        assert md["has_audio"] is True


class TestParseSceneMetadata:
    def test_confirmed_format(self):
        text = (
            "frame:0    pts:30720   pts_time:3\n"
            "lavfi.scene_score=0.112500\n"
            "frame:1    pts:35840   pts_time:3.5\n"
            "lavfi.scene_score=0.000033\n"
        )
        assert extract.parse_scene_metadata(text) == [(3.0, 0.1125), (3.5, 0.000033)]

    def test_handles_missing_score_and_blanks(self):
        text = (
            "\n"
            "frame:0 pts:0 pts_time:0.28\n"
            "lavfi.scene_score=0.5\n"
            "frame:1 pts:1 pts_time:1.48\n"   # no score line -> dropped
            "frame:2 pts:2 pts_time:2.0\n"
            "lavfi.scene_score=0.3\n"
        )
        assert extract.parse_scene_metadata(text) == [(0.28, 0.5), (2.0, 0.3)]

    def test_empty(self):
        assert extract.parse_scene_metadata("") == []


class TestSelectEvenly:
    def test_under_cap_returns_all(self):
        assert extract.select_evenly([1.0, 2.0, 3.0], 5) == [1.0, 2.0, 3.0]

    def test_over_cap_keeps_endpoints(self):
        got = extract.select_evenly(list(range(10)), 3)
        assert got[0] == 0 and got[-1] == 9 and len(got) == 3

    def test_k_one_and_zero(self):
        assert extract.select_evenly([3, 4, 5], 1) == [3]
        assert extract.select_evenly([3, 4, 5], 0) == []

    def test_deterministic(self):
        items = list(range(100))
        assert extract.select_evenly(items, 7) == extract.select_evenly(items, 7)
        assert len(extract.select_evenly(items, 7)) == 7


class TestSelectSceneFrames:
    def test_threshold_filters_below(self):
        sel = extract.select_scene_frames([(10.0, 0.5), (20.0, 0.02)], duration=30, max_frames=60)
        times = [ts for (ts, _, _) in sel]
        assert 10.0 in times and 20.0 not in times
        assert {o for (_, _, o) in sel} == {"scene"}  # anchor@0 skipped (scene within 22.5s)

    def test_anchor_floor_on_static(self):
        sel = extract.select_scene_frames([], duration=100, max_frames=60)
        assert [ts for (ts, _, _) in sel] == [0.0, 45.0, 90.0]
        assert {o for (_, _, o) in sel} == {"anchor"}
        assert all(score is None for (_, score, _) in sel)

    def test_cap_keeps_all_anchors_fills_with_top_scene(self):
        cands = [(5.0, 0.9), (6.0, 0.9), (7.0, 0.9), (8.0, 0.9)]
        sel = extract.select_scene_frames(cands, duration=200, max_frames=6)
        assert len(sel) == 6
        anchors = [ts for (ts, _, o) in sel if o == "anchor"]
        scenes = sorted(ts for (ts, _, o) in sel if o == "scene")
        assert anchors == [45.0, 90.0, 135.0, 180.0]   # every anchor preserved
        assert scenes == [5.0, 6.0]                     # remaining slots: earliest of tied top scores
        assert [s for (s, _, _) in sel] == sorted(s for (s, _, _) in sel)  # ordered by time

    def test_anchors_thinned_when_alone_exceed_cap(self):
        sel = extract.select_scene_frames([], duration=450, max_frames=3)  # 10 anchors -> 3
        times = [ts for (ts, _, _) in sel]
        assert len(sel) == 3
        # No anchor at t == duration (450 is undecodable); last is 405.0.
        assert times[0] == 0.0 and times[-1] == 405.0
        assert {o for (_, _, o) in sel} == {"anchor"}

    def test_absurd_duration_is_bounded(self):
        # A corrupt/huge reported duration must not spin the anchor loop; the
        # anchors are still thinned down to max_frames.
        sel = extract.select_scene_frames([], duration=1e12, max_frames=5)
        assert len(sel) == 5
        assert {o for (_, _, o) in sel} == {"anchor"}

    def test_threshold_changes_selection(self):
        # The threshold must actually gate which candidates become scene frames,
        # not just get recorded in metadata.
        cand = [(10.0, 0.06)]
        low = extract.select_scene_frames(cand, duration=30, max_frames=60, threshold=0.05)
        high = extract.select_scene_frames(cand, duration=30, max_frames=60, threshold=0.08)
        assert 10.0 in [ts for (ts, _, o) in low if o == "scene"]
        assert 10.0 not in [ts for (ts, _, _) in high]
        # A score exactly at the threshold is kept (>=).
        eq = extract.select_scene_frames([(10.0, 0.08)], duration=30, max_frames=60, threshold=0.08)
        assert 10.0 in [ts for (ts, _, o) in eq if o == "scene"]

    def test_non_finite_duration_does_not_crash(self):
        # A crafted container can report nan/inf (or a probe failure gives 0);
        # a forced --strategy scene must not crash. No anchors are placed, but a
        # real scene candidate is still selected.
        for bad in (float("nan"), float("inf"), -5.0, 0.0):
            sel = extract.select_scene_frames([(10.0, 0.5)], duration=bad, max_frames=60)
            assert [ts for (ts, _, o) in sel if o == "scene"] == [10.0]
            assert all(o == "scene" for (_, _, o) in sel)


class TestExtractSceneFrames:
    def test_detects_cut_and_writes_manifest(self, scene_mp4, tmp_path):
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(scene_mp4, cache_dir)
        fi = extract.extract_scene_frames(scene_mp4, cache_dir, metadata, max_frames=60)

        assert fi["num_frames"] >= 1
        assert fi["num_frames"] == len(fi["manifest"])
        scene_entries = [e for e in fi["manifest"] if e["origin"] == "scene"]
        assert any(abs(e["timestamp_sec"] - 3.0) < 1.5 for e in scene_entries)

        with open(os.path.join(cache_dir, "frames.json")) as f:
            assert json.load(f) == fi["manifest"]
        for e in fi["manifest"]:
            assert os.path.isfile(os.path.join(cache_dir, "frames", e["file"]))


class TestDetectScenes:
    def test_odd_output_path_still_detects(self, scene_mp4, tmp_path):
        # A workdir holding an ffmpeg filtergraph metacharacter (':') must not
        # break scene detection — the metadata path is no longer embedded in the
        # filter string.
        workdir = tmp_path / "ca:lon dir"
        candidates = extract.detect_scenes(scene_mp4, str(workdir))
        assert any(abs(ts - 3.0) < 1.5 and score >= 0.08 for (ts, score) in candidates)

    def test_missing_file_returns_empty(self, tmp_path):
        assert extract.detect_scenes("/nonexistent/video.mp4", str(tmp_path / "wd")) == []
