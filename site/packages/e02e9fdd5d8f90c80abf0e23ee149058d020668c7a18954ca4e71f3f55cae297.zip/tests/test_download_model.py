"""Tests for scripts/download-model.sh (checksum-verified model download)."""

import hashlib
import json
import os
import subprocess

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
DOWNLOAD_SH = os.path.join(SCRIPTS_DIR, "download-model.sh")

PAYLOAD = b"pretend this is a ggml model" * 64


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def _write_manifest(path, url, sha256):
    manifest = {
        "test.en": {
            "file": "ggml-test.en.bin",
            "size": len(PAYLOAD),
            "sha256": sha256,
            "url": url,
        }
    }
    with open(str(path), "w") as f:
        json.dump(manifest, f)
    return str(path)


def _run(model, manifest, models_dir):
    env = os.environ.copy()
    env["HEIMDALL_CURL_RETRY_DELAY"] = "0"  # fail fast in tests; users keep 5s
    return subprocess.run(
        ["bash", DOWNLOAD_SH, model, "--manifest", manifest, "--models-dir", str(models_dir)],
        capture_output=True,
        text=True,
        env=env,
    )


class TestDownloadModel:
    def test_downloads_and_installs(self, tmp_path, http_server):
        serve_dir, base_url = http_server
        (serve_dir / "model.bin").write_bytes(PAYLOAD)
        manifest = _write_manifest(
            tmp_path / "m.json", base_url + "/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"

        result = _run("test.en", manifest, models_dir)

        assert result.returncode == 0, result.stderr
        installed = models_dir / "ggml-test.en.bin"
        assert installed.read_bytes() == PAYLOAD
        assert not (models_dir / "ggml-test.en.bin.part").exists()

    def test_checksum_mismatch_fails_cleanly(self, tmp_path, http_server):
        serve_dir, base_url = http_server
        (serve_dir / "model.bin").write_bytes(b"corrupted bytes")
        manifest = _write_manifest(
            tmp_path / "m.json", base_url + "/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"

        result = _run("test.en", manifest, models_dir)

        assert result.returncode != 0
        assert "checksum mismatch" in result.stderr.lower()
        assert not (models_dir / "ggml-test.en.bin").exists()
        assert not (models_dir / "ggml-test.en.bin.part").exists()

    def test_existing_valid_model_skips_download(self, tmp_path):
        """Valid existing file => success without any network access
        (URL is unroutable on purpose)."""
        manifest = _write_manifest(
            tmp_path / "m.json", "http://127.0.0.1:1/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"
        models_dir.mkdir()
        (models_dir / "ggml-test.en.bin").write_bytes(PAYLOAD)

        result = _run("test.en", manifest, models_dir)

        assert result.returncode == 0, result.stderr
        assert "already present" in result.stdout.lower()

    def test_existing_corrupt_model_heals(self, tmp_path, http_server):
        """A previously corrupted install (the old bare-curl bug) gets re-downloaded."""
        serve_dir, base_url = http_server
        (serve_dir / "model.bin").write_bytes(PAYLOAD)
        manifest = _write_manifest(
            tmp_path / "m.json", base_url + "/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"
        models_dir.mkdir()
        (models_dir / "ggml-test.en.bin").write_bytes(b"<html>429 Too Many Requests</html>")

        result = _run("test.en", manifest, models_dir)

        assert result.returncode == 0, result.stderr
        assert (models_dir / "ggml-test.en.bin").read_bytes() == PAYLOAD

    def test_unknown_model_fails(self, tmp_path):
        manifest = _write_manifest(
            tmp_path / "m.json", "http://127.0.0.1:1/x.bin", _sha256(PAYLOAD)
        )
        result = _run("nope", manifest, tmp_path / "models")
        assert result.returncode != 0
        assert "unknown model" in (result.stderr + result.stdout).lower()

    def test_download_failure_fails(self, tmp_path):
        """Unroutable URL => nonzero exit, nothing installed."""
        manifest = _write_manifest(
            tmp_path / "m.json", "http://127.0.0.1:1/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"
        result = _run("test.en", manifest, models_dir)
        assert result.returncode != 0
        assert not (models_dir / "ggml-test.en.bin").exists()
