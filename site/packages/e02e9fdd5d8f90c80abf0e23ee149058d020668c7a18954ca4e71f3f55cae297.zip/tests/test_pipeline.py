"""End-to-end integration tests for extract.py pipeline."""

import json
import os
import sys
import subprocess

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
EXTRACT_PY = os.path.join(SCRIPTS_DIR, "extract.py")


class TestPipelineIntegration:
    def test_overview_produces_json(self, selftest_mp4, run_extract):
        """Overview mode should produce valid JSON on stdout."""
        result = run_extract(selftest_mp4, "--overview", "--no-audio")
        assert result["status"] == "extracted"
        assert "video_hash" in result
        assert "cache_dir" in result
        assert result["num_frames"] > 0

    def test_metadata_fields(self, selftest_mp4, run_extract):
        """Output JSON should include full metadata."""
        result = run_extract(selftest_mp4, "--overview", "--no-audio")
        meta = result["metadata"]
        assert meta["resolution"] == "320x240"
        assert meta["has_audio"] is True
        assert meta["extraction_strategy"] == "interval"

    def test_cache_hit_on_second_run(self, selftest_mp4, run_extract):
        """Second run on same video should return cached results."""
        result1 = run_extract(selftest_mp4, "--overview", "--no-audio")
        assert result1["status"] == "extracted"

        result2 = run_extract(selftest_mp4, "--overview", "--no-audio")
        assert result2["status"] == "cached"
        assert result2["video_hash"] == result1["video_hash"]

    def test_no_audio_flag(self, selftest_mp4, run_extract):
        """--no-audio should skip transcript."""
        result = run_extract(selftest_mp4, "--overview", "--no-audio")
        assert result["has_transcript"] is False

    def test_max_frames_flag(self, selftest_mp4, run_extract):
        """--max-frames should cap frame count."""
        result = run_extract(selftest_mp4, "--overview", "--no-audio", "--max-frames", "2")
        assert result["num_frames"] <= 2

    def test_missing_file_exits_with_code_2(self, tmp_output_dir):
        """Missing video file should exit with code 2."""
        cmd = [
            sys.executable, EXTRACT_PY,
            "/nonexistent/video.mp4",
            "--output-dir", tmp_output_dir,
            "--overview",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 2

    def test_detail_without_range_exits_with_code_2(self, selftest_mp4, tmp_output_dir):
        """--detail without --start/--end should exit with code 2."""
        cmd = [
            sys.executable, EXTRACT_PY,
            selftest_mp4,
            "--output-dir", tmp_output_dir,
            "--detail",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 2

    def test_detail_start_without_end_exits_2(self, selftest_mp4, tmp_output_dir):
        """--detail --start N with no --end must not clobber the full/ cache."""
        cmd = [
            sys.executable, EXTRACT_PY, selftest_mp4,
            "--output-dir", tmp_output_dir, "--detail", "--start", "1",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 2
        assert "requires --start and --end" in result.stderr

    def test_detail_end_without_start_exits_2(self, selftest_mp4, tmp_output_dir):
        """--detail --end N with no explicit --start is rejected too (spec: both)."""
        cmd = [
            sys.executable, EXTRACT_PY, selftest_mp4,
            "--output-dir", tmp_output_dir, "--detail", "--end", "2",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 2
        assert "requires --start and --end" in result.stderr

    def test_detail_mode_with_range(self, selftest_mp4, run_extract):
        """--detail with --start/--end should extract frames for the range."""
        result = run_extract(
            selftest_mp4, "--detail",
            "--start", "0", "--end", "2",
            "--no-audio",
        )
        assert result["status"] == "extracted"
        assert result["num_frames"] > 0

    def test_creates_frames_on_disk(self, selftest_mp4, run_extract):
        """Frames should exist as JPEG files on disk."""
        result = run_extract(selftest_mp4, "--overview", "--no-audio")
        frames_dir = os.path.join(result["cache_dir"], "frames")
        assert os.path.isdir(frames_dir)
        frames = [f for f in os.listdir(frames_dir) if f.endswith(".jpg")]
        assert len(frames) == result["num_frames"]

    def test_exit_code_0_on_success(self, selftest_mp4, tmp_output_dir):
        """Successful extraction should exit with code 0."""
        cmd = [
            sys.executable, EXTRACT_PY,
            selftest_mp4,
            "--output-dir", tmp_output_dir,
            "--overview", "--no-audio",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 0
