"""Tests for keyframe-only extraction (long-video strategy)."""

import importlib.util
import json
import os

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestListKeyframeTimestamps:
    def test_returns_sorted_floats(self, selftest_mp4):
        ts = extract.list_keyframe_timestamps(selftest_mp4)
        assert isinstance(ts, list)
        assert len(ts) >= 1
        assert all(isinstance(t, float) for t in ts)
        assert ts == sorted(ts)

    def test_missing_file_returns_empty(self):
        assert extract.list_keyframe_timestamps("/nonexistent/video.mp4") == []


class TestExtractKeyframes:
    def test_yields_frames_and_manifest(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        fi = extract.extract_keyframes(selftest_mp4, cache_dir, metadata, max_frames=60)

        assert fi["num_frames"] >= 1
        assert fi["num_frames"] == len(fi["manifest"])
        assert all(e["origin"] == "keyframe" for e in fi["manifest"])
        assert all(e["scene_score"] is None for e in fi["manifest"])

        with open(os.path.join(cache_dir, "frames.json")) as f:
            assert json.load(f) == fi["manifest"]
        for e in fi["manifest"]:
            assert os.path.isfile(os.path.join(cache_dir, "frames", e["file"]))

    def test_cap_thins_keyframes(self, selftest_mp4, tmp_path, monkeypatch):
        """A keyframe list far above the cap is thinned to exactly max_frames via
        select_evenly, endpoints preserved."""
        monkeypatch.setattr(
            extract, "list_keyframe_timestamps", lambda _v: [float(i) for i in range(100)]
        )

        # Force extraction to succeed so the cap — not decode failures on the
        # short fixture (timestamps 25..99s lie past its 5s end) — determines
        # num_frames. Otherwise the test passes even if the cap did nothing.
        def _fake_extract(_video, _timestamp, out_path):
            with open(out_path, "w") as f:
                f.write("x")
            return True
        monkeypatch.setattr(extract, "_extract_single_frame", _fake_extract)

        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        fi = extract.extract_keyframes(selftest_mp4, cache_dir, metadata, max_frames=5)
        assert fi["num_frames"] == 5
        ts = [e["timestamp_sec"] for e in fi["manifest"]]
        assert ts == [0.0, 25.0, 50.0, 74.0, 99.0]
