"""Tests for compute_hash, get_cache_dir, and is_cached."""

import os
import sys
import json
import types

# Import extract.py as a module
SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
sys.path.insert(0, SCRIPTS_DIR)
import importlib.util
spec = importlib.util.spec_from_file_location("extract", os.path.join(SCRIPTS_DIR, "extract.py"))
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestComputeHash:
    def test_deterministic(self, selftest_mp4):
        """Same file always produces same hash."""
        h1 = extract.compute_hash(selftest_mp4)
        h2 = extract.compute_hash(selftest_mp4)
        assert h1 == h2

    def test_length(self, selftest_mp4):
        """Hash is exactly 12 hex characters."""
        h = extract.compute_hash(selftest_mp4)
        assert len(h) == 12
        assert all(c in "0123456789abcdef" for c in h)

    def test_different_files_different_hashes(self, selftest_mp4, tmp_path):
        """Different file content produces different hash."""
        other = tmp_path / "other.bin"
        other.write_bytes(b"different content")
        h1 = extract.compute_hash(selftest_mp4)
        h2 = extract.compute_hash(str(other))
        assert h1 != h2


class TestGetCacheDir:
    def _make_args(self, **kwargs):
        defaults = {
            "output_dir": "/tmp/test_cache",
            "detail": False,
            "start": 0,
            "end": None,
            "overview": True,
        }
        defaults.update(kwargs)
        return types.SimpleNamespace(**defaults)

    def test_overview_uses_full_subdir(self, selftest_mp4):
        args = self._make_args()
        cache_dir = extract.get_cache_dir(selftest_mp4, args)
        assert cache_dir.endswith("/full")

    def test_detail_uses_range_subdir(self, selftest_mp4):
        args = self._make_args(detail=True, start=10.0, end=20.0)
        cache_dir = extract.get_cache_dir(selftest_mp4, args)
        assert "/range_10.0_20.0" in cache_dir

    def test_includes_video_hash(self, selftest_mp4):
        args = self._make_args()
        cache_dir = extract.get_cache_dir(selftest_mp4, args)
        video_hash = extract.compute_hash(selftest_mp4)
        assert video_hash in cache_dir

    def test_respects_output_dir(self, selftest_mp4):
        args = self._make_args(output_dir="/custom/path")
        cache_dir = extract.get_cache_dir(selftest_mp4, args)
        assert cache_dir.startswith("/custom/path")


class TestIsCached:
    def test_empty_dir_is_not_cached(self, tmp_path):
        assert not extract.is_cached(str(tmp_path))

    def test_with_metadata_frames_and_manifest(self, tmp_path):
        """A complete 0.3.0 cache has metadata.json, frames/, and frames.json."""
        (tmp_path / "metadata.json").write_text("{}")
        (tmp_path / "frames").mkdir()
        (tmp_path / "frames.json").write_text("[]")
        assert extract.is_cached(str(tmp_path))

    def test_metadata_without_frames_not_cached(self, tmp_path):
        (tmp_path / "metadata.json").write_text("{}")
        assert not extract.is_cached(str(tmp_path))

    def test_frames_without_metadata_not_cached(self, tmp_path):
        (tmp_path / "frames").mkdir()
        assert not extract.is_cached(str(tmp_path))

    def test_metadata_and_frames_without_manifest_not_cached(self, tmp_path):
        """Pre-0.3.0 or partial cache lacking frames.json is a miss and re-extracted."""
        (tmp_path / "metadata.json").write_text("{}")
        (tmp_path / "frames").mkdir()
        assert not extract.is_cached(str(tmp_path))
