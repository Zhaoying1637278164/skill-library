"""Tests for extract_transcript and whisper fallback behavior."""

import json
import os
import sys
import types

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
sys.path.insert(0, SCRIPTS_DIR)
import importlib.util
spec = importlib.util.spec_from_file_location("extract", os.path.join(SCRIPTS_DIR, "extract.py"))
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestExtractTranscriptFallback:
    def test_returns_none_when_no_audio_flag(self, selftest_mp4, tmp_path):
        """--no-audio should skip transcription entirely."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}
        result = extract.extract_transcript(selftest_mp4, hash_dir, metadata, no_audio=True)
        assert result is None

    def test_returns_none_when_no_audio_track(self, selftest_mp4, tmp_path):
        """Videos without audio should skip transcription."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": False}
        result = extract.extract_transcript(selftest_mp4, hash_dir, metadata, no_audio=False)
        assert result is None

    def test_graceful_when_whisper_missing(self, selftest_mp4, tmp_path, monkeypatch):
        """When whisper-cpp is not installed, should return None gracefully."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}
        # Ensure whisper can't be found
        monkeypatch.setattr(extract, "_find_whisper_binary", lambda: None)
        # A model is resolved (non-None) so the flow reaches the binary check;
        # the path is never opened because whisper is never invoked.
        model_path = str(tmp_path / "ggml-base.en.bin")
        result = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=model_path
        )
        assert result is None

    def test_returns_none_when_no_model(self, selftest_mp4, tmp_path, monkeypatch):
        """No resolved model must skip transcription — never a silent fallback."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}
        calls = [0]
        monkeypatch.setattr(
            extract, "_find_whisper_binary", lambda: calls.__setitem__(0, calls[0] + 1)
        )
        result = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=None
        )
        assert result is None
        assert calls[0] == 0  # whisper never even looked up

    def test_no_test_model_fallback_helper(self):
        """The Homebrew test-model fallback is gone."""
        assert not hasattr(extract, "_find_whisper_model")


class TestExtractTranscriptWithMock:
    def test_produces_transcript_json(self, selftest_mp4, tmp_path, mock_whisper_bin, monkeypatch):
        """With mock whisper, should produce valid transcript."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}

        # Make mock whisper discoverable
        monkeypatch.setattr(extract, "_find_whisper_binary", lambda: os.path.join(mock_whisper_bin, "whisper-cpp"))

        model_path = str(tmp_path / "ggml-base.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=model_path
        )
        assert result is not None
        assert "segments" in result
        assert "full_text" in result
        assert "language" in result
        assert len(result["segments"]) == 2
        assert result["segments"][0]["text"] == "This is a test recording"

    def test_transcript_cached_on_second_call(self, selftest_mp4, tmp_path, mock_whisper_bin, monkeypatch):
        """Second call should return cached transcript without re-running whisper."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}

        monkeypatch.setattr(extract, "_find_whisper_binary", lambda: os.path.join(mock_whisper_bin, "whisper-cpp"))

        model_path = str(tmp_path / "ggml-base.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result1 = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=model_path
        )
        assert result1 is not None

        # Second call — should use cache
        call_count = [0]
        original_find = extract._find_whisper_binary
        def counting_find():
            call_count[0] += 1
            return original_find()
        monkeypatch.setattr(extract, "_find_whisper_binary", counting_find)

        result2 = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=model_path
        )
        assert result2 is not None
        assert result2["segments"] == result1["segments"]
        # Should not have called whisper binary lookup — cached path read first
        assert call_count[0] == 0

    def test_transcript_records_whisper_model(self, selftest_mp4, tmp_path, mock_whisper_bin, monkeypatch):
        """A freshly produced transcript.json records the producing model label."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}

        monkeypatch.setattr(
            extract, "_find_whisper_binary",
            lambda: os.path.join(mock_whisper_bin, "whisper-cpp"),
        )

        model_path = str(tmp_path / "ggml-tiny.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=model_path
        )
        assert result["whisper_model"] == "tiny.en"
        # The label is persisted, not merely returned in-memory.
        with open(os.path.join(hash_dir, "transcript.json")) as f:
            assert json.load(f)["whisper_model"] == "tiny.en"


class TestTranscriptModelInvalidation:
    """A cached transcript must not silently satisfy a request for a different model."""

    def _counting_find(self, monkeypatch, mock_whisper_bin):
        """Patch _find_whisper_binary and count invocations (proxy for re-transcribe)."""
        calls = [0]

        def counting_find():
            calls[0] += 1
            return os.path.join(mock_whisper_bin, "whisper-cpp")

        monkeypatch.setattr(extract, "_find_whisper_binary", counting_find)
        return calls

    def _seed_transcript(self, hash_dir, text, whisper_model=None):
        """Write a cached transcript.json; omit whisper_model to simulate legacy."""
        hash_dir.mkdir(parents=True, exist_ok=True)
        data = {
            "segments": [{"start": 0.0, "end": 1.0, "text": text}],
            "language": "en",
            "full_text": text,
        }
        if whisper_model is not None:
            data["whisper_model"] = whisper_model
        (hash_dir / "transcript.json").write_text(json.dumps(data))

    def test_stale_model_retranscribes(self, selftest_mp4, tmp_path, mock_whisper_bin, monkeypatch):
        """Cached base.en transcript + request for tiny.en => re-transcribe with tiny.en."""
        hash_dir = tmp_path / "hash"
        self._seed_transcript(hash_dir, "old base content", whisper_model="base.en")
        calls = self._counting_find(monkeypatch, mock_whisper_bin)

        model_path = str(tmp_path / "ggml-tiny.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result = extract.extract_transcript(
            selftest_mp4, str(hash_dir), {"has_audio": True},
            no_audio=False, model_path=model_path,
        )
        assert calls[0] >= 1  # whisper actually ran
        assert result["whisper_model"] == "tiny.en"
        assert result["segments"][0]["text"] == "This is a test recording"  # fresh content
        with open(str(hash_dir / "transcript.json")) as f:
            assert json.load(f)["whisper_model"] == "tiny.en"  # cache overwritten

    def test_matching_model_reused(self, selftest_mp4, tmp_path, mock_whisper_bin, monkeypatch):
        """Cached transcript whose model matches the request is reused verbatim."""
        hash_dir = tmp_path / "hash"
        self._seed_transcript(hash_dir, "cached content", whisper_model="tiny.en")
        calls = self._counting_find(monkeypatch, mock_whisper_bin)

        model_path = str(tmp_path / "ggml-tiny.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result = extract.extract_transcript(
            selftest_mp4, str(hash_dir), {"has_audio": True},
            no_audio=False, model_path=model_path,
        )
        assert calls[0] == 0  # whisper never invoked
        assert result["segments"][0]["text"] == "cached content"  # untouched
        assert result["whisper_model"] == "tiny.en"

    def test_legacy_transcript_retranscribes(self, selftest_mp4, tmp_path, mock_whisper_bin, monkeypatch):
        """A pre-existing transcript with no model field re-transcribes once, then carries it."""
        hash_dir = tmp_path / "hash"
        self._seed_transcript(hash_dir, "legacy content")  # no whisper_model field
        calls = self._counting_find(monkeypatch, mock_whisper_bin)

        model_path = str(tmp_path / "ggml-base.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result = extract.extract_transcript(
            selftest_mp4, str(hash_dir), {"has_audio": True},
            no_audio=False, model_path=model_path,
        )
        assert calls[0] >= 1
        assert result["whisper_model"] == "base.en"
        assert result["segments"][0]["text"] == "This is a test recording"


class TestParseWhisperTimestamp:
    def test_basic(self):
        assert extract._parse_whisper_timestamp("00:00:02.500") == 2.5

    def test_with_hours(self):
        assert extract._parse_whisper_timestamp("01:30:00.000") == 5400.0

    def test_invalid_returns_zero(self):
        assert extract._parse_whisper_timestamp("invalid") == 0.0

    def test_empty_returns_zero(self):
        assert extract._parse_whisper_timestamp("") == 0.0
