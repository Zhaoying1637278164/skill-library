"""Tests for extraction-strategy selection and CLI dispatch."""

import importlib.util
import json
import os

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestSelectStrategy:
    def test_auto_bands(self):
        assert extract.select_strategy(30) == "interval"
        assert extract.select_strategy(300) == "scene"
        assert extract.select_strategy(2000) == "keyframe"

    def test_boundaries(self):
        assert extract.select_strategy(59.9) == "interval"
        assert extract.select_strategy(60.0) == "scene"
        assert extract.select_strategy(1800.0) == "scene"
        assert extract.select_strategy(1800.1) == "keyframe"

    def test_detail_forces_interval(self):
        assert extract.select_strategy(300, detail=True) == "interval"

    def test_explicit_override_wins(self):
        assert extract.select_strategy(5, strategy_arg="scene") == "scene"
        assert extract.select_strategy(5, strategy_arg="keyframe") == "keyframe"


class TestStrategyDispatchCLI:
    def test_auto_interval_for_short_fixture(self, selftest_mp4, run_extract):
        r = run_extract(selftest_mp4, "--overview", "--no-audio")
        assert r["metadata"]["extraction_strategy"] == "interval"
        assert "scene_threshold" not in r["metadata"]

    def test_scene_override_records_strategy_and_threshold(self, scene_mp4, run_extract):
        r = run_extract(scene_mp4, "--overview", "--no-audio", "--strategy", "scene")
        assert r["metadata"]["extraction_strategy"] == "scene"
        assert r["metadata"]["scene_threshold"] == 0.08
        assert r["num_frames"] >= 1
        with open(os.path.join(r["cache_dir"], "frames.json")) as f:
            manifest = json.load(f)
        assert any(e["origin"] == "scene" and abs(e["timestamp_sec"] - 3.0) < 1.5 for e in manifest)

    def test_scene_threshold_flag_recorded(self, scene_mp4, run_extract):
        r = run_extract(
            scene_mp4, "--overview", "--no-audio", "--strategy", "scene",
            "--scene-threshold", "0.05",
        )
        assert r["metadata"]["scene_threshold"] == 0.05

    def test_keyframe_override(self, selftest_mp4, run_extract):
        r = run_extract(selftest_mp4, "--overview", "--no-audio", "--strategy", "keyframe")
        assert r["metadata"]["extraction_strategy"] == "keyframe"
        assert r["num_frames"] >= 1


class TestStrategyCacheIdentity:
    def test_is_cached_requires_frames_manifest(self, tmp_path):
        cache = tmp_path / "c"
        (cache / "frames").mkdir(parents=True)
        (cache / "metadata.json").write_text("{}")
        # metadata + frames/ but no frames.json -> treated as a miss.
        assert extract.is_cached(str(cache)) is False
        (cache / "frames.json").write_text("[]")
        assert extract.is_cached(str(cache)) is True

    def test_strategy_change_bypasses_stale_cache(self, scene_mp4, run_extract):
        r1 = run_extract(scene_mp4, "--overview", "--no-audio", "--strategy", "scene")
        assert r1["metadata"]["extraction_strategy"] == "scene"
        # Same video + output dir, different strategy: must re-extract, not serve
        # the cached scene result back.
        r2 = run_extract(scene_mp4, "--overview", "--no-audio", "--strategy", "keyframe")
        assert r2["metadata"]["extraction_strategy"] == "keyframe"

    def test_scene_threshold_change_bypasses_cache(self, scene_mp4, run_extract):
        r1 = run_extract(scene_mp4, "--overview", "--no-audio", "--strategy", "scene")
        assert r1["metadata"]["scene_threshold"] == 0.08
        r2 = run_extract(
            scene_mp4, "--overview", "--no-audio", "--strategy", "scene",
            "--scene-threshold", "0.05",
        )
        assert r2["metadata"]["scene_threshold"] == 0.05
