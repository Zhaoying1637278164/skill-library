"""Guards for install-deps.sh parked follow-ups (probe + mktemp hardening)."""

import os
import subprocess

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
INSTALL_DEPS = os.path.join(SCRIPTS_DIR, "install-deps.sh")


def _content():
    with open(INSTALL_DEPS) as f:
        return f.read()


def test_probes_whisper_cli_at_both_sites():
    # macOS and Linux both must accept an existing whisper-cli.
    assert _content().count("command -v whisper-cli") >= 2


def test_uses_mktemp_not_predictable_path():
    content = _content()
    assert "mktemp -d" in content
    assert "/tmp/whisper-cpp-build" not in content


def test_syntax_valid():
    result = subprocess.run(["bash", "-n", INSTALL_DEPS], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_reaps_build_dir_on_early_exit():
    # A failed source build must not leak the mktemp dir.
    assert "trap 'rm -rf \"${build_dir:-}\"' EXIT" in _content()
