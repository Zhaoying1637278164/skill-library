# Whisper Model Management (v0.2.0) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Kill silent transcript-quality degradation — checksum-verified model downloads, a `--model` flag, no test-model fallback, and reports that name the model actually used.

**Architecture:** A pinned JSON manifest (`scripts/models.json`) is the single source of truth for model names → URL/SHA-256. A new `scripts/download-model.sh` downloads+verifies+atomically installs models (called by `setup`). `extract.py` gains `resolve_whisper_model()` with precedence `--model` > `$HEIMDALL_WHISPER_MODEL` > models-dir search > skip-transcription, and records the truth in `metadata.json` (`whisper_model`, `whisper_model_source`, `transcript_status`).

**Tech Stack:** Python 3.8+ stdlib only (`extract.py`), bash + curl + python3-for-JSON (`setup`/`download-model.sh`), pytest.

**Spec:** `docs/superpowers/specs/2026-07-10-heimdall-roadmap-v0.2-v0.6-design.md` §2.

## Global Constraints

- `scripts/extract.py` is Python 3.8+, **stdlib only** — no pip imports, external tools via subprocess.
- Exit codes: 0 success, 1 missing deps, 2 bad input, 3 extraction failed. Explicitly requested model (`--model`/env) that can't be resolved → exit 2. Auto-search finding nothing → **skip transcription, exit 0** (frames are the primary signal).
- Tests must be network-free (local `http.server` fixture; never hit huggingface.co).
- Commits: small and atomic, **no co-author tags**.
- The Homebrew `for-tests-ggml-tiny.bin` fallback is removed entirely — no silent downgrade, ever.
- `transcript_status` values: `"ok"`, `"skipped_no_audio"`, `"skipped_no_model"`, `"failed"` (failed = whisper binary missing or whisper run error).
- Run tests with: `python3 -m pytest tests/ -v` from the repo root.

## File Structure

- **Create** `scripts/models.json` — pinned manifest (name → file/size/sha256/url).
- **Create** `scripts/download-model.sh` — verified downloader: curl retry/resume → temp `.part` → sha256 verify → atomic `mv`. Heals corrupt existing files.
- **Modify** `scripts/extract.py` — add `resolve_whisper_model()` + `_model_label()`; delete `_find_whisper_model()`; thread `model_path` into `extract_transcript()`; `--model` flag; truth fields in metadata/summary.
- **Modify** `setup` — `--model NAME` flag (default `base.en`); replace the bare-curl block with a `download-model.sh` call.
- **Modify** `agents/heimdall.md`, `README.md`, `CLAUDE.md`, `.claude-plugin/plugin.json` (→ 0.2.0).
- **Create** `tests/test_model_resolution.py`, `tests/test_download_model.py`; **modify** `tests/test_transcript.py`, `tests/conftest.py` (http_server fixture).

---

### Task 1: Model manifest + `resolve_whisper_model()`

**Files:**
- Create: `scripts/models.json`
- Create: `tests/test_model_resolution.py`
- Modify: `scripts/extract.py` (add functions near `_find_whisper_binary`, ~line 235; do NOT remove `_find_whisper_model` yet — Task 2 does)

**Interfaces:**
- Produces: `resolve_whisper_model(model_arg, models_dir=None) -> (path_or_None, source)`; `source` ∈ `{"flag","env","cache","none"}`; raises `ValueError` when an explicitly requested model (arg or `$HEIMDALL_WHISPER_MODEL`) doesn't exist. `_model_label(path) -> str` (e.g. `"base.en"`). `DEFAULT_MODELS_DIR` constant. Tasks 2–3 consume all three.

- [ ] **Step 1: Create the manifest**

Write `scripts/models.json` exactly:

```json
{
  "base.en": {
    "file": "ggml-base.en.bin",
    "size": 147964211,
    "sha256": "a03779c86df3323075f5e796cb2ce5029f00ec8869eee3fdfb897afe36c6d002",
    "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin"
  },
  "small.en": {
    "file": "ggml-small.en.bin",
    "size": 487614201,
    "sha256": "c6138d6d58ecc8322097e0f987c32f1be8bb0a18532a3f88f734d1bbf9c41e5d",
    "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en.bin"
  }
}
```

- [ ] **Step 2: Write the failing tests**

Create `tests/test_model_resolution.py`:

```python
"""Tests for whisper model resolution and labeling in extract.py."""

import importlib.util
import os

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


@pytest.fixture
def models_dir(tmp_path):
    """A models dir containing fake base.en and tiny.en model files."""
    d = tmp_path / "models"
    d.mkdir()
    (d / "ggml-base.en.bin").write_bytes(b"fake model")
    (d / "ggml-tiny.en.bin").write_bytes(b"fake model")
    return str(d)


class TestResolveWhisperModel:
    def test_flag_name(self, models_dir):
        path, source = extract.resolve_whisper_model("base.en", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"

    def test_flag_ggml_filename(self, models_dir):
        """--model ggml-base.en.bin resolves the same as base.en."""
        path, source = extract.resolve_whisper_model("ggml-base.en.bin", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"

    def test_flag_filesystem_path(self, models_dir, tmp_path):
        custom = tmp_path / "custom.bin"
        custom.write_bytes(b"model")
        path, source = extract.resolve_whisper_model(str(custom), models_dir=models_dir)
        assert path == str(custom)
        assert source == "flag"

    def test_flag_missing_raises(self, models_dir):
        with pytest.raises(ValueError):
            extract.resolve_whisper_model("large-v3", models_dir=models_dir)

    def test_flag_missing_path_raises(self, models_dir):
        with pytest.raises(ValueError):
            extract.resolve_whisper_model("/nonexistent/model.bin", models_dir=models_dir)

    def test_env_name(self, models_dir, monkeypatch):
        monkeypatch.setenv("HEIMDALL_WHISPER_MODEL", "tiny.en")
        path, source = extract.resolve_whisper_model(None, models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-tiny.en.bin")
        assert source == "env"

    def test_env_missing_raises(self, models_dir, monkeypatch):
        monkeypatch.setenv("HEIMDALL_WHISPER_MODEL", "nope")
        with pytest.raises(ValueError):
            extract.resolve_whisper_model(None, models_dir=models_dir)

    def test_flag_beats_env(self, models_dir, monkeypatch):
        monkeypatch.setenv("HEIMDALL_WHISPER_MODEL", "tiny.en")
        path, source = extract.resolve_whisper_model("base.en", models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "flag"

    def test_cache_prefers_base_en(self, models_dir, monkeypatch):
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        path, source = extract.resolve_whisper_model(None, models_dir=models_dir)
        assert path == os.path.join(models_dir, "ggml-base.en.bin")
        assert source == "cache"

    def test_cache_lexicographic_without_base(self, tmp_path, monkeypatch):
        d = tmp_path / "m"
        d.mkdir()
        (d / "ggml-tiny.en.bin").write_bytes(b"x")
        (d / "ggml-small.en.bin").write_bytes(b"x")
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        path, source = extract.resolve_whisper_model(None, models_dir=str(d))
        assert path == os.path.join(str(d), "ggml-small.en.bin")
        assert source == "cache"

    def test_none_when_no_models(self, tmp_path, monkeypatch):
        monkeypatch.delenv("HEIMDALL_WHISPER_MODEL", raising=False)
        path, source = extract.resolve_whisper_model(
            None, models_dir=str(tmp_path / "does-not-exist")
        )
        assert path is None
        assert source == "none"


class TestModelLabel:
    def test_canonical(self):
        assert extract._model_label("/x/ggml-base.en.bin") == "base.en"

    def test_quantized(self):
        assert extract._model_label("/x/ggml-base.en-q5_1.bin") == "base.en-q5_1"

    def test_custom_path(self):
        assert extract._model_label("/somewhere/custom.bin") == "custom"


class TestManifest:
    def test_manifest_valid_and_pinned(self):
        import json
        with open(os.path.join(SCRIPTS_DIR, "models.json")) as f:
            manifest = json.load(f)
        for name in ("base.en", "small.en"):
            entry = manifest[name]
            assert entry["file"] == "ggml-{}.bin".format(name)
            assert len(entry["sha256"]) == 64
            assert entry["size"] > 0
            assert entry["url"].startswith("https://huggingface.co/")
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_model_resolution.py -v`
Expected: `TestManifest` PASSES (Step 1 created the file); every other test FAILS with `AttributeError: module 'extract' has no attribute 'resolve_whisper_model'` / `'_model_label'`.

- [ ] **Step 4: Implement resolution in extract.py**

In `scripts/extract.py`, directly below `DEFAULT_CACHE_BASE` (line ~66), add:

```python
DEFAULT_MODELS_DIR = os.path.join(os.path.expanduser("~"), ".cache", "heimdall", "models")
```

Directly above `_find_whisper_binary()` (line ~235), add:

```python
def _model_label(model_path):
    """Human label for a model file: ggml-base.en.bin -> base.en."""
    name = os.path.basename(model_path)
    if name.startswith("ggml-"):
        name = name[len("ggml-"):]
    if name.endswith(".bin"):
        name = name[: -len(".bin")]
    return name


def _resolve_model_value(value, models_dir):
    """Resolve a --model/env value to an existing file path, or None.

    A value containing a path separator (or naming an existing file) is
    treated as a filesystem path. Anything else is a canonical name:
    'base.en', 'ggml-base.en.bin' -> <models_dir>/ggml-base.en.bin.
    """
    if os.sep in value or os.path.isfile(value):
        return value if os.path.isfile(value) else None
    name = value
    if name.startswith("ggml-"):
        name = name[len("ggml-"):]
    if name.endswith(".bin"):
        name = name[: -len(".bin")]
    candidate = os.path.join(models_dir, "ggml-{}.bin".format(name))
    return candidate if os.path.isfile(candidate) else None


def resolve_whisper_model(model_arg, models_dir=None):
    """Resolve which whisper model to use.

    Precedence: --model arg > $HEIMDALL_WHISPER_MODEL > models-dir search
    (base.en preferred, else lexicographically first ggml-*.bin) > none.

    Returns (model_path, source) with source in {"flag", "env", "cache", "none"}.
    Raises ValueError when an explicitly requested model does not exist —
    an explicit request must never silently degrade.
    """
    if models_dir is None:
        models_dir = DEFAULT_MODELS_DIR

    if model_arg:
        path = _resolve_model_value(model_arg, models_dir)
        if path is None:
            raise ValueError(
                "--model {!r} not found (searched {})".format(model_arg, models_dir)
            )
        return path, "flag"

    env_value = os.environ.get("HEIMDALL_WHISPER_MODEL")
    if env_value:
        path = _resolve_model_value(env_value, models_dir)
        if path is None:
            raise ValueError(
                "HEIMDALL_WHISPER_MODEL={!r} not found (searched {})".format(
                    env_value, models_dir
                )
            )
        return path, "env"

    preferred = os.path.join(models_dir, "ggml-base.en.bin")
    if os.path.isfile(preferred):
        return preferred, "cache"
    if os.path.isdir(models_dir):
        candidates = sorted(
            f
            for f in os.listdir(models_dir)
            if f.startswith("ggml-") and f.endswith(".bin")
        )
        if candidates:
            return os.path.join(models_dir, candidates[0]), "cache"
    return None, "none"
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_model_resolution.py -v`
Expected: all PASS.

- [ ] **Step 6: Run the full suite (no regressions), then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS.

```bash
git add scripts/models.json scripts/extract.py tests/test_model_resolution.py
git commit -m "feat(extract): add pinned model manifest and resolve_whisper_model()"
```

---

### Task 2: Thread the model into transcription; delete the test-model fallback

**Files:**
- Modify: `scripts/extract.py` — `extract_transcript()` (line ~271), `_find_whisper_model()` (lines ~246-268, DELETE), whisper command build (lines ~312-331)
- Modify: `tests/test_transcript.py`

**Interfaces:**
- Consumes: nothing new (model resolution wired in Task 3).
- Produces: `extract_transcript(video_path, hash_dir, metadata, no_audio=False, model_path=None) -> dict|None`. `model_path=None` with audio present → returns `None` *without* invoking whisper (the skip path Task 3's `transcript_status` relies on). `_find_whisper_model()` no longer exists.

- [ ] **Step 1: Update tests to the new contract**

In `tests/test_transcript.py`, replace the two `TestExtractTranscriptWithMock` test bodies so every call passes `model_path`, and add the two new skip tests to `TestExtractTranscriptFallback`:

```python
    def test_returns_none_when_no_model(self, selftest_mp4, tmp_path, monkeypatch):
        """No resolved model must skip transcription — never a silent fallback."""
        hash_dir = str(tmp_path / "hash")
        metadata = {"has_audio": True}
        calls = [0]
        monkeypatch.setattr(
            extract, "_find_whisper_binary", lambda: calls.__setitem__(0, calls[0] + 1)
        )
        result = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=None
        )
        assert result is None
        assert calls[0] == 0  # whisper never even looked up

    def test_no_test_model_fallback_helper(self):
        """The Homebrew test-model fallback is gone."""
        assert not hasattr(extract, "_find_whisper_model")
```

And in `TestExtractTranscriptWithMock`, change both `extract.extract_transcript(...)` calls to:

```python
        model_path = str(tmp_path / "ggml-base.en.bin")
        with open(model_path, "wb") as f:
            f.write(b"fake model")

        result = extract.extract_transcript(
            selftest_mp4, hash_dir, metadata, no_audio=False, model_path=model_path
        )
```

(In `test_transcript_cached_on_second_call`, apply the same for `result1` and `result2` calls — same `model_path` variable, created once at the top of the test.)

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_transcript.py -v`
Expected: FAIL — `extract_transcript() got an unexpected keyword argument 'model_path'` and `test_no_test_model_fallback_helper` fails (`_find_whisper_model` still exists).

- [ ] **Step 3: Implement**

In `scripts/extract.py`:

1. **Delete** the whole `_find_whisper_model()` function (lines ~246-268, including the Homebrew `for-tests-ggml-tiny.bin` block).

2. Change the `extract_transcript` signature and add the skip guard after the `no_audio` check:

```python
def extract_transcript(video_path, hash_dir, metadata, no_audio=False, model_path=None):
    """Extract audio and transcribe with whisper-cpp.

    Transcript is per-video (not per-range), stored at hash_dir level.
    model_path is required for transcription — None skips (no silent fallback).
    Returns transcript dict or None if skipped/unavailable.
    """
    transcript_path = os.path.join(hash_dir, "transcript.json")

    # Return cached transcript if it exists
    if os.path.isfile(transcript_path):
        with open(transcript_path) as f:
            return json.load(f)

    if no_audio or not metadata.get("has_audio", False):
        return None

    if model_path is None:
        print(
            "WARNING: No whisper model found — skipping transcription. "
            "Run ./setup or pass --model.",
            file=sys.stderr,
        )
        return None
```

3. In the whisper command build (formerly lines ~312-331): remove the line `model_path = _find_whisper_model()` and change both branches to append the model unconditionally — replace `if model_path: cmd_whisper.extend(["-m", model_path])` with plain `cmd_whisper.extend(["-m", model_path])` (both the `whisper-cli` and legacy branches).

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_transcript.py -v`
Expected: all PASS. (`main()` still calls `extract_transcript` without `model_path` — that's Task 3; the default `None` keeps the pipeline importable and the full suite green because `main()`-level tests either mock whisper or have no model and now skip.)

- [ ] **Step 5: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS.

```bash
git add scripts/extract.py tests/test_transcript.py
git commit -m "feat(extract): require explicit model for transcription, drop test-model fallback"
```

---

### Task 3: `--model` CLI flag + truth fields in metadata/summary

**Files:**
- Modify: `scripts/extract.py` — `build_parser()` (line ~24), `main()` (lines ~438-549)
- Modify: `tests/test_model_resolution.py` (append CLI-level tests)

**Interfaces:**
- Consumes: `resolve_whisper_model` (Task 1), `extract_transcript(..., model_path=)` (Task 2).
- Produces: CLI flag `--model VALUE`; `metadata.json` + stdout summary gain `whisper_model` (label or null), `whisper_model_source` (`"flag"|"env"|"cache"|"none"`), `transcript_status` (`"ok"|"skipped_no_audio"|"skipped_no_model"|"failed"`). The old hardcoded `whisper_model: "base"` is gone. Package 3's `report.json` reads these fields.

- [ ] **Step 1: Write the failing CLI tests**

Append to `tests/test_model_resolution.py`:

```python
import json
import subprocess
import sys

EXTRACT_PY = os.path.join(SCRIPTS_DIR, "extract.py")


def _run_cli(video, out_dir, env_overrides, *extra_args):
    """Run extract.py in a subprocess with a controlled environment."""
    env = os.environ.copy()
    env.update(env_overrides)
    cmd = [sys.executable, EXTRACT_PY, video, "--output-dir", str(out_dir)] + list(extra_args)
    return subprocess.run(cmd, capture_output=True, text=True, env=env)


class TestModelCLI:
    def test_no_model_skips_with_status(self, selftest_mp4, tmp_path, mock_whisper_bin):
        """Empty HOME (no models dir) => transcription skipped, never a fallback."""
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {
                "HOME": str(home),
                "PATH": mock_whisper_bin + os.pathsep + os.environ["PATH"],
            },
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        assert summary["has_transcript"] is False
        assert summary["transcript_status"] == "skipped_no_model"
        assert summary["metadata"]["whisper_model"] is None
        assert summary["metadata"]["whisper_model_source"] == "none"
        assert "skipping transcription" in result.stderr.lower()

    def test_model_flag_records_truth(self, selftest_mp4, tmp_path, mock_whisper_bin):
        """--model <path> => transcript ok, real label recorded (not hardcoded 'base')."""
        home = tmp_path / "home"
        home.mkdir()
        model = tmp_path / "ggml-tiny.en.bin"
        model.write_bytes(b"fake model")
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {
                "HOME": str(home),
                "PATH": mock_whisper_bin + os.pathsep + os.environ["PATH"],
            },
            "--model", str(model),
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        assert summary["has_transcript"] is True
        assert summary["transcript_status"] == "ok"
        assert summary["metadata"]["whisper_model"] == "tiny.en"
        assert summary["metadata"]["whisper_model_source"] == "flag"

    def test_explicit_missing_model_exits_2(self, selftest_mp4, tmp_path):
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4, tmp_path / "out", {"HOME": str(home)}, "--model", "large-v3"
        )
        assert result.returncode == 2
        assert "not found" in result.stderr

    def test_env_missing_model_exits_2(self, selftest_mp4, tmp_path):
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4,
            tmp_path / "out",
            {"HOME": str(home), "HEIMDALL_WHISPER_MODEL": "nope"},
        )
        assert result.returncode == 2
        assert "not found" in result.stderr

    def test_no_audio_status(self, selftest_mp4, tmp_path):
        home = tmp_path / "home"
        home.mkdir()
        result = _run_cli(
            selftest_mp4, tmp_path / "out", {"HOME": str(home)}, "--no-audio"
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        assert summary["transcript_status"] == "skipped_no_audio"
```

Note: `mock_whisper_bin` lives in `tests/conftest.py` and is injected via PATH; the mock ignores `-m` and always writes canned JSON, which is exactly what makes `test_model_flag_records_truth` deterministic.

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_model_resolution.py::TestModelCLI -v`
Expected: FAIL — `--model` is an unknown argument; `transcript_status` KeyError.

- [ ] **Step 3: Implement CLI wiring**

In `scripts/extract.py`:

1. `build_parser()` — add to the modes group (after `--no-audio`):

```python
    mode_group.add_argument(
        "--model",
        default=None,
        help="Whisper model: name (base.en) or file path (default: auto-detect)",
    )
```

2. `main()` — after the ffmpeg check and mode validation (line ~466, before cache paths), add:

```python
    # Resolve whisper model up front — explicit requests must not silently degrade
    try:
        model_path, model_source = resolve_whisper_model(args.model)
    except ValueError as e:
        print("ERROR: {}".format(e), file=sys.stderr)
        return EXIT_BAD_INPUT
```

3. Change the transcription call (line ~524) to:

```python
    transcript = extract_transcript(
        video_path, hash_dir, metadata, no_audio=args.no_audio, model_path=model_path
    )
```

4. Replace the metadata block at lines ~529-536 (`metadata["extraction_strategy"] = ...` through the `whisper_model` hardcode) with:

```python
    if transcript is not None:
        transcript_status = "ok"
    elif args.no_audio or not metadata.get("has_audio", False):
        transcript_status = "skipped_no_audio"
    elif model_path is None:
        transcript_status = "skipped_no_model"
    else:
        transcript_status = "failed"

    metadata["extraction_strategy"] = "interval"
    metadata["extraction_fps"] = frame_info["extraction_fps"]
    metadata["num_frames"] = frame_info["num_frames"]
    metadata["has_transcript"] = transcript is not None
    metadata["transcript_status"] = transcript_status
    metadata["whisper_model"] = (
        _model_label(model_path) if (transcript is not None and model_path) else None
    )
    metadata["whisper_model_source"] = model_source
```

5. Add `"transcript_status": transcript_status,` to the fresh-extraction summary dict (line ~539), and `"transcript_status": metadata.get("transcript_status"),` to the cached summary dict (line ~500).

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_model_resolution.py -v`
Expected: all PASS.

- [ ] **Step 5: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS (pipeline/metadata tests only assert existing keys; new keys are additive).

```bash
git add scripts/extract.py tests/test_model_resolution.py
git commit -m "feat(extract): add --model flag and record true whisper model in metadata"
```

---

### Task 4: `download-model.sh` — verified, resumable, atomic

**Files:**
- Create: `scripts/download-model.sh`
- Create: `tests/test_download_model.py`
- Modify: `tests/conftest.py` (add `http_server` fixture — Package 4 reuses it)

**Interfaces:**
- Consumes: `scripts/models.json` (Task 1).
- Produces: `bash scripts/download-model.sh <model-name> [--models-dir DIR] [--manifest FILE]` — exit 0 with `<models-dir>/<file>` installed and checksum-verified; exit 1 on unknown model / download failure / checksum mismatch (no partial files left). `setup` (Task 5) calls it. Test fixture `http_server -> (serve_dir: Path, base_url: str)`.

- [ ] **Step 1: Add the http_server fixture**

Append to `tests/conftest.py`:

```python
@pytest.fixture
def http_server(tmp_path):
    """Local HTTP server serving tmp files — keeps download tests network-free.

    Yields (serve_dir, base_url); files written into serve_dir are served
    at base_url/<name>.
    """
    import re

    serve_dir = tmp_path / "serve"
    serve_dir.mkdir()
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "http.server", "0",
            "--bind", "127.0.0.1", "--directory", str(serve_dir),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    # http.server announces its port on the first stdout line
    line = proc.stdout.readline()
    match = re.search(r"port (\d+)", line)
    assert match, "http.server did not announce a port: {!r}".format(line)
    base_url = "http://127.0.0.1:{}".format(match.group(1))
    yield serve_dir, base_url
    proc.terminate()
    proc.wait()
```

- [ ] **Step 2: Write the failing tests**

Create `tests/test_download_model.py`:

```python
"""Tests for scripts/download-model.sh (checksum-verified model download)."""

import hashlib
import json
import os
import subprocess

import pytest

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
DOWNLOAD_SH = os.path.join(SCRIPTS_DIR, "download-model.sh")

PAYLOAD = b"pretend this is a ggml model" * 64


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def _write_manifest(path, url, sha256):
    manifest = {
        "test.en": {
            "file": "ggml-test.en.bin",
            "size": len(PAYLOAD),
            "sha256": sha256,
            "url": url,
        }
    }
    with open(str(path), "w") as f:
        json.dump(manifest, f)
    return str(path)


def _run(model, manifest, models_dir):
    env = os.environ.copy()
    env["HEIMDALL_CURL_RETRY_DELAY"] = "0"  # fail fast in tests; users keep 5s
    return subprocess.run(
        ["bash", DOWNLOAD_SH, model, "--manifest", manifest, "--models-dir", str(models_dir)],
        capture_output=True,
        text=True,
        env=env,
    )


class TestDownloadModel:
    def test_downloads_and_installs(self, tmp_path, http_server):
        serve_dir, base_url = http_server
        (serve_dir / "model.bin").write_bytes(PAYLOAD)
        manifest = _write_manifest(
            tmp_path / "m.json", base_url + "/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"

        result = _run("test.en", manifest, models_dir)

        assert result.returncode == 0, result.stderr
        installed = models_dir / "ggml-test.en.bin"
        assert installed.read_bytes() == PAYLOAD
        assert not (models_dir / "ggml-test.en.bin.part").exists()

    def test_checksum_mismatch_fails_cleanly(self, tmp_path, http_server):
        serve_dir, base_url = http_server
        (serve_dir / "model.bin").write_bytes(b"corrupted bytes")
        manifest = _write_manifest(
            tmp_path / "m.json", base_url + "/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"

        result = _run("test.en", manifest, models_dir)

        assert result.returncode != 0
        assert "checksum mismatch" in result.stderr.lower()
        assert not (models_dir / "ggml-test.en.bin").exists()
        assert not (models_dir / "ggml-test.en.bin.part").exists()

    def test_existing_valid_model_skips_download(self, tmp_path):
        """Valid existing file => success without any network access
        (URL is unroutable on purpose)."""
        manifest = _write_manifest(
            tmp_path / "m.json", "http://127.0.0.1:1/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"
        models_dir.mkdir()
        (models_dir / "ggml-test.en.bin").write_bytes(PAYLOAD)

        result = _run("test.en", manifest, models_dir)

        assert result.returncode == 0, result.stderr
        assert "already present" in result.stdout.lower()

    def test_existing_corrupt_model_heals(self, tmp_path, http_server):
        """A previously corrupted install (the old bare-curl bug) gets re-downloaded."""
        serve_dir, base_url = http_server
        (serve_dir / "model.bin").write_bytes(PAYLOAD)
        manifest = _write_manifest(
            tmp_path / "m.json", base_url + "/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"
        models_dir.mkdir()
        (models_dir / "ggml-test.en.bin").write_bytes(b"<html>429 Too Many Requests</html>")

        result = _run("test.en", manifest, models_dir)

        assert result.returncode == 0, result.stderr
        assert (models_dir / "ggml-test.en.bin").read_bytes() == PAYLOAD

    def test_unknown_model_fails(self, tmp_path):
        manifest = _write_manifest(
            tmp_path / "m.json", "http://127.0.0.1:1/x.bin", _sha256(PAYLOAD)
        )
        result = _run("nope", manifest, tmp_path / "models")
        assert result.returncode != 0
        assert "unknown model" in (result.stderr + result.stdout).lower()

    def test_download_failure_fails(self, tmp_path):
        """Unroutable URL => nonzero exit, nothing installed."""
        manifest = _write_manifest(
            tmp_path / "m.json", "http://127.0.0.1:1/model.bin", _sha256(PAYLOAD)
        )
        models_dir = tmp_path / "models"
        result = _run("test.en", manifest, models_dir)
        assert result.returncode != 0
        assert not (models_dir / "ggml-test.en.bin").exists()
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_download_model.py -v`
Expected: FAIL — `bash: scripts/download-model.sh: No such file or directory` (nonzero exit asserts trip on the wrong messages / installs missing).

- [ ] **Step 4: Implement the script**

Create `scripts/download-model.sh` (then `chmod +x scripts/download-model.sh`):

```bash
#!/usr/bin/env bash
# Download and verify a whisper GGML model, per scripts/models.json.
# Usage: download-model.sh <model-name> [--models-dir DIR] [--manifest FILE]
#
# Exit 0: model installed (or already present) and checksum-verified.
# Exit 1: unknown model, download failure, or checksum mismatch.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ $# -lt 1 ]]; then
    echo "usage: download-model.sh <model-name> [--models-dir DIR] [--manifest FILE]" >&2
    exit 1
fi

MODEL_NAME="$1"
shift
MODELS_DIR="${HOME}/.cache/heimdall/models"
MANIFEST="${SCRIPT_DIR}/models.json"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --models-dir) MODELS_DIR="$2"; shift 2 ;;
        --manifest) MANIFEST="$2"; shift 2 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

read_field() {
    MANIFEST="$MANIFEST" MODEL_NAME="$MODEL_NAME" FIELD="$1" python3 -c '
import json, os, sys
manifest = json.load(open(os.environ["MANIFEST"]))
entry = manifest.get(os.environ["MODEL_NAME"])
if entry is None:
    sys.exit("unknown model: {} (available: {})".format(
        os.environ["MODEL_NAME"], ", ".join(sorted(manifest))))
print(entry[os.environ["FIELD"]])
'
}

MODEL_FILE="$(read_field file)"
MODEL_URL="$(read_field url)"
MODEL_SHA="$(read_field sha256)"
TARGET="${MODELS_DIR}/${MODEL_FILE}"

sha256_of() {
    if command -v sha256sum &>/dev/null; then
        sha256sum "$1" | awk '{print $1}'
    else
        shasum -a 256 "$1" | awk '{print $1}'
    fi
}

if [[ -f "$TARGET" ]]; then
    if [[ "$(sha256_of "$TARGET")" == "$MODEL_SHA" ]]; then
        echo "==> Model ${MODEL_NAME} already present and verified"
        exit 0
    fi
    echo "==> Existing ${MODEL_FILE} fails checksum — re-downloading"
    rm -f "$TARGET"
fi

mkdir -p "$MODELS_DIR"
TMP="${TARGET}.part"

echo "==> Downloading ${MODEL_NAME} from ${MODEL_URL}"
# HEIMDALL_CURL_RETRY_DELAY exists so tests can fail fast; users get the 5s default.
if ! curl -L --fail --retry 5 --retry-delay "${HEIMDALL_CURL_RETRY_DELAY:-5}" \
        --retry-all-errors --retry-connrefused \
        -C - -o "$TMP" "$MODEL_URL"; then
    rm -f "$TMP"
    echo "ERROR: download failed for ${MODEL_NAME}" >&2
    exit 1
fi

ACTUAL_SHA="$(sha256_of "$TMP")"
if [[ "$ACTUAL_SHA" != "$MODEL_SHA" ]]; then
    rm -f "$TMP"
    echo "ERROR: checksum mismatch for ${MODEL_NAME}" >&2
    echo "  expected: ${MODEL_SHA}" >&2
    echo "  actual:   ${ACTUAL_SHA}" >&2
    exit 1
fi

mv "$TMP" "$TARGET"
echo "==> Model installed: ${TARGET}"
```

Note on `set -e` + curl: the `if ! curl …` form keeps the retry-exhausted failure inside our error handling instead of aborting the script mid-cleanup. `read_field` passes values via environment variables, not string interpolation, so a hostile manifest path can't inject Python.

- [ ] **Step 5: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_download_model.py -v`
Expected: all PASS (retry delay is 0 in tests, so the unroutable-URL case fails in ~1s).

- [ ] **Step 6: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS.

```bash
chmod +x scripts/download-model.sh
git add scripts/download-model.sh tests/test_download_model.py tests/conftest.py
git commit -m "feat(setup): add checksum-verified whisper model downloader"
```

---

### Task 5: Wire `setup` to the verified downloader

**Files:**
- Modify: `setup` — usage (line ~11), flag parsing (line ~98), model download block (lines ~135-146)

**Interfaces:**
- Consumes: `scripts/download-model.sh` (Task 4).
- Produces: `./setup [--model NAME]` (default `base.en`) — the only model-download path users touch.

- [ ] **Step 1: Replace the bare-curl block**

In `setup`, replace lines 135-146 (the `# Download whisper model if not present` block through `fi`) with:

```bash
    # Download whisper model (checksum-verified; heals corrupt files)
    bash "${SCRIPT_DIR}/scripts/download-model.sh" "$model"
```

- [ ] **Step 2: Add the --model flag**

In `main()`, change `local host="auto"` block (line ~95) to include `local model="base.en"`, and add to the argument `case` (line ~99):

```bash
            --model) model="$2"; shift 2 ;;
```

In `usage()` (line ~11), add below the `--host` line:

```bash
    echo "  --model NAME   Whisper model to download: base.en, small.en (default: base.en)"
```

- [ ] **Step 3: Verify syntax and behavior**

Run: `bash -n setup && bash setup --help`
Expected: no syntax errors; help text shows `--model NAME`.

Run: `bash setup --model bogus 2>&1 | head -20 || true` — but only if deps are already installed locally (it runs install-deps first). If deps are present, expected: fails at the download step with `unknown model: bogus (available: base.en, small.en)`. If deps are missing on this machine, skip this check — the downloader's own tests cover it.

- [ ] **Step 4: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS.

```bash
git add setup
git commit -m "feat(setup): use verified model downloader with --model flag"
```

---

### Task 6: Docs + report template + version bump

**Files:**
- Modify: `agents/heimdall.md` (report templates, lines ~82 and ~117)
- Modify: `README.md` (Requirements section, line ~74)
- Modify: `CLAUDE.md` (Coding Conventions, line ~40)
- Modify: `.claude-plugin/plugin.json` (version)

**Interfaces:**
- Consumes: `metadata.json` fields from Task 3 (`whisper_model`, `transcript_status`).
- Produces: report header names the model; docs describe model management; version 0.2.0.

- [ ] **Step 1: Report templates name the model**

In `agents/heimdall.md`, change both report header lines (bug-report template line ~82 and general template line ~117) from:

```markdown
**Source:** [filename] | **Duration:** [X sec] | **Resolution:** [WxH]
```

to:

```markdown
**Source:** [filename] | **Duration:** [X sec] | **Resolution:** [WxH] | **Transcript:** [whisper_model from metadata.json, or "none"]
```

And in Phase 3 (line ~57), after the metadata.json step, add:

```markdown
   - `metadata.json` includes `whisper_model` and `transcript_status` — name the model in the report header; if transcription was skipped, say why (e.g. "none — no whisper model installed")
```

- [ ] **Step 2: README + CLAUDE.md**

In `README.md` Requirements (line ~74), change the whisper-cpp line to:

```markdown
- **whisper-cpp** (optional) — audio transcription. Setup downloads the `base.en` model (148MB, checksum-verified) to `~/.cache/heimdall/models/`; higher-accuracy opt-in: `./setup --model small.en`, or per-run `--model`/`$HEIMDALL_WHISPER_MODEL`.
```

In `CLAUDE.md` Coding Conventions (after the Transcript-sharing bullet, line ~44), add:

```markdown
- **Whisper models** — pinned in `scripts/models.json` (name → sha256/url); downloads only via `scripts/download-model.sh`; no fallback models — missing model means transcription is skipped with `transcript_status: "skipped_no_model"`
```

- [ ] **Step 3: Version bump**

In `.claude-plugin/plugin.json`, change `"version": "0.1.0"` to `"version": "0.2.0"`.

- [ ] **Step 4: Full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS.

```bash
git add agents/heimdall.md README.md CLAUDE.md .claude-plugin/plugin.json
git commit -m "docs: document whisper model management; bump to 0.2.0"
```

---

## Done Criteria (Package 1)

- `python3 -m pytest tests/ -v` fully green, no network access needed.
- `grep -n "for-tests" scripts/extract.py` → no matches.
- `python3 scripts/extract.py fixtures/selftest.mp4 --overview --output-dir /tmp/heimdall-check` on a machine with no models → exit 0, `transcript_status: "skipped_no_model"` in output.
- `bash setup --help` shows `--model`; plugin version is 0.2.0.
