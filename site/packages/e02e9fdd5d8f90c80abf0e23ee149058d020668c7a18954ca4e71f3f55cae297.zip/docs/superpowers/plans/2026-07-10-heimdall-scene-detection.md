# Scene-Detection Extraction (v0.3.0) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extract frames where the picture actually changes — scene detection for 1–30 min videos, keyframes for longer ones, interval for short clips — driven by a `frames.json` manifest that becomes the single source of frame timestamps.

**Architecture:** `extract.py` gains a strategy selector (auto by duration, `--strategy` override, detail mode always interval). Every strategy writes `frames.json` (`[{file, timestamp_sec, scene_score, origin}]`) into the mode cache dir via a shared `write_frames_manifest()`. Scene extraction is a two-pass ffmpeg flow: pass 1 detects per-frame `lavfi.scene_score` (no images written), Python selects scene frames above a threshold unioned with time anchors under a frame cap, pass 2 seeks and writes each selected frame. `correlate_frames_transcript()` reads timestamps from the manifest instead of assuming `start + i × interval`, so non-uniform frames correlate correctly. Two latent bugs are fixed along the way.

**Tech Stack:** Python 3.8+ stdlib only (`extract.py`), ffmpeg/ffprobe via subprocess, bash (`generate-fixture.sh`, `install-deps.sh`), pytest.

**Spec:** `docs/superpowers/specs/2026-07-10-heimdall-roadmap-v0.2-v0.6-design.md` §3.

## Global Constraints

- `scripts/extract.py` is Python 3.8+, **stdlib only** — no pip imports; external tools (ffmpeg, ffprobe, whisper) via subprocess only.
- Exit codes unchanged: 0 success, 1 missing deps, 2 bad input, 3 extraction failed. `--detail` without a full `--start`/`--end` range → **exit 2** (EXIT_BAD_INPUT).
- Tests must be **network-free** and self-contained. Scene/keyframe tests use ffmpeg on local fixtures; scratch files (ffmpeg metadata dumps) are written **inside the cache dir**, never `/tmp` (this machine's sandbox blocks `/var/folders` temp writes).
- **stdout summary and `frame_transcript_map.json` stay backward-compatible** — new keys only, existing keys and shapes unchanged.
- `frames.json` entry shape is fixed: `{"file": str, "timestamp_sec": float, "scene_score": float|null, "origin": str}` with `origin ∈ {"interval","scene","anchor","keyframe"}`.
- Scene-threshold default is **0.08** (`--scene-threshold`). Anchor spacing is **45s**, anchor skip radius **22.5s**, dedupe window **1.0s**. Scene band is **60s–30min (1800s)**; keyframe band is **>1800s**.
- Commits: small and atomic, conventional-commit style, **no co-author tags and no `Claude-Session:` trailers or links** (public repo).
- Run tests with: `python3 -m pytest tests/ -v` from the repo root. On this machine the `http_server`-fixture tests (Package 1) need an **unsandboxed** run to bind loopback; the full suite is otherwise sandbox-clean.
- **Version bumps once** for the package (Task 7): `.claude-plugin/plugin.json` → `0.3.0`.

## File Structure

- **Modify** `scripts/extract.py` — the whole feature lands here:
  - Bug fix: `--detail` range guard + delete dead `hash_dir` line (Task 1).
  - `write_frames_manifest()`; interval `extract_frames()` writes the manifest; `correlate_frames_transcript()` reads it (Task 2).
  - Scene path: `parse_scene_metadata()`, `detect_scenes()`, `select_scene_frames()`, `select_evenly()`, `_extract_single_frame()`, `extract_scene_frames()` (Task 4).
  - Keyframe path: `list_keyframe_timestamps()`, `extract_keyframes()` (Task 5).
  - Dispatch: `select_strategy()`, `--strategy`/`--scene-threshold` flags, strategy routing + metadata recording in `main()` (Task 6).
- **Modify** `scripts/generate-fixture.sh` — add a `scene` variant (drawbox cut at a known timestamp) (Task 3).
- **Modify** `tests/conftest.py` — add a `scene_mp4` session fixture (Task 3).
- **Create** `tests/test_frames_manifest.py` — manifest + correlation tests (Task 2).
- **Create** `tests/test_scene_extraction.py` — parser, selection, scene integration (Tasks 3–4).
- **Create** `tests/test_keyframe_extraction.py` — keyframe listing/thinning/integration (Task 5).
- **Create** `tests/test_strategy.py` — strategy selection + CLI dispatch (Task 6).
- **Modify** `tests/test_pipeline.py` — add the two new `--detail` guard cases (Task 1).
- **Modify** `scripts/install-deps.sh` + **create** `tests/test_install_deps.py` — parked Package-1 follow-ups (Task 8).
- **Modify** docs: `agents/heimdall.md`, `README.md`, `CLAUDE.md`, `.claude-plugin/plugin.json` (Task 7).

**Insertion points shift as the file grows — locate by structure (function/comment above), not by absolute line number.** Line hints below are from the pre-Package-2 file (663 lines).

---

### Task 1: Fix the `--detail` range guard; delete the dead `hash_dir` line

**Files:**
- Modify: `scripts/extract.py` — `build_parser()` `--start` default (~line 33), `main()` mode validation (~line 540), `main()` cache-path block (~lines 562–565)
- Modify: `tests/test_pipeline.py` — add two guard cases

**Interfaces:**
- Consumes: nothing new.
- Produces: `--detail` requires **both** `--start` and `--end` explicitly; any omission → `EXIT_BAD_INPUT`. `--start` default becomes the sentinel `None` (normalized to `0.0` for overview in `main()`). Behavior for every other invocation is unchanged.

**Why the sentinel:** the real bug is that `--detail --start N` with no `--end` falls through `get_cache_dir()`'s `args.end is not None` check to the `full/` subdir and overwrites the overview extraction with 3fps frames. `--start` has a default of `0`, so "was it supplied?" is otherwise undetectable. The spec (§3 Bug fixes) requires *both* — the sentinel makes that literally enforceable.

- [ ] **Step 1: Write the failing tests**

In `tests/test_pipeline.py`, inside `class TestPipelineIntegration`, add after `test_detail_without_range_exits_with_code_2`:

```python
    def test_detail_start_without_end_exits_2(self, selftest_mp4, tmp_output_dir):
        """--detail --start N with no --end must not clobber the full/ cache."""
        cmd = [
            sys.executable, EXTRACT_PY, selftest_mp4,
            "--output-dir", tmp_output_dir, "--detail", "--start", "1",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 2
        assert "requires --start and --end" in result.stderr

    def test_detail_end_without_start_exits_2(self, selftest_mp4, tmp_output_dir):
        """--detail --end N with no explicit --start is rejected too (spec: both)."""
        cmd = [
            sys.executable, EXTRACT_PY, selftest_mp4,
            "--output-dir", tmp_output_dir, "--detail", "--end", "2",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 2
        assert "requires --start and --end" in result.stderr
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -m pytest tests/test_pipeline.py -k "detail" -v`
Expected: the two new tests FAIL — `test_detail_end_without_start_exits_2` currently gets exit 0 (start defaults to 0, end=2 → a valid range today); `test_detail_start_without_end_exits_2` currently gets exit 0 as well (start=1≠0 slips past the weak `args.start == 0` guard — this is the bug).

- [ ] **Step 3: Make `--start` a sentinel**

In `build_parser()`, change the `--start` argument (currently `default=0`):

```python
    time_group.add_argument(
        "--start", type=float, default=None, help="Start time in seconds (default: 0)"
    )
```

- [ ] **Step 4: Fix the validation and normalize start**

In `main()`, replace the mode-validation block (currently):

```python
    # Validate mode arguments
    if args.detail and args.start == 0 and args.end is None:
        print("ERROR: --detail requires --start and --end to specify a time range", file=sys.stderr)
        return EXIT_BAD_INPUT
```

with:

```python
    # Validate mode arguments. --detail must carry an explicit range: without
    # both --start and --end it falls through to the "full" cache subdir and
    # clobbers the overview extraction with high-density detail frames.
    if args.detail and (args.start is None or args.end is None):
        print("ERROR: --detail requires --start and --end to specify a time range", file=sys.stderr)
        return EXIT_BAD_INPUT

    # Overview mode: start defaults to 0. The sentinel None above only exists to
    # detect an omitted --start in detail mode.
    if args.start is None:
        args.start = 0.0
```

- [ ] **Step 5: Delete the dead `hash_dir` line**

In `main()`, the cache-path block currently reads:

```python
    cache_dir = get_cache_dir(video_path, args)
    video_hash = compute_hash(video_path)
    hash_dir = os.path.dirname(cache_dir) if args.detail else cache_dir
    # For detail mode, hash_dir is <base>/<hash>, cache_dir is <base>/<hash>/range_X_Y
    # For overview mode, hash_dir == cache_dir parent is <base>/<hash>, cache_dir is <base>/<hash>/full
    hash_dir = os.path.join(args.output_dir or DEFAULT_CACHE_BASE, video_hash)
```

The third line is computed then immediately overwritten. Replace the whole block with:

```python
    cache_dir = get_cache_dir(video_path, args)
    video_hash = compute_hash(video_path)
    # hash_dir is <base>/<hash>; cache_dir is its full/ or range_X_Y/ subdir.
    # The transcript lives at hash_dir level (shared across modes); frames and
    # correlation live in cache_dir.
    hash_dir = os.path.join(args.output_dir or DEFAULT_CACHE_BASE, video_hash)
```

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_pipeline.py -v`
Expected: all PASS — the two new guard tests plus the existing `test_detail_mode_with_range` (`--start 0 --end 2` → both explicit → still valid) and `test_detail_without_range_exits_with_code_2` (`--detail` alone → both None → exit 2).

- [ ] **Step 7: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS (overview tests pass no `--start`; `main()` normalizes it to `0.0`).

```bash
git add scripts/extract.py tests/test_pipeline.py
git commit -m "fix(extract): require --start and --end for --detail; drop dead hash_dir line"
```

---

### Task 2: `frames.json` manifest; correlate from it (interval strategy)

**Files:**
- Modify: `scripts/extract.py` — add `write_frames_manifest()` after `extract_frames()` (~line 238); have `extract_frames()` build + write the manifest; rewrite `correlate_frames_transcript()` body (~lines 477–518)
- Create: `tests/test_frames_manifest.py`

**Interfaces:**
- Consumes: nothing new.
- Produces:
  - `write_frames_manifest(cache_dir, manifest) -> path` — writes `frames.json` (indented JSON list). `manifest` is a list of `{"file","timestamp_sec","scene_score","origin"}` dicts in frame order.
  - `extract_frames(...)` return dict gains `"manifest"` (the list just described; `origin="interval"`, `scene_score=None`). All existing keys (`frames_dir`, `num_frames`, `extraction_fps`, `frame_files`, `start`, `interval`) are unchanged. Tasks 4–5 produce the same `"manifest"` key.
  - `correlate_frames_transcript(frame_info, transcript, cache_dir)` — **signature unchanged**; now reads timestamps from `frame_info["manifest"]` (entry `timestamp_sec`/`file`) instead of `start + i × interval`. Tasks 4–6 rely on this.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_frames_manifest.py`:

```python
"""Tests for the frames.json manifest and manifest-driven correlation."""

import importlib.util
import json
import os
import types

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def _make_args(**kwargs):
    defaults = {
        "fps": None, "max_frames": 60, "start": 0, "end": None,
        "overview": True, "detail": False, "no_audio": True, "output_dir": None,
    }
    defaults.update(kwargs)
    return types.SimpleNamespace(**defaults)


class TestWriteFramesManifest:
    def test_writes_json_list(self, tmp_path):
        cache_dir = str(tmp_path / "c")
        os.makedirs(cache_dir)
        manifest = [
            {"file": "frame_001.jpg", "timestamp_sec": 1.0, "scene_score": None, "origin": "interval"},
        ]
        path = extract.write_frames_manifest(cache_dir, manifest)
        assert path == os.path.join(cache_dir, "frames.json")
        with open(path) as f:
            assert json.load(f) == manifest


class TestIntervalManifest:
    def test_interval_extraction_writes_manifest(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        args = _make_args(end=metadata["duration_sec"])
        frame_info = extract.extract_frames(selftest_mp4, cache_dir, metadata, args)

        assert "manifest" in frame_info
        manifest_path = os.path.join(cache_dir, "frames.json")
        assert os.path.isfile(manifest_path)
        with open(manifest_path) as f:
            manifest = json.load(f)

        assert len(manifest) == frame_info["num_frames"] == len(frame_info["manifest"])
        for entry in manifest:
            assert set(entry) == {"file", "timestamp_sec", "scene_score", "origin"}
            assert entry["origin"] == "interval"
            assert entry["scene_score"] is None
            assert entry["file"] in frame_info["frame_files"]
        timestamps = [e["timestamp_sec"] for e in manifest]
        assert timestamps == sorted(timestamps)


class TestManifestCorrelation:
    def test_correlation_reads_manifest_non_uniform(self, tmp_path):
        """The killer case: a frame at 40s (not start + i*interval) must map to
        the segment covering 40s. This proves the uniform-interval assumption
        is gone."""
        cache_dir = str(tmp_path / "c")
        os.makedirs(cache_dir)
        frame_info = {
            "manifest": [
                {"file": "frame_001.jpg", "timestamp_sec": 1.0, "scene_score": None, "origin": "interval"},
                {"file": "frame_002.jpg", "timestamp_sec": 40.0, "scene_score": 0.5, "origin": "scene"},
            ]
        }
        transcript = {
            "segments": [
                {"start": 0.0, "end": 2.0, "text": "hello"},
                {"start": 39.0, "end": 41.0, "text": "world"},
            ]
        }
        corr = extract.correlate_frames_transcript(frame_info, transcript, cache_dir)
        assert corr[0]["frame"] == "frame_001.jpg"
        assert corr[0]["transcript_segment"]["text"] == "hello"
        assert corr[1]["timestamp_sec"] == 40.0
        assert corr[1]["transcript_segment"]["text"] == "world"

        with open(os.path.join(cache_dir, "frame_transcript_map.json")) as f:
            assert json.load(f) == corr

    def test_correlation_none_transcript_writes_null(self, tmp_path):
        cache_dir = str(tmp_path / "c")
        os.makedirs(cache_dir)
        frame_info = {"manifest": [
            {"file": "frame_001.jpg", "timestamp_sec": 1.0, "scene_score": None, "origin": "interval"},
        ]}
        assert extract.correlate_frames_transcript(frame_info, None, cache_dir) is None
        with open(os.path.join(cache_dir, "frame_transcript_map.json")) as f:
            assert json.load(f) is None
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -m pytest tests/test_frames_manifest.py -v`
Expected: FAIL — `write_frames_manifest` missing (`AttributeError`); `extract_frames` return has no `"manifest"`; `correlate_frames_transcript` raises `KeyError`/`TypeError` because it still reads `frame_info["start"]`/`["interval"]`, which the synthetic `frame_info` doesn't provide.

- [ ] **Step 3: Add `write_frames_manifest()`**

In `scripts/extract.py`, immediately after `extract_frames()` (before `_model_label()`), add:

```python
def write_frames_manifest(cache_dir, manifest):
    """Write frames.json — the canonical per-frame record for this extraction.

    manifest: list of {"file","timestamp_sec","scene_score","origin"} dicts in
    frame order. This is the single source of frame timestamps for correlation,
    written for every strategy (interval, scene, keyframe). Returns the path.
    """
    path = os.path.join(cache_dir, "frames.json")
    with open(path, "w") as f:
        json.dump(manifest, f, indent=2)
    return path
```

- [ ] **Step 4: Build the manifest in `extract_frames()`**

In `extract_frames()`, replace the `return {...}` block at the end with a manifest build + write, then return:

```python
    manifest = []
    for i, frame_file in enumerate(extracted):
        manifest.append({
            "file": frame_file,
            "timestamp_sec": round(start + i * interval, 2),
            "scene_score": None,
            "origin": "interval",
        })
    write_frames_manifest(cache_dir, manifest)

    return {
        "frames_dir": frames_dir,
        "num_frames": len(extracted),
        "extraction_fps": round(1.0 / interval, 2) if interval > 0 else fps,
        "frame_files": extracted,
        "start": start,
        "interval": interval,
        "manifest": manifest,
    }
```

- [ ] **Step 5: Rewrite `correlate_frames_transcript()` to read the manifest**

Replace the body of `correlate_frames_transcript()` with:

```python
def correlate_frames_transcript(frame_info, transcript, cache_dir):
    """Match each frame timestamp to the overlapping transcript segment.

    Frame timestamps come from the extraction manifest (frame_info["manifest"]),
    not a uniform interval — scene and keyframe frames are non-uniformly spaced.
    Writes frame_transcript_map.json to cache_dir. Shape is unchanged.
    """
    if transcript is None:
        map_path = os.path.join(cache_dir, "frame_transcript_map.json")
        with open(map_path, "w") as f:
            json.dump(None, f)
        return None

    segments = transcript.get("segments", [])
    manifest = frame_info["manifest"]

    correlation = []
    for entry in manifest:
        frame_ts = entry["timestamp_sec"]

        matching_segment = None
        for seg in segments:
            if seg["start"] <= frame_ts <= seg["end"]:
                matching_segment = {
                    "start": seg["start"],
                    "end": seg["end"],
                    "text": seg["text"],
                }
                break

        correlation.append({
            "frame": entry["file"],
            "timestamp_sec": round(frame_ts, 2),
            "transcript_segment": matching_segment,
        })

    map_path = os.path.join(cache_dir, "frame_transcript_map.json")
    with open(map_path, "w") as f:
        json.dump(correlation, f, indent=2)

    return correlation
```

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_frames_manifest.py -v`
Expected: all PASS.

- [ ] **Step 7: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS. (`test_frames.py` still finds every key it asserts; `test_pipeline.py` exercises the full interval → manifest → correlation path; `frames.json` is additive.)

```bash
git add scripts/extract.py tests/test_frames_manifest.py
git commit -m "feat(extract): write frames.json manifest and correlate from it"
```

---

### Task 3: Scene-cut test fixture

**Files:**
- Modify: `scripts/generate-fixture.sh` — add a `scene` variant
- Modify: `tests/conftest.py` — add a `scene_mp4` session fixture
- Create: `tests/test_scene_extraction.py` (fixture-validation tests only for now; Task 4 appends)

**Interfaces:**
- Consumes: nothing.
- Produces: `bash scripts/generate-fixture.sh <out> scene` writes a 6s, 320×240 clip: static gray with a red box that appears at **t=3.0** (one synthetic scene cut, static before and after). Verified on this machine to score **0.1125** at t=3.0 — above the 0.08 default threshold. `scene_mp4` pytest fixture returns the path (auto-generated, session-scoped). Tasks 4 and 6 consume `scene_mp4`.

**Note — no `drawtext`:** this machine's ffmpeg has **no freetype** (`drawtext` absent, confirmed), matching the existing fixture's deliberate text-free design. The "dialog appears" cut from spec §3 is realized with `drawbox` (a box appearing == the change), which needs no freetype and produces a clean, known-timestamp cut.

- [ ] **Step 1: Add the `scene` variant to `generate-fixture.sh`**

In `scripts/generate-fixture.sh`, after the line `OUTPUT="${1:-fixtures/selftest.mp4}"`, add:

```bash
VARIANT="${2:-basic}"
```

Then replace the single generation block (from `echo "==> Generating test fixture: ${OUTPUT}"` through the closing `"$OUTPUT"` ffmpeg invocation) with a branch:

```bash
if [[ "$VARIANT" == "scene" ]]; then
    echo "==> Generating scene-cut fixture: ${OUTPUT}"
    # 6 seconds, 320x240, 10fps. Static gray background; a filled red box
    # appears at t=3 -> exactly one synthetic scene cut at a known timestamp,
    # static before and after (exercises the anchor floor around the cut).
    # drawbox (not drawtext) keeps this freetype-free, like the basic fixture.
    ffmpeg -y -v quiet \
        -f lavfi -i "color=c=gray:size=320x240:d=6:r=10" \
        -f lavfi -i "sine=frequency=440:duration=6" \
        -vf "drawbox=x=80:y=60:w=160:h=120:color=red@1.0:t=fill:enable='gte(t,3)'" \
        -c:v libx264 -preset ultrafast -crf 30 \
        -c:a aac -b:a 32k \
        -shortest \
        "$OUTPUT"
else
    echo "==> Generating test fixture: ${OUTPUT}"
    # 5 seconds, 320x240, 10fps
    # - Frames cycle through red/green/blue (no text overlay — avoids freetype dep)
    # - Audio is a 440Hz sine wave
    ffmpeg -y -v quiet \
        -f lavfi -i "color=c=red:size=320x240:d=1.67:r=10[v1];color=c=green:size=320x240:d=1.67:r=10[v2];color=c=blue:size=320x240:d=1.66:r=10[v3];[v1][v2][v3]concat=n=3:v=1:a=0" \
        -f lavfi -i "sine=frequency=440:duration=5" \
        -c:v libx264 -preset ultrafast -crf 30 \
        -c:a aac -b:a 32k \
        -shortest \
        "$OUTPUT"
fi
```

(The `else` branch is the current command verbatim — preserve it exactly.)

- [ ] **Step 2: Add the `scene_mp4` fixture to conftest**

In `tests/conftest.py`, after the `selftest_mp4` fixture, add:

```python
@pytest.fixture(scope="session")
def scene_mp4():
    """Path to a fixture with one synthetic scene cut at t=3.0, auto-generated."""
    path = os.path.join(FIXTURES_DIR, "selftest_scene.mp4")
    if not os.path.isfile(path):
        subprocess.run(
            ["bash", GENERATE_FIXTURE, path, "scene"],
            check=True,
            capture_output=True,
        )
    return path
```

- [ ] **Step 3: Write the failing fixture-validation tests**

Create `tests/test_scene_extraction.py`:

```python
"""Tests for scene-detection extraction (fixture, parser, selection, e2e)."""

import importlib.util
import json
import os

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestSceneFixture:
    def test_fixture_generates(self, scene_mp4):
        assert os.path.isfile(scene_mp4)
        assert os.path.getsize(scene_mp4) > 0

    def test_fixture_metadata(self, scene_mp4, tmp_path):
        md = extract.extract_metadata(scene_mp4, str(tmp_path / "c"))
        assert md["resolution"] == "320x240"
        assert 5.5 <= md["duration_sec"] <= 6.5
        assert md["has_audio"] is True
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_scene_extraction.py -v`
Expected: both PASS (the fixture is generated on first use). This task's deliverable is the fixture itself; it has no failing-first red step because it adds infrastructure, not behavior — the assertions simply confirm the generator produces a well-formed clip.

- [ ] **Step 5: Confirm the cut is real (manual, one-time sanity)**

Run:
```bash
python3 -c "import subprocess, os; \
d=os.path.abspath('fixtures/selftest_scene.mp4'); \
m=os.path.abspath('fixtures/_scene_check.txt'); \
subprocess.run(['ffmpeg','-hide_banner','-v','error','-i',d,'-vf',\"select='gt(scene,0)',metadata=print:file=\"+m,'-f','null','-'],check=True); \
print(open(m).read()); os.remove(m)"
```
Expected: output contains `pts_time:3` followed by `lavfi.scene_score=0.11...` (a score above 0.08). If it prints nothing, the fixture has no detectable cut — stop and fix the generator before Task 4.

- [ ] **Step 6: Commit**

```bash
git add scripts/generate-fixture.sh tests/conftest.py tests/test_scene_extraction.py
git commit -m "test(fixtures): add scene-cut fixture variant (drawbox at t=3)"
```

---

### Task 4: Scene-detection two-pass extraction

**Files:**
- Modify: `scripts/extract.py` — add scene constants + functions after `write_frames_manifest()` (Task 2), before `_model_label()`
- Modify: `tests/test_scene_extraction.py` — append parser/selection/integration tests

**Interfaces:**
- Consumes: `write_frames_manifest()` (Task 2), `scene_mp4` fixture (Task 3).
- Produces:
  - `parse_scene_metadata(text) -> [(pts_time, score), ...]` — parses ffmpeg `metadata=print` output.
  - `detect_scenes(video_path, workdir) -> [(pts_time, score), ...]` — pass 1; writes/reads a metadata file inside `workdir`; `[]` on failure.
  - `select_evenly(items, k) -> list` — even thinning, keeps first/last, deterministic. **Task 5 consumes this.**
  - `select_scene_frames(candidates, duration, max_frames, threshold=SCENE_THRESHOLD_DEFAULT, anchor_interval=ANCHOR_INTERVAL_SEC) -> [(ts, score_or_None, origin), ...]` — pure selection.
  - `_extract_single_frame(video_path, timestamp, out_path) -> bool` — pass 2, one frame. **Task 5 consumes this.**
  - `extract_scene_frames(video_path, cache_dir, metadata, max_frames, threshold=SCENE_THRESHOLD_DEFAULT) -> frame_info` — same dict shape as `extract_frames` (plus `manifest`; `extraction_fps`/`interval` are `None`). **Task 6 consumes this.**
  - Constants: `SCENE_THRESHOLD_DEFAULT=0.08`, `ANCHOR_INTERVAL_SEC=45.0`, `ANCHOR_SKIP_RADIUS_SEC=22.5`, `DEDUPE_WINDOW_SEC=1.0`.

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_scene_extraction.py`:

```python
class TestParseSceneMetadata:
    def test_confirmed_format(self):
        text = (
            "frame:0    pts:30720   pts_time:3\n"
            "lavfi.scene_score=0.112500\n"
            "frame:1    pts:35840   pts_time:3.5\n"
            "lavfi.scene_score=0.000033\n"
        )
        assert extract.parse_scene_metadata(text) == [(3.0, 0.1125), (3.5, 0.000033)]

    def test_handles_missing_score_and_blanks(self):
        text = (
            "\n"
            "frame:0 pts:0 pts_time:0.28\n"
            "lavfi.scene_score=0.5\n"
            "frame:1 pts:1 pts_time:1.48\n"   # no score line -> dropped
            "frame:2 pts:2 pts_time:2.0\n"
            "lavfi.scene_score=0.3\n"
        )
        assert extract.parse_scene_metadata(text) == [(0.28, 0.5), (2.0, 0.3)]

    def test_empty(self):
        assert extract.parse_scene_metadata("") == []


class TestSelectEvenly:
    def test_under_cap_returns_all(self):
        assert extract.select_evenly([1.0, 2.0, 3.0], 5) == [1.0, 2.0, 3.0]

    def test_over_cap_keeps_endpoints(self):
        got = extract.select_evenly(list(range(10)), 3)
        assert got[0] == 0 and got[-1] == 9 and len(got) == 3

    def test_k_one_and_zero(self):
        assert extract.select_evenly([3, 4, 5], 1) == [3]
        assert extract.select_evenly([3, 4, 5], 0) == []

    def test_deterministic(self):
        items = list(range(100))
        assert extract.select_evenly(items, 7) == extract.select_evenly(items, 7)
        assert len(extract.select_evenly(items, 7)) == 7


class TestSelectSceneFrames:
    def test_threshold_filters_below(self):
        sel = extract.select_scene_frames([(10.0, 0.5), (20.0, 0.02)], duration=30, max_frames=60)
        times = [ts for (ts, _, _) in sel]
        assert 10.0 in times and 20.0 not in times
        assert {o for (_, _, o) in sel} == {"scene"}  # anchor@0 skipped (scene within 22.5s)

    def test_anchor_floor_on_static(self):
        sel = extract.select_scene_frames([], duration=100, max_frames=60)
        assert [ts for (ts, _, _) in sel] == [0.0, 45.0, 90.0]
        assert {o for (_, _, o) in sel} == {"anchor"}
        assert all(score is None for (_, score, _) in sel)

    def test_cap_keeps_all_anchors_fills_with_top_scene(self):
        cands = [(5.0, 0.9), (6.0, 0.9), (7.0, 0.9), (8.0, 0.9)]
        sel = extract.select_scene_frames(cands, duration=200, max_frames=6)
        assert len(sel) == 6
        anchors = [ts for (ts, _, o) in sel if o == "anchor"]
        scenes = sorted(ts for (ts, _, o) in sel if o == "scene")
        assert anchors == [45.0, 90.0, 135.0, 180.0]   # every anchor preserved
        assert scenes == [5.0, 6.0]                     # remaining slots: earliest of tied top scores
        assert [s for (s, _, _) in sel] == sorted(s for (s, _, _) in sel)  # ordered by time

    def test_anchors_thinned_when_alone_exceed_cap(self):
        sel = extract.select_scene_frames([], duration=450, max_frames=3)  # 11 anchors -> 3
        times = [ts for (ts, _, _) in sel]
        assert len(sel) == 3
        assert times[0] == 0.0 and times[-1] == 450.0
        assert {o for (_, _, o) in sel} == {"anchor"}


class TestExtractSceneFrames:
    def test_detects_cut_and_writes_manifest(self, scene_mp4, tmp_path):
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(scene_mp4, cache_dir)
        fi = extract.extract_scene_frames(scene_mp4, cache_dir, metadata, max_frames=60)

        assert fi["num_frames"] >= 1
        assert fi["num_frames"] == len(fi["manifest"])
        scene_entries = [e for e in fi["manifest"] if e["origin"] == "scene"]
        assert any(abs(e["timestamp_sec"] - 3.0) < 1.5 for e in scene_entries)

        with open(os.path.join(cache_dir, "frames.json")) as f:
            assert json.load(f) == fi["manifest"]
        for e in fi["manifest"]:
            assert os.path.isfile(os.path.join(cache_dir, "frames", e["file"]))
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -m pytest tests/test_scene_extraction.py -v`
Expected: the `TestSceneFixture` tests still PASS; every new class FAILS with `AttributeError` (functions not defined yet).

- [ ] **Step 3: Add constants and the scene functions**

In `scripts/extract.py`, directly below `DEFAULT_MODELS_DIR` (~line 72), add:

```python
SCENE_THRESHOLD_DEFAULT = 0.08
ANCHOR_INTERVAL_SEC = 45.0
ANCHOR_SKIP_RADIUS_SEC = 22.5
DEDUPE_WINDOW_SEC = 1.0
```

Then, immediately after `write_frames_manifest()`, add:

```python
def parse_scene_metadata(text):
    """Parse ffmpeg metadata=print output into [(pts_time, scene_score), ...].

    Format is two lines per selected frame:
        frame:0    pts:30720   pts_time:3
        lavfi.scene_score=0.112500
    A frame line with no following score line is dropped.
    """
    results = []
    pending_ts = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("frame:"):
            pending_ts = None
            for tok in line.split():
                if tok.startswith("pts_time:"):
                    try:
                        pending_ts = float(tok.split(":", 1)[1])
                    except ValueError:
                        pending_ts = None
        elif line.startswith("lavfi.scene_score=") and pending_ts is not None:
            try:
                score = float(line.split("=", 1)[1])
            except ValueError:
                continue
            results.append((pending_ts, score))
            pending_ts = None
    return results


def detect_scenes(video_path, workdir):
    """Pass 1: run ffmpeg scene detection, return [(pts_time, score), ...].

    No images are written. Per-frame metadata is printed to a file inside
    workdir (not /tmp — sandbox-safe) and parsed. Returns [] on any failure.
    """
    os.makedirs(workdir, exist_ok=True)
    meta_path = os.path.join(workdir, "scene_meta.txt")
    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-i", video_path,
        "-vf", "select='gt(scene,0)',metadata=print:file={}".format(meta_path),
        "-f", "null", "-",
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print("WARNING: scene detection failed: {}".format(e), file=sys.stderr)
        return []
    if not os.path.isfile(meta_path):
        return []
    with open(meta_path) as f:
        candidates = parse_scene_metadata(f.read())
    os.remove(meta_path)
    return candidates


def select_evenly(items, k):
    """Return k items evenly spaced across `items`, keeping first and last.

    Deterministic. len(items) <= k returns a copy of items; k <= 0 returns [].
    """
    if k <= 0:
        return []
    if len(items) <= k:
        return list(items)
    if k == 1:
        return [items[0]]
    step = (len(items) - 1) / float(k - 1)
    return [items[int(round(i * step))] for i in range(k)]


def select_scene_frames(candidates, duration, max_frames,
                        threshold=SCENE_THRESHOLD_DEFAULT,
                        anchor_interval=ANCHOR_INTERVAL_SEC):
    """Select frame timestamps from scene candidates unioned with time anchors.

    candidates: [(timestamp, scene_score), ...] from detect_scenes.
    Returns [(timestamp, scene_score_or_None, origin), ...] sorted by timestamp,
    origin in {"scene","anchor"}, capped at max_frames.

    Rules (spec §3):
      - scene frames = candidates with score >= threshold.
      - anchors = one per anchor_interval, skipped when a scene frame lands
        within +/- anchor_interval/2 (static stretches still get coverage).
      - union > max_frames: keep all anchors, fill remaining slots with the
        highest-scoring scene frames (deterministic; ties broken by earliest ts).
      - anchors alone > max_frames (only via manual flags): thin anchors evenly.
      - collapse frames within DEDUPE_WINDOW_SEC, preferring a scene over an anchor.
    """
    scene_frames = [(ts, score) for (ts, score) in candidates if score >= threshold]
    scene_times = [ts for (ts, _) in scene_frames]

    skip_radius = anchor_interval / 2.0
    anchors = []
    t = 0.0
    while t <= duration:
        if not any(abs(t - st) <= skip_radius for st in scene_times):
            anchors.append(t)
        t += anchor_interval

    if len(anchors) > max_frames:
        selected = [(ts, None, "anchor") for ts in select_evenly(anchors, max_frames)]
    else:
        remaining = max_frames - len(anchors)
        top = sorted(scene_frames, key=lambda p: (-p[1], p[0]))[:remaining]
        selected = (
            [(ts, None, "anchor") for ts in anchors]
            + [(ts, score, "scene") for (ts, score) in top]
        )

    selected.sort(key=lambda p: p[0])

    deduped = []
    for item in selected:
        if deduped and abs(item[0] - deduped[-1][0]) < DEDUPE_WINDOW_SEC:
            if item[2] == "scene" and deduped[-1][2] == "anchor":
                deduped[-1] = item  # scene wins a near-collision with an anchor
            continue
        deduped.append(item)
    return deduped


def _extract_single_frame(video_path, timestamp, out_path):
    """Pass 2: extract one frame at `timestamp` (keyframe-seek + decode-forward).

    -ss before -i is a fast seek, frame-accurate enough for scene frames.
    Scales to <=1280px wide. Returns True on success.
    """
    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-ss", str(timestamp),
        "-i", video_path,
        "-frames:v", "1", "-q:v", "2",
        "-vf", "scale='min(1280,iw)':-2",
        out_path,
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        return os.path.isfile(out_path)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def extract_scene_frames(video_path, cache_dir, metadata, max_frames,
                         threshold=SCENE_THRESHOLD_DEFAULT):
    """Two-pass scene extraction: detect -> select -> extract -> manifest.

    Returns a frame_info dict shaped like extract_frames() (extraction_fps and
    interval are None; scene frames are non-uniform). A static video with no
    cut above threshold falls back to the anchor floor from select_scene_frames.
    """
    duration = metadata["duration_sec"]
    frames_dir = os.path.join(cache_dir, "frames")
    os.makedirs(frames_dir, exist_ok=True)

    candidates = detect_scenes(video_path, cache_dir)
    selected = select_scene_frames(candidates, duration, max_frames, threshold=threshold)

    manifest = []
    frame_files = []
    seq = 0
    for (ts, score, origin) in selected:
        candidate_name = "frame_{:03d}.jpg".format(seq + 1)
        if _extract_single_frame(video_path, ts, os.path.join(frames_dir, candidate_name)):
            seq += 1
            frame_files.append(candidate_name)
            manifest.append({
                "file": candidate_name,
                "timestamp_sec": round(ts, 2),
                "scene_score": round(score, 4) if score is not None else None,
                "origin": origin,
            })

    write_frames_manifest(cache_dir, manifest)
    return {
        "frames_dir": frames_dir,
        "num_frames": len(frame_files),
        "extraction_fps": None,
        "frame_files": frame_files,
        "start": 0,
        "interval": None,
        "manifest": manifest,
    }
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_scene_extraction.py -v`
Expected: all PASS. (Selection tests are pure; the integration test runs real ffmpeg on `scene_mp4` and finds the t=3 cut.)

- [ ] **Step 5: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS (scene functions are not yet wired into `main()`; only the new tests exercise them).

```bash
git add scripts/extract.py tests/test_scene_extraction.py
git commit -m "feat(extract): scene-detection two-pass frame extraction"
```

---

### Task 5: Keyframe-only extraction (long videos)

**Files:**
- Modify: `scripts/extract.py` — add `list_keyframe_timestamps()` and `extract_keyframes()` after `extract_scene_frames()`
- Create: `tests/test_keyframe_extraction.py`

**Interfaces:**
- Consumes: `select_evenly()`, `_extract_single_frame()`, `write_frames_manifest()` (Tasks 2, 4).
- Produces:
  - `list_keyframe_timestamps(video_path) -> [float]` — sorted keyframe pts_times via ffprobe `-skip_frame nokey`; `[]` on failure.
  - `extract_keyframes(video_path, cache_dir, metadata, max_frames) -> frame_info` — same dict shape as `extract_scene_frames`; `origin="keyframe"`, `scene_score=None`. **Task 6 consumes this.**

- [ ] **Step 1: Write the failing tests**

Create `tests/test_keyframe_extraction.py`:

```python
"""Tests for keyframe-only extraction (long-video strategy)."""

import importlib.util
import json
import os

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestListKeyframeTimestamps:
    def test_returns_sorted_floats(self, selftest_mp4):
        ts = extract.list_keyframe_timestamps(selftest_mp4)
        assert isinstance(ts, list)
        assert len(ts) >= 1
        assert all(isinstance(t, float) for t in ts)
        assert ts == sorted(ts)

    def test_missing_file_returns_empty(self):
        assert extract.list_keyframe_timestamps("/nonexistent/video.mp4") == []


class TestExtractKeyframes:
    def test_yields_frames_and_manifest(self, selftest_mp4, tmp_path):
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        fi = extract.extract_keyframes(selftest_mp4, cache_dir, metadata, max_frames=60)

        assert fi["num_frames"] >= 1
        assert fi["num_frames"] == len(fi["manifest"])
        assert all(e["origin"] == "keyframe" for e in fi["manifest"])
        assert all(e["scene_score"] is None for e in fi["manifest"])

        with open(os.path.join(cache_dir, "frames.json")) as f:
            assert json.load(f) == fi["manifest"]
        for e in fi["manifest"]:
            assert os.path.isfile(os.path.join(cache_dir, "frames", e["file"]))

    def test_cap_thins_keyframes(self, selftest_mp4, tmp_path, monkeypatch):
        """With a synthetic keyframe list far above the cap, num_frames <= cap
        and the first/last keyframes survive the even thinning."""
        monkeypatch.setattr(
            extract, "list_keyframe_timestamps", lambda _v: [float(i) for i in range(100)]
        )
        cache_dir = str(tmp_path / "c")
        metadata = extract.extract_metadata(selftest_mp4, cache_dir)
        fi = extract.extract_keyframes(selftest_mp4, cache_dir, metadata, max_frames=5)
        assert fi["num_frames"] <= 5
        ts = [e["timestamp_sec"] for e in fi["manifest"]]
        assert ts == sorted(ts)
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -m pytest tests/test_keyframe_extraction.py -v`
Expected: FAIL — `AttributeError` (functions undefined).

- [ ] **Step 3: Implement**

In `scripts/extract.py`, after `extract_scene_frames()`, add:

```python
def list_keyframe_timestamps(video_path):
    """Return sorted keyframe presentation timestamps (seconds) via ffprobe.

    -skip_frame nokey makes the decoder skip non-key frames, so this is cheap
    even for long videos. Returns [] on failure.
    """
    cmd = [
        "ffprobe", "-v", "quiet",
        "-select_streams", "v:0",
        "-skip_frame", "nokey",
        "-show_entries", "frame=pts_time",
        "-of", "csv=p=0",
        video_path,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []
    times = []
    for line in result.stdout.splitlines():
        tok = line.split(",")[0].strip()
        if not tok:
            continue
        try:
            times.append(float(tok))
        except ValueError:
            continue
    return sorted(times)


def extract_keyframes(video_path, cache_dir, metadata, max_frames):
    """Keyframe-only extraction for long videos: list keyframes, thin evenly to
    the cap, extract each. Returns a frame_info dict (origin="keyframe").
    """
    frames_dir = os.path.join(cache_dir, "frames")
    os.makedirs(frames_dir, exist_ok=True)

    timestamps = list_keyframe_timestamps(video_path)
    if len(timestamps) > max_frames:
        timestamps = select_evenly(timestamps, max_frames)

    manifest = []
    frame_files = []
    seq = 0
    for ts in timestamps:
        candidate_name = "frame_{:03d}.jpg".format(seq + 1)
        if _extract_single_frame(video_path, ts, os.path.join(frames_dir, candidate_name)):
            seq += 1
            frame_files.append(candidate_name)
            manifest.append({
                "file": candidate_name,
                "timestamp_sec": round(ts, 2),
                "scene_score": None,
                "origin": "keyframe",
            })

    write_frames_manifest(cache_dir, manifest)
    return {
        "frames_dir": frames_dir,
        "num_frames": len(frame_files),
        "extraction_fps": None,
        "frame_files": frame_files,
        "start": 0,
        "interval": None,
        "manifest": manifest,
    }
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_keyframe_extraction.py -v`
Expected: all PASS.

- [ ] **Step 5: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS.

```bash
git add scripts/extract.py tests/test_keyframe_extraction.py
git commit -m "feat(extract): keyframe-only extraction for long videos"
```

---

### Task 6: Strategy selection, CLI flags, and dispatch

**Files:**
- Modify: `scripts/extract.py` — `select_strategy()` + strategy constants (before `main()`), `build_parser()` (density group ~lines 39–45), `main()` dispatch + metadata (~lines 612–644)
- Create: `tests/test_strategy.py`

**Interfaces:**
- Consumes: `extract_frames()`, `extract_scene_frames()`, `extract_keyframes()` (Tasks 2, 4, 5).
- Produces:
  - `select_strategy(duration_sec, strategy_arg=None, detail=False) -> str` — detail → `"interval"`; explicit `strategy_arg` wins; else auto: `<60s` interval, `60s–1800s` scene, `>1800s` keyframe.
  - CLI: `--strategy {interval,scene,keyframe}` and `--scene-threshold FLOAT` (default 0.08).
  - `metadata`/summary gain `extraction_strategy` (the strategy actually used — replaces the old hardcoded `"interval"`) and, when scene, `scene_threshold`. Additive.
  - Constants `STRATEGY_SCENE_MIN_SEC=60.0`, `STRATEGY_SCENE_MAX_SEC=1800.0`.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_strategy.py`:

```python
"""Tests for extraction-strategy selection and CLI dispatch."""

import importlib.util
import json
import os

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
spec = importlib.util.spec_from_file_location(
    "extract", os.path.join(SCRIPTS_DIR, "extract.py")
)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


class TestSelectStrategy:
    def test_auto_bands(self):
        assert extract.select_strategy(30) == "interval"
        assert extract.select_strategy(300) == "scene"
        assert extract.select_strategy(2000) == "keyframe"

    def test_boundaries(self):
        assert extract.select_strategy(59.9) == "interval"
        assert extract.select_strategy(60.0) == "scene"
        assert extract.select_strategy(1800.0) == "scene"
        assert extract.select_strategy(1800.1) == "keyframe"

    def test_detail_forces_interval(self):
        assert extract.select_strategy(300, detail=True) == "interval"

    def test_explicit_override_wins(self):
        assert extract.select_strategy(5, strategy_arg="scene") == "scene"
        assert extract.select_strategy(5, strategy_arg="keyframe") == "keyframe"


class TestStrategyDispatchCLI:
    def test_auto_interval_for_short_fixture(self, selftest_mp4, run_extract):
        r = run_extract(selftest_mp4, "--overview", "--no-audio")
        assert r["metadata"]["extraction_strategy"] == "interval"
        assert "scene_threshold" not in r["metadata"]

    def test_scene_override_records_strategy_and_threshold(self, scene_mp4, run_extract):
        r = run_extract(scene_mp4, "--overview", "--no-audio", "--strategy", "scene")
        assert r["metadata"]["extraction_strategy"] == "scene"
        assert r["metadata"]["scene_threshold"] == 0.08
        assert r["num_frames"] >= 1
        with open(os.path.join(r["cache_dir"], "frames.json")) as f:
            manifest = json.load(f)
        assert any(e["origin"] == "scene" and abs(e["timestamp_sec"] - 3.0) < 1.5 for e in manifest)

    def test_scene_threshold_flag_recorded(self, scene_mp4, run_extract):
        r = run_extract(
            scene_mp4, "--overview", "--no-audio", "--strategy", "scene",
            "--scene-threshold", "0.05",
        )
        assert r["metadata"]["scene_threshold"] == 0.05

    def test_keyframe_override(self, selftest_mp4, run_extract):
        r = run_extract(selftest_mp4, "--overview", "--no-audio", "--strategy", "keyframe")
        assert r["metadata"]["extraction_strategy"] == "keyframe"
        assert r["num_frames"] >= 1
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -m pytest tests/test_strategy.py -v`
Expected: FAIL — `select_strategy` undefined; `--strategy` is an unknown argument.

- [ ] **Step 3: Add `select_strategy()` and its constants**

In `scripts/extract.py`, directly below the scene constants added in Task 4 (`DEDUPE_WINDOW_SEC`), add:

```python
STRATEGY_SCENE_MIN_SEC = 60.0
STRATEGY_SCENE_MAX_SEC = 1800.0  # 30 minutes
```

Then, directly above `def main():`, add:

```python
def select_strategy(duration_sec, strategy_arg=None, detail=False):
    """Choose the frame-extraction strategy.

    Detail mode is always interval. An explicit --strategy wins. Otherwise auto
    by duration: <60s interval, 60s-30min scene, >30min keyframe.
    """
    if detail:
        return "interval"
    if strategy_arg:
        return strategy_arg
    if duration_sec < STRATEGY_SCENE_MIN_SEC:
        return "interval"
    if duration_sec <= STRATEGY_SCENE_MAX_SEC:
        return "scene"
    return "keyframe"
```

- [ ] **Step 4: Add the CLI flags**

In `build_parser()`, add to `density_group` (after `--max-frames`):

```python
    density_group.add_argument(
        "--strategy",
        choices=["interval", "scene", "keyframe"],
        default=None,
        help="Frame extraction strategy (default: auto by duration)",
    )
    density_group.add_argument(
        "--scene-threshold",
        type=float,
        default=SCENE_THRESHOLD_DEFAULT,
        help="Scene-change score threshold for the scene strategy (default: 0.08)",
    )
```

- [ ] **Step 5: Dispatch by strategy in `main()`**

In `main()`, replace the frame-extraction call:

```python
    # 3. Extract frames
    frame_info = extract_frames(video_path, cache_dir, metadata, args)
```

with:

```python
    # 3. Extract frames using the chosen strategy
    strategy = select_strategy(metadata["duration_sec"], args.strategy, args.detail)
    if strategy == "scene":
        frame_info = extract_scene_frames(
            video_path, cache_dir, metadata, args.max_frames,
            threshold=args.scene_threshold,
        )
    elif strategy == "keyframe":
        frame_info = extract_keyframes(video_path, cache_dir, metadata, args.max_frames)
    else:
        frame_info = extract_frames(video_path, cache_dir, metadata, args)
```

- [ ] **Step 6: Record the real strategy in metadata**

In `main()`, the metadata block currently hardcodes the strategy:

```python
    metadata["extraction_strategy"] = "interval"
    metadata["extraction_fps"] = frame_info["extraction_fps"]
```

Replace those two lines with:

```python
    metadata["extraction_strategy"] = strategy
    if strategy == "scene":
        metadata["scene_threshold"] = args.scene_threshold
    metadata["extraction_fps"] = frame_info["extraction_fps"]
```

(`extraction_strategy` already flows into both summary dicts because they embed `metadata` — no summary change needed.)

- [ ] **Step 7: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_strategy.py -v`
Expected: all PASS. The 5s fixtures auto-select interval; `--strategy scene` on `scene_mp4` finds the t=3 cut; `--strategy keyframe` yields ≥1 frame.

- [ ] **Step 8: Run the full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS. `test_pipeline.py::test_metadata_fields` still sees `extraction_strategy == "interval"` (selftest is 5s → interval).

```bash
git add scripts/extract.py tests/test_strategy.py
git commit -m "feat(extract): auto strategy selection with --strategy/--scene-threshold"
```

---

### Task 7: Docs + version bump to 0.3.0

**Files:**
- Modify: `agents/heimdall.md` — Phase 2 + Phase 3 guidance
- Modify: `README.md` — Usage list + a strategy note
- Modify: `CLAUDE.md` — Coding Conventions (cache layout / strategies)
- Modify: `.claude-plugin/plugin.json` — version

**Interfaces:**
- Consumes: `frames.json` + `metadata.extraction_strategy`/`scene_threshold` from Tasks 2–6.
- Produces: docs describe the strategy bands and the manifest; overview guidance tells the agent scene frames are the interesting ones; version is 0.3.0.

- [ ] **Step 1: Agent overview guidance**

In `agents/heimdall.md`, in Phase 3 (Read + Analyze), after the existing `frame_transcript_map.json` bullet (item 3), add a new bullet:

```markdown
4. Read `frames.json` from the cache directory — each frame carries `timestamp_sec`, `scene_score`, and `origin` (`interval`/`scene`/`anchor`/`keyframe`). **Scene-origin frames are where the picture changed — treat them as the interesting moments; `anchor` frames are periodic context. Prioritize scene frames when choosing what to drill into.**
```

Renumber the subsequent Phase 3 items (the current items 4 and 5 become 5 and 6).

- [ ] **Step 2: README usage + strategy note**

In `README.md`, replace the first item of the "Heimdall will:" list:

```markdown
1. Extract frames at 0.5 fps (overview) or 3 fps (detail)
```

with:

```markdown
1. Extract frames adaptively by duration — interval sampling for short clips
   (< 1 min), scene detection for 1–30 min videos, keyframes for longer ones
   (override with `--strategy interval|scene|keyframe`)
```

Then, immediately after the "Heimdall will:" list and its follow-up paragraph (after the line ending "…higher-density frame extraction."), add:

```markdown
### Extraction strategies

Frame density adapts to video length: short clips are sampled at a fixed
interval; 1–30 minute videos use two-pass scene detection (frames are chosen
where the picture actually changes, with periodic anchors so static stretches
stay covered); videos over 30 minutes fall back to keyframes. Tune scene
sensitivity with `--scene-threshold` (default `0.08`). Every extraction writes
a `frames.json` manifest recording each frame's timestamp, scene score, and
origin.
```

- [ ] **Step 3: CLAUDE.md conventions**

In `CLAUDE.md`, in the Coding Conventions list, after the `Cache` bullet, add:

```markdown
- **Frame manifest** — every extraction writes `frames.json` (`[{file, timestamp_sec, scene_score, origin}]`) in the mode cache dir; it is the single source of frame timestamps for correlation (`correlate_frames_transcript` reads it — no uniform-interval assumption)
- **Extraction strategy** — auto by duration: `<60s` interval, `60s–30min` scene detection (two-pass ffmpeg: detect `lavfi.scene_score`, select above `--scene-threshold` ∪ 45s anchors under `--max-frames`, seek-extract), `>30min` keyframe-only; override with `--strategy`; `--detail` is always interval and requires both `--start` and `--end`
```

- [ ] **Step 4: Version bump**

In `.claude-plugin/plugin.json`, change `"version": "0.2.0"` to `"version": "0.3.0"`.

- [ ] **Step 5: Full suite, then commit**

Run: `python3 -m pytest tests/ -v` — expected: all PASS (docs-only + version).

```bash
git add agents/heimdall.md README.md CLAUDE.md .claude-plugin/plugin.json
git commit -m "docs: document extraction strategies; bump to 0.3.0"
```

---

### Task 8: Parked Package-1 follow-ups (opportunistic)

**Files:**
- Modify: `scripts/install-deps.sh` — whisper-cli probe (2 sites) + `mktemp -d` build dir
- Create: `tests/test_install_deps.py`

**Interfaces:**
- Consumes: nothing.
- Produces: `install-deps.sh` recognizes an existing `whisper-cli` (so Linux does not needlessly rebuild whisper) and builds from a private `mktemp -d` directory instead of a predictable `/tmp/whisper-cpp-build`.

**Scope note:** the third parked security item — pinning the whisper.cpp `git clone` to a release tag — is **deferred, not done here.** Recent whisper.cpp releases switched the build from `make` + `cp main` to CMake with the binary renamed to `whisper-cli`; pinning a tag without also migrating the build steps would break the Linux source build. That migration is a separate change and out of scope for this package. The `mktemp -d` hardening (removing the predictable, symlink-attackable path) is the cheap, self-contained win and is done.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_install_deps.py`:

```python
"""Guards for install-deps.sh parked follow-ups (probe + mktemp hardening)."""

import os
import subprocess

SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "..", "scripts")
INSTALL_DEPS = os.path.join(SCRIPTS_DIR, "install-deps.sh")


def _content():
    with open(INSTALL_DEPS) as f:
        return f.read()


def test_probes_whisper_cli_at_both_sites():
    # macOS and Linux both must accept an existing whisper-cli.
    assert _content().count("command -v whisper-cli") >= 2


def test_uses_mktemp_not_predictable_path():
    content = _content()
    assert "mktemp -d" in content
    assert "/tmp/whisper-cpp-build" not in content


def test_syntax_valid():
    result = subprocess.run(["bash", "-n", INSTALL_DEPS], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -m pytest tests/test_install_deps.py -v`
Expected: the probe and mktemp tests FAIL (current script probes only `whisper-cpp`/`whisper` and uses `/tmp/whisper-cpp-build`); `test_syntax_valid` PASSES.

- [ ] **Step 3: Add the whisper-cli probe at both sites**

In `scripts/install-deps.sh`, both occurrences of:

```bash
    if ! command -v whisper-cpp &>/dev/null && ! command -v whisper &>/dev/null; then
```

become:

```bash
    if ! command -v whisper-cli &>/dev/null && ! command -v whisper-cpp &>/dev/null && ! command -v whisper &>/dev/null; then
```

(one in `install_macos`, one in `install_linux`).

- [ ] **Step 4: Harden the build dir with `mktemp -d`**

In `install_whisper_from_source()`, replace:

```bash
    local build_dir="/tmp/whisper-cpp-build"
    echo "==> Cloning whisper.cpp..."
    rm -rf "$build_dir"
    git clone --depth 1 https://github.com/ggerganov/whisper.cpp.git "$build_dir"
```

with:

```bash
    local build_dir
    build_dir="$(mktemp -d "${TMPDIR:-/tmp}/whisper-cpp-build.XXXXXX")"
    echo "==> Cloning whisper.cpp into ${build_dir}..."
    git clone --depth 1 https://github.com/ggerganov/whisper.cpp.git "$build_dir"
```

(The `rm -rf "$build_dir"` before the clone is dropped — `mktemp -d` creates a fresh empty dir, and `git clone` requires the target to be empty. The existing `rm -rf "$build_dir"` cleanup *after* the build stays.)

- [ ] **Step 5: Run the tests to verify they pass**

Run: `python3 -m pytest tests/test_install_deps.py -v`
Expected: all PASS.

- [ ] **Step 6: Verify script syntax, then commit**

Run: `bash -n scripts/install-deps.sh` — expected: no output, exit 0.

```bash
git add scripts/install-deps.sh tests/test_install_deps.py
git commit -m "fix(install-deps): probe whisper-cli; use mktemp for source build"
```

---

## Self-Review

Checked the plan against spec §3 and the cross-cutting rules (§7):

**Spec coverage:**
- Strategy bands (interval/scene/keyframe by duration) → Task 6 `select_strategy` + Task 4/5 implementations. ✓
- `--strategy` override; detail always interval → Task 6. ✓
- Two-pass scene mechanism (detect → select → extract), threshold 0.08, 45s anchors with ±22.5s skip, cap keeps anchors + top scene, anchors-alone thinned evenly, ~1s dedupe → Task 4. ✓
- Keyframe path + even thinning → Task 5. ✓
- `frames.json` for every strategy; correlation reads it; `frame_transcript_map.json` shape unchanged → Tasks 2, 4, 5. ✓
- Bug: `--detail` requires `--start`+`--end` → Task 1. ✓
- `metadata.extraction_strategy` + `scene_threshold` → Task 6. ✓
- `agents/heimdall.md` overview guidance → Task 7. ✓
- Fixture with a synthetic scene cut → Task 3 (drawbox, freetype-free — deviation from spec's literal "drawbox+drawtext", justified by confirmed absence of freetype). ✓
- Tests enumerated in §3 all map to a task (scene-cut detected; static → anchor floor; cap preserves anchors; manifest timestamps match output; correlation non-uniform; `--detail` without `--end` errors; strategy auto-selection; `--strategy` override). ✓
- §7: one version bump (Task 7); network-free tests; additive JSON. ✓
- Parked follow-ups: dead `hash_dir` line (Task 1), install-deps whisper-cli probe + security hardening (Task 8). ✓

**Placeholder scan:** no TBD/"handle edge cases"/"similar to Task N"; every code step shows complete code; the one intentionally-deferred item (tag-pinning, Task 8) is explained, not hand-waved. ✓

**Type/name consistency:** `write_frames_manifest`, `select_evenly`, `_extract_single_frame`, `select_scene_frames`, `detect_scenes`, `parse_scene_metadata`, `extract_scene_frames`, `list_keyframe_timestamps`, `extract_keyframes`, `select_strategy` are each defined once and consumed with matching signatures. `frame_info["manifest"]` entry keys are identical across interval/scene/keyframe. `origin` values match the constraint set. ✓

**Deviations from the literal spec (both evidence-backed, flagged for reviewer):**
1. Fixture uses `drawbox` only (no `drawtext`) — freetype confirmed absent in this ffmpeg build; the existing basic fixture already avoids freetype by design.
2. Task 8 does the mktemp hardening and whisper-cli probe but defers clone tag-pinning (would require a CMake build migration; out of scope).

## Done Criteria (Package 2)

- `python3 -m pytest tests/ -v` fully green (run **unsandboxed** so the Package-1 `http_server` tests can bind loopback).
- `python3 scripts/extract.py fixtures/selftest_scene.mp4 --overview --strategy scene --no-audio --output-dir /tmp/heimdall-check` → exit 0, output `metadata.extraction_strategy == "scene"`, `scene_threshold == 0.08`, and a `frames.json` in the cache dir with a `scene`-origin frame near `timestamp_sec` 3.0.
- `python3 scripts/extract.py fixtures/selftest.mp4 --detail --start 1 --output-dir /tmp/heimdall-check` → exit 2 (`requires --start and --end`).
- `grep -n "i \* interval" scripts/extract.py` → no match in `correlate_frames_transcript` (uniform-interval assumption gone).
- `.claude-plugin/plugin.json` version is `0.3.0`.
- Verify scene extraction end-to-end on a real screen recording (superpowers:`verify`) and run `security-review` before the PR (new ffmpeg-output parsing is new input surface).

## Execution Handoff

Two execution options:

**1. Subagent-Driven (recommended)** — dispatch a fresh implementer subagent per task, review between tasks (spec + quality), final whole-branch review. **Every subagent spawn must pass `model: "opus"`** (global rule; inheritance would silently use the orchestrator model). REQUIRED SUB-SKILL: superpowers:subagent-driven-development.

**2. Inline Execution** — execute tasks in this session with checkpoints. REQUIRED SUB-SKILL: superpowers:executing-plans.

Work on a feature branch (never `main`); PR to `main` with **no session links / no co-author tags**; run a security-review pass; address Codex's PR comments; the user merges (rebase-merge to keep the small commits linear).
