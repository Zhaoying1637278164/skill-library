# Heimdall — Video Watcher Plugin for Claude Code

**Date:** 2026-04-11
**Status:** Design approved, pending implementation
**Plugin name:** `heimdall`
**Working directory:** `/Users/pranav/work/video-watcher`

---

## 1. Problem

Claude Code cannot see video files. Users with bug report screen recordings have no way to feed them to Claude Code for analysis. Existing solutions are fragmented: some handle frame extraction but no audio, others handle audio but blow up the main context window. None combine subagent isolation, whisper transcription, automated dependency installation, and structured bug-report output in a distributable plugin.

## 2. Goals

- Enable Claude Code to "watch" video files — especially bug report screen recordings
- Produce structured bug reports: steps-to-reproduce, expected vs. actual, error messages, timestamps
- Keep all heavy work (frames, transcripts, analysis) in a subagent's isolated context — the main agent only sees the final report
- Automate dependency installation (ffmpeg, whisper-cpp) via a setup script
- Ship as a distributable Claude Code plugin
- Design the core engine to be harness-agnostic (support Codex, Cursor, OpenClaw in future versions)

## 3. Non-Goals (v1)

- Native video input in Claude Code (that's anthropics/claude-code#12676)
- Cloud-based video APIs (TwelveLabs, Gemini)
- Video creation or editing
- Real-time video streaming
- Duration-adaptive frame extraction strategies (scene detection, keyframe extraction) — see Appendix A
- JSON output schema for programmatic consumers — see Appendix B
- Multi-harness adapters (Codex, Cursor, OpenClaw) — see Section 10

## 4. Architecture

### 4.1 Subagent Pattern

All heavy work runs inside a `heimdall` subagent dispatched via the Task tool. The main agent's context window never sees frames, transcripts, or intermediate analysis.

```
Main agent context                    Subagent context (isolated)
┌──────────────────┐                 ┌──────────────────────────┐
│ User: "/watch    │   Task tool     │ 1. Check deps            │
│  bug.mp4"        │ ──────────────► │ 2. Run extract.py        │
│                  │                 │ 3. Read frames (batched) │
│                  │                 │ 4. Read transcript       │
│                  │                 │ 5. Drill down if needed  │
│ Receives only:   │  ◄──────────── │ 6. Synthesize report     │
│ structured report│   return text   └──────────────────────────┘
└──────────────────┘
```

### 4.2 Two Entry Points

1. **Slash command** (`/heimdall:watch <path>`) — explicit invocation
2. **Auto-trigger skill** (`skills/video-watching/SKILL.md`) — activates when the user mentions a video file path in conversation

Both dispatch to the same subagent via Task tool.

### 4.3 Install Flow

**Primary: paste-to-install (gstack pattern)**

User pastes a prompt into Claude Code:

> Install heimdall: run `git clone --depth 1 https://github.com/pranavtotla/heimdall.git ~/.claude/plugins/heimdall && ~/.claude/plugins/heimdall/setup`


One Bash permission prompt covers `git clone` + `./setup`. Setup installs ffmpeg, whisper-cpp, runs a self-test, and writes a stamp file.

**Secondary: plugin marketplace + `/heimdall:setup`**

For users who install via `claude plugin install heimdall`, they then run `/heimdall:setup` to install deps.

**Safety nets:**

- **SessionStart hook** — fast deps check; injects reminder if stamp file missing
- **Subagent guard** — refuses to proceed if deps missing; directs to `/heimdall:setup`

## 5. Repository Layout

### 5.1 Source Tree

```
video-watcher/                          # publishes as "heimdall"
│
│  ── CORE (harness-agnostic) ──────────────────────────
│
├── scripts/
│   ├── extract.py                      # CLI: video → frames + transcript
│   ├── install-deps.sh                 # OS-aware dep installer
│   └── check-deps.sh                   # fast `which` check for SessionStart
│
├── setup                               # top-level install script (chmod +x)
│                                       # accepts --host claude|auto
│
├── fixtures/
│   └── selftest.mp4                    # tiny (<100KB) test video
│
│  ── CLAUDE CODE ADAPTER ─────────────────────────────
│
├── .claude-plugin/
│   └── plugin.json                     # plugin manifest
│
├── agents/
│   └── heimdall.md                     # subagent: guard → extract → analyze → report
│
├── commands/
│   ├── watch.md                        # /heimdall:watch <path>
│   └── setup.md                        # /heimdall:setup
│
├── skills/
│   └── video-watching/
│       └── SKILL.md                    # auto-trigger on video file mentions
│
├── hooks/
│   └── hooks.json                      # SessionStart → check-deps.sh
│
│  ── REPO FILES ──────────────────────────────────────
│
├── .gitignore
├── LICENSE                             # MIT
└── README.md
```

### 5.2 Runtime Cache (not in repo)

```
~/.cache/heimdall/
├── deps.ok                             # stamp: deps installed
└── extractions/
    └── <sha256-first-12>/              # content hash of video file
        ├── metadata.json               # ffprobe output
        ├── transcript.json             # whisper output (full video, shared)
        ├── full/                       # overview extraction
        │   ├── frames/*.jpg
        │   └── frame_transcript_map.json
        └── range_<start>_<end>/        # drill-down extraction(s)
            ├── frames/*.jpg
            └── frame_transcript_map.json
```

### 5.3 Generic / Adapter Split

`scripts/extract.py` is the product — a standalone CLI tool any AI harness can call via Bash. Everything in `.claude-plugin/`, `agents/`, `commands/`, `skills/`, and `hooks/` is the Claude Code adapter. Future harness adapters (Codex, Cursor, OpenClaw) would add their own adapter directories while reusing the same `scripts/` core.

## 6. Core Engine: `scripts/extract.py`

### 6.1 CLI Interface

```
usage: extract.py [-h] [--output-dir DIR] [--max-frames N]
                  [--no-audio] [--fps FPS]
                  [--start SECS] [--end SECS]
                  [--overview] [--detail]
                  VIDEO_PATH

positional:
  VIDEO_PATH              path to video file

time range:
  --start SECS            start time in seconds (default: 0)
  --end SECS              end time in seconds (default: full duration)

density:
  --fps FPS               frames per second (default: 0.5 for overview, 3 for detail)
  --max-frames N          hard cap (default: 60)

modes:
  --overview              low-density pass for the full video (default)
  --detail                high-density pass for a time range
  --no-audio              skip whisper transcription

output:
  --output-dir DIR        override default cache directory
```

### 6.2 Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | ffmpeg or whisper-cpp missing |
| 2 | Video file not found or unreadable |
| 3 | Extraction failed |

### 6.3 Pipeline

```
VIDEO_PATH
    │
    ▼
1. HASH — sha256 of file content (first 12 chars)
   Cache hit? → return cached summary, exit 0
    │ (cache miss)
    ▼
2. PROBE — ffprobe → duration, resolution, fps, codec, has_audio
   Write metadata.json
    │
    ▼
3. FRAMES — extract at configured fps, capped at max-frames
   v1: interval-based extraction for all durations
   Write frames/frame_001.jpg, frame_002.jpg, ...
    │
    ├── audio track exists AND whisper available?
    │     │
    │  YES: 4a. TRANSCRIBE
    │     ffmpeg → 16kHz mono WAV
    │     whisper-cpp → segments with timestamps
    │     Write transcript.json (full video, once)
    │     │
    │     5. CORRELATE
    │     For each frame timestamp, find overlapping transcript segment
    │     Write frame_transcript_map.json
    │
    │  NO: 4b. Skip transcription
    │     transcript.json = null
    │     frame_transcript_map.json = null
    │
    ▼
6. OUTPUT — JSON summary to stdout, exit 0
```

### 6.4 Iterative Extraction

The subagent can call `extract.py` multiple times with different parameters:

- **First call:** `extract.py bug.mp4 --overview` → overview of full video
- **Second call:** `extract.py bug.mp4 --start 38 --end 48 --detail` → high-density drill-down
- **Third call:** `extract.py bug.mp4 --start 73 --end 78 --detail` → another region

Transcript is extracted once (full video) and shared. Range extractions only re-extract frames and rebuild the correlation map.

### 6.5 Output File Formats

**metadata.json:**
```json
{
  "duration_sec": 45.2,
  "resolution": "1920x1080",
  "fps": 30,
  "codec": "h264",
  "has_audio": true,
  "file_size_bytes": 12345678,
  "extraction_strategy": "interval",
  "extraction_fps": 0.5,
  "num_frames": 24,
  "whisper_model": "base",
  "has_transcript": true
}
```

**transcript.json:**
```json
{
  "segments": [
    {"start": 0.0, "end": 2.5, "text": "So watch this, when I click save"},
    {"start": 2.5, "end": 5.1, "text": "it should save but instead it throws this error"}
  ],
  "language": "en",
  "full_text": "So watch this, when I click save it should save but..."
}
```

**frame_transcript_map.json:**
```json
[
  {
    "frame": "frame_001.jpg",
    "timestamp_sec": 0.0,
    "transcript_segment": {"start": 0.0, "end": 2.5, "text": "So watch this, when I click save"}
  },
  {
    "frame": "frame_012.jpg",
    "timestamp_sec": 22.0,
    "transcript_segment": null
  }
]
```

## 7. Subagent: `agents/heimdall.md`

### 7.1 Workflow

**Phase 1 — Guard:** Check deps stamp file and `which ffmpeg`. If missing, return "run /heimdall:setup" and stop.

**Phase 2 — Overview extraction:** Run `scripts/extract.py <video> --overview`. Parse stdout JSON for cache directory and frame count.

**Phase 3 — Read + Analyze (batched):** Read metadata.json, transcript.json, and frame_transcript_map.json. Read frames in batches (guideline: ~8-10 per batch, adjust based on frame complexity and context budget). After each batch, accumulate observations — don't re-read earlier frames.

**Phase 4 — Drill down (conditional):** If interesting moments identified (error dialogs, state transitions, UI glitches), run `extract.py` with `--start`/`--end`/`--detail` for regions of interest (typically 1-3, use judgment based on video length and number of distinct issues). Read the high-density frames.

**Phase 5 — Synthesize + Return:** Produce structured bug report (Section 8) and return it as the subagent's final message.

### 7.2 Adaptive Behavior

| Signal | Adaptation |
|--------|------------|
| No audio / no transcript | Lean on visual analysis; note "no narration available" |
| Narration describes a bug | Weight transcript for steps-to-reproduce |
| Error text visible in frames | Extract error messages verbatim |
| Video is a tutorial/demo | Switch to general summary format |
| Video > 10 min | Aggressive batching; drill down only on most significant moments |
| Silent UI recording | Focus on state transitions, click targets, visual diffs between frames |

## 8. Output Schema

### 8.1 Bug Report Format (default)

```markdown
## Video Analysis: [auto-generated title]

**Source:** [filename] | **Duration:** [X sec] | **Resolution:** [WxH]

### Summary
[2-3 sentence overview: what the user does, what goes wrong, apparent root cause]

### Steps to Reproduce
1. [0:00] [initial state description]
2. [0:12] [user action]
3. [0:14] [system response]
4. [0:18] [failure point]

### Expected vs. Actual
- **Expected:** [what should have happened]
- **Actual:** [what actually happened]

### Error Messages
- [0:18] "Failed to save: 403 Forbidden" (error dialog)
- [0:22] "TypeError: Cannot read property 'id' of undefined" (console)

### Key Frames
- [0:00] Initial state — [description]
- [0:12] Trigger — [the action that causes the bug]
- [0:18] Failure — [the visible error state]

### Narration Highlights
> [0:10] "So watch, when I click save here..."
> [0:19] "...there's the error, it just started doing this today"

### Observations
- [Patterns, suggestions for where to look in code, correlations]
```

### 8.2 General Video Format

When the subagent determines the video is not a bug report (tutorial, demo, presentation):

```markdown
## Video Analysis: [title]

**Source:** [filename] | **Duration:** [X sec] | **Resolution:** [WxH]

### Summary
[2-3 sentence overview]

### Timeline
- [0:00–0:15] [segment description]
- [0:15–0:45] [segment description]

### Key Moments
- [0:22] [notable moment]

### Transcript Summary
[condensed narration, if any]
```

### 8.3 Format Detection

The subagent decides bug-report vs. general format based on:
- Visible error messages in frames
- Narration containing "bug", "broken", "error", "not working"
- User's original prompt context ("this is a bug report")
- Presence of UI state transitions that suggest a failure flow

## 9. Hooks + Setup

### 9.1 SessionStart Hook (`hooks/hooks.json`)

```json
{
  "SessionStart": [
    {
      "hooks": [
        {
          "type": "command",
          "command": "bash ${CLAUDE_PLUGIN_ROOT}/scripts/check-deps.sh",
          "timeout": 5
        }
      ]
    }
  ]
}
```

### 9.2 `scripts/check-deps.sh`

1. If `~/.cache/heimdall/deps.ok` exists → exit silently
2. Check `which ffmpeg` and `which whisper-cpp`
3. Both present → write stamp file, exit silently
4. Either missing → output: "heimdall: dependencies not installed. Run /heimdall:setup to install."

### 9.3 `setup` Script

```
#!/usr/bin/env bash
set -e

Flags: --host claude|auto, --check (verify only), --uninstall

1. Parse flags
2. Detect OS (macOS / Linux / WSL)
3. Call scripts/install-deps.sh
   macOS: brew install ffmpeg whisper-cpp
   Linux: apt-get install ffmpeg + build whisper.cpp from source
   Other: print manual instructions, exit 1
4. Verify: ffmpeg -version, whisper-cpp --help
5. Self-test: scripts/extract.py fixtures/selftest.mp4 --overview
6. Write ~/.cache/heimdall/deps.ok
7. Print success + available commands
```

### 9.4 `commands/setup.md`

Slash command that runs `bash ${CLAUDE_PLUGIN_ROOT}/setup` via Bash tool. For users who installed via plugin marketplace and need to install deps after.

## 10. Multi-Harness Support

### 10.1 Design Principle

`scripts/extract.py` is harness-agnostic — a standalone CLI tool with argparse, JSON output, clean exit codes. Any AI coding tool that can call Bash and read files can use it.

Everything in `.claude-plugin/`, `agents/`, `commands/`, `skills/`, and `hooks/` is the Claude Code adapter. Future harness adapters would add their own directories while reusing `scripts/`.

### 10.2 v1 Scope

- `setup` accepts `--host claude|auto`
- Only Claude Code adapter is built
- Other `--host` values print "not yet supported" and exit cleanly

### 10.3 Future Adapters

| Harness | Adapter location | Registration |
|---------|-----------------|--------------|
| Codex CLI | `adapters/codex/` | Codex skill format |
| Cursor | `adapters/cursor/` | `.cursor/rules/` format |
| OpenClaw | `adapters/openclaw/` | ClawHub skill format |
| Kiro | `adapters/kiro/` | Kiro format |

Adding a new adapter is mechanical: write a markdown file in the target harness's format that calls `scripts/extract.py` via Bash. The core engine doesn't change.

## 11. Prior Art

| Tool | Subagent isolation | Whisper | Bug-report output | Dep install | Plugin distributable |
|------|-------------------|---------|-------------------|-------------|---------------------|
| fabriqaai/ffmpeg-analyse-video-skill | Yes | No | No | No | No |
| msadig Video Input skill | No | Yes | No | No | No |
| TwelveLabs plugin | N/A (cloud) | Cloud | No | No | Yes |
| **heimdall** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** |

heimdall combines the best ideas from fabriqaai (batched sub-agent frame analysis) and msadig (frame-to-transcript correlation) while adding structured bug-report output, automated dep installation, and plugin marketplace distribution.

## Appendix A — Future: Adaptive Frame Extraction

**Not in v1.** v1 uses interval-based extraction for all video durations.

Future versions should adopt fabriqaai's duration-adaptive strategy:

| Duration | Strategy | Rationale |
|----------|----------|-----------|
| 0–60s | Interval (1 frame/2s) | Short enough that uniform sampling works |
| 1–10min | Scene detection (`ffmpeg -vf "select='gt(scene,0.3)'"`) | Emits frames only when visual content changes significantly — ideal for bug report screencasts with long static stretches punctuated by abrupt UI changes |
| 10–30min | Keyframe extraction (I-frames only) | Leverages codec's own scene-change boundaries |
| 30min+ | Thumbnail filter, capped at 60 | Prevents context blowup on very long videos |

Scene detection is particularly valuable for bug reports where nothing happens for 10 seconds, then a dialog pops up — interval-based extraction wastes frames on static parts while potentially missing the critical transition.

## Appendix B — Future: JSON Output Schema

**Not in v1.** v1 returns markdown from the subagent.

Future versions could add a JSON schema for programmatic consumers:

```json
{
  "type": "bug_report | general",
  "title": "string",
  "source": { "filename": "string", "duration_sec": 0, "resolution": "string" },
  "summary": "string",
  "steps_to_reproduce": [
    { "timestamp_sec": 0, "description": "string" }
  ],
  "expected": "string",
  "actual": "string",
  "error_messages": [
    { "timestamp_sec": 0, "text": "string", "source": "dialog | console | toast" }
  ],
  "key_frames": [
    { "timestamp_sec": 0, "label": "string", "description": "string" }
  ],
  "narration_highlights": [
    { "timestamp_sec": 0, "text": "string" }
  ],
  "observations": ["string"]
}
```

This enables downstream tooling: auto-filing GitHub issues, feeding into bug trackers, aggregating across multiple videos, etc.
