# Heimdall Roadmap v0.2–v0.6 — Design

**Date:** 2026-07-10
**Status:** Approved design, pending implementation plan
**Extends:** `2026-04-11-heimdall-design.md` (v0.1 design; Appendices A/B and §10 graduate here)
**Research basis:** 4-track research workflow (2026-07-10) — findings inlined below with sources where load-bearing.

---

## 1. Overview

Five sequential work packages, one version bump each, dependency-ordered:

| Pkg | Version | Title | Depends on |
|-----|---------|-------|------------|
| 1 | v0.2.0 | Whisper model management | — |
| 2 | v0.3.0 | Scene-detection frame extraction | — |
| 3 | v0.4.0 | JSON report + `/heimdall:file` | 1, 2 (metadata fields) |
| 4 | v0.5.0 | URL ingestion (Loom et al.) | — (3 for `source_url` in reports) |
| 5 | v0.6.0 | Codex adapter | 1–4 (stable core) |

Product decisions (made 2026-07-10):
- Default whisper model: **base.en** (small.en documented opt-in).
- URL sources first-class: **Loom, direct video URLs, Dropbox, Google Drive**. YouTube best-effort (works via yt-dlp, untested/unadvertised).
- Transcripts: **always whisper** — no per-source caption branching. Loom native captions noted as future optimization.
- Auth-gated URLs: **fail with a clear message by default**; `--cookies`/`--cookies-from-browser` passthrough exists but agents/skills must obtain explicit user approval before using it — never automatic.

## 2. Package 1 — Whisper model management (v0.2.0)

### Problem

- `setup:141` downloads the model with bare `curl -L -o` — no `--fail`, so an HTTP error body is saved *as the model file*, and every later run reports "already downloaded". No checksum, no resume, no retries.
- `extract.py:_find_whisper_model()` silently falls back to Homebrew's `for-tests-ggml-tiny.bin` test model.
- `extract.py:534` hardcodes `whisper_model: "base"` regardless of the model actually used.

### Design

**Model manifest** — new `scripts/models.json`, pinned:

```json
{
  "base.en":  {"file": "ggml-base.en.bin",  "size": 147964211,
               "sha256": "a03779c86df3323075f5e796cb2ce5029f00ec8869eee3fdfb897afe36c6d002",
               "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin"},
  "small.en": {"file": "ggml-small.en.bin", "size": 487614201,
               "sha256": "c6138d6d58ecc8322097e0f987c32f1be8bb0a18532a3f88f734d1bbf9c41e5d",
               "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en.bin"}
}
```

(SHA-256 values are HuggingFace git-LFS oids, verified 2026-07-10 via `raw/main` pointer files.)

**setup** — `--model NAME` flag (default `base.en`). Download flow: `curl -L --fail --retry 5 --retry-delay 5 --retry-all-errors --retry-connrefused -C - -o "$tmp"` → `shasum -a 256` / `sha256sum` verify against manifest → atomic `mv` to `~/.cache/heimdall/models/<file>`. On checksum mismatch: delete temp, exit 1 with message. Manifest parsed via `python3 -c` (python3 is already a hard requirement).

**extract.py**
- New `--model VALUE`: if VALUE contains a path separator or names an existing file → literal path; else canonical name (strip optional `ggml-` prefix and/or `.bin` suffix) → `<models_dir>/ggml-<name>.bin` — so `base.en`, `ggml-base.en.bin`, and `/abs/path.bin` all resolve.
- Resolution precedence: `--model` > `$HEIMDALL_WHISPER_MODEL` > models-dir search (prefer `base.en`, else lexicographically first `ggml-*.bin`) > **skip transcription**. The Homebrew test-model candidate is removed entirely.
- No model found → transcription skipped, stderr warning with remedy (`run setup or pass --model`), summary/metadata gain `transcript_status: "skipped_no_model"`. Transcription stays non-fatal (frames are the primary signal).
- Metadata/summary record truth: `whisper_model` = label derived from the resolved filename (e.g. `"base.en"`), `whisper_model_source` ∈ `{"flag","env","cache","none"}`. Replaces the hardcoded `"base"`.

**agents/heimdall.md** — report header line gains `**Transcript:** <model>` or `**Transcript:** none (no whisper model)`.

### Tests

Model-name resolution (name/`ggml-` name/path/missing), precedence order, no-model → `skipped_no_model` + exit 0, checksum-mismatch handling in setup (corrupt temp file → failure, no file installed), metadata records resolved model. Existing transcript tests updated to stub the model rather than rely on the brew test model.

## 3. Package 2 — Scene-detection extraction (v0.3.0)

### Problem

Interval sampling wastes frames on static stretches and can miss the moment a dialog appears — the exact signal bug recordings exist to capture. Two latent bugs ride along: `correlate_frames_transcript()` assumes `timestamp = start + i × interval` (breaks for non-uniform frames), and `--detail --start N` without `--end` silently writes 3fps frames into the `full/` overview cache.

### Design

**Strategy selection** (auto by duration; `--strategy interval|scene|keyframe` overrides; detail mode always interval):

| Duration | Strategy |
|----------|----------|
| < 60s | interval (unchanged) |
| 60s – 30min | scene detection (two-pass) |
| > 30min | keyframe-only + even thinning |

Research amendments to the v0.1 Appendix A table: the thumbnail filter is dropped (it decodes every frame — slowest exactly for the longest videos); scene detection is the primary band through 30min; coverage floors are mandatory in the scene band.

**Scene path — two-pass:**
1. *Detect* (no images written): `ffmpeg -i <in> -vf "select='gt(scene,0)',metadata=print:file=<tmp>" -f null -` → parse per-frame `pts_time` and `lavfi.scene_score` from the metadata file.
2. *Select* in Python: candidates = frames with `score ≥ threshold` (default **0.08**, flag `--scene-threshold`; screencast changes move few pixels, cinematic guidance of 0.3 is far too high) **∪ anchors** (one per 45s, skipped when a scene frame already lands within ±22.5s; ~1s dedupe window). If candidates exceed `max-frames`: keep all anchors, fill remaining slots with top-scoring scene frames (deterministic; no threshold sweeping). If anchors alone exceed the cap (only possible via manual flags), thin anchors evenly.
3. *Extract*: one `ffmpeg -ss <ts> -i <in> -frames:v 1 -q:v 2 -vf "scale='min(1280,iw)':-2" <frame>` per selected timestamp. `-ss` before `-i` is keyframe-seek + decode-forward — frame-accurate for this purpose. Known caveat (research open question): VFR screen recordings may seek ±1 frame; acceptable, and `--strategy interval` remains the escape hatch.

**Keyframe path** (>30min): `ffmpeg -skip_frame nokey -i <in> -vf "showinfo,scale='min(1280,iw)':-2" -vsync vfr` writing frames directly; real timestamps parsed from showinfo's `pts_time` on stderr; if count > cap, thin evenly (keyframes carry no scene score).

**frames.json manifest** — written for *every* strategy (interval included), in the mode cache dir:

```json
[{"file": "frame_001.jpg", "timestamp_sec": 12.34, "scene_score": 0.42, "origin": "scene"}]
```

`origin` ∈ `{"interval","scene","anchor","keyframe"}`. `correlate_frames_transcript()` reads timestamps from the manifest — the uniform-interval assumption is deleted. `frame_transcript_map.json` keeps its shape (consumers unchanged).

**Bug fixes**
- `--detail` now requires *both* `--start` and `--end`; anything else → `EXIT_BAD_INPUT` (fixes the `full/` cache clobber).
- `metadata.extraction_strategy` records the strategy actually used; `scene_threshold` recorded when relevant.

**agents/heimdall.md** — overview guidance updated: scene-origin frames are the interesting ones; anchors are context.

### Tests

New fixture variant in `generate-fixture.sh`: static color background with a `drawbox`+`drawtext` "dialog" appearing at a known timestamp (synthetic scene cut). Tests: scene band detects the cut frame; static video still yields anchor floor; cap respected with anchors preserved; manifest timestamps match showinfo/metadata output; correlation uses manifest (non-uniform case); `--detail` without `--end` errors; strategy auto-selection per duration; `--strategy` override.

## 4. Package 3 — JSON report + `/heimdall:file` (v0.4.0)

### Design

**Subagent output contract** — `agents/heimdall.md` gains the `Write` tool. Phase 5 writes two artifacts into the *hash-level* cache dir before returning:
- `report.json` — Appendix B schema plus: `schema_version: 1`, `video_hash`, `source_url` (null for local files), `whisper_model`, `extraction_strategy`.
- `report.md` — exactly the markdown returned as the final message.

One synthesis pass, two artifacts; the JSON is the machine interface, the markdown the human one.

**`/heimdall:file <video-or-url> [--repo owner/name] [--label ...]`** — new command + skill entry points, same dispatch pattern as `watch`:
1. If `report.json` is missing for the video's hash → dispatch the heimdall agent first (re-filing an already-analyzed video reuses the cached report).
2. Build a contact-sheet montage of the report's key frames: new `scripts/montage.sh <out> <frame>...` using ffmpeg tile/stack filters (≤6 frames, 3×2).
3. `gh issue create --title <report title> --body-file <report.md + footer>` (body is far below GitHub's 65,536-char cap). Footer notes it was filed by heimdall and names the montage path.
4. Print the created issue URL and the montage path with a one-line "drag this into the issue for inline visuals" note.

**Explicitly rejected:** programmatic image attachment. GitHub has no official API for issue image uploads (gh issues #12960/#13256 are blocked on the platform); the only inline path for private repos uses an undocumented endpoint plus an unscoped browser session cookie. Heimdall will not touch session cookies. An opt-in public-repo evidence-branch mode is deferred, not designed here.

### Tests

`report.json` schema validation (required keys, types) against a fixture report; montage script (frame count variants, missing frame error); `/file` flow with a stubbed `gh` binary on PATH (records argv; asserts title/body/labels); body footer content.

## 5. Package 4 — URL ingestion (v0.5.0)

### Design

`extract.py` accepts `^https?://` where it accepts a path today; everything downstream of "we have a local file" is unchanged.

**Routing** (`resolve_source()`):

| URL | Route |
|-----|-------|
| path ends `.mp4/.mov/.webm/.mkv/.avi/.m4v` | stdlib `urllib` streaming download |
| `dropbox.com` | rewrite `?dl=1`, then urllib |
| `loom.com/share|embed/<32hex>`, Google Drive | `yt-dlp` subprocess |
| `youtube.com`/`youtu.be` | `yt-dlp` (best-effort: undocumented, untested) |
| anything else | `EXIT_BAD_INPUT` with "unsupported URL" + supported list |

**yt-dlp flow** — probe first: `yt-dlp --skip-download --no-warnings --print "%(id)s|%(extractor)s|%(duration)s" <url>`. On failure, classify by stderr substring (yt-dlp collapses nearly all failures to exit code 1, so exit codes are useless):

| stderr contains | Report | Exit |
|-----------------|--------|------|
| `Video unavailable`/`removed`/`does not exist`/`404` | video no longer exists | 2 |
| `Private video`/`Sign in`/`login required`/`requires authentication` | needs login — download manually, or re-run with `--cookies*` if you approve | 2 |
| `password` (Loom `VideoPasswordMissingOrIncorrect`) | pass `--video-password` | 2 |
| `not available in your country` | geo-restricted | 2 |
| `403` | share link/token expired — re-open the page | 2 |
| other | extraction failed + "outdated yt-dlp? run `yt-dlp -U`" hint | 3 |

Then download: `yt-dlp -f "bv*+ba/b" --merge-output-format mp4 --no-playlist -o <cache>/downloads/<urlkey>/video.%(ext)s <url>` (Loom serves split audio/video HLS; ffmpeg muxes — already installed).

**urllib flow** — UA header, stream to `.part`, reject `Content-Type: text/html` and bodies starting `<!DOCTYPE`/`<html`, `os.replace` on completion.

**Validation + cache integration** — every downloaded file is ffprobe-validated (has a video stream) *before* acceptance; catches login pages masquerading as video regardless of route. Then: sha256 → `os.replace` into `extractions/<hash-12>/source.mp4` (same filesystem, atomic, no copy) → normal pipeline. URL and identical local file dedupe to one extraction dir.

**URL index** — `~/.cache/heimdall/urls/<sha256(normalized-url)[:12]>.json` = `{url, content_hash, extractor_id, resolved_at}`. Normalization: lowercase scheme+host, drop fragment, drop `utm_*`/`si` params. Index hit + extraction dir exists → no re-download (ToS/rate-limit friendly).

**Flags** — `--video-password` (Loom), `--cookies FILE`, `--cookies-from-browser NAME` — all passthrough to yt-dlp. Consent rule (product decision): the agent/skill never adds cookie flags on its own; the failure message offers them, the user must explicitly approve. Stated in `agents/heimdall.md` and the skills.

**Dependency** — yt-dlp is *lazily required*: local files and urllib-route URLs never need it; the yt-dlp route errors with install instructions if absent. `install-deps.sh` adds it (brew on macOS; standalone binary from GitHub releases → `~/.local/bin` on Linux — self-contained, supports `yt-dlp -U`; apt is stale). Binary discovery: `shutil.which("yt-dlp")` then `~/.local/bin/yt-dlp`. `check-deps.sh` lists it as optional.

**Surface updates** — `skills/video-watching` + watch command/skill trigger on `loom.com/share/…` and video URLs; `metadata.json` gains `source_url`, `source_id`.

### Tests

All network-free: routing table (URL → route/unsupported); Dropbox rewrite; normalization/urlkey stability; stub `yt-dlp` binary on PATH (probe output, download simulation, each stderr classification row); urllib route against a local `http.server` fixture (video bytes, HTML rejection, `.part` cleanup); ffprobe-validation rejection of a non-video download; index round-trip (second call skips download); content-hash dedupe with a pre-existing extraction dir.

## 6. Package 5 — Codex adapter (v0.6.0)

### Design

Research verdicts: **Codex viable** — its agent cannot read images mid-session, but `codex exec --image f1,f2,… "prompt"` attaches frames headlessly, and each nested exec doubles as an isolation boundary (frame bytes stay out of the parent context — the same property our subagent provides). **Cursor deferred** — its agent cannot autonomously read on-disk images (open feature requests #53415/#67338/#135007; headless docs claim otherwise but the evidence says no). **OpenClaw out** (chat gateway, not a coding harness). **Kiro** future candidate pending vision verification.

Layout:

```
adapters/
├── README.md                      # adapter matrix + Cursor/Kiro deferral rationale
└── codex/
    └── heimdall/
        ├── SKILL.md               # Codex skill (same authoring format as Claude skills)
        └── scripts/
            └── batch-analyze.sh   # loops frame batches through `codex exec --image`
```

`SKILL.md` workflow: run `extract.py` (unchanged, harness-agnostic core holds) → read `frames.json` + transcript → `batch-analyze.sh` shells out `codex exec --image <≤6 frames> "<analysis prompt with per-frame timestamps>"` per batch, accumulating text observations → final `codex exec` synthesizes the report from observations + transcript (no images). Batch size 6, conservative until Codex's multi-image attention is verified (research open question).

`setup --host codex`: verify `codex` binary, link `adapters/codex/heimdall` → `~/.agents/skills/heimdall`, print usage. `--host auto` continues to mean Claude; Codex is explicit opt-in.

### Tests

`batch-analyze.sh` with a stubbed `codex` binary (records `--image` args; asserts batching ≤6, timestamp injection, observation concatenation); setup `--host codex` linking; stub-missing-codex error path.

## 7. Cross-cutting

- **Sequencing:** packages land in order, each as one PR-sized unit of small atomic commits; version bump + CHANGELOG-style README note per package.
- **Testing bar:** every behavior change lands with pytest coverage, including error paths and boundary cases; all tests network-free via stub binaries (`tests/bin/` shims prepended to PATH) and local HTTP fixtures.
- **Docs per package:** README usage, CLAUDE.md conventions (cache layout changes in Pkg 2/4), agent/skill markdown kept in sync with engine flags.
- **Compatibility:** `extract.py` stdout summary stays additive (new keys only); `frame_transcript_map.json` shape unchanged; exit-code contract (0/1/2/3) unchanged.

## 8. Non-goals (this roadmap)

- Cursor/Kiro/OpenClaw adapters (deferred with documented rationale).
- Programmatic image attachment to GitHub issues; evidence-branch mode.
- Loom native caption ingestion (future optimization; whisper stays the single transcript path).
- Cookie handling beyond explicit passthrough flags (no cookie storage, no browser automation).
- Cache eviction/GC.
- OCR, video comparison, real-time streaming (unchanged from v0.1 non-goals).

## 9. Open questions accepted as implementation-time tuning

- Empirical scene threshold on real bug-report corpus (default 0.08; flag exists — sweep 0.05/0.08/0.1 when fixtures exist).
- Anchor spacing 45s (vs 30/60s) and ±1s dedupe window.
- Codex multi-image batch size (start 6).
- Whether frame `pts_time` and whisper segment clocks stay aligned on VFR recordings (correlation map risk; mitigated by manifest timestamps coming from the same ffmpeg clock that cut the audio).
