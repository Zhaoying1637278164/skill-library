# Operation map

Use this index only to route an operation to the right workflow skill. The
live MCP description and input schema are authoritative. Product operations
require the separate on-demand Product MCP; all other operations use the
bundled MyChatBot connection.

## MyChatBot Plugin Basics

Load `mychatbot-plugin-basics` for:

`get_docs_structure`, `search_docs`, `read_docs_page`.

## Account Audit

Load `account-audit` for:

`get_account_summary`, `get_subscription_info`, `get_token_usage`, `get_usage_summary`, `get_account_authoring_inventory`.

## Build Sales Assistant

Load `build-sales-assistant` for:

`list_assistants`, `get_assistant`, `assistant_list_skills`, `assistant_get_config_link`, `get_assistant_available_tools`, `assistant_create`.
`assistant_clone`, `assistant_create_skill`, `assistant_toggle_contact_details`, `assistant_toggle_client_context`, `assistant_toggle_strip_kb_history`, `assistant_update`.
`assistant_update_instructions`, `assistant_update_skill`, `assistant_delete_skill`, `assistant_update_client_context_schema`, `delete_assistant`, `enable_order_taking`.
`disable_order_taking`.

## Business Knowledge

Load `business-knowledge` for:

`list_faq_knowledge_base_entries`, `list_products`, `list_integrations`, `get_integration`, `create_faq_knowledge_base`, `add_website_knowledge`.
`create_product_feed_integration`, `create_products_integration`, `update_faq_knowledge_base_entries`, `delete_faq_knowledge_base`, `update_products`, `delete_products_integration`.
`delete_product_feed_integration`, `learn_website`, `create_knowledge_source`, `update_knowledge_source`, `delete_knowledge_source`, `semantic_product_search`.
`filter_category_products`, `get_all_categories`, `get_product_details`, `get_product_variants`, `find_similar_products`, `get_category_attributes`.
`get_category_attribute_values`, `get_available_filters`, `get_products_by_ids`.

## Channels And Integrations

Load `channels-and-integrations` for:

`list_channels`, `channel_get_config_link`, `get_integration_config_link`, `create_calls_channel_sdk`, `connect_telegram`, `create_website_widget`.
`channel_toggle`, `delete_channel`, `update_integration_trigger`, `start_connector_authorization`, `connect_sales_platform_connector`, `probe_connector`.
`disconnect_connector`.

## Crm And Sales Operations

Load `crm-and-sales-operations` for:

`list_labels`, `list_pipelines`, `get_pipeline`, `get_order_stats`, `get_event_stats`, `list_calendar_staff`.
`list_calendar_services`, `list_clients`, `scan_clients`, `get_client`, `client_list_notes`, `client_get_note`.
`client_list_tasks`, `client_list_attachments`, `client_get_attachment`, `export_clients`, `list_chats`, `get_chat`.
`get_chat_messages`, `export_chats`, `list_orders`, `get_order`, `list_events`, `get_event`.
`label_create`, `pipeline_create`, `pipeline_update`, `funnel_status_create`, `client_create`, `client_update`.
`client_context_merge`, `client_create_note`, `client_update_note`, `client_create_task`, `client_update_task`, `client_create_attachment`.
`client_update_attachment`, `client_delete`, `client_delete_note`, `client_delete_task`, `client_delete_attachment`, `label_delete`.
`pipeline_delete`, `funnel_status_delete`, `delete_test_orders`.

## Outreach And Followups

Load `outreach-and-followups` for:

`list_follow_ups`, `get_follow_up`, `immediate_outreach_preview_audience`, `follow_up_create`, `follow_up_update`, `follow_up_delete`.
`immediate_outreach_create`, `immediate_outreach_update_status`, `outbound_call`, `send_one_off_message`, `schedule_message`.

## Routines And Automations

Load `routines-and-automations` for:

`list_lead_forms`, `get_lead_forms_automation`, `set_lead_form_mapping`, `remove_lead_form_mapping`, `get_routine_authoring_context`, `list_routines`.
`get_routine`, `validate_routine`, `get_routine_readiness`, `get_routine_run`, `create_routine`, `start_routine_dry_run`.
`create_routine_schedule`, `create_trigger`, `set_routine_schedule_enabled`, `set_trigger_enabled`, `cancel_routine_run`, `update_routine`.
`delete_routine_schedule`, `delete_trigger`, `get_routine_session_history`.

## Build Agent System

Load `build-agent-system` for:

`get_agent`, `get_skill`, `claim_custom_agent`, `hire_library_agent`, `create_skill`, `replace_agent_configuration`.
`reset_agent_configuration`, `delete_custom_agent`, `replace_skill`, `delete_skill`.

## Test And Evaluate

Load `test-and-evaluate` for:

`eval_scenario_list`, `eval_scenario_get`, `eval_run_get`, `test_chat_send`, `test_chat_get_history`, `eval_run_start`.
`test_chat_start`, `test_chat_end`, `eval_scenario_save`, `eval_scenario_delete`, `eval_run_cancel`.

## Content And Publishing

Load `content-and-publishing` for:

`list_models`, `get_media_task`, `list_accounts`, `get_post`, `get_post_analytics`, `get_best_times_to_post`.
`get_daily_metrics`, `get_content_decay`, `get_posting_frequency`, `get_post_timeline`, `list_ad_accounts`, `list_campaigns`.
`get_campaign_tree`, `list_ads`, `generate_media`, `tts`, `create_post`.
