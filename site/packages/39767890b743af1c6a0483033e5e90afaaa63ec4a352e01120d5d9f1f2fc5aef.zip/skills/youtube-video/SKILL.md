---
name: youtube-video
description: Use when the user wants to schedule a YouTube video, Short, or set YouTube-specific metadata. Triggers on "youtube", "schedule a YT video", "post a Short", "youtube playlist", "made for kids", "youtube visibility".
---

# YouTube — Required Title and Visibility Controls

## When to Use

- User wants to schedule a YouTube video or Short
- User mentions YouTube-specific metadata (visibility, playlist, made-for-kids)

This skill writes the right `youtubeOptions` block. Hand scheduling back to `social-post`.

## The hard requirement: title

**YouTube REQUIRES a title for video posts.** The server enforces this with a 422 if you don't send `youtubeOptions.title`. The title is separate from the caption (which becomes the video description).

- Title: 1–100 chars, public-facing, search-keyword-friendly
- Caption (top-level `content`): becomes the description, can be longer

If the user gives you only a single caption to use, ask: "What should the video title be? (separate from the description — this is what shows above the video and in search.)"

## Flow

### Step 1: Verify the user has a YouTube account connected

Call `aa_list_accounts`. If no YT account, tell the user they need to connect one in the AA Social dashboard first.

### Step 2: Get title + caption + visibility

Required:
- `title` — 1–100 chars
- caption (top-level `content`) — becomes the description

Recommended-ask:
- visibility — public (default), private (only the channel sees it), unlisted (anyone with the link)
- playlistId — if they have a series, ask which playlist to add to

### Step 3: Made-for-kids and synthetic media

YouTube requires authors declare these:
- `madeForKids: true` — content is directed at kids (COPPA). Most book promo isn't this; default `false`.
- `containsSyntheticMedia: true` — if the video has AI-generated humans, voices, or events that didn't happen. Required by YouTube's 2024 policy. Default `false` unless the video was AI-generated or has voice clones.

If the video came from the campaign skill (any AI image/video provider), set `containsSyntheticMedia: true` to stay on the right side of YouTube's policy.

### Step 4: Build the post

```js
aa_create_post({
  content: "<long-form video description / caption>",
  accountIds: ["<youtube-account-id>"],
  scheduledAt: "<ISO timestamp>",
  mediaItems: [{ type: "video", url: "<video URL>" }],
  youtubeOptions: {
    title: "<1–100 char title>",
    visibility: "public",
    madeForKids: false,
    containsSyntheticMedia: true,  // if AI-generated
    firstComment: "<optional pinned first comment>",
    playlistId: "<optional>"
  }
})
```

### Step 5: Hand off to social-post for scheduling

## YouTube Shorts vs regular videos

YouTube auto-detects Shorts based on:
- Vertical aspect ratio (9:16)
- Duration ≤ 60 seconds
- Title or description includes `#Shorts`

You don't need to explicitly flag a Short — just upload a 9:16 video under 60s and add `#Shorts` to the title. YouTube routes it to the Shorts feed.

## Common mistakes to avoid

- Forgetting the title. The user gives you a caption; you ask for a title; don't proceed without one.
- Setting `madeForKids: true` for adult-fiction promo. The COPPA flag changes monetization and disables comments. Almost never what an indie author wants.
- Forgetting `containsSyntheticMedia: true` when the video was AI-generated. YouTube can demonetize or strike posts that don't disclose.
- Pasting the same string into title and caption. Title = short and search-friendly. Caption = long-form description with links and hashtags.
