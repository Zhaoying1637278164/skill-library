# Magpie setup

Follow this when the plugin is first installed or a tool returns an auth error.

**Free tier: nothing to set up.** `magpie_audit` runs anonymously — confirm the MCP connection works by running a free audit on any URL the user cares about.

**Pro tools** (`magpie_rank_track`, `magpie_keyword_gap`) need an API key:

1. Pro isn't open self-serve yet — the user joins the waitlist at https://magpied.au/waitlist and Jezweb issues a key. Never promise a checkout link or quote a price; there isn't a live one.
2. Set the key as the `MAGPIE_API_KEY` environment variable (e.g. `export MAGPIE_API_KEY=...` in their shell profile), then restart Claude so the MCP connection picks it up. The plugin sends it as the Bearer token automatically — no config file edits.
3. Verify: the Pro tools stop returning the upgrade payload and return real data.

With no key set, Magpie stays on the free tier and the audit keeps working. The `/magpie:connect` command walks the user through this same flow interactively.
