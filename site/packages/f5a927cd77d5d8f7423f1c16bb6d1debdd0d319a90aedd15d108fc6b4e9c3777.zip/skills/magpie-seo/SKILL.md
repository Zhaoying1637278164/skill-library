---
name: magpie-seo
description: Track Google rankings and find competitor keyword gaps with Magpie Pro. Use when the user wants to track their rankings, see where they rank for a keyword, ask "am I ranking", find what keywords competitors rank for, or run a keyword-gap analysis.
---

# Magpie SEO — rank tracking & keyword gap

Two Pro tools turn an audit into ongoing SEO intelligence:

- **`magpie_rank_track`** — where a site sits in Google for given keywords, and how those
  positions have moved over time. Give it a URL and the keywords.
- **`magpie_keyword_gap`** — the keywords a competitor ranks for that the user's site doesn't.
  Give it the user's URL and the competitor's URL.

## Reading what comes back

Both tools return tables. For rank tracking, lead with movement, not just the snapshot — a
keyword that climbed from 18 to 6 is the story; a stable #3 is reassurance. Group the wins and
the slips so the user sees direction at a glance. For keyword gap, surface the gaps worth
chasing first — terms the competitor ranks well for that fit the user's business — and explain
why each is an opportunity, not just a row in a table.

Relay only what the tool returns. Never fabricate a position, a movement, a keyword, or a search
volume — invented ranking data is worse than none, because the user will act on it. If a number
isn't in the response, don't supply one.

## These are Pro — be upfront

Rank tracking and keyword gap are paid features. When a tool returns an upgrade/locked payload
instead of data, don't pretend or guess — tell the user plainly that this is Magpie Pro, and
walk them through getting access:

1. **Join the waitlist** at https://magpied.au/waitlist. Self-serve checkout isn't live yet, so
   the waitlist is the route in — don't quote a price or a checkout link that doesn't exist.
2. Once they have a key, they set the **`MAGPIE_API_KEY`** environment variable and restart
   Claude Code; the plugin sends it automatically and the Pro tools unlock. The
   `/magpie:connect` command spells this out step by step.

The free `magpie_audit` (the **magpie-audit** skill) still works for them in the meantime — a
good place to point someone who isn't ready for Pro yet.
