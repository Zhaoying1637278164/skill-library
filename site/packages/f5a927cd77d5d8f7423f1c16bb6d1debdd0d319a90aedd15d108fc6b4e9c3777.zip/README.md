# Magpie plugin

Website intelligence for Claude, over a hosted MCP server.

## Tools

| Tool | Tier | What it does |
|------|------|--------------|
| `magpie_audit` | Free | Single-page audit: overall score, Core Web Vitals, on-page SEO, security headers, robots/sitemap, WordPress-aware findings. No key needed. |
| `magpie_rank_track` | Pro | Google positions for your keywords, plus movement over time. |
| `magpie_keyword_gap` | Pro | Keywords a competitor ranks for that your site doesn't. |

## Commands

- `/magpie:audit <url>` — run a free audit.
- `/magpie:rank <url> <keyword…>` — track rankings (Pro).
- `/magpie:gap <url> <competitorUrl>` — competitor keyword gap (Pro).
- `/magpie:connect` — how to get a Pro key and set `MAGPIE_API_KEY`.

## Skills

- **magpie-audit** — site-health consulting on the free audit; walks the highest-severity
  issues first in plain language.
- **magpie-seo** — interpreting rank tracking and keyword-gap tables, plus the Pro upgrade flow.

## Connecting

The free audit runs anonymously — nothing to configure. The Pro tools need an API key: join the
waitlist at https://magpied.au/waitlist, then set the `MAGPIE_API_KEY` environment variable. The
MCP connection sends it as the Bearer token automatically.

Hosted MCP server: `https://mcp.magpied.au/mcp`
