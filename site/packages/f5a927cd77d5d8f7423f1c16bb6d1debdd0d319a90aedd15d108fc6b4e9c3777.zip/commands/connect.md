---
description: How to unlock Magpie Pro — get a key and set MAGPIE_API_KEY.
---

Explain how to connect Magpie Pro.

The free `magpie_audit` tool works with no key at all — nothing to set up. The Pro tools
(`magpie_rank_track` and `magpie_keyword_gap`) need an API key.

Walk the user through it:

1. **Get a key.** Pro isn't open self-serve checkout yet — join the waitlist at
   https://magpied.au/waitlist. Jezweb issues you a key when your spot comes up. (Don't promise
   a checkout link or a price — there isn't a live one to quote.)
2. **Set the key.** Once they have a key, they set the `MAGPIE_API_KEY` environment variable in
   their shell (for example `export MAGPIE_API_KEY=...` in their shell profile), then restart
   Claude Code so the MCP connection picks it up. The plugin already sends it as the Bearer
   token — no config file edits needed.
3. **Verify.** After restarting, the Pro tools stop returning the upgrade payload and start
   returning real data.

With no key set, Magpie runs anonymously on the free tier — the audit still works.
