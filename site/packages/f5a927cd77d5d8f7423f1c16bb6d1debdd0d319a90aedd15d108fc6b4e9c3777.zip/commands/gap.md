---
description: Find keywords a competitor ranks for that your site doesn't (Magpie Pro).
argument-hint: <url> <competitorUrl>
---

Run a competitor keyword-gap analysis for: $ARGUMENTS

The first argument is your site URL; the second is the competitor's URL. Call the
`magpie_keyword_gap` tool with both (add `https://` where the scheme is missing). Relay the
keyword-gap table the tool returns — the keywords the competitor ranks for that your site
doesn't — and only what it returns, never invented keywords or volumes.

This is a **Magpie Pro** tool. If the tool responds with an upgrade/locked payload instead of
gap data, explain that keyword-gap analysis is a paid feature, point the user to the waitlist
at https://magpied.au/waitlist, and tell them that once they have a key they set the
`MAGPIE_API_KEY` environment variable to unlock it (`/magpie:connect` walks through this).

If both URLs weren't given, ask for the site and the competitor to compare.
