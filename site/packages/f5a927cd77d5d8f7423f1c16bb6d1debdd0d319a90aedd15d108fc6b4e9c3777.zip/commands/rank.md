---
description: Track Google search positions for a site and keywords over time (Magpie Pro).
argument-hint: <url> <keyword> [keyword…]
---

Track search rankings for the site and keywords in: $ARGUMENTS

The first argument is the site URL; the rest are the keywords to track. Call the
`magpie_rank_track` tool with the URL and the list of keywords (add `https://` if the scheme
is missing). Relay the positions-and-movement table the tool returns — only what it returns,
never invented rankings.

This is a **Magpie Pro** tool. If the tool responds with an upgrade/locked payload instead of
ranking data, don't guess at positions — explain that rank tracking is a paid feature, point
the user to the waitlist at https://magpied.au/waitlist, and tell them that once they have a
key they set the `MAGPIE_API_KEY` environment variable to unlock it (`/magpie:connect` walks
through this).

If no URL or keywords were given, ask which site and which keywords to track.
