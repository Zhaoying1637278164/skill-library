---
description: Run a free Magpie website audit (score, Core Web Vitals, SEO, security, WordPress) for a URL.
argument-hint: <url>
---

Run a Magpie audit for the website at: $ARGUMENTS

Call the `magpie_audit` tool with that URL (add `https://` if the user omitted the scheme).
The tool returns a complete Markdown report — relay it to the user as-is, then offer to walk
through the highest-severity issues (the critical and warning items first) and explain how to fix them.

If no URL was given, ask the user which website they'd like audited.
