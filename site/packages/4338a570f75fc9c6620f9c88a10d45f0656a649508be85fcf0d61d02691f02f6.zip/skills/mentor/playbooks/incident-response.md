# incident-response
*Last verified: 2026-07-12*

**Hidden gem:** Deep Research — two minutes checking whether it's a known upstream outage can save an hour of debugging code that was never the problem.

**Exemplar move:** Connect to Grafana and Datadog MCP servers. payment-service returns 503s on ~12% of requests — pull error timeline, latest deploy, top service:payment-service log errors; correlate spike with deploy timestamp.

| # | Approach | Best when | Why it fits |
|---|----------|-----------|-------------|
| 1 | [MCP Context](../approaches/techniques/mcp-context.md) | Error spike correlating with a recent deploy | Incidents are data problems — MCP makes Claude a unified query layer across your observability stack, collapsing data-gathering |
| 2 | [Deep Research](../approaches/techniques/deep-research.md) | Outage symptoms match something you've seen in a dependency | Many incidents originate outside your codebase; checking known issues first saves hours debugging code that wasn't the problem |
| 3 | [Plan Mode](../approaches/techniques/plan-mode.md) | Service down and you don't know where to start | In incidents a wrong action costs more than a delayed one — structured triage prevents fixing the wrong component |
| 4 | [Channels](../approaches/techniques/channels.md) | Alerts should land in the session with context already loaded | Triage speed is dominated by context assembly; channels deliver the event where that assembly already happened |
