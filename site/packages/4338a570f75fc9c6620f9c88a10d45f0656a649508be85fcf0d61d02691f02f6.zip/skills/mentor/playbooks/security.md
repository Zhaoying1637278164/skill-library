# security
*Last verified: 2026-07-12*

**Hidden gem:** Hooks — a PreToolUse guard on auth configs and crypto files prevents the accidental security regressions that no scanner catches.

**Exemplar move:** Run /security-review on the current branch — special attention to auth middleware in src/middleware/auth.ts and raw database queries in src/services/; security audit next week.

| # | Approach | Best when | Why it fits |
|---|----------|-----------|-------------|
| 1 | [Built-In Review Skills](../approaches/techniques/built-in-review-skills.md) | A branch's pending changes need a security pass before merge | Vulnerabilities follow well-known patterns — encoded checks applied exhaustively to every changed line beat manual review. Diff-based: `/security-review` scans pending changes, so it has nothing to say about code that is already committed — and it deliberately excludes outdated third-party dependencies, so known-CVE detection needs a scanner |
| 2 | [Subagent Delegation](../approaches/techniques/subagent-delegation.md) | Auditing existing code — no diff, the subject is the codebase | Security auditing is multi-dimensional — one concern per agent (injection, authz, secrets) gives deeper analysis without attention dilution; for a small surface the same audit is one grounded prompt naming the files and vulnerability classes |
| 3 | [Deep Research](../approaches/techniques/deep-research.md) | New CVE announced for a dependency in your stack | Hardening without context is guesswork — affected versions and exploitation prerequisites let you patch what matters |
| 4 | [Hooks](../approaches/techniques/hooks-as-workflow.md) | Protect security-critical files from accidental modification | Most security regressions are accidental — a speed bump forces conscious acknowledgment before touching critical code |
| 5 | [security-guidance](../approaches/tools/security-guidance.md) | Security review should happen on every edit, automatically | A hook that reviews as code is written catches issues at the cheapest moment — before they exist in a diff |
| 6 | [claude-code-security-review](../approaches/tools/claude-code-security-review.md) | Every PR should get a security pass without anyone invoking it | The official Action runs the same diff-scoped analysis as `/security-review` in CI and posts inline findings with fix recommendations — the review happens even when nobody remembers to ask |
