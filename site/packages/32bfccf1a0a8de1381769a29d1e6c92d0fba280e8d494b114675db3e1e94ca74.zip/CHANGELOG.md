# Changelog

All notable changes to Worker K will be documented in this file.

## [1.0.0] - 2026-04-10

### Added
- Initial release with 8 office automation skills
- Excel processing: read, create, edit, analyze, reconcile, chart, pivot, convert
- Word processing: read, create, edit, mail merge, convert to PDF
- PDF processing: extract text/tables, merge, split, watermark, fill forms, generate reports
- Research & analysis: structured research across accounting, tax, audit, regulatory domains
- Web browsing: browse, screenshot, scrape tables, fill forms, download, monitor
- Bank reconciliation: automated matching with professional Excel output
- Claim form extraction: PDF/Excel claim form parsing with structured summaries
- Management representation letter: template-based letter generation
