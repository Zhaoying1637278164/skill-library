---
name: socialpostflow
description: Use this skill when the user wants to publish, schedule, or manage social media posts across multiple networks (Facebook, X, LinkedIn, Instagram, Threads, Pinterest, TikTok, Mastodon, Bluesky, Telegram, Google Business Profiles). Triggers on requests like "schedule a tweet", "post this to all my socials", "share to LinkedIn and Facebook", "queue up a post for tomorrow", or any reference to scheduling/publishing content across networks. This plugin ships an OAuth-authenticated MCP server, so no API token setup is required — the user approves access in a browser on first use.
---

# Social Post Flow

Schedule and publish social media posts across 12+ networks via the Social Post Flow MCP server.

## Setup

Nothing to configure. This plugin registers an HTTP MCP server at `https://app.socialpostflow.com/mcp`. On first use, Claude Code will open a browser for the user to sign in with their Social Post Flow account and approve access. Tokens are stored by Claude Code and refreshed automatically.

If the tools ever return an auth error, ask the user to reconnect via `/plugin` → Social Post Flow → Reconnect, or check their subscription at `https://app.socialpostflow.com/billing`.

## Available MCP tools

| Tool                | Purpose                                                             |
| ------------------- | ------------------------------------------------------------------- |
| `get_user`          | The authenticated user's profile, subscription state, stats.        |
| `list_profiles`     | Connected social profiles (id, provider, name, connection state).   |
| `list_posts`        | Posts belonging to the user. Filterable by profile and status.      |
| `get_post`          | Full detail for a single post by ID.                                |
| `create_post`       | Create one post (may target multiple profiles at once via `profile_ids`). |
| `create_bulk_posts` | Create up to 50 posts in one call. Best-effort per item — inspect `errors`. |
| `update_post`       | Edit a scheduled post. Only works before `status` becomes `posted`. |
| `delete_post`       | Delete a post. Stops publishing if still scheduled.                 |

Always call `list_profiles` before creating posts if you don't already know the profile IDs.

## Mental model

A **profile** is one connected social account (their Facebook page, their X account, etc.). Each profile has a unique numeric `id`.

A **post** belongs to exactly one profile. Publishing the same content to three networks creates three separate post records — this happens automatically when you pass multiple `profile_ids` to `create_post`.

Posts have a **status** lifecycle: `scheduled` → `posted` (or `failed`).

## Creating posts — the rules

### Required fields

- `text` — the post body. Required for every `post_type` except `story` (Stories are image-only).
- `profile_ids` — array of one or more profile IDs. Each ID gets its own post record.
- `schedule_type` — one of `immediate`, `queue_end`, `queue_start`, `scheduled`.
- `scheduled_at` — required only when `schedule_type` is `scheduled`. ISO 8601, must be in the future. Use UTC.

### Post types

| `post_type` | Requires                                | Forbids                          |
| ----------- | --------------------------------------- | -------------------------------- |
| `text`      | `text`                                  | `url`                            |
| `link`      | `text`, `url`                           | `media_urls`                     |
| `image`     | `text`, `media_urls`                    | `url`                            |
| `story`     | `media_urls` (text optional)            | `url`, `first_comment`           |
| `pin`       | `text`, `media_urls`. Optional `url`.   | nothing — pins accept both.      |
| `tiktok`    | `text`, `media_urls` (video URL)        | `url`, `first_comment`           |
| `google`    | `text`. Optional `media_urls` and `url`. | `first_comment`                 |

If you violate these rules, the API returns a 422 with a clear message. Don't try to be clever, just pass through what the user asked for.

### Media URLs

`media_urls` is an array of public HTTP(S) URLs. Social Post Flow downloads each image server-side, crops it to the right aspect ratio per network, and stores it. **You don't need to upload anything** — pass URLs the API can fetch (web search results, the user's S3, a content CMS).

Per-network image caps: Facebook 10, X 4, LinkedIn 20, TikTok 35, Instagram feed 10 (Stories 1), Threads 20, Pinterest 1, Telegram 10, Google 1.

### Scheduling

- `immediate` (default) — publish as soon as possible (usually 1–2 min).
- `queue_end` — append to the profile's queue. Use for "queue this up", "schedule these throughout the week".
- `queue_start` — insert at the front of the queue, bumping everything else later.
- `scheduled` — publish at a specific `scheduled_at`. Must be in the future.

The queue model is key — each profile has its own queue interval (set per user). When the user says "post these throughout the week", use `queue_end`, don't compute timestamps yourself. Timezone comes from `get_user`.

## Bulk creation

For 2+ posts in one turn, prefer `create_bulk_posts`. It takes a `posts` array (max 50) where each item is a full post payload. Response shape:

```json
{
    "data":   [ /* SocialPostResource for each successful creation */ ],
    "errors": [ { "index": 3, "message": "..." } ]
}
```

**Best-effort**: a `200` response does NOT mean every item succeeded. Always inspect `errors`. Each entry references its original zero-based index in the input array. Items validate upfront as a batch — if any item fails validation, the whole request returns 422 with `posts.N.field` error keys and nothing is created.

Use `create_bulk_posts` when queueing a week of posts, importing a campaign, or scheduling a launch sequence. Use plain `create_post` for single-post interactions.

## Common workflows

### "Post this to all my socials"

1. `list_profiles` — gather IDs of profiles that accept the intended `post_type` (many networks only accept certain types).
2. `create_post` with `profile_ids` being the full list, `post_type: "text"` (or whatever matches), `schedule_type: "immediate"`.

### "Schedule a week of posts"

1. `list_profiles` to get IDs.
2. `create_bulk_posts` with one item per intended post, all using `schedule_type: "queue_end"`. Don't compute dates — the queue does that.

### "Show me what's failing"

`list_posts` with `status: "failed"`. Common causes: disconnected profiles (user must reconnect at `https://app.socialpostflow.com/profiles`), platform rate limits, or media validation issues.

### "What's posted today?"

`list_posts` with `status: "posted"`, `order_by: "posted_at"`, `order: "desc"`. Filter client-side by date if needed.

### "Edit / cancel that scheduled post"

`update_post` if the user wants to change content or timing (only works while `status: "scheduled"`).
`delete_post` to cancel it entirely. Deleting a `posted` post removes SPF's record but does NOT unpublish from the network — call that out to the user.

## Important behaviour

- **Server-side validation is authoritative.** Don't pre-validate; submit and surface any 422 message verbatim to the user.
- **One `create_post` call can create multiple posts.** Passing three `profile_ids` creates three post records. The response is always a collection.
- **Look up profiles before posting.** Don't ask "which X account?" — call `list_profiles` and let the user pick from the returned names.
- **Daily per-profile limits exist.** The API enforces a cap; hitting it returns a 429. Surface the message; don't retry.
- **Scheduled posts must be in the future.** Convert relative times (e.g. "tomorrow at 9am") to ISO 8601 UTC carefully. The user's timezone is in `get_user`.

## What this skill doesn't do

- **Doesn't upload media.** `media_urls` takes public URLs, not local files. If the user has a local image, they need to host it first.
- **Doesn't do analytics.** Post-level metrics aren't in the public API yet.
- **Doesn't connect new social accounts.** That's OAuth in a browser — direct the user to `https://app.socialpostflow.com/profiles`.
- **Doesn't manage users or teams.** One SPF account per MCP connection.

## More resources

- API reference: https://www.socialpostflow.com/documentation/api/
- MCP documentation: https://www.socialpostflow.com/documentation/mcp/
- Product: https://www.socialpostflow.com
- Source: https://github.com/socialpostflow/socialpostflow-cli
