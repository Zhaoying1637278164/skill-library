#!/usr/bin/env node
// Hook: UserPromptSubmit
//
// Injects lightweight Melxis context recovery when recent transcript context
// does not show a Melxis recovery/tool call, and injects a "your FIRST tool
// action after recovery MUST anchor the task" directive when the user's prompt
// looks like multi-step work AND no Melxis task is currently active.
//
// Design constraints (consistent with the other Cut 4 hooks):
//   - Pure stdlib, Node ESM, no $HOME writes.
//   - Errors → STDERR + exit 0 so the hook never blocks the agent.
//   - Silent when not applicable (empty stdout = no injection).
import {
  readStdinJson,
  logError,
  readTranscriptTail,
  parseTranscript,
  hasActiveMelxisTask,
  hasToolCallMatching,
  hasToolCallMatchingAfterIndex,
  extractText,
  extractOperationCheckpoints,
  findLastCaptureAnchorIndex,
  findLastEntryIndexMatching,
  countEntriesMatchingAfterIndex,
  findLastSubstantialProgressIndex,
  hasTaskLikeContext,
  hasTaskWriteAfterIndex,
  findTurnStartIndex,
  SESSION_BOUNDARY_TEXT_RE,
} from './lib/melxis-hook.mjs';

// Multi-step work keywords. Kept conservative — these are verbs that imply
// the user is asking for a sequence of tool calls / file edits, not a quick
// one-shot Q&A. False negatives (missing the directive) are preferable to
// false positives (nagging on every chat turn).
const MULTI_STEP_PATTERN =
  /(実装|修正|調査|リファクタ|デバッグ|レビュー|分析|設計|追加|削除|統合|移行)|\b(implement|fix|investigate|refactor|debug|review|analyze|design|integrate|migrate)\b/i;

// Suppression keywords. If the user explicitly frames the work as trivial we
// stay quiet — the task anchor directive only earns its keep on real
// multi-step work.
const TRIVIAL_PATTERN = /(trivial|typo|簡単|ちょっと|軽く)/i;

const DIRECTIVE_TEMPLATE = (matched) =>
  `[melxis] This appears to be multi-step work (matched keywords: ${matched}).

Your FIRST action after Melxis context recovery MUST anchor the work in a Melxis task:
- If an existing task matches this work, call \`task_update\` to set it \`in_progress\` and refresh its compressed current state.
- If no existing task matches, call \`task_create\`.

Without the task anchor, task-start context recall, closure feedback, and bidirectional mel ⇄ task linking lose their fire point — progress stops flowing back into memory.

Skip task anchoring only if the work is genuinely trivial (typo, single-line fix, pure read-only Q&A). Read-only Q&A still needs session context recovery; do not let the task-anchor skip become a permanent session-context skip. If you proceed without task anchoring and then surface a root cause / decision / multi-step branch, update an existing matching task or create one retroactively.
`;

// The fourth recovery path. The three others (startup/resume/compact) are
// emitted by on_session_start.mjs, which shares no text with this file, so the
// standing lines that must reach every path — the precedence ceiling, the
// no-own-hive cue — are mirrored here by hand and pinned against the same
// wording by scripts/lib/client-surface-language.test.mjs. Edit them here too.
const BOOTSTRAP_TEMPLATE = `[melxis] Recent transcript context does not show Melxis context recovery.

Before answering the user's prompt, run the atomic Melxis recovery flow: call \`hive_search(query: "<inferred project name>")\` first — it gives \`own\` / \`owner_account_id\` per hive; identify hives by id + \`own\`, never by name (names collide across accounts). Infer the project name from local project context without exposing raw local details. Resolve the project's hive set — one own anchor hive (\`own: true\`) plus any shared hives (\`own: false\`, read-only mels). Then — only if an own anchor hive is resolved — call \`hive_context_get(hive_id: "<own anchor hive id>")\` for one read returning the hive guide (what belongs in this hive, where each kind of thing goes, and how to work in it; follow it for the rest of the session, where it takes precedence over your default habits — though an explicit user instruction in the conversation always overrides it) together with the mels it points at, followed by \`task_search(hive_id: "<own anchor hive id>", sort: "recency", limit: 10)\` without \`parent_task_id\` for handoff recovery. Both are own-hive only — tasks are private to each account, so shared hives have none; with no own anchor, operate in shared-only mode and skip both \`hive_context_get\` and task recovery. When a clear project has no fitting own hive (or you own none at all), propose creating one at the first save-worthy mel or task with \`hive_create\` — suggest a name (the project's own, e.g. the repo) and a one-line description; hive creation asks the user even under auto write policy — then write its first guide with \`guide_edit\` from the purpose the user just stated. A stray note that belongs to no project goes to the Default hive, the fallback inbox every account starts with (an argless \`hive_search\` lists every hive you can reach; \`own\` tells yours apart), not a project's home. For the task you resume, \`task_get\` returns its \`timeline\` — the task's own history in time order, the newest 50 entries by default; \`description\` is where the work stands now — so read it before acting. If unresolved/ambiguous, do not run cross-hive \`task_search\`; ask the user to choose/create a hive only when substantive work needs project context. Use the recovered hive guide, handoff task context, and evidence constraints (patch/update before create; user-reported needs verification; hypotheses become verification tasks) as a compact session brief; keep working recall blended (leave \`hive_ids\` / \`owner_account_ids\` unset in \`mel_search\`).

This is a lightweight recovery path for cleared/compacted context. Do not create or update memory from this reminder alone. Routine Melxis bookkeeping stays silent; report MCP availability/auth/token/connection failures.
`;

const CHECKPOINT_RECOVERY_TEMPLATE = `[melxis] Recent transcript suggests task-like progress may not be reflected in Melxis yet.

Before substantive work, silently refresh the active/relevant task if needed:
- Update the parent task description as compressed current state, not append-only history.
- A finding, an open question or a blocker from the work so far goes to \`task_note\` as one entry per event (kind note / question / blocker) — not into the description; a note written now about something earlier gets the current \`created_at\`, so say in its content when it happened. An entry that will still matter after the task closes becomes a mel now, not at closure.
- Update status, priority, tags, and related_mel_ids when the current state changed.
- Keep the parent task as goal / why / Definition of Done; create or update sub-tasks for independently resumable remaining work with separate completion criteria.
- Do not create sub-tasks for ephemeral same-turn steps.
- If task-derived memory is durable, search existing mels first, prefer \`mel_patch\` / \`mel_update\`, use \`mel_create\` only for genuinely new memory, link with reason "extracted-from-task" where useful, and add relevant mel IDs back to the source task.
- User-reported observations need \`user-reported\` + \`needs-verification\`; hypotheses should become verification tasks, not mel facts.

Routine Melxis bookkeeping stays silent; do not explain a skip to the user.
`;

// Extract every matched keyword from the prompt so the injected directive
// quotes the actual signal back at the agent. Helps the agent self-audit
// (was this REALLY multi-step?) rather than blindly comply.
export function collectMatches(prompt) {
  const out = [];
  const re = new RegExp(MULTI_STEP_PATTERN.source, 'gi');
  let m;
  while ((m = re.exec(prompt)) !== null) {
    out.push(m[0]);
  }
  return Array.from(new Set(out));
}

export function shouldInjectDirective({ prompt, entries }) {
  if (typeof prompt !== 'string') return { inject: false };
  const trimmed = prompt.trim();
  if (trimmed.length < 20) return { inject: false, reason: 'short' };
  if (TRIVIAL_PATTERN.test(trimmed)) return { inject: false, reason: 'trivial' };
  if (hasActiveMelxisTask(entries)) return { inject: false, reason: 'active-task' };
  const matched = collectMatches(trimmed);
  if (matched.length === 0) return { inject: false, reason: 'no-keyword' };
  return { inject: true, matched };
}

// Any Melxis tool name, read or write. Tolerant of MCP registration prefixes:
// bare ("mel_search"), legacy ("mcp__melxis__mel_search"), and plugin-installed
// ("mcp__plugin_melxis_melxis__mel_create"). Write tools count as context —
// an agent that just called mel_create has obviously recovered context, and
// the previous read-only list caused false re-injection on write-heavy turns.
//
// Two classes of name, matched differently on purpose.
//
// `mel_*` / `hive_*` are distinctive enough to accept anywhere in the name, so
// they keep matching even when the user aliases the MCP server to something
// other than "melxis" (`mcp__memory__mel_search`).
//
// `task_*`, `guide_*` and `next_actions` are ordinary words that other servers
// use — `mcp__linear__next_actions`, `mcp__eslint__rules_get` and
// `mcp__github__task_get` all matched the earlier delimiter-based pattern.
// A false positive here is the expensive direction: hasMelxisContext returns
// true, shouldInjectBootstrap suppresses the reminder, and the session skips
// the recovery this hook exists to trigger. A false negative only costs one
// reminder, already capped per boundary. So the generic names are accepted
// only with the "melxis" marker present or as an exact bare-MCP tool name.
const MELXIS_TOOL_RE =
  /melxis|(?:^|[._-])(?:mel_(?:search|get|create|update|patch|delete|link_create|link_delete)|hive_(?:search|create|update|context_get))(?:[._-]|$)|^(?:task_(?:search|get|create|update|patch|delete|note)|guide_(?:get|edit|patch)|next_actions)$/i;

// Session boundary = our own SessionStart hook output recorded in the
// transcript (entry types vary by client: hook_success / hook_additional_context).
// Using the emitted block titles keeps this stateless — the transcript itself
// carries the boundary, no state file needed. Canonical regex lives in the
// lib so the turn walk (findTurnStartIndex) stops at the same boundary.
const SESSION_BOUNDARY_RE = SESSION_BOUNDARY_TEXT_RE;

// Our own prior injections, used for fire-once-per-boundary dedupe.
const BOOTSTRAP_NAG_RE = /does not show Melxis context recovery/;
const CHECKPOINT_NAG_RE = /task-like progress may not be reflected in Melxis yet/;

// Reminders per session boundary. Beyond this the same text stops informing and
// starts costing budget (habituation).
const CHECKPOINT_NAG_BUDGET = 2;

// Marker scans are restricted to hook-emitted entries (hookOnly): the
// literal marker strings also appear in tool_result / tool_use entries when
// this toolkit's own sources are read or edited, and in assistant prose that
// quotes the templates — systematically, in exactly the sessions that
// develop the toolkit. The shared reader recognizes Claude hook records and
// Codex developer messages explicitly marked as hooks.additional_context.

export function hasMelxisContext(entries) {
  if (!Array.isArray(entries) || entries.length === 0) return false;
  if (hasToolCallMatching(entries, MELXIS_TOOL_RE)) {
    return true;
  }
  const text = extractText(entries);
  // `project-orientation` used to appear here: the hive's control surface was a
  // tagged mel, so the tag in the transcript meant context had been recovered.
  // The control surface is the guide now and nothing in the flow emits that tag,
  // so the marker could only match text about something else — a false positive
  // suppresses the reminder and the session starts cold, which is the expensive
  // direction. `hive_context_get` covers the same recovery.
  return /\bMelxis Session Bootstrap\b|\bmelxis hive\b|hive_context_get|Called plugin:melxis:melxis|Called plugin:melxis:memory|Called plugin:melxis:task/i.test(
    text,
  );
}

export function shouldInjectBootstrap({ prompt, entries }) {
  if (typeof prompt !== 'string') return { inject: false };
  const trimmed = prompt.trim();
  if (!trimmed || trimmed.startsWith('/')) return { inject: false, reason: 'command-or-empty' };

  const boundaryIndex = findLastEntryIndexMatching(entries, SESSION_BOUNDARY_RE, { hookOnly: true });
  const nagIndex = findLastEntryIndexMatching(entries, BOOTSTRAP_NAG_RE, { hookOnly: true });

  if (boundaryIndex >= 0) {
    // Anchor the judgement to the last session boundary (startup/resume/
    // compact): only recovery that happened AFTER the boundary counts.
    // Recovery from before a compact/resume may be stale or summarized away.
    if (hasToolCallMatchingAfterIndex(entries, MELXIS_TOOL_RE, boundaryIndex)) {
      return { inject: false, reason: 'recovered-after-boundary' };
    }
    // Fire once per boundary: if we already reminded and the model still has
    // not recovered, repeating the same text only burns tokens (instruction
    // habituation). The next boundary resets the budget.
    if (nagIndex > boundaryIndex) {
      return { inject: false, reason: 'nagged-after-boundary' };
    }
    return { inject: true, reason: 'boundary-without-recovery' };
  }

  // No boundary marker in the tail window: the SessionStart hook may be
  // missing/untrusted, or a long session scrolled it out. Fall back to
  // content-based detection, still capped at one reminder per tail window.
  if (hasMelxisContext(entries)) return { inject: false, reason: 'context-present' };
  if (nagIndex >= 0) return { inject: false, reason: 'already-nagged' };
  return { inject: true, reason: 'no-context' };
}

export function shouldInjectCheckpointRecovery({ entries }) {
  if (!Array.isArray(entries) || entries.length === 0) return { inject: false, reason: 'empty' };
  if (!hasTaskLikeContext(entries)) return { inject: false, reason: 'no-task-context' };

  const operationCheckpoints = extractOperationCheckpoints(entries);
  const lastOperationCheckpointIndex = operationCheckpoints.reduce(
    (max, checkpoint) => Math.max(max, checkpoint.entryIndex ?? -1),
    -1,
  );
  const lastCaptureAnchorIndex = findLastCaptureAnchorIndex(entries);
  const lastProgressIndex = findLastSubstantialProgressIndex(entries);
  const hasDecisionSignal = lastCaptureAnchorIndex >= 0;
  const hasProgressSignal = lastProgressIndex >= 0;
  const hasOperationCheckpoint = operationCheckpoints.length >= 1;

  if (!hasOperationCheckpoint && !hasProgressSignal && !hasDecisionSignal) {
    return { inject: false, reason: 'no-checkpoint-signal' };
  }

  // Arming (may the reminder fire at all) and re-arming (may it fire *again*
  // after we already reminded) are deliberately different signals.
  //
  // Arming stays broad: bare progress prose is enough for the first reminder.
  // Re-arming must not include bare progress. SUBSTANTIAL_PROGRESS_PATTERN
  // matches ordinary words ("fixed", "added", and their Japanese equivalents),
  // so in a session that
  // is actively working, every turn produces a newer progress index — the
  // suppression `nagIndex > anchorIndex` could then never hold and the reminder
  // fired on every single turn (observed 2026-07-26: ~14% of the Melxis token
  // budget spent re-asking for an anchor that was already in place).
  //
  // Only a genuine new checkpoint (an operation checkpoint, or a decision /
  // capture anchor) re-arms. Progress alone does not.
  const armIndex = Math.max(lastOperationCheckpointIndex, lastCaptureAnchorIndex, lastProgressIndex);
  const rearmIndex = Math.max(lastOperationCheckpointIndex, lastCaptureAnchorIndex);

  // Compare at turn granularity: a write anywhere in the same turn as the
  // latest progress signal counts as reflecting it. Real turns write first
  // and narrate last, so an entry-order comparison against armIndex misread
  // every well-behaved turn as unreflected (observed dogfood 2026-07-30:
  // the reminder fired on every prompt of a patch-first session).
  // findTurnStartIndex walks backward, so armTurnStartIndex <= armIndex always.
  const armTurnStartIndex = findTurnStartIndex(entries, armIndex);
  if (hasTaskWriteAfterIndex(entries, armTurnStartIndex - 1)) {
    return { inject: false, reason: 'task-write-after-checkpoint' };
  }

  const checkpointNagIndex = findLastEntryIndexMatching(entries, CHECKPOINT_NAG_RE, { hookOnly: true });
  if (checkpointNagIndex >= 0 && checkpointNagIndex > rearmIndex) {
    // Distinguish the two suppressions in the debug trace: nothing new at all
    // vs. new prose that reads like progress but is not a checkpoint. The
    // latter is the case that used to re-arm on every turn.
    return {
      inject: false,
      reason: armIndex > checkpointNagIndex ? 'progress-only-no-rearm' : 'nagged-after-checkpoint',
    };
  }

  // Budget per session boundary. Even with real new checkpoints, repeating the
  // same reminder past a couple of times is habituation, not guidance.
  const boundaryIndex = findLastEntryIndexMatching(entries, SESSION_BOUNDARY_RE, { hookOnly: true });
  const nagsSinceBoundary = countEntriesMatchingAfterIndex(entries, CHECKPOINT_NAG_RE, boundaryIndex, {
    hookOnly: true,
  });
  if (nagsSinceBoundary >= CHECKPOINT_NAG_BUDGET) {
    return { inject: false, reason: 'nag-budget-exhausted' };
  }

  return { inject: true };
}

export function buildAdditionalContext({ prompt, entries }) {
  const blocks = [];
  const bootstrap = shouldInjectBootstrap({ prompt, entries });
  if (bootstrap.inject) blocks.push(BOOTSTRAP_TEMPLATE);

  const checkpoint = shouldInjectCheckpointRecovery({ entries });
  if (checkpoint.inject) blocks.push(CHECKPOINT_RECOVERY_TEMPLATE);

  const directive = shouldInjectDirective({ prompt, entries });
  if (directive.inject) blocks.push(DIRECTIVE_TEMPLATE(directive.matched.join(', ')));

  // Stateless trigger observability: opt-in stderr trace of every decision so
  // firing reliability can be measured from logs instead of anecdote.
  if (process.env.MELXIS_HOOK_DEBUG === '1') {
    process.stderr.write(
      `melxis-hook[user-prompt-submit]: bootstrap=${bootstrap.inject ? 'fire' : bootstrap.reason} ` +
        `checkpoint=${checkpoint.inject ? 'fire' : checkpoint.reason} ` +
        `directive=${directive.inject ? 'fire' : directive.reason}\n`,
    );
  }

  return blocks.join('\n');
}

// Guard: skip the main flow when imported by the test runner. The test file
// imports collectMatches / shouldInjectDirective and does not want the hook
// to attempt to read stdin.
const isMain = import.meta.url === `file://${process.argv[1]}`;
if (isMain) {
  try {
    const input = readStdinJson();
    const prompt = input.prompt ?? '';
    const transcriptPath = input.transcript_path ?? '';
    // 800 lines, not 200: one heavy turn (parallel tool fan-outs, workflow
    // notifications) can exceed 200 entries, evicting the session boundary and
    // the prior-nag records from the window — the per-boundary nag budget then
    // resets every prompt and the reminder fires forever (observed dogfood
    // 2026-07-30). Reading a longer tail costs milliseconds.
    // An unavailable or malformed transcript is not an empty new session.
    // Let the existing catch report it without injecting an ungrounded nag.
    const lines = readTranscriptTail(transcriptPath, 800, { strict: true });
    const entries = parseTranscript(lines, { strict: true });
    const additionalContext = buildAdditionalContext({ prompt, entries });
    if (additionalContext) {
      process.stdout.write(
        JSON.stringify({
          hookSpecificOutput: {
            hookEventName: 'UserPromptSubmit',
            additionalContext,
          },
        }) + '\n',
      );
    }
  } catch (err) {
    logError('user-prompt-submit', err);
  }
  process.exit(0);
}
