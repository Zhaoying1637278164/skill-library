"""Dataset operations: list, info, sql, data, pull, push.

Wraps sup dataset subcommands as structured Python functions.
Each function calls run_sup() with --json and parses the output
into typed dataclasses.
"""
import json
from dataclasses import dataclass, field
from typing import List, Optional

from scripts.config import ToolkitConfig
from scripts.sync import run_sup


@dataclass
class DatasetSummary:
    """Single dataset in a list result."""
    id: int
    name: str
    database: str = ""
    schema: str = ""
    modified: str = ""


@dataclass
class DatasetListResult:
    """Result from list_datasets()."""
    success: bool
    datasets: List[DatasetSummary] = field(default_factory=list)
    total: int = 0
    error: str = ""


@dataclass
class DatasetInfo:
    """Detailed metadata for a single dataset."""
    success: bool
    id: int = 0
    name: str = ""
    database: str = ""
    schema: str = ""
    sql: str = ""
    columns: List[dict] = field(default_factory=list)
    metrics: List[dict] = field(default_factory=list)
    raw: dict = field(default_factory=dict)
    error: str = ""


@dataclass
class DatasetSQL:
    """SQL definition for a dataset."""
    success: bool
    sql: str = ""
    error: str = ""


@dataclass
class DatasetData:
    """Sample data results from a dataset query."""
    success: bool
    columns: List[str] = field(default_factory=list)
    rows: List[dict] = field(default_factory=list)
    row_count: int = 0
    error: str = ""


@dataclass
class DatasetPullResult:
    """Result from pull_datasets()."""
    success: bool
    datasets_pulled: int = 0
    files: List[str] = field(default_factory=list)
    error: str = ""


@dataclass
class DatasetPushResult:
    """Result from push_datasets()."""
    success: bool
    datasets_pushed: int = 0
    errors: List[str] = field(default_factory=list)
    error: str = ""


def _parse_dataset_summary(item: dict) -> DatasetSummary:
    """Parse a single dataset dict from sup JSON into DatasetSummary."""
    return DatasetSummary(
        id=item.get("id", 0),
        name=item.get("table_name", ""),
        database=item.get("database_name", ""),
        schema=item.get("schema", ""),
        modified=item.get("changed_on_utc", ""),
    )


def list_datasets(
    config: ToolkitConfig,
    search: Optional[str] = None,
    database_id: Optional[int] = None,
    mine: bool = False,
    modified_after: Optional[str] = None,
    limit: Optional[int] = None,
    order: Optional[str] = None,
    desc: bool = False,
) -> DatasetListResult:
    """List datasets with optional filtering. Uses sup dataset list --json."""
    args = ["dataset", "list", "--json"]

    if search is not None:
        args.extend(["--search", search])
    if database_id is not None:
        args.extend(["--database-id", str(database_id)])
    if mine:
        args.append("--mine")
    if modified_after is not None:
        args.extend(["--modified-after", modified_after])
    if limit is not None:
        args.extend(["--limit", str(limit)])
    if order is not None:
        args.extend(["--order", order])
    if desc:
        args.append("--desc")

    r = run_sup(args)
    if r.returncode != 0:
        return DatasetListResult(success=False, error=r.stderr.strip())

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError) as e:
        return DatasetListResult(success=False, error=f"JSON parse error: {e}")

    if isinstance(data, list):
        datasets = [_parse_dataset_summary(item) for item in data]
    else:
        datasets = []

    return DatasetListResult(success=True, datasets=datasets, total=len(datasets))


def get_dataset_info(
    config: ToolkitConfig,
    dataset_id: int,
) -> DatasetInfo:
    """Get detailed metadata for a single dataset. Uses sup dataset info --json."""
    args = ["dataset", "info", str(dataset_id), "--json"]

    r = run_sup(args)
    if r.returncode != 0:
        return DatasetInfo(success=False, error=r.stderr.strip())

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError) as e:
        return DatasetInfo(success=False, error=f"JSON parse error: {e}")

    if not isinstance(data, dict):
        return DatasetInfo(success=False, error="Unexpected response format")

    return DatasetInfo(
        success=True,
        id=data.get("id", 0),
        name=data.get("table_name", ""),
        database=data.get("database_name", ""),
        schema=data.get("schema", ""),
        sql=data.get("sql", ""),
        columns=data.get("columns", []),
        metrics=data.get("metrics", []),
        raw=data,
    )


def get_dataset_sql(
    config: ToolkitConfig,
    dataset_id: int,
) -> DatasetSQL:
    """Get the SQL definition for a dataset. Uses sup dataset sql --json."""
    args = ["dataset", "sql", str(dataset_id), "--json"]

    r = run_sup(args)
    if r.returncode != 0:
        return DatasetSQL(success=False, error=r.stderr.strip())

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError) as e:
        return DatasetSQL(success=False, error=f"JSON parse error: {e}")

    sql = data.get("result", "") if isinstance(data, dict) else ""
    return DatasetSQL(success=True, sql=sql)


def get_dataset_data(
    config: ToolkitConfig,
    dataset_id: int,
    limit: Optional[int] = None,
) -> DatasetData:
    """Get sample data from a dataset. Uses sup dataset data --json."""
    args = ["dataset", "data", str(dataset_id), "--json"]
    if limit is not None:
        args.extend(["--limit", str(limit)])

    r = run_sup(args)
    if r.returncode != 0:
        return DatasetData(success=False, error=r.stderr.strip())

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError) as e:
        return DatasetData(success=False, error=f"JSON parse error: {e}")

    if not isinstance(data, dict):
        return DatasetData(success=False, error="Unexpected response format")

    return DatasetData(
        success=True,
        columns=data.get("columns", []),
        rows=data.get("data", []),
        row_count=data.get("rowcount", 0),
    )


def pull_datasets(
    config: ToolkitConfig,
    dataset_id: Optional[int] = None,
    dataset_ids: Optional[List[int]] = None,
    name: Optional[str] = None,
    mine: bool = False,
    modified_after: Optional[str] = None,
    limit: Optional[int] = None,
    skip_dependencies: bool = False,
    overwrite: bool = True,
    assets_folder: Optional[str] = None,
) -> DatasetPullResult:
    """Pull dataset definitions to local filesystem. Uses sup dataset pull.

    dataset_id and dataset_ids are mutually exclusive.
    Raises ValueError if both are provided.
    """
    if dataset_id is not None and dataset_ids is not None:
        raise ValueError("dataset_id and dataset_ids are mutually exclusive")

    args = ["dataset", "pull", "--json"]

    if dataset_id is not None:
        args.extend(["--dataset-id", str(dataset_id)])
    if dataset_ids is not None:
        args.extend(["--dataset-ids", ",".join(str(did) for did in dataset_ids)])
    if name is not None:
        args.extend(["--name", name])
    if mine:
        args.append("--mine")
    if modified_after is not None:
        args.extend(["--modified-after", modified_after])
    if limit is not None:
        args.extend(["--limit", str(limit)])
    if skip_dependencies:
        args.append("--skip-dependencies")
    if not overwrite:
        args.append("--no-overwrite")
    if assets_folder is not None:
        args.extend(["--assets-folder", assets_folder])

    r = run_sup(args)
    if r.returncode != 0:
        return DatasetPullResult(success=False, error=r.stderr.strip())

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError) as e:
        return DatasetPullResult(success=False, error=f"JSON parse error: {e}")

    if not isinstance(data, dict):
        return DatasetPullResult(success=True)

    return DatasetPullResult(
        success=True,
        datasets_pulled=data.get("datasets_pulled", 0),
        files=data.get("files", []),
    )


def push_datasets(
    config: ToolkitConfig,
    assets_folder: Optional[str] = None,
    overwrite: bool = True,
    force: bool = True,
    continue_on_error: bool = False,
    load_env: bool = False,
) -> DatasetPushResult:
    """Push dataset definitions to workspace. Uses sup dataset push --json."""
    args = ["dataset", "push", "--json"]

    if assets_folder is not None:
        args.extend(["--assets-folder", assets_folder])
    if not overwrite:
        args.append("--no-overwrite")
    if force:
        args.append("--force")
    if continue_on_error:
        args.append("--continue-on-error")
    if load_env:
        args.append("--load-env")

    r = run_sup(args)
    if r.returncode != 0:
        return DatasetPushResult(success=False, error=r.stderr.strip())

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError) as e:
        return DatasetPushResult(success=False, error=f"JSON parse error: {e}")

    if not isinstance(data, dict):
        return DatasetPushResult(success=True)

    return DatasetPushResult(
        success=True,
        datasets_pushed=data.get("datasets_pushed", 0),
        errors=data.get("errors", []),
    )
