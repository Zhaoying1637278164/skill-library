# Security

Please report suspected vulnerabilities privately to <hi@getcontroller.ai>. Do not include credentials, OAuth tokens, customer data, or exploit details in a public issue.

Include the affected plugin version, a minimal reproduction, and the security impact. Controller AI will acknowledge the report and coordinate remediation and disclosure.
