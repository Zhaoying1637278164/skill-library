# CompanyTrack — UK Company Data for Claude

Connects Claude to [CompanyTrack](https://companytrack.com), a UK company
intelligence platform built on Companies House filings and derived sources.
Search ~5.8 million active UK companies (name, number, keyword, or semantic
description matching), then pull any layer of detail by company number:

| Tool | What it returns |
| --- | --- |
| `search_companies` | Find companies by name, number, filters, or description |
| `get_company` | Registry profile: status, address, SIC codes, incorporation |
| `get_financials` | Filed accounts — turnover, profit, assets, employees |
| `get_officers` | Directors and secretaries, current and resigned |
| `get_ownership` | Shareholders and PSCs (persons with significant control) |
| `get_group_structure` | Parent/subsidiary tree |
| `get_filings` | Filing history with document links |
| `get_charges` | Registered charges (mortgages, debentures) |
| `get_properties` | Land Registry property holdings |
| `get_grants` | Government grant awards |
| `get_fundraisings` | Equity raises reconstructed from SH01 filings |
| `get_news` | Recent news mentions |
| `get_intelligence` | Operating profile derived from the company website |
| `get_person` | A person's directorships and shareholdings across companies |
| `get_credit_balance` | Your remaining CompanyTrack credits |

All tools are read-only.

## Setup

1. Get a free API key at **[companytrack.com/api-keys](https://companytrack.com/api-keys)**
   — the free tier includes 1,000 API/MCP credits a month, no card required.
2. Install the plugin. When you enable it, Claude prompts for your CompanyTrack
   API key and stores it securely in your system keychain.
3. Start asking about UK companies:

   > "Who are the directors of Monzo Bank and what did it report in its last accounts?"

If the key is missing or wrong, tool calls return a clear error telling you
where to get one — re-enter it in the plugin's settings.

Works in Claude Code and Claude Cowork.

## Pricing and limits

Listing tools is free. Each tool call draws on your CompanyTrack credit
allowance (1,000/month free; paid plans at
[companytrack.com/pricing](https://companytrack.com/pricing)). Failed calls are
never billed.

## Support

- Docs: [companytrack.com/mcp-server](https://companytrack.com/mcp-server)
- API reference: [companytrack.com/uk-company-data-api](https://companytrack.com/uk-company-data-api)
- Contact: contact@companytrack.com

## Privacy

The server receives only your API key and the tool arguments you send. Data
served is UK public-register information (Companies House, Land Registry) and
derived analytics. See [companytrack.com/privacy](https://companytrack.com/privacy).
