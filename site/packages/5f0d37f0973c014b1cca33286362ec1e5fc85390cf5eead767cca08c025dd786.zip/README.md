# Varlock Skill for Claude Code

> Secure-by-default environment variable management. Ensures secrets are **never exposed** in Claude sessions.

## Why This Skill?

When working with Claude Code, secrets can accidentally leak into:
- Terminal output
- Claude's input/output context
- Log files or traces
- Git commits or diffs

This skill wraps [Varlock](https://varlock.dev) to enforce secure patterns and prevent accidental exposure.

## Installation

### Option A: One-liner (Recommended)

```bash
mkdir -p ~/.claude/skills/varlock && curl -sSL https://raw.githubusercontent.com/wrsmith108/varlock-claude-skill/main/skills/varlock/SKILL.md -o ~/.claude/skills/varlock/SKILL.md
```

### Option B: Manual

```bash
git clone https://github.com/wrsmith108/varlock-claude-skill /tmp/varlock-skill
cp -r /tmp/varlock-skill/skills/varlock ~/.claude/skills/
rm -rf /tmp/varlock-skill
```

## Prerequisites

Install the Varlock CLI:

```bash
curl -sSfL https://varlock.dev/install.sh | sh -s -- --force-no-brew
export PATH="$HOME/.varlock/bin:$PATH"
```

## Core Principle

**Secrets must NEVER appear in Claude's context.**

| Never Do | Safe Alternative |
|----------|------------------|
| `cat .env` | `cat .env.schema` |
| `echo $SECRET` | `varlock load` |
| `printenv \| grep API` | `varlock load \| grep API` |

## Quick Reference

```bash
# Validate all secrets (shows masked values)
varlock load

# Quiet validation (no output on success)
varlock load --quiet

# Run command with secrets injected
varlock run -- npm start

# View schema (safe - no values)
cat .env.schema
```

## Schema File

Create `.env.schema` to define variable types and sensitivity:

```bash
# Global defaults
# @defaultSensitive=true @defaultRequired=infer

# Public config
# @type=enum(development,staging,production) @sensitive=false
NODE_ENV=development

# Sensitive secrets
# @type=string(startsWith=sk_) @required @sensitive
STRIPE_SECRET_KEY=

# @type=url @required @sensitive
DATABASE_URL=
```

### Annotations

| Annotation | Effect |
|------------|--------|
| `@sensitive` | Value masked in all output |
| `@sensitive=false` | Value shown (for public keys) |
| `@required` | Must be present |
| `@type=string(startsWith=X)` | Prefix validation |


## Handling Secret Requests

When users ask Claude to:

- **"Check if API key is set"** → `varlock load | grep API_KEY`
- **"Debug authentication"** → `varlock load` (validates all)
- **"Update a secret"** → Decline; ask user to update manually
- **"Show me .env"** → `cat .env.schema` instead

## Credits

This skill wraps [Varlock](https://github.com/dmno-dev/varlock) by [DMNO](https://dmno.dev).

## License

MIT
