---
name: guardian
description: Use BEFORE any significant decision or implementation, and especially when STARTING or SWITCHING a task (e.g. after /add-task) or resuming after a break/compaction — to verify it aligns with the project's NORTH_STAR (essence + invariants), the current FOCUS objective, and the cardinal principles. Catches hyper-focusing on the immediate sub-task while forgetting the overarching goal (e.g. building a feature while forgetting the project is a SaaS sold to clients).
---

# Guardian — consistency with context / objective / principles

Before a significant decision or implementing, STOP and check:

1. **NORTH_STAR** — does the decision respect the project's essence and its invariants? (e.g. if it is a multi-tenant SaaS, does the feature respect multi-tenancy and billing?)
2. **FOCUS** — are you working on the current 🔄 objective or drifting? One feature at a time (R.17).
3. **Cardinal principles** — done=validated · adversarial verification · lose-nothing (+ the project-type principles: for software, systematic debugging and goal verification).

If the decision contradicts one of these: **do NOT proceed blindly** — flag the tension to the user and realign. The GUARDIAN (injected by the hooks) keeps these elements always in context; this skill is the moment when you **actively use** them to judge.
