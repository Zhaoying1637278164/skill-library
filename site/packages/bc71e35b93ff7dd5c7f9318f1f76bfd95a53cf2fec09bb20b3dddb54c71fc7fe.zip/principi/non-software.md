## 📗 Principles — Tier 2b: NON-software projects  (STUB)
> Loaded when the project is NOT software development (research, writing, design, etc.).
>
> **TODO (to be defined in a dedicated pass).** The method was born and tested ~90% on software projects;
> here go the *equivalent* method rules for non-software projects (e.g. source verification instead of
> debugging, validation with reviewers/readers instead of tests, etc.).

- *(placeholder — to be filled in)*
