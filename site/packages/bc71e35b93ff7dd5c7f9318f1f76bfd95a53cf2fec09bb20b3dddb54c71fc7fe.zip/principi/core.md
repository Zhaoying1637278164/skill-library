## ⚓ Cardinal principles — Tier 1 (universal)
> They hold for EVERY project (software or not).

- **Done = validated, not implemented.** Green build/tests = *implemented*; "done" only after the user has seen it work. Never declare it done on compilation alone.
- **Adversarial verification.** Every thesis / finding / decision goes through an attempt to **refute** it by reading reality (code, data, output), not just asserting it. When in doubt, refute.
- **Lose nothing.** Whatever is decided / done / to-do / to-verify / to-flag gets **written to a file immediately**, before acting. Conversation memory is not reliable.
