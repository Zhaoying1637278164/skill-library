# KotlinSense - Codex Context

## Project

- Path: `Plugins/KotlinSense`
- Type: plugin

## Workflows

- Inspect existing README, package/build files, and scripts before choosing commands.
- Keep generated output and local machine state out of git.
- Add project-specific notes here when a durable decision is made.

## Codex Rules

- Global context comes from `~/.codex/AGENTS.md`.
- Verify actual files before claiming repo state, config, counts, or duplicates.
- Do not commit secrets, `.env*`, local config, signing material, generated caches, sessions, or auth files.
- Stage files by explicit path only.
- Prefer focused changes and match existing project patterns.
- Treat plugin manifests, skills, and privacy-policy docs as release-sensitive.

