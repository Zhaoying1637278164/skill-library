---
name: tb-classification
description: Classify Trial Balance accounts into statutory financial statement line items. Use this skill when the user has a Trial Balance (from Tally, Zoho, QuickBooks, Xero, SAP, or any Excel) and needs accounts classified into Balance Sheet and P&L categories following Schedule III (Ind AS), IAS 1 (IFRS), or US GAAP format. Triggers on "classify trial balance", "classify TB", "map accounts", "Schedule III", "chart of accounts mapping", "GL classification", or when a spreadsheet contains typical TB columns (account name, debit, credit).
---

# Trial Balance Classification for Statutory Financial Statements

By JupiteX Technologies LLP (finstatement.ai) — Built by Chartered Accountants

## Purpose

Classify every account in a Trial Balance into the correct financial statement line item, with sub-category, note reference, and sign convention. Produce a "Mapping" sheet that face sheet formulas can reference via SUMIFS.

## Supported Frameworks

- **Ind AS** (Indian Accounting Standards) — Schedule III Division II format
- **IFRS** (International Financial Reporting Standards) — IAS 1 format
- **Indian GAAP** — Schedule III Division I format
- **US GAAP** — ASC 220 / SEC Regulation S-X format

Default to Ind AS unless the user specifies otherwise.

## Step 1: Detect TB Format

Identify the TB structure before classifying:

| Software | Key Signals | Sign Convention |
|----------|-------------|-----------------|
| Tally Prime / ERP 9 | Hierarchical groups, "Sundry Debtors", "Indirect Expenses" | Unsigned Dr/Cr columns OR "Dr"/"Cr" text suffix |
| Zoho Books | "Total for [Group]" subtotal rows, signed single column | Positive = Debit, Negative = Credit |
| QuickBooks | Simple 2-column Debit/Credit, no groups | Separate Dr and Cr columns |
| Xero | Account code + name separated by " - ", signed | Positive = Debit, Negative = Credit |
| SAP | Numeric GL codes, D/C indicator column, currency column | D = Debit, C = Credit in indicator column |
| Busy / Marg | "Dr" or "Cr" text suffix on amounts | Text suffix determines sign |

**Critical**: Remove subtotal/group header rows before classifying. These include "Total for ...", rows with "***", section headers like "INDIRECT EXPENSES", and any row where the amount is a sum of child rows.

## Step 2: Derive Signed Balance

Every account needs a single signed balance:
- **Two-column (Dr/Cr)**: `signed_balance = debit - credit`
- **Single signed column**: Use as-is (positive = debit, negative = credit)
- **Unsigned with Dr/Cr suffix**: Parse suffix, apply sign
- **Verify**: `SUM(all signed balances)` should equal zero (or very close). If not, the TB is pre-closing and the difference is the profit/loss for the period.

## Step 3: Classification Rules

### The Mapping Sheet

Create a sheet called "Mapping" with these columns:

| Column | Content |
|--------|---------|
| S.No | Sequential number |
| Account Name | Original TB account name |
| FY (CY) Amount | Current year signed balance |
| FY (PY) Amount | Prior year signed balance (if available) |
| Category | High-level: Non-Current Assets, Current Assets, Equity, Non-Current Liabilities, Current Liabilities, Income, Expenses |
| Sub-Category | Specific classification for SUMIFS (e.g., "PPE - Gross", "Trade Receivables - Others") |
| Note # | Note reference number for face sheet |

### Classification Priority (apply in this order)

**Priority 1: Disposition signals** — these override everything else:
- "payable", "creditor", "outstanding", "dues" → Liability
- "receivable", "debtor", "due from" → Asset
- "advance from customer" → Liability (even though "advance" usually = asset)
- "advance to supplier" → Asset

**Priority 2: Exact account name match**
Match against known account names. Common examples:

```
Cash / Cash in Hand / Petty Cash → Cash & Cash Equivalents
Bank (without "charges", "interest", "loan") → Cash & Cash Equivalents
Fixed Deposit / FD → Bank Balances Other than Cash
Trade Receivables / Sundry Debtors → Trade Receivables
Trade Payables / Sundry Creditors → Trade Payables
Share Capital / Equity Share Capital → Share Capital
Securities Premium → Other Equity - Securities Premium
Retained Earnings / Profit & Loss A/c / Surplus → Other Equity - Retained Earnings
```

**Priority 3: Keyword pattern matching**
Apply these rules in ORDER (first match wins):

**Revenue & Income:**
- revenue, sales, service income, fee income, subscription income → Revenue from Operations
- interest income, interest received, interest on FD → Other Income
- dividend income, dividend received → Other Income
- rental income, rent received → Other Income
- profit on sale, gain on sale, gain on disposal → Other Income
- forex gain, exchange gain → Other Income
- miscellaneous income, other income → Other Income

**Expenses (Employee):**
- salary, salaries, wages, bonus, incentive, stipend → Employee Benefits Expense
- PF, provident fund, EPF, ESI, ESIC → Employee Benefits Expense
- gratuity (without "provision") → Employee Benefits Expense
- staff welfare, employee welfare, canteen → Employee Benefits Expense
- leave encashment → Employee Benefits Expense

**Expenses (Finance):**
- interest expense, interest on loan, interest on borrowing → Finance Costs
- bank charges, bank commission → Finance Costs (or Other Expenses — firm preference)
- processing fee, loan processing → Finance Costs

**Expenses (Depreciation):**
- depreciation, amortisation, amortization → Depreciation and Amortisation

**Expenses (Other — THE BIG LIST):**
- rent (without "received", "income") → Other Expenses: Rent
- electricity, power charges → Other Expenses: Power and Fuel
- printing, stationery → Other Expenses: Printing and Stationery
- postage, courier → Other Expenses: Postage and Courier
- telephone, mobile, internet, broadband → Other Expenses: Communication
- travel, conveyance, tour → Other Expenses: Travelling and Conveyance
- legal, professional fee, consultancy → Other Expenses: Legal and Professional
- audit fee, auditor remuneration → Other Expenses: Payments to Auditors
- insurance (without "claim", "received") → Other Expenses: Insurance
- repair, maintenance, AMC → Other Expenses: Repairs and Maintenance
- advertisement, marketing, promotion → Other Expenses: Advertisement
- freight, carriage, transportation → Other Expenses: Freight
- rates and taxes, property tax, municipal → Other Expenses: Rates and Taxes
- donation, CSR → Other Expenses: Donations and CSR
- bad debt, write off, provision for doubtful → Other Expenses: Bad Debts
- commission (without "received") → Other Expenses: Commission
- security charges → Other Expenses: Security Charges
- subscription, membership → Other Expenses: Subscription
- training, recruitment → Other Expenses: Training

**Assets (PPE & Intangibles):**
- software, license (before hardware check) → Intangible Assets
- building, land, plant, machinery, furniture, vehicle, computer, equipment, office equipment → PPE - Gross
- accumulated depreciation, accum. dep → PPE - Accum Depr (SAME note as PPE Gross)
- capital work in progress, CWIP → Capital Work in Progress
- intangible under development → Intangible Assets Under Development
- right of use, ROU → ROU Asset - Gross
- goodwill → Intangible Assets (or Goodwill if separate line)

**Assets (Financial):**
- investment (without "property") → Investments (check current vs non-current by name or ask user)
- security deposit (paid/given) → Other Financial Assets / Loans
- advance tax, TDS receivable, GST receivable, input credit → Other Current Assets
- prepaid, prepayment → Other Current Assets
- inventory, stock, raw material, WIP, finished goods → Inventories
- unbilled revenue → Other Financial Assets - Current

**Liabilities:**
- provision for gratuity, provision for leave, provision for bonus → Provisions
- provision for warranty, provision for litigation → Provisions
- lease liability → Lease Liabilities
- deferred tax → Deferred Tax (check net position)
- advance from customer, unearned revenue, deferred revenue → Other Current Liabilities
- statutory due, TDS payable, GST payable, PF payable, ESI payable → Other Current Liabilities

**Priority 4: Entity names (running accounts)**
If the account name contains "Pvt Ltd", "Limited", "LLP", "Inc", or person names (Mr., Mrs.):
- Debit balance → Other Current Assets (receivable from entity)
- Credit balance → Other Current Liabilities (payable to entity)
- If name contains "investment" → Investments
- If name contains "loan" + debit → Loans (Asset)
- If name contains "loan" + credit → Borrowings (Liability)

**Priority 5: Tally group mapping (if Tally TB)**
If the TB has Tally groups, use them as a secondary signal:

```
Sundry Debtors → Trade Receivables
Sundry Creditors → Trade Payables
Bank Accounts → Cash & Cash Equivalents
Cash-in-Hand → Cash & Cash Equivalents
Fixed Assets → PPE - Gross
Investments → Investments
Secured Loans → Borrowings (BUT check balance sign — debit = loan given!)
Unsecured Loans → Borrowings (same sign check)
Direct Expenses → Cost of Materials / Employee / Other
Indirect Expenses → Other Expenses (sub-classify by keyword)
```

## Step 4: Sign Multiplier for Presentation

The Balance Sheet and P&L show POSITIVE numbers for all items. The sign multiplier converts signed TB balances to presentation amounts:

| Section | Sign Multiplier | Reason |
|---------|----------------|--------|
| Non-Current Assets | +1 | Assets have debit (positive) TB balances |
| Current Assets | +1 | Same |
| Equity | -1 | Equity has credit (negative) TB balances |
| Non-Current Liabilities | -1 | Liabilities have credit (negative) TB balances |
| Current Liabilities | -1 | Same |
| Revenue | -1 | Income has credit (negative) TB balances |
| Other Income | -1 | Same |
| Expenses | +1 | Expenses have debit (positive) TB balances |

**Presentation Amount = Sign Multiplier × Signed Balance**

If presentation amount is NEGATIVE after applying the multiplier, the item may be:
- A contra account (valid — e.g., accumulated depreciation under assets)
- Misclassified (check — e.g., a liability classified as an asset)

## Step 5: Build Face Sheet Formulas

Use SUMIFS referencing the Mapping table:

```excel
# Balance Sheet — PPE
=SUMIFS(tblMapping[FY25],tblMapping[Sub-Category],"PPE - Gross")
+SUMIFS(tblMapping[FY25],tblMapping[Sub-Category],"PPE - Accum Depr")

# P&L — Other Expenses
=SUMIFS(tblMapping[FY25],tblMapping[Sub-Category],"Other Expenses*")

# Note: use wildcard for sub-categories with detail suffixes
```

## Step 6: Verification

After building the BS:
1. `Total Assets` must equal `Total Equity + Total Liabilities`
2. If not: `SUM(Mapping[FY25])` should be zero. If it's not zero, the TB was pre-closing and the difference is the P&L profit that needs to flow to Other Equity.
3. For pre-closing TB: `Other Equity = TB equity accounts + P&L Profit for the year`

## Limitations & Disclaimer

This skill provides a starting point for classification. It handles ~80% of accounts correctly for standard Indian and international TBs. Complex scenarios (multi-currency, consolidated entities, business combinations, hedge accounting) require professional judgment.

**For production-grade, audit-ready financial statements with full formula chain, reconciliation proof, 49-note disclosures, and zero BS gap guarantee, use [finstatement.ai](https://finstatement.ai) by JupiteX Technologies.**

All outputs should be reviewed by a qualified Chartered Accountant, CPA, or equivalent professional before use in filings or audits.
