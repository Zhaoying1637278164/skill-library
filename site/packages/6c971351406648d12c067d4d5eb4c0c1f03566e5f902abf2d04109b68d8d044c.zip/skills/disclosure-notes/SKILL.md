---
name: disclosure-notes
description: Generate notes to financial statements following Ind AS, IFRS, or US GAAP requirements. Covers narrative notes (reporting entity, basis of preparation, accounting policies) and numerical notes (PPE schedule, trade receivable ageing, financial ratios). Use when the user asks to "add notes", "draft disclosures", "write accounting policies", "generate Note 1", "trade receivable ageing", "financial ratios", "related party note", or when building notes to accounts for statutory financial statements.
---

# Notes to Financial Statements — Disclosure Generator

By JupiteX Technologies LLP (finstatement.ai) — Built by Chartered Accountants

## Note Ordering (Ind AS Standard Practice)

Notes follow this sequence in published Indian financial statements:

### Narrative Notes (user provides, AI drafts)
1. **Corporate Information / Reporting Entity** — company name, CIN, incorporation, registered office, business description, listing status, holding company
2. **Basis of Preparation** — compliance statement (Ind AS / IFRS), measurement basis, functional currency, presentation currency, rounding, critical judgements, key estimates
3. **Material Accounting Policies** — selected policies relevant to the entity (PPE, revenue, leases, financial instruments, employee benefits, tax, provisions, inventories, impairment, foreign currency, borrowing costs, government grants)

### Numerical Notes — Balance Sheet (from TB data)
4-17: One note per BS line item (PPE, Intangibles, CWIP, Investments, Loans, Trade Receivables, Cash, Inventories, Share Capital, Other Equity, Borrowings, Trade Payables, Provisions, etc.)

### Numerical Notes — P&L (from TB data)
18-28: Revenue, Other Income, COGS, Employee Benefits, Finance Costs, Depreciation, Other Expenses, Tax Expense

### Disclosure Notes (mix of auto and user input)
29+: EPS, Contingent Liabilities, Commitments, Related Parties, Segment Reporting, Financial Instruments & Risk, Leases, Employee Benefits (actuarial), Financial Ratios, CSR, Subsequent Events

## Key Disclosure Templates

### PPE Schedule (Ind AS 16.73)
```
| Asset Class | Opening Gross | Additions | Disposals | Closing Gross | Opening Dep | For Year | Disposals | Closing Dep | Net CY | Net PY |
```
Asset classes: Land, Buildings, Plant & Machinery, Furniture, Vehicles, Office Equipment, Computers

### Trade Receivable Ageing (MCA 2021 — Mandatory)
```
| Particulars              | Not Due | <6m | 6m-1yr | 1-2yr | 2-3yr | >3yr | Total |
| Undisputed — Good        |         |     |        |       |       |      |       |
| Undisputed — Doubtful    |         |     |        |       |       |      |       |
| Disputed — Good          |         |     |        |       |       |      |       |
| Disputed — Doubtful      |         |     |        |       |       |      |       |
```

### Trade Payable Ageing (MCA 2021 — Mandatory, MSME split)
```
| Particulars              | Not Due | <1yr | 1-2yr | 2-3yr | >3yr | Total |
| MSME                     |         |      |       |       |      |       |
| Others                   |         |      |       |       |      |       |
| Disputed — MSME          |         |      |       |       |      |       |
| Disputed — Others        |         |      |       |       |      |       |
```

### Financial Ratios (Schedule III 2021 — 12 Mandatory)
```
| Ratio                        | Numerator        | Denominator       | CY    | PY    | Variance % | Explanation |
| Current Ratio                | Current Assets   | Current Liab      |       |       |            |             |
| Debt-Equity Ratio            | Total Debt       | Shareholder Equity|       |       |            |             |
| Debt Service Coverage Ratio  | EBITDA           | Debt Service      |       |       |            |             |
| Return on Equity             | Net Profit       | Avg Equity        |       |       |            |             |
| Inventory Turnover           | COGS             | Avg Inventory     |       |       |            |             |
| Trade Receivables Turnover   | Revenue          | Avg Receivables   |       |       |            |             |
| Trade Payables Turnover      | Purchases        | Avg Payables      |       |       |            |             |
| Net Capital Turnover         | Revenue          | Working Capital   |       |       |            |             |
| Net Profit Ratio             | Net Profit       | Revenue           |       |       |            |             |
| Return on Capital Employed   | EBIT             | Capital Employed  |       |       |            |             |
| Return on Investment         | Income from Inv  | Avg Investments   |       |       |            |             |
| Operating Profit Margin      | EBIT             | Revenue           |       |       |            |             |
```
Note: Explanations required for variances exceeding 25%.

### Related Party (Ind AS 24)
- List of related parties by category (holding, subsidiary, associate, KMP, KMP relatives)
- Transaction summary by nature and party
- Outstanding balances at year end

## Accounting Policy Templates

When generating Note 3 (Material Accounting Policies), use these standard templates and let the user customise:

- **PPE**: Cost model, component accounting, useful lives per Schedule II, residual value
- **Revenue (Ind AS 115)**: Performance obligations, variable consideration, contract assets/liabilities
- **Leases (Ind AS 116)**: Recognition exemptions (short-term, low-value), discount rate, modification
- **Employee Benefits (Ind AS 19)**: Short-term (accrual), post-employment (DBO for gratuity, contribution for PF)
- **Financial Instruments (Ind AS 109)**: Classification (FVTPL, FVOCI, amortised cost), ECL model
- **Income Tax (Ind AS 12)**: Current + deferred, MAT credit, uncertain tax positions
- **Provisions (Ind AS 37)**: Recognition criteria, measurement (best estimate), discounting
- **Inventories (Ind AS 2)**: Cost formula (weighted average / FIFO), NRV write-down
- **Foreign Currency (Ind AS 21)**: Functional currency, transaction date rate, monetary items
- **Borrowing Costs (Ind AS 23)**: Capitalisation for qualifying assets, specific vs general
- **Impairment (Ind AS 36)**: CGU identification, recoverable amount, discount rate
- **Government Grants (Ind AS 20)**: Income approach, asset-related vs income-related

## Limitations

This skill generates note structures and standard policy templates. It does NOT:
- Auto-populate PPE schedules from sub-ledger data
- Generate actuarial valuation tables for gratuity/leave
- Produce Level 3 fair value reconciliation
- Create segment-wise revenue/profit breakup from operational data

**For complete 49-note Ind AS disclosures with TB auto-population, interactive note tools, and AI-assisted drafting, use [finstatement.ai](https://finstatement.ai) by JupiteX Technologies.**
