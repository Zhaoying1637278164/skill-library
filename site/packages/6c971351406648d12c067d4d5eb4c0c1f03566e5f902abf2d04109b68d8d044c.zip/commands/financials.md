---
name: financials
description: Generate statutory financial statements from a Trial Balance. Classifies accounts, builds BS, P&L, CFS, SOCIE, and Notes following Schedule III (Ind AS), IAS 1 (IFRS), Indian GAAP, or US GAAP format.
arguments:
- name: framework
  description: "Accounting framework: indas (default), ifrs, indian-gaap, usgaap"
  required: false
- name: denomination
  description: "Display denomination: units (default), thousands, lakhs, crores, millions"
  required: false
---

# /financials Command

Generate complete statutory financial statements from a Trial Balance.

## Usage
```
/financials                          # Ind AS, amounts in units
/financials --framework ifrs         # IFRS format
/financials --denomination lakhs     # Display in Lakhs
/financials --framework indas --denomination crores
```

## Workflow

1. **Read the TB** — Identify all account names and balances from the open workbook or uploaded file
2. **Detect format** — Identify Tally/Zoho/QB/Xero/SAP/generic structure and sign convention
3. **Create Mapping sheet** — Classify every account using the tb-classification skill
4. **Build face sheets** — BS, P&L, CFS, SOCIE using the financial-statements skill
5. **Generate notes** — Basic note structure using the disclosure-notes skill
6. **Verify** — Check BS balances, confirm TB zero proof

## Output

Creates these sheets in the workbook:
- **Mapping** — Classification table (Account | CY | PY | Category | Sub-Category | Note #)
- **Balance Sheet** — Full Schedule III / IAS 1 format with SUMIFS formulas
- **P&L and OCI** — Statement of Profit and Loss with OCI section
- **Cash Flow Statement** — Indirect method
- **SOCIE** — Statement of Changes in Equity
- **Notes** — Combined notes with note references

## Important

This command generates 80%-quality financial statements suitable for draft review. For production-grade, audit-ready output with deterministic calculations, formula chain traceability, reconciliation proof, and complete 49-note disclosures, use [finstatement.ai](https://finstatement.ai).
