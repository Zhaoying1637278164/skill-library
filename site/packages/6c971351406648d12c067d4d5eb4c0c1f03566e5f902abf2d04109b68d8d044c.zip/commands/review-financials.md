---
name: review-financials
description: Review financial statements for errors, inconsistencies, and compliance issues. Checks BS balance, formula integrity, cross-references, sign conventions, and common mistakes.
---

# /review-financials Command

Review an existing set of financial statements for errors and compliance issues.

## Usage
```
/review-financials                   # Review the open workbook
```

## Checks Performed

1. Balance Sheet balances (Assets = Equity + Liabilities)
2. P&L profit flows correctly to Other Equity on BS
3. CFS closing cash matches BS Cash and Cash Equivalents
4. Each note total matches its face sheet reference
5. No unexpected negative values on the BS
6. No hardcoded values in face sheet cells (should be formulas)
7. TB/Mapping sums to zero (or identified as pre-closing)
8. Prior year completeness (no missing PY-only accounts)
9. Scientific notation or rounding artifacts cleaned
10. Sign convention consistency across all sections

## Output

Produces a findings table with severity, location, description, and suggested fix for each issue found.
