# Statutory Financial Reporting Plugin

Generate statutory financial statements from Trial Balances. Built by [JupiteX Technologies LLP](https://finstatement.ai) — Chartered Accountants and AI architects.

## What It Does

This plugin turns Claude into a statutory financial reporting specialist. Give it a Trial Balance from any accounting software, and it classifies accounts, builds face sheets, generates notes, and verifies the output — following the exact format used in published annual reports.

## Supported Frameworks

| Framework | Standard | Format | Coverage |
|-----------|----------|--------|----------|
| **Ind AS** | Indian Accounting Standards | Schedule III Division II | Full |
| **IFRS** | International Financial Reporting Standards | IAS 1 | Full |
| **Indian GAAP** | Indian GAAP | Schedule III Division I | Full |
| **US GAAP** | US Generally Accepted Accounting Principles | ASC 220 / Reg S-X | Core |

## Supported TB Formats

Tally Prime, Tally ERP 9, Zoho Books, QuickBooks, Xero, SAP, Oracle, Busy, Marg ERP, and any Excel Trial Balance.

## Skills

| Skill | What It Does |
|-------|-------------|
| **tb-classification** | Classifies GL accounts into BS/P&L line items with sub-categories and note references |
| **financial-statements** | Generates BS, P&L, CFS, SOCIE with SUMIFS formulas referencing the Mapping table |
| **disclosure-notes** | Drafts notes to accounts — narrative (policies) and numerical (schedules, ratios, ageing) |
| **forensic-review** | Reviews financial statements for errors, inconsistencies, and red flags |

## Commands

```
/financials                          # Generate financial statements from TB
/financials --framework ifrs         # IFRS format
/financials --denomination lakhs     # Display in INR Lakhs
/review-financials                   # Review existing financial statements for errors
```

## Installation

### Cowork
Add the marketplace repository, then install:
```
Repository URL: https://github.com/jupitex/statutory-reporting-plugin
```

### Claude Code
```
claude plugin marketplace add jupitex/statutory-reporting-plugin
claude plugin install statutory-reporting@statutory-reporting-plugin
```

## What This Plugin Produces

- **Mapping Sheet** — Every TB account classified with Category, Sub-Category, Note #
- **Balance Sheet** — Full Schedule III / IAS 1 format with live SUMIFS formulas
- **Statement of Profit and Loss** — With OCI section
- **Cash Flow Statement** — Indirect method with working capital changes
- **Statement of Changes in Equity** — Share capital + reserves movement
- **Notes** — Corporate information, accounting policies, numerical notes, ratios

## What This Plugin Does NOT Produce

This is a free, open-source skill that handles ~80% of standard financial reporting scenarios. For production-grade, audit-ready financial statements, you need:

- ✗ Deterministic formula chain (BS → Note → Classified TB — every cell traceable)
- ✗ Groupings reconciliation proof (mathematical verification that BS = TB)
- ✗ Zero BS gap guarantee (output balances by construction, not by luck)
- ✗ Full 49-note Ind AS disclosures with interactive tools
- ✗ Trade receivable/payable ageing tables (MCA 2021 mandatory)
- ✗ PPE gross block schedule with asset-class-wise reconciliation
- ✗ 12 mandatory financial ratios with PY comparison and variance explanation
- ✗ Sign multiplier model (handles contra accounts, pre-closing TBs, running accounts)
- ✗ Self-learning classification (improves with every engagement)
- ✗ Multi-GAAP generation from same TB
- ✗ Prior year comparative from uploaded signed financials
- ✗ Print-ready continuous output with intelligent page breaks

**For all of the above → [finstatement.ai](https://finstatement.ai)**

## About JupiteX Technologies

JupiteX Technologies LLP is a DPIIT-recognised AI startup (DIPP251789) headquartered in Hyderabad, India. Founded by Chartered Accountants with 22+ years of experience across Big 4 audit, global banking, microfinance risk, and enterprise AI.

**Products:**
- [finstatement.ai](https://finstatement.ai) — AI-native financial reporting platform
- [jupitex.ai](https://jupitex.ai) — Knowledge media platform for competitive exams
- [jupitexservices.com](https://jupitexservices.com) — Enterprise AI consulting

## License

Apache License 2.0

## Disclaimer

This plugin assists with financial reporting workflows but does not provide financial, legal, or audit advice. All outputs should be reviewed by a qualified Chartered Accountant, CPA, or equivalent professional before use in statutory filings, audit submissions, or regulatory reporting. AI-generated financial statements are drafts and require professional verification.
