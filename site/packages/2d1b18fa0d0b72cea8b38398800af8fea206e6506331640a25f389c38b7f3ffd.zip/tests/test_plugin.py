#!/usr/bin/env python3
"""
Unit tests for claude-code-tokenbudget plugin hooks.
Run with: python3 -m pytest tests/ or python3 -m unittest tests/test_plugin.py
"""

import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

HOOKS_DIR = Path(__file__).parent.parent / "hooks"
ENFORCE = HOOKS_DIR / "enforce_quota.py"
TRACK = HOOKS_DIR / "track_tokens.py"
STATUS = HOOKS_DIR / "quota_status.py"
SNOOZE = HOOKS_DIR / "snooze.py"


def run_script(script: Path, stdin: str = "", env_overrides: dict = None) -> subprocess.CompletedProcess:
    env = {**os.environ, **(env_overrides or {})}
    return subprocess.run(
        [sys.executable, str(script)],
        input=stdin,
        capture_output=True,
        text=True,
        env=env,
    )


def make_ledger(ledger_dir: Path, total_tokens: int, days_ago: int = 0, sessions: list = None) -> Path:
    target_date = date.today() - timedelta(days=days_ago)
    ledger_file = ledger_dir / f"{target_date.isoformat()}.json"
    ledger_file.write_text(
        json.dumps(
            {
                "date": target_date.isoformat(),
                "total_tokens": total_tokens,
                "sessions": sessions or [],
            }
        )
    )
    return ledger_file


def make_transcript(tmp_dir: Path, usage: dict) -> Path:
    transcript = tmp_dir / "session.jsonl"
    entry = {
        "parentUuid": "abc123",
        "isSidechain": False,
        "message": {
            "role": "assistant",
            "usage": usage,
        },
    }
    transcript.write_text(json.dumps(entry) + "\n")
    return transcript


class TestEnforceQuota(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_dir = Path(self.tmp.name)
        self.env = {"TOKEN_QUOTA_DIR": self.tmp.name, "TOKEN_QUOTA_DAILY": "1000000"}

    def tearDown(self):
        self.tmp.cleanup()

    def test_allows_when_no_ledger(self):
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_allows_when_under_limit(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_blocks_when_at_limit(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")
        self.assertIn("exceeded", output["reason"])

    def test_blocks_when_over_limit(self):
        make_ledger(self.ledger_dir, total_tokens=1_200_000)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")

    def test_warns_at_95_percent(self):
        make_ledger(self.ledger_dir, total_tokens=960_000)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "allow")
        self.assertIn("Nearly exhausted", output["reason"])

    def test_warns_to_stderr_at_85_percent(self):
        make_ledger(self.ledger_dir, total_tokens=860_000)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.stdout.strip(), "")
        self.assertIn("token-quota", result.stderr)

    def test_warns_at_custom_critical_threshold(self):
        env = {**self.env, "TOKEN_QUOTA_WARN_CRITICAL": "80", "TOKEN_QUOTA_WARN": "70"}
        make_ledger(self.ledger_dir, total_tokens=810_000)  # 81% — above custom critical
        result = run_script(ENFORCE, stdin="{}", env_overrides=env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "allow")
        self.assertIn("Nearly exhausted", output["reason"])

    def test_warns_to_stderr_at_custom_warn_threshold(self):
        env = {**self.env, "TOKEN_QUOTA_WARN_CRITICAL": "90", "TOKEN_QUOTA_WARN": "70"}
        make_ledger(self.ledger_dir, total_tokens=750_000)  # 75% — above custom warn, below critical
        result = run_script(ENFORCE, stdin="{}", env_overrides=env)
        self.assertEqual(result.stdout.strip(), "")
        self.assertIn("token-quota", result.stderr)

    def test_no_warning_below_warn_threshold(self):
        env = {**self.env, "TOKEN_QUOTA_WARN_CRITICAL": "95", "TOKEN_QUOTA_WARN": "85"}
        make_ledger(self.ledger_dir, total_tokens=800_000)  # 80% — below both thresholds
        result = run_script(ENFORCE, stdin="{}", env_overrides=env)
        self.assertEqual(result.stdout.strip(), "")
        self.assertEqual(result.stderr.strip(), "")

    def test_respects_custom_limit(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        env = {**self.env, "TOKEN_QUOTA_DAILY": "500000"}
        result = run_script(ENFORCE, stdin="{}", env_overrides=env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")

    def test_handles_empty_stdin(self):
        result = run_script(ENFORCE, stdin="", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)

    def test_handles_corrupt_ledger(self):
        (self.ledger_dir / f"{date.today().isoformat()}.json").write_text("not json")
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")


class TestTrackTokens(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_dir = Path(self.tmp.name)
        self.env = {"TOKEN_QUOTA_DIR": self.tmp.name, "TOKEN_QUOTA_DAILY": "1000000"}

    def tearDown(self):
        self.tmp.cleanup()

    def _stop_hook_input(self, transcript_path: str) -> str:
        return json.dumps(
            {
                "session_id": "test-session",
                "transcript_path": transcript_path,
                "hook_event_name": "Stop",
            }
        )

    def test_records_tokens_from_transcript(self):
        transcript = make_transcript(
            self.ledger_dir,
            {
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
        )
        stdin = self._stop_hook_input(str(transcript))
        result = run_script(TRACK, stdin=stdin, env_overrides=self.env)
        self.assertEqual(result.returncode, 0)

        ledger = json.loads((self.ledger_dir / f"{date.today().isoformat()}.json").read_text())
        self.assertEqual(ledger["total_tokens"], 150)
        self.assertEqual(len(ledger["sessions"]), 1)

    def test_records_cache_tokens(self):
        transcript = make_transcript(
            self.ledger_dir,
            {
                "input_tokens": 10,
                "output_tokens": 20,
                "cache_creation_input_tokens": 500,
                "cache_read_input_tokens": 1000,
            },
        )
        stdin = self._stop_hook_input(str(transcript))
        run_script(TRACK, stdin=stdin, env_overrides=self.env)

        ledger = json.loads((self.ledger_dir / f"{date.today().isoformat()}.json").read_text())
        self.assertEqual(ledger["total_tokens"], 1530)

    def test_accumulates_across_turns(self):
        transcript = make_transcript(
            self.ledger_dir,
            {
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
        )
        stdin = self._stop_hook_input(str(transcript))
        run_script(TRACK, stdin=stdin, env_overrides=self.env)
        run_script(TRACK, stdin=stdin, env_overrides=self.env)

        ledger = json.loads((self.ledger_dir / f"{date.today().isoformat()}.json").read_text())
        self.assertEqual(ledger["total_tokens"], 300)
        self.assertEqual(len(ledger["sessions"]), 2)

    def test_handles_empty_stdin(self):
        result = run_script(TRACK, stdin="", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)

    def test_handles_missing_transcript(self):
        stdin = self._stop_hook_input("/nonexistent/path.jsonl")
        result = run_script(TRACK, stdin=stdin, env_overrides=self.env)
        self.assertEqual(result.returncode, 0)

    def test_handles_transcript_with_no_usage(self):
        transcript = self.ledger_dir / "empty.jsonl"
        transcript.write_text(json.dumps({"role": "user", "content": "hello"}) + "\n")
        stdin = self._stop_hook_input(str(transcript))
        result = run_script(TRACK, stdin=stdin, env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertFalse((self.ledger_dir / f"{date.today().isoformat()}.json").exists())

    def test_cleans_up_old_ledgers(self):
        old_file = make_ledger(self.ledger_dir, total_tokens=1000, days_ago=35)
        recent_file = make_ledger(self.ledger_dir, total_tokens=1000, days_ago=5)

        transcript = make_transcript(
            self.ledger_dir,
            {
                "input_tokens": 10,
                "output_tokens": 10,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
        )
        stdin = self._stop_hook_input(str(transcript))
        env = {**self.env, "TOKEN_QUOTA_RETAIN_DAYS": "30"}
        run_script(TRACK, stdin=stdin, env_overrides=env)

        self.assertFalse(old_file.exists())
        self.assertTrue(recent_file.exists())

    def test_retains_files_within_window(self):
        recent_file = make_ledger(self.ledger_dir, total_tokens=1000, days_ago=10)
        transcript = make_transcript(
            self.ledger_dir,
            {
                "input_tokens": 10,
                "output_tokens": 10,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
        )
        stdin = self._stop_hook_input(str(transcript))
        env = {**self.env, "TOKEN_QUOTA_RETAIN_DAYS": "30"}
        run_script(TRACK, stdin=stdin, env_overrides=env)

        self.assertTrue(recent_file.exists())

    def test_stderr_reports_usage(self):
        transcript = make_transcript(
            self.ledger_dir,
            {
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
        )
        stdin = self._stop_hook_input(str(transcript))
        result = run_script(TRACK, stdin=stdin, env_overrides=self.env)
        self.assertIn("token-quota", result.stderr)
        self.assertIn("150", result.stderr)


class TestEnforceQuotaWeekly(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_dir = Path(self.tmp.name)
        # High daily limit so it never fires first
        self.env = {
            "TOKEN_QUOTA_DIR": self.tmp.name,
            "TOKEN_QUOTA_DAILY": "10000000",
            "TOKEN_QUOTA_WEEKLY": "3000000",
        }

    def tearDown(self):
        self.tmp.cleanup()

    def test_allows_when_no_weekly_ledgers(self):
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_allows_when_under_weekly_limit(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=1)
        make_ledger(self.ledger_dir, total_tokens=500_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_blocks_when_weekly_limit_exceeded(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=2)
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=1)
        make_ledger(self.ledger_dir, total_tokens=1_100_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")
        self.assertIn("Weekly", output["reason"])

    def test_blocks_at_exact_weekly_limit(self):
        make_ledger(self.ledger_dir, total_tokens=1_500_000, days_ago=1)
        make_ledger(self.ledger_dir, total_tokens=1_500_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")

    def test_ignores_days_outside_rolling_window(self):
        # 10 days ago is outside the 7-day window and should not count
        make_ledger(self.ledger_dir, total_tokens=3_000_000, days_ago=10)
        make_ledger(self.ledger_dir, total_tokens=500_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_no_weekly_limit_by_default(self):
        env = {"TOKEN_QUOTA_DIR": self.tmp.name, "TOKEN_QUOTA_DAILY": "10000000"}
        make_ledger(self.ledger_dir, total_tokens=5_000_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")


class TestEnforceQuotaMonthly(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_dir = Path(self.tmp.name)
        # High daily and weekly limits so they never fire first
        self.env = {
            "TOKEN_QUOTA_DIR": self.tmp.name,
            "TOKEN_QUOTA_DAILY": "10000000",
            "TOKEN_QUOTA_WEEKLY": "100000000",
            "TOKEN_QUOTA_MONTHLY": "5000000",
        }

    def tearDown(self):
        self.tmp.cleanup()

    def test_allows_when_no_monthly_ledgers(self):
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_allows_when_under_monthly_limit(self):
        make_ledger(self.ledger_dir, total_tokens=2_000_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_blocks_when_monthly_limit_exceeded(self):
        # Use days_ago=0 and 1 to stay safely within the current calendar month.
        # This assumption holds when run on the 2nd or later of any month.
        make_ledger(self.ledger_dir, total_tokens=3_000_000, days_ago=1)
        make_ledger(self.ledger_dir, total_tokens=2_500_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")
        self.assertIn("Monthly", output["reason"])

    def test_blocks_at_exact_monthly_limit(self):
        make_ledger(self.ledger_dir, total_tokens=5_000_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")

    def test_no_monthly_limit_by_default(self):
        env = {"TOKEN_QUOTA_DIR": self.tmp.name, "TOKEN_QUOTA_DAILY": "20000000"}
        make_ledger(self.ledger_dir, total_tokens=10_000_000, days_ago=0)
        result = run_script(ENFORCE, stdin="{}", env_overrides=env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")


def make_snooze(ledger_dir: Path, extra_tokens: int, days_ago: int = 0) -> Path:
    snooze_date = date.today() - timedelta(days=days_ago)
    snooze_file = ledger_dir / "snooze.json"
    snooze_file.write_text(
        json.dumps(
            {
                "extra_tokens": extra_tokens,
                "expires": snooze_date.isoformat(),
            }
        )
    )
    return snooze_file


class TestSnooze(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_dir = Path(self.tmp.name)
        self.env = {
            "TOKEN_QUOTA_DIR": self.tmp.name,
            "TOKEN_QUOTA_DAILY": "1000000",
        }

    def tearDown(self):
        self.tmp.cleanup()

    def test_snooze_creates_file(self):
        run_script(SNOOZE, env_overrides=self.env)
        snooze_file = self.ledger_dir / "snooze.json"
        self.assertTrue(snooze_file.exists())
        data = json.loads(snooze_file.read_text())
        self.assertEqual(data["extra_tokens"], 1_000_000)
        self.assertEqual(data["expires"], date.today().isoformat())

    def test_snooze_respects_custom_amount(self):
        env = {**self.env, "TOKEN_QUOTA_SNOOZE_TOKENS": "500000"}
        run_script(SNOOZE, env_overrides=env)
        data = json.loads((self.ledger_dir / "snooze.json").read_text())
        self.assertEqual(data["extra_tokens"], 500_000)

    def test_snooze_allows_previously_blocked_prompt(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000)  # at daily limit
        make_snooze(self.ledger_dir, extra_tokens=1_000_000)  # snooze adds 1M more
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "")

    def test_expired_snooze_is_ignored(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000)
        make_snooze(self.ledger_dir, extra_tokens=1_000_000, days_ago=1)  # yesterday
        result = run_script(ENFORCE, stdin="{}", env_overrides=self.env)
        output = json.loads(result.stdout)
        self.assertEqual(output["decision"], "block")

    def test_snooze_shown_in_status(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        make_snooze(self.ledger_dir, extra_tokens=1_000_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertIn("Snooze", result.stdout)
        self.assertIn("1,000,000", result.stdout)

    def test_no_snooze_line_without_active_snooze(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertNotIn("Snooze", result.stdout)


class TestQuotaStatus(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_dir = Path(self.tmp.name)
        self.env = {"TOKEN_QUOTA_DIR": self.tmp.name, "TOKEN_QUOTA_DAILY": "1000000"}

    def tearDown(self):
        self.tmp.cleanup()

    def test_reports_no_usage_when_no_ledger(self):
        result = run_script(STATUS, env_overrides=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertIn("No usage recorded", result.stdout)

    def test_shows_usage_stats(self):
        make_ledger(self.ledger_dir, total_tokens=250_000, sessions=[{"timestamp": "2026-04-17T10:00:00", "input_tokens": 200_000, "output_tokens": 50_000}])
        result = run_script(STATUS, env_overrides=self.env)
        self.assertIn("250,000", result.stdout)
        self.assertIn("750,000", result.stdout)

    def test_shows_ok_status_when_under_80_percent(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertIn("OK", result.stdout)

    def test_shows_warning_status_at_85_percent(self):
        make_ledger(self.ledger_dir, total_tokens=870_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertIn("WARNING", result.stdout)

    def test_shows_exceeded_status_at_100_percent(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertIn("EXCEEDED", result.stdout)

    def test_shows_turn_count(self):
        make_ledger(
            self.ledger_dir,
            total_tokens=100_000,
            sessions=[
                {"timestamp": "2026-04-17T10:00:00"},
                {"timestamp": "2026-04-17T11:00:00"},
                {"timestamp": "2026-04-17T12:00:00"},
            ],
        )
        result = run_script(STATUS, env_overrides=self.env)
        self.assertIn("3", result.stdout)

    def test_no_weekly_section_without_limit(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertNotIn("Weekly", result.stdout)

    def test_no_monthly_section_without_limit(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertNotIn("Monthly", result.stdout)

    def test_shows_weekly_section_when_limit_set(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=1)
        make_ledger(self.ledger_dir, total_tokens=500_000, days_ago=0)
        env = {**self.env, "TOKEN_QUOTA_WEEKLY": "5000000"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("Weekly", result.stdout)
        self.assertIn("1,500,000", result.stdout)
        self.assertIn("3,500,000", result.stdout)  # remaining

    def test_shows_monthly_section_when_limit_set(self):
        make_ledger(self.ledger_dir, total_tokens=500_000, days_ago=0)
        env = {**self.env, "TOKEN_QUOTA_MONTHLY": "10000000"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("Monthly", result.stdout)
        self.assertIn("9,500,000", result.stdout)  # remaining

    def test_weekly_shows_exceeded_status(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=1)
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=0)
        env = {**self.env, "TOKEN_QUOTA_WEEKLY": "1500000"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("EXCEEDED", result.stdout)

    def test_monthly_shows_exceeded_status(self):
        make_ledger(self.ledger_dir, total_tokens=5_000_000, days_ago=0)
        env = {**self.env, "TOKEN_QUOTA_MONTHLY": "3000000"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("EXCEEDED", result.stdout)

    def test_warns_when_retain_days_below_31_with_monthly_quota(self):
        env = {**self.env, "TOKEN_QUOTA_MONTHLY": "10000000", "TOKEN_QUOTA_RETAIN_DAYS": "28"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("WARNING", result.stdout)
        self.assertIn("RETAIN_DAYS", result.stdout)

    def test_no_retain_days_warning_without_monthly_quota(self):
        env = {**self.env, "TOKEN_QUOTA_RETAIN_DAYS": "7"}
        result = run_script(STATUS, env_overrides=env)
        self.assertNotIn("RETAIN_DAYS", result.stdout)

    def test_no_retain_days_warning_when_retain_days_is_31(self):
        env = {**self.env, "TOKEN_QUOTA_MONTHLY": "10000000", "TOKEN_QUOTA_RETAIN_DAYS": "31"}
        result = run_script(STATUS, env_overrides=env)
        self.assertNotIn("RETAIN_DAYS", result.stdout)

    def test_no_cost_shown_without_cost_per_m(self):
        make_ledger(self.ledger_dir, total_tokens=500_000)
        result = run_script(STATUS, env_overrides=self.env)
        self.assertNotIn("~$", result.stdout)

    def test_shows_cost_in_daily_section(self):
        # 1,000,000 tokens at $5.40/M = $5.40
        make_ledger(self.ledger_dir, total_tokens=1_000_000)
        env = {**self.env, "TOKEN_QUOTA_COST_PER_M": "5.40"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("~$5.40", result.stdout)

    def test_shows_cost_in_weekly_section(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=0)
        env = {**self.env, "TOKEN_QUOTA_WEEKLY": "5000000", "TOKEN_QUOTA_COST_PER_M": "5.40"}
        result = run_script(STATUS, env_overrides=env)
        # Weekly section should contain cost for used tokens and limit
        self.assertIn("~$5.40", result.stdout)

    def test_shows_cost_in_monthly_section(self):
        make_ledger(self.ledger_dir, total_tokens=1_000_000, days_ago=0)
        env = {**self.env, "TOKEN_QUOTA_MONTHLY": "5000000", "TOKEN_QUOTA_COST_PER_M": "5.40"}
        result = run_script(STATUS, env_overrides=env)
        self.assertIn("~$5.40", result.stdout)


if __name__ == "__main__":
    unittest.main()
