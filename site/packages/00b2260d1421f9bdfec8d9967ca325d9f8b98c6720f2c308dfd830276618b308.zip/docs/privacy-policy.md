---
title: Privacy Policy
nav_order: 7
---

# Privacy Policy

**Last updated: April 4, 2026**

## Overview

sailfishos-dev is a skill plugin for [Claude Code](https://claude.ai/code). It consists
entirely of documentation files that are loaded into Claude's context to provide
SailfishOS development guidance.

## Data collection

This plugin does not collect, transmit, store, or process any personal data.

Specifically:

- **No data is collected.** The plugin contains only static markdown files.
- **No network requests are made.** The plugin does not connect to any server or
  external service.
- **No analytics or tracking.** No usage data, identifiers, or telemetry of any kind
  are gathered.
- **No cookies.** This plugin does not use cookies or any local storage mechanism.

## How the plugin works

When you use this plugin, Claude Code loads the plugin's markdown files into the
AI model's context window. All processing happens within your Claude Code session.
No information from your session is sent to or stored by the plugin author.

## Third-party services

This plugin has no integration with any third-party services.

Your use of Claude Code itself is subject to [Anthropic's Privacy Policy](https://www.anthropic.com/privacy).

## Changes to this policy

If this policy is updated, the "Last updated" date at the top of this page will
change. Changes will be published to this page and to the
[GitHub repository](https://github.com/juergenbr/claude-plugin-sailfishos-dev).

## Contact

Questions about this policy can be directed to the repository maintainer via
[GitHub Issues](https://github.com/juergenbr/claude-plugin-sailfishos-dev/issues).
