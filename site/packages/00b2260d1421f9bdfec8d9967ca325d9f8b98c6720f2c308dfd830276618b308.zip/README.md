# sailfishos-dev

SailfishOS app development skill. Teaches Claude how to develop, build, deploy, debug,
and publish SailfishOS applications using the Sailfish SDK, Silica QML, and sfdk CLI.

## Skill

- **sailfishos-dev** — Covers app architecture, Silica components, Theme design properties,
  sfdk build/deploy/run commands, C++/QML integration, debugging, platform APIs
  (Notifications, DBus, Contacts, Pickers), and Harbour store submission.

## Invoke

`/sailfishos-dev` — or it activates automatically when you ask about SailfishOS topics.
