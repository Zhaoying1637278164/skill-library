/*
 * SPDX-FileCopyrightText: The ilo Authors
 * SPDX-License-Identifier: 0BSD
 */
package wtf.metio.ilo.shell;

import wtf.metio.ilo.errors.LocalDirectoryDoesNotExistException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static wtf.metio.ilo.utils.Streams.filter;
import static wtf.metio.ilo.utils.Streams.fromList;

/**
 * Controls how the 'ilo shell' command handles missing local mount directories.
 */
public enum ShellVolumeBehavior {

  /**
   * Automatically create local volume mount directories that do not exist. If local directory cannot be created,
   * behave like WARN and remove from --volume list.
   */
  CREATE {
    @Override
    boolean handleMissingDirectory(final Path directory) {
      try {
        if (Files.notExists(directory)) {
          Files.createDirectories(directory);
        }
        return true;
      } catch (final IOException exception) {
        System.err.println("Could not create directory " + directory.toAbsolutePath() + " because of " + exception.getMessage());
        return false;
      }
    }
  },

  /**
   * Warn in case local mount directories do not exist remove them from --volume list.
   */
  WARN {
    @Override
    boolean handleMissingDirectory(final Path directory) {
      if (Files.exists(directory)) {
        return true;
      }
      System.err.println("The local directory " + directory.toAbsolutePath() + " does not exist.");
      return false;
    }
  },

  /**
   * Error in case local mount directories do not exist and stop execution.
   */
  ERROR {
    @Override
    boolean handleMissingDirectory(final Path directory) {
      if (Files.notExists(directory)) {
        throw new LocalDirectoryDoesNotExistException(directory);
      }
      return true;
    }
  };

  public List<String> handleLocalDirectories(final List<String> volumes) {
    return filter(fromList(volumes))
        .filter(this::handleLocalDirectory)
        .toList();
  }

  private boolean handleLocalDirectory(final String volume) {
    if (!isBindMount(volume)) {
      // Named volumes (e.g. 'cache:/data') and anonymous volumes (e.g. '/data') have no host
      // directory, so they are passed through untouched rather than created or checked.
      return true;
    }
    final var localPath = Paths.get(extractLocalPart(volume));
    return handleMissingDirectory(localPath);
  }

  /**
   * Decides whether a {@code --volume} value bind-mounts a host directory, as opposed to referencing
   * a named or anonymous volume. A bind mount has a {@code source:target} form whose source is a
   * path; a named volume source is a bare name (no path separator) and an anonymous volume has no
   * source at all. This mirrors how the container runtime interprets the value.
   *
   * @param volume The {@code --volume} value.
   * @return Whether the value bind-mounts a host directory ilo should manage.
   */
  // visible for testing
  static boolean isBindMount(final String volume) {
    if (isWindowsDrivePath(volume)) {
      return true;
    }
    final var separator = volume.indexOf(':');
    if (separator < 0) {
      return false;
    }
    final var source = volume.substring(0, separator);
    // A source with a path separator is a path; so is a bare '.'/'..' or a './'/'../' prefix — those
    // are relative bind mounts a named-volume name (no separator) never is.
    return source.contains("/") || ".".equals(source) || "..".equals(source)
        || source.startsWith("./") || source.startsWith("../");
  }

  // visible for testing
  static String extractLocalPart(final String volume) {
    if (isWindowsDrivePath(volume)) {
      // 'C:\path:/container[:opts]': the source spans the drive letter and path up to the next ':'.
      final var next = volume.indexOf(':', 2);
      return next < 0 ? volume : volume.substring(0, next);
    }
    return volume.split(":")[0];
  }

  // A 'C:\…' / 'C:/…' style source, whose first ':' is the drive separator rather than the
  // source:target separator.
  private static boolean isWindowsDrivePath(final String volume) {
    return volume.length() >= 3 && Character.isLetter(volume.charAt(0)) && ':' == volume.charAt(1)
        && ('\\' == volume.charAt(2) || '/' == volume.charAt(2));
  }

  abstract boolean handleMissingDirectory(Path directory);

}
