/*
 * SPDX-FileCopyrightText: The ilo Authors
 * SPDX-License-Identifier: 0BSD
 */
package wtf.metio.ilo.devcontainer;

import picocli.CommandLine;
import wtf.metio.ilo.compose.ComposeRuntime;
import wtf.metio.ilo.compose.ComposeRuntimeConverter;
import wtf.metio.ilo.model.Options;
import wtf.metio.ilo.shell.ShellRuntime;
import wtf.metio.ilo.shell.ShellRuntimeConverter;

import java.util.List;

public final class DevcontainerOptions implements Options {

  @CommandLine.Option(
      names = {"--shell-runtime", "-S"},
      description = "Specify the shell runtime to use. If none is specified, use auto-selection.",
      converter = ShellRuntimeConverter.class
  )
  public ShellRuntime shellRuntime;

  @CommandLine.Option(
      names = {"--compose-runtime", "-C"},
      description = "Specify the compose runtime to use. If none is specified, use auto-selection.",
      converter = ComposeRuntimeConverter.class
  )
  public ComposeRuntime composeRuntime;

  @CommandLine.Option(
      names = {"--debug"},
      description = "Print the runtime commands to stderr before executing them."
  )
  public boolean debug;

  @CommandLine.Option(
      names = {"--pull"},
      description = "Pull images before opening shell."
  )
  public boolean pull;

  @CommandLine.Option(
      names = {"--mount-project-dir"},
      description = "Mount the project directory into the running container.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean mountProjectDir;

  @CommandLine.Option(
      names = {"--remove-image"},
      description = "Remove the container and its image after closing the shell, instead of keeping them for reuse."
  )
  public boolean removeImage;

  @CommandLine.Option(
      names = {"--fresh"},
      description = "Discard any reused container and start from a clean slate, re-running the creation lifecycle."
  )
  public boolean fresh;

  @CommandLine.Option(
      names = {"--shell"},
      description = "The shell to run when attaching interactively to the container.",
      defaultValue = "/bin/bash"
  )
  public String shell;

  @CommandLine.Option(
      names = {"--execute-initialize-command"},
      description = "Execute the 'initializeCommand' before creating containers.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean executeInitializeCommand;

  @CommandLine.Option(
      names = {"--execute-on-create-command"},
      description = "Execute the 'onCreateCommand' after a container was started.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean executeOnCreateCommand;

  @CommandLine.Option(
      names = {"--execute-update-content-command"},
      description = "Execute the 'updateContentCommand' after new content is available during the creation process.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean executeUpdateContentCommand;

  @CommandLine.Option(
      names = {"--execute-post-create-command"},
      description = "Execute the 'postCreateCommand' after a container was created.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean executePostCreateCommand;

  @CommandLine.Option(
      names = {"--execute-post-start-command"},
      description = "Execute the 'postStartCommand' after a container was started.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean executePostStartCommand;

  @CommandLine.Option(
      names = {"--execute-post-attach-command"},
      description = "Execute the 'postAttachCommand' after attaching to a container.",
      defaultValue = "true",
      fallbackValue = "true",
      negatable = true
  )
  public boolean executePostAttachCommand;

  @CommandLine.Parameters(
      index = "0..*",
      description = "List of possible locations for a devcontainer.json file. First found will be used.",
      defaultValue = ".devcontainer/devcontainer.json .devcontainer.json",
      split = " "
  )
  public List<String> locations;

  @Override
  public boolean debug() {
    return debug;
  }

}
