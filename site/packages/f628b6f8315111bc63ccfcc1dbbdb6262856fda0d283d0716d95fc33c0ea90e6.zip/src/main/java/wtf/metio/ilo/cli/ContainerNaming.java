/*
 * SPDX-FileCopyrightText: The ilo Authors
 * SPDX-License-Identifier: 0BSD
 */
package wtf.metio.ilo.cli;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

/**
 * Derives the deterministic name of a managed container. The same project directory and image always
 * map to the same name, so a later invocation finds and reuses the container started by an earlier
 * one; a different project or image maps to a different name, so unrelated sessions never collide.
 */
public final class ContainerNaming {

  // Container names must start with an alphanumeric and may then contain '_', '.' and '-'. A short
  // hex digest of the discriminator keeps the name valid, stable, and free of filesystem characters.
  private static final int DIGEST_LENGTH = 12;

  /**
   * @param prefix        A human-readable prefix identifying the command, e.g. {@code ilo-shell}.
   * @param discriminator The values that make a session unique, e.g. the project directory and image.
   * @return The container name, of the form {@code <prefix>-<digest>}.
   */
  public static String containerName(final String prefix, final String... discriminator) {
    return prefix + "-" + fingerprint(String.join(" ", discriminator));
  }

  private static String fingerprint(final String value) {
    try {
      final var digest = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
      return HexFormat.of().formatHex(digest).substring(0, DIGEST_LENGTH);
    } catch (final NoSuchAlgorithmException exception) {
      throw new IllegalStateException("SHA-256 is required to be present on every JVM", exception);
    }
  }

  private ContainerNaming() {
    // utility class
  }

}
