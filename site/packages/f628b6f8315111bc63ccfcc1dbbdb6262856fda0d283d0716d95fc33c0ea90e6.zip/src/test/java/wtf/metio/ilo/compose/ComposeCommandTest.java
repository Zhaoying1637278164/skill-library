/*
 * SPDX-FileCopyrightText: The ilo Authors
 * SPDX-License-Identifier: 0BSD
 */
package wtf.metio.ilo.compose;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import uk.org.webcompere.systemstubs.jupiter.SystemStubsExtension;
import uk.org.webcompere.systemstubs.stream.SystemErr;
import wtf.metio.ilo.errors.RuntimeIOException;
import wtf.metio.ilo.test.TestMethodSources;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("ComposeCommand")
@ExtendWith(SystemStubsExtension.class)
class ComposeCommandTest extends TestMethodSources {

  private static final String YML = "docker-compose.yml";
  // Stands in for the generated keepalive override file, so its path is known in assertions.
  private static final String OVERRIDE = "ilo-keepalive.yml";

  private ComposeCommand compose;
  private TestComposeExecutor executor;
  private ComposeOptions options;

  @BeforeEach
  void setUp() {
    executor = new TestComposeExecutor();
    options = new ComposeOptions();
    options.file = List.of(YML);
    options.service = "dev";
    compose = new ComposeCommand(executor, service -> OVERRIDE);
    compose.options = options;
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("brings up the services and execs into them")
  void minimal(final String runtime) {
    final var tool = useRuntime(runtime);
    final var exitCode = compose.call();
    assertEquals(0, exitCode);
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh"),
        call(tool, "--file", YML, "stop", "dev")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("pulls before bringing up the services")
  void withPull(final String runtime) {
    final var tool = useRuntime(runtime);
    options.pull = true;
    compose.call();
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "pull", "dev"),
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh"),
        call(tool, "--file", YML, "stop", "dev")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("builds before bringing up the services")
  void withBuild(final String runtime) {
    final var tool = useRuntime(runtime);
    options.build = true;
    compose.call();
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "build", "dev"),
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh"),
        call(tool, "--file", YML, "stop", "dev")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("tears the services down before recreating them when fresh")
  void fresh(final String runtime) {
    final var tool = useRuntime(runtime);
    options.fresh = true;
    compose.call();
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "down"),
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh"),
        call(tool, "--file", YML, "stop", "dev")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("execs a custom command instead of the shell")
  void customArguments(final String runtime) {
    final var tool = useRuntime(runtime);
    options.arguments = List.of("ls", "-la");
    compose.call();
    assertIterableEquals(
        call(tool, "--file", YML, "exec", "-T", "dev", "ls", "-la"),
        executor.executed().get(1));
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("brings up additional run services alongside the attached service")
  void withRunServices(final String runtime) {
    final var tool = useRuntime(runtime);
    options.runServices = List.of("db", "cache");
    compose.call();
    assertIterableEquals(
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev", "db", "cache"),
        executor.executed().get(0));
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("passes runtime run options to the up step")
  void withRuntimeRunOption(final String runtime) {
    final var tool = useRuntime(runtime);
    options.runtimeRunOptions = List.of("--use-aliases");
    compose.call();
    assertIterableEquals(
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "--use-aliases", "dev"),
        executor.executed().get(0));
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("reports the exit code of the attached command")
  void reportsAttachExitCode(final String runtime) {
    useRuntime(runtime);
    // pull (empty), build (empty), up, exec — the fourth executed step is the attach.
    executor.exitCodes(0, 0, 0, 7);
    assertEquals(7, compose.call());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("does not bring up the services when the build fails")
  void shortCircuitsOnBuildFailure(final String runtime) {
    final var tool = useRuntime(runtime);
    options.build = true;
    // The empty pull step consumes the first exit code; the build then fails.
    executor.exitCodes(0, 1);
    final var exitCode = compose.call();
    assertEquals(1, exitCode);
    assertIterableEquals(List.of(call(tool, "--file", YML, "build", "dev")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("leaves the services running while another session is still attached")
  void otherSessionKeepsRunning(final String runtime) {
    final var tool = useRuntime(runtime);
    // 'compose top' prints the container name, then the process table; a process beyond the keepalive
    // (PID 1 and its sleep child) means another terminal is attached.
    executor.processesOutput("project-dev-1\nUID PID PPID CMD\nroot 1 0 sh\nroot 2 1 sleep\nroot 42 0 bash\n");
    compose.call();
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("leaves the services running on exit with --keep-running")
  void keepRunning(final String runtime) {
    final var tool = useRuntime(runtime);
    options.keepRunningOnExit = true;
    compose.call();
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "--file", OVERRIDE, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("does not inject the keepalive and stops on exit with --no-override-command")
  void noOverrideCommand(final String runtime) {
    final var tool = useRuntime(runtime);
    options.overrideCommand = false;
    compose.call();
    assertIterableEquals(List.of(
        call(tool, "--file", YML, "up", "--detach", "dev"),
        call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh"),
        call(tool, "--file", YML, "stop", "dev")), executor.executed());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("passes cleanup options to the compose down when recreating")
  void wiresCleanupOptionsIntoDown(final String runtime) {
    final var tool = useRuntime(runtime);
    options.fresh = true;
    options.runtimeCleanupOptions = List.of("--volumes");
    compose.call();
    assertTrue(executor.executed().contains(call(tool, "--file", YML, "down", "--volumes")),
        executor.executed().toString());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("stops the run-services it started, not just the attached service, so they don't leak")
  void stopsRunServicesItStarted(final String runtime) {
    final var tool = useRuntime(runtime);
    options.runServices = List.of("db", "cache");
    compose.call();
    assertTrue(executor.executed().contains(call(tool, "--file", YML, "stop", "dev", "db", "cache")),
        executor.executed().toString());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("stops only the attached service on exit, leaving other services for other terminals")
  void stopsOnlyTheAttachedService(final String runtime) {
    final var tool = useRuntime(runtime);
    options.service = "web";
    compose.call();
    assertTrue(executor.executed().contains(call(tool, "--file", YML, "stop", "web")),
        executor.executed().toString());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("warns that services will be stopped without the keepalive override")
  void warnsWithoutOverride(final String runtime, final SystemErr systemErr) {
    useRuntime(runtime);
    options.overrideCommand = false;
    compose.call();
    assertTrue(systemErr.getText().contains("--keep-running"), systemErr.getText());
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("degrades to the unmanaged path when the keepalive override cannot be written")
  void degradesWhenOverrideWriteFails(final String runtime, final SystemErr systemErr) {
    final var failing = new ComposeCommand(executor, service -> {
      throw new RuntimeIOException(new IOException("disk full"));
    });
    failing.options = options;
    final var tool = useRuntime(runtime);

    failing.call();

    assertAll(
        () -> assertTrue(systemErr.getText().contains("keepalive override"), systemErr.getText()),
        // The services still come up, but without the override file layered onto the compose files.
        () -> assertIterableEquals(List.of(
            call(tool, "--file", YML, "up", "--detach", "dev"),
            call(tool, "--file", YML, "exec", "-T", "dev", "/bin/sh"),
            call(tool, "--file", YML, "stop", "dev")), executor.executed()));
  }

  @ParameterizedTest
  @MethodSource("dockerComposeLikeRuntimes")
  @DisplayName("lists the attached service's processes to detect other sessions")
  void processesArguments(final String runtime) {
    final var tool = useRuntime(runtime);
    final var cli = ComposeRuntime.fromAlias(runtime).cli();
    assertIterableEquals(call(tool, "--file", YML, "top", "dev"), cli.processesArguments(options));
  }

  private String useRuntime(final String runtime) {
    options.runtime = ComposeRuntime.fromAlias(runtime);
    return options.runtime.aliases()[0];
  }

  private List<String> call(final String runtime, final String... args) {
    final var cli = "docker".equalsIgnoreCase(runtime)
        ? Stream.of(runtime, "compose")
        : Stream.of(runtime);
    return Stream.concat(cli, Arrays.stream(args)).toList();
  }

}
