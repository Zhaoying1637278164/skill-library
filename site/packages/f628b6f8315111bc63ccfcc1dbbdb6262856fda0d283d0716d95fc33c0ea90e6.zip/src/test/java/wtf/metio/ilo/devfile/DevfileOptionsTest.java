/*
 * SPDX-FileCopyrightText: The ilo Authors
 * SPDX-License-Identifier: 0BSD
 */
package wtf.metio.ilo.devfile;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import wtf.metio.ilo.test.ClassTests;

import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("DevfileOptions")
class DevfileOptionsTest {

  @Test
  @DisplayName("has default constructor")
  void shouldHaveDefaultConstructor() {
    assertDoesNotThrow(() -> ClassTests.hasDefaultConstructor(DevfileOptions.class));
  }

  @ParameterizedTest
  @DisplayName("has public fields")
  @ValueSource(strings = {
      "runtime",
      "runtimeOptions",
      "runtimePullOptions",
      "runtimeRunOptions",
      "runtimeBuildOptions",
      "runtimeCleanupOptions",
      "removeImage",
      "component",
      "pull",
      "debug",
      "locations"
  })
  void shouldHavePublicProperty(final String field) throws NoSuchFieldException {
    final var runtime = DevfileOptions.class.getDeclaredField(field);
    assertTrue(Modifier.isPublic(runtime.getModifiers()));
  }

  @ParameterizedTest
  @DisplayName("returns debug value")
  @ValueSource(booleans = {true, false})
  void shouldReturnDebugValue(final boolean value) {
    final var options = new DevfileOptions();
    options.debug = value;
    assertEquals(value, options.debug());
  }

}
