# Headset for Claude Code

Bring your [Headset](https://headset.io) cannabis data into Claude Code. Ask about sales, inventory, store performance, and market trends in plain language and get answers sourced straight from your Headset account. Access is read-only — Claude can query your data but never change it.

## Installation

```
/plugin marketplace add Headset/claude-code
/plugin install headset@Headset
```

## Setup

On first use, Claude Code will prompt you to authenticate with Headset via OAuth. No API keys to manage — once you approve access, you're connected.

## Usage

Just ask, for example:

```
Show me sales totals for the last 30 days
```

```
List my stores
```

```
What were my top-selling products last week?
```

```
Compare inventory levels across all my stores
```

## Uninstall

```
/plugin uninstall headset
```

## Support

Questions or issues: support@headset.io
