# Development mechanics

The acquisition-style DAG models stabilized operations for supported development assets. Development timing and funding live in the separate monthly engine and `viewConfig.development`. A stabilized Year 1 is not necessarily the first twelve calendar months of construction or ownership. A returned headline acquisition metric is not proof of monthly development performance.

Read existing `update_development_config` inputs before editing: GSF, predevelopment/construction/lease-up months, preleased percentage, stabilized occupancy, loan and budget configuration. Retain stable budget IDs. `budget_upsert` preserves unrelated lines; `budget` is a complete replacement. Use exact supported basis and distribution values.

Cost bases include total, per GSF, percent of hard cost and percent of costs. The percent-of-costs basis is land + hard + soft cost; do not include the fee itself recursively or infer a broader base without inspecting the engine's current treatment. Reconcile land, hard/soft costs, contingency, financing and carrying costs to the user's source budget. Avoid counting the same TI/LC both here and in operating cash flow.

Advanced configuration can include velocity versus ramp lease-up, loan NOI application, refinancing and equity waterfalls. Flexible JSON is not a guarantee that every guessed field has an effect. Use documented current fields already returned or exposed in the schema, and verify the stored value and resulting available output.

If monthly funding/draw schedules are absent from the MCP response, request a supported Pencil view/export or supplied schedule for that portion of the review. State the limitation explicitly; do not create a monthly schedule that appears to be a Pencil result. A partial budget/timing review remains useful with its scope stated.
