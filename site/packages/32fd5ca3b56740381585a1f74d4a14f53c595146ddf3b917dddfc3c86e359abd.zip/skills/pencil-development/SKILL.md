---
name: pencil-development
description: Build or review a supported ground-up development model in Pencil, including cost budgets, construction timing, lease-up and stabilization. Use for Pencil development feasibility or a development assumption change; hotel and ground-lease development need separate modeling support.
---

# Pencil development

Read [core](references/core.md), [development](references/development.md), [write semantics](references/writes.md), and the matching [property type](references/property-types.md).

1. Resolve the deal and verify its asset class and strategy. Hotel and ground-lease development are outside this release's supported model pairs. Do not disguise those projects as multifamily or relabel acquisition returns as a development model.
2. Inspect current development configuration and the stabilized operating model. Capture land, physical area or unit/capacity counts, cost bases, budget line IDs, predevelopment/construction/lease-up duration, preleasing, debt and exit/refinance timing. Pin dates where supported; flag relative dates that would make reruns drift.
3. Reconcile sources and uses, contingency and fee bases. Identify omitted carrying costs and avoid double-counting financed interest, reserves, tenant improvements or costs already included elsewhere. Keep actual committed costs separate from estimates.
4. For a single budget change use `budget_upsert` with the existing line ID. Use whole `budget` replacement only for a requested full replacement with all lines accounted for. Preserve unrelated configuration. Inspect and use the exact live schema for nested advanced options instead of guessing field names.
5. Read back the configuration and request the available calculated output. Separate stabilized operating Year 1 from development calendar/monthly cash flow. Report peak funding, timing, yield on cost, stabilization and exit economics only when the relevant engine output is actually available. The hosted pricing tool's acquisition-style outputs alone do not establish a complete monthly development result.

Return the supported feasibility conclusion, budget and timeline changes, cost/revenue assumptions, funding gaps and output limitations. If a required schedule is unavailable through the host's tools, identify the missing Pencil view/export or source needed and continue with a clearly labeled partial review. Do not synthesize server-calculated monthly draws or development IRR.
