# Source imports and classification

## Residential rent roll

`import_rent_roll` creates a complete snapshot; activating it replaces the active rent-roll basis. Do not import an excerpt as a patch. Read current state and reconcile the full inventory first. Use `deal_id`, `rent_roll.rows`, source date and `set_active` according to the actual schema and user intent.

Resident names and resident contact identifiers are not accepted. If the supplied residential source contains them, ask the user for a deidentified replacement before invoking the import. Do not silently strip identifiers and submit the rest, including when a name is described as synthetic. Unit identifiers and commercial business tenant names serve different purposes and are not residential resident identity fields.

The remote row allowlist includes unit number/type, area, in-place/market rent, vacancy, lease/move dates and monthly concessions. Preserve occupied/vacant distinctions and zero-versus-missing rents. The remote JSON schema does not currently expose a subsidy field. Do not discard housing-assistance amounts or blend them into resident rent without establishing the correct supported mapping. Report the gap or use a verified source-import capability that preserves it.

## T-12

`import_t12` expects monthly `YYYY-MM` entries, not a single annual number relabeled as a month. The schema includes GPI, vacancy loss, concessions, other income, categorized expenses and capex, with optional detailed line items. Losses use positive values in the corresponding loss categories. Do not sum detail plus its subtotal. Preserve the original period and account labels for a reviewable mapping. Reconcile EGI, operating expenses and NOI after import, including source rounding differences.

Use `get_t12_line_items` when classification matters. Matching total NOI can conceal offsetting category errors. `reclassify_t12` defaults `write_memory` to true, which can affect later classifications for the organization. Set `write_memory: false` for a repair limited to the current deal. Use stable line IDs when available; a broad `label_contains` match may alter multiple accounts. Only create organization-wide memory when that broader action is intended.

## Commercial sources

Read the lease entries, lease dates, rentable area, charge-code definitions and recovery terms before proposing lease changes. Contract rent, CAM/NNN charges, free rent and one-time TI/LC are different cash-flow items. A source charge roll may have several rows for one tenant; do not create duplicate leases from charge rows. Proposed lease imports are not approved merely because the user asked to inspect them.
