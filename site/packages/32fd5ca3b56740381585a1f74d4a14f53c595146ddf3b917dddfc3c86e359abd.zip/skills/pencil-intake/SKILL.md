---
name: pencil-intake
description: Prepare user-supplied rent rolls, T-12s and property facts for a Pencil commercial real estate deal; reconcile sources and import authorized, deidentified data. Use for Pencil deal setup or intake, not property search or a standalone spreadsheet unrelated to Pencil.
---

# Pencil intake

Turn supplied documents into a traceable starting model. Read [core](references/core.md), [imports](references/imports.md) and the relevant section of [property types](references/property-types.md).

1. Resolve the workspace, target deal and acquisition/development strategy. If the user wants a new deal, collect only missing creation fields and check that the asset/strategy pair is supported. Inspect an existing deal before changing it. A property address alone is not a rent roll or operating statement.
2. Inventory the available sources with their as-of dates and granularity. Identify the unit/area/capacity basis, monthly versus annual amounts, actual versus market rents, occupied versus vacant units, and whether a T-12 is really twelve months. Keep reported values distinct from user assumptions. Ask for missing critical inputs in one concise group; continue source reconciliation that is independent of them.
3. Follow the import rules before constructing a payload. A residential roll containing resident identifiers requires a deidentified replacement from the user. Do not silently redact and import it. A one-unit excerpt cannot replace the full active rent roll. A local path cannot be read by the hosted MCP.
4. Reconcile unit counts, occupied/vacant counts, total area, scheduled and collected rent, concessions, and T-12 monthly/category totals. Explain unresolved gaps and unsupported fields before an import would lose information. For commercial properties, use the lease tools for revenue terms; do not force commercial leases into a residential roll.
5. Carry out the user's authorized import with the actual tool schema and the intended active-snapshot setting. After each write inspect the result and read back the active source/model summary. Recompute pricing only after the inputs are verified. Stop dependent writes on an error or unresolved mismatch.

Return a compact intake ledger: source and date, destination, reconciliation result, completed changes, and missing inputs. Link to the deal when returned by Pencil. Report imported versus inferred information explicitly. Do not claim an underwriting is complete merely because an import succeeded.
