---
name: pencil-review
description: Audit an existing Pencil commercial real estate model against its sources, reconcile returns and identify material underwriting errors. Use for Pencil model QA, diligence, discrepancy investigation, targeted operating-assumption fixes or an investment-committee review; inspection alone does not authorize repairs.
---

# Pencil model review

Read [core](references/core.md) and the matching [property type](references/property-types.md). Read [imports](references/imports.md) for source discrepancies and [write semantics](references/writes.md) for requested repairs.

1. Resolve the target deal. Read current inputs, model summary and fresh pricing. Identify historical/source, model-year and exit/forward periods before comparing numbers. Note missing source documents rather than inventing provenance.
2. Reconcile the material paths: source rent and occupancy to forward revenue; T-12 line categories to expenses; tax facts to tax assumptions; NOI to cap value; capex/leasing costs to cash flow; debt to equity cash flow; and exit value to its stated forward NOI/cap rate. Tie out on consistent units, periods and denominators. A historical cap rate and a forward cap rate can both be correct.
3. Inspect property-specific omissions and concentration risks. A T-12 total that ties does not prove its classifications are correct. A clean tool response does not prove the user's inputs are credible. Distinguish a reproducible error, an unsupported assumption, a disclosed limitation, and an investment judgment.
4. Rank findings by their potential effect on the decision, supported by a source reference or an exact returned model field. Explain the observed value, expected treatment and consequence. Quantify impact only when calculated or independently reproducible with a stated method. Avoid arbitrary severity for missing cosmetic detail.
5. An inspection request is read-only. If the user also authorizes repairs, correct only the agreed scope, preserve schedules and IDs, then re-read the inputs and pricing. For a deal-specific T-12 reclassification set `write_memory: false`; organization-wide learned classification requires that broader intent. If a batch partly succeeds, report the partial state before attempting a targeted repair.

Deliver findings first, then the reconciled headline metrics, completed repairs if any, and remaining evidence gaps. Include enough field/source detail for another underwriter to reproduce each material finding. Say which workflows and property outputs were actually reviewed; do not describe a partial review as a fully validated model.
