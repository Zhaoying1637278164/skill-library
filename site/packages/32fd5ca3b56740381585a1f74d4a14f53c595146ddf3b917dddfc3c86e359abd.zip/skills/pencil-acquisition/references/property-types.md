# Property model selection

Choose by the deal's actual asset class and strategy. This is model guidance, not market benchmarks. Support listed here means a registered Pencil model pair; it does not mean every specialized output is exposed by the hosted MCP.

| Asset class | Acquisition | Development | Operating basis |
| --- | --- | --- | --- |
| `multifamily` | Yes | Yes | Units, monthly rent, expenses per unit/year |
| `retail` | Yes | Yes | Commercial leases, SF, annual rent per SF |
| `industrial` | Yes | Yes | Commercial leases, SF, annual rent per SF |
| `office` | Yes | Yes | Commercial leases, SF, annual rent per SF |
| `data_center` | Yes | Yes | Commercial engine with IT-load kW in area fields |
| `self_storage` | Yes | Yes | Storage units/sizes, monthly rent, economic vacancy |
| `build_to_rent` | Yes | Yes | Homes as units, monthly rent |
| `ground_lease` | Yes | No | Dedicated leased-fee valuation engine |
| `hotel` | Yes | No | Dedicated annual USALI operating engine |

## Multifamily

Reconcile physical occupancy to economic vacancy; distinguish in-place, market and renovated rents. Preserve concession timing and renovation downtime. Reconcile T-12 tax/insurance to forward assumptions with source dates. Capital improvements belong in capital cash flow rather than silently reducing operating expenses. A residential import needs a complete deidentified roll.

## Retail

Use tenant leases and commencement/expiry dates. Review contractual increases, renewal/rollover, downtime, free rent, recoveries and tenant concentration. Anchor/co-tenancy or percentage-rent provisions need their actual source and supported model treatment; do not assume the engine handles every clause. Separate reimbursements from base rent and TI/LC from NOI.

## Industrial

Underwrite area, lease structure, rollover and downtime from the lease evidence. Distinguish triple-net and landlord-paid expenses. Tenant improvements, leasing commissions and building capital are separate. Property facts such as power or clear height are diligence inputs, not permission to fabricate rent premiums.

## Office

Check lease-by-lease expirations, mark-to-market assumptions, renewal probability, free rent, TI/LC and recovery stops. Contractual occupancy is not the same as economic rent collection. Preserve suite/lease IDs and pin the analysis date when supported. Stress discussion should address rollover capital and timing, not just vacancy percentage.

## Data center

Pencil uses the commercial model with IT load in kW stored in fields whose internal names contain `sf`. A lease quoted at $/kW/month converts to $/kW/year by multiplying by 12. For example, 1,000 kW at $150/kW/month is $1.8m annual base rent before other adjustments. In `add_commercial_lease`, that means `square_feet: 1000` and total `base_rent_monthly: 150000`. An annual per-capacity field such as `market_rent_psf_annual` would use 1800 only when that is the intended market-rent assumption. Do not put an annual total or a per-kW rate in the monthly-total field. Do not substitute physical building SF or mix MW and kW. Keep power availability, contracted versus energized capacity, ramp timing and power-cost recovery distinct. Unsupported service/redundancy clauses are evidence gaps, not invented cash flows.

## Self-storage

Storage sizes are unit types. Distinguish physical and economic occupancy, discounts and achieved rent from advertised street rent. The engine is unit-based; do not treat one square foot as one rentable unit. State whether ancillary income and management fees are source actuals or assumptions. Avoid annualizing a seasonal month as a T-12 without labeling it.

## Build-to-rent

Homes are units with monthly rents. Acquisition uses the standard unit model. Development needs horizontal/site and vertical/home costs, delivery timing and property-tax phase-in. Do not apply a multifamily cost per building SF to a per-home budget without a supported conversion and supplied area.

## Ground lease

The dedicated ground-lease engine values the leased fee, including contractual rent, escalations, term, discounting and reversion assumptions. Distinguish leased-fee from leasehold and fee-simple interests. Do not substitute ordinary property NOI divided by cap rate for the ground-lease valuation. Ground-lease development is not a supported pair in this release.

## Hotel

Use `viewConfig.hotel` and `update_hotel_config` for the USALI operating model. Revenue depends on available room nights, occupancy and ADR, plus supported departmental revenue. Track departmental/undistributed expenses, fee bases and FF&E reserves in the correct cascade. Use supplied operating evidence and agreements for those ratios; do not fill an explanation or model with an unsourced typical expense or fee percentage. Do not model hotel rooms as twelve monthly apartment rents or call an acquisition IRR a development result. This release supports annual acquisitions, not ground-up hotel development, monthly hotel cash flow or mid-hold hotel refinancing.
