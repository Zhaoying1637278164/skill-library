# Writes that need particular care

| Operation | Preserve this behavior |
| --- | --- |
| `update_assumption` | Use a returned editable node ID. `year` is one-based. Omitting it on an annual node writes every modeled year, including the forward year, flattening the existing schedule. A Year 2 edit needs `year: 2`. |
| Amount units | Standard operating expense nodes generally use dollars/unit/year; commercial ones use dollars/SF/year, or dollars/kW/year for data centers. Standard other-income inputs can be dollars/unit/month. Check the actual node's unit before converting a property total. |
| `update_tax_record` vs `update_property_tax` | The former stores assessor facts; the latter changes modeled tax/abatement configuration. Do not report one as a change to the other. |
| `update_valuation_record` | Stores the user's judgment bands, not a recalculated appraisal. Dollar bands must satisfy strong <= target <= reach. Null clears a field. |
| `update_loan` | Rates, LTV and fees use decimals. Choose amount OR LTV. Use the intended slot. `interest_only: true` means full-term IO; a partial IO period uses its supported month field. Read the loan back. |
| Commercial leases | Use the existing `entry_id` when available, not a guessed suite match. Null can clear fields. Add/update/delete and approval of proposed imports are separate actions. |
| Commercial configuration | Preserve analysis start date, existing MLA profile IDs and valuation mode. Recoveries offset eligible expenses and must not be double-counted in commercial NOI allocation. |
| Renovations and capital | Generated renovation phases can replace the prior generated schedule; other-capital schedule writes can replace the entire schedule. Inspect the existing schedule and intended scope. |
| Development budget | `budget` replaces all lines; `budget_upsert` merges by existing line ID. Use upsert for an isolated cost change. |
| Waterfall | Replacing class, fee or tier arrays can remove existing economics. Read the whole configuration and include only an intentional complete replacement. |

Use the live descriptions and input schemas for required nested fields. Never submit a guessed deep key merely because a schema has a flexible object. If a batch is not atomic, retain each operation's outcome and re-read partial state before any targeted retry.
