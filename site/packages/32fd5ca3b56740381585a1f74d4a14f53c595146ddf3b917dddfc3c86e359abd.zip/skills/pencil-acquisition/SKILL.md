---
name: pencil-acquisition
description: Underwrite an acquisition in the user's Pencil workspace, reconcile operating assumptions and report current returns, risks and decision inputs for commercial real estate. Use for a Pencil acquisition or buy-box assessment, not public stocks, personal mortgages or finding listings.
---

# Pencil acquisition

Read [core](references/core.md) and the matching [property type](references/property-types.md). Read [write semantics](references/writes.md) if the user requests model changes.

1. Resolve the deal and read its current inputs with `get_deal` and `get_model_summary`. Identify the asset class, unit basis, analysis date, source dates and hold period. If intake is incomplete, identify the consequential missing inputs and finish the analysis that the available evidence supports.
2. Reconcile historical income to the current rent roll or leases and the forward model. Explain vacancy, concessions, bad debt, recovery income, nonrecurring income, management fees, reserves and capex on the basis appropriate to this property. Distinguish assessor records from modeled property tax. Read line items when aggregate T-12 categories appear misleading.
3. For requested assumption changes, name the target fields, units and affected years. Preserve annual schedules and existing lease identifiers. Apply already authorized changes without asking for permission again; clarify only unresolved targets, values or replacement scope. Read back modified inputs before refreshing returns.
4. Fetch `get_pricing` for the current base case. Report purchase price, source/forward NOI with explicit periods, leverage, levered and unlevered returns, equity multiple, annual debt coverage, hold period and exit assumptions when returned. Prefer fresh pricing to saved or broker-quoted returns. An unlabeled single NOI is insufficient when historical, Year 1 and exit figures differ.
5. Evaluate the user's investment criteria. Identify which source gaps or assumptions could reverse the conclusion. Discuss downside drivers without inventing a computed sensitivity grid. A grid requires an available scenario calculation capability or authorized scenario writes with restoration; otherwise say which comparisons remain uncomputed.

Deliver a concise investment assessment: fit to the user's criteria, current model outputs, the main income/expense bridge, material risks with supporting evidence, and decisions still needed. Do not invent a market cap rate, lender quote, rent comp or universal return hurdle. If no criteria were provided, report the economics and tradeoffs rather than declaring that the deal is a buy.
