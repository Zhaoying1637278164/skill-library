---
name: pencil-capital-structure
description: Analyze or update debt, refinancing, equity classes and waterfalls for a deal in Pencil; distinguish property, levered and investor returns. Use for a Pencil financing or capital-stack task, not personal borrowing, securities trading or generic loan shopping.
---

# Pencil capital structure

Read [core](references/core.md), [capital](references/capital.md), [write semantics](references/writes.md), and the relevant [property type](references/property-types.md).

1. Resolve the deal and read its operating model, loan slots, capital events and waterfall configuration. Establish whether the user wants analysis, a what-if, or a persistent edit. Honor financing terms already supplied; ask only for consequential missing terms.
2. Identify loan amount or LTV and its value basis, rate type and units, amortization, maturity, interest-only period, fees and refinance/sale timing. Separate a published benchmark from a lender's spread and actual quote. Do not silently choose either loan amount or leverage when the user's inputs conflict.
3. Reconcile available debt coverage and equity funding. Explain amortization, balloon exposure and refinancing assumptions. Underwrite refinancing against the stated forward NOI/value and timing, not an unexplained reuse of today's purchase-price LTV.
4. For an authorized change use the intended existing slot and exact schema. Preserve unrelated loans. For waterfalls read the whole current configuration before an operation that replaces classes, tiers or fees. Confirm unresolved economic choices, including contributions, priority, pref compounding, catch-up and promote splits. Do not impose a default sponsor waterfall.
5. Read back all changed terms and recompute the outputs the server exposes. Distinguish unlevered asset returns, levered deal returns, LP net returns and GP proceeds. If the relevant investor/monthly output is unavailable, say so; do not infer it from the headline levered IRR.

Return a before/after comparison when there was a change, financing terms with units and dates, available coverage and returns, and unresolved funding or refinancing risks. A what-if without authorized temporary writes stays an analytical discussion unless a read-only scenario tool is available. Never report a live base case as restored until its inputs and pricing have been checked.
