# Pencil Underwriting 1.1.0

Five guided workflows for commercial real estate underwriting in Pencil:

- **Intake:** reconcile source documents and import complete, deidentified inputs.
- **Acquisition:** review current economics, assumptions and investment criteria.
- **Development:** review supported budgets, timelines and stabilization.
- **Capital structure:** review debt and distinguish deal returns from investor returns.
- **Model review:** audit a model and perform specifically authorized repairs.

Guidance covers multifamily, retail, industrial, office, data centers, self-storage, build-to-rent, ground leases and hotels. It follows the supported Pencil model pairs; hotel and ground-lease development are not supported.

## Connect to Pencil

A Pencil account is required. Authenticate through the host's OAuth connection to `https://pencil.deals/api/mcp`. Both plugin manifests use this one hosted MCP. These files contain no local MCP executable or local file-import commands.

Claude Code can load this directory for a session with `claude --plugin-dir /absolute/path/to/pencil-underwriting`. Example: “Review a deal in my Pencil workspace and explain the assumptions that drive its returns.” The host can select the relevant skill from the request.

OpenAI receives the same skills through the MCP import protocol when the publisher scans a new submission. Availability in a directory depends on that platform's review and supported host features; this repository alone does not establish an approved listing.

## What the workflows do

The skills guide source reconciliation, model selection, units, authorized changes and readback. Calculations and saved changes use the actual Pencil tools. They do not turn unavailable monthly, sensitivity or LP-return output into a supported feature.

This package is generated from Pencil's maintained skill library. It includes five self-contained skill directories, OpenAI and Claude manifests, and one remote MCP configuration. No customer data, credentials, application backend source or hooks are included.

[Product](https://pencil.deals) · [Privacy policy](https://pencil.deals/privacy) · [Service terms](https://pencil.deals/terms)

For support or a security issue, contact support@pencil.deals. Keep credentials and customer data out of public issue reports.

## License

Proprietary. Copyright 2026 PENCIL LLC. All rights reserved. The source is publicly available for inspection; it is not offered under an open-source license. See [LICENSE](LICENSE) for permitted use with Pencil and distribution restrictions.
