---
description: Check that flowy's dependencies, config and guard hooks are actually working
---

Diagnose the flowy install. Report only what you actually checked, with the evidence — flowy's own
verified-only rule applies to flowy itself.

Run the checks, then print one table: **check · result · fix if broken**. Do not fix anything
without asking first.

## 1 — Webflow MCP connected

Call `webflow_guide_tool` once, then `data_sites_tool > list_sites` with `limit: 1`.

- Both succeed → connected; report how many sites the account holds if the response says.
- Fails → the Webflow MCP server is not connected. flowy cannot do anything without it. Point at
  the Webflow MCP setup, do not attempt to install it.

## 2 — Chrome extension connected

Load the browser tools in one batched `ToolSearch`, then call `tabs_context_mcp`.

- Succeeds → connected. Note which browser the tabs appear to be in if that is visible.
- Fails → the Designer hand is unavailable. flowy still works for structure, CMS and audits, but
  every visual-judgment route and house rule #13's escalation path are closed. Say that plainly
  rather than reporting a clean bill of health.

## 3 — Config present and parseable

Read `~/.claude/flowy.config.md`.

- Present → echo the four values.
- Absent → **not an error.** Report the defaults in use (`Google Chrome` / `per-brand` / `none` /
  `required`) and mention `/flowy:setup`.

## 4 — The configured browser actually exists

```bash
open -Ra "<browser from config, or Google Chrome>" && echo "resolves"   # macOS; on Linux use: command -v <binary>; on Windows skip this probe
```

If it does not resolve, that is the single most likely cause of "the Designer tools time out but
the data tools work." Say so.

## 5 — Guard hooks present and behaving

The hooks are the part of flowy that has teeth, so test them rather than assuming. Find the plugin
root — the directory containing `hooks/scripts/` — then run each guard against a synthetic payload
and check the decision:

```bash
D=<plugin-root>/hooks/scripts
echo '{"tool_input":{"actions":[{"label":"p","publish_site":{"site_id":"x"}}]}}' | python3 $D/webflow-publish-guard.py
echo '{"tool_input":{"actions":[{"label":"l","list_sites":{}}]}}'               | python3 $D/webflow-publish-guard.py
echo '{}'                                                                      | python3 $D/no-window-resize-guard.py
echo '{"tool_input":{"actions":[{"label":"d","delete_asset":{"asset_id":"x"}}]}}' | python3 $D/webflow-destructive-guard.py
```

Expected, in order: `ask` · no output (reads pass through) · `deny` · `ask`.

Anything else means a guard is not doing its job — report which one and what it returned instead.
A publish guard that stays silent on a publish payload is the most serious possible failure here;
do not soften it.

Then check the matchers actually reach this session's tools: read the `matcher` values in
`<plugin-root>/hooks/hooks.json` and test each regex against the full name of your own connected
Webflow MCP tools (you know your tool names; the prefix is `mcp__<server>__` and the server name is
whatever this install called it). A guard whose matcher matches nothing in the live session will
never fire regardless of how well its script behaves — report that as a broken guard, name the
matcher and the live tool name it failed to match.

## 6 — Python available

The hooks are Python 3. `python3 --version`. If missing, every guard silently does nothing — which
means flowy's hard rules are documentation only. Report that as a failure, not a warning.

## Report

End with a one-line verdict: fully working, working with the Designer hand missing, or broken —
and if broken, the single next action. No caveats appended after the verdict.
