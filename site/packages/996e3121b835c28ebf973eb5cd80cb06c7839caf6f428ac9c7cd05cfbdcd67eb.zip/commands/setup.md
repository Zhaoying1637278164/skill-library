---
description: Create or update the flowy config at ~/.claude/flowy.config.md
argument-hint: "[optional: browser name, e.g. Comet]"
---

Set up flowy's four settings and write them to `~/.claude/flowy.config.md`.

That path is deliberate — it is the user's own directory, so the config survives plugin updates.
Never write settings into the plugin directory; it is replaced wholesale on upgrade.

## Steps

**1. Read the current state.** If `~/.claude/flowy.config.md` already exists, read it and show the
current values. This is an update, not a fresh start — carry existing values forward as the defaults
and only change what the user changes.

**2. Detect the browser rather than asking blindly.** The `claude-in-chrome` extension is installed
in exactly one browser and it is frequently not Google Chrome. Check which candidates are actually
installed:

```bash
for b in "Google Chrome" "Comet" "Arc" "Brave Browser" "Microsoft Edge" "Google Chrome Canary"; do
  open -Ra "$b" 2>/dev/null && echo "installed: $b"   # macOS probe; elsewhere ask the user directly
done
```

If `$ARGUMENTS` named a browser, use it. If exactly one candidate is installed, propose it. If
several are, ask which one holds the extension — installed is not the same as hosting the extension,
and only the user knows.

**3. Ask about the other three**, briefly and with the defaults visible. Do not interrogate; a user
who wants all defaults should be able to say so in one reply.

- `fonts` — `per-brand` (default), or a pinned house typeface like `Inter`
- `board` — `none` (default), `Notion`, `Linear`, `Asana`, `Trello`, `Jira`
- `approval` — `required` (default, recommended) or `trusted`

Explain `approval` in one line if they ask: `required` means flowy presents a plan and waits before
any Webflow write, because Webflow writes are frequently not undoable.

**4. Write the file** in exactly this format — flowy parses the fenced block:

````markdown
# flowy config

```
browser: <value>
fonts: <value>
board: <value>
approval: <value>
```
````

**5. Verify by reading it back**, and confirm the browser resolves:

```bash
cat ~/.claude/flowy.config.md   # then on macOS: open -Ra "<browser value>" && echo "browser OK"
```

Report the four values and the fact that they survive plugin updates. Do not offer to publish
anything, and do not start Webflow work unless asked — this command only writes config.

Full reference for every setting: `skills/flowy/setup.md`.
