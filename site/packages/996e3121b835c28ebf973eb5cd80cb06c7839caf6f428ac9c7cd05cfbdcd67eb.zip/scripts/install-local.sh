#!/bin/sh
# Sync this repo's skills and hook scripts into the live ~/.claude setup.
#
# The repo is the single source of truth; ~/.claude holds the deployed
# copies Claude Code actually loads. Run this after editing anything under
# skills/ or hooks/scripts/ — never edit the ~/.claude copies directly.
#
# This is the copy-based dev-loop alternative to installing the plugin
# (/plugin marketplace add yaroshidi/flowy). Don't use both at once, or the
# skills will be listed twice and the guard hooks will prompt twice.
set -e
REPO="$(cd "$(dirname "$0")/.." && pwd)"

for s in flowy flowy-manual flowy-verify; do
  rsync -a --delete --exclude '.DS_Store' "$REPO/skills/$s/" "$HOME/.claude/skills/$s/"
  echo "synced  ~/.claude/skills/$s"
done

for h in "$REPO"/hooks/scripts/*.py; do
  cp "$h" "$HOME/.claude/hooks/"
  echo "synced  ~/.claude/hooks/$(basename "$h")"
done

if ! grep -q "webflow-destructive-guard" "$HOME/.claude/settings.json" 2>/dev/null; then
  echo "NOTE: hook scripts are copied but not registered — add the PreToolUse/"
  echo "      PostToolUse entries from hooks/hooks.json to ~/.claude/settings.json,"
  echo "      pointing at ~/.claude/hooks/ instead of \${CLAUDE_PLUGIN_ROOT}."
fi
echo "done — restart or reopen Claude Code sessions to pick up skill changes"
