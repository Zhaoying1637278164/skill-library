#!/usr/bin/env python3
"""Validate the flowy plugin: manifests, skills, links, hooks.

Run from anywhere:  python3 scripts/validate.py

Checks structure and behaviour that can be verified without a Claude Code install:
manifests parse, skill frontmatter meets the spec, every relative link resolves, no
file is orphaned, the hook scripts compile, and each guard returns the right
decision for a representative payload. Exits non-zero on any failure so it can gate
a commit or CI run.

What it cannot check: that Claude Code loads the plugin, that the MCP servers are
connected, or that the hooks fire in a real session. `/flowy:doctor` covers those
from inside a session.
"""
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAILURES = []
CHECKS = 0


def check(ok, label, detail=""):
    global CHECKS
    CHECKS += 1
    if ok:
        print("  \033[32mok\033[0m   {}".format(label))
    else:
        print("  \033[31mFAIL\033[0m {}{}".format(label, "  — " + detail if detail else ""))
        FAILURES.append(label)
    return ok


def section(name):
    print("\n{}".format(name))


def read(path):
    with open(os.path.join(ROOT, path), encoding="utf-8") as fh:
        return fh.read()


# ---------------------------------------------------------------- manifests
section("Manifests")

try:
    plugin = json.loads(read(".claude-plugin/plugin.json"))
    check(True, "plugin.json parses")
    check(bool(plugin.get("name")), "plugin.json has name")
    check(bool(plugin.get("version")), "plugin.json has version")
    check(bool(plugin.get("description")), "plugin.json has description")
except Exception as exc:  # noqa: BLE001
    plugin = {}
    check(False, "plugin.json parses", str(exc))

try:
    market = json.loads(read(".claude-plugin/marketplace.json"))
    check(True, "marketplace.json parses")
    names = [p.get("name") for p in market.get("plugins", [])]
    check(plugin.get("name") in names,
          "marketplace lists the plugin",
          "plugins={}".format(names))
    versions = {p.get("name"): p.get("version") for p in market.get("plugins", [])}
    check(versions.get(plugin.get("name")) == plugin.get("version"),
          "marketplace version matches plugin.json",
          "{} vs {}".format(versions.get(plugin.get("name")), plugin.get("version")))
except Exception as exc:  # noqa: BLE001
    check(False, "marketplace.json parses", str(exc))

# -------------------------------------------------------------------- hooks
section("Hooks")

try:
    hooks = json.loads(read("hooks/hooks.json"))
    check(True, "hooks.json parses")
    scripts = []
    for event, matchers in hooks.get("hooks", {}).items():
        for matcher in matchers:
            for hook in matcher.get("hooks", []):
                cmd = hook.get("command", "")
                found = re.search(r'\$\{CLAUDE_PLUGIN_ROOT\}/(\S+?)"', cmd)
                if found:
                    scripts.append(found.group(1))
    check(bool(scripts), "hooks reference scripts via ${CLAUDE_PLUGIN_ROOT}")
    # The mcp__<server>__ prefix is user-chosen at MCP setup, not fixed. Every
    # Webflow matcher must fire no matter what the user named the server, or the
    # guards are silently dead on their install.
    known_server_names = ["webflow", "Webflow", "claude_ai_Webflow", "webflow-mcp"]
    for event, matchers in hooks.get("hooks", {}).items():
        for matcher in matchers:
            pattern = matcher.get("matcher", "")
            if "ebflow" not in pattern:
                continue
            probe = "data_sites_tool" if "data_sites_tool" in pattern else "data_assets_tool"
            portable = all(
                re.search(pattern, "mcp__{}__{}".format(name, probe))
                for name in known_server_names
            )
            check(portable, "{} Webflow matcher fires for any server name".format(event))
    for rel in scripts:
        check(os.path.exists(os.path.join(ROOT, rel)), "hook script exists: {}".format(rel))
except Exception as exc:  # noqa: BLE001
    check(False, "hooks.json parses", str(exc))

hook_dir = os.path.join(ROOT, "hooks", "scripts")
for name in sorted(os.listdir(hook_dir)) if os.path.isdir(hook_dir) else []:
    if not name.endswith(".py"):
        continue
    path = os.path.join(hook_dir, name)
    # compile() in-process rather than py_compile — no __pycache__ side effects.
    try:
        compile(open(path, encoding="utf-8").read(), path, "exec")
        check(True, "compiles: {}".format(name))
    except SyntaxError as exc:
        check(False, "compiles: {}".format(name), str(exc))

# ------------------------------------------------------------ hook behaviour
section("Hook behaviour")

PUBLISH = os.path.join(hook_dir, "webflow-publish-guard.py")
RESIZE = os.path.join(hook_dir, "no-window-resize-guard.py")
DESTRUCT = os.path.join(hook_dir, "webflow-destructive-guard.py")


def decision(script, payload):
    out = subprocess.run([sys.executable, script], input=payload,
                         capture_output=True, text=True).stdout.strip()
    if not out:
        return None
    try:
        return json.loads(out)["hookSpecificOutput"]["permissionDecision"]
    except Exception:  # noqa: BLE001
        return "UNPARSEABLE"


CASES = [
    (PUBLISH, '{"tool_input":{"actions":[{"label":"p","publish_site":{"site_id":"x"}}]}}',
     "ask", "publish_site asks"),
    (PUBLISH, '{"tool_input":{"actions":[{"label":"p","publish_site":{"site_id":"x","pageId":"y"}}]}}',
     "ask", "single-page publish asks"),
    (PUBLISH, '{"tool_input":{"actions":[{"label":"a","get_site":{}},{"label":"b","publish_site":{}}]}}',
     "ask", "publish hidden in a batch asks"),
    (PUBLISH, '{"tool_input":{"actions":[{"label":"l","list_sites":{}}]}}',
     None, "list_sites passes through"),
    (PUBLISH, 'not json {publish_site}',
     "ask", "malformed payload with a publish FAILS SAFE"),
    (PUBLISH, 'not json {list_sites}',
     None, "malformed payload without a publish passes through"),
    (RESIZE, '{}', "deny", "resize_window denies"),
    (DESTRUCT, '{"tool_input":{"actions":[{"label":"d","delete_asset":{"asset_id":"x"}}]}}',
     "ask", "delete_asset asks"),
    (DESTRUCT, '{"tool_input":{"actions":[{"label":"c","compress_assets":{}}]}}',
     "ask", "compress_assets asks"),
    (DESTRUCT, '{"tool_input":{"actions":[{"label":"f","create_asset_folder":{}}]}}',
     "ask", "create_asset_folder asks"),
    (DESTRUCT, '{"tool_input":{"actions":[{"label":"u","unregister_component":{}}]}}',
     "ask", "unregister_component asks"),
    (DESTRUCT, '{"tool_input":{"actions":[{"label":"l","list_assets":{"site_id":"x"}}]}}',
     None, "list_assets passes through"),
    (DESTRUCT, 'garbage delete_asset garbage',
     "ask", "malformed payload with a delete FAILS SAFE"),
]

for script, payload, expected, label in CASES:
    got = decision(script, payload)
    check(got == expected, label, "expected {!r}, got {!r}".format(expected, got))

# ------------------------------------------------------------------- skills
section("Skills")

skills_dir = os.path.join(ROOT, "skills")
skill_names = sorted(d for d in os.listdir(skills_dir)
                     if os.path.isdir(os.path.join(skills_dir, d)))
check(bool(skill_names), "skills/ contains skills")

for name in skill_names:
    rel = os.path.join("skills", name, "SKILL.md")
    if not check(os.path.exists(os.path.join(ROOT, rel)), "{}: has SKILL.md".format(name)):
        continue
    text = read(rel)
    match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not check(match is not None, "{}: has YAML frontmatter".format(name)):
        continue
    fm = match.group(1)
    fields = dict(re.findall(r"^(\w[\w-]*):\s*(.*)$", fm, re.M))
    check(len(fm) <= 1024, "{}: frontmatter <=1024 chars".format(name), "{} chars".format(len(fm)))
    check(re.fullmatch(r"[a-zA-Z0-9-]+", fields.get("name", "")) is not None,
          "{}: name is letters/numbers/hyphens".format(name), fields.get("name", ""))
    check(fields.get("name") == name, "{}: frontmatter name matches directory".format(name),
          fields.get("name", ""))
    check(bool(fields.get("description")), "{}: has a description".format(name))
    check(fields.get("description", "").startswith("Use "),
          "{}: description starts with 'Use ...'".format(name),
          fields.get("description", "")[:40])

# ----------------------------------------------------------------- commands
section("Commands")

cmd_dir = os.path.join(ROOT, "commands")
declared = plugin.get("commands")
if declared:
    check(os.path.isdir(cmd_dir), "commands/ exists as declared in plugin.json")
for name in sorted(os.listdir(cmd_dir)) if os.path.isdir(cmd_dir) else []:
    if not name.endswith(".md"):
        continue
    text = read(os.path.join("commands", name))
    match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not check(match is not None, "{}: has frontmatter".format(name)):
        continue
    fields = dict(re.findall(r"^([\w-]+):\s*(.*)$", match.group(1), re.M))
    check(bool(fields.get("description")), "{}: has a description".format(name))
    check(len(text.split("---", 2)[-1].strip()) > 100,
          "{}: has a body, not just frontmatter".format(name))

# -------------------------------------------------------------------- links
section("Links and reachability")

md_files = []
for base, _dirs, files in os.walk(skills_dir):
    for f in files:
        if f.endswith(".md"):
            md_files.append(os.path.join(base, f))

broken = []
for path in md_files:
    body = open(path, encoding="utf-8").read()
    for target in re.findall(r"\]\(([^)]+?\.md)(?:#[^)]*)?\)", body):
        if target.startswith(("http://", "https://")):
            continue
        if not os.path.exists(os.path.join(os.path.dirname(path), target)):
            broken.append("{} -> {}".format(os.path.relpath(path, ROOT), target))
check(not broken, "every relative .md link resolves", "; ".join(broken[:3]))

orphans = []
for path in md_files:
    base = os.path.basename(path)
    if base == "SKILL.md":
        continue
    referenced = any(base in open(o, encoding="utf-8").read()
                     for o in md_files if o != path)
    if not referenced:
        orphans.append(os.path.relpath(path, ROOT))
check(not orphans, "no orphaned files", "; ".join(orphans))

# --------------------------------------------------------------- hygiene
section("Hygiene")

leaked = []
for path in md_files + [os.path.join(hook_dir, f) for f in os.listdir(hook_dir)
                        if f.endswith(".py")]:
    body = open(path, encoding="utf-8").read()
    for pattern, what in [(r"\b[0-9a-f]{24}\b", "site id"),
                          (r"/Users/", "local path"),
                          (r"(?i)\b(api[_-]?key|secret|password)\s*[:=]", "credential")]:
        if re.search(pattern, body):
            leaked.append("{}: {}".format(os.path.relpath(path, ROOT), what))
check(not leaked, "no site ids, local paths or credentials", "; ".join(leaked[:3]))

cruft = []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in (".git", "__pycache__")]
    for f in files:
        # .DS_Store is Finder noise, gitignored and never shipped; only flag what git would ship.
        if f.endswith(".pyc"):
            cruft.append(os.path.relpath(os.path.join(base, f), ROOT))
check(not cruft, "no .pyc in the tree", "; ".join(cruft[:3]))

# Guards must not be silently unrunnable: the shebang and the interpreter both matter.
bad_shebang = [f for f in os.listdir(hook_dir) if f.endswith(".py")
               and not open(os.path.join(hook_dir, f), encoding="utf-8")
               .readline().startswith("#!")]
check(not bad_shebang, "hook scripts carry a shebang", "; ".join(bad_shebang))

# ------------------------------------------------------ universal bundle
section("Universal bundle")

# The single-skill bundle (claude.ai / Cowork upload, single-file edition) is
# generated from these sources by scripts/build-universal.py. Its rewrite
# table must keep matching the sources: build to a temp dir and verify every
# link still resolves, so a source restructure cannot silently break the zip.
build = subprocess.run(
    [sys.executable, os.path.join(ROOT, "scripts", "build-universal.py"), "--check"],
    capture_output=True, text=True)
check(build.returncode == 0, "universal bundle builds, all links resolve",
      (build.stderr or build.stdout).strip()[:200])

# -------------------------------------------------------------------- done
print("\n" + "-" * 52)
if FAILURES:
    print("\033[31m{} of {} checks FAILED\033[0m".format(len(FAILURES), CHECKS))
    for f in FAILURES:
        print("  - {}".format(f))
    sys.exit(1)
print("\033[32mall {} checks passed\033[0m".format(CHECKS))
sys.exit(0)
