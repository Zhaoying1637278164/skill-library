#!/usr/bin/env python3
"""Compile the three flowy skills into one universally-distributable bundle.

The plugin (skills/flowy, skills/flowy-manual, skills/flowy-verify + hooks +
commands) is the source of truth and the richest install. But two audiences
can't take a plugin:

  - claude.ai / Claude Cowork users, who upload ONE skill as a zip
  - people on other LLMs entirely, who can only paste or attach a file

This script builds both from the sources, so the bundle never drifts:

  dist/flowy/       one merged skill folder (flowy-manual -> manual/,
                    flowy-verify -> verify.md, links rewritten)
  dist/flowy.zip    the folder zipped for claude.ai / Cowork upload
  dist/flowy.md     the whole corpus as a single flat file for any LLM

dist/ is gitignored on purpose: committing a fourth SKILL.md into the repo
would make skills.sh installs offer the merged bundle alongside the three
real skills. Attach dist/flowy.zip to a GitHub Release instead.

Usage:
  python3 scripts/build-universal.py            # build into dist/
  python3 scripts/build-universal.py --check    # build to a temp dir, verify, discard
"""
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "skills"

# The merged skill keeps flowy/SKILL.md as the door; the other two skills
# become reference files inside it. One frontmatter for the whole bundle.
MERGED_FRONTMATTER = """---
name: flowy
description: Use when starting or planning ANY Webflow build, design, styling, layout, CMS, component, or edit task — before choosing tools — and the moment you are about to reach for a Webflow MCP write tool to do VISUAL or detail work. Also use mid-build when you need verified ground truth about Webflow MCP behaviours, traps and schema quirks (manual/), and after every batch of Webflow MCP writes to check they actually landed (verify.md). Owns which-hand routing (Webflow MCP vs a browser-driven Designer), the session lifecycle for new builds and already-built sites, and the paste-first rule for third-party components.
---
"""

# Inserted into SKILL.md right after the marks legend. The plugin enforces
# the non-negotiables with PreToolUse hooks; a standalone skill has no hooks,
# so the same rules must bind as prose.
STANDALONE_SECTION = """
## Running as a standalone skill (no plugin)

This bundle is the flowy plugin's three skills merged into one folder:
the field manual lives in [manual/](manual/README.md), the post-write
checklist in [verify.md](verify.md). If you installed flowy as the Claude
Code plugin instead, its guard hooks and commands cover this section.
Standalone, there are no hooks — these rules bind as instructions:

- **Nothing will block a publish.** Never publish a site, and never offer
  to publish — every domain, including `.webflow.io` staging. Only the
  user's explicit, unprompted request is a publish. [house-rules.md](house-rules.md) #2
- **Nothing will prompt before irreversible operations.** Confirm with the
  user before `delete_asset`, `compress_assets`, `create_asset_folder`,
  `unregister_component` — the Webflow MCP schema itself documents all four
  as unrecoverable.
- **No reminder will fire after writes.** At every batch boundary — before
  claiming any work complete — run [verify.md](verify.md) yourself. A write
  response is never verification.
- **Never resize the browser window** to test responsive; use the Designer
  breakpoint toggles. [house-rules.md](house-rules.md) #3
- **No config file available** (no filesystem, or `~/.claude/flowy.config.md`
  absent)? Use the defaults in [setup.md](setup.md); ask the user only when
  a default fails.
- **No browser-automation tool?** Then the Designer hand is closed: say
  plainly which routes that closes (visual verification, the Interactions
  panel), ask the user to look or act in the Designer, and never report
  🔍-unchecked work as done.
"""

SINGLE_FILE_PREAMBLE = """# flowy — Webflow expertise for AI agents (single-file edition)

This is the complete flowy corpus compiled into one file for tools that
cannot install skills. If your tool supports Agent Skills, prefer the skill
bundle (flowy.zip) or the Claude Code plugin (github.com/yaroshidi/flowy) —
they load sections on demand instead of all at once.

How to read it: `# ── FILE: <path> ──` headers separate the original files.
Start with SKILL.md (the router), consult manual/ entries when a tool
misbehaves, and run verify.md after every batch of Webflow MCP writes.
Marks: ✅ verified on the date given · 🚫 banned or refuses · ⚠️ caution ·
🔍 unchecked.
"""

# (source subdir, dest subdir inside the merged skill, rename map)
GROUPS = [
    ("flowy", ".", {}),
    ("flowy-manual", "manual", {"SKILL.md": "README.md"}),
    ("flowy-verify", ".", {"SKILL.md": "verify.md"}),
]

# Link rewrites per source group, applied longest-pattern-first.
REWRITES = {
    "flowy": [
        ("../flowy-manual/SKILL.md", "manual/README.md"),
        ("../flowy-manual/", "manual/"),
        ("../flowy-verify/SKILL.md", "verify.md"),
        # paths quoted from the manual's perspective, and self-references
        ("../flowy/", ""),
        # link labels that name the old skill path
        ("[flowy-manual/", "[manual/"),
    ],
    "flowy-manual": [
        ("../flowy-verify/SKILL.md", "../verify.md"),
        ("../flowy-manual/SKILL.md", "README.md"),
        ("../flowy-manual/", ""),
        ("../flowy/", "../"),
        ("](SKILL.md", "](README.md"),
    ],
    "flowy-verify": [
        ("../flowy-manual/SKILL.md", "manual/README.md"),
        ("../flowy-manual/", "manual/"),
        ("../flowy-verify/SKILL.md", "verify.md"),
        ("../flowy/", ""),
    ],
}

LINK_RE = re.compile(r"\]\(([^)#\s]+\.md)(#[^)]*)?\)")
LEGEND_MARKER = "Marks used throughout:"


def fail(msg):
    print(f"BUILD FAILED: {msg}", file=sys.stderr)
    sys.exit(1)


def build(out_root: Path):
    skill_dir = out_root / "flowy"
    if skill_dir.exists():
        shutil.rmtree(skill_dir)

    ordered = []  # (bundle-relative path, transformed text) for flowy.md
    for src_name, dest_sub, renames in GROUPS:
        src_dir = SRC / src_name
        if not src_dir.is_dir():
            fail(f"missing source skill {src_dir}")
        for f in sorted(src_dir.rglob("*.md")):
            rel = f.relative_to(src_dir)
            name = renames.get(str(rel), str(rel))
            dest = skill_dir / dest_sub / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            text = f.read_text(encoding="utf-8")
            for old, new in REWRITES[src_name]:
                text = text.replace(old, new)
            if src_name == "flowy" and str(rel) == "SKILL.md":
                text = merge_skill_md(text)
            dest.write_text(text, encoding="utf-8")
            ordered.append((dest.relative_to(skill_dir), text))

    # SKILL.md first in the flat file, then everything else in tree order.
    ordered.sort(key=lambda p: (str(p[0]) != "SKILL.md", str(p[0])))
    verify_links(skill_dir)
    write_single_file(out_root, ordered)
    write_zip(out_root, skill_dir)
    return skill_dir, len(ordered)


def merge_skill_md(text: str) -> str:
    body = re.sub(r"\A---\n.*?\n---\n", "", text, count=1, flags=re.S)
    if body == text:
        fail("flowy/SKILL.md frontmatter not found — source shape changed")
    lines = body.split("\n")
    legend = next((i for i, l in enumerate(lines) if LEGEND_MARKER in l), None)
    if legend is None:
        fail(f"'{LEGEND_MARKER}' marker not found in flowy/SKILL.md — "
             "update LEGEND_MARKER or the insertion anchor")
    lines.insert(legend + 1, STANDALONE_SECTION)
    if len(MERGED_FRONTMATTER) > 1024:
        fail(f"merged frontmatter is {len(MERGED_FRONTMATTER)} chars (max 1024)")
    return MERGED_FRONTMATTER + "\n".join(lines)


def verify_links(skill_dir: Path):
    """Every relative .md link in the bundle must resolve. This is the test
    that the rewrite table still matches the sources."""
    broken = []
    for f in skill_dir.rglob("*.md"):
        for m in LINK_RE.finditer(f.read_text(encoding="utf-8")):
            target = m.group(1)
            if target.startswith(("http://", "https://")):
                continue
            if not (f.parent / target).resolve().is_file():
                broken.append(f"{f.relative_to(skill_dir)} -> {target}")
    if broken:
        fail("broken links after rewrite:\n  " + "\n  ".join(broken))


def write_single_file(out_root: Path, ordered):
    parts = [SINGLE_FILE_PREAMBLE]
    for rel, text in ordered:
        parts.append(f"\n\n---\n\n# ── FILE: {rel} ──\n\n{text}")
    (out_root / "flowy.md").write_text("".join(parts), encoding="utf-8")


def write_zip(out_root: Path, skill_dir: Path):
    zip_path = out_root / "flowy.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(skill_dir.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(out_root))


def main():
    check_only = "--check" in sys.argv
    if check_only:
        with tempfile.TemporaryDirectory() as tmp:
            _, n = build(Path(tmp))
        print(f"ok   universal bundle builds clean ({n} files, all links resolve)")
    else:
        out = ROOT / "dist"
        out.mkdir(exist_ok=True)
        skill_dir, n = build(out)
        size = (out / "flowy.zip").stat().st_size
        print(f"built {skill_dir.relative_to(ROOT)}/ ({n} files)")
        print(f"built dist/flowy.zip ({size:,} bytes) — upload to claude.ai / Cowork")
        print(f"built dist/flowy.md — single file for any LLM")


if __name__ == "__main__":
    main()
