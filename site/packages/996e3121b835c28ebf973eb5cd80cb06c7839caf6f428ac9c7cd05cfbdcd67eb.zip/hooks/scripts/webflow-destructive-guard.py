#!/usr/bin/env python3
"""flowy: force a confirmation prompt before irreversible Webflow operations.

PreToolUse guard on data_assets_tool and data_component_tool for any Webflow MCP
server name — the matcher in hooks.json is a regex because the mcp__<server>__
prefix depends on what each user named their Webflow MCP server.

Every action guarded here is one the Webflow MCP's own schema documents as
destructive or unrecoverable — quoted below from the live schemas, read 2026-08-05.
These are not flowy's opinions about risk; they are the tool author's:

  delete_asset        "DESTRUCTIVE - the asset is removed from the site's assets
                       (soft delete) and there is no API to restore it; confirm
                       with the user before calling."

  compress_assets     "Compression REPLACES each asset's hosted file in place -
                       same asset ID, new hostedUrl/contentType/size; the original
                       file is not retained - confirm with the user first."

  create_asset_folder "there is no API to delete asset folders, so created folders
                       are permanent - confirm with the user before creating."

  unregister_component flagged DANGEROUS in the tool schema; it affects every
                       instance of the component site-wide. unlink_component_instance
                       is the per-instance tool. (flowy/componentize.md)

The schemas say "confirm with the user" — but nothing makes that happen, and an
agent mid-task reliably reads its own intent as the confirmation. This hook turns
the instruction into a mechanism.

It asks rather than denies: unlike resizing the window, each of these is sometimes
genuinely the right call. The user simply has to be the one who says so.

FAILS SAFE, like the publish guard: an unparseable or unfamiliar payload falls back
to a substring check on the raw input.
"""
import json
import sys

# action name -> why it cannot be undone
GUARDED = {
    "delete_asset": (
        "deletes an asset from the site. There is no API to restore it. Anything "
        "still referencing that asset - a style background-image, an <img> src, a "
        "CMS image field - breaks on the next publish."
    ),
    "compress_assets": (
        "replaces each asset's hosted file IN PLACE. The original file is not "
        "retained and cannot be recovered. Same asset ID, new bytes."
    ),
    "create_asset_folder": (
        "creates a permanent folder. There is no API to delete asset folders, so a "
        "folder created by mistake stays in the user's asset library forever."
    ),
    "unregister_component": (
        "affects EVERY instance of the component across the whole site, not just "
        "the one in front of you. unlink_component_instance is the per-instance "
        "tool and is almost always what was actually meant."
    ),
}


def guarded_actions(payload):
    """Names of guarded actions present in the call.

    Returns None when the payload is not shaped as expected, so the caller falls
    back to the raw-text check instead of reading 'unrecognised' as 'safe'.
    """
    if not isinstance(payload, dict):
        return None
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        return None
    actions = tool_input.get("actions")
    if not isinstance(actions, list):
        return None
    found = []
    for a in actions:
        if not isinstance(a, dict):
            continue
        for name in GUARDED:
            if name in a and name not in found:
                found.append(name)
    return found


raw = ""
try:
    raw = sys.stdin.read()
except Exception:
    pass

try:
    found = guarded_actions(json.loads(raw))
except Exception:
    found = None

if found is None:
    found = [name for name in GUARDED if name in raw]

if found:
    detail = "\n".join("  - {}: {}".format(n, GUARDED[n]) for n in found)
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "ask",
            "permissionDecisionReason": (
                "FLOWY - this call contains an operation the Webflow MCP schema "
                "itself documents as destructive or unrecoverable:\n"
                "\n" + detail + "\n"
                "\n"
                "Approve only if the user asked for this specific operation. If the "
                "agent chose it as cleanup, optimisation, or tidying that nobody "
                "requested, deny - flowy never takes an irreversible action on its "
                "own initiative.\n"
                "\n"
                "Before approving a delete, it is worth knowing what still points "
                "at the asset: a style background-image, an element src, or a CMS "
                "image field will break silently at the next publish."
            ),
        }
    }))

sys.exit(0)
