#!/usr/bin/env python3
"""flowy house rule #2: never publish a Webflow site without the user's explicit,
unprompted permission — any domain, including the .webflow.io staging subdomain.

PreToolUse guard on data_sites_tool for any Webflow MCP server name — the matcher
in hooks.json is a regex (mcp__\\S*[Ww]ebflow\\S*__data_sites_tool) because the
mcp__<server>__ prefix depends on what each user named their Webflow MCP server.

`data_sites_tool` is the ONLY publish surface in the Webflow MCP — verified against
the live tool schemas on 2026-08-05: designer_tool and data_enterprise_tool expose
no publish action. Its `actions` array holds items shaped
{"label": str, "<action_name>": {...}} with exactly one action per item. Read-only
actions (get_site, list_sites) pass through untouched; the moment a `publish_site`
action appears, force a human permission prompt so a publish can never happen
silently or on the agent's own initiative.

FAILS SAFE. If the payload cannot be parsed, or arrives in a shape this hook does
not recognise, it falls back to a substring check on the raw input and asks rather
than staying silent. A guard that fails open on the one rule it exists to enforce
is not a guard. A false prompt costs one keystroke; a false pass costs a client
site published without permission.
"""
import json
import sys


def wants_publish(payload):
    """True if any action in the call is a publish_site.

    Returns None when the payload is not shaped as expected, so the caller can fall
    back to the raw-text check instead of reading 'unrecognised' as 'safe'.
    """
    if not isinstance(payload, dict):
        return None
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        return None
    actions = tool_input.get("actions")
    if not isinstance(actions, list):
        return None
    return any(isinstance(a, dict) and "publish_site" in a for a in actions)


raw = ""
try:
    raw = sys.stdin.read()
except Exception:
    pass

try:
    publish = wants_publish(json.loads(raw))
except Exception:
    publish = None

if publish is None:
    # Unparseable or unfamiliar shape — fail safe on the raw text.
    publish = "publish_site" in raw

if publish:
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "ask",
            "permissionDecisionReason": (
                "FLOWY HOUSE RULE #2 - never publish a Webflow site without the "
                "user's explicit, unprompted permission. This covers the "
                ".webflow.io staging subdomain, not just the custom domain, and it "
                "covers single-page publishing. The agent must NOT publish, and "
                "must NOT offer to publish, on its own initiative.\n"
                "\n"
                "Approve ONLY if the user just asked, in their own words, for a "
                "publish right now. If the agent arrived here by its own reasoning "
                "- 'the work is done so I should publish', 'to verify the live "
                "page', 'to check whether the embed script runs' - deny it. Embed "
                "runtime genuinely does require a publish; the correct report is "
                "still 'comes alive on publish', not a publish."
            ),
        }
    }))

sys.exit(0)
