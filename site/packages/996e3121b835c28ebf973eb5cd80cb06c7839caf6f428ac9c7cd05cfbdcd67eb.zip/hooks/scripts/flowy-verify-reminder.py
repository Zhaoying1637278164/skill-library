#!/usr/bin/env python3
"""flowy: remind the agent to run flowy-verify after a Webflow MCP write.

PostToolUse hook on every Webflow MCP tool that is capable of writing.

Why this exists: Webflow MCP write responses report success on writes that did not
land. `data_whtml_builder` silently drops classes that don't already exist as
Designer styles (the tell is an ABSENT `styleNames` field, not an error), and
`update_style` / `set_settings` both echo success regardless. Without a nudge at the
batch boundary, an agent will report "done" on unverified work.

The matcher is tool-level, so pure reads (`query_*`, `get_*`, `list_*`) will
sometimes trigger it too. That is expected noise, and the message says so, so the
agent doesn't run a pointless verification pass after a read.
"""
import json
import sys

# Drain stdin so the hook never blocks on an unread pipe.
try:
    json.load(sys.stdin)
except Exception:
    pass

MESSAGE = (
    "flowy guard: a Webflow MCP call that can write just occurred. At the next "
    "batch boundary (before claiming work complete), invoke the flowy-verify skill "
    "via the Skill tool. It checks class attachment (data_whtml_builder still "
    "silently drops classes - the tell is an ABSENT styleNames field), audits "
    "auto-created styles for injected max-width/min-height/aspect-ratio, verifies "
    "bindings via all_raw_settings (never all_resolved_settings - it reports "
    "working CMS bindings as null), confirms the element tree, and re-reads embed "
    "code. A write response is never verification. This matcher is tool-level, so "
    "pure reads will sometimes trigger it - that is noise, not a signal. Cite "
    "flowy-manual when applying fixes."
)

print(json.dumps({
    "hookSpecificOutput": {
        "hookEventName": "PostToolUse",
        "additionalContext": MESSAGE,
    }
}))

sys.exit(0)
