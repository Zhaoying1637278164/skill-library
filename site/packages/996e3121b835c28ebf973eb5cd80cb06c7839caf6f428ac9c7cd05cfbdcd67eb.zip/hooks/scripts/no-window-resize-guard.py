#!/usr/bin/env python3
"""flowy house rule #3: NEVER resize the browser window to test mobile/responsive.

PreToolUse guard on mcp__claude-in-chrome__resize_window.

Origin: observed 2026-06-30, re-triggered 2026-07-19 on a live client project. This
is the single most-repeated correction in flowy's history ("you do it everytime").
Two independent reasons:

  1. It does not work. Observed twice — resizing the tab to 375/390 left
     `window.innerWidth` at the desktop value (1787 in 2026-06-30; 1907 in
     2026-07-19). The page never enters mobile mode, so any measurement taken
     afterwards is a desktop measurement wearing a mobile label.
  2. It shrinks the user's actual browser window, which is disruptive — and if the
     tab is the Webflow Designer, resizing breaks the Designer outright.

This hook denies rather than asks, because there is no case where resizing is the
right tool: every legitimate need has a strictly better alternative, listed in the
denial reason so the agent redirects instead of retrying.
"""
import sys
import json

try:
    json.load(sys.stdin)
except Exception:
    sys.exit(0)

print(json.dumps({
    "hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": (
            "FLOWY HOUSE RULE #3 — never resize the browser window to test "
            "mobile/responsive. It does not work (innerWidth stays at the desktop "
            "value, so the page never enters mobile mode and your measurement is "
            "wrong), and it shrinks the user's real window / breaks the Webflow "
            "Designer.\n"
            "\n"
            "Use instead:\n"
            "  * Webflow Designer -> the device toggles in the top toolbar "
            "(Desktop* / Tablet / Mobile Landscape / Mobile Portrait). This is the "
            "ONLY sanctioned way to see mobile in the Designer.\n"
            "  * A LIVE page -> measure inside an iframe set to the target width:\n"
            "      const f=document.createElement('iframe');\n"
            "      f.style.cssText='position:fixed;left:-9999px;width:390px;height:844px';\n"
            "      f.src=location.pathname; document.body.appendChild(f);\n"
            "      await new Promise(r=>f.onload=r);\n"
            "      /* then read f.contentDocument / f.contentWindow.innerWidth */\n"
            "    The iframe genuinely fires the small-viewport media queries; the "
            "window resize does not.\n"
            "  * Webflow breakpoints are fixed: 1920 / base / 991 / 767 / 478. Style "
            "changes belong on Desktop (main); smaller breakpoints are for responsive "
            "overrides only.\n"
            "\n"
            "Do NOT retry this call. Switch to one of the above."
        ),
    }
}))

sys.exit(0)
