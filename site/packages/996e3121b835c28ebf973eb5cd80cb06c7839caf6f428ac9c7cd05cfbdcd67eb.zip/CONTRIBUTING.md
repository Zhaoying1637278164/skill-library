# Contributing to flowy

flowy's value is that every claim in it is true, dated, and traceable to the tool call that
produced it. Contributions are held to the same bar.

## What a finding looks like

A mergeable finding names four things:

1. **The exact tool call**: tool name and the parameters that matter, as code.
2. **What the tool reported**: the response, especially where it claims success.
3. **What was actually true, and how you read it back**: the second call, canvas check, or
   published-page evidence that revealed the gap.
4. **The date and the Webflow MCP version** you observed it on.

Example of the bar, from the manual itself:

> `update_style` with `breakpoint_id:"main"` returned `status:"success"` and `query_styles` read
> back the old value. 2026-06-01, ~6 calls on the same style, tab foreground and background.

"This seems to happen" or "I think the MCP can't do X" won't land, however plausible. Single
observations are welcome; if you saw it once, say it happened once.

## What gets merged

- **Findings** in the format above: new traps, new capabilities, schema quirks, Designer
  behaviours.
- **Reversals**: evidence that an existing entry is no longer true. The old entry stays, struck
  and dated with a pointer to yours. Being proven wrong in public is how a verified-only ledger
  stays trustworthy.
- **Coverage**: areas the manual doesn't touch yet (localization, e-commerce, more conventions),
  built with the same evidence discipline.

## What doesn't

- Style rewrites, tone changes, restructuring for its own sake.
- Reproductions of third-party documentation (Client-First, Lumos, MAST are credited and linked,
  not copied).
- Speculation, however expert. The manual is a lab record.

## House rules for evidence

- **Anonymise client work.** No site IDs, no client names, no client class names presented as
  conventions. A class name may appear as *evidence* ("a class named like `x-label-1` was
  dropped") but genericise it first. `scripts/validate.py` checks for site IDs, local paths and
  credentials.
- **One finding per PR** where possible; it keeps the ledger's history legible.

## Before opening a PR

```bash
python3 scripts/validate.py
```

All checks must pass; the same script runs as CI and will block the merge otherwise.

## Cadence

This repo is maintained in bursts around real client work, which is also where its findings come
from. Issues and PRs are triaged in batches. A quiet week is normal; check the commit history.
