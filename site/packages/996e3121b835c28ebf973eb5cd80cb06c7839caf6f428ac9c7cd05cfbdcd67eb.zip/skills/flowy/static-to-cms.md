# flowy — converting static repeats to CMS

> How to take a component built with hard-coded repeated elements and make it CMS-driven, natively.
> Mechanics and traps: [flowy-manual → mcp-2.0.md](../flowy-manual/mcp-2.0.md) §3.

## THE RULE — one Collection List per parallel group

**When a component animates N parallel groups that live in different containers, each group becomes its
own Collection List, all bound to the same collection with the same sort.**

Scripted components commonly read several arrays and pair them **by index**:

```js
const titles      = [...root.querySelectorAll('[data-title]')];
const backgrounds = [...root.querySelectorAll('[data-bg]')];
const maskItems   = [...root.querySelectorAll('[data-mask-item]')];
// …then render() uses backgrounds[i], titles[i], maskItems[i]
```

The script does not care whether those are static divs or `.w-dyn-item`s; it queries by attribute. So
CMS works. But the groups sit inside **differently positioned ancestors** (a full-bleed absolute layer,
a centred flex strip, a clipped fixed frame). **One list cannot serve three containers**, because one
item cannot be in three places.

Hence: **N containers → N Collection Lists → one collection.** Each list renders the same items; each
container shows a different *facet* of each item.

### Index alignment is the thing that silently breaks

All lists must return items in the **same order**, or the animation pairs the wrong background with the
wrong title. Do not rely on default order:

- Add an **`Order` (Number)** field to the collection.
- Set `sort` to `[{"fieldSlug":"order","direction":"ascending"}]` on **every** list.
- Give every list the same `filters` and a `limit` above the item count.

## Deriving the collection from the component

1. **Find the repeats**: groups of N sibling elements sharing a class.
2. **Detect parallel groups**: separate groups with the *same* N are almost always facets of one
   entity. 5 backgrounds + 5 titles + 5 mask images = **5 slides**, one collection.
3. **One field per facet**, typed by what varies:

| What varies per item | Field type | Element in the item | Bindable key |
|---|---|---|---|
| Text / a heading | PlainText | `Heading` / `TextBlock` | `text` |
| A clickable title | PlainText (+ Link) | `LinkBlock` (returns type `Link`) | `text`, and `link` for the href |
| An image | **Image** | **`Image` element** | **`assetId`** |
| Rich copy | RichText | `RichText` | `text` |
| Ordering | Number (`Order`) | — | — |

**Images: add an `Image` element inside the Collection Item and connect it to the CMS image field.**
Bound images **do render** once connected through the connector (standing rule, 2026-07-27). Writing the binding
via MCP sets the same thing: key `assetId`, `binding {source_type:"cms", collection_id, field_id}`.

4. **Reuse the original element types.** If the static title was a `Link`, the CMS version must be a
   `Link` too; scripts often call `preventDefault()` on it or include `a, button` in a hover-pause set.
   Swapping it for a heading silently changes behaviour.

## Verified sequence, per container

Order matters. Building into an unbound list fails with *"Connect this Collection List to a Collection
before adding elements."*

1. `data_element_builder type:"CMSCollection"` into the container → returns a `DynamoWrapper`.
2. `set_settings` on the wrapper: **`source` + `sort` first.**
3. `set_style` the wrapper with the original list class (optional; keeps layout faithful).
4. `query_elements` scoped to the wrapper → the `DynamoItem` id.
5. On the item: `set_style` the original item class, then `set_attributes` for the script's hook
   (empty-string value). **Both coexist**: the item ends up `your-class w-dyn-item`.
6. `data_element_builder` the child element inside the item, with `set_style` for its class.
7. Bind the child's key to the CMS field.
8. `remove_element` on the original static **list wrapper**; one call removes all N static items.
9. **Reload the Designer tab**, then verify.

## The extra DOM level is harmless

A native Collection List is `DynamoWrapper (.w-dyn-list) › DynamoList (.w-dyn-items) › DynamoItem
(.w-dyn-item)`: three levels where static markup had two. By default the middle level carries no
class and shows in the Navigator as an unnamed **"Collection List"** row. That is normal, not
something missed.

**But it is not un-styleable** (corrected 2026-07-27). `data_element_tool > set_style` on the
`DynamoList` **succeeds**, and `set_attributes` on it succeeds too. Readback returned
`styleNames: ["radial-gsap-slider__list"]` plus `attributes: {"data-radial-slider-list": ""}`, and the
canvas DOM showed `class="radial-gsap-slider__list w-dyn-items"`. This is the lever that makes the
next section possible.

**Measured 2026-07-25:** `.w-dyn-items` computes `position: static; display: block`, so it creates no
containing block. An absolutely-positioned item's `offsetParent` resolves **past it** to the outer
container, identical to the static original. Confirm on any new component with the `offsetParent` probe
in [flowy-manual → diagnostics.md](../flowy-manual/diagnostics.md) §2.

**Re-measured 2026-07-27** with the track class moved onto `.w-dyn-items` (below): `.w-dyn-list` is
`position: static; display: block`, and the item's `offsetParent` resolved to the `.w-dyn-items` track
itself. The extra level stays transparent either way.

## ⚠️ Scripts using `:scope >` — the hook goes on the DynamoList, not the wrapper

**The single biggest trap in converting a scripted component.** Check the script for direct-child
selectors before you build:

```js
const items = Array.from(track.querySelectorAll(':scope > [data-slider-item]'));
track.appendChild(clone);                    // clones must be siblings of the items
```
and in its CSS:
```css
[data-slider-list] > :first-child { position: relative; }
```

Descendant queries (`root.querySelectorAll('[data-x]')`) don't care about nesting, so they survive a
normal conversion. **`:scope >` does not.** Put the track hook on the original list div and the items
land at `list > .w-dyn-list > .w-dyn-items > .w-dyn-item`: two levels too deep. `:scope >` returns
**zero** items, and generated clones (appended to the track) become the only direct children, so the
component silently renders nothing or pairs the wrong slides.

**Fix — move the track's class *and* attribute onto the `DynamoList`:**

| Element | Class | Attribute |
|---|---|---|
| `DynamoWrapper` (`.w-dyn-list`) | *(none needed)* | — |
| **`DynamoList` (`.w-dyn-items`)** | **the original track class** | **the track hook** |
| `DynamoItem` (`.w-dyn-item`) | the original item class | the item hook |

Then delete the original static track div entirely; the Collection List *is* the track. The items are
now genuine direct children, and `track.appendChild(clone)` puts clones in the right place.

The track class must carry the layout, not just the hook: an absolutely-positioned item takes its
static position from its **direct** parent, so `display:flex; justify-content:center; align-items:center`
has to live on `.w-dyn-items` or the cards stop being centred.

**Verified 2026-07-27** (Osmo "Radial Cards Slider"): canvas DOM returned
`trackClasses: "radial-gsap-slider__list w-dyn-items"` with **5 direct children**, each
`radial-gsap-slider__item w-dyn-item` carrying the item hook; at runtime `:scope >` matched 10
(5 CMS items + 5 generated clones).

## ⚠️ The canvas lies until you reload

After setting `source`, the canvas keeps rendering **"No items found."** even though the source is set
and readable. **Reload the Designer tab** (`?app=<token>` to keep the Bridge) and the items appear.

This is the most misleading moment in a conversion; it looks exactly like a failed binding. Check
`get_settings all_raw_settings` shows the source, *then* reload, *then* judge.

## Verification

- Bindings: `get_settings type:"all_raw_settings"`, **never `all_resolved_settings`**, which reports a
  working CMS binding as `null`.
- Items resolved: the canvas-DOM probe in
  [diagnostics.md](../flowy-manual/diagnostics.md) §4: count, texts, and `w-dyn-item` in the class list.
- Alignment: all groups must return the **same count**. Compare them explicitly.
- Then [flowy-verify](../flowy-verify/SKILL.md).

## Bonus: the counter updates itself

Scripts that derive a total from array length
(`totalEl.textContent = String(count).padStart(2,'0')`) need no change. **Add a CMS item and the
component grows**: the count, the pagination dots, the progress bar. That is the payoff of converting,
and the thing a static build can never do.
