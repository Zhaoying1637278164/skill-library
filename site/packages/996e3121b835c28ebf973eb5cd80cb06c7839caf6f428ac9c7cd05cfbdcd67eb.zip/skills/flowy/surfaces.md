# surfaces — running flowy outside Claude Code

Part of [flowy](SKILL.md). The lifecycle is surface-portable; only the file plumbing adapts.

**Non-negotiable everywhere:** the publish ban · plan approval before writes · one target per MCP call · every change ledgered *somewhere* · Designer-first for style values (Chrome extension) · flowy-verify at batch boundaries.

| Surface | Adaptation |
|---|---|
| **Claude Code** (primary) | Full flow as in [SKILL.md](SKILL.md). |
| **Cowork** (desktop app, filesystem) | Full flow. The export folder (and `_flowy/`) lives inside the Cowork workspace folder. No Bash assumptions — use the app's file tools for read/write; everything MCP + Chrome-extension is unchanged. |
| **Desktop chat** (no filesystem) | **Mirror deferred, not dropped.** Plan + ledger are maintained as a pinned artifact / project doc the user can persist across chats (the phase checklist at the top of plan.md replaces harness tasks). Ledger rows simply stay blank in `mirrored`; Phase 5 executes in the next filesystem-capable session (Claude Code / Cowork), resuming from that plan + ledger. Optionally emit the exact hand-edit diffs as an artifact meanwhile. Recon: against an attached export if provided; otherwise **MCP queries are the permitted fallback** for the page/site-ID map — the explicit exception to local-first. |

## Mirror-less mode

**Used only for sites that cannot produce a code export** (e.g. Ecommerce/Users; plans without export). Check for the Export button in the site's Designer; confirm current policy via Webflow docs/web search if absent. Desktop chat without an attached export is NOT mirror-less mode: it stays on the Desktop-chat row above (MCP-fallback recon, mirror deferred).

- `_flowy/` (plan + ledger + site-map) lives in a standalone folder (Claude Code/Cowork) or a maintained artifact (Desktop chat), **not** inside an export.
- Recon runs via MCP queries + Chrome extension instead of local files; the site-map still gets built (pages, IDs, stylesheet-equivalent class inventory via `query_styles`).
- Phases 3, 4, and 6 unchanged. Phase 5 mirror rows are all `mirrored: n/a` (the site can never export; the value is defined in SKILL.md's ledger spec).

## Supplying flowy to claude.ai (Cowork / Desktop)

Upload this skill folder as a claude.ai skill (or paste SKILL.md + these references into project instructions). The skill self-adapts via this file: no separate playbook is maintained. The trio (`flowy`, `flowy-manual`, `flowy-verify`) should travel with it; flowy routes to them constantly.
