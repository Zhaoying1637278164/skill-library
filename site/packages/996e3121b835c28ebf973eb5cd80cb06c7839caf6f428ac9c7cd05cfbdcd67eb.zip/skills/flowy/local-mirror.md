# local-mirror — export anatomy & hand-edit rules

Part of [flowy](SKILL.md). Two jobs: (1) what a Webflow code export looks like, what you can rely on vs must discover; (2) how Phase 5 mirrors approved Webflow changes into the local files.

**Standing rule: confirm at intake, never assume.** Everything below marked *[n=1]* was observed on a single real export; anything unmarked-but-structural should still be verified against the actual files during recon. The export is Webflow-generated output: treat surprises as findings to record in `site-map.md`, not errors.

## What a Webflow export IS (detection)

A folder of root-level `.html` files whose `<html>` tags carry `data-wf-page="<page-id>"` and `data-wf-site="<site-id>"`. **That attribute pair is the reliable detector**: stylesheet names, directory lists, and file counts all vary per site.

## Identity keys (harvest these first)

| Key | Where | Use |
|---|---|---|
| `data-wf-site` | `<html>` tag, every page | THE site identity — recorded in `_flowy/site-notes.md`, must match the open Designer before any write |
| `data-wf-page` | `<html>` tag, every page | Page-ID map: local file ↔ MCP page, harvested locally instead of MCP queries |
| `<!-- Last Published: … -->` | line 1, every page | The intake version check's local side (vs MCP `data_sites_tool`); recorded in site-map.md. May be absent on never-published sites |
| Canonical / `og:url` link | `<head>`, *optional* (only when configured in SEO settings) | Live domain, `<site>`-name fallback |

## Anatomy (typical shape; verify per export)

- **Root**: one `.html` per static page; `401.html`, `404.html`; possibly `search.html` *[n=1]*. CMS collection-page templates export as `detail_<collection>.html` **shells**: template markup only, **no CMS item content**. Designer page folders export as directories (`<folder>/<page>.html`).
  *Localized sites: locale subtree layout not yet observed [n=0]. Detect at intake, record in site-map.md, don't misread locale dirs as page folders.*
- **`css/`**: `normalize.css` plus one or more compiled stylesheets; **names and count vary** *[n=1: three sheets; other exports use `<slug>.webflow.css` naming]*. The class inventory lives in the compiled sheet(s): record which in site-map.md; all downstream rules reference that discovered set, never a hardcoded filename.
- **`js/`**: the Webflow-generated runtime (interactions included), typically site-slug-named *[n=1]*. **Read-only reference. Never hand-edit**: Webflow regenerates it; local edits are meaningless.
- **`images/`**: uploads plus Webflow-generated responsive variants (`-p-500`, `-p-800`, `-p-1080` suffixes) *[n=1]*.
- **`fonts/`, `documents/`**: uploaded assets. Observed: uploaded `.js` libraries stored renamed to `.txt`; Lottie `.json` files under `documents/` *[n=1]*.
- **Heads**: head/footer custom code IS included in the export; external CDN scripts stay external; embeds appear as `w-embed` blocks; inline `<style>` blocks appear where embeds carry CSS.

## `site-map.md` template (written at recon)

```markdown
# <site> — site map
site id: <data-wf-site value>
live domain: <from canonical/og:url, or "unknown">
last published: <line-1 value, or "absent">

## pages                          ## stylesheets
| file | data-wf-page | notes |   | file | role |
(one row per .html, incl.        (normalize / compiled — which
detail_* templates and folders)   sheet holds the classes)

## embeds inventory               ## unmapped
(page → w-embed blocks, what      (MCP pages with no local file;
they carry)                        locales; notes)
```

## `plan.md` template (drafted at recon, approved by the user)

```markdown
# <site> — plan
approved: <yes + time, or "pending">

## Phases (checklist on surfaces without a task tool)
- [ ] 1 intake  - [ ] 2 recon/plan  - [ ] 3 execute  - [ ] 4 test  - [ ] 5 mirror  - [ ] 6 wrap

## Sync-down (intake drift — executed immediately, no separate approval gate)
- [ ] S1 — sync-down: <what changed on Webflow since the export>

## Changes
- [ ] P1 — <what & where> · lane: <structure|style|attribute|cms|embed>
- [ ] P2 — …
```

Items are checked off at batch boundaries (flowy Phase 3). Ledger rows reference items via the `P<n>:` prefix in `intent`; that join is what makes crash-resume deterministic.

## Hand-edit rules (Phase 5 mirror — and Phase 1 sync-down)

Two triggers, same mechanics: **Phase 5** works from the ledger, row by row, and mirrors this session's approved Webflow changes; **Phase 1 sync-down** works from the intake drift list (`S<n>` items) and replicates whatever changed on Webflow since the export. Either way, **the mirrored value's source of truth is a fresh MCP read at mirror time**: `data_style_tool > query_styles include_properties:true` for style rows, `data_element_tool > query_elements` for structure/attribute rows, never the ledger's `intent` text (it names the goal, not the final tuned value).

| Change (lane) | Mirror action |
|---|---|
| structure (element added/moved/removed) | Edit the page's `.html` — insert/adjust the same markup Webflow will generate (match the file's existing formatting and class placement) |
| style (class value changed/created) | Locate **which discovered stylesheet defines the class** (grep the compiled sheets) and edit that rule there, matching its compiled format |
| attribute | Edit the element's attributes in the page `.html` |
| cms (collection schema / item data) | No local counterpart (exports carry no CMS content) → `mirrored: n/a (no export counterpart)` |
| embed (inline) | Edit the embed's content inside its `w-embed` block in the page `.html` |
| embed (page-level / site-level custom code) | Page-level: page `.html` head/footer. Site-level: appears in every page's head/footer — mirror it in **all** of them (it has a counterpart in every page) |

**New pages (in-session or found during sync-down) DO get a local file, hand-minted, never guessed:** copy a sibling exported page's invariant scaffolding (doctype, head boilerplate, stylesheet/runtime references), set its `data-wf-page` and title/meta from MCP reads, build the body from `data_element_tool > query_elements` reads. Flag it `hand-minted` in site-map.md; the next real export replaces it byte-exact.

**Truly counterpart-less (no file to edit):** CMS item content, anything in `js/<runtime>`, regenerated image variants → ledger `mirrored: n/a (no export counterpart)`.

**Known caveat:** hand edits and hand-minted pages approximate what a real re-export would produce. The mirror is a working reference, not a byte-perfect export. A fresh export re-baselines any time → flowy Phase 1 on the new folder, `_flowy/` carried forward (unfinished plan items survive).
