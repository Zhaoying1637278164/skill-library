# ix2-to-code — translating Webflow interactions into CSS/JS embeds

Default rule: **get off IX2 where the interaction is simple enough to rebuild.** This
file is the translation table and the decision rule.

> Companion to [interactions.md](interactions.md), which is about *reading* a reference's motion.
> This one is about *replacing* it. Read that first; you cannot translate what you have not inventoried.

## Why translate at all

IX2 is fine until it isn't. Reasons to move motion into code:

- **Portable.** Verified 2026-07-31: interactions do **not** survive a cross-site paste into a
  different engine, while an embed inside the component travels with it perfectly.
- **Legible.** A `<style>` block is reviewable and diffable. An IX2 timeline is a panel you have to
  click through.
- **Component-safe.** Embed motion is scoped to the component's own classes and survives duplication.
- **Engine-proof.** Classic IX2 vs `Interactions with GSAP (new)` is a per-site setting that can
  strand your work. CSS does not care.

**But do not translate reflexively**; see the decision rule.

---

## The decision rule

| Interaction | Verdict |
|---|---|
| **Hover on the hovered element itself**: its own colour, transform, opacity, border | ✅ **Native state, no code, no IX2.** Style panel → States → Hover. See the capability boundary below |
| **Hover that changes a DIFFERENT element**: card→arrow, wrapper→image, group→label | ✅ **Translate to an embed.** Webflow has no descendant selectors; this is `<style>`-tag territory. **This is most template hover motion** |
| **Click toggle**: menu, accordion, tab | ✅ **Translate.** Tiny JS: toggle a class; CSS does the rest |
| **Scroll into view, one-shot**: fade/slide in | ✅ **Translate.** `IntersectionObserver` + a class + a CSS transition |
| **Stagger** across siblings | ✅ **Translate.** Index-based `transition-delay` |
| **Page load** reveal | ✅ **Translate.** A class on `DOMContentLoaded`, or pure CSS keyframes |
| **Mouse-move parallax / tilt / magnetic** | ✅ **Translate.** `mousemove` → CSS custom properties → `transform`. Add lerp for IX2's "smoothing" |
| **Infinite loop**: marquee, spin, pulse | ✅ **Translate.** CSS `@keyframes` + `animation: … infinite`. Never JS-drive a loop |
| **Scrubbed scroll timeline**: progress-linked, multi-keyframe | ⚠️ **Cost check.** Doable with `animation-timeline: view()` (no JS, limited browser support) or GSAP ScrollTrigger. If the reference already has it working in IX2 and the site is on Classic, keeping it may be cheaper |
| **Multi-element choreography**: many elements, staggered timeline, interdependent | ⚠️ **Usually keep**, or rebuild deliberately in GSAP. Hand-rolling this in raw JS is where embeds get expensive and fragile |

**The heuristic:** if the interaction is *one element responding to one event*, translate it. If it is
*a timeline coordinating many elements against scroll progress*, price it before committing.

---

## Translation table

### The capability boundary — what Webflow expresses natively vs what needs the embed

⚠️ **Get this line right or you will either write embeds you did not need, or promise native states
Webflow cannot produce.** Both are verified 2026-07-31 on a real client build.

| CSS you need | Native? | How |
|---|---|---|
| `:hover` on **the hovered element itself** | ✅ **Yes** | Style panel → **States → Hover**. Via MCP: `update_style {pseudo:"hover"}`. Verified: `.rt-features-card` stores `pseudos.hover` with `transform` + token-bound border colours, **no embed** |
| `:focus`, `:focus-visible`, `:active`, `:visited`, `:placeholder` | ✅ Yes | Same States dropdown / `pseudo` argument |
| `:first-child`, `:last-child`, `nth-child(odd/even)` | ✅ Yes | Same |
| Hover on a **combo class** | ✅ Yes | Create the combo first, then the state |
| Hover **inside a component variant** | ✅ Yes | `set_variant_styles {pseudo:"hover"}`: verified on the button's Secondary/Light variants |
| `transition` | ✅ Yes | Normal style property |
| **`.a:hover .b`**: hover changes a *descendant* | 🚫 **No** | **Embed.** Webflow has no descendant selectors |
| **`.a:hover ~ .b` / `+ .b`**: sibling / group hover | 🚫 No | **Embed** |
| **`::before` / `::after`** | 🚫 No | **Embed** |
| **`@keyframes`** / `animation` sequences | 🚫 No | **Embed** (`animation-*` *properties* can be set natively once the keyframes exist in an embed) |
| **CSS custom properties** (`--x`) | 🚫 No | **Embed.** Verified rejected: `Invalid style property --rt-nav-bg` |
| **Compound state**: `.is-open .child`, `.is-scrolled .inner` | 🚫 No | **Embed**, and this is what class-toggling JS always needs |
| `@media (prefers-reduced-motion)` | 🚫 No | **Embed** |
| `@supports`, `:has()`, `clamp()`/`min()`/`max()`, `dvh/dvw` | 🚫 No | **Embed** (see [styles-and-classes.md](styles-and-classes.md)) |

**The rule that follows:** *does the effect stay on the element being interacted with?*
Yes → native state. No → embed. **Most template hover motion is "no"**, which is why the embed is the
normal tool and the native state is the narrow (but real, and free) case.

### Hover on the element itself → native state

`update_style {style_name, pseudo:"hover", properties:[…]}` plus a `transition` on the base class.
Previews on canvas, stays token-bound, survives duplication. Use it whenever it is sufficient, but do
not contort a design to stay inside it.

### Hover that reaches another element → the embed pattern

The workhorse. One **Code Embed** inside the component, holding a `<style>` tag scoped to the
component's own classes:

```html
<style>
/* hover the card, move the arrow — impossible natively */
.rt-card .rt-card-arrow{transform:translate3d(0,0,0);transition:transform .4s cubic-bezier(.22,1,.36,1)}
.rt-card:hover .rt-card-arrow{transform:translate3d(6px,0,0)}

/* hover the wrapper, scale the image — one element morphed, no duplicate layer */
.rt-card .rt-card-img{transform:scale(1);transition:transform .6s cubic-bezier(.22,1,.36,1)}
.rt-card:hover .rt-card-img{transform:scale(1.04)}

@media (prefers-reduced-motion:reduce){
  .rt-card .rt-card-arrow,.rt-card .rt-card-img{transition:none;transform:none}
}
</style>
```

Rules for this embed:

- **Always prefix with the component root class** (`.rt-card …`), never bare `.rt-card-arrow`. The
  embed is global once published; an unscoped rule leaks into every other component.
- **Declare the resting state in the embed too**, not natively. Both halves of one effect in
  one place is what makes it reviewable, and avoids the specificity trap below.
- ⚠️ **Embed CSS out-ranks native classes on the published page** (it loads later and usually has
  higher specificity), while being invisible on the canvas. So never set the *same property* both
  natively and in the embed: in particular, do not put plain colour/size in an embed on a class a
  **variant** overrides, or the variant will silently stop working.
  [flowy-manual/mcp-2.0.md](../flowy-manual/mcp-2.0.md) §13.6.
- One embed per component, placed as the **last child of the component root**, so it travels with the
  component and cannot be orphaned.

**Morph the element itself.** Never duplicate-and-crossfade; never add a second layer to fake a fill.
Single-element techniques that cover most IX2 hover effects:

```css
/* sweep fill — one element, background-position animated */
.btn{background-image:linear-gradient(90deg,#fff 0 50%,#161616 50% 100%);
     background-size:200% 100%;background-position:100% 0;
     transition:background-position .45s cubic-bezier(.22,1,.36,1),color .35s}
.btn:hover{background-position:0 0}

/* underline wipe — drawn as a background, not a child div */
.link{background-image:linear-gradient(currentColor,currentColor);
      background-size:0% 1px;background-position:0 100%;background-repeat:no-repeat;
      transition:background-size .32s cubic-bezier(.22,1,.36,1)}
.link:hover{background-size:100% 1px}
```

### Click toggle → class toggle

IX2 "Mouse click (tap)" with two states = one class and CSS.

```js
btn.addEventListener('click', function(e){
  e.preventDefault();
  var open = root.classList.toggle('is-open');
  btn.setAttribute('aria-expanded', open ? 'true' : 'false');
});
```

Everything visual lives in CSS on `.is-open`. Add `keydown` for Enter/Space, and real ARIA — IX2
gives you no accessibility at all, so this is a straight upgrade.

### Scroll into view (one-shot) → IntersectionObserver

The single most common IX2 animation, and the easiest win.

```js
var items = root.querySelectorAll('.js-reveal');
if(!('IntersectionObserver' in window)){
  items.forEach(function(el){el.classList.add('is-in')}); return;
}
var io = new IntersectionObserver(function(entries){
  entries.forEach(function(e){
    if(e.isIntersecting){ e.target.classList.add('is-in'); io.unobserve(e.target); }
  });
},{threshold:.15, rootMargin:'0px 0px -8% 0px'});
items.forEach(function(el){io.observe(el)});
```

```css
.js-reveal{opacity:0;transform:translateY(18px);
  transition:opacity .7s cubic-bezier(.22,1,.36,1),transform .7s cubic-bezier(.22,1,.36,1)}
.js-reveal.is-in{opacity:1;transform:none}
```

**`unobserve` after firing**: that is IX2's "once" behaviour and it keeps the observer cheap.

### Stagger → index-based delay

IX2 does this by hand-offsetting each child. Do it in one line:

```js
items.forEach(function(el,i){ el.style.transitionDelay = Math.min(i,8)*70 + 'ms'; });
```

Cap the index (`Math.min`) or item 20 waits 1.4s. IX2 has the same flaw and templates ship it.

### Page load → class on ready

```js
document.addEventListener('DOMContentLoaded',function(){root.classList.add('is-ready')});
```

Pure-CSS alternative when nothing needs coordinating: `animation` with `animation-fill-mode:both` on
the class directly. **Never delay the headline's first paint**: reveal supporting elements, let the
H1 land immediately, or you have traded a design flourish for a worse LCP.

### Mouse move (parallax / tilt / magnetic) → custom properties + lerp

IX2's "Mouse move in viewport" / "over element", including its **Smoothing** slider.

```js
var tx=0,ty=0,cx=0,cy=0,raf=null;
root.addEventListener('mousemove',function(e){
  var r=root.getBoundingClientRect();
  tx=(e.clientX-r.left)/r.width-.5;      // -0.5 … 0.5
  ty=(e.clientY-r.top)/r.height-.5;
  if(!raf) raf=requestAnimationFrame(tick);
});
root.addEventListener('mouseleave',function(){tx=0;ty=0});
function tick(){
  cx+=(tx-cx)*0.08; cy+=(ty-cy)*0.08;    // 0.08 ≈ IX2 "smoothing"
  root.style.setProperty('--mx',cx.toFixed(4));
  root.style.setProperty('--my',cy.toFixed(4));
  raf = (Math.abs(tx-cx)>0.001||Math.abs(ty-cy)>0.001) ? requestAnimationFrame(tick) : null;
}
```

```css
.card{transform:translate3d(calc(var(--mx,0)*24px),calc(var(--my,0)*24px),0)}
```

The lerp factor *is* the smoothing control. Let the rAF loop **stop when settled**; do not run a
frame loop forever.

### Infinite loop → CSS keyframes

```css
@keyframes rt-scroll{from{transform:translate3d(0,0,0)}to{transform:translate3d(-50%,0,0)}}
.track{animation:rt-scroll 32s linear infinite}
.viewport:hover .track{animation-play-state:paused}
```

Duplicate the content **in the DOM** so `-50%` lands seamlessly; see the marquee rule in
[from-template.md](from-template.md). Speed and direction become variant overrides
(`animation-duration`, `animation-direction`), which is also the only way to expose them to the
client, since props cannot bind to data attributes.

---

## Non-negotiables for any translated interaction

1. **Reduced motion.** Every embed ends with:
   ```css
   @media (prefers-reduced-motion:reduce){ .x{transition:none!important;animation:none!important;
     opacity:1!important;transform:none!important} }
   ```
   IX2 ignores this by default. Translating is your chance to fix it.
2. **Animate `transform` and `opacity` only.** Not `top/left/width/height/margin`; those trigger
   layout on every frame.
3. **Idempotency guard**, or a duplicated section runs the script twice:
   ```js
   if(!root || root.dataset.rtInit) return; root.dataset.rtInit='1';
   ```
4. **Scope to the component root**, never `document.querySelectorAll`:
   ```js
   var s=document.currentScript, root=s?s.closest('.rt-thing'):null;
   if(!root){var a=document.querySelectorAll('.rt-thing');root=a[a.length-1]}
   ```
5. **Passive listeners** for scroll/touch: `{passive:true}`.
6. **Keyboard + ARIA** on anything clickable. Non-negotiable, and IX2 gives none of it.
7. **Specificity discipline.** Embed CSS loads after Webflow's and wins ties, so keep embeds to
   compound/descendant state selectors (`.is-open .child`) and leave plain colour/size on the classes,
   or you will silently break every variant override. Verified trap:
   [flowy-manual/mcp-2.0.md](../flowy-manual/mcp-2.0.md) §13.6.

## Acceptance

Embed script never runs on the Designer canvas; that is normal (house rule #12). Acceptance at build
time is **byte-exact readback** of the embed plus a review of the CSS against this file. Runtime is
`🔍 Unchecked — comes alive on publish`, which is a finished state, not a caveat.
