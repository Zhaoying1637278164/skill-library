# flowy — house rules (always apply)

> **The working agreement.** These are **not** Webflow facts: they are how the work gets done, and
> they override any routing advice in [SKILL.md](SKILL.md). Webflow behaviour lives in
> [flowy-manual](../flowy-manual/SKILL.md).
>
> Every rule here was earned by a real correction on a real project. Rules 1–5, 8, 9a and 10–13 are
> Webflow-universal: keep them. Rules 6, 7 and 9 encode a setup choice (which browser, which
> typeface, which board etiquette) and read their values from `~/.claude/flowy.config.md`; see
> [setup.md](setup.md). No config is fine: the defaults are sane.
>
> **Three rules are hook-enforced and run whether the model cooperates or not:** #2 publish (ask),
> #3 window resize (deny), #9a irreversible operations (ask). The rest depend on being read.

## 1 — Know the project, and open it in a new tab with the Bridge (standing rule, 2026-07-25; extended 2026-07-29)

Two halves of one rule. Neither is optional, and the first comes first.

### 1a — The agreed project is a pinned identity, not a name

Before any work: **agree which project**, then resolve it to hard identifiers and keep them for the
session: `site name` + `site_id` + `page_id` + the Designer `tab id`.

`data_sites_tool > list_sites` to resolve. **Never assume a site id, and never resolve by name
alone.** Working accounts collect near-duplicates fast: one measured account (2026-07-29) held 258 sites with
heavy name collision. In an account like that, a name is not an identifier.

If more than one site matches what the user said, **ask which**: do not pick the newest, the first, or
the best guess. Writing to the wrong site is not recoverable by undo.

Re-state the pinned identity when switching sites, and re-run
`data_agent_instructions_tool > search_instructions` for the new one (SKILL.md step 5).

### 1b — Open it in a NEW tab, with the Bridge, in one navigation

Open the Designer **with the MCP Bridge connected**, in one navigation. Fire any `designer_tool`
call, take the `?app=<token>` link from the error text, `navigate` straight to it. Don't fumble the
Apps panel; don't start work with a half-connected stack.

**A new tab, via `tabs_create_mcp`.** Never reuse a tab id from a previous session: stale ids fail
in ways that look like Bridge problems. If a tool reports a tab that doesn't exist, or the user closed
it, call `tabs_context_mcp` for fresh state and open again; don't retry the dead id.

Tokens are reusable within a session. Foreground with the browser command from
the config (SKILL.md step 0). **The extension is bound to one specific browser, and it is often not
Google Chrome** (rule #6). The Bridge is only required for `designer_tool`; `data_*` REST calls work
with the tab backgrounded, but a backgrounded tab plus a large call is a guaranteed timeout (rule #5).

## 2 — 🚫 NEVER PUBLISH WITHOUT EXPLICIT, UNPROMPTED PERMISSION

Every domain, **including staging `.webflow.io`**, not just the custom `.com`.

Do NOT publish. Do NOT *offer* to publish. Do NOT close a message with "want me to publish?",
"ready to publish?", or any variation. Publishing is the user's action, not an option you extend. Even
raising it as a closing question is unwanted. Do the work → verify against the real artifact →
present the finding → **STOP.** The user raises publishing themselves; when they do, you publish.

Hard rule since 2026-06-18. **Enforced by a PreToolUse hook** on `data_sites_tool` that ships with this plugin
(`hooks/scripts/webflow-publish-guard.py`): it forces a human permission prompt the moment a
`publish_site` action appears, so a publish can never happen silently. Reads pass through untouched.
An in-canvas embed deploy is not a publish, but any publish that would follow it is still gated.

### 2a — The one narrow exception: ASKING the user to publish a REFERENCE template (standing rule, 2026-07-31)

Asking is the mechanism; the publish itself stays the user's action.

✅ You may **ask** the user to publish a **reference / template** site you are learning from, when a live
page is genuinely required: real DOM, embed `<script>` runtime, scroll-linked behaviour, console.

🚫 The exception is deliberately tiny. It does **not** touch anything else:

- **You still never publish anything yourself**, reference or target.
- **It applies only to the template you are reading**, never to the site you are building.
- **Rule #2 is unchanged for the target/client site**: do not publish it, do not offer, do not close a
  message with it. This note creates no opening there.
- **Ask only after the Designer routes are exhausted**: Interactions panel, Preview ▷, MCP reads,
  device toggles. Most questions die there and never need a publish.
- **State what you tried, what is still unanswered, and what you will do** with the live page, then
  stop and wait rather than building a guess.

Full protocol and the exhaust-first table: [interactions.md](interactions.md) §5.

## 3 — 🚫 NEVER resize the browser window to test mobile

It does not work (`innerWidth` stays desktop: 1787 on 2026-06-30, 1907 on 2026-07-19) and it
shrinks the user's real window / breaks the Designer. Use the Designer **device toggles**,
or an iframe at the target width on a live page. **Enforced by a PreToolUse hook** on
`resize_window` that ships with this plugin (`hooks/scripts/no-window-resize-guard.py`): it *denies*
rather than asks, and names the alternatives in the denial so the agent redirects instead of
retrying. This is the single most-repeated failure mode in flowy's history.
Snippet + breakpoint table: [flowy-manual → responsive.md](../flowy-manual/responsive.md).

## 4 — 🚫 NEVER use the Designer "Enable custom code?" preview

A standing rule (2026-07-06, after a repeat miss). It launches an
unreliable multi-second recompile. **This is banned, not a fallback.** Embed code is verified
byte-exact in-editor or by MCP readback ([embeds.md](embeds.md)); true runtime behaviour is
`🔍 Unchecked — deferred until the user publishes / tests on the real page`.

⚠️ **This rule bans a verification method. It does not ban script-based solutions** (see rule #12).
Reading "I can't preview it" as "I shouldn't build it" inverts both rules at once.

## 5 — Webflow MCP calls must be SMALL — one call, one thing

The most important MCP rule (2026-06-18). One query per `query_*`; one action per write tool.
Inspect and build one element at a time. Many small calls beat one big call.

**Scope:** this is the Webflow MCP. `claude-in-chrome` `browser_batch` is exempt: batch freely
there. Compounds with the foreground throttle: backgrounded tab + big call = guaranteed timeout.

## 6 — ⚙️ "Chrome" does not necessarily mean Google Chrome

**The `claude-in-chrome` extension is connected to exactly one browser, and it may not be the one
called Chrome.** Any Chromium browser can host it: Comet, Arc, Brave, Edge, Chrome Canary. Opening
the wrong app does nothing for the automated tab and wastes the turn, and the failure is confusing
because the tools still "work", just on a tab nobody is looking at.

**Read `browser` from `~/.claude/flowy.config.md`** (SKILL.md step 0) and foreground with that.
Default `Google Chrome`. If the default turns out to be wrong, say so once and offer `/flowy:setup`
(it writes the config). 🚫 Never write settings into this plugin's own directory; it is replaced
wholesale on update and anything stored there is lost. Reference: [setup.md](setup.md).

**The diagnostic:** if `designer_tool` calls time out while `data_*` calls keep
succeeding, suspect the wrong browser before you suspect the Bridge.

## 7 — ⚙️ Fonts: one typeface, set on `body` only

**Never introduce a new typeface unless the user explicitly asks.** Set `font-family`
**once on `body`** and let everything inherit: never per class or element, not as a literal, not as
a variable binding. Applies to Designer styles and embed CSS alike. Verify with a `query_styles`
property filter on `font-family`: only `body` should match.

The *policy* is universal; the *typeface* is a setup choice. Read `fonts` from
`~/.claude/flowy.config.md` for new builds. Default `per-brand` means the brand intake decides.
If it names a house typeface, that wins. On already-built sites (Track E), **respect the discovered font
system as-is**: body-only and no-new-typeface still apply, but do not retypeset someone's site.

## 8 — Verify the persistent artifact, not a temporary injection

Do not verify by injecting temporary `<style>`/JS into the canvas or live page: the user finds leftover
code messy. Build the real persistent artifact (native style, committed embed) and verify **that**.
A one-off probe is acceptable only if removed in the same turn.

## 9 — ⚙️ Never move a client task to Done, and never propose it

Where a project board is shared with a client, **the client owns the Done column.** They confirm,
then they move it. Your job ends at presenting finished work and, when asked, drafting the note that
tells the client it's ready. Working statuses (Active / Up next / To be Reviewed) are fair game **on
the user's instruction**: do it, then read the row back. Never unprompted; never Done.
(2026-07-19, clarified 2026-07-20.)

`board` in `~/.claude/flowy.config.md` names the tool (Notion, Linear, Asana, Trello, Jira, none).
Default `none`, which makes this rule inert, but the underlying principle still holds: **never declare someone
else's acceptance on their behalf.**

## 9a — 🚫 Never take an irreversible action on your own initiative

Four Webflow MCP operations cannot be undone, and the tool schemas say so themselves:

| Operation | The schema's own words |
|---|---|
| `delete_asset` | *"there is no API to restore it; confirm with the user before calling"* |
| `compress_assets` | *"REPLACES each asset's hosted file in place… the original file is not retained"* |
| `create_asset_folder` | *"there is no API to delete asset folders, so created folders are permanent"* |
| `unregister_component` | flagged DANGEROUS; affects **every instance site-wide**. `unlink_component_instance` is the per-instance tool |

**Enforced by a PreToolUse hook** on `data_assets_tool` and `data_component_tool`
(`hooks/scripts/webflow-destructive-guard.py`): it asks rather than denies, because each is
occasionally the right call. The user simply has to be the one who says so.

The failure this prevents is not malice, it is tidiness: deleting an "unused" asset, compressing
images to be helpful, unregistering a component that looked redundant. **Cleanup nobody asked for is
the most common way an agent destroys something.** Webflow's own Designer "Clean up" / bulk-delete
of unused styles belongs in the same category: one irreversible action across the whole site, and
it cannot see classes used by embeds, interactions or CMS rich text. Never unprompted.

Before approving a delete, know what still points at the asset: a style `background-image`, an
element `src`, or a CMS image field will break silently at the next publish.

## 10 — Verified-only, and no unverified claims

Every entry in [flowy-manual](../flowy-manual/SKILL.md) references a directly observed event and the
tool that produced it. No hedges, no untested fixes, no single-observation generalizations dressed as
patterns.

When uncertain about anything load-bearing: **verify now**, or say "I don't know" **and name the next
move**, or propose an alternative. Never silently drop it. Re-check recency before stating anything
possibly stale.

## 11 — Session-end routine

At the end of any Webflow session, ask the user whether anything observed should be captured.
Webflow-general → the right `flowy-manual` file; the maintainer keeps the dated
verification ledger privately. Site-local quirks → that site's `_flowy/site-notes.md`. Never into this file unless the user states a new standing rule.

## 12 — Invisible in the Designer is NOT a reason to ship less (standing rule, 2026-07-30)

Scripts cannot render on the Designer canvas; they come alive only on the published site. That is
a property of the platform, not a defect in the work.

**Script and CSS inside an embed do not execute on the Designer canvas. That is normal Webflow
behaviour, not a defect, not a blocker, and not evidence the code is wrong.** The correct response is
to add the code, verify it byte-exact, and let it come alive on the user's publish.

🚫 **Never downgrade a component's functionality because the canvas cannot render it.** Replacing a
working interactive pattern with a static one to make the canvas look right is the failure this rule
exists to prevent. Corrected after exactly that miss on 2026-07-29: an FAQ accordion was flattened to
a static Q&A list because `<details>` mis-rendered on canvas and rule #4 bans the custom-code preview.
Both premises were true; the conclusion was wrong. The only thing actually broken was the
preview, not the component.

**Order of preference for any interactive section** (take the first that applies):

1. **An interaction that already exists.** Check the source component for Webflow IX first
   (§[componentize.md](componentize.md) → *Interactive behaviour*). If the template's own
   `Accordion`/`Tabs`/`Slider` already animates, **duplicate that component and reskin it**: the
   behaviour comes along and it previews natively in the Designer.
2. **A custom-code embed inside the component.** Self-contained `<style>`/`<script>`, scoped to the
   component's own classes. Invisible on canvas by design; verify byte-exact and defer runtime.
3. **Static**: only with the user's explicit agreement, and say plainly what was given up.

**Acceptance at build time is byte-exact readback**, not observed motion. Report runtime as
`🔍 Unchecked — comes alive on publish`, which is a normal completed state here, not a caveat.

## 13 — A failed MCP check is NOT a finished check — escalate to the browser (standing rule, 2026-07-30)

An MCP check that fails is not a completed check: repeat the same check through the Chrome
extension by opening the page, not stopping at the error.

**Every check has two hands. MCP is only the first.** If the MCP call errors, times out, returns
empty, or is inconclusive, **the check is still open.** Open the Designer with `claude-in-chrome` and
look. Only after *both* hands have failed may anything be reported as unverified, and then say what
you tried, in both hands.

🚫 **Banned phrasings until the browser hand has actually been attempted:** "couldn't verify",
"MCP is down so this is unchecked", "🔍 Unchecked" on anything a human could see on screen.

### The one legitimate 🔍, and the line between them

| Situation | Verdict |
|---|---|
| **Runtime of embed `<script>`/`<style>`** | ✅ `🔍 Unchecked — comes alive on publish` is correct and final. Genuinely needs a publish (rule #12); the browser hand cannot see it either |
| **Anything observable on screen** — does this component have an interaction, does it render, does it break at mobile, did the class attach | ❌ **Not 🔍.** Observable in the Designer. Go look |

The test: *could the user see this by opening the Designer themselves?* If yes, so can you.

### Escalation ladder when MCP fails

1. **Re-resolve the session.** `data_sites_tool > list_sites`: site ids go stale between sessions
   (observed 2026-07-30: `The site cannot be found` on an id that worked the day before).
2. **Re-open the Designer in a new tab with the Bridge** (rule #1b). This alone often restores MCP,
   because most failures are a dead Designer session rather than a broken API.
3. **Switch hands entirely.** `claude-in-chrome`: navigate, screenshot, read the panel.
4. **Cross-check surfaces.** `element_snapshot_tool` and `claude-in-chrome` are *independent*
   connections; one frequently works when the other is down (observed 2026-07-29, both directions).
   Try the other before concluding anything.

### Checking for interactions specifically

The Designer's **Interactions panel** is the authority, not an inferred attribute:

1. MCP: `data_element_tool > get_attributes` looking for `data-w-id`.
2. **If that fails or is inconclusive → browser.** Open the Designer, select the element, open the
   Interactions panel (lightning-bolt icon, right sidebar) and read what is bound to it.
3. **Designer Preview (▷, without custom code)**: watch it animate. Preview runs IX2 but not embed
   script, so it is a valid and unbanned check here (rule #4 bans only the *custom-code* preview).
4. If the site is published, read the live DOM through the extension and look for `data-w-id`.
