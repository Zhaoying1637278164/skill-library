# flowy — rebrand

> Pushing a new brand through an existing build.
> Runs **before** componentization: variables propagate, components do not.

## 🚫 Required input — this file does not define it

**"Rebrand it" is not an instruction until the brand has a source.** One of:

- a Figma file
- a brand guide
- an explicit token list: colour ramp, type scale, spacing scale, imagery

**This phase does not run until that input is supplied.** The brand is **never inferred from the
site**, and never from another page on the site. Ask once, plainly, and wait.

**The pipeline does not block on it.** Rebrand is independent of the classifier, so build the
components in the project's existing brand and apply the rebrand as a second pass once tokens exist.
Sequencing it that way also keeps Gate 1 judging structure rather than structure *and* brand at once.

---

## Why before componentizing

Change a variable once and every element bound to it moves. Change it after componentizing and you
are re-checking twenty definitions instead of one token set.

**Verify the project is actually token-bound first.** `data_variable_tool > get_variable_collections`,
then `get_variables` per collection. If values are hardcoded, propagation will not happen and the
job is a different, larger one; say so before starting rather than discovering it at element 200.

⚠️ **Zero variables is not a defect.** At least one major convention's official starter ships none
and hardcodes every value. Absence tells you the *method*, not the quality
([conventions.md](conventions.md) §1).

---

## What to change, in order

**1. Colour.** `data_variable_tool > update_color_variable`. Read the original value first; the
readback is your revert path.

**2. Type.** ⚠️ **Fonts are governed by house rule #7 and it overrides this file.** Never introduce a
typeface unless the user asks. Policy: one typeface, set once on `body`, inherited, never per class,
never as a variable binding. On an already-built site: **respect the discovered font system as-is**;
body-only and no-new-typeface still apply. Verify with a `query_styles` property filter on
`font-family`; only `body` should match.

**3. Spacing / radius / shadow.** Same tool, same revert discipline.

**4. Imagery.** `asset_tool > upload_image_by_url`: one call per asset from a public URL. Rebind
via `set_image_asset` or the relevant `image` prop.

**5. Variable modes.** If the project themes via modes (a `Theme` variant prop, a mode set on the
page wrapper), the rebrand has to cover **every mode**, not just the default. Read
`get_variables { include_all_modes: true }` and check the count before assuming one.

---

## Class renaming — deferred, and narrower than it sounds

**Deferred to build time**, where every element is being touched anyway.

**Scope: rename only where the class name carries the *template's own brand*.**

| Rename | Leave alone |
|---|---|
| `flowbase-hero-wrap` | `hero-wrap` |
| `acme-btn-primary` | `btn-primary` |

A systematic re-naming of an entire class system is a **much larger job** and is not what "rebrand"
means. If that is genuinely wanted, it is its own phase with its own approval.

### 🚫 Before any rename

**Read the class's site-wide usage.** A rename propagates to every element carrying it,
including elements on pages you are not working on, and **including elements inside component
definitions**, which page-level queries do not reach.

```
data_style_tool  > query_styles   name_path:["<class>"]
data_element_tool> query_elements element_filter:{ style:"<class>" }     ← per page
                 > query_elements element_filter:{ style:"<class>" }, scope_component_id:<each>
```

⚠️ There is **no single call that returns per-style usage**; it must be assembled per page, and it
**under-counts unless you also scope into component definitions.**

⚠️ **Renaming does not reach duplicate same-named combo classes.** `update_style` and `rename_style`
are name-based with no by-id form: they hit one instance and silently leave the other. Check for
duplicates before renaming.

---

## Verification

| Check | How |
|---|---|
| Token landed | `get_variables` readback: value equals what you wrote |
| Propagated | Chrome `getComputedStyle` on two elements that consume the token, on two different pages |
| All modes | `get_variables { include_all_modes: true }`: no mode left on the old value |
| Fonts | `query_styles` property filter `font-family` → only `body` matches |
| Assets | the new asset renders on canvas, and the old one is no longer referenced |
| Renames | re-run the usage queries **including component scopes**; zero hits on the old name |

Then [flowy-verify](../flowy-verify/SKILL.md).

**Canvas ≠ live.** Everything here is verified in the Designer. Runtime is
`🔍 Unchecked — deferred until the user publishes`, per house rule.

---

## Open

- 🔍 **Token propagation has been reasoned, not measured.** No rebrand has been executed end to end
  through this file. The mechanism is documented from the tool surface and from
  [conventions.md](conventions.md)'s token findings; log what actually happens on first run,
  especially how many elements move per token and whether any consumer fails to update.
- 🔍 **Whether a variable update reaches styles inside component definitions** is untested. Assume it
  does (variables are site-scoped), but verify it on the first real rebrand rather than trusting it.
