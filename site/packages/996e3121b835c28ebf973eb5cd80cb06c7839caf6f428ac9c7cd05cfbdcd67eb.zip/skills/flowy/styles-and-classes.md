# flowy — styles & classes

> How to read, write, audit and consolidate Webflow styles without breaking a live design.
> Verified against Webflow MCP **2.0.1**. Every entry below references a directly observed event
> ([house-rules.md](house-rules.md) #10). Routing lives in [SKILL.md](SKILL.md).

## 🚫 `row-gap` rejects variable binding (verified 2026-07-29, MCP 2.0.1)

`data_style_tool` fails with `Tool create_style failed: An internal error occurred` when `row-gap`
is given `variable_as_value`. Isolated by elimination on one class:

| Call | Result |
|---|---|
| `row-gap` + `variable_as_value` | ❌ internal error (`create_style` **and** `update_style`) |
| `row-gap` + `property_value:"16px"` | ✅ |
| `column-gap` + `variable_as_value` (**same variable id**) | ✅ |
| `flex-wrap:"wrap"` | ✅ |

**Not a token problem**: the identical variable binds fine on the other axis. **Workaround: static
value for `row-gap`, variable for `column-gap`.** The error names neither the property nor the
cause, so a multi-property call fails opaquely; isolate by splitting the call.

## ⚠️ Empty `<div>`s render as a large bordered placeholder on the canvas

An empty block shows as a ~74px pale bordered square in the Designer **even with an explicit small
`width`/`height` on its class**: `query_styles` confirmed `width:40px; height:3px` was stored
correctly while the canvas drew a square. Canvas chrome, not a style fault, but the client sees it.
**Fix: move the shape into an `HtmlEmbed` that references the token CSS var**, e.g.
`<div style="width:40px;height:3px;background:var(--<collection>---<group>--accent,#RRGGBB)"></div>`
Identical on canvas and live, and still follows the token. Verified by before/after snapshot.

## 1 — Which hand writes a style

| Target | Hand | Why |
|---|---|---|
| Global class, base breakpoint | **MCP** `data_style_tool > update_style` | Exact, one call, re-readable |
| Global class, other breakpoint | **MCP** `update_style` + `breakpoint_id` | Never set the canvas width to "get to" a breakpoint; see §3 |
| Combo class | **MCP** `update_style` + `parent_style_names` | The combo is a *separate style object*; see §2 |
| **Component-variant override** | 🔴 **Designer-hand only** | `update_style` has **no `variant_id`**; see §4 |
| A visual judgment (does this look right) | **Designer-hand** | WYSIWYG; type the value and watch it land |
| Removing a property | **MCP** `update_style { remove_properties: [...] }` | Verified 2026-07-28: leaves `base: {}`, does not delete the style |

## 1b — 🔴 `style_name` is the Designer NAME, not the CSS selector

Verified 2026-07-28. `remove_style { style_name: "heading-3" }` returned
**`Style "heading-3" not found`**, while `query_styles name_path:["heading"]` showed the style very
much exists, as name **`Heading 3`**, selector `.heading-3`.

Webflow slugifies the Designer name into the compiled CSS: `Heading 3` → `.heading-3`,
`Menu Button` → `.menu-button`, `USP-heading` → `.usp-heading`. **The export only ever shows you the
slug.** Classes authored in code-style naming (`badges_paragraph`, `u-text-style-h3`) happen to have
name == slug, which is why this trap stays hidden until you touch an older, hand-named class.

**Consequence, and it is a nasty one:** a batch of `remove_style` calls built from export class
names fails with `not found`, which reads exactly like *"already deleted, nothing to do."* 29
consecutive false negatives were mistaken for a clean site before `query_styles` exposed the real
names. **Never infer "already gone" from `not found`.** Resolve every target through `query_styles`
first and take the `name` field verbatim.

Safe side: a `not found` removal is a genuine no-op (nothing is deleted), so the failure mode is
lost time, not lost styles.

## 1c — The export is a snapshot; Webflow is the truth

Verified 2026-07-28: against a 3-week-old export, the live site had styles the export did not
(`u-text-style-body-large`, `u-text-style-label-bold`) *and* had lost a whole family the export
still listed (a `-2` shadow set removed by an earlier cleanup).

Local census (§6) is the right way to find *candidates* fast. It is never the list you act on.
**Re-base every candidate list against `get_styles` / `query_styles` immediately before writing**,
especially names, which §1b shows you cannot guess.

## 2 — Base class vs combo class are different objects

Verified 2026-07-28 on `.badges_paragraph` / `.badges_paragraph.sg-body-1`:

- `query_styles name_path:["badges_paragraph"]` returns **only** the base class.
- `query_styles name_path:["badges_paragraph","sg-body-1"]` returns the combo, with its own
  per-breakpoint properties.
- Removing `max-width` from the base left the combo's `medium { max-width: 44ch }` completely
  untouched.

**Consequence:** "I removed the cap" is only true for the object you named. Before claiming a
property is gone site-wide, read the base *and* every combo chain that ends in it. A single-segment
`name_path` does **not** walk combos.

## 3 — 🔴 The canvas-width trap

**Setting the Designer canvas width also switches the active breakpoint.** Verified 2026-07-28: at
canvas 1889 the Designer announced *"Breakpoint switched to 1440px based on canvas size"*; at 1920,
*"switched to 1920px"*; back at 1279, *"switched to Desktop"*.

So a style edit made while the canvas is wide **lands on that breakpoint, not on base**, silently,
and it will look correct on screen while being invisible at every narrower width.

**Rule:** make all base-breakpoint edits at a canvas width inside the base range, *then* widen only
to inspect. Restore the width when done. If you must edit at a tier, do it deliberately via MCP
`breakpoint_id` instead, where the target is explicit and re-readable.

This is distinct from [house-rules.md](house-rules.md) #3: that bans resizing the *browser
window*; this is the *canvas* control inside the Designer, which is the legitimate tool, with this
one sharp edge.

## 4 — Component variants: MCP cannot write them

`data_style_tool`'s `variant_id` parameter exists **only** on the variable-mode actions
(`get/set/remove_style_variable_mode`). `update_style` has no `variant_id`. There is no MCP path to
a per-variant style override.

Verified 2026-07-28: `.hero_content` needed `align-items: end` on variant "Layout split".
`query_styles` on `hero_content` returned only the base properties: **the variant override was
invisible to MCP entirely**, both for reading and writing.

**The working sequence (Designer-hand):**

1. `data_component_tool > query_components` → get the component id **and the variant id/name**.
2. `data_element_tool > query_elements` with `scope_component_id` → get the target element id.
   (A page-scoped query returns **0 matches** for componentized subtrees.)
3. `designer_tool > open_component_view` on the *instance*.
   🔴 **This opens the definition at the Base variant, NOT the instance's variant.** Verified
   2026-07-28: the About page instance uses "Layout split", but the canvas opened on Base and the
   Style panel showed Base's properties. Editing there would have silently hit the wrong variant.
4. **Click the variant in the Variants panel** (top-left). Confirm the Style panel header now shows
   the variant chip beside the class name.
5. Edit in the Style panel.
6. **Verify by switching back to Base** and confirming it still shows the old value. That isolation
   check is the only proof the write was correctly scoped, since MCP can't read either one.

## 5 — Global usage truth: the Clean-up panel

The Style panel's "N on this page" is **per-page**, not global: useless for deciding whether a
class is dead.

**Webflow's own global answer:** Style selectors panel (shortcut `G`) → the filter icon at the panel
header → *"The following styles are not associated with any page elements"*, with a total count and
a bulk **Delete**.

Verified 2026-07-28 on a mature client site: **585 unused styles.**

🔴 **Never click Delete unprompted.** It is one irreversible bulk action across the whole site, and
Webflow's detection is *element association only*; it does not know about:
- classes referenced from **custom code / embed CSS** but never applied to an element,
- classes targeted by **interactions**,
- classes used only in **CMS rich-text** output.

Report the count and the risk; the delete is the user's call. For a small, precise purge, use MCP
`remove_style` one class at a time instead: same effect, auditable, one ledger row each.

## 6 — Token-cheap global census from the export (Track E)

Before touching Webflow, count usage locally. Far cheaper than MCP and gives per-class numbers the
Designer never shows:

```bash
# every class token, ranked by element count, across the whole export
grep -rho 'class="[^"]*"' --include="*.html" . \
  | sed 's/class="//;s/"//' | tr ' ' '\n' | sort | uniq -c | sort -rn
```

Pair it with a CSS-side parse (strip `@media` blocks first to isolate base rules) to get
*rule → properties → usage count* in one table. That is what turns "clean up the styles" from a
guess into a list.

**Blind spot:** the export renders Collection Lists empty, so a class appearing *only* inside CMS
rich-text output reads as unused. The `detail_*.html` template pages cover most CMS markup; say so
explicitly rather than presenting the census as complete.

## 7 — Consolidating a legacy class system

When a site has grown two parallel type/spacing systems (a template one plus a bespoke one):

**Map by value, never by name.** Verified on a real site 2026-07-28: a template scale
(`u-text-style-h1…h6`) and a bespoke scale (`sg-h1…h4`) collided; the bespoke scale was the
template scale shifted one step: `sg-h1`(55px) ≈ template `h2`(52px), `sg-h2`(43) ≈ `h3`(41),
and so on, with nothing at the template's `h1`(74). Renaming by matching numbers would have jumped
155 headings from 55px to 74px. Always align the two scales on a sorted value ladder and read
the names across, before proposing any rename.

**Unify through variables, not through re-classing.** Re-tagging thousands of elements is slow and
risky. Instead point every in-use class's property at the *same variable*
(`update_style` supports `variable_as_value`). The classes stay where they are, the design does not
move, and afterwards one variable edit propagates everywhere, which also converts a later
"match the spec" pass from an N-class job into an N-role job.

**Separate the two questions.** "Unify the classes" (zero visual delta) and "move the design to the
spec" (visible delta) are different decisions with different approvers. Do the first; stage the
second so it is one small, reviewable edit.

## 8 — Verifying a style change without publishing

The Designer canvas is a same-origin iframe (**id `site-iframe-next`**), so real computed geometry
is readable, which beats eyeballing a screenshot:

```js
const d = document.getElementById('site-iframe-next').contentDocument;
const el = d.querySelector('.my-class');
getComputedStyle(el).fontSize;              // resolved value, variables included
el.getBoundingClientRect();                 // real layout result
```

Verified 2026-07-28: confirmed a grid child filling its track exactly (`976→1672 = 696px`) and a
bottom-alignment fix (`delta 0px`) this way, at three canvas widths, with nothing published.

This satisfies "verify the real artifact" for unpublished work, and it is **not** a temporary
injection ([house-rules.md](house-rules.md) #8); it only reads.

Caveats: re-measure after changing canvas width (see §3), and a background tab freezes rAF, so
scroll/animation sampling reads stale.

## 9 — Order of operations for a style-cleanup engagement

1. **Census first** (§6): local, cheap, complete-enough, with the CMS caveat stated.
2. **Classify** every in-use class: on-system / drifted / dead. Present the table; get the calls that
   change the design signed off before any of them are written.
3. **Purge the dead** (§5): no visual risk, biggest legibility win.
4. **Consolidate the duplicates**: classes with *identical* property sets that differ only in name.
   Check every type property, not just the headline one, before merging.
5. **Bind the survivors to variables** (§7): the actual unification.
6. **Then**, and only with sign-off, move the variables to the spec.

Do not reorder 5 before 3: binding dead classes to variables preserves the mess.
