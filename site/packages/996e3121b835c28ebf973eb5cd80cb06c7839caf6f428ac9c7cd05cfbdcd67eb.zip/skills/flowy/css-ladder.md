# embeds & the CSS ladder

Part of [flowy](SKILL.md). Decision rules for custom code on an existing site. The *editing technique* for embeds is NOT here: it's `flowy-manual` → `../flowy/embeds.md`; follow it exactly, it encodes several verified UI traps. This file decides **where code goes**, not how to type it.

## JS embed placement — decide by scope, smallest first

Be deliberate: inline, page-wise, and site-wise are three different blast radii. Pick the smallest that covers the requirement.

1. **Section-scoped script** → inline embed **inside that section**. Selectors scope from a section-local root (an attribute or class on the section wrapper), e.g. query within the embed's own section, never bare global IDs/classes that may repeat across pages or CMS items.
2. **Page-specific** → page-level custom code (page settings head/footer), not an inline embed floating in the layout.
3. **Site-wide** → site-level custom code / `data_scripts_tool`. Documented limits (10k chars per inline script; no selective delete) → `webflow-mcp-custom-code-management`.

Existing embeds are edited in-canvas (flowy-manual technique). New embeds: MCP-insert the embed element (one call, ledgered), then edit its code in-canvas.

Load-order note: section-inline embeds execute where they sit in the DOM; page/site scripts per their head/footer placement. If a script needs the Webflow runtime or a CDN lib, verify availability at its position (`flowy-manual` catalogues observed load-order traps, e.g. an early-body embed script running before later-body elements exist).

## CSS the Style panel can't express — the ladder

Resolved **at planning time** (flowy Phase 2): each CSS-ladder item enters the plan re-tagged as **the winning rung's lane** (*style* for rungs 1 and 3, *structure* for rung 2, *embed* only when the ladder is exhausted). Exhaust in order:

1. **Style panel properties**, including custom properties/variables settable directly in the panel. Most "Webflow can't do this" beliefs die on this rung; check the panel before concluding. → lane: *style*
2. **Preset / DOM element options**: often the right native element type (list, rich text, form element, etc.) exposes the styling the wrong element type hides. → lane: *structure* (element-type change)
3. **Webflow Variables**: for values that need reuse/theming. → lane: *style*
4. **Embed `<style>`**: last resort only, flagged in the ledger. → lane: *embed*

## Embed-CSS verification protocol (flowy-manual-verified; read `designer-traps.md` for the observations)

- **Canvas rendering of embed `<style>` is per-embed, NOT universal.** Some embeds render and apply in the canvas, others on the same page don't (cause unconfirmed). Never assume either way: **verify the specific embed with a canvas `getComputedStyle` probe** before relying on what the canvas shows.
- **Specificity trap:** embed rules win over native classes only by normal CSS rules. The classic trap is a descendant selector in an embed (e.g. specificity 0,1,1) beating a native flat class (0,1,0) **on the live site**, while that embed doesn't render in the canvas, so the Designer shows the native class winning. If a native style "mysteriously doesn't apply" live, grep the export's `w-embed` blocks for a shadowing rule before touching the class. Fixes per flowy-manual: migrate the embed rule's properties into the native class, or reach higher specificity with a combo class.
- **Native-first check:** this session's native structure/styles must stand alone in Designer preview with custom code **OFF** (flowy Phase 4.1): a new embed must never be load-bearing for something a native class should do. (Pre-existing embed-dependence found on an already-built site is a site-local quirk → record in `site-notes.md`, not a failure to repair.)
- In-session verification for embed-carried CSS/JS = **in-editor SHA verify** (`flowy-manual` `../flowy/embeds.md`: SHA-256 of the CM6 doc == the built file's `shasum`) + the per-embed canvas probe above. 🚫 **NEVER enable the "custom code" preview / sitePreview compile to verify.** Never use it: it is slow, unreliable, and proves nothing about the published page. True live behavior stays `🔍 Unchecked — deferred until the user publishes / tests on the real page`. Never claim live-verified without a live page.

---

## The canvas is the test for "does this belong in an embed?"

Verified 2026-08-02 on a portfolio build, after the prompt bar rendered on top of the sidebar brand in
the Designer yet looked correct when published.

**Rule: an embed may hold only what changes. Everything static belongs in the Style panel.**

For a fixed overlay (a prompt bar, a sticky header, a cookie bar), that split is:

| Property | Where | Why |
|---|---|---|
| `position`, `left`, `right`, `z-index`, `display`, `padding`, `pointer-events`, **and the resting `top`/`bottom`** | **Style panel** | Native, so the canvas renders it and the user can see the real thing |
| The *other* state's `top`/`bottom` (`.is-hero`) | Embed | JS-toggled class — Webflow cannot express it |
| `::before` / `::after` scrims | Embed | Pseudo-elements are not native |
| `:has()`, `:focus-within`, descendant/sibling selectors | Embed | Not native |
| `transition` on a JS-toggled property | Embed | Belongs with the state it animates |

**Make the Designer base equal the *default* state.** Here the base is the docked bar, so the embed
needs exactly one rule to lift it (`.is-hero`) instead of one rule per state. Fewer rules, and the
canvas shows a real, usable layout instead of an unpositioned block.

🚫 **Never set the same property in both places.** Embed CSS out-ranks native classes on the
published page while being invisible on the canvas: you get a layout that looks broken in the
Designer, correct when published, and impossible to edit through the Style panel.

**The tell:** an element that looks wrong on the canvas but right on the published page has its
static properties in the embed. Move them.

---

## A fixed overlay and flowing content must be composed, not just layered

The same session: the bar sat at `top:31vh` while the hero headline flowed independently in
`#swup`, so at most viewport heights the bar landed on top of the subtitle. In the reference
prototype this could not happen, because the headline, field and chips were all children of the one
fixed block.

🚫 Do not fix this with px margins on the flowing content. The overlay is positioned in `vh` and the
content in `px`; they only agree at one viewport height. Verified: a margin that cleared the bar at
900px tall collided again at 1300px.

✅ **Reserve the band in the same unit, with a real element.**

```
.hero_lede { height: 31vh; display:flex; flex-direction:column; justify-content:flex-end;
             padding-bottom: 28px }   /* content bottom-aligns to the bar's top edge */
.hero_gap  { height: 84px }           /* bar height (56) + the same 28 clearance */
.hero_chips{ margin-top: 0 }
```

Measured across 700 / 800 / 900 / 1080 / 1300 / 1117px viewport heights: **28px above and 28px below
the bar at every one.** The spacer is `aria-hidden="true"`: it is layout, not content.

⚠️ **Shortening a hero moves whatever marker your scroll logic keys on.** Collapsing the hero pulled
`[data-hero-end]` above the halfway line, which would have flipped the bar to docked on load. Fixed
with `min-height:100vh` on the hero so the marker always sits at the fold. **Whenever you change a
hero's height, re-check every measurement taken against it.**
