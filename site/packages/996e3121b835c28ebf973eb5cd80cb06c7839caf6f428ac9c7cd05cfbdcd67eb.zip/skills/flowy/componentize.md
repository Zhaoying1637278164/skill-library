# flowy — componentize

> Turning what is already built into components a client can operate.
> Read [conventions.md](conventions.md) first: you build in the project's idiom, not ours.
> Verified end-to-end on a live site 2026-07-29; every claim here names the call that produced it.

## The routing question, asked first

> **Does the subtree contain component instances?**

| | Path | Because |
|---|---|---|
| **Yes** | **A — composite** | `transform_element_to_component` will refuse. Build the definition, then insert into it |
| **No** | **B — from raw** | `transform_element_to_component` works normally |

Any project built on MAST, Lumos or Client-First is **Path A**. Marketplace templates with
hand-built markup are Path B. A single project can need both.

---

## 🚫 The transform rejection

**`transform_element_to_component` fails on any subtree containing component instances.**
Error: `Target element is invalid.`

Verified four ways on 2026-07-29:

| Target | Result |
|---|---|
| A component instance | ❌ `Target element is invalid.` |
| A raw `Block` **containing** instances | ❌ same |
| Same, with the page open on the Designer canvas | ❌ same — **not a canvas-state problem** |
| **Control:** plain `Block` + `Heading`, no instances | ✅ **succeeded** |

The control is what makes this a finding rather than a failed call.

⚠️ **The error string is uselessly generic.** `Target element is invalid.` is identical for a bad
element id and for an instance-containing subtree. **Check the subtree for instances before you
debug the id.**

**This likely generalises.** `flowy-manual` lists *"transform where the subtree contains a Collection
List"* as unverified. Retest it against this hypothesis (same rejection family) rather than
as a separate unknown.

---

## Path A — composite components

### A1. Create the definition

```
data_component_tool > create_blank_component
  name, group, description
```

**The schema says "Create a blank component with no root element." It is wrong**: a root `Block`
(tag `div`) is created. Readback confirms. Build into it directly.

Name and group **in the project's idiom**. `conventions.md` §2 step 7 tells you the format. On a
MAST project that means Title Case in a Title Case group, and a description of the form
*"Only for use within the X component"* on anything non-standalone.

### A2. Insert the children

```
data_component_tool > insert_component_instance
  component_id, parent_element_id, creation_position:"append",
  scope_component_id: <the new component id>
```

One call per child (house rule #5). `scope_component_id` is what addresses the definition's tree
rather than the page's. Omit it and the lookup goes to the page.

**Build the composite out of the project's own components**, not out of raw elements. A composite
that reaches for a bare `Heading` element on a site that has a `Heading` component fails the idiom
test on sight.

### 🚫 A2b. MCP cannot fill a nested instance's slot — this is the hard ceiling

**Verified 2026-07-29.** Inserting into a component instance that sits inside a definition fails:

> `Cannot insert relative to a component instance — the Designer rejects inserts that use a
> component instance as the anchor. Target the instance's parent element (e.g. append to the parent)
> or an element inside the component definition instead.`

The instance *exposes* its slot in readback (`slots: [{ id: {component, element, slot}, … }]`), but
`parent_element_id` accepts only `{component, element}`. **There is no slot-targeting parameter.**

**What this rules out.** A wrapper chain in which every level is a component instance
(`Section › Grid Row › Grid Column › content`, the idiomatic shape on any component-first framework)
**cannot be assembled through MCP.** You can insert instances as *siblings* under a definition root,
but you cannot nest one inside another's slot.

**So MCP composites are flat.** Flat is fine when the composite's children sit directly under the
root. It is not fine when the project's idiom requires the wrapper chain, and on a component-first
framework it usually does.

### A2c. The Designer hand is required for nested composition

This is [two-hands.md](two-hands.md)'s paste-first rule arriving in a new place, and for the same
reason: **the operation is lossless in the Designer and impossible over the API.**

### ✅ The verified layout-faithful route

**Run end to end 2026-07-29.** Six steps, alternating hands:

| # | Hand | Call |
|---|---|---|
| 1 | MCP | `create_blank_component { name, group, description }` |
| 2 | MCP | **`insert_component_instance` of the new component onto any page** (see the trap below) |
| 3 | Designer | `designer_tool > select_element` on the **source** composed section |
| 4 | Designer | `computer key cmd+c` (`ctrl+c` on Windows/Linux) |
| 5 | MCP | `designer_tool > open_canvas { component_id }` |
| 6 | Designer | `computer key cmd+v` (`ctrl+v` on Windows/Linux) |

Then §A3–A4 (props, defaults, tooltips, bindings) on the pasted tree, exactly as normal.

**The paste is lossless.** Readback after step 6 showed the full chain, `Section` (Container=true)
› slot › `Grid Row` › slot "Add Grid Column" › …, and `hasOverride: true` survived on the nested
Grid Row's `Column Alignment` prop. Instance-level overrides come across, not just structure. The
component canvas rendered a fully styled hero: eyebrow, headline, body copy, primary and secondary
buttons. The MCP-built equivalent rendered flat.

### ⚠️ `open_canvas` fails on a component with no instances

Step 2 exists because of this. `open_canvas` returned `Failed to open canvas` twice on a
freshly-created component, then succeeded immediately once an instance was placed (same
component, same call).

**Do not read this as "open_canvas requires an instance."** A different fresh component with 0
instances *did* open earlier in the same session; it had variants and a styled root. **The
discriminator is not established.** What is established is the workaround: **place an instance
first**, and it worked on the component that had just failed twice.

⚠️ **The Bridge log reported both failed calls as "Designer tool completed" in 17ms and 14ms** while
the MCP tool returned an error. **Bridge-log success is not tool success**; read the tool result.

**Seeding a placeholder element does NOT fix it** (tested); the canvas still refused to open with a
child present but no instance. Only placing an instance worked. If you seed a placeholder anyway,
`remove_element` it after pasting.

**Do not conclude from this that composites are a Designer job.** Definition, props, bindings,
variants and variant styles are all MCP. Only *nested composition* crosses over.

### A3. Derive the prop surface

What varies between instances becomes a prop:

| What varies | Prop type |
|---|---|
| Text | `textContent` |
| Rich copy | `richText` (default via `default_text.rich_text_inner_text`) |
| An image | `image` |
| A destination | `link` |
| A child present in some instances, absent in others | `boolean` |
| **A categorical design state** (Dark/Light, Compact/Full) | **a variant — not a prop** |

Encoding design state as a boolean, or content as a variant, are both wrong and both common.

`create_prop` takes an array: **all props in one action**, with `group`, `tooltip` and the matching
`default_*` in the same call. All three write successfully together; no follow-up update needed.

### A4. Bind each prop through to the child it drives

```
data_component_props_tool > set_component_instance_prop_values
  element_id: <the CHILD instance inside the definition>
  scope_component_id: <the composite>
  values: [{ prop_id: <the CHILD's own prop>,
             type: "bindable",
             binding_source_type: "prop",
             binding_prop_id: <the COMPOSITE's prop> }]
```

**This is the mechanism the whole path depends on**, and it works. Multiple values bind in one call.

✅ **Cross-type binds work.** A composite `boolean` prop bound to a child's `visibility` prop is
accepted and renders as a working toggle. That is what lets a client see `Show`/`Hide` instead of
being handed a raw visibility control.

### A5. Instantiate and read back

`insert_component_instance` on the page, then `get_component_instance_props` with **`resolved_value`
both ways**:

- `true` → concrete values. The composite's defaults must arrive at the inner props.
- `false` → binding references (`{"sourceType":"prop","propId":"…"}`).

**Both must be non-empty.** A populated `false` with an empty `true` means the binding exists but
resolves to nothing: a prop that looks correct in the definition and is broken in use.

---

## Path B — from raw markup

`transform_element_to_component { id, name, group, description, replace: true }`, then props derived
from **elements** rather than passed through to child components. Everything in §A3 and the
usability contract still applies.

✅ **Verified 2026-07-29**: run eight times end to end on a marketplace template
(hand-built markup, no instances in the subtrees). All eight transforms succeeded. The sequence:

| # | Call |
|---|---|
| 1 | `data_element_builder`: build the raw tree on the page (nested `children[]`, one call) |
| 2 | fix-ups: `set_text` on **String** children, `set_link` on `TextLink`s (see traps) |
| 3 | `transform_element_to_component { replace: true }` |
| 4 | `create_prop` — all props in one action, with `group`, `tooltip`, `default_*` |
| 5 | `data_element_settings_tool > set_settings` — bind each prop |

**Binding a prop to a raw element** (this is the Path B equivalent of §A4):

```
set_settings operations: [{
  element_id: <element INSIDE the definition>,
  scope_component_id: <the component id>,
  settings: [{ key: "text", binding: { source_type:"prop", prop_id: <prop> } }]
}]
```

Discover the valid keys first with `get_settings type:"query_settings"` — on a `Link` they are
`domId`, `link`, `text`, `visibility`, all `canBind:true`. Verify with `all_raw_settings`, which
returns `{sourceType:"prop", propId, propName, propGroup}`.

**Path B traps, all hit on 2026-07-29:**

- `set_text` on a `TextBlock` fails with *"This element doesn't support text"*. The builder creates
  it as a `Block` wrapping a `String`. **Target the `String` child.**
- `set_link` inside a nested `element_builder` call lands on `LinkBlock` but **not** on `TextLink`;
  apply it afterwards with `data_element_tool > set_link`.
- Element ids are random UUIDs on the page but **sequential from the component id** after the
  transform. Predicting them saves a read, but setting text inserts a `String` child and shifts the
  sequence, so **re-read before a long binding batch.**

---

## Interactive behaviour — accordions, tabs, sliders, reveals

> Governed by [house-rules.md](house-rules.md) #12. **Never flatten an interactive section to a
> static one because the canvas can't show it working.** Work down this ladder and stop at the first
> rung that applies.

### Rung 1 — Inherit an interaction that already exists (check this FIRST)

Marketplace templates ship working IX2 on their `Accordion`, `Tabs`, `Slider` and reveal components.
⚠️ **`duplicate_component` does NOT bring the behaviour** (verified 2026-08-17: a duplicated
accordion carried structure, styles and props, and its Interactions panel was empty while the
original showed its Mouse-click trigger). Inheriting means **instancing the original**:

```
data_component_tool > insert_component_instance { component_id, parent_element_id, creation_position }
```
then override props as normal (§A3–A4). Reskin via variants or per-instance props rather than
duplicating; if you must duplicate, read the copy's Interactions panel first and expect to rebuild
the trigger (rung 2).

**How to detect an existing interaction before you commit, in this order.**
Governed by [house-rules.md](house-rules.md) #13: **if the MCP step fails or is inconclusive, the
check is not over: switch to the browser hand and look.** Never conclude "no interaction" from a
failed MCP call.

| # | Hand | Check | Meaning |
|---|---|---|---|
| 1 | MCP | `data_element_tool > get_attributes` with `scope_component_id`, looking for `data-w-id` | 🔍 **Hypothesis — unverified.** IX2 is understood to stamp `data-w-id` on every element it drives. **Run it before relying on it** |
| 2 | MCP | `query_styles name_path` for trigger-shaped names (`…-trigger`, `…-toggle`, `…-content`) | Weak signal only: naming is a convention, not a binding. Never decide on this alone |
| 3 | **Chrome** | Open the Designer, select the element, read the **Interactions panel** (lightning-bolt, right sidebar) | ✅ **The authority.** This is what MCP is only ever inferring. Go here whenever 1–2 fail *or* disagree |
| 4 | **Chrome** | Designer **Preview** (▷, *without* custom code) — watch it animate | Strongest behavioural proof. Preview runs IX2 but **not** embed script; that asymmetry is the whole point of this ladder, and rule #4 bans only the *custom-code* preview, not this |
| 5 | **Chrome** | If the site is published, read the live DOM and look for `data-w-id` | Fallback when the Designer hand is unavailable |

⚠️ **Whether `duplicate_component` carries IX bindings across to the copy is also unverified.**
Check the duplicate at step 4 before building on it. If the interaction does not survive, fall to
rung 2 rather than rebuilding it by hand.

### Rung 2 — Drive it from a custom-code embed inside the component

Self-contained `<style>` + `<script>` in an `HtmlEmbed` child of the definition, scoped to the
component's own classes. One embed serves every instance.

- **It will not run on the canvas. That is expected** (house rule #12), not a
  reason to change approach.
- Verify **byte-exact** via `get_settings type:"all_raw_settings"`; report runtime as
  `🔍 Unchecked — comes alive on publish`.
- **Make it degrade honestly.** Gate the active state on an attribute the script sets
  (`[data-x-ready="1"]`), so a blocked script leaves a sane static layout instead of a broken one.
  Verified pattern 2026-07-29 on a marquee: without the gate a failed script left the track
  mid-slide; with it, the row simply sits centred and still.
- Prefer delegated listeners on `document` over one per instance.

### Rung 3 — Static

Only with the user's explicit agreement, and state plainly what was given up.

### 🚫 Not a rung — native `<details>` / `<summary>`

Verified 2026-07-29: the tags apply correctly via `set_dom_config` and read back as
`"tag":"details"`, but **the Designer canvas does not implement disclosure layout at all**: the
answer spills outside the collapsed box and overlaps the next row, and adding `open` changes nothing.
Live behaviour would be fine; the canvas is the problem, and the canvas is where the client works.
Use rung 1 or 2 instead.

## The client-usability contract

The person who ends up operating these has never opened Webflow. **Every prop must satisfy all
five**; this is the acceptance criterion, not polish.

1. **Named in the client's language.** `Headline`, not `h1_text`. `Button link`, not `cta_href`.
2. **A tooltip on every prop**, in plain words. Say what it does and, where it helps, what makes a
   good value: *"Keep it under about ten words so it stays on two lines."*
3. **Grouped**: `Settings` for content, `Advanced` for escape hatches. Follow the project's own
   grouping if it has one.
4. **A default that renders something sensible.** A dropped instance must look right immediately,
   never empty.
5. **Booleans get labels**: `default_boolean: { value, true_label: "Show", false_label: "Hide" }`.

⚠️ **`true_label` / `false_label` cannot be verified by MCP.** They are not returned by
`create_prop`'s response and not returned by `get_component` with `includeProps`. Verified
2026-07-29: they *do* persist and render as a labelled two-button toggle in the Designer, but
**the canvas is the only verification path.** Screenshot the props panel; a readback will not
prove it.

### The two acceptance tests

**The client test.** Open the Add panel and read the component as someone who has never used
Webflow. If a prop's purpose is not obvious from name plus tooltip, it fails.

**The idiom test.** Put the new component's class list, name and prop set beside an original from
the same project. **If you can tell which is new, the profile was adopted in name only.** Go back
to `conventions.md` §2 and read deeper. This catches a derived profile that matched the structural
chain while missing that the project suffixes every modifier, or never uses combo classes.

---

## Prop types: direct vs. derived

`create_prop` **directly creates**: `textContent`, `string`, `richText`, `image`, `link`, `video`,
`number`, `boolean`, `id`, `altText`.

**The others are not uncreatable; they are derived.** You do not create the prop; you create the
structure it stands for, and the prop appears.

| Prop type | Create instead | |
|---|---|---|
| `slot` | `data_element_builder` with `type:"ComponentSlot"` inside the definition. Returns `type:"Slot"`; a `slot` prop appears on the component. **Full guide: [slots.md](slots.md)** | ✅ verified |
| `variant` | `data_component_variants_tool > create_variant`. A `variant` prop appears automatically | ✅ verified |
| `visibility` | hypothesis: bind an element's `visibility` setting to a prop; the Designer shows this as a purple bind-dot beside ID / Visibility / Attributes in the Settings panel | 🔍 untested |
| `headingTag` | hypothesis: same, on a Heading's tag setting. Note `headingTag` is not even in the MCP *filter* enum, yet real components expose it | 🔍 untested |

**Readable prop types ⊃ filterable ⊃ directly creatable.** Absence from `create_prop`'s enum is not
a capability limit; ask what structure the type describes.

---

## Variants

`data_component_variants_tool`: create, duplicate, rename, reorder, and style.

✅ **Variant styling works via MCP** (corrected 2026-07-29; `SKILL.md:26` previously said Designer-
only). `set_variant_styles` takes `variant_id` + `style_name` + `breakpoint_id` + `pseudo`, and
`variable_as_value` for token binding. The old premise still holds (`update_style` genuinely has no
`variant_id`); the conclusion did not, because variant styling lives on a different tool.

- **Overrides are sparse.** The readback returns only overridden properties, not a copy of the base.
  Verified: base kept `padding` after a variant override wrote only `background-color`.
- **The write response is a thin echo**: `{variant_id, style}` with no properties. Useless as
  verification; `get_variant_styles` is the evidence.
- Always confirm the **base is unchanged** after styling a variant. A variant write landing on base
  is worse than failing.

---

## Verification

| Check | Call | Pass condition |
|---|---|---|
| Definition | `get_component` + `includeProps`/`includeVariants`/`includeInstanceCount` | names, groups, tooltips, defaults all present |
| Instance | `get_component_instance_props`, `resolved_value` **true and false** | both non-empty; resolved values are the composite's defaults |
| Variant style | `get_variant_styles`, then `query_styles` on the base | override present on the variant, base unchanged |
| Class attachment | any element readback | `styleNames` **present**. An **absent** `styleNames` is the silent-drop tell |
| Boolean labels | **screenshot the Designer props panel** | ⚠️ no MCP path exists |
| Rendered | Chrome pass | every instance renders; none empty |

Then [flowy-verify](../flowy-verify/SKILL.md).

---

## Traps

- ⚠️ **`children_depth:0` does not suppress slot contents on `ComponentInstance` results.** On a
  slot-composed site, broad instance queries return full slot subtrees and blow the response ceiling
  (observed at 127KB and 182KB). Scope to one page or one parent and parse the saved tool-result file
  locally.
- ⚠️ **Page-level element queries do not descend into component definitions.** Use
  `scope_component_id`. Any "unused class" conclusion drawn without it is wrong.
- 🚫 **`unregister_component` is flagged DANGEROUS: it affects every instance site-wide.** It is
  never the tool for undoing a bad componentization. `unlink_component_instance` is, and it works
  per-instance. Never call `unregister_component` unprompted.
- 🚫 **`unlink_component_instance` does not work on code or library components.** Inventory them
  first (`query_components` with `isCodeComponent` / `isLibrary`) and treat them as read-only.
- **Probe on a duplicate.** `create_page { duplicateOf, draft: true }` gives a disposable sandbox.
  There is no `delete_page` in the MCP; the page must be removed in the Designer, so name it
  obviously.

---

## Known gaps

- **Authoring a *new* Webflow interaction has no MCP path.** IX2 timelines cannot be created over
  the API. This is a gap in *authoring*, not a reason to ship a static component; see
  *Interactive behaviour* above for the two routes that do work (inherit an existing IX, or drive it
  from an embed).
- **Why `open_canvas` refuses some 0-instance components and not others is unexplained.** The
  workaround is verified; the rule is not.
- **Interaction survival through componentization is unmeasured.** Deferred to Path B, where
  IX-heavy templates are the norm.
- **`visibility` and `headingTag` prop derivation is untested**: mechanism identified (setting-to-
  prop binding, the purple bind-dot), not run.

**Closed 2026-07-29, previously open:** whether a nested instance's slot can be filled via MCP. It
cannot (§A2b), and that is what makes §A2c necessary rather than merely convenient.
