# interactions — reading, judging and reusing IX2 on a reference template

Template-agnostic. Applies to any Webflow template you are asked to learn from, not one in particular.

> Written 2026-07-31 after shipping a library that hand-rebuilt motion the reference already had.
> The failure was not the code; it was never looking.

## Why this file exists

A premium template's value is mostly its motion. The layout is copyable by eye in minutes; the
choreography took the author weeks and is what makes a page feel expensive.
If you reproduce a template's layout and invent your own motion, you have reproduced the cheap half.

**So: inventory the motion before you build anything.**

---

## 1 — The only reliable way to see interactions

🚫 **`data-w-id` does not exist in the Designer.** It is stamped at publish/export. An attribute query
for it returns `0` on pages that are full of interactions. Verified 2026-07-31
([flowy-manual/mcp-2.0.md](../flowy-manual/mcp-2.0.md) §13.1).

**There is currently no MCP route to IX2 at all.** Not `get_attributes`, not `query_elements`, not
`element_snapshot_tool`. This is a **browser-hand-only** capability.

### The read, step by step

1. Open the reference Designer: `<shortname>.design.webflow.com`. **It does not need to be
   published**; the Designer renders and previews an unpublished site fully.
2. Select an element. The **Navigator** is the reliable way in; clicking the canvas selects the
   outermost component instance.
3. Right panel → **Interactions** tab (third, after Style and Settings).
4. Read both blocks:
   - **Element trigger**: fires from interaction with *this* element (click, hover, mouse move over,
     scroll into view, while scrolling in view).
   - **Page trigger**: fires from the page (page load, scroll, mouse move in viewport). These are
     listed on every element but belong to the page.
5. Read the **named animation** on each trigger; this is the prize. Names are authored by the
   template designer and are usually descriptive.
6. Read the **Version** field at the bottom: `Classic Interactions` vs newer. It affects what
   duplication and pasting carry.

### What a name tells you

Observed on one template: page load → `Landing Hero Slider`, mouse move in viewport →
`Page Card Mouse Move`. From two strings you learn the hero is a scripted slider on load and the
cards parallax to the cursor: two facts no amount of CSS reading would surface.

**Record names verbatim.** They are the index into the animation library, and they are how you ask
for the same thing again.

---

## 2 — The motion inventory (the Gate 0 deliverable)

Before building, produce this table for the sections in scope:

| Section | Trigger | Animation name | What it does, in plain words | Rung |
|---|---|---|---|---|

`Rung` is from the ladder in §4. Anything you cannot name, mark `?` and resolve it before building;
an unresolved `?` is how you end up inventing motion that already existed.

Also note, once, for the whole template:
- **Signature moment**: the one thing a visitor remembers. Usually the hero.
- **Choreography**: does content stagger in, or arrive at once? What is the rough delay step?
- **Restraint**: is motion everywhere, or saved for two or three moments? Award-level templates are
  almost always *restrained*; the density of motion is itself a design decision worth copying.
- **Easing character**: sharp and snappy, or long and floaty? One curve usually repeats throughout.

---

## 3 — Watching it actually run

Reading the panel tells you *what exists*; it does not tell you how it *feels*.

✅ **Designer Preview (▷) is allowed and is the right tool here.** Preview runs IX2. House rule #4
bans only the **"Enable custom code?"** preview; plain Preview is not that, and is unbanned.

So: Preview → watch the section → note timing, distance, easing, order. This is free and needs no
publish.

**What Preview will NOT show you:** embed `<script>`/`<style>` behaviour (house rule #12). If a
template's motion lives in a custom-code embed rather than IX2, Preview shows nothing and the
Interactions panel is empty; that combination is the tell that the motion is scripted.

---

## 4 — The reuse ladder

Take the first rung that applies. Never start at the bottom.

1. **Instance the component that already animates, then override its props.** The behaviour comes
   along, previews natively, and there is nothing to maintain. Best outcome by a wide margin.
   ⚠️ Not `duplicate_component`: the duplicate arrives with an empty Interactions panel (verified
   2026-08-17).
2. **Recreate the interaction in IX2** using the inventory: same trigger, same named actions, your
   own values. Stays native, stays editable by the user, previews in the Designer.
3. **Custom-code embed inside the component.** Correct when the effect is genuinely beyond IX2
   (infinite marquees, canvas/WebGL, scroll-linked physics, anything needing `requestAnimationFrame`),
   or when the user has asked for no interactions. Scope it to the component's own classes.
4. **Static**: only with the user's explicit agreement, and say what was given up.

⚠️ Rungs 1 and 2 were skipped entirely on 2026-07-31 in favour of rung 3. Embeds are not "more
professional" than IX2; they are the fallback. A no-IX2 delivery preference, where one exists, applies to
**what we ship on a client build**; it does not stop you **reading** the reference's IX to learn what
the motion should be.

### Cross-site portability — tested 2026-07-31

**Gate first: check BOTH sites' interaction engine.** Bottom of the Interactions panel → **Version**:
`Classic Interactions` or `Interactions with GSAP (new)`. It is per-site and switchable.

⚠️ **A Classic-era template's IX is meaningless in a GSAP-engine site.** Check this before planning
any motion reuse; it decides whether rung 1 is even available. Never flip the setting unprompted;
it is site-wide.

**What a cross-site paste actually did** (a Classic-engine template → a GSAP-engine target site):

| Survived | Died |
|---|---|
| Element tree, nesting, tags, text | **Interactions — panel came across empty** |
| Classes and their properties | Component links (instances arrive **unlinked**) |
| — | Some links; **custom fonts** |
| — | Colliding class *names*: renamed `X` → `X 2` |

Webflow announces the losses in a paste toast that then disappears. Read it.

🔍 **Still unknown: whether IX survives a cross-site paste between two `Classic` sites.** The test
above is confounded by the engine mismatch, and the toast did *not* list interactions among what it
dropped. Close it by setting a scratch site to Classic and repeating.
[flowy-manual/mcp-2.0.md](../flowy-manual/mcp-2.0.md) §14.

| Question | Status |
|---|---|
| Does `duplicate_component` carry IX bindings *within* a site? | 🔍 untested |
| Do IX bindings survive paste **between two Classic sites**? | 🔍 untested — the one that matters |
| Do they survive **Classic → GSAP**? | ❌ **No** — verified |

### Two mechanics that cost a session

- **Copy (`cmd+c`/`ctrl+c`) needs canvas focus.** Selecting via the **Navigator** and copying silently does
  nothing. Click the element **on the canvas** first.
- **`pbpaste` is the wrong probe.** Designer element copy does not touch the OS clipboard (it read
  `0` chars while the paste worked fine). `pbpaste` only applies to the `Copy to Webflow` button.

---

## 5 — Asking the user to publish the reference

**Rule (2026-07-31):** you may ask the user to publish a reference or template site when Designer
routes are exhausted; you never publish anything yourself.

A narrow, explicitly granted exception. Read it precisely:

✅ **You may ASK the user to publish a REFERENCE / TEMPLATE site**, so you can inspect the real running
page — when, and only when, the Designer routes are exhausted.

🚫 **Everything in house rule #2 still stands, unchanged:**
- You never publish anything yourself. Not the reference, not the target.
- You never publish, offer to publish, or hint at publishing **the target / client site**. That rule
  has no exception and this note does not create one.
- The ask is for the *reference you are learning from*, never for the thing you are building.

### Exhaust these first — most questions die here

| Need | Route | Publish needed? |
|---|---|---|
| Does this animate, and with what trigger? | Interactions panel | No |
| How does it feel: timing, easing, order? | Designer **Preview ▷** | No |
| Structure, classes, tokens, tags | MCP reads | No |
| How does it look, any breakpoint | Designer + device toggles | No |
| **Real DOM, `data-w-id`, published markup** | Live page | **Yes** |
| **Embed `<script>` runtime**, third-party libs, console | Live page | **Yes** |
| **Scroll-linked behaviour end to end**, performance | Live page | **Yes** |

### How to ask

One short message, containing:

1. **What I already tried**: panel read, Preview, MCP reads, and what each gave.
2. **What is still unanswered**, specifically.
3. **Why it needs a live page**, from the table above.
4. **Exactly what I will do** once it is up, and roughly how long.

Then **stop and wait.** Do not build a guess in the meantime that would have to be thrown away.

---

## 6 — Making it good, not just faithful

The bar is *award-winning*, not *accurate*. Reproduction is the floor.

**Copy the system, not the frame.** Take the template's easing curve, stagger step, motion density
and signature-moment discipline. Those transfer to any brand. The specific hero animation often does
not; it was designed for that content.

**Earn one signature moment.** One memorable thing, executed properly, beats six competent
transitions. Identify the reference's signature moment, then decide what the equivalent is for *this*
brand; it is rarely a copy.

**Motion must survive the content changing.** A hero animation tuned to a 4-word headline that breaks
on 9 words is a bug. Test every motion component with long copy, no image, and the smallest breakpoint.

**Always:** honour `prefers-reduced-motion`, keep hover effects on the element itself (one element,
morphed, never a duplicate-and-crossfade), and never let motion delay first paint of the headline.

### Variations that are worth building

Weak variants restate the same thing (`Left` / `Centered`). Strong variants change what the section
is *for*:

- **Density**: spacious hero vs compact hero for lower-funnel pages.
- **Emphasis**: type-led vs image-led vs data-led.
- **Tone**: light/editorial vs dark/cinematic. This is usually the highest-value variant axis and
  the cheapest to build if colour is tokenised.
- **Proof shape**: logos vs metrics vs quote.

Build the variant axis the *client* will actually switch between, and name variants after the job
they do, not the layout they use.
