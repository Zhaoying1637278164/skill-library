# flowy — converting CMS-driven back to static

> The inverse of [static-to-cms.md](static-to-cms.md), and it inherits that file's traps.
> Read both; the forward direction documents the mechanics this one runs backwards.

## THE DECISION RULE

**Not "is it currently CMS" — "does this component ship as a fixed design?"**

| Ships fixed → **static** | Stays bound |
|---|---|
| A 3-card feature grid the client never adds to | A blog list |
| A hero, a CTA band, a footer | A team directory, a case-study index |
| A pricing table with a fixed number of tiers | Anything whose item count is the client's to change |

**Converting a genuinely dynamic list to static is a downgrade you cannot undo cheaply.** If the
count might change, leave it bound. The forward file's closing point is the test: *add a CMS item
and the component grows*. If that behaviour is wanted, this conversion is wrong.

---

## 🚫 Snapshot first — this step is the guardrail, not paperwork

Removing the `DynamoWrapper` destroys the built structure and every binding on it. The collection
survives; the work does not. **There is no undo you can rely on.**

**1. Read the bindings.**

```
data_element_settings_tool > get_settings   type: "all_raw_settings"
```

on the wrapper and on **every bound child**.

🚫 **Never `all_resolved_settings`.** It reports a working CMS binding as `null`: a correct binding
reads as broken, and you will "fix" something that was fine.

**2. Read the resolved content**: `data_cms_tool > list_collection_items` for the item count,
per-item field values and asset ids, honouring the list's own `sort` and `filters` so the order
matches what renders.

**3. Write it to the session ledger**: item count, per-item values, asset ids, the full binding map,
and the class + attribute list at **all three levels** (`DynamoWrapper` / `DynamoList` /
`DynamoItem`). Keep it for the session.

**4. On a client site, duplicate the page first**: `data_pages_tool > create_page { duplicateOf,
draft: true }`. Note there is **no `delete_page` action in the MCP**, so name it obviously; removal
is a Designer action.

---

## Sequence

1. **Snapshot** (above). Do not proceed without it.
2. **Build N static siblings** in the Collection List's parent.
3. **Reuse the original element types.** If the bound title was a `Link`, the static one is a `Link`.
   Scripts key off element type and may call `preventDefault()` on it or include `a, button` in a
   hover-pause set; swapping it for a heading changes behaviour silently. Same rule as the forward
   direction, same reason.
4. **Reapply classes and hook attributes** to each static item from the snapshot. Both coexist; the
   `w-dyn-*` classes disappear with the wrapper and should not be recreated.
5. **Populate** each static item from the snapshot's per-item values. Images by `assetId`.
6. **Remove the `DynamoWrapper`**: `data_element_tool > remove_element`. One call takes all N
   dynamic items with it.
7. **Reload the Designer tab** (`?app=<token>` to keep the Bridge), *then* judge.
8. **Verify** against the snapshot.

---

## ⚠️ Index alignment, in reverse

The forward rule is **one Collection List per parallel group**. The reverse rule is its mirror:

> **All parallel groups must be materialised to the same count and the same order.**

A scripted component that pairs arrays by index (`backgrounds[i]`, `titles[i]`, `maskItems[i]`)
breaks silently if one group materialises 5 items and another 4, or if one comes out in a different
order. It will not error. It will show the wrong background behind the right title.

**Materialise every parallel group in one pass, from one snapshot, in the collection's sort order.**
Then count them and compare explicitly.

---

## ⚠️ The `:scope >` trap, inverted

The forward file's biggest trap is scripts using `:scope >` direct-child selectors, which forces the
track class and hook onto the `DynamoList` rather than the wrapper.

**Coming back the other way, that structure has to be undone correctly.** The Collection List *is*
the track in that arrangement, so the static rebuild needs the track class and its attribute on a
**real element you create**, with the items as its **direct** children. Rebuild:

```
<track div: original track class + track hook>
  ├ <item: item class + item hook>
  ├ <item …>
```

Get this wrong and `:scope > [data-item]` returns zero, exactly as it does in the forward direction:
same failure, opposite cause.

---

## ⚠️ The canvas lies until you reload

After removing the wrapper the canvas can keep rendering stale dynamic items, or render nothing at
all. **Reload the Designer tab before judging.** This is the same trap as the forward direction and
it is equally misleading here: it looks exactly like a failed conversion.

---

## Verification

| Check | How | Pass |
|---|---|---|
| Count | canvas-DOM probe via `javascript_tool` | equals the snapshot's item count |
| Content | read the static items' text | matches the snapshot, **in the same order** |
| Element types | `query_elements` | each static item's types match the original bound types |
| Hooks | `get_attributes` per item | every `data-*` hook from the snapshot present |
| No residue | `query_elements element_filter:{ style:"w-dyn-list" }` | no matches on the page |
| Parallel groups | compare counts across groups | identical |

Then [flowy-verify](../flowy-verify/SKILL.md).

---

## Open

- 🔍 **Whether un-CMS-ing leaves orphaned bindings** that later surface as prop or settings errors is
  **untested.** After conversion, re-read the parent's `all_raw_settings` and check for binding
  metadata pointing at a collection that is no longer rendered here.
- 🔍 **The whole procedure is unrun.** The decision rule, the snapshot guardrail and the traps are
  derived from the verified forward direction and from the destructive-operation analysis, but no
  CMS→static conversion has been executed end to end. Treat the sequence as reasoned, not observed,
  and log what actually happens the first time it runs.
