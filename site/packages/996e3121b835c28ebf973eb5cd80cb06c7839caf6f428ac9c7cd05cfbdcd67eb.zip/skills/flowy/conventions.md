# flowy — conventions: adopt what exists, impose only on a mess

> How to work out how a project is already built, and continue in its idiom.
> Profiles: [client-first.md](conventions/client-first.md) · [lumos.md](conventions/lumos.md) ·
> [mast.md](conventions/mast.md)

## The governing principle

**A project's existing system wins.** New work must be **indistinguishable in idiom** from what is
already there: class grammar, style architecture, component naming, variant usage.

Client-First, Lumos and MAST are **not the goal.** They are three grammars we happen to recognise,
which lets us skip deriving from scratch. A project with its own consistent bespoke system is not an
"unknown" to report; it is the normal case, and it gets followed.

🚫 **Imposing a convention on a project that already has one is a defect.**

## Two questions, never conflated

| Question | Decided by | Outcome |
|---|---|---|
| **Does this project have a system at all?** | the mess test, §1 | adopt · adopt-with-gaps · impose |
| **Which grammar is it?** | fingerprint scoring, §3 | recognised (load a profile) · derived (read it off the site) |

Scoring never decides adopt-vs-impose. **Both scoring branches end in adoption.** A weak score costs
one derivation, never a wrong convention.

---

## 1 — The mess test

The only thing that licenses proposing a system. Compute from the §2 name census plus element
enumeration on three probe pages, and report the numbers alongside the verdict so the threshold
stays auditable.

| Has a system | Is a mess |
|---|---|
| Median applications per class ≥2, and ≥40% of applied classes appear in ≥2 different sections | >50% of applied classes used exactly once, with no repeated chain to compensate |
| Power-law shape — a small high-frequency tier carries most applications | Flat distribution; almost everything used once |
| **A repeated structural chain** — same ordered parent→child relation in ≥3 sections across ≥2 pages | No repeating structural pattern between sections |
| ≤15 distinct spacing values, or spacing bound to variables | >25 distinct raw margin/padding values, mixed units, untokenised |
| ≥90% of multi-word names on one separator scheme | Hyphen, underscore, camelCase and spaces all present with no positional meaning |
| A finite, reused prefix/suffix tier — **any** prefix, bespoke included | Default names: `/^(div block\|section\|container\|heading\|paragraph\|text block\|link block\|image\|button\|list\|grid)\s*\d*$/i`, `/untitled/i`, `/^class \d+$/i`, `/-copy(-\d+)?$/i` |
| Components with instance counts >1, especially with props or variants | Near-duplicate families after stripping digits/`copy` — `hero`, `hero-2`, `hero-copy` |
| | No width owner — `max-width` scattered across unrelated classes |
| | Unmigrated template residue interleaved with hand-authored classes |

**The repeated structural chain is the strongest single signal, and it survives bad naming.**

### 🚫 Three things that must NOT count as mess

- **Zero variables.** ~~The official Client-First starter ships none, every value hardcoded.~~
  **superseded 2026-08-05**: the current `client-first-cloneable.webflow.io` ships a full two-tier
  token system (see [client-first.md](conventions/client-first.md) §4). The *rule* survives its
  evidence: absence of variables still never counts as mess, because token adoption is generational
  and an older project is not a disorganised one.
- **Zero registered components** beyond one.
- **Colour-literal token names** like `text-color-black`: Finsweet's own starter breaks Finsweet's
  own rule this way.

### Verdicts

| Verdict | Action |
|---|---|
| **Coherent but bespoke** | Derive and adopt. **The normal case.** Not a licence to introduce a named convention. |
| **Mixed — a system plus one messy corner** | Adopt the system. **Match the neighbourhood you are editing, not the site-wide plurality.** Say which is which in the plan. |
| **Genuine mess** | The only case where imposing is on the table, and it is **one direct question to the user** about which system, never a unilateral choice. |

**Calibration.** Client-First starter ≈215 styles, 15 combos all depth 2. Lumos 2.0.3 ≈233 global
classes (79 `u-`), 43 `_wrap`, 10 `_contain`, 23 components, ~160 tokens. MAST starter 36 components,
4 breakpoints. That is the shape of a systematic small site.

⚠️ **The numeric thresholds are proposed, not measured.** Three sites were examined, all official
starters, none a mess. Revise on first contact with a real disorganised project.

---

## 2 — Deriving the profile — the main road

Every project gets a derived profile. Recognition only lets you skip steps 3–7 by loading a prior,
and the prior is a hypothesis you verify, never a substitute for what the site does.

**The five parts you are reading off:** structure · naming grammar · style architecture ·
component practice · violations.

> Keep calls small (house rule #5). `include_properties` and `include_breakpoints` are expensive.
> `data_style_tool` and `data_variable_tool` require a `pageId` even though they read site-wide;
> pass any valid page id.

**Step 0 — Frame.** `list_sites` → `list_pages`. Check `get_page_metadata` for drafts: style-guide
pages are usually `draft: true`, and their classes are **lineage evidence, not production evidence**.
Pick three probe pages: home, an interior page, a utility page. Three is the minimum that
distinguishes repetition from coincidence.

**Step 1 — Name census.** `get_styles { query:"all", include_properties:false }`. Names only:
the highest-value call in the routine, and cheap without properties. From the raw list compute, before
querying anything else:

- total style count
- how many contain `_`, `-`, uppercase, or a space
- **leading tokens** up to the first separator → surfaces prefix tiers (`u-`, `cc-`, `is-`, `g_`, `col-`, `page_`)
- **trailing tokens** after the last separator → surfaces role/size vocabularies (`_wrap`, `_component`, `-lg`, `-xxhuge`)
- registered combo chains and their depth

**Step 2 — Structure by property, not by name.** The move that makes derivation work when you know
none of the names. Three separate calls:

```
query_styles { properties:[{name:"max-width"}],    include_properties:true }  → width tier
query_styles { properties:[{name:"padding-left"}], include_properties:true }  → gutter tier
query_styles { properties:[{name:"padding-top"}],  include_properties:true }  → vertical-rhythm tier
```

Look for **role purity**: a class carrying *only* left/right padding is a designed gutter owner; a
class carrying max-width plus eleven other things is a one-off. Client-First's `padding-global`
(gutters only) and Lumos 2.0.x's `u-container` (max-width *and* all four paddings) are both coherent.
**The output is a description, not a grade.**

**Step 3 — Verify the chain in the DOM.**

```
query_elements { element_filter:{ style:"<gutter class>" }, return_parent:"parent" }   → what's outside
query_elements { element_filter:{ style:"<gutter class>" }, children_depth:1 }         → what's inside
```

Per probe page. The chain is real when the same ordered parent→direct-child relation holds across
every instance on a page **and** repeats on a second page.

**Derive the relation, not the div count.** Client-First's docs describe a two-div chain; all 16
instances in its own shipped starter use three. The relation survived; the count didn't.

**Do not assume `<section>` for the full-bleed level.** In the Client-First starter the same
structural slot is occupied by `header`, `section` and plain `div`. Define it structurally (*the
nearest ancestor of the gutter owner that sets neither max-width nor horizontal padding*) and record
tag distribution as a separate observation.

**Step 4 — Grammar.** Write each separator rule as a *positional* claim, then try to falsify it.
Count conformers and exceptions in the census. ≥90% with exceptions clustered in one old page or one
family = **a rule plus residue**. 60% = **not a rule**.

**Step 5 — Tokens.** `get_variable_collections { query:"all" }`, then `get_variables` per collection
(`include_all_modes` only if >1 mode). Record collection/mode counts, cssName shape, literals vs
reference chains, which tiers are tokenised.

⚠️ **cssName shape is a WEAK corroborator, never an anchor (measured 2026-08-05):**

| Convention | Shape on its live reference site |
|---|---|
| Client-First | `--text-color--text-primary` → **`--group--name`** |
| Lumos | 85 × **`--group--name`**, 3 × `--_…---…--…`, 2 flat |
| MAST | `--_typography---h1--font-size` → **`--_collection---group--name`** |

**CF and Lumos are indistinguishable by shape.** Only MAST's underscore-lead form is distinctive,
and Lumos uses it too. ~~Record cssName shape (`--group--name` vs `--_collection---group--value` vs
flat)~~ as a discriminator — **superseded 2026-08-05.** Record it as description; score on
vocabulary and structure instead.

**Token presence proves nothing either way.** A 2023-era CF project ships zero variables; the
current CF cloneable ships ~30 in reference chains: same classes, same structure, same convention.

**What tokens DO tell you is the responsive architecture** (step 6), which is the read that actually
changes how you build.

**Step 6 — Breakpoints and pseudo states.** Re-query the structural classes with
`include_breakpoints:["medium","small","tiny"]`. You want the *mechanism*: per-class overrides,
`:root` token remaps inside `@media` in an embed, container queries, or fluid values and nothing at
all. Note the authoring direction. Then separately `include_base_pseudos:["hover","focus-visible"]`
on button/link classes: **default reads are base + `noPseudo`, so skipping this leaves hover/focus
conventions unobserved.**

**Step 7 — Components.** `get_all_components { includeProps, includeVariants, includeInstanceCount }`.
Record name format, grouping, whether configuration rides on **variants** or **enum props**, and
instance counts. Then read the two most-instanced definitions with `query_elements
{ scope_component_id }`.

⚠️ **Trap: page-level element queries do not descend into component definitions.** Classes used only
inside components look unused until you scope. **Any "unused class" conclusion drawn without this
step is wrong.**

⚠️ **Trap: `children_depth:0` does not suppress slot contents on `ComponentInstance` results.**
On a slot-composed site a broad instance query returns full slot subtrees and blows the response
ceiling. Scope to one page or one parent, and parse the saved tool-result file locally.
*(Observed 2026-07-29: two calls exceeded the limit at 127KB and 182KB.)*

**Step 8 — Custom code and attributes.** `data_scripts_tool > get_site_freeform_code` /
`get_page_freeform_code` / `get_registered_scripts`, then read embed elements in the DOM. In two of
the three known conventions **the project's real CSS lives in embeds inside a component, not in Site
Settings**, so empty Site Settings code is not evidence of no system. Then probe for an attribute
layer (`element_filter:{attribute_name:"data-theme"}`, or `get_attributes` on three section-level
elements to reveal the vocabulary).

### Deliberate pattern vs. accident

Apply all of these; any one alone misfires.

- **Recurrence across independent contexts**: ≥3 occurrences spanning ≥2 pages. One page is one person's afternoon.
- **Realised in a component definition**: anything inside a registered component with >1 instance is deliberate by construction.
- **Role purity**: one property family = a designed role; a grab-bag = a one-off with a name.
- **Closed vocabularies**: a finite, reused ladder or modifier set is a decision. An open-ended set of near-unique names is not.
- **Structural consistency beats naming consistency.** Names drift; the chain doesn't.
- **Majority-with-residue is normal, and residue is not the rule.** The Lumos 2.0.3 starter contains
  a class in its own V1 syntax; the Client-First starter contains `_container` where the convention
  says `_contain`. Small + older-looking + absent from newest pages = residue. **Do not adopt it and
  do not "fix" it.**

**Gap:** MCP exposes no per-style creation/modification timestamp, so a class cannot be dated
directly. Age is proxied by which pages use it. **Say so when you use it.**

---

## 3 — Fingerprint scoring: recognised vs. derived

Uses **anchors** (structural relations verified in the DOM or by property signature, never by name
alone) and **corroborators** (name/vocabulary families). Only patterns that survived reconciliation
against a real site are eligible.

> **RECOGNISED** = one verified anchor **AND** ≥2 corroborators from *different* families **AND** no
> anchor from a competing convention.
>
> Anything else (anchor with no corroborators, corroborators with no anchor, two conventions both
> scoring, name matches without a property check) is **DERIVE FROM SCRATCH.**

Anchors and corroborators per convention live in the profile files. Three standing constraints:

- **Absence is never evidence.** Never score down for missing `padding-section-*`, missing `is-*`,
  missing variables, missing component variants, missing `@media`, missing clamp values, empty Site
  Settings code, or a `<div>` where a `<section>` was expected. **Every one of those is false on at
  least one convention's own official starter.**
- **Never substring-match.** `section` hits `padding-section-large`, `fs-styleguide_section`,
  `u-section` and MAST's bare `section`. `container` hits all three conventions. Anchor prefixes at
  position 0 and role suffixes at the end.
- **The prior loses every conflict with the site.** Recognition pre-loads a hypothesis; you still run
  steps 2, 3 and 7. **Asymmetric cost:** deriving a site you could have recognised costs a handful of
  calls; misrecognising imports doctrine the project never followed and makes your new work the odd
  one out, the exact defect this file exists to prevent.

---

## 4 — Cross-convention collisions

Patterns in more than one convention that cause misclassification if scored naively.

| Collision | In | Discriminate by |
|---|---|---|
| **`page-wrapper`** | MAST + Client-First | Its **partner**: MAST → `page-main`; Client-First → `main-wrapper`; Lumos → underscore `page_wrap`/`page_main`. **Never score the wrapper alone.** |
| **`u-` utility prefix** | MAST + Lumos | **The largest collision.** Vocabulary only: `u-mb-sm`, `u-mlr-auto`, `u-img-cover`, `u-link-cover`, `u-mode-dark` → MAST; `u-hflex-*`, `u-vflex-*`, `u-gap-*`, `u-column*`, `u-h1..u-h6` → Lumos 2.0.x; `u-text-style-*`, `u-theme-*` → Lumos 2.1+. MAST embeds a **breakpoint infix** after `u-` (`u-md-d-none`); no Lumos generation does. |
| **`u-sr-only`** | MAST + Lumos 2.1+ | Exact-token collision. **Worthless; do not score it.** |
| **`is-` combos** | Client-First + Lumos | 🚫 **WORTHLESS for scoring; do not use. Reversed 2026-08-05.** ~~Abundance runs counter to intuition: CF uses them systematically (15); Lumos 2.0.3 has exactly two, so heavy `is-` pushes toward Client-First.~~ Falsified on `timothyricks.com`: **the Lumos author's own site carries 15** (`is-hidden is-desktop is-mobile is-code is-thumb is-visual is-title is-brand-2 is-brand-3 is-no-color is-tags is-alt is-1 is-2 is-3`) plus `.button.is-bright:hover`, against CF's 12. The old rule pointed the wrong way. **What still holds:** MAST uses `cc-` instead, and *that* remains its sharpest single discriminator. |
| **Underscore as separator** | all three | Depth + terminal vocabulary. Lumos ≤3 underscores terminating `_wrap`/`_contain`/`_layout`; Client-First one underscore terminating `_component`/`_item`/`_list`; MAST hyphenated multi-word segments both sides, co-occurring with `cc-`/`col-`. Confirm with a structural anchor. |
| **token `section`** | all three | `padding-section-large` / `fs-styleguide_section` (CF), `u-section` (Lumos 2.1+), bare `section` (MAST) |
| **token `container`** | all three | bare `container` (MAST), `container-small\|medium\|large` (CF), `u-container` / `{group}_container` (Lumos) |
| **token `styleguide`** | all three | `fs-styleguide_*` (CF), `styleguide_*` (Lumos 2.0.3), `styles__` (MAST). All on pages meant to be deleted. |
| **`small`/`medium`/`large`** | CF + MAST | Position: CF full words as a name segment (`container-large`); MAST abbreviated postfix (`u-mb-lg`). **Lumos's scale is `none\|small\|main\|large`: `main` as a size step is a Lumos-only tell.** |
| **A component holding the project's CSS embeds** | all three | CF `Global Styles`, MAST `Custom Code`, Lumos `page_code_wrap`. The *pattern* is worthless; only the class names inside discriminate. |
| **`data-*` on structural elements** | Lumos + MAST | What they control: MAST → animation only (`data-animate`); Lumos → theme, padding, button style. And whether a site-level embed selects them. |
| **bare `row` / `col`** | MAST, vs Bootstrap templates | Webflow's legacy grid carries `w-` (`w-row`, `w-col`), so `col-lg-8` with no `w-` stays a strong MAST signal. ⚠️ **Reasoned, not observed.** |

---

## 5 — Imposition order

Only after a **genuine mess** verdict, and only after asking.

1. **Lumos**, the default. The most advanced of the three.
2. **MAST.**
3. **Client-First**, on request, or where the project is already partly CF and adoption is the better half of the decision.

### Recognition coverage ≠ imposition preference

Different lists; conflating them is a trap. **Client-First is the convention encountered most often
in the wild**, so its fingerprint must be the strongest, even though it is last for imposition.
We recognise CF constantly; we choose Lumos.

---

## 6 — ⚠️ Which conventions MCP can actually build (verified 2026-08-05)

**The three conventions are not the same shape of work, and the difference is a hard tool limit.**

`update_style` silently rejects `clamp()`, `min()`, `max()`, `dvw` and `dvh`, and **one rejected
property voids the entire call** ([flowy-manual](../flowy-manual/SKILL.md)). Measured against each
convention's live reference site:

| Convention | Fluid values | MCP-buildable? |
|---|---|---|
| **Client-First** | None — static rem ladders (`.container-large` 80rem, `.padding-section-large` 8rem, `h1` 4rem with per-breakpoint overrides) | ✅ **Fully.** Every structural value is a plain rem |
| **MAST** | `.container` is `max-width: min(…)`; **every** heading is `clamp()` off `--_layout---fluid--min/max` | 🚫 **No.** Token tier and container must be authored by hand |
| **Lumos** | `--site--margin`, `--section-space--main`, `--h1--font-size` … all `clamp()` | 🚫 **No.** Same |

**The consequence for a build:**

1. **Author the token tier first, outside MCP**: in the Designer's variable panel, or as a `:root`
   block in a `<style>` embed. Both MAST and Lumos put nearly all fluid maths in tokens, which is
   what makes this tractable: the fluid values live in ~30 variables, not scattered across 200
   classes.
2. **Then build classes with MCP**, referencing the variables via `variable_as_value`. A class
   saying `max-width: var(--site--width)` writes fine; the *token* holding the `clamp()` does not.
3. **Never send a `clamp()` inside a batch of other properties.** It voids the good ones too, and
   reports success.

🚫 **Do not "simplify" a fluid convention into static rem values to make it MCP-writable.** That
produces a page that matches no convention and that the next session will misclassify. If the
project is MAST or Lumos, the Designer hand is not optional; it is part of the build.

---

## Read the published CSS — it is the strongest evidence available

**Verified 2026-08-05, and it changed four rulings in this file.** The compiled Webflow stylesheet of
a published site carries three things the Designer and MCP both hide: compiled `:hover`/`:focus`
states, every `@media` block, and the resolved `:root` token graph. One `curl` of
`…website-files.com/…/<site>.webflow.shared.<hash>.min.css` is worth a dozen MCP reads.

```
Find it:  [...document.querySelectorAll('link[rel=stylesheet]')].map(l=>l.href)
```

⚠️ **If CSS optimisation is on, the `.shared.` file is Webflow's base only** and the project's real
classes live in the per-page `…<pageid>.<hash>.opt.min.css`. MAST's shared file yielded 6 classes;
its page file yielded 193. Check both before concluding a site has no system.

⚠️ **The per-page `.opt.` file only contains classes used on that page**: never read a class census
off it and call it the project's vocabulary.

---

## Standing gaps

- **Mess-test thresholds are proposed, not measured**: no disorganised project examined yet.
- **No class dating**: MCP exposes no per-style timestamp.
- **No usage counts**: no single call returns per-style usage; assemble by enumerating elements per
  page, and it under-counts unless you scope into component definitions (step 7 trap).
- ✅ ~~**Hover/focus conventions unobserved** on all three reference sites.~~ **Closed 2026-08-05**
  by reading published CSS. Client-First defines **zero** states (verified absent, not merely
  unobserved), so a CF build has no state convention to inherit. MAST: 11, with `:focus-visible` +
  `outline-color: var(--primary--accent)` applied systematically. Lumos: 38, colours drawn from the
  `--swatch--*` tier. Details in each profile's §4.
- ◐ **Client-First global chrome**: ~~starter ships no navbar~~ **half-closed 2026-08-05**: a full
  `nav_*` family is present and documented in [client-first.md](conventions/client-first.md) §2.
  **A footer is still genuinely absent**: no `footer*` class exists anywhere in its CSS. CMS
  wrappers remain unobserved, so a `blog_list`/`blog_item` pattern is still unmodelled.
- **MAST Build Mode never read on a live site.** Every MAST observation here is Design Mode; the
  style-guide site carries no `#build-mode-page-slot`. The Build-Mode component/prop surface is
  still derived from the Designer read of 2026-07-29, not from published output.
