# presets — what a Webflow element brings with it

> Written 2026-08-02 after a live page shipped with a row whose title was crushed into a 60px
> track. Everything here is verified on `a portfolio build` unless explicitly marked otherwise.

**An element preset is not an empty div.** It arrives with built-in `w-*` classes, sometimes with
child elements, and with CSS you did not write and *cannot see in the Style panel*.

---

## The three layers on any Webflow element

| Layer | Example | Visible to `query_styles`? |
|---|---|---|
| 1. Your custom class | `.list_item` | ✅ yes, and **only** this |
| 2. Webflow's built-in preset class | `.w-layout-grid`, `.w-button`, `.w-nav` | 🚫 no |
| 3. Tag defaults | `<kbd>`, `<input>` | 🚫 no |

✅ **Verified 2026-08-02:** `create_style {name, properties:[{display:grid}]}` stores and reads back
**exactly** `display:grid`; MCP injects nothing of its own. So if the canvas disagrees with what
`query_styles` returns, the difference came from layer 2 or 3, never from the style write.

🚫 **A style that reads back clean can still be laying out wrong.** Read the rendered result.

---

## The base stylesheet ships in two halves

Verified by fetching the published `*.webflow.shared.*.css` and listing its `.w-` classes:

- **Always shipped, used or not:** `normalize`, `.w-col-1…12` (plus `-medium` / `-small` / `-tiny`),
  `.w-nav*`, `.w-tab*`, `.w-slider*`, `.w-dropdown*`, `.w-button`, `.w-checkbox`, `.w-form*`,
  `.w-background-video`, `.w-code-block`, `.w-clearfix`.
- **Emitted only when a matching preset element exists on the site:** the `w-layout-*` family:
  `w-layout-grid`, `w-layout-blockcontainer`, `w-layout-hflex`, `w-layout-vflex`, `w-layout-layout`.

**One-line test for "is a preset default my problem?":**

```sh
curl -s "$(curl -s https://<site>.webflow.io/ | grep -o 'https://[^"]*\.css' | head -1)" \
  | grep -o '\.w-layout-[a-z-]*{[^}]*}'
```

Empty output means the site contains **no** such preset, so no preset default can be your bug;
go look at your own class. That check is what turned a wrong diagnosis into the right one below.

---

## Grid: the 2×2 that catches everyone

The Designer's **Grid preset** carries `.w-layout-grid`, which defaults to **2 columns × 2 rows**
with 16px gaps. Adding a fifth child does not add a column; it overflows into implicit rows.

🚫 Do not "fix" it by adding children until it looks right.
✅ Pin **all four** axis properties on your own class, every time:

```
grid-template-columns   grid-template-rows   grid-auto-flow   grid-auto-columns
```

⚠️ **`display:grid` set via MCP on a `DivBlock` does not carry `w-layout-grid`.** It is a plain CSS
grid and the 2×2 default never applies. Verified: this project's six grids are all MCP-made, and the
published CSS contains **zero** `grid-template` rules outside the project's own classes.

So there are two different bugs that look identical, and they need opposite fixes:

| Symptom | Real cause | Fix |
|---|---|---|
| Designer-added Grid, children overflow after the 4th | `.w-layout-grid` 2×2 default | Pin all four axis properties |
| MCP-made grid, children land in the wrong tracks | **your own template** | Match the track list to the child count |

---

## The failure that *looks* like a preset bug and isn't

✅ Verified 2026-08-02, live: `.list_item` was `grid-template-columns: 60px 1fr 130px 70px` (four
tracks, written for a four-part row) applied to rows that only ever had **two** children. Child 1
(`.list_title`) landed in the 60px track and wrapped to five lines; child 2 took `1fr`; tracks 3 and
4 sat empty. It reads exactly like "Webflow's grid default is fighting me." It was not.

It also carried `justify-content: space-between`, which does nothing once a `1fr` track exists:
a leftover that made the intent harder to read.

> **Rule: whenever you write `grid-template-columns`, count the children in the same breath.**
> Put the count in the style's reason for existing. If the count can vary (CMS, optional elements),
> do not use a fixed track list at all; use `grid-auto-flow` + `grid-auto-columns`.

---

## Presets that ship child elements

Never hand-build these and never flatten them; their JS keys on the structure:

**Slider** (mask, slides, arrows, nav) · **Tabs** (menu, links, content, panes) · **Dropdown**
(toggle, list) · **Navbar** (brand, menu, links, button) · **Form** (form block, success, error,
Name/Email inputs, submit) · **Lightbox** · **Background Video** · **Collection List** (wrapper,
list, item, empty).

⚠️ A `<form>` passed to `data_whtml_builder` **or** `BY_CUSTOM_TAG` always becomes a full Form Block
with Name/Email/Submit plus success and error blocks. For a bare input row, use a `DivBlock` and
handle Enter in JS.

⚠️ `CMSCollection` auto-creates `DynamoList` + `DynamoItem` + `DynamoEmpty`, and the empty state
ships the literal string **"No items found."** Hide it or rewrite it, or it publishes as-is.

---

## The MCP builder enum is a subset of the preset catalogue

`data_element_builder.type` offers ~35 types. The Designer's preset reference lists 100+. Anything
missing (**Grid**, Quick Stack, most e-commerce) has to come from the Designer hand or a clipboard
paste.

⚠️ [developers.webflow.com/designer/reference/element-presets](https://developers.webflow.com/designer/reference/element-presets)
is an **index only**. Checked 2026-08-02: it lists the presets and documents **no** default styles,
child structure, or attributes for any of them. Defaults are established by experiment, and the
results belong in this file.

---

## Checklist before shipping any layout element

1. Both grid axes pinned, plus `grid-auto-flow` and `grid-auto-columns`?
2. Track count == child count, **at every breakpoint**?
3. Is `justify-content` doing anything? With a `1fr` track present it cannot; delete it.
4. Did I read the **rendered** result (canvas iframe or published page), not the Style panel?
