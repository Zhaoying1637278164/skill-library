# flowy — slots

> Making a component that accepts **other components inside it**, chosen per instance.
> Read [componentize.md](componentize.md) first: slots are one part of the prop surface, not a
> separate system. Routing lives in [SKILL.md](SKILL.md).

## What a slot is, and when it beats a prop

A prop swaps a **value** (text, link, image). A slot swaps **structure**: the client drops whatever
component they like into a hole you left for them.

| The client needs to… | Give them |
|---|---|
| Change the heading text | `textContent` prop |
| Choose Dark or Light | a **variant** |
| Show or hide the badge | `boolean` prop |
| **Put any card / CTA / form of their choosing inside this region** | **a slot** |

The tell: *you do not know, at build time, what will go in there.* A three-card grid where the cards
are always Capability Cards is a nested-instance job. A section that should accept *any* card, or two
cards, or five: that is a slot.

⚠️ **Do not reach for a slot when a nested instance is right.** A slot hands the client an empty hole
and the responsibility to fill it. If there is a sensible default arrangement, nest real instances and
expose their props instead.

## Creating a slot — the prop is derived, not created

`create_prop` has **no `slot` type**. You do not create the prop; you create the element it stands
for, and the prop appears.

```
data_element_builder
  scope_component_id: <the component definition>
  parent_element_id: <where the hole goes>
  element_schema: { type: "ComponentSlot" }
```

✅ **Verified**: the call returns `type:"Slot"`, and a `slot` prop appears on the component.
Same derived-prop family as `variant` (created via `create_variant`, never via `create_prop`); see
[componentize.md](componentize.md) → *Prop types: direct vs. derived*.

**Give it a display name.** `data_element_tool > set_display_name` on the slot element; the client
sees this label where they drop things, so name it in their language: `Cards`, `Footer CTA`, not
`slot-1`.

## Filling a slot

This is where the ceiling is, and it is worth knowing **before** you design the component.

| Where the instance lives | Can MCP fill its slot? |
|---|---|
| A component instance **on a page** | ✅ **Yes — `data_component_builder action_type:"insert_in_slot"`.** Verified 2026-08-23 |
| A component instance **nested inside another definition** | ✅ **Yes**, same call with `scope_component_id`. Verified 2026-08-23 |

### ✅ Resolved 2026-08-23 — `data_component_builder` fills slots

**Use `data_component_builder`, not `data_element_tool`.** Its action schema is
`{build_label, action_type: 'insert_in_element' | 'insert_in_slot', parent_element_id,
creation_position: 'append'|'prepend'|'before'|'after', component_schema, scope_component_id?}`.
`insert_in_slot` is the route the 2026-07-29 and 2026-08-17 runs never tried: both were driving
`insert_component_instance` on `data_element_tool`, which has no slot-targeting parameter and
refuses an instance as anchor. That refusal is real and still stands — it just is not the whole
picture.

Verified 2026-08-23 on Lumos V222: four `Accordion Item` instances placed into an `Accordion List`
instance's slot over MCP, inside a component definition (`FAQ Home`). Readback shows them as
`slots[0].children` on the instance.

The rows below are **superseded** for slot filling. They remain correct for
`data_element_tool > insert_component_instance` and for reordering.

### 🚫 The verified ceiling — nested instances

`insert_component_instance` refuses to anchor on a component instance:

> `Cannot insert relative to a component instance — the Designer rejects inserts that use a component
> instance as the anchor. Target the instance's parent element or an element inside the component
> definition instead.`

The instance *exposes* its slot in readback (`slots: [{ id: {component, element, slot}, … }]`), but
`parent_element_id` accepts only `{component, element}`. **There is no slot-targeting parameter.**
So a wrapper chain where every level is an instance cannot be assembled over MCP; that is what makes
the Designer paste route ([componentize.md](componentize.md) §A2c) necessary rather than merely
convenient.

The same restriction bites on the page: `insert_component_instance` and `move_element` both refuse an
instance as the anchor, so **page-level component instances cannot be reordered relative to each
other over MCP** (verified 2026-07-29; `move_element` surfaced it as a generic
`An internal error occurred`). Append to the parent and reorder in the Designer.

### ~~Resolved 2026-08-17 — page-level slot filling is a Designer-hand job~~ (superseded 2026-08-23)

Run against MCP 2.0.1 on a live site. Slots are **addressable**: `insert_component_instance`'s own
response (and `query_elements`) return `slots[]` with a composite `{component, element, slot}` id.
Filling is **refused on every route**: the instance as anchor ("the Designer rejects inserts that
use a component instance as the anchor"), the slot's element id at page scope (not found — the API
accepts only `{component, element}`), and the slot element inside the definition ("Missing
element"). Slot **creation** works via `data_element_builder type:"ComponentSlot"`. The fill is the
Designer hand: select the slot on canvas and drag/paste the component in
([two-hands.md](two-hands.md)).

The original test plan, kept for re-verification when Webflow ships slot APIs (house rule #13):

1. Build a component with one `ComponentSlot`; place an instance on a page.
2. `data_element_tool > query_elements` on the instance → read the `slots` array; note whether the
   slot id carries a third `slot` key.
3. Try `insert_component_instance` with `parent_element_id` set to the **slot's** id object.
   - If it accepts → slots are fully MCP-buildable. Record the exact id shape.
   - If it refuses with the anchor error → the fill is a **Designer-hand** job: select the slot on
     canvas and drag/paste the component in ([two-hands.md](two-hands.md)).
4. Either way, confirm in the Designer that the dropped component renders inside the slot.

## Verification

| Check | Call | Pass condition |
|---|---|---|
| Slot element exists | `query_elements` with `scope_component_id` | an element of type `Slot` |
| Slot prop derived | `get_component` + `includeProps` | a prop of type `slot` |
| Client-facing label | `get_display_name` | reads in the client's language, not `slot-1` |
| Filled correctly | `query_elements` on the instance | `slots[].children` lists the inserted instances |

## The client test

Open the Add panel and read the component as someone who has never used Webflow. **An empty slot with
no label is a trap**: they will not know what belongs there. Name it, and say in the component
description what it expects: *"Drop one or more Capability Cards here."*
