# flowy — session lifecycle

> Track N is thin by design. Track E is the full engine for already-built sites.
> Routing lives in [SKILL.md](SKILL.md); hard rules in [house-rules.md](house-rules.md).

## Principles

1. **General engine, discovered specifics.** Nothing site-specific lives in this skill. Site name,
   pages, classes, fonts, embeds, CMS usage: all discovered at intake and recorded per-site.
2. **Local-first recon (Track E).** The unzipped export is token-cheap ground truth. Read and grep
   local files for structure, class inventory, and page IDs rather than burning MCP queries.
3. **One MCP call, one target, one ledger row.** Every write in the structure/style/attribute/embed
   lanes touches one thing per call: crash-resumability beats speed. CMS data writes may batch
   (drafts-only), via the delegate skills when present.
4. **Every change is ledgered, whichever hand made it**: MCP writes, Designer-hand tuning, and
   in-canvas embed edits alike. The ledger is what makes crashes, compaction, and mirroring safe.
5. **Plan before write.** No Webflow write before the user approves the plan in-session.

## Track N — new build

Connections ([SKILL.md](SKILL.md) session start) → plan → execute → verify → present. No export, no
mirror phase, no local-first recon.

`_flowy/` lives in whatever folder the user names. If they name none, the plan and ledger are session-only
and **crash-resume is degraded**: state that plainly rather than pretending otherwise.

## Track E — already-built site

### 1 — Intake (verify, don't set up)

The user starts with the export already downloaded, unzipped, and opened as the workspace. Intake verifies.

0. **Exportability.** Site can't export code (Ecommerce/Users, or a plan without export)? → mirror-less
   mode ([surfaces.md](surfaces.md)); everything else still applies.
1. **Workspace present.** Root `.html` files carrying `data-wf-site`/`data-wf-page` on `<html>`: that
   attribute pair is the detector, never stylesheet naming. Read `data-wf-site`; an existing
   `_flowy/site-notes.md` must match it. Create `_flowy/` + `site-notes.md` if absent. Missing or
   ambiguous → stop and ask.
2. **Connections up** per [SKILL.md](SKILL.md), plus: the open Designer's site must match the export's
   `data-wf-site`. **MCP auth is an action**: unauthenticated or wrong site → stop and re-authorize.
   Site mismatch is a hard stop; never write across it.
3. **Version check.** Compare the export's `Last Published` (line-1 comment) against the site's
   current publish state, and local page files against the MCP page list. Match → Phase 2. Drift →
   sync-down first.

**Sync-down.** Webflow is the source of truth; local catches up. List the drift, record it in
`plan.md` as `- [ ] S<n> — sync-down: …`, then execute per [local-mirror.md](local-mirror.md) with
values from fresh MCP reads. Sync-down is standing-approved maintenance: it does not wait for plan
approval (Phase 2 approval covers *new* changes only).

### 2 — Recon & plan

1. Map the export locally → `_flowy/site-map.md`: pages + `data-wf-page` map, site ID, stylesheet
   inventory, embeds, locale subtrees, and any MCP page with no local file (*unmapped*).
2. Draft `_flowy/plan.md` with numbered checkbox items (`- [ ] P1 — …`), one per change, each tagged with
   its lane: **structure** · **style** · **attribute** · **cms** · **embed**. CSS-ladder items are
   resolved **at planning time** into the winning rung's lane ([css-ladder.md](css-ladder.md)). Only
   those five lanes reach Phase 3.
3. Present the plan; **The user approves before any write.**

### 3 — Execute (lane order: structure → style → attributes → cms → embeds)

- Every successful write appends a ledger row **immediately**, with its plan-item ref in `intent`.
- **Batch = all writes for one plan item, or one lane on one page, whichever is smaller.** At each
  boundary: verify, stamp `verified`, tick off completed plan items.
- **Verification by hand:** MCP rows → [flowy-verify](../flowy-verify/SKILL.md).
  `designer>style-tune` rows → `query_styles include_properties:true` readback of the tuned class.
  `chrome>embed-edit` rows → the in-editor SHA check in [embeds.md](embeds.md).
- Designer stuck → unstick it. A blocked Designer is never a licence to MCP-design.

### 4 — Test & present

1. Designer preview with **"Enable custom code?" OFF**: this session's native changes must stand
   alone. Pre-existing embed-dependence found here is a site-local quirk for `site-notes.md`, not a
   failure to repair.
2. Embed surface = byte-exact verification per [embeds.md](embeds.md). **Never** the custom-code
   preview.
3. Full [flowy-verify](../flowy-verify/SKILL.md) pass → present findings → **STOP.**

**Revision rounds.** Client feedback re-enters as a mini-cycle, never ad-hoc fixes:
1. Pull the **full thread from its source**, not a screenshot of the comment. The draft the client
   references usually lives wherever they filed it (task board, email thread); that is the ground
   truth.
2. **Diagnose before choosing the fix.** Measure the artifact the client actually saw. A point that
   *sounds* like a known property ("labels not aligned" ≠ "wrong padding") may have a structural root
   cause.
3. Present an **interpretation summary** (one numbered read per feedback point, naming every
   interpretation call) and get the user's approval. This is the Phase-2 gate in revision form.
4. Then a normal batch: new plan-item prefix, execute, verify, ledger.

### 5 — Mirror to local

- Gate: The user approves the changes on Webflow. Rejected work never reaches the mirror: revert on
  Webflow via fresh ledgered writes, or mark rows `mirrored: rejected`.
- Approved → hand-edit local export files per [local-mirror.md](local-mirror.md), driven by the
  ledger. Mirrored **values** come from a fresh MCP read at mirror time, never from `intent` text.
- **Catch-all:** new pages get files hand-minted; genuinely counterpart-less changes (CMS item
  content, `js/` runtime, regenerated image variants) → `mirrored: n/a`.

### 6 — Session end

Per [house-rules.md](house-rules.md) #11. Webflow-general → `flowy-manual`. Site-local →
`_flowy/site-notes.md`. Never into the skill.

## Working folder (Track E)

**The export folder the user points at IS the working folder: work in place.** Never move, rename, or copy
it into a managed workspace.

```
<export folder>
  (export contents)
  _flowy/
    site-notes.md   # durable: data-wf-site ID (identity key), live domain, site-local quirks
    plan.md         # approved plan
    ledger.md       # append-only write ledger
    site-map.md     # page-ID map, stylesheets, embeds, locales, Last Published
```

- **Identity is guarded by `data-wf-site`.** Mismatch against an existing `site-notes.md` = hard stop.
  Never mix two sites' histories in one `_flowy/`.
- **Fresh export of a known site:** copy the previous `_flowy/` into the new folder. Notes,
  unfinished plan items, and ledger history survive.
- **Resume anchor:** read `plan.md` + `ledger.md`; next action = first unchecked item. Never re-guess.
- **Ledger state ≠ current state.** The ledger says what *was* done; it does not promise Webflow still
  looks like that. The user edits between sessions. **Re-query every write target fresh at the start of each
  batch**: never aim a write at an ID remembered from a prior session. (Verified twice: a built
  section became a component between sessions and silently invalidated page-level queries.)

## Ledger format

```
| # | time | lane | hand>action | target | page | intent | verified | mirrored |
```

- `hand>action`: e.g. `mcp:data_element_builder>insert`, `mcp:data_element_settings_tool>set_settings`,
  `designer>style-tune`, `chrome>embed-edit`, `clipboard>paste`.
- `target`: MCP → the ID **returned by the call**; Designer-hand → class or element ID from
  site-map.md. The resume key either way.
- `verified`: `✓`/`✗` + time. On `✗` the fix is a **fresh write and a fresh row** referencing the failed
  row's `#`. Failed rows are never edited.
- `mirrored`: blank until Phase 5, then `✓` / `rejected` / `n/a`.

## Error routes

- MCP timeout / Bridge disconnect → re-foreground, `?app=<token>` relaunch ([SKILL.md](SKILL.md)).
- `designer_tool` times out but `data_*` calls work → the Designer tab is backgrounded. Only
  Designer-session tools need it foregrounded.
- Backgrounded tab reports zero viewport → foreground before measuring.
- MCP on wrong site / unauthenticated → hard stop, re-authorize.
- Element query returns 0 matches for content that visibly exists → the subtree was likely
  componentized. Pass `scope_component_id` to walk the component's tree. Class and style writes stay
  global either way.
- Ambiguous / non-Webflow workspace → stop and ask.
- Designer genuinely undrivable → stop and surface it.

## Delegates

**Optional.** Webflow publishes its own skill pack at
[github.com/webflow/webflow-skills](https://github.com/webflow/webflow-skills). flowy does not
require it and does not install it. If it happens to be present, delegate to these
rather than reimplementing:

`webflow-mcp-asset-audit` · `webflow-mcp-cms-collection-setup` ·
`webflow-mcp-custom-code-management` · `webflow-mcp-bulk-cms-update` (drafts-only) · the audit family
(`site-audit`, `link-checker`, `accessibility-audit`, `cms-best-practices`, `review-comments`).

⚠️ `webflow-mcp-safe-publish` is a guarded checklist, **not** an exemption: house rule #2 still
applies, and the publish hook still fires. Delegating to it does not authorise a publish.

🚫 Do not go hunting for Code-Components / DevLink skills. They were evaluated and set aside; the
capability they wrap is not what flowy needs.
