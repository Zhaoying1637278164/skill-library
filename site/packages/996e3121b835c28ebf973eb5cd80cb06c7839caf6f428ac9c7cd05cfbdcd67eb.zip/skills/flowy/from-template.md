# from-template — reproducing a reference design as client components

The recurring job: *"here is a template, here is a brand, rebuild those sections as components on
another project."* This file is the **order of operations**. [rebrand.md](rebrand.md) covers the
token/asset swap once you know what you are swapping; this covers everything before that.

> Written 2026-07-31 after a build that produced a technically sound library which **did not look
> like the reference**. Root cause: tokens were read via MCP, the pages were never opened. Every rule
> below is a fix for a specific miss in that session.

## The one-line lesson

**Reading a template's variables is not reading its design.** Colour and type tokens said
`whitesmoke` + `Inter`; the actual pages were dark, cinematic and centred. Tokens are the palette,
not the painting.

**And a handed-over spec is not the artifact either.** A handed-over spec file written by another tool
(2026-08-02) carried a `:root` token block that matched *neither* theme in the actual prototype; it
specified a blue accent for a design with no blue in it. A spec is evidence about intent. Only the
rendered thing is evidence about the design.

---

## Gate 0 — Look at the reference before you build anything

🚫 **Do not create a single style until you have SEEN the reference pages.** Not the style panel:
the pages, rendered.

⚠️ **The reference is often NOT a Webflow site.** It may be a prototype HTML file, a live URL, a
Figma frame, a video. Gate 0 is about **the rendered artifact, whatever holds it**. If there is no
Designer to open, the gate still applies, it just changes how you open it. Missing this cost a full
rebuild on 2026-08-02: the reference was a single-file prototype, so "open the reference Designer"
read as not-applicable, and its markup and data arrays got read *instead of* its design.

For a local file, serve it and look (under two minutes):

```sh
cd <dir> && python3 -m http.server 8787   # then navigate + screenshot, and read the
                                          # computed tokens off :root in the live DOM
```

Mandatory, in this order:

1. **Open the reference, rendered, in a tab.** Webflow reference → the Designer renders it fully
   without publishing: `<shortname>.design.webflow.com`. Anything else → serve it or load the URL.
2. **Screenshot 3–5 real pages**, not the style guide. On a multi-home template, the home variants
   are where the design language lives.
3. **Screenshot the section you were asked to reproduce**, at desktop *and* mobile device toggles.
4. **Read the Interactions panel on the hero and on any section whose name implies motion.**
   See Gate 1.
5. Only then read tokens, classes and structure via MCP.

**Deliverable of Gate 0:** a short written description of the design language: *dark or light,
centred or left, dense or airy, image-led or type-led, sharp or soft, what the buttons look like,
what the nav does.* If you cannot write that paragraph, you have not looked.

### The tell that you skipped Gate 0

You built something that follows best practice, uses the right tokens, and looks nothing like the
reference. Generic-but-correct is the failure signature.

---

## Gate 0b — Compare the two type systems before you copy one spacing value

**Spacing numbers are only meaningful inside the type system they were authored in.** Two projects
can share font, size, weight, tracking and column width and still render different gaps, because a
gap is the author's explicit spacer **plus whatever leading each line box contributes.**

The switch that decides this is **cap-height trimming** (text-box trim, "text crop", `leading-trim`).
A trimmed element's box is cap-top to baseline; an untrimmed one carries half its leading above the
cap and half below the baseline. Between a heading at `1.3` and body at `1.75`, that is ~27px of
optical gap at a 58px heading that exists in one system and not the other.

Check both sides before porting anything (~30 seconds, in each rendered page):

```js
const e = document.querySelector('h2');
const cs = getComputedStyle(e);
JSON.stringify({
  boxH: e.getBoundingClientRect().height,       // == line-height when untrimmed,
  lh: cs.lineHeight,                            // ~0.7em when trimmed
  before: getComputedStyle(e, '::before').marginBottom,
  after:  getComputedStyle(e, '::after').marginBottom,
});
```

Negative pseudo margins, or a box height well below the line-height, means trimming is on.

Then pick one, before building:

| Source | Target | Do this |
|---|---|---|
| untrimmed → untrimmed | | copy spacing verbatim |
| untrimmed → **trimmed** | | **turn the target's trim off** for the ported page. Copying the source's spacing into a trimmed target closes every heading-to-body gap to exactly your margin, and text collides |
| trimmed → untrimmed | | add each element's half-leadings back, or turn trimming on at the target |

Turning trim off is nearly always the cheaper half of that table for a faithful port: it holds at
every viewport for free, whereas re-deriving gaps means recomputing two half-leadings that scale
with fluid font sizes while your margin token does not.

Frameworks that trim by default include **Lumos v2.1+** (`.u-text-trim-off` is its per-element
switch; see [conventions/lumos.md](conventions/lumos.md) §8). Client-First does not trim.

**The tell that you skipped this gate:** every heading on the page sits directly on top of the line
below it, and the spacing looks fine in isolation on any single element you inspect.

---

## Gate 1 — Find the interactions. The MCP hand cannot do this.

> **Full field guide: [interactions.md](interactions.md)** — the motion inventory table, the reuse
> ladder, Preview ▷, when to ask the user to publish the reference, and the craft bar. This gate is the
> short version; that file is what you actually work from.

⚠️ **`data-w-id` is emitted at publish/export. It does not exist in the Designer.**
Verified 2026-07-31: `query_elements {element_filter:{attribute_name:"data-w-id"}}` returned
**0 matches** on a page whose Interactions panel showed two live page-triggered animations.

**A zero from that query is not evidence of "no interactions." It is evidence of nothing.**

**The authority is the Interactions panel**, read through the browser hand:

1. Open the reference Designer.
2. Select the section (Navigator is easiest).
3. Right panel → **Interactions** tab.
4. Read **Element trigger** and **Page trigger**, and note the **named** animations.
5. Note the **Version** field at the bottom (`Classic Interactions` vs newer); it changes what
   duplicating will carry.

Named animations are the prize: a page-load `Landing Hero Slider` or a `Page Card Mouse Move` tells
you the hero is a scripted slider and the cards track the cursor. That is a design fact you cannot
infer from CSS.

**Then apply the interactive-behaviour ladder** ([componentize.md](componentize.md)):
duplicate-and-reskin the component that already animates beats hand-writing an embed. Hand-written
embeds are rung 2, not rung 1.

---

## Gate 2 — Decide the data shape BEFORE building: CMS or props

Ask per component: **does the client add *more of these*, or just edit the ones that exist?**

| Signal | Shape |
|---|---|
| Repeating items of the same kind: logos, FAQ rows, feature cards, testimonials, team, posts | **CMS collection + Collection List** |
| One-off strings on a fixed layout: headline, eyebrow, CTA label, brand name | **Props** |
| A region whose *content type* varies: hero media, card body | **Slot** |

🚫 **The prop-explosion smell.** If you are writing `Card 1 title … Card 6 title`, or a footer with
**27 props**, stop: that is a CMS collection wearing a costume. Six hard-coded cards cannot become
seven without a developer, which defeats the point of handing the client a library.

Conversion procedure: [static-to-cms.md](static-to-cms.md); note the **one Collection List per
parallel group** rule.

**Rule of thumb:** props for the *frame*, CMS for the *contents*, slots for the *unknown*.

---

## Gate 3 — Slots need a filled example, not just a hole

An empty slot is a half-delivered feature. For every slot:

- Give it a **meaningful display name** (`Media`, `Avatar`, not `Slot`).
- **Fill it on the demo page** with a real instance so the client sees what belongs there.
- Say in the component description what is expected to go in it.

A component panel showing `Slot — Empty` teaches the client nothing.

---

## Marquees: two tracks in the DOM, never a JS clone

The Webflow best practice.

✅ **Build the duplicate as real elements**: one `.marquee-track` containing **two identical
`.marquee-group` children** (or two sibling tracks), then animate `translateX(0 → -50%)` in CSS.

- Renders on the Designer canvas, because no script is required.
- Survives export and duplication.
- With CMS: **two Collection Lists**, same collection, same sort. The parallel-group rule.

🚫 **Do not clone the track in JavaScript at runtime.** It works on the published page but the canvas
shows a single un-duplicated track, the client cannot see the component, and the loop silently breaks
if the script does not run. Built 2026-07-31 this way; corrected by the user the same day.

---

## Batch size — how much to take in one pass

**Seven components in one pass is too many.** Verified by doing it: the design drift in components
5–7 was never caught, because there was no checkpoint before the end.

Slice it like this:

| Pass | Output | Gate before continuing |
|---|---|---|
| **0** | Gate 0 write-up + screenshots + interactions inventory | The user confirms the read is right |
| **1** | Tokens + base classes + **one** component, built end to end | **The user sees it and confirms the look** |
| **2..n** | One component per pass (2 max if trivial) | Quick look each time |
| **Final** | Demo page + flowy-verify | — |

The expensive failure is not a slow build, it is seven components built against a wrong reading. **The
first component is the design review.** Get it approved before the pattern is copied six more times.

---

## The intake, when the user brings a brand

When the ask is *"here's a logo / colours / brand guide — take these sections from that template and
rebuild them for this brand"*, capture up front:

1. **Which sections**, by page name or component page slug.
2. **The brand**: logo asset, colour values, typeface *and whether the licence travels*.
3. **The target site**, pinned by id, per house rule #1a.
4. **What stays and what changes**: usually layout/motion stay, colour/type/copy/imagery change.
5. **The data shape per section** (Gate 2).

⚠️ **Fonts are a licence question, not a design question.** A template's typeface is often a
commercial font uploaded to *that* site. Do not copy the files to a client site on your own
initiative; surface it and let the user decide. Falling back to the body typeface is the safe default
and is compatible with house rule #7.
