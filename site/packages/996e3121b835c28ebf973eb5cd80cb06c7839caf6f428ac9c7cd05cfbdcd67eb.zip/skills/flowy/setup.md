# flowy — setup

> **Read this at session start** (SKILL.md step 0). It tells you where the user's settings live and
> what to do when they don't exist yet.

## Where the config lives

```
~/.claude/flowy.config.md
```

**Not here.** This file is inside the plugin, and plugin directories are replaced wholesale on
update: anything written here is lost the next time flowy is upgraded. The user's config lives in
their own `~/.claude/` directory, which flowy never touches.

**At session start:** read `~/.claude/flowy.config.md`.

- **It exists** → use those values.
- **It doesn't exist** → use the defaults below. Do not block, do not interrogate the user, do not
  create the file unprompted. Mention `/flowy:setup` once if a default turns out to be wrong (for
  example, `open -a "Google Chrome"` foregrounds an app the extension is not in).

Three house rules read from this config: #6 (browser), #7 (fonts), #9 (board). Everything else in
flowy is Webflow-universal and needs no configuration.

## The four settings, and their defaults

### `browser` — default `Google Chrome`

Which browser the `claude-in-chrome` extension is actually installed in. Foregrounded with
`open -a "<value>"` on macOS; on Windows/Linux focus the window via the platform equivalent.
Recorded once at first-run setup alongside MCP auth: which Chromium hosts the extension is a
per-device fact, and OS-level computer control of browsers is typically read-only, so
trusted-input steps follow the nudge protocol in [two-hands.md](two-hands.md).

| If they use | Value |
|---|---|
| Google Chrome | `Google Chrome` |
| Comet (Perplexity) | `Comet` |
| Arc | `Arc` |
| Brave | `Brave Browser` |
| Microsoft Edge | `Microsoft Edge` |
| Chrome Canary | `Google Chrome Canary` |

**Why it matters:** opening the wrong app does nothing to the
automated tab, but the MCP calls keep succeeding against a tab nobody is looking at. It presents as
a Bridge problem, not a wrong-app problem. If `designer_tool` calls time out while `data_*` calls
succeed, suspect this before anything else. House rule #6.

### `fonts` — default `per-brand`

- `per-brand`: the typeface comes from each project's brand intake.
- `<Typeface name>`: a pinned house typeface for new builds, e.g. `Inter`.

The **policy** is fixed either way and is not a setting (house rule #7): one typeface, `font-family`
set once on `body`, everything inherits, never per class or element. On an already-built site,
respect the font system that is already there: do not retypeset someone's site.

### `board` — default `none`

`Notion` · `Linear` · `Asana` · `Trello` · `Jira` · `none`

Governs house rule #9: where a board is shared with a client, the client owns the Done column. Set
`none` and the rule is inert, but never declare someone else's acceptance on their behalf
regardless.

### `approval` — default `required`

- `required`: present the plan and stop until the user approves it. **Recommended, and the
  default for a reason:** Webflow writes are frequently not undoable, and writing to the wrong site
  is not recoverable by undo.
- `trusted`: execute an agreed plan without pausing at the Phase-2 gate. Still never publishes
  (house rule #2 is hook-enforced), still verifies every write.

## Template

`/flowy:setup` writes this file interactively. To create it by hand, this is the whole format
(flowy reads the fenced values, so keep the fences):

````markdown
# flowy config

```
browser: Google Chrome
fonts: per-brand
board: none
approval: required
```
````

## What is NOT configurable

Deliberately. These are the rules flowy exists to hold:

| Rule | Enforcement |
|---|---|
| **Never publish without explicit, unprompted permission** — every domain, including staging `.webflow.io` | PreToolUse hook, forces a prompt |
| **Never resize the browser window to test mobile** — it does not work and it breaks the Designer | PreToolUse hook, denies outright |
| **Confirm before irreversible asset operations** — delete, compress-in-place, folder creation | PreToolUse hook, forces a prompt |
| **Never use the Designer "Enable custom code?" preview** | House rule #4 |
| **Small MCP calls — one call, one thing** | House rule #5 |
| **Verified-only reporting; a failed MCP check is not a finished check** | House rules #10, #13 |
