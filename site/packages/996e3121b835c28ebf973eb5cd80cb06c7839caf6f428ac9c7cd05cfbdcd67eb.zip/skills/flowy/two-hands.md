# flowy — paste first, then the Designer, then the API

> Routing detail behind the table in [SKILL.md](SKILL.md).

## Paste-first

**For any third-party Webflow component (Osmo, a cloneable, a library piece), the clipboard is the
correct tool, and nothing else comes close.**

Verified end to end 2026-07-25 (Osmo "Layered Image Slider" → a dedicated empty probe site). One `Copy to Webflow`
click plus one paste (`cmd+v` / `ctrl+v`) on a selected Body delivered:

- `Section.layered-slider` with the full element tree
- **24 style definitions with complete properties**: `aspect-ratio:4/5`, border radii, `translate`,
  full border specs, `scale3d(0,1,1)` with `transform-origin`
- **all 9 data-attribute hooks** (5 bg, 5 title, mask, 5 mask-item, fill, current, total, prev, next)
- correct semantic tags: `section`, `span`, and `button` as type `DOM`

**Nothing was dropped.** In the same session, `data_whtml_builder` silently dropped a class.

Consequences:

- **Never rebuild a copyable component element-by-element.** It is slower and lossier.
- **A resource's separate CSS block is usually unnecessary on the Webflow route.** Osmo ships 3,797
  chars of CSS for its Code route; the paste delivered all of it as native Webflow classes. Read the
  resource's Webflow tab, not its Code tab.
- **Only the JS needs manual placement.** See [embeds.md](embeds.md).

### Procedure

1. Open the resource page in a **second tab** (keep the Designer tab intact).
2. `get_page_text` to capture the recipe: external scripts, steps, the implementation notes.
3. Click `Copy to Webflow`.
4. In the Designer: click **Body** (or the intended parent) in the Navigator, then `cmd+v` (`ctrl+v` on Windows/Linux).
5. **Audit the hooks**: one `query_elements` call with a query per data attribute. Don't assume.
6. Confirm styles arrived: `query_styles name_path:["<component-prefix>"] include_properties:true`.

The clipboard payload is `{"type":"@webflow/XscpData","payload":{"nodes":[…]}}`: 381,553 chars for
that component. Recoverable from the OS clipboard (`pbpaste` on macOS) if you need to inspect it.

### Cross-site paste needs trusted input — the escalation rule

Designer copy/paste fires only on a **real keystroke**. Verified 2026-08-17: synthetic
`cmd+c`/`cmd+v` sent through the Chrome extension silently do nothing (no trusted user gesture),
the component-canvas context menu has no Copy item, and OS-level computer control is typically
read-only for browsers. Each Designer subdomain is its own origin, so the **first** cross-site
paste on a site raises a browser clipboard-permission prompt that lives outside the page, where no
extension can click. Within-site copy is unaffected — it never touches the OS clipboard.

The rule: exhaust every hand in order (MCP, extension, deeper control surfaces). When a step needs
trusted input none of them can produce, ask the user for the **smallest possible nudge** — "click
the element, cmd+c, switch tab, cmd+v, Allow if prompted" — then verify the result yourself and
continue without further asks. Prepare everything before the nudge; consume it immediately after.

## The anti-pattern: MCP-first design

Reaching for a Webflow MCP write tool to achieve a **visual** result instead of driving the Designer.
It feels precise and fast. For visual work it is neither.

- classes silently dropped after `data_whtml_builder` insert (still true in 2.0.1)
- Webflow injects `max-width` / `aspect-ratio` defaults you didn't ask for
- `clamp()`/`min()`/`max()` and `dvw`/`dvh` are silently rejected: one rejected property voids the
  whole `update_style` call
- no descendant selectors
- embed `<style>` rules outrank native classes **on live** while being invisible in the canvas

**When MCP styling IS fine (narrow):** bulk-applying a value you *already tuned and saw land on the
canvas* across many classes or items. That is the whole exception.

**Not covered:** a single-element design write even when every value is numeric; a value the user
merely *dictated* but you haven't rendered and seen; any **state** (hover / focus / active).
"Already-decided" means **tuned-and-seen on the canvas**, never just typed at you.

**What 2.0 changed:** the *mechanical* surface MCP can complete without a Designer click grew a lot
(CMS bindings, Collection List queries, component props and variants, embed code, element settings).
Route those to MCP now. The **visual judgment** rationale is untouched: MCP still never decides, nor
first-renders, what looks right.

## Rationalization table

| Excuse | Reality |
|---|---|
| "I'll rebuild the component properly with the API." | The paste is lossless and takes one keystroke; your rebuild drops classes. Paste it. |
| "MCP writes are pixel-exact; the Designer rounds and drifts." | The Style panel accepts typed exact values. MCP is the lossy one. |
| "Use Chrome only where the API can't reach." | Backwards for design. The Designer is the default; the API is the data layer. |
| "I confirmed the open tab — now I'll do everything via MCP." | Confirming the tab is step 1, not a detour into MCP-only edits. |
| "It's faster to fire one style write." | A blind write you must then verify and fix — and that may not show live — is slower than tuning where you can see it. |
| "The Designer is stuck, so I'll use the MCP." | Unstick it (re-foreground, `?app=` relaunch, re-run `tabs_context_mcp`). If genuinely undrivable, **STOP and surface it.** A blocked Designer is not a licence to MCP-design. |
| "The user gave me exact numbers." | Dictated ≠ verified. Type them in and watch them land — numbers still hit injected defaults and embed overrides. |
| "The write returned success." | `set_settings` and `update_style` report success on writes you must still re-read. Verify. |
| "2.0 can do bindings now, so it can do design now." | Different claim. Mechanical reach grew; visual judgment did not move. |

## After the paste — reconcile. A paste is an import, not an integration.

Established 2026-07-31 after pasting a hero cross-site and leaving the wreckage in place. Getting the
pixels in is step one of three. **Skipping the rest forks your design system on day one.**

### The rename toast is a collision report — read it as a to-do list

> *"Renamed `"rt-button-v1"` and `"rt-button-font"` classes to `"rt-button-v1 2"` and
> `"rt-button-font 2"` in order to avoid conflicts."*

Every ` 2` means **the target already had that concept.** Webflow is telling you precisely where the
incoming work overlaps what you already own. It is the most useful output of the whole paste, and it
vanishes in a few seconds. Capture it immediately.

🚫 **Never leave a ` 2` class in a project.** It is either a duplicate to delete or a distinct concept
that deserves a real name. A cluster of ` 2` classes is the fingerprint of an unreconciled paste
(unreconciled pastes are exactly how templates accumulate these clusters).

### ⚠️ Pasted styles arrive DETACHED FROM YOUR TOKENS

Verified 2026-07-31, and the reason a paste cannot simply be adopted:

| | Original (`rt-button-v1`) | Pasted (`rt-button-v1 2`) |
|---|---|---|
| `border-*-color` | bound to the **Black** variable | literal `"white"` |
| `color` | bound to the **White** variable | absent |
| `font-size` (`rt-button-font`) | bound to the **Button** size variable | literal `16px` |

**Cross-site paste flattens variable bindings to resolved literals.** The pasted markup therefore
looks right on arrival and **will not re-theme**: change a colour token and the pasted section
ignores you. Rebinding to tokens is mandatory, not cosmetic.

### The reconciliation procedure

1. **Capture the toast** verbatim before it disappears.
2. **Diff each collision**: `query_styles name_path:["X"]` and `["X 2"]`, `include_properties:true`.
3. **Decide per class:**
   - *Same intent* → delete the ` 2` class, apply the original to the pasted elements, done.
   - *Genuinely different* → rename it to describe the difference (`rt-button-v1-inverse`), never
     leave a numeral.
4. **Rebind literals to tokens** on anything you keep.
5. **Replace unlinked components with your own.** Cross-site paste unlinks every component
   instance, so a pasted button arrives as loose markup. If the target already has an equivalent
   component, **delete the loose markup and insert an instance of yours**. Otherwise you are
   maintaining two buttons and the client gets two panels for one concept. *This is the single most
   commonly skipped step.*
6. **Audit the classes the paste brought that did NOT collide.** They are new to your system and were
   never reviewed. In the 2026-07-31 paste these included `rt-button-bg`
   (`position:absolute; right:101%; width:102%`): a second element sliding in to fake a hover
   fill, which violates the one-element-morphed rule: transform the hovered element itself rather than
   overlaying a second element to fake the effect. Incoming patterns are not automatically good
   patterns; they are one designer's choices.
7. **Re-point what was dropped**: custom fonts and some links do not travel.
8. **Purge** what you deleted, then re-read to confirm.

### Predict the collisions before you paste

Cheap and saves all of the above:

- `data_component_tool > get_all_components` on the target: *do I already own this thing?*
- `query_styles name_path:["<incoming-prefix>"]`: *which names will collide?*

If the target already has an equivalent component, **do not paste the section at all**: paste it into
a scratch page, harvest the layout and motion, and build with your own component. The paste is a
reference, not the deliverable.
