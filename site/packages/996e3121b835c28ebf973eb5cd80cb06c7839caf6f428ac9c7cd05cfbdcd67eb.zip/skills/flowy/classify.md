# flowy — classify

> Reading an unfamiliar site and deciding what should become a component, at what level.
> Runs after [conventions.md](conventions.md) (which grammar) and before
> [componentize.md](componentize.md) (how to build it).

## Output: the candidate ledger

One row per candidate, and it is what Gate 1 is approved against:

| page | element | level | CMS-bound? | already a component? | conformance | archetype |
|---|---|---|---|---|---|---|

`level` ∈ section · atom · slot host · leave alone.

---

## Read with both hands

They return different truths and you need both.

| Hand | Gives |
|---|---|
| **MCP** | stored structure: tree, tags, applied classes, components, props, CMS bindings |
| **Chrome** | rendered truth: computed width, real `max-width`, actual padding |

A class named `container` that computes to full width is not a container. Only the second hand
knows that.

Computed width via `javascript_tool` against the canvas iframe:

```js
const el = document.querySelector('<selector>');
const r = el.getBoundingClientRect();
({ w: r.width, vw: window.innerWidth, full: Math.abs(r.width - window.innerWidth) < 2 })
```

---

## 1 — Sections

### 🚫 Do not assume sections are children of `<body>`

**Verified 2026-07-29:** a component-first framework's pages are
`Body › .page-wrapper › [chrome instances, <main> › page slot › sections]`. Sections were **four
levels down**, not direct children of Body.

**Find the section level structurally**: the *repeated sibling group whose members are full-bleed and
sit at the same depth*. Then check what wraps it, once, and reuse that for every page.

### Signals

| Signal | Weight |
|---|---|
| Member of a repeated full-bleed sibling group at consistent depth | **strong** |
| `<section>` tag | strong, but never required (a starter can use `header`, `section` and `div` in the same slot) |
| Computed width == viewport width | strong |
| Class matches the profile's section pattern | strong, only when the convention is recognised |
| Exactly one direct child that constrains width | confirms Section › Container |
| Vertical padding present | supporting |
| **Is an instance of a component named for the section role** | **strong, and changes everything below** |

---

## 2 — Section › Container conformance — three check modes

One structural invariant, and it can be **expressed three different ways**. Checking only the first
is the most likely way to be wrong.

**A section is full-bleed and has exactly one direct child that constrains width.**

| Mode | How it looks | How to check |
|---|---|---|
| **Class chain** | `section` › `container`, or `padding-section-*` › `padding-global` › `container-*` | trace the parent→direct-child class relation, per the profile |
| **Computed structure** | no meaningful class names, but the geometry holds | Chrome: full-bleed parent, one child with a real `max-width` and auto inline margins |
| **🔑 A component prop** | a `Section` component with a boolean container/width toggle | read the component's props: **there is no class relation to trace** |

⚠️ **The third mode is not exotic.** Verified 2026-07-29 on a mainstream framework: 22 section
instances, a `Container · boolean · default true` prop, and **no `section`→`container` class relation
anywhere on the site.** A classifier tracing only the class chain reports **zero conformance on a
fully conformant project**, and would then "fix" a site that was never broken.

**Check for the prop mode whenever the site is component-first.** Look for a Layout-group component
whose props include a container/width toggle.

### Violations to flag (never auto-fix)

- A section with no width-constraining child, or more than one
- The container carrying the full-bleed background
- Gutters on a level the profile says owns something else
- ⚠️ **Custom classes outside the framework vocabulary are not violations** on any framework that
  states an 80/20 stance. Check the profile before flagging.

---

## 3 — Atoms

- Structurally identical subtree occurring **≥3 times**
- across **≥2 distinct parent sections**: repetition inside one section is a **list**, not an atom
- node count below a ceiling: **start at ≤6 and calibrate from the distribution**, not from the
  number. Find the natural break between "button with icon and label" and "whole card", and
  **record the distribution that justified the ceiling.**
- **or** unambiguous semantics (a `Link`/`Button` with a consistent class root), which bypasses the
  ceiling entirely

The two-parent rule is what separates a real atom from a row of cards belonging to one section.

**On a component-first site, most atoms already exist as components.** Inventory before deriving:
`get_all_components` with `includeInstanceCount`. A site can ship 30+ atoms already built.

---

## 4 — Slots

A wrapper constant across occurrences whose inner content varies **in element type, not merely in
value.**

- Varying **values** → props
- Varying **types** → a slot

⚠️ Filling a nested instance's slot is **Designer-hand only**; see
[componentize.md](componentize.md) §A2b. Classify slot hosts honestly anyway; the routing is the
build step's problem, not the classifier's.

---

## 5 — Already a component

`get_all_components { includeProps, includeVariants, includeInstanceCount }`: **first, always.**
Never rebuild what exists.

Then `query_components` with `isCodeComponent: true` and `isLibrary: true`. Anything returned is
**read-only**: `unlink_component_instance` does not work on either. Record under a
`DO NOT MODIFY` heading in the ledger.

**A site can already be a component system.** Verified 2026-07-29: a "template" turned out to ship
36 components with props, variants, groups and slots: nothing raw to componentize at all. The real
candidates were the **compositions assembled from those components**, which are not themselves
components. Check before planning; the answer changes what the whole job is.

---

## Query traps

- ⚠️ **`children_depth: 0` does not suppress slot contents on `ComponentInstance` results.** Broad
  instance queries on a slot-composed site return full slot subtrees and blow the response ceiling
  (observed at 127KB and 182KB). **Scope to one page or one parent, and parse the saved tool-result
  file locally** rather than re-querying smaller.
- ⚠️ **Page-level element queries do not descend into component definitions.** Classes used only
  inside components look unused until you pass `scope_component_id`. Any "unused class" conclusion
  drawn without it is wrong.
- **Breakpoints are per-site.** `designer_tool > get_all_breakpoints` before assuming a wide canvas
  means a wide breakpoint: a site with only four breakpoints has no XL, so 1834px is still base.
  The generic canvas-width hazard in [SKILL.md](SKILL.md) still stands; it just may not apply here.

---

## Gate 1 — "did I read your site right?"

Present **before any build**: sections found, the profile adopted (recognised or derived), the
adopt-vs-impose call, conformance violations, atom candidates with the calibrated ceiling and its
distribution, and anything deliberately excluded.

**This gate is cheap and the next one is not.** A misread here costs a sentence of feedback;
uncaught, it produces twenty confidently wrong components that every later stage inherits.
