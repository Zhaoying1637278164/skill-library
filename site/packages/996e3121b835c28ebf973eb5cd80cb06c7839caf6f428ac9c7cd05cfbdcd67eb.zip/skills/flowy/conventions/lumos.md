# Lumos — convention profile

> By Timothy Ricks. Derived from the current published documentation (v2.2.0 line), then
> **reconciled against a real shipped "Lumos 2.0.3" starter (April 2024) and a real 2023 V1
> site on 2026-07-29**. Where docs and site disagreed, the site won, and here it disagreed on
> almost everything: most of the disagreement is **version skew, not builder sloppiness**.
> Loaded by [../conventions.md](../conventions.md) when Lumos is recognised, and again when Lumos
> is the system being imposed (§7).

**Legend** — ✅ verified on a real site · 📄 documented only, never seen on a site · ⚠️ trap · 🚫 never.

**A claim carrying 📄 is not weaker doctrine, it is untested doctrine.** Do not score a recognition
decision on a 📄 pattern alone, and do not "fix" a project for violating one. This matters more here
than in the other two profiles: **an entire Lumos generation (v2.1+) is 📄 throughout.**

## ⚠️ Read this before scoring: Lumos is three incompatible frameworks wearing one name

Lumos spans **at least three mutually-incompatible generations**. They share a grammar and share
almost nothing else: the utility vocabularies of V1 and V2.0.x and V2.1+ are nearly disjoint, the
container behaves differently in each, and the theming, token and responsive mechanisms are three
separate architectures.

🚫 **A detector built on the documented (newest) fingerprint fails to recognise every project cloned
from the 2.0.x starter, which is what most real Lumos sites in the wild descend from.** The
documented v2.0.6 release note ("instead of having to apply left and right padding to containers,
containers now hug the edge of their content") is itself proof the shipped 2.0.3 starter predates
the documented behaviour.

| Generation | Year | What it looks like | Status |
|---|---|---|---|
| **V1** | 2023 | `{block}_{el}_wrap--{encoded modifiers}`: `card_sg_wrap--bw1-br2-pd2`, `hero_sg_wrap--vt1-vb1-sm0.2`, `footer_sg_wrap--bw1t-vt1-vb1`, `hero_sg_tag_wrap--gp1.5`. **No `u-` utility layer. No container class.** | ✅ verified directly on a real 2023 site |
| **V2.0.x** | 2024 | `u-` utility layer (`u-hflex`/`u-vflex` matrix, `u-gap-*`, `u-column*`, `u-grid-custom`, `u-h1`…`u-h6`); `u-container` carrying max-width **and all four paddings**; an HTML `data-*` layer (`data-theme`, `data-padding-top`/`-bottom`, `data-button-style`) powered by four `page_code_*` style embeds; `--group--name` double-dash tokens, **one** collection, **one** mode; responsiveness via `@media` token remaps | ✅ the reconciled reference, verified in full |
| **V2.1+ / V2.2** | 2025 | `u-section` plus a **padding-less, calc-width** `u-container`; `--_collection---group--value` triple-dash tokens; "breakpointless" container queries; theming via Webflow variable **modes** and `u-theme-*`; `u-text-style-*`; `data-trigger`/`data-state` | 📄 **doc-only; no v2.1+ site was ever read** |

### What is constant across all three — build the anchor on this, nothing else

- **The class grammar**: underscore-segmented, hyphen only *inside* a segment, named class first
  with `u-` utilities stacked after, ≤3 underscores, terminating `_wrap` / `_contain` / `_layout`.
- **The `page_wrap` › `page_main` shell** (underscores).
- **The `page_code_*` embed stack.**
- **The absence of Client-First vocabulary.**

Everything else is generation-specific and must be scored as **positive-only**.

---

## 1 — Fingerprint

### Anchor — either one, verified structurally, never name-matched

| # | Anchor |
|---|---|
| **A** | **`page_wrap` › `page_main`** with **underscores**: confirmed in the DOM, `page_main` on `<main>`, `page_wrap` carrying `overflow: clip`. Discriminates cleanly from Client-First's dashed `page-wrapper`/`main-wrapper` and MAST's `page-wrapper`/`page-main` |
| **B** | **The `page_code_wrap` embed stack**: a component whose root is `.page_code_wrap`, holding `page_code_base` / `page_code_color` / `page_code_responsive` / `page_code_custom` as HtmlEmbeds in fixed order, applied per page |

✅ **Anchor B is the strongest marker found anywhere in this research: `page_code_wrap` was verified
in BOTH the 2023 V1 site and the 2024 2.0.3 starter**, the only marker confirmed across two
generations, and it appears in no other convention. ⚠️ `page_code_custom` **ships empty**; an empty
embed is conforming, not evidence against.

### Corroborators

| Pattern | Strength | Note |
|---|---|---|
| `{group}_wrap` › `{group}_contain\|_container` › `{group}_layout` | **strong** | ⚠️ **Match `_contain(er)?` as one pattern.** The docs say `_contain` uniformly; the starter ships both: 10 `_contain` (nav, projects, split, layout_split, layout_full, layout_card, styleguide, styleguide_guide, hero_placeholder, hero_utility-page) and 3 `_container` (blog, footer, hero), *including the live Home hero*. A detector keyed strictly to `_contain` misses Timothy Ricks' own hero and footer |
| **The grammar itself**: lowercase, ≤3 underscores, hyphen only inside a segment, named class first with `u-` stacked after | **strong, and the only signal identical in all three generations** | ✅ Verified on the 2.0.3 starter's 233 globals: `layout_split_visual_wrap`, `hero_utility-page_wrap`, `g_link-title_text`, `hero_column-1`. Deepest classes sit exactly at three underscores and never exceed it |
| `page_code_wrap` / `page_code_base\|color\|responsive\|custom` | **strong** | Also usable as corroboration when anchor A carried the match |
| Token cssName shape **`--group--name`** (double dash) with a strict reference chain, colour literals confined to a swatch tier | strong | ✅ `--max-width--main`, `--radius--main`, `--border-width--main`, `--theme--background`. ⚠️ Not the docs' triple-dash shape; see §4 |
| `u-container` as the **sole** max-width owner, `--max-width--main` = **90rem** | strong | ✅ Value verified directly. The *single-element role* and the *value* are stable across generations; only whether it also carries padding varies |
| `g_`-prefixed globally-reused blocks paired 1:1 with `Global / *` components: `g_header_*`, `g_visual_*`, `g_eyebrow_*`, `g_link-title_*`, `g_tag_wrap` | strong, **2.0.x** | ✅ A **fourth** class tier the docs never mention (they claim three: custom / `u-` / `is-`). Unambiguous, and absent from Client-First |
| `form_main_*` grammar: `form_main_field_wrap`, `form_main_option_wrap`, `form_main_option_link` | strong | ✅ Verified in **both** V1 and 2.0.3 |
| **HTML `data-*` attributes on structural elements, given behaviour by a site-level `<style>` embed** | strong, **matched at this generality** | 🚫 Do not require the specific attribute names. Discriminate from MAST by *what they control*: MAST's `data-animate` controls animation only; Lumos's control theme, padding and button style (see [../conventions.md](../conventions.md) §4) |
| `u-` prefix + dash grammar + **always stacked after a named class** | strong as *placement*, ⚠️ **worthless as vocabulary** | The largest collision in the set (MAST also uses `u-`). And the two Lumos generations' utility name sets are **almost disjoint**: only `u-grid-autofit` appears in both. Score the *placement rule*, then use names to version-stamp |
| `none \| small \| main \| large` scale keywords | **strong, and a Lumos-only tell** | ✅ Both sources agree on the keyword set: docs `--_spacing---section-space--{none\|small\|main\|large\|page-top}`, site `--padding-vertical--{none\|small\|main\|large}`. **`main` as a size step is used by no other system** (see [../conventions.md](../conventions.md) §4) |
| `is-` combos scoped to one component class, never standalone globals | **weak, and it runs backwards** | ✅ The 2.0.3 starter has **exactly two**: `.form_main_field_input.is-message`, `.g_tag_wrap.is-wider`. **Abundant `is-` pushes a classifier toward Client-First (15, all depth 2), not toward Lumos.** Drop `is-` from any required set |
| Hard negative: `padding-global`, `container-large\|medium\|small`, `padding-section-*`, `spacer-*`, `text-size-*`, `heading-style-*`, `max-width-*` | **decisive against** | ✅ None of these exists anywhere in the starter's 233 classes. Their presence means Client-First, not Lumos |

### 🚫 Must NOT be used as evidence *against* Lumos

Every one of these is false on Timothy Ricks' own shipped 2.0.3 starter. A detector applying the
documented rule misclassifies the official artifact.

- Absence of `u-section`: **zero matches** on the real site.
- Horizontal *and* vertical padding on `u-container`: correct pre-v2.0.6 behaviour, all four sides confirmed.
- Layout / flex / gap utilities stacked **onto** `u-container`: the docs' cardinal anti-pattern is the starter's live Home hero.
- Presence of `@media` queries or Webflow breakpoint overrides: "breakpointless" is v2.1+ doctrine; 2.0.3 is built on `@media`.
- Absence of `--_x---y` triple-dash tokens.
- A single-mode variable collection, or absence of `u-theme-*`.
- Zero component variants: all 23 components on the starter are base-only.
- Sparse or absent `is-` classes.
- Isolated `px` values (`--border-width--main` is **1.5px** in the shipped starter) or non-fluid, non-clamp tokens.
- ` / `-separated component names, and ungrouped singleton components.

---

## 1b — VERSION-STAMP, immediately after recognition

**This is a required step, not an optional refinement. Getting the generation wrong is as bad as
getting the convention wrong**: every structural rule, every utility name and every "violation"
below is generation-conditional, so an unstamped Lumos verdict cannot be acted on.

Run it after the anchor matches, before writing anything. All three sets are **positive evidence
when present and carry zero negative weight when absent.**

| Stamp | Positive markers |
|---|---|
| **V1 (2023)** | `{block}_{el}_wrap--{encoded}` suffixes (`--vt1-vb1-sm0.2`, `--bw1-br2-pd2`, `--bw1t`, `--gp1.5`), **with no `u-` layer and no container class at all** |
| **V2.0.x (2024)** | the exhaustive `u-hflex-{left\|center\|right\|between}-{top\|center\|bottom\|stretch}` / `u-vflex-*` matrix · `u-gap-*` · `u-column` / `-full` / `-indent` · `u-grid-custom` · `u-h1`…`u-h6` · `u-text-large` / `u-text-small` · `data-theme` · `data-padding-top` / `-bottom` · `data-button-style` · single-mode variable collection · `:root` token remaps inside `@media` |
| **V2.1+ (2025)** ✅ *partly observed 2026-08-05* | `u-section` · **`u-text-style-*`** ✅ · `u-theme-*` · `u-margin-trim` · `u-grid-breakout` · **`u-display-contents`** ✅ · `u-sr-only` · `u-container-small` / `-full` · `--_collection---group--value` tokens · `container-type` **on `u-container`** · `data-trigger` / `data-state` · multi-mode collections · component **Variants** |

### ⭐ V2.1+ IS NOW OBSERVED — and generations MIX (2026-08-05)

~~The entire v2.1+ generation is 📄 documentation only; no v2.1+ site was read.~~ **Superseded
2026-08-05** by reading **`timothyricks.com`, the framework author's own production site.**

Observed there: `u-text-style-small` and `u-display-contents` (v2.1+ markers) **alongside
`u-container`** (catalogued above as a v2.0.x marker), on the same page, in the same DOM.

🚫 **This falsifies "never mix generations" as a detection rule.** §7 still tells you not to mix them
when *building*; that guidance stands, because a deliberate new project should pick one. But as a
*recognition* rule it would flag Timothy Ricks' own site as matching no Lumos profile.

**The operative correction:**

- **Mixed markers are the expected state of a maintained Lumos site**, not a defect and not a
  mis-stamp. Frameworks migrate class by class.
- **Stamp on the NEWEST marker present, not the oldest.** One `u-text-style-*` outranks twenty
  `u-container`s: v2.1+ vocabulary does not appear by accident, whereas v2.0.x vocabulary persists
  by inertia.
- **Never "fix" the older-generation classes** on a mixed site. That is residue under
  [../conventions.md](../conventions.md) §2, and the author ships it himself.
- Still unobserved from that row: `u-theme-*`, `u-margin-trim`, `u-grid-breakout`, `u-section`,
  `container-type`, `data-trigger`/`data-state`, multi-mode collections. Those stay 📄.

⚠️ **`u-sr-only` collides exactly with MAST's utility list; do not score it in either direction**
([../conventions.md](../conventions.md) §4).

⚠️ **`--{letters}{digits}` suffixes on an otherwise-2.0.x site are V1 residue, not a stamp and not a
typo.** The 2.0.3 starter itself ships `g_eyebrow_text--fs7` (`fs7` = font-size step 7). **Do not
adopt it and do not "fix" it** (see [../conventions.md](../conventions.md) §2 on residue).

---

## 2 — The section chain, as Lumos spells it

### V2.0.x — verified

```
<section> | <header> | <footer>     {group}_wrap
                                    data-theme · data-padding-top · data-padding-bottom
                                    NO u-section · position:relative comes from a tag
                                    selector in page_code_base, not from a class
  └ <div>   {group}_contain | {group}_container  +  u-container
            max-width: var(--max-width--main) 90rem
            width:100% · margin-left/right:auto
            AND all four paddings — --padding-horizontal--main 3.5rem,
            --padding-vertical--main
      └ <div>  {group}_layout  + layout utilities
```

**Vertical rhythm lives on the container, not on the section.** There is no section-level padding
class in this generation; section spacing is driven by `data-padding-top`/`-bottom` read by
`page_code_color`-era embeds, resolving to `--padding-vertical--{none|small|main|large}`.

⚠️ **`{group}_layout` is the intended layout level, but the starter routinely skips it.** The live
Home hero is `div.hero_container.u-container.u-vflex-stretch-between.u-gap-medium`: layout
utilities stacked straight onto the container. **On 2.0.x that is idiomatic, not a defect.**

### V2.1+ — 📄 documented only, never observed

```
<section class="{name}_wrap u-section">
        display:flex · position:relative · theme background/color
        padding-top/bottom: var(--_spacing---section-space--main)
  └ {name}_contain  +  u-container
        width: calc(100% - var(--site--margin) * 2) · margin-inline: auto
        NO padding — "containers now hug the edge of their content" (v2.0.6)
        container-type: inline-size
      └ {name}_layout        ← layout MUST live here
```

🚫 **The docs' single most emphasised anti-pattern (`display:grid` / `grid-template-columns` / any
layout on `u-container`) exists only because `container-type: inline-size` makes `@container` rules
apply to the container's children. Enforce it ONLY after confirming `container-type: inline-size` is
actually present on that project's container.** On the 2.0.3 starter it is not: exactly **one** class
site-wide carries `container-type`, and it is `styleguide_flex_wrap`, not the container.

🚫 **Never auto-convert a 2.0.x padded container into the calc-width form.** That silently
reimplements the framework rather than conforming to it.

### V1 — verified only at the naming level

No `u-` layer and **no container class exists at all**; width and spacing ride in the encoded
modifier suffix. ⚠️ **V1's structural chain below `_wrap` was not enumerated**; see *Still
unverified*.

### The page shell — constant across generations

```
.page_wrap                      <div> — overflow: clip
  ├ ⬡ Custom Code → .page_code_wrap
  │      ├ page_code_base        tag selectors, resets, position:relative
  │      ├ page_code_color       [data-theme] rules incl. real nesting inversion
  │      │                         [data-theme="dark"] [data-theme="invert"]
  │      ├ page_code_responsive  @media blocks remapping :root primitives
  │      └ page_code_custom      ships EMPTY
  └ .page_main                   <main>
```

The four embeds are applied **per page, in fixed order**. ⚠️ Where nav/footer components sit
relative to `page_code_wrap` inside the shell was not recorded; do not assert an order.

🚫 **There are no per-section `<style>` embeds.** The docs state a firm rule that component CSS is a
`<style>` as the first child of each component's `_wrap` and JS a `<script>` as the last; the
starter has none. **Their absence is not evidence against Lumos.**

---

## 3 — Class-naming grammar

Constant across all three generations. This is the part to copy.

- **Lowercase throughout.** No camelCase, no BEM `__`, no PascalCase.
- **Underscore separates semantic segments. Hyphen joins words INSIDE one segment.**
  ✅ `tabs_link_wrap` correct; `tabs_link-wrap` wrong. Real classes: `layout_split_visual_wrap`,
  `hero_utility-page_wrap`, `g_link-title_text`, `hero_column-1`.
- **Broadest term first**, drilling narrower, so the Designer's class field filters usefully.
- **Hard cap of three underscores.** ✅ The docs state it; the starter's deepest classes
  (`layout_split_visual_wrap`, `form_main_option_link`) sit exactly at the cap and never exceed it.
- **Role suffixes terminate the name:** `_wrap` (component/block root) › `_contain` *or*
  `_container` (width owner) › `_layout` (layout owner).
- **The named/custom class is ALWAYS first in the chain and is what holds bespoke CSS.** Utilities
  stack after it. ✅ Canonical shipped chain:
  `.g_link-title_wrap.u-hflex-between-center.u-hflex-nowrap.u-gap-xsmall`.
- **Utilities take `u-`, use dashes between words, never underscores**, and are named
  broadest-search-term-first. ✅ All 79 utility globals on the starter obey it.
- **`g_` marks a globally-reused block** backed 1:1 by a `Global / *` component (2.0.x). A fourth
  tier the docs do not document.
- **`is-` marks a combo modifier scoped to one specific component class**, never a standalone
  global; it is nearly vestigial here (n=2).
- **`--{letters}{digits}` suffixes are V1 encoded modifiers**, not part of the V2 grammar.

⚠️ All three conventions use the underscore. Discriminate by **depth and terminal vocabulary**
(see [../conventions.md](../conventions.md) §4) and confirm with a structural anchor.

---

## 4 — Style architecture

### Tokens

- **Webflow-native variables, and almost nothing holds a literal.** ✅ Colour literals are confined
  to a swatch tier; everything else is a reference chain: `..padding-vertical/main` → `size/6rem`,
  `.h1/font-size` → `size/5rem`. ~160 tokens on the starter.
- **cssName shape is the double dash `--group--name`.** ✅ `--max-width--main`, `--radius--main`,
  `--theme--background`.
- ⚠️ **The docs' `--_collection---group--value` triple-dash shape is presented as Lumos's strongest
  unique signature and does not appear on the real site at all.** 📄 Treat `--_x---y` as a
  high-confidence positive **for v2.1+ only**; its absence carries zero weight.
- **Leading dots in the Webflow variable NAME are a Designer sort-order hack** and are stripped from
  the cssName entirely: three dots = component/theme tier, two = semantic, one = typography role,
  none = raw primitive. ⚠️ **Visible only through the variables API, never in compiled CSS: a
  CSS-only detector cannot see this at all.**
- **Sizes are a static rem ladder**, `size/0rem` … `size/16rem`, 28 steps. 📄 The docs' fluid/clamp
  tokens and the Fluid Builder App are a v2.1+-era signal only: **do not require `clamp()`** and do
  not flag isolated px (`--border-width--main` is 1.5px in the shipped starter).

### Theming — two mechanisms, detect either

| Generation | Mechanism |
|---|---|
| **2.0.x** ✅ | **One collection ("Base collection"), ONE mode.** Zero variable-level theming. Theming is pure CSS in the `page_code_color` embed, driven by a `data-theme` attribute (`light\|dark\|invert\|inherit`) with real nesting inversion (`[data-theme="dark"] [data-theme="invert"]`). **Zero `u-theme*` classes exist.** This is the form actually in the wild |
| **2.1+** 📄 | Webflow variable **modes**, switched by `u-theme-inherit\|light\|dark\|brand` classes |

### Responsiveness — two architectures, opposite to each other

| Generation | Mechanism |
|---|---|
| **2.0.x** ✅ | Built **on `@media`**. `page_code_responsive` remaps `:root` primitives wholesale (at ≤991px `--padding-horizontal--main` → 2rem and `--size--6rem` → 4.5rem, again at ≤767px → 1rem / 3.5rem), plus one Designer breakpoint override (`u-grid-column-3` at `small`). Container queries essentially unused (one class) |
| **2.1+** 📄 | "Breakpointless": no styles on tablet/mobile breakpoints, never `@media`, `@container` in `em`, responsive keyword variables (`display: var(--flex-medium, grid)`), `--_responsive---{large\|medium\|small\|xsmall}` flags |

⚠️ **This is the drift most likely to cause a false negative.** Better: **a `:root` token-remap block
inside `@media` is itself a strong POSITIVE fingerprint for Lumos 2.0.x**, because remapping
primitives rather than overriding classes is unusual.

### ⭐ There is a THIRD architecture: fluid `clamp()` tokens (observed 2026-08-05)

Neither of the two rows above describes what `timothyricks.com` actually does. Its `:root` holds
**fluid tokens that need no breakpoint mechanism at all**:

```
--site--margin         clamp(1rem,    -.072rem + 5.36vw, 5.286rem)
--section-space--main  clamp(5.17rem, 4.062rem + 5.54vw, 9.604rem)
--h1--font-size        clamp(3.18rem, 2.606rem + 2.87vw, 5.477rem)
--h2--font-size        clamp(2.52rem, 2.174rem + 1.73vw, 3.903rem)
--text-main--font-size clamp(1rem,     .986rem +  .07vw, 1.057rem)
```

Every `@media` block present is Webflow's stock 991/767/479 set carrying only incidental overrides:
the responsive *system* is in the token graph, not in the breakpoints.

**How to tell the three apart:** read `:root` and ask what the values ARE.

| Architecture | `:root` signature |
|---|---|
| **2.0.x `@media` remap** | Static values, **re-declared** inside `@media` blocks |
| **2.1+ "breakpointless"** 📄 | Responsive keyword variables, `@container` in `em` |
| **Fluid tokens** ✅ | `clamp(min, calc + vw, max)` in the token itself; `@media` nearly empty |

⚠️ **This matters more for building than for scoring**: `clamp()` cannot be written by
`update_style` ([../conventions.md](../conventions.md) §6). A fluid Lumos project **cannot have its
token tier built through MCP.**

### ⭐ `--swatch--*` is the colour-literal tier (confirmed 2026-08-05)

38 state rules on the author's site draw their colours from it:
`.button:hover{background-color:var(--swatch--light-200)}`,
`.modal_close:hover{color:var(--swatch--brand-1)}`. That confirms this profile's claim that colour
literals are confined to a swatch tier. **Semantic tokens (`--theme--text`, `--theme--background`)
reference swatches; classes reference semantic tokens.** Hover states are the one place that
convention is routinely broken even on the author's site (several use raw `#ffffff1a`).

### Project CSS

Segregated into a dedicated embed rather than scattered. Same principle in both sources, different
container: docs put it in a `Global Styles` component; the site ships the four-embed `page_code_wrap`
stack. ⚠️ **Empty Site Settings custom code is therefore not evidence of no system.** ⚠️ `Global
Styles` as a component name is a direct collision with Client-First's shipped artifact.

⭐ **A third container, observed 2026-08-05:** `timothyricks.com` uses **`u-embed-css` and
`u-embed-js`**, utility-prefixed classes on the embeds themselves, with **no `page_code_wrap`
stack at all.** So the code-holder is `page_code_*` (2.0.x starter) **or** `u-embed-*` (current
author site) **or** a `Global Styles` component (docs). **Detect the pattern (a class-named embed
holder), never a specific name.**

---

## 5 — Component practice

- **Broadest-term-first names so the components panel filters**, and **the component group mirrors
  the class prefix**: `Global / *` → `g_*`, `Btn / Main` → `btn_main_*`,
  `Section / Content / 2 Column` → the `_wrap`/`_contain`/`_layout` trio inside.
- ✅ **Names are slash-grouped Title Case with spaces around the slash, nesting up to three levels**:
  `Btn / Main`, `Btn / Main / With Link`, `Icon / Arrow`, `Global / Visual`,
  `Section / Content / 2 Column`, `Starter / Section`. 📄 The docs give space-separated names
  ("Section Hero", "Button Main"). **Match on the broadest-first ORDERING, not on the separator.**
- ⚠️ **Grouping is incomplete in the official starter**: `Projects Card`, `Blog Card`, `Logo`, `Nav`,
  `Footer` sit ungrouped at root. **Ungrouped singletons are not a convention breach.**
- 🚫 **Zero variants.** All 23 components on the 2.0.3 starter return only `{id: 'base', name: 'Base'}`.
  📄 The docs call variants "the preferred alternative to near-duplicate components" and require the
  prop be named exactly `Variant`.
- ✅ **The jobs the docs assign to variants are done by Title Case ENUM PROPS that write `data-*`
  attributes**: `Theme`, `Padding Top`, `Padding Bottom`. A section is configured by ~10–12 props on
  one base variant. **A prop named `Theme` rather than `Variant` is not a naming violation on 2.0.x.**
- **The stable, generation-independent mechanism is: an enum prop writes a `data-*` attribute, which a
  site-level style embed consumes.** Detect *that*. Whether it is spelled as a variant or a prop is
  generational.

---

## 6 — Violations

Real violations, the grammar rules that hold in every generation:

- A hyphen where a segment boundary belongs: `tabs_link-wrap` for `tabs_link_wrap`.
- More than three underscores in a class name.
- A utility class **first** in the chain, or a utility carrying bespoke one-off CSS. The named class
  is always first and holds the bespoke styling.
- An underscore inside a `u-` utility name.
- Client-First vocabulary (`padding-global`, `container-large`, `padding-section-*`, `spacer-*`,
  `text-size-*`, `heading-style-*`) inside a Lumos project.
- A width constraint set anywhere other than the container tier.

**Generation-conditional: enforce only after the §1b stamp says v2.1+, and only against observed
CSS:**

- Horizontal padding on the container. 🚫 On 2.0.x this is the *correct shipped behaviour*.
- Layout / flex / grid / gap on the container. 🚫 Only a violation where
  `container-type: inline-size` is actually present.
- `@media` queries and Webflow breakpoint overrides. 🚫 2.0.x is *built* on them.
- Selecting `[data-*]` directly in CSS. 🚫 The 2.0.x embeds do exactly this
  (`[data-padding-top="large"] { padding-top: var(--padding-vertical--large); }`), which the docs
  forbid.

### 🚫 Never auto-fix — all of these ship in the official starter

Container padding · layout-on-container · `@media` token remaps · the `_container` spelling holdouts
· `g_eyebrow_text--fs7` (V1 encoded-modifier residue, **not** a typo) · the stray `c` selector in the
theme rule · the panel-less `--button-secondary--*` tokens. **"Fixing" any of them means diverging
from the framework rather than conforming to it.** Flag the `_contain`/`_container` inconsistency to
a human; never auto-rename.

---

## 7 — Imposing Lumos on a project with no system

**Lumos is flowy's default convention to impose** ([../conventions.md](../conventions.md) §5), so
this profile has to work forwards as well as backwards. Two gates first, both non-negotiable:

1. A **genuine mess** verdict from the mess test ([../conventions.md](../conventions.md) §1). A
   coherent-but-bespoke project gets derived and adopted, never converted.
2. **One direct question to the user**, answered. Imposition is never a unilateral choice.

### Then: pick a generation and write it down

**Default to the verified V2.0.x shape.** Every rule in it has been observed working in a shipped
artifact; the v2.1+ line is 📄 documentation only in this research and its container, theming, token
and responsive mechanisms are all unverified. Adopt v2.1+ only on explicit instruction, or after
reading a real v2.1+ site and updating this profile.

🚫 **Never mix generations *in a new build*.** A calc-width container with `data-padding-top`
attributes, or `u-theme-*` classes over a single-mode collection, is a project nobody can maintain
coherently. Pick one generation and hold it.

⚠️ **This is a BUILD rule only. It is not a detection rule**: `timothyricks.com` mixes v2.0.x and
v2.1+ markers, so scoring a mixed site as "matches no Lumos profile" is wrong. See §1b.

### ⚠️ Before you start: the token tier cannot be built through MCP

The author's own site holds its type scale, section spacing and gutters in **`clamp()` tokens**, and
`update_style` silently rejects `clamp()`; **one rejected property voids the whole call**
([../conventions.md](../conventions.md) §6).

**Sequence that works:**

1. Author the ~15 fluid tokens **by hand in the Designer's variable panel**, or as a `:root` block
   in the `u-embed-css` / `page_code_base` embed.
2. Only then build classes with MCP, referencing them via `variable_as_value`. A class saying
   `max-width: var(--site--width)` writes fine; the token holding the `clamp()` does not.

🚫 **Do not substitute static rem values to make the build MCP-friendly.** That is a different
convention wearing Lumos class names.

### Build order for a blank project (V2.0.x)

1. **Shell.** `.page_wrap` on the body's child › `.page_main` on `<main>`.
   ✅ *Verified 2026-08-05 on the author's site:*
   `.page_wrap { display:flex; flex-flow:column; width:100%; min-height:100vh; position:relative; overflow:clip }`
   so `min-height:100vh` and the flex column are part of it, not just `overflow:clip`. `.page_main`
   carries **no CSS**, a named, applied, empty class, like Client-First's `main-wrapper`.
2. **Code stack.** One `Custom Code` component rooted at `.page_code_wrap`, holding
   `page_code_base` / `page_code_color` / `page_code_responsive` / `page_code_custom` in that fixed
   order, instanced on every page. Project CSS goes here, **not** in Site Settings.
3. **Tokens before classes.** One collection, one mode. cssNames `--group--name`. A rem size ladder
   as the primitive tier; semantic tokens as reference chains onto it; colour literals confined to a
   swatch tier. `--max-width--main` 90rem. Use the leading-dot naming tiers (`...` theme/component,
   `..` semantic, `.` typography role, none = primitive) so the variables panel sorts.
4. **Sections.** `{group}_wrap` on the `<section>`/`<header>`/`<footer>`, carrying `data-theme` and
   `data-padding-top`/`-bottom`; no section-level padding class. Then `{group}_contain` + the
   shared `u-container`. Then `{group}_layout` where layout is non-trivial.
   ⚠️ Pick one spelling, `_contain`, and hold it; the starter's `_container` holdouts are
   residue you are not obliged to reproduce.
5. **Utility layer.** `u-hflex-{j}-{a}` / `u-vflex-{j}-{a}`, `u-gap-*`, `u-column` / `-full` /
   `-indent`, `u-grid-custom`, `u-h1`…`u-h6`, `u-text-large` / `u-text-small`. Dashes only.
   ⭐ *Observed 2026-08-05 — utility scales are **numeric**, not keyword:* `u-gap-0…8`,
   `u-gap-row-0…8`, `u-mb-1…7`, plus `u-align-self-{start|center|end}`, `u-grid-autofit`,
   `u-cover` / `-absolute`, `u-display-none` / `-contents`, `u-btn-group`, `u-link`, `u-icon`.
   **The `none|small|main|large` keyword scale governs section spacing only** (step 7), not gaps;
   conflating the two is the commonest Lumos build error.
6. **The stacking rule, enforced from element one:** named class first, utilities after, bespoke CSS
   only on the named class.
7. **Scale keywords `none | small | main | large`** for section spacing and gaps. `main` is the
   default step, not a maximum.
8. **Theming** by `data-theme` (`light|dark|invert|inherit`) resolved in `page_code_color`, with the
   nesting-inversion rule.
9. **Responsiveness** by remapping `:root` primitives inside `@media` in `page_code_responsive`,
   not by per-class breakpoint overrides.
10. **Components** named broadest-first, grouped with ` / `, configured by Title Case enum props that
    write the `data-*` attributes from step 4. `g_`-prefixed classes for anything backed by a
    `Global / *` component.

---

## 8 — ⭐ v2.2 starter read directly (2026-08-24)

A full page was built inside a real **Lumos V222 starter**, so the pieces below move from 📄 to ✅.
This does not clear the whole v2.1+ row: what is listed here is what was exercised.

### ✅ Cap-height text trim is ON by default, and it is the single biggest porting hazard

Lumos trims every text element to its **cap height**, so a heading's box ends exactly on the
baseline and starts exactly at the cap. It is implemented with the classic crop pseudo-elements:

```
::before { content: ""; display: table; margin-bottom: calc(var(--trim-top) * 1em - 0.5lh) }
::after  { content: ""; display: table; margin-bottom: calc(var(--trim-bottom) * 1em - 0.5lh) }
```

Measured on the V222 starter with Manrope: `--_text-style---trim-top: 0.33em`, trim-bottom `0.38em`,
so every trimmed box is `0.71em` tall regardless of line-height. A 58px/1.3 heading renders a
41.2px box instead of 75.4px; a 24px/1.5 label renders 17.05px instead of 36px.

**Who gets trimmed:** `p`, `h1`–`h6`, and anything carrying a `u-text-style-*` class. Plain
`<div>`s without a text-style utility are **not** trimmed. Verify per element rather than assuming
— `.link-arrow_text` (div) was untrimmed while `.stats_value` (div + `u-text-style-h2`) was trimmed.

**Why it bites.** Trimmed elements have **zero optical space between them**: stack a trimmed heading
directly above trimmed body copy and the body's cap-tops land on the heading's baseline. Lumos
intends you to space them with its own margin scale. Any design authored **without** trim — every
Client-First site, every Figma-to-Webflow build that relies on line-height — carries its spacing
inside its line-heights, and those values do not transfer. Porting CF 6's spacing verbatim produced
collisions in five places (hero badge, quote rows, process steps, stats band, footer info).

**The switch.** `.u-text-trim-off` sets `content: none` on both pseudos. It is **element-scoped and
does not inherit**, so putting it on `page_wrap` or `body` does nothing. Lumos's own trim rule is
`!important`, so a scoped override needs `!important` too:

```css
.page_main :is(p, h1, h2, h3, h4, h5, h6, [class*="u-text-style"])::before,
.page_main :is(p, h1, h2, h3, h4, h5, h6, [class*="u-text-style"])::after {
  content: none !important;
}
```

**Decide the trim policy before you port a single spacing value.** Trim off reproduces an untrimmed
source exactly and for free at every viewport. Trim on means re-deriving every gap as
`source spacer + heading half-leading + body half-leading`, where both half-leadings scale with
fluid font sizes and your margin token does not — so it only holds at the width you computed for.

### ✅ `text-wrap: balance` is on the heading tag styles

Set in the Designer on the h1–h6 tag selectors, not in an embed. Headings therefore break into even
lines rather than greedily. A ported design will never match its source's line breaks even when
font-size, weight, tracking, family and column width all measure identical. Keep it or override it,
but say which and why.

### ✅ The nav is fixed and takes no space in flow

`nav_component` is `position: fixed`, `z-index: 1000`, and `page_main` starts at y=0 behind it.
Lumos exposes `--nav--height-total` = `calc(var(--nav--height) + var(--nav--spacing-outer-vertical))`
(~104px desktop, ~90px at 667px — the spacing half is fluid). The first section must reserve it.
A Client-First source solves the same problem with a `.nav_blank-space` sibling; port that as
`padding-top: calc(var(--nav--height-total) + <source's own section padding>)` on the first section.

### ✅ Other v2.2 mechanisms exercised

- `u-theme-*` variable-mode theming works as documented: `.u-theme-brand` on a wrapper re-points
  `--_theme---*` for everything inside it, including a nested Button Main instance.
- Fluid `clamp()` tokens driven by `--site--viewport-min` / `--site--viewport-max` are the
  responsive type mechanism; `@media` remaps of tokens were not used.
- `--swatch--*` confirmed again as the colour-literal tier beneath `--_theme---*`.
- Derived hover colours are `color-mix(in srgb, <base>, white 10%)` per theme mode, not literals.

## Still unverified

- **Most of the v2.1+/v2.2 generation.** §8 (2026-08-24) verified the text trim, `text-wrap: balance`,
  the fixed nav and its height token, `u-theme-*` variable modes, the fluid `clamp()` token tier and
  `--swatch--*` on a real V222 starter. Still doc-only: the calc-width container and
  `container-type` on it, container-query responsiveness, `data-trigger`/`data-state`, and component
  Variants.
- **"Most real Lumos sites in the wild descend from 2.0.x"** is the reconciliation's assertion, not a
  survey. The operational rule stands regardless (absence of v2.1+ markers must never disqualify),
  but the population claim itself is unmeasured.
- **V1 beyond class names.** One 2023 site was read. Its structural chain below `_wrap`, its spacing
  and its code stack beyond the presence of `page_code_wrap` were not enumerated.
- **The V1 encoded-modifier vocabulary.** Only `fs` (font-size step) is glossed in the research;
  `vt`, `vb`, `sm`, `bw`, `br`, `pd`, `gp` are read off class names and their expansions are
  **inferred, not confirmed.**
- **Hover / focus conventions.** Every style read was base + `noPseudo`, on all three reference sites.
- **Order of nav/footer components within `.page_wrap`** relative to `page_code_wrap`.
- **Token values beyond those quoted**: `--max-width--main` 90rem, `--padding-horizontal--main`
  3.5rem and its ≤991/≤767 remaps, `--border-width--main` 1.5px. The rest of the ~160 tokens were
  not enumerated.
- **Whether any migration path or codemod exists between generations.** Nothing in the research
  addresses it; assume none.
- **Class dating.** MCP exposes no per-style timestamp, so "residue vs rule" here (including the
  `_container` holdouts and `g_eyebrow_text--fs7`) is decided by page-level proxies only.
