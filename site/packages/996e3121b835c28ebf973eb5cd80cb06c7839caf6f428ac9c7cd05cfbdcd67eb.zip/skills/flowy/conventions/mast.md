# MAST — convention profile

> By No-Code Supply Co. Self-described *"a lightweight, component-first framework"*.
> Derived from official documentation, then **reconciled against a live v2.4 starter on
> 2026-07-29**. Where the two disagreed, the site won, and it disagreed twice, both times
> importantly. Loaded by [../conventions.md](../conventions.md) when MAST is recognised.

**Legend** — ✅ verified on a real site · 📄 documented only, never seen on a site · ⚠️ trap · 🚫 never.

**A claim carrying 📄 is not weaker doctrine, it is untested doctrine.** Do not score a recognition
decision on a 📄 pattern alone, and do not "fix" a project for violating one.

## ⚠️ Read this before scoring: MAST has two modes

**Design Mode** builds with classes. **Build Mode** builds with components, and routes what the
documentation describes as classes through props and variants instead.

Every documented class fingerprint below describes Design Mode. On a Build-Mode project the same
decisions exist but are invisible to a class search. **A profile that models only the class
vocabulary will fail to recognise MAST's own current starter.** Both forms are given for every
pattern where they differ.

The mode is itself detectable: `<main>.page-main › .page-slot`, a `DropTarget` carrying
`id="build-mode-page-slot"`, means Build Mode. The starter also ships two draft pages literally
named `Build Mode Blank` and `Design Mode`.

---

## 1 — Fingerprint

### Anchor — one of these, verified, not name-matched

| Mode | Anchor |
|---|---|
| **Design Mode** | the `section` › `container` chain **confirmed in the DOM**: bare `section` setting vertical padding only, with `container` as the width owner |
| **Build Mode** | a **`Section` component exposing a boolean container/width prop**, together with a **`Grid Column` component whose variants are `Fill` / `Shrink` / `N/12`** |

### Corroborators

| Pattern | Strength | Note |
|---|---|---|
| **`cc-` prefix on combo/modifier classes** | **sharpest single discriminator** | Client-First and Lumos both use `is-`. MAST uses `cc-`. ✅ *Confirmed live: a component tooltip instructs "Add `cc-active` to make this the active tab".* |
| `u-` utilities **with MAST vocabulary** | strong | `u-mb-sm`, `u-mlr-auto`, `u-img-cover`, `u-link-cover`, `u-mode-dark`, `u-sr-only`. ✅ *Confirmed live: a component's `Class` prop defaults to `u-mb-sm`.* ⚠️ The `u-` prefix alone collides with Lumos (see [../conventions.md](../conventions.md) §4) |
| **breakpoint infix after `u-`**: `u-md-d-none` | strong | **No Lumos generation does this.** Cleanest way to break the `u-` collision |
| `page-wrapper` **paired with** `page-main` | strong | ✅ *Confirmed live.* Never score `page-wrapper` alone: Client-First uses it too, paired with `main-wrapper`; Lumos uses underscores |
| `row-*` modifier family | strong | `row-justify-between\|center\|around\|end`, `row-align-center\|end`, `row-content-*`, `row-gap-md\|sm\|button\|0`. ✅ *Confirmed live: a Grid Row instance carried `row-gap-button` via its `Class` prop.* Note these do **not** take the `cc-` prefix |
| `col-{lg\|md\|sm\|xs}-{1..12}` | **Design Mode only** | ⚠️ **Absent from Build Mode entirely**; see §2. Documented as near-conclusive; verified *not present* on the live Build-Mode starter |
| `col-lg-contain-left\|right`, `col-shrink`, `col-lg-offset-3`, `col-no-gutters` | strong, Design Mode | The break-out-of-container mechanism; no equivalent name in the other two systems |
| `data-animate="stagger-children"` | strong | ✅ *Confirmed live as an `Animate` prop with exactly that tooltip on Section, Grid Row, Grid Column and Content Wrap.* Discriminate from Lumos's `data-*` layer by scope: **MAST's attributes control animation only**; Lumos's control theme, padding and button style |
| `styles__` prefix | documented | Style-guide-page-only classes. Not verified live |
| `-component` suffix on componentised roots | strong | `content-wrap-component`, `spacer-component`, `plain-text-component`, `theme-toggle-component` |
| bare `section`, `container`, `row`, `col` | weak alone | Decisive only in combination with `cc-` and `col-lg-*`. Webflow's legacy grid carries `w-` (`w-row`, `w-col`), so `col-lg-8` with no `w-` stays strong |

---

## 2 — Section › Container, as MAST spells it

### Design Mode — a class chain

```
section        bare class · vertical padding only (fluid clamp() since v2.3) · full-bleed by construction
  └ container  bare class · max-width AND horizontal gutters
      └ row
          └ col
```

Knock out vertical padding with the utilities `u-pt-0` / `u-pb-0`.

**MAST has no `padding-global` equivalent.** Gutters live on `container` itself. This is the key
structural difference from Client-First, where gutters and max-width are deliberately separate
levels.

### Build Mode — a component prop

```
Section  (component, group "Layout")
  └ prop:  Container · boolean · group "Settings" · default true
      └ slot cc-section
          └ Grid Row → Grid Column → slot cc-column
```

**✅ Verified 2026-07-29; this is the refutation that matters most.** The documentation never
states the section/container chain as a rule; the research derived it from examples and flagged it
as needing DOM confirmation. Confirmed: **in Build Mode it is a boolean prop on the `Section`
component, not a class relation at all.**

🚫 **A classifier tracing `section` › `container` as a parent→child class relation finds nothing on
a Build-Mode MAST site and will report zero conformance on a perfectly conformant project.** Check
for the component prop as a first-class alternative.

### Enclosing page structure (both modes)

```
.page-wrapper                 <div>  — global background/text colour, Theme variable mode
  ├ ⬡ Custom Code
  ├ ⬡ Nav Banner
  ├ ⬡ Nav                     <nav>
  ├ .page-main                <main>
  │   └ .page-slot            DropTarget, id="build-mode-page-slot"   ← Build Mode only
  └ ⬡ Footer                  <footer>
```

---

## 3 — Class-naming grammar

- **Lowercase throughout**, hyphen separates words.
- **Base classes carry no prefix**: `section`, `container`, `row`, `col`, `form`, `input`, `btn`,
  `eyebrow`, `card`, `rich-text`, `modal`, `nav`, `h1`.
- **`cc-` prefixes combo/modifier classes.** Never stands alone; only added to a base or custom class.
- **`u-` prefixes utilities.**
- **`styles__`**, double underscore, marks style-guide-only classes.
- **Size tokens are postfixes**: `paragraph-xl`, `u-mb-lg`.
- **Breakpoint tokens are infixes**: `col-lg-8`, `u-md-d-none`.
  ⚠️ **The same tokens mean different things by position.** `-lg` at the end is a size; `-lg-` in
  the middle is a breakpoint. This positional distinction is itself a MAST tell.
- Underscores appear inside custom class names for element roles (`nav-menu_btn-bar`), with
  hyphenated multi-word segments on both sides. That is how MAST's underscore use differs from
  Client-First's (one underscore, `_component`/`_item`/`_list` terminals) and Lumos's (up to three,
  `_wrap`/`_contain`/`_layout` terminals).

**The 80/20 stance is explicit in the docs**: the framework's class set is meant to build ~80% of a
site, with the remaining 20% expected to be custom classes and custom code. **Custom classes
alongside MAST classes are conforming, not residue.** Do not flag them.

---

## 4 — Style architecture

- **Modified BEM**, developer-first framing.
- **Bootstrap-derived, Flexbox-based 12-column grid**: expressed as classes in Design Mode, as
  `Grid Column` variants in Build Mode.
- **CSS custom properties** in the triple-dash shape `--_layout---grid--gap-md`.
  ✅ *Confirmed live: a `Slider` component's gap prop defaults to
  `--gap: var(--_layout---grid--gap-md)`.*
- **Variable modes** carry theming: the `Theme` variant prop on Nav, Footer and Section
  (`base` / `Accent`), with the mode set on `.page-wrapper`.
- **Icons are Phosphor**, configured by class string (`ph ph-cube`) through a prop, not by asset.
- **Project CSS lives in a `Custom Code` component**, not in Site Settings, with per-feature
  visibility toggles (Marquee, Accordion, Modal, Slider, Inline Video, Tabs) plus a `Canvas QA`
  toggle that surfaces authoring problems on the canvas.
  ⚠️ **Empty Site Settings custom code is therefore not evidence of no system.**
- Approximate published footprint: ~84kb base CSS, 11 universal components, 67 grid classes,
  50 utility classes. The live v2.4 starter carried **36 components**.

### Breakpoints

Four, verified live: `main` Desktop (base) · `medium` ≤991 · `small` ≤767 · `tiny` ≤479.
**No `large` / `xl` / `xxl`.** A wide canvas therefore still edits base on this site; re-check
per project rather than assuming.

---

## 5 — Component practice

**This is the part of MAST worth copying**, and it is the target the idiom test measures against.

- **Title Case names**, grouped: `Global` · `Layout` · `Content` · `Interactive` · `Nested` ·
  `Style` · `CMS`.
- **`Nested` group components carry a description of the form *"Only for use within the X
  component"***: an explicit convention for marking non-standalone components. Reproduce it.
- **Variants carry design state; props carry content. Never mixed.**
  Button `Primary`/`Secondary`; Heading `Inherit`/`H1`…`H6`; Grid Column `Fill`/`Shrink`/`N/12`;
  Grid Row 12 alignment combinations.
- **Near-every component exposes the same `Advanced` prop block:**

  | Prop | Type |
  |---|---|
  | `Visibility` | `visibility` |
  | `Class` | `string` — modifier-class escape hatch |
  | `Style` | `string` — inline-style escape hatch |
  | `ID` | `id` / `string` |
  | `Attribute Name` / `Attribute Value` | `string` |
  | `Slot` / `Slot content` | `slot` |
  | `Animate` | `string`, tooltip *"Add \"stagger-children\" to animate the children…"* |

- **Tooltips are written for the person operating the component**, not for the builder.
- **Booleans are sometimes deliberately typed `string`** with a tooltip reading *"true or false"*,
  where the value is passed through into custom code rather than consumed by Webflow.
- **Slots are pervasive**: 18 of the 36 components on the live starter expose at least one.
  Marquee and Table expose two each.
- **Modifier classes travel through the `Class` prop**, not by adding a class to an element.
  ✅ *Confirmed live: a Grid Row instance carrying `Class = "row-gap-button"`.*
- ⚠️ **Gap and alignment travel by different mechanisms in the same component**: gap as a class
  through the `Class` prop, alignment as a variant. Do not assume one mechanism per concern.

---

## 6 — Violations

- A `section` with more than one width-constraining child, or none.
- Horizontal gutters applied anywhere other than `container` (MAST has no separate gutter level).
- A `cc-` class applied without a base class beneath it.
- A `u-` utility used to carry structure rather than a single-purpose override.
- A `Nested`-group component used outside its documented parent.
- A modifier class added directly to a component instance's element rather than passed via the
  `Class` prop.

**Flag, do not auto-fix.** Custom classes outside the MAST vocabulary are explicitly expected
(the 80/20 stance) and are never a violation.

---

## 7 — What the published CSS shows (2026-08-05)

Read from `mast-framework.webflow.io`, No-Code Supply Co's own style guide, **Design Mode** (no
`#build-mode-page-slot` present). 193 non-`w-` classes on the page-optimised stylesheet.

⚠️ **MAST runs CSS optimisation.** Its `.shared.` file is Webflow's base only: 6 classes. The
framework lives in the per-page `…<pageid>.<hash>.opt.min.css`. Reading the shared file and
concluding "no system" is the trap here.

### ⭐ MAST is fluid-token-first — this is the headline

Every heading is a `clamp()` computed from two fluid anchors, not a breakpoint override:

```
--_typography---h1--font-size: clamp(
    var(--_typography---h1--font-size-min-rem) * 1rem,
    …linear interpolation across (--_layout---fluid--min → --_layout---fluid--max)…,
    var(--_typography---h1--font-size-max-rem) * 1rem)
--_typography---h1--line-height: 1      --h1--font-weight: 500    --h1--letter-spacing: -.02em
--_typography---h1--bottom-margin: .2em     ← headings own their own bottom margin
```

Token namespace is `--_{collection}---{group}--{name}` throughout: `--_typography---*`,
`--_color---neutral--white`, `--_layout---grid--gap-main`, `--_components---container--gutter`.

**Consequence:** the four breakpoints listed in §4 exist but carry very little. **The responsive
system is the fluid token graph.** And `clamp()` cannot be written by `update_style` (see
[../conventions.md](../conventions.md) §6).

### ⭐ Verified structural values

```
.container   width:100%;  margin-inline:auto;
             max-width: min( 100% - var(--_components---container--gutter)*2,
                             var(--_components---container--max-width) )
```

🚫 **`min()` is Designer-only. MCP cannot write this rule at all.**

**This corrects §2.** The profile says *"container — max-width AND horizontal gutters."* It carries
**no padding whatsoever**: gutters are subtracted from the max-width inside `min()`. A build that
gives `.container` `padding-left/right` is not MAST.

```
.row   grid-row-gap: var(--_layout---grid--gap-main);
       margin-left/right: calc(var(--_layout---grid--gap-main) / 2 * -1)     ← negative-margin grid
.col   padding-left/right: calc(var(--_layout---grid--gap-main) / 2);
       flex: 1; display: flex; flex-flow: column
```

**A Bootstrap-style negative-margin gutter system**: `row` pulls out by half a gap, `col` pads in by
half. The two are a matched pair: **a `col` outside a `row` is misaligned by half a gutter**, which
is invisible until it sits beside a contained element.

```
.page-wrapper  background: var(--primary--background); color: var(--primary--text);
               display:flex; flex-flow:column; position:relative; overflow:clip
.page-main     display:flex; flex-flow:column; flex:1
```

### ⭐ Theming is compiled variable modes, not just `u-mode-*`

```
--primary--background: var(--lightningcss-light, var(--_color---neutral--white))
                       var(--lightningcss-dark,  var(--_color---neutral--black))
--primary--text:       var(--lightningcss-light, var(--_color---neutral--black))
                       var(--lightningcss-dark,  var(--_color---neutral--white))
```

Webflow **variable modes** compiled through LightningCSS, resolved on `.page-wrapper`. The
`u-mode-light` / `u-mode-dark` classes observed in the DOM are the **switch**, not the mechanism.
✅ Confirms §4's "variable modes carry theming" and gives the emitted shape.

### ⭐ Hover / focus — MAST is the only one of the three with a real state convention

```
.button:hover                  background-color: var(--primary--accent-dark)
.button:focus-visible,
.button[data-wf-focus-visible] outline-color: var(--primary--accent); outline-offset: …
a:focus-visible                same pattern
.eyebrow.cc-breadcrumb:hover   text-decoration: underline      ← cc- combos take states
.styles__nav-btn:hover         background-color: var(--_color---neutral--dark-gray)
.button:hover:where(.w-variant-…) background-color: color-mix(in hsl, var(--primary--accent) …)
```

Three things to copy:

1. **`:focus-visible` is applied systematically**, always paired with Webflow's
   `[data-wf-focus-visible]` fallback attribute, always via `outline-color` + `outline-offset`.
   **Client-First ships zero states; Lumos ships hover but little focus. This is MAST's genuine
   accessibility edge and the strongest reason to choose it.**
2. **States resolve to semantic tokens** (`--primary--accent-dark`), never literals.
3. **`color-mix(in hsl, …)` inside a `:where(.w-variant-…)`**: MAST uses Webflow **Variants** with
   state styling, and modern colour functions. Neither is MCP-writable.

### ⭐ Verified vocabulary counts

| Tier | Count | Sample |
|---|---|---|
| `col-*` | **87** | `col-lg-1…12`, `col-md-*`, `col-sm-*`, `col-xs-*`, `col-shrink` |
| `u-*` | 32 | `u-border u-d-flex u-h-100 u-link-cover u-m-0 u-mb-0 u-mb-auto u-minh-100vh u-sr-only u-full-height-center` |
| `row-*` | 14 | `row-align-center|end`, `row-content-between|center|end`, `row-gap-0|button|…` |
| `cc-*` | 13 | `cc-align-center cc-bottom cc-breadcrumb cc-cta cc-current-page cc-dropdown-btn cc-full cc-mega` |
| `styles__` | 11 | `styles__cover styles__nav-btn styles__nav-link styles__nav-logo styles__ncsc-logo` |
| `nav-*` | 9 | `nav-cta-wrapper nav-dropdown nav-dropdown_content nav-link nav-logo_link nav-menu nav-menu_btn nav-menu_btn-bar` |

✅ `nav-menu_btn-bar` confirms §3's underscore-for-element-role rule on a real artifact.
✅ `button` (not `btn`) is the styled class; `btn-icon` / `btn-text` are children. **Resolves the
docs' `btn` vs `button` contradiction: the block is `button`.**

### Building in MAST — order

1. **Tokens by hand first** (Designer variable panel or a `:root` embed): `--_layout---fluid--min/max`,
   the `--_typography---*` min/max rem pairs, `--_layout---grid--gap-main`,
   `--_components---container--gutter` / `--max-width`, the `--_color---*` primitives, then
   `--primary--*` semantic modes. **Nothing else can be built until these exist.**
2. **Shell**: `.page-wrapper` › `.page-main`, both with real CSS (above), unlike CF's and Lumos's
   empty shells.
3. **`Custom Code` component** as first child, with its per-feature toggles. Site Settings stays empty.
4. **`.container` by hand**; the `min()` rule is Designer-only.
5. **`.row` / `.col` pair**, never one without the other.
6. **Sections**: bare `section` with vertical padding only, `u-pt-0` / `u-pb-0` to knock it out.
7. **`cc-` for modifiers, `u-` for utilities, `col-{bp}-{n}` for widths.**
8. **States**: `:focus-visible` + `[data-wf-focus-visible]`, `outline-color` from a semantic token.

---

## Still unverified

- ✅ ~~`styles__` prefix — style-guide page classes not read~~ **Closed 2026-08-05:** 11 present,
  style-guide-only as documented.
- `col-lg-contain-left|right`: still no instance encountered on a live page.
- ✅ ~~Numeric defaults for container max-width, section padding, grid gap~~ **Partly closed:** the
  *mechanism* is verified (`min()` container, negative-margin row/col, fluid clamp type). The literal
  rem numbers sit behind `--_layout---fluid--min/max` and were not resolved to values; read the
  variable panel on a real project.
- ✅ ~~Hover / focus conventions~~ **Closed 2026-08-05**; see §7. The strongest of the three.
- ✅ ~~`btn` vs `button` naming~~ **Resolved 2026-08-05: `button`.**
- 🚫 **Build Mode has never been read on a published site.** Everything in §7 is Design Mode. The
  Build-Mode component/prop surface still rests on the Designer read of 2026-07-29. **Before a
  Build-Mode project, read one.**
