# Client-First — convention profile

> By Finsweet. v2.x. A **convention over a framework**: a flat hand-authored global utility layer
> plus a thin namespaced custom-class layer, joined by a fixed structural chain inside every section.
> Derived from official documentation, then **reconciled against the shipped "Client-first Starter
> 2023" cloneable, with spot-checks re-verified live on 2026-07-29**. Where the two disagreed, the
> site won, and it disagreed on the single most load-bearing rule in the system. Loaded by
> [../conventions.md](../conventions.md) when Client-First is recognised.

**Legend** — ✅ verified on a real site · 📄 documented only, never seen on a site · ⚠️ trap · 🚫 never.

**A claim carrying 📄 is not weaker doctrine, it is untested doctrine.** Do not score a recognition
decision on a 📄 pattern alone, and do not "fix" a project for violating one.

## ⚠️ Read this before scoring: the docs describe two divs, the starter ships three

The documentation says the two padding classes **stack on one div**: literal markup
`class="padding-global padding-section-large"` whose only child is `div.container-large`.

**That form appears nowhere in the shipped starter.** The real chain is three separate divs, with
`padding-section-*` on the **outside**:

```
div.padding-section-large  ›  div.padding-global  ›  div.container-large
```

✅ **Verified across all 16 `padding-section-large` instances on the style-guide page.** The two
classes are never once stacked on the same element anywhere in the starter.

🚫 **Do not key on co-occurrence of the two classes in one class attribute.** A detector matching the
literal string `"padding-global padding-section-large"` scores **zero** on Finsweet's own official
2023 starter. Detect the ordered parent→direct-child relation **`padding-global` → `container-*`**
instead; it is the true invariant and it holds under *both* topologies.

**Accept both arrangements as conformant. Never emit a violation for either ordering.**

### Version reality

The docs' last changelog milestone is v2.1 (Jan 2023) and the reference artifact is the 2023
starter; the two are consistent, and every v1→v2 discriminator that is actually observable reads as
v2.

| Version test | Usable? |
|---|---|
| `padding-global` present, `page-padding` absent | ✅ **use this** |
| `hide-*` present with **no** `show-*` anywhere | ✅ **use this** |
| `section-` dash vs `section_` underscore | 🚫 **unusable**: the class it depends on is absent from the reference starter entirely (see §1) |

---

## 1 — Fingerprint

### Anchor — property signature plus a structural relation, never a name match

> **`padding-global` carrying padding-left/right and nothing else, whose *direct child* is
> `container-small|medium|large` carrying max-width with *zero* padding.**

Both halves are required. The name alone is not the anchor; the property purity and the
parent→direct-child relation are. This is the one marker that survived the largest doc/site
disagreement in the system intact, because it is true under both topologies.

### Corroborators

| Pattern | Strength | Note |
|---|---|---|
| `padding-section-small\|medium\|large` with a **vertical-only** signature at **8/6/4 · 5/4/3 · 3/2 rem** | strong | ✅ *Site-verified.* The docs flagged these numbers as an unverified prior from one style-guide instance; the real site matches them exactly. ⚠️ **Optional layer**: absence must never score down (see §2) |
| `container-small\|medium\|large` as a trio at **48 / 64 / 80 rem**, `width:100%`, `margin-inline` auto, **zero padding** | strong | ✅ *Site-verified.* **The absence of padding here is as diagnostic as the max-width** |
| Direction classes matched by their **inverted-mask signature**: three sides explicitly zeroed, the named side conspicuously absent | **very high precision** | Essentially no other system builds spacing this way. More robust than name matching. See §4 |
| The `tiny → xxhuge` ladder plus `custom1/2/3`, across `margin-*`, `padding-*` **and** `spacer-*` | strong | The `huge` tier sitting **above** `xxlarge`, plus named `customN` escape hatches, is a scale no other system uses |
| `is-*` combos that **never exist as base styles** | strong | ✅ *Site-verified: 15 of 15 registered combos use `is-`, every one bound to a specific parent, none registered standalone.* ⚠️ **Counter-intuitive; see below** |
| `text-size-regular` | strong | Not `base`, not `body`. A genuine CF tell inside the `text-size-*` family |
| `hide-tablet` **with no `show-*` anywhere in the project** | strong | The v1→v2 removal is borne out by the artifact |
| `{namespace}_component` roots | strong | ✅ *Site-verified: `home-message_component`, `utility-page_component`, `form_component`, `fs-styleguide_component`.* ⚠️ **A naming convention, not a Webflow Component; see §5** |
| `max-width-full-tablet` / `-mobile-landscape` / `-mobile-portrait`: **empty base, exactly one breakpoint override each** | strong | The site supplies the mechanism the docs omit |
| **Negative fingerprint**: a total absence of flex / grid / gap / column / Tailwind-style utilities | strong | ✅ *Held perfectly on the real site.* The docs' "no layout system" claim survives contact fully; layout lives on custom classes |
| `page-wrapper` **paired with** `main-wrapper` (on `<main>`) | moderate | ⚠️ Never score `page-wrapper` alone: MAST uses it too, paired with `page-main`. See [../conventions.md](../conventions.md) §4 |
| `spacing-clean`, `display-inlineflex`, `global-styles`, `button-group`, `icon-1x1-*` / `icon-height-*` | weak, **any N of M** | ✅ *`spacing-clean`, `display-inlineflex`, `global-styles` re-verified as registered styles.* 🚫 **Never test conjunctively: `inherit-color` is documented but does not exist on the starter** |
| `section_{identifier}` at position 0 | **positive-only, near-zero recall** | 🚫 **Zero `section_` classes exist in the starter.** Presence is near-conclusive; absence is worthless as counter-evidence. See below |
| `fs-styleguide_*` | **separate lineage bucket** | Highest-precision marker available, but it proves **clone origin, not discipline**; see below |

### ⚠️ `is-*` abundance pushes toward Client-First, not away from it

This runs opposite to intuition and it is the point most often got backwards.

**Client-First uses `is-` combo classes systematically**: 15 registered on the starter, all at
combo depth 2, every one parent-bound. **Lumos 2.0.3 has exactly two.** MAST uses `cc-` instead.

So a project dense with `is-*` combos is being pushed **toward Client-First**, not toward Lumos.
Cross-referenced in [../conventions.md](../conventions.md) §4.

### 🚫 `section_` — the trap inside the trap

The docs mark `section_[identifier]` a *unique* fingerprint: every section wrapper in one `section_`
folder, `section_home-header` / `section_testimonials` / `section_contact`.

**The shipped starter has none.** A query over every style whose name contains "section" returned
only `fs-styleguide_section`, `fs-styleguide_section-header`, and `padding-section-small|medium|large`.
Section-level elements carry component-namespaced classes instead.

Two consequences:

1. **Anchor the match to the literal prefix `section_` at position 0.** A naive substring search for
   "section" false-positives on `padding-section-large` and `fs-styleguide_section`, which are
   present on every Client-First site.
2. Its absence proves nothing. Positive-only signal.

### 🚫 `fs-styleguide_*` — lineage evidence, not discipline evidence

All 40+ style-guide classes on the starter carry the **`fs-` vendor prefix**:
`fs-styleguide_component`, `fs-styleguide_section`, `fs-styleguide_header`,
`fs-styleguide_heading-tags`, `fs-styleguide_1-col` … `_4-col`. The docs show them unprefixed
(`styleguide_sidebar`, `styleguide_structure`); **match both forms.**

They sit on a page flagged **`draft: true`**, built to be deleted before launch.

**Score this in a separate bucket from production-class evidence.** It is near-conclusive for
"cloned from the CF starter" and says nothing about "built to CF". **Its absence must never lower a
score**: a launched Client-First site should have none of it.

### Minimum viable detector

> The parent→direct-child pair **`padding-global` > `container-{small|medium|large}`**, plus **any
> two** of `padding-section-*` · an `is-*` combo · the `tiny → xxhuge` ladder · `text-size-regular` ·
> `hide-tablet` · the direction-mask signature.

That set is robust to every drift catalogued in this file.

---

## 2 — Section › container, as Client-First spells it

```
[full-bleed element]                          tag VARIES — header, section, or plain div
  └ .padding-section-{small|medium|large}     vertical rhythm ONLY   ← OPTIONAL layer
      └ .padding-global                       horizontal gutters ONLY
          └ .container-{small|medium|large}   max-width ONLY
              └ content
```

**Separation of concerns is strict, and it holds in both sources.** This is the part of Client-First
worth copying, and the part a detector must read by property rather than by name.

| Level | Owns | Measured values | Carries nothing else |
|---|---|---|---|
| `padding-global` | horizontal page gutters | `padding-left` / `padding-right` **2.5rem** base → **1.25rem** at `small` | ✅ no vertical padding, no max-width |
| `padding-section-large` | vertical rhythm | `padding-top`/`bottom` **8rem** base → **6rem** `medium` → **4rem** `small` | ✅ no horizontal padding |
| `padding-section-medium` | vertical rhythm | **5rem** → **4rem** → **3rem** | ✅ |
| `padding-section-small` | vertical rhythm | **3rem** → **2rem** at `small` | ✅ |
| `container-small` | max-width | `max-width: 48rem`, `width:100%`, `margin-left/right: auto` | ✅ **zero padding** |
| `container-medium` | max-width | `max-width: 64rem`, same | ✅ **zero padding** |
| `container-large` | max-width | `max-width: 80rem`, same | ✅ **zero padding** |

The docs' most emphatic architectural claim, that padding must stay decoupled from max-width,
is honoured verbatim by the shipped starter. Nothing else on the site sets page-edge gutters.

`container-*` is the only width constraint in the structural chain. Nested width limits use a
separate `max-width-*` family (`xxsmall` 12rem through `xxlarge` 80rem). Both sources draw the same
line.

### ⚠️ `padding-section-*` is optional — absence is not evidence

Both patterns ship **inside the same reference artifact**:

| Page | Pattern |
|---|---|
| Style Guide | `padding-section-large` on all 11 sections |
| Home | **exactly one** `padding-global` on the entire page, parented by `div.home-message_content`, with **no `padding-section` layer at all**; the component class owns its own vertical rhythm |

🚫 **A detector requiring all three layers rejects legitimate Client-First marketing pages.** The
genuinely invariant part is `padding-global` > `container-*`. Score `padding-section-*` as a
positive-only signal with partial coverage.

### 🚫 Do not require `<section>` at the full-bleed level

The tag is set per element and is **not reliably `section`**. Checking the six parents of
`padding-section-large` returned:

| Tag | Class on it |
|---|---|
| `header` | `fs-styleguide_header` |
| `section` | `fs-styleguide_structure`, `_heading-tags`, `_other-tags`, `_heading-styles` |
| **`div`** | `fs-styleguide_spacing` — a plain div occupying the identical structural slot |

Home's hero is `<header class="home-message_component">`.

**Semantics live on the tag setting, never on the class name.** Identify the full-bleed level
**structurally**: *the nearest ancestor of `padding-global` that sets neither max-width nor
horizontal padding.* Anything keyed on `<section>` misses roughly a third of real CF section-level
elements.

### Page shell

```
<body>
  └ .page-wrapper          body's ONLY child
      ├ ⬡ Global Styles    the only registered Webflow Component in the file
      ├ .nav_fixed         ✅ observed 2026-08-05 — see below
      └ .main-wrapper      <main>
```

### ⭐ The nav — observed 2026-08-05, previously recorded as absent

The 2023 read concluded the starter ships no navbar. **The current cloneable ships a full one**, and
it is structurally instructive:

```
.nav_fixed              position:absolute; inset:0 0 auto
  └ .nav_component      background:#000; padding-top/bottom:1rem; position:relative; inset:0 0 auto   [.w-nav]
      └ .padding-global           ← the SAME gutter class the sections use
          └ .nav_container        flex; justify-content:space-between; align-items:center;
                                  width:100%; max-width:80rem; margin-inline:auto
              ├ .nav_brand › .nav_logo
              └ .nav_menu › .nav_menu_link ×2
                 .nav_button (hamburger)
```

Family: `nav_fixed · nav_component · nav_container · nav_brand · nav_logo · nav_menu ·
nav_menu_link · nav_button`.

**Copy the first two; note the third:**

- ✅ **The nav reuses `padding-global`.** Gutters are shared with sections: the gutter tier is
  global chrome, not section-only. Build a CF nav the same way.
- ✅ **`nav_*` follows `{namespace}_{element}` exactly** like `hero_grid` / `hero_content`. Global
  chrome gets no special grammar.
- ⚠️ **`nav_container` duplicates `container-large`'s 80rem rather than composing with it.** It
  re-declares `max-width:80rem; margin-inline:auto` instead of stacking `container-large`. This is
  the starter's own choice, not a documented rule: **do not treat a composed
  `padding-global › container-large` nav as non-conforming**, and do not "fix" a duplicated one.

### 🚫 Footer — still genuinely absent

No `footer*` class exists anywhere in the compiled CSS (checked 2026-08-05). **A Client-First build
has no footer pattern to inherit.** Derive one from the `{namespace}_{element}` grammar
(`footer_component` / `footer_container` / `footer_link`) and say in the plan that it is derived,
not doctrinal.

⚠️ **Both classes return `properties {base:{}}`, completely empty.** They are registered and applied
but style nothing; they are pure structural and semantic hooks. The docs imply `page-wrapper` carries
page-level styling instead of `<body>`; it does not.

🚫 **Detect them by name, position and tag, never by CSS.** A stylesheet-only crawler that skips
zero-property classes silently misses two of the six core-structure classes and under-scores a
perfectly conforming site.

---

## 3 — Class-naming grammar

- **All lowercase.** Neither source contains BEM `__` or `--`, camelCase, or PascalCase anywhere.
- **Hyphen separates words.**
- **Underscore separates a component namespace from an element role.**
- **Utilities never contain an underscore. Component-scoped classes always do.** That is the cleanest
  tier test in the system.
- **Variants are `is-` combo classes and never stand alone.**

```
padding-global          utility     — no underscore
text-size-regular       utility     — no underscore
home-message_component  namespaced  — exactly one underscore
form_component          namespaced
.button.is-large        combo       — is-* is never a base style
```

### ⚠️ Exactly-one-underscore is the empirical mode, not a rule

No class anywhere on the starter has two underscores, and DOM nesting is never encoded:
`home-message_item` sits inside `home-message_list` but is **not** named
`home-message_list_item`.

But **nested folders are explicitly sanctioned by the docs** (`slider_1_component`,
`page-folder_keyword-folder_element`, three levels endorsed for large component libraries), so a
second underscore is legal and **must not be treated as disqualifying or flagged as a violation**.

> **Test for:** *contains at least one underscore · is all-lowercase · contains no `__` and no `--`.*
> **Do not count underscores to exactly one.**

Depth and terminal vocabulary are what separate the three conventions' underscore use: Client-First
is one underscore in practice terminating in `_component` / `_item` / `_list`. See
[../conventions.md](../conventions.md) §4.

---

## 4 — Style architecture

Two layers, and the joint between them is the whole design: a **flat, hand-authored global utility
layer** (spacing, sizing, typography, colour, display, visibility) and a **thin namespaced
custom-class layer**.

**Deliberately NOT utility-first.** It ships no flex / grid / column / gap utility system at all, and
the docs argue against one. ✅ *Confirmed absent from the real site; layout lives on custom classes.*

### The spacing ladder

```
0 · tiny · xxsmall · xsmall · small · medium · large · xlarge · xxlarge · huge · xhuge · xxhuge
  · custom1 · custom2 · custom3
```

Applied to both `margin-*` and `padding-*`, and mirrored by an empty-div `spacer-tiny` … `spacer-xxhuge`
family. Identical in both sources.

### ⚠️ Direction classes are MASKS, not setters

The docs read as though `margin-top` sets the top margin: *"First, we apply the direction class,
`margin-top`. Then we apply the size class, `margin-large`."*

What the site actually does:

| Class | Declares |
|---|---|
| `.margin-bottom` | `margin-top: 0` · `margin-right: 0` · `margin-left: 0`, **and does not declare `margin-bottom` at all** |
| `.margin-small` | all four sides `1rem` |

The pair composes to bottom-only spacing **by zeroing the other three**.

🚫 **A property-level detector must not expect `.margin-top` to declare `margin-top`**: that check
fails on every Client-First site. Match the direction family by its **inverted signature**: three
sides explicitly zeroed, the named side conspicuously absent. That signature is itself a very
high-precision fingerprint.

### Typography

📄 **Documented only; the full family list below was not enumerated against the starter.**
Single-purpose prefix families: `text-size-*` · `text-weight-*` · `text-style-*` · `text-color-*` ·
`text-align-*`, plus `heading-style-h1` … `h6` for borrowing heading styles without changing the tag.

Treat the *shape* of the convention (single-purpose `text-{property}-{value}` families) as reliable
and any **individual family name** as unconfirmed. Check the census before scoring on one.

✅ **`text-size-regular`** (not `base`, not `body`) appears in both sources and is a genuine
tell. This is the one typography corroborator safe to score on.

### ⚠️ Colour tokens are named literally, and the docs call that a hard violation

| Docs say | Site does |
|---|---|
| Naming a semantic token after its colour is a **HARD violation** ("breaks theming"). Classes are `text-color-primary` / `-secondary` / `-alternate`, bound to semantic variables. | ✅ *Verified: the registered styles are exactly `text-color-black`, `text-color-grey`, `text-color-white`, plus `background-color-black/white/grey` — with **hardcoded literal values, not variables**.* |

**The official Finsweet starter breaks Finsweet's own hard rule.**

🚫 Match on the **prefix family** `text-color-*` / `background-color-*` and accept any value segment,
including literal colour words. A detector requiring `primary`/`secondary`/`alternate` rejects the
reference implementation. **Never raise "colour-named token" as a violation on a real site**: the
canonical artifact does it. (Also listed in [../conventions.md](../conventions.md) §1 as one of three
things that must not count toward a "mess" verdict.)

### Visibility

`hide` · `hide-tablet` · `hide-mobile-landscape` · `hide-mobile-portrait`. **There is no `show-*`
class anywhere.** The docs' v1→v2 note ("Removed `show-` utility classes") is borne out.

`max-width-full-tablet` / `-mobile-landscape` / `-mobile-portrait` exist as breakpoint-named release
classes; the site supplies the mechanism the docs omit: **empty base, exactly one breakpoint
override each**.

### Breakpoints and units

- Webflow-native breakpoints, styled per class, **no prefix syntax in class names**.
- Authoring is **desktop-down only**: overrides appear only at `medium` / `small` / `tiny`.
- **rem throughout** for size, 16px browser-inherited root. `em` used only for line-height.

### 🚫 Variables prove nothing in either direction

The docs refuse to ship size variables: *"there is no breakpoint feature on the variables panel."*
The artifacts contradict that **in both directions at once**:

| Artifact | Variables |
|---|---|
| **2023 starter** (the original read) | **ONE collection containing ZERO variables.** Every value hardcoded: `padding-global` 2.5rem, `container-large` 80rem |
| **Sibling "Client First + Variables"** | ~100 variables, **overwhelmingly SIZE tokens** (`--container--large`, `--padding-section--medium`, `--max-width--xxlarge`, `--text-size--tiny`, `--headings--h1_font-size`), precisely what the docs said would not be released |
| ⭐ **Current `client-first-cloneable.webflow.io`** ✅ *published CSS, 2026-08-05* | **~30 COLOUR tokens in a two-tier reference graph.** Sizes stay hardcoded |

### ⭐ The current cloneable's token architecture (verified 2026-08-05)

```
--base-color-brand--blue              ← primitive tier, literals
--base-color-neutral--black | --white | --neutral-darker | --neutral-lightest
--base-color-system--success-green | --error-red | --warning-yellow  (+ -dark variants)

--text-color--text-primary:            var(--base-color-neutral--black)      ← semantic tier
--text-color--text-alternate:          var(--base-color-neutral--white)
--background-color--background-secondary: var(--base-color-brand--blue)
--border-color--border-alternate:      var(--base-color-neutral--neutral-darker)
--link-color--link-primary:            var(--base-color-brand--blue)
```

Two tiers, semantic-references-primitive: **the architecture this file elsewhere attributes to
Lumos.** cssName shape is `--group--name`, **identical to Lumos's** ([../conventions.md](../conventions.md)
§2 step 5).

**Tokens are load-bearing, not decorative:** `is-brand` resolves to
`var(--background-color--background-secondary)`, and `is-secondary` to
`var(--border-color--border-alternate)`. A build that hardcodes those colours is not conforming.

**Sizes remain hardcoded even here**: `padding-global` is still a literal 2.5rem, containers still
literal rem. So the docs' *"no breakpoint feature on the variables panel"* still governs the size
tier. **Colour is tokenised; space and type are not.** That split is itself the current CF signature.

Tokenisation is incomplete even there: `padding-global`'s `small` override stays a hardcoded 1.25rem.

> **A conforming Client-First site may have zero variables or a hundred, with identical class names
> and identical structure.** Never gate detection on tokens. Never treat a fully hardcoded stylesheet
> as evidence against CF.

If variables *do* exist, the emission pattern `--group--name_modifier` with groups mirroring the class
families one-to-one (`container/`, `padding-section/`, `max-width/`, `text-size/`) is a strong
**additive confirmation only**. Do not expect breakpoint values to be tokenised even then.

### Where project CSS lives

`global-styles` is a registered class **and** a real Webflow Component named **"Global Styles"**
(the only registered Component in the entire file), instanced as the first child of `.page-wrapper`
on both pages. The class itself is a parked holder: `position: fixed`, `top`/`left` 0.

Site head and footer freeform code are **both empty strings**, and the starter ships **no custom CSS
at all**.

🚫 **Detect the class NAME and its position, not its contents.** Do not require an Embed with CSS in
it. **Empty Site Settings custom code is not evidence against Client-First: CF
actively predicts it, so emptiness there is mildly *confirming*.**

---

## 5 — Component practice

### ⚠️ `{namespace}_component` is a NAMING convention, not a Webflow Component

This is the single most misread thing in the system.

`home-message_component`, `utility-page_component`, `form_component`, `fs-styleguide_component` are
**class names on ordinary divs**, exactly as the Folders strategy describes. ✅ *Confirmed in the
shipped markup.*

**The only registered Webflow Component in the starter is "Global Styles."**

🚫 A detector that looks for registered Components, props or variants finds essentially nothing and
will report zero conformance on a perfectly conformant project. Componentisation in Client-First is
**a folder discipline in the Style panel**, not a Webflow feature.

### Variants ride on combo classes

Configuration is carried by `is-*` combo classes, not by component variants:

- 15 registered combos, **all at depth 2** (`.button.is-large`), every one bound to a specific parent.
- None is registered as a base style.
- No three-part combo chain is registered anywhere.

### 🚫 The deep-stacking ceiling is unfalsifiable — do not detect on it

The docs publish hard counts: 1–2 classes common, 3 questionable, **4 the absolute maximum**, 5+ a
violation requiring a custom class.

**Nothing on the starter exercises the limit**: 15 combos out of ~215 styles, every one exactly two
parts.

Registered **combo depth** (max 2 in practice) is observable and usable as a weak corroborator.
**Element-level class counts should not be scored at all**: the rule would only ever produce noise.

### Style-guide scaffolding

The `fs-styleguide_*` family (40+ classes, `_component`, `_section`, `_header`, `_heading-tags`,
`_1-col` … `_4-col`) lives on a `draft: true` page built to be deleted before launch. See §1:
**lineage bucket, weighted separately, absence means nothing.**

---

## 6 — Violations

**There is no enforcement mechanism.** The docs publish no linter or compliance checker; the site
carries no Attributes script, and both head and footer freeform code blocks are empty strings. Both
sources independently conclude the same thing:

> **Flag, never auto-fix.** Every rule below is caught by human or agent review, and nothing shipping
> with the convention enforces any of it.

### Genuinely flaggable

- **Padding on `container-*`.** The trio must carry `width:100%`, `max-width` and `margin-inline` auto
  and nothing else. Coupling padding to max-width is the one hard rule the shipped starter honours
  verbatim.
- **A max-width, or vertical padding, on `padding-global`.** It owns horizontal gutters only.
- **Horizontal padding on `padding-section-*`.** It owns vertical rhythm only.
- **Page-edge gutters set anywhere other than `padding-global`.** Nothing else on the site sets them.
- **An `is-*` class registered or applied as a base style**, with no parent class beneath it.
- **An underscore in a utility class**, or a component-scoped class with none: the tier grammar
  depends on it.
- **`__`, `--`, camelCase, PascalCase or uppercase in a class name.** Absent from both sources
  entirely.
- **Flex / grid / gap / column utilities introduced into the utility layer.** The negative fingerprint
  is deliberate; layout belongs on custom classes.

### 🚫 Must NEVER be flagged — each of these would misclassify a genuine Client-First site

| Not a violation | Why |
|---|---|
| `padding-section-*` **and** `padding-global` on separate divs | The shipped starter's own form, on all 16 instances |
| Both padding classes stacked on **one** div | The docs' form. Accept both orderings |
| **No** `padding-section-*` layer at all | Home omits it entirely; the component class owns its vertical rhythm |
| A `<div>` or `<header>` where a `<section>` was expected | All three tags occupy the identical structural slot on one page |
| **No** `section_*` classes | The reference starter has zero |
| Colour-literal token names — `text-color-black` | The official Finsweet starter ships exactly these |
| **Zero variables**, or ~100 | Both ship as official CF artifacts with identical classes and structure |
| `inherit-color` missing | Documented, but **does not exist** on the starter |
| More than 4 stacked classes on an element | The ceiling is unobservable against the reference artifact; noise only |
| `page-wrapper` / `main-wrapper` carrying no CSS | Both are genuinely empty by design |
| A **second** underscore in a class name | Multi-level namespaces are documented and legal |
| **Empty** Site Settings custom code | CF predicts it; treat as mildly *confirming* |

---

## 7 — Building in Client-First

**Client-First is the only one of the three that MCP can build end to end**: every structural value
is a static rem, with no `clamp()` or `min()` anywhere ([../conventions.md](../conventions.md) §6).
That makes it the right convention to build first when validating a pipeline.

### Verified values — build against these, not against the docs

```
.padding-global          padding-left/right: 2.5rem
.container-small         max-width: 48rem      .container-medium  64rem     .container-large  80rem
.padding-section-small   3rem   -medium  5rem   -large  8rem      (padding-top AND -bottom)

.heading-style-h1…h6     4 · 3 · 2 · 1.5 · 1.25 · 1 rem      font-weight 700
   @max-991              2.5 · 2 · 1.5 · 1 · .875 · .75 rem
   line-height           h1 1.1 · h2–h3 1.2 · h4 1.4 · h5–h6 1.5

spacing ladder (both .spacer-* as padding-top, and .padding-* as all-round):
   tiny .125 · xxsmall .25 · xsmall .5 · small 1 · medium 2 · large 3
   xlarge 4 · xxlarge 5 · huge 6 · xhuge 8 · xxhuge 12      (rem, desktop)
   ⚠️ every step has its own value at 991 / 767 / 479 — the ladder compresses, it does not scale
```

### Build order

1. **Shell.** `.page-wrapper` as body's only child › `.main-wrapper` on `<main>`. **Both carry zero
   CSS**: create them as named, applied, empty classes. A build that skips them because they style
   nothing is missing two of the six core-structure classes.
2. **Global Styles component** first child of `.page-wrapper`, holding the CSS embed. Site Settings
   custom code stays **empty**; that is CF-correct, not an omission.
3. **Colour tokens** in two tiers: `--base-color-{brand|neutral|system}--{name}` primitives, then
   `--{role}-color--{role}-{variant}` semantic references onto them. **Leave sizes hardcoded.**
4. **The section chain, three divs:**
   ```
   section.section_{name}
     └ div.padding-global.padding-section-{size}      ← BOTH classes, same element
         └ div.container-{small|medium|large}
             └ div.{namespace}_{element}
   ```
   `padding-section-*` is a **combo on the gutter div**, not its own level. The docs' two-div chain
   is wrong; the starter ships three.
5. **Nav** per §2: `nav_fixed › nav_component › padding-global › nav_container`.
6. **Footer**: no pattern exists. Derive from the grammar and label it derived.
7. **Utilities last.** `text-size-*`, `text-align-*`, `max-width-*`, `margin-*`/`padding-*` as masks,
   `is-*` for component variants.
8. **States: you must invent them.** See below.

### 🚫 Client-First defines no hover or focus states

**Verified 2026-08-05:** the compiled CSS contains exactly one state rule, `a:active,a:hover{outline:0}`,
which is Webflow's normalize, not Client-First. Every `.button`, `.button.is-secondary`,
`.text-style-link` ships **stateless**.

This is now *verified absent*, not unobserved. Consequences:

- **There is no CF state convention to inherit.** Invent one, and say so in the plan.
- **Do not read a stateless CF project as unfinished**: it matches the starter exactly.
- Compare with MAST, which ships `:focus-visible` + `outline-color` systematically. **If
  accessibility matters on a CF build, you are adding something the convention does not give you.**

---

## Still unverified

- ◐ **Global chrome half-modelled.** ~~The starter ships no navbar and no footer.~~ **Nav observed
  2026-08-05** (§2). **Footer still genuinely absent**: no `footer*` class exists in the compiled
  CSS, so the footer pattern remains derived, not doctrinal.
- **CMS is unmodelled.** The starter ships **no Collection List**, so the collection-wrapper pattern
  (a likely `blog_list` / `blog_item` shape) is **inferred from the naming grammar, not observed.**
  Do not assert it as a rule.
- ✅ ~~**Hover and focus conventions are unknown.**~~ **Closed 2026-08-05: verified ABSENT.** See §7.
- **Which findings were re-queried in this reconciliation pass, and which were not.** Re-verified
  directly against the shipped starter: the three-div chain order across all 16 instances · zero
  `section_` classes · the six section-level parent tags · Home's `padding-global` parented by
  `home-message_content` · `text-color-black/grey/white` · `inherit-color` absent · `spacing-clean`,
  `display-inlineflex`, `global-styles` present. **Carried over from the two source profiles without
  independent re-query:** the variables findings, the `fs-styleguide_` prefix, namespace depth, the
  direction-class mask signature, the stacking-ceiling observation, the `global-styles` component
  placement, and the emptiness of `page-wrapper` / `main-wrapper`. Treat the second group as
  site-observed but not re-confirmed on 2026-07-29.
- **No class dating.** MCP exposes no per-style timestamp, so "rule vs residue" here is proxied by
  which page uses a class.
