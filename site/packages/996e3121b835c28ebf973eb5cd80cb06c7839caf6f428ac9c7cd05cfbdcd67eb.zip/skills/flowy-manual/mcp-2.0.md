# Webflow MCP 2.0.1 — what changed

> Established 2026-07-25 by reading `webflow_guide_tool` (which reports **version 2.0.1**), enumerating
> every tool schema, and running behavioural probes against a scratch site. **Read this before trusting
> any row in [mcp-capabilities.md](mcp-capabilities.md)**: roughly half of that ledger predates 2.0.
>
> Probe site: `a dedicated empty probe site`, empty, never published.

## 0 — Every tool name changed

Designer-adjacent tools gained a `data_` prefix:

| Was (pre-2.0) | Now (2.0.1) |
|---|---|
| `element_tool` | `data_element_tool` |
| `style_tool` | `data_style_tool` |
| `element_builder` | `data_element_builder` |
| `whtml_builder` | `data_whtml_builder` |
| `component_builder` | `data_component_builder` |
| `de_page_tool` / `de_component_tool` | gone → `data_pages_tool` / `data_component_tool` |

*(If a future find-and-replace ever flattens this table into identical columns, the left column is the
pre-2.0 name and should not carry the `data_` prefix.)*

Unprefixed survivors: `asset_tool`, `designer_tool`, `element_snapshot_tool`, `webflow_guide_tool`,
`get_asset_preview`, `get_more_tools`.

⚠️ **The guide's own prose is inconsistent with its schemas.** It says `cms_tool`, `pages_tool`, and
`data_cms_tool > list_collections`; the real names are `data_cms_tool`, `data_pages_tool`, and
`get_collection_list`. Following the guide literally fails.

## 1 — FIXED: the `breakpoint_id:"main"` silent no-op

~~Passing `breakpoint_id:"main"` to `update_style` returns success, logs success in the Bridge, and
silently fails to commit. THE #1 "writes don't persist" trap.~~
**superseded 2026-07-25.**

Explicit `breakpoint_id:"main"` **now persists.** Verified 2/2 on fresh `query_styles` readbacks by
`style_id`; the second trial used `min-height:470px`, the exact property and value that no-op'd six
times on 2026-06-01.

The `update_style` **response also now reflects post-write state**, contradicting the old
"response always echoes PRE-write state" row. Still re-read anyway: a response is not verification.

## 2 — NEW: CMS and data bindings via MCP

~~CMS field bindings on non-DOM elements are not exposed; `add_or_update_attribute` has no binding
support; bindings require a manual Designer click.~~ **superseded 2026-07-25.**

`data_element_settings_tool` exposes `get_bindable_sources`, `get_settings`, `set_settings`,
`set_tag`, `set_visibility`, `set_dom_id`. Binding source types: **`prop`, `cms`, `page`, `locale`,
`localeItem`**.

Verified: `get_bindable_sources` on a heading inside a Collection List returned all 4 CMS fields with
`bindableTo` arrays, plus 7 `page` sources (`title`, `description`, `ogTitle`, `ogImage`…).
`set_settings` with `binding {source_type:"cms", collection_id, field_id}` on key `text` persisted, and
the canvas rendered the real item value.

⚠️ **`all_resolved_settings` returns `null` for a working CMS binding**: bindings cannot resolve at
design time. The raw view shows full metadata and the canvas renders correctly. **Verify bindings with
`all_raw_settings` only**; the resolved view makes a working bind look broken.

**Image binding verified 2026-07-25.** An `Image` element's setting keys are `domId`, **`assetId`**,
`altText`, `visibility`, `attributes`. Bind the CMS image field to **`assetId`**. Reads back as
`{sourceType:"cms", fieldName:"…", fieldType:"image"}`.

⚠️ **Key-name asymmetry:** `get_bindable_sources` reports `bindableTo: ["image"]` for an image field,
but the key you write is **`assetId`**. `bindableTo` names a value-type *category*, not the setting
key. Filter sources with `value_type: "cmsImage"` to find image fields.

**Setting keys by element type** (from `get_settings all_raw_settings`):

| Element | Bindable key | Also present |
|---|---|---|
| `Heading` / text | `text` (`{innerText}` when static) | `domId`, `tag`, `visibility`, `attributes` |
| `Image` | `assetId` | `altText` (defaults to `"inherit"`), `domId`, `visibility`, `attributes` |
| `HtmlEmbed` | `code` | `domId`, `visibility`, `attributes` |
| `DynamoWrapper` | `source`, `sort`, `filters`, … (13 keys) | see §3 |

**Writing a CMS Image field value** (`data_cms_tool > create_collection_items`): pass
`{"url": "https://…"}` in `fieldData`. Verified working. ⚠️ **Webflow re-ingests the file**: it
returns a new `fileId` and a fresh CDN URL rather than referencing the existing site asset, so the
CMS image is a separate copy. Passing an existing asset's hosted URL is fine, it just duplicates the
bytes.

## 3 — NEW: Collection Lists are fully configurable

~~Collection List source binding is unreachable; `data_element_builder` rejects `collection` as a setting
key.~~ **superseded 2026-07-25.**

A Collection List is a `DynamoWrapper`, structured `DynamoWrapper > DynamoList > DynamoItem` plus
`DynamoEmpty > Block > String`. Its query lives entirely in **element settings**, not `data_cms_tool`.

13 settable keys, verified by `get_settings all_raw_settings`:
`domId, tag, visibility, attributes, source, queryMode, filters, filterMatch, sort, limit, offset,
pagination, curatedItemIds`.

- `source` → `static_json`, value `"{\"collectionId\":\"…\"}"`. Verified persisted.
- `filters` → array of `{fieldSlug, operator, value?}`; `filterMatch` → `"all"` | `"any"`.
- Operators are **per field type**, not global; a wrong one errors with the valid list. plainText →
  `equals`/`doesNotEqual`; rich text → `contains`/`doesNotContain`/…; Switch → `isOn`/`isOff`;
  Image/Reference → `isSet`/`isNotSet`; Number/DateTime → comparisons.
- `pagination`: `null` = off, `{"itemsPerPage":N}` = on. `queryMode`: `"dynamic"` | `"curated"`.
- Numeric keys (`limit`, `offset`) use `static_number`. `static_json` rejects a bare `null`; use
  `clear: true` to reset, and **re-read, because `clear` does not always persist.**
- `sort` write verified 2026-07-25: `static_json` value
  `"[{\"fieldSlug\":\"order\",\"direction\":\"ascending\"}]"` persisted and the canvas rendered items
  in that order.

⚠️ **THE CANVAS LIES UNTIL YOU RELOAD.** After setting a Collection List `source` via MCP, the Designer
canvas keeps rendering the **`DynamoEmpty` "No items found." state** even though the source is
correctly set and readable via `get_settings`. **Reload the Designer tab** (`?app=<token>` to keep the
Bridge) and the items appear. Verified twice on 2026-07-25: once on a probe list, once on the real
titles list, where a post-reload canvas-DOM read returned all 5 CMS items in sort order.

**This is the single most misleading moment in a CMS conversion**: it looks exactly like a failed
binding. Verify with `get_settings all_raw_settings` (source present) before concluding anything, then
reload.

### Converting static repeats to a Collection List — verified sequence

End-to-end on 2026-07-25 (five static title divs → one native Collection List):

1. `data_element_builder type:"CMSCollection"` into the container → returns `DynamoWrapper`.
2. `set_settings` on the wrapper: `source` + `sort`. **Must be before step 5**: building into an
   unbound list errors with *"Connect this Collection List to a Collection before adding elements."*
3. `set_style` the wrapper with the original list class (optional but keeps layout faithful).
4. `query_elements` scoped to the wrapper → the `DynamoItem` id.
5. `set_style` the item with the original item class, then `set_attributes` for the script's hook.
   **Both coexist**: verified `styleNames:["…__text-item"]` + `attributes:{"data-…-title":""}`.
6. `data_element_builder` the child inside the item, with `set_style` for its class.
7. `set_settings` the child's bindable key → `{source_type:"cms", collection_id, field_id}`.
8. `remove_element` on the original static **list** wrapper; one call removes all N static items.
9. **Reload the canvas**, then verify.

Bindable keys by element: text/heading/link → **`text`**; image → **`assetId`**; link href → **`link`**.
A `Link` element carries `domId`, `link`, `text`, `visibility`, `attributes`.

## 4 — NEW: component internals are addressable

~~Element queries go blind inside component definitions; component-scope reads don't surface
bindings.~~ **superseded 2026-07-25** for the navigation problem.

`scope_component_id` is a documented parameter across element, builder, and settings actions and walks
the component's tree instead of the page's. Verified: a `query_elements` with `scope_component_id`
found the definition's Heading, a prop binding was written to it, and it read back component-scoped:
**no `open_component_view`, no canvas navigation.**

Also now exposed: `data_component_props_tool` (create/update/remove prop definitions; read and set
instance values; 10 creatable types) and `data_component_variants_tool` (variants plus per-variant
styles scoped by breakpoint and pseudo; base variant id is `'base'`).

**Not retested in 2.0.1:** CMS binding on an element *inside* a component definition
(previously "Element is not inside a CMS context"); `transform_element_to_component` where the subtree
*contains* a Collection List; `insert_component_instance` anchored on a component instance.

## 5 — NEW: one-call asset upload from a URL

~~Asset upload requires MD5 hashing plus a presigned S3 multipart POST with every `uploadDetails`
field mapped by hand.~~ **superseded 2026-07-25 for remote images.**

`asset_tool > upload_image_by_url {url, asset_name?, alt_text?}`: one call, returns id, name,
mimeType, hosted URL, altText. Verified. The manual S3 flow (`data_assets_tool > create_asset` + POST)
**is still required for local files.**

## 6 — NEW: embed code is writable via MCP

`data_element_settings_tool > set_settings` key **`code`** writes HtmlEmbed/CodeBlock content, verified
byte-exact by readback. This supersedes the CodeMirror procedure **for small or generated embeds**.
Large or externally-authored payloads still go via clipboard → CM6 to avoid hand-escaping.
Routing and both procedures: [flowy/embeds.md](../flowy/embeds.md).

## 7 — NEW: the Bridge App is mostly optional

The Bridge panel itself states: *"Webflow MCP 2.0 is live. Most design actions no longer require the
Bridge app."*

Confirmed operationally: with the Designer tab backgrounded, `designer_tool > select_element` timed
out while **every `data_*` REST call kept succeeding.** Data tools are REST; only `designer_tool`
needs a foregrounded tab with the Bridge connected.

`?app=<token>` launch links **are reusable within a session**; the same token reconnected the Bridge
on a second navigation. The token also survives Webflow's redirect to `?legacyEditorMigrated=true`,
so the one-navigation reconnect still works.

## 8 — STILL BROKEN: `data_whtml_builder` drops classes

Verified 2026-07-25: inserting `<div class="ghost-class">` with no `css` parameter silently dropped the
class: no style created, no error. `query_styles name_path:["ghost-class"]` → `matches: []`.

**The tell is an absent `styleNames` field** on the element. When a class *does* attach, both the
builder response and `query_elements` return `styleNames:["…"]` normally. Passing a `css` rule
alongside the html avoids the drop.

[flowy-verify](../flowy-verify/SKILL.md) Step 1 stays necessary. `data_whtml_builder` also caps at
**5 actions per call**.

## 9 — STILL BROKEN: `TextBlock` `set_text` at creation

Verified 2026-07-25: `data_element_builder` with `type:"TextBlock"` and `set_text` returned type
`Block`, and the inner String still held Webflow's default *"This is some text inside of a div
block."*; the passed value was ignored.

**Changed detail:** nesting is now `Block > String` (**one** wrapper), not the old
`Block > Block > String`. Fix unchanged: follow up with `set_text` on the inner String node's id.

By contrast `Heading` is created directly with no wrapper, and `set_heading_level` applies at creation.

## 10 — New surfaces with no manual entry yet

Present in 2.0.1, undocumented here, untested: **branches** (create / update / publish to staging /
merge with conflict resolution, async task polling; a real safe-workflow story), **forms and
submissions**, **custom fonts**, **sitemap indexing**, **localization**, **schema markup**, **asset
compression**, **analytics** (`data_analyze_tool`, entitlement-gated), and **freeform head/footer
custom code** (`set_site_freeform_code`; no registration step, unlike the 2,000-char registered
inline scripts).

Also new: `data_style_tool > rename_style` (class renaming, relevant to retrofitting a naming
framework onto an existing site) and `create_variable_mode` accepting a `breakpoint_id` to auto-apply
a variable mode per breakpoint.

## 11 — Site-hosted agent instructions

`data_agent_instructions_tool` stores rules and skills on the Webflow site at `rules/<name>.md`
and `<skill-name>/SKILL.md`, up to 256KB, with drafts and reference resolution. The guide instructs
agents to call `search_instructions` early in any workflow and to repeat discovery on site switch.

**Current decision: local files remain canonical.** Site-hosted instructions are read at intake but
not written. Revisit if collaborating on shared or client sites.

## 12 — Clipboard paste beats the API for third-party components

Not an MCP change, but the most important routing finding of the day. Verified on Osmo's Layered Image
Slider: `Copy to Webflow` + `cmd+v` (`ctrl+v` on Windows/Linux) delivered 24 style definitions with full properties, all 9
data-attribute hooks, and correct semantic tags with **nothing dropped**, while
`data_whtml_builder` dropped a class in the same session. Full procedure:
[flowy/two-hands.md](../flowy/two-hands.md).

## 13 — Component-library build, verified 2026-07-31

> Probe: building 8 components (button, navbar, hero, marquee, feature grid, testimonial, FAQ,
> footer) from scratch on `The client library` (`<site_id>`), a blank site.
> Every row below was hit and re-read in that session.

### 13.1 — 🚫 `data-w-id` is NOT queryable in the Designer

`query_elements {element_filter:{attribute_name:"data-w-id"}}` returned **0 matches** on a page
(the source template / Home One) whose **Interactions panel showed two live page triggers**: a page-load
`Landing Hero Slider` and a mouse-move `Page Card Mouse Move`, on `Classic Interactions`.

`data-w-id` is stamped at **publish/export**, not stored as a Designer attribute. **A zero result is
not evidence of "no interactions" — it is evidence of nothing.** The Interactions panel, read through
the browser hand, is the only authority. Recorded in the iteration log.

### 13.2 — Two classes on one element require the combo to exist FIRST

`set_style {style_names:["rt-button-font","rt-button-label"]}` → `One or more styles not found`,
even though both global styles existed and `query_styles` returned both. `data_element_builder`
did the same silently (absent `styleNames`).

**Fix:** create the combo explicitly, then apply:
`create_style {name:"rt-button-label", parent_style_names:["rt-button-font"]}` → returns
`isComboClass:true`, selector `.rt-button-font.rt-button-label`. The two-name `set_style` then works.
A single class per element never hits this.

### 13.3 — `set_text` targets the String child, not the Block

A Text Block is `Block` + a `String` child. `set_text` on the Block → `This element doesn't support
text`. **On the `String` child it succeeds.** The builder's `set_text` on a child schema also
silently no-ops and leaves Webflow's placeholder copy.

The Block itself exposes a **bindable `text` key** (`valueType:"textContent"`, `canBind:true`), so
for prop-driven text, bind `text` on the Block and ignore the String entirely.

### 13.4 — 🚫 `ComponentSlot` cannot be created on a page

`data_element_builder {type:"ComponentSlot"}` at page level →
`Slot elements can only be inserted within a Component`.

**Order is forced:** build the tree → `transform_element_to_component` → *then* add the slot inside
the definition with `scope_component_id`. Returns `type:"Slot"`. Slot props are derived, not created.

### 13.5 — 🚫 `ComponentInstance` does not support `set_visibility`

`Element does not support setVisibility`. **Wrap the instance in a `DivBlock`** and bind visibility to
the wrapper. `move_element` also refuses an instance as anchor, so remove and re-insert the
instance inside the new wrapper rather than moving it.

### 13.6 — 🚫 CSS custom properties are rejected

`set_variant_styles {property_name:"--rt-nav-bg"}` → `Invalid style property --rt-nav-bg`.
Same for `update_style`. **A variant cannot be themed via one custom property**: override each real
class instead (`rt-navbar`, `rt-navbar-brand`, `rt-navbar-link`, `rt-navbar-bar`).

Consequence for embed CSS: never let embed selectors out-specify the classes a variant overrides.
Keep embeds to compound/descendant states (`.is-open .child`) and leave plain colour on the classes.

### 13.7 — 🚫 Attribute value-binding is rejected at runtime

`set_settings {key:"attributes", attributes:[{name_static, value_binding:{source_type:"prop",…}}]}`
→ `attributes[0] ("data-rt-speed"): value must be a string or a binding`, with a `number` prop
**and** with a `string` prop. The schema documents `value_binding`; the API refuses it.

**Therefore a prop cannot reach a data attribute.** Any embed knob you wanted to expose as a prop must
instead be a variant overriding a real CSS property (e.g. `animation-duration` for marquee speed,
`animation-direction` for reverse). Both verified working.

### 13.8 — Definition element ids are predictable: sequential hex, depth-first

After `transform_element_to_component`, every descendant id is the **component id incremented by 1 in
hex**, in depth-first order (root = component id itself, String nodes included).

Predicted and confirmed **4/4** across components of 15, 24, 47 and 46 elements. Saves a full-tree
read per component. Still cheap to validate with one filtered `query_elements` (e.g. `type:"HtmlEmbed"`)
before writing a large batch.

### 13.9 — `visibility` binds through `set_settings`, and batches

`set_settings {key:"visibility", binding:{source_type:"prop",…}}` works and can sit in the **same
operation** as a `text` bind. One `set_settings` action took **18 operations** covering 30 bindings.
Prefer it over the single-element `set_visibility` action.

### 13.10 — Tag styles do not exist on a blank site

`update_style {style_name:"h1"}` → `Style "h1" not found` on a site with no heading elements. Only
`default-body` pre-exists. Tag styles materialise once an element of that tag is on a page, so on a
new build, style the classes and set tag styles at the end (or skip them).

Also: `-webkit-font-smoothing` on `update_style` → `An internal error occurred`. Vendor-prefixed
properties are not accepted; the same call succeeded once removed.

### 13.11 — A variant prop takes the variant **id** as a plain string

Setting a nested instance's variant:
`set_component_instance_prop_values {prop_id:<the auto-created "Variant" prop>, type:"string",
string_value:"<variant_id>"}`. Verified switching a nested button to its `Secondary` variant.
Every component with variants auto-gains a `Variant` prop; it appears in `instanceDetails.props`.

### 13.12 — Slots DO surface on page-level instances

`get_all_elements` on the page returned, per instance, a `slots[]` array with
`{component, element, slot}` ids and `children: []`. So slots are **addressable** from the page,
which narrowed the slot-filling case to whether `insert_component_instance` accepts that
composite id as `parent_element_id`. Still 🔍 untested.

## 14 — Cross-site paste: what survives, what dies (verified 2026-07-31)

> Probe: `rt-landing-hero` (source template / `a scratch site`) → `The client library`, Designer to
> Designer, both in the same account and browser session.

### 14.1 — Designer element copy does NOT use the OS clipboard

`pbpaste` after a successful in-Designer `cmd+c` returned **0 chars**: the copy *cleared* the OS
clipboard rather than filling it. The paste then worked anyway.

**`pbpaste` is not a valid probe for Designer→Designer copy.** It *is* valid for the `Copy to Webflow`
button on a resource site, which explicitly writes `{"type":"@webflow/XscpData"…}` JSON
([two-hands.md](../flowy/two-hands.md)). Two different mechanisms; do not conflate them.

### 14.2 — copy (`cmd+c` / `ctrl+c`) needs CANVAS focus, not Navigator focus

Selecting the element by clicking its Navigator row and pressing `cmd+c` silently did nothing.
Clicking the same element on the canvas and pressing `cmd+c` worked.

Navigator selection drives the panels but does not give the canvas the keyboard focus the copy
handler needs. **Select on canvas before any keyboard command.**

### 14.3 — Webflow states the losses itself, in a toast

Verbatim, on paste:

> **Paste** — For pasting cross-site we had to **unlink components, drop some links and custom
> fonts**. Renamed `"rt-button-v1"` and `"rt-button-font"` classes to `"rt-button-v1 2"` and
> `"rt-button-font 2"` in order to avoid conflicts.

**Read that toast.** It is the only place Webflow tells you what it destroyed, and it disappears.

| Survives | Dies |
|---|---|
| Element tree, nesting, tags | **Interactions** (see 14.4) |
| Classes and their properties | Component links — instances arrive **unlinked** |
| Text content | Some links |
| — | Custom fonts |
| — | Original class **names** where they collide (renamed ` 2`) |

### 14.4 — Interactions did NOT survive — but the cause is confounded

Before, on the source: `rt-landing-hero-slider` carried **Element trigger → Scroll into view →
`Slide in from Bottom`**, plus page triggers `Landing Hero Slider` (page load) and
`Page Card Mouse Move` (mouse move).

After, on the target: the same element's Interactions panel is **empty**. Structure identical
(`rt-landing-hero > rt-landing-hero-main > rt-landing-hero-slider`), Navigator interaction marker
absent.

⚠️ **Do not over-read this.** The two sites run **different interaction engines**:

| Site | Version selector |
|---|---|
| Source template | `Classic Interactions` |
| The client library (target) | `Interactions with GSAP (new)` |

So the loss is explained by *either* cross-site paste *or* the engine mismatch; **this test cannot
separate them.** The toast notably did **not** mention interactions among what it dropped, which
leaves the engine mismatch as the more likely culprit.

**The test that closes it:** set a scratch site to `Classic Interactions`, paste the same hero, read
the panel. Until then, treat "IX survives cross-site paste" as 🔍 unknown, not as false.

### 14.5 — The interaction engine is a per-site, switchable setting

Bottom of the Interactions panel → **Version** dropdown, two options:
`Interactions with GSAP (new)` · `Classic Interactions`.

**This is a strategic lever and a gate.** Before planning to reuse any template's motion, check
both sites' Version. A Classic-era template's IX has no meaning in a GSAP-engine site. Switching
is site-wide; never flip it unprompted.

### 14.6 — The ` 2` class suffix is a paste artifact, and it is a fingerprint

The rename rule (`X` → `X 2` on collision) explains the `rt-text-style-h5 2`, `rt-counter-text 2`,
`rt-button-v1 2` classes already catalogued on the source template: **that template was itself assembled by
cross-site pasting.** A cluster of ` 2` classes in an unfamiliar project is evidence of paste-assembly,
not sloppiness; useful when deriving a project's conventions ([flowy/conventions.md](../flowy/conventions.md)).

### 14.7 — Cross-site paste FLATTENS variable bindings to literals

Verified 2026-07-31 by diffing the collided pair on `The client library`:

| Property | Original `rt-button-v1` | Pasted `rt-button-v1 2` |
|---|---|---|
| `border-*-color` | `{id: variable-…Black}` | `"white"` (literal) |
| `color` | `{id: variable-…White}` | absent |
| `font-size` on `rt-button-font` | `{id: variable-…Button}` | `"16px"` (literal) |

The source site bound these to its own variables; the paste resolved and inlined them. **Pasted
sections are disconnected from the target's token system**: they render correctly on arrival and
then ignore every future token change.

Consequence: a paste can never be "adopted as-is" into a tokenised project. Rebinding is mandatory.
Procedure: [flowy/two-hands.md](../flowy/two-hands.md) → *After the paste — reconcile*.

### 14.8 — The paste brings unreviewed patterns, not just unreviewed classes

The same paste introduced `rt-button-bg` (`position:absolute; right:101%; width:102%`), a second
element that slides across to fake a button hover fill. That is the duplicate-and-crossfade approach
The standing animation rule forbids; the equivalent single-element technique is an animated
`background-position` on the button itself.

**Audit non-colliding incoming classes too.** Collisions get flagged by Webflow; *new* classes arrive
silently and carry the other designer's decisions straight into your system.

### 14.9 — The native-CSS capability boundary (settles a recurring argument)

Verified 2026-07-31 on `The client library`. Both halves matter; stating either alone is wrong.

**Native — no embed needed.** `update_style {pseudo:"hover"}` stored a real pseudo-state on the class:
`.rt-features-card` → `pseudos.hover` carrying `transform: translate3d(0,-4px,0)` and four
**token-bound** border colours. Same confirmed on `rt-button-v1`, `rt-navbar-link`, `rt-footer-link`,
`rt-footer-social`, and on component variants via `set_variant_styles {pseudo:"hover"}`. These
appear in the Designer's **States** dropdown. Element states (`hover`, `focus`, `focus-visible`,
`active`, `visited`, `placeholder`) and structural pseudos (`first-child`, `last-child`,
`nth-child(odd|even)`) are all natively settable.

**Embed-only.** Everything where the selector is not simply *this element in a state*:

| | Why |
|---|---|
| `.a:hover .b` (descendant), `~` / `+` (sibling, "group hover") | Webflow has **no descendant selectors** |
| `::before` / `::after` | Not exposed |
| `@keyframes` | Not exposed (`animation-*` *properties* are settable once keyframes exist in an embed) |
| CSS custom properties `--x` | Verified rejected: `Invalid style property --rt-nav-bg` (§13.6) |
| Compound state `.is-open .child` | Descendant again; this is why class-toggle JS always ships with a `<style>` |
| `@media (prefers-reduced-motion)`, `@supports`, `:has()` | Not exposed |
| `clamp()`/`min()`/`max()`, `dvh`/`dvw` | Designer-only, rejected via MCP |

**The operative rule:** *does the effect stay on the element being interacted with?* Yes → native
state. No → `<style>` embed. Most real template hover motion is "no", which is why the embed is the
everyday tool. But the native case is real, free, canvas-previewable and stays token-bound, so do not
write an embed for a self-hover.

⚠️ **Do not set the same property in both places.** Embed CSS loads after Webflow's stylesheet and
usually out-specifies it on the published page while invisible on the canvas; the failure
mode is a **variant override that silently stops working**. One property, one home.

---

## 15 — Prompt-first portfolio build, verified 2026-08-02

Site: `a portfolio build`, built from empty to 11 pages + 4 CMS
collections in one session. Every row below is a readback, not a write response.

### 15.1 — ⭐ `var(--token)` in `data_whtml_builder` css becomes a REAL variable binding

The highest-leverage finding of the session. Passing `color:var(--ink)` inside the `css` string does
**not** store a literal or a raw expression: the parser resolves it to a genuine Webflow variable
binding.

```
css: ".brand-mark{font-family:var(--font-display);color:var(--ink)}"
→ query_styles include_properties:true
  "color":       {"id":"variable-cb1ad239-…"}
  "font-family": {"id":"variable-d929a3f6-…"}
```

**Why it matters:** binding 30+ classes to tokens via `update_style {variable_as_value}` is one call
per property. Writing the same thing as `var(--x)` in one whtml `css` block binds a whole component
in a single call. Variable `cssName` is what you reference (`--bg`, `--font-mono`), visible in the
`create_*_variable` response.

### 15.2 — `data_element_builder` rejects reserved attribute names

`set_attributes` with `name:"id"` → `"id" is a reserved attribute name`. Same for `type`.

- **id** → use the `domId` setting, not an attribute: `settings:[{key:"domId",static_text:{value:"ask"}}]`.
- **type** → not settable at all on a custom-tag `input`. Omit it; HTML defaults to `text`, and a
  `<button>` inside a form defaults to `submit`.

### 15.3 — 🚫 A `<form>` cannot be created as a plain form

Both routes produce Webflow's Form Block, never a bare `<form>`:

| Route | Result |
|---|---|
| `data_whtml_builder` with `<form class="field">` | `FormWrapper` › `FormForm` + `FormSuccessMessage` + `FormErrorMessage`; the class lands on the **wrapper**, the `id` on the inner `FormForm` |
| `data_element_builder` `BY_CUSTOM_TAG` `custom_tag:"form"` | Same: returned `type:"FormWrapper"`, auto-named "Email Form 2", pre-filled with Name/Email fields |

Webflow's form runtime then binds to it. **If you need a non-form field row** (a command bar, a
filter input), build a `DivBlock` and handle Enter in JS via `keydown`. A custom-tag `button`
also comes back as a `Link`, so wire it with a click handler, not a submit.

### 15.4 — ⚠️ Failed builder calls can still leave elements behind — with different ids

Two `data_element_builder` calls that **errored** on reserved attributes nonetheless created partial
Form Blocks on the page. Worse, `remove_element` using the id the *successful* call returned
(`076dd950…`) reported success while the actual orphan in the tree carried a different id
(`ace9655c…`).

**Rule:** after any failed or partially-failed build, `query_elements` the parent and delete by the
ids **currently in the tree**. Never assume an error meant nothing was written. The visible symptom
here was two duplicate `id="ask"` inputs, which silently breaks `getElementById`.

### 15.5 — `data_whtml_builder` input constraints

- **Single root required.** Two siblings → `Expected single root element but found 2 elements.`
- **No descendant selectors in `css`.** `.prose p {…}` →
  `Nested selectors are not allowed. Found: ".prose p". … StyleParser drops descendant selectors.`
  Single-class selectors only; give the child its own class.

### 15.6 — Existing classes attach by name with NO css, and do NOT duplicate

Refines §8. The drop rule is *class has no css **and** does not already exist*. Once a style exists
site-wide, later whtml calls that reference it by name attach it correctly with no `css` at all, and
produce **no ` 2` suffix**. Verified: `.answer`, `.a-h1`, `.lead`, `.follow`, `.cta` all attached on a
second page with no css passed; `query_styles name_path:["2"]` returned `matches: []`.

So the `promptbar` drop happened because that class was in the html but had no rule in `css` **and**
had never been created, not because css must always accompany html.

### 15.7 — `border-radius` shorthand does NOT clear existing corner longhands

`update_style {border-radius:"3px"}` on a class already holding `border-top-left-radius:12px` etc.
leaves **all four longhands in place** alongside the shorthand. Bit three classes in one session
(`.field`, `.fact`, `.pcard`).

**Fix:** always pair the change with
`remove_properties:["border-top-left-radius","border-top-right-radius","border-bottom-left-radius","border-bottom-right-radius"]`.

### 15.8 — `display:grid` inherits Webflow's default two-column template

Setting `display:grid` via `update_style` renders as a **2-column grid** on the canvas even though
`query_styles include_properties:true` shows **no** `grid-template-columns` stored. The stored style
is not the whole truth here; Webflow's own grid default fills the gap.

Symptom: an answer article laid its lead and its prose side by side. **Fix:** always pin
`grid-template-columns` explicitly when you set `display:grid`. Caught by looking at the canvas, not
by readback; the readback looked clean.

**It injects default ROWS too — verified 2026-08-02.** Trying to make a strip size itself to its item
count with `grid-auto-flow:column` + `grid-auto-columns:1fr` (and `grid-template-columns` removed)
produced a **two-row, two-column** layout for three items: Webflow's unstated `grid-template-rows:
auto auto` was still in force, so column flow filled row 1, row 2, then wrapped. Stored properties
showed neither a template nor the rows.

**Fix:** pin **both** axes. For a self-sizing single row:

```
grid-auto-flow: column
grid-auto-columns: 1fr
grid-template-rows: auto     ← without this the strip silently wraps
```

**The general rule:** on any Webflow grid, whichever of `grid-template-columns` / `grid-template-rows`
you do not set explicitly is not "unset": it is Webflow's `auto auto` default, and it is invisible in
`query_styles`. Set both, or look at the canvas.

### 15.9 — 🚫 Body elements do not accept classes

`set_style` on a page's Body → `This element doesn't support styles`. Confirms §13.10 from the other
direction: page-level ground (background, base type) cannot be set from this hand at all. Either use
the Designer for the Body tag style, or carry it on the outermost content wrapper, which keeps it
native and avoids putting a tag rule in embed CSS (see [flowy/css-ladder.md](../flowy/css-ladder.md)
native-first check).

### 15.10 — `create_style` fails wholesale on an unsupported property

`-webkit-font-smoothing:antialiased` → `Tool create_style failed: An internal error occurred`. No
indication of which property. Same all-or-nothing behaviour as `update_style` with `clamp()` (§5).
Drop the vendor property and retry.

### 15.11 — Colour variables reject `rgba()`; use 8-digit hex

`create_color_variable` with `custom_value:"rgba(18,18,18,.11)"` → internal error. The same colour as
`static_value:"#1212121C"` succeeds. Alpha hex conversion: `.11 → 1C`, `.20 → 33`, `.13 → 21`,
`.26 → 42`, `.10 → 1A`, `.12 → 1F`.

### 15.12 — Variable modes are the clean way to ship two themes

`create_variable_mode` + `update_color_variable {mode_id}` gives one variable two values. Readback
shows both: `"value":"#F4F3EF"` with `"modeValues":[{"modeId":"…","value":"#0C0C0D"}]`. Eleven colours
× two modes = a complete light/dark token set, natively, no embed.

### 15.13 — Collection List `source` takes `{ collectionId }`, as JSON

`static_text` with a bare id → `Invalid value for setting "source": expected { collectionId } or null.`
The error states the shape. Correct form:

```
{key:"source", static_json:{value:"{\"collectionId\":\"6a6f2027…\"}"}}
{key:"sort",   static_json:{value:"[{\"fieldSlug\":\"order\",\"direction\":\"ascending\"}]"}}
{key:"limit",  static_number:{value:24}}
```

All three applied in one `set_settings`, before adding any children, per
[flowy/static-to-cms.md](../flowy/static-to-cms.md).

### 15.14 — 🚫 Option fields cannot be sorted on

`sort` on an Option field → `Field 'category' (option) cannot be used for sorting.`

**Consequence for grouped lists:** you cannot sort by category. Either use one filtered Collection
List per category (filters *do* accept options), or, cheaper, carry a **global** `Order` number
across the whole collection so a single sorted list still emits the groups in sequence. Did the
latter for 22 tools across 5 categories; per-category numbering had to be renumbered 1–22.

### 15.15 — ⭐ CMS Image fields accept a URL and Webflow ingests the asset

Passing `image:{"url":"https://example.com/images/photo.avif"}` in `create_collection_items`
does not hotlink. Webflow **downloads the file into the site's asset library** and returns its own
record:

```
"image":{"fileId":"6a6f209e…","url":"https://cdn.prod.website-files.com/…_example.avif","alt":null}
```

Verified with 8 `.avif` files pulled from a live third-party site in a single call. This is the fast
path for content migration: no `asset_tool` upload step needed.

⚠️ The image field's own `alt` came back `null`. Per-item alt text needs its **own PlainText field**,
bound separately to the Image element's `altText` key. Verified rendering per row in the canvas DOM.

### 15.16 — Google fonts: a `missing_font` warning at write time is not a failure

After adding fonts in Site Settings → Fonts, `data_whtml_builder` returned
`{"code":"missing_font","message":"Font \"Instrument Serif\" could not be installed or is unavailable"}`
as a `partial_success`, yet `query_styles` showed `font-family` bound to the font variable, and
the canvas rendered the serif correctly after a Designer reload. The warning reflects a stale Designer
font list, not a dropped property. Re-read before reacting to it.

### 15.17 — Collection List item classes stack with Webflow's own

Canvas DOM after conversion: `class="row wf-grid w-dyn-item"` and `class="pcard w-dyn-item"`. Your
class, Webflow's grid helper where applicable, and the dyn class coexist; this matches §3's guidance that
the item ends up `your-class w-dyn-item`.

### 15.18 — ⚠️ A scroll-state machine that settles once will settle WRONG (verified live 2026-08-02)

First finding taken from a **published** page rather than the canvas, and it could not have been
caught any other way.

A fixed prompt bar chose between `is-hero` and `is-docked` by comparing a marker's
`getBoundingClientRect().top` to half the viewport; it ran `settle()` once at init and thereafter
only on `scroll` and `resize`. On the live page it sat **docked on a page whose own rule said hero**:

```
markerTop     525
innerHeight   900   → half 450     525 > 450 ⇒ hero
bar.className "promptbar is-docked"
```

**Cause:** `settle()` ran before the webfonts loaded. With fallback metrics the hero was shorter, the
marker sat above the midpoint, and *docked was the correct answer at that instant*. Instrument Serif
then loaded (`wf-instrumentserif-n4-active` on `<html>`), the hero grew ~150px, and nothing re-ran the
decision: no scroll, no resize. The state was not wrong, it was **stale**.

**Fix — observe layout, not just events:**

```js
if (window.ResizeObserver) {
  ro = new ResizeObserver(function () { if (settle) settle(); });
  ro.observe(doc.body);                       // fonts, images, CMS render, reveal
}
if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(function () { settle(); });
```

Disconnect `ro` wherever the listeners are torn down, or a soft navigation leaks observers.

**Generalise it:** on a Webflow site every one of these shifts layout *after* first paint: webfonts
(always, since Webflow loads them async and stamps `wf-*-active` late), CMS Collection Lists, bound
images, and the reveal animation itself. **Any measurement-based state machine needs a
ResizeObserver, not a load-time reading.** The same applies to scroll-triggered pinning, sticky
offsets, and anything comparing a rect to the viewport.

### 15.19 — ⭐ `rename_style` is global and non-destructive — re-grammar a whole site cheaply

`data_style_tool > rename_style` renames the style **everywhere it is applied**. Elements keep the
class; no element rewiring, no re-application, no ` 2` duplicate.

Verified 2026-08-02: **64 renames** across 11 pages and a component definition, moving an ad-hoc class
layer into Client-First `block_element` grammar. Post-audit `query_styles name_path:["2"]` returned
`matches: []`, and probes for the old bare generics (`.row`, `.field`) returned only the namespaced
replacements.

**This makes "adopt the convention later" genuinely cheap**: the expensive part is not the rename,
it is everything that *references* the names (§15.20).

### 15.20 — ⚠️ A class rename silently breaks third-party JS that keys on class names

Renaming `transition-main` → `main-wrapper` (Client-First) **breaks Swup's page transitions with no
error.** Swup's default `animationSelector` is `[class*="transition-"]`; with no match it measures a
zero-duration animation and the fade simply stops happening.

```js
swup = new Swup({ containers: ["#swup"], animationSelector: ".main-wrapper", … });
```

**Before renaming any class, grep every embed for the string.** The referencing surfaces are: embed
`<style>` selectors, embed JS `querySelector`/`classList` calls, library config (Swup
`animationSelector`/`linkSelector`, Finsweet `fs-*`), and IX2 targets. Renaming through MCP touches
none of them.

**Corollary:** prefer ids and `data-` attributes for JS hooks: `#promptbar`, `#swup`,
`[data-hero-end]` and `[data-ask]` all survived the 64-class rename untouched, while every
class-based selector had to be rewritten.

### 15.21 — ⚠️ An embed inside a top-of-body component runs BEFORE the page content

The single worst bug of the session, and it is structural rather than a Webflow quirk.

A behaviour script placed as the last child of a **Shell component** (sidebar + fixed bar, sitting
first in `<body>`) executes while `<body>` is still being parsed. Everything after it in the
document does not exist yet:

| Query at that moment | Returns |
|---|---|
| `getElementById("promptbar")` (inside the Shell, before the embed) | ✅ the element |
| `getElementById("swup")` (later in body) | ❌ `null` |
| `querySelector("[data-hero-end]")` (later in body) | ❌ `null` |

The failure was silent and looked like a logic bug: `initDock()` found no marker, took its
"not the home page" branch, docked the bar and **returned without attaching its scroll listener**, so
the bar was frozen and immune to scroll *and* resize. `reveal()` returned early for the same reason,
and only the 2.5s failsafe made content visible.

**Fix:** gate everything that touches page content on DOM ready.

```js
if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", boot, { once: true });
else boot();
```

**Better fix when components are on the table:** keep the early embed for CSS and the first-paint
contract only, and put behaviour in a second component placed **last** in the body. Early-body is the
right home for the style/arming embed and the wrong home for anything that queries the page.

**Diagnostic that identifies this instantly:** if a state machine ignores *both* `scroll` and
`resize`, its listeners were never attached; look at what its init queried, not at its logic.

---

## 16. CMS lists, bindings and verification — verified 2026-08-02

### 16.1 A nested Collection List takes `{collectionId}` and nothing else

`data_element_settings_tool > set_settings` key `source` on a `DynamoWrapper` **inside** a
`DynamoItem` stores only `{"collectionId": "..."}`. A `fieldId` / `referenceFieldId` / `sourceType`
in the payload is **silently dropped**: `applied_keys:["source"]` still reports success.

**And it does not matter.** The multi-reference link is implicit, because Webflow restricts the legal
nested sources to collections reachable by reference from the parent item. Verified inside a Projects
item: `Tags` accepted; `Projects` and `Notes` both rejected with

> `Collection 'X' is not a valid source for this Collection List. Use searchAvailableSources() to discover valid sources.`

Confirmation the scoping is real, not just accepted: `get_bindable_sources` on the nested `DynamoItem`
returns Tags fields only, and the canvas renders a different chip set per card (Tag-A · Tag-B ·
2000+ Pages vs Crypto · Web3 · Fintech).

⚠️ Untested: a collection with **two** multi-reference fields pointing at the same collection, where
`{collectionId}` would be ambiguous. Check the canvas if you hit that.

### 16.2 Collection List filters — shape, and option fields take the option **id**

```json
[{"fieldSlug":"category","operator":"equals","value":"617db9de2f6625ff08d112c38775e190"}]
```

- Option fields accept **only** `equals | doesNotEqual | isSet | isNotSet`. `eq` is rejected.
- The value must be the **option id** from `get_collection_details`, not the option name.
  `"Development & Build"` → `Filter value '...' is not a valid option for field 'category'.`
- `sort` is `[{"fieldSlug":"order","direction":"ascending"}]`.

**The error strings enumerate the valid operators: use them as the documentation.** Probing with a
deliberately wrong operator is the fastest way to learn a field type's filter surface.

Verified end to end: five lists, one per category, 3+5+5+4+5 = **22** rows on the canvas; every tool
appeared exactly once.

### 16.3 `data_element_builder` cannot bind to CMS at creation time

Passing `settings:[{key:"text", binding:{source_type:"cms", …}}]` in `element_schema` fails with

> `Element is not inside a CMS context`

— the binding is validated before the element joins the tree. **Create first, bind in a second
`set_settings` call.** 10/10 failed at creation, 10/10 succeeded on the follow-up call.

### 16.4 `BY_CUSTOM_TAG` is the reliable way to make inline elements

`{"type":"BY_CUSTOM_TAG","custom_tag":"span"}` returns `type:"DOM"` with `settings.tag:"span"`, and
`set_style` classes **attach reliably**, unlike `data_whtml_builder`, which drops classes when no
`css` is supplied (§ flowy-verify Step 1). Works for semantic tags too: `kbd` rendered as a real
`<kbd>`. The settable text key on these is **`text`** (`valueType: textContent`, `canBind: true`).

### 16.5 `CMSCollection` auto-creates three children

One builder call yields `DynamoWrapper > DynamoList > DynamoItem` plus a sibling `DynamoEmpty`
containing the literal string **"No items found."** Hide it (`set_visibility false`) or rewrite it;
otherwise it publishes as-is the moment a filter matches nothing.

### 16.6 Breakpoint ids ↔ the Designer's device toggles

| Toggle | `breakpoint_id` | Applies at |
|---|---|---|
| Desktop | `main` | base |
| Tablet | `medium` | ≤ 991px |
| Mobile landscape | `small` | ≤ 767px |
| Mobile portrait | `tiny` | ≤ 479px |

Styles written at `medium` **cascade down** to `small` and `tiny`, so a single `medium` write is
usually the whole phone fix. `update_style {breakpoint_id}` returns the full style with a
`breakpoints` block; that readback *is* the verification.

⚠️ **The Publish button sits immediately right of the device toggles.** A mis-aimed click opens the
publish destination panel. It does not publish (that needs "Publish to selected domains"), but
close it immediately and re-aim. Zoom the toolbar strip to get exact coordinates before clicking.

### 16.7 Read the Designer canvas directly — the strongest verification short of publishing

The canvas is a same-origin iframe. From the `claude-in-chrome` hand:

```js
const d = [...document.querySelectorAll('iframe')]
  .map(f => { try { return f.contentDocument } catch { return null } })
  .find(x => x && x.querySelector('.your-class'));
d.defaultView.getComputedStyle(el);          // real computed values
d.documentElement.scrollWidth - d.defaultView.innerWidth;   // real overflow
```

Combined with the device toggles this gives **measured** layout numbers at any breakpoint without a
publish: grid track lists, element widths, overflow, resolved font sizes. This is the answer to
"I couldn't verify it from here."

🚫 It does **not** run embed code. `<style>` and `<script>` in an `HtmlEmbed` never execute on canvas
(Webflow shows the "only displays in preview mode… or on the published/exported site" placeholder),
so dock state, JS-toggled classes and `:has()` rules in an embed are all invisible here. For those,
build a local fixture that mirrors the component's element order and drive it headlessly.

### 16.8 `getComputedStyle().top` on a fixed element never returns `auto`

It returns the **used** pixel value. Asserting `top === "auto"` produces a confident false failure.
Assert on the side you actually set (`bottom`), or on `getBoundingClientRect()`.

Cost: one "FAIL" in a 23-check harness that was entirely the test's fault. **When a
single check fails inside a passing suite, suspect the assertion before the build.**

---

## 17. Variables, modes, and building a theme switch — verified 2026-08-02

### 17.1 `get_variables` lies about modes unless you ask for them

```
get_variables {variable_collection_id}                      → modeValues: []   for every variable
get_variables {variable_collection_id, include_all_modes:true} → the real per-mode values
```

The first form returns an **empty** `modeValues` array even when a mode is fully populated. Taken at
face value it says "the Ink mode has no values," which is the opposite of the truth. **Always pass
`include_all_modes: true` before concluding anything about a mode.**

### 17.2 What Webflow actually publishes for variables

Verified by reading the published stylesheet:

- The **Base mode** is emitted once as `:root{--ink:#121212;--bg:#f4f3ef;…}` (23 declarations here).
- Rules reference them normally: `.prompt_component{left:var(--sidebar-w);padding-left:var(--pad-x)}`.
- **Non-base modes are emitted only where a mode-carrying class is actually applied.** With no
  element carrying the Ink mode, the published CSS contains the base values and nothing else.

**Therefore a runtime theme switch is just a higher-specificity override on `<html>`:**

```css
html.theme-ink{--bg:#0C0C0D;--ink:#EDECE8;…}   /* (0,1,1) beats :root (0,1,0) */
```

Set the class in the **first-paint script** (before `<body>`) from `localStorage`, falling back to
`prefers-color-scheme`, and there is no flash. Verified 15/15: switch, repaint of sidebar and main,
`color-scheme`, `aria-pressed`, persistence, survival across reload and across a Swup soft
navigation, and back again.

⚠️ Keep the mode in Variables as the design source and **mirror** its values into the embed with a
comment naming it. They can drift; re-read with `include_all_modes:true` when the palette changes.

### 17.3 Why the mode-carrying-class route does not work here

`set_style_variable_mode` itself works: it writes, and `get_style_variable_modes` reads it back.
The route dies on two other constraints:

- 🚫 **Body rejects styles.** `set_style` on the Body element → `This element doesn't support styles`.
  So there is no single ancestor of both the Shell and `#swup` that can carry a theme class.
- 🚫 **`set_style` cannot apply two independent global classes.**
  `style_names:["main-wrapper","u-theme-ink"]` fails with `One or more styles not found:
  main-wrapper, u-theme-ink`; **both** are reported missing even though `main-wrapper` plainly
  exists. The list is resolved as a *combo chain*, not as two classes. To add a second class you must
  first `create_style {name:"u-theme-ink", parent_style_names:["main-wrapper"]}`.

That leaves a per-base-class combo for every wrapper you want themed, each needing its own mode:
more moving parts than the `<html>` override, for the same result.

### 17.4 `BY_CUSTOM_TAG` does not give you every tag

`{"type":"BY_CUSTOM_TAG","custom_tag":"button"}` returns `type:"Link"`: a Webflow Link element,
which publishes as `<a>` with no `href`. It is **not** keyboard focusable and carries no button
semantics.

✅ Add `role="button"` and `tabindex="0"`, and handle `Enter` / `Space` in JS yourself.

(`span` and `kbd` come through as real `DOM` elements with the requested tag; see §16.4. The
mapping is tag-by-tag, so check the returned `type` rather than assuming.)

## §18 — 2026-08-17: slots, duplicate_component, and the trusted-input boundary (2.0.1, live site)

### 18.1 Slots are addressable but not fillable

`create_blank_component` + `data_element_builder type:"ComponentSlot"` builds a slot and derives the
prop. Inserting the host on a page returns `slots[]` on the instance with a composite
`{component, element, slot}` id — the addressing exists. Every fill route refuses:

| Route | Result |
|---|---|
| `insert_component_instance`, parent = the page instance | "Cannot insert relative to a component instance — the Designer rejects inserts that use a component instance as the anchor" |
| parent = the slot's element id at page scope | "Element ... not found" — the API accepts only `{component, element}`; the composite's `slot` key has nowhere to go |
| parent = the slot element inside the definition, with `scope_component_id` | "Failed to create component instance: Missing element" |

Slot filling is the Designer hand. See [flowy/slots.md](../flowy/slots.md).

### 18.2 `duplicate_component` strips IX2 triggers

Duplicated a template `Accordion | V2` whose root wrapper carries Mouse click (tap) →
Accordion - Open / Accordion - Close (Classic engine). The duplicate, read in the Interactions
panel on the same root element and its children: empty. Structure, styles and props carry;
triggers do not. Inheriting behaviour means instancing the original, not duplicating it.

### 18.3 Designer copy/paste needs trusted input; cross-site paste needs a clipboard grant

Synthetic `cmd+c`/`cmd+v` via the Chrome extension no-op silently — no error, no copy. The
component-canvas context menu carries no Copy item (Convert to / Open settings / class ops /
Add interaction trigger / Rename only). OS-level computer control grants browsers as read-only.
Each site's Designer is its own origin (`<shortname>.design.webflow.com`), so the first cross-site
paste on a site raises a browser clipboard permission prompt outside the page. Same-site copy never
touches the OS clipboard and is unaffected. Procedure and escalation rule:
[flowy/two-hands.md](../flowy/two-hands.md).

### 18.4 Bridge behaviour reconfirmed

`designer_tool` → error carrying the `?app=<token>` link → navigating the Designer tab to it
connects the Bridge (agent-drivable end to end). Backgrounding the Designer window kills
`designer_tool` while every `data_*` call keeps succeeding — same split as §'s earlier finding.
A safe component-canvas open without the double-click insert trap: Components panel → hover the
row → the edit (pencil) icon.
## 19 — CF 6 → Lumos V222 port (2026-08-23, MCP 2.0.1)

A full home-page port, ~90 writes across elements, styles, variables, CMS, assets and embeds.
Everything below was hit directly.

### 19.1 `update_style` takes `breakpoint_id` — and silently ignores anything else

The schema is `{style_name, breakpoint_id?, parent_style_names?, pseudo?, properties?,
remove_properties?}`. `breakpoint_id` enum: `main | large | xl | xxl | medium | small | tiny`
(medium ≤991, small ≤767, tiny ≤479).

The trap: passing `breakpoint: "tablet"` — a key that is not in the schema — is **not** rejected.
The call succeeds and the write lands on **base**. I did that to `services_list` and turned the
desktop grid from four columns to three with a success response. `additionalProperties:false`
elsewhere in this tool does not extend to the action bodies.

Read the echoed `properties` object: a correct breakpoint write comes back as
`{"base":{…},"breakpoints":{"medium":{…}}}`. If your write appears under `base`, the key was wrong.

### 19.2 `parent_style_names` styles a combo; the combo must already exist

`update_style {style_name:"is-service", parent_style_names:["hero_home_badge"], breakpoint_id:"small",
properties:[{display:none}]}` → `selector: ".hero_home_badge.is-service"`. Works.

But `data_element_tool > set_style` with **two independent global classes** still fails:
`set_style {style_names:["stats_value","u-text-style-h2"]}` → `"One or more styles not found:
stats_value, u-text-style-h2"`, even though both exist as globals. The pairing has to exist as a
combo first. Create it once by hand — select the element, Style selector → type the class →
the dropdown offers **New Combo Class → Create `<name>`**; pressing Enter attaches the *existing*
global (verified: the element then computed 58px/800/-0.03em from `u-text-style-h2` while keeping
its own colour). After that one Designer action, `set_style` with both names succeeds on every
sibling.

The new combo is created **empty** (`properties: {base:{}}`) — no injected defaults.

### 19.3 `data_whtml_builder` keeps only the first class of a multi-class attribute

Separate from the long-known drop-if-not-created behaviour. Given
`<div class="stats_value u-text-style-h2">` where **both** classes exist, the element came back
with `styleNames: ["stats_value"]`. Same for `<div class="u-text-style-h6 u-color-faded">` →
`["u-text-style-h6"]`. Webflow reads class 2+ as a combo, and the builder will not create one.
Use §19.2's route instead.

Also: **one root element per action.** Four sibling `<div>`s in one `html` string →
`"Expected single root element but found 4 elements. Wrap multiple elements in a container."`
Issue one action per root.

### 19.4 `property_value` accepts `calc()` with `var()` — the echo lies about it

`update_style {properties:[{property_name:"padding-top",
property_value:"calc(var(--nav--height-total) + 5rem)"}]}` returned
`{"padding-top":{"id":"variable-709f575d-…"}}` — which reads as "the calc was dropped, only the
variable survived". It was not dropped: the canvas computed `184px` at desktop
(`--nav--height-total` 104px + 80px) and `154.196px` at 667px (90.196 + 64). I removed a
compensating padding elsewhere on the strength of the echo and had to put it back.

`clamp()` is still rejected on **variable** writes (see §5) but `calc(var() + …)` on a **style
property** works. Verify in the canvas, never from the echo.

### 19.5 Element-tool action args: `id`, not `element_id`

`data_element_tool` action bodies take `id: {component, element}` plus `scope_component_id` **inside**
the action object. `element_id` is rejected as an unrecognized key. Same tool, different convention
from `data_element_settings_tool`, which does use `element_id`.

Two more from the same tool:
- `set_text` on a Block → `"This element doesn't support text"`. Target the **String child**.
  In a duplicated subtree the child id is the parent's id + 1 in hex (`…c06` → `…c07`), which is
  guessable when `get_all_elements` has already truncated at `hasMoreChildren`.
- `set_image_asset` takes `image_asset_id`, not `asset_id`.
- Omitting `scope_component_id` inside the action gives `"Element not found"`, which reads like a
  bad id.

### 19.6 `SliderSlide` cannot be created by any builder

`data_element_builder`'s type enum (full list in the validation error) has `Slider` but no
`SliderSlide`, `SliderMask`, `SliderArrow` or `SliderNav`. `data_whtml_builder` produces a plain
Block. Slides are a Designer-only action: right-click the slide in the Navigator → **Duplicate**
(⌘D), then ⌘D repeats on the newly selected copy. Two slides → six in four keystrokes. Content is
then fixable over MCP (`set_text` on the String child, `set_image_asset` on the Image).

Slider *behaviour* settings — Duration, Nav Spacing, Rounded, Number labels, Infinite, Autoplay —
are not in `get_settings`/`set_settings` either (`all_raw_settings` returns only domId, visibility,
attributes). Set them in the Designer Settings panel; **read them back from the rendered
`data-duration` / `data-nav-spacing` / `data-*` attributes** in the canvas iframe.

### 19.7 `designer_tool` argument shapes

- `select_element {id: {component, element}}` — and it only works when the element is on the
  current page **or inside the currently open component**. Otherwise: *"Cannot select an element
  that does not exist on the current page or within the current Component."*
- `open_component_view {component_instance_id: {component, element}}` — a **page-level instance**
  id, not a component id. Get it from the page tree (`get_all_elements` at page scope, the
  `ComponentInstance` node's own `id`).
- `switch_page {page_id}` first: after a Bridge reconnect the Designer lands on the site's default
  page, so a select against another page's element fails.
- `close_component_view: true` (a bare boolean, not an object).

### 19.8 `asset_tool > upload_image_by_url` deduplicates by content

Re-uploading seven CF 6 service icons returned seven **existing** asset ids and their *original*
filenames — no duplicates created. That makes it a cheap identity check: two differently-named
assets that dedupe to the same id are byte-identical. It resolved a false alarm here (assets named
`Quote icon experts.svg` and `Service 2.svg` are the same file, so the "wrong" service icons were
correct all along).

### 19.9 `data_style_tool > query_styles` ignores a bad query shape instead of erroring

`{queries:[{style_name:"brands_logo"}]}` returned a 50-row unfiltered dump with
`truncated: true`. The valid key is `name_path: ["<class>"]` (single segment = substring match on
the style's own name; multi-segment = a combo chain of that exact depth). A wrong key silently
becomes "match everything".

`get_settings` similarly requires `type: "all_raw_settings" | "all_resolved_settings" |
"query_settings"`; a `keys` array is rejected.

### 19.10 Text bindings on a Block do not appear in `all_raw_settings`

The Services Collection List's item title is CMS-bound and renders eight distinct names on canvas,
but `get_settings all_raw_settings` on that Block returns only `domId / tag / visibility /
attributes` — no binding metadata. The Link on the same item **does** report
`{"link":{"mode":"collectionPage"}}`, and the `DynamoWrapper` reports its full
`source / queryMode / filters / sort / limit`. So: a missing text-binding row is not evidence of a
missing binding. Confirm text bindings in the rendered canvas (distinct values across items), per
house rule #13.

### 19.11 Lumos v2.2 specifics worth knowing before porting into it

Full write-up now lives in [../flowy/conventions/lumos.md](../flowy/conventions/lumos.md) §8, which
moves most of the v2.2 generation from doc-only to verified. The one that cost a round trip:

- **Cap-height text trim is on by default** and closes every heading-to-body gap to exactly the
  margin you set. Ported Client-First spacing collided in five places. `.u-text-trim-off` is the
  per-element switch (`content: none`); it does **not** inherit, and Lumos's trim rule is
  `!important`, so a scoped override needs `!important`. Decide trim policy before porting any
  spacing value — [../flowy/from-template.md](../flowy/from-template.md) Gate 0b.


- **`text-wrap: balance` is on the heading tag styles**, so headings break differently from a
  fixed-breakpoint source even when font-size, weight, tracking, family and column width all match
  exactly. It is a framework default, not a defect — decide explicitly whether to keep it.
- **`nav_component` is `position: fixed` with zero height in flow.** `page_main` starts at y=0 and
  the first section renders under the nav. Lumos exposes `--nav--height-total`
  (`calc(var(--nav--height) + var(--nav--spacing-outer-vertical))`, ~104px desktop / ~90px mobile);
  the first section has to reserve it. A source using a spacer div (Client-First's
  `.nav_blank-space`) has that height baked into a sibling — port it as
  `padding-top: calc(var(--nav--height-total) + <source's own section padding>)`.
- The Accordion Item's Heading is a **prop on the slot child**, and slot children carry no
  addressable element id (the `slots[]` entry reports the component-definition id, identical for
  every instance). Three of four FAQ headings silently stayed `""` with `hasOverride: true`.
  Set them in the Designer: Navigator → expand the Accordion List → expand the slot row → select
  each item → Properties → Heading. There is no MCP route.
- Putting a `<style>` embed inside a **repeated** component definition ships one copy per instance.
  Scope it to the section and put a single embed in the section component instead.
