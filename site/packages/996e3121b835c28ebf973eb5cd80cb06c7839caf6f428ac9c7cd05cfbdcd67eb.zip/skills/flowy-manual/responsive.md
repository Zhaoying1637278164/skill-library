# flowy-manual — Responsive & breakpoints (how to see and edit mobile)

> Consolidated 2026-07-19. The rules below are general to all Webflow work — they apply on every
> project, not just the ones where they were first learned.

## 🚫 NEVER resize the browser window to test mobile/responsive (HARD STANDING RULE)

**Enforced by a PreToolUse hook** on `mcp__claude-in-chrome__resize_window` that ships with this
plugin (`hooks/scripts/no-window-resize-guard.py`): the call is denied outright and the denial
text names the alternatives, so the agent redirects instead of retrying. This is the single
most-repeated correction in flowy's history.

Two independent reasons, both directly observed:

1. **It does not work.** Resizing the tab leaves `window.innerWidth` at the desktop value, so the
   page never enters mobile mode and any measurement taken after it is a desktop measurement
   wearing a mobile label.
   - 2026-06-30: resized to 375/390 → `innerWidth` still **1787**.
   - 2026-07-19: resized to 390×844, tool returned "Successfully resized" → page still
     reported `innerWidth` **1907**, and `.menu-button` measured `width: 0` because it was still in
     its desktop (hidden) state.
2. **It shrinks the user's real browser window**, which is disruptive; if the tab holds the Webflow
   Designer, resizing **breaks the Designer**. This is a known Webflow behavior, not something to
   work around.

### What to do instead

| Surface | Method |
|---|---|
| **Webflow Designer** | The **device toggles in the top toolbar** (Desktop★ / Tablet / Mobile Landscape / Mobile Portrait). This is the ONLY sanctioned way to see mobile in the Designer. |
| **A live / published page** | Measure inside an **iframe** sized to the target width (below). The iframe genuinely fires the small-viewport media queries; the window resize does not. |
| **Never** | The OS window size. |

```js
// Verified 2026-07-19 on a client site — returned true mobile geometry at 390/640/768
async function measure(w){
  const f = document.createElement('iframe');
  f.style.cssText = `position:fixed;left:-9999px;top:0;width:${w}px;height:844px;border:0`;
  f.src = location.pathname;
  document.body.appendChild(f);
  await new Promise(r => f.onload = r);
  await new Promise(r => setTimeout(r, 900));   // let Webflow/IX2/Lenis settle
  const d = f.contentDocument, win = f.contentWindow;
  const out = { vw: win.innerWidth /* …read elements from d… */ };
  f.remove();
  return out;
}
```
Same-origin only (the page and the iframe must share an origin), which holds when probing a site
from one of its own pages. Cross-links [diagnostics.md](diagnostics.md).

## Which breakpoint to edit on — Desktop main (the ★ starred icon)

Device toolbar, left → right:
`[monitor 1920] [monitor 1440/1280] [★ laptop = DESKTOP MAIN] [tablet 991] [tablet-landscape 767] [phone 478] [⋯]`

- **Make style changes on Desktop main (★).** Base styles cascade to every breakpoint.
- The plain **monitor icons LEFT** of the star = larger screens → do **not** put primary design there;
  edits only affect wider screens.
- The **tablet / landscape / phone icons RIGHT** of the star = smaller screens → use **only** for
  responsive overrides, never for the primary design.
- Before ANY style edit, confirm the starred icon is the active/highlighted breakpoint. (Learned
  2026-05-29 after repeatedly mis-clicking device icons and accidentally editing Tablet/Mobile.
  The canvas px reading when Desktop main is active is machine-specific; identify it by the
  **star**, not by a px number.)

**Webflow's breakpoints are fixed**: you cannot invent your own. A design spec written for
arbitrary widths must be mapped onto Webflow's tiers:

| Webflow tier | `breakpoint_id` | Media query |
|---|---|---|
| 1920 | `xxl` | `min-width: 1920px` |
| 1440 | `xl` | `min-width: 1440px` |
| 1280 | `large` | `min-width: 1280px` |
| Desktop main ★ | `main` | base (no query) |
| Tablet | `medium` | `max-width: 991px` |
| Mobile Landscape | `small` | `max-width: 767px` |
| Mobile Portrait | `tiny` | `max-width: **479**px` |

So a spec saying "≤1024" lands on Webflow's **991**, and "≤480" lands on **479**. Say this out loud
when translating a client type scale rather than silently rounding.

**Mobile Portrait is 479, not 478** (corrected 2026-07-25). `designer_tool > get_all_breakpoints`
returned `maxWidth: 479` for `tiny`, and the MCP guide's `data_whtml_builder` section likewise
specifies `max-width: 479px`. Earlier entries in this manual said 478.

**Enumerate rather than assume:** `designer_tool > get_all_breakpoints` returns each breakpoint's
`id`, `name`, `minWidth`, `maxWidth`, and `isBase`, in cascade order. On a site with no larger tiers
configured it returned **only 4** — `main` (`isBase: true`), `medium`, `small`, `tiny` — even though
`update_style`'s enum accepts all seven. The enum is not the site's reality; ask the site.

> ✅ **The `breakpoint_id: "main"` silent no-op is FIXED in MCP 2.0.1.** Explicit `main` now persists
> (verified 2/2, 2026-07-25). Details and the superseded claim: [mcp-2.0.md](mcp-2.0.md) §1. Editing on
> Desktop main ★ is still the right habit for *cascade* reasons; that guidance is unchanged.

## Backgrounded tabs report a zero viewport

A backgrounded / sleeping browser tab reports `window.innerWidth === 0` and
`innerHeight === 0` to JavaScript, which **falsely fires small-viewport media queries**. Foreground
the tab before measuring anything. If a probe returns `{w:0,h:0}`, that is the tell: the numbers
are not real. See [mcp-capabilities.md](mcp-capabilities.md) and [diagnostics.md](diagnostics.md).

## ✅ CSS math functions ARE writable by the MCP (2.0.1)

~~`clamp()` / `min()` / `max()` — and `dvw` / `dvh` units — are **silently rejected** by
`update_style`. A fluid responsive scheme built on `clamp()` is not natively writable via MCP; author
it by hand in the Designer Style panel or in an embed. One rejected property silently voids the whole
call.~~ **superseded 2026-07-25.**

All of it now writes and persists. Verified by fresh `query_styles` readback on `style_id`:

| Written | Read back |
|---|---|
| `font-size: clamp(1rem, 2vw, 2rem)` | ✅ persisted verbatim |
| `height: 100dvh` | ✅ persisted verbatim |
| `max-width: min(90vw, 1200px)` | ✅ persisted verbatim |
| `letter-spacing: -0.02em` (sibling control) | ✅ persisted — **no whole-call voiding** |

**Consequence: a fluid responsive scheme is now natively MCP-writable.** Fluid type scales and
viewport-relative sizing no longer need hand-authoring in the Style panel or an embed escape hatch.
This meaningfully widens what MCP can do for responsive work; see [mcp-2.0.md](mcp-2.0.md).

**Still true and unchanged:** the Style panel *displays* `clamp()` / `calc()` size values as **"0 PX"**.
A "zero width/max-width" showing in the panel is usually a *healthy* clamp: check the computed style
or the API before "fixing" it, because clicking through such a field can **commit the 0** (observed
twice in one session, 2026-06-11).
