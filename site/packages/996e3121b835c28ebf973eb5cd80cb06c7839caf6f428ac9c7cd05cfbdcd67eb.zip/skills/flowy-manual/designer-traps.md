# flowy-manual — verified Webflow Designer behaviours

> Directly-observed Designer-side traps and their verified fixes. Schema/call behaviour lives in
> [mcp-2.0.md](mcp-2.0.md) (current) and [mcp-capabilities.md](mcp-capabilities.md) (historical);
> probes in [diagnostics.md](diagnostics.md); the post-write routine is
> [flowy-verify](../flowy-verify/SKILL.md). Standing rules are in
> [house-rules.md](../flowy/house-rules.md).
>
> **Each entry is dated and states how strongly it was verified.** Class names are written as generic
> placeholders (`.a`, `.parent__child`); the original observations came from client projects and those
> names carry no meaning here. Read for the *mechanism*, and check the precondition actually holds in
> the current project before treating an entry as a live risk.

## Classes silently dropped after a `data_whtml_builder` insert

**Observed 2026-05 (client site) and re-confirmed 2026-07-25 (MCP 2.0.1).** Markup inserted with
`class="…"` names that don't already exist as Designer styles: the classes vanish. No error, no style
created. In the 2026-05 case **11 of 16 classes** in one insert came back with `className === ""` on the
live page, while the other 5 attached, so it is not all-or-nothing and you cannot predict which.

**The tell:** an **absent** `styleNames` field on the element. When a class does attach, both the builder
response and `query_elements` return `styleNames: ["…"]` normally.

**Verified fix:** `data_style_tool > create_style {name, properties: []}` then
`data_element_tool > set_style {id, style_names: [name]}`. Passing a `css` rule alongside the html at
insert time also avoids the drop. [flowy-verify](../flowy-verify/SKILL.md) Step 1 automates the check.

## Webflow injects properties into auto-created styles that your CSS can't override

**Observed 2026-05, 2 distinct classes.** After a builder insert created styles automatically,
`query_styles` returned properties nobody asked for: `max-width`, `aspect-ratio`, a stray `position`,
`top`. One case: an injected `max-width: 1100px` + `aspect-ratio` capped an element that an embed rule
tried to make `inset: 0`, because the embed rule didn't mention those properties. Live computed width
read `1100px` in a `1430px` viewport.

**Verified fix:** `update_style {style_name, properties: […], remove_properties: ["max-width", "aspect-ratio"]}`.

**Not cleared under 2.0.1.** A 2026-07-25 probe on a plain `<div>` with a `color` rule saw **no**
injection, but the historical cases were on **Image** elements, which remain untested. Keep the audit
step.

## Embed `<style>` CSS renders in the canvas — per-embed, NOT universally

**Observed 2026-05-22 / 24 / 25.** A `<style>` inside an HtmlEmbed **does** render in the Designer canvas
and its rules do apply to canvas elements and survive a cold reload (Cmd+R). That's what makes the
`html.wf-design-mode` canvas-only technique deliverable via an ordinary body embed, with no Page
Settings head code.

**⚠️ But it is inconsistent between embeds on the same page.** With several sibling embeds in one
wrapper: a small one (~900 bytes) rendered and applied in the canvas; a large one (~6.6KB) did **not**.
Its rules were simply absent from the canvas cascade. Cause unconfirmed (size threshold? order? a
Webflow heuristic?). **Verify the specific embed with a canvas `getComputedStyle` probe before relying
on it.**

*(A 2026-05-22 probe suggesting embed CSS never reaches the canvas did NOT replicate and is
**superseded** — do not rely on it.)*

## ⚠️ Specificity trap: embed descendant selectors beat native classes on live, invisibly

**Observed 2026-05-25.** A pre-existing embed rule like `.parent__body h3 { … }` has specificity
`0,1,1` and beats a native Webflow class like `.parent__title` at `0,1,0`. Native flat classes cannot
out-specify it: no `!important`, no descendant authoring via `data_style_tool`.

And because that embed may not render in the canvas (above), **the conflict is invisible in the
Designer**: the canvas shows the native class winning, live shows the embed winning. One measured case
read `50px` in canvas and `17px` on live.

**When styling an element that also has an embed descendant rule, verify on the LIVE page, not the
canvas.** Fix: migrate the embed rule's properties into the native class and delete the embed rule, or
add a combo class to reach `0,2,0`.

> Related: cross-origin Webflow CDN `.webflow.css` `cssRules` throw on JS read, so specificity is
> unknowable from inside the canvas iframe. That is why `!important` is sometimes the only lever.

## Whitespace between sibling inline elements is stripped on insert

**Observed once, 2026-05.** Inserting a heading whose words were wrapped in sibling `<span>`s separated
by literal spaces rendered as `WordWordWord`: the inter-span whitespace was gone from the live DOM.

**Verified workaround:** put plain text in the element and split it into spans at runtime in JS,
inserting the separators yourself. Confirmed by contrast: JS-built spans in the same page did not
exhibit the problem.

## An inline `<script>` in a body embed runs BEFORE the rest of `<body>` is parsed

**Observed 2026-05.** An IIFE inside an HtmlEmbed near the top of `<body>` tried to touch an element in
the footer and threw `TypeError: Cannot set properties of null`. A later diagnostic confirmed the
element existed fine post-`DOMContentLoaded`, so it was strictly load order, not a missing element.

**Verified fix:** wrap in `document.addEventListener('DOMContentLoaded', () => { … })`. Error gone,
animation ran.

## `<img src="relative-path">` inserted via builder becomes `<imgraw>` and 404s

**Observed 2026-05.** Inserting `<img src="images/logo.svg" alt="…">` produced an element with
`tag: "imgraw"` and an auto-generated `inline-imgraw-…` class. The live page showed the alt text instead
of the image.

**Verified workaround:** insert the full inline `<svg>…</svg>` markup instead (created with `tag: "svg"`).
For raster images, upload as a Webflow asset first (`asset_tool > upload_image_by_url` is one call)
and set it via `set_image_asset` or bind `assetId`.

## `data_whtml_builder` parameter restrictions

From the tool schema:

- `html` must be a **single root element**
- `html` must **not** contain `<style>` tags — use the `css` parameter
- `css` must not contain `@keyframes`
- `css` must not contain custom `@media` queries, only Webflow's breakpoints
  (`max-width: 991px` / `767px` / `479px`)
- **maximum 5 actions per call**

## Preview ONE Collection List item on the canvas (canvas-only)

**Verified 2026-06-04.** In the canvas a Collection List renders every item stacked, because the JS
that shows one at a time never runs there. A "one card at a time" component is therefore impossible to
judge visually.

The repeating element is Webflow's **`.w-dyn-item`**, not your custom class; the custom class often
isn't on it. Chain is `.w-dyn-list › .w-dyn-items › .w-dyn-item`. Scope the rule to one section so other
lists are untouched:

```css
html.wf-design-mode .your-section .w-dyn-item:not(:nth-child(3)) { display: none !important; }
html.wf-design-mode .your-empty-state { display: none !important; }
```

**Verified:** visible items flipped 9 → 1 and back on removal; the single item rendered exactly as live.
The published `<html>` has no `wf-design-mode`, so it is inert once published.

**Delivery:** a small, dedicated HtmlEmbed; large embeds don't render in the canvas (above). Keep it
separate from any other canvas-only embed rather than appending to load-bearing CSS. Build it as a
committed embed and verify that, per [house-rules.md](../flowy/house-rules.md) #8.

## Cut/pasting a Collection List into a component strips its binding AND item template

**Observed 2026-07-13.** Symptom: a builder insert into the item fails with *"Connect this Collection
List to a Collection before adding elements"*, and the Navigator shows the item with no children.

**Fix (UI only):** select the list wrapper in the component view → Settings → Collection list settings →
Source → re-pick the collection, then rebuild the item template. **Simplest mitigation: don't move a
Collection List into a component.** Build it in place.

## `set_style` with a bare name can attach a whole combo CHAIN

**Observed 2026-07-13, on a project that used combo classes.** Passing a single style name attached
**three** classes, because a combo class existed whose *tail* matched the name given. `set_style` by the
same name re-resolved identically and reported success with the chain intact.

**Precondition: the project must already contain combo classes with that tail.** On a flat-class project
this cannot happen; check before treating it as a risk.

**Detection:** read `styleNames` back after every `set_style`. **Fix is UI-only:** focus the style
selector, Backspace the extra pills off, retype the name and pick the global match from the dropdown.
`set_style` also **replaces** the element's whole class list; it is not additive.

## `set_text` at creation no-ops on `TextBlock`

**Observed 2026-07-13, re-confirmed 2026-07-25 (2.0.1).** In a builder schema, `set_text` applies to
Heading and Paragraph children but is **silently ignored on TextBlock**: the build reports
success and the element renders Webflow's placeholder *"This is some text inside of a div block."*
Classes, attributes and structure all land correctly.

**Changed in 2.0.1:** nesting is now `Block > String` (**one** wrapper), where it used to be
`Block > Block > String`. Requested type `TextBlock` returns type `Block`.

**Fix:** after the build, `set_text` targeting the inner **String** node's id. Budget one
`children_depth: -1` query plus the text writes for any text-heavy build.

## Backgrounded-tab CSS-transition freeze fakes "transform not applying"

**Observed 2026-07-21.** Verifying a slider from a NON-focused tab: the library wrote
`transform: translateX(-560px)` inline, yet `getComputedStyle().transform` stayed
`matrix(1,0,0,1,0,0)` and `getBoundingClientRect()` never moved — for minutes, across repeated calls.

**Cause:** the element had a `transition` on `transform`, and a backgrounded tab renders no frames, so
CSS transitions never advance past their start value. Computed style reports the frozen
interpolation, not the target. **The tell:** a transition-less element in the same page applies
transforms instantly.

**Fix:** set `el.style.transition = 'none'` before the change (re-set per move; libraries often
re-apply their transition inline every move), or foreground the tab. Index/state APIs advance fine;
only rendered and computed values freeze. Sibling trap to the `{w:0,h:0}` backgrounded-viewport caveat
in [diagnostics.md](diagnostics.md).

## Slider libraries can inline-override your class spacing

**Observed 2026-07-21 (Splide v4, but the pattern generalises).** With a `gap` option set, the library
writes `margin-right` **inline** on every slide at mount: `gap: 0` silently zeroed a `44px` class
margin. No stylesheet rule involved; computed `marginRight` read `0px` with zero matching CSS rules.

**Fix:** express the gap in the library options, not the class. The canvas (no library) still uses
the class margin and live uses the option; set both to the same value so they agree.

## Multi-instance CMS slider pairing (Finsweet cmsslider v1)

**Source-verified, v1.7.1.** Every unsuffixed `fs-cmsslider-element="list"` pairs to the **first**
`.w-slider[fs-cmsslider-element="slider"]` in the document. Unpaired sliders keep their static
placeholder slides. Multiple instances on one page need `slider-2` / `list-2` suffixes; assign them at
parse time by document order.

**Bonus trap:** items moved between variant-styled instances keep their `w-variant-*` classes, so light
items dropped into a dark slider render dark-on-dark and look like empty slides.

## `Enter` on a Navigator-selected HtmlEmbed opens the Code Embed Editor

**Observed 2026-07-21.** This is the reliable route. Canvas double-click often selects an
**ancestor** (the embed's strip sits under the parent's hit area), and the hover-pencil (`EditIcon`)
**disappears the moment `javascript_tool` runs**, because hover state is lost.

Single-click the embed's Navigator row → press **Enter**. A second `Enter` does nothing once focus
leaves the Navigator; re-click the row first. Naming embeds via `set_display_name` makes the row
unambiguous.

## "Delete Collection" silently no-ops while the collection has items

**Observed 2026-07-21.** Clicking the red **Delete Collection** button with items still present produced
**nothing**: no modal, no toast, no error, no dialog in the accessibility tree. Three attempts,
identical non-result.

**Verified fix:** empty the collection first (`data_cms_tool > delete_collection_items`), **reload the
CMS view**, then click Delete Collection; the confirm modal appears and Delete works.

**Also verified:** a collection settings screen left open across an external MCP item deletion is
stale (it kept showing the old item count). Reload before retrying.

> There is still **no `delete_collection` action** in the MCP schema, re-checked under 2.0.1. Collection
> deletion is Designer-UI-only.
