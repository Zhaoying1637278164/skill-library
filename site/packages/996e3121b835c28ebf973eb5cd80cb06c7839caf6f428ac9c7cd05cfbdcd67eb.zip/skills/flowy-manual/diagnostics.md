# flowy-manual — live-page & canvas diagnostic probes

> Part of **flowy-manual** (see [SKILL.md](SKILL.md)). [flowy-verify](../flowy-verify/SKILL.md) Step 6
> runs live-page probes after an authorized publish. Run these via
> `mcp__claude-in-chrome__javascript_tool`.
>
> **These are templates.** Substitute the classes, IDs, and library names from the site you are actually
> working on. The traps they diagnose live in [designer-traps.md](designer-traps.md) and
> [mcp-2.0.md](mcp-2.0.md).

## Before you trust any measurement

```js
// Viewport sanity check — run this FIRST
({ vw: innerWidth, vh: innerHeight })
```

`{vw: 0, vh: 0}` means the tab is **backgrounded or asleep**. Every number after that is fiction, and
small-viewport media queries will have fired falsely. Foreground the tab and re-run.

## 1 — Class attachment after a builder insert

```js
// Did the classes actually land? Absent/empty className = silently dropped.
Object.fromEntries(
  ['<class-a>', '<class-b>'].map(c => {
    const el = document.querySelector('.' + c);
    return [c, el ? el.className : 'NOT FOUND'];
  })
)
```

Cross-check the stored side with `data_style_tool > query_styles name_path:["<class>"]`: `matches: []`
means the style was never created. See [mcp-2.0.md](mcp-2.0.md) §8.

## 2 — Computed geometry

```js
const el = document.querySelector('<selector>');
const cs = getComputedStyle(el), b = el.getBoundingClientRect();
({ w: cs.width, h: cs.height, position: cs.position,
   offsetParent: el.offsetParent ? el.offsetParent.className : null,
   rect: { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height) } })
```

`offsetParent` is the reliable way to learn which ancestor an absolutely-positioned element actually
resolves against, essential whenever an extra DOM level appears, e.g. converting static repeats to a
Collection List, where `.w-dyn-items` sits between wrapper and item.

## 3 — Reading the Designer canvas iframe

```js
const ifr = [...document.querySelectorAll('iframe')].find(f => {
  try { return f.contentDocument && f.contentDocument.querySelector('<selector-on-the-page>'); }
  catch (e) { return false; }
});
const d = ifr.contentDocument;
({ htmlClasses: d.documentElement.className,      // contains wf-design-mode in the canvas
   count: d.querySelectorAll('<selector>').length })
```

The canvas `<html>` carries `wf-design-mode`; the published page does **not**. That is what makes
`html.wf-design-mode .x { … }` a canvas-only styling hook.

## 4 — Did a Collection List actually resolve?

```js
const items = [...d.querySelectorAll('[data-your-hook]')];
({ count: items.length,
   texts: items.map(i => i.textContent.trim()).slice(0, 10),
   classes: items[0] ? items[0].className : null,   // expect: your class + w-dyn-item
   emptyStatePresent: !!d.querySelector('.w-dyn-empty') })
```

⚠️ If this returns 0 and the empty state is showing, **reload the Designer tab before concluding
anything**: a newly-set Collection List source does not appear in the canvas until reload
([mcp-2.0.md](mcp-2.0.md) §3).

## 5 — Animation library initialised?

```js
// Adapt to whichever library the site uses.
({ libVersion: typeof gsap !== 'undefined' ? gsap.version : null,
   pluginRegistered: typeof ScrollTrigger !== 'undefined',
   instanceOnRoot: !!document.querySelector('<root-selector>')?._yourInstanceKey })
```

Many scripts stash their instance on the root element (a `destroy()` handle, for example). Reading that
property proves the script *ran*, not merely that the library loaded.

## 6 — Embed byte-exactness (CodeMirror 6)

```js
const expected = '<sha-256 from shasum>';
let view = null;
for (const s of ['.cm-content', '.cm-editor', '.cm-scroller']) {
  const el = document.querySelector(s);
  if (el && el.cmTile && el.cmTile.view) { view = el.cmTile.view; break; }
}
const doc = view.state.doc.toString();
const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(doc));
const sha = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
({ shaMatches: sha === expected, len: doc.length })   // boolean ONLY — see below
```

## ⚠️ The output filter — two modes

`javascript_tool` output is filtered. **Never return code content or a hex digest:**

| Returning | Block |
|---|---|
| source code (even a head/tail slice) | `[BLOCKED: Cookie/query string data]` |
| a 64-char hex SHA-256 | `[BLOCKED: Base64 encoded data]` |

Pass the expected value **into** the page and return a **boolean** plus a length. To get otherwise-blocked
content into context legitimately, route it through the OS clipboard:
`navigator.clipboard.writeText(...)` in the page (return only a length), then read the OS clipboard to a file (`pbpaste > file` on macOS, `xclip -o` / `Get-Clipboard`
elsewhere) and read
the file; the filter does not apply to local files. `clipboard.readText()` **times out** (45s,
permission-gated); write works, read does not.

## Backgrounded-tab transition freeze

A non-focused tab renders no frames, so **CSS transitions never advance past their start value**.
`getComputedStyle().transform` reports the frozen initial value while the inline style shows the target,
and `getBoundingClientRect()` never moves, for minutes. The tell: a transition-less element in the same
page applies transforms instantly.

Fix when measuring animated properties from a background tab: set `el.style.transition = 'none'` before
the change (re-set per move; libraries often re-apply their transition inline on every move), or
foreground the tab. Index and state APIs advance fine; only rendered and computed values freeze.
