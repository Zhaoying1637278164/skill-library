# YoFacturo MCP Plugin

Connect Claude to your [YoFacturo](https://yo-facturo.com) account — the invoicing, POS
and business management platform for Argentina with AFIP/ARCA electronic invoicing.
Once connected, Claude can query and manage customers, products, sales, invoices, quotes,
expenses, suppliers, current accounts and VAT reports in plain language.

This repository only contains **configuration** that points Claude at YoFacturo's remote
MCP server (`https://api.yo-facturo.com/api/v1/mcp`). It ships no code of its own — the
server itself is operated and maintained by YoFacturo.

## Install

### Option A — Plugin marketplace (recommended)

```
/plugin marketplace add MatiasZani/yofacturo-mcp-plugin
/plugin install yofacturo@yofacturo-mcp-plugin
```

### Option B — Add the MCP server directly

If you don't want to use the plugin marketplace, add the server straight to Claude Code:

```
claude mcp add --transport http yofacturo https://api.yo-facturo.com/api/v1/mcp
```

### Option C — Claude.ai / Claude Desktop custom connector

1. Go to **Settings → Connectors → Add custom connector**.
2. Name it `YoFacturo` and set the URL to `https://api.yo-facturo.com/api/v1/mcp`.
3. Save, then follow the authorization flow described below.

## Authentication

The server uses **OAuth 2.1 with PKCE** and Dynamic Client Registration — there are no
API keys or secrets to configure. The first time you call a YoFacturo tool, Claude opens
a browser window to `yo-facturo.com` for you to log in and authorize access. Tokens are
issued per-client and can be revoked at any time (see below).

### Scopes

| Scope | Grants |
|---|---|
| `yofacturo:read` | Read-only access: look up customers, products, sales, invoices, quotes, expenses, suppliers, current accounts and reports. |
| `yofacturo:write` | Everything in `read`, plus creating/updating records: turn a quote into a sale, register a payment, log an expense, etc. |

You choose which scopes to grant during the authorization flow.

### Plan requirement

The MCP server is available on the **Básico**, **Completo** and **Premium** plans
(including active trials). It is not available on lower tiers.

### Rate limits

| Window | Limit |
|---|---|
| Per second | 8 requests |
| Per minute | 120 requests |
| Per hour | 3,000 requests |
| Per day | 20,000 requests |

### Managing or revoking access

Go to **Settings → Integrations → MCP Server** in your YoFacturo account to see connected
clients, review granted scopes, or revoke access at any time.

## Example prompts

- "Give me a sales summary for last month."
- "Turn quote #1042 into a sale."
- "Register a payment of $50,000 for invoice #A-0003-00001200."
- "Generate the VAT book report for August."
- "Log an expense of $8,000 for office supplies, paid in cash."

## Links

- Docs: https://yo-facturo.com/docs/
- Privacy policy: https://yo-facturo.com/legal/privacy-policies/
- Terms and conditions: https://yo-facturo.com/legal/terms-and-conditions/
- Support: https://yo-facturo.com/docs/

---

## En español

Este plugin conecta Claude con tu cuenta de [YoFacturo](https://yo-facturo.com) —el
sistema de facturación, POS y gestión de negocio para Argentina con facturación
electrónica AFIP/ARCA— para consultar y gestionar clientes, productos, ventas, facturas,
presupuestos, gastos, proveedores, cuentas corrientes y reportes de IVA en lenguaje natural.

Instalación vía marketplace: `/plugin marketplace add MatiasZani/yofacturo-mcp-plugin` y
luego `/plugin install yofacturo@yofacturo-mcp-plugin`; o agregá el servidor MCP
directamente con `claude mcp add --transport http yofacturo https://api.yo-facturo.com/api/v1/mcp`.
El login es por OAuth 2.1 + PKCE (sin API keys), disponible en los planes Básico, Completo
y Premium (incluye trials). Podés administrar o revocar el acceso desde
**Configuración → Integraciones → Servidor MCP** dentro de YoFacturo.

## License

[MIT](./LICENSE)
