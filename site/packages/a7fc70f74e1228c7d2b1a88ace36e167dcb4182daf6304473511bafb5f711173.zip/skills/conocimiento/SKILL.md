---
name: conocimiento
description: Busca en el conocimiento y las normas de la empresa en Xestando
argument-hint:
- consulta
- o normas
---

Busca en el conocimiento de Xestando: $ARGUMENTS

Usa `searchKnowledge` del servidor MCP `xestando`:

- `consulta` — el texto a buscar.
- `tipo=conocimiento` (por defecto) para documentos que el usuario ha añadido al
  conocimiento desde el gestor de archivos; `tipo=normas` para normas e instrucciones.
- `carpeta` — acota a una carpeta si el usuario la nombra.
- `limite` — número de fragmentos.

Es de solo lectura y solo ve el conocimiento de la cuenta autenticada. Cita el
documento del que sale cada fragmento. Si no hay resultados, dilo y ofrece explorar
el gestor con `mcpFileStorageApi` (`list-dirs` / `list-files`).
