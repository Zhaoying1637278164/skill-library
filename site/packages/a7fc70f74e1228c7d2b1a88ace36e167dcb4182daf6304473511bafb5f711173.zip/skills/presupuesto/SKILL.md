---
name: presupuesto
description: Prepara un presupuesto en Xestando a partir de un alcance o de código del repo
argument-hint:
- cliente y alcance del trabajo
---

Prepara un presupuesto en Xestando para: $ARGUMENTS

Pasos:

1. Si el alcance sale del repositorio en el que estás (una feature, un issue, un plan de
   migración), revisa el código o los documentos necesarios para estimar de verdad, y
   parte el trabajo en partidas con horas o unidades. `searchKnowledge` puede aportar
   normas o tarifas de la empresa si las tiene en el conocimiento.
2. Localiza el cliente con `mcpSeleccionarFicha` (`tipo=cliente`) o `mcpObtenerPersonas`.
   Si la elección no es evidente, `mcpSolicitarSeleccion`.
3. Enseña la estimación al usuario antes de mandar nada: partidas (`lineas` /
   `lines` con concepto, cantidad, `precioUnitarioSinIva`, descuento, IVA y retención).
   Sin fecha, validez, moneda, IVA o retención, la tool usa hoy, 30 días, EUR, 21% y 0%.
4. Llama a `mcpCrearPresupuestoConfirmacionPush` y muéstrale el `confirmationUrl`.

No maquilles la estimación: si una partida es incierta, dilo en su concepto.
