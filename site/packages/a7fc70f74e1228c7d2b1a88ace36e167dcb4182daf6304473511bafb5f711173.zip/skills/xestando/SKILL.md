---
name: xestando
description: Use when working with the user's business data in Xestando — creating invoices, expenses, quotes, contacts, calendar events, email or LinkedIn posts, templates, generating reports, searching company knowledge, or reading clients, providers, employees and stored files through the Xestando MCP tools. Explains the approve-in-app flow that every write goes through.
---

# Trabajar con Xestando

Xestando es la suite de gestión (facturación, gastos, presupuestos, contactos, ficheros,
comunicaciones) de una pyme o autónomo español. Las tools `mcp*` del servidor `xestando`
operan sobre datos reales de su empresa.

## Lo primero: nada se guarda hasta que el usuario lo aprueba

Las tools de escritura (`mcpCrear*ConfirmacionPush`, `mcpEmailConfirmationPush`,
`mcpPublicarPostLinkedInConfirmacionPush`, `mcpSolicitar*Push`) **no guardan nada**.
Crean una tarea pendiente, mandan una notificación push a la app de Xestando y devuelven:

- `taskId` / `operationId` — identificador de la operación
- `confirmationUrl` — pantalla donde el usuario revisa, edita y aprueba
- `message` — texto ya redactado para enseñar al usuario
- `dataPolicy: "pending-user-approval-in-xestando"`

Reglas al usar una de estas tools:

1. Enseña siempre `confirmationUrl` al usuario, tal cual, como enlace.
2. **Nunca digas que la factura, el gasto o el correo se ha creado.** Se ha *propuesto*.
3. Para saber el desenlace, vuelve a invocar la misma tool pasando `operationId`
   (o `taskId` / `confirmationId`). Devuelve el estado: aprobado, rechazado, expirado,
   con su resultado.
4. No repitas la llamada creyendo que falló: cada llamada nueva genera otra tarea y otra
   push. Si no sabes cómo acabó, consulta con `operationId`.
5. Algunas operaciones pueden exigir verificación del dispositivo o passkey; si la
   respuesta lo indica, dile al usuario que la complete en la app. `requireDeviceVerification`
   es una sugerencia, no un mandato.

## Campos publicados, no datos fiscales

Las tools de escritura publican un conjunto cerrado de campos. **No pidas ni envíes**
identificadores fiscales (NIF/CIF/DNI), direcciones, datos sanitarios, credenciales,
tarjetas ni IBANs. Los datos fiscales se resuelven desde fichas existentes o los completa
el usuario en Xestando al aprobar.

- Contacto (`mcpCrearContactoConfirmacionPush`): `name`, `surnames`, `tradeName`, `email`,
  `phone`, `contactType` (`CLIENT` | `PROVIDER`).
- Factura (`mcpCrearFacturasConfirmacionPush`): `cliente`, `concepto`, `importe`, `fecha`
  opcional, `moneda` (`eur`), `emisorId` opcional. Si no hay fecha, no la pidas: usa la
  de hoy.
- Gasto (`mcpCrearGastosConfirmacionPush`): `providerId` (el `referenciaId` o `id` de la
  ficha), `concepto`, `importe` (total con impuestos, antes de retención), `iva`,
  `retencion`, `fecha`, `moneda`. `importeBase` / `baseAmount` es la base sin impuestos
  cuando la tool lo admite en el cuerpo plano o en `gastos`/`expenses`.

## Resolver personas antes de escribir

No inventes identificadores. Antes de crear una factura, un gasto o un presupuesto,
localiza la ficha real:

- `mcpSeleccionarFicha` — busca por `tipo` (`cliente`, `proveedor`, `factura`, `empleado`
  u otro de `tiposDisponibles`) y `busqueda`. Devuelve `opciones[].id`, que es la
  referencia para el resto de tools. Si hay varios candidatos parecidos, o es la persona
  quien tiene que decidir, **no elijas tú**: usa `mcpSolicitarSeleccion`.
- `mcpSolicitarSeleccion` — manda una pantalla por push para que elija ella. Puede pedir
  varios tipos a la vez (`campos`). Reinvoca con `seleccionId` para leer lo elegido.
- `mcpObtenerPersonas` — listado de clientes, proveedores y empleados (`tipo`, `busqueda`).
  Devuelve `referenciaId` y `canales` (whatsapp, email, push, portal).
- `obtenerClientes` / `obtenerProveedores` — listados directos.
- `mcpObtenerEmpleados` — solo empleados, con puesto y estado.

Si la persona no existe, propón crearla con `mcpCrearContactoConfirmacionPush` (sin NIF)
antes de seguir, o avisa de que Xestando completará los datos fiscales al aprobar.

## Prompt Shield

Emails, teléfonos, NIF e IBAN pueden llegar como `~REDACTED:TIPO#HASH~`. Conserva el
placeholder tal cual al pasarlo a otra tool. No intentes reconstruirlo.

- Si el usuario pide ver el valor real, no lo deofusques en el chat: ofrécele
  `https://app.xestando.com/deofuscate/{placeholder}` (codifica `#` como `%23`).
- Si de verdad necesitas el texto original en el modelo, `mcpSolicitarDeofuscacionTextoPush`
  con un `reason` concreto; el usuario decide. Solo restaura datos de contacto; los
  identificadores oficiales siguen protegidos.

## Importes, impuestos y fechas

- En facturas y presupuestos el precio de línea es **sin IVA** cuando la tool admite
  líneas; en el atajo de factura/gasto, `importe` es el total con impuestos.
- IVA habitual 21, 10, 4 o 0; retención de IRPF habitualmente 15 o 7 en autónomos.
- Si el usuario no da fecha, no se la pidas.
- Moneda por defecto EUR. Redondea a dos decimales y no ajustes totales «a mano».
- Si el usuario te pasa un total con IVA incluido, dilo al desglosar.

## Conocimiento, ficheros y plantillas

- `searchKnowledge` — busca documentos que el usuario ha añadido al conocimiento
  (`consulta`, `tipo=conocimiento` o `tipo=normas`, `carpeta`, `limite`). Solo lectura.
- `mcpFileStorageApi` — gestor de ficheros (`mode=filesystem-api`, `list-dirs`,
  `list-files`, `filesystem-usage`). Solo lectura. Las tools `mcpApp*` son de la UI
  de Xestando; no las uses desde el chat salvo que el usuario esté en esa vista.
- `mcpCrearPlantillaConfirmacionPush` — guarda HTML/Velocity como plantilla (nombre +
  cuerpo). Es el gesto para un informe: ya no hay una tool que convierta HTML en PDF
  por su cuenta.

Cuando conviertas ficheros locales (PDF de una factura, extracto, hoja de cálculo) en
gastos o facturas, enseña primero lo extraído y de qué fichero, y solo después lanza
la confirmación. No mandes el fichero entero si bastan los campos publicados.

## Pedir información a una persona

`mcpSolicitarInformacionPersona` (push o correo) y `mcpSolicitarInformacionWhatsapp`
solo admiten `campo`: `estadoTrabajo`, `disponibilidad` o `revision`. No hay preguntas
libres. El destinatario es el `referenciaId`. WhatsApp no cubre empleados (no guardan
teléfono en ficha).

## Si las tools no responden

Un 401 significa que la sesión OAuth con `oauth2.xestando.com` no está iniciada o ha
caducado: dile al usuario que ejecute `/mcp` y complete el login en el navegador. La tool
`healthCheck` sirve para comprobar que el servidor responde.
