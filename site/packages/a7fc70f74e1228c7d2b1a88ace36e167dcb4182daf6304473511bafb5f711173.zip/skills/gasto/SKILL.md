---
name: gasto
description: Registra gastos en Xestando leyendo facturas o tickets del disco
argument-hint:
- ruta a factura/ticket
- carpeta
- o descripción del gasto
---

Registra en Xestando el gasto o los gastos de: $ARGUMENTS

Pasos:

1. Si son ficheros o una carpeta, léelos (PDF, imagen, CSV, hoja de cálculo) y extrae de
   cada uno: proveedor, fecha, concepto, base, IVA, retención y total. No envíes el NIF:
   resuélvelo con la ficha del proveedor.
2. Localiza el proveedor con `mcpSeleccionarFicha` (`tipo=proveedor`) o
   `mcpObtenerPersonas` (`tipo=proveedor`). El `id` / `referenciaId` va en `providerId`.
   Si no está dado de alta, avisa: Xestando lo creará con los datos del documento al
   aprobar, o propón `mcpCrearContactoConfirmacionPush` (`contactType=PROVIDER`).
3. Presenta una tabla con lo extraído y el fichero de origen de cada línea, para que el
   usuario detecte errores de lectura antes de mandar nada. `importe` es el total con
   impuestos, antes de retención.
4. Llama a `mcpCrearGastosConfirmacionPush` con todos los gastos en una sola llamada
   (hay un máximo por solicitud; si te pasas, agrupa en varias tandas y dilo).
5. Muestra el `confirmationUrl` para que los revise y apruebe.

Si algún importe no cuadra con el total del documento, no lo ajustes en silencio:
señálalo como dudoso.
