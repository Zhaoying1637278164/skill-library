---
name: fichas
description: Consulta clientes, proveedores y empleados de Xestando
argument-hint:
- búsqueda o tipo: cliente|proveedor|empleado
---

Consulta las fichas de Xestando que encajen con: $ARGUMENTS

Usa `mcpSeleccionarFicha` (o `mcpObtenerPersonas` con `tipo` y `busqueda`) para buscar.
`obtenerClientes` / `obtenerProveedores` / `mcpObtenerEmpleados` valen si pide un
listado concreto. Sin argumentos, muestra un resumen por tipo. Si hay varios candidatos
y la elección importa, no elijas tú: `mcpSolicitarSeleccion`.

Presenta los resultados en una tabla con nombre, tipo, email y teléfono. Guarda los
`id` / `referenciaId` para usarlos en llamadas posteriores, pero no los muestres salvo
que hagan falta. Los datos personales pueden llegar ofuscados por Prompt Shield;
conserva los placeholders. No copies estos datos a ficheros del proyecto sin que el
usuario lo pida.
