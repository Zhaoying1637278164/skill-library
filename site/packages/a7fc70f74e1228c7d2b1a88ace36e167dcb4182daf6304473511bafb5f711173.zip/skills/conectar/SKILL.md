---
name: conectar
description: Comprueba la conexión con Xestando y muestra qué puedes hacer desde aquí
---

Comprueba el estado de la conexión con Xestando y resume lo que hay disponible:

1. Llama a la tool `healthCheck` del servidor MCP `xestando`.
2. Si responde, llama a `mcpObtenerPersonas` con un límite pequeño para confirmar que el
   token tiene acceso a los datos de la cuenta, y di de qué cuenta se trata.
3. Si falla con 401 o no autorizado, explica al usuario que debe ejecutar `/mcp`,
   elegir el servidor `xestando` y completar el login en `oauth2.xestando.com`.
4. Si el servidor no responde, indica que el problema está en `api.xestando.com/mcp`
   y no en su configuración.

Termina con una lista corta de lo que puede pedirte desde el terminal: crear facturas y
gastos (incluso a partir de PDFs del disco), presupuestos, contactos, eventos de agenda,
correos y campañas, posts de LinkedIn, plantillas HTML, buscar en el conocimiento de la
empresa y consultar ficheros. Recuérdale que todo lo que escriba se aprueba antes en la
app de Xestando.
