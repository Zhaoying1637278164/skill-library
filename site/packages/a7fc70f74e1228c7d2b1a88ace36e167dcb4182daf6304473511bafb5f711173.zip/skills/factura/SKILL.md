---
name: factura
description: Prepara una factura en Xestando a partir de una descripción o de un fichero
argument-hint:
- cliente y conceptos
- o ruta a un fichero
---

Prepara una factura en Xestando con esto: $ARGUMENTS

Pasos:

1. Si el argumento apunta a un fichero del proyecto (PDF, imagen, hoja de horas, CSV,
   albarán…), léelo y extrae de ahí cliente, concepto e importe. No extraigas ni envíes
   el NIF: Xestando lo toma de la ficha.
2. Localiza el cliente con `mcpSeleccionarFicha` (`tipo=cliente`) o `mcpObtenerPersonas`
   (`tipo=cliente`). Si hay varios candidatos, usa `mcpSolicitarSeleccion` para que elija
   el usuario. Si no existe, dilo antes de continuar o propón `mcpCrearContactoConfirmacionPush`.
3. Monta `cliente` (nombre o id de ficha), `concepto` e `importe`. La fecha es opcional;
   si no la da el usuario, no la pidas. Moneda `eur`. No envíes identificadores fiscales
   ni direcciones.
4. Enseña al usuario el desglose y espera su visto bueno si algún dato es una suposición.
5. Llama a `mcpCrearFacturasConfirmacionPush` y muéstrale el `confirmationUrl` devuelto.

La factura no queda emitida hasta que la apruebe en Xestando. Si quiere saber cómo acabó,
vuelve a invocar la tool con el `operationId`.
