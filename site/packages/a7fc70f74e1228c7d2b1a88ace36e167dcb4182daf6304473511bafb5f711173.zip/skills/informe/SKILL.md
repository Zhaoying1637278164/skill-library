---
name: informe
description: Genera un informe en HTML y lo guarda como plantilla en Xestando
argument-hint:
- tema del informe
---

Genera un informe en Xestando sobre: $ARGUMENTS

Pasos:

1. Reúne los datos con las tools de lectura que hagan falta (`mcpSeleccionarFicha`,
   `mcpObtenerPersonas`, `obtenerClientes`, `obtenerProveedores`, `mcpObtenerEmpleados`,
   `mcpFileStorageApi`, `searchKnowledge`) y, si el informe trata del proyecto en el
   que estás, con lo que haya en el repositorio.
2. Escribe el informe en HTML autocontenido: estilos en línea, sin fuentes ni imágenes
   externas, pensado para imprimirse en A4 y en el idioma del usuario.
3. Enséñale un resumen de lo que vas a incluir antes de mandarlo.
4. Llama a `mcpCrearPlantillaConfirmacionPush` con un `name`/`nombre` y el HTML en
   `body` / `html` / `contenido`. Muéstrale el `confirmationUrl`.

Tras la aprobación, la plantilla queda en Xestando. No hay una tool que convierta el
HTML en PDF por su cuenta: el usuario genera o imprime el PDF desde ahí si lo necesita.
