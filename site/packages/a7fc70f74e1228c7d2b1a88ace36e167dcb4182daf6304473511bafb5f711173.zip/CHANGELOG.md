# Changelog

## 0.2.0 — 2026-09-11

- Complete the plugin listing description (what Xestando is, approval flow, Prompt
  Shield) for Claude Code, Cursor and GitHub.

- Align skills with the current hosted MCP: published write fields only (no tax IDs
  or addresses), `mcpSeleccionarFicha` / `mcpSolicitarSeleccion`, Prompt Shield
  placeholders, and `searchKnowledge`.
- Replace the removed HTML-to-PDF tool with `mcpCrearPlantillaConfirmacionPush`.
- Add the `conocimiento` skill.
- Ship Cursor and Agent Plugins manifests (`plugin.json`, `.cursor-plugin/plugin.json`,
  `mcp.json`) so the same repo can be submitted to the Cursor Marketplace.

## 0.1.0 — 2026-08-13

- First release.
- Bundles the hosted Xestando MCP server (`https://api.xestando.com/mcp`, streamable
  HTTP, OAuth 2.1 with dynamic client registration).
- Skills invocable as commands: `conectar`, `factura`, `gasto`, `presupuesto`,
  `informe`, `fichas`.
- Skill `xestando`: approval flow, resolving contacts before writing, tax and date
  conventions, handling of local files and reports.
