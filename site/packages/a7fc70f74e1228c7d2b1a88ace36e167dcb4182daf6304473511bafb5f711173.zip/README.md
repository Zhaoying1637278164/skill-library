# Xestando for Claude Code and Cursor

Connect Claude Code and Cursor to [Xestando](https://xestando.com), the Spanish
business suite for freelancers and small companies: VERI*FACTU invoicing, expenses,
quotes, contacts, calendar, email, file storage, company knowledge and HTML templates.

**The AI proposes, you decide.** Every write goes through Xestando's approval flow: the
hosted MCP creates a pending task, sends a push to your Xestando app, and nothing is
saved until you review and approve it there. Prompt Shield redacts tax IDs, emails,
phones and IBANs before they reach the model. See
[xestando.com/ia-conectada](https://xestando.com/ia-conectada/).

## Install

### Claude Code

```
/plugin marketplace add javyxx/xestando-claude-plugin
/plugin install xestando@xestando
```

Then run `/mcp`, pick `xestando` and sign in.

### Cursor

When the plugin is listed in the [Cursor Marketplace](https://cursor.com/marketplace),
install **Xestando** from Customize. Until then, add the GitHub repo as a plugin
source (`/add-plugin https://github.com/javyxx/xestando-claude-plugin`) or load it
from `~/.cursor/plugins/local/xestando`.

Authentication is OAuth 2.1 with PKCE against `oauth2.xestando.com`; the client
registers itself dynamically, so there are no tokens or secrets to paste or store in
the repository. You need a Xestando account.

## What you get

Skills you can also invoke as slash commands, a skill that teaches the approval flow
and Spanish invoicing conventions, and Xestando's hosted MCP server
(`https://api.xestando.com/mcp`).

| Command | What it does |
| --- | --- |
| `/xestando:conectar` | Checks the connection and lists what you can ask for |
| `/xestando:factura` | Prepares an invoice from a description or a file on disk |
| `/xestando:gasto` | Turns PDFs, tickets or spreadsheets on disk into expenses |
| `/xestando:presupuesto` | Prepares a quote, optionally estimated from the repo you are in |
| `/xestando:informe` | Writes an HTML report and saves it as a template in Xestando |
| `/xestando:fichas` | Looks up clients, providers and employees |
| `/xestando:conocimiento` | Searches company knowledge and norms in Xestando |

The MCP server also exposes tools for contacts, calendar events, email and email
campaigns, LinkedIn posts, letting the user pick a record by push, file storage and
requesting information from a person by push or WhatsApp. Claude and Cursor pick them
as needed.

## Data and safety

- **Nothing is written without your approval.** Write tools return a `confirmationUrl`
  and a task; the operation only runs after you approve it in Xestando, and it expires
  if you don't.
- **Write tools only send published fields.** Tax IDs, addresses, health data,
  credentials and card numbers stay in Xestando; the agent does not ask for them.
- **Prompt Shield** redacts emails, phone numbers, tax IDs and IBANs before context
  reaches the model; real values are restored server-side only after authorization.
- **Read tools** (clients, providers, employees, file listings, knowledge search)
  return data from your own account to the model in the conversation, as any MCP tool
  does.
- **Local files stay local** unless you ask for them: the commands that read invoices or
  tickets from disk send only the published fields of the resulting accounting entry.
- The plugin ships no binaries, no hooks and no scripts — manifests, an MCP endpoint
  and markdown skills.

## En español

Este plugin conecta Claude Code y Cursor con tu cuenta de Xestando. En Claude Code
instálalo con `/plugin marketplace add javyxx/xestando-claude-plugin` y
`/plugin install xestando@xestando`. En Cursor, desde el marketplace o añadiendo el
repositorio. Ejecuta `/mcp` y entra con tu cuenta.

Sirve para lo que ya haces en Xestando, pero desde el terminal y con los ficheros del
disco a mano: registrar la carpeta de facturas del trimestre como gastos, emitir una
factura a partir de un parte de horas, presupuestar una feature leyendo el repositorio,
consultar el conocimiento de la empresa o guardar un informe como plantilla.

Ninguna tool guarda nada por su cuenta. Todas preparan la operación, te mandan una
notificación push y esperan a que la apruebes en la app. Si no la apruebas, caduca.

## Support

- Product: [xestando.com](https://xestando.com)
- How connected AI works: [xestando.com/ia-conectada](https://xestando.com/ia-conectada/)
- App: [app.xestando.com](https://app.xestando.com)

## License

MIT for the plugin contents (see `LICENSE`). The Xestando service itself is governed by
its own terms.
