# Changelog

All notable changes to the GoodSet Claude Code plugin. Versions follow SemVer; users
receive an update only when the manifest `version` is bumped.

## 1.1.4 - 2026-08-30

- Identified Treetap LLC as the plugin publisher while keeping GoodSet as the
  product name.

## 1.1.3 - 2026-08-30

- Added a package-level marketplace manifest so the published mirror can be
  added directly with `/plugin marketplace add torfoes/goodset-claude-plugin`
  and installed as `goodset@goodset-claude-plugin`, as the README instructs.

## 1.1.2 - 2026-08-30

- Made the package self-contained for the public distribution mirror: the
  contract tests now derive the plugin identity from the manifest and skip the
  monorepo-only checks (staging sync, local marketplace, publish workflow) when
  the package is tested standalone.
- Rewrote the README validation and installation instructions to work from the
  package root in both the monorepo and the published mirror.

## 1.1.1 - 2026-08-30

- Pointed marketplace submission metadata at the public distribution mirror and
  its repository root.
- Excluded generated Python cache files from mirror releases.

## 1.1.0 — 2026-08-29

- Broadened skill activation: trigger phrases now say workout, lift, or run
  instead of strength workout, and cover the record, log, and track verbs.
- Added the `when_to_use` frontmatter field with the "Good Set" spoken aliases,
  body-part training days, and exercise-history phrasing.
- Kept two routing negatives in the description (bare travel/arrival/readiness
  phrases, requests for another app); moved hypothetical plans, gym logistics,
  directions, and general fitness advice into the skill body.
- Dropped the "strength" qualifier from the manifest description.
- Plain-language pass over the skill body: straight quotes, no em dashes.

## 1.0.0 — 2026-08-29

- First production release candidate for community-marketplace submission.
- Added `displayName`, `homepage`, and author URL to the manifest.
- Added marketplace submission collateral under `review/` (listing metadata and
  reviewer test cases).
- MIT-licensed the package and pointed `repository` at the public distribution
  mirror `torfoes/goodset-claude-plugin`.
- Aligned activation with the OpenAI skill: bare travel, arrival, or readiness
  phrases no longer activate the skill; explicit tracking, history, progress, or
  location-management intent is required. Eval cases 07–09 grade the suppression.

## 0.1.0 — 2026-08-20

- Initial package: `track-workout` skill, production MCP server declaration
  (`https://mcp.goodset.app/mcp`, host-managed OAuth), 24 activation eval cases,
  and the package contract test suite.
