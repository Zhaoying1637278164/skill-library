# GoodSet Claude Code plugin

This package adds one focused Claude Code skill for discovering and operating the existing
GoodSet MCP workout capability. It is a host adapter: workout state, authentication,
authorization, validation, confirmation, and persistence remain in the GoodSet backend.

## Source status

This is the **production** submission artifact. The package combines the `track-workout`
discovery skill with the GoodSet production MCP server declared in `.mcp.json` at
`https://mcp.goodset.app/mcp`. No client ID, secret, or token lives in the
package: Claude Code detects that the server requires auth from its 401/403 response and
runs the OAuth flow itself (`/mcp` → select `goodset` → authenticate).

This package is developed in the GoodSet monorepo at `plugins/anthropic/goodset/` and
published to the public distribution mirror `torfoes/goodset-claude-plugin`, where it sits
at the repository root. In the monorepo, day-to-day iteration happens in the staging
sibling `plugins/anthropic/goodset-staging/` (bound to `mcp.staging.goodset.app`); promote
proven changes here by copying `skills/`, `evals/`, and `tests/` (a contract test asserts
the two trees stay in sync). Do not add a localhost URL, tunnel credential, API key, OAuth
secret, or placeholder app ID to this package.

## Validate

From this package's root directory (works in both the monorepo and the published mirror):

```bash
claude plugin validate . --strict
python3 -m unittest discover -s tests
```

The contract tests skip the monorepo-only checks (staging sync, local marketplace, publish
workflow) when the package is tested standalone. Monorepo CI runs the full checks via
`.github/workflows/ci.yml`.

The activation eval suite under `evals/` mirrors the OpenAI plugin's `evals.json` in the
`claude plugin eval` format (one `prompt.md` plus an LLM grader per case). The eval runner
is in early access; when it is enabled for the organization, run it with:

```bash
claude plugin eval .
```

## Install

From the public distribution mirror:

```bash
claude
/plugin marketplace add torfoes/goodset-claude-plugin
/plugin install goodset@goodset-claude-plugin
```

In the monorepo, the local marketplace at `.claude-plugin/marketplace.json` exposes this
package as `goodset` instead:

```bash
claude
/plugin marketplace add /path/to/goodset
/plugin install goodset@goodset-local
```

Then run `/mcp`, select `goodset`, and authenticate in the browser. Tokens are stored and
refreshed by Claude Code; authentication is a separate step from install. Inside the
plugin the server's tools are scoped as `mcp__plugin_goodset_goodset__<tool>` for
`allowed-tools` lists and hook matchers.

`SKILL.md` edits apply live; changes to `.mcp.json` need `/reload-plugins`. Test
authentication, direct and indirect activation, reads, writes, and negative cases in fresh
conversations.

## Submit

The public listing target is the Anthropic community marketplace
(`anthropics/claude-plugins-community`), submitted against the public distribution mirror
`torfoes/goodset-claude-plugin` (this package published at the repo root by
`.github/workflows/publish-claude-plugin.yml` on `claude-plugin-v*` tags). Listing copy
and reviewer test cases live in `review/`; the release process (validation, OAuth
verification, tagging, submission forms, SHA pinning) is documented in
`docs/integrations/claude-code-plugin.md`. Record every release in `CHANGELOG.md` and
bump the manifest `version` — installed users only receive updates on a version bump.
