---
type: llm
criteria: "Say that workout history could not be retrieved and ask the user to connect GoodSet without implying that a write failed."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not invent workout history
- States that history could not be retrieved
- Does not say that a workout was not recorded
- Asks the user to connect GoodSet
