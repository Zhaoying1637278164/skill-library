---
name: "Show me my last chest workout, but the GoodSet connection is unavailab"
---

Show me my last chest workout, but the GoodSet connection is unavailable.
