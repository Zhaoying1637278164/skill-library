---
type: llm
criteria: "Look for a saved match, then start or recover the workout without location context when none exists. Do not delay the workout or save the place unless asked."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls training_location_find for Harbor Strength before starting the workout
- Calls workout_track without training_location_ref when no clear match exists
- Does not call training_location_manage without an explicit save request
- Does not delay workout start to ask about the unmatched location
