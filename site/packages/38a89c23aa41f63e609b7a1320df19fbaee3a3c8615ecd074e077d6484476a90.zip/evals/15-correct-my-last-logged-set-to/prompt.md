---
name: "Correct my last logged set to 60 kilos for 9 reps."
---

Correct my last logged set to 60 kilos for 9 reps.
