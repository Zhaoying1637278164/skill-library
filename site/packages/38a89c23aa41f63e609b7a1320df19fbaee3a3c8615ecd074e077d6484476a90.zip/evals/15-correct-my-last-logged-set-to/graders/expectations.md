---
type: llm
criteria: "Prepare a correct_set mutation through workout_track, preserve the identified set and supplied values through any clarification, and confirm it before claiming success."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls workout_track with action=correct_set
- Supplies 60 kilograms and 9 repetitions without adding a replacement set
- Follows any returned disambiguation and confirmation steps
- Claims success only after the confirmed tool result
