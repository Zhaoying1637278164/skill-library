---
type: llm
criteria: "Recover the current GoodSet workout and report the returned exercise and latest-set context concisely."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls workout_track for current status
- Reports only state returned by GoodSet
- Does not invent an active exercise or previous set
