---
name: "What's my barbell bench press PR, and am I progressing?"
---

What's my barbell bench press PR, and am I progressing?
