---
type: llm
criteria: "Treat the statement as a plan and do not record a completed set."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not call a mutating GoodSet operation
- Does not claim that a set was logged
- May offer concise advice without changing workout state
