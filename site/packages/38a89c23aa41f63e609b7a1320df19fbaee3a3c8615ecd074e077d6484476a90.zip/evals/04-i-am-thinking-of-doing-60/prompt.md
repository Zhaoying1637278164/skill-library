---
name: "I am thinking of doing 60 kilos for 8 reps next."
---

I am thinking of doing 60 kilos for 8 reps next.
