---
name: "Delete that last set. I logged it by mistake."
---

Delete that last set. I logged it by mistake.
