---
type: llm
criteria: "Prepare remove_latest_set through workout_track, verify that the preview identifies the intended set, and confirm it before claiming that the set was removed."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls workout_track with action=remove_latest_set
- Confirms the preview only when it identifies the user's latest logged set
- Does not simulate removal by correcting values or adding a replacement set
- Claims that the set was removed only after the confirmed result reports outcome=applied
