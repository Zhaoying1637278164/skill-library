---
type: llm
criteria: "Prepare the finish through workout_track and follow the returned confirmation requirement before claiming success."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls workout_track with finish intent
- Does not claim the workout ended before a successful confirmed result
- Follows the tool's next action exactly
