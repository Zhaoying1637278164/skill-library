---
name: "We're tracking bench press in GoodSet. I just did 85 kilos for 6 reps."
---

We're tracking bench press in GoodSet. I just did 85 kilos for 6 reps.
