---
type: llm
criteria: "Record the completed bench-press set through workout_track and confirm only the returned result."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Treats the set as completed rather than planned
- Preserves 85 kilograms and 6 repetitions
- Follows any confirmation or continuation returned by workout_track
