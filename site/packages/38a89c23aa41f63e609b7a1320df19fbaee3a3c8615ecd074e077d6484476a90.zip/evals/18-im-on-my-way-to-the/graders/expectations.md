---
type: llm
criteria: "Treat the explicit goal as directions and do not activate GoodSet workout tracking."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not activate the track-workout skill despite the gym-arrival phrase
- Does not call a GoodSet tool
- Answers the directions request or asks for the missing locations
