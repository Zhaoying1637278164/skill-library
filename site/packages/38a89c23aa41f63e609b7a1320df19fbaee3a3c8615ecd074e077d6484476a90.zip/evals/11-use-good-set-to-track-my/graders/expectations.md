---
type: llm
criteria: "Recognize the spoken GoodSet alias and open or recover the live workout."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Activates the track-workout skill for the Good Set alias
- Calls workout_track immediately
- Claims tracking started only after a successful result
