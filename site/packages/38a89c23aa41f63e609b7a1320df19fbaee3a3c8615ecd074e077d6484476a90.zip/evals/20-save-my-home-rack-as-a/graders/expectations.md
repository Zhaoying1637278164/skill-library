---
type: llm
criteria: "Create a generic training location named Home Rack with only the explicitly supplied state."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls training_location_manage with a create operation
- Treats the place as a training location rather than requiring it to be a gym
- Does not invent coordinates or an external provider ID
- Reports success only after the tool returns it
