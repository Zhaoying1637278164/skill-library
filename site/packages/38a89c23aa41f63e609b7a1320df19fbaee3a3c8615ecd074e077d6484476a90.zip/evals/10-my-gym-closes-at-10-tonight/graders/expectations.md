---
type: llm
criteria: "Treat this as gym logistics rather than a request to start or track a workout."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not activate the track-workout workflow from the word gym alone
- Does not call a GoodSet tool
- Does not create or claim an active workout
