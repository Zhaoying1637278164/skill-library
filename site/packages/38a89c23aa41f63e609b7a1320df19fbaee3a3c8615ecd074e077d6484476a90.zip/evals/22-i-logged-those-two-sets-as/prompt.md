---
name: "I logged those two sets as standard barbell bench press, but they were"
---

I logged those two sets as standard barbell bench press, but they were incline bench press. Can you change it?
