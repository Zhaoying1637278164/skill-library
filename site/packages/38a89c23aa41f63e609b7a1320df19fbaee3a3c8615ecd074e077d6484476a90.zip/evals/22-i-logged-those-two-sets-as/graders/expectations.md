---
type: llm
criteria: "Prepare a correct_exercise mutation through workout_track, resolve the existing occurrence and replacement exercise, and confirm the reassignment before claiming success."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls workout_track with action=correct_exercise
- Uses standard barbell bench press as the source and incline bench press as the replacement
- Follows any returned exercise or occurrence disambiguation and confirmation steps
- Does not add, delete, or duplicate the two logged sets
- Claims success only after the confirmed tool result
