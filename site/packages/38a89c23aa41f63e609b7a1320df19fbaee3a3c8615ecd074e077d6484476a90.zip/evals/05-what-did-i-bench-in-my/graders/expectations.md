---
type: llm
criteria: "Use GoodSet workout history immediately and answer from the returned workout data."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Activates the track-workout skill even though GoodSet is not named
- Calls find_workouts with the relevant area or exercise filter
- Does not ask which fitness app contains the history
