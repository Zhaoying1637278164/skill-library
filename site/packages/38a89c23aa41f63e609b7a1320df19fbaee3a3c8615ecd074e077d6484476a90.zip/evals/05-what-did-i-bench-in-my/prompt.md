---
name: "What did I bench in my last chest workout?"
---

What did I bench in my last chest workout?
