---
type: llm
criteria: "Say that nothing was recorded and ask the user to connect GoodSet."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not simulate a successful workout start
- Clearly states that the workout was not recorded
- Asks the user to connect GoodSet
