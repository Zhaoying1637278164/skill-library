---
name: "Start tracking my workout, but the GoodSet connection is unavailable."
---

Start tracking my workout, but the GoodSet connection is unavailable.
