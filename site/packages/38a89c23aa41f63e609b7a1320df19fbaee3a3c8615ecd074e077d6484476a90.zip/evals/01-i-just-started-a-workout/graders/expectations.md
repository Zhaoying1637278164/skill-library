---
type: llm
criteria: "Activate GoodSet and open or recover the live workout before asking for exercise details."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Activates the track-workout skill even though GoodSet is not named
- Calls workout_track immediately
- Does not offer a conversation-only workout log
- Does not ask which app should record the workout
