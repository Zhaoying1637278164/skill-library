---
name: "We're tracking bench press. I did 85 kilos for eight sets."
---

We're tracking bench press. I did 85 kilos for eight sets.
