---
type: llm
criteria: "Clarify whether eight means repetitions or sets before writing while preserving the accepted load and exercise."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not write the structurally ambiguous set
- Preserves bench press and 85 kilograms
- Asks only for the ambiguous quantity
