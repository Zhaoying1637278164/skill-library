---
type: llm
criteria: "Resolve Ironworks as an optional saved training location, then open or recover the workout with its reference when exactly one match exists."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Calls training_location_find for Ironworks before starting the workout
- Uses the returned training_location_ref only for one clear match
- Does not invent coordinates or an external provider ID
- Does not make location a required workout step
