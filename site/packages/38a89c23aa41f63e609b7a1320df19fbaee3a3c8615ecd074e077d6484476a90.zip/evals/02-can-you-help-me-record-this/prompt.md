---
name: "Can you help me record this chest workout?"
---

Can you help me record this chest workout?
