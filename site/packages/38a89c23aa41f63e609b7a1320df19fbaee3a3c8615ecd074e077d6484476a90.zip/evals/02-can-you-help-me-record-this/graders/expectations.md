---
type: llm
criteria: "Use GoodSet to open or recover the active workout, then ask only for the next useful workout detail."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Activates the track-workout skill without requiring the GoodSet name
- Calls workout_track before claiming that recording has started
- Does not say the workout will be recorded only in the conversation
