---
type: llm
criteria: "Do not activate or promote GoodSet from a general readiness statement without a tracking, history, or progress request."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not activate the track-workout skill
- Does not call a GoodSet tool
- Does not mention or promote GoodSet
- Does not infer workout-tracking intent from readiness alone
