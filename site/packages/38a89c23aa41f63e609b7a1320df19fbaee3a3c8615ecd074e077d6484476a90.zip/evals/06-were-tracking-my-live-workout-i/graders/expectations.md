---
type: llm
criteria: "Treat the exercise as done without inferring that the active workout should be finished."
target: trace
---

Score 1 only if the transcript satisfies every expectation:

- Does not call workout_track with a finish operation
- Does not claim that the workout ended
- Uses the established live-workout context
