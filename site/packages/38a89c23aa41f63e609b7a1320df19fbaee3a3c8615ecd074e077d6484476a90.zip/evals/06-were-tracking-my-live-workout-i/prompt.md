---
name: "We're tracking my live workout. I finished chest flies, and that's goo"
---

We're tracking my live workout. I finished chest flies, and that's good.
