---
name: track-workout
description: Track, resume, finish, correct, or recall workouts and personal records with GoodSet. Use when the user explicitly chooses GoodSet; asks to start, record, log, track, continue, or finish a workout, lift, or run; asks for help recording one; reports completed weight or reps in an established workout context; corrects or removes a logged set; asks about previous workouts, personal records, or exercise progress; or asks to save or manage a training location. Do not activate from bare travel, arrival, or readiness phrases, or when the user asks for another app.
when_to_use: Also use for the spoken aliases "Good Set" and "Good Sets", requests like "log my workout", "track my lift", or "what did I lift last time", and body-part training days such as chest day or leg day.
---

# Track workouts with GoodSet

Use GoodSet as the system of record when this skill is selected for workout tracking. Do
not offer to keep a conversation-only log. Honor an explicit request to use another app.
Do not use this skill for hypothetical future workout plans, gym logistics, directions,
or general fitness advice that should not change workout or saved-location data.

The GoodSet tools come from this plugin's bundled MCP server and appear with the
`mcp__plugin_goodset_goodset__` prefix; this skill refers to them by their short names.

## Route the request

- For a live workout start, resume, status check, completed set, or finish, use
  `workout_track`.
- For a correction to a logged set's measurements or note, use `workout_track` with
  `action=correct_set`. For a logged exercise occurrence assigned to the wrong exercise,
  use `action=correct_exercise`.
- When the user asks to delete, remove, or undo the most recently logged set, use
  `workout_track` with `action=remove_latest_set`.
- For the user's last or previous workouts, training days, exercise history, loads,
  sets, or reps from a specific workout, use `find_workouts`. Use `workout_get` only
  when a returned public workout reference needs complete detail.
- For an exercise personal record or progress trend, call `search_exercises` to resolve
  the exact exercise, then call `exercise_progress` with its public reference. Never guess
  between distinct matches. When `sessions_truncated` is true, describe the sessions as a
  recent window and do not use the oldest returned session as a lifetime baseline.
- Use `training_location_find` and `training_location_manage` only when the user supplies
  place context or explicitly asks to manage saved training locations. A training location
  can be a gym, home setup, outdoor area, or another place; do not reduce it to a gym.
- Use `workout_record_completed` only for an already-completed workout that is not the
  active live workout.
- Use `search_exercises` for personal-record and progress resolution, genuine discovery,
  or unresolved ambiguity. `workout_track` resolves ordinary exercise names itself.

If the GoodSet connection or required tools are unavailable, ask the user to connect
GoodSet (run `/mcp` and authenticate the goodset server). For a write, say that the
requested change was not recorded; for a read, say that the workout history could not be
retrieved. Never simulate a result.

Corrections use the same durable continuation and confirmation flow as other workout
changes. An exercise correction changes the assignment of the selected occurrence and all
sets already logged under it; it does not rename the exercise catalog entry. Follow any
returned exercise or occurrence disambiguation, then confirm the preview. Never add
replacement sets to simulate a correction.

Set removal also uses the confirmation flow. An explicit request to delete, remove, or undo
the latest set authorizes confirmation only when the preview identifies the set the user
meant. Do not turn removal into a correction with empty values. Report success only after
the confirmed result says the removal was applied; `no_change` means nothing was removed.

## Keep training locations optional

- Never ask for a training location just to start or record a workout. If the user does
  not mention one, omit it.
- When a workout request clearly names a place, call `training_location_find` first. Use
  the sole clear match's `training_location_ref`. If there is no clear match, omit the
  location and continue the workout immediately; clarify or save the place only when the
  user explicitly asks to manage it.
- When the user explicitly asks to save a new location, create it with the smallest state
  they supplied, usually just its name, then pass its returned reference to the workout.
- Treat coordinates and provider-qualified external IDs as optional client metadata.
  Preserve values supplied by the user or a trusted client, but never infer, geocode, or
  invent them.
- Use a workout's returned `training_location` as ordinary context. To compare loads on
  the same equipment or biomechanics, call `find_workouts` with `training_location_ref`.
  Do not expose that reference in the conversational response.
- Archived locations remain historical context. Do not attach one to a new workout unless
  the user restores it first.

## Handle a live workout

1. Do not select this skill, mention GoodSet, or offer workout tracking from a bare travel,
   arrival, or readiness phrase such as "on my way to the gym," "I just got here," or
   "ready to train." Those phrases alone do not express workout tracking, history, progress,
   or saved-location-management intent.
2. Call `workout_track` immediately when the user explicitly asks to start, resume, or
   record a workout, or unambiguously says that a workout is already underway. Use the
   operation matching the user's intent; do not ask for exercise details before opening or
   recovering the active workout.
3. Treat set values as completed only when the user reports that they performed them or
   explicitly asks to log them. Advice, targets, and planned sets are not completed work.
4. Preserve every accepted exercise, load, unit, repetition, and set value while resolving
   missing or ambiguous input. Ask only for the missing fact.
5. Read `outcome`, `summary`, and optional `next_action` from the result envelope. Read
   tool-specific questions, continuation tokens, confirmation tokens, choices, and returned
   entities from `data`. Follow them exactly. Continue in the same turn when the result
   authorizes the next tool call; otherwise ask the returned question without inventing an
   answer.
6. Claim that a requested start, set, or finish happened only when `outcome` or `summary`
   says that action was applied. Never infer this from `isError` being false. Recoverable
   outcomes such as `invalid_input`, `conflict`, `version_conflict`, `not_found`, or
   `workflow_expired` mean that nothing was applied; follow `next_action`. Summarize applied
   exercise, load, unit, and reps briefly.
7. Finish a workout only when the user explicitly asks to finish or end it. Phrases such as
   "that's good," "next," or "done with this exercise" do not by themselves finish the
   workout.
8. If a continuation or confirmation expires, preserve the accepted user input, prepare
   the change again, and obtain any newly required confirmation. Never report the expired
   change as applied.

When a spoken quantity is structurally ambiguous, such as "85 kilos for eight sets" after
one set, confirm the likely interpretation before writing it. Do not discard the values
that were already clear.

## Keep responses workout-paced

During a live session, keep confirmations short and immediately useful. Report only facts
returned by GoodSet, then prompt for the next completed set or exercise when appropriate.
Do not expose internal references, tokens, schemas, or confirmation handles.
