import json
import re
import unittest
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = PLUGIN_ROOT / ".claude-plugin" / "plugin.json"
PLUGIN_NAME = json.loads(MANIFEST_PATH.read_text())["name"]
IS_STAGING = PLUGIN_NAME == "goodset-staging"
IN_MONOREPO = PLUGIN_ROOT.parent.name == "anthropic"
REPO_ROOT = PLUGIN_ROOT.parents[2] if IN_MONOREPO else PLUGIN_ROOT
SIBLING_ROOT = PLUGIN_ROOT.with_name("goodset" if IS_STAGING else "goodset-staging")
MCP_CONFIG_PATH = PLUGIN_ROOT / ".mcp.json"
SKILL_ROOT = PLUGIN_ROOT / "skills" / "track-workout"
MARKETPLACE_PATH = REPO_ROOT / ".claude-plugin" / "marketplace.json"
EVALS_ROOT = PLUGIN_ROOT / "evals"
CHANGELOG_PATH = PLUGIN_ROOT / "CHANGELOG.md"
REVIEW_ROOT = PLUGIN_ROOT / "review"
PUBLISH_WORKFLOW_PATH = (
    REPO_ROOT / ".github" / "workflows" / "publish-claude-plugin.yml"
)

VERSION = "1.1.4"
DISPLAY_NAME = "GoodSet Staging" if IS_STAGING else "GoodSet"
HOMEPAGE = "https://goodset.app"
DISTRIBUTION_REPOSITORY = "https://github.com/torfoes/goodset-claude-plugin"
PUBLISHER_NAME = "Treetap LLC"
MCP_URL = (
    "https://mcp.staging.goodset.app/mcp"
    if IS_STAGING
    else "https://mcp.goodset.app/mcp"
)
DESCRIPTION = (
    "Staging build: track, resume, finish, and recall workouts with GoodSet."
    if IS_STAGING
    else "Track, resume, finish, and recall workouts with GoodSet."
)


def require_contract(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def frontmatter_value(markdown: str, key: str) -> str:
    frontmatter = markdown.split("---", 2)[1]
    match = re.search(rf"^{re.escape(key)}:\s*(.+)$", frontmatter, re.MULTILINE)
    if match is None:
        raise AssertionError(f"skill frontmatter is missing {key}")
    return match.group(1).strip()


class GoodSetClaudePluginContractTest(unittest.TestCase):
    def setUp(self) -> None:
        self.manifest = json.loads(MANIFEST_PATH.read_text())

    def test_manifest_has_stable_identity_and_real_paths(self) -> None:
        expected_keys = {
            "$schema",
            "name",
            "displayName",
            "version",
            "description",
            "author",
            "homepage",
            "license",
            "repository",
            "keywords",
            "skills",
        }

        actual_contract = (
            set(self.manifest),
            self.manifest["name"],
            self.manifest["displayName"],
            self.manifest["version"],
            self.manifest["description"],
            self.manifest["author"]["name"],
            self.manifest["author"]["url"],
            self.manifest["homepage"],
            self.manifest["license"],
            self.manifest["repository"],
            self.manifest["skills"],
            SKILL_ROOT.is_dir(),
            (PLUGIN_ROOT / "LICENSE").is_file(),
        )
        expected_contract = (
            expected_keys,
            PLUGIN_NAME,
            DISPLAY_NAME,
            VERSION,
            DESCRIPTION,
            PUBLISHER_NAME,
            HOMEPAGE,
            HOMEPAGE,
            "MIT",
            DISTRIBUTION_REPOSITORY,
            ["./skills/track-workout"],
            True,
            True,
        )
        require_contract(actual_contract == expected_contract, "manifest identity changed")
        require_contract(
            PLUGIN_NAME in {"goodset", "goodset-staging"}
            and (not IN_MONOREPO or PLUGIN_ROOT.name == PLUGIN_NAME),
            "manifest name must be a known plugin and match its monorepo directory",
        )

    def test_changelog_records_the_released_version(self) -> None:
        changelog = CHANGELOG_PATH.read_text()
        require_contract(
            f"## {VERSION} " in changelog,
            "CHANGELOG.md does not record the manifest version; document the release "
            "before bumping the manifest",
        )

    def test_production_package_carries_submission_collateral(self) -> None:
        if IS_STAGING:
            require_contract(
                not REVIEW_ROOT.exists(),
                "staging must not carry marketplace submission collateral",
            )
            return

        package_marketplace = json.loads(
            (PLUGIN_ROOT / ".claude-plugin" / "marketplace.json").read_text()
        )
        require_contract(
            package_marketplace["name"] == "goodset-claude-plugin"
            and package_marketplace["owner"]["name"] == PUBLISHER_NAME
            and package_marketplace["plugins"][0]["name"] == "goodset"
            and package_marketplace["plugins"][0]["source"] == "./",
            "package marketplace manifest must expose goodset from the mirror root",
        )

        metadata = json.loads((REVIEW_ROOT / "submission-metadata.json").read_text())
        cases = json.loads((REVIEW_ROOT / "submission-test-cases.json").read_text())
        actual_contract = (
            metadata["schema_version"],
            metadata["display_name"],
            metadata["developer_name"],
            metadata["category"],
            metadata["website_url"],
            metadata["distribution"]["source_repository"],
            metadata["distribution"]["plugin_path"],
            cases["schema_version"],
            bool(cases["positive"]),
            bool(cases["negative"]),
            bool(cases["account_fixture"]["sign_in_requirements"]),
        )
        expected_contract = (
            1,
            "GoodSet",
            PUBLISHER_NAME,
            "Health & Fitness",
            "https://goodset.app",
            DISTRIBUTION_REPOSITORY,
            ".",
            1,
            True,
            True,
            True,
        )
        require_contract(
            actual_contract == expected_contract,
            "marketplace submission collateral changed or is incomplete",
        )

    @unittest.skipUnless(IN_MONOREPO, "publish workflow lives only in the monorepo")
    def test_publish_workflow_removes_generated_python_files(self) -> None:
        workflow = PUBLISH_WORKFLOW_PATH.read_text()
        required_cleanup_commands = (
            "--exclude .git",
            "--exclude='__pycache__/'",
            "--exclude='*.py[cod]'",
            "find mirror -type f \\( -name '*.pyc' -o -name '*.pyo' \\) -delete",
            "find mirror -depth -type d -name __pycache__ -empty -delete",
        )
        require_contract(
            all(command in workflow for command in required_cleanup_commands),
            "Claude mirror publishing can retain generated Python files",
        )

    def test_plugin_declares_environment_mcp_server(self) -> None:
        mcp_config = json.loads(MCP_CONFIG_PATH.read_text())
        expected_config = {
            "mcpServers": {
                "goodset": {
                    "type": "http",
                    "url": MCP_URL,
                }
            }
        }
        require_contract(
            mcp_config == expected_config,
            f"plugin does not declare the {PLUGIN_NAME} GoodSet MCP server",
        )

    def test_plugin_has_no_localhost_or_credential_material(self) -> None:
        mcp_config = MCP_CONFIG_PATH.read_text()
        require_contract(
            re.search(r"localhost|127\.0\.0\.1", mcp_config) is None,
            "MCP config contains a machine-local server",
        )
        require_contract(
            re.search(r"(?i)secret|token|api[_-]?key", mcp_config) is None,
            "MCP config contains credential material",
        )

    @unittest.skipUnless(IN_MONOREPO, "the local marketplace lives only in the monorepo")
    def test_repo_marketplace_surfaces_both_environments(self) -> None:
        marketplace = json.loads(MARKETPLACE_PATH.read_text())
        entries = {entry["name"]: entry for entry in marketplace["plugins"]}
        expected_entry = {
            "name": PLUGIN_NAME,
            "source": f"./plugins/anthropic/{PLUGIN_NAME}",
            "description": DESCRIPTION,
            "category": "Health & Fitness",
        }
        actual_contract = (
            marketplace["name"],
            marketplace["description"],
            marketplace["owner"]["name"],
            set(entries),
            entries.get(PLUGIN_NAME),
            (REPO_ROOT / f"plugins/anthropic/{PLUGIN_NAME}").is_dir(),
        )
        expected_contract = (
            "goodset-local",
            "Local development marketplace for the GoodSet Claude Code plugin.",
            PUBLISHER_NAME,
            {"goodset", "goodset-staging"},
            expected_entry,
            True,
        )
        require_contract(actual_contract == expected_contract, "repo marketplace entry changed")

    def test_skill_scopes_tools_to_this_plugin(self) -> None:
        skill = (SKILL_ROOT / "SKILL.md").read_text()
        require_contract(
            f"`mcp__plugin_{PLUGIN_NAME}_goodset__` prefix" in skill,
            "skill tool prefix does not match this plugin's name",
        )

    @unittest.skipUnless(IN_MONOREPO, "the staging sibling lives only in the monorepo")
    def test_environments_stay_in_sync(self) -> None:
        def normalized_tree(root: Path) -> dict[str, str]:
            files = {}
            for subtree in ("skills", "evals", "tests"):
                for path in sorted((root / subtree).rglob("*")):
                    if path.is_file() and "__pycache__" not in path.parts:
                        files[str(path.relative_to(root))] = path.read_text().replace(
                            "goodset-staging", "goodset"
                        )
            return files

        require_contract(
            normalized_tree(PLUGIN_ROOT) == normalized_tree(SIBLING_ROOT),
            "staging and production plugin content diverged; promote by copying "
            "skills/, evals/, and tests/ between the two trees",
        )

    def test_skill_activates_for_transcript_language(self) -> None:
        skill = (SKILL_ROOT / "SKILL.md").read_text()
        description = frontmatter_value(skill, "description")
        when_to_use = frontmatter_value(skill, "when_to_use")
        body = skill.split("---", 2)[2]
        required_description_phrases = (
            "explicitly chooses GoodSet",
            "record, log, track, continue, or finish a workout, lift, or run",
            "help recording",
            "completed weight or reps",
            "personal records",
            "corrects or removes a logged set",
            "Do not activate from bare travel, arrival, or readiness phrases",
            "asks for another app",
        )
        required_when_to_use_phrases = (
            "Good Set",
            "Good Sets",
            "log my workout",
            "lift last time",
        )
        required_body_phrases = (
            "hypothetical future workout plans",
            "gym logistics",
            "general fitness advice",
            "Honor an explicit request to use another app",
        )
        require_contract(
            all(phrase in description for phrase in required_description_phrases)
            and all(phrase in when_to_use for phrase in required_when_to_use_phrases)
            and all(phrase in body for phrase in required_body_phrases),
            "skill activation metadata lost required transcript language",
        )
        require_contract(
            len(description) + len(when_to_use) <= 1536,
            "combined description and when_to_use exceed the 1536-character listing cap",
        )

    def test_skill_has_no_scaffold_placeholders(self) -> None:
        skill = (SKILL_ROOT / "SKILL.md").read_text()
        require_contract("TODO" not in skill, "skill contains a scaffold placeholder")

    def test_skill_routes_pr_and_progress_queries_to_exercise_progress(self) -> None:
        skill = " ".join((SKILL_ROOT / "SKILL.md").read_text().split())
        required_phrases = (
            "exercise personal record or progress trend",
            "search_exercises",
            "exercise_progress",
            "sessions_truncated",
            "recent window",
        )
        require_contract(
            all(phrase in skill for phrase in required_phrases),
            "skill does not route PR and progress questions to exercise_progress",
        )

    def test_skill_keeps_training_locations_generic_and_optional(self) -> None:
        skill = (SKILL_ROOT / "SKILL.md").read_text()
        normalized_skill = " ".join(skill.split())
        required_phrases = (
            "training_location_find",
            "training_location_manage",
            "Never ask for a training location",
            "gym, home setup, outdoor area, or another place",
            "training_location_ref",
            "never infer, geocode, or invent",
            "omit the location and continue the workout immediately",
        )
        require_contract(
            all(phrase in normalized_skill for phrase in required_phrases),
            "skill lost optional generic training-location behavior",
        )

    def test_activation_eval_ids_are_unique(self) -> None:
        case_ids = [
            case_dir.name.partition("-")[0]
            for case_dir in EVALS_ROOT.iterdir()
            if case_dir.is_dir()
        ]
        require_contract(
            all(case_id.isdigit() for case_id in case_ids)
            and len(case_ids) == len(set(case_ids)),
            "activation eval IDs must be numeric and unique",
        )

    def test_activation_evals_cover_required_families(self) -> None:
        case_dirs = sorted(path for path in EVALS_ROOT.iterdir() if path.is_dir())
        require_contract(
            all(
                (case_dir / "prompt.md").is_file() and any((case_dir / "graders").glob("*.md"))
                for case_dir in case_dirs
            ),
            "an eval case is missing its prompt or grader",
        )

        prompts = "\n".join(
            (case_dir / "prompt.md").read_text().split("---", 2)[2].lower()
            for case_dir in case_dirs
        )
        required_phrases = (
            "started a workout",
            "help me record",
            "continue my workout",
            "thinking of doing",
            "last chest workout",
            "that's good",
            "on my way to the gym",
            "just got to the gym",
            "at the gym and ready to train",
            "gym closes at 10",
            "use good set",
            "just did 85 kilos for 6 reps",
            "85 kilos for eight sets",
            "finish my goodset workout",
            "correct my last logged set",
            "delete that last set",
            "connection is unavailable",
            "show me my last chest workout, but the goodset connection is unavailable",
            "which bus should i take",
            "start my workout at ironworks",
            "save my home rack as a training location",
            "barbell bench press pr",
        )
        require_contract(
            all(phrase in prompts for phrase in required_phrases),
            "activation eval coverage is incomplete",
        )


if __name__ == "__main__":
    unittest.main()
