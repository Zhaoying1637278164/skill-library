---
name: sustainability
description: "Explain sustainability ratings and help users find eco-friendly branded merchandise. Use when the user asks about \"sustainability\", \"eco-friendly\", \"green products\", \"recycled\", \"ethical sourcing\", or \"environmental impact\" of merchandise.\n"
---

# Sustainability

Products are rated A through E for sustainability:

- **A** — Excellent: recycled materials, certified sustainable, minimal environmental impact
- **B** — Good: some sustainable attributes, eco-conscious production
- **C** — Moderate: meets basic standards
- **D** — Below average: limited sustainability credentials
- **E** — No sustainability data available

## Criteria

Sustainability scores are based on multiple criteria including:
- Recycled or recyclable materials
- Organic or sustainably sourced materials
- Factory audits or EU manufacturing
- Certifications (B Corp, FSC, GOTS, etc.)
- Reduced packaging or carbon-neutral shipping

## Searching by sustainability

Use `sustainabilityRating` filter in `search_products`:
- For eco-focused briefs, filter by A or B
- Highlight sustainability credentials when presenting products
- If a client has sustainability goals, proactively filter for higher-rated products

## Talking about sustainability

When sustainability is relevant:
- Mention the rating prominently
- List specific criteria the product meets
- Compare sustainability across options if presenting multiple products
