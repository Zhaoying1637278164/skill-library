---
name: pricing
description: "Calculate and explain branded merchandise pricing including unit costs, decoration costs, and selling prices at different quantities. Use when the user asks to \"price this\", \"how much would it cost\", \"get a quote\", \"pricing breakdown\", or \"compare prices at different quantities\".\n"
---

# Pricing

Use the `get_pricing` tool to calculate detailed pricing breakdowns.

## How pricing works

- **Trade price** is what we pay the supplier per unit. It decreases at higher quantities (tiered pricing).
- **Print/decoration cost** is the per-unit cost for branding (pad print, screen print, laser engraving, embroidery, etc.). Also tiered.
- **Setup cost** is a one-off charge for creating the printing plate/screen. Typically £20-£50.
- **Selling price** = (trade price + print cost) / (1 - margin%). Default margin is 40%.

## Presenting pricing

Always quote **selling prices** to clients unless they specifically ask for trade/cost prices.

When showing pricing, include:
- Per-unit selling price at the requested quantity
- A comparison table at common quantities (50, 100, 250, 500, 1000)
- Setup cost
- Print technique (pad print, screen print, laser engraving, etc.)
- Total order cost estimate (quantity x unit price + setup)

## Quantity guidance

- **Under 50 units**: Prices are significantly higher per unit
- **100-250 units**: Sweet spot for most orders
- **500+ units**: Best per-unit rates, worth mentioning savings vs. smaller quantities
