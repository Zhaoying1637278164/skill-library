# Merch — Claude Cowork Plugin

Search and discover branded merchandise from Social Supermarket's catalog of 8,000+ products across multiple ethical suppliers.

## What it does

- **Search products** by keyword, category, color, budget, and sustainability rating
- **Get product details** including variants, decoration methods, and gallery images
- **Calculate pricing** at any quantity with margin and decoration costs
- **Browse categories** to discover what's available

## Commands

- `/merch:search <query>` — Search for products (e.g. `/merch:search eco water bottles under £5`)
- `/merch:pricing <product-code> [quantity]` — Get pricing breakdown (e.g. `/merch:pricing P100582 250`)
- `/merch:browse` — Browse available categories and brands

## Setup

No configuration needed — just install the plugin and start searching.

## About

Built by [Social Supermarket](https://www.socialsupermarket.org) — branded merchandise with purpose.
