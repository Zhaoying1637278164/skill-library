---
description: Browse available product categories and brands
---

Fetch the catalog overview using the `get_categories` tool.

Present a summary of:
- Total products available
- Top categories with product counts
- Price range
- Available brands (top 10)
- Available colors

Help the user narrow their search based on what's available.
