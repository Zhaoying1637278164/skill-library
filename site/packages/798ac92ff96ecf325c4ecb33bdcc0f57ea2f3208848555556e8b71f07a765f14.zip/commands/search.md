---
description: Search for branded merchandise products
argument-hint: <search query>
---

Search for branded merchandise matching "$ARGUMENTS" using the `search_products` tool.

If the query mentions a budget or price, extract it as a maxPrice filter.
If the query mentions sustainability or eco-friendly, add sustainabilityRating=A or B.
If the query mentions specific colors, add them as a colors filter.

Present 3-5 products as a curated shortlist with images, prices, and key details.
