---
description: Get pricing breakdown for a product
argument-hint: <product-code> [quantity]
---

Get pricing for product $1 at quantity $2 (default 250) using the `get_pricing` tool.

Present:
1. Per-unit selling price at the requested quantity
2. Pricing comparison table at 50, 100, 250, 500, and 1000 units
3. Setup cost and print technique
4. Total order cost estimate
