#!/usr/bin/env node
// heavy-usage unit tests — plain Node, no framework. Run: node tests/run.js
// Reports every failure and exits non-zero if any failed. Uses a throwaway
// CLAUDE_CONFIG_DIR (which relocates the state dir) so no real state is touched.

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

// Isolate state BEFORE requiring modules that resolve paths lazily (they read
// process.env on each call). stateDir() = claudeDir()/heavy-usage, and
// claudeDir() honors CLAUDE_CONFIG_DIR — so pointing that at a temp dir isolates
// all state under <TMP>/heavy-usage without touching the real ~/.claude.
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'heavy-usage-test-'));
process.env.CLAUDE_CONFIG_DIR = TMP;
delete process.env.CLAUDE_PLUGIN_DATA;

const lib = require('../scripts/usage-lib');
const meter = require('../scripts/usage-meter');
const sl = require('../scripts/usage-statusline');
const session = require('../scripts/usage-session-check');

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; }
  catch (e) { console.error(`✗ ${name}\n  ${e.message}`); process.exitCode = 1; }
}

const TH = { warn: 0.70, windDown: 0.85 };

// --- usage-lib --------------------------------------------------------------

test('statusWord bands', () => {
  assert.equal(lib.statusWord(null, TH), 'NO DATA');
  assert.equal(lib.statusWord(0.50, TH), 'OK');
  assert.equal(lib.statusWord(0.72, TH), 'WARN');
  assert.equal(lib.statusWord(0.90, TH), 'WIND DOWN');
  assert.equal(lib.statusWord(1.00, TH), 'AT LIMIT');
});

test('untilStr formatting', () => {
  const now = 1_000_000;
  assert.equal(lib.untilStr(now - 10, now), 'now');
  assert.equal(lib.untilStr(now + 1800, now), '30m');
  assert.equal(lib.untilStr(now + 5400, now), '1h 30m');
  assert.equal(lib.untilStr(null, now), '?');
});

test('bar is 20 cells + fills proportionally', () => {
  assert.equal(lib.bar(0).replace(/[^█░]/g, '').length, 20);
  assert.ok(lib.bar(0).startsWith('░'));
  assert.ok(lib.bar(1).startsWith('█'.repeat(20)));
  assert.equal((lib.bar(0.5).match(/█/g) || []).length, 10);
});

// --- pace -------------------------------------------------------------------

test('elapsedFrac: 0 at window start, ~0.5 mid, clamps to [0,1]', () => {
  const now = 1_000_000;
  const W = lib.WINDOW_SEC.five;
  assert.equal(lib.elapsedFrac(now + W, now, W), 0);          // just reset
  assert.equal(lib.elapsedFrac(now + W / 2, now, W), 0.5);    // halfway
  assert.equal(lib.elapsedFrac(now, now, W), 1);              // resets now
  assert.equal(lib.elapsedFrac(now - 100, now, W), 1);        // past -> clamp 1
  assert.equal(lib.elapsedFrac(now + 2 * W, now, W), 0);      // before -> clamp 0
  assert.equal(lib.elapsedFrac(null, now, W), null);
});

test('paceDelta: used minus linear expectation, signed', () => {
  const now = 1_000_000;
  const W = lib.WINDOW_SEC.five;
  const mid = now + W / 2; // 50% elapsed
  assert.equal(lib.paceDelta(60, mid, now, W), 10);   // ahead
  assert.equal(lib.paceDelta(40, mid, now, W), -10);  // behind
  assert.equal(lib.paceDelta(50, mid, now, W), 0);    // exact
  assert.equal(lib.paceDelta(50, null, now, W), null);
});

test('paceTag: band edges + word/mag strings + null without resets_at', () => {
  const now = 1_000_000;
  const W = lib.WINDOW_SEC.five;
  const mid = now + W / 2; // 50% elapsed
  // within ±10 inclusive -> on track
  assert.deepEqual(lib.paceTag(60, mid, now, W, 10), { state: 'ontrack', word: '', mag: '±10%' });
  assert.deepEqual(lib.paceTag(50, mid, now, W, 10), { state: 'ontrack', word: '', mag: '±0%' });
  // just past the band
  assert.deepEqual(lib.paceTag(61, mid, now, W, 10), { state: 'ahead', word: 'early', mag: '+11%' });
  assert.deepEqual(lib.paceTag(39, mid, now, W, 10), { state: 'behind', word: "won't reach", mag: '-11%' });
  assert.equal(lib.paceTag(50, null, now, W, 10), null);
});

test('sanitizePaceBand keeps valid, falls back on junk', () => {
  assert.equal(lib.sanitizePaceBand(15), 15);
  assert.equal(lib.sanitizePaceBand(100), 100);
  assert.equal(lib.sanitizePaceBand(0), 10);     // <=0 -> default
  assert.equal(lib.sanitizePaceBand(150), 10);   // >100 -> default
  assert.equal(lib.sanitizePaceBand(NaN), 10);
  assert.equal(lib.sanitizePaceBand('x'), 10);
  assert.equal(lib.sanitizePaceBand(undefined), 10);
});

test('readState returns defaults when no file', () => {
  const s = lib.readState();
  assert.equal(s.enabled, true);
  assert.equal(s.thresholds.warn, 0.75);
  assert.equal(s.thresholds.windDown, 0.90);
  assert.equal(s.paceBandPp, 10);
  assert.equal(s.innerStatusline, null);
});

test('writeState/readState round-trip + merges new keys', () => {
  const s = lib.readState();
  s.thresholds.windDown = 0.9;
  s.innerStatusline = 'printf X';
  lib.writeState(s);
  const back = lib.readState();
  assert.equal(back.thresholds.windDown, 0.9);
  assert.equal(back.innerStatusline, 'printf X');
  assert.equal(back.thresholds.warn, 0.75); // default preserved
});

test('atomic write leaves no tmp file', () => {
  lib.writeState(lib.readState());
  const leftovers = fs.readdirSync(TMP).filter(f => f.includes('.tmp'));
  assert.deepEqual(leftovers, []);
});

test('readLive null when absent, round-trips when written', () => {
  fs.rmSync(lib.livePath(), { force: true });
  assert.equal(lib.readLive(), null);
  lib.writeLive({ version: 1, capturedAt: 123, five_hour: { used_percentage: 5, resets_at: 9 }, seven_day: null });
  assert.equal(lib.readLive().five_hour.used_percentage, 5);
});

// --- usage-meter ------------------------------------------------------------

test('worst picks higher window', () => {
  const live = { five_hour: { used_percentage: 30 }, seven_day: { used_percentage: 80 } };
  const w = meter.worst(live);
  assert.equal(w.which, 'weekly');
  assert.equal(w.frac, 0.80);
});

test('worst picks 5-hour when higher', () => {
  const w = meter.worst({ five_hour: { used_percentage: 95 }, seven_day: { used_percentage: 10 } });
  assert.equal(w.which, '5-hour');
});

test('worst null when no data', () => {
  assert.equal(meter.worst(null), null);
  assert.equal(meter.worst({ five_hour: null, seven_day: null }), null);
});

test('formatHook silent when disabled', () => {
  const live = { five_hour: { used_percentage: 99, resets_at: 9 }, seven_day: null };
  assert.equal(meter.formatHook(live, { enabled: false, thresholds: TH }), '');
});

test('formatHook silent below warn', () => {
  const live = { five_hour: { used_percentage: 50, resets_at: 9 }, seven_day: null };
  assert.equal(meter.formatHook(live, { enabled: true, thresholds: TH }), '');
});

test('formatHook WARN band = status-only FYI, no behavioral steer', () => {
  const live = { five_hour: { used_percentage: 75, resets_at: Math.floor(Date.now()/1000)+60 }, seven_day: null };
  const out = meter.formatHook(live, { enabled: true, thresholds: TH });
  assert.ok(out.includes('FYI'), out);
  assert.ok(out.includes('🔋'), out);
  assert.ok(out.includes('75%'), out);
  // must not nudge work habits
  assert.ok(!/smaller steps|commit (more|frequently|often)|stop/i.test(out), out);
});

test('formatHook WIND DOWN band', () => {
  const live = { five_hour: { used_percentage: 90, resets_at: Math.floor(Date.now()/1000)+60 }, seven_day: null };
  const out = meter.formatHook(live, { enabled: true, thresholds: TH });
  assert.ok(out.startsWith('[heavy-usage] WIND DOWN'), out);
  assert.ok(out.includes('stop the loop') || out.includes('end'));
});

test('formatHook null live -> silent', () => {
  assert.equal(meter.formatHook(null, { enabled: true, thresholds: TH }), '');
});

test('ageStr', () => {
  assert.equal(meter.ageStr(Date.now()), 'just now');
  assert.equal(meter.ageStr(Date.now() - 5*60*1000), '5m ago');
  assert.equal(meter.ageStr(0), '');
});

// --- usage-statusline -------------------------------------------------------

test('captureRateLimits writes live + returns true', () => {
  fs.rmSync(lib.livePath(), { force: true });
  const ok = sl.captureRateLimits({ rate_limits: {
    five_hour: { used_percentage: 23.5, resets_at: 111 },
    seven_day: { used_percentage: 41.2, resets_at: 222 },
  }}, 999);
  assert.equal(ok, true);
  const live = lib.readLive();
  assert.equal(live.five_hour.used_percentage, 23.5);
  assert.equal(live.seven_day.resets_at, 222);
  assert.equal(live.capturedAt, 999);
});

test('captureRateLimits false when no rate_limits', () => {
  assert.equal(sl.captureRateLimits({}, 1), false);
  assert.equal(sl.captureRateLimits({ rate_limits: {} }, 1), false);
});

test('segment renders 5h/7d, empty without rate_limits', () => {
  const seg = sl.segment({ rate_limits: { five_hour: { used_percentage: 24 }, seven_day: { used_percentage: 41 } } }, { thresholds: TH });
  assert.ok(seg.includes('5h 24%'));
  assert.ok(seg.includes('7d 41%'));
  assert.equal(sl.segment({}, { thresholds: TH }), '');
});

test('segment renders pace tag: early / won\'t reach / on-track', () => {
  const now = Math.floor(Date.now() / 1000);
  const W = lib.WINDOW_SEC.five;
  const st = { thresholds: TH, paceBandPp: 10 };
  const mid = now + Math.floor(W / 2); // 50% elapsed
  // used 62 vs ~50 elapsed -> ahead
  assert.ok(sl.segment({ rate_limits: { five_hour: { used_percentage: 62, resets_at: mid } } }, st).includes('early'));
  // used 12 vs ~50 -> behind
  assert.ok(sl.segment({ rate_limits: { five_hour: { used_percentage: 12, resets_at: mid } } }, st).includes("won't reach"));
  // used 50 vs ~50 -> on track (± marker)
  assert.ok(sl.segment({ rate_limits: { five_hour: { used_percentage: 50, resets_at: mid } } }, st).includes('±'));
  // no resets_at -> no pace, no crash
  const np = sl.segment({ rate_limits: { five_hour: { used_percentage: 50 } } }, st);
  assert.ok(np.includes('5h 50%') && !np.includes('±') && !np.includes('early'));
});

test('chainInner empty when no inner command', () => {
  assert.equal(sl.chainInner({ innerStatusline: null }, '{}'), '');
});

// --- threshold input validation (the silent-NaN guard) ---------------------

test('getFlag returns value, null on missing value or flag-as-value', () => {
  assert.equal(meter.getFlag(['--warn', '0.7'], '--warn'), '0.7');
  assert.equal(meter.getFlag(['--warn'], '--warn'), null);                    // missing value
  assert.equal(meter.getFlag(['--warn', '--winddown', '0.85'], '--warn'), null); // next flag
  assert.equal(meter.getFlag(['x'], '--warn'), null);                         // absent
});

test('thresholdsOk rejects NaN / out-of-range / inverted / equal', () => {
  assert.equal(meter.thresholdsOk(0.7, 0.85), true);
  assert.equal(meter.thresholdsOk(NaN, 0.85), false);
  assert.equal(meter.thresholdsOk(0.7, NaN), false);
  assert.equal(meter.thresholdsOk(-0.1, 0.85), false);
  assert.equal(meter.thresholdsOk(0.7, 1.5), false);
  assert.equal(meter.thresholdsOk(0.9, 0.7), false);  // inverted
  assert.equal(meter.thresholdsOk(0.5, 0.5), false);  // equal
});

const DEF = { warn: 0.75, windDown: 0.90, weeklyWarn: 0.85, weeklyWindDown: 0.95 };

test('sanitizeThresholds keeps valid, replaces invalid, fills weekly', () => {
  // old/partial object (no weekly fields) -> weekly defaults applied
  assert.deepEqual(lib.sanitizeThresholds({ warn: 0.6, windDown: 0.8 }),
    { warn: 0.6, windDown: 0.8, weeklyWarn: 0.85, weeklyWindDown: 0.95 });
  // full custom object preserved
  assert.deepEqual(lib.sanitizeThresholds({ warn: 0.6, windDown: 0.8, weeklyWarn: 0.7, weeklyWindDown: 0.9 }),
    { warn: 0.6, windDown: 0.8, weeklyWarn: 0.7, weeklyWindDown: 0.9 });
  // each window's bad pair falls back independently
  assert.deepEqual(lib.sanitizeThresholds({ warn: 0.9, windDown: 0.7, weeklyWarn: 0.7, weeklyWindDown: 0.9 }),
    { warn: 0.75, windDown: 0.90, weeklyWarn: 0.7, weeklyWindDown: 0.9 });
  assert.deepEqual(lib.sanitizeThresholds({ warn: 0.6, windDown: 0.8, weeklyWarn: 0.95, weeklyWindDown: 0.7 }),
    { warn: 0.6, windDown: 0.8, weeklyWarn: 0.85, weeklyWindDown: 0.95 });
  assert.deepEqual(lib.sanitizeThresholds({ warn: 'x', windDown: 2 }), DEF);
  assert.deepEqual(lib.sanitizeThresholds(null), DEF);
});

test('thFor resolves per-window pair, falls back to 5h when weekly absent', () => {
  assert.deepEqual(lib.thFor(DEF, false), { warn: 0.75, windDown: 0.90 });
  assert.deepEqual(lib.thFor(DEF, true), { warn: 0.85, windDown: 0.95 });
  // partial object: weekly falls back to the 5h pair
  assert.deepEqual(lib.thFor({ warn: 0.6, windDown: 0.8 }, true), { warn: 0.6, windDown: 0.8 });
});

test('formatHook applies separate weekly thresholds', () => {
  const soon = Math.floor(Date.now()/1000)+60;
  // weekly at 88% with weekly warn 85/wd 95 -> WARN band (5h quiet at 50%)
  const out = meter.formatHook(
    { five_hour: { used_percentage: 50, resets_at: soon }, seven_day: { used_percentage: 88, resets_at: soon } },
    { enabled: true, thresholds: DEF });
  assert.ok(out.includes('FYI') && out.includes('weekly') && out.includes('88%'), out);
  // weekly at 96% -> WIND DOWN
  const out2 = meter.formatHook(
    { five_hour: { used_percentage: 50, resets_at: soon }, seven_day: { used_percentage: 96, resets_at: soon } },
    { enabled: true, thresholds: DEF });
  assert.ok(out2.startsWith('[heavy-usage] WIND DOWN') && out2.includes('weekly'), out2);
  // weekly at 88% would be WIND DOWN under the OLD shared 90 wd? no — proves separation:
  // 5h at 88% (5h wd 90) is only WARN, weekly at 88% (weekly wd 95) is only WARN too.
  const out3 = meter.formatHook(
    { five_hour: { used_percentage: 92, resets_at: soon }, seven_day: { used_percentage: 88, resets_at: soon } },
    { enabled: true, thresholds: DEF });
  assert.ok(out3.startsWith('[heavy-usage] WIND DOWN') && out3.includes('5-hour'), out3); // 5h wins
});

test('readState sanitizes a corrupt thresholds object on disk', () => {
  lib.atomicWriteJson(lib.statePath(), { version: 1, enabled: true, thresholds: { warn: 'x', windDown: 2 }, innerStatusline: null });
  const s = lib.readState();
  assert.equal(s.thresholds.warn, 0.75);
  assert.equal(s.thresholds.windDown, 0.90);
});

test('thresholds CLI rejects bad input, exits non-zero, leaves state unchanged', () => {
  const { spawnSync } = require('child_process');
  const before = lib.readState();
  before.thresholds = { warn: 0.6, windDown: 0.8 };
  lib.writeState(before);
  const run = (extra) => spawnSync(process.execPath,
    [path.join(__dirname, '..', 'scripts', 'usage-meter.js'), 'thresholds', ...extra],
    { env: { ...process.env, CLAUDE_CONFIG_DIR: TMP }, encoding: 'utf8' });
  assert.equal(run(['--warn', '0.9', '--winddown', '0.7']).status, 1); // inverted
  assert.equal(run(['--warn', 'foo']).status, 1);                      // NaN
  assert.equal(run(['--warn']).status, 1);                             // missing value
  const after = lib.readState();
  assert.equal(after.thresholds.warn, 0.6);   // unchanged by the rejected calls
  assert.equal(after.thresholds.windDown, 0.8);
  assert.equal(run(['--warn', '0.5', '--winddown', '0.9']).status, 0); // valid
  assert.equal(lib.readState().thresholds.warn, 0.5);
});

test('thresholds CLI sets weekly pair independently, validates it', () => {
  const { spawnSync } = require('child_process');
  const before = lib.readState();
  before.thresholds = { warn: 0.6, windDown: 0.8, weeklyWarn: 0.85, weeklyWindDown: 0.95 };
  lib.writeState(before);
  const run = (extra) => spawnSync(process.execPath,
    [path.join(__dirname, '..', 'scripts', 'usage-meter.js'), 'thresholds', ...extra],
    { env: { ...process.env, CLAUDE_CONFIG_DIR: TMP }, encoding: 'utf8' });
  // inverted weekly pair rejected, state unchanged
  assert.equal(run(['--weekly-warn', '0.95', '--weekly-winddown', '0.85']).status, 1);
  assert.equal(lib.readState().thresholds.weeklyWarn, 0.85);
  // valid weekly update, 5h left alone
  assert.equal(run(['--weekly-warn', '0.8', '--weekly-winddown', '0.92']).status, 0);
  const s = lib.readState();
  assert.equal(s.thresholds.weeklyWarn, 0.8);
  assert.equal(s.thresholds.weeklyWindDown, 0.92);
  assert.equal(s.thresholds.warn, 0.6);   // untouched
  assert.equal(s.thresholds.windDown, 0.8);
});

test('thresholds CLI sets pace band, rejects bad value, leaves state unchanged', () => {
  const { spawnSync } = require('child_process');
  const before = lib.readState();
  before.thresholds = { warn: 0.6, windDown: 0.8, weeklyWarn: 0.85, weeklyWindDown: 0.95 };
  before.paceBandPp = 10;
  lib.writeState(before);
  const run = (extra) => spawnSync(process.execPath,
    [path.join(__dirname, '..', 'scripts', 'usage-meter.js'), 'thresholds', ...extra],
    { env: { ...process.env, CLAUDE_CONFIG_DIR: TMP }, encoding: 'utf8' });
  // bad pace band rejected, state unchanged
  assert.equal(run(['--pace-band', '0']).status, 1);
  assert.equal(run(['--pace-band', '150']).status, 1);
  assert.equal(run(['--pace-band', 'foo']).status, 1);
  assert.equal(run(['--pace-band']).status, 1);
  assert.equal(lib.readState().paceBandPp, 10);
  // valid update, thresholds left alone
  assert.equal(run(['--pace-band', '15']).status, 0);
  const s = lib.readState();
  assert.equal(s.paceBandPp, 15);
  assert.equal(s.thresholds.warn, 0.6);
});

// --- formatting on partial / missing data -----------------------------------

test('formatHuman renders with data and reports no-data', () => {
  const th = { warn: 0.70, windDown: 0.85 };
  const now = Math.floor(Date.now() / 1000);
  const out = meter.formatHuman(
    { five_hour: { used_percentage: 24, resets_at: now + 3600 }, seven_day: { used_percentage: 41, resets_at: now + 7200 }, capturedAt: Date.now() },
    { thresholds: th, enabled: true });
  assert.ok(out.includes('24%') && out.includes('5-hour'), out);
  // absolute reset clock shown next to the relative countdown
  assert.match(out, /resets in .+ \(\d\d:\d\d\)/);
  // pace tag shown on the resets line
  assert.match(out, /· pace .+\((early|won't reach|on track)\)/);
  assert.ok(meter.formatHuman(null, { thresholds: th, enabled: true }).includes('No usage data yet'));
});

test('clockStr formats local HH:MM, empty without value', () => {
  assert.equal(lib.clockStr(0), '');
  assert.equal(lib.clockStr(null), '');
  assert.match(lib.clockStr(1780203000), /^\d\d:\d\d$/);
});

test('segment appends reset countdown only when a window is hot', () => {
  const now = Math.floor(Date.now() / 1000);
  const cool = sl.segment({ rate_limits: { five_hour: { used_percentage: 40, resets_at: now + 3600 } } }, { thresholds: TH });
  assert.ok(!cool.includes('1h 0m'), cool); // below warn -> no countdown
  const hot = sl.segment({ rate_limits: { five_hour: { used_percentage: 95, resets_at: now + 3600 } } }, { thresholds: TH });
  assert.ok(hot.includes('1h 0m'), hot);    // wind-down -> countdown appended
});

test('formatHook tolerates missing resets_at', () => {
  const out = meter.formatHook({ five_hour: { used_percentage: 90 }, seven_day: null }, { enabled: true, thresholds: TH });
  assert.ok(out.startsWith('[heavy-usage] WIND DOWN'), out);
  assert.ok(out.includes('resets in ?'), out);
});

test('segment tolerates a missing window', () => {
  const seg = sl.segment({ rate_limits: { five_hour: { used_percentage: 50 }, seven_day: null } }, { thresholds: TH });
  assert.ok(seg.includes('5h 50%'));
  assert.ok(!seg.includes('7d'));
});

// --- usage-session-check ----------------------------------------------------

test('isWired detects our capturer (object + string forms)', () => {
  assert.equal(session.isWired(null), false);
  assert.equal(session.isWired({}), false);
  assert.equal(session.isWired({ statusLine: { command: 'bash caveman-statusline.sh' } }), false);
  assert.equal(session.isWired({ statusLine: { command: 'node "/x/scripts/usage-statusline.js"' } }), true);
  assert.equal(session.isWired({ statusLine: 'node /x/usage-statusline.js' }), true);
});

test('wiredStatuslinePath extracts the capturer path (quoted + bare)', () => {
  assert.equal(session.wiredStatuslinePath('node "C:/x/scripts/usage-statusline.js"'), 'C:/x/scripts/usage-statusline.js');
  assert.equal(session.wiredStatuslinePath('node /home/u/usage-statusline.js'), '/home/u/usage-statusline.js');
  assert.equal(session.wiredStatuslinePath('bash other.sh'), null);
  assert.equal(session.wiredStatuslinePath(null), null);
});

// --- stale guard + pace projection ------------------------------------------

test('sanitizeStaleMins clamps to (0,1440] else default', () => {
  assert.equal(lib.sanitizeStaleMins(15), 15);
  assert.equal(lib.sanitizeStaleMins(1440), 1440);
  assert.equal(lib.sanitizeStaleMins(0), lib.STATE_DEFAULTS.staleMins);
  assert.equal(lib.sanitizeStaleMins(-5), lib.STATE_DEFAULTS.staleMins);
  assert.equal(lib.sanitizeStaleMins(5000), lib.STATE_DEFAULTS.staleMins);
  assert.equal(lib.sanitizeStaleMins(NaN), lib.STATE_DEFAULTS.staleMins);
});

test('paceProjection extrapolates end% and 100% ETA', () => {
  const now = 1_000_000;
  const win = lib.WINDOW_SEC.five;            // 5h = 18000s
  // half the window elapsed, 60% used -> projects ~120%, hits 100% before reset
  const resets = now + win / 2;
  const p = lib.paceProjection(60, resets, now, win);
  assert.equal(p.endPct, 120);
  assert.ok(p.hitsInSec > 0 && now + p.hitsInSec < resets);
  // behind pace: 20% used at half window -> projects ~40%, never hits 100%
  const p2 = lib.paceProjection(20, resets, now, win);
  assert.equal(p2.endPct, 40);
  assert.equal(p2.hitsInSec, null);
  // too early to extrapolate (<2% elapsed) -> null
  assert.equal(lib.paceProjection(50, now + win * 0.99, now, win), null);
  // no resets_at -> null
  assert.equal(lib.paceProjection(50, null, now, win), null);
});

test('formatHook annotates stale numbers but never suppresses wind-down', () => {
  const st = { enabled: true, thresholds: lib.STATE_DEFAULTS.thresholds, staleMins: 15 };
  const old = Date.now() - 30 * 60 * 1000;    // captured 30m ago, stale window 15m
  const live = { capturedAt: old, five_hour: { used_percentage: 95, resets_at: Math.floor(Date.now() / 1000) + 600 }, seven_day: null };
  const out = meter.formatHook(live, st);
  assert.ok(out.includes('WIND DOWN'), 'still winds down on stale data');
  assert.ok(/old/.test(out), 'annotates staleness');
  // fresh numbers -> no stale note
  const fresh = { ...live, capturedAt: Date.now() };
  assert.ok(!/old/.test(meter.formatHook(fresh, st)), 'no stale note when fresh');
});

// --- sweep-state engine -----------------------------------------------------

const sweep = require('../scripts/sweep-state');

// Isolate sweep state under a temp "repo root" so tests never touch the real repo.
const SWEEP_ROOT = fs.mkdtempSync(path.join(os.tmpdir(), 'hu-sweep-'));
process.env.HEAVY_USAGE_SWEEP_ROOT = SWEEP_ROOT;

test('decideTier scales fan-out with headroom', () => {
  const th = { windDown: 0.90, weeklyWindDown: 0.95 };
  // wide headroom (5h 90-20=70pp) -> multiple scouts
  const wide = sweep.decideTier({ five_hour: { used_percentage: 20 }, seven_day: null, thresholds: th });
  assert.ok(wide.fanout >= 2, `expected >=2, got ${wide.fanout}`);
  // mid (~18pp) -> 1 scout
  const mid = sweep.decideTier({ five_hour: { used_percentage: 72 }, seven_day: null, thresholds: th });
  assert.equal(mid.fanout, 1);
  // tight (<10pp) -> inline, no subagents
  const tight = sweep.decideTier({ five_hour: { used_percentage: 85 }, seven_day: null, thresholds: th });
  assert.equal(tight.fanout, 0);
  // worst window wins: weekly close to its wind-down dominates
  const weekly = sweep.decideTier({ five_hour: { used_percentage: 10 }, seven_day: { used_percentage: 94 }, thresholds: th });
  assert.equal(weekly.fanout, 0);
  // no data -> conservative inline
  assert.equal(sweep.decideTier({ thresholds: th }).fanout, 0);
});

test('decideTier drops a tier when stale', () => {
  const th = { windDown: 0.90, weeklyWindDown: 0.95 };
  const fresh = sweep.decideTier({ five_hour: { used_percentage: 20 }, thresholds: th, stale: false });
  const stale = sweep.decideTier({ five_hour: { used_percentage: 20 }, thresholds: th, stale: true });
  assert.ok(stale.fanout < fresh.fanout, `stale ${stale.fanout} should be < fresh ${fresh.fanout}`);
  assert.ok(/stale/.test(stale.reason));
});

test('globToRe matches ** and * correctly', () => {
  assert.ok(sweep.anyMatch(['src/**'], 'src/a/b.js'));
  assert.ok(sweep.anyMatch(['*.test.js'], 'foo.test.js'));
  assert.ok(!sweep.anyMatch(['*.test.js'], 'foo.js'));
  assert.ok(!sweep.anyMatch(['src/*'], 'src/a/b.js')); // single * does not cross /
});

test('config round-trips and hasConfig gates prompting', () => {
  assert.equal(sweep.hasConfig('bugs'), false);
  sweep.saveConfig('bugs', { focus: ['scripts/**'], severityFloor: 'medium' });
  assert.equal(sweep.hasConfig('bugs'), true);
  assert.deepEqual(sweep.loadConfig().bugs.focus, ['scripts/**']);
  assert.equal(sweep.hasConfig('review'), false); // independent per mode
});

test('nextSlice advances cursor and bumps depth on wrap', () => {
  // Seed an index directly (no git needed in the temp root).
  fs.mkdirSync(sweep.stateDir(), { recursive: true });
  fs.writeFileSync(path.join(sweep.stateDir(), 'index.json'),
    JSON.stringify({ files: ['a.js', 'b.js', 'c.js'], cursor: 0, depth: 0 }));
  assert.deepEqual(sweep.nextSlice(2).slice, ['a.js', 'b.js']);
  const s2 = sweep.nextSlice(2);
  assert.deepEqual(s2.slice, ['c.js']);
  assert.equal(s2.cursor, 3);
  const s3 = sweep.nextSlice(2);      // wrapped: depth bumps, restart
  assert.equal(s3.depth, 1);
  assert.deepEqual(s3.slice, ['a.js', 'b.js']);
});

test('recordFindings dedupes by file+line+claim', () => {
  const r1 = sweep.recordFindings('bugs', [
    { file: 'x.js', line: 10, claim: 'off-by-one', severity: 'high' },
    { file: 'y.js', line: 3, claim: 'null deref' },
  ], 't1');
  assert.equal(r1.added, 2);
  const r2 = sweep.recordFindings('bugs', [
    { file: 'x.js', line: 10, claim: 'off-by-one' }, // dup
    { file: 'z.js', line: 1, claim: 'new one' },
  ], 't2');
  assert.equal(r2.added, 1);
  assert.equal(r2.skipped, 1);
  assert.ok(fs.readFileSync(sweep.docFor('bugs'), 'utf8').includes('off-by-one'));
});

fs.rmSync(SWEEP_ROOT, { recursive: true, force: true });

// --- version sync -----------------------------------------------------------

test('version is in sync across all manifests + CHANGELOG', () => {
  const { sources, ref, mismatches } = require('../scripts/check-version-sync').collect();
  assert.ok(ref, 'package.json version missing');
  assert.deepEqual(mismatches, [], `version mismatch: ${JSON.stringify(sources)}`);
});

test('checkTag matches stripped tag and flags mismatch', () => {
  const { checkTag } = require('../scripts/check-version-sync');
  assert.equal(checkTag('1.2.3', 'v1.2.3'), null);
  assert.equal(checkTag('1.2.3', '1.2.3'), null);
  assert.ok(checkTag('1.2.3', 'v9.9.9'));
});

// --- summary ----------------------------------------------------------------

fs.rmSync(TMP, { recursive: true, force: true });
if (process.exitCode) {
  console.error(`\n${passed} passed, some FAILED.`);
} else {
  console.log(`✓ all ${passed} tests passed`);
}
