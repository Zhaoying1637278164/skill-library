# ToolJet theme API

Use `manage_theme` to manage workspace theme objects. The available actions are `list`, `create`, `set_default`,
`update_definition`, `rename`, and `delete`. Theme deletion requires `confirm:true` after the user approves the
exact theme. ToolJet still enforces the active workspace, permissions, validation, and license gates.

Creating a workspace theme does not apply it to an app. After creating or selecting a theme, call
`update_app_settings({ app_id, version_id, theme_id })` to apply it to that app's current editing version.

## Theme definition

A theme definition uses literal values and follows this structure:

```text
brand.colors
  primary:   { light, dark }
  secondary: { light, dark }  # optional
  tertiary:  { light, dark }  # optional

text
  font
  colors.primary:     { light, dark }
  colors.placeholder: { light, dark }  # optional
  colors.disabled:    { light, dark }  # optional

border
  radius: { default, small, large }
  colors.default:  { light, dark }
  colors.weak:     { light, dark }  # optional
  colors.disabled: { light, dark }  # optional

systemStatus.colors
  success: { light, dark }
  error:   { light, dark }  # optional
  warning: { light, dark }  # optional

surface.colors
  appBackground: { light, dark }
  surface1:      { light, dark }
  surface2:      { light, dark }
  surface3:      { light, dark }
```

Theme colors are normally hex values. The saved definition generates ToolJet's semantic `--cc-*` variables at
runtime; do not put CSS variable references inside the theme definition itself.

## The standard theme (applied by default)

`create_app` applies the skill's standard theme, **"ToolJet Modern"**, to every new app unless told otherwise. It is
created once per workspace (matched by name, from `data/default-theme.json`) and is never set as the workspace
default, so hand-built apps are unaffected. The result of `create_app` reports `theme.mode` and any `theme.warning`;
if the theme could not be created (for example a licence gate on custom themes) the app is on the workspace default
and the handoff should say so.

- Pass `create_app({ theme: "workspace_default" })` when the user wants the workspace default, or an existing theme
  name/id to reuse one, or `theme: { name, definition }` to create (once, by name) and apply a derived theme.
- Never call `set_default`, rename, or delete a theme unless the user asks for exactly that.

## When theming applies

Theme selection must preserve user intent; design freedom is not permission to replace an existing or selected theme.

- **New app** (you call `create_app`, or a host hands you an empty shell with a single blank page): first inspect the current/selected theme and any supplied design system. Preserve a chosen theme, including on
  an empty shell. Only when no theme was selected should you derive or use the fallback below. For an unthemed
  shell, create/reuse the resolved theme with `manage_theme` and apply it with `update_app_settings` before the first phase.
- **Design request on an existing app** (the message is about theme, colours, palette, branding, fonts, corner
  radius, "make it look like a spa", "match our brand"): change the theme and styling as asked, and nothing else.
- **Any other change to an existing app** (pages, components, queries, data, behaviour, text, defects): do not
  create, change or apply a theme, do not touch app settings, and style what you add to match what is already
  there. The app's current theme is the user's decision, not yours.

**Licence gate.** Custom themes are a licensed feature. When `manage_theme` create returns `licensed: false`
(the instance answered HTTP 451), the app stays on the workspace default theme: do not retry under another name
or guess a theme id, build on the default, and repeat the result's `user_message` to the user in the closing
handoff so they know their plan does not include custom themes and that upgrading enables them.

## Resolve the design source before creating or styling the app

Use this precedence:
1. Explicit user requirements and a supplied design system.
2. The app's existing or explicitly selected ToolJet theme; a requested workspace default counts as selected.
3. A recognizable brand identity, when no higher-priority choice supplies it.
4. Use case, industry, audience and working environment.
5. The polished ToolJet Modern fallback when nothing useful can be inferred.

Inspect `get_app_settings` / `list_app_themes` or `manage_theme` list as needed to resolve an existing
choice. Do not replace a selected theme because the industry suggests another colour. When requirements ask
for a branding change, apply that change at the app scope; do not mutate a shared workspace theme unexpectedly.
A theme's mere presence in the workspace is not a request to use it.

A short prompt deserves the same contemporary 2026 quality bar as a detailed one. "Beautiful", "modern" or
"premium" can steer the mood; they are not prerequisites for a well-designed product. Neither a year label
nor a fashionable effect proves good design: relevance, hierarchy, readability and complete states do.

### Derive when there is no selected design source

- **Brand:** use supplied or reliably established colours and identity. Do not invent a logo, tagline or exact
  brand hex. When uncertain, use a conservative inspired palette and describe it as such, or ask for the
  missing brand asset when exact fidelity matters.
- **Context:** infer temperature, density, typography and emphasis from the people and work. A clinic schedule,
  fleet maintenance desk and financial review tool need different information hierarchies, not just different
  button colours. Use domain conventions as clues, not fixed industry-to-colour assignments.
- **Mood/material/place:** use these as supporting cues, not literal rules that override a real brand. A name
  alone is weak evidence. Explain an important assumption briefly so the user can redirect.
- **Fallback:** use ToolJet Modern with a coherent neutral canvas, readable typography, purposeful accent,
  consistent surfaces and clear actions. Do not invent a brand to justify novelty. Blue is allowed; generic
  composition and unfinished formatting are the problems, not a particular hue.

Derive the palette rather than choosing a named preset. With no selected theme, decide what should recede
(canvas and supporting surfaces), what needs sustained reading (text and data), and what must stand out
(the next action and meaningful exceptions). Choose literal colours for those roles, then check their
contrast together. Industry is evidence about the work, not a lookup key for a colour.

For example, a hotel night-audit desk needs prolonged readability and visible reconciliation exceptions;
a guest-facing hotel booking flow needs room comparison and a clear reservation action. Neither implies
beige by default. Two tools for the same brand can preserve its palette while using different density,
surface emphasis and hierarchy. These examples explain decisions; they are not additional theme presets.

When the request offers no useful visual identity, use ToolJet Modern without inventing a brand story.
Still derive the composition from the actual task. A familiar palette or layout is appropriate when it
serves the job; do not force novelty or rotate colours simply to make successive apps look different.

### Build a coherent theme, not one recoloured button

Use `data/default-theme.json` as the theme-definition schema and fallback, not a mandatory visual starting point.
For a derived design, author related text, borders, surfaces, status colours and radii as a coherent set.
Keep repeated roles on the existing `--cc-*` tokens. Choose warm, cool or neutral surfaces deliberately.
Use `surface1` for cards and `surface2` for contextual regions—not literal white everywhere.
Preserve an existing dark theme; derive and check its actual foreground/background pairs when authoring one.

- Use the brand colour faithfully where contrast allows. For a bright brand, choose readable foregrounds or
  an accessible action shade without discarding the original identity. Soft and saturated colours can appear
  on surfaces and accents when legible; do not insist on white text for every button.
- Keep one dominant accent with deliberate secondary/semantic colours where distinctions matter. Status
  treatments must have readable labels; do not rely on colour alone or make every state the brand colour.
- Check normal text against its actual surface at 4.5:1 or better. Essential control boundaries and focus
  indicators need at least 3:1 against adjacent colours; subtle decorative dividers need not dominate.
  Check chart series and labels against their actual background, especially in dark mode.
- Use a small type scale and spacing/radius hierarchy that fits the task. Staff tools may be dense without
  being austere; customer-facing tools may be expressive without becoming marketing pages.
- The theme accent used for chart literals must be recorded in the design brief; do not invent a CSS token
  for it. Plotly needs literal theme-matched colours where CSS variables are unsupported.

Apply the resolved theme with `create_app({ name, theme: { name, definition } })`, an existing theme
name/id, or `theme: "workspace_default"` as appropriate. Do not silently omit the selected theme and let
the default replace it. Report any license/application warning honestly.

### Identity and emphasis follow the job

For a recognizable named brand, carry its distinctive visual cues into the working UI, not only the
theme definition. In the existing brief, map the chosen identity to visible roles such as an orientation
surface, section emphasis, selection treatment or primary action. Implement those roles with the resolved
tokens and reuse them across pages; layouts still follow each page's job. A branded name plus a lone
coloured button is insufficient when the defining identity is otherwise absent.

If a secondary colour is important to recognition, give it a restrained visible role rather than leaving
it unused in settings. Not every palette colour must appear, and no banner, KPI, logo or fixed surface
count is required. Preserve neutral reading areas, contrast, semantic status colours and selected-theme
precedence. Do not invent brand assets or recolour unrelated existing pages to satisfy this check.

Translate identity into hierarchy and interaction emphasis, not just a colour swap. Decide where orientation
is needed, what must be compared simultaneously, and what can wait until a record is selected. Let these
needs determine header prominence, region proportions, grouping and density; no named composition is required.
Use read-only Html when it improves comprehension, while keeping actual controls, charts and tables native.

Do not add filler statistics,
fictional trends, fabricated brand assets or unsupported workflows to make the app look finished.
Reuse visual roles across pages while allowing each page's layout to fit its job. A form may need no KPIs;
an analytical dashboard may need trends the user did not explicitly name.

The standard theme's tokens, for reference when choosing literal colours that must match it:

| Role | Light | Dark |
| --- | --- | --- |
| Primary (`--cc-primary-brand`) | `#2563EB` | `#3B82F6` |
| Text (`--cc-primary-text`) | `#111827` | `#F9FAFB` |
| Muted text (`--cc-placeholder-text`) | `#6B7280` | `#9CA3AF` |
| Border (`--cc-default-border`) / weak (`--cc-weak-border`) | `#E5E7EB` / `#F3F4F6` | `#374151` / `#1F2937` |
| App background (`--cc-appBackground-surface`) | `#F9FAFB` | `#111827` |
| Surface 1 (`--cc-surface1-surface`, cards, modals) / Surface 2 (`--cc-surface2-surface`, tinted panels) | `#FFFFFF` / `#F3F4F6` | `#1F2937` / `#111827` |
| Success / warning / error (`--cc-success-systemStatus`, `--cc-error-systemStatus`) | `#16A34A` / `#D97706` / `#DC2626` | `#4ADE80` / `#FBBF24` / `#F87171` |
| Radius default / small / large | 8 / 6 / 12 | |

The theme's `text.font` is advisory: ToolJet instances render their configured UI font regardless.

## Styling components with a selected theme

When an app has a selected theme, preserve token-backed component defaults and use existing semantic variables for
repeated visual roles. Common tokens include:

- `var(--cc-primary-brand)`
- `var(--cc-primary-text)`
- `var(--cc-placeholder-text)`
- `var(--cc-default-border)`
- `var(--cc-weak-border)`
- `var(--cc-error-systemStatus)`
- `var(--cc-appBackground-surface)`
- `var(--cc-surface1-surface)`

Pass these as raw style values, for example
`styles.backgroundColor.value = "var(--cc-surface1-surface)"`; do not wrap them in `{{...}}` and do not invent
token names. Literal hex or RGB values remain appropriate for deliberate one-off accents, chart series, or contrast
corrections when no semantic token fits. Repeated foundational colors should remain token-backed so theme and
light/dark changes continue to propagate.
