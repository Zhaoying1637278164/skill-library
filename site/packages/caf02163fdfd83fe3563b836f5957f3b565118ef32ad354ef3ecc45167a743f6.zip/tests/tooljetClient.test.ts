import { describe, it, expect, vi, beforeEach } from 'vitest';
import { PartialWriteError, createClient } from '../src/tooljetClient.js';
import type { Config } from '../src/config.js';
import type { Auth } from '../src/auth.js';

const { uuidState } = vi.hoisted(() => ({ uuidState: { n: 0 } }));
vi.mock('node:crypto', () => ({ randomUUID: () => `component-uuid-${++uuidState.n}` }));

const config: Config = {
  apiUrl: 'http://localhost:3000',
  appUrl: 'http://localhost:8082',
  email: 'a@b.com',
  password: 'pw',
};

function mockResponse(opts: { status?: number; json?: unknown; text?: string }) {
  const status = opts.status ?? 200;
  return {
    status,
    ok: status >= 200 && status < 300,
    json: async () => opts.json ?? {},
    text: async () => opts.text ?? '',
    clone: () => mockResponse(opts),
  } as unknown as Response;
}

function makeAuth(): Auth & { authedFetch: ReturnType<typeof vi.fn>; getOrganizationId: ReturnType<typeof vi.fn> } {
  return {
    authedFetch: vi.fn(),
    getOrganizationId: vi.fn().mockResolvedValue('org1'),
    getOrganizationSlug: vi.fn().mockResolvedValue('myworkspace'),
  };
}

describe('createClient', () => {
  let auth: ReturnType<typeof makeAuth>;

  beforeEach(() => {
    auth = makeAuth();
    uuidState.n = 0;
  });

  describe('workspace groups', () => {
    it('uses v2 routes and exposes membership IDs without leaking nested user data', async () => {
      const group = { id: 'group-7', name: 'Dispatch', type: 'custom' };
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ json: { groupPermissions: [group] } }))
        .mockResolvedValueOnce(mockResponse({ json: { group } }))
        .mockResolvedValueOnce(mockResponse({ json: [{ id: 'membership-9', userId: 'person-4',
          user: { email: 'dispatch@example.test', password: 'private-field' } }] }));
      const client = createClient(auth, config);
      expect(await client.listWorkspaceGroups()).toEqual([group]);
      expect(await client.getWorkspaceGroup('group-7')).toEqual(group);
      const members = await client.listWorkspaceGroupMembers('group-7');
      expect(members).toEqual([{ group_user_id: 'membership-9', user_id: 'person-4', email: 'dispatch@example.test' }]);
      expect(JSON.stringify(members)).not.toContain('private-field');
      expect(auth.authedFetch.mock.calls.map((call) => call[0])).toEqual([
        '/api/v2/group-permissions', '/api/v2/group-permissions/group-7', '/api/v2/group-permissions/group-7/users',
      ]);
    });

    it('sends only names for create/rename and deletes memberships using the membership route', async () => {
      auth.authedFetch.mockResolvedValue(mockResponse({ status: 204 }));
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201,
        json: { id: 'group-7', name: 'Dispatch' } }));
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ json: { group: { id: 'group-7', name: 'Dispatch', type: 'custom' } } }));
      const client = createClient(auth, config);
      expect(await client.createWorkspaceGroup('Dispatch')).toEqual({ id: 'group-7', name: 'Dispatch', type: 'custom' });
      await client.renameWorkspaceGroup('group-7', 'Routing');
      await client.removeWorkspaceGroupMember('membership-9');
      await client.deleteWorkspaceGroup('group-7');
      expect(auth.authedFetch.mock.calls).toEqual([
        ['/api/v2/group-permissions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"name":"Dispatch"}' }],
        ['/api/v2/group-permissions/group-7'],
        ['/api/v2/group-permissions/group-7', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: '{"name":"Routing"}' }],
        ['/api/v2/group-permissions/users/membership-9', { method: 'DELETE' }],
        ['/api/v2/group-permissions/group-7', { method: 'DELETE' }],
      ]);
    });

    it('propagates backend permission errors and rejects malformed discovery responses', async () => {
      const client = createClient(auth, config);
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 403, text: 'Denied' }));
      await expect(client.deleteWorkspaceGroup('group-7')).rejects.toThrow();
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ json: {} }));
      await expect(client.listWorkspaceGroups()).rejects.toThrow('Unexpected workspace groups');
    });
  });

  describe('createApp', () => {
    it('creates the app then fetches it to resolve version/home page, and builds the app url', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'app1' } }))
        .mockResolvedValueOnce(
          mockResponse({
            status: 200,
            json: {
              id: 'app1',
              name: 'My App',
              editing_version: { id: 'ver1', name: 'v1' },
              pages: [
                { id: 'page-other', name: 'Other', index: 1 },
                { id: 'page-home', name: 'Home', handle: 'home', index: 0 },
              ],
            },
          })
        );

      const client = createClient(auth, config);
      const result = await client.createApp('My App');

      expect(auth.authedFetch).toHaveBeenCalledTimes(2);

      const [createPath, createInit] = auth.authedFetch.mock.calls[0];
      expect(createPath).toBe('/api/apps');
      expect(createInit.method).toBe('POST');
      expect(JSON.parse(createInit.body)).toEqual({ name: 'My App', type: 'front-end' });

      const [getPath] = auth.authedFetch.mock.calls[1];
      expect(getPath).toBe('/api/apps/app1');

      expect(result).toEqual({
        app_id: 'app1',
        version_id: 'ver1',
        home_page_id: 'page-home',
        app_url: 'http://localhost:8082/myworkspace/apps/app1',
        editor_url: 'http://localhost:8082/myworkspace/apps/app1',
        viewer_url: 'http://localhost:8082/applications/app1/home?env=development&version=v1',
        datasources_url: 'http://localhost:8082/myworkspace/data-sources',
      });
    });

    it('falls back to the first page when there is no page named Home', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'app2' } }))
        .mockResolvedValueOnce(
          mockResponse({
            status: 200,
            json: {
              id: 'app2',
              editing_version: { id: 'ver2' },
              pages: [{ id: 'page-first', name: 'Not Home', index: 0 }],
            },
          })
        );

      const client = createClient(auth, config);
      const result = await client.createApp('Another App');

      expect(result.home_page_id).toBe('page-first');
    });

    it('retries a taken name with a counter instead of failing', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 409, text: '{"message":"This app name is already taken."}' }))
        .mockResolvedValueOnce(mockResponse({ status: 409, text: '{"message":"This app name is already taken."}' }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'app3' } }))
        .mockResolvedValueOnce(
          mockResponse({ status: 200, json: { id: 'app3', slug: 'app3', editing_version: { id: 'v1', name: 'v1' }, pages: [{ id: 'p1', name: 'Home' }] } })
        );

      const client = createClient(auth, config);
      const result = await client.createApp('Nordlicht Order Desk');
      expect(result.app_id).toBe('app3');
      const names = auth.authedFetch.mock.calls.slice(0, 3).map(([, init]) => JSON.parse((init as RequestInit).body as string).name);
      expect(names).toEqual(['Nordlicht Order Desk', 'Nordlicht Order Desk 2', 'Nordlicht Order Desk 3']);
    });

    it('throws when the create call is non-2xx', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 500, text: 'boom' }));

      const client = createClient(auth, config);
      await expect(client.createApp('Bad App')).rejects.toThrow(
        /ToolJet createApp failed \(500\): boom/
      );
    });
  });

  describe('renameApp', () => {
    it('updates the app name and verifies readback', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { id: 'app1', name: 'Support Operations' } }));

      const client = createClient(auth, config);
      await client.renameApp('app1', 'ver1', 'Support Operations');

      expect(auth.authedFetch).toHaveBeenNthCalledWith(1, '/api/apps/app1', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ app: { name: 'Support Operations', editingVersionId: 'ver1' } }),
      });
      expect(auth.authedFetch).toHaveBeenNthCalledWith(2, '/api/apps/app1');
    });
  });

  describe('getApp', () => {
    it('fetches the app by id', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({ status: 200, json: { id: 'app1', name: 'My App' } })
      );

      const client = createClient(auth, config);
      const app = await client.getApp('app1');

      expect(auth.authedFetch).toHaveBeenCalledWith('/api/apps/app1');
      expect(app).toEqual({ id: 'app1', name: 'My App' });
    });

    it('throws when non-2xx', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 404, text: 'not found' }));
      const client = createClient(auth, config);
      await expect(client.getApp('missing')).rejects.toThrow(
        /ToolJet getApp failed \(404\): not found/
      );
    });
  });

  // The raw GET /api/apps/:id nests actual values under pages[].components[id].component.definition,
  // with the full widget schema under component.properties. getAppSummary must project values only.
  const rawAppResponse = {
    id: 'app1',
    name: 'My App',
    editing_version: { id: 'ver1' },
    pages: [
      {
        id: 'page-home',
        name: 'Home',
        handle: 'home',
        icon: 'IconLayoutDashboard',
        hidden: { value: '{{true}}', fxActive: false },
        index: 1,
        components: {
          'c-1': {
            layouts: { desktop: { top: 0, left: 0, width: 20, height: 4 } },
            component: {
              name: 'title',
              component: 'Text',
              // full widget schema (the bulk) — must be dropped
              properties: { text: { type: 'code', displayName: 'x', validation: {} } },
              definition: {
                properties: { text: { value: 'Dashboard' } },
                styles: { textSize: { value: 24 } },
                others: { showOnMobile: { value: '{{false}}' } },
              },
            },
          },
        },
      },
    ],
    data_queries: [
      { id: 'q1', name: 'getRows', kind: 'tooljetdb', data_source_id: 'ds1', options: { operation: 'list_rows' }, extra: 'drop' },
    ],
    events: [
      { id: 'e1', name: 'onClick → run-query', sourceId: 'c-1', target: 'component', event: { eventId: 'onClick', actionId: 'run-query' }, appVersionId: 'ver1' },
    ],
  };

  describe('getAppSummary', () => {
    it('projects values-only components, compact queries and events', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: rawAppResponse }));
      const client = createClient(auth, config);
      const summary = await client.getAppSummary('app1');

      expect(summary).toEqual({
        app_id: 'app1',
        name: 'My App',
        version_id: 'ver1',
        pages: [
          {
            id: 'page-home',
            name: 'Home',
            handle: 'home',
            icon: 'IconLayoutDashboard',
            hidden: true,
            index: 1,
            components: [
              {
                id: 'c-1',
                name: 'title',
                type: 'Text',
                layouts: { desktop: { top: 0, left: 0, width: 20, height: 4 } },
                properties: { text: { value: 'Dashboard' } },
                styles: { textSize: { value: 24 } },
                others: { showOnMobile: { value: '{{false}}' } },
              },
            ],
          },
        ],
        queries: [
          { id: 'q1', name: 'getRows', kind: 'tooljetdb', data_source_id: 'ds1', options: { operation: 'list_rows' } },
        ],
        events: [
          { id: 'e1', name: 'onClick → run-query', sourceId: 'c-1', target: 'component', event: { eventId: 'onClick', actionId: 'run-query' } },
        ],
      });
    });

    it('reports a persisted native slot without hiding ToolJet\'s raw parent id', async () => {
      const response = structuredClone(rawAppResponse);
      response.pages[0].components['c-1'].component.parent = 'modal-1-header';
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: response }));
      const client = createClient(auth, config);
      const component = (await client.getAppSummary('app1')).pages[0].components[0];

      expect(component).toMatchObject({ parent: 'modal-1-header', slot_name: 'header' });
    });
  });

  describe('getComponent', () => {
    it('returns one component projection with its page_id', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: rawAppResponse }));
      const client = createClient(auth, config);
      const c = await client.getComponent('app1', 'c-1');
      expect(c).toEqual({
        id: 'c-1',
        name: 'title',
        type: 'Text',
        page_id: 'page-home',
        layouts: { desktop: { top: 0, left: 0, width: 20, height: 4 } },
        properties: { text: { value: 'Dashboard' } },
        styles: { textSize: { value: 24 } },
        others: { showOnMobile: { value: '{{false}}' } },
      });
    });

    it('throws when the component id is not in any page', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: rawAppResponse }));
      const client = createClient(auth, config);
      await expect(client.getComponent('app1', 'nope')).rejects.toThrow(
        /component nope not found in app app1/
      );
    });
  });

  describe('getDevelopmentEnvironmentId', () => {
    it('finds the development environment from a top-level array response', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({
          status: 200,
          json: [
            { id: 'env-prod', name: 'production' },
            { id: 'env-dev', name: 'development' },
          ],
        })
      );

      const client = createClient(auth, config);
      const envId = await client.getDevelopmentEnvironmentId();

      expect(auth.authedFetch).toHaveBeenCalledWith('/api/app-environments');
      expect(envId).toBe('env-dev');
    });

    it('caches the development environment for repeated and concurrent callers', async () => {
      auth.authedFetch.mockResolvedValue(
        mockResponse({ status: 200, json: [{ id: 'env-dev', name: 'development' }] })
      );
      const client = createClient(auth, config);

      await expect(Promise.all([
        client.getDevelopmentEnvironmentId(),
        client.getDevelopmentEnvironmentId(),
      ])).resolves.toEqual(['env-dev', 'env-dev']);
      await expect(client.getDevelopmentEnvironmentId()).resolves.toBe('env-dev');
      expect(auth.authedFetch).toHaveBeenCalledOnce();
    });

    it('finds the development environment from a wrapped { environments } response', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({
          status: 200,
          json: { environments: [{ id: 'env-dev', name: 'development' }] },
        })
      );

      const client = createClient(auth, config);
      const envId = await client.getDevelopmentEnvironmentId();

      expect(envId).toBe('env-dev');
    });

    it('throws when non-2xx', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 500, text: 'server error' }));
      const client = createClient(auth, config);
      await expect(client.getDevelopmentEnvironmentId()).rejects.toThrow(
        /ToolJet getDevelopmentEnvironmentId failed \(500\): server error/
      );
    });
  });

  describe('listDatasources', () => {
    it('resolves org id and dev env id, then fetches app-scoped datasources', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(
          mockResponse({ status: 200, json: { environments: [{ id: 'env-dev', name: 'development' }] } })
        )
        .mockResolvedValueOnce(
          mockResponse({
            status: 200,
            json: {
              // Real responses are fully hydrated — options/plugin/scope/timestamps etc. The client
              // must strip these to {id,name,kind} at runtime (the TS type alone does not).
              data_sources: [
                {
                  id: 'ds1',
                  name: 'tjdb',
                  kind: 'tooljetdb',
                  options: { foo: 'bar' },
                  plugin: { id: 'p1', manifest: {} },
                  scope: 'global',
                  created_at: '2020-01-01',
                },
                { id: 'ds2', name: 'restapi1', kind: 'restapi', options: {}, plugin: null },
              ],
            },
          })
        );

      const client = createClient(auth, config);
      const datasources = await client.listDatasources('ver1');

      expect(auth.getOrganizationId).toHaveBeenCalledTimes(1);
      expect(auth.authedFetch).toHaveBeenNthCalledWith(1, '/api/app-environments');
      expect(auth.authedFetch).toHaveBeenNthCalledWith(
        2,
        '/api/data-sources/org1/environments/env-dev/versions/ver1'
      );
      // compact identity + repair link — bulky fields stripped
      expect(datasources).toEqual([
        {
          id: 'ds1', name: 'tjdb', kind: 'tooljetdb',
          settings_url: 'http://localhost:8082/myworkspace/data-sources/ds1',
        },
        {
          id: 'ds2', name: 'restapi1', kind: 'restapi',
          settings_url: 'http://localhost:8082/myworkspace/data-sources/ds2',
        },
      ]);
    });

    it('throws when non-2xx', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(
          mockResponse({ status: 200, json: { environments: [{ id: 'env-dev', name: 'development' }] } })
        )
        .mockResolvedValueOnce(mockResponse({ status: 403, text: 'forbidden' }));

      const client = createClient(auth, config);
      await expect(client.listDatasources('ver1')).rejects.toThrow(
        /ToolJet listDatasources failed \(403\): forbidden/
      );
    });
  });

  describe('getQueries', () => {
    it('adds a direct datasource settings URL without exposing datasource credentials', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({
        status: 200,
        json: {
          data_queries: [{
            id: 'q1', name: 'orders', kind: 'postgresql', data_source_id: 'pg1',
            options: { mode: 'sql', query: 'select id from orders limit 25' },
          }],
        },
      }));

      const queries = await createClient(auth, config).getQueries('ver1');

      expect(queries).toEqual([expect.objectContaining({
        id: 'q1',
        datasource_settings_url: 'http://localhost:8082/myworkspace/data-sources/pg1',
      })]);
    });
  });

  describe('createQuery', () => {
    it('posts to the data-source-scoped query route with kind tooljetdb', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({ status: 201, json: { id: 'query1', name: 'getUsers' } })
      );

      const client = createClient(auth, config);
      const result = await client.createQuery({
        versionId: 'ver1',
        dataSourceId: 'ds1',
        name: 'getUsers',
        options: { operation: 'list_rows', table_name: 'users' },
        kind: 'tooljetdb',
      });

      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/data-queries/data-sources/ds1/versions/ver1');
      expect(init.method).toBe('POST');
      expect(JSON.parse(init.body)).toEqual({
        kind: 'tooljetdb',
        name: 'getUsers',
        options: { operation: 'list_rows', table_name: 'users' },
      });

      expect(result).toEqual({ query_id: 'query1', name: 'getUsers' });
    });

    it('resolves the kind from the datasource when not given (any datasource works)', async () => {
      auth.authedFetch
        // listDatasources → app-environments, then app-scoped datasources
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { environments: [{ id: 'env-dev', name: 'development' }] } }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { data_sources: [{ id: 'ds-snow', name: 'servicenow', kind: 'servicenow' }] } }))
        // the create
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'q9', name: 'snq' } }));

      const client = createClient(auth, config);
      await client.createQuery({ versionId: 'ver1', dataSourceId: 'ds-snow', name: 'snq', options: { operation: 'list_records' } });

      const createInit = auth.authedFetch.mock.calls[2][1];
      expect(JSON.parse(createInit.body).kind).toBe('servicenow'); // resolved from the datasource, NOT hardcoded tjdb
    });

    it('throws when non-2xx', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 422, text: 'invalid options' }));
      const client = createClient(auth, config);
      await expect(
        client.createQuery({ versionId: 'ver1', dataSourceId: 'ds1', name: 'q', options: {}, kind: 'tooljetdb' })
      ).rejects.toThrow(/ToolJet createQuery failed \(422\): invalid options/);
    });
  });

  describe('createComponent', () => {
    it('posts a v2 diff body keyed by a generated uuid and returns that id', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));

      const client = createClient(auth, config);
      const result = await client.createComponent({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        name: 'usersTable',
        type: 'Table',
        properties: { title: 'Users' },
        layout: { top: 0, left: 0, width: 10, height: 20 },
      });

      expect(result).toEqual({ component_id: 'component-uuid-1' });

      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/components');
      expect(init.method).toBe('POST');

      const body = JSON.parse(init.body);
      expect(body.is_user_switched_version).toBe(false);
      expect(body.pageId).toBe('page-home');
      expect(Object.keys(body.diff)).toEqual(['component-uuid-1']);
      expect(body.diff['component-uuid-1']).toMatchObject({
        name: 'usersTable',
        type: 'Table',
        properties: { title: 'Users' },
        layouts: {
          desktop: { top: 0, left: 0, width: 10, height: 20 },
          mobile: { top: 0, left: 0, width: 10, height: 20 },
        },
      });
    });

    it('passes styles/validation/others through instead of hardcoding empty objects', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));

      const client = createClient(auth, config);
      await client.createComponent({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        name: 'title',
        type: 'Text',
        properties: { text: { value: 'Hello' } },
        styles: { textSize: { value: 24 }, fontWeight: { value: 'bold' } },
        validation: { customRule: { value: null } },
        others: { showOnMobile: { value: '{{true}}' } },
        layout: { top: 0, left: 0, width: 10, height: 4 },
      });

      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      const dto = body.diff['component-uuid-1'];
      expect(dto.styles).toEqual({ textSize: { value: 24 }, fontWeight: { value: 'bold' } });
      expect(dto.validation).toEqual({ customRule: { value: null } });
      expect(dto.others).toEqual({ showOnMobile: { value: '{{true}}' } });
    });

    it('rejects style keys placed under properties (ToolJet silently drops them)', async () => {
      const client = createClient(auth, config);
      await expect(
        client.createComponent({
          appId: 'app1',
          versionId: 'ver1',
          pageId: 'page-home',
          name: 'title',
          type: 'Text',
          properties: { text: { value: 'Hi' }, textColor: { value: '#111' } },
        })
      ).rejects.toThrow(/style keys \["textColor"\] were placed under `properties`/);
      // never hit the network
      expect(auth.authedFetch).not.toHaveBeenCalled();
    });

    it('honors explicit per-resolution layouts (does not duplicate a flat rectangle)', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));

      const client = createClient(auth, config);
      await client.createComponent({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        name: 'card',
        type: 'Text',
        properties: {},
        layouts: {
          desktop: { top: 0, left: 0, width: 20, height: 6 },
          mobile: { top: 0, left: 0, width: 43, height: 6 },
        },
      });

      const dto = JSON.parse(auth.authedFetch.mock.calls[0][1].body).diff['component-uuid-1'];
      expect(dto.layouts).toEqual({
        desktop: { top: 0, left: 0, width: 20, height: 6 },
        mobile: { top: 0, left: 0, width: 43, height: 6 },
      });
    });

    it('throws when non-2xx', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 400, text: 'bad component' }));

      const client = createClient(auth, config);
      await expect(
        client.createComponent({
          appId: 'app1',
          versionId: 'ver1',
          pageId: 'page-home',
          name: 'x',
          type: 'Table',
          properties: {},
        })
      ).rejects.toThrow(/ToolJet createComponents failed \(400\): bad component/);
    });
  });

  describe('createComponents (batch)', () => {
    it('sends all components in ONE request as a diff keyed by unique ids', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));

      const client = createClient(auth, config);
      const result = await client.createComponents({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        components: [
          { name: 'title', type: 'Text', properties: { text: { value: 'Hi' } }, layout: { top: 0, left: 2, width: 40, height: 40 } },
          { name: 'grid', type: 'Table', properties: { data: { value: '{{queries.q.data}}' } }, layout: { top: 60, left: 2, width: 40, height: 300 } },
        ],
      });

      // exactly one HTTP call for both components
      expect(auth.authedFetch).toHaveBeenCalledTimes(1);
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/components');
      const body = JSON.parse(init.body);
      expect(Object.keys(body.diff)).toEqual(['component-uuid-1', 'component-uuid-2']);
      expect(body.diff['component-uuid-1']).toMatchObject({ name: 'title', type: 'Text' });
      expect(body.diff['component-uuid-2']).toMatchObject({ name: 'grid', type: 'Table' });
      expect(result).toEqual([
        { component_id: 'component-uuid-1', name: 'title' },
        { component_id: 'component-uuid-2', name: 'grid' },
      ]);
    });

    it('resolves parentRef to a same-batch clientRef in the single create request', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));
      const client = createClient(auth, config);
      await client.createComponents({
        appId: 'app1', versionId: 'ver1', pageId: 'page-home',
        components: [
          { name: 'modal', type: 'ModalV2', clientRef: 'new-modal', properties: {}, layout: { top: 0, left: 0, width: 10, height: 10 } },
          { name: 'field', type: 'TextInput', parentRef: 'new-modal', properties: {}, styles: { alignment: { value: 'top' } }, layout: { top: 20, left: 2, width: 18, height: 60 } },
        ],
      });
      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.diff['component-uuid-2'].parent).toBe('component-uuid-1');
    });

    it('persists Kanban modal children on the separate card-click canvas', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));
      const client = createClient(auth, config);
      await client.createComponents({
        appId: 'app1', versionId: 'ver1', pageId: 'page-home',
        components: [
          { name: 'board', type: 'Kanban', clientRef: 'board', properties: { openModalOnCardClick: { value: true } } },
          { name: 'detail', type: 'Text', parentRef: 'board', slotName: 'modal', properties: { text: { value: '{{cardData.title}}' } } },
        ],
      });
      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.diff['component-uuid-2'].parent).toBe('component-uuid-1-modal');
    });

    it('encodes a logical modal slot in the persisted parent id', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { success: true } }));
      const client = createClient(auth, config);
      await client.createComponents({
        appId: 'app1', versionId: 'ver1', pageId: 'page-home',
        components: [
          { name: 'modal', type: 'ModalV2', clientRef: 'new-modal', properties: {}, layout: { top: 0, left: 0, width: 10, height: 10 } },
          {
            name: 'title', type: 'Text', parentRef: 'new-modal', slotName: 'header',
            properties: { text: { value: 'Add a test case' } }, layout: { top: 10, left: 2, width: 30, height: 50 },
          },
          {
            name: 'field', type: 'TextInput', parentRef: 'new-modal', slotName: 'body',
            properties: {}, layout: { top: 20, left: 2, width: 18, height: 60 },
          },
        ],
      });
      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.diff['component-uuid-2'].parent).toBe('component-uuid-1-header');
      expect(body.diff['component-uuid-3'].parent).toBe('component-uuid-1');
    });
  });

  describe('createEvents', () => {
    it('bulk-posts events with eventId merged into action, per-component index', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: {} }));
      const client = createClient(auth, config);
      const result = await client.createEvents({
        appId: 'app1',
        versionId: 'ver1',
        existingEvents: [],
        events: [
          { sourceId: 'btn1', sourceType: 'component', trigger: 'onClick', action: { actionId: 'run-query', queryName: 'save' } },
          { sourceId: 'btn1', sourceType: 'component', trigger: 'onClick', action: { actionId: 'show-alert', message: 'Saved', alertType: 'success' } },
          { sourceId: 'tbl1', sourceType: 'component', trigger: 'onRowClicked', action: { actionId: 'switch-page', pageId: 'p2', queryParams: [['id', '{{x}}']] } },
        ],
      });

      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/events/bulk');
      const body = JSON.parse(init.body);
      expect(body.events[0]).toMatchObject({ eventType: 'component', attachedTo: 'btn1', index: 0, event: { eventId: 'onClick', actionId: 'run-query', queryName: 'save' } });
      expect(body.events[1]).toMatchObject({ attachedTo: 'btn1', index: 1 }); // second event on same component → index 1
      expect(body.events[2]).toMatchObject({ attachedTo: 'tbl1', index: 0, event: { eventId: 'onRowClicked', actionId: 'switch-page', pageId: 'p2' } });
      expect(result).toEqual({ created: 3 });
    });

    it('bulk-posts query and page lifecycle events with independent per-source ordering', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: {} }));
      const client = createClient(auth, config);
      await client.createEvents({
        appId: 'app1',
        versionId: 'ver1',
        existingEvents: [],
        events: [
          { sourceId: 'save1', sourceType: 'data_query', trigger: 'onDataQuerySuccess', action: { actionId: 'run-query', queryId: 'list1' } },
          { sourceId: 'save1', sourceType: 'data_query', trigger: 'onDataQuerySuccess', action: { actionId: 'show-alert', message: 'Saved' }, name: 'Refresh after save' },
          { sourceId: 'page1', sourceType: 'page', trigger: 'onPageLoad', action: { actionId: 'run-query', queryId: 'list1' } },
        ],
      });

      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.events[0]).toMatchObject({ eventType: 'data_query', attachedTo: 'save1', index: 0, event: { eventId: 'onDataQuerySuccess' } });
      expect(body.events[1]).toMatchObject({ eventType: 'data_query', attachedTo: 'save1', index: 1, name: 'Refresh after save' });
      expect(body.events[2]).toMatchObject({ eventType: 'page', attachedTo: 'page1', index: 0, event: { eventId: 'onPageLoad' } });
    });

    it('bulk-posts Table Button-column refs with per-button ordering', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: {} }));
      const client = createClient(auth, config);
      await client.createEvents({
        appId: 'app1',
        versionId: 'ver1',
        existingEvents: [],
        events: [
          { sourceId: 'tbl1', sourceType: 'table_column', ref: 'actions::view', trigger: 'onClick', action: { actionId: 'run-query', queryId: 'view1' } },
          { sourceId: 'tbl1', sourceType: 'table_column', ref: 'actions::delete', trigger: 'onClick', action: { actionId: 'run-query', queryId: 'delete1' } },
          { sourceId: 'tbl1', sourceType: 'table_column', ref: 'actions::view', trigger: 'onClick', action: { actionId: 'show-alert', message: 'Opened' } },
        ],
      });

      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.events[0]).toMatchObject({
        eventType: 'table_column',
        attachedTo: 'tbl1',
        index: 0,
        event: { eventId: 'onClick', ref: 'actions::view', actionId: 'run-query' },
      });
      expect(body.events[1]).toMatchObject({ index: 0, event: { ref: 'actions::delete' } });
      expect(body.events[2]).toMatchObject({ index: 1, event: { ref: 'actions::view' } });
    });

    it('adds the empty params array required by parameterless control-component actions', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: {} }));
      const client = createClient(auth, config);
      await client.createEvents({
        appId: 'app1',
        versionId: 'ver1',
        existingEvents: [],
        events: [{
          sourceId: 'save1',
          sourceType: 'data_query',
          trigger: 'onDataQuerySuccess',
          action: {
            actionId: 'control-component',
            componentId: 'notes1',
            componentSpecificActionHandle: 'clear',
          },
        }],
      });

      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.events[0].event).toMatchObject({
        actionId: 'control-component',
        componentSpecificActionHandle: 'clear',
        componentSpecificActionParams: [],
      });
    });

    it('appends indices after persisted events for the same source and sub-element', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: {} }));
      const client = createClient(auth, config);
      await client.createEvents({
        appId: 'app1',
        versionId: 'ver1',
        existingEvents: [
          {
            id: 'existing-1', sourceId: 'btn1', target: 'component', index: 2,
            event: { eventId: 'onClick', actionId: 'run-query' },
          },
          {
            id: 'other-ref', sourceId: 'tbl1', target: 'table_column', index: 7,
            event: { eventId: 'onClick', ref: 'actions::delete', actionId: 'run-query' },
          },
        ],
        events: [
          { sourceId: 'btn1', sourceType: 'component', trigger: 'onClick', action: { actionId: 'show-alert' } },
          {
            sourceId: 'tbl1', sourceType: 'table_column', ref: 'actions::view', trigger: 'onClick',
            action: { actionId: 'run-query' },
          },
        ],
      });

      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.events[0].index).toBe(3);
      expect(body.events[1].index).toBe(0);
    });
  });

  describe('createPage', () => {
    it('appends after existing pages, slugifies the handle, uses a client-generated id', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { pages: [{ id: 'home', name: 'Home', index: 1 }] } })) // getApp
        .mockResolvedValueOnce(mockResponse({ status: 201, json: {} })); // create page

      const client = createClient(auth, config);
      const result = await client.createPage({ appId: 'app1', versionId: 'ver1', name: 'Details View' });

      const [path, init] = auth.authedFetch.mock.calls[1];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/pages');
      const body = JSON.parse(init.body);
      expect(body).toMatchObject({ id: 'component-uuid-1', name: 'Details View', handle: 'details-view', index: 2 });
      expect(result).toEqual({ page_id: 'component-uuid-1', name: 'Details View', index: 2 });
    });

    it('persists and verifies a sidebar icon through the page update route', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { pages: [{ id: 'home', name: 'Home', index: 1 }] } }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { pages: [{ id: 'home', name: 'Home', index: 1 }, { id: 'component-uuid-1', name: 'Customers', icon: 'IconUsers', index: 2 }] },
        }));

      const client = createClient(auth, config);
      const result = await client.createPage({
        appId: 'app1',
        versionId: 'ver1',
        name: 'Customers',
        icon: 'IconUsers',
      });

      const [updatePath, updateInit] = auth.authedFetch.mock.calls[2];
      expect(updatePath).toBe('/api/v2/apps/app1/versions/ver1/pages');
      expect(updateInit.method).toBe('PUT');
      expect(JSON.parse(updateInit.body)).toEqual({ pageId: 'component-uuid-1', diff: { icon: 'IconUsers' } });
      expect(result).toEqual({ page_id: 'component-uuid-1', name: 'Customers', index: 2, icon: 'IconUsers' });
    });

    it('persists hidden pages with ToolJet\'s canonical Boolean binding', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { pages: [{ id: 'home', name: 'Home', index: 1 }] } }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { pages: [
            { id: 'home', name: 'Home', index: 1 },
            { id: 'component-uuid-1', name: 'Details', hidden: { value: '{{true}}', fxActive: false }, index: 2 },
          ] },
        }));

      const client = createClient(auth, config);
      const result = await client.createPage({
        appId: 'app1', versionId: 'ver1', name: 'Details', hidden: true,
      });

      expect(JSON.parse(auth.authedFetch.mock.calls[2][1].body)).toEqual({
        pageId: 'component-uuid-1',
        diff: { hidden: { value: '{{true}}', fxActive: false } },
      });
      expect(result).toEqual({ page_id: 'component-uuid-1', name: 'Details', index: 2, hidden: true });
    });

    it('reports exactly which pages persisted when one request in a batch fails', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { pages: [{ id: 'home', name: 'Home', index: 1 }] } }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 500, text: 'page write failed' }));

      const client = createClient(auth, config);
      let caught: unknown;
      try {
        await client.createPages({
          appId: 'app1', versionId: 'ver1',
          pages: [{ name: 'Customers' }, { name: 'Reports' }],
        });
      } catch (error) {
        caught = error;
      }

      expect(caught).toBeInstanceOf(PartialWriteError);
      expect((caught as PartialWriteError<unknown>).completed).toEqual([
        { page_id: 'component-uuid-1', name: 'Customers', index: 2 },
      ]);
      expect(String(caught)).toMatch(/Persisted before failure.*Customers.*Reports.*page write failed.*not deleted/i);
    });
  });

  describe('updatePages', () => {
    it('updates one field per request, reorders all pages, and verifies the readback', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: {
            pages: [
              { id: 'home', name: 'Home', handle: 'home', index: 1 },
              { id: 'cases', name: 'Cases', handle: 'cases', icon: 'IconChecklist', index: 2 },
            ],
          },
        }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: {
            pages: [
              { id: 'cases', name: 'Cases', handle: 'cases', icon: 'IconChecklist', index: 0 },
              { id: 'home', name: 'Overview', handle: 'home', icon: 'IconHome', hidden: { value: false }, index: 1 },
            ],
          },
        }));

      const client = createClient(auth, config);
      const result = await client.updatePages({
        appId: 'app1',
        versionId: 'ver1',
        updates: [{ pageId: 'home', name: 'Overview', icon: 'IconHome', hidden: false }],
        order: ['cases', 'home'],
      });

      expect(auth.authedFetch.mock.calls.slice(1, 3).map(([, init]) => JSON.parse(init.body))).toEqual([
        { pageId: 'home', diff: { name: 'Overview' } },
        { pageId: 'home', diff: { icon: 'IconHome' } },
      ]);
      const [reorderPath, reorderInit] = auth.authedFetch.mock.calls[3];
      expect(reorderPath).toBe('/api/v2/apps/app1/versions/ver1/pages/reorder');
      expect(JSON.parse(reorderInit.body)).toEqual({
        diff: { cases: { index: 0 }, home: { index: 1 } },
      });
      expect(result).toEqual({
        updated_fields: 2,
        reordered: true,
        pages: [
          { page_id: 'cases', name: 'Cases', handle: 'cases', icon: 'IconChecklist', hidden: false, index: 0 },
          { page_id: 'home', name: 'Overview', handle: 'home', icon: 'IconHome', hidden: false, index: 1 },
        ],
      });
    });

    it('rejects partial page orders before writing', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({
        status: 200,
        json: { pages: [{ id: 'home', name: 'Home' }, { id: 'cases', name: 'Cases' }] },
      }));
      const client = createClient(auth, config);

      await expect(client.updatePages({
        appId: 'app1',
        versionId: 'ver1',
        order: ['cases'],
      })).rejects.toThrow(/every current page id exactly once/i);
      expect(auth.authedFetch).toHaveBeenCalledOnce();
    });

    it('rejects hiding the Home page before writing', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({
        status: 200,
        json: {
          editing_version: { home_page_id: 'home' },
          pages: [{ id: 'home', name: 'Play', handle: 'home', hidden: { value: '{{false}}', fxActive: false } }],
        },
      }));
      const client = createClient(auth, config);

      await expect(client.updatePages({
        appId: 'app1', versionId: 'ver1', updates: [{ pageId: 'home', hidden: true }],
      })).rejects.toThrow(/Home page cannot be hidden/i);
      expect(auth.authedFetch).toHaveBeenCalledOnce();
    });

    it('allows a non-Home page to be hidden with the canonical binding', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: {
            editing_version: { home_page_id: 'home' },
            pages: [
              { id: 'home', name: 'Home', handle: 'home' },
              { id: 'details', name: 'Details', handle: 'details', hidden: { value: '{{false}}', fxActive: false } },
            ],
          },
        }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { pages: [
            { id: 'home', name: 'Home', handle: 'home' },
            { id: 'details', name: 'Details', handle: 'details', hidden: { value: '{{true}}', fxActive: false } },
          ] },
        }));
      const client = createClient(auth, config);

      const result = await client.updatePages({
        appId: 'app1', versionId: 'ver1', updates: [{ pageId: 'details', hidden: true }],
      });

      expect(JSON.parse(auth.authedFetch.mock.calls[1][1].body)).toEqual({
        pageId: 'details',
        diff: { hidden: { value: '{{true}}', fxActive: false } },
      });
      expect(result.pages.find((page) => page.page_id === 'details')?.hidden).toBe(true);
    });

    it('rewrites a raw Boolean hidden value to ToolJet\'s canonical binding', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: {
            editing_version: { home_page_id: 'home' },
            pages: [
              { id: 'home', name: 'Home', handle: 'home' },
              { id: 'details', name: 'Details', handle: 'details', hidden: { value: false } },
            ],
          },
        }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { pages: [
            { id: 'home', name: 'Home', handle: 'home' },
            { id: 'details', name: 'Details', handle: 'details', hidden: { value: '{{false}}', fxActive: false } },
          ] },
        }));
      const client = createClient(auth, config);

      const result = await client.updatePages({
        appId: 'app1', versionId: 'ver1', updates: [{ pageId: 'details', hidden: false }],
      });

      expect(JSON.parse(auth.authedFetch.mock.calls[1][1].body)).toEqual({
        pageId: 'details',
        diff: { hidden: { value: '{{false}}', fxActive: false } },
      });
      expect(result).toMatchObject({
        updated_fields: 1,
        pages: [
          { page_id: 'home', hidden: false },
          { page_id: 'details', hidden: false },
        ],
      });
    });
  });

  describe('createTable', () => {
    it('normalizes types, sets constraints, and auto-adds a serial id PK when none given', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { result: { id: 't1', table_name: 'people' } } }));

      const client = createClient(auth, config);
      const result = await client.createTable({
        tableName: 'people',
        columns: [
          { name: 'name', type: 'string' },
          { name: 'age', type: 'integer', notNull: true },
        ],
      });

      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/tooljet-db/organizations/org1/table');
      const body = JSON.parse(init.body);
      expect(body.table_name).toBe('people');
      // auto id PK prepended
      expect(body.columns[0]).toMatchObject({ column_name: 'id', data_type: 'serial', constraints_type: { is_primary_key: true } });
      // alias normalized + constraints set
      expect(body.columns[1]).toMatchObject({ column_name: 'name', data_type: 'character varying' });
      expect(body.columns[2]).toMatchObject({ column_name: 'age', data_type: 'integer', constraints_type: { is_not_null: true } });
      expect(result).toEqual({ table_id: 't1', table_name: 'people' });
    });

    it('preserves defaults/configurations and creates foreign-key relationships', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 201, json: { result: { id: 't2', table_name: 'orders' } } }));
      const client = createClient(auth, config);
      await client.createTable({
        tableName: 'orders',
        columns: [
          { name: 'id', type: 'serial', primaryKey: true },
          { name: 'customer_id', type: 'integer', notNull: true },
          { name: 'active', type: 'boolean', defaultValue: false },
          { name: 'created_at', type: 'timestamp', defaultValue: 'now()', configurations: { timezone: 'UTC' } },
        ],
        foreignKeys: [
          { columns: ['customer_id'], referencedTable: 'customers', referencedColumns: ['id'], onDelete: 'CASCADE' },
        ],
      });
      const body = JSON.parse(auth.authedFetch.mock.calls[0][1].body);
      expect(body.columns[2]).toMatchObject({ column_name: 'active', column_default: false });
      expect(body.columns[3]).toMatchObject({ column_default: 'now()', configurations: { timezone: 'UTC' } });
      expect(body.foreign_keys).toEqual([
        { column_names: ['customer_id'], referenced_table_name: 'customers', referenced_column_names: ['id'], on_delete: 'CASCADE' },
      ]);
    });

    it('rejects malformed foreign keys before sending a request', async () => {
      const client = createClient(auth, config);
      await expect(client.createTable({
        tableName: 'orders',
        columns: [{ name: 'customer_id', type: 'integer' }],
        foreignKeys: [{ columns: ['missing'], referencedTable: 'customers', referencedColumns: ['id'] }],
      })).rejects.toThrow(/missing local columns: missing/);
      expect(auth.authedFetch).not.toHaveBeenCalled();
    });

    it('rejects ToolJet DB reserved column names before sending a request', async () => {
      const client = createClient(auth, config);
      await expect(client.createTable({
        tableName: 'test_steps',
        columns: [{ name: 'action', type: 'string' }],
      })).rejects.toThrow(/reserved column name: action.*step_action/i);
      expect(auth.authedFetch).not.toHaveBeenCalled();

      await expect(client.addTableColumn({
        tableName: 'test_results',
        column: { name: 'comment', type: 'string' },
      })).rejects.toThrow(/reserved column name: comment.*result_comment/i);
      expect(auth.authedFetch).not.toHaveBeenCalled();

      await expect(client.createTable({
        tableName: 'inspections',
        columns: [{ name: 'condition', type: 'string' }],
      })).rejects.toThrow(/reserved column name: condition.*item_condition/i);
      expect(auth.authedFetch).not.toHaveBeenCalled();
    });
  });

  describe('ToolJet DB schema maintenance', () => {
    it('adds a typed column with defaults and foreign keys', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.addTableColumn({
        tableName: 'orders',
        column: { name: 'customer_id', type: 'integer', notNull: true, defaultValue: 0 },
        foreignKeys: [{ columns: ['customer_id'], referencedTable: 'customers', referencedColumns: ['id'] }],
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/tooljet-db/organizations/org1/table/orders/column');
      expect(JSON.parse(init.body)).toMatchObject({
        column: { column_name: 'customer_id', data_type: 'integer', column_default: 0 },
        foreign_keys: [{ column_names: ['customer_id'], referenced_table_name: 'customers', referenced_column_names: ['id'] }],
      });
    });

    it('drops one encoded column or table target', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.dropTableColumn({ tableName: 'order lines', columnName: 'legacy/value' });
      await client.dropTable({ tableName: 'old orders' });
      expect(auth.authedFetch.mock.calls[0][0]).toBe(
        '/api/tooljet-db/organizations/org1/table/order%20lines/column/legacy%2Fvalue'
      );
      expect(auth.authedFetch.mock.calls[1][0]).toBe('/api/tooljet-db/organizations/org1/table/old%20orders');
    });
  });

  describe('getTableSchema', () => {
    it('maps result.columns to a simplified schema', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({
          status: 200,
          json: { result: {
            columns: [
              { column_name: 'id', data_type: 'integer', constraints_type: { is_primary_key: true, is_not_null: true, is_unique: true } },
              { column_name: 'customer_id', data_type: 'integer', column_default: 0 },
            ],
            foreign_keys: [{ column_names: ['customer_id'], referenced_table_name: 'customers', referenced_column_names: ['id'], on_delete: 'CASCADE' }],
            configurations: { columns: { column_names: { customer_id: 'uuid-1' }, configurations: { 'uuid-1': { timezone: 'UTC' } } } },
          } },
        })
      );
      const client = createClient(auth, config);
      const schema = await client.getTableSchema('people');
      expect(schema).toEqual([
        { name: 'id', type: 'integer', isPrimaryKey: true, isNotNull: true, isUnique: true, foreignKeys: [] },
        {
          name: 'customer_id', type: 'integer', isPrimaryKey: false, isNotNull: false, isUnique: false,
          defaultValue: 0,
          configurations: { timezone: 'UTC' },
          foreignKeys: [{ columns: ['customer_id'], referencedTable: 'customers', referencedColumns: ['id'], onDelete: 'CASCADE' }],
        },
      ]);
    });
  });

  describe('insertRows', () => {
    it('omits generated ids and sends one object per insert-only PostgREST request', async () => {
      auth.authedFetch
        // getTableSchema
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: { columns: [{ column_name: 'id', data_type: 'integer', column_default: "nextval('people_id_seq'::regclass)", constraints_type: { is_primary_key: true } }, { column_name: 'name', data_type: 'character varying' }] } } }))
        // listTables
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: [{ id: 'people-id', table_name: 'people' }] } }))
        // insert-only PostgREST proxy, one object at a time because ToolJet's proxy mangles arrays
        .mockResolvedValueOnce(mockResponse({ status: 201, json: [{ id: 41, name: 'A' }] }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: [{ id: 42, name: 'B' }] }));

      const client = createClient(auth, config);
      const result = await client.insertRows({ tableName: 'people', rows: [{ name: 'A' }, { name: 'B' }] });

      expect(auth.authedFetch).toHaveBeenCalledTimes(4);
      expect(auth.authedFetch.mock.calls[2][0]).toBe('/api/tooljet-db/proxy/people-id');
      expect(auth.authedFetch.mock.calls[2][1]).toMatchObject({ method: 'POST' });
      expect(JSON.parse(auth.authedFetch.mock.calls[2][1].body)).toEqual({ name: 'A' });
      expect(JSON.parse(auth.authedFetch.mock.calls[3][1].body)).toEqual({ name: 'B' });
      expect(result).toEqual({ processed_rows: 2 });
    });

    it('reports an uncertain insert without retrying a gateway timeout', async () => {
      vi.useFakeTimers();
      try {
        const cloudflare = '<!DOCTYPE html><html><head><title>tooljet.ai | 524: A timeout occurred</title></head><body>…</body></html>';
        auth.authedFetch
          .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: { columns: [{ column_name: 'name', data_type: 'character varying' }] } } }))
          .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: [{ id: 'people-id', table_name: 'people' }] } }))
          .mockResolvedValueOnce(mockResponse({ status: 524, text: cloudflare }))
          .mockResolvedValueOnce(mockResponse({ status: 201, json: [{ id: 41, name: 'A' }] }));

        const client = createClient(auth, config);
        const pending = client.insertRows({ tableName: 'people', rows: [{ name: 'A' }] }).catch((error: Error) => error);
        await vi.runAllTimersAsync();
        const error = await pending;

        expect(error).toBeInstanceOf(Error);
        expect((error as Error).message).toMatch(/outcome unknown.*verify persisted rows/i);
        expect(auth.authedFetch).toHaveBeenCalledTimes(3);
        expect(auth.authedFetch.mock.calls[2][1].signal).toBeInstanceOf(AbortSignal);
      } finally {
        vi.useRealTimers();
      }
    });

    it('surfaces a persistent gateway timeout as one line, not the HTML page', async () => {
      vi.useFakeTimers();
      try {
        const cloudflare = '<!DOCTYPE html><html><head><title>tooljet.ai | 524: A timeout occurred</title></head><body>' + 'x'.repeat(12000) + '</body></html>';
        auth.authedFetch
          .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: { columns: [{ column_name: 'name', data_type: 'character varying' }] } } }))
          .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: [{ id: 'people-id', table_name: 'people' }] } }))
          .mockResolvedValue(mockResponse({ status: 524, text: cloudflare }));

        const client = createClient(auth, config);
        const pending = client.insertRows({ tableName: 'people', rows: [{ name: 'A' }] }).catch((error: Error) => error);
        await vi.runAllTimersAsync();
        const error = (await pending) as Error;

        expect(error.message).toContain('insertRows failed (524): tooljet.ai | 524: A timeout occurred (HTML error page from the proxy, markup omitted)');
        expect(error.message).toContain('Insert outcome unknown');
        expect(error.message.length).toBeLessThan(400);
        expect(auth.authedFetch).toHaveBeenCalledTimes(3); // two reads and one insert; no gateway retries
      } finally {
        vi.useRealTimers();
      }
    });

    it('rejects explicit values for a generated primary key before writing', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({
        status: 200,
        json: { result: { columns: [{ column_name: 'id', data_type: 'integer', column_default: "nextval('people_id_seq'::regclass)", constraints_type: { is_primary_key: true } }] } },
      }));

      const client = createClient(auth, config);
      await expect(client.insertRows({ tableName: 'people', rows: [{ id: 1, name: 'replacement' }] }))
        .rejects.toThrow(/omit generated primary key "id".*collide/i);
      expect(auth.authedFetch).toHaveBeenCalledTimes(1);
    });

    it('surfaces a primary-key conflict instead of silently upserting', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: { columns: [{ column_name: 'code', data_type: 'character varying', constraints_type: { is_primary_key: true } }] } } }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { result: [{ id: 'people-id', table_name: 'people' }] } }))
        .mockResolvedValueOnce(mockResponse({ status: 409, text: 'duplicate key value violates unique constraint' }));

      const client = createClient(auth, config);
      await expect(client.insertRows({ tableName: 'people', rows: [{ code: 'existing', name: 'replacement' }] }))
        .rejects.toThrow(/insertRows failed \(409\).*duplicate key/i);
    });

    it('reports completed table seeds when a later table fails', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { result: { columns: [{ column_name: 'id', data_type: 'serial', constraints_type: { is_primary_key: true } }] } },
        }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { result: [{ id: 'parents-id', table_name: 'parents' }, { id: 'children-id', table_name: 'children' }] },
        }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: [{ id: 1, name: 'Parent' }] }))
        .mockResolvedValueOnce(mockResponse({ status: 500, text: 'schema unavailable' }));

      const client = createClient(auth, config);
      let caught: unknown;
      try {
        await client.insertRowsBatch({
          tables: [
            { tableName: 'parents', rows: [{ name: 'Parent' }] },
            { tableName: 'children', rows: [{ name: 'Child' }] },
          ],
        });
      } catch (error) {
        caught = error;
      }

      expect(caught).toBeInstanceOf(PartialWriteError);
      expect((caught as PartialWriteError<unknown>).completed).toEqual([
        { table_name: 'parents', processed_rows: 1 },
      ]);
      expect(String(caught)).toMatch(/children.*schema unavailable.*not deleted/i);
    });

    it('reports rows already inserted when a later row in the same table fails', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { result: { columns: [{ column_name: 'id', data_type: 'serial', constraints_type: { is_primary_key: true } }] } },
        }))
        .mockResolvedValueOnce(mockResponse({
          status: 200,
          json: { result: [{ id: 'people-id', table_name: 'people' }] },
        }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: [{ id: 1, name: 'A' }] }))
        .mockResolvedValueOnce(mockResponse({ status: 409, text: 'duplicate key value violates unique constraint' }));

      const client = createClient(auth, config);
      let caught: unknown;
      try {
        await client.insertRowsBatch({
          tables: [{ tableName: 'people', rows: [{ name: 'A' }, { name: 'duplicate' }] }],
        });
      } catch (error) {
        caught = error;
      }

      expect(caught).toBeInstanceOf(PartialWriteError);
      expect((caught as PartialWriteError<unknown>).completed).toEqual([
        { table_name: 'people', processed_rows: 1 },
      ]);
      expect(String(caught)).toMatch(/people.*row 2\/2.*duplicate key.*not deleted/i);
    });
  });

  describe('createQueries (batch)', () => {
    it('serializes overlapping single and batch writes per version but not across versions', async () => {
      const releases: Array<() => void> = [];
      const started: string[] = [];
      auth.authedFetch.mockImplementation(async (_path: string, init: RequestInit) => {
        const { name } = JSON.parse(init.body as string);
        started.push(name);
        await new Promise<void>(resolve => releases.push(resolve));
        return mockResponse({status:201,json:{id:name,name}});
      });
      const client = createClient(auth, config);
      const query = (name: string) => ({name,dataSourceId:'ds1',kind:'runjs',options:{code:'return [];'}});
      const batch = client.createQueries({versionId:'v1',queries:[query('a'),query('b')]});
      const same = client.createQuery({versionId:'v1',...query('c')});
      const other = client.createQuery({versionId:'v2',...query('d')});
      await vi.waitFor(() => expect(started).toEqual(['a','d']));
      releases[0]!(); releases[1]!();
      await vi.waitFor(() => expect(started).toEqual(['a','d','b']));
      releases[2]!();
      await vi.waitFor(() => expect(started).toEqual(['a','d','b','c']));
      releases[3]!();
      await Promise.all([batch,same,other]);
    });
    it('continues after a failed write, reports partial success and does not automatically retry', async () => {
      auth.authedFetch
        .mockRejectedValueOnce(new Error('connection lost: outcome unknown'))
        .mockResolvedValueOnce(mockResponse({status:201,json:{id:'q2',name:'b'}}))
        .mockResolvedValueOnce(mockResponse({status:201,json:{id:'q3',name:'c'}}));
      const client = createClient(auth, config);
      const query = (name: string) => ({name,dataSourceId:'ds1',kind:'runjs',options:{code:'return [];'}});
      await expect(client.createQueries({versionId:'v1',queries:[query('a'),query('b')]})).rejects.toMatchObject({completed:[{query_id:'q2',name:'b'}]});
      await expect(client.createQuery({versionId:'v1',...query('c')})).resolves.toEqual({query_id:'q3',name:'c'});
      expect(auth.authedFetch).toHaveBeenCalledTimes(3);
    });
    it('fans out to one create call per query and returns all results', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'q1', name: 'a' } }))
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'q2', name: 'b' } }));

      const client = createClient(auth, config);
      const result = await client.createQueries({
        versionId: 'ver1',
        queries: [
          { dataSourceId: 'ds1', name: 'a', options: { operation: 'list_rows' }, kind: 'tooljetdb' },
          { dataSourceId: 'ds1', name: 'b', options: { operation: 'list_rows' }, kind: 'tooljetdb' },
        ],
      });

      expect(auth.authedFetch).toHaveBeenCalledTimes(2);
      expect(result).toEqual([
        { query_id: 'q1', name: 'a' },
        { query_id: 'q2', name: 'b' },
      ]);
    });

    it('reports successful query ids when another query in the batch fails', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 201, json: { id: 'q1', name: 'a' } }))
        .mockResolvedValueOnce(mockResponse({ status: 422, text: 'invalid options' }));

      const client = createClient(auth, config);
      let caught: unknown;
      try {
        await client.createQueries({
          versionId: 'ver1',
          queries: [
            { dataSourceId: 'ds1', name: 'a', options: {}, kind: 'tooljetdb' },
            { dataSourceId: 'ds1', name: 'b', options: {}, kind: 'tooljetdb' },
          ],
        });
      } catch (error) {
        caught = error;
      }

      expect(caught).toBeInstanceOf(PartialWriteError);
      expect((caught as PartialWriteError<unknown>).completed).toEqual([{ query_id: 'q1', name: 'a' }]);
      expect(String(caught)).toMatch(/Persisted before failure.*q1.*b.*invalid options.*not deleted/i);
    });
  });

  describe('updateComponents', () => {
    it('wraps a definition change under component.definition, keyed by existing id, with pageId', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateComponents({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        updates: [{ componentId: 'c-1', definition: { properties: { text: { value: 'NEW' } } } }],
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/components');
      expect(init.method).toBe('PUT');
      expect(JSON.parse(init.body)).toEqual({
        is_user_switched_version: false,
        pageId: 'page-home',
        diff: { 'c-1': { component: { definition: { properties: { text: { value: 'NEW' } } } } } },
      });
    });

    it('sends a rename as a raw column change (no definition key)', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateComponents({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        updates: [{ componentId: 'c-1', name: 'renamed' }],
      });
      expect(JSON.parse(auth.authedFetch.mock.calls[0][1].body).diff).toEqual({
        'c-1': { component: { name: 'renamed' } },
      });
    });

    it('encodes slot-aware reparenting as ToolJet\'s suffixed parent id', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateComponents({
        appId: 'app1', versionId: 'ver1', pageId: 'page-home',
        updates: [{ componentId: 'c-1', parent: 'modal-1', slotName: 'footer' }],
      });
      expect(JSON.parse(auth.authedFetch.mock.calls[0][1].body).diff).toEqual({
        'c-1': { component: { parent: 'modal-1-footer' } },
      });
    });

    it('preserves an explicitly supplied raw parent id when slotName is omitted', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateComponents({
        appId: 'app1', versionId: 'ver1', pageId: 'page-home',
        updates: [{ componentId: 'c-1', parent: 'modal-1-header' }],
      });
      expect(JSON.parse(auth.authedFetch.mock.calls[0][1].body).diff).toEqual({
        'c-1': { component: { parent: 'modal-1-header' } },
      });
    });

    it('rejects mixing definition with name/parent in one entry', async () => {
      const client = createClient(auth, config);
      await expect(
        client.updateComponents({
          appId: 'app1',
          versionId: 'ver1',
          pageId: 'page-home',
          updates: [{ componentId: 'c-1', name: 'x', definition: { styles: { textSize: { value: 20 } } } }],
        })
      ).rejects.toThrow(/set EITHER definition .* OR name\/parent/);
      expect(auth.authedFetch).not.toHaveBeenCalled();
    });
  });

  describe('deleteComponents', () => {
    it('DELETEs with diff as a bare array of ids', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      const r = await client.deleteComponents({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        componentIds: ['c-1', 'c-2'],
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/components');
      expect(init.method).toBe('DELETE');
      expect(JSON.parse(init.body)).toEqual({
        is_user_switched_version: false,
        pageId: 'page-home',
        diff: ['c-1', 'c-2'],
      });
      expect(r).toEqual({ deleted: 2 });
    });
  });

  describe('updateLayouts', () => {
    it('PUTs to /components/layout with only the provided resolutions', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateLayouts({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-home',
        layouts: [{ componentId: 'c-1', desktop: { top: 8, left: 5, width: 15, height: 6 } }],
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/components/layout');
      expect(init.method).toBe('PUT');
      expect(JSON.parse(init.body).diff).toEqual({
        'c-1': { layouts: { desktop: { top: 8, left: 5, width: 15, height: 6 } } },
      });
    });
  });

  describe('updateQuery / deleteQuery', () => {
    it('PATCHes name+options (options replace wholesale)', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateQuery({ queryId: 'q1', versionId: 'ver1', name: 'q', options: { a: 1 } });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/data-queries/q1/versions/ver1');
      expect(init.method).toBe('PATCH');
      expect(JSON.parse(init.body)).toEqual({ options: { a: 1 }, name: 'q' });
    });

    it('DELETEs a query with no body', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.deleteQuery({ queryId: 'q1', versionId: 'ver1' });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/data-queries/q1/versions/ver1');
      expect(init.method).toBe('DELETE');
    });

    it('repoints a query datasource through the dedicated route', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateQueryDatasource({ queryId: 'q1', versionId: 'ver1', dataSourceId: 'ds2' });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/data-queries/q1/versions/ver1/data-source');
      expect(init.method).toBe('PUT');
      expect(JSON.parse(init.body)).toEqual({ data_source_id: 'ds2' });
    });
  });

  describe('deletePage', () => {
    it('calls the v2 page delete endpoint with the page id and association choice', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 204 }));
      const client = createClient(auth, config);
      const result = await client.deletePage({
        appId: 'app1',
        versionId: 'ver1',
        pageId: 'page-analytics',
        deleteAssociatedPages: false,
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/pages');
      expect(init.method).toBe('DELETE');
      expect(JSON.parse(init.body)).toEqual({ pageId: 'page-analytics', deleteAssociatedPages: false });
      expect(result).toEqual({ deleted: true });
    });
  });

  describe('getPluginSpec', () => {
    it('reads a raw spec through the authenticated metadata route with encoded segments', async () => {
      const spec = 'openapi: 3.0.0\npaths: {}\n';
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ text: spec }));
      expect(await createClient(auth, config).getPluginSpec('example plugin', 'service/cases')).toBe(spec);
      expect(auth.authedFetch).toHaveBeenCalledWith('/api/plugins/specs/example%20plugin/service%2Fcases');
    });

    it('surfaces denied or missing spec responses instead of parsing them as API metadata', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 403, text: 'Forbidden' }));
      await expect(createClient(auth, config).getPluginSpec('hubspot', 'tickets')).rejects.toThrow('getPluginSpec');
    });
  });

  describe('runQuery', () => {
    it('resolves the dev env, POSTs to /run/:env with empty options, returns the result', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { environments: [{ id: 'env-dev', name: 'development' }] } }))
        .mockResolvedValueOnce(mockResponse({ status: 200, json: { status: 'ok', data: [{ id: 1 }] } }));
      const client = createClient(auth, config);
      const r = await client.runQuery({ queryId: 'q1', versionId: 'ver1' });
      const [path, init] = auth.authedFetch.mock.calls[1];
      expect(path).toBe('/api/data-queries/q1/versions/ver1/run/env-dev');
      expect(init.method).toBe('POST');
      expect(JSON.parse(init.body)).toEqual({ resolvedOptions: {}, options: {} });
      expect(r).toEqual({ status: 'ok', data: [{ id: 1 }] });
    });

    it('invokes one datasource metadata method with explicit narrow args', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({ status: 200, json: { status: 'ok', data: [{ value: 'public', label: 'public' }] } })
      );
      const client = createClient(auth, config);
      const result = await client.invokeDatasourceMethod({
        dataSourceId: 'pg1',
        method: 'listTables',
        environmentId: 'env-dev',
        args: { values: { schema: 'public' }, search: 'tick', limit: 20 },
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/data-sources/pg1/invoke');
      expect(JSON.parse(init.body)).toEqual({
        method: 'listTables',
        environmentId: 'env-dev',
        args: { values: { schema: 'public' }, search: 'tick', limit: 20 },
      });
      expect(result.status).toBe('ok');
    });
  });

  describe('events: list / update / delete', () => {
    it('lists events filtered by sourceId and projects fields', async () => {
      auth.authedFetch.mockResolvedValueOnce(
        mockResponse({
          status: 200,
          json: [
            { id: 'e1', name: 'n', index: 0, event: { actionId: 'run-query' }, sourceId: 'c-1', target: 'component', appVersionId: 'ver1' },
          ],
        })
      );
      const client = createClient(auth, config);
      const evs = await client.listEvents({ appId: 'app1', versionId: 'ver1', sourceId: 'c-1' });
      expect(auth.authedFetch).toHaveBeenCalledWith('/api/v2/apps/app1/versions/ver1/events?sourceId=c-1');
      expect(evs).toEqual([
        { id: 'e1', name: 'n', index: 0, event: { actionId: 'run-query' }, sourceId: 'c-1', target: 'component' },
      ]);
    });

    it('PUT update sends {event_id, diff:{name,event}} + updateType', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: [] }));
      const client = createClient(auth, config);
      await client.updateEvents({
        appId: 'app1',
        versionId: 'ver1',
        events: [{ eventId: 'e1', name: 'n', event: { actionId: 'show-alert', message: 'hi' } }],
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/events');
      expect(init.method).toBe('PUT');
      expect(JSON.parse(init.body)).toEqual({
        updateType: 'update',
        events: [{ event_id: 'e1', diff: { name: 'n', event: { actionId: 'show-alert', message: 'hi' } } }],
      });
    });

    it('DELETEs one event by id', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.deleteEvent({ appId: 'app1', versionId: 'ver1', eventId: 'e1' });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1/events/e1');
      expect(init.method).toBe('DELETE');
    });
  });

  describe('app settings', () => {
    it('reads settings from the native version endpoint without the app endpoint snake-case corruption', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {
        id: 'app1',
        editing_version: {
          id: 'ver1',
          globalSettings: { appMode: 'dark' },
          pageSettings: {
            properties: {
              hideHeader: true,
              disableMenu: { value: '{{true}}', fxActive: false },
            },
          },
          showViewerNavigation: true,
        },
      } }));
      const client = createClient(auth, config);
      await expect(client.getAppSettings('app1', 'ver1')).resolves.toEqual({
        app_id: 'app1', version_id: 'ver1',
        global_settings: { appMode: 'dark' },
        page_settings: {
          properties: {
            hideHeader: true,
            disableMenu: { value: '{{true}}', fxActive: false },
          },
        },
      });
      expect(auth.authedFetch).toHaveBeenCalledWith('/api/v2/apps/app1/versions/ver1');
    });

    it('rejects a response for a different editing version', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {
        id: 'app1', editing_version: { id: 'ver2' },
      } }));
      const client = createClient(auth, config);
      await expect(client.getAppSettings('app1', 'ver1')).rejects.toThrow(/not the current editing version/i);
    });

    it('updates global and page settings through one exact version PUT', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: {} }));
      const client = createClient(auth, config);
      await client.updateAppSettings({
        appId: 'app1', versionId: 'ver1',
        globalSettings: { appMode: 'auto' },
        pageSettings: { properties: { hideHeader: true } },
      });
      const [path, init] = auth.authedFetch.mock.calls[0];
      expect(path).toBe('/api/v2/apps/app1/versions/ver1');
      expect(init.method).toBe('PUT');
      expect(JSON.parse(init.body)).toEqual({
        globalSettings: { appMode: 'auto' },
        pageSettings: { properties: { hideHeader: true } },
      });
    });

    it('lists themes from the workspace theme endpoint', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({ status: 200, json: [
        { id: 'theme1', name: 'ToolJet', definition: {} },
      ] }));
      const themes = await createClient(auth, config).listAppThemes();
      expect(auth.authedFetch).toHaveBeenCalledWith('/api/themes');
      expect(themes).toEqual([{ id: 'theme1', name: 'ToolJet', definition: {} }]);
    });
  });

  describe('workspace users', () => {
    it('lists the PAT workspace users with the requested filters', async () => {
      auth.authedFetch.mockResolvedValueOnce(mockResponse({
        status: 200,
        json: { users: [], meta: { total_pages: 1, total_count: 0, current_page: 3 } },
      }));

      await createClient(auth, config).listWorkspaceUsers({ page: 3, searchText: 'sam', status: 'active' });

      expect(auth.authedFetch).toHaveBeenCalledWith('/api/organization-users?page=3&searchText=sam&status=active');
    });

    it('updates and archives the exact organization-user id', async () => {
      auth.authedFetch
        .mockResolvedValueOnce(mockResponse({ status: 200 }))
        .mockResolvedValueOnce(mockResponse({ status: 201 }));
      const client = createClient(auth, config);

      await client.updateWorkspaceUser('org-user-1', { role: 'builder', addGroupIds: ['group-1'] });
      await client.setWorkspaceUserArchived('org-user-1', true);

      expect(auth.authedFetch).toHaveBeenNthCalledWith(1, '/api/organization-users/org-user-1', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'builder', addGroups: ['group-1'] }),
      });
      expect(auth.authedFetch).toHaveBeenNthCalledWith(2, '/api/organization-users/org-user-1/archive', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      });
    });
  });
});
