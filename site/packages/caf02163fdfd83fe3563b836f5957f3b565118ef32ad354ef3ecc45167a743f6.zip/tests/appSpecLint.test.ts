import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { ToolJetClient } from '../src/tooljetClient.js';
import { lintAppSpecTool } from '../src/tools/lintAppSpec.js';
import { lintPlannedApp } from '../src/appSpecLint.js';
import { clearAppPlansForTests, consumeAppPlan } from '../src/appPlanStore.js';

function textOf(result: { content: Array<{ text: string }> }): any {
  return JSON.parse(result.content[0]!.text);
}

describe('lint_app_spec', () => {
  beforeEach(() => clearAppPlansForTests());

  it('blocks a planned bulk upsert on a unique non-primary key, while accepting implicit id', async () => {
    const client={listTables:vi.fn().mockResolvedValue([]),listDatasources:vi.fn().mockResolvedValue([{id:'db',kind:'tooljetdb'}])} as unknown as ToolJetClient;
    for (const key of ['finding_key','id']) {
      const body=textOf(await lintAppSpecTool(client).handler({version_id:'v1',
        tables:[{table_name:'findings',columns:[{name:'finding_key',type:'varchar',unique:true}]}],
        queries:[{datasource_id:'db',name:'saveFindings',table_ref:'findings',options:{operation:'bulk_upsert_with_primary_key',bulk_upsert_with_primary_key:{primary_key:[key],rows:[]}}}],
      }));
      expect(body.ok).toBe(key === 'id');
      if (key !== 'id') { expect(body.plan_token).toBeUndefined(); expect(body.errors.join(' ')).toContain('actual PRIMARY KEY'); }
    }
  });

  it('rejects obvious invalid seed timestamps before issuing a writable phase token', async () => {
    const client = { listTables: vi.fn().mockResolvedValue([]) } as unknown as ToolJetClient;
    const body = textOf(await lintAppSpecTool(client).handler({
      tables: [{ table_name: 'jobs', columns: [{name:'created_at',type:'timestamp'}] }],
      seed_data: [{table_name:'jobs',rows:[{created_at:'2026-09-16T00:00:00Z'},{created_at:'3'}]}],
    }));
    expect(body.ok).toBe(false);
    expect(body.plan_token).toBeUndefined();
    expect(body.errors.join(' ')).toMatch(/created_at.*row\(s\) 2/);
  });

  it('resolves an exact unique datasource name within the version and pins the ID in the plan', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]),
    } as unknown as ToolJetClient;
    const query = { datasource_name: 'runjsdefault', name: 'transform', options: { code: 'return 1;' } };
    const body = textOf(await lintAppSpecTool(client).handler({ version_id: 'v1', queries: [query] }));
    expect(body.ok).toBe(true);
    expect(client.listDatasources).toHaveBeenCalledExactlyOnceWith('v1');
    expect(consumeAppPlan(body.plan_token).spec.queries).toEqual([
      { datasource_id: 'js-source', name: 'transform', options: { code: 'return 1;' } },
    ]);
    expect(query).toHaveProperty('datasource_name', 'runjsdefault');
    expect(query).not.toHaveProperty('datasource_id');
  });

  it.each([
    ['missing selector', {}, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]],
    ['two selectors', { datasource_id: 'js-source', datasource_name: 'runjsdefault' }, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]],
    ['unknown name', { datasource_name: 'other' }, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]],
    ['case mismatch', { datasource_name: 'RunJsDefault' }, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]],
    ['empty name', { datasource_name: '' }, [{ id: 'js-source', name: '', kind: 'runjs' }]],
    ['ambiguous name', { datasource_name: 'runjsdefault' }, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }, { id: 'other', name: 'runjsdefault', kind: 'runjs' }]],
    ['spliced ID is not repaired', { datasource_id: 'js-spliced' }, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]],
    ['kind mismatch', { datasource_name: 'runjsdefault', kind: 'tooljetdb' }, [{ id: 'js-source', name: 'runjsdefault', kind: 'runjs' }]],
  ])('refuses %s without issuing a plan token', async (_label, selector, sources) => {
    const client = { listDatasources: vi.fn().mockResolvedValue(sources) } as unknown as ToolJetClient;
    const body = textOf(await lintAppSpecTool(client).handler({
      version_id: 'v1', queries: [{ ...selector, name: 'transform', options: { code: 'return 1;' } }],
    }));
    expect(body.ok).toBe(false);
    expect(body.plan_token).toBeUndefined();
  });

  it('resolves a planned table by table_name, never a table alias', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', name: 'tooljetdbdefault', kind: 'tooljetdb' }]),
      listTables: vi.fn().mockResolvedValue([]),
    } as unknown as ToolJetClient;
    const args = {
      version_id: 'v1', tables: [{ table_name: 'actual_jobs', columns: [{ name: 'job', type: 'varchar' }] }],
      queries: [{ datasource_name: 'tooljetdbdefault', name: 'listJobs', table_ref: 'jobs_alias',
        options: { operation: 'list_rows', list_rows: { limit: 20 } } }],
    };
    const bad = textOf(await lintAppSpecTool(client).handler(args));
    expect(bad.ok).toBe(false);
    expect(bad.errors.join(' ')).toContain('actual table_name');
    args.queries[0]!.table_ref = 'actual_jobs';
    const good = textOf(await lintAppSpecTool(client).handler(args));
    expect(good.ok).toBe(true);
    expect(consumeAppPlan(good.plan_token).spec.queries?.[0]?.datasource_id).toBe('tjdb');
  });

  it('checks planned custom-key updates, includes implicit id, and leaves all predicates untouched', async () => {
    const client = {
      listTables: vi.fn().mockResolvedValue([]),
      listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', kind: 'tooljetdb' }]),
      getTableSchema: vi.fn(),
    } as unknown as ToolJetClient;
    const options = { operation: 'update_rows', update_rows: {
      columns: { 0: { column: 'state', value: 'Approved' } },
      where_filters: { 0: { column: 'reference', operator: 'eq', value: 'R1' } },
    } };
    const before = structuredClone(options);
    for (const primaryKey of [true, false]) {
      const body = textOf(await lintAppSpecTool(client).handler({
        version_id: 'v1',
        tables: [{ table_name: 'requests', columns: [
          { name: 'reference', type: 'string', primaryKey }, { name: 'state', type: 'string' },
        ] }],
        queries: [{ datasource_id: 'tjdb', name: 'save', table_ref: 'requests', options }],
      }));
      expect(body.ok).toBe(true);
      expect(body.warnings.some((warning: string) => warning.includes('has no id column'))).toBe(primaryKey);
    }
    expect(client.getTableSchema).not.toHaveBeenCalled();
    expect(options).toEqual(before);
  });

  it('inspects each existing update target once, not unrelated tables or list-only targets', async () => {
    const client = {
      listTables: vi.fn().mockResolvedValue([
        { id: 't1', table_name: 'requests' }, { id: 't2', table_name: 'unrelated' },
      ]),
      listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', kind: 'tooljetdb' }]),
      getTableSchema: vi.fn().mockResolvedValue([{ name: 'request_id', isPrimaryKey: true }, { name: 'state' }]),
    } as unknown as ToolJetClient;
    const queries = ['approve', 'reject'].map(name => ({
      datasource_id: 'tjdb', name, table_ref: 'requests', options: {
        operation: 'update_rows', update_rows: {
          columns: { 0: { column: 'state', value: name } },
          where_filters: { 0: { column: 'request_id', operator: 'eq', value: 'R1' } },
        },
      },
    }));
    const body = textOf(await lintAppSpecTool(client).handler({ version_id: 'v1', queries }));
    expect(body.ok).toBe(true);
    expect(body.warnings.filter((warning: string) => warning.includes('has no id column'))).toHaveLength(2);
    expect(client.getTableSchema).toHaveBeenCalledExactlyOnceWith('requests');
    vi.mocked(client.getTableSchema).mockClear();
    await lintAppSpecTool(client).handler({ version_id: 'v1', queries: [{
      datasource_id: 'tjdb', name: 'list', table_ref: 'requests', options: { operation: 'list_rows', list_rows: {} },
    }] });
    expect(client.getTableSchema).not.toHaveBeenCalled();
    vi.mocked(client.getTableSchema).mockRejectedValue(new Error('Unavailable'));
    const failedRead = textOf(await lintAppSpecTool(client).handler({ version_id: 'v1', queries }));
    expect(failedRead.warnings.join(' ')).toContain('primary-key compatibility was not checked');
    expect(failedRead.warnings.join(' ')).not.toContain('has no id column');
  });

  it('validates a complete planned flow through logical refs without writing', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', name: 'ToolJet DB', kind: 'tooljetdb' }]),
      listTables: vi.fn().mockResolvedValue([{ id: 't1', table_name: 'existing' }]),
    } as unknown as ToolJetClient;
    const result = await lintAppSpecTool(client).handler({
      version_id: 'v1',
      tables: [{ table_name: 'cases', columns: [{ name: 'title', type: 'string' }] }],
      queries: [
        { client_ref: 'list', datasource_id: 'tjdb', name: 'list_cases', options: { operation: 'list_rows', table_id: 't1', list_rows: {} } },
        {
          client_ref: 'create', datasource_id: 'tjdb', name: 'create_case',
          options: { operation: 'create_row', table_id: 't1', create_row: { 0: { column: 'title', value: '{{components.caseTitle.value}}' } } },
        },
      ],
      pages: [{
        client_ref: 'home', name: 'Home', icon: 'IconHome2',
        components: [
          {
            client_ref: 'caseTitle', name: 'caseTitle', type: 'TextInput',
            properties: { label: { value: 'Title' } }, styles: { alignment: { value: 'top' } },
            layout: { top: 20, left: 2, width: 20, height: 40 },
          },
          {
            client_ref: 'save', name: 'saveCase', type: 'Button', properties: { text: { value: 'Save' } },
            layout: { top: 120, left: 2, width: 6, height: 40 },
          },
        ],
      }],
      events: [{
        source_ref: 'save', source_type: 'component', trigger: 'onClick',
        action: { actionId: 'run-query', target_ref: 'create' },
      }],
      lifecycles: [{
        query_ref: 'create', refresh_query_refs: ['list'], clear_component_refs: ['caseTitle'],
        success_alert: { message: 'Created' }, failure_alert: { message: 'Failed' },
      }],
    });
    const body = textOf(result);
    expect(body.ok).toBe(true);
    expect(body.counts).toMatchObject({ tables: 1, seed_rows: 0, pages: 1, components: 2, queries: 2, events: 5, lifecycles: 1 });
    expect(body.plan_token).toEqual(expect.any(String));
    expect(client.listDatasources).toHaveBeenCalledOnce();
  });

  it('turns an unseeded integer primary key into a serial key instead of failing the plan', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([]),
      listTables: vi.fn().mockResolvedValue([{ id: 't1', table_name: 'existing' }]),
    } as unknown as ToolJetClient;
    const tables = [{
      table_name: 'flights',
      columns: [{ name: 'id', type: 'integer', primaryKey: true }, { name: 'flight_no', type: 'string', notNull: true }],
    }];
    const result = await lintAppSpecTool(client).handler({
      tables,
      seed_data: [{ table_name: 'flights', rows: [{ flight_no: 'AI101' }, { flight_no: 'AI131' }] }],
    });
    const body = textOf(result);
    expect(body.ok).toBe(true);
    expect(body.plan_token).toEqual(expect.any(String));
    expect(body.errors.join(' ')).not.toMatch(/omits required non-generated column/);
    expect(body.warnings.join(' ')).toMatch(/primary key "id".*created as "serial"/i);
    expect(tables[0]!.columns[0]!.type).toBe('serial'); // the stored plan creates it generated

    // A required column that some rows do supply is still a real omission.
    const partial = textOf(await lintAppSpecTool(client).handler({
      tables: [{ table_name: 'crews', columns: [{ name: 'id', type: 'integer', primaryKey: true }] }],
      seed_data: [{ table_name: 'crews', rows: [{ id: 1 }, {}] }],
    }));
    expect(partial.ok).toBe(false);
    expect(partial.errors.join(' ')).toMatch(/omits required non-generated column "id" in row\(s\) 2/);
  });

  it('blocks oversized standard single-line fields before issuing a plan token', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([]),
      listTables: vi.fn().mockResolvedValue([{ id: 't1', table_name: 'existing' }]),
    } as unknown as ToolJetClient;
    const result = await lintAppSpecTool(client).handler({
      pages: [{
        name: 'Log Bug', icon: 'IconBug',
        components: [
          {
            client_ref: 'title', name: 'bugTitle', type: 'TextInput',
            properties: { label: 'Title' }, styles: { alignment: 'top' },
            layout: { top: 100, left: 2, width: 39, height: 90 },
          },
          {
            client_ref: 'module', name: 'bugModule', type: 'DropdownV2',
            properties: { label: 'Module' }, styles: { alignment: 'top' },
            layout: { top: 220, left: 2, width: 18, height: 90 },
          },
        ],
      }],
    });

    const body = textOf(result);
    // Oversized single-line fields used to fail the plan; the height is deterministic, so lint now
    // lowers it and says so, and the plan proceeds.
    expect(body.ok).toBe(true);
    expect(body.plan_token).toBeDefined();
    expect(body.errors.join(' ')).not.toMatch(/exceeds the standard single-line height/i);
    expect(body.warnings.join(' ')).toMatch(/TextInput "bugTitle": lowered layout height 90px to the standard single-line 40px/i);
    expect(body.warnings.join(' ')).toMatch(/DropdownV2 "bugModule": lowered layout height 90px to the standard single-line 40px/i);
  });

  it('uses existing app context for repair bindings and event targets', async () => {
    const client = {
      getAppSummary: vi.fn().mockResolvedValue({
        app_id: 'app1', name: 'Returns', version_id: 'v1',
        pages: [{ id: 'home-id', name: 'Home', handle: 'home', icon: 'IconHome2', components: [] }],
        queries: [{
          id: 'returns-id', name: 'returnsPage', kind: 'tooljetdb', data_source_id: 'tjdb',
          options: { operation: 'list_rows', table_id: 'returns-table', list_rows: { limit: 7 } },
        }],
        events: [],
      }),
    } as unknown as ToolJetClient;

    const result = await lintAppSpecTool(client).handler({
      app_id: 'app1',
      version_id: 'v1',
      pages: [{
        client_ref: 'home', name: 'Home', icon: 'IconHome2',
        components: [
          {
            client_ref: 'count', name: 'returnCount', type: 'Text',
            properties: { text: '{{queries.returnsPage.data.length}}' },
            layout: { top: 20, left: 2, width: 12, height: 40 },
          },
          {
            client_ref: 'refresh', name: 'refreshReturns', type: 'Button',
            properties: { text: 'Refresh' }, layout: { top: 80, left: 2, width: 6, height: 40 },
          },
        ],
      }],
      events: [{
        source_ref: 'refresh', source_type: 'component', trigger: 'onClick',
        action: { actionId: 'run-query', target_ref: 'returnsPage' },
      }],
    });

    const body = textOf(result);
    expect(body.ok).toBe(true);
    expect(body.counts).toMatchObject({ pages: 1, components: 2, queries: 0, events: 1 });
    expect(body.warnings.join(' ')).not.toMatch(/no query is named "returnsPage"/i);
    expect(client.getAppSummary).toHaveBeenCalledWith('app1');
  });

  it('does not duplicate planned switch-page handlers into persisted chains', async () => {
    const client = {
      getAppSummary: vi.fn().mockResolvedValue({
        app_id: 'app1', name: 'Returns', version_id: 'v1',
        pages: [{
          id: 'queue-id', name: 'Returns Queue', handle: 'returns-queue', icon: 'IconListDetails',
          components: [{
            id: 'table-id', name: 'returnsTable', type: 'Table',
            properties: {
              columns: { value: [{
                id: 'actions', name: 'Actions', key: 'actions', columnType: 'button',
                autogenerated: false, buttons: [{ id: 'review', buttonLabel: 'Review' }],
              }] },
            },
          }],
        }],
        queries: [],
        events: [{
          id: 'alert-id', name: 'Review selected', sourceId: 'table-id', target: 'table_column', index: 0,
          event: { eventId: 'onClick', ref: 'actions::review', actionId: 'show-alert', message: 'Opening', alertType: 'info' },
        }],
      }),
    } as unknown as ToolJetClient;

    const result = await lintAppSpecTool(client).handler({
      app_id: 'app1', version_id: 'v1',
      pages: [{
        client_ref: 'review-page', name: 'Return Review', icon: 'IconClipboardCheck', hidden: true,
        components: [{
          client_ref: 'back', name: 'backToQueue', type: 'Button', properties: { text: 'Back' },
          layout: { top: 20, left: 2, width: 8, height: 40 },
        }],
      }],
      events: [
        {
          source_ref: 'returnsTable', source_type: 'table_column', ref: 'actions::review', trigger: 'onClick',
          action: { actionId: 'switch-page', target_ref: 'review-page' }, name: 'Open return review',
        },
        {
          source_ref: 'back', source_type: 'component', trigger: 'onClick',
          action: { actionId: 'switch-page', target_ref: 'Returns Queue' }, name: 'Back to returns queue',
        },
      ],
    });

    const body = textOf(result);
    expect(body.ok).toBe(true);
    expect(body.errors).toEqual([]);
  });

  it('collects mechanical failures across tables, components, queries, and events in one pass', async () => {
    const client = { listDatasources: vi.fn(), listTables: vi.fn().mockResolvedValue([]) } as unknown as ToolJetClient;
    const result = await lintAppSpecTool(client).handler({
      tables: [{ table_name: 'steps', columns: [{ name: 'action', type: 'string' }] }],
      queries: [{ datasource_id: 'tjdb', kind: 'tooljetdb', name: 'bad_query', options: { operation: 'list_rows', table_id: 't1', order_filters: [] } }],
      pages: [{
        name: 'Cases', icon: 'IconChecklist',
        components: [
          {
            client_ref: 'title', name: 'title', type: 'Text', properties: { text: { value: 'Large heading' } },
            styles: { textSize: { value: 32 }, fontWeight: { value: 'bold' } },
            layout: { top: 0, left: 0, width: 20, height: 40 },
          },
          {
            client_ref: 'save', name: 'save', type: 'Button', properties: { text: { value: 'Save' } },
            layout: { top: 60, left: 0, width: 6, height: 40 },
          },
        ],
      }],
      events: [{
        source_ref: 'save', source_type: 'component', trigger: 'onChange',
        action: { actionId: 'run-query', target_ref: 'missing' },
      }],
    });
    const body = textOf(result);
    expect(body.ok).toBe(false);
    expect(body.errors.join(' ')).toMatch(/reserved column name/i);
    expect(body.errors.join(' ')).toMatch(/unknown.*target_ref/i);
    expect(body.errors.join(' ')).toMatch(/trigger "onChange" is not valid for Button/i);
    expect(body.warnings.join(' ')).toMatch(/order_filters|Unknown option key/i);
    expect(body.errors.join(' ')).not.toMatch(/too short to render one line/i);
    expect(body.warnings.join(' ')).toMatch(/Text "title": raised layout height 40px to 54px/i);
  });

  it('requires at least one spec section', async () => {
    const result = await lintAppSpecTool({} as ToolJetClient).handler({});
    expect(result.isError).toBe(true);
    expect(result.content[0]!.text).toMatch(/at least one table, seed_data batch, query, page, event, or lifecycle/i);
  });
});

describe('lint_app_spec table_id preflight', () => {
  it('rejects a ToolJet DB table_id that is not a workspace table and names the closest id', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', name: 'ToolJet DB', kind: 'tooljetdb' }]),
      listTables: vi.fn().mockResolvedValue([
        { id: 'cea811cf-122a-43ee-af86-f04ee2bb2268', table_name: 'hub_aircraft' },
        { id: '0a4470b8-481c-4fbe-96a1-34053e027cdf', table_name: 'hub_crew' },
      ]),
    } as unknown as ToolJetClient;
    const result = await lintAppSpecTool(client).handler({
      version_id: 'v1',
      queries: [{
        datasource_id: 'tjdb', name: 'maintenanceAircraft',
        // the aircraft table's prefix fused with the crew table's tail, as Luna and Gemini Pro produced
        options: { operation: 'list_rows', table_id: 'cea811cf-122a-43be-96a1-34053e027cdf', list_rows: { limit: 50 }, runOnPageLoad: true },
      }],
    });
    const body = textOf(result);
    expect(body.ok).toBe(false);
    expect(body.errors.join(' ')).toMatch(/not a table in this workspace; the closest id is hub_aircraft \(cea811cf-122a-43ee-af86-f04ee2bb2268\)/);
    expect(body.errors.join(' ')).toMatch(/Use table_ref/);
  });

  it('accepts a table_id that exists and never lists tables when no query names one', async () => {
    const listTables = vi.fn().mockResolvedValue([{ id: 't9', table_name: 'flights' }]);
    const client = {
      listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', name: 'ToolJet DB', kind: 'tooljetdb' }]),
      listTables,
    } as unknown as ToolJetClient;
    const ok = await lintAppSpecTool(client).handler({
      version_id: 'v1',
      queries: [{ datasource_id: 'tjdb', name: 'flights', options: { operation: 'list_rows', table_id: 't9', list_rows: { limit: 25 }, runOnPageLoad: true } }],
    });
    expect(textOf(ok).ok).toBe(true);
    expect(listTables).toHaveBeenCalledTimes(1);
  });
});

describe('plan lint error de-duplication', () => {
  it('reports an Html render error once, with its page prefix', () => {
    const html = {
      client_ref: 'hdr', name: 'OverviewHeader', type: 'Html',
      properties: { rawHtml: { value: '<div style="height:100%;background:var(--cc-surface);padding:24px"><h1 style="font-size:32px;margin:0">Operations</h1><p style="margin:8px 0 0">Today</p><p style="margin:8px 0 0">More</p></div>' } },
      layouts: { desktop: { left: 0, top: 0, width: 43, height: 60 } },
    };
    const result = lintPlannedApp({ pages: [{ client_ref: 'home', name: 'Home', icon: 'IconHome2', components: [html] }] } as any);
    const heightErrors = result.errors.filter((e) => e.includes('its markup needs about'));
    expect(heightErrors).toHaveLength(1);
    expect(heightErrors[0]).toMatch(/^Page "Home": Html "OverviewHeader"/);
  });
});

describe('plan preflight repairs', () => {
  const client = () => ({
    listDatasources: vi.fn().mockResolvedValue([{ id: 'tjdb', name: 'ToolJet DB', kind: 'tooljetdb' }]),
    listTables: vi.fn().mockResolvedValue([{ id: 't1', table_name: 'orders' }, { id: 't2', table_name: 'orders_2' }]),
  }) as unknown as ToolJetClient;

  it('renames a planned table that already exists and carries the name into seeds, table_ref and foreign keys', async () => {
    const args = {
      version_id: 'v1',
      tables: [
        { table_name: 'orders', columns: [{ name: 'id', type: 'serial', primaryKey: true }, { name: 'total', type: 'number' }] },
        { table_name: 'order_items', columns: [{ name: 'order_id', type: 'integer' }], foreign_keys: [{ columns: ['order_id'], referencedTable: 'orders', referencedColumns: ['id'] }] },
      ],
      seed_data: [{ table_name: 'orders', rows: [{ total: 10 }] }],
      queries: [{ client_ref: 'q', datasource_id: 'tjdb', name: 'list_orders', table_ref: 'orders', options: { operation: 'list_rows', list_rows: { limit: 50 } } }],
      pages: [{ client_ref: 'home', name: 'Home', icon: 'IconHome2', components: [] }],
    };
    const result = await lintAppSpecTool(client()).handler(args as never);
    const parsed = JSON.parse(result.content[0]!.text!);
    expect(parsed.errors).toEqual([]);
    expect(parsed.warnings.join(' ')).toMatch(/"orders" already exists in this workspace, so it is created as "orders_3"/);
    expect(args.tables[0]!.table_name).toBe('orders_3');
    expect(args.seed_data[0]!.table_name).toBe('orders_3');
    expect(args.queries[0]!.table_ref).toBe('orders_3');
    expect(args.tables[1]!.foreign_keys![0]!.referencedTable).toBe('orders_3');
  });

  it.each([
    'SELECT id, total FROM orders LIMIT 10',
    'UPDATE orders SET total = 20 WHERE id = 1',
    'SELECT o.id FROM "orders" o JOIN order_items i ON i.order_id = o.id',
    'SELECT i.order_id FROM order_items i JOIN orders o ON o.id = i.order_id',
  ])('rejects a colliding table without silently redirecting SQL: %s', async (sql) => {
    const args = {
      version_id: 'v1',
      tables: [{ table_name: 'orders', columns: [{ name: 'total', type: 'number' }] }],
      seed_data: [{ table_name: 'orders', rows: [{ total: 10 }] }],
      queries: [{ datasource_id: 'tjdb', name: 'orders_sql', table_ref: 'orders',
        options: { operation: 'sql_execution', sql_execution: { sqlQuery: sql } } }],
    };
    const before = structuredClone(args);
    const parsed = textOf(await lintAppSpecTool(client()).handler(args));
    expect(parsed.ok).toBe(false);
    expect(parsed.plan_token).toBeUndefined();
    expect(parsed.errors.join(' ')).toContain('SQL');
    expect(parsed.errors.join(' ')).toContain('Rename');
    expect(args).toEqual(before);
  });

  it('accepts a revised SQL plan with a unique table name and consistent references', async () => {
    const args = {
      version_id: 'v1',
      tables: [{ table_name: 'new_orders', columns: [{ name: 'total', type: 'number' }] }],
      seed_data: [{ table_name: 'new_orders', rows: [{ total: 10 }] }],
      queries: [{ datasource_id: 'tjdb', name: 'list_orders', table_ref: 'new_orders',
        options: { operation: 'sql_execution', sql_execution: { sqlQuery: 'SELECT total FROM new_orders LIMIT 10' } } }],
    };
    const parsed = textOf(await lintAppSpecTool(client()).handler(args));
    expect(parsed.errors).toEqual([]);
    expect(parsed.ok).toBe(true);
    expect(parsed.plan_token).toEqual(expect.any(String));
  });

  it('also rejects a collision when the SQL query has no table_ref', async () => {
    const args = {
      version_id: 'v1',
      tables: [{ table_name: 'orders', columns: [{ name: 'total', type: 'number' }] }],
      queries: [{ datasource_id: 'tjdb', name: 'joined',
        options: { operation: 'sql_execution', sql_execution: { sqlQuery: 'SELECT * FROM orders JOIN order_items ON orders.id = order_items.order_id' } } }],
    };
    const parsed = textOf(await lintAppSpecTool(client()).handler(args));
    expect(parsed.ok).toBe(false);
    expect(parsed.plan_token).toBeUndefined();
    expect(args.tables[0].table_name).toBe('orders');
  });

  it('raises a short Html block to the height its markup needs and moves the components below it', async () => {
    const args = {
      version_id: 'v1',
      pages: [{
        client_ref: 'home', name: 'Home', icon: 'IconHome2',
        components: [
          { client_ref: 'hdr', name: 'header', type: 'Html', layout: { left: 0, top: 10, width: 43, height: 60 },
            properties: { rawHtml: { value: '<div style="height:100%;background:var(--cc-surface);padding:24px"><h1 style="font-size:32px;margin:0">Orders</h1><p style="margin:8px 0 0">Line one</p><p style="margin:8px 0 0">Line two</p><p style="margin:8px 0 0">Line three</p></div>' } } },
          { client_ref: 'tbl', name: 'orders', type: 'Table', layout: { left: 0, top: 80, width: 43, height: 400 },
            properties: { data: { value: '{{[]}}' }, dataSourceSelector: { value: 'rawJson' }, autogenerateColumns: { value: true } } },
          { client_ref: 'side', name: 'aside', type: 'Text', layout: { left: 30, top: 10, width: 10, height: 30 }, properties: { text: { value: 'Right of the header' } } },
        ],
      }],
    };
    const result = await lintAppSpecTool(client()).handler(args as never);
    const parsed = JSON.parse(result.content[0]!.text!);
    expect(parsed.errors.filter((e: string) => e.includes('its markup needs'))).toEqual([]);
    const fixed = parsed.warnings.find((w: string) => w.includes('so its height is now'));
    expect(fixed).toMatch(/Html "header" needed about \d+px .* was 60px, so its height is now (\d+)px and 1 component\(s\) below it moved down/);
    const newHeight = args.pages[0]!.components[0]!.layout.height;
    expect(newHeight).toBeGreaterThan(60);
    expect(args.pages[0]!.components[1]!.layout.top).toBe(80 + newHeight - 60);
    expect(args.pages[0]!.components[2]!.layout.top).toBe(10);
  });
});

describe('empty-page reuse guard', () => {
  it('refuses to create new pages while the app still has empty pages the plan ignores', async () => {
    const client = {
      listDatasources: vi.fn().mockResolvedValue([]),
      listTables: vi.fn().mockResolvedValue([]),
      getAppSummary: vi.fn().mockResolvedValue({
        app_id: 'app1', version_id: 'v1', events: [], queries: [],
        pages: [
          { id: 'home', name: 'Home', handle: 'home', components: [{ id: 'c', name: 'title', type: 'Text' }] },
          { id: 'p2', name: 'Orders', handle: 'orders', components: [] },
        ],
      }),
    } as unknown as ToolJetClient;
    const shadowing = await lintAppSpecTool(client).handler({
      app_id: 'app1', version_id: 'v1',
      pages: [{ client_ref: 'od', name: 'Orders Desk', icon: 'IconList', components: [] }],
    } as never);
    expect(JSON.parse(shadowing.content[0]!.text!).errors.join(' ')).toMatch(/empty page\(s\) this plan does not touch: "Orders"/);
    const reusing = await lintAppSpecTool(client).handler({
      app_id: 'app1', version_id: 'v1',
      pages: [{ client_ref: 'od', name: 'Orders', icon: 'IconList', components: [] }],
    } as never);
    expect(JSON.parse(reusing.content[0]!.text!).errors.filter((e: string) => e.includes('empty page'))).toEqual([]);
  });
});
