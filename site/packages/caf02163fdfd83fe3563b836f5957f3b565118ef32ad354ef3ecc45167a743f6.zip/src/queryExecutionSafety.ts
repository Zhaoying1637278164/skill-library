import { assessRedisRead } from './redisReadSafety.js';
import JSON5 from 'json5';
import { hubspotQueryIssues } from './hubspotQuery.js';
import type { QuerySummary, RunQueryResult } from './tooljetClient.js';

export const LARGE_READ_ROW_THRESHOLD = 1000;

const SQL_KINDS = new Set([
  'postgresql', 'mysql', 'mariadb', 'mssql', 'sqlserver', 'cockroachdb', 'redshift',
  'snowflake', 'bigquery', 'clickhouse', 'oracle', 'oracledb', 'sqlite',
  'databricks', 'athena', 'awsredshift', 'harperdb', 'ibmdb', 'saphana',
  // SQL dialects assessSql already parses; each keeps its SQL in one operation, and the write
  // operations carry no SQL field, so they still fall through to a refusal.
  'spanner', 'presto', 'cosmosdb', 'couchbase', 'salesforce',
]);

// ToolJet's kind string is `awsredshift`; the bare `redshift` entry never matched a real datasource.
const BILLABLE_SCAN_SQL_KINDS = new Set(['bigquery', 'snowflake', 'redshift', 'awsredshift', 'athena', 'databricks']);

interface ReadSource {
  kind: 'sql_table' | 'table_id' | 'gui_table' | 'remote_endpoint';
  value: string;
}

export interface QueryReadAssessment {
  provenRead: boolean;
  directSafe: boolean;
  countOnly: boolean;
  selectStar: boolean;
  requiresCountPreflight: boolean;
  requiresBillableReadConfirmation?: boolean;
  /** Remote API reads may expose sensitive data, consume quota, or return an unbounded payload. */
  requiresRemoteReadConfirmation?: boolean;
  /** True only when a count covers the entire simple source and can upper-bound a target read. */
  fullSourceCount?: boolean;
  /** True only for a single-table read whose cardinality is upper-bounded by a full-source count. */
  simpleSourceRead?: boolean;
  datasourceKind?: string;
  datasourceId?: string;
  source?: ReadSource;
  maxRows?: number;
  reason?: string;
}

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function staticPositiveInteger(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isInteger(value) && value > 0) return value;
  if (typeof value !== 'string') return undefined;
  const match = value.trim().match(/^(?:\{\{\s*)?(\d+)(?:\s*\}\})?$/);
  return match ? Number(match[1]) : undefined;
}

function containsBinding(value: unknown): boolean {
  if (typeof value === 'string') return value.includes('{{');
  if (Array.isArray(value)) return value.some(containsBinding);
  return !!record(value) && Object.values(record(value)!).some(containsBinding);
}

/* ServiceNow's Table API, split by effect.

   Without this, every ServiceNow query fell through to "no proven read classifier" and was refused
   before execution, so a connected ServiceNow instance could not be used to build anything: the
   agent could not run a single query to check its own work, and gave up with an empty app. Measured
   on a real build against a live ServiceNow datasource.

   Reads are proven but never directSafe, for the same reason REST GET is not: they cross into a
   remote system, where they consume quota and can return data the user did not expect to expose. */
const SERVICENOW_ROW_READS = new Set(['list_records']);
const SERVICENOW_SINGLE_READS = new Set(['get_record', 'aggregate']);
const SERVICENOW_METADATA_READS = new Set([
  'list_tables',
  'get_table_schema',
  'get_field_choices',
  'list_workflows',
  'list_flows',
]);

function assessServiceNow(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const identity = { datasourceKind: 'servicenow', ...(datasourceId ? { datasourceId } : {}) };
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : undefined;
  const table = typeof options.table === 'string' ? options.table.trim() : '';
  const source = table
    ? ({ kind: 'remote_endpoint', value: `servicenow:${table}` } as QueryReadAssessment['source'])
    : undefined;
  const refuse = (reason: string): QueryReadAssessment => ({
    provenRead: false, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, reason, ...identity,
  });

  if (!operation) return refuse('ServiceNow query has no operation.');

  // create/update/delete change records; invoke_workflow and trigger_flow start work inside
  // ServiceNow. None of them may be run to "see what happens".
  if (!SERVICENOW_ROW_READS.has(operation) && !SERVICENOW_SINGLE_READS.has(operation)
      && !SERVICENOW_METADATA_READS.has(operation)) {
    return refuse(`ServiceNow operation ${operation} is not a read; it can change ServiceNow state.`);
  }

  const remote = {
    provenRead: true as const, directSafe: false as const, selectStar: false as const,
    requiresCountPreflight: false as const, requiresRemoteReadConfirmation: true as const,
    ...(source ? { source } : {}), ...identity,
  };

  if (SERVICENOW_SINGLE_READS.has(operation)) {
    // get_record returns one record; aggregate returns one computed row.
    return { ...remote, countOnly: operation === 'aggregate', maxRows: 1,
      reason: `ServiceNow ${operation} reads remote data and consumes API quota.` };
  }

  if (SERVICENOW_METADATA_READS.has(operation)) {
    return { ...remote, countOnly: false,
      reason: `ServiceNow ${operation} reads remote metadata and consumes API quota.` };
  }

  // list_records: bounded only by sysparm_limit, which the plugin passes through as a string.
  const maxRows = staticPositiveInteger(options.sysparm_limit);
  if (maxRows === undefined) {
    return {
      ...remote, countOnly: false, requiresCountPreflight: true,
      reason: 'ServiceNow list_records has no static sysparm_limit, so its result size cannot be bounded.',
    };
  }
  if (maxRows > LARGE_READ_ROW_THRESHOLD) {
    return {
      ...remote, countOnly: false, requiresCountPreflight: true, maxRows,
      reason: `ServiceNow list_records can return up to ${maxRows} rows, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.`,
    };
  }
  return { ...remote, countOnly: false, maxRows, simpleSourceRead: true,
    reason: 'ServiceNow list_records reads remote data and consumes API quota.' };
}

/* OpenAPI, split by HTTP method.

   Without this, every openapi query fell through to "no proven read classifier" and was refused
   before execution, so the agent could not run a single query to check its own work and finished
   with an app whose components were bound to nothing. Same failure ServiceNow had.

   Only GET is a proven read: the other methods are declared by the spec to change remote state.
   Reads are never directSafe, exactly as REST GET is not — they cross into a remote system, consume
   quota, and can return data the user did not expect to expose. */
function assessOpenapi(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const identity = { datasourceKind: 'openapi', ...(datasourceId ? { datasourceId } : {}) };
  const refuse = (reason: string): QueryReadAssessment => ({
    provenRead: false, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, reason, ...identity,
  });

  // `operation` is the HTTP method for this kind, not a plugin operation name.
  const method = typeof options.operation === 'string' ? options.operation.toLowerCase() : undefined;
  if (method !== 'get') {
    return refuse(`OpenAPI method ${method ?? '<missing>'} is not a proven read; only GET queries can be previewed.`);
  }

  const path = typeof options.path === 'string' ? options.path.trim() : '';
  if (!path || containsBinding(path)) {
    return refuse('OpenAPI preview requires a non-empty static path; dynamic endpoints must be verified in the viewer.');
  }
  if (containsBinding(options.params) || containsBinding(options.host)) {
    return refuse('OpenAPI preview requires static host and parameters; binding-dependent requests must be verified in the viewer.');
  }

  const host = typeof options.host === 'string' ? options.host.trim() : '';
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, requiresRemoteReadConfirmation: true,
    source: { kind: 'remote_endpoint', value: `${host}${path}` },
    reason: 'OpenAPI GET may expose remote data, consume quota, or return an unbounded payload.',
    ...identity,
  };
}

/* InfluxDB's v2 API, split by effect.

   Without this, every InfluxDB query fell through to "no proven read classifier" and was refused
   before execution — the same failure mode ServiceNow had above. Measured on a real 2-page build
   (thread f4e3a7da): all three Flux queries were refused on every turn, so the agent never saw a
   response and shipped a guessed transformation it re-guessed twice more.

   Reads are proven but never directSafe: they cross into a remote system and can return an
   unbounded series. */
const INFLUX_ROW_READS = new Set(['query_data']);
const INFLUX_METADATA_READS = new Set([
  'list_buckets',
  'retrieve_bucket',
  'analyze_flux_query',
  'abstract_syntax_tree',
  'query_suggestions',
  'query_suggestions_for_branching',
]);

/* Flux is not read-only, and the writers are a family, not two names: `to()`, `experimental.to()`,
   `experimental.wideTo()`, `sql.to()`, `kafka.to()`, `mqtt.to()`. The package qualifier can be any
   identifier, so match a qualified OR bare call rather than naming the packages — a denylist of
   package names goes stale the moment Flux adds another writer.

   Matching `<anything>.to(` is safe here because Flux records have no methods: you cannot call a
   field, so a qualified `.to(` is always a package function, never user data. */
const FLUX_WRITE_CALL = /(^|[^A-Za-z0-9_])(?:[A-Za-z_][A-Za-z0-9_]*\s*\.\s*)?(?:wideTo|to)\s*\(/;

/* The other half of the family sends data somewhere else, or pulls secrets into the result. None of
   it belongs in a query run to check a build. Flux requires an explicit `import` for every one of
   these packages, so gate on the import: that catches the call however it is written or aliased. */
const FLUX_EGRESS_PACKAGES = [
  'sql', 'kafka', 'mqtt', 'http', 'slack', 'pagerduty', 'discord', 'teams', 'telegram',
  'bigpanda', 'opsgenie', 'sensu', 'servicenow', 'victorops', 'webexteams', 'zenoss', 'monitor',
  'influxdata/influxdb/secrets', 'influxdata/influxdb/tasks',
];
const FLUX_EGRESS_IMPORT = new RegExp(
  String.raw`(^|\n)\s*import\s+(?:[A-Za-z_][A-Za-z0-9_]*\s+)?"(?:` +
    FLUX_EGRESS_PACKAGES.map((name) => name.replace(/\//g, String.raw`\/`)).join('|') +
    String.raw`)"`
);

/* A Flux read is bounded by an explicit `limit(n:)`; a bare `range()` over a busy measurement can
   return millions of points. */
const FLUX_LIMIT = /(^|[^A-Za-z0-9_.])limit\s*\(\s*n\s*:\s*(\d+)/;

function assessInflux(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const identity = { datasourceKind: 'influxdb', ...(datasourceId ? { datasourceId } : {}) };
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : undefined;
  const refuse = (reason: string): QueryReadAssessment => ({
    provenRead: false, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, reason, ...identity,
  });

  if (!operation) return refuse('InfluxDB query has no operation.');

  // write appends points; create/update/delete_bucket change retention and can destroy series.
  if (!INFLUX_ROW_READS.has(operation) && !INFLUX_METADATA_READS.has(operation)) {
    return refuse(`InfluxDB operation ${operation} is not a read; it can change InfluxDB state.`);
  }

  const remote = {
    provenRead: true as const, directSafe: false as const, selectStar: false as const,
    requiresCountPreflight: false as const, requiresRemoteReadConfirmation: true as const,
    ...identity,
  };

  if (INFLUX_METADATA_READS.has(operation)) {
    return { ...remote, countOnly: false,
      reason: `InfluxDB ${operation} reads remote metadata without executing a query.` };
  }

  // query_data: the Flux script is the query, and it decides both effect and size.
  const body = typeof options.body === 'string' ? options.body : '';
  if (!body.trim()) return refuse('InfluxDB query_data has no Flux body to classify.');
  if (FLUX_WRITE_CALL.test(body)) {
    return refuse(
      'InfluxDB query_data body calls to()/wideTo(), which writes points or rows out of the query; that is not a read.'
    );
  }
  const egress = body.match(FLUX_EGRESS_IMPORT);
  if (egress) {
    return refuse(
      `InfluxDB query_data body imports ${egress[0].trim()}, which can send data out of InfluxDB or read secrets; ` +
        'that is not a read.'
    );
  }

  const bucket = body.match(/from\s*\(\s*bucket\s*:\s*"([^"]+)"/)?.[1];
  const source = bucket
    ? ({ kind: 'remote_endpoint', value: `influxdb:${bucket}` } as QueryReadAssessment['source'])
    : undefined;
  const bounded = { ...remote, countOnly: false, ...(source ? { source } : {}) };

  const maxRows = staticPositiveInteger(body.match(FLUX_LIMIT)?.[2]);
  if (maxRows === undefined) {
    return {
      ...bounded, requiresCountPreflight: true,
      reason: 'InfluxDB Flux query has no static limit(n:), so the number of points it returns cannot be bounded.',
    };
  }
  if (maxRows > LARGE_READ_ROW_THRESHOLD) {
    return {
      ...bounded, requiresCountPreflight: true, maxRows,
      reason: `InfluxDB Flux query can return up to ${maxRows} points, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.`,
    };
  }
  return { ...bounded, maxRows, reason: 'InfluxDB query_data reads remote time-series data.' };
}

function assessRestGet(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const identity = { datasourceKind: 'restapi', ...(datasourceId ? { datasourceId } : {}) };
  const method = typeof options.method === 'string' ? options.method.toLowerCase() : undefined;
  if (method !== 'get') {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false,
      reason: `REST method ${method ?? '<missing>'} is not a proven read; only static GET queries can be previewed.`,
      ...identity,
    };
  }
  const url = typeof options.url === 'string' ? options.url.trim() : '';
  if (!url || containsBinding(url)) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false,
      reason: 'REST GET preview requires a non-empty static url; dynamic endpoints must be verified in the viewer.',
      ...identity,
    };
  }
  const requestFields = ['url_params', 'headers', 'cookies'].map((key) => options[key]);
  if (requestFields.some(containsBinding)) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false,
      reason: 'REST GET preview requires static request parameters/headers/cookies; binding-dependent requests must be verified in the viewer.',
      ...identity,
    };
  }
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, requiresRemoteReadConfirmation: true,
    source: { kind: 'remote_endpoint', value: url },
    reason: 'REST GET may expose remote data, consume quota, or return an unbounded payload.',
    ...identity,
  };
}

function assessSupabase(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : '';
  const table = operation === 'count_rows' ? options.count_table_name : options.get_table_name;
  const identity = { datasourceKind: 'supabase', ...(datasourceId ? { datasourceId } : {}) };
  if (!['get_rows', 'count_rows'].includes(operation) || typeof table !== 'string' || !table.trim() || containsBinding(table)) {
    return { provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, reason: 'Supabase operation is not a static row read.', ...identity };
  }
  const source = { kind: 'remote_endpoint' as const, value: `supabase:${table.trim().toLowerCase()}` };
  if (operation === 'count_rows') {
    const countFilters = options.count_filters;
    const fullSourceCount = countFilters == null ||
      (Array.isArray(countFilters) && countFilters.length === 0) ||
      (!!record(countFilters) && Object.keys(record(countFilters)!).length === 0);
    return { provenRead: true, directSafe: false, countOnly: true, selectStar: false,
      requiresCountPreflight: false, requiresRemoteReadConfirmation: true, fullSourceCount,
      simpleSourceRead: true, maxRows: 1, source, ...identity };
  }
  const maxRows = staticPositiveInteger(options.get_limit);
  return { provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: maxRows === undefined || maxRows > LARGE_READ_ROW_THRESHOLD,
    requiresRemoteReadConfirmation: true, simpleSourceRead: true, source, maxRows, ...identity };
}

/* MongoDB, split by effect: the operation decides it, except for `aggregate`, whose pipeline can
   end in a $out/$merge write. Those are refused structurally rather than proven safe. A bounded
   read is directSafe — this is a database the workspace owns, not a remote API. */
const MONGO_ROW_READS = new Set(['find_many']);
const MONGO_SINGLE_READS = new Set(['find_one']);
const MONGO_COUNT_READS = new Set(['count', 'count_total']);
const MONGO_WRITE_STAGES = ['$out', '$merge'];

/** Authoring normalizes objects to text; the plugin parses JSON5, not only strict JSON. */
function mongoOptions(raw: unknown): Record<string, unknown> | undefined {
  const direct = record(raw);
  if (direct) return direct;
  if (typeof raw !== 'string' || !raw.trim()) return undefined;
  try {
    if (containsBinding(raw)) return undefined;
    return record(JSON5.parse(raw));
  } catch {
    return undefined;
  }
}

function mongoPipelineWrites(pipeline: unknown): boolean {
  if (Array.isArray(pipeline)) return pipeline.some(mongoPipelineWrites);
  const obj = record(pipeline);
  return !!obj && Object.entries(obj).some(([key, value]) =>
    MONGO_WRITE_STAGES.includes(key) || mongoPipelineWrites(value));
}

function assessMongo(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : '';
  const identity = { datasourceKind: 'mongodb', ...(datasourceId ? { datasourceId } : {}) };
  const refuse = (reason: string): QueryReadAssessment => ({
    provenRead: false, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, reason, ...identity,
  });

  const collection = options.collection;
  if (typeof collection !== 'string' || !collection.trim() || containsBinding(collection)) {
    return refuse('MongoDB collection is missing or not statically known.');
  }
  const source = { kind: 'gui_table' as const, value: collection };

  if (MONGO_COUNT_READS.has(operation)) {
    const filter = options.filter;
    // An unfiltered count bounds the whole collection, so it can upper-bound a later read.
    const fullSourceCount = filter == null || filter === '' ||
      (!!record(filter) && Object.keys(record(filter)!).length === 0) ||
      (typeof filter === 'string' && ['{}', '{ }'].includes(filter.trim()));
    return {
      provenRead: true, directSafe: true, countOnly: true, selectStar: false,
      requiresCountPreflight: false, fullSourceCount, simpleSourceRead: true,
      maxRows: 1, source, ...identity,
    };
  }

  if (MONGO_SINGLE_READS.has(operation)) {
    return {
      provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, simpleSourceRead: true, maxRows: 1, source, ...identity,
    };
  }

  if (operation === 'aggregate') {
    // The driver appends a $out stage from options.out, even when the supplied pipeline
    // only reads. Prove the options as well as the pipeline before allowing execution.
    const rawOptions = options.options;
    const aggregateOptions = rawOptions == null || rawOptions === '' ? {} : mongoOptions(rawOptions);
    if (!aggregateOptions || containsBinding(rawOptions) || containsBinding(aggregateOptions)) {
      return refuse('MongoDB aggregate options must be a statically known JSON5 object.');
    }
    if ('out' in aggregateOptions) {
      return refuse('MongoDB aggregate options.out adds a $out stage, which writes a collection.');
    }
    let pipeline: unknown = options.pipeline;
    if (containsBinding(pipeline)) return refuse('MongoDB aggregate pipeline is not statically known.');
    if (typeof pipeline === 'string') {
      try { pipeline = JSON5.parse(pipeline); } catch { return refuse('MongoDB aggregate pipeline must be valid JSON5 array text.'); }
    }
    if (!Array.isArray(pipeline) || pipeline.some((stage) => !record(stage))) {
      return refuse('MongoDB aggregate pipeline must be a statically known array of stages.');
    }
    if (mongoPipelineWrites(pipeline)) {
      return refuse('MongoDB aggregate pipeline contains a $out/$merge stage, which writes a collection.');
    }
    // An aggregation reshapes rows, so no simpleSourceRead: a collection count cannot bound it.
    // Driver options.limit is ignored by aggregate. Only a final pipeline $limit bounds output;
    // a later $unwind/$unionWith can expand an earlier limit again.
    const last = record(pipeline.at(-1));
    const maxRows = last && Object.keys(last).length === 1 && typeof last.$limit === 'number'
      ? staticPositiveInteger(last.$limit) : undefined;
    return {
      provenRead: true, directSafe: maxRows !== undefined && maxRows <= LARGE_READ_ROW_THRESHOLD,
      countOnly: false, selectStar: false,
      requiresCountPreflight: maxRows === undefined || maxRows > LARGE_READ_ROW_THRESHOLD,
      source, maxRows, ...identity,
      ...(maxRows === undefined
        ? { reason: 'MongoDB aggregate has no statically provable row limit; add a final {$limit: N} pipeline stage. options.limit does not bound aggregation output.' }
        : {}),
    };
  }

  if (operation === 'distinct') {
    return { provenRead: true, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: true, source, ...identity,
      reason: 'MongoDB distinct ignores options.limit and array fields can yield multiple values per document. Use a bounded aggregate with a final $limit stage.' };
  }

  if (!MONGO_ROW_READS.has(operation)) {
    return refuse(
      `MongoDB operation ${operation || '<missing>'} is not a proven bounded read.`
    );
  }

  const maxRows = staticPositiveInteger(mongoOptions(options.options)?.limit);
  if (maxRows !== undefined && maxRows <= LARGE_READ_ROW_THRESHOLD) {
    return {
      provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, simpleSourceRead: true, maxRows, source, ...identity,
    };
  }
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: true, simpleSourceRead: true, maxRows, source, ...identity,
    reason: maxRows === undefined
      ? `MongoDB ${operation} has no statically provable row limit; set options.limit.`
      : `MongoDB ${operation} can return up to ${maxRows} rows, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.`,
  };
}

/* Google Sheets v2. Reads cross into Google, so they are never directSafe. A bound comes only
   from an explicit A1 row range; `read` without one, and `list_all`, can return a whole sheet. */
const SHEETS_METADATA_READS = new Set(['info', 'list_all_spreadsheets']);
const A1_ROW_RANGE = /^(?:[^!]*!)?[A-Z]*(\d+):[A-Z]*(\d+)$/i;

function sheetsRangeRows(range: unknown): number | undefined {
  if (typeof range !== 'string' || containsBinding(range)) return undefined;
  const match = range.trim().match(A1_ROW_RANGE);
  if (!match) return undefined;
  const rows = Number(match[2]) - Number(match[1]) + 1;
  return rows > 0 ? rows : undefined;
}

function assessSheets(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : '';
  const identity = { datasourceKind: 'googlesheetsv2', ...(datasourceId ? { datasourceId } : {}) };
  const spreadsheet = options.spreadsheet_id;

  if (SHEETS_METADATA_READS.has(operation)) {
    return { provenRead: true, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, requiresRemoteReadConfirmation: true, maxRows: 1, ...identity };
  }
  if (operation !== 'read' && operation !== 'list_all') {
    return { provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, ...identity,
      reason: `Google Sheets operation ${operation || '<missing>'} is not a proven bounded read.` };
  }
  if (typeof spreadsheet !== 'string' || !spreadsheet.trim() || containsBinding(spreadsheet)) {
    return { provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, ...identity,
      reason: 'Google Sheets spreadsheet_id is missing or not statically known.' };
  }
  const sheet = typeof options.sheet === 'string' && options.sheet.trim() ? `:${options.sheet.trim()}` : '';
  const source = { kind: 'remote_endpoint' as const, value: `googlesheets:${spreadsheet.trim()}${sheet}` };
  const maxRows = operation === 'read' ? sheetsRangeRows(options.spreadsheet_range) : undefined;
  const bounded = maxRows !== undefined && maxRows <= LARGE_READ_ROW_THRESHOLD;
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: !bounded, requiresRemoteReadConfirmation: true, source, maxRows, ...identity,
    ...(bounded ? {} : { reason: maxRows === undefined
      ? `Google Sheets ${operation} has no statically bounded row range; set spreadsheet_range to an explicit A1 range such as A1:D100.`
      : `Google Sheets range covers ${maxRows} rows, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.` }),
  };
}

/* DynamoDB. `scan_table` reads the whole table and DynamoDB publishes no static row bound, so it
   is proven but always needs a preflight; `query_table` is key-bounded but still unbounded in row
   count. Neither is remote in the billing sense the API kinds are. */
function assessDynamo(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : '';
  const identity = { datasourceKind: 'dynamodb', ...(datasourceId ? { datasourceId } : {}) };
  const table = options.table;
  const refuse = (reason: string): QueryReadAssessment => ({
    provenRead: false, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, reason, ...identity });

  if (!['get_item', 'query_table', 'scan_table', 'describe_table'].includes(operation)) {
    return refuse(`DynamoDB operation ${operation || '<missing>'} is not a proven bounded read.`);
  }
  if (typeof table !== 'string' || !table.trim() || containsBinding(table)) {
    return refuse('DynamoDB table is missing or not statically known.');
  }
  const source = { kind: 'gui_table' as const, value: table.trim().toLowerCase() };
  if (operation === 'get_item' || operation === 'describe_table') {
    return { provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, simpleSourceRead: true, maxRows: 1, source, ...identity };
  }
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: true, simpleSourceRead: true, source, ...identity,
    reason: `DynamoDB ${operation} has no statically provable row limit.`,
  };
}

/* CouchDB. Same shape as Mongo, minus a collection field — the database lives on the datasource
   connection, so a query names no static source and nothing can count it ahead of time. */
function assessCouch(options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : '';
  const identity = { datasourceKind: 'couchdb', ...(datasourceId ? { datasourceId } : {}) };

  if (operation === 'retrieve_record') {
    return { provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, maxRows: 1, ...identity };
  }
  if (!['list_records', 'get_view', 'find'].includes(operation)) {
    return { provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, ...identity,
      reason: `CouchDB operation ${operation || '<missing>'} is not a proven bounded read.` };
  }
  // `find` is a Mango query whose limit sits inside the request body.
  const limit = operation === 'find'
    ? mongoOptions(options.body)?.limit
    : options.limit;
  const maxRows = staticPositiveInteger(limit);
  if (maxRows !== undefined && maxRows <= LARGE_READ_ROW_THRESHOLD) {
    return { provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, maxRows, ...identity };
  }
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: true, maxRows, ...identity,
    reason: maxRows === undefined
      ? `CouchDB ${operation} has no statically provable row limit; set ${operation === 'find' ? 'limit in the request body' : 'limit'}.`
      : `CouchDB ${operation} can return up to ${maxRows} rows, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.`,
  };
}

function stripSql(sql: string): string {
  return sql.replace(/--.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim().replace(/;\s*$/, '').trim();
}

function normalizeSqlTable(raw: string): string {
  return raw.split('.').map((part) => part.replace(/^[`"\[]|[`"\]]$/g, '')).join('.').toLowerCase();
}

function sqlSource(sql: string): ReadSource | undefined {
  const match = sql.match(/\bfrom\s+((?:[`"\[]?[A-Za-z_$][\w$]*[`"\]]?\.)*[`"\[]?[A-Za-z_$][\w$]*[`"\]]?)/i);
  return match ? { kind: 'sql_table', value: normalizeSqlTable(match[1]!) } : undefined;
}

function assessSql(sql: string, datasourceKind: string, datasourceId?: string): QueryReadAssessment {
  const compact = stripSql(sql);
  const identity = { datasourceKind, ...(datasourceId ? { datasourceId } : {}) };
  if (!compact || /;\s*\S/.test(compact)) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, reason: 'SQL is empty or contains more than one statement', ...identity,
    };
  }
  if (/^(show\b|describe\b|desc\b|explain\s+(?:select\b|show\b))/i.test(compact)) {
    return {
      provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, ...identity,
    };
  }
  if (!/^select\b/i.test(compact)) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, reason: 'SQL is not a single proven read statement', ...identity,
    };
  }

  if (/\binto\s+(?:temp(?:orary)?\s+|unlogged\s+)?[`"\[]?[A-Za-z_$]/i.test(compact)) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, reason: 'SELECT INTO creates or replaces data and is not a read-only query', ...identity,
    };
  }
  if (/\bfor\s+(?:no\s+key\s+update|key\s+share|update|share)\b|\block\s+in\s+share\s+mode\b/i.test(compact)) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, reason: 'Locking SELECT statements are not side-effect-free reads', ...identity,
    };
  }

  const fromIndex = compact.search(/\bfrom\b/i);
  const selectClause = compact.slice('select'.length, fromIndex >= 0 ? fromIndex : compact.length).trim();
  const countOnly = /^count\s*\([\s\S]+\)(?:\s+(?:as\s+)?[`"A-Za-z_$][\w$`"]*)?$/i.test(selectClause);
  const projectionClause = selectClause.replace(/^top\s*(?:\(\s*\d+\s*\)|\d+)\s+/i, '').trim();
  const selectStar = !countOnly && /(?:^|,)\s*(?:[`"A-Za-z_$][\w$`"]*\.)?\*\s*(?:,|$)/.test(projectionClause);
  const source = sqlSource(compact);
  const fromCount = compact.match(/\bfrom\b/gi)?.length ?? 0;
  const simpleSourceRead = !!source && fromCount === 1 &&
    !/\b(join|union|intersect|except)\b|\bfrom\s*\(|\bfrom\s+(?:[`"\[]?[A-Za-z_$][\w$]*[`"\]]?\.)*[`"\[]?[A-Za-z_$][\w$]*[`"\]]?\s*\(/i.test(compact);
  const limit = compact.match(/\blimit\s+(\d+)\b/i);
  const top = selectClause.match(/^top\s*(?:\(\s*(\d+)\s*\)|(\d+))\s+/i);
  const fetch = compact.match(/\bfetch\s+(?:first|next)\s+(\d+)\s+rows?\s+only\b/i);
  const maxRows = limit
    ? Number(limit[1])
    : top
      ? Number(top[1] ?? top[2])
      : fetch
        ? Number(fetch[1])
        : undefined;
  const billableRead = BILLABLE_SCAN_SQL_KINDS.has(datasourceKind) && fromIndex >= 0;
  const fullSourceCount = countOnly && /^count\s*\(\s*\*\s*\)(?:\s+(?:as\s+)?[`"A-Za-z_$][\w$`"]*)?$/i.test(selectClause) &&
    simpleSourceRead && !/\b(where|group\s+by|having|limit|offset)\b/i.test(compact);

  if (selectStar) {
    return {
      provenRead: true, directSafe: false, countOnly: false, selectStar: true,
      requiresCountPreflight: false, source, maxRows, simpleSourceRead, ...identity,
      reason: 'SELECT * is refused. Inspect the schema and select only the required columns.',
    };
  }
  if (fromIndex < 0) {
    if (/\b[A-Za-z_$][\w$.]*\s*\(/.test(selectClause)) {
      return {
        provenRead: false, directSafe: false, countOnly: false, selectStar: false,
        requiresCountPreflight: false,
        reason: 'Function-only SELECT statements cannot be proven side-effect-free',
        ...identity,
      };
    }
    return {
      provenRead: true, directSafe: true, countOnly: false, selectStar: false,
      requiresCountPreflight: false, source, maxRows, ...identity,
    };
  }
  if (countOnly) {
    return {
      provenRead: true, directSafe: !billableRead, countOnly: true, selectStar: false,
      requiresCountPreflight: false, requiresBillableReadConfirmation: billableRead,
      fullSourceCount, simpleSourceRead, source, maxRows: 1, ...identity,
    };
  }
  if (maxRows !== undefined && maxRows <= LARGE_READ_ROW_THRESHOLD) {
    return {
      provenRead: true, directSafe: !billableRead, countOnly: false, selectStar: false,
      requiresCountPreflight: false, requiresBillableReadConfirmation: billableRead,
      simpleSourceRead, source, maxRows, ...identity,
    };
  }
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: true, requiresBillableReadConfirmation: billableRead,
    simpleSourceRead, source, maxRows, ...identity,
    reason: maxRows === undefined
      ? 'Row-returning SQL has no static LIMIT.'
      : `SQL can return up to ${maxRows} rows, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.`,
  };
}

function countAggregate(options: Record<string, unknown>): boolean {
  const listRows = record(options.list_rows);
  const aggregates = record(listRows?.aggregates);
  const groupBy = record(listRows?.group_by);
  if (!aggregates || Object.keys(aggregates).length === 0 || (groupBy && Object.keys(groupBy).length > 0)) return false;
  return Object.values(aggregates).every((aggregate) => record(aggregate)?.aggFx === 'count');
}

function fullToolJetDbCount(options: Record<string, unknown>): boolean {
  if (!countAggregate(options)) return false;
  const listRows = record(options.list_rows)!;
  const aggregates = record(listRows.aggregates)!;
  if (Object.keys(aggregates).length !== 1) return false;
  const aggregate = record(Object.values(aggregates)[0]);
  if (aggregate?.column !== 'id') return false;
  const ignoredForScope = new Set(['aggregates', 'group_by', 'order_filters', 'limit', 'offset']);
  return Object.entries(listRows).every(([key, value]) => {
    if (ignoredForScope.has(key)) return true;
    if (value === undefined || value === null || value === '') return true;
    if (Array.isArray(value)) return value.length === 0;
    if (record(value)) return Object.keys(record(value)!).length === 0;
    return false;
  });
}

function guiSource(kind: string, options: Record<string, unknown>): ReadSource | undefined {
  if (kind === 'tooljetdb' && typeof options.table_id === 'string') {
    return { kind: 'table_id', value: options.table_id };
  }
  const table = typeof options.table === 'string' ? options.table : undefined;
  if (!table) return undefined;
  const schema = typeof options.schema === 'string' ? `${options.schema}.` : '';
  return { kind: 'gui_table', value: `${schema}${table}`.toLowerCase() };
}

function assessListRows(kind: string, options: Record<string, unknown>, datasourceId?: string): QueryReadAssessment {
  const source = guiSource(kind, options);
  const billableRead = BILLABLE_SCAN_SQL_KINDS.has(kind);
  const identity = { datasourceKind: kind, ...(datasourceId ? { datasourceId } : {}) };
  if (kind === 'tooljetdb' && countAggregate(options)) {
    return {
      provenRead: true, directSafe: true, countOnly: true, selectStar: false,
      requiresCountPreflight: false, fullSourceCount: fullToolJetDbCount(options),
      simpleSourceRead: true, source, maxRows: 1, ...identity,
    };
  }
  const listRows = record(options.list_rows);
  const maxRows = staticPositiveInteger(listRows?.limit ?? options.limit);
  if (maxRows !== undefined && maxRows <= LARGE_READ_ROW_THRESHOLD) {
    return {
      provenRead: true, directSafe: !billableRead, countOnly: false, selectStar: false,
      requiresCountPreflight: false, requiresBillableReadConfirmation: billableRead,
      simpleSourceRead: true, source, maxRows, ...identity,
    };
  }
  return {
    provenRead: true, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: true, requiresBillableReadConfirmation: billableRead,
    simpleSourceRead: true, source, maxRows, ...identity,
    reason: maxRows === undefined
      ? 'list_rows has no statically provable row limit.'
      : `list_rows can return up to ${maxRows} rows, above the ${LARGE_READ_ROW_THRESHOLD}-row safety threshold.`,
  };
}

/** Fail-closed execution assessment. Unknown datasource kinds are not assumed safe. */
export function assessQueryRead(query: QuerySummary): QueryReadAssessment {
  const kind = query.kind?.toLowerCase();
  const datasourceId = query.data_source_id;
  const options = record(query.options);
  if (!kind || !options) {
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false, reason: 'Datasource kind/options are unavailable.',
    };
  }
  const operation = typeof options.operation === 'string' ? options.operation.toLowerCase() : undefined;

  if (kind === 'hubspot') {
    const issue = hubspotQueryIssues(options)[0];
    const assessment = assessOpenapi({ ...options, host: 'https://api.hubapi.com' }, datasourceId);
    return {
      ...assessment, datasourceKind: 'hubspot',
      ...(issue ? { provenRead: false, directSafe: false, requiresRemoteReadConfirmation: false, reason: issue.message }
        : { reason: assessment.reason?.replaceAll('OpenAPI', 'HubSpot') }),
    };
  }

  if (kind === 'restapi') return assessRestGet(options, datasourceId);
  if (kind === 'openapi') return assessOpenapi(options, datasourceId);

  if (kind === 'servicenow') return assessServiceNow(options, datasourceId);

  if (kind === 'influxdb') return assessInflux(options, datasourceId);

  if (kind === 'supabase') return assessSupabase(options, datasourceId);

  if (kind === 'mongodb') return assessMongo(options, datasourceId);
  if (kind === 'redis') return assessRedisRead(options, datasourceId);

  if (kind === 'googlesheetsv2') return assessSheets(options, datasourceId);

  if (kind === 'dynamodb') return assessDynamo(options, datasourceId);

  if (kind === 'couchdb') return assessCouch(options, datasourceId);

  if (kind === 'tooljetdb') {
    if (operation === 'list_rows') return assessListRows(kind, options, datasourceId);
    if (operation === 'sql_execution') {
      const sql = record(options.sql_execution)?.sqlQuery;
      return typeof sql === 'string'
        ? assessSql(sql, kind, datasourceId)
        : {
            provenRead: false, directSafe: false, countOnly: false, selectStar: false,
            requiresCountPreflight: false, reason: 'ToolJet DB SQL text is unavailable.',
          };
    }
    return {
      provenRead: false, directSafe: false, countOnly: false, selectStar: false,
      requiresCountPreflight: false,
      reason: `ToolJet DB operation ${operation ?? '<missing>'} is not a proven bounded read.`,
    };
  }

  if (SQL_KINDS.has(kind)) {
    if (operation === 'list_rows' || options.mode === 'gui') return assessListRows(kind, options, datasourceId);
    // Plugins disagree on the field name; databricks, awsredshift and harperdb use `sql_query`.
    const sql = ['query', 'sql_query', 'sql', 'presto_sql_query', 'soql_query']
      .map((field) => options[field])
      .find((value): value is string => typeof value === 'string' && !!value.trim());
    return sql
      ? assessSql(sql, kind, datasourceId)
      : {
          provenRead: false, directSafe: false, countOnly: false, selectStar: false,
          requiresCountPreflight: false, reason: 'SQL text is unavailable.',
        };
  }

  return {
    provenRead: false, directSafe: false, countOnly: false, selectStar: false,
    requiresCountPreflight: false, reason: `Datasource kind ${kind} has no proven read classifier.`,
  };
}

export function sameReadSource(target: QueryReadAssessment, count: QueryReadAssessment): boolean {
  return !!target.source && !!count.source &&
    target.simpleSourceRead === true && count.fullSourceCount === true &&
    !!target.datasourceId && target.datasourceId === count.datasourceId &&
    target.datasourceKind === count.datasourceKind &&
    target.source.kind === count.source.kind && target.source.value === count.source.value;
}

/** Accept one-row count results with exactly one numeric value; reject ambiguous response shapes. */
export function extractRowCount(result: RunQueryResult): number | undefined {
  if (result.status !== 'ok') return undefined;
  let value: unknown = result.data;
  // MongoDB count/count_total return a scalar, unlike SQL's one-row result.
  if (typeof value === 'number') return Number.isSafeInteger(value) && value >= 0 ? value : undefined;
  if (record(value)?.result !== undefined) value = record(value)!.result;
  if (Array.isArray(value)) {
    if (value.length !== 1) return undefined;
    value = value[0];
  }
  const row = record(value);
  if (!row) return undefined;
  const numeric = Object.values(row).flatMap((candidate) => {
    const parsed = typeof candidate === 'number'
      ? candidate
      : typeof candidate === 'string' && /^\d+$/.test(candidate.trim())
        ? Number(candidate)
        : Number.NaN;
    return Number.isSafeInteger(parsed) && parsed >= 0 ? [parsed] : [];
  });
  return numeric.length === 1 ? numeric[0] : undefined;
}
