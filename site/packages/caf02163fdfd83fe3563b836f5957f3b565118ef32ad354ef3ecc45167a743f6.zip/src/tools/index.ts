import { listWorkspaceGroupsTool, manageWorkspaceGroupsTool } from './workspaceGroupManagement.js';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ToolJetClient } from '../tooljetClient.js';
import type { ToolDef } from './types.js';
import { listWorkspacesTool } from './listWorkspaces.js';
import { useWorkspaceTool } from './useWorkspace.js';
import { createAppTool } from './createApp.js';
import { getAppSettingsTool } from './getAppSettings.js';
import { listAppThemesTool } from './listAppThemes.js';
import { updateAppSettingsTool } from './updateAppSettings.js';
import { listDatasourcesTool } from './listDatasources.js';
import { listTablesTool } from './listTables.js';
import { createTableTool } from './createTable.js';
import { createTablesTool } from './createTables.js';
import { addTableColumnTool } from './addTableColumn.js';
import { dropTableColumnTool } from './dropTableColumn.js';
import { dropTableTool } from './dropTable.js';
import { getTableSchemaTool } from './getTableSchema.js';
import { insertRowsTool } from './insertRows.js';
import { insertRowsBatchTool } from './insertRowsBatch.js';
import { getComponentCatalogTool } from './getComponentCatalog.js';
import { getDatasourceQuerySchemaTool } from './getDatasourceQuerySchema.js';
import { inspectDatasourceSchemaTool } from './inspectDatasourceSchema.js';
import { testDatasourceConnectionTool } from './testDatasourceConnection.js';
import { prepareSqlDiscoveryQueriesTool } from './prepareSqlDiscoveryQueries.js';
import { generateFormSchemaTool } from './generateFormSchema.js';
import { generateEditContractTool } from './generateEditContract.js';
import { getAppTool } from './getApp.js';
import { getAppSummaryTool } from './getAppSummary.js';
import { getComponentTool } from './getComponent.js';
import { validateAppTool } from './validateApp.js';
import { verifyPageRenderTool } from './verifyPageRender.js';
import { lintAppSpecTool } from './lintAppSpec.js';
import { applyAppPhaseTool } from './applyAppPhase.js';
import { addPageTool } from './addPage.js';
import { addPagesTool } from './addPages.js';
import { updatePagesTool } from './updatePages.js';
import { deletePageTool } from './deletePage.js';
import { addQueryTool } from './addQuery.js';
import { addQueriesTool } from './addQueries.js';
import { addComponentTool } from './addComponent.js';
import { addComponentsTool } from './addComponents.js';
import { addComponentBatchesTool } from './addComponentBatches.js';
import { updateComponentsTool } from './updateComponents.js';
import { deleteComponentsTool } from './deleteComponents.js';
import { updateLayoutTool } from './updateLayout.js';
import { addEventsTool } from './addEvents.js';
import { addQueryLifecyclesTool } from './addQueryLifecycles.js';
import { updateQueryTool } from './updateQuery.js';
import { deleteQueryTool } from './deleteQuery.js';
import { runQueryTool } from './runQuery.js';
import { runQueriesTool } from './runQueries.js';
import { listEventsTool } from './listEvents.js';
import { updateEventsTool } from './updateEvents.js';
import { deleteEventTool } from './deleteEvent.js';
import { withToolTelemetry } from '../telemetry.js';
import {
  runtimeFreshness,
  staleRuntimeResult,
  withRuntimeStatus,
  type RuntimeFreshnessMonitor,
} from '../runtimeFreshness.js';
import { getRuntimeInfoTool } from './getRuntimeInfo.js';
import { manageThemeTool } from './manageTheme.js';
import { manageAppPermissionsTool } from './manageAppPermissions.js';
import {
  listWorkspaceAppsTool,
  listWorkspaceUsersTool,
  manageWorkspaceUsersTool,
} from './workspaceUserManagement.js';

export const LEGACY_SINGULAR_CREATE_TOOL_NAMES = new Set([
  'create_table',
  'insert_rows',
  'add_page',
  'add_query',
  'add_component',
]);

function includeLegacySingularCreateTools(): boolean {
  return /^(1|true|yes)$/i.test(process.env.TOOLJET_INCLUDE_LEGACY_SINGULAR_TOOLS ?? '');
}

export function registerTools(
  server: McpServer,
  client: ToolJetClient,
  runtime: RuntimeFreshnessMonitor = runtimeFreshness
): void {
  const tools: ToolDef[] = [
    getRuntimeInfoTool(runtime),
    listWorkspacesTool(client),
    useWorkspaceTool(client),
    manageAppPermissionsTool(client),
    listWorkspaceAppsTool(client),
    listWorkspaceUsersTool(client),
    manageWorkspaceUsersTool(client),
    listWorkspaceGroupsTool(client),
    manageWorkspaceGroupsTool(client),
    createAppTool(client),
    getAppSettingsTool(client),
    listAppThemesTool(client),
    updateAppSettingsTool(client),
    listDatasourcesTool(client),
    listTablesTool(client),
    createTableTool(client),
    createTablesTool(client),
    addTableColumnTool(client),
    dropTableColumnTool(client),
    dropTableTool(client),
    getTableSchemaTool(client),
    insertRowsTool(client),
    insertRowsBatchTool(client),
    getDatasourceQuerySchemaTool(client),
    inspectDatasourceSchemaTool(client),
    testDatasourceConnectionTool(client),
    prepareSqlDiscoveryQueriesTool(client),
    generateFormSchemaTool(client),
    generateEditContractTool(),
    getComponentCatalogTool(client),
    getAppTool(client),
    getAppSummaryTool(client),
    getComponentTool(client),
    validateAppTool(client),
    verifyPageRenderTool(client, () => process.env.TOOLJET_APP_URL || process.env.TOOLJET_DEPLOYMENT_URL || 'http://localhost:8082'),
    lintAppSpecTool(client),
    applyAppPhaseTool(client),
    addPageTool(client),
    addPagesTool(client),
    updatePagesTool(client),
    deletePageTool(client),
    addQueryTool(client),
    addQueriesTool(client),
    updateQueryTool(client),
    deleteQueryTool(client),
    runQueryTool(client),
    runQueriesTool(client),
    addComponentTool(client),
    addComponentsTool(client),
    addComponentBatchesTool(client),
    updateComponentsTool(client),
    deleteComponentsTool(client),
    updateLayoutTool(client),
    addEventsTool(client),
    addQueryLifecyclesTool(client),
    listEventsTool(client),
    updateEventsTool(client),
    deleteEventTool(client),
    manageThemeTool(client),
  ];

  const exposedTools = includeLegacySingularCreateTools()
    ? tools
    : tools.filter((tool) => !LEGACY_SINGULAR_CREATE_TOOL_NAMES.has(tool.name));

  for (const tool of exposedTools) {
    server.registerTool(
      tool.name,
      {
        title: tool.title,
        description: tool.description,
        inputSchema: tool.inputSchema,
        annotations: tool.annotations,
      },
      (args: any) => withToolTelemetry(tool.name, async () => {
        const status = runtime.status();
        if (status.restart_required && tool.name !== 'get_runtime_info') {
          return staleRuntimeResult(status);
        }
        return withRuntimeStatus(await tool.handler(args), status);
      }) as any
    );
  }
}
