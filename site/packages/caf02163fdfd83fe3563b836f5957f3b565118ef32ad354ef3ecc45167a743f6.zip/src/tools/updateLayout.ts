import { z } from 'zod';
import type { ToolJetClient } from '../tooljetClient.js';
import {
  introducedLintFindings,
  lintComponentSlots,
  lintComponentSpec,
  lintRenderedGeometry,
  lintStandardSingleLineInputHeight,
  lintTextGeometry,
  lintUnusableTextGeometry,
  type LintComponent,
} from '../lint.js';
import { COMPONENT_SLOT_NAMES, decodeComponentParent, encodeComponentParent } from '../componentParent.js';
import { ok, fail, type ToolDef } from './types.js';
import { resolveRef } from '../refResolution.js';
import { strictEntry } from '../strictEntry.js';

const rect = z.object({ top: z.number(), left: z.number(), width: z.number(), height: z.number() });

const RECT_KEYS = new Set(['top', 'left', 'width', 'height']);

// Unknown entry keys are rejected, never stripped: a stripped rect or wrapper left an entry with
// nothing to write, which went out as an empty diff and was reported as updated (see src/strictEntry.ts).
const layoutEntrySchema = strictEntry(
  {
    component_id: z.string(),
    desktop: rect.optional(),
    mobile: rect.optional(),
    parent: z.string().optional(),
    slot_name: z.enum(COMPONENT_SLOT_NAMES).optional(),
  },
  (key) => {
    if (RECT_KEYS.has(key)) {
      return `Layout entry key "${key}" must be nested under desktop and/or mobile (e.g. { component_id, desktop: { top, left, width, height } }).`;
    }
    if (key === 'layout' || key === 'layouts') {
      return `Layout entry key "${key}" is not accepted; put the rect directly under desktop and/or mobile on the entry.`;
    }
    if (key === 'definition' || key === 'properties' || key === 'styles') {
      return `Layout entry key "${key}" is not accepted by update_layout; edit component values with update_components.`;
    }
    return `Unknown layout entry key "${key}"; accepted keys are component_id, desktop, mobile, parent, slot_name.`;
  }
);

export function updateLayoutTool(client: ToolJetClient): ToolDef {
  return {
    name: 'update_layout',
    title: 'Update Layout',
    annotations: {
      readOnlyHint: false,
      destructiveHint: true,
      openWorldHint: true,
    },
    description:
      'Move / resize existing components (batch) without touching their properties. `left`/`width` are ' +
      'in grid columns (43 desktop), `top`/`height` in grid rows. Provide desktop and/or mobile per ' +
      'component. Use this to fix overlaps or reflow a page. Set `parent` to reparent; use `slot_name` ' +
      '(header/body/footer) for native ModalV2/Form/Container regions or modal for Kanban card-click content. `slot_name` alone keeps the current parent.',
    inputSchema: {
      app_id: z.string(),
      version_id: z.string(),
      page_id: z.string(),
      layouts: z.array(layoutEntrySchema).min(1),
    },
    async handler(args: {
      app_id: string;
      version_id: string;
      page_id: string;
      layouts: Array<{
        component_id: string;
        desktop?: { top: number; left: number; width: number; height: number };
        mobile?: { top: number; left: number; width: number; height: number };
        parent?: string;
        slot_name?: 'body' | 'header' | 'footer' | 'modal';
      }>;
    }) {
      try {
        const summary = await client.getAppSummary(args.app_id);
        const page = summary.pages.find((candidate) => candidate.id === args.page_id);
        if (!page) return fail(new Error(`Page "${args.page_id}" does not exist in app "${args.app_id}".`));
        const components = new Map(page.components.map((component) => [component.id, component]));
        // Accept a component NAME as component_id — the same slip that made update_components loop
        // forever on a false "does not exist". Resolved ids are substituted below so the write is
        // unaffected. See src/refResolution.ts for why this matters.
        const layoutWarnings: string[] = [];
        const resolveErrors: string[] = [];
        const resolvedIds = new Map<string, string>();
        for (const layout of args.layouts) {
          if (!layout.desktop && !layout.mobile && layout.parent === undefined && layout.slot_name === undefined) {
            resolveErrors.push(
              `Component "${layout.component_id}": nothing to update. Provide desktop and/or mobile rects, or a parent/slot_name change.`
            );
            continue;
          }
          if (resolvedIds.has(layout.component_id)) continue;
          const resolution = resolveRef(page.components, layout.component_id, 'Component', `on page "${args.page_id}"`);
          if (!resolution.ok) {
            resolveErrors.push(resolution.error);
            continue;
          }
          resolvedIds.set(layout.component_id, resolution.target.id);
          if (resolution.warning) layoutWarnings.push(resolution.warning);
        }
        if (resolveErrors.length) return fail(new Error(resolveErrors.join(' ')));
        args = {
          ...args,
          layouts: args.layouts.map((layout) => ({
            ...layout,
            component_id: resolvedIds.get(layout.component_id) ?? layout.component_id,
          })),
        };
        const rootSlotWarnings: string[] = [];
        const resolvedLayouts = args.layouts.map((layout) => {
          const current = components.get(layout.component_id)!;
          let parent = layout.parent;
          let slot_name = layout.slot_name;
          if (slot_name !== undefined) {
            parent ??= current.parent ? decodeComponentParent(current.parent).parentId : undefined;
            if (!parent) {
              if (slot_name === 'body') {
                // A root/parentless component has no slots; "body" is the implicit default, so
                // slot_name:"body" here is a redundant no-op. Drop it and warn instead of erroring —
                // a frequent model mistake that otherwise triggers identical repair retries.
                rootSlotWarnings.push(
                  `Component "${layout.component_id}": slot_name:"body" ignored on a root component (it has no parent slots).`
                );
                slot_name = undefined;
              } else {
                throw new Error(`Component "${layout.component_id}": slot_name:"${slot_name}" requires an existing or explicit parent.`);
              }
            }
          }
          return { ...layout, parent, slot_name };
        });
        const changes = new Map(resolvedLayouts.map((layout) => [layout.component_id, layout]));
        const projected = page.components.map((component) => {
          const change = changes.get(component.id);
          if (!change) return component as LintComponent;
          const currentLayouts = (component.layouts ?? {}) as LintComponent['layouts'];
          return {
            ...component,
            layouts: {
              ...currentLayouts,
              desktop: change.desktop ?? currentLayouts?.desktop,
              mobile: change.mobile ?? currentLayouts?.mobile,
            },
            parent: change.parent !== undefined
              ? encodeComponentParent(change.parent, change.slot_name)
              : component.parent,
            slotName: change.slot_name,
          } as LintComponent;
        });
        const changedIds = new Set(resolvedLayouts.map((layout) => layout.component_id));
        const changed = projected.filter((component) => component.id && changedIds.has(component.id));
        const introducedForChanged = (
          lint: (components: LintComponent[]) => string[]
        ) => changed.flatMap((component) =>
          introducedLintFindings(lint([components.get(component.id!) as LintComponent]), lint([component]))
        );
        const errors = [
          ...introducedLintFindings(
            lintComponentSlots(page.components as LintComponent[]),
            lintComponentSlots(projected)
          ),
          ...introducedForChanged((items) => items.flatMap((component) => lintComponentSpec(component).errors)),
          ...introducedForChanged(lintUnusableTextGeometry),
        ];
        if (errors.length) return fail(new Error(errors.join(' ')));
        const warnings = [...new Set([
          ...layoutWarnings,
          ...rootSlotWarnings,
          ...introducedForChanged((items) => items.flatMap((component) => lintComponentSpec(component).warnings)),
          ...introducedForChanged((items) => items.flatMap(lintStandardSingleLineInputHeight)),
          ...introducedForChanged(lintTextGeometry),
          ...lintRenderedGeometry(projected),
        ])];
        const result = await client.updateLayouts({
          appId: args.app_id,
          versionId: args.version_id,
          pageId: args.page_id,
          layouts: resolvedLayouts.map((l) => ({
            componentId: l.component_id,
            desktop: l.desktop,
            mobile: l.mobile,
            parent: l.parent,
            slotName: l.slot_name,
          })),
        });
        return ok({ ...result, warnings });
      } catch (err) {
        return fail(err);
      }
    },
  };
}
