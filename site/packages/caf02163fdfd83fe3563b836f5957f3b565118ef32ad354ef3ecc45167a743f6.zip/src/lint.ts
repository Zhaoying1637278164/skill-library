// Mechanical, catalog-independent checks that catch the render bugs the skill can only *advise*
// against. Used by add_component(s) (component-level, pre-write) and validate_app (whole-app,
// post-write). Errors block; warnings are surfaced to the agent but don't block.
import type { AppSummary } from './tooljetClient.js';
import { parseExpression } from '@babel/parser';
import {
  lintHtmlContentHeight,
  BARE_QUERY_DATA_BINDING,
  lintChartDataShape,
  lintEmbeddedBindingSyntax,
  lintHtmlRootSurface,
  lintOversizedWidths,
  lintUnguardedComponentRefs,
  lintUnguardedSelectionText,
  lintTableColumnsShape,
  lintTextFormat,
  lintUntriggeredDataQueries,
} from './renderReadiness.js';
import { bindingReferences } from './bindingReferences.js';
import { lintEditPrefill, lintUninitializedWriteSelections } from './editPrefillContract.js';
import { lintWhitespaceGuards } from './whitespaceGuard.js';
import { lintSelectedRowObjectGuards } from './selectedRowGuard.js';
import { lintSurfaceInsets } from './surfaceInsets.js';
import { lintComponentStateBindings } from './componentStateBindings.js';
import { pageIconError } from './pageIcons.js';
import { runjsComponentReferences, runjsQueryReferences } from './runjsReferences.js';
import { lintBindingSyntax } from './bindingSyntax.js';
import { lintSelectedRowProjections } from './selectedRowProjection.js';
import { dropdownDefaultVisibilityWarning, dropdownSelfDefaultWarning } from './dropdownDefaultContract.js';
import { getCatalog, getComponentSchema, getLegacyComponentReplacement } from './catalog.js';
import { COMPONENT_SLOT_NAMES, decodeComponentParent, type ComponentSlotName } from './componentParent.js';
import {
  FORM_SCHEMA_FIELD_TYPE_SET,
  SAFE_GENERATED_FORM_FIELD_TYPE_SET,
} from './formFieldTypes.js';

export interface LintResult {
  errors: string[];
  warnings: string[];
}

/** Style-ish keys ToolJet's renderer reads from `definition.styles`, NOT `properties` — placing them
 *  under `properties` is silently dropped. Single source of truth (also used by the client DTO builder). */
export const STYLE_KEYS_IN_PROPERTIES = new Set([
  'styles',
  'textSize',
  'fontWeight',
  'textColor',
  'backgroundColor',
  'borderColor',
  'borderRadius',
  'boxShadow',
  'textAlign',
  'fontVariant',
  'padding',
  'accentColor',
  'iconColor',
]);

/** Known wrong property/style keys (CSS or other-builder names, or bad casing) mapped to the correct
 *  ToolJet key. The edit-distance suggester misses these because the names differ too much
 *  (fontSize vs textSize). Lookup is case-insensitive; a match is only used when its target is actually
 *  a valid key for the component. */
export const PROPERTY_KEY_ALIASES: Record<string, string> = {
  disabled: 'disabledState',
  isdisabled: 'disabledState',
  fontsize: 'textSize',
  font_size: 'textSize',
  size: 'textSize',
  fontcolor: 'textColor',
  fontcolour: 'textColor',
  color: 'textColor',
  colour: 'textColor',
  textcolour: 'textColor',
  bgcolor: 'backgroundColor',
  bgcolour: 'backgroundColor',
  background: 'backgroundColor',
  background_color: 'backgroundColor',
  backgroundcolour: 'backgroundColor',
  bordercolour: 'borderColor',
  weight: 'fontWeight',
  align: 'textAlign',
};

/** ToolJet Table column header casing — the ONLY valid values (table.js: 'As typed' / 'AA'). */
export const VALID_HEADER_CASING = new Set(['none', 'uppercase']);

/* ToolJet still accepts these column types but flags them deprecated in the inspector, and some
   (badge/badges) draw an empty cell, so the table looks silently broken. The replacements are
   ToolJet's own, from DEPRECATED_COLUMN_TYPES in the Table inspector; `tags` maps to its versioned
   successor `tagsV2` rather than the tooltip's "Multiselect", which loses the tag semantics.
   Models reach for these from prior knowledge of older ToolJet, and nothing else catches it: the
   component catalog does not advertise them at all. */
const DEPRECATED_TABLE_COLUMN_TYPES: Record<string, string> = {
  default: 'string',
  badge: 'newMultiSelect',
  badges: 'newMultiSelect',
  tags: 'tagsV2',
  dropdown: 'select',
  radio: 'select',
  toggle: 'select',
  multiselect: 'newMultiSelect',
};

const VALID_TABLE_COLUMN_TYPES = new Set([
  'string', 'number', 'text', 'datepicker', 'select', 'newMultiSelect', 'tagsV2',
  'boolean', 'image', 'link', 'json', 'markdown', 'html', 'rating', 'button',
]);

/** Form inputs that carry a label \`alignment\` style ('side' default / 'top'). A narrow one with a
 *  side label wastes most of its width on the label — warn and suggest top alignment. */
export const FORM_INPUT_TYPES = new Set([
  'TextInput',
  'NumberInput',
  'CurrencyInput',
  'PasswordInput',
  'EmailInput',
  'PhoneInput',
  'TextArea',
  'DropdownV2',
  'MultiselectV2',
  'DatePickerV2',
  'DatetimePickerV2',
  'TimePicker',
  'TreeSelect',
  'RadioButtonV2',
]);

/** Exact ToolJet INPUT_COMPONENTS_FOR_FORM list. When one of these widgets uses a top-aligned
 * label, the canvas renderer adds TOP_ALIGNMENT_HEIGHT_INCREMENT (20px) to its authored height. */
export const TOP_ALIGNED_INPUT_TYPES = new Set([
  'TextInput',
  'PasswordInput',
  'EmailInput',
  'PhoneInput',
  'CurrencyInput',
  'NumberInput',
  'DropdownV2',
  'MultiselectV2',
  'Cascader',
  'RadioButtonV2',
  'DatetimePickerV2',
  'Checkbox',
  'ToggleSwitchV2',
  'DatePickerV2',
  'TimePicker',
  'DaterangePicker',
  'TextArea',
  'StarRating',
  'TagsInput',
  'ColorPicker',
  'ButtonGroupV2',
]);
export const TOP_ALIGNMENT_HEIGHT_INCREMENT = 20;
/** At or below this width (grid columns), a side-aligned label leaves too little room for the input. */
const NARROW_SIDE_LABEL_COLS = 18;
const STATISTICS_VALUE_ONLY_MIN_WIDTH_COLS = 12;
const STATISTICS_WITH_SECONDARY_MIN_WIDTH_COLS = 18;
// A value-only tile with an icon needs more width: the icon sits beside the value, and the value font
// defaults to ~34px and word-wraps then clips (overflow hidden). Below this, a currency/large number
// renders as e.g. "$3" unless the value font is shrunk.
const STATISTICS_VALUE_ONLY_WITH_ICON_MIN_WIDTH_COLS = 18;
// A primaryValueSize at/under this is small enough that a value-only tile fits without the icon squeeze.
const STATISTICS_SAFE_VALUE_FONT_PX = 22;
const TABLE_REGULAR_ROW_HEIGHT_PX = 46;
const TABLE_CONDENSED_ROW_HEIGHT_PX = 40;
const TABLE_COLUMN_HEADER_HEIGHT_PX = 40;
const TABLE_TOOLBAR_HEIGHT_PX = 56;
const TABLE_FOOTER_HEIGHT_PX = 56;
const TABLE_BORDER_PX = 2;
/** Above this many visible Table columns, a default-width table usually forces horizontal scrolling. */
const TABLE_VISIBLE_COLUMN_WARN = 10;
const SLOT_PARENT_TYPES = new Set(['ModalV2', 'Form', 'Container']);
/** ToolJet's viewer chrome reduces the usable height of a common ~800px desktop window. Keep a
 * primary action above this authored-canvas boundary when it follows an independently scrolling
 * Table/Listview, otherwise users must operate two nested vertical scroll regions. */
const DEFAULT_DESKTOP_CONTENT_FOLD_PX = 720;
const BOUNDED_OPERATIONAL_SURFACE_TYPES = new Set(['Table', 'Listview']);
const MIN_BOUNDED_OPERATIONAL_SURFACE_HEIGHT_PX = 240;
// Root-canvas geometry on a laptop: the viewer canvas is the window minus the page rail, about 1200px on
// a 1440 screen, so one of the 43 grid columns is about 28px. Nested canvases (Kanban cards, modals) differ.
const CANVAS_COLUMN_PX = 28;
const CONTENT_COLUMNS = 39;
const TABLE_UNSIZED_COLUMN_MIN_PX = 100;
const KANBAN_CARD_WIDTH_PX = 300;
const KANBAN_CARD_CHILD_MIN_COLS = 30;
const BUTTON_CHAR_PX = 7.5;
// Readable column widths in pixels by column type; below these, values wrap mid word, money splits at the
// decimal point and status chips are cut ("Waiting on Custor", round nine 2026-09-12).
const TABLE_COLUMN_MIN_PX: Record<string, number> = {
  string: 120, text: 120, number: 80, datepicker: 110, html: 130, button: 90, badge: 110, badges: 130, tags: 130,
  link: 120, boolean: 70, toggle: 70, image: 60, select: 110, multiselect: 130, radio: 110, dropdown: 110,
};
const TABLE_COLUMN_MONEY_MIN_PX = 130;
const TABLE_COLUMN_NAME_MIN_PX = 150;
const MONEY_COLUMN_NAME = /\b(amount|price|cost|spend|revenue|budget|salary|fee)\b/i;
const NAME_COLUMN_NAME = /\b(email|contact|customer|vendor|product|title|subject|description|address|category)\b/i;
const columnWords = (value: string): string => value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]/g, ' ');
const BUTTON_PADDING_PX = 32;

interface Rect {
  top?: number;
  left?: number;
  width?: number;
  height?: number;
}
export interface LintComponent {
  id?: string;
  name?: string;
  type?: string;
  properties?: Record<string, unknown>;
  styles?: Record<string, unknown>;
  layout?: Rect;
  layouts?: { desktop?: Rect; mobile?: Rect };
  clientRef?: string;
  parentRef?: string;
  parent?: string;
  slotName?: ComponentSlotName;
}

/** Read a property whose value is wrapped as `{ value: X }` (ToolJet's shape), or a bare value. */
function propVal(props: Record<string, unknown> | undefined, key: string): unknown {
  const p = props?.[key] as { value?: unknown } | undefined;
  return p && typeof p === 'object' && 'value' in p ? p.value : p;
}

function editDistance(left: string, right: string): number {
  const previous = Array.from({ length: right.length + 1 }, (_, index) => index);
  for (let leftIndex = 1; leftIndex <= left.length; leftIndex += 1) {
    const current = [leftIndex];
    for (let rightIndex = 1; rightIndex <= right.length; rightIndex += 1) {
      current[rightIndex] = Math.min(
        current[rightIndex - 1]! + 1,
        previous[rightIndex]! + 1,
        previous[rightIndex - 1]! + (left[leftIndex - 1] === right[rightIndex - 1] ? 0 : 1)
      );
    }
    previous.splice(0, previous.length, ...current);
  }
  return previous[right.length]!;
}

export function nearestCatalogKey(value: string, candidates: string[]): string | undefined {
  const normalized = value.toLowerCase();
  const ranked = candidates
    .map((candidate) => ({ candidate, distance: editDistance(normalized, candidate.toLowerCase()) }))
    .sort((left, right) => left.distance - right.distance || left.candidate.localeCompare(right.candidate));
  const best = ranked[0];
  return best && best.distance <= Math.max(2, Math.floor(normalized.length * 0.25)) ? best.candidate : undefined;
}

function projectedTableDataKeys(value: unknown): string[] | undefined {
  if (typeof value !== 'string' || !/\.map\s*\(/.test(value)) return undefined;
  const arrowObject = value.match(/=>\s*\(\s*\{/);
  const returnedObject = value.match(/=>\s*\{[\s\S]*?\breturn\s*\{/);
  const projection = arrowObject ?? returnedObject;
  if (projection?.index === undefined) return undefined;
  const objectOffset = projection[0].lastIndexOf('{');
  if (objectOffset < 0) return undefined;
  const objectStart = projection.index + objectOffset;

  const chunks: string[] = [];
  let chunkStart = objectStart + 1;
  let braceDepth = 0;
  let bracketDepth = 0;
  let parenDepth = 0;
  let quote: '"' | "'" | '`' | undefined;
  let escaped = false;
  for (let index = objectStart + 1; index < value.length; index++) {
    const char = value[index]!;
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (char === '\\') {
        escaped = true;
      } else if (char === quote) {
        quote = undefined;
      }
      continue;
    }
    if (char === '"' || char === "'" || char === '`') {
      quote = char;
      continue;
    }
    if (char === '{') braceDepth++;
    else if (char === '}') {
      if (braceDepth === 0) {
        chunks.push(value.slice(chunkStart, index));
        break;
      }
      braceDepth--;
    } else if (char === '[') bracketDepth++;
    else if (char === ']') bracketDepth--;
    else if (char === '(') parenDepth++;
    else if (char === ')') parenDepth--;
    else if (char === ',' && braceDepth === 0 && bracketDepth === 0 && parenDepth === 0) {
      chunks.push(value.slice(chunkStart, index));
      chunkStart = index + 1;
    }
  }
  if (!chunks.length) return undefined;

  const keys: string[] = [];
  for (const rawChunk of chunks) {
    const chunk = rawChunk.trim();
    if (!chunk) continue;
    // A top-level spread preserves every source key, so the projection is not closed.
    if (chunk.startsWith('...') || chunk.startsWith('[')) return undefined;
    const identifier = chunk.match(/^([A-Za-z_$][\w$]*)\s*(?::|$)/);
    if (identifier) {
      keys.push(identifier[1]!);
      continue;
    }
    const quoted = chunk.match(/^(?:"([^"]+)"|'([^']+)')\s*:/);
    const quotedKey = quoted?.[1] ?? quoted?.[2];
    if (quotedKey !== undefined) {
      keys.push(quotedKey);
      continue;
    }
    return undefined;
  }
  return keys;
}

function explicitlyProjectsTableData(value: unknown): boolean {
  return projectedTableDataKeys(value) !== undefined;
}

function explicitlyProjectsObjectData(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const expression = value.trim().replace(/^\{\{\s*/, '').replace(/\s*\}\}$/, '').trim();
  const directObject = /^\(*\s*\{/.test(expression);
  const returnedObject = /\breturn\s*\{/.test(expression);
  return (directObject || returnedObject) && !expression.includes('...');
}

function visibilityExpression(component: LintComponent): string | undefined {
  const value = propVal(component.properties, 'visibility');
  if (typeof value !== 'string') return undefined;
  const trimmed = value.trim();
  return trimmed.startsWith('{{') && trimmed.endsWith('}}')
    ? trimmed.slice(2, -2).trim()
    : undefined;
}

function stripOuterParens(value: string): string {
  let result = value;
  while (result.startsWith('(') && result.endsWith(')')) {
    let depth = 0;
    let enclosesWholeExpression = true;
    for (let index = 0; index < result.length; index++) {
      if (result[index] === '(') depth++;
      if (result[index] === ')') depth--;
      if (depth === 0 && index < result.length - 1) {
        enclosesWholeExpression = false;
        break;
      }
    }
    if (!enclosesWholeExpression) break;
    result = result.slice(1, -1);
  }
  return result;
}

function rowsStateExpression(value: string): { query: string; state: 'empty' | 'present' } | undefined {
  const compact = value.replace(/\s+/g, '').replace(/[()]/g, '');
  const queries = [...compact.matchAll(/queries\.([A-Za-z_$][\w$]*)\.(?:isLoading|data)/g)]
    .map((match) => match[1]!);
  if (!queries.length || new Set(queries).size !== 1) return undefined;
  const query = queries[0]!;
  if (compact === `queries.${query}.isLoading||queries.${query}.data||[].length>0`) {
    return { query, state: 'present' };
  }
  if (compact === `!queries.${query}.isLoading&&queries.${query}.data||[].length===0`) {
    return { query, state: 'empty' };
  }
  return undefined;
}

/** Only suppress geometry warnings when two visibility bindings are provably disjoint. */
function mutuallyExclusiveVisibility(a: LintComponent, b: LintComponent): boolean {
  const aVisibility = propVal(a.properties, 'visibility');
  const bVisibility = propVal(b.properties, 'visibility');
  if (isFalseBinding(aVisibility) || isFalseBinding(bVisibility)) return true;
  const aExpression = visibilityExpression(a);
  const bExpression = visibilityExpression(b);
  if (!aExpression || !bExpression) return false;
  const aCompact = stripOuterParens(aExpression.replace(/\s+/g, ''));
  const bCompact = stripOuterParens(bExpression.replace(/\s+/g, ''));
  const negates = (left: string, right: string): boolean =>
    left.startsWith('!') && stripOuterParens(left.slice(1)) === stripOuterParens(right);
  if (negates(aCompact, bCompact) || negates(bCompact, aCompact)) return true;
  const aRowsState = rowsStateExpression(aExpression);
  const bRowsState = rowsStateExpression(bExpression);
  return !!aRowsState && !!bRowsState &&
    aRowsState.query === bRowsState.query && aRowsState.state !== bRowsState.state;
}

function recordValue(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
}

function looksDateLikeField(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const normalized = value
    .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_');
  return /(?:^|_)(?:date|datetime|timestamp|created|updated|submitted|requested|started|ended|expires|expired|due)(?:_at|_date|_time)?$/.test(normalized);
}

function isTruthyBinding(v: unknown): boolean {
  return v === true || v === '{{true}}' || v === 'true';
}

/** A user-facing column header that is really a raw database field name (snake_case), e.g. "order_date". */
function looksRawFieldHeader(value: unknown): boolean {
  return typeof value === 'string' && /^[a-z0-9]+(?:_[a-z0-9]+)+$/.test(value.trim());
}

/** An internal identifier field usually meaningless to end users, e.g. "id", "row_id", "customer_id". */
function looksInternalIdField(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const normalized = value.trim().toLowerCase();
  return /^id$/.test(normalized) || /_id$/.test(normalized) || /(?:^|_)uuid$/.test(normalized);
}

function isTrueBinding(v: unknown): boolean {
  if (v === true) return true;
  return typeof v === 'string' && /^\s*(\{\{\s*true\s*\}\}|true)\s*$/i.test(v);
}

function isFalseBinding(v: unknown): boolean {
  return v === false || v === '{{false}}' || v === 'false';
}

function differsFromCatalogDefault(type: string, key: string, value: unknown): boolean {
  if (value === undefined) return false;
  const defaultValue = getComponentSchema(type)?.properties.find((property) => property.key === key)?.default;
  return defaultValue === undefined || JSON.stringify(value) !== JSON.stringify(defaultValue);
}

function catalogValue(
  type: string,
  entries: Record<string, unknown> | undefined,
  key: string,
  section: 'properties' | 'styles' = 'properties'
): unknown {
  const authored = propVal(entries, key);
  if (authored !== undefined) return authored;
  return getComponentSchema(type)?.[section].find((entry) => entry.key === key)?.default;
}

function isDynamicBinding(value: unknown): boolean {
  return typeof value === 'string' && value.includes('{{');
}

function nestedMapInValue(value: unknown): boolean {
  if (typeof value === 'string') return value.includes('{{') && hasNestedMapCall(value);
  if (Array.isArray(value)) return value.some(nestedMapInValue);
  if (value && typeof value === 'object') return Object.values(value as Record<string, unknown>).some(nestedMapInValue);
  return false;
}

/** The projection checker only certifies arrow-object projections. Explain unsupported function
 * callbacks directly instead of sending the model into column/autogeneration repair loops.
 * Parse without executing; quoted examples and unrelated callbacks must not trigger this hint. */
function functionStyleTableMap(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const binding = value.trim().match(/^\{\{([\s\S]*)\}\}$/);
  if (!binding) return false;
  let root: unknown;
  try { root = parseExpression(binding[1]!); } catch { return false; }
  const visit = (value: unknown): boolean => {
    if (Array.isArray(value)) return value.some(visit);
    if (!value || typeof value !== 'object') return false;
    const node = value as Record<string, any>;
    const callee = node.callee;
    if (['CallExpression', 'OptionalCallExpression'].includes(node.type) &&
        callee && ['MemberExpression', 'OptionalMemberExpression'].includes(callee.type) &&
        (callee.computed ? callee.property?.value === 'map' : callee.property?.name === 'map') &&
        node.arguments?.[0]?.type === 'FunctionExpression') return true;
    return Object.values(node).some(visit);
  };
  return visit(root);
}

function statementBodyMapInValue(value: unknown): boolean {
  if (typeof value === 'string') {
    return value.includes('{{') && /\.map\s*\(\s*(?:async\s+)?(?:[A-Za-z_$][\w$]*|\([^)]*\))\s*=>\s*\{/.test(value);
  }
  if (Array.isArray(value)) return value.some(statementBodyMapInValue);
  if (value && typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).some(statementBodyMapInValue);
  }
  return false;
}

function unsafeEmptyArrayFirstRowFallback(value: unknown): boolean {
  if (typeof value === 'string') {
    return value.includes('{{') && /\|\|\s*\[\s*\{\s*\}\s*\]\s*\)\s*\[\s*0\s*\]\s*\./.test(value);
  }
  if (Array.isArray(value)) return value.some(unsafeEmptyArrayFirstRowFallback);
  if (value && typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).some(unsafeEmptyArrayFirstRowFallback);
  }
  return false;
}

/** ToolJet's component-expression evaluator can fail on a map call nested inside another map callback.
 * Distinguish true nesting from safe sequential chains such as rows.map(...).map(...). */
function hasNestedMapCall(source: string): boolean {
  const parenthesisStack: boolean[] = [];
  let quote: "'" | '"' | undefined;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;

  for (let index = 0; index < source.length; index += 1) {
    const current = source[index];
    const next = source[index + 1];
    if (lineComment) {
      if (current === '\n') lineComment = false;
      continue;
    }
    if (blockComment) {
      if (current === '*' && next === '/') {
        blockComment = false;
        index += 1;
      }
      continue;
    }
    if (quote) {
      if (escaped) escaped = false;
      else if (current === '\\') escaped = true;
      else if (current === quote) quote = undefined;
      continue;
    }
    if (current === '/' && next === '/') {
      lineComment = true;
      index += 1;
      continue;
    }
    if (current === '/' && next === '*') {
      blockComment = true;
      index += 1;
      continue;
    }
    if (current === "'" || current === '"') {
      quote = current;
      continue;
    }
    if (current === '(') {
      const isMapCall = /\.map\s*$/.test(source.slice(Math.max(0, index - 24), index));
      if (isMapCall && parenthesisStack.some(Boolean)) return true;
      parenthesisStack.push(isMapCall);
    } else if (current === ')') {
      parenthesisStack.pop();
    }
  }
  return false;
}

function staticNumber(v: unknown, fallback: number): number {
  return optionalStaticNumber(v) ?? fallback;
}

function optionalStaticNumber(v: unknown): number | undefined {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string') {
    const match = v.trim().match(/^(?:\{\{\s*)?(\d+(?:\.\d+)?)(?:\s*\}\})?(?:px)?$/);
    if (match) return Number(match[1]);
  }
  return undefined;
}

/** ToolJet adds 20px outside the authored layout box for a top-aligned labelled form input.
 * Missing label metadata is treated as the catalog default (labelType:auto), which also increments. */
export function renderedHeight(component: LintComponent, rect?: Rect): number {
  const layout = rect ?? component.layouts?.desktop ?? component.layout;
  const authored = layout?.height ?? 0;
  if (!TOP_ALIGNED_INPUT_TYPES.has(component.type ?? '')) return authored;
  if (propVal(component.styles, 'alignment') !== 'top') return authored;

  const labelType = propVal(component.properties, 'labelType');
  const label = propVal(component.properties, 'label');
  const hasRenderedLabel =
    labelType === undefined ||
    labelType === 'auto' ||
    label === undefined ||
    (typeof label === 'string' ? label.trim().length > 0 : Boolean(label));
  return authored + (hasRenderedLabel ? TOP_ALIGNMENT_HEIGHT_INCREMENT : 0);
}

/** Standard single-line form controls keep their catalog-default authored height. Making the
 *  component taller does not enlarge its value text; with a top-aligned label ToolJet adds a
 *  separate 20px rendered footprint outside that authored box. Treat the catalog's
 *  compactFormHeight hint as the source-of-truth marker instead of duplicating a component list. */
export function lintStandardSingleLineInputHeight(component: LintComponent): string[] {
  const schema = component.type ? getComponentSchema(component.type) : undefined;
  const defaultHeight = schema?.defaultSize?.height;
  if (!schema?.renderingHints?.compactFormHeight || defaultHeight === undefined) return [];

  const layouts: Array<[string, Rect]> = [];
  if (component.layout) layouts.push(['layout', component.layout]);
  if (component.layouts?.desktop) layouts.push(['desktop', component.layouts.desktop]);
  if (component.layouts?.mobile) layouts.push(['mobile', component.layouts.mobile]);

  const label = component.name ?? component.type ?? 'component';
  return layouts.flatMap(([layoutName, layout]) => {
    const authoredHeight = layout.height;
    if (authoredHeight === undefined || authoredHeight <= defaultHeight) return [];
    return [
      `${component.type} "${label}": ${layoutName} authored height ${authoredHeight}px exceeds the standard ` +
        `single-line height ${defaultHeight}px. Oversizing does not enlarge the value text. Keep height at ` +
        `${defaultHeight}px; a top-aligned label renders ${TOP_ALIGNMENT_HEIGHT_INCREMENT}px outside the authored ` +
        `box, so move the following row down instead of increasing this field's height.`,
    ];
  });
}

/** Text renders inside 4px of canvas-wrapper padding plus its own 1px top/bottom border. A single
 * line therefore needs fontSize * lineHeight + 6 authored pixels or descenders are clipped. */
export function minimumTextHeight(component: LintComponent): number | undefined {
  if (component.type !== 'Text') return undefined;
  const dynamicHeight = propVal(component.properties, 'dynamicHeight');
  if (isTruthyBinding(dynamicHeight)) return undefined;
  if (typeof dynamicHeight === 'string' && /\{\{/.test(dynamicHeight) && !isFalseBinding(dynamicHeight)) return undefined;

  const textSizeValue = propVal(component.styles, 'textSize');
  const lineHeightValue = propVal(component.styles, 'lineHeight');
  const textSize = textSizeValue === undefined ? 14 : optionalStaticNumber(textSizeValue);
  const lineHeight = lineHeightValue === undefined ? 1.5 : optionalStaticNumber(lineHeightValue);
  if (textSize === undefined || lineHeight === undefined) return undefined;
  return Math.ceil(textSize * lineHeight + 6);
}

/** Height below the rendered line box itself is unusable; wrapper chrome is handled as a warning. */
function minimumTextContentHeight(component: LintComponent): number | undefined {
  const minimum = minimumTextHeight(component);
  return minimum === undefined ? undefined : minimum - 6;
}

export function lintUnusableTextGeometry(components: LintComponent[]): string[] {
  const errors: string[] = [];
  for (const component of components) {
    const minimum = minimumTextContentHeight(component);
    if (minimum === undefined) continue;
    const layouts: Array<[string, Rect | undefined]> = [
      [component.layouts?.desktop ? 'desktop' : 'layout', component.layouts?.desktop ?? component.layout],
      ['mobile', component.layouts?.mobile],
    ];
    const undersized = layouts.filter((entry): entry is [string, Rect] =>
      !!entry[1] && typeof entry[1].height === 'number' && entry[1].height < minimum
    );
    if (undersized.length) {
      const recommended = minimumTextHeight(component)!;
      errors.push(
        `Text "${component.name ?? component.id ?? 'Text'}" is too short to render one line: ` +
          `${undersized.map(([resolution, layout]) => `${resolution} height ${layout.height}px`).join(', ')}; ` +
          `use at least ${recommended}px or enable dynamicHeight.`
      );
    }
  }
  return errors;
}

export function introducedLintFindings(before: string[], after: string[]): string[] {
  const existing = new Set(before);
  return after.filter((finding) => !existing.has(finding));
}

export function lintTextGeometry(components: LintComponent[]): string[] {
  const warnings: string[] = [];
  for (const component of components) {
    const minimum = minimumTextHeight(component);
    if (minimum === undefined) continue;
    const desktop = component.layouts?.desktop ?? component.layout;
    const mobile = component.layouts?.mobile ?? component.layout;
    const layouts: Array<[string, Rect]> = [];
    if (desktop) layouts.push([component.layouts?.desktop ? 'desktop' : 'layout', desktop]);
    if (mobile && mobile !== desktop) layouts.push(['mobile', mobile]);
    const undersized = layouts.filter(([, rect]) => typeof rect.height === 'number' && rect.height < minimum);
    if (!undersized.length) continue;
    const recommended = Math.ceil(minimum / 10) * 10;
    warnings.push(
      `Text "${component.name ?? component.id ?? 'Text'}" is too short for its static font/line height: ` +
        `${undersized.map(([resolution, rect]) => `${resolution} height ${rect.height}px`).join(', ')}; ` +
        `a single line needs at least ${minimum}px (use ${recommended}px on ToolJet's 10px grid), otherwise ` +
        `bold glyphs and descenders are clipped. Enable dynamicHeight for intentionally wrapping content.`
    );
  }
  return warnings;
}

function componentKey(component: LintComponent): string | undefined {
  return component.clientRef ?? component.id;
}

function parentPlacement(component: LintComponent): {
  parentId: string;
  slotName: ComponentSlotName;
} | undefined {
  if (component.parentRef) {
    return { parentId: component.parentRef, slotName: component.slotName ?? 'body' };
  }
  if (!component.parent) return undefined;
  const decoded = decodeComponentParent(component.parent);
  return { parentId: decoded.parentId, slotName: component.slotName ?? decoded.slotName };
}

function placementKey(component: LintComponent): string {
  const placement = parentPlacement(component);
  return placement ? `${placement.parentId}::${placement.slotName}` : '__page__';
}

/** Validate named slot placement when the parent is available in the same component set. */
export function lintComponentSlots(components: LintComponent[]): string[] {
  const errors: string[] = [];
  const refs = new Map(
    components.flatMap((component) => {
      const key = componentKey(component);
      return key ? [[key, component] as const] : [];
    })
  );
  for (const component of components) {
    const persistedSlot = component.parent ? decodeComponentParent(component.parent).slotName : 'body';
    const slotName = component.slotName ?? (persistedSlot === 'body' ? undefined : persistedSlot);
    if (!slotName) continue;
    const placement = parentPlacement(component);
    const parent = placement ? refs.get(placement.parentId) : undefined;
    const validParent = slotName === 'modal' ? parent?.type === 'Kanban' :
      SLOT_PARENT_TYPES.has(parent?.type ?? '') || (slotName === 'body' && parent?.type === 'Kanban');
    if (parent && !validParent) {
      errors.push(
        `Component "${component.name ?? component.id ?? component.type}" uses slot_name:"${slotName}" with ` +
          `${parent.type ?? 'unknown'} parent "${parent.name ?? parent.id}"; header/body/footer belong to ModalV2, Form, and Container; Kanban supports body (card) and modal.`
      );
    }
  }
  return errors;
}

/** Cross-component Kanban checks that require seeing both the board and its card children. */
export function lintKanbanInteractions(components: LintComponent[]): string[] {
  const warnings: string[] = [];
  const boards = components.filter((component) => component.type === 'Kanban');
  for (const board of boards) {
    const key = componentKey(board);
    if (!key) continue;
    const openModal = propVal(board.properties, 'openModalOnCardClick');
    const nativeModalEnabled = openModal === undefined || isTruthyBinding(openModal);
    if (!nativeModalEnabled) continue;
    const modalChildren = components.filter(component => {
      const p = parentPlacement(component);
      return p?.parentId === key && p.slotName === 'modal';
    });
    if (modalChildren.length) continue;
    warnings.push(
      `Kanban "${board.name ?? board.id ?? 'Kanban'}" enables the native card modal but has no modal children. ` +
        'Cards (including custom Html) can look correct while a blank built-in modal covers page-level detail controls. ' +
        'Parent the detail controls to this Kanban with slot_name:"modal"; ordinary body children only populate cards. ' +
        'For a board without card selection use openModalOnCardClick:false and omit onCardSelected. Never merely enable the modal to satisfy the event lint without giving it content.'
    );
  }
  return warnings;
}

/** A Kanban card is its own 43-column canvas about 300px wide, so a title child at the catalog default of
 *  14 columns is under 100px and cuts a customer name after a few characters (round eight, 2026-09-12). */
export function lintKanbanCardChildren(components: LintComponent[]): string[] {
  const errors: string[] = [];
  for (const board of components.filter((component) => component.type === 'Kanban')) {
    const key = componentKey(board);
    if (!key) continue;
    for (const child of components) {
      if (parentPlacement(child)?.parentId !== key || parentPlacement(child)?.slotName !== 'body') continue;
      if (child.type !== 'Text' && child.type !== 'Html') continue;
      const width = (child.layouts?.desktop ?? child.layout)?.width;
      if (typeof width !== 'number' || width >= KANBAN_CARD_CHILD_MIN_COLS) continue;
      const px = Math.round((width / 43) * KANBAN_CARD_WIDTH_PX);
      errors.push(
        `Kanban "${board.name ?? board.id ?? 'Kanban'}" card child ${child.type} "${child.name ?? child.id ?? child.type}": width ${width} columns ` +
          `is about ${px}px of the ${KANBAN_CARD_WIDTH_PX}px card (card children use the card's own 43-column grid), so a name or title is cut ` +
          'after a few characters. For long titles prefer left 2, width 39; short badges or metadata may stay compact after checking their actual text.'
      );
    }
  }
  return errors;
}

/** Spare space can be a composition defect or a deliberate neighboring region. Advisory only. */
export function lintStatisticsRows(components: LintComponent[]): string[] {
  const errors: string[] = [];
  const tiles = components.filter((component) => component.type === 'Statistics' && !parentPlacement(component)?.parentId);
  if (tiles.length < 2) return errors;
  const rect = (component: LintComponent) => component.layouts?.desktop ?? component.layout;
  const rows: LintComponent[][] = [];
  for (const tile of [...tiles].sort((a, b) => (rect(a)?.top ?? 0) - (rect(b)?.top ?? 0))) {
    const row = rows.find((candidate) => Math.abs((rect(candidate[0])?.top ?? 0) - (rect(tile)?.top ?? 0)) <= 6);
    if (row) row.push(tile);
    else rows.push([tile]);
  }
  for (const row of rows) {
    const span = row.reduce((sum, tile) => sum + (rect(tile)?.width ?? 0), 0);
    if (span >= CONTENT_COLUMNS - 5) continue;
    const names = row.map((tile) => `"${tile.name ?? tile.id ?? 'Statistics'}"`).join(', ');
    errors.push(
      `Statistics row at top ${rect(row[0])?.top ?? 0}px (${names}) spans ${span} of the ${CONTENT_COLUMNS} content columns and leaves an empty slot, ` +
        'which may be intentional beside another region. Check hierarchy and alignment; widen/rebalance an accidental gap, ' +
        'but retain deliberate compact or multi-row groups when the content is readable.'
    );
  }
  return errors;
}

/** Inspect syntax only. Never execute model-authored bindings, even in a Node vm.
 * Property boundaries and operator precedence belong to the parser, not a character scan.
 * Only provably unterminated opening tags in explicitly HTML columns block writes. */
export function lintTableProjectionRender(spec: LintComponent, warnings: string[] = []): string[] {
  if (spec.type !== 'Table') return [];
  const data = propVal(spec.properties, 'data');
  if (typeof data !== 'string') return [];
  const binding = data.trim().match(/^\{\{([\s\S]*)\}\}$/);
  if (!binding) return [];
  let root: unknown;
  try { root = parseExpression(binding[1]); } catch { return []; } // syntax lint owns parse errors
  type Ast = Record<string, any>;
  type Literal = string | number | boolean | null | undefined;
  const errors: string[] = [];
  const columns = propVal(spec.properties, 'columns');
  const reported = new Map<string, { proven: boolean; message: string }>();

  // Bounded abstract evaluation of literals only: no calls, getters, identifiers or runtime code.
  // null means unknown, not invalid. Dynamic keys and inherited properties stay unknown.
  const variants = (node: Ast, depth = 0): Literal[] | null => {
    if (!node || depth > 32) return null;
    if (['StringLiteral', 'NumericLiteral', 'BooleanLiteral'].includes(node.type)) return [node.value];
    if (node.type === 'NullLiteral') return [null];
    if (node.type === 'LogicalExpression' && node.operator === '||') {
      const left = variants(node.left, depth + 1);
      if (!left) return null;
      if (left.every(Boolean)) return left;
      if (left.every((v) => !v)) return variants(node.right, depth + 1);
      return null;
    }
    if (node.type === 'BinaryExpression' && node.operator === '+') {
      const left = variants(node.left, depth + 1), right = variants(node.right, depth + 1);
      if (!left || !right || left.length * right.length > 16) return null;
      const values: Literal[] = [];
      for (const a of left) for (const b of right) {
        // Only string concatenation; this check does not need to evaluate arithmetic.
        if (typeof a !== 'string' && typeof b !== 'string') return null;
        const value = String(a) + String(b);
        if (value.length > 8192) return null;
        values.push(value);
      }
      return values;
    }
    if (node.type === 'TemplateLiteral' && node.expressions.length === 0) return [node.quasis[0].value.cooked];
    if (['MemberExpression', 'OptionalMemberExpression'].includes(node.type) && node.object?.type === 'ObjectExpression') {
      const props = node.object.properties;
      if (props.length > 15 || props.some((p: Ast) => p.type !== 'ObjectProperty' || p.computed || p.method ||
          (p.key.name ?? p.key.value) === '__proto__')) return null;
      const key = node.computed
        ? (['StringLiteral', 'NumericLiteral'].includes(node.property?.type) ? String(node.property.value) : undefined)
        : node.property?.name;
      if (key === undefined) return null;
      const prop = [...props].reverse().find((p: Ast) => String(p.key.name ?? p.key.value) === key);
      return prop ? variants(prop.value, depth + 1) : null;
    }
    return null;
  };
  const skeleton = (node: Ast, depth = 0): string => {
    if (!node || depth > 32) return '?';
    if (node.type === 'StringLiteral') return node.value;
    if (node.type === 'BinaryExpression' && node.operator === '+') return (skeleton(node.left, depth + 1) + skeleton(node.right, depth + 1)).slice(0, 8192);
    if (node.type === 'TemplateLiteral') return node.quasis.map((q: Ast) => q.value.cooked ?? '').join('?');
    return '?';
  };
  // Recognize actual opening tags and respect quoted ">" inside attributes. Not plain "x < y".
  const unfinishedTag = (text: string): boolean => {
    const start = /<[A-Za-z][\w:-]*(?=[\s/>]|$)/g;
    let match: RegExpExecArray | null;
    while ((match = start.exec(text))) {
      let quote = '', closed = false;
      for (let i = start.lastIndex; i < text.length; i++) {
        const c = text[i];
        if (quote) { if (c === quote) quote = ''; }
        else if (c === '"' || c === "'") quote = c;
        else if (c === '>') { start.lastIndex = i + 1; closed = true; break; }
      }
      if (!closed) return true;
    }
    return false;
  };
  const inspect = (node: Ast, key: string, depth = 0, canBlock = true): void => {
    if (!node || depth > 32) return;
    if (node.type === 'ConditionalExpression') {
      const test = variants(node.test);
      if (!test || !test.every((v) => !v)) inspect(node.consequent, key, depth + 1, canBlock);
      if (!test || !test.every(Boolean)) inspect(node.alternate, key, depth + 1, canBlock);
      return;
    }
    if (node.type !== 'LogicalExpression' || node.operator !== '||') return;
    // A || nested under concatenation is grouped; its suffix still runs. Inspect only returned
    // logical branches, not arbitrary descendants, helper calls, or unrelated object properties.
    inspect(node.left, key, depth + 1, canBlock);
    const left = variants(node.left);
    if (!left || !left.every(Boolean)) inspect(node.right, key, depth + 1, canBlock);
    const possible = unfinishedTag(skeleton(node.left)) || left?.some((v) => typeof v === 'string' && unfinishedTag(v));
    if (!possible) return;
    const column = Array.isArray(columns) ? columns.find((c: any) => c?.key === key) : undefined;
    const proven = canBlock && column?.columnType === 'html' && left !== null &&
      left.every((v) => typeof v === 'string' && v.length > 0 && unfinishedTag(v));
    const message = 'Table "' + (spec.name ?? spec.type) + '" column "' + key + '": ' +
      (proven ? 'the data projection renders broken markup for this cell. ' :
        'the data projection may short-circuit while constructing HTML; runtime values must be verified. ') +
      'The left branch of || contains an unfinished opening tag. When truthy, it skips the fallback and its closing markup. ' +
      'If the fallback is part of the attribute, group it before concatenating the closing markup: (lookup[x] || fallback).';
    if (!reported.has(key) || (proven && !reported.get(key)!.proven)) reported.set(key, { proven, message });
  };
  let remaining = 20_000;
  const visit = (value: unknown, depth = 0): void => {
    if (--remaining < 0 || depth > 128 || !value || typeof value !== 'object') return;
    if (Array.isArray(value)) { for (const item of value) visit(item, depth + 1); return; }
    const node = value as Ast, callee = node.callee;
    if (['CallExpression', 'OptionalCallExpression'].includes(node.type) &&
        ['MemberExpression', 'OptionalMemberExpression'].includes(callee?.type) &&
        (callee.computed ? callee.property?.value === 'map' : callee.property?.name === 'map') &&
        node.arguments?.[0]?.type === 'ArrowFunctionExpression' && node.arguments[0].body.type === 'ObjectExpression') {
      // Only the outermost returned map proves a rendered value. Intermediate maps
      // can be overwritten, filtered or consumed as scratch data by a later step.
      // Within an object, the last property wins; a later spread/computed key makes
      // the effective value unknown, so it cannot justify a blocking error.
      const seen = new Set<string>();
      let unknownOverride = false;
      for (const prop of [...node.arguments[0].body.properties].reverse()) {
        if (prop.type !== 'ObjectProperty' || (prop.computed && prop.key.type !== 'StringLiteral')) {
          unknownOverride = true;
          continue;
        }
        const key = String(prop.key.name ?? prop.key.value);
        if (seen.has(key)) continue;
        seen.add(key);
        inspect(prop.value, key, 0, node === root && !unknownOverride);
      }
    }
    for (const child of Object.values(node)) visit(child, depth + 1);
  };
  visit(root);
  for (const { proven, message } of reported.values()) (proven ? errors : warnings).push(message);
  return errors;
}

/** An empty-state message ("No users found", "Keine Nutzer gefunden.") with no visibility binding shows
 *  under a populated table (round nine, 2026-09-12). It must be bound to the data being empty. */
const EMPTY_STATE_TEXT = /^(?:no\s+(?:\w+\s+){0,3}(?:found|available|yet|records?|results?|items?)|nothing\s+(?:found|available|yet)|keine?\s+\w+\s+gefunden)[.!\s]*$/i;
export function lintUnboundEmptyState(spec: LintComponent): string[] {
  if (spec.type !== 'Text' && spec.type !== 'Html') return [];
  const key = spec.type === 'Html' ? 'rawHtml' : 'text';
  const text = propVal(spec.properties ?? {}, key);
  if (typeof text !== 'string' || text.includes('{{')) return [];
  const name = spec.name ?? '';
  if (!EMPTY_STATE_TEXT.test(text.replace(/<[^>]*>/g, '').trim()) && !/empty/i.test(name)) return [];
  const visibility = propVal(spec.properties ?? {}, 'visibility') ?? propVal(spec.styles ?? {}, 'visibility');
  if (typeof visibility === 'string' && visibility.includes('{{') && !/^\{\{\s*(true|false)\s*\}\}$/.test(visibility.trim())) return [];
  return [
    `${spec.type} "${name || spec.id || spec.type}": the empty-state message "${text.trim().slice(0, 40)}" has no visibility binding, so it shows ` +
      'under a populated table. Bind visibility to the data being empty ({{(queries.<q>.data || []).length === 0}}), or drop the ' +
      'component: a Table shows its own empty message.',
  ];
}

/** A Tabs component with no child components renders its tab strip over an empty box (a 490px white
 *  panel on a round-nine docs page). Tab content is children placed with parent_ref and the tab's slot. */
export function lintEmptyTabs(components: LintComponent[]): string[] {
  const errors: string[] = [];
  for (const tabs of components.filter((component) => component.type === 'Tabs')) {
    const key = componentKey(tabs);
    if (!key) continue;
    // Tab children carry the tab index in their parent id ("<tabs>-0"), which the slot decoder leaves intact.
    const children = components.filter((component) => {
      const parentId = parentPlacement(component)?.parentId;
      return parentId === key || (typeof parentId === 'string' && parentId.startsWith(`${key}-`) && /^\d+$/.test(parentId.slice(key.length + 1)));
    });
    if (children.length) continue;
    const height = (tabs.layouts?.desktop ?? tabs.layout)?.height;
    errors.push(
      `Tabs "${tabs.name ?? tabs.id ?? 'Tabs'}" has no child components, so it renders its tab strip over an empty ${height ?? ''}px box. ` +
        'Give every tab its content (Text, Html, Table) as children with parent_ref and the tab\'s slot, or replace the Tabs with a plain panel.'
    );
  }
  return errors;
}

/** ToolJet renders the catalog's literal "Label" caption when an input's label is missing or an empty
 *  string (round eleven, 2026-09-12: five search boxes captioned "Label"). A real caption is required. */
const LABELLED_INPUT_TYPES = new Set(['TextInput', 'NumberInput', 'TextArea', 'PasswordInput', 'EmailInput', 'DatePickerV2', 'DatetimePickerV2', 'TimePicker', 'DaterangePicker', 'Checkbox', 'ToggleSwitchV2', 'RadioButtonV2', 'FilePicker']);
export function lintDefaultInputLabel(spec: LintComponent): string[] {
  if (!LABELLED_INPUT_TYPES.has(spec.type ?? '')) return [];
  const label = propVal(spec.properties ?? {}, 'label');
  const text = typeof label === 'string' ? label.trim() : label;
  if (text !== undefined && text !== '' && text !== 'Label') return [];
  return [
    `${spec.type} "${spec.name ?? spec.id ?? spec.type}": ${text === undefined ? 'no label' : 'an empty label'} renders the catalog's literal "Label" caption ` +
      'above the box. Give it the field\'s name ("Search", "Warehouse name"); a search box is labelled Search.',
  ];
}

/** A data surface with a static disabledState renders faded and inert: a Sol build (2026-09-12) set it on a
 *  read-only Kanban and the whole board looked greyed out. Read-only is a property choice, not disabled. */
const DISABLED_SURFACE_TYPES = new Set(['Kanban', 'Table', 'Listview', 'Chart', 'Form', 'Tabs', 'Container']);
export function lintStaticDisabledSurface(spec: LintComponent): string[] {
  if (!DISABLED_SURFACE_TYPES.has(spec.type ?? '')) return [];
  const value = propVal(spec.styles ?? {}, 'disabledState') ?? propVal(spec.properties ?? {}, 'disabledState');
  const staticTrue = value === true || (typeof value === 'string' && /^\s*(\{\{\s*true\s*\}\}|true)\s*$/.test(value));
  if (!staticTrue) return [];
  return [
    `${spec.type} "${spec.name ?? spec.id ?? spec.type}": disabledState is a static true, so the whole component renders faded and inert and ` +
      'reads as broken. For a read-only surface leave disabledState off and turn the editing affordances off instead ' +
      '(a Kanban: no add-card, no card modal; a Table: allowSelection false, no row actions).',
  ];
}

/** A Button narrower than its label wraps the label onto two lines inside a 40px button (an "Add product"
 *  button at 3 columns, round eight). Root canvas only: nested canvases have a different column width. */
export function lintButtonLabelWidth(spec: LintComponent): string[] {
  if (spec.type !== 'Button' || parentPlacement(spec)?.parentId) return [];
  const text = propVal(spec.properties ?? {}, 'text');
  if (typeof text !== 'string' || text.includes('{{') || !text.trim()) return [];
  const width = (spec.layouts?.desktop ?? spec.layout)?.width;
  if (typeof width !== 'number' || width <= 0) return [];
  const neededPx = Math.ceil(text.trim().length * BUTTON_CHAR_PX + BUTTON_PADDING_PX);
  const px = Math.round(width * CANVAS_COLUMN_PX);
  if (px >= neededPx) return [];
  return [
    `Button "${spec.name ?? spec.id ?? 'Button'}": the label "${text.trim()}" needs about ${neededPx}px but the button is ${width} columns, ` +
      `about ${px}px, so the label wraps or is cut. Use at least ${Math.ceil(neededPx / CANVAS_COLUMN_PX)} columns.`,
  ];
}

/** Repeated Listview children use a fresh 43-column canvas inside every item. Also catch Html
 * roots whose copied pixel height exceeds the wrapper's actual inner height. */
export function lintListviewChildren(components: LintComponent[]): string[] {
  const warnings: string[] = [];
  const refs = new Map(
    components.flatMap((component) => {
      const key = componentKey(component);
      return key ? [[key, component] as const] : [];
    })
  );
  const childrenByParent = new Map<string, LintComponent[]>();
  for (const child of components) {
    const parentId = parentPlacement(child)?.parentId;
    if (!parentId || refs.get(parentId)?.type !== 'Listview') continue;
    childrenByParent.set(parentId, [...(childrenByParent.get(parentId) ?? []), child]);
  }

  for (const [parentId, children] of childrenByParent) {
    const parent = refs.get(parentId)!;
    if (propVal(parent.properties, 'mode') !== 'grid') continue;
    for (const child of children) {
      const rect = child.layouts?.desktop ?? child.layout;
      if (!rect || rect.top === undefined || rect.height === undefined) continue;
      const sharesRow = children.some((sibling) => {
        if (sibling === child) return false;
        const siblingRect = sibling.layouts?.desktop ?? sibling.layout;
        if (!siblingRect || siblingRect.top === undefined || siblingRect.height === undefined) return false;
        return rect.top! < siblingRect.top + siblingRect.height && siblingRect.top < rect.top! + rect.height!;
      });
      if (sharesRow || (rect.left === 0 && rect.width === 43)) continue;
      warnings.push(
        `Component "${child.name ?? child.id ?? child.type}" is the only child on its row inside grid-mode ` +
          `Listview "${parent.name ?? parent.id ?? 'Listview'}", but uses left:${rect.left ?? 'unset'}, ` +
          `width:${rect.width ?? 'unset'}. Each repeated grid cell has its own fresh 43-column local canvas; ` +
          'for a full-row child use left:0, width:43. Do not divide the child width by the parent grid column count.'
      );
    }
  }

  for (const child of components.filter((component) => component.type === 'Html')) {
    const parent = refs.get(parentPlacement(child)?.parentId ?? '');
    if (parent?.type !== 'Listview') continue;
    const rawHtml = propVal(child.properties, 'rawHtml');
    if (typeof rawHtml !== 'string' || !/\bheight\s*:\s*\d+(?:\.\d+)?px\b/i.test(rawHtml)) continue;
    if (/\bheight\s*:\s*100%\b/i.test(rawHtml)) continue;
    warnings.push(
      `Html "${child.name ?? child.id ?? 'Html'}" is repeated inside Listview ` +
        `"${parent.name ?? parent.id ?? 'Listview'}" and uses a fixed pixel CSS height. The Listview wrapper's ` +
        'inner canvas can be shorter than the authored component, creating a scrollbar in every item. ' +
        'Use height:100%; box-sizing:border-box on the Html root instead.'
    );
  }
  return warnings;
}

/** Warn only for the high-confidence operational failure: a top-level primary action placed below
 * a substantial, independently scrolling Table/Listview and below the common desktop fold. Long
 * forms/detail pages without a bounded data pane remain valid and intentionally scrollable. */
export function lintOperationalViewport(components: LintComponent[]): string[] {
  const refs = new Map(
    components.flatMap((component) => {
      const key = componentKey(component);
      return key ? [[key, component] as const] : [];
    })
  );
  const absoluteTop = (component: LintComponent, seen = new Set<string>()): number => {
    const rect = component.layouts?.desktop ?? component.layout;
    const localTop = rect?.top ?? 0;
    const placement = parentPlacement(component);
    if (!placement || seen.has(placement.parentId)) return localTop;
    const parent = refs.get(placement.parentId);
    if (!parent) return localTop;
    return localTop + absoluteTop(parent, new Set([...seen, placement.parentId]));
  };
  const hasBoundedAncestor = (component: LintComponent): boolean => {
    let placement = parentPlacement(component);
    const seen = new Set<string>();
    while (placement && !seen.has(placement.parentId)) {
      seen.add(placement.parentId);
      const parent = refs.get(placement.parentId);
      if (!parent) return false;
      if (BOUNDED_OPERATIONAL_SURFACE_TYPES.has(parent.type ?? '')) return true;
      placement = parentPlacement(parent);
    }
    return false;
  };
  const surfaces = components.flatMap((component) => {
    if (!BOUNDED_OPERATIONAL_SURFACE_TYPES.has(component.type ?? '')) return [];
    const rect = component.layouts?.desktop ?? component.layout;
    if (!rect || (rect.height ?? 0) < MIN_BOUNDED_OPERATIONAL_SURFACE_HEIGHT_PX) return [];
    return [{ component, bottom: absoluteTop(component) + (rect.height ?? 0) }];
  });
  if (!surfaces.length) return [];

  const warnings: string[] = [];
  for (const button of components.filter((component) => component.type === 'Button' && !hasBoundedAncestor(component))) {
    if (propVal(button.styles, 'type') !== 'primary') continue;
    const rect = button.layouts?.desktop ?? button.layout;
    if (!rect) continue;
    const buttonTop = absoluteTop(button);
    const buttonBottom = buttonTop + (rect.height ?? 0);
    if (buttonBottom <= DEFAULT_DESKTOP_CONTENT_FOLD_PX) continue;
    const precedingSurface = surfaces.find(({ bottom }) => buttonTop >= bottom);
    const surface = precedingSurface ?? surfaces[0]!;
    const relation = precedingSurface ? 'below' : 'on a page with';
    warnings.push(
      `Primary Button "${button.name ?? button.id ?? 'Button'}" ends at ${buttonBottom}px ${relation} a bounded ` +
        `${surface.component.type} "${surface.component.name ?? surface.component.id ?? surface.component.type}" ` +
        `and is likely outside the initial desktop viewport. This creates page scrolling on top of the data pane's ` +
        `inner scrolling. Move the primary action above about ${DEFAULT_DESKTOP_CONTENT_FOLD_PX}px, shorten the pane/header, ` +
        'or browser-verify that the extra page scroll is deliberate.'
    );
  }
  return warnings;
}

/** Catch an accidentally half-width desktop composition while allowing deliberate narrow forms/details. */
/** The complement of lintDesktopCanvasCoverage: content that runs to the canvas EDGES.
 *
 * references/ui-layout.md already asks for a side gutter ("top-level content ≈ columns 2-41,
 * full-bleed only if asked"), but nothing enforced it and models systematically ignored it —
 * observed shipping tables at left:0 width:43 (zero gutter) and, more often, left:1 width:41, which
 * is ~2% of the canvas and reads as flush against the window. Guidance alone has not been enough.
 *
 * Reported per page rather than per component so a wide layout produces one actionable line instead
 * of one per widget, and it names the exact target columns so the fix needs no guesswork. */
export function lintCanvasSideGutter(components: LintComponent[]): string[] {
  const MIN_LEFT = 2;
  const MAX_RIGHT = 41;
  // Modals/drawers carry a trigger-ish desktop rect that is not page content, so a right-edge value
  // there is not a gutter problem.
  const EXEMPT = new Set(['Modal', 'ModalV2', 'Drawer']);
  const roots = components.filter(
    (component) => !parentPlacement(component) && !EXEMPT.has(component.type ?? '')
  );
  // Only judge a PAGE's composition, never a single insertion: add_component lints the one component
  // it is adding, and a page-level "no side gutter" verdict from that has no context behind it.
  // Mirrors lintDesktopCanvasCoverage, which guards the same way.
  if (roots.length < 3) return [];
  const offenders = roots.filter((component) => {
    const rect = component.layouts?.desktop ?? component.layout;
    if (!rect || typeof rect.left !== 'number' || typeof rect.width !== 'number') return false;
    return rect.left < MIN_LEFT || rect.left + rect.width > MAX_RIGHT;
  });
  if (!offenders.length) return [];
  const names = offenders.map((component) => component.name ?? component.id).filter(Boolean);
  return [
    `Page content has no side gutter: ${names.slice(0, 4).join(', ')}` +
      (names.length > 4 ? ` and ${names.length - 4} more` : '') +
      ` reach the edges of ToolJet's 43-column canvas, so the app renders flush against the window. ` +
      `Keep top-level content within columns ${MIN_LEFT}-${MAX_RIGHT} (left >= ${MIN_LEFT}, ` +
      `left + width <= ${MAX_RIGHT}); a full-width row is left:${MIN_LEFT} width:${MAX_RIGHT - MIN_LEFT}. ` +
      'Only go edge-to-edge if the user explicitly asked for a full-bleed layout.',
  ];
}

export function lintDesktopCanvasCoverage(components: LintComponent[]): string[] {
  const roots = components.filter((component) => !parentPlacement(component));
  if (roots.length < 4) return [];
  if (!roots.some((component) => ['Table', 'Chart', 'Listview', 'Kanban'].includes(component.type ?? ''))) return [];
  const rects = roots
    .map((component) => component.layouts?.desktop ?? component.layout)
    .filter((rect): rect is Rect => Boolean(rect && typeof rect.left === 'number' && typeof rect.width === 'number'));
  if (rects.length < 4) return [];
  const left = Math.min(...rects.map((rect) => rect.left!));
  const right = Math.max(...rects.map((rect) => rect.left! + rect.width!));
  if (right - left > 27 || right > 29) return [];
  return [
    `Desktop page content spans only columns ${left}-${right} of ToolJet's 43-column canvas despite having ` +
      'multiple operational/analytical surfaces. This often produces an accidental half-width app. Expand the ' +
      'main composition toward the standard columns 2-41, or browser-verify that the narrow rail is deliberate.',
  ];
}

/** Lint a single component spec (pre-write). */
/** Text-bearing property keys whose value the customer reads on screen. */
const RENDERED_TEXT_KEYS = ['text', 'rawHtml', 'label', 'title', 'placeholder', 'description', 'subtitle', 'primaryValue', 'secondaryValue'];

/** Defaults a container ships with when its items were never authored; a customer sees them verbatim. */
const CONTAINER_ITEMS: Record<string, string> = { Tabs: 'tabs', Steps: 'steps', Timeline: 'data' };

/**
 * What a customer would read as a bug in rendered text, caught before the write. Three shapes seen in the
 * 2026-09-12 Luna campaign (224 pages reviewed): a literal backslash-n in a Text value ("TOTAL PRODUCTS\n8"
 * on four KPI tiles), an expression written outside its braces so the source prints verbatim
 * ("'+moment().format('DD MMM YYYY')+'" in a header), and a Tabs component left with its default
 * "Tab 1 / Tab 2 / Tab 3" items next to hand-built content.
 */
export function lintRenderedText(spec: LintComponent): string[] {
  const errors: string[] = [];
  const label = spec.name ?? spec.type ?? 'component';
  const props = spec.properties ?? {};
  for (const key of RENDERED_TEXT_KEYS) {
    const value = propVal(props, key);
    if (typeof value !== 'string' || !value) continue;
    if (value.includes('\\n')) {
      errors.push(
        `Component "${label}".properties.${key} contains a literal backslash-n; ToolJet prints it as the two characters "\\n". ` +
          'Use a real line break, <br> in Html, or separate components.'
      );
    }
    const outside = expressionOutsideBinding(value);
    if (outside) {
      errors.push(
        `Component "${label}".properties.${key} has JavaScript outside a {{ }} binding (${outside}); it renders as source text. ` +
          'Wrap the whole expression in one {{ }} or move it into a query.'
      );
    }
  }
  // Tabs has two item surfaces: static tabItems (the default "Tab 1 / Tab 2 / Tab 3") and dynamic tabs, read
  // only when useDynamicOptions is true. Authoring tabs alone leaves the defaults on screen: three Chainventory
  // pages on 2026-09-12 shipped "Tab 1 / Tab 2 / Tab 3" beside fully authored tabs.
  if (spec.type === 'Tabs') {
    const dynamic = isTrueBinding(propVal(props, 'useDynamicOptions'));
    const tabs = propVal(props, 'tabs');
    const tabItems = propVal(props, 'tabItems');
    const authoredItems = Array.isArray(tabItems) && tabItems.length > 0 &&
      !tabItems.every((item) => /^Tab \d+$/.test(String((item as Record<string, unknown>)?.title ?? '')));
    if (dynamic && (tabs === undefined || tabs === null || tabs === '')) {
      errors.push(`Tabs "${label}": useDynamicOptions is on but properties.tabs is empty, so nothing renders. Bind tabs to an array of {id, title}.`);
    } else if (!dynamic && !authoredItems) {
      errors.push(
        `Tabs "${label}": ToolJet renders properties.tabItems (default "Tab 1 / Tab 2 / Tab 3") unless useDynamicOptions is true; ` +
          (tabs !== undefined ? 'the authored properties.tabs is ignored. ' : '') +
          'Either set properties.useDynamicOptions to "{{true}}" and keep tabs as [{id, title}], or author properties.tabItems with the real titles.'
      );
    }
  }
  const itemsKey = spec.type === 'Tabs' ? undefined : CONTAINER_ITEMS[spec.type ?? ''];
  if (itemsKey) {
    const items = propVal(props, itemsKey);
    const authored = Array.isArray(items) ? items.length > 0 : typeof items === 'string' && items.includes('{{');
    if (!authored) {
      errors.push(
        `${spec.type} "${label}" has no properties.${itemsKey}: it renders ToolJet's placeholder items ("Tab 1 / Tab 2 / Tab 3"). ` +
          `Author ${itemsKey} with the real titles, or use a different component.`
      );
    }
  }
  return errors;
}

/** A snippet of code-looking text that sits outside every {{ }} span, or null. */
export function expressionOutsideBinding(value: string): string | null {
  const outside = value.replace(/\{\{[\s\S]*?\}\}/g, ' ');
  const match = outside.match(/'\s*\+\s*(?:moment|queries|components|globals|variables|page|new Date)\b[^\n]{0,40}|\b(?:moment|queries|components)\.[A-Za-z_]+\([^\n]{0,30}|\+\s*'[^']{0,30}'\s*\+/);
  return match ? JSON.stringify(match[0].trim().slice(0, 60)) : null;
}

const WRAP_REQUIRED_COLUMNS = 5;

/** Rough rendered height of a Text value: one entry per line (<br>, block tags, newlines), each the largest
 *  inline font-size on that line at 1.5 line height (minimum 18px), plus the widget's padding. */
export function estimateTextHeight(text: string, baseSize: number): { lines: number; px: number; sizes: number[] } {
  // Blank lines from a doubled <br> still take space (about half a line each).
  const blankLines = (text.match(/<br\s*\/?>\s*<br\s*\/?>/gi) ?? []).length;
  const rawParts = text.split(/<br\s*\/?>|<\/(?:div|p|h[1-6]|li)>|\n/i);
  const parts = rawParts
    .map((part) => part.replace(/<[^>]+>/g, '').trim() === '' ? null : part)
    .filter((part): part is string => part !== null);
  // Heading and paragraph tags carry the browser's own font size and margins: measured on a
  // 2026-09-12 round, an h1 + p + small header at 90px needed 98, and its dashboard variant 119.
  const sizes = parts.map((part) => {
    const found = [...part.matchAll(/font-size\s*:\s*(\d+(?:\.\d+)?)px/gi)].map((m) => Number(m[1]));
    if (found.length) return Math.max(...found);
    if (/<h1\b/i.test(part)) return baseSize * 2;
    if (/<h2\b/i.test(part)) return baseSize * 1.5;
    if (/<h3\b/i.test(part)) return baseSize * 1.17;
    return baseSize;
  });
  const blockBoundaries = parts.filter((part) => /<(?:h[1-6]|p|div|li)\b/i.test(part)).length;
  const px = Math.round(sizes.reduce((sum, size) => sum + Math.max(18, size * 1.5), 0) + blankLines * 10 + blockBoundaries * 8 + 6);
  return { lines: parts.length + blankLines, px, sizes };
}

// The Chart wrapper (Chart.jsx) spreads layout first, then overrides paper/plot backgrounds from the component's
// backgroundColor and the margin from styles.padding on all four sides; layout.margin and the bgcolors are ignored.
const CHART_HOUSE_LAYOUT_KEYS = ['font', 'family'];
const CHART_PADDING_MAX_PX = 24;

/**
 * Return render/data failures; send presentation heuristics to warnings. JSON mode gives finer theme
 * control, but native rendering, inherited fonts and deliberate margins are valid design choices.
 * A style warning must not short-circuit the subsequent data/label safety checks.
 */
export function lintChartHouseStyle(spec: LintComponent, warnings: string[] = []): string[] {
  if (spec.type !== 'Chart') return [];
  const label = spec.name ?? spec.type;
  const props = spec.properties ?? {};
  const fromJson = propVal(props, 'plotFromJson');
  if (!isTrueBinding(fromJson)) {
    const kind = String(propVal(props, 'type') ?? 'bar');
    warnings.push(
      `Chart "${label}": native type "${kind}" renders Plotly's defaults (Verdana labels, grey grid, flat unlabeled bars, ` +
        'the rainbow pie). Set properties.plotFromJson to "{{true}}" and write properties.jsonDescription as the house ' +
        'chart from references/ui-layout.md for finer control, or retain native rendering when its themed presentation is verified.',
    );
    return [];
  }
  const raw = propVal(props, 'jsonDescription');
  const description = typeof raw === 'string' ? raw : raw && typeof raw === 'object' ? JSON.stringify(raw) : '';
  if (!description.trim()) {
    return [`Chart "${label}": plotFromJson is on but properties.jsonDescription is empty, so nothing renders.`];
  }
  // styles.padding is the Plotly margin on all four sides. The catalog default 50 spends 100 of a 290px chart on
  // margins, and the string "default" hands Plotly its own 80/100 margins: two round-ten charts drew in 114px
  // of a 300px tile. Axis tick labels get their room from automargin, so a small padding is safe.
  const padding = propVal(spec.styles ?? {}, 'padding');
  const paddingPx = typeof padding === 'number' ? padding : typeof padding === 'string' && /^\s*\d+\s*$/.test(padding) ? Number(padding) : undefined;
  if (paddingPx === undefined || paddingPx > CHART_PADDING_MAX_PX) {
    warnings.push(
      `Chart "${label}": styles.padding ${padding === undefined ? 'is unset (catalog default 50)' : `is ${JSON.stringify(padding)}`}; the wrapper uses it as the Plotly margin ` +
        `on all four sides and ignores layout.margin, which can shrink the plot. Start with styles.padding 16 (usually at most ${CHART_PADDING_MAX_PX}); ` +
        'the axes add their own room for tick labels. Keep a larger margin only when labels need it and verify the rendered plot.',
    );
  }
  // A description that is only a binding to a query builds its layout elsewhere; the dynamic-mode warning covers it.
  if (!description.includes('layout') && /^\s*\{\{[\s\S]*\}\}\s*$/.test(description) && !description.includes('data')) return [];
  if (!description.includes('layout') && /^\s*\{\{\s*[\w.]+\s*\}\}\s*$/.test(description)) return [];
  // `data:` set to a mapped list of points ({x, y} per row) instead of a list of traces draws empty axes:
  // three charts on a 2026-09-12 MedCard build. Plotly wants data: [{ type, x: [...], y: [...] }].
  if (/\bdata\s*:\s*\(?\s*queries\.[\w.$]+\.data\b[^,;]*?\)?\s*\.map\(/.test(description)) {
    return [
      `Chart "${label}": jsonDescription sets data to rows.map(r => ({x, y})), a list of points, so Plotly draws empty axes. ` +
        "data is a list of traces: [{ type: 'bar', x: rows.map(r => r.label), y: rows.map(r => r.value), ... }].",
    ];
  }
  // Plotly clips bar text to the plot area unless the trace sets cliponaxis:false, so the tallest bar's
  // outside label is cut in half (measured 2026-09-12: a bigger top margin does not help, cliponaxis does).
  if (/textposition\s*:\s*['"]outside['"]/.test(description) && !/cliponaxis\s*:\s*false/.test(description)) {
    return [
      `Chart "${label}": a bar trace uses textposition 'outside' without cliponaxis:false, so the tallest bar's value label is ` +
        'cut in half by the plot area. Add cliponaxis:false to every bar trace that places its text outside.',
    ];
  }
  const missing = CHART_HOUSE_LAYOUT_KEYS.filter((key) => !description.includes(key));
  if (missing.length) {
    warnings.push(
      `Chart "${label}": jsonDescription has no layout.${missing.join(', layout.')}; without the house layout the chart ` +
        'falls back to Plotly defaults. Prefer explicit theme typography; retain inherited defaults only after verifying the result.',
    );
  }
  // A static description is parseable: every trace must carry its data. A bar with a colour and no x/y
  // drew empty axes on a round-seven build (2026-09-12).
  if (!description.includes('{{')) {
    try {
      const parsed = JSON.parse(description) as { data?: Array<Record<string, unknown>> };
      const traces = Array.isArray(parsed.data) ? parsed.data : [];
      const dataless = traces.filter((trace) => {
        const type = String(trace.type ?? 'scatter');
        if (type === 'pie') return !Array.isArray(trace.values) || trace.values.length === 0;
        if (type === 'heatmap') return !Array.isArray(trace.z) || trace.z.length === 0;
        return !Array.isArray(trace.y) || trace.y.length === 0;
      });
      if (dataless.length) {
        return [
          `Chart "${label}": ${dataless.length} of ${traces.length} trace(s) carry no data (no x/y, values or z arrays), so the chart draws empty axes. ` +
            'Put the arrays in the trace, or build the whole { data, layout } object in a JavaScript query and bind jsonDescription to it.',
        ];
      }
    } catch {
      /* the JSON validity error is reported by lintChartDataShape */
    }
  }
  return [];
}

export function lintComponentSpec(spec: LintComponent): LintResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const props = spec.properties ?? {};
  const label = spec.name ?? spec.type ?? 'component';

  // An omitted Text payload uses the catalog greeting, not an empty display.
  // Keep this advisory: staged authoring and deliberately retained sample copy are valid.
  if (spec.type === 'Text' && propVal(props, 'text') === undefined) {
    warnings.push(
      `Text "${label}" has no properties.text and will render ToolJet's default greeting. ` +
      'Supply the intended text or binding; use an explicit empty string if this display is intentionally blank. ' +
      'Do not invent replacement copy or change its layout.'
    );
  }

  if (spec.type === 'Table') {
    const columns = propVal(props, 'columns');
    if (Array.isArray(columns)) {
      const hasClockFormat = (c: Record<string, unknown>) => typeof c.dateFormat === 'string' &&
        !c.dateFormat.includes('{{') && /[Hhms]/.test(c.dateFormat.replace(/\[[^\]]*\]/g, ''));
      const timed = columns.filter((c) => c && typeof c === 'object' &&
        c.columnType === 'datepicker' && (isTrueBinding(c.isTimeChecked) || hasClockFormat(c)) &&
        c.columnVisibility !== false && c.columnVisibility !== '{{false}}');
      const local = timed.filter(c => !c.timeZoneDisplay);
      if (local.length) warnings.push(
        `Table "${label}" time columns ${local.map(c => JSON.stringify(c.key ?? c.name)).join(', ')} have no timeZoneDisplay, so times follow the viewer's browser timezone. ` +
        'For a location-bound schedule, set the business IANA timeZoneDisplay and appropriate source timeZoneValue; keep viewer-local time only when intended and labelled. Do not infer a timezone from locale or currency.'
      );
      const doubled = timed.filter(c => isTrueBinding(c.isTimeChecked) && hasClockFormat(c));
      if (doubled.length) warnings.push(
        `Table "${label}" time columns ${doubled.map(c => JSON.stringify(c.key ?? c.name)).join(', ')} include time tokens in dateFormat while isTimeChecked is on. ` +
        'The renderer appends time itself; use a date-only dateFormat and isTwentyFourHrFormatEnabled for 24-hour time to avoid displaying the time twice.'
      );
    }
  }

  // Outline ignores backgroundColor; surface-colored primary-button text is not remapped
  // by Button.jsx. Warn, rather than rewrite: a deliberately dark parent can be valid.
  if (spec.type === 'Button' && propVal(spec.styles ?? {}, 'type') === 'outline') {
    const textColor = propVal(spec.styles ?? {}, 'textColor') ??
      getComponentSchema('Button')?.styles.find((style) => style.key === 'textColor')?.default;
    if (textColor === 'var(--cc-surface1-surface)') {
      warnings.push(
        `Button "${label}": outline background is transparent even when backgroundColor is set. ` +
          'Surface-colored text can disappear against the page or card. Set textColor to a contrasting ' +
          'token such as var(--cc-primary-text), and check iconColor/loaderColor against the actual parent; ' +
          'retain surface-colored text only when the parent provides sufficient contrast.'
      );
    }
  }

  // NumberInput's persisted defaults contain these legacy property keys, but its current
  // renderer reads bounds only from validation. Empty defaults must remain repair-compatible.
  if (spec.type === 'NumberInput') {
    for (const key of ['minValue', 'maxValue']) {
      const value = propVal(props, key);
      if (value == null || (typeof value === 'string' && value.trim() === '')) continue;
      errors.push(
        `NumberInput "${label}": properties.${key} is ignored by the renderer. ` +
          `Move the limit to top-level validation.${key}: {value: ...} and clear the legacy property. ` +
          'Gate standalone submit actions on field validity and the intended numeric range; truthiness accepts negative values.'
      );
    }
  }

  errors.push(...lintBindingSyntax(props, `Component "${label}".properties`));
  errors.push(...lintBindingSyntax(spec.styles, `Component "${label}".styles`));
  errors.push(...lintRenderedText(spec));
  errors.push(...lintChartHouseStyle(spec, warnings));

  // A Text widget holding several lines (eyebrow <br> title, or block tags) in a box sized for one line
  // clips its last line: MedCard's "Sales control centre" header on 2026-09-12 was 12px + 22px lines in 50px.
  if (spec.type === 'Text') {
    const text = propVal(props, 'text');
    const height = (spec.layouts?.desktop ?? spec.layout)?.height;
    if (typeof text === 'string' && typeof height === 'number') {
      const needed = estimateTextHeight(text, optionalStaticNumber(propVal(spec.styles, 'textSize')) ?? 14);
      if (needed.lines > 1 && needed.px > height + 6) {
        errors.push(
          `Text "${label}": its ${needed.lines} lines (font sizes ${needed.sizes.join('/')}px) need about ${needed.px}px but the widget is ` +
            `${height}px tall, so the last line is cut off. Set height to at least ${Math.ceil(needed.px / 10) * 10}, or split the lines into separate Text widgets.`
        );
      }
    }
  }

  // A ModalV2 keeps its catalog default useDefaultButton:true, so a "Launch Modal" trigger button renders at the
  // modal's own coordinates: on 2026-09-12 that was the stray dark block at the bottom of two Chainventory pages.
  if (spec.type === 'ModalV2' && !isFalseBinding(propVal(props, 'useDefaultButton'))) {
    const top = (spec.layouts?.desktop ?? spec.layout)?.top;
    errors.push(
      `ModalV2 "${label}": properties.useDefaultButton is on (the catalog default), so ToolJet renders a "Launch Modal" trigger ` +
        `button at the modal's own coordinates${typeof top === 'number' ? ` (top ${top})` : ''} as a stray block on the page. ` +
        'Set properties.useDefaultButton to false and open the modal from your own Button with a show-modal event.'
    );
  }

  // A labelled filter dropdown left on the catalog placeholder renders "Select": reviewers read it as an unfinished control.
  if ((spec.type === 'DropdownV2' || spec.type === 'MultiselectV2') && !differsFromCatalogDefault(spec.type, 'placeholder', propVal(props, 'placeholder'))) {
    const labelText = propVal(props, 'label');
    if (typeof labelText === 'string' && labelText.trim()) {
      warnings.push(
        `${spec.type} "${label}": placeholder is the catalog default, so the control reads "Select" until a value is chosen. ` +
          `Set properties.placeholder to the neutral choice for "${labelText.trim()}" (for example "All ${labelText.trim().toLowerCase()}") or give it a default value.`
      );
    }
  }
  // These boolean controls are not text templates. A malformed expression plus stray prose can
  // silently become a truthy string and disable/hide an otherwise working primary action.
  for (const key of ['disabledState', 'loadingState', 'visibility', 'collapseWhenHidden']) {
    const path = `Component "${label}".properties.${key}`;
    for (const error of lintBindingSyntax(props[key], path, true)) {
      if (!errors.includes(error)) errors.push(error);
    }
  }
  // Dropdown schemas are arrays, not interpolated prose. In particular, do not skip malformed
  // nested {{ }} expressions as the generic mixed-text binding check deliberately does.
  if (['DropdownV2', 'MultiselectV2'].includes(spec.type ?? '') && isTruthyBinding(propVal(props, 'advanced'))) {
    for (const error of lintBindingSyntax(props.schema, `Component "${label}".properties.schema`, true)) {
      if (!errors.includes(error)) errors.push(error);
    }
  }

  if (spec.slotName !== undefined) {
    if (!(COMPONENT_SLOT_NAMES as readonly string[]).includes(spec.slotName)) {
      errors.push(`Component "${label}": unsupported slot_name "${String(spec.slotName)}"; use header, body, footer, or Kanban modal.`);
    }
    if (!spec.parentRef && !spec.parent) {
      errors.push(`Component "${label}": slot_name requires parent_ref or parent.`);
    }
  }

  // ERROR: style keys under `properties` are silently dropped by ToolJet.
  const misplaced = Object.keys(props).filter((k) => STYLE_KEYS_IN_PROPERTIES.has(k));
  if (misplaced.length) {
    errors.push(
      `Component "${label}": style keys ${JSON.stringify(misplaced)} are under \`properties\`, where ToolJet ` +
        `ignores them — move them to the top-level \`styles\` object.`
    );
  }

  // Layout sanity.
  const rects = [spec.layout, spec.layouts?.desktop, spec.layouts?.mobile].filter(Boolean) as Rect[];
  for (const r of rects) {
    if ((r.width ?? 0) <= 0 || (r.height ?? 0) <= 0) {
      errors.push(`Component "${label}": layout has non-positive size (${r.width}×${r.height}) — it may be invisible.`);
    }
  }

  const componentSchema = spec.type ? getComponentSchema(spec.type) : null;
  if (!spec.type) {
    errors.push(`Component "${label}": type is required.`);
  } else if (!componentSchema) {
    const suggestion = nearestCatalogKey(spec.type, getCatalog().map((entry) => entry.type));
    errors.push(
      `Component "${label}": unknown component type "${spec.type}"; ToolJet may persist an unusable component.` +
        (suggestion ? ` Did you mean "${suggestion}"?` : ' Call get_component_catalog with no type to list supported types.')
    );
  } else {
    const replacement = getLegacyComponentReplacement(spec.type);
    if (replacement) {
      warnings.push(
        `Component "${label}": "${spec.type}" is legacy. Keep it only when repairing an existing app; ` +
          `use "${replacement}" for new components.`
      );
    }
  }
  for (const [sectionName, authored, entries] of [
    ['property', spec.properties, componentSchema?.properties],
    ['style', spec.styles, componentSchema?.styles],
  ] as const) {
    if (!authored || !entries) continue;
    const knownKeys = entries.map((entry) => entry.key);
    for (const key of Object.keys(authored)) {
      if (knownKeys.includes(key)) continue;
      if (sectionName === 'property' && STYLE_KEYS_IN_PROPERTIES.has(key)) continue;
      const aliasTarget = PROPERTY_KEY_ALIASES[key.toLowerCase()];
      const alias =
        aliasTarget && (knownKeys.includes(aliasTarget) || STYLE_KEYS_IN_PROPERTIES.has(aliasTarget))
          ? aliasTarget
          : undefined;
      const suggestion = alias ?? nearestCatalogKey(key, knownKeys);
      if (suggestion) {
        // A known alias or a close typo is almost certainly a mistake that ToolJet silently drops. Make it
        // a hard error with the exact fix, so it's corrected in one turn instead of being ignored into a
        // false "verification_ok" (the submitted property never actually applied).
        errors.push(
          `Component "${label}": "${key}" is not a valid ${sectionName} key for ${spec.type} and is ` +
            `silently ignored — use "${suggestion}" instead.`
        );
      } else {
        warnings.push(
          `Component "${label}": unknown ${sectionName} key "${key}" for ${spec.type}; ToolJet may silently ` +
            'ignore it. Check get_component_catalog before authoring this key.'
        );
      }
    }
    for (const entry of entries) {
      if (!entry.allowedValues?.length) continue;
      const value = propVal(authored, entry.key);
      if (value === undefined || isDynamicBinding(value)) continue;
      if (!entry.allowedValues.some((allowed) => Object.is(allowed, value))) {
        errors.push(
          `Component "${label}": unsupported ${sectionName} value ${JSON.stringify(value)} for "${entry.key}"; ` +
            `allowed values are ${entry.allowedValues.map((allowed) => JSON.stringify(allowed)).join(', ')}. ` +
            'ToolJet silently ignores unsupported enum values.'
        );
      }
    }
  }

  // Chart: the native title defaults to a non-empty string that clips at common dashboard sizes.
  if (spec.type === 'Chart') {
    const title = propVal(props, 'title');
    if (title === undefined) {
      warnings.push(
        `Chart "${label}": native title defaults to a non-empty string that clips at common sizes — set ` +
          `properties.title.value = "" and put a separate Text heading above the chart.`
      );
    } else if (typeof title === 'string' && title.trim() !== '') {
      warnings.push(
        `Chart "${label}": native title "${title}" can clip at dashboard sizes — prefer properties.title.value = "" ` +
          `+ a separate Text heading (enable a native title only after visual verification).`
      );
    }

    const plotFromJson = propVal(props, 'plotFromJson');
    const jsonDescription = propVal(props, 'jsonDescription');
    if (isTruthyBinding(plotFromJson)) {
      if (jsonDescription === undefined) {
        errors.push(
          `Chart "${label}": plotFromJson is enabled without an explicit jsonDescription, so ToolJet falls back to demo data. ` +
            'Provide a static Plotly object/string, or prefer the proven simple type + data mode.'
        );
      } else if (isDynamicBinding(jsonDescription)) {
        warnings.push(
          `Chart "${label}": dynamic plotFromJson/jsonDescription cannot be evaluated statically. This is a verification gap, ` +
            'not evidence of a broken chart. Preserve the authored chart configuration; browser-verify that the evaluated chart ' +
            'has at least one trace. Without runtime evidence, report the gap rather than switching chart modes just to clear this warning.'
        );
      } else {
        let parsed: unknown = jsonDescription;
        if (typeof jsonDescription === 'string') {
          try {
            parsed = JSON.parse(jsonDescription);
          } catch {
            errors.push(
              `Chart "${label}": plotFromJson requires jsonDescription to be valid JSON with a non-empty data array; ` +
                'ToolJet silently renders an empty chart for invalid JSON.'
            );
            parsed = undefined;
          }
        }
        if (parsed !== undefined) {
          const description = recordValue(parsed);
          if (!description || !Array.isArray(description.data) || description.data.length === 0) {
            errors.push(
              `Chart "${label}": plotFromJson jsonDescription must contain a non-empty data array. ` +
                'Use simple type + data mode when an advanced Plotly object is not required.'
            );
          }
        }
      }
    }
  }

  if (spec.type === 'Html' && nestedMapInValue(propVal(props, 'rawHtml'))) {
    warnings.push(
      `Html "${label}": rawHtml contains .map() inside another .map(); ToolJet's Html expression evaluator ` +
        'can throw and render the component completely blank before an || fallback runs. Flatten to one filter().map() ' +
        'chain, or pre-shape the nested data in a datasource/RunJS query and bind the simple result. Do not generalize ' +
        'this warning to Table data bindings, where lookup joins such as filter(...)[0] inside map() are supported.'
    );
  }

  if (unsafeEmptyArrayFirstRowFallback(spec.properties) || unsafeEmptyArrayFirstRowFallback(spec.styles)) {
    warnings.push(
      `Component "${label}": a binding uses (data || [{}])[0].field as a first-row fallback, but an empty array ` +
        'is truthy, so zero rows still produce undefined.field and can blank the component. Use ' +
        '(data || [])[0]?.field or data?.[0]?.field instead.'
    );
  }

  // Statistics renders secondaryValue in a deliberately narrow delta slot. Prose placed there
  // wraps letter-by-letter even when the tile itself is reasonably wide; keep prose in the label.
  if (spec.type === 'Statistics') {
    const secondaryValue = propVal(props, 'secondaryValue');
    if (
      typeof secondaryValue === 'string' &&
      !secondaryValue.includes('{{') &&
      /[A-Za-z]/.test(secondaryValue)
    ) {
      warnings.push(
        `Statistics "${label}": secondaryValue "${secondaryValue}" is prose, but ToolJet renders it in a narrow delta slot ` +
          'that can wrap letter-by-letter. Put prose in secondaryValueLabel and leave secondaryValue empty; reserve the value for a number or percentage.'
      );
    }
    const width = (spec.layouts?.desktop ?? spec.layout)?.width;
    const secondaryHidden = isTruthyBinding(propVal(props, 'hideSecondary'));
    const minimumWidth = secondaryHidden
      ? STATISTICS_VALUE_ONLY_MIN_WIDTH_COLS
      : STATISTICS_WITH_SECONDARY_MIN_WIDTH_COLS;
    if (typeof width === 'number' && width < minimumWidth) {
      warnings.push(
        `Statistics "${label}": desktop width ${width} columns is too narrow; ` +
          `${secondaryHidden ? 'a value-only tile' : 'a tile with visible secondary content'} needs at least ${minimumWidth} columns ` +
          `to keep labels and values readable. ${secondaryHidden ? 'Use no more than three tiles per content row.' : 'Use a two-column KPI grid, or set hideSecondary:true and use at least 12 columns.'}`
      );
    }
    // Value clipping (blocking): a value-only tile with an icon and the default large value font clips
    // multi-digit/currency values in a narrow card (the value renders as e.g. "$3"). Any one of the
    // three fixes below resolves it, so make it an error rather than another ignored warning.
    const iconName = catalogValue('Statistics', props, 'icon');
    const iconVisible =
      typeof iconName === 'string' && iconName.trim() !== '' &&
      propVal(props, 'iconVisibility') !== false && propVal(props, 'iconVisibility') !== '{{false}}';
    const valueFontPx = optionalStaticNumber(
      catalogValue('Statistics', spec.styles, 'primaryValueSize', 'styles')
    );
    const largeValueFont = valueFontPx === undefined || valueFontPx > STATISTICS_SAFE_VALUE_FONT_PX;
    if (
      secondaryHidden &&
      iconVisible &&
      largeValueFont &&
      typeof width === 'number' &&
      width < STATISTICS_VALUE_ONLY_WITH_ICON_MIN_WIDTH_COLS
    ) {
      errors.push(
        `Statistics "${label}": a value-only tile with an icon at ${width} columns clips its value — the ` +
          `default ~34px value font plus the icon leaves too little room, so a currency/large number renders ` +
          `truncated (e.g. "$3" for $37,781.64). Fix any one: widen to at least ` +
          `${STATISTICS_VALUE_ONLY_WITH_ICON_MIN_WIDTH_COLS} columns, set primaryValueSize to ` +
          `${STATISTICS_SAFE_VALUE_FONT_PX} or less, or remove the icon.`
      );
    }
    const primaryLabel = catalogValue('Statistics', props, 'primaryValueLabel');
    if (
      secondaryHidden &&
      typeof width === 'number' &&
      width >= STATISTICS_VALUE_ONLY_MIN_WIDTH_COLS &&
      width < STATISTICS_WITH_SECONDARY_MIN_WIDTH_COLS &&
      typeof primaryLabel === 'string' &&
      !primaryLabel.includes('{{') &&
      (primaryLabel.trim().length > 12 || primaryLabel.trim().split(/\s+/).length > 2)
    ) {
      warnings.push(
        `Statistics "${label}": value-only width ${width} columns is only safe for a short one- or two-word ` +
          `primaryValueLabel, but "${primaryLabel}" can wrap vertically and hide the value in the viewer. ` +
          'Shorten the label, use at least 18 columns, or browser-verify the exact viewer width.'
      );
    }
  }

  // DropdownV2 has two mutually exclusive option surfaces. ToolJet persists defaults for both, so
  // compare with the exact catalog defaults and warn only when the caller authored a custom value.
  if (spec.type === 'DropdownV2') {
    for (const key of ['value', 'defaultValue']) {
      if (Object.prototype.hasOwnProperty.call(props, key)) {
        errors.push(`DropdownV2 "${label}": properties.${key} is not a supported preselection property. ` +
          'Set visible:true and default:true on the matching option; for an edit form use advanced:true and a schema binding ' +
          'whose option.default compares its value with the raw selected record ID/field. Preserve ID types. ' +
          'Remove this unsupported property after wiring the selection; silently dropping it can clear saved relationships.');
      }
    }
    const advanced = propVal(props, 'advanced');
    const schema = propVal(props, 'schema');
    const options = propVal(props, 'options');
    const customSchema = differsFromCatalogDefault('DropdownV2', 'schema', schema);
    const customOptions = differsFromCatalogDefault('DropdownV2', 'options', options);
    if (isTruthyBinding(advanced)) {
      warnings.push(...dropdownDefaultVisibilityWarning(schema, label));
      if (spec.name) warnings.push(...dropdownSelfDefaultWarning(schema, spec.name));
    }
    else if (advanced === undefined || isFalseBinding(advanced)) warnings.push(...dropdownDefaultVisibilityWarning(options, label));

    if (customOptions && !Array.isArray(options)) {
      errors.push(
        `DropdownV2 "${label}": properties.options is static-array-only, but received ${typeof options === 'string' && isDynamicBinding(options) ? 'a dynamic {{ }} binding' : typeof options}. ` +
          'ToolJet can silently split a binding string into character objects. Use properties.schema with ' +
          'properties.advanced.value="{{true}}" for dynamic options, or pass a literal options array.'
      );
    } else if (Array.isArray(options)) {
      const malformedIndexes = options.flatMap((option, index) => {
        const entry = recordValue(option);
        return entry && 'label' in entry && 'value' in entry ? [] : [index];
      });
      if (malformedIndexes.length) {
        errors.push(
          `DropdownV2 "${label}": properties.options contains malformed entries at indexes ${malformedIndexes.join(', ')}; ` +
            'each static option must be an object with label and value. This can indicate a previously shredded dynamic binding; ' +
            'replace it with properties.schema + advanced="{{true}}".'
        );
      }
    }

    if (customSchema && customOptions) {
      warnings.push(
        `DropdownV2 "${label}": custom \`schema\` and custom \`options\` are both present, but the modes are mutually exclusive. ` +
          `Use schema with properties.advanced.value="{{true}}", or options with advanced="{{false}}".`
      );
    }
    if (customSchema && (advanced === undefined || isFalseBinding(advanced))) {
      warnings.push(
        `DropdownV2 "${label}": custom \`schema\` is silently ignored unless properties.advanced.value="{{true}}"; ` +
          `ToolJet will render the static options instead.`
      );
    }
    if (customOptions && isTruthyBinding(advanced)) {
      warnings.push(
        `DropdownV2 "${label}": custom \`options\` are silently ignored while properties.advanced is true; ` +
          `use \`schema\` for dynamic mode or set advanced="{{false}}".`
      );
    }
  }

  if (spec.type === 'DatePickerV2') {
    const defaultValue = propVal(props, 'defaultValue');
    const dateFormat = catalogValue('DatePickerV2', props, 'dateFormat');
    const literal = typeof defaultValue === 'string'
      ? defaultValue.trim().replace(/^\{\{\s*(['"])([^'"]+)\1\s*\}\}$/, '$2')
      : undefined;
    // Reject the observed year-last misparse, not every spelling that differs from ISO.
    // Moment also accepts numeric year-first formats such as YYYY-M-D and YYYY/MM/DD.
    const yearLastFormat = typeof dateFormat === 'string' &&
      /^(?:D{1,2}[^A-Za-z]+M{1,4}|M{1,4}[^A-Za-z]+D{1,2})[^A-Za-z]+Y{2,4}$/.test(dateFormat);
    if (literal && /^\d{4}-\d{2}-\d{2}$/.test(literal) && yearLastFormat) {
      errors.push(
        `DatePickerV2 "${label}": ISO defaultValue "${literal}" does not match dateFormat "${dateFormat}". ` +
        'ToolJet parses the default with dateFormat, not as ISO automatically. Use dateFormat:"YYYY-MM-DD" ' +
        'or format the default into the selected display format; otherwise the initial day can silently change.'
      );
    }
    if (typeof defaultValue === 'string' && defaultValue.includes('{{') &&
        typeof dateFormat === 'string' && !dateFormat.includes('{{')) {
      const formats = [...defaultValue.matchAll(/\.format\(\s*(['"])([^'"]+)\1\s*\)/g)].map((m) => m[2]);
      if (formats.length === 1 && formats[0] !== dateFormat) {
        warnings.push(
          `DatePickerV2 "${label}": defaultValue formats as "${formats[0]}" but dateFormat is "${dateFormat}". ` +
          'Check the evaluated default: the parser and display share dateFormat. Match them before authoring dependent queries.'
        );
      }
    }
    const demoDefault = getComponentSchema('DatePickerV2')?.properties.find(
      (property) => property.key === 'defaultValue'
    )?.default;
    if (defaultValue === undefined || JSON.stringify(defaultValue) === JSON.stringify(demoDefault)) {
      warnings.push(
        `DatePickerV2 "${label}": the untouched default renders ToolJet's 01/01/2022 demo date. ` +
          'Set properties.defaultValue.value="{{null}}" for an empty/create field, or bind an explicit date for edit/filter state.'
      );
    }
  }

  if (spec.type === 'KeyValuePair') {
    const data = propVal(props, 'data');
    const fields = propVal(props, 'fields');
    if (data !== undefined && Array.isArray(fields) && fields.length > 0) {
      const declaredKeys = new Set(
        fields.flatMap((field) => {
          const key = recordValue(field)?.key;
          return typeof key === 'string' && key.length > 0 ? [key] : [];
        })
      );
      const staticData = recordValue(data);
      const undeclaredKeys = staticData
        ? Object.keys(staticData).filter((key) => !declaredKeys.has(key))
        : [];
      if (undeclaredKeys.length > 0 || (!staticData && !explicitlyProjectsObjectData(data))) {
        warnings.push(
          `KeyValuePair "${label}": explicit fields do not suppress undeclared data keys; ToolJet appends them as visible rows. ` +
            (undeclaredKeys.length > 0 ? `Undeclared keys: ${undeclaredKeys.join(', ')}. ` : '') +
            'Project data to a new object containing only the intended field keys; object spreads are not safe projections.'
        );
      }
    }
    if (Array.isArray(fields) && fields.length > 0) {
      const catalogFields = getComponentSchema('KeyValuePair')?.properties.find(
        (property) => property.key === 'fields'
      )?.default;
      const catalogKeyById = new Map<string, string>();
      if (Array.isArray(catalogFields)) {
        for (const field of catalogFields) {
          const entry = recordValue(field);
          if (typeof entry?.id === 'string' && typeof entry.key === 'string') {
            catalogKeyById.set(entry.id, entry.key);
          }
        }
      }
      const deletionHistoryValue = propVal(props, 'fieldDeletionHistory');
      const deletionHistory = new Set(
        Array.isArray(deletionHistoryValue)
          ? deletionHistoryValue.filter((key): key is string => typeof key === 'string')
          : []
      );
      const hasCustomField = fields.some((field) => {
        const id = recordValue(field)?.id;
        return typeof id !== 'string' || !catalogKeyById.has(id);
      });
      const contradictoryDemoKeys = hasCustomField
        ? fields.flatMap((field) => {
            const id = recordValue(field)?.id;
            const key = typeof id === 'string' ? catalogKeyById.get(id) : undefined;
            return key && deletionHistory.has(key) ? [key] : [];
          })
        : [];
      if (contradictoryDemoKeys.length) {
        warnings.push(
          `KeyValuePair "${label}": persisted catalog demo fields (${[...new Set(contradictoryDemoKeys)].join(', ')}) ` +
            'are still present even though fieldDeletionHistory marks them deleted. Deletion history does not remove ' +
            'already-persisted rows; replace properties.fields with the complete intended array in one update.'
        );
      }
      fields.forEach((field, index) => {
        const entry = recordValue(field);
        if (
          entry?.fieldType === 'string' &&
          (looksDateLikeField(entry.key) || looksDateLikeField(entry.name))
        ) {
          warnings.push(
            `KeyValuePair "${label}" field[${index}] "${String(entry.key ?? entry.name)}" looks date/time-like but uses ` +
              'fieldType:"string", which can expose a raw ISO timestamp. Use fieldType:"datepicker" with explicit ' +
              'dateFormat/parseDateFormat matching the source, unless the raw timestamp is intentional.'
          );
        }
      });
    }
  }

  // Text holding markdown in the default html format renders the markdown literally.
  errors.push(...lintTextFormat(spec));
  errors.push(...lintHtmlContentHeight(spec));
  errors.push(...lintHtmlRootSurface(spec));
  errors.push(...lintUnguardedComponentRefs(spec));
  errors.push(...lintEmbeddedBindingSyntax(spec));
  errors.push(...lintChartDataShape(spec));
  errors.push(...lintUnguardedSelectionText(spec));
  warnings.push(...lintSurfaceInsets(spec));

  // Table: data-binding + column config traps.
  if (spec.type === 'Table') {
    // A stringified columns array crashes the Table component; check it before the shape-dependent lints.
    errors.push(...lintTableColumnsShape(spec));
    const data = propVal(props, 'data');
    const selector = propVal(props, 'dataSourceSelector');
    const autogen = propVal(props, 'autogenerateColumns');
    const columns = propVal(props, 'columns');
    const hasColumns = Array.isArray(columns);
    const projectedDataKeys = projectedTableDataKeys(data);
    const projectsDataKeys = projectedDataKeys !== undefined;
    const desktopHeight = (spec.layouts?.desktop ?? spec.layout)?.height;
    const dynamicHeight = catalogValue('Table', props, 'dynamicHeight');
    const contentWrap = catalogValue('Table', spec.styles, 'contentWrap', 'styles');
    const expandableRows = catalogValue('Table', props, 'enableExpandableRows');
    const paginationEnabled = catalogValue('Table', props, 'enablePagination');
    const serverSide = catalogValue('Table', props, 'serverSidePagination');
    const rowsPerPage = optionalStaticNumber(
      isTruthyBinding(serverSide)
        ? catalogValue('Table', props, 'serverSideRowsPerPage')
        : catalogValue('Table', props, 'rowsPerPage')
    );
    if (functionStyleTableMap(data)) {
      errors.push(
        `Table "${label}": the projection checker cannot certify a function-style .map() callback. ` +
          'Rewrite map(function(row) { return {id:row.id}; }) as map(row => ({id:row.id})), keeping the same explicit keys. ' +
          'Do not remove columns or disable autogenerateColumns to work around this; use the expression-body arrow or pre-shape complex logic in a query.'
      );
    } else if (statementBodyMapInValue(data)) {
      errors.push(
        `Table "${label}": data uses a statement-body .map() callback (for example map(row => { ... })). ` +
          'ToolJet can silently evaluate this binding as no data. Use an expression body such as ' +
          'map(row => ({...})) or pre-shape multi-statement logic in the datasource/RunJS query.'
      );
    }
    if (
      typeof desktopHeight === 'number' &&
      rowsPerPage !== undefined &&
      rowsPerPage > 0 &&
      isTruthyBinding(paginationEnabled) &&
      !isTruthyBinding(dynamicHeight) &&
      !isTruthyBinding(expandableRows)
    ) {
      const cellSize = catalogValue('Table', spec.styles, 'cellSize', 'styles');
      const baseRowHeight = cellSize === 'condensed' ? TABLE_CONDENSED_ROW_HEIGHT_PX : TABLE_REGULAR_ROW_HEIGHT_PX;
      const rowHeight = isTruthyBinding(contentWrap) ? Math.max(baseRowHeight, 60) : baseRowHeight;
      const toolbarVisible = ['displaySearchBox', 'showFilterButton', 'showDownloadButton', 'showAddNewRowButton', 'showBulkUpdateActions']
        .some((key) => isTruthyBinding(catalogValue('Table', props, key)));
      const chromeHeight =
        (toolbarVisible ? TABLE_TOOLBAR_HEIGHT_PX : 0) +
        TABLE_COLUMN_HEADER_HEIGHT_PX +
        TABLE_FOOTER_HEIGHT_PX +
        TABLE_BORDER_PX;
      const minimumHeight = chromeHeight + rowsPerPage * rowHeight;
      if (desktopHeight < chromeHeight + baseRowHeight) {
        errors.push(
          `Table "${label}": desktop height ${desktopHeight}px cannot show even one data row; ` +
            `use at least ${chromeHeight + baseRowHeight}px.`
        );
      } else if (desktopHeight < minimumHeight) {
        warnings.push(
          `Table "${label}": desktop height ${desktopHeight}px is too short to show ${rowsPerPage} ` +
            `${cellSize === 'condensed' ? 'condensed' : 'regular'} rows without an inner scrollbar; use about ` +
            `${minimumHeight}px, reduce rowsPerPage, or enable dynamicHeight. This is an estimate; wrapped rows vary. ` +
            'Deliberate inner scrolling is valid when the rows and actions remain usable.'
        );
      }
    }
    if (data !== undefined && selector !== 'rawJson') {
      warnings.push(
        `Table "${label}": binds \`data\` but dataSourceSelector is not "rawJson" — it may render blank. ` +
          `Set properties.dataSourceSelector.value = "rawJson".`
      );
    }
    if (data !== undefined && !isTruthyBinding(autogen) && !hasColumns) {
      warnings.push(
        `Table "${label}": binds \`data\` with neither autogenerateColumns:true nor an explicit columns array — columns may not render.`
      );
    }
    // Same trap as an all-autogenerated columns array below, caught before ToolJet writes one back:
    // with no columns authored, every header is the raw field name the query returned.
    if (data !== undefined && !hasColumns && !projectsDataKeys && (autogen === undefined || isTruthyBinding(autogen))) {
      errors.push(
        `Table "${label}": bound straight to the query's rows with no authored columns, so ToolJet generates one column per database ` +
          'field and labels each with the raw field name ("flight_number", "delay_code"). Project the data to the keys you want ' +
          '(.map(r => ({...}))) and author the columns array, each {name,key,id,columnType,columnSize,autogenerated:false} with a readable name.'
      );
    }
    if (hasColumns) {
      const columnKeys = new Map<string, number[]>();
      (columns as unknown[]).forEach((column, index) => {
        const key = (column as Record<string, unknown> | null)?.key;
        if (typeof key !== 'string' || !key) return;
        const indexes = columnKeys.get(key) ?? [];
        indexes.push(index);
        columnKeys.set(key, indexes);
      });
      for (const [key, indexes] of columnKeys) {
        if (indexes.length > 1) {
          errors.push(
            `Table "${label}": duplicate column key "${key}" at indexes ${indexes.join(', ')} — ToolJet silently keeps the last column. Use unique keys.`
          );
        }
      }
      if (isTruthyBinding(autogen) && projectedDataKeys) {
        const undeclaredKeys = projectedDataKeys.filter((key) => !columnKeys.has(key));
        if (undeclaredKeys.length) {
          warnings.push(
            `Table "${label}": projected data keys ${undeclaredKeys.join(', ')} have no matching explicit column while ` +
              'autogenerateColumns is true, so ToolJet will append them as visible columns. Add matching columns with ' +
              'columnVisibility:false when the data is still needed (for example an id used by row actions), or remove ' +
              'the keys from the projection.'
          );
        }
      }
      if (isTruthyBinding(autogen) && !projectsDataKeys && data !== undefined) {
        // An error, not a warning: on 2026-09-12 nine of thirteen pages of one app showed raw snake_case
        // columns (member_id, tx_type, order_index) because the bindings were bare query references.
        errors.push(
          `Table "${label}": has an explicit columns array but autogenerateColumns is still true — ` +
            `ToolJet will append undeclared datasource fields (often technical IDs) as raw snake_case columns. Project the Table data binding to a new object with only intended keys (.map(r => ({...}))); ` +
            `identity maps and object spreads are not safe projections. ` +
            `This is safer than disabling autogeneration, which can crash some ToolJet Table versions.`
        );
      }
      // Columns ToolJet generated for itself are named after the raw field: a flight table shipped with
      // "flight_number", "delay_code", "aircraft_status" as its headers on 2026-09-12. Autogeneration is
      // a runtime safety net, not a column design, so a bound table needs authored columns.
      const authoredColumns = (columns as unknown[]).filter((col) => {
        const c = col as Record<string, unknown> | null;
        return c != null && c.autogenerated !== true && c.autogenerated !== 'true';
      });
      if (data !== undefined && authoredColumns.length === 0 && !projectsDataKeys && (autogen === undefined || isTruthyBinding(autogen))) {
        errors.push(
          `Table "${label}": bound straight to the query's rows with only columns ToolJet generated for itself, so every header is the raw ` +
            'field name ("flight_number", "delay_code"). Project the data to the keys you want (.map(r => ({...}))) and author the ' +
            'columns array, each {name,key,id,columnType,columnSize,autogenerated:false} with a readable name.'
        );
      }
      const visibleColumnCount = (columns as unknown[]).filter((col) => {
        const c = col as Record<string, unknown> | null;
        return c && c.columnVisibility !== false && c.columnVisibility !== '{{false}}';
      }).length;
      // Height advice is computed once above from the catalog chrome and row size. Pagination-off,
      // dynamic/expanded content and deliberate scrolling cannot be proven clipped from a static box.
      // Columns wider than the table: authored columnSize values are pixels, and whatever does not fit is cut
      // at the right edge (round eight, 2026-09-12: four tables summed 955 to 1775px of columns inside 530 to
      // 1090px of width and lost their last columns mid value). Root tables only; nested canvases differ.
      const tableWidth = (spec.layouts?.desktop ?? spec.layout)?.width;
      if (typeof tableWidth === 'number' && tableWidth > 0 && !parentPlacement(spec)?.parentId) {
        const widthPx = Math.round(tableWidth * CANVAS_COLUMN_PX);
        let sizedPx = 0;
        let unsized = 0;
        for (const col of columns as unknown[]) {
          const c = col as Record<string, unknown> | null;
          if (!c || c.columnVisibility === false || c.columnVisibility === '{{false}}') continue;
          if (typeof c.columnSize === 'number' && c.columnSize >= 16) sizedPx += c.columnSize;
          else unsized += 1;
        }
        const neededPx = sizedPx + unsized * TABLE_UNSIZED_COLUMN_MIN_PX;
        if (neededPx > widthPx + 8) {
          errors.push(
            `Table "${label}": its ${visibleColumnCount} visible columns need about ${neededPx}px (the columnSize values plus ` +
              `${TABLE_UNSIZED_COLUMN_MIN_PX}px per unsized column) but the table is ${tableWidth} columns wide, about ${widthPx}px on a laptop, ` +
              'so the last columns are cut off at the right edge. Show fewer columns (detail belongs in a side panel or modal), ' +
              'shrink the columnSize values, or widen the table.'
          );
        }
      }
      if (visibleColumnCount >= WRAP_REQUIRED_COLUMNS && !isTrueBinding(propVal(spec.styles, 'contentWrap'))) {
        errors.push(
          `Table "${label}" has ${visibleColumnCount} columns and styles.contentWrap off (the catalog default), so any value wider than its ` +
            'cell (an email, a description, a timestamp) is cut mid word with no ellipsis. Set styles.contentWrap to true ' +
            '(rows grow to fit) and keep long text columns at columnSize 180 or more.'
        );
      }
      (columns as unknown[]).forEach((col, i) => {
        const c = col as Record<string, unknown> | null;
        for (const req of ['name', 'key']) {
          if (c == null || c[req] === undefined) {
            warnings.push(
              `Table "${label}" column[${i}]: missing \`${req}\` — explicit columns should be ` +
                `{name,key,id,columnType,columnSize,autogenerated:false}.`
            );
          }
        }
        const deprecatedReplacement =
          typeof c?.columnType === 'string' ? DEPRECATED_TABLE_COLUMN_TYPES[c.columnType] : undefined;
        if (c && c.columnVisibility !== false && c.columnVisibility !== '{{false}}' &&
            typeof c.header === 'string' && c.header.trim() && !c.header.includes('{{') &&
            c.header !== c.name) {
          errors.push(
            `Table "${label}" column[${i}] "${String(c.key ?? c.name ?? '')}": header is ignored by ToolJet. ` +
            'Put the intended display label in name, keep the source field in key, and remove header.'
          );
        }
        // columnSize is a pixel width, not a flex weight or canvas grid span. Tiny positive
        // values collapse ordinary text/date columns to the renderer's minimum width.
        // Ignore hidden columns and non-literal values rather than guessing their runtime intent.
        if (
          c && c.columnVisibility !== false && c.columnVisibility !== '{{false}}' &&
          typeof c.columnSize === 'number' && c.columnSize > 0 && c.columnSize < 16 &&
          ['string', 'text', 'number', 'datepicker', 'button'].includes(String(c.columnType))
        ) {
          errors.push(
            `Table "${label}" column[${i}] "${String(c.key ?? c.name)}": columnSize ${c.columnSize} ` +
              'is in pixels, not proportional weights or grid columns. Use a readable pixel width ' +
              '(for example 240 for a name, 140 for a date), or omit columnSize for the default.'
          );
        } else if (c && c.columnVisibility !== false && c.columnVisibility !== '{{false}}' && typeof c.columnSize === 'number' && c.columnSize > 0) {
          const type = String(c.columnType ?? 'string');
          const heading = columnWords(`${String(c.name ?? '')} ${String(c.key ?? '')}`);
          const base = TABLE_COLUMN_MIN_PX[type] ?? 100;
          const minimum = ['string', 'text', 'html', 'number'].includes(type)
            ? Math.max(base, MONEY_COLUMN_NAME.test(heading) ? TABLE_COLUMN_MONEY_MIN_PX : 0, NAME_COLUMN_NAME.test(heading) ? TABLE_COLUMN_NAME_MIN_PX : 0)
            : base;
          if (c.columnSize < minimum) {
            warnings.push(
              `Table "${label}" column[${i}] "${String(c.key ?? c.name)}": columnSize ${c.columnSize} is below the readable minimum of ${minimum}px for a ${type} column ` +
                '(possible mid-word wrapping or clipped values). Size for the actual content; deliberate compact columns are valid after visual verification.'
            );
          }
        }
        if (deprecatedReplacement) {
          errors.push(
            `Table "${label}" column[${i}] "${String(c?.key ?? c?.name ?? '')}" uses deprecated ` +
              `columnType:"${String(c?.columnType)}". ToolJet marks it deprecated in the inspector and some ` +
              `deprecated types render an empty cell. Use columnType:"${deprecatedReplacement}" instead.`
          );
        }
        if (typeof c?.columnType === 'string' && !c.columnType.startsWith('{{') &&
            !deprecatedReplacement && !VALID_TABLE_COLUMN_TYPES.has(c.columnType)) {
          errors.push(
            `Table "${label}" column[${i}] "${String(c.key ?? c.name)}" has unsupported columnType:"${c.columnType}". ` +
            (c.columnType === 'date' || c.columnType === 'datetime'
              ? 'Use columnType:"datepicker" with explicit dateFormat/parseDateFormat matching the source; unknown types fall back to raw text.'
              : `Use a supported type: ${[...VALID_TABLE_COLUMN_TYPES].join(', ')}.`)
          );
        }
        if (c && c.headerCasing !== undefined && !VALID_HEADER_CASING.has(c.headerCasing as string)) {
          warnings.push(
            `Table "${label}" column[${i}]: headerCasing "${String(c.headerCasing)}" is invalid — use "none" (as typed) or "uppercase".`
          );
        }
        if (
          c?.columnType === 'string' &&
          (looksDateLikeField(c.key) || looksDateLikeField(c.name))
        ) {
          warnings.push(
            `Table "${label}" column[${i}] "${String(c.key ?? c.name)}" looks date/time-like but uses ` +
              'columnType:"string", which can expose a raw ISO timestamp. Use columnType:"datepicker" with explicit ' +
              'dateFormat/parseDateFormat matching the source, unless the raw timestamp is intentional.'
          );
        }
        if (c?.columnType === 'button') {
          const buttons = c.buttons;
          if (!Array.isArray(buttons) || buttons.length === 0) {
            warnings.push(
              `Table "${label}" column[${i}]: button column needs a non-empty \`buttons\` array; ` +
                `read get_component_catalog({type:"Table",sections:["authoringHints"]}).`
            );
          } else {
            const ids = new Set<string>();
            buttons.forEach((button, buttonIndex) => {
              const id = (button as Record<string, unknown> | null)?.id;
              if (typeof id !== 'string' || id.length === 0) {
                warnings.push(
                  `Table "${label}" column[${i}] button[${buttonIndex}]: missing string \`id\`; ` +
                    `its event ref must be <column key or name>::<button id>.`
                );
              } else if (ids.has(id)) {
                warnings.push(`Table "${label}" column[${i}]: duplicate button id "${id}" makes event refs ambiguous.`);
              } else {
                ids.add(id);
              }
            });
          }
        }
      });
      // Semantic quality (warnings only): a user-facing default table should not surface raw database
      // field names or internal IDs as headers, and shouldn't be wide enough to force horizontal
      // scrolling. Advisory — the model may keep them deliberately (e.g. an id needed by a row action).
      const visibleColumns = (columns as unknown[])
        .map((column) => column as Record<string, unknown> | null)
        .filter((column) => column && column.columnVisibility !== false && column.columnVisibility !== '{{false}}');
      const rawHeaderColumns = visibleColumns
        .map((column) => String((column!.name ?? column!.key) ?? '').trim())
        .filter((header) => header && (looksRawFieldHeader(header) || looksInternalIdField(header)));
      if (rawHeaderColumns.length) {
        warnings.push(
          `Table "${label}": visible columns ${rawHeaderColumns.map((header) => `"${header}"`).join(', ')} expose raw ` +
            'database field names or internal IDs as user-facing headers. Give them human-readable `name` labels, ' +
            'or hide internal IDs with columnVisibility:false.'
        );
      }
      if (visibleColumns.length > TABLE_VISIBLE_COLUMN_WARN) {
        warnings.push(
          `Table "${label}": ${visibleColumns.length} visible columns likely overflow the viewport width and force ` +
            `horizontal scrolling. Show only the most useful columns (about ${TABLE_VISIBLE_COLUMN_WARN} or fewer) and ` +
            'hide the rest with columnVisibility:false.'
        );
      }
    }
    const legacyActions = propVal(props, 'actions');
    if (Array.isArray(legacyActions) && legacyActions.length > 0) {
      warnings.push(
        `Table "${label}": properties.actions is the deprecated row-action surface and can render without a reachable event. Use a columnType:"button" column plus table_column onClick events.`
      );
    }
    if (isTruthyBinding(propVal(props, 'serverSidePagination'))) {
      if (propVal(props, 'serverSideRowsPerPage') === undefined) {
        warnings.push(`Table "${label}": server-side pagination needs serverSideRowsPerPage bound to the query page size.`);
      }
      if (propVal(props, 'totalRecords') === undefined) {
        warnings.push(`Table "${label}": server-side pagination needs totalRecords bound to a separate count/metadata query.`);
      }
    }
  }

  if (spec.type === 'Form') {
    const mode = propVal(props, 'generateFormFrom');
    const schemaValue = propVal(props, 'newJsonSchema');
    if (mode === 'jsonSchema' && schemaValue === undefined) {
      warnings.push(`Form "${label}": generateFormFrom is "jsonSchema" but newJsonSchema is missing.`);
    }
    if (mode === 'rawJson' && propVal(props, 'JSONData') === undefined) {
      warnings.push(`Form "${label}": generateFormFrom is "rawJson" but JSONData is missing.`);
    }
    const fields = recordValue(recordValue(schemaValue)?.properties);
    if (mode === 'jsonSchema' && fields) {
      const standaloneRequiredFields: string[] = [];
      for (const [fieldName, rawField] of Object.entries(fields)) {
        const field = recordValue(rawField);
        if (!field) continue;
        const type = field.type;
        if (typeof type !== 'string' || !FORM_SCHEMA_FIELD_TYPE_SET.has(type)) {
          errors.push(
            `Form "${label}" field "${fieldName}": unsupported type "${String(type)}". ` +
              'Use the authoritative Form field-type list; aliases such as email/star/file do not work.'
          );
          continue;
        }
        if (type === 'filepicker') {
          errors.push(
            `Form "${label}" field "${fieldName}": type "filepicker" crashes the entire Form. ` +
              'Use a standalone FilePicker component and read components.<picker>.file instead.'
          );
        }
        if (type === 'datepicker' && (field.value === null || field.value === undefined)) {
          warnings.push(
            `Form "${label}" field "${fieldName}": a null/omitted datepicker value renders ToolJet's 01/01/2022 demo date. ` +
              'Set value to "{{null}}" for an empty create field.'
          );
        }
        if (['dropdown', 'multiselect'].includes(type)) {
          if ('options' in field) {
            errors.push(
              `Form "${label}" field "${fieldName}": ${type} uses "values" and "displayValues", not "options".`
            );
          }
          if (!('values' in field) || !('displayValues' in field)) {
            warnings.push(
              `Form "${label}" field "${fieldName}": ${type} should define both "values" and "displayValues".`
            );
          }
        }
        if (type !== 'filepicker' && !SAFE_GENERATED_FORM_FIELD_TYPE_SET.has(type)) {
          standaloneRequiredFields.push(`${fieldName} (${type})`);
        }
        const validation = recordValue(field.validation);
        if ('required' in field || validation?.required !== undefined) {
          warnings.push(
            `Form "${label}" field "${fieldName}": "required" is not a supported Form schema validator. ` +
              'Use validation.minLength or validation.customRule.'
          );
        }
      }
      if (standaloneRequiredFields.length > 0) {
        errors.push(
          `Form "${label}": generated fields ${standaloneRequiredFields.join(', ')} are not layout-safe. ` +
            'FormUtils cannot pass alignment through consistently; Dropdown/Multiselect labels become misaligned and TextArea retains a literal "Label". ' +
            'Build the entire form from standalone components with styles.alignment.value="top"; use a consistent two-column grid and full-width TextArea fields.'
        );
      }
    }
  }

  // Form input: a narrow field with a side-aligned label (the default) wastes width on the label.
  if (FORM_INPUT_TYPES.has(spec.type ?? '')) {
    const align = propVal(spec.styles, 'alignment'); // `alignment` is a STYLE, not a property
    const width = (spec.layouts?.desktop ?? spec.layout)?.width;
    if ((align === undefined || align === 'side') && typeof width === 'number' && width <= NARROW_SIDE_LABEL_COLS) {
      warnings.push(
        `${spec.type} "${label}": narrow (${width} cols) with a SIDE-aligned label (the default) — the label ` +
          `eats the input width. Set styles.alignment.value = "top" (label above the control), especially in forms/modals.`
      );
    }
  }

  return { errors, warnings };
}

/** Pairwise desktop-rect overlap within a set of components. */
export function detectOverlaps(components: LintComponent[]): string[] {
  const warnings: string[] = [];
  const items = components
    .filter((c) => !(c.type === 'ModalV2' && isFalseBinding(propVal(c.properties, 'useDefaultButton'))))
    .map((c) => ({
      component: c,
      name: c.name ?? c.type ?? '?',
      r: c.layouts?.desktop ?? c.layout,
      parent: placementKey(c),
    }))
    .filter((x): x is { component: LintComponent; name: string; r: Rect; parent: string } => !!x.r);
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      if (items[i].parent !== items[j].parent) continue;
      if (mutuallyExclusiveVisibility(items[i].component, items[j].component)) continue;
      const a = items[i].r;
      const b = items[j].r;
      const ax = a.left ?? 0,
        ay = a.top ?? 0,
        aw = a.width ?? 0,
        ah = renderedHeight(items[i].component, a);
      const bx = b.left ?? 0,
        by = b.top ?? 0,
        bw = b.width ?? 0,
        bh = renderedHeight(items[j].component, b);
      if (ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah) {
        const increments = [items[i], items[j]]
          .filter((item) => renderedHeight(item.component, item.r) > (item.r.height ?? 0))
          .map(
            (item) =>
              `"${item.name}" renders ${renderedHeight(item.component, item.r)}px tall ` +
              `(authored ${item.r.height ?? 0}px + ${TOP_ALIGNMENT_HEIGHT_INCREMENT}px for its top-aligned label)`
          );
        warnings.push(
          `Components "${items[i].name}" and "${items[j].name}" overlap at rendered desktop size` +
            (increments.length ? `; ${increments.join(' and ')}` : '') +
            `.`
        );
      }
    }
  }
  return warnings;
}

/** Hiding a ModalV2 launch button does not remove its canvas wrapper. It can
 * still intercept clicks on siblings. Keep this advisory: DOM stacking order,
 * custom pointer-events and dynamic visibility are not statically knowable. */
export function lintHiddenModalHitTargets(components: LintComponent[]): string[] {
  const interactive = new Set(['Button', 'ButtonGroup', 'ButtonGroupV2', 'Table', 'Kanban', 'Calendar', 'Map', ...FORM_INPUT_TYPES]);
  const warnings: string[] = [];
  for (const modal of components) {
    if (modal.type !== 'ModalV2' || !isFalseBinding(propVal(modal.properties, 'useDefaultButton'))) continue;
    const a = modal.layouts?.desktop ?? modal.layout;
    if (!a) continue;
    const targets: string[] = [];
    for (const target of components) {
      if (!interactive.has(target.type ?? '') || placementKey(target) !== placementKey(modal) || mutuallyExclusiveVisibility(modal, target)) continue;
      const b = target.layouts?.desktop ?? target.layout;
      if (!b) continue;
      if ((a.left ?? 0) < (b.left ?? 0) + (b.width ?? 0) && (b.left ?? 0) < (a.left ?? 0) + (a.width ?? 0) &&
          (a.top ?? 0) < (b.top ?? 0) + renderedHeight(target, b) && (b.top ?? 0) < (a.top ?? 0) + (a.height ?? 0)) {
        targets.push(target.name ?? target.type ?? '?');
      }
    }
    if (targets.length) warnings.push(`ModalV2 "${modal.name ?? '?'}" hides its launch button but its canvas footprint overlaps interactive component(s) ${targets.map(n=>`"${n}"`).join(', ')}. The invisible wrapper can intercept clicks even with useDefaultButton:false. Move its footprint to unused canvas space, keeping modal contents in their own slots, and verify the actual trigger is clickable. Do not disable the modal or remove its open action.`);
  }
  return warnings;
}

const TOOLBAR_BUTTON_TYPES = new Set(['Button', 'ButtonGroup']);

/** A button sharing a row with top-labelled inputs must align with their field boxes, not their labels.
 *  A top-labelled input renders its label in the first 20px and its box below (see renderedHeight), so a
 *  button authored at the inputs' top sits on the label band, visibly above the fields. Measured on
 *  2026-09-12 in three Luna builds (todo, vendors, Chainventory): every toolbar button was misaligned. */
export function lintToolbarButtonAlignment(components: LintComponent[]): string[] {
  const errors: string[] = [];
  const items = components
    .map((c) => ({ component: c, name: c.name ?? c.type ?? '?', r: c.layouts?.desktop ?? c.layout, parent: placementKey(c) }))
    .filter((x): x is { component: LintComponent; name: string; r: Rect; parent: string } => !!x.r);
  const grownInputs = items.filter((x) => renderedHeight(x.component, x.r) > (x.r.height ?? 0));
  if (!grownInputs.length) return errors;
  for (const button of items) {
    if (!button.component.type || !TOOLBAR_BUTTON_TYPES.has(button.component.type)) continue;
    const bTop = button.r.top ?? 0;
    const bBottom = bTop + (button.r.height ?? 0);
    for (const input of grownInputs) {
      if (input.parent !== button.parent) continue;
      const iTop = input.r.top ?? 0;
      const labelBand = iTop + TOP_ALIGNMENT_HEIGHT_INCREMENT;
      const boxBottom = iTop + renderedHeight(input.component, input.r);
      // Same row: the button's span meets the input's rendered span and they do not share columns.
      if (bBottom <= iTop || bTop >= boxBottom) continue;
      const bLeft = button.r.left ?? 0, bRight = bLeft + (button.r.width ?? 0);
      const iLeft = input.r.left ?? 0, iRight = iLeft + (input.r.width ?? 0);
      if (bLeft < iRight && iLeft < bRight) continue; // an overlap; detectOverlaps reports it
      if (bTop >= labelBand) continue; // aligned with the field box (or below it): fine
      errors.push(
        `Button "${button.name}" shares its row with the top-labelled input "${input.name}" but sits at top ${bTop}: ` +
          `the input's label renders in its first ${TOP_ALIGNMENT_HEIGHT_INCREMENT}px and its field box from ${labelBand} to ${boxBottom}, ` +
          `so the button lands on the label band. Set the button's top to ${labelBand} (height ${Math.max(0, boxBottom - labelBand)}) ` +
          'so it aligns with the field, or give the inputs no label and a placeholder instead.'
      );
      break;
    }
  }
  return errors;
}

function isTitleLikeText(component: LintComponent): boolean {
  if (component.type !== 'Text') return false;
  const top = (component.layouts?.desktop ?? component.layout)?.top ?? 0;
  if (top > 100) return false;
  const name = component.name ?? '';
  const text = propVal(component.properties, 'text');
  const fontWeight = propVal(component.styles, 'fontWeight');
  const textSize = optionalStaticNumber(propVal(component.styles, 'textSize'));
  return (
    /(?:title|heading|header)/i.test(name) ||
    (typeof text === 'string' && !text.includes('{{') && text.trim().length > 0 && text.trim().length <= 80 &&
      (/^(?:add|create|edit|new|view|update)\b/i.test(text.trim()) || /(?:title|details?)$/i.test(text.trim()))) ||
    (typeof fontWeight === 'string' && /bold|[6-9]00/.test(fontWeight)) ||
    (typeof fontWeight === 'number' && fontWeight >= 600) ||
    (textSize !== undefined && textSize >= 18)
  );
}

/** Modal checks work both before a batch write (clientRef/parentRef) and on persisted ids. */
export function lintModalChildren(components: LintComponent[]): string[] {
  const warnings: string[] = [];
  const refs = new Map(
    components.flatMap((component) => {
      const key = componentKey(component);
      return key ? [[key, component] as const] : [];
    })
  );
  const parentOf = (component: LintComponent): LintComponent | undefined =>
    refs.get(parentPlacement(component)?.parentId ?? '');
  const modalChildren = components.filter((component) => {
    const parent = parentOf(component);
    return parent?.type === 'ModalV2' || parent?.type === 'Modal';
  });
  const bodyChildren = modalChildren.filter((component) => parentPlacement(component)?.slotName === 'body');

  for (const child of bodyChildren) {
    if (!FORM_INPUT_TYPES.has(child.type ?? '')) continue;
    const align = propVal(child.styles, 'alignment');
    if (align === undefined || align === 'side') {
      warnings.push(
        `${child.type} "${child.name ?? child.type}": modal form child uses a SIDE-aligned label — ` +
          `set styles.alignment.value = "top" so the control gets the full field width.`
      );
    }
  }

  for (let i = 0; i < bodyChildren.length; i++) {
    for (let j = i + 1; j < bodyChildren.length; j++) {
      const a = bodyChildren[i];
      const b = bodyChildren[j];
      if (
        parentPlacement(a)?.parentId !== parentPlacement(b)?.parentId ||
        !FORM_INPUT_TYPES.has(a.type ?? '') ||
        !FORM_INPUT_TYPES.has(b.type ?? '')
      ) continue;
      const ar = a.layouts?.desktop ?? a.layout;
      const br = b.layouts?.desktop ?? b.layout;
      if (!ar || !br) continue;
      const ax = ar.left ?? 0, aw = ar.width ?? 0, ay = ar.top ?? 0, ah = renderedHeight(a, ar);
      const bx = br.left ?? 0, bw = br.width ?? 0, by = br.top ?? 0, bh = renderedHeight(b, br);
      if (!(ax < bx + bw && bx < ax + aw)) continue;
      const gap = by >= ay + ah ? by - (ay + ah) : ay >= by + bh ? ay - (by + bh) : -1;
      if (gap >= 0 && gap < 10) {
        warnings.push(
          `Modal fields "${a.name ?? a.type}" and "${b.name ?? b.type}" have only ${gap}px vertical gap — ` +
            `use at least 10px on ToolJet's vertical grid.`
        );
      }
    }
  }

  for (const modal of components.filter((component) => component.type === 'ModalV2' || component.type === 'Modal')) {
    const key = componentKey(modal);
    if (!key) continue;
    const children = bodyChildren.filter((child) => parentPlacement(child)?.parentId === key);
    if (modal.type === 'ModalV2' && !isFalseBinding(propVal(modal.properties, 'showHeader'))) {
      const headerChildren = modalChildren.filter((child) => {
        const placement = parentPlacement(child);
        return placement?.parentId === key && placement.slotName === 'header';
      });
      if (!headerChildren.length) {
        warnings.push(
          `Modal "${modal.name ?? modal.type}" has showHeader enabled but its native header slot is empty, so it renders reserved blank chrome. ` +
            'Add a Text child with the modal parent_ref/parent and slot_name:"header", or set showHeader:false.'
        );
      }
      for (const child of children.filter(isTitleLikeText)) {
        warnings.push(
          `Modal "${modal.name ?? modal.type}" has title-like Text "${child.name ?? child.type}" in the body while the native header is visible. ` +
            'Move that Text to slot_name:"header" instead of spending body space on a second title row.'
        );
      }
    }
    const childBottoms = children.flatMap((child) => {
      const rect = child.layouts?.desktop ?? child.layout;
      return rect ? [{ child, bottom: (rect.top ?? 0) + renderedHeight(child, rect) }] : [];
    });
    if (!childBottoms.length) continue;

    const lowest = childBottoms.reduce((current, candidate) => candidate.bottom > current.bottom ? candidate : current);
    const modalHeight = staticNumber(propVal(modal.properties, 'modalHeight'), 400);
    const isV2 = modal.type === 'ModalV2';
    const headerHeight = !isV2 || isFalseBinding(propVal(modal.properties, 'showHeader'))
      ? 0
      : staticNumber(propVal(modal.properties, 'headerHeight'), 80);
    const footerHeight = !isV2 || isFalseBinding(propVal(modal.properties, 'showFooter'))
      ? 0
      : staticNumber(propVal(modal.properties, 'footerHeight'), 80);
    const bottomSlack = 20;
    const requiredHeight = lowest.bottom + headerHeight + footerHeight + bottomSlack;
    if (modalHeight < requiredHeight) {
      warnings.push(
        `Modal "${modal.name ?? modal.type}" has modalHeight ${modalHeight}px but needs at least ${requiredHeight}px ` +
          `for child "${lowest.child.name ?? lowest.child.type}" (rendered bottom ${lowest.bottom}px + ` +
          `${headerHeight}px header + ${footerHeight}px footer + ${bottomSlack}px bottom slack); ` +
          `content can be clipped or forced into unintended scrolling.`
      );
    }
  }
  return warnings;
}

/** Geometry-only checks for a complete page after creates, property edits, or layout edits. */
/** Geometry a customer sees as broken: components on top of each other, a toolbar button on the label
 *  band, modal or list children outside their parent. Filed as errors: on 2026-09-12 the same overlaps
 *  shipped in every round while they were warnings, because a model reads a warning as optional. */
export function lintRenderedGeometryBlocking(components: LintComponent[]): string[] {
  return [
    ...detectOverlaps(components),
    ...lintToolbarButtonAlignment(components),
    ...lintModalChildren(components),
    ...lintListviewChildren(components),
  ];
}

/** Geometry advice: fold, canvas coverage, gutters. Warnings. */
export function lintRenderedGeometryAdvisory(components: LintComponent[]): string[] {
  return [
    ...lintOperationalViewport(components),
    ...lintDesktopCanvasCoverage(components),
    ...lintCanvasSideGutter(components),
  ];
}

export function lintRenderedGeometry(components: LintComponent[]): string[] {
  return [...lintRenderedGeometryBlocking(components), ...lintRenderedGeometryAdvisory(components)];
}

// Widgets that are legitimately a few pixels tall, or whose authored box is not what renders.
const THIN_BY_DESIGN = new Set(['Divider', 'VerticalDivider', 'Spacer', 'ModalV2', 'Modal', 'Icon']);
const MIN_RENDERABLE_HEIGHT = 24;

/** A model that mistakes the pixel grid for row units authors 14px headers, 10px inputs and 1px
 *  modals; every other lint passes and the app renders as a row of slivers. Measured on one Grok 4.5
 *  build: four pages, every header, KPI strip and input under 16px, no lint error. Below 24px
 *  nothing but a divider can show its content, so this is an error, not a warning. */
export function lintUnrenderableHeights(components: LintComponent[]): string[] {
  const errors: string[] = [];
  for (const c of components) {
    if (!c.type || THIN_BY_DESIGN.has(c.type)) continue;
    const height = c.layouts?.desktop?.height;
    if (typeof height !== 'number' || height >= MIN_RENDERABLE_HEIGHT) continue;
    errors.push(
      `${c.type} "${c.name ?? c.id ?? '?'}": desktop height ${height}px cannot render its content; heights are ` +
        `pixels on a 10px grid, not row units. Use at least ${MIN_RENDERABLE_HEIGHT}px (inputs 40, headers 60+, ` +
        'KPI strips 120+, tables 300+).'
    );
  }
  return errors;
}

/** Lint a batch: per-component checks + overlap detection across the batch. */
export function lintComponents(components: LintComponent[]): LintResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  warnings.push(...lintSelectedRowProjections(components));
  for (const c of components) {
    const r = lintComponentSpec(c);
    errors.push(...r.errors);
    errors.push(...lintStandardSingleLineInputHeight(c));
    errors.push(...lintButtonLabelWidth(c));
    warnings.push(...lintUnboundEmptyState(c));
    errors.push(...lintTableProjectionRender(c, warnings));
    errors.push(...lintStaticDisabledSurface(c));
    errors.push(...lintDefaultInputLabel(c));
    warnings.push(...r.warnings);
  }
  errors.push(...lintComponentSlots(components));
  warnings.push(...lintKanbanCardChildren(components));
  warnings.push(...lintStatisticsRows(components));
  warnings.push(...lintEmptyTabs(components)); // a partial add may create the parent before its children
  errors.push(...lintUnusableTextGeometry(components));
  errors.push(...lintUnrenderableHeights(components));
  errors.push(...lintOversizedWidths(components));
  for (const c of components) errors.push(...lintHtmlContentHeight(c), ...lintHtmlRootSurface(c), ...lintUnguardedComponentRefs(c), ...lintEmbeddedBindingSyntax(c), ...lintChartDataShape(c), ...lintUnguardedSelectionText(c));
  warnings.push(...lintTextGeometry(components));
  for (const c of components) warnings.push(...lintSurfaceInsets(c));
  errors.push(...lintRenderedGeometryBlocking(components));
  warnings.push(...lintRenderedGeometryAdvisory(components));
  warnings.push(...lintKanbanInteractions(components));
  warnings.push(...lintHiddenModalHitTargets(components));
  return { errors, warnings };
}

const uniq = (xs: string[]): string[] => [...new Set(xs)];

/** A stat row authored one page at a time drifts: page 1 gets 152px tiles with a 34px value, page 2
 *  gets 120px tiles with a 28px value, and the app reads as three different products. Nothing in the
 *  per-component lints can see this, because every individual tile is legal. Compare the app's stat
 *  rows once, after the pages exist. Nested tiles are skipped: inside a Listview or Kanban they are a
 *  per-row template, not the page's stat row. */
const KPI_STRIP_VALUE_FONT_MIN_PX = 20;

function isHtmlKpiStrip(rawHtml: unknown): boolean {
  if (typeof rawHtml !== 'string') return false;
  const html = rawHtml.replace(/\s+/g, '');
  if (!/display:(grid|flex)/.test(html)) return false;
  // A KPI card carries one figure noticeably larger than its label; prose blocks and legends do not.
  return [...html.matchAll(/font-size:(\d+)px/g)].some((m) => Number(m[1]) >= KPI_STRIP_VALUE_FONT_MIN_PX);
}

const distinct = <T,>(xs: T[]): T[] => [...new Set(xs)];

export function lintStatTileConsistency(summary: AppSummary): string[] {
  const warnings: string[] = [];
  const tiles: Array<{ page: string; height?: number; valueSize?: number; labelSize?: number }> = [];
  const stripPages = new Map<string, number[]>();

  for (const page of summary.pages) {
    const pageName = page.name ?? page.id;
    for (const component of page.components as LintComponent[]) {
      if (component.parent) continue;
      const height = (component.layouts?.desktop ?? component.layout)?.height;
      if (component.type === 'Statistics') {
        tiles.push({
          page: pageName,
          height: typeof height === 'number' ? height : undefined,
          valueSize: optionalStaticNumber(
            catalogValue('Statistics', component.styles, 'primaryValueSize', 'styles')
          ),
          labelSize: optionalStaticNumber(
            catalogValue('Statistics', component.styles, 'primaryLabelSize', 'styles')
          ),
        });
      } else if (
        component.type === 'Html' &&
        typeof height === 'number' &&
        isHtmlKpiStrip(propVal(component.properties, 'rawHtml'))
      ) {
        stripPages.set(pageName, [...(stripPages.get(pageName) ?? []), height]);
      }
    }
  }

  const tilePages = distinct(tiles.map((t) => t.page));
  if (tilePages.length > 1) {
    const heights = distinct(tiles.map((t) => t.height).filter((h): h is number => h !== undefined));
    if (heights.length > 1) {
      const perPage = tilePages
        .map((page) => `${page}: ${distinct(tiles.filter((t) => t.page === page).map((t) => t.height)).join('/')}`)
        .join('; ');
      warnings.push(
        `Statistics tiles differ in height across pages (${perPage}). Compare equivalent visual roles for ` +
          'accidental drift; overview and detail metrics may intentionally differ. Do not normalize all pages automatically.'
      );
    }
    const typeScales = distinct(tiles.map((t) => `${t.valueSize ?? '?'}/${t.labelSize ?? '?'}`));
    if (typeScales.length > 1) {
      const perPage = tilePages
        .map(
          (page) =>
            `${page}: ${distinct(
              tiles.filter((t) => t.page === page).map((t) => `${t.valueSize ?? '?'}/${t.labelSize ?? '?'}`)
            ).join(', ')}`
        )
        .join('; ');
      warnings.push(
        `Statistics tiles use different value/label font sizes across pages (${perPage}, as primaryValueSize/` +
          'primaryLabelSize). Check equivalent roles for consistency; intentional emphasis and compact detail metrics may use different scales.'
      );
    }
  }

  if (stripPages.size > 1) {
    const stripHeights = distinct([...stripPages.values()].flat());
    if (stripHeights.length > 1) {
      const perPage = [...stripPages].map(([page, hs]) => `${page}: ${distinct(hs).join('/')}`).join('; ');
      warnings.push(
        `Html KPI strips differ in height across pages (${perPage}). Check whether their roles and content differ ` +
          'before changing them; different page jobs do not require equal heights or type scales.'
      );
    }
  }

  const mechanismPages = distinct([...tilePages, ...stripPages.keys()]);
  if (mechanismPages.length > 1 && tilePages.length > 0 && stripPages.size > 0) {
    warnings.push(
      `Stat rows are built two different ways in one app (Statistics on ${tilePages.join(', ')}; Html KPI strip on ` +
        `${[...stripPages.keys()].join(', ')}). Both mechanisms are valid; compare equivalent roles for ` +
        'visual consistency without replacing components or adding metrics merely to make pages identical.'
    );
  }

  return warnings;
}

/** Whole-app structural validation over a compact app summary (post-write). Catches dangling
 *  references, ambiguous duplicate names, and bindings to non-existent queries/components, plus
 *  re-runs the per-component render lints against what actually persisted. */
export function validateAppStructure(summary: AppSummary): LintResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  warnings.push(...lintEditPrefill(summary));
  warnings.push(...lintUninitializedWriteSelections(summary));
  warnings.push(...lintWhitespaceGuards(summary));
  warnings.push(...lintSelectedRowObjectGuards(summary));

  const allComponents = summary.pages.flatMap((p) => p.components);
  const componentNames = new Set(allComponents.map((c) => c.name).filter(Boolean) as string[]);
  const componentIds = new Set(allComponents.map((c) => c.id));
  const queryNames = new Set(summary.queries.map((q) => q.name).filter(Boolean) as string[]);
  const queryIds = new Set(summary.queries.map((q) => q.id));
  const pageIds = new Set(summary.pages.map((p) => p.id));

  // Duplicate component names within a page (ambiguous {{components.X}}).
  for (const p of summary.pages) {
    // ToolJet renders IconHome2 for the native Home page even when its stored icon is empty. API
    // summaries are not guaranteed to return pages in creation order, so identify Home by its
    // stable handle/name rather than array position. Other icon-less pages also receive a
    // generic fallback, which makes multi-page sidebar navigation look unfinished.
    const isNativeHome = p.handle === 'home' || p.name === 'Home';
    // Saved legacy mistakes are visible but do not block unrelated functional repairs.
    // New/planned icons and icon writes are rejected before persistence.
    if (p.icon) {
      const iconError = pageIconError(p.icon);
      if (iconError) warnings.push(`Page "${p.name ?? p.id}": ${iconError}`);
    }
    if (!isNativeHome && !p.icon) {
      warnings.push(
        `Page "${p.name ?? p.id}" has no icon — set a relevant Tabler export so the left sidebar does not use a generic fallback icon.`
      );
    }
    const counts = new Map<string, number>();
    for (const c of p.components) if (c.name) counts.set(c.name, (counts.get(c.name) ?? 0) + 1);
    for (const [name, n] of counts) {
      if (n > 1) warnings.push(`Page "${p.name}": ${n} components named "${name}" — {{components.${name}}} is ambiguous.`);
    }
    for (const kanban of p.components.filter((component) => component.type === 'Kanban')) {
      if (!p.components.some((component) => component.parent === kanban.id)) {
        warnings.push(
          `Kanban "${kanban.name ?? kanban.id}" has no nested card child components, so cards can render with ` +
            `correct columns/counts but blank bodies. Recreate it through add_component(s), or add an Html/Text ` +
            `child parented to this Kanban.`
        );
      }
    }
  }
  // Duplicate query names (ambiguous {{queries.X}}).
  {
    const counts = new Map<string, number>();
    for (const q of summary.queries) if (q.name) counts.set(q.name, (counts.get(q.name) ?? 0) + 1);
    for (const [name, n] of counts) {
      if (n > 1) warnings.push(`${n} queries named "${name}" — {{queries.${name}}} is ambiguous.`);
    }
  }

  // The native Home page is entered during initial app load. A query with runOnPageLoad=true that
  // is also run by Home.onPageLoad executes twice and can noticeably delay first paint.
  const homePage = summary.pages.find((page) => page.handle === 'home' || page.name === 'Home');
  if (homePage) {
    const appLoadQueryIds = new Set(
      summary.queries
        .filter((query) => isTruthyBinding(propVal(recordValue(query.options), 'runOnPageLoad')))
        .map((query) => query.id)
    );
    for (const event of summary.events) {
      if (event.target !== 'page' || event.sourceId !== homePage.id) continue;
      const value = recordValue(event.event);
      if (
        value?.eventId === 'onPageLoad' &&
        value.actionId === 'run-query' &&
        typeof value.queryId === 'string' &&
        appLoadQueryIds.has(value.queryId)
      ) {
        const query = summary.queries.find((candidate) => candidate.id === value.queryId);
        warnings.push(
          `Query "${query?.name ?? value.queryId}" has runOnPageLoad=true and is also run by Home.onPageLoad, ` +
            'so the initial page executes it twice. Keep one lifecycle path; use focused page events for later navigation refreshes.'
        );
      }
    }
  }

  // RunJS code is stored as a plain JavaScript body. ToolJet does not register plain
  // `queries.foo` reads inside that body as reactive bindings, so runOnDependencyChange can leave
  // an aggregate at its first (often empty) result. Treat explicit source-query success chains as
  // the reliable dependency graph.
  const queryByName = new Map(summary.queries.flatMap((query) => query.name ? [[query.name, query] as const] : []));
  for (const query of summary.queries.filter((candidate) => candidate.kind === 'runjs')) {
    const options = recordValue(query.options);
    const code = options?.code;
    if (typeof code !== 'string') continue;
    for (const name of runjsComponentReferences(code)) {
      if (!componentNames.has(name)) errors.push(
        `RunJS query "${query.name ?? query.id}" references components[${JSON.stringify(name)}], but no component is named ` +
          `${JSON.stringify(name)}. Use the persisted component name exactly (bracket notation for spaces); ` +
          'a plan client_ref is not a runtime component name. A fallback can hide the missing reference and silently ignore user input.'
      );
    }
    const referencedNames = runjsQueryReferences(code);
    for (const name of referencedNames) {
      if (!queryNames.has(name)) errors.push(
        `RunJS query "${query.name ?? query.id}" references queries[${JSON.stringify(name)}], but no query is named ` +
          `${JSON.stringify(name)}. Names are case-sensitive; use the persisted query name exactly (bracket notation for spaces). ` +
          'An empty-array fallback can hide this mistake and make a populated dashboard show zero records.'
      );
    }
    if (!isTruthyBinding(propVal(options, 'runOnDependencyChange'))) continue;
    if (!referencedNames.length) continue;
    const explicitlyChained = new Set(
      summary.events.flatMap((event) => {
        if (event.target !== 'data_query') return [];
        const payload = recordValue(event.event);
        return payload?.eventId === 'onDataQuerySuccess' &&
          payload.actionId === 'run-query' && payload.queryId === query.id
          ? [event.sourceId]
          : [];
      })
    );
    const missing = referencedNames.filter((name) => {
      const source = queryByName.get(name);
      return source && !explicitlyChained.has(source.id);
    });
    if (missing.length) {
      warnings.push(
        `RunJS query "${query.name ?? query.id}" sets runOnDependencyChange=true but reads ${missing.map((name) => `queries.${name}`).join(', ')} ` +
          'as plain JavaScript. ToolJet does not infer those reads as reactive dependencies, so the result can stay empty or stale. ' +
          'Run this query explicitly from each source query\'s onDataQuerySuccess event (after the source data exists), or invoke it from a later user/page event.'
      );
    }
  }

  // Datasource query options can bind filters/parameters to another query's data. Starting both
  // automatically lets the dependent query evaluate before its source has returned, and ToolJet does
  // not necessarily retry it. Require an explicit source-success chain for these saved dependencies.
  const successChains = new Set(
    summary.events.flatMap((event) => {
      if (event.target !== 'data_query') return [];
      const payload = recordValue(event.event);
      return payload?.eventId === 'onDataQuerySuccess' &&
        payload.actionId === 'run-query' && typeof payload.queryId === 'string'
        ? [`${event.sourceId}->${payload.queryId}`]
        : [];
    })
  );
  for (const query of summary.queries.filter((candidate) => candidate.kind !== 'runjs')) {
    const options = recordValue(query.options);
    if (!options) continue;
    const automatic = isTruthyBinding(propVal(options, 'runOnPageLoad')) ||
      isTruthyBinding(propVal(options, 'runOnDependencyChange'));
    if (!automatic) continue;
    const blob = JSON.stringify(options);
    const referencedNames = [...new Set(
      [...blob.matchAll(/\bqueries\.([A-Za-z_][A-Za-z0-9_]*)/g)].map((match) => match[1]!)
    )];
    const missing = referencedNames.filter((name) => {
      const source = queryByName.get(name);
      return source && source.id !== query.id && !successChains.has(`${source.id}->${query.id}`);
    });
    if (missing.length) {
      warnings.push(
        `Query dependency race: query "${query.name ?? query.id}" starts automatically but reads ` +
          `${missing.map((name) => `queries.${name}.data`).join(', ')}. The dependent query can run before its source ` +
          'has returned and remain empty or stale. Disable its automatic start and run it explicitly from each source ' +
          `query's onDataQuerySuccess event, or pass a stable custom-variable/component value instead.`
      );
    }
  }

  // Result-shape mismatch. ToolJet DB `sql_execution` returns data as {results: rows}; every other
  // ToolJet DB operation (list_rows, joins) returns the rows array itself. Observed live (Luna max,
  // 2026-09-06): the catalog hint for SQL reads was applied to two list_rows queries, so both
  // Maintenance tables read `queries.q.data.results`, got undefined, and showed No data with no error.
  for (const component of allComponents) {
    const blob = JSON.stringify(component.properties ?? '');
    const bad = new Set<string>();
    for (const m of blob.matchAll(/\bqueries\.([A-Za-z_][A-Za-z0-9_]*)\??\.data\??\.results\b/g)) {
      const query = queryByName.get(m[1]!);
      if (!query || query.kind !== 'tooljetdb') continue;
      const operation = recordValue(query.options)?.operation;
      if (operation === 'sql_execution' || operation === undefined) continue;
      bad.add(m[1]!);
    }
    for (const name of bad) {
      const operation = String(recordValue(queryByName.get(name)?.options)?.operation);
      errors.push(
        `${component.type ?? 'Component'} "${component.name ?? component.id}": reads queries.${name}.data.results, but "${name}" is a ` +
          `ToolJet DB ${operation} query whose data is the rows array itself; only sql_execution returns {results: rows}. ` +
          `Bind queries.${name}.data instead, or the component shows No data.`
      );
    }
  }

  // The mirror image: a ToolJet DB sql_execution query returns {results: rows}, so a data-bound component
  // reading `queries.q.data` gets an object, not rows, and shows No data. Observed live (Nordlicht
  // benchmark, 2026-09-07): Haiku wrote seven SQL queries and bound every table and KPI to `.data`;
  // all four pages rendered empty although the seeds and the queries were fine.
  for (const component of allComponents) {
    if (!['Table', 'ListView', 'Chart', 'Kanban', 'Statistics', 'Text', 'Html'].includes(component.type ?? '')) continue;
    const blob = JSON.stringify(component.properties ?? '');
    const bad = new Set<string>();
    for (const m of blob.matchAll(/\bqueries\.([A-Za-z_][A-Za-z0-9_]*)\??\.data(?![\w?]*\.results)\b/g)) {
      const query = queryByName.get(m[1]!);
      if (!query || query.kind !== 'tooljetdb') continue;
      if (recordValue(query.options)?.operation !== 'sql_execution') continue;
      if (blob.includes(`queries.${m[1]}.data.results`) || blob.includes(`queries.${m[1]}?.data?.results`) || blob.includes(`queries.${m[1]}.data?.results`)) continue;
      bad.add(m[1]!);
    }
    for (const name of bad) {
      errors.push(
        `${component.type} "${component.name ?? component.id}": reads queries.${name}.data, but "${name}" is a ToolJet DB sql_execution ` +
          `query whose data is {results: rows}. Bind queries.${name}.data.results (or data.results[0].<column> for a single value), ` +
          'or the component shows No data.'
      );
    }
  }

  // ServiceNow unwraps the REST `result` envelope: without a transformation, queries.q.data is the rows
  // array (or the record). Observed live (model-guide benchmark, 2026-09-07): Luna max,
  // Luna high and Gemini Pro bound every incident list to data.result from memory of the raw REST API and
  // rendered empty queues although the queries returned 16 to 40 incidents.
  for (const component of allComponents) {
    const blob = JSON.stringify(component.properties ?? '');
    const bad = new Set<string>();
    for (const m of blob.matchAll(/\bqueries\.([A-Za-z_][A-Za-z0-9_]*)\??\.data\??\.result\b/g)) {
      const query = queryByName.get(m[1]!);
      if (!query || query.kind !== 'servicenow') continue;
      // Transformations replace query.data and may deliberately add a result field.
      if (isTruthyBinding(propVal(recordValue(query.options), 'enableTransformation'))) continue;
      bad.add(m[1]!);
    }
    for (const name of bad) {
      errors.push(
        `${component.type ?? 'Component'} "${component.name ?? component.id}": reads queries.${name}.data.result, but "${name}" is a ` +
          'ServiceNow query and the plugin already unwraps the REST result envelope: queries.<q>.data is the records array ' +
          `(or the record for get/create/update). Bind queries.${name}.data instead, or the component shows No data.`
      );
    }
  }

  // A query referenced by bare name. Observed live (Haiku, Helix benchmark 2026-09-07): `jobsWaitingLongest.data`
  // instead of `queries.jobsWaitingLongest.data`, which is an undefined identifier at runtime, so the table
  // showed No data while the query itself was fine. Component references are excluded by the lookbehind
  // (they always follow a dot or bracket).
  for (const component of allComponents) {
    const blob = JSON.stringify(component.properties ?? '');
    const bare = new Set<string>();
    for (const name of queryByName.keys()) {
      if (!name || !/^[A-Za-z_$][\w$]*$/.test(name)) continue;
      const pattern = new RegExp(`(?<![\\w$.\\]'"])${name.replace(/\$/g, '\\$')}\\??\\.(data|rawData|isLoading)\\b`);
      if (pattern.test(blob)) bare.add(name);
    }
    for (const name of bare) {
      errors.push(
        `${component.type ?? 'Component'} "${component.name ?? component.id}": reads ${name}.data by bare name; queries are referenced as ` +
          `queries.${name}.data. A bare name is undefined at runtime and the component shows No data.`
      );
    }
  }

  // A Chart bound straight to query rows plots nothing unless the query itself returns x and y.
  // Observed live (Nordlicht benchmark, 2026-09-07): Terra bound a ToolJet DB group_by/aggregate query
  // returning {order_date, orders_count} and the "orders per day" chart drew an empty axis.
  for (const component of allComponents) {
    if (component.type !== 'Chart') continue;
    const props = component.properties ?? {};
    if (isTruthyBinding(propVal(props, 'plotFromJson'))) continue;
    const data = propVal(props, 'data');
    const m = typeof data === 'string' ? data.trim().match(BARE_QUERY_DATA_BINDING) : null;
    if (!m) continue;
    const query = queryByName.get(m[1]!);
    if (!query || query.kind === 'runjs' || query.kind === 'runpy') continue;
    const options = recordValue(query.options);
    const sql = typeof options?.query === 'string' ? options.query : typeof (recordValue(options?.sql_execution))?.sqlQuery === 'string' ? String(recordValue(options?.sql_execution)?.sqlQuery) : '';
    if (sql && /\bas\s+["'`]?x["'`]?\b/i.test(sql) && /\bas\s+["'`]?y["'`]?\b/i.test(sql)) continue;
    errors.push(
      `Chart "${component.name ?? component.id}": data binds queries.${m[1]}.data directly, but "${m[1]}" is a ${query.kind ?? 'datasource'} query ` +
        'that does not return columns named x and y. The Chart plots [{x, y}] only and draws an empty axis otherwise. ' +
        `Map the rows: {{queries.${m[1]}.data.map(r => ({x: r.<label>, y: Number(r.<value>)}))}}.`
    );
  }

  // Dangling event references.
  for (const e of summary.events) {
    const name = e.name ?? e.id;
    const validSources =
      e.target === 'data_query'
        ? queryIds
        : e.target === 'page'
          ? pageIds
          : e.target === 'component' || e.target === 'table_column' || e.target === 'table_action'
            ? componentIds
            : new Set([...componentIds, ...queryIds, ...pageIds]);
    if (e.sourceId && !validSources.has(e.sourceId)) {
      errors.push(`Event "${name}" is attached to a source (${e.sourceId}) that no longer exists.`);
    }
    const ev = (e.event ?? {}) as Record<string, unknown>;
    if (ev.actionId === 'run-query' && typeof ev.queryId === 'string' && !queryIds.has(ev.queryId)) {
      errors.push(`Event "${name}" runs a query (${ev.queryId}) that no longer exists.`);
    }
  }

  // Bindings to non-existent queries/components + re-run per-component render lints.
  const bindingSources = [
    ...allComponents.map((c) => ({ label: `Component "${c.name ?? c.id}"`, value: { p: c.properties, s: c.styles, v: c.validation, o: c.others } })),
    ...summary.queries.map((q) => ({ label: `Query "${q.name ?? q.id}"`, value: q.options })),
    ...summary.events.map((e) => ({ label: `Event "${e.name ?? e.id}"`, value: e.event })),
  ];
  warnings.push(...lintSelectedRowProjections(allComponents, bindingSources.filter(s => !s.label.startsWith('Component '))));
  for (const source of bindingSources) {
    errors.push(...lintComponentStateBindings(source.value, allComponents, source.label));
    const seen = new Set<string>();
    for (const ref of bindingReferences(source.value)) {
      const names = ref.namespace === 'components' ? componentNames : queryNames;
      const key = `${ref.namespace}.${ref.name}`;
      if (!names.has(ref.name) && !seen.has(key)) {
        seen.add(key);
        errors.push(`${source.label} references ${key}, but no ${ref.namespace === 'components' ? 'component' : 'query'} ` +
          `is named "${ref.name}". Binding names are case-sensitive; use the persisted name.`);
      }
    }
  }
  for (const c of allComponents) {
    const blob = JSON.stringify({ p: c.properties ?? {}, s: c.styles ?? {} });
    for (const m of blob.matchAll(/\{\{\s*queries\.([A-Za-z0-9_]+)/g)) {
      if (!queryNames.has(m[1])) {
        warnings.push(`Component "${c.name ?? c.id}" binds {{queries.${m[1]}…}} but no query is named "${m[1]}".`);
      }
    }
    for (const m of blob.matchAll(/\{\{\s*components\.([A-Za-z0-9_]+)/g)) {
      if (!componentNames.has(m[1])) {
        warnings.push(`Component "${c.name ?? c.id}" binds {{components.${m[1]}…}} but no component is named "${m[1]}".`);
      }
    }
    const r = lintComponentSpec({
      id: c.id,
      name: c.name ?? c.id,
      type: c.type,
      properties: c.properties,
      styles: c.styles,
      layouts: c.layouts as LintComponent['layouts'],
      parent: c.parent,
    });
    errors.push(...r.errors);
    warnings.push(...r.warnings);
  }

  const eventsBySource = new Map<string, Set<string>>();
  for (const event of summary.events) {
    if (!event.sourceId || event.target !== 'component') continue;
    const trigger = (event.event as Record<string, unknown> | undefined)?.eventId;
    if (typeof trigger !== 'string') continue;
    const triggers = eventsBySource.get(event.sourceId) ?? new Set<string>();
    triggers.add(trigger);
    eventsBySource.set(event.sourceId, triggers);
  }
  for (const table of allComponents.filter((component) => component.type === 'Table')) {
    const triggers = eventsBySource.get(table.id) ?? new Set<string>();
    const dataBinding = JSON.stringify(propVal(table.properties, 'data') ?? '');
    const boundDataQueries = [...new Set(
      [...dataBinding.matchAll(/queries\.([A-Za-z_][A-Za-z0-9_]*)/g)].map((match) => match[1]!)
    )];
    const hasReactiveDataQuery = (stateName: string): boolean => boundDataQueries.some((queryName) => {
      const query = queryByName.get(queryName);
      const options = recordValue(query?.options);
      if (!options || !isTruthyBinding(propVal(options, 'runOnDependencyChange'))) return false;
      return typeof table.name === 'string' && JSON.stringify(options).includes(`components.${table.name}.${stateName}`);
    });
    const requirements: Array<[string, string, string]> = [
      ['serverSidePagination', 'onPageChanged', 'pageIndex'],
      ['serverSideSearch', 'onSearch', 'searchText'],
      ['serverSideSort', 'onSort', 'sortApplied'],
      ['serverSideFilter', 'onFilterChanged', 'filters'],
    ];
    for (const [property, trigger, stateName] of requirements) {
      if (
        isTruthyBinding(propVal(table.properties, property)) &&
        !triggers.has(trigger) &&
        !hasReactiveDataQuery(stateName)
      ) {
        warnings.push(
          `Table "${table.name ?? table.id}": ${property} is enabled but no ${trigger} event refreshes its data query ` +
            `and no runOnDependencyChange data query is bound to components.${table.name ?? '<table>'}.${stateName}.`
        );
      }
    }

    const tableColumnRefs = new Set(
      summary.events
        .filter((event) => event.sourceId === table.id && event.target === 'table_column')
        .map((event) => (event.event as Record<string, unknown> | undefined)?.ref)
        .filter((ref): ref is string => typeof ref === 'string')
    );
    const columns = propVal(table.properties, 'columns');
    if (Array.isArray(columns)) {
      columns.forEach((column, columnIndex) => {
        const col = column as Record<string, unknown> | null;
        if (col?.columnType !== 'button' || col.useDynamicColumn === true || !Array.isArray(col.buttons)) return;
        const columnKey = col.key ?? col.name;
        if (typeof columnKey !== 'string') return;
        col.buttons.forEach((button, buttonIndex) => {
          const b = button as Record<string, unknown> | null;
          if (Array.isArray(b?.events) && b.events.length > 0) return;
          if (typeof b?.id !== 'string') return;
          const ref = `${columnKey}::${b.id}`;
          if (!tableColumnRefs.has(ref)) {
            warnings.push(
              `Table "${table.name ?? table.id}" column[${columnIndex}] button[${buttonIndex}] has no ` +
                `table_column onClick event with ref "${ref}".`
            );
          }
        });
      });
    }
  }

  for (const p of summary.pages) {
    errors.push(...lintUnusableTextGeometry(p.components as LintComponent[]));
    errors.push(...lintUnrenderableHeights(p.components as LintComponent[]));
    errors.push(...lintOversizedWidths(p.components as LintComponent[]));
    for (const c of p.components as LintComponent[]) errors.push(...lintHtmlContentHeight(c), ...lintHtmlRootSurface(c), ...lintUnguardedComponentRefs(c), ...lintEmbeddedBindingSyntax(c), ...lintChartDataShape(c), ...lintUnguardedSelectionText(c));
    warnings.push(...lintTextGeometry(p.components as LintComponent[]));
    for (const c of p.components) warnings.push(...lintSurfaceInsets(c));
    errors.push(...lintRenderedGeometryBlocking(p.components as LintComponent[]));
    warnings.push(...lintRenderedGeometryAdvisory(p.components as LintComponent[]));
    warnings.push(...lintKanbanInteractions(p.components as LintComponent[]));
  }
  warnings.push(...lintInnerPageBands(summary));
  // Data-bound components whose query nothing runs render No data forever.
  const readiness = lintUntriggeredDataQueries(summary);
  errors.push(...readiness.errors);
  warnings.push(...readiness.warnings);
  warnings.push(...lintStatTileConsistency(summary));

  return { errors: uniq(errors), warnings: uniq(warnings) };
}

/* Relative luminance of a CSS hex colour (0 = black, 1 = white); NaN for anything that is not hex. */
function hexLuminance(hex: string): number {
  const raw = hex.replace('#', '');
  const full = raw.length === 3 ? raw.split('').map((c) => c + c).join('') : raw;
  if (!/^[0-9a-f]{6}$/i.test(full)) return NaN;
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(full.slice(i, i + 2), 16) / 255);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** True when an Html block's ROOT element paints a dark or brand-filled background: a flat dark hex,
 *  a gradient with a dark stop, or the primary brand token. Only the root's inline style counts, so a
 *  light card that merely contains a dark badge is not a band. */
export function htmlRootHasDarkBackground(rawHtml: string): boolean {
  const root = rawHtml.match(/<[a-z][a-z0-9]*\b[^>]*\bstyle\s*=\s*"([^"]*)"/i);
  if (!root) return false;
  const declaration = root[1].match(/(?:^|;)\s*background(?:-color|-image)?\s*:\s*([^;]+)/i);
  if (!declaration) return false;
  const value = declaration[1];
  if (/var\(--cc-primary-brand\)/i.test(value)) return true;
  const hexes = value.match(/#(?:[0-9a-f]{6}|[0-9a-f]{3})\b/gi) ?? [];
  return hexes.some((hex) => hexLuminance(hex) < 0.35);
}

/** The skill's header treatments put a statement band (a dark or brand-filled header) on the home page
 *  only; inner pages take a plain title, toolbar or masthead. Measured on two Sol builds with a stated
 *  design brief, the second or third page still came back with a dark band the brief never chose, so
 *  this names the drift at lint time. A warning, not an error: a brief can choose it deliberately. */
export function lintInnerPageBands(summary: AppSummary): string[] {
  const warnings: string[] = [];
  const pages = summary.pages ?? [];
  const explicitHome = pages.some((p) => p.handle === 'home' || p.name === 'Home' || p.index === 1);
  pages.forEach((page, pageIndex) => {
    const isHome =
      page.handle === 'home' || page.name === 'Home' || page.index === 1 || (!explicitHome && pageIndex === 0);
    if (isHome) return;
    for (const component of page.components ?? []) {
      if (component.type !== 'Html' || component.parent) continue;
      const rawHtml = propVal((component as { properties?: Record<string, unknown> }).properties ?? {}, 'rawHtml');
      if (typeof rawHtml !== 'string') continue;
      const desktop = (component.layouts as { desktop?: { top?: number; height?: number; width?: number } } | undefined)
        ?.desktop;
      if (!desktop || (desktop.top ?? 0) > 60 || (desktop.height ?? 0) > 200 || (desktop.width ?? 0) < 20) continue;
      if (!htmlRootHasDarkBackground(rawHtml)) continue;
      warnings.push(
        `Page "${page.name ?? page.id}": Html "${component.name ?? component.id}" is a dark or brand-filled header ` +
          'band on a page that is not Home. The skill\'s header treatments put a statement band on the home page ' +
          'only; inner pages take a plain title, toolbar or masthead. Keep it only if the design brief chose it ' +
          'for this page deliberately.'
      );
    }
  });
  return warnings;
}
