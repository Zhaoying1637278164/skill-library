import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { isInitializeRequest } from '@modelcontextprotocol/sdk/types.js';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { buildServer } from './server.js';
import { identityFromHeaders, type RequestIdentity } from './config.js';
import { bearerValue } from './httpAuth.js';
import { isBuildToken, mintAuthorized, mintBuildToken, mintSecret, resolveBuildToken, revokeBuildToken } from './buildTokens.js';

const DEFAULT_MAX_BODY_BYTES = 1024 * 1024;

interface Session {
  server: McpServer;
  transport: StreamableHTTPServerTransport;
  /** The build token this session was opened with, when it was opened with one. Kept so every later
   *  request can re-check it: identity is bound at initialize, but a token's VALIDITY is not. */
  buildToken?: string;
  credential: Buffer;
  createdAt: number;
  lastSeenAt: number;
  closing?: boolean;
}

export interface HttpMcpServerOptions {
  /** Creates one isolated MCP server instance for each Streamable HTTP session. Receives the acting
   *  user parsed from the initialize request's headers, when the caller sent one. */
  serverFactory?: (identity?: RequestIdentity) => McpServer;
  /** Maximum accepted JSON request size. Defaults to 1 MiB. */
  maxBodyBytes?: number;
  maxSessions?: number;
  idleTimeoutMs?: number;
  maxSessionAgeMs?: number;
  sweepIntervalMs?: number;
  now?: () => number;
}

export interface HttpMcpServer {
  server: Server;
  close: () => Promise<void>;
  sessionCount: () => number;
}

function writeJson(res: ServerResponse, status: number, body: unknown): void {
  if (res.headersSent) return;

  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
}

function writeError(res: ServerResponse, status: number, message: string): void {
  writeJson(res, status, {
    jsonrpc: '2.0',
    error: { code: -32000, message },
    id: null,
  });
}

function getSessionId(req: IncomingMessage): string | undefined {
  const value = req.headers['mcp-session-id'];
  return Array.isArray(value) ? value[0] : value;
}

/** Do not keep another plaintext copy of credentials. Build-token identity always wins; otherwise
 * bind both the acting-user headers and any bearer supplied at initialization. URL metadata is not
 * identity and never changes the session's already-bound destination. */
function credentialFingerprint(req: IncomingMessage): Buffer {
  const bearer = bearerValue(req.headers.authorization);
  const fields = isBuildToken(bearer) ? [bearer] : [
    bearer ?? null, req.headers['x-tooljet-pat'] ?? null,
    req.headers['x-tooljet-session'] ?? null, req.headers['x-tooljet-workspace-id'] ?? null,
  ];
  return createHash('sha256').update(JSON.stringify(fields)).digest();
}

async function readJsonBody(req: IncomingMessage, maxBodyBytes: number): Promise<unknown> {
  const chunks: Buffer[] = [];
  let totalBytes = 0;

  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    totalBytes += buffer.length;

    if (totalBytes > maxBodyBytes) {
      throw new Error(`Request body exceeds ${maxBodyBytes} bytes`);
    }

    chunks.push(buffer);
  }

  if (chunks.length === 0) throw new Error('Request body is required');
  return JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown;
}

export function createHttpMcpServer(options: HttpMcpServerOptions = {}): HttpMcpServer {
  const serverFactory = options.serverFactory ?? buildServer;
  const maxBodyBytes = options.maxBodyBytes ?? DEFAULT_MAX_BODY_BYTES;
  const sessions = new Map<string, Session>();
  const now = options.now ?? Date.now;
  const maxSessions = options.maxSessions ?? 256;
  const idleTimeout = options.idleTimeoutMs ?? 30 * 60_000;
  const maxAge = options.maxSessionAgeMs ?? 6 * 60 * 60_000;
  let initializing = 0;
  const closing = new Set<Promise<void>>();
  const dispose = (id: string, session: Session): Promise<void> => {
    if (session.closing) return Promise.resolve();
    session.closing = true;
    sessions.delete(id);
    const task = (async () => {
      await session.server.close().catch(() => {});
      await session.transport.close().catch(() => {});
    })();
    closing.add(task);
    void task.finally(() => closing.delete(task));
    return task;
  };
  const expired = (session: Session): boolean => now() - session.lastSeenAt >= idleTimeout ||
    now() - session.createdAt >= maxAge || Boolean(session.buildToken && !resolveBuildToken(session.buildToken));
  const sweep = setInterval(() => {
    for (const [id, session] of sessions) if (expired(session)) void dispose(id, session);
  }, options.sweepIntervalMs ?? 60_000);
  sweep.unref();

  const authorizeSession = async (req: IncomingMessage, res: ServerResponse, id: string, session: Session): Promise<boolean> => {
    if (expired(session)) {
      await dispose(id, session);
      writeError(res, 401, 'Session or build token revoked or expired');
      return false;
    }
    if (!timingSafeEqual(session.credential, credentialFingerprint(req))) {
      writeError(res, 401, 'Session credential does not match');
      return false;
    }
    session.lastSeenAt = now();
    return true;
  };

  const handlePost = async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    let body: unknown;

    try {
      body = await readJsonBody(req, maxBodyBytes);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid JSON request body';
      writeError(res, 400, message);
      return;
    }

    const sessionId = getSessionId(req);
    const existingSession = sessionId ? sessions.get(sessionId) : undefined;

    if (existingSession) {
      if (!await authorizeSession(req, res, sessionId!, existingSession)) return;
      await existingSession.transport.handleRequest(req, res, body);
      return;
    }

    if (sessionId || !isInitializeRequest(body)) {
      writeError(res, 400, 'Bad Request: No valid session ID provided');
      return;
    }

    /* Identity is bound at initialize; every later request must carry the same credential, not just
       the session id. NOTE this transport has
       no bearer gate of its own (src/http.ts binds it to loopback) — do not expose it off-box
       without one, or any local caller could name a user. */
    let identity: RequestIdentity | undefined;
    let sessionBuildToken: string | undefined;
    const bearer = bearerValue(req.headers.authorization);
    if (isBuildToken(bearer)) {
      identity = resolveBuildToken(bearer);
      if (!identity) {
        writeError(res, 401, 'Build token is unknown or expired.');
        return;
      }
      sessionBuildToken = bearer;
    }
    try {
      if (!identity) identity = await identityFromHeaders(req.headers);
    } catch (error) {
      writeError(res, 400, error instanceof Error ? error.message : 'Invalid identity headers');
      return;
    }

    // A build token is the bearer a hosted harness carries: it names the user who started the build,
    // and it is the only way that identity can travel when the harness (not us) holds the connection
    // and the platform forbids custom headers. Resolved before the PAT fallback so a token is never
    // mistaken for a PAT belonging to whoever presented it.
    if (!identity?.pat && !identity?.sessionToken && bearer) {
      // Same fallback as the bundle's direct HTTP mode.
      identity = { ...identity, pat: bearer };
    }
    if (identity && !identity.pat && !identity.sessionToken) {
      writeError(res, 401, 'URL metadata is not a user credential');
      return;
    }

    for (const [id, session] of sessions) if (expired(session)) await dispose(id, session);
    if (sessions.size + initializing >= maxSessions) {
      writeError(res, 503, 'MCP session capacity reached; retry later');
      return;
    }
    initializing++;
    let mcpServer: McpServer | undefined;
    try {
      mcpServer = serverFactory(identity);
      const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => randomUUID(),
        onsessioninitialized: (newSessionId) => {
          sessions.set(newSessionId, { server: mcpServer!, transport, buildToken: sessionBuildToken,
            credential: credentialFingerprint(req), createdAt: now(), lastSeenAt: now() });
        },
      });
      transport.onclose = () => {
        const closedSessionId = transport.sessionId;
        const session = closedSessionId ? sessions.get(closedSessionId) : undefined;
        if (session) void dispose(closedSessionId!, session);
      };
      await mcpServer.connect(transport);
      await transport.handleRequest(req, res, body);
      if (!transport.sessionId) await mcpServer.close();
    } catch (error) {
      await mcpServer?.close().catch(() => {});
      throw error;
    } finally {
      initializing--;
    }
  };

  /** Mint (POST) or revoke (DELETE) a build token. Authorised by the shared mint secret, and the
   *  minted identity is read from this request's own headers, so a caller can only name the user it
   *  could already act as. Absent secret means the feature is off and the route does not exist. */
  const handleBuildToken = async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    const secret = mintSecret();
    if (!secret) {
      writeJson(res, 404, { error: 'Not found' });
      return;
    }
    if (!mintAuthorized(req.headers.authorization, secret)) {
      writeJson(res, 401, { error: 'Build tokens require the mint secret as a bearer.' });
      return;
    }

    if (req.method === 'DELETE') {
      const token = bearerValue(req.headers['x-tooljet-build-token'] as string | undefined)
        ?? (req.headers['x-tooljet-build-token'] as string | undefined);
      const revoked = revokeBuildToken(token);
      for (const [id, session] of sessions) if (session.buildToken === token) await dispose(id, session);
      writeJson(res, 200, { revoked });
      return;
    }

    if (req.method !== 'POST') {
      res.setHeader('allow', 'POST, DELETE');
      writeJson(res, 405, { error: 'Method not allowed' });
      return;
    }

    let identity: RequestIdentity | undefined;
    try {
      identity = await identityFromHeaders(req.headers, { allowPat: false });
    } catch (error) {
      writeJson(res, 400, { error: error instanceof Error ? error.message : 'Invalid identity headers' });
      return;
    }
    if (!identity?.sessionToken || !identity.workspaceId) {
      writeJson(res, 400, {
        error: 'A build token names a signed-in user: send x-tooljet-session with x-tooljet-workspace-id.',
      });
      return;
    }

    let ttlMs: number | undefined;
    try {
      const body = (await readJsonBody(req, maxBodyBytes)) as { ttl_seconds?: number } | undefined;
      if (body && typeof body.ttl_seconds === 'number') ttlMs = body.ttl_seconds * 1000;
    } catch {
      /* no body is fine; the default TTL applies */
    }

    const minted = mintBuildToken(identity, ttlMs);
    writeJson(res, 200, { token: minted.token, expires_at: new Date(minted.expiresAt).toISOString() });
  };

  const handleSessionRequest = async (
    req: IncomingMessage,
    res: ServerResponse,
  ): Promise<void> => {
    const sessionId = getSessionId(req);
    const session = sessionId ? sessions.get(sessionId) : undefined;

    if (!session) {
      writeError(res, 400, 'Invalid or missing session ID');
      return;
    }

    if (!await authorizeSession(req, res, sessionId!, session)) return;
    await session.transport.handleRequest(req, res);
  };

  const server = createServer((req, res) => {
    void (async () => {
      const requestUrl = new URL(req.url ?? '/', 'http://localhost');

      if (requestUrl.pathname === '/health' && req.method === 'GET') {
        writeJson(res, 200, { status: 'ok', transport: 'streamable-http' });
        return;
      }

      if (requestUrl.pathname === '/build-token') {
        await handleBuildToken(req, res);
        return;
      }

      if (requestUrl.pathname !== '/mcp') {
        writeJson(res, 404, { error: 'Not found' });
        return;
      }

      if (req.method === 'POST') {
        await handlePost(req, res);
        return;
      }

      if (req.method === 'GET' || req.method === 'DELETE') {
        await handleSessionRequest(req, res);
        return;
      }

      res.setHeader('allow', 'GET, POST, DELETE');
      writeJson(res, 405, { error: 'Method not allowed' });
    })().catch((error: unknown) => {
      console.error('Error handling MCP HTTP request:', error);
      writeError(res, 500, 'Internal server error');
    });
  });

  const close = async (): Promise<void> => {
    clearInterval(sweep);
    await Promise.allSettled(Array.from(sessions, ([id, session]) => dispose(id, session)));
    await Promise.allSettled(closing);

    if (!server.listening) return;

    await new Promise<void>((resolve, reject) => {
      server.close((error) => (error ? reject(error) : resolve()));
    });
  };

  return {
    server,
    close,
    sessionCount: () => sessions.size,
  };
}
