import { TableQuotaError, tableQuotaError } from './tableQuotaError.js';
import { randomUUID } from 'node:crypto';
import { assertPageIcon } from './pageIcons.js';
import type { Auth, Workspace } from './auth.js';
import type { Config } from './config.js';
import { STYLE_KEYS_IN_PROPERTIES } from './lint.js';
import { hasNonEmptyDefinition } from './strictEntry.js';
import { decodeComponentParent, encodeComponentParent, type ComponentSlotName } from './componentParent.js';
import { tableCreationLevels, TOOLJET_DB_RESERVED_COLUMN_NAMES } from './tableValidation.js';
import { booleanBindingValue, isCanonicalStaticBooleanBinding, staticBooleanBinding } from './bindings.js';
import { invalidSeedTimestamps } from './seedTimestampValidation.js';

export interface CreateAppResult {
  app_id: string;
  version_id: string;
  home_page_id: string;
  /** Backward-compatible alias for editor_url. */
  app_url: string;
  editor_url: string;
  viewer_url: string;
  datasources_url: string;
}

export interface Datasource {
  id: string;
  name: string;
  kind: string;
  settings_url: string;
}

export interface AppTheme {
  id: string;
  name: string;
  definition: Record<string, unknown>;
  isDefault?: boolean;
  isBasic?: boolean;
  isDisabled?: boolean;
  [key: string]: unknown;
}

export interface CreateAppThemeParams {
  name: string;
  definition: Record<string, unknown>;
  isDefault?: boolean;
}

export type AppPermissionResourceType = 'page' | 'query' | 'component';
export type AppPermissionAccessType = 'users' | 'groups';

export interface AppPermissionSubjects {
  users: Array<{ id: string; name?: string; email?: string }>;
  groups: Array<{ id: string; name?: string; count?: number }>;
}

export interface SetAppPermissionParams {
  appId: string;
  resourceType: AppPermissionResourceType;
  resourceId: string;
  accessType: AppPermissionAccessType;
  subjectIds: string[];
}

export type WorkspaceUserStatus = 'active' | 'archived' | 'invited';
export type WorkspaceUserRole = 'admin' | 'builder' | 'end-user';

export interface WorkspaceUser {
  id: string;
  user_id?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  name?: string;
  role?: WorkspaceUserRole;
  status?: WorkspaceUserStatus;
  groups?: Array<{ id: string; name: string }>;
  [key: string]: unknown;
}

export const WORKSPACE_PERMISSION_KEYS = [
  'appCreate', 'appDelete', 'moduleCreate', 'moduleDelete', 'workflowCreate', 'workflowDelete',
  'folderCRUD', 'orgConstantCRUD', 'tjdbCRUD', 'dataSourceCreate', 'dataSourceDelete', 'appPromote', 'appRelease',
] as const;
export const WORKSPACE_ACCESS_KEYS = [
  'canEdit', 'canView', 'hideFromDashboard', 'canAccessDevelopment', 'canAccessStaging',
  'canAccessProduction', 'canAccessReleased', 'canConfigure', 'canUse',
] as const;
export type WorkspaceResourceType = 'app' | 'module' | 'workflow' | 'data_source';
export function workspaceAccessKeys(type: WorkspaceResourceType): readonly string[] {
  if (type === 'data_source') return ['canConfigure', 'canUse'];
  if (type === 'module') return ['canEdit', 'canView', 'hideFromDashboard'];
  if (type === 'workflow') return ['canEdit', 'canView'];
  return WORKSPACE_ACCESS_KEYS.filter(key => !['canConfigure', 'canUse'].includes(key));
}
export interface WorkspaceAccessRule {
  id?: string;
  read_only?: boolean;
  read_only_reason?: string;
  name: string;
  type: WorkspaceResourceType;
  is_all: boolean;
  actions: Record<string, boolean>;
  resources: Array<{ id: string; name: string; membership_id: string }>;
}

export interface WorkspaceGroup {
  id: string;
  name: string;
  type: 'default' | 'custom';
  disabled?: boolean;
  permissions?: Record<string, boolean>;
}

export interface WorkspaceGroupMember {
  group_user_id: string;
  user_id: string;
  email?: string;
  first_name?: string;
  last_name?: string;
}

export interface WorkspaceUsersPage {
  meta: { total_pages: number; total_count: number; current_page: number };
  users: WorkspaceUser[];
}

export interface InviteWorkspaceUserParams {
  email: string;
  role: WorkspaceUserRole;
  firstName?: string;
  lastName?: string;
  groupIds?: string[];
}

export interface UpdateWorkspaceUserParams {
  firstName?: string;
  lastName?: string;
  role?: WorkspaceUserRole;
  addGroupIds?: string[];
  userMetadata?: Record<string, unknown>;
}

export interface AppSettingsSnapshot {
  app_id: string;
  version_id: string;
  global_settings: Record<string, unknown>;
  page_settings: Record<string, unknown>;
}

export interface UpdateAppSettingsParams {
  appId: string;
  versionId: string;
  globalSettings?: Record<string, unknown>;
  pageSettings?: Record<string, unknown>;
  showViewerNavigation?: boolean;
}

export interface CreateQueryParams {
  versionId: string;
  dataSourceId: string;
  name: string;
  options: Record<string, unknown>;
  /** Query kind = the datasource's kind (tooljetdb/postgresql/runjs/servicenow/…). Resolved from the datasource if omitted. */
  kind?: string;
}

export interface CreateQueryResult {
  query_id: string;
  name: string;
}

/** A multi-request batch persisted some items before an upstream failure. Callers must report
 * completed items and must not retry the whole batch or auto-delete user resources. */
export class PartialWriteError<T> extends Error {
  readonly completed: T[];
  readonly failures: string[];

  constructor(operation: string, completed: T[], failures: string[], cause?: unknown) {
    super(
      `ToolJet ${operation} partially failed. Persisted before failure: ${JSON.stringify(completed)}. ` +
        `Failed: ${failures.join(' | ')}. Persisted resources were not deleted automatically.`,
      { cause }
    );
    this.name = 'PartialWriteError';
    this.completed = completed;
    this.failures = failures;
  }
}

export function completedPartialWrites<T>(error: unknown): T[] {
  return error instanceof PartialWriteError ? error.completed as T[] : [];
}

export interface ComponentLayout {
  top?: number;
  left?: number;
  width?: number;
  height?: number;
}

export interface CreateComponentParams {
  appId: string;
  versionId: string;
  pageId: string;
  /** Component name — REQUIRED by ToolJet (NOT NULL); a missing name returns 422 "name is required". */
  name: string;
  type: string;
  properties: Record<string, unknown>;
  styles?: Record<string, unknown>;
  validation?: Record<string, unknown>;
  others?: Record<string, unknown>;
  layout?: ComponentLayout;
  layouts?: { desktop?: ComponentLayout; mobile?: ComponentLayout };
}

export interface CreateComponentResult {
  component_id: string;
}

/** One component in a batch (no app/version/page — those are shared across the batch). */
export interface ComponentSpec {
  name: string;
  type: string;
  properties: Record<string, unknown>;
  /** Native styling (textSize, fontWeight, textColor, backgroundColor, …). Read by ToolJet's
   *  renderer from `definition.styles` — putting these under `properties` is silently ignored. */
  styles?: Record<string, unknown>;
  validation?: Record<string, unknown>;
  /** e.g. `{ showOnMobile: {...}, showOnDesktop: {...} }`. */
  others?: Record<string, unknown>;
  /** Convenience: one rectangle applied to both resolutions. */
  layout?: ComponentLayout;
  /** Explicit per-resolution layout; takes precedence over `layout` for the resolution it sets. */
  layouts?: { desktop?: ComponentLayout; mobile?: ComponentLayout };
  /** Caller-stable reference used only inside one createComponents batch. */
  clientRef?: string;
  /** Parent another component in the same batch by its clientRef. */
  parentRef?: string;
  /** Parent an already-existing component by its ToolJet component id. */
  parent?: string;
  /** Logical parent slot. ToolJet stores header/footer as suffixed parent ids; the client translates it. */
  slotName?: ComponentSlotName;
}


export interface CreateComponentsParams {
  appId: string;
  versionId: string;
  pageId: string;
  components: ComponentSpec[];
}

/** One query in a batch (versionId is shared across the batch). */
export interface QuerySpec {
  dataSourceId: string;
  name: string;
  options: Record<string, unknown>;
  kind?: string;
}

export interface CreateQueriesParams {
  versionId: string;
  queries: QuerySpec[];
}

/** A column when creating a ToolJet-DB table. */
export interface TableColumn {
  name: string;
  /** tjdb data type. Common: "character varying", "integer", "bigint", "double precision", "boolean", "timestamp with time zone", "jsonb", "serial". Friendly aliases (string/number/bool/…) are normalized. */
  type: string;
  primaryKey?: boolean;
  notNull?: boolean;
  unique?: boolean;
  /** Database default. False, 0, and empty strings are preserved. */
  defaultValue?: unknown;
  /** Type-specific ToolJet DB metadata, for example a timestamp timezone. */
  configurations?: Record<string, unknown>;
}

function assertAllowedToolJetDbColumnNames(operation: 'createTable' | 'addTableColumn', columns: TableColumn[]): void {
  const reserved = columns
    .map((column) => column.name)
    .filter((name) => TOOLJET_DB_RESERVED_COLUMN_NAMES.has(name.toLowerCase()));
  if (reserved.length) {
    throw new Error(
      `ToolJet ${operation} failed: reserved column name${reserved.length === 1 ? '' : 's'}: ${reserved.join(', ')}. ` +
        'Use a descriptive name such as step_action, result_comment, or item_condition.'
    );
  }
}

export type ForeignKeyAction = 'RESTRICT' | 'NO ACTION' | 'CASCADE' | 'SET NULL' | 'SET DEFAULT';

export interface TableForeignKey {
  columns: string[];
  referencedTable: string;
  referencedColumns: string[];
  onDelete?: ForeignKeyAction;
  onUpdate?: ForeignKeyAction;
}

export interface CreateTableParams {
  tableName: string;
  columns: TableColumn[];
  foreignKeys?: TableForeignKey[];
}

export interface CreateTableResult {
  table_id: string;
  table_name: string;
}

export interface CreateTablesParams {
  tables: CreateTableParams[];
}

export interface SchemaColumn {
  name: string;
  type: string;
  isPrimaryKey: boolean;
  isNotNull: boolean;
  isUnique: boolean;
  defaultValue?: unknown;
  configurations?: Record<string, unknown>;
  foreignKeys: TableForeignKey[];
}

export interface InsertRowsParams {
  tableName: string;
  rows: Array<Record<string, unknown>>;
}

export interface InsertRowsBatchParams {
  tables: InsertRowsParams[];
}

export interface InsertRowsBatchResult {
  table_name: string;
  processed_rows: number;
}

export interface CreatePageParams {
  appId: string;
  versionId: string;
  name: string;
  /** Exact Tabler export, e.g. "IconLayoutDashboard". ToolJet renders a generic fallback if omitted. */
  icon?: string;
  /** Hide the page from the auto-generated sidebar nav (still reachable via switch-page). For detail/sub-pages. */
  hidden?: boolean;
}

export interface CreatePageResult {
  page_id: string;
  name: string;
  index: number;
  icon?: string;
  hidden?: boolean;
}

export interface CreatePagesParams {
  appId: string;
  versionId: string;
  pages: Array<{ name: string; icon?: string; hidden?: boolean }>;
}

export interface UpdatePageSpec {
  pageId: string;
  name?: string;
  icon?: string;
  hidden?: boolean;
}

export interface DeletePageParams {
  appId: string;
  versionId: string;
  pageId: string;
  deleteAssociatedPages?: boolean;
}

export interface UpdatePagesParams {
  appId: string;
  versionId: string;
  updates?: UpdatePageSpec[];
  /** Complete ordered list of the app's current page ids. */
  order?: string[];
}

export interface UpdatePagesResult {
  updated_fields: number;
  reordered: boolean;
  pages: Array<{
    page_id: string;
    name?: string;
    handle?: string;
    icon?: string;
    hidden: boolean;
    index?: number;
  }>;
}

export interface AddTableColumnParams {
  tableName: string;
  column: TableColumn;
  foreignKeys?: TableForeignKey[];
}

export interface InvokeDatasourceMethodParams {
  dataSourceId: string;
  method: string;
  environmentId?: string;
  args?: Record<string, unknown>;
}

/** A saved datasource's stored connection configuration, as ToolJet holds it for one environment.
 *
 *  `options` values carry `credential_id` references for secrets rather than plaintext — ToolJet
 *  dereferences them server-side. Nothing here is ever shown to the model. */
export interface DatasourceConnectionDetails {
  kind: string;
  /** Present only for marketplace plugins; core datasources have none and must omit it. */
  pluginId?: string;
  options: Record<string, unknown>;
}

export interface TestDatasourceConnectionParams {
  dataSourceId: string;
  kind: string;
  pluginId?: string;
  options: Record<string, unknown>;
  environmentId?: string;
}

/** ToolJet's own test-connection verdict. Unsupported plugins preserve the existing `failed`
 *  status for compatibility and add a structured `category`. */
export interface ConnectionTestResult {
  status: string;
  category?: string;
  supported?: boolean;
  message?: string;
  [key: string]: unknown;
}

export type EventSourceType = 'component' | 'data_query' | 'page' | 'table_column' | 'table_action';

/** One event handler: a trigger on a component, query, page, or component sub-element + an action. */
export interface EventSpec {
  /** The component, data query, or page id the event is attached to. Table sub-elements use the Table id. */
  sourceId: string;
  /** Source kind. Modern Table row buttons use table_column; table_action is legacy/deprecated. */
  sourceType: EventSourceType;
  /** Sub-element reference. Table Button columns use `<column key or name>::<button id>`. */
  ref?: string;
  /** The trigger event id, e.g. onClick, onDataQuerySuccess, onDataQueryFailure, onPageLoad. */
  trigger: string;
  /** The action: { actionId, ...params }, e.g. { actionId: 'run-query', queryId, queryName }. */
  action: Record<string, unknown>;
  /** Optional readable event name. A deterministic name is generated when omitted. */
  name?: string;
}

export interface CreateEventsParams {
  appId: string;
  versionId: string;
  events: EventSpec[];
  /** Persisted events from a fresh app summary, used to append deterministic indices. */
  existingEvents: AppSummary['events'];
}

/** Compact projection of one placed component — actual bound values only, no widget schema. */
export interface ComponentSummary {
  id: string;
  name?: string;
  type?: string;
  layouts?: unknown;
  /** Bound property values, e.g. { text: { value: 'Hello' } }. */
  properties?: Record<string, unknown>;
  styles?: Record<string, unknown>;
  /** Actual native input validation, not the widget's editor schema. */
  validation?: Record<string, unknown>;
  others?: Record<string, unknown>;
  parent?: string;
  /** Present for persisted header/footer children. Body children use the plain parent id. */
  slot_name?: ComponentSlotName;
}

/** Compact projection of a whole app — what an authoring agent needs, without the ~10× schema bloat
 *  that the raw GET /api/apps/:id carries (each component embeds its full widget property schema). */
export interface AppSummary {
  app_id: string;
  name?: string;
  version_id?: string;
  pages: Array<{
    id: string;
    name?: string;
    handle?: string;
    icon?: string;
    hidden?: boolean;
    index?: number;
    is_page_group?: boolean;
    page_group_id?: string;
    components: ComponentSummary[];
  }>;
  queries: Array<{ id: string; name?: string; kind?: string; data_source_id?: string; options?: unknown }>;
  events: Array<{ id: string; name?: string; sourceId?: string; target?: string; event?: unknown; index?: number }>;
}

export interface QuerySummary {
  id: string;
  name?: string;
  kind?: string;
  data_source_id?: string;
  datasource_settings_url?: string;
  options?: unknown;
}

/* There is deliberately no setAppPublic here. Publishing an app makes it world-readable, and nothing
   this server does is worth that: the render audit used to flip it to reach a private page and flip it
   back, which left the app public whenever the restore failed — a best-effort call with nobody watching.
   An app's visibility belongs to its owner, changed by them, in the product. Do not add it back. */
export interface ToolJetClient {
  listWorkspaces(): Promise<Workspace[]>;
  /** Toggle the app's public viewer (PUT /api/apps/:id/public). Used by the render audit when allowed. */
  useWorkspace(workspaceId: string): Promise<Workspace>;
  listWorkspaceApps(params?: { page?: number; searchText?: string }): Promise<Record<string, unknown>>;
  listWorkspaceUsers(params?: {
    page?: number;
    searchText?: string;
    status?: WorkspaceUserStatus;
  }): Promise<WorkspaceUsersPage>;
  listWorkspaceGroups(): Promise<WorkspaceGroup[]>;
  getWorkspaceGroup(groupId: string): Promise<WorkspaceGroup>;
  listWorkspaceGroupMembers(groupId: string): Promise<WorkspaceGroupMember[]>;
  createWorkspaceGroup(name: string): Promise<WorkspaceGroup>;
  renameWorkspaceGroup(groupId: string, name: string): Promise<void>;
  deleteWorkspaceGroup(groupId: string): Promise<void>;
  removeWorkspaceGroupMember(groupUserId: string): Promise<void>;
  updateWorkspaceGroupPermissions(groupId: string, permissions: Record<string, boolean>, allowRoleChange?: boolean): Promise<void>;
  duplicateWorkspaceGroup(groupId: string, options: Record<string, boolean>): Promise<WorkspaceGroup>;
  listWorkspaceGroupAccess(groupId: string): Promise<WorkspaceAccessRule[]>;
  listWorkspaceGroupResources(type: WorkspaceResourceType): Promise<Array<{ id: string; name: string }>>;
  writeWorkspaceGroupAccess(method: 'POST' | 'PUT' | 'DELETE', groupId: string, type: WorkspaceResourceType,
    ruleId?: string, body?: Record<string, unknown>): Promise<void>;
  inviteWorkspaceUser(params: InviteWorkspaceUserParams): Promise<void>;
  updateWorkspaceUser(organizationUserId: string, params: UpdateWorkspaceUserParams): Promise<void>;
  setWorkspaceUserArchived(organizationUserId: string, archived: boolean): Promise<void>;
  createApp(name: string): Promise<CreateAppResult>;
  renameApp(appId: string, versionId: string, name: string): Promise<void>;
  getApp(appId: string): Promise<any>;
  getAppSummary(appId: string): Promise<AppSummary>;
  listAppPermissionSubjects(appId: string): Promise<AppPermissionSubjects>;
  getAppPermission(
    appId: string,
    resourceType: AppPermissionResourceType,
    resourceId: string
  ): Promise<Array<Record<string, unknown>>>;
  setAppPermission(params: SetAppPermissionParams): Promise<Array<Record<string, unknown>>>;
  clearAppPermission(
    appId: string,
    resourceType: AppPermissionResourceType,
    resourceId: string
  ): Promise<void>;
  getAppSettings(appId: string, versionId: string): Promise<AppSettingsSnapshot>;
  listAppThemes(): Promise<AppTheme[]>;
  createAppTheme(params: CreateAppThemeParams): Promise<AppTheme>;
  setDefaultAppTheme(themeId: string, isDefault: boolean): Promise<void>;
  updateAppThemeDefinition(themeId: string, definition: Record<string, unknown>): Promise<void>;
  renameAppTheme(themeId: string, name: string): Promise<void>;
  deleteAppTheme(themeId: string): Promise<void>;
  updateAppSettings(params: UpdateAppSettingsParams): Promise<void>;
  getComponent(appId: string, componentId: string): Promise<ComponentSummary & { page_id: string }>;
  createPage(params: CreatePageParams): Promise<CreatePageResult>;
  createPages(params: CreatePagesParams): Promise<CreatePageResult[]>;
  updatePages(params: UpdatePagesParams): Promise<UpdatePagesResult>;
  deletePage(params: DeletePageParams): Promise<{ deleted: boolean }>;
  createEvents(params: CreateEventsParams): Promise<{ created: number }>;
  getDevelopmentEnvironmentId(): Promise<string>;
  listDatasources(versionId: string): Promise<Datasource[]>;
  listTables(): Promise<Array<{ id: string; table_name: string }>>;
  createTable(params: CreateTableParams): Promise<CreateTableResult>;
  createTables(params: CreateTablesParams): Promise<CreateTableResult[]>;
  addTableColumn(params: AddTableColumnParams): Promise<{ added: boolean }>;
  dropTableColumn(params: { tableName: string; columnName: string }): Promise<{ dropped: boolean }>;
  dropTable(params: { tableName: string }): Promise<{ dropped: boolean }>;
  getTableSchema(tableName: string): Promise<SchemaColumn[]>;
  insertRows(params: InsertRowsParams): Promise<{ processed_rows: number }>;
  insertRowsBatch(params: InsertRowsBatchParams): Promise<InsertRowsBatchResult[]>;
  createQuery(params: CreateQueryParams): Promise<CreateQueryResult>;
  createQueries(params: CreateQueriesParams): Promise<CreateQueryResult[]>;
  createComponent(params: CreateComponentParams): Promise<CreateComponentResult>;
  createComponents(params: CreateComponentsParams): Promise<Array<CreateComponentResult & { name: string }>>;
  updateComponents(params: UpdateComponentsParams): Promise<{ updated: number }>;
  deleteComponents(params: DeleteComponentsParams): Promise<{ deleted: number }>;
  updateLayouts(params: UpdateLayoutsParams): Promise<{ updated: number }>;
  updateQuery(params: UpdateQueryParams): Promise<{ query_id: string }>;
  updateQueryDatasource(params: { queryId: string; versionId: string; dataSourceId: string }): Promise<void>;
  deleteQuery(params: { queryId: string; versionId: string }): Promise<{ deleted: boolean }>;
  getQueries(versionId: string): Promise<QuerySummary[]>;
  getQuery(queryId: string, versionId: string): Promise<QuerySummary>;
  runQuery(params: { queryId: string; versionId: string; environmentId?: string }): Promise<RunQueryResult>;
  invokeDatasourceMethod(params: InvokeDatasourceMethodParams): Promise<RunQueryResult>;
  getDatasourceConnectionDetails(dataSourceId: string, environmentId?: string): Promise<DatasourceConnectionDetails>;
  getPluginSpec(pluginKind: string, specName: string): Promise<string>;
  testDatasourceConnection(params: TestDatasourceConnectionParams): Promise<ConnectionTestResult>;
  listEvents(params: { appId: string; versionId: string; sourceId?: string }): Promise<EventSummary[]>;
  updateEvents(params: UpdateEventsParams): Promise<{ updated: number }>;
  deleteEvent(params: { appId: string; versionId: string; eventId: string }): Promise<{ deleted: boolean }>;
}

/** A single component definition-or-rename update. Set EITHER `definition` (property/style edits,
 *  deep-merged; array values like Table columns / DropdownV2 options are REPLACED) OR name/parent — not
 *  both in one entry (ToolJet applies only one path). */
export interface UpdateComponentSpec {
  componentId: string;
  definition?: {
    properties?: Record<string, unknown>;
    styles?: Record<string, unknown>;
    validation?: Record<string, unknown>;
    general?: Record<string, unknown>;
    general_styles?: Record<string, unknown>;
    others?: Record<string, unknown>;
  };
  name?: string;
  parent?: string;
  slotName?: ComponentSlotName;
}
export interface UpdateComponentsParams {
  appId: string;
  versionId: string;
  pageId: string;
  updates: UpdateComponentSpec[];
}
export interface DeleteComponentsParams {
  appId: string;
  versionId: string;
  pageId: string;
  componentIds: string[];
}
export interface UpdateLayoutsParams {
  appId: string;
  versionId: string;
  pageId: string;
  layouts: Array<{
    componentId: string;
    desktop?: ComponentLayout;
    mobile?: ComponentLayout;
    parent?: string;
    slotName?: ComponentSlotName;
  }>;
}
export interface UpdateQueryParams {
  queryId: string;
  versionId: string;
  /** REPLACES the stored options wholesale — send the full options object, not a partial. */
  options: Record<string, unknown>;
  name?: string;
}
/** Run/preview result — `status` is 'ok' or 'failed' (HTTP is 200 either way); rows under `data`. */
export interface RunQueryResult {
  status: string;
  /** Structured by ToolJet's plugin boundary; never inferred from human-readable error text. */
  category?:
    | 'authentication'
    | 'connection'
    | 'schema_name'
    | 'timeout'
    | 'rate_limit'
    | 'transient'
    | 'query'
    | 'unknown';
  data?: unknown;
  message?: string;
  [k: string]: unknown;
}
export interface EventSummary {
  id: string;
  name?: string;
  index?: number;
  event?: unknown;
  sourceId?: string;
  target?: string;
}
export interface UpdateEventsParams {
  appId: string;
  versionId: string;
  /** For 'update': name + event required (name becomes null if omitted). For 'reorder': index used. */
  events: Array<{ eventId: string; name?: string; event?: Record<string, unknown>; index?: number }>;
  updateType?: 'update' | 'reorder';
}

/** An HTML error page (Cloudflare's 524 "A timeout occurred", an nginx 502) says nothing useful past
 *  its title, and a production build once carried 12 KB of Cloudflare markup into the model's context
 *  for every failed seed row. Keep the title, drop the markup, and cap plain bodies too. */
export function condenseErrorBody(detail: string, limit = 600): string {
  const text = String(detail ?? '');
  if (/<!doctype html|<html[\s>]/i.test(text)) {
    const title = /<title>([^<]*)<\/title>/i.exec(text)?.[1]?.trim();
    return `${title || 'HTML error page'} (HTML error page from the proxy, markup omitted)`;
  }
  return text.length > limit ? `${text.slice(0, limit)} …[${text.length - limit} more chars]` : text;
}

export class ToolJetHttpError extends Error {
  constructor(
    public readonly status: number,
    public readonly method: string,
    public readonly detail: string
  ) {
    super(`ToolJet ${method} failed (${status}): ${condenseErrorBody(detail)}`);
    this.name = 'ToolJetHttpError';
  }
}

function isPageHidden(page: any): boolean {
  return booleanBindingValue(page?.hidden?.value) === true;
}

function pageHiddenNeedsUpdate(page: any, expected: boolean): boolean {
  if (page?.hidden === undefined || page?.hidden === null) return expected;
  return booleanBindingValue(page.hidden?.value) !== expected ||
    !isCanonicalStaticBooleanBinding(page.hidden, expected);
}

async function assertOk(res: Response, method: string): Promise<void> {
  if (!res.ok) {
    const detail = await res.text();
    if (method === 'createTable' && res.status === 451) throw new TableQuotaError();
    throw new ToolJetHttpError(res.status, method, detail);
  }
}

// Friendly aliases → tjdb data types, so callers can say "string"/"number"/"bool".
export const TYPE_ALIASES: Record<string, string> = {
  string: 'character varying',
  text: 'character varying',
  varchar: 'character varying',
  int: 'integer',
  integer: 'integer',
  number: 'double precision',
  float: 'double precision',
  decimal: 'double precision',
  double: 'double precision',
  bigint: 'bigint',
  bool: 'boolean',
  boolean: 'boolean',
  timestamp: 'timestamp with time zone',
  datetime: 'timestamp with time zone',
  date: 'timestamp with time zone',
  json: 'jsonb',
  jsonb: 'jsonb',
  serial: 'serial',
};
export const normalizeType = (t: string): string => TYPE_ALIASES[t.trim().toLowerCase()] ?? t.trim().toLowerCase();
/** The data types ToolJet DB's create-table API accepts (server `TJDB` enum); anything else is a 400. */
export const TOOLJET_DB_DATA_TYPES = new Set([
  'character varying', 'integer', 'bigint', 'serial', 'double precision', 'boolean', 'timestamp with time zone', 'jsonb',
]);

function tableColumnDto(column: TableColumn): Record<string, unknown> {
  return {
    column_name: column.name,
    data_type: normalizeType(column.type),
    constraints_type: {
      is_not_null: !!column.notNull || !!column.primaryKey,
      is_primary_key: !!column.primaryKey,
      is_unique: !!column.unique || !!column.primaryKey,
    },
    ...(column.defaultValue !== undefined ? { column_default: column.defaultValue } : {}),
    ...(column.configurations ? { configurations: column.configurations } : {}),
  };
}

function tableForeignKeyDto(foreignKey: TableForeignKey): Record<string, unknown> {
  return {
    column_names: foreignKey.columns,
    referenced_table_name: foreignKey.referencedTable,
    referenced_column_names: foreignKey.referencedColumns,
    ...(foreignKey.onDelete ? { on_delete: foreignKey.onDelete } : {}),
    ...(foreignKey.onUpdate ? { on_update: foreignKey.onUpdate } : {}),
  };
}

export function createClient(auth: Auth, config: Config): ToolJetClient {
  let developmentEnvironmentIdPromise: Promise<string> | undefined;
  const datasourceManagementUrl = (workspaceSlug: string, datasourceId?: string) =>
    `${config.appUrl}/${encodeURIComponent(workspaceSlug)}/data-sources` +
    (datasourceId ? `/${encodeURIComponent(datasourceId)}` : '');

  async function listWorkspaceApps(
    params: { page?: number; searchText?: string } = {}
  ): Promise<Record<string, unknown>> {
    const query = new URLSearchParams({ page: String(params.page ?? 1), type: 'front-end' });
    if (params.searchText) query.set('searchKey', params.searchText);
    const res = await auth.authedFetch(`/api/apps?${query}`);
    await assertOk(res, 'listWorkspaceApps');
    return (await res.json()) as Record<string, unknown>;
  }

  async function listWorkspaceUsers(
    params: { page?: number; searchText?: string; status?: WorkspaceUserStatus } = {}
  ): Promise<WorkspaceUsersPage> {
    const query = new URLSearchParams({ page: String(params.page ?? 1) });
    if (params.searchText) query.set('searchText', params.searchText);
    if (params.status) query.set('status', params.status);
    const res = await auth.authedFetch(`/api/organization-users?${query}`);
    await assertOk(res, 'listWorkspaceUsers');
    return (await res.json()) as WorkspaceUsersPage;
  }

  const groupPath = '/api/v2/group-permissions';

  function workspaceGroup(value: any): WorkspaceGroup {
    if (!value || typeof value.id !== 'string' || typeof value.name !== 'string' ||
        !['default', 'custom'].includes(value.type)) {
      throw new Error('Unexpected workspace group response.');
    }
    const permissions = booleanFields(value, WORKSPACE_PERMISSION_KEYS);
    return { id: value.id, name: value.name, type: value.type,
      ...(typeof value.disabled === 'boolean' ? { disabled: value.disabled } : {}),
      ...(Object.keys(permissions).length ? { permissions } : {}) };

  }

  function booleanFields(value: any, keys: readonly string[]): Record<string, boolean> {
    return Object.fromEntries(keys.filter(key => typeof value?.[key] === 'boolean').map(key => [key, value[key]]));
  }

  async function updateWorkspaceGroupPermissions(groupId: string, permissions: Record<string, boolean>, allowRoleChange = false) {
    const res = await auth.authedFetch(`${groupPath}/${groupId}`, { method: 'PUT',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...permissions, allowRoleChange }) });
    await assertOk(res, 'updateWorkspaceGroupPermissions');
  }

  async function duplicateWorkspaceGroup(groupId: string, options: Record<string, boolean>): Promise<WorkspaceGroup> {
    const res = await auth.authedFetch(`${groupPath}/${groupId}/duplicate`, { method: 'POST',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(options) });
    await assertOk(res, 'duplicateWorkspaceGroup');
    const created = await res.json();
    if (typeof created?.id !== 'string') throw new Error('Unexpected duplicated group response.');
    return getWorkspaceGroup(created.id);
  }

  async function listWorkspaceGroupResources(type: WorkspaceResourceType): Promise<Array<{ id: string; name: string }>> {
    const res = await auth.authedFetch(`${groupPath}/granular-permissions/addable-${type === 'data_source' ? 'data-sources' : 'apps'}`);
    await assertOk(res, 'listWorkspaceGroupResources');
    const items = await res.json();
    if (!Array.isArray(items)) throw new Error('Unexpected group resources response.');
    const appType = { app: 'front-end', module: 'module', workflow: 'workflow' };
    return items.filter(item => type === 'data_source' || item.type === appType[type])
      .map(item => {
        if (typeof item.id !== 'string' || typeof item.name !== 'string') throw new Error('Unexpected group resource.');
        return { id: item.id, name: item.name };
      });
  }

  async function listWorkspaceGroupAccess(groupId: string): Promise<WorkspaceAccessRule[]> {
    const res = await auth.authedFetch(`${groupPath}/${groupId}/granular-permissions`);
    await assertOk(res, 'listWorkspaceGroupAccess');
    const items = await res.json();
    if (!Array.isArray(items)) throw new Error('Unexpected granular permissions response.');
    return items.map(item => {
      if (!item || (item.id != null && typeof item.id !== 'string') || typeof item.name !== 'string' || typeof item.isAll !== 'boolean' ||
          !['app', 'module', 'workflow', 'data_source'].includes(item.type)) throw new Error('Unexpected granular permission.');
      // Restricted plans return synthetic, all-resource rules without persisted IDs.
      // Expose their effective permissions, but never invent an ID usable for a mutation.
      const synthetic = item.id == null;
      if (synthetic && !item.isAll) throw new Error('Unexpected granular permission without a persisted ID.');
      const ds = item.type === 'data_source';
      const detail = ds ? item.dataSourcesGroupPermission : item.appsGroupPermissions;
      return { ...(synthetic ? { read_only: true,
          read_only_reason: 'These effective permissions are supplied by the current license/plan and cannot be edited.' } : { id: item.id }),
        name: item.name, type: item.type, is_all: item.isAll,
        actions: booleanFields(detail, workspaceAccessKeys(item.type)),
        resources: (detail?.[ds ? 'groupDataSources' : 'groupApps'] ?? []).map((link: any) => {
          const resource = link[ds ? 'dataSource' : 'app'];
          if (!resource || typeof resource.id !== 'string' || typeof resource.name !== 'string' || typeof link.id !== 'string') {
            throw new Error('Unexpected granular permission resource.');
          }
          return { id: resource.id, name: resource.name, membership_id: link.id };
        }) };
    });
  }

  async function writeWorkspaceGroupAccess(method: 'POST' | 'PUT' | 'DELETE', groupId: string,
    type: WorkspaceResourceType, ruleId?: string, body?: Record<string, unknown>): Promise<void> {
    // The UI routes workflow/module payloads through the data-source endpoint as well.
    const route = type === 'app' ? 'app' : 'data-source';
    const path = method === 'POST' ? `${groupId}/granular-permissions/${route}` : `granular-permissions/${route}/${ruleId}`;
    const res = await auth.authedFetch(`${groupPath}/${path}`, { method,
      ...(body ? { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}) });
    await assertOk(res, 'writeWorkspaceGroupAccess');
  }

  async function listWorkspaceGroups(): Promise<WorkspaceGroup[]> {
    const res = await auth.authedFetch(groupPath);
    await assertOk(res, 'listWorkspaceGroups');
    const data = await res.json();
    if (!Array.isArray(data.groupPermissions)) throw new Error('Unexpected workspace groups response.');
    return data.groupPermissions.map(workspaceGroup);
  }

  async function getWorkspaceGroup(groupId: string): Promise<WorkspaceGroup> {
    const res = await auth.authedFetch(`${groupPath}/${encodeURIComponent(groupId)}`);
    await assertOk(res, 'getWorkspaceGroup');
    return workspaceGroup((await res.json()).group);
  }

  async function listWorkspaceGroupMembers(groupId: string): Promise<WorkspaceGroupMember[]> {
    const res = await auth.authedFetch(`${groupPath}/${encodeURIComponent(groupId)}/users`);
    await assertOk(res, 'listWorkspaceGroupMembers');
    const data = await res.json();
    if (!Array.isArray(data)) throw new Error('Unexpected workspace group members response.');
    return data.map((entry: any) => {
      if (typeof entry?.id !== 'string' || typeof entry?.userId !== 'string') {
        throw new Error('Unexpected workspace group member response.');
      }
      return { group_user_id: entry.id, user_id: entry.userId,
        email: entry.user?.email, first_name: entry.user?.firstName, last_name: entry.user?.lastName };
    });
  }

  async function createWorkspaceGroup(name: string): Promise<WorkspaceGroup> {
    const res = await auth.authedFetch(groupPath, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }),
    });
    await assertOk(res, 'createWorkspaceGroup');
    // TypeORM's insert response omits the database-default group type. Read the persisted entity.
    const created = await res.json();
    if (typeof created?.id !== 'string') throw new Error('Create group response did not include an id.');
    return getWorkspaceGroup(created.id);
  }

  async function renameWorkspaceGroup(groupId: string, name: string): Promise<void> {
    const res = await auth.authedFetch(`${groupPath}/${encodeURIComponent(groupId)}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }),
    });
    await assertOk(res, 'renameWorkspaceGroup');
  }

  async function deleteWorkspaceGroup(groupId: string): Promise<void> {
    const res = await auth.authedFetch(`${groupPath}/${encodeURIComponent(groupId)}`, { method: 'DELETE' });
    await assertOk(res, 'deleteWorkspaceGroup');
  }

  async function removeWorkspaceGroupMember(groupUserId: string): Promise<void> {
    const res = await auth.authedFetch(`${groupPath}/users/${encodeURIComponent(groupUserId)}`, { method: 'DELETE' });
    await assertOk(res, 'removeWorkspaceGroupMember');
  }

  async function inviteWorkspaceUser(params: InviteWorkspaceUserParams): Promise<void> {
    const res = await auth.authedFetch('/api/organization-users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: params.email,
        role: params.role,
        ...(params.firstName !== undefined ? { firstName: params.firstName } : {}),
        ...(params.lastName !== undefined ? { lastName: params.lastName } : {}),
        ...(params.groupIds !== undefined ? { groups: params.groupIds } : {}),
      }),
    });
    await assertOk(res, 'inviteWorkspaceUser');
  }

  async function updateWorkspaceUser(
    organizationUserId: string,
    params: UpdateWorkspaceUserParams
  ): Promise<void> {
    const res = await auth.authedFetch(`/api/organization-users/${encodeURIComponent(organizationUserId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...(params.firstName !== undefined ? { firstName: params.firstName } : {}),
        ...(params.lastName !== undefined ? { lastName: params.lastName } : {}),
        ...(params.role !== undefined ? { role: params.role } : {}),
        addGroups: params.addGroupIds ?? [],
        ...(params.userMetadata !== undefined ? { userMetadata: params.userMetadata } : {}),
      }),
    });
    await assertOk(res, 'updateWorkspaceUser');
  }

  async function setWorkspaceUserArchived(organizationUserId: string, archived: boolean): Promise<void> {
    const action = archived ? 'archive' : 'unarchive';
    const res = await auth.authedFetch(
      `/api/organization-users/${encodeURIComponent(organizationUserId)}/${action}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
      }
    );
    await assertOk(res, `${action}WorkspaceUser`);
  }

  async function getApp(appId: string): Promise<any> {
    const res = await auth.authedFetch(`/api/apps/${appId}`);
    await assertOk(res, 'getApp');
    return res.json();
  }

  // In GET /api/apps/:id, each placed component lives at pages[].components[<id>] as
  // { component: { name, component: <type>, definition: { properties, styles, others } }, layouts }.
  // `component.definition` holds the ACTUAL bound values; `component.properties`/`styles` is the full
  // widget schema (the bulk). Project to values-only.
  function projectComponent(id: string, entry: any): ComponentSummary {
    const c = entry?.component ?? {};
    const def = c.definition ?? {};
    const persistedParent = typeof c.parent === 'string' ? c.parent : undefined;
    const decodedParent = persistedParent ? decodeComponentParent(persistedParent) : undefined;
    return {
      id,
      name: c.name,
      type: c.component,
      layouts: entry?.layouts,
      properties: def.properties,
      styles: def.styles,
      ...(def.validation !== undefined ? { validation: def.validation } : {}),
      others: def.others,
      ...(persistedParent ? { parent: persistedParent } : {}),
      ...(decodedParent && decodedParent.slotName !== 'body' ? { slot_name: decodedParent.slotName } : {}),
    };
  }

  async function getAppSummary(appId: string): Promise<AppSummary> {
    const full = await getApp(appId);
    const pages = (full.pages ?? []).map((p: any) => ({
      id: p.id,
      name: p.name,
      handle: p.handle,
      icon: p.icon,
      hidden: isPageHidden(p),
      ...(typeof p.index === 'number' ? { index: p.index } : {}),
      ...(typeof p.isPageGroup === 'boolean' ? { is_page_group: p.isPageGroup } : {}),
      ...(typeof p.pageGroupId === 'string' ? { page_group_id: p.pageGroupId } : {}),
      components: Object.entries(p.components ?? {}).map(([id, entry]) => projectComponent(id, entry)),
    }));
    const queries = (full.data_queries ?? []).map((q: any) => ({
      id: q.id,
      name: q.name,
      kind: q.kind,
      data_source_id: q.data_source_id,
      options: q.options,
    }));
    const events = (full.events ?? []).map((e: any) => ({
      id: e.id,
      name: e.name,
      sourceId: e.sourceId,
      target: e.target,
      event: e.event,
      ...(typeof e.index === 'number' ? { index: e.index } : {}),
    }));
    return { app_id: full.id, name: full.name, version_id: full.editing_version?.id, pages, queries, events };
  }

  function appPermissionPath(
    appId: string,
    resourceType: AppPermissionResourceType,
    resourceId: string
  ): string {
    const segment =
      resourceType === 'page' ? 'pages' : resourceType === 'query' ? 'queries' : 'components';
    return `/api/app-permissions/${encodeURIComponent(appId)}/${segment}/${encodeURIComponent(resourceId)}`;
  }

  async function listAppPermissionSubjects(appId: string): Promise<AppPermissionSubjects> {
    const app = encodeURIComponent(appId);
    const [usersResponse, groupsResponse] = await Promise.all([
      auth.authedFetch(`/api/app-permissions/${app}/pages/users`),
      auth.authedFetch(`/api/app-permissions/${app}/pages/user-groups`),
    ]);
    await assertOk(usersResponse, 'listAppPermissionSubjects users');
    await assertOk(groupsResponse, 'listAppPermissionSubjects groups');
    const users = await usersResponse.json();
    const groups = await groupsResponse.json();
    if (!Array.isArray(users) || !Array.isArray(groups)) {
      throw new Error('ToolJet listAppPermissionSubjects failed: expected array responses.');
    }
    return {
      users: users.map((user: any) => ({
        id: user.id,
        name: [user.firstName, user.lastName].filter(Boolean).join(' ') || undefined,
        email: user.email,
      })),
      groups: groups.map((group: any) => ({
        id: group.id,
        name: group.name,
        ...(typeof group.count === 'number' ? { count: group.count } : {}),
      })),
    };
  }

  async function getAppPermission(
    appId: string,
    resourceType: AppPermissionResourceType,
    resourceId: string
  ): Promise<Array<Record<string, unknown>>> {
    const res = await auth.authedFetch(appPermissionPath(appId, resourceType, resourceId));
    await assertOk(res, 'getAppPermission');
    const body = await res.json();
    if (!Array.isArray(body)) {
      throw new Error('ToolJet getAppPermission failed: expected an array response.');
    }
    return body as Array<Record<string, unknown>>;
  }

  async function setAppPermission(
    params: SetAppPermissionParams
  ): Promise<Array<Record<string, unknown>>> {
    const path = appPermissionPath(params.appId, params.resourceType, params.resourceId);
    const existing = await getAppPermission(params.appId, params.resourceType, params.resourceId);
    const body =
      params.accessType === 'users'
        ? { type: 'SINGLE', users: params.subjectIds }
        : { type: 'GROUP', groups: params.subjectIds };
    const res = await auth.authedFetch(path, {
      method: existing.length ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    await assertOk(res, 'setAppPermission');
    return getAppPermission(params.appId, params.resourceType, params.resourceId);
  }

  async function clearAppPermission(
    appId: string,
    resourceType: AppPermissionResourceType,
    resourceId: string
  ): Promise<void> {
    const existing = await getAppPermission(appId, resourceType, resourceId);
    if (!existing.length) return;
    const res = await auth.authedFetch(appPermissionPath(appId, resourceType, resourceId), {
      method: 'DELETE',
    });
    await assertOk(res, 'clearAppPermission');
  }

  async function getAppSettings(appId: string, versionId: string): Promise<AppSettingsSnapshot> {
    // GET /api/apps/:id deep-snake-cases free-form settings keys (for example disableMenu becomes
    // disable_menu), which makes a successful settings write look absent during readback. The native
    // version endpoint preserves the page/global settings blobs in the camelCase shape ToolJet's
    // settings editor and update endpoint use.
    const res = await auth.authedFetch(
      `/api/v2/apps/${encodeURIComponent(appId)}/versions/${encodeURIComponent(versionId)}`
    );
    await assertOk(res, 'getAppSettings');
    const app = await res.json();
    const editingVersion = app.editing_version ?? app.editingVersion;
    if (!editingVersion || editingVersion.id !== versionId) {
      throw new Error(
        `ToolJet getAppSettings failed: version "${versionId}" is not the current editing version for app "${appId}".`
      );
    }
    return {
      app_id: appId,
      version_id: versionId,
      global_settings: editingVersion.global_settings ?? editingVersion.globalSettings ?? {},
      page_settings: editingVersion.page_settings ?? editingVersion.pageSettings ?? {},
    };
  }

  async function listAppThemes(): Promise<AppTheme[]> {
    const res = await auth.authedFetch('/api/themes');
    await assertOk(res, 'listAppThemes');
    const body = await res.json();
    if (!Array.isArray(body)) throw new Error('ToolJet listAppThemes failed: expected an array response.');
    return body as AppTheme[];
  }

  async function createAppTheme(params: CreateAppThemeParams): Promise<AppTheme> {
    const res = await auth.authedFetch('/api/themes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: params.name,
        organizationId: await auth.getOrganizationId(),
        definition: params.definition,
        isDefault: params.isDefault ?? false,
      }),
    });
    await assertOk(res, 'createAppTheme');
    return (await res.json()) as AppTheme;
  }

  async function updateAppTheme(
    themeId: string,
    field: 'default' | 'definition' | 'name',
    body: Record<string, unknown>,
    operation: string
  ): Promise<void> {
    const res = await auth.authedFetch(`/api/themes/${encodeURIComponent(themeId)}/${field}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    await assertOk(res, operation);
  }

  async function setDefaultAppTheme(themeId: string, isDefault: boolean): Promise<void> {
    await updateAppTheme(themeId, 'default', { isDefault }, 'setDefaultAppTheme');
  }

  async function updateAppThemeDefinition(themeId: string, definition: Record<string, unknown>): Promise<void> {
    await updateAppTheme(themeId, 'definition', { definition }, 'updateAppThemeDefinition');
  }

  async function renameAppTheme(themeId: string, name: string): Promise<void> {
    await updateAppTheme(themeId, 'name', { name }, 'renameAppTheme');
  }

  async function deleteAppTheme(themeId: string): Promise<void> {
    const res = await auth.authedFetch(`/api/themes/${encodeURIComponent(themeId)}`, { method: 'DELETE' });
    await assertOk(res, 'deleteAppTheme');
  }

  async function updateAppSettings(params: UpdateAppSettingsParams): Promise<void> {
    const body: Record<string, unknown> = {
      ...(params.globalSettings ? { globalSettings: params.globalSettings } : {}),
      ...(params.pageSettings ? { pageSettings: params.pageSettings } : {}),
      ...(params.showViewerNavigation !== undefined
        ? { showViewerNavigation: params.showViewerNavigation }
        : {}),
    };
    if (!Object.keys(body).length) {
      throw new Error('ToolJet updateAppSettings failed: provide at least one setting.');
    }
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      }
    );
    await assertOk(res, 'updateAppSettings');
  }

  async function getComponent(
    appId: string,
    componentId: string
  ): Promise<ComponentSummary & { page_id: string }> {
    const full = await getApp(appId);
    for (const p of full.pages ?? []) {
      const entry = (p.components ?? {})[componentId];
      if (entry) return { ...projectComponent(componentId, entry), page_id: p.id };
    }
    throw new Error(
      `ToolJet getComponent failed: component ${componentId} not found in app ${appId}`
    );
  }

  async function listWorkspaces(): Promise<Workspace[]> {
    return auth.listWorkspaces();
  }

  async function useWorkspace(workspaceId: string): Promise<Workspace> {
    return auth.switchWorkspace(workspaceId);
  }

  async function createApp(name: string): Promise<CreateAppResult> {
    // A taken name is a 409 that used to bounce back to the model, which then spent a turn (and at
    // max reasoning effort, a minute) inventing "… 2026" or "… A9". Every build in a shared workspace
    // paid it twice. Append a counter ourselves; the model sees the name it got in the result.
    let createRes: Response | undefined;
    let finalName = name;
    for (let attempt = 1; attempt <= 6; attempt++) {
      finalName = attempt === 1 ? name : `${name} ${attempt}`;
      createRes = await auth.authedFetch('/api/apps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: finalName, type: 'front-end' }),
      });
      if (createRes.status !== 409) break;
    }
    await assertOk(createRes!, 'createApp');
    const created = (await createRes!.json()) as { id: string; slug?: string };

    const app = await getApp(created.id);
    const versionId: string = app.editing_version.id;
    const versionName: string = app.editing_version.name ?? 'v1';
    const pages: Array<{ id: string; name: string; handle?: string }> = app.pages ?? [];
    const homePage = pages.find((p) => p.name === 'Home') ?? pages[0];
    if (!homePage) {
      throw new Error('ToolJet createApp failed: app has no pages');
    }

    // Editor URL is /<workspace-slug>/apps/<app-slug> — the workspace segment is required.
    const orgSlug = await auth.getOrganizationSlug();
    const appSlug = created.slug ?? created.id;

    const editorUrl = `${config.appUrl}/${orgSlug}/apps/${appSlug}`;
    const homeHandle = homePage.handle ?? 'home';
    const viewerUrl =
      `${config.appUrl}/applications/${created.id}/${encodeURIComponent(homeHandle)}` +
      `?env=development&version=${encodeURIComponent(versionName)}`;

    return {
      app_id: created.id,
      version_id: versionId,
      home_page_id: homePage.id,
      app_url: editorUrl,
      editor_url: editorUrl,
      viewer_url: viewerUrl,
      datasources_url: datasourceManagementUrl(orgSlug),
    };
  }

  async function renameApp(appId: string, versionId: string, name: string): Promise<void> {
    const res = await auth.authedFetch(`/api/apps/${appId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app: { name, editingVersionId: versionId } }),
    });
    await assertOk(res, 'renameApp');
    const refreshed = await getApp(appId);
    if (refreshed.name !== name) {
      throw new Error(`ToolJet renameApp failed: expected name "${name}", received "${String(refreshed.name)}".`);
    }
  }

  async function listTables(): Promise<Array<{ id: string; table_name: string }>> {
    const orgId = await auth.getOrganizationId();
    const res = await auth.authedFetch(`/api/tooljet-db/organizations/${orgId}/tables`);
    await assertOk(res, 'listTables');
    const body = (await res.json()) as { result: Array<{ id: string; table_name: string }> };
    return body.result ?? [];
  }

  async function createPages(params: CreatePagesParams): Promise<CreatePageResult[]> {
    // Validate every supplied icon before reads/writes: direct/hybrid callers can bypass Zod.
    for (const page of params.pages) {
      if (page.icon !== undefined) assertPageIcon(page.icon, `Page "${page.name}"`);
    }
    // Page order = append after existing pages. Precompute ids/indexes and create the batch concurrently.
    const app = await getApp(params.appId);
    const existingPages = app.pages ?? [];
    const highestPersistedIndex = existingPages.reduce(
      (highest: number, page: any) =>
        typeof page.index === 'number' && Number.isFinite(page.index)
          ? Math.max(highest, page.index)
          : highest,
      0
    );
    // ToolJet's initial Home page starts at index 1. Older payloads can omit index, so fall back
    // to the current page count instead of reusing an occupied index.
    const startIndex = Math.max(highestPersistedIndex, existingPages.length) + 1;
    const handleOf = (name: string): string =>
      name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 50) || 'page';
    const existingNames = new Set((app.pages ?? []).map((page: any) => String(page.name).toLowerCase()));
    const existingHandles = new Set((app.pages ?? []).map((page: any) => String(page.handle).toLowerCase()));
    const seenNames = new Set<string>();
    const seenHandles = new Set<string>();
    const entries = params.pages.map((page, offset) => {
      const nameKey = page.name.toLowerCase();
      const handle = handleOf(page.name);
      if (existingNames.has(nameKey) || seenNames.has(nameKey)) {
        throw new Error(`ToolJet createPages failed: duplicate page name "${page.name}".`);
      }
      if (existingHandles.has(handle) || seenHandles.has(handle)) {
        throw new Error(`ToolJet createPages failed: page "${page.name}" resolves to duplicate handle "${handle}".`);
      }
      seenNames.add(nameKey);
      seenHandles.add(handle);
      return { ...page, id: randomUUID(), handle, index: startIndex + offset };
    });

    const createSettled = await Promise.allSettled(entries.map(async (page) => {
      const res = await auth.authedFetch(`/api/v2/apps/${params.appId}/versions/${params.versionId}/pages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: page.id,
          name: page.name,
          handle: page.handle,
          index: page.index,
          ...(page.icon ? { icon: page.icon } : {}),
        }),
      });
      await assertOk(res, `createPages "${page.name}"`);
      return page;
    }));
    const createdEntries = createSettled.flatMap((result) => result.status === 'fulfilled' ? [result.value] : []);
    const failures = createSettled.flatMap((result, index) => result.status === 'rejected'
      ? [`${entries[index]!.name}: ${result.reason instanceof Error ? result.reason.message : String(result.reason)}`]
      : []);

    // ToolJet's create-page service ignores `icon` and `hidden`, even though the DTO accepts them.
    // Persist them via the update route — which applies a single-field diff (a diff with >1 key throws
    // "Can not update multiple pages"), so send ONE field per call. Boolean bindable fields use ToolJet's
    // canonical expression wrapper even when fxActive is false. Read back so a silent drop cannot look successful.
    const metadataTasks = createdEntries.flatMap((page) => [
      ...(page.icon
        ? [{ page, field: 'icon', promise: persistFieldForPage(page.id, 'icon', page.icon, `createPages "${page.name}" icon update`) }]
        : []),
      ...(page.hidden
        ? [{ page, field: 'hidden', promise: persistFieldForPage(page.id, 'hidden', staticBooleanBinding(true), `createPages "${page.name}" hidden update`) }]
        : []),
    ]);
    const metadataSettled = await Promise.allSettled(metadataTasks.map((task) => task.promise));
    failures.push(...metadataSettled.flatMap((result, index) => result.status === 'rejected'
      ? [`${metadataTasks[index]!.page.name} ${metadataTasks[index]!.field}: ${result.reason instanceof Error ? result.reason.message : String(result.reason)}`]
      : []));

    let persistedById = new Map<string, any>();
    if (createdEntries.some((page) => page.icon || page.hidden)) {
      try {
        const refreshed = await getApp(params.appId);
        persistedById = new Map((refreshed.pages ?? []).map((page: any) => [page.id, page]));
        for (const entry of createdEntries) {
          const page = persistedById.get(entry.id);
          if (entry.icon && page?.icon !== entry.icon) {
            failures.push(`page "${entry.name}" exists, but sidebar icon "${entry.icon}" did not persist`);
          }
          if (entry.hidden && !isPageHidden(page)) {
            failures.push(`page "${entry.name}" exists, but hidden-from-sidebar did not persist`);
          }
        }
      } catch (error) {
        failures.push(`page metadata readback: ${error instanceof Error ? error.message : String(error)}`);
      }
    }

    const completed = createdEntries.map((page) => ({
      page_id: page.id,
      name: page.name,
      index: page.index,
      ...(persistedById.get(page.id)?.icon ? { icon: persistedById.get(page.id).icon as string } : {}),
      ...(isPageHidden(persistedById.get(page.id)) ? { hidden: true } : {}),
    }));
    if (failures.length) throw new PartialWriteError('createPages', completed, failures);
    return completed;

    async function persistFieldForPage(pageId: string, field: string, value: unknown, label: string): Promise<void> {
      const r = await auth.authedFetch(`/api/v2/apps/${params.appId}/versions/${params.versionId}/pages`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pageId, diff: { [field]: value } }),
      });
      await assertOk(r, label);
    }
  }

  async function createPage(params: CreatePageParams): Promise<CreatePageResult> {
    const [page] = await createPages({
      appId: params.appId,
      versionId: params.versionId,
      pages: [{ name: params.name, icon: params.icon, hidden: params.hidden }],
    });
    return page;
  }

  async function updatePages(params: UpdatePagesParams): Promise<UpdatePagesResult> {
    const updates = params.updates ?? [];
    for (const update of updates) {
      if (update.icon !== undefined) assertPageIcon(update.icon, `Page "${update.pageId}"`);
    }
    const order = params.order;
    if (!updates.length && !order) {
      throw new Error('ToolJet updatePages failed: provide at least one page update or a complete page order.');
    }

    const app = await getApp(params.appId);
    const pages: any[] = app.pages ?? [];
    const pagesById = new Map(pages.map((page) => [String(page.id), page]));
    const editingVersion = app.editing_version ?? app.editingVersion ?? {};
    const homePageId = String(
      editingVersion.home_page_id ?? editingVersion.homePageId ?? app.home_page_id ?? app.homePageId ?? ''
    );
    const seenUpdateIds = new Set<string>();
    for (const update of updates) {
      if (!pagesById.has(update.pageId)) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" does not exist.`);
      }
      if (seenUpdateIds.has(update.pageId)) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" is updated more than once.`);
      }
      seenUpdateIds.add(update.pageId);
      if (update.name === undefined && update.icon === undefined && update.hidden === undefined) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" has no changed fields.`);
      }
      if (update.name !== undefined && !update.name.trim()) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" has an empty name.`);
      }
      if (update.icon !== undefined && !update.icon.trim()) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" has an empty icon.`);
      }
      const current = pagesById.get(update.pageId);
      if (update.hidden === true && (update.pageId === homePageId || (!homePageId && current?.handle === 'home'))) {
        throw new Error('ToolJet updatePages failed: the Home page cannot be hidden from navigation.');
      }
    }

    const requestedNames = new Map(updates.map((update) => [update.pageId, update.name]));
    const finalNames = pages.map((page) => {
      const kind = page.isPageGroup === true ? 'group' : 'page';
      const name = String(requestedNames.get(String(page.id)) ?? page.name ?? '').trim().toLowerCase();
      return `${kind}:${name}`;
    });
    if (new Set(finalNames).size !== finalNames.length) {
      throw new Error('ToolJet updatePages failed: page names must remain unique.');
    }

    if (order) {
      const orderedIds = new Set(order);
      if (order.length !== pages.length || orderedIds.size !== order.length) {
        throw new Error('ToolJet updatePages failed: order must contain every current page id exactly once.');
      }
      const missing = pages.filter((page) => !orderedIds.has(String(page.id))).map((page) => page.id);
      if (missing.length || order.some((pageId) => !pagesById.has(pageId))) {
        throw new Error('ToolJet updatePages failed: order must contain every current page id exactly once.');
      }
    }

    const fieldUpdates: Array<{ pageId: string; field: string; value: unknown }> = [];
    for (const update of updates) {
      const current = pagesById.get(update.pageId);
      if (update.name !== undefined && update.name !== current.name) {
        fieldUpdates.push({ pageId: update.pageId, field: 'name', value: update.name });
      }
      if (update.icon !== undefined && update.icon !== current.icon) {
        fieldUpdates.push({ pageId: update.pageId, field: 'icon', value: update.icon });
      }
      if (update.hidden !== undefined && pageHiddenNeedsUpdate(current, update.hidden)) {
        fieldUpdates.push({ pageId: update.pageId, field: 'hidden', value: staticBooleanBinding(update.hidden) });
      }
    }

    // ToolJet's page update service accepts one changed field per request.
    await Promise.all(fieldUpdates.map(async ({ pageId, field, value }) => {
      const response = await auth.authedFetch(
        `/api/v2/apps/${params.appId}/versions/${params.versionId}/pages`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pageId, diff: { [field]: value } }),
        }
      );
      await assertOk(response, `updatePages ${pageId}.${field}`);
    }));

    if (order) {
      const diff = Object.fromEntries(order.map((pageId, index) => [pageId, { index }]));
      const response = await auth.authedFetch(
        `/api/v2/apps/${params.appId}/versions/${params.versionId}/pages/reorder`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ diff }),
        }
      );
      await assertOk(response, 'updatePages reorder');
    }

    const refreshed = await getApp(params.appId);
    const refreshedPages: any[] = refreshed.pages ?? [];
    const refreshedById = new Map(refreshedPages.map((page) => [String(page.id), page]));
    for (const update of updates) {
      const page = refreshedById.get(update.pageId);
      if (update.name !== undefined && page?.name !== update.name) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" name did not persist.`);
      }
      if (update.icon !== undefined && page?.icon !== update.icon) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" icon did not persist.`);
      }
      if (update.hidden !== undefined && isPageHidden(page) !== update.hidden) {
        throw new Error(`ToolJet updatePages failed: page "${update.pageId}" hidden state did not persist.`);
      }
    }
    if (order) {
      for (const [index, pageId] of order.entries()) {
        if (refreshedById.get(pageId)?.index !== index) {
          throw new Error(`ToolJet updatePages failed: page order did not persist at index ${index}.`);
        }
      }
    }

    return {
      updated_fields: fieldUpdates.length,
      reordered: order !== undefined,
      pages: refreshedPages
        .slice()
        .sort((left, right) => (left.index ?? 0) - (right.index ?? 0))
        .map((page) => ({
          page_id: page.id,
          name: page.name,
          handle: page.handle,
          icon: page.icon,
          hidden: isPageHidden(page),
          ...(typeof page.index === 'number' ? { index: page.index } : {}),
        })),
    };
  }

  async function createEvents(params: CreateEventsParams): Promise<{ created: number }> {
    // Each event → { event: { eventId: <trigger>, ref?, ...action }, eventType, attachedTo, index }.
    // index is ordered independently for each source; component sub-elements also scope it by ref,
    // matching EventManager's per-button ordering for Table column buttons.
    const indexBySource: Record<string, number> = {};
    for (const existing of params.existingEvents) {
      if (!existing.sourceId || !existing.target || typeof existing.index !== 'number') continue;
      const raw = existing.event && typeof existing.event === 'object' && !Array.isArray(existing.event)
        ? existing.event as Record<string, unknown>
        : undefined;
      const ref = typeof raw?.ref === 'string' ? raw.ref : '';
      const sourceKey = `${existing.target}:${existing.sourceId}:${ref}`;
      indexBySource[sourceKey] = Math.max(indexBySource[sourceKey] ?? 0, existing.index + 1);
    }
    const events = params.events.map((e) => {
      const sourceKey = `${e.sourceType}:${e.sourceId}:${e.ref ?? ''}`;
      const index = indexBySource[sourceKey] ?? 0;
      indexBySource[sourceKey] = index + 1;
      const action =
        e.action.actionId === 'control-component' && e.action.componentSpecificActionParams === undefined
          ? { ...e.action, componentSpecificActionParams: [] }
          : e.action;
      return {
        // name is NOT NULL server-side (the DTO marks it optional but the column requires it).
        name: e.name ?? `${e.trigger} → ${(e.action.actionId as string) ?? 'action'}`,
        event: { eventId: e.trigger, ...(e.ref ? { ref: e.ref } : {}), ...action },
        eventType: e.sourceType,
        attachedTo: e.sourceId,
        index,
      };
    });
    const res = await auth.authedFetch(`/api/v2/apps/${params.appId}/versions/${params.versionId}/events/bulk`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ events }),
    });
    await assertOk(res, 'createEvents');
    return { created: events.length };
  }

  async function getDevelopmentEnvironmentId(): Promise<string> {
    if (!developmentEnvironmentIdPromise) {
      developmentEnvironmentIdPromise = (async () => {
        const res = await auth.authedFetch('/api/app-environments');
        await assertOk(res, 'getDevelopmentEnvironmentId');
        const body = await res.json();
        const envs: Array<{ id: string; name: string }> = Array.isArray(body) ? body : body.environments;
        const dev = envs.find((e) => e.name === 'development');
        if (!dev) {
          throw new Error('ToolJet getDevelopmentEnvironmentId failed: no development environment found');
        }
        return dev.id;
      })().catch((error) => {
        developmentEnvironmentIdPromise = undefined;
        throw error;
      });
    }
    return developmentEnvironmentIdPromise;
  }

  async function listDatasources(versionId: string): Promise<Datasource[]> {
    const [orgId, orgSlug, envId] = await Promise.all([
      auth.getOrganizationId(),
      auth.getOrganizationSlug(),
      getDevelopmentEnvironmentId(),
    ]);
    // The route retains versionId for API compatibility, but ToolJet resolves workspace/global sources
    // available to this user + environment; a new app does not need a per-app datasource-link operation.
    const res = await auth.authedFetch(
      `/api/data-sources/${orgId}/environments/${envId}/versions/${versionId}`
    );
    await assertOk(res, 'listDatasources');
    // The API returns fully-hydrated datasource objects (options, plugin, scope, …) — ~22KB in a
    // typical app. The agent only needs identity + a repair URL; strip the rest at runtime (the TS type does
    // NOT strip fields on its own).
    const body = (await res.json()) as { data_sources: Array<Datasource & Record<string, unknown>> };
    return body.data_sources.map((d) => ({
      id: d.id,
      name: d.name,
      kind: d.kind,
      settings_url: datasourceManagementUrl(orgSlug, d.id),
    }));
  }

  async function createTable(params: CreateTableParams): Promise<CreateTableResult> {
    assertAllowedToolJetDbColumnNames('createTable', params.columns);
    const columnNames = new Set(params.columns.map((column) => column.name));
    for (const foreignKey of params.foreignKeys ?? []) {
      if (foreignKey.columns.length !== foreignKey.referencedColumns.length) {
        throw new Error(
          `ToolJet createTable failed: foreign key columns and referencedColumns must have the same length.`
        );
      }
      const missing = foreignKey.columns.filter((column) => !columnNames.has(column));
      if (missing.length) {
        throw new Error(`ToolJet createTable failed: foreign key references missing local columns: ${missing.join(', ')}`);
      }
    }
    const orgId = await auth.getOrganizationId();
    let cols = params.columns.map(tableColumnDto);
    // Every tjdb table needs a primary key; if none was specified, prepend a serial `id`.
    if (!params.columns.some((column) => column.primaryKey)) {
      cols = [
        {
          column_name: 'id',
          data_type: 'serial',
          constraints_type: { is_not_null: true, is_primary_key: true, is_unique: true },
        },
        ...cols,
      ];
    }
    const res = await auth.authedFetch(`/api/tooljet-db/organizations/${orgId}/table`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        table_name: params.tableName,
        columns: cols,
        ...(params.foreignKeys?.length
          ? {
              foreign_keys: params.foreignKeys.map(tableForeignKeyDto),
            }
          : {}),
      }),
    });
    await assertOk(res, 'createTable');
    const body = (await res.json()) as { result: { id: string; table_name: string } };
    return { table_id: body.result.id, table_name: body.result.table_name };
  }

  async function createTables(params: CreateTablesParams): Promise<CreateTableResult[]> {
    const levels = tableCreationLevels(params.tables);
    const created: CreateTableResult[] = [];
    for (const level of levels) {
      // Bound in-flight writes and stop scheduling after a failed batch. Already-started
      // requests must settle so every persisted table remains available for recovery.
      for (let start = 0; start < level.length; start += 4) {
        const batch = level.slice(start, start + 4);
        const settled = await Promise.allSettled(batch.map((table) => createTable(table)));
        const failures: string[] = [];
        let quota: TableQuotaError | undefined;
        settled.forEach((result, index) => {
          if (result.status === 'fulfilled') created.push(result.value);
          else {
            quota ??= tableQuotaError(result.reason);
            failures.push(`${batch[index].tableName}: ${result.reason instanceof Error ? result.reason.message : String(result.reason)}`);
          }
        });
        if (failures.length) throw new PartialWriteError('createTables', created, failures, quota);
      }
    }
    const byName = new Map(created.map((table) => [table.table_name.toLowerCase(), table]));
    return params.tables.map((table) => byName.get(table.tableName.toLowerCase())!);
  }

  async function addTableColumn(params: AddTableColumnParams): Promise<{ added: boolean }> {
    assertAllowedToolJetDbColumnNames('addTableColumn', [params.column]);
    for (const foreignKey of params.foreignKeys ?? []) {
      if (!foreignKey.columns.includes(params.column.name)) {
        throw new Error(
          `ToolJet addTableColumn failed: foreign key must include the new column "${params.column.name}".`
        );
      }
      if (foreignKey.columns.length !== foreignKey.referencedColumns.length) {
        throw new Error(
          'ToolJet addTableColumn failed: foreign key columns and referencedColumns must have the same length.'
        );
      }
    }
    const orgId = await auth.getOrganizationId();
    const res = await auth.authedFetch(
      `/api/tooljet-db/organizations/${orgId}/table/${encodeURIComponent(params.tableName)}/column`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          column: tableColumnDto(params.column),
          foreign_keys: (params.foreignKeys ?? []).map(tableForeignKeyDto),
        }),
      }
    );
    await assertOk(res, 'addTableColumn');
    return { added: true };
  }

  async function dropTableColumn(params: {
    tableName: string;
    columnName: string;
  }): Promise<{ dropped: boolean }> {
    const orgId = await auth.getOrganizationId();
    const res = await auth.authedFetch(
      `/api/tooljet-db/organizations/${orgId}/table/${encodeURIComponent(params.tableName)}/column/${encodeURIComponent(params.columnName)}`,
      { method: 'DELETE' }
    );
    await assertOk(res, 'dropTableColumn');
    return { dropped: true };
  }

  async function dropTable(params: { tableName: string }): Promise<{ dropped: boolean }> {
    const orgId = await auth.getOrganizationId();
    const res = await auth.authedFetch(
      `/api/tooljet-db/organizations/${orgId}/table/${encodeURIComponent(params.tableName)}`,
      { method: 'DELETE' }
    );
    await assertOk(res, 'dropTable');
    return { dropped: true };
  }

  async function getTableSchema(tableName: string): Promise<SchemaColumn[]> {
    const orgId = await auth.getOrganizationId();
    const res = await auth.authedFetch(
      `/api/tooljet-db/organizations/${orgId}/table/${encodeURIComponent(tableName)}`
    );
    await assertOk(res, 'getTableSchema');
    const body = (await res.json()) as {
      result: {
        columns: Array<{
          column_name: string;
          data_type: string;
          column_default?: unknown;
          configurations?: Record<string, unknown>;
          constraints_type?: { is_primary_key?: boolean; is_not_null?: boolean; is_unique?: boolean };
        }>;
        foreign_keys?: Array<{
          column_names: string[];
          referenced_table_name: string;
          referenced_column_names: string[];
          on_delete?: ForeignKeyAction;
          on_update?: ForeignKeyAction;
        }>;
        configurations?: {
          columns?: {
            column_names?: Record<string, string>;
            configurations?: Record<string, Record<string, unknown>>;
          };
        };
      };
    };
    return body.result.columns.map((c) => {
      const columnUuid = body.result.configurations?.columns?.column_names?.[c.column_name];
      const configurations =
        c.configurations ??
        (columnUuid ? body.result.configurations?.columns?.configurations?.[columnUuid] : undefined);
      return {
        name: c.column_name,
        type: c.data_type,
        isPrimaryKey: !!c.constraints_type?.is_primary_key,
        isNotNull: !!c.constraints_type?.is_not_null,
        isUnique: !!c.constraints_type?.is_unique,
        ...(c.column_default !== undefined ? { defaultValue: c.column_default } : {}),
        ...(configurations ? { configurations } : {}),
        foreignKeys: (body.result.foreign_keys ?? [])
          .filter((foreignKey) => foreignKey.column_names.includes(c.column_name))
          .map((foreignKey) => ({
            columns: foreignKey.column_names,
            referencedTable: foreignKey.referenced_table_name,
            referencedColumns: foreignKey.referenced_column_names,
            ...(foreignKey.on_delete ? { onDelete: foreignKey.on_delete } : {}),
            ...(foreignKey.on_update ? { onUpdate: foreignKey.on_update } : {}),
          })),
      };
    });
  }

  // After a table is created, PostgREST's schema cache can lag behind the DDL, so the first proxy write
  // returns PGRST205 ("Could not find the table ... in the schema cache") — a transient infra race, not
  // an app error. Retry with backoff so seeding waits the cache out instead of failing the phase and
  // handing an unfixable error to the model. Once the cache refreshes, later rows succeed on attempt 0.
  const SCHEMA_CACHE_RETRY_DELAYS_MS = [300, 600, 1200, 2400, 4000];
  // A timed-out POST may already have committed. Bound the wait, but never replay an insert after
  // a transport failure or uncertain server response without server-side idempotency.
  const INSERT_ATTEMPT_TIMEOUT_MS = 45_000;
  const UNKNOWN_INSERT_OUTCOME = 'Insert outcome unknown: the row may already have been inserted. ' +
    'Verify persisted rows before retrying; do not replay the whole batch.';

  async function insertRowViaProxy(tableId: string, row: Record<string, unknown>): Promise<Response> {
    let schemaWaits = 0;
    for (;;) {
      let res: Response;
      try {
        res = await auth.authedFetch(`/api/tooljet-db/proxy/${encodeURIComponent(tableId)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(row),
          signal: AbortSignal.timeout(INSERT_ATTEMPT_TIMEOUT_MS),
        });
      } catch (error) {
        throw new Error(`ToolJet insertRows request failed (${error instanceof Error ? error.name : 'transport error'}). ${UNKNOWN_INSERT_OUTCOME}`);
      }
      if (res.ok) return res;
      if (res.status === 408 || res.status >= 500) {
        const body = await res.text().catch(() => 'Response body unavailable');
        const error = new ToolJetHttpError(res.status, 'insertRows', body);
        error.message += ` ${UNKNOWN_INSERT_OUTCOME}`;
        throw error;
      }
      // Only retry explicit schema-cache rejections, where PostgREST did not execute the insert.
      // The BODY is the discriminator, not the status: ToolJet's proxy wraps PGRST205 as a 409, so
      // gating on 400/404 meant this retry never ran for the case it was written for. Measured
      // 2026-09-14: six partial applies across two models, every one "failed during seed data and
      // create queries" with the table created and zero rows seeded, all carrying PGRST205 in a 409.
      // A 409 is normally a real conflict (duplicate key), which is why the body check stays: only a
      // response that actually names the schema cache is retried.
      if (schemaWaits >= SCHEMA_CACHE_RETRY_DELAYS_MS.length) return res;
      const body = await res.clone().text().catch(() => '');
      if (!/PGRST205|schema cache/i.test(body)) return res; // a real error — let assertOk surface it
      await new Promise((resolve) => setTimeout(resolve, SCHEMA_CACHE_RETRY_DELAYS_MS[schemaWaits]));
      schemaWaits += 1;
    }
  }

  async function insertRows(params: InsertRowsParams): Promise<{ processed_rows: number }> {
    if (!params.rows.length) return { processed_rows: 0 };
    const schema = await getTableSchema(params.tableName);
    const rows = params.rows.map((r) => ({ ...r }));
    const timestampErrors = invalidSeedTimestamps(schema, rows);
    if (timestampErrors.length) throw new Error(`insertRows preflight for "${params.tableName}": ${timestampErrors.join(' ')} No rows in this table batch were inserted.`);
    const generatedPrimaryKey = schema.find(
      (column) => column.isPrimaryKey && (
        /serial/i.test(column.type) || /^nextval\(/i.test(String(column.defaultValue ?? ''))
      )
    );
    if (generatedPrimaryKey && rows.some((row) => generatedPrimaryKey.name in row)) {
      throw new Error(
        `insertRows: omit generated primary key "${generatedPrimaryKey.name}" for table "${params.tableName}". ` +
          'ToolJet will allocate it from the real table sequence; explicit generated ids can collide or desynchronize future inserts.'
      );
    }

    const table = (await listTables()).find((candidate) => candidate.table_name === params.tableName);
    if (!table) throw new Error(`insertRows: ToolJet DB table "${params.tableName}" was not found in the active workspace.`);

    // ToolJet's PostgREST proxy object-spreads POST bodies while validating JSONB values, which
    // turns an array payload into numeric column names. Send one ordinary INSERT per row instead.
    // Unlike bulk-upload, this path does not upsert on primary-key conflicts, and omitted
    // serial/generated keys use the table's real sequence.
    let processedRows = 0;
    for (const [index, row] of rows.entries()) {
      try {
        const res = await insertRowViaProxy(table.id, row);
        await assertOk(res, 'insertRows');
        processedRows += 1;
      } catch (error) {
        if (!processedRows) throw error;
        throw new PartialWriteError('insertRows', [{ processed_rows: processedRows }], [
          `row ${index + 1}/${rows.length}: ${error instanceof Error ? error.message : String(error)}`,
        ]);
      }
    }
    return { processed_rows: processedRows };
  }

  async function insertRowsBatch(params: InsertRowsBatchParams): Promise<InsertRowsBatchResult[]> {
    const results: InsertRowsBatchResult[] = [];
    for (const table of params.tables) {
      try {
        const result = await insertRows(table);
        results.push({ table_name: table.tableName, processed_rows: result.processed_rows });
      } catch (error) {
        const partialRows = completedPartialWrites<{ processed_rows: number }>(error)
          .reduce((total, result) => total + result.processed_rows, 0);
        if (partialRows) results.push({ table_name: table.tableName, processed_rows: partialRows });
        throw new PartialWriteError('insertRowsBatch', results, [
          `${table.tableName}: ${error instanceof Error ? error.message : String(error)}`,
        ]);
      }
    }
    return results;
  }

  // The query's kind must match its datasource's kind. Resolve it from the datasource list
  // when the caller didn't pass one (so it works for any datasource, not just ToolJet DB).
  async function resolveDatasourceKind(versionId: string, dataSourceId: string): Promise<string> {
    const ds = (await listDatasources(versionId)).find((d) => d.id === dataSourceId);
    if (!ds) throw new Error(`ToolJet createQuery failed: datasource ${dataSourceId} not found for this app version`);
    return ds.kind;
  }

  // Query creates contend on version-scoped backend locks. Keep one in flight per version
  // in this client, including overlapping single/batch calls. Other versions remain independent.
  // This is not a distributed lock; separate MCP processes can still contend.
  const queryCreateTails = new Map<string, Promise<void>>();
  async function createQuery(params: CreateQueryParams): Promise<CreateQueryResult> {
    const previous = queryCreateTails.get(params.versionId);
    let release!: () => void;
    const tail = new Promise<void>(resolve => { release = resolve; });
    queryCreateTails.set(params.versionId, tail);
    await previous;
    try {
      return await createQueryUnqueued(params);
    } finally {
      release();
      if (queryCreateTails.get(params.versionId) === tail) queryCreateTails.delete(params.versionId);
    }
  }

  async function createQueryUnqueued(params: CreateQueryParams): Promise<CreateQueryResult> {
    const kind = params.kind ?? (await resolveDatasourceKind(params.versionId, params.dataSourceId));
    const res = await auth.authedFetch(
      `/api/data-queries/data-sources/${params.dataSourceId}/versions/${params.versionId}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind, name: params.name, options: params.options }),
      }
    );
    await assertOk(res, 'createQuery');
    const body = (await res.json()) as { id: string; name: string };
    return { query_id: body.id, name: body.name };
  }

  // One model call, N ordered HTTP writes. Preserve partial-write reporting without replaying
  // successful or uncertain writes; serial execution avoids this client's own lock contention.
  async function createQueries(params: CreateQueriesParams): Promise<CreateQueryResult[]> {
    // Resolve datasource kinds once; createQuery queues the writes per version.
    const needResolve = params.queries.some((q) => !q.kind);
    const dsList = needResolve ? await listDatasources(params.versionId) : [];
    const kindOf = (id: string): string | undefined => dsList.find((d) => d.id === id)?.kind;
    const settled = await Promise.allSettled(
      params.queries.map((q) =>
        createQuery({
          versionId: params.versionId,
          dataSourceId: q.dataSourceId,
          name: q.name,
          options: q.options,
          kind: q.kind ?? kindOf(q.dataSourceId),
        })
      )
    );
    const completed = settled.flatMap((result) => result.status === 'fulfilled' ? [result.value] : []);
    const failures = settled.flatMap((result, index) => result.status === 'rejected'
      ? [`${params.queries[index]!.name}: ${result.reason instanceof Error ? result.reason.message : String(result.reason)}`]
      : []);
    if (failures.length) throw new PartialWriteError('createQueries', completed, failures);
    return completed;
  }

  function buildComponentDto(spec: ComponentSpec): Record<string, unknown> {
    // Guard: styling nested under `properties` is silently discarded by ToolJet (its renderer
    // reads styles from `definition.styles`). Reject early with an actionable message.
    const misplaced = Object.keys(spec.properties ?? {}).filter((k) => STYLE_KEYS_IN_PROPERTIES.has(k));
    if (misplaced.length) {
      throw new Error(
        `Component "${spec.name}": style keys ${JSON.stringify(misplaced)} were placed under \`properties\`, ` +
          `where ToolJet silently ignores them. Move them to the top-level \`styles\` object instead.`
      );
    }
    const dto: Record<string, unknown> = {
      name: spec.name,
      type: spec.type,
      properties: spec.properties,
      styles: spec.styles ?? {},
      validation: spec.validation ?? {},
      others: spec.others ?? {},
    };
    // layouts are keyed by resolution type (desktop/mobile) — a flat {top,left,...} returns 422
    // "invalid input value for enum layout_type". Explicit per-resolution `layouts` wins; otherwise
    // the flat `layout` convenience is applied to both.
    const desktop = spec.layouts?.desktop ?? spec.layout;
    const mobile = spec.layouts?.mobile ?? spec.layout;
    if (desktop || mobile) {
      dto.layouts = { ...(desktop ? { desktop } : {}), ...(mobile ? { mobile } : {}) };
    }
    return dto;
  }

  // Batch: create many components on one page in a SINGLE request. ToolJet's create endpoint
  // takes a diff MAP keyed by component id, so N components = one HTTP call.
  async function createComponents(
    params: CreateComponentsParams
  ): Promise<Array<CreateComponentResult & { name: string }>> {
    const entries = params.components.map((spec) => ({ id: randomUUID(), spec }));
    const refToId = new Map<string, string>();
    for (const e of entries) {
      if (!e.spec.clientRef) continue;
      if (refToId.has(e.spec.clientRef)) {
        throw new Error(`createComponents: duplicate clientRef "${e.spec.clientRef}".`);
      }
      refToId.set(e.spec.clientRef, e.id);
    }
    const diff: Record<string, unknown> = {};
    for (const e of entries) {
      if (e.spec.parent && e.spec.parentRef) {
        throw new Error(`createComponents "${e.spec.name}": set EITHER parent or parentRef, not both.`);
      }
      const dto = buildComponentDto(e.spec);
      const resolvedParent = e.spec.parentRef ? refToId.get(e.spec.parentRef) : e.spec.parent;
      if (e.spec.parentRef && !resolvedParent) {
        throw new Error(
          `createComponents "${e.spec.name}": parentRef "${e.spec.parentRef}" does not match a clientRef in this batch.`
        );
      }
      if (e.spec.slotName && !resolvedParent) {
        throw new Error(`createComponents "${e.spec.name}": slotName requires parent or parentRef.`);
      }
      if (resolvedParent) dto.parent = encodeComponentParent(resolvedParent, e.spec.slotName);
      diff[e.id] = dto;
    }

    const res = await auth.authedFetch(`/api/v2/apps/${params.appId}/versions/${params.versionId}/components`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_user_switched_version: false, pageId: params.pageId, diff }),
    });
    await assertOk(res, 'createComponents');
    return entries.map((e) => ({ component_id: e.id, name: e.spec.name }));
  }

  async function createComponent(params: CreateComponentParams): Promise<CreateComponentResult> {
    const [r] = await createComponents({
      appId: params.appId,
      versionId: params.versionId,
      pageId: params.pageId,
      components: [
        {
          name: params.name,
          type: params.type,
          properties: params.properties,
          styles: params.styles,
          validation: params.validation,
          others: params.others,
          layout: params.layout,
          layouts: params.layouts,
        },
      ],
    });
    return { component_id: r.component_id };
  }

  // Update = PUT /components. The diff value is wrapped in `component` (NOT the flat create shape) and
  // partial: send only changed leaves under `definition`. Server deep-merges, except arrays (Table
  // columns / dropdown options) which it REPLACES. Renames/reparents go as raw column changes with no
  // `definition` key. pageId is required by the DTO even though the update handler ignores it.
  async function updateComponents(params: UpdateComponentsParams): Promise<{ updated: number }> {
    const diff: Record<string, unknown> = {};
    for (const u of params.updates) {
      const hasDef = hasNonEmptyDefinition(u.definition);
      const hasRaw = u.name !== undefined || u.parent !== undefined || u.slotName !== undefined;
      if (!hasDef && !hasRaw) {
        // Never PUT an empty diff: ToolJet answers 200 without writing and the caller would report
        // it as updated. Observed live when a patch was sent outside `definition` and stripped.
        throw new Error(
          `updateComponents "${u.componentId}": nothing to update. Provide a non-empty definition ` +
            '(properties/styles/validation/others) or a name/parent change.'
        );
      }
      if (hasDef && hasRaw) {
        throw new Error(
          `updateComponents "${u.componentId}": set EITHER definition (properties/styles/…) OR name/parent/slotName ` +
            `in one entry — ToolJet applies only one path. Split into two update calls.`
        );
      }
      if (u.slotName !== undefined && u.parent === undefined) {
        throw new Error(`updateComponents "${u.componentId}": slotName requires parent.`);
      }
      if (hasDef) {
        diff[u.componentId] = { component: { definition: u.definition } };
      } else {
        diff[u.componentId] = {
          component: {
            ...(u.name !== undefined ? { name: u.name } : {}),
            ...(u.parent !== undefined ? { parent: encodeComponentParent(u.parent, u.slotName) } : {}),
          },
        };
      }
    }
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/components`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_user_switched_version: false, pageId: params.pageId, diff }),
      }
    );
    await assertOk(res, 'updateComponents');
    return { updated: params.updates.length };
  }

  // Delete = DELETE /components with a JSON body whose `diff` is a bare array of component ids.
  async function deleteComponents(params: DeleteComponentsParams): Promise<{ deleted: number }> {
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/components`,
      {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          is_user_switched_version: false,
          pageId: params.pageId,
          diff: params.componentIds,
        }),
      }
    );
    await assertOk(res, 'deleteComponents');
    return { deleted: params.componentIds.length };
  }

  // Move/resize = PUT /components/layout; diff keyed by id → { layouts:{desktop?,mobile?}, component?:{parent} }.
  async function updateLayouts(params: UpdateLayoutsParams): Promise<{ updated: number }> {
    const diff: Record<string, unknown> = {};
    for (const l of params.layouts) {
      if (!l.desktop && !l.mobile && l.parent === undefined) {
        throw new Error(
          `updateLayouts "${l.componentId}": nothing to update. Provide desktop and/or mobile rects, or a parent change.`
        );
      }
      const entry: Record<string, unknown> = {
        layouts: {
          ...(l.desktop ? { desktop: l.desktop } : {}),
          ...(l.mobile ? { mobile: l.mobile } : {}),
        },
      };
      if (l.slotName !== undefined && l.parent === undefined) {
        throw new Error(`updateLayouts "${l.componentId}": slotName requires parent.`);
      }
      if (l.parent !== undefined) entry.component = { parent: encodeComponentParent(l.parent, l.slotName) };
      diff[l.componentId] = entry;
    }
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/components/layout`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_user_switched_version: false, pageId: params.pageId, diff }),
      }
    );
    await assertOk(res, 'updateLayouts');
    return { updated: params.layouts.length };
  }

  // Update query = PATCH /:id/versions/:versionId. `options` REPLACES the stored options wholesale.
  async function updateQuery(params: UpdateQueryParams): Promise<{ query_id: string }> {
    const body: Record<string, unknown> = { options: params.options };
    if (params.name !== undefined) body.name = params.name;
    const res = await auth.authedFetch(
      `/api/data-queries/${params.queryId}/versions/${params.versionId}`,
      {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      }
    );
    await assertOk(res, 'updateQuery');
    return { query_id: params.queryId };
  }

  async function updateQueryDatasource(params: {
    queryId: string;
    versionId: string;
    dataSourceId: string;
  }): Promise<void> {
    const res = await auth.authedFetch(
      `/api/data-queries/${params.queryId}/versions/${params.versionId}/data-source`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data_source_id: params.dataSourceId }),
      }
    );
    await assertOk(res, 'updateQueryDatasource');
  }

  async function deleteQuery(params: { queryId: string; versionId: string }): Promise<{ deleted: boolean }> {
    const res = await auth.authedFetch(
      `/api/data-queries/${params.queryId}/versions/${params.versionId}`,
      { method: 'DELETE' }
    );
    await assertOk(res, 'deleteQuery');
    return { deleted: true };
  }

  async function deletePage(params: DeletePageParams): Promise<{ deleted: boolean }> {
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/pages`,
      {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pageId: params.pageId,
          deleteAssociatedPages: params.deleteAssociatedPages ?? false,
        }),
      }
    );
    await assertOk(res, 'deletePage');
    return { deleted: true };
  }

  async function getQueries(versionId: string): Promise<QuerySummary[]> {
    const res = await auth.authedFetch(`/api/data-queries/${versionId}`);
    await assertOk(res, 'getQueries');
    const body = (await res.json()) as { data_queries?: QuerySummary[] };
    const orgSlug = await auth.getOrganizationSlug();
    return (body.data_queries ?? []).map((query) => ({
      ...query,
      ...(query.data_source_id
        ? { datasource_settings_url: datasourceManagementUrl(orgSlug, query.data_source_id) }
        : {}),
    }));
  }

  async function getQuery(queryId: string, versionId: string): Promise<QuerySummary> {
    const query = (await getQueries(versionId)).find((candidate) => candidate.id === queryId);
    if (!query) throw new Error(`ToolJet getQuery failed: query ${queryId} not found in version ${versionId}`);
    return query;
  }

  // Run a SAVED query and return its result — the browser-free way to see real rows. Executes the query
  // as stored in the DB; `options:{}` avoids persisting anything back. Response { status:'ok', data:[…] }
  // on success, { status:'failed', message } on error — HTTP is 200 either way, so callers inspect status.
  async function runQuery(params: {
    queryId: string;
    versionId: string;
    environmentId?: string;
  }): Promise<RunQueryResult> {
    const envId = params.environmentId ?? (await getDevelopmentEnvironmentId());
    const res = await auth.authedFetch(
      `/api/data-queries/${params.queryId}/versions/${params.versionId}/run/${envId}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resolvedOptions: {}, options: {} }),
      }
    );
    await assertOk(res, 'runQuery');
    return (await res.json()) as RunQueryResult;
  }

  async function invokeDatasourceMethod(params: InvokeDatasourceMethodParams): Promise<RunQueryResult> {
    const environmentId = params.environmentId ?? (await getDevelopmentEnvironmentId());
    const res = await auth.authedFetch(`/api/data-sources/${params.dataSourceId}/invoke`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        method: params.method,
        environmentId,
        ...(params.args ? { args: params.args } : {}),
      }),
    });
    await assertOk(res, 'invokeDatasourceMethod');
    return (await res.json()) as RunQueryResult;
  }

  /** Read installed plugin API metadata through the authenticated spec route. */
  async function getPluginSpec(pluginKind: string, specName: string): Promise<string> {
    const res = await auth.authedFetch(`/api/plugins/specs/${encodeURIComponent(pluginKind)}/${encodeURIComponent(specName)}`);
    await assertOk(res, 'getPluginSpec');
    return res.text();
  }

  /** Read one saved datasource's stored connection configuration for an environment.
   *
   *  Deliberately NOT taken from listDatasources: that response passes through ToolJet's
   *  decamelizeKeys, which rewrites option KEYS as well as envelope fields — `apiKey` becomes
   *  `api_key` for the 18 kinds whose manifests use camelCase (openai, mssql `instanceName`,
   *  cosmosdb `endPoint`, …). Posting those back would test a config the plugin cannot read and
   *  report a healthy source as broken. This route returns the entity unmodified. */
  async function getDatasourceConnectionDetails(
    dataSourceId: string,
    environmentId?: string
  ): Promise<DatasourceConnectionDetails> {
    const envId = environmentId ?? (await getDevelopmentEnvironmentId());
    const res = await auth.authedFetch(
      `/api/data-sources/${encodeURIComponent(dataSourceId)}/environment/${encodeURIComponent(envId)}`
    );
    await assertOk(res, 'getDatasourceConnectionDetails');
    const body = (await res.json()) as Record<string, any>;
    const pluginId = body.pluginId ?? body.plugin_id ?? undefined;
    return {
      kind: body.kind,
      ...(pluginId ? { pluginId } : {}),
      options: (body.options ?? {}) as Record<string, unknown>,
    };
  }

  /** Run ToolJet's own connection test for a saved datasource — the same call the datasource
   *  settings page makes. Options are the stored ones; a caller never supplies its own, so no
   *  credential passes through this process. */
  async function testDatasourceConnection(
    params: TestDatasourceConnectionParams
  ): Promise<ConnectionTestResult> {
    const environmentId = params.environmentId ?? (await getDevelopmentEnvironmentId());
    const res = await auth.authedFetch(
      `/api/data-sources/${encodeURIComponent(params.dataSourceId)}/test-connection`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: params.kind,
          options: params.options,
          environment_id: environmentId,
          // ToolJet validates plugin_id as a UUID; core datasources have none, so it must be
          // omitted rather than sent as null.
          ...(params.pluginId ? { plugin_id: params.pluginId } : {}),
        }),
      }
    );
    await assertOk(res, 'testDatasourceConnection');
    return (await res.json()) as ConnectionTestResult;
  }

  async function listEvents(params: {
    appId: string;
    versionId: string;
    sourceId?: string;
  }): Promise<EventSummary[]> {
    const qs = params.sourceId ? `?sourceId=${encodeURIComponent(params.sourceId)}` : '';
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/events${qs}`
    );
    await assertOk(res, 'listEvents');
    const body = (await res.json()) as any[];
    return (Array.isArray(body) ? body : []).map((e) => ({
      id: e.id,
      name: e.name,
      index: e.index,
      event: e.event,
      sourceId: e.sourceId,
      target: e.target,
    }));
  }

  // Update = PUT /events, body { events:[{event_id, diff}], updateType }. For 'update' the server reads
  // diff.name + diff.event (name becomes null if omitted); for 'reorder' it reads diff.index.
  async function updateEvents(params: UpdateEventsParams): Promise<{ updated: number }> {
    const updateType = params.updateType ?? 'update';
    const events = params.events.map((e) =>
      updateType === 'reorder'
        ? { event_id: e.eventId, diff: { index: e.index } }
        : {
            event_id: e.eventId,
            diff: {
              name: e.name,
              event: e.event,
              ...(e.index !== undefined ? { index: e.index } : {}),
            },
          }
    );
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/events`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events, updateType }),
      }
    );
    await assertOk(res, 'updateEvents');
    return { updated: params.events.length };
  }

  async function deleteEvent(params: {
    appId: string;
    versionId: string;
    eventId: string;
  }): Promise<{ deleted: boolean }> {
    const res = await auth.authedFetch(
      `/api/v2/apps/${params.appId}/versions/${params.versionId}/events/${params.eventId}`,
      { method: 'DELETE' }
    );
    await assertOk(res, 'deleteEvent');
    return { deleted: true };
  }

  return {
    listWorkspaces,
    useWorkspace,
    listWorkspaceApps,
    listWorkspaceUsers,
    listWorkspaceGroups,
    getWorkspaceGroup,
    listWorkspaceGroupMembers,
    createWorkspaceGroup,
    renameWorkspaceGroup,
    deleteWorkspaceGroup,
    removeWorkspaceGroupMember,
    updateWorkspaceGroupPermissions,
    duplicateWorkspaceGroup,
    listWorkspaceGroupAccess,
    listWorkspaceGroupResources,
    writeWorkspaceGroupAccess,
    inviteWorkspaceUser,
    updateWorkspaceUser,
    setWorkspaceUserArchived,
    createApp,
    renameApp,
    getApp,
    getAppSummary,
    listAppPermissionSubjects,
    getAppPermission,
    setAppPermission,
    clearAppPermission,
    getAppSettings,
    listAppThemes,
    createAppTheme,
    setDefaultAppTheme,
    updateAppThemeDefinition,
    renameAppTheme,
    deleteAppTheme,
    updateAppSettings,
    getComponent,
    createPage,
    createPages,
    updatePages,
    deletePage,
    createEvents,
    getDevelopmentEnvironmentId,
    listDatasources,
    listTables,
    createTable,
    createTables,
    addTableColumn,
    dropTableColumn,
    dropTable,
    getTableSchema,
    insertRows,
    insertRowsBatch,
    createQuery,
    createQueries,
    createComponent,
    createComponents,
    updateComponents,
    deleteComponents,
    updateLayouts,
    updateQuery,
    updateQueryDatasource,
    deleteQuery,
    getQueries,
    getQuery,
    runQuery,
    invokeDatasourceMethod,
    getDatasourceConnectionDetails,
    getPluginSpec,
    testDatasourceConnection,
    listEvents,
    updateEvents,
    deleteEvent,
  };
}
