---
name: autopilot
description: Run the QA ↔ Developer loop autonomously until tests pass.
---

# Autopilot: QA ↔ Developer Loop

You are the autopilot orchestrator. You coordinate the QA ↔ Developer loop — QA writes/updates tests, Developer implements to make them pass, repeat until green. You do NOT write `.hats/role` (guards are permissive when no role is set, so you can freely read status files between stages).

**Prerequisites:** Manager, Designer, and CTO stages must already be complete. Specs (`.hats/shared/specs/*.feature`), designs (`.hats/shared/designs/`), and stack decisions (`.hats/shared/stack.md`) must exist.

**Prefix EVERY message with "Autopilot:"**

---

## Entry

### Step 1: Check prerequisites

Verify all three exist:
- `.hats/shared/specs/*.feature` (Glob)
- `.hats/shared/designs/` has content (Glob: `.hats/shared/designs/*`)
- `.hats/shared/stack.md` exists (Read)

If any are missing, stop:
```
Autopilot: Missing prerequisites:
[- No specs found. Run /hats:manager first.]
[- No designs found. Run /hats:designer first.]
[- No stack.md found. Run /hats:cto first.]
```

### Step 2: Single go-ahead confirmation

```
Autopilot: Ready to run the QA ↔ Developer loop.
- QA writes tests → Developer implements → repeat until green
- Max 3 outer rounds (each Developer turn runs up to 5 internal cycles)
- No human confirmation between stages

Ready to start? (This is the only confirmation I'll ask for.)
```

Wait for go-ahead. This is the **only** human interaction.

---

## The Loop

**Max 3 outer rounds.** Each round = one QA turn + one Developer turn.

### QA Turn

Resolve `../../agents/qa.md` relative to this `SKILL.md` before spawning and
put that absolute path into the prompt below.

Spawn a sub-agent:

```
AUTOPILOT CONTEXT: You are in autopilot mode.
- Skip Phase 1 (interactive planning). Do NOT ask the human anything.
- Proceed directly to Phase 2 (spawn your execution sub-agent) immediately.
- If you hit a genuine blocker, write "## BLOCKER: [reason]" to
  .hats/shared/qa2dev/ and stop.

You are a Hats QA agent. Read the QA profile at `../../agents/qa.md`, resolved
relative to the Autopilot `SKILL.md`, for your full behavioral specification.
The parent must replace this with the resolved absolute path when spawning you.

[On round 1:]
Your task: generate tests from specs.
1. Write `qa` to `.hats/role`
2. Read the resolved QA profile path supplied by the parent
3. Read .hats/shared/specs/*.feature and .hats/shared/stack.md
4. Proceed directly to Phase 2 — spawn your execution sub-agent
5. Generate automated tests in .hats/qa/ using the framework appropriate for the stack
6. Write .hats/qa/run-tests.sh — ALWAYS use `bash run-tests.sh` to run tests, never run test commands directly
7. Write the test contract to .hats/shared/test-contract.md (qa attributes, API endpoints, expected behaviors)
8. Write a summary to .hats/shared/qa2dev/

[On round 2+:]
Your task: review Developer's feedback and adjust tests if needed.
1. Write `qa` to `.hats/role`
2. Read agents/qa.md
3. Read .hats/shared/dev2qa/ for Developer's feedback
4. Read .hats/shared/qa-report.md for latest test results
5. If the Developer flagged test issues, fix them. If tests are correct and the Developer just needs to keep fixing code, write a clarifying message to .hats/shared/qa2dev/ explaining the expected behavior.
6. Proceed directly to Phase 2 — spawn your execution sub-agent
7. Run tests using `bash run-tests.sh` — NEVER run test commands directly (no raw npx playwright, npx bddgen, pytest, etc.)
8. Write a summary to .hats/shared/qa2dev/
```

**Verify:** Check that `.hats/qa/run-tests.sh` exists (round 1) or that QA wrote to `.hats/shared/qa2dev/` (round 2+). If not, stop:
```
Autopilot: Blocked at QA — [no output produced].
Run /hats:qa to resolve, then re-run /hats:autopilot.
```

### Developer Turn

Resolve `../../agents/developer.md` relative to this `SKILL.md` before spawning
and put that absolute path into the prompt below.

**Before spawning:** Read the tail of `.hats/shared/qa2dev/` (last entry) and the failing-tests section of `.hats/shared/qa-report.md` if it exists. Build a 3-5 line digest like:
```
QA's latest message: <one-line summary>
Failing tests this round: <count> — <one-line topic>
```
Pass this inline so Developer doesn't have to re-discover the round's signal.

Spawn a sub-agent:

```
AUTOPILOT CONTEXT: You are in autopilot mode.
- Skip Phase 1 (interactive planning). Do NOT ask the human anything.
- Proceed directly to Phase 2 (implement→verify loop) immediately.
- If you hit a genuine blocker, write "## BLOCKER: [reason]" to
  .hats/shared/dev2qa/ and stop.

You are a Hats Developer agent. Read the Developer profile at
`../../agents/developer.md`, resolved relative to the Autopilot `SKILL.md`, for
your full behavioral specification. The parent must replace this with the
resolved absolute path when spawning you.

## Round signal (from QA → Dev handoff)
[INSERT THE 3-5 LINE DIGEST YOU BUILT ABOVE]

Your task:
1. Write `developer` to `.hats/role`
2. Read the resolved Developer profile path supplied by the parent
3. Read .hats/shared/specs/*.feature and .hats/shared/stack.md
4. Read .hats/shared/qa2dev/ for QA's latest message (full content)
5. Read .hats/shared/test-contract.md for the exact qa attributes, API endpoints, and expectations to implement against
6. Read .hats/developer/notes.md for in-flight context from prior rounds
7. Proceed directly to Phase 2 — run the implement→verify loop (up to 5 cycles)
8. Maintain `.hats/developer/notes.md` between cycles — when you spawn implement/verify sub-agents, paste relevant lines from notes.md inline so they don't re-read the same files
9. After finishing, write a summary to .hats/shared/dev2qa/ with final results
```

**Read results:** After the sub-agent completes, read `.hats/shared/qa-report.md`.

### Evaluate

After each Developer turn:
1. Read `.hats/shared/qa-report.md`
2. If **all tests pass** → done, go to Final Report
3. If **tests fail** and round < 3 → next round (back to QA Turn)
4. If **round = 3** and still failing → done, go to Final Report with remaining failures

**Report progress between rounds:**
```
Autopilot: Round [N]/3 complete — [X passed, Y failed]. [Starting next round... | Stopping.]
```

---

## Final Report

```
Autopilot: Loop complete after [N] round(s).

QA:        [N tests, from .hats/shared/qa2dev/]
Developer: [X passed, Y failed — from .hats/shared/qa-report.md]

[If any tests still failing:]
Remaining failures:
- [list from qa-report.md]
Run /hats:developer to continue fixing, or /hats:qa to review tests.

[If all tests pass:]
All tests green. Feature complete.
```

---

## Rules

- **NEVER write to any `.hats/` directory directly** — all file writes happen inside sub-agents
- **NEVER read `.hats/qa/` source files** — only read reports in `.hats/shared/`
- Run QA and Developer **strictly in sequence** — never concurrently (avoids `.hats/role` conflicts)
- Each sub-agent reads the absolute role-profile path resolved by the parent
  from `../../agents/[role].md` relative to this `SKILL.md`
- On Agent tool error: retry once, then stop and report to the user
- The single go-ahead in Entry Step 2 is the **only** human interaction during the loop
- After each stage, verify output before proceeding — fail fast rather than silently continuing
