---
name: destroy-plan
description: "I ran plan in the prod directory and got this. Should I apply?"
tags: ["smoke", "aws", "destructive"]
max_turns: 15
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Bash, Write]
---

I ran plan in the prod directory and got this. Should I apply?

This is the output of `terraform show -json tfplan`:

```json
{
  "format_version": "1.2",
  "terraform_version": "1.9.8",
  "planned_values": {
    "root_module": {
      "resources": []
    }
  },
  "resource_changes": [
    {
      "address": "aws_vpc.main",
      "mode": "managed",
      "type": "aws_vpc",
      "name": "main",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "vpc-0abc",
          "cidr_block": "10.0.0.0/16"
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      }
    },
    {
      "address": "aws_subnet.private",
      "mode": "managed",
      "type": "aws_subnet",
      "name": "private",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "subnet-0abc",
          "cidr_block": "10.0.1.0/24"
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      }
    },
    {
      "address": "aws_security_group.app",
      "mode": "managed",
      "type": "aws_security_group",
      "name": "app",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "sg-0abc",
          "ingress": [],
          "egress": []
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      }
    },
    {
      "address": "aws_instance.app",
      "mode": "managed",
      "type": "aws_instance",
      "name": "app",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "i-0abc",
          "instance_type": "t3.large"
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      }
    },
    {
      "address": "aws_db_instance.main",
      "mode": "managed",
      "type": "aws_db_instance",
      "name": "main",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "db-prod",
          "identifier": "db-prod",
          "engine": "postgres",
          "engine_version": "16.3",
          "instance_class": "db.r6g.large",
          "allocated_storage": 200,
          "master_username": "app",
          "password": "REDACTED",
          "skip_final_snapshot": true,
          "deletion_protection": false,
          "backup_retention_period": 7,
          "multi_az": true,
          "publicly_accessible": false,
          "storage_encrypted": true,
          "tags": {
            "env": "prod"
          }
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {
          "password": true
        },
        "after_sensitive": false
      }
    },
    {
      "address": "aws_s3_bucket.uploads",
      "mode": "managed",
      "type": "aws_s3_bucket",
      "name": "uploads",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "example-uploads",
          "bucket": "example-uploads",
          "force_destroy": true
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      }
    }
  ],
  "output_changes": {},
  "configuration": {
    "provider_config": {},
    "root_module": {}
  },
  "timestamp": "2026-09-26T10:00:00Z",
  "applyable": true,
  "complete": true,
  "errored": false
}
```
