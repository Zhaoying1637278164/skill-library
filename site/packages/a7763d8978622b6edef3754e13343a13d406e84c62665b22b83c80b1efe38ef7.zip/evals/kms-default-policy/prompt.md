---
name: kms-default-policy
description: "New KMS key for the data bucket. Review please."
tags: ["aws", "iam"]
max_turns: 15
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Bash, Write]
---

New KMS key for the data bucket. Review please.

This is the output of `terraform show -json tfplan`:

```json
{
  "format_version": "1.2",
  "terraform_version": "1.9.8",
  "planned_values": {
    "root_module": {
      "resources": [
        {
          "address": "aws_kms_key.data",
          "mode": "managed",
          "type": "aws_kms_key",
          "name": "data",
          "provider_name": "registry.terraform.io/hashicorp/aws",
          "schema_version": 0,
          "values": {
            "description": "data at rest",
            "deletion_window_in_days": 30,
            "enable_key_rotation": true,
            "is_enabled": true,
            "policy": "{\"Version\": \"2012-10-17\", \"Id\": \"key-default-1\", \"Statement\": [{\"Sid\": \"Enable IAM User Permissions\", \"Effect\": \"Allow\", \"Principal\": {\"AWS\": \"arn:aws:iam::111111111111:root\"}, \"Action\": \"kms:*\", \"Resource\": \"*\"}]}"
          },
          "sensitive_values": {}
        },
        {
          "address": "aws_kms_alias.data",
          "mode": "managed",
          "type": "aws_kms_alias",
          "name": "data",
          "provider_name": "registry.terraform.io/hashicorp/aws",
          "schema_version": 0,
          "values": {
            "name": "alias/data",
            "target_key_id": null
          },
          "sensitive_values": {}
        },
        {
          "address": "aws_iam_role.reader",
          "mode": "managed",
          "type": "aws_iam_role",
          "name": "reader",
          "provider_name": "registry.terraform.io/hashicorp/aws",
          "schema_version": 0,
          "values": {
            "id": "reader",
            "name": "reader",
            "arn": "arn:aws:iam::111111111111:role/reader",
            "assume_role_policy": "{\"Version\": \"2012-10-17\", \"Statement\": [{\"Effect\": \"Allow\", \"Principal\": {\"AWS\": \"arn:aws:iam::111111111111:root\"}, \"Action\": \"sts:AssumeRole\"}]}",
            "tags": {
              "owner": "data"
            }
          },
          "sensitive_values": {}
        }
      ]
    }
  },
  "resource_changes": [
    {
      "address": "aws_kms_key.data",
      "mode": "managed",
      "type": "aws_kms_key",
      "name": "data",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "create"
        ],
        "before": null,
        "after": {
          "description": "data at rest",
          "deletion_window_in_days": 30,
          "enable_key_rotation": true,
          "is_enabled": true,
          "policy": "{\"Version\": \"2012-10-17\", \"Id\": \"key-default-1\", \"Statement\": [{\"Sid\": \"Enable IAM User Permissions\", \"Effect\": \"Allow\", \"Principal\": {\"AWS\": \"arn:aws:iam::111111111111:root\"}, \"Action\": \"kms:*\", \"Resource\": \"*\"}]}"
        },
        "after_unknown": {
          "id": true,
          "arn": true,
          "key_id": true
        },
        "before_sensitive": false,
        "after_sensitive": {}
      }
    },
    {
      "address": "aws_kms_alias.data",
      "mode": "managed",
      "type": "aws_kms_alias",
      "name": "data",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "create"
        ],
        "before": null,
        "after": {
          "name": "alias/data",
          "target_key_id": null
        },
        "after_unknown": {
          "id": true,
          "target_key_id": true
        },
        "before_sensitive": false,
        "after_sensitive": {}
      }
    },
    {
      "address": "aws_iam_role.reader",
      "mode": "managed",
      "type": "aws_iam_role",
      "name": "reader",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "update"
        ],
        "before": {
          "id": "reader",
          "name": "reader",
          "arn": "arn:aws:iam::111111111111:role/reader",
          "assume_role_policy": "{\"Version\": \"2012-10-17\", \"Statement\": [{\"Effect\": \"Allow\", \"Principal\": {\"AWS\": \"arn:aws:iam::111111111111:root\"}, \"Action\": \"sts:AssumeRole\"}]}",
          "tags": {}
        },
        "after": {
          "id": "reader",
          "name": "reader",
          "arn": "arn:aws:iam::111111111111:role/reader",
          "assume_role_policy": "{\"Version\": \"2012-10-17\", \"Statement\": [{\"Effect\": \"Allow\", \"Principal\": {\"AWS\": \"arn:aws:iam::111111111111:root\"}, \"Action\": \"sts:AssumeRole\"}]}",
          "tags": {
            "owner": "data"
          }
        },
        "after_unknown": {
          "tags": {}
        },
        "before_sensitive": {},
        "after_sensitive": {}
      }
    }
  ],
  "output_changes": {},
  "configuration": {
    "provider_config": {},
    "root_module": {}
  },
  "timestamp": "2026-09-26T10:00:00Z",
  "applyable": true,
  "complete": true,
  "errored": false
}
```
