---
name: sub-resource-deletes
description: "Cleaning up some leftovers. Is anything here dangerous?"
tags: ["aws", "destructive"]
max_turns: 15
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Bash, Write]
---

Cleaning up some leftovers. Is anything here dangerous?

This is the output of `terraform show -json tfplan`:

```json
{
  "format_version": "1.2",
  "terraform_version": "1.9.8",
  "planned_values": {
    "root_module": {
      "resources": []
    }
  },
  "resource_changes": [
    {
      "address": "aws_route_table_association.private_a",
      "mode": "managed",
      "type": "aws_route_table_association",
      "name": "private_a",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "rtbassoc-0abc",
          "route_table_id": "rtb-0abc",
          "subnet_id": "subnet-a"
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      },
      "action_reason": "delete_because_no_resource_config"
    },
    {
      "address": "aws_s3_bucket_policy.logs",
      "mode": "managed",
      "type": "aws_s3_bucket_policy",
      "name": "logs",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "example-logs",
          "bucket": "example-logs",
          "policy": "{}"
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      },
      "action_reason": "delete_because_no_resource_config"
    },
    {
      "address": "aws_iam_role_policy_attachment.ci_readonly",
      "mode": "managed",
      "type": "aws_iam_role_policy_attachment",
      "name": "ci_readonly",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "delete"
        ],
        "before": {
          "id": "ci-2026",
          "role": "ci",
          "policy_arn": "arn:aws:iam::aws:policy/ReadOnlyAccess"
        },
        "after": null,
        "after_unknown": {},
        "before_sensitive": {},
        "after_sensitive": false
      },
      "action_reason": "delete_because_no_resource_config"
    }
  ],
  "output_changes": {},
  "configuration": {
    "provider_config": {},
    "root_module": {}
  },
  "timestamp": "2026-09-26T10:00:00Z",
  "applyable": true,
  "complete": true,
  "errored": false
}
```
