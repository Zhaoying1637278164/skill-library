---
name: clean-plan
description: "Anything risky in this plan? New Lambda plus a tag change."
tags: ["smoke", "aws", "clean"]
max_turns: 15
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Bash, Write]
---

Anything risky in this plan? New Lambda plus a tag change.

This is the output of `terraform show -json tfplan`:

```json
{
  "format_version": "1.2",
  "terraform_version": "1.9.8",
  "planned_values": {
    "root_module": {
      "resources": [
        {
          "address": "aws_lambda_function.report",
          "mode": "managed",
          "type": "aws_lambda_function",
          "name": "report",
          "provider_name": "registry.terraform.io/hashicorp/aws",
          "schema_version": 0,
          "values": {
            "function_name": "report",
            "runtime": "python3.12",
            "memory_size": 512,
            "timeout": 30,
            "role": "arn:aws:iam::111111111111:role/report-lambda"
          },
          "sensitive_values": {}
        },
        {
          "address": "aws_cloudwatch_log_group.report",
          "mode": "managed",
          "type": "aws_cloudwatch_log_group",
          "name": "report",
          "provider_name": "registry.terraform.io/hashicorp/aws",
          "schema_version": 0,
          "values": {
            "name": "/aws/lambda/report",
            "retention_in_days": 30
          },
          "sensitive_values": {}
        },
        {
          "address": "aws_s3_bucket.data",
          "mode": "managed",
          "type": "aws_s3_bucket",
          "name": "data",
          "provider_name": "registry.terraform.io/hashicorp/aws",
          "schema_version": 0,
          "values": {
            "id": "example-data",
            "bucket": "example-data",
            "force_destroy": false,
            "tags": {
              "env": "prod",
              "owner": "data-team"
            }
          },
          "sensitive_values": {}
        }
      ]
    }
  },
  "resource_changes": [
    {
      "address": "aws_lambda_function.report",
      "mode": "managed",
      "type": "aws_lambda_function",
      "name": "report",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "create"
        ],
        "before": null,
        "after": {
          "function_name": "report",
          "runtime": "python3.12",
          "memory_size": 512,
          "timeout": 30,
          "role": "arn:aws:iam::111111111111:role/report-lambda"
        },
        "after_unknown": {
          "id": true
        },
        "before_sensitive": false,
        "after_sensitive": {}
      }
    },
    {
      "address": "aws_cloudwatch_log_group.report",
      "mode": "managed",
      "type": "aws_cloudwatch_log_group",
      "name": "report",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "create"
        ],
        "before": null,
        "after": {
          "name": "/aws/lambda/report",
          "retention_in_days": 30
        },
        "after_unknown": {
          "id": true
        },
        "before_sensitive": false,
        "after_sensitive": {}
      }
    },
    {
      "address": "aws_s3_bucket.data",
      "mode": "managed",
      "type": "aws_s3_bucket",
      "name": "data",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "update"
        ],
        "before": {
          "id": "example-data",
          "bucket": "example-data",
          "force_destroy": false,
          "tags": {
            "env": "prod"
          }
        },
        "after": {
          "id": "example-data",
          "bucket": "example-data",
          "force_destroy": false,
          "tags": {
            "env": "prod",
            "owner": "data-team"
          }
        },
        "after_unknown": {
          "tags": {}
        },
        "before_sensitive": {},
        "after_sensitive": {}
      }
    },
    {
      "address": "data.aws_caller_identity.current",
      "mode": "data",
      "type": "aws_caller_identity",
      "name": "current",
      "provider_name": "registry.terraform.io/hashicorp/aws",
      "change": {
        "actions": [
          "read"
        ],
        "before": null,
        "after": {
          "account_id": "111111111111"
        },
        "after_unknown": {
          "id": true
        },
        "before_sensitive": false,
        "after_sensitive": {}
      }
    }
  ],
  "output_changes": {},
  "configuration": {
    "provider_config": {},
    "root_module": {}
  },
  "timestamp": "2026-09-26T10:00:00Z",
  "applyable": true,
  "complete": true,
  "errored": false
}
```
