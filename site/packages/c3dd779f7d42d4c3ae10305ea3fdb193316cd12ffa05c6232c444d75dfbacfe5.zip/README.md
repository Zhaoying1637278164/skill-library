# Design Steward

Design Steward takes a website or app from design feedback to a verified fix. Mark up a live page with notes, drawings and preview edits, then turn that feedback into a clear list of issues with testable acceptance criteria. Check which design rules your project has actually settled on and where its docs and code disagree, update the docs once you decide, and make the changes with a progress log you can pause and resume. Finally, confirm each fix at the screen sizes you care about. A cleanup skill also finds leftover plans, scratch notes and stale files, and archives anything you approve for removal so nothing is lost. Each of the seven skills works on its own.

A Claude Code plugin by Matthew Cohen.

## Install

```text
/plugin marketplace add enoevol81/enoevol-plugins
/plugin install design-steward@enoevol-plugins
```

For an unpublished local checkout: `claude --plugin-dir ./design-steward`.

## Requirements and where it works

- **Claude Code** is the supported host. The skills work on a local project folder.
- **Python 3** runs the bundled helper scripts (progress ledger, source freshness,
  source mapping, cleanup inventory).
- **Live review** needs a browser bridge such as Claude in Chrome, or you can paste
  the overlay script into DevTools yourself. Turning an existing capture into a brief
  needs no browser.
- **claude.ai chat and Cowork** can load the skills, but they are not tested there.
  Without access to your project folder, Python and a browser, most stages won't work.

Install either this bundle or the standalone Hands Free, Canon Check, Critic Layer and
Cut Weight plugins, not both, so their skills don't compete for the same requests.

## Seven independent skills

| Command | Result |
| --- | --- |
| `/design-steward:audit` | Which design rules are settled, where each came from, and where docs and code disagree |
| `/design-steward:review` | Notes, drawings and preview edits on a live page, saved so nothing is lost |
| `/design-steward:brief` | A numbered issue list with likely source files and testable acceptance criteria |
| `/design-steward:align` | Your design docs updated to match the decisions you make |
| `/design-steward:execute` | The approved changes made step by step, with a progress log you can pause and resume |
| `/design-steward:verify` | Before/after checks of each issue at the screen sizes you choose |
| `/design-steward:cleanup` | Leftover plans, notes and stale files found and reviewed with you; approved removals archived with restore steps |

Example: "Review this local page, resolve its button-radius conflict, implement
the direction I choose, and verify at 390px and 1280px." Each stage is usable on
its own; asking for review does not authorize implementation or publication.

## What stays distinct

A suggestion is not a standard. A preview is not a source change. A source change
is not a verified interface. Evidence records these distinctions throughout the
workflow. Existing authorization carries forward; only new decisions require
clarification. The plugin does not elevate permissions or assume special agents.

Runs live under `.design-steward/<run-id>/`. Tab recovery uses sessionStorage,
which the reviewed origin can read; export to local capture.json for durable
recovery. Imported captures never replay HTML changes. Disable tab recovery for
sensitive reviews with `window.__CRITIC__.forgetRecovery()`.

## What it runs and touches

Everything stays on your machine. The plugin has no hooks, no MCP servers, and makes
no network requests of its own.

- **Local scripts:** Python helpers bundled in the plugin read your project files and
  write JSON records. The cleanup inventory also runs read-only `git` commands
  (`ls-files`, `rev-parse`, `log`, `check-ignore`) in your project.
- **Project files:** run records go in `.design-steward/<run-id>/` inside your project.
  Align and execute edit only the documents and source files you authorize.
- **Browser review:** the review overlay is injected into the page you are reviewing.
  It stores notes, drawings and preview edits in that tab's sessionStorage, can copy
  an export to your clipboard, and sends nothing anywhere.
- **Cleanup archives:** approved removals are copied, with a manifest and restore
  steps, to a `<project>-graveyard/` folder next to your project before anything is
  removed. Only groups you approve are removed, using `git rm` for tracked files and
  left uncommitted for you to review. Archives are never deleted automatically.

## Tests

Behavior tests for `claude plugin eval` live in `evals/` (see `evals/README.md`).
