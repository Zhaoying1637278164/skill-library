---
type: tool_used
tool: Skill
input_match: '"skill"\s*:\s*"design-steward:review"'
---
