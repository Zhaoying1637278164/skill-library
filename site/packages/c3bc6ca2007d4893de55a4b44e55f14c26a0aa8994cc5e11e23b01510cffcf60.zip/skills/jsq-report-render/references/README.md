# Reference renders

These files are required by the `jsq-report-render` skill.

| File | Description |
| --- | --- |
| `example-tearsheet.html` | Ostmere Family Office — quarterly-review tearsheet reference |
| `example-action-report.html` | Tarnwick Ventures Fund II — fundraise action report reference |
| `example-org-chart.html` | Mossvale Fund — master-feeder entity org chart reference |
| `tokens.css` | JSQ color token ramps; inlined into every report |

All examples are scrubbed of real people, companies, and tenant names.
