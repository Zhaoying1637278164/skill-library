#!/bin/sh
set -eu

# AppHaven CLI installer for Linux/macOS
# Usage: sh install-cli.sh  (bundled copy of github.com/apphaven-eu/cli install.sh)

BASE_URL="${APPHAVEN_DOWNLOAD_BASE:-https://github.com/apphaven-eu/cli/releases/latest/download}"

detect_os() {
  os="$(uname -s | tr '[:upper:]' '[:lower:]')"
  case "$os" in
    linux)  echo "linux" ;;
    darwin) echo "darwin" ;;
    *)      echo "Unsupported OS: $os" >&2; exit 1 ;;
  esac
}

detect_arch() {
  arch="$(uname -m)"
  case "$arch" in
    x86_64|amd64) echo "amd64" ;;
    aarch64|arm64) echo "arm64" ;;
    *)             echo "Unsupported architecture: $arch" >&2; exit 1 ;;
  esac
}

install_dir() {
  if [ -w /usr/local/bin ]; then
    echo "/usr/local/bin"
  else
    mkdir -p "${HOME}/.local/bin"
    echo "${HOME}/.local/bin"
  fi
}

compute_sha256() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    echo "Error: no sha256sum or shasum found" >&2
    exit 1
  fi
}

main() {
  os="$(detect_os)"
  arch="$(detect_arch)"
  binary="apphaven-${os}-${arch}"
  dir="$(install_dir)"
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT

  echo "Downloading apphaven for ${os}/${arch}..."
  curl -fsSL "${BASE_URL}/${binary}" -o "${tmp}/apphaven"
  curl -fsSL "${BASE_URL}/checksums.txt" -o "${tmp}/checksums.txt"

  echo "Verifying checksum..."
  expected="$(grep "${binary}" "${tmp}/checksums.txt" | awk '{print $1}')"
  if [ -z "$expected" ]; then
    echo "Error: checksum not found for ${binary}" >&2
    exit 1
  fi
  actual="$(compute_sha256 "${tmp}/apphaven")"
  if [ "$expected" != "$actual" ]; then
    echo "Error: checksum mismatch" >&2
    echo "  expected: $expected" >&2
    echo "  actual:   $actual" >&2
    exit 1
  fi

  chmod +x "${tmp}/apphaven"
  mv "${tmp}/apphaven" "${dir}/apphaven"
  echo "Installed apphaven to ${dir}/apphaven"

  if ! echo "$PATH" | tr ':' '\n' | grep -qx "$dir"; then
    echo ""
    echo "Note: ${dir} is not in your PATH."
    echo "Add it with: export PATH=\"${dir}:\$PATH\""
  fi
}

main
