# AppHaven CLI installer for Windows
# Usage: powershell -ExecutionPolicy Bypass -File install-cli.ps1  (bundled copy of github.com/apphaven-eu/cli install.ps1)

$ErrorActionPreference = "Stop"

$BaseUrl = if ($env:APPHAVEN_DOWNLOAD_BASE) { $env:APPHAVEN_DOWNLOAD_BASE } else { "https://github.com/apphaven-eu/cli/releases/latest/download" }
$Arch = if ([System.Environment]::Is64BitOperatingSystem) {
    if ([System.Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture -eq [System.Runtime.InteropServices.Architecture]::Arm64) {
        "arm64"
    } else {
        "amd64"
    }
} else {
    Write-Error "Unsupported architecture"
    exit 1
}

$Binary = "apphaven-windows-${Arch}.exe"
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\apphaven"
$InstallPath = Join-Path $InstallDir "apphaven.exe"

Write-Host "Downloading apphaven for windows/${Arch}..."

# Create install directory
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

# Download binary and checksums
$TempDir = Join-Path $env:TEMP "apphaven-install-$(Get-Random)"
New-Item -ItemType Directory -Path $TempDir -Force | Out-Null
try {
    Invoke-WebRequest -Uri "${BaseUrl}/${Binary}" -OutFile (Join-Path $TempDir "apphaven.exe") -UseBasicParsing
    Invoke-WebRequest -Uri "${BaseUrl}/checksums.txt" -OutFile (Join-Path $TempDir "checksums.txt") -UseBasicParsing

    # Verify checksum
    Write-Host "Verifying checksum..."
    $checksums = Get-Content (Join-Path $TempDir "checksums.txt")
    $expected = ($checksums | Where-Object { $_ -match $Binary }) -replace "\s+.*$", ""
    if (-not $expected) {
        Write-Error "Checksum not found for ${Binary}"
        exit 1
    }
    $actual = (Get-FileHash -Path (Join-Path $TempDir "apphaven.exe") -Algorithm SHA256).Hash.ToLower()
    if ($expected -ne $actual) {
        Write-Error "Checksum mismatch: expected $expected, got $actual"
        exit 1
    }

    # Install
    Move-Item -Path (Join-Path $TempDir "apphaven.exe") -Destination $InstallPath -Force
    Write-Host "Installed apphaven to $InstallPath"

    # Add to PATH if not already there
    $UserPath = [Environment]::GetEnvironmentVariable("PATH", "User")
    if ($UserPath -notlike "*$InstallDir*") {
        [Environment]::SetEnvironmentVariable("PATH", "$UserPath;$InstallDir", "User")
        Write-Host "Added $InstallDir to user PATH. Restart your terminal for changes to take effect."
    }
} finally {
    Remove-Item -Path $TempDir -Recurse -Force -ErrorAction SilentlyContinue
}
