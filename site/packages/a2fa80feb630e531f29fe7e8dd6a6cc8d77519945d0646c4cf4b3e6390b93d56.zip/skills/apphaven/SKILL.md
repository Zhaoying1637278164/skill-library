---
name: apphaven
description: Work with apps hosted on AppHaven. Use when the user asks about an AppHaven deployment (is it deployed/running, on what URL), build failures or logs, container/runtime logs, crashes, app configuration/variables, or when writing or editing apphaven.yaml. Also use to set up AppHaven access (install the apphaven CLI, log in).
---

# AppHaven

AppHaven hosts applications straight from a Git repository: a push builds the app (from its
Dockerfile) and deploys it on a real URL over HTTPS, with managed PostgreSQL, backups, and login
available as platform features. The deploy model: **push the production branch → production
deploys; push a branch matching the app's preview pattern (default `preview/*`) → it deploys as a
preview on its own URL with its own data.** Your iteration loop is therefore: push, then check
the preview, then merge.

What actually auto-deploys is per-app configuration — check it before assuming.
`apphaven app <name>` prints it as `Auto-deploy:`, one of *Off* (every deploy is a human clicking
in the console), *Production branch only* (a preview branch needs a human to deploy it), or
*Production + preview branches matching "<pattern>" (max N previews)*. When previews are on, name
your branch to match the pattern — that naming **is** the deploy trigger.

The `apphaven` CLI is your read-only window onto the platform. It can never change platform state,
so you can run it freely.

## Setup (drive it end to end)

1. `apphaven version` — if the CLI is missing, install it with the installer bundled in this
   skill's `scripts/` folder. It downloads the latest binary from the CLI's GitHub releases and
   verifies its SHA-256 checksum, so show the user the command and get their OK before running it
   (pick by shell):
   - Linux/macOS/WSL: `sh "${CLAUDE_SKILL_DIR}/scripts/install-cli.sh"`
   - Windows PowerShell: `powershell -NoProfile -ExecutionPolicy Bypass -File "${CLAUDE_SKILL_DIR}\scripts\install-cli.ps1"`
2. Run `apphaven login` — but first tell the user: *"a browser tab will open on auth.apphaven.eu
   asking you to approve read-only access — approve it there."* The command prints the
   authorization URL too (in case the browser doesn't open from this shell) and blocks until the
   user approves (default timeout 5 min).
3. Confirm with `apphaven whoami`.

Running `login` yourself is safe by design: tokens are written straight to the CLI's credentials
file and **never appear in command output**. The browser approval is the user's step.

- If any command answers `Not logged in. Run "apphaven login".` — the grant was revoked or
  expired; redo step 2.
- **Headless or firewalled environment** (SSH box, container, sandbox — the browser can't reach
  this machine): don't run `login` yourself; the fallback needs an interactive paste. Ask the user
  to run `apphaven login --manual` in their own terminal, open the printed URL on any device, and
  paste the code the approval page shows.

## CLI quick reference

Every command supports `--json`. `apphaven <cmd> --help` is the runtime truth if this list and the
installed CLI disagree.

| Command | What it answers |
|---|---|
| `apphaven projects` / `apps` | What exists, and the ids/names other commands take |
| `apphaven app <name>` | One overview: source repo/branch config, URLs, per-branch deployments |
| `apphaven status <app>` | Deployment phase (`Pending`/`Running`/`Stopped`/`Failed`), branch, URL; `--wait` blocks until Running/Failed (`--wait-timeout`, default 10m) |
| `apphaven builds <app>` | Build history: branch, commit, outcome, duration |
| `apphaven build-log <app> [buildId]` | Build log (defaults to the latest build) |
| `apphaven logs <app> --service <svc>` | Container output; `--tail`, `--since`, `--until`, `--follow`; `--branch` picks a preview deployment (default: newest) |
| `apphaven crash-log <app>` | Captured output of a failed deployment's containers; `--branch` as above |
| `apphaven variables <app>` | Variable names + non-secret values (secrets always masked) |
| `apphaven events <app>` | Activity timeline: deploys, build outcomes, config changes; `--limit N` |
| `apphaven vulns <app>` | Vulnerability findings from the latest security scan per service, with the version to update to; `--history` for past scans, `--scan <id>` for one of them |
| `apphaven validate [file]` | Validate `apphaven.yaml` (defaults to ./apphaven.yaml) |
| `apphaven docs [topic]` | Deep links into the documentation |

If an app name is ambiguous, pass `--project <name>`. `apphaven logout` revokes the grant and
deletes the stored credentials; only run it when the user asks.

## Debugging playbook (in order)

1. `apphaven status <app>` — what phase is it in?
2. Build failed → `apphaven build-log <app>` — the error is at the tail.
3. Deployment `Failed` → `apphaven crash-log <app>` — the containers are gone, this is what they
   said while dying.
4. `Running` but misbehaving → `apphaven logs <app> --service <svc>`; then
   `apphaven variables <app>` for missing/misnamed configuration.
5. Manifest rejected → fix and re-check with `apphaven validate` before pushing.

## Fixing reported vulnerabilities

AppHaven scans every build (and re-scans production nightly against fresh CVE data) using the
SBOM of what was actually built — OS packages and application dependencies. When the user asks
about security findings, or `apphaven status` shows a `Security:` line:

1. `apphaven vulns <app>` (or `--json`) — each finding names the vulnerable package, the
   installed version, and the fix: `update to <version>` when a fixed release exists,
   `not available` when none is released yet.
2. Fix what has a fix version: bump the dependency in the repo's manifest/lockfile to at least
   that version, or — for OS packages — update the Dockerfile base image and rebuild.
   `not available` findings usually have no action beyond noting them to the user.
3. Push (preview branch first if the app has previews); the next build is scanned automatically,
   so `apphaven vulns <app>` after the deploy verifies the findings are gone.

The scan covers the app's own dependency tree — treat findings as the platform pointing at the
repo you can edit, not at AppHaven itself.

## Getting a preview in front of the user

The standard way to hand the user a change they can click through:

1. Commit on a branch matching the app's preview pattern (see `Auto-deploy:` in
   `apphaven app <name>`; default `preview/*`) and push it.
2. `apphaven status <app> --wait` — when the new branch's deployment reaches `Running`, give the
   user its URL.
3. The user opens the link and signs in with their AppHaven account (previews are
   access-protected by default). **You cannot fetch the preview page yourself** — the login wall
   is by design; never try to get around it. The user is the one previewing.

If no deployment for your branch appears, check `apphaven events <app>`:

- **`Preview limit reached`** — the app is at its preview cap. Nothing is evicted automatically;
  tell the user: *"the app is at its preview limit (N); delete an old preview in the console,
  then I'll push again"* (a fresh push retries — or they can click Deploy on the branch in the
  console). Never suggest which preview to delete or try to free capacity yourself.
- **`Auto-deploy failed`** / a quota error — read the message; it names the fix.
- No event at all — the branch probably doesn't match the pattern; rename and re-push, or ask
  the user to deploy it from the console.

Preview lifecycle facts worth relaying when relevant: previews are **not backed up**; a preview
idle for 30 days is stopped but keeps its data, and the next push to the branch resumes it;
**deleting the branch deletes the preview and its data**; merging to the production branch is
what ships the change to production.

## Writing `apphaven.yaml`

The manifest is AppHaven's own schema — **not** docker-compose. Validation is **fail-closed**:
any field the schema doesn't define is an error (there is no compose passthrough, no
`privileged`, no host bind mounts). Always run `apphaven validate` before pushing.

- Top level: `version` (currently `1`), `services` (at least one), `volumes` (only if mounted),
  `auth` (optional, suggestions only — see "Paths that must skip the login" below).
- Service `type: container`: `image` **or** `build` (`dockerfile`, `context`, `args`); plus
  `ports` (list of ints), `env` (string map), `volumes` (`{name, mount_path}` — `mount_path`
  absolute and canonical), `healthcheck`, `depends_on`.
- Service `type: postgres`: a managed database — only `version` (`"17"`).
  It takes no `image`/`env`/`ports`; AppHaven provisions engine, storage, credentials, and a
  healthcheck. Storage comes from the deployment's overall budget, not a per-database setting.
- **Interpolation** in `env` values and `build.args`: `${service.<name>.<field>}` (a managed
  service's `url`, `host`, `port`, `user`, `password`, `database`) and `${env.<NAME>}` (a
  console-defined variable/secret). Unresolvable references fail validation. Literal `${` is
  escaped `$${`.
- `depends_on: [{service: <name>, condition: started|healthy}]` — `healthy` requires the target
  to have a healthcheck (managed postgres has one). No cycles. Referencing `${service.db.url}`
  does **not** imply ordering; declare `depends_on` explicitly if the app must wait.
- Healthcheck: `test: ["CMD-SHELL", "<cmd>"]` (or `["CMD", ...]`), `interval`/`timeout` like
  `10s`, `retries`, `start_period`. Durations are `<int>s|m`, bounded 1s–5m.

Common validation errors read like: `service web: unknown field "privileged"` ·
`service web: image or build is required` · `service db: "ports" is not allowed on a postgres
service` · `service web depends_on db (healthy) but db has no healthcheck` ·
`service web: ${service.cache.url} — no service "cache"`. They are written to be actionable —
fix exactly what they name.

Worked example (web app built from source + managed database + persistent uploads):

```yaml
# yaml-language-server: $schema=https://docs.apphaven.eu/schemas/apphaven.schema.json
version: 1

services:
  web:
    type: container
    build:
      dockerfile: Dockerfile
      context: .
    ports:
      - 3000
    env:
      NODE_ENV: production
      DATABASE_URL: ${service.db.url}
    volumes:
      - name: uploads
        mount_path: /app/uploads

  db:
    type: postgres
    version: "17"

volumes:
  uploads:
    type: persistent
```

Put the `# yaml-language-server: $schema=…` comment at the top of every manifest you write — it
gives editors (and you) inline validation.

## Paths that must skip the login

An app can be protected by AppHaven's own login. When it is, every request needs a session, which
breaks endpoints meant for machines: an external REST API, a webhook receiver, an uptime probe.

You can **suggest** which paths should be reachable anonymously, but you cannot grant one. The
manifest lives in the repo you write to, so a manifest that could switch off authentication by
itself would let you widen the app's attack surface with a commit. A project admin has to add each
one in the console.

```yaml
auth:
  public_paths:
    - path: /api/*
      reason: Partner REST API, authenticated by our own API keys
    - path: /healthz
      reason: Uptime probe
```

Two pattern forms only: an exact path (`/healthz`, or `/` for the root path and nothing below it),
or a single trailing `/*` (`/api/*`, which covers `/api/` and everything below it). `reason` is
required and is what the admin reads when deciding. At most 10 suggestions, 128 characters each.

The loop to follow:

1. Add the suggestion, with a reason that explains why anonymous access is safe for that path.
2. Tell the human what you suggested and that they have to grant it in the console.
3. `apphaven app <name>` shows the granted list and any suggestion still waiting.

Until it is granted, a redirect to the login page on that path is **correct behaviour**. Do not
debug it, retry it, or re-suggest it — the answer just has not come yet.

Two things to design around once a path is granted: the request arrives with no `X-Apphaven-Auth`
header at all, so the app must authenticate it itself; and the exemption covers the path, not the
query string, so every query on a public path is public too.

## Hard boundaries

The CLI is **read-only**. It cannot deploy, restart, stop, change variables or configuration,
delete anything, or reveal secret values — and neither can you through it. The deploy trigger is
`git push` (to the production branch, or to a branch matching the preview pattern); everything
else — deploying other branches, deleting previews, changing the deploy settings — is the human
in the console. When asked to do any of those, say so and point at the right path; never attempt
workarounds.

## Pointers

- Documentation: https://docs.apphaven.eu — agent setup: https://docs.apphaven.eu/agent-integration
- Manifest reference: https://docs.apphaven.eu/reference/manifest
- Whole docs in one fetch: https://docs.apphaven.eu/llms-full.txt (index: /llms.txt)
- Manifest JSON Schema: https://docs.apphaven.eu/schemas/apphaven.schema.json
