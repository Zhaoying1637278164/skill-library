---
description: Scaffold a new oryxflow project into the current directory from the bundled minimal template (skip-existing, never overwrite).
disable-model-invocation: true
---

# Scaffold a new oryxflow project

Copy the bundled minimal oryxflow template into the user's project directory so they
have a runnable starting point.

- Template source: `${CLAUDE_PLUGIN_ROOT}/resources/template-minimal/`
- Target: the current project directory `${CLAUDE_PROJECT_DIR}` (where Claude Code
  was launched).

Follow these steps exactly.

## 1. Pre-flight - do not clobber an existing project

Inspect the target directory. If it ALREADY looks like a oryxflow project - any of
`tasks.py`, `flow.py`, or `CLAUDE.md` exist - STOP. Do not copy anything yet.
Report what you found and ask the user whether they want to (a) scaffold only the
missing files, or (b) cancel. Proceed only on their answer.

If the directory has no oryxflow files, continue.

## 2. Copy the template (skip-existing, never overwrite)

Copy every file and subdirectory from the template source into the target,
preserving the layout (including `docs/`). One hard rule: NEVER overwrite a file
that already exists in the target - skip it and remember it for the report.

Do the copy with a single SHELL COPY COMMAND. Do NOT read the template files into
context and re-write them with the Write tool - that is slow and can corrupt
binary-ish files like `viz-template.ipynb`. Pick the copy command by PLATFORM and
use it consistently - do not improvise a different one each run:

- **Windows (the default here): `robocopy`** via the PowerShell tool:
  `robocopy "<src>" "<dst>" /E /XC /XN /XO` (the `/XC /XN /XO` flags skip files
  that already exist in the target). This is the standard path on this OS - reach
  for `robocopy` first, not `cp` / `Copy-Item`.
- macOS / Linux: `cp -rn "<src>/." "<dst>/"` (`-n` = no-clobber).

**robocopy exit codes are NOT shell errors.** robocopy returns 0-7 on SUCCESS
(1 = files copied, 0 = nothing to copy, 2/3 = extras present) and only >= 8 is a
real failure. Exit code 1 means the copy worked - do NOT treat it as an error or
retry with a different command. Only investigate when the code is >= 8.

After the copy, diff the source and target file lists to determine what was newly
created vs skipped (for the report) - again via shell (e.g. compare directory
listings), not by reading file contents.

The template contains the project wiring (`cfg.py`, `flow_params.py`, `flow.py`,
`run.py`, `tasks.py`, `visualize.py`, `viz-template.ipynb`), `CLAUDE.md`,
`.gitignore`, `.creds.yaml.example`, and `docs/oryxflow-data.md`. `tasks.py` and
`flow_params.py` ship with a `PLACEHOLDER SCAFFOLD` marker (and `tasks.py`'s
module + task docstrings are placeholders); `docs/oryxflow-data.md` ships with a
`PLACEHOLDER` marker on line 1. Those markers are intentional - leave them; they
are replaced when the real pipeline and data findings are written. (Pipeline
documentation lives in the code's docstrings, not a separate doc.)

## 3. Create the data directory

Ensure an empty `data/` exists in the target (it is gitignored; oryxflow writes
per-task parquet outputs there).

## 4. Report

Tell the user exactly which files were CREATED and which were SKIPPED (already
present). If `CLAUDE.md` was skipped, note the template version lives at
`${CLAUDE_PLUGIN_ROOT}/resources/template-minimal/CLAUDE.md` for them to diff.

Finish with the next steps: the scaffold runs as-is (`python run.py`) but does no
real work yet; replace the `PLACEHOLDER SCAFFOLD` tasks in `tasks.py` with the real
pipeline (documenting them via the module + task docstrings), and fill
`docs/oryxflow-data.md` as data findings accumulate.
