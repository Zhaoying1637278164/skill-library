# devils-advocate

> A **devil's advocate agent** for Claude Code. Place it at the end of any plan / design / multi-agent review pipeline to break groupthink — with the strict rule: *only fatal points, and every point must come with a fix*.

[English](#english) | [日本語](#日本語)

---

## English

### What does it do?

Run `/devils-advocate` and the agent reviews the most recent plan, design, or review output and returns:

- **Fatal points only** (no nitpicks)
- **Every point paired with a concrete fix or alternative** (no pure negativity)
- **Numbers, facts, and specifics** (no vibes)
- A final verdict: *Agree / Conditional Agree / Object*
- A forward-looking closing line: *"Fix this and it becomes the real thing"*

### Why this exists

Parallel agents and review panels share the same priors, so they share the same blind spots:

- The plan everyone agreed on quietly fails in production
- The design no one objected to dies on the first user touchpoint
- The multi-agent synthesis report is drenched in optimism bias

This plugin is the *last gate* — a single command that injects an opposing perspective right before you ship the decision.

### Design principles

#### Do
- Surface only **fatal** problems
- Pair every problem with a **fix or alternative**
- Strike with **numbers, facts, and concrete examples**

#### Don't
- Pure negativity ("this won't work")
- Pedantic nitpicks, style critique, preference enforcement
- Problems without proposed fixes

### Review axes (general checklist)

| # | Axis |
|---|---|
| A | Plan / design itself |
| B | Validity of expected outcomes |
| C | User / recipient blind spots |
| D | Execution and ops reality |
| E | Technical implementation pitfalls |
| F | Legal / ethics / policy |
| G | Risk management |

### Installation

#### From the official marketplace (in review)

```
/plugin install devils-advocate
```

#### Directly from GitHub

```bash
git clone https://github.com/keitashimoda24-maker/devils-advocate.git \
  ~/.claude/plugins/devils-advocate
```

Then run `/reload-plugins` in Claude Code.

### Usage

Once a plan, design, or integrated report exists in the conversation:

```
/devils-advocate
```

Output format:

- Up to 3 fatal points, each with a fix
- Optimism bias warnings
- Blind-spot angles everyone missed
- Final verdict
- Forward-looking single closing line

### Recommended use cases

- Final check on multi-agent integrated reports
- Second opinion before major decisions
- An additional pass on top of standard code/design reviews
- Self-review of your own plans and proposals

---

## 日本語

### 何ができる？

`/devils-advocate` を実行すると、直前の計画・設計・レビュー結果に対して以下を返します:

- **致命傷レベルの指摘のみ**（重箱の隅はNG）
- 各指摘に**必ず改善案 or 代替案がセット**で付くので、単なるダメ出しで終わらない
- **数字・事実・具体例で殴る**（感情論禁止）
- 最終判定（同意 / 条件付き同意 / 異議あり）
- 前向きな最終1行（「ここを直せば本物になる」）

### なぜ作ったか

並列稼働する複数の専門家・エージェントは、**同じ前提から発想するため集団思考バイアスに陥りがち**です。

- 全員が「いける」と言った企画が大コケする
- レビュー会で誰も反対しなかった設計が本番でハマる
- マルチエージェントの統合レポートが楽観バイアスまみれになる

→ このプラグインは「最後の砦としての否定役」を1コマンドで起動します。

### 設計思想

#### Do
- **致命傷レベルの指摘のみ**（重箱の隅はNG）
- 各指摘に**必ず改善案を添える**
- 数字・事実・具体例で殴る（感情論禁止）

#### Don't
- 単なる否定で終わる「ダメ出し」
- 揚げ足取り・文体批判・好みの押しつけ
- 改善案なしの「これは無理」

### レビュー観点（汎用チェックリスト）

A. 企画/設計そのものへの疑い
B. 想定成果の妥当性
C. ユーザー/受け手視点の罠
D. 実行・運用の現実
E. 技術・実装の落とし穴
F. 法務・倫理・規約
G. リスク管理

### インストール

#### 公式マーケットから（レビュー待ち）

```
/plugin install devils-advocate
```

#### GitHub から直接

```bash
git clone https://github.com/keitashimoda24-maker/devils-advocate.git \
  ~/.claude/plugins/devils-advocate
```

その後 Claude Code で `/reload-plugins` を実行。

### 使い方

レビュー対象（計画書・設計書・統合レポート等）が会話に存在する状態で:

```
/devils-advocate
```

エージェントが起動し、以下フォーマットで出力します:

- 致命傷指摘（最大3つ、改善案セット）
- 楽観バイアスへの警告
- 全員が見落とした角度
- 最終判定（同意 / 条件付き同意 / 異議あり）
- 前向きな最終1行

### 推奨ユースケース

- マルチエージェント統合レポートの最終チェック
- 重要な意思決定前のセカンドオピニオン
- コードレビュー・設計レビュー結果への上乗せレビュー
- 自分が書いた企画書・提案書のセルフチェック

---

## Background

This pattern came out of running multi-agent pipelines for real operational decisions (shift scheduling, payroll distribution, expense audits) across 10 convenience stores. Every time I added another "specialist" agent, the integrated report got *more* confident — not more correct. The fix wasn't a smarter specialist; it was a structurally adversarial final gate.

## Author

[@keitashimoda24-maker](https://github.com/keitashimoda24-maker)

Non-engineer area manager running 10 convenience stores in Japan, building daily automation with Claude Code (30+ systems and counting).

## Related Projects

- [claude-code-smart-hooks](https://github.com/keitashimoda24-maker/claude-code-smart-hooks) — Conditional ultrathink injection for consistent reasoning depth
- [slash-commands-jp](https://github.com/keitashimoda24-maker/slash-commands-jp) — Japanese slash command reference plugin
- [mac-pixel-bridge](https://github.com/keitashimoda24-maker/mac-pixel-bridge) — Resilient ADB clipboard / screenshot bridge

## License

MIT — see [LICENSE](LICENSE).
