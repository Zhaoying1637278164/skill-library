# Security Policy

## Supported Versions

`mypowers` is released as a rolling plugin and does not currently maintain long-lived version branches.

- Supported: latest commit on `master`
- Older commits and forks: best effort only

## Reporting A Vulnerability

Please report vulnerabilities privately through GitHub Security Advisories:

1. Open the repository Security tab.
2. Select "Report a vulnerability".
3. Share clear reproduction steps, impact, and affected files.

If private reporting is not available in your environment, open a minimal public issue without exploit details and request a private handoff channel.

## Response Targets

- Initial acknowledgment: within 72 hours
- Triage decision: within 7 days
- Patch timeline: based on severity and exploitability

We prioritize fixes for credential exposure, secret scanning bypasses, hook bypasses, integrity-attestation bypasses, and remote command execution risks.