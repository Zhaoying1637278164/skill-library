#!/bin/sh
set -eu

for test_file in \
  tests/test_repo_layout.sh \
  tests/test_manifests.sh \
  tests/test_posture.sh \
  tests/test_superpowers.sh \
  tests/test_lib.sh \
  tests/test_scan.sh \
  tests/test_fast_gate.sh \
  tests/test_commit_gate.sh \
  tests/test_bridge_import.sh \
  tests/test_attest.sh \
  tests/test_skill_contract_part1.sh \
  tests/test_docs_and_agents.sh \
  tests/test_repo_smoke.sh
do
  sh "$test_file"
done

echo "PASS: tests/run-all.sh"
