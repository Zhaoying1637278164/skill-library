#!/bin/sh
set -eu

HOOK="hooks/pre-edit-security/claude-hook.sh"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

check() {
  label="$1"
  expected="$2"
  actual="$3"
  if [ "$expected" != "$actual" ]; then
    echo "FAIL: $label (expected=$expected actual=$actual)" >&2
    exit 1
  fi
}

result="$(printf '' | sh "$HOOK")"
check "empty stdin" "{}" "$result"

result="$(printf '{"tool_input":{"file_path":"/tmp/does-not-exist-fast-gate.sh"}}' | sh "$HOOK")"
check "nonexistent file" "{}" "$result"

tmp_clean="$TMP_DIR/clean.sh"
printf 'echo hello\n' >"$tmp_clean"
result="$(printf '{"tool_input":{"file_path":"%s"}}' "$tmp_clean" | sh "$HOOK")"
check "clean existing file" "{}" "$result"

tmp_secret="$TMP_DIR/secret.sh"
printf 'GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyzABCDEFGHIJ\n' >"$tmp_secret"
result="$(printf '{"tool_input":{"file_path":"%s"}}' "$tmp_secret" | sh "$HOOK")"
check "secret file blocked" "1" "$(echo "$result" | grep -c 'permissionDecision":"deny' || echo 0)"

result="$(printf '{"tool_input":{"file_path":"/tmp/../etc/passwd"}}' | sh "$HOOK")"
check "path traversal blocked" "1" "$(echo "$result" | grep -c 'path traversal' || echo 0)"

result="$(printf 'not{{json' | sh "$HOOK")"
check "malformed payload parser warning" "1" "$(echo "$result" | grep -c 'parser_warning' || echo 0)"

tmp_binary="$TMP_DIR/data.bin"
printf '\000\001\002binary' >"$tmp_binary"
result="$(printf '{"tool_input":{"file_path":"%s"}}' "$tmp_binary" | sh "$HOOK")"
check "binary file skipped" "{}" "$result"

echo "PASS: tests/test_fast_gate.sh"
