#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
PATH="/usr/bin:/bin"
export PATH

TARGET="$TMP_DIR/sample.txt"
OUT_DIR="$TMP_DIR/out"
BATCH_DIR="$TMP_DIR/batch-vault"
BATCH_FORTRESS="$TMP_DIR/batch-fortress.md"
mkdir -p "$OUT_DIR" "$BATCH_DIR"
printf '%s\n' 'hello mypowers' >"$TARGET"
export CLAUDE_CODE_PERMISSION_MODE=auto

[ -x scripts/attest.sh ]

sh scripts/attest.sh "$TARGET" "$OUT_DIR" >"$TMP_DIR/attest.out"

MANIFEST_FILE="$(find "$OUT_DIR" -type f -name '*.json' | head -n 1)"
[ -n "$MANIFEST_FILE" ]
grep '"provenance":"local-merkle"' "$MANIFEST_FILE" >/dev/null
grep '"status":"attested"' "$MANIFEST_FILE" >/dev/null
grep '"claude_permission_mode":"AUTO"' "$MANIFEST_FILE" >/dev/null
grep '"merkle_root":"' "$MANIFEST_FILE" >/dev/null
grep '"status":"attested"' "$TMP_DIR/attest.out" >/dev/null

FORTRESS_BIBLE="$OUT_DIR/fortress-bible.md"
[ -f "$FORTRESS_BIBLE" ]
grep '^Merkle Root: ' "$FORTRESS_BIBLE" >/dev/null
grep '^Security Posture: ' "$FORTRESS_BIBLE" >/dev/null
grep '^- Claude Code permission mode: AUTO' "$FORTRESS_BIBLE" >/dev/null

FILE_ONE="$TMP_DIR/a.sh"
FILE_TWO="$TMP_DIR/b.sh"
printf '%s\n' 'echo a' >"$FILE_ONE"
printf '%s\n' 'echo b' >"$FILE_TWO"

MYPOWERS_VAULT_DIR="$BATCH_DIR" MYPOWERS_FORTRESS_BIBLE="$BATCH_FORTRESS" sh scripts/attest.sh --batch "$FILE_ONE" "$FILE_TWO" >"$TMP_DIR/attest-batch.out"

BATCH_MANIFEST_COUNT="$(find "$BATCH_DIR" -maxdepth 1 -type f -name 'pre-commit-*.json' | wc -l | tr -d ' ')"
[ "$BATCH_MANIFEST_COUNT" = "1" ]

BATCH_MANIFEST="$(find "$BATCH_DIR" -maxdepth 1 -type f -name 'pre-commit-*.json' | head -n 1)"
[ -n "$BATCH_MANIFEST" ]

BATCH_NAME="$(basename "$BATCH_MANIFEST")"
echo "$BATCH_NAME" | grep -E '^pre-commit-[0-9TZ:-]+-[a-f0-9]{4}\.json$' >/dev/null

grep '"mode":"batch"' "$BATCH_MANIFEST" >/dev/null
grep '"status":"attested"' "$BATCH_MANIFEST" >/dev/null

BATCH_ENTRIES="$(grep -c 'pre-commit-' "$BATCH_FORTRESS" || true)"
[ "$BATCH_ENTRIES" = "1" ]

TMP_FILE_COUNT="$(find "$BATCH_DIR" -maxdepth 1 -type f -name '*.tmp*' | wc -l | tr -d ' ')"
[ "$TMP_FILE_COUNT" = "0" ]

grep '"mode":"batch"' "$TMP_DIR/attest-batch.out" >/dev/null

echo "PASS: tests/test_attest.sh"
