#!/bin/sh
set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
repo_root=$(CDPATH= cd -- "$script_dir/.." && pwd)

python3 - "$repo_root" <<'PY'
import json
import sys
from pathlib import Path
from pprint import pformat

repo_root = Path(sys.argv[1])

required_files = {
    ".codex-plugin/plugin.json": repo_root / ".codex-plugin/plugin.json",
    ".claude-plugin/plugin.json": repo_root / ".claude-plugin/plugin.json",
    "commands/mypowers.json": repo_root / "commands/mypowers.json",
}

for label, path in required_files.items():
    if not path.exists():
        raise SystemExit(f"missing required file: {label}")

expected_codex = {
    "name": "mypowers",
    "description": "mypowers – Zero-Trust AI Co-Founder OS for Codex with progressive FULL/PARTIAL/BASIC security posture and portable shared scripts.",
    "author": {
        "name": "Rohan Reddy",
        "url": "https://github.com/rohanreddy",
    },
    "homepage": "https://github.com/rohanreddy/mypowers",
    "repository": "https://github.com/rohanreddy/mypowers",
    "license": "MIT",
    "keywords": [
        "security",
        "zero-trust",
        "plugin",
        "orchestrator",
        "portable",
    ],
    "skills": "./skills/",
    "interface": {
        "displayName": "mypowers – Zero-Trust AI Co-Founder OS",
        "shortDescription": "mypowers – Zero-Trust AI Co-Founder OS for Codex and Claude Code",
        "longDescription": "mypowers – Zero-Trust AI Co-Founder OS with eight shared skills, portable POSIX scripts, progressive security posture, and lightweight cross-tool setup guidance.",
        "developerName": "Rohan Reddy",
        "category": "Productivity",
        "capabilities": [
            "Interactive",
            "Write",
        ],
        "websiteURL": "https://github.com/rohanreddy/mypowers",
        "defaultPrompt": [
            "Run the mypowers forge workflow with truthful posture reporting.",
            "Verify a bridge import artifact before using it in code.",
            "Show me the current security posture and next hardening step.",
        ],
        "brandColor": "#1F6F78",
    },
}

expected_claude = {
    "name": "mypowers",
    "description": "mypowers – Zero-Trust AI Co-Founder OS for Claude Code with native hook registration, permission-mode-aware FULL/PARTIAL/BASIC posture reporting, and portable shared scripts.",
    "author": {
        "name": "Rohan Reddy",
        "url": "https://github.com/rohanreddy",
    },
    "license": "MIT",
    "homepage": "https://github.com/rohanreddy/mypowers",
    "repository": "https://github.com/rohanreddy/mypowers",
    "keywords": [
        "claude-code",
        "security",
        "zero-trust",
        "hooks",
        "skills",
        "orchestrator",
        "portable",
    ],
    "agents": [
        "./agents/visionary-agent.md",
        "./agents/analyst-agent.md",
        "./agents/security-auditor-agent.md",
        "./agents/executor-agent.md",
    ],
    "skills": [
        "./skills/",
    ],
    "commands": [
        "./commands/claude/",
    ],
    "hooks": {
        "PreToolUse": [
            {
                "matcher": "Edit|Write|MultiEdit",
                "hooks": [
                    {
                        "type": "command",
                        "command": "sh \"${CLAUDE_PLUGIN_ROOT}/hooks/pre-edit-security/claude-hook.sh\"",
                        "timeout": 5,
                        "statusMessage": "mypowers secret scan",
                    }
                ],
            },
            {
                "matcher": "Bash",
                "hooks": [
                    {
                        "type": "command",
                        "command": "sh \"${CLAUDE_PLUGIN_ROOT}/hooks/commit-gate/claude-hook.sh\"",
                        "timeout": 30,
                        "statusMessage": "mypowers commit gate",
                    }
                ],
            }
        ],
    },
}

expected_commands = {
    "namespace": "mypowers",
    "commands": [
        {
            "name": "forge",
            "description": "Run the end-to-end mypowers orchestrator workflow.",
        },
        {
            "name": "next",
            "description": "Show the next recommended orchestrator action for the current posture.",
        },
        {
            "name": "status",
            "description": "Summarize the current forge phase, posture, and pending follow-ups.",
        },
        {
            "name": "bridge-import",
            "description": "Verify and import a Decision Artifact through zero-trust checks.",
        },
        {
            "name": "security-oracle",
            "description": "Run the shared posture and scan pipeline.",
        },
        {
            "name": "setup-tools",
            "description": "Print recommended install commands for the full security stack.",
        },
        {
            "name": "setup-hooks",
            "description": "Print one-time hook registration snippets for the current tool.",
        },
    ],
}


def check_equal(actual, expected, label):
    if actual != expected:
        raise SystemExit(
            f"{label} did not match expected structure\n"
            f"expected: {pformat(expected, width=100)}\n"
            f"actual:   {pformat(actual, width=100)}"
        )


check_equal(json.loads(required_files[".codex-plugin/plugin.json"].read_text()), expected_codex, ".codex-plugin/plugin.json")
check_equal(json.loads(required_files[".claude-plugin/plugin.json"].read_text()), expected_claude, ".claude-plugin/plugin.json")
check_equal(json.loads(required_files["commands/mypowers.json"].read_text()), expected_commands, "commands/mypowers.json")
PY

echo "PASS: tests/test_manifests.sh"
