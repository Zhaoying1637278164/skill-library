#!/bin/sh
set -eu

HOOK="hooks/commit-gate/claude-hook.sh"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

check_eq() {
  label="$1"
  expected="$2"
  actual="$3"
  if [ "$expected" != "$actual" ]; then
    echo "FAIL: $label (expected=$expected actual=$actual)" >&2
    exit 1
  fi
}

check_contains() {
  label="$1"
  haystack="$2"
  needle="$3"
  if ! printf '%s' "$haystack" | grep -F "$needle" >/dev/null; then
    echo "FAIL: $label (missing '$needle')" >&2
    exit 1
  fi
}

non_git_result="$(printf '{"tool_input":{"command":"echo hello"}}' | sh "$HOOK")"
check_eq "non-git command passthrough" "{}" "$non_git_result"

parser_warning_result="$(printf '{"tool_input":{"foo":"bar"}}' | sh "$HOOK")"
check_contains "parser warning when command missing" "$parser_warning_result" "parser_warning"

rebase_result="$(printf '{"tool_input":{"command":"git rebase main"}}' | sh "$HOOK")"
check_contains "rebase coverage note" "$rebase_result" "coverage_note"

REPO="$TMP_DIR/repo"
mkdir -p "$REPO"

git -C "$REPO" init -q
git -C "$REPO" config user.email "test@example.com"
git -C "$REPO" config user.name "Test User"

printf '%s\n' 'hello' >"$REPO/clean.txt"
git -C "$REPO" add clean.txt
git -C "$REPO" commit -m "init" -q

printf '%s\n' 'hello updated' >"$REPO/clean.txt"
git -C "$REPO" add clean.txt

clean_commit_result="$(printf '{"tool_input":{"command":"git commit -m clean"}}' | CLAUDE_PROJECT_DIR="$REPO" sh "$HOOK")"
check_contains "clean staged commit allowed" "$clean_commit_result" 'permissionDecision":"allow'
check_contains "clean staged commit context includes coverage" "$clean_commit_result" 'coverage=full'

manifest_count="$(find "$REPO/vault" -maxdepth 1 -type f -name 'pre-commit-*.json' | wc -l | tr -d ' ')"
check_eq "single manifest for clean commit gate run" "1" "$manifest_count"

fortress_entries="$(grep -c 'pre-commit-' "$REPO/vault/fortress-bible.md" || true)"
check_eq "single fortress batch entry" "1" "$fortress_entries"

git -C "$REPO" reset --hard -q
printf '%s\n' 'GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyzABCDEFGHIJ' >"$REPO/secret.env"
git -C "$REPO" add secret.env

secret_commit_result="$(printf '{"tool_input":{"command":"git commit -m secret"}}' | CLAUDE_PROJECT_DIR="$REPO" sh "$HOOK")"
check_contains "secret staged commit denied" "$secret_commit_result" 'permissionDecision":"deny'
check_contains "secret staged commit reason" "$secret_commit_result" 'hardcoded secret detected'

echo "PASS: tests/test_commit_gate.sh"
