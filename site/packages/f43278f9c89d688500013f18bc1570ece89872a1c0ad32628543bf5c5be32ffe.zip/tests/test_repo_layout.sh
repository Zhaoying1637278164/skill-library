#!/bin/sh
set -eu

require_dir() {
  if [ ! -d "$1" ]; then
    echo "missing required directory: $1" >&2
    exit 1
  fi
}

require_file() {
  if [ ! -f "$1" ]; then
    echo "missing required file: $1" >&2
    exit 1
  fi
}

require_dir ".codex-plugin"
require_dir ".claude-plugin"
require_dir "skills"
require_dir "hooks"
require_dir "agents"
require_dir "templates"
require_dir "commands"
require_dir "scripts"
require_dir "tests"
require_file "vault/.gitkeep"
require_file "scripts/check-superpowers.sh"
require_file "scripts/lib.sh"
require_file "hooks/commit-gate/claude-hook.sh"
require_file "hooks/commit-gate/HOOK.md"

echo "PASS: tests/test_repo_layout.sh"
