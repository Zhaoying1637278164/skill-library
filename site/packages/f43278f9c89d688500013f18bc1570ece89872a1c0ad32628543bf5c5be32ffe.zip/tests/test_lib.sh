#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

SCRIPT_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
LIB_SH="$SCRIPT_ROOT/scripts/lib.sh"

if [ ! -f "$LIB_SH" ]; then
  echo "FAIL: scripts/lib.sh missing" >&2
  exit 1
fi

# shellcheck disable=SC1090
. "$LIB_SH"

checks=0
failures=0

check_eq() {
  name="$1"
  expected="$2"
  actual="$3"
  checks=$((checks + 1))
  if [ "$expected" = "$actual" ]; then
    echo "PASS: $name"
  else
    failures=$((failures + 1))
    echo "FAIL: $name (expected='$expected' actual='$actual')" >&2
  fi
}

check_true() {
  name="$1"
  if "$2"; then
    checks=$((checks + 1))
    echo "PASS: $name"
  else
    checks=$((checks + 1))
    failures=$((failures + 1))
    echo "FAIL: $name" >&2
  fi
}

check_eq "json_escape plain" "plain" "$(json_escape "plain")"
check_eq "json_escape quote+backslash" 'a\"b\\c' "$(json_escape "a\"b\\c")"
check_eq "json_escape newline" 'line1\nline2' "$(json_escape "$(printf 'line1\nline2')")"
check_eq "json_escape tab" 'left\tright' "$(json_escape "$(printf 'left\tright')")"

JSON_PAYLOAD='{"file_path":"top-level","path":"/tmp/fallback","tool_input":{"file_path":"inner/path","quoted":"he said \"hi\""}}'
check_eq "extract_json_string tool_input priority" "inner/path" "$(extract_json_string "$JSON_PAYLOAD" "file_path")"
check_eq "extract_json_string top-level fallback" "/tmp/fallback" "$(extract_json_string "$JSON_PAYLOAD" "path")"
check_eq "extract_json_string missing key" "" "$(extract_json_string "$JSON_PAYLOAD" "unknown")"
check_eq "extract_json_string escaped quotes" 'he said "hi"' "$(extract_json_string "$JSON_PAYLOAD" "quoted")"

H1="$(sha256_string "hello")"
H2="$(sha256_string "hello")"
check_eq "sha256_string length" "64" "${#H1}"
check_eq "sha256_string deterministic" "$H1" "$H2"

FILE_PATH="$TMP_DIR/input.txt"
printf 'hello file\n' >"$FILE_PATH"
FILE_HASH="$(sha256_file "$FILE_PATH")"
check_eq "sha256_file length" "64" "${#FILE_HASH}"

TEXT_FILE="$TMP_DIR/text.txt"
BIN_FILE="$TMP_DIR/data.bin"
printf 'just text\n' >"$TEXT_FILE"
printf '\001\002\000\003' >"$BIN_FILE"

if is_binary_file "$TEXT_FILE"; then
  check_eq "is_binary_file text=false" "false" "true"
else
  check_eq "is_binary_file text=false" "false" "false"
fi

if is_binary_file "$BIN_FILE"; then
  check_eq "is_binary_file binary=true" "true" "true"
else
  check_eq "is_binary_file binary=true" "true" "false"
fi

ROUNDTRIP_PATH="$TMP_DIR/../$(basename -- "$TMP_DIR")"
RESOLVED_ROUNDTRIP="$(resolve_real_path "$ROUNDTRIP_PATH")"
EXPECTED_ROUNDTRIP="$(cd "$TMP_DIR" && pwd -P)"
check_eq "resolve_real_path tmp roundtrip" "$EXPECTED_ROUNDTRIP" "$RESOLVED_ROUNDTRIP"

PROJECT_ROOT="$(git -C "$SCRIPT_ROOT" rev-parse --show-toplevel 2>/dev/null || printf '%s' "$SCRIPT_ROOT")"
CACHE_FILE="${TMPDIR:-/tmp}/mypowers-posture-$(sha256_string "$PROJECT_ROOT")"
rm -f "$CACHE_FILE"

CLAUDE_PROJECT_DIR="$PROJECT_ROOT" posture_cached
if [ -f "$CACHE_FILE" ]; then
  check_eq "posture_cached miss writes cache" "yes" "yes"
else
  check_eq "posture_cached miss writes cache" "yes" "no"
fi

cat >"$CACHE_FILE" <<'EOF'
POSTURE='CACHED'
DETECTED_TOOLS='cached-tools'
MISSING_TOOLS='none'
VERIFIED_TOOLS='9/9'
CLAUDE_PERMISSION_MODE='AUTO'
POSTURE_MESSAGE='from-cache'
EOF

CLAUDE_PROJECT_DIR="$PROJECT_ROOT" posture_cached
check_eq "posture_cached hit reads cache" "CACHED" "${POSTURE:-}"

CLAUDE_PROJECT_DIR="$PROJECT_ROOT" posture_cached --refresh
if [ "${POSTURE:-}" = "CACHED" ]; then
  check_eq "posture_cached --refresh forces fresh" "fresh" "cached"
else
  check_eq "posture_cached --refresh forces fresh" "fresh" "fresh"
fi

if [ "$failures" -ne 0 ]; then
  echo "FAIL: tests/test_lib.sh ($failures failed, $checks checks)" >&2
  exit 1
fi

echo "PASS: tests/test_lib.sh (0 failed, $checks checks)"