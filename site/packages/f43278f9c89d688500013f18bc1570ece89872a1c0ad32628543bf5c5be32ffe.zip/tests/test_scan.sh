#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

CLEAN_FILE="$TMP_DIR/clean.env"
SECRET_FILE="$TMP_DIR/secret.env"
QUOTED_SECRET_FILE="$TMP_DIR/quoted-secret.env"
COMMENTED_SECRET_FILE="$TMP_DIR/commented-secret.env"
COMMENT_PREFIXED_SECRET_FILE="$TMP_DIR/comment-prefixed-secret.env"
ANNOTATED_BYPASS_FILE="$TMP_DIR/annotated-bypass.env"
UNMATCHED_FENCE_SECRET_FILE="$TMP_DIR/unmatched-fence-secret.md"
JSON_OBJECT_SECRET_FILE="$TMP_DIR/json-object-secret.json"
COMPACT_JSON_OPENAI_SECRET_FILE="$TMP_DIR/compact-json-openai-secret.json"
PRETTY_JSON_SECRET_FILE="$TMP_DIR/pretty-json-secret.json"
JSON_SECRET_KEY_FILE="$TMP_DIR/json-secret-key.json"
COMPACT_JSON_SECRET_KEY_FILE="$TMP_DIR/compact-json-secret-key.json"
TRAILING_SPACE_SECRET_FILE="$TMP_DIR/trailing-space-secret.env"
TRAILING_TAB_SECRET_FILE="$TMP_DIR/trailing-tab-secret.env"
CRLF_SECRET_FILE="$TMP_DIR/crlf-secret.env"
GITHUB_TOKEN_FILE="$TMP_DIR/github-token.env"
AWS_TEMP_ACCESS_KEY_FILE="$TMP_DIR/aws-temp-access-key.env"
SLACK_BOT_TOKEN_FILE="$TMP_DIR/slack-bot-token.env"
STRIPE_LIVE_KEY_FILE="$TMP_DIR/stripe-live-key.env"
RSA_PRIVATE_KEY_FILE="$TMP_DIR/rsa-private-key.pem"
EC_PRIVATE_KEY_FILE="$TMP_DIR/ec-private-key.pem"
LINE_CAP_SECRET_FILE="$TMP_DIR/line-cap-secret.env"
SECRET_KEY_INDIRECTION_FILE="$TMP_DIR/secret-key-indirection.env"
SECRET_KEY_BRACE_INDIRECTION_FILE="$TMP_DIR/secret-key-brace-indirection.env"
SECRET_KEY_DJANGO_INDIRECTION_FILE="$TMP_DIR/secret-key-django-indirection.env"
SECRET_KEY_DJANGO_BRACE_INDIRECTION_FILE="$TMP_DIR/secret-key-django-brace-indirection.env"
COMMENT_PLACEHOLDER_FILE="$TMP_DIR/comment-placeholder.env"
SLASH_COMMENT_PLACEHOLDER_FILE="$TMP_DIR/slash-comment-placeholder.env"
GENERIC_PLACEHOLDER_FILE="$TMP_DIR/generic-placeholder.env"
BULLET_BYPASS_FILE="$TMP_DIR/bullet-bypass.md"
PROSE_BYPASS_FILE="$TMP_DIR/prose-bypass.md"
UNREADABLE_FILE="$TMP_DIR/unreadable.env"
DOCS_EXAMPLE_FILE="$TMP_DIR/docs-example.md"
JSON_FILE="$TMP_DIR/json\"target.env"
BACKSLASH_FILE="$TMP_DIR/backslash\\target.env"
NEWLINE_FILE="$(printf '%s\n%s' "$TMP_DIR/newline" "target.env")"
SOURCE_STYLE_FILE="$TMP_DIR/source-style.js"
FIXTURE_FILE="$TMP_DIR/fixture.env"
NO_PYTHON_BIN="$TMP_DIR/no-python-bin"
mkdir -p "$NO_PYTHON_BIN"
ln -s /bin/sh "$NO_PYTHON_BIN/sh"
ln -s /usr/bin/grep "$NO_PYTHON_BIN/grep"
ln -s /usr/bin/dirname "$NO_PYTHON_BIN/dirname"
ln -s /usr/bin/od "$NO_PYTHON_BIN/od"
ln -s /usr/bin/tr "$NO_PYTHON_BIN/tr"

cat >"$CLEAN_FILE" <<'EOF'
APP_MODE=development
EOF

cat >"$SECRET_FILE" <<'EOF'
OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef
EOF

cat >"$QUOTED_SECRET_FILE" <<'EOF'
OPENAI_API_KEY="sk-prod-1234567890abcdef1234567890abcdef"
EOF

cat >"$COMMENTED_SECRET_FILE" <<'EOF'
OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef # test account
EOF

cat >"$COMMENT_PREFIXED_SECRET_FILE" <<'EOF'
# OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef
EOF

cat >"$ANNOTATED_BYPASS_FILE" <<'EOF'
# mypowers: skip-security-oracle temporary
EOF

cat >"$JSON_OBJECT_SECRET_FILE" <<'EOF'
{"OPENAI_API_KEY":"sk-prod-1234567890abcdef1234567890abcdef"}
EOF

cat >"$COMPACT_JSON_OPENAI_SECRET_FILE" <<'EOF'
{"service":"demo","OPENAI_API_KEY":"sk-prod-1234567890abcdef1234567890abcdef","enabled":true}
EOF

cat >"$PRETTY_JSON_SECRET_FILE" <<'EOF'
{
  "service": "demo",
  "OPENAI_API_KEY": "sk-prod-1234567890abcdef1234567890abcdef",
  "enabled": true
}
EOF

cat >"$JSON_SECRET_KEY_FILE" <<'EOF'
{
  "name": "session",
  "SECRET_KEY": "prod-secret-key-value",
  "enabled": true
}
EOF

cat >"$COMPACT_JSON_SECRET_KEY_FILE" <<'EOF'
{"name":"session","SECRET_KEY":"prod-secret-key-value","enabled":true}
EOF

printf 'OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef \n' >"$TRAILING_SPACE_SECRET_FILE"
printf 'OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef\t\n' >"$TRAILING_TAB_SECRET_FILE"
printf 'OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef\r\n' >"$CRLF_SECRET_FILE"
cat >"$GITHUB_TOKEN_FILE" <<'EOF'
GITHUB_TOKEN=ghp_1234567890abcdefghijklmnopqrstuvwxyzABCD
EOF
cat >"$AWS_TEMP_ACCESS_KEY_FILE" <<'EOF'
AWS_ACCESS_KEY_ID=ASIA1234567890ABCDEF
EOF
cat >"$SLACK_BOT_TOKEN_FILE" <<'EOF'
token=xoxb-12345678901-abcdefghijkl
EOF
cat >"$STRIPE_LIVE_KEY_FILE" <<'EOF'
key=sk_live_abcdefghijklmnopqrstu
EOF
cat >"$RSA_PRIVATE_KEY_FILE" <<'EOF'
-----BEGIN RSA PRIVATE KEY-----
EOF
cat >"$EC_PRIVATE_KEY_FILE" <<'EOF'
-----BEGIN EC PRIVATE KEY-----
EOF
awk 'BEGIN { for (i = 1; i <= 10001; i++) print "safe line"; print "GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyzABCDEFGHIJ" }' >"$LINE_CAP_SECRET_FILE"
cat >"$SECRET_KEY_INDIRECTION_FILE" <<'EOF'
SECRET_KEY=$SECRET_KEY
EOF
cat >"$SECRET_KEY_BRACE_INDIRECTION_FILE" <<'EOF'
SECRET_KEY=${SECRET_KEY}
EOF
cat >"$SECRET_KEY_DJANGO_INDIRECTION_FILE" <<'EOF'
SECRET_KEY=$DJANGO_SECRET_KEY
EOF
cat >"$SECRET_KEY_DJANGO_BRACE_INDIRECTION_FILE" <<'EOF'
SECRET_KEY=${DJANGO_SECRET_KEY}
EOF

cat >"$UNREADABLE_FILE" <<'EOF'
APP_MODE=production
EOF

cat >"$JSON_FILE" <<'EOF'
APP_MODE=qa
EOF

cat >"$BACKSLASH_FILE" <<'EOF'
APP_MODE=staging
EOF

cat >"$NEWLINE_FILE" <<'EOF'
APP_MODE=testing
EOF

cat >"$SOURCE_STYLE_FILE" <<'EOF'
const example = "OPENAI_API_KEY=sk-test-123456789012345678901234567890";
EOF

cat >"$DOCS_EXAMPLE_FILE" <<'EOF'
```env
OPENAI_API_KEY=sk-test-123456789012345678901234567890
```
EOF

cat >"$COMMENT_PLACEHOLDER_FILE" <<'EOF'
# OPENAI_API_KEY=sk-example-123456789012345678901234567890
EOF

cat >"$SLASH_COMMENT_PLACEHOLDER_FILE" <<'EOF'
// OPENAI_API_KEY=sk-test-123456789012345678901234567890
EOF

cat >"$GENERIC_PLACEHOLDER_FILE" <<'EOF'
# SECRET_KEY=example
EOF

cat >"$BULLET_BYPASS_FILE" <<'EOF'
- mypowers: skip-security-oracle temporary
EOF

cat >"$PROSE_BYPASS_FILE" <<'EOF'
mypowers: skip-security-oracle is mentioned here in prose and should be allowed.
EOF

cat >"$UNMATCHED_FENCE_SECRET_FILE" <<'EOF'
```env
OPENAI_API_KEY=sk-prod-1234567890abcdef1234567890abcdef
EOF

cat >"$FIXTURE_FILE" <<'EOF'
OPENAI_API_KEY=sk-example-123456789012345678901234567890
EOF

chmod 000 "$UNREADABLE_FILE"

PATH="$NO_PYTHON_BIN" sh scripts/scan.sh "$CLEAN_FILE" >"$TMP_DIR/no-python.out"
python3 - "$TMP_DIR/no-python.out" "$CLEAN_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$CLEAN_FILE" >"$TMP_DIR/clean.out"
python3 - "$TMP_DIR/clean.out" "$CLEAN_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
assert payload["posture"]
assert payload["message"]
PY

sh hooks/pre-edit-security/run.sh "$CLEAN_FILE" >"$TMP_DIR/hook-clean.out"
python3 - "$TMP_DIR/hook-clean.out" "$CLEAN_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
assert payload["posture"]
assert payload["message"]
PY

cat >"$TMP_DIR/claude-hook-existing.json" <<EOF
{"permission_mode":"auto","tool_input":{"file_path":"$CLEAN_FILE"}}
EOF

sh hooks/pre-edit-security/claude-hook.sh <"$TMP_DIR/claude-hook-existing.json" >"$TMP_DIR/claude-hook-existing.out"
python3 - "$TMP_DIR/claude-hook-existing.out" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload == {}
PY

NEW_FILE="$TMP_DIR/new-file.py"
cat >"$TMP_DIR/claude-hook-new-file.json" <<EOF
{"permission_mode":"auto","tool_input":{"file_path":"$NEW_FILE"}}
EOF

sh hooks/pre-edit-security/claude-hook.sh <"$TMP_DIR/claude-hook-new-file.json" >"$TMP_DIR/claude-hook-new-file.out"
python3 - "$TMP_DIR/claude-hook-new-file.out" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload == {}
PY

cat >"$TMP_DIR/claude-hook-secret.json" <<EOF
{"permission_mode":"auto","tool_input":{"file_path":"$SECRET_FILE"}}
EOF

sh hooks/pre-edit-security/claude-hook.sh <"$TMP_DIR/claude-hook-secret.json" >"$TMP_DIR/claude-hook-secret.out"
python3 - "$TMP_DIR/claude-hook-secret.out" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
hook = payload["hookSpecificOutput"]
assert payload["continue"] is False
assert hook["hookEventName"] == "PreToolUse"
assert hook["permissionDecision"] == "deny"
assert "hardcoded secret detected" in hook["permissionDecisionReason"]
PY

if sh scripts/scan.sh "$SECRET_FILE" >"$TMP_DIR/secret.out" 2>"$TMP_DIR/secret.err"; then
  echo "expected secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/secret.err" >/dev/null

if sh hooks/pre-edit-security/run.sh "$SECRET_FILE" >"$TMP_DIR/hook-secret.out" 2>"$TMP_DIR/hook-secret.err"; then
  echo "expected hook secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/hook-secret.err" >/dev/null

if sh scripts/scan.sh "$QUOTED_SECRET_FILE" >"$TMP_DIR/quoted-secret.out" 2>"$TMP_DIR/quoted-secret.err"; then
  echo "expected quoted secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/quoted-secret.err" >/dev/null

if sh scripts/scan.sh "$COMMENTED_SECRET_FILE" >"$TMP_DIR/commented-secret.out" 2>"$TMP_DIR/commented-secret.err"; then
  echo "expected commented secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/commented-secret.err" >/dev/null

if sh scripts/scan.sh "$COMMENT_PREFIXED_SECRET_FILE" >"$TMP_DIR/comment-prefixed-secret.out" 2>"$TMP_DIR/comment-prefixed-secret.err"; then
  echo "expected comment-prefixed secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/comment-prefixed-secret.err" >/dev/null

if sh scripts/scan.sh "$ANNOTATED_BYPASS_FILE" >"$TMP_DIR/annotated-bypass.out" 2>"$TMP_DIR/annotated-bypass.err"; then
  echo "expected annotated bypass scan to fail" >&2
  exit 1
fi

grep 'security oracle bypass marker detected' "$TMP_DIR/annotated-bypass.err" >/dev/null

if sh scripts/scan.sh "$JSON_OBJECT_SECRET_FILE" >"$TMP_DIR/json-object-secret.out" 2>"$TMP_DIR/json-object-secret.err"; then
  echo "expected json object secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/json-object-secret.err" >/dev/null

if sh scripts/scan.sh "$COMPACT_JSON_OPENAI_SECRET_FILE" >"$TMP_DIR/compact-json-openai-secret.out" 2>"$TMP_DIR/compact-json-openai-secret.err"; then
  echo "expected compact json openai secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/compact-json-openai-secret.err" >/dev/null

if sh scripts/scan.sh "$PRETTY_JSON_SECRET_FILE" >"$TMP_DIR/pretty-json-secret.out" 2>"$TMP_DIR/pretty-json-secret.err"; then
  echo "expected pretty json secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/pretty-json-secret.err" >/dev/null

if sh scripts/scan.sh "$JSON_SECRET_KEY_FILE" >"$TMP_DIR/json-secret-key.out" 2>"$TMP_DIR/json-secret-key.err"; then
  echo "expected json secret key scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/json-secret-key.err" >/dev/null

if sh scripts/scan.sh "$COMPACT_JSON_SECRET_KEY_FILE" >"$TMP_DIR/compact-json-secret-key.out" 2>"$TMP_DIR/compact-json-secret-key.err"; then
  echo "expected compact json secret key scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/compact-json-secret-key.err" >/dev/null

if sh scripts/scan.sh "$TRAILING_SPACE_SECRET_FILE" >"$TMP_DIR/trailing-space-secret.out" 2>"$TMP_DIR/trailing-space-secret.err"; then
  echo "expected trailing-space secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/trailing-space-secret.err" >/dev/null

if sh scripts/scan.sh "$TRAILING_TAB_SECRET_FILE" >"$TMP_DIR/trailing-tab-secret.out" 2>"$TMP_DIR/trailing-tab-secret.err"; then
  echo "expected trailing-tab secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/trailing-tab-secret.err" >/dev/null

if sh scripts/scan.sh "$CRLF_SECRET_FILE" >"$TMP_DIR/crlf-secret.out" 2>"$TMP_DIR/crlf-secret.err"; then
  echo "expected crlf secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/crlf-secret.err" >/dev/null

if sh scripts/scan.sh "$GITHUB_TOKEN_FILE" >"$TMP_DIR/github-token.out" 2>"$TMP_DIR/github-token.err"; then
  echo "expected github token scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/github-token.err" >/dev/null

if sh scripts/scan.sh "$AWS_TEMP_ACCESS_KEY_FILE" >"$TMP_DIR/aws-temp-access-key.out" 2>"$TMP_DIR/aws-temp-access-key.err"; then
  echo "expected aws temp access key scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/aws-temp-access-key.err" >/dev/null

if sh scripts/scan.sh "$SLACK_BOT_TOKEN_FILE" >"$TMP_DIR/slack-bot-token.out" 2>"$TMP_DIR/slack-bot-token.err"; then
  echo "expected slack bot token scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/slack-bot-token.err" >/dev/null

if sh scripts/scan.sh "$STRIPE_LIVE_KEY_FILE" >"$TMP_DIR/stripe-live-key.out" 2>"$TMP_DIR/stripe-live-key.err"; then
  echo "expected stripe live key scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/stripe-live-key.err" >/dev/null

if sh scripts/scan.sh "$RSA_PRIVATE_KEY_FILE" >"$TMP_DIR/rsa-private-key.out" 2>"$TMP_DIR/rsa-private-key.err"; then
  echo "expected rsa private key scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/rsa-private-key.err" >/dev/null

if sh scripts/scan.sh "$EC_PRIVATE_KEY_FILE" >"$TMP_DIR/ec-private-key.out" 2>"$TMP_DIR/ec-private-key.err"; then
  echo "expected ec private key scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/ec-private-key.err" >/dev/null

sh scripts/scan.sh "$LINE_CAP_SECRET_FILE" >"$TMP_DIR/line-cap-secret.out"
python3 - "$TMP_DIR/line-cap-secret.out" "$LINE_CAP_SECRET_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

if sh scripts/scan.sh "$UNREADABLE_FILE" >"$TMP_DIR/unreadable.out" 2>"$TMP_DIR/unreadable.err"; then
  echo "expected unreadable file scan to fail" >&2
  exit 1
fi

grep 'scan target not readable' "$TMP_DIR/unreadable.err" >/dev/null

sh scripts/scan.sh "$JSON_FILE" >"$TMP_DIR/json.out"
python3 - "$TMP_DIR/json.out" "$JSON_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$BACKSLASH_FILE" >"$TMP_DIR/backslash.out"
python3 - "$TMP_DIR/backslash.out" "$BACKSLASH_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$NEWLINE_FILE" >"$TMP_DIR/newline.out"
python3 - "$TMP_DIR/newline.out" "$NEWLINE_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$SOURCE_STYLE_FILE" >"$TMP_DIR/source-style.out"
python3 - "$TMP_DIR/source-style.out" "$SOURCE_STYLE_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$DOCS_EXAMPLE_FILE" >"$TMP_DIR/docs-example.out"
python3 - "$TMP_DIR/docs-example.out" "$DOCS_EXAMPLE_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$COMMENT_PLACEHOLDER_FILE" >"$TMP_DIR/comment-placeholder.out"
python3 - "$TMP_DIR/comment-placeholder.out" "$COMMENT_PLACEHOLDER_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$SLASH_COMMENT_PLACEHOLDER_FILE" >"$TMP_DIR/slash-comment-placeholder.out"
python3 - "$TMP_DIR/slash-comment-placeholder.out" "$SLASH_COMMENT_PLACEHOLDER_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$GENERIC_PLACEHOLDER_FILE" >"$TMP_DIR/generic-placeholder.out"
python3 - "$TMP_DIR/generic-placeholder.out" "$GENERIC_PLACEHOLDER_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$SECRET_KEY_INDIRECTION_FILE" >"$TMP_DIR/secret-key-indirection.out"
python3 - "$TMP_DIR/secret-key-indirection.out" "$SECRET_KEY_INDIRECTION_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$SECRET_KEY_BRACE_INDIRECTION_FILE" >"$TMP_DIR/secret-key-brace-indirection.out"
python3 - "$TMP_DIR/secret-key-brace-indirection.out" "$SECRET_KEY_BRACE_INDIRECTION_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$SECRET_KEY_DJANGO_INDIRECTION_FILE" >"$TMP_DIR/secret-key-django-indirection.out"
python3 - "$TMP_DIR/secret-key-django-indirection.out" "$SECRET_KEY_DJANGO_INDIRECTION_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$SECRET_KEY_DJANGO_BRACE_INDIRECTION_FILE" >"$TMP_DIR/secret-key-django-brace-indirection.out"
python3 - "$TMP_DIR/secret-key-django-brace-indirection.out" "$SECRET_KEY_DJANGO_BRACE_INDIRECTION_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

if sh scripts/scan.sh "$UNMATCHED_FENCE_SECRET_FILE" >"$TMP_DIR/unmatched-fence-secret.out" 2>"$TMP_DIR/unmatched-fence-secret.err"; then
  echo "expected unmatched fence secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/unmatched-fence-secret.err" >/dev/null

if sh scripts/scan.sh "$BULLET_BYPASS_FILE" >"$TMP_DIR/bullet-bypass.out" 2>"$TMP_DIR/bullet-bypass.err"; then
  echo "expected bullet bypass scan to fail" >&2
  exit 1
fi

grep 'security oracle bypass marker detected' "$TMP_DIR/bullet-bypass.err" >/dev/null

sh scripts/scan.sh "$PROSE_BYPASS_FILE" >"$TMP_DIR/prose-bypass.out"
python3 - "$TMP_DIR/prose-bypass.out" "$PROSE_BYPASS_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

sh scripts/scan.sh "$FIXTURE_FILE" >"$TMP_DIR/fixture.out"
python3 - "$TMP_DIR/fixture.out" "$FIXTURE_FILE" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

if sh scripts/scan.sh "$TMP_DIR/missing.env" >"$TMP_DIR/missing.out" 2>"$TMP_DIR/missing.err"; then
  echo "expected missing file scan to fail" >&2
  exit 1
fi

grep 'scan target not found' "$TMP_DIR/missing.err" >/dev/null

if sh scripts/scan.sh relative.env >"$TMP_DIR/relative.out" 2>"$TMP_DIR/relative.err"; then
  echo "expected relative path scan to fail" >&2
  exit 1
fi

grep 'must be an absolute path' "$TMP_DIR/relative.err" >/dev/null

cat >"$TMP_DIR/bypass.env" <<'EOF'
# mypowers: skip-security-oracle
EOF

if sh scripts/scan.sh "$TMP_DIR/bypass.env" >"$TMP_DIR/bypass.out" 2>"$TMP_DIR/bypass.err"; then
  echo "expected bypass marker scan to fail" >&2
  exit 1
fi

grep 'security oracle bypass marker detected' "$TMP_DIR/bypass.err" >/dev/null

cat >"$TMP_DIR/bypass-mention.md" <<'EOF'
This document mentions mypowers: skip-security-oracle as an example only.
EOF

sh scripts/scan.sh "$TMP_DIR/bypass-mention.md" >"$TMP_DIR/bypass-mention.out"
python3 - "$TMP_DIR/bypass-mention.out" "$TMP_DIR/bypass-mention.md" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["status"] == "ok"
assert payload["target"] == sys.argv[2]
PY

echo "PASS: tests/test_scan.sh"
