#!/bin/sh
set -eu

for shell_file in \
  tests/run-all.sh \
  tests/test_repo_layout.sh \
  tests/test_manifests.sh \
  tests/test_posture.sh \
  tests/test_superpowers.sh \
  tests/test_scan.sh \
  tests/test_lib.sh \
  tests/test_fast_gate.sh \
  tests/test_commit_gate.sh \
  tests/test_bridge_import.sh \
  tests/test_attest.sh \
  tests/test_skill_contract_part1.sh \
  tests/test_docs_and_agents.sh \
  scripts/posture.sh \
  scripts/check-superpowers.sh \
  scripts/posture-reporting.sh \
  scripts/setup-help.sh \
  scripts/scan.sh \
  scripts/bridge-import.sh \
  scripts/attest.sh \
  scripts/lib.sh \
  hooks/pre-edit-security/run.sh \
  hooks/pre-edit-security/claude-hook.sh \
  hooks/commit-gate/claude-hook.sh
do
  sh -n "$shell_file"
done

python3 - <<'PY'
import json
from pathlib import Path

for path in [
    Path(".codex-plugin/plugin.json"),
    Path(".claude-plugin/plugin.json"),
    Path("commands/mypowers.json"),
]:
    json.loads(path.read_text())
PY

grep 'tests/test_repo_smoke.sh' tests/run-all.sh >/dev/null
grep 'tests/test_superpowers.sh' tests/run-all.sh >/dev/null

echo "PASS: tests/test_repo_smoke.sh"
