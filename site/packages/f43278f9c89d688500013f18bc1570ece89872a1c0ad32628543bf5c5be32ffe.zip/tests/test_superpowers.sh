#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

HOME_DIR="$TMP_DIR/home"
mkdir -p "$HOME_DIR"

NO_INSTALL_OUTPUT="$(HOME="$HOME_DIR" /bin/sh scripts/check-superpowers.sh)"
echo "$NO_INSTALL_OUTPUT" | grep '"available":false' >/dev/null
echo "$NO_INSTALL_OUTPUT" | grep '"reason":"no standard Superpowers skill installation found"' >/dev/null

eval "$(HOME="$HOME_DIR" /bin/sh scripts/check-superpowers.sh --env)"
[ "$SUPERPOWERS_AVAILABLE" = "false" ]
[ "$SUPERPOWERS_ROOT" = "" ]
[ "$SUPERPOWERS_REASON" = "no standard Superpowers skill installation found" ]

mkdir -p "$TMP_DIR/workspace/everything-claude-code/skills/brainstorming"
cat >"$TMP_DIR/workspace/everything-claude-code/skills/brainstorming/SKILL.md" <<'EOF'
# not a standard install path
EOF

CLONE_ONLY_OUTPUT="$(HOME="$HOME_DIR" /bin/sh scripts/check-superpowers.sh)"
echo "$CLONE_ONLY_OUTPUT" | grep '"available":false' >/dev/null

for skill in brainstorming writing-plans test-driven-development; do
  mkdir -p "$HOME_DIR/.claude/skills/$skill"
  cat >"$HOME_DIR/.claude/skills/$skill/SKILL.md" <<'EOF'
# standard Claude skill
EOF
done

CLAUDE_OUTPUT="$(HOME="$HOME_DIR" /bin/sh scripts/check-superpowers.sh)"
echo "$CLAUDE_OUTPUT" | grep '"available":true' >/dev/null
echo "$CLAUDE_OUTPUT" | grep '"root":"'"$HOME_DIR"'/\.claude/skills"' >/dev/null

eval "$(HOME="$HOME_DIR" /bin/sh scripts/check-superpowers.sh --env)"
[ "$SUPERPOWERS_AVAILABLE" = "true" ]
[ "$SUPERPOWERS_ROOT" = "$HOME_DIR/.claude/skills" ]
[ "$SUPERPOWERS_REASON" = "found recognized Superpowers skills in $HOME_DIR/.claude/skills" ]

rm -rf "$HOME_DIR/.claude"
for skill in brainstorming writing-plans test-driven-development; do
  mkdir -p "$HOME_DIR/.codex/superpowers/skills/$skill"
  cat >"$HOME_DIR/.codex/superpowers/skills/$skill/SKILL.md" <<'EOF'
# standard Codex plugin skill
EOF
done

CODEX_OUTPUT="$(HOME="$HOME_DIR" /bin/sh scripts/check-superpowers.sh)"
echo "$CODEX_OUTPUT" | grep '"available":true' >/dev/null
echo "$CODEX_OUTPUT" | grep '"root":"'"$HOME_DIR"'/\.codex/superpowers/skills"' >/dev/null

echo "PASS: tests/test_superpowers.sh"
