#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

EMPTY_BIN="$TMP_DIR/empty-bin"
PARTIAL_BIN="$TMP_DIR/partial-bin"
FULL_BIN="$TMP_DIR/full-bin"
DARWIN_BIN="$TMP_DIR/darwin-bin"
LINUX_BIN="$TMP_DIR/linux-bin"
FALLBACK_BIN="$TMP_DIR/fallback-bin"
mkdir -p "$EMPTY_BIN" "$PARTIAL_BIN" "$FULL_BIN" "$DARWIN_BIN" "$LINUX_BIN" "$FALLBACK_BIN"

for tool in trivy grype syft semgrep cosign rekor-cli; do
  cat >"$FULL_BIN/$tool" <<'EOF'
#!/bin/sh
exit 0
EOF
  chmod +x "$FULL_BIN/$tool"
done

for tool in trivy grype syft; do
  cat >"$PARTIAL_BIN/$tool" <<'EOF'
#!/bin/sh
exit 0
EOF
  chmod +x "$PARTIAL_BIN/$tool"
done

cat >"$DARWIN_BIN/uname" <<'EOF'
#!/bin/sh
printf '%s\n' Darwin
EOF
chmod +x "$DARWIN_BIN/uname"

cat >"$LINUX_BIN/uname" <<'EOF'
#!/bin/sh
printf '%s\n' Linux
EOF
chmod +x "$LINUX_BIN/uname"

cat >"$FALLBACK_BIN/uname" <<'EOF'
#!/bin/sh
printf '%s\n' Plan9
EOF
chmod +x "$FALLBACK_BIN/uname"

BASIC_OUTPUT="$(PATH="$EMPTY_BIN" /bin/sh scripts/posture.sh)"
PARTIAL_OUTPUT="$(PATH="$PARTIAL_BIN" /bin/sh scripts/posture.sh)"
FULL_OUTPUT="$(PATH="$FULL_BIN" /bin/sh scripts/posture.sh)"

echo "$BASIC_OUTPUT" | grep '"posture":"BASIC"' >/dev/null
echo "$PARTIAL_OUTPUT" | grep '"posture":"PARTIAL"' >/dev/null
echo "$FULL_OUTPUT" | grep '"posture":"FULL"' >/dev/null
echo "$FULL_OUTPUT" | grep '"claude_permission_mode":"UNKNOWN"' >/dev/null
echo "$FULL_OUTPUT" | grep 'mypowers posture: FULL' >/dev/null

eval "$(PATH="$FULL_BIN" /bin/sh scripts/posture.sh --env)"
[ "$POSTURE" = "FULL" ]
[ "$DETECTED_TOOLS" = "trivy,grype,syft,semgrep,cosign,rekor-cli" ]
[ "$MISSING_TOOLS" = "" ]
[ "$VERIFIED_TOOLS" = "6/6" ]
[ "$CLAUDE_PERMISSION_MODE" = "UNKNOWN" ]
[ "$POSTURE_MESSAGE" = "Claude Code permission mode: UNKNOWN | mypowers posture: FULL | Security Oracle verified: 6/6 tools present" ]

eval "$(PATH="$PARTIAL_BIN" /bin/sh scripts/posture.sh --env)"
[ "$POSTURE" = "PARTIAL" ]
[ "$DETECTED_TOOLS" = "trivy,grype,syft" ]
[ "$MISSING_TOOLS" = "semgrep,cosign,rekor-cli" ]
[ "$VERIFIED_TOOLS" = "3/6" ]
[ "$POSTURE_MESSAGE" = "Claude Code permission mode: UNKNOWN | mypowers posture: PARTIAL | Security Oracle verified: 3/6 tools present | Missing: semgrep,cosign,rekor-cli" ]

eval "$(PATH="$EMPTY_BIN" /bin/sh scripts/posture.sh --env)"
[ "$POSTURE" = "BASIC" ]
[ "$DETECTED_TOOLS" = "" ]
[ "$MISSING_TOOLS" = "trivy,grype,syft,semgrep,cosign,rekor-cli" ]
[ "$VERIFIED_TOOLS" = "0/6" ]
[ "$POSTURE_MESSAGE" = "Claude Code permission mode: UNKNOWN | mypowers posture: BASIC | Security Oracle verified: 0/6 tools present | Missing: trivy,grype,syft,semgrep,cosign,rekor-cli" ]

SIMPLE_OUTPUT="$(PATH="$FULL_BIN" /bin/sh scripts/posture.sh --simple)"
echo "$SIMPLE_OUTPUT" | grep '^FULL$' >/dev/null

MODE_OUTPUT="$(CLAUDE_CODE_PERMISSION_MODE=auto PATH="$PARTIAL_BIN" /bin/sh scripts/posture.sh)"
echo "$MODE_OUTPUT" | grep '"claude_permission_mode":"AUTO"' >/dev/null
echo "$MODE_OUTPUT" | grep 'Claude Code permission mode: AUTO | mypowers posture: PARTIAL | Security Oracle verified: 3/6 tools present | Missing: semgrep,cosign,rekor-cli' >/dev/null

ESCAPED_MODE_OUTPUT="$(CLAUDE_CODE_PERMISSION_MODE='plan"quoted\mode' PATH="$EMPTY_BIN" /bin/sh scripts/posture.sh)"
printf '%s' "$ESCAPED_MODE_OUTPUT" >"$TMP_DIR/escaped-mode.json"
python3 - "$TMP_DIR/escaped-mode.json" <<'PY'
import json
import sys

payload = json.load(open(sys.argv[1]))
assert payload["posture"] == "BASIC"
assert payload["claude_permission_mode"] == 'PLAN"QUOTED\\MODE'
assert 'PLAN"QUOTED\\MODE' in payload["message"]
PY

DARWIN_OUTPUT="$(PATH="$DARWIN_BIN:$EMPTY_BIN" /bin/sh scripts/setup-help.sh)"
echo "$DARWIN_OUTPUT" | grep '^brew install trivy grype syft semgrep cosign$' >/dev/null
echo "$DARWIN_OUTPUT" | grep '^brew install rekor$' >/dev/null

LINUX_OUTPUT="$(PATH="$LINUX_BIN:$EMPTY_BIN" /bin/sh scripts/setup-help.sh)"
echo "$LINUX_OUTPUT" | grep '^Install Trivy, Grype, Syft, Semgrep, Cosign, and Rekor using your package manager or vendor instructions\.$' >/dev/null
echo "$LINUX_OUTPUT" | grep '^Examples: apt-get install trivy semgrep || use the official installer scripts when packages are unavailable\.$' >/dev/null

FALLBACK_OUTPUT="$(PATH="$FALLBACK_BIN:$EMPTY_BIN" /bin/sh scripts/setup-help.sh)"
echo "$FALLBACK_OUTPUT" | grep '^Install Trivy, Grype, Syft, Semgrep, Cosign, and Rekor CLI manually for full posture support\.$' >/dev/null

echo "PASS: tests/test_posture.sh"
