#!/bin/sh
set -eu

require_contains() {
  file="$1"
  text="$2"
  grep -F "$text" "$file" >/dev/null || {
    echo "missing '$text' in $file" >&2
    exit 1
  }
}

for file in \
  skills/orchestrator/SKILL.md \
  skills/bridge-import/SKILL.md \
  skills/security-oracle/SKILL.md \
  skills/supply-chain/SKILL.md
do
  [ -f "$file" ] || {
    echo "missing skill file: $file" >&2
    exit 1
  }
  require_contains "$file" "Purpose:"
  require_contains "$file" "Execution Contract:"
done

require_contains skills/orchestrator/SKILL.md "/mypowers:forge"
require_contains skills/orchestrator/SKILL.md "scripts/posture.sh"
require_contains skills/orchestrator/SKILL.md "scripts/check-superpowers.sh"
require_contains skills/orchestrator/SKILL.md "Superpowers"
require_contains skills/orchestrator/SKILL.md "brainstorming"
require_contains skills/orchestrator/SKILL.md "writing-plans"
require_contains skills/bridge-import/SKILL.md "Bridge import rejected: integrity check failed. Possible tampering or corruption detected."
require_contains skills/security-oracle/SKILL.md "FULL / PARTIAL / BASIC"
require_contains skills/security-oracle/SKILL.md "scripts/scan.sh"
require_contains skills/security-oracle/SKILL.md 'eval "$(sh scripts/posture.sh --env)"'
require_contains skills/security-oracle/SKILL.md "posture-reporting.sh"
require_contains skills/security-oracle/SKILL.md "hardcoded secrets"
require_contains skills/security-oracle/SKILL.md "curl|sh|bash|dash"
require_contains skills/supply-chain/SKILL.md "scripts/attest.sh"

echo "PASS: tests/test_skill_contract_part1.sh"
