#!/bin/sh
set -eu

require_contains() {
  file="$1"
  text="$2"
  grep -F "$text" "$file" >/dev/null || {
    echo "missing '$text' in $file" >&2
    exit 1
  }
}

for file in \
  skills/fortress-lab/SKILL.md \
  skills/decision-weaver/SKILL.md \
  skills/dynamic-skill-forge/SKILL.md \
  skills/compliance-reporter/SKILL.md \
  agents/visionary-agent.md \
  agents/analyst-agent.md \
  agents/security-auditor-agent.md \
  agents/executor-agent.md \
  README.md \
  LICENSE \
  CONTRIBUTING.md \
  commands/claude/forge.md \
  commands/claude/next.md \
  commands/claude/status.md \
  commands/claude/bridge-import.md \
  commands/claude/security-oracle.md \
  commands/claude/setup-tools.md \
  commands/claude/setup-hooks.md
do
  [ -f "$file" ] || {
    echo "missing documentation file: $file" >&2
    exit 1
  }
done

for skill_file in \
  skills/fortress-lab/SKILL.md \
  skills/decision-weaver/SKILL.md \
  skills/dynamic-skill-forge/SKILL.md \
  skills/compliance-reporter/SKILL.md
do
  require_contains "$skill_file" "Purpose:"
  require_contains "$skill_file" "Execution Contract:"
done

require_contains README.md "Quick Start"
require_contains README.md "Status"
require_contains README.md "Initial public release"
require_contains README.md "Installation"
require_contains README.md "Philosophy"
require_contains README.md "Superpowers Integration (Optional)"
require_contains README.md "scripts/check-superpowers.sh"
require_contains README.md "mypowers remains the primary zero-trust orchestrator"
require_contains README.md "falls back to its own built-in logic"
require_contains README.md "Hook Setup (One-Time per Tool)"
require_contains README.md ".codex/hooks.json"
require_contains README.md "PreToolUse"
require_contains README.md "Edit|Write|MultiEdit"
require_contains README.md "Bash"
require_contains README.md "commit gate"
require_contains README.md "/mypowers:setup-tools"
require_contains README.md "Optimized for Claude Code"
require_contains README.md "CLAUDE.md"
require_contains README.md "AGENTS.md"
require_contains README.md "/mypowers:setup-hooks"
require_contains README.md "Zero-Trust AI Co-Founder OS"
require_contains README.md "Built with Superpowers in Codex"
require_contains README.md "Native Integration"
require_contains README.md "permission_mode"
require_contains CONTRIBUTING.md 'Run `sh tests/run-all.sh`'
require_contains LICENSE "MIT License"
require_contains agents/security-auditor-agent.md "Role: Security Auditor"
require_contains agents/security-auditor-agent.md "script-enforced veto paths"
require_contains skills/dynamic-skill-forge/SKILL.md "scripts/check-superpowers.sh"
require_contains skills/dynamic-skill-forge/SKILL.md "Superpowers"
require_contains skills/dynamic-skill-forge/SKILL.md "test-driven-development"

echo "PASS: tests/test_docs_and_agents.sh"
