# Pre-edit Security Hook

Purpose: run a lightweight Security Oracle check before a file change is accepted by the host tool.

Behavior:
- calls the shared `scripts/scan.sh` entrypoint
- relies on `scripts/posture.sh` for posture calculation
- blocks only on zero-trust failures that can be detected locally
- never claims full scanner coverage unless the tools are actually installed

Setup:
- Claude Code can load this wrapper natively through `.claude-plugin/plugin.json`
- Codex users register the shared wrapper manually in `.codex/hooks.json`
- the plugin never edits host config automatically
