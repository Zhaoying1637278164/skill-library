#!/bin/sh
set -eu

hook_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
plugin_root=$(CDPATH= cd -- "$hook_dir/../.." && pwd)
project_root="${CLAUDE_PROJECT_DIR:-$(git -C "$plugin_root" rev-parse --show-toplevel 2>/dev/null || pwd)}"

. "$plugin_root/scripts/lib.sh"

deny_with_reason() {
  deny_reason="$1"
  printf '{"continue":false,"stopReason":"'
  json_escape "$deny_reason"
  printf '","reason":"'
  json_escape "$deny_reason"
  printf '","hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"'
  json_escape "$deny_reason"
  printf '"}}\n'
}

hook_input="$(cat)"

if [ -z "$hook_input" ]; then
  printf '{}\n'
  exit 0
fi

file_path="$(extract_json_string "$hook_input" "file_path")"
if [ -z "$file_path" ]; then
  file_path="$(extract_json_string "$hook_input" "path")"
fi

if [ -z "$file_path" ]; then
  printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","additionalContext":"parser_warning: unable to extract file path from hook payload"}}\n'
  exit 0
fi

case "$file_path" in
  /*)
    target_path="$file_path"
    ;;
  *)
    target_path="$project_root/$file_path"
    ;;
esac

if printf '%s\n' "$target_path" | grep -Eq '(^|/)\.\.(/|$)'; then
  deny_with_reason "path traversal rejected by mypowers fast gate"
  exit 0
fi

if [ ! -f "$target_path" ]; then
  printf '{}\n'
  exit 0
fi

if [ ! -r "$target_path" ]; then
  printf '{}\n'
  exit 0
fi

if is_binary_file "$target_path"; then
  printf '{}\n'
  exit 0
fi

if scan_error="$(sh "$plugin_root/scripts/scan.sh" "$target_path" 2>&1 >/dev/null)"; then
  printf '{}\n'
  exit 0
fi

if [ -z "$scan_error" ]; then
  scan_error="hardcoded secret detected in target file"
fi

deny_with_reason "$scan_error"
