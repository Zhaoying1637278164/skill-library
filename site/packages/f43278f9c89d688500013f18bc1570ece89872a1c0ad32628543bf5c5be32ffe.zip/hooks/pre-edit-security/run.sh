#!/bin/sh
set -eu

exec sh "$(dirname "$0")/../../scripts/scan.sh" "$@"
