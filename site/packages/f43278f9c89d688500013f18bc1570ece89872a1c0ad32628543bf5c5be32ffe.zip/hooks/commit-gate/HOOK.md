# Commit Gate Hook

Purpose: run the full mypowers verification pipeline once per commit-producing git command.

Behavior:
- triggers on `PreToolUse` for `Bash`
- classifies git flows (`commit`, `push`, `merge`, `cherry-pick`, `rebase`)
- refreshes posture cache and discovers candidate files per flow
- scans discovered text files for secrets before command execution
- writes one batch attestation manifest to `vault/` for scanned files
- blocks on secret findings or attestation failures, allows otherwise

Notes:
- `git rebase` is explicitly excluded at `PreToolUse` and returns an allow with coverage note
- non-git bash commands pass through silently
- best-effort flows (push/merge/cherry-pick) report coverage notes when file discovery is partial
