#!/bin/sh
set -eu

hook_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
plugin_root=$(CDPATH= cd -- "$hook_dir/../.." && pwd)
project_root="${CLAUDE_PROJECT_DIR:-$(git -C "$plugin_root" rev-parse --show-toplevel 2>/dev/null || pwd)}"

. "$plugin_root/scripts/lib.sh"

tmp_rel="$(mktemp "${TMPDIR:-/tmp}/mypowers-commit-rel.XXXXXX")"
tmp_abs="$(mktemp "${TMPDIR:-/tmp}/mypowers-commit-abs.XXXXXX")"

cleanup() {
  rm -f "$tmp_rel" "$tmp_abs" 2>/dev/null || true
}
trap 'cleanup' EXIT INT TERM HUP

deny_with_reason() {
  deny_reason="$1"
  printf '{"continue":false,"stopReason":"'
  json_escape "$deny_reason"
  printf '","reason":"'
  json_escape "$deny_reason"
  printf '","hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"'
  json_escape "$deny_reason"
  printf '"}}\n'
}

allow_with_context() {
  context="$1"
  printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"allow","additionalContext":"'
  json_escape "$context"
  printf '"}}\n'
}

hook_input="$(cat)"
if [ -z "$hook_input" ]; then
  printf '{}\n'
  exit 0
fi

command_text="$(extract_json_string "$hook_input" "command")"
if [ -z "$command_text" ]; then
  command_text="$(extract_json_string "$hook_input" "bash_command")"
fi

if [ -z "$command_text" ]; then
  printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","additionalContext":"parser_warning: unable to extract command from hook payload"}}\n'
  exit 0
fi

if ! printf '%s\n' "$command_text" | grep -Eq '(^|[;&|[:space:]])git[[:space:]]+'; then
  printf '{}\n'
  exit 0
fi

if printf '%s\n' "$command_text" | grep -Eq 'git[[:space:]]+rebase([[:space:]]|$)'; then
  allow_with_context "mypowers commit gate coverage_note: git rebase is excluded at PreToolUse"
  exit 0
fi

flow=""
coverage="full"
coverage_note=""

if printf '%s\n' "$command_text" | grep -Eq 'git[[:space:]]+commit([[:space:]]|$)'; then
  flow="commit"
elif printf '%s\n' "$command_text" | grep -Eq 'git[[:space:]]+push([[:space:]]|$)'; then
  flow="push"
  coverage="best-effort"
elif printf '%s\n' "$command_text" | grep -Eq 'git[[:space:]]+merge([[:space:]]|$)'; then
  flow="merge"
  coverage="best-effort"
elif printf '%s\n' "$command_text" | grep -Eq 'git[[:space:]]+cherry-pick([[:space:]]|$)'; then
  flow="cherry-pick"
  coverage="best-effort"
else
  printf '{}\n'
  exit 0
fi

if ! git -C "$project_root" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  printf '{}\n'
  exit 0
fi

posture_cached --refresh

: >"$tmp_rel"

if [ "$flow" = "commit" ]; then
  git -C "$project_root" diff --cached --name-only --diff-filter=d >>"$tmp_rel" 2>/dev/null || true

  if printf '%s\n' "$command_text" | grep -Eq '(^|[[:space:]])-a($|[[:space:]])|--all([[:space:]]|$)'; then
    git -C "$project_root" diff --name-only --diff-filter=d >>"$tmp_rel" 2>/dev/null || true
  fi

  if printf '%s\n' "$command_text" | grep -Eq '[[:space:]]--[[:space:]]'; then
    pathspec_tail="$(printf '%s\n' "$command_text" | awk 'match($0, /[[:space:]]--[[:space:]]/) { print substr($0, RSTART + RLENGTH) }')"
    for pathspec in $pathspec_tail; do
      printf '%s\n' "$pathspec" >>"$tmp_rel"
    done
  fi
elif [ "$flow" = "push" ]; then
  if git -C "$project_root" rev-parse --abbrev-ref --symbolic-full-name '@{u}' >/dev/null 2>&1; then
    git -C "$project_root" diff --name-only --diff-filter=d '@{u}..HEAD' >>"$tmp_rel" 2>/dev/null || true
  else
    coverage_note="upstream unavailable"
  fi
elif [ "$flow" = "merge" ]; then
  if [ -f "$project_root/.git/MERGE_HEAD" ]; then
    git -C "$project_root" diff --name-only --diff-filter=d 'HEAD...MERGE_HEAD' >>"$tmp_rel" 2>/dev/null || true
  else
    coverage_note="MERGE_HEAD unavailable"
  fi
elif [ "$flow" = "cherry-pick" ]; then
  cherry_ref="$(printf '%s\n' "$command_text" | sed -n 's/.*git[[:space:]]\+cherry-pick[[:space:]]\+\([^[:space:]]\+\).*/\1/p' | head -n 1)"
  if [ -n "$cherry_ref" ]; then
    git -C "$project_root" show --pretty='' --name-only "$cherry_ref" >>"$tmp_rel" 2>/dev/null || true
  else
    coverage_note="cherry-pick ref unavailable"
  fi
fi

awk 'NF && !seen[$0]++ { print $0 }' "$tmp_rel" >"${tmp_rel}.uniq"
mv "${tmp_rel}.uniq" "$tmp_rel"

: >"$tmp_abs"
while IFS= read -r rel_path || [ -n "${rel_path:-}" ]; do
  [ -n "${rel_path:-}" ] || continue

  case "$rel_path" in
    /*) abs_path="$rel_path" ;;
    *) abs_path="$project_root/$rel_path" ;;
  esac

  if [ ! -f "$abs_path" ] || [ ! -r "$abs_path" ]; then
    continue
  fi

  if is_binary_file "$abs_path"; then
    continue
  fi

  printf '%s\n' "$abs_path" >>"$tmp_abs"
done <"$tmp_rel"

awk 'NF && !seen[$0]++ { print $0 }' "$tmp_abs" >"${tmp_abs}.uniq"
mv "${tmp_abs}.uniq" "$tmp_abs"

scan_count="$(awk 'END { print NR + 0 }' "$tmp_abs")"
if [ "$scan_count" -eq 0 ]; then
  allow_with_context "mypowers commit gate allow: no scannable files discovered (flow=$flow coverage=$coverage${coverage_note:+, note=$coverage_note})"
  exit 0
fi

while IFS= read -r scan_target || [ -n "${scan_target:-}" ]; do
  [ -n "${scan_target:-}" ] || continue
  if scan_error="$(sh "$plugin_root/scripts/scan.sh" "$scan_target" 2>&1 >/dev/null)"; then
    :
  else
    deny_with_reason "$scan_error"
    exit 0
  fi
done <"$tmp_abs"

set --
while IFS= read -r attest_target || [ -n "${attest_target:-}" ]; do
  [ -n "${attest_target:-}" ] || continue
  set -- "$@" "$attest_target"
done <"$tmp_abs"

if [ "$#" -gt 50 ]; then
  coverage_note="${coverage_note:+$coverage_note; }large-change-set"
fi

mkdir -p "$project_root/vault"
if attest_error="$(MYPOWERS_VAULT_DIR="$project_root/vault" sh "$plugin_root/scripts/attest.sh" --batch "$@" 2>&1 >/dev/null)"; then
  :
else
  deny_with_reason "$attest_error"
  exit 0
fi

allow_with_context "mypowers commit gate allow: posture=$POSTURE flow=$flow coverage=$coverage files_scanned=$scan_count${coverage_note:+ note=$coverage_note}"
