# Project Fortress Bible

Last verified: [timestamp]
Merkle Root: [hash]
Security Posture: [FULL|PARTIAL|BASIC]
Native Integration:
- Claude Code permission mode: [AUTO|PLAN|DEFAULT|BYPASS|ACCEPT_EDITS|DONT_ASK|UNKNOWN]
- Verified tools: [x/6]
- Hook lifecycle: [native Claude plugin hooks when available; shared wrappers everywhere else]
- Transparency: [native integration enriches context but never upgrades posture claims beyond local verification]
Decisions from Chat:
- [decision one]

Security Score:
- Status: [GO|NO-GO]
- Notes: [risk summary]

Recent Audit Entries:
- [timestamp] [event summary]
