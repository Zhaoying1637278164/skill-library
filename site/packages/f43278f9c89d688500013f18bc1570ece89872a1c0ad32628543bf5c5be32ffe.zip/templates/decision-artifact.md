**Decision Artifact for mypowers:bridge-import**

Decision: [clear decision summary]
Chosen Option: [single selected option]
Rationale: [why this option was chosen]
Security Implications: [risk and mitigation summary]
Scope: [what is in and out of scope]
Metadata (JSON): {"topic":"example","owner":"mypowers"}
Checksum: sha256:[computed from the artifact body without this line]
