# Contributing

Thanks for helping improve `mypowers`.

## Ground Rules

- Keep the plugin focused on zero-trust forge workflows, not general-purpose editor configuration
- Preserve truthful `FULL`, `PARTIAL`, and `BASIC` posture reporting
- Keep shared scripts POSIX `sh`
- Avoid adding heavyweight runtime dependencies without a clear portability reason

## Before Opening a Pull Request

1. Update documentation and tests with any behavioral change
2. Run `sh tests/run-all.sh`
3. Keep manifest, README, and hook examples aligned
4. Do not introduce claims about enforcement that the current tooling cannot actually provide

## Pull Request Notes

- Explain user-facing behavior changes clearly
- Call out any posture or hook behavior changes explicitly
- Prefer small, reviewable patches over broad unrelated cleanup
