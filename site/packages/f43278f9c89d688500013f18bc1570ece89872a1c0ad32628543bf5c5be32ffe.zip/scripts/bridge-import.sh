#!/bin/sh
set -eu

script_dir="${0%/*}"
if [ "$script_dir" = "$0" ]; then
  script_dir="."
fi

. "$script_dir/lib.sh"

integrity_error() {
  echo "Bridge import rejected: integrity check failed. Possible tampering or corruption detected." >&2
}

sha256_stream() {
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum | awk '{print $1}'
  else
    openssl dgst -sha256 | awk '{print $NF}'
  fi
}

contains_unsafe_backticks() {
  file_path="$1"
  awk '
    BEGIN { in_fence = 0 }
    {
      line = $0
      gsub(/\r/, "", line)

      if (line ~ /^[[:space:]]*```+/) {
        if (in_fence == 0) {
          in_fence = 1
        } else {
          in_fence = 0
        }
        next
      }

      if (in_fence == 1) {
        next
      }

      while (match(line, /`[^`]*`/)) {
        segment = substr(line, RSTART + 1, RLENGTH - 2)
        if (segment ~ /[|;><$]/) {
          exit 0
        }
        line = substr(line, 1, RSTART - 1) substr(line, RSTART + RLENGTH)
      }

      if (line ~ /`/) {
        exit 0
      }
    }

    END {
      exit 1
    }
  ' "$file_path"
}

if [ "${1:-}" = "--hash" ]; then
  if [ "$#" -ne 2 ]; then
    echo "usage: sh scripts/bridge-import.sh --hash /absolute/path/to/file" >&2
    exit 2
  fi

  hash_target="$2"
  if [ ! -f "$hash_target" ]; then
    echo "artifact not found: $hash_target" >&2
    exit 2
  fi

  if [ ! -r "$hash_target" ]; then
    echo "artifact not readable: $hash_target" >&2
    exit 2
  fi

  tr -d '\r' <"$hash_target" | sha256_stream
  exit 0
fi

if [ "$#" -ne 1 ]; then
  echo "usage: sh scripts/bridge-import.sh /absolute/path/to/decision-artifact.md" >&2
  exit 2
fi

artifact="$1"
case "$artifact" in
  /*) ;;
  *)
    echo "artifact path must be absolute: $artifact" >&2
    exit 2
    ;;
esac

if [ ! -f "$artifact" ]; then
  echo "artifact not found: $artifact" >&2
  exit 2
fi

if [ ! -r "$artifact" ]; then
  echo "artifact not readable: $artifact" >&2
  exit 2
fi

eval "$(sh "$script_dir/posture.sh" --env)"

checksum_count="$(tr -d '\r' <"$artifact" | grep -c '^Checksum: sha256:' || true)"
if [ "$checksum_count" -ne 1 ]; then
  integrity_error
  exit 1
fi

checksum_line="$(tr -d '\r' <"$artifact" | grep '^Checksum: sha256:' | head -n 1)"
expected_hash="$(printf '%s\n' "$checksum_line" | sed 's/^Checksum: sha256://')"
if [ -z "$expected_hash" ]; then
  integrity_error
  exit 1
fi
if ! printf '%s\n' "$expected_hash" | grep -Eq '^[a-f0-9]{64}$'; then
  integrity_error
  exit 1
fi

actual_hash="$(tr -d '\r' <"$artifact" | grep -v '^Checksum: sha256:' | sha256_stream)"
if [ "$expected_hash" != "$actual_hash" ]; then
  integrity_error
  exit 1
fi

artifact_hash="$(tr -d '\r' <"$artifact" | sha256_stream)"
payload_leaf="$(sha256_string "payload:$actual_hash")"
checksum_leaf="$(sha256_string "checksum:$expected_hash")"
artifact_leaf="$(sha256_string "artifact:$artifact_hash")"
merkle_root="$(sha256_string "${payload_leaf}${checksum_leaf}${artifact_leaf}")"

if grep -E '(curl|wget)[[:space:]]+[^|]*\|[[:space:]]*(sh|bash|dash|zsh|ksh|fish)([[:space:]]|$)|rm[[:space:]]+-rf([[:space:]]|$)' "$artifact" >/dev/null 2>&1 ||
  grep -F '$(' "$artifact" >/dev/null 2>&1 ||
  contains_unsafe_backticks "$artifact"; then
  echo "bridge import rejected: injection pattern detected" >&2
  exit 1
fi

if ! sh "$script_dir/scan.sh" "$artifact" >/dev/null; then
  exit 1
fi

printf '{"status":"accepted","posture":"'
json_escape "$POSTURE"
printf '","artifact":"'
json_escape "$artifact"
printf '","verified_tools":"'
json_escape "$VERIFIED_TOOLS"
printf '","claude_permission_mode":"'
json_escape "$CLAUDE_PERMISSION_MODE"
printf '","merkle_root":"'
json_escape "$merkle_root"
printf '","message":"'
json_escape "$POSTURE_MESSAGE"
printf '"}\n'
