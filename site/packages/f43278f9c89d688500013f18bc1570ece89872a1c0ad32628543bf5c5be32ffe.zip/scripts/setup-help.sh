#!/bin/sh
set -eu

os_name="$(uname -s 2>/dev/null || printf 'Unknown')"

case "$os_name" in
  Darwin)
    printf '%s\n' 'brew install trivy grype syft semgrep cosign'
    printf '%s\n' 'brew install rekor'
    ;;
  Linux)
    printf '%s\n' 'Install Trivy, Grype, Syft, Semgrep, Cosign, and Rekor using your package manager or vendor instructions.'
    printf '%s\n' 'Examples: apt-get install trivy semgrep || use the official installer scripts when packages are unavailable.'
    ;;
  *)
    printf '%s\n' 'Install Trivy, Grype, Syft, Semgrep, Cosign, and Rekor CLI manually for full posture support.'
    ;;
esac
