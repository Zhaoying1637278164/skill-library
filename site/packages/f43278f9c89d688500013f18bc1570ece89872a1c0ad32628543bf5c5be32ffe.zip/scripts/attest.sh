#!/bin/sh
set -eu

script_dir="${0%/*}"
if [ "$script_dir" = "$0" ]; then
  script_dir="."
fi

. "$script_dir/lib.sh"

eval "$(sh "$script_dir/posture.sh" --env)"

tmp_manifest=""
tmp_fortress=""
tmp_batch_list=""

cleanup_tmp_files() {
  [ -n "$tmp_manifest" ] && rm -f "$tmp_manifest" 2>/dev/null || true
  [ -n "$tmp_fortress" ] && rm -f "$tmp_fortress" 2>/dev/null || true
  [ -n "$tmp_batch_list" ] && rm -f "$tmp_batch_list" 2>/dev/null || true
}

trap 'cleanup_tmp_files' EXIT INT TERM HUP

mktemp_safe() {
  template="$1"

  if command -v mktemp >/dev/null 2>&1; then
    if temp_path="$(mktemp "$template" 2>/dev/null)"; then
      printf '%s' "$temp_path"
      return 0
    fi
  fi

  temp_path="${template%XXXXXX}$$"
  : >"$temp_path"
  printf '%s' "$temp_path"
}

random_suffix4() {
  od_bin=""
  tr_bin=""

  if command -v od >/dev/null 2>&1; then
    od_bin="$(command -v od)"
  elif [ -x /usr/bin/od ]; then
    od_bin="/usr/bin/od"
  fi

  if command -v tr >/dev/null 2>&1; then
    tr_bin="$(command -v tr)"
  elif [ -x /usr/bin/tr ]; then
    tr_bin="/usr/bin/tr"
  fi

  if [ -n "$od_bin" ] && [ -n "$tr_bin" ] && [ -r /dev/urandom ]; then
    candidate="$("$od_bin" -An -N 2 -tx1 /dev/urandom 2>/dev/null | "$tr_bin" -d ' \n')"
    if [ -n "$candidate" ]; then
      printf '%s' "${candidate%${candidate#????}}"
      return 0
    fi
  fi

  candidate="$(sha256_string "$$-$(date -u '+%Y-%m-%dT%H:%M:%SZ')")"
  printf '%s' "${candidate%${candidate#????}}"
}

read_previous_root() {
  fortress_file="$1"

  if [ -f "$fortress_file" ]; then
    previous_root="$(awk -F': ' '/^Merkle Root:/ { print $2; exit }' "$fortress_file")"
    if [ -n "$previous_root" ]; then
      printf '%s' "$previous_root"
      return 0
    fi
  fi

  printf '%s' "genesis"
}

update_or_append_line() {
  file_path="$1"
  prefix="$2"
  replacement="$3"
  tmp_file="$(mktemp_safe "${file_path}.line.XXXXXX")"
  found="0"

  if [ -f "$file_path" ]; then
    while IFS= read -r line || [ -n "$line" ]; do
      case "$line" in
        "$prefix"*)
          if [ "$found" = "0" ]; then
            printf '%s\n' "$replacement" >>"$tmp_file"
            found="1"
          else
            printf '%s\n' "$line" >>"$tmp_file"
          fi
          ;;
        *)
          printf '%s\n' "$line" >>"$tmp_file"
          ;;
      esac
    done <"$file_path"
  fi

  if [ "$found" = "0" ]; then
    printf '%s\n' "$replacement" >>"$tmp_file"
  fi

  mv "$tmp_file" "$file_path"
}

write_fortress_bible() {
  fortress_bible="$1"
  template_path="$2"
  timestamp="$3"
  merkle_root="$4"
  entry_line="$5"

  tmp_fortress="$(mktemp_safe "${fortress_bible}.tmp.XXXXXX")"

  if [ -f "$fortress_bible" ]; then
    cp "$fortress_bible" "$tmp_fortress"
  else
    cp "$template_path" "$tmp_fortress"
  fi

  update_or_append_line "$tmp_fortress" "Last verified:" "Last verified: $timestamp"
  update_or_append_line "$tmp_fortress" "Merkle Root:" "Merkle Root: $merkle_root"
  update_or_append_line "$tmp_fortress" "Security Posture:" "Security Posture: $POSTURE"
  update_or_append_line "$tmp_fortress" "- Claude Code permission mode:" "- Claude Code permission mode: $CLAUDE_PERMISSION_MODE"
  update_or_append_line "$tmp_fortress" "- Verified tools:" "- Verified tools: $VERIFIED_TOOLS"
  update_or_append_line "$tmp_fortress" "- Hook lifecycle:" "- Hook lifecycle: native Claude plugin hooks when available; shared wrappers everywhere else"
  update_or_append_line "$tmp_fortress" "- Transparency:" "- Transparency: native integration enriches context but never upgrades posture claims beyond what local verification supports"
  printf '%s\n' "$entry_line" >>"$tmp_fortress"

  mv "$tmp_fortress" "$fortress_bible"
  tmp_fortress=""
}

validate_target_file() {
  file_path="$1"
  label="$2"

  case "$file_path" in
    /*) ;;
    *)
      echo "$label must be an absolute path: $file_path" >&2
      return 1
      ;;
  esac

  if [ ! -f "$file_path" ]; then
    echo "$label not found: $file_path" >&2
    return 1
  fi

  if [ ! -r "$file_path" ]; then
    echo "$label not readable: $file_path" >&2
    return 1
  fi

  return 0
}

is_batch_mode="0"
if [ "${1:-}" = "--batch" ]; then
  is_batch_mode="1"
  shift
fi

if [ "$is_batch_mode" = "0" ] && [ "$#" -ne 2 ]; then
  echo "usage: sh scripts/attest.sh /absolute/path/to/file vault" >&2
  echo "   or: sh scripts/attest.sh --batch /absolute/path/to/file1 [/absolute/path/to/file2 ...]" >&2
  exit 2
fi

if [ "$is_batch_mode" = "1" ] && [ "$#" -lt 1 ]; then
  echo "usage: sh scripts/attest.sh --batch /absolute/path/to/file1 [/absolute/path/to/file2 ...]" >&2
  exit 2
fi

template_path="$script_dir/../templates/fortress-bible.md"
timestamp="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"

if [ "$is_batch_mode" = "0" ]; then
  target="$1"
  output_dir="$2"

  if ! validate_target_file "$target" "attestation target"; then
    exit 2
  fi

  mkdir -p "$output_dir"

  file_hash="$(sha256_file "$target")"
  provenance="local-merkle"
  manifest="$output_dir/${file_hash}.json"
  fortress_bible="${MYPOWERS_FORTRESS_BIBLE:-$output_dir/fortress-bible.md}"
  previous_root="$(read_previous_root "$fortress_bible")"

  file_leaf="$(sha256_string "file:$file_hash")"
  posture_leaf="$(sha256_string "posture:$POSTURE")"
  mode_leaf="$(sha256_string "mode:$CLAUDE_PERMISSION_MODE")"
  previous_leaf="$(sha256_string "previous:$previous_root")"
  merkle_root="$(sha256_string "${file_leaf}${posture_leaf}${mode_leaf}${previous_leaf}")"

  tmp_manifest="$(mktemp_safe "${manifest}.tmp.XXXXXX")"

  printf '{"status":"attested","posture":"' >"$tmp_manifest"
  json_escape "$POSTURE" >>"$tmp_manifest"
  printf '","target":"' >>"$tmp_manifest"
  json_escape "$target" >>"$tmp_manifest"
  printf '","sha256":"' >>"$tmp_manifest"
  json_escape "$file_hash" >>"$tmp_manifest"
  printf '","provenance":"' >>"$tmp_manifest"
  json_escape "$provenance" >>"$tmp_manifest"
  printf '","merkle_root":"' >>"$tmp_manifest"
  json_escape "$merkle_root" >>"$tmp_manifest"
  printf '","previous_merkle_root":"' >>"$tmp_manifest"
  json_escape "$previous_root" >>"$tmp_manifest"
  printf '","verified_tools":"' >>"$tmp_manifest"
  json_escape "$VERIFIED_TOOLS" >>"$tmp_manifest"
  printf '","claude_permission_mode":"' >>"$tmp_manifest"
  json_escape "$CLAUDE_PERMISSION_MODE" >>"$tmp_manifest"
  printf '","timestamp":"' >>"$tmp_manifest"
  json_escape "$timestamp" >>"$tmp_manifest"
  printf '","message":"' >>"$tmp_manifest"
  json_escape "$POSTURE_MESSAGE" >>"$tmp_manifest"
  printf '"}\n' >>"$tmp_manifest"

  mv "$tmp_manifest" "$manifest"
  tmp_manifest=""

  write_fortress_bible "$fortress_bible" "$template_path" "$timestamp" "$merkle_root" "- [$timestamp] attested $target sha256=$file_hash posture=$POSTURE mode=$CLAUDE_PERMISSION_MODE verified=$VERIFIED_TOOLS provenance=$provenance"

  printf '{"status":"attested","manifest":"'
  json_escape "$manifest"
  printf '","provenance":"'
  json_escape "$provenance"
  printf '","merkle_root":"'
  json_escape "$merkle_root"
  printf '","claude_permission_mode":"'
  json_escape "$CLAUDE_PERMISSION_MODE"
  printf '"}\n'

  exit 0
fi

output_dir="${MYPOWERS_VAULT_DIR:-vault}"
mkdir -p "$output_dir"

fortress_bible="${MYPOWERS_FORTRESS_BIBLE:-$output_dir/fortress-bible.md}"
previous_root="$(read_previous_root "$fortress_bible")"
provenance="local-merkle"
manifest_key="pre-commit-${timestamp}-$(random_suffix4).json"
manifest="$output_dir/$manifest_key"

tmp_batch_list="$(mktemp_safe "${output_dir}/.attest-batch.XXXXXX")"
batch_count=0

for candidate in "$@"; do
  if validate_target_file "$candidate" "attestation target"; then
    hash="$(sha256_file "$candidate")"
    printf '%s\t%s\n' "$candidate" "$hash" >>"$tmp_batch_list"
    batch_count=$((batch_count + 1))
  else
    echo "warning: skipping invalid batch target: $candidate" >&2
  fi
done

if [ "$batch_count" -eq 0 ]; then
  echo "no valid batch targets were provided" >&2
  exit 2
fi

posture_leaf="$(sha256_string "posture:$POSTURE")"
mode_leaf="$(sha256_string "mode:$CLAUDE_PERMISSION_MODE")"
previous_leaf="$(sha256_string "previous:$previous_root")"
merkle_input="${posture_leaf}${mode_leaf}${previous_leaf}"

while IFS="$(printf '\t')" read -r batch_target batch_hash || [ -n "${batch_target:-}" ]; do
  [ -n "${batch_target:-}" ] || continue
  file_leaf="$(sha256_string "file:$batch_hash")"
  merkle_input="${merkle_input}${file_leaf}"
done <"$tmp_batch_list"

merkle_root="$(sha256_string "$merkle_input")"

tmp_manifest="$(mktemp_safe "${manifest}.tmp.XXXXXX")"

printf '{"status":"attested","mode":"batch","manifest_key":"' >"$tmp_manifest"
json_escape "$manifest_key" >>"$tmp_manifest"
printf '","posture":"' >>"$tmp_manifest"
json_escape "$POSTURE" >>"$tmp_manifest"
printf '","provenance":"' >>"$tmp_manifest"
json_escape "$provenance" >>"$tmp_manifest"
printf '","merkle_root":"' >>"$tmp_manifest"
json_escape "$merkle_root" >>"$tmp_manifest"
printf '","previous_merkle_root":"' >>"$tmp_manifest"
json_escape "$previous_root" >>"$tmp_manifest"
printf '","verified_tools":"' >>"$tmp_manifest"
json_escape "$VERIFIED_TOOLS" >>"$tmp_manifest"
printf '","claude_permission_mode":"' >>"$tmp_manifest"
json_escape "$CLAUDE_PERMISSION_MODE" >>"$tmp_manifest"
printf '","timestamp":"' >>"$tmp_manifest"
json_escape "$timestamp" >>"$tmp_manifest"
printf '","files":[' >>"$tmp_manifest"

first_entry="1"
while IFS="$(printf '\t')" read -r batch_target batch_hash || [ -n "${batch_target:-}" ]; do
  [ -n "${batch_target:-}" ] || continue
  if [ "$first_entry" = "1" ]; then
    first_entry="0"
  else
    printf ',' >>"$tmp_manifest"
  fi

  printf '{"target":"' >>"$tmp_manifest"
  json_escape "$batch_target" >>"$tmp_manifest"
  printf '","sha256":"' >>"$tmp_manifest"
  json_escape "$batch_hash" >>"$tmp_manifest"
  printf '"}' >>"$tmp_manifest"
done <"$tmp_batch_list"

printf '],"message":"' >>"$tmp_manifest"
json_escape "$POSTURE_MESSAGE" >>"$tmp_manifest"
printf '"}\n' >>"$tmp_manifest"

mv "$tmp_manifest" "$manifest"
tmp_manifest=""

write_fortress_bible "$fortress_bible" "$template_path" "$timestamp" "$merkle_root" "- [$timestamp] $manifest_key files=$batch_count posture=$POSTURE mode=$CLAUDE_PERMISSION_MODE verified=$VERIFIED_TOOLS provenance=$provenance"

printf '{"status":"attested","mode":"batch","manifest":"'
json_escape "$manifest"
printf '","manifest_key":"'
json_escape "$manifest_key"
printf '","files_attested":%s,"provenance":"' "$batch_count"
json_escape "$provenance"
printf '","merkle_root":"'
json_escape "$merkle_root"
printf '","claude_permission_mode":"'
json_escape "$CLAUDE_PERMISSION_MODE"
printf '"}\n'
