#!/bin/sh
set -eu

_SCAN_DIR="${0%/*}"
if [ "$_SCAN_DIR" = "$0" ]; then
  _SCAN_DIR="."
fi

. "$_SCAN_DIR/lib.sh"

if [ "$#" -ne 1 ]; then
  echo "usage: sh scripts/scan.sh /absolute/path/to/file" >&2
  exit 2
fi

TARGET="$1"
case "$TARGET" in
  /*) ;;
  *)
    echo "scan target must be an absolute path: $TARGET" >&2
    exit 2
    ;;
esac

if [ ! -f "$TARGET" ]; then
  echo "scan target not found: $TARGET" >&2
  exit 2
fi

if [ ! -r "$TARGET" ]; then
  echo "scan target not readable: $TARGET" >&2
  exit 2
fi

eval "$(sh "$_SCAN_DIR/posture.sh" --env)"

MATCHABLE_VALUE='[^[:space:]"'"'"',#}]+'
ELLIPSIS_VALUE='[^[:space:]"'"'"',#}]*\.\.\.[^[:space:]"'"'"',#}]*'
OPENAI_KEY_PATTERN='OPENAI_API_KEY|openai_api_key'
SECRET_KEY_PATTERN='SECRET_KEY|secret_key'
AWS_ACCESS_KEY_PATTERN='AWS_ACCESS_KEY_ID|aws_access_key_id'
GITHUB_TOKEN_PATTERN='GITHUB_TOKEN|github_token|GH_TOKEN|gh_token'
ENV_VAR_REFERENCE_PATTERN='\$[A-Za-z_][A-Za-z0-9_]*|\$\{[A-Za-z_][A-Za-z0-9_]*\}'
SLACK_TOKEN_PATTERN='xox[baprs]-[A-Za-z0-9-]{10,}'
STRIPE_LIVE_KEY_PATTERN='[sr]k_live_[A-Za-z0-9]{20,}'
PRIVATE_KEY_HEADER_PATTERN='-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----'

normalize_scan_line() {
  NORMALIZED_SCAN_LINE="$1"
  tab="$(printf '\t')"
  cr="$(printf '\r')"

  while :; do
    case "$NORMALIZED_SCAN_LINE" in
      *"$cr")
        NORMALIZED_SCAN_LINE=${NORMALIZED_SCAN_LINE%"$cr"}
        ;;
      *" ")
        NORMALIZED_SCAN_LINE=${NORMALIZED_SCAN_LINE%" "}
        ;;
      *"$tab")
        NORMALIZED_SCAN_LINE=${NORMALIZED_SCAN_LINE%"$tab"}
        ;;
      *)
        break
        ;;
    esac
  done
}

match_secret_assignment_line() {
  line="$1"
  key_pattern="$2"
  value_pattern="$3"

  if printf '%s\n' "$line" | grep -Eq "^[[:space:]]*(\{[[:space:]]*)?(#|//)?[[:space:]]*(export[[:space:]]+)?[\"']?($key_pattern)[\"']?[[:space:]]*[:=][[:space:]]*[\"']?($value_pattern)[\"']?([[:space:]]*,?[[:space:]]*\}?[[:space:]]*(#.*|//.*)?)?$"; then
    return 0
  fi

  return 1
}

match_secret_object_line() {
  line="$1"
  key_pattern="$2"
  value_pattern="$3"

  if printf '%s\n' "$line" | grep -Eq "^[[:space:]]*\{.*[\"']($key_pattern)[\"']?[[:space:]]*:[[:space:]]*[\"']?($value_pattern)[\"']?.*\}[[:space:]]*(#.*|//.*)?$"; then
    return 0
  fi

  return 1
}

match_secret_line() {
  line="$1"
  key_pattern="$2"
  value_pattern="$3"

  if match_secret_assignment_line "$line" "$key_pattern" "$value_pattern" ||
    match_secret_object_line "$line" "$key_pattern" "$value_pattern"; then
    return 0
  fi

  return 1
}

is_secret_env_indirection_line() {
  line="$1"

  if match_secret_assignment_line "$line" "$SECRET_KEY_PATTERN" "$ENV_VAR_REFERENCE_PATTERN"; then
    return 0
  fi

  return 1
}

is_placeholder_secret_line() {
  line="$1"

  if match_secret_line "$line" "$OPENAI_KEY_PATTERN" "sk-(test|example)-$MATCHABLE_VALUE|$ELLIPSIS_VALUE"; then
    return 0
  fi

  if match_secret_line "$line" "$OPENAI_KEY_PATTERN|$SECRET_KEY_PATTERN|$AWS_ACCESS_KEY_PATTERN|$GITHUB_TOKEN_PATTERN" "example|test|fixture|placeholder|sample|dummy|fake|changeme|replace[-_ ]?me|your[-_ ]?(key|token|secret)|$ELLIPSIS_VALUE"; then
    return 0
  fi

  return 1
}

scan_secret_line() {
  line="$1"

  case "$line" in
    *OPENAI_API_KEY*|*openai_api_key*|*SECRET_KEY*|*secret_key*|*AWS_ACCESS_KEY_ID*|*aws_access_key_id*|*GITHUB_TOKEN*|*github_token*|*GH_TOKEN*|*gh_token*|*ghp_*|*github_pat_*|*AKIA*|*ASIA*)
      ;;
    *)
      return 1
      ;;
  esac

  if match_secret_line "$line" "$OPENAI_KEY_PATTERN" "sk-[A-Za-z0-9_-]{16,}" ||
    match_secret_line "$line" "$SECRET_KEY_PATTERN" "$MATCHABLE_VALUE" ||
    match_secret_line "$line" "$AWS_ACCESS_KEY_PATTERN" "(AKIA|ASIA)[0-9A-Z]{16}" ||
    match_secret_line "$line" "$GITHUB_TOKEN_PATTERN" "gh[pousr]_[A-Za-z0-9_]{20,255}|github_pat_[A-Za-z0-9_]{20,255}"; then
    if is_secret_env_indirection_line "$line"; then
      return 1
    fi
    if ! is_placeholder_secret_line "$line"; then
      return 0
    fi
    return 1
  fi

  return 1
}

scan_additional_secret_line() {
  line="$1"

  case "$line" in
    *xox*|*k_live_*|*PRIVATE\ KEY*)
      ;;
    *)
      return 1
      ;;
  esac

  if printf '%s\n' "$line" | grep -Eq "$SLACK_TOKEN_PATTERN|$STRIPE_LIVE_KEY_PATTERN"; then
    return 0
  fi

  if printf '%s\n' "$line" | grep -Eq "^[[:space:]]*$PRIVATE_KEY_HEADER_PATTERN[[:space:]]*$"; then
    return 0
  fi

  return 1
}

scan_bypass_line() {
  line="$1"

  if printf '%s\n' "$line" | grep -Eq '^[[:space:]]*mypowers:[[:space:]]*skip-security-oracle[[:space:]]*$|^[[:space:]]*(#|//|[-*+]|[0-9]+\.)[[:space:]]+mypowers:[[:space:]]*skip-security-oracle([[:space:]].*)?$'; then
    return 0
  fi

  return 1
}

line_count=0
while IFS= read -r line || [ -n "$line" ]; do
  line_count=$((line_count + 1))
  if [ "$line_count" -gt 10000 ]; then
    break
  fi

  normalize_scan_line "$line"

  if scan_secret_line "$NORMALIZED_SCAN_LINE" || scan_additional_secret_line "$NORMALIZED_SCAN_LINE"; then
    echo "hardcoded secret detected in $TARGET; move it to a secret store or environment variable before editing" >&2
    exit 1
  fi

  if scan_bypass_line "$NORMALIZED_SCAN_LINE"; then
    echo "security oracle bypass marker detected in $TARGET; remove the marker and use an approved exception path instead" >&2
    exit 1
  fi
done <"$TARGET"

printf '{"status":"ok","posture":"'
json_escape "$POSTURE"
printf '","target":"'
json_escape "$TARGET"
printf '","message":"'
json_escape "$POSTURE_MESSAGE"
printf '"}\n'
