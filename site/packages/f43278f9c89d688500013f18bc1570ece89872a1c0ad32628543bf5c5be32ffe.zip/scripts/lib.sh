#!/bin/sh
set -eu

json_escape() {
  value="${1:-}"
  od_cmd=""
  if command -v od >/dev/null 2>&1; then
    od_cmd="$(command -v od)"
  elif [ -x /usr/bin/od ]; then
    od_cmd="/usr/bin/od"
  elif [ -x /bin/od ]; then
    od_cmd="/bin/od"
  fi

  if [ -z "$od_cmd" ]; then
    # Fallback to raw output when byte-level escaping tools are unavailable.
    printf '%s' "$value"
    return 0
  fi

  set -- $(printf '%s' "$value" | LC_ALL=C "$od_cmd" -An -v -t u1)
  for byte do
    case "$byte" in
      34)
        printf '%s' "\\\""
        ;;
      92)
        printf '%s' "\\\\"
        ;;
      8)
        printf '%s' "\\b"
        ;;
      9)
        printf '%s' "\\t"
        ;;
      10)
        printf '%s' "\\n"
        ;;
      12)
        printf '%s' "\\f"
        ;;
      13)
        printf '%s' "\\r"
        ;;
      0|1|2|3|4|5|6|7|11|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)
        printf '%s' "\\u$(printf '%04x' "$byte")"
        ;;
      *)
        printf '%b' "\\$(printf '%03o' "$byte")"
        ;;
    esac
  done
}

extract_json_string() {
  json_input="${1:-}"
  target_key="${2:-}"

  if [ -z "$target_key" ]; then
    printf ''
    return 0
  fi

  printf '%s' "$json_input" | awk -v target_key="$target_key" '
function read_json_string(src, start,    i, c, esc, out) {
  out = ""
  esc = 0
  for (i = start; i <= length(src); i++) {
    c = substr(src, i, 1)
    if (esc == 1) {
      if (c == "\"") {
        out = out "\""
      } else if (c == "\\") {
        out = out "\\"
      } else if (c == "/") {
        out = out "/"
      } else if (c == "b") {
        out = out sprintf("%c", 8)
      } else if (c == "f") {
        out = out sprintf("%c", 12)
      } else if (c == "n") {
        out = out sprintf("%c", 10)
      } else if (c == "r") {
        out = out sprintf("%c", 13)
      } else if (c == "t") {
        out = out sprintf("%c", 9)
      } else if (c == "u") {
        out = out "u"
      } else {
        out = out c
      }
      esc = 0
      continue
    }

    if (c == "\\") {
      esc = 1
      continue
    }

    if (c == "\"") {
      _read_end = i
      return out
    }

    out = out c
  }

  _read_end = length(src)
  return out
}

function skip_ws(src, start,    i, c) {
  for (i = start; i <= length(src); i++) {
    c = substr(src, i, 1)
    if (c !~ /[ \t\r\n]/) {
      return i
    }
  }
  return length(src) + 1
}

function find_key_string(src, key,    i, c, key_text, j, k, value) {
  key_text = ""
  for (i = 1; i <= length(src); i++) {
    c = substr(src, i, 1)
    if (c != "\"") {
      continue
    }

    key_text = read_json_string(src, i + 1)
    j = _read_end
    k = skip_ws(src, j + 1)
    if (substr(src, k, 1) == ":" && key_text == key) {
      k = skip_ws(src, k + 1)
      if (substr(src, k, 1) == "\"") {
        value = read_json_string(src, k + 1)
        return value
      }
    }
    i = j
  }

  return ""
}

function find_tool_input_object(src,    i, c, key_text, j, k, depth, in_str, esc, ch, start_obj, end_obj) {
  key_text = ""
  for (i = 1; i <= length(src); i++) {
    c = substr(src, i, 1)
    if (c != "\"") {
      continue
    }

    key_text = read_json_string(src, i + 1)
    j = _read_end
    k = skip_ws(src, j + 1)
    if (key_text == "tool_input" && substr(src, k, 1) == ":") {
      k = skip_ws(src, k + 1)
      if (substr(src, k, 1) != "{") {
        i = j
        continue
      }

      start_obj = k
      depth = 0
      in_str = 0
      esc = 0
      end_obj = 0

      for (; k <= length(src); k++) {
        ch = substr(src, k, 1)

        if (in_str == 1) {
          if (esc == 1) {
            esc = 0
          } else if (ch == "\\") {
            esc = 1
          } else if (ch == "\"") {
            in_str = 0
          }
          continue
        }

        if (ch == "\"") {
          in_str = 1
          continue
        }

        if (ch == "{") {
          depth++
          continue
        }

        if (ch == "}") {
          depth--
          if (depth == 0) {
            end_obj = k
            break
          }
        }
      }

      if (end_obj > start_obj) {
        return substr(src, start_obj, end_obj - start_obj + 1)
      }
    }
    i = j
  }

  return ""
}

{
  input = input $0 "\n"
}

END {
  value = ""
  tool_obj = find_tool_input_object(input)
  if (tool_obj != "") {
    value = find_key_string(tool_obj, target_key)
  }

  if (value == "") {
    value = find_key_string(input, target_key)
  }

  printf "%s", value
}
'
}

sha256_file() {
  file_path="$1"
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$file_path" | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$file_path" | awk '{print $1}'
  else
    openssl dgst -sha256 "$file_path" | awk '{print $NF}'
  fi
}

sha256_string() {
  value="${1:-}"
  if command -v shasum >/dev/null 2>&1; then
    printf '%s' "$value" | shasum -a 256 | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    printf '%s' "$value" | sha256sum | awk '{print $1}'
  else
    printf '%s' "$value" | openssl dgst -sha256 | awk '{print $NF}'
  fi
}

resolve_real_path() {
  target_path="$1"

  if command -v realpath >/dev/null 2>&1; then
    if resolved="$(realpath "$target_path" 2>/dev/null)"; then
      printf '%s' "$resolved"
      return 0
    fi
  fi

  if command -v readlink >/dev/null 2>&1; then
    if resolved="$(readlink -f "$target_path" 2>/dev/null)"; then
      printf '%s' "$resolved"
      return 0
    fi
  fi

  if [ -d "$target_path" ]; then
    (
      cd "$target_path" >/dev/null 2>&1 && pwd -P
    )
    return 0
  fi

  parent_dir=$(dirname -- "$target_path")
  base_name=$(basename -- "$target_path")

  if [ -d "$parent_dir" ]; then
    (
      cd "$parent_dir" >/dev/null 2>&1 && printf '%s/%s' "$(pwd -P)" "$base_name"
    )
    return 0
  fi

  printf '%s' "$target_path"
}

is_binary_file() {
  file_path="$1"

  if [ ! -f "$file_path" ]; then
    return 1
  fi

  if command -v file >/dev/null 2>&1; then
    if file --mime "$file_path" 2>/dev/null | grep -qi 'charset=binary'; then
      return 0
    fi
  fi

  if LC_ALL=C od -An -tx1 -N 512 "$file_path" 2>/dev/null | grep -qi ' 00'; then
    return 0
  fi

  return 1
}

posture_cached() {
  refresh="0"
  if [ "${1:-}" = "--refresh" ]; then
    refresh="1"
  fi

  project_root="${CLAUDE_PROJECT_DIR:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
  cache_file="${TMPDIR:-/tmp}/mypowers-posture-$(sha256_string "$project_root")"
  posture_script="${MYPOWERS_POSTURE_SCRIPT:-$project_root/scripts/posture.sh}"

  if [ "$refresh" = "1" ] || [ ! -f "$cache_file" ]; then
    tmp_cache="${cache_file}.tmp.$$"
    if sh "$posture_script" --env >"$tmp_cache" 2>/dev/null; then
      mv "$tmp_cache" "$cache_file"
    else
      rm -f "$tmp_cache"
    fi
  fi

  cache_ok="1"
  if [ -f "$cache_file" ]; then
    # shellcheck disable=SC1090
    if . "$cache_file" 2>/dev/null; then
      :
    else
      cache_ok="0"
    fi
  else
    cache_ok="0"
  fi

  if [ "$cache_ok" != "1" ] || [ -z "${POSTURE:-}" ]; then
    POSTURE="BASIC"
    DETECTED_TOOLS=""
    MISSING_TOOLS=""
    VERIFIED_TOOLS="0/0"
    CLAUDE_PERMISSION_MODE="UNKNOWN"
    POSTURE_MESSAGE="mypowers posture cache unavailable"
  fi

  POSTURE_LEVEL="$POSTURE"

  export POSTURE
  export POSTURE_LEVEL
  export DETECTED_TOOLS
  export MISSING_TOOLS
  export VERIFIED_TOOLS
  export CLAUDE_PERMISSION_MODE
  export POSTURE_MESSAGE

  return 0
}