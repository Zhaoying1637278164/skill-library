#!/bin/sh
set -eu

POSTURE="${1:-}"
MISSING="${2:-}"
VERIFIED="${3:-0/0}"
CLAUDE_MODE="${4:-UNKNOWN}"

case "$POSTURE" in
  FULL)
    printf '%s\n' "Claude Code permission mode: ${CLAUDE_MODE} | mypowers posture: FULL | Security Oracle verified: ${VERIFIED} tools present"
    ;;
  PARTIAL)
    printf '%s\n' "Claude Code permission mode: ${CLAUDE_MODE} | mypowers posture: PARTIAL | Security Oracle verified: ${VERIFIED} tools present | Missing: ${MISSING}"
    ;;
  BASIC)
    printf '%s\n' "Claude Code permission mode: ${CLAUDE_MODE} | mypowers posture: BASIC | Security Oracle verified: ${VERIFIED} tools present | Missing: ${MISSING}"
    ;;
  *)
    printf '%s\n' "Claude Code permission mode: ${CLAUDE_MODE} | mypowers posture: UNKNOWN | Security Oracle verified: ${VERIFIED} tools present | Missing: ${MISSING}"
    ;;
esac
