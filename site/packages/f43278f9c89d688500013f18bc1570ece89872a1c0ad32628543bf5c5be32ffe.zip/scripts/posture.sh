#!/bin/sh
set -eu

MODE="json"
if [ "${1:-}" = "--json" ]; then
  MODE="json"
fi
if [ "${1:-}" = "--env" ]; then
  MODE="env"
fi
if [ "${1:-}" = "--simple" ]; then
  MODE="simple"
fi

script_dir="${0%/*}"
if [ "$script_dir" = "$0" ]; then
  script_dir="."
fi

. "$script_dir/lib.sh"

required_tools="trivy grype syft semgrep cosign rekor-cli"
detected=""
missing=""
detected_count=0
required_count=0

normalize_claude_permission_mode() {
  tr_bin=""
  if command -v tr >/dev/null 2>&1; then
    tr_bin="$(command -v tr)"
  elif [ -x /usr/bin/tr ]; then
    tr_bin="/usr/bin/tr"
  elif [ -x /bin/tr ]; then
    tr_bin="/bin/tr"
  fi

  case "${1:-}" in
    auto|AUTO)
      printf '%s' 'AUTO'
      ;;
    plan|PLAN)
      printf '%s' 'PLAN'
      ;;
    default|DEFAULT)
      printf '%s' 'DEFAULT'
      ;;
    acceptEdits|ACCEPTEDITS|ACCEPT_EDITS)
      printf '%s' 'ACCEPT_EDITS'
      ;;
    bypassPermissions|BYPASSPERMISSIONS|BYPASS)
      printf '%s' 'BYPASS'
      ;;
    dontAsk|DONTASK|DONT_ASK)
      printf '%s' 'DONT_ASK'
      ;;
    "")
      printf '%s' 'UNKNOWN'
      ;;
    *)
      if [ -n "$tr_bin" ]; then
        printf '%s' "$1" | "$tr_bin" '[:lower:]' '[:upper:]'
      else
        printf '%s' "$1"
      fi
      ;;
  esac
}

append_csv() {
  current="$1"
  next="$2"
  if [ -z "$current" ]; then
    printf '%s' "$next"
  else
    printf '%s,%s' "$current" "$next"
  fi
}

sh_quote() {
  value="$1"
  printf '%s' "'"
  while :; do
    case "$value" in
      *"'"*)
        prefix=${value%%"'"*}
        printf '%s' "$prefix"
        printf '%s' "\\"
        printf '%s' "'"
        printf '%s' "'"
        value=${value#*"'"}
        ;;
      *)
        printf '%s' "$value"
        printf '%s' "'"
        return
        ;;
    esac
  done
}

for tool in $required_tools; do
  required_count=$((required_count + 1))
  if command -v "$tool" >/dev/null 2>&1; then
    detected="$(append_csv "$detected" "$tool")"
    detected_count=$((detected_count + 1))
  else
    missing="$(append_csv "$missing" "$tool")"
  fi
done

if [ "$detected_count" -eq 0 ]; then
  posture="BASIC"
elif [ "$detected_count" -eq "$required_count" ]; then
  posture="FULL"
else
  posture="PARTIAL"
fi

verified_tools="${detected_count}/${required_count}"
claude_permission_mode="$(normalize_claude_permission_mode "${CLAUDE_CODE_PERMISSION_MODE:-${CLAUDE_PERMISSION_MODE:-}}")"
MESSAGE="$(/bin/sh "$script_dir/posture-reporting.sh" "$posture" "${missing:-none}" "$verified_tools" "$claude_permission_mode")"

if [ "$MODE" = "simple" ]; then
  printf '%s\n' "$posture"
  exit 0
fi

if [ "$MODE" = "env" ]; then
  printf 'POSTURE=%s\n' "$(sh_quote "$posture")"
  printf 'DETECTED_TOOLS=%s\n' "$(sh_quote "$detected")"
  printf 'MISSING_TOOLS=%s\n' "$(sh_quote "$missing")"
  printf 'VERIFIED_TOOLS=%s\n' "$(sh_quote "$verified_tools")"
  printf 'CLAUDE_PERMISSION_MODE=%s\n' "$(sh_quote "$claude_permission_mode")"
  printf 'POSTURE_MESSAGE=%s\n' "$(sh_quote "$MESSAGE")"
  exit 0
fi

printf '{"posture":"'
json_escape "$posture"
printf '","detected_tools":"'
json_escape "$detected"
printf '","missing_tools":"'
json_escape "$missing"
printf '","verified_tools":"'
json_escape "$verified_tools"
printf '","claude_permission_mode":"'
json_escape "$claude_permission_mode"
printf '","message":"'
json_escape "$MESSAGE"
printf '"}\n'
