#!/bin/sh
set -eu

mode="json"

case "${1:-}" in
  "")
    ;;
  --json)
    mode="json"
    ;;
  --env)
    mode="env"
    ;;
  *)
    echo "usage: sh scripts/check-superpowers.sh [--json|--env]" >&2
    exit 1
    ;;
esac

roots=""

add_root() {
  path="$1"
  [ -n "$path" ] || return 0
  [ -d "$path" ] || return 0
  case "
$roots
" in
    *"
$path
"*)
      return 0
      ;;
  esac
  roots="${roots}${roots:+
}$path"
}

if [ -n "${HOME:-}" ]; then
  add_root "$HOME/.claude/skills/superpowers"
  add_root "$HOME/.claude/skills"
  add_root "$HOME/.claude/plugins/superpowers/skills"
  add_root "$HOME/.codex/skills/superpowers"
  add_root "$HOME/.codex/skills"
  add_root "$HOME/.codex/superpowers/skills"
fi

if [ -n "${CLAUDE_HOME:-}" ]; then
  add_root "$CLAUDE_HOME/skills/superpowers"
  add_root "$CLAUDE_HOME/skills"
fi

if [ -n "${CODEX_HOME:-}" ]; then
  add_root "$CODEX_HOME/skills/superpowers"
  add_root "$CODEX_HOME/skills"
  add_root "$CODEX_HOME/superpowers/skills"
fi

has_required_skill_bundle() {
  root="$1"
  [ -f "$root/brainstorming/SKILL.md" ] || return 1
  [ -f "$root/writing-plans/SKILL.md" ] || return 1
  [ -f "$root/test-driven-development/SKILL.md" ] || return 1
  return 0
}

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

shell_escape() {
  printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"
}

available="false"
reason="no standard Superpowers skill installation found"
root_path=""

OLD_IFS=${IFS}
IFS='
'
for candidate in $roots; do
  if has_required_skill_bundle "$candidate"; then
    available="true"
    root_path="$candidate"
    reason="found recognized Superpowers skills in $candidate"
    break
  fi
done
IFS=${OLD_IFS}

if [ "$mode" = "env" ]; then
  printf 'SUPERPOWERS_AVAILABLE=%s\n' "$available"
  printf 'SUPERPOWERS_REASON=%s\n' "$(shell_escape "$reason")"
  printf 'SUPERPOWERS_ROOT=%s\n' "$(shell_escape "$root_path")"
  exit 0
fi

printf '{"available":%s,"reason":"%s","root":"%s"}\n' \
  "$available" \
  "$(json_escape "$reason")" \
  "$(json_escape "$root_path")"
