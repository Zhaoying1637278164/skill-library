---
name: mypowers-compliance-reporter
description: Use when summarizing posture, decisions, and attestation outputs into audit-friendly artifacts for reviewers or compliance stakeholders.
---

# mypowers:compliance-reporter

Purpose:
- turn posture, decisions, and attestation output into evidence-friendly summaries

Execution Contract:
- summarize only the evidence that currently exists in repo artifacts
- include the current posture and mark evidence partial when posture is not `FULL`
- mark outputs as partial when optional tooling is missing
- never imply stronger compliance coverage than the available evidence supports

Responsibilities:
- summarize posture, decisions, and attestation outputs
- produce evidence-friendly markdown artifacts
- map outputs to common controls such as SOC 2 and FedRAMP at a documentation level
- state clearly when evidence is partial because optional tooling is missing
