---
name: mypowers-security-oracle
description: Use when validating edits, imported artifacts, or forge outputs against the mypowers zero-trust contract and current local tooling posture.
---

# mypowers:security-oracle

Claude Code note: This skill is intended to feel native in Claude Code edit flows. Read `CLAUDE.md` and `AGENTS.md` first, then let the configured hooks and shared scripts enforce the same posture contract.

Purpose:
- validate edits, imports, and forge outputs against the mypowers zero-trust contract

Execution Contract:
- every run starts with `scripts/posture.sh`
- every invocation starts with `eval "$(sh scripts/posture.sh --env)"`
- establish and report `FULL / PARTIAL / BASIC` before describing any enforcement
- report Claude Code permission mode when it is available from native hook context
- every scan path calls `scripts/scan.sh`
- every invocation ends with the posture message from `scripts/posture-reporting.sh`
- never claim stronger enforcement than the current posture supports

Posture contract:
- `FULL / PARTIAL / BASIC`

High-signal local blocks:
- hardcoded secrets in env-style, JSON-style, and commented assignments
- Security Oracle bypass markers such as `mypowers: skip-security-oracle`
- bridge-import checksum failures and shell-execution patterns such as `$(...)`, backticks, or `curl|sh|bash|dash`

Progressive behavior:
- degrade gracefully when Trivy, Grype, Syft, Semgrep, Cosign, or Rekor CLI are missing
- report exactly which tools were unavailable
- use `scripts/setup-help.sh` when posture is not `FULL`

Outputs:
- structured JSON result
- human-readable posture summary with Claude permission mode when available
- recommended install command from `scripts/setup-help.sh` when posture is not `FULL`
