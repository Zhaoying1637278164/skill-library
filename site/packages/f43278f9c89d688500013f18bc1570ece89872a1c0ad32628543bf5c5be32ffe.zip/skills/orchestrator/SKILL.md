---
name: mypowers-orchestrator
description: Use when coordinating the full mypowers forge flow across research, decision-making, scanning, attestation, and audit updates.
---

# mypowers:orchestrator

Claude Code note: This skill is designed to sit naturally inside Claude Code workflows and should honor project rules in `CLAUDE.md` and `AGENTS.md` before invoking the shared script layer.

Purpose:
- coordinate the focused mypowers A-Z forge across research, decision-making, scanning, attestation, and audit updates

Execution Contract:
- call `scripts/posture.sh` first to establish `FULL`, `PARTIAL`, or `BASIC`
- call `scripts/check-superpowers.sh` before any optional workflow delegation
- keep every phase truthful about the current posture and available tooling
- surface Claude Code permission mode when the native hook path provides it
- route bridge imports through `scripts/bridge-import.sh`
- route all scanning through `scripts/scan.sh`
- route all provenance through `scripts/attest.sh`
- when `scripts/check-superpowers.sh --env` reports `SUPERPOWERS_AVAILABLE=true`, delegate brainstorming and detailed plan writing to Superpowers `brainstorming` and `writing-plans`
- log whether Superpowers was used in the forge summary and audit update
- fall back to built-in mypowers orchestration when Superpowers is unavailable
- keep Security Oracle, posture reporting, bridge-import, and attestation under mypowers control even when Superpowers contributes workflow structure
- never describe enforcement that the current posture cannot support

Commands:
- `/mypowers:forge sample-project`
- `/mypowers:next`
- `/mypowers:status`

Phases:
1. Phase 0: run `bridge-import` when a Decision Artifact is present
2. Phase 1: run `fortress-lab` to produce a risk matrix
3. Phase 2: run `decision-weaver` to pick the implementation path
4. Phase 3: optionally use Superpowers `brainstorming` or `writing-plans` for complex scope and detailed implementation breakdown when available
5. Phase 4: run `dynamic-skill-forge` to create project-specific support assets and optional Superpowers-aligned TDD scaffolding
6. Phase 5: run `security-oracle` to validate the implementation path
7. Phase 6: run `supply-chain` to create attestation output
8. Phase 7: update the Fortress Bible and audit log

Optional Superpowers delegation:
- use Superpowers `brainstorming` only for feature shaping and option exploration after posture is established
- use Superpowers `writing-plans` only for implementation-plan structure after `decision-weaver` selects the path
- keep all security gates, posture checks, and final go or no-go decisions inside `mypowers`
- record `superpowers=used` or `superpowers=not-available` in the audit summary

Outputs:
- truthful posture summary
- next recommended action
- immutable-style audit update
