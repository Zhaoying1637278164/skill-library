---
name: mypowers-dynamic-skill-forge
description: Use when a project needs narrow, repeatable helper skills derived from the Fortress Bible and the current implementation context.
---

# mypowers:dynamic-skill-forge

Purpose:
- generate narrow project-specific helper skills from the current repo context

Execution Contract:
- read the Fortress Bible and project context before generating anything
- call `scripts/check-superpowers.sh` before optional delegation
- keep generated skills aligned with the shared script layer
- keep generated skills posture-aware and compatible with `FULL`, `PARTIAL`, or `BASIC` behavior
- when Superpowers is available, delegate helper-skill brainstorming, implementation-plan shape, and TDD scaffolding prompts to `brainstorming`, `writing-plans`, and `test-driven-development`
- log whether Superpowers contributed to the generated skill shape
- fall back gracefully to native mypowers helper-skill generation when Superpowers is unavailable
- keep Fortress Bible alignment, posture checks, and security wording under mypowers control even when Superpowers contributes structure
- evolve generated skills only after explicit user feedback

Responsibilities:
- read the Fortress Bible and current project context
- generate narrow project skills under `.mypowers/skills/`
- keep generated skills posture-aware by calling the shared script layer
- use `scripts/check-superpowers.sh` to decide whether to borrow Superpowers planning and test-first structure
- use Superpowers only for brainstorming, planning, and TDD discipline when available
- evolve generated skills only after explicit user feedback
