---
name: mypowers-decision-weaver
description: Use when comparing implementation options and choosing the simplest truthful path within the current tooling and posture constraints.
---

# mypowers:decision-weaver

Purpose:
- compare viable implementation paths and pick the simplest truthful option

Execution Contract:
- prefer options that fit the current posture and local tooling
- preserve truthful `FULL`, `PARTIAL`, or `BASIC` messaging when comparing options
- capture rationale and trade-offs clearly enough for later audit review
- avoid choosing paths that imply unsupported automation by default

Responsibilities:
- compare viable implementation paths
- prefer the simplest truthful path
- capture rationale and trade-offs for the Fortress Bible
- avoid choosing options that require unsupported local tooling by default
