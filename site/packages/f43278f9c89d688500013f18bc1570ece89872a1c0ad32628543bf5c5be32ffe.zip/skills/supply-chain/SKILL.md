---
name: mypowers-supply-chain
description: Use when producing change-level provenance, attestation artifacts, or truthful supply-chain status for mypowers outputs.
---

# mypowers:supply-chain

Purpose:
- produce truthful change-level attestation output for the current repo state

Execution Contract:
- call `scripts/posture.sh` first
- call `scripts/attest.sh` for file-level or change-level attestation
- include the current posture in every attestation result
- prefer real signing flows only when they are actually configured
- fall back to local Merkle-style manifests when they are not

Execution:
- prefer Cosign and Rekor when a real signing flow is configured
- fall back to local Merkle-style manifests when they are not

Truthfulness rules:
- never claim SLSA-grade provenance without Cosign and Rekor CLI
- never label local manifests as signed provenance
- include posture in every output
- point users to `/mypowers:setup-tools` when optional tooling is missing
