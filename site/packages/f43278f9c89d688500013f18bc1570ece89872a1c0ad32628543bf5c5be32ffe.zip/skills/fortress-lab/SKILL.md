---
name: mypowers-fortress-lab
description: Use when gathering project context, framing risks, and deciding which checks matter most before implementation begins.
---

# mypowers:fortress-lab

Purpose:
- gather context and frame the risks that matter before implementation starts

Execution Contract:
- anchor research to the current project scope and posture
- keep recommendations aligned with the current `FULL`, `PARTIAL`, or `BASIC` posture
- record assumptions clearly enough for Fortress Bible follow-up
- recommend only checks that the current repo and tooling can support honestly

Responsibilities:
- gather market, product, and threat context
- build a concise risk matrix
- record assumptions for the Fortress Bible
- recommend which security checks matter most for the current scope
