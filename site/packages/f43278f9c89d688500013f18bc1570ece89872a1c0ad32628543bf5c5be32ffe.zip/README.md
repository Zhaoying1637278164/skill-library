# mypowers

`mypowers – Zero-Trust AI Co-Founder OS` is a focused, shared-content plugin for Claude Code and OpenAI Codex that combines zero-trust orchestration, bridge-import verification, progressive security scanning, and Fortress Bible attestation into one portable workflow. It stays radically honest about what the local machine can actually enforce: `FULL` when the recommended stack is present, `PARTIAL` when some tools are missing, and `BASIC` when only built-in checks are available.

## Status

`Initial public release`

## Quick Start

### Claude Code

```bash
/plugin load --dir .
/mypowers:forge test-project
/mypowers:security-oracle
```

### Codex

```bash
codex plugin load --dir .
/mypowers:setup-hooks
/mypowers:forge test-project
/mypowers:security-oracle
```

## Installation

### Claude Code

1. Load the plugin from the repository root with `/plugin load --dir .`
2. Claude Code registers two native `PreToolUse` hooks directly from `.claude-plugin/plugin.json`: a fast edit-time secret scan (`Edit|Write|MultiEdit`) and a commit gate (`Bash`)
3. Run `/mypowers:forge test-project` or `/mypowers:security-oracle`
4. Use `/mypowers:setup-hooks` only if you want to inspect the native Claude registration or print the manual Codex snippet

### Codex

1. Load the plugin from the repository root with `codex plugin load --dir .`
2. Run `/mypowers:setup-hooks` to print the latest hook status and guidance for this checkout
3. Enable `[features] codex_hooks = true` in `~/.codex/config.toml` before expecting any Codex hooks to run
4. Keep `.codex/hooks.json` wired only if you want the currently supported Codex hook coverage
5. If you cannot edit Codex config from the app UI, start from the repo-managed samples in `templates/codex/config.toml` and `templates/codex/hooks.json`
6. Start with `/mypowers:forge test-project` or `/mypowers:security-oracle`

## Philosophy

`mypowers` is a focused zero-trust A-Z forge, not a general config pack. It stays narrow on purpose: shared skills, shared scripts, and a truthful progressive security model that says exactly how much local enforcement is available.

- `FULL`: the recommended security stack is present and the shared workflows can run at full strength
- `PARTIAL`: some optional tools are missing, so `mypowers` hard-blocks only what it can verify honestly and reports the missing tooling
- `BASIC`: no recommended SCA/security tools are available, so `mypowers` falls back to local checks and clear upgrade guidance

## What Ships In v1

- dual manifests in `.codex-plugin/` and `.claude-plugin/`
- shared skills, hooks, scripts, templates, agents, and commands
- posture-aware scanning and attestation scripts
- truthful `FULL`, `PARTIAL`, and `BASIC` reporting

## Superpowers Integration (Optional)

mypowers remains the primary zero-trust orchestrator. When `scripts/check-superpowers.sh` detects a standard-path Superpowers installation, `mypowers` can optionally delegate brainstorming, implementation planning, and TDD scaffolding to Superpowers while keeping security gates and posture reporting in-house.

- detection is path-based and truthful: `scripts/check-superpowers.sh` only checks standard skill locations such as `~/.claude/skills`, `~/.codex/skills`, and common plugin-managed skill directories like `$CODEX_HOME/superpowers/skills`
- arbitrary cloned repositories are ignored, so a local reference checkout does not count as an active Superpowers install
- when available, `mypowers` can borrow Superpowers `brainstorming`, `writing-plans`, and `test-driven-development` for structured workflow help
- when unavailable, `mypowers` falls back to its own built-in logic and remains fully functional
- Security Oracle, bridge-import verification, posture reporting, attestation, and final go or no-go decisions stay inside `mypowers`

## Hook Setup (One-Time per Tool)

### Claude Code

Claude Code is now a first-class native target for `mypowers`. When you load the plugin, Claude reads the hook registrations directly from `.claude-plugin/plugin.json`, so you do not need to edit `.claude/settings.json` just to enable the default zero-trust path.

Native Claude hook registrations:

- `PreToolUse` on `Edit|Write|MultiEdit` runs a fast secret-scan gate before edit tools are accepted
- `PreToolUse` on `Bash` runs the commit gate before commit-producing git commands, then performs posture-aware scan + batch attestation

Optional project-level overrides still belong in `.claude/settings.json` if you want to add your own extra hooks around the native `mypowers` ones.

### Codex

Codex Desktop uses Claude-style hook event names, but hooks are feature-gated. Enable them first in `~/.codex/config.toml`:

```toml
[features]
codex_hooks = true
```

Current Codex Desktop behavior confirmed on March 31, 2026 with `Codex Desktop/0.118.0-alpha.2`:

- `SessionStart` fires when the first turn starts
- `PreToolUse` fires for shell tool calls such as `Bash`
- direct desktop file writes land as `fileChange` items after the tool phase, so the Claude-style pre/post edit wrappers do not receive a file path for those writes yet

That means `mypowers` cannot truthfully promise hook-backed edit enforcement for direct Codex desktop file changes in this build. Keep `.codex/hooks.json` wired if you want future compatibility, but rely on `/mypowers:security-oracle`, `/mypowers:forge ...`, or the native Claude plugin flow when you need enforced edit-time gating today.

`mypowers` never auto-edits either configuration file. Use `/mypowers:setup-hooks` to print the latest status and guidance for the current tool and checkout.

Repository-managed Codex starter files are also provided for teams that want these settings tracked in Git:

- `templates/codex/config.toml`
- `templates/codex/hooks.json`

## Tooling Posture

- `FULL`: full recommended security stack detected
- `PARTIAL`: some recommended tools missing
- `BASIC`: no recommended SCA/security tools detected

Use `/mypowers:setup-tools` to print platform-specific install commands.

## Optimized for Claude Code

`mypowers` is designed to feel native in Claude Code: the plugin now registers the two-phase hook model directly through the plugin manifest (`Edit|Write|MultiEdit` fast gate plus `Bash` commit gate), reads Claude's `permission_mode` signal inside hook payloads, and still respects local `CLAUDE.md` and `AGENTS.md` guardrails before the shared script layer enforces posture or attestation.

Use `/mypowers:setup-hooks` to print the latest Claude Code snippet for your current checkout whenever the hook wrappers change.

## Native Integration

The Claude Code source reference clarified three native integration points that `mypowers` can use honestly today:

- Claude passes `permission_mode` into hook payloads, so Security Oracle can report Claude's real mode without guessing
- Claude supports native plugin hook registration, so `mypowers` can register the fast gate and commit gate directly instead of pretending they are just documentation
- plugin agents can use supported frontmatter such as descriptions, effort, and skill preload hints, but they cannot silently add privileged per-agent hooks or permission modes

This improves native behavior without changing the core contract. `mypowers` still reports `FULL`, `PARTIAL`, or `BASIC` strictly from local verification, still blocks only on zero-trust conditions it can actually prove, and still keeps Fortress Bible updates transparent instead of hidden behind private runtime state.

## Final Verification

Run the full local verification suite before publishing changes:

```bash
sh tests/run-all.sh
```

## License

`mypowers` is released under the MIT license. See `LICENSE`.

## Security

Security disclosure and response guidance lives in `SECURITY.md`.

## Contributing

Issues and pull requests are welcome. See `CONTRIBUTING.md` for the contribution checklist and release expectations.

## Built with Superpowers in Codex

This plugin was built with Superpowers in Codex using TDD, review checkpoints, and portable shared scripts.
