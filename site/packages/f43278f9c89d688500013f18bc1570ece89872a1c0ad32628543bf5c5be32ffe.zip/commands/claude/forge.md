---
description: Run the end-to-end mypowers forge workflow with truthful posture reporting and zero-trust phase sequencing.
---

# Forge

Use the `mypowers:orchestrator` skill to run the focused A-Z forge flow.

Execution requirements:
- establish posture first via `scripts/posture.sh`
- keep every phase truthful about `FULL`, `PARTIAL`, or `BASIC`
- route bridge imports through `scripts/bridge-import.sh`
- route scanning through `scripts/scan.sh`
- route provenance through `scripts/attest.sh`

If the user supplied a project name, treat it as the forge target and include it in the status summary.
