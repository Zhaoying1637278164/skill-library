---
description: Verify and import a Decision Artifact through the mypowers zero-trust bridge flow.
---

# Bridge Import

Use the `mypowers:bridge-import` skill.

Requirements:
- call posture first
- verify integrity before accepting any artifact
- reject malformed, tampered, or secret-bearing imports
- state the final posture and any required operator follow-up
