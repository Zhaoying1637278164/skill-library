---
description: Run the mypowers security-oracle flow and report posture-aware security findings.
---

# Security Oracle

Use the `mypowers:security-oracle` skill.

Requirements:
- start with `eval "$(sh scripts/posture.sh --env)"`
- run `scripts/scan.sh`
- block on high-signal local violations
- end with the posture message from `scripts/posture-reporting.sh`
