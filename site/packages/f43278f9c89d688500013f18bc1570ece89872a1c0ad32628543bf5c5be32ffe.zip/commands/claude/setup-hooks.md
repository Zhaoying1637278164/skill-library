---
description: Print one-time hook registration guidance for Claude Code or Codex using the current checkout paths.
---

# Setup Hooks

Print the current hook registration snippets for the detected tool.

Requirements:
- explain that Claude Code loads the native `PreToolUse`, `PostToolUse`, and `PreCompact` hooks directly from `.claude-plugin/plugin.json`
- prefer Codex hook examples when the user asks for manual registration details
- explain that Codex manual hooks require `[features] codex_hooks = true` in `~/.codex/config.toml`
- explain that current Codex desktop builds fire `PreToolUse` and `PostToolUse` for shell tool calls such as `Bash`, not the later `fileChange` apply step
- provide Codex hook examples when the user asks for Codex specifically
- mention the repo-managed Codex starter files at `templates/codex/config.toml` and `templates/codex/hooks.json` for users who cannot edit from Codex directly
- use repository-safe path resolution based on `git rev-parse --show-toplevel 2>/dev/null || pwd`
- do not edit user config automatically
