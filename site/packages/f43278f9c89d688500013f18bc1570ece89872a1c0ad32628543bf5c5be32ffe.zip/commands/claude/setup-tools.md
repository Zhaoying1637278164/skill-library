---
description: Print recommended install commands for the full mypowers security toolchain.
---

# Setup Tools

Use `scripts/setup-help.sh` to print platform-specific install guidance.

Always:
- describe the current posture
- list missing tools clearly
- keep the recommendation truthful and optional
