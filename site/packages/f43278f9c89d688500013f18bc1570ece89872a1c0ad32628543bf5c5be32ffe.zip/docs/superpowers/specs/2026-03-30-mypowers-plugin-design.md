# mypowers Plugin Design

Date: 2026-03-30
Status: Approved for planning

## Goal

Build `mypowers` as a shared-content plugin package for both Claude Code and OpenAI Codex. The plugin must be truthful about cross-tool compatibility, portable by default, and explicit about when security enforcement is full, partial, or basic.

## Scope

This design covers:

- repository structure
- cross-tool packaging strategy
- shared skill, hook, script, agent, template, command, and vault boundaries
- security posture contract
- runtime data flow
- hard-block and graceful-degradation behavior
- verification requirements for a first shippable v1

This design does not cover:

- marketplace publishing automation
- auto-modification of user config files
- enterprise-only strict mode beyond the v1 posture contract

## Product Positioning

`mypowers` is a zero-trust AI co-founder plugin that ships one shared operational package for Claude Code and Codex, with thin tool-specific manifests and setup instructions. The plugin delivers real value with no external security tools installed, then upgrades automatically when local tooling is available.

Core intelligence must work out of the box:

- Decision Weaver
- Fortress Memory Bridge
- Dynamic Skill Forge
- A-Z Orchestrator
- Project Fortress Bible updates
- basic ContextCov-style project rule generation

Security and supply-chain features are progressive rather than falsely mandatory.

## Cross-Tool Packaging Strategy

The repository will use a dual-manifest structure with one shared content surface:

- `.codex-plugin/plugin.json`
- `.claude-plugin/plugin.json`
- shared `skills/`
- shared `hooks/`
- shared `agents/`
- shared `templates/`
- shared `commands/`
- shared `vault/`
- shared `scripts/`

The manifests are adapters only. The plugin's real behavior lives in the shared content and shared scripts.

This is intentionally not a single-manifest design. The current tool ecosystems use different manifest locations and different hook registration models, so the v1 package must be truthful about those differences.

## Repository Layout

The repository will include the following top-level structure:

```text
mypowers/
├── .claude-plugin/
│   └── plugin.json
├── .codex-plugin/
│   └── plugin.json
├── skills/
├── hooks/
├── agents/
├── templates/
├── commands/
├── scripts/
├── vault/
│   └── .gitkeep
└── README.md
```

Additional documentation will live under `docs/superpowers/specs/`.

## Component Boundaries

### Skills

`skills/` contains the nine user-facing skills. Skills are high-level and policy-focused. They do not contain raw shell logic. They describe workflow, zero-trust gates, expected outputs, and when shared scripts must be invoked.

Every security-relevant skill uses the same posture vocabulary:

- `FULL`
- `PARTIAL`
- `BASIC`

Every security-relevant skill must be truthful about what was actually enforced on the local machine.

### Agents

`agents/` contains four shared role prompts:

- visionary agent
- analyst agent
- security auditor agent
- executor agent

These are content assets, not environment-specific executables.

### Templates

`templates/` contains:

- Fortress Bible template
- Decision Artifact template

These templates define the shape of imported decisions, Bible updates, and audit-facing outputs.

### Commands

`commands/` contains shortcut metadata and human-facing command definitions such as `forge`, `bridge-import`, `security-oracle`, `setup-tools`, and `setup-hooks`.

### Vault

`vault/` is runtime-owned storage. The repository only seeds `.gitkeep`. Runtime content is created during actual use and is not treated as source-controlled implementation content.

### Scripts

`scripts/` is the single source of truth for:

- environment detection
- tool detection
- posture calculation
- scan execution
- attestation execution
- setup-help output
- structured JSON result generation

All major skills and hook wrappers call into `scripts/`. No environment detection logic should be duplicated in skills, manifests, or hook documentation.

Scripts must be POSIX-compliant `sh`, not bash-only.

### Hooks

`hooks/` contains:

- `HOOK.md` files describing hook purpose and policy
- thin wrapper scripts that call into shared `scripts/`

Hook wrappers do not contain independent business logic. They delegate to shared script entrypoints.

## Primary Script Entry Points

The initial script set should include:

- `posture.sh`
- `scan.sh`
- `bridge-import.sh`
- `attest.sh`
- `setup-help.sh`

`posture.sh` must be the single source of truth for posture calculation. Every other script such as `scan.sh`, `bridge-import.sh`, and `attest.sh` must call `posture.sh` first and respect its output.

### posture.sh

`posture.sh` is called by every major skill and hook. It detects available tools with portable commands such as `command -v`, computes posture as `FULL`, `PARTIAL`, or `BASIC`, and emits structured output that downstream scripts and skills can reuse.

### scan.sh

Runs Security Oracle logic using the current posture. When external scanners are unavailable, it performs lightweight local checks and labels the result accordingly.

### bridge-import.sh

Verifies and processes imported Decision Artifact content, including integrity checks, zero-trust screening, and structured output for skill-level Bible and audit updates.

### attest.sh

Handles post-change attestation behavior. When optional supply-chain tooling is unavailable, it falls back to local Merkle-manifest style outputs and clearly states the reduced provenance guarantees.

### setup-help.sh

Prints platform-aware installation guidance for recommended tools. It never installs tools automatically and never mutates local config.

## Security And Tooling Contract

The plugin is portable by default and degrades gracefully. It never silently fails, never pretends a missing external tool ran, and never overstates the strength of enforcement.

### Always Available

The following capabilities are available without external security CLIs:

- Decision Weaver reasoning
- Fortress Memory Bridge workflow
- Dynamic Skill Forge logic
- A-Z Orchestrator workflow
- Fortress Bible updates
- basic project rule generation
- lightweight local pattern-based validation

### Progressive Security Oracle

When tools such as `trivy`, `grype`, `syft`, `semgrep`, `cosign`, or Rekor CLI are missing, Security Oracle falls back to local checks and labels results clearly.

Expected result language:

- `Security Posture: BASIC` when no SCA/security tools are available
- `Security Posture: PARTIAL` when some but not all recommended tools are available
- `Security Posture: FULL` when the full recommended stack for the relevant check is available

Example summary:

`Security Posture: PARTIAL (Trivy + Cosign missing) - Full enforcement requires: brew install trivy cosign`

### Supply-Chain Behavior

Cosign and Rekor-backed provenance is optional in v1. If these are missing, the plugin produces a local Merkle-style manifest and encrypted audit log fallback and explicitly states that full SLSA-style provenance is unavailable without the external tools.

## Runtime Data Flow

1. A user invokes a command or skill such as `forge`, `bridge-import`, or `security-oracle`.
2. The skill prepares inputs, applies zero-trust policy, and calls a portable script in `scripts/`.
3. The script detects available tools using portable shell commands.
4. The script computes and exports `POSTURE=FULL|PARTIAL|BASIC`.
5. The script performs the requested action or a graceful fallback path.
6. The script returns structured JSON output plus a human-readable summary.
7. The skill consumes that output and updates the Fortress Bible with a Merkle hash.
8. The skill records an immutable-style audit entry.
9. The skill displays a truthful final summary including posture and recommended next steps.

Hook flow follows the same script boundary:

1. A user manually configures a host-tool hook using documented setup instructions.
2. A thin wrapper script in `hooks/` calls a shared script entrypoint.
3. The pre-edit hook runs a lightweight Security Oracle path.
4. The post-change hook runs attestation and Bible update logic.

## Hard-Block Conditions

The plugin must exit non-zero and block progress on the following zero-trust failures:

- detectable hardcoded secrets, including high-entropy patterns and common secret formats
- obvious injection or command-execution payloads in bridge-import artifacts
- explicit violations of project rules stored in the Fortress Bible, including scope, architecture, and security-policy violations
- malformed or tampered bridge-import artifacts, including failed checksum or Merkle verification
- any attempt to bypass Security Oracle in critical paths

Any bridge-import that fails Merkle or integrity verification must trigger a hard-block with the message: `Bridge import rejected: integrity check failed. Possible tampering or corruption detected.`

Hard-block responses must include:

- non-zero exit code
- precise error message
- clear remediation guidance

## Graceful Degradation Conditions

The plugin must degrade gracefully for:

- missing external tools such as Trivy, Grype, Syft, Semgrep, Cosign, or Rekor CLI
- missing optional parsers or AST helpers
- unsupported host environments

Graceful degradation responses must include:

- zero exit code
- `POSTURE=PARTIAL` or `POSTURE=BASIC`
- structured JSON result
- clear recommendation string

## Hook Model

The plugin does not auto-edit any user or project configuration files.

Instead, it ships:

- shared hook documentation
- thin wrapper scripts
- exact setup snippets in `README.md` for both tools
- a `setup-hooks` command that prints the correct configuration for the detected tool

The hook-install story is therefore:

- truthful
- copy-pasteable
- non-destructive
- tool-specific only where necessary

## Verification Requirements

The v1 implementation will be considered ready for review when all of the following are true:

- both manifests exist and validate structurally for their respective tools
- all shared skills reference only shared assets and shared scripts
- all environment detection lives only in `scripts/`
- every major script is POSIX `sh`
- every hook wrapper delegates to `scripts/`
- README includes one-time hook setup for Claude Code and Codex
- README includes setup-help guidance for installing optional tooling
- no command or script auto-mutates `.claude/settings.json`, `.codex/hooks.json`, or equivalent host configuration
- all security-facing docs and skills use the same posture contract wording

## v1 Non-Goals

The initial release will not:

- auto-install or auto-configure security tools
- auto-edit hook or settings files
- claim identical manifest semantics across Claude Code and Codex
- require enterprise-only tooling for the base experience
- block on missing optional supply-chain tooling
- provide advanced project-specific scaffolding or private workflow helpers beyond the shared public plugin scope

## Risks And Mitigations

### Risk: Cross-tool drift

Mitigation: keep all meaningful behavior in shared skills, shared scripts, and shared templates. Restrict tool-specific logic to manifests and README setup instructions.

### Risk: Overpromising security guarantees

Mitigation: require every skill and script output to declare posture explicitly and state what did not run.

### Risk: Fragile hook installation

Mitigation: provide exact manual setup snippets and thin wrapper scripts, but do not mutate user config.

### Risk: Script portability issues

Mitigation: keep all scripts POSIX `sh`, avoid bash-only constructs, and centralize tool detection in `posture.sh`.

### Risk: Skills becoming too verbose or duplicating posture language

Mitigation: create a shared `posture-reporting.sh` helper called by scripts to generate consistent human-readable posture messages. Skills should consume that output instead of composing their own posture summaries.

## Recommended Next Step

Create a detailed implementation plan that builds the shared-content skeleton first, then fills in shared scripts, manifests, skills, hook wrappers, documentation, and verification in small reviewable stages.
