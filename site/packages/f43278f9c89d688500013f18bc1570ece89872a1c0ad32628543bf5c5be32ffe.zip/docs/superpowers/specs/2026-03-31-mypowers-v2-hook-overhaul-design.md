# mypowers v2 — Two-Phase Security Hook Overhaul

**Date:** 2026-03-31
**Status:** Approved
**Author:** Rohan Reddy + Claude

## Goal

Re-engineer the mypowers hook system from a noisy, per-edit three-hook architecture into a fast, two-phase design: a lightweight pre-edit secret scanner and a heavyweight commit-gate that runs the full security pipeline once at commit time. Fix all 15 known bugs. Keep the existing architecture (posture tiers, bridge-import, attestation, Merkle trees) intact but make them invisible during normal editing.

## Problem Statement

The current hook system fires on every Edit/Write/MultiEdit:
- **PreToolUse**: posture.sh (6x `command -v`) + scan.sh (line-by-line file read)
- **PostToolUse**: posture.sh again + attest.sh (hash, Merkle tree, vault manifest, fortress-bible append)
- **PreCompact**: fortress-bible sync

This creates ~14 subprocess spawns per edit, hundreds of vault manifest files per session, endless fortress-bible appends, and blocks new file creation. Users report the hooks as annoying and sluggish.

## Design

### Approach: Two-Phase Security

Split security into two tiers:
1. **Fast Gate** — pre-edit, secret detection only, <50ms, silent on success
2. **Commit Gate** — pre-commit, full posture + scan + attestation pipeline, runs once

### Hook 1: Fast Gate (PreToolUse on Edit|Write|MultiEdit)

A stripped-down pre-edit check that does ONE thing: regex scan for hardcoded secrets.

**Flow:**
```
stdin (JSON) →
  → stdin empty: allow silently ({})
  → stdin present, file_path unextractable: allow with parser_warning
  → file_path extracted, file does not exist: allow silently ({})
  → file_path extracted, file exists:
      validate path under project root → binary check → line cap → regex scan
        → CLEAN: allow silently ({})
        → SECRET FOUND: deny with reason
```

**Properties:**
- No posture.sh call
- No attestation
- No context message injection on success
- Minimal subprocess overhead: sources `lib.sh` (one `.` invocation); `resolve_real_path` and `is_binary_file` may invoke `realpath`, `readlink`, or `file` — these are single fast external calls, not the per-line scan overhead of the old design. Target latency remains <50ms on warm filesystem.
- Timeout: 5 seconds
- Binary files skipped (check via `file --mime-type` or first-bytes null check)
- Large files capped at 10,000 lines
- Symlinks resolved and validated against project root
- Path traversal (`..`) rejected after normalization

### Hook 2: Commit Gate (PreToolUse on Bash)

Fires when Claude runs a Bash command that will produce a commit. Coverage is tiered based on what information is available at PreToolUse time (before the command runs).

#### Coverage tiers

| Git flow | File discovery method | Coverage level |
|----------|-----------------------|----------------|
| `git commit` (staged only) | `git diff --cached --name-only --diff-filter=d` | **Full** |
| `git commit --amend` | Same as above — staged index is the source | **Full** |
| `git commit -a` | `git diff --name-only` (tracked modified, unstaged) + staged | **Full** |
| `git commit -- path/file` (pathspec) | Parse pathspec from command string + staged | **Full** |
| `git push` | `git diff @{u}..HEAD --name-only` — works when upstream is set and not stale. Fails silently (allow with coverage note) when upstream ref is missing, force-push rewrites history, or multiple refs are pushed. | **Best-effort** |
| `git merge` | `git diff HEAD...MERGE_HEAD --name-only` (best-effort, only when MERGE_HEAD exists) | **Best-effort** |
| `git cherry-pick` | `git show --name-only <ref>` parsed from command string | **Best-effort** |
| `git rebase` | **Explicitly out of scope** — rebase replays commits internally before any visible shell command; cannot scan meaningfully at PreToolUse time | **Excluded** |

Best-effort flows scan the files they can discover, attest what was scanned, and include a coverage note in the output. They never silently skip — they always report what they checked and what they could not.

**Flow:**
```
stdin (JSON) → extract command string → classify git flow →
  → NOT a commit-producing command: allow silently (exit 0)
  → git rebase: allow silently with coverage note in additionalContext
  → commit-producing command:
    1. posture_cached --refresh → establish FULL/PARTIAL/BASIC
    2. Discover files per coverage tier above
    3. Filter out binary files and deletions
    4. For each discovered file: scan.sh (secret scan)
    5. attest.sh --batch with discovered files + coverage tier label
    6. Update fortress-bible.md ONCE with batch entry
    7. Write ONE vault manifest keyed by pre-commit timestamp + 4-char random suffix
    → ALL PASS: allow with posture context + coverage tier
    → ANY FAIL: deny with specific file + reason
    → NO FILES DISCOVERED: allow silently with coverage note
```

**Properties:**
- Timeout: 30 seconds
- Uses `git -C "$project_root"` to force correct repo (ignores GIT_DIR override)
- Skips binary files via mime-type check
- Warns if >50 files discovered
- Not a git repo: allow silently
- Manifest key: `pre-commit-{ISO8601-timestamp}-{4-char-random}` (commit hash not available at PreToolUse time)

### Removed Hooks

- **PostToolUse on Edit|Write|MultiEdit** — deleted entirely
- **PreCompact** — deleted. Attestation only at commit time.
- **`hooks/post-change-attest/` directory** — removed (claude-hook.sh, claude-lifecycle.sh, run.sh, HOOK.md)

### Plugin Manifest

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write|MultiEdit",
        "hooks": [{
          "type": "command",
          "command": "sh \"${CLAUDE_PLUGIN_ROOT}/hooks/pre-edit-security/claude-hook.sh\"",
          "timeout": 5,
          "statusMessage": "mypowers secret scan"
        }]
      },
      {
        "matcher": "Bash",
        "hooks": [{
          "type": "command",
          "command": "sh \"${CLAUDE_PLUGIN_ROOT}/hooks/commit-gate/claude-hook.sh\"",
          "timeout": 30,
          "statusMessage": "mypowers commit gate"
        }]
      }
    ]
  }
}
```

## Shared Library: scripts/lib.sh

Single file sourced by all scripts. Eliminates 5x duplication of `json_escape` and provides shared utilities.

**Exports:**
- `json_escape "$string"` — safe JSON string escaping
- `json_unescape_basic "$string"` — reverse basic escapes
- `extract_json_string "$json" "$key"` — awk-based extraction that handles escaped quotes and tries nested paths in order: `tool_input.$key` → `$key` → top-level scan. On extraction failure (malformed JSON, key absent): returns empty string. Callers that need the value must handle empty separately.
- `sha256_file "$path"` — portable SHA256 (shasum/sha256sum/openssl fallback)
- `sha256_string "$string"` — portable SHA256 of string
- `posture_cached [--refresh]` — load posture from session cache or run posture.sh and cache
- `is_binary_file "$path"` — check if file is binary (file command or first-bytes null check)
- `resolve_real_path "$path"` — portable realpath (realpath/readlink -f/cd+pwd fallback)

**Extraction failure policy — two distinct cases:**

| Situation | Response | Rationale |
|-----------|----------|-----------|
| Payload is empty or stdin is absent | Allow silently (`{}`) | Legitimate: Claude may send no payload for certain tool invocations. Nothing to warn about. |
| Payload is present but key is absent or JSON is malformed | Allow with `parser_warning` in `hookSpecificOutput` | Extraction failure on a non-empty payload is unexpected and should be visible. Blocking all edits over a parser bug is worse than the risk of missing one scan. |

All callers in the fast gate and commit gate MUST implement this distinction. "Allow silently" and "allow with parser_warning" are not interchangeable.

**Posture Cache:**
- First call: runs `posture.sh --env`, writes to `${TMPDIR:-/tmp}/mypowers-posture-$(sha256_string "$project_root")`
- Subsequent calls: sources cached file
- `--refresh` forces fresh call (used by commit-gate)
- Corrupted/unreadable cache: falls back to fresh call

## Bug Fixes (All 15)

### Critical

| # | Bug | Fix |
|---|-----|-----|
| 1 | New file writes blocked (scan.sh exit 2) | Fast Gate allows immediately if file doesn't exist |
| 4 | Post-attest failure kills session (continue:false) | PostToolUse hook removed entirely |

### High

| # | Bug | Fix |
|---|-----|-----|
| 7 | No file locking on fortress-bible.md | Commit-gate writes once per commit via atomic mv from temp file |
| 9 | posture.sh JSON mode has no escaping | Use json_escape from lib.sh |
| 13 | sed-based JSON parsing fragile | Replace with awk-based extraction in lib.sh |
| 14 | No temp file cleanup in attest.sh | Add trap 'rm -f "$tmp_file"' EXIT INT TERM HUP |

### Medium

| # | Bug | Fix |
|---|-----|-----|
| 2 | Posture recalculated every hook (12 command -v per edit) | Posture cached per session via lib.sh |
| 3 | Vault pollution (hundreds of manifests per session) | One manifest per commit-gate invocation, keyed by `pre-commit-{timestamp}-{4-char-random}` (commit hash unavailable at PreToolUse time) |
| 5 | 20s timeout per hook (40s total per edit) | Fast Gate: 5s, Commit Gate: 30s |
| 8 | json_escape duplicated 5 times | Single definition in lib.sh |
| 11 | Context messages flood conversation | Fast Gate returns no context on allow |
| 12 | PreCompact attests fortress-bible circularly | PreCompact hook removed |

### Low

| # | Bug | Fix |
|---|-----|-----|
| 6 | Backtick false positives in bridge-import | Allow fenced code blocks and inline code; reject bare command substitution only |
| 10 | eval of posture.sh output (4 sites) | Replace with posture_cached sourcing in lib.sh (1 site) |
| 15 | Path traversal on absolute paths | Validate resolved path starts with project_root |

## New Secret Patterns

Added to scan.sh alongside existing patterns:

| Pattern | Regex |
|---------|-------|
| Slack tokens | `xox[bpas]-[A-Za-z0-9-]{10,}` |
| Stripe live keys | `[sr]k_live_[A-Za-z0-9]{20,}` |
| Private keys | `-----BEGIN (RSA\|EC\|OPENSSH )?PRIVATE KEY-----` |

## Script Changes Summary

| File | Action | Details |
|------|--------|---------|
| `scripts/lib.sh` | **CREATE** | Shared utilities (~80 lines) |
| `scripts/scan.sh` | MODIFY | Source lib.sh, remove duplicate json_escape, add new patterns, formalize exit codes |
| `scripts/attest.sh` | MODIFY | Source lib.sh, add --batch mode, atomic writes, trap cleanup |
| `scripts/posture.sh` | MODIFY | Use json_escape from lib.sh for JSON output mode |
| `scripts/bridge-import.sh` | MODIFY | Source lib.sh, smarter backtick detection |
| `hooks/pre-edit-security/claude-hook.sh` | REWRITE | Strip to ~30 lines, inline regex, no subprocesses |
| `hooks/commit-gate/claude-hook.sh` | **CREATE** | Full pipeline on git commit/push (~60 lines) |
| `hooks/commit-gate/HOOK.md` | **CREATE** | Documentation |
| `hooks/post-change-attest/` | **DELETE** | Entire directory removed |
| `.claude-plugin/plugin.json` | MODIFY | Two PreToolUse entries, no PostToolUse, no PreCompact |

## Edge Cases

### Fast Gate

| Case | Handling |
|------|----------|
| stdin empty / absent | Allow silently (`{}`) |
| stdin present, `file_path` unextractable (malformed JSON, key absent) | Allow with `parser_warning` in `hookSpecificOutput` |
| `file_path` extracted, file does not exist (new file) | Allow silently (`{}`) |
| File path with spaces/quotes/unicode | awk-based extraction handles correctly |
| Symlink outside project | Resolve with resolve_real_path, validate under project_root; reject if outside |
| Binary file | Allow silently — skip scan (is_binary_file check) |
| File >10,000 lines | Scan first 10,000 lines only |
| Path contains `..` | Reject after normalization |
| Path to /dev/null or /proc | Rejected by project_root validation |

### Commit Gate

| Case | Handling |
|------|----------|
| `git commit` (staged) | Full coverage via `git diff --cached` |
| `git commit --amend` | Full coverage — same staged index |
| `git commit -a` | Full coverage — adds `git diff --name-only` (tracked unstaged) to discovered files |
| `git commit -- path/file` (pathspec) | Full coverage — parses pathspec from command string |
| `git push` | `git diff @{u}..HEAD --name-only` — best-effort. Works when upstream is set and not stale. Falls back to allow with coverage note when upstream ref is missing, force-push, or multiple refs. |
| `git add && git commit` (pipeline) | Matched — checks anywhere in command string |
| `git merge` | Best-effort — discovers files via `git diff HEAD...MERGE_HEAD` when MERGE_HEAD exists; includes coverage tier label in output |
| `git cherry-pick` | Best-effort — parses ref from command, discovers files via `git show --name-only` |
| `git rebase` | Explicitly excluded — allow silently with coverage note in `additionalContext` |
| stdin present, `command` unextractable | Allow with `parser_warning` in `hookSpecificOutput` |
| stdin empty / absent | Allow silently (`{}`) |
| No files discovered after classification | Allow silently with coverage note in `additionalContext` (not a parser error — expected for some flows) |
| Discovered file was deleted | Excluded via --diff-filter=d |
| Discovered binary files | Filtered out via is_binary_file |
| 100+ files discovered | Sequential with early-exit on first failure, warn if >50 |
| Not a git repo | Allow silently |
| GIT_DIR override | Uses `git -C "$project_root"` to force correct repo |

### lib.sh / Cache

| Case | Handling |
|------|----------|
| TMPDIR not set | Fallback to /tmp |
| Multiple instances (different projects) | Cache keyed by sha256 of project_root |
| Stale cache | Acceptable for fast-gate; commit-gate always refreshes |
| Corrupted cache file | Fallback to fresh posture.sh call |

### attest.sh --batch

| Case | Handling |
|------|----------|
| Empty batch | Minimal manifest, timestamp-only fortress-bible entry |
| File in batch no longer exists | Skip with warning, don't fail batch |
| fortress-bible.md missing | Create from template (existing behavior) |
| Concurrent invocations | Atomic mv from temp file |
| Interrupted mid-write | trap cleanup removes temp files |

### bridge-import.sh

| Case | Handling |
|------|----------|
| Nested triple backticks | Allow (count backtick runs, allow 3+) |
| CRLF line endings | Normalize with tr -d '\r' before hashing |
| Inline code backticks | Allow (balanced pairs without spaces indicating commands) |

### Cross-platform

| Case | Handling |
|------|----------|
| realpath not available | Fallback: readlink -f, then cd+pwd |
| file command not available | Skip binary detection, scan everything |
| dash vs bash vs zsh | All scripts POSIX sh, tested on dash and bash |
| macOS grep (no -P) | Using grep -E everywhere (already POSIX) |

## Test Plan

### Updated Tests

| File | Changes |
|------|---------|
| test_scan.sh | Add Slack/Stripe/private key pattern tests. Remove post-change-attest hook wrapper tests. |
| test_attest.sh | Add --batch mode, atomic write, trap cleanup tests. |
| test_manifests.sh | Expect new plugin.json (no PostToolUse, no PreCompact, Bash matcher). |
| test_repo_layout.sh | Remove post-change-attest checks. Add commit-gate and lib.sh checks. |
| test_bridge_import.sh | Add triple-backtick pass, inline code pass, bare command-sub fail tests. |
| test_repo_smoke.sh | Update file lists for new/deleted files. |
| test_docs_and_agents.sh | Update README section checks. |

### New Tests

| File | Coverage |
|------|----------|
| test_lib.sh | json_escape edge cases, sha256 portability, extract_json_string with escaped quotes, posture_cached hit/miss/refresh. |
| test_commit_gate.sh | Non-git passthrough, `git commit` (staged) full coverage, `git commit -a` picks up tracked unstaged files, `git commit -- path` parses pathspec, `git push` triggers, `git merge` best-effort with coverage note, `git cherry-pick` best-effort, `git rebase` allow-with-note, staged secret = deny, clean files = allow + attestation, manifest keyed by timestamp not commit hash, fortress-bible single entry per invocation, parser_warning emitted when command unextractable. |
| test_fast_gate.sh | New files allowed, clean files silent, secret = deny, path traversal rejected, binary files skipped. |

### Verification

`sh tests/run-all.sh` — single entry point, auto-discovers test_*.sh files.

## Migration

### What users need to do

Nothing. The plugin manifest change is automatic on next plugin load. The fast-gate is backward compatible (same PreToolUse on Edit|Write|MultiEdit, just faster). The commit-gate is new (PreToolUse on Bash) and additive.

### What gets deleted

- `hooks/post-change-attest/` directory (4 files)
- Vault manifests from old per-edit attestation (users can clean `vault/*.json` manually)

### Codex compatibility

- `.codex-plugin/plugin.json` updated to reflect new hook structure
- `templates/codex/hooks.json` updated for commit-gate pattern
- Codex users on manual hook setup get updated guidance via `/mypowers:setup-hooks`
