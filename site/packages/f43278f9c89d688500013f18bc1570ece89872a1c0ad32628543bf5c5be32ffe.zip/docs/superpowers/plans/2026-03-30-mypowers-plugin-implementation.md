# mypowers Plugin Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the shared-content `mypowers` plugin for Codex and Claude Code with dual manifests, portable POSIX shell scripts, shared skills/hooks/templates/agents, and verification coverage that matches the approved v1 design.

**Architecture:** Keep all real behavior in shared `skills/`, `hooks/`, `agents/`, `templates/`, `commands/`, `scripts/`, and `vault/`. Use `.codex-plugin/plugin.json` and `.claude-plugin/plugin.json` as thin adapters only, keep hook setup manual and documented, and make `scripts/posture.sh` the single source of truth for posture calculation for every runtime path.

**Tech Stack:** POSIX `sh`, Markdown, JSON, Git, `python3` for local manifest validation, portable tool detection via `command -v`

**Shell Script Rule:** Every shell script created in this plan must begin with `#!/bin/sh` and `set -eu`.

---

## File Map

### Root And Verification

- Create: `.gitignore`
  Responsibility: ignore runtime vault artifacts, local reports, and platform noise without hiding source files.
- Create: `tests/run-all.sh`
  Responsibility: run every shell-based verification script in `tests/`.
- Create: `tests/test_repo_layout.sh`
  Responsibility: confirm the shared-content directory layout exists before deeper implementation begins.
- Create: `tests/test_repo_smoke.sh`
  Responsibility: final repo-wide smoke test that lints shell files, parses manifests, and runs all task-level tests.

### Tool Adapters

- Create: `.codex-plugin/plugin.json`
  Responsibility: Codex-facing manifest pointing to shared content and interface metadata.
- Create: `.claude-plugin/plugin.json`
  Responsibility: Claude-facing manifest mirroring the shared plugin identity without claiming automatic hook wiring.
- Create: `commands/mypowers.json`
  Responsibility: shared shortcut catalog for `forge`, `bridge-import`, `security-oracle`, `setup-tools`, and `setup-hooks`.
- Create: `tests/test_manifests.sh`
  Responsibility: parse and validate manifest structure and command metadata.

### Shared Scripts

- Create: `scripts/posture.sh`
  Responsibility: single source of truth for tool detection and `FULL` / `PARTIAL` / `BASIC` posture calculation.
- Create: `scripts/posture-reporting.sh`
  Responsibility: generate consistent human-readable posture messages from posture and missing-tool inputs.
- Create: `scripts/setup-help.sh`
  Responsibility: print OS-aware install commands for the recommended stack without installing anything.
- Create: `scripts/scan.sh`
  Responsibility: lightweight zero-trust scan with optional tool fan-out and graceful degradation.
- Create: `scripts/bridge-import.sh`
  Responsibility: verify artifact integrity, reject tampering, and return structured import results.
- Create: `scripts/attest.sh`
  Responsibility: create local attestation manifests and optionally elevate to Cosign/Rekor-backed provenance.

### Hooks

- Create: `hooks/pre-edit-security/HOOK.md`
  Responsibility: explain the lightweight pre-edit security path and manual setup expectations.
- Create: `hooks/pre-edit-security/run.sh`
  Responsibility: thin wrapper that delegates to `scripts/scan.sh`.
- Create: `hooks/post-change-attest/HOOK.md`
  Responsibility: explain post-change attestation behavior and manual setup expectations.
- Create: `hooks/post-change-attest/run.sh`
  Responsibility: thin wrapper that delegates to `scripts/attest.sh`.

### Templates And Agents

- Create: `templates/decision-artifact.md`
  Responsibility: standardize bridge-import input format.
- Create: `templates/fortress-bible.md`
  Responsibility: standardize shared decision and posture tracking.
- Create: `agents/visionary-agent.md`
  Responsibility: strategy and product-shaping persona.
- Create: `agents/analyst-agent.md`
  Responsibility: research, risk, and evidence persona.
- Create: `agents/security-auditor-agent.md`
  Responsibility: zero-trust and hardening persona.
- Create: `agents/executor-agent.md`
  Responsibility: implementation and verification persona.

### Skills

- Create: `skills/orchestrator/SKILL.md`
  Responsibility: define the end-to-end forge workflow.
- Create: `skills/fortress-lab/SKILL.md`
  Responsibility: define research, threat framing, and risk matrix output.
- Create: `skills/bridge-import/SKILL.md`
  Responsibility: define safe import policy and integrity requirements.
- Create: `skills/security-oracle/SKILL.md`
  Responsibility: define progressive security scanning behavior.
- Create: `skills/decision-weaver/SKILL.md`
  Responsibility: define multi-agent decision workflow.
- Create: `skills/dynamic-skill-forge/SKILL.md`
  Responsibility: define project-specific skill generation workflow.
- Create: `skills/supply-chain/SKILL.md`
  Responsibility: define provenance and attestation workflow.
- Create: `skills/compliance-reporter/SKILL.md`
  Responsibility: define audit export and compliance reporting workflow.

### Documentation

- Create: `README.md`
  Responsibility: installation, hook setup, command usage, posture contract, and public release guidance.
- Modify: `docs/superpowers/specs/2026-03-30-mypowers-plugin-design.md`
  Responsibility: none expected during implementation unless the user requests a design correction.

## Task 1: Scaffold The Shared Repository Layout

**Files:**
- Create: `.gitignore`
- Create: `vault/.gitkeep`
- Create: `tests/run-all.sh`
- Create: `tests/test_repo_layout.sh`

- [ ] **Step 1: Write the failing layout test**

```sh
#!/bin/sh
set -eu

require_path() {
  if [ ! -e "$1" ]; then
    echo "missing required path: $1" >&2
    exit 1
  fi
}

require_path ".codex-plugin"
require_path ".claude-plugin"
require_path "skills"
require_path "hooks"
require_path "agents"
require_path "templates"
require_path "commands"
require_path "scripts"
require_path "tests"
require_path "vault/.gitkeep"

echo "PASS: tests/test_repo_layout.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_repo_layout.sh`

Expected: FAIL with `missing required path: .codex-plugin`

- [ ] **Step 3: Create the minimal repo skeleton**

```gitignore
.DS_Store
vault/*
!vault/.gitkeep
*.attestation.json
*.scan-report.json
```

```sh
#!/bin/sh
set -eu

for test_file in tests/test_*.sh; do
  if [ "$(basename "$test_file")" = "test_repo_smoke.sh" ]; then
    continue
  fi
  sh "$test_file"
done

echo "PASS: tests/run-all.sh"
```

```sh
mkdir -p .codex-plugin .claude-plugin skills hooks agents templates commands scripts tests vault
touch vault/.gitkeep
chmod +x tests/run-all.sh
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_repo_layout.sh`

Expected: PASS with `PASS: tests/test_repo_layout.sh`

- [ ] **Step 5: Commit**

```bash
git add .gitignore tests/run-all.sh tests/test_repo_layout.sh vault/.gitkeep
git commit -m "chore: scaffold mypowers repository layout"
```

## Task 2: Add Dual Manifests And Command Metadata

**Files:**
- Create: `.codex-plugin/plugin.json`
- Create: `.claude-plugin/plugin.json`
- Create: `commands/mypowers.json`
- Create: `tests/test_manifests.sh`

- [ ] **Step 1: Write the failing manifest test**

```sh
#!/bin/sh
set -eu

python3 - <<'PY'
import json
from pathlib import Path

required_files = [
    Path(".codex-plugin/plugin.json"),
    Path(".claude-plugin/plugin.json"),
    Path("commands/mypowers.json"),
]

for path in required_files:
    if not path.exists():
        raise SystemExit(f"missing required file: {path}")

codex = json.loads(Path(".codex-plugin/plugin.json").read_text())
claude = json.loads(Path(".claude-plugin/plugin.json").read_text())
commands = json.loads(Path("commands/mypowers.json").read_text())

assert codex["name"] == "mypowers"
assert codex["skills"] == "./skills/"
assert claude["name"] == "mypowers"
assert "orchestrator" in claude["skills"]
assert commands["namespace"] == "mypowers"
assert any(item["name"] == "setup-hooks" for item in commands["commands"])
PY

echo "PASS: tests/test_manifests.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_manifests.sh`

Expected: FAIL with `missing required file: .codex-plugin/plugin.json`

- [ ] **Step 3: Implement the manifests and command catalog**

```json
{
  "name": "mypowers",
  "description": "Zero-trust AI co-founder plugin with shared skills, portable security scripts, and truthful posture reporting.",
  "author": {
    "name": "Rohan Reddy",
    "url": "https://github.com/rohanreddy"
  },
  "homepage": "https://github.com/rohanreddy/mypowers",
  "repository": "https://github.com/rohanreddy/mypowers",
  "license": "MIT",
  "keywords": [
    "security",
    "zero-trust",
    "plugin",
    "orchestrator",
    "portable"
  ],
  "skills": "./skills/",
  "interface": {
    "displayName": "mypowers",
    "shortDescription": "Shared zero-trust plugin for Codex and Claude Code",
    "longDescription": "Builds a shared-content plugin with portable scripts, progressive security posture, and manual hook setup guidance.",
    "developerName": "Rohan Reddy",
    "category": "Productivity",
    "capabilities": [
      "Write",
      "Interactive"
    ],
    "websiteURL": "https://github.com/rohanreddy/mypowers",
    "defaultPrompt": [
      "Run the mypowers forge workflow.",
      "Verify a bridge import artifact safely.",
      "Show me the current security posture."
    ],
    "brandColor": "#1F6F78"
  }
}
```

```json
{
  "schemaVersion": "1",
  "name": "mypowers",
  "displayName": "mypowers",
  "description": "Zero-trust AI co-founder plugin with shared skills, portable security scripts, and truthful posture reporting.",
  "author": "Rohan Reddy",
  "license": "MIT",
  "homepage": "https://github.com/rohanreddy/mypowers",
  "repository": "https://github.com/rohanreddy/mypowers",
  "skills": [
    "orchestrator",
    "fortress-lab",
    "bridge-import",
    "security-oracle",
    "decision-weaver",
    "dynamic-skill-forge",
    "supply-chain",
    "compliance-reporter"
  ],
  "hooks": [
    "pre-edit-security",
    "post-change-attest"
  ],
  "commands": [
    "mypowers"
  ],
  "compatibility": {
    "claude-code": "1.0+"
  }
}
```

```json
{
  "namespace": "mypowers",
  "commands": [
    {
      "name": "forge",
      "description": "Run the end-to-end mypowers orchestrator workflow."
    },
    {
      "name": "bridge-import",
      "description": "Verify and import a Decision Artifact through zero-trust checks."
    },
    {
      "name": "security-oracle",
      "description": "Run the shared posture and scan pipeline."
    },
    {
      "name": "setup-tools",
      "description": "Print recommended install commands for the full security stack."
    },
    {
      "name": "setup-hooks",
      "description": "Print one-time hook registration snippets for the current tool."
    }
  ]
}
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_manifests.sh`

Expected: PASS with `PASS: tests/test_manifests.sh`

- [ ] **Step 5: Commit**

```bash
git add .codex-plugin/plugin.json .claude-plugin/plugin.json commands/mypowers.json tests/test_manifests.sh
git commit -m "feat: add dual manifests and command catalog"
```

## Task 3: Implement Posture Detection And Setup Guidance

**Files:**
- Create: `scripts/posture.sh`
- Create: `scripts/posture-reporting.sh`
- Create: `scripts/setup-help.sh`
- Create: `tests/test_posture.sh`

- [ ] **Step 1: Write the failing posture test**

```sh
#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

EMPTY_BIN="$TMP_DIR/empty-bin"
FULL_BIN="$TMP_DIR/full-bin"
mkdir -p "$EMPTY_BIN" "$FULL_BIN"

for tool in trivy grype syft semgrep cosign rekor-cli; do
  cat >"$FULL_BIN/$tool" <<'EOF'
#!/bin/sh
exit 0
EOF
  chmod +x "$FULL_BIN/$tool"
done

BASIC_OUTPUT="$(PATH="$EMPTY_BIN" /bin/sh scripts/posture.sh)"
FULL_OUTPUT="$(PATH="$FULL_BIN" /bin/sh scripts/posture.sh)"

echo "$BASIC_OUTPUT" | grep '"posture":"BASIC"' >/dev/null
echo "$FULL_OUTPUT" | grep '"posture":"FULL"' >/dev/null
echo "$FULL_OUTPUT" | grep 'Security Posture: FULL' >/dev/null

ENV_OUTPUT="$(PATH="$FULL_BIN" /bin/sh scripts/posture.sh --env)"
echo "$ENV_OUTPUT" | grep '^POSTURE=FULL$' >/dev/null

SIMPLE_OUTPUT="$(PATH="$FULL_BIN" /bin/sh scripts/posture.sh --simple)"
echo "$SIMPLE_OUTPUT" | grep '^FULL$' >/dev/null

echo "PASS: tests/test_posture.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_posture.sh`

Expected: FAIL with `cannot open scripts/posture.sh`

- [ ] **Step 3: Implement posture and setup scripts**

```sh
#!/bin/sh
set -eu

POSTURE="${1:-}"
MISSING="${2:-}"

case "$POSTURE" in
  FULL)
    printf '%s\n' 'Security Posture: FULL (full recommended tool stack detected)'
    ;;
  PARTIAL)
    printf '%s\n' "Security Posture: PARTIAL (${MISSING}) - Full enforcement requires: ${MISSING}"
    ;;
  BASIC)
    printf '%s\n' "Security Posture: BASIC (${MISSING}) - Recommended next step: install the recommended security stack"
    ;;
  *)
    printf '%s\n' "Security Posture: UNKNOWN (${MISSING})"
    ;;
esac
```

```sh
#!/bin/sh
set -eu

MODE="json"
if [ "${1:-}" = "--env" ]; then
  MODE="env"
fi
if [ "${1:-}" = "--simple" ]; then
  MODE="simple"
fi

script_dir="${0%/*}"
if [ "$script_dir" = "$0" ]; then
  script_dir="."
fi

required_tools="trivy grype syft semgrep cosign rekor-cli"
detected=""
missing=""
detected_count=0
required_count=0

append_csv() {
  current="$1"
  next="$2"
  if [ -z "$current" ]; then
    printf '%s' "$next"
  else
    printf '%s,%s' "$current" "$next"
  fi
}

for tool in $required_tools; do
  required_count=$((required_count + 1))
  if command -v "$tool" >/dev/null 2>&1; then
    detected="$(append_csv "$detected" "$tool")"
    detected_count=$((detected_count + 1))
  else
    missing="$(append_csv "$missing" "$tool")"
  fi
done

if [ "$detected_count" -eq 0 ]; then
  posture="BASIC"
elif [ "$detected_count" -eq "$required_count" ]; then
  posture="FULL"
else
  posture="PARTIAL"
fi

MESSAGE="$(/bin/sh "$script_dir/posture-reporting.sh" "$posture" "${missing:-no missing tools}")"

if [ "$MODE" = "simple" ]; then
  printf '%s\n' "$posture"
  exit 0
fi

if [ "$MODE" = "env" ]; then
  printf 'POSTURE=%s\n' "$posture"
  printf 'DETECTED_TOOLS=%s\n' "$detected"
  printf 'MISSING_TOOLS=%s\n' "$missing"
  printf 'POSTURE_MESSAGE=%s\n' "$MESSAGE"
  exit 0
fi

printf '{"posture":"%s","detected_tools":"%s","missing_tools":"%s","message":"%s"}\n' \
  "$posture" "$detected" "$missing" "$MESSAGE"
```

```sh
#!/bin/sh
set -eu

os_name="$(uname -s 2>/dev/null || printf 'Unknown')"

case "$os_name" in
  Darwin)
    printf '%s\n' 'brew install trivy grype syft semgrep cosign'
    printf '%s\n' 'brew install rekor'
    ;;
  Linux)
    printf '%s\n' 'Install Trivy, Grype, Syft, Semgrep, Cosign, and Rekor using your package manager or vendor instructions.'
    printf '%s\n' 'Examples: apt-get install trivy semgrep || use the official installer scripts when packages are unavailable.'
    ;;
  *)
    printf '%s\n' 'Install Trivy, Grype, Syft, Semgrep, Cosign, and Rekor CLI manually for full posture support.'
    ;;
esac
```

```sh
chmod +x scripts/posture.sh scripts/posture-reporting.sh scripts/setup-help.sh
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_posture.sh`

Expected: PASS with `PASS: tests/test_posture.sh`

- [ ] **Step 5: Commit**

```bash
git add scripts/posture.sh scripts/posture-reporting.sh scripts/setup-help.sh tests/test_posture.sh
git commit -m "feat: add posture detection and setup guidance"
```

## Task 4: Implement Security Scan And Pre-Edit Hook

**Files:**
- Create: `scripts/scan.sh`
- Create: `hooks/pre-edit-security/HOOK.md`
- Create: `hooks/pre-edit-security/run.sh`
- Create: `tests/test_scan.sh`

- [ ] **Step 1: Write the failing scan test**

```sh
#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

CLEAN_FILE="$TMP_DIR/clean.env"
SECRET_FILE="$TMP_DIR/secret.env"

cat >"$CLEAN_FILE" <<'EOF'
APP_MODE=development
EOF

cat >"$SECRET_FILE" <<'EOF'
OPENAI_API_KEY=sk-test-123456789012345678901234567890
EOF

sh scripts/scan.sh "$CLEAN_FILE" >"$TMP_DIR/clean.out"
grep '"status":"ok"' "$TMP_DIR/clean.out" >/dev/null

if sh scripts/scan.sh "$SECRET_FILE" >"$TMP_DIR/secret.out" 2>"$TMP_DIR/secret.err"; then
  echo "expected secret scan to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/secret.err" >/dev/null

echo "PASS: tests/test_scan.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_scan.sh`

Expected: FAIL with `cannot open scripts/scan.sh`

- [ ] **Step 3: Implement scan and pre-edit hook**

```sh
#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
  echo "usage: sh scripts/scan.sh /absolute/path/to/file" >&2
  exit 2
fi

TARGET="$1"
if [ ! -f "$TARGET" ]; then
  echo "scan target not found: $TARGET" >&2
  exit 2
fi

eval "$(sh "$(dirname "$0")/posture.sh" --env)"

if grep -E 'OPENAI_API_KEY=sk-|AKIA[0-9A-Z]{16}|SECRET_KEY=' "$TARGET" >/dev/null 2>&1; then
  echo "hardcoded secret detected in $TARGET" >&2
  exit 1
fi

if grep -E 'mypowers:[[:space:]]*skip-security-oracle' "$TARGET" >/dev/null 2>&1; then
  echo "security oracle bypass marker detected in $TARGET" >&2
  exit 1
fi

printf '{"status":"ok","posture":"%s","target":"%s","message":"%s"}\n' \
  "$POSTURE" "$TARGET" "$(printf '%s' "$POSTURE_MESSAGE" | tr '"' "'")"
```

```markdown
# Pre-edit Security Hook

Purpose: run a lightweight Security Oracle check before a file change is accepted by the host tool.

Behavior:
- calls the shared `scripts/scan.sh` entrypoint
- relies on `scripts/posture.sh` for posture calculation
- blocks only on zero-trust failures that can be detected locally
- never claims full scanner coverage unless the tools are actually installed

Setup:
- users register this wrapper manually in their Claude Code or Codex hook configuration
- the plugin never edits host config automatically
```

```sh
#!/bin/sh
set -eu

exec sh "$(dirname "$0")/../../scripts/scan.sh" "$@"
```

```sh
chmod +x scripts/scan.sh hooks/pre-edit-security/run.sh
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_scan.sh`

Expected: PASS with `PASS: tests/test_scan.sh`

- [ ] **Step 5: Commit**

```bash
git add scripts/scan.sh hooks/pre-edit-security/HOOK.md hooks/pre-edit-security/run.sh tests/test_scan.sh
git commit -m "feat: add scan pipeline and pre-edit hook"
```

## Task 5: Implement Bridge Import And Shared Templates

**Files:**
- Create: `scripts/bridge-import.sh`
- Create: `templates/decision-artifact.md`
- Create: `templates/fortress-bible.md`
- Create: `tests/test_bridge_import.sh`

- [ ] **Step 1: Write the failing bridge-import test**

```sh
#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

ARTIFACT="$TMP_DIR/artifact.md"
TAMPERED="$TMP_DIR/tampered.md"

cat >"$ARTIFACT" <<'EOF'
Decision: Use dual manifests.
Chosen Option: Shared content with thin adapters.
Rationale: Truthful compatibility.
Security Implications: Manual hook registration is required.
Scope: v1 plugin packaging.
Metadata (JSON): {"topic":"manifests"}
EOF

ARTIFACT_HASH="$(
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$ARTIFACT" | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$ARTIFACT" | awk '{print $1}'
  else
    openssl dgst -sha256 "$ARTIFACT" | awk '{print $NF}'
  fi
)"

printf 'Checksum: sha256:%s\n' "$ARTIFACT_HASH" >>"$ARTIFACT"

cp "$ARTIFACT" "$TAMPERED"
printf '%s\n' 'Scope: v1 plugin packaging plus auto-write hooks.' >>"$TAMPERED"

SECRET_ARTIFACT="$TMP_DIR/secret-artifact.md"
cp "$ARTIFACT" "$SECRET_ARTIFACT"
printf '%s\n' 'OPENAI_API_KEY=sk-test-123456789012345678901234567890' >>"$SECRET_ARTIFACT"

sh scripts/bridge-import.sh "$ARTIFACT" >"$TMP_DIR/pass.out"
grep '"status":"accepted"' "$TMP_DIR/pass.out" >/dev/null

if sh scripts/bridge-import.sh "$TAMPERED" >"$TMP_DIR/fail.out" 2>"$TMP_DIR/fail.err"; then
  echo "expected tampered artifact to fail" >&2
  exit 1
fi

grep 'Bridge import rejected: integrity check failed. Possible tampering or corruption detected.' "$TMP_DIR/fail.err" >/dev/null

if sh scripts/bridge-import.sh "$SECRET_ARTIFACT" >"$TMP_DIR/secret.out" 2>"$TMP_DIR/secret.err"; then
  echo "expected secret-bearing artifact to fail" >&2
  exit 1
fi

grep 'hardcoded secret detected' "$TMP_DIR/secret.err" >/dev/null

echo "PASS: tests/test_bridge_import.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_bridge_import.sh`

Expected: FAIL with `cannot open scripts/bridge-import.sh`

- [ ] **Step 3: Implement bridge import and templates**

```sh
#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
  echo "usage: sh scripts/bridge-import.sh /absolute/path/to/decision-artifact.md" >&2
  exit 2
fi

artifact="$1"
if [ ! -f "$artifact" ]; then
  echo "artifact not found: $artifact" >&2
  exit 2
fi

eval "$(sh "$(dirname "$0")/posture.sh" --env)"

checksum_line="$(grep '^Checksum: sha256:' "$artifact" || true)"
if [ -z "$checksum_line" ]; then
  echo "Bridge import rejected: integrity check failed. Possible tampering or corruption detected." >&2
  exit 1
fi

expected_hash="$(printf '%s' "$checksum_line" | sed 's/^Checksum: sha256://')"
actual_hash="$(
  grep -v '^Checksum: sha256:' "$artifact" | {
    if command -v shasum >/dev/null 2>&1; then
      shasum -a 256 | awk '{print $1}'
    elif command -v sha256sum >/dev/null 2>&1; then
      sha256sum | awk '{print $1}'
    else
      openssl dgst -sha256 | awk '{print $NF}'
    fi
  }
)"

if [ "$expected_hash" != "$actual_hash" ]; then
  echo "Bridge import rejected: integrity check failed. Possible tampering or corruption detected." >&2
  exit 1
fi

if grep -E 'curl[[:space:]]+\|[[:space:]]*sh|rm -rf|`.+`|\$\(.+\)' "$artifact" >/dev/null 2>&1; then
  echo "bridge import rejected: injection pattern detected" >&2
  exit 1
fi

if /bin/sh "$(dirname "$0")/scan.sh" "$artifact" >/dev/null 2>"$artifact.scan.err"; then
  :
else
  cat "$artifact.scan.err" >&2
  rm -f "$artifact.scan.err"
  exit 1
fi
rm -f "$artifact.scan.err"

printf '{"status":"accepted","posture":"%s","artifact":"%s","message":"%s"}\n' \
  "$POSTURE" "$artifact" "$(printf '%s' "$POSTURE_MESSAGE" | tr '"' "'")"
```

```markdown
**Decision Artifact for mypowers:bridge-import**

Decision: [clear decision summary]
Chosen Option: [single selected option]
Rationale: [why this option was chosen]
Security Implications: [risk and mitigation summary]
Scope: [what is in and out of scope]
Metadata (JSON): {"topic":"example","owner":"mypowers"}
Checksum: sha256:[computed from the artifact body without this line]
```

```markdown
# Project Fortress Bible

Last verified: [timestamp]
Merkle Root: [hash]
Security Posture: [FULL|PARTIAL|BASIC]
Decisions from Chat:
- [decision one]

Security Score:
- Status: [GO|NO-GO]
- Notes: [risk summary]

Recent Audit Entries:
- [timestamp] [event summary]
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_bridge_import.sh`

Expected: PASS with `PASS: tests/test_bridge_import.sh`

- [ ] **Step 5: Commit**

```bash
git add scripts/bridge-import.sh templates/decision-artifact.md templates/fortress-bible.md tests/test_bridge_import.sh
git commit -m "feat: add bridge import verification and templates"
```

## Task 6: Implement Attestation And Post-Change Hook

**Files:**
- Create: `scripts/attest.sh`
- Create: `hooks/post-change-attest/HOOK.md`
- Create: `hooks/post-change-attest/run.sh`
- Create: `tests/test_attest.sh`

- [ ] **Step 1: Write the failing attestation test**

```sh
#!/bin/sh
set -eu

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

TARGET="$TMP_DIR/sample.txt"
OUT_DIR="$TMP_DIR/out"
mkdir -p "$OUT_DIR"
printf '%s\n' 'hello mypowers' >"$TARGET"

sh scripts/attest.sh "$TARGET" "$OUT_DIR" >"$TMP_DIR/attest.out"

MANIFEST_FILE="$(find "$OUT_DIR" -type f -name '*.json' | head -n 1)"
[ -n "$MANIFEST_FILE" ]
grep '"provenance":"local-merkle"' "$MANIFEST_FILE" >/dev/null
grep '"status":"attested"' "$TMP_DIR/attest.out" >/dev/null

echo "PASS: tests/test_attest.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_attest.sh`

Expected: FAIL with `cannot open scripts/attest.sh`

- [ ] **Step 3: Implement attestation and post-change hook**

```sh
#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
  echo "usage: sh scripts/attest.sh /absolute/path/to/file vault" >&2
  exit 2
fi

target="$1"
output_dir="$2"

if [ ! -f "$target" ]; then
  echo "attestation target not found: $target" >&2
  exit 2
fi

mkdir -p "$output_dir"
eval "$(sh "$(dirname "$0")/posture.sh" --env)"

file_hash="$(
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$target" | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$target" | awk '{print $1}'
  else
    openssl dgst -sha256 "$target" | awk '{print $NF}'
  fi
)"

if command -v cosign >/dev/null 2>&1 && command -v rekor-cli >/dev/null 2>&1; then
  provenance="cosign-rekor"
else
  provenance="local-merkle"
fi

manifest="$output_dir/${file_hash}.json"
printf '{"status":"attested","posture":"%s","target":"%s","sha256":"%s","provenance":"%s","message":"%s"}\n' \
  "$POSTURE" "$target" "$file_hash" "$provenance" "$(printf '%s' "$POSTURE_MESSAGE" | tr '"' "'")" >"$manifest"

printf '{"status":"attested","manifest":"%s","provenance":"%s"}\n' "$manifest" "$provenance"
```

```markdown
# Post-change Attest Hook

Purpose: run shared attestation after a file change has been accepted by the host tool.

Behavior:
- delegates to `scripts/attest.sh`
- uses the same posture calculation path as every other runtime action
- writes local attestation manifests when Cosign or Rekor CLI are unavailable
- never claims full provenance unless both optional tools are present

Setup:
- register manually in the host tool's hook configuration
- use the README snippets instead of editing config heuristically
```

```sh
#!/bin/sh
set -eu

exec sh "$(dirname "$0")/../../scripts/attest.sh" "$@"
```

```sh
chmod +x scripts/attest.sh hooks/post-change-attest/run.sh
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_attest.sh`

Expected: PASS with `PASS: tests/test_attest.sh`

- [ ] **Step 5: Commit**

```bash
git add scripts/attest.sh hooks/post-change-attest/HOOK.md hooks/post-change-attest/run.sh tests/test_attest.sh
git commit -m "feat: add attestation workflow and post-change hook"
```

## Task 7: Write Core Security And Orchestration Skills

**Files:**
- Create: `skills/orchestrator/SKILL.md`
- Create: `skills/bridge-import/SKILL.md`
- Create: `skills/security-oracle/SKILL.md`
- Create: `skills/supply-chain/SKILL.md`
- Create: `tests/test_skill_contract_part1.sh`

- [ ] **Step 1: Write the failing skill-contract test**

```sh
#!/bin/sh
set -eu

require_contains() {
  file="$1"
  text="$2"
  grep -F "$text" "$file" >/dev/null || {
    echo "missing '$text' in $file" >&2
    exit 1
  }
}

for file in \
  skills/orchestrator/SKILL.md \
  skills/bridge-import/SKILL.md \
  skills/security-oracle/SKILL.md \
  skills/supply-chain/SKILL.md
do
  [ -f "$file" ] || {
    echo "missing skill file: $file" >&2
    exit 1
  }
done

require_contains skills/orchestrator/SKILL.md "/mypowers:forge"
require_contains skills/orchestrator/SKILL.md "scripts/posture.sh"
require_contains skills/bridge-import/SKILL.md "Bridge import rejected: integrity check failed. Possible tampering or corruption detected."
require_contains skills/security-oracle/SKILL.md "FULL / PARTIAL / BASIC"
require_contains skills/security-oracle/SKILL.md "scripts/scan.sh"
require_contains skills/security-oracle/SKILL.md 'eval "$(sh scripts/posture.sh --env)"'
require_contains skills/security-oracle/SKILL.md "posture-reporting.sh"
require_contains skills/supply-chain/SKILL.md "scripts/attest.sh"

echo "PASS: tests/test_skill_contract_part1.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_skill_contract_part1.sh`

Expected: FAIL with `missing skill file: skills/orchestrator/SKILL.md`

- [ ] **Step 3: Write the core skill docs**

```markdown
# mypowers:orchestrator

Military-grade A-Z forge pipeline for the shared `mypowers` plugin.

Commands:
- `/mypowers:forge sample-project`
- `/mypowers:next`
- `/mypowers:status`

Execution contract:
- call `scripts/posture.sh` first to establish `FULL`, `PARTIAL`, or `BASIC`
- route all scanning through `scripts/scan.sh`
- route all provenance through `scripts/attest.sh`
- never describe enforcement that the current posture cannot support

Phases:
1. Phase 0: run `bridge-import` when a Decision Artifact is present
2. Phase 1: run `fortress-lab` to produce a risk matrix
3. Phase 2: run `decision-weaver` to pick the implementation path
4. Phase 3: run `dynamic-skill-forge` to create project-specific support assets
5. Phase 4: run `security-oracle` to validate the implementation path
6. Phase 5: run `supply-chain` to create attestation output
7. Phase 6: update the Fortress Bible and audit log

Outputs:
- truthful posture summary
- next recommended action
- immutable-style audit update
```

```markdown
# mypowers:bridge-import

Zero-trust Chat -> Code memory bridge.

Policy:
- never trust raw pasted artifacts
- call `scripts/posture.sh` first
- call `scripts/bridge-import.sh` for every artifact
- reject malformed, tampered, or scope-expanding imports

Hard-block message:
`Bridge import rejected: integrity check failed. Possible tampering or corruption detected.`

Required checks:
- checksum or Merkle integrity verification
- injection-pattern detection
- scope-policy alignment against the Fortress Bible

Outputs:
- accepted or rejected decision
- structured import result
- posture-aware recommendations
```

```markdown
# mypowers:security-oracle

Progressive zero-trust scanner for `mypowers`.

Posture contract:
- `FULL / PARTIAL / BASIC`
- every run starts with `scripts/posture.sh`
- every invocation starts with `eval "$(sh scripts/posture.sh --env)"`
- every scan path calls `scripts/scan.sh`
- every invocation ends with the posture message from `scripts/posture-reporting.sh`

Enforcement:
- hard-block on secrets, bridge-import tampering, and Security Oracle bypass attempts
- degrade gracefully when Trivy, Grype, Syft, Semgrep, Cosign, or Rekor CLI are missing
- report exactly which tools were unavailable

Outputs:
- structured JSON result
- human-readable posture summary
- recommended install command from `scripts/setup-help.sh` when posture is not `FULL`
```

```markdown
# mypowers:supply-chain

Supply-chain attestation workflow for `mypowers`.

Execution:
- call `scripts/posture.sh` first
- call `scripts/attest.sh` for file-level or change-level attestation
- prefer Cosign and Rekor when available
- fall back to local Merkle-style manifests when they are not

Truthfulness rules:
- never claim SLSA-grade provenance without Cosign and Rekor CLI
- include posture in every output
- point users to `/mypowers:setup-tools` when optional tooling is missing
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_skill_contract_part1.sh`

Expected: PASS with `PASS: tests/test_skill_contract_part1.sh`

- [ ] **Step 5: Commit**

```bash
git add skills/orchestrator/SKILL.md skills/bridge-import/SKILL.md skills/security-oracle/SKILL.md skills/supply-chain/SKILL.md tests/test_skill_contract_part1.sh
git commit -m "feat: add core security and orchestration skills"
```

## Task 8: Write Remaining Skills, Agents, And README

**Files:**
- Create: `skills/fortress-lab/SKILL.md`
- Create: `skills/decision-weaver/SKILL.md`
- Create: `skills/dynamic-skill-forge/SKILL.md`
- Create: `skills/compliance-reporter/SKILL.md`
- Create: `agents/visionary-agent.md`
- Create: `agents/analyst-agent.md`
- Create: `agents/security-auditor-agent.md`
- Create: `agents/executor-agent.md`
- Create: `README.md`
- Create: `tests/test_docs_and_agents.sh`

- [ ] **Step 1: Write the failing docs-and-agents test**

```sh
#!/bin/sh
set -eu

require_contains() {
  file="$1"
  text="$2"
  grep -F "$text" "$file" >/dev/null || {
    echo "missing '$text' in $file" >&2
    exit 1
  }
}

for file in \
  skills/fortress-lab/SKILL.md \
  skills/decision-weaver/SKILL.md \
  skills/dynamic-skill-forge/SKILL.md \
  skills/compliance-reporter/SKILL.md \
  agents/visionary-agent.md \
  agents/analyst-agent.md \
  agents/security-auditor-agent.md \
  agents/executor-agent.md \
  README.md
do
  [ -f "$file" ] || {
    echo "missing documentation file: $file" >&2
    exit 1
  }
done

require_contains README.md "Hook Setup (One-Time per Tool)"
require_contains README.md ".claude/settings.json"
require_contains README.md ".codex/hooks.json"
require_contains README.md "/mypowers:setup-tools"
require_contains agents/security-auditor-agent.md "Role: Security Auditor"

echo "PASS: tests/test_docs_and_agents.sh"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `sh tests/test_docs_and_agents.sh`

Expected: FAIL with `missing documentation file: skills/fortress-lab/SKILL.md`

- [ ] **Step 3: Write the remaining skills, agents, and README**

```markdown
# mypowers:fortress-lab

Research and risk-framing skill for `mypowers`.

Responsibilities:
- gather market, product, and threat context
- build a concise risk matrix
- record assumptions for the Fortress Bible
- recommend which security checks matter most for the current scope
```

```markdown
# mypowers:decision-weaver

Decision synthesis skill for `mypowers`.

Responsibilities:
- compare viable implementation paths
- prefer the simplest truthful path
- capture rationale and trade-offs for the Fortress Bible
- avoid choosing options that require unsupported local tooling by default
```

```markdown
# mypowers:dynamic-skill-forge

Project-specific skill generation workflow.

Responsibilities:
- read the Fortress Bible and current project context
- generate narrow project skills under `.mypowers/skills/`
- keep generated skills posture-aware by calling the shared script layer
- evolve generated skills only after explicit user feedback
```

Organization-specific builder skills are intentionally out of scope for the public release and should not be scaffolded into the shared plugin.

```markdown
# mypowers:compliance-reporter

Audit and export skill for `mypowers`.

Responsibilities:
- summarize posture, decisions, and attestation outputs
- produce evidence-friendly markdown artifacts
- map outputs to common controls such as SOC 2 and FedRAMP at a documentation level
- state clearly when evidence is partial because optional tooling is missing
```

```markdown
Role: Visionary

Mission:
- shape ambitious but truthful product direction
- identify leverage, differentiation, and user-facing clarity
- avoid promising unsupported automation
```

```markdown
Role: Analyst

Mission:
- gather evidence
- compare options
- document constraints, assumptions, and risk
```

```markdown
Role: Security Auditor

Mission:
- enforce zero-trust reasoning
- challenge unsupported security claims
- prioritize hard-block issues and honest degradation messaging
```

```markdown
Role: Executor

Mission:
- implement the approved path
- keep changes small and testable
- verify behavior before reporting success
```

```markdown
# mypowers

`mypowers` is a shared-content zero-trust plugin for OpenAI Codex and Claude Code.

## What Ships In v1

- dual manifests in `.codex-plugin/` and `.claude-plugin/`
- shared skills, hooks, scripts, templates, agents, and commands
- posture-aware scanning and attestation scripts
- truthful `FULL`, `PARTIAL`, and `BASIC` reporting

## Install

### Codex

Load the local plugin from the repo root:

```bash
codex plugin load --dir .
```

### Claude Code

Install or register the plugin using your local Claude Code plugin workflow, then point it at this repository.

## Hook Setup (One-Time per Tool)

### Claude Code

Add a hook entry to `.claude/settings.json` that points to the shared wrapper:

```json
{
  "hooks": {
    "preEdit": [
      {
        "command": "sh hooks/pre-edit-security/run.sh /absolute/path/to/file-being-edited"
      }
    ],
    "postEdit": [
      {
        "command": "sh hooks/post-change-attest/run.sh /absolute/path/to/file-being-edited vault"
      }
    ]
  }
}
```

### Codex

Add matching entries to `.codex/hooks.json`:

```json
{
  "hooks": {
    "pre_edit": [
      {
        "command": "sh hooks/pre-edit-security/run.sh /absolute/path/to/file-being-edited"
      }
    ],
    "post_change": [
      {
        "command": "sh hooks/post-change-attest/run.sh /absolute/path/to/file-being-edited vault"
      }
    ]
  }
}
```

`mypowers` does not auto-edit either configuration file. Use `/mypowers:setup-hooks` to print the correct snippet for the current tool.

## Tooling Posture

- `FULL`: full recommended security stack detected
- `PARTIAL`: some recommended tools missing
- `BASIC`: no recommended SCA/security tools detected

Use `/mypowers:setup-tools` to print platform-specific install commands.

## Project-Specific Extensions

Organization-specific builder skills are intentionally out of scope for the public v1 release. The shared plugin should provide only posture-aware, portable scaffolding that applies to any project.
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `sh tests/test_docs_and_agents.sh`

Expected: PASS with `PASS: tests/test_docs_and_agents.sh`

- [ ] **Step 5: Commit**

```bash
git add skills/fortress-lab/SKILL.md skills/decision-weaver/SKILL.md skills/dynamic-skill-forge/SKILL.md skills/compliance-reporter/SKILL.md agents/visionary-agent.md agents/analyst-agent.md agents/security-auditor-agent.md agents/executor-agent.md README.md tests/test_docs_and_agents.sh
git commit -m "feat: add supporting skills agents and README"
```

## Task 9: Add Final Repo Smoke Verification

**Files:**
- Create: `tests/test_repo_smoke.sh`
- Modify: `tests/run-all.sh`

- [ ] **Step 1: Write the failing smoke test**

```sh
#!/bin/sh
set -eu

for shell_file in \
  tests/run-all.sh \
  tests/test_repo_layout.sh \
  tests/test_manifests.sh \
  tests/test_posture.sh \
  tests/test_scan.sh \
  tests/test_bridge_import.sh \
  tests/test_attest.sh \
  tests/test_skill_contract_part1.sh \
  tests/test_docs_and_agents.sh \
  scripts/posture.sh \
  scripts/posture-reporting.sh \
  scripts/setup-help.sh \
  scripts/scan.sh \
  scripts/bridge-import.sh \
  scripts/attest.sh \
  hooks/pre-edit-security/run.sh \
  hooks/post-change-attest/run.sh
do
  sh -n "$shell_file"
done

python3 - <<'PY'
import json
from pathlib import Path

for path in [
    Path(".codex-plugin/plugin.json"),
    Path(".claude-plugin/plugin.json"),
    Path("commands/mypowers.json"),
]:
    json.loads(path.read_text())
PY

grep 'tests/test_repo_smoke.sh' tests/run-all.sh >/dev/null

echo "PASS: tests/test_repo_smoke.sh"
```

- [ ] **Step 2: Run the smoke test to verify the current repo still fails**

Run: `sh tests/test_repo_smoke.sh`

Expected: FAIL because `tests/run-all.sh` does not yet invoke `tests/test_repo_smoke.sh`

- [ ] **Step 3: Implement the smoke verification wiring**

```sh
#!/bin/sh
set -eu

for test_file in \
  tests/test_repo_layout.sh \
  tests/test_manifests.sh \
  tests/test_posture.sh \
  tests/test_scan.sh \
  tests/test_bridge_import.sh \
  tests/test_attest.sh \
  tests/test_skill_contract_part1.sh \
  tests/test_docs_and_agents.sh \
  tests/test_repo_smoke.sh
do
  sh "$test_file"
done

echo "PASS: tests/run-all.sh"
```

- [ ] **Step 4: Run the smoke test to verify it passes**

Run: `sh tests/test_repo_smoke.sh`

Expected: PASS with `PASS: tests/test_repo_smoke.sh`

- [ ] **Step 5: Commit**

```bash
git add tests/run-all.sh tests/test_repo_smoke.sh
git commit -m "test: add repo smoke verification"
```

## Self-Review Checklist

Before execution begins, review this plan against the spec:

1. Spec coverage:
   - dual manifests: Task 2
   - shared scripts and posture source of truth: Tasks 3 through 6
   - shared hooks and wrapper scripts: Tasks 4 and 6
   - templates and bridge import integrity blocking: Task 5
   - skills, agents, commands, and README setup guidance: Tasks 2, 7, and 8
   - truthful `FULL` / `PARTIAL` / `BASIC` messaging: Tasks 3, 4, 5, 6, 7, and 8
   - no auto-mutation of host config: Task 8
   - organization-specific extensions remain out of scope: Task 8

2. Placeholder scan:
   - no `TODO`
   - no `TBD`
   - no “implement later”

3. Type and naming consistency:
   - scripts consistently call `scripts/posture.sh`
   - posture helper is consistently named `scripts/posture-reporting.sh`
   - hook wrappers consistently delegate into `scripts/`
   - command names consistently use the `mypowers` namespace

## Verification Commands After Implementation

Run these after all tasks are complete:

```bash
sh tests/test_repo_layout.sh
sh tests/test_manifests.sh
sh tests/test_posture.sh
sh tests/test_scan.sh
sh tests/test_bridge_import.sh
sh tests/test_attest.sh
sh tests/test_skill_contract_part1.sh
sh tests/test_docs_and_agents.sh
sh tests/test_repo_smoke.sh
```

Expected: every command prints a `PASS:` line and exits with code `0`.
