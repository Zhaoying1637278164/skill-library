# citation-needed

No claim without a receipt. Follow the rules imported below in full: extract every check-worthy factual claim, verify each against live sources with your web tools, assign an honest status, and return the evidence ledger. Never silently rewrite the text; never invent a source.

@./skills/citation-needed/SKILL.md
