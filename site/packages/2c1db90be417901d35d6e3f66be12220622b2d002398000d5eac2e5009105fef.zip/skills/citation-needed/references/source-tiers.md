# Source tiers

The evidence standard is: two independent Tier B sources, or one Tier A source, makes
a claim VERIFIED. One Tier B source makes it PARTIAL. Tier C can point you to a better
source but never counts on its own. Tier D is not evidence.

## Tier A — primary

The thing itself, or the party that owns the fact.

- Official statements, press releases, and pages of the organisation the claim is about
- Government and regulator records: statutes, court filings, registries, statistics offices
- Original documents: the paper, the report, the filing, the contract, the patent
- Official results and databases: sports governing bodies, election authorities, standards bodies
- Recordings and transcripts of the event or interview
- The person's own published words (their book, post, or statement), for what they said

A Tier A source proves what it contains. It does not prove interpretation. A company
press release proves the company announced X, not that X is true.

## Tier B — reputable secondary

Publishers with editorial standards and a correction process.

- Wire services and established news organisations
- Peer-reviewed journals and academic presses
- Reference works with editorial oversight
- Specialist trade publications with named journalists
- Reputable databases and encyclopedias for uncontested facts

Two Tier B sources are independent only if they are different publishers and neither
is quoting, syndicating, or citing the other. Check the byline and the phrasing. Two
articles that share three sentences share one origin.

## Tier C — weak

Useful for finding Tier A or B sources. Never sufficient alone.

- Wikipedia and other user-edited wikis (follow the footnote to the real source)
- Personal blogs, newsletters, and forum posts
- Aggregators, content farms, and SEO listicles
- AI-generated summaries and answer boxes
- Social media posts by anyone other than the subject of the claim

## Tier D — not evidence

- The draft you are checking
- Any other AI output, including your own memory
- A page that merely repeats the draft's wording
- A URL you did not get from a tool in this session

## Reading a source

- Check the date. A 2019 page cannot verify a "current" claim.
- Check who is speaking. A quote inside an article is the interviewee's claim, not the
  publication's finding.
- Check the unit and the basis. Revenue vs profit, nominal vs real, calendar vs fiscal
  year, local time vs UTC.
- Prefer the passage to the headline. Headlines round, compress, and sometimes
  contradict the body.
