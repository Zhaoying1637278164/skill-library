---
{"description": "Fact-check drafts against live sources for the rest of this session"}
---

Use the `citation-needed` skill and apply its rules to every response for the rest of
this session: extract every check-worthy factual claim, verify each with web tools
against the two-source-or-one-primary standard, assign an honest status, and return
the evidence ledger with problem markers in place. Never silently rewrite; never invent
a source. These rules persist until I say "stop citation-needed".
