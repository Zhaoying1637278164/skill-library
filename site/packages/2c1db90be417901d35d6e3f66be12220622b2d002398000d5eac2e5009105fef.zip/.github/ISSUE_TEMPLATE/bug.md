---
name: Bug
about: Install problem, hook problem, script error, or the report format breaking
title: ""
labels: bug
---

**What happened**

**What you expected**

**Platform and version** (e.g. Claude Code 2.1.x, Codex 0.15.x, Cursor, Gemini CLI)

**How you installed it** (command or file copy)

**Output or error** (paste in a code block)
