---
name: Wrong verdict
about: The skill marked a claim VERIFIED that is wrong, or flagged a claim that is right
title: "Wrong verdict: <short claim>"
labels: wrong-verdict
---

**The claim (verbatim from the text)**

**What the skill said** (status, evidence column, fix column)

**What is actually true, with a source you can open**

**Platform and model** (e.g. Claude Code 2.1 / Codex 0.15, model name)

**Mode** (default / quick check / strict / guard)

**Can we turn this into a fixture?** If yes, suggest a one-paragraph text that
contains the claim.
