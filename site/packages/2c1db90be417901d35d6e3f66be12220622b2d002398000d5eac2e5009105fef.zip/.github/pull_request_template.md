## What changed

## Why

## Checks

- [ ] `python3 -m unittest discover -s tests` passes
- [ ] `python3 scripts/run_evals.py validate` passes
- [ ] If `SKILL.md` changed: `.cursor` mirror re-copied, and eval results table pasted below
- [ ] If the version changed: every manifest and `CHANGELOG.md` updated

## Eval results (if behaviour changed)
