# Script: "The seven-title club" (YouTube, 4 minutes)

HOOK: Only two drivers in history have won seven Formula 1 world championships. One of them did it with a broken neck. Stay with me.

Michael Schumacher won seven world championships, and his first title came with Ferrari in 1994. Lewis Hamilton matched that record of seven titles in 2020. Before either of them, Juan Manuel Fangio won five titles in the 1950s, a record that stood for almost half a century.

Not every great story ends well. Ayrton Senna died at Imola on May 1, 1994. For me, Senna at Monaco in 1988 is the greatest qualifying lap ever driven. As Niki Lauda put it, "If you no longer go for a gap that exists, you are no longer a racing driver."

The modern era belongs to two names. Sebastian Vettel won four consecutive titles with Red Bull from 2011 to 2014, and Max Verstappen took his first championship in 2022 after that famous last lap in Abu Dhabi. I think Verstappen will end up with more titles than either of them.

Two bits of trivia to close. Ferrari is the only team to have competed in every Formula 1 season since 1950, and the Monaco Grand Prix has appeared on the Formula 1 calendar every single year since 1950. On two wheels, Valentino Rossi won nine world titles across all classes, and Marc Márquez became the youngest premier-class champion in 2013.

OUTRO: If you learned something, the next video is about the race that changed the safety rules forever.
