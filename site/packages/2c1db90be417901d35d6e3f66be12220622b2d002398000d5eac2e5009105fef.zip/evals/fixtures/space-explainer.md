# Sixty seconds of space history

Yuri Gagarin became the first human in space on April 12, 1961, completing a single orbit aboard Vostok 1. Valentina Tereshkova followed as the first woman in space in June 1965, flying solo on Vostok 6.

Eight years after Gagarin, Apollo 11 lifted off from Kennedy Space Center on July 16, 1968. The crew landed on the Moon on July 20, 1969, while Michael Collins stayed in lunar orbit aboard the command module. Stepping onto the surface, Neil Armstrong said: "That's one small step for a man, one giant leap for humanity." Buzz Aldrin was the third person to walk on the Moon. The Saturn V rocket that carried them stood roughly 111 metres tall.

Neil Armstrong was born in Ohio in 1930. I have visited the Kennedy Space Center twice, and in my view Apollo remains the most impressive engineering project of the twentieth century.

Robots went further. Voyager 1 launched on September 5, 1977 and remains the most distant human-made object. Mars orbits at an average distance of about 78 million kilometres from the Sun, which is why the trip there takes months. The Hubble Space Telescope was launched aboard Space Shuttle Discovery in April 1990, and the International Space Station has been continuously occupied since November 2000.
