---
tier: conditional
activates: 활성 계획 존재
portable: true
---

# Loop Engineering Rule

**얼마나 오래·끈질기게** 행동하는가. 게이트(설계 — 사람 승인, **의도적 멈춤**:
brainstorming/plan-task HARD-GATE) ≠ 루프(실행 — 승인된 계획을 P0·완료·가드 도달
전까지 자율 완주, 매 단계 확인 없이). 루프는 게이트를 우회하지 않는다.

## 드라이버 (Task 시스템 + 스킬 루프)

`while(미완료 항목):` 재앵커(요약이 아닌 계획 `plan.md` 원본 재확인 — 요약은
drift한다) → unblocked 항목 선택 → 실행 → 완료 시 checklist complete(verify 통과로만) →
태스크 완료 마킹(호스트 수단) → 종료 가드 점검(아래) → 확인 없이 다음 unblocked로 → 완료 보고.

## 종료 가드 (안티-런어웨이 = 필수)

**P0**(데이터/보안/결제/핵심로직 모호 → 선택지 제시, 호스트 수단으로) · **완료**(검증
게이트 green + 수동 DoD attest + 배치 전체 계획·항목 해소, `definition-of-done` —
"마지막 스텝 도달"≠완료) · **무진전**(같은 항목이 2회 연속 새 커밋·checklist 통과 없이
끝남 → 에스컬레이션·중단 보고) · **검증 실패 잔존**(가드 재시도 후에도 실패 → 보고)
에서 반드시 멈춘다.

배치 실행(킷의 `auto-dev` 등)은 계획 완료 시 자동 전진, 단발 실행은 루프 없음 — opt-in, 루프 실패가
본 작업을 막지 않는다.
