# Spring Standards — Claude Code Plugin

Production-grade engineering standards for Spring Boot projects. One skill that adapts to both **modular monoliths** and **microservices**.

## What It Does

When you work on a Spring Boot project with Claude Code, this plugin enforces:

- **Hexagonal architecture** with clear domain/application/infrastructure separation
- **Feature-oriented package structure** instead of framework-driven sprawl
- **Explicit layer rules** — domain never depends on Spring, JPA entities stay in infrastructure, controllers delegate to use cases
- **API design standards** — OpenAPI, consistent error contracts, validation at all levels
- **Security baseline** — deny-by-default, least privilege, protected actuators
- **Testing strategy** — unit, integration, contract, and non-functional tests with Testcontainers
- **Observability** — structured logging, trace IDs, metrics, health endpoints
- **Database discipline** — Flyway migrations, no Hibernate DDL in production

The skill automatically detects whether your project is a modular monolith or microservices system and loads the appropriate guide.

## Install

```bash
claude plugin add alexanderCanon/spring-standards
```

## Usage

The skill activates automatically when Claude detects Spring Boot work. You can also invoke it explicitly:

```
/spring-standards
```

## Architecture Coverage

### Always Applied (Shared Foundation)
- Hexagonal architecture + DDD-inspired boundaries
- Package and module governance
- API design, error handling, validation standards
- Security, observability, configuration management
- Database migrations, Docker, testing, CI/CD
- AI coding tool operating rules

### Modular Monolith
- Module boundary rules by business capability
- Transaction strategy using local ACID advantage
- Data ownership within a shared database
- Internal module interaction patterns
- Performance and scalability guidance

### Microservices
- Service boundary and data ownership rules
- Synchronous and asynchronous communication standards
- Resilience patterns (timeouts, retries, circuit breakers, idempotency)
- Distributed observability with tracing
- Service-to-service security
- Data consistency strategy

## Technology Baseline

- Spring Boot
- Spring Security
- Spring Boot Actuator
- PostgreSQL
- Flyway
- Docker
- Testcontainers
- OpenAPI / Swagger
- Hexagonal Architecture + DDD

## License

MIT
