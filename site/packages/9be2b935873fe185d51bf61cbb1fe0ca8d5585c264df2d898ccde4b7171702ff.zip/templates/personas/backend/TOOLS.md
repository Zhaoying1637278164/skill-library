# Tools — Backend Engineer Persona

## Required

- **GitHub MCP** (`mcp__github__*`): Read issues, post comments, manage labels.
- **Repo tools** (Read, Write, Edit, Bash, Grep, Glob): Full codebase access for implementation.

## Common Patterns

### Implement a feature
1. Read the issue and existing code
2. Create or modify files (Edit/Write)
3. Run tests (Bash)
4. Commit changes (Bash — git)
5. Post heartbeat comment with commit SHAs (GitHub MCP)

### Fix a bug
1. Read the issue for reproduction steps
2. Find relevant code (Grep/Glob)
3. Fix and add regression test
4. Commit and comment

### Database work
- Use Neon MCP (`mcp__neon__*`) if available for database operations
- Always create reversible migrations
- Test migration up and down paths

## Optional Tools

Add to `required_tools` in config.yaml as needed:
- `mcp__neon` — Neon Postgres (database queries, migrations)
- `mcp__context7` — Documentation lookup
