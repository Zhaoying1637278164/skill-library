---
description: Run a githubclip heartbeat cycle (pick up issues, do work, report)
argument-hint: "[--dry-run] [--persona NAME]"
---

Run the githubclip heartbeat using the heartbeat skill.

**GitHub-native:** reads `.githubclip/config.yaml` and executes against GitHub Projects via GitHub MCP.

Arguments passed: $ARGUMENTS

Parse the arguments:
- If `--dry-run` is present, pass it through to the heartbeat procedure (Step 3 reports what would be picked without doing work)
- If `--persona <name>` is present, filter to only issues matching that persona's label

Execute the full heartbeat procedure (GitHub Project items, persona routing, work, reporting, state updates). On any error or exit, ensure the lockfile at `.githubclip/.heartbeat-lock` is deleted.

**Anti-fragile behaviors enabled:**
- Schema validation and drift detection
- Progressive degradation on write failures
- Canary mutation check
- Recovery journal for crash resume
