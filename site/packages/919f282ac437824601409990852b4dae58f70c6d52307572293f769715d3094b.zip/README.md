# castellano-rae-plugin
Claude Code plugin — Corrección y análisis de castellano a nivel bachillerato (RAE)
