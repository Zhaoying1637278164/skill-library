# Análisis Académico — Nivel Bachillerato

## Las 6 Dimensiones

---

## 1. Corrección Normativa

Evalúa el cumplimiento de la norma RAE (OLE 2010 + NGLE).

**Escala de gravedad:**
- 🔴 **Grave**: tilde diacrítica, haber impersonal, dequeísmo/queísmo, leísmo no aceptado,
  gerundio de posterioridad, confusión ser/estar con cambio de significado
- 🟡 **Leve**: tilde no diacrítica, mayúscula incorrecta, puntuación no normativa,
  mismo como anáfora, «en base a», abuso de pasiva
- 🔵 **Estilo**: voz activa preferible, variedad léxica, conectores más precisos

---

## 2. Adecuación y Registro

Evalúa si el texto es apropiado para su contexto comunicativo.

**Parámetros:**

| Registro | Rasgos léxicos | Rasgos morfosintácticos | Rasgos textuales |
|---|---|---|---|
| Coloquial | Léxico común, expresiones hechas, apócopes | Oraciones simples, yuxtaposición | Subjetivo, espontáneo |
| Estándar | Léxico neutro y preciso | Variedad sintáctica moderada | Objetivo o moderadamente subjetivo |
| Culto/académico | Léxico técnico, cultismos, tecnicismos | Oraciones complejas, subordinación | Objetivo, impersonal |

**Preguntas de evaluación:**
- ¿El léxico es adecuado al destinatario y al contexto?
- ¿La sintaxis refleja el registro esperado?
- ¿Hay incongruencias de registro (mezcla de coloquial y formal)?
- ¿La persona gramatical es adecuada (tuteo / ustedeo / impersonal)?

---

## 3. Coherencia y Cohesión

### Coherencia (nivel del contenido)
- **Unidad temática**: el texto desarrolla un solo tema central
- **Progresión**: la información avanza (tema-rema; de lo conocido a lo nuevo)
- **No contradicción**: ausencia de afirmaciones que se anulen entre sí
- **Relevancia**: toda la información contribuye al tema central

### Cohesión (nivel de la forma)

**Mecanismos de cohesión:**

**Deixis:**
- Anáfora (referencia a lo ya mencionado): *Pedro llegó tarde. **Él** no se disculpó.*
- Catáfora (referencia a lo que viene): ***Este** es el problema: no hay recursos.*

**Elipsis:** omisión de elementos recuperables del contexto:
*María estudió mucho y [María] aprobó.*

**Sustitución léxica:** sinónimos, hiperónimos, perífrasis:
*Llegó el presidente. **El mandatario** saludó a la multitud.*

**Conectores discursivos por función:**

| Función | Conectores |
|---|---|
| Aditivos | además, asimismo, también, incluso, es más, por añadidura |
| Adversativos | sin embargo, no obstante, aunque, pero, sino, a pesar de, con todo |
| Causales | porque, ya que, puesto que, dado que, pues, como |
| Consecutivos | por tanto, por consiguiente, en consecuencia, así pues, de ahí que |
| Temporales | después, a continuación, previamente, finalmente, mientras, entonces |
| Explicativos | es decir, o sea, esto es, a saber, en otras palabras |
| Ejemplificadores | por ejemplo, en concreto, en particular, a saber, pongamos que |
| Reformuladores | mejor dicho, en realidad, en definitiva, en resumen |
| Ordenadores | en primer lugar, por un lado / por otro, finalmente, para concluir |

---

## 4. Estilo y Recursos Expresivos

### Figuras retóricas

**Semánticas:**
- **Metáfora**: identificación de dos realidades sin «como»: *Sus ojos son luceros.*
- **Símil/comparación**: con nexo comparativo: *Luchó como un león.*
- **Metonimia**: sustitución por contigüidad: *Tomó la copa* (= el vino).
- **Sinécdoque**: la parte por el todo o viceversa: *Tiene muchas bocas que alimentar.*
- **Hipérbole**: exageración: *Te lo he dicho mil veces.*
- **Ironía**: se dice lo contrario de lo que se piensa: *¡Qué maravilla de servicio!*
- **Antítesis**: contraposición de ideas: *Es tan corto el amor y tan largo el olvido.*
- **Paradoja**: aparente contradicción que encierra verdad: *Muero porque no muero.*
- **Oxímoron**: unión de contrarios en un sintagma: *Un silencio atronador.*
- **Eufemismo**: suavización: *Persona mayor* (= viejo); *conflicto armado* (= guerra).
- **Personificación/prosopopeya**: atribuir cualidades humanas a lo inanimado: *El viento susurró su nombre.*
- **Lítotes**: negación de lo contrario para afirmar: *No era cobarde* (= era valiente).

**Sintácticas:**
- **Anáfora**: repetición al inicio de versos u oraciones: *Vine, vi, vencí.*
- **Epífora**: repetición al final: *¿Cuándo?, ¿cómo?, ¿por qué?*
- **Paralelismo**: estructuras sintácticas paralelas: *Llegó, vio, conquistó.*
- **Hipérbaton**: alteración del orden lógico: *Del salón en el ángulo oscuro.*
- **Elipsis retórica**: omisión con efecto expresivo: *Al pan, pan; y al vino, vino.*
- **Asíndeton**: supresión de conjunciones: *Llegué, vi, vencí.*
- **Polisíndeton**: repetición de conjunciones: *Y ríe, y llora, y canta, y baila.*
- **Gradación**: enumeración en orden ascendente o descendente.
- **Quiasmo**: estructura cruzada: *Cuando quiero llorar, no lloro; / a veces lloro sin querer.*
- **Apóstrofe**: invocación directa: *¡Oh, fortuna, cuán mudable eres!*
- **Perífrasis retórica**: rodeo expresivo: *El astro rey* (= el sol).
- **Sinestesia**: mezcla de sensaciones: *Un silencio verde.*
- **Aliteración**: repetición de sonidos: *El ala aleve del leve abanico.*

**Evaluación del estilo:**
- Riqueza léxica (variedad, precisión, evitar repeticiones)
- Variedad sintáctica (no abusar de frases cortas ni largas)
- Uso de recursos expresivos con función (no ornamental)

---

## 5. Tipología Textual

### Narrativo
**Rasgos**: narrador (1.ª/3.ª persona), tiempo (pasado predominante), espacio,
personajes, secuencia narrativa (planteamiento-nudo-desenlace).
**Verbos**: pretérito perfecto simple o imperfecto.
**Función**: contar hechos reales o ficticios.

### Descriptivo
**Rasgos**: adjetivación abundante, ausencia de progresión temporal, punto de
vista (objetivo/subjetivo), presente o imperfecto.
**Función**: representar seres, lugares, objetos, estados.
**Subtipos**: retrato (persona), topografía (lugar), cronografía (época).

### Expositivo
**Rasgos**: objetividad, léxico técnico o especializado, estructura ordenada
(inductiva: ejemplos→conclusión / deductiva: idea general→ejemplos),
uso de definiciones, clasificaciones, ejemplos.
**Función**: informar, explicar, aclarar.

### Argumentativo
**Estructura**: tesis + argumentos + (contraargumentación) + conclusión.
**Tipos de argumento**:
- De autoridad: cita a expertos o fuentes fiables
- De ejemplo: casos concretos que apoyan la tesis
- Estadístico: datos cuantitativos
- Analógico: comparación con otra situación similar
- De experiencia: vivencias propias o ajenas
**Falacias frecuentes**: ad hominem, ad populum («todo el mundo sabe»),
pendiente resbaladiza, falsa dicotomía.
**Función**: persuadir, convencer.

### Instructivo
**Rasgos**: modalidad imperativa o infinitiva, segunda persona (tú/usted/vosotros),
secuencialidad (numeración, conectores temporales: primero, después, finalmente),
precisión léxica.
**Función**: guiar la conducta del destinatario.

### Dialogado
**Rasgos**: alternancia de turnos, marcadores conversacionales, deixis personal,
registro coloquial o formal según el contexto.
**Función**: representar la comunicación oral.

---

## 6. Análisis Morfosintáctico

### Metodología paso a paso

**Paso 1: Tipo de oración**
- Simple: un solo verbo conjugado
- Compuesta por coordinación: dos o más proposiciones del mismo rango (copulativa «y», adversativa «pero/sino», disyuntiva «o», distributiva «ya...ya», explicativa «es decir»)
- Compuesta por subordinación: una proposición depende de otra

**Paso 2: Delimitar sintagmas**
- SN (sintagma nominal): Determinante + (Adyacente) + Núcleo N + (Complemento del N)
- SV (sintagma verbal): Núcleo V + (Complementos)
- SAdj: (Adv modificador) + Núcleo Adj
- SAdv: (Adv modificador) + Núcleo Adv
- SPrep: Preposición + término (SN/SAdj/SAdv)

**Paso 3: Funciones sintácticas**
| Función | Abreviatura | Identificación |
|---|---|---|
| Sujeto | Suj | Concuerda con el verbo en persona y número |
| Predicado | Pred | Todo el SV |
| Complemento Directo | CD | «lo/la/los/las» lo sustituye |
| Complemento Indirecto | CI | «le/les» lo sustituye |
| Complemento Circunstancial | CC | Responde a ¿dónde?, ¿cuándo?, ¿cómo?... |
| Atributo | Atr | Con ser/estar/parecer; lo sustituye «lo» |
| Complemento Predicativo | CPred | Predica del sujeto o CD con verbos no copulativos |
| Complemento de Régimen | CRég | Preposición exigida por el verbo: *hablar de* |
| Complemento Agente | CAg | En pasiva perifrástica: *por + SN* |

**Paso 4: Tipo de subordinadas**
- **Sustantivas**: hacen función de SN (sujeto, CD, CI…). Nexos: que, si, interrogativos (qué, quién…)
- **Adjetivas/relativas**: modifican a un antecedente. Nexos: que, quien, cual, cuyo, donde…
  - Especificativas (sin comas): *El libro que leí era interesante.*
  - Explicativas (con comas): *Madrid, que es la capital, tiene 3 millones.*
- **Adverbiales**: función de CC.
  - Lugar (donde), tiempo (cuando, mientras, antes de que…), modo (como, según…)
  - Causales (porque, ya que, puesto que…), finales (para que, a fin de que…)
  - Concesivas (aunque, a pesar de que…), condicionales (si, en caso de que…)
  - Consecutivas (tan…que, tanto…que…)
  - Comparativas (más…que, tan…como…)

**Paso 5: Modo verbal y justificación**
- Indicativo: realidad o certeza
- Subjuntivo: deseo, duda, hipótesis, mandato negativo, acción no realizada
- Imperativo: orden o ruego directos (solo afirmativo)
