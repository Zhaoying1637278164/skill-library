# Ortografía — OLE 2010

## Tildes

### Reglas generales
| Tipo | Condición | Ejemplos |
|---|---|---|
| Aguda | Tilde si acaba en vocal, -n, -s | canción, café, compás |
| Llana | Tilde si NO acaba en vocal, -n, -s | árbol, fácil, carácter |
| Esdrújula | Siempre tilde | pájaro, música, cómodo |
| Sobresdrújula | Siempre tilde | dígamelo, lléveselo |

### Tilde diacrítica
| Con tilde | Sin tilde |
|---|---|
| él (pronombre personal) | el (artículo) |
| tú (pronombre personal) | tu (posesivo) |
| sí (afirmación / pron. reflexivo) | si (condicional / nota musical) |
| mí (pronombre personal) | mi (posesivo / nota musical) |
| más (cantidad) | mas (= pero, conjunción adversativa) |
| sé (saber 1.ª sg. / ser imperativo) | se (pronombre) |
| té (infusión) | te (pronombre / nota musical) |
| dé (dar subjuntivo/imperativo) | de (preposición) |
| aún (= todavía) | aun (= incluso) |

**Nota OLE 2010:** «solo» (adverbio = solamente) ya NO lleva tilde. Tampoco
los demostrativos «este/ese/aquel» como pronombres.

### Hiatos acentuados
Tilde cuando la vocal débil (i, u) es tónica junto a vocal fuerte:
baúl, país, oído, reír, actúa, continúo, prohíbe.

### Interrogativas y exclamativas
qué, quién, cuándo, cómo, dónde, cuál, cuánto llevan tilde en interrogativas y
exclamativas directas e indirectas: «¿Cuándo llega?», «No sé qué hacer».

### Tildes en mayúsculas
Las mayúsculas SÍ llevan tilde: MÁLAGA, Ángel, Óscar.

### Palabras compuestas
Solo el último componente lleva tilde si procede: decimoséptimo, rioplatense.
Con guion, cada parte conserva su tilde: físico-químico.

### Adverbios en -mente
Conservan la tilde del adjetivo base: fácilmente, ágilmente, cortésmente.

---

## Consonantes con confusión frecuente

### B y V (mismo sonido bilabial en España)
- Imperfecto -ar e «ir»: **siempre -aba** (cantaba, iba, estaba)
- «haber» y compuestos: ha**b**ía, hu**b**o, ha**b**er, sa**b**er
- Prefijos bi-, bis-, biz-: bilateral, bisabuelo, biznieto
- Después de m: también, cambio, ambos, combinar
- «v» en verbos «ir», «vivir», «servir» cuando el sonido comienza vocal: voy, vive, vino

### G y J
- Ge/gi suaves → g: gente, girar, agente, región
- Je/ji fuertes → j: jefe, jinete, viaje, tijera, caja, ojo
- -ger/-gir → g (coger, dirigir) salvo «tejer, crujir»

### H muda
Obligatoria en: haber (≠ a ver), hacer, hablar, huir, ahora, ahí, hay (≠ ay ≠ ahí)

### LL e Y (yeísmo aceptado en pronunciación)
Ortografía diferente: pollo ≠ poyo, valla ≠ vaya, hulla ≠ huya, arrollo ≠ arroyo

### X / S / CC
- x ante consonante → s: «esplicar» incorrecto → «explicar»
- cc cuando hay dos sonidos /k+θ/: acción, acceso, dirección, lección
- pero: conexión, reflexión (solo /ks/)

---

## Mayúsculas

**Sí llevan mayúscula:** nombres propios de persona, lugar, institución, obra,
acontecimiento histórico relevante (la Revolución Francesa), nombre de eras
geológicas, disciplinas académicas cuando son nombre propio de asignatura
(«Matemáticas», cuando es el nombre de la asignatura concreta).

**No llevan mayúscula:** cargos y títulos (el presidente, la reina, el papa),
meses (enero, febrero), días (lunes, martes), estaciones, gentilicios (español,
madrileño), asignaturas genéricas (matemáticas, lengua), los puntos cardinales
salvo en denominaciones geográficas (el norte ≠ América del Norte).

---

## Puntuación exhaustiva

### Punto
- Cierra enunciado.
- NO tras títulos y subtítulos de apartados, ni tras el título de un libro.
- Tras abreviaturas: Sr., pág., etc. (pero no tras siglas: RAE, ONG).

### Coma
**Usos principales:**
- Enumeración de elementos sin conjunción final: *pan, leche, huevos y mantequilla*
- Vocativo: *María, ven aquí* / *Venid, chicos*
- Inciso explicativo: *Madrid, capital de España, tiene 3 millones de habitantes*
- Subordinada adverbial antepuesta: *Cuando llegues, llámame*
- Ante «pero», «sino», «aunque», «sin embargo», «no obstante» en cláusulas largas
- Ante «es decir», «o sea», «esto es»

**Prohibida entre sujeto y verbo:** ~~«Los alumnos, aprobaron»~~ incorrecto.

### Punto y coma
**Tres usos:**
1. **Enumeraciones complejas** cuyos elementos ya contienen comas:
   *Llegaron María, de Madrid; Pedro, de Sevilla; y Ana, de Valencia.*
2. **Ante conectores adversativos o consecutivos** en cláusulas largas:
   *Estudió mucho; sin embargo, no aprobó.*
   *Había llovido toda la noche; por tanto, las calles estaban mojadas.*
3. **Oraciones relacionadas** sin conjunción cuando la coma sería ambigua:
   *Los precios subieron un 3 %; la inflación se disparó.*

### Dos puntos
- Ante enumeración: *Vinieron tres países: Francia, Italia y España.*
- Cita textual: *El director dijo: «El proyecto está listo».*
- Causa-efecto o conclusión: *Estaba agotado: había trabajado doce horas.*
- Tras fórmula de saludo en cartas y correos: *Estimado señor García:*

### Puntos suspensivos
- Suspensión del discurso o duda: *No sé si ir o...*
- Enumeración incompleta (equivale a «etcétera»): *Trajo pan, leche...*
- Ironía o sobreentendido: *Sí, claro...*
- Omisión en cita textual (entre corchetes): *«El acuerdo [...] fue firmado ayer»*
- **Siempre son tres**, pegados a la palabra anterior, espacio tras ellos si sigue texto.

### Paréntesis ( ) ← PREFERIDOS EN ESTA SKILL SOBRE LA RAYA
- Incisos aclaratorios: *El tratado (firmado en 1945) sigue vigente.*
- Datos complementarios: *Llamad al 112 (emergencias) si es urgente.*
- Opciones: *El/la alumno/a deberá entregar el trabajo.*
- Dentro de un paréntesis, punto antes del cierre si es oración completa:
  *(El proyecto fue cancelado.)*

### Raya — (válida por RAE, sustituir por paréntesis en producción propia)
- Incisos con mayor integración sintáctica: *El proyecto —ya terminado— fue presentado.*
- Diálogos: guion largo al inicio de cada intervención.
- **En esta skill:** sustituir por paréntesis en toda escritura propia.

### Comillas
- **Españolas «»**: texto citado, uso metalingüístico, ironía → PREFERIDAS
- **Inglesas ""**: citas dentro de citas, títulos en contexto digital
- **Simples ''**: significados, uso dentro de «»

### Signos de interrogación y exclamación
- **Apertura obligatoria** en español: ¿...? y ¡...!
- Pueden delimitar solo la parte interrogativa/exclamativa:
  *Pero, ¿qué dices?* / *Ven aquí, ¡ahora mismo!*

### Abreviaturas, siglas y acrónimos
- Abreviatura: lleva punto (Sr., pág., etc., núm.)
- Sigla: mayúsculas sin puntos (RAE, ONG, DNA)
- Acrónimo: se lee como palabra (Renfe, Otan, radar)
- Plural de siglas: sin -s (*las ONG*, no ~~las ONGs~~)
