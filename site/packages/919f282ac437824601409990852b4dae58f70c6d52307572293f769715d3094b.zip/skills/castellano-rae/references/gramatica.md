# Gramática — NGLE

## Perífrasis verbales

### Modales
| Perífrasis | Valor | Ejemplo |
|---|---|---|
| deber + inf. | Obligación | Debes estudiar más. |
| deber de + inf. | Probabilidad/suposición | Debe de ser tarde. |
| poder + inf. | Posibilidad/permiso | Puede llover mañana. |
| tener que + inf. | Obligación fuerte | Tienes que entregar esto hoy. |
| haber de + inf. | Obligación (culto) | Has de saber que... |
| haber que + inf. | Obligación impersonal | Hay que trabajar más. |

**Error frecuente:** *«Debo de ir»* con valor de obligación → incorrecto. Usar *«debo ir»*.

### Aspectuales
| Perífrasis | Valor | Ejemplo |
|---|---|---|
| estar + gerundio | Acción en curso | Está estudiando ahora. |
| ir + gerundio | Progresión gradual | Vas mejorando. |
| llevar + gerundio | Duración acumulada | Lleva tres horas esperando. |
| ir a + infinitivo | Futuro inmediato/intención | Voy a salir ahora. |
| acabar de + infinitivo | Acción recién terminada | Acaba de llegar. |
| volver a + infinitivo | Repetición | Volvió a equivocarse. |
| dejar de + infinitivo | Cese de acción | Dejó de fumar. |
| seguir + gerundio | Continuación | Sigue estudiando. |
| ponerse a + infinitivo | Inicio | Se puso a llover. |

---

## Gerundio

### Usos correctos
- Acción **simultánea** al verbo principal: *Entró cantando.*
- Acción **anterior** al verbo principal: *Habiendo terminado el trabajo, salió.*
- Con verbos de percepción: *La vi cantando en el escenario.*
- Con «estar», «seguir», «ir», «llevar» (perífrasis): *Está lloviendo.*

### Usos incorrectos
- **Gerundio de posterioridad** — acción posterior al verbo principal:
  ~~*Cayó, rompiéndose la pierna*~~ (si la rotura fue después de la caída) → *Cayó y se rompió la pierna.*
- **Gerundio especificativo** (modifica a un sustantivo):
  ~~*Una ley regulando el tráfico*~~ → *Una ley que regula el tráfico.*
  (Solo válido en lenguaje jurídico y administrativo: «decreto regulando…»)
- Gerundio con valor causal cuando hay ambigüedad:
  ~~*Siendo tarde, nos fuimos*~~ → mejor *Como era tarde, nos fuimos.*

---

## Pronombres relativos

| Relativo | Uso | Ejemplo |
|---|---|---|
| que | Universal; sin preposición en registros no formales | el libro que leí |
| el que / la que / los que / las que | Con preposición; antecedente conocido | el libro del que hablamos |
| el cual / la cual… | Formal; tras preposiciones de más de una sílaba | la empresa para la cual trabajo |
| quien / quienes | Solo personas | el profesor a quien admiro |
| cuyo / cuya… | Posesivo (= de quien/del que) | el autor cuya obra leímos |
| donde | Lugar | la ciudad donde nació |
| cuando | Tiempo | el día cuando llegó |
| como | Modo | la manera como lo dijo |

### Error frecuente con cuyo
~~*El libro que su autor es conocido*~~ → *El libro cuyo autor es conocido*
~~*El hombre que su hija estudia aquí*~~ → *El hombre cuya hija estudia aquí*

---

## Concordancia

### Estándar
- Sujeto y verbo: persona y número. *Los niños juegan* / *Yo canto.*
- Adjetivo con sustantivo: género y número. *Las casas blancas.*

### Ad sensum
Con sustantivos colectivos, puede concertar con el sentido plural:
*La mayoría de los estudiantes **llegaron** tarde.* (también válido: *llegó*)
*Un grupo de personas **protestaron**.* (también válido: *protestó*)

### Con usted/ustedes
«Usted» es 2.ª persona de respeto pero concuerda con el verbo en 3.ª:
*Usted **sabe** lo que hace.* ✓

---

## Subjuntivo

### Usos principales
- **Subordinadas sustantivas de deseo, volición, duda:**
  *Quiero que **vengas**.* / *Dudo que **sea** verdad.*
- **Subordinadas relativas con antecedente indefinido o negado:**
  *Busco un empleado que **sepa** inglés.* (vs. *Tengo un empleado que **sabe** inglés.*)
- **Subordinadas concesivas:** *Aunque **llueva**, iremos.*
- **Subordinadas finales:** *Para que lo **entiendas**...*
- **Oraciones condicionales con «si»:**
  - Condición posible: *Si **llueve**, no saldremos.* (indicativo)
  - Condición hipotética: *Si **lloviera**, no saldríamos.* (imperfecto subj.)
  - **NUNCA:** ~~*Si **llovaría***~~ ni ~~*Si **habrá** llovido***~~

### Correlación temporal
| Verbo principal | Verbo subordinado |
|---|---|
| Presente / futuro | Presente de subj. (*quiero que **venga***) |
| Pasado / condicional | Imperfecto de subj. (*quería que **viniera***) |
| Pasado perfecto | Pret. perf. subj. (*ha pedido que **hayas venido***) |

---

## Ser y Estar

### Ser
Identidad, origen, materia, autoría, hora/fecha, precio fijo, pasiva de acción.
*Es médico. Es de Madrid. Es de madera. Son las tres. Fue escrito por Cervantes.*

### Estar
Estado, situación, resultado de un proceso, pasiva de estado, participios de proceso.
*Está cansado. Está en casa. Está muerto. El libro está escrito.*

### Diferencias de significado
| Con ser | Con estar |
|---|---|
| es listo (= inteligente) | está listo (= preparado) |
| es malo (= malvado) | está malo (= enfermo) |
| es bueno (= bondadoso) | está bueno (= sabroso / en buen estado) |
| es vivo (= despierto, avispado) | está vivo (= con vida) |
| es muerto (= oficio de muerto en teatro) | está muerto (= ha fallecido) |
| es seguro (= sin riesgo) | está seguro (= convencido) |

---

## Voz pasiva

### Pasiva perifrástica (ser + participio)
Acción: *El acuerdo **fue firmado** por los ministros.*
Válida, pero el español prefiere la voz activa en redacción clara:
*Los ministros **firmaron** el acuerdo.* ← más natural

### Pasiva refleja (se + verbo 3.ª persona)
*Se vendieron cien ejemplares.* / *Se ha convocado una reunión.*
Más frecuente en español que la perifrástica.

### Abuso de pasiva como anglicismo
Calco del inglés: ~~*El proyecto fue completado exitosamente*~~ →
*El proyecto se completó con éxito* o *Completamos el proyecto con éxito.*

---

## Preposiciones problemáticas

| Construcción incorrecta | Correcta | Nota |
|---|---|---|
| *en base a* | *sobre la base de / basándose en* | «en base a» está muy extendida pero la RAE prefiere las alternativas |
| *a nivel de calidad* | *en cuanto a calidad / en términos de calidad* | abuso de «a nivel de» |
| *bajo mi punto de vista* | *desde mi punto de vista / a mi juicio* | calco del francés/inglés |
| *de acuerdo a* | *de acuerdo con* | la norma culta prefiere «con» |
| *ante la duda* | correcto | ✓ |

---

## Leísmo, laísmo, loísmo

### Leísmo (referencia personal masculina singular — ACEPTADO)
*Le vi ayer* (= lo vi, persona masculina) ✓ aceptado en España
*Les vi ayer* (plural) ✗ no aceptado
*Le vi ayer* (cosa) ✗ no aceptado → *Lo vi*

### Laísmo (INCORRECTO)
~~*La dije la verdad*~~ → *Le dije la verdad* (CI femenino debe ser «le»)

### Loísmo (INCORRECTO)
~~*Lo dije a Juan que viniera*~~ → *Le dije a Juan que viniera*

---

## Dequeísmo y queísmo

**Dequeísmo** (añadir «de» donde no corresponde):
~~*Pienso de que es tarde*~~ → *Pienso que es tarde*
~~*Creo de que tiene razón*~~ → *Creo que tiene razón*
Truco: si puedes preguntar «¿Qué pienso?» → no lleva «de»

**Queísmo** (omitir «de» donde sí corresponde):
~~*Me alegro que hayas venido*~~ → *Me alegro de que hayas venido*
~~*Estoy seguro que vendrá*~~ → *Estoy seguro de que vendrá*
Truco: si puedes decir «me alegro de ello» → necesita «de»

---

## Haber impersonal

Siempre **singular**, aunque el sustantivo que le sigue sea plural:
*Había muchas personas.* ✓ (no ~~*habían*~~)
*Hubo varios problemas.* ✓ (no ~~*hubieron*~~)
*Ha habido muchos cambios.* ✓ (no ~~*han habido*~~)
*Hay diez alumnos.* ✓ (no ~~*hayn*~~, que no existe)

---

## «Mismo» como anáfora

**Correcto** (valor enfático o intensivo):
*El director mismo firmó el documento.* (= en persona)

**Incorrecto** (mero sustituto pronominal):
~~*Llamé al director y el mismo me respondió*~~ → *Llamé al director y él me respondió.*
~~*Consulté la ley; la misma establece que...*~~ → *Consulté la ley; esta establece que...*
