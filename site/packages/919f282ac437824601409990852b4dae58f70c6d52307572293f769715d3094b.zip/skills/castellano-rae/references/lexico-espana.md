# Léxico — España frente a Latinoamérica y neologismos

> En escritura propia, usar siempre la variante de España.
> En corrección de textos ajenos, señalar la variante LatAm y ofrecer la de España.

---

## Léxico por categorías

### Tecnología
| España | Evitar (LatAm) |
|---|---|
| ordenador | computadora, computador |
| móvil | celular |
| ratón (informático) | mouse |
| pantalla | monitor (cuando se refiere a la pantalla plana) |
| disco duro | hard disk (usar el español) |
| tecla | key (en contextos técnicos: usar «tecla») |
| contraseña | password (usar el español cuando sea posible) |
| correo electrónico / email | mail (preferir el término completo o «email» aceptado) |

### Transporte
| España | Evitar (LatAm) |
|---|---|
| coche | carro, auto, automóvil (auto es válido en España también) |
| conducir | manejar |
| autobús | camión (México), colectivo (Argentina), bus (válido en España) |
| metro | subte (Argentina), subterráneo |
| ascensor | elevador |
| aparcamiento / parking | parqueadero, estacionamiento |
| aparcar | parquear, estacionar (estacionar también válido en España) |
| tren de cercanías | tren suburbano |

### Alimentación
| España | Evitar (LatAm) |
|---|---|
| zumo | jugo |
| patatas (fritas) | papas (fritas) — papas válido en Canarias |
| melocotón | durazno, melocotón (válido en España y algunos países) |
| judías / alubias / habichuelas | frijoles, porotos, caraotas |
| pimiento | chile, ají (en contextos culinarios específicos) |
| maíz | choclo, elote |
| aguacate | palta (Argentina, Chile) |
| cacahuete | maní |
| tortilla (de patata) | omelet / omelette (para la de huevo sin relleno) |

### Vivienda
| España | Evitar (LatAm) |
|---|---|
| piso / apartamento | departamento, apartamento (apartamento válido en España) |
| frigorífico / nevera | refrigerador, heladera |
| lavabo / lavamanos | lavamanos es válido |
| fontanero | plomero, gasfiter |
| electricista | idéntico |
| comunidad de vecinos | propiedad horizontal |

### Ropa y complementos
| España | Evitar (LatAm) |
|---|---|
| jersey / suéter | chompa, buzo, polera |
| bañador | traje de baño, malla, pantaloneta |
| calcetines | medias (para referirse a los calcetines cortos) |
| bolso | cartera (en algunos países) |
| gafas | lentes, anteojos |
| zapatillas (deporte) | tenis, zapatos deportivos |
| sandalias | chanclas (chanclas válido en España también) |

### Trabajo y educación
| España | Evitar (LatAm) |
|---|---|
| currículo / currículum vítae | hoja de vida (aunque se usa en España también) |
| empresa | compañía (compañía también válido) |
| jefe/a | gerente, patrón |
| nómina | quincena, planilla |
| contrato | idéntico |
| instituto | colegio de secundaria / bachillerato (en LatAm «colegio» incluye secundaria) |
| carrera universitaria | carrera (idéntico) |
| apuntes | notas (en algunos países) |
| bolígrafo | lapicero, esfero, birome, pluma (pluma es «pluma estilográfica» en España) |

### Medicina y salud
| España | Evitar (LatAm) |
|---|---|
| médico de cabecera | médico de familia |
| ambulatorio / centro de salud | consultorio, clínica (clínica en España es privada) |
| urgencias | emergencias (emergencias también usado en España) |
| inyección | pinchazo (coloquial en España), vacuna (solo si es vacuna) |
| tiritas | curitas, banditas |
| farmacia | botica (arcaico en España) |

### Dinero y comercio
| España | Evitar (LatAm) |
|---|---|
| cajero automático | ATM, cajero |
| billete (de banco) | billete (idéntico), plata (coloquial para dinero en general) |
| moneda | idéntico |
| factura | boleta, ticket (ticket también en España, factura para las formales) |
| descuento | rebaja, oferta (oferta válido en España) |
| comprar en oferta | estar de rebajas / en promoción |

---

## Neologismos aceptados por la RAE

| Forma española | Nota |
|---|---|
| tuit / tuitear / tuitero | Formas hispanizadas de tweet/tweet/tweeter. En el DLE. |
| selfi | Hispanización de selfie. Preferida por RAE/Fundéu. |
| internet | Minúscula desde 2016 (antes «Internet»). |
| wifi | Minúscula. |
| podcast | Aceptado sin cambio formal. Plural: podcasts. |
| emoji | Aceptado. Plural: emojis. |
| hackear / hacker | En el DLE. |
| wasapear | Aceptado coloquialmente. |
| blog / bloguero | En el DLE. |
| chat / chatear | En el DLE. |
| influencer | Fundéu propone «influidor/a» pero influencer está muy extendido. |

---

## Anglicismos: aceptados vs. rechazados

### Aceptados (RAE o Fundéu)
| Anglicismo | Nota |
|---|---|
| email | Junto a «correo electrónico». Ambos correctos. |
| online / en línea | Ambos válidos. |
| software / hardware | Sin alternativa española establecida. |
| marketing / mercadotecnia | Ambos válidos; mercadotecnia preferida en contextos formales. |
| hobby / afición | Ambos; afición preferida. |
| show / espectáculo | Show muy integrado en el coloquial. |
| test | Aceptado. |
| récord | Hispanizado con tilde y sin «d» final en español. |

### Rechazados o con alternativa preferida
| Anglicismo | Alternativa española |
|---|---|
| chequear | comprobar, verificar, revisar |
| setear | configurar, ajustar |
| linkear | enlazar, vincular |
| printear | imprimir |
| resetear | reiniciar |
| deletear | eliminar, borrar |
| forwardear | reenviar |
| upgradar | actualizar, mejorar |
| googlear | buscar en Google / buscar en internet |
| implementar | aplicar, llevar a cabo, poner en marcha (según contexto) |
| tener una reunión | celebrar / mantener / convocar una reunión |
| hacer sentido | tener sentido |
| en base a | sobre la base de, basándose en |
| bajo mi punto de vista | desde mi punto de vista, a mi juicio |
