# Regionalismos de España — Variantes válidas

> Estas variantes son correctas dentro de la norma española. No se marcan como
> errores; se reconocen y contextualizan.

---

## Español de Canarias

**Rasgos válidos específicos:**
- **Ustedes** como 2.ª persona plural informal (en lugar de «vosotros»):
  *«Ustedes saben bien lo que hay que hacer»* — CORRECTO en Canarias, no es error.
- **Guagua** para autobús: léxico canario plenamente válido en España.
- **Papa** para patata: uso compartido con LatAm pero legítimo en Canarias.
- Seseo (pronunciación s por z/c ante e,i): rasgo fonético, no afecta a la escritura.

**Nota:** No corregir *«ustedes»* por *«vosotros»* en textos canarios. Sí usar
*«vosotros»* en el resto de España cuando Claude escribe.

---

## Español de Andalucía

**Rasgos fonéticos (no afectan la escritura):**
- Seseo (Sevilla, Málaga, Almería): pronuncian /s/ donde otros dicen /θ/
- Ceceo (algunas zonas): pronuncian /θ/ donde otros dicen /s/
- Aspiración de /s/ final: rasgos orales, no escritos

**Léxico andaluz válido:**
- *Curro* (trabajo coloquial): *«Mañana tengo curro»*
- *Majo/maja* (simpático/agradable): *«Es muy maja»*
- *Chaval/chavala* (joven): uso extendido a toda España

**Escritura:** Las normas ortográficas son las mismas en toda España.
Los rasgos fonéticos no se reflejan en la escritura normativa.

---

## Español de Madrid — Léxico coloquial estándar

El siguiente léxico coloquial es propio del español de Madrid y está
plenamente integrado en el español estándar peninsular informal:

| Término | Significado | Ejemplo |
|---|---|---|
| tío / tía | amigo/a, apelativo coloquial | *Tío, ¿has visto eso?* |
| guay | genial, estupendo | *¡Qué guay ha quedado!* |
| mola / molar | gustar, ser chulo | *Este sitio mola mucho.* |
| flipar | alucinar, sorprenderse | *Me flipó la película.* |
| currar | trabajar | *Hoy curro hasta tarde.* |
| cole | colegio | *Los niños están en el cole.* |
| boli | bolígrafo | *¿Me prestas un boli?* |
| peli | película | *¿Vemos una peli?* |
| profe | profesor/a | *El profe no ha venido.* |
| caña | cerveza pequeña / esfuerzo | *Ponme una caña. / Hay que dar caña.* |
| cantidad | mucho (adv. coloquial) | *Me gusta cantidad.* |
| mogollón | mucho, en gran cantidad | *Hay mogollón de gente.* |
| tronco | amigo (más juvenil que tío) | *¿Qué pasa, tronco?* |
| chaval/chavala | chico/a joven | *Los chavales de hoy en día...* |

**Uso:** estos términos son correctos en registro coloquial. En registro
formal o académico, sustituir por el equivalente estándar.

---

## Español de otras regiones

**Cataluña, País Vasco, Galicia** (hablantes de español como L2 o bilingües):
Pueden aparecer interferencias del catalán, euskera o gallego en la sintaxis
o el léxico. Señalar con respeto cuando sea un error normativo, no un
rasgo regional legítimo.

Ejemplo de interferencia catalán-español:
*«Subir arriba»* (pleonasmo por influencia del catalán *«pujar amunt»*) →
señalar como redundancia, no como barbarismo.

---

## Principio general

La skill no corrige variantes regionales válidas del español de España.
Solo corrige lo que es incorrecto conforme a la norma RAE,
independientemente de la región de origen del texto.
