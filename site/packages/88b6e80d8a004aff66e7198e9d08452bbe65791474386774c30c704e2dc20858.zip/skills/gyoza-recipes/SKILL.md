---
name: gyoza-recipes
description: Create gyoza recipes (llms.txt files) that describe a website's structure for the gyoza browser AI copilot. Use when the user wants to create, write, or generate a recipe, llms.txt, site manifest, or website description for gyoza. Also use when the user asks how to make their website work with gyoza or wants to describe their site's routes, UI elements, and pages for an AI copilot.
version: '1.0.0'
---

# Gyoza Recipes

Recipes are Markdown files in llms.txt format that describe a website's structure to the gyoza AI browser copilot. They act as a sitemap for the AI -- telling it what pages exist, what interactive elements are on each page, and what each page does.

When gyoza has a recipe for a site, it can navigate directly to any page, click the right buttons using stable CSS selectors, fill forms, call APIs, and complete tasks reliably -- even on non-English websites.

## Recipe Format

Every recipe follows this structure:

```markdown
# Site Name

> domain: example.com | prefix: /optional-prefix

Short description of what the site does.

## Routes

- [Page Name](/path): Description of the page
- [Another Page](/other): What this page is for

## UI Elements

- `#element-id` button "Submit Order" on /checkout
- `a[href='/settings']` link "Settings" on /dashboard
- `#email` input "Email address" on /signup

## API Endpoints

- POST /api/orders: Create a new order
- GET /api/products: List all products
- DELETE /api/cart/:id: Remove item from cart

## Page Descriptions

- /dashboard: Main dashboard showing account overview, recent activity, and quick actions.
- /settings: User settings page with profile, notifications, and billing sections.
```

## Section Reference

### Header (required)

```markdown
# Site Name
> domain: example.com | prefix: /app
Description of the site.
```

- `domain`: The website's domain (no protocol, no trailing slash)
- `prefix`: Optional URL prefix if the app lives under a subpath (e.g., `/app`, `/demos/ginko`)
- Description: 1-2 sentences explaining what the site does

### Routes (required)

List every navigable page the AI might need to visit:

```markdown
## Routes
- [Page Name](/path): What this page is for
```

- Use the display name users see (e.g., "Account Overview", not "account-page")
- For non-English UIs, include both the original text and English translation: `[ホーム (Home)](/)`
- Include route parameters where applicable: `/product/:id`

### UI Elements (required)

List interactive elements the AI should know about:

```markdown
## UI Elements
- `css-selector` type "label" on /route
```

**Element types**: `button`, `link`, `input`, `form`, `select`, `toggle`

**CSS selector preference** (most to least stable):
1. `#id` -- best, unique and rarely changes
2. `[data-testid="name"]` -- great if the site uses test attributes
3. `a[href='/path']` -- good for navigation links
4. `.specific-class` -- OK if the class is semantic, not generated
5. `form button[type='submit']` -- acceptable compound selectors
6. `div > div > span:nth-child(3)` -- AVOID, fragile and breaks on layout changes

**For non-English labels**, include both original and translation:
```markdown
- `#submit` button "注文を確定 (Confirm Order)" on /checkout
```

### API Endpoints (optional)

List endpoints the AI can call via fetch actions:

```markdown
## API Endpoints
- METHOD /api/path: What it does
```

Include the HTTP method (GET, POST, PUT, PATCH, DELETE) and a brief description.

### Page Descriptions (required)

Rich context for each page -- describe what the user sees:

```markdown
## Page Descriptions
- /path: What this page shows and what the user can do here.
```

Write from the user's perspective: "Shows a grid of products with prices" not "Renders ProductGrid component with props".

## Best Practices

1. **Test selectors on the live site** -- run `document.querySelector('your-selector')` in browser devtools to verify each selector works
2. **Prefer IDs over classes** -- `#checkout-btn` is far more stable than `.btn-primary`
3. **Include ALL interactive elements** -- every button, link, input, and form the user might ask the AI to interact with
4. **Keep descriptions concise** -- 1-2 sentences per page, focus on what the user sees and can do
5. **Update when the site changes** -- a stale recipe with broken selectors is worse than no recipe
6. **Test with gyoza** -- import the recipe and try common tasks to verify it works end-to-end

## Validation Rules

Recipes are validated before publishing:

- Must start with an H1 heading (`# Site Name`)
- Max size: 100KB, max lines: 2000
- No executable code: `eval()`, `<script>`, `javascript:`, `Function()`, etc.
- No obfuscation: Base64 blobs, hex/unicode escapes, `String.fromCharCode`
- No dangerous URLs: webhook.site, ngrok, Discord webhooks
- Domain must be a valid public FQDN (no localhost in production)

## Action Types

When gyoza uses a recipe, it translates user requests into these action types:

| Action | Purpose | Key Fields |
|--------|---------|------------|
| `navigate` | Go to a URL | `target` (URL path) |
| `click` | Click an element | `selector` (CSS selector) |
| `execute-js` | Run JavaScript on page | `code` (JS code) |
| `show-message` | Display text to user | `message` (text) |
| `highlight-ui` | Highlight an element | `selector` (CSS selector) |
| `fetch` | Call an API endpoint | `url`, `method` |
| `clarify` | Ask user for clarification | `message`, `options[]` |

The AI uses the recipe's selectors and routes to generate accurate actions. Without a recipe, it falls back to reading the live DOM -- slower and less reliable.

## Examples

See the `examples/` directory for complete, production-ready recipes:

- **ginko-bank.txt** -- Japanese banking app with non-English UI, form inputs, and navigation
- **freshcart.txt** -- E-commerce grocery store with product categories, cart, and API endpoints
- **gyozai-website.txt** -- The gyoz.ai website itself with docs, demos, and auth flows

Each example demonstrates different patterns: non-English labels, API endpoints, dynamic routes, form handling, and multi-page workflows.
