# CSS Selector Guide for Gyoza Recipes

## Selector Stability Ranking

From most to least stable:

### 1. ID selectors (best)
```
#submit-btn
#email-input
#main-nav
```
IDs are unique per page and rarely change. Always prefer these.

### 2. Data attributes
```
[data-testid="checkout-button"]
[data-action="submit-form"]
```
Great if the site uses `data-testid` or similar attributes. These are explicitly meant to be stable selectors.

### 3. Attribute selectors (links)
```
a[href='/settings']
a[href*='/category/']
button[type='submit']
input[name='email']
```
Good for navigation links and form elements. Use `*=` for partial matching when paths have dynamic segments.

### 4. Semantic class selectors
```
.checkout-button
.nav-link
.product-card
```
OK if the class name is semantic (describes purpose). Avoid utility classes like `.mt-4`, `.flex`, `.text-lg`.

### 5. Compound selectors
```
form#checkout button[type='submit']
.product-list .product-card:first-child
nav a[href='/about']
```
Acceptable when simpler selectors aren't unique. Keep them as short as possible.

### 6. Positional selectors (avoid)
```
div > div > span:nth-child(3)
.container > :last-child > button
```
These break whenever the layout changes. Never use unless absolutely no alternative exists.

## Common Patterns

### Forms
```markdown
- `#email` input "Email address" on /signup
- `#password` input "Password" on /signup
- `#signup-form button[type='submit']` button "Create Account" on /signup
```

### Navigation
```markdown
- `a[href='/dashboard']` link "Dashboard" in sidebar on /
- `a[href='/settings']` link "Settings" in sidebar on /
- `nav a[href='/about']` link "About" in header on /
```

### Dynamic content
```markdown
- `.product-card a` link "Product card" on /products (multiple)
- `#load-more` button "Load More" on /products
- `#search-input` input "Search" on /products
```

### Modals and dialogs
```markdown
- `[data-dialog='confirm'] button.confirm` button "Confirm" in confirmation dialog
- `.modal-close` button "Close" in modal overlay
```

## Testing Selectors

Before adding a selector to a recipe, verify it in the browser:

```javascript
// Check if selector matches exactly one element
document.querySelectorAll('#submit-btn').length === 1

// Check if the element is the right one
document.querySelector('#submit-btn').textContent

// Check if element is visible and clickable
const el = document.querySelector('#submit-btn');
el.offsetParent !== null && !el.disabled
```

## Non-English UI Labels

Always include both the original text and an English translation:

```markdown
- `#submit` button "注文を確定 (Confirm Order)" on /checkout
- `a[href='/account']` link "マイページ (My Page)" on /
```

This helps the AI understand intent even when the UI language doesn't match the user's language.
