# gyoza-recipes

Claude Code plugin for creating [gyoza](https://gyoz.ai) recipes -- llms.txt files that describe a website's structure for the gyoza AI browser copilot.

## What are gyoza recipes?

Recipes are Markdown files that act as a sitemap for the AI. They tell the gyoza browser extension what pages exist on a website, what interactive elements are on each page (with CSS selectors), and what each page does. With a recipe, the AI can navigate, click, fill forms, and complete tasks reliably.

## Installation

```bash
claude plugin add gyoz-ai/gyoza-recipes
```

## Usage

### Skill

The `gyoza-recipes` skill activates automatically when you ask Claude to create a recipe, llms.txt, or website description for gyoza. Just ask naturally:

- "Create a gyoza recipe for my website at example.com"
- "Write an llms.txt file for my React dashboard"
- "Help me describe my site's structure for the gyoza browser copilot"

### Command

```
/create-recipe https://example.com
/create-recipe "my e-commerce store with products, cart, and checkout"
```

## What's included

- **Skill**: Complete recipe format reference, validation rules, best practices, and action types
- **Command**: `/create-recipe` -- guided recipe creation from a URL or description
- **Examples**: Three production-ready recipes demonstrating different patterns:
  - `ginko-bank.txt` -- Japanese banking app (non-English UI with translations)
  - `freshcart.txt` -- Grocery store (e-commerce with API endpoints)
  - `gyozai-website.txt` -- The gyoz.ai website (marketing + docs + auth)
- **References**: CSS selector stability guide

## Links

- [gyoz.ai](https://gyoz.ai) -- gyoza website
- [Recipe docs](https://gyoz.ai/docs/recipes) -- Full recipe writing guide
- [Actions reference](https://gyoz.ai/docs/actions) -- All action types the AI can perform
- [Extension](https://gyoz.ai/docs/extension) -- Browser extension setup guide
