---
description: Create a gyoza recipe (llms.txt) for a website
argument-hint:
- website-url-or-description
---

Create a gyoza recipe for the website described by $ARGUMENTS.

Use the gyoza-recipes skill to understand the recipe format, then:

1. If a URL was provided, fetch the site to understand its structure (routes, pages, interactive elements)
2. If a description was provided, ask clarifying questions about the site's pages and features
3. Write a complete recipe in llms.txt format following the exact structure from the skill
4. Include all sections: header with domain, Routes, UI Elements, Page Descriptions, and API Endpoints if applicable
5. Use stable CSS selectors (prefer IDs, data attributes, and href selectors over positional selectors)
6. For non-English UIs, include both original text and English translations in parentheses
7. Save the recipe as a .txt file

Refer to the examples in the skill's examples/ directory for reference:
- ginko-bank.txt for non-English UI patterns
- freshcart.txt for e-commerce with API endpoints
- gyozai-website.txt for a multi-section marketing/docs site
