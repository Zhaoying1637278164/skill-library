# Support

GitHub Issues: https://github.com/blackrock/advisor-center-agent-skills/issues

1. Response Time:

Project maintainers will make efforts to respond to issues and inquiries within 20 business days.
Priority levels for responses:

Critical: 10 business days
Normal: 20 business days

2. Bug Fixes:

Critical bugs will be addressed within 10 business days and fixed within 20 business days.
Other bugs will be addressed and fixed based on their severity and impact.

3. Feature Requests:

Feature requests will be considered by the maintainers and evaluated based on project goals and priorities.
Contributors are encouraged to submit well-documented feature requests through GitHub Issues.

4. Code Contributions:

External contributors are welcome to submit pull requests.
Maintainers will review and merge contributions based on adherence to project coding standards and relevance to project goals.
Contributors are expected to follow the project's contribution guidelines.

5. Maintenance and Updates:

Regular maintenance releases and updates will be provided as deemed necessary by the maintainers.
