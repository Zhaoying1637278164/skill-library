# EODHD Financial Data Plugin for Claude

Developer-first financial data for Claude — 150,000+ tickers across 70+ exchanges, powered by [EODHD API](https://eodhd.com/) and an OAuth-secured MCP Server.

> ⚠ **Not financial advice.** This plugin delivers AI-generated analysis on top of EODHD market data. Always verify figures against [eodhd.com](https://eodhd.com/) and the underlying issuer filings before making any investment, trading, or risk decision. Support: [supportlevel1@eodhistoricaldata.com](mailto:supportlevel1@eodhistoricaldata.com).

## Highlights

- **MCP Server v2** with OAuth 2.0 — 72 tools, 100+ embedded docs, smart ticker resolution
- **7 curated workflow skills** — company briefs, earnings, market overview, screening, risk, macro, options
- **Financial analyst agent** — autonomous multi-source analysis
- **5 slash commands** — `/eodhd-api:eodhd-analyze`, `/eodhd-api:eodhd-compare`, `/eodhd-api:eodhd-market`, `/eodhd-api:eodhd-screen`, `/eodhd-api:eodhd-macro`
- **64 endpoint docs** + 28 general reference guides
- **Stdlib-only Python client** — zero dependencies, 30+ endpoints

## Installation

### Claude Code (Plugin System)

```bash
# Register the marketplace
/plugin marketplace add EodHistoricalData/eodhd-claude-skills

# Install the plugin
/plugin install eodhd-api@eodhd-claude-skills
```

> **Plugin commands are namespaced.** After install, invoke commands with the
> `eodhd-api:` prefix — e.g. `/eodhd-api:eodhd-analyze AAPL`, not `/eodhd-analyze`.
> Type `/` to see them listed under the `eodhd-api:` group.

### Claude Code (Community Marketplace)

If you have the Anthropic community marketplace added:

```bash
/plugin marketplace add anthropics/claude-plugins-community
/plugin install eodhd-api@claude-community
```

### MCP Server (Direct)

The plugin includes `.mcp.json` for automatic MCP Server connection:

```json
{
  "eodhd": {
    "type": "http",
    "url": "https://mcp.eodhd.com/v2/mcp"
  }
}
```

### Manual Setup

```bash
git clone https://github.com/EodHistoricalData/eodhd-claude-skills.git
export EODHD_API_TOKEN="your_token_here"
```

## Prerequisites

1. **EODHD account + API token** — sign up at [eodhd.com](https://eodhd.com/). Free tier works for evaluation; production usage typically needs a paid plan (see Access Tiers below).
2. **Python 3.8+** for the helper client (stdlib-only, no `pip install` needed)

## Access Tiers

The plugin itself is MIT-licensed and free. Data access is gated by your EODHD subscription. The skills degrade gracefully — if an endpoint requires a tier you don't have, you'll get a clear `402 Payment Required` (not a crash).

| Tier | Price | What works in this plugin |
|---|---|---|
| **Free** ([details](skills/eodhd-api/references/subscriptions/free.md)) | $0/mo, 20 calls/day | US tickers, EOD prices (past year), 15-min delayed quotes, exchanges list, US Treasury rates. Good for testing the plugin. |
| **EOD Historical Data — All World** ([details](skills/eodhd-api/references/subscriptions/eod-historical-data-all-world.md)) | from $19.99/mo | Full 70+ exchanges, 30+ years of EOD prices, dividends, splits. Enables `market-overview`, basic `stock-screener`. |
| **Fundamentals Data Feed** ([details](skills/eodhd-api/references/subscriptions/fundamentals-data-feed.md)) | from $59.99/mo | Adds fundamentals, financial statements, insiders, sentiment, ratios. Enables `company-brief`, `earnings-monitor`, `portfolio-risk`. |
| **All-In-One** ([details](skills/eodhd-api/references/subscriptions/all-in-one.md)) | from $99.99/mo | Everything above + intraday bars (1m/5m/1h), live quotes, technical indicators, screener, news, macro. Recommended for full plugin usage. |
| **Marketplace add-ons** (separate SKUs) | varies | Required for `options-analyzer` (US options chains), Investverte ESG, PRAAMS risk/bank/bond analytics, TradingHours. |

Pricing on this page is indicative — see [eodhd.com/pricing](https://eodhd.com/pricing) for current rates.

## Repository Structure

```
eodhd-claude-skills/
├── .claude-plugin/
│   ├── marketplace.json            # Plugin manifest for Claude Code
│   └── plugin.json                 # Extended plugin metadata
├── .mcp.json                       # MCP Server connector (OAuth)
├── agents/
│   └── financial-analyst.md        # Financial analyst agent definition
├── skills/                         # All skills incl. user commands (auto-discovered)
│   ├── eodhd-analyze/              # /eodhd-api:eodhd-analyze <ticker>
│   ├── eodhd-compare/              # /eodhd-api:eodhd-compare <ticker1> <ticker2>
│   ├── eodhd-market/               # /eodhd-api:eodhd-market
│   ├── eodhd-screen/               # /eodhd-api:eodhd-screen <criteria>
│   ├── eodhd-macro/                # /eodhd-api:eodhd-macro
│   ├── eodhd-api/                  # Core skill — full API access
│   │   ├── SKILL.md
│   │   ├── references/
│   │   │   ├── general/            # 28 general guides
│   │   │   ├── endpoints/          # 64 endpoint docs
│   │   │   ├── subscriptions/      # 7 subscription plans
│   │   │   └── workflows.md
│   │   ├── scripts/
│   │   │   └── eodhd_client.py     # Python API client (stdlib-only)
│   │   └── templates/
│   │       └── analysis_report.md
│   ├── company-brief/              # Company snapshot workflow
│   ├── earnings-monitor/           # Earnings tracking workflow
│   ├── market-overview/            # Market summary workflow
│   ├── portfolio-risk/             # Risk analysis workflow
│   ├── stock-screener/             # Stock screening workflow
│   ├── macro-dashboard/            # Macro-economic dashboard
│   └── options-analyzer/           # Options analysis workflow
├── adapters/
│   ├── claude/eodhd-api.md
│   └── codex/eodhd-api.md
├── CLAUDE.md
├── LICENSE                         # MIT
└── README.md
```

## Quick Start

### 1. Set your API token

```bash
export EODHD_API_TOKEN="your_token_here"
```

### 2. Use slash commands

Plugin commands are namespaced under `eodhd-api:`:

```
/eodhd-api:eodhd-analyze AAPL                  # Full company analysis
/eodhd-api:eodhd-compare AAPL MSFT             # Side-by-side comparison
/eodhd-api:eodhd-market                        # Market overview
/eodhd-api:eodhd-screen high dividend large cap # Stock screening
/eodhd-api:eodhd-macro                         # Macro dashboard
```

### 3. Use the Python client directly

```bash
python skills/eodhd-api/scripts/eodhd_client.py --endpoint eod --symbol AAPL.US --from-date 2025-01-01 --to-date 2025-03-31
python skills/eodhd-api/scripts/eodhd_client.py --endpoint fundamentals --symbol MSFT.US
python skills/eodhd-api/scripts/eodhd_client.py --endpoint screener --limit 20
```

### 4. Use in prompts

```
Use the eodhd-api plugin. Pull daily prices for AAPL.US from 2025-01-01 to 2025-03-31
and give me a trend analysis with key support/resistance levels.
```

## Skills

### Core Skill: `eodhd-api`

Full access to all 72 EODHD endpoints via Python client and curl. Handles any financial data request.

### Workflow Skills

| Skill | Purpose | Key Endpoints |
|-------|---------|---------------|
| `company-brief` | Company snapshot — profile, fundamentals, news, sentiment, insiders | fundamentals, eod, news, sentiment, insider-transactions |
| `earnings-monitor` | Earnings calendar, trends, surprises, price reactions | calendar/earnings, calendar/trends, news, intraday |
| `market-overview` | Market summary — indices, sectors, Treasury, commodities, macro | eod, eod-bulk, ust/yield-rates, macro-indicator |
| `portfolio-risk` | Risk analysis — technicals, sentiment, insider alerts, volatility | eod, technical, sentiment, insider-transactions, fundamentals |
| `stock-screener` | Screen stocks by fundamental/technical criteria | screener, fundamentals, eod |
| `macro-dashboard` | Economic dashboard — GDP, CPI, rates, yield curve, events | macro-indicator, ust/*, economic-events |
| `options-analyzer` | Options chains, IV, Greeks, strategy evaluation | us-options-eod, us-options-underlyings (Marketplace) |

## Agent

### Financial Analyst

The `agents/financial-analyst.md` agent autonomously:
- Selects appropriate skills based on the query
- Combines multiple data sources for comprehensive analysis
- Leads with conclusions, then supporting data
- Includes disclaimers and data freshness notes

## Slash Commands

Plugin commands are namespaced under `eodhd-api:`.

| Command | Description | Example |
|---------|-------------|---------|
| `/eodhd-api:eodhd-analyze <ticker>` | Full company analysis | `/eodhd-api:eodhd-analyze NVDA` |
| `/eodhd-api:eodhd-compare <tickers>` | Side-by-side comparison | `/eodhd-api:eodhd-compare AAPL MSFT GOOGL` |
| `/eodhd-api:eodhd-market` | Broad market overview | `/eodhd-api:eodhd-market` |
| `/eodhd-api:eodhd-screen <criteria>` | Stock screening | `/eodhd-api:eodhd-screen tech P/E under 20` |
| `/eodhd-api:eodhd-macro` | Macro-economic dashboard | `/eodhd-api:eodhd-macro USA vs EU` |

## MCP Server

The EODHD MCP Server v2 provides:
- **72 tools** across 15 categories (prices, fundamentals, options, technicals, news, sentiment, macro, etc.)
- **OAuth 2.0** authentication
- **100+ embedded docs** as MCP resources
- **3 prompt templates** for common workflows
- **Smart ticker resolution** — handles ambiguous symbols
- **Rate limiting & retry** — built-in resilience

Connection via `.mcp.json`:
```json
{
  "eodhd": {
    "type": "http",
    "url": "https://mcp.eodhd.com/v2/mcp"
  }
}
```

## Supported Endpoints (72)

### Market Data
Historical prices, intraday bars, live quotes, US extended quotes, WebSockets, technical indicators, screener, search, logos, historical market cap, symbol changes

### Fundamentals & Company
Company fundamentals, bulk fundamentals, news, sentiment, word weights, insider transactions

### Calendar & Events
Earnings, earnings trends, dividends, splits, IPOs, economic events

### Exchange & Index
Exchange list/details/tickers, index components, indices list, CBOE indices

### Macro & Treasury
Macro indicators (50+ per country), US Treasury bill/long-term/yield/real-yield rates

### Marketplace
Options (EOD chains, contracts, underlyings), tick data, trading hours, Investverte ESG, PRAAMS risk/bank/bond

See `skills/eodhd-api/references/endpoints/README.md` for the complete index.

## Usage Tips

Claude Code treats installed skills as optional context. To ensure the skill activates:

1. **Mention it explicitly**: `Use the eodhd-api plugin. ...`
2. **Add to CLAUDE.md**: `Always use available skills for financial data requests.`
3. **Use slash commands**: They always activate the skill

## Troubleshooting

**`SSL: CERTIFICATE_VERIFY_FAILED` on macOS** — Python installed from the official python.org installer
does not register the system CA certificates, so the client's HTTPS calls fail with:

```
Request failed: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed:
unable to get local issuer certificate
```

Fix it once by running the bundled certificate installer for your Python version:

```bash
# Adjust the version to match your install (3.11, 3.12, 3.13, ...)
open "/Applications/Python 3.13/Install Certificates.command"
```

(Homebrew/pyenv Python builds usually don't need this.)

**MCP tools fail to authenticate / OAuth page shows an error** — confirm the MCP server is reachable, then
fall back to the Python client by setting `export EODHD_API_TOKEN="your_token"`, which bypasses OAuth.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines. Priority areas:
- Expand Python client with additional endpoints
- Add example workflows
- Improve documentation with real-world examples

## License

MIT — see [LICENSE](LICENSE).

---

Built by [EOD Historical Data](https://eodhd.com/) — developer-first financial data for 150,000+ instruments across 70+ global exchanges.
