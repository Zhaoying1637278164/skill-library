"""
Tests for the manual-install hook wiring (hooks/setup_settings.py).

The manual-install path (settings.json) must wire the same hooks as the plugin
path (.claude-plugin/plugin.json). This guards against the two drifting — in
particular the access guard (PreToolUse + PostToolUse) and trust ledger
(SessionStart), which the installer historically omitted.

Runs under pytest, or standalone:  python tests/test_setup_settings.py
"""

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "hooks"))

import setup_settings as S  # noqa: E402

HOOK_SCRIPT = Path(__file__).resolve().parent.parent / "hooks" / "claude_hook.py"


def _install(tmp_path) -> dict:
    settings = tmp_path / "settings.json"
    S.merge(settings, HOOK_SCRIPT)
    return json.loads(settings.read_text(encoding="utf-8"))


def _scripts_on(data: dict, event: str) -> set[str]:
    """Set of Clawness script basenames wired under an event (across all groups)."""
    out = set()
    for group in data.get("hooks", {}).get(event, []):
        for h in group.get("hooks", []):
            for name in S.CLAW_HOOK_SCRIPTS:
                if name in h.get("command", ""):
                    out.add(name)
    return out


def test_access_guard_wired_on_pre_and_post_tool_use(tmp_path):
    data = _install(tmp_path)
    assert "access_guard.py" in _scripts_on(data, "PreToolUse")
    # PostToolUse is required for the two-phase ledger's confirm step — without
    # it a declined ask could never re-ask.
    assert "access_guard.py" in _scripts_on(data, "PostToolUse")


def test_access_guard_matchers_match(tmp_path):
    data = _install(tmp_path)
    expected = "Bash|Write|Edit|MultiEdit|NotebookEdit|Read"
    for event in ("PreToolUse", "PostToolUse"):
        matchers = [
            g.get("matcher")
            for g in data["hooks"][event]
            if any("access_guard.py" in h.get("command", "") for h in g.get("hooks", []))
        ]
        assert matchers == [expected], f"{event}: {matchers}"


def test_trust_ledger_wired_on_session_start(tmp_path):
    data = _install(tmp_path)
    assert "trust_ledger.py" in _scripts_on(data, "SessionStart")


def test_all_expected_hooks_present(tmp_path):
    data = _install(tmp_path)
    assert _scripts_on(data, "UserPromptSubmit") == {"claude_hook.py"}
    assert _scripts_on(data, "SessionStart") == {
        "git_check.py", "memory_init.py", "handoff_check.py", "stack_detect.py",
        "trust_ledger.py", "changelog_check.py", "claude_md_check.py",
    }
    assert "compress_output.py" in _scripts_on(data, "PostToolUse")
    assert "plan_gate.py" in _scripts_on(data, "PreToolUse")


def test_install_is_idempotent(tmp_path):
    settings = tmp_path / "settings.json"
    S.merge(settings, HOOK_SCRIPT)
    first = json.loads(settings.read_text(encoding="utf-8"))
    second_msg = S.merge(settings, HOOK_SCRIPT)
    second = json.loads(settings.read_text(encoding="utf-8"))
    assert first == second  # no duplication on re-run
    assert "already configured" in second_msg


def test_uninstall_removes_new_hooks(tmp_path):
    settings = tmp_path / "settings.json"
    S.merge(settings, HOOK_SCRIPT)
    S.unmerge(settings)
    data = json.loads(settings.read_text(encoding="utf-8"))
    # Every Clawness hook is gone; the hooks section is left empty (not dangling).
    for event in ("PreToolUse", "PostToolUse", "SessionStart", "UserPromptSubmit"):
        assert _scripts_on(data, event) == set(), event


def test_matches_plugin_manifest(tmp_path):
    """The manual installer must wire the same hooks as the plugin manifest.
    ensure_deps.py is the one intentional exception (plugin-only — a manual
    install runs a real `pip install`, so the deps are already present)."""
    data = _install(tmp_path)
    manifest = json.loads(
        (Path(__file__).resolve().parent.parent / ".claude-plugin" / "plugin.json")
        .read_text(encoding="utf-8")
    )
    plugin_hooks = manifest["hooks"]

    def plugin_scripts_on(event: str) -> set[str]:
        out = set()
        for group in plugin_hooks.get(event, []):
            for h in group.get("hooks", []):
                for name in S.CLAW_HOOK_SCRIPTS:
                    if name in h.get("command", ""):
                        out.add(name)
        return out

    for event in ("UserPromptSubmit", "PreToolUse", "PostToolUse", "SessionStart"):
        plugin_set = plugin_scripts_on(event) - {"ensure_deps.py"}
        installer_set = _scripts_on(data, event)
        assert plugin_set == installer_set, (
            f"{event}: plugin has {plugin_set}, installer has {installer_set}"
        )


def _wiring(hooks: dict) -> set:
    """Set of (event, script, matcher, timeout) tuples — the full shape of each
    wired hook, so a drift in a matcher or timeout (not just the script set) is a
    test failure. Command strings differ by install path (plugin-root vs absolute)
    so we key on the script basename, not the command."""
    out = set()
    for event, groups in hooks.items():
        for group in groups:
            matcher = group.get("matcher")
            for h in group.get("hooks", []):
                cmd = h.get("command", "")
                for name in S.CLAW_HOOK_SCRIPTS:
                    if name in cmd:
                        out.add((event, name, matcher, h.get("timeout")))
    return out


def test_matchers_and_timeouts_match_plugin(tmp_path):
    # Beyond the script SET: every wired hook must agree on matcher and timeout
    # with the plugin manifest. ensure_deps.py is plugin-only (async pip install).
    data = _install(tmp_path)
    manifest = json.loads(
        (Path(__file__).resolve().parent.parent / ".claude-plugin" / "plugin.json")
        .read_text(encoding="utf-8")
    )
    plugin = {t for t in _wiring(manifest["hooks"]) if t[1] != "ensure_deps.py"}
    installer = _wiring(data["hooks"])
    assert plugin == installer, (
        f"wiring drift:\n  plugin-only: {plugin - installer}\n  installer-only: {installer - plugin}"
    )


def test_partial_state_self_heals_missing_post_companion(tmp_path):
    # A settings file with the access-guard PRE hook but no POST companion (hand
    # edited, or a partially-applied older write) must be REPAIRED on re-run —
    # otherwise a declined ask goes silent for the session. Same for the plan gate.
    settings = tmp_path / "settings.json"
    S.merge(settings, HOOK_SCRIPT)
    data = json.loads(settings.read_text(encoding="utf-8"))
    # Surgically drop the PostToolUse access-guard + plan-gate companions.
    data["hooks"]["PostToolUse"] = [
        g for g in data["hooks"]["PostToolUse"]
        if not any(
            ("access_guard.py" in h.get("command", "") or "plan_gate.py" in h.get("command", ""))
            for h in g.get("hooks", [])
        )
    ]
    settings.write_text(json.dumps(data, indent=2), encoding="utf-8")
    assert "access_guard.py" not in _scripts_on(data, "PostToolUse")
    # Re-run must add the missing companions back.
    S.merge(settings, HOOK_SCRIPT)
    healed = json.loads(settings.read_text(encoding="utf-8"))
    assert "access_guard.py" in _scripts_on(healed, "PostToolUse")
    assert "plan_gate.py" in _scripts_on(healed, "PostToolUse")


# ---------------------------------------------------------------------------
# No-interpreter fall-through
#
# With no Python on PATH every `command -v` in the picker fails, the `&&`
# short-circuits, and the loop's status is the last failed test — exit 1. Claude
# Code treats a non-zero, non-2 exit as a non-blocking error and shows a hook
# error notice plus the first line of stderr, which is empty here: an
# unexplained error on every session start, prompt and gated tool call, with the
# plan gate and access guard silently inert and no bootstrap.log to diagnose
# from (ensure_deps can't run either). These pin the trailing `exit 0` and the
# one notice that explains it.
# ---------------------------------------------------------------------------

PLUGIN_JSON = Path(__file__).resolve().parent.parent / ".claude-plugin" / "plugin.json"


def _plugin_commands() -> list:
    data = json.loads(PLUGIN_JSON.read_text(encoding="utf-8"))
    return [
        h["command"]
        for groups in data["hooks"].values()
        for group in groups
        for h in group["hooks"]
    ]


def test_every_plugin_hook_command_exits_zero(tmp_path):
    for cmd in _plugin_commands():
        assert cmd.endswith("; exit 0"), cmd


def test_exactly_one_plugin_hook_carries_the_no_python_notice(tmp_path):
    # Eight SessionStart registrations all echoing would repeat it eight times.
    carrying = [c for c in _plugin_commands() if S.NO_PYTHON_NOTICE in c]
    assert len(carrying) == 1, f"{len(carrying)} commands carry the notice"
    assert "git_check.py" in carrying[0]


def test_installer_matches_the_plugin_fall_through(tmp_path):
    """Both install paths must degrade identically — the manual path is not the
    one people read the README for."""
    data = _install(tmp_path)
    commands = [
        h["command"]
        for groups in data["hooks"].values()
        for group in groups
        for h in group["hooks"]
        if _is_claw(h)
    ]
    assert commands, "no Clawness hooks wired"
    for cmd in commands:
        assert cmd.endswith("; exit 0"), cmd
    carrying = [c for c in commands if S.NO_PYTHON_NOTICE in c]
    assert len(carrying) == 1 and "git_check.py" in carrying[0]


def _is_claw(h: dict) -> bool:
    return any(name in h.get("command", "") for name in S.CLAW_HOOK_SCRIPTS)


def _sh():
    """The POSIX shell Claude Code would run a hook command through.

    On Windows that is Git Bash, and it must be preferred explicitly: the only
    `bash` on the Windows PATH is usually WSL's, which sees `/mnt/c/...` but
    resolves no `python`/`py` (no `.exe` suffix), so the picker legitimately
    falls through there and the test would measure the wrong shell.
    """
    import shutil
    if os.name == "nt":
        for p in (r"C:\Program Files\Git\bin\bash.exe",
                  r"C:\Program Files\Git\usr\bin\bash.exe"):
            if Path(p).exists():
                return p
    return shutil.which("sh") or shutil.which("bash")


def test_picker_fall_through_exits_zero_and_says_why(tmp_path):
    """The real plugin.json command, through a real shell, with nothing on PATH.

    `command -v` and `echo` are shell builtins, so an empty PATH removes every
    interpreter without breaking the test itself.
    """
    import subprocess
    sh = _sh()
    if not sh:
        import pytest
        pytest.skip("no POSIX shell available")
    cmd = next(c for c in _plugin_commands() if "git_check.py" in c)
    env = dict(os.environ, PATH="", CLAUDE_PLUGIN_ROOT=str(tmp_path))
    r = subprocess.run([sh, "-c", cmd], capture_output=True, text=True,
                       env=env, timeout=60)
    assert r.returncode == 0, f"rc={r.returncode} stderr={r.stderr!r}"
    assert "Python 3.10+ was not found" in r.stdout
    # SessionStart stdout becomes context, so this is what reaches the user.
    assert "plan gate and access guard are inactive" in r.stdout


def test_picker_still_runs_the_interpreter_when_one_exists(tmp_path):
    """The fall-through must not fire when Python IS present — `exec` replaces
    the shell, so nothing after `done` should run."""
    import subprocess
    sh = _sh()
    if not sh:
        import pytest
        pytest.skip("no POSIX shell available")
    probe = subprocess.run(
        [sh, "-c", 'for p in python3 python py; do command -v "$p" && exit 0; done; exit 1'],
        capture_output=True, text=True, timeout=60)
    if probe.returncode != 0:
        import pytest
        pytest.skip(f"no interpreter visible to {sh} — premise not met")
    script = tmp_path / "marker.py"
    script.write_text("print('MARKER-RAN')\n", encoding="utf-8")
    cmd = S.build_hook_entry(script, notice=True)["command"]
    r = subprocess.run([sh, "-c", cmd], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0, f"rc={r.returncode} stderr={r.stderr!r}"
    assert "MARKER-RAN" in r.stdout
    assert S.NO_PYTHON_NOTICE not in r.stdout


if __name__ == "__main__":
    import tempfile
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = 0
    for fn in fns:
        with tempfile.TemporaryDirectory() as d:
            fn(Path(d))
        passed += 1
        print(f"  ok  {fn.__name__}")
    print(f"\n{passed}/{len(fns)} tests passed")
