## Contents

- Accessing webhooks
- Create webhook endpoints
- Edit webhook endpoints
- Delete webhook endpoints
- Webhook events
- Webhook payload format
- See Also




Webhooks are HTTP callbacks that Daytona sends to your specified endpoints when specific events occur.
Think of them as "reverse API calls" - instead of your application asking Daytona for updates, Daytona
proactively notifies your application when something important happens.

Webhooks enable powerful automation and integration scenarios:

- **Real-time notifications**: get instant alerts when sandboxes are created, started, or stopped
- **Automated workflows**: trigger deployment pipelines when snapshots are created
- **Monitoring & analytics**: track usage patterns and resource utilization across organizations
- **Integration**: connect Daytona with existing tools like Slack, Discord, or custom applications
- **Audit & compliance**: maintain detailed logs of all important changes

Webhooks are available to all members of an organization. If you don't see **Webhooks** in [Daytona Dashboard ↗](https://app.daytona.io/dashboard), contact [support@daytona.io](mailto:support@daytona.io) to enable webhooks for your organization.

## Accessing webhooks

Daytona provides a webhook management interface to access and manage webhook endpoints.

1. Navigate to [Daytona Dashboard ↗](https://app.daytona.io/dashboard)
2. Click <Button>Webhooks</Button> in the sidebar

The webhooks management interface contains two tabs: [Endpoints](#endpoints) and [Messages](#messages).

### Endpoints

The endpoints tab lists all the webhook endpoints for the organization. Each endpoint has the following details:

- **Name**: the name of the webhook endpoint
- **URL**: the URL of the webhook endpoint
- **Status**: the status of the webhook endpoint
- **Created**: the timestamp when the webhook endpoint was created

Clicking on an endpoint opens the endpoint details page with additional endpoint configuration details: **name**, **URL**, **events**, **status**, **delivery statistics**, and **event history**.

### Messages

The messages tab lists all the webhook messages for the organization. Each message has the following details:

- **Message ID**: the ID of the webhook message
- **Event type**: the event type of the webhook message
- **Timestamp**: the timestamp when the webhook message was created

Clicking on a message opens the message details dialog with additional message details: **message ID**, **event type**, **timestamp**, **payload**, and **delivery attempts**.

Delivery attempts are shown in a separate table with the following columns:

- **Status**: the status of the delivery attempt
- **URL**: the URL of the delivery attempt
- **Timestamp**: the timestamp when the delivery attempt was created

Expanding a delivery attempt displays additional delivery attempt details: **status code**, **duration**, **trigger**, **endpoint ID**, and **response body**.

## Create webhook endpoints

Daytona provides a webhook management interface to create webhook endpoints.

1. Navigate to [Daytona Dashboard ↗](https://app.daytona.io/dashboard)
2. Click <Button>Webhooks</Button> in the sidebar
3. Click <Button>Add Endpoint</Button>
4. Configure your endpoint:

- **Endpoint name**: a name for the endpoint
- **Endpoint URL**: HTTPS endpoint where you want to receive events
- [Events](#webhook-events): select which events to subscribe to

5. Click <Button>Create</Button>

## Edit webhook endpoints

Daytona provides a webhook management interface to edit webhook endpoints.

1. Navigate to [Daytona Dashboard ↗](https://app.daytona.io/dashboard)
2. Click <Button>Webhooks</Button> in the sidebar
3. Select a webhook endpoint from the [Endpoints](#endpoints) tab
4. Click the three dots menu (**⋮**) and select <Button>Edit</Button>
5. Update the endpoint details
6. Click <Button>Save</Button>

## Delete webhook endpoints

Daytona provides a webhook management interface to delete webhook endpoints.

1. Navigate to [Daytona Dashboard ↗](https://app.daytona.io/dashboard)
2. Click <Button>Webhooks</Button> in the sidebar
3. Select a webhook endpoint from the [Endpoints](#endpoints) tab
4. Click the three dots menu (**⋮**) and select <Button>Delete</Button>
5. Confirm the deletion

## Webhook events

Daytona sends webhooks for lifecycle events across your infrastructure resources. You can subscribe to specific event types or receive all events and filter them in your application.

### Sandbox events

| Event Type                  | Description                    |
| --------------------------- | ------------------------------ |
| **`sandbox.created`**       | A new sandbox has been created |
| **`sandbox.state.updated`** | A sandbox's state has changed  |

### Snapshot events

| Event Type                   | Description                     |
| ---------------------------- | ------------------------------- |
| **`snapshot.created`**       | A new snapshot has been created |
| **`snapshot.state.updated`** | A snapshot's state has changed  |
| **`snapshot.removed`**       | A snapshot has been removed     |

### Volume events

| Event Type                 | Description                   |
| -------------------------- | ----------------------------- |
| **`volume.created`**       | A new volume has been created |
| **`volume.state.updated`** | A volume's state has changed  |

## Webhook payload format

All webhook payloads are JSON objects following a consistent format with common fields and event-specific data.

**Common Fields:**

| Field           | Type   | Description                                     |
| --------------- | ------ | ----------------------------------------------- |
| **`event`**     | string | Event type identifier (e.g., `sandbox.created`) |
| **`timestamp`** | string | ISO 8601 timestamp when the event occurred      |

### **`sandbox.created`**

Sent when a new sandbox is created.

```json
{
  "event": "sandbox.created",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "sandbox123",
  "organizationId": "org123",
  "state": "started",
  "sandboxClass": "container",
  "createdAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                     |
| -------------------- | ------ | ----------------------------------------------- |
| **`id`**             | string | Sandbox ID                                      |
| **`organizationId`** | string | Organization ID                                 |
| **`state`**          | string | Sandbox state                                   |
| **`sandboxClass`**   | string | Sandbox class                                   |
| **`createdAt`**      | string | ISO 8601 timestamp when the sandbox was created |

### **`sandbox.state.updated`**

Sent when a sandbox's state changes.

```json
{
  "event": "sandbox.state.updated",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "sandbox123",
  "organizationId": "org123",
  "oldState": "started",
  "newState": "stopped",
  "updatedAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                          |
| -------------------- | ------ | ---------------------------------------------------- |
| **`id`**             | string | Sandbox ID                                           |
| **`organizationId`** | string | Organization ID                                      |
| **`oldState`**       | string | Previous sandbox state                               |
| **`newState`**       | string | New sandbox state                                    |
| **`updatedAt`**      | string | ISO 8601 timestamp when the sandbox was last updated |

### **`snapshot.created`**

Sent when a new snapshot is created.

```json
{
  "event": "snapshot.created",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "snapshot123",
  "name": "my-snapshot",
  "organizationId": "org123",
  "state": "active",
  "createdAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                      |
| -------------------- | ------ | ------------------------------------------------ |
| **`id`**             | string | Snapshot ID                                      |
| **`name`**           | string | Snapshot name                                    |
| **`organizationId`** | string | Organization ID                                  |
| **`state`**          | string | Snapshot state                                   |
| **`createdAt`**      | string | ISO 8601 timestamp when the snapshot was created |

### **`snapshot.state.updated`**

Sent when a snapshot's state changes.

```json
{
  "event": "snapshot.state.updated",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "snapshot123",
  "name": "my-snapshot",
  "organizationId": "org123",
  "oldState": "building",
  "newState": "active",
  "updatedAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                           |
| -------------------- | ------ | ----------------------------------------------------- |
| **`id`**             | string | Snapshot ID                                           |
| **`name`**           | string | Snapshot name                                         |
| **`organizationId`** | string | Organization ID                                       |
| **`oldState`**       | string | Previous snapshot state                               |
| **`newState`**       | string | New snapshot state                                    |
| **`updatedAt`**      | string | ISO 8601 timestamp when the snapshot was last updated |

### **`snapshot.removed`**

Sent when a snapshot is removed.

```json
{
  "event": "snapshot.removed",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "snapshot123",
  "name": "my-snapshot",
  "organizationId": "org123",
  "removedAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                      |
| -------------------- | ------ | ------------------------------------------------ |
| **`id`**             | string | Snapshot ID                                      |
| **`name`**           | string | Snapshot name                                    |
| **`organizationId`** | string | Organization ID                                  |
| **`removedAt`**      | string | ISO 8601 timestamp when the snapshot was removed |

### **`volume.created`**

Sent when a new volume is created.

```json
{
  "event": "volume.created",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "vol-12345678",
  "name": "my-volume",
  "organizationId": "org123",
  "state": "ready",
  "createdAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                    |
| -------------------- | ------ | ---------------------------------------------- |
| **`id`**             | string | Volume ID                                      |
| **`name`**           | string | Volume name                                    |
| **`organizationId`** | string | Organization ID                                |
| **`state`**          | string | Volume state                                   |
| **`createdAt`**      | string | ISO 8601 timestamp when the volume was created |

### **`volume.state.updated`**

Sent when a volume's state changes.

```json
{
  "event": "volume.state.updated",
  "timestamp": "2025-12-19T10:30:00.000Z",
  "id": "vol-12345678",
  "name": "my-volume",
  "organizationId": "org123",
  "oldState": "creating",
  "newState": "ready",
  "updatedAt": "2025-12-19T10:30:00.000Z"
}
```

| Field                | Type   | Description                                         |
| -------------------- | ------ | --------------------------------------------------- |
| **`id`**             | string | Volume ID                                           |
| **`name`**           | string | Volume name                                         |
| **`organizationId`** | string | Organization ID                                     |
| **`oldState`**       | string | Previous volume state                               |
| **`newState`**       | string | New volume state                                    |
| **`updatedAt`**      | string | ISO 8601 timestamp when the volume was last updated |

## See Also

- [Python SDK](../python-sdk/README.md)
- [TypeScript SDK](../typescript-sdk/README.md)
- [Java SDK](../java-sdk/README.md)
- [Go SDK](../go-sdk/README.md)
- [Ruby SDK](../ruby-sdk/README.md)
