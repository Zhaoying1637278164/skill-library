
## Image

Declarative image builder used to define Sandbox runtime environments.

Use factory methods such as `#base(String)` or `#debianSlim(String)` and chain
mutating methods to append Dockerfile instructions.

### Methods

#### base()
```java
public static Image base(String baseImage)
```

Creates an image definition from an existing base image.

**Parameters**:

- `baseImage` _String_ - base image reference (for example `python:3.12-slim-bookworm`)

**Returns**:

- `Image` - new `Image` initialized with a `FROM` instruction

#### debianSlim()
```java
public static Image debianSlim(String pythonVersion)
```

Creates a Python Debian slim image.

**Parameters**:

- `pythonVersion` _String_ - Python version to use; defaults to `3.11` when `null` or empty

**Returns**:

- `Image` - new `Image` using a Python slim base image

#### pipInstall()
```java
public Image pipInstall(String... packages)
```

Adds a `pip install` instruction for one or more packages.

**Parameters**:

- `packages` _String..._ - package names to install

**Returns**:

- `Image` - this `Image` for method chaining

#### runCommands()
```java
public Image runCommands(String... commands)
```

Adds one or more `RUN` instructions.

**Parameters**:

- `commands` _String..._ - shell commands to execute during image build

**Returns**:

- `Image` - this `Image` for method chaining

#### env()
```java
public Image env(Map<String, String> envVars)
```

Adds environment variables using `ENV` instructions.

**Parameters**:

- `envVars` _Map\<String, String\>_ - environment variables to set in the image

**Returns**:

- `Image` - this `Image` for method chaining

#### workdir()
```java
public Image workdir(String path)
```

Sets the default working directory using a `WORKDIR` instruction.

**Parameters**:

- `path` _String_ - working directory path

**Returns**:

- `Image` - this `Image` for method chaining

#### entrypoint()
```java
public Image entrypoint(String... commands)
```

Sets the container entrypoint.

**Parameters**:

- `commands` _String..._ - entrypoint command and arguments

**Returns**:

- `Image` - this `Image` for method chaining

#### cmd()
```java
public Image cmd(String... commands)
```

Sets the default container command.

**Parameters**:

- `commands` _String..._ - default command and arguments

**Returns**:

- `Image` - this `Image` for method chaining

#### getDockerfile()
```java
public String getDockerfile()
```

Returns generated Dockerfile content.

**Returns**:

- `String` - Dockerfile text assembled by this builder

## See Also
- [TypeScript SDK - image](../typescript-sdk/image.md)
