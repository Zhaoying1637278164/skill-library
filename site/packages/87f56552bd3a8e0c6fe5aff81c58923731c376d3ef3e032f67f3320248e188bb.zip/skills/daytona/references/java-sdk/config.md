
## DaytonaConfig

Configuration used to initialize a `Daytona` client.

Contains API authentication settings, API endpoint URL, and the default target region used
when creating new Sandboxes.

### Methods

#### getApiKey()
```java
public String getApiKey()
```

Returns the API key used to authenticate SDK requests.

**Returns**:

- `String` - API key configured for the client

#### getApiUrl()
```java
public String getApiUrl()
```

Returns the Daytona API base URL.

**Returns**:

- `String` - API URL used for main API requests

#### getTarget()
```java
public String getTarget()
```

Returns the default target location for newly created Sandboxes.

**Returns**:

- `String` - target region identifier, or `null` if not configured

#### isOtelEnabled()
```java
public boolean isOtelEnabled()
```

Returns whether OpenTelemetry tracing is enabled for SDK operations.

Note: SDK-side OpenTelemetry instrumentation is not yet implemented in the Java SDK.
This setter exists for API parity with the other SDKs and to allow code to opt in ahead
of instrumentation landing in a future release.

**Returns**:

- `boolean` - `true` if OpenTelemetry tracing is enabled

#### isUseDeprecatedPolling()
```java
public boolean isUseDeprecatedPolling()
```

Returns whether legacy polling mode is enabled instead of WebSocket event streaming.

**Deprecated**: Polling-only mode will be removed in a future release; event streaming is the default and falls back to polling automatically when WebSockets are unavailable.

**Returns**:

- `boolean` - `true` if deprecated polling mode is active

## DaytonaConfig.Builder

Builder for creating immutable `DaytonaConfig` instances.

### Methods

#### apiKey()
```java
public Builder apiKey(String apiKey)
```

Sets the API key used for authenticating SDK requests.

**Parameters**:

- `apiKey` _String_ - Daytona API key

**Returns**:

- `Builder` - this builder instance

#### apiUrl()
```java
public Builder apiUrl(String apiUrl)
```

Sets the Daytona API base URL.

**Parameters**:

- `apiUrl` _String_ - API URL to use; defaults to `https://app.daytona.io/api` when omitted

**Returns**:

- `Builder` - this builder instance

#### target()
```java
public Builder target(String target)
```

Sets the default target region for new Sandboxes.

**Parameters**:

- `target` _String_ - target location identifier

**Returns**:

- `Builder` - this builder instance

#### otelEnabled()
```java
public Builder otelEnabled(boolean otelEnabled)
```

Enables OpenTelemetry tracing for SDK operations.

Note: SDK-side OpenTelemetry instrumentation is not yet implemented in the Java SDK.
This setter exists for API parity with the other SDKs and to allow code to opt in ahead
of instrumentation landing in a future release.

**Parameters**:

- `otelEnabled` _boolean_ - whether to enable OpenTelemetry tracing

**Returns**:

- `Builder` - this builder instance

#### useDeprecatedPolling()
```java
public Builder useDeprecatedPolling(boolean useDeprecatedPolling)
```

Observe sandbox state by legacy polling instead of WebSocket event streaming.
Defaults to `false` (event streaming). Can also be enabled via the
`DAYTONA_USE_DEPRECATED_POLLING` environment variable.

**Deprecated**: Polling-only mode will be removed in a future release; event streaming is the default and falls back to polling automatically when WebSockets are unavailable.

**Parameters**:

- `useDeprecatedPolling` _boolean_ - whether to use legacy polling

**Returns**:

- `Builder` - this builder instance

#### build()
```java
public DaytonaConfig build()
```

Builds a new immutable `DaytonaConfig`.

**Returns**:

- `DaytonaConfig` - configured `DaytonaConfig` instance
