## Contents

- ComputerUse
- Accessibility
- See Also



## ComputerUse

Initialize a new ComputerUse instance.

### Constructors

#### new ComputerUse()

```ruby
def initialize(sandbox_id:, toolbox_api:, otel_state: nil)

```

Initialize a new ComputerUse instance.

**Parameters**:

- `sandbox_id` _String_ - The ID of the sandbox
- `toolbox_api` _DaytonaApiClient:ToolboxApi_ - API client for sandbox operations
- `otel_state` _Daytona:OtelState, nil_ -

**Returns**:

- `ComputerUse` - a new instance of ComputerUse

### Methods

#### sandbox_id()

```ruby
def sandbox_id()

```

**Returns**:

- `String` - The ID of the sandbox

#### toolbox_api()

```ruby
def toolbox_api()

```

**Returns**:

- `DaytonaApiClient:ToolboxApi` - API client for sandbox operations

#### mouse()

```ruby
def mouse()

```

**Returns**:

- `Mouse` - Mouse operations interface

#### keyboard()

```ruby
def keyboard()

```

**Returns**:

- `Keyboard` - Keyboard operations interface

#### screenshot()

```ruby
def screenshot()

```

**Returns**:

- `Screenshot` - Screenshot operations interface

#### display()

```ruby
def display()

```

**Returns**:

- `Display` - Display operations interface

#### recording()

```ruby
def recording()

```

**Returns**:

- `Recording` - Screen recording operations interface

#### accessibility()

```ruby
def accessibility()

```

**Returns**:

- `Accessibility` - Accessibility operations interface

#### start()

```ruby
def start()

```

Starts all computer use processes (Xvfb, xfce4, x11vnc, novnc).

**Returns**:

- `DaytonaApiClient:ComputerUseStartResponse` - Computer use start response

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
result = sandbox.computer_use.start
puts "Computer use processes started: #{result.message}"

```

#### stop()

```ruby
def stop()

```

Stops all computer use processes.

**Returns**:

- `DaytonaApiClient:ComputerUseStopResponse` - Computer use stop response

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
result = sandbox.computer_use.stop
puts "Computer use processes stopped: #{result.message}"

```

#### status()

```ruby
def status()

```

Gets the status of all computer use processes.

**Returns**:

- `DaytonaApiClient:ComputerUseStatusResponse` - Status information about all VNC desktop processes

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
response = sandbox.computer_use.get_status
puts "Computer use status: #{response.status}"

```

#### get_process_status()

```ruby
def get_process_status(process_name:)

```

Gets the status of a specific VNC process.

**Parameters**:

- `process_name` _String_ - Name of the process to check

**Returns**:

- `DaytonaApiClient:ProcessStatusResponse` - Status information about the specific process

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
xvfb_status = sandbox.computer_use.get_process_status("xvfb")
no_vnc_status = sandbox.computer_use.get_process_status("novnc")

```

#### restart_process()

```ruby
def restart_process(process_name:)

```

Restarts a specific VNC process.

**Parameters**:

- `process_name` _String_ - Name of the process to restart

**Returns**:

- `DaytonaApiClient:ProcessRestartResponse` - Process restart response

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
result = sandbox.computer_use.restart_process("xfce4")
puts "XFCE4 process restarted: #{result.message}"

```

#### get_process_logs()

```ruby
def get_process_logs(process_name:)

```

Gets logs for a specific VNC process.

**Parameters**:

- `process_name` _String_ - Name of the process to get logs for

**Returns**:

- `DaytonaApiClient:ProcessLogsResponse` - Process logs

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
logs = sandbox.computer_use.get_process_logs("novnc")
puts "NoVNC logs: #{logs}"

```

#### get_process_errors()

```ruby
def get_process_errors(process_name:)

```

Gets error logs for a specific VNC process.

**Parameters**:

- `process_name` _String_ - Name of the process to get error logs for

**Returns**:

- `DaytonaApiClient:ProcessErrorsResponse` - Process error logs

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
errors = sandbox.computer_use.get_process_errors("x11vnc")
puts "X11VNC errors: #{errors}"

```

## Accessibility

Accessibility operations for computer use functionality.

### Constructors

#### new Accessibility()

```ruby
def initialize(sandbox_id:, toolbox_api:, otel_state: nil)

```

**Parameters**:

- `sandbox_id` _String_ - The ID of the sandbox
- `toolbox_api` _DaytonaToolboxApiClient:ComputerUseApi_ - API client for sandbox operations
- `otel_state` _Daytona:OtelState, nil_ -

**Returns**:

- `Accessibility` - a new instance of Accessibility

### Methods

#### sandbox_id()

```ruby
def sandbox_id()

```

**Returns**:

- `String` - The ID of the sandbox

#### toolbox_api()

```ruby
def toolbox_api()

```

**Returns**:

- `DaytonaToolboxApiClient:ComputerUseApi` - API client for sandbox operations

#### get_tree()

```ruby
def get_tree(scope: nil, pid: nil, max_depth: nil)

```

Fetches the AT-SPI accessibility tree.

**Parameters**:

- `scope` _String, nil_ - Tree scope to inspect: "focused", "pid", or "all"
- `pid` _Integer, nil_ - Process ID when scope is "pid"
- `max_depth` _Integer, nil_ - Maximum depth to descend; 0 returns only the root

**Returns**:

- `DaytonaToolboxApiClient:AccessibilityTreeResponse` - Accessibility tree response

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
tree = sandbox.computer_use.accessibility.get_tree(scope: "all", max_depth: 3)
puts tree.root.name

```

#### find_nodes()

```ruby
def find_nodes(scope: nil, pid: nil, role: nil, name: nil, name_match: nil, states: nil, limit: nil)

```

Finds AT-SPI accessibility nodes matching the provided filters.

**Parameters**:

- `scope` _String, nil_ - Search scope: "focused", "pid", or "all"
- `pid` _Integer, nil_ - Process ID when scope is "pid"
- `role` _String, nil_ - Accessibility role to match, such as "button"
- `name` _String, nil_ - Accessible name to match
- `name_match` _String, nil_ - Name match mode, such as "exact" or "substring"
- `states` _Array\<String\>, nil_ - Required accessibility states
- `limit` _Integer, nil_ - Maximum number of matches

**Returns**:

- `DaytonaToolboxApiClient:AccessibilityNodesResponse` - Matching accessibility nodes

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
buttons = sandbox.computer_use.accessibility.find_nodes(
  scope: "all",
  role: "button",
  name: "Submit",
  name_match: "substring"
)
puts buttons.matches.length

```

#### focus_node()

```ruby
def focus_node(id:)

```

Focuses an AT-SPI accessibility node.

**Parameters**:

- `id` _String_ - Accessibility node ID returned by get_tree or find_nodes

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
sandbox.computer_use.accessibility.focus_node(id: node.id)

```

#### invoke_node()

```ruby
def invoke_node(id:, action: nil)

```

Invokes an AT-SPI accessibility node action.

**Parameters**:

- `id` _String_ - Accessibility node ID returned by get_tree or find_nodes
- `action` _String, nil_ - Action name to invoke, or nil for the primary action

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
sandbox.computer_use.accessibility.invoke_node(id: node.id, action: "click")

```

#### set_node_value()

```ruby
def set_node_value(id:, value:)

```

Sets an AT-SPI accessibility node value.

**Parameters**:

- `id` _String_ - Accessibility node ID returned by get_tree or find_nodes
- `value` _String_ - Value to write to the node

**Raises**:

- `Daytona:Sdk:Error` - If the operation fails

**Examples:**

```ruby
sandbox.computer_use.accessibility.set_node_value(id: node.id, value: "hello")

```

## See Also
- [Python SDK - computer-use](../python-sdk/sync/computer-use.md)
- [TypeScript SDK - computer-use](../typescript-sdk/computer-use.md)
- [Java SDK - computer-use](../java-sdk/computer-use.md)
