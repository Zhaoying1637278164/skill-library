const fs = require('fs')
const path = require('path')

const defaultPaths = [
  '.env.example',
  '.env.sample',
  '.env.template',
  'README.md',
  'readme.md',
  'config',
]

const args = process.argv.slice(2)
const inputPaths = args.length > 0 ? args : defaultPaths

const envKeyPattern = /^\s*(?:export\s+)?([A-Z][A-Z0-9_]+)\s*=\s*.*$/

function isTextFile(filePath) {
  const ext = path.extname(filePath).toLowerCase()
  return ['.env', '.md', '.txt', '.yml', '.yaml', '.json', '.toml'].includes(ext)
}

function collectFiles(p) {
  const files = []
  if (!fs.existsSync(p)) return files
  const stat = fs.statSync(p)
  if (stat.isFile()) return [p]
  if (!stat.isDirectory()) return files
  const entries = fs.readdirSync(p)
  for (const entry of entries) {
    const full = path.join(p, entry)
    const st = fs.statSync(full)
    if (st.isDirectory()) {
      files.push(...collectFiles(full))
    } else if (isTextFile(full) || entry.startsWith('.env')) {
      files.push(full)
    }
  }
  return files
}

const files = Array.from(new Set(inputPaths.flatMap(collectFiles)))
const keys = new Set()
const sources = {}

for (const file of files) {
  try {
    const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/)
    for (const line of lines) {
      const m = envKeyPattern.exec(line)
      if (m) {
        const key = m[1]
        keys.add(key)
        sources[key] = sources[key] || []
        sources[key].push(file)
      }
    }
  } catch {}
}

const missing = []
const present = []
for (const key of keys) {
  if (process.env[key] == null || process.env[key] === '') missing.push(key)
  else present.push(key)
}

const status = missing.length > 0 ? 'fail' : 'ok'
const result = {
  status,
  missing: missing.sort(),
  present: present.sort(),
  notes: files.length === 0
    ? ['No env files found in default locations.']
    : ['Scanned files:', ...files],
  sources,
}

process.stdout.write(JSON.stringify(result, null, 2))
