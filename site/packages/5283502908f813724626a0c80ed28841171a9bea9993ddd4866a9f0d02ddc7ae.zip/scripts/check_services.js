const fs = require('fs')
const net = require('net')

const defaultPorts = {
  postgres: 5432,
  mysql: 3306,
  redis: 6379,
  rabbitmq: 5672,
  kafka: 9092,
  mongodb: 27017,
}

const args = process.argv.slice(2)

function detectPortsFromCompose() {
  const files = ['docker-compose.yml', 'docker-compose.yaml']
  const ports = new Set()
  for (const f of files) {
    if (!fs.existsSync(f)) continue
    const lines = fs.readFileSync(f, 'utf8').split(/\r?\n/)
    for (const line of lines) {
      const m = line.match(/\b(\d{2,5})\s*:\s*(\d{2,5})\b/)
      if (m) ports.add(Number(m[1]))
    }
  }
  return Array.from(ports)
}

function detectServicesFromEnv() {
  const candidates = []
  const files = ['.env', '.env.local', '.env.example', '.env.sample', '.env.template']
  for (const f of files) {
    if (!fs.existsSync(f)) continue
    const content = fs.readFileSync(f, 'utf8')
    if (/POSTGRES|DATABASE_URL|PGHOST|PGPORT/i.test(content)) candidates.push('postgres')
    if (/MYSQL|MARIADB/i.test(content)) candidates.push('mysql')
    if (/REDIS/i.test(content)) candidates.push('redis')
    if (/RABBIT|AMQP/i.test(content)) candidates.push('rabbitmq')
    if (/KAFKA/i.test(content)) candidates.push('kafka')
    if (/MONGO/i.test(content)) candidates.push('mongodb')
  }
  return Array.from(new Set(candidates))
}

function checkPort(port, host = '127.0.0.1', timeoutMs = 800) {
  return new Promise(resolve => {
    const socket = new net.Socket()
    let done = false
    const finish = status => {
      if (done) return
      done = true
      socket.destroy()
      resolve(status)
    }
    socket.setTimeout(timeoutMs)
    socket.once('connect', () => finish('ok'))
    socket.once('timeout', () => finish('down'))
    socket.once('error', () => finish('down'))
    socket.connect(port, host)
  })
}

async function main() {
  const detected = detectServicesFromEnv()
  const composePorts = detectPortsFromCompose()

  const services = []
  if (args.length > 0) {
    for (const name of args) {
      if (defaultPorts[name]) services.push({ name, port: defaultPorts[name] })
    }
  } else {
    for (const name of detected) {
      services.push({ name, port: defaultPorts[name] })
    }
    for (const port of composePorts) {
      if (!Object.values(defaultPorts).includes(port)) {
        services.push({ name: `port-${port}`, port })
      }
    }
    if (services.length === 0) {
      for (const [name, port] of Object.entries(defaultPorts)) {
        services.push({ name, port })
      }
    }
  }

  const results = []
  for (const svc of services) {
    const status = await checkPort(svc.port)
    results.push({
      name: svc.name,
      status,
      check: `tcp://127.0.0.1:${svc.port}`,
      hint: status === 'ok' ? '' : `Start ${svc.name} or ensure it is listening on ${svc.port}.`,
    })
  }

  const status = results.some(r => r.status !== 'ok') ? 'fail' : 'ok'
  const output = { status, services: results }
  process.stdout.write(JSON.stringify(output, null, 2))
}

main().catch(err => {
  process.stdout.write(JSON.stringify({ status: 'fail', error: String(err) }))
})
