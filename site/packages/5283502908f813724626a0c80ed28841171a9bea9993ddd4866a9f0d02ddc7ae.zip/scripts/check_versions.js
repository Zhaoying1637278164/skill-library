const fs = require('fs')
const childProcess = require('child_process')

function readFileSafe(p) {
  try { return fs.readFileSync(p, 'utf8').trim() } catch { return '' }
}

function parseVersion(raw) {
  const m = String(raw).match(/(\d+)(?:\.(\d+))?(?:\.(\d+))?/)
  if (!m) return null
  return {
    major: Number(m[1] || 0),
    minor: Number(m[2] || 0),
    patch: Number(m[3] || 0),
  }
}

function compare(a, b) {
  if (!a || !b) return 0
  if (a.major !== b.major) return a.major - b.major
  if (a.minor !== b.minor) return a.minor - b.minor
  return a.patch - b.patch
}

function readRequiredVersions() {
  const req = {}
  const nvmrc = readFileSafe('.nvmrc')
  const nodeVersion = readFileSafe('.node-version')
  const pkg = readFileSafe('package.json')
  if (nvmrc) req.node = nvmrc
  else if (nodeVersion) req.node = nodeVersion
  else if (pkg) {
    try {
      const parsed = JSON.parse(pkg)
      if (parsed.engines && parsed.engines.node) req.node = parsed.engines.node
      if (parsed.engines && parsed.engines.bun) req.bun = parsed.engines.bun
    } catch {}
  }

  const pyVersion = readFileSafe('.python-version')
  if (pyVersion) req.python = pyVersion
  const pyproject = readFileSafe('pyproject.toml')
  if (!req.python && pyproject) {
    const m = pyproject.match(/python\s*=\s*["']([^"']+)["']/)
    if (m) req.python = m[1]
  }

  const goMod = readFileSafe('go.mod')
  if (goMod) {
    const m = goMod.match(/^go\s+(\d+(?:\.\d+)?)/m)
    if (m) req.go = m[1]
  }

  const rustToolchain = readFileSafe('rust-toolchain') || readFileSafe('rust-toolchain.toml')
  if (rustToolchain) {
    const m = rustToolchain.match(/channel\s*=\s*["']([^"']+)["']/) || rustToolchain.match(/^(\d+(?:\.\d+){1,2})/m)
    if (m) req.rust = m[1]
  }

  return req
}

function runVersion(cmd) {
  try { return childProcess.execSync(cmd, { stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim() } catch { return '' }
}

function normalizeRequirement(req) {
  const r = String(req).trim()
  if (r.startsWith('>=')) return { op: '>=', version: r.slice(2).trim() }
  if (r.startsWith('^')) return { op: '^', version: r.slice(1).trim() }
  if (r.startsWith('~')) return { op: '~', version: r.slice(1).trim() }
  return { op: '=', version: r }
}

function checkMatch(required, detected) {
  const req = normalizeRequirement(required)
  const reqVer = parseVersion(req.version)
  const detVer = parseVersion(detected)
  if (!reqVer || !detVer) return { status: 'warn', reason: 'unparseable' }
  const cmp = compare(detVer, reqVer)
  if (req.op === '>=') return { status: cmp >= 0 ? 'ok' : 'warn' }
  if (req.op === '=') return { status: cmp === 0 ? 'ok' : 'warn' }
  return { status: cmp >= 0 ? 'ok' : 'warn' }
}

const required = readRequiredVersions()
const checks = []

if (required.node) {
  const detected = runVersion('node --version')
  const match = detected ? checkMatch(required.node, detected) : { status: 'fail' }
  checks.push({
    tool: 'node',
    required: required.node,
    detected: detected || 'not found',
    status: detected ? match.status : 'fail',
    hint: detected ? '' : 'Install Node.js or ensure it is in PATH.',
  })
}

if (required.bun) {
  const detected = runVersion('bun --version')
  const match = detected ? checkMatch(required.bun, detected) : { status: 'fail' }
  checks.push({
    tool: 'bun',
    required: required.bun,
    detected: detected || 'not found',
    status: detected ? match.status : 'fail',
    hint: detected ? '' : 'Install Bun or ensure it is in PATH.',
  })
}

if (required.python) {
  const detected = runVersion('python --version') || runVersion('python3 --version')
  const match = detected ? checkMatch(required.python, detected) : { status: 'fail' }
  checks.push({
    tool: 'python',
    required: required.python,
    detected: detected || 'not found',
    status: detected ? match.status : 'fail',
    hint: detected ? '' : 'Install Python or ensure it is in PATH.',
  })
}

if (required.go) {
  const detected = runVersion('go version')
  const match = detected ? checkMatch(required.go, detected) : { status: 'fail' }
  checks.push({
    tool: 'go',
    required: required.go,
    detected: detected || 'not found',
    status: detected ? match.status : 'fail',
    hint: detected ? '' : 'Install Go or ensure it is in PATH.',
  })
}

if (required.rust) {
  const detected = runVersion('rustc --version')
  const match = detected ? checkMatch(required.rust, detected) : { status: 'fail' }
  checks.push({
    tool: 'rust',
    required: required.rust,
    detected: detected || 'not found',
    status: detected ? match.status : 'fail',
    hint: detected ? '' : 'Install Rust (rustup) or ensure it is in PATH.',
  })
}

const status = checks.some(c => c.status === 'fail')
  ? 'fail'
  : checks.some(c => c.status === 'warn')
    ? 'warn'
    : 'ok'

process.stdout.write(JSON.stringify({ status, checks }, null, 2))
