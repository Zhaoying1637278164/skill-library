const path = require('path')
const childProcess = require('child_process')

function run(script) {
  const p = path.join(__dirname, script)
  const out = childProcess.execFileSync(process.execPath, [p], {
    stdio: ['ignore', 'pipe', 'ignore'],
  }).toString()
  return JSON.parse(out)
}

function formatList(items) {
  if (!items || items.length === 0) return 'None'
  return items.join(', ')
}

function render() {
  const env = run('scan_env_files.js')
  const services = run('check_services.js')
  const versions = run('check_versions.js')

  const missingEnv = env.missing || []
  const downServices = (services.services || []).filter(s => s.status !== 'ok')
  const versionIssues = (versions.checks || []).filter(c => c.status !== 'ok')

  const status =
    missingEnv.length > 0 || downServices.length > 0 || versionIssues.length > 0
      ? 'WARN'
      : 'OK'

  const report = {
    status,
    env: {
      status: missingEnv.length > 0 ? 'fail' : 'ok',
      missing: missingEnv,
    },
    services: {
      status: downServices.length > 0 ? 'fail' : 'ok',
      down: downServices.map(s => `${s.name} (${s.check})`),
    },
    versions: {
      status: versionIssues.length > 0 ? 'warn' : 'ok',
      mismatches: versionIssues.map(c => `${c.tool}: required ${c.required}, detected ${c.detected}`),
    },
  }

  const lines = []
  lines.push(`Dev Environment Doctor — ${status}`)
  lines.push('')
  lines.push(`Env vars: ${report.env.status.toUpperCase()}`)
  lines.push(`  Missing: ${formatList(report.env.missing)}`)
  lines.push('')
  lines.push(`Services: ${report.services.status.toUpperCase()}`)
  lines.push(`  Down: ${formatList(report.services.down)}`)
  lines.push('')
  lines.push(`Versions: ${report.versions.status.toUpperCase()}`)
  lines.push(`  Mismatches: ${formatList(report.versions.mismatches)}`)

  process.stdout.write(lines.join('\n'))
}

render()
