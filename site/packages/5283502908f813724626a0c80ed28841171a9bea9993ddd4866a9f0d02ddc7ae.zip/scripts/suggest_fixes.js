const path = require('path')
const childProcess = require('child_process')

function run(script) {
  const p = path.join(__dirname, script)
  const out = childProcess.execFileSync(process.execPath, [p], {
    stdio: ['ignore', 'pipe', 'ignore'],
  }).toString()
  return JSON.parse(out)
}

function unique(items) {
  return Array.from(new Set(items))
}

function main() {
  const env = run('scan_env_files.js')
  const services = run('check_services.js')
  const versions = run('check_versions.js')

  const steps = []

  if (env.missing && env.missing.length > 0) {
    steps.push({
      priority: 1,
      action: 'Set missing environment variables',
      detail: unique(env.missing).join(', '),
      hint: 'Use your shell, .env.local, or a secrets manager. Do not commit secrets.',
    })
  }

  const down = (services.services || []).filter(s => s.status !== 'ok')
  if (down.length > 0) {
    steps.push({
      priority: 2,
      action: 'Start required services',
      detail: down.map(s => `${s.name} (${s.check})`).join(', '),
      hint: 'Use docker compose or your system service manager.',
    })
  }

  const mismatch = (versions.checks || []).filter(c => c.status !== 'ok')
  if (mismatch.length > 0) {
    steps.push({
      priority: 3,
      action: 'Align tool versions',
      detail: mismatch.map(c => `${c.tool}: required ${c.required}, detected ${c.detected}`).join('; '),
      hint: 'Install the required versions using your version manager.',
    })
  }

  const status = steps.length === 0 ? 'ok' : 'warn'
  process.stdout.write(JSON.stringify({ status, steps }, null, 2))
}

main()
