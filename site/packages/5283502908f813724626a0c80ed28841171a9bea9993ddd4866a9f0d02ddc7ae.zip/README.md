# Dev Environment Doctor

Local dev breaks for the same reasons every time: missing env vars, services that are down, and version drift. This plugin runs a fast, read-only check and tells you exactly what is wrong and how to fix it. No guessing, no "works on my machine" surprises.

## The Problem

- Missing environment variables lead to cryptic runtime errors
- Local services (db, cache, queue) fail silently or are misconfigured
- Tool versions drift from project requirements
- Debugging time gets burned on issues that are not code bugs

## The Solution

Run one command: `/dev-env-doctor:doctor`. It scans env vars, services, and versions, then returns actionable fixes. It is safe by default: read-only checks, no file edits, no service restarts.

## Benefits

- Save hours of setup and debugging time
- Faster onboarding for new contributors
- Fewer "it works on my machine" issues
- Prevent hidden config errors before they ship
- Works across projects with common env files

## When to Use This

- Starting a new project locally
- After pulling new changes
- Before running tests or CI locally
- When something "suddenly broke" on your machine

## What It Checks

- Required environment variables from common project files
- Local services (database, cache, queue) are reachable
- Tool versions match declared requirements

## Commands

- `/dev-env-doctor:doctor` — full health check summary
- `/dev-env-doctor:check_env` — validate required environment variables
- `/dev-env-doctor:check_services` — verify local service health
- `/dev-env-doctor:check_versions` — validate tool versions
- `/dev-env-doctor:suggest_fixes` — generate a prioritized fix plan

## Requirements

- Node.js (v18+ recommended)

## Installation / Usage

Run Claude Code with the local plugin directory:

```
claude --plugin-dir ./plugins/dev-env-doctor
```

Then run any command:

```
/dev-env-doctor:doctor
/dev-env-doctor:check_env
/dev-env-doctor:check_services
/dev-env-doctor:check_versions
/dev-env-doctor:suggest_fixes
```

## Example Usage

```
/dev-env-doctor:doctor
/dev-env-doctor:check_env
/dev-env-doctor:check_services
/dev-env-doctor:check_versions
/dev-env-doctor:suggest_fixes
```

## Safety

- Read-only checks
- No file modifications
- No service restarts
- Only suggestions with explicit commands

## Example Output

```
Dev Environment Doctor — WARN

Env vars: OK
	Missing: None

Services: FAIL
	Down: postgres (tcp://127.0.0.1:5432), redis (tcp://127.0.0.1:6379)

Versions: OK
	Mismatches: None
```

## License

MIT
