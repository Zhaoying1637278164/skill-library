---
description: Generate a prioritized fix plan based on environment checks.
allowed-tools: Bash
---

Generate fix plan:
!`node ${CLAUDE_PLUGIN_ROOT}/scripts/suggest_fixes.js`

Return the steps in priority order. Only suggest actions; do not apply any changes.
