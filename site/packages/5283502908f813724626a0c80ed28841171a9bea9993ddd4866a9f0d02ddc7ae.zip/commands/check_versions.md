---
description: Validate tool versions against project requirements.
argument-hint:
- tool...
allowed-tools: Bash
---

Run version checks:
!`node ${CLAUDE_PLUGIN_ROOT}/scripts/check_versions.js $ARGUMENTS`

Summarize mismatches and provide safe upgrade guidance. Do not install or change versions automatically.
