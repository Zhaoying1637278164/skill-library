---
description: Check whether local dev services are reachable (DB, cache, queue).
argument-hint:
- service...
allowed-tools: Bash
---

Run service checks:
!`node ${CLAUDE_PLUGIN_ROOT}/scripts/check_services.js $ARGUMENTS`

Summarize unhealthy services and provide safe, explicit commands to start them. Do not start or restart services automatically.
