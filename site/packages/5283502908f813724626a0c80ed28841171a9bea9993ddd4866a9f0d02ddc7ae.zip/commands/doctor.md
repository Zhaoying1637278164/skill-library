---
description: Run a full dev environment health check and return a single report.
allowed-tools: Bash
---

Run all checks and combine results:
!`node ${CLAUDE_PLUGIN_ROOT}/scripts/doctor.js`

Summarize failures and warnings with clear next steps. Do not apply changes.
