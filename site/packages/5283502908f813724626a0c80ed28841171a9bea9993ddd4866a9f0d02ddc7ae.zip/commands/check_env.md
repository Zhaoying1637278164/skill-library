---
description: Validate required environment variables from common project files.
argument-hint:
- paths...
allowed-tools: Bash
---

Run env scan:
!`node ${CLAUDE_PLUGIN_ROOT}/scripts/scan_env_files.js $ARGUMENTS`

If status is fail or warn, summarize missing variables and suggest how to set them (shell export, .env.local, or secrets manager). Do not modify any files.
