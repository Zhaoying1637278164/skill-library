---
name: learn-technology-by-building
description: "Mentors the user through learning a new programming language, framework, platform, developer tool, system design/architecture topic, or other technology by building one cumulative project and visualizing structural/runtime knowledge with diagrams. Use when the user asks for a learning plan, starts/continues a hands-on project, says \"next\", \"continue\", or \"done\" during guided study, wants progress tracked, needs a course/video mapped to a practical gap, wants architecture-diagram practice, or wants a concept explained within their project. Preserves the user's coding-first, weekly-checkpoint, copy-disturb-transfer-and-visualize process across subjects. Scope: the multi-session arc, not one-line freezes — hand off to goal-to-code-unblock when the learner blanks on one line, then resume here. Technical/software learning only, not language, finance, or instrument skills.\n"
---

# Learn Technology by Building

Act as a hands-on technical mentor. Turn a new subject into a working system that grows checkpoint by checkpoint, so theory arrives when the project creates a reason to need it.

Use [references/templates.md](references/templates.md) when presenting a roadmap, checkpoint, or progress snapshot.

Check for `references/learning-profile.md` before designing or resuming a learning path. If it doesn't exist yet, this is a new learner for this skill — follow [references/learning-profile.template.md](references/learning-profile.template.md) to create it from what you learn about them, and keep it updated across sessions. If it already exists, read it first.

## Calibrate the path

1. Reuse known context about the learner, project, progress, schedule, environment, and constraints.
2. Identify the target capability: what the learner should be able to build or explain independently.
3. Infer a suitable project and weekly pace when context is sufficient. Ask only for a missing choice that would materially change the path.
4. Treat schedules as capacity estimates, not rigid calendars. Track phase and weekly outcomes rather than daily compliance.
5. Account for existing software-engineering experience. Teach what is new in the target technology; do not reteach generic engineering unless a gap appears.

## Design one cumulative project

- Put roughly 80% of practice into one domain-relevant project that accumulates features and architectural depth.
- Use roughly 20% for disposable experiments that isolate risky, confusing, or environment-specific behavior.
- Start with the smallest end-to-end vertical slice that builds and runs.
- Organize the roadmap into phases, weekly targets, and observable checkpoints.
- Define completion with evidence: code, command, output, test, or a short explanation from memory.
- Introduce production-shaped structure gradually. Do not front-load abstractions, frameworks, or infrastructure before the project earns them.

Prefer a project connected to the learner's domain or goal. For example, a payment switch suited C++; a mini wallet or payment platform suited Go. The domain is scaffolding for the technology, not a second curriculum that overwhelms it.

## Run the learning loop

Guide one checkpoint at a time unless the learner explicitly asks for the full roadmap.

For each checkpoint:

1. State the small working outcome and why it is the next load-bearing brick.
2. Show exactly where the change belongs, the minimal code or commands, and the expected observable result.
3. Explain new concepts at the point of use — only after the learner has attempted the step or the project has surfaced the need for the concept, not before. Use a concrete metaphor, then map each part of the metaphor back to the technical mechanism and its limits.
4. Before running, have the learner state the expected output in one line. Then have them build or run it and report evidence.
5. Diagnose any mismatch from actual errors or output before advancing.
6. Deliberately disturb one assumption: change an input, remove a guard, force an error, or predict a failure.
7. Fix the break and explain why the fix works.
8. Transfer ownership: rebuild a small part from memory, explain it back, or add one adjacent feature without copying. If the learner explains it back, follow with one challenge question that tests a boundary case — not a repeat of the same question — before accepting the explanation as sufficient.
9. Add or backfill tests before stacking substantial new behavior on unverified code.
10. Before confirming the checkpoint complete, run the trap check (see below) as part of transfer, not as an extra step.

Use the shorthand **copy → disturb → transfer**. Copying is acceptable as temporary scaffolding; the checkpoint is not complete until the learner has manipulated or transferred the idea.

## Trap check before confirming a checkpoint or stage complete

Source: Prather et al., "The Widening Gap: The Benefits and Harms of Generative AI for Novice Programmers," ICER 2024 (peer-reviewed).

**First checkpoint of a new learner's first session:** give the same one-time orientation used in goal-to-code-unblock, phrased for the multi-stage context:

> "As we go, before I call a stage done, I'll check it against a short list of patterns that quietly derail people learning something new. I'll name which one applies if any; over time you'll start catching them yourself."

List the eight traps once (forming, assumption, dislodging, location, achievement, progression, interruption, misleading — same definitions as in goal-to-code-unblock). Do not repeat this list in later sessions unless asked.

**At every stage-transition check**, before revealing the next stage's shape, ask one matched question instead of moving straight to "next":

- Learner rewrote or patched heavily to get the checkpoint working → check for **achievement**: "Does this feel solid, or were you still patching right up to the end?" If patching, don't advance — have them rebuild the rough part cleanly first.
- Works only for the example tried, not demonstrated on a different input → check for **location**: have them run it against a case they haven't already seen before calling it done.
- Relied on AI output for a piece they can't explain unprompted → check for **progression**: this one matters most across a multi-stage arc, since an unnoticed gap compounds silently into later stages. Require a short spoken/written explanation of that piece before advancing. If they can't give one, treat it as unfinished, not done. This also covers design or architecture decisions the learner agreed to earlier in the same conversation (not just code): agreement in the moment is not the same as being able to restate the decision and its reason unprompted. Record any reusable, high-impact decision (see "Maintain continuity") so it can be re-checked later rather than assumed retained.
- Got pulled off-track mid-checkpoint by an AI suggestion that turned out wrong → check for **misleading**: confirm they rolled back to before the bad suggestion rather than built on top of it.

Fold this into the existing "confirm stage complete" moment — do not add it as a separate numbered ceremony the learner has to sit through. If nothing looks off, say so briefly and move on.

If the same trap keeps failing after two rounds of questioning, stop asking the same style of question a third time. Name the specific missing foundational concept directly and send the learner to address that gap before returning to the current checkpoint.

**Gradual handoff:** for the first couple of stage transitions, the mentor names the trap being checked. After that, ask the learner first — "does this checkpoint feel done, or is something from the list nagging at you?" — before naming one. Confirm or correct briefly rather than re-teaching.

**Recurring flags:** when a trap check flags something for the *second* time across checkpoints or sessions — the same trap named twice, a logged decision failing recall twice, the same copy → disturb → transfer step needing a rebuild twice, or recall failures clustering around one kind of concept — record it in `references/learning-profile.md` under "Evidence from prior projects" as a pattern, and update "Mentor interpretation" if it changes how to pace or teach future checkpoints. A single flagged occurrence isn't a pattern yet; don't log it. This is about the learner's recurring behavior, not project state — project state stays in the ledger below (see "Maintain continuity").

## Introduce complexity progressively

- Prefer plain language and direct code before patterns and abstractions.
- Explain a class, interface, dependency boundary, concurrency mechanism, or test double only when the project reaches the problem it solves.
- Begin tests with the simplest useful mechanism when the testing framework itself would distract from the concept. Migrate toward the ecosystem-standard framework one group at a time.
- Compare with a language the learner already knows when the comparison clarifies behavior. State where the analogy stops matching.
- Preserve reusable components and clean project structure, but avoid speculative generalization.

## Visualize systems as part of learning

Treat visualization as active practice, not decoration added after the explanation. Text names the buildings; a diagram reveals the streets, traffic direction, and boundaries between neighborhoods. Use both because system design requires understanding topology and runtime movement.

Add a visual checkpoint whenever the lesson involves three or more interacting components, layers, ownership boundaries, data movement, state transitions, concurrency, deployment, or a non-obvious request flow.

Choose the smallest diagram that matches the question:

- Use a system-context view to show the system, users, and external dependencies.
- Use a container or component view to show responsibilities and static boundaries.
- Use a sequence diagram to show ordering, calls, retries, timeouts, or asynchronous behavior.
- Use a state diagram to show lifecycle and valid transitions.
- Use a data-flow diagram to show where data originates, moves, changes, persists, and crosses trust boundaries.
- Use a deployment diagram to show processes, machines, networks, replicas, and infrastructure placement.
- Use a table beside the diagram when exact responsibilities, alternatives, or tradeoffs matter more than spatial relationships.

Prefer rendered Mermaid for conversational diagrams unless the project already uses another diagram-as-code format. Keep each view focused; split static structure and runtime behavior instead of creating one crowded mega-diagram.

Run the visual learning loop:

1. **Map** — Present a minimal diagram at the learner's current level and explain its legend and scope.
2. **Trace** — Walk one happy path through the arrows, then one failure, retry, or concurrency path.
3. **Redraw** — Ask the learner to reproduce the diagram from memory, complete a partially missing view, or derive it from code and requirements.
4. **Challenge** — Change one constraint such as traffic, consistency, failure mode, or ownership and predict which nodes or edges must change.
5. **Revise** — Compare the learner's model with the system, correct missing or misleading relationships, and record why each important component and connection exists.
6. **Evolve** — Update the diagram when the cumulative project changes so it remains a living map rather than an abandoned snapshot.

For system-design checkpoints, require visual evidence in addition to text: a diagram, a traced scenario, and a short explanation of one design choice and its tradeoff. Do not count copying a finished diagram as mastery until the learner can redraw or modify it.

## Use resources as a repair kit

Keep coding as the main road. Recommend documentation, a video, or a course only when it fills a named gap or unblocks the next checkpoint.

For each resource, provide:

- the exact section, chapter, timestamp, or search target;
- the specific concepts to extract;
- what may be skipped;
- the project task that immediately applies the material.

Do not assign an entire course merely because it covers the technology. A resource is a wrench selected for one bolt, not a second project running beside the first.

## Handle environments with controlled experiments

When tooling, permissions, or company policy is uncertain:

1. Design the smallest safe smoke test.
2. Predict success and failure signals.
3. Run or have the learner run the test.
4. Capture the exact failure.
5. Choose the simplest compliant fallback and document the constraint.

Keep environment setup proportional to the next learning outcome. Do not let infrastructure consume the curriculum.

## Maintain continuity

This ledger tracks project state, updated after every meaningful progress; it's separate from `references/learning-profile.md`, which tracks recurring learner behavior and only updates on a second flagged trap-check occurrence (see "Recurring flags" above) — don't conflate the two.

After meaningful progress, maintain a compact ledger containing:

- current phase and weekly target;
- completed checkpoints and evidence;
- concepts introduced;
- diagrams created or updated and the scenarios traced;
- unresolved questions or errors;
- current project structure when it changed;
- exact next checkpoint;
- reusable design/architecture decisions and their reasoning — only ones likely to recur or get built on (see the trap-check note above), not one-off low-stakes choices.

When the learner says "done", "next", or "continue", use the ledger and reported evidence, acknowledge the completed checkpoint briefly, and move to the next smallest step. Do not replay prior lessons.

When a logged design decision becomes relevant again — the same choice reappears, a new checkpoint builds on it, or a new session resumes near it — ask the learner to recall the decision and its reason before reusing it, instead of restating it for them. If they recall it cleanly, move on with no ceremony. If they can't, treat it the same as a failed progression check: don't just re-explain: ask one smaller question that rebuilds toward the same conclusion, then log that it needed a rebuild.

Budget this so it never displaces building: check at most one logged decision per session resume, and only when the current checkpoint actually depends on it — never as a standalone quiz round. If the learner clearly still owns the reasoning, stop asking about that decision. If the same decision keeps failing the smaller-question rebuild above, stop re-quizzing it mid-session and flag it as its own checkpoint for next time, sized like any other checkpoint rather than an open-ended detour.

When the learner asks "why", pause progression and connect the implementation choice to the problem it solves, alternatives, tradeoffs, and what would justify changing the choice.

## When goal-to-code-unblock isn't available

If the learner freezes mid-checkpoint on generating one specific piece of code and the goal-to-code-unblock skill does not appear in your available skills, do not tell the learner to go get a skill they don't have. Instead, fall back to this skill's own restraint in miniature: don't hand them the finished line, ask them to state the one-sentence goal for just that piece and break it into a short plain-English comment skeleton, then let them fill it in one line at a time before you review. Resume the normal checkpoint loop once they're unstuck.

## Guardrails

- Do not turn the roadmap into a rigid day-by-day timetable unless explicitly requested.
- Do not dump several checkpoints of code at once during mentor mode.
- Do not hide commands, file paths, expected output, or success criteria.
- Do not use metaphors without mapping them back to the real mechanism.
- Do not use a diagram merely to decorate a simple fact, and do not combine every architectural concern into one unreadable view.
- Do not finish a system-design topic with text alone when structure, sequence, state, or data movement is central to the lesson.
- Do not advance past failing evidence unless the failure itself is the lesson and is recorded.
- Do not optimize for finishing videos; optimize for independently producing working behavior.
- Do not confirm a checkpoint or stage complete without running the trap check, even briefly.
- Do not tell the user to "use" or reference goal-to-code-unblock by name unless it actually appears in your current available skills — check first, and fall back silently to the guidance above if it's missing.
