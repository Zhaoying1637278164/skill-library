# Sources on purebhakti.com

purebhakti.com publishes lectures, essays and books of Sri Srimad Bhaktivedanta Narayana
Gosvami Maharaja. All books are the property of their publishers. Link to these pages;
never copy their text beyond one short line.

## Finding Srila Gurudeva's own explanation
- Site search: https://www.purebhakti.com/resources/search
- Bhakti Discourses (lectures, many on Bhagavatam verses and pastimes; HTML pages, easy to read):
  https://www.purebhakti.com/teachers/bhakti-discourses
- Rays of The Harmonist (essays): https://www.purebhakti.com/resources/harmonist-monthly
- Web search pattern: `site:purebhakti.com <topic or verse>` (for example
  `site:purebhakti.com Damodara-lila` or `site:purebhakti.com Venu-gita`)

## Srimad-Bhagavatam: free PDF downloads (Hindi)
Sanskrit verses with translations, in accordance with Vaisnava siddhanta:
- Cantos 1-4 (Part 1):
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/238-srimad-bhagavatam-01-04-cantos-part-1
- Cantos 5-9 (Part 2):
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/1193-srimad-bhagavatam-5-9-cantos-part-2
- Canto 10 (Part 3):
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/1188-srimad-bhagavatam-10th-canto-part-3
- Cantos 11-12 (Part 4):
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/1215-srimad-bhagavatam-11-12-cantos-part-4

Canto 10 with Srila Visvanatha Cakravarti Thakura's commentary, its Hindi bhavanuvada, and
the Bhavaprakasika vrtti:
- Chapters 1-8:
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/250-srimad-bhagavatam-10th-canto-chapters-01-08
- Chapters 9-16:
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/661-srimad-bhagavatam-10th-canto-chapters-09-16

## Books on single Bhagavatam chapters
- Venu-gita (English), Canto 10 Chapter 21, with Srila Gurudeva's commentary:
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/english/43-venu-gita
- Rasa-pancadhyayi (Hindi), Canto 10 Chapters 29-33, with the commentaries of Sri Sridhara
  Svami, Srila Jiva Gosvami and Srila Visvanatha Cakravarti Thakura:
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi/237-rasa-pancadhyayi
- Rasa-pancadhyayi (English, translated from Srila Gurudeva's Hindi edition):
  https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/english-other/1139-rasa-pancadhyayi-2

## All books
- Books in PDF, all languages: https://www.purebhakti.com/resources/ebooks-magazines
- English books: https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/english
- Hindi books: https://www.purebhakti.com/resources/ebooks-magazines/bhakti-books/hindi
- Books for e-readers: https://www.purebhakti.com/resources/ebooks-magazines/books-for-e-readers
- Purchase printed books: https://www.purebhakti.com/resources/purchase-books
