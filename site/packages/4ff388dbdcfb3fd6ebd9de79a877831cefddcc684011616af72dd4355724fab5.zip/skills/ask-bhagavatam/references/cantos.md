# The 12 Cantos: main topics and where they are

Chapter numbers follow the common editions. Verse numbers can differ by one or two
between editions, so confirm verse numbers from the user's own edition when available.

## Canto 1 (19 chapters): why the Bhagavatam was spoken
- 1.1 The sages of Naimisaranya question Suta Gosvami
- 1.2 Pure devotional service, the highest dharma (1.2.6)
- 1.3 The avataras; Krishna is Bhagavan Himself (1.3.28)
- 1.4-1.6 Vyasa's dissatisfaction; Narada's instruction and his previous life
- 1.7 Asvatthama punished
- 1.8 Kunti's prayers; Pariksit protected in the womb
- 1.9 Bhisma's departure in Krishna's presence
- 1.10-1.11 Krishna departs for Dvaraka and is received there
- 1.13 Vidura instructs Dhrtarastra
- 1.15 The Pandavas retire
- 1.16-1.17 Maharaja Pariksit meets Kali
- 1.18-1.19 Pariksit is cursed; Sukadeva Gosvami arrives

## Canto 2 (10 chapters): Sukadeva begins
- 2.1-2.3 First instructions to Pariksit on hearing about the Lord
- 2.9 Brahma's vision; the four seed verses, catuh-sloki (2.9.32-35 or 33-36)
- 2.10 The ten subjects of the Bhagavatam

## Canto 3 (33 chapters): Vidura, Maitreya, Varaha, Kapila
- 3.1-3.4 Vidura meets Uddhava
- 3.5 onward Maitreya speaks to Vidura
- 3.13 Lord Varaha appears
- 3.15-3.16 Jaya and Vijaya are cursed
- 3.17-3.19 Hiranyaksa is killed
- 3.21-3.24 Kardama Muni and Devahuti
- 3.25-3.33 Lord Kapila teaches His mother Devahuti

## Canto 4 (31 chapters): Daksa, Dhruva, Prthu, Puranjana
- 4.2-4.7 Daksa, Sati and Daksa's sacrifice
- 4.8-4.12 Dhruva Maharaja
- 4.13-4.14 King Vena
- 4.15-4.23 King Prthu
- 4.24 Lord Siva's song to the Pracetas
- 4.25-4.29 The allegory of King Puranjana
- 4.30-4.31 The Pracetas; Narada's instruction

## Canto 5 (26 chapters): Rsabhadeva, Bharata, the universe
- 5.1 Priyavrata
- 5.3-5.6 Lord Rsabhadeva (5.5 His teachings to His sons)
- 5.7-5.8 Bharata Maharaja and the deer
- 5.9-5.14 Jada Bharata and King Rahugana
- 5.16-5.26 The structure of the universe (5.26 the hellish planets)

## Canto 6 (19 chapters): the holy name and Vrtrasura
- 6.1-6.3 Ajamila; the Yamadutas and Visnudutas; glory of the holy name
- 6.4 Daksa's Hamsa-guhya prayers
- 6.5 Narada and the sons of Daksa
- 6.7-6.8 Indra offends Brhaspati; the Narayana-kavaca
- 6.9-6.12 Vrtrasura (6.11 his prayers)
- 6.14-6.17 King Citraketu
- 6.18-6.19 Diti; the pumsavana vow

## Canto 7 (15 chapters): Prahlada and Nrsimha
- 7.1 Why the Lord kills demons; Jaya and Vijaya's births
- 7.2-7.3 Hiranyakasipu
- 7.4-7.7 Prahlada Maharaja (7.5 the nine processes of bhakti; 7.6 he teaches his classmates)
- 7.8 Lord Nrsimhadeva appears
- 7.9 Prahlada's prayers
- 7.11-7.15 Narada instructs Maharaja Yudhisthira

## Canto 8 (24 chapters): Gajendra, the churning, Vamana
- 8.2-8.4 Gajendra the elephant king
- 8.5-8.12 The churning of the ocean (8.7 Lord Siva drinks the poison; 8.8-8.9 Mohini)
- 8.15-8.23 Bali Maharaja and Lord Vamana
- 8.24 Lord Matsya

## Canto 9 (24 chapters): the dynasties
- 9.4-9.5 Ambarisa Maharaja and Durvasa Muni
- 9.10-9.11 Lord Ramacandra
- 9.14 onward The moon dynasty
- 9.18-9.19 King Yayati
- 9.24 The Yadu dynasty; Krishna's appearance introduced

## Canto 10 (90 chapters): Sri Krishna's pastimes
- 10.1-10.3 Kamsa; prayers to the Lord in the womb; Sri Krishna's birth
- 10.5 Nanda Maharaja's festival
- 10.6 Putana
- 10.8 Naming ceremony; Yasoda sees the universe in Krishna's mouth
- 10.9 Damodara-lila: Mother Yasoda binds Krishna
- 10.10 The Yamalarjuna trees
- 10.13-10.14 Brahma's bewilderment and his prayers (10.14.8)
- 10.16-10.17 Kaliya
- 10.21 Venu-gita, the song of the flute
- 10.22 Cira-harana
- 10.23 The wives of the brahmanas
- 10.24-10.27 Govardhana
- 10.29-10.33 Rasa-pancadhyayi (10.31 Gopi-gita)
- 10.35 Yugala-gita
- 10.38-10.39 Akrura comes; Krishna leaves Vraja
- 10.44 Kamsa is killed
- 10.45 Sandipani Muni
- 10.46-10.47 Uddhava in Vraja (10.47 Bhramara-gita)
- 10.52-10.54 Rukmini
- 10.80-10.81 Sudama
- 10.82-10.84 Meeting the Vrajavasis at Kuruksetra
- 10.87 Veda-stuti, the prayers of the Vedas

## Canto 11 (31 chapters): Uddhava-gita
- 11.1 The curse on the Yadu dynasty
- 11.2-11.5 King Nimi and the nine Yogendras
- 11.6 Uddhava's request
- 11.7-11.9 The avadhuta's 24 gurus
- 11.12-11.29 Sri Krishna's teachings to Uddhava (11.14 bhakti is supreme; 11.23 the song of the Avanti brahmana)
- 11.30-11.31 The Lord's departure

## Canto 12 (13 chapters): Kali-yuga and the conclusion
- 12.1-12.3 Kali-yuga, its kings and faults; chanting the Lord's name as the remedy (12.3.51)
- 12.5 Sukadeva's final instruction to Pariksit
- 12.6 Maharaja Pariksit's departure
- 12.8-12.10 Markandeya Rsi
- 12.12-12.13 Summary and glories of Srimad-Bhagavatam
