# Shrimad Bhagwatam Guide – Srila BV Narayan Goswami Maharaj

Ask any question from all 12 Cantos of Srimad-Bhagavatam and get a simple, warm answer in
your own language, in the line of Sri Srimad Bhaktivedanta Narayana Gosvami Maharaja and
the Gaudiya Vaisnava acaryas.

Every answer gives:
- the Canto, Chapter and Verse
- who is speaking to whom
- a short answer, a simple explanation, and an everyday example
- a link to read more on purebhakti.com

## Try asking
- "What is in each Canto?"
- "Tell me Dhruva Maharaja's story"
- "Explain SB 10.14.8 in simple words"
- "Damodara-lila kya hai? Hindi mein samjhaiye"
- "Prepare a 30-minute Bhagavatam class on 1.2.6"
- "Give me a Bhagavatam verse for today"

Works in English, Hindi, Hinglish, Bengali and other languages.

## Where the answers come from
1. Your own copy of the book: download Srila Narayana Gosvami Maharaja's Srimad-Bhagavatam
   free from purebhakti.com and attach it to your chat for the most exact answers.
2. purebhakti.com: when web access is on, the guide looks for Srila Gurudeva's own lectures
   and books there and links to them.
3. Otherwise, a general explanation in the Gaudiya line, clearly labelled as such.

The guide never invents quotes, stories or verse numbers.

## Respect for the books
This plugin contains no text from any book. All books of Sri Srimad Bhaktivedanta Narayana
Gosvami Maharaja belong to their publishers and are freely available at
https://www.purebhakti.com. The guide quotes at most one short line at a time and always
points devotees to read the book itself. Please support the publishers by reading and
purchasing their books.

This is an independent, unofficial helper made with respect for devotees. It is not
affiliated with or endorsed by purebhakti.com or its publishers. It is an AI helper, not a
guru or spiritual authority. For initiation and personal spiritual guidance, please approach
senior Vaisnavas.

## Privacy
This plugin collects no personal data and sends nothing to its author. It runs inside Claude.
When web access is available, it may search or open public pages on purebhakti.com to find
sources. Your conversations are handled by Claude under Anthropic's own privacy policy.

## Made by
Nimaii Innovations. Questions or corrections: please open an issue on this GitHub repository.

Hare Krishna 🙏
