# stackql-skills

A [Claude Code](https://claude.ai/code) plugin that adds StackQL-powered skills for querying cloud infrastructure, exploring provider schemas, managing deployments, and more.

## Installation

### From GitHub

Add the repository as a plugin source and install:

```
/plugin marketplace add stackql/stackql-skills
/plugin install stackql-skills@stackql-skills
```

This registers the GitHub repo as a marketplace and installs the plugin. Skills will be available as `/stackql-skills:<skill-name>` in all future sessions.

### Updating

To pull the latest version, update the marketplace first and then the plugin:

```
/plugin marketplace update stackql-skills
/plugin update stackql-skills@stackql-skills
```

## Skills

### `install-stackql`

Install or update the StackQL CLI. Detects the platform and uses the appropriate package manager or installer.

```
/stackql-skills:install-stackql
/stackql-skills:install-stackql --update
```

### `pull-provider`

Pull one or more StackQL providers from the registry. Supports version pinning with `name@version` syntax. Use `--list` to see all available providers.

```
/stackql-skills:pull-provider google
/stackql-skills:pull-provider aws azure github
/stackql-skills:pull-provider okta@v23.03.00121
/stackql-skills:pull-provider --list
```

### `query`

Run StackQL queries against cloud and SaaS providers. Accepts raw SQL or natural language questions. Supports SELECT, INSERT, UPDATE, DELETE, and EXEC operations.

```
/stackql-skills:query SELECT id, status FROM google.compute.instances WHERE project = 'my-project' AND zone = 'us-central1-a'
/stackql-skills:query "what EC2 instances are running in us-east-1?"
/stackql-skills:query SHOW SERVICES IN aws
```

### `explore`

Navigate the StackQL provider hierarchy interactively. Discover services, resources, methods, and fields for any provider.

```
/stackql-skills:explore google
/stackql-skills:explore google.compute
/stackql-skills:explore google.compute.instances
/stackql-skills:explore "how do I manage S3 buckets?"
```

### `stackql-docs`

Search StackQL documentation, provider registry docs, and blog posts.

```
/stackql-skills:stackql-docs window functions
/stackql-skills:stackql-docs "how do I authenticate with Azure?"
/stackql-skills:stackql-docs stackql-deploy manifest format
```

### `read-memories`

Search past Claude Code session logs to recover context from previous conversations - decisions made, patterns established, open TODOs.

```
/stackql-skills:read-memories stackql --here
```

### `auth-setup`

Configure authentication for StackQL providers. Walks through credential setup for Google, AWS, Azure, GitHub, and other providers.

```
/stackql-skills:auth-setup google
/stackql-skills:auth-setup aws
/stackql-skills:auth-setup azure
```

### `notebook`

Create a complete StackQL Jupyter notebook using the `pystackql` magic commands (`%stackql` / `%%stackql`). Generates setup cells, provider pulls, parameterized queries with `$variable` substitution, and optional visualizations.

```
/stackql-skills:notebook "GitHub repo analytics for stackql org"
/stackql-skills:notebook google.compute.instances
/stackql-skills:notebook "AWS S3 bucket inventory" --server
```

Requires `pystackql` (`pip install pystackql`).

### `notebook-cell`

Add StackQL query cells to an existing pystackql notebook. Creates a markdown heading cell, a `%%stackql` query cell, and an optional visualization cell.

```
/stackql-skills:notebook-cell "show all running instances by zone"
/stackql-skills:notebook-cell "SELECT name, status FROM google.compute.instances WHERE project = '$project' AND zone = '$zone'" --viz bar
```

### `scaffold-stack`

Generate a stackql-deploy stack with a `stackql_manifest.yml` and `.iql` resource files for provisioning cloud infrastructure.

```
/stackql-skills:scaffold-stack "VPC with two subnets in Google Cloud"
/stackql-skills:scaffold-stack google.compute.networks
```

### `setup-ci`

Generate CI/CD pipeline configuration for stackql-deploy stacks. Creates workflows for build, test, and teardown.

```
/stackql-skills:setup-ci
/stackql-skills:setup-ci --provider github-actions --stack my-network
```

## Local development

To test skills locally from a clone of this repo:

```bash
# 1. Clone the repo
git clone https://github.com/stackql/stackql-skills.git
cd stackql-skills

# 2. Launch Claude Code with the local plugin directory
claude --plugin-dir .
```

This loads the plugin from disk instead of the marketplace, so any edits to `skills/*/SKILL.md` take effect immediately - just start a new conversation (or re-run the slash command) to pick up changes.

You can test individual skills directly:

```
/stackql-skills:explore google
/stackql-skills:query SHOW PROVIDERS
/stackql-skills:stackql-docs authentication
```

**Prerequisites:** StackQL CLI must be installed. If it isn't, the skills will offer to install it via `/stackql-skills:install-stackql`.

## How the skills work together

Skills reference each other where it makes sense:

- `query`, `explore`, and `auth-setup` all check for StackQL installation and delegate to `install-stackql` if needed
- `query` and `explore` check for pulled providers and delegate to `pull-provider`
- `query` checks for auth and delegates to `auth-setup` when credentials are missing
- `notebook` uses `explore` patterns to discover schemas and generates `pystackql` magic cells
- `notebook-cell` reads existing notebooks to understand context (variables, providers) before adding cells
- `scaffold-stack` uses `explore` patterns to discover resource schemas
- `setup-ci` reads `stackql_manifest.yml` created by `scaffold-stack`
- All skills use `stackql-docs` for error troubleshooting

## Platform support

These skills work on **macOS**, **Linux**, and **Windows**. The StackQL CLI supports all three platforms.

## Reporting issues and suggestions

Found a bug or have an idea for improvement? Open an issue at:

**https://github.com/stackql/stackql-skills/issues**

For StackQL-specific bugs (provider issues, SQL errors), please include the StackQL version (`stackql --version`) and the full error message.
