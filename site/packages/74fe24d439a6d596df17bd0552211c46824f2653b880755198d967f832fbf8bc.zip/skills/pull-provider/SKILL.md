---
name: pull-provider
description: "Pull one or more StackQL providers from the registry. Supports version pinning with name@version syntax. Lists available providers when called with --list.\n"
argument-hint: "<provider1> [provider2@version] [--list]"
allowed-tools: Bash
---

Arguments: `$@`

## Step 1 - Check StackQL is installed

```bash
command -v stackql
```

If not found, delegate to `/stackql-skills:install-stackql` and then continue.

## Step 2 - Handle --list flag

If `--list` is in `$@`, list all available providers:

```bash
stackql exec "REGISTRY LIST;" --output json
```

Present the results as a table showing provider name and version, then stop.

## Step 3 - Show currently installed providers

```bash
stackql exec "SHOW PROVIDERS;" --output json
```

Note which providers are already installed so you can report additions vs updates.

## Step 4 - Pull each provider

For each argument in `$@`:

- `name` -> `REGISTRY PULL name;`
- `name@version` -> `REGISTRY PULL name v<version>;`

Run each pull command:

```bash
stackql exec "REGISTRY PULL <provider>;"
```

Or with a version:

```bash
stackql exec "REGISTRY PULL <provider> v<version>;"
```

## Step 5 - Verify

After pulling, verify the providers are available:

```bash
stackql exec "SHOW PROVIDERS;" --output json
```

## Step 6 - Report

For each provider pulled, report success or failure. If successful, suggest next steps:

> Provider `<name>` is ready. Next steps:
> - Set up auth: `/stackql-skills:auth-setup <name>`
> - Explore services: `/stackql-skills:explore <name>`
> - Run a query: `/stackql-skills:query "SELECT ... FROM <name>.<service>.<resource> WHERE ..."`
