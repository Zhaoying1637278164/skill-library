---
name: stackql-docs
description: "Search StackQL documentation, provider registry docs, and blog posts. Fetches content from stackql.io/docs, registry.stackql.io, and provider-specific doc sites.\n"
argument-hint: "<question or keyword>"
allowed-tools: Bash, WebFetch, WebSearch
---

You are helping the user find relevant StackQL documentation.

Query: `$@`

Follow these steps in order.

## Step 1 - Classify the query

Determine what kind of documentation the user needs:

- **StackQL core** (SQL syntax, CLI flags, commands, general usage) -> search stackql.io/docs
- **Provider-specific** (how to query a specific provider, resource schemas, auth for a provider) -> search the provider docs site
- **Registry** (available providers, versions) -> search registry.stackql.io
- **Blog/tutorials** (how-to guides, examples, use cases) -> search stackql.io/blog
- **stackql-deploy** (IaC workflows, manifests, deployment) -> search stackql-deploy.io

## Step 2 - Determine the documentation URLs

| Topic | Primary URL |
|-------|------------|
| Core docs | `https://stackql.io/docs` |
| CLI reference | `https://stackql.io/docs/command-line-usage/global-flags` |
| Registry commands | `https://stackql.io/docs/command-line-usage/registry` |
| Provider registry | `https://registry.stackql.io/` |
| Google provider | `https://google.stackql.io/` |
| AWS provider | `https://awscc.stackql.io/` |
| Azure provider | `https://azure.stackql.io/` |
| GitHub provider | `https://github.stackql.io/` |
| Okta provider | `https://okta.stackql.io/` |
| Databricks provider | `https://databricks-workspace.stackql.io/` |
| Snowflake provider | `https://snowflake.stackql.io/` |
| stackql-deploy | `https://stackql-deploy.io/docs` |
| Blog | `https://stackql.io/blog` |

## Step 3 - Search for documentation

Use web search to find relevant documentation pages:

Search for: `site:stackql.io <query terms>` or the appropriate provider site.

If the query is provider-specific, also search: `site:<provider>.stackql.io <query terms>`

## Step 4 - Fetch and extract relevant content

For the most relevant search results (up to 3-4 pages), fetch the page content:

Use the WebFetch tool to retrieve the documentation page content.

Extract the relevant sections that answer the user's question.

## Step 5 - Handle common topics directly

For frequently asked topics, you can provide answers from your knowledge:

### StackQL SQL syntax basics
- `SELECT` reads cloud resources (maps to GET/LIST API calls)
- `INSERT INTO ... SELECT` creates resources (maps to POST/PUT)
- `UPDATE ... SET ... WHERE` modifies resources (maps to PATCH/PUT)
- `DELETE FROM ... WHERE` removes resources (maps to DELETE)
- `EXEC <resource>.<method>` runs lifecycle operations (start, stop, etc.)

### Provider hierarchy
- `SHOW PROVIDERS;` - list installed providers
- `SHOW SERVICES IN <provider>;` - list services
- `SHOW RESOURCES IN <provider>.<service>;` - list resources
- `DESCRIBE <provider>.<service>.<resource>;` - show fields
- `SHOW METHODS IN <provider>.<service>.<resource>;` - show methods

### CLI usage
- Interactive: `stackql shell --auth="${AUTH}"`
- Non-interactive: `stackql exec --auth="${AUTH}" "<SQL>"`
- From file: `stackql exec --auth="${AUTH}" -i script.iql`
- Output formats: `--output json|csv|table|text`

## Step 6 - Present results

For each relevant documentation section found, format as:

```
### <Section title>
<URL>

<Relevant content>
```

After presenting the sources, synthesize a concise answer to the user's original question. If the documentation directly answers the question, lead with the answer before showing the sources.

If no relevant documentation was found, suggest:
- Visiting https://stackql.io/docs directly
- Checking the provider-specific docs site
- Using `/stackql-skills:explore <provider>` to discover resources interactively
