---
name: read-memories
description: "Search past Claude Code session logs to recover your own context. Invoke this proactively when you need to recall past decisions, patterns, or unresolved work - either across all projects or scoped to the current one.\n"
argument-hint: <keyword> [--here]
allowed-tools: Bash
---

Use this to recover your own context from past sessions. Do NOT narrate the
process to the user - silently run the query, absorb the results, and continue
with enriched context.

`$0` is the keyword to search for.
Pass `--here` as a second argument (`$1`) to scope the search to the current project only.

## Step 1 - Set the search path

```bash
ALL_PROJECTS="$HOME/.claude/projects/*/*.jsonl"
CURRENT_PROJECT="$HOME/.claude/projects/$(echo "$PWD" | sed 's|[/_]|-|g')/*.jsonl"
```

Use `$CURRENT_PROJECT` if `$1` is `--here`, otherwise use `$ALL_PROJECTS`.

## Step 2 - Query

Use grep to search through the JSONL session logs:

```bash
grep -r -l "<KEYWORD>" <SEARCH_PATH> 2>/dev/null
```

Then for each matching file, extract relevant context:

```bash
grep -i "<KEYWORD>" <FILE> | head -40
```

Replace `<SEARCH_PATH>` and `<KEYWORD>` with the resolved values before running.

## Step 3 - Handle large result sets

If Step 2 returns more than 40 matches or the output is very large, narrow down:

- Add more specific search terms
- Scope to the current project with `--here`
- Filter by date if relevant

## Step 4 - Internalize

From the results, extract:
- Decisions made and their rationale
- Patterns and conventions established
- Unresolved items or open TODOs
- Any corrections the user made to your prior behavior

Use this to inform your current response. Do not repeat back the raw logs to the user.
