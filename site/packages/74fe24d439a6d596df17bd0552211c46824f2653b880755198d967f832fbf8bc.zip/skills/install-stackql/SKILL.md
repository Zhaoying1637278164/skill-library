---
name: install-stackql
description: "Install or update the StackQL CLI. Detects the platform and uses the appropriate package manager or installer. Pass --update to check for and apply updates.\n"
argument-hint: "[--update]"
allowed-tools: Bash
---

Arguments: `$@`

## Step 1 - Check if StackQL is already installed

```bash
STACKQL=$(command -v stackql)
```

If found, get the current version:

```bash
"$STACKQL" --version
```

## Step 2 - Determine mode

- If `--update` is in `$@` -> **update mode**
- Otherwise -> **install mode**

## Step 3 - Install or update

### Install mode

If StackQL is already installed, report the version and stop.

If not installed, detect the platform and install:

**macOS (brew available):**
```bash
brew install stackql
```

**macOS (no brew):**
```bash
curl -L https://bit.ly/stackql-zip -O && unzip stackql-zip
```

**Linux:**
```bash
curl -L https://bit.ly/stackql-zip -O && unzip stackql-zip
sudo mv stackql /usr/local/bin/
```

**Windows (choco available):**
```bash
choco install stackql
```

**Windows (no choco):**
Tell the user to download the MSI installer from the StackQL releases or use `winget` if available.

After install, verify:

```bash
stackql --version
```

### Update mode

Check the currently installed version:

```bash
CURRENT=$(stackql --version 2>&1)
```

Attempt the update using the same platform-appropriate method:

- macOS (`brew` available): `brew upgrade stackql`
- Linux: re-download and replace the binary
- Windows (`choco` available): `choco upgrade stackql`

After update, verify and report the new version:

```bash
stackql --version
```

## Step 4 - Report

Report success or failure. If the install succeeded, suggest next steps:

> StackQL is installed. To get started:
> - Pull a provider: `/stackql-skills:pull-provider google`
> - Set up auth: `/stackql-skills:auth-setup google`
> - Explore resources: `/stackql-skills:explore google`
