---
name: explore
description: "Navigate the StackQL provider hierarchy interactively. Discover services, resources, methods, and fields for any provider. Use natural language or direct provider paths.\n"
argument-hint: "<provider[.service[.resource]]> [question]"
allowed-tools: Bash
---

You are helping the user explore StackQL providers to discover available services, resources, and their schemas.

Input: `$@`

Follow these steps in order.

## Step 1 - Check StackQL is installed

```bash
command -v stackql
```

If not found, delegate to `/stackql-skills:install-stackql` and then continue.

## Step 2 - Parse the input

Determine what level of the hierarchy the user wants to explore:

- **Just a provider name** (e.g., `google`, `aws`) -> show services
- **Provider.service** (e.g., `google.compute`) -> show resources
- **Provider.service.resource** (e.g., `google.compute.instances`) -> show fields and methods
- **Natural language** (e.g., "how do I manage S3 buckets in AWS?") -> identify the provider and navigate to the relevant resource

## Step 3 - Ensure the provider is pulled

```bash
stackql exec "SHOW PROVIDERS;" --output json
```

If the target provider is not installed, delegate to `/stackql-skills:pull-provider <provider>` and then continue.

## Step 4 - Explore the hierarchy

### Level 1: Provider -> Services

```bash
stackql exec "SHOW SERVICES IN <provider>;" --output json
```

Present as a list. If the user included a question or keyword, filter to relevant services using LIKE:

```bash
stackql exec "SHOW SERVICES IN <provider> LIKE '%<keyword>%';" --output json
```

### Level 2: Service -> Resources

```bash
stackql exec "SHOW RESOURCES IN <provider>.<service>;" --output json
```

Present as a list with resource names and descriptions.

### Level 3: Resource -> Fields and Methods

Show the resource schema:

```bash
stackql exec "DESCRIBE <provider>.<service>.<resource>;" --output json
```

Show available methods (what SQL operations map to which API calls):

```bash
stackql exec "SHOW METHODS IN <provider>.<service>.<resource>;" --output json
```

Present the fields as a table (name, type, description) and list the available methods with their SQL verb mappings (SELECT, INSERT, DELETE, EXEC, etc.).

### Level 4: Extended details

If the user asks for more detail on a specific resource:

```bash
stackql exec "DESCRIBE EXTENDED <provider>.<service>.<resource>;" --output json
```

This shows additional metadata including required parameters and provider-specific details.

## Step 5 - Suggest example queries

Based on the resource being explored, generate 2-3 example StackQL queries the user could run:

For a SELECT-capable resource:
```sql
SELECT <key_fields>
FROM <provider>.<service>.<resource>
WHERE <required_params>;
```

For an INSERT-capable resource:
```sql
INSERT INTO <provider>.<service>.<resource> (<fields>)
SELECT <values>;
```

For EXEC methods:
```sql
EXEC <provider>.<service>.<resource>.<method>
@param1 = 'value1';
```

## Step 6 - Offer navigation

After presenting results, suggest what the user can do next:

- Drill deeper into a specific service or resource
- Run a query: `/stackql-skills:query <example>`
- Search docs: `/stackql-skills:stackql-docs <topic>`
- Set up auth if not configured: `/stackql-skills:auth-setup <provider>`
