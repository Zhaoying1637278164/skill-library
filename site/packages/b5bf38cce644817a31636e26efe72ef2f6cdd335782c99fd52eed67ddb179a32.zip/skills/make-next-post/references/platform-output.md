# Platform Output Packages

## Instagram

Return the Reel/carousel/static format, spoken or slide-by-slide body, caption, CTA, visual opening, on-screen text, and production notes. Optimize for reach plus shares, saves, and engagement relative to the creator's Instagram baseline.

## TikTok

Return the opening frame, spoken hook, complete script, caption, CTA, visual beats, pacing, and production notes. Make the premise legible immediately without relying on the caption.

## YouTube Shorts

Return the spoken hook, complete script, title options, CTA, visual beats, pacing, and production notes. Make the payoff explicit and preserve retention through the ending.

## YouTube long-form

Return the title, thumbnail concept, opening hook, structured outline or full script as requested, retention resets, CTA, description, and production notes.
