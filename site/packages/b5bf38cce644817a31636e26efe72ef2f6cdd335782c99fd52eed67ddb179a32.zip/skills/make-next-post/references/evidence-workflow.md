# Evidence Workflow

## Internal evidence first

Compare candidates across six dimensions:

1. Audience demand: comments, demand gaps, and audience-need paths.
2. Proven mechanism: connections to posts that materially outperformed the creator's baseline.
3. Contrast: similar posts that missed, including format or angle differences.
4. Novelty: nearest hook and claim similarity, not merely topic overlap.
5. Timing: recent territory momentum, fatigue, saturation, and newest relevant evidence.
6. Platform fit: format and performance history on the selected platform.

Generate five candidates that vary the underlying angle or mechanism, not only wording. Select privately and explain the winner with traceable evidence paths.

## Conditional external research

Research externally when any condition is true:

- The user asks about what is current, trending, or happening now.
- Fewer than five relevant internal posts exist.
- The newest relevant hit is more than 45 days old.
- The tool returns `coverage.status = "insufficient"`.

Search the selected platform first. Prefer normalized outliers over raw high-view accounts. Transcribe no more than two videos, then use their mechanics as evidence rather than copying their ideas or wording.

If both internal and external evidence remain empty, produce a best-effort package, label the evidence limitation, list it under uncertainties, and do not invent metrics or citations.

## Preflight

Re-check the completed hook and angle. If the nearest hook similarity is at least `0.95`, change the angle or promise—not just synonyms. If evidence conflicts, state the uncertainty instead of inventing confidence.
