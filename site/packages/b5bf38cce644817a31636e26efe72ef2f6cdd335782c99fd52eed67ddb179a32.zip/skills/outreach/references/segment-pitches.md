# Segment pitches

The framing per segment, verbatim from the GTM playbook. Pick by what the
lead IS, not by which platform you found them on. Never pitch Mysocial as
"AI social media analytics" - that phrase kills replies.

| Segment | They are | Open with |
|---|---|---|
| Creator | An individual living off content | "Stop creating from zero" - their next post should start from what already worked for them. |
| Educator | Courses, coaching, teaching businesses | "You've already created years of content" - their archive is an asset they are not using. |
| Founder | An expert/founder-led brand | "Turn your expertise archive into an asset" - their knowledge compounds when their content memory does. |
| Agency | Manages other people's accounts | "Stop relearning every client's brain" - client memory that survives staff churn. |

Brand collab outreach (a creator pitching a brand) inverts the frame: lead
with the creator's fit for the brand's audience - a real overlap, a real
post that proves it - not with Mysocial at all.

## Draft shape

- Line 1: the personal observation (their post, their number, their gap).
- Line 2-3: the segment frame, in one sentence, in plain words.
- Last line: one small ask (a look, a reply, 15 minutes - never "a call to
  discuss synergies").
