# Query Ideation

How to compose a `search_universe` query. Reach for it when `explore_topic` has been
exhausted and you need a broader or more specific semantic search.

- Prefer a `keywordId` or `clusterId` from `get_topics`; this preserves creator lineage.
- Use the audience’s phrasing rather than internal strategy language.
- Keep one intent per query and prefer three to six concrete words.
- Search a direct phrase first. Add an adjacent or pain/desire phrasing only when it answers a distinct part of the user’s question.
- Do not search private channel information externally; use the creator’s own-content tools instead.
