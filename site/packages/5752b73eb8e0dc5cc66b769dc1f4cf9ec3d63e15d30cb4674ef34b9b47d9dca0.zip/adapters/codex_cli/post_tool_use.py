from __future__ import annotations

from contextlib import ExitStack
import json
from pathlib import Path
import runpy
import sys

def _fail_open(message: str) -> int:
    data = json.dumps({"systemMessage": f"[smtw] fail-open(게이트 오류, 통과 처리): {message}"}, ensure_ascii=False)
    _ = sys.stdout.buffer.write(data.encode("utf-8"))
    _ = sys.stdout.buffer.write(b"\n")
    return 0


def main() -> int:
    common: dict[str, object] = {}
    cache_stack = ExitStack()
    try:
        root = Path(__file__).resolve().parents[2]
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        common = runpy.run_path(str(Path(__file__).with_name("common.py")))
        payload = common["read_payload"]()
        from core.ledger import ledger_read_cache

        cache_stack.enter_context(ledger_read_cache())
        from core.adapter_observation import observe_post_tool, resolve_active_invocation, verification_covers
        from core.classify import classify_prompt
        from core.contract import EDIT_TOOLS, SHELL_TOOLS, record_contract_authored_event
        from core.ledger import load_ledger, record_event_if_current_turn
        from core.provenance_types import ProvenanceStatus
        from core.scope_guard import evaluate_scope
        from core.verification import is_verification_command

        root = common["project_root"](payload)
        tool = payload.get("tool_name")
        family = "edit" if tool in EDIT_TOOLS else "shell" if tool in SHELL_TOOLS else "other"
        if family != "other":
            command = common["tool_command"](payload)
            invocation = common["canonical_invocation"](
                payload,
                "post_tool",
                family,
                common["tool_file_paths"](payload),
                command,
                common["tool_success"](payload),
                common["tool_output"](payload),
            )
            invocation = resolve_active_invocation(Path(root), invocation)
            # CODEX-02: promote a resolved recovered identity's attribution before
            # recording contract authorship, matching
            # adapters/claude_code/post_tool_use.py. Without this, a recovered
            # identity's own namespaced-contract edit is recorded as
            # attribution=legacy_default and the contract_authored audit event never
            # cross-checks against a subsequent exact-identity high-risk edit.
            attribution = invocation.scorecard_attribution
            if attribution == "legacy_default" and invocation.session_id != "default":
                attribution = "exact"
            if family == "edit" and not invocation.identity_conflict:
                record_contract_authored_event(
                    {
                        "project_root": root,
                        "file_paths": common["tool_file_paths"](payload),
                        "host": invocation.host,
                        "agent": invocation.agent,
                        "session_id": invocation.session_id,
                        "turn_id": invocation.turn_id,
                        "attribution": attribution,
                    }
                )
            observation = observe_post_tool(Path(root), invocation)
            verification_command = family == "shell" and is_verification_command(command)
            if observation.error_kind == "StaleTurn":
                return common["emit"](
                    {"systemMessage": "[smtw] provenance incomplete; fail-open observation."}
                )
            if verification_command:
                covers = verification_covers(Path(root), invocation)
                verification = {
                    "project_root": root,
                    "event": "verification",
                    "host": invocation.host,
                    "agent": invocation.agent,
                    "session_id": invocation.session_id,
                    "turn_id": invocation.turn_id,
                    "invocation_id": invocation.invocation_id,
                    "command": command,
                    "success": invocation.success,
                    "evidence": invocation.evidence,
                }
                if covers is not None:
                    verification["covers"] = covers
                _ = record_event_if_current_turn(verification, allow_missing=True)
                return common["emit"]({"systemMessage": "[smtw] 원장: 검증 기록 / recorded verification."})
            if observation.status is ProvenanceStatus.SCOPE_TOO_LARGE:
                return common["emit"]({})
            if observation.incomplete:
                return common["emit"](
                    {"systemMessage": "[smtw] provenance incomplete; fail-open observation."}
                )
            paths = list(observation.changed_paths)
            ledger = load_ledger({"project_root": root})
            prompt = ledger.get("prompt")
            prompt_text = prompt if isinstance(prompt, str) else ""
            requested = classify_prompt({"prompt": prompt_text})["requested_paths"] if prompt_text else []
            scope = evaluate_scope(
                {
                    "project_root": root,
                    "prompt": prompt_text,
                    "requested_paths": requested,
                    "changed_files": paths,
                }
            )
            if scope["decision"] == "warn":
                _ = record_event_if_current_turn(
                    {
                        "project_root": root,
                        "event": "scope_warning",
                        "host": invocation.host,
                        "agent": invocation.agent,
                        "session_id": invocation.session_id,
                        "turn_id": invocation.turn_id,
                        "message": scope["message"],
                    },
                    allow_missing=True,
                )
                return common["emit"](
                    {
                        "systemMessage": str(scope["message"]),
                        "hookSpecificOutput": {
                            "hookEventName": "PostToolUse",
                            "additionalContext": str(scope["message"]),
                        },
                    }
                )
            if family == "edit":
                return common["emit"]({"systemMessage": f"[smtw] provenance: observed {len(paths)} change(s)."})
            return common["emit"]({"systemMessage": f"[smtw] provenance: observed {len(paths)} change(s)."})
        return common["emit"]({})
    except Exception as exc:
        runtime_env_fail_closed = common.get("fail_closed_runtime_env")
        if callable(runtime_env_fail_closed):
            denied = runtime_env_fail_closed(exc)
            if denied is not None:
                return denied
        return _fail_open(str(exc))
    finally:
        cache_stack.close()


if __name__ == "__main__":
    raise SystemExit(main())
