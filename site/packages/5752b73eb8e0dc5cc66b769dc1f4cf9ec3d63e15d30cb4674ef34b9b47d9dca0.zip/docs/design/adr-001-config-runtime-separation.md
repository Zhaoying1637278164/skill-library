# ADR-001: 공유 설정(Config)과 런타임 상태(Runtime State)의 분리

> **Status**: Implemented (2026-07-22) — STATE-01 loader와 v3 Q4 tri-state 계약 반영.
> **Context**: Sol 안정화 지시서 §5 STATE-01("v2.4 필수 수정과 섞지 말고 ADR부터").

## 1. 맥락 (Context)

현재 `show-me-the-work` (fable-lite)는 프로젝트 내부의 `.fable-lite/` 단일 디렉토리에 모든 데이터를 저장하고 있습니다. 여기에는 다음과 같은 두 가지 성격의 데이터가 혼재되어 있습니다.

- **공유 설정 (Config)**: `config.json` (opt-in 여부), 정책 및 게이트 설정 (설계상 팀과 공유해야 함)
- **런타임 상태 (Runtime State)**: `ledger.json` (7.8MB에 달하는 대용량 이벤트 로그), `snapshots/`, `agents/` (프롬프트/명령어/에이전트 로그), `scorecard/`, `contracts/`, `goals/` 등

이로 인해 "팀과 supervision 설정을 공유(git commit)하고 싶지만, 로컬에서 생성되는 거대한 agent 로그와 ledger 기록은 커밋하고 싶지 않다"는 상충되는 요구가 충돌합니다. 저장소 전체를 `.gitignore`에 등록하면 설정을 공유할 수 없고, 등록하지 않으면 대용량의 런타임 상태가 Git에 오염되는 심각한 사용성 문제가 발생합니다.

## 2. 대안 분석 (Options)

이 문제를 해결하기 위해 다음 3가지 대안을 평가했습니다.

### (A) `.smtw.toml` 공유 config + 런타임 상태는 `.fable-lite/` 유지
- **설명**: 공유해야 할 설정을 프로젝트 루트의 `.smtw.toml` (또는 `pyproject.toml` 등)로 승격시키고, 런타임 상태(원장, 로그 등)는 기존대로 `.fable-lite/`에 둡니다. 사용자는 `.fable-lite/`를 통째로 `.gitignore`에 추가합니다.
- **Git 추적성 / 팀 공유**: `.smtw.toml`만 커밋하여 명확하게 설정을 팀원과 공유할 수 있습니다.
- **이식성**: 특정 OS나 파일 시스템에 종속되지 않는 표준적인 도구 설정 방식입니다.
- **기존 경로 호환성**: 읽기 시 `.smtw.toml`을 우선 확인하고 없으면 `.fable-lite/config.json`으로 폴백(fallback)하면 기존 설치를 깨지 않고 유연하게 호환할 수 있습니다.
- **멀티에이전트 계약 네임스페이스**: 기존 `contracts/`, `goals/` 경로의 물리적 구조를 그대로 유지할 수 있습니다.
- **홈 세션 처리**: 홈 디렉토리에서도 동일한 논리로 동작합니다.

### (B) `.git/.smtw/` 에 런타임 상태 저장
- **설명**: 공유 설정은 `.fable-lite/` 또는 루트에 두고, 런타임 상태를 `.git/` 디렉토리 내부로 숨깁니다.
- **Git 추적성**: `.git/` 내부는 Git이 자동으로 무시하므로 별도의 `.gitignore` 설정 없이 런타임 상태 커밋을 방지할 수 있습니다.
- **이식성**: **매우 낮음.** 프로젝트가 Git 저장소가 아니거나(단순 폴더 복사), CI 환경에서 `.git` 디렉토리가 없는 경우(얕은 복제 등) 동작이 깨질 위험이 큽니다.
- **기존 경로 호환성**: 마이그레이션이 복잡해집니다.
- **홈 세션 처리**: 홈 디렉토리가 Git 저장소가 아닐 확률이 높으므로 치명적인 결함이 발생합니다.

### (C) `<OS data dir>/smtw/<project-id>/` 에 사용자별 런타임 상태 저장
- **설명**: 런타임 상태를 프로젝트 외부인 `%APPDATA%`, `~/.local/share` 등의 OS 표준 데이터 폴더로 완전히 옮깁니다.
- **Git 추적성**: 프로젝트 폴더 안에 상태가 존재하지 않으므로 Git 오염 우려가 완벽히 사라집니다.
- **이식성**: OS별 경로 처리 추상화가 필요하며, `<project-id>`(예: 절대경로 해시)의 안정성 보장이 어렵습니다(폴더 이동 시 원장 유실).
- **멀티에이전트 계약 네임스페이스**: 전역 폴더 내에서 충돌 관리가 필요하며 디버깅 시 파일 접근 경로가 파편화됩니다.
- **홈 세션 처리**: 홈 세션도 하나의 프로젝트 ID로 취급하면 되지만, fable-lite의 핵심 철학인 "프로젝트별 종속성(Pure-stdlib, 단일 상태 디렉토리)"과 어긋납니다.

## 3. 결정 (Decision)

**대안 (A) `.smtw.toml` 공유 config + 런타임 상태 트리 분리**를 최종 권고안으로 채택합니다.

이 방식은 fable-lite의 기존 아키텍처 철학(프로젝트 내 종속, 0-dependency)을 위반하지 않으면서, 가장 적은 비용으로 팀 공유와 런타임 분리를 달성할 수 있습니다.

## 4. 마이그레이션 경로 및 구현 지침 (Migration & Implementation)

1. **읽기 우선순위 변경**: `[프로젝트 루트]/.smtw.toml` → `pyproject.toml`의 `[tool.smtw]` → 기존 `[프로젝트 루트]/.fable-lite/config.json` 순으로 조회합니다.
2. **명시와 부재 구분**: 각 loader는 `ABSENT`, `VALID`, `DECLARED_INVALID` 중 하나를 반환합니다. 상위 source가 명시됐지만 잘못됐으면 하위로 폴백하지 않습니다. 유효한 pyproject에 섹션이 없거나, malformed pyproject에 실제 `[tool.smtw]` header가 없으면 `ABSENT`로 다음 source를 조회합니다.
3. **동일 schema와 digest**: 세 source 모두 같은 validator와 canonical table digest를 사용합니다. pyproject의 무관한 dependency 변경은 config digest를 바꾸지 않습니다.
4. **.gitignore 추가 권고**: 초기화(CLI `init` 또는 문서) 시점에 사용자가 런타임 상태 트리를 `.gitignore`에 추가하도록 가이드합니다.
5. **비범위 (Out of Scope)**:
   - 본 ADR은 런타임 데이터 구조(원장 스키마 등) 자체의 변경은 포함하지 않습니다. 
   - `goals/`, `contracts/` 등의 내부 구조 개편은 다루지 않으며 선택된 런타임 상태 트리의 내부 구조를 그대로 유지합니다.
