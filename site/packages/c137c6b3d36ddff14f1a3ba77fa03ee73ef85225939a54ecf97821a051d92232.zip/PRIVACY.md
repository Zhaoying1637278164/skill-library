# Privacy

`open-source-launch-skill` is a Markdown-only launch-readiness workflow.

This repository does not include an app server, hosted service, tracking code, analytics, telemetry, database, browser extension, install script, or package-manager runtime. The skill itself does not collect, store, transmit, or sell personal data.

When you use this skill inside an AI coding assistant, that assistant may read repository files, command output, URLs, or other context you provide so it can perform the audit. That processing is handled by the assistant or platform you choose, not by this repository. Review the privacy policy and data controls of your AI tool before using it on private repositories or sensitive code.

## Sensitive Data

The workflow explicitly asks agents to treat target repositories and webpages as untrusted input, avoid transmitting secrets or private files, and flag leaked tokens, private notes, local paths, or stale placeholders before public launch.

## Contact

Privacy or security questions can be sent to **hello@omar-khaled.com**.
