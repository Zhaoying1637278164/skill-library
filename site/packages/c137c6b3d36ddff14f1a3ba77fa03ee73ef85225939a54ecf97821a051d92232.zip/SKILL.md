---
name: open-source-launch
description: Prepare any open-source repository for a clear, trusted public launch. Use when auditing launch readiness, improving README/metadata/proof, choosing launch channels, writing launch copy, or producing a final launch verdict.
---

# Open Source Launch Skill

This root file is the portable/manual entrypoint for agents that load `SKILL.md` directly.

The canonical Claude Code plugin skill lives at [`skills/open-source-launch/SKILL.md`](skills/open-source-launch/SKILL.md). Follow that file for the full workflow.

Reference files live in [`skills/open-source-launch/references/`](skills/open-source-launch/references/):

- [`skills/open-source-launch/references/positioning.md`](skills/open-source-launch/references/positioning.md) for positioning, README conversion, proof, quickstarts, and above-the-fold structure.
- [`skills/open-source-launch/references/metadata.md`](skills/open-source-launch/references/metadata.md) for repo surface, naming, metadata, distribution status, security posture, first-run paths, and verification.
- [`skills/open-source-launch/references/channels.md`](skills/open-source-launch/references/channels.md) for channel selection, launch-day flow, community behavior, post-launch follow-up, and metrics.
- [`skills/open-source-launch/references/launch-copy.md`](skills/open-source-launch/references/launch-copy.md) for launch asset packs, Show HN, Product Hunt, Reddit/community, social, and outreach templates.
- [`skills/open-source-launch/references/failure-modes.md`](skills/open-source-launch/references/failure-modes.md) for verdict format, common failures, and the final quality bar.
