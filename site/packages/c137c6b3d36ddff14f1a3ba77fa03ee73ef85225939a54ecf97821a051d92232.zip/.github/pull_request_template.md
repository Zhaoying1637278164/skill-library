## What Changed

Describe the launch-readiness guidance, reference, or example you changed.

## Why

Explain the launch failure, confusion, or trust gap this addresses.

## Evidence

Include a real project example, public reference, or before/after snippet when possible.

## Checklist

- [ ] I kept this focused on launch clarity, evidence, or trust.
- [ ] I avoided promising stars, votes, or guaranteed attention.
- [ ] I checked that public examples do not include private paths, secrets, or stale launch notes.
