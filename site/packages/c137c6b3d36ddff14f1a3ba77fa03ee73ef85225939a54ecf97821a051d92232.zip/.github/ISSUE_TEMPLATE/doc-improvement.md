---
name: Documentation improvement
about: Improve the skill text, references, or examples
title: "Docs: "
labels: documentation
---

## Where

Point to the section or file that should change.

## Problem

What is unclear, inaccurate, outdated, or too vague?

## Suggested Change

What should the skill say instead?
