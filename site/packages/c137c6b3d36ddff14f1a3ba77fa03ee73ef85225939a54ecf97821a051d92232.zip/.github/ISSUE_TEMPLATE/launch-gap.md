---
name: Launch gap
about: Report a launch-readiness signal this skill missed
title: "Launch gap: "
labels: launch-gap
---

## Project

Link to the public repo, release, demo, or launch post.

## What The Skill Missed

Describe the launch problem that was not caught.

## Evidence

Include the file, command, screenshot, output, or public thread that shows the gap.

## Suggested Check

What readiness check would have caught this before launch?
