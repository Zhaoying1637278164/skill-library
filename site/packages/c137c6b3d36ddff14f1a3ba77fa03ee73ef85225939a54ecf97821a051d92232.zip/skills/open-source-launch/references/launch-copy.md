# Launch Copy Reference

Use this reference when preparing launch assets, social posts, Show HN submissions, Product Hunt comments, Reddit/community posts, or maintainer outreach.

Adapt copy to each channel. Never paste the same promotional text everywhere.

## Launch Asset Pack

Prepare this before writing channel copy:

```text
One-line pitch:
Short description:
Long description:
Primary screenshot/GIF/example output:
Demo link:
First-run command or link:
Three strongest use cases:
Three proof points:
Known limitations:
Primary CTA:
Specific feedback question:
```

Never ask for stars. Ask people to try it, give feedback, or share it with someone who has the problem — stars follow usefulness.

## Show HN Template

Use Show HN when people can try the project without sign-up. See `channels.md` for fit criteria.

```text
Show HN: <project> - <specific outcome for specific users>

I built <project>, a <category> for <audience> who need <outcome>.

It works by <short mechanism>. You can try it with <command/link>.

The repo is here: <url>

I would especially value feedback on <specific question>.
```

Keep it plain. Over-polished copy underperforms on HN.

## Product Hunt First Comment Template

Use when the project has visual/demo proof. See `channels.md` for fit criteria.

```text
Hey Product Hunt,

I built <project> because <pain/problem>.

It helps <audience> <outcome> by <mechanism>.

You can try it here: <demo/repo>

What is included:
- <proof/use case 1>
- <proof/use case 2>
- <proof/use case 3>

I would love feedback on <specific question>.
```

## Reddit Or Community Template

```text
I built <project> for <specific audience/problem>.

The useful part: <technical or practical detail the community cares about>.

Repo/demo: <url>

I am looking for feedback on <specific question>, especially from people who <relevant experience>.
```

Adapt this to the community. If the post would not be useful without the repo link, rewrite it.

## Short Social Template

```text
Launched <project>: <specific outcome for specific users>.

Try it: <command/link>
Repo: <url>

Built for <audience>. Feedback welcome on <specific question>.
```

Pair social copy with a screenshot, GIF, terminal output, example result, or before/after.

## Maintainer Outreach Template

```text
Hey <name>, I built <project>, a <category> that helps <audience> <outcome>.

I thought it might be useful to your audience because <specific reason>.

Repo/demo: <url>

No pressure to share. If you have feedback on <specific question>, I would genuinely appreciate it.
```

Personalize outreach or do not send it.

## Copy Checks

Before publishing, check:

- Does the first sentence say who it helps and what changes?
- Is there one clear CTA?
- Is there a real link, command, or demo?
- Does the post ask for feedback instead of votes?
- Is the copy specific to the channel?
- Does it avoid hype words, fake urgency, and empty claims?
