# Channels And Follow-Up Reference

Use this reference when choosing launch channels, planning launch day, responding to attention, and deciding what to measure.

## Channel Fit

Use channels where the audience already has the problem. Do not create a broad generic launch plan when one focused channel would work better.

Possible channels:

- GitHub only
- package registry, model hub, plugin marketplace, app store, or release archive
- hosted demo, docs, release page, or GitHub Pages
- Show HN
- Product Hunt
- Reddit or niche forums
- X/Twitter, LinkedIn, Mastodon, Bluesky
- Discord, Slack, Telegram, or community groups
- newsletters, blogs, podcasts, or maintainer networks

Match each launch to the project, audience, and maintainer capacity. Skip channels that don't fit.

## Show HN

Use Show HN when people can actually try the project without sign-up. See `launch-copy.md` for the template.

- link directly to the repo or demo
- be present in comments
- do not ask for upvotes
- do not hide the working project behind an email wall

## Product Hunt

Use Product Hunt when the project has a clear demo, visual asset, and maker story. See `launch-copy.md` for the first-comment template.

- prepare tagline, description, maker comment, images, demo, and FAQs
- launch only when the project can handle attention
- respond throughout launch day

## Reddit And Niche Communities

Use niche communities to contribute, not just promote.

- read the rules before posting
- adapt the post to the community
- ask for feedback, not applause
- disclose that you built it
- do not paste the same promotional text everywhere

## Social Platforms

Use social when the idea can be understood quickly through a short demo, screenshot, terminal output, or concrete before/after.

- state the audience and outcome in the first line
- include the repo link and one clear CTA
- tag relevant technologies only when true
- reply to every serious question

## Newsletters, Podcasts, And Maintainers

Personalize outreach. Skip generic pitches.

- explain why their audience would care
- include the repo, demo, and one-sentence summary
- keep the ask small
- do not mass-send generic pitches

## Launch Day Checklist

1. Confirm repo visibility, license, metadata, and topics.
2. Confirm the first-run command, link, or demo still works from a clean environment.
3. Confirm screenshots, GIFs, example outputs, and demo links load.
4. Publish release, tag, artifact, package, page, or listing if applicable.
5. Post to the primary channel first.
6. Stay available for comments, issues, and questions.
7. Fix launch-blocking bugs quickly and publicly.
8. Capture recurring questions for README updates.
9. Share follow-up posts only when they add new context.
10. Record traffic, stars, usage, downloads, issues, PRs, and feedback themes.

Do not launch and disappear. Presence is part of the launch.

## Post-Launch Conversion

After launch, reply quickly to issues and comments, convert recurring questions into docs, label approachable issues for new contributors, and thank specific helpers by name. Measure stars, forks, visitors, clones, issues, PRs, response time, and contribution themes — usage and retention matter more than vanity metrics.
