---
name: peer-identity
description: Use when setting up a Claude Code instance as a specialist peer — defines identity schema, capability advertisement, and discovery conventions
---

# Peer Identity

This skill defines how a Claude Code instance announces itself as a specialist peer on the network.

## On Startup

Call `set_summary` with a structured announcement so other peers can discover you. Then call `check_messages` to process any pending work that arrived while you were offline.

## Capability Schema

Advertise your identity using this structured format:

```json
{
  "role": "designer|reviewer|architect|debugger|custom",
  "capabilities": ["design-review", "token-audit", "code-review", "architecture-review", "debugging"],
  "projects": ["project-ids-this-peer-covers"],
  "availability": "active|busy|offline"
}
```

Include this JSON block in your `set_summary` call so other peers can parse your capabilities programmatically.

## Summary Format

Your summary must be two lines. The first line is a human-readable role description. The second line is the JSON capability block.

Example:

```
Design system reviewer across all portfolio projects.
{"role":"designer","capabilities":["design-review","token-audit","parity-check"],"projects":["project-a","project-b"]}
```

This dual format means both humans and automated routing can understand what you do.

## Discovery

Use `list_peers` with the appropriate scope (`machine`, `directory`, or `repo`) to find other active peers. Match peers by their `capabilities` array when you need to route work to a specialist. If no peer matches the required capability, queue the request or escalate to the user.

## Updating Status

When you become busy with a long-running task, update your summary to reflect `"availability": "busy"`. Reset to `"active"` when done. This prevents other peers from sending you work you cannot process promptly.
