---
name: peer-messaging
description: Use when sending or receiving messages between Claude Code peers — defines request format, review artifact format, and handoff protocol
---

# Peer Messaging

This skill defines how peers communicate: request format, response artifacts, and handoff protocol.

## Request Format

When messaging a peer, structure your request with these fields:

- **project**: Which project this concerns (so the peer loads correct context)
- **ask**: What you need — review, critique, check, question, or handoff
- **context**: Relevant file paths, components, decisions, or code snippets
- **constraints**: Scope limits, deadlines, specific concerns to focus on

Example: "project: my-app | ask: review component spacing | context: src/components/Card.tsx lines 12-45 | constraints: focus on mobile breakpoints only"

## Review Artifact Format

When responding to a review request, return a structured artifact:

```json
{
  "type": "design-review|code-review|architecture-review",
  "scope": ["file1.tsx", "file2.tsx"],
  "findings": [
    {"severity": "critical|warning|info", "file": "path/to/file", "line": 42, "rule": "rule-name", "message": "description of finding"}
  ],
  "summary": "One-paragraph synthesis of the review"
}
```

Severity levels: `critical` blocks merging, `warning` should be addressed, `info` is advisory.

## Handoff Protocol

- Always include the `project` field so the specialist peer loads the right context immediately
- Message status flows: sent -> read -> replied
- If the target peer is offline, the request queues automatically and will be processed when they call `check_messages` on startup
- The requesting peer can call `message_status` to check delivery — they see "pending", not silence

## Response Protocol

When you receive a peer message, **respond immediately**. Pause your current work, reply via `send_message` with your findings or answer, then resume what you were doing. Treat peer messages like a colleague asking a direct question — answer now, not later.
