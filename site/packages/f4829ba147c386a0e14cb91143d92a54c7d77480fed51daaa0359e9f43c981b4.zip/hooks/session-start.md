# Peer Session Start Hook

On session start, if a `peer.json` or CLAUDE.md with peer configuration exists in the working directory:

1. Read peer config (role, capabilities, projects)
2. Call `set_summary` with structured announcement
3. Call `check_messages` for any pending requests
4. Process pending requests before other work
