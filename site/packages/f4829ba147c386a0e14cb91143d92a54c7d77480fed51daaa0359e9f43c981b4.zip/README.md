# @decibelsystems/peers

Peer network patterns for Claude Code agent specialization.

## Installation

```bash
claude plugin add decibelsystems/peers
```

Or clone directly:

```bash
git clone https://github.com/decibelsystems/peers.git
```

## What's Included

- **2 skills** -- `peer-identity` (startup announcement, capability schema, discovery) and `peer-messaging` (request format, review artifacts, handoff protocol)
- **1 hook** -- `session-start` describes the peer initialization sequence
- **4 role templates** -- Ready-to-use CLAUDE.md files for designer, reviewer, architect, and debugger specialists

## Quick Start

Create a directory for your specialist peer, drop in a template CLAUDE.md, and run `claude`:

```bash
mkdir my-reviewer-peer
cp peers/templates/reviewer.md my-reviewer-peer/CLAUDE.md
cd my-reviewer-peer
claude
```

The template tells Claude to announce itself on the peer network, check for pending messages, and respond to requests using structured formats.

## Philosophy

Peers gives agents specialist coordination. How they find each other, how they communicate, how they hand off work.

Each peer is a Claude Code instance with a defined role and capability set. Peers advertise themselves on startup, discover each other via `list_peers`, and exchange structured messages. Reviews come back as parseable artifacts. Handoffs include project context so the receiving peer can start immediately.

The templates are starting points. Customize the role, capabilities, project list, and voice to match your needs.

## Templates

| Template | Role | Capabilities |
|---|---|---|
| `designer.md` | Design system reviewer | design-review, token-audit, parity-check, component-review |
| `reviewer.md` | Code review specialist | code-review, architecture-review, test-coverage |
| `architect.md` | System design advisor | architecture-review, system-design, api-design, data-modeling |
| `debugger.md` | Debugging specialist | debugging, root-cause-analysis, reproduction |

## Credits

Built by [Decibel Systems](https://github.com/decibelsystems).

## License

MIT
