# Slack MCP and Skills Plugin

A [Claude Code][claude-code], [Cursor][cursor], and [Codex][codex-cli] plugin that brings Slack into your AI tools with a [Slack MCP Server][slack-mcp-docs] and set of Slack skills for both users and developers.

[![CI Build](https://github.com/slackapi/slack-skills-plugin/actions/workflows/ci-build.yml/badge.svg)](https://github.com/slackapi/slack-skills-plugin/actions/workflows/ci-build.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## Installation

### Claude Code

The plugin is published on the [official Claude marketplace](https://claude.com/plugins/slack). Install it from inside Claude Code:

```text
/plugin install slack@claude-plugins-official
```

The Slack MCP server is configured automatically. You'll be prompted to authenticate to your Slack workspace via OAuth on first use.

### Cursor

The plugin is published on the [official Cursor Marketplace](https://cursor.com/marketplace/slack). Install it from inside Cursor:

```text
/add-plugin slack
```

This installs the skills, commands, and MCP server together. You'll be prompted to authenticate to your Slack workspace via OAuth on first use.

### Codex

The plugin is published as a Codex marketplace in this repository. Add the marketplace, then install the plugin:

```sh
codex plugin marketplace add slackapi/slack-skills-plugin
codex plugin add slack@slack
```

Start a new Codex session to pick up the plugin, then invoke a skill by name with a `$` mention, for example `$block-kit`.

Codex support currently ships the skills only; the MCP server is not yet wired into the Codex surface.

### Other agents

The skills install into other coding agents with [`npx skills`][npx-skills], no plugin marketplace required:

```bash
# Install the skills for a coding agent, named by its own identifier
npx skills add slackapi/slack-skills-plugin -y -a <agent>

# For example, Gemini CLI or OpenCode
npx skills add slackapi/slack-skills-plugin -y -a gemini-cli
npx skills add slackapi/slack-skills-plugin -y -a opencode
```

Other popular agents include `crush`, `devin`, `hermes-agent`, `openclaw`, and `pi`. See [supported agents][npx-skills] for the full list of agents and their identifiers. Add `-g` to install for your user instead of the current project.

The `-y` flag installs every skill without prompting. Drop it to choose skills from a list, or pass `-s <skill>` to name the ones you want.

This path carries the skills only: no commands, and no MCP server.

## Features

### MCP Server

The plugin connects your AI tool to Slack's hosted [MCP server][slack-mcp-docs]:

- **Search** - find messages, files, users, and channels (public and private)
- **Messaging** - send and schedule messages, read channels, follow threads, add reactions
- **Canvas** - create, read, and update canvas documents
- **Users** - read profiles and list channel members

### Skills

Six skills load on demand to handle messaging tasks and developer workflows:

- [`slack:slack-messaging`](skills/slack-messaging/SKILL.md) - composing well-formatted, effective Slack messages
- [`slack:slack-search`](skills/slack-search/SKILL.md) - finding messages, files, channels, and people
- [`slack:slack-api`](skills/slack-api/SKILL.md) - discovering and calling Slack Web API methods
- [`slack:slack-cli`](skills/slack-cli/SKILL.md) - using the [Slack CLI][slack-cli] to create, run, and manage apps
- [`slack:create-slack-app`](skills/create-slack-app/SKILL.md) - building a Slack app or agent with the CLI and [Bolt][bolt]
- [`slack:block-kit`](skills/block-kit/SKILL.md) - building and validating [Block Kit][block-kit] layouts

### Commands

Five slash commands for common Slack workflows:

- `/slack:summarize-channel <channel-name>` - Summarize recent activity in a Slack channel
- `/slack:find-discussions <topic>` - Find discussions about a specific topic across Slack channels
- `/slack:draft-announcement <topic>` - Draft a well-formatted Slack announcement and save it as a draft
- `/slack:standup` - Generate a standup update based on your recent Slack activity
- `/slack:channel-digest <channel1, channel2, ...>` - Get a digest of recent activity across multiple Slack channels

## Usage examples

Once installed, talk to your tool in natural language:

- "Search for messages about the product launch from the last week"
- "Send a message to #general saying the deployment is complete"
- "Summarize the last day of activity in #engineering"
- "Draft an announcement about the new pricing page"
- "Create a new Slack app using Bolt for Python"
- "Build a Block Kit feedback modal with a rating select and a comments field"
- "Validate the Block Kit JSON in ./modal.json"

## Documentation

- [Slack MCP server][slack-mcp-docs]
- [Slack developer docs](https://docs.slack.dev/)
- [Block Kit Builder][block-kit]

## Limitations

- **Workspace admin approval.** Your Slack workspace admin must approve MCP integration before you can authenticate.

## Contributing

We welcome contributions from everyone! Please check out our [contributor's guide](.github/contributing.md) for guidelines on opening issues and pull requests.

Working on the plugin itself? See the [maintainer's guide](.github/maintainers_guide.md) for local development setup.

[claude-code]: https://claude.com/claude-code
[cursor]: https://cursor.com
[codex-cli]: https://developers.openai.com/codex/cli
[slack-mcp-docs]: https://docs.slack.dev/ai/mcp-server/
[npx-skills]: https://github.com/vercel-labs/skills#supported-agents
[slack-cli]: https://tools.slack.dev/slack-cli
[bolt]: https://tools.slack.dev/bolt-js
[block-kit]: https://app.slack.com/block-kit-builder
