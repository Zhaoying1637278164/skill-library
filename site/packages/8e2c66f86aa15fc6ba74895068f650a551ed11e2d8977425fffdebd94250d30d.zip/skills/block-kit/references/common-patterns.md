# Common Block Kit Patterns

> Starting scaffolds for frequent use cases — copy one and customize rather than building from scratch.
> They were valid when written, but the live docs (the skill's **Source of Truth**) remain authoritative for field schemas, and Block Kit evolves. Confirm any field you change against the component's doc page, and re-run the customized payload through `blocks.validate` (Step 5) before shipping.
> `[M]` patterns show `{ "blocks": [...] }` — add `channel` and a `text` fallback when calling `chat.postMessage` per Step 1; don't skip `text`, it matters for accessibility.

---

## Approval Message [M]

A notification with context and Approve/Reject buttons.

```json
{
  "blocks": [
    {
      "type": "header",
      "text": { "type": "plain_text", "text": "New Approval Request" }
    },
    {
      "type": "section",
      "text": { "type": "mrkdwn", "text": "*Requester:* <@U0123456789>\n*Type:* Access request\n*Details:* Production database read access" }
    },
    { "type": "divider" },
    {
      "type": "actions",
      "block_id": "approval_actions",
      "elements": [
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Approve" },
          "style": "primary",
          "action_id": "approve_btn",
          "value": "request_123"
        },
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Reject" },
          "style": "danger",
          "action_id": "reject_btn",
          "value": "request_123"
        }
      ]
    }
  ]
}
```

**Customization points:** Header text, section fields, button values, adding a confirmation dialog to the Reject button.

---

## Simple Form Modal [V]

A modal with text input, select menu, and optional checkbox.

```json
{
  "type": "modal",
  "callback_id": "feedback_form",
  "title": { "type": "plain_text", "text": "Submit Feedback" },
  "submit": { "type": "plain_text", "text": "Submit" },
  "close": { "type": "plain_text", "text": "Cancel" },
  "blocks": [
    {
      "type": "input",
      "block_id": "category_block",
      "label": { "type": "plain_text", "text": "Category" },
      "element": {
        "type": "static_select",
        "action_id": "category_select",
        "placeholder": { "type": "plain_text", "text": "Choose a category" },
        "options": [
          { "text": { "type": "plain_text", "text": "Bug Report" }, "value": "bug" },
          { "text": { "type": "plain_text", "text": "Feature Request" }, "value": "feature" },
          { "text": { "type": "plain_text", "text": "General Feedback" }, "value": "general" }
        ]
      }
    },
    {
      "type": "input",
      "block_id": "description_block",
      "label": { "type": "plain_text", "text": "Description" },
      "element": {
        "type": "plain_text_input",
        "action_id": "description_input",
        "multiline": true,
        "placeholder": { "type": "plain_text", "text": "Tell us more..." }
      }
    },
    {
      "type": "input",
      "block_id": "urgency_block",
      "label": { "type": "plain_text", "text": "Priority" },
      "element": {
        "type": "radio_buttons",
        "action_id": "urgency_select",
        "options": [
          { "text": { "type": "plain_text", "text": "Low" }, "value": "low" },
          { "text": { "type": "plain_text", "text": "Medium" }, "value": "medium" },
          { "text": { "type": "plain_text", "text": "High" }, "value": "high" }
        ]
      },
      "optional": true
    }
  ]
}
```

**Customization points:** Title, callback_id, input types, options list, adding/removing input blocks.

---

## Notification Alert [M]

An alert banner with description and timestamp context.

```json
{
  "blocks": [
    {
      "type": "alert",
      "text": { "type": "plain_text", "text": "Deployment failed for api-gateway" },
      "level": "error"
    },
    {
      "type": "section",
      "text": { "type": "mrkdwn", "text": "The deployment to *production* failed during the health check phase.\n\n*Error:* `Connection timeout after 30s`\n*Commit:* `a1b2c3d`" }
    },
    {
      "type": "context",
      "elements": [
        { "type": "mrkdwn", "text": "Triggered by <@U0123456789> | <!date^1700000000^{date_short} at {time}|Nov 14, 2023>" }
      ]
    },
    {
      "type": "actions",
      "elements": [
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "View Logs" },
          "url": "https://logs.example.com/deploy/456",
          "action_id": "view_logs_btn"
        },
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Retry" },
          "style": "primary",
          "action_id": "retry_deploy_btn"
        }
      ]
    }
  ]
}
```

**Customization points:** Level (`info`, `warning`, `error`, `success`), description text, action buttons.

---

## Dashboard Home Tab [H]

A welcome dashboard with metrics fields and quick-action buttons.

```json
{
  "type": "home",
  "blocks": [
    {
      "type": "header",
      "text": { "type": "plain_text", "text": "Welcome to AppName" }
    },
    {
      "type": "section",
      "text": { "type": "mrkdwn", "text": "Here's your overview for today:" }
    },
    {
      "type": "section",
      "fields": [
        { "type": "mrkdwn", "text": "*Open Tickets:*\n12" },
        { "type": "mrkdwn", "text": "*Resolved Today:*\n5" },
        { "type": "mrkdwn", "text": "*Avg Response:*\n2.4 hrs" },
        { "type": "mrkdwn", "text": "*SLA Status:*\n:white_check_mark: On Track" }
      ]
    },
    { "type": "divider" },
    {
      "type": "actions",
      "elements": [
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "New Ticket" },
          "style": "primary",
          "action_id": "new_ticket_btn"
        },
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "My Queue" },
          "action_id": "my_queue_btn"
        },
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Settings" },
          "action_id": "settings_btn"
        }
      ]
    }
  ]
}
```

**Customization points:** Metrics fields, action buttons, adding image blocks or additional sections.

---

## Confirmation with Dialog [M]

An action button with a confirmation dialog attached (prevents accidental clicks).

```json
{
  "blocks": [
    {
      "type": "section",
      "text": { "type": "mrkdwn", "text": "Are you sure you want to shut down *prod-server-01*?" }
    },
    {
      "type": "actions",
      "elements": [
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Shut Down" },
          "style": "danger",
          "action_id": "shutdown_btn",
          "value": "prod-server-01",
          "confirm": {
            "title": { "type": "plain_text", "text": "Confirm Shutdown" },
            "text": { "type": "plain_text", "text": "This will immediately terminate the server. Active connections will be dropped." },
            "confirm": { "type": "plain_text", "text": "Shut Down" },
            "deny": { "type": "plain_text", "text": "Cancel" },
            "style": "danger"
          }
        }
      ]
    }
  ]
}
```

**Customization points:** Confirmation title/text (title max 100 chars, text max 300 chars, confirm/deny max 30 chars), button style.

---

## Data Table [M]

A structured table for displaying tabular data. Only one table block per message.

```json
{
  "blocks": [
    {
      "type": "header",
      "text": { "type": "plain_text", "text": "Sprint Summary" }
    },
    {
      "type": "table",
      "column_settings": [
        { "is_wrapped": true },
        { "align": "center" },
        { "align": "right" }
      ],
      "rows": [
        [
          { "type": "raw_text", "text": "Name" },
          { "type": "raw_text", "text": "Status" },
          { "type": "raw_text", "text": "Points" }
        ],
        [
          { "type": "raw_text", "text": "Auth refactor" },
          { "type": "raw_text", "text": "In Progress" },
          { "type": "raw_text", "text": "5" }
        ],
        [
          { "type": "raw_text", "text": "API docs update" },
          { "type": "raw_text", "text": "Done" },
          { "type": "raw_text", "text": "2" }
        ],
        [
          { "type": "raw_text", "text": "Bug #1234" },
          { "type": "raw_text", "text": "Blocked" },
          { "type": "raw_text", "text": "3" }
        ]
      ]
    }
  ]
}
```

**Customization points:** Column settings (alignment: `left`/`center`/`right`, wrapping: `is_wrapped`), row data, cell type (`raw_text` for plain content, `rich_text` for formatted content with links/emoji/mentions). Max 100 rows, max 20 cells per row. First row is the header. Only one table block per message.

---

## Settings Modal with Multiple Input Types [V]

A modal combining different input types for a settings/preferences form.

```json
{
  "type": "modal",
  "callback_id": "settings_modal",
  "title": { "type": "plain_text", "text": "Notification Settings" },
  "submit": { "type": "plain_text", "text": "Save" },
  "close": { "type": "plain_text", "text": "Cancel" },
  "blocks": [
    {
      "type": "input",
      "block_id": "channel_block",
      "label": { "type": "plain_text", "text": "Notification Channel" },
      "element": {
        "type": "conversations_select",
        "action_id": "channel_select",
        "default_to_current_conversation": true
      }
    },
    {
      "type": "input",
      "block_id": "frequency_block",
      "label": { "type": "plain_text", "text": "Digest Frequency" },
      "element": {
        "type": "static_select",
        "action_id": "frequency_select",
        "options": [
          { "text": { "type": "plain_text", "text": "Real-time" }, "value": "realtime" },
          { "text": { "type": "plain_text", "text": "Hourly" }, "value": "hourly" },
          { "text": { "type": "plain_text", "text": "Daily" }, "value": "daily" }
        ],
        "initial_option": { "text": { "type": "plain_text", "text": "Daily" }, "value": "daily" }
      }
    },
    {
      "type": "input",
      "block_id": "events_block",
      "label": { "type": "plain_text", "text": "Notify me about" },
      "element": {
        "type": "checkboxes",
        "action_id": "events_checkboxes",
        "options": [
          { "text": { "type": "plain_text", "text": "New deployments" }, "value": "deploys" },
          { "text": { "type": "plain_text", "text": "Failed builds" }, "value": "failures" },
          { "text": { "type": "plain_text", "text": "PR reviews needed" }, "value": "reviews" }
        ]
      }
    },
    {
      "type": "input",
      "block_id": "quiet_hours_block",
      "label": { "type": "plain_text", "text": "Quiet hours start" },
      "element": {
        "type": "timepicker",
        "action_id": "quiet_start",
        "initial_time": "22:00",
        "placeholder": { "type": "plain_text", "text": "Select time" }
      },
      "optional": true
    }
  ]
}
```

**Customization points:** Input types, options, initial values, adding `hint` text to inputs, marking fields as `optional`.

---

## Rich Text Section [M]

Formatted text with bold, links, and a bullet list — the WYSIWYG-composer format, for layouts needing richer inline styling or structure than a `mrkdwn` string offers.

```json
{
  "blocks": [
    {
      "type": "rich_text",
      "elements": [
        {
          "type": "rich_text_section",
          "elements": [
            { "type": "text", "text": "Deploy summary: " },
            { "type": "text", "text": "3 services", "style": { "bold": true } },
            { "type": "text", "text": " updated. See the " },
            { "type": "link", "url": "https://example.com/changelog", "text": "changelog" },
            { "type": "text", "text": " for details." }
          ]
        },
        {
          "type": "rich_text_list",
          "style": "bullet",
          "elements": [
            { "type": "rich_text_section", "elements": [{ "type": "text", "text": "api-gateway: v2.4.1" }] },
            { "type": "rich_text_section", "elements": [{ "type": "text", "text": "auth-service: v1.9.0" }] }
          ]
        }
      ]
    }
  ]
}
```

**Customization points:** Text styling (`bold`, `italic`, `strike`, `code`) on individual `text` elements, list `style` (`bullet` or `ordered`), adding `rich_text_quote` or `rich_text_preformatted` elements, mixing in `user`/`channel`/`emoji` elements for mentions and reactions inline.

---

## Row Actions with Overflow Menu [M]

A row-level "⋯" menu for actions that don't need dedicated buttons (edit, duplicate, delete).

```json
{
  "blocks": [
    {
      "type": "actions",
      "block_id": "row_actions_block",
      "elements": [
        {
          "type": "overflow",
          "action_id": "row_actions",
          "options": [
            { "text": { "type": "plain_text", "text": "Edit" }, "value": "edit" },
            { "text": { "type": "plain_text", "text": "Duplicate" }, "value": "duplicate" },
            { "text": { "type": "plain_text", "text": "Delete" }, "value": "delete" }
          ],
          "confirm": {
            "title": { "type": "plain_text", "text": "Confirm delete" },
            "text": { "type": "plain_text", "text": "This can't be undone." },
            "confirm": { "type": "plain_text", "text": "Delete" },
            "deny": { "type": "plain_text", "text": "Cancel" },
            "style": "danger"
          }
        }
      ]
    }
  ]
}
```

**Customization points:** Option list (max 5), which option(s) trigger the `confirm` dialog, using `overflow` as a `section` block's `accessory` instead of inside `actions` for a single row's trailing menu.

---

## Card Preview [M]

An image/thumbnail-driven card — link preview, product card, or similar — with a title, body, and action buttons.

```json
{
  "blocks": [
    {
      "type": "card",
      "hero_image": {
        "type": "image",
        "image_url": "https://example.com/product-photo.png",
        "alt_text": "Wireless noise-cancelling headphones, matte black"
      },
      "title": { "type": "plain_text", "text": "Noise-Cancelling Headphones" },
      "subtitle": { "type": "plain_text", "text": "$149.99 — In Stock" },
      "body": { "type": "mrkdwn", "text": "30-hour battery life, USB-C fast charging, and adaptive noise cancellation." },
      "actions": [
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "View Product" },
          "url": "https://example.com/products/headphones",
          "action_id": "view_product_btn"
        },
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Add to Cart" },
          "style": "primary",
          "action_id": "add_to_cart_btn",
          "value": "headphones_sku_123"
        }
      ]
    }
  ]
}
```

**Customization points:** `hero_image` (top image) vs. `icon` (small image beside title/subtitle — mutually exclusive with `slack_icon`), `subtext` for secondary detail below `body`, up to 3 `actions` buttons. At least one of `hero_image`, `title`, `actions`, or `body` is required; `title`/`subtitle` max 150 chars, `body`/`subtext` max 200 chars.
