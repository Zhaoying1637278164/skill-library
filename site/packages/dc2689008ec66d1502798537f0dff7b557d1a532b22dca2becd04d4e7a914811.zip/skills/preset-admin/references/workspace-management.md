# Workspace Management Reference

Use `preset-workspaces` for read-only discovery and hostname resolution. Use this reference when the task involves workspace lifecycle management or membership edge cases.

Workspace create, update, delete, un-hibernate, and membership role changes are sensitive administration workflows. Load the safety policy and get explicit confirmation before mutating. Existing-member role changes are covered in [Update Workspace Member Role](#update-workspace-member-role).

## Create A Workspace

Confirmation summary should include the target `team_name`, workspace title, region or cluster selection, whether example data will be loaded, and any public dashboard or embedding-related setting.

```bash
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  "https://api.app.preset.io/v1/teams/{team_name}/workspaces/" \
  -d '{"title":"Analytics","region":"us-east-1","load_examples":true}'
```

```python
workspace = client.mgmt(
    "POST",
    f"/teams/{team_name}/workspaces/",
    json={
        "title": "Analytics",
        "region": "us-east-1",
        "load_examples": True,
    },
)["payload"]
```

Common request fields:

| Field | Description |
|---|---|
| `title` | Required workspace title |
| `region` | Region for workspace placement |
| `cluster_id` | Explicit cluster ID, when approved |
| `load_examples` | Whether to load examples; defaults true in Manager |
| `icon`, `color`, `descr` | Workspace display metadata |
| `allow_public_dashboards` | Public dashboard setting |

## Update A Workspace

`PUT` updates the workspace resource, but Manager does not treat every omitted field as preserved. Some omitted optional fields are passed to the manager as `None` or `False`, which can clear display metadata or disable boolean settings. Always read the current workspace first and send the full desired state for fields managed by this endpoint.

Confirmation summary should include the target `team_name`, workspace ID, current title, current hostname, every field being preserved, every field being changed, and the expected effect.

```bash
CURRENT_WORKSPACE="$(curl -s -H "Authorization: Bearer $TOKEN" \
  "https://api.app.preset.io/v1/teams/{team_name}/workspaces/{workspace_id}/")"

CURRENT_WORKSPACE="$CURRENT_WORKSPACE" jq -n '{
  title: "Analytics",
  descr: (env.CURRENT_WORKSPACE | fromjson | .payload.descr),
  color: (env.CURRENT_WORKSPACE | fromjson | .payload.color),
  icon: (env.CURRENT_WORKSPACE | fromjson | .payload.icon),
  allow_public_dashboards: (env.CURRENT_WORKSPACE | fromjson | .payload.allow_public_dashboards)
}' \
| curl -s -X PUT \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  "https://api.app.preset.io/v1/teams/{team_name}/workspaces/{workspace_id}/" \
  -d @-
```

```python
current = client.mgmt(
    "GET",
    f"/teams/{team_name}/workspaces/{workspace_id}/",
)["payload"]

payload = {
    "title": "Analytics",
    "descr": current.get("descr"),
    "color": current.get("color"),
    "icon": current.get("icon"),
    "allow_public_dashboards": current.get("allow_public_dashboards", False),
}

updated = client.mgmt(
    "PUT",
    f"/teams/{team_name}/workspaces/{workspace_id}/",
    json=payload,
)["payload"]
```

Do not include secrets such as `slack_token` unless the user explicitly asks and provides an approved secret-handling path. Treat AI Assist, embedding, MCP, and Copilot settings as separate sensitive configuration changes, not incidental workspace metadata updates.

## Delete A Workspace

Deleting a workspace is destructive. Confirmation must name the team, workspace ID, workspace title, hostname, and expected deletion effect.

```bash
curl -s -X DELETE \
  -H "Authorization: Bearer $TOKEN" \
  "https://api.app.preset.io/v1/teams/{team_name}/workspaces/{workspace_id}/"
```

```python
client.mgmt("DELETE", f"/teams/{team_name}/workspaces/{workspace_id}/")
```

## Un-Hibernate A Workspace

Un-hibernating may resume compute and incur runtime cost. Confirm the target `team_name`, workspace title, stable workspace slug, hostname, and expected cost or availability effect before calling this endpoint.

```bash
curl -s -X PATCH \
  -H "Authorization: Bearer $TOKEN" \
  "https://api.app.preset.io/v1/teams/{team_name}/workspaces/{workspace_slug}/un-hibernate/"
```

```python
workspace = client.mgmt(
    "PATCH",
    f"/teams/{team_name}/workspaces/{workspace_slug}/un-hibernate/",
)["payload"]
```

Use the stable workspace slug from the workspace `name` field, not the display title.

## Workspace Membership Edge Cases

The read-only workspace membership list lives in `preset-workspaces`. These details are important for admin work:

- `GET /teams/{team_name}/workspaces/{workspace_id_or_name}/memberships/` accepts either a numeric workspace ID or `name-<workspace_name>`.
- Use `user_name_or_email` to search members.
- The response is paginated and returns `meta.count`.
- `is_role_from_group` means the visible role is inherited from a group. Updating a direct user role may not change effective access.

```python
members = client.mgmt(
    "GET",
    f"/teams/{team_name}/workspaces/name-{workspace_name}/memberships/"
    "?page_number=1&page_size=100"
    "&user_name_or_email=jdoe@example.com",
)["payload"]
```

## Update Workspace Member Role

`PUT /teams/{team_name}/workspaces/{workspace_id}/membership` updates direct workspace access for an existing team member. This endpoint accepts a numeric workspace ID, not `name-<workspace_name>`, and currently validates default workspace role identifiers only.

Before updating a member role:

1. Load [role-identifiers.md](role-identifiers.md) and choose a default `role_identifier`.
2. List the workspace memberships and resolve the target `user_id` from the API response.
3. Check `is_role_from_group`. If it is true, the effective role is inherited from a group and a direct role update may not change access.
4. For creator role upgrades on Enterprise teams, preflight seat availability with `GET /teams/{team_name}/has-seats-remaining/`.
5. Confirm the target team, workspace ID, workspace title, user ID, email, current role, new role, group-derived role status, and seat preflight result.

```python
members = client.mgmt(
    "GET",
    f"/teams/{team_name}/workspaces/{workspace_id}/memberships/"
    "?page_number=1&page_size=100"
    "&user_name_or_email=jdoe@example.com",
)["payload"]

member = next(
    m for m in members
    if m["user"]["email"].lower() == "jdoe@example.com"
)

if member.get("is_role_from_group"):
    raise RuntimeError("Role is inherited from a group; confirm before direct update")

seat_check = client.mgmt("GET", f"/teams/{team_name}/has-seats-remaining/")["payload"]
if not seat_check.get("has_seats_remaining"):
    raise RuntimeError("Team has no seats remaining")

updated = client.mgmt(
    "PUT",
    f"/teams/{team_name}/workspaces/{workspace_id}/membership",
    json={
        "user_id": member["user"]["id"],
        "role_identifier": "PresetGamma",
    },
)["payload"]
```

Use `PresetNoAccess` to remove direct workspace access. Do not use custom workspace role identifiers with this endpoint unless Manager's request schema changes to accept them.

## Workspace User Access

`GET /teams/{team_name}/workspaces/{workspace_name}/user-access/` returns workspace access information suitable for non-admin displays, but Manager does not mark this route as `user_api_key_allowed`. Do not call it with the API-key JWT client from `preset-api`; use the workspace membership list for API-key examples or a browser/session-backed context outside this skill.

## Defer Adjacent Workspace Admin APIs

Do not use this skill for database connection creation/update/test, embedded guest tokens, embedded access-token keys, trusted domains, homepage settings, workspace cloning, hibernation recovery, internal health checks, or internal `/api-internal/*` workspace operations. See [deferrals.md](deferrals.md).
