# Cala Plugin for Claude Code

A Claude Code plugin that connects Claude to [Cala](https://cala.ai), the knowledge layer for AI agents.

This plugin is built and maintained by the Cala team. It is not an official
Anthropic product, and inclusion in Anthropic's directories does not imply
partnership, sponsorship, or endorsement by Anthropic.

## What this does

Cala turns the open web into a verified, structured entity graph — typed data,
deterministic queries, and full source traceability. This plugin gives Claude direct access to Cala's knowledge base through
MCP, so you can ask Claude things like "find Spanish startups that raised
between €10M and €50M" and get back clean, sourced, typed answers instead of
a pile of links to parse yourself.

Cala supports two response shapes for the same input:

- **Natural-language answers** — succinct, sourced markdown with citations.
- **Structured answers** — typed, tabular JSON rows for programmatic use.

Both accept either a plain-language question or a Cala QL expression
(dot-notation filters, e.g. `startups.location=Spain.funding>10M`).

## Installation

Install via the Claude Code plugin marketplace:

```
/plugin install cala@claude-community
```

Or add this repository directly:

```
claude plugin marketplace add cala-ai/cala-claude-plugin
```

## Authentication

This plugin connects to Cala's hosted MCP server at `https://api.cala.ai/mcp/`.

On first use, Claude Code will prompt you to sign in to
your Cala account and authorize access. No API keys or credentials are stored
in this repository or in your local configuration.

## Available tools

| Tool | Description |
|---|---|
| `knowledge_search` | Get a succinct, token-optimized natural-language answer with sources, explainability, and matching entities. Accepts a natural-language question or a Cala QL expression. |
| `knowledge_query` | Get verified knowledge as structured, typed JSON rows plus matching entities. Accepts a Cala QL expression or a natural-language question. |
| `entity_search` | Find entities by name with fuzzy matching. |
| `entity_introspection` | Get the field schema for an entity by its UUID — available properties, relationships, and numerical observations. |
| `entity_retrieval` | Retrieve full details for a known entity by its UUID. |

Full API reference: [docs.cala.ai/api-reference](https://docs.cala.ai/api-reference)

## Pairing with the Cala agent skill

For the best experience, install the Cala skill alongside this plugin so
Claude knows how to use these tools well out of the box:

```
npx skills add cala-ai/cala-skill
```

See [docs.cala.ai/integrations/agent-skill](https://docs.cala.ai/integrations/agent-skill) for details.

## Using this MCP server with other clients

This plugin packages Cala's server for Claude Code specifically. Cala's MCP
server also works directly with Cursor, VS Code, Claude Desktop, Codex, and
any other MCP-compatible client — see
[docs.cala.ai/integrations/mcp](https://docs.cala.ai/integrations/mcp) for
per-client setup instructions.

## Support

- Docs: [docs.cala.ai](https://docs.cala.ai)
- Support: [heyeli@cala.ai](mailto:heyeli@cala.ai)

## License

MIT