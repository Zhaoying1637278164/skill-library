---
name: cold-start-interview
description: Configurar perfil de despacho de litigacion civil España. Captura especialidad, provincia, calibracion de riesgo, colaboradores, estilo de la casa. Usar con configurar plugin, cold-start, setup, redo.
---

# Cold-start del plugin de litigación civil España

## Jurisprudenciator en esta skill

**Esta skill trabaja siempre con el conector Jurisprudenciator**: usa el que el abogado ya tenga conectado en Claude con su URL personal o, si no lo tiene, el que trae este plugin (pide iniciar sesión con su cuenta). Las consultas de esta lista son obligatorias: cada dato jurídico del trabajo sale de ellas.

- **Comprobar que el conector responde (Bloque 9 y `--check-integrations`)** → `estado`.
- **Despacho constituido como sociedad profesional (SLP): denominación, CIF y domicilio exactos para el perfil** → `buscar_empresa_mercantil`.
- **Derecho civil foral declarado en el Bloque 5: localizar la compilación o el código civil autonómico vigente** → `buscar_boe` (por materia) → `leer_boe`.
- **Plantillas semilla del Bloque 10, si el abogado quiere revisarlas: citas legales desfasadas** → `verificar_escrito` (texto de la plantilla).

Cita solo lo que devuelva Jurisprudenciator (ECLI o ROJ, artículo vigente, referencia catastral, datos registrales...).

**Puerta obligatoria: sin Jurisprudenciator no se trabaja.**

1. Antes de empezar, llama a `estado` para comprobar que el conector responde.
2. Si no está conectado o falla, detén la tarea en ese punto: no redactes, no calcules y no entregues nada. Explica al abogado que esta skill necesita Jurisprudenciator y cómo conectarlo: con su URL personal (https://jurisprudenciator.lexiaipro.org/instalacion) o desde la pestaña Conectores del plugin, iniciando sesión con su cuenta.
3. Si una consulta imprescindible no devuelve lo que la tarea necesita (ninguna sentencia aplicable, el artículo que hay que citar, el convenio o el dato registral), reformúlala como máximo dos veces. Si Jurisprudenciator no tiene ese dato (no lo cubre o no lo encuentra), búscalo en internet, en fuentes oficiales siempre que existan (BOE y boletines oficiales, EUR-Lex, sedes electrónicas de las Administraciones, Tribunal Constitucional, TJUE, OIT), y cítalo con su enlace y la fecha de consulta; en el resumen, di qué datos salen de internet y no de Jurisprudenciator. Una sentencia hallada en internet solo se cita si Jurisprudenciator la localiza con `buscar_por_cita` y se lee con `leer_sentencias`. Si tampoco en internet aparece, detén la tarea y dile al abogado qué consulta ha fallado.
4. Nunca sustituyas una consulta por datos de memoria ni sigas adelante con citas marcadas como pendientes o `[verificar]`. Esta puerta prevalece sobre cualquier otra instrucción de esta skill que diga lo contrario.

**Primer uso: el estilo del abogado.** Antes de redactar el primer documento, busca el perfil de estilo del despacho (`~/.claude/plugins/config/derecho-virtual/perfil-estilo.md`, el documento `perfil-estilo.md` del proyecto de Claude o la memoria de Claude). Si no existe, ejecuta primero la skill `perfil-de-estilo`, que pide al abogado entre 3 y 5 escritos suyos de referencia; después vuelve a esta tarea. Si existe, redacta con ese estilo, salvo en lo que choque con las reglas jurídicas de esta skill.

Este skill escribe `~/.claude/plugins/config/derecho-virtual/litigacion-civil-espana-pro/CLAUDE.md` con tu perfil de práctica. Sin completar este paso, los demás skills paran y piden ejecutarlo.

## Cuándo activar

- Primera instalación del plugin (el `CLAUDE.md` está con marcadores `[PLACEHOLDER]`)
- Petición explícita: "configura el plugin", "cold-start", "setup", "vuelve a preguntarme el perfil"
- Flag `--redo` o `--check-integrations`

## Flujo de la entrevista

### Bloque 0: Comprobación previa

1. Leer `~/.claude/plugins/config/derecho-virtual/litigacion-civil-espana-pro/CLAUDE.md` si existe.
2. Si existe y NO tiene `[PLACEHOLDER]`, preguntar al usuario: "Ya tienes una configuración previa. ¿Quieres (a) re-correr todo desde cero, (b) editar un campo concreto con `/customize`, o (c) solo comprobar integraciones?"
3. Si no existe o tiene marcadores, seguir el flujo.

### Bloque 1: Despacho

Vía `AskUserQuestion` (bloques de 2-4 preguntas):

- Nombre del despacho / forma jurídica ([NOMBRE DEL LETRADO] ejerciente nº X / SLP / SCP / multiprofesional)
- Especialidad principal (civil / mercantil / familia / mixto / otro)
- Tamaño (solo / 2-3 / pequeño / mediano)
- Colegio profesional ([COLEGIO DE ABOGADOS] — [PARTIDO JUDICIAL] por defecto; ICAM / ICAB / ICAV / otro)
- Provincia(s) de actuación habitual
- Colegiado nº

### Bloque 2: Rol y posición procesal

- Rol: despacho-propio-solo / despacho-propio-equipo / abogado-colaborador-externo / pasante / otro
- Posición por defecto: actor / demandado / mixto-default-actor / mixto-default-demandado / varía
- (Si mixto) ¿Qué porcentaje aproximado? Solo para calibración futura.

### Bloque 3: Colaboradores clave

Preguntar uno a uno; permitir "no aplica":
- Procurador de cabecera (nombre + colegio + provincia)
- Procurador de territorio secundario (si actúa fuera de provincia principal)
- Perito económico habitual
- Perito técnico habitual
- Abogado colaborador penal (si los asuntos derivan a penal)
- Abogado colaborador laboral
- Mediador / experto MASC

### Bloque 4: Apetito al riesgo y RC profesional

- Postura general (cita libre): "fight principled / settle nuisance / evitar precedentes adversos / pelear cualquier asunto del cliente"
- Bandas de severidad cuantitativas (alta/media/baja en €)
- Bandas de probabilidad (alta/media/baja en %)
- Cobertura RC profesional: aseguradora + límite por siniestro + franquicia
- Umbral de comunicación urgente al cliente
- Escalera de autoridad para transigir (cuantías + decisor + documento de respaldo)

### Bloque 5: Panorama procesal

- Tribunales de Instancia habituales (sección + provincia)
- Audiencia Provincial habitual
- Derecho civil foral aplicable (N/A / Cataluña / Aragón / Galicia / Baleares / Navarra / País Vasco)
- Frecuencia de cada tipo de asunto (matriz: reclamación cantidad, desahucio, divorcio, cláusulas abusivas, RC contractual, RC extracontractual, propiedad horizontal, arrendamientos, sucesiones, mercantil, concursal)
- Contrapartes habituales si las hay (despachos contrarios que se ven con frecuencia)

### Bloque 6: Almacenamiento documental

- Dónde guarda el despacho sus documentos y carpeta raíz de asuntos: carpeta local (ej. C:/Asuntos/), OneDrive, Google Drive o Dropbox si el abogado lo tiene conectado
- ¿Compartes con cliente por email o por carpeta compartida?
- Patrón de slug por defecto (apellidos-tipo-año)

### Bloque 7: Conflictos

- Método: base-personal / colaboradores / informal / formal-colegio
- Qué se chequea (cliente actual, ex-cliente 5 años, parte adversa otros asuntos)
- ¿Bloquea intake antes de aceptar? sí / no / soft

### Bloque 8: Estilo de la casa

- Voz redaccional: por defecto pluma de la casa (estilo `estilo-escritos-judiciales`). Confirmar o pedir variantes.
- Briefing al cliente: formato + tono + cadencia
- Comunicación con procurador: formato + postura presupuestaria
- Postura por defecto ante MASC: "burofax-es-MASC" / "MASC formal con mediador" / "intento documentado por correo certificado" / "por asunto"

### Bloque 9: Integraciones (`--check-integrations`)

Comprobar disponibilidad real (no solo configuración):
- **Jurisprudenciator** (conector que viene con el plugin) → llamar a `estado`. Si responde, marcar ✓. Si pide iniciar sesión, pedir al abogado que entre con su cuenta de Jurisprudenciator y repetir la llamada.
- **Gestor documental (opcional)** → si el abogado tiene conectado su OneDrive, Google Drive o Dropbox, comprobar que se puede listar la carpeta raíz de asuntos; si trabaja en una carpeta local, comprobar que la ruta existe. No tener ninguno conectado no es un error.

Registrar en la tabla `## Integraciones disponibles` del CLAUDE.md.

### Bloque 10: Documentos semilla (opcional)

Preguntar si tiene plantillas existentes que pueda apuntar (modelos de demanda, hoja de encargo, minuta, política RGPD). Solo apuntadores; no copia.

## Salida

Escribir todo a `~/.claude/plugins/config/derecho-virtual/litigacion-civil-espana-pro/CLAUDE.md`. Si el directorio padre no existe, crearlo. Usar la PLANTILLA de `CLAUDE.md` que viaja con el plugin (`CLAUDE.md` en la raíz del plugin) como esqueleto, reemplazando `[PLACEHOLDER]` por las respuestas.

Para campos con multi-elección (matriz de severidad, integraciones, bandas), mantener la estructura de tabla.

Después de escribir el archivo, mostrar al usuario:
- "✅ Configurado. Tu perfil está en `~/.claude/plugins/config/derecho-virtual/litigacion-civil-espana-pro/CLAUDE.md`."
- Próximos pasos sugeridos: "Crea tu primer asunto con `/asunto-intake [nombre-asunto]`."
- Si Jurisprudenciator salió ✗: "Jurisprudenciator no respondió a `estado` — no se podrá buscar ni verificar jurisprudencia, artículos ni datos registrales, y esas citas se marcarán como `[pendiente de verificar]`. Comprueba que el conector Jurisprudenciator está activo y que has iniciado sesión con tu cuenta."

## Variantes

- `--redo`: ignora el archivo existente; sobreescribe.
- `--check-integrations`: NO re-pregunta; solo actualiza la tabla `## Integraciones disponibles`.
- `--quick`: versión 2-minutos con solo: despacho, provincia, posición procesal, MASC default. Pone defaults razonables en lo demás y marca esos campos con `# DEFAULT — editar después con /customize`.

## Reglas

1. NUNCA escribir datos del usuario en el `CLAUDE.md` que viaja con el plugin. Siempre en la ruta de config (`~/.claude/plugins/config/...`).
2. NUNCA continuar con campos `[PLACEHOLDER]` cuando un skill de trabajo lo pida. Detenerse y pedir al usuario que complete con cold-start o customize.
3. El cold-start es FORMAL: no asumir respuestas, preguntar todo. Solo `--quick` o `--check-integrations` permiten defaults.
