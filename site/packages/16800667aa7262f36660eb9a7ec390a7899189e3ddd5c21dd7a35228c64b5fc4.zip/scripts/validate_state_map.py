#!/usr/bin/env python3
"""Validate Stateful 0.1 maps without third-party dependencies."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path


ID_PATTERN = re.compile(r"^[a-z][a-z0-9-]*$")
QUESTIONS = {
    "after_time",
    "alternate_entry",
    "without_predecessor",
    "data_changed",
    "after_failure",
}
VALID_CATEGORIES = {"state", "failure", "interruption", "surface"}
VALID_SCOPES = {"in", "out-with-implication", "out"}
VALID_STATUSES = {"discovered", "triaged", "specified", "implemented", "verified"}
VALID_RELATIONSHIPS = {
    "transition",
    "interrupted-by",
    "reenters-as",
    "projects-to",
}
TOP_LEVEL_KEYS = {
    "$schema",
    "schema_version",
    "system_sentence",
    "conditions",
    "scenarios",
    "relationships",
    "metadata",
}
CONDITION_KEYS = {
    "id",
    "name",
    "category",
    "scope",
    "status",
    "description",
    "transient",
    "scope_note",
    "renders_on",
    "layers",
    "cause",
    "priority",
    "evidence",
    "specification",
    "reentry_variants",
    "reentry_review",
}


def no_duplicate_keys(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate object key {key!r}")
        result[key] = value
    return result


def fail(errors: list[str], path: str, message: str) -> None:
    errors.append(f"{path}: {message}")


def nonempty(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def validate_condition(
    condition: object,
    index: int,
    errors: list[str],
    profile: str,
) -> None:
    path = f"conditions[{index}]"
    if not isinstance(condition, dict):
        fail(errors, path, "must be an object")
        return
    for key in sorted(condition.keys() - CONDITION_KEYS):
        fail(errors, path, f"unknown property {key}")

    required = {
        "id",
        "name",
        "category",
        "status",
        "description",
        "evidence",
    }
    for key in sorted(required - condition.keys()):
        fail(errors, path, f"missing {key}")
    condition_id = condition.get("id")
    if not nonempty(condition_id) or not ID_PATTERN.fullmatch(condition_id):
        fail(errors, f"{path}.id", "must be a lowercase kebab-case id")
    if condition.get("category") not in VALID_CATEGORIES:
        fail(errors, f"{path}.category", "unknown category")
    if "scope" in condition and condition.get("scope") not in VALID_SCOPES:
        fail(errors, f"{path}.scope", "unknown scope")
    if condition.get("status") not in VALID_STATUSES:
        fail(errors, f"{path}.status", "unknown status")
    for key in ("name", "description"):
        if not nonempty(condition.get(key)):
            fail(errors, f"{path}.{key}", "must be non-empty")

    if (
        condition.get("scope") == "out-with-implication"
        and not nonempty(condition.get("scope_note"))
    ):
        fail(errors, path, "out-with-implication requires scope_note")
    if condition.get("category") == "failure" and not nonempty(
        condition.get("cause")
    ):
        fail(errors, path, "failure conditions require cause")
    if condition.get("category") != "failure" and "cause" in condition:
        fail(errors, path, "cause is only valid on failure conditions")

    needs_triage = condition.get("status") in {
        "triaged",
        "specified",
        "implemented",
        "verified",
    }
    if needs_triage and condition.get("scope") not in VALID_SCOPES:
        fail(errors, f"{path}.scope", "is required after discovery")
    priority = condition.get("priority")
    if needs_triage and not isinstance(priority, dict):
        fail(errors, f"{path}.priority", "is required after discovery")
    elif isinstance(priority, dict):
        for key in ("likelihood", "impact", "confidence", "rationale"):
            if key not in priority:
                fail(errors, f"{path}.priority", f"missing {key}")

    evidence = condition.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        fail(errors, f"{path}.evidence", "must contain at least one source")

    if (
        profile == "handoff"
        and condition.get("scope") == "in"
        and condition.get("status") not in {"specified", "implemented", "verified"}
    ):
        fail(errors, path, "handoff requires in-scope conditions to be specified")
    if condition.get("status") in {"specified", "implemented", "verified"}:
        specification = condition.get("specification")
        if not isinstance(specification, dict):
            fail(errors, f"{path}.specification", "is required")
        else:
            if not nonempty(specification.get("behavior")):
                fail(errors, f"{path}.specification.behavior", "must be non-empty")
            if not nonempty(specification.get("owner")):
                fail(errors, f"{path}.specification.owner", "must be non-empty")
            criteria = specification.get("acceptance_criteria")
            if not isinstance(criteria, list) or not criteria or not all(
                nonempty(item) for item in criteria
            ):
                fail(
                    errors,
                    f"{path}.specification.acceptance_criteria",
                    "must contain at least one criterion",
                )
            if condition.get("category") in {"failure", "interruption"} and not nonempty(
                specification.get("recovery")
            ):
                fail(errors, f"{path}.specification.recovery", "is required")
            if condition.get("status") in {"implemented", "verified"}:
                links = specification.get("implementation_links")
                if not isinstance(links, list) or not links:
                    fail(
                        errors,
                        f"{path}.specification.implementation_links",
                        "is required for implemented or verified conditions",
                    )
            if condition.get("status") == "verified":
                links = specification.get("test_links")
                if not isinstance(links, list) or not links:
                    fail(
                        errors,
                        f"{path}.specification.test_links",
                        "is required for verified conditions",
                    )

    needs_reentry = (
        condition.get("scope") == "in"
        and condition.get("category") == "state"
        and condition.get("status") in {"specified", "implemented", "verified"}
        and not condition.get("transient", False)
    )
    review = condition.get("reentry_review")
    if needs_reentry and not isinstance(review, dict):
        fail(errors, f"{path}.reentry_review", "is required")
    elif isinstance(review, dict):
        missing = QUESTIONS - review.keys()
        extra = review.keys() - QUESTIONS
        for key in sorted(missing):
            fail(errors, f"{path}.reentry_review", f"missing {key}")
        for key in sorted(extra):
            fail(errors, f"{path}.reentry_review", f"unknown question {key}")
        for key, check in review.items():
            check_path = f"{path}.reentry_review.{key}"
            if not isinstance(check, dict):
                fail(errors, check_path, "must be an object")
                continue
            applicability = check.get("applicability")
            if applicability == "applicable" and not nonempty(
                check.get("specification")
            ):
                fail(errors, check_path, "applicable checks require specification")
            elif applicability == "not-applicable" and not nonempty(
                check.get("reason")
            ):
                fail(errors, check_path, "not-applicable checks require reason")
            elif applicability not in {"applicable", "not-applicable"}:
                fail(errors, check_path, "unknown applicability")

    variants = condition.get("reentry_variants", [])
    if not isinstance(variants, list):
        fail(errors, f"{path}.reentry_variants", "must be an array")
    else:
        variant_ids = []
        for variant_index, variant in enumerate(variants):
            variant_path = f"{path}.reentry_variants[{variant_index}]"
            if not isinstance(variant, dict):
                fail(errors, variant_path, "must be an object")
                continue
            for key in ("id", "context", "specification"):
                if not nonempty(variant.get(key)):
                    fail(errors, variant_path, f"missing or empty {key}")
            if nonempty(variant.get("id")):
                variant_ids.append(variant["id"])
        if len(variant_ids) != len(set(variant_ids)):
            fail(errors, f"{path}.reentry_variants", "duplicate variant ids")
        if isinstance(review, dict):
            for question, check in review.items():
                if not isinstance(check, dict):
                    continue
                for variant_id in check.get("variant_ids", []):
                    if variant_id not in variant_ids:
                        fail(
                            errors,
                            f"{path}.reentry_review.{question}.variant_ids",
                            f"unknown re-entry variant {variant_id!r}",
                        )


def validate_map(path: Path, profile: str = "working") -> list[str]:
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(), object_pairs_hook=no_duplicate_keys)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return [f"{path}: {exc}"]
    if not isinstance(data, dict):
        return [f"{path}: root must be an object"]
    for key in sorted(data.keys() - TOP_LEVEL_KEYS):
        fail(errors, "$", f"unknown property {key}")
    if data.get("schema_version") != "0.1":
        fail(errors, "schema_version", "must be 0.1")
    if not nonempty(data.get("system_sentence")):
        fail(errors, "system_sentence", "must be non-empty")
    conditions = data.get("conditions")
    if not isinstance(conditions, list):
        fail(errors, "conditions", "must be an array")
        conditions = []
    for index, condition in enumerate(conditions):
        validate_condition(condition, index, errors, profile)

    ids = [
        condition.get("id")
        for condition in conditions
        if isinstance(condition, dict) and nonempty(condition.get("id"))
    ]
    if len(ids) != len(set(ids)):
        fail(errors, "conditions", "condition ids must be unique")
    category_by_id = {
        condition["id"]: condition["category"]
        for condition in conditions
        if isinstance(condition, dict)
        and nonempty(condition.get("id"))
        and condition.get("category") in VALID_CATEGORIES
    }
    surfaces = {
        condition_id
        for condition_id, category in category_by_id.items()
        if category == "surface"
    }
    for index, condition in enumerate(conditions):
        if not isinstance(condition, dict):
            continue
        for surface in condition.get("renders_on", []):
            if surface not in surfaces:
                fail(
                    errors,
                    f"conditions[{index}].renders_on",
                    f"{surface!r} is not a surface condition id",
                )

    scenarios = data.get("scenarios")
    if not isinstance(scenarios, list):
        fail(errors, "scenarios", "must be an array")
        scenarios = []
    scenario_ids = []
    for index, scenario in enumerate(scenarios):
        scenario_path = f"scenarios[{index}]"
        if not isinstance(scenario, dict):
            fail(errors, scenario_path, "must be an object")
            continue
        allowed_scenario_keys = {
            "id",
            "name",
            "scope",
            "status",
            "conditions",
            "description",
            "priority",
            "evidence",
            "specification",
        }
        for key in sorted(scenario.keys() - allowed_scenario_keys):
            fail(errors, scenario_path, f"unknown property {key}")
        for key in (
            "id",
            "name",
            "scope",
            "status",
            "conditions",
            "description",
            "priority",
            "evidence",
            "specification",
        ):
            if key not in scenario:
                fail(errors, scenario_path, f"missing {key}")
        scenario_id = scenario.get("id")
        if not nonempty(scenario_id) or not ID_PATTERN.fullmatch(scenario_id):
            fail(errors, f"{scenario_path}.id", "must be a lowercase kebab-case id")
        else:
            scenario_ids.append(scenario_id)
        if scenario.get("scope") != "in":
            fail(errors, f"{scenario_path}.scope", "composite scenarios must be in")
        if scenario.get("status") not in {"specified", "implemented", "verified"}:
            fail(
                errors,
                f"{scenario_path}.status",
                "must be specified, implemented, or verified",
            )
        references = scenario.get("conditions")
        if not isinstance(references, list) or len(references) < 2:
            fail(
                errors,
                f"{scenario_path}.conditions",
                "must reference at least two conditions",
            )
        else:
            if len(references) != len(set(references)):
                fail(errors, f"{scenario_path}.conditions", "contains duplicates")
            for reference in references:
                if reference not in category_by_id:
                    fail(
                        errors,
                        f"{scenario_path}.conditions",
                        f"unknown condition {reference!r}",
                    )
        if not nonempty(scenario.get("name")) or not nonempty(
            scenario.get("description")
        ):
            fail(errors, scenario_path, "name and description must be non-empty")
        if not isinstance(scenario.get("priority"), dict):
            fail(errors, f"{scenario_path}.priority", "must be an object")
        if not isinstance(scenario.get("evidence"), list) or not scenario["evidence"]:
            fail(errors, f"{scenario_path}.evidence", "must contain a source")
        specification = scenario.get("specification")
        if not isinstance(specification, dict):
            fail(errors, f"{scenario_path}.specification", "must be an object")
        else:
            if not nonempty(specification.get("behavior")):
                fail(errors, f"{scenario_path}.specification.behavior", "is required")
            if not nonempty(specification.get("owner")):
                fail(errors, f"{scenario_path}.specification.owner", "is required")
            criteria = specification.get("acceptance_criteria")
            if not isinstance(criteria, list) or not criteria:
                fail(
                    errors,
                    f"{scenario_path}.specification.acceptance_criteria",
                    "must contain at least one criterion",
                )
            if scenario.get("status") in {"implemented", "verified"}:
                links = specification.get("implementation_links")
                if not isinstance(links, list) or not links:
                    fail(
                        errors,
                        f"{scenario_path}.specification.implementation_links",
                        "is required for implemented or verified scenarios",
                    )
            if scenario.get("status") == "verified":
                links = specification.get("test_links")
                if not isinstance(links, list) or not links:
                    fail(
                        errors,
                        f"{scenario_path}.specification.test_links",
                        "is required for verified scenarios",
                    )
    if len(scenario_ids) != len(set(scenario_ids)):
        fail(errors, "scenarios", "scenario ids must be unique")

    relationships = data.get("relationships")
    if not isinstance(relationships, list):
        fail(errors, "relationships", "must be an array")
        relationships = []
    seen_relationships = set()
    for index, relationship in enumerate(relationships):
        path_prefix = f"relationships[{index}]"
        if not isinstance(relationship, dict):
            fail(errors, path_prefix, "must be an object")
            continue
        for key in sorted(
            relationship.keys() - {"type", "from", "to", "trigger", "guard", "notes"}
        ):
            fail(errors, path_prefix, f"unknown property {key}")
        for key in ("type", "from", "to", "trigger"):
            if not nonempty(relationship.get(key)):
                fail(errors, path_prefix, f"missing or empty {key}")
        relationship_type = relationship.get("type")
        if relationship_type not in VALID_RELATIONSHIPS:
            fail(errors, f"{path_prefix}.type", "unknown relationship type")
        from_id, to_id = relationship.get("from"), relationship.get("to")
        if from_id not in category_by_id:
            fail(errors, f"{path_prefix}.from", f"unknown condition {from_id!r}")
        if to_id not in category_by_id:
            fail(errors, f"{path_prefix}.to", f"unknown condition {to_id!r}")
        if from_id in category_by_id and to_id in category_by_id:
            from_category, to_category = category_by_id[from_id], category_by_id[to_id]
            expected = (
                "projects-to"
                if to_category == "surface"
                else "interrupted-by"
                if to_category == "interruption"
                else "reenters-as"
                if from_category == "interruption"
                else "transition"
            )
            if relationship_type != expected:
                fail(
                    errors,
                    path_prefix,
                    f"{from_category}->{to_category} must use {expected}",
                )
        signature = (
            relationship_type,
            from_id,
            to_id,
            relationship.get("trigger"),
        )
        if signature in seen_relationships:
            fail(errors, path_prefix, "duplicate relationship")
        seen_relationships.add(signature)

    metadata = data.get("metadata")
    if not isinstance(metadata, dict):
        fail(errors, "metadata", "must be an object")
    else:
        for key in ("project_name", "version", "last_updated", "maturity"):
            if not nonempty(metadata.get(key)):
                fail(errors, "metadata", f"missing or empty {key}")
        try:
            dt.date.fromisoformat(metadata.get("last_updated", ""))
        except ValueError:
            fail(errors, "metadata.last_updated", "must be YYYY-MM-DD")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--profile",
        choices=("working", "handoff"),
        default="working",
        help="handoff additionally requires every in-scope condition to be specified",
    )
    parser.add_argument("maps", nargs="+", type=Path)
    args = parser.parse_args()
    failed = False
    for path in args.maps:
        errors = validate_map(path, args.profile)
        if errors:
            failed = True
            print(f"{path}: invalid", file=sys.stderr)
            for error in errors:
                print(f"  - {error}", file=sys.stderr)
        else:
            print(f"{path}: valid")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
