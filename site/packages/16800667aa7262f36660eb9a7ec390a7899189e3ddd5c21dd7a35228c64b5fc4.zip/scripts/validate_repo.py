#!/usr/bin/env python3
"""Check local links, skill frontmatter, JSON syntax, and plugin versions."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LINK = re.compile(r"(?<!!)\[[^\]]+\]\(([^)#]+)(?:#[^)]+)?\)")
FRONTMATTER = re.compile(r"\A---\n(.*?)\n---\n", re.DOTALL)
EXPECTED_VERSION = "0.1.0"


def check_links(errors: list[str]) -> None:
    for path in ROOT.rglob("*.md"):
        if ".git" in path.parts:
            continue
        text = path.read_text()
        for target in LINK.findall(text):
            if "://" in target or target.startswith("mailto:"):
                continue
            resolved = (path.parent / target).resolve()
            if not resolved.exists():
                errors.append(f"{path.relative_to(ROOT)}: broken link {target}")


def check_skills(errors: list[str]) -> None:
    for path in sorted((ROOT / "skills").glob("*/SKILL.md")):
        match = FRONTMATTER.match(path.read_text())
        if not match:
            errors.append(f"{path.relative_to(ROOT)}: missing YAML frontmatter")
            continue
        fields = {}
        for line in match.group(1).splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                fields[key.strip()] = value.strip()
        expected_name = path.parent.name
        if fields.get("name") != expected_name:
            errors.append(
                f"{path.relative_to(ROOT)}: name must be {expected_name!r}"
            )
        if not fields.get("description"):
            errors.append(f"{path.relative_to(ROOT)}: missing description")
        if set(fields) != {"name", "description"}:
            errors.append(
                f"{path.relative_to(ROOT)}: frontmatter must contain only name and description"
            )


def check_json_and_versions(errors: list[str]) -> None:
    for path in ROOT.rglob("*.json"):
        if ".git" in path.parts or ".claude" in path.parts:
            continue
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            errors.append(f"{path.relative_to(ROOT)}: invalid JSON: {exc}")
            continue
        if path.name == "plugin.json" and data.get("version") != EXPECTED_VERSION:
            errors.append(
                f"{path.relative_to(ROOT)}: version must be {EXPECTED_VERSION}"
            )
        if path.name == "marketplace.json":
            for plugin in data.get("plugins", []):
                if "version" in plugin and plugin["version"] != EXPECTED_VERSION:
                    errors.append(
                        f"{path.relative_to(ROOT)}: plugin version must be {EXPECTED_VERSION}"
                    )


def main() -> int:
    errors: list[str] = []
    check_links(errors)
    check_skills(errors)
    check_json_and_versions(errors)
    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1
    print("repository checks: valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
