from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from scripts.validate_state_map import validate_map


ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "EXAMPLES" / "password-reset" / "04-state-map.json"


class ValidateStateMapTests(unittest.TestCase):
    def setUp(self) -> None:
        self.data = json.loads(EXAMPLE.read_text())

    def validate(self, data: dict, profile: str = "working") -> list[str]:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state-map.json"
            path.write_text(json.dumps(data))
            return validate_map(path, profile)

    def test_worked_example_is_valid(self) -> None:
        self.assertEqual(validate_map(EXAMPLE), [])

    def test_duplicate_condition_id_is_rejected(self) -> None:
        data = copy.deepcopy(self.data)
        data["conditions"][1]["id"] = data["conditions"][0]["id"]
        self.assertTrue(
            any("condition ids must be unique" in error for error in self.validate(data))
        )

    def test_in_scope_condition_requires_specification(self) -> None:
        data = copy.deepcopy(self.data)
        condition = next(item for item in data["conditions"] if item["scope"] == "in")
        condition.pop("specification")
        self.assertTrue(
            any(".specification" in error for error in self.validate(data))
        )

    def test_triaged_in_scope_condition_is_valid_working_memory(self) -> None:
        data = copy.deepcopy(self.data)
        condition = next(item for item in data["conditions"] if item["scope"] == "in")
        condition["status"] = "triaged"
        condition.pop("specification")
        condition.pop("reentry_review", None)
        self.assertEqual(self.validate(data), [])
        self.assertTrue(
            any(
                "handoff requires" in error
                for error in self.validate(data, profile="handoff")
            )
        )

    def test_broken_relationship_reference_is_rejected(self) -> None:
        data = copy.deepcopy(self.data)
        data["relationships"][0]["to"] = "missing-condition"
        self.assertTrue(
            any("unknown condition" in error for error in self.validate(data))
        )

    def test_broken_scenario_reference_is_rejected(self) -> None:
        data = copy.deepcopy(self.data)
        data["scenarios"][0]["conditions"][0] = "missing-condition"
        self.assertTrue(
            any("unknown condition" in error for error in self.validate(data))
        )

    def test_renders_on_must_reference_surface(self) -> None:
        data = copy.deepcopy(self.data)
        condition = next(item for item in data["conditions"] if item.get("renders_on"))
        condition["renders_on"][0] = "request-form-empty"
        self.assertTrue(
            any("is not a surface condition id" in error for error in self.validate(data))
        )

    def test_reentry_review_variant_must_exist(self) -> None:
        data = copy.deepcopy(self.data)
        condition = next(
            item
            for item in data["conditions"]
            if item.get("reentry_variants") and item.get("reentry_review")
        )
        question = next(
            check
            for check in condition["reentry_review"].values()
            if check["applicability"] == "applicable"
        )
        question["variant_ids"] = ["missing-variant"]
        self.assertTrue(
            any("unknown re-entry variant" in error for error in self.validate(data))
        )

    def test_duplicate_json_key_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state-map.json"
            path.write_text('{"schema_version":"0.1","schema_version":"0.1"}')
            self.assertTrue(
                any("duplicate object key" in error for error in validate_map(path))
            )


if __name__ == "__main__":
    unittest.main()
