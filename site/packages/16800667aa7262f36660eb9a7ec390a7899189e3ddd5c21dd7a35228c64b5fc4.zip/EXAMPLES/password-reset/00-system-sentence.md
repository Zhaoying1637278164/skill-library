# 00. System Sentence

The system sentence for the password-reset example, with two rejected drafts and the reasoning for the final version.

---

## First attempt (feature-framed)

> A password reset feature lets users regain access to their account when they have forgotten their password.

This is a feature sentence. It describes what the system does *for the user*, not what the system *is*. Read it for verbs: *lets, regain, forgotten*. These describe a user's experience, not a system condition. Attempt to derive states from it and you get a loose set ("before reset", "during reset", "after reset") which are time segments of a user's experience, not conditions the system occupies.

Feature sentences are the default output of a prompt like "describe the password-reset feature". They are not wrong, only misaligned with the purpose of the system sentence in this method.

## Second attempt (flow-framed)

> Password reset is a flow where the user requests a reset link, receives it by email, clicks the link, sets a new password, and regains access.

This is better. It contains nouns the system is made of (link, email, password). It is still inadequate. It describes a canonical sequence through the system, not the system itself. The states it generates correspond to steps in the sequence ("link requested", "email sent", "password entered") and miss the properties that make the system structurally interesting: the link is time-bound, the process is out-of-band (completed across two devices and two channels), and the conditions at completion are not guaranteed to match the conditions at initiation.

A system sentence that describes a flow will generate a condition inventory that tracks the flow. This is the failure mode the method is trying to avoid.

## Final version (structural)

> A password reset is a time-bound, single-use credential-replacement process, initiated from one context, continued via an out-of-band message, and completed under conditions that may differ from those at initiation.

This sentence is not a description of what the user does. It is a description of what the system *is*, as an object that exists over time.

Underlining the structural terms: *time-bound*, *single-use*, *credential-replacement*, *initiated*, *out-of-band message*, *continued*, *completed*, *conditions that may differ*.

Each of these generates states:

- **time-bound** → states for link unexpired, expiring, expired
- **single-use** → states for link unused, in-use, used
- **credential-replacement** → states for request, validation, commit, confirmation
- **initiated from one context** → states for the originating surface
- **out-of-band message** → states for email composition, delivery, receipt, preview, deliverability failure
- **continued via** → states around the click-return to the system: token validation, challenge step-up, arrival-without-prior-context
- **completed under conditions that may differ** → the entire re-entry surface: different device, different session, different time, different account context, different network

The final sentence does not list the state space. It *generates* it. That is the test for a structurally useful system sentence.
