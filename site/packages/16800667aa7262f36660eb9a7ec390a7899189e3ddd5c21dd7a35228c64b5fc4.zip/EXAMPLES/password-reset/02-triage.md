# 02. Triage

The conditions from [01-state-list.md](01-state-list.md) are annotated here with illustrative scope. The **Layers** column records `fe` (frontend), `be` (backend), `dm` (data-model), and `inf` (infrastructure). The v0.1 JSON mirror adds likelihood, impact, confidence, rationale, evidence, status, owner, behavior, and acceptance criteria. Those values demonstrate the artifact shape and are not production measurements.

Project assumption: a first-party web application with iOS and Android clients. Two-factor authentication is supported. Embedded email-client browser rendering is not tackled this iteration. SSO is not offered by this product.

---

## Lifecycle states

| # | State | Scope | Layers | Note |
|---|---|---|---|---|
| 1 | Request form, empty | in | fe | |
| 2 | Request form, email entered | in | fe | |
| 3 | CAPTCHA challenge | in | fe, be | |
| 4 | Request submitted, awaiting delivery | in | be | Transient. |
| 5 | Request acknowledged, email sent | in | fe | |
| 6 | Email in inbox, unread | out-with-implication | fe | Rendered by the email client, but subject line, preheader, and first visible text are under our control; those are the designed artefacts. |
| 7 | Email opened, link not clicked | out-with-implication | fe | Body copy, CTA copy, and plain-text fallback are under our control. |
| 8 | Link clicked, token being validated | in | be | Transient. |
| 9 | Two-factor challenge required | in | fe, be | |
| 10 | New-password form, empty | in | fe | |
| 11 | New-password form, entry in progress | in | fe | |
| 12 | New-password submitted, server-side validation | in | be | Transient. |
| 13 | Reset committed, confirmation rendering | in | fe, be | |
| 14 | Sessions elsewhere terminated | in | be | |
| 15 | Auto-signed-in on this device | in | fe, be | |
| 16 | Redirected to sign-in | out | fe | Auto-sign-in is the chosen completion path. Documented so the decision is not rediscovered later as a surprise. |

## Failure conditions

| # | State | Scope | Layers | Cause | Note |
|---|---|---|---|---|---|
| 17 | Email not recognised | out-with-implication | be | user-input | Never rendered to the user by design (the condition inventory gives the reason). Implication: the acknowledgement copy in state 5 must be compatible with the case where no email exists. |
| 18 | Rate-limited (per email) | in | fe, be | policy | |
| 19 | Rate-limited (per IP or device) | in | fe, be | policy | |
| 20 | Email deliverability failure | out-with-implication | be, inf | external | Unknown to the user on the origin surface. Implication: state 5 copy must not promise delivery and must offer a re-request path. |
| 21 | Email delayed | out-with-implication | inf | external | Same implication as state 20, plus an expectation-setting copy requirement and a re-request cooldown timer. |
| 22 | Link expired | in | fe, be | policy | |
| 23 | Link already used | in | fe, be | policy | |
| 24 | Link tampered or malformed | in | fe, be | user-input | |
| 25 | Link for a different account than signed-in | in | fe, be | policy | |
| 26 | Account deleted between request and click | in | fe, be | system | |
| 27 | Account locked independently | in | fe, be | policy | |
| 28 | Account is SSO-only | out | be, dm | policy | Product does not offer SSO. Becomes in-scope if SSO is introduced. |
| 29 | New password fails policy | in | fe, be | policy | |
| 30 | New password matches old | in | fe, be, dm | policy | |
| 31 | Concurrent reset requests | in | be | policy | |
| 32 | Two-factor challenge failed | in | fe, be | user-input | |
| 33 | Server error during commit | in | fe, be | system | |

## Interruption contexts

| # | State | Scope | Layers |
|---|---|---|---|
| 34 | Tab closed before submit | in | fe |
| 35 | Tab closed after submit, before email | in | fe |
| 36 | Email on different device from request | in | fe |
| 37 | Link clicked long after request | in | fe, be |
| 38 | Link opened in different browser or incognito | in | fe |
| 39 | Link prefetched by security scanner | in | be, inf |
| 40 | Link prefetched by email client | in | be, inf |
| 41 | Network drop during password submission | in | fe, inf |
| 42 | App backgrounded mid-form | in | fe |
| 43 | Email missed, user re-requests | in | fe |
| 44 | Original tab open after reset completed elsewhere | in | fe, be |

All eleven interruption contexts are in-scope. For a credentialled system, interruptions are where most real-world failures occur, and the cost of any of them rendering poorly is a locked-out user.

## Surface conditions

| # | State | Scope | Layers | Note |
|---|---|---|---|---|
| 45 | Request form, web | in | fe | |
| 46 | Request form, mobile web | in | fe | |
| 47 | Request form, native iOS | in | fe | |
| 48 | Request form, native Android | in | fe | |
| 49 | Email, HTML | in | fe | |
| 50 | Email, plain-text | in | fe | |
| 51 | Email, mobile preview pane | in | fe | |
| 52 | Email, push-notification preview | in | fe | |
| 53 | Reset form in embedded email-client browser | out | fe | Out this iteration; a measurable share of users (estimated 8–15%) will experience an inconsistent reset surface until brought in. |
| 54 | Reset form in stock browser | in | fe | |
| 55 | Reset form, screen reader | in | fe | |
| 56 | Confirmation surface on each rendering | in | fe | |
| 57 | Email notification of password change | in | fe, inf | |
| 58 | Push notification of password change | in | fe, inf | |

---

## Totals

- **In:** 50
- **Out-with-implication:** 5
- **Out:** 3

**By layer (in-scope states only; states often touch more than one):**

- Frontend: 43
- Backend: 25
- Data-model: 1
- Infrastructure: 5

**By failure cause (in-scope failures only):**

- User-input: 2
- System: 2
- External: 0
- Policy: 9

The cause distribution is the audit-relevant signal here: in a credentialled system, the dominant cause is `policy` (rate limits, validity windows, single-use enforcement, account-state rules). The design surface has to *explain the rules* clearly enough that users understand why the system is saying no, without apologising for what is intentional. The `system` and `user-input` slices are smaller but each needs its own response style: server errors need "we are aware, try again"; input errors need "what we expect" coaching.

The proportion of in-scope states is high because the cost of any state being silently wrong is a locked-out user. For other systems the distribution will differ; there is no target ratio.

The layer distribution shows the audit-relevant pattern: every in-scope state has a frontend dimension (the user needs to see something), more than half involve backend logic, and a meaningful slice depends on infrastructure (email delivery, notification push). Data-model engagement is rare; this is a transient credential-replacement system, not a long-running stateful entity.
