# 03. Re-Entry Pass

This readable view focuses on the five-question re-entry review for in-scope lifecycle states. Full prose is shown for two conditions and abbreviated prose for the others. The v0.1 JSON mirror records all five verdicts explicitly—including `not-applicable` reasons—and gives every in-scope lifecycle, failure, interruption, and surface condition a behavior, owner, and acceptance criterion.

Transient states (4, 8, 12) receive category specifications but no meaningful re-entry review; their rejected transitions are represented as failure conditions.

The five questions:

1. What does the user see if they return after time has passed?
2. What does the user see if they arrive from a notification, deep link, or different device?
3. What does the user see if they arrive without the preceding state having been shown?
4. What does the user see if the underlying data has changed since they last saw this state?
5. What does the user see if they arrive during or after a failure in the system?

---

## Full specification: State 5. Request acknowledged, email sent

**Canonical rendering.** A message confirming the request, the address the email was sent to (masked past the first character and the domain), and guidance on what to do next. A secondary affordance to re-request after a cooldown.

**Q1. Return after time has passed.** If the user returns to this surface minutes later (common: switched tabs and came back), the cooldown timer should reflect elapsed time, not restart. If the user returns hours later, the surface should degrade: the request is no longer actionable from this tab, and the surface should say so and offer a fresh start rather than appearing as though the request is still in flight.

**Q2. Arrival from notification, deep link, or different device.** Not applicable as a target: nothing outside the system links to this state. If a user shares the URL with a second device, that second device must not appear to have requested a reset. The surface must be session-scoped.

**Q3. Arrival without the preceding state.** If a user bookmarks this URL and visits it directly without submitting a request, the surface must not imply a request was made. Render the request form instead.

**Q4. Underlying data has changed.** If the user completes the reset on another device and returns to this tab, the surface must detect the completed state on focus and update accordingly (see state 44, original tab open after reset completed elsewhere).

**Q5. Arrival during or after a failure.** If the backend acknowledged the request but the email subsequently failed to send (state 20, deliverability failure), this surface cannot know. The copy on the canonical rendering must not promise delivery; it must describe the request as sent and offer a recovery path for the user who does not receive the email.

---

## Full specification: State 10. New-password form, empty

**Canonical rendering.** A form with password and confirm-password fields, policy hints, and a submit button. The account context (which account is being reset) is displayed.

**Q1. Return after time has passed.** The token has a validity window. If the user opens the form, leaves, and returns after the window has elapsed, submitting the form must not silently fail. The surface must detect token expiry on focus, not only on submit, and present state 22 (link expired) with a path to re-request.

**Q2. Arrival from notification, deep link, or different device.** This is the canonical arrival: the user clicks a link in email, which is a deep link by definition. The link may arrive on a device that has never signed in to the account before. The surface must not assume any session context; the account identity must be derived from the token and shown explicitly so the user confirms they are resetting the intended account.

**Q3. Arrival without the preceding state.** A user may arrive at the reset form without having requested a reset (forwarded link, testing scenario, malformed URL that happens to parse). The surface must not allow the reset to proceed; it must validate token presence and correctness before rendering the form.

**Q4. Underlying data has changed.** Between link click and form submit, the account's email may have changed, the account may have been deleted, or the user may have signed in normally and changed their password through a different path. The form submit must revalidate the token and the account state, not only the password value.

**Q5. Arrival during or after a failure.** If the user arrives at the form after a previous submit failed mid-commit (state 33), the surface must not assume the previous attempt failed cleanly. It must re-check the credential state before offering a second submit.

---

## Abbreviated specifications

### State 1. Request form, empty
- Q1: prefill the email field if the user was previously signed in on this device and is reasonably likely to be resetting their own account. Do not prefill across account boundaries.
- Q2: may be arrived at from a sign-in failure (wrong password); the form should accept a pre-populated email passed through this route.
- Q5: arrival after a rate-limit rejection (states 18, 19) must explain the cooldown rather than accepting another submission.

### State 2. Request form, email entered
- Q4: if the email was changed in the interim, validation hints should not become stale.

### State 3. CAPTCHA challenge
- Q1: if the user abandons the challenge and returns, the previous challenge is no longer valid; a new challenge must be presented.
- Q5: arrival after a failed challenge must present a fresh challenge with a cooldown on repeat failures.

### State 9. Two-factor challenge required
- Q1: if the user leaves the 2FA challenge and returns within its validity window, the challenge may still be valid; on expiry, revert to the token-validation error path.
- Q2: arrival on a device other than the one holding the second factor (e.g. authenticator app on another device) is the common case; the challenge must be completable across devices.
- Q5: arrival after a failed 2FA attempt (state 32) must rate-limit subsequent attempts.

### State 11. New-password form, entry in progress
- Q1: if the user pauses typing for an extended period, the token-expiry check from state 10 applies on next keystroke or focus.
- Q4: inherits from state 10.

### State 13. Reset committed, confirmation
- Q1: returning to this URL after the session ends must not re-commit. The surface must be safe to revisit.
- Q2: arrival from the password-change email (state 57) must be distinguished from arrival via the reset flow itself; the notification email is informational and its link should lead to an account-review surface, not this confirmation.

### State 14. Sessions elsewhere terminated
- Q2: the user on another device who was signed in is now signed out mid-task. Their rendering of this state (on *their* device, not the one where the reset happened) is its own specification and deserves design attention.

### State 15. Auto-signed-in on this device
- Q3: arrival at the signed-in state without having seen state 13 (commit confirmation) must not happen. If it does, a bug has occurred and the state is undefined.

### Transient states (4, 8, 12)
Users do not meaningfully remain on these states; re-entry in the sense of Q1 is not applicable. Q5 reduces to "what does failure at this state look like" and is already covered by the failure conditions these transients transition into (state 4 → 18/19; state 8 → 22/23/24/25/26/27; state 12 → 29/30/31/33).

---

Re-entry distinguishes this map from a canonical flow, but it is only one part of the v0.1 specification contract. Failure recovery, interruption reconciliation, surface constraints, ownership, and acceptance criteria are recorded alongside it in the JSON mirror.
