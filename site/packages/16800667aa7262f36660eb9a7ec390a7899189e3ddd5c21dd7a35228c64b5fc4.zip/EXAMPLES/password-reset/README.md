# Worked example: Password reset

Password reset is familiar, bounded, and unusually rich in failure conditions. The gap between its canonical screens—request, email, new password, confirmation—and its production condition space is easy to recognise.

This is an illustrative map, not a production case study. Its scope, priority, ownership, and evidence records demonstrate the v0.1 artifact contract; a live team must replace them with product evidence and accountable owners.

## Files

- [00-system-sentence.md](00-system-sentence.md): structural sentence and rejected drafts.
- [01-state-list.md](01-state-list.md): four-lens condition inventory.
- [02-triage.md](02-triage.md): illustrative scope, layers, and cause decisions.
- [03-reentry-pass.md](03-reentry-pass.md): readable re-entry specifications for lifecycle states.
- [04-state-map.json](04-state-map.json): complete v0.1 illustrative map, including specifications for all in-scope conditions and explicit five-question re-entry verdicts.

## Why it is useful

- Lifecycle conditions cover request, validation, 2FA, commit, and confirmation.
- Failures distinguish expiry, reuse, tampering, account changes, policy rejection, and commit errors.
- Interruptions capture different devices and browsers, elapsed time, prefetched links, network loss, and concurrent completion.
- Surfaces expose independent web, native, email, push, and accessibility constraints.

The map contains 58 conditions. Its high in-scope count is intentionally expansive so the example exposes the full method; it is not a recommended first-iteration commitment for an arbitrary team.

The important observation is not the count. It is that conditions outside the canonical flow otherwise fall through to framework defaults, generic toasts, redirects, silent failures, or unreviewed implementation choices. Stateful makes those conditions available for evidence-based triage and specification.

The JSON uses typed `transition`, `interrupted-by`, `reenters-as`, and `projects-to` relationships. It is a discovery/specification map, not an executable credential state machine.
