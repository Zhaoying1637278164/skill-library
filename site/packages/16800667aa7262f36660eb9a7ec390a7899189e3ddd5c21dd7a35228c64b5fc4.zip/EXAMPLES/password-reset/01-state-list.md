# 01. Condition Inventory

The four-lens condition inventory for the password-reset system, with short annotations on each condition. Lifecycle states, failures, interruption contexts, and surfaces are related lenses rather than equivalent state-machine node types. Numbers are for reference only; order within a lens is not meaningful.

System sentence:
> A password reset is a time-bound, single-use credential-replacement process, initiated from one context, continued via an out-of-band message, and completed under conditions that may differ from those at initiation.

## Not modelled in this iteration

To keep the example walkable end-to-end, the following are explicitly outside this map: passkey / WebAuthn-only accounts, accounts with multiple email addresses, backup-code recovery when email is inaccessible, and interactions with password managers. Each belongs to the wider condition space; its absence is an explicit boundary rather than a completeness claim.

---

## Lifecycle states

Conditions the system occupies while operating normally.

1. **Request form, empty.** The initial state of the request surface; no email entered.
2. **Request form, email entered.** Email is present in the field; submit not pressed. Client-side validation hints may have rendered.
3. **CAPTCHA challenge.** Presented on the request surface when abuse signals exceed a threshold. Not every request sees it; when it appears it is a real state of the system, not a modal overlay on another state.
4. **Request submitted, awaiting delivery.** Transient. The backend has accepted the request; the email is being composed or dispatched.
5. **Request acknowledged, email sent.** The origin surface has rendered confirmation. The email is in delivery.
6. **Email in the user's inbox, unread.** Rendered by the email client, not by the product; included because its first visible text (subject line, preheader) is under our control.
7. **Email opened, link not yet clicked.** The user is reading the email body.
8. **Link clicked, token being validated.** Transient. Token validity, expiry, and single-use status are being checked.
9. **Two-factor challenge required.** For accounts with a second factor enabled, the token's validation branches into a 2FA challenge before the new-password form is revealed. This is a required step, not a failure.
10. **New-password form, empty.** Token validated; form presented with the account context displayed.
11. **New-password form, entry in progress.** User typing; client-side policy hints rendering.
12. **New-password submitted, server-side validation.** Transient. Server-side policy, history, and breach-list checks.
13. **Reset committed, confirmation rendering.** Password replaced in the credential store; confirmation surface rendered.
14. **Sessions elsewhere terminated.** Other active sessions for this account have been invalidated.
15. **Auto-signed-in on this device.** The user is signed into a new session on the device where they completed the reset.
16. **Redirected to sign-in.** The alternative completion path, where the user is asked to sign in manually rather than being auto-signed-in.

## Failure conditions

Conditions the system occupies when something goes wrong.

17. **Email address not recognised.** The submitted email has no account. The standard design choice is not to reveal this, which routes the request to state 5 rather than rendering a distinct failure. The condition exists structurally even though the user does not see it.
18. **Rate-limited (per email).** Too many reset requests for this address within the window.
19. **Rate-limited (per IP or device).** Too many reset requests from this origin, regardless of address.
20. **Email deliverability failure.** The email bounced or was rejected. The user is unaware.
21. **Email delayed.** Delivered eventually but not within the expected window.
22. **Link expired.** The token is past its validity window at click time.
23. **Link already used.** The token was consumed by a prior request, often by a security scanner or the user clicking twice.
24. **Link tampered or malformed.** The token does not parse or does not match.
25. **Link for a different account than the one currently signed in.** The current session belongs to a different account. This consolidates what earlier drafts of this list recorded separately as a failure and as an interruption; they were the same state under different labels.
26. **Account deleted between request and click.** The account existed at request time but does not at click time.
27. **Account locked independently of the reset.** The account has been locked for another reason (abuse, compromise, admin action).
28. **Account is SSO-only.** Password reset is not applicable; the user was directed through the wrong flow.
29. **New password fails policy.** Too short, too common, missing character class, matches a breach list.
30. **New password matches the old password.** A specific policy case worth separating: the user's mental model says "I changed it" and the system must say otherwise.
31. **Concurrent reset requests.** Two requests are in flight. Whether the second link invalidates the first is a policy decision the state must encode.
32. **Two-factor challenge failed.** The 2FA challenge at state 9 was not completed successfully. Distinct from state 9, which is the challenge itself.
33. **Server error during commit.** Validation passed; the credential store write failed. Indeterminate from the user's perspective.

## Interruption contexts

Conditions arising from the passage of time, a change of context, or the user leaving the system.

34. **Tab closed before submit.** Request form abandoned.
35. **Tab closed after submit, before email arrives.** Origin surface is gone; the continuation point is the email.
36. **Email arrives on a different device from the request.** User decides whether to continue on the request device or the email device.
37. **Link clicked long after request.** Link still valid but the surrounding system state may have moved on (user may have signed in normally in the interim).
38. **Link opened in a different browser or incognito.** Request-origin session context is unavailable.
39. **Link prefetched by a security scanner.** Single-use token consumed before the user sees the email.
40. **Link prefetched by the email client.** Similar consumption failure with a different cause.
41. **Network drop during password submission.** Client cannot determine whether the commit succeeded.
42. **App backgrounded mid-form, returned to hours later.** The new-password form is still on screen but the token may have expired.
43. **Email missed, user re-requests.** The user did not see the first email and initiates a second request, producing state 31.
44. **Original tab still open after reset completed elsewhere.** The user completed the reset on a second device; the first device's tab still shows state 5 (request acknowledged). This is the state referenced in the re-entry specification for state 5.

## Surface conditions

Surfaces the system presents itself on.

45. **Request form on web.**
46. **Request form on mobile web.**
47. **Request form in native iOS.**
48. **Request form in native Android.**
49. **Email, HTML rendering.**
50. **Email, plain-text rendering.** A second rendering surface for the same structural content.
51. **Email, mobile preview pane.** The portion visible before the email is opened.
52. **Email, push-notification preview.** The portion visible in the lock-screen notification.
53. **Reset form, opened in the email client's embedded browser.** A constrained rendering environment with inconsistent session, JS, and autofill support.
54. **Reset form, opened in a stock browser.**
55. **Reset form, screen-reader rendering.** A second rendering surface; focus order and live-region announcements are specified here.
56. **Confirmation surface on each of the above.**
57. **Email notification to the user that their password has changed.** A rendering of the system's commit event, sent to the account's primary email regardless of where the reset was completed.
58. **Push notification to other devices that the password has changed.**

---

## Coverage

- **Term coverage: 8/8.** Every structural term from the system sentence generated states; [00-system-sentence.md](00-system-sentence.md) shows the term-by-term derivation.
- **Interrogation coverage: 16/16.** Each lifecycle state was asked the failure question and the interruption question; the failure and interruption inventories above are the answers. The transient states (4, 8, 12) answer the interruption question with *none* (the user does not remain on them); their failure answers are conditions 18/19, 22 to 27, and 29 to 33 respectively.
- **Surface coverage: 14/14.** Every surface listed maps to a surface condition. In the JSON mirror, in-scope lifecycle states carry `renders_on`; the exceptions are noted in the map itself (the two email conditions render in the email client, not the product; session termination is backend-only).
- **Cross-cutting: no inventory.** This is a standalone worked example; a real product would check the list against its product-wide inventory here.

The map totals 58 conditions. The number is not a target; it is where three successive probes produced only specialisations of existing records. This is a saturation heuristic, not proof of completeness. The items under *Not modelled in this iteration* would extend the map meaningfully.
