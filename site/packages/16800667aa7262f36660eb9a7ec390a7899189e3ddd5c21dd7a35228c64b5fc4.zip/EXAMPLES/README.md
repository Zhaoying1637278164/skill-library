# Examples

Two illustrative applications of Stateful. Each shows how a structural sentence produces a four-lens condition inventory, how the inventory is triaged, and how re-entry changes the specification.

The examples are deliberately broad so readers can see the method’s shape. They are not production case studies, proof of completeness, or evidence that the illustrative scope and risk decisions fit another product.

## Structure

- `00-system-sentence.md`: structural sentence, rejected drafts, and derivation.
- `01-state-list.md`: lifecycle states, failures, interruption contexts, and surfaces.
- `02-triage.md`: illustrative scope, layers, and failure-cause decisions.
- `03-reentry-pass.md`: detailed re-entry work for lifecycle states.
- `04-state-map.json`: the v0.1 condition map, including typed relationships, evidence, priority, specifications for every in-scope condition, and explicit re-entry verdicts.

The markdown keeps the examples readable. The JSON demonstrates the full artifact contract and validates against [schema.json](../schema.json). Priority scores cite illustrative evidence and must be replaced with live analytics, incidents, research, support, requirements, and domain evidence in real use.

## Examples

- **[Password reset](password-reset/):** bounded, transactional, and rich in rejected transitions.
- **[Medication tracker](medication-tracker/):** periodic, multi-surface, and dense in interruption and reconciliation concerns.

Run:

```text
python3 scripts/validate_state_map.py --profile handoff EXAMPLES/*/04-state-map.json
```
