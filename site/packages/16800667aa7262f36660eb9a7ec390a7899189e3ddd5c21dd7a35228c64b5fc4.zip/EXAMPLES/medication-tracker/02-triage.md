# 02. Triage

The conditions from [01-state-list.md](01-state-list.md) are annotated with illustrative scope. The **Layers** column records `fe` (frontend), `be` (backend), `dm` (data-model), and `inf` (infrastructure). The v0.1 JSON mirror adds likelihood, impact, confidence, rationale, evidence, status, owner, behavior, and acceptance criteria. Those values demonstrate the artifact shape and are not medical, safety, or production measurements.

Project assumption: consumer-facing mobile app (iOS + Android) with optional watch companion, supporting single-user accounts. No caregiver or clinician-shared workflows this iteration. No pharmacy or prescription-renewal integrations. Reminders use OS-level push and local notifications.

---

## Lifecycle states

| # | State | Scope | Layers | Note |
|---|---|---|---|---|
| 1 | Medication list empty | in | fe | |
| 2 | Adding a medication | in | fe, be, dm | Sub-flow states elided for this example; treated as a single in-scope state for triage purposes. |
| 3 | Medication scheduled, idle between doses | in | be, dm | |
| 4 | Dose window pending | in | fe, be | |
| 5 | Dose window open | in | fe, be | |
| 6 | Dose overdue | in | fe, be | |
| 7 | Dose missed | in | fe, be, dm | |
| 8 | Dose taken on time | in | fe, be, dm | |
| 9 | Dose taken late | in | fe, be, dm | |
| 10 | Dose skipped by user | in | fe, be, dm | |
| 11 | Dose auto-skipped by system | in | be, dm | |
| 12 | Daily schedule view | in | fe, be | |
| 13 | History view | in | fe, be | |
| 14 | Medication paused | in | fe, be, dm | |
| 15 | Medication discontinued | in | fe, be, dm | |
| 16 | Dose precondition unmet | in | fe, be | |

All sixteen lifecycle states are in-scope in this deliberately expansive example. The illustrative product value depends on distinguishing the shades of adherence (on-time, late, skipped, missed), but a live team must confirm that scope against its evidence and capacity.

## Failure conditions

| # | State | Scope | Layers | Cause | Note |
|---|---|---|---|---|---|
| 17 | Notification permission not granted | out-with-implication | fe, inf | user-input | The condition itself is handled at onboarding by a permissions primer, not as a distinct in-app state. Implication: the today view must render meaningfully without the presumption that reminders have fired. |
| 18 | Notification permission revoked after onboarding | in | fe, inf | user-input | Detect on app foreground; surface an explicit banner. Distinct from 17 because the user's mental model ("I granted permission earlier") must be corrected. |
| 19 | Schedule conflict | in | be | user-input | |
| 20 | Daily dose exceeds safe total | in | fe, be | user-input | |
| 21 | Reminder delivery failed | out-with-implication | inf | external | The app cannot reliably detect this from device-side. Implication: the today view must not assume a reminder fired; act-now affordances must remain visible even when a reminder was expected. |
| 22 | Backend sync failure | in | fe, be | system | |
| 23 | Dose marked in distant past | in | fe, be, dm | user-input | |
| 24 | Device clock significantly off | out-with-implication | be, inf | external | Rare enough not to design a dedicated rendering; implication: server-time reconciliation on sync, and a single generic "something looks off with your device's time" state re-using the sync-failure surface. |
| 25 | Time zone change not reconciled | in | fe, be | external | |
| 26 | Daylight saving boundary | out-with-implication | be, dm | external | Handled by the schedule engine rather than by a rendered state. Implication: the engine's decision (skip vs double-dose) is a policy baked into the data model, documented so it is not rediscovered later. |
| 27 | Dose double-confirmed within short window | in | fe, be | user-input | |
| 28 | Interaction warning | in | fe, be | policy | |

## Interruption contexts

| # | State | Scope | Layers |
|---|---|---|---|
| 29 | App backgrounded through multiple dose windows | in | fe, inf |
| 30 | Travel across time zones mid-day | in | be, inf |
| 31 | Phone off at reminder time | in | inf |
| 32 | Do Not Disturb at reminder time | in | inf |
| 33 | Airplane mode at scheduled dose | in | fe, inf |
| 34 | User opens app days later | in | fe, be |
| 35 | Notification tapped from lock screen | in | fe, inf |
| 36 | Cross-device action race | in | fe, be |
| 37 | Battery saver suppressing background tasks | in | inf |
| 38 | Medication deleted with doses in history | in | fe, be, dm |

All ten interruption contexts are in-scope. Medication tracking is a system the user visits intermittently and which must behave correctly across long absences, OS-level interference, and multi-device use. Interruptions are not edge cases for this class of product; they are the dominant condition of use.

## Surface conditions

| # | State | Scope | Layers | Note |
|---|---|---|---|---|
| 39 | Home-screen widget (compact) | in | fe | |
| 40 | Home-screen widget (medium) | in | fe | |
| 41 | Lock-screen live activity | in | fe | |
| 42 | Watch complication | in | fe | |
| 43 | Push notification, first reminder | in | fe, inf | |
| 44 | Push notification, snooze repeat | in | fe, inf | |
| 45 | Push notification, overdue escalation | in | fe, inf | |
| 46 | In-app today view | in | fe | |
| 47 | In-app history view | in | fe | |
| 48 | In-app medication detail | in | fe | |
| 49 | Screen-reader rendering | in | fe | |
| 50 | Weekly export / PDF | out-with-implication | fe, be | Not designed this iteration. Implication: the data model must preserve enough history to support export later; per-dose entries must carry their medication name rather than an id that might later be deleted. |
| 51 | Voice-assistant rendering | out | fe, inf | Platform integrations deferred. Becomes in-scope when a specific assistant integration is committed to. |
| 52 | Custom notification grouping | out | fe, inf | OS-default grouping is accepted for this iteration. |

---

## Totals

- **In:** 45
- **Out-with-implication:** 5
- **Out:** 2

**By layer (in-scope states only; states often touch more than one):**

- Frontend: 38
- Backend: 26
- Data-model: 11
- Infrastructure: 11

**By failure cause (in-scope failures only):**

- User-input: 5
- System: 1
- External: 1
- Policy: 1

The cause distribution shows medication tracking's different shape from password reset. Where reset is policy-heavy (the system enforces credential rules), tracking is user-input-heavy: most in-scope failures come from what the user configures or does. The design surface implication: most failure responses are about coaching the user to a valid configuration. Notice the contrast with the *out-with-implication* tier (states 17, 21, 24, 26), which is mostly `external`: even though external causes are deferred from the in-scope design this iteration, they constrain the in-scope work via the implication notes.

Total listed: 52. The distribution differs from the password-reset example in two ways worth noting. Lifecycle states are all in-scope (the product's core value lives in the reconciliation of dose states, none of which can be deferred). A higher share of surface conditions are in-scope (the system reaches the user on surfaces the user does not actively visit, widget, watch, push, and under-designing any of these leaves the user unreminded).

The layer distribution shows medication tracking's different shape from password reset: data-model engagement is common (every dose state needs to persist), backend engagement is substantial (schedule computation, sync reconciliation), and infrastructure is roughly twice as load-bearing (notification delivery is on the critical path of the product's value).
