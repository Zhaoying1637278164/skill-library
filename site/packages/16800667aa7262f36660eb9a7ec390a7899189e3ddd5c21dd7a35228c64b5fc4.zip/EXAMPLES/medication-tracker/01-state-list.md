# 01. Condition Inventory

The four-lens condition inventory for the medication-tracker system, with short annotations. Lifecycle states, failures, interruption contexts, and surfaces are related lenses rather than equivalent state-machine node types. Numbers are for reference only; order within a lens is not meaningful.

System sentence:
> A medication tracker is a time-indexed obligation ledger that reconciles scheduled doses against taken doses across varying adherence, delay, substitution, and prescription-change conditions, rendered on surfaces the user visits intermittently.

## Not modelled in this iteration

To keep the example walkable end-to-end, this map excludes multi-user or caregiver-shared accounts, pharmacy refill integrations, drug-interaction databases beyond a warning flag, insurance and renewal flows, paediatric or weight-based dosing, and dose substitution. Each belongs to the wider condition space; its absence is an explicit boundary rather than a completeness claim.

---

## Lifecycle states

Conditions the system occupies while operating normally.

1. **Medication list empty.** First use, or the user has removed all medications. The home surface has no scheduled obligations to reconcile.
2. **Adding a medication.** Configuration flow: name, strength, schedule, preconditions, duration. A sub-flow with its own states elided here for brevity.
3. **Medication scheduled, idle between doses.** The system is between dose windows for this medication. No action required from the user; the obligation exists but is not yet due.
4. **Dose window pending.** The next dose is within view (e.g. within an hour) but the window has not opened. A "coming up" rendering, not an "act now".
5. **Dose window open.** The dose is due now, within its acceptable window. The primary action, mark as taken, is available.
6. **Dose overdue.** The window has passed but not by enough to count as missed. Still takeable; the system prompts more urgently and may offer "take late" versus "skip".
7. **Dose missed.** Past the missed threshold. No longer takeable for this window; recorded as missed in the ledger.
8. **Dose taken on time.** Recorded within the window. The terminal state for a successfully reconciled dose.
9. **Dose taken late.** Recorded after the window but before the missed threshold. Distinct from on-time in the ledger; adherence reporting uses the distinction.
10. **Dose skipped by user.** User explicitly chose to skip. Optionally records a reason.
11. **Dose auto-skipped by system.** System skipped because the medication is paused or discontinued during the window. Distinct from user-skip because the obligation never surfaced to the user.
12. **Daily schedule view.** Aggregate rendering of today's obligations: what has been taken, what is pending, what is overdue. The default home surface once medications are configured.
13. **History view.** Ledger view across days or weeks. Aggregates taken, late, skipped, missed.
14. **Medication paused.** User or provider has paused this medication. Scheduled doses do not surface as obligations; the medication persists in configuration.
15. **Medication discontinued.** User or provider has discontinued. Future doses are removed from the schedule; historical doses remain in the ledger.
16. **Dose precondition unmet.** The dose has a precondition (take with food, take on empty stomach) that the system cannot verify. The dose window is open but the action requires user confirmation of the precondition state.

## Failure conditions

Conditions the system occupies when something goes wrong.

17. **Notification permission not granted.** At onboarding the user did not grant permission to send reminders. The system cannot discharge its reminder obligation.
18. **Notification permission revoked after onboarding.** User granted then revoked in OS settings. The system must detect this and surface it; until it does, the user may expect reminders that never fire.
19. **Schedule conflict.** Two doses scheduled at identical times across different medications. Not necessarily an error, but a condition the system may want to consolidate.
20. **Daily dose exceeds safe total.** User configured a schedule whose daily sum exceeds a safety threshold for the medication. A policy reject at configuration time.
21. **Reminder delivery failed.** The push / local notification did not reach the user's device (push service failure, device offline past the notification's TTL).
22. **Backend sync failure.** User's actions (mark taken, skip) have not synced to the backend. Local state diverges from remote.
23. **Dose marked in distant past.** User attempts to mark a dose taken that is more than a day old. Data-integrity policy: the system may accept, reject, or require confirmation.
24. **Device clock significantly off.** System time disagrees with server time by more than a threshold. Schedules computed against device time would be wrong.
25. **Time zone change not reconciled.** User travelled; device timezone updated; schedule has not been reconciled against the new zone.
26. **Daylight saving boundary.** The DST transition either doubles a dose or skips one, depending on direction. Schedule engine must decide which.
27. **Dose double-confirmed within short window.** User marked the same dose taken twice within seconds, likely double-tap. The system must decide whether to treat as one confirmation or two.
28. **Interaction warning.** Two medications scheduled within an unsafe window for a known interaction. Flagged at configuration time; may re-surface if schedules change.

## Interruption contexts

Conditions that arise from the passage of time, a change of context, or the user leaving the system.

29. **App backgrounded through multiple dose windows.** The user was not looking; several windows opened and some closed without action. On next open, the system has accumulated state to reconcile.
30. **Travel across time zones mid-day.** Device timezone changes between dose windows. Each subsequent dose is now computed against a different zone.
31. **Phone off at reminder time.** The device was off at the moment a notification would have fired. OS delivers on boot, possibly after the window has passed.
32. **Do Not Disturb at reminder time.** Notification suppressed. The system cannot distinguish "user saw it" from "OS withheld it".
33. **Airplane mode at scheduled dose.** Local notifications fire but network sync is unavailable; remote state diverges.
34. **User opens app days later.** Many dose windows have passed. The daily schedule view is showing history, not today.
35. **Notification tapped from lock screen.** Deep link into a specific dose. The system must handle arrival at the dose without the preceding schedule-view context.
36. **Cross-device action race.** User marks a dose on one device; opens another device seconds later. Second device may not have synced yet; show a prior state.
37. **Battery saver suppressing background tasks.** Device OS has suppressed the app's background work. Reminders do not fire, sync lags.
38. **Medication deleted with doses in history.** User deletes a medication that has recorded doses. History must survive the deletion.

## Surface conditions

Surfaces the system presents itself on.

39. **Home-screen widget (compact).** One-line summary: next dose name and time.
40. **Home-screen widget (medium).** Today's schedule condensed, with a primary action.
41. **Lock-screen live activity.** For dose windows that are open now, a live activity surface (iOS) or persistent notification (Android).
42. **Watch complication.** Smallest surface, typically a single next-dose indicator.
43. **Push notification, first reminder.** The initial reminder at the window open.
44. **Push notification, snooze repeat.** Follow-up reminder after a user-configured snooze.
45. **Push notification, overdue escalation.** Stronger reminder once the window has closed but the dose is not yet missed.
46. **In-app today view.** The canonical today surface.
47. **In-app history view.** The ledger view.
48. **In-app medication detail.** Detail surface for a single medication: schedule, recent history, preconditions.
49. **Screen-reader rendering.** Semantic rendering of the today view, live-region announcements for dose-window transitions.
50. **Weekly export / PDF.** A printable summary for sharing with a clinician.
51. **Voice-assistant rendering.** "Hey assistant, have I taken my X?" and the system's answer.
52. **Custom notification grouping for overlapping doses.** Grouped rendering when multiple doses fire in the same window.

---

## Coverage

- **Term coverage: 10/11.** Every structural term from the system sentence generated at least one state, except *substitution*, which generated none. The check forced a decision: substitution states (taking an equivalent medication in place of the scheduled one) are real but out of this iteration's scope, so the condition moved to *Not modelled in this iteration* above rather than sitting decoratively in the sentence.
- **Interrogation coverage: 16/16.** Each lifecycle state was asked the failure question and the interruption question; the failure and interruption inventories above are the answers. The terminal dose records (conditions 8 to 11) answered *none* to the failure question, with one exception: double confirmation (condition 27) attaches to a just-recorded dose.
- **Surface coverage: 14/14.** Every surface listed maps to a surface condition; lifecycle states carry `renders_on` in the JSON mirror.
- **Cross-cutting: no inventory.** This is a standalone worked example; a real product would check the list against its product-wide inventory here.

The map totals 52 conditions. The number is not a target; it is where three successive probes produced only specialisations of existing records. This is a saturation heuristic, not proof of completeness.
