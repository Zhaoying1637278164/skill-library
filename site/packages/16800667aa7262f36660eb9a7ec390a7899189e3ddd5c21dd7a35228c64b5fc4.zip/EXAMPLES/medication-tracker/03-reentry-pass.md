# 03. Re-Entry Pass

This readable view focuses on the five-question re-entry review for in-scope lifecycle states. Full prose is shown for two conditions and abbreviated prose for the others. The v0.1 JSON mirror records all five verdicts explicitly—including `not-applicable` reasons—and gives every in-scope lifecycle, failure, interruption, and surface condition a behavior, owner, and acceptance criterion.

The medication tracker has no transient lifecycle states in this example; each can remain relevant long enough to require re-entry review.

The five questions:

1. What does the user see if they return after time has passed?
2. What does the user see if they arrive from a notification, deep link, or different device?
3. What does the user see if they arrive without the preceding state having been shown?
4. What does the user see if the underlying data has changed since they last saw this state?
5. What does the user see if they arrive during or after a failure in the system?

Re-entry is the medication-tracker's default, not its exception: the user visits the app intermittently, often arriving from a notification rather than from a prior in-app state, and often after a gap long enough that data has changed. Re-entry specifications compose heavily here; write them together, read them together, check for coherence.

---

## Full specification: State 5. Dose window open

**Canonical rendering.** A today surface showing the dose is due now, with a primary "mark as taken" action, secondary "skip" action, and context about the dose (medication name, strength, preconditions). Rendered on any of the in-scope surfaces (today view, widget, watch, push).

**Q1. Return after time has passed.** If the user returns mid-window, the rendering reflects the current window status. If the user returns after the window has closed, this state has transitioned: the dose is now overdue (state 6) or missed (state 7). The return surface must show the transitioned state, not the state at leave-time.

**Q2. Arrival from notification, deep link, or different device.** Canonical arrival. A tap on the first-reminder notification (state 43) opens this state directly, bypassing the today view. The surface must be self-sufficient: show which medication, which dose, and the take / skip actions, without assuming the user saw the today view first. Arrival from another device requires an optimistic-then-reconciled flow: render the state as currently known locally, then reconcile with the backend; if the dose was taken on the other device, transition to state 8 and surface a lightweight confirmation rather than failing.

**Q3. Arrival without the preceding state.** The user may arrive at this state without having seen state 4 (dose window pending), for example, when a notification fires while the app was backgrounded. This state must not assume the user had any warning; it is the user's first awareness of the dose.

**Q4. Underlying data has changed.** Between the moment the window opened and the moment the user arrives, the medication may have been paused, discontinued, or had its schedule changed by the user on another device. The surface must revalidate against current configuration before accepting a mark-as-taken; if the medication is now paused, route to state 14's rendering rather than recording a dose against a paused medication.

**Q5. Arrival during or after a failure.** If the reminder did not fire (states 17, 18, 21, 32, 37) the window may be open without the user being aware. The today view must render the open dose prominently on re-open regardless of whether the reminder fired. Backend sync failure (state 22) means a mark-as-taken may not persist; the surface must accept the action optimistically, queue it, and reconcile.

---

## Full specification: State 12. Daily schedule view

**Canonical rendering.** Today's obligations, ordered by time, with each dose shown in its current state (pending, open, overdue, missed, taken, skipped). Aggregate adherence summary for the day at the top or as a running score.

**Q1. Return after time has passed.** If the user returns later the same day, doses that were pending or open have transitioned; the rendering must reflect current state rather than cached state. If the user returns on a subsequent day, this surface is now rendering a new day and should show the new day's schedule; yesterday's ledger moves to the history view (state 13).

**Q2. Arrival from notification, deep link, or different device.** Most common arrival is from a notification tap into a specific dose; a return-to-home action then brings the user to this view. On a different device, the surface may render stale data briefly during sync; show a subtle "updating" affordance rather than blocking the view.

**Q3. Arrival without the preceding state.** A new user lands on the medication-list-empty state (state 1) rather than this one; this state is entered for the first time after a first medication is configured. Arrival without medications configured must route to state 1.

**Q4. Underlying data has changed.** Data commonly changes between visits: doses marked on another device, medications paused, schedules edited. The surface must reconcile on foreground and render the current state, not the state at last visit. Changes that would surprise the user (an in-progress dose now marked taken) should surface a lightweight indication of the change.

**Q5. Arrival during or after a failure.** If multiple reminders failed (e.g. after battery-saver suppressed background work, state 37), several doses may be overdue or missed on arrival. The surface must not hide this behind the "today" summary; overdue doses should be prominent, and the user's ability to mark them late should be preserved where the missed threshold has not been crossed.

---

## Abbreviated specifications

### State 1. Medication list empty
- Q1: returning after removing all medications must render this state faithfully rather than persisting a stale schedule view.
- Q2: arrival from a deep link to a deleted medication should land here with a brief explanation.

### State 2. Adding a medication
- Q1: if the user abandons mid-flow and returns, preserve the partial configuration locally; prompt to resume or discard.
- Q5: a validation failure (state 20, daily dose exceeds safe total) must not clear entered fields.

### State 3. Medication scheduled, idle between doses
- Q1: the next-dose time renders from absolute scheduled time, not from a stale "in 2 hours" that was computed at leave-time.
- Q4: schedule changes on another device must re-render the next-dose indicator.

### State 4. Dose window pending
- Q2: arrival from a pre-window notification ("coming up in 15 minutes") must show the same information as entering via the today view.
- Q5: if the prior dose failed to sync (state 22), this view must still render the upcoming dose.

### State 6. Dose overdue
- Q1: on return, check whether the missed threshold has been crossed and transition to state 7 if so.
- Q2: escalation notification (state 45) deep-links here.
- Q5: same backend-sync handling as state 5.

### State 7. Dose missed
- Q4: if policy changes (e.g. an admin-edited schedule retroactively), the missed status may reverse; the history-view rendering must handle this.

### State 8. Dose taken on time
- Q1: safe to revisit; does not re-commit.
- Q4: reversal within grace period (see state 27) may return the dose to state 5.

### State 9. Dose taken late
- Similar to state 8.

### State 10. Dose skipped by user
- Q4: the reason, if recorded, must persist through history rendering.

### State 11. Dose auto-skipped by system
- Q3: rendered in history without the user having seen an in-app prompt. Copy must explain why the system skipped (paused medication).

### State 13. History view
- Q1: returning shows the same data; the ledger is append-only from the user's perspective.
- Q2: deep-linked history (from a weekly summary notification) must scroll to the referenced date.

### State 14. Medication paused
- Q2: if paused by a provider-integration (out of scope this iteration but retained as out-with-implication), the cause must render; pause by the user renders differently from an external pause.

### State 15. Medication discontinued
- Q3: the discontinuation decision is generally initiated from medication detail (state 48), but deep links from external systems may bring the user here; explain the current state.

### State 16. Dose precondition unmet
- Q5: if the user confirms the precondition and then fails to complete (e.g. network drop), the precondition confirmation must not be lost on retry.

---

The medication-tracker example emphasises composition. Arrival at state 5 (dose window open) from a notification, after the app has been backgrounded across timezone change, during battery-saver suppression, and with pending sync failures is a plausible Tuesday. A live map should promote this combination into an explicit high-risk scenario with its own acceptance criteria and tests.
