# 00. System Sentence

The system sentence for the medication-tracker example, with two rejected drafts and the reasoning for the final version.

---

## First attempt (feature-framed)

> A medication tracker helps people remember to take their pills on time and records whether they took them.

This is a feature sentence. It names a beneficiary (people), a goal (remembering), and an outcome (on-time). The verbs are *helps* and *records*, which describe what the product does *for* the user; they do not describe what the product *is*. Derived states collapse into "reminded" and "recorded", which are events, not conditions the system occupies.

## Second attempt (flow-framed)

> A medication tracker is an app where the user sets up a schedule, receives reminders at scheduled times, and marks each dose as taken or missed.

This reads better. It contains nouns the system is made of (schedule, reminders, doses) and it hints at the periodic structure. It is still inadequate, for two related reasons. First, it describes the system in terms of a user sequence rather than the object's own structure: the user enters, the user marks. Second, the sequence omits the conditions under which the system actually spends most of its time: waiting between dose windows, carrying accumulated state across days, reconciling timestamps against wall-clock time, rendering on surfaces other than the primary app.

The condition inventory this sentence generates is thin in exactly the places where medication trackers fail in production: time-zone and daylight-saving boundaries, accumulated overdue doses after a gap in app use, interaction warnings across multiple medications, widget and watch rendering on days the user never opens the app.

## Final version (structural)

> A medication tracker is a time-indexed obligation ledger that reconciles scheduled doses against taken doses across varying adherence, delay, substitution, and prescription-change conditions, rendered on surfaces the user visits intermittently.

This sentence describes what the system *is*, as an object that exists over time.

Underlining the structural terms: *time-indexed*, *obligation ledger*, *reconciles*, *scheduled doses*, *taken doses*, *adherence*, *delay*, *substitution*, *prescription-change*, *rendered on surfaces*, *visits intermittently*.

Each generates states:

- **time-indexed** → states keyed to windows, not events: window pending, window open, window overdue, window missed
- **obligation ledger** → states for a durable record: history view, export, reconciliation with retroactive edits
- **reconciles** → states that arise from disagreement between scheduled and taken (on-time, late, skipped, missed, double-confirmed)
- **adherence / delay** → states for the shades between taken and missed: taken-late, auto-skipped, overdue-not-yet-missed
- **prescription-change** → states for paused, discontinued, auto-skipped medications
- **substitution** → generated no state in this iteration; the condition inventory's coverage check catches this and scopes it out explicitly (see [01-state-list.md](01-state-list.md))
- **rendered on surfaces** → states for widget, watch, lock-screen live activity, push, screen-reader, export
- **visits intermittently** → re-entry as the default: opening the app after days, deep-linking from a notification, waking the watch

The sentence does not list the state space. It generates it. The generative-ness of the sentence is the test for whether it is structurally useful.
