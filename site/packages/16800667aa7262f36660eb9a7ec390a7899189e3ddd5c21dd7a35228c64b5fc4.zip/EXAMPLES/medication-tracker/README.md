# Worked example: Medication tracker

The medication tracker complements password reset with a continuous, time-indexed system. Dose windows change while nobody is looking, actions occur on multiple devices, and value is delivered on surfaces the user visits intermittently.

This is an illustrative map, not medical guidance, a validated safety case, or a production case study. Live work requires clinical/domain review, measured evidence, explicit safety ownership, and verification beyond this method.

## Files

- [00-system-sentence.md](00-system-sentence.md): structural sentence and rejected drafts.
- [01-state-list.md](01-state-list.md): four-lens condition inventory.
- [02-triage.md](02-triage.md): illustrative scope, layers, and cause decisions.
- [03-reentry-pass.md](03-reentry-pass.md): readable re-entry specifications for lifecycle states.
- [04-state-map.json](04-state-map.json): complete v0.1 illustrative map, including specifications for all in-scope conditions and explicit five-question re-entry verdicts.

## Why it is useful

- It is periodic rather than a single transaction.
- Notification, widget, watch, lock-screen, history, and accessibility surfaces are load-bearing.
- Interruption contexts include app absence, device state, timezone changes, battery restrictions, and cross-device races.
- Re-entry conditions compose: an overdue dose may be opened from a notification after timezone change while another device has unsynced data.

The map contains 52 conditions. Its broad in-scope selection exposes the method’s full shape; it is not a delivery recommendation. Teams should re-score every record using product analytics, incidents, support, research, policy, and clinical/domain evidence.

The JSON uses typed relationships and category-specific specification contracts. It remains a discovery/specification artifact, not an executable scheduler or safety verification.
