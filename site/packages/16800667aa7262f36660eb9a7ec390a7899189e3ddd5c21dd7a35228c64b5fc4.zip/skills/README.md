# Skills

Agent-assisted workflows for [PRACTICE.md](../PRACTICE.md), packaged as portable `SKILL.md` folders. The method is the source of truth; the skills accelerate interrogation, evidence gathering, and artifact maintenance.

## Installing

**Claude Code**

```text
/plugin marketplace add mskayyali/Stateful
/plugin install stateful@stateful
```

**Codex**

```text
codex plugin marketplace add mskayyali/Stateful
```

Install from the plugin browser, then start a new session.

**Most other agents**

```text
npx skills add mskayyali/Stateful
```

Manual fallback: copy the skill folders into the skill directory used by your agent. Manual copies do not update automatically.

## Standard paths

### New feature

1. **[system-sentence](system-sentence/SKILL.md)** confirms a structural sentence and records evidence and assumptions.
2. **[state-list](state-list/SKILL.md)** builds four related inventories: lifecycle states, failures, interruptions, and surfaces.
3. **[state-triage](state-triage/SKILL.md)** recommends risk and scope, then stops for human confirmation.
4. **[reentry-pass](reentry-pass/SKILL.md)** specifies every in-scope condition and runs the five-question re-entry review on eligible lifecycle states.

### Existing feature

1. **[state-audit](state-audit/SKILL.md)** compares an evidence-derived expected inventory with code, tests, designs, telemetry, incidents, and other observed handling.
2. Run **state-triage** on the gaps.
3. Run **reentry-pass** to specify confirmed in-scope work.

### Cross-cutting

- **[state-prompt](state-prompt/SKILL.md)** creates a generation prompt for one condition or one explicit high-risk composition.
- **[state-graph](state-graph/SKILL.md)** renders a typed condition-map view without pretending it is an executable statechart.

## Artifact contract

The skills maintain:

- `STATEFUL.md`: compact human-readable working memory;
- optional `state-map.json`: v0.1 machine-readable condition records and typed relationships;
- the team’s existing design, work, implementation, and test systems through links.

The JSON lifecycle is explicit:

- discovery creates records with `status: discovered`, evidence, and no invented scope;
- confirmed triage adds priority and scope, setting `status: triaged`;
- specification adds behavior, owner, acceptance criteria, category requirements, and re-entry review, setting `status: specified`;
- teams add implementation and test links before advancing to `implemented` or `verified`.

Validate a JSON map with:

```text
python3 scripts/validate_state_map.py state-map.json
```

## Agent boundaries

- The agent may generate candidates; it must cite evidence or label assumptions.
- The agent may recommend scope; a human confirms before persistence.
- Code is evidence of implementation, not the only account of intended behavior.
- “Saturation reached” is a bounded stopping rule, not proof of completeness.
- A condition name is not a specification.
- The JSON mirror is not a direct runtime code-generation contract.

Each skill frontmatter contains only `name` and `description` so the same folders remain portable across agents.
