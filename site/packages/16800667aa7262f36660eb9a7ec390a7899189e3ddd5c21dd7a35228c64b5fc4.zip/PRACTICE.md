# Practice

A practical guide to running Stateful on a feature, surface, or screen. No visual-design background is assumed.

The output is a condition map: systematic coverage of the materially distinct conditions relevant to the current work, with evidence and scope recorded, and every in-scope condition specified. It can live in a design file, work tracker, document, `STATEFUL.md`, or an optional `state-map.json`.

Stateful is a discovery and specification practice. It does not prove completeness, replace an executable statechart, or verify an implementation by itself.

## Vocabulary

- **Condition.** The umbrella record in the map: a lifecycle state, failure, interruption context, or surface projection.
- **Lifecycle state.** A condition the product or domain persists in or renders distinctly: *configuration unsaved*, *dose overdue*.
- **Failure.** A rejected or unsuccessful transition requiring a deliberate response: *link expired*, *commit failed*.
- **Interruption.** Context that changes reconciliation or rendering on return: *tab closed mid-flow*, *device switched*, *time passed*.
- **Surface.** A projection channel with independent constraints: *email HTML*, *watch complication*, *screen reader*.
- **Condition space.** All possible combinations of data, time, actors, dependencies, context, and surfaces. Effectively infinite in a non-trivial system.
- **Condition map.** The bounded artifact relevant to the current feature and iteration.
- **Scope.** `in`, `out-with-implication`, or `out`.
- **Status.** `discovered`, `triaged`, `specified`, `implemented`, or `verified`.

The four lenses are not four equivalent machine-state node types. They compose:

```text
lifecycle state × interruption context × surface × data/dependency condition
```

The map keeps individual conditions reviewable and uses typed relationships and composite scenarios to show the combinations that matter.

---

## Scope: one sentence per feature or surface

Run the method where conditions are dense: a feature or surface, not an entire product. Sign-in, checkout, reader, library, and settings each get their own map.

For a whole product, maintain:

- one sentence and map per feature or surface;
- a short cross-cutting inventory for recurring conditions such as unauthenticated, offline, subscription expired, sync conflict, low storage, and first-run;
- references from feature maps to the applicable cross-cutting conditions.

The specification for a cross-cutting condition belongs with each feature that renders or handles it. “Offline” is not one universal design.

## Evidence before confidence

Use more than feature copy or source code. Evidence can come from:

- requirements, policies, and domain rules;
- research and observed workflows;
- analytics and telemetry;
- support tickets and complaint themes;
- incidents and postmortems;
- code, tests, schedulers, enums, data models, and dependency contracts;
- design files and prototypes;
- explicit assumptions when no stronger source exists.

Record a source for every condition. Mark confidence as `hypothesis`, `informed`, or `measured`. Code is evidence of what exists, not proof of what ought to exist.

---

## The four steps

### 1. Describe

Write one sentence about what the system *is* as an object that exists over time, not what it *does* for the user.

A feature-framed sentence—“a meeting invite helps people schedule a time”—generates little. A structural sentence generates conditions from its verbs and time-bearing nouns:

> A meeting invite is a time-bound proposal that gathers responses and resolves into a confirmed, cancelled, or unresolved event as the proposed time approaches.

Before drafting, gather five kinds of raw material:

1. **Time.** What exists when nobody is looking? Which windows, schedules, or expiries govern it?
2. **Lifecycle.** What is created, and how can it resolve, cancel, expire, supersede, or remain abandoned?
3. **Channels.** Where does the process leave the product and come back?
4. **Completion differences.** What can change between start and finish: data, actor, device, session, permission, dependency, or time?
5. **Surfaces.** Where does the system present itself besides the primary screen?

**Done gate.** Three to five materially distinct lifecycle states fall directly from the sentence. A colleague unfamiliar with the feature can name at least three conditions without prompting. The team confirms the sentence before mapping.

### 2. Map

Build four inventories. Keep them linked, but do not flatten their semantics.

#### Lifecycle states

Underline structural verbs and time-bearing nouns. For each verb, consider before, during, and after. For time-bearing nouns, consider before, within, and beyond the relevant window.

Expect roughly 8–15 lifecycle states for a non-trivial feature, but treat the number as a diagnostic, not a target.

#### Failures

For each lifecycle state and transition, ask what can prevent or reject the next change. Push beyond “validation error” to domain-distinct responses such as *token already used*, *password matches old*, or *provider declined the operation*.

Record the cause:

- `user-input`: the supplied value or action was rejected;
- `system`: an internal error or bug;
- `external`: a dependency failed;
- `policy`: a deliberate business or domain rule rejected the action.

#### Interruptions

For each lifecycle state, ask what happens when:

- the user leaves or the process is suspended;
- time passes;
- the device, session, actor, permission, network, or dependency changes;
- the underlying data changes elsewhere.

An interruption record is context applied to lifecycle states, not necessarily another lifecycle node.

#### Surfaces

Inventory each place where the condition reaches the user: web, native app, email, push, widget, watch, screen reader, print, webhook, or another system.

A surface specification is not merely a resized screen. It carries content, available actions, accessibility, freshness, security, and privacy constraints. Use `renders_on` or a `projects-to` relationship to connect logical conditions to surfaces.

#### Relationships

The JSON mirror uses four typed relationships:

- `transition`: lifecycle or failure condition to another lifecycle or failure condition;
- `interrupted-by`: a lifecycle or failure condition affected by an interruption;
- `reenters-as`: an interruption resolving into a lifecycle or failure condition;
- `projects-to`: a lifecycle or failure condition presented on a surface.

These relationships are descriptive. They do not contain the complete semantics required by an executable state machine.

#### Coverage and stopping

Check:

- every structural term generates a lifecycle state or is removed as decorative;
- every lifecycle state has an explicit failure answer and interruption answer, including `none`;
- every surface is connected to at least one applicable condition;
- applicable cross-cutting conditions are referenced;
- each condition cites evidence or is marked as an assumption.

Stop when three successive probes produce only specialisations of existing records. This is a saturation heuristic, not proof of completeness. Record known unknowns and the evidence sources not yet consulted.

### 3. Decide

For each condition, record:

- **Likelihood:** low, medium, or high.
- **Impact:** low, medium, or high.
- **Confidence:** hypothesis, informed, or measured.
- **Rationale:** one sentence grounded in cited evidence.
- **Scope:** `in`, `out-with-implication`, or `out`.

Scope meanings:

- **`in`.** Must be specified in this iteration.
- **`out-with-implication`.** Deferred, but constrains in-scope naming, copy, data, architecture, or policy. Record the implication.
- **`out`.** Deferred with no current implication. Record what would cause it to be reconsidered.

Likelihood alone is not priority. A rare, irreversible, security-sensitive, or safety-critical condition may outrank a common inconvenience.

The agent may recommend. Product, design, engineering, operations, and domain owners decide. Do not persist agent-recommended scope until a human confirms it.

**Done gate.** Every condition has evidence, risk, confidence, scope, and a rationale. Preconditions and related conditions have compatible scope decisions.

### 4. Specify

Every in-scope condition receives a common contract:

- behavior;
- accountable owner;
- at least one testable acceptance criterion;
- design, implementation, and test links as they become available.

Then add the contract for its category.

#### Lifecycle-state contract

Specify:

- canonical rendering or externally observable behavior;
- permitted and prohibited actions;
- required data and invariants;
- next valid transitions and their guards;
- stale-data and concurrency behavior.

For each non-transient, in-scope lifecycle state, review all five re-entry questions:

1. What happens after time has passed?
2. What happens on arrival from a notification, deep link, or different device?
3. What happens without the preceding condition having been shown?
4. What happens if underlying data changed?
5. What happens during or after a failure?

Every question is recorded as `applicable` with a specification or `not-applicable` with a reason. Applicable conditions can compose; review important combinations as scenarios rather than assuming five independent answers remain coherent.

#### Failure contract

Specify:

- what the user sees and whether sensitive details are withheld;
- which input or work is preserved;
- retry, alternate path, escalation, or safe exit;
- idempotency and duplicate-action behavior where relevant;
- logging, alerting, and correlation requirements for system or external failures.

#### Interruption contract

Specify:

- what persists and for how long;
- what is revalidated on return;
- reconciliation and conflict behavior;
- whether the user resumes, restarts, or lands in another lifecycle state;
- recovery when the original context no longer exists.

#### Surface contract

Specify:

- content and information priority;
- supported actions and fallback path;
- freshness and stale-content behavior;
- accessibility and platform constraints;
- privacy, authentication, and redaction requirements.

#### Composite scenarios

Write scenarios for high-risk combinations, such as:

> Dose overdue × timezone changed × notification tap × another device has unsynced data.

Do not enumerate the full Cartesian product. Choose combinations using risk, incidents, domain rules, and known concurrency boundaries.

**Done gate.** Every in-scope condition has status `specified` or later, an owner, behavior, and acceptance criteria. Failures and interruptions include recovery. Non-transient lifecycle states have five explicit re-entry verdicts. High-risk combinations have scenario coverage. The map is then ready to feed design, implementation, and test work.

---

## From map to delivery

Advance condition status as evidence accumulates:

- `discovered`: named and sourced;
- `triaged`: risk and scope confirmed;
- `specified`: the step-4 contract is complete;
- `implemented`: implementation is linked;
- `verified`: acceptance criteria are covered by tests, review, or production evidence.

A condition map at `specified` is a handoff artifact, not proof of implementation. Teams should link records to their normal delivery system rather than creating a parallel backlog.

If executable semantics are needed, translate the relevant lifecycle states and transitions into a statechart or equivalent formalism. Add explicit events, guards, actions, hierarchy, parallel regions, invariants, and persistence semantics there. Do not generate runtime code directly from the discovery map.

## `STATEFUL.md`: working memory

`STATEFUL.md` is optional, human-readable working memory. Keep it compact:

```markdown
# Stateful working memory

Last updated: <date>

## System sentence
<confirmed structural sentence>

## Surface(s) in scope
- `<path>`: <description>

## Evidence consulted
- <type>: <reference>

## Condition inventory
Lifecycle: <n> · Failure: <n> · Interruption: <n> · Surface: <n>

## Triage
In: <n> · Out-with-implication: <n> · Out: <n>
High-impact hypotheses: <n>

## Specification
Specified: <n>/<in-scope total> · Re-entry reviewed: <n>/<eligible states>

## Audit
- `<file>:<line>`: <gap>

## Decisions
- state-map.json: yes | no
- known unknowns: <one line>
```

The JSON mirror is optional. When present, it is the machine-readable source for condition records and typed relationships. Run:

```text
python3 scripts/validate_state_map.py state-map.json
```

## Optional implementation dimensions

**Layers.** Mark which layers must change: `frontend`, `backend`, `data-model`, `infrastructure`.

**Cause.** Record the source of each failure: `user-input`, `system`, `external`, or `policy`.

These annotations help route work. They do not replace an accountable owner.

## Practical cadence

- **Greenfield:** run Describe and Map in a cross-functional workshop; triage asynchronously; specify only confirmed in-scope records.
- **Existing feature:** derive expected conditions from domain evidence, then compare with code, tests, designs, incidents, support, and telemetry.
- **During delivery:** add design, implementation, and test links; review status in normal refinement or design critique.
- **After launch:** use incidents, support, and analytics to update likelihood, confidence, and missing conditions.

Measure whether the method helps: time spent, conditions found before build, escaped defects, rework, support volume, and which mapped conditions never became relevant.

## Examples

The two worked examples in [EXAMPLES/](EXAMPLES/) demonstrate the method’s breadth:

- **Password reset:** bounded and transactional, with a rich failure inventory.
- **Medication tracker:** periodic and notification-driven, with dense interruption and surface concerns.

Their JSON maps use `maturity: illustrative`. Their priority scores and evidence references are examples, not production claims. Replace those with live product evidence during a real engagement.

## Skills

Seven agent skills in [skills/](skills/) accelerate the method:

- **New feature:** `system-sentence`, `state-list`, `state-triage`, `reentry-pass`.
- **Existing feature:** `state-audit`, then triage and specification.
- **Cross-cutting:** `state-prompt`, `state-graph`.

The skills accelerate interrogation and artifact maintenance. They do not provide missing evidence, own scope, or verify implementation.
