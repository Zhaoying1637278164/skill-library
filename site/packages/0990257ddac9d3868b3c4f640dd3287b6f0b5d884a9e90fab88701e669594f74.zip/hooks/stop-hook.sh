#!/usr/bin/env bash
#
# claude-code-notify: Stop hook
# Sends a desktop notification when Claude is waiting for input.
# Focus-aware, tmux-aware, with session name and last message.
#

set -euo pipefail

# --- Dependency check ---
if ! command -v jq &>/dev/null; then
  exit 0
fi

# --- Read stdin payload immediately ---
PAYLOAD=$(cat)

# --- Guard: skip if another hook is continuing the conversation ---
STOP_HOOK_ACTIVE=$(echo "$PAYLOAD" | jq -r '.stop_hook_active // false')
if [[ "$STOP_HOOK_ACTIVE" == "true" ]]; then
  exit 0
fi

# --- Debounce: 5-second cooldown ---
DEBOUNCE_FILE="/tmp/claude-notify-${PPID}"
if [[ -f "$DEBOUNCE_FILE" ]]; then
  LAST_NOTIFY=$(stat -c %Y "$DEBOUNCE_FILE" 2>/dev/null || stat -f %m "$DEBOUNCE_FILE" 2>/dev/null || echo 0)
  NOW=$(date +%s)
  if (( NOW - LAST_NOTIFY < 5 )); then
    exit 0
  fi
fi

# --- Detect platform ---
OS="$(uname -s)"

# --- Focus detection: skip notification if user is looking at this session ---
if [[ -n "${TMUX:-}" ]]; then
  # tmux: check pane, window, and terminal focus
  PANE_ACTIVE=$(tmux display-message -t "${TMUX_PANE:-}" -p '#{pane_active}' 2>/dev/null || echo "")
  WINDOW_ACTIVE=$(tmux display-message -t "${TMUX_PANE:-}" -p '#{window_active}' 2>/dev/null || echo "")
  CLIENT_FLAGS=$(tmux display-message -t "${TMUX_PANE:-}" -p '#{client_flags}' 2>/dev/null || echo "")

  FOCUSED=true
  [[ "$PANE_ACTIVE" != "1" ]] && FOCUSED=false
  [[ "$WINDOW_ACTIVE" != "1" ]] && FOCUSED=false
  # client_flags requires tmux 3.3+; skip check if empty (graceful fallback)
  if [[ -n "$CLIENT_FLAGS" ]] && [[ "$CLIENT_FLAGS" != *"focused"* ]]; then
    FOCUSED=false
  fi

  if [[ "$FOCUSED" == "true" ]]; then
    exit 0
  fi
elif [[ "$OS" == "Darwin" ]]; then
  # macOS without tmux: check if terminal is frontmost app
  FRONTMOST=$(osascript -e 'tell application "System Events" to get name of first process whose frontmost is true' 2>/dev/null || echo "")
  case "$FRONTMOST" in
    Terminal|iTerm2|Alacritty|kitty|WezTerm|Ghostty)
      exit 0
      ;;
  esac
fi

# --- Extract last assistant message ---
LAST_MSG=$(echo "$PAYLOAD" | jq -r '.last_assistant_message // empty' 2>/dev/null)
if [[ -n "$LAST_MSG" ]]; then
  BODY="${LAST_MSG:0:80}"
  [[ ${#LAST_MSG} -gt 80 ]] && BODY="${BODY}..."
else
  BODY="Ready for input"
fi

# --- Session name resolution ---
SESSION_NAME=""
TRANSCRIPT_PATH=$(echo "$PAYLOAD" | jq -r '.transcript_path // empty' 2>/dev/null)
if [[ -n "$TRANSCRIPT_PATH" ]] && [[ -f "$TRANSCRIPT_PATH" ]]; then
  SESSION_NAME=$(tac "$TRANSCRIPT_PATH" | grep -m1 '"type":"custom-title"' | jq -r '.customTitle // empty' 2>/dev/null || echo "")
fi

# Fallback to directory name
if [[ -z "$SESSION_NAME" ]]; then
  CWD=$(echo "$PAYLOAD" | jq -r '.cwd // empty' 2>/dev/null)
  CWD="${CWD:-$PWD}"
  SESSION_NAME="${CWD##*/}"
  # Handle worktree paths
  if [[ "$CWD" == *".worktrees"* ]]; then
    SESSION_NAME=$(echo "$CWD" | sed 's|.*\.worktrees/\([^/]*\)/.*|\1|')
  fi
fi

# --- Build title ---
TITLE=""

# tmux window index
if [[ -n "${TMUX:-}" ]]; then
  WIN_IDX=$(tmux display-message -t "${TMUX_PANE:-}" -p '#{window_index}' 2>/dev/null || echo "")
  if [[ -n "$WIN_IDX" ]]; then
    TITLE="(w:${WIN_IDX}) "
  fi
fi

# Optional work/personal context
if [[ "${CLAUDE_NOTIFY_CONTEXT:-false}" == "true" ]]; then
  CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
  CREDENTIALS="$CONFIG_DIR/.credentials.json"
  if [[ -f "$CREDENTIALS" ]] && jq -e '.claudeAiOauth' "$CREDENTIALS" &>/dev/null; then
    TITLE="${TITLE}[Personal] "
  else
    TITLE="${TITLE}[Work] "
  fi
fi

TITLE="${TITLE}${SESSION_NAME}"

# --- Send notification ---
URGENCY="${CLAUDE_NOTIFY_URGENCY:-normal}"

touch "$DEBOUNCE_FILE"

if [[ "$OS" == "Darwin" ]]; then
  timeout 2 osascript \
    -e 'on run argv' \
    -e 'display notification (item 2 of argv) with title (item 1 of argv)' \
    -e 'end run' -- "$TITLE" "$BODY" 2>/dev/null || true
else
  timeout 2 notify-send \
    --app-name="Claude Code" \
    --category="im.received" \
    --urgency="$URGENCY" \
    --icon="dialog-information" \
    "$TITLE" \
    "$BODY" 2>/dev/null || true
fi

exit 0
