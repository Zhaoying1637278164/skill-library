---
name: notify-test
description: Send a test notification to verify your setup
---

Run the test notification script to verify the user's notification setup works:

```bash
bash ${CLAUDE_PLUGIN_ROOT}/scripts/test-notification.sh
```

After running, ask the user if they saw the notification. If not, troubleshoot:
- **Linux**: Check if `notify-send` is installed (`sudo dnf install libnotify` or `sudo apt install libnotify-bin`)
- **macOS**: `osascript` is built-in, check System Settings > Notifications
- **GNOME**: Check if Do Not Disturb is enabled
- **KDE**: Check notification settings for unknown apps
