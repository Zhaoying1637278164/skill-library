---
name: notify-help
description: Show claude-code-notify configuration and status
---

Show the user the following information about the claude-code-notify plugin:

## Configuration

Environment variables (set in your shell profile):

| Variable | Default | Description |
|---|---|---|
| `CLAUDE_NOTIFY_CONTEXT` | `false` | Show `[Work]`/`[Personal]` prefix in title |
| `CLAUDE_NOTIFY_URGENCY` | `normal` | Notification urgency: `low`, `normal`, `critical` |

## Current Status

Check and report:
1. **Platform**: Run `uname -s` to detect OS
2. **Notification tool**: Check if `notify-send` (Linux) or `osascript` (macOS) is available
3. **tmux**: Check if `$TMUX` is set — if yes, focus detection is active
4. **jq**: Check if `jq` is installed — required for the plugin to work
5. **Config values**: Echo current `CLAUDE_NOTIFY_CONTEXT` and `CLAUDE_NOTIFY_URGENCY`

## How It Works

- Sends a desktop notification when Claude finishes responding
- Shows the session name (from `/rename`) and last message in the notification
- Suppresses notifications when you're looking at the session (tmux focus detection)
- 5-second debounce prevents notification spam

## Test

Run `/notify-test` to send a test notification and verify your setup.
