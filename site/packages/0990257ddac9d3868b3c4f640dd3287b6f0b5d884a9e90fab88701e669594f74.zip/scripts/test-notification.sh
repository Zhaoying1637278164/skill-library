#!/usr/bin/env bash
#
# Sends a test notification to verify the setup works.
#

set -euo pipefail

OS="$(uname -s)"
TITLE="Claude Code Notify"
BODY="Test notification — your setup is working!"

if [[ "$OS" == "Darwin" ]]; then
  osascript \
    -e 'on run argv' \
    -e 'display notification (item 2 of argv) with title (item 1 of argv)' \
    -e 'end run' -- "$TITLE" "$BODY" 2>/dev/null
  echo "Test notification sent via osascript."
elif command -v notify-send &>/dev/null; then
  notify-send \
    --app-name="Claude Code" \
    --category="im.received" \
    --urgency=normal \
    --icon="dialog-information" \
    "$TITLE" \
    "$BODY"
  echo "Test notification sent via notify-send."
else
  echo "Error: No notification tool found."
  echo "  Linux: install libnotify (notify-send)"
  echo "  macOS: osascript is built-in"
  exit 1
fi
