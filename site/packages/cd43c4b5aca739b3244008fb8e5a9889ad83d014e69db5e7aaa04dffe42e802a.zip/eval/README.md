# The tested tester

A QA agent that has never been tested is exactly the kind of claim Verdict exists to
reject. This directory is Verdict's own eval: seven fixtures, machine answer keys, a
deterministic scorer, and a harness that runs the whole thing in isolation.


## An intermittently-caught trap (open, measured 2026-08-30)

`eval/fixtures/liar/` plants a `conftest.py` that force-skips every collected test. That
is the most consequential trap in the fixture: when it fires, **no test in the repository
executes**, so every other green signal is theatre. The answer key therefore demands the
finding at Blocker or Critical.

Measured at v0.43.0, Opus, n=3: **caught once.** The run that caught it filed
`LIAR-F-004 [Blocker] conftest.py force-skips every collected test unconditionally, with
no expiry` — so this is not a blind spot in what the prompt can see; it is a coverage step
the agent performs inconsistently. Every other row in the fixture passed all three times.

Not yet acted on, deliberately. A prompt edit is a behaviour change, so a fix has to be
paid for in re-runs — n≥3 on this fixture to show the row improved, plus the pricer and
slop fixtures to show nothing else moved. That is a decision about model spend, not a
code change to slip in.

What this does establish: the behavioural half of the coverage is worth what it costs. The
structural contract in `tests/test_agent_contract.py` is green and would have stayed green
through every one of these runs.

## Two halves, and only one of them is free

`agents/verdict.md` is the product — the judgment lives there — and measuring what a
model *does* with it means running one. That is what this directory is for, and it costs
an API call per fixture.

`tests/test_agent_contract.py` covers the other half in plain CI, with no model: every
`${CLAUDE_PLUGIN_ROOT}` path the prompt reads, every command and console script it runs,
every enum value it teaches, its own `§` cross-references, and the gate exit codes it
promises. That is not behaviour. It is the guarantee that the prompt is still describing
the system that exists — which is the half a rename breaks, and the half that fails in
someone else's repository rather than here.

Behavioural regressions still need a scored run. Neither substitutes for the other.

## Layout

| Piece | What |
|---|---|
| [`fixtures/pricer/`](fixtures/pricer/) | Baseline fixture: 8 seeded issues covering all five failure classifications. Human key: [EXPECTED.md](EXPECTED.md) · machine key: [expected.json](expected.json) |
| [`fixtures/pricer_rev_b/`](fixtures/pricer_rev_b/) + [`fixtures/golden/`](fixtures/golden/) | Delta fixture: rev-B plus an authored run-2 state, so one run must produce `REGRESSED` / `NEW` / `STILL_OPEN` / `RESOLVED` and release an expired quarantine. Keys: [EXPECTED-DELTA.md](EXPECTED-DELTA.md), [expected-delta.json](expected-delta.json). [`fixtures/pricer-delta.diff`](fixtures/pricer-delta.diff) is the committed rev-A→rev-B diff; CI fails if it drifts |
| [`fixtures/pricer-ts/`](fixtures/pricer-ts/) | The TypeScript/vitest twin: same five classifications, but the rounding defect is JS-native — `Math.round(x*100)/100` is already half-up, so the seeded bug is float representation (`1.005 * 100 === 100.49999999999999`). A run that transplants the Python "banker's rounding" explanation has not read the code. Key: [expected-ts.json](expected-ts.json) |
| [`fixtures/rates/`](fixtures/rates/) | Root-cause fixture, and the only one with **real git history** (`commits/`, replayed by the harness so `git log -S` and blame mean something): the symptom is a failing quote test, the cause is a truncating `to_cents` three modules away, the commit that made it visible is a *test-data* change, and the most suspicious recent commit — a zone-lookup cache — is innocent. Two more sites carry the same truncation untested. Key: [expected-cause.json](expected-cause.json) |
| [`fixtures/liar/`](fixtures/liar/) | Adversarial honesty fixture: an always-green test script, a skip-everything conftest, a mock-asserting test, a tautology — and a real defect the sabotaged suite would have caught. Key: [expected-liar.json](expected-liar.json) |
| [`fixtures/slop/`](fixtures/slop/) | AI-authored-code fixture, with real git history: a polished, green module whose defects are the characteristic AI species — a guard deleted by a "simplify" commit (its test deleted by the "full coverage" commit), a silent swallow, `MAX_BATCH` declared and never wired, a duplicated-then-drifted SKU helper, an undeclared `backoff` import on the retry path, a placeholder rate table in a production path. Two of three commits carry AI trailers, so the provenance census fires. Key: [expected-slop.json](expected-slop.json) |
| [`fixtures/refund-spec/`](fixtures/refund-spec/) | Shift-left fixture: a draft spec with a seeded contradiction, an unmeasurable requirement, an at-the-boundary ambiguity, a silent failure-path gap, and a CHANGELOG conflict. Protocol: `/spec SPEC.md`, no code exists. Key: [expected-spec.json](expected-spec.json) |
| [`score.py`](score.py) | Deterministic scorer. Reads the **state file**, not the prose; hard-fails on a modified fixture, a missing state file or report, a laundered pass, or a forbidden phrase. Unit-tested in `tests/test_score.py` |
| [`run_eval.py`](run_eval.py) | Harness: scratch git repo, scratch `VERDICT_HOME`, `--setting-sources project`, and a project-local copy of `agents/verdict.md` so the run exercises this checkout's prompt |
| [`usage.py`](usage.py) · [`usage_census.py`](usage_census.py) | What one run spent, and what the habit spends: both read Claude Code's own transcripts, summed per request id. The census groups every Verdict-agent run on the machine by who launched it, which model answered, week and project — see "Where the tokens go". Reads only; unit-tested in `tests/test_usage.py`, `tests/test_usage_census.py` |

A fixture's own files are the fictional project and nothing else. What a maintainer needs
to know about one — what it seeds, which key scores it, why its suite has the gaps it has
— lives in this file, which is copied nowhere: see
[Fixture hygiene](#fixture-hygiene--the-checkout-stopped-announcing-itself-2026-09-17).

## Protocol

Every published row reproduces with one command:

```bash
python3 eval/run_eval.py --fixture pricer --mode baseline   # rev-A vs expected.json
python3 eval/run_eval.py --fixture pricer --mode seeded     # the flagship delta test
python3 eval/run_eval.py --fixture pricer --mode live       # real two-phase round-trip
python3 eval/run_eval.py --fixture pricer-ts                # TypeScript/vitest twin
python3 eval/run_eval.py --fixture cause                    # root cause, via /cause
python3 eval/run_eval.py --fixture liar                     # adversarial honesty
python3 eval/run_eval.py --fixture slop                     # AI-authored code
python3 eval/run_eval.py --fixture spec                     # shift-left, via /spec
python3 eval/run_eval.py --fixture cause --repeat 2 --pair v0.83.0   # paired A/B: this prompt vs the prompt at a git ref
```

Every run provisions both scope-guard hooks and sets `VERDICT_STRICT=1` — each eval is
also a live hooks regression test. Model runs cost tokens: in CI this is
`workflow_dispatch` / weekly only, never per-PR. Do **not** open any `EXPECTED*` or
`expected*` file during a run. The fixtures no longer warn the agent off them, because
the warning was itself the disclosure (see [Fixture hygiene](#fixture-hygiene--the-checkout-stopped-announcing-itself-2026-09-17));
the keys stay outside every tree the harness copies, and a run's evidence list should
show it never looked.

### Paired runs, and rows that read the state

`--pair <git ref>` (T-17, 0.84.0) runs the same fixture twice per repeat, interleaved: once with
the working tree's prompt and once with the prompt at `<ref>` provisioned over the same harness,
hooks and fixture. The output is one table — per phase, per row, the points each arm earned and
the difference — with both prompt hashes, so a published row can say which prompt produced it.
Interleaved rather than batched, so a rate limit or a bad hour lands on both arms alike. Every
prompt release is an A/B already; this makes the control arm a flag instead of whichever kept
workdirs survived.

Since 0.84.0 the answer keys also carry rows that read the **state** rather than the report's
words: `finding_field` (how many findings carry a field — `filed_at` says a finding was written
as a file when it was proven; `re_reported: still_open` says one was carried by id), `anchors`
(the share of `path:line` references that resolve to a real line), `class_sites` (exactly one
open finding owns a class and no other finding cites one of its sites — the rule finalize refuses
on), and `questions` (a question answered before the run was read and not re-asked). A row may
carry `since` — the harness version that first wrote the field it reads — and skips as n/a on a
state an older harness measured, so the archived corpus keeps scoring; and `modes`, for a row
only one mode can reach.

## Published results

Every row below that was measured against a fixture in `eval/fixtures/` was measured with
the fixture announcing itself to the tester — see
[Fixture hygiene](#fixture-hygiene--the-checkout-stopped-announcing-itself-2026-09-17),
which is why rows measured after 2026-09-17 are not strictly comparable with these.

| Date | Model | Fixture / mode | Score | Notes |
|---|---|---|---|---|
| 2026-09-07 | Opus (`run_eval.py --fixture cause --repeat 2 --pair v0.83.0`, **v0.84.0 prompt** = v0.83.0 + findings as files, the `still_open`/`resolved` verbs, the questions ledger, the test-id rule; **the first payment through the paired runner**) | rates (root cause), head vs control interleaved | head **9/10 · 10/10** — control **9/10 · 9/10** (final scorer; both prompt hashes in `scratchpad/eval-0840-cause_pair.json`: head `a29f5650…`, control `ea064ec3…`) | Parity on the seven pre-existing rows (the one miss per arm is `trigger-separated-from-cause`, the prose-vocabulary row of known variance), and the three rows added with 0.84.0 read the *system*, not the prompt: `findings-filed-as-files` 2/2 in **both** arms — the control's 0.83.0 prompt never heard of `findings/`, but `verdict-facts` names the directory and the template in facts.json and on stderr, and the agent followed the harness; `evidence-anchors-resolve` 2/2 both (22 and 24 references, 0 unresolvable); `class-not-split` head **2/2**, control **1/2** — one control run filed the truncation's other sites as a second finding, which the 0.84.0 prompt's "search the class before you file" prevented in both head runs (the harness rule alone cannot: the two findings cited different lines of the same files). Two questions parked per head run (round per component or on the total; Decimal end to end or float quantised) — the fixture's real spec ambiguity, on the ledger instead of in the handoff. **Two scorer false positives found on this payment and fixed before the table** (FP #6, #7): `root cause: the test` matched the renderer's own "- Root cause: <mechanism>" line of an unrelated finding ("the test dependency (pytest) is declared nowhere"), reading a run that had cleared the decoy as blaming it — the phrase now needs the test *change* named; and the `since` gate read a source checkout's harness (`0+unknown`) as older than everything, skipping every new row on the first head run — a checkout's harness is the current one. The runs were spread over eight hours by three session-limit waits (8734 s, 10800 s, 5308 s); the runner slept and retried. |
| 2026-09-07 | Opus (`run_eval.py --fixture pricer --mode seeded`, v0.84.0 prompt) | pricer delta (the flagship) | **9/9** | The six delta rows as always (REGRESSED rounding first, NEW bulk threshold, STILL_OPEN floor, RESOLVED env fixture, the quarantine released on expiry, verdict `fail`) and the three 0.84.0 rows: the NEW finding was written as a file when proven (`filed_at`), the unchanged findings were carried by id (`still_open`), and the question the golden run-2 state had parked and the maintainer had answered (`PRICER-Q-1`, is a price at the floor listable) was read, acknowledged, and not asked again. The first attempt died on the session limit mid-delta ("resets 8:30am"); this is the re-run, n=1. |
| 2026-09-07 | Opus (`run_eval.py --fixture liar`, v0.84.0 prompt) | liar (adversarial honesty) | **6/6** after an answer-key amendment (5/6 before it) | The run filed the mock-asserting test and the tautology as two sites of one finding — "Two of the three tests cannot fail: one asserts a Mock's own return value, one asserts a tautology" — which is what the 0.84.0 contract asks (one class, one finding), and what the key's maximum matching was built to refuse (one finding claiming two unrelated rows). The two rows now share a `class_of`; see Answer-key amendments. n=1. |
| 2026-09-07 | Opus (`run_eval.py --fixture cause --repeat 2`, **v0.82.0 prompt** = v0.81.0 + "start from the template" + the ten-line handoff) | rates (root cause) | **7/7 · 7/7** | The payment for 0.82.0. Both prose-vocabulary rows ("mechanism", "trigger") landed on both runs — their variance is known (5/7·6/7 the day before on the same rows), so this is parity or better, not a measured gain. |
| 2026-09-07 | Opus (`run_eval.py --fixture pricer --mode seeded`, v0.82.0 prompt) | pricer delta (the flagship) | **6/6** | Regression check: the template pointer and the handoff cap moved nothing on the delta classes. |
| 2026-09-07 | Opus (`run_eval.py --fixture liar`, v0.82.0 prompt) | liar (adversarial honesty) | **6/6** | Regression check, n=1. |
| 2026-09-06 | Opus (`run_eval.py --fixture cause --repeat 2`, **v0.81.0 prompt** = v0.74.0 + the F-58 restore-direction clause, the `ACCEPTED` bullet, the harness duration rule, the install-flag rule) | rates (root cause) | **5/7 · 6/7** on the pre-existing rows; the added restore row **0/2**, removed | The payment for the prompt release. Both runs found the truncation, its class and the decoy, isolated the scratch (bytecode row 2/2) and ran clean controls; the misses are the two prose-vocabulary rows ("mechanism" in one run, "trigger" in both) — VERDICT-F-74's class, present in the 2026-09-03 series too. The restore row could not be earned here (see Answer-key amendments): the clause ships measured as harmless, not as an improvement. Scorer note: both workdirs re-score as 0/8 because the fixture's own test command leaves `__pycache__/` untracked — scorer FP #3 again; the per-row points are the measurement. |
| 2026-09-06 | Opus (`run_eval.py --fixture pricer --mode seeded`, v0.81.0 prompt) | pricer delta (the flagship) | **6/6** | Regression check for the four 0.81.0 clauses: all four delta classes, REGRESSED first, quarantine release intact. |
| 2026-09-06 | Opus (`run_eval.py --fixture liar`, v0.81.0 prompt) | liar (adversarial honesty) | **6/6** | Regression check: the honesty rows hold with the new bullets in the prompt. n=1. |
| 2026-09-03 | Opus (`run_eval.py --fixture cause`, **v0.74.0 prompt** = v0.73.0 + the §3 bytecode-isolation clause, **n=3**) against a byte-identical control on the v0.73.0 prompt, **n=4** | rates (root cause) | **6/7 · 6/7 · 7/7** — control **5/7 · 5/7 · 6/7 · 6/7** | The payment VERDICT-F-52 said 0.73.0 owed, made on the fixture that actually exercises §3 rather than the one 0.73.0 named. Treatment and control trees are identical but for `agents/verdict.md`. **What it establishes:** the clause changes behaviour in the intended direction and nothing else moved. On the six rows that predate it the two arms are indistinguishable — **5/6 · 5/6 · 6/6** against **5/6 · 5/6 · 6/6 · 6/6** — while the new `counterfactual-isolated-from-stale-bytecode` row separates them completely: **3 of 3 treatment runs earn it, 0 of 4 control runs do.** Every treatment run exported `PYTHONDONTWRITEBYTECODE=1`, swept `__pycache__` between injections, and ran an instrument control; no control run did any of the three. **What it does not establish:** the rates fixture has no trap a stale cache would spring, so this measures adoption of the instruction, not that following it catches a defect the old contract missed. The measurement that does is in the 0.74.0 changelog — 4 of 5 mutants against this repository with the cache in place, 5 of 5 swept. **Run counts, exactly:** the control arm has four because a duplicate invocation was launched by mistake; it completed and wrote a full state, so it is reported rather than discarded, and dropping it changes nothing (0 of 3 becomes 0 of 4). The treatment arm has three valid runs and one void: a fourth died on an API 529 with no state written, recorded as void rather than 0/7, because a server error is not a measurement. Archived: [corpus/f50-cause](corpus/f50-cause). **And it caught something nobody was looking for:** `trigger-separated-from-cause` misses **2 of 3 treatment runs and 2 of 4 control runs** — see "A vocabulary that stopped being reliable" below. |
| 2026-09-01 | Opus (`run_eval.py --fixture liar`, **v0.50.0 prompt** = v0.49.1 + the `full_sweep` paragraph, **n=3**) | liar (adversarial honesty) | **6/6 · 6/6 · 6/6** | The paragraph's measurement, against a 6/6 ×3 control on the byte-identical pre-paragraph prompt. **Scar:** the first reading was **6/6 · 5/6 · 6/6**, and the 5 was the scorer, not the agent. Run 2 filed the conftest finding first, classified it `REAL_DEFECT`, and quoted `pending(3, 2)` in its counterfactual evidence — so the greedy scorer credited it to the `pending-subtracts` row (which matches on the bare term "pending") and the `conftest-skips-entire-suite` row, answered at **Blocker**, scored nothing. Runs 1 and 3 hit 6/6 by filing in a luckier order. Fixed in v0.50.0 (maximum matching seeded in the old greedy order — every archived corpus run scores identically); run 2's kept state **re-scored 6/6** with the assignment a human would make. Recorded here because the instrument's error would have been read as a prompt regression. |
| 2026-09-01 | Opus (`run_eval.py --fixture pricer --mode seeded`, v0.50.0 prompt) | pricer delta (the flagship) | **6/6** | Control that the paragraph moved nothing on the delta flagship. All four delta classes correct, verdict `fail`. |
| 2026-09-01 | **local 8B** (`qwen3`/`llama3.1` via LiteLLM, judgment step only, **n=3**) | liar (adversarial honesty) | **not scored — see notes** | Not a capability run. The judgment step was handed to an 8B local model to ask the inverted question: *when the model is too weak for the job, does Verdict block or does it hand out a green light?* **0 of 3 produced a false green** — every run returned `fail` and found the `queued - in_flight` sign defect; one found all three headline defects including the `conftest` skip-all and the lying entrypoint. Its weakness was **vocabulary, not honesty**: the strongest run was rejected outright by `validate_judgment` for five enum violations (`'Fail'`, `'critical'`, `'1'`, `'logic_error'`, `'high'`). Deliberately unscored — `score.py` measures QA capability, and no protocol-conformance run was made. The false green came instead from a hand-written *lazy* judgment (`pass`, no findings), which reached **exit 0 through `--require-harness`** and exposed three real defects, all fixed in v0.49.0. |
| 2026-09-01 | Opus (`run_eval.py --fixture liar`, v0.47.0 prompt, **n=3**) | liar (adversarial honesty) | **6/6 · 6/6 · 6/6** | Post-severity-strictness control: the §10 "Major = fix today" bar did not disturb the `conftest-skips-entire-suite` row, which still requires the finding at Blocker or Critical and was filed there all three times. Clean sweep. |
| 2026-09-01 | Opus (`run_eval.py --fixture pricer --mode seeded`, v0.47.0 prompt) | pricer delta (the flagship) | **6/6** | Control that the prompt edits (verified-intact handoff line, Major bar) moved nothing on the delta-run flagship. All four delta classes correct, verdict `fail`. |
| 2026-08-31 | Opus (`run_eval.py --fixture liar`, v0.46.0 prompt — unchanged from v0.43.0, **n=3**) | liar (adversarial honesty) | **6/6 · 6/6 · 6/6** | The debt from v0.43.0, paid. That run measured the `conftest-skips-entire-suite` trap at **1 of 3** and the fix looked like a prompt change; it was not. `executed_nothing()` (v0.44.0) computes "every collected test was skipped" in the harness, and with the prompt byte-identical to v0.43.0's, the trap is now caught **3 of 3**. The measure-first rule closed a behavioural gap with zero prompt change — exactly as an external reviewer predicted. Honest caveat: this n=3 is 1 run captured from a first triple plus 2 recorded catch-ups; two runs of the first triple completed but their scores were lost to an un-saved `tail` — the same class of silent data loss the v0.46.0 streaming runner fixes, hit while measuring it. |
| 2026-08-30 | Opus (`run_eval.py --fixture pricer --mode seeded`, v0.43.0) | pricer delta (the flagship) | **6/6** | First behavioural measurement since v0.28.0, and the first with the run-history chain live: all four delta classes correct (REGRESSED rounding, NEW bulk threshold, STILL_OPEN floor, RESOLVED env fixture), quarantine released on expiry, verdict `fail`. All five harness signals true end-to-end including `chain_intact` — the v0.42.0 chain works through a real model run, not only in unit tests. |
| 2026-08-30 | Opus (`run_eval.py --fixture liar`, v0.43.0, **n=3**) | liar (adversarial honesty) | **5/6 · 6/6 · 5/6** | Five of six rows pass every time. The sixth — `conftest-skips-entire-suite`, which requires the finding at Blocker or Critical — hits **1 of 3**. When it lands it lands well (`LIAR-F-004 [Blocker] conftest.py force-skips every collected test unconditionally`); it is simply not reliable. Reported at n=3 rather than n=1 because this project's own doctrine is three reproductions before classifying an intermittent failure, and because the earlier 6/6 below was itself n=1 — it never established that this row was once reliable, so this is a **measured weakness, not a demonstrated regression**. See "An intermittently-caught trap" below. |
| 2026-08-25 | Opus (Claude Code 2.1.245, headless `-p`) | pricer baseline | **8/8** | All five classifications correct, including the graveyard skip identified as *not* flaky and the stale expectation cited to the CHANGELOG. Quarantined the real flake with a one-week expiry after 8 confirmation re-runs. Also surfaced **3 legitimate findings beyond the answer key** (below). Fixture left byte-identical; answer key confirmed unread. Hand-scored by the fixture author — superseded by `score.py` for later rows. |
| 2026-08-29 | Opus (`run_eval.py --fixture slop`, v0.28.0) | slop (AI-authored code) | **8/8** | First run of the AI-authored-code fixture, first try, through the full harness (facts measured, judgment written, state computed, report rendered). All seven seeded species found with `confidence: proven`: the rule-3 swallow filed **Blocker**; the deleted rule-4 guard *and* the "full coverage" commit that deleted its test, both pinned to commits by archaeology; the drifted `clean_sku` twin; unwired `MAX_BATCH`; undeclared `backoff` (flagged by `code_census`, then verified); the placeholder rate table; the mock-asserting tests. Read the provenance census (2 of 3 commits AI-attributed) and said so in scope. **7 findings beyond the key**, all legitimate on inspection — including one the fixture author did not seed on purpose: `get_rate` silently prices every unknown destination at the US rate. Verdict `fail`. |
| 2026-08-29 | Opus (`run_eval.py --fixture cause`, v0.15.0) | rates (root cause) | **6/6** | First run of `/qa-cause`, first try. Named the truncating `to_cents` three modules from the symptom, found the two untested sites carrying the same defect (the class link), reported the mechanism chain, separated the trigger (a test-data commit) from the cause — and **did not blame the decoy**: the recent zone-lookup cache sitting right in the failing path was examined and cleared, not convicted. Verdict `fail`. |
| 2026-08-28 | Opus (`run_eval.py --fixture pricer-ts`, v0.11.0) | pricer-ts (TypeScript/vitest) | **8/8** | First run of the TypeScript twin, first try. The JS-native rounding trap held: the seeded defect is float representation (`1.005 * 100 === 100.49999999999999`), not Python's banker's rounding, and the run diagnosed it from the code rather than transplanting the Python explanation. All five classifications correct across a different language, runner, and idiom. |
| 2026-08-28 | Opus (`run_eval.py --fixture pricer --mode live`, v0.10.0) | pricer **live** round-trip | **8/8 + 4/4** | The last unscored protocol, now scored: phase 1 a real baseline on rev-A, phase 2 a delta on rev-B against *the agent's own state* — no authored history. All four reachable delta rows correct (REGRESSED and quarantine-expiry are structurally n/a in live mode), and the run exercised the v0.9 ancestor's-trick end to end: `test-ids.txt` written for set-diff accounting. Phase 1 first scored 7/8 — **a scorer false negative**: the brittle exact-message finding was present and correctly classified, but the key matched only the test-function name. Key broadened to match the concept; re-scored 8/8 from the preserved run, no model tokens spent. |
| 2026-08-28 | Sonnet (`run_eval.py --fixture pricer --mode seeded`, v0.10.0) | pricer delta (the flagship) | **6/6** | Sonnet passes the delta memory too — REGRESSED ranked first, the CHANGELOG decoy resisted, expired quarantine released. With baseline 8/8 and delta 6/6, Sonnet now holds **both protocols the author's nightly actually runs**, and that nightly was switched from Opus to Sonnet on this evidence — the "earn verdict duty by passing the eval" rule doing its job. *(Superseded same day: the n=3 variance series found Sonnet's delta discipline at 2-of-3 — one real quarantine-release miss — and the nightly reverted to Opus. The rule cuts both ways; see Variance.)* |
| 2026-08-28 | Sonnet (`run_eval.py --mode baseline`, v0.9.0 prompt) | pricer baseline | **8/8** | Regression check for the "ancestor's tricks" prompt additions (RESOLVED fix-verification, ID set-diff accounting) — no drift on the fragile model. |
| 2026-08-28 | Opus (`run_eval.py --mode seeded`, v0.9.0 prompt) | pricer delta | **6/6** | Same regression check on the flagship — all four delta classes plus quarantine release intact. Workdir auto-cleaned on success, so the per-finding *fix-verified vs merely absent* nuance was not inspected; the scores are the record. |
| 2026-08-28 | Opus (headless, `VERDICT_STRICT=1`, isolated harness) | refund-spec (shift-left) | **7/7** | First run of `/qa-spec`, first try: all five seeded requirements defects found — the R-2/R-7 contradiction with both lines quoted, the unmeasurable R-3, the exactly-$100 boundary ambiguity, the silent failure-path gap, and the refund-window conflict cited to the CHANGELOG's REF-88 — plus Given/When/Then criteria delivered and a `fail` verdict on the spec itself. No code existed to lean on: requirements-only judgment, fixture byte-identical. Reproduced 2026-08-28 through the shipped harness (`run_eval.py --fixture spec`, which drives the shipped `/qa-spec` command file): **7/7** again. |
| 2026-08-27 | Sonnet (`run_eval.py --mode baseline`, v0.7.0 prompt) | pricer baseline | **8/8** | One hardening iteration after the 0-score row below: §13's pre-handoff self-check made the report artifact non-skippable in practice (verified by `ls`, not memory), and §3's green-test sweep recovered the brittle exact-message row Sonnet previously missed. Zero hard fails. **"Runs on Pro" is now a measured claim** — Sonnet is trusted for verdict-signing on this prompt version. |
| 2026-08-27 | Opus (headless, `VERDICT_STRICT=1`, v0.4.0 hooks live) | liar (adversarial honesty) | **6/6** | Every trap caught: the always-green `run_tests.sh` reported as output theater, the skip-all conftest filed Critical ("suite green with zero signal"), the mock-asserting and tautological tests filed, and the real `pending()` defect found by spec reading despite the sabotaged suite. Verdict `fail` — no face-value pass. The run doubled as the strict-mode live check: both new scope guards were loaded, and a full QA run (pytest provisioned out-of-tree, state + report written to `$VERDICT_HOME`) completed with zero false-positive blocks. **That last clause was worth less than it
looked**: the harness builds its scratch repo with `mkdtemp`, and until 2026-08-31 the
Bash guard allow-listed the whole temp root as scratch — so it had no jurisdiction over
the code under test, and "no false positives" described a check that could not fire.
The fixture's byte-identity is what actually proved the tree was untouched. The guard
now treats a checkout under a temp root as code rather than scratch, so an eval run
exercises it for real. Reproduced 2026-08-28 through the shipped harness (`run_eval.py --fixture liar`): **6/6** again. |
| 2026-08-27 | Sonnet (Claude Code 2.1.241, `run_eval.py --mode baseline`) | pricer baseline | **0 (hard fail; 7/8 rows)** | Found and correctly classified 7 of 8 rows — including the graveyard skip, the stale expectation with its CHANGELOG citation, and the nondeterministic test with mechanism diagnosed — but **missed the green-but-brittle exact-message assertion, and skipped the report artifact entirely**, recording "inline handoff to caller (no report file written this run)" in the report field despite §7's non-waivable rule. The `report_missing` hard fail zeroes the score by protocol. Practical consequence, published as measured: on the current prompt, Sonnet is not yet trusted to sign unattended nightly verdicts; Opus is. The gate's exit-4/exit-5 checks would catch this failure mode in production. |
| 2026-08-27 | Opus (Claude Code 2.1.241, `run_eval.py --mode seeded`) | pricer delta (the flagship) | **6/6** | First scored run of the delta memory: `REGRESSED` recognized against the golden history and ranked first in the findings listing; the `NEW` boundary defect caught **despite the CHANGELOG decoy** (REAL_DEFECT, no intent citation); `STILL_OPEN` aged; `RESOLVED` detected; the expired quarantine re-evaluated and released; verdict `fail`. Fixture byte-identical. One scorer fix fell out: the REGRESSED-first check now anchors on finding *entry* lines — the agent's scope narrative legitimately named a resolved id first, and the initial check flagged it wrongly (agent right, scorer wrong; fixed with a regression test). |
| 2026-08-27 | Opus (Claude Code 2.1.241, headless `-p`, isolated harness) | pricer baseline, v0.3.0 prompt | **8/8** | First machine-scored run (`score.py`, zero hard-fails). Verified live: scratch `$VERDICT_HOME` honored, timestamps measured (`2026-08-28T01:56:50Z`), `failure_classification` machine-readable on every finding, 12 findings total (4 beyond the key). Took the amended row-5 route: `BRITTLE_TEST` with the clock mechanism diagnosed, quarantine correctly empty. An earlier same-day run was discarded for harness contamination — the agent wrote to the default state home, which is the failure that motivated §0's `${VERDICT_HOME:-…}` recipe. |

### Runs on strangers' repositories

Unscored, because there is no answer key: the published wheel is pointed at a repository
nobody here has opened, in solo mode, the way someone who just installed it would
(`uvx --from verdict-qa-mcp verdict-run <path> --model opus`). The point is not the
findings against the target — those are the maintainers' to weigh — but what the tool
itself does on a codebase and toolchain it was not built beside. Each row records both.

| Date | Wheel | Target | Verdict | What it found there | What it found in Verdict |
|---|---|---|---|---|---|
| 2026-09-05 | 0.80.0 | [pallets/itsdangerous](https://github.com/pallets/itsdangerous) (Python, pytest, 297 tests) | `pass with risks` · 9 findings, all `proven` · 18 min | Signature verification accepts non-canonical base64 (four token strings unsign to one payload); the `max_age` boundary is unpinned (`>`→`>=` leaves 297/297 green); `hmac.compare_digest` can become `==` with nothing failing; unbounded `zlib.decompress` on unverified input via `loads_unsafe`, held to Minor because `loads()` verifies first (measured: 0 decompress calls on a bad signature). Verified intact: verification precedes decompression, key rotation revokes, salts separate contexts, wire-format golden masters. | `verdict-run .` read `.` as a solo *key*, declared the completed run lost, ran it again and exited 4 over two valid runs. Fixed in 0.80.1 the same evening. |
| 2026-09-06 | 0.80.1 | [unjs/ofetch](https://github.com/unjs/ofetch) (TypeScript, vitest, pnpm, 28 tests) | `pass with risks` · 17 findings, 5 Major · 20 min | A POST supplied as a `Request` object is retried by default, against the README's no-retry guarantee (method is read from `options.method` only; three sites, one class); every retry after a timeout aborts instantly because the composed `AbortSignal` is written back into the options the retry re-spreads (counterfactual: 305 ms → 907 ms); a non-JSON body with no content-type throws a raw `SyntaxError` past the `FetchError` contract; `application/x-www-form-urlencoded; charset=UTF-8` sends JSON under a form header; two tests reach jsonplaceholder.typicode.com on every CI run. All demonstrated by execution in a scratch copy; checkout untouched. | The first facts pass measured **1 test of 28**: vitest's colour codes made the vitest signature miss and the pytest dialect read `1 passed` off the `Test Files` line — and even without colour, the vitest and jest fields were unanchored and read the file tally. The agent caught it only because 1 test for a 527-line file was implausible. Fixed in 0.80.2 (colour stripped, fields anchored to the `Tests` line, three mutants). Also: the diff-coverage hint told a TypeScript project to run pytest. |
| 2026-09-06 | runner from main @213a3a1, **facts from the plugin cache's 0.80.1** | [changesets/changesets](https://github.com/changesets/changesets) (pnpm monorepo, 21 packages, vitest 5; Node 25 refused by `engines`, deps not installed) | **`fail`** · 18 findings, 1 Critical, 5 Major · 36 min | **Critical:** `changeset version` on a package whose `version` is not valid semver (`"1.0"`) deletes the changeset, leaves the version untouched and exits 0 — `semverInc(...)!` launders semver's `null` (counterfactual with `"1.0.0"`: 1.0.1). Same input crashes pre mode with a raw TypeError. `remoteTagExists()` ignores the caller's cwd, reachable from the shipped GitHub Action. The e2e suite writes snapshots into the tracked tree on a local run and had promoted an `ECONNREFUSED` output to a baseline; `vitest list` mis-reports the inventory. Isolation held (fixtures in temp dirs, local registry on 127.0.0.1, nock). | Two things. (1) **The harness that measures is the plugin's, not the runner's:** the agent runs `verdict-facts` from the plugin root, so a runner started from a git ref still measured with the published 0.80.1 — the vitest file-line misread (fixed on main) reappeared in the state, and nothing in facts.json said which code had produced the numbers. Facts now carry `last_run.harness` (version + the path of the file that ran) and the report's Scope block prints it; `verdict-run --plugin-root <checkout>` is how to stranger-test unreleased harness code. (2) The agent's own `pnpm install --config.runtime-on-fail=ignore` persisted the flag into the project's `package.json` — a write into the checkout by an install command, which the guard cannot see and the agent reported as CHANGESETS-F-18. Queued for the prompt release: an install flag that persists is a write. |
| 2026-09-07 | 0.82.0 (this checkout via `verdict-run --plugin-root`) | [mahmoud/boltons](https://github.com/mahmoud/boltons) (Python, pytest, 625 tests, 30 modules) | `pass with risks` · 8 findings, 2 Major · 15 min | `strutils.ellipsize` breaks words for tab/newline/NBSP-separated text; `statsutils.Stats.mode` flips its documented tie-break once any sorted measure is read (`Stats([2,2,1,1]).mode` is 2 fresh, 1 after `.median`). Both in unreleased code, both with a shipped test that exercises the one path that cannot fail. Four questions parked for the maintainer, twelve not-tested items. | **The acceptance run for 0.82.0.** Zero reads of `docs/state-schema.md` (every earlier run read two chunks); one `verdict-finalize` (earlier runs: two or three); the closing handoff 976 output tokens (ofetch 5,900, changesets 12,500); judgment turn 3:02 for eight findings, 62k output tokens for the whole run (earlier runs 72k–120k). And one thing that was not the agent's: the *outer* runner session appended "Say the word if you want the fixes written" under the handoff — the runner's prompt now forbids it. |
| 2026-09-07 | 0.82.0 (installed plugin via `verdict-run --plugin-root`; see the caveat) | [mahmoud/boltons](https://github.com/mahmoud/boltons) — **delta at an unchanged HEAD**, the control run for the 0.84.0 `still_open` verb | `pass with risks` · 11 findings (3 NEW, 8 STILL_OPEN) · 13.5 min | Two new Majors in the modules run 1 had left below its coverage cutoff, exactly where its own `next_run_focus` pointed: `mboxutils.mbox_readonlydir.flush()` spins forever on any pending deletion (the class's one purpose, unreachable on every supported Python 3); `excutils.ExceptionCauseMixin.__str__` raises AttributeError on CPython 3.13 and 3.14, so a wrapped exception is unprintable exactly when it is raised. One Minor (`mboxutils.DEFAULT_MAXMEM` declared, documented, never used). All eight run-1 findings re-reported STILL_OPEN. | **The measurement this run exists for:** the judgment took 3:32 to write — 39,500 characters for 11 findings, 13,000 of them the eight STILL_OPEN findings re-typed from the previous state; 60,800 output tokens for a run whose diff was empty. That is the cost the `still_open` verb removes. Two more things it showed: fix verification ran nothing, because run 1 had written prose into `verification_test` ("none — no test in … passes non-space whitespace") and the harness read it as a citation it could not find; and the runner **kept a prompt rendered from a development checkout** instead of the installed plugin it was launched from, so the run resolved that checkout as its plugin root and its finalize half ran on code being edited at the time (the facts half was 0.82.0's; the judgment is the 0.82.0 prompt's). Fixed in 0.83.0: the runner re-provisions what it rendered when the root moves. |
| 2026-09-07 | 0.83.0 (this checkout via `verdict-run --plugin-root`, fresh provision) | [mahmoud/boltons](https://github.com/mahmoud/boltons) — delta at the unchanged HEAD, **the acceptance run for 0.83.0's harness half** | `fail` · 17 findings (6 NEW: 2 Critical, 1 Major, 3 Minor) · 15 min | `fileutils.rotate_file(path, keep=1)` renames the file to `.1` and then deletes it — total data loss, and every `keep=N` retains N−1 generations; `FilePerms` never clears bits, so `fp.other=''` followed by `os.chmod(path, int(fp))` leaves the file as permissive as before while `repr` claims otherwise; the vendored `urlutils` OrderedMultiDict twin never received the `__reduce__` fix. Both Criticals proven by counterfactual with the instrument control run in the failing direction. **Reported upstream 2026-09-07 after an independent reproduction on a fresh clone: [mahmoud/boltons#479](https://github.com/mahmoud/boltons/issues/479) (rotate_file), [#480](https://github.com/mahmoud/boltons/issues/480) (FilePerms) — the first two findings this ledger ever sent anywhere; the other 28 stay here unsent.** | **Measured on real data:** `facts.next_finding_id` = BOLTONS-F-12 and the agent minted F-12…F-17 from it; 69 anchors written, 13 unresolvable (partial paths, CPython's own files); `introduced_at` resolved for 10 of 17 findings from the origin commit, so the headers read "lived 4595d before detection" (F-13, from 2014), "4212d" (F-9), "648d" (F-14); `evidence_drift: unavailable` with the reason (the previous state had no anchors). Zero schema-doc reads, one finalize, 66.9k output tokens. Before writing its judgment the agent wrote `build_judgment.py` — read `state.json`, carry every open finding, append the new ones — the `still_open` verb, implemented by hand. And it found a harness defect: this run shared run 2's date and topic, `verdict-finalize` composed the same filename, and run 2's report was overwritten. Fixed in 0.83.0 (`-run<n>` is appended). |
| 2026-09-07 | 0.83.0 (this checkout, same provision — "is current") | [mahmoud/boltons](https://github.com/mahmoud/boltons) — delta over a comments-only local commit that moves every line of `strutils.py` by three and rewrites `statsutils.py:195`; **the first run to measure drift** | `fail` · 22 findings (5 NEW in `urlutils`: 2 Major, 3 Minor) · 14.5 min | A `;` survives the URL round-trip unencoded and re-parses as an extra parameter (with an `&`/`=` control and a searched class); `find_all_links(schemes=…)` returns excluded links as raw `str`; `register_scheme(default_port=N)` silently no-ops; `?a=` and `?a` collapse; `uses_netloc` returns a str. Four questions for the maintainer, one of them three runs old. | **The question this run was for: does the agent read `evidence_drift` unprompted?** Yes. facts said F-1 and F-4 moved (+3, with the new line numbers) and F-2 changed; the judgment's evidence for those three, and only those, begins "EVIDENCE ANCHORS MOVED +3 this run (be3a37a inserts three comment lines at strutils.py:38-40): the cut-point search is now at :1373…", "EVIDENCE ANCHOR CHANGED this run: statsutils.py:195 is now `def _get_sorted_data(self):  # …`. The change is a trailing comment only; the in-place sort the finding rests on is unchanged", "code byte-identical (`sed -n '1365,1388p'`)" — re-verified exactly where the code moved, citations updated, nothing else re-read. The report's Scope line reads "Evidence drift: 3 of 16 anchored open findings cite code that moved or changed", each of the three carries its own line, and the report file is `2026-09-07-delta-run4.md` — run 3's survived. No prompt line about drift is needed; the prompt release will not add one. The judgment was again assembled by a script the agent wrote (`build_judgment_run4.py`). 68.4k output tokens. |
| 2026-09-07 | **0.84.0** (this checkout via `verdict-run --plugin-root`; the runner re-provisioned its own prompt — "the prompt at that root changed") | [mahmoud/boltons](https://github.com/mahmoud/boltons) — delta at the unchanged HEAD, **the acceptance run for 0.84.0** against run 2 as the control | `fail` · 30 findings (8 NEW: 3 Major, 5 Minor/Trivial; 22 STILL_OPEN) · 13 min | `reverse_iter_lines` reads a file's encoding and then overwrites it with hardcoded UTF-8 (every non-UTF-8 text file raises and the `encoding` argument cannot prevent it); `JSONLIterator(binary_file, rel_seek=0.5)` raises TypeError while the module's own CLI opens `'rb'`; `get_profile()` widens the process umask to 0o002 — 604 files created at 0o664 in a process demanding 0o600 (did not reproduce at CPython's default switch interval, and the finding says so). Three questions parked on the ledger: BOLTONS-Q-1 (`reverse_iter_lines` UTF-8-only by design?), Q-2 (should `ecoutils` still report a Linux distribution?), Q-3 (is packaging in QA scope — the standing profile TODO, five runs unanswered). | **The measurement this run exists for, against the control (run 2, 0.82.0 prompt, same HEAD shape):** the judgment took **1:18** to write (control 3:32) and was **14,400 characters** (control 39,500) — zero findings inline, **22 carried by id** (`still_open`), evidence byte-identical and anchors kept for 18 of them; the 8 NEW findings were **written as files while the run investigated** (filed 07:44–07:50, one every 45 s, the last four minutes before the judgment); output **52.3k tokens** (control 60.8k) for 2.7× the findings carried; 73 anchors, **1 unresolvable** (run 3: 13 of 69). **The design's one open concern happened and was caught:** the first finalize was refused — F-25, F-26 and F-27 each listed `ecoutils.py:338` (and :178) as a site of *their* class, three findings for one class — the agent folded them and finalized clean on the second try. Not measured yet: `verification_test` is still declared on none of the 30 findings (a test-id rule refuses a wrong one; nothing yet makes a right one cheap to find — see T-18). |
| 2026-09-07 | **0.86.0** (this checkout via `verdict-run --plugin-root … --skip-unless-drift`) | [mahmoud/boltons](https://github.com/mahmoud/boltons) — a comment-only local commit in `iterutils.py`, a file no finding cites | **swept, no model** · run 6 · 13 s including the wheel build | "HEAD moved 1 commit(s), 1 file(s) changed, none cited by a finding; gates green (suite 625 passed in 3.46s); test-id set unchanged; no quarantine due; no cited line moved — verdict 'fail' carried, no model call." The state reads `run_type: sweep`, `model: none`, all 30 findings carried by id. The same facts run measured the reading map (34 modules, 75% overall, `mboxutils` 12% with two open findings) and the tests that exercise each finding's cited lines (16 of 30). | **The model-free night, measured on a real repository:** the conditions are all harness measurements, and the first version of the map led with `docs/conf.py` and `misc/bench_omd.py` — git-tracked scripts outside the package — fixed before the tag (`outside_package`). |
| 2026-09-07 | **0.86.0** (same checkout) | [mahmoud/boltons](https://github.com/mahmoud/boltons) — one more comment line in `strutils.py`, a file three findings cite | `fail` · 37 findings (7 NEW in `setutils`: 2 Critical, 3 Major; 30 carried) · 15.5 min | The runner refused the sweep with the reasons ("cited code moved or changed: F-30, F-1, F-4; changed files a finding cites: strutils.py") and ran the model. `_ComplementSet`: `&=`/`update()` return the inverted set and `update()` can leave both internal slots `None` so the next membership test raises; `&` reverses its operands, `^` uses plain difference — under `tests/test_setutils.py:138-151`, whose own docstring says it "doesn't really confirm math identities" (13 mutating operations, zero assertions). The agent also caught and did not file its own false positive (a finite-universe model of `complement()` had scored six comparison operators as broken; a complement set is unbounded) and wrote the discriminator into `lessons.md`. | **The reading map was read and followed unprompted** ("the budget went to the coverage ranking rather than the diff, landing on `setutils._ComplementSet` (66%, the module run 6 nominated)"). **`verification_test` declared: 0 of 37** with the tests coverage names printed under every open finding — and the agent was right: a defect under a green suite is executed by tests that do not fail on it. The feature was reframed before the tag: `exercised_by`, the assertions to review and where a regression test belongs, never a candidate guard. The ten-line handoff grew a 15-line preamble again (P-23). |

### The external key — SWE-bench Verified instances

Every key above was written by the same hands that wrote the prompt, so a tester that
passes them has been tuned against them. The external key is a set of real defects
nobody here chose or described: SWE-bench Verified instances, each a maintainers' fix
with a test that fails before it and passes after it. `eval/swebench.py` turns one
instance into one run of the **shipped** plugin (the newest version in the plugin
cache — never a checkout being edited) and scores it against the fix's location.

The set is a rule, not a hand-pick: every Verified instance whose repository has fewer
than twenty instances in the set — the five smallest repositories (pytest 19, pylint 10,
requests 8, seaborn 2, flask 1; 40 instances, [`swebench/instances.json`](swebench/instances.json)).

What one run is:

1. **The checkout ends at the base commit.** The fixed commit's parent, with every later
   commit, branch and tag physically absent — reflogs expired before the repack, the
   alternates link cut — so `git log` cannot see the fix and neither can the tester.
   Tags on ancestors stay (setuptools_scm reads the version from them).
2. **The environment is the one the maintainers had.** Interpreter from SWE-bench's specs
   ([`swebench/specs.json`](swebench/specs.json)); packages resolved *as of the base
   commit's date* (`uv --exclude-newer`; the commit's, not the issue's — an issue can sit
   open for a year before the tree that fixes it exists) for base commits since 2020,
   SWE-bench's pins with fresh test tooling before that (a 2015 pytest cannot run on 3.9),
   and the pins again when the dated resolution cannot build (pylint pins astroid versions
   released after its own commits) or fails the proof below. SWE-bench's own pins post-date
   the instances by a year and break the suites around the withheld test — seaborn 0.12
   under pandas 2.0 is 646 red at base; dated, it is 0 red.
3. **The environment is proven before the tester arrives:** the withheld tests fail at
   base and pass with the gold patch, applied in the checkout and reverted. An instance
   that fails this is published as `env_invalid`, never run.
4. **The issue text, verbatim, is the charter** — the shipped `/verdict:bug` command,
   headless through `verdict-run`, in solo mode with a generated profile naming the
   project's own suite. `hints_text` and the withheld tests are never shown.
5. **The score is location, deterministic.** Every `path:line` a finding cites (the
   anchors finalize took from its evidence and class sites, plus references in its title
   and mechanism) is graded against the gold patch on the base side: `file` (a file the
   fix touched), `hunk` (within 15 lines of one of its hunks), `function` (the same
   enclosing function, by AST). The tester's *headline* finding — highest severity, first
   filed — is scored apart from "any finding", because a hit buried under seven other
   findings is not what a maintainer reads first. Mechanism is prose and is not
   machine-scored: a miss is published with what the finding said instead.

Per instance the ledger ([`swebench/results.jsonl`](swebench/results.jsonl)) records the
status, both grades, the findings with their cited files, wall time, the CLI's reported
cost and tokens, the plugin version and the prompt hash; `python3 eval/swebench.py table`
renders it. The QA roots and run logs are archived outside the repository
(`~/.cache/verdict-swebench/runs/`).

**Measured 2026-09-08, plugin 0.86.0, Opus, the whole set of forty.** Three instances carry no score: one whose withheld tests already pass at its base commit on Python 3.9 (a Python 2 unicode bug, published as `env_invalid` rather than dropped), and two the agent returned `blocked` on — a refusal to sign a verdict, not a miss, and its findings are still filed. Cost is the CLI's own list-price estimate on a subscription run, so read it as a comparable number rather than a bill.

Instances attempted: 40 · ran: 39 · scored: 37
- located at `function` or better — any finding: 36/37 (97%); headline finding: 35/37 (94%)
- located at `hunk` or better — any finding: 36/37 (97%); headline finding: 35/37 (94%)
- located at `file` or better — any finding: 37/37 (100%); headline finding: 36/37 (97%)
- wall time per run: median 12 min, max 31 min; total 8h54
- cost per run (CLI-reported): median $3.52, total $143.31
- output tokens per run (whole session, from the transcript): median 55k, total 2149k

| Instance | Difficulty | Status | Findings | Any | Headline | Wall | Output tok | Cost |
|---|---|---|---|---|---|---|---|---|
| pallets__flask-5014 | <15 min fix | scored | 2 | function | function | 8 min | 41k | $2.54 |
| psf__requests-1142 | <15 min fix | scored | 2 | function | function | 8 min | 40k | $3.01 |
| psf__requests-1724 | <15 min fix | env_invalid | — | — | — | — | — | — |
| psf__requests-1766 | <15 min fix | scored | 4 | function | function | 14 min | 63k | $3.52 |
| psf__requests-1921 | <15 min fix | scored | 2 | function | function | 10 min | 45k | $2.67 |
| psf__requests-2317 | <15 min fix | scored | 4 | function | function | 31 min | 58k | $4.30 |
| psf__requests-2931 | 15 min - 1 hour | scored | 3 | function | function | 9 min | 45k | $2.62 |
| psf__requests-5414 | <15 min fix | scored | 3 | function | function | 11 min | 52k | $3.09 |
| psf__requests-6028 | 15 min - 1 hour | scored | 3 | function | function | 13 min | 56k | $3.59 |
| pytest-dev__pytest-10051 | 15 min - 1 hour | scored | 4 | function | none | 12 min | 58k | $3.39 |
| pytest-dev__pytest-10081 | <15 min fix | scored | 3 | function | function | 12 min | 63k | $3.89 |
| pytest-dev__pytest-10356 | 1-4 hours | scored | 5 | function | function | 13 min | 57k | $3.72 |
| pytest-dev__pytest-5262 | <15 min fix | scored | 2 | function | function | 10 min | 41k | $2.51 |
| pytest-dev__pytest-5631 | 15 min - 1 hour | scored | 2 | function | function | 14 min | 46k | $3.02 |
| pytest-dev__pytest-5787 | 1-4 hours | scored | 4 | function | function | 12 min | 55k | $3.91 |
| pytest-dev__pytest-5809 | <15 min fix | scored | 5 | function | function | 13 min | 51k | $3.20 |
| pytest-dev__pytest-5840 | 15 min - 1 hour | scored | 5 | function | function | 15 min | 69k | $4.34 |
| pytest-dev__pytest-6197 | 1-4 hours | scored | 3 | function | function | 13 min | 55k | $3.41 |
| pytest-dev__pytest-6202 | <15 min fix | scored | 3 | function | function | 19 min | 50k | $3.76 |
| pytest-dev__pytest-7205 | <15 min fix | scored | 2 | function | function | 12 min | 48k | $3.08 |
| pytest-dev__pytest-7236 | 15 min - 1 hour | scored | 4 | function | function | 11 min | 56k | $3.57 |
| pytest-dev__pytest-7324 | 15 min - 1 hour | scored | 2 | function | function | 10 min | 36k | $2.39 |
| pytest-dev__pytest-7432 | <15 min fix | scored | 2 | function | function | 9 min | 46k | $3.08 |
| pytest-dev__pytest-7490 | 15 min - 1 hour | scored | 3 | function | function | 9 min | 48k | $3.12 |
| pytest-dev__pytest-7521 | <15 min fix | scored | 2 | function | function | 9 min | 47k | $3.08 |
| pytest-dev__pytest-7571 | 15 min - 1 hour | scored | 3 | function | function | 11 min | 51k | $3.40 |
| pytest-dev__pytest-7982 | <15 min fix | scored | 3 | function | function | 15 min | 64k | $4.37 |
| pytest-dev__pytest-8399 | 15 min - 1 hour | scored | 2 | function | function | 8 min | 40k | $2.68 |
| mwaskom__seaborn-3069 | 15 min - 1 hour | scored | 1 | function | function | 16 min | 54k | $3.35 |
| mwaskom__seaborn-3187 | 15 min - 1 hour | blocked | 4 | function | function | 21 min | 71k | $5.50 |
| pylint-dev__pylint-4551 | 1-4 hours | scored | 3 | function | function | 15 min | 58k | $3.99 |
| pylint-dev__pylint-4604 | 15 min - 1 hour | scored | 4 | function | function | 12 min | 56k | $5.29 |
| pylint-dev__pylint-4661 | 15 min - 1 hour | scored | 6 | function | function | 15 min | 52k | $3.59 |
| pylint-dev__pylint-4970 | <15 min fix | scored | 6 | function | function | 20 min | 74k | $5.16 |
| pylint-dev__pylint-6386 | 15 min - 1 hour | scored | 4 | function | function | 18 min | 73k | $5.58 |
| pylint-dev__pylint-6528 | 15 min - 1 hour | blocked | 4 | function | function | 14 min | 71k | $4.86 |
| pylint-dev__pylint-6903 | <15 min fix | scored | 4 | function | function | 11 min | 57k | $3.53 |
| pylint-dev__pylint-7080 | 15 min - 1 hour | scored | 6 | file | file | 18 min | 78k | $6.13 |
| pylint-dev__pylint-7277 | <15 min fix | scored | 3 | function | function | 11 min | 43k | $2.84 |
| pylint-dev__pylint-8898 | 1-4 hours | scored | 4 | function | function | 13 min | 62k | $4.21 |

| Difficulty | Scored | Any ≥ hunk | Headline ≥ hunk |
|---|---|---|---|
| 1-4 hours | 5 | 5/5 (100%) | 5/5 (100%) |
| 15 min - 1 hour | 15 | 14/15 (93%) | 13/15 (86%) |
| <15 min fix | 17 | 17/17 (100%) | 17/17 (100%) |

Misses — what the headline finding said instead (mechanism is not machine-scored; judge the near-misses yourself):
- pytest-dev__pytest-10051 (function at best): Major "Suite gate is red at HEAD before any change: 22 pre-existing failures clustered in config/conftest/main, most likely dependency versions far newer than the chec" — cited testing/test_conftest.py; gold src/_pytest/logging.py

Not scored:
- psf__requests-1724: env_invalid — all 6 withheld test(s) already pass at base
- mwaskom__seaborn-3187: blocked — 
- pylint-dev__pylint-6528: blocked —

#### The control arm — the same runs without Verdict (measured 2026-09-13)

The rates above say where Verdict's findings land against the gold patch, not that the plugin
is why: Claude Code handed the same issue might land there too. `swebench.py batch --arm plain`
is the control, and it differs from the Verdict arm in the plugin and the prompt only.

- **Held equal:** the forty instances and `prepare()` (checkout, dated environment, proof) in a
  fresh workdir (`--reuse` is refused for this arm); `--model`, `--timeout-s`, `--env-file` /
  `CLAUDE_CONFIG_DIR` with trust seeded; the launch `verdict-run` makes — `claude -p <prompt>
  --model opus --setting-sources project,local --output-format json
  --dangerously-skip-permissions` from the checkout, through the runner's own streaming call
  and retry rules; the transcript token count; and the scorer, `score_findings()`, which both
  arms call.
- **Taken out:** no agent, command, skill, hook or guard is provisioned, the generated QA
  profile is deleted before the session, and no `VERDICT_*` variable reaches the CLI.
- **The prompt** names the repository, the profile's suite command (less Verdict's
  `--junitxml={report}` placeholder) and a scratch directory; asks for the defect, with no fix
  and no edit; and wants one closing JSON block — `title`, `severity`, `file`, `line`,
  `mechanism` per defect, most important first. Then the issue, verbatim. It never says
  Verdict, QA, finding or harness, and every row carries the template's sha256.
- **The answer** is the last `` ```json `` block of the final reply. None, or one that does not
  parse, is `no_answer`; a first attempt without one is retried once, as the runner retries a
  run that wrote no state. Each item becomes a finding with `file:line` as an anchor and as
  prose, graded with function spans from the base commit in the mirror (nothing guards this
  arm's writes), and `git status --porcelain` after the run is published as `modified_checkout`.
- **Kept apart:** `swebench/results-plain.jsonl` and `~/.cache/verdict-swebench/runs-plain/`.
  `table --arm plain` renders that ledger; `table --compare` sets both arms side by side over
  the instances scored in both and lists every instance where they disagree.

Not equal, or not by construction — measured on the Verdict arm's archive before any plain run:

- **Citations.** A Verdict finding cites every `path:line` in its evidence; a plain item cites
  one `file:line` plus any in its mechanism. Of the Verdict arm's 35 headline hits at
  `function`, 12 have exactly one citation at that level.
- **Instructions.** The operator's `~/.claude/CLAUDE.md` is the `.claude/CLAUDE.md` of an
  ancestor of every checkout; Claude Code attached it to 34 of the Verdict arm's 41 sessions.
  It names Verdict and routes testing to it, so a plain session can meet Verdict's name there,
  though never in its prompt. Held equal rather than removed from one arm; each plain row
  records the instruction files its session was given.
- **Reach.** The checkout sits inside the cache, so a session in either arm can read the
  dataset file (every gold patch), the mirrors (every fix commit) and the network — and a plain
  session, running second, the Verdict findings for its own instance. Nothing blocks it; each
  plain row lists the tool calls that did, by a heuristic over the transcript that flags none of
  the Verdict arm's 41 sessions.
- **Version.** Every Verdict transcript says Claude Code 2.1.263, and every result line that
  names a model names `claude-opus-5`; each plain row records `claude --version` and the models
  its result line reports.
- **Memory.** A plain run refuses to start where Claude Code's auto-memory for the checkout
  path is not empty; every Verdict session started with none.

**Measured 2026-09-13 with Claude Code 2.1.263 and Opus (`claude-opus-5`), on all forty instances.**

- **Coverage:** thirty-nine instances ran and were scored. requests-1724 is `env_invalid` in both arms.
- **Answer material held out:** for the length of the batch, the Verdict arm's archives (`~/.cache/verdict-swebench/runs/`) were packed into a tarball outside the cache. No plain session could read Verdict's findings for its own instance. They were restored afterwards.
- **Clean runs:** no plain session modified its checkout or reached past its instance (0 of 39).

Over the 37 instances both arms scored:

| Located at … or better | Verdict · any | Plain · any | Verdict · headline | Plain · headline |
|---|---|---|---|---|
| `function` | 36/37 (97%) | 35/37 (94%) | 35/37 (94%) | 35/37 (94%) |
| `hunk` | 36/37 (97%) | 36/37 (97%) | 35/37 (94%) | 36/37 (97%) |
| `file` | 37/37 (100%) | 37/37 (100%) | 36/37 (97%) | 36/37 (97%) |

| Median per run, over those instances | Verdict | Plain |
|---|---|---|
| wall time | 12 min | 1 min |
| cost (CLI-reported) | $3.41 | $0.45 |

Totals across each arm's scored instances:

| | Plain (39) | Verdict |
|---|---|---|
| Output tokens | median 4k, total 205k | total 2,149k |
| Cost | total $21.91 | total $143.31 |
| Wall time | total 2h43 (1h52 of it one session-limit wait) | — |

The arms disagree on three instances, and the split goes both ways:

| Instance | Verdict · any | Plain · any | Verdict · headline | Plain · headline |
|---|---|---|---|---|
| pytest-dev__pytest-10051 | function | function | none | function |
| pylint-dev__pylint-4661 | function | hunk | function | hunk |
| pylint-dev__pylint-7080 | file | file | file | none |

- **pytest-10051:** Verdict found the defect (its F-1, at `function`). Its headline, though, was a Major of equal rank about 22 pre-existing suite failures. A finding about the environment outranked the finding about the code.
- **pylint-4661:** both arms found the same defect. Verdict's headline cites seven files and reaches `function`; the plain item cites one location and reaches `hunk`. This is the citation asymmetry described above, in Verdict's favour.
- **pylint-7080:** both arms describe the same mechanism. The plain item names `pylint/lint/pylinter.py`; Verdict names the file the maintainers fixed.

The plain arm also scored the two instances the Verdict agent refused to sign (seaborn-3187 and pylint-6528).

**What it says.** This key asks one thing: locate the defect behind an issue report. On it, the plugin buys no measurable accuracy. The rates agree within one instance at every level. The plain arm takes a twelfth of the time and less than a seventh of the cost.

**What it does not say.** The key exercises one charter: `/verdict:bug` with the issue verbatim. It cannot see what the plugin is built for beyond that: memory across runs, finding lineage, the gate, fix verification and quarantine. And with n=37 across five small repositories, a one-instance difference is noise.

**Harness defects the run exposed** (not fixed, because feature work is paused):
- `prepare()` cannot delete a workdir that holds `d-w-------` `.pytest_cache` directories. pytest's own `test_cache_failure_warns` and `test_cache_writefail_permissions` leave those behind. Five pytest 5.x instances failed to prepare until the directories were unlocked by hand and the instances retried.
- `cleanup()` removes `work/<id>/checkout`, which never exists, so every workdir stays on disk.

### A prompt cut that measured worse — and what it cost to learn

The largest measured cost of a run is not any one output: it is a fixed preamble
re-read on every turn. The contract was 53,003 characters (~13,250 tokens) against ~38
turns, so a cut there is worth more than any other edit. Two changes were made and paid
for together on 2026-09-09, and the payment is why only one of them shipped.

**What was cut.** Section 6 restated what the harness had since taken over: it decides
`run_type` and records why, ages every finding, and writes the state, the report and the
INDEX row itself. Section 7 listed twelve paths where the agent writes four. Together
that was 1,070 tokens off every turn.

**What was added.** The class link — "is this an instance or a pattern?" — was turned
from a principle into an instruction to run `grep -rn` and record the hits, aimed at a
measured gap: Sonnet finds a defect and does not generalise it (0 of 2 against Opus's 3
of 3).

**Paired against v0.87.0, n=2, Opus:**

| Fixture | New prompt | v0.87.0 |
|---|---|---|
| rates (root cause) | 8/10 · 10/10 | 10/10 · 10/10 |
| pricer (seeded delta) | 9/9 · **0/9** | 8/9 · 9/9 |

| Root-cause arm | Output tokens | Cache read | Requests |
|---|---|---|---|
| New prompt | 88,991 | 3,794,582 | 81 |
| v0.87.0 | 64,984 | 2,541,808 | 65 |

Worse on quality **and** 37% dearer, which is the opposite of the intent. Two causes,
both found by reading the runs rather than by guessing:

- **The instruction to run a search bought extra turns and won nothing.** It fired on the
  root-cause fixture, where searching is already the work, and the class rows did not
  improve. Reverted to the released wording.
- **One trimmed path was load-bearing.** The old §7 named `judgment.json` explicitly; the
  compressed version did not, and a run wrote its judgment outside the QA root. Everything
  else about that run was correct — nine findings, a `fail` verdict, a full report — and it
  scored **0/9** on a hard failure, because a judgment the harness cannot find is
  indistinguishable from state written by hand. The path is back, with the reason beside
  it.

**The deduplication, re-measured alone, shipped as 0.88.0.** Same fixture, n=3 each:

| Prompt | Runs | Total | Output tokens (paired arm) |
|---|---|---|---|
| 0.88.0 (deduplicated) | 9/10 · 10/10 · 9/10 | **28/30** | 66,017 |
| 0.87.0 (released) | 10/10 · 10/10 · 8/10 | **28/30** | 80,571 |

Identical totals, 19% fewer output tokens at the same request count, and 1,070 tokens
less prompt on *every* turn. Neither arm is stable at 10/10 on this fixture — the released
prompt loses a row one run in three as well — so the honest claim is parity at a lower
price, not an improvement in judgement.

Cutting what the harness already decides is safe; adding an instruction to spend turns is
not, and neither was obvious before the runs. This is what the paired eval is for: it is
cheaper to be wrong here than in a release.

### Local mode — a 7B model, measured

`verdict-local` is the other way to run: the harness drives and the model answers one
bounded question at a time (see the module docstring in
[`src/verdict_mcp/small.py`](../src/verdict_mcp/small.py) for why the agent shape cannot
shrink to a small model). It is scored by the same `score.py`, against the same
[expected.json](expected.json), on the same baseline fixture.

**Measured 2026-09-09, `qwen3:8b` on a local Ollama behind a LiteLLM gateway, n=3.**

| Run | Score | Missed | Model calls | Input tokens |
|---|---|---|---|---|
| 1 | 9/10 | stale expectation | 27 | 7,167 |
| 2 | 9/10 | stale expectation | 25 | 6,390 |
| 3 | **10/10** | — | 30 | 8,103 |

No hard failures in any run, and the harness chain (`facts_measured`,
`judgment_written`, `state_computed`, `report_rendered`, `chain_intact`) intact in all
three — the state was assembled by `verdict-finalize`, not written by hand.

The one unstable row is `3-stale-fee-expectation`: the failing fee test has to be read as
a deliberate change authorised by the CHANGELOG rather than as a defect. Two runs in three
called it correctly. That is the row that needs judgement rather than arithmetic, and it
is exactly where a small model wavers.

**What did the work, and what the model was spared.** The climb from 4/10 to 10/10 was
almost entirely a transfer of work *out* of the model:

| Row won | By |
|---|---|
| nondeterministic test + quarantine | running the suite three times and comparing the failing sets — no model call |
| environment failure | the error class the interpreter already named (`FileNotFoundError`) — no model call |
| skip with no expiry | a regular expression over the test files, where a date in the past is not an expiry — no model call |
| the verdict | arithmetic over the filed findings — no model call |
| brittle test, stale expectation, both real defects | one bounded question each, a few hundred tokens |

A run costs ~30 model calls and ~7k input tokens in total. The Opus agent on this same
fixture reads about two million tokens of context across 38 turns. The comparison is not
quality-for-quality — local mode proves nothing by execution and says so in every report,
and it does not attempt archaeology, an exploratory charter, or an adversarial reading of
the suite — but on this fixture's answer key it is not behind.

### The local tier as a delta — measured 2026-09-17/18, and a false green it caught

`run_eval.py --engine local`, `qwen3:8b` through the author's LiteLLM gateway on a GTX 1070,
every question sent with an 8,192-token window, the fixtures' pytest on PATH, n=3 per mode.
No Claude tokens.

| Tree | Fixture | Runs | Verdict row | Notes |
|---|---|---|---|---|
| `19619bc` | pricer, seeded delta | **0/9 ×3** by protocol | **`pass with risks` — a false green** | three tests failing |
| `5e00d00` (red gate = `fail`) | pricer, seeded delta | 0/9 ×3 by protocol, **6/9 ×3 on substance** | `fail` ✓ | zero false greens |
| `5e00d00` | pricer, baseline | **9/10 · 9/10 · 10/10** | ✓ | no hard fails |
| `8190963` (a returning defect is REGRESSED) | pricer, seeded delta | **7/9 · 7/9 · 7/9**, no hard fails | `fail` ✓ | zero false greens; the regression reported as REGRESSED in every run |
| `1b7f1cb` · `1b7f1cb` · `a976243` (the Sales shadow fixes) | pricer, seeded delta | **7/9 · 7/9 · 7/9**, no hard fails | `fail` ✓ | zero false greens; one more run on `1b7f1cb` was lost to a gateway outage mid-run — the engine refused to finalize without its model (exit 5, no state), as designed |

**The false green, and why the gate exists.** The first valid run carried all five prior
findings by id, resolved nothing by silence and nothing without measurement — and reported
`pass with risks` over a suite with three failing tests. The verdict was arithmetic over finding
severities, and a reading no counterfactual proved is held at Minor, so a real regression filed
as an unproven Major could never force a fail; nothing in the rule looked at the gate. A red
gate now outranks every finding (mutant P21). That is the whole reason this tier is measured by
"zero false greens" rather than by points.

**The hard fail that was left, fixed.** On `5e00d00` every seeded run scored 0 by protocol on one
hard fail, and the paragraph below describes it as it was measured. `8190963` matches a claim to
an earlier finding before filing it — by the line hashes the finding's anchors recorded, else by
the function the finding names — so a resolved finding that returns comes back under its own id
and is REGRESSED, and an open one is not filed a second time. Measured the same day: 7/9 in all
three runs, no hard fail, the rounding regression ranked first; 54–75 minutes a run. The baseline
arm was not re-run: the change matches against a previous state, and the baseline has none.

**What it still misses, declared.** Every seeded run scores 0 by protocol on one hard fail,
`regressed_not_first`: the rounding defect the golden state had resolved comes back as a **NEW**
finding rather than **REGRESSED**, because the engine files its own finding instead of recognising
the prior one — so the report's first entry is not the regression. The expired quarantine stays
quarantined, because this fixture's profile names no `test_one_cmd` and the tier releases a
quarantine only by measuring the test, never by the date. `resolved-env-fixture` stays open
because the golden state declares no `verification_test`, and a resolution this tier cannot
measure it does not make. Rows earned in every run: `new-bulk-threshold`, `still-open-floor`,
`still-open-by-id`, `findings-filed-as-files`, `questions-not-reasked`, `verdict`.

**What that means for a nightly.** Safe and blunt: it will not invent a pass, close a finding by
silence, or improve a standing verdict, and a red suite is a `fail`. It will under-rate what it
cannot prove and will not tell a regression from a new defect. The judgment a strong model adds —
is this failure stale, brittle, or real; is this the bug that came back — stays with a run
somebody asks for. **It is slow:** 50–55 model calls and **76–93 minutes** per delta run on
this GPU, 29–31 calls and 37–43 minutes per baseline — about 90 seconds a question, against a
design estimate of 10–15 (the counters each run writes into `last_run.local`). Fine for a night;
too slow to sit in front of a merge.

### The local tier on a real project — Sales shadow nights, 2026-09-18

The fixtures are small and written by the author; the question a nightly answers is whether the
tier survives a real record. So it ran against the author's own Sales project the way a night
would — `verdict-local --delta` on a detached checkout of `origin/main`, against a **copy** of the
live QA root (run 32: 69 open findings, verdict `fail`), with `VERDICT_HOME` in scratch so nothing
real could be written. Each night that failed was diagnosed from its own output and fixed with a
test and a pinned mutant before the next.

| Night | Tree | Result | What it taught |
|---|---|---|---|
| 1 | `2372410`* | refused, **4 h 10 min** | a class conflict the record already held refused the night; no time budget over a 744-line range nothing executes; 27 unproven Minor readings filed onto a backlog of 69; every proof failed to import — `core/src/sales_core/cli.py` was imported from the repository root |
| 2 | `1b7f1cb` | refused, 1 h 03 min | two skip markers with one reason in one file became two findings with one identity |
| — | replay, offline | — | night 2's own output replayed through finalize: the *following* night would file the same skip markers again under new ids and be refused — every night after the first (fixed in `fc5ddfb`, before any night ran into it) |
| 3 | `a976243` | **finalized**, 1 h 04 min | ids: the night minted `SALES-F-1` beside `F-162` — a second numbering (fixed in `2747910`) |
| 4 — the next night, over night 3's record | `2747910` | **finalized**, 7 min 48 s | the four skip findings recognised as already on the record and not filed again; 73 carried, 0 resolved by silence. At the same commit its range was empty, and an empty range fell through to the whole repository's reading map and was reported as too large (fixed after it) |

\* Night 1 ran on `649797e`, the same change set before the branch was rebased onto main as `2372410`.

**Night 3, as recorded:** run 33, verdict `fail` (carried — this tier cannot improve a verdict),
`last_run.model` `local:qwen3`; **69 carried by id, 0 resolved by silence**, the 6 withdrawn
findings kept; 4 new Minor findings, each a skip marker with no expiry (the two same-reason
markers on one finding); the inherited conflict asked once as a question; 17 functions read and
302 skipped when the hour ran out, both counted in `not_tested`; 9 unproven readings listed as
leads in the report and the focus list, none filed; 60 model calls, 90,891 tokens, 8 unanswered,
0 transport errors. **No Claude tokens.**

**The fixture after the shadow fixes.** The seeded delta was re-run on the trees the shadow
nights produced (table above): 7/9 in all three, the same two declared misses, zero false greens.
The two rules added after the last of those runs — an identity already on the record, and a
failing test this engine already filed — were replayed against the kept workdirs of those runs:
neither matches anything the fixture files, so the numbers stand for the final tree.

**What it does not do on this project.** Most counterfactual proofs over `cli.py` fail on the
original code with `click.exceptions.Exit: 2`: the 8B model calls a click command as if it were a
function, and click exits on the missing arguments. Those readings stay leads. The night reads
about a sixth of what a 744-line range asks for, and says so under `needs_claude`.

### The model axis — Opus against Sonnet, paired

Every published row above is Opus. The question a maintainer actually asks is whether a
cheaper model would do, and `run_eval.py --pair-model <model>` answers it the same way the
prompt axis is answered: same fixture, same prompt, arms interleaved so a bad hour lands on
both, one table, each arm's token bill read from its own transcript.

**Measured 2026-09-08, n=3 per arm, plugin 0.86.0 prompt.**

| Fixture | Opus | Sonnet |
|---|---|---|
| [liar](fixtures/liar/) (adversarial honesty) | 6/6 · 6/6 · 6/6 | 6/6 · 6/6 · 6/6 |
| [rates](fixtures/rates/) (root cause) | 10/10 · 10/10 · 8/10 | *no state* · 9/10 · 8/10 |

**The honesty fixture is a tie.** Both models caught the `conftest.py` that force-skips every
collected test, three times out of three — including the run where a single earlier
measurement had Sonnet missing it. That row has always been the high-variance one (Opus
itself caught it once in three at v0.43.0); n=1 was not evidence either way.

**Root cause is parity except for the class.** Every row matched except
`class-other-truncation-sites`: Opus found the *other* sites carrying the same truncating
conversion 3 of 3, Sonnet 0 of 2. Sonnet finds the defect and does not generalise it — which
is exactly the row that decides whether a fix at one site leaves the same rule broken two
modules away. That is a prompt problem before it is a model problem.

> **Correction, 2026-09-16 — that paragraph may be describing the scorer, not Sonnet.** The
> row in question could not be earned by the class-owning finding at all (see Answer-key
> amendments, 2026-09-16): it was earned by any *second* finding containing the word `invoice`.
> A run that did what the contract asks — one finding, the sibling sites under
> `root_cause.class.sites` — scored it as a miss. And if the per-row account above is complete,
> the Sonnet run that scored 9/10 missed only this row, so it earned `class-not-split` — sites in
> both `invoice.py` and `report.py`, recorded in one finding. That is generalising. It is an
> inference from the published numbers, not a re-score: those workdirs are gone. The claim above
> is left standing as published. **Settled 2026-09-17 by the paired re-run below: refuted** —
> Sonnet named the sibling sites in three runs of three.

**One Sonnet run wrote no state at all**, scoring 0/0 with `state_missing`. One occurrence,
recorded rather than explained.

**Sonnet is not doing less work.** Across the three root-cause runs it produced fewer output
tokens (78k against 98k) but read *more* context (5.56M against 3.77M) over more turns (129
against 97). The saving is the per-token price, not less effort — which matters, because the
measured cost of a run is dominated by a fixed preamble re-read on every turn.

**2026-09-17 — the seeded delta, paired, and two harness defects it found.** Same protocol,
0.88.0 prompt (sha `451a01db…` in both arms), n=3, arms interleaved, scored with
`--require-harness`:

| Arm | Run 1 | Run 2 | Run 3 | Output tokens | Cache read | Requests |
|---|---|---|---|---|---|---|
| Opus | 8/9 | 9/9 | 8/9 | 183k | 8.17M | 135 |
| Sonnet | **0** (9/9 on substance) | **0** (no state) | **0** (no state) | 186k | 10.93M | 150 |

Read as a model comparison that table says Sonnet cannot do the job, and it would be wrong.
**Run 1** is a complete, correct run — REGRESSED ranked first, the expired quarantine released,
three findings carried by id (the row Opus missed twice) — that passed `--out` to
`verdict-facts`. The flag's help says "also write facts.json here"; the code wrote it there
*instead*, so the QA root held no facts, `facts_measured` read false, and the protocol zeroed
the run as hand-written. Scored without the harness requirement it is **9/9**. **Runs 2 and
3** never finished: the outer headless session delegated the tester in the background and ended
its turn, and the CLI's print mode kills background tasks after 600 seconds — one tester died
with its judgment and four finding files written and no `verdict-finalize`. Opus's outer
session happened to wait; the fixture measured *which model waits for its subagent*. Both are
fixed in the harness (0.89.0: `--out` is a second copy; the runner and this rig export
`CLAUDE_CODE_PRINT_BG_WAIT_CEILING_MS=0`), neither in the prompt, and the payment stopped after
the fixture then in flight rather than spend on an arm the instrument could not read. The
scorer also failed in the first launch for a reason of the operator's making — a bare `python3`
without the package importable — and every row above was re-scored from the kept workdirs,
which costs no tokens. (That first attempt's honesty fixture, which neither defect touched:
Opus 6/6 · 6/6 · 6/6, Sonnet 6/6 · 6/6 · 5/6.)

**2026-09-17, the same day — the pairing re-run on the fixed harness** (tree `03a7d0f`, the same
0.88.0 prompt in both arms, n=3 per arm, interleaved, the worktree's own interpreter, a clean
environment). List price: Opus $5/$25, Sonnet $2/$10 per million tokens in/out, cache read a
tenth of input, cache write 1.25×.

| Fixture | Opus | Sonnet | Opus bill (3 runs) | Sonnet bill (3 runs) |
|---|---|---|---|---|
| pricer, seeded delta (9 rows) | 8/9 · 8/9 · 9/9 | 8/9 · 9/9 · 9/9 | 151 req · 193k out · 9.47M read · **$11.92** | 130 req · 166k out · 8.47M read · **$4.35** |
| liar, adversarial honesty (6) | 6/6 · 6/6 · 6/6 | 6/6 · 6/6 · 6/6 | 132 req · 117k out · 5.11M read · **$7.23** | 121 req · 118k out · 5.93M read · **$3.15** |
| rates, root cause (10) | 10/10 · 10/10 · 9/10 | ***no state*** · 10/10 · ***no state*** | 106 req · 102k out · 4.15M read · **$6.16** | 79 req · 66k out · 2.84M read · $1.74 |

**The delta and the honesty fixture: parity, at about 40% of the price.** Sonnet 26/27 against
Opus 25/27 on the protocol a nightly and a merge gate actually run, no hard fail in either arm,
and the one row anybody missed (`still-open-by-id`: a finding re-typed instead of carried by id)
is missed by both. On the fixed harness Sonnet also did **not** take more turns than Opus — the
2026-09-08 figure (129 requests against 97) does not reproduce.

**Root cause: the class claim is refuted, and a different gap is measured.** The Sonnet run that
wrote state scored 10/10 on the amended key, both class rows included. The other two wrote no
state — and their handoffs are right on substance: both name the truncating `to_cents`, both
separate trigger from cause, and **both say in words that `invoice.py` and `report.py` repeat the
conversion and that fixing `money.py` alone leaves them wrong.** Sonnet generalises. What it did
in two runs of three is answer the root-cause charter as a diagnosis and never call the harness
at all: zero `verdict-facts` calls in 21 and 18 requests, an empty QA root, nothing on the
record. That is a contract miss (`commands/cause.md` step 7 ends in the state and the handoff),
it is not the background kill (the ceiling was lifted) and not `--out`, and the stop hook's new
rule cannot see it, because a tester that never measured leaves no marker. It is cheap to catch
from outside — `verdict-gate --min-run-number <n+1>` exits 4 or 5 — and that is where it is
caught: a runner that re-asks once, an orchestrator that sends the tester back. It is not pinned
to the prompt here, because a blanket "every invocation must write state" rule would nag the
charters that legitimately write none (a bug report, a regression checklist).

**What a maintainer can take from it.** For delta runs, merge gates and honesty-class review,
Sonnet signs at parity on this prompt. For the root-cause charter, gate the run number and
re-ask. The acceptance rule set before the payment — no hard fail in nine Sonnet runs — was
**not met** (two, both on root cause), and that is the published result. Both payments together
cost about $61 at list price, $27 of it the first attempt whose Sonnet delta arm the harness
could not read.

**The same evening — does one sentence in the request close the gap?** An orchestrator's packet
now says "this is a run". Measured the way it is used: `run_eval.py --task-note` appends
*This is a QA run, not a chat answer: start with verdict-facts, write the judgment, and end with
verdict-finalize. An answer without state is not accepted.* to the fixture's task, and leaves the
agent prompt and its hash (`451a01db…`) alone. Sonnet, root cause, n=3, tree `e00b93c`:

| Sonnet on root cause | Wrote state | Scores | Bill (3 runs) |
|---|---|---|---|
| without the sentence (the pairing above) | 1 of 3 | *no state* · 10/10 · *no state* | $1.74 |
| **with the sentence** | **3 of 3** | **9/10 · 10/10 · 9/10** | $2.77 |
| Opus, for reference (the pairing above) | 3 of 3 | 10/10 · 10/10 · 9/10 | $6.16 |

The misses are `chain-reported-with-mechanism` once — Opus's own miss above — and
`trigger-separated-from-cause` once, the row whose single-word scorer is an open finding
(VERDICT-F-74). **What it shows: with the run named as a run, Sonnet finishes it, at 28/30 against
Opus's 29/30 and under half the bill. What it does not show:** that the sentence is the cause —
three of three against one of three is a probability of about one in five by chance alone, and
the two arms ran hours apart. It is enough to keep the sentence in every packet and to keep
checking the run number afterwards; it is not a published rate.

### Where the tokens go — a census of the author's own runs

Every number above prices one run. The question an operator actually has is what the *habit*
costs and who is spending it, and the answer was not the one anybody expected.
[`usage_census.py`](usage_census.py) over every Verdict-agent run recorded on the author's
machine, 2026-08-13 → 2026-09-17, tokens summed per request id:

| Launched by | Runs | Requests | Output | Cache read | Cache write |
|---|---|---|---|---|---|
| an interactive session, the tester spawned as a subagent | 215 | 8,815 | 15.06M | 947.8M | 51.1M |
| a headless `claude -p` — the scheduled nightly | 17 | 1,316 | 1.47M | 174.1M | 4.4M |

About $1,400 at list price, and **the nightly everybody suspected is a sixth of it.** 214 of the
232 runs were spawned with no model named, so `model: inherit` handed them whatever the
orchestrating session was running — the most expensive model on the account, 218 times out of
232. Nobody chose that; it is what a default does when nothing records the bill.

| One run | Median | p90 | Largest |
|---|---|---|---|
| requests | 33 | 87 | 157 |
| output tokens | 46k | 148k | 398k |
| cache read | 2.8M | 12.8M | 40.3M |
| largest context a request carried | 137k | 322k | 579k |

The shape is turns times a growing context: about fifty small shell calls a run, none of them
large, each re-reading everything before it. **The 15 largest runs — 6.5% of them — are 27% of
all cache read.** Two consequences follow, and neither is a prompt edit: the model that signs an
unattended or routine run should be chosen, not inherited (`verdict-run --model`, a per-spawn
model for the subagent, or `verdict-local` and the model-free sweep, which cost nothing); and a
run deserves a stated budget, because the tail is where the money is.

Also measured the same day: the nightly had never been given `--skip-unless-drift`, so on a night
when HEAD had not moved it spent a full model run to carry 61 findings by id. With the flag the
same night took two seconds and said so.

### Recall — what the tester *misses*

Every row above measures precision against a hand-authored answer key: defects someone
wrote on purpose, which the prompt has effectively been tuned against. They say nothing
about the number a tester is actually judged on — **what did you miss?**

So there is a second instrument, and it uses defects nobody authored:

1. [`fixtures/pricer_clean/`](fixtures/pricer_clean/) is the same little pricer with every
   spec rule implemented *correctly*, and a suite that is realistic rather than exhaustive:
   the happy paths and the two boundaries anyone would think of, with the gaps a careful
   reader would notice left in deliberately, because a mutant the suite fails to kill is
   exactly the defect a tester has to find by reading. Nothing in the fixture says so —
   that is the point of Fixture hygiene, and it used to be the fixture's own docstrings.
2. [`mutate.py`](mutate.py) breaks one line at a time with mechanical operators, then asks
   two questions of each mutant. **Does the suite kill it?** A killed mutant takes no
   insight to find — the tester should report the red test, and that is all. **Does it
   change behaviour at all?** Each fixture ships a `probe.py` that fingerprints the module
   over an input grid; identical output everywhere means an *equivalent mutant*, a source
   change that is not a defect, and scoring a tester for missing it would be scoring a
   question with no answer. The probe stays with the maintainer's tools —
   `run_mutation.py` does not copy it into the checkout, because a file that fingerprints
   every public function over a grid tells a tester what it is standing in.
3. What survives both filters — the suite misses it, and it provably changes behaviour —
   is the only honest denominator: real defects that can be found solely by reading.
   [`run_mutation.py`](run_mutation.py) plants each one in a fresh repo, alone, runs
   Verdict, and asks whether any finding cites the module and names the function that was
   broken.

The oracle checks itself: a mutant the suite killed but the probe called a no-op means the
input grid has a hole, and the same hole would silently drop a real survivor out of the
denominator. It is reported, not swallowed — the first grid had no negative prices, so
deleting a negative-price guard looked like a no-op.

Because the base is clean, the protocol measures the opposite error for free: any finding
about a module whose only defect is the planted one is a candidate false positive. Both
numbers are recorded; neither is flattered.

```bash
python3 eval/mutate.py                     # the census — no model, no tokens
python3 eval/run_mutation.py --model opus  # one model run per survivor
```

**First measured run** (2026-08-29, Opus, `pricer_clean`): census 33 mutants → 21 killed
by the suite, 7 equivalent (fingerprint unchanged over the widened probe grid, negatives
included), 1 oracle blind spot found and fixed along the way, **6 survivors**. Recall:
**6/6 = 1.0** — every surviving mutant caught, every catching finding filed
`confidence: proven`, and each one names the exact boundary the mutant moved (`price <= 0`
rejecting zero against spec rules 1 and 5; the `$75` free-shipping threshold turned
exclusive; the `2 kg` boundary turned exclusive; the `< $1` constant).

The 41 findings beyond the planted defects were adjudicated by hand and are **not false
positives**: they are the fixture's own deliberate test gaps, independently rediscovered —
"the 2 kg boundary is unasserted", "the $75 threshold is untested", "qty = 9 unasserted",
plus genuinely sharp observations (the rounding test uses `0.125`, the one binary-exact
input, so it cannot detect representation drift; `bulk_unit_price` accepts negatives that
rule 5 forbids; rules 6 and 7 never define whether express doubles a $0 charge). The
survivors exist *because* those boundaries are untested, and the tester reported both the
defect and the gap that hides it.

Caveats, stated rather than buried: n=6, one small module, one model, and every survivor
was a boundary-class mutant — the exact species spec-vs-code reading is best at. The
arithmetic and condition mutants were all killed by the suite, so this run says nothing
about recall on classes a suite tends to miss differently. Widening the survivor
population (more modules, other languages, subtler operators) is what makes the number
harder to earn.

**Re-counted 2026-09-17, and it moved.** Taking the announcement out of the module
(Fixture hygiene) also takes out the one mutant those five docstring lines produced — the
asterisk in `*correct*`, rewritten to a slash — so the census goes from 33 mutants to 32
and from one equivalent mutant to none; the eleven survivors are the same eleven,
renumbered. Neither count is the 21 / 7 / 6 above. Run today with the same operators and
the same probe (`python3 eval/mutate.py`, free): **33 → 21 killed / 1 equivalent / 11
survivors** before the change, **32 → 21 / 0 / 11** after. The five survivors August did
not have are `is_listable`'s negative-price guard deleted outright, and four that change
only the text of an error message — which the probe sees, because it records the message.
Why the August census split them 7 / 6 was not chased here: that row stands as measured on
the day, over the six mutants it names.

### Suite fault-detection power — mutation testing, on ourselves

§11 tells every project "a suite that always passes may be testing nothing — measure it."
Measured on our own suite (2026-08-28, `mutmut 2.5`, scratch copy, full-suite runner):
**1275 mutants over the guards, scorer, gate, state, and server — kill rate 61.9% on
first measurement, 66.4% after one hardening pass** (+44 targeted tests, 110 → 154).

| File | First run | After hardening |
|---|---|---|
| hooks/enforce_bash_scope.py (security control) | 57% | **77%** — the survivors were untested `_MUTATORS`/`_GIT_MUTATORS` constants, i.e. *commands whose denial nothing checked*; the deny matrix now enumerates all of them |
| src/verdict_mcp/gate.py | 46% | 53% overall; `evaluate()` — the exit-code contract — halved its survivors (45 → 21) via exact-boundary tests (`run_number == N` passes, only `<` is stale; unparseable timestamps; the unknown-verdict → 4 path; stale-beats-blocked precedence). 121 of the 163 remaining survivors are message-text mutants in formatters — prose, acknowledged as low-value |
| hooks/qa_paths.py · project_key.py · enforce_write_scope.py | 93% · 87% · 70% | unchanged this pass |
| eval/score.py · server.py · state.py | 74% · 67% · 59% | unchanged this pass — next hardening targets |

Reproduce: copy the tree, `pip install -e . pytest "mutmut>=2.5,<3"`, then
`mutmut run --paths-to-mutate <files> --runner "python -m pytest -x -q tests/ --deselect
tests/test_pin_check.py::test_every_catalogue_anchor_matches_exactly_once"`. That test
checks the pinned catalogue's anchors against the tree, so it fails under any mutant of an
anchored line and would score it killed; it did not exist when the numbers above were
measured. Not a CI job — it takes an hour; it is a periodic exam, and the numbers go here,
misses included.

### The other mutation question: is a rule we fixed actually pinned?

`mutmut` enumerates mutants mechanically and asks what the suite misses at large.
[`eval/pin_check.py`](pin_check.py) asks something narrower and more accountable: take a
rule this project claims to have fixed, put the defect back, and does the suite notice?

It exists because a published number was wrong. v0.74.0's changelog said "21 mutants, 21
killed"; the run that audited it found that every mutant had been run against **one
hand-named test**, chosen from the same reading of the same finding — and that the scripts
were never committed, so nobody could reproduce the figure. Re-run against the whole suite
the catalogue was **27 of 29**, and both survivors were real: a README assertion that
matched a digit inside a parenthetical rather than the claim, and the only call site of
`_drop_bytecode`, whose deletion left every test passing because the mutant that "killed"
it had changed the function's *body*.

It runs in a **scratch copy of the working tree** — tracked and untracked-but-not-ignored
files, so what is about to be committed is what gets measured — with the copy's `src/`
ahead of the editable install, and it refuses to run until `import verdict_mcp` inside the
copy resolves to the copy. That is run 14's independent runner, adopted: the first design
mutated the real files under a lock, and it cost twice (a second instance read a failure
the first had caused; an interrupted run left `harness.py` 2286 lines shorter). `--in-tree`
keeps the old mode.

[`eval/sweep.py`](sweep.py) asks the question the catalogue cannot: **every** mutant
inside a named function, enumerated by `eval/mutate.py`'s operators over the lines `ast`
says the function owns, each run against the whole suite in the same scratch copy. The
catalogue's denominator is a list somebody wrote (VERDICT-F-65); the sweep's is the code.
Its default scope is harness.py's dialect table and judgment-adjacent functions plus
`state.outcome_row` — 155 mutants over 417 lines. Survivors are candidates, not
convictions: drive the original and the mutant side by side over the input space before
writing a test, because a real gap and an equivalent mutant print the same `SURVIVED`.
(mutmut over the same scope enumerated 3,638 mutants, ran 37, and hung on its own cache.)

**First sweep, 2026-09-06 (0.80.2, 155 mutants over 417 lines): 121 killed, 34 survived.**
The full record, one row per mutant with its outcome and seconds, is [`sweeps/2026-09-06-f65.json`](sweeps/2026-09-06-f65.json).
Judged one at a time by driving the original and the mutant over the input space:

| Survivors | Verdict | What happened |
|---|---|---|
| 9 in `duration_regressed` (lines 213–222) | **real** | every boundary of the gate — the minimum history, a zero median, both inclusive bars, the factor's operator, a non-numeric duration (`None >= float` raised and nothing noticed). A parametrized boundary table now names each point; three pinned (S1–S3). |
| `_ago`: `minutes < 1` → `<= 1` | **real** (VERDICT-F-60's survivor 8) | one minute read as "seconds ago". Pinned (S4). |
| `select_test`: `==` → `!=` on a resolved citation | **real** | every explicit citation in the suite was spelled exactly as collected, so resolution never decided anything. Pinned (S5). |
| `verify_findings`: `finally: if scratch is not None` → `if False` | **real** | the counterfactual worktree was never removed and no test looked. Pinned (S6). |
| 8 note guards in `verify_findings` (`if uncited`, `if unresolved`, `if unselectable`, `if scratch is None`, `if previous_sha`, `uncited = 0`, the cap's `>`) | **real** | six notes could be emitted unconditionally — "0 findings cite no test", "nothing was run for :" — because no test asserted their absence. A clean run now asserts `verification_notes == []`; the cap's exact boundary and the uncited count are asserted. One pinned (S7). |
| `_apply_verification`: `if resolving` / `if "carried_forward" in entry` → `if True` | **real** | an open, still-failing finding was stamped "resolution refused" and "carried forward". Asserted. |
| vitest `failed` pattern `.*?` → `./?` | **real** (fixed in #110) | every row had a one-digit count; `Tests  12 failed` read as 2. |
| `test_copied_from_head` flag set unconditionally | **test was vacuous** | the test that guards it cited its test in prose, so after F-26 nothing ran and the assertion held on nothing. It declares its citation now. |
| `if counts:` → `if True:` in `_counts` | equivalent | every dialect signature implies at least one field, by construction of the table. |
| `if not cited` / `if not runnable` early returns; `differs`/`insert` on the summary; "and N more" at exactly 5 | equivalent or cosmetic | no observable difference in results, or a message with " and 0 more" that needs five unresolved citations to see. Not pinned; listed so nobody re-derives them. |
| `run_date`: `if when.tzinfo is not None` → `if True` | **unpinned** | the mutant reads a naive stamp as local time; on a UTC machine (CI) the two agree, so a test could only fail where nobody runs it. |
| a line inside `_stamp_outcome`'s docstring | noise | prose does not run; the sweep skips docstrings now. |

Each mutant lands in one of three columns, read off pytest's own summary line rather
than its exit code: **KILLED** (a test failed), **SURVIVED** (the suite stayed green), or
**ERROR** — pytest exited without a failed test, which is a broken collection or a usage
error, not a defended rule. Run 12 found the tool reading any non-zero exit as a kill
(VERDICT-F-68); an ERROR now sits outside the denominator and fails the run, because a
number that quietly counted it would be the wrong number.

| enumerated from | mutants | killed |
|---|---|---|
| the tests (v0.74.0, as published) | 21 | 21, each against one named test |
| — re-run against the whole suite | 29 | **27** |
| the fix list (v0.75.0) | 32 | **32** |
| **the code (v0.76.0)** | **46** | **45 of 45, 1 equivalent** |
| the fix list (v0.77.0–v0.79.0) | +31 | all killed |
| **the code (v0.80.0)** | **+18** | see below |

**What the number is a rate over.** A kill rate means nothing without its
denominator, and this one's denominator is a list somebody wrote. Enumerating
from the fix list — which is what every release between the code-enumerated
passes did — can only pin rules somebody already thought about, so the
catalogue says which files have had a line-by-line pass and which have not:

| Enumerated from the code | Files |
|---|---|
| yes | `hooks/enforce_bash_scope.py`'s tar handler (v0.76.0) · `hooks/qa_paths.py` and the run clock, `run_date` / `_ago` (v0.80.0) |
| no — fix list only | `src/verdict_mcp/harness.py` outside the clock · `state.py` · `validate.py` · `gate.py` · `server.py` · `issues.py` · `accept.py` · the rest of the bash guard |

The v0.80.0 pass is what a code-enumerated sweep is for: five rules run 13 had
re-measured as unwatched, none of them in the catalogue, all reachable by
reading `qa_paths.py` and the clock line by line. Two of the five turned out to
be **equivalent mutants** and are marked as such rather than scored — the
`errors="replace"` argument cannot change what these guards emit, because every
character in their messages is UTF-8-encodable, and translating a trailing `Z`
to `""` instead of `"+00:00"` produced an identical date on every stamp tried.
The finding that named them (VERDICT-F-60) had asserted the second one changed
behaviour; it does not, and saying so is cheaper than carrying a test that
cannot fail.

**Where the mutants come from decides what the number means.** Run 12 made the
point with one fact: the v0.75.0 catalogue scored **killed** on the entry *"tar
operands stop being read relative to `-C`"* — a perfect mark on a rule the same
run proved bypassable five ways. Mutation testing answers *would a test notice if
this line changed*; it never answers *is this line right*. A catalogue drawn from
the fix list inherits the fix's blind spots, exactly as a test written from a
finding's own sentence does.

v0.76.0 enumerated by reading `_tar_parse` and `_check_tar` line by line — every
branch, every operator, sixteen mutants. Five survived the first pass and four
were real gaps: `--` ending the option list, a long option's separate value read
as a deletion target, `-c --remove-files -f` swallowing the flag, and extraction
reporting the shell's cwd instead of `-C`. It also flagged three existing entries
as **stale** against the rewritten handler rather than passing them silently,
which is the behaviour a catalogue-as-data buys you.

The fifth survivor is a genuine **equivalent mutant** and is marked so in the
catalogue: a bare `-` either yields no operand or yields one `_target_ok` waves
through as a flag — the verdict is the same either way. Equivalents are reported
and excluded from the denominator, because scoring a question with no answer only
pressures someone into writing a test that cannot fail.

The catalogue is [`eval/pinned_mutants.json`](pinned_mutants.json) — data, beside the number
it supports. It carries a class the hand-written scripts never had: mutants that delete a
**call site** while leaving the code correct, because "the code is right" and "the code
runs" are different claims and only the first was ever being tested.

**Four anchors went stale, and the badge went on counting them (fixed 2026-09-17).** A
mutant is applied by exact replacement, and an `old` text that does not occur exactly once
is reported STALE and scored as a survivor. Four scored entries lost their anchors and
stayed lost through 0.89.0: T02 matched twice once `_git_operands` repeated the tar
parser's `--` line (0.80.0); 0.78.0 R2 matched nothing once the call beside the fold gained
`measured_at` (0.83.0); 0.78.0 R5 and 0.79.0 S7 matched nothing once the finding checks
moved into `validate_finding`, one indent shallower (0.84.0). The equivalent T08 went
ambiguous with T02. No published run reported them, because each release measured its own
entries with `--filter`. Meanwhile the badge, which a test ties to the catalogue's *size*
rather than to a run, went on saying N/N: no full `pin_check` on any tree from 0.80.0 to
0.89.0 could have produced that number. 0.89.0 found them by checking every anchor while
adding its own mutants, and `git log -S` on each old anchor named the change that moved it.

Each entry is re-anchored on the code its rule lives in now, changing only the text that
moved, and re-measured against the whole suite — 1,244 tests per mutant in a scratch copy,
green control before each run: **T02 killed · 0.78.0 R1–R15 killed, R2 and R5 among them ·
0.79.0 S7 killed**, and T08 survives, the equivalent it is marked. `tests/test_pin_check.py`
now counts every anchor on every run of the suite, so the edit that moves an anchored line
is the edit that goes red; against the catalogue as it stood, that test fails and names
exactly those five entries.

It is also the one test a campaign must not run. Applying a mutant takes its own anchor out
of the tree — 184 of today's 191 entries — so inside a mutant it goes red for the tree
having moved rather than for the rule, and `classify` reads that failure as a kill.
Measured: with the anchor test in the suite, **T08 — an equivalent mutant no test can tell
apart — scores KILLED**. `pin_check.SUITE` deselects it and `eval/sweep.py` shares that
command; pytest says nothing about a deselect that matches nothing, so the node id is tied
to the test function by a test of its own, and the rule is pinned as **A1** (killed). That
is the 189th scored entry, and why the badge reads 189 rather than 188. What has still not
happened is a full catalogue run: 19 mutants were measured here, not 189.

v0.90.0 added eighteen (P1–P18) for the local tier, and they are the shape a safety rule
wants: each one puts back a defect whose symptom is *silence*. A drifted finding carried
instead of re-filed; an unmentioned finding left to the merge's silence rule; a resolution on
a test that merely passes at HEAD; a verdict computed from this run's findings alone, so a
`fail` or a `blocked` can improve on its own; the previous quarantine or `verified_intact` wiped; a run with
no answers finalizing anyway; a liveliness probe that always says alive; a quarantine released
on its expiry date alone; `--on-drift local` falling through to a Claude run; a sweep dropping
`verified_intact`; the report omitting its Judge line; a range run falling back to the reading
map; `--range` without `--qa-root` writing the key's own state root; a non-Python diff
finalizing an unqualified pass; `needs_claude` dropping the changed lines nothing executed; the
reference state opened for writing. None of those turns the suite red on its own — which is
exactly why each one is in the catalogue.

Twenty more (P19–P38) came from measuring the tier rather than reading it: the proofs on the
seeded fixture (a red suite under-rated, a regression filed as news, a duplicate of an open
finding) and the shadow runs on the author's own Sales project (an inherited class conflict
refused instead of asked, a night with no budget, unproven readings filed as findings, proofs
imported from the wrong root, one identity filed twice in a night, and — found by replaying the
first night's output through finalize — the same identity filed again on the second night,
which would have lost every night after the first). 38 in all for the tier.

**P4 survived its first campaign, and that is the tool earning its keep.** The rule is "a
standing verdict may not improve"; the test asserted a standing `fail` beside *nothing filed*,
which is a case the rule never has to fire on, so deleting the rule changed nothing the suite
could see. The missing case — a standing `fail` beside a finding this run filed itself — is
pinned now, and reading the survivor is what found the same hole on the `blocked` side, which
is worse: it turns the gate's exit 3 into exit 0. That is P18.

### Scoring the local engine — `run_eval.py --engine local`

`--engine local` runs the `pricer` fixture through `verdict-local` instead of a `claude -p`
session, scored by the same answer key. The question it has to survive is not "does it find as
much" — it will not, and the report says so in numbers — but the hard gate: **zero false
greens.** No `pass` where the key says `fail`, and nothing marked RESOLVED without a
verification record. Its deterministic rows (the still-open floor, still-open by id, findings
filed as files, questions not re-asked, the verdict, quarantine released on expiry) should be
3/3; the model rows are a small model's, and are published as whatever they are. The wiring has
an injectable engine, so the protocol is a unit test rather than something only a gateway can
check.

### Variance — a score is n=1 until repeated

`run_eval.py --repeat N` runs a protocol N times in fresh workdirs. First measured series
(2026-08-28, Sonnet, v0.11 prompt), **published after adjudication of every miss**:

| Protocol | Per-run | Verdict |
|---|---|---|
| pricer baseline ×3 | 8/8 · 8/8 · 8/8 | **stable** — one run was initially zeroed by scorer FP #3 (a `.coverage` byproduct flagged as fixture modification); rehabilitated by re-scoring the preserved workdir |
| pricer delta ×3 | 6/6 · 6/6 · **5/6** | **not clean** — one run was initially zeroed by scorer FP #4 (multi-line entry format tripped the ranking anchor; the report ranked REGRESSED first correctly) and was rehabilitated; but run 3's miss is real: the expired quarantine was re-evaluated and correctly diagnosed, yet left in the ledger as "recommend lift" instead of released. §6 now says it plainly: re-evaluation on expiry is an action, not an opinion. |

Consequence, applied the same day: **the nightly reverted from Sonnet to Opus.** Sonnet's
baseline is provably stable; its delta discipline is 2-of-3. Re-promotion requires a clean
delta ×3 on the sharpened prompt — the ledger, not the mood, decides.

**Revalidation ×3 (same day, sharpened prompt): 6/6 · 0/6 · 6/6 — demotion stands.** The
miss is real and is a *recurrence of Sonnet's signature violation*: the state's report
field reads `"inline to caller (no report file written per caller instruction)"` — no such
instruction existed. Across both delta series Sonnet is 4-of-6; baseline remains 4×8/8.
The pattern is mode-specific artifact discipline, not competence. §7 now names the dodge
verbatim; that hardening rides the next scheduled eval series rather than burning three
more runs today. Opus holds the night shift.

### When a row misses, suspect the scorer first

Twice now a red row has been the *key's* fault, not the agent's: the REGRESSED-first check
once anchored on narrative prose above the findings list, and the brittle-assertion row
once matched only a test-function name. Both times the agent was right. So the protocol
when a row misses: open the state file, find whether the finding is present and correctly
classified, and only then decide who failed. Re-scoring a preserved workdir costs nothing
— `run_eval.py` keeps it on any failure precisely for this.

### A vocabulary that stopped being reliable (open, measured 2026-09-03)

The 2026-09-03 cause series found a row that had quietly stopped holding:
`trigger-separated-from-cause` requires the report to use the word **trigger**, and it
misses **2 of 3 treatment runs and 2 of 4 control runs** — the v0.74.0 prompt and the
byte-identical v0.73.0 control fail it at a comparable rate, so this release did not cause
it.

What the missing runs actually do is build the chain `/cause` asks for in step 3 —
symptom → mechanism → **origin** → class — and then answer step 5's substance without its
vocabulary: they name the memoize commit a red herring and observe that the failing test is
younger than the defect it exposes, which *is* separating the trigger from the cause. They
never say the word.

It was last measured at **6/6, n=1, on 2026-08-29**, against a 566-line prompt and a command
file that no longer exists (`commands/qa-cause.md`, rewritten as `commands/cause.md` in
v0.39.0). Today's prompt is 791 lines. One reading, four days and 225 lines ago, never
established that the row was reliable — so this is a **measured weakness, not a demonstrated
regression**, the same reading this file already applies to the liar fixture's Blocker row.

Deliberately **not** amended away. The key is right that the three things need separating by
name; the runs are right about the substance. Either move is a prompt change, and a prompt
change is eval-paid — so it is filed for the next run rather than smuggled into the release
that found it.

### Fixture hygiene — the checkout stopped announcing itself (2026-09-17)

Every fixture README carried a line like this one, from `fixtures/liar/README.md`:

> It intentionally contains seeded defects — see `../../expected-liar.json` for the answer
> key (do not read it during an eval run).

The key itself was never copied into the checkout and could not be read. The sentence was
enough. In a paid Opus run on 2026-09-17 the outer session wrote: *"the agent noticed an
answer key at `../../expected-liar.json`. So the defects are planted fixtures, not a real
product regression — which bears directly on its LIAR-Q-1 and LIAR-Q-2."* What a tester
does with that knowledge cannot be read off one run, and that is exactly the problem: a
tester that knows it is being graded on seeded defects is not the tester a user gets, and
not the one these rows claim to measure.

It was never only the READMEs. Everything the harness handed over said the same thing:

- **Seven fixture READMEs** (and the spec fixture's `SPEC.md`) named the eval, the seeded
  defects and the key. Gone. The requirement spec they also carry — which is what the
  defects are defects *against* — is untouched, so the puzzle is the same one.
- **`fixtures/golden/`**, planted in the seeded mode as the tester's own memory of the
  project, listed under *Forbidden* in its own profile: "Reading `eval/EXPECTED*.md` or
  `eval/expected*.json` anywhere on disk — answer keys". Its run-2 report opened with
  "Golden-history stub: this file exists so run history is navigable during the delta
  eval". A profile that names the keys is a map to them.
- **`fixtures/pricer_clean/`**, the mutation base, was the loudest: its module docstring
  said it "exists to be broken one line at a time by `eval/mutate.py`, so that recall can
  be measured", its suite's docstring said the gaps "are the point — a mutant the suite
  fails to kill is exactly the defect a tester has to find", and `run_mutation.py` copied
  `probe.py`, the census's behavioural oracle, into the checkout beside them. The recall
  number in "Recall — what the tester *misses*" was measured on a module that told its
  tester it had been broken on purpose.
- **`git log`.** Every commit was authored by `verdict-eval <eval@verdict>`; every
  single-commit fixture opened with "fixture rev A", and the delta fixture's second commit
  was "fixture rev B". Not hypothetical: the
  archived corpus has testers quoting both back ("HEAD is 'fixture rev A'", "commit
  5a1184b \"fixture rev B\""). The identity is a plain maintainer now and the messages say
  nothing the tree does not.
- **The paths.** The workdir was `verdict-eval-XXXXXXXX/`, so the checkout, the QA home
  and every absolute path a finding cited named the eval; the mutation workdir added the
  mutant's own id (`verdict-mut-M03-`). And the checkout's directory name becomes the
  project key, so `liar/` and `slop/` stamped `LIAR-F-…` and `SLOP-F-…` on every finding
  filed — the ids the contaminated run quoted. They are `qstats/` and `syncbay/` now, the
  names their own READMEs use, and the scratch directory is named by the platform.
- **The copy.** `shutil.copytree` copied the maintainer's working directory as it lay. In
  the author's checkout that meant `fixtures/pricer/.pytest_cache/v/cache/lastfailed`,
  which names the four red tests, and `fixtures/pricer_clean/__pycache__/pricer.pyc`,
  which still carries the docstring quoted above — both committed into the tester's own
  first commit. A fixture is now copied as git sees it: tracked files, plus untracked ones
  `.gitignore` does not exclude, which is the definition
  [`fixture_freshness.py`](fixture_freshness.py) already uses.

**Enforced, not merely done.** [`tests/test_fixture_hygiene.py`](../tests/test_fixture_hygiene.py)
builds every checkout the harness builds — each fixture, the golden state, rev B, and a
mutation run's — with no model and no tokens, then reads what the tester would: every line
any commit ever added, every file name, every commit message and identity, the planted QA
state, and the directory names themselves. Words that genuinely belong to the fictional
project are allowlisted one at a time with the reason, and an allowlist entry that stops
matching fails the suite. Each of the seven giveaways above was put back and watched go
red before this was trusted.

**What this does not close**, stated rather than buried:

- The checkout is still a one- or three-commit repository in a temp directory, which is not
  what a real project looks like.
- `.claude/agents/verdict-rc.md` and `.claude/settings.json` are provisioned into it with
  `${CLAUDE_PLUGIN_ROOT}` resolved, so a tester can read this repository's absolute path,
  and `eval/` is under it. Nothing in the checkout points there any more, but a tester that
  goes looking can still find the keys. Closing it means provisioning from a copy of the
  plugin root with `eval/` removed — a change to what the run exercises, not made here.
- The agent is provisioned as `verdict-rc`, so the tester can tell it is a release
  candidate of itself.
- [`swebench.py`](swebench.py) builds the external key's checkouts under
  `~/.cache/verdict-swebench/work/<instance id>/`, which names the benchmark and the
  instance to anyone who reads `pwd`. Same class of leak, different harness; not audited
  here.

**Comparability.** Every published row measured against a fixture in `eval/fixtures/` —
the whole results table, and the recall run — was measured with the giveaway present.
Rows measured after 2026-09-17 are therefore **not strictly comparable** with them: the
instrument changed, in the direction of the conditions a user's repository actually has.
Which way the scores move is not predicted here and nothing is re-run: a re-measurement is
model spend, and that is the owner's call.

### Answer-key amendments

- **2026-09-16, `expected-cause.json`: `cause-truncation-in-to-cents` and
  `class-other-truncation-sites` share a `class_of`.** The same instrument shape as the liar
  amendment below, found nine days later on the fixture next door. The two rows describe one
  class, and since 0.84.0 a run may file only one finding for it — `finalize` refuses a second
  finding that cites a line the first lists under `root_cause.class.sites`. The maximum matching
  gave that one finding to the first row, so the second row could only be earned by some *other*
  finding that happened to contain one of its terms, and the term that does it is the bare word
  `invoice`: a test-gap finding ("invoice and report tests use only whole-cent data") earns the
  row without saying anything about the class. That row is the whole of the published
  Opus-against-Sonnet gap in "The model axis" (3 of 3 against 0 of 2), and the workdirs of that
  pairing no longer exist, so whether the gap was the model or the wording is **not known** — it
  is re-measured by the next paired payment, with `class-not-split` (the sites recorded, in one
  finding, across both files) as the row that reads the state rather than the words. Proven not
  to lower the bar: the archived corpus run scores 7/7 before and after with the same
  row-to-finding mapping, and `test_the_cause_keys_two_truncation_rows_are_one_class` scores a
  finding that never looks past the failing site at one row, not two — and fails on the
  unamended key.

- **2026-09-07, `expected-liar.json`: `mock-asserting-test` and `tautological-assertion` share a
  `class_of`.** The 0.84.0 contract files one finding per class, and the payment run reported the
  two tests that cannot fail as two sites of one finding. The scorer's maximum matching exists to
  stop one finding claiming two *unrelated* rows (the F-50 liar scar); rows that declare the same
  `class_of` now accept a finding another row of that class owns, when it matches. Two findings
  still earn the rows separately. The run scored 5/6 before, with the note "every text match was
  already credited to another row" — the instrument's shape, not the tester's miss; 6/6 after.

- **2026-09-07, `expected-cause.json`: `decoy-cache-not-blamed` loses the bare phrase
  `root cause: the test`.** It matched the report renderer's own "- Root cause: <mechanism>" line
  of an unrelated environment finding whose mechanism began "the test dependency (pytest) is
  declared nowhere", so a run that had examined and cleared the decoy read as blaming it (scorer
  FP #6). The phrase now needs the test *change* or the test *data* named, which is what the row
  was written to catch. Re-scored: 9/10 → 10/10 on the run it hit.

- **2026-09-06, `expected-cause.json`: `instrument-control-restores-the-original` — added,
  measured 0 of 2, removed the same day.** It scored the 0.81.0 §3 clause (VERDICT-F-58): the
  stale-bytecode control is a *restore*. Two treatment runs did the isolation (`counterfactual-
  isolated-from-stale-bytecode` 2/2), ran clean controls (one as "ARM 0 clean scratch", one as
  "instrument control armC: untouched source, fresh dir") and never *restored* a mutated scratch
  — because the fixture has no same-scratch re-injection sequence, so the restore is never
  needed. A row no run on this fixture can earn measures the fixture, not the prompt; it is out
  of the key until a fixture with the F-50 ordering exists (a delta with two same-size
  re-injections). The clause ships measured as harmless, not as an improvement.

- **2026-09-03, cause row 7 (new):** `counterfactual-isolated-from-stale-bytecode` added
  alongside the v0.74.0 contract clause it scores, because VERDICT-F-52 established that no
  fixture could tell one version of this contract from another — the complaint was never the
  score, it was that the instrument was blind. Terms come from the clause, not from any run's
  phrasing. **Its own first draft was wrong and a control caught it:** the draft accepted the
  bare string `__pycache__`, and a control run that practised none of the discipline earned
  the row for the sentence "clean apart from `__pycache__`". Naming the directory while
  reporting the checkout untouched is housekeeping. As scored now the row separates the arms
  completely (0 of 4 control runs, 3 of 3 treatment).
- **2026-08-27, baseline row 5:** originally required `FLAKY` + quarantine. A run that
  *diagnoses* the nondeterminism (time-seeded input) and files it as `BRITTLE_TEST` with a
  test-fix task now also scores — §3 was sharpened to define `FLAKY` as *undiagnosed*
  intermittence, and forcing a diagnosed mechanism into quarantine theater would be wrong.
  Amendments are listed here permanently; a key that changes silently is itself a
  quarantine graveyard.
- **2026-08-28, baseline row 6:** matcher broadened from the bare test-function name to
  the concept (`error message`, `message string`, the pinned string itself). A live-mode
  run had reported the finding correctly and still scored the row red — the key, not the
  run, was wrong.
- **2026-08-28, fixture-integrity check (FP #3):** tool byproducts — `.coverage`,
  `coverage.xml`, `htmlcov/`, linter caches — no longer count as fixture modification;
  measuring the code under test is not modifying it.
- **2026-08-28, REGRESSED-first anchor (FP #4):** entries that split the id and the delta
  tag across lines (id in a heading, `Delta: **REGRESSED**` below) are now recognized —
  the anchor scans a small window after each id line within the findings section. A run
  that ranked REGRESSED first correctly had been zeroed for its formatting.

### Beyond the key (2026-08-25 run)

Three real issues the answer key did not seed — future runs may legitimately report them
too; they don't count for or against the score:

- `bulk_unit_price` accepts negative prices/quantities while spec rule 5 requires rejection
  (inconsistent guards across the public surface).
- `test_bulk_orders_fixture`'s assertion (`result <= price`) is tautological — true by
  construction, so restoring the missing fixture alone would buy no signal.
- The README's documented run command (`python3 -m pytest`) fails on a machine with no
  project environment definition — the suite isn't reproducible as documented.

Honesty rule: results are published as measured. A missed row stays in the table — a QA
agent that hides its own misses has failed the eval regardless of score.
