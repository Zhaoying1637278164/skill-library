---
gates:
  suite: uv run --group dev python -m pytest tests/
  fixture_freshness: python3 eval/fixture_freshness.py
test_ids_cmd: uv run --group dev python -m pytest tests/ --collect-only -q -o addopts=
test_one_cmd: uv run --group dev python -m pytest {id} -q -p no:cacheprovider -o addopts=
coverage_suite_cmd: uv run --group dev python -m coverage run -m pytest tests/ -q -o addopts=
---

# QA profile — verdict

Project-Key: verdict
Repo-Path: /Users/artjack/Projects/verdict
Repo-Remote: https://github.com/ArtJack/verdict
Mode: team (.qa/ committed with the repo)
Security-Pass: disabled
Created: 2026-08-28

## What this project is

The Verdict Claude Code plugin plus the `verdict-mcp` Python package (v0.12.0):

- `agents/verdict.md` — the QA agent's behaviour contract (the product).
- `hooks/` — `enforce_write_scope.py`, `enforce_bash_scope.py`, shared `qa_paths.py`.
  These are a **security control**: they are what makes "Verdict never patches your code"
  a guarantee rather than a promise.
- `src/verdict_mcp/` — read-only MCP server (`server.py`), CI gate (`gate.py`),
  project-key resolution (`project_key.py`), state IO (`state.py`).
- `eval/` — scorer (`score.py`), answer keys (`expected*.json`), regression corpus, and
  fixtures containing **intentionally seeded defects**.
- `action.yml` — the GitHub Action (gate mode, and experimental run mode).

## What it touches

No database, no network calls, no third-party accounts, no user data. It reads and writes
QA state under a `.qa/` directory or `$VERDICT_HOME`. The only privileged surfaces are:
the Action's `run` mode (installs npm packages, uses an API key, may commit `.qa/`), and
the hooks, which decide whether another agent's write is permitted.

## Isolation check

Pass when all three hold:

1. No network/DB/credential usage in the suite:
   `grep -rlE "requests\.|httpx|urlopen|boto3|psycopg|DATABASE_URL" tests/ src/` → no matches.
2. `pyproject.toml` has `testpaths = ["tests"]` — the seeded-defect fixtures under
   `eval/fixtures/` must never be collected by the project suite.
3. The suite writes only to pytest `tmp_path` and to hook-guarded QA roots.

## Standing decision — the Bash guard is a cost-raiser, not a sandbox (2026-09-05)

Read this before rating a finding against `hooks/enforce_bash_scope.py`. The README
already states it, DECISIONS.md records it, and runs 8 through 14 spent most of seven
releases on it: the guard is a deny-heuristic over a command string. A determined
invocation can get past it, and the OS is the real boundary. So:

- A **new spelling or argument order** of an already-modelled command family (`tar`,
  `git`, `find`, `sed`, wrappers) that the guard mis-reads is **Minor** by policy, not a
  release blocker, unless it also defeats one of the *structural* controls (the file tools
  having no `Edit`, the write-scope hook, the maintainer's ledger being refused to the
  tester). File it; do not block a release on it; do not put it first in
  `next_run_focus`.
- A **whole command family** the guard does not model at all, or a way to disarm the
  guard's decision as such (a token in the wrong role standing the whole check down, as
  VERDICT-F-75 did), is still rated on its merits.
- The releases that model each family "measured before modelled" are the right way to
  close such a finding when one is taken up. They are not owed one per run.

This is the maintainer's call, recorded so the tester stops re-litigating it and the
project stops shipping a release per spelling.

## Forbidden commands

- No `git commit`, `git push`, `git checkout`, `git stash`, or any checkout mutation.
  QA reports; QA does not fix and does not commit. Committing `.qa/` is the maintainer's act.
- Never regenerate or "fix" `eval/fixtures/pricer-delta.diff`, the answer keys
  (`eval/expected*.json`), or the corpus. They are tamper-evidence and trust anchors.
- Never modify, skip, or xfail a test to make a gate green.
- Never `npm install -g` or run the Action's `run` mode locally — it uses
  `--dangerously-skip-permissions`.

## Real commands (from .github/workflows/ci.yml)

- Suite gate: `uv run --group dev python -m pytest tests/ -q`
  (CI matrix: ubuntu + windows x py3.10 + py3.13)
- **For counting**, use `uv run --group dev python -m pytest tests/` — the CI form yields
  `-qq` (see finding VERDICT-F-3) and prints no summary line.
- Test-ID collection: `uv run --group dev python -m pytest tests/ --collect-only -q -o addopts=`
- Fixture freshness gate: from `eval/fixtures/`,
  `git diff --no-index pricer pricer_rev_b > /tmp/fresh.diff || true; cmp pricer-delta.diff /tmp/fresh.diff`
- Self-gate: `verdict-gate .` (the repo gates itself via `.github/workflows/qa-gate.yml`,
  `max-age-hours: 240`).
- Changed-files coverage: `uv run --group dev python -m coverage run -m pytest tests/ -q -o addopts=`,
  named as `coverage_suite_cmd` in the front matter above and run by `verdict-facts` itself
  — the diff-coverage block in `state.json` is its output, not a declaration. Run 7 measured
  122 of 143 changed lines with it.
- Mutation testing: `mutmut` is in the dev group. First campaign run 2026-09-02 over
  `src/verdict_mcp/validate.py`: 574 mutants, 335 killed by `tests/test_validate.py` alone;
  of the 239 survivors, 186 only rewrite a message string and 53 change an operator,
  boundary or guard. Those 53 were re-checked against the whole suite one at a time — the
  only honest way to read a scoped run — and the gap they showed was that
  `validate_judgment`'s rules were unpinned while `validate`'s twins were. Closed across
  0.67.0, 0.69.0 and 0.72.0. Run 9 re-measured with the same tool and scope: 391 killed
  against the original 335, +56. Of its 9 non-string survivors, 2 died against the whole
  suite, 2 are the clock tolerances accepted as equivalent (one second apart), and **5 were
  real and unwatched** — the judgment validator's `status` enum, two loop `continue`s, and
  both PostToolUse hook exit codes. Closed in 0.72.0. The earlier summary here said the
  residual was "mostly message text", which understated it in the direction that flatters
  (VERDICT-F-48). **Re-run before trusting the number**: control the harness first by
  applying a mutant the tool reports as killed and confirming the suite fails.

## Known risk areas (weight effort here)

1. **Scope-guard hooks** — a bypass silently removes the product's core safety guarantee.
2. **Agent prompt** (`agents/verdict.md`) — the behaviour contract; regressions here are
   only visible through the eval corpus, not the unit suite.
3. **Scorer and answer keys** — if the scorer is wrong, every eval score is wrong.
4. **Gate exit codes** — a CI contract consumed by other repos; 0/1/3/4/5 are load-bearing.
5. **Cross-platform** — Windows is in the CI matrix but is not testable on this machine.

## Needs human decision

- Whether `.qa/` gets committed (required for the self-gate to work — VERDICT-F-2).
- Whether to add a coverage tool, and the changed-files coverage command if so.
- Risk acceptance for the Action's `run` mode (`--dangerously-skip-permissions` + bot commit).
