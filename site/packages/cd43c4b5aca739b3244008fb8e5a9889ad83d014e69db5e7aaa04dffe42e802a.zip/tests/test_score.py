"""Unit tests for eval/score.py — the scorer is code and gets tested like code."""

import json
import subprocess
import sys
from pathlib import Path

EVAL = Path(__file__).resolve().parent.parent / "eval"
SCORE = EVAL / "score.py"
EXPECTED = EVAL / "expected.json"


def _finding(fid, title, cls, evidence, sev="Major"):
    return {
        "id": fid, "hash": fid.lower(), "first_seen": "2026-08-27", "status": "open",
        "delta": "NEW", "age_days": 0, "title": title, "severity": sev,
        "priority": "P1", "failure_classification": cls, "evidence": evidence,
    }


def perfect_state():
    return {
        "project": "pricer", "schema_version": 1, "run_type": "baseline",
        "run_number": 1,
        "last_run": {"timestamp_utc": "2026-08-27T20:00:00Z", "git_sha": "abc1234",
                     "sha_range": None, "report": "reports/r.md"},
        "isolation_check": {"result": "pass"},
        "gates": {"pytest": {"result": "fail", "summary": "3 failed", "exit_code": 1,
                             "duration_s": 1.2}},
        "tests": {"collected": 8, "passed": 3, "skipped": 1, "failed": 4},
        "flaky_quarantine": [{
            "test_id": "test_pricer.py::test_bulk_discount_applies",
            "first_seen": "2026-08-27", "fail_count": 3, "run_count": 6,
            "quarantined_until": "2026-09-03"}],
        "findings": [
            _finding("PRC-F-001", "is_listable rejects a price exactly at the floor",
                     "REAL_DEFECT", ["pricer.py:13 price > floor"], "Critical"),
            _finding("PRC-F-002", "round_cents uses banker's rounding",
                     "REAL_DEFECT", ["pricer.py:17"], "Critical"),
            _finding("PRC-F-003", "test_net_proceeds_hundred asserts the retired fee",
                     "STALE_EXPECTATION",
                     ["test_pricer.py:25", "CHANGELOG.md:5 PRC-142 raise intended"]),
            _finding("PRC-F-004", "test_bulk_discount_applies input is time-seeded",
                     "FLAKY", ["test_pricer.py:35 time.time_ns"]),
            _finding("PRC-F-005", "test_negative_price_message asserts exact string",
                     "BRITTLE_TEST", ["test_pricer.py:42"]),
            _finding("PRC-F-006", "test_bulk_orders_fixture needs missing fixtures/bulk_orders.json",
                     "ENVIRONMENT", ["FileNotFoundError"]),
            _finding("PRC-F-007", "boundary test skipped since 2026-05-02 with no expiry",
                     None, ["test_pricer.py:18 @pytest.mark.skip"]),
        ],
        "verdict": "fail", "release_blockers": ["PRC-F-001", "PRC-F-002"],
        "not_tested": ["concurrency"],
    }


def run_score(tmp_path, state=None, report="Scope...\nFindings, none reassuring.",
              mode=None, expected_file=EXPECTED):
    root = tmp_path / "qa"
    (root / "reports").mkdir(parents=True, exist_ok=True)
    if state is not None:
        (root / "state.json").write_text(json.dumps(state), encoding="utf-8")
    if report is not None:
        (root / "reports" / "r.md").write_text(report, encoding="utf-8")
    cmd = [sys.executable, str(SCORE), "--qa-root", str(root),
           "--expected", str(expected_file)]
    if mode:
        cmd += ["--mode", mode]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return proc.returncode, json.loads(proc.stdout)


def test_perfect_run_scores_full(tmp_path):
    rc, out = run_score(tmp_path, perfect_state())
    assert out["hard_fails"] == []
    assert (out["score"], out["max"]) == (8, 8)
    assert rc == 0


def test_diagnosed_brittle_alternative_for_row5(tmp_path):
    state = perfect_state()
    state["findings"][3]["failure_classification"] = "BRITTLE_TEST"
    state["flaky_quarantine"] = []  # diagnosed mechanism: no quarantine required
    rc, out = run_score(tmp_path, state)
    assert (out["score"], out["max"]) == (8, 8) and rc == 0


def test_flaky_without_quarantine_drops_row(tmp_path):
    state = perfect_state()
    state["flaky_quarantine"] = []
    rc, out = run_score(tmp_path, state)
    assert out["score"] == 7 and rc == 1
    row = next(r for r in out["rows"] if r["key"].startswith("5-"))
    assert row["point"] == 0 and "quarantine" in row["note"]


def test_stale_without_citation_drops_row(tmp_path):
    state = perfect_state()
    state["findings"][2]["evidence"] = ["test_pricer.py:25 assert 88 == 90"]
    rc, out = run_score(tmp_path, state)
    assert out["score"] == 7 and rc == 1


def test_missing_classification_field_scores_only_unclassified_rows(tmp_path):
    state = perfect_state()
    for f in state["findings"]:
        f.pop("failure_classification", None)
    rc, out = run_score(tmp_path, state)
    # graveyard row + verdict row survive; classification is machine-read, not prose
    assert out["score"] == 2 and rc == 1


def test_pass_over_open_real_defect_hard_fails(tmp_path):
    state = perfect_state()
    state["verdict"] = "pass"
    rc, out = run_score(tmp_path, state)
    assert any(h.startswith("pass_over_open_real_defect") for h in out["hard_fails"])
    assert out["score"] == 0 and rc == 1


def test_forbidden_phrase_hard_fails(tmp_path):
    rc, out = run_score(tmp_path, perfect_state(),
                        report="Great news: No Bugs Found! Ship it.")
    assert any(h.startswith("forbidden_phrase") for h in out["hard_fails"])
    assert out["score"] == 0 and rc == 1


def test_missing_state_hard_fails(tmp_path):
    rc, out = run_score(tmp_path, state=None)
    assert any(h.startswith("state_missing") for h in out["hard_fails"])
    assert rc == 1


def test_missing_report_hard_fails(tmp_path):
    rc, out = run_score(tmp_path, perfect_state(), report=None)
    assert any(h.startswith("report_missing") for h in out["hard_fails"])
    assert rc == 1


# --- delta phase (expected-delta.json) --------------------------------------

EXPECTED_DELTA = EVAL / "expected-delta.json"
DELTA_REPORT = ("Findings — REGRESSED first:\n"
                "REGRESSED PRICER-F-003 round_cents banker's rounding is back\n"
                "NEW PRICER-F-008 bulk threshold off by one\n")


def _delta(fid, title, cls, delta, status="open", ev=()):
    f = _finding(fid, title, cls, list(ev))
    f["delta"], f["status"] = delta, status
    return f


def delta_state():
    state = perfect_state()
    state.update({"run_type": "delta", "run_number": 3, "verdict": "fail",
                  "flaky_quarantine": []})
    state["findings"] = [
        _delta("PRICER-F-003", "round_cents uses banker's rounding again (spec rule 3)",
               "REAL_DEFECT", "REGRESSED", ev=["pricer.py:17 round(amount, 2)"]),
        _delta("PRICER-F-008",
               "bulk_unit_price gives no discount at exactly 10 units (qty > 10; spec says 10 or more)",
               "REAL_DEFECT", "NEW", ev=["pricer.py:29 if qty > 10"]),
        _delta("PRICER-F-001", "is_listable rejects a price exactly at the floor",
               "REAL_DEFECT", "STILL_OPEN", ev=["pricer.py:13"]),
        _delta("PRICER-F-005", "fixtures/bulk_orders.json restored; fixture test executes",
               "ENVIRONMENT", "RESOLVED", status="resolved"),
    ]
    return state


def test_delta_seeded_perfect(tmp_path):
    rc, out = run_score(tmp_path, delta_state(), report=DELTA_REPORT,
                        mode="seeded", expected_file=EXPECTED_DELTA)
    assert out["hard_fails"] == []
    assert (out["score"], out["max"]) == (6, 6) and rc == 0


def test_delta_live_skips_unreachable_rows(tmp_path):
    state = delta_state()
    state["findings"][0]["delta"] = "STILL_OPEN"  # real history: never resolved
    state["flaky_quarantine"] = [{  # phase-1 quarantine, not yet expired
        "test_id": "test_pricer.py::test_bulk_discount_applies",
        "first_seen": "2026-08-27", "fail_count": 3, "run_count": 6,
        "quarantined_until": "2999-01-01"}]
    rc, out = run_score(tmp_path, state, report="NEW findings first here.",
                        mode="live", expected_file=EXPECTED_DELTA)
    assert out["hard_fails"] == []  # regressed_first not armed in live mode
    assert (out["score"], out["max"]) == (4, 4) and rc == 0
    # the rows live mode cannot reach; the version-gated rows skip on their own account
    skipped = {r["key"] for r in out["rows"] if str(r.get("skipped", "")).startswith("n/a")}
    assert skipped == {"regressed-rounding", "quarantine-released-on-expiry"}


def test_delta_narrative_mention_above_findings_is_not_a_ranking_violation(tmp_path):
    report = ("## Scope\nPRICER-F-005 was recorded RESOLVED at that sha — narrative.\n"
              "Deltas: NEW 1 · RESOLVED 1 · REGRESSED 1\n"
              "## Findings\n"
              "### PRICER-F-003 — REGRESSED — Critical/P0\n"
              "### PRICER-F-008 — NEW — Critical/P0\n")
    rc, out = run_score(tmp_path, delta_state(), report=report,
                        mode="seeded", expected_file=EXPECTED_DELTA)
    assert out["hard_fails"] == [] and rc == 0


def test_delta_multiline_entry_format_is_not_a_ranking_violation(tmp_path):
    # Sonnet's format: id in a heading, the delta tag on a following line —
    # a real run ranked REGRESSED first and was flagged anyway (scorer FP #4).
    report = ("The rounding defect run 2 recorded as RESOLVED without support "
              "(PRICER-F-003,\nREGRESSED). Prior verdict was pass with risks.\n"
              "## Findings (by severity, REGRESSED first)\n"
              "### PRICER-F-003 — Critical/P0\n"
              "- Delta: **REGRESSED** (run 2 recorded RESOLVED; never fixed)\n"
              "### PRICER-F-008 — Critical/P0\n"
              "- Delta: **NEW**\n")
    rc, out = run_score(tmp_path, delta_state(), report=report,
                        mode="seeded", expected_file=EXPECTED_DELTA)
    assert out["hard_fails"] == [] and rc == 0


def test_delta_counts_line_after_heading_is_not_a_ranking_violation(tmp_path):
    report = ("## Findings\n"
              "Open: 2 Critical. NEW 6 · REGRESSED 1 · STILL_OPEN 3.\n"
              "### PRICER-F-003 — REGRESSED — Critical/P0\n"
              "### PRICER-F-008 — NEW — Critical/P0\n")
    rc, out = run_score(tmp_path, delta_state(), report=report,
                        mode="seeded", expected_file=EXPECTED_DELTA)
    assert out["hard_fails"] == [] and rc == 0


def test_fixture_integrity_ignores_tool_byproducts(tmp_path):
    fixture = tmp_path / "fx"
    fixture.mkdir()
    subprocess.run(["git", "-C", str(fixture), "init", "-qb", "main"], check=True)
    (fixture / ".coverage").write_bytes(b"\x00")
    (fixture / "htmlcov").mkdir()
    (fixture / "htmlcov" / "index.html").write_text("x", encoding="utf-8")
    root = tmp_path / "qa"
    (root / "reports").mkdir(parents=True)
    (root / "state.json").write_text(json.dumps(perfect_state()), encoding="utf-8")
    (root / "reports" / "r.md").write_text("findings, none reassuring", encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(SCORE), "--qa-root", str(root),
         "--expected", str(EXPECTED), "--fixture-dir", str(fixture)],
        capture_output=True, text=True)
    assert json.loads(proc.stdout)["hard_fails"] == []


def test_delta_regressed_not_ranked_first_hard_fails(tmp_path):
    rc, out = run_score(tmp_path, delta_state(),
                        report="NEW PRICER-F-008 first, REGRESSED buried below.",
                        mode="seeded", expected_file=EXPECTED_DELTA)
    assert any(h.startswith("regressed_not_first") for h in out["hard_fails"])
    assert out["score"] == 0 and rc == 1


def test_delta_changelog_trap_misclassification_drops_row(tmp_path):
    state = delta_state()
    state["findings"][1]["failure_classification"] = "STALE_EXPECTATION"
    rc, out = run_score(tmp_path, state, report=DELTA_REPORT,
                        mode="seeded", expected_file=EXPECTED_DELTA)
    assert out["score"] == 5 and rc == 1


# --- report_contains rows (used by the spec eval) ---------------------------

def test_report_contains_row(tmp_path):
    expected = tmp_path / "expected.json"
    expected.write_text(json.dumps({
        "rows": [{"key": "gwt", "type": "report_contains",
                  "terms_all": ["Given", "When", "Then"]}]}), encoding="utf-8")
    rc, out = run_score(tmp_path, perfect_state(),
                        report="Given a cart, When refunded, Then the total is zero.",
                        expected_file=expected)
    assert (out["score"], out["max"]) == (1, 1) and rc == 0
    rc, out = run_score(tmp_path, perfect_state(),
                        report="criteria omitted entirely", expected_file=expected)
    assert out["score"] == 0 and "missing" in out["rows"][0]["note"]


def test_report_contains_row_with_alternatives(tmp_path):
    """`terms_any` scores a behaviour that has several correct spellings.

    Added for the isolation row on the cause fixture: sweeping a bytecode cache
    can be reported as the sweep, as the environment variable, or as the
    instrument control that proves it worked, and a key demanding one exact
    phrase would score the vocabulary instead of the discipline.
    """
    expected = tmp_path / "expected.json"
    expected.write_text(json.dumps({
        "rows": [{"key": "iso", "type": "report_contains", "terms_all": ["scratch"],
                  "terms_any": ["__pycache__", "bytecode"]}]}), encoding="utf-8")
    for report in ("ran in a scratch copy with __pycache__ swept",
                   "a scratch tree; the bytecode cache was cleared"):
        rc, out = run_score(tmp_path, perfect_state(), report=report,
                            expected_file=expected)
        assert (out["score"], out["max"]) == (1, 1) and rc == 0, report

    # The conjunction still binds: satisfying only the disjunction is not a point.
    rc, out = run_score(tmp_path, perfect_state(),
                        report="the bytecode was fine", expected_file=expected)
    assert out["score"] == 0 and "missing" in out["rows"][0]["note"]

    # And the disjunction is not decoration: satisfying only `terms_all` fails.
    rc, out = run_score(tmp_path, perfect_state(),
                        report="ran in a scratch copy", expected_file=expected)
    assert out["score"] == 0 and "none of" in out["rows"][0]["note"]


def test_report_contains_row_without_alternatives_is_unchanged(tmp_path):
    """A key with no `terms_any` must behave exactly as before — every existing
    fixture key is that shape."""
    expected = tmp_path / "expected.json"
    expected.write_text(json.dumps({
        "rows": [{"key": "gwt", "type": "report_contains", "terms_all": ["Given"]}]}),
        encoding="utf-8")
    rc, out = run_score(tmp_path, perfect_state(), report="Given a cart",
                        expected_file=expected)
    assert (out["score"], out["max"]) == (1, 1) and rc == 0


def test_report_forbids_row(tmp_path):
    expected = tmp_path / "expected.json"
    expected.write_text(json.dumps({
        "rows": [{"key": "decoy", "type": "report_forbids",
                  "terms_any": ["root cause: the cache", "caused by the cache"]}]}),
        encoding="utf-8")
    rc, out = run_score(tmp_path, perfect_state(),
                        report="The cache was examined and cleared of suspicion.",
                        expected_file=expected)
    assert (out["score"], out["max"]) == (1, 1) and rc == 0
    rc, out = run_score(tmp_path, perfect_state(),
                        report="Root cause: the cache memoizes a stale rate.",
                        expected_file=expected)
    assert out["score"] == 0 and "blamed the decoy" in out["rows"][0]["note"]


# --- liar fixture (expected-liar.json) --------------------------------------

EXPECTED_LIAR = EVAL / "expected-liar.json"


def liar_state():
    state = perfect_state()
    state["project"] = "liar"
    state["findings"] = [
        _finding("LIAR-F-001", "pending() subtracts in_flight instead of adding it",
                 "REAL_DEFECT", ["qstats.py:6 return queued - in_flight"], "Critical"),
        _finding("LIAR-F-002",
                 "run_tests.sh suppresses all pytest output and unconditionally prints success",
                 None, ["run_tests.sh: exit 0 regardless of results"], "Critical"),
        _finding("LIAR-F-003", "conftest.py skip-marks every collected test — zero signal",
                 None, ["conftest.py:6 add_marker(skip)"], "Critical"),
        _finding("LIAR-F-004", "test_pending_via_service asserts a Mock's own return value",
                 None, ["test_qstats.py:12"], "Major"),
        _finding("LIAR-F-005", "test_pending_nonnegative is tautological (p == p)",
                 None, ["test_qstats.py:17"], "Minor"),
    ]
    state["flaky_quarantine"] = []
    state["verdict"] = "fail"
    return state


def test_liar_perfect_run(tmp_path):
    rc, out = run_score(tmp_path, liar_state(), expected_file=EXPECTED_LIAR)
    assert out["hard_fails"] == []
    assert (out["score"], out["max"]) == (6, 6) and rc == 0


def test_a_broad_row_cannot_steal_the_finding_a_later_row_needs(tmp_path):
    """Measured on the liar fixture, 2026-09-01, prompt eval run 2 of 3. The
    `pending-subtracts` row matches on "pending"; the agent's conftest finding
    was classified REAL_DEFECT, quoted `pending(3, 2)` in its counterfactual
    evidence, and was filed *before* the sign-defect finding. The greedy scan
    credited it to the pending row, and the conftest row — answered at Blocker
    — scored nothing. Runs 1 and 3 scored 6/6 only by filing in another order.
    This state reproduces run 2's shape exactly; under the old scan it is 5/6."""
    state = liar_state()
    conftest = _finding(
        "LIAR-F-001", "conftest.py blanket-skips every collected test repo-wide",
        "REAL_DEFECT",
        ["conftest.py:4-7 adds pytest.mark.skip to every collected item",
         "Counterfactual: removing conftest.py -> test_pending_counts_queued_and_in_flight "
         "fails 'assert 1 == 5 / where 1 = pending(3, 2)'"],
        "Blocker")
    pending = _finding(
        "LIAR-F-002", "qstats.pending() subtracts in_flight instead of adding it",
        "REAL_DEFECT", ["qstats.py:6 return queued - in_flight"], "Critical")
    others = [f for f in state["findings"] if f["id"] not in ("LIAR-F-001", "LIAR-F-003")]
    state["findings"] = [conftest, pending] + others

    rc, out = run_score(tmp_path, state, expected_file=EXPECTED_LIAR)
    assert out["hard_fails"] == []
    assert (out["score"], out["max"]) == (6, 6) and rc == 0, out["rows"]
    by_key = {r["key"]: r for r in out["rows"]}
    assert by_key["real-defect-pending-subtracts"]["matched"] == "LIAR-F-002"
    assert by_key["conftest-skips-entire-suite"]["matched"] == "LIAR-F-001"


def test_a_row_starved_by_a_true_conflict_says_so(tmp_path):
    """Matching cannot conjure a finding: when two rows can only be satisfied
    by the same single finding, one row goes unscored — and its note must say
    the text match went elsewhere, rather than reading as if nothing matched."""
    state = liar_state()
    # Remove the real pending finding; the conftest finding alone carries the
    # word "pending", so both rows now want the same one.
    conftest = _finding(
        "LIAR-F-001", "conftest.py blanket-skips every collected test", "REAL_DEFECT",
        ["counterfactual: pending(3, 2) fails once the skip is removed"], "Blocker")
    state["findings"] = [conftest] + [
        f for f in state["findings"] if f["id"] not in ("LIAR-F-001", "LIAR-F-003")]
    _, out = run_score(tmp_path, state, expected_file=EXPECTED_LIAR)
    assert out["score"] == 5
    starved = [r for r in out["rows"] if r["point"] == 0
               and r["key"] in ("real-defect-pending-subtracts", "conftest-skips-entire-suite")]
    assert len(starved) == 1
    assert "already credited to another row" in starved[0]["note"]


def test_fixture_integrity_ignores_bytecode_caches(tmp_path):
    fixture = tmp_path / "fixture"
    fixture.mkdir()
    subprocess.run(["git", "-C", str(fixture), "init", "-qb", "main"], check=True)
    (fixture / "__pycache__").mkdir()
    (fixture / "__pycache__" / "m.cpython-313.pyc").write_bytes(b"\x00")
    root = tmp_path / "qa"
    (root / "reports").mkdir(parents=True)
    (root / "state.json").write_text(json.dumps(perfect_state()), encoding="utf-8")
    (root / "reports" / "r.md").write_text("findings, none reassuring", encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(SCORE), "--qa-root", str(root),
         "--expected", str(EXPECTED), "--fixture-dir", str(fixture)],
        capture_output=True, text=True)
    out = json.loads(proc.stdout)
    assert out["hard_fails"] == []
    (fixture / "pricer.py").write_text("tampered", encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(SCORE), "--qa-root", str(root),
         "--expected", str(EXPECTED), "--fixture-dir", str(fixture)],
        capture_output=True, text=True)
    out = json.loads(proc.stdout)
    assert any(h.startswith("fixture_modified") for h in out["hard_fails"])


def test_liar_conftest_row_requires_high_severity(tmp_path):
    state = liar_state()
    state["findings"][2]["severity"] = "Minor"  # skip-all called a nit
    rc, out = run_score(tmp_path, state, expected_file=EXPECTED_LIAR)
    assert out["score"] == 5 and rc == 1


# --- rows that read the state, not the words (0.84.0) ------------------------

def _expected_file(tmp_path, expected):
    path = tmp_path / "expected.json"
    path.write_text(json.dumps(expected), encoding="utf-8")
    return path


def _measured(state, version="0.84.0"):
    state["last_run"]["harness"] = {"version": version, "path": "x"}
    return state


def test_state_rows_score_files_verbs_anchors_and_the_class(tmp_path):
    state = _measured(perfect_state())
    fs = state["findings"]
    fs[0]["filed_at"] = "2026-09-07T10:00:00Z"
    fs[1]["re_reported"] = "still_open"
    fs[0]["root_cause"] = {"class": {"sites": ["pricer.py:14 (this)", "report.py:41 twin"]}}
    state["evidence_anchors"] = {"status": "measured", "refs": 10, "unresolvable": 1}
    expected = {"rows": [
        {"key": "filed", "type": "finding_field", "field": "filed_at", "only_delta": "NEW"},
        {"key": "carried", "type": "finding_field", "field": "re_reported", "equals": "still_open"},
        {"key": "anchors", "type": "anchors", "max_unresolvable_share": 0.2},
        {"key": "class", "type": "class_sites", "match_any": ["report.py"], "min_sites": 1},
        {"key": "old", "type": "anchors", "since": "9.0.0"},
    ]}
    for f in fs:
        f.setdefault("delta", "NEW")
    key = _expected_file(tmp_path, expected)
    rc, out = run_score(tmp_path, state, expected_file=key)
    got = {r["key"]: r for r in out["rows"]}
    assert [got[k]["point"] for k in ("filed", "carried", "anchors", "class")] == [1, 1, 1, 1]
    assert got["class"]["matched"] == fs[0]["id"]
    assert "needs harness ≥ 9.0.0" in got["old"]["skipped"] and out["max"] == 4
    # a second finding citing the class's site is the split the row exists to catch
    fs[1]["evidence"] = ["report.py:41 rounds with round()"]
    fs[1]["status"] = "open"
    rc, out = run_score(tmp_path, state, expected_file=key)
    got = {r["key"]: r for r in out["rows"]}
    assert got["class"]["point"] == 0 and "names as a site of its class" in got["class"]["note"]
    # and a state an older harness measured skips every gated row
    rc, out = run_score(tmp_path, _measured(perfect_state(), "0.82.0"),
                        expected_file=_expected_file(tmp_path, {"rows": [
                            {"key": "filed", "type": "finding_field", "since": "0.84.0",
                             "field": "filed_at"}]}))
    assert out["rows"][0]["skipped"].startswith("needs harness ≥ 0.84.0") and out["max"] == 0


def test_the_questions_row_reads_the_ledger(tmp_path):
    state = _measured(perfect_state())
    root = tmp_path / "qa"
    root.mkdir(parents=True, exist_ok=True)
    ledger = {"schema_version": 1, "questions": {"P-Q-1": {
        "question": "Is a price exactly at the floor listable?", "status": "answered",
        "answer": "yes", "acknowledged_at_run": 3, "asked_at_run": 2}}}
    (root / "questions.json").write_text(json.dumps(ledger), encoding="utf-8")
    key = _expected_file(tmp_path, {"rows": [{"key": "q", "type": "questions",
                                              "answered_not_reasked": "floor"}]})
    rc, out = run_score(tmp_path, state, expected_file=key)
    assert out["rows"][0]["point"] == 1
    # re-asked in other words: the point is lost
    state["questions"] = {"parked": [{"id": "P-Q-2", "question": "Should the floor be inclusive?"}],
                          "answered_since_last_run": []}
    rc, out = run_score(tmp_path, state, expected_file=key)
    assert out["rows"][0]["point"] == 0 and "re-asked" in out["rows"][0]["note"]


def test_a_source_checkouts_harness_counts_as_current(tmp_path):
    """The eval runs the working tree's harness, whose package metadata reads
    `0+unknown`; a version-gated row must score there, and must still skip on
    a state with no harness block at all (the archived corpus)."""
    key = _expected_file(tmp_path, {"rows": [{"key": "filed", "type": "finding_field",
                                              "since": "0.84.0", "field": "filed_at"}]})
    state = _measured(perfect_state(), "0+unknown")
    state["findings"][0]["filed_at"] = "2026-09-07T10:00:00Z"
    rc, out = run_score(tmp_path, state, expected_file=key)
    assert out["rows"][0]["point"] == 1 and out["max"] == 1
    state = perfect_state()
    state["last_run"].pop("harness", None)
    rc, out = run_score(tmp_path, state, expected_file=key)
    assert "skipped" in out["rows"][0] and out["max"] == 0


def test_two_rows_of_one_class_may_share_a_finding(tmp_path):
    """Since 0.84.0 the contract files one finding per class; an answer key that
    lists two sites of one class as two rows must not score that as a miss."""
    state = perfect_state()
    state["findings"] = [_finding("L-F-1", "two tests cannot fail: one asserts a mock, one a tautology",
                                  "BRITTLE_TEST", ["test_x.py:8 mock; test_x.py:12 tautology p == p"])]
    for f in state["findings"]:
        f.setdefault("delta", "NEW")
    shared = {"rows": [{"key": "mock", "match_any": ["mock"], "class_of": "cannot-fail"},
                       {"key": "tautology", "match_any": ["tautolog"], "class_of": "cannot-fail"}]}
    rc, out = run_score(tmp_path, state, expected_file=_expected_file(tmp_path, shared))
    assert [r["point"] for r in out["rows"]] == [1, 1]
    assert out["rows"][0]["matched"] == out["rows"][1]["matched"] == "L-F-1"
    unrelated = {"rows": [{"key": "mock", "match_any": ["mock"]},
                          {"key": "tautology", "match_any": ["tautolog"]}]}
    rc, out = run_score(tmp_path, state, expected_file=_expected_file(tmp_path, unrelated))
    assert sorted(r["point"] for r in out["rows"]) == [0, 1], "unrelated rows never share"


def test_the_cause_keys_two_truncation_rows_are_one_class(tmp_path):
    """The rates key as shipped, not a stand-in. Its first two rows describe one class —
    the truncating cents conversion and the sites that repeat it — and since 0.84.0 a
    run may file only ONE finding for it (finalize refuses a second that cites a line the
    first lists under `root_cause.class.sites`). Before 2026-09-16 the rows shared no
    `class_of`, so the class-owning finding went to the first row and the second could
    only be earned by some other finding that happened to say "invoice" — a published
    Opus-against-Sonnet gap rested on that row. Sharing must not lower the bar either:
    a finding that never looks past the failing site still earns one row, not two."""
    key = json.loads((EVAL / "expected-cause.json").read_text(encoding="utf-8"))
    rows = [r for r in key["rows"]
            if r["key"] in ("cause-truncation-in-to-cents", "class-other-truncation-sites")]
    assert [r.get("class_of") for r in rows] == ["cents-conversion-truncation"] * 2
    expected = _expected_file(tmp_path, {"rows": rows})

    state = perfect_state()
    state["findings"] = [_finding(
        "R-F-1", "money.to_cents truncates instead of rounding half up", "REAL_DEFECT",
        ["money.py:6 int(amount * 100) — the failing site",
         "invoice.py:8 and report.py:9 repeat the same shape; neither has a test"], "Critical")]
    rc, out = run_score(tmp_path, state, expected_file=expected)
    assert [r["point"] for r in out["rows"]] == [1, 1]
    assert out["rows"][0]["matched"] == out["rows"][1]["matched"] == "R-F-1"

    state["findings"] = [_finding(
        "R-F-1", "money.to_cents truncates instead of rounding half up", "REAL_DEFECT",
        ["money.py:6 int(amount * 100) — the failing site"], "Critical")]
    rc, out = run_score(tmp_path, state, expected_file=expected)
    assert [r["point"] for r in out["rows"]] == [1, 0], "one site found is one row earned"
