"""Fix verification: the harness re-injects the defect so the tester need not.

`fix_verified` is the one judgment field that feeds the track record, and it
was almost never set — 95 of 110 Sales findings undecided, no precision rate
publishable. Each test here builds a real two-commit repository and lets the
real runner say whether the cited test fails before the fix and passes after.
"""

import json
import subprocess
import sys
from datetime import datetime, timezone

import verdict_mcp.harness as h
from verdict_mcp.harness import (cited_tests, collect, merge, render_report,
                                 resolve_test_id, select_test)
from verdict_mcp.validate import validate_judgment

from conftest import judgment

CMD = f'"{sys.executable}" -m pytest {{id}} -q -p no:cacheprovider'


def git(repo, *args):
    return subprocess.run(["git", "-c", "user.email=t@t", "-c", "user.name=t", "-C", str(repo), *args],
                          capture_output=True, text=True, check=True).stdout.strip()


def commit(repo, message):
    git(repo, "add", "-A")
    git(repo, "commit", "-qm", message)
    return git(repo, "rev-parse", "HEAD")


BUGGY = "def pending(q, i):\n    return q - i\n"
FIXED = "def pending(q, i):\n    return q + i\n"
TEST = "from pkg import pending\n\ndef test_pending():\n    assert pending(3, 2) == 5\n"


def bugged_repo(tmp_path, *, with_test=True):
    r = tmp_path / "proj"
    r.mkdir()
    git(r, "init", "-qb", "main")
    (r / "pkg.py").write_text(BUGGY, encoding="utf-8")
    if with_test:
        (r / "test_pkg.py").write_text(TEST, encoding="utf-8")
    return r, commit(r, "bug")


CITED = "test_pkg.py::test_pending"


def previous_state(qa_root, sha, evidence=("pkg.py:2 return q - i",
                                           "test_pkg.py::test_pending fails: assert 1 == 5"),
                   verification_test=None):
    """`verification_test` is the tester's own citation. Where a test below
    models the loop closing, it is set: a fail→pass confirms only on a chosen
    test, never on an id that happened to be quoted (VERDICT-F-72)."""
    qa_root.mkdir(parents=True, exist_ok=True)
    finding = {"id": "P-F-1", "hash": "h1", "status": "open", "severity": "Major",
               "priority": "P1", "title": "pending subtracts", "confidence": "proven",
               "first_seen": datetime.now(timezone.utc).date().isoformat(),
               "evidence": list(evidence)}
    if verification_test:
        finding["verification_test"] = verification_test
    (qa_root / "state.json").write_text(json.dumps({
        "project": "proj", "run_number": 1, "run_type": "baseline",
        "last_run": {"git_sha": sha,
                     "timestamp_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")},
        "findings": [finding],
    }), encoding="utf-8")
    return json.loads((qa_root / "state.json").read_text(encoding="utf-8"))


def resolved():
    j = judgment()
    j["findings"] = [{"id": "P-F-1", "title": "pending subtracts", "severity": "Major",
                      "priority": "P1", "status": "resolved", "evidence": ["pkg.py:2 now q + i"]}]
    return j


# ── the loop closes ─────────────────────────────────────────────────────────

def test_a_fix_is_verified_when_the_cited_test_fails_before_and_passes_after(tmp_path):
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec
    assert rec["previous_sha"] == sha_a

    state = merge(facts, resolved(), prev)
    f = state["findings"][0]
    assert f["delta"] == "RESOLVED" and f["fix_verified"] is True
    assert f["outcome"] == "confirmed" and "fix-verified" in f["outcome_reason"]
    assert any("verification (measured)" in e for e in f["evidence"])
    assert "Fix verification: 1 verified" in render_report(state)


def test_a_clean_verification_writes_no_notes_and_leaves_no_scratch(tmp_path):
    """The notes are what the tester reads before the numbers, and the sweep
    found six of them could be emitted unconditionally — "0 findings cite no
    test", "nothing was run for :", "previous commit is not in this
    repository" — with the suite none the wiser, because no test had ever
    asserted their ABSENCE. And the worktree the counterfactual ran in could be
    left behind forever. A clean run says nothing and leaves nothing."""
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec
    assert facts.get("verification_notes", []) == [], facts.get("verification_notes")
    # the summary reads old → new, in that order
    assert rec["summary"].index("failed") < rec["summary"].index("passed"), rec["summary"]
    # the scratch worktree is gone, and git no longer lists it
    from pathlib import Path
    for p in rec["pythonpath"]:
        assert not Path(p).exists(), f"scratch left behind: {p}"
    assert "verdict-verify-" not in git(repo, "worktree", "list")
    assert merge(facts, resolved(), prev)["findings"][0]["fix_verified"] is True


def test_a_finding_that_cites_nothing_is_counted_once_and_said_once(tmp_path):
    repo, sha_a = bugged_repo(tmp_path)
    qa = tmp_path / "qa"
    previous_state(qa, sha_a, evidence=("pkg.py:2 return q - i",))     # no node id anywhere
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    assert "P-F-1" not in (facts.get("verification") or {})
    notes = facts["verification_notes"]
    assert notes == ["1 open finding(s) cite no test id, so the harness cannot fix-verify them"], notes


def test_without_a_previous_commit_the_note_says_so(tmp_path):
    """No recorded commit and a recorded commit that is gone are two different
    sentences; the sweep found the first could be replaced by the second."""
    repo, _ = bugged_repo(tmp_path)
    qa = tmp_path / "qa"
    prev = previous_state(qa, "deadbeef" * 5, verification_test=CITED)
    prev["last_run"].pop("git_sha", None)
    (qa / "state.json").write_text(json.dumps(prev), encoding="utf-8")
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["at_previous"] == "unavailable" and rec["at_head"] == "fail", rec
    assert any(n.startswith("no previous commit recorded") for n in facts["verification_notes"]), facts
    assert not any("not in this repository" in n for n in facts["verification_notes"])


def test_a_failing_test_refuses_only_a_resolution(tmp_path):
    """`_apply_verification`'s two guards, `if resolving` and `if
    "carried_forward" in entry`, could both become `if True` unnoticed: an
    OPEN finding whose test still fails would then be stamped "resolution
    refused" and told it was carried forward, neither of which happened."""
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "README").write_text("unrelated\n", encoding="utf-8")
    commit(repo, "unrelated")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    assert facts["verification"]["P-F-1"]["at_head"] == "fail"
    j = resolved()
    j["findings"][0]["status"] = "open"                  # reported again, still open
    f = [x for x in merge(facts, j, prev)["findings"] if x["id"] == "P-F-1"][0]
    assert f["status"] == "open" and f["delta"] == "STILL_OPEN"
    assert "resolution_refused" not in f and "carried_forward" not in f, f


def test_an_explicit_citation_counts_when_it_resolves_to_the_collected_form():
    """A citation spelled with backslashes names the same test as the collected
    id; the sweep turned the `==` in that check into `!=` and no row noticed,
    because every explicit citation in the suite was spelled exactly as
    collected."""
    from verdict_mcp.harness import select_test
    finding = {"verification_test": "dir\\test_a.py::t"}
    assert select_test(finding, ["dir/test_a.py::t"], set()) == ("dir/test_a.py::t", "explicit")


def test_a_single_prose_citation_is_not_run_either(tmp_path):
    """VERDICT-F-26, the other half. The same setup as the test above, minus
    the tester's citation — the id is merely quoted in the evidence, and it is
    the only one. 0.79.0 still ran that pick, "the conservative direction": it
    could only hold a finding open. It then mis-selected on six consecutive
    runs and refused nothing, while attaching a measurement of an unrelated
    test to the finding every time. A node id in prose is text: nothing runs,
    the record says so, and the resolution stands on the tester's word."""
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a)                       # no verification_test
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["selected_by"] == "unselectable" and rec["candidates"] == 1, rec
    assert rec["test"] is None and rec["at_head"] == "unavailable", rec
    assert rec["candidate_tests"] == [CITED] and "1 test cited" in rec["summary"], rec
    assert any("verification_test" in n and "text, not a citation" in n
               for n in facts["verification_notes"]), facts
    state = merge(facts, resolved(), prev)
    f = state["findings"][0]
    assert f["delta"] == "RESOLVED" and f.get("fix_verified") is not True
    assert f["outcome"] != "confirmed", f
    assert not any("verification (measured)" in e for e in f["evidence"])
    report = render_report(state)
    assert "Fix verification: 0 verified" in report and "1 not run" in report, report
    # …and the same repository with the tester's citation confirms (the control)
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    assert facts["verification"]["P-F-1"]["selected_by"] == "explicit"
    assert merge(facts, resolved(), prev)["findings"][0]["fix_verified"] is True


def test_a_prose_pick_that_arrives_by_hand_still_confirms_nothing(tmp_path):
    """The guard behind the selector, kept and controlled. `verify_findings`
    never writes a `first_cited` record now, but facts.json is read as facts
    whoever wrote it, and a confirmed row is a permanent grade (VERDICT-F-72).
    A fail→pass on a record that says it was chosen by prose order is recorded,
    named `not_weighed`, and confirms nothing."""
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert (rec["selected_by"], rec["at_previous"], rec["at_head"]) == ("explicit", "fail", "pass")
    rec["selected_by"] = "first_cited"                     # the hand on the file
    f = merge(facts, resolved(), prev)["findings"][0]
    assert f["delta"] == "RESOLVED" and f.get("fix_verified") is not True, f
    assert "verification_test" in f["verification"].get("not_weighed", ""), f
    assert f["outcome"] != "confirmed", f


def test_silence_is_verified_too(tmp_path):
    """A finding nobody re-reported used to stay `unknown` forever. The cited
    test does not care whether anyone mentioned it."""
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    j = judgment()
    j["findings"] = []
    carried = [f for f in merge(facts, j, prev)["findings"] if f["id"] == "P-F-1"][0]
    assert carried["delta"] == "RESOLVED" and carried["fix_verified"] is True
    assert carried["outcome"] == "confirmed"


# ── measurement outranks the claim ──────────────────────────────────────────

def test_a_resolution_is_refused_while_the_cited_test_still_fails(tmp_path):
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "README").write_text("unrelated\n", encoding="utf-8")
    commit(repo, "unrelated")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    assert facts["verification"]["P-F-1"]["at_head"] == "fail"

    f = merge(facts, resolved(), prev)["findings"][0]
    assert f["status"] == "open" and f["delta"] == "STILL_OPEN"
    assert "test_pkg.py::test_pending still fails at HEAD" in f["resolution_refused"]
    assert f["outcome"] == "unknown" and "fix_verified" not in f

    j = judgment()
    j["findings"] = []
    carried = [x for x in merge(facts, j, prev)["findings"] if x["id"] == "P-F-1"][0]
    assert carried["status"] == "open" and "held open by measurement" in carried["carried_forward"]


def test_a_test_the_fix_added_is_carried_back_to_the_old_commit(tmp_path):
    """The commonest shape: fix and regression test land together. The old
    code has no test to run — so the new test is copied back and meets it."""
    repo, sha_a = bugged_repo(tmp_path, with_test=False)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    (repo / "test_pkg.py").write_text(TEST, encoding="utf-8")
    commit(repo, "fix + test")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["test_copied_from_head"] is True
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass")
    assert merge(facts, resolved(), prev)["findings"][0]["fix_verified"] is True


# ── what is honestly not a verification ─────────────────────────────────────

def test_pass_at_both_commits_verifies_nothing(tmp_path):
    """The test did not demonstrate the defect — or the old source was not what
    ran. The harness cannot tell which, and does not pretend to."""
    r = tmp_path / "proj"
    r.mkdir()
    git(r, "init", "-qb", "main")
    (r / "pkg.py").write_text(FIXED, encoding="utf-8")
    (r / "test_pkg.py").write_text(TEST, encoding="utf-8")
    sha_a = commit(r, "already fine")
    (r / "README").write_text("x\n", encoding="utf-8")
    commit(r, "later")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(r, qa, [], test_one_cmd=CMD)
    assert facts["verification"]["P-F-1"]["at_previous"] == "pass"
    f = merge(facts, resolved(), prev)["findings"][0]
    assert f["delta"] == "RESOLVED" and "fix_verified" not in f
    assert f["outcome"] == "unknown" and "absence is not proof" in f["outcome_reason"]


def test_a_setup_error_at_the_old_commit_never_reads_as_fail(tmp_path):
    """A collection error exits like a failure. Read as `fail`, it would mint a
    verification the code never earned — the one false positive this feature
    must not have."""
    # The fix adds the test *and* a helper it imports. Copied back to the old
    # commit the test cannot even be collected: that is an error, not a
    # failing assertion, and pytest exits 1 either way.
    repo, sha_a = bugged_repo(tmp_path, with_test=False)
    (repo / "test_pkg.py").write_text("import helper\n" + TEST, encoding="utf-8")
    (repo / "helper.py").write_text("", encoding="utf-8")
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix + test + helper")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["at_head"] == "pass" and rec["at_previous"] == "error", rec
    assert "fix_verified" not in merge(facts, resolved(), prev)["findings"][0]


def test_an_error_beside_a_failure_is_still_an_error(tmp_path):
    """The rule the pure-collection-error case cannot pin: a summary reading
    "1 failed, 1 error" must classify as `error`. Read `failed` first and the
    old commit looks like a clean failure — and the fix looks verified.

    The error has to come from something that does NOT travel back to the old
    commit. It used to be a fixture in conftest.py, until conftest started
    travelling with the test (VERDICT-F-33) and this scenario quietly stopped
    producing an error at all. It is now a fixture *inside the test file* whose
    body imports a function only the fix added: copied back with the file,
    still unsatisfiable against the old source.
    """
    repo, sha_a = bugged_repo(tmp_path, with_test=False)
    (repo / "pkg.py").write_text(FIXED + "\n\ndef helper():\n    return 1\n", encoding="utf-8")
    (repo / "test_pkg.py").write_text(
        "import pytest\n\n" + TEST +
        "\n\n@pytest.fixture\ndef helper():\n    from pkg import helper as h\n    return h()\n"
        "\n\ndef test_with_fixture(helper):\n    assert helper == 1\n", encoding="utf-8")
    commit(repo, "fix + a helper the fixture needs + tests")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD.replace("{id}", "test_pkg.py"))
    rec = facts["verification"]["P-F-1"]
    assert rec["at_head"] == "pass"
    assert rec["at_previous"] == "error", rec
    assert "fix_verified" not in merge(facts, resolved(), prev)["findings"][0]


def test_without_test_one_cmd_nothing_runs_and_the_note_says_how(tmp_path):
    repo, sha_a = bugged_repo(tmp_path)
    qa = tmp_path / "qa"
    previous_state(qa, sha_a)
    facts = collect(repo, qa, [])
    assert "verification" not in facts
    assert any("test_one_cmd" in n for n in facts["verification_notes"])


def test_a_missing_previous_commit_still_measures_head(tmp_path):
    """The squash-merged base of this repository's own run 3: gone from every
    clone. The counterfactual half is unavailable; the still-failing half
    still refuses a resolution."""
    repo, _ = bugged_repo(tmp_path)
    qa = tmp_path / "qa"
    prev = previous_state(qa, "deadbeef" * 5, verification_test=CITED)
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["at_previous"] == "unavailable" and rec["at_head"] == "fail"
    assert any("not in this repository" in n for n in facts["verification_notes"])
    assert merge(facts, resolved(), prev)["findings"][0]["delta"] == "STILL_OPEN"


def test_verification_is_bounded(tmp_path, monkeypatch):
    monkeypatch.setattr(h, "VERIFY_MAX_FINDINGS", 2)
    repo, sha_a = bugged_repo(tmp_path)
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a)
    prev["findings"] = [dict(prev["findings"][0], id=f"P-F-{i}", hash=f"h{i}") for i in range(1, 5)]
    (qa / "state.json").write_text(json.dumps(prev), encoding="utf-8")
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    assert len(facts["verification"]) == 2
    assert any("capped at 2 of 4" in n for n in facts["verification_notes"])
    # …and exactly at the cap nothing is capped and nothing says so.
    prev["findings"] = prev["findings"][:2]
    (qa / "state.json").write_text(json.dumps(prev), encoding="utf-8")
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    assert len(facts["verification"]) == 2
    assert not any("capped" in n for n in facts["verification_notes"]), facts["verification_notes"]


def test_the_old_source_is_put_ahead_of_any_installed_copy(tmp_path):
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "src").mkdir()
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    previous_state(qa, sha_a, verification_test=CITED)
    rec = collect(repo, qa, [], test_one_cmd=CMD)["verification"]["P-F-1"]
    assert rec["pythonpath"] and all("verdict-verify-" in p for p in rec["pythonpath"])


def test_the_judgment_may_not_claim_a_verification():
    f = dict(judgment()["findings"][0], verification={"at_previous": "fail", "at_head": "pass"})
    bad = validate_judgment(judgment(findings=[f]))
    assert any("verification" in b and "verdict-finalize computes" in b for b in bad)


def test_cited_tests_reads_ids_not_line_references():
    f = {"verification_test": "tests/test_a.py::test_explicit",
         "evidence": ["tests/test_b.py::test_rate[west 7kg] fails.",
                      "src/x.py:12 the guard", "tests/test_b.py::test_rate[west 7kg]",
                      "see tests/test_c.py::TestK::test_m: assert 1 == 2"]}
    assert cited_tests(f) == ["tests/test_a.py::test_explicit",
                              "tests/test_b.py::test_rate[west 7kg]",
                              "tests/test_c.py::TestK::test_m"]


# ── a citation is only a citation if the collector reported it (F-26) ────────

OTHER = "def test_other():\n    assert True\n"


def _emit(lines):
    """A shell command printing these lines, on any platform — no backslash
    escapes, which a POSIX shell would eat before Python saw them."""
    body = "; ".join(f"print({line!r})" for line in lines)
    return f'"{sys.executable}" -c "{body}"'


def fixed_repo(tmp_path, **kw):
    repo, sha_a = bugged_repo(tmp_path, **kw)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    return repo, sha_a


def test_a_node_id_scraped_from_prose_is_never_run(tmp_path):
    """VERDICT-F-26, live on run 5 of this repository: the regex matches a node
    id anywhere in evidence, including inside a quoted snippet, and the record
    for F-20 read `t.py::new` — a test that exists in no file here. It errored
    at both commits, and an error is not a measurement."""
    repo, sha_a = fixed_repo(tmp_path)
    qa = tmp_path / "qa"
    previous_state(qa, sha_a, evidence=("the old code called t.py::new",))
    facts = collect(repo, qa, [], test_ids_cmd=_emit(["test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    assert "P-F-1" not in (facts.get("verification") or {})
    assert any("not in the collected id ledger" in n and "t.py::new" in n
               for n in facts["verification_notes"]), facts["verification_notes"]


def test_the_collected_citation_wins_over_the_scraped_one(tmp_path):
    """Selection was evidence ORDER — `tests[0]`, whatever it happened to be."""
    repo, sha_a = fixed_repo(tmp_path)
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, evidence=("prose naming t.py::new first",
                                               "test_pkg.py::test_pending fails: assert 1 == 5"))
    facts = collect(repo, qa, [], test_ids_cmd=_emit(["test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["test"] == "test_pkg.py::test_pending"
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec
    assert merge(facts, resolved(), prev)["findings"][0]["fix_verified"] is True


def test_without_a_ledger_a_declared_citation_is_still_tried(tmp_path):
    """The filter is only as good as the ledger. A project with no
    `test_ids_cmd` has nothing to check against, and refusing to run there
    would turn a working verification off to fix a scraping bug. The citation
    has to be the tester's own: a prose mention is not tried anywhere."""
    repo, sha_a = fixed_repo(tmp_path)
    qa = tmp_path / "qa"
    previous_state(qa, sha_a, evidence=("the old code called t.py::new",),
                   verification_test="t.py::new")
    facts = collect(repo, qa, [], test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["test"] == "t.py::new" and rec["selected_by"] == "explicit", rec


def test_resolve_test_id_matches_the_collected_form_not_the_prose():
    known = {"tests/test_x.py::test_y", "tests/test_x.py::test_p[a]",
             "tests/test_x.py::test_p[b]", "tests/sub/test_z.py::test_q"}
    assert resolve_test_id("tests/test_x.py::test_y", known) == "tests/test_x.py::test_y"
    assert resolve_test_id("test_x.py::test_y", known) == "tests/test_x.py::test_y"
    assert resolve_test_id("tests\\test_x.py::test_y", known) == "tests/test_x.py::test_y"
    assert resolve_test_id("test_z.py::test_q", known) == "tests/sub/test_z.py::test_q"
    # a base id is what pytest expands over the parametrizations
    assert resolve_test_id("tests/test_x.py::test_p", known) == "tests/test_x.py::test_p"
    assert resolve_test_id("t.py::new", known) is None
    assert resolve_test_id("t.py::new", None) == "t.py::new"


# ── the new test meets the old source, appended or not (F-25) ────────────────

def test_a_regression_test_appended_to_an_existing_file_verifies(tmp_path):
    """VERDICT-F-25: the copy-back was file-level, so the commonest real shape
    — a regression test appended to a test file that already existed — left the
    old file in place. It does not contain the test, so at_previous read
    `error` and no fix could ever verify."""
    r = tmp_path / "proj"
    r.mkdir()
    git(r, "init", "-qb", "main")
    (r / "pkg.py").write_text(BUGGY, encoding="utf-8")
    (r / "test_pkg.py").write_text(OTHER, encoding="utf-8")
    sha_a = commit(r, "bug, and a test file that already exists")
    (r / "pkg.py").write_text(FIXED, encoding="utf-8")
    (r / "test_pkg.py").write_text(OTHER + "\n" + TEST, encoding="utf-8")
    commit(r, "fix + appended regression test")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a)
    facts = collect(r, qa, [], test_ids_cmd=_emit(["test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["test_copied_from_head"] is True
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec
    assert merge(facts, resolved(), prev)["findings"][0]["fix_verified"] is True


def test_a_test_file_the_fix_did_not_touch_is_not_reported_as_copied(tmp_path):
    """`test_copied_from_head` must keep meaning "the old commit did not have
    this test as written". Setting it unconditionally would make it noise."""
    repo, sha_a = fixed_repo(tmp_path)  # test_pkg.py is identical at both commits
    qa = tmp_path / "qa"
    previous_state(qa, sha_a, verification_test=CITED)
    rec = collect(repo, qa, [], test_one_cmd=CMD)["verification"]["P-F-1"]
    assert rec["at_head"] == "pass", "the test must actually have run for the flag to mean anything"
    assert "test_copied_from_head" not in rec


# ── the report counts the measurement, not the claim (F-30) ──────────────────

def _resolved_state(verification, **extra):
    return {"project": "p", "run_number": 2, "run_type": "delta", "verdict": "pass",
            "last_run": {"timestamp_utc": "2026-09-02T00:00:00Z"},
            "findings": [{"id": "P-F-1", "title": "t", "severity": "Major", "priority": "P1",
                          "status": "resolved", "delta": "RESOLVED",
                          "verification": verification, **extra}]}


def test_the_report_counts_the_measurement_not_the_claim():
    """VERDICT-F-30, live in run 5's own report: the block is selected by
    measurement and was counted by `fix_verified`, the one judgment field in
    it. A record measured error/error published as "1 verified", and the
    arithmetic then emptied the bucket that would have shown it."""
    claimed = _resolved_state({"test": "t.py::new", "at_previous": "error", "at_head": "error"},
                              fix_verified=True)
    text = render_report(claimed)
    assert "Fix verification: 0 verified" in text
    assert "1 measured but not verifiable" in text
    assert "claims fix_verified the measurement does not show: P-F-1" in text


def test_a_measured_fix_still_reads_as_verified():
    measured = _resolved_state({"test": "t.py::a", "at_previous": "fail", "at_head": "pass",
                                "selected_by": "explicit"}, fix_verified=True)
    text = render_report(measured)
    assert "Fix verification: 1 verified" in text
    assert "0 measured but not verifiable" in text
    assert "claims fix_verified" not in text


# ── a test is not only its file (F-33) ──────────────────────────────────────

CONFTEST = "import pytest\n\n\n@pytest.fixture\ndef order():\n    return (3, 2)\n"
FIXTURE_TEST = ("from pkg import pending\n\n\n"
                "def test_pending(order):\n    assert pending(*order) == 5\n")


def test_a_regression_test_that_lands_with_its_fixture_verifies(tmp_path):
    """VERDICT-F-33: the copy-back covered the cited test's own file, so a test
    arriving with the conftest it needs met an old commit that had never seen
    that fixture. It errored there, and an error is not a measurement."""
    repo, sha_a = bugged_repo(tmp_path, with_test=False)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    (repo / "conftest.py").write_text(CONFTEST, encoding="utf-8")
    (repo / "test_pkg.py").write_text(FIXTURE_TEST, encoding="utf-8")
    commit(repo, "fix + regression test + its fixture")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a)
    facts = collect(repo, qa, [], test_ids_cmd=_emit(["test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec.get("support_copied_from_head") == ["conftest.py"], rec
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec
    assert merge(facts, resolved(), prev)["findings"][0]["fix_verified"] is True


def test_a_conftest_the_commit_did_not_touch_is_not_reported_as_copied(tmp_path):
    """`support_copied_from_head` must keep meaning "the old commit did not
    have this, as written"."""
    r = tmp_path / "proj"
    r.mkdir()
    git(r, "init", "-qb", "main")
    (r / "pkg.py").write_text(BUGGY, encoding="utf-8")
    (r / "conftest.py").write_text(CONFTEST, encoding="utf-8")
    (r / "test_pkg.py").write_text(FIXTURE_TEST, encoding="utf-8")
    sha_a = commit(r, "bug, with the fixture already in place")
    (r / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(r, "fix only")
    qa = tmp_path / "qa"
    previous_state(qa, sha_a)
    facts = collect(r, qa, [], test_ids_cmd=_emit(["test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert "support_copied_from_head" not in rec, rec
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec


# ── which test, and how it was chosen (F-26) ────────────────────────────────

def test_a_test_the_fix_added_is_preferred_over_one_merely_mentioned(tmp_path):
    """VERDICT-F-26, measured on run 7: the harness picked a non-guarding test
    for every finding it verified, because selection was evidence order among
    valid ids. A test the collector saw for the first time this run is what a
    fix's own regression test looks like."""
    repo, sha_a = fixed_repo(tmp_path)
    qa = tmp_path / "qa"
    (qa).mkdir(parents=True, exist_ok=True)
    (qa / "test-ids.txt").write_text("test_pkg.py::test_other\n", encoding="utf-8")
    previous_state(qa, sha_a, evidence=("test_pkg.py::test_other covers the caller",
                                        "test_pkg.py::test_pending fails: assert 1 == 5"))
    facts = collect(repo, qa, [],
                    test_ids_cmd=_emit(["test_pkg.py::test_other",
                                        "test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["test"] == "test_pkg.py::test_pending", rec
    assert rec["selected_by"] == "added_this_run" and rec["candidates"] == 2


def test_an_explicit_citation_leads_whatever_the_prose_says(tmp_path):
    repo, sha_a = fixed_repo(tmp_path)
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, evidence=("test_pkg.py::test_other is nearby",))
    prev["findings"][0]["verification_test"] = "test_pkg.py::test_pending"
    (qa / "state.json").write_text(json.dumps(prev), encoding="utf-8")
    facts = collect(repo, qa, [],
                    test_ids_cmd=_emit(["test_pkg.py::test_other", "test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["test"] == "test_pkg.py::test_pending" and rec["selected_by"] == "explicit"


def test_select_test_labels_how_it_chose():
    f = {"verification_test": "t.py::a"}
    assert select_test(f, ["t.py::a", "t.py::b"], {"t.py::b"}) == ("t.py::a", "explicit")
    assert select_test({}, ["t.py::b"], {"t.py::b"}) == ("t.py::b", "added_this_run")
    assert select_test({}, ["t.py::c"], set()) == ("t.py::c", "first_cited")
    assert select_test({}, [], set()) == (None, None)


def test_a_prose_pick_among_several_is_not_run_at_all(tmp_path):
    """The strongest thing a measurement does is overrule the tester, and a
    test chosen by prose order from several is not a citation. Run 7 showed the
    harness choosing that way, and the pick stopped being weighed. Run 12
    showed the other half: the pick was still RUN, and its pass/pass record sat
    in the state reading as a measurement of a test nobody chose — the id had
    come out of another finding's quoted evidence. So the harness now says it
    could not choose: nothing runs, the candidates are named, and the note asks
    for `verification_test`."""
    repo, sha_a = bugged_repo(tmp_path)          # the defect is NOT fixed at HEAD
    (repo / "test_pkg.py").write_text(
        TEST + "\n\ndef test_other():\n    assert True\n", encoding="utf-8")
    commit(repo, "a second test, no fix")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, evidence=("test_pkg.py::test_pending fails",
                                              "test_pkg.py::test_other is nearby"))
    # Both ids were already in the ledger, so neither is "the test the fix
    # added" and the choice really is prose order.
    (qa / "test-ids.txt").write_text("test_pkg.py::test_pending\ntest_pkg.py::test_other\n",
                                     encoding="utf-8")
    facts = collect(repo, qa, [],
                    test_ids_cmd=_emit(["test_pkg.py::test_pending", "test_pkg.py::test_other"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["selected_by"] == "unselectable" and rec["candidates"] == 2, rec
    assert rec["test"] is None and rec["at_head"] == "unavailable", rec
    assert set(rec["candidate_tests"]) == {"test_pkg.py::test_pending",
                                           "test_pkg.py::test_other"}
    assert any("verification_test" in n for n in facts["verification_notes"]), facts
    state = merge(facts, resolved(), prev)
    f = state["findings"][0]
    assert f["delta"] == "RESOLVED", "a pick nobody made may not reopen a finding"
    assert f.get("fix_verified") is not True and f.get("outcome") != "confirmed", f
    report = render_report(state)
    assert "1 not run" in report and "none declared" in report, report


def test_a_single_cited_test_that_fails_at_head_still_refuses(tmp_path):
    """The false-positive guard: refusing to run a prose pick must not weaken
    the real one. One chosen test, still failing, still holds the finding open."""
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(BUGGY + "\n# touched, but the defect is untouched\n",
                                 encoding="utf-8")
    commit(repo, "a commit that fixes nothing")
    qa = tmp_path / "qa"
    prev = previous_state(qa, sha_a, verification_test=CITED)
    (qa / "test-ids.txt").write_text("test_pkg.py::test_pending\n", encoding="utf-8")
    facts = collect(repo, qa, [], test_ids_cmd=_emit(["test_pkg.py::test_pending"]),
                    test_one_cmd=CMD)
    rec = facts["verification"]["P-F-1"]
    assert rec["candidates"] == 1 and rec["at_head"] == "fail"
    f = merge(facts, resolved(), prev)["findings"][0]
    assert f["delta"] == "STILL_OPEN" and f["status"] == "open"
    assert "resolution_refused" in f


def test_a_stale_cache_planted_in_the_scratch_does_not_survive_the_run(tmp_path, monkeypatch):
    """The sweep has to happen in the real flow, not merely exist.

    VERDICT-F-57 caught this the honest way: `_drop_bytecode`'s body was
    mutation-tested and its **only call site** was not, so deleting the call
    left all 721 tests passing. A rule nothing calls is a rule that can be
    removed by accident, and the suite says the same thing either way.

    Fault injection rather than a mock assertion: the scratch checkout is
    poisoned with a `__pycache__` before verification runs, and the check is
    what the filesystem says afterwards. Deleting the call site fails this.
    """
    repo, sha_a = bugged_repo(tmp_path)
    (repo / "pkg.py").write_text(FIXED, encoding="utf-8")
    commit(repo, "fix")
    qa = tmp_path / "qa"
    previous_state(qa, sha_a, verification_test=CITED)

    real_scratch = h._scratch_checkout
    planted = {}

    def poisoned(repo_path, sha):
        """A real worktree, plus the stale cache a previous run could leave."""
        scratch = real_scratch(repo_path, sha)
        cache = scratch / "__pycache__"
        cache.mkdir(exist_ok=True)
        stale = cache / "pkg.cpython-stale.pyc"
        stale.write_bytes(b"not really bytecode, and that is the point")
        planted["path"] = stale
        return scratch

    # Observed at the only moment that matters: when the old code actually
    # runs. Checking after the run proves nothing — verification removes the
    # whole scratch worktree on the way out, so the planted file is gone
    # whether it was swept or not. The first version of this test asserted
    # exactly that, passed, and was killed by the mutant it was written for.
    seen = []
    real_run_test = h._run_test

    def watch(template, test_id, cwd, repo_path, timeout, pythonpath=None):
        seen.append((str(cwd), planted.get("path") is not None
                     and planted["path"].exists()))
        return real_run_test(template, test_id, cwd, repo_path, timeout, pythonpath)

    monkeypatch.setattr(h, "_scratch_checkout", poisoned)
    monkeypatch.setattr(h, "_run_test", watch)
    facts = collect(repo, qa, [], test_one_cmd=CMD)

    assert planted, "the scratch was never built; this test measured nothing"
    scratch_dir = str(planted["path"].parent.parent)
    in_scratch = [cache_present for cwd, cache_present in seen if cwd == scratch_dir]
    assert in_scratch, f"the old commit never ran in the scratch; saw {seen}"
    assert not any(in_scratch), (
        "a planted __pycache__ was still there when the previous commit ran — the "
        "scratch is not swept, so a stale .pyc could decide the result")
    # And the measurement itself must still be right, not merely cache-free.
    rec = facts["verification"]["P-F-1"]
    assert (rec["at_previous"], rec["at_head"]) == ("fail", "pass"), rec
