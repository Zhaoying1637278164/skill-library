# Rolino for Claude

Draft, schedule, and publish social posts and blog articles from a conversation
with Claude, through your [Rolino](https://getrolino.com) workspace. Claude
prepares the work; Rolino previews every schedule and publish, and nothing goes
out until you approve that exact preview.

## What you can ask

- "Draft a LinkedIn and Bluesky post announcing our new pricing page."
- "Schedule these five product photos to Instagram, one a day at 9am Toronto time."
- "What's going out this week, and is anything broken?"
- "The TikTok post from yesterday says failed. Did it go out?"
- "What should we blog about next based on our SEO report?"
- "How much storage are we using? Clear out uploads older than 90 days that aren't in use."

Slash commands: `/rolino:week` summarizes the next seven days, and
`/rolino:draft <idea>` drafts a post without publishing it.

## What's inside

| Component | Purpose |
| --- | --- |
| Rolino connector (`.mcp.json`) | Connects to the hosted Rolino MCP server at `https://getrolino.com/mcp` |
| `schedule-posts` skill | Drafts, captions, media, per-platform rules, and the preview-then-approve flow for scheduling and publishing |
| `content-calendar` skill | Read-only calendar and account-health review |
| `fix-delivery` skill | Checks what really happened before any retry, then recovers, cancels, or reschedules |
| `blog-studio` skill | Blog plans, article drafts, approval, and publishing |
| `seo-opportunities` skill | SEO reports, website analytics, and backlink prospecting |
| `media-cleanup` skill | Storage usage and safe Media Library cleanup |

## Set up

1. Install the plugin, then open its **Connectors** tab and connect Rolino.
2. Sign in to Rolino in the browser, pick a workspace, and choose the
   permissions you want Claude to have. Start with read and draft access; add
   scheduling, publishing, Blog, SEO, or storage permissions only when you want
   Claude to use them.
3. Connect your social accounts inside Rolino. Claude can't connect or
   disconnect social accounts for you.

You need a Rolino account on [getrolino.com](https://getrolino.com). For a
self-hosted Rolino, add your own server's `/mcp` URL as a custom connector
instead.

## Safety

- Asking Claude to write or prepare a post creates a draft only.
- Scheduling and publishing always run through a Rolino preview that expires
  after five minutes, and execute only after you approve that exact preview.
- Claude checks the real delivery status before any retry, so an uncertain
  result isn't posted twice.
- Claude only gets the permissions you grant on Rolino's consent screen and
  can't widen them.

## Data

This plugin contains only instructions and the connector address; it runs no
code of its own. When you use it, Claude sends the requests you ask for
(captions, schedule times, media you approve, and project, post, and blog
identifiers) to your Rolino workspace at getrolino.com over the Rolino MCP
connector, authenticated with OAuth. Rolino then publishes to the social
accounts and websites you connected. Rolino's handling of your data is covered
by its [privacy policy](https://getrolino.com/privacy) and
[terms](https://getrolino.com/terms).

## Support

Questions and issues: [hello@getrolino.com](mailto:hello@getrolino.com) or
[GitHub issues](https://github.com/deifos/rolino-claude-plugin/issues).

## License

MIT. See [LICENSE](LICENSE).
