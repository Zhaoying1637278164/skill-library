---
description: Draft a Rolino social post from an idea, file, or link (saves a draft, never publishes)
argument-hint: "[what the post is about]"
---

Draft a social post in Rolino about: $ARGUMENTS

Follow the schedule-posts skill through step 5 only. Ask which project and destination accounts to use if that isn't clear, show me the captions with character usage per destination, and save it as a draft after I approve. Don't schedule or publish it.
