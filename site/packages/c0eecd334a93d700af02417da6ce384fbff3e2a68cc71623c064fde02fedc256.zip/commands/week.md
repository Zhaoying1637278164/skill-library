---
description: Summarize this week's Rolino schedule and anything that needs attention
---

Using the Rolino connector, review the content calendar for the next 7 days in my timezone. Follow the content-calendar skill. Lead with anything that needs my attention (failed or uncertain posts, readiness blockers, disconnected accounts), then list what's going out each day. Don't change anything.
