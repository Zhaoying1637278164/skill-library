---
name: content-calendar
description: Review what's scheduled in Rolino and spot gaps or problems. Use when the user asks what's going out this week or month, wants a content calendar summary, asks which posts are drafts or failed, or wants to know whether their social accounts are healthy before a launch.
---

# Review the Rolino content calendar

Everything here is read-only. Don't change, schedule, or publish anything unless
the user asks for it afterward; hand that off to the `schedule-posts` skill.

## Steps

1. Resolve the project with `list_projects` (ask if more than one fits).
2. Read the window the user asked about with `list_calendar_events`. Pass both
   `from` and `to` for a specific range; by default it covers 30 days back to
   90 days ahead. Follow `nextCursor` until the window is complete.
3. Read unscheduled work with `list_posts`, filtered by status when useful
   (drafts, failed).
4. Read `list_integration_health` so you can flag accounts that will block
   upcoming posts.
5. For any post that looks off, `get_post` and `get_post_readiness` explain why.

## What to report

Lead with what matters, then the detail:

- **Needs attention:** failed or uncertain deliveries, scheduled posts whose
  readiness has blockers, disconnected or expiring accounts with posts queued
  against them.
- **Coming up:** the schedule grouped by day in the user's timezone, each line
  with time, destinations, and the first few words of the caption.
- **Gaps:** days or platforms with nothing planned, if the user cares about
  cadence. Offer to draft posts for them; don't create drafts unprompted.
- **Drafts waiting:** drafts not yet scheduled.

Present times in the user's timezone and say which timezone you used. Don't
report a queued or processing post as published.

YouTube posts can show up early because Rolino starts the private upload before
the public time. Describe those as "uploading ahead of its scheduled time".
