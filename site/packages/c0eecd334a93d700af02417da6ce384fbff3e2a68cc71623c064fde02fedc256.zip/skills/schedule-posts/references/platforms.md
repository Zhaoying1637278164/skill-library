# Platform rules in Rolino

Rolino's server validation and `get_post_readiness` are the source of truth. If
they disagree with this page, follow Rolino and tell the user.

## Caption limits

| Destination | Hard limit | How it's counted |
| --- | --- | --- |
| Instagram | 2,200 | characters |
| TikTok (video caption) | 2,200 | UTF-16 code units |
| YouTube description | 5,000 | UTF-8 bytes |
| LinkedIn member post | 3,000 | characters |
| Bluesky | 300 | graphemes |

Preferred or "sweet spot" lengths are writing guidance, not limits, unless the
user or brand says otherwise.

## Instagram

- Needs media: images or a Reel video.
- The connected account must meet Meta's publishing requirements.

## TikTok

- Call `refresh_delivery_options` for the exact account right before preparing
  settings.
- Choose direct publishing or an inbox (draft) handoff explicitly.
- For direct publishing, use a visibility value the refresh returned, and give
  explicit yes/no values for comments, duet, stitch, commercial content,
  own-brand promotion, third-party promotion, and AI-generated content. Never
  enable an interaction the refresh marks unavailable.
- Mark the settings as reviewed only after the user has reviewed those exact
  choices; that is separate from approving the draft itself.
- If "Everyone" isn't available, ask the user which available audience to use.
  Don't quietly switch to private or to an inbox draft.
- Changing the caption, media, or destinations clears the previous review.
- The inbox handoff doesn't carry the caption; Rolino keeps it for the user to
  copy.

## YouTube

- Exactly one stored video, plus explicit title, category, visibility,
  audience, disclosure, notification, and tag settings. The description is the
  YouTube caption override or the shared caption.
- Scheduling requires Public. Immediate publishing keeps the chosen Public,
  Unlisted, or Private visibility and never creates a schedule.
- Unaudited Google API projects may be limited to Private uploads; say so if
  readiness reports it.

## LinkedIn

- Posts as the member who connected the account, never as a Company Page.
  Confirm that member is the intended author.
- Text only, up to ten JPEG/PNG images, or exactly one MP4. Don't mix images and
  video. Follow the refreshed video size and duration limits.
- `LINKEDIN_PUBLISH_OUTCOME_UNKNOWN`: don't retry until the user checks their
  LinkedIn feed. The post may exist without Rolino having its ID.

## Bluesky

- Text, or up to four JPEG, PNG, or WebP images, each at most 2,000,000 bytes.
  No video, no link cards.
- Add image descriptions (alt text) for every image.
- To change a scheduled Bluesky post: cancel the schedule
  (`preview_post_schedule_cancellation` then
  `execute_post_schedule_cancellation`), update the draft, then preview and
  confirm a new schedule.

## Facebook Page

- Refresh delivery options for the exact Page and check that video is
  available.
- FEED: one MP4 or MOV in its original aspect ratio. REEL: one vertical 9:16
  MP4, at least 540×960, 3–90 seconds, 24–60 fps. Both are public. At most
  1 GB. Put links in the caption.

## Google Business Profile

- Text plus at most one stored JPEG or PNG. Confirm the selected location name
  in readiness.
- If the result is unknown, have the user check the Business Profile; don't
  resend.
