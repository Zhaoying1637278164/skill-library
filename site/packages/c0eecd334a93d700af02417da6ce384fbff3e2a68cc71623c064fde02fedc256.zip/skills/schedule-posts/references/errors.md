# Rolino errors and what to do

| Code | What it means | What to do |
| --- | --- | --- |
| `AUTH_REQUIRED` | The connector isn't signed in, or the session expired | Ask the user to reconnect Rolino from the plugin's Connectors tab and approve in the browser |
| `FORBIDDEN`, `SCOPE_REQUIRED` | The connection lacks the permission this action needs | Name the missing permission. The user must disconnect and reconnect, granting it. Never work around it |
| `BILLING_REQUIRED`, `LIMIT_REACHED` | Plan restriction | Tell the user and point them to https://getrolino.com/settings/billing |
| `CONNECTION_REQUIRED` | A social account is disconnected or unhealthy | Send the user to the project's Connections page in Rolino, then re-check `list_integration_health` |
| `VALIDATION_ERROR` | Input breaks a rule | Quote Rolino's message, re-read the post and readiness, and ask only for the missing decision or content |
| `CONFLICT` | The post changed since you read it, or a confirmation no longer matches | Re-read with `get_post`, then preview again. Never reuse an idempotency key with changed input |
| `RATE_LIMITED` | Too many requests | Wait `retryAfterSeconds` before trying again |
| `ACCOUNT_SELECTION_REQUIRED` | Several accounts match | Ask which account; don't fall back to another |
| Timeout or unknown provider result | The outcome is uncertain | Check state first (`get_post`, `check_post_delivery`). Never assume it failed and send a duplicate |

## Permissions the user may need to grant

Capabilities are chosen by the user on Rolino's consent screen. Existing
connections never gain new ones automatically.

- Posts: read, write, schedule, publish, and a separate delete permission
- `seo:read` for SEO reports and opportunities
- `backlinks:read`, `backlinks:write`, `backlinks:contacts` for backlink work
- `blog:read`, `blog:write`, `blog:manage`, `blog:approve`, `blog:publish` for
  Blog Studio, each independent
- `storage:read` and `media:delete` for storage and Media Library cleanup
- `website-analytics:read` and `website-analytics:manage` for Umami and Datafast
