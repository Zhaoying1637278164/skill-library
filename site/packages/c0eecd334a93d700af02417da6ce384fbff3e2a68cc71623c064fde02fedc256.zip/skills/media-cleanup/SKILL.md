---
name: media-cleanup
description: Check Rolino storage usage and safely remove unused files from the Media Library. Use when the user asks how much storage they're using, is near their storage limit, or wants to free space or clear out old uploads in Rolino.
---

# Rolino storage and Media Library cleanup

Reading storage needs `storage:read`; deleting needs the separate `media:delete`
permission. If either is missing, say so; the user grants it by reconnecting.

1. `get_storage_usage`: report stored bytes, upload reservations, space left,
   and what's pending deletion, in human units (MB, GB).
2. `list_media_assets` to see what's there.
3. `preview_media_cleanup` for specific asset IDs or one age filter.
   `olderThanDays` means upload age, not time since last use. The preview
   deletes nothing.
4. Show the exact cutoff, how many files would go, how many are excluded
   because they're in use, any with unknown size, and the space it would free.
   "Free up some space" is not approval of a specific cleanup; ask the user to
   confirm this exact preview.
5. After approval, `execute_media_cleanup` with the unchanged selection,
   digest, token, and a stable idempotency key.
6. Poll `get_media_cleanup_status` until it's done. Space is freed only when
   deletion completes. Files used by posts are never removed.
