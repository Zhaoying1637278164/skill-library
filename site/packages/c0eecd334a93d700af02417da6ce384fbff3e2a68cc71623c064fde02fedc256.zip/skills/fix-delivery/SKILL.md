---
name: fix-delivery
description: Investigate and recover a Rolino post that failed, got stuck, or has an uncertain publishing result. Use when the user says a post didn't go out, shows as failed or pending, may have been posted twice, or asks to retry, reschedule, or cancel a scheduled post.
---

# Recover a Rolino post delivery

The first rule: **find out what actually happened before doing anything
else.** A missing ID is not proof that nothing was posted, and a blind retry can
publish the same content twice to the user's audience.

## 1. Look

1. Resolve the project and post (`list_projects`, `list_posts` or the ID the
   user gives, then `get_post`). Note each destination's stage, any saved remote
   post ID, and the error.
2. `list_integration_health` for the project. An expired or disconnected account
   explains most failures; the fix is reconnecting in Rolino, not retrying.
3. `get_post_readiness` to see anything else blocking it.

## 2. Check the platform

Call `check_post_delivery` for an uncertain destination. It reads the platform's
record and updates Rolino from that evidence; it never uploads or publishes.

- A confirmed remote post: tell the user it's live and where.
- `UNKNOWN`: ask the user to look at the account itself (their feed, profile, or
  YouTube Studio) and tell you what they see. Don't retry until they have.
- `LINKEDIN_PUBLISH_OUTCOME_UNKNOWN`: always have the user check their LinkedIn
  feed first.

## 3. Recover

Pick the smallest action that fixes it, and preview it first:

- **Account problem:** have the user reconnect in Rolino, re-check health, then
  preview a new schedule or publish through the `schedule-posts` skill.
- **Existing YouTube video Rolino lost track of:** `preview_post_recovery` with
  `ATTACH` (links the video, publishes nothing) or `RESUME` (sets an explicit
  future `publishAt`, or `null` to publish now). Show the video, account, and
  consequence, then `execute_post_recovery` with identical values after
  approval. `QUEUED` means pending, not live. No new copy is ever uploaded.
- **Cancel a future schedule:** `preview_post_schedule_cancellation`, show which
  destinations return to Draft, then `execute_post_schedule_cancellation` after
  approval. If delivery already started or is uncertain, run
  `check_post_delivery` first.
- **Fix content and reschedule:** cancel, edit with `update_draft_post`, then
  preview and confirm a new schedule.
- **Delete an untouched draft:** `preview_draft_deletion`, confirm with the
  user, then `execute_draft_deletion`. This needs the separate delete
  permission.

Reuse the same idempotency key when retrying the same approved action. Change
nothing between preview and execute.

## 4. Report

Say per destination what happened, what you did, and what's still pending or
needs the user. Be plain about anything unresolved.
