---
name: seo-opportunities
description: Read Rolino's SEO reports, content opportunities, website analytics, and backlink prospects, and turn them into content. Use when the user asks what to write about next, wants their weekly SEO report, asks which topics or pages to improve, or wants help finding and preparing backlink outreach.
---

# SEO opportunities and backlinks in Rolino

This work needs optional permissions (`seo:read`, `website-analytics:read`, and
the `backlinks:*` set). Check `whoami`. If one is missing, say which, and that
the user grants it by reconnecting Rolino. Don't work around it.

## SEO reports and opportunities (read-only)

1. Resolve the project.
2. `list_seo_reports` then `get_seo_report` for the one the user wants, or
   `list_seo_opportunities` then `get_seo_opportunity` for a specific task.
   Only read IDs returned for the same project.
3. Each opportunity is either **Ready** or **Research**:
   - **Ready:** you can draft the full deliverables it lists. Return them for the
     user to review; don't publish anything.
   - **Research:** first check current search results, the intent, and the
     facts, then report it as validated or rejected. Don't draft the final piece
     in the same step.
4. When the user wants to act on one, hand off: social posts through the
   `schedule-posts` skill (as drafts), articles through `blog-studio`.

Summarize with the decision, the target, the evidence, the limitations, and the
success metric. Say where the evidence is thin rather than overstating it.

## Website analytics

`read_website_analytics` returns stored Umami or Datafast data and content
opportunities. Missing pages mean unknown, not zero. It has no search queries,
rankings, revenue, or conversions, so don't imply otherwise. Connecting,
syncing, or deleting analytics data uses the preview/execute tools and needs
`website-analytics:manage`. Deleting imported data is permanent in Rolino.
Never echo an API key.

## Backlinks

Rolino never sends email; everything it prepares is a draft for the user to send
themselves.

1. `start_backlink_discovery` for the project (no free-form queries), then poll
   `get_backlink_discovery`.
2. `list_backlink_prospects` and `get_backlink_prospect` to review. These omit
   emails and drafts.
3. For an approved prospect, `research_backlink_contact`. Use only a public
   contact Rolino returns with its source and checked date. Never guess or
   construct an email address.
4. `list_backlink_contacts` shows contacts and editable drafts (needs
   `backlinks:contacts`). Improve a draft with `update_backlink_outreach`.
5. Move a prospect along with `update_backlink_stage`. A prospect counts as won
   only after `verify_backlink` confirms the exact link to the user's page.
