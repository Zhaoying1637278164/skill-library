---
name: blog-studio
description: Plan, write, approve, and publish blog articles with Rolino Blog Studio. Use when the user wants a blog content plan, wants an article drafted or edited, asks to change their blogging cadence, or wants an approved article published or scheduled to their website.
---

# Rolino Blog Studio

Blog Studio has five independent permissions: `blog:read`, `blog:write`,
`blog:manage`, `blog:approve`, and `blog:publish`. Check what `whoami` reports.
If a step needs a permission the connection doesn't have, stop and tell the
user; they grant it by reconnecting Rolino. Approval never implies publication,
and publication never implies approval.

The blog plan is separate from the social calendar.

## Set up

1. `get_blog_setup_status` shows website, import, plan, and delivery readiness.
2. Ask for anything missing: the website, the posting cadence, the destination,
   and the access level the user wants you to have (review only, approve, or
   full publishing). Never invent a site URL or choose the access level.
3. `initialize_blog_site` imports the site as a background job. Poll
   `get_blog_job`; retry only a reported failure (`retry_blog_site_import`).
4. Destination setup (`list_blog_publishing_providers`,
   `list_blog_publishing_destinations`, and the connection preview/execute
   tools) is a separate task. Preview each change and confirm first. A
   one-time delivery token or signing secret goes only into the user's
   server environment, never into chat, logs, or files you share.

## Plan

1. Ask for the cadence, then `create_blog_plan` and poll `get_blog_job`.
2. `list_blog_plan_items`: show each title, type, evidence, and why it was
   chosen. Accept or dismiss with `set_blog_plan_item_state` only after the
   user has seen that evidence.
3. To change cadence: `preview_blog_plan_cadence`, show every date move and
   locked item, then `apply_blog_plan_cadence` with the unchanged values.

## Write

1. `create_blog_article_from_plan_item` from an accepted item.
2. Article generation costs credits. Call `generate_blog_article` with
   `previewOnly` first, show the exact charge, and send the confirmation only
   after the user agrees to the charge. Permission to write is not permission
   to spend credits.
3. Edit with `get_blog_article` then `update_blog_draft` using the current
   version. Each save is a new revision; use the internal links Rolino offers.
4. Image: `generate_blog_image` (optional `editorialBrief`, up to 500
   characters) or `upload_blog_image`, then `review_blog_image` with real alt
   text.

## Approve (needs `blog:approve`)

`preview_blog_revision_approval`, then show the revision, images, links, and
warnings. After the user approves, `execute_blog_revision_approval` with the
unchanged values. Without this permission, ask the user to approve in Rolino.

If the text or any image changes afterward, the approval is stale: start again
from the approval preview.

## Publish or schedule (needs `blog:publish`)

1. `preview_blog_publish` or `preview_blog_schedule` (future time plus IANA
   timezone). Show the revision, destination, time, and URL.
2. After approval, execute the matching tool with identical values.
3. Poll `list_blog_delivery_attempts` and confirm the live URL. Queued is not
   published.

To cancel a future schedule: `preview_blog_schedule_cancellation` then
`execute_blog_schedule_cancellation`. It never unpublishes a live article.
