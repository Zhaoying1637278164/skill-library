# FlowStudio Power Automate MCP Extension

Debug, build, and manage Microsoft Power Automate cloud flows via the FlowStudio MCP server.

## Requirements

- **Node.js 18+** and **npm** — required at runtime for `npx mcp-remote`
- A FlowStudio MCP API key — get one at https://mcp.flowstudio.app

## Setup

When you install this extension, Gemini CLI will prompt you for your
`FLOWSTUDIO_MCP_API_KEY`. The key is stored securely in your Gemini CLI settings.

## What you can do

- List flows in any Power Platform environment
- Debug failures with action-level inputs, outputs, and loop iterations
- Build and deploy new flows from natural language
- Trigger, resubmit, or cancel flow runs
- Inspect connections and environment configuration

## Links

- [FlowStudio](https://flowstudio.app)
- [MCP Server](https://mcp.flowstudio.app)
- [Getting Started](https://learn.flowstudio.app/mcp-getting-started)
