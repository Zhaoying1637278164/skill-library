# Stark Accessibility Plugin

Five persona accessibility agents, packaged as skills and bundled with the Stark MCP
server. Each skill turns Stark scan results into role-appropriate fixes and can set up new scans
— all scoped to the signed-in user's Stark workspace.

| Skill | Invoke | For | Owns these scans |
|---|---|---|---|
| `stark-frontend` | `/stark-accessibility:stark-frontend` | Web UI, HTML/ARIA, keyboard, focus | url, code, storybook, automated-test |
| `stark-backend` | `/stark-accessibility:stark-backend` | `lang`/metadata, SSR markup, error contracts | code, automated-test |
| `stark-mobile` | `/stark-accessibility:stark-mobile` | iOS/Android native a11y APIs | ios, android, code |
| `stark-design` | `/stark-accessibility:stark-design` | Contrast, color, target size, tokens (design language) | figma |
| `stark-pm` | `/stark-accessibility:stark-pm` | Posture, prioritization, compliance status, reporting | url (mostly read-only) |

Skills also auto-trigger when their description matches what you're doing; the slash commands
above are for explicit selection (e.g. forcing the mobile skill rather than the front-end one).

## The MCP server

`.mcp.json` connects the remote Stark MCP server over streamable HTTP:

```json
{ "mcpServers": { "stark": { "type": "http", "url": "https://mcp.getstark.ai/mcp" } } }
```

Authentication is OAuth, handled by the client on first connect — no token is stored in the
plugin. The server scopes every call to the signed-in user, and gates the `create-*` tools
behind the `edit:projects` permission - available to any non-viewer role. The skills are behavioral guidance; **the actual
enforcement (tenant isolation, the permission gate, write confirmation) lives in the server and
the Stark app, not in skill text.**

## How the shared core works

Skills don't inherit from one another, so the shared rules live in `shared/core-rules.md` (the
single source of truth) and each skill references it via `${CLAUDE_PLUGIN_ROOT}/shared/core-rules.md`.
Each skill also keeps a condensed copy of the critical guardrails in its own body, so the
safety-relevant rules are always in context when a persona is active — not only if the reference
file gets opened.
