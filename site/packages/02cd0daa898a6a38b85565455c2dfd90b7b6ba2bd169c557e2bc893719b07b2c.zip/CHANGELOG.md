# Changelog

## 0.1.0

- Initial public release: five persona accessibility skills (front-end, back-end, mobile,
  design, PM) backed by the Stark MCP server.
