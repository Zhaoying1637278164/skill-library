# Wyatt Agent Plugin

Connect Claude Code, Cursor, or Codex to your [Wyatt](https://www.wyattworks.ai) workspace.
The plugin uses Wyatt's remote MCP server and OAuth to work with workspace context, documents,
tasks, and background agents.

## What is included

- A portable [Agent Plugins 1.0](https://agent-plugins.org/) manifest for Cursor and other
  compatible clients.
- A native Cursor manifest that loads the Wyatt skills, `/wyatt` command, MCP server, and logo.
- Native Claude Code and Codex manifests.
- Skills for workspace orientation, document work, task management, and task delegation.
- Wyatt's production MCP server configuration and canonical brand assets.

## Install in Claude Code

```bash
claude plugin marketplace add luminpdf/wyatt-plugin
claude plugin install wyatt@wyatt
```

Complete the Wyatt OAuth sign-in when Claude prompts you.

## Cursor and Codex

This repository is the source package for Cursor Marketplace and OpenAI Plugins Directory
validation and submission. Installation from those clients will be available after their public
listings are approved.

For local Cursor testing:

```bash
cursor agent --plugin-dir /path/to/wyatt-plugin
```

The Cursor submission form logo URL is `https://www.wyattworks.ai/Logo.svg`.

## Authentication

The plugin connects to:

```text
https://www.wyattworks.ai/api/mcp-server
```

Approve the workspaces and access level you want the agent to use. Never paste API keys or access
tokens into the plugin or a chat.

## Try it

> Catch me up on my Wyatt workspace, then suggest the three most useful next actions.

## License

Apache-2.0. See [LICENSE](LICENSE).
