---
name: wyatt
description: Connect to your Wyatt workspace and get oriented.
---

Get me set up and oriented in my Wyatt workspace.

Follow the **wyatt-workspace** skill:

1. If a Wyatt call returns an authentication error, ask me to complete the Wyatt OAuth flow in
   this client, then retry.
2. Call `list_workspaces`. If there is exactly one result, use it. If there are several and I
   named one in "$ARGUMENTS", match it; otherwise show the choices and ask which one to use.
3. Call `get_workspace_overview` for that workspace.
4. Give me a concise orientation covering recent work, important open tasks, and two to four
   useful next actions. Then proceed with anything else I asked for.
