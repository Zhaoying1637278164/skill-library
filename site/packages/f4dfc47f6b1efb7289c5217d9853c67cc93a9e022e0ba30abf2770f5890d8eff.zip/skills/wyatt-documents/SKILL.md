---
name: wyatt-documents
description: Find, read, summarize, create, and safely edit markdown documents in a Wyatt workspace. Use when the user wants to locate workspace knowledge, work with a Wyatt document, or save new material into Wyatt.
---

# Wyatt documents

Use the `wyatt` MCP server for document work. Resolve a `workspace_id` with `list_workspaces`
before calling workspace-scoped tools.

## Find and read

- Use `search` for workspace search. It searches document content by default; pass `entity_types`
  only when the request should also include PDFs or database tables.
- Use `list_documents` when the user wants to browse. Follow `next_cursor` when more results are
  needed.
- Once you have a document id, call `get_document` to read its markdown content.

Summarize the relevant material instead of echoing a whole document unless the user asks for it.
If `content_complete` is false, say that the document was truncated.

## Create

Call `create_document` with `workspace_id`, `title`, and optional markdown `content`. Use clean,
idiomatic markdown and report the returned document id.

## Update safely

Choose the narrowest `update_document` command:

- `edit` with `edits` for targeted text replacements. Read the document first and copy
  `old_str` from its visible text. Matches cannot span blocks.
- `append` with `content` to add markdown blocks at the end.
- `replace` with `content` only when the whole body should be replaced.

For a material rewrite, show the proposed result before saving unless the user has already given
clear approval. If an edit or append reports a partial application, read the document again before
retrying.

## Delete carefully

`delete_document` permanently removes the document. Confirm with the user first and name the exact
document. Do not delete when the request is ambiguous.

Pass `workspace_id` and `document_id` values back exactly as returned. On an authorization error,
ask the user to complete the Wyatt OAuth flow in their current client and retry.
