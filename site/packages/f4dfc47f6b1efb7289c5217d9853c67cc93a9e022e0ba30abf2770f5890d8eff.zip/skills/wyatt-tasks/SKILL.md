---
name: wyatt-tasks
description: Inspect, create, update, and resolve tasks in a Wyatt workspace, understand prioritized next actions, and delegate durable work to a background Wyatt agent. Use when the user asks what is on their plate, wants task status, wants to add or complete a Wyatt task, or asks Wyatt to run work asynchronously.
---

# Wyatt tasks and background agents

Use the `wyatt` MCP server for task work and durable background work. Resolve the target
`workspace_id` first.

## Understand the work

- `get_workspace_context_next` returns current tasks, the workspace digest, and prioritized next
  actions together.
- `list_tasks` returns the broader task list. It can filter by status, assignee, priority, or
  update time and supports cursor pagination.
- `get_task` returns full detail, recent comments, and links for one task.

Summarize for a human: lead with blocked and in-progress work, group by status, and avoid dumping
raw JSON.

## Act on tasks

These tools mirror what Wyatt's own in-app agent can do, so anything the user could ask Wyatt to
do with a task is available here.

- `create_task` with `workspace_id` and `title`. Optional: `description`, `priority`
  (`low`, `medium`, `high`, `urgent`; default `medium`), `type` (`task`, `bug`, `feature`,
  `question`, `action`; default `task`), `due_at` (ISO 8601 — always set it for reminders),
  `blocking`, `assigned_member_id`, `group_id`.
- `update_task` with `workspace_id`, `task_id`, and at least one change: `title`, `description`,
  `status` (`open`, `in_progress`, `blocked`), `priority`, `type`, `due_at` (empty string clears
  it), `blocking`, `assigned_member_id`. Do not set status to resolved here.
- `resolve_task` with `workspace_id`, `task_id`, and `resolution` (`completed`, `wont_do`,
  `duplicate`, `invalid`) to complete a task.
- `delete_task` permanently removes a task. Confirm with the user first and name the exact task.

Report the returned task id and title after a mutation. When the user says "done" or "finished"
about a task, resolve it as `completed` rather than deleting it.

## Delegate durable work

`kickoff_background_agent` starts a persisted asynchronous Wyatt run inside the workspace.

1. Confirm the user's intent unless they already clearly asked for the kickoff.
2. Write a self-contained prompt with the goal, relevant workspace context, constraints, and a
   concrete definition of done. The background run does not inherit this conversation.
3. Pass `model` only when the user explicitly specifies one.
4. Report what started and how to follow it in Wyatt. Do not claim the asynchronous run has
   finished or invent results.

Use background agents for work that should outlive this session. Handle quick reads, task
updates, and document edits directly. Pass all returned IDs back exactly.
