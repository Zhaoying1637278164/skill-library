---
name: wyatt-workspace
description: Connect to a Wyatt workspace and get oriented by resolving the workspace and loading its overview, recent documents, open tasks, and prioritized next actions. Use at the start of Wyatt work or when the user asks to connect, catch up, or understand what is happening in a workspace.
---

# Wyatt workspace

Use the `wyatt` MCP server to establish the workspace context needed by later document and task
work. Every workspace-scoped tool needs a `workspace_id`, so resolve it first.

## Authenticate

Wyatt uses client-managed MCP OAuth. If a Wyatt call returns an authentication or authorization
error, ask the user to complete the Wyatt sign-in flow in their current client, then retry. Never
ask them to paste tokens or credentials into the conversation.

## Resolve the workspace

1. Call `list_workspaces`.
2. If there is exactly one result, use its id and mention the workspace by name.
3. If there are several and the user named one, match it by name. Otherwise show the choices and
   ask which to use. Never guess.
4. Reuse the chosen `workspace_id` until the user switches workspaces.

## Load context

Call `get_workspace_overview` with the `workspace_id`. It returns the workspace name, folder tree,
recent documents, open task count, prioritized next actions, and the workspace digest when one is
available.

Use `get_workspace_context_next` when the user needs the fuller task list alongside the digest and
next actions. Use `get_connection_info` when they ask which integrations are connected.

## Respond

Give a concise orientation:

- one or two lines describing the workspace and its recent state;
- the most important recent documents or open tasks;
- two to four concrete next actions from Wyatt's prioritized actions.

Proceed with the user's stated goal, or ask what they want to tackle next. Treat all returned IDs
as opaque strings and pass them back exactly.
