"""Insights engine: baseline, rules, rendering."""
from conftest import assistant, usage, user, write_jsonl

# Isolated table for helpers that take a pricing dict — not the bundled file
# and not an in-code DEFAULT_PRICING copy.
PRICING = {"claude-fable-5": {"input": 10.0, "output": 50.0}}


def _agg(tu, entries, tmp_path, name="x"):
    t = write_jsonl(tmp_path / f"{name}.jsonl", entries)
    return tu.aggregate(tu.parse_session(t), tu.load_pricing())


BASE = {"sessions": 10, "median_session_cost": 1.0,
        "commands": {"/go": {"sessions": 10, "median_cost": 0.5,
                             "median_cache_ratio": 0.9}}}
THIN = {"sessions": 2, "median_session_cost": 1.0, "commands": {}}


def _session(tmp_path, name, out_tokens, ts="2026-07-01T10:00:00Z", project="p"):
    return write_jsonl(tmp_path / "projects" / project / f"{name}.jsonl", [
        user(ts, command="/go"),
        assistant(ts, usage(inp=100, out=out_tokens, cache_read=1000), request_id="r1"),
    ])


def test_median(tu):
    assert tu._median([]) is None
    assert tu._median([3.0]) == 3.0
    assert tu._median([1.0, 3.0]) == 2.0
    assert tu._median([1.0, 2.0, 9.0]) == 2.0


def test_cache_ratio(tu):
    u = tu.empty_usage()
    assert tu.cache_ratio(u) is None
    u.update(cache_read=900, input=50, cache_5m=50)
    assert tu.cache_ratio(u) == 0.9


def test_finding_shape(tu):
    f = tu.finding("cost-outlier", "warn", "msg", ratio=2.5)
    assert f == {"rule": "cost-outlier", "severity": "warn",
                 "message": "msg", "data": {"ratio": 2.5}}


def test_compute_baseline(tu, monkeypatch, tmp_path):
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    ts = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    for i, out in enumerate([1000, 2000, 3000, 4000, 5000]):
        _session(tmp_path, f"s{i}", out, ts=ts)
    current = _session(tmp_path, "current", 99000, ts=ts)
    b = tu.compute_baseline(tu.load_pricing(), project="p", exclude=str(current))
    assert b["sessions"] == 5                     # excludes the current transcript
    assert b["median_session_cost"] is not None
    assert b["commands"]["/go"]["sessions"] == 5
    assert 0 < b["commands"]["/go"]["median_cache_ratio"] < 1


def test_compute_baseline_scopes_to_project(tu, monkeypatch, tmp_path):
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    ts = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    _session(tmp_path, "mine", 1000, ts=ts, project="p")
    _session(tmp_path, "other", 1000, ts=ts, project="q")
    b = tu.compute_baseline(tu.load_pricing(), project="p")
    assert b["sessions"] == 1


def test_cost_outlier_warn_info_and_quiet(tu, tmp_path):
    big = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                    assistant("2026-07-01T10:00:05Z", usage(out=70000), request_id="r1")],
               tmp_path, "big")        # 70k out on fable-5 = $3.50 = 3.5x median
    rules = {f["rule"]: f for f in tu.session_insights(big, BASE)}
    assert rules["cost-outlier"]["severity"] == "warn"
    assert "3.5×" in rules["cost-outlier"]["message"]
    mid = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                    assistant("2026-07-01T10:00:05Z", usage(out=44000), request_id="r1")],
               tmp_path, "mid")        # $2.20 = 2.2x -> info
    assert {f["rule"]: f for f in tu.session_insights(mid, BASE)}["cost-outlier"]["severity"] == "info"
    small = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                      assistant("2026-07-01T10:00:05Z", usage(out=2000), request_id="r1")],
                 tmp_path, "small")    # $0.10 -> quiet
    assert "cost-outlier" not in {f["rule"] for f in tu.session_insights(small, BASE)}


def test_cost_outlier_skipped_on_thin_baseline(tu, tmp_path):
    big = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                    assistant("2026-07-01T10:00:05Z", usage(out=70000), request_id="r1")],
               tmp_path, "big2")
    assert "cost-outlier" not in {f["rule"] for f in tu.session_insights(big, THIN)}


def test_cache_regression_fires_and_respects_norm(tu, tmp_path):
    # all-input, no cache reads: ratio 0.0 vs norm 0.9 -> warn
    cold = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                     assistant("2026-07-01T10:00:05Z", usage(inp=5000, out=10), request_id="r1")],
                tmp_path, "cold")
    rules = {f["rule"] for f in tu.session_insights(cold, BASE)}
    assert "cache-regression" in rules
    warm = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                     assistant("2026-07-01T10:00:05Z",
                               usage(inp=100, out=10, cache_read=9000), request_id="r1")],
                tmp_path, "warm")      # ratio ~0.99 -> quiet
    assert "cache-regression" not in {f["rule"] for f in tu.session_insights(warm, BASE)}


def test_adhoc_dominance(tu, tmp_path):
    heavy = _agg(tu, [user("2026-07-01T10:00:00Z", "just chatting"),
                      assistant("2026-07-01T10:00:05Z", usage(out=60000), request_id="r1"),
                      user("2026-07-01T11:00:00Z", command="/go"),
                      assistant("2026-07-01T11:00:05Z", usage(out=1000), request_id="r2")],
                 tmp_path, "adhoc")
    f = {f["rule"]: f for f in tu.session_insights(heavy, THIN)}["adhoc-dominance"]
    assert f["severity"] == "info" and "ad-hoc" in f["message"]


def test_findings_sorted_warn_first(tu, tmp_path):
    big = _agg(tu, [user("2026-07-01T10:00:00Z", "chat"),
                    assistant("2026-07-01T10:00:05Z", usage(inp=5000, out=70000), request_id="r1")],
               tmp_path, "sortcheck")
    found = tu.session_insights(big, BASE)
    sevs = [f["severity"] for f in found]
    assert sevs == sorted(sevs, key=lambda s: {"warn": 0, "info": 1}[s])


def test_unpriced_models_rule(tu, tmp_path):
    a = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                  assistant("2026-07-01T10:00:05Z", usage(out=100),
                            model="claude-mystery-9", request_id="r1")],
             tmp_path, "unpriced")
    f = {f["rule"]: f for f in tu.session_insights(a, THIN)}["unpriced-models"]
    assert f["severity"] == "warn"
    assert "claude-mystery-9" in f["message"] and "pricing.json" in f["message"]


def test_agent_fanout_rule(tu, tmp_path):
    t = write_jsonl(tmp_path / "fan.jsonl", [
        user("2026-07-01T10:00:00Z", command="/go"),
        assistant("2026-07-01T10:00:05Z", usage(out=1000), request_id="r1"),
    ])
    write_jsonl(tmp_path / "fan" / "subagents" / "agent-1.jsonl", [
        assistant("2026-07-01T10:01:00Z", usage(out=50000), request_id="a1"),
    ])
    data = tu.aggregate(tu.parse_session(t), tu.load_pricing())
    f = {f["rule"]: f for f in tu.session_insights(data, THIN)}["agent-fanout"]
    assert f["severity"] == "info" and "/go" in f["message"] and "subagent" in f["message"]


def test_budget_pace_rule(tu, tmp_path):
    a = _agg(tu, [user("2026-07-01T10:00:00Z", command="/go"),
                  assistant("2026-07-01T10:00:05Z", usage(out=160000), request_id="r1")],
             tmp_path, "pace")   # $8.00 on fable-5
    f = {f["rule"]: f for f in tu.session_insights(a, THIN, budget=10.0)}["budget-pace"]
    assert "$8.00" in f["message"] and "$10.00" in f["message"]
    # over budget: the hook already nudged — insights stays quiet
    assert "budget-pace" not in {f["rule"] for f in tu.session_insights(a, THIN, budget=5.0)}
    # no budget set
    assert "budget-pace" not in {f["rule"] for f in tu.session_insights(a, THIN)}


def _summary(ts, cost, label_costs=None, by_model=None):
    return {"first_ts": ts, "total": {"cost_usd": cost, "usage": {}},
            "by_label": {k: {"cost_usd": v, "usage": {}, "invocations": 1}
                         for k, v in (label_costs or {}).items()},
            "by_model": by_model or {}}


CUTOFF, NOW = "2026-07-01T00:00:00Z", "2026-07-11T00:00:00Z"  # midpoint 07-06


def test_spend_trend_warn_and_direction(tu):
    ss = [_summary("2026-07-02T10:00:00Z", 10.0),
          _summary("2026-07-08T10:00:00Z", 20.0)]
    f = {f["rule"]: f for f in tu.window_insights(ss, CUTOFF, PRICING, now=NOW)}
    assert f["spend-trend"]["severity"] == "warn" and "up" in f["spend-trend"]["message"]
    down = [_summary("2026-07-02T10:00:00Z", 20.0),
            _summary("2026-07-08T10:00:00Z", 14.0)]   # -30% -> info
    f = {f["rule"]: f for f in tu.window_insights(down, CUTOFF, PRICING, now=NOW)}
    assert f["spend-trend"]["severity"] == "info" and "down" in f["spend-trend"]["message"]


def test_spend_trend_quiet_when_flat_or_empty_first_half(tu):
    flat = [_summary("2026-07-02T10:00:00Z", 10.0),
            _summary("2026-07-08T10:00:00Z", 11.0)]
    assert "spend-trend" not in {f["rule"] for f in
                                 tu.window_insights(flat, CUTOFF, PRICING, now=NOW)}
    empty = [_summary("2026-07-08T10:00:00Z", 11.0)]
    assert tu.window_insights(empty, CUTOFF, PRICING, now=NOW) == []


def test_top_mover(tu):
    ss = [_summary("2026-07-02T10:00:00Z", 10.0, {"/review": 1.0}),
          _summary("2026-07-08T10:00:00Z", 22.0, {"/review": 11.0})]
    f = {f["rule"]: f for f in tu.window_insights(ss, CUTOFF, PRICING, now=NOW)}
    assert "/review" in f["top-mover"]["message"]


def test_window_unpriced(tu):
    ss = [_summary("2026-07-02T10:00:00Z", 1.0,
                   by_model={"claude-mystery-9": dict(tu.empty_usage(), output=100)})]
    f = {f["rule"]: f for f in tu.window_insights(ss, CUTOFF, PRICING, now=NOW)}
    assert "claude-mystery-9" in f["unpriced-models"]["message"]


def test_window_insights_bare_date_cutoff_default_now(tu):
    # since_cutoff passes bare YYYY-MM-DD through; must not crash with now=None
    ss = [_summary("2026-07-02T10:00:00Z", 10.0)]
    assert isinstance(tu.window_insights(ss, "2026-07-01", PRICING), list)


def test_window_insights_timestampless_sessions_excluded_from_halves(tu):
    ss = [_summary(None, 100.0),                       # must not inflate either half
          _summary("2026-07-02T10:00:00Z", 10.0),
          _summary("2026-07-08T10:00:00Z", 20.0)]      # +100% -> warn still fires
    f = {f["rule"]: f for f in tu.window_insights(ss, CUTOFF, PRICING, now=NOW)}
    assert f["spend-trend"]["severity"] == "warn"
    assert f["spend-trend"]["data"]["first_half"] == 10.0


import json as jsonlib
import os
import subprocess
import sys


def test_render_insights_empty_and_lines(tu):
    assert tu.render_insights({"findings": []}) == "No notable findings."
    r = {"findings": [tu.finding("x", "warn", "watch out"),
                      tu.finding("y", "info", "fyi")]}
    assert tu.render_insights(r) == "- [warn] watch out\n- [info] fyi"


def test_render_insights_names_the_session_in_both_branches(tu):
    # Which session was measured matters most when discovery guessed it, and
    # "nothing to report" is exactly when the reader has no other clue.
    path = "/home/u/.claude/projects/-Users-x-alpha/aaa-111.jsonl"
    assert tu.render_insights({"findings": [], "transcript_path": path}) == \
        "No notable findings. (session: -Users-x-alpha/aaa-111.jsonl)"
    r = {"findings": [tu.finding("x", "warn", "watch out")], "transcript_path": path}
    assert tu.render_insights(r) == \
        "- [warn] watch out\n(session: -Users-x-alpha/aaa-111.jsonl)"
    # Window mode has no session to name, so the bare sentence stands.
    assert tu.render_insights({"findings": [], "mode": "window",
                               "baseline": {"sessions": 3}}) == "No notable findings."


def test_run_insights_session_mode(tu, monkeypatch, tmp_path):
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    ts = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    for i in range(5):
        _session(tmp_path, f"s{i}", 2000, ts=ts)          # ~$0.10 median
    current = _session(tmp_path, "current", 70000, ts=ts)  # $3.50
    r = tu.run_insights(transcript=current)
    assert r["mode"] == "session"
    assert "cost-outlier" in {f["rule"] for f in r["findings"]}
    assert r["baseline"]["sessions"] == 5


def test_session_mode_discloses_unreadable_baseline_transcripts(tu, monkeypatch, tmp_path):
    # Session mode is entirely baseline-driven: transcripts the corpus scan
    # cannot read thin the baseline out, and below
    # INSIGHT_MIN_BASELINE_SESSIONS every baseline rule stops firing. "No
    # notable findings" then means "we could not look" -- say which files.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    ts = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    for i in range(5):
        _session(tmp_path, f"s{i}", 2000, ts=ts)
    current = _session(tmp_path, "current", 70000, ts=ts)
    assert tu.run_insights(transcript=current)["findings"]      # baseline intact
    broken = []
    for name in ("s0", "s1"):                                   # unreadable: directories
        f = tmp_path / "projects" / "p" / f"{name}.jsonl"
        f.unlink()
        f.mkdir()
        broken.append(str(f))
    r = tu.run_insights(transcript=current)
    assert r["findings"] == []                                  # baseline now too thin
    assert r["baseline"]["sessions"] == 3
    assert sorted(r["skipped_transcripts"]) == sorted(broken)
    out = tu.render_insights(r)
    assert out.startswith("No notable findings. (session: p/current.jsonl)")
    assert "2 transcript(s) skipped (unreadable)" in out
    assert broken[0] in out


def test_run_insights_window_mode(tu, monkeypatch, tmp_path):
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    old = (datetime.now(timezone.utc) - timedelta(days=8)).strftime("%Y-%m-%dT%H:%M:%SZ")
    new = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    _session(tmp_path, "old", 20000, ts=old)
    _session(tmp_path, "new", 60000, ts=new)
    r = tu.run_insights(since="10d")
    assert r["mode"] == "window"
    assert "spend-trend" in {f["rule"] for f in r["findings"]}


def test_insights_cli_json(tu, monkeypatch, tmp_path):
    t = write_jsonl(tmp_path / "projects" / "p" / "s.jsonl", [
        user("2026-07-01T10:00:00Z", command="/go"),
        assistant("2026-07-01T10:00:05Z", usage(out=100), request_id="r1"),
    ])
    env = {"TOKEN_USAGE_PROJECTS_DIR": str(tmp_path / "projects"),
           "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "cache"),
           "XDG_CONFIG_HOME": os.environ["XDG_CONFIG_HOME"],
           "PATH": "/usr/bin:/bin"}
    out = subprocess.run([sys.executable, str(tu.__file__ if hasattr(tu, "__file__")
                          else "scripts/token_usage.py"), "insights", str(t), "--json"],
                         capture_output=True, text=True, env=env, check=False)
    assert out.returncode == 0
    data = jsonlib.loads(out.stdout)
    assert data["mode"] == "session" and isinstance(data["findings"], list)


def test_insights_cli_rejects_transcript_plus_since(tu, tmp_path):
    import subprocess
    import sys
    out = subprocess.run([sys.executable, "scripts/token_usage.py", "insights",
                          str(tmp_path / "x.jsonl"), "--since", "7d"],
                         capture_output=True, text=True, check=False)
    assert out.returncode != 0 and "--since" in out.stderr


def test_cursor_session_rejects_mismatched_runtime(tu, tmp_path, monkeypatch):
    from test_cursor_adapter import build_cursor_tree

    cursor_root = tmp_path / "cursor-user"
    build_cursor_tree(cursor_root, composer_id="comp-zero")
    monkeypatch.setenv("TOKEN_USAGE_CURSOR_DIR", str(cursor_root))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    session = next(tu.get_runtime_adapter("cursor").iter_sessions())
    import pytest
    with pytest.raises(SystemExit, match="CursorSession.*cursor"):
        tu.run_insights(transcript=session, runtime="claude")


def test_cursor_insights_activity_only_no_cost_findings(tu, tmp_path, monkeypatch):
    from test_cursor_adapter import build_cursor_tree

    cursor_root = tmp_path / "cursor-user"
    zero_headers = [
        {"bubbleId": "zero-user", "type": 1},
        {"bubbleId": "zero-asst", "type": 2},
    ]
    build_cursor_tree(
        cursor_root,
        composer_id="comp-zero",
        bubble_headers=zero_headers,
    )
    monkeypatch.setenv("TOKEN_USAGE_CURSOR_DIR", str(cursor_root))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))

    adapter = tu.get_runtime_adapter("cursor")
    session = next(adapter.iter_sessions())
    r = tu.run_insights(transcript=session, runtime="cursor")
    assert r["runtime"] == "cursor"
    assert r.get("measurement") == "activity_only"
    cost_rules = {"cost-outlier", "budget-pace", "spend-trend", "top-mover", "adhoc-dominance"}
    assert cost_rules.isdisjoint({f["rule"] for f in r["findings"]})
    parsed = adapter.parse(session)
    assert sum(tu.sum_buckets(s["by_model"])["requests"] for s in parsed["segments"]) >= 1


def test_insights_cli_rejects_project_without_since(tu, tmp_path):
    # --project only filters the window scan; in session mode it was dropped
    # in silence, so `insights --project alpha` reported on whichever session
    # discovery happened to find.
    out = subprocess.run([sys.executable, "scripts/token_usage.py", "insights",
                          "--project", "alpha"],
                         capture_output=True, text=True, check=False)
    assert out.returncode != 0
    assert "--project applies to window mode (use --since)" in out.stderr


def test_render_insights_all_clear_states_what_was_examined(tu):
    # An empty findings list is also what "the rules could not run" looks like.
    # Window mode that matched no sessions at all, and a session-mode baseline
    # below INSIGHT_MIN_BASELINE_SESSIONS (rules 1-2 off), must not read as a
    # clean bill of health.
    assert tu.render_insights({"findings": [], "mode": "window",
                               "baseline": {"sessions": 0, "since": "7d"}}) == \
        "No sessions in window — nothing was scanned."
    # A window that did scan sessions and found nothing is a real all-clear.
    assert tu.render_insights({"findings": [], "mode": "window",
                               "baseline": {"sessions": 4, "since": "7d"}}) == \
        "No notable findings."
    path = "/home/u/.claude/projects/-Users-x-p/current.jsonl"
    assert tu.render_insights({"findings": [], "mode": "session",
                               "transcript_path": path,
                               "baseline": {"sessions": 1}}) == \
        ("No notable findings. (session: -Users-x-p/current.jsonl) "
         "(baseline: 1 prior session(s); the comparison rules need 5)")
    # At the threshold the rules did run, so the plain sentence stands.
    assert tu.render_insights({"findings": [], "mode": "session",
                               "transcript_path": path,
                               "baseline": {"sessions": 5}}) == \
        "No notable findings. (session: -Users-x-p/current.jsonl)"
    # A thin baseline is news in BOTH branches. The rules that need no
    # baseline (ad-hoc dominance, unpriced models) fire happily on a young
    # project, so a non-empty findings list is not evidence that the
    # comparison rules ran -- and if the qualifier only ever appeared on the
    # empty branch, its absence would mean nothing.
    r = {"findings": [tu.finding("x", "warn", "watch out")], "mode": "session",
         "transcript_path": path, "baseline": {"sessions": 1}}
    assert tu.render_insights(r) == (
        "- [warn] watch out\n(session: -Users-x-p/current.jsonl) "
        "(baseline: 1 prior session(s); the comparison rules need 5)")
    # No transcript path to name: the qualifier still has to land.
    assert tu.render_insights({"findings": [tu.finding("x", "info", "fyi")],
                               "mode": "session", "baseline": {"sessions": 0}}) == (
        "- [info] fyi\n(baseline: 0 prior session(s); the comparison rules need 5)")
    # Window mode: rules 7-8 are gated on the window's FIRST half having spend,
    # so a window longer than the project's history switches them off just as
    # silently as a thin session baseline did.
    assert tu.render_insights({"findings": [], "mode": "window",
                               "baseline": {"sessions": 6, "since": "30d",
                                            "first_half_cost": 0.0}}) == (
        "No notable findings. (baseline: no spend in the window's first half; "
        "the trend rules need both halves)")
    assert tu.render_insights({"findings": [tu.finding("x", "warn", "watch out")],
                               "mode": "window",
                               "baseline": {"sessions": 6, "since": "30d",
                                            "first_half_cost": 0.0}}) == (
        "- [warn] watch out\n(baseline: no spend in the window's first half; "
        "the trend rules need both halves)")
    # Both halves have spend: the rules ran, so nothing is qualified.
    assert tu.render_insights({"findings": [], "mode": "window",
                               "baseline": {"sessions": 6, "since": "30d",
                                            "first_half_cost": 1.5}}) == \
        "No notable findings."


def test_window_mode_empty_scan_says_nothing_was_scanned(tu, monkeypatch, tmp_path):
    # A projects dir that does not exist, and a --project matching no slug:
    # both scan zero sessions and both used to print a confident all-clear.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "nope"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    r = tu.run_insights(since="7d")
    assert r["baseline"]["sessions"] == 0 and r["findings"] == []
    # ...and when the reason is that there is no corpus at all, say so: an
    # empty scan of a real projects dir and a mistyped one read identically.
    assert tu.render_insights(r) == (
        "No sessions in window — nothing was scanned.\n\n"
        f"No readable Claude Code projects directory at {tmp_path / 'nope'} — nothing was scanned.")

    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    _session(tmp_path, "s0", 2000)
    assert tu.render_insights(tu.run_insights(since="2026-01-01",
                                              project="no-such-project")) == \
        "No sessions in window — nothing was scanned."


def test_session_mode_thin_baseline_is_disclosed(tu, monkeypatch, tmp_path):
    # One prior session in the project: rule 1 cannot fire however extreme the
    # current session is, so the all-clear has to say the baseline is too thin.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    ts = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    _session(tmp_path, "s0", 100, ts=ts)                     # ~$0.005
    current = _session(tmp_path, "current", 2000000, ts=ts)  # $100.00, 1000x
    r = tu.run_insights(transcript=current)
    assert r["findings"] == [] and r["baseline"]["sessions"] == 1
    assert tu.render_insights(r) == (
        "No notable findings. (session: p/current.jsonl) "
        "(baseline: 1 prior session(s); the comparison rules need 5)")


def test_session_mode_thin_baseline_is_disclosed_alongside_findings(tu, monkeypatch,
                                                                    tmp_path):
    # The rules that fire on a young project need no baseline, so the ones
    # that DO need one go off in silence unless the render says so. Here a
    # 10,000x session is all ad-hoc: rule 3 fires, rule 1 cannot, and without
    # the qualifier the reader is handed one [info] line as the whole story.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    ts = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    _session(tmp_path, "s0", 200, ts=ts)                    # ~$0.01
    current = write_jsonl(tmp_path / "projects" / "p" / "current.jsonl", [
        user(ts),                                           # no command: ad-hoc
        assistant(ts, usage(inp=100, out=2000000, cache_read=1000), request_id="r1"),
    ])
    r = tu.run_insights(transcript=current)
    assert {f["rule"] for f in r["findings"]} == {"adhoc-dominance"}
    assert r["baseline"]["sessions"] == 1
    assert tu.render_insights(r).endswith(
        "(session: p/current.jsonl) "
        "(baseline: 1 prior session(s); the comparison rules need 5)")


def test_window_shorter_than_history_discloses_the_empty_first_half(tu, monkeypatch,
                                                                    tmp_path):
    # Every session inside the window's second half -> c1 == 0 -> rules 7 and 8
    # cannot fire whatever the spend. That is "the rules could not run", not a
    # clean bill of health.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    for i in range(6):
        ts = (datetime.now(timezone.utc)
              - timedelta(days=1, minutes=i)).strftime("%Y-%m-%dT%H:%M:%SZ")
        _session(tmp_path, f"s{i}", 4000, ts=ts)
    r = tu.run_insights(since="30d")
    assert r["baseline"]["sessions"] == 6
    assert r["baseline"]["first_half_sessions"] == 0
    assert r["baseline"]["first_half_cost"] == 0.0
    assert r["findings"] == []
    assert r["baseline"]["first_half_spend"] is False
    # first_half_sessions == 0 is the sharper of the two silences: there was
    # nothing in the first half to compare, not sessions that spent nothing.
    assert tu.render_insights(r) == (
        "No notable findings. (baseline: no sessions in the window's first half; "
        "the trend rules need both halves)")


def test_window_with_both_halves_populated_is_not_qualified(tu, monkeypatch, tmp_path):
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    from datetime import datetime, timedelta, timezone
    now = datetime.now(timezone.utc)
    for i, days in enumerate([9, 8, 1]):
        ts = (now - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
        _session(tmp_path, f"s{i}", 4000, ts=ts)
    r = tu.run_insights(since="10d")
    assert r["baseline"]["first_half_sessions"] == 2
    assert r["baseline"]["first_half_cost"] > 0
    assert "baseline:" not in tu.render_insights(r)


def _at(days_ago):
    from datetime import datetime, timedelta, timezone
    return (datetime.now(timezone.utc)
            - timedelta(days=days_ago)).strftime("%Y-%m-%dT%H:%M:%SZ")


def test_window_caveat_never_contradicts_the_rules_that_ran(tu, tmp_path, monkeypatch):
    # run_insights stored round(half_cost(first), 6) while window_insights
    # gated rules 7-8 on the unrounded value, so a first half holding under
    # ~$5e-7 (a few cache-read tokens) printed a spend-trend finding directly
    # above "(baseline: no spend in the window's first half)".
    proj = tmp_path / "projects"
    early, late = _at(20), _at(1)
    write_jsonl(proj / "p" / "s0.jsonl", [
        user(early, command="/go"),
        assistant(early, usage(cache_read=1), model="claude-fable-5-1", request_id="r1"),
    ])
    write_jsonl(proj / "p" / "s1.jsonl", [
        user(late, command="/go"),
        assistant(late, usage(out=120_000), model="claude-fable-5-1", request_id="r2"),
    ])
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(proj))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    r = tu.run_insights(since="30d")
    assert r["baseline"]["first_half_cost"] == 0.0        # 1 cache-read token, 6dp
    assert r["baseline"]["first_half_spend"] is True      # ...but the rules ran on it
    assert [f["rule"] for f in r["findings"] if f["rule"] == "spend-trend"] == ["spend-trend"]
    assert "no spend in the window's first half" not in tu.render_insights(r)


def test_window_is_split_once(tu, tmp_path, monkeypatch):
    # run_insights and window_insights each called window_halves with their
    # own datetime.now(), so the two midpoints could differ by a second and
    # the disclosure could describe a different split from the rules'.
    proj = tmp_path / "projects"
    write_jsonl(proj / "p" / "s0.jsonl", [
        user(_at(1), command="/go"),
        assistant(_at(1), usage(out=1000), request_id="r1"),
    ])
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(proj))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    calls = []
    real = tu.window_halves

    def counting(*a, **kw):
        calls.append(kw.get("now"))
        return real(*a, **kw)

    monkeypatch.setattr(tu, "window_halves", counting)
    tu.run_insights(since="30d")
    assert len(calls) == 1


def test_window_caveat_distinguishes_no_sessions_from_no_spend(tu):
    # The caveat keys off the same predicate the rules use (first_half_spend),
    # not a rounded cost, and first_half_sessions tells the reader which of
    # the two silences they are looking at.
    def caveat(**baseline):
        return tu.insights_caveat({"mode": "window", "findings": [],
                                   "baseline": dict({"sessions": 6, "since": "30d"},
                                                    **baseline)})
    assert caveat(first_half_cost=0.0, first_half_spend=True) == ""
    assert caveat(first_half_cost=0.0, first_half_spend=False, first_half_sessions=0) == (
        "(baseline: no sessions in the window's first half; "
        "the trend rules need both halves)")
    assert caveat(first_half_cost=0.0, first_half_spend=False, first_half_sessions=2) == (
        "(baseline: no spend in the window's first half; "
        "the trend rules need both halves)")
    # A result that predates first_half_spend still gets the old reading.
    assert caveat(first_half_cost=0.0) == ("(baseline: no spend in the window's first half; "
                                           "the trend rules need both halves)")
    assert caveat(first_half_cost=1.5) == ""


CLAUDE_SESSION_INSIGHT_KEYS = {
    "mode", "findings", "baseline", "skipped_transcripts",
    "projects_dir_missing", "transcript_path",
}
CLAUDE_WINDOW_INSIGHT_KEYS = {
    "mode", "findings", "baseline", "skipped_transcripts", "projects_dir_missing",
}


def test_default_claude_session_insights_keeps_its_pre_runtime_shape(tu, tmp_path,
                                                                     monkeypatch):
    # Routing Claude through the adapter seam added runtime, measurement and
    # warnings to a payload that never carried them. `json` was already put
    # back; `insights` drifted the same way.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    current = _session(tmp_path, "current", 1000)
    r = tu.run_insights(transcript=current)
    assert set(r) == CLAUDE_SESSION_INSIGHT_KEYS
    assert r["transcript_path"] == str(current)


def test_default_claude_window_insights_keeps_its_pre_runtime_shape(tu, tmp_path,
                                                                    monkeypatch):
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "projects"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    _session(tmp_path, "s0", 1000)
    r = tu.run_insights(since="36500d")
    assert set(r) == CLAUDE_WINDOW_INSIGHT_KEYS


def test_claude_insights_warnings_still_reach_stderr(tu, tmp_path, monkeypatch, capsys):
    # Dropping "warnings" from the payload must not silence the warning: the
    # CLI reader has always been told on stderr.
    monkeypatch.setenv("TOKEN_USAGE_PROJECTS_DIR", str(tmp_path / "missing"))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    warnings = []
    r = tu.run_insights(since="36500d", warnings=warnings)
    assert "warnings" not in r
    assert any("projects directory" in w for w in warnings)
    assert "no readable Claude Code projects directory" in capsys.readouterr().err


def test_cursor_session_insights_still_disclose_runtime_and_measurement(
    tu, tmp_path, monkeypatch,
):
    from test_cursor_adapter import build_cursor_tree

    cursor_root = tmp_path / "cursor-user"
    build_cursor_tree(cursor_root)
    monkeypatch.setenv("TOKEN_USAGE_CURSOR_DIR", str(cursor_root))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    session = next(tu.get_runtime_adapter("cursor").iter_sessions())
    r = tu.run_insights(transcript=session, runtime="cursor")
    assert r["runtime"] == "cursor"
    assert r["measurement"] == "partial"
    assert isinstance(r["warnings"], list)


def test_cursor_window_insights_still_disclose_runtime_and_measurements(
    tu, tmp_path, monkeypatch,
):
    from test_cursor_adapter import build_cursor_tree

    cursor_root = tmp_path / "cursor-user"
    build_cursor_tree(cursor_root)
    monkeypatch.setenv("TOKEN_USAGE_CURSOR_DIR", str(cursor_root))
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "cache"))
    r = tu.run_insights(since="2020-01-01", runtime="cursor")
    assert r["runtime"] == "cursor"
    assert r["measurements"]
    assert isinstance(r["warnings"], list)


def test_insights_cli_json_default_claude_shape(tu, tmp_path):
    t = write_jsonl(tmp_path / "projects" / "p" / "s.jsonl", [
        user("2026-07-01T10:00:00Z", command="/go"),
        assistant("2026-07-01T10:00:05Z", usage(out=100), request_id="r1"),
    ])
    env = {**os.environ,
           "TOKEN_USAGE_PROJECTS_DIR": str(tmp_path / "projects"),
           "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "cache")}
    out = subprocess.run([sys.executable, "scripts/token_usage.py", "insights",
                          str(t), "--json"],
                         capture_output=True, text=True, env=env, check=False)
    assert out.returncode == 0, out.stderr
    assert set(jsonlib.loads(out.stdout)) == CLAUDE_SESSION_INSIGHT_KEYS
