import json
import os
import subprocess
import sys

from conftest import SCRIPT, assistant, usage, user, write_jsonl


def run_hook(payload, tmp_path, extra_env=None):
    env = {**os.environ, "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "ledger")}
    env.pop("TOKEN_USAGE_BUDGET_USD", None)
    env.update(extra_env or {})
    return subprocess.run(
        [sys.executable, str(SCRIPT), "hook"],
        input=json.dumps(payload), capture_output=True, text=True, env=env, check=False,
    )


def make_transcript(tmp_path, out_tokens=1000):
    return write_jsonl(tmp_path / "t.jsonl", [
        user("2026-06-12T10:00:00Z", command="/big"),
        assistant("2026-06-12T10:00:01Z", usage(out=out_tokens), request_id="r1"),
    ])


def test_hook_writes_ledger_and_exits_zero(tmp_path):
    t = make_transcript(tmp_path)
    r = run_hook({"session_id": "abc-123", "transcript_path": str(t)}, tmp_path)
    assert r.returncode == 0
    ledger = json.loads((tmp_path / "ledger" / "abc-123.json").read_text())
    assert ledger["total"]["usage"]["output"] == 1000


def test_hook_never_fails_on_garbage(tmp_path):
    r = subprocess.run([sys.executable, str(SCRIPT), "hook"], input="not json{",
                       capture_output=True, text=True, check=False,
                       env={**os.environ, "TOKEN_USAGE_LEDGER_DIR": str(tmp_path)})
    assert r.returncode == 0


def test_hook_never_fails_on_wrong_shaped_payload(tmp_path):
    # Valid JSON that is not a hook payload: json.load() succeeds, so the
    # JSONDecodeError guard never sees it, and payload.get() / Path() then
    # raised outside the broad try that exists so a hook can never break the
    # session. Exit 1 plus a traceback on stderr is exactly that break.
    env = {**os.environ, "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "ledger")}
    env.pop("TOKEN_USAGE_BUDGET_USD", None)
    for payload in ("null", "[1, 2, 3]", '"hello"', "42", "true",
                    '{"session_id": "s", "transcript_path": 42}',
                    '{"session_id": "s", "transcript_path": ["a"]}',
                    '{"session_id": "s", "transcript_path": null}'):
        r = subprocess.run([sys.executable, str(SCRIPT), "hook"], input=payload,
                           capture_output=True, text=True, env=env, check=False)
        assert r.returncode == 0, (payload, r.stderr)
        assert r.stdout.strip() == "" and r.stderr.strip() == "", payload


def test_budget_nudge_fires_once(tmp_path):
    t = make_transcript(tmp_path, out_tokens=1_000_000)  # 1MTok fable output ≈ $50
    payload = {"session_id": "bud-1", "transcript_path": str(t)}
    env = {"TOKEN_USAGE_BUDGET_USD": "10"}
    r1 = run_hook(payload, tmp_path, env)
    assert r1.returncode == 0
    msg = json.loads(r1.stdout)
    assert "passed 5× your $10.00 budget" in msg["systemMessage"]  # $50 = 5x $10
    assert "/big" in msg["systemMessage"]
    ledger = json.loads((tmp_path / "ledger" / "bud-1.json").read_text())
    assert ledger["budget_notified"] is True
    r2 = run_hook(payload, tmp_path, env)                 # second run: silent
    assert r2.returncode == 0
    assert r2.stdout.strip() == ""


def test_budget_unset_or_invalid_is_inert(tmp_path):
    t = make_transcript(tmp_path, out_tokens=1_000_000)
    for env in ({}, {"TOKEN_USAGE_BUDGET_USD": "not-a-number"}):
        r = run_hook({"session_id": "bud-2", "transcript_path": str(t)}, tmp_path, env)
        assert r.returncode == 0
        assert r.stdout.strip() == ""


def test_budget_under_limit_is_silent_and_unarmed(tmp_path):
    t = make_transcript(tmp_path, out_tokens=1000)        # ≈ $0.05, well under $10
    payload = {"session_id": "bud-3", "transcript_path": str(t)}
    env = {"TOKEN_USAGE_BUDGET_USD": "10"}
    r = run_hook(payload, tmp_path, env)
    assert r.returncode == 0
    assert r.stdout.strip() == ""
    ledger = json.loads((tmp_path / "ledger" / "bud-3.json").read_text())
    assert ledger["budget_notified"] is False              # not prematurely armed
    # Session grows past the limit -> the nudge then fires (at 5x here).
    make_transcript(tmp_path, out_tokens=1_000_000)
    r2 = run_hook(payload, tmp_path, env)
    assert "passed 5× your $10.00 budget" in json.loads(r2.stdout)["systemMessage"]


def test_budget_renudges_at_each_multiple(tmp_path):
    # $15 on a $10 budget -> first nudge (1x). Growing past $20 -> 2x nudge.
    t = make_transcript(tmp_path, out_tokens=300_000)      # fable: ≈ $15
    payload = {"session_id": "bud-5", "transcript_path": str(t)}
    env = {"TOKEN_USAGE_BUDGET_USD": "10"}
    r1 = run_hook(payload, tmp_path, env)
    assert "passed your $10.00 budget" in json.loads(r1.stdout)["systemMessage"]
    r2 = run_hook(payload, tmp_path, env)                  # unchanged cost: silent
    assert r2.stdout.strip() == ""
    make_transcript(tmp_path, out_tokens=500_000)          # grows to ≈ $25
    r3 = run_hook(payload, tmp_path, env)
    msg = json.loads(r3.stdout)["systemMessage"]
    assert "2×" in msg and "$10.00" in msg
    r4 = run_hook(payload, tmp_path, env)                  # 2x already notified: silent
    assert r4.stdout.strip() == ""
    ledger = json.loads((tmp_path / "ledger" / "bud-5.json").read_text())
    assert ledger["budget_notified_multiple"] == 2
    assert ledger["budget_notified"] is True               # legacy field still maintained


def test_budget_jump_message_names_actual_multiple(tmp_path):
    # A session that first reports in at 2x must say 2x, not just "your budget".
    t = make_transcript(tmp_path, out_tokens=500_000)      # fable: ≈ $25
    payload = {"session_id": "bud-7", "transcript_path": str(t)}
    r = run_hook(payload, tmp_path, {"TOKEN_USAGE_BUDGET_USD": "10"})
    msg = json.loads(r.stdout)["systemMessage"]
    assert "2× your $10.00 budget" in msg
    ledger = json.loads((tmp_path / "ledger" / "bud-7.json").read_text())
    assert ledger["budget_notified_multiple"] == 2


def test_hook_leaves_no_stray_tmp_and_valid_latest(tmp_path):
    t = make_transcript(tmp_path)
    r = run_hook({"session_id": "tmp-1", "transcript_path": str(t)}, tmp_path)
    assert r.returncode == 0
    ledger_dir = tmp_path / "ledger"
    assert list(ledger_dir.glob("*.tmp")) == []
    latest = ledger_dir / "latest.json"
    assert latest.is_symlink() and latest.resolve() == (ledger_dir / "tmp-1.json").resolve()


def test_ledger_write_failure_leaves_no_stray_tmp(tu, tmp_path, monkeypatch):
    # The hook swallows its own failures so Claude Code never stalls, which is
    # exactly why a failed ledger write must clean up after itself: nobody is
    # watching, and the ledger directory is written on every single stop.
    import pathlib

    import pytest
    monkeypatch.setenv("TOKEN_USAGE_LEDGER_DIR", str(tmp_path / "ledger"))
    original = pathlib.Path.write_text

    def patched(self, data, *a, **kw):
        if self.name.endswith(".tmp"):
            original(self, data[:3], *a, **kw)
            raise OSError("No space left on device")
        return original(self, data, *a, **kw)

    monkeypatch.setattr(pathlib.Path, "write_text", patched)
    with pytest.raises(OSError):
        tu._write_ledger(tu.ledger_dir() / "sess-1.json", {"session_id": "sess-1"})
    assert list((tmp_path / "ledger").glob("*.tmp")) == []


def test_budget_multiple_survives_legacy_bool_ledger(tmp_path):
    # A 0.2.x ledger has only budget_notified: true — treat as 1x already sent.
    t = make_transcript(tmp_path, out_tokens=300_000)      # ≈ $15 -> still 1x
    payload = {"session_id": "bud-6", "transcript_path": str(t)}
    ledger_dir = tmp_path / "ledger"
    ledger_dir.mkdir(parents=True)
    (ledger_dir / "bud-6.json").write_text('{"budget_notified": true}')
    r = run_hook(payload, tmp_path, {"TOKEN_USAGE_BUDGET_USD": "10"})
    assert r.returncode == 0
    assert r.stdout.strip() == ""                          # 1x was already notified


def make_session_with_agent(tmp_path, main_out=100, agent_out=40):
    proj = tmp_path / "proj"
    main = write_jsonl(proj / "sess-1.jsonl", [
        user("2026-06-12T10:00:00Z", command="/big"),
        assistant("2026-06-12T10:00:01Z", usage(out=main_out), request_id="r1"),
    ])
    agent = write_jsonl(proj / "sess-1" / "subagents" / "agent-001.jsonl", [
        assistant("2026-06-12T10:00:30Z", usage(out=agent_out), request_id="a1"),
    ])
    return main, agent


def test_subagent_stop_reaggregates_full_session(tmp_path):
    # SubagentStop delivers the subagent's own sidechain transcript; the hook
    # must resolve the owning session and ledger the WHOLE session, not the
    # sidechain alone.
    _main, agent = make_session_with_agent(tmp_path)
    r = run_hook({"session_id": "sess-1", "transcript_path": str(agent),
                  "hook_event_name": "SubagentStop"}, tmp_path)
    assert r.returncode == 0
    ledger = json.loads((tmp_path / "ledger" / "sess-1.json").read_text())
    assert ledger["total"]["usage"]["output"] == 140       # main 100 + agent 40


def test_subagent_stop_workflow_agent_reaggregates_full_session(tmp_path):
    proj = tmp_path / "proj"
    _main = write_jsonl(proj / "sess-wf.jsonl", [
        user("2026-06-12T10:00:00Z", command="/wf"),
        assistant("2026-06-12T10:00:01Z", usage(out=100), request_id="r1"),
    ])
    wf_agent = write_jsonl(proj / "sess-wf" / "subagents" / "workflows" / "run-1" / "agent-001.jsonl", [
        assistant("2026-06-12T10:00:30Z", usage(out=75), request_id="a1"),
    ])
    r = run_hook({"session_id": "sess-wf", "transcript_path": str(wf_agent),
                  "hook_event_name": "SubagentStop"}, tmp_path)
    assert r.returncode == 0
    ledger = json.loads((tmp_path / "ledger" / "sess-wf.json").read_text())
    assert ledger["total"]["usage"]["output"] == 175       # main 100 + wf agent 75


def test_subagent_stop_without_main_transcript_bails(tmp_path):
    # If the owning session transcript can't be found, never write a ledger
    # from sidechain-only data.
    agent = write_jsonl(tmp_path / "proj" / "sess-2" / "subagents" / "agent-001.jsonl", [
        assistant("2026-06-12T10:00:30Z", usage(out=40), request_id="a1"),
    ])
    r = run_hook({"session_id": "sess-2", "transcript_path": str(agent),
                  "hook_event_name": "SubagentStop"}, tmp_path)
    assert r.returncode == 0
    assert not (tmp_path / "ledger" / "sess-2.json").exists()


def test_subagent_stop_never_fires_budget_nudge(tmp_path):
    # Parallel SubagentStop hooks race the ledger read-modify-write, so budget
    # nudges only fire from the (serial) Stop hook. SubagentStop still updates
    # the ledger but must not consume the pending multiple.
    main, agent = make_session_with_agent(tmp_path, main_out=1_000_000)  # ≈ $50+
    env = {"TOKEN_USAGE_BUDGET_USD": "10"}
    r1 = run_hook({"session_id": "sess-1", "transcript_path": str(agent),
                   "hook_event_name": "SubagentStop"}, tmp_path, env)
    assert r1.returncode == 0
    assert r1.stdout.strip() == ""                         # no nudge mid-turn
    ledger = json.loads((tmp_path / "ledger" / "sess-1.json").read_text())
    assert ledger["budget_notified_multiple"] == 0         # left for Stop to claim
    r2 = run_hook({"session_id": "sess-1", "transcript_path": str(main),
                   "hook_event_name": "Stop"}, tmp_path, env)
    assert "your $10.00 budget" in json.loads(r2.stdout)["systemMessage"]


def test_hooks_json_registers_stop_and_subagent_stop():
    # SubagentStop keeps the ledger (and statusline) fresh during long
    # agent-heavy turns instead of only at turn end.
    hooks = json.loads((SCRIPT.parent.parent / "hooks" / "hooks.json").read_text())
    events = hooks["hooks"]
    assert set(events) >= {"Stop", "SubagentStop"}
    commands = {e: events[e][0]["hooks"][0]["command"] for e in ("Stop", "SubagentStop")}
    assert commands["Stop"] == commands["SubagentStop"]


def test_hook_recovers_from_non_dict_ledger(tmp_path):
    t = make_transcript(tmp_path)
    payload = {"session_id": "bud-4", "transcript_path": str(t)}
    ledger_dir = tmp_path / "ledger"
    ledger_dir.mkdir(parents=True)
    (ledger_dir / "bud-4.json").write_text("[1, 2, 3]")    # valid JSON, wrong shape
    r = run_hook(payload, tmp_path)
    assert r.returncode == 0
    ledger = json.loads((ledger_dir / "bud-4.json").read_text())
    assert ledger["total"]["usage"]["output"] == 1000      # ledger self-healed


def test_hook_reports_a_failed_ledger_write(tmp_path):
    # The nudge is the plugin's headline feature; an unwritable cache dir used
    # to kill it with zero output on any channel. stderr is free (the hook's
    # contract is stdout + exit status), so say what broke.
    if os.geteuid() == 0:
        import pytest
        pytest.skip("root ignores directory permissions")
    t = make_transcript(tmp_path, out_tokens=1_000_000)          # ≈ $50
    ro = tmp_path / "readonly"
    ro.mkdir()
    ro.chmod(0o500)
    try:
        r = run_hook({"session_id": "ro-1", "transcript_path": str(t)}, tmp_path,
                     {"TOKEN_USAGE_LEDGER_DIR": str(ro / "ledger"),
                      "TOKEN_USAGE_BUDGET_USD": "10"})
    finally:
        ro.chmod(0o700)
    assert r.returncode == 0                                     # never break the session
    assert "hook: ledger update failed" in r.stderr
    # ...and the nudge itself still goes out: it was computed before the write
    # failed, and losing the headline feature to a broken cache dir is exactly
    # the silence this test exists to prevent. stdout stays hook protocol.
    assert json.loads(r.stdout)["systemMessage"].startswith(
        "token-usage: session estimate $50.00 has passed")


def test_hook_never_fails_on_undecodable_stdin(tmp_path):
    # json.load(sys.stdin) DECODES before it parses, so a non-UTF-8 byte raises
    # UnicodeDecodeError — a ValueError, but not a JSONDecodeError — and walks
    # straight past the guard: rc=1 plus a traceback on every Stop, which is
    # the one thing a hook must never do. PYTHONIOENCODING pins strict UTF-8
    # decoding, the ordinary desktop locale (a POSIX locale hides this behind
    # PEP 538 coercion to surrogateescape).
    env = {**os.environ, "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "ledger"),
           "PYTHONIOENCODING": "utf-8"}
    env.pop("TOKEN_USAGE_BUDGET_USD", None)
    for raw in (b'\xff\xfe{"a": 1}', b"\xff", b"\x80\x81\x82",
                b'{"session_id": "s", "transcript_path": "\xff\xfe"}'):
        r = subprocess.run([sys.executable, str(SCRIPT), "hook"], input=raw,
                           capture_output=True, env=env, check=False)
        assert r.returncode == 0, (raw, r.stderr)
        assert r.stdout == b"" and r.stderr == b"", raw


def test_hook_survives_an_ascii_stdio_encoding(tmp_path):
    # launchd/cron/containers hand the hook a POSIX locale: stdin then decodes
    # as ASCII, and a well-formed payload naming a path with one non-ASCII
    # character died in the decode. Hook payloads are JSON — UTF-8 by spec —
    # so the bytes must be decoded as UTF-8 whatever the locale says, and the
    # nudge must come back out as ASCII-safe JSON.
    t = write_jsonl(tmp_path / "café" / "t.jsonl", [
        user("2026-06-12T10:00:00Z", command="/big"),
        assistant("2026-06-12T10:00:01Z", usage(out=1_000_000), request_id="r1"),
    ])
    payload = json.dumps({"session_id": "loc-1", "transcript_path": str(t)},
                         ensure_ascii=False).encode()
    env = {**os.environ, "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "ledger"),
           "PYTHONIOENCODING": "ascii", "TOKEN_USAGE_BUDGET_USD": "10"}
    r = subprocess.run([sys.executable, str(SCRIPT), "hook"], input=payload,
                       capture_output=True, env=env, check=False)
    assert r.returncode == 0, r.stderr
    assert "budget" in json.loads(r.stdout.decode())["systemMessage"]
    ledger = json.loads((tmp_path / "ledger" / "loc-1.json").read_text())
    assert ledger["total"]["cost_usd"] == 50.0


def test_hook_survives_a_closed_stdout_pipe(tmp_path):
    # print() only buffers: CPython flushes sys.stdout at INTERPRETER SHUTDOWN,
    # after run_hook's `except Exception` has already returned 0, so a reader
    # that closed the pipe turned a successful hook into rc=120 plus
    # "Exception ignored on flushing sys.stdout" — a broken session for a
    # reason no channel explains.
    t = make_transcript(tmp_path, out_tokens=1_000_000)       # ≈ $50: the nudge prints
    env = {**os.environ, "TOKEN_USAGE_LEDGER_DIR": str(tmp_path / "ledger"),
           "TOKEN_USAGE_BUDGET_USD": "10"}
    p = subprocess.Popen([sys.executable, str(SCRIPT), "hook"], stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    p.stdout.close()                                          # the reader is gone
    p.stdin.write(json.dumps({"session_id": "pipe-1", "transcript_path": str(t)}).encode())
    p.stdin.close()
    err = p.stderr.read().decode()
    p.stderr.close()
    assert p.wait() == 0, err
    assert "Exception ignored" not in err and "BrokenPipeError" not in err
    assert json.loads((tmp_path / "ledger" / "pipe-1.json").read_text())["budget_notified"]
