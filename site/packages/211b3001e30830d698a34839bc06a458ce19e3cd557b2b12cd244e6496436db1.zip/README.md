# Simple Muscle Claude Plugin

Simple Muscle helps Claude design complete workout programs, review recorded training, progress prescriptions, and swap exercises using the user's real workout data. The plugin combines the Simple Muscle remote MCP connector with planning judgment, safety boundaries, explicit write approval, and an independent program audit for Claude Code and Cowork.

## Prerequisites

You need a [Simple Muscle](https://simplemuscle.ai) account with AI Connection access enabled.

## Install

### Claude Code

Install from this repository:

```text
/plugin marketplace add SimpleMuscle/simplemuscle-claude-plugin
/plugin install simplemuscle@simplemuscle
```

After the plugin is published in Anthropic's directory:

```text
/plugin install simplemuscle@claude-plugins-official
```

To test a local clone without installing it, start Claude Code with:

```bash
claude --plugin-dir ./simplemuscle-claude-plugin
```

### Cowork

Open **Customize → Plugins**, find **Simple Muscle** in the plugin marketplace, and select **Install**.

## First run

Run `/simplemuscle:setup`. If prompted, run `/mcp`, select `simple-muscle`, and complete OAuth sign-in. The connector uses OAuth 2.0 and does not require a pasted API token.

## Commands

| Command | What it does | Writes? |
| --- | --- | --- |
| `/simplemuscle:setup` | Verify OAuth and confirm workout access. | No |
| `/simplemuscle:create-plan <brief>` | Design a full plan, audit it, confirm it, and create it with one plan write. | Yes, after approval |
| `/simplemuscle:review-progress <window>` | Review adherence and lift history, and recommend the next block. | No |
| `/simplemuscle:progress-workout <workout>` | Present a before/after progression table and update only approved prescriptions. | Yes, after approval |
| `/simplemuscle:swap-exercise <exercise>` | Find a movement-pattern substitute and apply the confirmed replacement. | Yes, after approval |
| `/simplemuscle:program-design` | The shared training principles — structure, volume, progression, exercise order, deload, and safety — that the other skills apply. | No |

The plugin also includes the read-only critic `simplemuscle:program-auditor`, which `create-plan` invokes to review a draft before it is written.

Every write is preceded by an explicit, itemized confirmation step; nothing is created, updated, or removed without the user approving the exact values first.

## Connector and authentication

The remote MCP endpoint is [`https://api.simplemuscle.ai/mcp`](https://api.simplemuscle.ai/mcp). Authentication is OAuth 2.0 with dynamic client registration.

## Limits and safety

Completed workout sessions are read-only and cannot be created, edited, or deleted through the plugin. The plugin does not diagnose injuries, prescribe rehabilitation, or replace qualified medical or exercise professionals; pain, injury, and alarming symptoms trigger a stop-and-refer safety boundary. It does not provide nutrition or supplement guidance.

## Privacy and support

Read the [Simple Muscle privacy policy](https://simplemuscle.ai/privacy). Visit [support](https://simplemuscle.ai/contact) or email [hello@simplemuscle.ai](mailto:hello@simplemuscle.ai).

## License

MIT — see [LICENSE](LICENSE).
