---
description: Verifies Simple Muscle OAuth and workout access. Use for setup, first run, sign in, authorization, or connection problems.
disable-model-invocation: true
---

1. Call `list_workouts`.
2. If the Simple Muscle server is not authorized, stop. Tell the user to run `/mcp`, select `simple-muscle`, complete OAuth sign-in, and then rerun `/simplemuscle:setup`.
3. On success, report that the connection works and summarize only the workout names returned. Do not create or edit anything during setup.
4. Recommend two or three useful starting commands: `/simplemuscle:create-plan`, `/simplemuscle:review-progress`, `/simplemuscle:progress-workout`, or `/simplemuscle:swap-exercise`.
