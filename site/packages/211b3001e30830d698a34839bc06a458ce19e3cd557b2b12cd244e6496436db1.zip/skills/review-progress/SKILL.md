---
description: Reviews recorded training without editing anything. Use for progress review, adherence, stalled lifts, volume drift, or planning the next block.
argument-hint: "[date window] [main lifts]"
---

User request: $ARGUMENTS

Treat anything above as the requested date window, goal, and main lifts.

This skill is read-only: report and recommend, but never call a write tool. Applying changes belongs to `progress-workout` or `swap-exercise`.

1. Call `list_history` for the recent training window. Call `show_training_stats` for the rendered summary.
2. Resolve the main lifts from the user's program and call `get_exercise_history` for each. Use only recorded results, and distinguish a missing session from a completed session with weaker performance.
3. Report concisely:
   - adherence across the selected window;
   - lifts whose achieved reps or load progressed;
   - lifts that stalled or regressed, and for how many comparable exposures;
   - meaningful drift between planned and completed volume.
4. Use `program-design` principles to recommend the next block. State each suggested prescription change as a specific before/after in kilograms against a named workout and exercise.
5. If the user reports pain, injury, or alarming symptoms, apply the safety stop in `program-design` and keep every recommendation conservative.
6. State plainly that completed workout history is read-only and cannot be edited. Close by offering to apply the recommended changes with `/simplemuscle:progress-workout`.
