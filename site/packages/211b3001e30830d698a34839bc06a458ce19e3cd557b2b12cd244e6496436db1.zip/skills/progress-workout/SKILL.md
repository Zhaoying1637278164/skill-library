---
description: Progresses an approved Simple Muscle workout. Use for increase weights, next week, double progression, update sets, or advance my program.
argument-hint: "[workout name] [date range]"
---

User request: $ARGUMENTS

Treat anything above as the workout, date range, and progression preferences the user has already supplied.

1. Call `get_workout` for the current prescription. Resolve every exercise from its real ID, and call `get_exercise_history` for enough recent comparable exposures to judge what was achieved.
2. Choose one progression per exercise using `program-design`: advance prescriptions completed cleanly and consistently; hold or conservatively reduce work that stalled. Do not infer pain-free status, technique quality, or effort when the record does not contain it — ask the user.
3. If the user reports pain, injury, or alarming symptoms, apply the safety stop in `program-design` before proposing changes.
4. Present a before/after table with exercise, sets, reps, and kilograms, plus a one-line reason for each change or hold. Keep cardio and stretching in sets × duration.
5. Obtain explicit confirmation for the exact table. If any value changes, present the revised row and reconfirm it.
6. Call `update_exercise_sets` once per approved exercise. Complete all writes before rendering; do not call `show_workout_overview` between updates.
7. After every write finishes, call `show_workout_overview` once. Report any failures and leave unapproved exercises unchanged.
