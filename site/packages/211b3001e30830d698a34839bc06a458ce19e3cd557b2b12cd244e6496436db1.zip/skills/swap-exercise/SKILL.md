---
description: Replaces an exercise with an approved pattern match. Use for swap exercise, substitute movement, equipment or preference alternative, or pain-free alternative.
argument-hint: "[workout] [exercise] [reason]"
---

User request: $ARGUMENTS

Treat anything above as the workout, exercise, and reason the user has already supplied.

1. Identify the workout, the exercise to replace, and the reason: equipment, preference, or a requested pain-free alternative. Call `get_workout` if the current prescription is not already known.
2. If pain, injury, or alarming symptoms are involved, apply the safety stop in `program-design`. Continue only with a conservative substitution the user explicitly wants to consider.
3. Call `list_exercises` or `search` for real candidate IDs that match the same movement pattern and intended stimulus. Call `show_exercise_info` for the strongest candidates so the user can inspect them.
4. Propose one replacement and explain the movement-pattern match. Carry over the set and rep structure only when appropriate, and set a conservative load expectation for the new exercise rather than copying the old kilogram value blindly.
5. Show the exact before/after prescription and obtain explicit confirmation before any write.
6. On confirmation, read the replaced exercise's 0-based position and `plan_id` from `get_workout`. Call `remove_exercise_from_workout`, passing `plan_id` when that exercise appears more than once. Then call `add_exercise_to_workout` with the recorded `position` and the agreed sets, reps, and weight, so the replacement keeps its place in the session order. Stop and report immediately if either step fails; do not continue blindly.
7. Call `show_workout_overview` only after every approved write succeeds.
