---
description: Creates an approved Simple Muscle plan with one plan write. Use for new plan, routine, split, hypertrophy plan, or strength block.
argument-hint: "[goal] [days per week] [equipment] [constraints]"
---

User brief: $ARGUMENTS

Treat anything above as detail the user has already supplied, and ask only for what is still missing.

1. Ask together for every missing essential: goal, training days per week and which days, session length, equipment, experience, and injuries or restrictions. Do not interview one question at a time.
2. If the user reports pain, injury, or alarming symptoms, apply the safety stop in `program-design` before continuing.
3. Draft the structure using `program-design`. Call `list_exercises` to resolve every intended exercise to a real ID. Use `search` and `get_exercise` when a movement pattern needs a specific match. Never invent an ID.
4. Present the complete plan before any write: workout names and days, ordered exercises with IDs, all strength prescriptions in sets × reps × kg, cardio and stretching in sets × duration, the progression approach, and a realistic session-length check.
5. Invoke the `program-auditor` subagent with the complete draft and the user's constraints. Address each concrete issue in the main thread; the auditor never writes or rewrites the plan.
6. Ask for explicit approval of the final displayed plan. If anything changes, display the revised full plan and request approval again.
7. For a multi-workout or multi-day plan, call `create_workout_plan` exactly once with the entire approved plan. Never assemble it with `create_workout` plus later set updates. Do not retry after an ambiguous failure without first checking the live workout list and asking the user.
8. Do not call `show_workout_overview` afterwards: `create_workout_plan` renders the final overview itself. Summarize the result only after that single write completes.
