---
description: Connect and verify Simple Muscle after installing the plugin. Use for first-run setup, OAuth authorization, or connection troubleshooting.
disable-model-invocation: true
---

Run `/simplemuscle:setup`. It verifies Simple Muscle OAuth and confirms that the workout connection can be read before any planning workflow begins.
