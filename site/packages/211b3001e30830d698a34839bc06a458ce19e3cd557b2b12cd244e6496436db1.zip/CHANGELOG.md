# Changelog

All notable changes to this plugin are documented here.

## 0.2.0 - 2026-08-25

- Add `.claude-plugin/marketplace.json` so the repository installs directly with `/plugin marketplace add`.
- Rename `/simplemuscle:new-plan` to `/simplemuscle:create-plan`, `/simplemuscle:progress-review` to `/simplemuscle:review-progress`, `/simplemuscle:progress-plan` to `/simplemuscle:progress-workout`, and `/simplemuscle:exercise-swap` to `/simplemuscle:swap-exercise`.
- Make `review-progress` strictly read-only; applying recommended changes now belongs to `progress-workout`.
- Restrict `program-auditor` to a read-only tool allowlist.
- Quote command argument hints so their frontmatter is parser-independent.
- Preserve exercise position and disambiguate repeated exercises when applying a swap.
- Restore the directory-facing root `SETUP.md` guide while retaining `/simplemuscle:setup` for Claude Code.

## 0.1.0 - 2026-08-23

- Add the Simple Muscle remote MCP connector configuration.
- Add setup, programme-design, new-plan, progress-review, progression, and exercise-swap skills.
- Add the read-only `program-auditor` sub-agent.
