# Contributor Covenant Code of Conduct

## Our pledge

We as members, contributors, and leaders pledge to make participation in our community a
harassment-free experience for everyone, regardless of age, body size, visible or invisible
disability, ethnicity, sex characteristics, gender identity and expression, level of experience,
education, socioeconomic status, nationality, personal appearance, race, caste, color, religion,
or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive,
and healthy community.

## Our standards

Examples of behavior that contributes to a positive environment include:

- Demonstrating empathy and kindness toward other people
- Respecting differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologizing to those affected by our mistakes, and learning from
  the experience
- Focusing on what is best for the overall community

Examples of unacceptable behavior include:

- The use of sexualized language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information, such as a physical or email address, without their
  explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

## Enforcement responsibilities

Community leaders are responsible for clarifying and enforcing our standards of acceptable
behavior and will take appropriate and fair corrective action in response to behavior they deem
inappropriate, threatening, offensive, or harmful.

Community leaders have the right and responsibility to remove, edit, or reject comments, commits,
code, wiki edits, issues, and other contributions that are not aligned with this Code of Conduct,
and will communicate reasons for moderation decisions when appropriate.

## Scope

This Code of Conduct applies within all community spaces and when an individual is officially
representing the community in public spaces.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported privately
through [vidIQ Support](https://support.vidiq.com/) or by emailing
[support@vidiq.com](mailto:support@vidiq.com) with the subject **Code of Conduct report**. Ask for
private escalation to the community maintainers. All complaints will be reviewed and investigated
promptly and fairly.

Community leaders are obligated to respect the privacy and security of the reporter of any
incident.

## Enforcement guidelines

Community leaders will follow these Community Impact Guidelines in determining the consequences
for any action they deem in violation of this Code of Conduct:

### 1. Correction

**Community impact:** Use of inappropriate language or other behavior deemed unprofessional or
unwelcome in the community.

**Consequence:** A private, written warning providing clarity around the nature of the violation
and an explanation of why the behavior was inappropriate. A public apology may be requested.

### 2. Warning

**Community impact:** A violation through a single incident or series of actions.

**Consequence:** A warning with consequences for continued behavior. No interaction with the
people involved, including unsolicited interaction with those enforcing the Code of Conduct, for
a specified period of time. This includes avoiding interactions in community spaces as well as
external channels like social media. Violating these terms may lead to a temporary or permanent
ban.

### 3. Temporary ban

**Community impact:** A serious violation of community standards, including sustained
inappropriate behavior.

**Consequence:** A temporary ban from any sort of interaction or public communication with the
community for a specified period of time. No public or private interaction with the people
involved, including unsolicited interaction with those enforcing the Code of Conduct, is allowed
during this period. Violating these terms may lead to a permanent ban.

### 4. Permanent ban

**Community impact:** Demonstrating a pattern of violation of community standards, including
sustained inappropriate behavior, harassment of an individual, or aggression toward or
disparagement of classes of individuals.

**Consequence:** A permanent ban from any sort of public interaction within the community.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant, version
2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct.html), available under the
[Creative Commons Attribution 4.0 International
License](https://creativecommons.org/licenses/by/4.0/). This adapted file is licensed under
[CC BY 4.0](LICENSES/CC-BY-4.0.txt).
