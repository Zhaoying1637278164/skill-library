# Trackly SMS integrations

Connect an assistant to Trackly SMS, check account and sender setup, and prepare
messages for human approval. This public package contains configuration and a
portable skill. The hosted service runs at **https://mcp.tracklysms.com/mcp**
with Streamable HTTP and native OAuth account connection.

Start with a sandbox connection and required send approval. Live sending depends
on current service availability, account authority, sender and billing readiness,
recipient consent, and an approved hold. Check
[Trackly's connection guide](https://docs.tracklysms.com/agents/connect) and
`trackly_whoami`; package installation alone establishes none of these.

## Install

Clone or download [this public integration repository](https://github.com/Trackly-Inc/trackly-sms-integrations).
The repository root is the plugin root; keep its hidden directories when copying.
Install one Trackly connection per client to avoid duplicate tool entries.

| Client | Package entry point and setup |
| --- | --- |
| ChatGPT / Codex | Native `.codex-plugin/plugin.json`, inline MCP configuration, and `.agents/plugins/marketplace.json`. Add the repository with `codex plugin marketplace add Trackly-Inc/trackly-sms-integrations`, then use the desktop Plugins Directory to install from the Trackly source. Local marketplace availability varies by surface. Public directory listing requires separate publisher review. |
| Claude Code | `.claude-plugin/marketplace.json`. Run `/plugin marketplace add Trackly-Inc/trackly-sms-integrations`, then `/plugin install trackly-sms@trackly-sms`. Use `/mcp` to complete native authorization. |
| Junie CLI | Its Claude-compatible extension loader reads `.claude-plugin/marketplace.json`. Use `/extensions marketplace add https://github.com/Trackly-Inc/trackly-sms-integrations.git`, then select Trackly under `/extensions`. Authorize the connection through `/mcp`. Junie IDE settings and built-in catalog inclusion are separate. |
| Cursor | The root `plugin.json`, `mcp.json`, and `skills/` use Agent Plugins 1.0. For a local installation, place this complete directory at `~/.cursor/plugins/local/trackly-sms` and reload Cursor. Authorize Trackly in MCP settings. Marketplace acceptance is separate. |
| Cline | Merge the `trackly` server entry from [install/cline-mcp.json](install/cline-mcp.json) into Cline's MCP configuration; preserve other servers. Use its Authenticate action. Copy [skills/trackly/](skills/trackly/) into your project's `.cline/skills/trackly/`. This is a native MCP/skill recipe, not a Cline plugin format. |

For ChatGPT's hosted connection surface, use its developer/plugin connection flow
with the hosted URL and native OAuth. A local CLI install does not register a
hosted connection or publish a directory entry. Do not invent a connection ID.

Client formats were checked against the official references below on
2026-09-07. Native Trackly account-connection tests in these clients have **not
been run** for this package. File validation does not prove a successful sign-in
or marketplace approval. Keep client tool confirmations enabled.

The public catalog logo is [assets/logo.png](assets/logo.png), a 400×400 PNG
rendered from Trackly's existing [SVG](assets/logo.svg).

## Connect, review, and recover

The client opens Trackly for owner sign-in or signup, email verification and any
required second factor, and account consent. Keep passwords, codes, tokens, and
keys outside chat. Review allowed senders, mode, and limits before consenting.

After connection, ask the assistant to check `trackly_whoami` and
`trackly_get_setup_status`. A first message follows preflight → hold → human
review in Trackly → execution of that approved hold → result inspection.
Connection consent and client prompts do not approve SMS. Sandbox can invoke
configured webhooks, though it does not submit SMS to a carrier.

Optional registration drafts and private previews require a fresh owner grant
for `trackly.registration` and deployed tools. Final publishing, domain
authorization, registration submission, and charges remain owner actions.

For uncertain execution, inspect the same hold; do not create a replacement or
blindly resend. Disconnect grants under
[Settings → Agent connections](https://app.tracklysms.com/settings/agent-connections).
Disconnection cannot recall an already queued message.

## Data, support, and license

The assistant's requested account, sender, message, and registration information
is sent to Trackly through the authenticated MCP connection. Follow both your
client's data policy and [Trackly's privacy policy](https://tracklysms.com/privacy).
Use controlled recipients and avoid unnecessary personal data in test prompts.

- [Terms of service](https://tracklysms.com/terms)
- [Public support](https://docs.tracklysms.com/resources/support) or [support@tracklysms.com](mailto:support@tracklysms.com)
- [New-account onboarding](https://docs.tracklysms.com/agents/onboarding)
- [Approved sends and recovery](https://docs.tracklysms.com/agents/send-with-approval)
- [Number registration](https://docs.tracklysms.com/agents/number-registration)

[MIT](LICENSE) covers this package's newly authored integration configuration,
documentation, and skill. Trackly logo assets and trademarks are excluded;
Trackly's hosted service and private application source are not licensed here.

## Format references

- [OpenAI plugin packaging](https://developers.openai.com/plugins/build/plugins)
- [Codex inline MCP manifest support](https://github.com/openai/codex/blob/6750f5bd1356fe1553c0fcc9f2632704f3055946/codex-rs/core-plugins/src/manifest.rs)
- [Claude plugins](https://code.claude.com/docs/en/plugins-reference) and [marketplaces](https://code.claude.com/docs/en/plugin-marketplaces)
- [Junie CLI extensions](https://junie.jetbrains.com/docs/junie-cli-extensions.html)
- [Cursor plugins](https://cursor.com/docs/reference/plugins)
- [Agent Plugins MCP configuration](https://agent-plugins.org/plugin-authors/mcp-servers)
- [Cline MCP](https://docs.cline.bot/mcp/mcp-overview) and [skills](https://docs.cline.bot/customization/skills)
