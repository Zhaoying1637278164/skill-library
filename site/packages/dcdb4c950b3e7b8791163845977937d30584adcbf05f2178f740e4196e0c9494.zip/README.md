# Hive for Claude

Connect Claude to Hive, then use focused workflows for project status, meeting follow-up, and weekly planning.

## What this plugin includes

- Hive's remote MCP connector at `https://hive-mind.hive.com/mcp`
- `/hive:project-status` for concise, evidence-backed project updates
- `/hive:meeting-follow-up` for turning meeting outcomes into reviewed Hive actions
- `/hive:weekly-plan` for prioritizing assigned work across active projects

## Connect

1. Install and enable the plugin.
2. Open `/mcp` in Claude Code or the connector panel in Cowork.
3. Select `hive` and complete Hive OAuth in your browser.
4. Choose the Hive workspace you want to use.

Hive only exposes records and operations allowed by the connected user's existing workspace permissions. Read and write tools are available; Claude should verify requested writes with a readback.

## Example prompts

- `/hive:project-status Website launch`
- `/hive:meeting-follow-up Create the agreed follow-ups from this conversation in Marketing Operations`
- `/hive:weekly-plan Plan my week around overdue work and deadlines through Friday`

## Development

Validate before release:

```bash
claude plugin validate . --strict
```

Test locally:

```bash
claude --plugin-dir .
```

## Support and policies

- Support: https://help.hive.com/en/
- Privacy: https://hive.com/policy-documents/privacy-policy
