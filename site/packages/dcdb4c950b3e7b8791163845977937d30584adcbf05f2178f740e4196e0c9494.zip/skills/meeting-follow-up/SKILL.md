---
name: meeting-follow-up
description: Turn meeting notes or the current conversation into a reviewed set of Hive actions with owners, projects, and dates, then create them only after the user confirms the proposed changes. Use for meeting follow-ups, action-item capture, or converting decisions into Hive work.
argument-hint: "[meeting context and target project]"
---

# Hive meeting follow-up

Prepare follow-up work from `$ARGUMENTS` and the current conversation.

1. Extract explicit decisions, commitments, owners, dates, and unresolved questions. Do not invent an owner or deadline.
2. Resolve the target Hive workspace and project. Read existing active actions first to avoid duplicates.
3. Present a compact proposed change set with title, owner, due date, project, and source context for every action.
4. Ask for confirmation before creating or updating records. Treat edits to owner, date, project, or scope as a new confirmation requirement.
5. After confirmation, make the smallest requested writes. Read every created or updated action back and report exact Hive links or stable identifiers.
6. If any write fails, report the first cause and leave unaffected records unchanged. Do not retry non-idempotent writes blindly.

Never archive, delete, or bulk-update unrelated Hive work through this workflow.
