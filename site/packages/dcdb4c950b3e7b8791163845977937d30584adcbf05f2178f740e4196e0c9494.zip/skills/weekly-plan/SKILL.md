---
name: weekly-plan
description: Build a realistic weekly plan from the user's assigned Hive work, prioritizing overdue items, deadlines, blockers, approvals, and dependencies. Use when the user asks what to work on, to plan the week, or to prioritize current Hive actions.
argument-hint: "[week, constraints, or workspace]"
---

# Hive weekly plan

Plan the user's work using `$ARGUMENTS` as timing and scope constraints.

1. Resolve the user and workspace, then read assigned active actions across relevant projects. Include overdue work, work due during the requested period, blocked dependencies, pending approvals, priorities, and estimates when available.
2. Exclude completed, archived, or unassigned work unless the user asks to review it.
3. Prioritize by business impact, deadline, dependency leverage, and effort. Flag conflicts instead of pretending everything fits.
4. Return:
   - must-do outcomes;
   - a day-by-day sequence;
   - blocked items and required decisions;
   - work to defer, with reason;
   - unverified assumptions.
5. Keep this workflow read-only unless the user explicitly asks to change dates, owners, priorities, or statuses. For requested changes, show the exact proposed deltas first, then write and read back only after confirmation.
