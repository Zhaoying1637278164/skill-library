---
name: project-status
description: Build a concise, evidence-backed status report for a Hive project, including progress, overdue work, blockers, owners, approvals, and next actions. Use when the user asks for project status, project health, blockers, risks, or a stakeholder update from Hive.
argument-hint: "[project name or URL]"
---

# Hive project status

Create a current-state report for `$ARGUMENTS`.

1. Resolve the exact Hive workspace and project. If multiple projects match, ask the user to choose before continuing.
2. Read project metadata plus active actions, assignees, statuses, due dates, dependencies, recent relevant comments, and pending approvals. Use narrow queries and continue pagination when results are incomplete.
3. Separate confirmed facts from inferences. Never infer completion from a title, stale status, or missing result.
4. Summarize:
   - overall outcome and health;
   - completed or materially advanced work;
   - overdue or blocked work with owner and date;
   - decisions or approvals needed;
   - smallest concrete next actions.
5. Include Hive links or stable record identifiers when available.

This workflow is read-only. Do not update Hive unless the user separately requests a specific change.
