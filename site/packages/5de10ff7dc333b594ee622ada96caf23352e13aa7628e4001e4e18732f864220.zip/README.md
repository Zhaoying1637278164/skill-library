# claude-find-session

A Claude Code plugin that makes finding and resuming past sessions actually usable.

The built-in `/resume` shows a flat list scoped to the current directory. This plugin searches across every project, filters out junk sessions, groups results by time, and hands you a ready-to-run `claude --resume <id>` command.

## What it looks like

```
Today
  1. `2m`  projects
     this website is my personal website, my name is Peter Rong, contact peter.gh.rong@gmail.com

This week
  2. `2d`  projects/peterghrong/github/io
     the posts are not in chronological order, it should be my first post first, brownian motion...

  3. `2d`  projects/poly/data
     lets play with this repo a bit

Older
  4. `2w`  projects/anthropomorphic
     I want to add an ability, I want it to be able to access repos, trigger code generation...

Pick a number, or refine.
```

Pick a number and you get back:

```
! claude --resume c21ed67d-6f7e-423d-b3f0-357c0f0a8edd
```

Run it inline with the `!` prefix to switch sessions.

## Install

From inside Claude Code:

```
/plugin install session-finder
```

Or clone this repo and drop it into `~/.claude/plugins/`.

## Usage

- `/session-finder:find-session` — list the most recent sessions globally
- `/session-finder:find-session websocket` — keyword filter (literal substring across all session files)
- After the list shows, say a number or describe one ("the github.io one") to get the resume command
- Ask "show older" / "go further back" to pull older buckets

## How it works

A bash helper walks `~/.claude/projects/**/*.jsonl`, extracts the first real user message of each session as a preview, filters out subagent sessions and trivially short ones, then emits a grouped markdown list (Today / This week / Older) sorted by mtime. The skill instructs Claude to print the output verbatim — no reformatting, no drift between calls.

## Limitations

- Project paths are decoded best-effort from `~/.claude/projects/<encoded>/` directory names, so `peterghrong.github.io` shows as `peterghrong/github/io`. Cosmetic only.
- `--grep` is a literal substring search, not semantic. For conceptual queries, the skill falls back to ranking by reading previews.

## License

MIT
