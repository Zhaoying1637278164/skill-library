---
name: find-session
description: Search past Claude Code sessions across all projects by keyword or natural-language query, then resume the chosen one. Use when the user asks to find, recall, or resume a previous Claude Code conversation.
---

# find-session

Find a past Claude Code session and produce a `claude --resume <id>` command for the user to run.

## How to use

The helper does all the formatting. Your job is to invoke it correctly and resolve user picks.

### Listing

1. **No query** → list recent sessions:

   ```bash
   ${CLAUDE_SKILL_DIR}/list-sessions.sh --limit 15
   ```

2. **Keyword query** (e.g. `/find-session websocket`) → use `--grep`:

   ```bash
   ${CLAUDE_SKILL_DIR}/list-sessions.sh --grep "websocket" --limit 15
   ```

3. **"Show me older" / "go further back"** → bump `--limit` and add `--min-age-days` so today/this-week sessions aren't repeated:

   ```bash
   ${CLAUDE_SKILL_DIR}/list-sessions.sh --limit 30 --min-age-days 7
   ```

### Displaying

The helper prints fully-formatted markdown on stdout. **Print it verbatim. Do not reformat, re-indent, or restyle it.** Do not add a preamble.

The helper also prints an index map on stderr (after `---index---`), one line per entry: `<n>\t<session_id>\t<project>`. **Capture stderr** when invoking, so you can resolve picks. In Claude Code, that means running:

```bash
${CLAUDE_SKILL_DIR}/list-sessions.sh --limit 15 2>&1 1>/tmp/find-session-out.md && cat /tmp/find-session-out.md
```

Or simpler — run once and read both streams from the Bash tool result (stdout shown, stderr captured by the tool runner). Either works; what matters is you keep the index map in mind so picks can resolve.

### When the user picks

The user replies with a number, "the github.io one", "the 936-msg session", etc. Match against the index and respond with ONLY the resume command in a code block — no narration:

```
! claude --resume <session-id>
```

## Notes

- Helper already filters out subagent sessions, empty/trivial previews, and sessions with <5 messages.
- For semantic / conceptual queries where `--grep` doesn't help, run with `--format json` instead and rank candidates yourself, but still print the final list using the same grouped markdown shape (Today / This week / Older sections with `  N. \`time\`  **project**` rows).
