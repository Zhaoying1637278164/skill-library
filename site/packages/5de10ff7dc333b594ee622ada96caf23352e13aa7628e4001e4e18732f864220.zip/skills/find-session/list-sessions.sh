#!/usr/bin/env bash
# Emit recent Claude Code sessions across all projects.
# Usage: list-sessions.sh [--limit N] [--grep PATTERN] [--format md|json] [--min-age-days N]
#
# Default format is `md`: prints a grouped markdown list ready to display.
# `json`: prints JSONL, one object per session (for programmatic ranking).

set -euo pipefail

LIMIT=10
GREP_PATTERN=""
FORMAT="md"
MIN_AGE_DAYS=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --limit) LIMIT="$2"; shift 2;;
    --grep) GREP_PATTERN="$2"; shift 2;;
    --format) FORMAT="$2"; shift 2;;
    --min-age-days) MIN_AGE_DAYS="$2"; shift 2;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done

PROJECTS_DIR="$HOME/.claude/projects"
[[ -d "$PROJECTS_DIR" ]] || { echo "no projects dir" >&2; exit 0; }

# Collect candidate files. Exclude /subagents/.
if [[ -n "$GREP_PATTERN" ]]; then
  FILES=$(grep -rli --include='*.jsonl' "$GREP_PATTERN" "$PROJECTS_DIR" 2>/dev/null | grep -v '/subagents/' || true)
else
  FILES=$(find "$PROJECTS_DIR" -name '*.jsonl' -type f -not -path '*/subagents/*' 2>/dev/null)
fi

[[ -z "$FILES" ]] && exit 0

NOW=$(date +%s)
MIN_AGE_CUTOFF=$((NOW - MIN_AGE_DAYS * 86400))

# Build sorted list of records: mtime\tsession_id\tproject\trel\tpreview\tmsg_count
RECORDS=$(
  echo "$FILES" | while IFS= read -r f; do
    [[ -f "$f" ]] || continue
    stat -f '%m %N' "$f"
  done | sort -rn | head -n "$LIMIT" | while read -r mtime path; do
    (( mtime > MIN_AGE_CUTOFF )) && continue
    session_id=$(basename "$path" .jsonl)
    project_encoded=$(basename "$(dirname "$path")")
    project=$(echo "$project_encoded" | sed 's|^-|/|; s|-|/|g')
    project_display="${project#/Users/peterrong/}"
    age=$((NOW - mtime))
    if   (( age < 3600 ));   then rel="$((age/60))m"
    elif (( age < 86400 ));  then rel="$((age/3600))h"
    elif (( age < 604800 )); then rel="$((age/86400))d"
    elif (( age < 2592000 ));then rel="$((age/604800))w"
    else                          rel="$((age/2592000))mo"
    fi

    preview=$(jq -r '
      select(.type == "user" and (.message.role // "") == "user")
      | .message.content
      | if type == "string" then . else "" end
      | select(length > 0 and (startswith("<") | not))
    ' "$path" 2>/dev/null | head -n 1)

    [[ -z "$preview" ]] && continue
    (( ${#preview} < 10 )) && continue

    msg_count=$(wc -l < "$path" | tr -d ' ')
    (( msg_count < 5 )) && continue

    # Strip leading filler tokens
    preview=$(echo "$preview" | sed -E 's/^(aight,|okie,|ok,|yo,)[[:space:]]*//i')
    # Truncate to 120 chars
    if (( ${#preview} > 120 )); then
      preview="${preview:0:117}…"
    fi
    # Use \x1f (unit separator) to avoid clash with tabs in content
    printf '%s\x1f%s\x1f%s\x1f%s\x1f%s\x1f%s\n' "$mtime" "$session_id" "$project_display" "$rel" "$preview" "$msg_count"
  done
)

[[ -z "$RECORDS" ]] && exit 0

if [[ "$FORMAT" == "json" ]]; then
  echo "$RECORDS" | while IFS=$'\x1f' read -r mtime sid proj rel preview msgs; do
    mtime_iso=$(date -r "$mtime" -u +"%Y-%m-%dT%H:%M:%SZ")
    jq -cn \
      --arg sid "$sid" --arg proj "$proj" --arg mtime "$mtime_iso" \
      --arg rel "$rel" --arg prev "$preview" --argjson msgs "$msgs" \
      '{session_id: $sid, project: $proj, mtime: $mtime, mtime_rel: $rel, preview: $prev, msg_count: $msgs}'
  done
  exit 0
fi

# Markdown output. Group by time bucket.
print_bucket() {
  local name="$1"; local body="$2"
  [[ -z "$body" ]] && return
  echo "$name"
  echo "$body"
  echo
}

{
  today=""; week=""; older=""; n=0
  while IFS=$'\x1f' read -r mtime sid proj rel preview msgs; do
    n=$((n+1))
    age=$((NOW - mtime))
    line=$(printf "  %d. \`%s\`  **%s**\n     %s" "$n" "$rel" "$proj" "$preview")
    if   (( age < 86400 ));  then today+="${line}"$'\n'
    elif (( age < 604800 )); then week+="${line}"$'\n'
    else                          older+="${line}"$'\n'
    fi
  done <<< "$RECORDS"

  print_bucket "**Today**" "$today"
  print_bucket "**This week**" "$week"
  print_bucket "**Older**" "$older"
  echo "Pick a number, or refine."
}

# Emit a sidecar map of index → session_id on stderr so the caller can resolve picks.
{
  echo "---index---"
  n=0
  while IFS=$'\x1f' read -r mtime sid proj rel preview msgs; do
    n=$((n+1))
    echo "$n	$sid	$proj"
  done <<< "$RECORDS"
} >&2
