# Changelog

## 1.2.2

- Every skill now opens by calling `getsign_help` for its flow, so the step order it works from is the server's live one rather than whatever was cached when the plugin was installed. A host refreshes these files only when the plugin version moves, so a skill could otherwise run a recipe several releases old with nothing to show it.
- Each manifest labels itself in the MCP server entry, and the skills report which flow they are running, so GetSign can see which clients and which plugin versions are actually in use and which skills get used at all. No document content, arguments or chat text is involved — see SECURITY.md.
- The Claude Code manifest now links GetSign's privacy policy (`privacyPolicyUrl`), which the Claude plugin directory asks for.

## 1.2.1

- Notes that `getsign_reset_signing_process` now starts disabled, where the signing-order guidance tells you to reset before changing order mid-flight. It and `getsign_start_sign_by_me` were shipping a schema on every request without being called once in a month; enable either with `getsign_manage_tools`.

## 1.2.0

- First-class in Codex: ships OpenAI's `.codex-plugin/plugin.json` and a root `.agents/plugins/marketplace.json`, so `codex plugin marketplace add Getsign-JP/getsign-mcp-plugin` resolves GetSign's own listing — display name, category, and composer prompts — instead of falling back to the Claude-format index.
- A DOCX merge-tag step was added to the document flows, so the skills no longer stop short of a document that carries `{{Column Title}}` tokens: `getsign_validate_document_placeholders` checks those tokens once the template is on the workflow.

## 1.1.2

- Publishes under the GetSign name: the marketplace owner and the author block in all three manifests now read `GetSign` rather than the operating company.
- Restores `appsupport@jetpackwork.com` as the contact address in all three plugin manifests, where a merge had reverted it to an address that does not receive mail. The marketplace files were unaffected, which is why the listing looked right while every plugin manifest under it did not.

## 1.1.1

- Points every install instruction and manifest link at `Getsign-JP/getsign-mcp-plugin`, the public home of this plugin.

## 1.1.0

- Installs in Cursor: the same directory now ships Agent Plugins 1.0 (`plugin.json` + `mcp.json`) and Cursor (`.cursor-plugin/`) manifests alongside the Claude Code pair.
- Skill frontmatter carries only the six Agent Skills fields — `when_to_use` is folded into `description`, which every client reads.
- Ships a square logo at `assets/logo.svg`, so the Cursor listing renders a tile rather than a blank square.

## 1.0.0

- First public release: `install-getsign-on-new-account`, `send-new-document`, `board-pending-signatures`, `create-or-update-workflow`, `sign-from-file-column`, `save-signed-document-to-file-column`.
- Bundles the hosted GetSign MCP server at `https://mcp.getsign.io/mcp`.
