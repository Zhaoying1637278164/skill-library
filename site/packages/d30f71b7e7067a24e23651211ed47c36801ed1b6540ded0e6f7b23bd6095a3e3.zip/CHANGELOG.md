# Changelog

## 0.5.3 (28 September 2026)
- Health subfolders: 3 or more exams of one type or body area get their own folder (`02.Health/Blood-Tests/`, `Thyroid/`, `Heart/`, `Prescriptions/`), names still date-first. The check-up suggests them; the inbox files into existing subfolders.
- Inbox: moving a library file back through the inbox no longer leaves a stray catalog row.

## 0.5.2 (28 September 2026)
- Inbox: a copy that only exists in `90.Review` no longer counts as a kept copy (new `exact-in-review` hint), and catalog rows of deleted files are ignored when looking for duplicates.
- Check-up: files the user deleted from Review are reported and can be recorded with `--record-review-deletions`.
- Check-up: expired documents with a "renewing" note stay in place without a question.

## 0.5.1 (25 September 2026)
- Skill descriptions updated so Claude picks the right skill for the new requests: "tidy my vault", "archive expired documents", "archive the pack", "add Leo to the vault", "I shared photos from my phone".

## 0.5.0 (25 September 2026)
- Check-up: expired documents that were replaced by a newer one are suggested for an `Archive` folder in the same category; expired ones without a replacement trigger a question (renewing or archive?).
- Check-up: tidy suggestions, a subfolder when 5 or more files of one topic or series sit in one folder.
- iPhone shortcut: save photos, PDFs and files into the Inbox from the Share button (link in the README and offered at set-up). Converts HEIC photos to full-quality JPEG.
- Packs: "archive the pack" moves a finished pack to `90.Review/Packs` (logged, undoable).
- Packs: password-protected PDFs are copied as usual but left out of combined PDFs. Claude says so before building (in the combined-PDF question and the plan table) and explains how to make an unlocked copy if a portal needs one file.
- Inbox scan: password-protected PDFs are now flagged as locked.
- Inbox scan: phone photos taken sideways or upside down are turned upright before reading (they came out as unreadable text before).

## 0.4.0 (25 September 2026)
- New skill **Prepare a pack**: paste the list of documents an application asks for (visa, residence permit renewal, mortgage, school...), and Claude matches it to the vault, asks which passport to use when someone has several, flags expiring or outdated documents, and builds `80.Packs/<name>/` with numbered copies per person and a checklist.
- Optional combined PDF per person or for the whole family, in list order, lossless.
- Check-up lists open packs and no longer counts their copies as duplicates.

## 0.3.1 (24 September 2026)
- Privacy policy, security contact, troubleshooting and support sections.

## 0.3.0 (24 September 2026)
- Masking fix: long numbers next to "/" or "." (e.g. insurance member numbers) are now hidden; better IBAN and password detection.
- Saved web pages (.html) are read as text, without page code.
- Add a family member to an existing vault (logged and undoable).
- Set-up questions written for new users.

## 0.2.0 (24 September 2026)
- Default text-recognition languages: English, Portuguese, Russian, Hebrew; language files download during set-up.

## 0.1.0 (24 September 2026)
- First version: set up a vault, process the inbox, vault check-up, find a document.
