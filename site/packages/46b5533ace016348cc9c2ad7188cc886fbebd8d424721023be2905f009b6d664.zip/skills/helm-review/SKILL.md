---
name: helm-review
description: This skill should be used when the user asks to "review a Helm chart", "check my chart", mentions Helm templates, values.yaml design, chart versioning, or debugging "helm install/upgrade" failures. Reviews charts for correctness, upgrade safety, and production readiness.
version: '0.1.0'
argument-hint: "[chart-dir]"
paths:
- "**/Chart.yaml"
- "**/values.yaml"
- "**/templates/**"
---

# Helm Chart Review

Review a Helm chart for correctness, upgrade safety, and production readiness. Start by reading `Chart.yaml`, `values.yaml`, and every file under `templates/`, then verify rendering before commenting on style.

## Step 1: Verify it renders

```bash
helm lint <chart-dir>
helm template <release-name> <chart-dir> --values <chart-dir>/values.yaml
helm template <release-name> <chart-dir> --set <edge-case-overrides>   # exercise conditionals
```

Render with non-default values too — most template bugs hide behind `if` branches that defaults never take (`ingress.enabled=true`, `autoscaling.enabled=true`, extra env lists, etc.). Pipe rendered output through `kubectl apply --dry-run=server -f -` when a cluster is available to catch schema errors lint misses.

## Step 2: Review checklist

### Workload correctness
- **Resources**: every container sets `resources.requests`; limits at least for memory. Charts shipping without requests get evicted first and schedule unpredictably.
- **Probes**: liveness AND readiness defined, configurable via values. A missing readiness probe sends traffic to unready pods on every rollout.
- **Checksum annotations for config**: config changes must restart pods —
  ```yaml
  annotations:
    checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
  ```
  Without this, `helm upgrade` updates the ConfigMap but running pods keep the old config.
- **securityContext**: `runAsNonRoot: true`, `allowPrivilegeEscalation: false`, `readOnlyRootFilesystem` where feasible, exposed through values.
- **Image**: `tag` defaults to `.Chart.AppVersion`, never `latest`; `pullPolicy` configurable; support `imagePullSecrets`.

### Template hygiene
- Names go through the standard helpers (`fullname`, `labels` in `_helpers.tpl`); every resource carries the common label block, and selector labels are the STABLE subset only — selectors are immutable, so putting `chart-version` in `matchLabels` breaks every upgrade.
- Quote string outputs that YAML could mistype: `{{ .Values.podAnnotationValue | quote }}` (unquoted `"true"`, `"1.10"` become bool/float).
- Use `with`/`default`/`required` instead of assuming keys exist; `{{ required "ingress.host is required" .Values.ingress.host }}` beats a nil-pointer render error.
- `toYaml | nindent` for passthrough blocks (`nodeSelector`, `tolerations`, `affinity`, `extraEnv`) so users aren't boxed in.

### values.yaml design
- Every template conditional has a documented default; comment each top-level key.
- Ship a `values.schema.json` for anything beyond a trivial chart — it turns silent typos (`replicas` vs `replicaCount`) into install-time errors.
- No secrets in values defaults. Reference existing Secrets by name (`existingSecret` pattern) rather than templating credentials into the release.

### Upgrade safety
- Bump `version` (chart) on every change; `appVersion` tracks the app. Breaking values changes ⇒ major version bump plus a `## Upgrading` note in the README.
- StatefulSets: `volumeClaimTemplates` and `serviceName` are immutable — flag any change to them as requiring manual migration.
- Hooks (`pre-upgrade` jobs, etc.): set `helm.sh/hook-delete-policy`, otherwise failed hook jobs accumulate and block re-runs.

## Step 3: Debugging failed installs/upgrades

- `helm install --dry-run --debug` shows the rendered manifest with the error in context.
- `Error: UPGRADE FAILED: another operation is in progress`: a stuck release — `helm history <release>` is read-only. `helm rollback <release> <last-deployed-rev>` is mutating: describe it and ask first; never run rollback automatically.
- Immutable-field errors on upgrade (selector, PVC size via template): identify the field and state plainly that it needs delete-and-recreate or a migration, not a retry.
- Release stuck `pending-upgrade` with no history to roll back: the stored release secret (`sh.helm.release.v1.*`) can be inspected with `kubectl get secrets -n <ns> -l owner=helm`.

## Deliverable

Report findings grouped by severity: **blocking** (won't render / breaks upgrades), **production risk** (missing probes, resources, checksum annotation), and **style**. Include the exact template fix for each blocking and production-risk finding.
