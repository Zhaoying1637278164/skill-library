---
name: compose-review
description: This skill should be used when the user asks to "review my docker-compose file", "fix my compose setup", mentions docker compose services not starting in order, containers that can't reach each other, compose volumes, or env var handling in compose. Reviews and fixes Compose files for reliability and local-dev ergonomics.
version: '0.1.0'
argument-hint: "[compose-file]"
paths:
- "**/compose.y*ml"
- "**/docker-compose.y*ml"
- "**/compose.yaml"
- "**/compose.yml"
---

# Docker Compose Review

Review `compose.yaml` / `docker-compose.yml` files for startup reliability, networking, data safety, and environment handling. Read the compose file and any referenced `Dockerfile`s and `.env` before commenting.

## Startup ordering — the #1 source of flaky compose setups

`depends_on` alone only orders CONTAINER START, not readiness. An app that connects to Postgres on boot will race it and crash. The correct pattern:

```yaml
services:
  db:
    image: postgres:16
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U $${POSTGRES_USER:-postgres}"]
      interval: 5s
      timeout: 3s
      retries: 10
  app:
    depends_on:
      db:
        condition: service_healthy
```

Every dependency a service connects to at startup needs a `healthcheck` + `condition: service_healthy`. Common healthchecks: `pg_isready` (Postgres), `mysqladmin ping -h localhost` (MySQL), `redis-cli ping` (Redis), `curl -f http://localhost:<port>/health || exit 1` (HTTP apps — note the image must contain curl/wget).

## Networking

- Services reach each other by SERVICE NAME on the default network — `db:5432`, never `localhost:5432` (localhost inside a container is the container itself). Flag any inter-service `localhost` URL.
- `ports:` is for host access only; container-to-container traffic doesn't need it. Unnecessary published ports are a common accidental exposure — prefer `expose:` or nothing.
- Bind published ports to loopback for local dev: `"127.0.0.1:5432:5432"` — a bare `"5432:5432"` listens on all interfaces.

## Data safety

- Named volumes for databases, declared under top-level `volumes:`. Flag databases with NO volume (data lost on `down`) and warn that `docker compose down -v` deletes named volumes.
- Bind mounts for source code in dev is fine, but flag a bind mount over the container's dependency directory (`.:/app` hiding the image's `/app/node_modules`) — the standard fix is an anonymous volume: `- /app/node_modules`.

## Environment and secrets

- `env_file` vs `environment`: `environment` wins on conflict; make precedence explicit rather than accidental.
- Warn on real credentials committed in the compose file or a committed `.env` — recommend `.env` in `.gitignore` with a committed `.env.example`.
- Variable escaping: `$$` for literal `$` inside commands/healthchecks (single `$` is interpolated by compose at parse time).

## Reliability details

- `restart: unless-stopped` for long-running services in anything beyond throwaway dev.
- Pin image tags (`postgres:16`, not `postgres`) — an unpinned pull can silently major-upgrade a database.
- `init: true` for apps that spawn subprocesses, and exec-form commands, so signals propagate and `compose stop` doesn't hang for 10s per service.
- Resource limits (`mem_limit`, or `deploy.resources` with compose v2) for anything memory-hungry running on a laptop.
- The `version:` top-level key is obsolete in Compose v2 — remove it.

## Verification

After fixing, validate and exercise the startup path:

```bash
docker compose config            # parse + interpolation check
docker compose up -d --wait      # --wait respects healthchecks; nonzero exit if any service unhealthy
docker compose ps                # confirm all healthy
docker compose logs --tail=50 <flaky-service>
```

## Deliverable

Return the corrected compose file plus a finding list ordered by impact: startup races, data-loss risks, networking errors, security issues, then style. Keep the user's structure and comments intact — change only what a finding justifies.
