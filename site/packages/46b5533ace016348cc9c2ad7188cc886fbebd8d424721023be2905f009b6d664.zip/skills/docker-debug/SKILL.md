---
name: docker-debug
description: This skill should be used when a container exits immediately, docker run fails, a port is already allocated, the user cannot connect to a published port, docker logs are empty, a bind mount hides files, permission is denied in the container, or they see "exec format error". Runs a structured, read-only-first diagnostic workflow with docker / docker compose.
version: '0.1.0'
argument-hint: "[container-or-compose-service]"
---

# Docker Debugging

Diagnose local Docker and Compose failures with evidence first. Stay read-only until the user agrees to a mutating command (`docker rm`, `docker restart`, `docker compose up`/`down`).

## Step 1: Gather evidence (read-only)

```bash
docker ps -a
docker logs <container> --tail=100
docker inspect <container>
docker compose ps
docker compose logs --tail=100
docker compose config
```

If this is a Compose project, prefer `docker compose ps` / `logs` / `config` and point at the **compose-review** skill for file-level races, `depends_on`, and service-name DNS. Report what you found before proposing a fix.

## Step 2: Classify and follow the playbook

### Exited immediately (nonzero or zero exit)
The container created then stopped. The cause is almost always the process inside, not Docker daemon health.
1. `docker ps -a` — read **STATUS** and **STATUS (Exit N)**. `docker inspect --format '{{.State.ExitCode}} {{.State.Error}} {{.State.OOMKilled}}' <container>`.
2. `docker logs <container>` (and timestamps if needed). Empty logs → entrypoint/binary failed before stdio, or logs go to a file; check `docker inspect` `Path`/`Args`/`Entrypoint`/`Cmd`.
3. Exit codes: **0** on a long-running service means the command finished (override replaced the server process). **1** application error. **127** command not found. **137** SIGKILL / OOM (`OOMKilled=true`). **139** segfault.
4. Do not `docker start`/`rm` during diagnosis. Propose the smallest command or Dockerfile/`command:` change and ask first.

### Port already allocated / cannot bind
`Bind for 0.0.0.0:PORT failed: port is already allocated` or `address already in use`.
1. Read the published ports from `docker ps` and `docker inspect --format '{{json .HostConfig.PortBindings}}' <container>`.
2. On the host, identify the occupant with `lsof -nP -iTCP:<port> -sTCP:LISTEN` or `docker ps --filter publish=<port>` — another container often owns it.
3. Compose `ports:` collisions across projects are common. `docker compose config` shows the interpolated host port.
4. Fixes to propose (ask before applying): change the host port, stop the other container, or bind `127.0.0.1:<port>:<port>` if remote access was unintentional.

### Cannot connect to a published port
The container is running but `localhost:PORT` fails from the host (or works from the host and fails from another container).
1. Confirm the container is running and the port mapping: `docker ps` vs `docker inspect` `NetworkSettings.Ports`.
2. App listening on `127.0.0.1` inside the container is unreachable via published ports — it must listen on `0.0.0.0`. Logs or inspect `Cmd` often show `--host 127.0.0.1`.
3. Host vs container: from another Compose service, use the **service name** and **container port**, not `localhost` and not the host-published port. If the file is Compose, continue in compose-review.
4. IPv6 / `localhost` resolving to `::1` while Docker bound IPv4 only — try `127.0.0.1`.

### Empty docker logs
1. Confirm you have the right container: `docker ps -a` (Compose prefixes project names).
2. `docker logs` only captures stdout/stderr. Apps that log to a file inside the container will look empty — `docker inspect` mount list may show a log volume.
3. Logging driver: `docker inspect --format '{{.HostConfig.LogConfig.Type}}' <container>`. `none` or a broken json-file rotation can hide output.
4. Crashed before exec: empty logs plus Create/Start error in `inspect.State.Error`.

### Volume / bind-mount hiding files
The image has files that disappear at runtime, or edits on the host never appear.
1. `docker inspect --format '{{json .Mounts}}' <container>` — note Source, Destination, RW, and whether it is a bind or named volume.
2. Bind-mounting the project root over `/app` hides image-built `node_modules` / venv. Compose anonymous volume `- /app/node_modules` is the usual fix (compose-review).
3. Wrong relative path: Source on the host does not exist → Docker may create a directory and mount an empty tree. Confirm the host path.
4. Named volume vs bind: data in a volume survives `compose down` without `-v`; a bind follows the host folder.

### Permission denied in the container
`Permission denied`, EACCES on bind-mounted files, or cannot write to a directory.
1. `docker inspect` `User` (`Config.User`) vs mount ownership. Host UID/GID often does not match the container user (especially rootless Docker or a `USER` in the Dockerfile).
2. Read-only mounts (`"RW": false`) and `read_only: true` / `:ro`.
3. Linux host: file modes on the bind source. macOS/Windows virtiofs can still UID-mismatch.
4. Propose `user:` in Compose, `chown` in the image, or matching host UID — ask before chmod/chown on the host.

### Exec format error / architecture mismatch
`exec format error` or `cannot execute binary file: Exec format error`.
1. Image vs host arch: `docker image inspect <image> --format '{{.Architecture}} {{.Os}}'` vs `uname -m` / `docker version` (Server OS/Arch).
2. Common: pulling `linux/amd64` on Apple Silicon without emulation, or copying a macOS binary into a Linux image.
3. `FROM` + `COPY` of a prebuilt binary that was compiled for the wrong GOOS/GOARCH.
4. Do not `docker buildx build --platform` during diagnosis unless the user asks; report the arch mismatch and the smallest rebuild/platform pin.

### Image not found / pull failure
`Unable to find image` / `manifest unknown` / `unauthorized`.
1. Exact ref: `docker compose config` interpolated image, or the `docker run` argument. Tag typos and private registries without `docker login` are the usual causes.
2. `docker manifest inspect <image>` is read-only when the daemon can reach the registry.
3. Compose build vs pull: `build:` without `image:` may still name a local tag; missing `--build` is a "image not found" after `down --rmi`.
4. Ask before `docker pull` / `docker compose pull` if that would hit a private registry or a large download.

### Networking: localhost vs service name
1. Inside Compose, services resolve by **service name** on the project network. `localhost` in a container is itself — flag `DB_HOST=localhost` for a sibling `db` service.
2. Published host ports are for the host (and other machines), not for container-to-container traffic.
3. Hand off file-level Compose networking reviews to **compose-review**.

## Step 3: Propose the fix

State the diagnosis with the evidence line that proves it, then the smallest fix (compose/Dockerfile/`docker run` flag). Ask before `docker rm`, `docker restart`, `docker compose up`, `docker compose down`, or anything that deletes volumes (`down -v`).

## Deliverable

Diagnosis with evidence (command + relevant output) and the smallest fix. If Compose-specific, say so and reuse compose-review rather than duplicating startup-ordering guidance.
