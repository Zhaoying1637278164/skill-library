---
name: dockerfile-optimize
description: This skill should be used when the user asks to "optimize a Dockerfile", "make my image smaller", "speed up docker build", mentions slow builds, large image size, Docker layer caching, or asks to review/write a Dockerfile. Applies multi-stage builds, cache-friendly layer ordering, and security hardening.
version: '0.1.0'
argument-hint: "[Dockerfile]"
paths:
- "**/Dockerfile*"
---

# Dockerfile Optimization

Review or rewrite Dockerfiles for build speed, image size, and security. Before proposing changes, read the existing Dockerfile, any `.dockerignore`, and identify the language/toolchain — the right pattern is stack-specific.

## Measure first

When a built image is available, quantify before optimizing:

```bash
docker image ls <image>                 # total size
docker history <image> --no-trunc      # size per layer — find the fat ones
```

Report the top offending layers so the user sees where the size actually comes from.

## Layer ordering for cache hits

Order instructions from least to most frequently changing. The single most impactful pattern — copy dependency manifests and install BEFORE copying source:

```dockerfile
# Good: source changes don't invalidate the dependency layer
COPY package.json package-lock.json ./
RUN npm ci
COPY . .
```

Equivalents: `requirements.txt` / `uv.lock` + install before `COPY . .` (Python), `go.mod go.sum` + `go mod download` (Go), `Cargo.toml Cargo.lock` + a dummy-build or `cargo chef` (Rust), `pom.xml` + `mvn dependency:go-offline` (Java).

For repeat builds with BuildKit, add cache mounts to package managers:

```dockerfile
RUN --mount=type=cache,target=/root/.npm npm ci
RUN --mount=type=cache,target=/var/cache/apt,sharing=locked apt-get update && apt-get install -y ...
```

## Multi-stage builds

Build tools never belong in the runtime image. Pattern:

```dockerfile
FROM golang:1.23 AS build
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 go build -o /out/app ./cmd/app

FROM gcr.io/distroless/static-debian12:nonroot
COPY --from=build /out/app /app
USER nonroot
ENTRYPOINT ["/app"]
```

Runtime base selection, smallest first: `scratch` (static binaries) → distroless → `alpine` (musl caveats for glibc-linked binaries and some Python wheels) → `debian:*-slim`. Interpreted languages: use the official `-slim` variant and copy only the built artifact + production dependencies from the build stage (`npm ci --omit=dev` in a separate prod-deps stage, or Python wheels installed into a venv that gets copied).

## Size reducers

- `.dockerignore` is mandatory — at minimum: `.git`, `node_modules`/`venv`, build output, logs, `.env*`. A missing `.dockerignore` silently bloats the build context and busts the cache on every commit.
- Combine package-manager install and cleanup in ONE `RUN` (cleanup in a later layer removes nothing): `apt-get update && apt-get install -y --no-install-recommends <pkgs> && rm -rf /var/lib/apt/lists/*`.
- Don't `RUN chown -R` or `chmod -R` over large trees in a separate layer — it duplicates every file. Use `COPY --chown=user:group` instead.

## Security hardening

- **Non-root**: create and switch to an unprivileged user (`USER`), or use a `:nonroot` distroless base. Required by most K8s admission policies.
- **Pin bases**: a named tag at minimum (`node:22-slim`), digest pin (`@sha256:...`) for reproducibility. Never bare `latest`.
- **No secrets in layers**: build-time secrets go through `RUN --mount=type=secret,...` — an `ARG` or a `COPY`-then-delete leaks into layer history.
- `HEALTHCHECK` for standalone Docker/Compose use (Kubernetes ignores it — probes replace it).
- Prefer exec-form `ENTRYPOINT ["bin", "arg"]` so the process receives signals (PID 1 shell form swallows SIGTERM → 10s kill delay on every deploy).

## Deliverable

Present the optimized Dockerfile with a short list of what changed and why each change matters (cache, size, or security). If the image can be built locally, offer to build both and compare `docker image ls` sizes as proof.
