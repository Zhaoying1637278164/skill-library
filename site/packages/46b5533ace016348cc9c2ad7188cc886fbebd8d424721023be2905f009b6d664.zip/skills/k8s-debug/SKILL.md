---
name: k8s-debug
description: This skill should be used when the user asks to "debug a pod", "why is my pod crashing", mentions "CrashLoopBackOff", "ImagePullBackOff", "OOMKilled", "pod pending", "pod not ready", or asks to troubleshoot any Kubernetes workload, Service, Ingress, or DNS problem. Runs a structured, read-only-first diagnostic workflow with kubectl.
version: '0.1.0'
argument-hint: "[namespace] [pod]"
---

# Kubernetes Debugging

Diagnose Kubernetes workload failures with a structured workflow: gather evidence first, classify the symptom, then follow the matching playbook. Never mutate the cluster while diagnosing — all commands below are read-only unless explicitly marked as a fix.

## Step 1: Gather evidence

Run these before forming any hypothesis (substitute the namespace; add `-A` if unknown). Start with a full pod list — CrashLoopBackOff is usually still phase=Running, so `status.phase!=Running` will miss it. Flag STATUS not in {Running, Completed, Succeeded} **or** READY not fully ready (e.g. `0/1`, `1/2`):

```bash
kubectl get pods -n <ns> -o wide
kubectl describe pod <pod> -n <ns>
kubectl logs <pod> -n <ns> --previous --tail=100   # previous container, if it restarted
kubectl logs <pod> -n <ns> --tail=100
kubectl get events -n <ns> --sort-by=.lastTimestamp | tail -30
```

The `describe` output's **State / Last State / Reason / Exit Code** block and the **Events** section usually identify the failure class. Report what you found to the user before proposing fixes.

## Step 2: Classify and follow the playbook

### CrashLoopBackOff
The container starts and exits repeatedly. The cause is inside the container, not the scheduler.
1. Read `--previous` logs — the crash reason is almost always there.
2. Check the exit code in `describe`:
   - **Exit 0**: the process finishes and exits — wrong for a long-running workload. Check `command`/`args` override the image's entrypoint incorrectly, or the app needs a foreground mode.
   - **Exit 1 / app-specific**: application error — missing env var, unreachable dependency, bad config file. Cross-check `envFrom`/`configMapRef` names actually exist: `kubectl get configmap,secret -n <ns>`.
   - **Exit 137**: SIGKILL — usually OOM (see OOMKilled) or failing liveness probe killing it mid-start.
3. If logs are empty, report that — the entrypoint may have failed before producing output (missing binary or shared library). Do **not** run `kubectl debug` during diagnosis. Offer `kubectl debug -it <pod> --image=busybox --target=<container>` as an opt-in follow-up only after asking.
4. Liveness probe too aggressive is a classic: compare probe `initialDelaySeconds` against actual app startup time in the logs. Prefer a `startupProbe` for slow-starting apps.

### OOMKilled (exit 137, Reason: OOMKilled)
1. Confirm: `kubectl describe pod` shows `Last State: Terminated, Reason: OOMKilled`.
2. Compare actual usage vs limit: `kubectl top pod <pod> -n <ns> --containers` (requires metrics-server).
3. Distinguish undersized limit (steady usage near the limit → raise `resources.limits.memory`) from a leak (usage climbs until each kill → fix the app; raising the limit only delays it).
4. JVM/Node caveat: the runtime must respect the cgroup limit (modern JVMs do via `MaxRAMPercentage`; for Node set `--max-old-space-size` below the limit).

### ImagePullBackOff / ErrImagePull
1. `describe` Events show the exact pull error — read it verbatim.
2. **manifest unknown / not found**: tag typo or tag never pushed. Verify the exact ref with the registry (`docker manifest inspect <image>` locally).
3. **unauthorized / authentication required**: private registry — check `imagePullSecrets` on the pod/serviceaccount exists in the SAME namespace: `kubectl get secret <name> -n <ns>`.
4. **x509 / TLS**: private registry with self-signed cert — node-level containerd config, not fixable from the manifest.
5. `latest` tag pulled onto a node with a stale cache + `imagePullPolicy: IfNotPresent` explains "it works on one node only" — pin digests or real tags.

### Pending (never scheduled)
1. `describe pod` Events state the reason: `0/N nodes are available: ...` — parse each clause.
2. **Insufficient cpu/memory**: requests exceed free capacity — check `kubectl describe nodes | grep -A5 "Allocated resources"`; lower requests or scale nodes.
3. **node(s) didn't match node selector/affinity**: compare pod `nodeSelector`/`affinity` with `kubectl get nodes --show-labels`.
4. **untolerated taint**: `kubectl describe node <node> | grep Taints` — add a toleration or use a different pool.
5. **unbound PersistentVolumeClaim**: `kubectl get pvc -n <ns>` — Pending PVC means no matching PV/StorageClass, or a WaitForFirstConsumer deadlock with zone affinity.

### Running but not Ready / Service returns no endpoints
1. Readiness probe failing: `describe pod` shows probe failures with the HTTP code or connection error — verify the probe port/path against what the container actually listens on (`kubectl exec <pod> -- ss -tlnp` where available).
2. Service selector mismatch is the top cause of "Service doesn't work": `kubectl get endpoints <svc> -n <ns>` — empty endpoints means the Service `selector` doesn't match pod labels. Diff them explicitly.
3. Port mismatch: Service `targetPort` must match the container's listening port, not the Service `port`.


### Init container failures
The pod never reaches the app container because an init container exited non-zero or is still running.
1. `kubectl describe pod <pod> -n <ns>` — read **Init Containers** State / Last State / Reason / Exit Code, not only the app container.
2. Logs: `kubectl logs <pod> -n <ns> -c <init-container> --tail=100` and `--previous` if it restarted.
3. Common causes: missing ConfigMap/Secret (`CreateContainerConfigError` on the init container), image pull on the init image, a migration job that fails, or a wait-for-service script that never sees DNS.
4. `kubectl get pod <pod> -n <ns> -o jsonpath='{.status.initContainerStatuses}'` to confirm which init is blocking `PodInitialized`.

### CreateContainerConfigError / CreateContainerError
The kubelet cannot start the container. This is a spec/config problem, not an application crash.
1. `describe` Events: **CreateContainerConfigError** usually means a missing Secret, ConfigMap, or projected volume key. **CreateContainerError** often means a bad command/args or missing binary in the image.
2. Confirm referenced objects exist in the same namespace: `kubectl get secret,configmap -n <ns>`. Match every `envFrom` / `secretKeyRef` / `configMapKeyRef` / volume name.
3. If the objects exist, check the key names — a typo in `key:` produces the same error as a missing object.
4. For CreateContainerError, compare `command`/`args` against the image entrypoint (`docker image inspect` locally if you have the image). Do not `kubectl run` a replacement during diagnosis.

### FailedMount / FailedAttachVolume
The pod is stuck because a volume never attached or never mounted.
1. `describe pod` Events: **FailedMount**, **FailedAttachVolume**, timeout waiting for kubelet.
2. PVC: `kubectl get pvc -n <ns>` — Pending means no PV/StorageClass; Lost/Released needs a new claim. Check `kubectl describe pvc <name> -n <ns>` for provisioning errors.
3. Node attach: if the PVC is Bound but the pod is Pending/ContainerCreating, the volume may still be attached to a deleted node — note the node in Events; do not delete pods to force detach unless the user opts in.
4. SubPath / secret/configMap volume: missing key → FailedMount. Same check as CreateContainerConfigError.

### Evicted (DiskPressure / MemoryPressure)
The pod was evicted by the kubelet, not crashed by the app.
1. Confirm: `describe pod` Reason **Evicted** and a message mentioning DiskPressure, MemoryPressure, PIDPressure, or node ephemeral-storage.
2. Node conditions: `kubectl describe node <node>` — look at Conditions and Allocated resources. `kubectl get pods -A --field-selector spec.nodeName=<node>` shows what was competing for disk/memory.
3. Ephemeral-storage evictions: emptyDir, logs, and images. Check `df` via node describe; image GC and log rotation are node-level, not a pod YAML typo.
4. Distinguish from OOMKilled (container exit 137, Reason OOMKilled). Evicted pods are not restarted in place; a controller creates a replacement.

### Job / CronJob failures
A Job is not a long-running pod — Succeeded is healthy; look at failed pods and backoff.
1. `kubectl get job,cronjob -n <ns>` and `kubectl describe job <job> -n <ns>` — **backoffLimit**, completions vs failed, and the last failed pod name.
2. Logs of the failed pod: `kubectl logs job/<job> -n <ns> --tail=100` or the pod listed under the Job's events.
3. CronJob: `kubectl get cronjob <name> -n <ns> -o yaml` — `suspend`, `concurrencyPolicy`, `startingDeadlineSeconds`. Failed Jobs pile up if `failedJobsHistoryLimit` is high; that is history, not a live crash loop.
4. Do not `kubectl delete job` during diagnosis. Propose a spec fix (command, image, backoffLimit, resources) and ask before deleting a stuck Job.

### Ingress / TLS
Traffic never reaches pods, or HTTPS fails, even when the Service has endpoints.
1. `kubectl get ingress -n <ns>` — ADDRESS empty means no controller claimed it. Compare `ingressClassName` / `kubernetes.io/ingress.class` with `kubectl get ingressclass`.
2. Backend: Service name/port on the Ingress must match a Service that has endpoints (`kubectl get endpoints <svc> -n <ns>`). Wrong class or wrong Service name both look like "Ingress does nothing".
3. TLS: `kubectl describe ingress <name> -n <ns>` for secret errors. If cert-manager is in use: `kubectl get certificate,certificaterequest,order,challenge -n <ns>` and `kubectl describe certificate <name> -n <ns>` — Ready=False is the diagnosis, not a guess about DNS.
4. Keep this read-only: do not restart the ingress controller or delete challenges unless the user opts in.

### DNS / networking inside the cluster
1. Check CoreDNS itself (read-only): `kubectl get pods -n kube-system -l k8s-app=kube-dns` and `kubectl logs -n kube-system -l k8s-app=kube-dns --tail=100`.
2. List NetworkPolicies: `kubectl get networkpolicy -n <ns>` (and `-A` if the client is in another namespace) — a default-deny policy with no matching allow rule is a frequent silent breaker.
3. Do **not** create a throwaway DNS pod during diagnosis. If CoreDNS looks healthy and policies do not explain the failure, offer `kubectl run dnstest --rm -it --image=busybox:1.36 --restart=Never -- nslookup <svc>.<ns>.svc.cluster.local` as an opt-in check only after asking.

## Step 3: Propose the fix

State the diagnosis with the evidence line that proves it, then propose the smallest fix (manifest diff or command). Ask before running anything that mutates the cluster (`apply`, `edit`, `rollout restart`, `delete`). After the fix, verify: `kubectl rollout status deployment/<name> -n <ns>` and re-check events.
