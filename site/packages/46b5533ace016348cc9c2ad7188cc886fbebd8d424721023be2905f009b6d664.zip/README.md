# Drydock

A Claude Code plugin for diagnosing and fixing Kubernetes and Docker problems: structured pod-failure triage, Dockerfile optimization, Helm chart review, and Docker Compose review.

## What's included

### Skills

| Skill | What it does |
|---|---|
| `k8s-debug` | Structured, read-only-first diagnosis of Kubernetes failures: CrashLoopBackOff, OOMKilled, ImagePullBackOff, Pending pods, failing readiness, empty Service endpoints, and in-cluster DNS/NetworkPolicy issues — each with a concrete kubectl playbook. |
| `dockerfile-optimize` | Reviews or rewrites Dockerfiles for build speed (cache-friendly layer ordering, BuildKit cache mounts), image size (multi-stage builds, base image selection, `.dockerignore`), and security (non-root, pinned bases, no secrets in layers). |
| `helm-review` | Reviews Helm charts for correctness, upgrade safety (immutable selectors, checksum annotations, hook policies), values design, and production readiness — and debugs failed installs/upgrades. |
| `compose-review` | Reviews Compose files for startup races (`depends_on` + healthchecks), networking mistakes, data-loss risks, env/secret handling, and signal propagation. |
| `docker-debug` | Structured, read-only-first diagnosis of local Docker/Compose runtime failures: immediate exits, port binds, empty logs, bind mounts, permission denied, exec format error, and published-port connectivity — each with a concrete docker playbook. |

These activate automatically when your request matches (e.g. "why is my pod crashing?", "make this image smaller"), or invoke them directly: `/k8s-debug`, `/docker-debug`, `/dockerfile-optimize`, `/helm-review`, `/compose-review`.

### Agents

- **cluster-triage** — a read-only cluster/namespace health sweep that inspects nodes, workloads, events, capacity, and PVCs, and returns a prioritized findings report with evidence for every claim. It never mutates the cluster.

## Requirements

- `kubectl` configured for your cluster (for the Kubernetes skills and the triage agent)
- `docker` / `docker compose` (for the Docker skills)
- `helm` (for chart review)

The skills degrade gracefully: anything a missing tool prevents is reported as "not checked" rather than guessed at.

## Safety model

Diagnosis is read-only. Skills gather evidence with `get`/`describe`/`logs`/`events`/`template`/`config` style commands and always ask before running anything that mutates a cluster or your files.

## Installation

Claude Code installs plugins from a marketplace catalog. Add this repo as a marketplace, then install the plugin:

```
/plugin marketplace add ayobamiseun/drydock
/plugin install drydock@drydock
```

Or install from the git URL without a marketplace:

```
claude plugin install https://github.com/ayobamiseun/drydock.git
```

## License

MIT — see [LICENSE](LICENSE).
