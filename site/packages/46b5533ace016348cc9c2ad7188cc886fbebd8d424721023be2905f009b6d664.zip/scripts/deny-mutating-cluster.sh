#!/usr/bin/env bash
# PreToolUse: deny mutating kubectl/helm/docker commands during diagnosis.
# Always exit 0. Invalid JSON or a missing interpreter must not block the tool.

raw=$(cat)
if ! command -v python3 >/dev/null 2>&1; then
  exit 0
fi

py=$(cat <<'PY'
import json, re, sys

raw = sys.stdin.read()
try:
    payload = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.exit(0)
if not isinstance(payload, dict):
    sys.exit(0)

def extract(obj):
    if not isinstance(obj, dict):
        return ""
    for key in ("tool_input", "toolInput", "input"):
        inner = obj.get(key)
        if isinstance(inner, dict):
            for ck in ("command", "cmd", "bash"):
                v = inner.get(ck)
                if isinstance(v, str) and v.strip():
                    return v
        elif isinstance(inner, str) and inner.strip():
            return inner
    for ck in ("command", "cmd"):
        v = obj.get(ck)
        if isinstance(v, str) and v.strip():
            return v
    return ""

cmd = extract(payload)
if not cmd:
    sys.exit(0)

DENY = {
    "hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": (
            "Diagnosis is read-only. Ask before running mutating "
            "kubectl/helm/docker commands."
        ),
    }
}

flags = r'(?:\s+(?:--[^\s=]+(?:=[^\s]+)?|-[A-Za-z](?:\s+[^\s-][^\s]*)?))'
kctl = r'\bkubectl\b' + flags + r'*'
mut_k = re.compile(
    kctl + r'\s+(?:apply|delete|edit|patch|replace|scale|drain|cordon|'
    r'uncordon|taint|create|run|debug)\b', re.I)
roll = re.compile(kctl + r'\s+rollout\s+(?:restart|undo|pause|resume)\b', re.I)
lab = re.compile(kctl + r'\s+(?:label|annotate)\b', re.I)
listf = re.compile(r'(?:^|\s)--list(?:\s|=|$)', re.I)
helm = re.compile(
    r'\bhelm\b' + flags + r'*\s+(?:install|upgrade|rollback|uninstall|delete)\b',
    re.I)
dcomp = re.compile(
    r'\b(?:docker(?:\s+compose)?|docker-compose)\s+'
    r'(?:up|down|start|stop|restart|rm)\b', re.I)
docker = re.compile(
    r'\bdocker\s+(?:rm|rmi|stop|kill|prune)\b|\bdocker\s+system\s+prune\b', re.I)

def mutating(s):
    if mut_k.search(s) or roll.search(s) or helm.search(s):
        return True
    if dcomp.search(s) or docker.search(s):
        return True
    m = lab.search(s)
    if m and not listf.search(s[m.start():]):
        return True
    return False

if mutating(cmd):
    json.dump(DENY, sys.stdout)
    sys.stdout.write("\n")
PY
)
printf '%s' "$raw" | python3 -c "$py"
exit 0
