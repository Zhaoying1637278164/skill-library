"""Rendering: the three templates, the renderer chain and backend detection.

HTML and Markdown builds are always tested. A typst build runs only when typst
is on PATH, and a browser PDF build only when Chrome, Chromium or Edge is found.
"""

import html as htmlmod
import json
import os
import re
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

try:
    from helpers import make_ws, run
    from test_sheet import (NOW, SUBJECT, cold_spec, drills_spec, new_sheet, sheet_row, subject_dir,
                            theory_spec)
except ImportError:  # run as part of the tests package
    from tests.helpers import make_ws, run
    from tests.test_sheet import (NOW, SUBJECT, cold_spec, drills_spec, new_sheet, sheet_row, subject_dir,
                                  theory_spec)

from lib import TEMPLATES_DIR, render
from lib import io as fio

DAY = "2026-10-15"  # a Thursday
GATE_1 = ("If 2 of items 1–3 have a failed check, an “I don't know” or an empty box: "
          "stop and send a photo of 1–3.")
GATE_2 = ("If 2 of items 4–6 have a failed check, an “I don't know” or an empty box: "
          "stop and send a photo of 4–6.")
V_RULE = ("If a word here was never explained to you, on this sheet or an earlier one, write it beside "
          "that answer: that's my mistake, not yours")
CLOSE = ("Send me your pencil answers and keep this sheet open until I've marked them. "
         "Then put it away and tell me “closed”. The drills come on their own sheet.")


def practised_drills(**over):
    """Drills on a topic at mastery 2 or above: the failure gate stops only on 2 failed checks,
    "I don't know"s or blanks (the fixture's own blocks, at mastery 0, stop every time)."""
    spec = drills_spec(**over)
    for b in spec["blocks"]:
        b.pop("gate", None)
    return spec


def visible_text(page):
    """The text a reader sees in an HTML page (tags dropped, entities decoded, spaces collapsed)."""
    body = page.split("<body>", 1)[-1]
    return re.sub(r"\s+", " ", htmlmod.unescape(re.sub(r"<[^>]+>", " ", body))).strip()


def typst_balance_problems(src):
    """Brackets that do not balance outside string literals and comments ([] if well formed)."""
    stack, i, n = [], 0, len(src)
    pairs = {")": "(", "]": "[", "}": "{"}
    while i < n:
        c = src[i]
        if c == '"':
            i += 1
            while i < n and src[i] != '"':
                if src[i] == "\\":
                    i += 1
                elif src[i] == "\n":
                    return ["newline inside a string literal at %d" % i]
                i += 1
            if i >= n:
                return ["unterminated string literal"]
        elif src.startswith("//", i):
            while i < n and src[i] != "\n":
                i += 1
            continue
        elif c in "([{":
            stack.append(c)
        elif c in ")]}":
            if not stack or stack[-1] != pairs[c]:
                return ["unbalanced %s at %d" % (c, i)]
            stack.pop()
        i += 1
    return ["unclosed %s" % "".join(stack)] if stack else []


class Base(unittest.TestCase):
    def setUp(self):
        self._old_now = os.environ.get("INDELIBLE_NOW")
        os.environ["INDELIBLE_NOW"] = NOW
        self.tmp = Path(tempfile.mkdtemp(prefix="indelible-render-"))

    def tearDown(self):
        if self._old_now is None:
            os.environ.pop("INDELIBLE_NOW", None)
        else:
            os.environ["INDELIBLE_NOW"] = self._old_now
        shutil.rmtree(str(self.tmp), ignore_errors=True)


# ==========================================================================
# Templates (in-process)
# ==========================================================================

class HtmlTemplateTests(Base):
    def setUp(self):
        Base.setUp(self)
        self.page = render.render_html(practised_drills(), date=DAY, tools="none")
        self.text = visible_text(self.page)

    def test_header_has_title_date_weekday_minutes_count_and_provenance(self):
        self.assertIn('<h1 id="sheet-title">Other words, same idea</h1>', self.page)
        self.assertIn("Thursday 15 October 2026", self.text)
        self.assertIn('datetime="2026-10-15"', self.page)
        self.assertIn("About 12 min · 6 questions · Practice — written by Claude", self.text)

    def test_the_sheet_code_ends_the_header_line(self):
        m = render.build_model(cold_spec(), date=DAY, sheet_code="IELTS-07")
        self.assertEqual(m["meta"], "About 10 min · 4 questions · Measurement — written by Claude · Sheet IELTS-07")
        self.assertIn("· Sheet IELTS-07", render.render_markdown(cold_spec(), date=DAY, sheet_code="IELTS-07"))
        self.assertIn('· Sheet IELTS-07"', render.render_typst(cold_spec(), date=DAY, sheet_code="IELTS-07"))
        self.assertNotIn("Sheet ", render.build_model(cold_spec(), date=DAY)["meta"], "no code, no mention")

    def test_rules_box(self):
        rules = visible_text(self.page.split('<section class="rules"', 1)[1].split("</section>", 1)[0])
        for s in ("Closed book", "Answer on paper, one answer in each box.",
                  "Write the check beside each answer.", "“I don't know” is always an accepted answer.",
                  "Stop after 12 minutes.", "Tools allowed: none.", V_RULE,
                  "If a check fails and you can't see why within a minute, mark it ✗ or “no”, leave your "
                  "answer and the check as they are, put its number on the Least-sure line and go on: "
                  "I'll show you where at marking."):
            self.assertIn(s, rules)

    def test_the_exams_formula_sheet_is_allowed_where_the_exam_gives_one(self):
        from lib import render
        clean = "You may use a clean copy of the exam's formula sheet, with nothing written on it."
        for spec in (drills_spec(), cold_spec(), drills_spec(type="mock")):
            lines = render.rules(spec, "calculator", reference_sheet=True)
            self.assertTrue(any(line.startswith("Closed book") and clean in line for line in lines), spec["type"])
            self.assertIn("Tools allowed: calculator, the exam's formula sheet.", lines)
            self.assertFalse(any(clean in line for line in render.rules(spec, "calculator")))
        self.assertIn("Tools allowed: the exam's formula sheet.",
                      render.rules(drills_spec(), "none", reference_sheet=True))
        # A sheet read with the page open says nothing about it.
        for spec in (theory_spec(), drills_spec(type="repair")):
            lines = render.rules(spec, "calculator", reference_sheet=True)
            self.assertFalse(any("formula sheet" in line for line in lines), spec["type"])
        # The rest of the box is unchanged.
        lines = render.rules(drills_spec(), "calculator", reference_sheet=True)
        self.assertTrue(any(line.startswith("If a check fails and you can't see why within a minute")
                            for line in lines))
        self.assertIn(V_RULE, " ".join(lines))

    def test_the_word_rule_counts_earlier_sheets_and_asks_for_the_word(self):
        # Drills and rechecks use words defined on the theory sheet (defined_on:<id>): those are
        # not Claude's mistake, so the rule can't say "not defined on this sheet".
        for spec in (drills_spec(), cold_spec(), theory_spec()):
            lines = render.rules(spec, "none")
            self.assertEqual(lines[-1], V_RULE + ".")
        self.assertIn('<li class="v-rule">%s.</li>' % htmlmod.escape(V_RULE, quote=True), self.page)
        for old in ("mark it V", "not defined on this sheet"):
            self.assertNotIn(old, self.text)

    def test_practice_sheets_say_the_learner_may_ask_for_a_hint(self):
        stuck = "Stuck on a question after a real try? Tell me its number: you get a small hint, never the answer."
        idk = "“I don't know” is always an accepted answer."
        # The sheets the hint ladder serves (session-teach.md §3) say so, on the "I don't know" line.
        for t in ("drills", "theory", "external", "example", "repair"):
            spec = theory_spec() if t in ("theory", "external", "example") else drills_spec(type=t)
            spec["type"] = t
            self.assertIn("%s %s" % (idk, stuck), render.rules(spec, "none"), t)
        self.assertIn("Closed book: no notes, no book, no search, no other AI.", render.rules(drills_spec(), "none"))
        # Mixed, review and measuring sheets get no hints before they are filed.
        for t in ("mixed", "review", "cold", "diagnostic", "mock", "checkpoint", "probe", "words"):
            lines = render.rules(drills_spec(type=t), "none")
            self.assertFalse(any("Stuck on a question" in r for r in lines), t)
            self.assertIn(idk, lines, t)
            self.assertIn("Closed book: no notes, no book, no search, no AI.", lines, t)
        self.assertIn(stuck, self.text)

    def test_theory_pencils_are_sent_and_marked_before_the_sheet_is_put_away(self):
        # The pencils print last and are marked by pointing back into the sheet, so the sheet
        # stays open until then, and "closed" is the learner's signal for the drills.
        self.assertEqual(render.build_model(theory_spec())["close_line"], CLOSE)
        ext = theory_spec(type="external")
        self.assertEqual(render.build_model(ext)["close_line"], CLOSE)
        self.assertIn("pencil questions at the end with it open", render.rules(theory_spec(), "none")[0])
        # An example sheet is followed by the stuck question, not by drills: its own lines.
        ex = theory_spec(type="example")
        self.assertEqual(render.build_model(ex)["close_line"], render.CLOSE_LINE_EXAMPLE)
        self.assertNotIn("drills", render.rules(ex, "none")[0])

    def test_reading_sheets_allow_their_minutes_and_practice_stops_at_them(self):
        allow = "Allow about 8 minutes, and read it all even if it takes longer."
        for t in ("theory", "external", "example", "repair"):
            lines = render.rules(theory_spec(type=t), "none")
            self.assertIn(allow, lines, t)
            self.assertFalse(any(r.startswith("Stop after") for r in lines), t)
        # Drills and measuring sheets keep the hard stop: it protects the session's close.
        for spec in (drills_spec(), cold_spec(), drills_spec(type="mock")):
            lines = render.rules(spec, "none")
            self.assertTrue(any(r.startswith("Stop after") for r in lines), spec["type"])
            self.assertFalse(any(r.startswith("Allow about") for r in lines), spec["type"])

    def test_a_mock_and_an_official_paper_are_checked_as_in_the_exam(self):
        # pedagogy-2: the exam has no check column, so neither has the sheet that copies it.
        exam = "Check your answers as you would in the exam: there is no check line on this sheet."

        def no_checks(spec, origin=None):
            for it in spec["items"]:
                if origin:
                    it["origin"] = origin
                for a in it["asks"]:
                    a["check"] = False
            return spec
        mock_sheet = no_checks(drills_spec(type="mock"))
        lines = render.rules(mock_sheet, "none")
        self.assertIn(exam, lines)
        self.assertFalse(any(r.startswith("Write the check") or "check fails" in r for r in lines))
        self.assertLessEqual(len(lines), 8)
        official = no_checks(cold_spec(type="checkpoint"), origin="official:Cambridge 18")
        self.assertIn(exam, render.rules(official, "none"))
        # A checkpoint with Claude's own items among official ones keeps the check where it is printed.
        mixed = no_checks(cold_spec(type="checkpoint"), origin="official:Cambridge 18")
        mixed["items"][0]["origin"] = "new"
        mixed["items"][0]["asks"][0]["check"] = True
        lines = render.rules(mixed, "none")
        self.assertNotIn(exam, lines)
        self.assertTrue(any(r.startswith("Write the check beside each answer where a Check line is printed")
                            for r in lines))

    def test_the_rules_box_stays_short(self):
        # Eight lines at most: new advice joins a line it belongs with (the failed-check mark, the hint offer).
        for spec in (drills_spec(), cold_spec(), theory_spec(), drills_spec(type="repair"), drills_spec(type="mock")):
            lines = render.rules(spec, "calculator", reference_sheet=True)
            self.assertLessEqual(len(lines), 8, spec["type"])
            self.assertLessEqual(len([r for r in lines if "check fails" in r]), 1, spec["type"])

    def test_a_failed_check_is_a_flag_not_a_hunt_only_where_there_are_checks(self):
        from lib import render
        line = "If a check fails and you can't see why within a minute"
        self.assertTrue(any(line in r for r in render.rules(drills_spec(), "none")))
        self.assertFalse(any(line in r for r in render.rules(theory_spec(), "none")))

    def test_items_asks_check_lines_and_hints(self):
        self.assertLess(self.text.index("0. Start time:"), self.text.index("Question 1."))
        self.assertEqual(self.text.count("Check:"), 6)
        self.assertEqual(self.text.count("Read the new sentence aloud with your answer in it"), 6)
        self.assertEqual(self.page.count('class="box"'), 6)
        for i in range(1, 7):
            self.assertIn("%da Write it again with a new verb:" % i, self.text)

    def test_block_titles_and_failure_gate_after_item_3_of_each_block(self):
        t = self.text
        self.assertIn("Block A: swap one word", t)
        self.assertIn("Block B: swap one word", t)
        self.assertEqual(t.count("have a failed check, an “I don't know” or an empty box"), 2)
        self.assertTrue(t.index("Question 3.") < t.index(GATE_1) < t.index("Question 4."))
        self.assertTrue(t.index("Question 6.") < t.index(GATE_2) < t.index("Stop time:"))

    def test_gate_after_moves_the_gate_past_the_worked_item(self):
        # At mastery 0–1 item 1 of a block is worked: gate_after 4 covers the faded item and two
        # independent ones.
        spec = practised_drills(n=12)
        spec["blocks"][0]["gate_after"] = 4
        gate = ("If 2 of items 2–4 have a failed check, an “I don't know” or an empty box: "
                "stop and send a photo of 2–4.")
        t = visible_text(render.render_html(spec, date=DAY))
        self.assertTrue(t.index("Question 4.") < t.index(gate) < t.index("Question 5."))
        self.assertNotIn("items 1–3", t)
        self.assertIn("items 7–9", t, "the second block keeps its gate after its third item")
        md = render.render_markdown(spec, date=DAY)
        self.assertTrue(md.index("**4.**") < md.index("> **%s**" % gate) < md.index("**5.**"))
        src = render.render_typst(spec, date=DAY)
        self.assertTrue(src.index('#"4."') < src.index('#"%s"' % gate) < src.index('#"5."'))
        # A gate_after lint refuses (too early, or not in the block) leaves the gate after item 3.
        for bad in (2, 99):
            spec["blocks"][0]["gate_after"] = bad
            self.assertIn("items 1–3", visible_text(render.render_html(spec, date=DAY)), bad)

    def test_at_mastery_0_1_the_gate_stops_every_time(self):
        spec = drills_spec(n=12)                               # blocks marked gate "always"
        spec["blocks"][0]["gate_after"] = 4
        stop_1 = "Stop here and send a photo of items 2–4. Go on once I've marked them."
        stop_2 = "Stop here and send a photo of items 7–9. Go on once I've marked them."
        t = visible_text(render.render_html(spec, date=DAY))
        self.assertTrue(t.index("Question 4.") < t.index(stop_1) < t.index("Question 5."))
        self.assertTrue(t.index("Question 9.") < t.index(stop_2) < t.index("Question 10."))
        self.assertNotIn("have a failed check", t)
        md = render.render_markdown(spec, date=DAY)
        self.assertIn("> **%s**" % stop_1, md)
        self.assertIn('#"%s"' % stop_2, render.render_typst(spec, date=DAY))
        # Another block on the same sheet keeps the conditional gate.
        spec["blocks"][1].pop("gate")
        t = visible_text(render.render_html(spec, date=DAY))
        self.assertIn(stop_1, t)
        self.assertIn("If 2 of items 7–9 have a failed check", t)

    def test_end_lines(self):
        t = self.text
        self.assertTrue(t.index("Question 6.") < t.index("Stop time:") < t.index("Least sure I chose the right idea (item numbers):"))
        page = render.render_html(drills_spec(least_sure=False), date=DAY)
        self.assertNotIn("Least sure", visible_text(page))

    def test_typed_answers_are_asked_for_in_one_message_in_every_format(self):
        # A learner answering from a phone (format.answer_form "typed") is never sent to paper or photos.
        typed = ("Type your answers, numbered as on the sheet, each with its check; when you stop, send them in one "
                 "message (or a text file) with the start and stop times and the Least-sure line.")
        for fmt in ("html", "md", "pdf"):
            lines = render.rules(drills_spec(), "none", fmt=fmt, answer_form="typed")
            self.assertIn(typed, lines, fmt)
            self.assertFalse(any("paper" in r for r in lines), fmt)
        self.assertIn("Type your answers, numbered as on the sheet; when you stop, send them in one message (or a "
                      "text file) with the start and stop times.",
                      render.rules(theory_spec(), "none", answer_form=" Typed "), "no checks, no Least-sure line")
        self.assertIn("Answer on paper, one answer in each box.", render.rules(drills_spec(), "none", answer_form="short"))
        self.assertTrue(any("in your editor" in r for r in render.rules(drills_spec(), "none", profile="code",
                                                                        answer_form="typed")), "code keeps the editor")
        # The failure gates ask for the typed answers too, in every template.
        spec = drills_spec(n=12)                               # the first block stops every time
        spec["blocks"][1].pop("gate")
        stop = "Stop here and send your answers to items 1–3. Go on once I've marked them."
        gate = ("If 2 of items 7–9 have a failed check, an “I don't know” or an empty box: stop and send your "
                "answers to 7–9.")
        t = visible_text(render.render_html(spec, date=DAY, answer_form="typed"))
        self.assertIn(stop, t)
        self.assertIn(gate, t)
        self.assertIn(typed, t)
        self.assertNotIn("photo", t)
        md = render.render_markdown(spec, date=DAY, answer_form="typed")
        self.assertIn("> **%s**" % stop, md)
        self.assertIn(typed, md)
        self.assertIn('#"%s"' % gate, render.render_typst(spec, date=DAY, answer_form="typed"))

    def test_the_least_sure_line_asks_about_the_idea_and_the_rules_ask_for_it(self):
        # One wording for every subject: the idea chosen, not a possible slip. The rules box asks
        # for item numbers or "none" on the time line, so a blank never reads as "none".
        self.assertEqual(render.LEAST_SURE_LABEL, "Least sure I chose the right idea (item numbers):")
        rule = "Then fill in the Least-sure line: item numbers, or “none”."
        lines = render.rules(drills_spec(), "none")
        self.assertIn("Stop after 12 minutes. " + rule, lines)
        self.assertFalse(any(rule in r for r in render.rules(drills_spec(least_sure=False), "none")))
        self.assertFalse(any(rule in r for r in render.rules(theory_spec(), "none")))

    def test_print_css_a4_and_page_x_of_y(self):
        self.assertIn("size: A4", self.page)
        self.assertIn('content: "page " counter(page) " of " counter(pages)', self.page)

    def test_self_contained_and_accessible(self):
        low = self.page.lower()
        for bad in ("http://", "https://", "<script", "<link", "url(", "@import", " src="):
            self.assertNotIn(bad, low)
        self.assertTrue(self.page.startswith("<!doctype html>"))
        self.assertIn('<html lang="en">', self.page)
        self.assertIn('<main aria-labelledby="sheet-title">', self.page)
        self.assertIn('<section class="rules" aria-labelledby="rules-h">', self.page)
        self.assertEqual(self.page.count('role="group"'), 6)
        self.assertIn('<h2 id="blk-1">Block A: swap one word</h2>', self.page)
        self.assertNotIn("$", self.page.replace("$$", ""), "every template placeholder is filled")

    def test_learner_text_is_escaped(self):
        spec = drills_spec()
        spec["items"][0]["text"] = 'Tag <script>alert(1)</script> & "quotes" x² ≤ 3'
        page = render.render_html(spec, date=DAY, lang="pt")
        self.assertNotIn("<script>", page)
        self.assertIn("&lt;script&gt;", page)
        self.assertIn('<html lang="pt">', page)
        self.assertIn("x² ≤ 3", visible_text(page))

    def test_measurement_provenance(self):
        self.assertIn("Measurement — written by Claude", visible_text(render.render_html(cold_spec(), date=DAY)))
        spec = cold_spec()
        for it in spec["items"]:
            it["origin"] = "official:Cambridge 18 Test 2"
        self.assertIn("Measurement — official", visible_text(render.render_html(spec, date=DAY)))
        self.assertNotIn("have a failed check", visible_text(render.render_html(cold_spec(), date=DAY)),
                         "the failure gate is for drills only")

    def test_theory_layout(self):
        t = visible_text(render.render_html(theory_spec(), date=DAY))
        order = ["Rules", "0. Start time:", "Before this sheet", "You can find the verb in a sentence.",
                 "Words on this sheet", "paraphrase (paráfrase)", "the same idea said with other words",
                 "A worked case", "What it is and why", "How to paraphrase", "Watch out", "Question 1.",
                 "Stop time:", CLOSE]
        positions = [t.index(s) for s in order]
        self.assertEqual(positions, sorted(positions))
        self.assertTrue(t.endswith(CLOSE))
        self.assertIn("Read this sheet, then do the pencil questions at the end with it open. "
                      "The drills that follow are closed book.", t)
        self.assertNotIn("Least sure", t)

    def test_a_scaffold_prints_working_lines_or_a_table_and_is_no_question(self):
        spec = drills_spec()
        spec["items"][0]["scaffold"] = ["Old verb:", "New verb:"]
        spec["items"][1]["scaffold"] = {"columns": ["word", "same meaning?"], "rows": 3}
        n = render.ask_count(drills_spec())
        self.assertEqual(render.ask_count(spec), n, "not counted")
        self.assertIn("About 12 min · %d questions" % n, render.build_model(spec)["meta"])
        html = render.render_html(spec, date=DAY)
        t = visible_text(html)
        self.assertLess(t.index("The bridge was closed"), t.index("Old verb:"))
        self.assertLess(t.index("New verb:"), t.index("1a"))
        self.assertEqual(html.count("<td></td>"), 6)
        self.assertIn('<th scope="col">same meaning?</th>', html)
        md = render.render_markdown(spec, date=DAY)
        self.assertIn("Old verb: ______________________", md)
        self.assertIn("| word | same meaning? |\n|---|---|\n|   |   |\n", md)
        self.assertLess(md.index("New verb:"), md.index("**1a**"))
        typ = render.render_typst(spec, date=DAY)
        self.assertIn('#"Old verb:" #fillin(1fr)', typ)
        self.assertIn("#table(columns: (1fr, 1fr), inset: 6pt", typ)
        self.assertEqual(typ.count("[#v(1.2em)]"), 6)
        self.assertIn("Old verb:", render.visible_texts(spec))
        self.assertIn("same meaning?", render.visible_texts(spec))

    def test_a_guess_before_reading_says_wrong_guesses_help(self):
        spec = theory_spec()
        spec["theory"]["sections"].insert(0, {"kind": "prequestion", "title": "",
                                              "body": "Say it another way: The shop shut at noon."})
        for fn in (render.render_html, render.render_typst, render.render_markdown):
            out = fn(spec, date=DAY)
            positions = [out.index(s) for s in ("Before you read: have a guess", "The shop shut at noon",
                                                "Write a guess on paper before reading on",
                                                "The answer is further down this sheet", "A worked case")]
            self.assertEqual(positions, sorted(positions), fn.__name__)
        self.assertNotIn("Write a guess", render.render_markdown(theory_spec(), date=DAY))
        # A guess is never a question: nothing to key, count or mark.
        self.assertEqual(render.ask_count(spec), render.ask_count(theory_spec()))

    def test_an_untitled_section_gets_its_kinds_heading_in_every_format(self):
        spec = theory_spec()
        for sec in spec["theory"]["sections"]:
            sec["title"] = ""
        for fn in (render.render_html, render.render_typst, render.render_markdown):
            out = fn(spec, date=DAY)
            positions = [out.index(s) for s in ("Worked case", "What it is and why", "The rule", "Warning")]
            self.assertEqual(positions, sorted(positions), fn.__name__)


class TypstAndMarkdownTests(Base):
    def test_typst_source_is_well_formed_and_complete(self):
        src = render.render_typst(practised_drills(), date=DAY)
        self.assertEqual(typst_balance_problems(src), [])
        self.assertIn('counter(page).display("1 of 1", both: true)', src)
        self.assertIn('paper: "a4"', src)
        self.assertIn('"Noto Serif", "Libertinus Serif", "New Computer Modern"', src)
        for s in ('#"Thursday 15 October 2026"', '#"Start time:"', '#"Stop time:"',
                  '#"Least sure I chose the right idea (item numbers):"', '#"%s."' % V_RULE, '#"%s"' % GATE_1, '#"%s"' % GATE_2,
                  '#"About 12 min · 6 questions · Practice — written by Claude"'):
            self.assertIn(s, src)
        self.assertEqual(src.count("#checkline()"), 6)
        self.assertEqual(src.count("#answer("), 6)
        self.assertLess(src.index(GATE_1), src.index('#"4."'))
        self.assertNotRegex(src, r"\$[a-z_]+", "every template placeholder is filled")

    def test_typst_learner_text_is_never_markup(self):
        self.assertEqual(render.ts('a"b\\c'), '"a\\"b\\\\c"')
        spec = drills_spec()
        spec["items"][0]["text"] = 'Costs #1 = $5 [draft] *bold* // not a comment "quoted" back\\slash\nline two'
        spec["title"] = "Title with $dollar and #hash"
        src = render.render_typst(spec, date=DAY)
        self.assertEqual(typst_balance_problems(src), [])
        self.assertIn('#"Costs #1 = $5 [draft] *bold* // not a comment \\"quoted\\" back\\\\slash" '
                      '#linebreak() #"line two"', src)
        self.assertIn('#set document(title: "Title with $dollar and #hash")', src)

    def test_typst_theory_ends_with_the_close_line(self):
        src = render.render_typst(theory_spec(), date=DAY)
        self.assertEqual(typst_balance_problems(src), [])
        self.assertLess(src.index('#"Stop time:"'), src.index('#"%s"' % CLOSE))
        self.assertTrue(src.rstrip().endswith('[#strong[#"%s"]]' % CLOSE))

    def test_markdown_has_every_element(self):
        md = render.render_markdown(practised_drills(), date=DAY)
        self.assertTrue(md.startswith("# Other words, same idea\n"))
        for s in ("**Thursday 15 October 2026** · About 12 min · 6 questions · Practice — written by Claude",
                  "> **Rules**", "Closed book", "Write the check beside each answer.", "Stop after 12 minutes.",
                  "Tools allowed: none.", V_RULE, "**0.** Start time: ____", "## Block A: swap one word",
                  "> **%s**" % GATE_1, "> **%s**" % GATE_2, "Stop time: ____", "Least sure I chose the right idea (item numbers): ____"):
            self.assertIn(s, md)
        self.assertEqual(md.count("Check: "), 6)
        self.assertLess(md.index(GATE_1), md.index("**4.**"))
        self.assertNotRegex(md, r"\$[a-z_]+")

    def test_markdown_theory_ends_with_the_close_line_and_escapes(self):
        md = render.render_markdown(theory_spec(), date=DAY)
        self.assertEqual(md.rstrip().splitlines()[-1], "**%s**" % CLOSE)
        spec = drills_spec()
        spec["items"][0]["text"] = "# not a heading *not bold*"
        md = render.render_markdown(spec, date=DAY)
        self.assertIn("\\# not a heading \\*not bold\\*", md)

    def test_templates_ship_with_placeholders(self):
        for name, marks in (("html/sheet.html", ["$lang", "$title", "$body"]),
                            ("typ/sheet.typ", ["$title_str", "$lang", "$body"]),
                            ("md/sheet.md", ["$title", "$date_line", "$meta", "$rules", "$body"])):
            text = (TEMPLATES_DIR / name).read_text(encoding="utf-8")
            for m in marks:
                self.assertIn(m, text, name)


class BackendTests(Base):
    def test_detect_backends_quick_lists_the_chain(self):
        rows = render.detect_backends(quick=True)
        self.assertEqual([r["name"] for r in rows], ["typst", "tectonic", "xelatex", "lualatex", "chrome", "html", "md"])
        by = dict((r["name"], r) for r in rows)
        self.assertTrue(by["html"]["ok"] and by["md"]["ok"])
        self.assertFalse(by["xelatex"]["ok"], "LaTeX sheets arrive in v0.2")
        for r in rows:
            self.assertEqual(set(r), {"name", "found", "ok", "detail", "path"})
        self.assertEqual(render.working_backends(quick=True)[-2:], ["html", "md"])

    def test_backend_order(self):
        self.assertEqual(render.backend_order("md"), ["md"])
        self.assertEqual(render.backend_order("html", preferred="typst"), ["html"])
        self.assertEqual(render.backend_order("pdf", preferred="html"), ["typst", "chrome", "html", "md"])
        self.assertEqual(render.backend_order(None, preferred="html"), ["html", "typst", "chrome", "md"])
        self.assertEqual(render.backend_order(None, preferred="chrome"), ["chrome", "typst", "html", "md"])
        self.assertEqual(render.backend_order(None, preferred="bogus"), ["typst", "chrome", "html", "md"])

    def test_pdf_request_falls_back_to_html_when_no_pdf_backend_works(self):
        with mock.patch.object(render, "find_typst", return_value=None), \
                mock.patch.object(render, "find_chrome", return_value=None):
            res = render.render_sheet(drills_spec(), self.tmp, "ielts-drills-01", fmt="pdf", date=DAY)
            self.assertEqual(res["backend"], "html")
            self.assertEqual(res["files"], [self.tmp / "ielts-drills-01.html"])
            self.assertIn("typst not found", res["notes"])
            rows = render.detect_backends()
            self.assertFalse(dict((r["name"], r) for r in rows)["chrome"]["ok"])

    def test_a_failed_pdf_moves_to_the_next_backend(self):
        with mock.patch.object(render, "find_typst", return_value="/nonexistent/typst"), \
                mock.patch.object(render, "find_chrome", return_value=None):
            res = render.render_sheet(drills_spec(), self.tmp, "x", fmt=None, date=DAY)
        self.assertEqual(res["backend"], "html")
        self.assertFalse((self.tmp / "x.typ").exists(), "a failed typst source is not left behind")
        self.assertTrue(any("typst" in n for n in res["notes"]))

    def test_unknown_format_is_a_usage_error(self):
        from lib import UsageError
        with self.assertRaises(UsageError):
            render.render_sheet(drills_spec(), self.tmp, "x", fmt="docx")


# ==========================================================================
# Through the CLI
# ==========================================================================

class BuildCliTests(Base):
    def setUp(self):
        Base.setUp(self)
        self.ws = make_ws(self.tmp, "A")

    def linted(self, spec):
        self.assertEqual(new_sheet(self.ws, spec).returncode, 0)
        r = run(["sheet", "lint", SUBJECT, spec["id"]], ws=self.ws, now=NOW)
        self.assertEqual(r.returncode, 0, r.stdout)

    def build(self, sheet_id, *extra):
        return run(["sheet", "build", SUBJECT, sheet_id] + list(extra), ws=self.ws, now=NOW)

    def test_md_and_html_builds_always_work(self):
        spec = drills_spec()
        self.linted(spec)
        for fmt in ("md", "html"):
            r = self.build(spec["id"], "--format", fmt)
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            out = Path(r.stdout.splitlines()[0])
            self.assertEqual(out, (subject_dir(self.ws) / "sheets" / "2026-10" / ("ielts-drills-01." + fmt)).resolve())
            self.assertTrue(out.is_file())
            self.assertIn("Other words, same idea", out.read_text(encoding="utf-8"))
            # built ahead, with no block and no session open: a blank date to fill in, not the build day
            self.assertIn("Date: ____________", out.read_text(encoding="utf-8"))
            self.assertNotIn("Monday 12 October 2026", out.read_text(encoding="utf-8"))
            self.assertNotIn("note:", r.stdout)
            row = sheet_row(self.ws, spec["id"])
            self.assertEqual(row["status"], "rendered")
            self.assertEqual(row["files"], ["sheets/2026-10/ielts-drills-01." + fmt])

    def test_a_typed_subject_builds_sheets_that_ask_for_typed_answers(self):
        r = run(["set", SUBJECT, "format.answer_form", '"typed"'], ws=self.ws, now=NOW)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        spec = drills_spec()
        self.linted(spec)
        r = self.build(spec["id"], "--format", "html")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        text = visible_text(Path(r.stdout.splitlines()[0]).read_text(encoding="utf-8"))
        self.assertIn("Type your answers, numbered as on the sheet", text)
        self.assertNotIn("Answer on paper", text)
        self.assertNotIn("send a photo", text)

    def test_recorded_backend_is_used_first(self):
        cfg_path = Path(self.ws) / "indelible.json"
        cfg = fio.read_json(cfg_path)
        cfg["render"] = {"backend": "html", "verified_at": NOW}
        fio.write_json(cfg_path, cfg)
        spec = drills_spec()
        self.linted(spec)
        r = self.build(spec["id"])
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertTrue(r.stdout.splitlines()[0].endswith("ielts-drills-01.html"))
        self.assertEqual(sheet_row(self.ws, spec["id"])["files"], ["sheets/2026-10/ielts-drills-01.html"])

    def test_date_flag_sets_the_header_and_the_month_folder(self):
        spec = drills_spec()
        self.linted(spec)
        r = self.build(spec["id"], "--format", "md", "--date", "2026-11-02")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        out = subject_dir(self.ws) / "sheets" / "2026-11" / "ielts-drills-01.md"
        self.assertIn("Monday 2 November 2026", out.read_text(encoding="utf-8"))
        self.assertEqual(self.build(spec["id"], "--format", "md", "--date", "2 Nov").returncode, 2)

    def test_theory_sheet_builds(self):
        spec = theory_spec()
        self.linted(spec)
        r = self.build(spec["id"], "--format", "html")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        page = Path(r.stdout.splitlines()[0]).read_text(encoding="utf-8")
        self.assertTrue(visible_text(page).endswith(CLOSE))

    def test_doctor_uses_render_detect_backends(self):
        r = run(["doctor", "--quick", "--json"], ws=self.ws, now=NOW)
        self.assertEqual(r.returncode, 0, r.stderr)
        data = json.loads(r.stdout)
        self.assertEqual(data["renderer_source"], "render")
        self.assertIn("md", [x["name"] for x in data["renderers"]])

    @unittest.skipUnless(shutil.which("typst"), "typst is not on PATH")
    def test_typst_pdf_build(self):
        spec = drills_spec()
        self.linted(spec)
        r = self.build(spec["id"], "--format", "pdf")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        row = sheet_row(self.ws, spec["id"])
        self.assertEqual(row["files"], ["sheets/2026-10/ielts-drills-01.pdf", "sheets/2026-10/ielts-drills-01.typ"])
        pdf = subject_dir(self.ws) / row["files"][0]
        self.assertTrue(render.pdf_complete(pdf))
        theory = theory_spec()
        self.linted(theory)
        self.assertEqual(self.build(theory["id"], "--format", "pdf").returncode, 0)
        self.assertTrue(sheet_row(self.ws, theory["id"])["files"][0].endswith(".pdf"))

    @unittest.skipUnless(render.find_chrome(), "no Chrome, Chromium or Edge found")
    def test_browser_pdf_build(self):
        spec = drills_spec()
        self.linted(spec)
        with_typst = bool(shutil.which("typst"))
        r = self.build(spec["id"], "--format", "pdf")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        if "note: no PDF" in r.stdout:
            self.skipTest("a browser is installed but could not print here")
        row = sheet_row(self.ws, spec["id"])
        self.assertTrue(row["files"][0].endswith(".pdf"))
        self.assertTrue(row["files"][1].endswith(".typ" if with_typst else ".html"))
        self.assertTrue(render.pdf_complete(subject_dir(self.ws) / row["files"][0]))


if __name__ == "__main__":
    unittest.main()
