# Headings: the whole paragraph first

**Date: ____________** · About 10 min · 3 questions · Practice — written by Claude · Sheet IELTS-02

> **Rules**
>
> - Read this sheet, then do the pencil questions at the end with it open. The drills that follow are closed book.
> - Answer on paper (or in a typed file), one answer for each box.
> - Write the check beside each answer where a Check line is printed. Work backwards from it: put it back in, rebuild the total, or test the definition you used against the question's words.
> - “I don't know” is always an accepted answer. Stuck on a question after a real try? Tell me its number: you get a small hint, never the answer.
> - Allow about 10 minutes, and read it all even if it takes longer.
> - Tools allowed: none.
> - If a word here was never explained to you, on this sheet or an earlier one, write it beside that answer: that's my mistake, not yours.

**0.** Start time: ____

## Before this sheet

- The main idea of a paragraph: the point that the other sentences explain or give examples of. You found one on the diagnostic.

## Words on this sheet

- **heading** *(título)*: a short title that says what a whole paragraph is about
- **distractor** *(distrator)*: a wrong option written to look right, often because it repeats a word from the paragraph

## Before you read: have a guess

Look at the Selby paragraph in the worked case below and its three headings, A, B and C, but not at the steps yet. Which heading would you choose, and why?

Write a guess on paper before reading on. Wrong guesses are expected and help. The answer is further down this sheet.

## A worked case

Paragraph: In 1890 the town of Selby had no clean water. Families carried water up from the river, and every summer many children fell ill. In 1902 the council built a pumping station and laid pipes to every street. Within ten years, summer illness in the town had almost disappeared.

Headings: A. The history of the river · B. How clean water changed a town's health · C. Why children fall ill in summer

Step 1. Cover the headings. Say what the whole paragraph is about in five words or fewer: 'piped water ended town illness'.

Step 2. Look at the distractors. A repeats 'river', but the paragraph is not about the river. C repeats 'children', 'ill' and 'summer', but those are details inside the story.

Step 3. Compare each heading with your five words, not with single words in the paragraph. B says the same thing as 'piped water ended town illness'.

Step 4. Check: read the whole paragraph again under B. Every sentence belongs under it.

## What it is and why

A heading is the paragraph's name: a reader scanning the list uses it to find the paragraph they need. So every sentence has to sit under it. A heading that covers only one sentence names a detail, and a reader who follows it lands in the wrong place.

> **The rule**
>
> Say the main idea of the whole paragraph in your words before you look at the headings. Then choose the heading that says the same thing. A heading that repeats a word from the paragraph is not a reason to choose it.
>

## Two headings, one paragraph

Paragraph: Rain fell on the valley for two days in March. Then warm air melted the snow on the hills, the river climbed a metre in one night, and the lower streets flooded.

'Rain in the valley' matches the first sentence. 'Why the valley flooded that spring' matches the whole paragraph. The second is the heading.

## When matching words works

Sometimes the heading that repeats a word is also the right one, because that word names the main idea. That is why matching words feels safe: it works often enough. Your five-word summary shows you when it does not.

> **The likeliest wrong turn**
>
> Choosing the heading that shares the most words with the first sentence. First sentences often describe the scene; the main idea can come later in the paragraph.
>

## Where this lives

IELTS Academic reading: a list of headings, one for each paragraph, with more headings than paragraphs. The same steps help with questions on the main idea of a whole passage.

**1.** Pencil questions: the same steps as the worked case, on a new paragraph.

Paragraph: In 2019 the primary school in Carden dug up half of its car park and planted vegetables. The pupils water the beds before lessons. Last autumn the garden gave so many potatoes that the school kitchen bought no vegetables for a month, and the extra went to the village market.

Headings:  
A. Why children should learn to cook  
B. A busy market in a small village  
C. How a school came to feed itself  
D. The trouble with car parks

- **1a** Step 1: the whole paragraph in five words or fewer:  
  Answer: ______________________  
- **1b** Step 3: letter of the heading that matches your five words:  
  Answer: ______________________  

**2.** Back to the worked case. Step 2 sets headings A and C aside because:  
(a) each names one detail, not what the whole paragraph says  
(b) each shares fewer words with the paragraph than B does  
(c) neither says what the first sentence says

- **2a** Letter (a, b or c):  
  Answer: ______________________  

---

Stop time: ____

**Send me your pencil answers and keep this sheet open until I've marked them. Then put it away and tell me “closed”. The drills come on their own sheet.**
