# Measure: diagnostics, probes, mocks and checkpoints

For `diagnose`, `mock`, checkpoints and week 1 of a new subject. Diagnose before teaching: levels come from measurement, never from self-report or earlier work. Sheet mechanics (builder, check-line forms, lint): [sheets.md](sheets.md). Filing evidence and general grading: [session-grade.md](session-grade.md). Miss classification: [taxonomies.md](taxonomies.md).

Contents: 1 Instrument · 2 Scope map · 3 Two-stage diagnostic · 4 Sitting · 5 Scoring · 6 Results card · 7 Probes · 8 Levels · 9 Hours and feasibility · 10 Topic order · 11 Week 1 · 12 Mocks, rationing, checkpoints

## 1. Choose the instrument

| Situation | Instrument | Labels |
|---|---|---|
| Exam, an unseen official test left over once the checkpoints and final mock have theirs (§12) | That test at the exam's time of day, plus a 10-minute vocabulary and floor `probe` | `[published]` test, `[measured n=…]` result |
| Exam, no official test to spare (A: two unopened, kept for a checkpoint and the final mock) | Two-stage Claude-built `diagnostic` (§3) | `[mine]`, `[measured n=…]` |
| Course final with an unseen past paper (C) | That paper in session 1; probes ride in session 2 | `[published]`, `[measured n=…]` |
| "Never studied it" | 10–15-minute floor `probe`; teaching starts in session 2 | `[mine]` |
| Language (B) | Placement in two `probe` sheets, sessions 1 and 2, pooled as one measurement (the CLI pools probes sat within 72 h): 1) at most 8 high-frequency words from different frequency bands, each in a sentence, answered with a one-word gloss in the instruction language; 2) 3 can-do prompts, each answered in one typed line, plus 1 listening item if the learner has audio. Both go in session 1 when its work minutes hold them. Size each by the work minutes `ind session open` prints; never lower `est_min` to fit | `[mine]` |
| Code (D) | 15-minute capstone in the learner's editor (compiler allowed; no AI, no docs) as a one-item `diagnostic`, plus a 6-item concept `probe` | `[mine]` |
| Interview | A `diagnostic` of 3–4 timed explanations; the required points stay in the key | `[mine]` |
| Skill or interest | 10-minute placement `probe` | `[mine]` |

- Before any official or past paper, ask: "Have you seen any of this paper before, even part of it?" A seen paper is practice, never a measurement.
- Official items are registered by pointer (`origin: official:<source>`, text like "Test 2, questions 1–13"), with the official answers sealed as the key. Never copy official item text into a record.
- Code: the learner types every line. File the project and the saved compiler or test output with `ind scan ingest <s> <id> --dir <project folder> --typed <output file>` ([profiles.md](profiles.md) §7).

## 2. Scope map

1. The official syllabus or course outline is the boundary: in scope, out of scope. With neither, draft the map from the learner's materials (contents pages, past papers) and label it `[mine]`.
2. Weights: published if they exist; else counted across the learner's past papers and labelled `[mine, from n papers]`; else equal.
3. One topic = one teach block plus a 10–15-minute recheck. Most subjects have 6–20.
4. Show the map without asking a question: at `teach` it is one readback row ("What's tested: …; say if any is missing"); elsewhere at most 8 lines ending "Say if anything here isn't on your exam, or is missing." Go on without waiting; a later correction becomes `ind topic add` or `ind set <subject> topics.<T>.scope '"out"'`.
5. Record each in-scope topic with `ind topic add <subject> T01 --name "…" --layer procedural --weight 0.15 --floor T00 --confusable T05`, and the out-of-scope list plus the weight source with `ind note append <subject> scope`.

## 3. The two-stage diagnostic

Brief the builder subagent with a blueprint only (topics, part, counts, formats, minutes, tools); items and answers never enter the main conversation.

- **Part A:** for every in-scope topic, one floor item (what it stands on) and one core item.
- **Part B:** exam-level items, only for topics with both Part A items right, enough for at least 4 questions per topic across both parts (the minimum for 3p). Build it after Part A is graded. This is the adaptive stop: nobody sits a long paper they mostly fail.
- **Sittings:** each part splits into ceil(part minutes ÷ the session's work minutes) sheets, all taken within 72 hours of the first. The parts are one measurement: one block when they fit, otherwise consecutive days.
- **Re-diagnosis** uses a parallel form (new items, same blueprint). A sealed sheet is never edited or re-issued.

Item rules (lint L2, L3 and L9 enforce the first three):
- Unlabelled and interleaved: no topic name in titles or labels, no two adjacent items on one topic. Per-topic counts are uneven and never stated.
- One labelled blank per question, each with a check line (not on an official question: an unseen official test is sat as the exam sets it, with no check column). For a definition: "write the definition you used and test it against the question's words".
- Item 0 records the start time; the last line records the stop time and "Least sure I chose the right idea (item numbers): ___" (the rules box asks for item numbers or "none"). No per-answer confidence marks.
- The rules box says "I don't know" is always an accepted answer.
- Mixed formats: compute, reverse the question, which rule applies, a one-line "why", and the exam's own answer form. No "find the error" items unless the exam itself asks them (a grammar "identify the error" question, say): spotting an error takes the knowledge the item tests. Form, tools and accommodations match `subject.json.format`.
- Two questions per topic hinge on a key term (the Part A core item and one Part B item). Every other item says what it means in plain words, so a word failure shows apart from a concept failure. Topics that stop after Part A get the second from the vocabulary probe (§7).
- Multiple choice: the CLI applies no chance correction, so each topic needs at least 4 constructed-response questions (answer written before any options are seen).

## 4. The sitting

- **When:** the learner's clear window, first block of the day, the exam's time of day where possible, never within 3 hours after another measurement. Book it with `ind plan add <subject> --kind diagnostic --start ISO --min N --protected --measurement` (or `--kind mock`, `--kind checkpoint`); `ind plan check` fails a 3-hour clash.
- **How:** paper, closed book, no notes, only the exam's tools and, if the exam gives one, a clean copy of its formula sheet (`format.reference_sheet`: the rules box says so). Accommodations apply; extra time scales the clock.
- **Size:** the exam clock (or the part's minutes) plus 10–15 minutes to record. An official paper's estimate is its exam clock; lint's pace floor counts only the questions Claude wrote. Exempt from the question budget, not from its own minutes: lint L5 and `ind sheet issue` refuse a sheet whose estimate is over its block's minutes less 10 (or `--budget-min`). Then split a part Claude wrote into sittings (§3); an official paper is never cut, so book it a longer block. No breaks the exam doesn't have.
- **Open:** `ind session open <subject> --planned N --block <B> --kind diagnostic`, then hand the sheet over and issue it: `ind sheet issue <subject> <id> --block <B>`. The hand-over ends with how to send the answers: "When you're done, send the photos (<the route from the welcome card>) and say 'sent'." No teaching, and no hints before evidence is filed.
- **Say once:** "This is triage, not a verdict. A few questions per topic give a rough picture, and we'll measure again. 'I don't know' is always an accepted answer." To a question mid-sitting: "Write your best try or 'I don't know'; we'll look after marking." Note its number: "I don't understand the question" is an "unclear" account at marking ([session-grade.md](session-grade.md) §9).
- **Overrides** (late, tired, soon after another test): `ind session override <subject> "<their words>" --predict "<items>"`, and state the confound beside the result ("taken 1 h after another test").

## 5. Scoring

1. **Evidence first:** `ind sheet sat <subject> <id> --start HH:MM --stop HH:MM`, then `ind scan ingest <subject> <id> <photos> --transcript -` with your transcript, a line for every question number ([session-grade.md](session-grade.md) §2) (or `--typed FILE`, or `--transcript -` alone for a chat photo). Only then `ind key open <subject> <id>`. **An online official test** (the platform marks it and shows answers beside the results): the evidence is the platform's per-question right/wrong list. Ask for the question numbers and right or wrong only, typed, or a screenshot with the correct-answer and explanation columns cropped out; never ask for the review pages. File it with `--typed <file>` (a screenshot as a photo), and take each verdict from that list. The platform holds the answers, so there is no key to seal: brief the builder with the pointers ("Test 2, questions 1–27", `official:` items) and "marked online" in NOTES, and it registers the test with `ind sheet new <s> <id> --spec <file> --marked-online`. Lint, build and issue it at the sitting as usual (the learner sits it on the platform, not on the sheet). The platform shows the results once the test is submitted, so the hand-over adds: "Before you submit, write the stop time and the Least-sure line on paper: question numbers, or 'none'. Send them with the right/wrong list." `ind key open` then prints an empty key.
2. **Between Part A and Part B,** give verdicts only; explain nothing on a topic going into Part B.
3. **Per question:** verdict `right`, `half`, `wrong`, `dont_know` (wrote "I don't know") or `skip` (blank); check `filled`, `missing`, `caught`, `failed` (marked ✗, answer kept) or `head` (checked in the head, no line written: [self-report]), or `n/a` for a question printed without a check line (a mock, an official question); `least_sure` from the closing line, and the line itself as `least_sure_line`: `named`, `none` or `blank` (on an online test, the line written before submitting; never read a blank as "sure of everything": [session-grade.md](session-grade.md) §3).
4. **Accounts before classifying,** one miss at a time, unnamed wrong answers first (wrong and not on the Least-sure line): "Question 7 (<gist>; you wrote <answer>): how did you get your answer? 1) I did it this way: ___ 2) a word stopped me 3) I guessed 4) I can see my slip: ___", naming each question by its number, a gist and the learner's answer, as [session-grade.md](session-grade.md) §3 says. An account is how they got it, never a hunt for the error ([session-grade.md](session-grade.md) §4). Any language is fine. Cap at about 5 minutes per paper; the rest get "no account", never counted as blanks.
5. **Classify** with the subject taxonomy. Give `kind` only for a specific wrong idea (`belief`) or a slip. A guess or "I don't know" on an untaught topic gets no `kind`: teaching covers it.
6. **Record:** write the grades file (`ind schema grades`), then `ind grade record <subject> <id> --from grades.json`. No `--shaky` on a diagnostic; use it on mocks and checkpoints.
7. **Claude-built keys can be wrong.** Say "that doesn't match my answer", check the scan and key, and if the answer is defensible, mark it right and log a `content_error` defect (`ind ledger add defect`).
8. **Compute:** `ind topic show <subject>` (levels with basis) and `ind stats <subject>` (careless per 10, unnamed-wrong %, check coverage, pace). Count per-topic fractions from the grades file against the item topics in `<subject>/.indelible/specs/<id>.json`. Then `ind render <subject>`.

## 6. Results card

At most 12 lines, plain words, no IDs. Open with what the learner owns; label every number.

```
Diagnostic, parts A and B [mine · measured n=38]
Already yours: probability rules 4/4 · z-scores 4/5
Next: confidence intervals 1/4 · hypothesis tests 1/4 · regression 2/4
Not tried yet: chi-square (both blank); a short check next session
4 of 9 wrong answers weren't on your Least-sure line: those come back first
Checks beside 34 of 38 answers; 2 answers changed after a check failed
Time 96 of 110 min · 2 "I don't know" (both accepted answers)
Needs about 48 h at your pace [mine]; you have about 38 h. Three options below.
```

The "Checks beside" line only when the sheet had check lines (never on a mock). When the Least-sure line came back blank, "Least-sure line: left blank" replaces the unnamed-wrong line. No praise beyond the evidence. End with the next step.

## 7. Probes (sessions 2–3)

- **A skipped topic is not an unknown topic.** Blanks often come from labels, time or nerves. Each topic whose evidence is mostly blanks gets 2–3 unlabelled items in one mixed 10–15-minute `probe`, taken within 48 hours of the results. A pass sends the topic to the back of the teach queue; a miss confirms it.
- **Vocabulary probes.** For each "a word stopped me" miss, and each term-hinged miss whose plain-worded twin was right, one line, cold, quoting the sentence the word came from rather than "in question 6", since the learner no longer has that sheet: "'An unbiased estimate of the mean is…': what does 'unbiased' mean here?" (for an official item, a sentence of the builder's own). At most 10 per `probe`. The same twin rule holds at ordinary grading for a second-language learner: a sentence miss on an operation they did right in symbols gets a probe without the sentence frame before it is classified ([session-grade.md](session-grade.md) §5). Fix the word (the words box of the next theory sheet, a `words` sheet, or the subject `lexicon` via `ind set`) before the topic is re-taught.

## 8. Levels

Computed by the CLI (`ind grade record`, `ind topic recompute`), never typed. The learner sees "mastery 0–5".

| Level | Evidence |
|---|---|
| 0 | None, or the latest measurement under 25% |
| 1 | Latest measurement 25–74% |
| 2 | 75%+ on practice on some day |
| 3p | 75%+ on diagnostic, mock or checkpoint questions, at least 4 of them; becomes 3 after a cold pass within 14 days |
| 3 | 75%+ on a 2-day recheck inside the window, no exposure in the prior 24 h, with at least 2 counted questions on the topic |
| 4 | A second cold pass of 75%+ (at least 2 counted questions), at least 7 days after the first |
| 5 | 75%+ on the topic in a mock or checkpoint after reaching 4 |

- A right answer on the Least-sure line counts toward a level only once it comes back right: its shaky mistake's first re-serve, at +3 days (`--shaky`); a named miss always counts. A cold fail under 50% (over at least 2 counted questions) drops the topic to 2. A recheck with fewer than 2 counted questions on a topic neither passes nor fails it.
- To confirm a never-taught 3p topic: a short mixed practice set, logged with `ind session expose <subject> <topic> --kind review`, then its 2-day recheck inside the window.
- **A recheck that leaves a topic below 3** (a miss, a score under 75%, a sitting outside its window) is not the last word: the topic's next warm exposure (its fix sheet, the feedback logged after marking, drills) opens a new 44–72 h window and books it (`Recheck to place: <B>`; place it as for a new topic), and `ind due <s> --list` offers it again as a 2-day recheck. `ind grade record` names each such topic and what opens its window. A `words` recheck never opens one: words sheets don't feed levels, and their later rungs are placed by hand ([profiles.md](profiles.md)).
- **Level 4 and upkeep come round by themselves:** a topic at 3 is offered for its level-4 recheck 7 days after its first pass, and a topic at 4 or 5 for an upkeep recheck 3 weeks after its last pass (brought forward to 2 days before the date, none after it): tiers 6 and 7 of `ind due <s> --list`, 2 questions a topic, never ahead of fixed mistakes.

## 9. Hours needed and feasibility

- **Base:** Σ over in-scope topics of (target level − current level) × step hours. Target 4 by default (5 comes from mocks); 3p counts as 3. Step hours: 1.5 h procedural, 2.5 h any other layer.
- **Language:** start from published guided-learning hours per CEFR level (Cambridge English's guideline: about 180–200 hours from zero to A2) `[published]`, then the learner's own pace.
- **Add** each mock (exam minutes plus 60 minutes of review) and the buffer (`time.buffer_pct`).
- **Recalibrate** once two topics have a cold pass: step hours become the learner's own time from first teach to first cold pass, per level step.
- **Available:** planned study minutes from today to the date, minus blocked dates. Every hours figure is `[mine]`.
- **When:** a rough fit at `teach`, with every topic at mastery 0 (one preview line; it overstates the need), then the real verdict on the results card, re-run at each weekly review and for a pace question ([review.md](review.md) §2).
- **Verdict:** comfortable (needs 80% of available or less), tight (80–100%), or plainly "needs 48 h, you have 38 h". The 80% line is mine too.
- **If it doesn't fit,** one numbered question with three cuts: 1) drop the lowest-weight topics; 2) add hours up to the weekly ceiling (the only time the ceiling is re-asked); 3) move the date or the target. Log the choice: `ind ledger add decision --subject <s> --summary "…" --why "<their words>" --check-on DATE --rule "…" --action "…"`.
- **Adding hours** (cut 2): `ind set root session.days_per_week <n>` or `session.length_min`; the weekly target follows. Run it with `--dry-run` first: a ceiling that was never set explicitly is re-derived and can rise past what the learner agreed, so set `time.weekly_ceiling_min` to the agreed ceiling in the same step. With one subject, also `ind set root subjects.<id>.target_weekly_min <new weekly target>`, or the week view keeps the old target; with several, set each subject's so they add up to the total ([teach.md](teach.md) §9).
- **No date (D):** no verdict; say what fits in the next 4-week cycle.

## 10. Topic order

Rank by gap × weight × the chance of a cold pass within a week (high when every floor topic is owned: level 3p or above, the same line the floor check in [session-teach.md](session-teach.md) §2 draws). Then:
- floor topics before what stands on them;
- skip-probe topics wait for their probe; a V miss gets its word fixed first;
- never-taught topics before polishing owned ones;
- confusable topics not on the same day while being learned; once both reach 3, a weekly mixed "which applies?" sheet until both reach 4 ([plan.md](plan.md));
- the first topic should give an early cold pass.

Log the order and its reason as a ledger decision whose `--check-on` is the first checkpoint.

## 11. Week 1 by session length

| Day | 30 min or less (B) | 45–75 min (A) | 120 min or more (C) |
|---|---|---|---|
| 1 | Placement probe 1 (words in sentences) | Diagnostic part A | Part A; break while Part B is built; Part B; results |
| 2 | Placement probe 2 (can-do prompts) and results | Part B, results, probes | Probes, then first teach (theory closed, drills) |
| 3 | Theory card for topic 1 (read, then closed) | First teach | Second teach |
| 4 | Drills for topic 1 | — | 2-day recheck for day 2, then third teach |
| 5 | — | 2-day recheck for day 3, then second teach | 2-day recheck for day 3, then a timed set |
| 6 | 2-day recheck on topic 1 (44–72 h after drills); theory card for topic 2 | — | — |
| 7 | 3-line check-in | Week-1 review (15 min) | Week-1 review |

Code, and on-demand learners (D), whatever they come for: session 1 is the capstone `diagnostic` plus the concept `probe`, with results; session 2 the first teach (code has no Part B); from then on each session opens with any recheck whose window is open. Each recheck is an obligation with a window, never a slot.

## 12. Mocks, rationing and checkpoints

**Mocks** (exam profile; how many and when, by runway: [plan.md](plan.md)):
- Exam conditions (clock, time of day, tools, accommodations), first in the day, in a block of exam length plus 15 minutes. No check lines: the exam has no check column, and a check per answer would take its clock (lint L2 asks for none; the rules box says to check as in the exam). No recheck before it: that day's rechecks go 3+ hours later, or the next day inside their window.
- If no window fits the whole exam, sit one section at a time; section scores are their own series.
- One trend line per instrument family (official, Claude-built, section). Never join mock numbers to diagnostic or recheck numbers.
- Within 48 hours, a `review` block per miss: account, repair, one fresh item, labelled practice. On official items the learner writes a why-line (why they chose their answer) before any reveal, then a "now" answer once Claude has pointed to the line or step the answer turns on, never the answer itself (`miss-review` sheet). A mock miss's recheck comes at least 24 hours after its repair (the repair is an exposure).
- On an online platform, the learner switches off any "show correct answer and explanation" option before opening each missed question, and writes the why-line and the "now" answer on paper before switching it back on.
- **Official answers or explanations pasted into chat anyway:** never quote or use them. Ask once: "Did you read the explanations for any of these? Which?" Only the questions they name count as seen (never infer it), and those skip the "now" answer. Say once that some chat apps offer pasted text back as you type, so the why-lines go on paper.

**Materials entries.** `ind schema subject` doesn't spell these out, so use exactly these shapes:
- `materials.sources[]`: `{"what":"Cambridge IELTS 18","path":null,"answers":false,"seen":"tests 1–2"}`: a plain name; a file or folder, or null for a paper book; `answers` true when it holds answers (registered by path, opened only at marking); what the learner has already seen, or null.
- `materials.ration[]`: `{"unit":"official test 1","job":"checkpoint","date":"2026-11-14","status":"assigned"}`: `job` is `diagnostic`, `checkpoint` or `final mock`; `status` is `assigned`, `used` or `seen` (turned out to be seen: practice only).

**Rationing official material:**
- Each scarce unit (an unseen official test, a past paper with answers) gets one job and a date: the checkpoints and the final mock first, a diagnostic only from what is left. Persona A, dry run first: `ind set ielts materials.ration.+ '{"unit":"official test 1","job":"checkpoint","date":"2026-11-14","status":"assigned"}' --dry-run`, then official test 2 as the `final mock` on 2026-11-21.
- A unit is used only for its job; afterwards set its `status` to `used`.
- A unit already seen, even in part, is never a measurement: practice, labelled `[practice]`. Ask "Have you seen any of this paper before?"
- Don't use an unseen official test for anything a question bank or Claude-written questions could cover (drills, topic practice, words).
- Another job, a unit reserved for a later one included, is the learner's call: `ind session override` with an item prediction, and the confound noted beside the result.

**Checkpoints** (every 1–2 weeks with a date; end of each 4-week cycle without one):
- Pre-register before the sitting, never after (at `teach`, in the subject draft): `ind set <subject> checkpoints.+ '{"date":"2026-11-14","instrument":"official test 1, reading","threshold":"30 of 40","if_below":"two review blocks replace new material for 2 weeks","status":"armed","result":null}'`.
- Mirror it as a safeguard so the brief flags it: `ind ledger add decision --subject ielts --summary "Checkpoint: official test 1, reading" --why "<their words>" --check-on 2026-11-14 --rule "below 30 of 40" --action "as if_below"`.
- After grading: set `status` and `result` (`ind set <subject> checkpoints.<index>.status '"passed"'`), close the row (`ind ledger close <L-id> --status scored --note "…"`), and carry out `if_below` as written. A threshold changes only by a new decision made before the next sitting.
