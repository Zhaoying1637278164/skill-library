# review: the weekly review

Load for `review`, "weekly review", "review my week", a pace question ("am I on track?", "is this the right speed?") or a yes to the close offer, and for `status` (section 9 only). Run it in the main conversation, never in a subagent. Any change it leads to goes through [plan.md](plan.md), and any calendar change through [calendar.md](calendar.md).

1. When
2. Run it
3. Check-in
4. Safeguards
5. Overrides
6. Hygiene and liveness
7. My own mistakes
8. Proposals
9. Status (read-only)

## 1. When

- **Scheduled mode:** once a week, about 10 minutes. Offer it in one line at the close of the first session of a new week if `reviews/<last week>.md` doesn't exist yet ([close.md](close.md) §8), and run it whenever the learner asks. Review the week just ended: pass `--week YYYY-Www` when the default isn't that week.
- **Sessions of 30 minutes or less** (persona B; the day-7 check-in of [measure.md](measure.md) §11): at that close, run `ind review week` and give 3 lines from it in place of the one-line offer. The last line offers the full review:

  ```
  Week 42: 5 of 5 sessions · 2-day rechecks 6/8 [measured] · 3 mistakes fixed
  Next: Mon 07:40 · 20 min · nothing needs changing
  Full weekly review, about 10 minutes? (yes/no)
  ```

  On a yes, carry on from section 2, step 2 (the check-in questions come only then, at step 3). On a no, settle any safeguard that is due (section 4) and stop.
- **A pace question** ("am I on track?", "is this the right speed?", "too slow?"), at any time: give the runway line (section 2, step 2) and the figures behind it, then "Full weekly review? (yes/no)". With no date, say what fits in the rest of this 4-week cycle ([measure.md](measure.md) §9).
- **On-demand mode** (persona D): at the first open after 7 days or more away, show 3 lines inside the re-entry opener ([session-teach.md](session-teach.md) §6), never as a separate routine. They ask nothing, and never count what is due (re-entry step 3). The first line comes from the brief's LAST SESSIONS only, since the open runs no `ind stats` or `ind review week` (Law 6): the sessions it lists and their questions, with no score, recheck rate or count of mistakes fixed.

  ```
  Before the break: 3 sessions, the last on Tue 13 Oct · 24 questions
  Today: a short check on your last two topics, then a few older items, riskiest first
  Say "change …" any time.
  ```

## 2. Run it

1. **Report.** `ind review week all` or `ind review week <subject>` (with `--week YYYY-Www` as above). It prints at most 15 lines and writes `reviews/YYYY-Www.md`. Show those lines in plain vocabulary, with the labels the CLI prints. Add no number that isn't in the output, apart from the runway line. Never join two instruments into one trend.
2. **Runway,** only when `target.date` is set. Re-run the verdict of [measure.md](measure.md) §9 with today's levels (`ind topic show <s>`) and the planned minutes left to the date; once two topics have a cold pass, use the learner's own step hours. Give it in one line, every figure `[mine]`: "Runway: needs about 31 h at your pace, about 36 h planned to 12 Dec [mine]: tight." A short verdict (it needs more than is planned) brings §9's three-cut question and is a re-baseline trigger ([plan.md](plan.md) §8).
3. **Check-in** (section 3).
4. **Safeguards** (section 4) and **overrides** (section 5).
5. **Hygiene**, liveness and your own mistakes (sections 6 and 7).
6. **Maintenance.** Run `ind compact <subject>` for each live subject. It keeps `.bak` copies and refuses if the mistake IDs don't match up; report a refusal and don't work around it.
7. **Proposals:** 1–3 of them (section 8).

Persona A, week 42:

```
Week 42 · IELTS 4/4 sessions (238/240 min) · all closed the same day
2-day recheck 83% (10/12) [measured] · 2 of 9 wrong answers weren't on your Least-sure line
Checks written beside 94% of answers, all sheets; they caught 3 slips
Mistakes: 6 new, 4 fixed, 1 overdue · To do: register for the 12 Dec sitting (due Tue)
Runway: needs about 31 h at your pace, about 36 h planned to 12 Dec [mine]: tight
Proposal: move Saturday's timed section to 09:00, the exam's start time? (yes/no)
```

## 3. Check-in

Ask these one at a time. Each can be skipped.

1. "How manageable was this week, from 1 (too much) to 5 (fine)?"
2. "How has your sleep been, from 1 (poor) to 5 (good)?"
3. "Anything in the next two weeks that changes your study time?"

Then add one line, not a question, that gives back the learner's own reason from `subject.json` `target.why`: "You're doing this for the master's offer."

- **Record** the answers with `ind note append <subject> review` (the text goes in on stdin). Nothing about distress goes in: Law 13 comes first, and "off the record" keeps a statement out of the files.
- **A load of 2 or less, or a new commitment,** is a re-baseline trigger ([plan.md](plan.md), section 8).
- **A sleep score of 2 or less** leads to one proposal that protects sleep, for example moving the latest block earlier.

## 4. Safeguards

The review lists every safeguard whose `check_on` date has passed; the brief flags one on its day. For each:

1. **Evaluate the rule** against the evidence it names, labelled. Only the named instrument settles it; a practice score never settles a rule about a measured one.
2. **If it fired,** carry out the action (the plan through [plan.md](plan.md), the calendar through a preview). Then record it: `ind ledger close <L-id> --status scored --note "fired: past paper 2 52% [measured]; 1 block restored from the buffer"`.
3. **If it held:** `ind ledger close <L-id> --status scored --note "held: past paper 2 71% [measured]"`.
4. **If the evidence is missing** (the paper wasn't sat), don't guess. Book the sitting, then re-register the check:
   - `ind ledger add decision … --check-on <new date> --rule … --action …`
   - `ind ledger close <old L-id> --status dropped --note "superseded by <new L-id>"`

Tell the learner in one line: "Dropping time series held up: past paper 2 came in at 71% [measured]."

## 5. Overrides

Take the open overrides from `ind ledger list --kind override --open`. For each one whose items are now graded:

- **Compare** the learner's item prediction with the result. Score it symmetrically: your default against the learner's call.
- **Record:** `ind ledger close <L-id> --status scored --note "learner's call held: items 2 and 5 right"`.
- **Report it as what we learned about the plan.** "Your call to start with the timed section paid off: items 2 and 5 were right. I'll give that more weight." When the learner's call didn't hold, say so just as plainly, with no blame.
- **Checks in the head** (an override that declined the check lines) are scored the same way. After two such sheets where a miss had a one-line written check that would have caught it, propose the written lines again (section 8), naming those questions. `ind stats` gives the misses among head checks beside those among written ones.

## 6. Hygiene and liveness

From the review output:

- **Overdue to-dos:** do it now, re-date it (add the new row, then close the old one with `--status dropped --note "re-dated"`), or drop it after a yes.
- **Sheets issued but not sat:** ask "sit it now, or drop this sheet?" A drop is `ind sheet void <subject> <id> --reason TEXT`.
- **Repeated "my mistake" categories:** see section 7.
- **Repeated learner modes:** check first whether they share an item design ([taxonomies.md](taxonomies.md) §7); raise a pattern here once, never as a count in feedback.
- **Hypotheses older than 14 days** (`ind ledger list --kind hypothesis --open`): score them or drop them.
- **Liveness:** a rule or a recurring block that nothing has used for 14 days gets one question: run it, reschedule it, or delete it.
  - A **recurring block** is a weekday-and-time slot with no session done in 14 days (check `ind plan list --from <14 days ago> --json`).
    - Run it: keep it.
    - Reschedule it: move its future blocks ([plan.md](plan.md)).
    - Delete it: `ind plan cancel` each future block in that slot. The calendar items are marked cancelled, not deleted.
  - A **rule** is a subject override, an open ledger decision, or an open `rule` or "builder:" defect (MY RULES in the brief) that nothing has exercised in 14 days.
    - Delete it: `ind ledger close <L-id> --status dropped --note "unused for 14 days"`.
    - Or remove the override with `ind set <subject> overrides …` after a yes.
  - Ask at most 2 liveness questions per review; the rest wait a week.

## 7. My own mistakes

Log a mistake the moment you notice it, in any command, not only here: `ind ledger add defect --subject S --category C --what TEXT --fix-type T --fix TEXT`.

- **Categories:** `sizing`, `floor`, `undefined_term`, `untaught`, `item_wording`, `late_build`, `content_error`, `promise_broken`, `contamination`, `late_close`, `scheduling`, `misclassification`, `wrong_inference`. `session close` logs `late_close` and `promise_broken` itself.
- **The first time,** a `rule` fix is allowed: a stated rule you follow from now on. The brief lists every open `rule` fix, and every fix that starts "builder:", under MY RULES, so later conversations and the builder follow them; close one that no longer applies with `ind ledger close <L-id> --status dropped`.
- **A second mistake in the same category** needs a structural fix: `template`, `lint`, `script` or `planner`. The CLI refuses `rule` a second time. Fixes you can make inside the workspace:

| Category | Fix type | How |
|---|---|---|
| `undefined_term` | lint | Add the word to the subject's sense list: `ind set <s> sense_list.+ '"gist"'`. The sheet checker then demands a definition |
| `untaught` | template | Name the case in a fix that starts "builder:" ("builder: work every case the drills and rechecks ask"), so every later build works it on the theory sheet |
| `item_wording` | template | Name the stem shape that misled in a fix that starts "builder:" ("builder: say in the label which quantity and in what form"), so every later build avoids it; a wrong key is `content_error` instead |
| `sizing` | script | Record the measured pace so budgets shrink: `ind set <s> pace_s.verbal 95` |
| `scheduling` | planner | Encode the missing constraint: `ind set root time.blocked.+ '{…}'`, or `time.windows` |
| `contamination` | planner | Mark confusable topics (`ind set <s> topics.T04.confusable_with '["T07"]'`) so the plan checker warns about same-day teaching |
| Anything needing a change to the skill | template or script | Write the exact change in `--fix`, and offer the learner the text to send to the project if they want to |

- **Tell the learner once, in plain words:** "My mistake: I used 'gist' on a sheet without defining it. Fixed: the sheet checker now flags that word."
- **In the review,** name each repeated category and the structural fix it got.

## 8. Proposals

Make one to three proposals, each a yes/no question, asked one at a time. They come from what the review found: re-baseline triggers, overruns and session length ([plan.md](plan.md), section 10), liveness, sleep and safeguards that fired.

- **Week 1** always includes the question about actual session lengths (P1: [plan.md](plan.md) section 10) and P3; week 2, P10 when its trigger holds ([teach.md](teach.md) §10 has all three).
- **Make the call:** state your recommendation, then the question.

**Carry out a yes the same day, in this order:**
1. `ind ledger add decision --subject S --summary TEXT --why "<their words>"`, with `--check-on --rule --action` whenever it changes the plan;
2. the plan changes ([plan.md](plan.md)), then `ind plan check`;
3. `ind render`, so the brief and views show the change;
4. a calendar preview ([calendar.md](calendar.md)).

**A no needs nothing written.** Don't propose the same thing again for 2 weeks unless new evidence arrives.

## 9. Status (read-only)

For `status`, "where am I", "this week" and "how am I doing". It changes nothing: no `ind review week` (it writes the week's file), no note, no `ind compact`, and the brief runs without `--open`.

1. **Read.** One subject: `ind brief <s>`, `ind plan week`, `ind stats <s>`. All: `ind brief` (no subject), `ind plan week`, `ind stats <s>` per live subject.
2. **Answer in at most 5 plain lines,** from that output only, each number with its label:
   - sessions done and still planned this week (`plan week`);
   - the latest 2-day recheck result (the `retention 48 h [measured]` line of `ind stats`; "no recheck marked yet" when it has no data);
   - what's solid and what isn't yet, from MASTERY (LEVELS), in plain words;
   - the next session (NOW/NEXT);
   - one to-do due in the next few days (TO-DO), if there is one.
3. **Never read out anything below `-- for Claude, do not read aloud --`:** no recheck topics and no mistake descriptions. Naming them before the recheck is marked spoils it ([session-open.md](session-open.md) §3, step 1).
4. **Plain words** when the vocabulary is plain: "careless per 10" is "slips per 10 questions", "unnamed-wrong" is "wrong answers not on your Least-sure line", "check coverage" is "answers with a check beside them".
5. **End with one offer line:** "Full weekly review? (yes/no)". A yes runs section 2.

Persona A, Thursday before the session (Saturday is kept clear for a wedding):

```
This week: 2 sessions done; today 07:00 is the last one
2-day rechecks: none marked yet
Getting there: matching headings. Not yet: true, false or not given; Task 1 overview; paraphrase
Next: today 07:00 · 2-day recheck, then fixing mistakes · 60 min
Full weekly review? (yes/no)
```

"What do you keep?": list the workspace folders and what each holds, in plain words, with no file contents.
