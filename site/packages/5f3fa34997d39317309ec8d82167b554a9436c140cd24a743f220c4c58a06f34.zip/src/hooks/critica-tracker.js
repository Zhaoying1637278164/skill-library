#!/usr/bin/env node
// critique — UserPromptSubmit hook
// Per-turn reinforcement: keeps critique mindset in model attention every message

const fs = require('fs');
const path = require('path');
const os = require('os');

const claudeDir = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
const flagPath = path.join(claudeDir, '.critique-active');
const TTL = 86400; // seconds — badge auto-clears this long after last hook run

// Flag format: <state>:<lang>:<unix_ts>, state being "active" or "off".
// "off" is stored explicitly rather than by deleting the file: absence means
// "never installed" and triggers first-run activation, so deleting the flag to
// deactivate made the mode come back on the very next prompt.
const FLAG_RE = /^(active|off):([a-z]{2}):(\d+)$/;

const NAME = '(?:critique|critica|crítica)';
const ART = '(?:\\s+(?:the|a|o|la|le|el|les|los|las))?';
const OFF_VERB = '(?:disable|stop|turn\\s+off|switch\\s+off|desativa(?:r)?|desliga(?:r)?|' +
                 'desactiva(?:r)?|désactive(?:r)?|arrête(?:r)?|sem|sin|sans)';
const ON_VERB = '(?:enable|activate|turn\\s+on|switch\\s+on|reactivate|ativa(?:r)?|reativa(?:r)?|' +
                'liga(?:r)?|activa(?:r)?|reactiva(?:r)?|réactive(?:r)?|active(?:r)?)';

// Adjacency, not co-occurrence. The previous patterns put `.*` between the verb and
// the name, so any prompt containing both anywhere silently toggled the mode —
// "sem problemas, faz a critica disso" and "stop using critique.md" both turned it off.
const OFF_RE = new RegExp('\\b' + NAME + '\\s+off\\b|\\b' + OFF_VERB + ART + '\\s+' + NAME + '\\b', 'i');
const ON_RE = new RegExp('\\b' + NAME + '\\s+on\\b|\\b' + ON_VERB + ART + '\\s+' + NAME + '\\b', 'i');

// Per-turn reinforcement, keyed by locale — mirrors MESSAGES in critica-activate.js.
//
// This was a single English string until 1.5.4. The flag already carried the detected
// language and handlePrompt already read it, so a user who set CRITIQUE_LANG=pt got a
// Portuguese banner at session start and an English directive on every turn after it —
// the plugin contradicting its own configuration, silently, forever.
const REINFORCEMENT = {
  en:
    'CRITIQUE MODE ACTIVE (medium). Surface real problems first. ' +
    'Speak on: code with logic/auth/state, architecture decisions, specs being elaborated. ' +
    'Stay silent on: trivial tasks (typo/rename/<50 lines), mechanical execution of approved instructions, issues already raised. ' +
    'Adapt focus: code→bugs+security+edge cases; spec/plan→assumptions+YAGNI; architecture→coupling+tradeoffs. ' +
    'Questionable decisions: explain why and what\'s better. ' +
    'Praise only the non-obvious. Order by impact. No sugarcoating.',

  pt:
    'MODO CRÍTICA ATIVO (medium). Traga os problemas reais primeiro. ' +
    'Fale sobre: código com lógica/auth/estado, decisões de arquitetura, specs em elaboração. ' +
    'Fique calado sobre: tarefas triviais (typo/rename/<50 linhas), execução mecânica de instruções já aprovadas, questões já levantadas. ' +
    'Adapte o foco: código→bugs+segurança+edge cases; spec/plano→premissas+YAGNI; arquitetura→acoplamento+tradeoffs. ' +
    'Decisões questionáveis: explique por que e qual é a alternativa melhor. ' +
    'Elogie só o não óbvio. Ordene por impacto. Sem suavizar.',

  es:
    'MODO CRÍTICA ACTIVO (medium). Saca primero los problemas reales. ' +
    'Habla sobre: código con lógica/auth/estado, decisiones de arquitectura, specs en elaboración. ' +
    'Quédate callado sobre: tareas triviales (typo/rename/<50 líneas), ejecución mecánica de instrucciones ya aprobadas, cuestiones ya planteadas. ' +
    'Adapta el foco: código→bugs+seguridad+casos límite; spec/plan→supuestos+YAGNI; arquitectura→acoplamiento+tradeoffs. ' +
    'Decisiones cuestionables: explica por qué y cuál es la mejor alternativa. ' +
    'Elogia solo lo no obvio. Ordena por impacto. Sin suavizar.',

  fr:
    'MODE CRITIQUE ACTIF (medium). Remonte d\'abord les vrais problèmes. ' +
    'Parle de : code avec logique/auth/état, décisions d\'architecture, specs en cours d\'élaboration. ' +
    'Reste silencieux sur : tâches triviales (typo/rename/<50 lignes), exécution mécanique d\'instructions déjà approuvées, points déjà soulevés. ' +
    'Adapte le focus : code→bugs+sécurité+cas limites ; spec/plan→hypothèses+YAGNI ; architecture→couplage+tradeoffs. ' +
    'Décisions discutables : explique pourquoi et quelle est la meilleure alternative. ' +
    'Ne loue que le non évident. Trie par impact. Pas de ménagement.',
};

// Kept in sync with critica-activate.js. Unlinking a symlinked flag removes the link,
// never its target: the redirect guard holds and the flag stops being a permanent
// dead end. See the comment there.
function safeWriteFlag(filePath, content) {
  try {
    // The config directory may not exist yet — CLAUDE_CONFIG_DIR can point anywhere, and a
    // first run can land before Claude Code has created it. Without this, writeFileSync threw
    // ENOENT into the empty catch below and the flag was never written: the session start
    // produced its banner but persisted nothing, so the badge stayed dark and the detected
    // language was lost. Present since 1.3.1.
    const dir = path.dirname(filePath);
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    try { if (fs.lstatSync(dir).isSymbolicLink()) return; } catch (e) {}
    try { if (fs.lstatSync(filePath).isSymbolicLink()) fs.unlinkSync(filePath); } catch (e) {}
    const tmp = filePath + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, content, { encoding: 'utf8', mode: 0o600 });
    fs.renameSync(tmp, filePath);
  } catch (e) {}
}

function readFlag(filePath) {
  try {
    const stat = fs.lstatSync(filePath);
    if (stat.isSymbolicLink() || stat.size > 64) return null;
    return fs.readFileSync(filePath, 'utf8');
  } catch (e) { return null; }
}

function fileExists(filePath) {
  try { fs.lstatSync(filePath); return true; } catch (e) { return false; }
}

// null when the file is absent, a symlink, oversized, or does not match FLAG_RE.
function parseFlag(filePath) {
  const content = readFlag(filePath);
  const m = content && content.trim().match(FLAG_RE);
  if (!m) return null;
  return { state: m[1], lang: m[2], ts: parseInt(m[3], 10) };
}

function refreshFlag(filePath) {
  const flag = parseFlag(filePath);
  const state = flag ? flag.state : 'active';
  const lang = flag ? flag.lang : 'en';
  safeWriteFlag(filePath, state + ':' + lang + ':' + Math.floor(Date.now() / 1000));
}

function spawnActivate() {
  try {
    const { spawn } = require('child_process');
    spawn(process.execPath, [path.join(__dirname, 'critica-activate.js')], {
      detached: true,
      stdio: 'ignore',
      env: process.env
    }).unref();
  } catch (e) {}
}

// Claude Code writes the hook payload straight to this process's stdin and never emits a BOM,
// but a PowerShell 5.1 pipe does — and JSON.parse then throws into the caller's catch, so
// critique stops injecting with no signal anywhere. The manual commands in CONTRIBUTING run
// through exactly such a pipe. U+FEFF is written as an escape on purpose: as a literal it is
// invisible in an editor and one careless reformat silently removes the guard.
function readPrompt(raw) {
  const data = JSON.parse(String(raw).replace(/^\uFEFF/, ''));
  return (data.prompt || '').trim();
}

function injection(lang) {
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: REINFORCEMENT[lang] || REINFORCEMENT.en
    }
  });
}

// Extracted for testability. fp defaults to module-level flagPath.
function handlePrompt(prompt, fp) {
  const file = fp !== undefined ? fp : flagPath;
  const now = Math.floor(Date.now() / 1000);
  const flag = parseFlag(file);
  const lang = (flag && flag.lang) || 'en';

  if (ON_RE.test(prompt)) {
    safeWriteFlag(file, 'active:' + lang + ':' + now);
    return null;
  }
  if (OFF_RE.test(prompt)) {
    safeWriteFlag(file, 'off:' + lang + ':' + now);
    return null;
  }

  // First-run detection: flag absent means SessionStart was missed (mid-session install).
  if (!fileExists(file)) {
    spawnActivate();
    // Write flag now so critique injects this turn; activate.js will overwrite with correct locale
    safeWriteFlag(file, 'active:en:' + now);
    // English on purpose: the locale is not known until activate.js finishes, and the
    // flag written above says so. From the next turn on it follows the detected one.
    return injection('en');
  }

  // File is present but unreadable, symlinked, oversized, or malformed. Stay silent
  // rather than guessing — SessionStart rewrites a clean flag next session.
  if (!flag) return null;
  if (flag.state !== 'active') return null;
  if (now - flag.ts > TTL) return null;

  safeWriteFlag(file, 'active:' + flag.lang + ':' + now);
  return injection(flag.lang);
}

if (require.main === module) {
  let input = '';
  process.stdin.on('data', chunk => { input += chunk; });
  process.stdin.on('end', () => {
    try {
      const prompt = readPrompt(input);
      const out = handlePrompt(prompt);
      if (out) process.stdout.write(out);
    } catch (e) {
      if (process.env.DEBUG_CRITIQUE) process.stderr.write('[critica-tracker] ' + e.stack + '\n');
    }
  });
}

module.exports = { safeWriteFlag, readFlag, parseFlag, refreshFlag, readPrompt, handlePrompt, REINFORCEMENT, OFF_RE, ON_RE, TTL };
