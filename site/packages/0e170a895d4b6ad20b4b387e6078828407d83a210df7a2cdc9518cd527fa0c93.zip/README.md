# Plantime for Claude Code

Run your [Plantime](https://www.plantime.io) workforce schedule from Claude — read
team rosters, plan and copy shifts, auto-assign staff, and review timesheets, all
against your own Plantime account over the authenticated MCP connector.

## Install

```
/plugin marketplace add plantime/claude-plugins
/plugin install plantime@plantime
```

(To try it from a local checkout instead: `/plugin marketplace add ./path/to/this/repo`.)

Then authenticate once:

```
/mcp
```

Pick the `plantime` server and complete the Plantime sign-in in your browser. Run
`/plantime:setup` to confirm it worked.

The plugin ships a pre-registered public OAuth client (`clientId` + `callbackPort` in
`.mcp.json`). Plantime's authorization server does not support dynamic client
registration, so without that block Claude Code cannot start the flow at all — if you
configure the server by hand instead, pass the same values:

```bash
claude mcp add --transport http plantime https://www.plantime.io/api/mcp/v1 \
  --client-id 7b22a093-8dcc-4a0b-bac8-cf420ecc0d3b --callback-port 6171
```

The plugin bundles the MCP server, so you do **not** also need
`claude mcp add --transport http plantime https://www.plantime.io/api/mcp/v1`. If you
already added it that way, either is fine — the skills refer to tools by
name and work with both.

The connector uses OAuth — your Plantime password is never shared with Claude, and
every action is permission-checked server-side against your own access levels.
Planning tools need `manager`, `admin` or `owner` on the team; timesheet tools also
let employees view and approve their own.

## Skills

Everything ships as skills. Four are invoked explicitly; two load automatically when
what you ask matches them.

| Invoke directly | What it does |
|---|---|
| `/plantime:setup` | Check the connector is authenticated and show what you can access |
| `/plantime:workspace` | List your organizations, teams, roles and planning windows |
| `/plantime:plan` | Build out a period's shifts — copy a week, repeat a template, or fill from history |
| `/plantime:auto-assign` | Run the auto-assign planner over open shifts and review the result |

| Loads on its own | What it knows |
|---|---|
| `plantime:planning` | The whole scheduling loop: resolving IDs, timezone-correct date-times, creating and copying and deleting shifts, assigning people, the asynchronous `auto_assign` planner and its objective weights, and coverage reporting |
| `plantime:timesheets` | The two-sided approval model, statuses, and the minutes and pay-cents fields. Also invocable as `/plantime:timesheets` to triage a list |

So you never have to reach for a command — "who's short-staffed next Tuesday?", "copy
this week's rota into March", "show me pending timesheets for the kitchen team" all work
on their own.

## Safety

The plugin is deliberately conservative about writes, because these tools change a
real business's schedule and a real person's pay period:

- Every write is confirmed first, with the resolved dates and the number of shifts
  or people it will touch.
- Fan-out tools (`copy_shifts`, `create_shifts_on_range`, `auto_assign`,
  `fill_shifts_from_history`, range deletes, the bulk suggestion tools) always state
  their blast radius before running.
- `delete_shifts` is a soft delete; the plugin surfaces the returned `undoId` and its
  one-hour expiry so you can reverse it with `undo_delete_shifts`.
- Timesheets are approved one at a time, never in bulk, and always after showing the
  hours.

## Pointing at another environment

The endpoint is hardcoded to `https://www.plantime.io/api/mcp/v1`. It deliberately does
**not** use `${VAR}` substitution: Claude Code expands those, but Cowork treats the URL
as a literal string and rejects it as not starting with `https`.

To reach a staging or local server, add a second server alongside the plugin rather than
editing this one — see [Developing](#developing).

## Developing

```bash
claude plugin validate . --strict          # marketplace manifest
claude plugin validate ./skills --strict
```

The installed copy is a **version-keyed snapshot**. `marketplace update` alone will not
pick up your edits — bump `version` in `.claude-plugin/plugin.json` first:

```bash
claude plugin marketplace update plantime
claude plugin update plantime@plantime
```

Skip the bump and you keep testing the old plugin while `claude plugin details` reports
the new inventory, because it reads from source rather than the cache. To see what is
actually installed: `ls ~/.claude/plugins/cache/plantime/plantime/*/skills/`.

Skill edits need `/reload-plugins`; `.mcp.json` changes need a full restart.

Never put a bearer token in `.mcp.json` — it would ship a hardcoded `Authorization`
header to every user. To test against a local webapp, add a separate server instead:
`claude mcp add --transport http plantime-local http://localhost:3000/api/mcp/v1 \
--header "Authorization: Bearer $TOKEN" --scope local`.

## Troubleshooting

**`Unauthenticated` / 401** — the OAuth session lapsed. Run `/mcp` and sign in again.

**"that endpoint doesn't support dynamic client registration"** — the `oauth` block in
`.mcp.json` is missing or was overridden. Plantime authenticates against Supabase, which
requires a pre-registered client; see the install section above.

**OAuth flow fails to complete** — port 6171 must be free, since it is the registered
redirect URI (`http://localhost:6171/callback`) and cannot be changed client-side.

**A team is missing** — the connector only sees workspaces your Plantime account
belongs to, and planning tools additionally need a manager-level role on that team.

**Dates land an hour off** — shift times are absolute instants. The skills build them
with an explicit UTC offset for the team's timezone; if you pass times yourself, do
the same rather than using a bare date or a `Z` suffix.

**`range too large`** — each tool caps its span (90 days for schedule reads and
range creates, 62 for auto-assign, 31 for deletes and copy sources). Split the work.

**A read looks incomplete** — `get_team_schedule` returns at most 200 shifts and sets
`truncated: true` when there are more. Narrow the range.

## Support

[support@plantime.io](mailto:support@plantime.io) · [plantime.io/support](https://www.plantime.io/en/support)

## License

MIT
