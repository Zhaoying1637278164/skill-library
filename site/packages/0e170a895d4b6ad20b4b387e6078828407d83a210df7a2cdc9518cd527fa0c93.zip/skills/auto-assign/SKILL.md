---
name: auto-assign
description: Run the Plantime auto-assign planner over a team's open shifts and review what it filled
argument-hint: "<team> <period> [e.g. 'even hours' | 'cheap' | 'ignore preferences']"
disable-model-invocation: true
---

Run the auto-assign planner to fill a Plantime team's open shifts, then report the
result. Follow the `planning` skill.

This command writes to the schedule. If the user only wants to *see* who is working,
that is a plain read — answer it with `get_team_schedule` and do not run the planner.

Arguments: $ARGUMENTS (team, period, and optionally what to optimise for).

1. `get_workspace` → resolve the team and timezone; require `manager` or above.
2. Resolve the period; `endDate` is **exclusive** and the range cannot exceed 62 days.
3. `get_team_schedule` with `includeContracts: true` over the range. Report how many
   shifts are open (`assignedCount < contractCount`) before doing anything. If none
   are, stop and say so.
4. If the user expressed a preference, translate it into `objectiveTuning` — e.g.
   "even hours" → `weights: {workload: 0.75}`, "cheap" → `weights: {cost: 0.75}`,
   "ignore preferences" → `enabled: {preference: false}`. Otherwise omit the block
   entirely and let the organization's defaults stand.
5. Confirm with the user: team, resolved range, open-shift count, and the tuning you
   will send. Wait for a yes.
6. Call `auto_assign`. `{success: true}` only means the job was dispatched — say the
   planner is running, then re-read the range with `get_team_schedule` to see the
   real result. If nothing has changed, wait and read once more before concluding.
7. Report: how many shifts the planner filled, and a list of the ones still open with
   day, time, role and shortfall. Offer to place those individually with
   `assign_contract`, checking each person's `competencyIds` covers the shift's role.

Do not touch `apply_suggested_contracts` or `discard_suggested_contracts` unless the
user asks — both act on every pending suggestion on the team, including ones this
conversation did not create.
