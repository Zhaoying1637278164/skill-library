---
name: planning
description: Plan and staff shifts in a Plantime workspace — read team schedules, create/copy/repeat/delete shifts, assign people, run the auto-assign planner, and report coverage and hours. Triggers on "plan next week", "add a shift", "copy this week's rota", "who's working Tuesday", "auto-assign the open shifts", "where are the gaps", "how many hours did we plan", "take Maria off next week".
---

# Planning and staffing in Plantime

The `plantime` MCP server exposes one workspace — the signed-in user's. Every call is
permission-checked server-side exactly as the web app is, so `no permission` is a real
answer about access level, not something to work around. Planning tools need `manager`,
`admin` or `owner` on the team.

## Ground yourself first

Every tool takes UUIDs. **Nothing accepts a name.** Never invent or pattern-match one.

`get_workspace` (no args) returns organizations with nested `teams`. Per team you get
what makes the rest of the work correct:

| Field | Why it matters |
|---|---|
| `id` | The `teamId` every tool needs |
| `timezone` | IANA zone — you MUST build shift times against this |
| `permission` | Below `manager` means planning tools will refuse |
| `openingDays`, `firstShiftStartsAt`, `lastShiftEndsAt` | Defaults when the user doesn't state hours |
| `planFrom`, `planUntil`, `publishedUntil` | The period actually being planned; past `publishedUntil` workers can't see it |
| `weeklyHours`, `workingDaysPerWeek` | Sanity-check coverage against contracted load |

For people and roles, `get_team_schedule` with `includeContracts: true` returns
`contracts[] = {id, name, competencyIds}`, and `includeCompetencies: true` returns the
roles. A **contract** is a person's employment record on a team — a `contractId` is how
you refer to a human being here. A person can only fill a shift whose `competencyId` is
in their `competencyIds`.

If a name is ambiguous or absent, ask. Don't pick the closest match.

## Dates

Date arguments are ISO 8601 strings parsed as absolute instants. Two consequences:

**Include an explicit offset matching the team's timezone.** A bare `2026-02-10` or a
`Z` suffix means UTC, which is the wrong wall-clock time for most teams. For
`Europe/Zurich`, "Tuesday 16:00" is `2026-02-10T16:00:00+01:00` (`+02:00` under CEST) —
not `...T16:00:00Z`. Getting this wrong silently shifts every shift by an hour. Work out
the offset for the *specific date*; don't assume today's offset survives a DST boundary.

**Range ends are exclusive** — except `create_shifts_on_range`, whose `applyFrom`/
`applyTo` are inclusive on both ends. To cover all of June 15th elsewhere, pass June 16th
at 00:00.

When the user says "next week", state the concrete dates you resolved it to before
acting, so a Monday/Sunday mismatch surfaces immediately.

## Limits

| Tool | Max span | Other caps |
|---|---|---|
| `get_team_schedule` | 90 days | Max 200 shifts; `truncated: true` means narrow the range |
| `create_shifts` | — | 1–10 shifts per call |
| `create_shifts_on_range` | 90 days | 1–10 templates; templates × days ≤ 1000 |
| `copy_shifts` | source 31, target 90 | Append-only |
| `delete_shifts` | 31 days | — |
| `remove_contract_assignments` | 31 days | — |
| `auto_assign` | 62 days | Asynchronous |

An over-long range returns `{success: false, message: "... range too large ..."}` rather
than throwing. **Read `success` on every result** — a JSON body is not proof the write
happened. Split oversized work into sequential in-range calls and report the total.

## Confirm before writing

Reads need no confirmation — run them freely to ground yourself. Before any write, state
the team, the resolved date range, and **how many shifts or people the call will touch**,
then wait for a yes. This matters most for the fan-out tools, where one call changes
hundreds of rows: `create_shifts_on_range`, `copy_shifts`, `fill_shifts_from_history`,
`auto_assign`, range `delete_shifts`, `remove_contract_assignments`, and the two bulk
suggestion tools.

Treat as destructive, never batched with other work: `delete_shifts`, `edit_shift`,
`remove_contract`, `remove_contract_assignments`, `discard_suggested_contracts`.

## Creating shifts

A shift is a staffing slot: start, end, `competencyId` (role), `contractCount` (people
needed). People attach separately. Creating an unstaffed shift is normal and often
correct — create the demand first, staff it second.

```
Does a similar period already exist in this team's schedule?
├── Yes, a specific week/period I want repeated
│      → copy_shifts (source range → target range)
├── Yes, but I just want "our usual rhythm", no named source
│      → fill_shifts_from_history
└── No, describing the shifts from scratch
       ├── Same pattern on every day of the range → create_shifts_on_range
       └── A handful of one-off shifts (≤ 10)     → create_shifts
```

**`create_shifts`** — `{teamId, shifts[]}`, each `{from, to, competencyId, contractIds?,
unpaidBreakMinutes?}`. Passing `contractIds` creates the shift and locks those people on
it. Hard cap 10; for more of the same shape switch tools rather than looping.

**`create_shifts_on_range`** — up to 10 templates plus `applyFrom`/`applyTo` (inclusive,
90-day max). Each template is replayed **on every single day** of the range at the same
clock time. **There is no weekday filter.** For a Mon/Wed/Fri pattern, build one
representative week with `create_shifts` and then `copy_shifts` it forward — that is
almost always what "the same schedule every week" means, and it's one confirmation
instead of many. Guard the fan-out yourself: `templates × days` ≤ 1000, and tell the user
that number first. Ten templates over 90 days is 910 shifts.

**`copy_shifts`** — `{teamId, from, to, applyFrom, applyTo}`. **Append-only**; it never
overwrites. If the target already has shifts you must pass `allowNonEmptyTarget: true` —
check with `get_team_schedule` and warn about duplicates before you do. A 7-day source
into a 28-day target repeats the week four times.

**`fill_shifts_from_history`** — `{teamId, from, to, maxWeeks?, fromWeekday?,
tzOffsetMinutes?}`. Replays the team's recent pattern into an empty range without
overwriting. Use it for "just fill it like we normally do". `fromWeekday` is 0 = Sunday …
6 = Saturday; pass `tzOffsetMinutes` for the team's zone so day boundaries land locally.
Because the result depends on history you can't see, always re-read afterwards.

If hours or roles aren't stated, don't invent them — take the defaults from the team
record (`openingDays`, `firstShiftStartsAt`, `lastShiftEndsAt`) and the role list, then
say which defaults you used in the confirmation. Omit `unpaidBreakMinutes` unless given.

## Editing and deleting

`edit_shift` — `{teamId, shiftId}` plus any subset of `from`, `to`, `contractCount`,
`competencyId`, `unpaidBreakMinutes`. Omitted fields are left alone; one shift per call.
Get `shiftId` from a fresh `get_team_schedule`, never from memory. Past roughly a dozen
edits, ask whether deleting and recreating is what the user wants — deletion has a
one-hour undo, a long chain of edits has none.

`delete_shifts` needs exactly one of `{teamId, shiftId}` or `{teamId, from, to}` (`to`
exclusive, 31-day max). It's a **soft delete** returning an `undoId` valid for **one
hour**. Show that id and its deadline in your reply every time; `undo_delete_shifts`
takes `{teamId, undoId}`. After an hour the only recovery is recreating by hand.

Before a range delete, read the range and report the exact shift count and whether any
are already staffed — deleting a staffed shift removes the assignment too.

## Staffing

`get_team_schedule` returns `contractCount` (needed) and `assignedCount` (has) per shift.
A shift is **open** when `assignedCount < contractCount`. That comparison is the basis of
every staffing answer — don't call a shift covered because one person is on it if it
needs two. Add `includeWorkload: true` for contracted-hours rows before answering "is
anyone overloaded".

**`assign_contract`** — `{teamId, shiftId, contractId, suggested?}`. There is **no
uniqueness constraint**: calling it twice assigns the person twice. Read
`assignedCount` first, and never retry a call that may already have succeeded.
`suggested: true` records a proposal instead of committing.

**`remove_contract`** — `{teamId, shiftId, contractId}`; the shift survives and reopens.

**`remove_contract_assignments`** — `{contractId, from, to, deleteIfUnstaffed?}` unassigns
one person across a range (`to` exclusive, 31-day max). Right for "Maria is off sick all
next week". `deleteIfUnstaffed: true` also *deletes* any shift left empty — a destructive
fan-out needing its own explicit yes. Default it to `false` unless the user wants the
demand gone too, not just the person.

**Suggestions.** `apply_suggested_contracts` and `discard_suggested_contracts` each take
just `{teamId}` and hit **every pending suggestion on the team**, including ones this
conversation didn't create. Report how many shifts are affected before calling either,
and don't touch them unless asked.

## `auto_assign`

`{teamId, startDate, endDate, objectiveTuning?}`, `endDate` exclusive, 62-day max. Fills
currently-open shifts using availability, roles, preferences, workload and compliance
constraints. Already-assigned shifts are untouched, so re-running to pick up new shifts
is safe.

**It is asynchronous.** `{success: true}` means the job was *dispatched*, not that anyone
is scheduled. Never report the schedule as staffed on the strength of that response:

1. Say the planner is running and over what range.
2. Wait, then re-read the range with `get_team_schedule`.
3. Report the real outcome — how many shifts filled, and list those still open so the
   user can place them by hand.

If nothing changed on the first re-read, wait and read once more before concluding it
produced nothing; a large range takes a while to solve. Shifts left open usually mean no
eligible person was available, not a failure. Run it *after* the shifts exist and after
workers have submitted preferences.

**`objectiveTuning`** is optional — omitting it, or individual factors, keeps the
organization's defaults, which is right unless the user asks for a trade-off. Shape:
`{"enabled": {"preference": false}, "weights": {"workload": 0.75}}`. Factors: `cost`
(labour cost), `workload` (even hours), `preference` (worker preferences), `span` (daily
work span), `underfill` (shifts left short), `overwork` (hours over contract), `karma`
(flexibility balance). Weights run 0.1–1.0: 0.1 very low, 0.25 low, 0.5 normal/default,
0.75 high, 1.0 very high. Out-of-range values are silently clamped by the solver, so stay
inside it.

Map intent to factors rather than asking for numbers — "spread the hours evenly" →
`weights: {workload: 0.75}`; "keep it cheap" → `weights: {cost: 0.75}`; "just cover the
shifts" → `enabled: {preference: false}`, `weights: {underfill: 1}`; "nobody over their
contract" → `weights: {overwork: 1}`; "shorter days" → `weights: {span: 0.75}`. Say which
tuning you're sending in the confirmation.

## Coverage and hours

Most reporting is derived from `get_team_schedule`:

- **Open shifts** — `assignedCount < contractCount`; the shortfall is the difference, not
  a boolean.
- **Planned hours** — sum `endAt - startAt` weighted by `contractCount`; subtract
  `unpaidBreakMinutes` for paid hours specifically.
- **Coverage by role** — group by `competencyId`, named via `includeCompetencies: true`.
- **Load per person** — `includeWorkload: true` against the team's `weeklyHours`.

For organization-wide aggregates, `get_shift_stats` takes `{organizationId, from, to,
groupBy?}` with `groupBy` of `"day"` or `"month"` (omit for a single total; `day` for a
week or two, `month` for a quarter or more). It needs **org-wide** manager access — a
team-scoped manager gets `no permission` here even though they can read their own team's
schedule. If that happens, aggregate from `get_team_schedule` over the teams they can see
and say that's what you did.

If `truncated: true`, any total you computed is wrong — split the range into windows, sum
across calls, and say you did.

## Reporting back

After a fan-out write, re-read the affected range and report what actually landed rather
than echoing the tool's own count — `count` is what was inserted, not what the schedule
now looks like.

Lead with what needs action — the open shifts, the person 12 hours over, the week with no
coverage — and put totals underneath. Group by day, name the role, give the shortfall.
Convert minutes to hours and state the timezone you bucketed days in; a "Monday" depends
on the team's zone, not yours.

## Not authenticated

`Unauthenticated` / 401 means the OAuth session lapsed. Tell the user to run `/mcp` and
re-authenticate with Plantime; you can't fix it from a tool call.
