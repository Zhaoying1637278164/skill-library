---
name: workspace
description: Show your Plantime organizations, teams, roles and planning windows
argument-hint: "[organization name] (optional)"
disable-model-invocation: true
---

Read-only: call `get_workspace` and present the user's Plantime workspace. Do not
call any tool that writes.

$ARGUMENTS — if a name is given, filter the output to the matching organization;
otherwise show everything.

Present one section per organization, and inside it a table of its teams with:

- Team name
- Your access level (`permission`) — flag teams where it is below `manager`, since
  planning tools will refuse there
- Timezone
- Planning window (`planFrom` → `planUntil`) and `publishedUntil`
- Weekly hours / working days per week
- Opening days and the usual first/last shift times

Keep the UUIDs out of the prose, but remember them — the rest of this session's
Plantime work needs them and re-fetching is wasteful.

Close with a one-line note of anything that stands out: a team whose planning window
has already ended, a team with nothing published, or a team you can read but not
plan for.
