---
name: timesheets
description: Triage, read, approve, reject and recalculate Plantime timesheets — the two-sided worker/manager approval model, the pending/approved/rejected/disputed statuses, and how to read the minutes and pay-cents fields. Triggers on "show pending timesheets", "approve my timesheet", "sign off the hours", "why is this timesheet disputed", "recalculate the hours for last month".
---

# Timesheets in Plantime

A **timesheet** is one person's (one `contractId`'s) closed period of worked time on a
team — planned vs actual hours, leave, holidays, and the resulting balance and pay.

Every tool takes UUIDs; nothing accepts a name. Get `teamId` from `get_workspace`, and a
`contractId` from `get_team_schedule` with `includeContracts: true`. Date arguments are
ISO 8601 and range ends are **exclusive** — to cover all of June 30th, pass July 1st.
Read `success` on every result; a JSON body is not proof the write happened. If a call
returns `Unauthenticated` / 401 the OAuth session lapsed — tell the user to run `/mcp`
and sign in again.

Timesheets are the one Plantime area a non-manager can use: employees can list,
read and approve **their own**. Manager access is required to see a whole team's,
and to reject or recalculate.

## Finding them

`list_timesheets` → `{teamId?, contractId?, status?, from?, to?}`. At least one of
`teamId` or `contractId` is required.

- `teamId` → every person's timesheets on that team; needs manager access
- `contractId` alone → that person's own; allowed if the caller owns the contract
- `status` → one of `pending`, `approved`, `rejected`, `disputed`
- `from`/`to` bound the period, `to` exclusive

`get_timesheet` → `{timesheetId}` for one, with the same access rule.

"Show me what needs signing off" is `list_timesheets` with
`{teamId, status: "pending"}`.

## Triage: presenting a list

Invoked directly (`/plantime:timesheets <team or 'mine'> [status]`), default to `pending`.
For "mine", resolve the user's own `contractId` via `get_team_schedule` with
`includeContracts: true` and filter by `contractId` rather than `teamId`.

Present a table — person, period, expected vs effective hours, balance, status — with
minutes converted to hours and cents to currency. Sort so the ones needing action come
first: `disputed`, then `pending` with the largest balance deviation.

## Status is derived, not stored

Each timesheet has two independent approval sides. `status` is computed from them:

| Status | Meaning |
|---|---|
| `pending` | Not all required sides have approved yet |
| `approved` | Manager approved, and the worker too if the team requires worker approval |
| `rejected` | One side rejected and the other has not approved |
| `disputed` | One side rejected while the other side approved — a genuine standoff needing a human |

`disputed` is the one to escalate rather than resolve by another tool call. Report
the `rejectionReason` and who rejected, and let the user decide.

Whether the worker side is required at all is a team setting
(`timesheetRequireWorkerApproval`), so on some teams a manager approval alone
finalises the period.

## Approving and rejecting

`approve_timesheet` → `{timesheetId, as}` where `as` is `"contract"` (the employee's
own sign-off) or `"manager"` (the manager sign-off). `reject_timesheet` takes the
same plus a non-empty `reason`.

Pick `as` from who the user is acting as, and say which side you are signing in your
confirmation — "approving as the manager" and "approving as the employee" are
different acts with different authority, and choosing the wrong one either fails on
permissions or records the wrong person's agreement.

**Always show the numbers before approving.** Read the timesheet, summarise
expected vs effective hours and the balance, and get an explicit yes. Approving is
a formal sign-off on someone's pay period; never batch-approve a list without the
user confirming each one, and never approve on your own judgement that "the hours
look right".

A rejection needs a real reason from the user. Do not compose one on their behalf.

## Recalculating

`recalculate_timesheet` → `{timesheetId}` recomputes the period from current source
data (shifts, time entries, holidays, leave). Use it when the underlying schedule
changed after the timesheet was generated. It requires manager access and **errors
on an already-approved timesheet** — approved periods are locked.

It overwrites the stored computed values, so if a number matters to the user,
capture it before recalculating.

## Reading the fields

Durations are **minutes**, money is **integer cents**. Convert for display and name
the currency unit rather than printing a bare number.

| Field | Meaning |
|---|---|
| `expectedMinutes` | What the contract required for the period |
| `plannedMinutes` | What the schedule planned |
| `effectiveMinutes` | What was actually worked |
| `balanceMinutes` | Over/under against expected; negative is a shortfall |
| `carryOverMinutes` | Balance brought in from the previous period |
| `holidayMinutes`, `leaveMinutes` | Non-worked time credited to the period |
| `workedPayCents`, `paidLeavePayCents`, `holidayPayCents`, `vacationPayCents` | Pay components |
| `grossPayCents` | Total gross for the period |
| `contractApprovedAt`, `managerApprovedAt`, `managerApprovedBy` | Approval trail |
| `rejectedAt`, `rejectedBy`, `rejectionReason` | Rejection trail |
| `periodStart`, `periodEnd` | The period covered |

When summarising a list, lead with the ones that need action — `pending` and
`disputed` — and flag any timesheet whose `balanceMinutes` is far from zero, since
that is usually what a manager wants to look at before signing.

If a tool reports timesheets are not enabled, the feature is off for that team or
contract; that is a Plantime settings change, not something to route around.
