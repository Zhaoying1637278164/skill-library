---
name: setup
description: Check the Plantime connector is authenticated and working, and explain how to fix it if not
disable-model-invocation: true
---

Verify the Plantime MCP connector.

1. Call `get_workspace` with no arguments.
2. If it succeeds, confirm the connection and summarise what the user has access to:
   how many organizations and teams, and which of those teams they can actually plan
   for (`permission` of `manager`, `admin` or `owner`).
3. If it fails with `Unauthenticated` or a 401, the OAuth session has lapsed or was
   never completed. Tell the user to run `/mcp`, select the `plantime` server, and
   complete the browser sign-in. Do not retry the tool call in a loop.
4. If the server is not listed at all, the plugin's MCP server did not load. Have
   them check `/mcp`, and confirm whether `PLANTIME_MCP_URL` is set to something
   other than `https://www.plantime.io/api/mcp/v1` — that variable overrides the
   endpoint and is the usual cause of pointing at a dead local server.

Then list what they can do next: `/plantime:workspace`, `/plantime:plan`,
`/plantime:auto-assign`, `/plantime:timesheets` — and note that they can also just ask in
plain language ("show me next week for the kitchen team", "where are the gaps?").
