---
name: plan
description: Build out a Plantime team's schedule for a period — copy a week, repeat a template, or fill from history
argument-hint: "<team> <period, e.g. 'next 4 weeks' or 'March'>"
disable-model-invocation: true
---

Create shifts for a Plantime team over a period. Follow the `planning`
skill; this command is the interactive wrapper around it.

Arguments: $ARGUMENTS (team, then the period to plan).

1. `get_workspace` → resolve the team, its timezone, opening days and usual shift
   times. Stop if the user's access level on that team is below `manager`.
2. Resolve the period to concrete dates in the team's timezone and state them.
3. `get_team_schedule` over the target range to see what is already there. If it is
   not empty, say so — none of the create tools overwrite, so planning on top of
   existing shifts produces duplicates.
4. Decide the approach and say which you picked and why:
   - a named source week to repeat → `copy_shifts`
   - a pattern the user described that repeats every day of the range → `create_shifts_on_range`
   - "the usual" with no named source → `fill_shifts_from_history`
   - a handful of specific shifts → `create_shifts`

   For a weekly pattern that is not every-day, build one representative week with
   `create_shifts` and then `copy_shifts` it forward — `create_shifts_on_range` has
   no weekday filter.
5. **Before writing**, show a short plan: team, resolved range, the shift shapes, and
   the total number of shifts this will create. Wait for a yes.
6. Write, then re-read the range with `get_team_schedule` and report what actually
   landed — count, span, roles, and how many shifts are unstaffed.

Offer `/plantime:auto-assign` as the next step if shifts came out unstaffed. Do not run
auto-assign yourself from this command.
