---
name: run-gbp
description: GBP optimization workflow using SearchAtlas's GBP suite — covers location audit, AI-powered recommendations, posts generation, reviews automation, citations, and photo management for both first-time setup and monthly maintenance.
---

# /searchatlas:run-gbp

Execute a GBP workflow — either first-time profile optimization or monthly maintenance.

## Instructions

### Step 1: Choose Mode

Ask the user:
> Is this a **first-time optimization** or **monthly maintenance** (reviews, posts, automation)?

### First-Time Optimization

Load `workflows/gbp-optimization.yaml` and execute:

1. **Load location** — `gbp_get_location` to sync latest from Google
2. **Get current state** — `gbp_get_location` + `gbp_get_location_metrics`
3. **AI recommendations** — `gbp_generate_location_recommendations` then `gbp_bulk_apply_recommendations` (apply CHANGE + ADD types, skip DELETE for manual review)
4. **Fix categories** — `gbp_manage_categories` to set primary + additional categories
5. **Add services** — `gbp_upsert_services` to add/update services with AI-generated descriptions
6. **Add attributes** — `gbp_manage_attributes` to fill in missing attributes
7. **AI description + deploy** — `gbp_suggest_description` to generate, `gbp_update_location` to save, then `gbp_bulk_deploy_locations` to push the changes live to Google

Ask the user for: GBP location ID (or help them find it via `gbp_list_locations`), primary category, additional categories, services to add.

### Monthly Maintenance

Load `workflows/gbp-monthly.yaml` and execute:

1. **Review replies** — `gbp_list_reviews` (unanswered) → `gbp_ai_generate_review_reply` → `gbp_set_review_reply_published` for each
2. **Generate posts** — `gbp_bulk_generate_posts` + `gbp_bulk_publish_posts`
3. **Automated posting** — `gbp_update_posting_settings` to configure + enable automated posting
4. **Publish posts** — `gbp_set_post_status` to approve + publish pending posts
5. **Performance summary** — `gbp_get_location_metrics`

Ask the user for: GBP location ID, number of posts to generate (default: 8), post type, whether to enable auto-posting.

### Final Step: Save Workflow Log

After completing all steps, write a workflow log to:

`${SA_CLIENTS_DIR:-$HOME/.searchatlas/clients}/{client_slug}/workflows/gbp-{YYYY-MM-DD}.md`

The log should include:
- Mode (first-time optimization or monthly maintenance)
- Location name, ID, and client slug
- Date/time of run
- Steps completed with results (counts, links where available)
- Steps failed with error details
- Posts generated (titles, post IDs)
- Reviews replied (review IDs, rating, reply snippet)
- Next recommended action

After writing the file, print the path in chat so the user can open it.

## Output Format

**Optimization:**
```
✅ {location_name} — GBP Profile Optimization

📍 Location       synced from Google                      View →
🤖 Recommendations {N} applied (CHANGE + ADD)             View →
🏷️ Categories      primary + {N} additional set            View →
🛎️ Services        {N} services added/updated              View →
✅ Attributes      {N} missing attributes added            View →
📝 Description     AI description generated + deployed     View →

📄 Workflow log: ${SA_CLIENTS_DIR:-$HOME/.searchatlas/clients}/{slug}/workflows/gbp-{YYYY-MM-DD}.md
```

**Monthly:**
```
✅ {location_name} — GBP Monthly · {period}

⭐ Reviews         {N} replies published                   View →
📢 Posts           {N} posts generated + published         View →
🤖 Auto-posting    enabled · {frequency}                   View →
📊 Performance     {views} views · {clicks} clicks         View →

📄 Workflow log: ${SA_CLIENTS_DIR:-$HOME/.searchatlas/clients}/{slug}/workflows/gbp-{YYYY-MM-DD}.md
```

## Golden Rules

- Always `gbp_get_location` first to sync the latest state from Google
- Confirm before deploying changes — deployment pushes to Google
- Skip DELETE-type recommendations — they should be reviewed manually
