# Anthropic directory submission

Two listings. Submit both. They point at the same server.

| Listing | Who it is for | Form |
|---|---|---|
| **Remote MCP connector** | Claude.ai, Desktop, mobile, Cowork | [claude.ai/admin-settings/directory/submissions/new](https://claude.ai/admin-settings/directory/submissions/new) |
| **Plugin** | Claude Code and Cowork | [claude.ai/admin-settings/directory/submissions/plugins/new](https://claude.ai/admin-settings/directory/submissions/plugins/new) or [platform.claude.com/plugins/submit](https://platform.claude.com/plugins/submit) |

You need a Team or Enterprise org (Owners by default), or a Console Developer/Admin/Owner account for the plugin form.

This repo is the plugin. The MCP server lives at `https://mentorcruise.com/mcp`.

## Plugin (this repo)

1. Confirm this GitHub repo is **public**: https://github.com/mentorcruise/plugin
2. From a machine with Claude Code:

   ```bash
   claude plugin validate /Users/dmonn/Documents/projects/plugin
   ```

   Fix anything it reports before you submit.
3. Open the plugin form. Paste:

   - **GitHub URL:** `https://github.com/mentorcruise/plugin`
   - **Name:** MentorCruise
   - **Tagline:** Find a mentor from chat.
4. After it is published, pushes to `main` are picked up automatically. Bump `version` in `.claude-plugin/plugin.json` when you want users to get the update.

Closed-source plugins are rejected. Do not make this repo private.

## Connector (remote MCP)

Use the full walkthrough in the web repo: `docs/anthropic-connector/SUBMISSION.md`.

Short version:

- **Server URL:** `https://mentorcruise.com/mcp`
- **Transport:** Streamable HTTP
- **Auth:** OAuth with DCR and CIMD. Lazy auth: search is anonymous; write tools return 401 + Connect.
- **Docs:** https://mentorcruise.com/agents/
- **Privacy:** https://mentorcruise.com/privacy/
- **Icon:** https://cdn.mentorcruise.com/img/favicons/favicon-196x196.png
- **Support:** info@mentorcruise.com
- **Test account:** a real mentee with applications, credits, and at least one mentorship. Write the login steps in the portal. Do not submit an empty account.

Deploy the padawin-web MCP title and OAuth changes before you hit submit. Reviewers hit production.

## After submit

Track status at [claude.ai/admin-settings/directory/submissions](https://claude.ai/admin-settings/directory/submissions). Escalations: mcp-review@anthropic.com. Include any `ofid_` from a failed Connect attempt.
