# MentorCruise plugin

Find a mentor from the chat you are already in. This plugin connects Claude, Cursor, Grok, and other MCP clients to MentorCruise's public MCP server and ships a playbook for interviewing you and searching the live directory.

Search works without signing in. Applying, messaging, paying, and booking wait on Connect so we know it is you.

## What it includes

- **MCP server** (`https://mentorcruise.com/mcp`): search mentors, read public profiles, list plans and sessions. After Connect: apply, message, pay from credits, and book calls.
- **Skill** (`find-mentor`): a short interview, then `search_mentors` / `get_mentor_profile`. It will not apply or pay unless you ask.
- **Command** (`/find-mentor`): jump straight into that search.
- **Skill** (`setup`): how Connect works when a write tool needs a mentee account.

It does **not** include the staff Admin MCP.

## Install

### Claude (Code / Cowork)

Once this plugin is in the Claude plugin directory:

```bash
claude plugin install mentorcruise
```

Or add the MCP by itself:

```bash
claude mcp add --transport http mentorcruise https://mentorcruise.com/mcp
```

On claude.ai, Cowork, or Claude Desktop you can also use **Customize → Connectors → Add custom connector** and paste `https://mentorcruise.com/mcp`. The directory listing uses the same URL.

To try this repo locally in Claude Code:

```bash
claude --plugin-dir /path/to/mentorcruise-plugin
```

### Cursor

1. Open **Settings → Plugins**.
2. Search for **MentorCruise**, or install from this repo once it is listed on the [Cursor Marketplace](https://cursor.com/marketplace).
3. Click **Install**. Search works after that. When you apply, Cursor will ask you to Connect.

To try it locally before marketplace listing:

```bash
ln -s /path/to/mentorcruise-plugin ~/.cursor/plugins/local/mentorcruise
```

Then **Developer: Reload Window**.

You can also add the MCP by itself in `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "mentorcruise": {
      "url": "https://mentorcruise.com/mcp"
    }
  }
}
```

### Grok

On [grok.com/connectors](https://grok.com/connectors): New Connector, Custom. Paste `https://mentorcruise.com/mcp`. Or install this plugin from the xAI plugin marketplace once the listing is live.

### Other clients

Any MCP client that supports Streamable HTTP can use the same URL. ChatGPT: the [published plugin](https://chatgpt.com/plugins/plugin_asdk_app_6a28f1ae232c819195f8a8faec6c255c), or Developer mode with that URL.

## MCP

```json
{
  "mcpServers": {
    "mentorcruise": {
      "type": "http",
      "url": "https://mentorcruise.com/mcp"
    }
  }
}
```

No API key. Discovery tools (`search_mentors`, `get_mentor_profile`, `get_sessions_or_services`, `create_booking_link`, `list_categories`) plus `register_mentee` / `verify_email` run without a token. Write tools require OAuth Connect; the host then sends `Authorization: Bearer`.

When the assistant asks you to Connect, finish it in the browser: email, the check, then the 6-digit code on that page. You do not paste the code back into the chat. If you already have a mentee account, use the same email.

## Network endpoints

This plugin only talks to MentorCruise:

| URL | Why |
|---|---|
| `https://mentorcruise.com/mcp` | Streamable HTTP MCP |
| `https://mentorcruise.com/.well-known/oauth-protected-resource` | OAuth resource metadata |
| `https://mentorcruise.com/.well-known/oauth-authorization-server` | OAuth server metadata |
| `https://mentorcruise.com/oauth/register` | Dynamic client registration |
| `https://mentorcruise.com/oauth/authorize` | Browser Connect |
| `https://mentorcruise.com/oauth/token` | Token exchange |
| `https://mentorcruise.com/mentor/...` | Public profile links in results |

No other hosts. No telemetry from this repo. The MCP server stores a one-way hash of the caller IP for abuse prevention, as documented at https://mentorcruise.com/docs/mcp.md.

## Credentials

None at install. Search is anonymous. Apply / pay / book need a mentee session from Connect (OAuth 2.1, PKCE S256, dynamic client registration). The plugin does not store tokens; the host does.

## Try a prompt

> I'm an L4 backend engineer at a Series B startup, looking to move toward staff. Find me 3 mentors who've done that, prefer European timezones, budget around $250/month.

The assistant should call MentorCruise tools and return results with profile links.

## Docs

- Human guide: https://mentorcruise.com/agents/
- Implementer spec: https://mentorcruise.com/docs/mcp.md
- Server card: https://mentorcruise.com/.well-known/mcp.json
- Anthropic directory: [ANTHROPIC.md](ANTHROPIC.md)
- Privacy: https://mentorcruise.com/privacy/

## Privacy

Search is anonymous. Apply / pay / book create or use a MentorCruise mentee account. MentorCruise's privacy policy: https://mentorcruise.com/privacy/

This plugin does not store tokens. The host (Claude, Cursor, Grok) does. The MCP server stores a one-way hash of the caller IP for abuse prevention, as documented at https://mentorcruise.com/docs/mcp.md.

## License

MIT
