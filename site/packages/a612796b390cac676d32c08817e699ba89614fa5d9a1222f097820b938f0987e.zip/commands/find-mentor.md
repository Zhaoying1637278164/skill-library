---
description: Find a mentor on MentorCruise
argument-hint: "[what you want help with]"
---

Find a mentor for this request using the MentorCruise MCP tools and the find-mentor skill. Search the live directory. Do not invent names.

$ARGUMENTS
