---
name: setup
description: Set up MentorCruise Connect (OAuth) when search works but apply, message, pay, or book needs a signed-in mentee.
---

# Set up MentorCruise Connect

Search, profiles, plans, and booking links work with no account. Apply, pay, message, and book wait on Connect so MentorCruise knows who you are.

## If the user has not connected

1. Call the write tool they asked for (`apply_to_mentor`, `pay_application`, `send_message`, `book_intro_call`, `book_mentorship_call`, or `book_session`).
2. The server returns HTTP 401. Claude shows a Connect card. Tell the user to finish it in the browser.
3. In the browser they enter their mentee email, complete the check, then enter the 6-digit code on that page. They do not paste the code back into this chat.
4. If they already have a mentee account, they should use the same email. MentorCruise does not open a second profile.
5. After Connect, retry the same tool. Do not start over.

## If Connect is not available

Fall back to in-chat verification:

1. `register_mentee` with their email.
2. Ask them to open `verify_url`, complete the check, then paste the 6-digit code here.
3. `verify_email` with that code.
4. Retry the write tool.

## Hard rules

- Do not apply, pay, or book unless they asked.
- Do not invent mentors. Search with `search_mentors` first.
- Point them at https://mentorcruise.com/agents/ if MCP is missing.
