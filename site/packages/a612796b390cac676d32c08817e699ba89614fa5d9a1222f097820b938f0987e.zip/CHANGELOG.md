# Changelog

## 1.1.0 – 2026-08-27

- Claude plugin manifest (`.claude-plugin/plugin.json`), `/find-mentor` command, and Connect setup skill.
- Anthropic directory submission notes.

## 1.0.0 – 2026-08-26

- First release: hosted MentorCruise MCP plus the find-mentor skill.
- Search works without signing in. Apply, message, pay, and book wait on Connect.
