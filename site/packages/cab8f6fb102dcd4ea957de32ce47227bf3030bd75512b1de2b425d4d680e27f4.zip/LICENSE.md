# LOCI LICENSE AGREEMENT

**Last Updated: May 4, 2026**

This Loci License Agreement ("**Terms**") constitutes a legally binding contract between you ("**Developer**" or "**you**") and Aurora Labs Ltd. ("**we**," "**us**," "**our**," and "**Aurora**") and governs your access to and use of our Loci product, which may be delivered as a plugin, integration, API, service, or through any other present or future distribution mechanism (collectively, "**Loci**" or "**Services**"). These Terms, together with any specific terms, the Data Processing Addendum, Documentation, and any other documents incorporated by reference, constitute the entire "**Agreement**."

By accessing or using the Services, or otherwise interacting with Loci, you agree to be bound by this Agreement. You must be at least 18 years of age to access or use Loci. If you are accepting on behalf of a company or other legal entity and represent that you have authority to bind it, the definitions "Developer" and "you" refer to such entity. If you do not agree, you may not access or use Loci or the Services, or allow any of your personnel to do so.

---

## 1. Definitions

**1.1** "**Authorized Users**" means Developer's employees, independent contractors, or Developer's affiliated companies. Developer will be responsible for the acts and omissions of its Authorized Users, including any acts or omissions that, if taken (or not taken) by Developer, would constitute a breach of the Agreement.

**1.2** "**Account**" means the account created by the Developer to access and use Loci.

**1.3** "**Beta Services**" means any features, endpoints, functionalities, or components that are identified as alpha, beta, preview, early access, or evaluation, or words or phrases with similar meanings, and which are made available to Developer for testing and evaluation purposes prior to general commercial release.

**1.4** "**Confidential Information**" means any confidential or proprietary information of the disclosing Party (the "**Discloser**") that is marked as "Confidential" or under the circumstances of disclosure should reasonably be considered confidential or proprietary. Confidential Information includes the Order Form and non-public information regarding features, functionality, and performance of the Services. Confidential Information does not include information that:

- (a) is lawfully in or enters the public domain through no fault of or breach by the receiving party (the "**Recipient**");
- (b) the Recipient was lawfully in possession of without any obligation of confidentiality prior to receiving it from the Discloser;
- (c) the Recipient developed independently and without use of or reference to the Discloser's Confidential Information; or
- (d) the Recipient receives from a third party without restriction on disclosure and without breach of a nondisclosure obligation.

**1.5** "**Developer Application**" means Developer's owned (or lawfully licensed) and operated application, web app, website, mobile app, game, or software, products, or services that interact with or incorporate Loci. For clarity, the Services are provided solely for use in Developer Applications and may not be sublicensed, resold, or otherwise made available to any third party for their independent use.

**1.6** "**DPA**" means the Data Processing Agreement.

**1.7** "**Input**" means the information, data, or content, in any form or medium, that is provided by Developer or its Authorized Users, directly or indirectly, submitted, uploaded, or otherwise provided to Loci.

**1.8** "**Intellectual Property Rights**" means any and all registered and unregistered rights granted, applied for, or otherwise now or hereafter in existence under or related to any patent, copyright, trademark, trade secret, or other intellectual property rights, in any part of the world.

**1.9** "**Materials**" means any and all materials, content, technology, and components made available by Aurora in connection with Loci or the Services, whether in source or object form, and regardless of delivery mechanism, including any present or future plugin, integration, API, service, repository, package, endpoint, interface, or other distribution method. Materials include, without limitation, software, code, models, prompts, prompt logic, instruction sets, workflows, configurations, pipelines, skill definitions, templates, connectors, authentication components, schemas, setup utilities, developer tools, helper scripts, documentation, technical reference materials, branding elements, and any other related content or materials made available by Aurora.

**1.10** "**Order Form**" means any written or electronic document, agreement, or online form that specifies the Services being provided to Developer, including but not limited to the type of access, usage limits, fees, payment terms, and any other commercial terms agreed upon between the parties. Order Forms are incorporated into and form part of this Agreement.

**1.11** "**Output**" means data, content, video, or other material generated, returned, or otherwise provided by Loci in response to an Input.

**1.12** "**Usage Data**" means data and information related to Developer's use of the Services, Loci, and Account, including telemetry data, timestamps, access times and dates, and duration of use, for the purpose of compiling statistical and performance information related to the provision and operation of the Services, for billing purposes, and for support services (if applicable). Usage Data is governed by Aurora's Privacy Policy.

---

## 2. License and Integration

**2.1 License.** Subject to the terms of this Agreement, Aurora grants Developer and its Authorized Users a limited, worldwide, non-exclusive, non-transferable, non-sublicensable, revocable license, during the Term, to: (i) access and use Loci solely to develop integrations within the Developer Application; and (ii) use the libraries and documentation solely as necessary to integrate with Loci.

**2.2 Loci Documentation.** Developer's use of Loci shall comply with the documentation for Loci, which includes technical specifications, usage guidelines, and other materials provided by Aurora ("**Documentation**"). The Loci Documentation forms an integral part of this Agreement and may be updated by Aurora from time to time.

**2.3 Developer License.** Developer hereby grants Aurora a fully paid, royalty-free, perpetual, irrevocable, worldwide, non-exclusive, and fully sublicensable right and license to use, distribute, reproduce, modify, adapt, publicly perform, and publicly display Developer's Input and Output for the purpose of operating the Services, improving the products and Services, and developing new products and services. Developer acknowledges that the foregoing means Aurora may use Inputs and Outputs to train and improve its artificial intelligence models, algorithms, and related technology, products, and services, and may reuse and generate the Input and Output as part of its training data in its sole discretion. Developer is solely responsible for ensuring that it has all necessary rights, licenses, and permissions to provide Input to Loci and to use Output in connection with its Developer Applications.

**2.4 Reservation of Rights.** Except for the licenses expressly granted, each party shall retain all rights, title, and interest in and to any related Intellectual Property Rights.

---

## 3. Developer's Obligations and Restrictions

**3.1 Sole Responsibility.** Developer assumes sole and exclusive responsibility for any acts or omissions related to the use or misuse of Loci and any Output generated through the Developer Applications, whether by Developer itself or by its end users, customers, or any third parties accessing Loci through Developer Application ("**End Users**"). Developer is solely responsible for ensuring that the Inputs do not include sensitive data (including health information) and that Developer, Authorized Users, and End Users comply with these Terms and any applicable law. To the extent applicable, Developer is solely responsible for adding applicable disclosures to End Users regarding data protection practices and notices, and for obtaining any required consents.

**3.2 Compliance with Terms and Law.** Developer must use Loci only in compliance with this Agreement, the Loci Documentation, and all applicable laws and regulations, including but not limited to laws related to data protection, privacy, intellectual property, export control, consumer protection, and content regulation. Developer is solely responsible for ensuring that its Developer Applications comply with all applicable legal requirements in the jurisdictions where Developer and its End Users operate, including by adding AI disclosures as required by applicable laws. Developer must not misrepresent the nature, source, or authenticity of Output generated by Loci.

**3.3 Security and Credential Management.** Developer must securely store and protect its Loci keys, tokens, authentication credentials, and any other access materials provided by Aurora. Developer may not share its credentials with unauthorized parties or allow third parties to access Loci using Developer's credentials without Aurora's prior written consent. Developer must implement appropriate technical and organizational measures to prevent unauthorized access, use, or disclosure of its Account and licenses provided herein, and shall report to Aurora immediately upon becoming aware of any unusual or unauthorized use of the Account or Services.

**3.4 Registration Information.** Developer must provide accurate, complete, and current information when registering for access to Loci and must promptly update such information if it changes. Developer represents and warrants that the information provided to Aurora is truthful and accurate.

**3.5 Content Moderation.** Developer is responsible for implementing appropriate content moderation measures, safety controls, and filtering mechanisms (substantially similar to the Acceptable Use Policy) to prevent its Developer Applications from generating, distributing, or facilitating access to harmful, illegal, or misleading content through Loci. Developer acknowledges that Aurora has no obligation, and it may be impossible, to pre-screen Developer's (or any End User's) Input or Output, although Aurora reserves the right in its sole discretion to do so. Aurora also reserves the right to remove any Input or Output from the Services that violates this Agreement.

**3.6 Restrictions.** Developer may not, and shall ensure its Authorized Users and End Users do not:

- (a) reverse engineer, decompile, or disassemble Loci;
- (b) circumvent or attempt to circumvent rate limits, quotas, authentication mechanisms, or access controls;
- (c) sell, sublicense, or otherwise provide Loci to third parties without Aurora's prior written consent;
- (d) interfere with, disrupt, or otherwise compromise the security, integrity, or availability of the Services;
- (e) use Loci or Output to generate, disseminate, or otherwise make available illegal content;
- (f) allow access to Loci or the Services from any source other than the Developer Application, meaning Developer may not host (or authorize or direct a third party to host) an endpoint that allows third parties to integrate with or otherwise use Loci in or with their own products or services;
- (g) extract, reproduce, retain, copy, publish, republish, display, distribute, scrape, crawl, harvest, or otherwise use any Materials outside the scope expressly permitted under this Agreement; or
- (h) use any Materials, Loci, Output, documentation, prompt logic, workflows, or related components to train, fine-tune, distill, benchmark, evaluate, improve, imitate, or otherwise support any external artificial intelligence, machine learning, large language model, or competing product or service, in each case without Aurora's prior written consent.

---

## 4. Input and Output Data

**4.1** Developer understands and acknowledges that, due to the nature of machine learning, the Output: (i) may not be unique across users, and Loci may generate the same or similar Output for other users; (ii) may be inaccurate, objectionable, inappropriate, or otherwise unsuited to Developer's purpose; and (iii) is dependent on the Input submitted by Developer, End Users, or Authorized Users, as applicable. Aurora will not be liable for any damages Developer or any third party alleges to incur as a result of or relating to any Output. Additionally, Developer may not use Output to impersonate real persons or falsely attribute Output as originating from real individuals. Developer agrees to evaluate the use of Output before using it, such as by using human review.

**4.2 No Confidentiality.** Developer acknowledges and agrees that Input and Output are not considered confidential information. Developer must not submit through Loci any Input that contains confidential, proprietary, or sensitive information unless Developer has all necessary rights and accepts the risk of disclosure and use as described in this Agreement.

**4.3 Representations.** Developer represents and warrants that it has sufficient rights in the Input to submit it to the Services. This means that if Developer uploads a photograph, image, video, or likeness of any person to the Services, Developer represents and warrants that it has obtained any and all required permissions or consent necessary to submit such person's likeness to the Services.

---

## 5. Fees and Payment

**5.1 Subscription Term and Fee.** The Services are provided as subscriptions based on subscription fees ("**Subscription**"). Subscription fees are paid in advance on a weekly, monthly, or annual basis, or other alternatives displayed to you and agreed by you prior to your subscription purchase (collectively, "**Subscription Fee**"). The Subscription Fee is displayed to you prior to your purchase.

**5.2 Cancellation.** You may cancel your Subscription plan at any time through your Account or any other means Aurora provides. Should you choose to cancel your Subscription, your access to the Services will continue through the end of your billing period, as applicable, and expire thereafter.

**5.3 Refund.** To the extent permitted by applicable law, any fees paid for your purchase of a subscription plan are non-refundable, and Aurora does not provide refunds for any partial subscriptions.

**5.4 Free Trial.** Aurora may offer a free trial for premium features ("**Free Trial**") as shall be determined by Aurora in its sole discretion. The Free Trial starts when you register and is for a limited period of time, with auto-renewal unless you cancel at least 24 hours before the end of the Free Trial period.

**5.5 Changes.** Aurora reserves the right, at its own discretion, to change any features or functionalities of the Subscription. Changes may be based on various factors, including improving or managing the Services or complying with legal or technical requirements. Aurora will notify Developer of any material changes.

**5.6 Taxes.** All fees and subscription purchases are exclusive of applicable taxes, duties, or levies, which Developer is responsible for paying in accordance with applicable law.

---

## 6. Termination

**6.1 Term.** This Agreement commences on the date Developer first accesses or uses Loci and will remain in effect until terminated in accordance with this Section 6 ("**Term**").

**6.2 Termination by Aurora.** Aurora may suspend or terminate Developer's access to Loci, in whole or in part, at any time and in its sole discretion, by providing notice to Developer (including via email or through Developer's account dashboard). Without limiting the foregoing, Aurora may suspend or terminate access:

- (i) to prevent or mitigate a security risk, operational risk, or other credible risk of harm or liability to Aurora, Loci, or any third party;
- (ii) if required to do so by applicable law, regulation, or governmental authority; or
- (iii) in the event of repeated or material violations of this Agreement.

**6.3 Termination by Developer.** Developer may terminate this Agreement at any time, for any reason, by ceasing all use of Loci and deleting its Account (if applicable).

**6.4 Effect of Termination.** Upon termination of this Agreement for any reason:

- (i) all rights and licenses granted to Developer under this Agreement will immediately cease;
- (ii) Developer must stop making calls to Loci and promptly delete all keys, credentials, and related integration materials provided by Aurora;
- (iii) Developer may retain and continue to use any Output generated prior to termination, subject to this Agreement and applicable law;
- (iv) Developer remains responsible for any obligations accrued prior to termination, including payment obligations;
- (v) Aurora's license to use Input and Output shall survive termination; and
- (vi) Developer is solely responsible for downloading and securing Output prior to the effective date of termination, as Aurora makes no commitment to store or maintain such Output following termination.

**6.5 Survival.** Sections 3.1 (Sole Responsibility), 9 (Disclaimer of Warranties), 10 (Limitation of Liability), and 13 (Governing Law) shall survive termination of this Agreement.

---

## 7. Support

Aurora will use commercially reasonable efforts to maintain the availability of Loci and to provide Developer with technical support for questions or issues regarding Loci during Aurora's normal business hours and through its designated support channels. Aurora does not guarantee uninterrupted or error-free operation of Loci and shall not be responsible for providing support directly to End Users of Developer Applications.

---

## 8. Confidentiality; DPA; Intellectual Property

**8.1 Privacy.** If the Input includes personal data, such data will be processed subject to the DPA. Aurora shall process such personal data as the "processor" or "service provider," as applicable.

**8.2 Intellectual Property.** As between the parties, Aurora owns and retains all right, title, and interest in and to the Services, the Materials, and all Intellectual Property Rights therein. Developer retains ownership of Input and Output, subject to the rights granted to Aurora under this Agreement. Except for the limited rights expressly granted under this Agreement, no license, right, or interest in or to the Services or Materials is granted, conveyed, or implied.

**8.3 Feedback.** Aurora may use and exploit, without any payment or attribution obligation of any kind, any comments, feedback, suggestions, or ideas ("**Feedback**") provided by Developer, Authorized Users, End Users, or any of their respective personnel, employees, agents, or subcontractors in connection with the Agreement or the Services. Developer waives any moral and similar rights relating to Feedback that Developer may have under any applicable law.

**8.4 Open Source.** Loci may include third-party open source software that is subject to third-party terms and conditions ("**Third Party Terms**"). If there is a conflict between any Third Party Terms and the terms of this Agreement, then the Third Party Terms shall prevail, but solely in connection with the related third-party open source software.

**8.5 Confidentiality.** Each party will:

- (a) hold in strict confidence all Confidential Information of the other party, using at least the same degree of care to protect the Discloser's Confidential Information as it uses to protect its own Confidential Information of like nature, but in no event less than reasonable care;
- (b) use such Confidential Information only to exercise its rights and perform its obligations under the Agreement; and
- (c) not transfer or disclose such Confidential Information to any individual or entity except to the directors, officers, employees, agents, contractors, accountants, auditors, or legal and financial advisors of such party who need to know such Confidential Information and who are under confidentiality obligations substantially similar to those set forth herein; provided that the handling and treatment of Confidential Information by any such individual or entity will be such party's full responsibility.

A Recipient may disclose the Discloser's Confidential Information to the extent required by law, provided that the Recipient: (i) notifies the Discloser in writing prior to disclosure so that the Discloser has a reasonable opportunity to obtain a protective order; (ii) assists the Discloser, at the Discloser's expense, in any attempt to limit or prevent the disclosure; and (iii) discloses only the minimum Confidential Information actually required to be disclosed. Neither party will disclose the existence or terms and conditions of the Agreement to any third party.

---

## 9. Disclaimer of Warranties

LOCI IS PROVIDED "AS IS" AND "AS AVAILABLE." TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, AURORA DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND ANY WARRANTIES ARISING FROM COURSE OF DEALING OR USAGE OF TRADE. AURORA DOES NOT WARRANT THAT LOCI WILL BE UNINTERRUPTED, ERROR-FREE, OR COMPLETELY SECURE.

---

## 10. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, AURORA SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL, PUNITIVE, OR EXEMPLARY DAMAGES, INCLUDING BUT NOT LIMITED TO DAMAGES FOR LOSS OF PROFITS, REVENUES, DATA, GOODWILL, OR OTHER INTANGIBLE LOSSES, ARISING OUT OF OR RELATED TO DEVELOPER'S USE OF LOCI, REGARDLESS OF THE THEORY OF LIABILITY AND EVEN IF AURORA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO EVENT SHALL AURORA'S TOTAL LIABILITY EXCEED THE AMOUNTS PAID BY DEVELOPER TO AURORA FOR LOCI IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM.

NOTWITHSTANDING ANYTHING TO THE CONTRARY, AURORA PROVIDES THE BETA SERVICES "AS IS" AND "AS AVAILABLE," WITHOUT ANY WARRANTIES OR REPRESENTATIONS OF ANY KIND, WHETHER EXPRESS OR IMPLIED. TO THE MAXIMUM EXTENT PERMITTED BY LAW, AURORA DISCLAIMS ALL IMPLIED WARRANTIES, INCLUDING THOSE OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT. DEVELOPER ASSUMES ALL RISKS AND COSTS ASSOCIATED WITH USING THE BETA SERVICES. AURORA'S OBLIGATIONS TO INDEMNIFY, DEFEND, OR HOLD HARMLESS UNDER THIS AGREEMENT DO NOT APPLY TO BETA SERVICES. THE LIABILITY CAP FOR BETA SERVICES IS $0 (ZERO DOLLARS).

---

## 11. Indemnification

**11.1 Developer's Indemnity to Aurora.** Developer agrees to defend, indemnify, and hold harmless Aurora, its affiliates, and each of their respective directors, officers, employees, agents, and representatives (collectively, the "**Aurora Indemnified Parties**") from and against any and all third-party claims, demands, actions, damages, losses, liabilities, judgments, costs, and expenses (including reasonable attorneys' fees) arising out of or in connection with:

- (i) Developer Application, products, or services that integrate or interact with Loci;
- (ii) any data, content, including Inputs or Outputs, or materials Developer or End Users input, upload, or otherwise provide through or in connection with Loci;
- (iii) Developer's use of Loci or Loci Documentation in violation of this Agreement, applicable laws, or third-party rights;
- (iv) any combination of Loci with products, services, or software not provided by Aurora; or
- (v) any breach or alleged breach by Developer of this Agreement.

**11.2** Aurora may, at its option, participate in the defense and settlement of any such claim with its own counsel and at its own expense. Developer shall not settle any claim without Aurora's prior written consent if the settlement requires Aurora to take or refrain from taking any action, admit liability, or incur any obligation.

---

## 12. Changes to These Loci Terms

**12.1 Modifications.** Aurora may update or modify this Agreement from time to time. Material changes will be communicated through Developer's account dashboard, email notification, or posting on the Aurora website. Developer's continued use of Loci after any changes constitutes acceptance of the revised Loci Terms. If Developer does not agree to the changes, it must discontinue use of Loci.

**12.2 Modifications to Loci.** Aurora reserves the right, in its sole discretion, to modify, update, enhance, or discontinue Loci at any time, including without limitation its level of access, content, functionality, performance specifications, or availability. While Aurora will endeavor to provide reasonable notice of material changes to Loci, Developer acknowledges that some changes may be implemented immediately without prior notice, particularly those related to security, legal compliance, or system stability. Developer is responsible for regularly reviewing the Loci Documentation and implementing necessary updates to ensure continued compatibility and functionality of its Developer Applications.

---

## 13. Governing Law

This Agreement shall be governed by and construed in accordance with the laws of the State of Israel, without regard to its conflict of law provisions. Disputes shall be subject to the exclusive jurisdiction of the courts of Tel Aviv, Israel.

---

## 14. General Provisions

**14.1 Entire Agreement.** This Agreement, together with the Loci Documentation and any referenced policies, constitutes the entire agreement between Developer and Aurora regarding Loci.

**14.2 Independent Contractors.** The parties are independent contractors. Nothing in this Agreement shall be construed to create a partnership, joint venture, agency, or employment relationship between the parties. Neither party has authority to bind the other.

**14.3 Severability.** If any provision of this Agreement is found to be unenforceable, the remaining provisions shall remain in full force and effect.

**14.4 No Waiver.** Aurora's failure to enforce any provision of this Agreement shall not constitute a waiver of such provision or any other provision.

**14.5 Assignment.** Developer may not assign this Agreement without Aurora's prior written consent. Aurora may assign this Agreement without restriction.

---

## 15. Contact Information

If you have questions about this Agreement, please contact us at legal@auroralabs.com.
