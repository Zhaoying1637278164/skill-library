<!-- ai-coding-ok: v4.1.0 -->
# ⛔ STOP — CALL Skill("ai-coding-ok") BEFORE ANY CODE WORK. THEN CALL Skill("ai-coding-ok") AFTER ALL WORK. THIS IS NON-NEGOTIABLE.

@AGENTS.md
