---
name: sentinel-driven-review
description: Use when reviewing code in a project with Decibel MCP tools — escalates findings to sentinel issues when they need tracking
---

# Sentinel-Driven Review

Extends code review with sentinel escalation for findings that need tracking beyond the current review session.

## During Review

Not every finding needs a sentinel issue. Apply this rule:

- **Findings fixed immediately** — no sentinel issue needed. Fix inline and move on.
- **Findings that need follow-up work** — create a sentinel issue with severity, file path, line number, and description. This ensures the finding is not lost.
- **Architectural concerns** — create an ADR proposal via the `architect` tool. Flag it as "proposed" status so it can be reviewed and accepted separately.
- **Review artifact format** — if `@decibelsystems/peers` review artifacts are available, structure findings in the expected format for consistency across reviews.

## After Review

- The review summary references created sentinel issue IDs so the author can find and address them.
- The reviewer (or author) can verify resolution in a follow-up session by checking issue status.

## Graceful Degradation

If Decibel MCP tools are not available, log an INFO message:

> Sentinel tools unavailable — proceeding with standard review.

Continue with standard code review practices. Do not block the workflow.
