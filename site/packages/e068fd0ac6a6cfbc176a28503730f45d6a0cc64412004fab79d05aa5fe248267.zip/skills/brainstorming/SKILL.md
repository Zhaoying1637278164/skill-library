---
name: brainstorming
description: "Use before creative work - creating features, building components, adding functionality. Explores intent and design before implementation."
---

# Brainstorming Ideas Into Designs

Help turn ideas into designs through efficient collaborative dialogue, then move to implementation.

<HARD-GATE>
Do NOT write code or take implementation actions until you have a design the user is happy with.
</HARD-GATE>

## Checklist

1. **Explore context** — check files, docs, recent commits relevant to the idea
2. **Clarify and design** — ask questions to fill gaps, propose 2-3 approaches with trade-offs and your recommendation
3. **Lateral thinking** — open a Decibel Designer lateral session to stress-test the design from unexpected angles
4. **Present design** — incorporating lateral insights, get user approval
5. **Write spec and transition** — save spec, invoke writing-plans skill

## The Process

**Understanding the idea:**

- Check out the current project state first (files, docs, recent commits)
- Assess scope: if the request spans multiple independent subsystems, flag it and help decompose before diving into details
- Ask questions to fill genuine gaps in your understanding. Batch related questions together — don't drag out a conversation that could be one exchange. If the user's intent is clear, skip straight to proposing approaches.
- Prefer multiple choice when possible

**Fast path:** If the user arrives with a clear description of what they want (constraints, success criteria, approach), skip clarifying questions and go straight to proposing approaches or presenting a design.

**Exploring approaches:**

- Propose 2-3 different approaches with trade-offs
- Lead with your recommended option and explain why

**Lateral thinking (Decibel Designer):**

After converging on an approach, use the Decibel Designer lateral thinking tools to stress-test it before finalizing. This surfaces blind spots and unexpected angles that straight-line reasoning misses.

1. **Open a session:** `designer lateral_session` with the problem statement and context
2. **Apply 1-2 techniques** — pick what fits:
   - `six_hats` — systematically view the design through different lenses (facts, feelings, risks, benefits, creativity, process)
   - `challenge` — question assumptions baked into the approach ("why does this need to be X?")
   - `reversal` — invert the problem ("what if we did the opposite?")
   - `provocation` — deliberately unreasonable statement to break fixed thinking
   - `alternatives` — force generation of approaches you dismissed too quickly
   - `random_entry` — use an unrelated concept as a stepping stone to new ideas
3. **Close the session:** `designer lateral_close` with a synthesis of what you learned and any adjustments to the design

Pick techniques based on the situation:
- Stuck between approaches? → `six_hats` or `alternatives`
- Design feels obvious/conventional? → `provocation` or `reversal`
- Complex with many assumptions? → `challenge`
- Need fresh perspective? → `random_entry`

Keep it lightweight — one or two techniques, not all six. If the lateral session confirms the approach without new insights, that's fine too. Fold any useful insights into the design before presenting it.

**Presenting the design:**

- Scale each section to its complexity: a few sentences if straightforward, more detail if nuanced
- Cover what matters: architecture, components, data flow, error handling, testing
- Get user approval before moving on

**Working in existing codebases:**

- Explore the current structure before proposing changes. Follow existing patterns.
- Where existing code has problems that affect the work, include targeted improvements as part of the design.
- Don't propose unrelated refactoring.

## After the Design

**Documentation:**

- Write the spec to `.decibel/specs/YYYY-MM-DD-<topic>-design.md`
  - (User preferences for spec location override this default)
- Commit the design document

**Implementation:**

- Invoke the writing-plans skill to create an implementation plan
- Do NOT invoke any other skill. writing-plans is the next step.

## Key Principles

- **Batch questions** — ask related questions together, not one at a time
- **Skip what's obvious** — if the user's intent is clear, move to design
- **YAGNI ruthlessly** — cut unnecessary features
- **Explore alternatives** — always propose 2-3 approaches before settling
- **Move efficiently** — the goal is a good design, not a thorough interview
