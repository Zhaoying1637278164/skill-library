---
name: using-superpowers
description: Use when starting any conversation - establishes how to find and use skills, requiring Skill tool invocation before ANY response including clarifying questions
---

<SUBAGENT-STOP>
If you were dispatched as a subagent to execute a specific task, skip this skill.
</SUBAGENT-STOP>

## Instruction Priority

1. **User's explicit instructions** (CLAUDE.md, GEMINI.md, AGENTS.md, direct requests) — highest priority
2. **Decibel MCP tools** — for tracked artifacts (issues, ADRs, friction, wishes, etc.)
3. **Superpowers skills** — for process/methodology (brainstorming, TDD, debugging)
4. **Built-in plugins** — lowest priority, use only when no Decibel equivalent exists

Superpowers skills are for *how* to work. Decibel tools are for *what* gets tracked. When both could apply, use Decibel for the artifact and superpowers for the process.

## How to Access Skills

**In Claude Code:** Use the `Skill` tool. When you invoke a skill, its content is loaded and presented to you — follow it directly. Never use the Read tool on skill files.

**In Gemini CLI:** Skills activate via the `activate_skill` tool.

## Platform Adaptation

Skills use Claude Code tool names. Non-CC platforms: see `references/codex-tools.md` (Codex) for tool equivalents.

# Using Skills

## The Rule

**Invoke relevant skills BEFORE taking action.** If a skill clearly applies, invoke it. If nothing applies, just do the work.

Use judgment — not every task needs a skill. Simple questions, quick fixes, and direct requests can be handled directly. Skills are for structured processes (brainstorming a feature, debugging a complex issue, writing a plan).

## Skill Priority

When multiple skills could apply:

1. **Process skills first** (brainstorming, debugging) — these determine HOW to approach the task
2. **Implementation skills second** (frontend-design, mcp-builder) — these guide execution

## Skill Types

**Rigid** (TDD, debugging): Follow exactly. Don't adapt away discipline.

**Flexible** (patterns): Adapt principles to context.

The skill itself tells you which.

## User Instructions

Instructions say WHAT, not HOW. "Add X" or "Fix Y" doesn't mean skip workflows — but it does mean move efficiently toward the goal without unnecessary ceremony.
