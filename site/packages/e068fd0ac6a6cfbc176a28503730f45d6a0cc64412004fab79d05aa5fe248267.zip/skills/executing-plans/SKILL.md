---
name: executing-plans
description: Use when you have a written implementation plan to execute in a separate session with review checkpoints
---

# Executing Plans

## Overview

Load plan, review it, execute all tasks, report when complete.

**Announce at start:** "I'm using the executing-plans skill to implement this plan."

## The Process

### Step 1: Load and Review Plan
1. Read plan file
2. Review critically — identify any genuine blockers or contradictions
3. If there are real blockers: raise them before starting
4. If the plan is sound: create tasks and proceed

### Step 2: Execute Tasks

For each task:
1. Mark as in_progress
2. Follow each step exactly (plan has bite-sized steps)
3. Run verifications as specified
4. Mark as completed

Execute confidently. Don't stop to ask questions unless you hit a genuine blocker — something that would produce wrong code if you guessed.

### Step 3: Complete Development

After all tasks complete and verified:
- Use superpowers:finishing-a-development-branch to wrap up
- Follow that skill to verify tests, present options, execute choice

## When to Stop

**STOP only when:**
- A dependency is genuinely missing and you can't proceed
- Tests fail in a way that indicates the plan is wrong (not just a typo)
- An instruction is ambiguous AND getting it wrong would be costly to undo

**Don't stop for:**
- Minor uncertainties you can resolve by reading the code
- Style questions — follow existing patterns
- Things you can try and verify with a test

## Remember
- Review plan critically first
- Follow plan steps exactly
- Don't skip verifications
- Execute with confidence — stop only on real blockers
- Never start implementation on main/master branch without explicit user consent

## Integration

**Related skills:**
- **superpowers:using-git-worktrees** — for isolated workspace setup
- **superpowers:writing-plans** — creates the plan this skill executes
- **superpowers:finishing-a-development-branch** — complete development after all tasks
