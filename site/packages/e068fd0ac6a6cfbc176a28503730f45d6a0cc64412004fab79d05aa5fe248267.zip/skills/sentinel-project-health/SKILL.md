---
name: sentinel-project-health
description: Use when verifying work is complete in a Decibel project — checks sentinel for open issues, stale ADRs, and design debt before claiming done
---

# Sentinel Project Health

Quick project health check before claiming work is complete. Surfaces forgotten items, stale decisions, and misalignment with the roadmap.

## Checks

1. **Open sentinel issues** related to the current work area — are there unresolved bugs or tasks?
2. **Stale ADRs** that may need updating given recent changes — has the architecture shifted without updating the decision record?
3. **Open design-review issues** — if `@decibelsystems/peers` review artifacts exist, check for unresolved review findings.
4. **Roadmap alignment** — does the completed work match what was planned? Are there planned items that were skipped?

## Surface During

- **verification-before-completion** — are there forgotten open items before claiming done?
- **brainstorming** — what is the current project state before starting new work?
- **planning** — what existing issues should be addressed in this plan?

## Graceful Degradation

If Decibel MCP tools are not available, log an INFO message:

> Sentinel tools unavailable — skipping project health check.

Proceed with standard verification. Do not block the workflow.
