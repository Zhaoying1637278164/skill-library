---
name: sentinel-driven-planning
description: Use when brainstorming or planning work in a project with Decibel MCP tools — creates sentinel issues, ADRs, and epics from design decisions
---

# Sentinel-Driven Planning

Extends the brainstorming and planning workflow with sentinel tracking so that design decisions, work items, and multi-session efforts are captured as first-class project artifacts.

## During Brainstorming

As design conversations produce concrete decisions and work items, capture them immediately:

- **Architectural decisions** — create an ADR via the `architect` tool. Include context, decision, consequences, and status.
- **Scoped work items** — create sentinel issues for each discrete deliverable identified during brainstorming. Keep titles action-oriented (e.g., "Add rate limiting to /chat endpoint").
- **Multi-session efforts** — if the work spans multiple sessions or has multiple sub-tasks, create an epic via the `sentinel` tool and link child issues to it.
- **Roadmap placement** — place new work on the project roadmap via the `roadmap` tool so it is visible alongside existing planned work.

## During Planning

When writing implementation plans, integrate sentinel tracking into each step:

- Each plan step that produces a deliverable gets a sentinel issue with clear acceptance criteria.
- Dependencies between steps get linked issues so blockers are visible.
- The plan document itself references sentinel issue IDs for traceability.
- If a step modifies architecture, reference or create the relevant ADR.

## Integration Hook

If `@decibelsystems/peers` is installed and a design peer is available, route design decisions through `lateral_session` before committing ADRs. This gives a second perspective on architectural choices before they are recorded.

## Graceful Degradation

If Decibel MCP tools are not available (e.g., `sentinel`, `architect`, `roadmap` calls fail or are not registered), log an INFO message:

> Sentinel tools unavailable — planning without issue tracking. Install @decibelsystems/tools for full tracking.

Fall back to standard superpowers planning (markdown only). Do not block the workflow.
