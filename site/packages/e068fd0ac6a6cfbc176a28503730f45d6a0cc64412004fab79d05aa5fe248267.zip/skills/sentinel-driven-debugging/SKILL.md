---
name: sentinel-driven-debugging
description: Use when debugging in a project with Decibel MCP tools — tracks bugs as sentinel issues with reproduction steps and resolution
---

# Sentinel-Driven Debugging

Extends systematic debugging with sentinel issue lifecycle so that bugs are tracked from discovery through resolution.

## On Bug Discovery

When a bug is identified, create a sentinel issue immediately with:

- **Title** — concise, action-oriented (e.g., "Memory bleedover between agents sharing episodic store")
- **Reproduction steps** — numbered steps to reproduce the behavior
- **Observed vs expected behavior** — what happens vs what should happen
- **Severity** — critical, high, medium, low
- **Domain tags** — tag with the relevant area (e.g., "transport", "memory", "security", "routing")
- **Related issues** — if the pattern matches existing bugs, link them

## During Investigation

As you investigate, keep the sentinel issue updated:

- Add findings and hypotheses as you narrow down the root cause.
- If the root cause reveals an architectural concern, create an ADR via the `architect` tool documenting the design issue and proposed resolution.
- If a pattern is detected across multiple bugs (e.g., all relate to the same subsystem), create a parent epic and link the individual bug issues to it.

## On Fix

When the fix is implemented and verified:

- Update the sentinel issue with the resolution: what changed, why, and what the root cause was.
- Close the issue.
- If the fix reveals a reusable pattern or lesson, record it via the `learnings` tool so future debugging benefits from the knowledge.

## Graceful Degradation

If Decibel MCP tools are not available (e.g., `sentinel`, `architect`, `learnings` calls fail or are not registered), log an INFO message:

> Sentinel tools unavailable — debugging without issue tracking.

Fall back to standard systematic debugging. Do not block the workflow.
