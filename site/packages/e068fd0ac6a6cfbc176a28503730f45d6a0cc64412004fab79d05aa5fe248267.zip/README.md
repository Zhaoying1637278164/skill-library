# @decibelsystems/superpowers

A Decibel Systems remix of [superpowers](https://github.com/obra/superpowers) by Jesse Vincent.

## What's Different

- **Sentinel-powered project tracking** — brainstorming, debugging, and review automatically create sentinel issues, ADRs, and epics when Decibel MCP tools are available.
- **Reduced ceremony** — streamlined for Decibel's MCP-first workflow. Tools do the tracking so you don't have to.
- **Lateral thinking integration** — design decisions can route through `@decibelsystems/peers` for a second perspective before committing.
- **Graceful degradation** — all sentinel skills fall back cleanly when MCP tools are unavailable.

## New Skills

| Skill | Description |
|-------|-------------|
| **sentinel-driven-planning** | Creates sentinel issues, ADRs, and epics from brainstorming and planning sessions |
| **sentinel-driven-debugging** | Tracks bugs as sentinel issues with reproduction steps, investigation notes, and resolution |
| **sentinel-driven-review** | Escalates code review findings to sentinel issues when they need follow-up |
| **sentinel-project-health** | Checks for open issues, stale ADRs, and roadmap alignment before claiming done |

## Upstream Skills

All 14 original superpowers skills are included unmodified:

brainstorming, dispatching-parallel-agents, executing-plans, finishing-a-development-branch, receiving-code-review, requesting-code-review, subagent-driven-development, systematic-debugging, test-driven-development, using-git-worktrees, using-superpowers, verification-before-completion, writing-plans, writing-skills

## Installation

### Claude Code

```bash
/plugin install superpowers@decibelsystems-superpowers
```

Or register the marketplace first:

```bash
/plugin marketplace add decibelsystems/marketplace
/plugin install superpowers@decibelsystems-superpowers
```

### Manual

Clone to your plugins directory:

```bash
git clone https://github.com/decibelsystems/superpowers.git ~/.claude/plugins/data/superpowers-decibel
```

## Philosophy

Superpowers gives your workflow optional juice. Sentinel integration makes your planning, debugging, and review project-aware. When Decibel MCP tools are present, every design decision, bug, and review finding becomes a tracked artifact. When they aren't, everything works exactly like upstream superpowers.

## Credits

Built on [superpowers](https://github.com/obra/superpowers) by Jesse Vincent. MIT license.

## License

MIT
