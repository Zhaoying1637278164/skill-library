# {{PROJECT_NAME}}

**{{TAGLINE}}**

<!-- TODO(scaffold): if this repo has a GitHub remote, insert a CI badge line ABOVE the bold
tagline (standard-readme puts badges between the title and the short description):
[![CI](https://github.com/<owner>/<repo>/actions/workflows/<file>/badge.svg)](https://github.com/<owner>/<repo>/actions/workflows/<file>)
with the REAL owner/repo from `git remote get-url origin` and the REAL workflow filename the
scaffold installed (test.yml or repo-standard.yml), never a guessed slug. If the repo has no
remote, delete this comment: a badge pointing nowhere is a fabricated claim. -->

<!-- TODO(scaffold): one short paragraph expanding the tagline: what this is, who it is for,
and the one-sentence reason it exists. Grounded in the real code, never aspirational. -->

## Table of Contents

- [Background](#background)
- [Install](#install)
- [Usage](#usage)
- [Caveats](#caveats)
- [Contributing](#contributing)
- [License](#license)

## Background

<!-- TODO(scaffold): the context a newcomer needs: the problem, why existing tools don't solve
it, and any prior art this builds on. Delete the section only if the tagline truly says it all,
AND delete its Table of Contents entry in the same edit: no check resolves a Contents anchor, so
a link left pointing at a deleted section stays green forever. -->

## Install

<!-- TODO(scaffold): real, copy-pasteable install steps for THIS repo (package manager command,
clone + build, or plugin install). If there is genuinely nothing to install, say so and say why. -->

```bash
{{INSTALL_COMMAND}}
```

## Usage

<!-- TODO(scaffold): the smallest real end-to-end example: a command and what it prints, or an
API call and what it returns. Taken from the actual entry points, never invented. -->

```bash
{{USAGE_COMMAND}}
```

## Caveats

<!-- TODO(scaffold): what this project does NOT do, where it is immature, and the sharp edges a
user will hit. An honest limits section is part of the standard, not an apology. -->

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Contributors are expected to follow the
[Code of Conduct](CODE_OF_CONDUCT.md).

## License

[{{LICENSE_ID}}](LICENSE) © {{LICENSE_HOLDER}}
