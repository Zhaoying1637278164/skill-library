# payload/templates/

**The standards-grounded documents the scaffold journey fills and writes into a governed repo.**
Every filename here is its destination: `CHANGELOG.md` is written out as the target repo's
`CHANGELOG.md`. The two `LICENSE-*.txt` files are the exception; both fill to `LICENSE`, and the
operator's answer picks one.

Each file carries `{{TOKEN}}` placeholders that `harness/fill-template.mjs` resolves, and HTML
comments marked `TODO(scaffold)` that the agent replaces with prose read out of the real repo.
The shipped lint reddens on either surviving, so a half-written scaffold cannot pass CI while
looking finished. `acceptance/test-templates-lint-green.mjs` fills every file below the way the
skill fills it and runs the shipped gate over the result: a template that drifts out of
compliance with the lint it ships beside fails the build here, not in someone else's repo.

This catalog is `INDEX.md` rather than the usual `README.md` because `README.md` in this
directory is the README template, and it has a row of its own below.

Reconciled against the code: 2026-07-31 (agent sweep)

| File | What it is for | Status |
|---|---|---|
| [`CHANGELOG.md`](CHANGELOG.md) | The [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) skeleton the scaffold writes into a repo with no tags yet: a maintenance rule naming the six canonical categories and the release ritual, then a lone `[Unreleased]` section. Takes `{{PROJECT_NAME}}` and `{{FIRST_CHANGELOG_ENTRY}}`, carries no `TODO(scaffold)` marker, and ships with no dated section on purpose, because a version heading corresponds to a real tag. | `active` |
| [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md) | [Contributor Covenant 3.0](https://www.contributor-covenant.org/version/3/0/), reproduced with the upstream section order and wording intact: pledge, encouraged and restricted behaviors, private reporting, the four-rung enforcement ladder, scope, attribution. Its one token is `{{COC_CONTACT}}`. This is the file this repo exempts from its own writing profile, with the reason recorded in `.repo-standard.json`. | `active` |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | The contributor's short path: a Node 18+ prerequisite, the one shell loop over `acceptance/test-*.mjs` that sets the merge bar, what a complete changeset carries, and the conventional-commit rule. Takes `{{PROJECT_NAME}}`, `{{DEFAULT_BRANCH}}` and `{{LICENSE_ID}}`, with two `TODO(scaffold)` markers for the real toolchain and project quality rules. | `active` |
| [`CONVENTIONS.md`](CONVENTIONS.md) | The numbered house rules, citable as §N in review, whose §5 restates in prose the front-matter standard the shipped lint enforces. That pairing is what `RS-reflexivity` checks: config cannot grow a rule the written standard does not carry. Ships §1 to §5 with `{{PROJECT_NAME}}` and two `TODO(scaffold)` markers, for project scope and repository layout. | `active` |
| [`LICENSE-Apache-2.0.txt`](LICENSE-Apache-2.0.txt) | The Apache License 2.0, byte-identical to the canonical apache.org text through END OF TERMS AND CONDITIONS, with the instructional appendix dropped so the file closes on the notice block applied for real: `Copyright {{YEAR}} {{LICENSE_HOLDER}}`. Hardcoding an attribution here would stamp someone else's name into every repo this scaffolds. | `active` |
| [`LICENSE-MIT.txt`](LICENSE-MIT.txt) | The MIT License, the permissive alternative, matching the SPDX reference text apart from line wrapping and its two tokens, `{{YEAR}}` and `{{LICENSE_HOLDER}}`. Fills to `LICENSE` when the operator picks MIT; the `MIT License` title line is what the shipped lint reads to tell it apart from MIT-0, which drops the notice condition and otherwise reads identically. | `active` |
| [`README.md`](README.md) | The target repo's front page in [standard-readme](https://github.com/RichardLitt/standard-readme) order: one H1, the bold `{{TAGLINE}}` under it, then Background, Install, Usage, Caveats, Contributing, and License last. Also takes `{{PROJECT_NAME}}`, `{{INSTALL_COMMAND}}`, `{{USAGE_COMMAND}}`, `{{LICENSE_ID}}` and `{{LICENSE_HOLDER}}`, and carries six `TODO(scaffold)` markers, one per section the agent writes from the real code. | `active` |
| [`SECURITY.md`](SECURITY.md) | The private-disclosure policy for `{{PROJECT_NAME}}`: what is in scope, the `{{SECURITY_CONTACT}}` email channel, what a report should contain, and the no-backport rule that fixes land on `{{DEFAULT_BRANCH}}`. Three `TODO(scaffold)` markers hold what it refuses to invent: excluded targets, the GitHub advisory bullet, and response-time targets. | `active` |

**One limit this directory knows about.** The README template's Table of Contents hardcodes a
Background entry whose own `TODO(scaffold)` invites deleting the section, which would leave a link
resolving to nothing: `RS-readme` checks the canon sections and their order, never whether a
Contents anchor resolves.

The limit that used to sit beside it is closed. The standing test still fills a hardcoded list of
templates, and `TG0` now holds that list against this directory in both directions, so a template
added tomorrow fails the build until a case fills it or an exclusion names the reason.
