# [![payload/: The product · everything installed into a governed repo](../.github/assets/banners/payload.svg)](https://github.com/runverdict/repo-standard-toolkit)

**Everything in this directory is installed into someone else's repository.** That is the whole
distinction: the rest of the plugin runs once, with an agent present, and then leaves. What
lives here keeps running afterwards, on every push, with `node` alone.

Two rules follow from that, and they are not negotiable:

- **Zero dependencies, forever.** Every file here imports `node:` built-ins or nothing at all.
  A target repo inherits whatever this directory carries, and it never agreed to a supply chain.
- **Installed verbatim, never hand-edited into a target.** Repo-specific scope belongs in
  `.repo-standard.json`. A forked copy stops being upgradeable, and the version constant each
  file carries is what lets a re-run tell an upgrade from a downgrade.

Every row below describes what the file does **once it lands**, not what it does here.
[`templates/`](templates/INDEX.md) keeps its own catalog and is not repeated in this one.

Reconciled against the code: 2026-07-31 (agent sweep)

| File | What it is for | Status |
|---|---|---|
| [`acceptance/test-repo-standard.mjs`](acceptance/test-repo-standard.mjs) | Runs as the target repo's committed hygiene gate on `node` built-ins alone, exiting 2 on a broken `.repo-standard.json` and 1 on doc drift. Its `RS-` checks cover Keep a Changelog shape, standard-readme structure, numbered CONVENTIONS, the voice and prose bans, count claims, licence agreement, shadowed docs, index coverage, asset re-render drift, and the ignore ruleset. It refuses to run at all when its own invocation path is a symlink or sits in a different repository from the file that is running, because either one means the verdict would be about a tree nobody asked about. | `active` |
| [`assets/generate.mjs`](assets/generate.mjs) | Renders every banner and pill SVG from the `manifest.json` beside it with `node` built-ins alone: same manifest in, identical bytes out. Writing happens only when it is run directly, so the lint can import `render`, `bannerH1` and `readmeBlock` to re-derive both the artwork and the README block it sits in. Arguments are parsed strictly, so a typo is an exit 2 rather than an unasked-for write; `--check` previews the engine's own replacement, the artwork, the deletions, the generated markdown against the front page the target's own config declares, and any README left heading a banner the manifest no longer produces, and writes nothing. The assets directory has to sit inside the repo it renders for, and every path it reads or writes has to be a regular file at the path it is named by. | `active` |
| [`assets/manifest.example.json`](assets/manifest.example.json) | A documented example of the `.github/assets/manifest.json` a governed repo writes: brand plus the fifteen-role palette, the token each derived role was read from, pills carrying the file every value is re-verified against and the optional link each one points at, folder banners, and third-party live badges. | `active` |
| [`assets/palettes/forest.json`](assets/palettes/forest.json) | A ready-made palette preset: all fifteen roles as hex, a deep desaturated forest ground under emerald and gold accents. Its `palette` object is copied into the repo's manifest, where each role is read by the job it does in the artwork rather than by its colour. | `active` |
| [`assets/palettes/slate.json`](assets/palettes/slate.json) | A ready-made palette preset: all fifteen roles as hex, a neutral slate ground under sky and amber accents. The brand-agnostic choice for a repo with no design identity of its own to derive colours from, and the one the standing tests render against. | `active` |
| [`assets/palettes/violet.json`](assets/palettes/violet.json) | A ready-made palette preset: all fifteen roles as hex, a deep violet ground under iris and amber accents. Structurally identical to the other two presets, which is the point: one fixed geometry, different brand inputs, a different identity. | `active` |
| [`hooks/pre-push`](hooks/pre-push) | Runs the installed lint before every `git push` from `.git/hooks/pre-push`, and nothing else. It exits 0 when the lint or `node` is absent, separates a broken config from drifted front matter, and names `--no-verify` as the way past. Local convenience, never the gate, which is why it is installed uncommitted. | `active` |
| [`ignore/repo-standard.gitignore`](ignore/repo-standard.gitignore) | The trust ruleset merged into the target's `.gitignore`: the whole `.env` family with only `.env.example` negated back, private keys and credential bundles, then build output, caches, logs and editor noise. `RS-ignore` holds the secrets leg forever, reading rules rather than file contents. | `active` |
| [`repo-standard.json`](repo-standard.json) | The scope config, landing as `.repo-standard.json` with every key documented inline as a `//` comment. It tunes which docs, counts, sections and paths the lint sweeps, never the canon; these shipped defaults are stricter than the lint's built-ins, and an unknown key is an exit-2 error rather than a silent no-op. | `active` |
| [`rulesets/repo-standard.json`](rulesets/repo-standard.json) | The GitHub branch ruleset POSTed to make the gate binding on the default branch: no deletion, no force-push, a pull request with zero required approvals, and the `test` check pinned to an app id under a strict up-to-date policy. Ships with enforcement disabled, so activating it is the operator's deliberate act. | `active` |
| [`workflows/repo-standard-scoped.yml`](workflows/repo-standard-scoped.yml) | The stopgap CI gate for a repo whose pre-existing tests were already red: the same read-only token, SHA-pinned checkout and push / pull_request / merge_group triggers as the full gate, but one step that runs only `acceptance/test-repo-standard.mjs`. | `active` |
| [`workflows/repo-standard.yml`](workflows/repo-standard.yml) | The full CI gate, installed as `.github/workflows/test.yml`: a `contents: read` token, a SHA-pinned checkout, no setup-node, and one step running every `acceptance/test-*.mjs` on the runner's own Node. Its job id `test` is the context the branch ruleset requires. | `active` |

`hooks/pre-push` has no file extension, and for a while that meant no rule could require a row for
it: the row above was written anyway, because a reader of this directory needs to know what the
file is, and it sat there unenforced. This index now declares `"extensions": ["*"]`, so every kept
file under `payload/` owes a row and the enforcement matches what the index already owed. The gap
was not hypothetical, and it is the reason the selector exists: an extension list cannot reach a
`Dockerfile`, a `Makefile`, or a shell hook, so a directory catalogued by one is covered exactly
as far as that list goes.

Changing anything here is at least a **minor** version bump: governed repos upgrade by re-running
the scaffold skill, and their diff should correspond to a version they can point at.

See [CONVENTIONS.md](../CONVENTIONS.md) §3 for the payload rules in full, and
[docs/enforcement.md](../docs/enforcement.md) for what each installed file does once it lands.
