# Changelog

All notable changes to **repo-standard-toolkit** are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versions follow
[semantic versioning](https://semver.org/).

Maintenance rule: every user-facing change lands an entry under `[Unreleased]` in the matching
category. Cutting a tag renames `[Unreleased]` to the version + date, bumps
`.claude-plugin/plugin.json` together with every payload version constant
(`REPO_STANDARD_LINT_VERSION` in the lint, `REPO_STANDARD_ASSETS_VERSION` in the generator) in
the same commit, and opens a fresh `[Unreleased]`. Standing tests lock the whole set, because a
constant that lags the release misdirects every governed repo's next re-run. A pulled release
keeps its section, tagged `[YANKED]` after the date.

## [Unreleased]

## [0.8.0] - 2026-08-05

An audit of the atlas pillar's first run against a real repository found that the run's most
useful outcome, converting a `docs/INDEX.md` into the `docs/README.md` a reader actually lands on,
was never offered. It was not an agent's oversight: nothing in the toolkit could express the
opportunity, price a directory that kept no index yet, or distinguish an index that was complete
from one that was true. This closes those gaps and hardens the rules the audit had to verify by
hand.

### Added

- **`RS-index (universe)`, a check on the SET every coverage rule is a statement about.** All
  three engines listed git's output as a UTF-8 string and dropped every path whose `lstat` failed,
  which quietly excused two kinds of tracked file: a sparse or skip-worktree entry (tracked, in
  HEAD, deliberately not materialised) and a filename whose bytes are not valid UTF-8 (decoded to
  U+FFFD, matching nothing on disk). Both are false greens over a SMALLER repository than the one
  git tracks: an uncatalogued file went from a red build to a green one by being hidden from the
  worktree. The listing is now read as BYTES and split on the NUL byte; a gitlink is identified
  from the index (mode 160000) rather than guessed from disk; and everything else git tracks that
  is not on disk is NAMED and fails. The gate, the planner and sense-state each carry their own
  copy of this rule, twinned line for line and held together by the differential tests: the lint
  ships into a target repository as one self-contained file, so it can import nothing, and
  "shared" here means kept identical by a check rather than by a module.
- **`--assets-dir` and `--repo` on the asset generator, so an upgrade can be planned without being
  performed.** Finding out what a new generator would do to an old target previously required
  copying it over the old one first, which is the write `--check` exists to preview; and a
  generator predating `--check` ignores the flag and writes, so a scaffold planning an upgrade
  through the installed generator carried the upgrade out to preview it. The flags shipped here;
  the scaffold journey that had to USE them still told the agent to run
  `node <assets.dir>/generate.mjs --check`, so on a real target the defect was unchanged. The
  journey is corrected in 0.8.0's fourth pass, below, and that is what closes this.
- **`offer-strict` and `offer-coverage`, two plan actions an adopted atlas can still return.**
  `strictAvailable` was computed, printed, and routed nowhere, so a repository with every row
  written and every directory decided reported `keep`, the scaffold read that as finished, and the
  one setting that turns this pillar from a description into a check was reachable only by
  invoking Atlas by hand for some other reason. `offer-strict` is the one-line config offer;
  `offer-coverage` is the state where nothing structural is left and unowned files still stand
  between the repository and strict. `ATLAS_STRICT_OFFER: declined` is the durable no.
- **The directory model is recorded rather than implied.** `scope` on an index declaration is
  `"direct"` (this index owns the files directly in its directory, and a nested directory keeps
  its own catalog) or `"recursive"` (the default, because it is what every configuration written
  before this key already means). Either way **ownership is per file: a file's owner is the
  deepest declaration that actually claims it**, derived from the declarations rather than from
  the filesystem. A declared child bounds its ancestor over the files that child CLAIMS. This
  repo's own `payload/README.md` had to hand-write an `ignore` entry restating exactly that; the
  entry is gone and the coverage is identical.
- **`ordered`, off until declared and printing a named skip while off.** With it on, rows sit in
  ascending path order, which is the only order a later sweep reproduces. Without it the next run
  over a directory produces a rewrite instead of a diff, burying the one row that changed among a
  hundred that did not.
- **`docs.declined`, a per-directory no that survives the session.** `{ dir, why }`, with the
  reason required, printed as a named skip on every run. The only durable decline available before
  this was the repo-wide `ATLAS_OFFER`, which is terminal: one small excluded directory left a
  whole repository sensing `offer` forever, and silencing that meant silencing the candidates that
  mattered too.
- **`docs.ownership`, the mode in which the pillar's own promise is a check.** The default
  `"declared"` is what every configuration written before this key already means: an index is held
  to the files its own declaration reaches, and a `Dockerfile` beside an index declared over `.mjs`
  is a named skip rather than a failure, because an extension list is the operator's answer and
  reddening it would impose a scope nobody gave. `"strict"` makes the undecided set the verdict.
  Every kept file under a declared index owes exactly one owner, an `ignore` entry, or a
  `docs.declined` record, and every directory holding kept files that no declaration reaches fails
  until somebody answers for it. It is opt-in because adopting it is a migration rather than a fix,
  and this repository now runs under it. Documented in
  [Atlas](docs/atlas.md#what-the-lint-holds-and-what-it-cannot): the sentence "a file added
  tomorrow reddens the build" was written as unconditional and is true only under this mode.
- **The gate can see a directory nobody has decided about.** The unowned scan was scoped to what
  sits inside a declared index's directory, so a whole new top-level directory of kept source was
  reported by the planner as structural work and mentioned by the committed lint nowhere at all:
  the one engine an adopter's CI actually runs was the one that could not see it. It is now named
  in a skip under `declared` and failed under `strict`.
- **The planner prices a directory that keeps no index yet.** `--candidate <dir>` with optional
  `--index-file`, `--extensions`, and `--scope` returns the exact paths, lines, bytes, unreadable
  files, oversized files, and agents. Candidate listings now carry lines and bytes per extension.
  Producing that number previously meant re-implementing the planner in shell, which arrived at a
  different total by a different counting rule, so the line rule is now stated in the output.
- **Migration opportunities.** An index that is not the page GitHub renders on arrival, where the
  README slot is free, is reported with its whole coordinated change set: the `git mv`, the
  declaration, the `docs.extra` entry, and the inbound references by file and line, reported as
  verified markdown links (which a rename repoints) apart from every other mention of the path
  (prose, a fenced example, a released CHANGELOG line, each of which is a person's judgement).
  Where the README is itself one of the directory's artifacts the slot is taken and no move is
  proposed. The banner manifest is named in the change set and edited by the identity pillar,
  which owns it. `sense-state` surfaces the same signal, so a complete index in the wrong place no
  longer senses as `keep`.
- **A byte ceiling on chunking, beside the line ceiling**, because one minified bundle is a single
  line and more reading than the rest of an offer put together.
- **Bounded queries.** `--mode gaps|reconcile` decides what the chunks cover, `--summary` drops
  the file lists, and `--chunk <n>` returns one chunk.
- **`RS-index` now requires every declared index to appear in `docs.extra`.** An index no prose
  sweep reaches is the one page in its directory that can rot with nothing in the toolkit
  noticing. The atlas journey already wrote both entries; now the gate holds it. **This is a
  breaking config requirement**, and the config line is the cheap half: the page enters the voice,
  prose, TODO, and placeholder sweeps for the first time, and a table nobody swept can carry a lot
  of drift. Run the lint before committing to the upgrade and read the failures as a batch.
- **`extensions: ["*"]`, the only selector that can promise a directory is completely covered.**
  An extension list cannot reach a `Dockerfile`, a `Makefile`, or an extensionless script. This
  repo's own `payload/hooks/pre-push` sat inside an indexed directory carrying a row that nothing
  enforced, and the README said so out loud rather than fixing it; `payload/README.md` now
  declares `["*"]` and the gate holds the row that was already there.
- **`retain`, the recorded answer that an index stays where it is.** A migration offer had no
  durable "no": the same question came back on every run, the planner's exit code never reached 0,
  and a decision somebody had made was indistinguishable from one nobody had. The reason is
  required, as it is on a decline, and it prints as a named skip.
- **`RS-index` refuses one file catalogued by two indexes.** The containment rule never saw this,
  because a row in an ancestor's table for a file the child owns resolves, exists, and reads as
  coverage. One file had two authoritative descriptions and nothing could say which was current.
- **A kept file no declaration speaks for is NAMED in a skip** (`RS-index (unowned)`) instead of
  passing as coverage. Deliberately not a failure: a repo indexing its markdown and not its images
  has said what it wanted, and reddening that would impose a scope nobody gave. What it may never
  be is silent, because "no missing rows" over a set nobody chose reads exactly like coverage.
  The planner reports the same set under `undecidedFiles`, and the atlas journey asks about it.

### Changed

- **Grammar 2 now binds every check to the column its header names, including the link.** Three
  rules were still unbound behind the version: the link was searched for in ANY cell, so a row
  with an empty `File` cell and a link in its description counted as coverage; a table with no
  status column fell back to reading every cell, so renaming `Status` to `Phase` silently restored
  the grammar-1 rule the index had opted out of; and the same fallback let a date under `Added`
  answer for a `Last verified` column that does not exist. A missing header is now reported as a
  gap in the page rather than treated as permission to read another column.
- **Every configured path goes through one registry rather than one call site at a time.** The
  containment contract was arrived at key by key, which is why it kept leaking: `versionManifest`,
  `ignore.file`, `ignore.generated`, `assets.coverage.roots`, `assets.coverage.ignore`,
  `prose.exempt[].path`, `counts.*.docs`, `counts.*.file` and `counts.*.glob` were each read,
  walked or globbed outside the repository while the gate reported green about a tree it does not
  govern. The asset manifest's own paths (`banners[].dir`, a pill's `source.file`, a relative pill
  `href`) go through the same contract, replacing a hand-rolled half-rule that checked for a
  leading slash and a `..` segment and missed backslashes, drive letters, empty components and
  every symlink. **Spelling is judged before normalisation**, because a normaliser that runs first
  repairs the very spelling the contract exists to refuse. The claim is about the GATE and the
  PLANNER. `harness/sense-state.mjs` had no containment rule at all when this was written, and
  it is the engine that decides which generator a scaffold run is told to execute; that gap is
  closed in 0.8.0's fourth pass, below.
  **Three narrower words belong on "every configured path", and each of them was a hole.** It meant
  every DECLARED path: an effective default is a value the config chose by staying silent, and no
  default went through the contract at all. It meant every path whose TYPE is a string: a
  route-selecting key given a number fell through to the default in two engines and exited 2 in the
  third. And it asked where a path LANDS, never whether the file there is the one this repository
  commits: a symlink satisfies both legs and reads through to bytes committed somewhere else. All
  three are closed in 0.8.0's fifth pass, below.
- **Identity no longer authors indexes at all.** It previously declared the block, named the
  uncatalogued files, wrote an `ignore` entry or a provisional row for each, and edited
  `docs.extra`, then admitted in its own hand-off note that those rows came from a directory
  listing and needed Atlas to re-author every one. Two authoring paths for one artifact, with the
  weaker one running first: the operator got an index that satisfied the gate, read as finished,
  and described files nobody had opened. Identity now owns the manifest, the artwork and the
  generated markup; Atlas owns index placement, content and configuration.

- **The planner answers three questions separately, and says which one the exit code carries.**
  `structuralWork` is what is missing; `reconciliationPlan` is what re-reading costs whether or
  not anything is missing; `migrationOpportunities` is what would serve readers better elsewhere.
  Exit 0 now reads `no structural work` and states in the same breath that it is not a claim the
  rows are accurate. The old phrasing was `nothing to do`, and a run read it exactly that way:
  seventeen files and two whole chunks went unread because the index covering them was
  structurally perfect and nobody had opened it in a year.
- **The index coverage universe is what the repository keeps**, being tracked files plus the ones
  git does not ignore, so a build directory or a vendored tree owes no rows. It is read
  NUL-delimited, a symlink owes a row, and a submodule owes nothing. Where git cannot answer
  nothing is excluded, which demands more rows rather than fewer, and the coverage failure names
  which universe it used.
- **The atlas skill asks per directory, and asks about more.** Placement, reconciliation, and
  migration are now explicit questions; approving a table no longer implies approving edits to the
  prose around it; `docs.extra` is stated as required rather than advisable; and the skill carries
  the `git mv` grant a migration needs.

### Fixed

**A seventh pass, from the first integration journey against a real repository.** The journey was
mechanically green and still exposed two release blockers, both the same kind of failure: a step
that could not do what it said, and a step that decided something that was never its to decide.

- **The run-as-main guard compared two spellings of a path rather than two files.** Node
  canonicalises a script's symlinks before running it, so `import.meta.url` names the file on disk
  while `process.argv[1]` keeps the path as it was INVOKED. A marketplace installed from a
  directory source reaches its plugins through a link, which is the ordinary developer topology, so
  `node <link>/assets/generate.mjs --check` failed the lexical test and the CLI body never ran: the
  program exited 0 having printed nothing at all. Exit 0 with an empty plan is byte for byte what a
  repository needing no work looks like from the outside, so the scaffold journey read that silence
  as "nothing changes" and copied a new engine over the old one on the strength of a preview that
  had never happened. The guard falls back to a `realpath` comparison now, wrapped so a path that
  is not on disk resolves to NOT MAIN, because a guard that throws while deciding whether it may
  write has decided nothing. `AG27`, `AG28` and `AG29` hold the preview, the apply, and the import
  through a symlinked parent; the first two were confirmed red against the old comparison.
- **Scaffold reads a preview before believing it.** Output that is empty, or that does not open
  with `generate v<version> --check:`, is a preview that did not happen and is now a STOP. An empty
  change list inside a well-formed plan is a repository that is up to date; zero bytes is a plan
  nobody has, and the two were being reported as one fact.
- **An index migration belongs to the atlas journey, whole.** Scaffold performed a `docs/INDEX.md`
  to `docs/README.md` rename itself, judged the identity work that rename had just caused out of
  scope, kept the `assets.coverage` exclusion the rename had falsified, and invoked the atlas
  journey afterwards, by which point the planner reported no migration opportunity because the page
  had already moved. Doing the move first destroys the offer, so scaffold is told to make neither
  the move nor the judgement.
- **A nonempty `identityEffects` now reaches the identity pillar or comes back as an operator
  decision.** Atlas held no tool that could invoke a skill, so "handed to identity" could only ever
  be a sentence in a recap. It holds `Skill` and invokes `/repo-standard-toolkit:identity` itself,
  which is what gives a direct atlas run the same behaviour as one reached through scaffold. The
  operator may still decline the artwork and keep the exclusion: the defect was the missing
  handoff and the missing consent, never that artwork must be forced.
- **Prose converges after the last write rather than in the middle of it.** A README is not
  finished because its rows are structurally valid. Atlas re-senses and scans the final governed
  reach once identity has written its banners and generated H1s, and only then runs the lint and
  the suite. Where adding a page to `docs.extra` brings prose that was here already under the
  profile for the first time, the affected pages and hits are shown and a bounded pass is offered:
  nothing pre-existing is rewritten silently, an existing decline is respected, and a bounded run
  never records `PROSE_OFFER` because a caller declining a six-page cleanup is not the operator
  declining the pillar. The recap has to say which of the five prose outcomes happened.
- **The fan-out is priced in CHUNKS, and the recap states no number of agents.** The planner emits
  `chunks` and prints that same integer under the noun `agent(s)`, which is a label on a price. A
  run priced 38 chunks, launched 34 calls, and reported "38 agents". Nothing this journey produces
  records how many calls ran, so the count is omitted rather than inferred from the plan, for the
  same reason a value the engine cannot derive is an absent key rather than an empty string.
- **`W12` to `W17` bind the ownership chain to the tree.** W3 and W4 bound a skill's prose to the
  ENGINES it runs; nothing bound it to the SKILLS it says it hands work to, which is how an
  instruction to hand something over survived while no grant could carry it out.

**A sixth pass, and the finding that would have made the release unusable.** All four skills
shipped a frontmatter YAML cannot parse. Each `description` was an unquoted scalar whose text
contained `": "`, which YAML reads as a nested mapping and refuses, and `claude plugin validate`
rejected the plugin outright. The loader does not fail loudly on this. It drops every frontmatter
field and loads the skill with EMPTY METADATA, so the description that decides whether a skill is
ever invoked and the `allowed-tools` that decide what it may touch both silently become nothing.
Sixteen green suites, a green CI run and a green dogfood lint all said the plugin was fine.

- **The descriptions are folded block scalars now** (`description: >-`), which have no escaping
  hazard at all and wrap at the width the rest of the repository is written to. The rewrap was
  done mechanically and refused to write unless the folded form reproduced the original string
  character for character, so no description changed meaning while being made readable.
- **`W10` parses the frontmatter instead of pattern-matching it.** `W2` asserted
  `^description: \S`, which the broken line satisfied: it checked that the right words were
  present, never that a loader could read them. `W10` refuses a plain scalar containing `": "`,
  one ending in `":"`, one containing `" #"`, one beginning with a YAML indicator, and a duplicate
  key; it requires every other value to be a block or quoted scalar, and it requires a folded
  block's lines to be uniformly indented, because one extra space puts a line break in the middle
  of a description without changing a visible character. Node ships no YAML parser and this
  repository takes no dependencies, so it is a validity check rather than a parser, and it is
  written to refuse what it cannot vouch for.
- **`W11` runs the official `claude plugin validate`** when the CLI is on the machine, and is a
  named skip when it is not, which is the same shape `RS-ignore` uses for git. It is the
  authoritative leg; `W10` is the one that holds on a CI runner with no CLI. Neither subsumes the
  other: of the five mutations used to confirm both go red, the validator caught two and `W10`
  caught all five, because uniform indentation, a truncating comment and a duplicate key are all
  valid YAML that silently changes what the skill says.

**A fifth pass, after an external audit of the fourth.** The declared suite was green and the
audit's adversarial fixtures were not: it found release-blocking false greens, unsafe migration
classifications, and filesystem writes outside the target repository. Every item below was
reproduced against a fixture the engines called clean before it was fixed, every one is a standing
test, and every one of those tests was re-run with its guard reverted to confirm it goes red.

- **Nothing checked that a governed file is the file this repository commits at that path.** The
  path contract asks where a path LANDS; a symlink satisfies it and reads through to bytes
  committed somewhere else. A target whose `acceptance/test-repo-standard.mjs` was a link to a
  clean copy in another checkout printed 29 passed on a repository whose own index was missing a
  row, and `sense-state` called the same link `matchesPayload: true` and `keep`. The same
  substitution on `manifest.json` and on `generate.mjs` passed every asset check. Worse, a
  symlinked `banner.svg` was invisible to a directory scan built on `isFile()`, so the lint
  reported no orphan, the generator's preview reported no change, and applying it wrote the
  rendered artwork THROUGH the link onto a file outside the repository. A REGULAR FILE is now
  required at the lint, the generator, the manifest, every generated asset, and every README
  carrying generated markdown, before any of them is read, imported, executed, copied, written or
  deleted; a `.svg` entry that is not one is an explicit error rather than an entry the scan cannot
  see; and the gate refuses to run at all when its own invocation path is a link or sits in a
  different repository from the file that is running.
- **`--assets-dir` was a write target with no containment rule.** The generator creates
  directories under it, writes every rendered SVG into it, and DELETES the assets the manifest no
  longer produces. Pointed outside `--repo` it did all three, on a tree the repository does not
  govern, at the request of the one flag whose purpose is to let one repository plan another's.
  The assets directory must now be inside `--repo`.
- **A tracked file replaced by a DIRECTORY went from a red build to a green one.** All three
  engines filtered git's listing with one question, "does `lstat` call this a directory", and a yes
  was dropped in silence. A cached, non-gitlink path with a directory sitting at it is now a
  universe error in all three; an untracked nested repository, which is what that skip was written
  for, is still the only thing it excuses.
- **`sense-state` re-applied a filesystem guess after git had already answered.** It excluded
  `node_modules` from candidate discovery even when the universe came from `git ls-files`, so a
  force-added `node_modules/kept.js` was red in the planner and the gate under strict ownership
  while sense reported `strictFailures: 0` and `keep`. The exclusion belongs to the walk, which is
  the fallback, and it stays there.
- **Three engines disagreed about paths in four more ways.** `.trim()` ran BEFORE the path
  contract on an index `file`, a `docs.declined` directory and an `assets.coverage.ignore` entry,
  so a control character was removed and the value accepted while the gate refused the same key
  untrimmed. Effective DEFAULTS went through no contract at all, so a root `README.md` symlinked
  into a sibling checkout was read by the planner and by sense and refused by the gate. A
  route-selecting key given the wrong TYPE (`assets.dir: 7`, `ignore.file: 7`) fell through to the
  default in the planner and in sense and exited 2 at the gate, which meant sense could route an
  upgrade at a directory the config never chose and report a repository's credentials covered by
  rules in a file it does not use. And a manifest path was validated without being CANONICALISED,
  so a banner declared for `"./docs"` was a no-op to the generator and a coverage failure at the
  gate. All four are closed, and the differential table stands at 66 cases, judged by exit CLASS
  over the same narrow surface as before. Beside it, the two engines are now compared on SETS
  rather than on verdicts: the exact universe errors, candidate directories and unowned files, with
  `sense-state` in the comparison for the first time.
- **Six more contexts credited a glossary Markdown does not render.** A comment nobody closed
  (which swallows the rest of the page on GitHub and matched nothing at all here); a `<pre>` block;
  four-space-indented code sitting directly under an ATX heading; a fenced block "closed" by an
  indented fence, which CommonMark 4.5 does not accept and GitHub does not honour; a file cell
  whose link is backslash-escaped; and a file cell carrying an IMAGE rather than a navigable link.
  Rather than adding six more patterns, both engines now run one conservative block scanner whose
  output is the same length as its input, so a byte is non-rendering exactly where the two differ,
  and the migration scan asks that same scanner instead of keeping a second, narrower copy of two
  of its rules. Every ordinary idiom is asserted beside every refusal.
- **The migration list called things mechanically safe that are not, and lost things that are.**
  On the real target Atlas reported 0 links and 13 mentions for `docs/INDEX.md`, and the
  repository's own front page carried `` [`docs/INDEX.md`](docs/INDEX.md) ``: one genuine live
  link, demoted because an overlap test saw the backticks in the link's LABEL. Classification is
  now asked of the opening bracket. Promoted into the safe list and now reported as mentions: a
  link inside a comment, inside indented code, inside `<pre>`, an escaped bracket, an unclosed
  link, and an image. Reported in NEITHER list and now found: a local `./INDEX.md`, a
  percent-encoded spelling, and a backslash-escaped destination. A changelog occurrence is manual
  unless it can be PROVEN to sit above released history, which a bracket-only heading regex could
  not do for `## v1.2.3`. And a bare basename counts only where it is written as a path, so
  "submission-package INDEX.md" in an unrelated roadmap row stops being reported as an inbound
  reference; that trade is stated in the engine, because a bare basename in flowing prose is given
  up to get it. Every entry now carries its source range and its resolved destination.
- **The asset preview omitted two writes it called approved.** On the real target the payload
  generator and the installed one had different SHA-256 values and `--check` said "nothing
  changes", while the sequence the scaffold journey follows copies the payload engine over the
  installed one FIRST: the change set began one write later than the change set. `ENGINE
  NEW`/`ENGINE CHANGED` is now named first and counted in the exit code. Separately, removing a
  folder banner deleted its SVG and left the README it headed pointing at nothing, and every other
  rule iterates the manifest, so nothing anywhere could see it; the preview and the gate now
  discover generated H1 carriers from the PAGES, and the apply says which are still stale.
- **Manifest text could inject SVG attributes.** One escape function handled `&`, `<` and `>`,
  which is right for a text node and wrong inside `aria-label="..."`, where a quote is what ends
  the attribute: a tagline of `safe" onload="alert(1)` rendered an event handler into every banner
  and every pill, and the committed lint re-rendered the same injected bytes and reported zero
  drift. Deterministic is not the same as safe. There are now four escapes for four contexts (XML
  text, XML attribute, Markdown label, Markdown destination), and a `brand.homepage` and a
  `badges[].href` are held to the destination rule the pill hrefs already were. **Rendered bytes
  move only for a manifest carrying one of the characters at issue**: an apostrophe is left alone
  on purpose, because every attribute this generator writes is double-quoted, so escaping it would
  redden every adopter whose tagline contains one and buy nothing.

**A fourth pass, after an external audit of the third.** Every item below was reproduced against
a fixture both engines called clean before it was fixed, and every one is now a standing test that
goes red when the fix is reverted. Three of those tests did not exist until an anti-vacuity sweep
went looking for them.

- **A plain `rm` turned a red build green, in all three engines.** Each subtracted
  `git ls-files --deleted` from the kept-file universe, on the belief that it means "staged for
  removal". It does not: it means "tracked, and not in the worktree", which is an ordinary unstaged
  deletion as well. Measured on a fixture with one uncatalogued tracked file, the pair went from
  1/1 to 0/0 on a `rm` a contributor makes without thinking about it. A staged deletion never
  needed a rule, because `git rm` takes the path out of the index and it never reaches the
  universe. The subtraction is gone; every cached, non-gitlink path `lstat` cannot find is named
  and fails, whether it was deleted, sparse or skip-worktree. **This is an operational
  compatibility change**: a tree carrying an unstaged deletion now fails `RS-index (universe)`
  where it used to pass, and the fix is to stage the removal or restore the file.
- **`harness/sense-state.mjs` could route execution outside the repository.** It read
  `assets.dir` and `ignore.file` before applying any containment rule, so a config naming
  `"../outside/assets"` had it read that generator, hash it, take its version, and emit a
  DIRECTED plan action for it, while the planner and the gate both exited 2 on the same config. The
  scaffold journey follows those actions, and one of them is "run this generator". Read-only is not
  the same as harmless when the thing being decided is which code runs. Every configured path now
  goes through the same two-leg contract before it is read, hashed or routed, and a refusal is
  terminal for the key it names (`blocked-config`) rather than a note beside a confident answer.
- **A universe error was computed, printed, and routed nowhere.** `strictFailures` excluded it, so
  a skip-worktree entry returned `keep` under strict ownership and `offer-coverage` under
  declared, on a tree where the planner exited 1 and the gate was red. The cheapest of the three
  engines, and the one that decides whether the pillar is offered at all, was the one saying nothing
  was wrong. It is now a terminal `blocked-universe` action in both modes: Atlas cannot price or
  reconcile a tree it cannot enumerate.
- **An accepted path spelling could still change what a rule means.** Spelling was judged first and
  then every call site kept the RAW value, so half the keys were canonicalised and half were not.
  Three measured divergences on configs nobody would call wrong: `docs.declined [{ dir: "./lib" }]`
  excused the directory in the planner and excused nothing in the gate (a green build against a red
  one under strict); an index's `ignore: ["./lib/two.mjs"]` was an exclusion in one engine and no
  exclusion in the other; and `docs.changelog: "./CHANGELOG.md"` stopped matching the
  `CHANGELOG.md` git lists, which silently disabled the migration offer's released-history guard
  and queued shipped history for mechanical rewriting. The contract now RETURNS one canonical path
  and every call site uses it. A control character in any configured path is refused outright.
- **Grammar 2 credited a glossary Markdown does not render.** A complete, correct, column-bound
  table inside an HTML comment, inside an indented code block, or written with every link in an
  inline code span was counted as full coverage by both engines, so a repository could report itself
  completely catalogued while a reader browsing the directory saw no glossary at all. Those three
  contexts are now masked positionally, a link whose opening bracket sits inside a code span is
  text, and a delimiter row must match the header's cell count (GFM 4.10) instead of merely
  containing a hyphen. The ordinary idioms are asserted beside each of them, because a rule that
  also refuses a backticked status cell or a three-space-indented table is worse than the hole.
  (`|-|-|-|` is valid GFM, GitHub renders it, and it is still accepted.) **Those three contexts are
  the ones this pass closed, and they were not the whole set**: six more were still open when this
  was written, and they are listed under 0.8.0's fifth pass below.
- **Migration discovery classified a LINE, and a line is not an occurrence.** A live link beside an
  identical link in a code span put both in the links list, so an applier would have rewritten the
  example. A live link beside a plain mention of the same path dropped the mention out of both
  lists. A multiline code span was blanked with spaces including its newlines, which shifted every
  later line number in the blanked copy, so a genuinely live link following one was classified as an
  example and left out of the list whose whole promise is that it is safe to apply. Discovery is now
  a range model over source offsets: every occurrence is classified on its own, raw HTML
  `href`/`src` attributes and the path inside a full URL land in `mentions` instead of in
  neither list, and anything not proven live is a mention. **"Anything not proven live" described
  the intent rather than the code**: the range model knew only about fenced blocks and inline code
  spans, so a link inside a comment, inside `<pre>`, or in indented code was still promoted into
  the safe list, and an escaped destination and a percent-encoded spelling still landed in neither.
  0.8.0's fifth pass below is where that sentence becomes true.
- **The generator wrote on a typo.** `process.argv.includes('--check')` means an argument this
  program has never heard of is not an error, it is a write: `--chek` rendered every asset and
  wrote it, and so did `--CHECK`. Arguments are now parsed strictly, and an unknown flag, a
  positional, a duplicate or a missing value exits 2 having written nothing.
- **The generator could not express a deletion, so no run could reach the state the lint wants.**
  It wrote the keys the manifest renders and nothing else, so a removed pill, a removed banner or a
  renamed slug left the old SVG on disk forever, `RS-assets (drift)` failed on it, and `--check`
  answered "every asset on disk already matches this manifest" because it compared the render to
  what it was about to write and never to the DIRECTORY. The preview now lists `DELETE` lines and
  says the apply is destructive; the apply carries them out.
- **The generator hardcoded the root README.** On a repository declaring
  `docs.readme: ".github/README.md"`, `--check` reported the root README missing and exited 1:
  a false failure whose obvious fix creates a second front page. It reads `docs.readme` from the
  target's own config now, with `--readme` as an override.
- **Three asset paths bypassed the containment contract.** `paletteSource.roles.*.file` and a
  relative `badges[].href` had no containment rule and the badge href had no existence rule
  either, so a palette could be "traced" to a sibling checkout's design tokens and a badge could
  link to `../../etc/passwd`. In the generator, `banners[].dir` of `"../outside"` made
  `--check` read a README outside the repository, and planting a satisfying one there changed the
  answer. All of them go through the same rule now.
- **The scaffold journey previewed an upgrade by performing it.** It ran
  `node <assets.dir>/generate.mjs --check`, which on an upgrade is the OLD generator, and an old
  generator does not know `--check`. The step now runs the payload copy with `--assets-dir` and
  `--repo`, which is what those flags were added for.
- **A submodule was claimed by one pillar and disowned by the other.** `RS-index` excludes a
  gitlink as another repository's content while `RS-assets` coverage walked into the same directory
  and demanded a banner entry and a folder README from it. One policy: neither pillar governs a
  submodule.
- **Both shipped lint copies contained a literal NUL byte**, in a template literal used as a Map
  key, so `file` called them binary data and `rg` skipped them. It is an escape sequence now,
  and the files are text.
- **A symlinked `--target` silently changed the file universe.** `git rev-parse --show-toplevel`
  returns the resolved worktree, so the ownership guard compared unequal and the planner and
  sense-state fell back to a filesystem walk while the gate used git: the same tree owed rows for
  every build directory, purely because of the path it was addressed by. All three canonicalise now.
- **Grammar 2 rejected correct destinations.** A query string was carried into the filename
  (`one.mjs?raw=1`), balanced parentheses truncated at the first `)` (CommonMark 6.6 allows
  them), and `decodeURI` preserves the reserved set so a file named `one#two.md`, correctly
  written `one%23two.md`, resolved to nothing. Each was a correct row reported as pointing nowhere.
- **An asset directory containing a space produced a destination Markdown cannot read.** CommonMark
  ends an unbracketed destination at the first whitespace, so the banner rendered as literal text.
  The angle-bracket form is used where it is needed and nowhere else, so no existing repository's
  bytes move.
- **The root-governance boundary counted disabled checks as governance** and omitted three licence
  spellings `RS-license` accepts (`LICENCE.txt`, `COPYING.txt`, `UNLICENSE`), and it called a
  file "governed" where it meant "checked". A check turned off with `checks.<id>.enabled: false`
  governs nothing, and no rule anywhere DESCRIBES a root file the way an index row would.
- **The atlas skill contradicted itself about candidates**, saying a candidate always has a README
  one paragraph after the rule that replaced it. The scaffold skill now also records a decline to
  `offer-coverage` as `ATLAS_STRICT_OFFER: declined`, which is the only place an answer survives
  a re-sense, and stops outright on `blocked-universe`.

- **`--check` reported "a run would be a no-op" for four ordinary manifest edits that redden the
  build.** The exit code came from SVG output alone, so a pill `href`, a `brand.homepage`, a badge
  `href` and a banner `dir` each rendered byte-identical artwork, each moved markdown the lint
  compares character for character, and each answered that nothing would change. A plan that
  reports a no-op for a change that reddens the build is worse than no plan. `--check` now makes
  the same three comparisons `RS-assets` makes, against the same helpers, and they reach the exit
  code. **Two writes were still outside the plan after this**: the generator's own replacement, and
  a README left carrying an H1 for a banner the manifest no longer declares. Both are closed in
  0.8.0's fifth pass below.
- **A migration's change set was incomplete in one way and unsafe in another.** The moving page
  was skipped during discovery, so a self-reference inside the index being renamed
  (`[this page](INDEX.md)`, a table of contents) appeared in neither list and dangled after the
  move. Separately, a closing fence may not carry an info string (CommonMark 4.5) and the parser
  accepted one, so a line reading ```` ```notclose ```` inside a block ended the fence here and not
  on GitHub: a link in a fenced EXAMPLE was classified as a verified live link and queued for
  mechanical rewriting, which is the one list this offer promises is safe to apply. The same fence
  defect let a fenced table count as index coverage. A link-shaped string inside code is now
  reported as a mention, whatever relative spelling it uses.
- **A link's closure was answered by a different link.** Two regexes over one cell asked two
  questions about two links, so in `[a](open.md and also [b](closed.md)` the destination came from
  the first and the closure test from the second: a row whose link never closes read as a catalog
  entry to both engines and as literal text to every reader. One parsed link now answers both.
- **A root-absolute link destination was joined onto the index's own directory.** `/guide.md` in a
  docs index resolved to `docs/guide.md` and passed as coverage, when a leading slash makes it a
  site path GitHub resolves against the domain. It is reported as what it is.
- **Three planner/gate divergences outside the differential table.** A config that is JSON `null`
  or an array crashed the gate with a `TypeError` where the planner exited 2; `"manifest": null`
  was exit 0 at the gate and exit 2 at the planner (the gate is right, and null reads as absent);
  and `docs.declined[].dir` written with a backslash was normalised into an accepted path by the
  planner and refused by the gate. The differential table stands at 59 cases, and its scope is
  the same narrow one stated above: the atlas surface of the config, judged by exit CLASS. It is
  not a claim that the two engines agree about everything, and three divergences outside that
  surface were still open when it was written (see 0.8.0's third pass, below).
- **The ownership boundary was stated as one undifferentiated list.** Twenty-three files reported
  as "outside the model" on this repository buried the question that matters, so each root file
  now states whether another check governs it, and `ungovernedRootFiles` counts the residual gap.
  On this repository that count is zero: the root holds the meta docs, the stable docs, the
  licence, the ignore ruleset and the config, each held by a rule of its own.
- **`identityEffects` compared exclusion paths by string identity.** `"./docs"` and `"docs/"` are
  the same exclusion as `"docs"` and matched none of them, and an exclusion naming an ancestor
  never matched at all, so the effect that says "this exclusion is about to be wrong" did not fire
  on a config written perfectly legibly. Normalised, and matched by containment.
- **Identity hardcoded `.github/assets` while the configuration has always had `assets.dir`.**
  Every command it documents now reads the configured directory and is shell-quoted, because a
  path containing a space arrived as two arguments and wrote the generator somewhere nobody looked.
- **A piped `--json` larger than 64 KiB arrived truncated to exactly 65536 bytes and failed to
  parse.** `console.log` to a pipe is asynchronous and `process.exit()` discards whatever has not
  drained. Affected `index-plan`, `voice-scan`, `github-about`, and `derive-palette`; all four now
  set the exit code instead of taking it. A standing test pipes a plan past the buffer and parses
  the result.
- **A literal pipe in a cell, written `\|`, tore the row into pieces**, which moved the status out
  of the column the check reads and failed a row that was correct.
- **A link destination in angle brackets was invisible to the parser**, so `[text](<two words.md>)`
  read as prose and the file it linked was then reported as uncatalogued.
- **The same file catalogued twice silently overwrote the first row**, so an index could carry two
  descriptions of one file, on two lines, and pass every check there was.
- **A row pointing outside the indexed directory counted as coverage** for a file the index has no
  business speaking for. Writing the target relative to the repo root instead of to the index is
  the commonest way to get a row wrong.
- **Two index declarations for one directory** are now a config refusal rather than a race in
  which neither catalog is authoritative.
- **Surface claims that the green suite allowed.** The plugin manifest advertised "two further
  opt-in journeys" and omitted the atlas entirely. The scaffold skill said a `docs/README.md`
  trips `RS-shadow`, which the lint deliberately exempts. `acceptance/README.md` and
  `payload/templates/INDEX.md` both described template-list completeness as untested after `TG0`
  had started testing it in both directions.

An adversarial pass over the work above found files that could disappear from every coverage claim
both engines make while the whole build stayed green. Each of the following was reproduced against
this repository's own tree before it was fixed, and each now has a standing test that fails
without the fix.

- **A boundary drawn at the child DIRECTORY discarded the child's own declaration.** A parent
  speaking for `.json` and a child speaking only for `.md` left every `.json` under the child
  claimed by nobody: not missing from the parent, not owed to the child, catalogued nowhere. A
  file added to such a directory vanished from coverage with both tables and the gate green.
  Ownership is now per file.
- **`--index` deleted the sibling declarations before working out what the surviving index
  owned**, so a narrowed plan disagreed with both the full plan and the gate about the same
  directory. Narrowing is a question about what gets reported and never about scope.
- **A path git has to quote left the file universe entirely.** `git ls-files` C-quotes anything
  outside plain ASCII, so `docs/café.md` came back as `"docs/caf\303\251.md"` with the quotes as
  characters, matched nothing in the filesystem walk, and owed no row. A filename containing a
  newline was worse: indistinguishable from a record separator. Both engines now read the listing
  NUL-delimited.
- **A symlink was dropped by a walk built on `Dirent.isFile()`**, which yields neither a file nor
  a directory for one. It owes a row, and is reported as a symlink rather than read through:
  following one would describe its target twice, and a link to a directory would walk forever. A
  submodule owes nothing, being another repository's content.
- **A directory holding kept files nobody owns is offered whether or not it keeps a README.**
  Requiring a README meant an ignored build directory with one was offered as work while a kept
  source directory without one was passed over in silence, which is the pillar's own north star
  missed by its discovery rule. An `ignore` entry or a recorded decline still closes the question,
  because those are answers rather than gaps.
- **`decodeURI` threw on a link target that is not valid percent-encoding**, and `100%.md` is a
  legal filename. The planner died with a stack trace and no JSON at all, which every caller reads
  as a broken planner rather than a broken row. It is now reported as the bad row it is, in both
  engines.
- **A markdown link that never closes was read as a catalog entry.** `[a](b.md` renders as literal
  text, so the row looked catalogued to the check and looked like prose to every reader.
- **The planner refused nothing the gate refuses.** `extensions: [1]`, a missing `docs.extra`
  entry, and two indexes for one directory were each exit 0 from the planner and a hard refusal
  from the lint, which is the worst pairing available: the expensive half runs and the cheap half
  is what says no. Those three are enforced in both, and a differential test now runs 48 mutated
  configs and pages through both engines and fails the build when their EXIT CLASSES disagree.
  That test is what found the eight further divergences listed below; the first draft of this
  entry claimed every index-related config rule was enforced in both, which was a claim written
  from the three cases in front of it rather than from a check. The second draft was no better:
  the test it pointed at asserted only that the gate was non-zero, which passes when one engine
  calls a config broken and the other calls it merely incomplete, and six real divergences sat
  behind that assertion. The scope of the parity claim is the ATLAS SURFACE and is stated rather
  than implied: the whole `docs` block, `manifest.file`, the format version, and the top-level key
  names. A broken `counts` or `voice` block is a config error the planner does not adjudicate; the
  gate reports it, and the atlas journey runs the gate first for that reason.
- **A configured path could leave the repository, and both engines went green describing what it
  found there.** An index declared at `../outside/README.md` resolved to a sibling directory, was
  opened, read, and reported as a passing `RS-index` over a tree neither engine governs. The same
  hole was open on an index's `ignore` list and on `docs.declined`. Every configured path is now
  held to one contract with two legs. The LEXICAL leg is how a path is written: repo-relative, no
  leading `/`, no drive letter, no `..`, no backslashes, no empty components. The PHYSICAL leg is
  where it lands: the resolved path has to stay inside the repository, so an in-repo page that is
  a symlink to a sibling checkout is refused rather than read. The spelling rule alone could not
  see that, and a first pass shipped with only the spelling rule: an in-repo `docs/README.md`
  linked to an external file was read by both engines and reported structurally complete, and a
  `docs.extra` entry pointed outside changed this repository's `RS-voice` verdict when prose in an
  unrelated checkout changed. The contract now covers `docs.readme`, `docs.changelog`,
  `docs.conventions`, every `docs.extra` entry, `manifest.file`, every index `file` and `ignore`
  entry, every `docs.declined` directory, `assets.dir`, `stableDocs`, `voice.alsoScan`, the count
  sources, and the planner's `--candidate` and `--index-file`. `assets.dir` had carried a guard of
  its own since it was written, and it is now the same guard as everything else rather than a
  second one that could drift.
- **The planner enforced the config rules and none of the ROW rules.** A row carrying no status
  word, a row missing the date its index requires, and an index missing its reconciliation line
  were each exit 0 from the planner and a hard failure from the gate, so a reconciliation run could
  rewrite an index, read its own exit 0 as done, and hand back a repo CI refuses.
- **Eight further config divergences, found by running both engines over the same mutated config
  rather than by reading either of them.** The planner trimmed whitespace out of config strings and
  the gate did not, so `[" .mjs "]` and `[" active "]` were silently repaired by one and refused by
  the other. Malformed `docs.declined` entries (bare strings, a missing `why`) were quietly dropped
  from the planner's list and were exit 2 at the gate. And a decline naming a FILE excused exactly
  that one file from every ownership rule, which is an `ignore` entry wearing a decline's clothes.
- **`--index` hid a duplicate the full plan caught.** Cross-index duplicate detection ran over the
  narrowed declaration list, so a file catalogued by both a parent and its child was reported by
  the full plan, missed by either narrowed run, and failed at the gate: a reconciliation of one
  directory could finish clean and leave the build red. Narrowing decides what gets REPORTED, and
  it was never a question about what is true.
- **A date with the shape of a date and no day behind it.** `2026-99-99` satisfied every check in
  both engines, and so did February 30th, which makes the freshness signal a string that looks like
  one. Both now read the calendar.
- **`sense-state` still required a README to see a candidate**, which is the discovery rule the
  planner abandoned in this same release and this same changelog headlines. The three engines
  therefore disagreed about what the pillar is for, and the cheapest of them was the one telling
  the operator whether to run it at all: on the real target it reported one candidate where the
  planner reported seven. It now derives candidates from kept files nobody owns, like the other two.
- **Two skills instructed themselves to do what their frontmatter forbade.** Scaffold told itself
  to re-render an upgraded asset generator and held no grant that could run one, which is the step
  it exists to perform failing at the moment it is needed. Atlas promised to repoint every verified
  inbound link during a migration while granted edits only on README, INDEX, and the config, which
  fails on the first repo whose CONTRIBUTING links the index. A new wiring test (W9) binds every
  committed-engine command a skill documents to a grant that covers it.
- **An `ignore` entry meant different things to the two engines.** The planner read it as a
  decision and the gate counted the file as unowned anyway. Under strict ownership that gap is the
  difference between a contract a repo can meet and one nothing can satisfy.
- **`sense-state` offered to move an index that does not exist**, sending a run looking for a page
  nobody had written, and kept offering a move the config had already recorded as retained.
- **A repo that declared no index and turned every directory down still sensed `offer`**, so a
  recorded no produced the same output as no answer at all. The lint had the mirror of this bug:
  recorded declines printed only inside the declared-index branch, so the one shape where every
  answer was a decline was the one shape where none of them was mentioned.
- **Generated commands were unquoted.** A path with a space in it became two arguments, which for
  `git mv` means moving the wrong file. The planner now returns structured argv beside a
  shell-quoted rendering.
- **The atlas skill would write config keys an older installed lint rejects.** `scope`, `ordered`,
  `retain`, `declined`, and `["*"]` are unknown keys to a pre-upgrade lint, and an unknown key is
  an exit-2 error that suppresses every other check, so a perfectly indexed repo could be handed
  back with its gate wedged shut. The journey now requires the installed lint to match the payload
  and routes through the scaffold skill when it does not.
- **The scaffold skill never consumed the generator plan action `sense-state` emits**, so an
  adopter's committed asset generator stayed stale through a re-run. That is why one run had to
  work out the generator replacement for itself, mid-journey.
- **Two claims the atlas skill made that were not true.** "Nothing is read until you approve" was
  false: pricing opens every file to count its lines and bytes, and migration discovery searches
  their contents. What is actually gated is agent review and every write, and that is what it now
  says. "Every inbound reference" was a promise substring matching cannot keep; references are now
  reported as verified links apart from mentions, and the skill promises only what it repoints.
  The skill also both claimed to update the banner manifest and, twelve lines later, that it never
  touches one; the manifest belongs to the identity pillar and the handoff is now explicit.
- **The parity test compared two silences.** It matched the planner's missing set against the
  lint's failure MESSAGE, so when the lint refused the config before `RS-index` ever ran, an empty
  list agreed with an absent one. It now requires the check to have run, and requires the gate to
  be green whenever the planner reports no structural work.
- **The example config in `docs/configuration.md` was invalid under the rule the same page
  documents**, declaring two indexes and listing neither in `docs.extra`.

A second adversarial pass, run against the work above rather than against the release before it,
found that several of the sentences already in this entry were true of the cases their author had
in front of them and false of the general rule. Each of the following was reproduced before it was
fixed, and each now has a standing test that fails without the fix.

- **`strict` was skipped entirely on a repo that declared no index.** The whole ownership contract
  sat inside the gate's "at least one index is declared" branch, so a config reading
  `"docs.ownership": "strict"` over a repo with zero declarations printed `no index declared` and
  went green while the planner exited 1 on the same tree. Strict now means the same thing before
  the first index exists as after it. A repo that has never adopted the pillar at all is still
  handed one line rather than a wall of directory names.
- **`--index` suppressed the repo-wide verdict.** The previous entry says narrowing decides what
  gets reported, and that had been made true for cross-index duplicates alone. Candidates and
  migrations were still emptied outright by a narrowed run, so a full plan exited 1 on a new
  top-level directory and `--index some/other/README.md` exited 0 on the same tree with the gate
  red. Every declaration is now planned on every run, narrowing selects what is REPORTED and
  chunked, and the output carries a `scope` block naming what it reported against what it judged.
- **"Every kept file" excluded the repo root and every dot-directory, silently.** A tracked
  `ROOT-UNOWNED` and a `.hidden/x.mjs` were both green under strict in both engines. Neither can
  be owned by construction, because an index must live inside the directory it catalogues, so the
  fix is to state the boundary rather than to pretend it is not there: both engines now name and
  count the files the model does not reach, the gate prints `RS-index (ownership boundary)` on
  every strict run whether or not anything is in it, and a dot-directory is brought inside by
  declaring an index for it.
- **`sense-state` reported `keep` on a repo whose build was red.** The atlas plan action was
  computed from candidates and migrations alone, so a strict repo with a file no declaration
  speaks for sensed as finished while the gate and the planner both failed it. Sense now reports
  the ownership mode, the unowned count, the strict failures, and strict READINESS: a `declared`
  adopter sitting at zero is told the mode exists, which it previously learned only if Atlas
  happened to run for some other reason.
- **Migration discovery was a substring match wearing a link's clothes.** It missed
  `[x](./docs/INDEX.md)` and, from a page inside the directory, `[x](../docs/INDEX.md)`, reporting
  them in neither list, so a rename would have left them pointing at a page that no longer exists
  with nothing said. It classified a reference-style definition (`[ix]: docs/INDEX.md`) as prose
  for a human, which is the one line that actually needs the rewrite. And it classified a link
  inside a code fence, a link inside an inline code span, and a markdown-shaped string inside a
  `.mjs` file as links an applier should repoint. Discovery now blanks fenced regions and code
  spans, finds the three link forms markdown has, resolves each destination RELATIVE TO THE FILE
  IT SITS IN, and compares resolved paths; only files markdown renders get link treatment.
- **A migration named the identity effects as prose and left the important one out.** Where a
  directory is excluded from folder-README coverage through `assets.coverage.ignore`, the
  exclusion is nearly always recorded BECAUSE the directory keeps its front page under another
  name, which is exactly what the rename changes. The plan could therefore stay lint-green while
  the reason written in the config had become false and no banner was ever declared. Migration
  output now carries structured `identityEffects` handed to the identity pillar, which owns the
  manifest, including the case where the directory is currently ignored and has no banner.
- **Atlas and Identity carried competing index-migration procedures.** Identity's was built on
  grepping for the filename and had every defect listed above. Identity now delegates index
  placement, content, and config entirely to Atlas and keeps the manifest, the banners, and the
  generated markup, which is what it owns.
- **The asset generator wrote before it compared.** A generator whose geometry moves by one path
  command rewrites every SVG in the tree, and the operator learned which ones from `git diff`,
  after the bytes had landed on files they may have been holding uncommitted. `--check` renders
  every asset in memory, writes nothing, lists each one as `NEW` or `CHANGED`, names the READMEs
  carrying generated markdown, and exits 1 when anything would move. The scaffold journey now
  checks the working tree is clean, runs `--check`, gets the plan approved, and only then applies.
- **A skill command carrying an `<angle>` placeholder was never bound to a grant.** The wiring
  test skipped them as shapes rather than commands, and the shape it skipped was
  `node <assets.dir>/generate.mjs`: the grants covered `.github/assets` and anything ending
  `assets/`, so a repo whose `assets.dir` is `.brand` would have had the step fail at the moment
  it ran. W9 now expands each placeholder over the values an adopter can really give it and
  requires every expansion to be covered.
- **A decline naming a symlink was accepted as a decline of a directory.** `stat` follows a link,
  so `isDirectory()` said yes, and the decline silently excused the symlink itself, which git
  keeps as one file that owes a row. Both engines now `lstat` and refuse it by name.
- **Both engines read a table inside a code fence as catalog rows**, so a page could document the
  row grammar and be credited with obeying it. Fenced regions are now blanked before parsing,
  under both grammar versions, with line numbers preserved.

One key was added by that pass rather than fixed by it:

- **`grammar` on an index declaration, defaulting to `1`.** Version 1 is what shipped: any line
  starting with `|` is a candidate row, any cell may carry the status, and any cell may carry the
  date. That let three things through, each of which makes a file look catalogued when nothing
  catalogues it: an UNRELATED table whose rows link files and carry a status word counted as
  coverage; a description cell BEGINNING with a status word satisfied the status rule while the
  status column sat empty; and a bare date in any column answered for a blank verification column.
  Version 2 reads the header, so a catalog row is a body row of a table whose header names a file
  column, and the status and date checks are bound to the columns their headers name. The default
  stays 1 because changing what a row MEANS under an adopter is a migration rather than a fix, and
  version 1 is an honest shape for a page carrying no headers; while it is in force the gate
  prints `RS-index (grammar)` naming exactly what it does not check. This repository runs all six
  of its indexes under version 2.

## [0.7.0] - 2026-08-01

**Never published.** This version was cut on a local branch, was never tagged, and never reached
the default branch the plugin catalog follows, so no adopter installed it. The section is kept
because the work is real and 0.8.0 builds on it; the date is the day it was cut, not a release
date. 0.8.0 is the first release to carry these changes.

### Added

- **The atlas, the fourth pillar: `/repo-standard-toolkit:atlas`.** The config surface shipped in
  0.6.0 and the journey that AUTHORS the rows did not, which left the standard held by whoever
  happened to write a table by hand. The identity skill's step 5 wrote folder README descriptions
  from directory LISTINGS and had never opened the files it described; on a real target that
  produced a table naming 33 of 101 files, and a table reads as complete. The atlas reads every
  file it writes a row about, which means a fan-out, and the fan-out is a gate: it states how
  many directories, how many files, how many lines and roughly how many agents before it starts,
  and a decline routes to a narrower scope or a hand-off rather than to a failed step. What makes
  many agents sound like one is that the shape is fixed before anyone writes a word. Deterministic
  contract, agentic execution.
- **`harness/index-plan.mjs`, which is where the number in that offer comes from.** It reports,
  per declared index, the files that owe a row, the ones that already have one, the rows pointing
  at a file that is gone, the files it cannot read, and how the reading divides into agents. It
  also reports candidates: directories keeping a README and no index, which the journey offers and
  never adopts. A consent gate whose numbers the asking party estimated is a worse gate than no
  gate, because it looks like information.
- **A standing test that the planner and the gate scope the same sweep.** They are two
  implementations of one rule in two files that cannot import each other, and if they ever
  disagree a sweep writes rows the lint does not want and skips the ones it does. The comparison
  is behavioural rather than textual: a fixture with one row makes the lint enumerate everything
  else it wants, and that list is compared to the planner's. It also runs against this repo's own
  six indexes on the real config.
- **`sense-state` reports `enforcement.indexes`**, so the scaffold's step 12 can offer the atlas
  once instead of every session, and an adopted pillar is never offered again.
- **`docs/atlas.md`**, and the row grammar recorded as a contract rather than as a lesson: the
  seven ambiguities three agents hit indexing this repo by hand are now decided in the brief every
  fan-out agent receives.
- **The front page's opening block is generated, and the lint compares it byte for byte.** The
  generator already emitted the banner H1 and the live badge line, and nothing in between, so the
  pill row was prose an agent assembled from a description. What it assembled was a left-aligned
  row under a full-width banner, because the `<div align="center">` wrapper that makes the real
  thing work was in this repo's own README and in no skill. New `readmeBlock()` export beside
  `bannerH1()` and `badgeMarkdown()`, emitting the whole arrangement: the H1, the centred wrapper,
  the pill row, and any live badge on its own line inside it. `RS-assets (idiom)` holds it, the
  CLI prints it flush left to paste whole, and the preview page shows both the centred row and
  the exact markdown. The failure this closes is the quiet kind: a banner that renders wrong gets
  noticed and fixed, while a badge row that is merely arranged wrong survives every review it
  will ever get. **Every repo that adopted the identity pillar fails `RS-assets (idiom)` until it
  re-runs**, which is the documented upgrade path and the only one: re-run
  `/repo-standard-toolkit:identity`, or copy the current generator and paste what it prints. The
  check is new, so no repo can already be carrying the block.
- **`pills[].href`, which is what a pill links to.** Optional, for the same reason
  `brand.homepage` is: a claim with no real destination renders as a bare image instead of
  pointing at an invented page. Written as it appears in the README rather than from the repo
  root, and a relative one has to resolve to a real file, because a badge linking nowhere reads
  authoritative and is not. Previously the link target was hand-chosen in the README and nothing
  checked it at all.

### Changed

- **Grammar 2 now binds every check to the column its header names, including the link.** Three
  rules were still unbound behind the version: the link was searched for in ANY cell, so a row
  with an empty `File` cell and a link in its description counted as coverage; a table with no
  status column fell back to reading every cell, so renaming `Status` to `Phase` silently restored
  the grammar-1 rule the index had opted out of; and the same fallback let a date under `Added`
  answer for a `Last verified` column that does not exist. A missing header is now reported as a
  gap in the page rather than treated as permission to read another column.
- **Every configured path goes through one registry rather than one call site at a time.** The
  containment contract was arrived at key by key, which is why it kept leaking: `versionManifest`,
  `ignore.file`, `ignore.generated`, `assets.coverage.roots`, `assets.coverage.ignore`,
  `prose.exempt[].path`, `counts.*.docs`, `counts.*.file` and `counts.*.glob` were each read,
  walked or globbed outside the repository while the gate reported green about a tree it does not
  govern. The asset manifest's own paths (`banners[].dir`, a pill's `source.file`, a relative pill
  `href`) go through the same contract, replacing a hand-rolled half-rule that checked for a
  leading slash and a `..` segment and missed backslashes, drive letters, empty components and
  every symlink. **Spelling is judged before normalisation**, because a normaliser that runs first
  repairs the very spelling the contract exists to refuse.
- **Identity no longer authors indexes at all.** It previously declared the block, named the
  uncatalogued files, wrote an `ignore` entry or a provisional row for each, and edited
  `docs.extra`, then admitted in its own hand-off note that those rows came from a directory
  listing and needed Atlas to re-author every one. Two authoring paths for one artifact, with the
  weaker one running first: the operator got an index that satisfied the gate, read as finished,
  and described files nobody had opened. Identity now owns the manifest, the artwork and the
  generated markup; Atlas owns index placement, content and configuration.

- **A pill's alt text is now its whole claim.** `![VERSION: 0.6.0](...)` rather than
  `![Version](...)`: a reader who cannot see the plate gets nothing from the label alone, and the
  colon is already the only separator this system uses. It is joined by the same `altText()`
  helper that joins a banner's title to its description.
- **Every index in this repo is now written by the journey rather than by hand**, including a
  sixth one: `payload/README.md`, whose prose table of backticked paths became a catalog with a
  row per installed file. Seven agents read 52 files across six directories. The five hand-written
  indexes were replaced, and the point of replacing tables that were already good is that
  reproducibility is the property being tested, not effort.
- **The row grammar mandates ascending path order and a backticked path as the link text.** Both
  were open questions in `docs/design.md` and both are settled on reproducibility: a later pass by
  a different agent has to produce a diff rather than a rewrite. Three of the five hand-written
  indexes used authored order and human titles, which is exactly the divergence a hundred agents
  would produce.
- **The reconciliation line names who did the reconciling**, as
  `Reconciled against the code: 2026-07-31 (agent sweep)`, with `(by hand)` as the other value. A
  bare date implied a reading that a fan-out does not do. A partial edit afterwards changes
  neither the date nor the parenthetical, because the claim is index-level and editing three rows
  does not reconcile an index.
- **`acceptance/test-github-about.mjs`**, closing the hole the sweep opened. The engine had one
  narrow guard on its tagline parse, and everything else it does was unguarded, including the
  shape of the payload every consumer reads. Both new cases fail on the pre-fix engine and pass
  on the fixed one, so the `topics: []` deletion is held by a red path rather than by a comment.
- **The atlas is offered to a repo that adopted it for one directory and stopped.** Adoption here
  is the one pillar that is not binary, and `declared > 0` read as `keep` retired the offer on
  exactly the repos with the most to gain. `sense-state` now reports `indexes.candidates`, the
  directories keeping a README and no index, cheaply and without reading a file, and `keep` means
  a tree with nothing left to cover. Measured on a real target: one index declared, nine
  directories carrying a README that explains nothing.

### Fixed

The first fan-out found these, and none of them is a lint failure, because no check reads a
comment and knows it is false. That is the point of the pillar rather than a caveat beside it.

- **A pill that was linked in the README and had no `href` in the manifest lost its link on the
  upgrade.** The block renders what the manifest says, and a manifest predating `href` says
  nothing, so every pill came out as a bare image in a paste that otherwise looked like a clean
  upgrade. Nothing catches it afterwards, because an unlinked pill is the correct rendering of a
  manifest with no `href`. The identity skill now reads those links out of the README into `href`
  before the paste, and diffs what it is replacing first. Found by walking the upgrade on a
  scratch copy of a real governed repo rather than in the repo itself.
- **Guards that claimed more than they held.** `test-templates-lint-green` filled a hardcoded
  list with nothing comparing it to the directory, so a template added tomorrow was ungated while
  the suite still said every template was proven; a new TG0 holds the list against what is
  shipped. `W6` claimed to check the licence id against the shipped LICENSE and hardcoded both
  sides, which failed a consistent relicense and passed a manifest that disagreed with its own
  file; it now derives the fingerprint from the manifest. `SC2` said it walked three directories
  recursively and walked one. `AG3` scanned a single hand-picked line and now scans every
  markdown surface the generator emits, the block included.

- **`github-about` proposed `topics: []` when it could derive no keywords**, in the same object
  that declares `topics: replace-whole-list`. A consumer applying the proposal verbatim, which is
  what the object invites, would have deleted every topic the repo had. An empty list is not a
  proposal to have no topics, it is the absence of a proposal, and the two now look different.
  `description: null` went the same way, which is the shape that already wedged a scaffold run
  once as `homepage: null`.
- **`install-hook` refused any `core.hooksPath` with a message asserting git ignores `.git/hooks`
  entirely**, which is false when the value resolves back there. The refusal stays conservative,
  because resolving the path properly and getting it wrong installs a file git never reads while
  reporting success. The message now says what was found rather than where git is looking.
- **The lint's own header described four checks it does not implement.** `RS-index` was documented
  as requiring a status and a date on every entry when both are opt-in and each prints a named
  skip, and as a docs check when it takes any extension over any number of directories.
  `RS-shadow` stated an absolute that exempts README. `RS-assets` said the front page "opens with"
  the generated block where the assertion is containment. `RS-voice` called itself the ban that
  reaches "everywhere, always" while being the narrowest of the four sweeps. The printed
  `RS-readme` name omitted Usage, which it enforces.
- **`.repo-standard.json` carried two em dashes inside `//` comment strings**, written as
  `—`, so no grep for the character found them and no lint reaches JSON. This repo lints its
  own prose at markdown reach and its own payload at every reach, and its own config was outside
  both.
- **Guard lists that had fallen behind their own files.** `test-assets-generator.mjs` listed AG1
  to AG8 while running thirteen guards. `test-voice-canon.mjs` claimed every payload file is
  clean at the widest reach while removing the Covenant template before scanning, which is the
  one exemption the payload does cost a consumer, and `skills/voice/SKILL.md` repeated the
  blanket version.
- **Cross-references stale by a whole pillar.** The scaffold's closing section still described two
  optional journeys after its step 12 grew a third, `sense-state` carried three different pillar
  counts in one file, and identity's index step mandated a column shape the atlas contradicts.
  Identity now defers the row grammar to the atlas and hands off to it, rather than pointing at
  manual paste-work for something a shipped skill does.

## [0.6.0] - 2026-07-31

**Never published.** Cut on a local branch, never tagged, never on the default branch the plugin
catalog follows. The date is the day it was cut. 0.8.0 is the first release to carry these
changes.

A preflight pass before pointing the toolkit at a large repository that does not follow these
conventions, and then the standard the run exposed as missing: a directory that says what each
file in it is for, held by CI. The findings all came from running the three journeys against a real target
(36 directories, 3 READMEs, 73 markdown files, 6,157 em dashes, an established `docs/INDEX.md`,
and two loud disables) rather than against a fixture, and every one of them is a case where a
fresh agent following the skill correctly would have produced a bad outcome.

### Fixed

- **`docs.index.requireDate` is off until you declare it.** It defaulted ON while the identity
  skill never named the key, so a repo whose index carries no date column had two green paths:
  invent a verification date for every row, or read the lint source to discover the opt-out. The
  first is the fabricated claim the check exists to prevent. Dates are now a named skip until the
  repo asks for them, matching how `statuses` already behaved. A repo that wants the old
  behaviour declares `"requireDate": true`, as this one now does.
- **`RS-index` matches a status by the word its cell begins with, not by the whole cell.**
  Surrounding code-span and emphasis marks come off first, so `` `REFERENCE` `` matches the
  declared word `REFERENCE` and `` `ACTIVE` (paused) `` matches `ACTIVE`. Whole-cell equality
  meant a mature index could only pass by transcribing every decorated cell verbatim, which is a
  per-row transcript rather than a vocabulary and reddens the moment anyone writes a new
  qualifier. It is deliberately anchored rather than a containment test: a purpose cell that
  happens to use the word must never stand in for a status nobody set.
- **A null `github.about.homepage` reads as absent.** The engine emits `null` for a repo that
  publishes no homepage of its own and the scaffold said to record the proposal as it stands, so
  the last step of the journey could wedge the gate at exit 2 with the engine's own output, after
  the recap had already reported green. The engine now omits the key instead, the lint accepts
  its absence, and an empty string stays an error, because it is the nearest exit for a stuck
  agent and it records a falsehood a later re-sync could push as a real blanking write.
- **`voice-scan` can answer the question the skill asks it.** At the default reach on a large
  repo the `--json` form was 53 KB and the first command the voice journey runs came back
  truncated mid-object, with no hit count anywhere in the surviving text. It now emits a `counts`
  block before the hit list, and carries `--summary`, `--files-only`, `--file`, and an opt-in
  `--limit` that reports what it withheld. The totals line prints first as well as last.
- **The voice journey can edit the files it offers to sweep.** Its `allowed-tools` reached 25 of
  the 72 files the `markdown` reach covers, so a sweep the operator had already approved would
  stall partway. The `all` reach still stops at markdown by design, and now says so at the gate
  where the reach is chosen rather than on the first blocked file.
- **The sweep loop runs on the scanner, not the gate.** `RS-prose` reports one hit per run
  because it is a gate, so "run the lint until it passes" was a drip of one sentence at a time.
  The scan is the sweep instrument and the lint is the single confirming run.
- **`sense-state` no longer reports `docs/README.md` as a shadow.** `RS-shadow` exempts it and
  the identity skill deliberately creates one, so a later scaffold re-run asked the operator
  which copy of their README was truth about a file this toolkit told them to write.
- **A pill could claim anything, and the provenance check would pass it.** This is the load-bearing
  promise of the identity pillar and it had a hole straight through the middle. The comparison was
  `value.toLowerCase().includes(truth.toLowerCase())`, and `includes('')` is true for every string,
  so any source regex whose capture group could match empty made the pill unfalsifiable. Proved
  end to end before fixing: a VERSION pill reading `99.99.99-TOTALLY-FABRICATED`, sourced from a
  regex that captured nothing, passed at 21 checks green. An empty resolution is now refused
  before the comparison rather than swallowed inside it. Three narrower holes went with it. A
  source regex must carry **exactly one** capture group, because the resolver reads group 1 and a
  two-group expression silently sourced the claim from whichever fragment came first. Every match
  in the file must **agree**, because first-match-wins meant inserting a line above the real one
  re-pointed the claim without touching the pill. And the sourced value must survive in the pill
  as a **whole token**, because bare substring matching let a truth of `90` pass a value of
  `1990%`: a coincidence wearing the clothes of a verified claim. A pill may still decorate what
  it sources, so `18` renders as `18+`. It may no longer be swallowed by it.
- **A long tagline no longer runs off both edges of its own banner.** The text solver sized the
  line with tracking held fixed and then clamped the result up to a readable floor, so past a
  certain length it handed back a size the width budget could not pay for. Every number in the
  file still looked reasonable, which is why only a rendered banner caught it: a 107-character
  tagline was drawn 1,326px wide inside a 1,040px line, centred, so it was cut off left and
  right at once. Size and tracking are now solved together and the pair that comes back always
  fits. Tracking is what gets spent first, which is what the code's own comment had always
  promised, and because the tracking was eating 530px the fixed line is also *larger* than the
  broken one: 15px where the clamp gave 12px. Underneath it was two bugs, not one, and the
  second is why the first went unnoticed for so long: both sub-text runs render UPPERCASE and
  were being measured with the mixed-case advance ratio, so the solver's own arithmetic
  understated every line it drew. Past the floor at zero tracking there is nothing left to
  spend, so the generator now refuses and names the length that would fit, rather than
  rendering a banner it knows is clipped. **No existing artwork changes**: every asset in this
  repo re-renders byte-identical, because the new path only engages where the old one had
  already overflowed.

### Added

- **An index is no longer a docs feature: any directory can say what each file in it is for, and
  CI holds it.** `docs.index` declared one catalog over one markdown tree. `docs.indexes` declares
  a list, each with its own directory and its own `extensions`, so `acceptance/README.md` indexes
  this repo's engines the same way `docs/README.md` indexes prose. Both spellings normalise to the
  same list, so nothing that declared the old key has to change. The property this buys is the one
  a summary README cannot give: a file added to a governed directory reddens the build until it
  has a row, so the glossary cannot quietly fall behind the tree it describes. This repo now
  dogfoods it over its own `acceptance/`, whose README was previously prose naming some of its
  files, which is the failure mode exactly: an incomplete table reads as a complete one.
- **The status vocabulary is canon, and a repo keeps its own words by mapping them.** The words
  are `active`, `superseded`, `reference`, `design`, and `delivered`, in whatever case a page
  writes them, so two governed repos are comparable rather than merely similarly shaped. Case is
  presentation and needs no declaration. A genuinely different word declares an `aliases` entry
  pointing at the canon one, which keeps `HONEST-ARTIFACT` on the page while the lint reads
  `reference`. Cell matching stays case-sensitive against whatever the index declared, so one
  index cannot drift between `Active` and `ACTIVE` while passing both.
- **`reconciled`: one recorded date for the whole index.** A date per row is one claim per row for
  somebody to defend, and on the day the index is generated they are all the same date anyway. On
  the repository that motivated this, whose `acceptance/` holds 89 standing tests, that is 89 of
  one fact. One line reading `Reconciled against the code: YYYY-MM-DD` is what a sweep over a
  directory can actually attest to. As everywhere else the lint checks the line exists and is
  well formed, never how old it is. `requireDate` still does per-row dates for an index that
  genuinely tracks them, and an index declaring neither says so as a named skip.
- **The identity journey adopts a documentation index it finds instead of writing a second one.**
  Step 5b was written purely as create-from-scratch, so a tree that already kept a catalog under
  another name got a new one beside it, each obliged to list the other. It now reads the existing
  index first, declares it, takes its status words from its own cells, and states plainly that
  adopting an index adopts its gaps: the omissions become CI failures the moment the block is
  declared, so they are named to the operator and either filled from documents actually read or
  listed under `ignore`. Renaming the index, reordering its columns, or restyling its cells to
  match ours is now explicitly prohibited.
- **The identity journey knows about `badges`.** The 0.5.0 live-badge feature was implemented,
  enforced, and documented everywhere except the one file a fresh agent executes, so a repo with
  an existing badge row got a palette-styled pill row bolted above three foreign-coloured badges.
  A new step 4b triages them at the same README read that finds the tagline: live status becomes
  a `badges` entry, a static fact becomes a pill with a real source (routing one through `badges`
  would launder it past the provenance rule, since the lint checks only that the line is present,
  never that it is true), and a claim with neither is offered for deletion. The GitHub-native
  `badge.svg` restatement is presented as a named trade rather than a syntax rewrite, and a badge
  with no shields equivalent is left exactly as it is.
- **The preview shows the badge line.** It renders the generated markdown and the plate colours
  rather than fetching anything, so the approval covers what will actually be written.
- **The ruleset offer describes what activating it does.** It was framed as the piece that makes
  a red run block, and it also requires a pull request for every change to the default branch
  with no bypass actors declared, so repo admins included, refuses force pushes and branch
  deletion, and requires a branch to be up to date before it merges. On a repo whose history is
  direct commits to main that changes how the operator works, and it belongs in the offer.
- **The scaffold runs the lint once more after its final write** and reports that verdict. Steps
  10 to 13 write and nothing re-read them, so a wedge introduced after step 9 was invisible.
- **An existing CI gate is measured, not just counted.** A hand-rolled workflow that runs the
  suite is kept, as before, but it is now read against the two properties the payload documents
  (SHA-pinned actions and a `merge_group` trigger), the gaps are named, and the operator chooses
  a shown diff or a verbatim replacement. Never a second workflow: both variants name their job
  `test`, so a second one doubles every run and makes the required-check binding ambiguous.
- **`writeSemantics` in the About payload.** The caution that GitHub replaces the whole topic
  list on write was printed only in human mode while the skill mandates `--json`, so the one
  destructive-semantics warning was invisible in the mode actually used. It is now a per-field
  statement in the payload itself, emitted from a single constant both output modes read.
- **A recorded decline survives a delegated journey.** The scaffold handed off to a pillar and
  never came back, so an operator who accepted the offer and then declined inside the pillar left
  nothing recorded and got asked again next session. Recording it still takes an explicit yes: a
  durable never-ask-again is a decision the operator makes, not one inferred from a pillar
  walking away.

### Changed

- **Grammar 2 now binds every check to the column its header names, including the link.** Three
  rules were still unbound behind the version: the link was searched for in ANY cell, so a row
  with an empty `File` cell and a link in its description counted as coverage; a table with no
  status column fell back to reading every cell, so renaming `Status` to `Phase` silently restored
  the grammar-1 rule the index had opted out of; and the same fallback let a date under `Added`
  answer for a `Last verified` column that does not exist. A missing header is now reported as a
  gap in the page rather than treated as permission to read another column.
- **Every configured path goes through one registry rather than one call site at a time.** The
  containment contract was arrived at key by key, which is why it kept leaking: `versionManifest`,
  `ignore.file`, `ignore.generated`, `assets.coverage.roots`, `assets.coverage.ignore`,
  `prose.exempt[].path`, `counts.*.docs`, `counts.*.file` and `counts.*.glob` were each read,
  walked or globbed outside the repository while the gate reported green about a tree it does not
  govern. The asset manifest's own paths (`banners[].dir`, a pill's `source.file`, a relative pill
  `href`) go through the same contract, replacing a hand-rolled half-rule that checked for a
  leading slash and a `..` segment and missed backslashes, drive letters, empty components and
  every symlink. **Spelling is judged before normalisation**, because a normaliser that runs first
  repairs the very spelling the contract exists to refuse.
- **Identity no longer authors indexes at all.** It previously declared the block, named the
  uncatalogued files, wrote an `ignore` entry or a provisional row for each, and edited
  `docs.extra`, then admitted in its own hand-off note that those rows came from a directory
  listing and needed Atlas to re-author every one. Two authoring paths for one artifact, with the
  weaker one running first: the operator got an index that satisfied the gate, read as finished,
  and described files nobody had opened. Identity now owns the manifest, the artwork and the
  generated markup; Atlas owns index placement, content and configuration.

- The scaffold installs the lint before writing the scope, because the lint defines the key space
  the scope is written into. Writing a newer config first left a repo governed by an older
  committed lint failing on keys it had never heard of, mid-journey.
- `docs/configuration.md` documents `github.about`, which was a known key with no section and no
  entry in the payload config that the scaffold tells the agent to work from.
- The coverage claim is corrected everywhere it appeared: `assets.coverage.roots` checks the
  immediate subdirectories of each declared root, one level deep, and a nested directory is
  reached by naming it as a root of its own. The docs promised every directory underneath.
- `docs/enforcement.md` attributes the gate's triggers and SHA pinning to the workflow this
  toolkit ships rather than to whatever is installed, and states the real condition under which
  the `RS-about (live panel)` skip prints.
- The Contributor Covenant exemption the voice skill raises in advance is keyed to the scan
  rather than asserted: "In order to honor these values" is Covenant 3.0 text, and 2.1 carries no
  banned term and no em dash at all. An exemption for a file with nothing to exempt is a line
  printed on every run forever.
- `harness/README.md` lists all seven engines. It had six.

## [0.5.0] - 2026-07-31

### Added

- **Live badges are part of the identity now, not a foreign object beside it.** A build status
  cannot be rendered locally, because a static "passing" is a claim that can never go red, which
  is the failure this toolkit exists to prevent. So the status stays live and third-party and the
  palette governs how it looks: declare it under `badges` in the manifest with the shields path
  after the host, and the generator appends the repo's own colours. `RS-assets` checks the README
  carries that exact line, so a badge row cannot drift back to a stranger's default palette. Two
  limits are stated rather than designed around. Shields exposes the two plate colours and
  nothing else, so a live badge will always differ in height, letter case, font, and label text
  colour however it is styled. That is a real trilemma (live status, pixel-matching, honest
  claims: pick two), and the resolution is to stop implying a match rather than to force one:
  live badges take the palette and sit on their own line, so a reader sees two kinds of claim
  instead of one broken row.
- **`RS-about` and `harness/github-about.mjs`: the panel a stranger reads before the README.**
  The GitHub About section is the one part of a repo's surface no committed file governs, so it
  rots quietly, keeping a description written before a rewrite and topics from a previous
  product. The engine derives what it should say from what the repo already states about itself,
  and never invents: the description is the README's bold tagline, so the panel inherits the
  writing standard rather than needing its own, and a field it cannot source is reported as
  missing with the file it would have read. The scaffold's new step 13 shows a real diff against
  the live panel and applies only on a yes.
  Two hazards the first live run surfaced, both now designed against. **Topics REPLACE the whole
  list on write**, so the skill proposes the union and never removes a topic the operator
  curated, because a discoverability topic is not derivable from any file in the tree. And a
  field that could not be derived is left alone rather than blanked.
  The lint takes no network by a rule older than this feature, so `RS-about` holds the offline
  half: the recorded description still matches the repo's own tagline, and editing the tagline
  makes the record go stale, loudly, with a re-sync as the fix. What it cannot see prints as a
  named skip on every run rather than being left for someone to assume.

### Fixed

- The tagline was read as the first LINE after the H1 rather than the first bold SPAN, so a
  tagline wrapped across lines was cut mid sentence and carried a stray bold marker into what
  would have been published as the repo's GitHub description. Found by running the engine against
  this repo, whose own tagline wraps. Fixed in the lint and the engine together, and `VS9` now
  fails the build if the two ever read a tagline differently, since a check that disagreed with
  the engine that fed it would redden on prose nobody touched.

## [0.4.0] - 2026-07-30

### Added

- **Identity, the second pillar.** A repo can now generate its README artwork from one manifest
  and have the lint keep it true. `payload/assets/generate.mjs` renders a root banner, a banner
  per folder README, and a pill row from `.github/assets/manifest.json`: fixed geometry over a
  fifteen-role palette named for what each colour does in the artwork rather than what it is,
  with type fitted so a twenty-letter project name does not run off the canvas. Three palette
  presets ship (`forest`, `violet`, `slate`), all proven to clear the contrast floor. The new
  `RS-assets` check runs in three named legs: the manifest is complete and readable, every asset
  re-renders byte-identical (the lint imports the repo's own generator, so "we regenerate the
  artwork" becomes an enforced property instead of a habit), and every declared README carries
  the exact generated H1. Every pill records the file its value was read from and is re-verified
  on every run; a pill with no single source of truth declares `"source": false` with a reason
  and prints as a named skip forever. A palette derived from a repo's own design tokens records
  the token and value per role, so a rebrand is reported as drift instead of leaving the banners
  representing a product that changed.
- **The `identity` skill** (`/repo-standard-toolkit:identity`), the journey behind that pillar.
  It asks rather than assumes, derives a palette from the repo's own design system where one
  exists, offers a preset where it does not, and shows a rendered preview (every banner
  animating on both of GitHub's page backgrounds, the palette with each role's job named, the
  measured contrast of all nine enforced pairs) before a single byte lands in the tree.
- **`harness/derive-palette.mjs`**, which reads CSS custom properties, SCSS and LESS variables,
  Tailwind and theme config, design-token JSON, and the declared theme colour, and maps what it
  finds onto the fifteen roles with file, line, token, and value recorded per role. It refuses
  rather than inventing: below six named colours it reports that there is no design system here
  to read and exits non-zero. Contrast is repaired to clear the 4.5:1 floor and every nudge to
  someone's brand colour is stated. A role derived by transform is never recorded as one the
  lint could re-verify.
- **`harness/preview-assets.mjs`**, which renders a manifest to one self-contained page written
  outside the repository. Previewing is not scaffolding.
- **Voice, the third pillar.** `RS-prose` enforces the enterprise writing standard as a
  deterministic check: no em dash in any form (the character, its HTML escapes, or a spaced en
  dash doing the same job) and no filler or AI-writing tells, from a canon list small enough
  that a hit is never a judgment call. Opt-in per repo, canon once on. Reach is `docs`,
  `markdown`, or `all`. The two rule families reach different distances on purpose: dashes go as
  far as the reach says, and filler stops at markdown, because in source `leverageRatio` is an
  identifier rather than register and the file declaring the ban list necessarily contains every
  word in it. Quoted and backticked mentions, fenced code, generated assets, the license file,
  and released CHANGELOG history are out of scope by design, and everything else exempted prints
  its reason on every run. Multi-word terms match across line breaks, because a hard-wrapped
  paragraph splits a phrase over two lines and a per-line scan would report the repo clean.
- **The `voice` skill** (`/repo-standard-toolkit:voice`) and **`harness/voice-scan.mjs`**, the
  guided sweep. The engine reports every hit at once, grouped by file, using the repo's own
  declared scope so a pre-adoption sweep looks exactly where adoption will look. The skill
  sweeps first and locks second, always in that order, preserving meaning over style: a rewrite
  that changes what a sentence claims has introduced a factual error under cover of a style
  pass. A standing test parses both files and fails the build if the sweep's rule lists and the
  lint's ever differ.
- **Trust, in the scaffold itself.** `payload/ignore/repo-standard.gitignore` and the new
  `RS-ignore` check encode the hygiene that has to exist before the file does: the whole `.env`
  family is ignored (a bare `.env` rule is the common half-fix that leaves `.env.local` and
  `.env.production` open), no negation re-exposes anything but an example file, and declared
  build output stays ignored and untracked. The tracked-file leg needs git and prints a named
  skip without it. This is ignore-rule hygiene and reads no file contents; secret scanning is a
  different product, and the docs say so in every place the line could blur.
- The banner `homepage` is optional. A repo with no remote and no product site omits it and
  gets an unlinked banner H1, because a link to an invented destination is the same fabricated
  claim as a CI badge for a workflow that was never installed. Found by running the journey
  against a blank repo, which had nowhere to point.
- `harness/sense-state.mjs` reports a declined offer as `declined` rather than `offer`, so the
  plan and the skill cannot disagree about whether to ask again. Found the same way.
- **`RS-index`, the catalog a documentation tree keeps of itself.** Where `docs.index` is
  declared, every document under it is listed with what it is for, what state it is in, and when
  a human last checked it against the code. The lint holds coverage (a doc nobody indexed is a
  doc nobody maintains, and that is how a docs tree rots), resolution (an index whose links have
  rotted reads authoritative and sends people nowhere), and the shape of each row. It never reads
  the clock: the date is a fact the repo records, and comparing it to today would make the same
  tree lint differently tomorrow. Deriving freshness from git history instead is worse rather
  than better, because a repo handed over as a single squashed baseline gives every file the same
  commit, which is exactly when a freshness signal earns its keep.
- Two new documentation pages, [Identity](docs/identity.md) and [Voice](docs/voice.md), and
  folder READMEs for `payload/`, `harness/`, `skills/`, `acceptance/`, and `docs/`, each governed
  by the same lint as the rest of the front matter. The `docs/` one is the tree's own catalog,
  declared as `docs.index` so `RS-index` holds its coverage and its links true here as well as in
  the repos this toolkit governs.
- A **Planned** section in the README and in [Design](docs/design.md), naming what is designed
  and not built: a truth pass (extract doc claims, verify each against the code, code wins), a
  handover mode (the guided clean-baseline ritual with an operator-gated force-push), and a
  docs-inventory classifier (runtime-consumed, operational, or history; propose-never-execute).

### Changed

- **Grammar 2 now binds every check to the column its header names, including the link.** Three
  rules were still unbound behind the version: the link was searched for in ANY cell, so a row
  with an empty `File` cell and a link in its description counted as coverage; a table with no
  status column fell back to reading every cell, so renaming `Status` to `Phase` silently restored
  the grammar-1 rule the index had opted out of; and the same fallback let a date under `Added`
  answer for a `Last verified` column that does not exist. A missing header is now reported as a
  gap in the page rather than treated as permission to read another column.
- **Every configured path goes through one registry rather than one call site at a time.** The
  containment contract was arrived at key by key, which is why it kept leaking: `versionManifest`,
  `ignore.file`, `ignore.generated`, `assets.coverage.roots`, `assets.coverage.ignore`,
  `prose.exempt[].path`, `counts.*.docs`, `counts.*.file` and `counts.*.glob` were each read,
  walked or globbed outside the repository while the gate reported green about a tree it does not
  govern. The asset manifest's own paths (`banners[].dir`, a pill's `source.file`, a relative pill
  `href`) go through the same contract, replacing a hand-rolled half-rule that checked for a
  leading slash and a `..` segment and missed backslashes, drive letters, empty components and
  every symlink. **Spelling is judged before normalisation**, because a normaliser that runs first
  repairs the very spelling the contract exists to refuse.
- **Identity no longer authors indexes at all.** It previously declared the block, named the
  uncatalogued files, wrote an `ignore` entry or a provisional row for each, and edited
  `docs.extra`, then admitted in its own hand-off note that those rows came from a directory
  listing and needed Atlas to re-author every one. Two authoring paths for one artifact, with the
  weaker one running first: the operator got an index that satisfied the gate, read as finished,
  and described files nobody had opened. Identity now owns the manifest, the artwork and the
  generated markup; Atlas owns index placement, content and configuration.

- **The scaffold is now a journey with two offers.** Its new step 8 installs or merges the
  ignore ruleset (append-only, every added line quoted), and its new step 12 names the identity
  and voice pillars and asks whether the operator wants either now. Silence is a no, and a
  declined offer is recorded in `scaffold.answers` so a re-run does not ask again: an offer
  repeated every session is a nag, and a nag is something people learn to click past.
- `harness/sense-state.mjs` now reports all three pillars: whether the repo's secrets are
  actually unstageable (naming the missing rules and any negation that re-exposes one), whether
  an identity is installed and whether its generator is current, and which writing profile is
  declared. The generator carries its own version constant, so a differing copy is directed the
  same way the lint's is, and a stale plugin is stopped rather than allowed to downgrade a newer
  committed generator.
- `RS-reflexivity` extends to the new pillars: a repo running the writing profile must document
  the em dash rule and every banned term where contributors will read them, and a repo with
  generated assets must document how they are regenerated, because a contributor who does not
  know will hand-edit an SVG and lose the work on the next run.
- **The whole payload is now profile-clean at every reach**, the lint's own commentary
  included, so a repo adopting the writing profile never writes an exemption for a file it did
  not author: an exemption for the checker's own text would be permanent noise in every
  consumer's lint run. The dash detectors are written with escapes, and the escape alternation is
  split, so no rule's own source matches it. The one standing exception is the Contributor
  Covenant text inside the CODE_OF_CONDUCT template, reproduced verbatim from an external
  standard and exempted with a printed reason rather than edited.
- This repo's declared reach is `markdown`, covering its entire published surface: front matter,
  docs pages, folder READMEs, and the three skill documents. The engines and the standing tests
  are JavaScript and stay outside it, and CONVENTIONS §5 says so rather than leaving it implied.
- This repo adopted all three pillars on itself, through the journeys rather than by hand: its
  own banner and five folder banners, its own docs catalog, its merged ignore ruleset, and the
  writing profile at `markdown` reach with two stated exemptions (the Contributor Covenant text,
  in the document and in the template that ships it, is reproduced verbatim, so editing it would
  misrepresent the standard this repo says it follows). The engines and the standing tests are
  JavaScript and deliberately outside the declared reach, and CONVENTIONS §5 says so rather than
  leaving the gap implied.
- The identity was rebuilt from a stripped tree as a cold-start validation, and every previously
  committed asset came back **byte-identical**. That is the reproducibility claim confirmed by
  observation rather than by assertion: the same manifest through the same generator produced
  the same bytes, so the only diff was the work that was genuinely new.
- The lint's check list grew from 14 to 18, and the standing suite from 11 tests to 14. Both
  numbers are machine-bound in the README, so neither can go stale.

### Fixed

- **`RS-shadow` no longer punishes the conventional documentation index.** README is the one
  governed basename with two jobs on GitHub: the front-page fallback, and the directory index
  rendered whenever anyone browses a folder. A `docs/README.md` beside a root README is the
  second job and hides nothing, but the check called it a duplicate, which was wrong hard enough
  that a governed repo switched the entire check off to keep its docs index. `docs/README.md` is
  now never a shadow; a `.github/README.md` beside a root one still is, and configuring the
  README into `docs/` while a higher-precedence copy exists still fails, because that one really
  is a page GitHub never serves.

## [0.3.0] - 2026-07-17

### Changed

- **Grammar 2 now binds every check to the column its header names, including the link.** Three
  rules were still unbound behind the version: the link was searched for in ANY cell, so a row
  with an empty `File` cell and a link in its description counted as coverage; a table with no
  status column fell back to reading every cell, so renaming `Status` to `Phase` silently restored
  the grammar-1 rule the index had opted out of; and the same fallback let a date under `Added`
  answer for a `Last verified` column that does not exist. A missing header is now reported as a
  gap in the page rather than treated as permission to read another column.
- **Every configured path goes through one registry rather than one call site at a time.** The
  containment contract was arrived at key by key, which is why it kept leaking: `versionManifest`,
  `ignore.file`, `ignore.generated`, `assets.coverage.roots`, `assets.coverage.ignore`,
  `prose.exempt[].path`, `counts.*.docs`, `counts.*.file` and `counts.*.glob` were each read,
  walked or globbed outside the repository while the gate reported green about a tree it does not
  govern. The asset manifest's own paths (`banners[].dir`, a pill's `source.file`, a relative pill
  `href`) go through the same contract, replacing a hand-rolled half-rule that checked for a
  leading slash and a `..` segment and missed backslashes, drive letters, empty components and
  every symlink. **Spelling is judged before normalisation**, because a normaliser that runs first
  repairs the very spelling the contract exists to refuse.
- **Identity no longer authors indexes at all.** It previously declared the block, named the
  uncatalogued files, wrote an `ignore` entry or a provisional row for each, and edited
  `docs.extra`, then admitted in its own hand-off note that those rows came from a directory
  listing and needed Atlas to re-author every one. Two authoring paths for one artifact, with the
  weaker one running first: the operator got an index that satisfied the gate, read as finished,
  and described files nobody had opened. Identity now owns the manifest, the artwork and the
  generated markup; Atlas owns index placement, content and configuration.

- The README template now carries a conditional CI-badge TODO: when the target repo has a
  GitHub remote, the scaffold inserts a badge for the exact workflow it installed (real slug
  from `git remote get-url origin`, real filename) above the tagline; a remote-less repo gets
  no badge — a badge pointing nowhere is a fabricated claim. A Documentation/docs-pages
  section is deliberately NOT templated: a greenfield repo has nothing to link, so the
  hub-and-spoke pattern lives in the skill's reconcile guidance (step 6) for READMEs that
  have outgrown their front page, with the RS-shadow basename and `docs.extra` governance
  rules spelled out.
- The README is now a hub, not a wall: deep-dive material moved to three governed docs pages —
  [Enforcement](docs/enforcement.md) (the 14 checks as a table, the ruleset, the hook),
  [Configuration](docs/configuration.md), and [Design](docs/design.md) (the load-bearing
  principle, the origin, and the deliberate rejections, now public instead of living only in
  commit messages). The README keeps Quick Start, the two-layer table, Caveats, and short
  linked summaries; a badge row (CI, release, license, dependencies-none) replaces nothing but
  says only what is live. The new pages are listed in `docs.extra`, so the voice ban, TODO
  sweep, placeholder sweep, and shadow check govern them like every other meta doc, and the
  status line's "14 lint checks" is a machine-bound count against the lint's own check
  header — the stat line that cannot go stale.

### Fixed

- The README's install instructions and two test comments pointed at the catalog's pre-rename
  repo name (`runverdict/claude-plugins`). The canonical catalog repo is `runverdict/plugins`
  — the old name resolved only through GitHub's rename redirect — and the wiring test now pins
  the canonical name.
- Public-readiness pass (adversarially reviewed before flipping the repo public): two "cannot
  merge" blocking overclaims that survived the 0.2.0 honesty scrub in CONVENTIONS §3 and
  CONTRIBUTING now say what is true (a violating template reddens the build); RS-license's
  documentation claimed "every manifest" when the check reads the two JSON manifests — all
  five statements of that claim (docs, template, lint header) now name exactly what runs;
  provenance links to the private parent toolkit are de-linked (they 404 for public readers);
  the standing-tests count scan is scoped to the README so the dated 0.2.0 block stays
  historical; the suite descriptions in acceptance/README and two test headers caught up with
  reality (no marketplace manifest, SS8/SS9 documented); the skill gains the plugin-manifest
  edit grant its backfill step documents, plus cross-link guidance for docs living at
  non-root locations; and the templates stop attributing the bold tagline and Caveats section
  to standard-readme — they are house additions, now labeled as such.

## [0.2.0] - 2026-07-17

### Added

**The generic enforcement core** (`payload/acceptance/test-repo-standard.mjs`)
- The proven project-meta lint from `ai-readiness-review-toolkit` (a private Verdict toolkit;
  PM1–PM8), generalized into a configurable, dependency-free standing test any repo commits and
  runs in CI with `node` alone: Keep a Changelog categories + shape + semver ordering
  (RS-changelog), CHANGELOG ⟺ version-manifest lockstep (RS-lockstep), standard-readme
  structure with License last (RS-readme), contiguous numbered CONVENTIONS sections
  (RS-conventions), manifest Totals reconciliation (RS-manifest), the marketing-voice ban
  (RS-voice), declarative machine-checked counts (RS-counts), lint ⟺ spec reflexivity
  (RS-reflexivity), stable meta files (RS-stable-docs), and no surviving `TODO(scaffold)`
  markers (RS-todos).
- `.repo-standard.json` — the per-repo scope config. The canon is hardcoded in the lint; config
  tunes scope only: doc paths (README pinned to GitHub-rendered locations), an optional
  reconciled manifest, extra required README sections, extra banned words (each must be
  documented in CONVENTIONS — enforced), `properNouns` voice exemptions (printed on every run),
  and counts as `pattern` + source of truth (`glob`, `file`+`lineRegex`, or agreement-only) with
  `minMentions` and `under` region scoping so historical numbers in dated CHANGELOG blocks stay
  historical. Unknown keys, bare-false disables, and unsupported versions are hard errors:
  exit 2 (fix the config) is a distinct failure class from exit 1 (fix the docs). A disabled
  check requires a stated reason and prints it on every run; every skip is a named line.
- `payload/workflows/repo-standard.yml` — the CI gate (read-only token, runs every
  `acceptance/test-*.mjs`).

**The scaffolder** (the agent half — never in the enforcement loop)
- `skills/scaffold` — senses greenfield vs. mid-project vs. governed, confirms the plan,
  scaffolds missing artifacts from the templates, reconciles drifted ones with minimal quoted
  edits (never clobbering prose), installs the lint + config + CI gate verbatim, and verifies to
  green. Idempotent: re-running senses the tree and reconciles; it never duplicates and never
  force-overwrites.
- `harness/sense-state.mjs` — the read-only inventory + deterministic classification and
  per-artifact action plan (scaffold / audit / install / upgrade / keep), with placeholder
  derivation from git and manifests.
- `harness/fill-template.mjs` — deterministic placeholder fill: refuses an unfilled
  placeholder, an unused key, and an un-forced overwrite, so a scaffold can never be silently
  partial.
- `harness/install-hook.mjs` + `payload/hooks/pre-push` — an **optional** local pre-push check,
  offered (never assumed) once a repo is governed and green. It runs the repo-standard lint and
  nothing else — not the repo's own test suite — so drift fails in the terminal instead of in CI
  a minute later. It is a **convenience, not a gate**, and is installed uncommitted into
  `.git/hooks/` precisely because a per-clone, `--no-verify`-skippable hook that a fresh clone
  never gets can never be enforcement; committing it would imply otherwise. The engine refuses
  rather than surprising anyone: a foreign pre-push hook is never clobbered, a `core.hooksPath`
  pointing elsewhere is reported instead of writing where git will never look, and an ungoverned
  repo is turned away. There is deliberately **no** push-time prompt to adopt the standard:
  adoption is a reviewed change that deserves its own session, not an interruption of unrelated
  work.
- `payload/templates/` — standards-grounded fill-in artifacts: standard-readme README, Keep a
  Changelog CHANGELOG, numbered CONVENTIONS (with the meta-docs-standard section the
  reflexivity check requires), CONTRIBUTING, Contributor Covenant 3.0 CODE_OF_CONDUCT,
  SECURITY, and Apache-2.0 / MIT license texts.

**The proof that it holds** (11 standing tests, zero npm dependencies)
- Mutation coverage of every lint rule: a known-clean fixture passes, then one targeted
  violation per rule must redden with the right check named — including the exemptions
  (quoted/fenced/properNouns) staying green and the exit-class split staying 2 vs 1.
- The scaffold → gate loop, mechanically: every template filled through the real engine,
  `TODO(scaffold)` resolution proven load-bearing, the result green under the shipped default
  config.
- Payload ⟺ dogfood byte-identity (this repo runs the exact lint + workflow it ships), engine
  behavior suites for `sense-state` and `fill-template`, skill wiring (engines exist and are
  granted; payload references exist), CHANGELOG ⟺ plugin.json lockstep, and supply-chain
  posture (no `package.json` anywhere, stdlib-only imports, least-privilege CI tokens — for
  this repo and for what gets installed into targets).
- Validated during development against the parent toolkit's real meta docs: the generic lint
  reproduced the proven repo-specific lint's verdict on the same tree, including catching the
  same live count drift (a development-time run; the standing in-tree proof is the mutation
  coverage above).

**This repo governs itself** — `.repo-standard.json` + the installed lint copy + the CI gate,
from the first push: the standard the plugin installs is the standard it lives under.

**RS-license — the LICENSE file joins the enforced set**
- The one scaffolded file the lint could not govern (a license text has no H1, so
  RS-stable-docs cannot hold it) was deletable while CI stayed green. The new `license` check
  requires a root license file (LICENSE / LICENCE / COPYING families, `.md`/`.txt` accepted),
  requires it non-empty, fingerprints the text with the same heuristics `sense-state` uses, and
  — when the text is a recognizable standard license — requires each JSON manifest it reads
  (`.claude-plugin/plugin.json`, `package.json`) that declares a `license` field (string form
  only; the deprecated npm object/array form reddens) and the README's License section to name
  the same id, GNU `-only`/`-or-later` suffixes accepted. What cannot be compared is a named skip, never an implied agreement: an
  unrecognized text skips the whole agreement leg, a manifest with no license field skips the
  manifest leg. The fingerprint knows MIT-0 and refuses to guess MIT from the shared grant
  sentence alone — a text is recognized by what distinguishes it, or it is `unrecognized`.

**RS-placeholders — hand-copied templates cannot pass half-filled**
- `fill-template` refuses an unfilled placeholder, but a template copied by hand never meets
  the engine. The new `placeholders` check reddens on any surviving `{{PLACEHOLDER}}` token in
  a governed doc or the license file — fenced code blocks deliberately included, because
  fenced install/usage examples are exactly where template placeholders live. Inline-code and
  quoted mentions stay exempt in prose only; inside a fence a quote is code syntax (a JSON
  example quotes its every value), so fences are scanned raw.

**RS-shadow — one governed copy per doc, and sensing that knows where docs live**
- GitHub serves README and every community health file with precedence `.github/` > root >
  `docs/`, so a stale copy in a higher-precedence location replaces the governed one on the
  repo page while the content checks stay green. The new `shadow` check reddens when a
  governed doc's basename — README, changelog, conventions, stable docs, the manifest doc, and
  `docs.extra` alike — exists in more than one of the three locations. `sense-state` senses
  the same three locations: a doc living only in
  `.github/` is audited (never re-scaffolded at root), the sensed path is reported, and a
  cross-location duplicate prints a DUPLICATE warning; the skill reconciles a doc where it
  lives and leaves resolving duplicates to the operator.

**Recorded scaffold provenance** (`.repo-standard.json` → `scaffold`)
- The skill records which plugin version produced the repo's governance and the operator's
  confirmed answers in a `scaffold` block (`{ pluginVersion, answers }`): a re-run pre-fills
  its questions from the block and re-asks only what is missing, `sense-state` reports the
  recorded version ("scaffolded by plugin 0.1.0"), and the repo can answer "which standard
  version governs me?" with the plugin gone. The lint validates the block's shape (semver
  version, PLACEHOLDER → string answers) and never varies enforcement by it.

**Version-directed lint upgrades**
- The payload lint now carries a machine-readable `REPO_STANDARD_LINT_VERSION` constant
  (printed on every run, locked to the plugin version by a standing test). When an installed
  lint differs from the payload, `sense-state` reads the constant from both copies and directs
  the move — `upgrade` (payload newer), `downgrade` (payload older: a loud stale-plugin
  warning, and the skill stops rather than regressing the committed gate while calling it an
  upgrade), or `local-edit` (same version, different bytes: diff and ask). Byte-difference
  alone can no longer be mislabeled an upgrade.

**The gate cannot be wedged or hijacked** (`payload/workflows/*`, `payload/rulesets/`)
- Both payload workflows now trigger on `merge_group` alongside push and pull_request — the
  moment the acceptance check is made required on a repo using a merge queue, queued PRs wait
  on checks fired by the queue's own event, and a workflow without the trigger deadlocks the
  queue.
- `actions/checkout` is pinned to a full commit SHA (verified against the upstream tag, named
  in a trailing comment) instead of a movable tag — OpenSSF Scorecard's Pinned-Dependencies —
  and `actions/setup-node` is dropped entirely: the lint and suite run on Node built-ins
  (18+ floor) and every ubuntu-latest image ships a newer Node on PATH, so the gate carries
  one less third-party action.
- `payload/rulesets/repo-standard.json` — a GitHub branch ruleset that makes the `test` check
  REQUIRED on the default branch (plus: no deletions, no force pushes, changes via PR, strict
  up-to-date checks). It ships `disabled` — fully configured but inert, POSTable on every
  GitHub plan (the `evaluate` dry-run mode is Enterprise-only, so it cannot be the default) —
  and flipping it to `active` is the operator's deliberate act. Every required check pins
  `integration_id` 15368 (the GitHub Actions app), so a hand-posted commit status cannot
  satisfy the gate. A standing test locks the required contexts and the workflows' job ids to
  the SAME SET, both directions — a phantom context would wedge every merge once active — and
  rejects job-level display names, which would change the check context out from under the
  ruleset.
- The scaffold skill offers the ruleset (new step 9, silence = no) once the suite is green —
  and probes first with a read-only ruleset GET, so the question only reaches operators whose
  plan can take it: GitHub gates rulesets on free-plan private repos, and an operator there
  gets the honest blocking-status line in the recap instead of a doomed offer. When the probe
  clears, the apply is idempotent (an existing `repo-standard` ruleset is never duplicated);
  without `gh`, the manual Settings path is printed. The pre-push hook, install output, and README no longer say
  "CI gates this push" — a workflow run without a required status check blocks nothing, and
  the honest phrasing now points at the ruleset that makes it block.
- A new `test-gate-posture` standing test pins all of the above.

### Changed

- **Grammar 2 now binds every check to the column its header names, including the link.** Three
  rules were still unbound behind the version: the link was searched for in ANY cell, so a row
  with an empty `File` cell and a link in its description counted as coverage; a table with no
  status column fell back to reading every cell, so renaming `Status` to `Phase` silently restored
  the grammar-1 rule the index had opted out of; and the same fallback let a date under `Added`
  answer for a `Last verified` column that does not exist. A missing header is now reported as a
  gap in the page rather than treated as permission to read another column.
- **Every configured path goes through one registry rather than one call site at a time.** The
  containment contract was arrived at key by key, which is why it kept leaking: `versionManifest`,
  `ignore.file`, `ignore.generated`, `assets.coverage.roots`, `assets.coverage.ignore`,
  `prose.exempt[].path`, `counts.*.docs`, `counts.*.file` and `counts.*.glob` were each read,
  walked or globbed outside the repository while the gate reported green about a tree it does not
  govern. The asset manifest's own paths (`banners[].dir`, a pill's `source.file`, a relative pill
  `href`) go through the same contract, replacing a hand-rolled half-rule that checked for a
  leading slash and a `..` segment and missed backslashes, drive letters, empty components and
  every symlink. **Spelling is judged before normalisation**, because a normaliser that runs first
  repairs the very spelling the contract exists to refuse.
- **Identity no longer authors indexes at all.** It previously declared the block, named the
  uncatalogued files, wrote an `ignore` entry or a provisional row for each, and edited
  `docs.extra`, then admitted in its own hand-off note that those rows came from a directory
  listing and needed Atlas to re-author every one. Two authoring paths for one artifact, with the
  weaker one running first: the operator got an index that satisfied the gate, read as finished,
  and described files nobody had opened. Identity now owns the manifest, the artwork and the
  generated markup; Atlas owns index placement, content and configuration.

- The scaffold skill's step-2 confirmation is now skippable when there is nothing to decide —
  every plan action `audit`/`keep` and no value missing — so a correct no-op re-run no longer
  has to interrogate the operator to approve nothing (previously the written step forced a
  pointless confirmation, and a correct run had to deviate from it).
- The skill's recap rules now require skips to be reported as skips ("N passed, 1 skipped
  (RS-lockstep: …)", N being whatever the lint printed), never folded into a pass count — a
  recap claiming "all checks pass" over a skipped check inflated exactly the claim this
  toolkit polices.

### Fixed

- The lint rejected Keep a Changelog's own `[YANKED]` vocabulary: the dated-heading rule
  anchored on the date, so a spec-valid `## [x.y.z] - YYYY-MM-DD [YANKED]` heading could never
  pass a lint that claims to enforce that spec. The heading grammar now allows exactly that tag
  (and nothing else after the date); the templates and CONVENTIONS document the yanked-release
  rule, and mutation cases prove both the allowance and that other suffixes still redden.
- `payload/hooks/pre-push` captured `$?` after an `if` statement, so the exit-2 branch was dead
  code (POSIX: a failed `if` with no `else` exits 0) and a broken `.repo-standard.json` was
  misdiagnosed as doc drift. The hook now runs the lint bare and captures the status on the next
  line; both diagnosis branches are fixture-proven — a broken config must print "fix the config,
  not the docs" and must not print the drift line.
