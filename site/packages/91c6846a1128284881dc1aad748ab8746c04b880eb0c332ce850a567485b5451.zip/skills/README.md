# [![skills/: The four journeys · scaffold, identity, voice, atlas](../.github/assets/banners/skills.svg)](https://github.com/runverdict/repo-standard-toolkit)

**Four journeys, one lint.** Each skill is a guided run an operator invokes as
`/repo-standard-toolkit:<name>`; each one ends by writing its scope into the same
`.repo-standard.json` and leaving the committed `acceptance/test-repo-standard.mjs` to hold the
result. The agent is out of the loop from then on, which is the point.

Only `scaffold` is required. The other three are **offers**, and the scaffold's step 12 asks rather
than assumes: generated artwork nobody asked for, a writing standard imposed on everything someone
has already written, or a fan-out reading a repository nobody agreed to spend, is not a service. A
declined offer is a finished run, not a failed one.

Reconciled against the code: 2026-07-31 (agent sweep)

| File | What it is for | Status |
|---|---|---|
| [`atlas/SKILL.md`](atlas/SKILL.md) | The opt-in glossary journey, in ten steps: price a fan-out from the planner's own counts, read every catalogued file in full, then merge the rows on one fixed grammar before a table is written. It refuses a row drawn from a listing or from a file's own header, will not start until the stated size is approved, and reports a lying header rather than repairing it. | `active` |
| [`identity/SKILL.md`](identity/SKILL.md) | The opt-in artwork journey, in nine steps plus 4b and 5b: one manifest, a committed generator, a palette read from the repo's own design tokens or a preset, pills pinned to a file the lint re-reads or openly declared unverifiable, and a catalog for a docs tree. Silence counts as a no, a repo with no design identity gets a refusal rather than an invented palette, and a downgrade stops the run. | `active` |
| [`scaffold/SKILL.md`](scaffold/SKILL.md) | The required front door, in thirteen steps: sense greenfield, partial or governed, fill missing meta docs from templates, install the lint before the config it validates, then the CI gate and the secrets ignore rules. It halts on a payload older than the committed lint, guesses no licence, contact or copyright holder, and asks for the ruleset, the hook, the other pillars, and the About panel. | `active` |
| [`voice/SKILL.md`](voice/SKILL.md) | The opt-in prose journey, in seven steps: price all three reaches before the operator picks one, sweep the chosen reach for em dashes in any form and the banned filler, rewrite hit by hit with diffs shown file by file, then lock the profile in the config. It will not lock over an unclean scan, will not loosen a standing test a rewrite turned red, and records a decline only on an explicit yes. | `active` |

Every skill here follows the same anatomy, and a standing test enforces it: frontmatter with
`name` (matching the directory), `description`, and the narrowest workable `allowed-tools`; then
a promise paragraph, **When to use** with its NOT-for bullets, **Prerequisites**, numbered
**Steps** that encode failure modes rather than happy paths, **Automated vs. manual recap**, and
**What feeds the next skill**. Every engine a skill invokes must exist and be granted; every
payload path it names must resolve. See [CONVENTIONS.md](../CONVENTIONS.md) §4.

The step counts above are the one claim in this table that no check holds. They are accurate as
of the reconciliation date and they will go stale the first time a journey grows a step, which is
the class of drift the planned truth pass in [Design](../docs/design.md#planned) exists to catch.
