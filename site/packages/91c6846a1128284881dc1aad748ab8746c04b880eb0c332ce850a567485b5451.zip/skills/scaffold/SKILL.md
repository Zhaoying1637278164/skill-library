---
name: scaffold
description: 'Bootstrap or reconcile enterprise repo hygiene in the current repo: sense greenfield vs. mid-project, scaffold the missing meta docs (README / CHANGELOG / CONVENTIONS / CONTRIBUTING / CODE_OF_CONDUCT / SECURITY / LICENSE) from standards-grounded templates, bring drifted ones into compliance without clobbering prose, and install the committed dependency-free lint + CI gate so the standard polices itself on every push with or without Claude. Idempotent, so it is safe to re-run on any repo at any maturity. Use on a fresh repo, on a repo whose front matter has drifted, or to adopt the standard mid-project.'
allowed-tools: Read Grep Glob AskUserQuestion Skill Bash(node *harness/github-about.mjs *) Bash(gh api repos/*) Write(.gitignore) Edit(.gitignore) Write(README.md) Write(CHANGELOG.md) Write(CONVENTIONS.md) Write(CONTRIBUTING.md) Write(CODE_OF_CONDUCT.md) Write(SECURITY.md) Write(LICENSE) Write(.repo-standard.json) Write(.github/workflows/*) Edit(README.md) Edit(CHANGELOG.md) Edit(CONVENTIONS.md) Edit(CONTRIBUTING.md) Edit(CODE_OF_CONDUCT.md) Edit(SECURITY.md) Edit(.repo-standard.json) Edit(package.json) Edit(.claude-plugin/plugin.json) Bash(ls *) Bash(mkdir -p acceptance*) Bash(mkdir -p .github/workflows*) Bash(cp *payload/*) Bash(git status*) Bash(git log *) Bash(git remote *) Bash(gh auth status*) Bash(gh api repos/*) Bash(node *harness/sense-state.mjs *) Bash(node *harness/fill-template.mjs *) Bash(node *harness/install-hook.mjs *) Bash(node *generate.mjs*) Bash(node acceptance/test-repo-standard.mjs*) Bash(node acceptance/test-*.mjs*) Bash(for t in acceptance/test-*.mjs*)
---

# Scaffold

Bring the current repo up to the repo standard: the published-spec front matter (Keep a
Changelog, standard-readme, Contributor Covenant, SemVer) plus the **committed enforcement**
that keeps it true: `acceptance/test-repo-standard.mjs`, its `.repo-standard.json` scope config,
and the CI workflow that runs it on every push. The skill generates; the installed lint
enforces. After this session the plugin is out of the loop by design, and a contributor with vim
and no AI hits the same gate.

## When to use

- A greenfield repo that should start immaculate from push #1
- A mid-project repo adopting the standard: existing docs are reconciled, never clobbered
- A governed repo after drift, or after this plugin ships a newer payload lint (re-run = upgrade)
- NOT for code linting, tests, or security review; this governs repo front matter only
- NOT a substitute for reading the generated prose: the operator reviews everything this
  skill writes before it is committed

## Prerequisites

- The target repo is the current working directory (any language: the enforcement needs only
  Node 18+ in CI, nothing else changes)
- Nothing else. The skill senses state itself; never assume a prior run.

## Steps

1. **Sense, never assume.** Run
   `node ${CLAUDE_PLUGIN_ROOT}/harness/sense-state.mjs --target . --json`
   and read the classification (`greenfield` / `partial` / `governed`), the per-artifact plan,
   and the `derived` values. Re-run this even if you scaffolded this repo earlier in the same
   conversation, because idempotency comes from sensing the tree, not from remembering what you did.
   The report also carries the pillars beyond the front matter: `enforcement.ignore` (are the
   repo's secrets unstageable?), `enforcement.assets` (a generated identity, and whether its
   generator is current), `enforcement.prose` (a declared writing profile), and
   `enforcement.indexes` (which directories say what each file in them is for). A plan action of
   `offer` means exactly that: the repo has not adopted it and the operator gets ASKED, at step
   12, never told.

2. **Confirm the plan with the operator, unless there is nothing to decide.** When every plan
   action is `audit` or `keep` and no step-2 value is missing, the run is a no-op reconcile:
   skip the confirmation and the questions entirely, proceed, and say so in the recap:
   interrogating the operator to approve nothing is noise, not diligence. Otherwise present
   the classification, the plan table, and the derived placeholder values. Ask
   (AskUserQuestion) for what is genuinely theirs to decide:
   license (`Apache-2.0` recommended default / `MIT` / keep existing), the **copyright holder**
   (the LICENSE line and the README's `© holder` footer, which is legally meaningful and never guessed;
   suggest the git author or org name as the option, but they choose), the security-report and
   code-of-conduct contact addresses, and the tagline if none is derivable. The copyright YEAR
   comes from the repo's first commit (`git log --reverse`) or, for a repo with no history,
   from the operator. Never invent a contact address, and never guess a license for a repo that
   already has one; `sense-state` derives it from the manifest or a recognizable LICENSE text
   (`derived.licenseId`; an `unrecognized` value means read the LICENSE file yourself and
   confirm with the operator). If a value is unknowable and the operator is absent, leave the
   placeholder-bearing artifact unscaffolded and say so in the recap rather than shipping a
   fabricated value. On a re-run, the sense report's `enforcement.config.scaffold.answers`
   block holds the values a previous run recorded as operator-confirmed: reuse them, name each
   reused value in the recap, and ask only for what is missing or newly needed. Never
   re-interrogate the operator for a contact they already gave, and never reuse a value the
   recorded block does not carry.

3. **Install the lint first, because it defines the scope's key space.**
   `mkdir -p acceptance && cp ${CLAUDE_PLUGIN_ROOT}/payload/acceptance/test-repo-standard.mjs acceptance/`
   The lint that will govern the repo goes in before the config that lint validates: a scope
   written for a newer lint is an unknown-key hard error to an older one, and a failing
   RS-config suppresses every doc check (exit 2), so the repo's own gate would sit wedged for
   the rest of the run. On a greenfield repo nothing is installed and the ordering costs
   nothing; on a `keep` it is a no-op; on a `downgrade` the run stops here, before a config
   exists in a shape the retained lint cannot read.
   The payload file is copied byte-identical, and never hand-edited into a target (repo-specific
   scope belongs in the config; a forked lint stops being upgradeable). When an installed copy
   differs from the payload, `sense-state` DIRECTS the move from the version constant each lint
   carries. Obey the direction; it exists because byte-difference alone cannot tell newer from
   older:
   - `upgrade` (payload newer): check `git status` for that path FIRST, because uncommitted local
     edits would be unrecoverable, so surface them and get the operator's go-ahead before
     replacing; a committed old copy is safely replaced (git keeps the history). Either way
     the replacement is named in the recap, with both versions.
   - `downgrade` (payload OLDER than the committed lint): **stop.** The installed plugin is
     stale; replacing would regress the repo's gate while looking like maintenance. Tell the
     operator their plugin is older than what governs the repo, tell them to update the plugin,
     and touch nothing. Replace only if they explicitly ask for the downgrade after hearing
     that, and record that choice in the recap.
   - `local-edit` (same version, different bytes): someone hand-edited a copy. Diff the
     installed lint against the payload, show the operator what changed, and proceed only on
     their call: an edit may be a hotfix worth keeping until the next payload release.

   **The lint is not the only engine this toolkit commits into a repo, and the other one drifts
   the same way.** A repo that has adopted the identity pillar carries
   `<assets.dir>/generate.mjs`, which also has a version constant and also goes stale when the
   plugin moves. `sense-state` emits a plan action for it beside the lint's, and this step
   consumes BOTH: `install`, `upgrade`, `downgrade`, and `local-edit` mean exactly what they mean
   above, with the same git-status check before replacing an upgraded copy and the same hard stop
   on a downgrade. (`offer` and `declined` are not drift; they belong to step 12, where an
   unadopted pillar is offered.) Leaving this action unread is what forced one run to work out
   the generator replacement for itself, mid-journey, on a repo it was supposed to be
   reconciling.

   **Replacing a generator is a change to the artwork, so PLAN it before applying it.** A new
   generator that moves a single rendered path rewrites every SVG in the tree, and doing that
   first and reading `git diff` afterwards puts the bytes on disk before anyone agreed to them.
   In order, and none of the four is optional:
   - **Check the tree is clean first.** `git status --short <assets.dir> README.md '**/README.md'`
     (`<assets.dir>` is `assets.dir` from the config, default `.github/assets`). Uncommitted work
     under any of those is work a re-render can overwrite. If anything is dirty, STOP and say so;
     the operator commits or stashes, and this step does not decide that for them.
   - **Plan with the PAYLOAD generator, pointed at the target.** Run:

     ```
     node "${CLAUDE_PLUGIN_ROOT}/payload/assets/generate.mjs" --check \
       --assets-dir '<assets.dir>' --repo '<repo root>'
     ```

     **Never `node <assets.dir>/generate.mjs --check` on an upgrade.** That is the INSTALLED
     generator, which is by definition the old one, and an old one does not know `--check`: it
     ignores the flag it has never heard of and WRITES. A run that previewed an upgrade that way
     performed the upgrade to preview it, which is the exact ordering this step exists to prevent.
     Only the payload copy can plan a replacement of itself, and `--assets-dir` / `--repo` are what
     let it read the target without being copied into it first. (Quote both paths: an `assets.dir`
     with a space in it becomes two arguments unquoted.)

     It renders every asset in memory, writes NOTHING, and lists each asset as `NEW`, `CHANGED`,
     or `DELETE`, names the READMEs that carry generated markdown, and exits 1 when anything would
     move. That list is the change set.
     **`ENGINE CHANGED` (or `ENGINE NEW`) is the first line of it when it appears, and it is the
     first write this sequence performs**: the payload generator has different bytes from the one
     installed in the target, the copy in the next step is what replaces it, and every asset line
     under it is what THIS engine renders rather than what the installed one would. It used to be
     absent from the list and from the exit code, so on a real target `--check` said "nothing
     changes" about a plan whose first act was to replace the engine that produced it.
     **A `STALE` line is a page, not an asset**: a README whose H1 points at a banner this manifest
     no longer declares. Applying the plan does not fix one, because this generator writes artwork
     and never edits a page. Read each of them out; the fix is a manifest entry or an ordinary
     heading, and it is the operator's call which.
   - **Read the preview before believing it, because silence is not a plan.** A real preview opens
     with `generate v<version> --check:` and closes with a total line. **Output that is empty, or
     that does not carry that preamble, is a preview that did not happen, and it is a STOP.** Say
     which command was run, say that nothing can be concluded from it, and do not copy the
     generator in. **Never read it as "nothing changes".** Invoked through a path it could not
     recognise as its own, this generator exited 0 having printed nothing, which is byte for byte
     what a repo needing no work looks like from the outside; the journey that read that silence
     as a no-op replaced the engine on the strength of a preview that had never run. The two
     states are not the same fact and must never be reported as one: an empty CHANGE LIST inside
     a well-formed plan is a repo that is up to date, and zero bytes is a plan nobody has.
   - **Get approval on that list before anything lands**, the same way every other write in this
     journey is approved. An empty change list inside a well-formed plan is the ordinary case on a
     same-version re-run, and it is worth saying out loud: "nothing changes" is the answer that
     makes the upgrade safe. **A
     `DELETE` line is destructive and needs saying out loud too**: it is an asset the manifest no
     longer produces, the lint fails while it sits there, and applying the plan removes it.
   - **Copy the generator in, then apply.** `cp "${CLAUDE_PLUGIN_ROOT}/payload/assets/generate.mjs"
     '<assets.dir>/generate.mjs'` and then `node '<assets.dir>/generate.mjs'` from the repo root
     writes the approved assets and removes the approved deletions. The generator then prints the
     README block and each folder README's H1: compare those bytes to what the pages carry,
     because a manifest change can move an H1 or the block with no SVG changing at all, and
     `RS-assets (idiom)` compares exactly those bytes. Re-run the lint afterwards and confirm
     `RS-assets (drift)` and `RS-assets (idiom)` are both green.

4. **Write the enforcement scope** (`.repo-standard.json`), so every later step can run the lint
   the repo will actually be governed by. Start from
   `${CLAUDE_PLUGIN_ROOT}/payload/repo-standard.json` (the default scope) and tune it to the
   repo, obeying its inline `//` doc keys. Write it for the version of the lint that is really
   installed: when the operator kept an older or hand-edited copy at step 3, the scope stays
   inside THAT lint's key space, and the recap names both versions.
   Declare a machine-checked count
   ONLY for a numeric claim with a countable source in this repo (e.g. `acceptance/test-*.mjs`
   for "N standing tests"); a count you cannot source is a lie the lint would then enforce.
   If the repo already has a `.repo-standard.json`, merge key-by-key and quote every change in
   the recap; operator customizations win over defaults. Record provenance in the same file:
   write (or update) the `scaffold` block: `pluginVersion` from
   `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`, `answers` holding exactly the step-2
   values this run used, keyed by placeholder name. Record only operator-confirmed values,
   never derived guesses. The block is what lets the next re-run skip the interrogation, and
   what lets the repo answer "which standard version governs me?" with the plugin gone.

5. **Scaffold what is missing.** For each `scaffold` action in the plan, fill the matching
   `${CLAUDE_PLUGIN_ROOT}/payload/templates/` file with
   `node ${CLAUDE_PLUGIN_ROOT}/harness/fill-template.mjs --template <tpl> --out <path> --set KEY=VALUE …`
   using the step-2 values (LICENSE uses `LICENSE-Apache-2.0.txt` or `LICENSE-MIT.txt`; the MIT
   year comes from `git log --reverse` or the operator, never from guessing). Do not pass
   `--force`: the engine refusing to overwrite means the plan is stale, so re-sense instead of
   forcing. `sense-state` reports WHERE each doc lives (`.github/` > root > `docs/`, GitHub's
   serving precedence). When a doc already exists at a non-root location, reconcile it there
   and never scaffold a root copy beside it: the lint's RS-shadow reddens on a doc duplicated
   across served locations, because GitHub silently serves the higher-precedence copy while the
   gate checks the other. A reported DUPLICATE is the operator's to resolve (which copy is
   truth?): ask, never delete on your own. The templates cross-link the meta docs at
   root-relative paths (README → CONTRIBUTING.md and CODE_OF_CONDUCT.md, CONTRIBUTING →
   CONVENTIONS.md and LICENSE); when a governed doc lives at a non-root location, correct
   those links in the filled output to the real path, because a scaffolded link must resolve.
   Then replace every `TODO(scaffold)` comment with real prose grounded in the actual
   repo: read the entry points, manifests, and code before writing Install/Usage/Background;
   SECURITY's GitHub-reporting bullet is added only when a real remote exists (its TODO says
   how), so a remote-less repo ships the email channel alone, never a fabricated link; the
   README's CI-badge TODO follows the same rule: the real slug and the workflow filename
   step 7 actually installed, or delete the comment. Never
   write a capability, benchmark, user count, or endorsement you cannot verify from the repo
   itself; an honest thin section beats a padded false one, and the Caveats section is where
   the limits go. The lint reddens on any `TODO(scaffold)` left behind, so an unfinished
   scaffold cannot pass CI silently. After scaffolding LICENSE, backfill the manifest's license
   field (`package.json` / plugin manifest) when one exists without it, because the manifest and the
   LICENSE file must agree, and the edit goes in the recap.

6. **Reconcile what exists.** Run `node acceptance/test-repo-standard.mjs` from the repo root.
   For a README that has outgrown its front page (long walls a first-time reader must scroll
   past), the recommended reconcile is hub-and-spoke: move deep-dive sections verbatim into
   linked `docs/` pages and keep short summaries, but the moved pages must avoid governed
   basenames (RS-shadow reddens a `docs/CONTRIBUTING.md` beside a root one; `docs/README.md` is
   the one exemption, because a documentation index is the conventional way to write one and
   punishing it drove a repo to switch the whole check off), should be added to `docs.extra` so
   the voice/TODO/placeholder sweeps govern them, and any test or count that pins README content
   must keep resolving. Never move what a standing check anchors to the README.
   For every failure on a pre-existing doc, make the smallest edit that satisfies the standard
   and preserve the author's prose: an ad-hoc CHANGELOG `### Notes` section is re-homed under
   the right canonical category (as bullets or a bold lead-in), never deleted; a stale count is
   corrected to the machine-derived number; a missing README section is added as a skeleton for
   the operator to fill, marked in the recap. Never rewrite a paragraph wholesale to "improve"
   it; voice violations get the minimal word-level fix. Every reconcile edit is quoted
   (before → after) in the recap; nothing is silent.

7. **Install the CI gate.** `sense-state` reports the gate as present only when a workflow runs
   the whole suite (the canonical for-loop) or the lint by name, because a workflow that happens to run
   one unrelated acceptance test is not a gate. When the plan says `install`: if the repo has
   other pre-existing `acceptance/test-*.mjs` files, run them ALL first. If any pre-existing
   test is red, install `${CLAUDE_PLUGIN_ROOT}/payload/workflows/repo-standard-scoped.yml`
   (verbatim, never hand-authoring workflow YAML) and tell the operator why: a gate must not be
   born red on someone else's tests. When they are green or absent, install
   `${CLAUDE_PLUGIN_ROOT}/payload/workflows/repo-standard.yml`, the full-suite gate with a
   read-only token. Destination filename is deterministic, not a choice:
   `.github/workflows/test.yml` when the repo has no workflows at all (the conventional name for
   a repo's only gate), else `.github/workflows/repo-standard.yml` (never collide with existing
   files). Never silently edit an existing workflow file. On a re-run, if the installed gate is the
   SCOPED payload variant and the full suite now passes, upgrade it to the full-suite workflow
   and say so in the recap: the scoped gate is a stopgap, not a destination.
   When the plan says `keep` and the gate is a hand-rolled file rather than a payload copy, read
   it against `${CLAUDE_PLUGIN_ROOT}/payload/workflows/repo-standard.yml` on the two properties
   the payload's own comments justify: every `uses:` pinned to a full commit SHA rather than a
   movable tag (a re-pointed tag is a supply-chain hole in the one file that gates everything
   else), and `merge_group` in the trigger list. A gate that runs the suite but lacks either is
   not a failure and not yours to rewrite: name the specific gaps and offer exactly two
   outcomes, a diff shown in full for the operator to apply to their own workflow, or replacing
   that file with the payload verbatim on an explicit yes. Never install a second workflow
   beside it: both payload variants name their job `test`, so GitHub would publish two check
   contexts called `test`, doubling every CI run and leaving step 10's ruleset binding ambiguous
   between them, satisfiable by the weaker of the two. If the operator takes neither, record it
   in `.repo-standard.json` under `scaffold.answers` (`GATE_HARDENING_OFFER`, value `declined`)
   so a re-run does not nag, and name in the recap which workflow is actually gating the repo.

8. **Install the ignore ruleset, the one hygiene rule the gate itself checks.** The lint's
   RS-ignore holds a single hard property: a secrets file can never BECOME trackable. Ignore
   rules have no effect on a path git already tracks, so the rule has to exist before the file
   does, and a bare `.env` line is the common half-fix that leaves `.env.local` and
   `.env.production` wide open. Read `enforcement.ignore` from step 1 and act on the plan:
   - `install` (no ignore file at all): copy
     `${CLAUDE_PLUGIN_ROOT}/payload/ignore/repo-standard.gitignore` to `.gitignore`.
   - `merge` (a file exists, the secrets rules do not hold): append ONLY the missing lines,
     under a comment saying where they came from. Never reorder or delete what is already
     there: someone put every one of those lines in for a reason you cannot see. Quote every
     added line in the recap.
   - `keep`: nothing to do, and say so.
   If `reopeningNegations` is non-empty, a `!` rule is re-exposing a real `.env` variant: that is
   the operator's line to remove, not yours to delete silently. Show it, explain what it does,
   and let them decide. If the tracked-file leg later reports a `.env` that is ALREADY committed,
   say plainly that ignoring it changes nothing, that the credentials in it should be treated as
   disclosed and rotated, and that `git rm --cached` is the operator's call. This is repo
   hygiene, not secret scanning: nothing here reads file contents, and the recap must not imply
   the repo was scanned for credentials.

9. **Verify to green, honestly.** Run `node acceptance/test-repo-standard.mjs` and iterate steps
   5 and 6 until IT exits 0, because that is the gate you installed and the only one you own. Then run the
   rest of the suite for information: a pre-existing test that was already red is the
   operator's, NOT yours to fix (that is exactly why step 7 scoped the gate); report it in the
   recap and stop; silently fixing someone's unrelated test is scope creep, and iterating on it
   forever is a deadlock. If green requires a judgment call that belongs to the operator (a
   count claim that looks intentional but does not match, a license conflict), stop and ask
   rather than guessing, and leave the tree consistent either way. Do not commit unless asked;
   when asked, use a conventional commit
   (`chore(repo-standard): scaffold hygiene standard + committed enforcement`).

10. **Offer the required-check ruleset, the piece that makes a red run BLOCK instead of just
   glow.** A workflow that runs on every push blocks nothing by itself: on GitHub only a
   REQUIRED status check stops a merge, and that requirement lives in a branch ruleset, not in
   any committed file. Once the suite is green, the repo has a GitHub remote, and
   `gh auth status` is green, PROBE before asking, and never offer what the plan cannot take.
   Run the read-only `gh api repos/{owner}/{repo}/rulesets` and branch on what comes back:
   - **403 with an upgrade message** (rulesets are unavailable on free-plan PRIVATE repos):
     do not ask the question at all. State it in the recap instead: rulesets are not
     available on this plan for a private repo, a red run blocks nothing, and the offer
     stands once the repo goes public or the plan changes.
   - **200 with a ruleset named `repo-standard` already present**: stand down with a note:
     a re-run must not stack duplicates.
   - **200 otherwise**: ask (AskUserQuestion) whether to apply
     `${CLAUDE_PLUGIN_ROOT}/payload/rulesets/repo-standard.json`; silence is a NO, like the
     hook. On a yes, apply it with
     `gh api repos/{owner}/{repo}/rulesets --method POST --input ${CLAUDE_PLUGIN_ROOT}/payload/rulesets/repo-standard.json`.
   Without `gh` (or unauthenticated), skip the probe and print the manual path instead:
   Settings → Rules → Rulesets → New branch ruleset → require the `test` status check on the
   default branch. Any other API refusal (403 without an upgrade hint: no admin rights;
   422: a field the plan rejects) is information, never something to retry blindly. Report
   it and fall back to the manual path. Describe the offer honestly: the payload ships with
   `"enforcement": "disabled"`: the
   ruleset lands fully configured but INERT, on every GitHub plan (`evaluate`, the dry-run
   mode, is Enterprise-only, which is exactly why it is not the default). Once ACTIVE it does
   more than block a red merge: every change to the default branch goes through a pull request
   (zero approvals), with no bypass actors declared, so repo admins included; force pushes and
   branch deletion are refused; and a branch must be up to date with the base before it merges.
   Turning it on
   is the operator's one deliberate act: Settings → Rules → Rulesets → repo-standard →
   Active (Enterprise operators may pass through Evaluate first). The required check is
   pinned to the GitHub Actions app, so only the real workflow can satisfy it. If the workflow
   that would satisfy it has no `merge_group` trigger (step 7 names that gap), disclose it as
   part of the offer rather than withholding the offer: this ruleset declares no merge-queue
   rule, so nothing deadlocks today, but a merge queue turned on for the branch later would
   leave queued PRs waiting forever for a check that never starts. Until the
   ruleset is ACTIVE, a red CI run blocks nothing, and whatever state this step ends in, the
   recap says so in those words.

11. **Offer the local pre-push check, and do not assume it.** Once the suite is green, ask
   (AskUserQuestion) whether the operator wants the optional pre-push hygiene check, and install
   it only on a yes:
   `node ${CLAUDE_PLUGIN_ROOT}/harness/install-hook.mjs --target .`
   Describe it honestly when you ask: it runs the repo-standard lint (nothing else, not their
   test suite) before each push, so drift fails in their terminal in a moment instead of in CI a
   minute later. It is a **convenience, not a gate**: per-clone, uncommitted, skippable with
   `git push --no-verify`, and absent for anyone who clones fresh. Never claim it enforces
   anything; the committed lint in CI is what enforces. A git hook surprises people, so silence
   is a NO. If the operator is absent or ambiguous, skip it and say so in the recap. The engine
   refuses rather than surprising anyone (an existing pre-push hook, a `core.hooksPath` pointing
   elsewhere, an ungoverned repo); a refusal is information for the operator, never something to
   route around with `--force`. Skip this step entirely on a repo that is not governed by the
   end of the run.

12. **Offer the three remaining pillars, as a journey rather than a lecture.** The front matter is
   only one quarter of what this toolkit can hold true. Once the suite is green, name the other
   three in one breath each and ask (AskUserQuestion) whether the operator wants any of them now.
   `enforcement.assets`, `enforcement.prose`, and `enforcement.indexes` in the sense-state report
   say which are already adopted, and an adopted pillar is not offered again:
   - **Identity** (`/repo-standard-toolkit:identity`): per-folder READMEs and a generated
     banner and pill system, rendered from one manifest, with every pill value traced to a real
     file so the lint re-verifies it forever. Say what it costs: committed artwork, a committed
     generator, and a check that reddens when either drifts.
   - **Voice** (`/repo-standard-toolkit:voice`): the enterprise writing profile (no em dash in
     any form, no filler or AI-writing tells), swept with the operator's approval and then
     locked in the config. Say what it costs: a rewrite pass over existing prose before the
     profile can go on, and a gate on every push after.
   - **Atlas** (`/repo-standard-toolkit:atlas`): every governed directory carrying a complete
     glossary of itself, one row per file, written from the file rather than from a listing. Say
     what it costs, and say it plainly, because this is the expensive one: a **fan-out** that
     reads every file it writes about, and a check that reddens when a directory grows a file
     nobody has described. Say also that the fan-out is its own gate inside that journey, priced
     before it starts in CHUNKS by `index-plan.mjs` (a unit of reading, and a price rather than a
     count of agents), so a yes here is a yes to being asked rather than a yes to the spend.
     **An index migration is not this journey's to perform, and it is not this journey's to
     dispose of.** If the sense report or the planner names one (an index sitting where a reader
     browsing that directory never finds it, usually `docs/INDEX.md` where `README.md` is free),
     do not move the page, do not rewrite the declaration, and do not decide what its knock-on
     identity work is worth. Offer the atlas journey and let it own the whole change set: the
     `git mv`, the inbound links, and the `identityEffects` it hands to
     `/repo-standard-toolkit:identity`. **A scaffold run that performed the rename itself, judged
     the resulting identity work out of scope, kept the coverage exclusion the rename had just
     falsified, and invoked the atlas journey afterwards, ended with an operator decision that
     nobody had put to the operator.** Doing the move first also destroys the offer: the planner
     reports no migration opportunity for a page that has already moved, so the skill that owns
     the change set arrives to find the evidence gone.
     **This is the one pillar where adoption is not binary, so read `enforcement.indexes`
     carefully.** A repo that declares one index over `docs/` has adopted it, and
     `indexes.candidates` may still name nine directories holding files nobody has described,
     whether or not those directories keep a README of their own. Where it does, the offer is to
     COVER MORE rather than to start:
     name those directories, and say that the existing index is re-read rather than replaced.
     `keep` here means there is genuinely nothing left, and only then is the pillar not offered.
     **Two further plan actions, and neither of them is `offer`.** An atlas can be structurally
     finished and still not be a check, so sense-state answers with the distance:
     - `offer-strict`: every directory is decided, every row is written, and `docs.ownership` is
       still `declared`. Offer the ONE config line (`"docs.ownership": "strict"`), and say what
       it buys in the sentence it earns: under `declared` a file added tomorrow is reported and
       green, and under `strict` it reddens the build. Say what it costs too: from then on every
       new file needs a row, an `ignore` entry, or a recorded decline before CI passes. This
       needs no fan-out and no Atlas run, so take the yes here and make the edit yourself, then
       re-run the lint. Record a no as `ATLAS_STRICT_OFFER: declined`, which reads as `keep`
       from then on.
     - `offer-coverage`: nothing structural is left and files inside an indexed directory are
       owned by no declaration, so strict cannot be turned on yet. `atlas.unowned` and
       `atlas.unownedFiles` name them. The offer is to close that gap (widen an `extensions`
       list, add `["*"]`, write an `ignore` entry, or record a decline), and strict is what it is
       for. This is the state a complete-looking repo sits in, and `keep` used to report it as
       finished.
     **RECORD THE ANSWER IN BOTH CASES, INCLUDING THIS ONE.** `offer-coverage` is an offer, so a
     no to it is an answer, and the only place an answer survives a re-sense is
     `scaffold.answers`. Leaving coverage `declared` and writing nothing meant the next run
     computed `offer-coverage` again and asked again, forever: a decision the operator had
     already made, indistinguishable from one nobody had put to them. Write
     `ATLAS_STRICT_OFFER: declined` for a no here too, and re-sense to confirm the action has
     become `keep` before moving on. An answer you cannot see in the next sense report was not
     recorded.
     - `blocked-universe`: git keeps a path none of the three engines can see (a tracked file
       deleted without the removal being staged, a sparse or skip-worktree entry, a name that is
       not valid UTF-8). This is not an offer and there is nothing to ask: every atlas count is a
       statement about a set, and this set has holes in it, so a fan-out priced from it would be
       priced wrong and a coverage verdict computed from it would be about a smaller repo than
       the one git tracks. STOP, name each path with the reason sense-state gives, and say the
       fix out loud: stage the removal, restore the file, materialise the sparse entry, or rename
       the one git cannot decode. The lint's `RS-index (universe)` is already red on this.
   On a yes, invoke that skill (the Skill tool) and let it run its own journey; it senses state
   itself, so nothing here needs to be handed over. When it returns, re-read
   `.repo-standard.json`: a yes to the offer is not adoption, and a pillar the operator declined
   from the inside leaves nothing recorded, so the next run senses `offer` again and asks the
   same question forever. If the pillar's block (`assets` / `prose` / `docs.index` or
   `docs.indexes`) is still absent, say so and
   ask once whether to record that as the answer, because a durable never-ask-again is itself a
   decision the operator makes rather than one you infer from a pillar walking away. Write
   `declined` only on an explicit yes; otherwise leave the offer open and name that in the recap.
   On a no, or on silence, record the decision
   in `.repo-standard.json` under `scaffold.answers` (`IDENTITY_OFFER` / `PROSE_OFFER` /
   `ATLAS_OFFER` / `ATLAS_STRICT_OFFER`, value
   `declined`) and say in the recap that the offer stands whenever they want it. A re-run reads
   that block and does not ask again: an offer repeated every session is a nag, and a nag is
   something people learn to click past. Skip this step entirely on a repo that is not governed
   by the end of the run, or when all three pillars are already adopted.

13. **Offer to sync the GitHub About panel, the page a stranger reads before the README.**
   It is the one part of a repo's surface no committed file governs, so it rots quietly: a
   description written before a rewrite, prose nobody would let into the README, topics from a
   previous product. Run
   `node ${CLAUDE_PLUGIN_ROOT}/harness/github-about.mjs --target . --json`
   to derive what the panel should say from what the repo already states about itself. The
   description is the README's bold tagline, which is already held to the readme, voice, and
   prose checks, so the panel inherits the writing standard rather than needing its own.
   Skip this step entirely without a GitHub remote, without `gh auth status`, or on an exit 1
   (no tagline to derive from: say so, and fix the README first).
   Read the live panel with `gh api repos/{owner}/{repo}` and show a real diff before asking.
   Then apply on a yes, and only what you could source:
   - `gh api repos/{owner}/{repo} --method PATCH -f description=... -f homepage=...`
   - **Never blank a field you could not derive.** An undeclared homepage means leave theirs
     alone, not overwrite it with nothing.
   - **Topics REPLACE the whole list on write.** `gh api repos/{owner}/{repo}/topics` first, then
     propose the UNION: every topic already there, plus the derived ones that are missing.
     Removing one is the operator's explicit call, never the default, because a topic curated for
     discoverability is not derivable from any file in the tree and dropping it silently undoes
     work you cannot see.
   Record exactly what was applied under `github.about` in `.repo-standard.json`, and OMIT any
   field the proposal does not carry: a homepage the engine could not derive is an absent key,
   never a null and never an empty string, because both record a claim the repo never made and
   the config that names one is a config error the whole gate stops on. RS-about then
   holds the offline half forever: edit the tagline and the recorded description goes stale,
   loudly, with a re-sync as the fix. Say plainly in the recap that the lint takes no network, so
   nothing here proves what GitHub is serving right now, only that the recorded values still
   match the repo's own front page.

## Automated vs. manual recap

End every run with two lists. **Automated:** every file created / modified / upgraded, one line
each, with the reconcile before→after quotes and which template or engine produced it.
**Manual:** what only the operator can finish: reviewing the generated prose, supplying any
contact/tagline left open, committing and pushing, and (once pushed) confirming the CI gate ran.
Run `node acceptance/test-repo-standard.mjs` once more AFTER the last write of the run, and
report THAT verdict: step 9 verifies, then steps 10 to 13 keep writing, so a gate wedged by a
later step is invisible until someone else's push finds it. Report the lint's verdict with skips
AS skips, as in "N passed, 1 skipped (RS-lockstep: no version
manifest)", with N being whatever the lint itself printed. Never fold a skip into a pass count,, and
never "all checks pass" when anything was skipped or disabled: a skip the lint prints loudly
must stay loud in the recap, or the recap inflates exactly the claim this toolkit exists to
police. State the blocking status in plain words: "the check is required and active", "the ruleset is
installed but disabled: a red run blocks nothing until the operator activates it, and activating
it also routes every change to the default branch through a pull request (zero approvals, no
bypass actors, so admins included) and refuses force pushes and branch deletion", or "no
ruleset: a red run turns the badge red and blocks nothing". Never imply the gate blocks when
it only reports.
Say what happened to the ignore ruleset in the same honest register: which lines were added and
to which file, or that the rules were already in place, or that a negation the operator must
decide about is re-exposing a secret path. If a `.env` is already tracked, that sentence says
the credentials should be treated as disclosed, and never let it read as "the repo was scanned and
is clean", because nothing here reads file contents.
Name the recorded `scaffold.pluginVersion`, the payload version that now governs the repo, and
beside it the version of the lint actually sitting in `acceptance/`: the two legitimately differ
when the operator kept an older or hand-edited copy, and a stranger reading the recap has no
other way to tell.
State plainly that the standard is now enforced by the committed lint in CI, not by this plugin
Removing the plugin changes nothing about enforcement. If the pre-push hook was installed, say
where it lives, that it is local-only and uncommitted (a teammate who wants it re-runs this
skill), and how to remove it.

## What feeds the next skill

Nothing downstream is REQUIRED, and that is the point. The committed
`acceptance/test-repo-standard.mjs` + `.repo-standard.json` + the CI workflow are the durable
interface: they police every future push without the agent. Re-invoking this skill later is
always safe (sense → reconcile → keep), and is the upgrade path when the plugin ships a newer
payload lint.

Three optional journeys extend the same lint, and step 12 offers them rather than assuming them:
`/repo-standard-toolkit:identity` (the generated banner and pill system, enforced by RS-assets),
`/repo-standard-toolkit:voice` (the enterprise writing profile, enforced by RS-prose), and
`/repo-standard-toolkit:atlas` (a per-directory glossary of what every file is for, enforced by
RS-index). All three sense their own state, so none needs anything handed over; all three write
their scope into the same `.repo-standard.json` this skill authored.
