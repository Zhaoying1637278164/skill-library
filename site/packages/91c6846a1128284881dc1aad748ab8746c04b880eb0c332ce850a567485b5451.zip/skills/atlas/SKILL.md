---
name: atlas
description: 'Give every directory a complete glossary of itself: one row per file, written from the file rather than from a listing, in one voice, on a fixed row grammar the committed lint holds forever. A gated fan-out reads every file it writes about, a normalization pass makes many agents sound like one, and a file header the sweep catches lying is reported as a finding rather than copied into a row. Use when a repo''s folder READMEs describe directories nobody re-read, when an index has drifted, or when a directory grew files nobody catalogued.'
allowed-tools: Read Grep Glob Task Skill AskUserQuestion Write(**/README.md) Edit(**/README.md) Write(**/INDEX.md) Edit(**/INDEX.md) Edit(**/*.md) Write(.repo-standard.json) Edit(.repo-standard.json) Bash(ls *) Bash(git mv *) Bash(node *harness/sense-state.mjs *) Bash(node *harness/index-plan.mjs *) Bash(node *harness/voice-scan.mjs *) Bash(node acceptance/test-repo-standard.mjs*) Bash(for t in acceptance/test-*.mjs*)
---

# Atlas

Make every directory in this repo explain itself, file by file, in one voice, and leave the
committed lint holding the result. A row is written from the file it describes, never from the
directory listing and never from the file's own header, because a header is a claim like any
other and this journey exists to check claims. The reading is a fan-out, and the fan-out is an
offer with its size stated before it happens.

What CI can hold afterwards is completeness, resolution, and shape: every file has a row, every
row points at something real, every row states a status from the repo's own vocabulary. It cannot
hold accuracy. No lint reads a description and knows it still matches the code. Say that in the
recap rather than letting a green check imply it.

## When to use

- A repo whose folder READMEs describe directories from the outside, or list some of what is in
  them. An incomplete table reads exactly like a complete one, which is the failure this closes
- A directory that grew files nobody catalogued, so `RS-index` is red and the rows have to be
  real ones rather than filler that turns the build green
- A repo adopting the index standard for the first time, one directory or all of them
- **A repo that adopted it for one directory and stopped.** Adoption here is not binary: one
  declared index over `docs/` and nine other directories holding files nobody has described is the
  common shape, and the nine are what this journey is for, whether or not they keep a README
- Reconciling after a release: the rows were true, the code moved, and nobody re-read the tables
- NOT before the repo standard itself: run `/repo-standard-toolkit:scaffold` first, because
  `RS-index` is a check inside the lint that scaffold installs
- NOT for a directory nobody should have to read. A glossary of a leaf holding three config
  fragments is decorated nothing, and offering one is worse than leaving it alone
- NOT a code review. The sweep reports where a file's own header contradicts the file, because
  reading every file is how that surfaces, and it stops there

## Prerequisites

- The target repo is the current working directory and is already governed
  (`acceptance/test-repo-standard.mjs` + `.repo-standard.json` present). If it is not, stop and
  point the operator at the scaffold skill.
- **The installed lint is the current payload.** Governed is not enough, because this journey
  WRITES CONFIG: `scope`, `ordered`, `retain`, `declined`, and `extensions: ["*"]` are all keys an
  older lint rejects as unknown, and an unknown key in `.repo-standard.json` is a hard RS-config
  error that suppresses every other check. So a run that indexed a repo perfectly against a stale
  lint would hand it back with the gate wedged shut.
  Read the plan entry `sense-state` emits for `acceptance/test-repo-standard.mjs`. On `keep`,
  continue. On `install`, `upgrade`, `downgrade`, or `local-edit`, **stop and route through
  `/repo-standard-toolkit:scaffold`**, which owns that decision and takes the git-status check and
  the downgrade refusal with it. Say which verdict was seen and what it means; do not copy the
  payload lint from here, because replacing a repo's gate is not a thing an indexing run should
  do on its way past.
- Nothing else. Sense the state; never assume a prior run.

## Steps

1. **Sense first, then plan, smallest question first.** Run
   `node ${CLAUDE_PLUGIN_ROOT}/harness/sense-state.mjs --target . --json` for the classification,
   then `node ${CLAUDE_PLUGIN_ROOT}/harness/index-plan.mjs --target . --summary --json` for the
   shape of the work. **`--summary` first, always**: the full plan carries a line per file and ran
   to nearly three thousand lines on the first real repository this met, which is a whole context
   window spent before a single question has been asked. Narrow with `--index <path>` or
   `--candidate <dir>` once the operator has said which directory is in scope, and reach for the
   unsummarised plan only for the directory being worked.
   The planner is the source of every number this run states, because a skill that counted its
   own work would be guessing at the figure the operator is about to agree to. It reports, per
   declared index: the files that owe a row, which already have one, which rows point at a file
   that is gone, which files cannot be read at all, and how the reading divides into agents. It
   also reports **candidates** (directories holding kept files that no index speaks for, README or
   no README), **undecided files** (kept files inside a directory that keeps an index which no
   declaration's `extensions` reach), **migration opportunities** (an index sitting where a reader
   browsing that directory never finds it), and any directory already **declined** or index
   already **retained**.

   **Read the exit code for what it actually carries, which is structure and nothing else.** `0`
   means no structural work: every declared index has a row for every file, every row resolves,
   nothing is catalogued twice, no directory is an unanswered candidate. **It does not mean the
   rows are true**, and the planner says so in those words on every run. `2` is a refusal, and the
   two that matter are an ungoverned repo (scaffold first) and a config declaring both
   `docs.index` and `docs.indexes`, which the lint rejects as a pair.

   So exit 0 leaves exactly one question, and it belongs to the operator: **is this a
   reconciliation run?** If it is, `--mode reconcile` prices re-reading every file the declared
   indexes speak for, and `reconciliationPlan` is that number. A run that reads exit 0 as "done"
   skips complete-but-stale indexes, which is what happened the first time this journey met a real
   repository: seventeen files and two whole chunks went unread because the index covering them
   was structurally perfect and nobody had opened it in a year.

2. **Settle the scope before pricing it.** Four separate questions, and the operator answers each
   one. Ask each **per directory**: bundling eight directories into a single yes is efficient for
   whoever is asking and is not the approval this skill promises.
   - **The declared indexes.** All of them, or a subset, and for each one whether this is a
     gap-fill or a reconciliation. `--index <path>` narrows the planner to one; `--mode reconcile`
     prices re-reading it. **A structurally complete index is a legitimate answer to this
     question, never a reason to skip asking it.**
   - **The candidates.** For each directory holding kept files that no index speaks for, offer one, priced.
     `--candidate <dir> --extensions <list>` returns the exact paths, lines, bytes, unreadable
     files, oversized files, and agents, so the offer carries a real number rather than a file
     count. Say what it costs afterwards too: a new file in that directory reddens the build until
     it has a row. A directory whose files nobody should have to read is a directory that should
     not get an index. **A declined candidate is a finished answer**, and it goes in
     `docs.declined` as `{ dir, why }` so the next run does not re-ask. That is a per-directory
     no; it is not the repo-wide `ATLAS_OFFER`, which is terminal and must never be written to
     record a single excluded leaf.
     **Keeping a README was never the rule**, and treating it as one is how the pillar missed its
     own north star: an ignored build directory with a README was offered as work while a kept
     source directory without one was passed over in silence. A candidate with `readmeExists:
     false` is a real offer with a different shape, because adopting it writes that directory its
     front page rather than adding a table to a page someone already wrote. Say which it is.
   - **The undecided files.** `undecidedFiles` counts kept files sitting inside a directory that
     already keeps an index, which that index's `extensions` do not reach: a `Dockerfile` beside
     the `.mjs` files, a `.png` in a `.md` tree. The gate NAMES these in a skip and does not fail
     on them, because the operator's extension list is their answer for that directory and
     reddening it would be this toolkit imposing a scope nobody gave it. So they are a question,
     asked once, per directory: widen `extensions` (`["*"]` means every kept file the directory
     holds, which is the only selector that can promise complete coverage), add an `ignore` entry,
     or leave it and say so in the recap. An unasked question here is how a repo ends up believing
     a directory is covered when a third of it was never in scope.
   - **Where the index goes, for a new one.** `README.md`, because GitHub renders it inline when a
     reader browses the directory. Whether one EXISTS yet is `readmeExists` on the candidate, and
     the two shapes are different offers: where the page exists, adopting the directory means
     **that page gains a table with its prose left alone**, not that a second catalog appears
     beside it; where it does not, adopting the directory **writes that directory its front page**.
     Say which one this is. (An earlier draft of this file said a candidate always has a README.
     That was the old discovery rule, which the pillar abandoned for a measured reason: it offered
     an ignored build directory with a README as work and passed over a kept source directory
     without one in silence. Keeping the sentence meant the step contradicted the bullet above it.)
     The one exception is a README that is
     itself one of the artifacts the directory ships: `payload/templates/README.md` IS a template,
     and an agent following "the index is the directory's README" would overwrite it and redden
     the build. No engine can tell those apart, so the planner prints a `CONFIRM` line and the
     operator answers. Where the README is genuinely taken, the catalog becomes `INDEX.md` and the
     README gets a row like any other file.
   - **Whether an existing index should move.** Every entry in `migrationOpportunities` is this
     question. The catalog is complete and correct and sits somewhere a reader browsing the
     directory does not find it, while `README.md` is free. Offer the move with the whole change
     set the planner already computed, and make all of it one change: `git mv` (never a copy and a
     delete, because history follows a file through a rename and does not follow it through a new
     file beside a deletion), the declaration's `file`, the `docs.extra` entry, and the inbound
     references, which the planner lists by file and line **in two separate sets, because they are
     two different jobs**:
     - `links` are verified markdown links to the page. These are the ones a rename has to
       repoint, and a rename that leaves them dangling is worse than no rename: the page is gone
       and every reference to it now lies.
     - `mentions` is everywhere else the path is written: prose, a fenced example, a released
       CHANGELOG line (flagged `released`, and **never** rewritten, because a released section is
       a record of what shipped and editing it falsifies the history the file exists to keep).
       Each of these is a judgement. Show them; do not batch-edit them.
     **Say `links` and `mentions` as two numbers**, and do not promise to fix "every inbound
     reference": until there is a parser-backed applier, this run repoints the links it verified
     and reports the rest for a person.
     **Uncertainty is always a mention.** A link the planner cannot see a reader seeing (inside a
     comment, a fence, a code span, a `<pre>` block, or indented code), one that never closes, an
     image rather than a navigable link, a raw HTML `href`, and anything at all inside a changelog
     that cannot be shown to sit above released history: each of those is real, each is inbound,
     and none of them is safe to rewrite without reading it. The two lists are not "found" and
     "not found"; they are "an applier could do this" and "a person has to".
     **A bare basename is only counted where it is written as a path** (in a code span, in
     brackets or parentheses, quoted, prefixed `./`, or starting a line or a table cell). That is a
     deliberate trade: it drops an unrelated sentence that happens to contain the two words, and it
     also drops a genuine bare mention in flowing prose. If the operator is renaming a page whose
     basename is a common word, say so rather than presenting the mentions list as exhaustive.
     **The banner manifest is not this journey's to edit, and it is not this journey's to excuse
     either.** The planner reports that half as `identityEffects`, a structured list beside
     `alsoUpdate` rather than inside it, and the distinction is the point: `alsoUpdate` is this
     journey's own edits (the `file` path in `.repo-standard.json`, and `docs.extra` when it lists
     the old path), while every `identityEffects` entry belongs to
     `/repo-standard-toolkit:identity`, which owns the manifest, the artwork, `assets.coverage`,
     the generated H1s, and the rationale recorded beside any exclusion. Read each `what` and
     `detail` out to the operator here, and carry out none of them here. **A nonempty
     `identityEffects` is not something this journey may dispose of.** Step 9 either hands it to
     that skill or brings back an explicit operator decision; "out of scope" written by the skill
     that caused the effect is neither.
     **Retain instead** when the operator wants the page where it is, or when `README.md` is about
     to be claimed by something else. That answer is durable and it gets written down: set
     `retain` on the declaration to the operator's own reason, and the offer stops. Without it the
     same question came back on every run forever, the exit code never reached 0, and a decision
     somebody had made looked exactly like one nobody had. Either way it is their call, and an
     unanswered migration is not a finished run.
   For an index that already exists, **adopting it adopts its gaps**, and the planner has already
   named them. For each uncatalogued file the answer is a real row or an `ignore` entry, never a
   third thing.

3. **Price the fan-out, and stop.** This is a gate. **No agent reviews a file and nothing is
   written** until the operator says yes, and the offer states the size before it happens rather
   than after. Say it that precisely: the planner has already opened every file it priced, to
   count its lines and bytes, and it has already searched their contents to find the inbound
   references to a page a migration would move. What has NOT happened is any of the reading this
   journey is about, and none of the writing. "Nothing is read until you approve" was the old
   wording and it was simply untrue.

   > `<N>` directories, `<M>` files, `<L>` lines, divided into `<K>` chunks. Each chunk is read in
   > full by one agent, which returns rows. Nothing is written until you have seen the tables.

   **`<K>` is the planner's `chunks` field, and a chunk is a unit of READING rather than a count of
   agents.** The planner packs files against three fixed ceilings (files, lines, bytes, whichever
   binds first), so the figure is exact as a price and says nothing about what will run. Its
   human-readable output prints that same integer under the noun `agent(s)`, which is a label on a
   price: quoting it afterwards as though something had measured it is how one recap claimed 38
   agents on a run that launched 34.
   Every number comes from the planner. Name the oversize chunks by file, because "one agent
   reads a 6,000 line file alone" is part of what is being agreed to. Name the unreadable files
   too: they will be reported, not described.

   **A decline is not a failed step, and this skill has somewhere to go on every one of them.**
   Offer the narrower scope first (fewer directories, or the gaps alone rather than a full
   re-read), because a scope that is too big is the usual reason. If the answer is still no, hand
   over: print the row grammar below and the planner's file list, and say plainly in the recap
   that nothing was read and nothing was written. Only record a permanent decline in
   `scaffold.answers` (`ATLAS_OFFER`) on an explicit request never to be asked again, because
   `declined` is terminal in sense-state and a pillar walking away is not the same as an operator
   closing the door.

   The capability is assumed here and the consent is not. A fan-out of this size is real work
   rather than an aspiration, and that is exactly why it needs an answer: work that is possible is
   not therefore free, and this repo's whole posture is that the operator sees what is about to
   happen while they can still stop it.

4. **Fan out on the row grammar, which is the contract.** One agent per chunk from the planner,
   launched with the Task tool. Many agents writing descriptions produce many voices, which fights
   the consistency that is the entire point, so what makes this work is that the SHAPE is fixed
   before anyone writes a word and only the reading is agentic.

   **One agent per chunk is the intent, and nothing measures whether it held.** Chunks are priced
   before the gate and calls are launched after it, and the two diverge for ordinary reasons: a
   directory declined at step 7 was priced at step 3 and never read, small chunks are combined into
   one call, a rejected table sends one directory back for a re-read. The agents return rows and no
   identifier, so the merged tables cannot be counted back to chunks either. The number launched is
   therefore not the number priced, and no artifact this journey produces records the first one.

   Hand each agent this brief, with its own values substituted and nothing left implicit:

   ```
   Read every file listed below IN FULL and return one table row for each, in the order given.

   Your directory:   <dir>/
   The index file:   <index path>
   Your files:       <paths, ascending, from the planner's chunk>
   Extensions this index speaks for: <ext list>
   Status vocabulary: <exact declared spellings, plus any aliases>

   ROW GRAMMAR, exactly:
   | [`<path relative to the index's directory>`](<same path>) | <what it is for> | `<status>` |

   - The link target is relative to the INDEX, not to the repo root. From skills/README.md the
     target for skills/scaffold/SKILL.md is `scaffold/SKILL.md`. Getting this wrong resolves to
     skills/skills/... and fails both coverage and resolution.
   - The link text is that same path, in backticks. Not a title you invented for it.
   - What it is for: 1 to 3 sentences, 120 to 400 characters. A file that DOES something when run
     or imported opens with a third-person present verb ("Classifies the target repo as..."). A
     file that IS something when read opens with a noun phrase ("The default scope config, with
     every key documented inline."). Name the failure it prevents or the refusal it makes where
     it has one.
   - Ground every claim in what you READ. Not the filename, and NOT the file's own header
     comment: headers go stale and this sweep is how that gets caught.
   - No raw `|` in a cell: write `\|`. No line breaks in a cell.
   - Status: exactly one of the declared words, backticked, in the spelling given above. A
     qualifier after it is allowed. Default to the primary status; assign another only from
     evidence in the file, and if a file is superseded, the row says by what.

   Also return, separately from the rows:
   - HEADER FINDINGS: anywhere the file's own header comment, docstring, or usage string
     contradicts what the file does. Quote both. This is a first-class output, not a footnote.
   - COULD NOT READ: any file you could not read in full, with the reason. Never write a
     confident row for one of these.

   Return rows and findings as text. Do not write to any file.
   ```

   The agent returns rows; this skill assembles them. A hundred agents each editing the same
   table is a race, and the merged order has to be the planner's order rather than whichever
   agent finished first.

5. **Normalize the merged result, in one pass, without re-deriving anything.** Read every row
   together and edit for form: the opening pattern, tense, length band, terminology used the same
   way in every directory, and the writing profile if one is active. Run
   `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --summary` afterwards rather
   than trusting yourself; a run that writes prose breaking the standard it installs has undone
   its own work.
   **The normalizer may reword and must never re-fact.** It has not read the files. A row whose
   claim it cannot follow back to something goes back for a re-read, never to a guess, and a row
   it shortens must not lose the specific thing that made it worth reading.

6. **Assemble each page, in a fixed order, so a later pass produces a diff and not a rewrite.**
   - The H1. At the top level that is the generated banner H1 when the repo has the identity
     pillar. **A nested directory has no banner**, because `assets.coverage.roots` is one level
     deep by design, so a nested index opens with a plain `# <dir>/` and you do not add a manifest
     entry to give it one.
   - A bold one-line promise, then any prose that frames the table.
   - The reconciliation line, immediately above the table, on its own line:
     `Reconciled against the code: YYYY-MM-DD (agent sweep)`. Today's date, and it is earned: the
     rows were written from the files today. The parenthetical names who did the reconciling, and
     `(by hand)` is the other value. **A later partial edit changes neither the date nor the
     parenthetical**, because the claim is about the whole index and editing three rows does not
     reconcile it. Only a whole-index reconciliation rewrites that line.
   - The table, rows in **ascending path order**. Mandated rather than chosen: it is the only
     order a different agent reproduces on a later run, and it is the order the lint reports
     missing files in.
   - Any prose after the table.
   Column headers are `File`, `What it is for`, `Status`. **Never reorder or restyle the columns
   of an index that already exists**: the lint matches a row by the link in it, not by position,
   and rewriting someone's headers to match ours is a diff nobody asked for.

7. **Show the tables before writing them, one directory at a time.** The operator approves a
   rendered table, not a promise about one. Approving per directory rather than per row is
   deliberate: a hundred approvals is not consent, it is attrition. **One approval covers one
   directory**, so eight directories is eight answers, not one bundle with eight items in it.
   For an index that already existed, show what changed, and say which rows are new, which were
   reworded, and which are gone because the file is. On a no, take the notes and re-run that
   directory. On silence, stop and report that nothing was written.

   **Anything outside the table is a separate approval.** Rewording existing prose, dropping a
   stale paragraph, retitling a section: each of those is an edit to a page the operator wrote,
   and a table approval does not cover it. Show the full-page diff and ask again. A run that
   quietly rewrote thirty-five descriptions and deleted an aggregate row on the strength of a
   "yes" to a table got more than it was given, however sensible each edit was on its own.

8. **Write, and declare.** Only after approval:
   - Write each index page.
   - Add or update each block in `.repo-standard.json`: `docs.index` for a single index,
     `docs.indexes` for a list, **never both**. `file` carries a path separator, because an index
     catalogues the directory it lives in. Set `extensions` where it is not the `.md` default,
     `scope: "direct"` on every new index (one README per directory, owning the files directly in
     it; a declared child index bounds its parent over the files that child CLAIMS, so no
     hand-written `ignore` is needed for nesting, and a file the child does not speak for stays the
     parent's), `statuses` to the subset the page actually uses, `ordered: true` because
     you just wrote the rows in ascending order and the lint should hold that, `reconciled: true`
     for the line you just wrote, and `ignore` for anything the operator chose to leave out.
     `extensions: ["*"]` is the answer when the operator wants a directory covered completely: an
     extension list can never reach a `Dockerfile`, a `Makefile`, or an extensionless script, and
     a directory catalogued by an extension list is covered only as far as that list goes.
   - **`grammar: 2` on every index this journey writes**, because this journey writes the header
     the version reads (`File` / `What it is for` / `Status`). Version 1 is the default for pages
     that already existed, and under it any cell answers for anything: an unrelated table whose
     rows link files counts as coverage, a description beginning with a status word satisfies the
     status rule while the status column is empty, and a date in any column answers for a blank
     verification column. On a page you just wrote there is no legacy to protect, so declare 2.
     For an index that was already there, offer 2, run the lint, and read the failures with the
     operator before committing to it: version 2 can redden a page version 1 passed, and that is
     the point of it.
   - **Add each index to `docs.extra`. This is required, not advisory**: `RS-index` fails an index
     no prose sweep governs, because it is the one page in the directory that can rot with nothing
     in the toolkit noticing.
   - Record every declined directory in `docs.declined` as `{ dir, why }`, with the operator's own
     reason. The `why` is required by the lint: a recorded no with no reason cannot be told apart
     from an oversight later.
   - Record every retained index as `retain` on its own declaration, with the operator's reason,
     for the same purpose a decline serves one level up: the offer stops, and the next run can
     tell a decision from an omission.
   - For an approved migration, make the whole change at once: `git mv` (use the planner's
     `moveArgv`, or its `move` string, which is shell-quoted; a path with a space in it silently
     became two arguments and moved the wrong file), the declaration's `file`, the `docs.extra`
     entry, and every verified inbound `link` the planner listed. Those links live in whatever
     markdown references the page, which is why this journey holds `Edit(**/*.md)`: a promise to
     repoint every verified link, made by a skill granted edits only on README and INDEX, is a
     promise that fails on the first repo whose CONTRIBUTING links the index. The edit is confined
     to the paths the planner VERIFIED. Then re-run the planner and confirm the opportunity is
     gone.
     **What `links` and `mentions` each mean, because the split is what makes the promise
     keepable.** A `link` is a markdown link destination the planner RESOLVED, relative to the file
     it sits in, and found to land on this index: `docs/INDEX.md`, `./docs/INDEX.md`, and (from a
     page inside the directory) `../docs/INDEX.md` are one destination spelled three ways, and a
     reference definition (`[ix]: docs/INDEX.md`) is a link too. Rewrite each one to the new path.
     A `mention` is every other place the path is written: prose, a fenced example, an inline code
     span, a path inside source that markdown does not render, a released CHANGELOG line. Report
     those to the operator and edit none of them. Do not go looking for more with a grep of your
     own: a substring search finds the fenced examples and misses the relative spellings, which is
     exactly the discovery this step replaced.
     The `identityEffects` list goes to step 9, which is where it is handed to
     `/repo-standard-toolkit:identity`. This journey never edits the manifest or the artwork, which
     is what keeps it re-runnable without regenerating a single SVG, and step 9 is what keeps that
     separation from turning into an effect nobody owns. Pay particular attention to the entry that
     reads "the identity coverage exclusion is about to be wrong": a directory excluded from
     folder-README coverage is usually excluded BECAUSE it kept its front page under another name,
     so this rename is what makes the exclusion, and the reason recorded beside it, false. A
     migration that leaves that behind is lint-green and wrong.
   - If a candidate was declined, write nothing for it and name it in the recap.
   - **Offer `"docs.ownership": "strict"` at the end, and only when the planner reports zero
     undecided files and zero candidates.** That is the setting under which "a file added tomorrow
     reddens the build" stops being a description of this journey and becomes a check the committed
     lint holds: every kept file under a declared index then owes exactly one owner, an `ignore`
     entry, or a `docs.declined` record, and a directory nobody has answered for fails the build.
     Offer it, never assume it, and never set it while anything is still undecided: a mode switched
     on over an incomplete atlas reddens the build on work the operator has not agreed to do, which
     is the one way to make an honest check feel like a trap. If they decline, say in the recap
     that coverage is held only as far as each `extensions` list reaches.

9. **Hand the identity effects over, and do not decide them here.** Every `identityEffects` entry
   the planner reported for an approved migration is structured work this run CAUSED and does not
   own. A nonempty list has exactly two honest endings, and reasoning it away is neither of them.
   - **Invoke `/repo-standard-toolkit:identity` (the Skill tool), from here.** Not from whatever
     invoked this journey: a run reached directly is the ordinary case for this skill, and an
     effect that is only handed over when a parent happens to be listening is an effect that goes
     missing exactly when nobody is watching. Pass each entry's `what` and `detail` verbatim, name
     the page that moved and the page it moved to, and let that skill sense the rest itself.
   - **Or bring back an explicit operator decision**, in the words they chose. The operator may
     decline the artwork and keep the exclusion, and that is a real answer. What is refused here is
     the exclusion being kept SILENTLY, by this skill, on its own authority. `assets.coverage`, the
     manifest banners, the generated H1s, and the rationale written beside an exclusion belong to
     the identity pillar, so a decline is recorded there, in that skill's terms, with the operator's
     reason.
   **A run that performs a migration, judges the resulting identity work out of scope, and leaves
   the exclusion standing has dispositioned a decision that was never its own.** That is the failure
   this step exists for, and it is the shape this pillar shipped in for one release. Silence is not
   a decision and neither is a sentence this skill writes about scope. Name the outcome in the recap
   either way: handed to identity, or declined by the operator with their reason.

10. **Converge the prose, after the last approved write and not before.** A page is not finished
    because its rows satisfy the row grammar; it is finished when it also reads like the rest of the
    repository. The order is fixed, because each stage writes markdown the next one has to read:
    this journey's content, then identity's banners and generated H1s, then the writing profile,
    then the lint and the suite. Scanning before identity has written its H1s scans a page that does
    not exist yet.
    - **Re-sense first, because the reach moved.** Adding an index to `docs.extra` widens what the
      `docs` reach covers, so prose that was ungoverned a moment ago is governed now. Read
      `enforcement.prose` from `sense-state` for whether a profile is DECLARED, and read the
      `prose profile` row of the same report for whether the offer was DECLINED. A decline lives
      only in that plan row: read `enforcement.prose` alone and a repo that already said no looks
      byte for byte like a repo nobody has asked.
    - **Then scan the final governed reach** with
      `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --summary`, and read the exit
      code: 0 clean, 1 hits, 2 a bad invocation, which is a report about nothing rather than a clean
      repo.
    Four states, and each has one ending:
    - **A profile is adopted and the scan is clean.** Continue silently. An offer made to a repo
      that already complies is a nag, and a nag is what people learn to click past.
    - **A profile is adopted and the scan has hits.** Prose this journey generated must satisfy the
      adopted profile before the recap, so fix the rows this run wrote, always. Where the hits sit
      in prose that was here already and became governed only because this run widened the reach,
      **show the exact pages and the exact hits, and offer a bounded pass over them.** A table
      approval never covered somebody else's paragraphs.
    - **No profile is adopted.** Offer `/repo-standard-toolkit:voice` ONCE, after every README and
      every identity write is finished, priced in files and lines from the scan, with two scopes to
      choose between: the pages this run created or modified, or a full repository pass.
    - **The offer is declined, now or in an earlier run.** Respect it and say so. A recorded
      `scaffold.answers.PROSE_OFFER` of `declined` is durable, and this step neither re-asks it nor
      writes one: a bounded cleanup after an atlas run is not the operator declining the pillar.
    **Silence is not approval anywhere in this step.** With no answer, write nothing further and say
    in the recap that the prose is unconverged and which pages are affected. When a bounded pass does
    run, its done-condition is per file rather than repo-wide: a whole-reach scan can never reach 0
    while unrelated hits sit elsewhere, so confirm each named page with `--file <path>` and stop
    there.

11. **Report what the sweep found that is not a row.** This is an output of the journey, not noise
   beside it. Writing a row about a file turns out to be the most reliable way anyone has found to
   notice the file's own header is lying, and no check the toolkit has would catch one, because no
   lint reads a comment and knows it is false. Group them: the header findings with both quotes,
   and the files that could not be read. **Propose the header fixes; do not apply them.** They are
   edits to files this journey was not invited to change, and some of them will be the code that
   is wrong rather than the comment.

12. **Verify to green, after the last write of the run and not in the middle of it.** Steps 9 and
    10 both write, so a lint run taken before them reports on a tree that no longer exists by the
    time the recap is read. Run `node acceptance/test-repo-standard.mjs` and read `RS-index`
    literally. A coverage failure names the files with no row: add one, or list it under `ignore`.
    A resolution failure means a link does not resolve, and the cause is almost always a target
    written relative to the repo root instead of to the index. A status failure means a cell does
    not begin with a declared word once backticks and emphasis come off. An index declaring
    neither `reconciled` nor `requireDate` prints `RS-index (dates)` as a named skip on every run
    afterwards; name that skip in the recap so nobody reads it as a pass. Then run the whole
    suite: `for t in acceptance/test-*.mjs; do node "$t" || exit 1; done`.

## Automated vs. manual recap

| Step | Automated | Needs the operator |
|---|---|---|
| Pricing the work in chunks, finding the gaps | `index-plan.mjs`, deterministic | nothing |
| How many agents actually ran | nothing records it | **omitted from the recap: state chunks priced, never a count of agents** |
| Handing a migration's identity effects over | invoking `/repo-standard-toolkit:identity` | **their call, and declining the artwork is a real answer** |
| Converging the prose after the last write | `voice-scan.mjs` over the final reach | **their call on any pre-existing prose the reach just widened onto** |
| Pricing a directory that keeps no index yet | `--candidate`, exactly | nothing |
| Starting the fan-out | nothing | **an explicit yes, with the size stated first** |
| Reading files and drafting rows | the fan-out | nothing |
| One voice across the merged tables | the normalization pass | nothing |
| Each directory's table | drafted | **approved before it is written, one directory at a time** |
| Any edit outside the table | drafted as a full-page diff | **a second approval; a table yes does not cover prose** |
| Adopting a candidate directory | offered | **their call, and a decline is a finished answer** |
| Whether this run reconciles a complete index | priced, never assumed | **their call: exit 0 is structure, not accuracy** |
| Moving an index to the page a reader lands on | offered with its whole change set | **their call, and retaining is a real answer** |
| Fixing a lying file header | reported with both quotes | **their call: sometimes the code is what is wrong** |
| Holding it true afterwards | `RS-index`, on every push | nothing |

Three limits to state in the recap rather than let a green check imply. **CI holds completeness,
resolution, and presence, and it cannot hold accuracy**: a row that was true when it was written
and is false now passes every check there is. The reconciliation date is a fact the repo
records, never one the lint compares to today, because a check whose verdict changes overnight is
the calendar-dependent failure this toolkit refuses everywhere else. And **the fan-out figure was a
price**: say how many chunks were PRICED and how many directories were approved and written, and
state no number of agents at all, because nothing this journey produces records one. An
unmeasurable count is omitted, never inferred from the plan, for the same reason a homepage the
engine could not derive is an absent key rather than an empty string: both record a claim the run
never made.

**The recap says what happened to the prose, in one of five sentences and never in none of them.**
A profile was already adopted and the final scan was clean; a bounded pass was applied, with the
files named; a full pass was applied, with the scope named; the offer was made and declined; or no
profile is adopted and the offer is deliberately left open. A run that writes prose and says
nothing about the standard that governs it has left the reader to assume the better of two answers.

Where this journey was reached directly rather than through `/repo-standard-toolkit:scaffold`,
steps 9 and 10 still belong to it. Either it completes them or it names them in the recap as
pending work with an owner; a step that only happens when a parent is listening is not part of the
skill.

## What feeds the next skill

Two of the three downstream skills are reached from INSIDE this journey rather than after it, and
that is the point of steps 9 and 10: an effect this run caused is this run's to hand over, whether
or not anything invoked it. `/repo-standard-toolkit:identity` takes the migration's
`identityEffects`, and `/repo-standard-toolkit:voice` takes whatever prose the final scan finds,
in that order, because identity writes markdown that the prose scan then has to read.

The indexes this run writes are governed prose from the moment they land, so
`/repo-standard-toolkit:voice` reaches them at `docs` reach through `docs.extra` and at `markdown`
reach automatically. A repo that has not adopted the writing profile yet has just gained the
pages that most benefit from it, which is why the offer is made at step 10 rather than left for
somebody to think of later.

Where a directory has an index and no banner, `/repo-standard-toolkit:identity` is the offer that
gives it one, and the sweep will usually have produced the honest one-line description that skill
asks for at its step 5. Where the sweep found a banner description that no longer matches what is
in the directory, that is an identity re-run, not an atlas one: this journey never touches the
manifest or the artwork, so it stays re-runnable without regenerating a single SVG.
