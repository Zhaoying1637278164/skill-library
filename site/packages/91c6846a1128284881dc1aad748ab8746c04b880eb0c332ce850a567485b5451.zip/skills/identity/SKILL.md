---
name: identity
description: 'Give a repo a generated visual identity it can keep true forever: a deterministic banner and pill system rendered from one manifest, with the palette derived from the repo''s own design tokens (or a preset), every pill value traced to a real file so the lint can re-verify it, a rendered preview before anything is written, and lint enforcement of coverage, idiom, and zero drift. Asked, never assumed. Use when a repo wants per-folder READMEs and a front page that looks intentional, or to reconcile an identity that has drifted.'
allowed-tools: Read Grep Glob AskUserQuestion SendUserFile Write(README.md) Write(**/README.md) Edit(README.md) Edit(**/README.md) Write(**/manifest.json) Edit(**/manifest.json) Write(.repo-standard.json) Edit(.repo-standard.json) Edit(CONVENTIONS.md) Write(docs/**) Edit(docs/**) Bash(ls *) Bash(git remote *) Bash(git log *) Bash(git mv *) Bash(mkdir -p *) Bash(cp *payload/*) Bash(node *harness/sense-state.mjs *) Bash(node *harness/derive-palette.mjs *) Bash(node *harness/preview-assets.mjs *) Bash(node *harness/voice-scan.mjs *) Bash(node *generate.mjs*) Bash(node acceptance/test-repo-standard.mjs*) Bash(for t in acceptance/test-*.mjs*)
---

# Identity

Give this repo a generated visual identity: one root banner, one banner per folder README, and
a row of pills that state real facts about the repo. All of it renders from a single
`manifest.json` through a committed generator, so it is reproducible byte for byte, and the
committed lint holds it true afterwards. The palette comes from the repo's OWN design tokens
where it has them, a preset where it does not, and never from a guess. Nothing is written until
a rendered preview has been approved.

## When to use

- A repo that wants per-folder READMEs and a front page that looks deliberate
- A repo whose identity has drifted: a hand-edited SVG, a version pill that outlived its release
- A repo adopting the plugin's newer generator (re-run is the upgrade path)
- **Entered from `/repo-standard-toolkit:atlas` with a list of `identityEffects`**, which is what
  an approved index migration hands over. This skill owns every one of them: the manifest banners,
  the generated H1s, `assets.coverage` and any `ignore` under it, and the rationale recorded beside
  an exclusion. A directory is usually excluded from folder-README coverage BECAUSE it kept its
  front page under another name, so a rename is exactly what makes that exclusion, and its recorded
  reason, false. **The operator may decline the artwork and keep the exclusion**, and that is a
  finished answer; what it may not be is a decision the calling skill made on their behalf. Record
  it here, in this skill's terms, with the reason they gave
- NOT before the repo standard itself: run `/repo-standard-toolkit:scaffold` first, because
  RS-assets is a check inside the lint that scaffold installs
- NOT for repos that do not want generated artwork. This is an offer. Silence is a no, and a
  repo with no banners is not a repo that failed anything
- NOT a design review: the engine enforces a contrast floor and nothing about taste

## Prerequisites

- The target repo is the current working directory and is already governed
  (`acceptance/test-repo-standard.mjs` + `.repo-standard.json` present). If it is not, stop and
  point the operator at the scaffold skill first.
- Nothing else. Sense the state; never assume a prior run.

## Steps

1. **Sense first.** Run `node ${CLAUDE_PLUGIN_ROOT}/harness/sense-state.mjs --target . --json`
   and read `enforcement.assets`. Four states, four different runs:
   - `generator.installed: false` and `declared: false`: a first adoption, so continue to step 2.
   - `generator.matchesPayload: true`: installed and current, so this run is reconcile-only
     (steps 5 to 9), and the questions in step 2 are already answered by the existing manifest.
   - `matchesPayload: false` with `upgrade`: the plugin ships a newer generator. Replace it,
     re-render, and expect the SVG bytes to change; say so in the recap with both versions.
   - `matchesPayload: false` with `downgrade`: the installed plugin is OLDER than the generator
     this repo renders with. **Stop.** Replacing it would regress the artwork while looking like
     maintenance. Tell the operator to update the plugin, and touch nothing.
   A `local-edit` verdict means someone hand-edited the generator: diff it against
   `${CLAUDE_PLUGIN_ROOT}/payload/assets/generate.mjs`, show the operator, and proceed only on
   their call.

2. **Ask, do not tell.** Two separate questions (AskUserQuestion), because they are separate
   commitments and one does not imply the other:
   - **Per-folder READMEs?** Every directory that carries one gets a banner and, more to the
     point, has to have something worth writing. Name the directories you would cover and let
     the operator cut the list.
   - **A generated banner and pill identity?** Explain what it costs them: a committed
     generator, a manifest, one SVG per asset, and a lint check that will redden if anyone
     hand-edits the artwork or lets a pill go stale.
   Silence, absence, or ambiguity is a **no**. Say so in the recap and stop. Generated artwork
   in someone's repo that they did not ask for is vandalism with good intentions.

3. **Derive the palette from what the repo already is.** Run
   `node ${CLAUDE_PLUGIN_ROOT}/harness/derive-palette.mjs --target . --json` and present what
   comes back honestly:
   - **Exit 0**: offer the derived palette FIRST, showing each role's real source
     (`--accent` at `styles/tokens.css:46`) and naming which roles had to be derived from
     another rather than read. Say plainly how many of the fifteen are file-backed: a palette
     with two real tokens and thirteen transforms is not this repo's identity, it is a tint of
     one colour it happens to declare.
   - **Exit 1**: the repo has no design identity to read. Say that, quote the engine's reason,
     and do NOT improvise one. Offer the presets
     (`${CLAUDE_PLUGIN_ROOT}/payload/assets/palettes/forest.json`, `violet.json`, `slate.json`)
     or values the operator supplies directly.
   Never mix a derived palette with invented colours to fill the gaps without saying which is
   which. The engine already repairs contrast to clear the lint's 4.5:1 floor and reports every
   nudge; carry those forward, they are edits to someone's brand colours.

4. **Gather the brand inputs, from the repo where possible.** `name` (the wordmark: the project
   name, usually upper-case), `tagline` (the one-line description: the README's existing bold
   tagline is the right answer, not a new one you wrote), and `eyebrow` (the small label on
   folder banners, conventionally `ORG · PROJECT`). Confirm all three. A tagline the operator has
   not seen must never end up rendered into an SVG.
   `homepage` is optional and is the link every banner points at: `derived.repoUrl` from
   sense-state, or the product site if the operator has one. **A repo with neither omits it**,
   and the H1 becomes an unlinked image. Do not invent a destination: a banner linking to a
   repository that does not exist yet is the same fabricated claim as a CI badge for a workflow
   that was never installed.

4b. **Triage the badges the README already carries.** You are in the README already for the
   tagline, and the badge run is usually the line above it. Do this now, not at step 8: step 7
   gets the operator's approval on a rendered page, and a badge line they never saw is not a
   line they approved. Read every badge in the row and sort it into one of three:
   - **A live status**, which changes without the repo changing (a workflow result). That is a
     `badges` entry in the manifest: `{ label, endpoint, href }`, where `endpoint` is the shields
     path after the host. A full URL is rejected by both the generator and the lint.
   - **A static fact** the repo states about itself (a licence id, a dependency count). That is a
     **pill with a real source** in step 6, not a badge. A static claim routed through `badges`
     is laundered past the provenance rule: the lint would check only that the line is present,
     never that it is still true, which is the one thing `pills[].source` exists to prevent.
   - **A claim with neither a live status behind it nor a file that states it.** Offer to delete
     it. A badge nothing backs is advertising.
   A GitHub-native `.../actions/workflows/<file>/badge.svg` has no shields form as written, so
   restating it as `github/actions/workflow/status/<owner>/<repo>/<workflow-file>?branch=<default>`
   is a **named trade, not a syntax change**: you swap a first-party renderer for a third-party
   one to gain the palette, the branch has to be stated explicitly where the native badge implied
   it, and it reads `unknown` whenever the API is unavailable. Put that trade to the operator in
   those terms. An operator who declines has not failed anything. Confirm the workflow file and
   the branch actually exist before writing the endpoint: a badge for a workflow nobody installed
   is the same fabricated claim as a banner pointing at a repository that does not exist.
   Three more things to say plainly, because each is a limit rather than a choice:
   - Live badges always take the accent scheme. The generator hard-wires the label plate to
     `ground` and the value plate to `pillAccentBg` because shields draws its value text white,
     so a light plate would be unreadable. There is no scheme to offer here.
   - A badge with no shields equivalent (a third-party service mark, a custom endpoint) is left
     exactly as it is. Dropping a working signal to tidy a row is the wrong trade, and so is
     approximating it.
   - **An undeclared badge is not a lint failure.** RS-assets checks the badges the manifest
     declares and says nothing about the rest. This is a cosmetic offer about a row the repo
     already chose, so present it as one; an agent that arrives sounding like it found a
     violation has misread its own tool.

5. **Inventory the directories, by reading them.** For every directory that will carry a README,
   open it first. `title` is the path as a reader would say it (`app/services/`, with the
   trailing slash), and `desc` is what is ACTUALLY in there, in a handful of words, grounded in
   the files you just read. A description you cannot support from the directory's contents is a
   claim, and this toolkit does not ship claims. Keep `slug` lower-case kebab and unique.
   **Read the writing profile before you draft a word of it.** Open `prose` in
   `.repo-standard.json` first. If a profile is active, every README this run writes is written
   to it from the first draft, not cleaned up afterwards. Two rule families, and you do not have
   to go looking for them:
   - **No em dash in any form**, anywhere the profile reaches: the character itself, `&mdash;`,
     `&#8212;`, and a spaced en dash. A colon, a semicolon, a full stop, or parentheses does the
     job every time. This is the one that a fresh README fails, because it is the punctuation an
     agent reaches for when a sentence turns.
   - **No banned filler** in markdown prose: `delve`, `utilize`, `leverage`, `in order to`,
     `worth noting`, and the rest of the list the profile carries. Run the scanner for the full
     set rather than working from memory.
   Confirm it afterwards rather than trusting yourself, in step 8 once the files exist:
   `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --summary`.
   **Do not skip `docs/`.** A documentation tree is the directory that most needs a front page.
   Where the tree keeps no index yet, a `docs/README.md` is a directory index rather than a
   second copy of the repo's README: GitHub still serves the root one, and RS-shadow exempts
   exactly this case. That exemption is permission to KEEP one, not an instruction to create one
   where the tree already keeps an index under another name. When the repo has a docs tree,
   step 5b decides which of those two cases this is.

5b. **A documentation tree owes a catalog, and this skill does not write one.** If the repo
   has a `docs/` directory, or any directory whose files should be described one by one, that
   directory should carry an index: a table with one row per file saying what it is for and what
   state it is in. It is not only a docs feature, and `/repo-standard-toolkit:atlas` owns all of
   it. This step's whole job is to SAY the offer exists and hand it over.

   **Every part of an index belongs to Atlas: where it sits, what it says, and how it is
   declared.** This skill used to declare the block in `.repo-standard.json`, name the
   uncatalogued files, write an `ignore` entry or a provisional row for each one, and add the
   page to `docs.extra`. Then it admitted, in its own hand-off note, that those rows came from a
   directory listing rather than from the files, and that Atlas would have to re-author every one
   of them. That is two authoring paths for one artifact, and the weaker one ran first: an
   operator who followed this skill got an index that satisfied the gate, read as finished, and
   described files nobody had opened. A row written from a filename is the confident lie the
   whole pillar exists to catch, and shipping one under a green check is worse than shipping
   none. **So: no declaration, no rows, no `ignore` entries, no `docs.extra` edit here.**

   What this step does instead, in one sentence to the operator: "this repo has directories whose
   files nothing describes; `/repo-standard-toolkit:atlas` prices the work and writes the rows
   from the files themselves." Name it in the recap as a hand-off, never as something done.

   **What DOES come back here is the identity half of an Atlas run.** The planner reports it as
   `identityEffects` on a migration, structured and named, and each entry is this skill's to
   carry out: a banner to declare for the directory, an `assets.coverage.ignore` entry to remove
   when the exclusion was recorded because the directory kept its front page under another name,
   and the generated H1 to insert. Carry those out here; carry out no rename and no config
   index block here.

   **One placement rule this skill does keep, because it is about README rather than about the
   index:** RS-shadow polices the three GitHub-served locations and exempts `docs/README.md` by
   name, precisely because a directory index is README's second job. A `.github/README.md` beside
   a root one is still a shadow. Where the tree keeps no index yet, that exemption is permission
   to KEEP one, never an instruction to create one.

6. **Propose pills that are facts.** Every pill is a claim on the repo's front page, so every
   pill carries a `source` the lint re-verifies on every run: `{ file, json: "dotted.path" }` or
   `{ file, match: "<regex with one capture group>" }`. Find the real source before proposing
   the pill: the version from the version manifest, the runtime floor from the engines field,
   the license id from the manifest. The extracted value must appear inside the pill's display
   value, so `0.115+` may front a source that says `0.115`. A pill with no single source of
   truth (a "TESTS: UNIT + E2E" summary) is declared `"source": false` with a `why`, and the
   lint then prints it as a named skip forever: stated, never verified. If the operator wants a
   pill you cannot source at all, say what it would cost and let them decide. Every static badge
   step 4b triaged out of the badge row belongs here, with the file that states it.
   **`href` is what the pill links to, and it is optional.** Write it as it will appear in the
   README (relative to that file, not to the repo root), pointing at the thing the pill makes a
   claim about: the CHANGELOG for a version, the LICENSE for a licence, the test that holds a
   claim true. A relative one has to resolve or the lint refuses it. Omit it where the claim has
   no real destination, and the pill renders as a bare image: pointing at an invented page is the
   same fabricated claim as a banner linking to a repository that does not exist.
   **On a repo whose README already links its pills, read those links out of the README and put
   them in `href` BEFORE step 8.** A manifest that predates `href` says nothing about them, so the
   block renders every pill as a bare image and the links vanish in a paste that otherwise looks
   like a clean upgrade. Nothing catches this afterwards: the lint compares the block to the
   manifest, and a manifest with no `href` is correctly rendered as an unlinked pill. Measured on
   a real target, where all three pills were linked and all three would have been dropped.

7. **Preview before writing. Nothing lands in the repo yet.** Write the manifest to a scratch
   path OUTSIDE the repo, then:
   `node ${CLAUDE_PLUGIN_ROOT}/harness/preview-assets.mjs --manifest <scratch>/manifest.json --generator ${CLAUDE_PLUGIN_ROOT}/payload/assets/generate.mjs --out <scratch>/identity-preview.html`
   and show it with SendUserFile (`display: "render"`). The page shows the banners animating on
   both of GitHub's page backgrounds, the pill row centred as the block will centre it, the exact
   markdown of that block, every palette role with the job it does, and
   the measured contrast of all nine enforced pairs. Any live badge appears there as the exact
   README line it will become, with the URL it resolves to and its two plate colours as swatches:
   shields draws the image itself when a reader loads the page, and the preview takes no network,
   so that is as close as an honest preview gets. Ask for approval on that, not on a list of hex
   values. On a no, iterate on the palette or the copy and preview again; on silence, stop and
   report that nothing was written.

8. **Install, render, and wire it up.** Only after an explicit yes:
   - **Read `assets.dir` from `.repo-standard.json` first, and use it everywhere below.** It
     defaults to `.github/assets`, and a repo that set it somewhere else means it. Every command
     here writes `<assets.dir>`, and every one of them is SHELL-QUOTED, because a directory path
     containing a space arrived as two arguments and `cp` wrote the generator somewhere nobody
     looked. Write `'my assets/generate.mjs'`, not `my assets/generate.mjs`.
   - `mkdir -p '<assets.dir>' && cp ${CLAUDE_PLUGIN_ROOT}/payload/assets/generate.mjs '<assets.dir>/'`
     (byte-identical, never hand-edited into a target: a forked generator stops being
     upgradeable, and the lint can only prove the artwork follows from the manifest, not that
     the generator is honest).
   - Write `<assets.dir>/manifest.json` with the approved brand, palette, banners, pills, and
     any `badges` the operator approved in step 4b.
     Record `paletteSource`: `{ "kind": "preset", "preset": "<name>" }`, or `{ "kind": "custom" }`,
     or for a derived palette the engine's `manifestPaletteSource` verbatim, which carries only
     the roles that came from a real file. Never record a derived-by-transform role as if the
     lint could re-read it.
   - `node '<assets.dir>/generate.mjs' --check` from the repo root FIRST, which renders nothing
     to disk and prints the whole change set: which SVGs move, which the manifest no longer
     produces (`DELETE`, and applying the plan removes them), and which generated markdown
     carriers (the front-page block, every folder H1) no longer match. Exit 1 means something
     changes, exit 0 means the run would be a no-op in all three. **This step copied the payload
     generator in above, so the installed copy IS the payload copy and `--check` means what it
     says.** When that is not true, which is the upgrade case the scaffold skill owns, plan with
     `node "${CLAUDE_PLUGIN_ROOT}/payload/assets/generate.mjs" --check --assets-dir '<assets.dir>'
     --repo '<repo root>'` instead: a generator older than `--check` ignores the flag and writes.
     Then `node '<assets.dir>/generate.mjs'` to apply. It writes every SVG, removes the assets it
     listed as `DELETE`, prints the whole opening block for the front page, and prints the exact
     H1 line for each folder README. Use what it prints verbatim; do not retype any of it.
     The front page is `docs.readme` from `.repo-standard.json` when one is declared, which the
     generator reads for itself: a repo serving `.github/README.md` is not a repo missing a
     README, and this used to report one as both.
   - **Paste the root block whole**, replacing the existing plain H1 and whatever badge row sits
     under it. Diff what you are replacing against what you are pasting before you do it: an
     existing row can carry a link, a badge, or an ordering that the manifest does not know
     about, and pasting over it is the moment that information is lost. It is the banner H1, then a centred `<div>` holding the pill row, then any live
     badge on its own line inside the same block. Do not assemble those parts yourself and do not
     tidy the blank lines: markdown needs one on each side of the `<div>` or the pills render as
     literal text, the badge sits apart from the pills because a third-party renderer will never
     match them for height, and RS-assets compares the whole thing byte for byte. The bold
     tagline stays right below the block: standard-readme's order is title, banner, badges,
     description, and RS-readme enforces that too.
   - For each folder README: existing file, replace its H1; new file, write the H1 plus real
     prose about the directory from step 5. A folder README that says nothing is worse than no
     folder README, because now the emptiness is decorated. Write it to the active profile from
     step 5, then check rather than assume:
     `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --summary` for the governed
     reach, and `--scan markdown --summary` to see the pages you just wrote when the profile's
     own reach does not yet cover them. Fix every hit before moving on. A run that installs a
     writing standard and then writes prose that breaks it has undone its own work.
   - **Offer to bring the new READMEs into the reach that governs them.** At `prose.scan:
     "docs"` the sweep reads the root meta docs plus `docs.extra`, and a folder README is in
     neither, so its prose is compliant on the day it is written and ungoverned every day after.
     Two ways to close that, and the cost of each is the point:
     - Add the new READMEs to `docs.extra`. Narrow and explicit; each future README has to be
       added by hand or it is unreached again.
     - Widen `prose.scan` to `markdown`, which reaches every `.md` in the tree, this run's and
       the next one's. Broader, and it will surface hits in prose nobody touched today, which is
       a sweep the operator has to be willing to run.
     If the repo is already at `markdown` reach, say so and skip the question: the pages are
     covered. This is an offer either way. If the operator declines, say plainly in the recap
     that those pages are unenforced, and name them.
   - Add the `assets` block to `.repo-standard.json`. Add `coverage` only if the operator wants
     new directories to be forced to earn a README, and explain exactly what that means: a new
     IMMEDIATE subdirectory of a covered root will fail CI until it is either documented or
     ignored, and the levels below it are not policed. Coverage reaches one level per root by
     design, so name each level the operator wants policed as its own root: `roots: [".", "skills"]`
     covers the top level and each skill directory, and nothing inside a skill.
   - Document the regeneration rule in CONVENTIONS: assets are generated, edit the manifest and
     re-run `node '<assets.dir>/generate.mjs'`, never hand-edit an SVG. **Write this yourself**;
     hand it to the operator only if the meta doc is absent or they refuse the edit.
     RS-reflexivity requires it, for the good reason that a contributor who does not know will
     lose their work on the next regenerate. Land it and the `assets` block together, write both
     or neither: a run interrupted between them leaves the repo red on a rule nobody documented.
     A repo whose conventions doc is renamed (`docs.conventions`) is an operator hand-off, since
     this skill's grants reach `CONVENTIONS.md` and `docs/` only.

9. **Verify to green.** Run `node acceptance/test-repo-standard.mjs` and iterate until RS-assets
   passes all three of its legs and RS-reflexivity passes on the conventions edit. Read the
   failures literally: `(drift)` means the committed SVGs
   and the manifest disagree, so re-run the generator; `(idiom)` means a README H1 is not the
   generated line, character for character; a pill provenance failure means the badge is
   advertising something the repo no longer is. If a writing profile is active, RS-prose has to be
   green on every README this run wrote. RS-index is not this run's to make green: this skill
   declares no index and writes no row, so an RS-index failure here is a pre-existing one to
   report and hand to `/repo-standard-toolkit:atlas`, never to close by writing rows. Then run the whole suite for information. Do not
   commit unless asked; when asked, use a conventional commit
   (`feat(identity): generated banner and pill system`).

## Automated vs. manual recap

**Automated:** every file created or modified, one line each: the generator (with its version),
the manifest, each SVG rendered, each README whose H1 changed or that was created, and the
config block added. Name the palette's provenance in one sentence a stranger could check: how
many of the fifteen roles were read from real files, which files, and which were derived and by
what transform. Name every contrast nudge the engine made to someone's brand colour. List every
pill and its source, and every pill declared unverifiable with the reason the lint will now
print on every run. List every badge and what became of it: declared, turned into a pill, left
exactly as it was, or deleted with the operator's yes. Repeat both of the live-badge limits
there, so the operator reads the mismatch on their own page as the documented trade rather than
a bug: a third-party renderer will never be pixel-identical to a local one, so the family
resemblance is the colour and the label rather than the height, and a live badge always takes
the accent scheme because shields draws its value text white. If any directory this run gave a
banner has files nothing describes, name it as an `/repo-standard-toolkit:atlas` hand-off rather
than as work done here, and say plainly that this run wrote no catalog rows. If an atlas
migration handed back `identityEffects`, list each one and say which you carried out. If a
writing profile is active, name the scan you ran on the READMEs you wrote and its result, and say
which pages the profile's reach now governs. Any page the operator chose to leave outside that
reach is named, individually, as unenforced prose.

**Manual:** reviewing the rendered artwork on the real repo page (GitHub caches images through a
proxy, so the first push can take a moment to show), writing any folder README prose that needs
a human who knows the code, committing, and pushing.

State plainly what is now enforced: the artwork re-renders byte-identical from the manifest on
every CI run, every declared README H1 is checked character for character, every declared badge's
generated line has to be in the README, and every sourced pill is re-read from the file it came
from. And state what is not: a badge nobody declared is nobody's business, so the lint says
nothing about it, and it takes no network, so what shields is serving today is unverified here
too. And say the deeper limit: the lint imports the repo's own generator, so it proves the SVGs
follow from the manifest, not that nobody rewrote the generator. If the run stopped at a question, say which one, and that nothing was written.

## What feeds the next skill

The `assets` block in `.repo-standard.json` and the committed
`<assets.dir>/{manifest.json,generate.mjs}` (`assets.dir` in the config, default `.github/assets`)
are the durable interface: RS-assets polices them
on every push with the plugin gone. Re-invoking this skill is always safe (sense, reconcile,
keep) and is the upgrade path when the plugin ships a newer generator. If the repo has not
adopted the enterprise writing profile yet, `/repo-standard-toolkit:voice` is the next offer:
banner alt text and folder README prose are governed prose too.

`/repo-standard-toolkit:atlas` is the other one, and it is the right next step for any directory
whose files nothing describes. This skill writes no index at all: it reads directories to write
BANNER descriptions, which is not the same act as reading every file, and a row written from a
listing is exactly the confident lie the atlas exists to catch. Atlas owns index placement,
content, and configuration; identity owns the manifest, the artwork, and the generated markup,
and carries out the `identityEffects` an atlas migration hands back.
