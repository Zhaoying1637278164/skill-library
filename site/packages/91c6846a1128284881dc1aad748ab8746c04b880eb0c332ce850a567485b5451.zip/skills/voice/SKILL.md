---
name: voice
description: 'Bring a repo''s prose up to the enterprise writing standard and then lock it: scan every governed doc for em dashes in any form and for the filler and AI-writing tells, rewrite each hit sentence by sentence with the operator approving the diff, then switch the profile on in the config so the committed lint holds the line on every future push. Gated and reversible; nothing is rewritten without a yes. Use before adopting the profile on an existing repo, or to clear a sweep the lint is now failing.'
allowed-tools: Read Grep Glob AskUserQuestion Edit(README.md) Edit(CHANGELOG.md) Edit(CONVENTIONS.md) Edit(CONTRIBUTING.md) Edit(CODE_OF_CONDUCT.md) Edit(SECURITY.md) Edit(docs/**) Edit(**/README.md) Edit(*.md) Edit(**/*.md) Edit(.repo-standard.json) Write(.repo-standard.json) Bash(ls *) Bash(node *harness/sense-state.mjs *) Bash(node *harness/voice-scan.mjs *) Bash(node acceptance/test-repo-standard.mjs*) Bash(node acceptance/test-*.mjs*) Bash(for t in acceptance/test-*.mjs*)
---

# Voice

Bring this repo's prose up to the enterprise writing standard, then make it stick. Two rules,
both deterministic: no em dash in any form (the character, its HTML escapes, or an en dash doing
the same job), and none of the filler and AI-writing tells that make technical prose read as
unattended. The sweep is a guided phase with the operator approving the rewrites; the lock is a
line in `.repo-standard.json` that turns RS-prose on, after which the committed lint holds the
standard on every push with nobody watching.

## When to use

- An existing repo adopting the profile: sweep first, lock second, in that order
- A governed repo whose RS-prose check is failing after new prose landed
- A repo widening its scan from the governed docs to all markdown, or to every text file
- NOT for a fresh scaffold with nothing written yet: there is nothing to sweep, so just turn the
  profile on and let the lint catch the first violation
- NOT a copy edit. This fixes exactly the rules the lint enforces. Rewriting prose the standard
  does not object to is someone else's judgment substituted for the author's
- **Called by another skill over a named list of pages**, which is the bounded mode described
  below. `/repo-standard-toolkit:atlas` generates index prose and then converges it at its step 10,
  and a migration that widens `docs.extra` can pull pages nobody has swept under the profile for
  the first time
- NOT for released CHANGELOG history: everything below the first dated version is a record of
  what shipped, and the scan and the lint both stop there

## Prerequisites

- The target repo is the current working directory and is governed
  (`acceptance/test-repo-standard.mjs` + `.repo-standard.json` present). If not, the scaffold
  skill comes first: RS-prose is a check inside the lint that scaffold installs.
- **For a bounded run, three things from the caller and nothing inferred**: the list of pages, the
  reach they were found at, and the consent the caller already took for those edits. A bounded run
  has different prerequisites from an adoption run because it is a different job: it is clearing
  hits in named pages, not deciding whether this repo adopts a profile. Read them here rather than
  discovering them at the consent gate.
- Nothing else.

## Steps

1. **Sense, measure, and take the baseline.** Three commands, in this order.
   - `node ${CLAUDE_PLUGIN_ROOT}/harness/sense-state.mjs --target . --json`, then read
     `enforcement.prose`. If a profile is already declared, this run is a clear-the-failures
     pass, not an adoption.
   - `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --summary` for the size of
     the job: the totals first, the file set the reach resolved to, and any exemption already in
     force. Take detail later, and take it narrow: `--files-only` for the worst-first table the
     sweep works through, `--file <path>` for one file's hits. The full `--json` form is the
     whole hit list, which on a large repo is hundreds of kilobytes and reaches you truncated,
     and a truncated measurement is worse than none because it still looks like one. Exit 1
     means hits; exit 0 means the repo is already clean and this is a one-line config change.
   - `for t in acceptance/test-*.mjs; do node "$t" >/dev/null 2>&1 && echo "green $t" || echo "RED $t"; done`
     to record which of this repo's own standing tests pass today and which are ALREADY red,
     before you touch a word. Plenty of repos police their own prose, and the test that does it
     is not always named for it: a CI-hygiene test that greps the README, a counts test that
     asserts a number in a sentence you are about to rewrite. Do not try to classify which tests
     are prose tests. Record the two lists and hold the line on the delta at step 7.

2. **Choose the reach with the operator, before rewriting anything.** Price the whole menu
   first: run `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --scan <reach> --summary`
   once for EACH of `docs`, `markdown`, and `all`. Step 1 measured one reach, and quoting its
   number as the cost of another is how an operator agrees to a job twenty times the size they
   were shown. Each run is a few hundred bytes. Then AskUserQuestion, with the measured number
   beside each option:
   - **`docs`** (the default): the governed meta docs at the repo root, meaning `README.md`,
     `CHANGELOG.md`, `CONVENTIONS.md`, `CONTRIBUTING.md`, `SECURITY.md`, `CODE_OF_CONDUCT.md`,
     plus anything the config names in `docs.extra`. The prose a stranger reads. Say what it is
     not: a `docs/` directory is NOT in this reach, and the scan prints a line naming how many
     markdown files it left there. The bounded way to cover those pages is `docs.extra`, naming
     the highest-traffic ones first (the index a stranger navigates from, before the design
     notes), rather than widening to every file in the tree.
   - **`markdown`**: every `.md` in the tree, folder READMEs and design notes included.
   - **`all`**: every text file, comments and strings included. This is the maximalist choice.
     Say plainly what it means: source comments, test fixtures, and data files come into scope,
     a repo that picks it usually ends up exempting at least one directory, and this skill's own
     tool grant stops at markdown. Choosing `all` therefore needs a broader edit permission,
     granted by the operator at this gate, before the first rewrite. A permission boundary
     discovered on the forty-seventh file is the worst possible place to find one.
   - **not now**: keep it on the menu and mean it. A decline is a success, not a failure.
   `docs` and `markdown` are the two this skill can execute as granted. Report the blast radius
   next to the price: at `docs` that is six root files; at `markdown` it is every design note,
   skill doc, and folder README the repo keeps, which is usually exactly where its own standing
   tests are pointed. Sweeping 40 hits is an afternoon, 900 is a decision, and four figures is a
   project with a stopping point in it. The operator makes that call, not you.

   On **not now**: do not lock anything and do not record anything. Say the offer stands, name
   what a later run would cost at the reach they were looking at, and stop. Then ask ONE
   explicit follow-up: "record this so I stop asking?" Only an explicit yes writes
   `scaffold.answers.PROSE_OFFER = "declined"` into `.repo-standard.json`. That value is a
   terminal state (`sense-state` reports the offer as declined from then on, and the way back is
   hand-editing a file the config says is never hand-edited), so "not at this volume today" and
   "never ask again" must not be recorded as the same answer.

   **A BOUNDED RUN DOES NOT REACH THIS GATE, and it must never write through it.** When another
   skill hands over a named list of pages it has already taken consent for, the scope question has
   been asked and answered at a different altitude, and asking it again here is a second gate on
   one decision. So: skip the reach menu, sweep exactly the pages handed over, and **never write
   `scaffold.answers.PROSE_OFFER`.** A caller declining a cleanup of six pages is not the operator
   declining the pillar, and recording it as one would silence an offer nobody had made. If the
   caller supplies no list, this is not a bounded run: fall back to the gate above and ask.

3. **Agree the exemptions and the extra terms up front, not as an escape hatch later.** Some
   content genuinely cannot be rewritten: applied migration history, vendored third-party text,
   generated files, a fixture whose bytes are the test. Each becomes an entry in `prose.exempt`
   as `{ "path": "...", "why": "..." }`, and that reason prints on every run forever. Propose the
   ones the scan makes obvious, cite the scan lines each one covers, and let the operator add
   theirs. An exemption is not a defeat; an exemption nobody can see would be.

   One is worth raising before the operator hits it: `CODE_OF_CONDUCT.md`, whenever it carries
   the Contributor Covenant. That text is reproduced verbatim from an external standard, so
   rewriting it would misrepresent the standard the repo says it follows. Check the scan first,
   because the versions differ: Covenant 3.0 contains "In order to honor these values" and will
   appear in the results; Covenant 2.1 contains no banned term and no dash, and will not. If it
   has hits, propose the exemption and cite them. If it is clean, say so and let the operator
   decide whether they want the entry standing in advance, because an exemption for a file with
   nothing to exempt is a line printed on every run forever for no current benefit.

   The reverse case is the repo that already bans terms of its own. If the conventions doc
   states writing rules (a house word list, a banned marketing phrase), fold those terms into
   `prose.extraBanned` rather than leaving them to a second test nobody connected to this sweep:
   one gate then enforces both standards, and RS-reflexivity already requires each added term to
   be documented in the conventions doc, which is where the operator wrote them anyway. Say it
   that way to the operator ("this repo already bans X in Y, so I am folding it into the
   profile"), not as a second layer being added on top. The scan cannot see those terms until
   the block is written at step 6, so use Grep for them while you rewrite.

   The Covenant is the ONE exemption this toolkit's own payload costs a repo, and it is the same
   file for the same reason: the template that ships it carries that text too, so a repo
   scaffolded from it inherits the exemption rather than inventing one. Every OTHER payload file,
   the lint included, is profile-clean at every reach. Say it that way rather than as a blanket
   guarantee, because the blanket version is contradicted by a file this toolkit puts in the tree.

4. **Sweep, file by file, smallest edit that works.** Get the order from
   `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --scan <chosen> --files-only`,
   then pull each file's hits with `--scan <chosen> --file <path>`. Pass `--scan <chosen>` on
   every run from here until the config is written: without it the scan falls back to the
   repo's declared reach, which is `docs` on a repo that has not adopted yet, and you would
   sweep six files while believing you swept the tree. For each hit:
   - **An em dash is rewritten, never substituted.** The reason the rule exists is that an em
     dash is usually two sentences avoiding a decision. Pick the one the sentence actually
     needs: a colon when what follows explains what came before, a full stop when it is a second
     thought, parentheses when it is genuinely an aside, a comma for a short apposition. Swapping
     in a semicolon or a pair of hyphens is the same sentence wearing a disguise and the review
     will say so.
   - **Filler is cut or replaced with the specific thing it stands in for.** "Utilize" is "use".
     "In order to" is "to". "A wide range of" is a number you can check. "It should be noted
     that" is nothing at all; delete it and start with the noun.
   - **Preserve the author's meaning and their voice.** This is the hard rule of the whole phase.
     If a rewrite changes what a sentence claims, you have introduced a factual error into
     documentation under cover of a style pass. When a sentence resists, leave it, list it, and
     let the operator decide.
   - Quoted and backticked spans are already exempt in both the scan and the lint, so a doc that
     NAMES a banned term (a conventions file listing them, as it must) needs no change.
   Show the operator the diffs as you go, batched by file. A sweep that lands as one
   unreviewable commit across forty files is not a guided sweep.

   **The sweep is finished when the scan is.** Re-run
   `node ${CLAUDE_PLUGIN_ROOT}/harness/voice-scan.mjs --target . --scan <chosen> --summary`
   and keep going until it exits 0. This loop converges where a lint loop does not: the scan
   reports every remaining hit at once, so one pass closes the gap and a second pass is only
   needed if a rewrite introduced something new. The lint is a gate and reports one hit per run
   by design, so driving the sweep from it would be one invocation per sentence. Do not use it
   for this.

   **A bounded run finishes per file, because a whole-reach scan can never say what it is being
   asked.** With unrelated hits sitting elsewhere in the repo, `--summary` keeps exiting 1 forever
   and a run driven from it never terminates. So the done-condition for a caller-supplied list is
   `--scan <reach> --file <path>` exiting 0 for every path on it, one invocation per page. Report
   the result in those terms too: exit 0 here means THESE pages are clean, never that the repo is,
   and a caller reading the exit code alone would conclude the second.

5. **Document the standard in CONVENTIONS, because the lint requires it.** RS-reflexivity fails
   unless the conventions doc carries the em dash rule and every banned filler term, backticked
   as mentions. This is not bureaucracy: the profile is about to fail a contributor's build, so
   the rules have to exist somewhere they can read them. If the repo added `prose.extraBanned`
   terms, those go in too.

6. **Lock it, against a clean scan and not before.** Add the block to `.repo-standard.json`:
   `"prose": { "profile": "enterprise", "scan": "<chosen>", "exempt": [ ... ], "extraBanned": [ ... ] }`.
   Step 4's scan must be exiting 0 at the chosen reach when you write this. Locking a profile
   over prose nobody swept is a red build tomorrow morning, and it is red in the operator's CI
   rather than in this session where it could still be fixed.
   If a genuinely correct use of a banned filler term survives (a finance repo that means
   "leverage" the noun), add `{ "term": "...", "why": "..." }` to `prose.allow` rather than
   disabling the check: the allowance is one term, printed on every run, while a disable is the
   whole rule gone. The dash rules cannot be allowed away by design.
   **A bounded run stops before this step and does not lock anything.** It swept a named list, not
   a reach, so the clean scan it can show is about those pages alone. Locking a repo-wide profile
   on the strength of six clean files is exactly the red build tomorrow morning this step refuses,
   and adopting the pillar was never the caller's decision to make. Steps 5 and 6 belong to the
   adoption run; a bounded run does step 4 and step 7 and says which pages it touched.

7. **Confirm, then check the delta.** Run `node acceptance/test-repo-standard.mjs` ONCE and
   read RS-prose. It should be green already, because step 4's scan and this check share one
   canon (a standing test in the plugin fails the build if the two rule lists ever drift apart).
   A disagreement in either direction is a toolkit bug worth reporting rather than routing
   around: a clean scan with a red RS-prose, and a red scan with a green RS-prose, are both the
   sweep and the gate enforcing different standards, which is the worst outcome this feature
   has.

   Then re-run the repo's own suite and compare against step 1's baseline. A test that was
   already red stays the operator's: report it, unchanged. A test that was green in step 1 and
   is red now is a regression this sweep caused, and there are exactly two fixes, both in the
   prose: rewrite the sentence differently, or revert that edit. Never edit the other repo's
   test to accommodate a rewrite. Loosening someone's standing test to make your copy edit fit
   is a worse outcome than the red build, and it is not yours to do. Do not commit unless
   asked; when asked, use a conventional commit
   (`docs(voice): sweep prose to the enterprise profile and lock it`).

## Automated vs. manual recap

**Automated:** the hit count before and after, by file and by rule. Every file edited, with a
representative before and after quote for each: this phase changes prose a human wrote, so the
recap has to show what it did to it. The config block added, including every exemption,
allowance, and folded-in `extraBanned` term with the reason that will now print on every run.
The standing-test delta from step 1: which of the repo's own tests were already red (still
theirs), and that no test which was green went red.

**Manual:** reading the swept prose end to end. A rule-by-rule rewrite can be locally correct and
leave a paragraph that no longer flows, and no lint can see that. Name any sentence you left
alone because rewriting it would have changed its meaning, and any file the operator chose to
exempt. Then committing and pushing.

State plainly what is now enforced and where it reaches: the profile, the scan scope, and the
fact that released CHANGELOG history is out of scope by design. Name what the reach does NOT
cover while you are there, because the operator will read the locked profile as "the repo is
governed": at `docs`, that is every markdown file under a `docs/` directory that is not in
`docs.extra`, and the scan prints the count. If the sweep was partial (the operator stopped, or
a file was too load-bearing to rewrite in one sitting), say so and say that the profile was NOT
switched on, because a locked profile over an unswept repo is a red build tomorrow morning.

If the answer was **not now**, that is a finished run, not an abandoned one. Say what was
measured, that nothing was written, and that the offer stands. If the operator asked for the
decline to be recorded, say what the record buys them: `sense-state` will report the offer as
declined, so the next session stops asking.

A bounded run recaps in narrower words, and the narrowness is the honesty. Name the pages that were
handed over, the pages that were rewritten, and the hits that remain outside that list. Say that
the profile was not locked and that no decline was recorded, because neither was this run's to
decide. **Never report a bounded exit 0 as a clean repo**: it is a statement about the pages on the
list.

## What feeds the next skill

The `prose` block in `.repo-standard.json` is the durable interface: RS-prose runs on every push
with the plugin gone, and a contributor with vim hits the same gate. Re-invoking this skill later
is safe and is how a repo widens its scan or clears a fresh batch of hits. If the repo has not
run `/repo-standard-toolkit:identity` yet, note that generated banner alt text and folder README
prose land inside this same profile, so the two pillars agree by construction.

This skill is also reached from the other direction, and naming the callers here is what keeps the
contract two-sided. `/repo-standard-toolkit:atlas` runs `voice-scan.mjs` after its normalization
pass and again at its step 10, where it converges the prose over the final governed reach and hands
a bounded list here when pre-existing pages have just come under the profile;
`/repo-standard-toolkit:identity` runs the same engine over the prose it generates. Both call the
ENGINE freely, because reading is not writing. Only the rewriting comes here, and only with the
scope and the consent already named.
