#!/usr/bin/env node
/*
 * github-about.mjs: derive the GitHub About panel from what the repo already says about itself.
 *
 * The About panel is the first thing a stranger reads, and in most repos it is the last thing
 * anyone edits. It ends up describing a product from two years ago, in prose nobody would let
 * into the README, with topics that made sense before the rewrite. Nothing governs it because it
 * lives on someone else's server.
 *
 * This engine derives what the panel SHOULD say from facts the repo already carries: the README's
 * tagline, the version manifest's keywords and homepage, and the git remote. NOT the manifest's
 * own description, deliberately: a repo has one front page, and taking the description from
 * anywhere but the sentence it already leads with would give it two.
 * It never invents. A field it cannot source is reported as missing, with the file it would have
 * read, and the operator supplies it or the field is left alone. `proposal` carries only the
 * fields that were actually derived, so it is recordable as it stands; `missing` names the rest.
 *
 * `writeSemantics` says, per field, what applying that value DOES at the API: description and
 * homepage are field updates, topics is a whole-list replacement. That belongs in the payload
 * rather than in the human print, because the destructive one is the field a JSON consumer is
 * most likely to apply verbatim.
 *
 * READ-ONLY and OFFLINE: it never calls GitHub, never writes, and never reads the clock. Reading
 * the live panel and PATCHing it belongs to the skill, which can ask the operator first. That
 * split is the same one the rest of the toolkit keeps: engines decide what is derivable, the
 * agent does the part that touches someone's account.
 *
 * Usage: node harness/github-about.mjs [--target <dir>] [--json]
 * Dependency-free: Node built-ins only. Exit 0 derived · 1 nothing derivable · 2 bad invocation.
 */
import { readFileSync, existsSync, statSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, resolve } from 'node:path'

// GitHub's own limits, so a proposal is never rejected at the API for a reason we could have
// caught here: 350 characters of description, 20 topics, each lower-case kebab up to 50.
const MAX_DESCRIPTION = 350
const MAX_TOPICS = 20
const TOPIC_RE = /^[a-z0-9][a-z0-9-]{0,49}$/

// The one caution that is a property of the WRITE rather than of this repo, so it is stated
// once and read out by both output modes. Two hand-written copies of the same sentence is how
// the human print and the JSON payload drift apart, and the JSON is the mode the skills use.
const TOPICS_REPLACE_NOTE = [
  'GitHub REPLACES the whole topic list on write. These are derived from declared',
  'keywords only, so treat them as additions to whatever the repo already carries.',
  'A topic someone curated for discoverability is not derivable from any file here.',
]

const fail = (msg) => { console.error(`github-about: ${msg}`); process.exit(2) }

const args = process.argv.slice(2)
let target = '.', asJson = false
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--target') target = args[++i] || fail('--target expects a directory')
  else if (args[i] === '--json') asJson = true
  else fail(`unknown argument "${args[i]}"`)
}
target = resolve(target)
if (!existsSync(target) || !statSync(target).isDirectory()) fail(`target is not a directory: ${target}`)

const readIf = (rel) => { try { return readFileSync(join(target, rel), 'utf8').replace(/^﻿/, '') } catch { return null } }
const jsonIf = (rel) => { const t = readIf(rel); if (t === null) return null; try { return JSON.parse(t) } catch { return null } }
const git = (...argv) => {
  try { return execFileSync('git', ['-C', target, ...argv], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim() } catch { return null }
}

// ── the sources, in the order a human would trust them ────────────────────────────────────
const config = jsonIf('.repo-standard.json') ?? {}
const docsCfg = config.docs && typeof config.docs === 'object' ? config.docs : {}
const readmePath = typeof docsCfg.readme === 'string' ? docsCfg.readme : 'README.md'
const manifests = ['.claude-plugin/plugin.json', 'package.json']
  .map((p) => ({ path: p, data: jsonIf(p) }))
  .filter((m) => m.data !== null)

/*
 * The description is the README's bold tagline, not the manifest's. A repo has one front page,
 * and the tagline is the sentence it already chose to lead with; taking the description from
 * anywhere else would give it two answers to the same question, which is how they drift apart.
 * The tagline is also already governed by the readme, voice, and prose checks, so the About
 * inherits the writing standard rather than needing its own.
 */
const taglineOf = (text) => {
  if (text === null) return null
  const stripped = text.replace(/^[ \t]*(```|~~~)[\s\S]*?^[ \t]*\1[^\n]*$/gm, '').replace(/<!--[\s\S]*?-->/g, '')
  const h1 = [...stripped.matchAll(/^# +.+$/gm)][0]
  if (!h1) return null
  // The tagline is the first BOLD SPAN after the H1, and it can wrap across lines: taking the
  // first line instead cuts a wrapped tagline mid sentence and leaves the `**` marker stranded
  // in the middle of what then gets published as the repo's description.
  const after = stripped.slice(h1.index + h1[0].length)
  const bold = after.match(/\*\*([\s\S]+?)\*\*/)
  return bold ? bold[1].replace(/\s+/g, ' ').trim() || null : null
}

const readmeText = readIf(readmePath)
const description = taglineOf(readmeText)
const descriptionSource = description ? `${readmePath} (the bold tagline under the H1)` : null

// The homepage is whatever the repo already publishes as its own, never the repo URL dressed up
// as a product site: pointing About's website field back at the page it is already on tells a
// reader nothing.
const remote = git('rev-parse', '--show-toplevel') === target ? git('remote', 'get-url', 'origin') : null
const repoUrl = remote ? remote.replace(/\.git$/, '').replace(/^git@([^:]+):/, 'https://$1/') : null
let homepage = null, homepageSource = null
for (const m of manifests) {
  const h = typeof m.data.homepage === 'string' ? m.data.homepage : null
  if (h && h.trim() && h.replace(/#.*$/, '').replace(/\/$/, '') !== (repoUrl ?? '').replace(/\/$/, '')) {
    homepage = h.trim(); homepageSource = `${m.path} homepage`; break
  }
}

// Topics come from declared keywords. A repo that declares none gets none proposed: guessing
// topics from a directory listing is exactly the kind of confident invention this toolkit
// refuses everywhere else, and a wrong topic is worse than a missing one because it puts the
// repo in front of the wrong people.
let topics = [], topicsSource = null
for (const m of manifests) {
  const k = Array.isArray(m.data.keywords) ? m.data.keywords.filter((x) => typeof x === 'string') : []
  if (k.length) { topics = k; topicsSource = `${m.path} keywords`; break }
}
const normalized = topics.map((k) => k.trim().toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50))
const validTopics = [...new Set(normalized.filter((k) => TOPIC_RE.test(k)))]
const rejectedTopics = topics.filter((k, i) => !TOPIC_RE.test(normalized[i]))
const cappedTopics = validTopics.slice(0, MAX_TOPICS)

// ── report ────────────────────────────────────────────────────────────────────────────────
const missing = []
if (!description) missing.push({ field: 'description', wouldHaveRead: `${readmePath} (the bold tagline under the H1)` })
if (!homepage) missing.push({ field: 'homepage', wouldHaveRead: manifests.length ? `${manifests.map((m) => m.path).join(' or ')} homepage` : 'a version manifest, of which this repo has none' })
if (!cappedTopics.length) missing.push({ field: 'topics', wouldHaveRead: manifests.length ? `${manifests.map((m) => m.path).join(' or ')} keywords` : 'a version manifest, of which this repo has none' })

const warnings = []
if (description && description.length > MAX_DESCRIPTION) warnings.push(`the tagline is ${description.length} characters; GitHub truncates the About panel at ${MAX_DESCRIPTION}`)
if (rejectedTopics.length) warnings.push(`${rejectedTopics.length} keyword(s) are not valid GitHub topics and were dropped: ${rejectedTopics.join(', ')}`)
if (validTopics.length > MAX_TOPICS) warnings.push(`${validTopics.length} topics derived, capped at GitHub's limit of ${MAX_TOPICS}; the ${validTopics.length - MAX_TOPICS} dropped are: ${validTopics.slice(MAX_TOPICS).join(', ')}`)

const report = {
  ok: Boolean(description),
  target,
  repoSlug: repoUrl ? repoUrl.split('/').slice(-2).join('/') : null,
  // Only what was derived: a field the engine could not source is named in `missing`, and its
  // absence here is what makes this object something the skill can record verbatim.
  //   Every field is conditional, and `topics` is the one that matters. It writes as a WHOLE-LIST
  // REPLACEMENT, so a proposal carrying `topics: []` because nothing was derivable, applied
  // verbatim by a consumer doing what this object invites, deletes every topic the repo had. An
  // empty list is not a proposal to have no topics; it is the absence of a proposal, and the two
  // have to look different. `description: null` is the same failure in the shape that already bit
  // once, when a recorded `homepage: null` wedged a scaffold run on its last step.
  proposal: {
    ...(description ? { description } : {}),
    ...(homepage ? { homepage } : {}),
    ...(cappedTopics.length ? { topics: cappedTopics } : {}),
  },
  sources: { description: descriptionSource, homepage: homepageSource, topics: topicsSource },
  writeSemantics: {
    description: 'field-update',
    homepage: 'field-update',
    '//topics': TOPICS_REPLACE_NOTE.join(' '),
    topics: 'replace-whole-list',
  },
  missing,
  warnings,
}

if (asJson) {
  console.log(JSON.stringify(report, null, 2))
} else {
  console.log(`github-about: ${target}`)
  console.log(`  repo: ${report.repoSlug ?? '(no git remote, so there is no About panel to sync)'}`)
  console.log(`\n  description: ${description ?? '(not derivable)'}`)
  if (descriptionSource) console.log(`    from ${descriptionSource}`)
  console.log(`  homepage:    ${homepage ?? '(none declared, and the repo URL is not a homepage)'}`)
  if (homepageSource) console.log(`    from ${homepageSource}`)
  console.log(`  topics:      ${cappedTopics.length ? cappedTopics.join(', ') : '(none declared)'}`)
  if (topicsSource) console.log(`    from ${topicsSource}`)
  for (const m of missing) console.log(`\n  ! ${m.field} is not derivable: would have read ${m.wouldHaveRead}`)
  if (cappedTopics.length) {
    console.log('')
    TOPICS_REPLACE_NOTE.forEach((line, i) => console.log(`${i === 0 ? '  ! ' : '    '}${line}`))
  }
  for (const w of warnings) console.log(`\n  ! ${w}`)
  if (!report.ok) console.log('\n  Nothing to propose without a description. The About panel takes the repo\'s own tagline, so give the README one first.')
}
// SET, never taken: process.exit() drops whatever stdout has not drained, which truncates a
// piped --json at the 64 KiB pipe buffer. Letting Node exit on its own flushes first.
process.exitCode = report.ok ? 0 : 1
