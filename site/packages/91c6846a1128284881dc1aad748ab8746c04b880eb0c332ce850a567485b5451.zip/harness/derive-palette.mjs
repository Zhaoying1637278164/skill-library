#!/usr/bin/env node
/*
 * derive-palette.mjs — read a repo's own design identity and propose the banner palette.
 *
 * The identity a repo already ships (its stylesheet custom properties, its Tailwind theme, its
 * design-token JSON) is the only honest source for what its README should look like. This
 * engine finds those colours, maps them onto the fifteen roles the generator renders, and
 * records WHERE each one came from so the committed lint can re-check the claim forever. When
 * the design identity later moves, RS-assets says the banners drifted instead of leaving them
 * quietly representing a brand that changed.
 *
 * It never invents a brand. A role it cannot read from the repo is DERIVED from one it could,
 * by a named, deterministic transform ("mix-black-40"), and every role says which it was. If
 * the repo has no design identity to read, the engine says so and exits non-zero rather than
 * proposing something plausible; the skill then offers the shipped presets instead.
 *
 * Contrast is repaired, not assumed. The lint enforces 4.5:1 (WCAG 2.2 AA) on nine text pairs,
 * so a proposal that would fail is nudged in fixed steps until it passes, with the nudge
 * recorded. A pair that cannot reach the floor is reported as a failure, never shipped.
 *
 * READ-ONLY: no writes, no clock, no randomness. The same tree always proposes the same
 * palette.
 *
 * Usage: node harness/derive-palette.mjs [--target <dir>] [--json]
 * Dependency-free: Node built-ins only. Exit 0 proposed · 1 nothing derivable · 2 bad invocation.
 */
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'

const ROLES = ['groundDeep', 'groundMid', 'ground', 'waveNear', 'waveFar', 'text', 'textMuted', 'rim',
  'accent', 'accentAlt', 'accentSoft', 'pillAccentBg', 'pillAccentFg', 'pillAltBg', 'pillAltFg']
const CONTRAST_PAIRS = [['text', 'ground'], ['text', 'groundMid'], ['text', 'groundDeep'],
  ['textMuted', 'ground'], ['textMuted', 'groundMid'], ['accentAlt', 'ground'], ['accentAlt', 'groundMid'],
  ['pillAccentFg', 'pillAccentBg'], ['pillAltFg', 'pillAltBg']]
const FLOOR = 4.5
// Directories with no design identity in them, only build output and other people's code.
const SKIP_DIRS = new Set(['.git', 'node_modules', 'dist', 'build', 'out', 'coverage', 'vendor',
  '.next', '.nuxt', '.svelte-kit', '.venv', 'venv', '__pycache__', 'target'])
// A minified bundle is a wall of colours with no names attached, which is noise, not identity.
const MAX_BYTES = 512 * 1024
const MAX_FILES = 500
// Evidence floor. Two stray hex values in one file are not a design system, and deriving a
// repo's whole visual identity from them would be a confident answer to a question the repo
// never actually answered. Below this, the honest report is "there is nothing here to read".
const MIN_POOL = 6

const fail = (msg) => { console.error(`derive-palette: ${msg}`); process.exit(2) }

const args = process.argv.slice(2)
let target = '.', asJson = false
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--target') target = args[++i] || fail('--target expects a directory')
  else if (args[i] === '--json') asJson = true
  else fail(`unknown argument "${args[i]}"`)
}
target = resolve(target)
if (!existsSync(target) || !statSync(target).isDirectory()) fail(`target is not a directory: ${target}`)

// ── colour maths ──────────────────────────────────────────────────────────────────────────
const norm = (hex) => {
  const h = hex.replace('#', '').toLowerCase()
  return `#${h.length === 3 ? [...h].map((c) => c + c).join('') : h}`
}
const toRgb = (hex) => {
  const h = norm(hex).slice(1)
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]
}
const toHex = ([r, g, b]) => `#${[r, g, b].map((c) => Math.max(0, Math.min(255, Math.round(c))).toString(16).padStart(2, '0')).join('')}`
const mix = (hex, towardHex, t) => {
  const a = toRgb(hex), b = toRgb(towardHex)
  return toHex([0, 1, 2].map((i) => a[i] + (b[i] - a[i]) * t))
}
const BLACK = '#000000', WHITE = '#ffffff'
const luminance = (hex) => {
  const [r, g, b] = toRgb(hex).map((c) => c / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
const contrast = (a, b) => {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x)
  return (hi + 0.05) / (lo + 0.05)
}
const saturation = (hex) => {
  const [r, g, b] = toRgb(hex).map((c) => c / 255)
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  return max === 0 ? 0 : (max - min) / max
}
const hue = (hex) => {
  const [r, g, b] = toRgb(hex).map((c) => c / 255)
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min
  if (d === 0) return 0
  const h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4
  return ((h * 60) % 360 + 360) % 360
}
const hueGap = (a, b) => { const d = Math.abs(hue(a) - hue(b)) % 360; return d > 180 ? 360 - d : d }

// ── harvest: every named colour the repo declares about itself ────────────────────────────
const HEX = '#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})\\b'
const EXTRACTORS = [
  // CSS custom properties and SCSS/LESS variables: the token name is right there.
  { test: /\.(css|scss|sass|less|styl)$/, re: new RegExp(`(--[A-Za-z0-9_-]+|\\$[A-Za-z0-9_-]+|@[A-Za-z0-9_-]+)\\s*:\\s*(${HEX})`, 'g') },
  // Tailwind and JS/TS theme objects: `primary: '#0ea5e9'` or `"brand": "#0ea5e9"`.
  { test: /(tailwind|theme|tokens|colou?rs|palette|design)[^/]*\.(js|ts|mjs|cjs|jsx|tsx)$/i, re: new RegExp(`["']?([A-Za-z0-9_-]+)["']?\\s*:\\s*["'](${HEX})["']`, 'g') },
  // Design-token JSON, by filename or by living in a tokens/theme directory.
  { test: /(theme|tokens|colou?rs|palette|design)[^/]*\.json$/i, re: new RegExp(`"([A-Za-z0-9_ -]+)"\\s*:\\s*"(${HEX})"`, 'g') },
  { test: /(^|\/)(design|theme|tokens|styles)\/[^/]+\.json$/i, re: new RegExp(`"([A-Za-z0-9_ -]+)"\\s*:\\s*"(${HEX})"`, 'g') },
  // The browser-chrome colour a site declares about itself.
  { test: /\.(html|htm|webmanifest)$/, re: new RegExp(`(theme[_-]?color)["']?[^#]{0,20}(${HEX})`, 'gi') },
]

const walk = (rel = '') => {
  const abs = rel ? join(target, rel) : target
  let entries
  try { entries = readdirSync(abs, { withFileTypes: true }) } catch { return [] }
  return entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0)).flatMap((e) => {
    const child = rel ? `${rel}/${e.name}` : e.name
    if (e.isDirectory()) return SKIP_DIRS.has(e.name) ? [] : walk(child)
    return e.isFile() ? [child] : []
  })
}

const candidates = []
const files = walk()
let scanned = 0, capped = false
for (const rel of files) {
  const ex = EXTRACTORS.find((x) => x.test.test(rel))
  if (!ex) continue
  if (scanned >= MAX_FILES) { capped = true; break }
  let text
  try {
    if (statSync(join(target, rel)).size > MAX_BYTES) continue
    text = readFileSync(join(target, rel), 'utf8')
  } catch { continue }
  scanned++
  const lineStarts = []
  for (let i = 0, n = 0; i < text.length; i++) if (text[i] === '\n') lineStarts.push(n = i)
  const lineOf = (idx) => lineStarts.filter((s) => s < idx).length + 1
  for (const m of text.matchAll(ex.re)) {
    candidates.push({ token: m[1], hex: norm(m[2]), file: rel, line: lineOf(m.index) })
  }
}
// Deduplicate on (token, value): the same token restated in a media query is one declaration,
// and the count of DISTINCT places a colour appears is what makes it load-bearing.
const seen = new Map()
for (const c of candidates) {
  const key = `${c.token}|${c.hex}`
  const prev = seen.get(key)
  if (prev) prev.uses++
  else seen.set(key, { ...c, uses: 1 })
}
const pool = [...seen.values()].sort((a, b) => b.uses - a.uses || (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line))

// ── map the pool onto the roles ───────────────────────────────────────────────────────────
const provenance = {}
const palette = {}
const warnings = []
const used = new Set()

const pick = (role, { name, filter }) => {
  const hit = pool.find((c) => !used.has(`${c.file}:${c.line}`) && name.test(c.token) && (!filter || filter(c.hex)))
  if (!hit) return false
  used.add(`${hit.file}:${hit.line}`)
  palette[role] = hit.hex
  provenance[role] = { kind: 'token', file: hit.file, line: hit.line, token: hit.token, value: hit.hex, transform: 'none' }
  return true
}
const derive = (role, from, transform, value) => {
  palette[role] = value
  provenance[role] = { kind: 'derived', from, transform, value }
}
const constant = (role, value, why) => {
  palette[role] = value
  provenance[role] = { kind: 'constant', value, why }
}

// The accent is the one role that must come from the repo: it is the colour a reader will
// recognize as this product. Without it there is no derived identity, only a guess.
const gotAccent = pool.length >= MIN_POOL && (
  pick('accent', {
    name: /(^|[-_])(primary|brand|accent)([-_]|$)|^\$?(primary|brand|accent)$/i,
    filter: (h) => saturation(h) >= 0.2 && luminance(h) >= 0.06 && luminance(h) <= 0.8,
  }) || pick('accent', {
    name: /colou?r|accent|primary|brand|main/i,
    filter: (h) => saturation(h) >= 0.35 && luminance(h) >= 0.1 && luminance(h) <= 0.75,
  })
)

if (!gotAccent) {
  const report = {
    ok: false,
    reason: pool.length === 0
      ? 'no named colours found: this repo declares no design tokens (no CSS custom properties, theme config, or token JSON), so there is no identity here to derive from'
      : pool.length < MIN_POOL
        ? `found only ${pool.length} named colour(s), below the ${MIN_POOL} it takes to call something a design system: too little to derive a whole identity from without inventing most of it`
        : `found ${pool.length} named colour(s), none of which reads as a brand accent (a saturated, mid-luminance token named primary, brand, or accent)`,
    scanned: { files: scanned, candidates: pool.length, capped },
    sample: pool.slice(0, 12).map(({ token, hex, file, line }) => ({ token, hex, file, line })),
    suggestion: 'use a shipped preset (payload/assets/palettes/{forest,violet,slate}.json) or supply the colours directly',
  }
  if (asJson) console.log(JSON.stringify(report, null, 2))
  else {
    console.log(`derive-palette: ${target}`)
    console.log(`  scanned ${scanned} file(s), found ${pool.length} named colour(s)${capped ? ' (file cap reached)' : ''}`)
    console.log(`\n  cannot derive: ${report.reason}`)
    for (const s of report.sample) console.log(`    ${s.hex}  ${s.token}  (${s.file}:${s.line})`)
    console.log(`\n  ${report.suggestion}`)
  }
  // Synchronous, unlike the tail: everything below assumes an accent was found, so this must
  // actually stop rather than merely set a code. The truncation the tail guards against needs
  // more than 64 KiB of pending output to bite, and this report is a bounded refusal (one reason,
  // at most twelve samples), so exiting here loses nothing.
  process.exit(1)
}

// A second accent, ideally a genuinely different hue: the prism bar reads as a gradient only
// when its ends disagree.
if (!pick('accentAlt', {
  name: /(secondary|warning|amber|gold|highlight|attention|caution)/i,
  filter: (h) => saturation(h) >= 0.25 && luminance(h) >= 0.1 && hueGap(h, palette.accent) >= 40,
})) {
  // Cycling the channels (r,g,b) to (b,r,g) rotates the hue by exactly 120 degrees, a third of
  // the way round the wheel: the deterministic stand-in for a second brand colour the repo never
  // declared. The transform NAME is recorded in the manifest as provenance, so it has to be the
  // arithmetic the code actually performs. It read `hue-rotate-140` for three versions, which is
  // a re-verifiable-looking claim that never matched the maths.
  const [r, g, b] = toRgb(palette.accent)
  derive('accentAlt', 'accent', 'hue-rotate-120', toHex([b, r, g]))
  warnings.push('accentAlt was derived by rotating the accent hue: the repo declares no second brand colour, so review this one closely')
}

// The ground. A repo's own dark surface if it has one, otherwise the accent taken most of the
// way to black, which keeps the artwork in the product's colour family.
if (!pick('ground', {
  name: /(bg|background|surface|base|canvas|deck|ground|paper|shell)/i,
  filter: (h) => luminance(h) <= 0.09,
})) {
  derive('ground', 'accent', 'mix-black-88', mix(palette.accent, BLACK, 0.88))
}
derive('groundDeep', 'ground', 'mix-black-30', mix(palette.ground, BLACK, 0.3))
derive('groundMid', 'ground', 'mix-white-08', mix(palette.ground, WHITE, 0.08))
derive('waveNear', 'ground', 'mix-black-55', mix(palette.ground, BLACK, 0.55))
derive('waveFar', 'ground', 'mix-black-72', mix(palette.ground, BLACK, 0.72))

if (!pick('text', {
  name: /(text|fg|foreground|ink|copy|body)/i,
  filter: (h) => luminance(h) >= 0.6,
})) {
  derive('text', 'ground', 'mix-white-93', mix(palette.ground, WHITE, 0.93))
}
if (!pick('textMuted', {
  name: /(muted|subtle|dim|tertiary|placeholder|secondary[-_]?text)/i,
  filter: (h) => luminance(h) >= 0.15 && luminance(h) <= 0.7,
})) {
  derive('textMuted', 'text', 'mix-ground-45', mix(palette.text, palette.ground, 0.45))
}
if (!pick('rim', {
  name: /(border|divider|rule|line|outline|rim|stroke)/i,
  filter: (h) => luminance(h) >= 0.05,
})) {
  derive('rim', 'accent', 'mix-text-35', mix(palette.accent, palette.text, 0.35))
}
derive('accentSoft', 'accent', 'mix-textMuted-45', mix(palette.accent, palette.textMuted, 0.45))

// Pills sit on their own plate rather than on the ground, so their two schemes are built to be
// legible in isolation: a deep plate under white, and a pale plate under a deep tint.
derive('pillAccentBg', 'accent', 'mix-black-42', mix(palette.accent, BLACK, 0.42))
constant('pillAccentFg', WHITE, 'white on the deep accent plate is the highest-contrast option available')
derive('pillAltBg', 'accentAlt', 'mix-white-86', mix(palette.accentAlt, WHITE, 0.86))
derive('pillAltFg', 'accentAlt', 'mix-black-58', mix(palette.accentAlt, BLACK, 0.58))

// ── repair contrast, or say it could not be repaired ──────────────────────────────────────
// The floor is not advisory: the lint enforces it, and a palette that fails it makes a repo's
// front page unreadable for exactly the people who most need it not to be.
const nudge = (role, towardHex, label) => {
  const before = palette[role]
  for (let step = 1; step <= 20; step++) {
    palette[role] = mix(before, towardHex, step * 0.05)
    if (CONTRAST_PAIRS.every(([fg, bg]) => (fg !== role && bg !== role) || contrast(palette[fg], palette[bg]) >= FLOOR)) {
      const p = provenance[role]
      provenance[role] = { ...p, kind: p.kind === 'token' ? 'token-adjusted' : p.kind, value: palette[role], transform: `${p.transform === 'none' ? '' : `${p.transform} then `}${label}-${step * 5}`, adjustedFrom: before }
      warnings.push(`${role} was lightened or darkened from ${before} to ${palette[role]} to clear the ${FLOOR}:1 contrast floor`)
      return true
    }
  }
  palette[role] = before
  return false
}
const failures = []
for (const [fg, bg] of CONTRAST_PAIRS) {
  if (contrast(palette[fg], palette[bg]) >= FLOOR) continue
  const toward = luminance(palette[bg]) < 0.5 ? WHITE : BLACK
  if (!nudge(fg, toward, toward === WHITE ? 'lighten' : 'darken')) failures.push(`${fg} on ${bg} (${contrast(palette[fg], palette[bg]).toFixed(2)}:1)`)
}

const contrastReport = CONTRAST_PAIRS.map(([fg, bg]) => ({ pair: `${fg} on ${bg}`, ratio: Number(contrast(palette[fg], palette[bg]).toFixed(2)) }))
const ok = failures.length === 0
// Only file-backed roles go into the manifest's paletteSource: those are the ones the lint can
// re-read later. A derived role has nothing to re-check, and recording it as if it did would
// be the exact kind of unfalsifiable claim this toolkit exists to stop.
const manifestPaletteSource = {
  kind: 'derived',
  roles: Object.fromEntries(Object.entries(provenance)
    .filter(([, p]) => p.file && p.kind === 'token')
    .map(([role, p]) => [role, { file: p.file, token: p.token, value: p.value, transform: p.transform }])),
}

const report = { ok, target, scanned: { files: scanned, candidates: pool.length, capped }, palette, provenance, manifestPaletteSource, contrast: contrastReport, warnings, failures }

if (asJson) {
  console.log(JSON.stringify(report, null, 2))
} else {
  console.log(`derive-palette: ${target}`)
  console.log(`  scanned ${scanned} file(s), found ${pool.length} named colour(s)${capped ? ` (stopped at the ${MAX_FILES}-file cap, so this is a partial read)` : ''}`)
  console.log(`  file-backed roles: ${Object.keys(manifestPaletteSource.roles).length} of ${ROLES.length}\n`)
  for (const role of ROLES) {
    const p = provenance[role]
    const where = p.kind === 'token' || p.kind === 'token-adjusted' ? `${p.token}  (${p.file}:${p.line})`
      : p.kind === 'derived' ? `derived from ${p.from} by ${p.transform}`
      : `constant: ${p.why}`
    console.log(`  ${palette[role]}  ${role.padEnd(13)} ${where}`)
  }
  console.log('\n  contrast:')
  for (const c of contrastReport) console.log(`    ${c.ratio >= FLOOR ? 'ok  ' : 'FAIL'} ${String(c.ratio).padStart(6)}:1  ${c.pair}`)
  for (const w of warnings) console.log(`\n  ! ${w}`)
  for (const f of failures) console.log(`\n  ✗ ${f} cannot reach the ${FLOOR}:1 floor from this repo's colours`)
  if (!ok) console.log('\n  Not proposable as it stands: pick a preset, or supply the failing roles directly.')
}
// SET, never taken: process.exit() drops whatever stdout has not drained, which truncates a
// piped --json at the 64 KiB pipe buffer. Letting Node exit on its own flushes first.
process.exitCode = ok ? 0 : 1
