#!/usr/bin/env node
/*
 * index-plan.mjs: what an atlas run would have to read, and how much of it there is.
 *
 * The atlas journey writes one row per file, from the file itself, across every directory that
 * keeps an index. Before any of that happens the operator has to approve a fan-out, and an offer
 * is only meaningful if the size in it is right. A skill that counted its own work would be
 * guessing at the number the operator is being asked to agree to, so the counting lives here.
 *
 * THREE QUESTIONS, ANSWERED SEPARATELY, because conflating them is how a sweep silently skips a
 * directory it was asked to check:
 *
 *   structuralWork          What is MISSING: files carrying no row, rows pointing at a file that
 *                           is gone, a row the gate refuses on grammar, an index that does not
 *                           exist yet, a directory holding kept files no declaration reaches, an
 *                           index sitting where a migration would move it, and (under strict
 *                           ownership only) the files nobody has decided about. This is what the
 *                           EXIT CODE carries, and nothing else does.
 *   reconciliationPlan      What a full RE-READ costs, whether or not anything is missing. An
 *                           index can carry a row for every file and have every row be false: no
 *                           check anywhere reads a description and knows it still matches the
 *                           code. So a structurally complete index is still work, and the exit
 *                           code deliberately does not say so. A run that read exit 0 as "done"
 *                           skipped a complete-but-stale index on the first real target this
 *                           engine met, which is why the two are now separate fields with the
 *                           verdict spelled out in the output rather than left to a convention.
 *   migrationOpportunities  An index sitting somewhere GitHub does not render when a reader
 *                           browses the directory, where the conventional home is free. Offered,
 *                           never taken.
 *
 * The coverage rule here is a deliberate TWIN of the one in RS-index (the lint ships as one
 * self-contained file into target repos, so it cannot import a shared module). A standing test
 * runs both over this repo's real config and fails the build if the two ever disagree about which
 * files need a row: a planner that scoped the sweep differently from the gate would send agents
 * to write rows the lint does not want, and skip the ones it does.
 *
 * READ-ONLY by design: it never edits, never writes, and never reads the clock. Chunk sizes are
 * fixed constants rather than a heuristic over machine load, so the same tree always plans the
 * same way and an offer can be re-read tomorrow and still mean what it said.
 *
 * Usage:
 *   node harness/index-plan.mjs [--target <dir>]
 *     [--index <path>]        narrow to one declared index (a reconciliation of one directory)
 *     [--mode gaps|reconcile] what the CHUNKS cover: the uncovered files, or every file (default)
 *     [--candidate <dir>]     price a directory that keeps no index YET, exactly
 *     [--index-file <path>]   where that prospective index would live (default: the free README)
 *     [--extensions .a,.b]    what it would speak for (default: every readable extension found)
 *     [--scope direct|recursive]  what it would own (default: direct, the model atlas declares)
 *     [--chunk <n>]           print one chunk's file list and nothing else
 *     [--summary]             counts and one line per index, with no file lists
 *     [--json]
 *
 * Without --index, every declared index is planned, and every directory that keeps a README
 * without keeping an index is reported as a candidate: those are the directories an atlas run
 * would OFFER to start indexing, never the ones it would just do. Candidate discovery skips
 * dot-directories, so a `.github/README.md` is never proposed. That is the same exclusion
 * `assets.coverage` makes, for the same reason: those directories hold tooling a reader does not
 * browse. A dot-directory that genuinely wants an index gets one by being declared, and the
 * planner covers it from then on like any other. A directory the operator has already turned
 * down is listed under `docs.declined` and is reported as declined rather than offered again.
 *
 * Dependency-free: Node built-ins only. Exit 0 no structural work · 1 structural work · 2 bad
 * invocation.
 */
import { readFileSync, readdirSync, existsSync, statSync, lstatSync, readlinkSync, realpathSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, resolve, dirname, sep } from 'node:path'

// ── the canon, twinned with RS-index ──────────────────────────────────────────────────────
const INDEX_STATUSES = ['active', 'superseded', 'reference', 'design', 'delivered']
const INDEX_KEYS = ['file', 'extensions', 'scope', 'statuses', 'aliases', 'ordered', 'requireDate', 'reconciled', 'ignore', 'retain', 'grammar']
const INDEX_SCOPES = ['direct', 'recursive']
const INDEX_GRAMMARS = [1, 2]
const WALK_SKIP_DIRS = new Set(['.git', 'node_modules'])
// A markdown link, with the two destination spellings CommonMark allows. The angle-bracket form
// is the only way to write a path containing a space, and a parser that missed it read the row
// as prose and then reported the file it linked as uncatalogued.
const LINK = /\[[^\]]*\]\(/
/*
 * INLINE CODE SPANS as offset ranges, twinned with the gate, because a link inside one is not a
 * link. `| `[one.mjs](one.mjs)` | ... |` renders as literal text and catalogues nothing, and both
 * engines counted it as a row for one.mjs. Blanking spans wholesale is not the fix: `` `active` ``
 * is the ordinary status cell and `` [`one.mjs`](one.mjs) `` puts a span inside a link LABEL.
 * CommonMark 6.3: a backtick string of length N opens a span, the next of EXACTLY length N closes.
 */
const codeSpans = (s) => {
  const runs = [...s.matchAll(/`+/g)].map((m) => ({ at: m.index, len: m[0].length }))
  const out = []
  for (let i = 0; i < runs.length; i++) {
    for (let j = i + 1; j < runs.length; j++) {
      if (runs[j].len !== runs[i].len) continue
      out.push([runs[i].at, runs[j].at + runs[j].len])
      i = j
      break
    }
  }
  return out
}
const insideSpan = (spans, at) => spans.some(([a, b]) => at >= a && at < b)
/*
 * ONE PARSED LINK, read by hand rather than by regex, answering every question from the offset the
 * link opened at. Two regexes over a whole cell answered two questions about two different links:
 * in `[a](open.md and also [b](closed.md)` the destination came from the first and the closure test
 * was satisfied by the second.
 *   A regex could not do the rest either. CommonMark 6.6 allows BALANCED parentheses in an
 * unbracketed destination, so `[x](one(a).mjs)` names `one(a).mjs`, and a `[^\s)]+` destination
 * stopped at the first `)`, named `one(a`, and reported a correct row as pointing nowhere.
 */
const WS = (c) => c !== undefined && /\s/.test(c)
// The destination of a link whose "](" ends at offset k, plus where the link ENDS. Shared by the
// index parser and the migration scan, so the two read a destination the same way and an offset
// is available to whichever of them needs one.
const readDest = (s, k) => {
  while (WS(s[k])) k++
  let dest = ''
  if (s[k] === '<') {
    const gt = s.indexOf('>', k + 1)
    if (gt === -1) return { dest: '', end: k, closed: false }
    dest = s.slice(k + 1, gt)
    k = gt + 1
  } else {
    const start = k
    let depth = 0
    for (; k < s.length; k++) {
      const c = s[k]
      if (WS(c)) break
      if (c === '(') depth++
      else if (c === ')') { if (depth === 0) break; depth-- }
    }
    dest = s.slice(start, k)
  }
  while (WS(s[k])) k++
  if (s[k] === '"' || s[k] === "'") {
    const q = s.indexOf(s[k], k + 1)
    if (q !== -1) { k = q + 1; while (WS(s[k])) k++ }
  }
  const closed = s[k] === ')'
  return { dest: dest.trim(), end: closed ? k + 1 : k, closed }
}
/*
 * A BACKSLASH ESCAPE, counted rather than looked for, twinned with the gate. CommonMark 2.4 lets any
 * ASCII punctuation be escaped and an escape can itself be escaped, so what decides is whether the
 * run of backslashes in front of a character is ODD. `\[one.mjs](one.mjs)` renders as literal text
 * and catalogues nothing, and it was read here as a row.
 */
const escapedAt = (s, i) => { let n = 0; while (i - 1 - n >= 0 && s[i - 1 - n] === '\\') n++; return n % 2 === 1 }
const firstLink = (cell, spans = codeSpans(cell)) => {
  for (let i = 0; i < cell.length; i++) {
    if (cell[i] !== '[' || insideSpan(spans, i) || escapedAt(cell, i)) continue
    // AN IMAGE IS NOT A LINK. `![alt](one.mjs)` renders the file as a picture; a reader cannot click
    // through to it, and a catalog row is the one place a destination has to be navigable. Both
    // engines read it as a row, so a directory could be "catalogued" by pictures of itself.
    if (cell[i - 1] === '!' && !escapedAt(cell, i - 1)) continue
    // The label ends at the first UNESCAPED "]": `[a\](x)` closes nowhere a reader can see.
    let close = -1
    for (let k = i + 1; k < cell.length; k++) if (cell[k] === ']' && !escapedAt(cell, k)) { close = k; break }
    if (close === -1 || cell[close + 1] !== '(') continue
    const { dest, closed } = readDest(cell, close + 2)
    return { dest, closed }
  }
  return null
}
// A link destination as a REPO PATH, twinned with the gate. The fragment and the query are
// addressing rather than filename, and each SEGMENT is percent-decoded on its own: `decodeURI`
// preserves the reserved set, so `one%23two.mjs` (a file genuinely named `one#two.mjs`, correctly
// written) came back encoded and was reported as a row pointing nowhere, and `one.mjs?raw=1`
// carried its query into the filename.
const destToPath = (dest) => dest.split('#')[0].split('?')[0].split('/').map((s) => decodeURIComponent(s)).join('/')

/*
 * How much one agent is asked to read. All three are ceilings and the first one to bind closes
 * the chunk. Twenty files because a row written from a file skimmed is the failure this whole
 * journey exists to prevent; four thousand lines because twenty files is meaningless as a budget
 * when one of them is a lint; and four hundred thousand bytes because a line count is not a
 * reading budget either. One minified bundle is a single line and more text than everything else
 * in the offer put together, and an offer that priced it as "1 line" would be wrong by four
 * orders of magnitude. A single file over either content ceiling becomes its own chunk and is
 * reported as oversize, so the offer says out loud that one agent has a large file to get
 * through rather than discovering it halfway.
 */
const MAX_FILES = 20
const MAX_LINES = 4000
const MAX_BYTES = 400_000
// Stated rather than left to be rediscovered: a line is a newline-separated segment, so a file
// ending in a newline counts a trailing empty one and `wc -l` reports one fewer. A run that
// re-counted the work with `wc` and got a different total from the offer it had already made is
// what put this line here.
const LINE_RULE = 'newline-separated segments; a file ending in a newline counts a trailing empty segment, so wc -l reports one fewer'

// A refusal is one short line on stderr and a hard stop. It exits synchronously ON PURPOSE:
// every call site reads `x || fail(...)`, so a fail that returned would carry on with the bad
// value. The truncation this file otherwise guards against needs more than 64 KiB of pending
// output to bite, and a refusal is one line.
const fail = (msg) => { console.error(`index-plan: ${msg}`); process.exit(2) }

// ── argv ──────────────────────────────────────────────────────────────────────────────────
const args = process.argv.slice(2)
let target = '.', onlyIndex = null, asJson = false, mode = 'reconcile', summary = false
let candidateDir = null, candidateFile = null, candidateExts = null, candidateScope = 'direct', wantChunk = null
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--target') target = args[++i] || fail('--target expects a directory')
  else if (args[i] === '--index') onlyIndex = args[++i] || fail('--index expects the path of a declared index')
  else if (args[i] === '--mode') {
    mode = args[++i] || fail('--mode expects gaps or reconcile')
    if (!['gaps', 'reconcile'].includes(mode)) fail(`--mode must be "gaps" (chunk only the files with no row) or "reconcile" (chunk every file, which is what re-reading an index costs); got "${mode}"`)
  } else if (args[i] === '--candidate') candidateDir = args[++i] || fail('--candidate expects a directory that keeps no index yet')
  else if (args[i] === '--index-file') candidateFile = args[++i] || fail('--index-file expects the path the prospective index would live at')
  else if (args[i] === '--extensions') {
    candidateExts = (args[++i] || fail('--extensions expects a comma-separated list, e.g. .mjs,.json')).split(',').map((e) => e.trim()).filter(Boolean)
    // The same rule the gate holds over a DECLARED extensions list. Without it, `--extensions mjs`
    // priced a prospective index whose declaration the gate exits 2 on, so the offer an operator
    // agreed to could not be written down.
    const bad = candidateExts.filter((e) => e !== '*' && !e.startsWith('.'))
    if (!candidateExts.length || bad.length) fail(`--extensions takes file extensions, each starting with a dot (e.g. .mjs,.json), or "*" for every kept file the directory holds; got ${bad.map((e) => JSON.stringify(e)).join(', ') || '(empty)'}. This becomes the declaration's "extensions", and the gate exits 2 on one written without the dot`)
  }
  else if (args[i] === '--scope') {
    candidateScope = args[++i] || fail('--scope expects direct or recursive')
    if (!INDEX_SCOPES.includes(candidateScope)) fail(`--scope must be one of ${INDEX_SCOPES.join(', ')}; got "${candidateScope}"`)
  } else if (args[i] === '--chunk') {
    wantChunk = Number(args[++i])
    if (!Number.isInteger(wantChunk) || wantChunk < 1) fail('--chunk expects a positive integer, and chunks are numbered from 1')
  } else if (args[i] === '--summary') summary = true
  else if (args[i] === '--json') asJson = true
  else fail(`unknown argument "${args[i]}"`)
}
if (candidateFile && !candidateDir) fail('--index-file only means something with --candidate, which says which directory the prospective index would catalogue')
if (candidateExts && !candidateDir) fail('--extensions only means something with --candidate; a declared index already states its own extensions in .repo-standard.json')
if (candidateDir && onlyIndex) fail('--candidate prices a directory that keeps no index yet and --index narrows to one that does; ask one question at a time')
target = resolve(target)
if (!existsSync(target) || !statSync(target).isDirectory()) fail(`target is not a directory: ${target}`)
// CANONICALISED, because how a repo is ADDRESSED must never change what is true about it. Reached
// through a symlinked path, `git rev-parse --show-toplevel` hands back the resolved worktree, the
// equality test below failed, and this engine silently fell back to the filesystem walk: the same
// tree then owed rows for every build directory git excludes, purely because of the path it was
// called with. The gate resolves both sides for the same reason.
try { target = realpathSync(target) } catch { /* not resolvable: the plain path is the best there is */ }

const read = (rel) => readFileSync(join(target, rel), 'utf8').replace(/^\ufeff/, '')
const exists = (rel) => existsSync(join(target, rel))
// Twinned with the gate, character for character. Keys beginning with "//" are operator comments
// and "$schema" is an editor hint; the gate ignores both and this engine ignored only the first,
// so a config carrying a nested "$schema" was exit 2 here and exit 0 there.
const isComment = (k) => k.startsWith('//') || k === '$schema'
const posix = (p) => p.split('\\').join('/')
const posixJoin = (dir, rel) => posix(join(dir, rel))
const underPath = (file, prefix) => file === prefix || file.startsWith(`${prefix}/`)
const dirOf = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '')
const extOf = (p) => { const d = p.lastIndexOf('.'), s = p.lastIndexOf('/'); return d > s ? p.slice(d) : '(none)' }
// Every command this engine prints is a command somebody pastes. A path with a space in it (or a
// quote, or a dollar sign) arrived unquoted and became two arguments, which for `git mv` means
// moving the wrong file. Single quotes, with the one escape a POSIX shell allows inside them.
const shellQuote = (s) => (/^[A-Za-z0-9._/-]+$/.test(s) ? s : `'${s.split("'").join("'\\''")}'`)
// ONE PATH CONTRACT, twinned with the gate. An index declared at "../outside/README.md" resolved
// to a sibling directory, was opened and read, and both engines reported it structurally
// complete: a green verdict earned by describing a tree neither of them governs. Absolute paths
// and backslashes are the same hole in a different spelling, and an empty component is a path a
// shell and a Set disagree about. A leading "./" is a spelling rather than an escape, and is left
// alone.
// A CONTROL CHARACTER is refused outright, twinned with the gate. No filename anyone typed carries
// a NUL, a newline or an escape; every one of them means something to a shell or a terminal; and a
// path carrying one travels through `git`, `execFileSync` and a printed diagnostic before anybody
// sees it.
const CONTROL_CHAR = /[\u0000-\u001f\u007f]/
const escapesRepo = (p) => p.startsWith('/') || /^[A-Za-z]:/.test(p) || p.includes('\\')
  || CONTROL_CHAR.test(p)
  || p.split('/').some((seg) => seg === '..' || seg === '')
// The SECOND leg, twinned with the gate. `escapesRepo` checks how a path is WRITTEN; this checks
// the object that actually gets opened. An in-repo index that is a symlink to a file in a sibling
// checkout satisfies every spelling rule, is read, and is reported structurally complete: a green
// verdict earned by cataloguing a tree neither engine governs. A directory in the chain can be
// the link just as easily as the leaf, so the whole resolved path is what gets compared.
const targetReal = (() => { try { return realpathSync(target) } catch { return target } })()
// Where a path REALLY lands. A dangling symlink throws out of realpath and still points
// somewhere, and where it points is the entire question, so the link is read by hand in that case
// rather than treated as absent.
const realOf = (abs) => {
  try { return realpathSync(abs) } catch { /* missing, or a link with no target */ }
  try { if (lstatSync(abs).isSymbolicLink()) return resolve(dirname(abs), readlinkSync(abs)) } catch { /* not on disk */ }
  return null
}
// Nothing on disk anywhere in the chain cannot leak content: absent, not escaped.
const escapesOnDisk = (p) => {
  const abs = join(target, p)
  const real = realOf(abs) ?? realOf(dirname(abs))
  if (real === null) return false
  return real !== targetReal && !real.startsWith(targetReal + sep)
}
/*
 * SPELLING FIRST, THEN NORMALISATION, and the order is the whole rule.
 *
 * Every call site used to tidy a path before handing it over: `posix()` on a decline directory,
 * a trailing-slash strip, a leading "./" removed. A normaliser that runs first REPAIRS the very
 * spelling this contract exists to refuse, and that is exactly how `docs.declined[].dir` written
 * as "ghost\dir" was turned into "ghost/dir" and accepted here while the gate refused it: one
 * engine planned a repo CI exits 2 on. So `rawPath` judges the bytes the operator wrote, and only
 * then returns the normalised value the rest of this engine uses.
 *   A TRAILING slash is a spelling rather than an escape, the same way a leading "./" is, so it
 * comes off before the empty-component rule sees it. A lone "/" keeps its leading slash and is
 * still refused as the filesystem root.
 */
const rawPath = (raw, where) => {
  const spelling = raw.length > 1 ? (raw.replace(/\/+$/, '') || raw) : raw
  if (escapesRepo(spelling)) fail(`"${where}" must be a repo-relative path that stays inside this repo (got ${JSON.stringify(raw)}): no leading "/", no "..", no backslashes, no empty path components, no control characters. A path that leaves the repo is planned against files this engine does not govern, and it reports complete by describing them`)
  // The canonical form, produced only AFTER the spelling has been judged, and it is the ONLY form
  // anything downstream sees. `posix()` is not applied: it would turn a backslash into a separator
  // and repair the very spelling the rule above refuses.
  const canon = spelling === '.' ? spelling : spelling.replace(/^\.\//, '')
  if (escapesOnDisk(canon)) fail(`"${where}" is spelled as a repo-relative path (${JSON.stringify(raw)}) and resolves OUTSIDE this repo: something in it is a symlink pointing away. The spelling rule cannot see this, and the file that gets opened is what the plan is built from`)
  return canon
}
// EVERY configured path now goes through `rawPath` and is used exactly as it comes back. This used
// to return the path as WRITTEN, so half the keys were canonicalised and half were not: `docs.
// changelog: "./CHANGELOG.md"` never compared equal to the `CHANGELOG.md` git lists, and the
// migration offer's released-history guard therefore never fired, queueing shipped history for a
// mechanical rewrite. The gate had the mirror-image split. One name, one behaviour.
const repoPath = rawPath
// A date that matches the SHAPE and names no day. `2026-99-99` satisfied every check in both
// engines, which makes the freshness signal a string that looks like one.
const isRealDate = (s) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false
  const d = new Date(`${s}T00:00:00Z`)
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s
}
// The row grammar the gate holds, twinned here character for character. The planner enforced none
// of it: a missing status word, a missing required row date and a missing reconciliation line
// were each exit 0 from this engine and a hard failure from the lint, which is the pairing that
// sends a fan-out at a repo CI has already decided against.
const INDEX_RECONCILED = /Reconciled against the code:\s*\**\s*(\d{4}-\d{2}-\d{2})/i
const reEscape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const undecorate = (c) => c.replace(/^[`*_\s]+/, '').replace(/[`*_\s]+$/, '')
const statusWordsFor = (ix) => (ix.statuses === null ? [] : [...ix.statuses, ...Object.keys(ix.aliases)])
const statusResFor = (ix) => statusWordsFor(ix).map((s) => new RegExp(`^${reEscape(s.trim())}([^A-Za-z0-9-]|$)`))

// ── the file universe ─────────────────────────────────────────────────────────────────────
// What owes a row is what the repo actually keeps, which is not the same as what is sitting on
// the disk. A build directory, a virtualenv, a vendored tree: none of them are files anyone
// should have to describe, and demanding rows for them is how an honest adopter concludes the
// check is unusable. Git already knows the difference, so ask it.
//   `git -C <dir>` walks UP to find a repo, so a plain directory nested inside an unrelated
// checkout would otherwise inherit that repo's file list. Only trust git when the discovered
// worktree IS the target, which is the same guard sense-state makes for the same reason.
//   When git cannot answer, the walk is the answer and NOTHING is excluded. That direction is
// deliberate: the fallback demands MORE rows, never fewer, so a missing git can make this engine
// noisier but it can never let a gap through. Which universe was used is reported on every run,
// because a coverage verdict that quietly changed its mind about what counts would be worse than
// either answer.
//   The listing is NUL-DELIMITED and read as BYTES. Without -z git C-quotes any path outside
// plain ASCII, so docs/café.md arrives as the literal characters "docs/caf\303\251.md", quotes
// included, and a newline inside a filename is indistinguishable from a record separator. Reading
// the result as a utf8 STRING was the second half of the same defect: a byte sequence that is not
// valid UTF-8 decodes to U+FFFD, which names no file on disk, so the path failed its lstat and
// left the universe with nothing said.
//
// FAIL CLOSED, twinned with the gate. TWO things a listing hands back that are not files to read:
// a GITLINK (mode 160000 in the index, standing in for another repository's whole content), and an
// UNTRACKED path that vanished between two calls.
//
// A STAGED DELETION needs no rule, and believing it did is what put a third one here. `git rm`
// takes the path out of the index, so it is already absent from `--cached` and never reaches this
// loop. What `git ls-files --deleted` actually reports is "tracked, and not in the worktree",
// which is the ORDINARY UNSTAGED DELETION too: a plain `rm` leaves the path in the index and off
// the disk. Subtracting that set excused exactly the case this fail-closed rule exists for. An
// uncatalogued tracked file was exit 1 from this engine and a red gate; `rm` on it, with nothing
// staged and nothing committed, made both of them green.
//
// So every cached, non-gitlink path lstat cannot find is NAMED and carries the exit code, whether
// it is missing because somebody deleted it without staging the removal or because a sparse or
// skip-worktree checkout is hiding it. Both are one fact about the set: git tracks a file, and
// this plan cannot see it.
const universeErrors = []
const gitRun = (args) => execFileSync('git', ['-C', target, ...args], { maxBuffer: 64 * 1024 * 1024, stdio: ['ignore', 'pipe', 'ignore'] })
// Records split on the NUL BYTE, never on a decoded string, so a name survives exactly as git
// wrote it. latin1 is the byte-preserving round trip used to COMPARE two listings; utf8 is used
// only where a real filename is needed.
const nulRecords = (buf) => {
  const out = []
  let start = 0
  for (let i = 0; i < buf.length; i++) if (buf[i] === 0) { if (i > start) out.push(buf.subarray(start, i)); start = i + 1 }
  if (start < buf.length) out.push(buf.subarray(start))
  return out
}
const decodeName = (rec) => {
  const s = rec.toString('utf8')
  return Buffer.from(s, 'utf8').equals(rec) ? s : null
}
const gitOwnsTarget = (() => {
  try { return gitRun(['rev-parse', '--show-toplevel']).toString('utf8').trim() === target } catch { return false }
})()
const gitKeeps = gitOwnsTarget ? (() => {
  try {
    const listed = nulRecords(gitRun(['ls-files', '-z', '--cached', '--others', '--exclude-standard']))
    // One call answers both "what is in the index" and "which of those are gitlinks". The record
    // is `<mode> <object> <stage>\t<path>`, and the tab is found by BYTE so a path git never
    // decoded cleanly still splits in the right place.
    const cached = new Set(), gitlinks = new Set()
    for (const rec of nulRecords(gitRun(['ls-files', '-z', '--stage']))) {
      const tab = rec.indexOf(0x09)
      if (tab < 0) continue
      const path = rec.subarray(tab + 1).toString('latin1')
      cached.add(path)
      if (rec.subarray(0, 7).toString('latin1') === '160000 ') gitlinks.add(path)
    }
    const kept = []
    for (const rec of listed) {
      const raw = rec.toString('latin1')
      if (gitlinks.has(raw)) continue
      const name = decodeName(rec)
      if (name === null) {
        universeErrors.push({ path: rec.toString('utf8'), why: 'git tracks this path and its name is not valid UTF-8. No markdown link can name it, so no row can catalogue it and no coverage rule can be held over it. Rename the file' })
        continue
      }
      let st = null
      try { st = lstatSync(join(target, name)) } catch { /* absent: judged immediately below */ }
      // WHAT THE PATH IS NOW, against what git says it is, twinned with the gate. The listing used
      // to be filtered by one question, "does lstat call this a directory", and a yes was silently
      // dropped: a TRACKED, uncatalogued blob replaced by a DIRECTORY at the same path went from a
      // red plan to a green one, because the file the index still carries stopped being a file on
      // disk. An UNTRACKED directory is the ordinary case the rule was written for (`ls-files
      // --others` reports a nested repository as `dir/`), and it is the only one still skipped.
      if (st !== null && st.isDirectory()) {
        if (!cached.has(raw)) continue
        universeErrors.push({ path: name, why: 'git has this path in the index as a FILE (it is not a submodule), and a directory is sitting at it on disk. The blob git tracks cannot be read, catalogued, or held to any coverage rule while a directory occupies its name: stage what actually happened here, or restore the file' })
        continue
      }
      if (st === null) {
        if (!cached.has(raw)) continue
        universeErrors.push({ path: name, why: 'git tracks this path, it is not a submodule, and it is not on disk. Either it was deleted without the removal being staged (git rm records it, and the path then leaves the index and this plan with it), or a sparse or skip-worktree checkout is hiding it. Until one of those is true it is still tracked and still owes a row, and dropping it here is how a file goes from a red plan to a green one by being deleted' })
        continue
      }
      kept.push(name)
    }
    return new Set(kept)
  } catch { return null }
})() : null

// SYMLINKS are kept files and owe a row. git tracks one, a reader browsing the directory sees
// one, and a walk built on Dirent.isFile() yields neither a file nor a directory for it, so it
// dropped out of the plan with nothing said. It is never followed: reading through a link would
// describe its target twice, and a link to a directory would walk forever.
const walkFiles = (rel = '') => {
  const abs = rel ? join(target, rel) : target
  let entries
  try { entries = readdirSync(abs, { withFileTypes: true }) } catch { return [] }
  return entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0)).flatMap((e) => {
    const child = rel ? `${rel}/${e.name}` : e.name
    if (e.isDirectory()) return WALK_SKIP_DIRS.has(e.name) ? [] : walkFiles(child)
    return e.isFile() || e.isSymbolicLink() ? [child] : []
  })
}
const allFiles = gitKeeps ? [...gitKeeps].sort() : walkFiles()
const universe = gitKeeps
  ? { kind: 'git', why: 'tracked files plus pending ones git does not ignore, so a build directory or a vendored tree owes no row' }
  : { kind: 'filesystem', why: gitOwnsTarget ? 'git is present but could not list files, so nothing is excluded and every file on disk owes a row' : 'not a git worktree, so nothing can be excluded and every file on disk owes a row' }

const walkDirs = (rel = '') => {
  const abs = rel ? join(target, rel) : target
  let entries
  try { entries = readdirSync(abs, { withFileTypes: true }) } catch { return [] }
  return entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0)).flatMap((e) => {
    if (!e.isDirectory() || WALK_SKIP_DIRS.has(e.name) || e.name.startsWith('.')) return []
    const child = rel ? `${rel}/${e.name}` : e.name
    return [child, ...walkDirs(child)]
  })
}

// A file an agent cannot read in full has to be NAMED, never given a confident row. Same NUL-byte
// heuristic git uses. Lines and bytes are both what the chunker spends.
const measured = new Map()
const measure = (rel) => {
  if (measured.has(rel)) return measured.get(rel)
  let m
  let buf
  // A symlink is named rather than read. Following one would spend an agent's budget describing a
  // file that already has its own row, and a link pointing at a directory has no contents to read
  // at all. The row an agent writes for it says what it points at, which is the whole fact.
  try {
    const st = lstatSync(join(target, rel))
    if (st.isSymbolicLink()) {
      let to = null
      try { to = posix(readlinkSync(join(target, rel))) } catch { to = null }
      m = { lines: 0, bytes: st.size, readable: false, why: to ? `symlink -> ${to}` : 'symlink' }
    }
  } catch { /* fall through to the read, which reports its own errno */ }
  if (!m) try { buf = readFileSync(join(target, rel)) } catch (e) { m = { lines: 0, bytes: 0, readable: false, why: e.code || 'unreadable' } }
  if (!m) {
    if (buf.subarray(0, 8192).includes(0)) m = { lines: 0, bytes: buf.length, readable: false, why: 'binary' }
    else { const text = buf.toString('utf8'); m = { lines: text === '' ? 0 : text.split('\n').length, bytes: buf.length, readable: true, why: null } }
  }
  measured.set(rel, m)
  return m
}

// ── the declared scope ────────────────────────────────────────────────────────────────────
if (!exists('.repo-standard.json')) fail('this repo is not governed yet: no .repo-standard.json, so nothing declares which directories keep an index. Run the scaffold skill first')
let config
try { config = JSON.parse(read('.repo-standard.json')) } catch (e) { fail(`.repo-standard.json is not valid JSON: ${e.message}`) }
if (typeof config !== 'object' || Array.isArray(config) || config === null) fail('.repo-standard.json must be a JSON object')

/*
 * THE ATLAS SURFACE OF THE CONFIG, refused here exactly as the gate refuses it.
 *
 * The scope of this parity claim is deliberately NARROW and stated rather than implied: every
 * key an atlas run reads — the whole `docs` block, `manifest.file` (which decides whether an
 * index counts as governed prose), the format version, and the top-level key names. A broken
 * `counts` or `voice` block is a config error this engine does NOT adjudicate; the gate reports
 * it, and the atlas skill runs the gate first for that reason.
 *
 * Everything below was found by running both engines over the same mutated config rather than by
 * reading either of them, and each line closed an exit-code pair in which the expensive half ran
 * and the cheap half was the one that said no.
 */
const KNOWN_TOP = ['version', 'docs', 'manifest', 'versionManifest', 'readme', 'conventions', 'voice', 'prose', 'counts', 'stableDocs', 'checks', 'scaffold', 'assets', 'ignore', 'github']
for (const k of Object.keys(config)) {
  if (!isComment(k) && !KNOWN_TOP.includes(k)) fail(`unknown top-level key "${k}" (known: ${KNOWN_TOP.join(', ')}); the gate exits 2 on this, so a plan built from it could never go green`)
}
if (config.version !== 1) fail(`"version" must be the number 1 (got ${JSON.stringify(config.version)}): a present config declares its format version, and the gate exits 2 when it does not`)
// A plain object, never an array. `docs: []` reads as an object to typeof, so every key came back
// undefined, the whole block was silently treated as absent, and this engine planned a repo the
// gate exits 2 on.
const DOCS_KEYS = ['readme', 'changelog', 'conventions', 'extra', 'index', 'indexes', 'declined', 'ownership']
if (config.docs !== undefined && config.docs !== null && (typeof config.docs !== 'object' || Array.isArray(config.docs))) fail('"docs" must be an object')
const docsCfg = config.docs && typeof config.docs === 'object' && !Array.isArray(config.docs) ? config.docs : {}
for (const k of Object.keys(docsCfg)) {
  if (!isComment(k) && !DOCS_KEYS.includes(k)) fail(`unknown key "docs.${k}" (known: ${DOCS_KEYS.join(', ')})`)
}
for (const k of ['changelog', 'conventions']) {
  if (docsCfg[k] !== undefined && typeof docsCfg[k] !== 'string') fail(`"docs.${k}" must be a string path, got ${JSON.stringify(docsCfg[k])}`)
}
// Every governed-doc path through the ONE contract, and REPLACED by what it returns. Keeping the
// raw spelling is how `docs.changelog: "./CHANGELOG.md"` stopped matching the `CHANGELOG.md` git
// lists, which silently disabled the migration offer's released-history guard.
/*
 * AN EFFECTIVE DEFAULT IS A CONFIGURED PATH, and it went through no contract at all.
 *
 * A key left undeclared is a value the config CHOSE by staying silent, and this engine opens it
 * exactly as it opens a written one. A root README.md that is a SYMLINK into a sibling checkout
 * was read here and refused by the gate: the cheap engine planned a fan-out over prose the
 * expensive one will not govern, on a repo where nothing in the config was wrong. The physical
 * containment leg is the whole reason this matters, because a default cannot be misspelled and it
 * can still be substituted.
 */
const DOC_DEFAULTS = { readme: 'README.md', changelog: 'CHANGELOG.md', conventions: 'CONVENTIONS.md' }
const docPath = {}
for (const k of ['readme', 'changelog', 'conventions']) {
  const v = docsCfg[k]
  docPath[k] = typeof v === 'string'
    ? repoPath(v, `docs.${k}`)
    : repoPath(DOC_DEFAULTS[k], `docs.${k} (the default, in force because the key is not declared)`)
}
// The front page has to be one GitHub actually renders, or the gate refuses before it reads a
// single row. Asked of the CANONICAL spelling, so "./README.md" is the front page it obviously is.
const readmePath = docPath.readme
if (!['README.md', 'docs/README.md', '.github/README.md'].includes(readmePath)) {
  fail(`"docs.readme" must be one of README.md, docs/README.md, .github/README.md (the paths GitHub renders), got ${JSON.stringify(docsCfg.readme)}`)
}
// Element types, never a silent filter. A `docs.extra` of [1, "lib/README.md"] was quietly
// reduced to the one string here and exits 2 there, so this engine planned a fan-out at a repo
// CI had already refused.
const extraDocs = []
if (docsCfg.extra !== undefined) {
  if (!Array.isArray(docsCfg.extra) || docsCfg.extra.some((s) => typeof s !== 'string')) fail('"docs.extra" must be an array of strings')
  extraDocs.push(...docsCfg.extra.map((p, i) => repoPath(p, `docs.extra[${i}]`)))
}
// `manifest.file` decides whether a declared index counts as governed prose, so its shape is
// part of this surface. A `manifest: 7` was ignored here and exits 2 there.
// `null` reads as ABSENT here because it reads as absent at the gate, which resolves the block
// with `?? false`. Refusing it was this engine inventing a rule the gate does not have: a config
// carrying `"manifest": null` was exit 2 here and exit 0 there, which is the pairing that stops a
// fan-out at a repo CI is perfectly happy with. Twinning a rule means twinning what it ACCEPTS.
let manifestFile = null
if (config.manifest !== undefined && config.manifest !== false && config.manifest !== null) {
  const m = config.manifest
  if (typeof m !== 'object' || Array.isArray(m)) fail('"manifest" must be false or an object { file, statuses }')
  for (const k of Object.keys(m)) if (!isComment(k) && !['file', 'statuses'].includes(k)) fail(`unknown key "manifest.${k}"`)
  if (typeof m.file !== 'string') fail('"manifest.file" must be a string path')
  manifestFile = repoPath(m.file, 'manifest.file')
  if (!Array.isArray(m.statuses) || m.statuses.length === 0 || m.statuses.some((s) => typeof s !== 'string')) fail('"manifest.statuses" must be a non-empty array of strings')
}
if (docsCfg.index !== undefined && docsCfg.indexes !== undefined) {
  fail('.repo-standard.json declares both "docs.index" and "docs.indexes"; the lint rejects the pair, so this plan would not match what CI holds')
}
const rawIndexes = docsCfg.indexes !== undefined
  ? (Array.isArray(docsCfg.indexes) ? docsCfg.indexes : fail('"docs.indexes" must be an array of index declarations'))
  : (docsCfg.index === undefined || docsCfg.index === false ? [] : [docsCfg.index])

// Every index-related rule the lint enforces, enforced HERE too and in the same words. A planner
// that happily plans a config CI rejects sends a fan-out at a repo that cannot go green: three of
// these were exit 0 from the planner and a hard refusal from the gate, which is the worst possible
// pairing, because the expensive half runs and the cheap half is what says no.
// Returned UNTRIMMED, because the gate does not trim either. A padded " .mjs " was silently
// repaired here and refused there, so this engine planned a fan-out over a config CI exits 2 on.
// Twinning a rule means twinning what it accepts, not only what it rejects.
const strArray = (v, at) => {
  if (v === undefined) return []
  if (!Array.isArray(v) || v.some((s) => typeof s !== 'string')) fail(`"${at}" must be an array of strings`)
  return v
}
// How much of the repo the index rules may stay silent about. Twinned with the gate: `declared`
// checks what a declaration reaches, `strict` requires every kept file under a declared root to
// be owned, ignored, or declined, and carries the answer in the EXIT CODE.
const OWNERSHIP_MODES = ['declared', 'strict']
const declared = []
for (const [i, raw] of rawIndexes.entries()) {
  const at = docsCfg.indexes !== undefined ? `docs.indexes[${i}]` : 'docs.index'
  if (typeof raw !== 'object' || Array.isArray(raw) || raw === null) fail(`"${at}" must be an object { ${INDEX_KEYS.join(', ')} }`)
  for (const k of Object.keys(raw)) if (!isComment(k) && !INDEX_KEYS.includes(k)) fail(`unknown key "${at}.${k}" (known: ${INDEX_KEYS.join(', ')})`)
  if (typeof raw.file !== 'string' || !raw.file.trim() || !raw.file.includes('/')) {
    fail(`"${at}.file" must be a path to the index document, inside the directory it catalogues`)
  }
  if (raw.scope !== undefined && !INDEX_SCOPES.includes(raw.scope)) fail(`"${at}.scope" must be one of ${INDEX_SCOPES.join(', ')}`)
  // THE RAW BYTES, never a trimmed copy, twinned with the gate. `.trim()` ran BEFORE the contract,
  // so a declaration written "\ndocs/README.md" had its control character removed here and was
  // accepted, while the gate judged the same key untrimmed and exited 2. A normaliser that runs
  // first repairs the very spelling the contract exists to refuse, which is the rule `rawPath`
  // states in its own comment and this call site was breaking.
  const file = repoPath(raw.file, `${at}.file`)
  const exts = raw.extensions === undefined ? ['.md'] : strArray(raw.extensions, `${at}.extensions`)
  if (raw.extensions !== undefined && (exts.length === 0 || exts.some((e) => e !== '*' && !e.startsWith('.')))) {
    fail(`"${at}.extensions" must be a non-empty array of file extensions, each starting with a dot (e.g. [".mjs"]), or ["*"] for every kept file the directory holds`)
  }
  const aliases = {}
  if (raw.aliases !== undefined) {
    if (typeof raw.aliases !== 'object' || Array.isArray(raw.aliases) || raw.aliases === null) fail(`"${at}.aliases" must be an object mapping this repo's status words onto the canon (${INDEX_STATUSES.join(', ')})`)
    for (const [w, c] of Object.entries(raw.aliases)) {
      if (isComment(w)) continue
      if (!INDEX_STATUSES.includes(String(c))) fail(`"${at}.aliases" maps "${w}" to "${c}", which is not one of the canon statuses (${INDEX_STATUSES.join(', ')})`)
      aliases[w.trim()] = String(c)
    }
  }
  let statuses = null
  if (raw.statuses !== undefined && raw.statuses !== false) {
    const list = raw.statuses === true ? INDEX_STATUSES : strArray(raw.statuses, `${at}.statuses`)
    if (raw.statuses !== true && !list.length) fail(`"${at}.statuses" must be true (the whole canon) or a non-empty array drawn from it`)
    const foreign = list.filter((s) => !INDEX_STATUSES.includes(s.toLowerCase()) && !Object.prototype.hasOwnProperty.call(aliases, s))
    if (foreign.length) fail(`"${at}.statuses" lists ${foreign.map((f) => JSON.stringify(f)).join(', ')}, which the canon does not contain (${INDEX_STATUSES.join(', ')}). A genuinely different word keeps its place on the page through "aliases"`)
    statuses = list
  }
  for (const k of ['ordered', 'requireDate', 'reconciled']) {
    if (raw[k] !== undefined && typeof raw[k] !== 'boolean') fail(`"${at}.${k}" must be a boolean`)
  }
  if (raw.retain !== undefined && (typeof raw.retain !== 'string' || !raw.retain.trim())) {
    fail(`"${at}.retain" must be the reason this index stays where it is rather than moving to the README a reader lands on`)
  }
  if (raw.grammar !== undefined && !INDEX_GRAMMARS.includes(raw.grammar)) {
    fail(`"${at}.grammar" must be one of ${INDEX_GRAMMARS.join(', ')} (default 1). Version 2 reads the table's HEADER: a catalog row is a body row of a table whose header names a file column, the status is read from the status column, and the date from the column that says when the file was last checked`)
  }
  declared.push({
    at,
    grammar: raw.grammar === 2 ? 2 : 1,
    file,
    dir: dirOf(file),
    // `recursive` is the default because it is what every already-adopted config means, and a
    // default that reddened every existing adopter on upgrade would be a migration disguised as
    // a fix. `direct` is what the atlas skill DECLARES on every new index: one README per
    // directory, owning the files directly in it, with a declared child index bounding it over
    // the files that child claims. Both are named in every plan so neither is ever inferred.
    scope: raw.scope === 'direct' ? 'direct' : 'recursive',
    extensions: exts,
    statuses,
    aliases,
    ordered: raw.ordered === true,
    requireDate: raw.requireDate === true,
    reconciled: raw.reconciled === true,
    ignore: strArray(raw.ignore, `${at}.ignore`).map((p, j) => rawPath(p, `${at}.ignore[${j}]`)),
    // The recorded answer to the migration question. Without somewhere to write "leave it where
    // it is", a deliberate decision came back as an unanswered offer on every run forever.
    retain: typeof raw.retain === 'string' && raw.retain.trim() ? raw.retain.trim() : null,
    prospective: false,
  })
}
// Two catalogs of ONE directory means neither is authoritative and the coverage rule would demand
// every file appear in both. The gate refuses the pair; so must this.
const seenDirs = new Map()
for (const ix of declared) {
  const prior = seenDirs.get(ix.dir)
  if (prior) fail(`"${ix.at}" and "${prior.at}" both declare an index for ${ix.dir}/ (${ix.file} and ${prior.file}). Two catalogs of one directory means neither is authoritative; the lint refuses this pair, so a plan built on it could not go green`)
  seenDirs.set(ix.dir, ix)
}
// An index no prose sweep reaches is the one page in its directory that can rot with nothing here
// noticing, which is why the gate requires every declared index to be a governed doc. That set is
// the meta docs plus docs.extra, and it is spelled out the same way here: an index that happens to
// BE the front page or the conventions doc is already swept, and refusing it would be this engine
// inventing a rule the gate does not have.
// Built from the CANONICAL paths, so an index declared "./lib/README.md" and listed in docs.extra
// as "lib/README.md" is one page rather than two that never compare equal.
const governedDocs = new Set([
  readmePath,
  docPath.changelog,
  docPath.conventions,
  ...(manifestFile ? [manifestFile] : []),
  ...extraDocs,
])
for (const ix of declared) {
  if (!governedDocs.has(ix.file)) {
    fail(`"${ix.at}.file" is ${ix.file}, which no prose sweep governs. Add it to "docs.extra": the lint fails an index nobody sweeps, so this plan would not match what CI holds`)
  }
}
// The COMPLETE declaration list, captured before any narrowing touches it. `--index` used to
// delete the sibling declarations and only then work out what the surviving index owned, so a
// narrowed plan claimed files a child index owns and disagreed with both the full plan and the
// gate. Narrowing is a question about what gets REPORTED; it was never a question about scope.
const allDeclared = [...declared]

// Directories the operator has already turned down, one entry each, with the reason on the page
// rather than in someone's memory. A global "never ask about the atlas again" would suppress the
// candidates that matter along with the leaf nobody wants catalogued, which is why this exists
// at directory granularity at all.
//   Validated exactly as the gate validates it. Silently dropping the entries that did not fit
// the shape meant a `declined` list of bare strings, or an entry with no `why`, planned here as
// though it were empty and exited 2 there.
const declined = []
if (docsCfg.declined !== undefined) {
  if (!Array.isArray(docsCfg.declined)) fail('"docs.declined" must be an array of { dir, why } objects naming the directories that were offered an index and turned it down')
  for (const [i, d] of docsCfg.declined.entries()) {
    if (typeof d !== 'object' || d === null || Array.isArray(d)) fail(`"docs.declined[${i}]" must be an object { dir, why }`)
    for (const k of Object.keys(d)) if (!isComment(k) && !['dir', 'why'].includes(k)) fail(`unknown key "docs.declined[${i}].${k}" (known: dir, why)`)
    if (typeof d.dir !== 'string' || !d.dir.trim()) fail(`"docs.declined[${i}].dir" must be the directory that was offered an index`)
    // Raw bytes, for the reason `${at}.file` takes them raw: trimming first accepted a decline
    // spelled "\nghost" that the gate refuses.
    const dir = rawPath(d.dir, `docs.declined[${i}].dir`)
    // A decline answers for a DIRECTORY. Handed a file path it quietly excused exactly one file
    // from every ownership rule, which is an `ignore` entry wearing a decline's clothes.
    //   lstat, never stat. A SYMLINK to a directory answers isDirectory() through stat, so a
    // decline naming one was accepted and silently excused the symlink itself, which git keeps as
    // one file that owes a row: the same substitution in a different spelling.
    if (existsSync(join(target, dir))) {
      const st = lstatSync(join(target, dir))
      if (st.isSymbolicLink()) fail(`"docs.declined[${i}].dir" is ${JSON.stringify(dir)}, which is a symlink rather than a directory. git keeps a symlink as one FILE, so declining it excuses that file from every ownership rule while reading as a decision about a whole tree; list it under an index's "ignore" if that is what you meant`)
      if (!st.isDirectory()) fail(`"docs.declined[${i}].dir" is ${JSON.stringify(dir)}, which is a file rather than a directory. A decline records a directory that was offered an index and turned it down; to excuse one file from an index's coverage, list it under that index's "ignore"`)
    }
    if (typeof d.why !== 'string' || !d.why.trim()) fail(`"docs.declined[${i}].why" must say why ${dir} keeps no index. A recorded no with no reason is indistinguishable from an oversight, and the next person to read this config is the one who has to tell them apart`)
    declined.push({ dir, why: d.why, stale: !existsSync(join(target, dir)) })
  }
}
for (const d of declined) {
  if (seenDirs.has(d.dir)) fail(`"docs.declined" lists ${d.dir}, which also declares an index. A directory cannot both keep a catalog and have refused one`)
}
// Twinned with the gate, and the one mode under which the count of undecided files below reaches
// the exit code at all.
let ownershipMode = 'declared'
if (docsCfg.ownership !== undefined) {
  if (!OWNERSHIP_MODES.includes(docsCfg.ownership)) fail(`"docs.ownership" must be one of ${OWNERSHIP_MODES.join(', ')} (default "declared"): "strict" requires every kept file under a declared index to be owned, ignored, or declined, and fails the build on the ones that are not`)
  ownershipMode = docsCfg.ownership
}
const declinedDirs = new Set(declined.map((d) => d.dir))

if (onlyIndex !== null) {
  const want = posix(onlyIndex).replace(/^\.\//, '')
  const hit = declared.find((ix) => ix.file === want)
  if (!hit) {
    fail(`--index "${onlyIndex}" is not declared in .repo-standard.json. Declared: ${declared.length ? declared.map((ix) => ix.file).join(', ') : '(none)'}`)
  }
  declared.length = 0
  declared.push(hit)
}

// ── a prospective index, priced exactly ───────────────────────────────────────────────────
// The offer an atlas run makes about a candidate directory is a number the operator agrees to,
// and until this existed the only way to get that number was to re-implement the planner in
// shell. A candidate listing gives a histogram; this gives the actual plan: the paths, the
// lines, the bytes, the unreadables, the oversized files, and the agents.
if (candidateDir !== null) {
  // Through the ONE path contract, the same as every configured path. `--candidate ../sibling`
  // was accepted, stat'd, read and priced: an offer built from a directory in another checkout,
  // which is the config hole in its command-line spelling.
  const dir = rawPath(candidateDir, '--candidate')
  if (!dir) fail('--candidate expects a directory inside the repo, not the repo root: an index catalogues the directory it lives in')
  if (!existsSync(join(target, dir)) || !lstatSync(join(target, dir)).isDirectory()) fail(`--candidate "${candidateDir}" is not a directory inside ${target} (a symlink is a file git keeps one entry for, not a directory to catalogue)`)
  const alreadyDeclared = declared.find((ix) => ix.dir === dir)
  if (alreadyDeclared) fail(`"${dir}" already keeps a declared index (${alreadyDeclared.file}); use --index ${alreadyDeclared.file} to plan it`)
  // The README is the default home whether or not one exists yet. A candidate is a directory
  // holding kept files nobody owns, which says nothing about which pages it keeps: one that has a
  // README GAINS a table, prose intact, rather than growing a second catalog beside it, and one
  // that has none gets its front page written. Which of the two this is changes the offer, so
  // `confirm` below states it rather than leaving it to be inferred from the path. The case that
  // breaks is a README which is itself one of the artifacts the directory ships
  // (payload/templates/README.md IS a template), and no engine can tell that from the outside, so
  // the operator redirects with --index-file.
  const file = candidateFile
    ? rawPath(candidateFile, '--index-file')
    : `${dir}/README.md`
  if (dirOf(file) !== dir) fail(`--index-file "${file}" does not live in "${dir}", and an index catalogues the directory it lives in`)
  const inDir = allFiles.filter((f) => (candidateScope === 'direct' ? dirOf(f) === dir : underPath(f, dir)) && f !== file)
  const exts = candidateExts ?? [...new Set(inDir.filter((f) => measure(f).readable).map(extOf))].filter((e) => e !== '(none)').sort()
  if (!exts.length) fail(`nothing under "${dir}" carries a readable extension to index; name one with --extensions, or leave the directory alone`)
  declared.length = 0
  declared.push({
    at: '(prospective, not declared)',
    // A page an atlas run is about to WRITE has no legacy to protect, so it is priced under the
    // grammar the run would write it in.
    grammar: 2,
    file,
    dir,
    scope: candidateScope,
    extensions: exts,
    statuses: null,
    aliases: {},
    ordered: true,
    requireDate: false,
    reconciled: true,
    ignore: [],
    prospective: true,
    // What the engine cannot decide, stated rather than assumed either way.
    confirm: exists(file) && !candidateFile
      ? `${file} already exists. Adopting this directory means that page GAINS a table, with its prose left alone. If it is itself one of the artifacts ${dir}/ ships rather than the directory's front page, re-run with --index-file ${dir}/INDEX.md`
      : null,
  })
}

// ── what each index already says, and what it is missing ──────────────────────────────────
// The row parse is the lint's, character for character in behaviour: a table row is a catalog
// entry when it links a file, whichever column the link sits in. External links and in-page
// anchors are prose, not entries.
//   Cells are split on unescaped pipes only. A `\|` inside a description is the markdown way to
// write a literal pipe, and splitting on it tore one cell into two, which moved the status out
// of the column the check reads and made a correct row look like a broken one.
const splitCells = (line) => {
  let t = line.trim()
  if (t.startsWith('|')) t = t.slice(1)
  if (t.endsWith('|') && !t.endsWith('\\|')) t = t.slice(0, -1)
  const out = []
  let cur = ''
  for (let i = 0; i < t.length; i++) {
    if (t[i] === '\\' && i + 1 < t.length) { cur += t[i] + t[i + 1]; i++; continue }
    if (t[i] === '|') { out.push(cur.trim()); cur = ''; continue }
    cur += t[i]
  }
  out.push(cur.trim())
  return out
}
// The TABLE GRAMMAR, twinned with the gate in both of its declared versions. Version 1 is what
// shipped: any pipe line, any cell answering for anything. Version 2 reads the header, so a
// catalog row is a body row of a table whose header names a file column, and the status and date
// checks are bound to the columns their headers name. FENCES are stripped under both, because a
// table inside a code fence is an example of a table and counting its rows as coverage let a page
// document the grammar and be credited with obeying it.
const FILE_COL = /^(file|document|doc|path|name|page|entry)\b/i
const STATUS_COL = /^(status|state|lifecycle)\b/i
const DATE_COL = /\b(verified|reconciled|checked|reviewed|confirmed)\b/i
// Blanked rather than deleted, so a reported line number is the line the operator opens.
//   A CLOSING fence carries no info string (CommonMark 4.5: "the closing code fence ... may not
// have an info string"). Accepting one meant a page could reopen itself from inside its own
// example: a line reading ```` ```notclose ```` ended the fence here and not on GitHub, so every
// row after it counted as coverage while a reader saw one code block.
/*
 * AT MOST THREE SPACES, on the opening fence and on the closing one (CommonMark 4.5). `^\s*`
 * accepted a fence at any indentation, and four spaces inside an open fence is CONTENT: a page
 * could write an indented ``` that ended the block here and did not end it on GitHub, so the
 * fenced example beneath it stopped being blanked and every row in it counted as coverage.
 */
const FENCE_LINE_RE = /^ {0,3}(```+|~~~+)[ \t]*(.*)$/
/*
 * CommonMark 4.6 type 1: these four tags open a RAW HTML block whose content markdown never parses
 * and which ends at the matching close tag, or at the end of the file. A complete, column-correct
 * glossary inside <pre> was credited by both engines as full coverage and rendered as literal text.
 */
const HTML_RAW_OPEN = /^ {0,3}<(pre|script|style|textarea)(?=[\s/>]|$)/i
/*
 * CommonMark 4.6 type 6, verbatim from the specification so the set is one somebody can check
 * against it rather than a list that grew by anecdote: a block-level tag opens a block of raw HTML
 * that ends at the next BLANK line. A table inside one is markup, not a table.
 */
const HTML_BLOCK_TAGS = new Set(['address', 'article', 'aside', 'base', 'basefont', 'blockquote', 'body', 'caption', 'center', 'col', 'colgroup', 'dd', 'details', 'dialog', 'dir', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'frame', 'frameset', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'head', 'header', 'hr', 'html', 'iframe', 'legend', 'li', 'link', 'main', 'menu', 'menuitem', 'nav', 'noframes', 'ol', 'optgroup', 'option', 'p', 'param', 'search', 'section', 'summary', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'title', 'tr', 'track', 'ul'])
const HTML_BLOCK_OPEN = /^ {0,3}<\/?([a-zA-Z][a-zA-Z0-9-]*)(?=[\s/>]|$)/
// The leaf blocks that CLOSE an open paragraph, which is the whole question an indented line
// depends on. Without them a four-space glossary sitting straight under a heading was read as a
// table and credited as coverage no reader can see.
const ATX_HEADING = /^ {0,3}#{1,6}(?:[ \t]|$)/
const THEMATIC_BREAK = /^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$/
const SETEXT_UNDERLINE = /^ {0,3}(?:=+|-+)[ \t]*$/
const blankRange = (s, a, b) => s.slice(0, a) + s.slice(a, b).replace(/[^\n]/g, ' ') + s.slice(b)
/*
 * HTML COMMENTS as ranges, INCLUDING the one nobody closed. `/<!--[\s\S]*?-->/` matched nothing at
 * all when the closing marker was missing, so a page could comment its real table out with one
 * typo, render as a comment that swallows the rest of the document on GitHub, and be reported
 * structurally complete here.
 */
const commentRanges = (text) => {
  const out = []
  for (let i = 0; ;) {
    const a = text.indexOf('<!--', i)
    if (a === -1) return out
    const b = text.indexOf('-->', a + 4)
    if (b === -1) { out.push([a, text.length]); return out }
    out.push([a, b + 3])
    i = b + 3
  }
}
/*
 * EVERYTHING MARKDOWN DOES NOT RENDER AS CONTENT, blanked POSITIONALLY and to the SAME LENGTH as
 * the source, so a reported line number is the line the operator opens and an offset is the offset
 * in the file. Twinned with the gate, character for character.
 *
 * The equal length is load-bearing rather than tidy. It is what lets the migration scan below ask
 * "is this byte inside something a reader can see" by comparing the blanked text to the source,
 * instead of keeping a second copy of these rules that drifts from this one. The two used to be
 * separate implementations of overlapping ideas, and the migration copy knew about exactly two of
 * the six contexts.
 *
 * Six contexts, each of which held a complete, column-correct glossary that both engines credited
 * as full coverage and no reader could see: a FENCED block (a table as an example of a table), a
 * fenced block closed by an INDENTED pseudo-fence (which does not close it on GitHub), an HTML
 * COMMENT (rendered as nothing at all, closed or not), a RAW HTML block (<pre> and friends), an
 * HTML BLOCK (<div>, <details>) up to the next blank line, and an INDENTED CODE BLOCK, including
 * one sitting directly under a heading.
 *
 * ORDER IS THE RULE. Fences come first because a fence's content is literal: a comment marker or an
 * HTML tag inside one is text, and blanking those first would let an example of a comment swallow a
 * real table below it.
 */
const blankNonRendering = (text) => {
  let fence = null
  const unfenced = text.split('\n').map((line) => {
    const m = line.match(FENCE_LINE_RE)
    // An unclosed fence runs to the end of the file, which is what GitHub renders.
    if (fence) { if (m && m[1][0] === fence[0] && m[1].length >= fence.length && m[2].trim() === '') fence = null; return ' '.repeat(line.length) }
    if (m) { fence = m[1]; return ' '.repeat(line.length) }
    return line
  }).join('\n')
  let masked = unfenced
  for (const [a, b] of commentRanges(unfenced)) masked = blankRange(masked, a, b)
  let raw = null, htmlBlock = false, paragraphOpen = false, inIndented = false
  return masked.split('\n').map((line) => {
    const blank = ' '.repeat(line.length)
    if (raw !== null) {
      if (new RegExp(`</${raw}(?:\\s*)>`, 'i').test(line)) raw = null
      paragraphOpen = false
      return blank
    }
    // A blank line closes every open paragraph and every open HTML block. A line an earlier pass
    // already blanked arrives here as spaces and is treated the same way, which is correct: after a
    // fenced block ends, no paragraph is open, so the next indented line IS code.
    if (line.trim() === '') { paragraphOpen = false; inIndented = false; htmlBlock = false; return line }
    if (htmlBlock) { paragraphOpen = false; return blank }
    const rawOpen = line.match(HTML_RAW_OPEN)
    if (rawOpen) {
      raw = rawOpen[1].toLowerCase()
      if (new RegExp(`</${raw}(?:\\s*)>`, 'i').test(line.slice(rawOpen[0].length))) raw = null
      paragraphOpen = false
      return blank
    }
    // CommonMark 4.4: an indented code block cannot interrupt a paragraph, so four spaces (or a
    // tab) is code only where no paragraph is open. A table indented one to three spaces still
    // renders, and is left alone.
    if (/^(?: {4}|\t)/.test(line) && (!paragraphOpen || inIndented)) { inIndented = true; return blank }
    inIndented = false
    const blockOpen = line.match(HTML_BLOCK_OPEN)
    if (blockOpen && HTML_BLOCK_TAGS.has(blockOpen[1].toLowerCase())) { htmlBlock = true; paragraphOpen = false; return blank }
    if (ATX_HEADING.test(line) || THEMATIC_BREAK.test(line)) { paragraphOpen = false; return line }
    if (paragraphOpen && SETEXT_UNDERLINE.test(line)) { paragraphOpen = false; return line }
    paragraphOpen = true
    return line
  }).join('\n')
}
/*
 * GFM 4.10: a delimiter row's cells hold only hyphens with an optional leading or trailing colon,
 * and "the delimiter row must match the header row in the number of cells. If not, a table will
 * not be recognized." Both halves, twinned with the gate. The old test asked only whether a hyphen
 * appeared somewhere on the line, so `| --- | not a delimiter |` opened a table and every pipe line
 * beneath it counted as a catalog row.
 *   `|-|-|-|` is VALID GFM and still opens a table: one hyphen is a legal delimiter cell and
 * GitHub renders it, so refusing it would fail a page a reader can see perfectly well.
 */
const DELIMITER_CELL = /^:?-+:?$/
const isDelimiter = (line, headerCells) => {
  if (!line.includes('|')) return false
  const cells = splitCells(line)
  return cells.length === headerCells && cells.every((c) => DELIMITER_CELL.test(c.trim()))
}
const tablesOf = (lines) => {
  const out = []
  for (let i = 0; i < lines.length; i++) {
    if (!lines[i].trimStart().startsWith('|')) continue
    const header = splitCells(lines[i]).map((c) => undecorate(c))
    if (!lines[i + 1] || !isDelimiter(lines[i + 1], header.length)) continue
    const body = []
    let j = i + 2
    for (; j < lines.length && lines[j].trimStart().startsWith('|'); j++) body.push({ line: j + 1, raw: lines[j] })
    out.push({ headerLine: i + 1, header, body, fileCol: header.findIndex((h) => FILE_COL.test(h)), statusCol: header.findIndex((h) => STATUS_COL.test(h)), dateCol: header.findIndex((h) => DATE_COL.test(h)) })
    i = j - 1
  }
  return out
}
const rowsOf = (ix) => {
  const rows = []
  const undecodable = []
  const malformed = []
  const siteAbsolute = []
  const headerGaps = []
  if (!exists(ix.file)) return { rows, undecodable, malformed, siteAbsolute, headerGaps }
  const lines = blankNonRendering(read(ix.file)).split('\n')
  const tables = ix.grammar === 2 ? tablesOf(lines).filter((t) => t.fileCol !== -1) : []
  // A COLUMN THAT IS NOT THERE is a gap in the page, never permission to read another one. With
  // no status column the check fell back to "any cell", so renaming `Status` to `Phase` turned
  // the bound rule back into the unbound one. Grammar 2 is the promise that each check reads the
  // column its header names, and a missing header means the promise cannot be kept.
  if (ix.grammar === 2) {
    for (const t of tables) {
      if (ix.statuses !== null && t.statusCol === -1) headerGaps.push({ line: t.headerLine, need: 'status', header: t.header })
      if (ix.requireDate && t.dateCol === -1) headerGaps.push({ line: t.headerLine, need: 'verification-date', header: t.header })
    }
  }
  const candidateRows = ix.grammar === 2
    ? tables.flatMap((t) => t.body.map((b) => ({ ...b, fileCol: t.fileCol, statusCol: t.statusCol, dateCol: t.dateCol })))
    : lines.map((raw, i) => ({ line: i + 1, raw, fileCol: -1, statusCol: -1, dateCol: -1 })).filter((r) => r.raw.trimStart().startsWith('|'))
  for (const { line: lineNo, raw: line, fileCol, statusCol, dateCol } of candidateRows) {
    const n = lineNo - 1
    if (!line.trimStart().startsWith('|')) continue
    const cells = splitCells(line)
    // THE LINK COMES FROM THE FILE COLUMN under grammar 2, and from anywhere under grammar 1.
    // Searching every cell was the last unbound rule: a row with an EMPTY file cell and a link in
    // its description counted as coverage, which is the "unrelated table" hole in its one-row
    // spelling.
    //   Under grammar 1 a cell only qualifies when it holds a link OUTSIDE a code span, for the
    // reason firstLink gives: a link inside one renders as text and catalogues nothing.
    const linkCell = fileCol >= 0 ? (cells[fileCol] ?? '') : (cells.find((c) => LINK.test(c) && firstLink(c)) ?? '')
    const link = firstLink(linkCell)
    if (!link) continue
    const to = link.dest
    if (!to || /^[a-z][a-z0-9+.-]*:/i.test(to) || to.startsWith('#')) continue
    // A ROOT-ABSOLUTE destination is a SITE path, which GitHub resolves against the domain rather
    // than against this directory. Joining it onto the index's directory invented a repo-relative
    // path nobody wrote, so `/guide.md` in a docs index resolved to docs/guide.md and passed as
    // coverage for a link that leads off the repo entirely.
    if (to.startsWith('/')) { siteAbsolute.push({ line: n + 1, raw: to }); continue }
    // A link with no closing parenthesis renders as literal text: the row reads as a catalog
    // entry to this parser and as prose to everyone who opens the page.
    if (!link.closed) { malformed.push({ line: n + 1, raw: to }); continue }
    // decodeURI THROWS on a target that is not valid percent-encoding, and `100%.md` is a legal
    // filename. Uncaught, one bad row killed the whole run with a decoder stack trace and no JSON
    // at all, which every caller reads as a broken planner rather than a broken row.
    let decoded
    try { decoded = destToPath(to) } catch { undecodable.push({ line: n + 1, raw: to }); continue }
    const resolved = posixJoin(ix.dir, decoded)
    rows.push({ line: n + 1, target: resolved, raw: to, cells, statusCol, dateCol, contained: underPath(resolved, ix.dir) })
  }
  return { rows, undecodable, malformed, siteAbsolute, headerGaps }
}

const chunk = (files) => {
  const out = []
  let cur = []
  let lines = 0
  let bytes = 0
  const flush = (oversize = false) => {
    if (!cur.length) return
    out.push({ index: out.length + 1, files: cur.map((f) => f.path), lines, bytes, oversize })
    cur = []; lines = 0; bytes = 0
  }
  for (const f of files) {
    if (f.lines > MAX_LINES || f.bytes > MAX_BYTES) { flush(); cur = [f]; lines = f.lines; bytes = f.bytes; flush(true); continue }
    if (cur.length >= MAX_FILES || lines + f.lines > MAX_LINES || bytes + f.bytes > MAX_BYTES) flush()
    cur.push(f)
    lines += f.lines
    bytes += f.bytes
  }
  flush()
  return out
}

// ONE OWNER PER FILE, and the owner is a DECLARATION rather than a directory.
//   A declared child index used to bound its ancestor at the whole child directory, which threw
// away the only thing that says what the child is authoritative about: the child's own
// declaration. A parent speaking for .json and a child speaking for .md left every .json under
// the child owned by nobody, catalogued by nobody, and green in both tables and the gate. The
// boundary is real; it runs over the files the child CLAIMS, not over its floor plan.
//   So the owner of a file is the DEEPEST declaration that actually claims it. Two declarations
// for one directory are refused above, so a tie is unreachable. Computed over the complete list
// plus any prospective index, never over a narrowed one.
const ownership = candidateDir !== null ? [...allDeclared, ...declared.filter((d) => d.prospective)] : allDeclared
const declaredIndexFiles = new Set(ownership.map((ix) => ix.file))
const claims = (ix, f) => (ix.scope === 'direct' ? dirOf(f) === ix.dir : underPath(f, ix.dir))
  // An index is a declaration, not content. Its own directory does not catalogue it, and neither
  // does an ancestor: a nested index is a directory's front page, and requiring the parent to
  // carry a row for it would mean declaring a child index reddens the parent that contains it.
  && !declaredIndexFiles.has(f)
  // `*` is the only selector that can promise a directory is completely covered: an extension
  // list can never reach a Dockerfile, a Makefile, or an extensionless executable.
  && (ix.extensions.includes('*') || ix.extensions.some((e) => f.endsWith(e)))
  && !ix.ignore.some((i) => underPath(f, i))
const ownerOf = (f) => {
  let best = null
  for (const ix of ownership) if (claims(ix, f) && (!best || ix.dir.length > best.dir.length)) best = ix
  return best
}
const inScope = (ix) => allFiles.filter((f) => ownerOf(f) === ix)

const planOf = (ix) => {
  const { rows, undecodable, malformed, siteAbsolute, headerGaps } = rowsOf(ix)
  const contained = rows.filter((r) => r.contained)
  const covered = new Set(contained.map((r) => r.target))
  const files = inScope(ix).map((path) => ({ path, ...measure(path), covered: covered.has(path) }))
  const missing = files.filter((f) => !f.covered)
  // A row pointing at a file that is gone. The lint fails on it too, and it is the other half of
  // what a reconciliation run fixes: a table can be wrong by omission or by rot.
  const orphaned = [...covered].filter((p) => !exists(p)).sort()
  // A row the table carries twice. Held in a Map this was a silent overwrite, so an index could
  // describe one file two different ways and pass every check there is.
  const seen = new Map()
  const duplicates = []
  for (const r of contained) {
    if (seen.has(r.target)) duplicates.push({ target: r.target, lines: [seen.get(r.target), r.line] })
    else seen.set(r.target, r.line)
  }
  // A row reaching out of the directory the index catalogues. It counted as coverage for a file
  // the index has no business speaking for, and it is almost always a target written relative to
  // the repo root instead of to the index.
  const escaping = rows.filter((r) => !r.contained).map((r) => ({ line: r.line, raw: r.raw, resolves: r.target }))
  const order = contained.map((r) => r.target)
  const outOfOrder = ix.ordered ? order.filter((t, i) => i > 0 && order[i - 1] > t) : []
  // The ROW GRAMMAR, which this engine did not check at all. A row with no status word, a row
  // with no required date, and an index with no reconciliation line were each exit 0 here and a
  // hard failure at the gate, so a reconciliation run could finish, report itself clean, and hand
  // back a repo CI refuses. The date rules read the calendar rather than the shape, so a row
  // dated 2026-99-99 is the missing date it actually is.
  const res = statusResFor(ix)
  // Under grammar 2 each check reads ITS column; under grammar 1 any cell answers for anything.
  //   Under grammar 2 a column that is not there yields NOTHING to read rather than every cell:
  // the header gap is the diagnosis, and falling back here would be the downgrade it refuses.
  const cellsFor = (r, col) => (ix.grammar === 2 ? (col >= 0 ? [r.cells[col] ?? ''] : []) : r.cells)
  const missingStatus = ix.statuses === null ? []
    : contained.filter((r) => !cellsFor(r, r.statusCol).some((c) => res.some((re) => re.test(undecorate(c))))).map((r) => ({ line: r.line, target: r.target }))
  const missingRowDate = !ix.requireDate ? []
    : contained.filter((r) => !cellsFor(r, r.dateCol).some((c) => isRealDate(c))).map((r) => ({ line: r.line, target: r.target }))
  const reconciledMatch = ix.reconciled && exists(ix.file) ? read(ix.file).match(INDEX_RECONCILED) : null
  const missingReconciled = Boolean(ix.reconciled && exists(ix.file) && !(reconciledMatch && isRealDate(reconciledMatch[1])))
  // An index that exists and lists NOTHING. The gate refuses it outright ("an index that lists
  // nothing indexes nothing") before it ever gets as far as saying what is missing, and this
  // engine reported exit 0 on it: a declared index over a directory whose files are all ignored
  // was structurally complete here and a hard failure there.
  const noRows = exists(ix.file) && contained.length === 0 && !ix.prospective
  const readOrder = mode === 'gaps' ? missing : files
  const structural = missing.length + orphaned.length + duplicates.length + escaping.length + outOfOrder.length
    + undecodable.length + malformed.length + siteAbsolute.length + headerGaps.length + (exists(ix.file) ? 0 : 1) + (noRows ? 1 : 0)
    + missingStatus.length + missingRowDate.length + (missingReconciled ? 1 : 0)
  return {
    ...ix,
    exists: exists(ix.file),
    files,
    missing: missing.map((f) => f.path),
    orphaned,
    duplicates,
    escaping,
    outOfOrder,
    // Rows the parser could read as an entry and a reader cannot: a link that never closes, and a
    // target that is not valid percent-encoding. Both are the page being wrong, not this engine.
    malformed,
    undecodable,
    // A destination markdown resolves against the DOMAIN, not against this directory.
    siteAbsolute,
    // A table header that does not name the column a declared check reads.
    headerGaps,
    // Rows the gate refuses on grammar rather than on coverage.
    missingStatus,
    missingRowDate,
    missingReconciled,
    noRows,
    unreadable: files.filter((f) => !f.readable).map((f) => ({ path: f.path, why: f.why })),
    // Named for what it is. `complete` read as "done" on the first target this met, and the rows
    // in that index had not been re-read in a year.
    structurallyComplete: structural === 0,
    lines: files.reduce((n, f) => n + f.lines, 0),
    bytes: files.reduce((n, f) => n + f.bytes, 0),
    // What the CHUNKS cover follows --mode. Reconcile is the default because re-reading an index
    // means re-reading every file it speaks for: a run that only read the new ones cannot notice
    // that an existing row stopped being true.
    chunks: chunk(readOrder),
  }
}
// EVERY declaration is planned, and narrowing chooses which of them gets REPORTED. Planning only
// the narrowed one meant `--index a` could not see that sibling `b` was missing a row, so a
// reconciliation of one directory finished clean and left the build red: the cheap check
// disagreed with the expensive one about a FACT, not about scope. Narrowing is a question about
// display and fan-out, and it was never a question about what is true. The same rule already
// governed cross-index duplicates; it governs everything now.
const planned = new Map(ownership.map((ix) => [ix, planOf(ix)]))
const allPlans = [...planned.values()]
const plans = declared.map((ix) => planned.get(ix)).filter(Boolean)
// Keyed on the FLAG, not on whether the two sets happen to differ. A repo with one declared index
// narrows to the same list it judges, and a run that then reported itself un-narrowed would be
// describing this invocation by accident of the repo's shape rather than by what was asked.
const isNarrowed = onlyIndex !== null || candidateDir !== null

// ── one file catalogued by two indexes ────────────────────────────────────────────────────
// The containment rule never saw this: a row in an ancestor's table for a file the child owns
// resolves, exists, and reads as coverage, so one file ended up with two authoritative
// descriptions and nothing anywhere could say which was current.
//   Scanned over EVERY declaration, never over the narrowed list. Narrowing scoped this to the one
// index being reported, so a file catalogued by both a parent and its child was caught by the full
// plan, missed by either narrowed run, and failed at the gate: a reconciliation of one directory
// could finish clean and leave the build red. Narrowing is a question about what gets REPORTED,
// and it was never a question about what is true.
const catalogedBy = new Map()
for (const ix of allDeclared) {
  for (const r of rowsOf(ix).rows.filter((r) => r.contained)) {
    if (!catalogedBy.has(r.target)) catalogedBy.set(r.target, new Set())
    catalogedBy.get(r.target).add(ix.file)
  }
}
const crossIndexDuplicates = [...catalogedBy].filter(([, where]) => where.size > 1)
  .map(([target, where]) => ({ target, indexes: [...where].sort() }))

// ── kept files no declaration speaks for ──────────────────────────────────────────────────
// The north star is every directory, and an extension list cannot reach it. A `direct` index
// (which is what the atlas skill declares on every new one) owns the files beside it and nothing
// below, so a nested directory with no declaration of its own belonged to nobody, was offered to
// nobody, and read as complete coverage. Scoped to what sits INSIDE an indexed tree, because a
// repo that indexes docs/ and nothing else has not asked to be told about its whole source tree.
//   An `ignore` entry is a DECISION, not a gap: the operator said out loud that this subtree owes
// no rows. Counting it as undecided would re-ask a question that has an answer sitting in the
// config, which is the exact failure docs.declined exists to prevent one level up.
const declaredFilePaths = new Set(allDeclared.map((ix) => ix.file))
const reaches = (ix, f) => (ix.scope === 'direct' ? dirOf(f) === ix.dir : underPath(f, ix.dir))
const decidedOut = (f) => ownership.some((ix) => reaches(ix, f) && ix.ignore.some((i) => underPath(f, i)))
const undecided = (f) => !declaredFilePaths.has(f) && !ownerOf(f) && !decidedOut(f)
  && !declined.some((d) => underPath(f, d.dir))
const unownedFiles = allFiles
  .filter((f) => undecided(f) && ownership.some((ix) => underPath(f, ix.dir)))
  .map((f) => ({
    path: f,
    dir: dirOf(f),
    why: ownership.some((ix) => reaches(ix, f))
      ? 'inside a directory that keeps an index, and no declaration\'s extensions reach it'
      : 'below a "direct" index, which owns the files beside it and nothing deeper',
  }))
// THE STATED BOUNDARY of the ownership model, twinned with the gate. A file at the repo ROOT
// cannot be owned: an index must live inside the directory it catalogues, so a root-level
// declaration is refused by construction, and the root's own pages are governed by the meta-doc
// checks instead. A file under a DOT-DIRECTORY is excluded for the reason candidate discovery
// excludes one: those directories hold tooling a reader does not browse. Both were silently
// green under strict, which made "every kept file" a sentence neither engine kept. Reported
// with the count so the qualifier travels with the claim, never failed: a dot-directory that
// genuinely wants covering is closable today by declaring an index for it.
//   A ROOT FILE IS NOT AUTOMATICALLY UNGOVERNED, and reporting 23 of them in one undifferentiated
// list said it was. Most of them are the meta docs, the ignore ruleset and the config, each held
// by a check of its own: naming those beside a root `Dockerfile` that genuinely nothing reaches
// buries the one file that is a real gap under eight that are not. So the boundary is CLASSIFIED
// rather than merely stated, and `governed` is the honest answer for a file another rule owns.
const ignoreFileRel = (() => {
  if (config.ignore !== undefined && config.ignore !== null && (typeof config.ignore !== 'object' || Array.isArray(config.ignore))) {
    fail('"ignore" must be an object { file, generated, allowExamples }; the gate exits 2 on this')
  }
  const ig = config.ignore && typeof config.ignore === 'object' && !Array.isArray(config.ignore) ? config.ignore : {}
  if (ig.file !== undefined && (typeof ig.file !== 'string' || !ig.file.trim())) {
    fail(`"ignore.file" must be a string path (got ${JSON.stringify(ig.file)}): it selects which file the trust ruleset is read from, and a wrong type silently substitutes a different one`)
  }
  return typeof ig.file === 'string'
    ? repoPath(ig.file, 'ignore.file')
    : repoPath('.gitignore', 'ignore.file (the default, in force because the key is not declared)')
})()
// Every root file another check already holds: the meta docs and any `docs.extra`, the stable
// docs (RS-stable-docs), the licence in each spelling RS-license accepts, the ignore ruleset, and
// the config itself.
// A DISABLED check governs nothing. `checks.<id>.enabled: false` is how a repo switches a rule
// off, and counting the files that rule would have held as "already governed" turned every
// disabled check into a silent widening of this boundary: a repo that disabled RS-stable-docs was
// told SECURITY.md was covered by a check that no longer runs.
const disabledChecks = (() => {
  const c = config.checks && typeof config.checks === 'object' && !Array.isArray(config.checks) ? config.checks : {}
  return new Set(Object.entries(c).filter(([, v]) => v && typeof v === 'object' && v.enabled === false).map(([k]) => k))
})()
const stableDocsRel = disabledChecks.has('stable-docs') ? []
  : (Array.isArray(config.stableDocs) ? config.stableDocs.filter((x) => typeof x === 'string')
    : ['SECURITY.md', 'CONTRIBUTING.md', 'CODE_OF_CONDUCT.md'])
// Every filename RS-license accepts, in the same list and the same order. Three spellings were
// missing here (LICENCE.txt, COPYING.txt, UNLICENSE), so a repo licensed under one of them was
// reported as carrying an UNGOVERNED root file while RS-license was holding it perfectly well.
const LICENSE_CANDIDATES = ['LICENSE', 'LICENSE.md', 'LICENSE.txt', 'LICENCE', 'LICENCE.md', 'LICENCE.txt', 'COPYING', 'COPYING.md', 'COPYING.txt', 'UNLICENSE']
const otherwiseGoverned = new Set([
  ...(disabledChecks.has('changelog') && disabledChecks.has('readme') && disabledChecks.has('conventions') ? [] : governedDocs),
  ...stableDocsRel,
  '.repo-standard.json',
  ...(disabledChecks.has('ignore') ? [] : [ignoreFileRel]),
  ...(disabledChecks.has('license') ? [] : LICENSE_CANDIDATES),
])
const outsideOwnership = allFiles
  .filter((f) => undecided(f) && !ownership.some((ix) => underPath(f, ix.dir)))
  .filter((f) => !dirOf(f) || f.split('/').some((seg, i, a) => i < a.length - 1 && seg.startsWith('.')))
  .map((f) => ({
    path: f,
    governed: !dirOf(f) && otherwiseGoverned.has(f),
    why: !dirOf(f)
      // "governed" here means a check reads this file and can fail on it, which is NOT the same as
      // "described": no rule anywhere says what SECURITY.md is for the way an index row would.
      // Stated in those words because the two were being conflated, and a boundary that quietly
      // upgrades "checked" to "catalogued" is the kind of claim this file exists to refuse.
      ? (otherwiseGoverned.has(f)
        ? 'at the repo root, where no index can reach it, and CHECKED by a rule of its own (a meta doc, the ignore ruleset, the licence, or the config). Checked is not described: no row anywhere says what it is for'
        : 'at the repo root, where no index can reach it, and NO enabled check reads it either: this is a real gap in "every file is described", not a technicality')
      : 'under a dot-directory, excluded the way candidate discovery excludes one; declare an index for it to bring it in',
  }))
// The gap worth counting: the root files nothing anywhere speaks for.
const ungovernedRoot = outsideOwnership.filter((f) => !dirOf(f.path) && !f.governed)

// ── directories that owe a decision ───────────────────────────────────────────────────────
// Offered, never assumed. These are the directories where a reader arrives and finds no glossary,
// which is where the standard has something to add. Keeping a README was never the rule that
// mattered: an ignored build directory with a README was offered as work while a kept source
// directory without one was passed over in silence. The rule is kept FILES that no declaration
// owns. Each one is MEASURED, per extension, because "42 files" is not a number anyone can agree
// to a fan-out over and the only alternative was re-counting the tree by hand in a shell.
// Over EVERY declaration, never the narrowed list. `--index` used to empty this outright, so a
// full plan reported a new top-level directory and the narrowed run over a sibling index exited 0
// on the same tree while the gate stayed red.
const declaredDirs = new Set(ownership.map((ix) => ix.dir))
const keptDirs = [...new Set(allFiles.map(dirOf))].filter(Boolean)
  .filter((d) => !d.split('/').some((seg) => seg.startsWith('.'))).sort()
const candidates = keptDirs
  .filter((d) => !declaredDirs.has(d) && !declinedDirs.has(d)
    // A directory whose files an ancestor already owns is covered; one whose files an `ignore`
    // entry excludes has been answered. Neither is a question worth asking again.
    && allFiles.filter((f) => dirOf(f) === d).some(undecided))
  .map((d) => {
    const files = allFiles.filter((f) => dirOf(f) === d && f !== `${d}/README.md`)
    const nested = allFiles.filter((f) => underPath(f, d) && dirOf(f) !== d)
    const byExt = {}
    for (const f of files) {
      const e = extOf(f)
      const m = measure(f)
      byExt[e] ??= { files: 0, lines: 0, bytes: 0, unreadable: 0 }
      byExt[e].files++
      byExt[e].lines += m.lines
      byExt[e].bytes += m.bytes
      if (!m.readable) byExt[e].unreadable++
    }
    return {
      dir: d,
      // Where the index would live. It is the README whether or not one exists yet: a directory
      // that keeps one gains a table on the page a reader already lands on, and a directory that
      // does not gets its front page written. Which of the two this is changes the offer, so it
      // is stated rather than left to be inferred from the path.
      readme: `${d}/README.md`,
      readmeExists: exists(`${d}/README.md`),
      // Direct files, because that is the model a new index is declared under. The nested count
      // is reported beside it so a recursive declaration can be priced without a second run.
      files: files.length,
      lines: files.reduce((n, f) => n + measure(f).lines, 0),
      bytes: files.reduce((n, f) => n + measure(f).bytes, 0),
      nestedFiles: nested.length,
      extensions: byExt,
      suggested: Object.entries(byExt).filter(([e, v]) => e !== '(none)' && v.files > v.unreadable).sort((a, b) => b[1].files - a[1].files).map(([e]) => e),
      priceWith: `--candidate ${d}`,
    }
  })

// ── an index sitting where a reader does not find it ──────────────────────────────────────
// GitHub renders README.md inline when someone browses a directory; INDEX.md takes a click. When
// the conventional home is FREE, moving the catalog into it is a real improvement and the
// operator should be asked. When it is taken the answer is no, and it is taken for a good reason
// more often than not: a README that is itself one of the artifacts the directory ships is not a
// slot to overwrite. Offered with the whole coordinated change set, because a rename that
// updates the config and forgets the inbound links leaves every reference to the page lying.
const textish = (f) => measure(f).readable
// Which directories carry a generated banner, so a rename can say that the artwork embedded in
// the page moves with it. Read straight from the manifest the identity pillar owns; absent or
// unparseable, the migration simply does not claim anything about artwork.
// What the identity pillar has been told about this directory, so a rename can hand it a change
// set rather than a hint. A directory EXCLUDED from folder-README coverage is the case that
// shipped broken: the exclusion is usually recorded because the directory keeps its front page
// under another name, so the rename is exactly what makes the exclusion (and the reason written
// beside it) false. Reporting that as one more line of prose to grep was not enough for an offer
// that calls itself a full change set.
// ROUTE-SELECTING FIELDS ARE VALIDATED BY TYPE, not defaulted past. `"assets": 7` and
// `"assets": { "dir": 7 }` both fell through to `.github/assets` here and exit 2 at the gate, so
// this engine reported on an asset directory the config never chose while the cheap half of the
// pair was the one saying no. A key whose VALUE decides which file gets opened is exactly the key
// a wrong type must stop, and the same rule governs `ignore.file` below.
if (config.assets !== undefined && config.assets !== false && (typeof config.assets !== 'object' || Array.isArray(config.assets) || config.assets === null)) {
  fail('"assets" must be false or an object { dir, coverage }; the gate exits 2 on this, and its "dir" decides which manifest this plan reads')
}
const assetsCfg = config.assets && typeof config.assets === 'object' && !Array.isArray(config.assets) ? config.assets : null
if (assetsCfg && assetsCfg.dir !== undefined && (typeof assetsCfg.dir !== 'string' || !assetsCfg.dir.trim())) {
  fail(`"assets.dir" must be a directory path relative to the repo root (got ${JSON.stringify(assetsCfg.dir)}): it selects the manifest this plan reads a banner declaration from, so a wrong type here is a plan built against a directory nobody chose`)
}
//   NORMALISED and matched by CONTAINMENT, not by string identity. `"./docs"` and `"docs/"` are
// the same exclusion as `"docs"`, and a `Set.has()` over the raw spelling agreed with none of
// them: the identity effect that says "this exclusion is about to be wrong" simply did not fire,
// on a config that was written perfectly legibly. An exclusion naming an ANCESTOR covers the
// directory too, for the same reason it does everywhere else in this engine.
// Raw bytes into the contract, twinned with the gate's `normRoot`: an exclusion written with a
// leading control character was trimmed into validity here and refused there. "." and "" are the
// repo root written two ways, and neither excludes anything in either engine.
const assetsCoverageIgnore = (assetsCfg && assetsCfg.coverage && Array.isArray(assetsCfg.coverage.ignore) ? assetsCfg.coverage.ignore : [])
  .filter((s) => typeof s === 'string')
  .map((s, i) => (s.trim() === '.' || s.trim() === '' ? '' : rawPath(s, `assets.coverage.ignore[${i}]`)))
const coverageExcludes = (dir) => assetsCoverageIgnore.some((i) => underPath(dir, i))
// The operator's recorded reason for that exclusion, if they wrote one. A "//assets" comment key
// naming the old path is a sentence that stops being true at the rename, and it is the one an
// applier can neither rewrite nor safely ignore.
const assetsRationale = typeof config['//assets'] === 'string' ? config['//assets'] : null
const assetBannerDirs = (() => {
  // Through the contract in both arms: the trailing-slash and leading-"./" spellings are the
  // contract's to normalise, and the DEFAULT is a path this engine opens too.
  const dir = (assetsCfg && typeof assetsCfg.dir === 'string'
    ? repoPath(assetsCfg.dir, 'assets.dir')
    : repoPath('.github/assets', 'assets.dir (the default, in force because the key is not declared)'))
  try {
    const m = JSON.parse(read(`${dir}/manifest.json`))
    // Spelled the same three ways a config path can be, and normalised the same way, or a banner
    // declared for "./docs" reads as a directory this repo does not have.
    return new Set((Array.isArray(m.banners) ? m.banners : []).map((b) => (typeof b?.dir === 'string' ? posix(b.dir.trim()).replace(/^\.\//, '').replace(/\/+$/, '') : null)).filter(Boolean))
  } catch { return new Set() }
})()
// A path is only a reference to this page when it stands on its own. Plain substring matching
// classified `submission-package/INDEX.md` as a reference to `docs/INDEX.md`, because one string
// contains the other, and proposed rewriting a file that had nothing to do with the move.
//   The trailing guard has to allow a SENTENCE-ENDING period and still refuse an extension that
// continues. A flat `(?![A-Za-z0-9._-])` refused both, so a rationale written "...it keeps its
// front page as docs/INDEX.md." was not a reference to docs/INDEX.md at all, and the one prose
// line a rename falsifies went unreported for want of a full stop.
//   GLOBAL, because a mention is an OCCURRENCE: two on one line are two things to judge, and a
// non-global regex reported the first and lost the second.
//   `full` decides what may precede the match. For the WHOLE path a "/" is allowed in front, which
// is what finds the path inside a full URL (https://github.com/o/r/blob/main/lib/INDEX.md): those
// used to appear in neither list. For the SHORT path, scanned only in the index's own directory, a
// "/" in front must still disqualify, or `submission-package/INDEX.md` reads as a reference to
// `docs/INDEX.md` and a rename proposes editing a file with nothing to do with it.
/*
 * A PATH AS IT CAN BE WRITTEN, which is not the same as how it is spelled. A URL carrying
 * `docs/INDEX%2Emd` names this page, matched no literal scan, and landed in NEITHER list: not a
 * link to repoint, not a mention for a person. Every ASCII character may appear as itself or
 * percent-encoded, in either hex case, which is exactly the set a browser and GitHub both decode.
 */
const pathAlternation = (path) => [...path].map((c) => {
  const lit = c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  if (c.charCodeAt(0) > 127) return lit
  const hex = c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0')
  return `(?:${lit}|%${hex}|%${hex.toLowerCase()})`
}).join('')
// The path itself is CAPTURED (group 2), because a percent-encoded spelling is longer than the path
// and the offset arithmetic used to subtract a constant length.
const referenceRe = (path, full) => new RegExp(`(^|[^A-Za-z0-9._${full ? '' : '/'}-])(${pathAlternation(path)})(?![A-Za-z0-9_-])(?!\\.[A-Za-z0-9_-])`, 'g')
/*
 * A BARE BASENAME IS A REFERENCE ONLY WHERE IT IS WRITTEN AS A PATH.
 *
 * Inside the index's own directory `INDEX.md` on its own is how a sibling page refers to it, and it
 * is equally how an unrelated sentence mentions somebody else's file. On the real target, a roadmap
 * row reading "submission-package INDEX.md" was reported as an inbound reference to docs/INDEX.md,
 * which it has nothing to do with, and no rule over the two words alone can tell them apart.
 *
 * So the short form counts where the character in front of it says "a filename follows": a code
 * span, a bracket, a parenthesis, a quote, a table-cell pipe, an emphasis marker, an explicit
 * "./", or the start of a line. What this gives up is a bare basename in flowing prose ("see
 * INDEX.md for the list"), and that is the trade taken deliberately: a mentions list an operator
 * stops reading is worth less than a shorter one where every line is real. The whole-path form is
 * unambiguous and is not held to this.
 */
const writtenAsPath = (body, at) => {
  if (body.slice(Math.max(0, at - 2), at) === './') return true
  let k = at
  while (k > 0 && (body[k - 1] === ' ' || body[k - 1] === '\t')) k--
  if (k === 0 || body[k - 1] === '\n') return true
  return '`([<"\'|*_'.includes(body[k - 1])
}

/*
 * WHERE A LINK ACTUALLY POINTS, which is the question the old regex never asked.
 *
 * The previous discovery was one regex for "does this line contain the index path" and a second
 * for "does a `](` sit in front of it". It got four things wrong at once, and an applier that
 * trusted it would have edited the wrong files and missed the right ones:
 *
 *   MISSED  `[x](./docs/INDEX.md)` and, from inside docs/, `[x](../docs/INDEX.md)`. Both are the
 *           same destination spelled differently, and neither matched a literal `docs/INDEX.md`
 *           with a boundary in front of it. They were reported in NEITHER list: not as a link to
 *           repoint, not even as a mention for a person to look at. A rename would have left them
 *           pointing at a page that no longer exists, silently.
 *   MISSED  reference-style links (`[x][id]` with `[id]: docs/INDEX.md` further down). The
 *           definition line was classified as a MENTION, so the one line that actually needs the
 *           rewrite was handed to a human as prose.
 *   WRONG   a link inside a fenced block or an inline code span is an EXAMPLE. Rewriting one
 *           edits documentation about the old path rather than a live reference to it.
 *   WRONG   `"see [the index](docs/INDEX.md)"` inside a .mjs string literal is not markdown at
 *           all. Only files markdown actually renders get link treatment; everything else naming
 *           the path is a mention a person judges.
 *
 * So: strip the code, find the three link forms markdown has, resolve each destination RELATIVE
 * TO THE FILE IT SITS IN, and compare resolved paths. A destination is a reference to this index
 * when it lands on it, whatever it was spelled like.
 */
const MARKDOWNISH = new Set(['.md', '.markdown', '.mdown', '.mkd'])
/*
 * WHERE THE CODE IS, as [start, end) RANGES over the source, never as a rewritten copy.
 *
 * The previous pass replaced each code span with spaces of the same LENGTH, which for a MULTILINE
 * span replaced its newlines too. Every line after such a span then sat one line earlier in the
 * blanked copy than in the file, and the two scans were compared by line NUMBER, so a genuinely
 * live link following a multiline code span was classified as an example and dropped from the
 * links list entirely. That is the one classification this offer must never get wrong: the whole
 * promise of the links list is that it is safe to apply mechanically.
 *
 * Ranges have no such failure mode. Nothing is rewritten, every offset is the offset in the file,
 * and "is this occurrence inside code" is asked of the occurrence rather than of its line.
 */
/*
 * WHAT A READER CANNOT SEE, as a predicate over OFFSETS, derived from the ONE block scanner above
 * rather than from a second copy of two of its rules.
 *
 * This used to be a private re-implementation that knew about fenced blocks and inline code spans
 * and nothing else, so a link inside an HTML comment, inside indented code, inside <pre>, or after
 * a fence nobody closed was promoted into the list this offer calls safe to rewrite mechanically.
 * `blankNonRendering` returns a string the SAME LENGTH as its input, so a byte is non-rendering
 * exactly where the two differ, and there is nothing left to drift.
 *
 * ASKED OF THE OPENING BRACKET, never of the whole link, and that is the second half of the fix.
 * An overlap test called `` [`docs/INDEX.md`](docs/INDEX.md) `` an example, because the code span
 * sits inside the link's LABEL: on the real target that demoted the one genuine live link in the
 * repository's front page into the manual list. A link is text when the `[` that opens it is
 * inside code. Where the label puts a span is the author's business.
 */
const hiddenAt = (text) => {
  const blanked = blankNonRendering(text)
  // Inline spans in WHAT IS LEFT: a backtick inside a fence, a comment or a <pre> never pairs with
  // one outside it. CommonMark 6.3: a run of length N is closed by the next run of exactly N.
  const spans = codeSpans(blanked)
  return (i) => blanked[i] !== text[i] || insideSpan(spans, i)
}
// Line numbers from offsets, computed once per file rather than by slicing the text at every hit.
const lineIndex = (text) => {
  const starts = [0]
  for (let i = 0; i < text.length; i++) if (text[i] === '\n') starts.push(i + 1)
  return (off) => {
    let lo = 0, hi = starts.length - 1
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (starts[mid] <= off) lo = mid; else hi = mid - 1 }
    return lo + 1
  }
}
// Resolve a link destination written in `from` against the repo root. Returns null for anything
// that is not a repo-relative path: an absolute URL, a mail link, a bare anchor, a root-absolute
// path (which is a site path, not a file path), or a destination that climbs out of the repo.
/*
 * A DESTINATION AS MARKDOWN READS IT. CommonMark 2.4 allows any ASCII punctuation to be
 * backslash-escaped inside one, so `[x](docs/INDEX\.md)` names docs/INDEX.md, and an escaped `#`
 * is part of the FILENAME rather than the start of a fragment. Neither was unescaped here, so a
 * correctly written destination resolved to nothing, matched no literal text scan either, and was
 * reported in NEITHER list.
 */
const PUNCT_ESCAPE = /\\([!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~])/g
const cutAddressing = (s) => {
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '\\') { i++; continue }
    if (s[i] === '#' || s[i] === '?') return s.slice(0, i)
  }
  return s
}
const resolveDest = (from, dest) => {
  let d = dest.trim().replace(/^<(.*)>$/, '$1').trim()
  if (!d) return null
  d = cutAddressing(d).replace(PUNCT_ESCAPE, '$1')
  if (!d || /^[a-z][a-z0-9+.-]*:/i.test(d) || d.startsWith('//') || d.startsWith('/')) return null
  // Per SEGMENT, the same way the index parser decodes one: decodeURI preserves the reserved set,
  // so a file named `one#two.md` and correctly written `one%23two.md` never resolved to itself.
  try { d = d.split('/').map((x) => decodeURIComponent(x)).join('/') } catch { /* compared as written */ }
  const segs = [...dirOf(from).split('/').filter(Boolean), ...d.split('/')]
  const stack = []
  for (const s of segs) {
    if (s === '.' || s === '') continue
    if (s === '..') { if (!stack.length) return null; stack.pop(); continue }
    stack.push(s)
  }
  return stack.join('/')
}
/*
 * EVERY LINK OCCURRENCE, with its own source offsets, so each one is classified on its own.
 *
 * Classification used to be keyed on the pair (line number, destination text), and a line is not
 * an occurrence. Three ways that went wrong, all of them on one line of ordinary prose:
 *   a live link and an identical link inside a code span on the SAME line matched the same key,
 *     so both were reported as live and an applier would have rewritten the example;
 *   a live link and a plain-text mention of the same path on the same line: the mention scan
 *     skipped any line a link had claimed, so the mention was reported in NEITHER list;
 *   the same destination twice on one line collapsed to one entry.
 *
 * Two forms beyond markdown's three are recognised here and land in `mentions`, because they were
 * reported in neither list before: a RAW HTML attribute (`<a href="lib/INDEX.md">`), which GitHub
 * renders as a working link markdown itself never sees, and the path inside a FULL URL, which the
 * plain-text scan below now reaches. Both need a person, and naming them is the difference between
 * "every inbound reference" and "every inbound reference this parser happens to recognise".
 */
const linkOccurrences = (text) => {
  const out = []
  for (let i = 0; i < text.length; i++) {
    // An ESCAPED bracket opens nothing: `\[x](docs/INDEX.md)` renders as literal text, and it was
    // promoted into the list this offer calls safe to rewrite mechanically.
    if (text[i] !== '[' || escapedAt(text, i)) continue
    let close = -1
    for (let k = i + 1; k < text.length; k++) if (text[k] === ']' && !escapedAt(text, k)) { close = k; break }
    if (close === -1) break
    if (text[close + 1] !== '(') continue
    const d = readDest(text, close + 2)
    // An IMAGE carries a real destination a rename breaks, and it is not a navigable link, so it is
    // reported rather than rewritten: the two are told apart here and judged below.
    const image = text[i - 1] === '!' && !escapedAt(text, i - 1)
    if (d.dest) out.push({ start: image ? i - 1 : i, end: d.end, dest: d.dest, closed: d.closed, kind: image ? 'inline image' : 'inline link' })
    i = close
  }
  // The reference DEFINITION is the rewritable half of a reference-style link; the `[x][id]` usage
  // carries no path at all and needs no edit.
  for (const m of text.matchAll(/^[ \t]{0,3}\[[^\]]+\]:[ \t]*(<[^>]*>|\S+)/gm)) {
    out.push({ start: m.index, end: m.index + m[0].length, dest: m[1], closed: true, kind: 'reference definition' })
  }
  for (const m of text.matchAll(/\b(?:href|src)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/gi)) {
    const dest = m[1] ?? m[2] ?? m[3] ?? ''
    if (dest) out.push({ start: m.index, end: m.index + m[0].length, dest, closed: true, kind: 'raw HTML attribute' })
  }
  return out.sort((a, b) => a.start - b.start)
}
// Released CHANGELOG sections are a record of what shipped. Rewriting a path inside one would
// falsify the history the file exists to preserve, so those lines are reported apart from the
// live ones and never counted as work an applier could take.
// The CANONICAL changelog path, so `f === changelogFile` compares against the spelling git
// lists. Written "./CHANGELOG.md" this comparison never matched, the released-history guard
// below never fired, and every link inside shipped history was queued as a safe mechanical
// rewrite: the one class of edit this offer promises never to make.
const changelogFile = docPath.changelog
/*
 * WHERE RELEASED HISTORY STARTS, and what to do when that cannot be established.
 *
 * The old rule looked for `## [x]` and treated everything above the first such heading as safe. Two
 * ways that shipped wrong. A changelog whose headings are written `## v1.2.3` matched nothing, so
 * the guard never fired and every link inside shipped history was queued as a mechanical rewrite:
 * the one class of edit this offer promises never to make. And a reference DEFINITION sitting below
 * a release heading is a link like any other, so it went the same way.
 *
 * So the burden is reversed, which is what the guard was always for: a changelog occurrence is
 * MANUAL unless it can be PROVEN to sit above released history. Any level-2 heading that is not
 * "Unreleased" opens the record of what shipped; if no such heading can be found at all, nothing in
 * the file can be proven to sit above one, and the whole file goes to the operator.
 */
const changelogRelease = (() => {
  if (!exists(changelogFile)) return { line: null, why: 'there is no changelog to reason about' }
  let text
  try { text = read(changelogFile) } catch { return { line: null, why: 'the changelog could not be read, so nothing in it can be shown to sit above released history' } }
  const heads = [...text.matchAll(/^[ \t]{0,3}##[ \t]+(.+?)[ \t]*$/gm)]
  const first = heads.find((m) => !/^\[?unreleased\]?\b/i.test(m[1].trim()))
  if (!first) return { line: null, why: 'no released section could be identified in it, so nothing here can be shown to sit above one' }
  return { line: text.slice(0, first.index).split('\n').length, why: null }
})()
const releasedIn = (f, n) => f === changelogFile && (changelogRelease.line === null || n >= changelogRelease.line)
const changelogWhy = changelogRelease.line === null
  ? `an occurrence in ${changelogFile}, and ${changelogRelease.why}. A changelog is a record of what shipped, so an occurrence in one is never rewritten mechanically unless it is provably above that record`
  : 'a link inside released changelog history, which is a record of what shipped'
const migrationOpportunities = allPlans
  // `retain` is the operator's recorded answer to exactly this question. Before it existed, a
  // deliberate "leave it where it is" had nowhere to live, so the offer came back on every run,
  // the exit code stayed 1 forever, and a finished decision was indistinguishable from an
  // ignored one.
  .filter((p) => p.exists && !p.prospective && !p.retain && p.file !== `${p.dir}/README.md` && !exists(`${p.dir}/README.md`))
  .map((p) => {
    const to = `${p.dir}/README.md`
    const short = p.file.slice(p.dir.length + 1)
    const links = []
    const mentions = []
    // THE MOVING PAGE IS IN ITS OWN CHANGE SET. Skipping it looked obvious and was wrong: a page
    // that links to itself (`[this page](INDEX.md)`, a table of contents, a "see the index below"
    // anchor) carries references that resolve to exactly the file being renamed, and they were
    // reported in NEITHER list. After the rename each one points at a page that no longer exists,
    // which is precisely the outcome the whole discovery pass exists to prevent.
    //
    // ONE ENTRY PER OCCURRENCE, and the occurrence is a RANGE OF BYTES rather than a line. Keying
    // on (line, destination) meant a line was the unit of classification, and a line holds more
    // than one thing: a live link beside an identical link in a code span put BOTH in the links
    // list, a live link beside a plain mention of the same path dropped the mention out of both
    // lists, and the same destination written twice on one line collapsed to a single entry.
    for (const f of allFiles) {
      if (!textish(f)) continue
      let body
      try { body = read(f) } catch { continue }
      const lines = body.split('\n')
      const lineAt = lineIndex(body)
      // Every entry carries its SOURCE RANGE and, for a link, the destination as written and as
      // resolved. An applier that has to re-find the occurrence by string matching would repeat the
      // whole classification, and the classification is the expensive half.
      const entry = (n, why, at) => ({ file: f, line: n, text: (lines[n - 1] ?? '').trim().slice(0, 160), released: releasedIn(f, n), why, ...at })
      // The byte ranges a link occurrence has already accounted for. The plain-text sweep below
      // skips these and nothing else, so a mention sharing a line with a link is still reported.
      const claimed = []
      /*
       * A LINK, and the bar for that word is every one of: a file markdown renders, an occurrence a
       * reader can SEE, a link that CLOSES, a destination that resolves to this index, a form the
       * markdown rule can actually repoint, and a line no released history owns.
       *
       * UNCERTAINTY BECOMES A MENTION. Everything this list promises rests on the claim that an
       * applier could rewrite each entry without reading it, so every case where that is arguable
       * goes to the operator instead. Each `continue` below is one of those cases, and each of them
       * used to end up in `links`.
       */
      if (MARKDOWNISH.has(extOf(f))) {
        const hidden = hiddenAt(body)
        for (const occ of linkOccurrences(body)) {
          const resolved = resolveDest(f, occ.dest)
          if (resolved !== p.file) continue
          const n = lineAt(occ.start)
          claimed.push([occ.start, occ.end])
          const at = { start: occ.start, end: occ.end, dest: occ.dest, resolves: resolved }
          // Raw HTML is a working link GitHub renders and markdown itself never parses, so it can
          // never be repointed by the same mechanical rule the markdown links get. It is real, it
          // is inbound, and it needs a person: that is exactly what the mentions list is for.
          if (occ.kind === 'raw HTML attribute') {
            mentions.push(entry(n, `a raw HTML href or src attribute pointing at ${p.file}. GitHub renders it as a live link and no markdown rule reaches it, so it is repointed by hand`, at))
            continue
          }
          // Asked of the OPENING BRACKET. An overlap test called a link with a code span in its
          // LABEL an example, which is how the one live link on a real repository's front page was
          // demoted into the manual list.
          if (hidden(occ.start)) {
            mentions.push(entry(n, `a link-shaped string somewhere markdown does not render it (a fence, a code span, an HTML comment, a <pre> block, or indented code), which is an EXAMPLE of ${p.file} rather than a reference to it`, at))
            continue
          }
          if (!occ.closed) {
            mentions.push(entry(n, `a link opening at ${p.file} that never closes, so markdown renders it as literal text: it reads as a reference here and as prose to everyone who opens the page`, at))
            continue
          }
          if (occ.kind === 'inline image') {
            mentions.push(entry(n, `an IMAGE whose destination resolves to ${p.file}. The rename breaks it, and an image is not a navigable link, so what the page meant here is a judgement rather than a rewrite`, at))
            continue
          }
          // Released history is quoted, never queued for rewriting, even when it is a real link.
          if (releasedIn(f, n)) { mentions.push(entry(n, changelogWhy, at)); continue }
          links.push(entry(n, f === p.file
            ? `a markdown ${occ.kind} on the moving page itself that resolves to ${p.file}, so it dangles the moment the file is renamed`
            : `a markdown ${occ.kind} that resolves to ${p.file}`, at))
        }
      }
      // Everything else naming the path: prose, a fenced example, a path written into source, a
      // config value, a released changelog line. Each needs a person, and saying so is what makes
      // "every inbound link is repointed" a claim this offer can keep.
      //   Scanned per OCCURRENCE and matched against the ranges above, so two mentions on one line
      // are two entries and a mention beside a link is still reported. The path itself is capture
      // group 2, because a percent-encoded spelling is longer than the path it names.
      const local = dirOf(f) === p.dir
      // The short form's leading boundary is the PERMISSIVE one, and `writtenAsPath` is what
      // narrows it. Refusing a preceding "/" in the regex looked like the same rule and was not:
      // it threw away `./INDEX.md`, which is a reference spelled the most ordinary way there is,
      // and reported it in neither list.
      for (const [re, isLocal] of [[referenceRe(p.file, true), false], ...(local ? [[referenceRe(short, true), true]] : [])]) {
        for (const m of body.matchAll(re)) {
          const at = m.index + m[1].length
          const len = m[2].length
          if (isLocal && !writtenAsPath(body, at)) continue
          if (claimed.some(([a, b]) => at >= a && at < b)) continue
          claimed.push([at, at + len])
          mentions.push(entry(lineAt(at), MARKDOWNISH.has(extOf(f))
            ? 'the path is written here, and it is not a live markdown link (prose, a fenced example, or a code span)'
            : 'the path is written in a file markdown does not render, so a link-shaped string in it is not a link', { start: at, end: at + len }))
        }
      }
    }
    links.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line))
    mentions.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line))
    const alsoUpdate = [
      `${p.at}.file in .repo-standard.json: "${p.file}" becomes "${to}"`,
      ...(extraDocs.includes(p.file) ? [`docs.extra, which lists "${p.file}" so the prose sweeps reach it`] : []),
    ]
    /*
     * WHAT THE IDENTITY PILLAR HAS TO DO ABOUT THIS RENAME, structured rather than mentioned.
     *
     * This journey owns neither the manifest nor the artwork and never writes one, so every
     * entry here is a HANDOFF: something for `/repo-standard-toolkit:identity` to carry out,
     * named precisely enough that the operator can see the whole change set before agreeing to
     * any of it. The case that shipped broken is the third one. A directory excluded from
     * folder-README coverage is usually excluded BECAUSE it keeps its front page under another
     * name, so the rename is exactly what makes the exclusion wrong, and reporting the config
     * line as one more grep hit left a plan that could stay lint-green while the reason written
     * in the config had become false and no banner was ever declared.
     */
    const identityEffects = [
      ...(assetBannerDirs.has(p.dir) ? [{
        what: 'banner moves with the page',
        detail: `the asset manifest declares a banner for "${p.dir}", and the generated markup for it is embedded in the page being renamed. The H1 block travels with the file, so nothing regenerates, but the manifest is the identity pillar's to confirm`,
      }] : []),
      ...(coverageExcludes(p.dir) ? [{
        what: 'the identity coverage exclusion is about to be wrong',
        detail: `"assets.coverage.ignore" excludes "${p.dir}" (by that name or by an ancestor), so this directory is left out from folder-README identity coverage. That exclusion is nearly always recorded because the directory keeps its front page under another name, which is the very thing this rename changes: after it, ${to} IS the folder README. Remove the exclusion, declare a banner for "${p.dir}", regenerate, and insert the generated H1${assetsRationale && referenceRe(p.file, true).test(assetsRationale) ? `. The recorded reason in "//assets" names "${p.file}" by path, so that sentence stops being true at the rename and no applier can rewrite a rationale` : ''}`,
      }] : []),
      ...(!assetBannerDirs.has(p.dir) && !coverageExcludes(p.dir) && assetsCfg ? [{
        what: 'the renamed page becomes a folder README with no banner declared',
        detail: `this repo generates an identity, and "${p.dir}" has no banner in the manifest. After the rename ${to} is the page a reader lands on, so it is the page a banner would head`,
      }] : []),
    ]
    return {
      dir: p.dir,
      from: p.file,
      to,
      why: 'GitHub renders README.md inline when a reader browses this directory, and the conventional home is free',
      // Structured argv, so a caller never has to re-quote a path with a space in it, plus the
      // shell-safe rendering for a human to read or paste.
      moveArgv: ['git', 'mv', p.file, to],
      move: `git mv ${shellQuote(p.file)} ${shellQuote(to)}`,
      alsoUpdate,
      // Handed to the identity pillar, which owns the manifest and the artwork. This journey
      // never writes one, and naming the effects is what keeps that separation honest instead of
      // silent.
      identityEffects,
      // Verified markdown links, which an applier could repoint mechanically...
      links,
      // ...and every other place the path is written, which needs a person: prose, a fenced
      // example, a released changelog line. Naming these apart is what makes "every inbound
      // reference" a claim anything can keep.
      mentions,
      retainIf: 'the operator wants the page to stay where it is, or something else is about to claim README.md',
      retainWith: `set "${p.at}.retain" in .repo-standard.json to the reason, and this stops being offered`,
    }
  })
// A recorded retain is a finished answer, reported as one rather than re-offered forever.
const retained = allDeclared.filter((ix) => ix.retain).map((ix) => ({ index: ix.file, dir: ix.dir, why: ix.retain }))

// ── counts and the three separate verdicts ────────────────────────────────────────────────
const counts = {
  universeErrors: universeErrors.length,
  indexes: plans.length,
  candidates: candidates.length,
  declined: declined.length,
  retained: retained.length,
  migrations: migrationOpportunities.length,
  files: plans.reduce((n, p) => n + p.files.length, 0),
  covered: plans.reduce((n, p) => n + p.files.filter((f) => f.covered).length, 0),
  missing: plans.reduce((n, p) => n + p.missing.length, 0),
  orphaned: plans.reduce((n, p) => n + p.orphaned.length, 0),
  duplicates: plans.reduce((n, p) => n + p.duplicates.length, 0),
  crossIndexDuplicates: crossIndexDuplicates.length,
  escaping: plans.reduce((n, p) => n + p.escaping.length, 0),
  outOfOrder: plans.reduce((n, p) => n + p.outOfOrder.length, 0),
  malformed: plans.reduce((n, p) => n + p.malformed.length, 0),
  undecodable: plans.reduce((n, p) => n + p.undecodable.length, 0),
  siteAbsolute: plans.reduce((n, p) => n + p.siteAbsolute.length, 0),
  headerGaps: plans.reduce((n, p) => n + p.headerGaps.length, 0),
  missingStatus: plans.reduce((n, p) => n + p.missingStatus.length, 0),
  missingRowDate: plans.reduce((n, p) => n + p.missingRowDate.length, 0),
  missingReconciled: plans.filter((p) => p.missingReconciled).length,
  emptyIndexes: plans.filter((p) => p.noRows).length,
  unreadable: plans.reduce((n, p) => n + p.unreadable.length, 0),
  unowned: unownedFiles.length,
  lines: plans.reduce((n, p) => n + p.lines, 0),
  bytes: plans.reduce((n, p) => n + p.bytes, 0),
  chunks: plans.reduce((n, p) => n + p.chunks.length, 0),
}
// The VERDICT is a fact about the repo, so every structural sum in it is taken over every
// declaration rather than over the narrowed report above. `counts` prices the fan-out being
// offered; this decides the exit code, and the two are different questions that used to share
// one set of numbers.
const sum = (f) => allPlans.reduce((n, p) => n + f(p), 0)
const absentIndexes = allPlans.filter((p) => !p.exists).map((p) => p.file)
const structuralWork = {
  // THE UNIVERSE ITSELF, first, because every count under it is a statement about a SET. A set
  // that quietly lost members makes "every file has a row" true of a smaller repo than the one
  // git tracks, so a plan built on one is not a plan.
  universeErrors: universeErrors.length,
  missing: sum((p) => p.missing.length),
  orphaned: sum((p) => p.orphaned.length),
  duplicates: sum((p) => p.duplicates.length),
  crossIndexDuplicates: counts.crossIndexDuplicates,
  escaping: sum((p) => p.escaping.length),
  outOfOrder: sum((p) => p.outOfOrder.length),
  malformed: sum((p) => p.malformed.length),
  undecodable: sum((p) => p.undecodable.length),
  siteAbsolute: sum((p) => p.siteAbsolute.length),
  headerGaps: sum((p) => p.headerGaps.length),
  // Grammar the gate refuses. Carried by the exit code here for the first time.
  missingStatus: sum((p) => p.missingStatus.length),
  missingRowDate: sum((p) => p.missingRowDate.length),
  missingReconciled: allPlans.filter((p) => p.missingReconciled).length,
  emptyIndexes: allPlans.filter((p) => p.noRows).length,
  // Undecided files reach the exit code only under strict ownership, which is the mode that
  // says they must be answered. Under `declared` they stay reported and unjudged, because the
  // operator's extension list IS their answer.
  undecidedFiles: ownershipMode === 'strict' ? counts.unowned : 0,
  absentIndexes,
  // A DIRECTORY nobody has decided about is structural work: it holds files the repo keeps, no
  // declaration reaches them, and no recorded no covers them. That is the whole north star, and
  // discovering it used to require the directory to keep a README, so a kept source directory
  // without one was passed over while an ignored build directory with one was offered.
  candidates: counts.candidates,
  migrations: counts.migrations,
}
// Computed from the block above rather than re-derived, so a field added there can never be left
// out of the verdict here. That divergence is exactly how `emptyIndexes` would have shipped
// counted-but-not-carried.
structuralWork.any = Object.entries(structuralWork)
  .some(([k, v]) => (k === 'absentIndexes' ? v.length > 0 : typeof v === 'number' && v > 0))
// Deliberately NOT part of structuralWork. A file inside a directory that already keeps an index
// sits under a declaration the operator wrote, and their extension list is their answer for it: a
// repo indexing its markdown and not its images has said what it wanted, and reddening that would
// be this engine imposing a scope nobody gave it. What it must never be is SILENT, because "no
// missing rows" over a set nobody chose reads exactly like coverage. So it is reported here, the
// gate names it in a skip, and the atlas run asks about it.
const undecidedFiles = {
  count: counts.unowned,
  ownership: ownershipMode,
  reachedByExitCode: ownershipMode === 'strict',
  // The qualifier travels with the claim. Without this the two engines said "every kept file" and
  // meant "every kept file except the ones at the root and under a dot-directory", which is the
  // difference between a checked invariant and a slogan.
  outsideModel: {
    count: outsideOwnership.length,
    // The number that actually means something: root files no check anywhere governs. The rest of
    // the list is the meta docs, the config and the ignore ruleset (each held by its own rule) and
    // the dot-directories (closable today by declaring an index for one).
    ungovernedRootFiles: ungovernedRoot.map((f) => f.path),
    files: outsideOwnership,
    note: 'kept files the ownership model does not reach in either mode: a file at the repo root (no declaration can reach one, because an index lives inside the directory it catalogues) and a file under a dot-directory (excluded the way candidate discovery excludes one). "strict" does not judge these, and says so rather than counting them as covered. Each root file states whether another check governs it, so the residual gap is countable rather than buried: see ungovernedRootFiles.',
  },
  note: ownershipMode === 'strict'
    ? 'kept files inside a directory that keeps an index which no declaration speaks for. "docs.ownership" is "strict", so these FAIL: every kept file under a declared root owes exactly one owner, an ignore entry, or a recorded decline. This is the mode in which "a file added tomorrow reddens the build" is a sentence this toolkit keeps.'
    : 'kept files inside a directory that keeps an index which no declaration speaks for. Answered by an extensions list (or ["*"]), an index of their own, an ignore entry, or a docs.declined record. Reported rather than failed, because "docs.ownership" is "declared": the directory has been decided about, and these files are what that decision left out. Set it to "strict" once the atlas is complete and they become failures.',
}
const reconciliationPlan = {
  files: counts.files,
  lines: counts.lines,
  bytes: counts.bytes,
  chunks: mode === 'reconcile' ? counts.chunks : plans.reduce((n, p) => n + chunk(p.files).length, 0),
  reachedByExitCode: false,
  note: 'what re-reading every file these indexes speak for would cost, whether or not any row is missing. No check anywhere reads a description and knows it still matches the code, so a structurally complete index is still work; the exit code does not carry this and never will.',
}
// What this run REPORTED, against what it judged. A narrowed run prices one directory's fan-out
// and still carries the repo's whole verdict, so the two have to be stated apart or an exit 1
// beside a clean-looking single index reads as a bug.
const scope = {
  narrowed: isNarrowed,
  reporting: plans.map((p) => p.file),
  judging: allPlans.map((p) => p.file),
  note: isNarrowed
    ? 'the detail and the chunks below cover the narrowed selection; the exit code covers the whole repo, because narrowing is a question about display and fan-out and never about what is true'
    : 'every declared index is both reported and judged',
}
const verdict = {
  exitCode: structuralWork.any ? 1 : 0,
  means: structuralWork.any
    ? 'there is structural work: something is missing, rotted, duplicated, out of place, owned by nobody, waiting to be offered, or (universeErrors) tracked by git and invisible to this plan.'
    : 'no structural work: every declared index carries a row for every file it speaks for, every row resolves, no file is catalogued by two indexes, no directory is an unanswered candidate, and no index is sitting somewhere a migration would move it. It does NOT mean the rows are accurate (reconciliationPlan prices re-reading them), and it does NOT mean every file is spoken for: undecidedFiles counts the ones inside an indexed directory that no declaration reaches.',
}

// ── output ────────────────────────────────────────────────────────────────────────────────
if (wantChunk !== null) {
  if (plans.length !== 1) fail(`--chunk asks for one chunk of one index, so say which: re-run with --index <path> (declared: ${plans.map((p) => p.file).join(', ') || 'none'}) or --candidate <dir>`)
  const c = plans[0].chunks.find((k) => k.index === wantChunk)
  if (!c) fail(`--chunk ${wantChunk} does not exist: ${plans[0].file} plans ${plans[0].chunks.length} chunk(s) in --mode ${mode}`)
  if (asJson) console.log(JSON.stringify({ index: plans[0].file, dir: plans[0].dir, mode, chunk: c }, null, 2))
  else {
    console.log(`index-plan: ${plans[0].file} chunk ${c.index} of ${plans[0].chunks.length} (--mode ${mode})`)
    console.log(`  ${c.files.length} file(s) · ${c.lines} line(s) · ${c.bytes} byte(s)${c.oversize ? ' · OVERSIZE, one file alone' : ''}`)
    for (const f of c.files) console.log(`    ${f}`)
  }
  process.exitCode = verdict.exitCode
} else if (asJson) {
  // counts FIRST, for the reason voice-scan puts them first: an agent harness truncates from the
  // tail, and the totals are what the offer is built from. (A PIPE no longer truncates: the exit
  // code is set rather than taken, so Node flushes stdout before it goes. It used to cut a large
  // plan at exactly 64 KiB and hand the caller invalid JSON.)
  const body = {
    target,
    mode,
    universe,
    universeErrors,
    scope,
    counts,
    verdict,
    structuralWork,
    reconciliationPlan,
    undecidedFiles,
    migrationOpportunities,
    chunking: { maxFiles: MAX_FILES, maxLines: MAX_LINES, maxBytes: MAX_BYTES, lineRule: LINE_RULE },
    declined,
    retained,
    crossIndexDuplicates,
    unownedFiles,
    indexes: summary ? plans.map(({ files, chunks, ...rest }) => rest) : plans,
    candidates,
  }
  console.log(JSON.stringify(body, null, 2))
  process.exitCode = verdict.exitCode
} else {
  console.log(`index-plan: ${target}`)
  console.log(`  universe: ${universe.kind} (${universe.why})`)
  if (universeErrors.length) {
    console.log(`  ${universeErrors.length} path(s) git keeps CANNOT ENTER the universe, so every count below is about a smaller repo than the one git tracks:`)
    for (const e of universeErrors) console.log(`    ${e.path}  (${e.why})`)
  }
  if (scope.narrowed) console.log(`  NARROWED: reporting ${scope.reporting.join(', ') || '(none)'} of ${scope.judging.length} declared index(es). ${scope.note}`)
  console.log(`  ${counts.indexes} declared index(es) · ${counts.files} file(s) to speak for · ${counts.lines} line(s) · ${counts.bytes} byte(s)`)
  console.log(`  ${counts.covered} row(s) already written · ${counts.missing} missing · ${counts.orphaned} pointing at a file that is gone`)
  console.log(`  a full re-read is ${reconciliationPlan.chunks} agent(s), at ${MAX_FILES} files or ${MAX_LINES} lines or ${MAX_BYTES} bytes each, whichever binds first`)
  console.log(`  --mode ${mode}: the chunks below cover ${mode === 'gaps' ? 'only the files carrying no row' : 'every file, which is what reconciling an index costs'}`)
  if (!summary) {
    for (const p of plans) {
      const dates = p.requireDate ? 'a date per row' : (p.reconciled ? 'one reconciled line for the index' : 'NONE, and the lint says so on every run')
      console.log(`\n  ${p.file}${p.exists ? '' : '  (does not exist yet)'}${p.prospective ? '  (PROSPECTIVE: nothing declares this yet)' : ''}`)
      console.log(`    ${p.extensions.join(' ')} ${p.scope === 'direct' ? 'directly in' : 'anywhere under'} ${p.dir}/ · ${p.files.length} file(s) · ${p.lines} line(s) · ${p.chunks.length} agent(s)`)
      console.log(`    statuses: ${p.statuses ? p.statuses.join(', ') : 'NONE declared, so no row states one'}${Object.keys(p.aliases).length ? ` · aliases: ${Object.entries(p.aliases).map(([w, c]) => `${w} to ${c}`).join(', ')}` : ''}`)
      console.log(`    dates: ${dates} · order: ${p.ordered ? 'ascending, and the lint holds it' : 'unchecked, so a later sweep produces a rewrite rather than a diff'}`)
      if (p.confirm) console.log(`    CONFIRM: ${p.confirm}`)
      if (p.retain) console.log(`    stays here by recorded decision: ${p.retain}`)
      if (p.ignore.length) console.log(`    ignored: ${p.ignore.join(', ')}`)
      // Which declarations take files out of this one's hands, and over what. A child index is a
      // boundary over the files it CLAIMS, never over its whole directory, so naming the directory
      // alone would describe a rule this engine no longer has.
      const bounds = ownership.filter((o) => o !== p && o.dir !== p.dir && underPath(o.dir, p.dir))
      if (bounds.length) console.log(`    stops at the declared child index(es): ${bounds.map((b) => `${b.file} (${b.extensions.join(' ')})`).join(', ')}`)
      if (p.structurallyComplete) console.log('    structurally complete: every file has a row and every row resolves. That is NOT the same as accurate; re-reading it is what checks that')
      for (const m of p.missing) console.log(`    missing row: ${m}`)
      for (const o of p.orphaned) console.log(`    row points nowhere: ${o}`)
      for (const d of p.duplicates) console.log(`    catalogued twice (lines ${d.lines.join(' and ')}): ${d.target}`)
      for (const e of p.escaping) console.log(`    row reaches outside ${p.dir}/ (line ${e.line}): "${e.raw}" resolves to ${e.resolves}`)
      for (const m of p.malformed) console.log(`    link never closes, so the row renders as prose (line ${m.line}): "${m.raw}"`)
      for (const u of p.undecodable) console.log(`    link target is not valid percent-encoding, so it cannot be resolved to a filename (line ${u.line}): "${u.raw}"`)
      for (const a of p.siteAbsolute) console.log(`    link destination begins with "/", which GitHub resolves against the domain rather than this directory, so it names no file here (line ${a.line}): "${a.raw}"`)
      for (const g of p.headerGaps) console.log(`    table header (line ${g.line}) names no ${g.need} column, and grammar 2 reads each check from the column its header names: ${g.header.map((h) => h || '(blank)').join(' | ')}`)
      for (const o of p.outOfOrder) console.log(`    out of ascending order: ${o}`)
      for (const s of p.missingStatus) console.log(`    no cell begins with one of this index's statuses (line ${s.line}): ${s.target}`)
      for (const d of p.missingRowDate) console.log(`    no verification date this index requires, or one that names no day on a calendar (line ${d.line}): ${d.target}`)
      if (p.noRows) console.log('    the page exists and carries no catalog row at all: an index that lists nothing indexes nothing, and the gate refuses it before it gets as far as saying what is missing')
      if (p.missingReconciled) console.log('    no well-formed "Reconciled against the code: YYYY-MM-DD" line, which this index declares it carries')
      for (const u of p.unreadable) console.log(`    cannot be read (${u.why}), so it must be named rather than described: ${u.path}`)
      for (const c of p.chunks.filter((c) => c.oversize)) console.log(`    one agent reads ${c.files[0]} alone (${c.lines} lines, ${c.bytes} bytes)`)
    }
  }
  if (crossIndexDuplicates.length) {
    console.log(`\n  ${crossIndexDuplicates.length} file(s) are catalogued by more than one index. One file has one owner, so one of the two rows is the one to delete:`)
    for (const d of crossIndexDuplicates) console.log(`    ${d.target}  (in ${d.indexes.join(' and ')})`)
  }
  if (unownedFiles.length) {
    console.log(`\n  ${unownedFiles.length} kept file(s) sit inside an indexed tree and no declaration speaks for them.${ownershipMode === 'strict' ? ' "docs.ownership" is "strict", so the gate FAILS on these:' : ' The gate names these in a skip rather than failing, so nothing here is red; they are undecided, which is not the same as covered:'}`)
    for (const u of unownedFiles) console.log(`    ${u.path}  (${u.why})`)
    console.log('    each is answered by an extensions list (or ["*"]), an index of its own, or a docs.declined entry')
  }
  if (outsideOwnership.length && ownershipMode === 'strict') {
    console.log(`\n  ${outsideOwnership.length} kept file(s) sit OUTSIDE the ownership model, so "strict" does not judge them. This is the qualifier on "every kept file", printed rather than left to be discovered:`)
    for (const u of outsideOwnership) console.log(`    ${u.path}  (${u.why})`)
    console.log(`    of those, ${ungovernedRoot.length} root file(s) are governed by NO check at all${ungovernedRoot.length ? `: ${ungovernedRoot.map((f) => f.path).join(', ')}` : ', so the boundary costs this repo nothing today'}`)
  }
  if (migrationOpportunities.length) {
    console.log(`\n  ${migrationOpportunities.length} index(es) sit where a reader browsing the directory does not find them. An atlas run OFFERS this move; it never makes one uninvited:`)
    for (const m of migrationOpportunities) {
      console.log(`    ${m.from} -> ${m.to}   (${m.move})`)
      for (const a of m.alsoUpdate) console.log(`      also: ${a}`)
      // Named apart from `alsoUpdate`, because these are not this journey's edits to make. The
      // manifest and the artwork belong to the identity pillar, and a change set that folded the
      // two together is one an atlas run would have carried out uninvited.
      for (const e of m.identityEffects) console.log(`      identity (hand to /repo-standard-toolkit:identity, which owns the manifest): ${e.what} — ${e.detail}`)
      // Two separate lists, because they call for two separate things. A markdown link can be
      // repointed mechanically; a path written into prose, a fenced example, or a released
      // changelog line is a judgement, and folding them together is what let this offer claim it
      // would repoint "every inbound reference".
      console.log(`      ${m.links.length} markdown link(s) to repoint${summary || !m.links.length ? '' : ':'}`)
      if (!summary) for (const i of m.links) console.log(`        ${i.file}:${i.line}  ${i.text}`)
      console.log(`      ${m.mentions.length} other mention(s), which a person has to judge${summary || !m.mentions.length ? '' : ':'}`)
      if (!summary) for (const i of m.mentions) console.log(`        ${i.file}:${i.line}${i.released ? '  (RELEASED HISTORY, never rewrite)' : ''}  ${i.text}`)
      console.log(`      retain instead: ${m.retainWith}`)
    }
  }
  if (candidates.length) {
    console.log(`\n  ${candidates.length} directory(ies) hold kept files no index speaks for. An atlas run OFFERS these; it never adopts one uninvited:`)
    for (const c of candidates) {
      const exts = Object.entries(c.extensions).sort((a, b) => b[1].files - a[1].files).map(([e, v]) => `${v.files} ${e} (${v.lines} lines)`).join(', ')
      console.log(`    ${c.dir}/  ${c.files} direct file(s), ${c.lines} line(s)${c.nestedFiles ? `, ${c.nestedFiles} more nested` : ''}${exts ? `: ${exts}` : ''}${c.readmeExists ? '' : '  (no README yet, so adopting it writes the directory a front page)'}`)
      console.log(`      price it exactly: node harness/index-plan.mjs --candidate ${shellQuote(c.dir)}${c.suggested.length ? ` --extensions ${shellQuote(c.suggested.join(','))}` : ''}`)
    }
  }
  if (retained.length) {
    console.log(`\n  ${retained.length} index(es) stay where they are by recorded decision, and are not offered a move again:`)
    for (const r of retained) console.log(`    ${r.index}  ${r.why}`)
  }
  if (declined.length) {
    console.log(`\n  ${declined.length} directory(ies) the operator has already turned down, recorded in docs.declined and not offered again:`)
    for (const d of declined) console.log(`    ${d.dir}/${d.stale ? '  (STALE: this directory no longer exists, so the decline outlived its subject)' : ''}${d.why ? `  ${d.why}` : '  (no reason recorded)'}`)
  }
  console.log(`\n  exit ${verdict.exitCode}: ${verdict.means}`)
  process.exitCode = verdict.exitCode
}
