#!/usr/bin/env node
/*
 * sense-state.mjs — the read-only inventory that tells the scaffolder what kind of repo it is
 * standing in, so greenfield vs. mid-project is DETECTED, never assumed.
 *
 * Reports, per standard artifact, whether it exists (and opens with an H1) and where it lives
 * (GitHub serves README + community health files with .github/ > root > docs/ precedence — the
 * sensed path is the one GitHub serves, lower-precedence duplicates are named, except a
 * docs/README.md under a served README, which is a directory index rather than a second front
 * page and is exempt in the lint too); whether the
 * enforcement layer is installed (the committed lint — and whether it is byte-identical to this
 * plugin's payload copy — the config, a CI workflow that runs the acceptance suite); the repo
 * signals a scaffolder can derive placeholder values from (git remote, manifests); and a
 * deterministic classification + per-artifact action plan:
 *
 *   greenfield — none of the governed docs exist yet (a LICENSE alone still counts as greenfield)
 *   partial    — some governed docs exist; scaffold the gaps, audit the rest
 *   governed   — all docs + lint + config + CI gate present; a re-run is reconcile-only
 *
 * Plan actions: scaffold (missing, fill from template) · audit (exists, run the lint and reconcile
 * only what reddens) · install (enforcement file missing) · merge (the file exists but is missing
 * rules this toolkit ships) · keep (byte-identical) · repair (the config does not parse) · offer
 * (an opt-in pillar nobody has answered about yet) · declined (the operator answered no, recorded
 * in scaffold.answers, so a re-run does not nag) · and, when the installed lint differs from the
 * payload, a DIRECTED verdict from the version constant each lint carries: upgrade (payload
 * newer, replace wholesale, config carries the repo specifics) · downgrade (payload OLDER: the
 * plugin is stale, and replacing would regress the repo's committed gate while calling it an
 * upgrade, so the skill must stop) · local-edit (same version, different bytes, so someone edited
 * a copy; diff before touching).
 *
 * Three actions are TERMINAL, and each means "stop, this answer cannot be trusted" rather than
 * "here is some work": blocked-universe (git keeps a path this engine cannot see, so every count
 * about the tree is about a smaller repo than the one git tracks), blocked-config (a configured
 * path leaves the repo, or a route-selecting key carries a type that would silently route this
 * plan somewhere else, so the key was refused rather than followed), and blocked-link (a governed
 * file is not a regular file at the path it is named by, so its bytes are committed somewhere else
 * and nothing here can honestly describe them).
 *
 * READ-ONLY by design: this engine never writes, never runs the lint (that is a separate,
 * visible step), and shells out only to read-only `git` queries. It never reads the clock, so the
 * same tree always senses the same.
 *
 * It DOES read .repo-standard.json, and branches on it: `assets.dir` decides which generator path
 * is checked for drift, `ignore.file` decides which file the secrets ruleset is read from, and
 * `scaffold.answers` is what turns an `offer` into a `declined`. What it does not do is enforce
 * anything, which is the lint's job. This header claimed the opposite for three versions.
 *   Because it BRANCHES on those paths, every one of them goes through the same two-leg path
 * contract the gate and the planner use, BEFORE anything is read, hashed or routed. Read-only is
 * not the same as harmless: this engine chooses which generator the scaffold skill is told to run.
 *
 * Usage: node harness/sense-state.mjs [--target <dir>] [--json]
 * Dependency-free: Node built-ins only. Exit 0 sensed · 2 bad invocation.
 */
import { readFileSync, readdirSync, existsSync, statSync, lstatSync, realpathSync, readlinkSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { join, resolve, dirname, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const PAYLOAD_LINT = fileURLToPath(new URL('../payload/acceptance/test-repo-standard.mjs', import.meta.url))
const PAYLOAD_GENERATOR = fileURLToPath(new URL('../payload/assets/generate.mjs', import.meta.url))
const DOCS = ['README.md', 'CHANGELOG.md', 'CONVENTIONS.md', 'CONTRIBUTING.md', 'CODE_OF_CONDUCT.md', 'SECURITY.md']
const LINT_REL = 'acceptance/test-repo-standard.mjs'
const CONFIG_REL = '.repo-standard.json'
// The pillars a re-run can offer beyond the front matter: the generated identity, the writing
// profile, the per-directory indexes, and the ignore ruleset. Sensed so the skill can ASK rather
// than assume, and so a repo that already adopted one is never asked about it twice.
const DEFAULT_ASSETS_DIR = '.github/assets'
// The literal rules that make a .env unstageable. Kept deliberately literal here, exactly as in
// the lint: what a plan proposes to add has to be as auditable as what the gate then enforces.
const SECRET_RULES = [
  { covers: '.env', accepts: ['.env', '/.env', '.env*', '/.env*'] },
  { covers: '.env.<variant>', accepts: ['.env.*', '/.env.*', '.env*', '/.env*'] },
]

const fail = (msg) => { console.error(`sense-state: ${msg}`); process.exit(2) }

const args = process.argv.slice(2)
let target = '.', asJson = false
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--target') target = args[++i] || fail('--target expects a directory')
  else if (args[i] === '--json') asJson = true
  else fail(`unknown argument "${args[i]}"`)
}
target = resolve(target)
if (!existsSync(target) || !statSync(target).isDirectory()) fail(`target is not a directory: ${target}`)
// CANONICALISED, twinned with the planner and the gate: how a repo is ADDRESSED must never change
// what is true about it. Reached through a symlinked path, `git rev-parse --show-toplevel` hands
// back the resolved worktree, the ownership guard below compared unequal, and this engine fell
// back to a filesystem walk that offers more directories than the other two engines see.
try { target = realpathSync(target) } catch { /* not resolvable: the plain path is the best there is */ }

/*
 * THE PATH CONTRACT, twinned with the gate and the planner, and it was missing here entirely.
 *
 * This engine is READ-ONLY, which is what made its absence easy to miss and expensive to keep. It
 * does not enforce anything; it ROUTES. `assets.dir` decides which generator is hashed, versioned
 * and handed a plan action, and `ignore.file` decides which file the secrets ruleset is read from.
 * With `assets.dir: "../outside/assets"` this engine read a generator in a sibling checkout,
 * reported it as installed at version 9.9.9, and emitted a DIRECTED action for it, while the
 * planner and the gate both exited 2 on the very same config. The scaffold skill then follows that
 * action, and one of the actions it can follow is "run this generator": a path the repo's own
 * config chose, outside the repo, executed on the operator's behalf.
 *
 * So every configured path is validated and canonicalised BEFORE it is read, hashed or routed, and
 * a refusal is TERMINAL for the thing it points at rather than a note beside a confident answer.
 */
const configPathErrors = []
const CONTROL_CHAR = /[\u0000-\u001f\u007f]/
const escapesRepo = (p) => p.startsWith('/') || /^[A-Za-z]:/.test(p) || p.includes('\\')
  || CONTROL_CHAR.test(p)
  || p.split('/').some((seg) => seg === '..' || seg === '')
const targetReal = (() => { try { return realpathSync(target) } catch { return target } })()
const realOf = (abs) => {
  try { return realpathSync(abs) } catch { /* missing, or a link with no target */ }
  try { if (lstatSync(abs).isSymbolicLink()) return resolve(dirname(abs), readlinkSync(abs)) } catch { /* not on disk */ }
  return null
}
const escapesOnDisk = (p) => {
  const abs = join(target, p)
  const real = realOf(abs) ?? realOf(dirname(abs))
  if (real === null) return false
  return real !== targetReal && !real.startsWith(targetReal + sep)
}
// Returns the CANONICAL path, or null when the key must not be followed. Spelling first, then the
// canonical form, then the physical containment leg: exactly the order the other two engines use.
const configPath = (raw, where) => {
  if (typeof raw !== 'string') return null
  const spelled = raw.length > 1 ? (raw.replace(/\/+$/, '') || raw) : raw
  if (escapesRepo(spelled)) {
    configPathErrors.push({ where, raw, why: 'must be a repo-relative path that stays inside this repo: no leading "/", no "..", no backslashes, no empty path components, no control characters' })
    return null
  }
  const canon = spelled === '.' ? spelled : spelled.replace(/^\.\//, '')
  if (escapesOnDisk(canon)) {
    configPathErrors.push({ where, raw, why: 'is spelled as a repo-relative path and resolves OUTSIDE this repo: something in it is a symlink pointing away' })
    return null
  }
  return canon
}

/*
 * A REGULAR FILE AT THE PATH IT IS NAMED BY, which is a different question from where the path
 * points and was asked nowhere here.
 *
 * This engine reads, hashes and VERSIONS the committed lint and the committed generator, and the
 * scaffold journey follows what it says about them: one of the actions it can return is "replace
 * this file", and another is "run it". A target whose acceptance/test-repo-standard.mjs was a
 * SYMLINK to a clean copy in another checkout came back `matchesPayload: true` and `keep`, on a
 * repo whose own index was missing a row, because every read followed the link and every hash was
 * of somebody else's bytes. `configPath` catches a path aimed outside; this catches the
 * substitution itself, including one aimed at a perfectly ordinary file inside the repo.
 *
 * It is TERMINAL for the artifact it names, the same as a refused config key: there is nothing
 * honest to say about a file whose committed content is not at the path being governed.
 */
const substitutions = []
const notRegularFile = (rel, what) => {
  let st = null
  try { st = lstatSync(join(target, rel)) } catch { return false } // absent is a different answer
  if (st.isFile()) return false
  substitutions.push({ path: rel, kind: st.isSymbolicLink() ? 'a symlink' : 'not a regular file', what })
  return true
}
const readIf = (rel) => { try { return readFileSync(join(target, rel), 'utf8').replace(/^﻿/, '') } catch { return null } }
const sha256 = (text) => createHash('sha256').update(text).digest('hex')
const git = (...argv) => {
  try { return execFileSync('git', ['-C', target, ...argv], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim() } catch { return null }
}
// `git -C <dir>` walks UP to find a repo, so a plain directory nested inside an unrelated
// checkout would otherwise inherit that repo's name, remote, and history. Only trust git when
// the discovered worktree IS the target.
const gitOwnsTarget = git('rev-parse', '--show-toplevel') === target

// ---- artifacts ----
// "opens with an H1" means the document's FIRST content is an ATX H1 — an unanchored /^# /m
// would match a `# comment` inside a fenced bash block, which nearly every README has.
const opensWithH1 = (text) => {
  const first = text.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('<!--'))[0] || ''
  return /^# +\S/.test(first)
}
const artifacts = {}
// a path is a candidate only if it is a readable FILE — existsSync alone would let a
// DIRECTORY named .github/README.md mask a healthy root README as "missing".
//   stat, not lstat, ON PURPOSE: a symlinked README is still the page GitHub serves from that
// path, so calling it missing would have the plan scaffold a duplicate on top of it. What it is
// NOT is a file whose content this repo commits at that path, and that is recorded separately by
// `notRegularFile` below and carried by a terminal action rather than folded in here.
const isFile = (p) => { try { return statSync(join(target, p)).isFile() } catch { return false } }
for (const doc of DOCS) {
  // GitHub serves README and the community health files with precedence .github/ > root >
  // docs/ — sense where a doc ACTUALLY lives, so the plan audits an existing .github/ copy
  // instead of scaffolding a root duplicate that would shadow it or be shadowed by it. The
  // first hit is what GitHub renders; further hits are duplicates the lint's RS-shadow reddens,
  // with the one exemption RS-shadow itself makes: a `docs/README.md` sitting under a served
  // README is a directory index, not a second front page, so it is never reported here either.
  const found = [`.github/${doc}`, doc, `docs/${doc}`].filter(isFile)
  // The candidate list stays three wide on purpose: a repo whose ONLY README is docs/README.md
  // is served from there, and dropping the path would sense it as missing and have the plan
  // scaffold a root duplicate beside it. `found.slice(1)` already means "something
  // higher-precedence won", so the exemption needs no extra condition: when docs/README.md is
  // the only copy it is found[0] and never reaches this filter.
  const dupes = found.slice(1).filter((p) => !(doc === 'README.md' && p === 'docs/README.md'))
  if (found.length) notRegularFile(found[0], `${doc} is a page the scaffold audits, reconciles and (for a README) compares generated markdown against`)
  const text = found.length ? readIf(found[0]) : null
  artifacts[doc] = text === null
    ? { exists: false }
    : {
      exists: true,
      path: found[0],
      bytes: Buffer.byteLength(text),
      hasH1: opensWithH1(text),
      ...(dupes.length ? { duplicates: dupes } : {}),
    }
}
// licensee's filename family, most conventional first — mirrored in the payload lint's
// RS-license candidates: a repo licensed via COPYING (the GPL convention) or LICENSE.md is
// licensed, not license-less, and scaffolding a second license file beside it would break
// GitHub's license detection outright.
const LICENSE_CANDIDATES = ['LICENSE', 'LICENSE.md', 'LICENSE.txt', 'LICENCE', 'LICENCE.md', 'LICENCE.txt', 'COPYING', 'COPYING.md', 'COPYING.txt', 'UNLICENSE']
const licenseFileRel = LICENSE_CANDIDATES.find(isFile) ?? null
const licenseText = licenseFileRel ? readIf(licenseFileRel) : null
artifacts.LICENSE = licenseText === null ? { exists: false } : { exists: true, path: licenseFileRel, bytes: Buffer.byteLength(licenseText) }

// ---- enforcement ----
// NOT READ WHEN IT IS NOT A REGULAR FILE. Reading through the link is what produced `matchesPayload:
// true` for a target whose committed gate was a pointer at somebody else's clean copy. `installed`
// stays true, because something IS at that path and telling the scaffold to install over it would
// write through the link; what changes is that nothing about its content is claimed.
const lintSubstituted = notRegularFile(LINT_REL, 'the committed gate is what CI runs, and what a re-run compares against the payload byte for byte')
const lintText = lintSubstituted ? null : readIf(LINT_REL)
const payloadText = existsSync(PAYLOAD_LINT) ? readFileSync(PAYLOAD_LINT, 'utf8') : null
// the machine-readable version each lint copy carries (the payload lint's REPO_STANDARD_LINT_
// VERSION constant, locked to the plugin version by an acceptance test). null = a copy from
// before versioning existed — older than every versioned payload by construction.
const lintVersionOf = (text) => text?.match(/^const REPO_STANDARD_LINT_VERSION = '([^'\n]+)'/m)?.[1] ?? null
// semver compare, enough for plugin versions: numeric triple, then a prerelease is older than
// its release, then prerelease identifiers left to right (numeric < alphanumeric, numeric
// numerically, alphanumeric by ASCII).
const semverCmp = (a, b) => {
  const pa = a.split('-')[0].split('.').map(Number), pb = b.split('-')[0].split('.').map(Number)
  for (let i = 0; i < 3; i++) if (pa[i] !== pb[i]) return pa[i] - pb[i]
  const preA = a.includes('-') ? a.slice(a.indexOf('-') + 1).split('.') : null
  const preB = b.includes('-') ? b.slice(b.indexOf('-') + 1).split('.') : null
  if (!preA || !preB) return (preA ? -1 : 0) - (preB ? -1 : 0)
  for (let i = 0; i < Math.max(preA.length, preB.length); i++) {
    if (preA[i] === undefined) return -1
    if (preB[i] === undefined) return 1
    const na = /^\d+$/.test(preA[i]), nb = /^\d+$/.test(preB[i])
    if (na && nb) { const d = Number(preA[i]) - Number(preB[i]); if (d) return d }
    else if (na !== nb) return na ? -1 : 1
    else if (preA[i] !== preB[i]) return preA[i] < preB[i] ? -1 : 1
  }
  return 0
}
// Recorded rather than branched on: the config is still parsed, because a substituted one that
// happens to be valid still tells the operator what this repo declares. What changes is that the
// plan entry for it becomes terminal.
notRegularFile(CONFIG_REL, 'every action below is computed from this file')
const configText = readIf(CONFIG_REL)
let configValid = null, configScaffold = null, configParsed = null
if (configText !== null) {
  try {
    const parsed = JSON.parse(configText)
    configParsed = parsed
    configValid = true
    // the provenance block the skill records at scaffold time — reported so the plan can
    // distinguish "scaffolded by 0.1.0" from "never recorded", and so a re-run can pre-fill
    // the operator's confirmed answers instead of re-asking.
    const s = parsed.scaffold
    if (s && typeof s === 'object' && !Array.isArray(s)) {
      configScaffold = {
        pluginVersion: typeof s.pluginVersion === 'string' ? s.pluginVersion : null,
        answers: s.answers && typeof s.answers === 'object' && !Array.isArray(s.answers) ? s.answers : {},
      }
    }
  } catch { configValid = false }
}

const wfDir = join(target, '.github', 'workflows')
const workflows = existsSync(wfDir) ? readdirSync(wfDir).filter((f) => /\.ya?ml$/.test(f)).sort() : []
// a workflow is the GATE only if it runs the whole suite (the canonical for-loop) or at least
// the repo-standard lint by name — merely mentioning some acceptance test is not a gate (a
// pre-existing workflow running one unrelated test must not satisfy the install plan).
// anchored at the COMMAND position: the gate must be what a step actually runs, not merely a
// string that appears somewhere in the file. A `#`-commented line and `echo "… node
// acceptance/test-repo-standard.mjs …"` both mention it and neither runs it.
const GATE_RE = /^(?:for t in acceptance\/test-\*\.mjs|node acceptance\/test-repo-standard\.mjs)/
const runsGate = (yml) => (yml || '').split('\n')
  .filter((l) => !/^\s*#/.test(l))
  .map((l) => l.replace(/\s#.*$/, '').trim().replace(/^-\s*/, '').replace(/^run:\s*/, '').trim())
  .some((l) => GATE_RE.test(l))
const ciRunsAcceptance = workflows.some((f) => runsGate(readIf(join('.github', 'workflows', f))))

const acceptDir = join(target, 'acceptance')
const existingTests = existsSync(acceptDir) ? readdirSync(acceptDir).filter((f) => /^test-.*\.mjs$/.test(f)).sort() : []

const installedLintVersion = lintVersionOf(lintText)
const payloadLintVersion = lintVersionOf(payloadText)
// direction of a differing lint, decided by version, never by assumption: an unversioned
// installed copy predates every versioned payload (upgrade); an unversioned PAYLOAD can never
// prove it is newer, so the honest verdict is local-edit, not a claimed upgrade.
const lintDrift = () => {
  if (installedLintVersion && payloadLintVersion) {
    const d = semverCmp(payloadLintVersion, installedLintVersion)
    return d > 0 ? 'upgrade' : d < 0 ? 'downgrade' : 'local-edit'
  }
  return payloadLintVersion ? 'upgrade' : 'local-edit'
}

// ---- the opt-in pillars, plus the ignore ruleset the gate already checks ----
// Identity. The generator carries its own version constant, so a differing copy is DIRECTED the
// same way the lint's is: an older payload must never quietly replace a newer committed one.
/*
 * A ROUTE-SELECTING FIELD IS VALIDATED BY TYPE, never defaulted past.
 *
 * `"assets": 7` and `"assets": { "dir": 7 }` both fell straight through to `.github/assets` here
 * while the gate and the planner exited 2 on the same config. That is worse than a disagreement
 * about an exit code: this engine's answer about the generator is what the scaffold journey
 * FOLLOWS, so a wrong type quietly routed an upgrade at a directory the config never chose. A key
 * whose value decides which file gets opened is exactly the key a wrong type has to stop.
 */
const assetsRaw = configParsed?.assets
const assetsTypeBad = assetsRaw !== undefined && assetsRaw !== false && assetsRaw !== null
  && (typeof assetsRaw !== 'object' || Array.isArray(assetsRaw))
if (assetsTypeBad) configPathErrors.push({ where: 'assets', raw: assetsRaw, why: 'must be false or an object { dir, coverage }: its "dir" selects the generator this engine hashes, versions and hands the scaffold to RUN' })
const assetsDeclared = assetsRaw && typeof assetsRaw === 'object' && !Array.isArray(assetsRaw)
const assetsDirTypeBad = Boolean(assetsDeclared && assetsRaw.dir !== undefined && (typeof assetsRaw.dir !== 'string' || !assetsRaw.dir.trim()))
if (assetsDirTypeBad) configPathErrors.push({ where: 'assets.dir', raw: assetsRaw.dir, why: 'must be a directory path relative to the repo root: it selects the generator this engine hashes, versions and hands the scaffold to RUN, and a wrong type silently routed that at the default directory instead' })
// THROUGH THE CONTRACT, BEFORE ANYTHING IS READ, and the DEFAULT goes through it too: a key left
// undeclared is a value the config chose by staying silent, and `.github/assets` can be a symlink
// pointing away exactly as a written path can. A refusal yields null, and null means this engine
// reports the key as unusable rather than following it: no read, no hash, no version, and above
// all no plan action pointing at a generator outside the tree for the scaffold skill to run.
const assetsDirDeclared = assetsTypeBad || assetsDirTypeBad ? null
  : (assetsDeclared && typeof assetsRaw.dir === 'string'
    ? configPath(assetsRaw.dir, 'assets.dir')
    : configPath(DEFAULT_ASSETS_DIR, 'assets.dir (the default, in force because the key is not declared)'))
const assetsDirUsable = assetsDirDeclared !== null
const assetsDir = assetsDirDeclared ?? DEFAULT_ASSETS_DIR
const generatorRel = `${assetsDir}/generate.mjs`
const assetManifestRel = `${assetsDir}/manifest.json`
// Not read when it is not a regular file, for the reason the lint is not: the scaffold runs what
// this engine reports on, and a linked generator is an engine committed somewhere else.
const generatorSubstituted = assetsDirUsable && notRegularFile(generatorRel, 'the scaffold journey runs this file, and a re-run compares it against the payload byte for byte')
const generatorText = assetsDirUsable && !generatorSubstituted ? readIf(generatorRel) : null
const payloadGeneratorText = existsSync(PAYLOAD_GENERATOR) ? readFileSync(PAYLOAD_GENERATOR, 'utf8') : null
const generatorVersionOf = (text) => text?.match(/^export const REPO_STANDARD_ASSETS_VERSION = '([^'\n]+)'/m)?.[1] ?? null
const installedGeneratorVersion = generatorVersionOf(generatorText)
const payloadGeneratorVersion = generatorVersionOf(payloadGeneratorText)
const generatorDrift = () => {
  if (installedGeneratorVersion && payloadGeneratorVersion) {
    const d = semverCmp(payloadGeneratorVersion, installedGeneratorVersion)
    return d > 0 ? 'upgrade' : d < 0 ? 'downgrade' : 'local-edit'
  }
  return payloadGeneratorVersion ? 'upgrade' : 'local-edit'
}
const manifestSubstituted = assetsDirUsable && notRegularFile(assetManifestRel, 'every asset and every generated line on the front page is rendered from this declaration')
const manifestText = assetsDirUsable && !manifestSubstituted ? readIf(assetManifestRel) : null
let assetManifestValid = null, assetCounts = null
if (manifestText !== null) {
  try {
    const m = JSON.parse(manifestText)
    assetManifestValid = true
    assetCounts = { banners: Array.isArray(m.banners) ? m.banners.length : 0, pills: Array.isArray(m.pills) ? m.pills.length : 0, paletteKind: m.paletteSource?.kind ?? null }
  } catch { assetManifestValid = false }
}

// Voice. Only what the config declares: the sweep itself is harness/voice-scan.mjs, which is a
// separate, visible step for the same reason running the lint is.
const proseDeclared = configParsed?.prose && typeof configParsed.prose === 'object' && !Array.isArray(configParsed.prose)
// Which directories already say what each file in them is for. Inventory only: which spelling the
// repo used and which pages it points at, so a re-run can ask about the atlas once instead of
// twice. What is actually MISSING from each index is harness/index-plan.mjs, which is a different
// question and a more expensive one.
const docsBlock = configParsed?.docs && typeof configParsed.docs === 'object' && !Array.isArray(configParsed.docs) ? configParsed.docs : null
const indexSpelling = docsBlock?.indexes !== undefined ? 'docs.indexes' : (docsBlock?.index !== undefined && docsBlock.index !== false ? 'docs.index' : null)
const indexDecls = indexSpelling === 'docs.indexes'
  ? (Array.isArray(docsBlock.indexes) ? docsBlock.indexes : [])
  : (indexSpelling === 'docs.index' ? [docsBlock.index] : [])
// Canonical, and only the declarations whose paths this engine may follow. A declaration whose
// file escapes the repo is reported in configPathErrors and takes no part in the atlas answer:
// counting it would be this engine describing a tree the other two refuse outright.
const indexFiles = indexDecls
  .filter((d) => d && typeof d === 'object' && typeof d.file === 'string')
  .map((d, i) => configPath(d.file, `${indexSpelling}[${i}].file`))
  .filter((f) => f !== null)
// Directories a reader lands in and finds prose with no glossary behind it. Adoption is not a
// binary: a repo can declare one index over `docs/` and leave nine other directories carrying a
// README that says nothing about what is in them, and a plan that read that as `keep` would
// never offer the pillar again on exactly the repo that needs it most. Measured on the real
// target this was built against, which had precisely that shape.
//   Cheap on purpose: one `git ls-files` and no file contents. What is MISSING from an index
// that already exists is harness/index-plan.mjs, which reads every file to answer it, and a
// sense run must never cost that.
//   The rule is KEPT FILES NOBODY OWNS, twinned with the planner and the gate. It used to be
// "keeps a README and no index", which is the rule the planner abandoned for a measured reason:
// an ignored build directory with a README was offered as work while a kept source directory
// without one was passed over in silence. Keeping it here meant the three engines disagreed about
// what the pillar is even for, and the cheapest of them was the one telling the operator whether
// to run it at all.
const indexedDirs = new Set(indexFiles.map((f) => f.slice(0, f.lastIndexOf('/'))))
const dirOfPath = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '')
const underPathIx = (file, prefix) => file === prefix || file.startsWith(`${prefix}/`)
// The declarations, read for what they OWN rather than only for where they live. Malformed
// entries are left to the gate, which refuses them with a message; a sense run reads what it can
// and never fails on a config it is not the authority for.
const indexOwners = indexDecls
  .map((d, i) => (d && typeof d === 'object' && typeof d.file === 'string'
    ? { d, file: configPath(d.file, `${indexSpelling}[${i}].file`), at: `${indexSpelling}[${i}]` }
    : null))
  .filter((x) => x && x.file !== null)
  .map(({ d, file, at }) => ({
    file,
    dir: dirOfPath(file),
    scope: d.scope === 'direct' ? 'direct' : 'recursive',
    extensions: Array.isArray(d.extensions) ? d.extensions.filter((e) => typeof e === 'string') : ['.md'],
    // Canonical, so `"./lib/vendor"` excuses the subtree the planner and the gate excuse. Kept raw
    // here, one engine read an ignore entry as an exclusion and the other read it as nothing.
    ignore: (Array.isArray(d.ignore) ? d.ignore.filter((e) => typeof e === 'string') : [])
      .map((p, j) => configPath(p, `${at}.ignore[${j}]`)).filter((p) => p !== null),
  }))
const indexFileSet = new Set(indexFiles)
// Names only, never contents, whichever way the answer arrives. Git is asked first because it
// already knows a build directory owes nothing; when it cannot answer, the walk IS the answer and
// nothing is excluded. That direction is deliberate and twinned with the planner: the fallback
// offers MORE directories, never fewer, so a missing git can make this noisier and can never
// retire an offer that was owed.
const walkKeptNames = (rel = '') => {
  let entries
  try { entries = readdirSync(rel ? join(target, rel) : target, { withFileTypes: true }) } catch { return [] }
  return entries.flatMap((e) => {
    const child = rel ? `${rel}/${e.name}` : e.name
    if (e.isDirectory()) return e.name === '.git' || e.name === 'node_modules' ? [] : walkKeptNames(child)
    return e.isFile() || e.isSymbolicLink() ? [child] : []
  })
}
/*
 * THE KEPT-FILE UNIVERSE, built the way the gate and the planner build it, because this is the
 * engine that decides whether the pillar is OFFERED at all.
 *
 * It used to be one `git ls-files` split on NUL and nothing else: no gitlink filter, no deleted
 * filter, no lstat. So a submodule and a path staged for deletion both counted as files owing
 * rows here and neither did there, and this sensor reported work the other two engines had
 * already agreed did not exist. Three implementations of one rule, each of which has been the odd
 * one out at least once.
 *
 * The two excluded classes and the one that FAILS CLOSED are the gate's, character for character:
 * a gitlink (mode 160000, another repository's whole content) and an untracked path that vanished
 * between two calls are excluded; a path git tracks that lstat cannot find is NAMED. Reading the
 * listing as BYTES is the other half: a name that is not valid UTF-8 decodes to U+FFFD, which
 * matches no file, and it used to leave the universe with nothing said.
 *
 * There used to be a third exclusion, `git ls-files --deleted`, and it was the wrong rule read
 * from the right instinct. A STAGED deletion needs no exclusion: `git rm` takes the path out of
 * the index, so it never reaches this loop. What `--deleted` reports is "tracked, and not in the
 * worktree", which is the ordinary unstaged `rm` as well, so subtracting it excused exactly the
 * case fail-closed exists for.
 */
const universeErrors = []
const nulRecords = (buf) => {
  const out = []
  let start = 0
  for (let i = 0; i < buf.length; i++) if (buf[i] === 0) { if (i > start) out.push(buf.subarray(start, i)); start = i + 1 }
  if (start < buf.length) out.push(buf.subarray(start))
  return out
}
const decodeName = (rec) => {
  const s = rec.toString('utf8')
  return Buffer.from(s, 'utf8').equals(rec) ? s : null
}
const keptFilesForIndex = (() => {
  if (gitOwnsTarget) {
    try {
      const gitBytes = (args) => execFileSync('git', ['-C', target, ...args], { maxBuffer: 64 * 1024 * 1024, stdio: ['ignore', 'pipe', 'ignore'] })
      const listed = nulRecords(gitBytes(['ls-files', '-z', '--cached', '--others', '--exclude-standard']))
      const cached = new Set(), gitlinks = new Set()
      for (const rec of nulRecords(gitBytes(['ls-files', '-z', '--stage']))) {
        const tab = rec.indexOf(0x09)
        if (tab < 0) continue
        const path = rec.subarray(tab + 1).toString('latin1')
        cached.add(path)
        if (rec.subarray(0, 7).toString('latin1') === '160000 ') gitlinks.add(path)
      }
      const kept = []
      for (const rec of listed) {
        const raw = rec.toString('latin1')
        if (gitlinks.has(raw)) continue
        const name = decodeName(rec)
        if (name === null) {
          universeErrors.push({ path: rec.toString('utf8'), why: 'git tracks this path and its name is not valid UTF-8, so no markdown link can name it and no row can catalogue it' })
          continue
        }
        let st = null
        try { st = lstatSync(join(target, name)) } catch { /* absent: judged immediately below */ }
        // WHAT THE PATH IS NOW, against what git says it is, twinned with the gate and the planner.
        // The listing used to be filtered by one question, "does lstat call this a directory", and a
        // yes was silently dropped: a TRACKED, uncatalogued blob replaced by a DIRECTORY at the same
        // path went from a red build to a green one in all three engines. An UNTRACKED directory is
        // the ordinary case that skip was written for, and it is the only one left in it.
        if (st !== null && st.isDirectory()) {
          if (!cached.has(raw)) continue
          universeErrors.push({ path: name, why: 'git has this path in the index as a FILE (it is not a submodule), and a directory is sitting at it on disk. The blob git tracks cannot be read, catalogued, or held to any coverage rule while a directory occupies its name' })
          continue
        }
        if (st === null) {
          if (!cached.has(raw)) continue
          universeErrors.push({ path: name, why: 'git tracks this path and it is not on disk: either it was deleted without the removal being staged, or a sparse or skip-worktree checkout is hiding it. Either way it is still tracked and still owes a row' })
          continue
        }
        kept.push(name)
      }
      return kept
    } catch { /* fall through to the walk */ }
  }
  return walkKeptNames()
})()
const reachesIx = (ix, f) => (ix.scope === 'direct' ? dirOfPath(f) === ix.dir : underPathIx(f, ix.dir))
const ownedByIndex = (f) => indexOwners.some((ix) => reachesIx(ix, f)
  && !indexFileSet.has(f)
  && (ix.extensions.includes('*') || ix.extensions.some((e) => f.endsWith(e)))
  && !ix.ignore.some((i) => underPathIx(f, i)))
// An `ignore` entry is a recorded decision, the same as a decline one level up.
const ignoredByIndex = (f) => indexOwners.some((ix) => reachesIx(ix, f) && ix.ignore.some((i) => underPathIx(f, i)))
// A directory the operator already turned down is not a candidate. Without this, the only way to
// stop being asked was a repo-wide `ATLAS_OFFER: declined`, which is terminal and suppresses the
// directories that matter along with the leaf nobody wants catalogued. One tiny excluded leaf
// left a whole repo sensing `offer` forever, which is how a real answer became noise.
const declinedIndexDirs = (Array.isArray(docsBlock?.declined) ? docsBlock.declined : [])
  .filter((d) => d && typeof d === 'object' && typeof d.dir === 'string')
  // The raw bytes, twinned with the gate and the planner: trimming before the contract accepted a
  // decline spelled "\nghost" that the gate exits 2 on.
  .map((d, i) => configPath(d.dir, `docs.declined[${i}].dir`))
  .filter((d) => d !== null)
// Dot-directories are excluded for the reason assets.coverage excludes them: they hold tooling a
// reader does not browse.
//   `node_modules` is NOT excluded here, and adding it was the mistake. The exclusion belongs to
// the filesystem WALK, which is a guess about what a repo keeps; once GIT has said a path is kept,
// the guess has been answered and re-applying it overrides the answer. A force-added
// node_modules/kept.js was a red build in the planner and the gate under strict ownership, and this
// engine filtered the directory away and returned strictFailures: 0 and `keep` on the same tree:
// the cheap sensor that decides whether the pillar runs was the one saying nothing was wrong.
const indexCandidates = [...new Set(keptFilesForIndex.map(dirOfPath))]
  .filter(Boolean)
  .filter((d) => !d.split('/').some((seg) => seg.startsWith('.')))
  .filter((d) => !indexedDirs.has(d)
    && !declinedIndexDirs.some((x) => underPathIx(d, x))
    && keptFilesForIndex.some((f) => dirOfPath(f) === d && !indexFileSet.has(f) && !ownedByIndex(f) && !ignoredByIndex(f)))
  .sort()
// An index GitHub does not render when a reader browses the directory, where the conventional
// home is free. Cheap enough for a sense run (one existsSync per declared index) and worth
// knowing here, because the alternative was that nothing surfaced it until someone happened to
// look. What the move actually COSTS is harness/index-plan.mjs, which reads the tree to find
// every inbound reference.
//   Two things stop a move being offered, and both were missed. An index that does not EXIST is
// not sitting in the wrong place, it is missing, and proposing a rename of a file that is not
// there sent one run looking for a page nobody had written yet. And a recorded `retain` is the
// operator's answer to this exact question, so re-asking it is the thing the record exists to
// prevent.
const retainedIndexes = new Set(indexDecls
  .filter((d) => d && typeof d === 'object' && typeof d.file === 'string' && typeof d.retain === 'string' && d.retain.trim())
  .map((d) => d.file))
const indexMigrations = indexFiles
  .filter((f) => existsSync(join(target, f))
    && !retainedIndexes.has(f)
    && f.slice(f.lastIndexOf('/') + 1) !== 'README.md'
    && !existsSync(join(target, f.slice(0, f.lastIndexOf('/')), 'README.md')))
  .map((f) => ({ from: f, to: `${f.slice(0, f.lastIndexOf('/'))}/README.md` }))

// Trust. Whether the committed ignore rules already make a .env unstageable, reported as the
// specific rules that are missing so a plan can propose exactly those and nothing else.
// Through the contract too, and for the same reason: this decides which file the secrets ruleset
// is READ from, so a path that leaves the repo had this engine reporting a sibling checkout's
// rules as the ones protecting the operator's credentials.
const ignoreRaw = configParsed?.ignore
const ignoreTypeBad = ignoreRaw !== undefined && ignoreRaw !== null && (typeof ignoreRaw !== 'object' || Array.isArray(ignoreRaw))
if (ignoreTypeBad) configPathErrors.push({ where: 'ignore', raw: ignoreRaw, why: 'must be an object { file, generated, allowExamples }: its "file" selects which file the secrets ruleset is read from' })
const ignoreObj = ignoreRaw && typeof ignoreRaw === 'object' && !Array.isArray(ignoreRaw) ? ignoreRaw : null
const ignoreFileTypeBad = Boolean(ignoreObj && ignoreObj.file !== undefined && (typeof ignoreObj.file !== 'string' || !ignoreObj.file.trim()))
if (ignoreFileTypeBad) configPathErrors.push({ where: 'ignore.file', raw: ignoreObj.file, why: 'must be a string path: it selects which file the secrets ruleset is read from, and a wrong type silently substituted .gitignore, so a repo could be told its credentials were covered by rules in a file it does not use' })
const ignoreFileDeclared = ignoreTypeBad || ignoreFileTypeBad ? null
  : (ignoreObj && typeof ignoreObj.file === 'string'
    ? configPath(ignoreObj.file, 'ignore.file')
    : configPath('.gitignore', 'ignore.file (the default, in force because the key is not declared)'))
const ignoreFileUsable = ignoreFileDeclared !== null
const ignoreFileRel = ignoreFileDeclared ?? '.gitignore'
const ignoreText = ignoreFileUsable ? readIf(ignoreFileRel) : null
const ignoreLines = ignoreText === null ? [] : ignoreText.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'))
const missingSecretRules = ignoreText === null ? SECRET_RULES.map((r) => r.covers) : SECRET_RULES.filter((r) => !r.accepts.some((a) => ignoreLines.includes(a))).map((r) => r.covers)
// A negation that re-exposes a real .env is worse than a missing rule, because the file looks
// governed. Only the example names may be negated.
const EXAMPLE_NAMES = new Set(['.env.example', '.env.sample', '.env.template', '.env.defaults'])
const reopeningNegations = ignoreLines.filter((l) => l.startsWith('!') && /^!\/?\.env(\.[^/]*)?$/.test(l) && !EXAMPLE_NAMES.has(l.replace(/^!\/?/, '')))

const enforcement = {
  lint: {
    path: LINT_REL,
    // Something being AT the path and this repo COMMITTING it there are two facts, and folding a
    // substitution into "not installed" would have the scaffold write over the link.
    installed: lintText !== null || lintSubstituted,
    ...(lintSubstituted ? { substituted: true } : {}),
    matchesPayload: lintText !== null && payloadText !== null ? sha256(lintText) === sha256(payloadText) : null,
    installedVersion: installedLintVersion,
    payloadVersion: payloadLintVersion,
  },
  config: { path: CONFIG_REL, present: configText !== null, valid: configValid, scaffold: configScaffold },
  ci: { workflows, runsAcceptance: ciRunsAcceptance },
  existingAcceptanceTests: existingTests,
  assets: {
    declared: Boolean(assetsDeclared),
    dir: assetsDir,
    manifest: { path: assetManifestRel, present: manifestText !== null, valid: assetManifestValid, ...(assetCounts ?? {}) },
    generator: {
      path: generatorRel,
      installed: generatorText !== null || generatorSubstituted,
      ...(generatorSubstituted ? { substituted: true } : {}),
      matchesPayload: generatorText !== null && payloadGeneratorText !== null ? sha256(generatorText) === sha256(payloadGeneratorText) : null,
      installedVersion: installedGeneratorVersion,
      payloadVersion: payloadGeneratorVersion,
    },
  },
  prose: {
    declared: Boolean(proseDeclared),
    profile: proseDeclared && typeof configParsed.prose.profile === 'string' ? configParsed.prose.profile : null,
    scan: proseDeclared && typeof configParsed.prose.scan === 'string' ? configParsed.prose.scan : (proseDeclared ? 'docs' : null),
  },
  indexes: {
    declared: indexFiles.length,
    spelling: indexSpelling,
    files: indexFiles,
    candidates: indexCandidates,
    declined: declinedIndexDirs,
    migrations: indexMigrations,
  },
  ignore: {
    path: ignoreFileRel,
    present: ignoreText !== null,
    secretsCovered: missingSecretRules.length === 0 && reopeningNegations.length === 0,
    missingRules: missingSecretRules,
    reopeningNegations,
  },
}

// ---- signals a scaffolder can derive placeholder values from ----
const manifests = {}
const pkgText = readIf('package.json')
if (pkgText) { try { const p = JSON.parse(pkgText); manifests['package.json'] = { name: p.name ?? null, version: p.version ?? null, description: p.description ?? null, license: p.license ?? null, repository: typeof p.repository === 'string' ? p.repository : p.repository?.url ?? null } } catch { manifests['package.json'] = { parseError: true } } }
const cpText = readIf('.claude-plugin/plugin.json')
if (cpText) { try { const p = JSON.parse(cpText); manifests['.claude-plugin/plugin.json'] = { name: p.name ?? null, version: p.version ?? null, description: p.description ?? null, license: p.license ?? null, repository: p.repository ?? null } } catch { manifests['.claude-plugin/plugin.json'] = { parseError: true } } }
const pyText = readIf('pyproject.toml')
if (pyText) manifests['pyproject.toml'] = { version: pyText.match(/^version\s*=\s*"([^"]+)"/m)?.[1] ?? null, name: pyText.match(/^name\s*=\s*"([^"]+)"/m)?.[1] ?? null }
const cargoText = readIf('Cargo.toml')
if (cargoText) manifests['Cargo.toml'] = { version: cargoText.match(/^version\s*=\s*"([^"]+)"/m)?.[1] ?? null, name: cargoText.match(/^name\s*=\s*"([^"]+)"/m)?.[1] ?? null }

const remoteUrl = gitOwnsTarget ? git('remote', 'get-url', 'origin') : null
// the repo's DEFAULT branch, not whatever is checked out: scaffolding happens on a topic branch
// far more often than not, and this value gets baked into docs. In descending order of
// authority — origin/HEAD says it outright; an existing local main/master is strong evidence
// (git itself has no notion of a default without a remote); init.defaultBranch is only a
// preference for NEW repos, so it ranks below real branches; the current branch is the last
// resort and is exactly the wrong answer on a topic branch, hence last.
const branchExists = (b) => git('rev-parse', '--verify', '--quiet', `refs/heads/${b}`) !== null
const defaultBranch = gitOwnsTarget
  ? (git('symbolic-ref', '--short', 'refs/remotes/origin/HEAD')?.replace(/^origin\//, '')
    ?? (branchExists('main') ? 'main' : branchExists('master') ? 'master' : null)
    ?? git('config', '--get', 'init.defaultBranch')
    ?? git('symbolic-ref', '--short', 'HEAD'))
  : null
const gitSignals = {
  isRepo: gitOwnsTarget,
  commitCount: gitOwnsTarget ? Number(git('rev-list', '--count', 'HEAD') ?? 0) : 0,
  defaultBranch,
  remoteUrl,
}

// pick the first manifest that actually PARSED — a broken package.json must not shadow a valid
// pyproject.toml sitting beside it (`??` would stop on the truthy {parseError:true} sentinel).
const manifest = ['.claude-plugin/plugin.json', 'package.json', 'pyproject.toml', 'Cargo.toml']
  .map((k) => manifests[k]).find((m) => m && !m.parseError) ?? null
const repoUrl = remoteUrl ? remoteUrl.replace(/\.git$/, '').replace(/^git@([^:]+):/, 'https://$1/') : null
// a repo "already has a license" when EITHER the manifest declares one or the LICENSE file is a
// recognizable standard text — the manifest field alone misses every LICENSE-file-only repo.
// each arm must key on what DISTINGUISHES its license: the BSD family shares one preamble
// verbatim, so only the third clause separates BSD-3 from BSD-2, and MIT's grant sentence also
// appears in other permissive texts — order and specificity both matter here, because this
// value becomes the {{LICENSE_ID}} a scaffolded repo declares.
const licenseFromFile = licenseText === null ? null
  : /Apache License\s*\n\s*Version 2\.0/.test(licenseText) ? 'Apache-2.0'
  : /GNU GENERAL PUBLIC LICENSE\s*\n\s*Version 3/.test(licenseText) ? 'GPL-3.0'
  : /Mozilla Public License Version 2\.0/.test(licenseText) ? 'MPL-2.0'
  : /Neither the name of the copyright holder|BSD 3-Clause/i.test(licenseText) ? 'BSD-3-Clause'
  : /BSD 2-Clause/i.test(licenseText) ? 'BSD-2-Clause'
  : /^MIT No Attribution\b/m.test(licenseText) ? 'MIT-0'
  : /^MIT License/m.test(licenseText) ? 'MIT'
  : /Redistribution and use in source and binary forms/.test(licenseText) ? 'unrecognized' // some BSD variant; say so rather than guess
  // the bare grant sentence is shared across the MIT family (MIT-0 drops the notice-preservation
  // condition) — claim MIT only when that condition is present too, else say so rather than guess.
  : /Permission is hereby granted, free of charge/.test(licenseText)
    ? (/above copyright notice and this permission notice/i.test(licenseText) ? 'MIT' : 'unrecognized')
  : 'unrecognized'
// tagline fallback: the first paragraph line after the existing README's H1 (the repo already
// states its own tagline on its front page — do not re-ask the operator for it). Read the
// SENSED README — a repo whose README lives in .github/ or docs/ states its tagline there.
const readmeText = artifacts['README.md'].exists ? readIf(artifacts['README.md'].path) : null
let readmeTagline = null
if (readmeText) {
  const h1 = readmeText.match(/^# +.+$/m)
  if (h1) {
    // slice from the match's own position (indexOf would find the H1's text if it also appears
    // earlier in prose), skip the badge/banner run, then strip bold markers rather than
    // splitting on them — `A **fast** parser` must survive whole, not truncate to "A".
    const after = readmeText.slice(h1.index + h1[0].length).split('\n').map((l) => l.trim())
      .filter((l) => l && !l.startsWith('<!--') && !l.startsWith('>')
        && !/^!\[|^\[!\[/.test(l) && !/^<\/?[a-z][^>]*>$/i.test(l) && !/^<img\s/.test(l))[0] || null
    readmeTagline = after ? after.replace(/\*\*/g, '').trim() || null : null
  }
}
const derived = {
  projectName: manifest?.name ?? (repoUrl ? repoUrl.split('/').pop() : null),
  tagline: manifest?.description ?? readmeTagline,
  repoUrl,
  repoSlug: repoUrl ? repoUrl.split('/').slice(-2).join('/') : null,
  licenseId: manifest?.license ?? licenseFromFile,
  defaultBranch: defaultBranch ?? 'main',
}

// ---- classification + plan (deterministic) ----
const docsPresent = DOCS.filter((d) => artifacts[d].exists)
const allDocs = docsPresent.length === DOCS.length && artifacts.LICENSE.exists
// a config the lint cannot parse is not enforcement — the gate is broken, so the repo is not
// governed no matter what else is installed.
const enforced = enforcement.lint.installed && enforcement.config.present && enforcement.config.valid !== false && ciRunsAcceptance
const classification = docsPresent.length === 0 ? 'greenfield' : allDocs && enforced ? 'governed' : 'partial'

const plan = []
for (const doc of [...DOCS, 'LICENSE']) plan.push({ artifact: doc, action: artifacts[doc].exists ? 'audit' : 'scaffold' })
plan.push({ artifact: LINT_REL, action: !enforcement.lint.installed ? 'install' : enforcement.lint.matchesPayload ? 'keep' : lintDrift() })
plan.push({ artifact: CONFIG_REL, action: !enforcement.config.present ? 'install' : enforcement.config.valid === false ? 'repair' : 'audit' })
plan.push({ artifact: '.github/workflows (acceptance gate)', action: ciRunsAcceptance ? 'keep' : 'install' })
// The trust ruleset is part of a scaffold run, because the gate checks it: a governed repo whose
// .env is stageable fails its own lint. Merge, never clobber, and quote every added line.
plan.push({ artifact: `${ignoreFileRel} (secrets ruleset)`, action: enforcement.ignore.secretsCovered ? 'keep' : ignoreText === null ? 'install' : 'merge' })
// The other three pillars are OFFERS. `offer` means the repo has not adopted this and the
// operator has to be asked; a scaffold run must never decide on its own that someone wants
// generated artwork, a new writing standard imposed on everything they have already written, or
// a fan-out reading their whole repository.
//
// `declined` is the third state, and it matters as much as the other two: an operator who said
// no once has answered the question, and a plan that kept saying `offer` would have the agent
// re-asking every session while the skill's own rule says not to. The recorded answer is what
// makes a no durable, so it is read here rather than left to whoever remembers the rule.
const declined = (key) => configScaffold?.answers?.[key] === 'declined'
plan.push({
  artifact: generatorRel,
  action: !assetsDeclared && generatorText === null
    ? (declined('IDENTITY_OFFER') ? 'declined' : 'offer')
    : generatorText === null ? 'install' : enforcement.assets.generator.matchesPayload ? 'keep' : generatorDrift(),
})
plan.push({
  artifact: 'prose profile (.repo-standard.json)',
  action: proseDeclared ? 'keep' : declined('PROSE_OFFER') ? 'declined' : 'offer',
})
// The atlas, on the same three states, with one difference the other pillars do not have:
// adoption is not binary. Identity is installed or it is not; a writing profile is on or it is
// not. A repo can declare one index over `docs/` and leave nine directories full of files nobody
// has described, and `keep` on that repo means the pillar is never offered again where it has the
// most to add. So an undeclared directory holding kept files nobody owns is an OFFER too, whether
// or not it keeps a README, and `keep` is reserved for a tree with nothing left to cover.
//   Without this entry at all the scaffold could record `ATLAS_OFFER: declined` and nothing
// would ever read it back, so a durable no would quietly become a question asked every session.
// An index sitting where a reader browsing the directory never finds it is an OFFER too, for the
// same reason: `keep` on that repo means the move is never proposed on exactly the tree that
// would benefit. A whole conversion was missed this way, because a structurally complete index
// in the wrong place looked, from here, like a finished one.
//   Nothing left to offer is not always `keep`. A repo that declared no index and turned down
// every directory it was asked about has ANSWERED, and reporting `offer` on it put the skill back
// at a question the config already settles: a recorded no that produces the same prompt as no
// answer at all is not a record, it is a comment.
//   And `keep` is not a verdict this can reach from candidates and migrations alone. A repo
// running `"docs.ownership": "strict"` with a file no declaration speaks for is a repo whose
// build is RED, and this reported `keep` on it: the two engines that decide the build agreed it
// was broken while the sensor that decides whether to offer the pillar said there was nothing
// to do. Ownership is the third input, and it is the one that carries the exit code.
const unownedUnderIndex = keptFilesForIndex.filter((f) => !indexFileSet.has(f)
  && !ownedByIndex(f) && !ignoredByIndex(f)
  && indexOwners.some((ix) => underPathIx(f, ix.dir))
  && !declinedIndexDirs.some((d) => underPathIx(f, d)))
// Whether turning strict ON would leave this repo green. The mode was never offered to a repo
// already sitting at zero, so a `declared` adopter with a complete atlas was never told the one
// setting that turns it into a check: the journey only reached the offer when Atlas happened to
// run for some other reason.
const ownershipMode = docsBlock?.ownership === 'strict' ? 'strict' : 'declared'
// A universe error is a STRICT FAILURE, because the gate treats it as one: RS-index (universe)
// runs whenever an index is declared or ownership is strict, and it fails. Leaving it out here
// meant strictFailures said 0 on a repo whose build was red.
const strictFailures = ownershipMode === 'strict'
  ? unownedUnderIndex.length + indexCandidates.length + universeErrors.length
  : 0
// A universe this engine could not fully see is not a universe strict can be turned on over: the
// files it lost are exactly the ones strict exists to catch.
const strictReady = !unownedUnderIndex.length && !indexCandidates.length && !universeErrors.length
const atlas = {
  ownership: ownershipMode,
  unowned: unownedUnderIndex.length,
  unownedFiles: unownedUnderIndex.slice(0, 12),
  candidates: indexCandidates,
  migrations: indexMigrations.map((m) => m.from),
  universeErrors,
  // Under strict these are build failures the gate is already reporting; under declared they are
  // the distance to being able to turn it on.
  strictFailures,
  strictReady,
  strictAvailable: ownershipMode === 'declared' && strictReady && indexFiles.length > 0,
  note: ownershipMode === 'strict'
    ? 'every kept file under a declared index owes one owner, an ignore entry, or a recorded decline, and the gate fails on the ones that do not. Files at the repo root and under dot-directories sit outside the model in both modes.'
    : 'coverage is held only as far as each "extensions" list reaches. "docs.ownership": "strict" is what turns the remainder into a build failure.',
}
const atlasNothingLeft = !indexCandidates.length && !indexMigrations.length && !strictFailures
/*
 * WHAT AN ADOPTED ATLAS STILL OWES, which `keep` could not say.
 *
 * `keep` meant "structurally finished", and the scaffold reads it as "nothing to do here". So a
 * repo that had every row written, every directory decided, and every migration answered was
 * reported finished while running under `declared` ownership: the mode in which a file added
 * tomorrow is NOT a build failure. `strictAvailable` was computed, printed, and routed nowhere,
 * so the only way the offer ever reached an operator was somebody invoking Atlas by hand for a
 * different reason. The setting that turns this pillar from a description into a check was the
 * one thing the plan could not ask for.
 *
 * Two further actions, both terminal-answerable like every other offer here:
 *   offer-strict    everything is covered and `declared` is still the mode. One config line.
 *   offer-coverage  nothing STRUCTURAL is left, and files inside an indexed directory are still
 *                   unowned, so strict cannot be turned on yet. The gap is the offer.
 * `ATLAS_STRICT_OFFER: declined` is the recorded no, and it reads as `keep` from then on: under
 * `declared` the operator's extension lists ARE their answer for the remainder, and re-asking a
 * settled question is the failure docs.declined exists to prevent one level up.
 */
const atlasAdoptedAction = () => {
  if (ownershipMode === 'strict') return 'keep'
  if (declined('ATLAS_STRICT_OFFER')) return 'keep'
  return atlas.strictAvailable ? 'offer-strict' : 'offer-coverage'
}
/*
 * A UNIVERSE THIS ENGINE COULD NOT SEE BEATS EVERY OTHER ANSWER, and it used to beat none of them.
 *
 * `universeErrors` was computed here, printed here, and then left out of every routing decision:
 * `strictFailures` excluded it, so a skip-worktree entry (or an unstaged deletion, once the
 * `--deleted` subtraction went) returned `keep` under strict and `offer-coverage` under declared,
 * on a tree where the planner exited 1 and the gate's RS-index (universe) was red. The cheap
 * engine that decides whether the pillar runs at all was the one saying there was nothing wrong.
 *
 * Atlas cannot price, sweep or reconcile a tree it cannot enumerate: every count it would produce
 * is a statement about a smaller repo than the one git tracks. So this is terminal, and Scaffold
 * stops on it rather than choosing between offers computed from a set with holes in it.
 */
plan.push({
  artifact: 'per-directory indexes (.repo-standard.json)',
  action: universeErrors.length ? 'blocked-universe'
    : indexFiles.length && atlasNothingLeft ? atlasAdoptedAction()
      : declined('ATLAS_OFFER') ? 'declined'
        : atlasNothingLeft && declinedIndexDirs.length ? 'declined'
          : 'offer',
})
// A configured path this engine refused is the same class of stop, one level up: the config is
// what every action here is computed FROM, so an unusable key makes the config the thing to fix
// before any of it can be trusted. Reported on the config's own plan entry, which the scaffold
// journey already reads, and never silently folded into a confident answer about a pillar.
if (configPathErrors.length) {
  const cfgEntry = plan.find((p) => p.artifact === CONFIG_REL)
  if (cfgEntry) cfgEntry.action = 'repair'
  for (const p of plan) {
    if (p.artifact === generatorRel && !assetsDirUsable) p.action = 'blocked-config'
    if (p.artifact === `${ignoreFileRel} (secrets ruleset)` && !ignoreFileUsable) p.action = 'blocked-config'
  }
}
/*
 * A SUBSTITUTED PATH IS THE THIRD TERMINAL STOP, beside blocked-universe and blocked-config.
 *
 * A file that is not a regular file at the path it is named by is not this repo's file, whatever it
 * resolves to. `keep` on a symlinked gate said the opposite in the one word the scaffold reads as
 * "nothing to do here", so the action has to change and not merely gain a note beside it.
 */
const BLOCKED_LINK = 'blocked-link'
// The manifest is the identity artifact's declaration, so it stops the identity entry: the plan has
// one row per artifact, and the generator's row is the one the scaffold reads before running it.
const blockedArtifactFor = (rel) => (rel === generatorRel || rel === assetManifestRel ? generatorRel
  : DOCS.includes(rel.split('/').pop()) && !rel.includes('/assets/') ? rel.split('/').pop()
    : rel)
for (const s of substitutions) {
  const entry = plan.find((p) => p.artifact === blockedArtifactFor(s.path))
  if (entry) entry.action = BLOCKED_LINK
}

const report = { target, classification, configPathErrors, substitutions, artifacts, enforcement, signals: { git: gitSignals, manifests }, derived, atlas, plan }

if (asJson) {
  console.log(JSON.stringify(report, null, 2))
} else {
  console.log(`sense-state: ${target}`)
  console.log(`  classification: ${classification}`)
  // First, because every line under it is computed FROM the config, and a key this engine refused
  // to follow is a key whose answers below are missing rather than negative.
  for (const e of configPathErrors) {
    console.log(`  ! ${CONFIG_REL} "${e.where}" ${e.why} (got ${JSON.stringify(e.raw)}). This engine did NOT read, hash or route it; the gate and the planner both exit 2 on it`)
  }
  // Beside them, and for the same reason: a path whose content this repo does not commit is a path
  // nothing below can honestly describe.
  for (const s of substitutions) {
    console.log(`  ! ${s.path} is ${s.kind}, not a regular file, and ${s.what}. Nothing about its content is claimed here: a link reads through to bytes committed somewhere else, and the plan action for it is ${BLOCKED_LINK}`)
  }
  for (const doc of [...DOCS, 'LICENSE']) {
    const a = artifacts[doc]
    const notes = [
      a.exists && a.hasH1 === false ? '(no H1)' : null,
      a.exists && a.path && a.path !== doc ? `(at ${a.path})` : null,
      a.exists && a.duplicates ? `(DUPLICATE: also at ${a.duplicates.join(', ')} — one governed copy only; the lint's RS-shadow reddens on this)` : null,
    ].filter(Boolean)
    console.log(`  ${a.exists ? '●' : '○'} ${doc}${notes.length ? '  ' + notes.join(' ') : ''}`)
  }
  const lintNote = !enforcement.lint.installed ? ''
    : enforcement.lint.matchesPayload ? ' (matches payload)'
    : ` (DIFFERS from payload — ${lintDrift()}: installed ${installedLintVersion ?? 'unversioned'}, payload ${payloadLintVersion ?? 'unversioned'})`
  console.log(`  ${enforcement.lint.installed ? '●' : '○'} ${LINT_REL}${lintNote}`)
  if (enforcement.lint.installed && !enforcement.lint.matchesPayload && lintDrift() === 'downgrade') {
    console.log(`  ! STALE PLUGIN: the installed plugin's payload (${payloadLintVersion}) is OLDER than the lint governing this repo (${installedLintVersion}) — replacing would downgrade the committed gate; update the plugin instead`)
  }
  console.log(`  ${enforcement.config.present ? '●' : '○'} ${CONFIG_REL}${enforcement.config.valid === false ? ' (INVALID JSON)' : ''}${configScaffold?.pluginVersion ? ` (scaffolded by plugin ${configScaffold.pluginVersion})` : ''}`)
  console.log(`  ${ciRunsAcceptance ? '●' : '○'} CI acceptance gate${workflows.length ? ` (workflows: ${workflows.join(', ')})` : ''}`)
  const ignoreNote = !enforcement.ignore.present ? '(no ignore file)'
    : enforcement.ignore.secretsCovered ? '(a .env cannot be staged)'
    : `(NOT covered: ${[...enforcement.ignore.missingRules.map((r) => `no rule for ${r}`), ...enforcement.ignore.reopeningNegations.map((n) => `"${n}" re-exposes it`)].join('; ')})`
  console.log(`  ${enforcement.ignore.secretsCovered ? '●' : '○'} ${ignoreFileRel} secrets ruleset ${ignoreNote}`)
  const genNote = generatorText === null ? '' : enforcement.assets.generator.matchesPayload
    ? ' (matches payload)'
    : ` (DIFFERS from payload — ${generatorDrift()}: installed ${installedGeneratorVersion ?? 'unversioned'}, payload ${payloadGeneratorVersion ?? 'unversioned'})`
  console.log(`  ${generatorText !== null ? '●' : '○'} identity assets${genNote}${manifestText !== null ? ` (manifest: ${assetCounts ? `${assetCounts.banners} banner(s), ${assetCounts.pills} pill(s), palette ${assetCounts.paletteKind ?? 'unrecorded'}` : 'INVALID JSON'})` : ''}`)
  if (generatorText !== null && !enforcement.assets.generator.matchesPayload && generatorDrift() === 'downgrade') {
    console.log(`  ! STALE PLUGIN: the installed generator payload (${payloadGeneratorVersion}) is OLDER than the one this repo renders with (${installedGeneratorVersion}) — replacing would regress the artwork; update the plugin instead`)
  }
  console.log(`  ${proseDeclared ? '●' : '○'} writing profile${proseDeclared ? ` (${enforcement.prose.profile}, scanning ${enforcement.prose.scan})` : ' (none declared: the marketing-voice ban still applies)'}`)
  console.log(`  ${indexFiles.length ? '●' : '○'} per-directory indexes${indexFiles.length ? ` (${indexFiles.length} declared under ${indexSpelling}: ${indexFiles.join(', ')})` : ' (none declared: no directory says what each file in it is for)'}`)
  if (indexCandidates.length) {
    console.log(`    ! ${indexCandidates.length} more director${indexCandidates.length === 1 ? 'y holds' : 'ies hold'} kept files no index speaks for: ${indexCandidates.join(', ')}`)
  }
  if (declinedIndexDirs.length) {
    console.log(`    ${declinedIndexDirs.length} director${declinedIndexDirs.length === 1 ? 'y was' : 'ies were'} offered one and declined, recorded in docs.declined: ${declinedIndexDirs.join(', ')}`)
  }
  if (indexFiles.length) {
    console.log(`    ownership: ${atlas.ownership}${atlas.unowned ? ` — ${atlas.unowned} kept file(s) under a declared index that no declaration speaks for: ${atlas.unownedFiles.join(', ')}${atlas.unowned > atlas.unownedFiles.length ? `, and ${atlas.unowned - atlas.unownedFiles.length} more` : ''}` : ' — every kept file under a declared index has an owner, an ignore entry, or a recorded decline'}`)
    if (atlas.strictFailures) console.log(`    ! "docs.ownership" is "strict", so the gate is FAILING on ${atlas.strictFailures} of those; the atlas skill is what closes them`)
    if (atlas.strictAvailable) console.log('    ! this repo would pass "docs.ownership": "strict" today, and does not declare it. That is the setting that turns "a file added tomorrow reddens the build" from a description into a check. Plan action: offer-strict')
    else if (ownershipMode === 'declared' && indexFiles.length && atlasNothingLeft && !declined('ATLAS_STRICT_OFFER')) {
      console.log(`    ! every index is structurally complete and "docs.ownership" is still "declared", because ${atlas.unowned} kept file(s) inside an indexed directory are owned by no declaration. Closing those is what makes strict available. Plan action: offer-coverage`)
    }
  }
  // OUTSIDE the "an index is declared" branch, because a universe error is a fact about the tree
  // rather than about a declaration: a repo running strict with no index yet has exactly the same
  // hole, and this printed nothing at all on it.
  for (const e of atlas.universeErrors) console.log(`  ! ${e.path}: ${e.why}`)
  if (atlas.universeErrors.length) {
    console.log(`  ! ${atlas.universeErrors.length} path(s) git keeps cannot enter the coverage universe, so every atlas count above is about a smaller repo than the one git tracks. Plan action: blocked-universe, and the atlas skill must not run until each one is resolved`)
  }
  for (const m of indexMigrations) {
    console.log(`    ! ${m.from} is not the page GitHub renders when a reader browses that directory, and ${m.to} is free`)
  }
  console.log('  plan:')
  for (const p of plan) console.log(`    ${p.action.padEnd(8)} ${p.artifact}`)
}
