#!/usr/bin/env node
/*
 * preview-assets.mjs — render the proposed identity to one self-contained page, before a single
 * byte lands in anyone's repo.
 *
 * Nobody should have to approve a palette from a column of hex values. This engine takes a
 * manifest and the generator that renders it, and writes an HTML page showing exactly what the
 * README will show: the root banner, every folder banner, the pill row, any live badge, the
 * palette with each role's job named, and the measured contrast of every pair the lint enforces.
 * Each asset is embedded as its own image, the way GitHub serves it, so what the operator
 * approves is what they will get.
 *
 * Live badges are the one thing this page cannot draw. They are rendered by img.shields.io when
 * a reader loads the README, and this engine takes no network, so a remote <img> would either
 * fail to load or make an approval depend on someone else's uptime. What is shown instead is the
 * exact markdown line the README will carry, the URL it resolves to, and the two plate colours
 * the palette sets. Approving a line you can read beats approving an image that may not arrive.
 *
 * The page is written wherever --out says, which the skill points OUTSIDE the repo. Previewing
 * is not scaffolding: an identity nobody has approved yet has no business in the tree.
 *
 * Usage:
 *   node harness/preview-assets.mjs --manifest <path> --out <file.html> [--generator <path>]
 *
 * --generator defaults to generate.mjs beside the manifest. Dependency-free: Node built-ins
 * only. Exit 0 written · 2 refused (nothing written).
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const ROLE_JOBS = {
  groundDeep: 'gradient stop 0, the deepest corner',
  groundMid: 'gradient stop 0.45, the lift through the middle',
  ground: 'gradient stop 1, and the pill label plate',
  waveNear: 'the near wave band along the bottom edge',
  waveFar: 'the far band, counter-scrolling against it',
  text: 'headline text on the ground',
  textMuted: 'subtitle and pill-label text',
  rim: 'the hairline grid stroke',
  accent: 'prism-bar start, first orb',
  accentAlt: 'prism-bar end, eyebrow, third orb',
  accentSoft: 'the large background orb',
  pillAccentBg: 'pill scheme "accent", value plate',
  pillAccentFg: 'pill scheme "accent", value text',
  pillAltBg: 'pill scheme "alt", value plate',
  pillAltFg: 'pill scheme "alt", value text',
}
const CONTRAST_PAIRS = [['text', 'ground'], ['text', 'groundMid'], ['text', 'groundDeep'],
  ['textMuted', 'ground'], ['textMuted', 'groundMid'], ['accentAlt', 'ground'], ['accentAlt', 'groundMid'],
  ['pillAccentFg', 'pillAccentBg'], ['pillAltFg', 'pillAltBg']]
const FLOOR = 4.5

const fail = (msg) => { console.error(`preview-assets: ${msg}`); process.exit(2) }

const args = process.argv.slice(2)
let manifestPath = null, generatorPath = null, out = null
const take = (flag, i) => {
  const v = args[i]
  if (v === undefined || v.startsWith('--')) fail(`${flag} expects a value, got "${v ?? '<end of arguments>'}"`)
  return v
}
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--manifest') manifestPath = take('--manifest', ++i)
  else if (args[i] === '--generator') generatorPath = take('--generator', ++i)
  else if (args[i] === '--out') out = take('--out', ++i)
  else fail(`unknown argument "${args[i]}"`)
}
if (!manifestPath) fail('--manifest is required')
if (!out) fail('--out is required (point it outside the repo: previewing is not scaffolding)')
manifestPath = resolve(manifestPath)
if (!existsSync(manifestPath)) fail(`manifest not found: ${manifestPath}`)
generatorPath = resolve(generatorPath ?? join(dirname(manifestPath), 'generate.mjs'))
if (!existsSync(generatorPath)) fail(`generator not found: ${generatorPath} (pass --generator to point elsewhere)`)

let manifest
try { manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) } catch (e) { fail(`${manifestPath} is not valid JSON: ${e.message}`) }

let mod
try { mod = await import(pathToFileURL(generatorPath).href) } catch (e) { fail(`cannot import ${generatorPath}: ${e.message}`) }
if (typeof mod.render !== 'function') fail(`${generatorPath} does not export render(manifest)`)

let rendered
try { rendered = mod.render(manifest) } catch (e) { fail(`the generator could not render this manifest: ${e.message}`) }

// ── contrast, measured the same way the lint measures it ──────────────────────────────────
const luminance = (hex) => {
  const h = String(hex).replace('#', '')
  const parts = h.length === 3 ? [...h].map((c) => c + c) : [h.slice(0, 2), h.slice(2, 4), h.slice(4, 6)]
  const [r, g, b] = parts.map((p) => parseInt(p, 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
const contrast = (a, b) => {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x)
  return (hi + 0.05) / (lo + 0.05)
}

const esc = (s) => String(s).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;')
// Each asset is embedded as its own image rather than inlined into the page, which is both how
// GitHub serves it and the only way several SVGs that share element ids can render correctly
// side by side.
const dataUri = (svg) => `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`
const imgOf = (rel, alt) => `<img src="${dataUri(rendered[rel])}" alt="${esc(alt)}">`

const palette = manifest.brand?.palette ?? {}
const homepage = manifest.brand?.homepage ?? ''
const h1For = (title, desc, to) => (typeof mod.bannerH1 === 'function' ? mod.bannerH1({ title, desc, to, homepage }) : '')
// The arrangement, in the same placeholder form the H1 lines use: the assets directory is
// relative to the README that will carry the block, and this page does not know where that is.
const blockFor = () => (typeof mod.readmeBlock === 'function' ? mod.readmeBlock(manifest, { assets: '<relative path>' }) : '')

const swatches = Object.keys(ROLE_JOBS).map((role) => `
    <tr>
      <td><span class="chip" style="background:${esc(palette[role] ?? '#000')}"></span></td>
      <td><code>${role}</code></td>
      <td><code>${esc(palette[role] ?? '')}</code></td>
      <td>${ROLE_JOBS[role]}</td>
    </tr>`).join('')

const contrastRows = CONTRAST_PAIRS.map(([fg, bg]) => {
  const r = contrast(palette[fg] ?? '#000', palette[bg] ?? '#fff')
  return `
    <tr class="${r >= FLOOR ? 'ok' : 'bad'}">
      <td><code>${fg}</code> on <code>${bg}</code></td>
      <td class="num">${r.toFixed(2)}:1</td>
      <td>${r >= FLOOR ? 'clears the floor' : `below the ${FLOOR}:1 floor, the lint will refuse this`}</td>
    </tr>`
}).join('')

const folderBanners = (manifest.banners ?? []).map((b) => `
    <figure>
      ${imgOf(`banners/${b.slug}.svg`, `${b.title}: ${b.desc}`)}
      <figcaption>${b.dir ? `<code>${esc(b.dir)}/README.md</code>` : `<em>no directory declared</em>`}${b.dir ? `<br><code class="h1">${esc(h1For(b.title, b.desc, `<relative path>/banners/${b.slug}.svg`))}</code>` : ''}</figcaption>
    </figure>`).join('')

const pillRow = (manifest.pills ?? []).map((p) => `<span class="pill">${imgOf(`pills/${p.file}`, `${p.label}: ${p.value}`)}<br><small>${esc(p.file)}${p.source === false ? ' · unverifiable' : ''}</small></span>`).join('')

// The live badges, in the only honest form a network-free page can show them: the README line
// itself, the resolved URL behind it, and the two plate colours as swatches.
const plate = (role, job) => `<span class="plate"><span class="chip" style="background:${esc(palette[role] ?? '#000')}"></span><code>${role}</code> ${job} <code>${esc(palette[role] ?? '')}</code></span>`
const badgeRows = (manifest.badges ?? []).map((b) => {
  const md = typeof mod.badgeMarkdown === 'function' ? mod.badgeMarkdown(manifest, b) : ''
  const url = typeof mod.badgeUrl === 'function' ? mod.badgeUrl(palette, b) : ''
  return `
    <figure>
      <figcaption><strong>${esc(b.label)}</strong> · links to <code>${esc(b.href ?? '')}</code></figcaption>
      <code class="h1">${esc(md)}</code>
      <p class="plates">${plate('ground', 'label plate')}${plate('pillAccentBg', 'value plate')}</p>
      <figcaption>drawn by <code>${esc(url)}</code> at the moment a reader opens the page</figcaption>
    </figure>`
}).join('')

const page = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Identity preview: ${esc(manifest.brand?.name ?? 'repo')}</title>
<style>
  :root { color-scheme: light dark; }
  body { margin: 0; padding: 2rem clamp(1rem, 4vw, 3rem); font: 15px/1.6 ui-sans-serif, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
  h1 { font-size: 1.4rem; margin: 0 0 .25rem; }
  h2 { font-size: 1rem; text-transform: uppercase; letter-spacing: .08em; margin: 2.5rem 0 .75rem; opacity: .7; }
  p.lede { margin: 0 0 2rem; opacity: .75; max-width: 70ch; }
  figure { margin: 0 0 1.5rem; }
  img { max-width: 100%; height: auto; display: block; border-radius: 10px; }
  figcaption { font-size: .82rem; opacity: .75; margin-top: .5rem; }
  code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: .85em; }
  code.h1 { display: block; margin-top: .35rem; padding: .4rem .6rem; border-radius: 6px; background: rgba(127,127,127,.14); overflow-x: auto; white-space: pre; }
  .surface { padding: 1.5rem; border-radius: 12px; margin-bottom: 1rem; }
  .light { background: #ffffff; } .dark { background: #0d1117; }
  .surface small { display: block; margin-bottom: .75rem; opacity: .6; font-size: .75rem; letter-spacing: .06em; text-transform: uppercase; }
  .light small { color: #24292f; } .dark small { color: #c9d1d9; }
  .pills { display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-start; justify-content: center; }
  .pill { text-align: center; font-size: .7rem; opacity: .8; }
  .pill img { border-radius: 4px; }
  table { border-collapse: collapse; width: 100%; max-width: 900px; }
  td, th { text-align: left; padding: .35rem .6rem; border-bottom: 1px solid rgba(127,127,127,.22); vertical-align: top; }
  td.num { font-variant-numeric: tabular-nums; }
  .chip { display: inline-block; width: 1.4rem; height: 1.4rem; border-radius: 4px; border: 1px solid rgba(127,127,127,.4); vertical-align: middle; }
  .plates { display: flex; flex-wrap: wrap; gap: 1.25rem; margin: .6rem 0 .25rem; font-size: .82rem; opacity: .8; }
  .plate { display: inline-flex; align-items: center; gap: .4rem; }
  tr.bad td { color: #b91c1c; font-weight: 600; }
  @media (prefers-color-scheme: dark) { tr.bad td { color: #fca5a5; } }
  .scroll { overflow-x: auto; }
</style>
</head>
<body>
<h1>Identity preview: ${esc(manifest.brand?.name ?? 'repo')}</h1>
<p class="lede">Rendered from <code>${esc(manifestPath)}</code> by <code>${esc(generatorPath)}</code>. Nothing has been written into the repository. The banners animate exactly as they will on GitHub, shown here on both of GitHub's page backgrounds.</p>

<h2>Root banner</h2>
<div class="surface light"><small>GitHub light</small>${imgOf('banner.svg', `${manifest.brand?.name}: ${manifest.brand?.tagline}`)}</div>
<div class="surface dark"><small>GitHub dark</small>${imgOf('banner.svg', `${manifest.brand?.name}: ${manifest.brand?.tagline}`)}</div>
<code class="h1">${esc(h1For(manifest.brand?.name, manifest.brand?.tagline, '<relative path>/banner.svg'))}</code>

<h2>Pill row</h2>
<p class="lede">Centred under the banner, which is what the generated block does with them. A pill that declares no <code>href</code> renders as a bare image rather than linking somewhere invented.</p>
<div class="surface light"><small>GitHub light</small><div class="pills">${pillRow || '<em>no pills declared</em>'}</div></div>
<div class="surface dark"><small>GitHub dark</small><div class="pills">${pillRow || '<em>no pills declared</em>'}</div></div>

<h2>The block, as the README will carry it</h2>
<p class="lede">The generator emits this whole thing and the lint compares it byte for byte, so the arrangement cannot drift the way a hand-written badge row does. Paste it whole.</p>
<code class="h1">${esc(blockFor()) || '<em>this generator predates readmeBlock()</em>'}</code>

<h2>Live badges (${(manifest.badges ?? []).length})</h2>
${badgeRows ? `<p class="lede">These sit on their own line under the pill row. A third party draws them when a reader opens the page, so this preview shows the exact line the README will carry rather than a picture it would have to fetch. Two limits, both stated rather than designed around: a third-party renderer will never be pixel-identical to the local pills, so the family resemblance is the colour and the label rather than the height, and a live badge always takes the accent scheme because shields draws its value text white.</p>${badgeRows}` : '<p><em>none declared</em></p>'}

<h2>Folder banners (${(manifest.banners ?? []).length})</h2>
${folderBanners || '<p><em>none declared</em></p>'}

<h2>Palette</h2>
<div class="scroll"><table>${swatches}</table></div>

<h2>Contrast</h2>
<div class="scroll"><table><tr><th>pair</th><th>ratio</th><th></th></tr>${contrastRows}</table></div>
</body>
</html>
`

try {
  mkdirSync(dirname(resolve(out)), { recursive: true })
  writeFileSync(resolve(out), page)
} catch (e) {
  fail(`cannot write ${out}: ${e.message}`)
}
console.log(`preview-assets: wrote ${resolve(out)} (${Object.keys(rendered).length} asset(s); nothing written into the repo)`)
