#!/usr/bin/env node
/*
 * voice-scan.mjs: the read-only finder behind the guided prose sweep.
 *
 * The lint's RS-prose answers one question, "is this repo clean?", and answers it with a single
 * failure because that is what a gate is for. Bringing an EXISTING repo up to the standard needs
 * the opposite shape: every hit at once, grouped by file, with enough context to rewrite each
 * sentence without opening it blind. That is this engine. The agent rewrites, the operator
 * approves, and the committed lint locks the result.
 *
 * The rule lists here are a deliberate TWIN of the ones in payload/acceptance/test-repo-standard.mjs
 * (the lint ships as one self-contained file into target repos, so it cannot import a shared
 * module). A standing test parses both files and fails the build if the two ever disagree: a
 * sweep that fixes a different set of rules than the gate enforces is worse than no sweep.
 *
 * READ-ONLY by design: it never edits, never writes, and never reads the clock. It reports what
 * a scan of the tree finds, and reporting is all it does.
 *
 * Usage:
 *   node harness/voice-scan.mjs [--target <dir>] [--scan docs|markdown|all]
 *                              [--json] [--summary] [--files-only] [--file <path>] [--limit <n>]
 *
 * --scan defaults to the target's own `prose.scan` when .repo-standard.json declares one, and
 * to `docs` otherwise, so a pre-adoption sweep looks exactly where adoption will look.
 *
 * Output size is the reason for the last four flags. A wide reach produces tens of thousands of
 * lines, and an agent harness truncates from the tail, which is where a report normally puts its
 * total. So: the totals line prints FIRST as well as last, the JSON carries a `counts` block
 * BEFORE its `hits` array, `--summary` emits the counts alone (cheap enough to price all three
 * reaches before the operator picks one), `--files-only` emits the file/count table that a
 * worst-first sweep actually orders by, and `--file` re-reads one file at a time. `--limit` caps
 * the hits reported per file and is OFF by default: a silent cap turns a loud truncation into a
 * quiet wrong answer, so when it is on, the count it dropped is stated in both forms.
 *
 * Dependency-free: Node built-ins only. Exit 0 clean · 1 hits found · 2 bad invocation.
 */
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'

// ── the canon, twinned with the lint ──────────────────────────────────────────────────────
const PROSE_DASHES = [
  { label: 'em dash', re: /\u2014/, fix: 'rewrite with a colon, a comma, parentheses, or a full stop' },
  { label: 'em dash escape', re: /&(?:mdash;|#8212;|#[xX]2014;)/, fix: 'the escape renders as an em dash; rewrite the sentence' },
  { label: 'spaced en dash', re: /\s\u2013|\u2013\s/, fix: 'an en dash with a space around it is an em dash wearing a hat; rewrite, or close it up if it is a range' },
]
const PROSE_FILLER = ['delve', 'utilize', 'leverage', 'in order to', 'worth noting', 'it should be noted',
  'needless to say', 'as you can see', 'furthermore', 'moreover', 'a wide range of', 'a variety of', 'state-of-the-art']
const PROSE_SCANS = ['docs', 'markdown', 'all']
const WALK_SKIP_DIRS = new Set(['.git', 'node_modules'])
const LICENSE_CANDIDATES = ['LICENSE', 'LICENSE.md', 'LICENSE.txt', 'LICENCE', 'LICENCE.md', 'LICENCE.txt', 'COPYING', 'COPYING.md', 'COPYING.txt', 'UNLICENSE']
const FENCE_LINE = /^\s*(?:```|~~~)/

const fail = (msg) => { console.error(`voice-scan: ${msg}`); process.exit(2) }

// ── argv ──────────────────────────────────────────────────────────────────────────────────
const args = process.argv.slice(2)
let target = '.', scanArg = null, asJson = false, summaryOnly = false, filesOnly = false, oneFile = null, limit = 0
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--target') target = args[++i] || fail('--target expects a directory')
  else if (args[i] === '--scan') scanArg = args[++i] || fail('--scan expects one of ' + PROSE_SCANS.join(', '))
  else if (args[i] === '--json') asJson = true
  else if (args[i] === '--summary') summaryOnly = true
  else if (args[i] === '--files-only') filesOnly = true
  else if (args[i] === '--file') oneFile = args[++i] || fail('--file expects a path relative to the target')
  else if (args[i] === '--limit') {
    const raw = args[++i]
    if (!/^\d+$/.test(raw ?? '')) fail('--limit expects a whole number (0 means no cap, which is the default)')
    limit = Number(raw)
  } else fail(`unknown argument "${args[i]}"`)
}
target = resolve(target)
if (!existsSync(target) || !statSync(target).isDirectory()) fail(`target is not a directory: ${target}`)
if (scanArg !== null && !PROSE_SCANS.includes(scanArg)) fail(`--scan must be one of ${PROSE_SCANS.join(', ')} (got "${scanArg}")`)

const read = (rel) => readFileSync(join(target, rel), 'utf8').replace(/^\ufeff/, '')
const exists = (rel) => existsSync(join(target, rel))

// ── the repo's declared scope, when it has one ────────────────────────────────────────────
let config = {}
if (exists('.repo-standard.json')) {
  try { config = JSON.parse(read('.repo-standard.json')) } catch { config = {} }
}
const prose = (config.prose && typeof config.prose === 'object') ? config.prose : {}
// The profile NAME is reported, not assumed. `enterprise` is the only one the lint accepts today,
// so hardcoding it was correct and would have quietly become a false report the day a second one
// landed: a scanner that names the wrong profile tells a repo it was held to a standard it was not.
const profileName = typeof prose.profile === 'string' && prose.profile.trim() ? prose.profile.trim() : 'enterprise'
const scan = scanArg ?? (PROSE_SCANS.includes(prose.scan) ? prose.scan : 'docs')
const docsCfg = config.docs && typeof config.docs === 'object' ? config.docs : {}
const DOC = {
  readme: typeof docsCfg.readme === 'string' ? docsCfg.readme : 'README.md',
  changelog: typeof docsCfg.changelog === 'string' ? docsCfg.changelog : 'CHANGELOG.md',
  conventions: typeof docsCfg.conventions === 'string' ? docsCfg.conventions : 'CONVENTIONS.md',
}
const extraDocs = Array.isArray(docsCfg.extra) ? docsCfg.extra.filter((x) => typeof x === 'string') : []
const stableDocs = Array.isArray(config.stableDocs) ? config.stableDocs.filter((x) => typeof x === 'string') : ['SECURITY.md', 'CONTRIBUTING.md', 'CODE_OF_CONDUCT.md']
const manifestDoc = config.manifest && typeof config.manifest === 'object' && typeof config.manifest.file === 'string' ? [config.manifest.file] : []
const exempt = (Array.isArray(prose.exempt) ? prose.exempt : [])
  .filter((e) => e && typeof e.path === 'string')
  .map((e) => ({ path: e.path.trim().replace(/\/+$/, ''), why: typeof e.why === 'string' ? e.why : '' }))
const allowed = new Set((Array.isArray(prose.allow) ? prose.allow : [])
  .filter((a) => a && typeof a.term === 'string').map((a) => a.term.toLowerCase()))
const extraBanned = (Array.isArray(prose.extraBanned) ? prose.extraBanned : [])
  .filter((x) => typeof x === 'string').map((x) => x.toLowerCase())

// ── the file set ──────────────────────────────────────────────────────────────────────────
const walkFiles = (rel = '') => {
  const abs = rel ? join(target, rel) : target
  let entries
  try { entries = readdirSync(abs, { withFileTypes: true }) } catch { return [] }
  return entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0)).flatMap((e) => {
    const child = rel ? `${rel}/${e.name}` : e.name
    if (e.isDirectory()) return WALK_SKIP_DIRS.has(e.name) ? [] : walkFiles(child)
    return e.isFile() ? [child] : []
  })
}
const looksBinary = (rel) => {
  try { return readFileSync(join(target, rel)).subarray(0, 8192).includes(0) } catch { return true }
}
const underPath = (file, prefix) => file === prefix || file.startsWith(`${prefix}/`)
const licenseFile = LICENSE_CANDIDATES.find((f) => exists(f)) ?? null

const metaDocs = [DOC.readme, DOC.changelog, DOC.conventions, ...manifestDoc, ...extraDocs]
// Generated output is skipped alongside the license text: rewriting either is either
// impossible or undone by the next regenerate. The assets directory is read from the repo's own
// declared scope, so the sweep and the gate agree on what counts as machine output.
const assetsDir = (config.assets && typeof config.assets === 'object' && typeof config.assets.dir === 'string'
  ? config.assets.dir : '.github/assets').replace(/\/+$/, '')
const assetsDeclared = Boolean(config.assets && typeof config.assets === 'object' && !Array.isArray(config.assets))
const inScope = (f) => f !== licenseFile
  && !exempt.some((e) => underPath(f, e.path))
  && !(assetsDeclared && underPath(f, assetsDir))
const reach = (scan === 'docs'
  ? [...new Set([...metaDocs, ...stableDocs])].filter((f) => exists(f))
  : walkFiles().filter((f) => (scan === 'markdown' ? f.endsWith('.md') : !looksBinary(f)))
).filter(inScope)
// The `docs` reach is the governed meta docs, which is not the same set as a `docs/` directory.
// On a repo that keeps one, say so rather than letting the option name imply coverage it has not
// got: the pages are reachable through docs.extra, or by widening the scan.
const docsOutsideReach = (scan === 'docs' && exists('docs'))
  ? walkFiles('docs').filter((f) => f.endsWith('.md') && inScope(f) && !reach.includes(f)).length
  : 0
if (oneFile !== null && !reach.includes(oneFile)) {
  fail(`--file ${oneFile} is not in the ${scan} reach of this target (nothing was scanned; check the path, or widen --scan)`)
}
const targets = oneFile !== null ? [oneFile] : reach

// ── the scan ──────────────────────────────────────────────────────────────────────────────
const filler = [...PROSE_FILLER.filter((t) => !allowed.has(t)), ...extraBanned]
const hits = []
let scannedLines = 0
for (const doc of targets) {
  const isMarkdown = doc.endsWith('.md')
  let text
  try { text = read(doc) } catch { continue }
  // A released CHANGELOG section is history. The lint stops at the first dated version and so
  // does the sweep, so nobody is ever asked to rewrite what already shipped.
  let historyFrom = null
  if (doc === DOC.changelog) {
    const firstDated = [...text.matchAll(/^## +\[[^\]]+\]/gm)].find((m) => !/^## +\[unreleased\]/i.test(m[0]))
    if (firstDated) {
      historyFrom = text.slice(0, firstDated.index).split('\n').length
      text = text.slice(0, firstDated.index)
    }
  }
  // Positional stripping, twinned with the lint: a fenced line becomes an empty line rather
  // than disappearing, so every reported line number is the one the editor will show.
  const source = text.split('\n')
  let inFence = false
  const bareLines = source.map((line) => {
    if (isMarkdown) {
      if (FENCE_LINE.test(line)) { inFence = !inFence; return '' }
      if (inFence) return ''
      scannedLines++
      return line.replace(/"[^"]*"|`[^`]*`/g, '').replace(/(?<![A-Za-z0-9])'[^']*'(?![A-Za-z0-9])/g, '')
    }
    scannedLines++
    return line
  })
  bareLines.forEach((bare, i) => {
    for (const rule of PROSE_DASHES) {
      if (rule.re.test(bare)) hits.push({ file: doc, line: i + 1, kind: 'dash', rule: rule.label, fix: rule.fix, text: source[i].trimEnd() })
    }
  })
  // Filler is a register rule and applies to markdown prose only, exactly as in the lint: in
  // source, `leverageRatio` is an identifier rather than register. Multi-word terms match
  // across the document, because a hard-wrapped paragraph splits a phrase over two lines and a
  // per-line scan would report the repo as clean. A quoted mention wraps the same way, so this
  // pass blanks quoted and backticked spans that cross a line break, replacing them with spaces
  // rather than removing them so line numbers stay true.
  if (!isMarkdown) continue
  const joined = bareLines.join('\n').replace(/"[^"]*"|`[^`]*`/g, (m) => m.replace(/[^\n]/g, ' '))
  const lineOf = (index) => joined.slice(0, index).split('\n').length
  for (const term of filler) {
    const safe = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/-/g, '[\\s-]+').replace(/ /g, '\\s+')
    for (const m of joined.matchAll(new RegExp(`\\b${safe}`, 'gi'))) {
      const n = lineOf(m.index)
      hits.push({ file: doc, line: n, kind: 'filler', rule: term, fix: `cut it, or say the specific thing "${term}" is standing in for`, text: source[n - 1].trimEnd() })
    }
  }
  if (historyFrom !== null) hits.push({ file: doc, line: historyFrom, kind: 'note', rule: 'released history', fix: 'not scanned: everything below the first dated version is a record of what shipped', text: '' })
}

// ── report ────────────────────────────────────────────────────────────────────────────────
const violations = hits.filter((h) => h.kind !== 'note')
const notes = hits.filter((h) => h.kind === 'note')
const byFile = new Map()
for (const h of violations) byFile.set(h.file, [...(byFile.get(h.file) ?? []), h])
const worstFirst = [...byFile.entries()].sort((a, b) => b[1].length - a[1].length)
const dashes = violations.filter((h) => h.kind === 'dash').length

// The totals, computed once and printed first. Everything below this line is detail that a
// truncating reader can afford to lose; this is the part it cannot.
const counts = {
  hits: violations.length,
  dash: dashes,
  filler: violations.length - dashes,
  files: byFile.size,
  byFile: Object.fromEntries(worstFirst.map(([f, list]) => [f, list.length])),
}
const detailed = !summaryOnly && !filesOnly
const reported = limit && detailed ? worstFirst.flatMap(([, list]) => list.slice(0, limit)) : violations
if (limit && detailed) {
  counts.reported = reported.length
  counts.omitted = violations.length - reported.length
  counts.truncated = counts.omitted > 0
}
const totalsLine = violations.length
  ? `  ${violations.length} hit(s) across ${byFile.size} file(s): ${dashes} dash, ${violations.length - dashes} filler.`
  : '  clean: no em dash, no banned filler, in everything scanned.'

if (asJson) {
  // Key order is the contract: `counts` sits ahead of `hits` so that a reader whose transport
  // truncates the tail still holds the numbers. The per-hit remedy moves to a legend for the
  // same reason, since the same sentence repeated once per hit is pure weight.
  const fixes = {}
  for (const h of violations) fixes[h.rule] ??= h.fix
  const head = {
    target,
    scan,
    mode: summaryOnly ? 'summary' : filesOnly ? 'files-only' : 'full',
    profile: profileName,
    ...(oneFile !== null ? { file: oneFile, reachFiles: reach.length } : {}),
    filesScanned: targets.length,
    linesScanned: scannedLines,
    ...(docsOutsideReach ? { docsOutsideReach } : {}),
    counts,
  }
  const body = summaryOnly ? {} : {
    exemptions: exempt,
    allowances: [...allowed],
    ...(filesOnly ? {} : { fixes, hits: reported.map(({ fix, ...h }) => h) }),
    notes,
  }
  console.log(JSON.stringify({ ...head, ...body }))
} else {
  console.log(`voice-scan: ${target}`)
  console.log(`  profile: ${profileName} · scan: ${scan} · ${targets.length} file(s), ${scannedLines} line(s)`)
  console.log(totalsLine)
  if (oneFile !== null) console.log(`  ! --file: ${oneFile} only, out of ${reach.length} file(s) in this reach.`)
  if (scan === 'docs') console.log(`  reach: ${reach.join(', ') || 'no governed doc found'}`)
  if (docsOutsideReach) {
    console.log(`  ! ${docsOutsideReach} markdown file(s) under docs/ sit outside this reach: name them in docs.extra, or widen the scan to markdown.`)
  }
  for (const e of exempt) console.log(`  ! exempt: ${e.path}${e.why ? ` (${e.why})` : ''}`)
  for (const a of allowed) console.log(`  ! allowed: "${a}"`)
  for (const n of notes) console.log(`  · ${n.file}: ${n.fix}`)
  if (violations.length && !summaryOnly) {
    if (filesOnly) console.log('')
    for (const [file, list] of worstFirst) {
      if (filesOnly) { console.log(`  ${String(list.length).padStart(6)}  ${file}`); continue }
      console.log(`\n  ${file}  (${list.length})`)
      for (const h of list.slice(0, limit || list.length)) console.log(`    ${String(h.line).padStart(5)}  ${h.rule.padEnd(18)} ${h.text.trim().slice(0, 96)}`)
      if (limit && list.length > limit) console.log(`      ... and ${list.length - limit} more in this file (--limit 0 for all, or --file ${file})`)
    }
    console.log(`\n${totalsLine}`)
    if (counts.omitted) console.log(`  ${counts.omitted} hit(s) not shown at --limit ${limit}.`)
    console.log('  Rewrite each sentence; substituting other punctuation for an em dash is not a fix.')
  }
}
// The code is SET, never taken. stdout to a pipe is asynchronous, and process.exit() discards
// whatever has not drained yet, which truncates a piped --json at exactly the 64 KiB pipe buffer
// and hands the caller invalid JSON. Letting Node exit on its own flushes first.
process.exitCode = violations.length ? 1 : 0
