# [![harness/: Read-only engines · the agent half of the split](../.github/assets/banners/harness.svg)](https://github.com/runverdict/repo-standard-toolkit)

**The engines a skill calls to do the parts that must be deterministic.** Anything a machine can
decide the same way twice belongs here rather than in skill prose, because prose is only as
reliable as the model that remembers to follow it. Nothing here ever runs in a governed repo's
CI: that is [`payload/`](../payload/README.md).

The table below is the catalog, and the lint reddens the build when an engine has no row. That
check is here because the old hand-kept list sat at six engines while the directory held seven,
which is exactly how a list that reads authoritative stops being true. It happened again, in this
directory, on the day the check that catches it was written.

Reconciled against the code: 2026-07-31 (agent sweep)

| File | What it is for | Status |
|---|---|---|
| [`derive-palette.mjs`](derive-palette.mjs) | Harvests every named colour a repo declares about itself (CSS custom properties, theme objects, token JSON), maps them onto the generator's fifteen roles, and nudges any of the nine text pairs that misses 4.5:1. Refuses with exit 1 when fewer than six named colours turn up or none reads as a brand accent, pointing at the shipped presets instead. | `active` |
| [`fill-template.mjs`](fill-template.mjs) | Substitutes `{{KEY}}` placeholders in a payload template and demands a total fill. Any unfilled placeholder, any `--set` key the template never uses, a key given twice, or an existing `--out` without `--force` exits 2 with nothing written. The agent chooses the values; this engine is what makes the fill typo-proof. | `active` |
| [`github-about.mjs`](github-about.mjs) | Derives a GitHub About panel offline from the README's bold tagline, plus homepage and keywords read from a version manifest, naming the source of every field and listing under `missing` whatever nothing can source. Refuses to propose anything without a tagline, exiting 1, and never calls GitHub. States per field what applying it does at the API, because topics is a whole-list replacement. | `active` |
| [`index-plan.mjs`](index-plan.mjs) | Counts what an atlas sweep would cost before anyone approves it, answering three questions separately so none of them is mistaken for another: the structural work the exit code carries (missing rows, rot, duplicates, rows escaping the directory, unanswered candidates, and paths git keeps that no engine can see), the reconciliation plan that prices re-reading a structurally complete index anyway, and the migrations that would move a catalog to the page a reader lands on. Prices a directory that keeps no index yet down to the chunk with `--candidate`, chunks at twenty files or four thousand lines or four hundred thousand bytes, and answers bounded queries with `--summary` and `--chunk`. Refuses on an ungoverned repo, on a config declaring both index spellings, on an `--index` the config never declared, and on any configured path (declared or defaulted) that is spelled wrongly, resolves outside the repo, or carries a type that would silently route the plan somewhere else. | `active` |
| [`install-hook.mjs`](install-hook.mjs) | Installs the payload pre-push hook into `.git/hooks/pre-push` at mode 0755, or reports what it would do under `--check`. Refuses when the target is not the git root, when the committed lint is absent, when `core.hooksPath` is set at all, or when a pre-push hook it did not write sits there without `--force`. | `active` |
| [`preview-assets.mjs`](preview-assets.mjs) | Imports the manifest's own generator and renders every banner and pill into one network-free HTML page: both GitHub backgrounds, the exact README block, fifteen palette roles with each drawing job named, and nine measured contrast pairs. Writes that page wherever `--out` points, which the skill points outside the repo, and refuses with exit 2 when the manifest, the generator, or its `render()` export is missing. | `active` |
| [`sense-state.mjs`](sense-state.mjs) | Classifies a target repo as greenfield, partial or governed from what is on disk, then emits the per-artifact plan every skill branches on (scaffold, audit, install, keep, merge, repair, offer, offer-strict, offer-coverage, declined, and the two terminal ones: blocked-config for a configured path that leaves the repo or carries a type that would route the plan elsewhere, blocked-universe for a tree git keeps paths this engine cannot see in, blocked-link for a governed file whose bytes this repo does not commit at that path). Validates and canonicalises every configured path before reading, hashing or routing it, because this engine chooses which generator a scaffold run is told to execute. Refuses to call a differing committed lint an upgrade unless the payload's version constant is genuinely newer, returning `downgrade` when the plugin is the stale copy. | `active` |
| [`voice-scan.mjs`](voice-scan.mjs) | Reports every em dash form and every banned filler term across the governed prose at once, worst file first, with the totals printed before the detail because an agent harness truncates from the tail. Refuses an unknown `--scan`, a non-numeric `--limit`, and a `--file` outside the current reach rather than quietly scanning nothing. | `active` |

Three properties they share, each load-bearing:

- **Deterministic.** No clock, no randomness, no network. The same tree always produces the same
  report, so a plan can be reviewed before it is trusted.
- **Loud refusals.** An engine that cannot do the right thing says so and exits non-zero. A
  refusal is information for the operator, never something for an agent to route around.
- **Node built-ins only.** Same rule as the payload, for the same reason.

Five of the eight never write at all. `preview-assets.mjs` writes one page outside the repo,
`fill-template.mjs` writes the filled document `--out` names, and `install-hook.mjs` writes
`.git/hooks/pre-push` when asked; every other engine reads and reports.

`sense-state.mjs`, `voice-scan.mjs`, `github-about.mjs`, and `index-plan.mjs` carry deliberate
twins of logic that also lives in the payload lint (the license fingerprint chain, the writing
profile's word lists, the README tagline parse, the index coverage rule). The lint ships into
target repos as one self-contained file, so it cannot import a shared module. A standing test
compares each twin and fails the build if they ever drift apart.
