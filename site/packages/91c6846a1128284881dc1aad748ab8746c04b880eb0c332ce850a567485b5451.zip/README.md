# [![REPO-STANDARD-TOOLKIT: Scaffold the standard, then enforce it forever](.github/assets/banner.svg)](https://github.com/runverdict/repo-standard-toolkit)

<div align="center">

[![VERSION: 0.8.0](.github/assets/pills/version.svg)](CHANGELOG.md)
[![LICENSE: APACHE-2.0](.github/assets/pills/license.svg)](LICENSE)
[![NODE: 18+](.github/assets/pills/node.svg)](CONTRIBUTING.md)
[![DEPENDENCIES: NONE](.github/assets/pills/dependencies.svg)](acceptance/test-supply-chain.mjs)

[![ACCEPTANCE](https://img.shields.io/github/actions/workflow/status/runverdict/repo-standard-toolkit/test.yml?branch=main&style=flat&label=ACCEPTANCE&labelColor=0A2418&color=1F6E47)](https://github.com/runverdict/repo-standard-toolkit/actions/workflows/test.yml)

</div>

**Bootstrap and enforce enterprise repo hygiene in any codebase, from one command.** A Claude
Code plugin that scaffolds project front matter (README, CHANGELOG, CONVENTIONS, CONTRIBUTING,
CODE_OF_CONDUCT, SECURITY, LICENSE, the CI gate) from published standards, then installs a
committed linter so the standard polices itself on every push, with or without Claude.

> **Status: released.** Versions and history live in the [CHANGELOG](CHANGELOG.md); the first
> tag (0.2.0) was cut after validated fixture runs and a live-repo drill, with the gate green on
> push and an active ruleset shown blocking a red PR, an admin merge, and a spoofed status.
> Everything below is test-guarded in this tree (16 standing tests, 19 lint checks, zero npm
> dependencies) and the repo governs itself with the exact lint it installs elsewhere.

## Table of Contents

- [Background](#background)
- [How it works](#how-it-works)
- [Install](#install)
- [Usage](#usage)
- [The four pillars](#the-four-pillars)
- [What gets installed](#what-gets-installed)
- [The standards it embodies](#the-standards-it-embodies)
- [Documentation](#documentation)
- [Planned](#planned)
- [Caveats](#caveats)
- [Contributing](#contributing)
- [License](#license)

## Background

Every serious repo re-invents the same front matter: a README that drifts stale, a CHANGELOG
that decays into ad-hoc sections, counts hand-synced across files until someone forgets one, a
manifest whose totals stop summing. The fixes are all **known, published standards** (Keep a
Changelog, standard-readme, Contributor Covenant, SemVer, Conventional Commits). What was
missing is a tool that (a) installs them correctly from the first commit and (b) makes them
**self-enforcing** so they can never rot.

The load-bearing principle, learned the hard way:

> **Enforcement lives with the code it gates. Generation lives in the agent. Never make
> enforcement depend on the agent.**

A linter that only fires inside one editor or one AI tool is not a gate: a contributor on a fork
with vim drifts it freely and CI stays green. So the enforcement is a **committed lint run in
CI**, tool-agnostic, dependency-free. The agent's job is the other half: authoring and installing
that enforcement. The full reasoning lives in [Design](docs/design.md).

## How it works

Two layers, cleanly separated:

| Layer | Artifact | Runs | Depends on Claude? |
|---|---|---|---|
| **Scaffold / author** | the four skills + the `harness/` engines | on demand, per repo | yes, it is the agent |
| **Enforce** | `acceptance/test-repo-standard.mjs` + `.repo-standard.json` + `.github/workflows/*.yml`, committed into the target | every push / PR, in CI | **no**, `node` alone |

The skill senses the repo (`greenfield` / `partial` / `governed`, detected rather than assumed),
confirms a plan, scaffolds what is missing from templates, reconciles what drifted with minimal
quoted edits, installs the lint + config + CI gate verbatim, and iterates the suite to green.
Then it steps out: the standard is now policed by the committed lint, and re-invoking the skill
later is the reconcile and upgrade path, safe at any maturity.

## Install

```bash
claude plugin marketplace add runverdict/plugins
claude plugin install repo-standard-toolkit@runverdict-plugins
```

Requirements: the target repo needs nothing beyond **Node 18+ in CI** for the installed gate.
There is nothing to `npm install`. The lint, the engines, and the standing tests use Node
built-ins only.

## Usage

From any repo root, one command at any maturity:

```
/repo-standard-toolkit:scaffold
```

- **Greenfield:** scaffolds the full front matter plus enforcement, asks only for what it cannot
  derive, and refuses to invent what it cannot verify. An honest thin section beats a padded
  false one.
- **Mid-project:** reconciles drifted files with the smallest possible edits, quoting every
  change (before and after) in the recap. Prose is preserved; an ad-hoc CHANGELOG section is
  re-homed, never deleted.
- **Re-run / upgrade:** sensing is the idempotency mechanism. Every lint carries its payload
  version, so a re-run distinguishes upgrade from downgrade from local edit, and a stale plugin
  is stopped rather than allowed to downgrade a newer committed lint.

**It does not run on its own.** The plugin is invoked by you, once per repo, plus re-runs for
reconcile or upgrade. What runs automatically afterward is the CI gate: committed files in your
repo, triggered by GitHub, with the plugin nowhere in the loop:

```bash
for t in acceptance/test-*.mjs; do node "$t" || exit 1; done
```

## The four pillars

The front matter is the front door. Three further journeys extend the same committed lint, and the
scaffold **offers** them rather than assuming them: generated artwork nobody asked for, a writing
standard imposed on everything someone has already written, or a fan-out reading a repository
nobody agreed to spend, is not a service.

| Pillar | Skill | What the lint then holds true |
|---|---|---|
| **Standard** | `/repo-standard-toolkit:scaffold` | Front matter to published specs, the CI gate, and the ignore ruleset that keeps a secrets file unstageable. |
| **Identity** | `/repo-standard-toolkit:identity` | Banners and pills that re-render byte-identical from one manifest, the exact generated block on the front page, and every pill value re-read from the file it came from. |
| **Voice** | `/repo-standard-toolkit:voice` | The enterprise writing profile: no em dash in any form, no filler or AI-writing tells, swept with your approval and then locked. |
| **Atlas** | `/repo-standard-toolkit:atlas` | Every governed directory carries a complete glossary of itself: one row per file, every row resolving, every row stating a status from a shared vocabulary. |

**Identity** derives its palette from the repo's own design tokens where they exist, falls back
to a shipped preset where they do not, and refuses to invent one either way. The palette, the
brand inputs, and every banner are shown as a rendered preview before a byte is written. See
[Identity](docs/identity.md).

**Voice** scans first and locks second, always in that order: a profile switched on over unswept
prose is a red build tomorrow morning. Released CHANGELOG history is out of scope by design, and
every exemption prints its reason on every run. See [Voice](docs/voice.md).

**Atlas** writes each row from the file it describes, which means reading every file in every
directory it covers, which means a fan-out. **That fan-out is a gate.** It never begins without an
explicit yes, and the offer states the size first: how many directories, how many files, roughly
how many agents. A decline is a finished answer with somewhere to go, not a failed step. What CI
holds afterwards is completeness, resolution, and shape; it cannot hold accuracy, because no lint
reads a description and knows it still matches the code. See [Atlas](docs/atlas.md).

## What gets installed

All committed, all dependency-free. The full detail is in [Enforcement](docs/enforcement.md):

- `acceptance/test-repo-standard.mjs`, the standing linter: 19 lint checks covering Keep a
  Changelog shape, version lockstep, standard-readme structure, machine-checked counts, the
  marketing-voice ban, license agreement, the writing profile, the generated identity, the
  documentation index, and the ignore ruleset. Exit 1 means fix the docs, exit 2 means fix the config, and every skip is a
  printed, named line.
- `.repo-standard.json`, the repo's declared scope. See [Configuration](docs/configuration.md).
- `.github/workflows/test.yml`, the CI gate, with a read-only token.
- `.gitignore` rules that make a secrets file unstageable before one exists, merged into
  whatever the repo already had rather than replacing it.
- The meta docs themselves, where missing, filled from templates and grounded in the real repo.
- Optionally, on your yes: a local `pre-push` hook (a convenience, not a gate) and a GitHub
  branch ruleset that makes the check **required**, which is the piece that turns a red run into
  a blocked merge. Until a repo requires the check, a red run blocks nothing, and the skill says
  so rather than implying otherwise.

## The standards it embodies

Grounded in the published specs, not invented here:

- **CHANGELOG** → [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/)
- **README** → [standard-readme](https://github.com/RichardLitt/standard-readme)
- **CODE_OF_CONDUCT** → [Contributor Covenant](https://www.contributor-covenant.org/) 3.0
- **Versioning** → [SemVer](https://semver.org/) · **Commits** →
  [Conventional Commits](https://www.conventionalcommits.org/)
- **Contrast** → [WCAG 2.2](https://www.w3.org/TR/WCAG22/) AA (4.5:1), enforced on the generated
  palette rather than assumed
- **Enforcement pattern** → a committed CI linter, the way ESLint, markdownlint, and commitlint
  live in a repo, never hidden in an editor plugin.

The canon is **hardcoded in the lint**; config tunes scope, never the standard itself.

## Documentation

- [Enforcement](docs/enforcement.md): the 19 lint checks, the CI gate, the required-check ruleset,
  and the optional pre-push hook.
- [Identity](docs/identity.md): the manifest, the generator, palette provenance, and what
  "zero drift" is actually checking.
- [Voice](docs/voice.md): the two rule families, the guided sweep, and what the profile
  deliberately does not reach.
- [Configuration](docs/configuration.md): the `.repo-standard.json` surface, key by key.
- [Design](docs/design.md): the load-bearing principle, the origin story, and the deliberate
  rejections.
- [CONVENTIONS.md](CONVENTIONS.md): the binding rules this repo itself is held to.
- [acceptance/README.md](acceptance/README.md): the standing-test suite.
- [CHANGELOG.md](CHANGELOG.md): full version history.

## Planned

Designed, not shipped. Listed here because a roadmap kept in someone's head is not a roadmap:

- **Truth pass.** Extract the factual claims a repo's docs make, verify each against the code,
  and report the divergences. Code wins; the docs are what gets corrected.
- **Handover mode.** The guided clean-baseline ritual: a single tagged commit, a CHANGELOG that
  describes the platform as shipped, and an operator-gated force-push. For handing a repo to a
  buyer, an auditor, or a new team.
- **Docs-inventory classifier.** Sort a repo's documentation into runtime-consumed, operational,
  and historical, and propose what belongs where. Propose-never-execute.

## Caveats

- **Scope is repo surface**: presentation, hygiene, and truthfulness. Docs, changelog, meta
  files, generated identity, the CI gate. Not code linting, not tests, not security review.
  RS-ignore is ignore-rule hygiene, and it reads no file contents: secret scanning is a
  different product, and pretending otherwise would be the more dangerous claim.
- **Markdown and GFM assumptions.** The lint reads ATX headings (`#`), fenced code blocks, and
  pipe tables; exotic markdown layouts may need the config's paths or a reasoned check disable.
- **Single-root repos.** Monorepo per-package scoping is not built; govern the repo root, or run
  per package with separate configs at your own judgment.
- **The count glob is deliberately tiny**: literal directories plus `*` in the basename. Deeper
  truths use `file` and `lineRegex`. That smallness is what keeps the enforcement auditable.
- **RS-assets proves the artwork follows from the manifest, not that the generator is honest.**
  The lint imports the repo's own committed generator to re-render. No committed file can prove
  a sibling it imports was not forked; byte-identity against the published payload is what a
  re-run reports.
- **A scaffold is not a certification.** The gate proves structure, consistency, and
  machine-checkable facts. The prose quality of what an agent writes still needs the operator's
  review, which is why every run ends in a quoted recap and nothing is committed for you.

## Contributing

Read [`CONTRIBUTING.md`](CONTRIBUTING.md) for the workflow and [`CONVENTIONS.md`](CONVENTIONS.md)
for the binding rules: the enforcement and generation split, the payload byte-identity
discipline, and the rule that every determinizable property lands in a standing test (16
standing tests today; the pass is zero failures, never a fixed count). By participating you agree
to the [Code of Conduct](CODE_OF_CONDUCT.md).

## License

Apache-2.0 © runverdict. See [`LICENSE`](LICENSE).
