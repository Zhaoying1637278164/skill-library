# Authoring Conventions

Binding rules for every file in this repo. They exist so the plugin stays honest about what it
enforces, generic across target repos, and upgradeable without breaking the repos it governed.
Numbered so reviews and commits can cite §N; sections are contiguous from §1, and the lint
reddens the build on a gap.

## 1. What this plugin is (and is not)

The plugin scaffolds repo front matter from published standards and installs a committed,
dependency-free lint plus the CI workflow that runs it. Three further journeys extend the same
lint: a generated visual identity, an enterprise writing profile, and a per-directory index of
what every file is for. All four are offers a repo owner accepts, never conditions imposed on a
run they asked for.

It is a **scaffolder, not an enforcer**: after a run, the target repo polices itself with `node`
alone. It is NOT a code linter, a test framework, or a security tool, and it never certifies a
repo "immaculate". It makes drift fail CI, which is a different and honest claim. The trust
ruleset is ignore-rule hygiene and reads no file contents; secret scanning belongs to a
different product, and blurring that line would be the more dangerous claim.

## 2. Enforcement lives with the code; generation lives in the agent

The load-bearing principle, never to be regressed: **enforcement must not depend on the agent.**
Anything that gates a target repo ships as committed files that run with Node built-ins in CI:
no npm install, no network, no plugin, no Claude. The agent half (skills, harness engines) does
the judgment-heavy, one-time-ish work of sensing, filling, reconciling, and explaining. If a
proposed check needs the agent at enforcement time, it is rejected or redesigned.

One documented boundary follows from this. RS-assets imports the target repo's own committed
generator to re-render the artwork, which proves the SVGs still follow from the manifest. It
cannot prove the generator was not forked to render whatever is already there, because no
committed file can prove that about a sibling it imports. Byte-identity against the published
payload is what a re-run reports, and the README says so rather than implying more.

## 3. Payload rules

- **`payload/` is the product.** Everything installed into target repos lives there:
  `payload/acceptance/test-repo-standard.mjs` (the generic lint, canonical copy),
  `payload/repo-standard.json` (the default scope config), `payload/workflows/repo-standard.yml`
  and `repo-standard-scoped.yml` (the CI gate, plus the stopgap variant for repos whose
  pre-existing tests are red), `payload/rulesets/repo-standard.json` (the branch ruleset that
  makes the gate a REQUIRED check, shipped disabled, activating it is the operator's flip),
  `payload/ignore/repo-standard.gitignore` (the trust ruleset), `payload/assets/` (the identity
  generator, its palette presets, and the documented manifest shape),
  `payload/hooks/pre-push` (the optional local check, installed uncommitted), and
  `payload/templates/` (the fill-in artifacts).
- **Dogfood is byte-identical.** This repo's own `acceptance/test-repo-standard.mjs` and
  `.github/assets/generate.mjs` are installed copies of the payload originals; a standing sync
  test fails the build if any of them differ. Edit the payload, then re-copy, never the reverse.
- **Every versioned payload file moves together.** The lint and the generator each carry a
  version constant that `harness/sense-state.mjs` reads to direct a re-run (upgrade, downgrade,
  or local edit). Cutting a release bumps all of them with the plugin manifest, and standing
  tests lock the set.
- **Zero dependencies, forever.** The payload and every harness engine import only `node:`
  built-ins or relative paths. There is no `package.json` in this repo, and a standing test
  keeps it that way.
- **The payload is profile-clean at every reach.** Every file under `payload/`, the lint's own
  commentary included, satisfies the strictest writing profile this toolkit ships. A repo that
  adopts the profile at `scan: "all"` is therefore never writing an exemption for a file it did
  not author, which would be permanent noise in its lint run and an apology rather than a
  standard. The one exception is the Contributor Covenant text inside the CODE_OF_CONDUCT
  template: it is reproduced verbatim from an external standard, so it is exempted with a
  printed reason rather than edited. The dash detectors are written with escapes and the escape
  alternation is split, so no rule's own source matches it.
- **Templates are proven, not trusted.** A standing test fills every template with sample
  values and runs the shipped lint over the result, twice: once under the default scope and once
  under the enterprise writing profile. A template that scaffolds a standard-violating repo
  reddens the build.
- **The canon is hardcoded; config tunes scope.** The six Keep a Changelog categories,
  License-last, the voice ban, the writing profile's word lists, the contrast floor: these are
  the standard and live in the lint. The per-repo `.repo-standard.json` selects which docs
  exist, which counts are machine-checked, how far a scan reaches, and what is exempt. It can
  never water the canon down.

## 4. Skill structure

- Frontmatter: `name`, `description` (when to use it, in one breath), `allowed-tools`
  (narrowest workable set; engines granted as `Bash(node *harness/<engine>.mjs *)`).
- Body sections in order: title · one-paragraph promise · **When to use** (with NOT-for
  bullets) · **Prerequisites** · numbered **Steps** · **Automated vs. manual recap** · **What
  feeds the next skill**.
- Steps encode *failure modes*, not happy paths. Every refusal an engine can make gets a
  sentence telling the agent what it means (an overwrite refusal means the plan is stale, not
  that `--force` is needed).
- Shared assets are referenced as `${CLAUDE_PLUGIN_ROOT}/payload/...` or
  `${CLAUDE_PLUGIN_ROOT}/harness/...`.
- Skills never write silently: every created or modified file appears in the recap.
- **An offer is asked, and a declined offer is recorded.** The identity and voice journeys are
  never started on a repo's behalf, and a no is written into `scaffold.answers` so a re-run does
  not ask again. An offer repeated every session is a nag, and a nag is something people learn
  to click past.

## 5. Writing voice

Dense, specific, failure-encoded. Tables for matrices, prose for reasoning. No marketing
language, no "simply", no unexplained acronyms on first use. American spelling. The generated
templates hold target repos to the same voice, so this repo cannot exempt itself.

This repo also lives under the **enterprise writing profile** it ships, declared in
`.repo-standard.json` as `prose`. Two rule families, both enforced by RS-prose:

- **No em dash, in any form.** The character, its HTML escapes, and an en dash doing the same
  job (spaced, as punctuation between clauses) are all banned. Rewrite the sentence: a colon
  when what follows explains what came before, a full stop when it is a second thought,
  parentheses when it is genuinely an aside, a comma for a short apposition. Substituting a
  semicolon or a pair of hyphens is the same sentence wearing a disguise. An en dash inside a
  numeric range is untouched, because that is what an en dash is for.
- **No filler and no AI-writing tells, in markdown prose.** Banned: `delve`, `utilize`,
  `leverage`, `in order to`, `worth noting`, `it should be noted`, `needless to say`,
  `as you can see`, `furthermore`, `moreover`, `a wide range of`, `a variety of`,
  `state-of-the-art`. Naming a term in backticks (as this list does) is a mention, not a use;
  the lint strips quoted and backticked spans before scanning.

The two families reach different distances, deliberately. Dashes are checked as far as
`prose.scan` says; filler stops at markdown. In source, `leverageRatio` is an identifier rather
than register, and the file that declares the ban list necessarily contains every word in it, so
a rule that fired on both is one people would learn to switch off. Register is a property of
prose, so it is checked where prose lives.

The declared reach here is `markdown`: every `.md` in the tree, which is this repo's whole
published surface, front matter and docs pages and folder READMEs and the skills alike. The
harness engines and the standing tests are JavaScript and stay outside it, and this file says so
instead of leaving the gap implied. Released CHANGELOG history is out of scope by canon, because rewriting
what already shipped would falsify the record the file exists to keep. `CODE_OF_CONDUCT.md` is
exempt with a stated reason: the Contributor Covenant text is reproduced verbatim, and editing
it would misrepresent the standard this repo says it follows.

## 6. Versioning and releases

[Semantic versioning](https://semver.org/). Every user-facing change lands a CHANGELOG entry
under `[Unreleased]` in the matching category, in the same PR. Cutting a release renames
`[Unreleased]` to the dated version, bumps `.claude-plugin/plugin.json` and every payload
version constant in the same commit, and opens a fresh `[Unreleased]`; pre-first-release, no
dated sections exist. Commits follow
[Conventional Commits](https://www.conventionalcommits.org/). Payload lint changes are always at
least a **minor** bump: governed repos upgrade by re-running the scaffold skill, and their diff
should correspond to a version they can point to.

## 7. Project-meta docs standard (README / CHANGELOG / CONVENTIONS)

This repo's front matter is held to the same standard the plugin installs everywhere else,
enforced by its own installed copy of `acceptance/test-repo-standard.mjs` (scope in
`.repo-standard.json`). Grounded in the published specs, not invented here:

- **CHANGELOG → [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/).** Under every
  version, the ONLY `###` subsections allowed are the six canonical change categories
  (**Added · Changed · Deprecated · Removed · Fixed · Security**), grouped one heading per
  category per version. `[Unreleased]` stays at the top; concrete versions are
  reverse-chronological, valid semver, the newest in lockstep with the version manifest. A
  pulled release keeps its section, tagged `[YANKED]` after the date.
- **README → [standard-readme](https://github.com/RichardLitt/standard-readme).** Exactly one
  H1; a short description immediately after it (never a blockquote); **Install**, **Usage**, and
  **Contributing** sections; the **License** section LAST. Two house additions on top of the
  spec: the short description is a **bold tagline**, and a **Caveats** or limitations section is
  required (a standard that ships its limits).
- **CONVENTIONS.** The numbered `## N.` sections are contiguous from §1, with no gaps and no
  duplicates.
- **Counts are machine-verified, not trusted.** Every count declared in `.repo-standard.json`
  (here: the standing-test and lint-check totals) must equal the real repo fact wherever stated,
  and cross-doc numbers must agree. A forgotten count reddens the build.
- **Voice (§5) extends here.** No marketing superlatives and no "simply" in any meta doc.
- **Stable meta files.** SECURITY, CONTRIBUTING, and CODE_OF_CONDUCT (the
  [Contributor Covenant](https://www.contributor-covenant.org/), currently 3.0) exist and open
  with an H1.
- **LICENSE is lint-governed too.** A license file exists at the repo root; when its text is a
  recognizable standard license, each JSON manifest the lint reads (the plugin manifest and
  `package.json`) that declares a `license` field, and the README's License section, must name
  the same id. What cannot be compared (an unrecognized text, or no manifest license field) is a
  loud named skip, never a silent pass.
- **No shadowed meta files.** A governed doc exists in exactly one of `.github/`, the repo root,
  or `docs/`. GitHub serves only the highest-precedence copy, so a second one is drift the
  content checks cannot see. **README is the exception**, because it is the one basename with two
  jobs: the front-page fallback, and the directory index GitHub renders when anyone browses a
  folder. A `docs/README.md` beside a root README is the second job and hides nothing, so it is
  never a shadow; a `.github/README.md` beside a root one still is.
- **A directory catalogues itself.** Where `docs.index` or `docs.indexes` is declared, every file
  under it is listed with what it is for and what state it is in, drawn from one canon vocabulary
  so two governed repos are comparable rather than merely similarly shaped. `extensions` decides
  what counts, so a directory of engines indexes its source the same way a docs tree indexes
  prose. Freshness is recorded either once for the index (`reconciled`) or per row
  (`requireDate`). The lint holds coverage and shape, never age: the date is a fact the repo
  records, and a check that compared it to today would make the same tree lint differently
  tomorrow.
- **No unfinished scaffolds.** No `TODO(scaffold)` marker survives in a governed doc: the lint
  reddens on any left behind, so a half-written scaffold cannot pass CI while looking done.
  Naming the marker in backticks (as this line does) is a mention, not an unfinished scaffold.
  The same rule holds for unfilled `{{PLACEHOLDER}}` tokens: a hand-copied template that
  bypassed the fill engine reddens the build, fenced code blocks included, because that is
  exactly where template placeholders live.

## 8. The generated identity

The banners and pills in every README are generated, never drawn. Edit
`.github/assets/manifest.json`, run `node .github/assets/generate.mjs` from the repo root, and
commit both. **Never hand-edit an SVG**: RS-assets re-renders the manifest on every CI run and
compares the bytes, so a hand edit is reverted by the next regenerate and reddens the build in
the meantime.

- **One idiom, not one per directory.** Every declared README opens with the exact H1 the
  generator prints. The lint rebuilds that line character for character and compares.
- **Every pill is a claim, so every pill has a source.** A pill records the file and the path or
  regex its value was read from, and the lint re-reads it forever. A value with no single source
  of truth declares `"source": false` with a reason, and the lint prints that as a named skip on
  every run: stated, never verified.
- **A derived palette records its tokens.** When a palette is read from a repo's own design
  system, each sourced role records the file, the token, and the value it held, and the lint
  re-reads them. A rebrand is reported as drift rather than leaving the banners quietly
  representing a product that changed. A role derived by transform is never recorded as if it
  could be re-verified.
- **Contrast is enforced, not assumed.** The palette clears 4.5:1 (WCAG 2.2 AA) on all nine
  text pairs the lint measures.
- **A pill is rendered; a live badge is only styled.** A pill states a fact this repo can render
  and whose source the lint re-reads. A build status changes without the repo changing, so a
  locally rendered "passing" would be a claim that can never go red. Live badges stay
  third-party, take the palette's colours through the generator, and the lint checks the README
  carries that exact line.
- **The GitHub About panel is part of the surface.** Its description is the README's tagline, so
  it inherits the writing standard rather than needing its own, and what was synced is recorded
  in `.repo-standard.json`. The lint takes no network, so it holds the offline half: edit the
  tagline and the record goes stale. Topics are added, never replaced, because GitHub's write
  replaces the whole list and a curated topic is not derivable from any file here.
- **Geometry is fixed; brand inputs vary.** Dimensions, orb drifts, and wave timings live in the
  generator under the payload byte-sync rule. Changing them re-renders every governed repo, so
  a standing test pins them.

## 9. The trust ruleset

The committed ignore rules are part of the standard, not a nicety, and RS-ignore holds them:

- **A secrets file can never become trackable.** The whole `.env` family is ignored before any
  such file exists, because ignoring a path does nothing about one git already tracks. A bare
  `.env` rule is the common half-fix that leaves `.env.local` and `.env.production` open, which
  is exactly where real credentials live. The only negation permitted is an example file.
- **Declared build output stays out of the tree.** Paths listed under `ignore.generated` must be
  ignored and untracked. A diff full of generated artifacts is noise hiding signal.
- **Merge, never clobber.** Adopting the ruleset appends the missing lines to whatever a repo
  already had. Someone put every existing line there for a reason that is not visible from here.
- **The tracked-file leg needs git, and says so when it is absent.** Without git the rules are
  still checked and the evidence leg prints a named skip, rather than a green line implying the
  repo was inspected.

## 10. The directory index

A governed directory keeps a complete glossary of itself, and `RS-index` holds it:

- **A row is written from the file, never from the listing and never from the file's own header.**
  A description drawn from a directory listing produces a table that names some of what is there,
  and a table reads as complete. A description copied from a header repeats whatever that header
  last claimed, which is the thing this sweep most reliably catches being false.
- **Row order is ascending path order, and the link target is relative to the index.** Both are
  mandated rather than preferred. Order, because it is the only order a later pass reproduces, and
  a re-sort produces a diff that reads as a rewrite. Link targets, because the repo-root instinct
  resolves to `skills/skills/...` and fails two checks at once.
- **The status vocabulary is canon, not scope.** `active`, `superseded`, `reference`, `design`,
  `delivered`, in whatever case the page writes them, with `aliases` for a genuinely different
  word. Two governed repos should be comparable rather than merely similarly shaped.
- **The index is not always the README.** Where a directory ships a `README.md` that is not a
  catalog, the catalog takes another name and the README gets a row like anything else.
  `payload/templates/` is the worked example here.
- **The fan-out that authors it is a gate.** It never starts without an explicit yes, and the
  offer states how many directories, files, and agents before it happens, from
  `harness/index-plan.mjs` rather than from an estimate. A decline routes to a narrower scope or
  a hand-off, and is a finished answer.
- **A green check is completeness, resolution, and shape, and never accuracy.** No lint reads a
  description and knows it still matches the code. Say so wherever the pillar is documented
  rather than letting the check imply more than it earns.
