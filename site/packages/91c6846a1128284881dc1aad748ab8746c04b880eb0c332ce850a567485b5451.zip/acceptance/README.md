# [![acceptance/: The standing suite · dependency-free, zero failures](../.github/assets/banners/acceptance.svg)](https://github.com/runverdict/repo-standard-toolkit)

**The standing, dependency-free proof that this plugin does what it claims.** Node built-ins
only: no `npm install`, no network, no LLM.

```bash
for t in acceptance/test-*.mjs; do node "$t" || exit 1; done
```

The pass is **zero failures**, never a fixed count (the check count grows with every change; a
hardcoded total would be false the moment a test lands). CI runs exactly this loop on every push.

Reconciled against the code: 2026-07-31 (agent sweep)

| File | What it is for | Status |
|---|---|---|
| [`test-assets-generator.mjs`](test-assets-generator.mjs) | Holds the shipped identity generator to the properties the lint depends on: `render()` is total and deterministic, the banner H1 and the README identity block are pinned as literals, an import writes nothing, brand text is escaped for the context it lands in (an attribute value, a text node, a Markdown label) so a quote in a manifest cannot inject an SVG attribute, an over-long tagline refuses instead of clipping, and every palette preset clears 4.5:1. Also holds the CLI to what it writes: an assets directory outside the target repo, a symlinked asset and a symlinked manifest are refusals, and the preview names the engine's own replacement and any README left carrying an H1 for a banner the manifest no longer declares. | `active` |
| [`test-changelog-version.mjs`](test-changelog-version.mjs) | Locks this plugin's four version sources together: CHANGELOG headings are semver and descend, the newest dated one equals `.claude-plugin/plugin.json`, and that version equals both `REPO_STANDARD_LINT_VERSION` and `REPO_STANDARD_ASSETS_VERSION`. It also pins the name and repository the catalog installs by. | `active` |
| [`test-derive-palette.mjs`](test-derive-palette.mjs) | Runs the palette engine over throwaway repos and holds it to reading rather than inventing: provenance names the real file, token and line; a tree with no named colours exits 1 with a reason and no palette; only token-backed roles are recorded as re-verifiable; and the proposal renders through the shipped generator. | `active` |
| [`test-fill-template.mjs`](test-fill-template.mjs) | Drives the fill engine through the happy path and each refusal: a missing or stray `--set` key, a duplicate key, a malformed flag, `--out` with `--stdout`, and a missing template each exit 2 leaving `--out` unwritten, and an existing `--out` needs `--force`. It also audits every token under `payload/templates/` for the `{{KEY}}` shape. | `active` |
| [`test-gate-posture.mjs`](test-gate-posture.mjs) | Holds the two payload workflows and the branch ruleset to their posture: triggers are exactly push, pull_request and merge_group; every `uses:` pins a 40-hex SHA; the ruleset ships disabled with four rules; and its required contexts equal the workflow job ids, with no job-level name override to break the pinning. | `active` |
| [`test-github-about.mjs`](test-github-about.mjs) | Holds the About proposal to something a consumer can apply verbatim: a field nothing could source is absent rather than null or empty, which is what stops a derived `topics: []` deleting every topic the repo had, and the replacement caution reaches both output modes from one constant. Also covers the tagline parse, the topic cap, the repo-URL-is-not-a-homepage rule, and that the engine writes nothing. | `active` |
| [`test-index-plan.mjs`](test-index-plan.mjs) | Proves the atlas planner scopes a sweep the way `RS-index` scopes a build, comparing the planner's coverage set against the lint's own missing-file message on a fixture and on this repo's real indexes. It also covers chunk packing, orphaned rows, unreadable files, README candidates, and every refusal path, a differential table asserting the exact exit CLASS both engines return on each mutated config, a matrix of tables Markdown does not render, a git-state matrix, a migration-occurrence matrix asserting which of `links` and `mentions` each spelling lands in, and a set-level comparison against `sense-state`. | `active` |
| [`test-install-hook.mjs`](test-install-hook.mjs) | Covers the hook installer and then executes the hook it installs: the install is byte-identical, executable and idempotent; five refusals (no git, subdirectory, ungoverned, foreign hook, `core.hooksPath`) write nothing; and the hook exits 1 on drift and on a broken config, 0 with no lint or a red sibling test. | `active` |
| [`test-lint-behavior.mjs`](test-lint-behavior.mjs) | Proves every payload lint rule twice: a known-clean fixture passes at exit 0, then one planted violation per rule reddens the matching `RS-` id, exemptions and loud skips stay green, and config errors exit 2. A second fixture family renders real artwork first, so the `RS-assets` cases mutate a genuinely generated tree. A third proves physical containment: a gate committed as a symlink (or reached through a symlinked parent) refuses to run rather than auditing the tree it points into, and a symlinked SVG, manifest or generator is an explicit error rather than an entry a directory scan cannot see. | `active` |
| [`test-payload-sync.mjs`](test-payload-sync.mjs) | Byte-locks what this repo lives under to what it ships: the installed lint, CI workflow and asset generator each equal their payload original, the payload lint imports only `node:` built-ins, and this repo's own banners and pills re-render byte-identical from its committed manifest. | `active` |
| [`test-repo-standard.mjs`](test-repo-standard.mjs) | Runs the shipped lint over this repo's own front matter under `.repo-standard.json`, so meta-doc drift cannot land green: Keep a Changelog shape, standard-readme structure, license agreement across LICENSE and manifest and README, generated-asset drift, index coverage, and the secrets ignore ruleset. The dogfood: what we ship is what we live under. | `active` |
| [`test-sense-state.mjs`](test-sense-state.mjs) | Drives the sensing engine over throwaway fixtures and asserts what a scaffold run trusts blindly: the greenfield, partial and governed verdicts, the per-artifact plan, lint and generator drift directed by each embedded version constant, derivations that report `unrecognized` rather than guess, and the terminal answers: a configured path leaving the repo, a tree git keeps paths it cannot see in, and a governed file whose bytes this repo does not commit at that path. Also proves the engine writes nothing. | `active` |
| [`test-skill-wiring.mjs`](test-skill-wiring.mjs) | Binds SKILL.md prose to the tree: every skill directory carries frontmatter and the fixed section anatomy, every referenced harness engine and payload path exists, every engine and documented `gh` command is granted in `allowed-tools`, and no marketplace of this repo's own is shipped. Catches wiring that would fail mid-scaffold in someone else's repo. | `active` |
| [`test-supply-chain.mjs`](test-supply-chain.mjs) | Holds the plugin's own trust floor so the zero-dependency claim cannot rot: no `package.json` or lockfile in the tracked-plus-untracked listing, every scanned `.mjs` importing only `node:` built-ins or relative paths, and a column-0 `permissions:` block granting `contents: read` with zero write grants. This is what makes the `DEPENDENCIES: NONE` pill true. | `active` |
| [`test-templates-lint-green.mjs`](test-templates-lint-green.mjs) | Performs the scaffold mechanically so no future scaffold is born red: fills the doc and licence templates through the real fill engine, installs the payload lint, config and ignore ruleset, then runs the gate. Asserts exit 1 while a `TODO(scaffold)` marker survives, exit 0 once resolved and again under the enterprise writing profile. | `active` |
| [`test-voice-canon.mjs`](test-voice-canon.mjs) | Parses the dash rules, the filler list and the scan reaches out of both the sweep engine and the payload lint and compares them literally, so a drifted twin cannot report a repo clean and then fail its build. Also proves the two agree on fixtures, that exemptions print, and that the payload tree scans clean at the widest reach. | `active` |

**The honest limit on mutation coverage:** it is maintained by discipline, not by a machine.
Nothing here fails the build when a new lint rule lands without a red-path case, so "every rule"
is a claim about the last time someone checked, not an invariant. It was **audited by deleting
each of the lint's assertions one at a time and re-running this suite**. The audit found six
rules that survived deletion with everything green, and those gaps are now covered.

Two traps that audit exposed, worth knowing before adding a case: a needle that is also a
substring of the check's own NAME is satisfied by the `✗` line no matter which assertion fired
(assert on the message, never the name), and a check with several assertions needs an input that
trips only the one under test, or an earlier assertion fires and the later rule is never proven.

**One coverage gap this directory knows about and does not yet close.** Several files here carry a
guard list in their own header, and nothing checks that the list still matches the guards the file
runs, so a case added tomorrow is described nowhere until somebody remembers. That is the failure
`RS-index` closes one level up, in a directory with no equivalent check on itself.

The gap that used to sit beside it is closed. `test-templates-lint-green.mjs` still fills a
hardcoded list of templates, but `TG0` now asserts that list against the directory in both
directions: a template nobody fills fails, a claimed template the directory no longer ships fails,
and a vacuous pass on an empty directory is refused.
