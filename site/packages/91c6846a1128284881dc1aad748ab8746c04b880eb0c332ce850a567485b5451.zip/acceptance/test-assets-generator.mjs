#!/usr/bin/env node
/*
 * test-assets-generator.mjs — the identity generator is deterministic, importable, and shippable.
 *
 * WHY: the committed lint imports this generator on every CI run and compares its output to the
 * bytes in the repo. That only means something if the generator is PURE (same manifest in, same
 * bytes out, no writes on import) and if its geometry is fixed rather than incidental. It is
 * also the one payload file whose output lands in someone's README as prose, so its alt text has
 * to satisfy the writing profile this same toolkit enforces.
 *
 * Guards:
 *   AG1  render() is total and deterministic: every declared asset, nothing else, byte-identical
 *        across runs and across two separate imports.
 *   AG2  the banner H1 idiom is exactly one documented shape, pinned here as a literal so that
 *        changing it is a deliberate act rather than a silent break for every governed repo.
 *   AG3  the generator's own output is prose-clean: no em dash and no banned filler in the alt
 *        text it writes into READMEs, or the standard would be arguing with itself.
 *   AG4  every shipped palette preset declares all 15 roles as hex and clears the 4.5:1 floor.
 *   AG5  importing the module writes nothing: the main guard is what makes the lint's import safe.
 *   AG6  brand text is XML-escaped, so one ampersand in a tagline cannot produce a broken SVG.
 *   AG7  the geometry constants are fixed (a change re-renders every governed repo on its next
 *        run, so it must never happen by accident).
 *   AG8  the version constant is in the exact shape harness/sense-state.mjs greps for.
 *   AG9  the wordmark fits the canvas at any brand-name length.
 *   AG10 a tagline of any length stays inside the banner, and spends tracking before size.
 *   AG11 a tagline that cannot fit at a readable size REFUSES rather than rendering clipped.
 *   AG12 a folder description is fitted on the same terms as the tagline.
 *   AG13 the README identity block is exactly one documented arrangement, pinned as a literal
 *        for the reason AG2 is: the lint compares it byte for byte on every governed front page.
 *
 * Dependency-free: `node acceptance/test-assets-generator.mjs`.
 *   AG14 --check renders and compares WITHOUT writing, artwork and generated markdown both.
 *   AG15 a MARKDOWN-ONLY manifest edit (a pill href, brand.homepage, a badge href, a banner dir)
 *        reaches the --check exit code; every one of them used to report a no-op.
 *   AG16 --assets-dir / --repo let a NEW generator plan an OLD target while writing nothing to it.
 *   AG17 the ARGUMENT matrix: a typo, a wrong case, a positional, a duplicate and a missing
 *        value each exit 2 and write nothing. `argv.includes('--check')` made a typo a WRITE.
 *   AG18 an asset the manifest no longer produces is planned as a DELETE and removed on apply,
 *        which is the state the lint wants and no run could previously reach.
 *   AG19 the front page is docs.readme, so a repo serving .github/README.md is not reported as
 *        one missing a README.
 *   AG20 an assets directory with a space renders a bracketed destination markdown can read.
 */
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, mkdtempSync, rmSync, writeFileSync, mkdirSync, existsSync, symlinkSync, renameSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, relative } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { render, bannerH1, readmeBlock, badgeMarkdown, altText, ROLES, GEOMETRY, PILL_SCHEMES, REPO_STANDARD_ASSETS_VERSION } from '../payload/assets/generate.mjs'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const GEN = join(ROOT, 'payload', 'assets', 'generate.mjs')
const PALETTES = join(ROOT, 'payload', 'assets', 'palettes')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

console.log('assets-generator standing test (deterministic identity)')

const palette = JSON.parse(readFileSync(join(PALETTES, 'slate.json'), 'utf8')).palette
const manifest = {
  version: 1,
  brand: { name: 'ACME', tagline: 'A test manifest', eyebrow: 'ACME · TEST', homepage: 'https://example.com', palette },
  pills: [{ file: 'version.svg', label: 'VERSION', value: '1.0.0', scheme: 'alt', source: false, why: 'fixture' }],
  banners: [{ slug: 'src', dir: 'src', title: 'src/', desc: 'Application source' }],
}

check('AG1 render() is total and deterministic (same manifest in, same bytes out)', () => {
  const a = render(manifest)
  const b = render(JSON.parse(JSON.stringify(manifest)))
  assert.deepEqual(Object.keys(a).sort(), ['banner.svg', 'banners/src.svg', 'pills/version.svg'],
    'render must produce exactly the declared assets: the root banner, one per banner entry, one per pill')
  for (const k of Object.keys(a)) assert.equal(a[k], b[k], `render is not deterministic for ${k}`)
  for (const k of Object.keys(a)) {
    assert.match(a[k], /^<svg /, `${k} must be an SVG document`)
    assert.match(a[k], /<\/svg>\n$/, `${k} must end with a newline, so the committed file is a well-formed text file`)
  }
})

check('AG2 the banner H1 idiom is exactly one documented shape', () => {
  // Pinned as a literal on purpose. This string is what the lint rebuilds and compares against
  // every governed README, so a change here silently breaks every repo the toolkit governs
  // until they regenerate. It should cost a deliberate edit to this line.
  assert.equal(
    bannerH1({ title: 'src/', desc: 'Application source', to: '../.github/assets/banners/src.svg', homepage: 'https://example.com' }),
    '# [![src/: Application source](../.github/assets/banners/src.svg)](https://example.com)',
    'the banner H1 idiom changed: every governed repo would fail RS-assets (idiom) until it regenerates',
  )
  assert.equal(altText('a', 'b'), 'a: b', 'the title and description are joined by a colon and a space, and nothing else')
  // A repo with no remote and no product site has nowhere for the banner to point. Linking it
  // to an invented destination would be the same fabricated claim as a CI badge for a workflow
  // that does not exist, so the H1 is the image alone.
  assert.equal(
    bannerH1({ title: 'src/', desc: 'Application source', to: '../.github/assets/banners/src.svg' }),
    '# ![src/: Application source](../.github/assets/banners/src.svg)',
    'without a homepage the banner H1 is an unlinked image, not a link to nowhere',
  )
})

check('AG13 the README identity block is exactly one documented arrangement', () => {
  // Pinned as a literal for the same reason AG2 is, and with more at stake: this is the whole
  // top of every governed front page, and the lint compares it byte for byte. The blank line on
  // each side of the <div> is load-bearing markdown, not formatting: without it GitHub renders
  // the pills as literal text inside an HTML block.
  const withHref = {
    ...manifest,
    pills: [
      { file: 'version.svg', label: 'VERSION', value: '1.0.0', scheme: 'alt', href: 'CHANGELOG.md', source: false, why: 'fixture' },
      { file: 'node.svg', label: 'NODE', value: '18+', scheme: 'accent', source: false, why: 'fixture' },
    ],
  }
  assert.equal(
    readmeBlock(withHref, { assets: '.github/assets' }),
    [
      '# [![ACME: A test manifest](.github/assets/banner.svg)](https://example.com)',
      '',
      '<div align="center">',
      '',
      '[![VERSION: 1.0.0](.github/assets/pills/version.svg)](CHANGELOG.md)',
      '![NODE: 18+](.github/assets/pills/node.svg)',
      '',
      '</div>',
    ].join('\n'),
    'the README identity block changed: every governed repo would fail RS-assets (idiom) until it re-pastes the block',
  )
  // A pill's alt text is the whole claim. "Version" alone tells a reader who cannot see the
  // plate nothing, and the separator is the one this system uses everywhere else.
  assert.ok(readmeBlock(withHref, { assets: '.github/assets' }).includes(`![${altText('VERSION', '1.0.0')}]`),
    'a pill\'s alt text is its label and its value, joined the way altText joins a banner\'s')
  // The live badge sits on its own line under the pills, because a third-party renderer never
  // matches the local plates for height and a reader should see two kinds of claim, not one
  // broken row. The URL inside it is pinned separately, against a hand-typed expectation.
  const withBadge = { ...withHref, badges: [{ label: 'CI', endpoint: 'github/actions/workflow/status/acme/x/test.yml', href: 'https://example.com/ci' }] }
  assert.equal(
    readmeBlock(withBadge, { assets: '.github/assets' }).split('\n').slice(-4).join('\n'),
    `\n${badgeMarkdown(withBadge, withBadge.badges[0])}\n\n</div>`,
    'a live badge goes inside the centred block, on its own line under the pill row',
  )
  // Nothing to centre, so nothing is centred. An empty div is decoration around a row that was
  // never written, and it would be the shape every repo with no pills inherits.
  assert.equal(
    readmeBlock({ ...manifest, pills: [], badges: [] }, { assets: '.github/assets' }),
    '# [![ACME: A test manifest](.github/assets/banner.svg)](https://example.com)',
    'with no pills and no badges the block is the H1 alone',
  )
  // The assets directory is given relative to the README that carries the block, so a repo whose
  // README sits beside its assets gets bare paths rather than a leading "./".
  assert.ok(readmeBlock(withHref, { assets: '.' }).includes('](banner.svg)'), 'an assets dir of "." must not produce "./banner.svg"')
})

check('AG3 the generator\'s own output satisfies the writing profile it ships beside', () => {
  // A generator that wrote an em dash into README markdown would put every repo that adopts both
  // pillars into a fight with itself. What is scanned is EVERY markdown surface the generator
  // emits, not one hand-picked line: the block, the H1s, the badge line, and the separator. The
  // manifest text is deliberately clean, because a tagline carrying banned filler is the repo's
  // problem and this guard is about what the GENERATOR contributes on top of it.
  const FILLER = ['delve', 'utilize', 'leverage', 'in order to', 'worth noting', 'it should be noted',
    'needless to say', 'as you can see', 'furthermore', 'moreover', 'a wide range of', 'a variety of', 'state-of-the-art']
  const clean = {
    ...manifest,
    pills: [{ file: 'version.svg', label: 'VERSION', value: '1.0.0', scheme: 'alt', href: 'CHANGELOG.md', source: false, why: 'fixture' }],
    badges: [{ label: 'CI', endpoint: 'github/actions/workflow/status/acme/x/test.yml', href: 'https://example.com/ci' }],
  }
  const surfaces = {
    'the README block': readmeBlock(clean, { assets: '.github/assets' }),
    'the root banner H1': bannerH1({ title: 'ACME', desc: 'A test manifest', to: '.github/assets/banner.svg', homepage: 'https://example.com' }),
    'an unlinked folder H1': bannerH1({ title: 'src/', desc: 'Application source', to: '../a/src.svg' }),
    'the badge line': badgeMarkdown(clean, clean.badges[0]),
    'the alt-text separator': altText('T', 'D'),
  }
  for (const [what, text] of Object.entries(surfaces)) {
    assert.doesNotMatch(text, /—|&mdash;|&#8212;|\s–|–\s/, `${what} must carry no em dash in any form`)
    for (const t of FILLER) {
      assert.ok(!new RegExp(`\\b${t.replace(/-/g, '[\\s-]')}`, 'i').test(text), `${what} must carry no banned filler ("${t}")`)
    }
  }
  assert.ok(!/[—–]/.test(surfaces['the alt-text separator']), 'the alt-text separator must not be a dash of any kind')
})

const lin = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
const lum = (hex) => {
  const h = hex.replace('#', '')
  const parts = h.length === 3 ? [...h].map((c) => c + c) : [h.slice(0, 2), h.slice(2, 4), h.slice(4, 6)]
  const [r, g, b] = parts.map((p) => lin(parseInt(p, 16) / 255))
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}
const ratio = (a, b) => { const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x); return (hi + 0.05) / (lo + 0.05) }

check('AG4 every shipped palette preset is complete and clears the 4.5:1 contrast floor', () => {
  const PAIRS = [['text', 'ground'], ['text', 'groundMid'], ['text', 'groundDeep'],
    ['textMuted', 'ground'], ['textMuted', 'groundMid'], ['accentAlt', 'ground'], ['accentAlt', 'groundMid'],
    ['pillAccentFg', 'pillAccentBg'], ['pillAltFg', 'pillAltBg']]
  const files = readdirSync(PALETTES).filter((f) => f.endsWith('.json')).sort()
  assert.ok(files.length >= 3, `expected the shipped presets (found ${files.length}) — refusing a vacuous pass`)
  for (const f of files) {
    const p = JSON.parse(readFileSync(join(PALETTES, f), 'utf8'))
    assert.ok(typeof p.name === 'string' && p.name.trim(), `${f} must name itself`)
    assert.ok(typeof p.description === 'string' && p.description.trim(), `${f} must say what it looks like`)
    for (const role of ROLES) assert.match(String(p.palette?.[role]), /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/, `${f} palette.${role} must be a hex colour`)
    const extra = Object.keys(p.palette).filter((k) => !k.startsWith('//') && !ROLES.includes(k))
    assert.deepEqual(extra, [], `${f} palette carries role(s) the generator never reads: ${extra.join(', ')}`)
    for (const [fg, bg] of PAIRS) {
      const r = ratio(p.palette[fg], p.palette[bg])
      assert.ok(r >= 4.5, `${f}: ${fg} on ${bg} is ${r.toFixed(2)}:1, below the 4.5:1 floor the lint enforces — a preset that cannot pass is a preset nobody can use`)
    }
  }
})

check('AG5 importing the generator writes nothing (the main guard is what makes the lint\'s import safe)', () => {
  const tmp = mkdtempSync(join(tmpdir(), 'rs-gen-import-'))
  try {
    mkdirSync(join(tmp, 'assets'), { recursive: true })
    writeFileSync(join(tmp, 'assets', 'generate.mjs'), readFileSync(GEN, 'utf8'))
    writeFileSync(join(tmp, 'assets', 'manifest.json'), JSON.stringify(manifest))
    // Import it the way the lint does, from a different process with a different argv[1].
    execFileSync('node', ['--input-type=module', '-e', `await import(${JSON.stringify(`file://${join(tmp, 'assets', 'generate.mjs')}`)})`], { encoding: 'utf8' })
    const after = readdirSync(join(tmp, 'assets')).sort()
    assert.deepEqual(after, ['generate.mjs', 'manifest.json'],
      `importing the generator wrote into the tree: found ${after.join(', ')} — the lint imports this file on every CI run, so an import must never have side effects`)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

check('AG6 brand text is XML-escaped (one ampersand cannot produce a broken SVG)', () => {
  const hostile = JSON.parse(JSON.stringify(manifest))
  hostile.brand.name = 'A & B'
  hostile.brand.tagline = '<script>alert(1)</script>'
  const svg = render(hostile)['banner.svg']
  assert.ok(svg.includes('A &amp; B'), 'an ampersand in the brand name must be escaped')
  assert.ok(!svg.includes('<script>'), 'markup in a manifest string must never reach the document raw')
  assert.ok(svg.includes('&lt;script&gt;') || svg.includes('&lt;SCRIPT&gt;'), 'the escaped form should be present instead')
})

check('AG7 the geometry is fixed (changing it re-renders every governed repo)', () => {
  assert.deepEqual(
    { width: GEOMETRY.width, rootHeight: GEOMETRY.rootHeight, folderHeight: GEOMETRY.folderHeight, pillHeight: GEOMETRY.pillHeight },
    { width: 1200, rootHeight: 300, folderHeight: 150, pillHeight: 26 },
    'the banner geometry changed: every repo governed by this generator would re-render differently on its next run',
  )
  assert.deepEqual(PILL_SCHEMES, ['accent', 'alt'], 'the pill schemes are part of the manifest contract')
  assert.equal(ROLES.length, 15, 'the palette role set is part of the manifest contract')
  const svg = render(manifest)['banner.svg']
  assert.ok(svg.includes('width="1200" height="300"'), 'the root banner is 1200x300')
  assert.ok(render(manifest)['banners/src.svg'].includes('width="1200" height="150"'), 'a folder banner is 1200x150')
})

check('AG9 the wordmark fits the canvas at any brand-name length', () => {
  // The original artwork was drawn around a seven-letter brand. A real repository name is
  // longer, and a wordmark that runs off a 1200px canvas is not a rendering bug anyone notices
  // until it is on their front page. Type is fitted, never clipped.
  const sizeOf = (svg) => Number(svg.match(/font-size="(\d+)" font-weight="800"/)[1])
  const barOf = (svg) => { const m = svg.match(/<rect x="([\d.]+)" y="170" width="(\d+)"/); return { x: Number(m[1]), w: Number(m[2]) } }
  const withName = (name) => render({ ...manifest, brand: { ...manifest.brand, name } })['banner.svg']
  const short = withName('ACME')
  assert.equal(sizeOf(short), 112, 'a short name keeps the design size')
  for (const name of ['ACME', 'REPO-STANDARD-TOOLKIT', 'A-VERY-LONG-PROJECT-NAME-INDEED-YES']) {
    const svg = withName(name)
    const size = sizeOf(svg), bar = barOf(svg)
    const width = name.length * size * 0.62 + (name.length - 1) * 10
    assert.ok(width <= 1040, `"${name}" renders ${Math.round(width)}px wide at size ${size}, past the 1200px canvas`)
    assert.ok(bar.x >= 0 && bar.x + bar.w <= 1200, `"${name}": the accent bar (x=${bar.x} w=${bar.w}) must stay on the canvas`)
    assert.ok(size >= 12, `"${name}": the wordmark must stay legible`)
  }
  // Folder titles are monospace and can be deep paths; the same rule applies.
  const deep = render({ ...manifest, banners: [{ slug: 'deep', title: 'apps/api/app/services/copilot/handlers/', desc: 'x' }] })['banners/deep.svg']
  const titleSize = Number(deep.match(/font-size="(\d+)" font-weight="700"/)[1])
  assert.ok('apps/api/app/services/copilot/handlers/'.length * titleSize * 0.6 <= 1040, 'a deep path title must be fitted, not clipped')
})

// The sub-text runs (root tagline, folder description) are the ones that actually overflowed:
// the solver held tracking fixed and clamped size up to a readable floor, so past a certain
// length it returned a size the width budget could not pay for and the centred line ran off BOTH
// edges. Every number in the file still looked reasonable, which is why only a rendered banner
// caught it. Both runs render UPPERCASE, so they are measured at the uppercase advance.
const UPPER_ADVANCE = 0.62
// The LAST tracked run in either banner is the one under test: a folder banner also carries the
// eyebrow at the top, which is a fixed size and not fitted to anything.
const subRun = (svg) => {
  const all = [...svg.matchAll(/font-size="([\d.]+)" font-weight="600" letter-spacing="([\d.]+)" fill="[^"]*">([^<]*)</g)]
  const m = all[all.length - 1]
  return { size: Number(m[1]), tracking: Number(m[2]), text: m[3] }
}
const runWidth = ({ size, tracking, text }) => text.length * size * UPPER_ADVANCE + Math.max(0, text.length - 1) * tracking

check('AG10 a tagline of any length stays inside the banner, and shrinks tracking before size', () => {
  const word = 'verdict '
  for (const len of [12, 40, 60, 80, 107, 120, 139]) {
    const tagline = word.repeat(Math.ceil(len / word.length)).slice(0, len).trim()
    const run = subRun(render({ ...manifest, brand: { ...manifest.brand, tagline } })['banner.svg'])
    const w = runWidth(run)
    assert.ok(w <= 1040, `a ${tagline.length}-character tagline renders ${Math.round(w)}px wide at size ${run.size}/tracking ${run.tracking}, past the 1040px line. This is the overflow that ran off both edges of a centred banner`)
    assert.ok(run.size >= 12, `a ${tagline.length}-character tagline must stay legible, got ${run.size}px`)
  }
  // The lever the old solver never pulled: at a length that cannot afford the design's tracking,
  // tracking is what gets spent, and the text stays LARGER than the readable floor as a result.
  const long = subRun(render({ ...manifest, brand: { ...manifest.brand, tagline: 'x'.repeat(107) } })['banner.svg'])
  assert.ok(long.tracking < 7, `a tagline too long for the design's tracking must lose tracking first, got ${long.tracking}`)
  assert.ok(long.size > 12, `spending tracking must buy back size, so the line beats the bare floor; got ${long.size}px`)
})

check('AG11 a tagline that cannot fit at a readable size REFUSES, rather than rendering it clipped', () => {
  const tooLong = 'x'.repeat(200)
  assert.throws(() => render({ ...manifest, brand: { ...manifest.brand, tagline: tooLong } }),
    /cannot fit a 1040px line at a readable size/,
    'past the floor at zero tracking there is no size left to spend, and a banner that silently clips the repo\'s own description tells the same lie as a stale pill')
  // The refusal has to say what would fit, or it is a dead end rather than an instruction.
  try { render({ ...manifest, brand: { ...manifest.brand, tagline: tooLong } }) } catch (e) {
    assert.match(e.message, /\d+ characters is the most it holds/, 'the refusal must name the length that would fit')
    assert.match(e.message, /brand\.tagline/, 'the refusal must name the manifest field it is about')
  }
})

check('AG12 a folder description is fitted on the same terms as the tagline', () => {
  for (const len of [20, 60, 100, 130]) {
    const desc = 'x'.repeat(len)
    const svg = render({ ...manifest, banners: [{ slug: 'd', title: 'src/', desc }] })['banners/d.svg']
    const run = subRun(svg)
    assert.ok(runWidth(run) <= 1040, `a ${len}-character folder description renders ${Math.round(runWidth(run))}px wide, past the 1040px line`)
    assert.ok(run.size >= 12, `a ${len}-character folder description must stay legible, got ${run.size}px`)
  }
  assert.throws(() => render({ ...manifest, banners: [{ slug: 'd', title: 'src/', desc: 'x'.repeat(200) }] }),
    /cannot fit a 1040px line at a readable size/, 'the same refusal applies to a folder description')
})

check('AG8 the version constant is in the shape sense-state greps for', () => {
  const m = readFileSync(GEN, 'utf8').match(/^export const REPO_STANDARD_ASSETS_VERSION = '([^'\n]+)'/m)
  assert.ok(m, "the generator must carry an `export const REPO_STANDARD_ASSETS_VERSION = '<semver>'` line — sense-state parses it to direct upgrade vs. downgrade")
  assert.equal(m[1], REPO_STANDARD_ASSETS_VERSION, 'the parsed constant must be the exported one')
  assert.match(m[1], /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/, 'the generator version must be valid semver')
  assert.ok(existsSync(join(ROOT, 'payload', 'assets', 'manifest.example.json')), 'the documented manifest shape ships beside the generator')
})

check('AG14 --check renders and compares WITHOUT writing, so an upgrade is a plan before it is a diff', () => {
  // The write used to come before the comparison. On an upgrade, a generator whose geometry moved
  // by one path command rewrote every SVG in the tree and the operator learned which ones from
  // `git diff`, after the bytes had landed on files they may have been holding uncommitted.
  const dir = mkdtempSync(join(tmpdir(), 'rs-gen-check-'))
  try {
    const manifest = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'manifest.example.json'), 'utf8'))
    // The assets sit UNDER the repo root here, which is the real layout: the generated markdown
    // lives in READMEs one level up, and a check that never looked at them was the defect.
    mkdirSync(join(dir, 'assets'), { recursive: true })
    writeFileSync(join(dir, 'assets', 'generate.mjs'), readFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), 'utf8'))
    const writeManifest = () => writeFileSync(join(dir, 'assets', 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`)
    writeManifest()
    const gen = (args = []) => {
      try { return { code: 0, out: execFileSync('node', [join(dir, 'assets', 'generate.mjs'), ...args], { cwd: dir, encoding: 'utf8' }) } }
      catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
    }
    // Every carrier written from the generator's OWN helpers, so the fixture can never drift into
    // testing a hand-typed approximation of the idiom.
    const rel = (fromDir, asset) => relative(fromDir, asset).split('\\').join('/')
    const writeCarriers = () => {
      writeFileSync(join(dir, 'README.md'), `${readmeBlock(manifest, { assets: 'assets' })}\n\nProse.\n`)
      for (const b of manifest.banners) {
        mkdirSync(join(dir, b.dir), { recursive: true })
        writeFileSync(join(dir, b.dir, 'README.md'), `${bannerH1({ title: b.title, desc: b.desc, to: rel(join(dir, b.dir), join(dir, 'assets', 'banners', `${b.slug}.svg`)), homepage: manifest.brand.homepage })}\n\nProse.\n`)
      }
    }
    // Nothing rendered yet, so every asset is NEW and --check must say so and write none of them.
    const first = gen(['--check'])
    assert.equal(first.code, 1, 'a run that would change the tree exits 1, so a caller can gate on it')
    assert.ok(first.out.includes('NOTHING was written'), `--check says plainly that it wrote nothing\n${first.out}`)
    assert.ok(first.out.includes('NEW'), `and lists each asset that would appear\n${first.out}`)
    assert.deepEqual(readdirSync(join(dir, 'assets')).sort(), ['generate.mjs', 'manifest.json'],
      '--check must leave the directory exactly as it found it: that is the whole point of it')
    // Apply the artwork AND the markdown, then --check again: the same manifest is now a no-op,
    // which is the sentence that makes an upgrade safe to approve.
    assert.equal(gen().code, 0, 'the real run writes')
    writeCarriers()
    const clean = gen(['--check'])
    assert.equal(clean.code, 0, `a tree already matching its manifest, artwork AND markdown, is exit 0\n${clean.out}`)
    // THREE halves now, not two. The DIRECTORY is compared as well as the render, because an
    // asset the manifest no longer produces is a change a plan has to carry: `--check` used to
    // answer "every asset on disk already matches this manifest" for a tree holding an orphan the
    // lint fails on.
    // FOUR halves now. The ENGINE is the first write the approved sequence performs, and a plan
    // that omitted it described a change set beginning one write later than the real one.
    assert.ok(clean.out.includes('no-op in the engine, the artwork, the directory, and the markdown'), `and says so about all four halves\n${clean.out}`)
    // A changed manifest is reported as CHANGED, and still nothing is written.
    const before = readFileSync(join(dir, 'assets', 'banner.svg'), 'utf8')
    manifest.brand.tagline = 'A different tagline entirely.'
    writeManifest()
    const moved = gen(['--check'])
    assert.equal(moved.code, 1, 'a manifest that moves an asset exits 1')
    assert.ok(/CHANGED\s+\S*banner\.svg/.test(moved.out), `naming the asset that would move\n${moved.out}`)
    assert.equal(readFileSync(join(dir, 'assets', 'banner.svg'), 'utf8'), before,
      'and the bytes on disk are untouched until the plan is applied')
    assert.ok(moved.out.includes('generated markdown, compared byte for byte'), `the plan compares the pages carrying generated markup\n${moved.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('AG15 --check catches a MARKDOWN-ONLY manifest edit, which used to report a no-op', () => {
  /*
   * The exit code came from SVG output alone. A pill `href`, a `brand.homepage`, a badge `href`
   * and a banner `dir` each render byte-identical artwork and each move markdown the lint
   * compares character for character. All four answered "every asset on disk already matches this
   * manifest, so a run would be a no-op", and the very next lint run failed on the block: the
   * operator agreed to nothing and got a red build. Each case is asserted separately, because one
   * of them passing is not evidence about the other three.
   */
  const dir = mkdtempSync(join(tmpdir(), 'rs-gen-md-'))
  try {
    const base = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'manifest.example.json'), 'utf8'))
    mkdirSync(join(dir, 'assets'), { recursive: true })
    writeFileSync(join(dir, 'assets', 'generate.mjs'), readFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), 'utf8'))
    const rel = (fromDir, asset) => relative(fromDir, asset).split('\\').join('/')
    const put = (m) => {
      writeFileSync(join(dir, 'assets', 'manifest.json'), `${JSON.stringify(m, null, 2)}\n`)
      writeFileSync(join(dir, 'README.md'), `${readmeBlock(m, { assets: 'assets' })}\n\nProse.\n`)
      for (const b of m.banners) {
        mkdirSync(join(dir, b.dir), { recursive: true })
        writeFileSync(join(dir, b.dir, 'README.md'), `${bannerH1({ title: b.title, desc: b.desc, to: rel(join(dir, b.dir), join(dir, 'assets', 'banners', `${b.slug}.svg`)), homepage: m.brand.homepage })}\n\nProse.\n`)
      }
    }
    const gen = (args = []) => {
      try { return { code: 0, out: execFileSync('node', [join(dir, 'assets', 'generate.mjs'), ...args], { cwd: dir, encoding: 'utf8' }) } }
      catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
    }
    put(base)
    assert.equal(gen().code, 0, 'render the artwork once')
    assert.equal(gen(['--check']).code, 0, 'and the baseline is genuinely a no-op, or nothing below means anything')
    const svgsBefore = JSON.stringify(readdirSync(join(dir, 'assets')).sort())
    const mutations = [
      ['a pill href', (m) => { m.pills[0].href = 'docs/versions.md' }],
      ['brand.homepage', (m) => { m.brand.homepage = 'https://example.invalid/moved' }],
      ['a badge href', (m) => { m.badges[0].href = 'https://example.invalid/ci' }],
      ['a banner dir', (m) => { m.banners[0].dir = 'source' }],
    ]
    for (const [what, mutate] of mutations) {
      const m = JSON.parse(JSON.stringify(base))
      mutate(m)
      // Only the MANIFEST moves. Every carrier on disk stays exactly as the baseline wrote it,
      // which is the state a real operator is in the moment after editing the manifest.
      writeFileSync(join(dir, 'assets', 'manifest.json'), `${JSON.stringify(m, null, 2)}\n`)
      const r = gen(['--check'])
      assert.equal(r.code, 1, `changing ${what} moves generated markdown, so --check must exit 1 rather than calling it a no-op\n${r.out}`)
      assert.ok(/(CHANGED|MISSING)\s+\S*README\.md/.test(r.out), `and must NAME the carrier that no longer matches (${what})\n${r.out}`)
      assert.equal(JSON.stringify(readdirSync(join(dir, 'assets')).sort()), svgsBefore, `--check still writes nothing (${what})`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('AG16 --assets-dir and --repo let a NEW generator plan an OLD target without writing to it', () => {
  /*
   * To find out what an upgrade would do, a run has to ask the NEW generator about an OLD target.
   * The only way to do that was to copy the new generator over the old one first, which is the
   * write the check exists to preview. Worse: a generator predating `--check` ignores the flag
   * and WRITES, so a scaffold planning an upgrade through the installed generator performed the
   * upgrade in order to preview it.
   */
  const target = mkdtempSync(join(tmpdir(), 'rs-gen-target-'))
  try {
    const m = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'manifest.example.json'), 'utf8'))
    mkdirSync(join(target, 'assets'), { recursive: true })
    writeFileSync(join(target, 'assets', 'manifest.json'), `${JSON.stringify(m, null, 2)}\n`)
    writeFileSync(join(target, 'README.md'), '# Not the generated H1\n\nProse.\n')
    const before = readdirSync(join(target, 'assets')).sort().join(',')
    // The generator under test is the PAYLOAD one, running from this repo, never copied in.
    let code = 0
    try { execFileSync('node', [join(ROOT, 'payload', 'assets', 'generate.mjs'), '--check', '--assets-dir', join(target, 'assets'), '--repo', target], { encoding: 'utf8' }) }
    catch (e) { code = e.status }
    assert.equal(code, 1, 'the target does not match its manifest, so the plan exits 1')
    assert.equal(readdirSync(join(target, 'assets')).sort().join(','), before,
      'and NOTHING was written into the target: that is what makes it a plan rather than the upgrade itself')
    assert.equal(readFileSync(join(target, 'README.md'), 'utf8'), '# Not the generated H1\n\nProse.\n',
      'including the markdown carriers, which are read and never rewritten')
  } finally { rmSync(target, { recursive: true, force: true }) }
})

/*
 * ───────────────────────────────────────────── THE CLI MATRIX (AG17, AG18, AG19, AG20)
 *
 * AG17  Every way an argument can be wrong, because the flag that stops this program writing was
 *       a substring test. `process.argv.includes('--check')` means a TYPO is not an error, it is
 *       a write: `--chek` rendered every asset and wrote it, and so did `--CHECK`, and so did any
 *       flag this program has never heard of. The operator who typed the flag was asking for the
 *       one behaviour they did not get, on a working tree nothing had told them to check.
 * AG18  A DELETION is half a plan, and this program could not express one. It wrote the keys the
 *       manifest renders and nothing else, so a removed pill, a removed banner or a renamed slug
 *       left the old SVG on disk forever; `--check` compared the render to what it was about to
 *       write and never to the DIRECTORY, so it answered "every asset already matches" for a tree
 *       carrying an orphan the lint fails on.
 * AG19  The front page is `docs.readme`, not a constant. On a repo serving .github/README.md the
 *       preview reported the root README missing and exited 1: a false failure on a correct repo,
 *       whose obvious fix would have created a second front page.
 * AG20  A path with a space is not a markdown destination unless it is bracketed (CommonMark 6.6).
 */
const genRepo = (extra = {}) => {
  const dir = mkdtempSync(join(tmpdir(), 'rs-gen-cli-'))
  const assets = extra.assetsDir ?? 'assets'
  mkdirSync(join(dir, assets), { recursive: true })
  writeFileSync(join(dir, assets, 'generate.mjs'), readFileSync(GEN, 'utf8'))
  const m = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'manifest.example.json'), 'utf8'))
  if (extra.editManifest) extra.editManifest(m)
  writeFileSync(join(dir, assets, 'manifest.json'), `${JSON.stringify(m, null, 2)}\n`)
  if (extra.config) writeFileSync(join(dir, '.repo-standard.json'), `${JSON.stringify(extra.config, null, 2)}\n`)
  for (const [rel, body] of Object.entries(extra.files ?? {})) {
    mkdirSync(join(dir, rel.split('/').slice(0, -1).join('/') || '.'), { recursive: true })
    writeFileSync(join(dir, rel), body)
  }
  return { dir, assets, manifest: m }
}
const genRun = (dir, assets, args = []) => {
  try { return { code: 0, out: execFileSync('node', [join(dir, assets, 'generate.mjs'), ...args], { cwd: dir, encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}
for (const [id, argv, needle] of [
  ['typo', ['--chek'], 'unknown argument "--chek"'],
  ['case', ['--CHECK'], 'unknown argument "--CHECK"'],
  ['positional', ['--check', 'extra'], 'unexpected argument "extra"'],
  ['duplicate', ['--check', '--check'], 'is given more than once'],
  ['missing-value', ['--assets-dir'], 'expects a value'],
  ['unknown-valued', ['--out', 'x'], 'unknown argument "--out"'],
]) {
  check(`AG17-${id} a bad argument exits 2 and writes NOTHING (the flag that stops the write is one of them)`, () => {
    const { dir, assets } = genRepo()
    try {
      const before = readdirSync(join(dir, assets)).sort()
      const r = genRun(dir, assets, argv)
      assert.equal(r.code, 2, `expected exit 2\n${r.out}`)
      assert.ok(r.out.includes(needle), `and the refusal names what was wrong: expected "${needle}"\n${r.out}`)
      assert.ok(r.out.includes('Nothing was written'), `and says so out loud\n${r.out}`)
      assert.deepEqual(readdirSync(join(dir, assets)).sort(), before,
        'a program that writes on an argument it does not understand is one nobody can preview')
    } finally { rmSync(dir, { recursive: true, force: true }) }
  })
}
check('AG18 an asset the manifest no longer produces is planned as a DELETE and removed on apply', () => {
  const { dir, assets } = genRepo()
  try {
    assert.equal(genRun(dir, assets).code, 0, 'render the baseline')
    const pillDir = join(dir, assets, 'pills')
    const before = readdirSync(pillDir)
    assert.ok(before.length > 0, 'the example manifest declares pills, or this case proves nothing')
    // Drop one pill: the artwork it renders is unchanged, and its file is now an orphan.
    const mPath = join(dir, assets, 'manifest.json')
    const m = JSON.parse(readFileSync(mPath, 'utf8'))
    const dropped = m.pills.pop().file
    writeFileSync(mPath, `${JSON.stringify(m, null, 2)}\n`)
    const plan = genRun(dir, assets, ['--check'])
    assert.equal(plan.code, 1, `a tree holding an asset the manifest does not produce is not a no-op\n${plan.out}`)
    assert.ok(plan.out.includes('DELETE') && plan.out.includes(dropped),
      `and the plan NAMES the file it would remove, because a deletion is destructive and has to be approved\n${plan.out}`)
    assert.ok(readdirSync(pillDir).includes(dropped), '--check still writes nothing, and deletes nothing')
    assert.ok(plan.out.includes('DELETES the assets listed above'), `and it says the apply is destructive\n${plan.out}`)
    assert.equal(genRun(dir, assets).code, 0, 'the apply run')
    assert.ok(!readdirSync(pillDir).includes(dropped),
      'the approved deletion is carried out: without it the lint fails forever on an orphan no run could remove')
    // The ARTWORK and the DIRECTORY are now settled. The markdown half of this fixture was never
    // written (no README carries the block), so it is still reported as a carrier that does not
    // match, which is the other half of the plan doing its job rather than a leftover deletion.
    const after = genRun(dir, assets, ['--check'])
    assert.ok(!after.out.includes('DELETE'), `no deletion is left to plan\n${after.out}`)
    assert.ok(after.out.includes('the directory holds nothing the manifest does not produce'),
      `and the directory is reported settled in its own words\n${after.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})
check('AG19 the front page is docs.readme, not a hardcoded root README.md', () => {
  const { dir, assets } = genRepo({
    config: { version: 1, docs: { readme: '.github/README.md' }, assets: { dir: 'assets' } },
    files: { '.github/README.md': '# placeholder\n' },
  })
  try {
    const r = genRun(dir, assets, ['--check'])
    assert.ok(r.out.includes('front page: .github/README.md'),
      `the preview names the page it is comparing against, and reads it from the config the lint reads\n${r.out}`)
    assert.ok(!r.out.includes('MISSING   README.md'),
      `a repo serving .github/README.md is not a repo missing a README, and reporting one is a false failure whose fix creates a second front page\n${r.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})
check('AG20 an assets directory with a space renders a destination markdown can actually read', () => {
  const { dir, assets } = genRepo({ assetsDir: 'my assets' })
  try {
    const r = genRun(dir, assets)
    assert.equal(r.code, 0, `the render succeeds\n${r.out}`)
    const h1 = bannerH1({ title: 'x', desc: 'y', to: 'my assets/banner.svg' })
    assert.ok(h1.includes('(<my assets/banner.svg>)'),
      `CommonMark 6.6 ends an unbracketed destination at the first whitespace, so a raw space renders the banner as literal text. Got: ${h1}`)
    assert.equal(bannerH1({ title: 'x', desc: 'y', to: '.github/assets/banner.svg' }), '# ![x: y](.github/assets/banner.svg)',
      'and a path with no space keeps the exact bytes every governed repo already carries')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

/*
 * ──────────────────────────── PHYSICAL CONTAINMENT AND A COMPLETE CHANGE SET (AG21-AG26)
 *
 * This program WRITES. An external audit found that everything deciding where it writes was either
 * unchecked or invisible: `--assets-dir` was never held to `--repo`, a symlinked asset dropped out
 * of the directory scan and became a write-through, the engine's own replacement was missing from
 * the plan and from the exit code, and a removed banner left a page pointing at deleted artwork
 * with nothing anywhere reporting it. Each case below is one of those, red before the fix.
 */
check('AG21 an --assets-dir outside --repo is refused, and nothing outside the repo is written or deleted', () => {
  const { dir, assets } = genRepo()
  const away = mkdtempSync(join(tmpdir(), 'rs-gen-away-'))
  try {
    writeFileSync(join(away, 'manifest.json'), readFileSync(join(dir, assets, 'manifest.json'), 'utf8'))
    writeFileSync(join(away, 'precious.svg'), '<svg>do not touch</svg>')
    const before = readdirSync(away).sort()
    const r = genRun(dir, assets, ['--assets-dir', away, '--repo', dir])
    assert.equal(r.code, 2, `writing into a directory the named repo does not own is a refusal\n${r.out}`)
    assert.ok(r.out.includes('not inside --repo'), `and it says which rule stopped it\n${r.out}`)
    assert.deepEqual(readdirSync(away).sort(), before,
      'nothing was written, and above all nothing was DELETED: this program removes assets the manifest no longer produces, and it was doing that outside the repo on request')
    assert.equal(readFileSync(join(away, 'precious.svg'), 'utf8'), '<svg>do not touch</svg>', 'the bytes outside the repo are untouched')
  } finally { rmSync(dir, { recursive: true, force: true }); rmSync(away, { recursive: true, force: true }) }
})

check('AG22 a symlinked asset is an explicit error, and an apply never writes through one', () => {
  const { dir, assets } = genRepo()
  const away = mkdtempSync(join(tmpdir(), 'rs-gen-away-'))
  try {
    assert.equal(genRun(dir, assets).code, 0, 'render the real tree first, so the link replaces something that was there')
    const target = join(away, 'target.svg')
    writeFileSync(target, '<svg>the file this repo does not govern</svg>')
    rmSync(join(dir, assets, 'banner.svg'))
    symlinkSync(target, join(dir, assets, 'banner.svg'))
    for (const argv of [['--check'], []]) {
      const r = genRun(dir, assets, argv)
      assert.equal(r.code, 2, `both the plan and the apply refuse it (${argv.join(' ') || 'apply'})\n${r.out}`)
      assert.ok(r.out.includes('not regular files'), `and each names the entry\n${r.out}`)
      assert.equal(readFileSync(target, 'utf8'), '<svg>the file this repo does not govern</svg>',
        `and the link's target is untouched (${argv.join(' ') || 'apply'}): rendering through it is the write this rule exists to stop`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }); rmSync(away, { recursive: true, force: true }) }
})

check('AG23 a differing installed engine is ENGINE CHANGED, is named FIRST, and reaches the exit code', () => {
  /*
   * On the real target the payload generator and the installed one had different SHA-256 values and
   * the plan said "nothing changes". The sequence the scaffold journey then follows copies this
   * engine over that one before running it, so the first write in the approved change set was the
   * one write the change set did not mention, and every asset line under it was rendered by an
   * engine the operator had not been told was arriving.
   */
  const { dir, assets } = genRepo()
  try {
    assert.equal(genRun(dir, assets).code, 0, 'a rendered, matching tree is the baseline: without it this proves nothing')
    writeFileSync(join(dir, 'README.md'), readmeBlock(JSON.parse(readFileSync(join(dir, assets, 'manifest.json'), 'utf8')), { assets }) + '\n')
    const m = JSON.parse(readFileSync(join(dir, assets, 'manifest.json'), 'utf8'))
    for (const b of m.banners ?? []) {
      if (!b.dir) continue
      mkdirSync(join(dir, b.dir), { recursive: true })
      writeFileSync(join(dir, b.dir, 'README.md'), `${bannerH1({ title: b.title, desc: b.desc, to: relative(join(dir, b.dir), join(dir, assets, 'banners', `${b.slug}.svg`)).split('\\').join('/'), homepage: m.brand.homepage })}\n\nProse.\n`)
    }
    const quiet = { code: 0, out: '' }
    try { quiet.out = execFileSync('node', [GEN, '--check', '--assets-dir', join(dir, assets), '--repo', dir], { encoding: 'utf8' }) }
    catch (e) { quiet.code = e.status; quiet.out = `${e.stdout || ''}${e.stderr || ''}` }
    assert.equal(quiet.code, 0, `identical engine, matching tree: this is the "nothing changes" that has to stay honest\n${quiet.out}`)
    // Now the installed engine differs by one byte of comment, which is exactly the shape a real
    // upgrade has: same behaviour on this manifest, different bytes.
    writeFileSync(join(dir, assets, 'generate.mjs'), `${readFileSync(GEN, 'utf8')}\n// a local edit\n`)
    let r = { code: 0, out: '' }
    try { r.out = execFileSync('node', [GEN, '--check', '--assets-dir', join(dir, assets), '--repo', dir], { encoding: 'utf8' }) }
    catch (e) { r = { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
    assert.equal(r.code, 1, `a plan whose first write is the engine itself is not a no-op\n${r.out}`)
    assert.ok(r.out.includes('ENGINE CHANGED'), `and the engine is named in the change set\n${r.out}`)
    assert.ok(r.out.includes('of which one is the generator itself'), `and counted in the total\n${r.out}`)
    const lines = r.out.split('\n')
    assert.ok(lines.findIndex((l) => l.includes('ENGINE CHANGED')) < lines.findIndex((l) => /^ {2}(NEW|CHANGED|DELETE)/.test(l) || l.includes('every asset on disk')),
      `and it comes FIRST, because everything under it was rendered by this engine rather than by the installed one\n${r.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('AG24 removing a banner reports the page it headed as STALE, in the plan and after the apply', () => {
  const { dir, assets } = genRepo()
  try {
    assert.equal(genRun(dir, assets).code, 0, 'render first')
    const m = JSON.parse(readFileSync(join(dir, assets, 'manifest.json'), 'utf8'))
    writeFileSync(join(dir, 'README.md'), readmeBlock(m, { assets }) + '\n')
    const gone = m.banners[0]
    mkdirSync(join(dir, gone.dir), { recursive: true })
    const carrier = join(dir, gone.dir, 'README.md')
    writeFileSync(carrier, `${bannerH1({ title: gone.title, desc: gone.desc, to: relative(join(dir, gone.dir), join(dir, assets, 'banners', `${gone.slug}.svg`)).split('\\').join('/'), homepage: m.brand.homepage })}\n\nProse.\n`)
    const before = readFileSync(carrier, 'utf8')
    m.banners = m.banners.filter((b) => b !== gone)
    writeFileSync(join(dir, assets, 'manifest.json'), `${JSON.stringify(m, null, 2)}\n`)
    const plan = genRun(dir, assets, ['--check'])
    assert.equal(plan.code, 1, `the plan is not a no-op\n${plan.out}`)
    assert.ok(plan.out.includes('DELETE'), `it deletes the artwork\n${plan.out}`)
    assert.ok(plan.out.includes('STALE') && plan.out.includes(`${gone.dir}/README.md`),
      `and it names the page that deletion breaks, which every manifest-driven loop was blind to\n${plan.out}`)
    const applied = genRun(dir, assets)
    assert.equal(applied.code, 0, `the apply succeeds\n${applied.out}`)
    assert.ok(applied.out.includes('STILL STALE'), `and says the page is still stale afterwards: this program writes artwork and never edits a page\n${applied.out}`)
    assert.equal(readFileSync(carrier, 'utf8'), before, 'and it did not touch the page')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('AG25 manifest text cannot inject an SVG attribute, whichever quote it carries', () => {
  /*
   * The shared escape handled `&`, `<` and `>`, which is right for a text node and wrong inside
   * `aria-label="..."`, where a quote is what ends the attribute. A tagline of `safe" onload="…`
   * rendered an event handler into every banner and every pill, from a hand-edited manifest, and
   * the committed lint then re-rendered the same injected bytes and reported zero drift.
   */
  const manifest = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'manifest.example.json'), 'utf8'))
  manifest.brand.tagline = 'safe" onload="alert(1)'
  manifest.brand.name = "it's fine"
  manifest.pills = [{ file: 'x.svg', label: 'A"B', value: "C'D", scheme: 'accent' }]
  const out = render(manifest)
  for (const [rel, svg] of Object.entries(out)) {
    for (const attr of svg.matchAll(/aria-label="([^"]*)"/g)) {
      assert.ok(!/[<>]/.test(attr[1]), `${rel}: an attribute value never carries raw markup characters`)
    }
    /*
     * The whole test: no ATTRIBUTE this generator did not write may exist anywhere in the document.
     * Quoted values are blanked first, on purpose. `onload=` still appears as TEXT inside the
     * escaped `aria-label`, which is exactly right and is what escaping means; what must not exist
     * is a second attribute outside the quotes. Asserting on the raw bytes would fail the fix.
     */
    const markup = svg.replace(/"[^"]*"/g, '""')
    for (const name of [...markup.matchAll(/([a-zA-Z-]+)\s*=/g)].map((m) => m[1])) {
      assert.ok(!/^on/i.test(name), `${rel}: manifest text produced an "${name}" attribute, which is text becoming markup\n${markup.slice(0, 300)}`)
    }
  }
  /*
   * The APOSTROPHE is deliberately left alone, and the decision is locked here rather than left to
   * be re-litigated. Every attribute this generator writes is double-quoted, so a `'` inside one is
   * ordinary text; escaping it would move the rendered bytes of every governed repository whose
   * brand text contains one, on upgrade, for no property gained. The invariant that makes it safe
   * is that no attribute here is single-quoted, and this is the test that notices if one becomes so.
   */
  const apostrophe = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'manifest.example.json'), 'utf8'))
  apostrophe.brand.name = "Someone's Toolkit"
  const rendered = render(apostrophe)
  for (const [rel, svg] of Object.entries(rendered)) {
    assert.ok(!/=\s*'/.test(svg.replace(/"[^"]*"/g, '""')),
      `${rel}: no attribute here may be single-quoted, because an unescaped apostrophe in brand text would end it`)
  }
  assert.ok(rendered['banner.svg'].includes("Someone's Toolkit"),
    'an apostrophe survives as itself, so an ordinary brand name renders the same bytes it always did')
  // A markdown LABEL is its own context: a bracket closes it early.
  const label = bannerH1({ title: 'a]b', desc: 'c[d', to: 'assets/banner.svg' })
  assert.ok(label.includes('a\\]b') && label.includes('c\\[d'),
    `a bracket in alt text closes the label and turns the rest of the line into prose. Got: ${label}`)
})

check('AG26 a symlinked manifest is refused before anything is rendered from it', () => {
  const { dir, assets } = genRepo()
  const away = mkdtempSync(join(tmpdir(), 'rs-gen-away-'))
  try {
    renameSync(join(dir, assets, 'manifest.json'), join(away, 'manifest.json'))
    symlinkSync(join(away, 'manifest.json'), join(dir, assets, 'manifest.json'))
    const r = genRun(dir, assets, ['--check'])
    assert.equal(r.code, 2, `the declaration everything is rendered from has to be the one this repo commits\n${r.out}`)
    assert.ok(r.out.includes('not a regular file'), `and the refusal says what it found\n${r.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }); rmSync(away, { recursive: true, force: true }) }
})

/*
 * HOW A REPO ADDRESSES THIS FILE MUST NOT CHANGE WHAT IT DOES, and for one release it decided
 * everything. A marketplace installed from a directory source reaches its plugins through a
 * symlink, so `${CLAUDE_PLUGIN_ROOT}` is a link to the checkout and
 * `node <link>/assets/generate.mjs --check` is the ordinary way the scaffold journey previews an
 * upgrade. The run-as-main guard compared `import.meta.url`, which Node canonicalises before it
 * runs a script, against `process.argv[1]`, which keeps the path as it was INVOKED. Through a link
 * the two spellings differ, the CLI body never ran, and the program exited 0 having printed
 * nothing. Exit 0 and an empty plan is what this program prints for a repo that needs no work, so
 * the silence was read as "nothing changes" and a new engine was copied over the old one on the
 * strength of it. The three checks below hold the three halves of the fix: a preview through a
 * link is a real preview, a run through a link really renders, and an IMPORT through a link is
 * still not a run.
 */
const linkedRepo = (prefix) => {
  const { dir, assets } = genRepo()
  const linkDir = mkdtempSync(join(tmpdir(), prefix))
  symlinkSync(dir, join(linkDir, 'plugin-root'))
  return { dir, assets, link: join(linkDir, 'plugin-root'), clean: () => { rmSync(dir, { recursive: true, force: true }); rmSync(linkDir, { recursive: true, force: true }) } }
}

check('AG27 --check through a symlinked parent is the same preview as --check through the physical path', () => {
  const { dir, assets, link, clean } = linkedRepo('rs-gen-link-')
  try {
    const run = (base) => {
      try { return { code: 0, out: execFileSync('node', [join(base, assets, 'generate.mjs'), '--check', '--repo', dir], { cwd: dir, encoding: 'utf8' }) } }
      catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
    }
    const phys = run(dir)
    const sym = run(link)
    assert.ok(phys.out.length > 0, `the physical path must print a plan for this fixture, or the comparison below proves nothing\n${phys.out}`)
    assert.ok(sym.out.length > 0,
      `--check through a symlinked parent printed nothing at all, while the physical path printed ${phys.out.length} byte(s). An empty preview is not "nothing changes", it is a preview that never ran, and a caller cannot tell those apart`)
    assert.match(sym.out, /^generate v\S+ --check:/,
      `--check through a symlinked parent must open with the recognizable plan preamble, so a caller can refuse output it cannot read rather than treating it as an empty change set. Got: ${JSON.stringify(sym.out.slice(0, 200))}`)
    assert.equal(sym.code, phys.code,
      `the exit class must not depend on how this file was addressed. Physical exited ${phys.code}, symlinked exited ${sym.code}, and the difference between 1 and 0 here is the difference between "apply this" and "there is nothing to apply"`)
    assert.equal(sym.out, phys.out,
      `the plan must not depend on how this file was addressed\n--- physical ---\n${phys.out}\n--- symlinked ---\n${sym.out}`)
  } finally { clean() }
})

check('AG28 a real run through a symlinked parent renders the artwork rather than exiting 0 having done nothing', () => {
  const { dir, assets, link, clean } = linkedRepo('rs-gen-link-apply-')
  try {
    let code = 0
    try { execFileSync('node', [join(link, assets, 'generate.mjs')], { cwd: dir, encoding: 'utf8' }) }
    catch (e) { code = e.status }
    assert.equal(code, 0, 'an ordinary render addressed through a symlinked parent succeeds like any other')
    assert.ok(existsSync(join(dir, assets, 'banner.svg')),
      'a run addressed through a symlinked parent must actually write the artwork. Exiting 0 having written nothing is indistinguishable from a repo that was already up to date, which is the failure this holds')
  } finally { clean() }
})

check('AG29 importing through a symlinked parent still runs no CLI body and writes nothing', () => {
  /*
   * The other side of the same guard, and the one a realpath comparison could break. The committed
   * lint imports this module on every CI run, so a guard that grew MORE willing to call itself
   * "main" would start writing to a tree nobody asked it to touch. Importing through the link is
   * the topology most likely to trip a path comparison, so it is the one pinned here.
   */
  const { dir, assets, link, clean } = linkedRepo('rs-gen-link-import-')
  try {
    execFileSync('node', ['--input-type=module', '-e', `await import(${JSON.stringify(`file://${join(link, assets, 'generate.mjs')}`)})`], { encoding: 'utf8' })
    assert.deepEqual(readdirSync(join(dir, assets)).sort(), ['generate.mjs', 'manifest.json'],
      'importing the module rendered assets into the tree. The lint imports this file on every run, so an import that writes is an import that edits a repo mid-check')
  } finally { clean() }
})

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
