#!/usr/bin/env node
/*
 * test-voice-canon.mjs — the sweep and the gate enforce the SAME writing standard.
 *
 * WHY: harness/voice-scan.mjs finds what to rewrite; the payload lint's RS-prose decides whether
 * the build goes red. The lint ships into target repos as one self-contained file, so it cannot
 * import a shared rule module, which means the two lists are twins maintained by hand. A twin
 * that drifts is the worst possible outcome for this feature: the sweep reports a repo clean and
 * the gate fails it, or the sweep rewrites prose the gate never objected to. This test makes
 * that drift impossible to commit.
 *
 * Guards:
 *   VS1  the dash rules are identical in both files (labels, patterns, and the stated fix).
 *   VS2  the filler list is identical in both files, in the same order.
 *   VS3  the scan reaches are identical in both files.
 *   VS4  the engine finds a planted violation of every rule family, and exits 1.
 *   VS5  the engine and the lint agree on the same tree: both clean, then both red on one hit.
 *   VS6  released CHANGELOG history is out of scope in the engine, exactly as in the lint.
 *   VS7  exemptions and allowances are honored and PRINTED (an invisible exemption is a deleted
 *        rule), and an exemption covers only its own path.
 *   VS8  every payload file EXCEPT the Contributor Covenant template is profile-clean at
 *        scan:"all". That one is removed before the scan and is the single exemption this
 *        toolkit's payload costs a consumer; it is external text we will not rewrite. Every
 *        other file we put in someone's tree is clean, which is the claim worth guarding.
 *   VS9  the lint and harness/github-about.mjs derive the SAME tagline, wrapped ones included,
 *        so RS-about can never redden against the value the engine itself produced.
 *
 * Dependency-free: `node acceptance/test-voice-canon.mjs`.
 */
import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, cpSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const LINT_SRC = readFileSync(join(ROOT, 'payload', 'acceptance', 'test-repo-standard.mjs'), 'utf8')
const ENGINE_SRC = readFileSync(join(ROOT, 'harness', 'voice-scan.mjs'), 'utf8')
const ENGINE = join(ROOT, 'harness', 'voice-scan.mjs')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

// Pull a top-level array literal out of a source file by name, normalised so that formatting
// differences between the two files cannot masquerade as a rule difference.
const arrayLiteral = (src, name) => {
  const start = src.indexOf(`const ${name} = [`)
  assert.ok(start !== -1, `${name} not found`)
  let depth = 0, i = src.indexOf('[', start)
  for (; i < src.length; i++) {
    if (src[i] === '[') depth++
    else if (src[i] === ']') { depth--; if (depth === 0) break }
  }
  return src.slice(src.indexOf('[', start), i + 1).replace(/\s+/g, ' ').trim()
}

console.log('voice-canon standing test (the sweep and the gate enforce one standard)')

check('VS1 the dash rules are identical in the lint and the sweep engine', () => {
  assert.equal(arrayLiteral(ENGINE_SRC, 'PROSE_DASHES'), arrayLiteral(LINT_SRC, 'PROSE_DASHES'),
    'PROSE_DASHES differs between harness/voice-scan.mjs and the payload lint — the sweep would fix a different set of rules than the gate enforces')
})

check('VS2 the filler list is identical in the lint and the sweep engine', () => {
  assert.equal(arrayLiteral(ENGINE_SRC, 'PROSE_FILLER'), arrayLiteral(LINT_SRC, 'PROSE_FILLER'),
    'PROSE_FILLER differs between harness/voice-scan.mjs and the payload lint')
  // Anti-vacuity: an empty or truncated list would satisfy equality while enforcing nothing.
  const terms = arrayLiteral(LINT_SRC, 'PROSE_FILLER').split(',').length
  assert.ok(terms >= 13, `expected the full filler canon (parsed ${terms} terms) — refusing a vacuous pass`)
})

check('VS3 the scan reaches are identical in the lint and the sweep engine', () => {
  assert.equal(arrayLiteral(ENGINE_SRC, 'PROSE_SCANS'), arrayLiteral(LINT_SRC, 'PROSE_SCANS'),
    'PROSE_SCANS differs — the sweep would look in a different place than the gate')
})

// ── a fixture both tools can read ────────────────────────────────────────────────────────
const files = (over = {}) => ({
  '.repo-standard.json': JSON.stringify({
    version: 1,
    readme: { requireSections: ['usage'] },
    conventions: { minSections: 1 },
    prose: { profile: 'enterprise' },
    ...over.config,
  }, null, 2) + '\n',
  '.gitignore': '.env\n.env.*\n!.env.example\n',
  'README.md': ['# fixture', '', '**A fixture.**', '', '## Install', '', 'Clone it.', '',
    '## Usage', '', over.usage ?? 'Run it.', '', '## Contributing', '', 'PRs.', '', '## License', '', 'MIT.', ''].join('\n'),
  'CHANGELOG.md': ['# Changelog', '', 'Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).', '',
    '## [Unreleased]', '', '### Added', '', '- Something new.', '',
    '## [1.0.0] - 2026-01-01', '', '### Added', '', over.history ?? '- First cut.', ''].join('\n'),
  'CONVENTIONS.md': ['# Conventions', '', '## 1. Voice', '',
    'No em dash in any form, and none of `delve`, `utilize`, `leverage`, `in order to`,',
    '`worth noting`, `it should be noted`, `needless to say`, `as you can see`, `furthermore`,',
    '`moreover`, `a wide range of`, `a variety of`, or `state-of-the-art`.', '',
    'CHANGELOG follows Keep a Changelog (keepachangelog.com): Added / Changed / Deprecated /',
    'Removed / Fixed / Security. README follows standard-readme: Install, Usage, Contributing,',
    'License last.', ''].join('\n'),
  'SECURITY.md': '# Security\n\nReport privately.\n',
  'CONTRIBUTING.md': '# Contributing\n\nBe kind.\n',
  'CODE_OF_CONDUCT.md': '# Code of Conduct\n\nCovenant.\n',
  'LICENSE': 'MIT License\n\nCopyright (c) 2026 fixture\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software, provided the above copyright notice and this permission notice are included.\n',
  ...over.extra,
})

const build = (over) => {
  const tmp = mkdtempSync(join(tmpdir(), 'rs-voice-'))
  for (const [rel, content] of Object.entries(files(over))) {
    mkdirSync(join(tmp, dirname(rel)), { recursive: true })
    writeFileSync(join(tmp, rel), content)
  }
  mkdirSync(join(tmp, 'acceptance'), { recursive: true })
  writeFileSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
  return tmp
}
const runScan = (dir, extra = []) => {
  try { return { code: 0, out: execFileSync('node', [ENGINE, '--target', dir, ...extra], { encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}
const runLint = (dir) => {
  try { return { code: 0, out: execFileSync('node', [join(dir, 'acceptance', 'test-repo-standard.mjs')], { encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}
const withFixture = (over, fn) => { const d = build(over); try { fn(d) } finally { rmSync(d, { recursive: true, force: true }) } }

check('VS4 the engine finds a planted violation of every rule family and exits 1', () => {
  for (const [label, usage, needle] of [
    ['em dash', 'Run it — quickly.', 'em dash'],
    ['escape', 'Run it &mdash; quickly.', 'em dash escape'],
    ['spaced en dash', 'Run it – quickly.', 'spaced en dash'],
    ['filler', 'Utilize the runner.', 'utilize'],
    ['wrapped filler', 'Run it in\norder to see output.', 'in order to'],
  ]) {
    withFixture({ usage }, (d) => {
      const r = runScan(d)
      assert.equal(r.code, 1, `${label}: the engine should exit 1 on a hit\n${r.out}`)
      assert.ok(r.out.includes(needle), `${label}: the report should name the rule (${needle})\n${r.out}`)
      assert.ok(r.out.includes('README.md'), `${label}: the report should name the file\n${r.out}`)
    })
  }
})

check('VS5 the engine and the lint agree on the same tree (both clean, then both red)', () => {
  withFixture({}, (d) => {
    assert.equal(runScan(d).code, 0, 'the clean fixture should scan clean')
    assert.equal(runLint(d).code, 0, 'the clean fixture should pass the lint')
  })
  withFixture({ usage: 'Run it — quickly.' }, (d) => {
    assert.equal(runScan(d).code, 1, 'the engine must report the hit')
    const lint = runLint(d)
    assert.equal(lint.code, 1, 'the lint must fail on the same hit')
    assert.ok(lint.out.includes('RS-prose'), `the lint failure must be RS-prose\n${lint.out}`)
  })
})

check('VS6 released CHANGELOG history is out of scope in the engine, exactly as in the lint', () => {
  withFixture({ history: '- First cut — with a wide range of things.' }, (d) => {
    const scan = runScan(d)
    assert.equal(scan.code, 0, `history must not be swept\n${scan.out}`)
    assert.ok(scan.out.includes('record of what shipped'), `the engine must SAY it skipped history, never skip it silently\n${scan.out}`)
    assert.equal(runLint(d).code, 0, 'the lint must agree that released history is out of scope')
  })
})

check('VS7 exemptions and allowances are honored, printed, and narrow', () => {
  const exempt = { config: { prose: { profile: 'enterprise', scan: 'markdown', exempt: [{ path: 'vendor', why: 'reproduced verbatim' }] } } }
  withFixture({ ...exempt, extra: { 'vendor/notice.md': '# Notice\n\nUpstream — verbatim.\n' } }, (d) => {
    const r = runScan(d)
    assert.equal(r.code, 0, `an exempt path must not produce hits\n${r.out}`)
    assert.ok(r.out.includes('exempt: vendor') && r.out.includes('reproduced verbatim'),
      `every active exemption must print with its reason: an exemption nobody sees is a deleted rule\n${r.out}`)
  })
  withFixture({ ...exempt, extra: { 'vendor/notice.md': '# Notice\n\nUpstream — verbatim.\n', 'notes/x.md': '# Notes\n\nAlso — here.\n' } }, (d) => {
    const r = runScan(d)
    assert.equal(r.code, 1, 'an exemption must cover only its own path')
    assert.ok(r.out.includes('notes/x.md') && !r.out.includes('vendor/notice.md  ('), `only the un-exempt file should be reported\n${r.out}`)
  })
  const allow = { config: { prose: { profile: 'enterprise', allow: [{ term: 'leverage', why: 'the financial noun' }] } } }
  withFixture({ ...allow, usage: 'Leverage ratios are computed here.' }, (d) => {
    const r = runScan(d)
    assert.equal(r.code, 0, `an allowed term must not be reported\n${r.out}`)
    assert.ok(r.out.includes('allowed: "leverage"'), `every allowance must print\n${r.out}`)
  })
  withFixture({ ...allow, usage: 'Leverage ratios, and utilize the runner.' }, (d) => {
    assert.equal(runScan(d).code, 1, 'an allowance lifts one term, not the list')
  })
})

check('VS8 every payload file is profile-clean at the widest reach', () => {
  // The claim CONVENTIONS section 3 makes, enforced instead of promised. A repo that adopts the
  // writing profile at scan:"all" must never be asked to exempt a file this toolkit put in their
  // tree: that exemption would print in their lint run forever, which is an apology rather than
  // a standard. Prose alone did not hold this. Two em dashes reached the payload from a single
  // afternoon's edits, which is precisely the argument for a test.
  const tmp = mkdtempSync(join(tmpdir(), 'rs-payload-prose-'))
  try {
    cpSync(join(ROOT, 'payload'), tmp, { recursive: true })
    // The Contributor Covenant is reproduced verbatim from an external standard and contains
    // "In order to honor these values". It is the one exemption, and it is not ours to rewrite.
    rmSync(join(tmp, 'templates', 'CODE_OF_CONDUCT.md'), { force: true })
    const r = runScan(tmp, ['--scan', 'all'])
    assert.equal(r.code, 0, `payload/ is not profile-clean at scan:"all"\n${r.out}`)
    // Anti-vacuity: prove the scan actually reached the payload rather than matching nothing.
    assert.match(r.out, /\d+ file\(s\), \d+ line\(s\)/, `the scan must report what it read\n${r.out}`)
    const files = Number(r.out.match(/(\d+) file\(s\)/)[1])
    assert.ok(files >= 10, `expected the whole payload tree (scanned ${files} files) — refusing a vacuous pass`)
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

check('VS9 the lint and the About engine derive the SAME tagline', () => {
  // RS-about compares a recorded description against the README's tagline, and
  // harness/github-about.mjs derives the value that gets recorded. If the two read a tagline
  // differently, the check reddens on prose nobody touched and the fix is invisible. Both were
  // wrong about a WRAPPED tagline at first: reading the first line cut it mid sentence and left
  // a stray bold marker in what would have been published as the repo's description.
  const ENGINE_ABOUT = join(ROOT, 'harness', 'github-about.mjs')
  const cases = [
    ['single line', '**A one-line tagline.**', 'A one-line tagline.'],
    ['wrapped over three lines', '**Bootstrap and enforce enterprise repo hygiene in any\ncodebase, from one\ncommand.**', 'Bootstrap and enforce enterprise repo hygiene in any codebase, from one command.'],
    ['bold followed by unbolded prose', '**The tagline.** And a sentence that continues after it.', 'The tagline.'],
    ['banners and badges between H1 and tagline', '[![x](a.svg)](b)\n\n<div align="center">\n\n**After the badge row.**', 'After the badge row.'],
  ]
  for (const [label, tagline, expected] of cases) {
    const tmp = mkdtempSync(join(tmpdir(), 'rs-about-'))
    try {
      for (const [rel, content] of Object.entries(files({}))) {
        mkdirSync(join(tmp, dirname(rel)), { recursive: true })
        writeFileSync(join(tmp, rel), content)
      }
      writeFileSync(join(tmp, 'README.md'), ['# fixture', '', tagline, '', '## Install', '', 'Clone it.', '',
        '## Usage', '', 'Run it.', '', '## Contributing', '', 'PRs.', '', '## License', '', 'MIT.', ''].join('\n'))
      mkdirSync(join(tmp, 'acceptance'), { recursive: true })
      writeFileSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
      // What the engine derives.
      let derived
      try { derived = JSON.parse(execFileSync('node', [ENGINE_ABOUT, '--target', tmp, '--json'], { encoding: 'utf8' })).proposal.description }
      catch (e) { derived = JSON.parse(`${e.stdout || '{}'}`).proposal?.description }
      assert.equal(derived, expected, `${label}: the engine derived "${derived}"`)
      // And what the lint accepts, given exactly that.
      const cfg = JSON.parse(readFileSync(join(tmp, '.repo-standard.json'), 'utf8'))
      cfg.github = { about: { description: derived } }
      writeFileSync(join(tmp, '.repo-standard.json'), JSON.stringify(cfg, null, 2) + '\n')
      const r = runLint(tmp)
      assert.equal(r.code, 0, `${label}: the lint rejected the engine's own output\n${r.out}`)
      assert.ok(r.out.includes('✓ RS-about'), `${label}: RS-about must actually run\n${r.out}`)
    } finally {
      rmSync(tmp, { recursive: true, force: true })
    }
  }
})

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
