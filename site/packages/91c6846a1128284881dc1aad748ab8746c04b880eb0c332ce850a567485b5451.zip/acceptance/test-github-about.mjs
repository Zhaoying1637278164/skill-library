#!/usr/bin/env node
/*
 * test-github-about.mjs: the About proposal is recordable verbatim, and cannot delete anything.
 *
 * WHY: this engine emits an object the skill is told to record and a consumer is invited to apply
 * as it stands, and one of its fields writes as a WHOLE-LIST REPLACEMENT. That combination is the
 * only place in this toolkit where a derived value can destroy something a human curated. It
 * already went wrong once: `topics: []`, emitted because nothing was derivable, applied verbatim,
 * deletes every topic the repo had. The absence of a proposal and a proposal to have nothing have
 * to look different, and nothing but this file holds that.
 *
 * The engine was previously covered by one guard, in test-voice-canon, comparing its tagline
 * parse to the lint's. Everything else it does was unguarded, including the shape of the payload
 * every consumer reads.
 *
 * Guards:
 *   GA1  a field nothing could source is ABSENT from the proposal, never null and never empty.
 *        The topics case is the destructive one and is asserted on its own.
 *   GA2  writeSemantics names the replacement, and the human print and the JSON carry the SAME
 *        caution from one constant, because two hand-written copies drift.
 *   GA3  the description is the README's bold tagline, wrapped ones included, and never the
 *        version manifest's own description.
 *   GA4  exit codes carry the verdict: 0 derived, 1 nothing derivable, 2 bad invocation.
 *   GA5  topics are normalized, de-duplicated and capped, and anything dropped is NAMED rather
 *        than silently removed.
 *   GA6  a homepage that is just the repo URL is not a homepage, and is reported as missing.
 *   GA7  every missing field names the file it would have read, so the operator knows where to
 *        put the answer.
 *   GA8  the engine writes nothing, which is what makes it safe to run against a repo uninvited.
 *
 * Dependency-free: `node acceptance/test-github-about.mjs`.
 */
import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, readdirSync, statSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const ENGINE = join(ROOT, 'harness', 'github-about.mjs')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

console.log('github-about standing test (a proposal that cannot delete what it did not derive)')

const run = (args, cwd = ROOT) => {
  try { return { code: 0, out: execFileSync('node', [ENGINE, ...args], { cwd, encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}
const build = (files) => {
  const tmp = mkdtempSync(join(tmpdir(), 'rs-about-'))
  for (const [rel, content] of Object.entries(files)) {
    mkdirSync(join(tmp, dirname(rel)), { recursive: true })
    writeFileSync(join(tmp, rel), content)
  }
  return tmp
}
const about = (dir) => {
  const r = run(['--target', dir, '--json'])
  return { code: r.code, data: JSON.parse(r.out) }
}
const README = (tagline) => `# Fixture\n\n**${tagline}**\n\nBody text.\n`

check('GA1 a field nothing could source is absent from the proposal, not null and not empty', () => {
  // No manifest at all: nothing to read a homepage or a keyword from.
  const dir = build({ 'README.md': README('A fixture repo for the About panel.') })
  try {
    const { data } = about(dir)
    assert.deepEqual(Object.keys(data.proposal), ['description'],
      'the proposal must carry only what was derived; a consumer records this object as it stands')
    assert.ok(!('homepage' in data.proposal), 'an underivable homepage is absent, not null: a recorded null already wedged a scaffold run once')
    // The one that matters. `topics: []` next to `replace-whole-list` is a delete instruction.
    assert.ok(!('topics' in data.proposal),
      'an empty topics list must NEVER appear in the proposal: paired with replace-whole-list, applying it verbatim deletes every topic the repo had. The absence of a proposal is not a proposal to have none')
    assert.deepEqual(data.missing.map((m) => m.field).sort(), ['homepage', 'topics'],
      'what the proposal omits, `missing` names: a field that vanished from both would be a silent gap')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('GA2 the replacement caution is stated once and reaches both output modes', () => {
  const dir = build({
    'README.md': README('A fixture repo for the About panel.'),
    'package.json': '{ "name": "fx", "version": "1.0.0", "keywords": ["alpha", "beta"] }\n',
  })
  try {
    const { data } = about(dir)
    assert.equal(data.writeSemantics.topics, 'replace-whole-list',
      'the destructive semantic has to be in the payload, because JSON is the mode the skills read')
    assert.equal(data.writeSemantics.description, 'field-update')
    const note = data.writeSemantics['//topics']
    assert.ok(note && note.includes('REPLACES the whole topic list'), `the note must say what the write does, got ${JSON.stringify(note)}`)
    // One constant, two modes. A second hand-written copy is how the human print and the payload
    // stop agreeing, and the payload is the one nobody reads before applying it.
    const human = run(['--target', dir]).out
    for (const sentence of note.split('. ').map((s) => s.trim()).filter(Boolean)) {
      const needle = sentence.replace(/\s+/g, ' ').slice(0, 40)
      assert.ok(human.replace(/\s+/g, ' ').includes(needle), `the human print is missing the caution fragment "${needle}"`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('GA3 the description is the README tagline, wrapped ones included, never the manifest\'s', () => {
  const dir = build({
    'README.md': '# Fixture\n\n**A tagline that wraps across\ntwo source lines and keeps going.**\n\nBody.\n',
    'package.json': '{ "name": "fx", "version": "1.0.0", "description": "the manifest description, which is NOT the front page" }\n',
  })
  try {
    const { data } = about(dir)
    assert.equal(data.proposal.description, 'A tagline that wraps across two source lines and keeps going.',
      'a wrapped tagline is joined, not cut at the first line, or the `**` marker is published inside the repo description')
    assert.ok(!data.proposal.description.includes('manifest description'),
      'a repo has one front page: taking the description from anywhere but the sentence it leads with gives it two answers')
    assert.match(data.sources.description, /README\.md/, 'the source names the file, so the claim is checkable')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('GA4 the exit code carries the verdict', () => {
  const derived = build({ 'README.md': README('Derivable.') })
  const bare = build({ 'README.md': '# Fixture\n\nNo bold tagline anywhere.\n' })
  try {
    assert.equal(about(derived).code, 0, 'a derived description is exit 0')
    const r = about(bare)
    assert.equal(r.code, 1, 'nothing derivable is exit 1, not a silent empty proposal')
    assert.equal(r.data.ok, false, 'and the payload says so too, for a consumer reading JSON rather than a status')
    assert.deepEqual(r.data.proposal, {}, 'with no tagline there is nothing to propose, and the object says nothing rather than saying null')
    assert.ok(run(['--target', bare]).out.includes('give the README one first'),
      'the human mode says what to do about it rather than only that it failed')
    assert.equal(run(['--nonsense']).code, 2, 'a bad invocation is exit 2, distinct from nothing derivable')
    assert.equal(run(['--target', join(tmpdir(), 'rs-about-does-not-exist')]).code, 2, 'a missing target is a refusal')
  } finally { rmSync(derived, { recursive: true, force: true }); rmSync(bare, { recursive: true, force: true }) }
})

check('GA5 topics are normalized and capped, and everything dropped is named', () => {
  const keywords = ['Alpha', 'alpha', 'Two Words', 'trailing-', '!!!', ...Array.from({ length: 22 }, (_, i) => `topic-${String(i).padStart(2, '0')}`)]
  const dir = build({
    'README.md': README('A fixture repo for the About panel.'),
    'package.json': JSON.stringify({ name: 'fx', version: '1.0.0', keywords }),
  })
  try {
    const { data } = about(dir)
    const t = data.proposal.topics
    assert.equal(t.length, 20, 'GitHub takes 20 topics, so the proposal carries 20 and never a set the API would reject')
    assert.equal(new Set(t).size, t.length, 'duplicates after normalization are collapsed: "Alpha" and "alpha" are one topic')
    assert.ok(t.includes('two-words'), 'a keyword with a space normalizes to kebab rather than being dropped')
    for (const k of t) assert.match(k, /^[a-z0-9][a-z0-9-]{0,49}$/, `"${k}" is not a valid GitHub topic`)
    // Silence is the failure here. A capped list that says nothing about the cap reads complete.
    const w = data.warnings.join(' ')
    assert.ok(/capped at GitHub's limit/.test(w), `the cap has to be stated, not applied quietly:\n${w}`)
    assert.ok(/not valid GitHub topics and were dropped/.test(w), `dropped keywords have to be named:\n${w}`)
    assert.ok(w.includes('!!!'), 'and named specifically, so the operator can fix the keyword rather than hunt for it')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('GA6 the repo URL is not a homepage, and saying so is not the same as having one', () => {
  const dir = build({ 'README.md': README('A fixture repo for the About panel.') })
  try {
    execFileSync('git', ['-C', dir, 'init', '-q'], { stdio: 'ignore' })
    execFileSync('git', ['-C', dir, 'remote', 'add', 'origin', 'https://github.com/acme/fixture.git'], { stdio: 'ignore' })
    // A manifest whose homepage is just the repo again. Pointing the About website field at the
    // page a reader is already on tells them nothing, so it is not a derived homepage.
    writeFileSync(join(dir, 'package.json'), '{ "name": "fx", "version": "1.0.0", "homepage": "https://github.com/acme/fixture" }\n')
    let { data } = about(dir)
    assert.ok(!('homepage' in data.proposal), 'the repo URL dressed up as a product site is not a homepage')
    assert.ok(data.missing.some((m) => m.field === 'homepage'), 'and it is reported missing rather than silently omitted')
    assert.equal(data.repoSlug, 'acme/fixture', 'the remote is read for the slug, which is what names the panel being synced')
    writeFileSync(join(dir, 'package.json'), '{ "name": "fx", "version": "1.0.0", "homepage": "https://acme.example/product" }\n')
    ;({ data } = about(dir))
    assert.equal(data.proposal.homepage, 'https://acme.example/product', 'a real product site IS derivable and is proposed')
    assert.match(data.sources.homepage, /package\.json/, 'with the file it came from')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('GA7 every missing field names the file it would have read', () => {
  const dir = build({ 'README.md': '# Fixture\n\nNo tagline.\n' })
  try {
    const { data } = about(dir)
    assert.equal(data.missing.length, 3, 'description, homepage and topics are all underivable here')
    for (const m of data.missing) {
      assert.ok(typeof m.wouldHaveRead === 'string' && m.wouldHaveRead.trim(),
        `${m.field} says it is missing but not where the answer goes, which leaves the operator guessing`)
    }
    const byField = Object.fromEntries(data.missing.map((m) => [m.field, m.wouldHaveRead]))
    assert.match(byField.description, /README\.md/, 'the description names the README and the tagline within it')
    assert.match(byField.homepage, /this repo has none/, 'with no manifest at all, it says so rather than naming a file that does not exist')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('GA8 the engine writes nothing', () => {
  // It is offered as safe to run against a repo before anything has been agreed to, so the
  // read-only claim is load-bearing rather than a nicety.
  const dir = build({
    'README.md': README('A fixture repo for the About panel.'),
    'package.json': '{ "name": "fx", "version": "1.0.0", "keywords": ["alpha"] }\n',
  })
  const snapshot = (d) => readdirSync(d, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))
    .flatMap((e) => (e.isDirectory() ? snapshot(join(d, e.name)) : [`${join(d, e.name)}:${statSync(join(d, e.name)).size}`]))
  try {
    const before = snapshot(dir)
    run(['--target', dir, '--json'])
    run(['--target', dir])
    assert.deepEqual(snapshot(dir), before, 'the engine changed the tree it was pointed at')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
