#!/usr/bin/env node
/*
 * test-templates-lint-green.mjs — the templates are proven against the lint they ship with.
 *
 * WHY: the scaffolder's promise is that a freshly scaffolded repo passes the freshly installed
 * gate. If a payload template drifted out of the payload lint's standard (a heading renamed, a
 * banned word slipped into template prose, License no longer last), every future scaffold would
 * be born red. This test performs the scaffold MECHANICALLY, exactly as the skill does: fill
 * every payload/templates/* file through the real harness/fill-template.mjs engine with sample
 * values, resolve the TODO(scaffold) markers the way the agent must (replace with real prose),
 * install the payload lint + the payload default config verbatim, and run the gate.
 *
 * Guards:
 *   TG0  every file shipped under payload/templates/ is filled by a case here or named as
 *        deliberately not filled, with a reason. The fill list is hand-written, because each
 *        template's destination is a fact only the skill knows, so without this the list is a
 *        claim about the directory that nothing compares to the directory.
 *   TG1  every doc template fills through the real engine (placeholder sets total and typo-free).
 *   TG2  the scaffolded repo passes the shipped lint (exit 0) under the shipped default config.
 *   TG3  the run is honest about what it skipped (manifest / counts / lockstep print SKIP lines).
 *   TG4  an UNRESOLVED TODO(scaffold) in the scaffold is caught by the shipped lint (exit 1) —
 *        a half-finished scaffold cannot pass CI silently.
 *   TG5  both licence templates fill with the real year and holder. Neither is verbatim: both
 *        end on a copyright line the tokens fill, because a hardcoded attribution here would
 *        stamp someone else's name into every repo this ever scaffolds.
 *   TG6  the same scaffold passes under the ENTERPRISE WRITING PROFILE. A repo that adopts the
 *        profile must not be fighting the templates that scaffolded it, so every template ships
 *        free of em dashes and banned filler, and the CONVENTIONS the voice skill writes carries
 *        the vocabulary RS-reflexivity demands.
 *   TG7  the shipped ignore ruleset actually satisfies RS-ignore: what the scaffold installs is
 *        what the gate then requires, proven rather than assumed.
 *
 * Dependency-free: `node acceptance/test-templates-lint-green.mjs`.
 */
import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, copyFileSync, readdirSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const FILL = join(ROOT, 'harness', 'fill-template.mjs')
const TPL = join(ROOT, 'payload', 'templates')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

// the sample values a scaffold session would derive/ask for — one flat map; fill-template
// rejects unused keys, so each template gets only the subset it declares.
const VALUES = {
  PROJECT_NAME: 'acme-demo',
  TAGLINE: 'A demo repo scaffolded by the repo standard.',
  INSTALL_COMMAND: 'git clone https://github.com/acme/acme-demo && cd acme-demo',
  USAGE_COMMAND: 'node bin/acme-demo.mjs --help',
  LICENSE_ID: 'Apache-2.0',
  LICENSE_HOLDER: 'Acme Maintainers',
  YEAR: '2026',
  DEFAULT_BRANCH: 'main',
  SECURITY_CONTACT: 'security@acme.example',
  COC_CONTACT: 'conduct@acme.example',
  REPO_SLUG: 'acme/acme-demo',
  REPO_URL: 'https://github.com/acme/acme-demo',
  FIRST_CHANGELOG_ENTRY: 'Repo hygiene standard scaffolded (README, CHANGELOG, CONVENTIONS, meta files, committed lint + CI gate).',
}

const fill = (template, out) => {
  const src = readFileSync(join(TPL, template), 'utf8')
  const keys = [...new Set([...src.matchAll(/\{\{([A-Z0-9_]+)\}\}/g)].map((m) => m[1]))]
  const args = ['--template', join(TPL, template), '--out', out]
  for (const k of keys) {
    assert.ok(k in VALUES, `template ${template} uses a placeholder {{${k}}} this test has no sample value for — add it to VALUES`)
    args.push('--set', `${k}=${VALUES[k]}`)
  }
  execFileSync('node', [FILL, ...args], { encoding: 'utf8' })
}

// the agent's half, done mechanically: every TODO(scaffold) HTML comment becomes real prose.
const resolveTodos = (path) => {
  const text = readFileSync(path, 'utf8')
  writeFileSync(path, text.replace(/<!--\s*TODO\(scaffold\):[\s\S]*?-->/g, 'Written from the real repo by the scaffold session: what this section claims is verified against the code, and limits are stated plainly.'))
}

const runLint = (dir) => {
  try { return { code: 0, out: execFileSync('node', [join(dir, 'acceptance', 'test-repo-standard.mjs')], { encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}

console.log('templates-lint-green standing test (mechanical scaffold → shipped gate)')

// The list below is hand-written, because each template fills to a destination only the skill
// knows. That makes it a claim about the directory rather than a reading of it, so TG0 holds the
// two apart: anything shipped under payload/templates/ is either filled by TG1, filled by TG5, or
// named here with a reason. Without it, a template added tomorrow is ungated and the suite still
// says every template is proven, which is the shape of lie this repo exists to catch.
const NOT_FILLED = {
  'INDEX.md': 'the directory\'s own catalog, not a document that ships into a target repo',
}
const TG1_TEMPLATES = [
  ['README.md', 'README.md'],
  ['CHANGELOG.md', 'CHANGELOG.md'],
  ['CONVENTIONS.md', 'CONVENTIONS.md'],
  ['CONTRIBUTING.md', 'CONTRIBUTING.md'],
  ['CODE_OF_CONDUCT.md', 'CODE_OF_CONDUCT.md'],
  ['SECURITY.md', 'SECURITY.md'],
  ['LICENSE-Apache-2.0.txt', 'LICENSE'],
]
const TG5_TEMPLATES = ['LICENSE-MIT.txt']

const tmp = mkdtempSync(join(tmpdir(), 'rs-templates-'))
try {
  check('TG0 every file shipped under payload/templates/ is filled here, or named as deliberately not', () => {
    const shipped = readdirSync(join(ROOT, 'payload', 'templates')).sort()
    const covered = new Set([...TG1_TEMPLATES.map(([t]) => t), ...TG5_TEMPLATES, ...Object.keys(NOT_FILLED)])
    const unclaimed = shipped.filter((f) => !covered.has(f))
    assert.deepEqual(unclaimed, [], `payload/templates/ ships ${unclaimed.join(', ')}, which no case here fills and no exclusion names. Add it to TG1, or to NOT_FILLED with the reason`)
    const stale = [...covered].filter((f) => !shipped.includes(f))
    assert.deepEqual(stale, [], `this test claims to cover ${stale.join(', ')}, which the directory no longer ships`)
    assert.ok(shipped.length >= 8, `only ${shipped.length} template(s) found: refusing a vacuous pass`)
  })

  const scaffolded = []
  check('TG1 every doc template fills through the real fill-template engine', () => {
    for (const [template, dest] of TG1_TEMPLATES) {
      fill(template, join(tmp, dest))
      scaffolded.push(dest)
    }
    for (const f of scaffolded) assert.ok(!readFileSync(join(tmp, f), 'utf8').includes('{{'), `${f} still carries a placeholder`)
  })

  // TG4 first — BEFORE resolving TODOs, the shipped lint must refuse the half-finished scaffold.
  mkdirSync(join(tmp, 'acceptance'), { recursive: true })
  copyFileSync(join(ROOT, 'payload', 'acceptance', 'test-repo-standard.mjs'), join(tmp, 'acceptance', 'test-repo-standard.mjs'))
  copyFileSync(join(ROOT, 'payload', 'repo-standard.json'), join(tmp, '.repo-standard.json'))
  // The scaffold's ignore step, done exactly as the skill does it: the payload fragment copied
  // in whole. TG7 then proves the gate accepts what the scaffold just installed.
  copyFileSync(join(ROOT, 'payload', 'ignore', 'repo-standard.gitignore'), join(tmp, '.gitignore'))
  check('TG4 an unresolved TODO(scaffold) is caught by the shipped lint — a half scaffold cannot pass', () => {
    const r = runLint(tmp)
    assert.equal(r.code, 1, `expected exit 1 on the unresolved scaffold, got ${r.code}\n${r.out}`)
    assert.ok(r.out.includes('RS-todos') && r.out.includes('TODO(scaffold)'), `RS-todos should name the marker\n${r.out}`)
  })

  check('TG2 after the agent half (TODOs resolved), the scaffolded repo passes the shipped gate under the shipped default config', () => {
    for (const f of scaffolded) if (f.endsWith('.md')) resolveTodos(join(tmp, f))
    const r = runLint(tmp)
    assert.equal(r.code, 0, `the scaffolded repo must pass the shipped lint\n--- lint output ---\n${r.out}`)
  })

  check('TG3 the green run names its dormant surfaces (manifest, counts, lockstep) as SKIPs, never silently', () => {
    const r = runLint(tmp)
    assert.ok(r.out.includes('RS-manifest SKIP'), `manifest skip must be printed\n${r.out}`)
    assert.ok(r.out.includes('RS-counts SKIP'), `counts skip must be printed\n${r.out}`)
    // must be the SKIP line specifically: a bare 'RS-lockstep' needle is satisfied by a '✓'
    // PASS too, which is exactly the failure this check exists to catch — a dormant check
    // counted as a pass inflates the green total and hides that it never ran. This is the only
    // coverage of the no-version-manifest skip path (the lint-behavior fixture ships a
    // package.json, so lockstep is always ACTIVE there).
    assert.ok(r.out.includes('RS-lockstep SKIP'), `lockstep must print a SKIP line, not merely appear\n${r.out}`)
    assert.match(r.out, /\d+ passed, 0 failed, \d+ skipped/, `the summary must count the skips it printed\n${r.out}`)
  })

  check('TG7 the shipped ignore ruleset satisfies RS-ignore (what we install is what the gate requires)', () => {
    const r = runLint(tmp)
    assert.ok(!r.out.includes('✗ RS-ignore'), `the payload ignore ruleset must pass the payload lint\n--- lint output ---\n${r.out}`)
    // Anti-vacuity: prove the check is live on this fixture rather than quietly skipped.
    assert.ok(r.out.includes('RS-ignore .gitignore'), `RS-ignore must actually run here\n${r.out}`)
  })

  check('TG6 the same scaffold passes under the enterprise writing profile', () => {
    // The voice skill's two acts, performed mechanically: document the vocabulary in
    // CONVENTIONS (RS-reflexivity requires it), then switch the profile on. The Covenant is the
    // one exemption, because its text is reproduced verbatim from an external standard and
    // editing it would misrepresent what the repo says it follows.
    const conv = join(tmp, 'CONVENTIONS.md')
    writeFileSync(conv, readFileSync(conv, 'utf8') + [
      '',
      '## 6. Enterprise writing profile',
      '',
      'No em dash in any form (the character, its HTML escapes, or a spaced en dash), and none',
      'of `delve`, `utilize`, `leverage`, `in order to`, `worth noting`, `it should be noted`,',
      '`needless to say`, `as you can see`, `furthermore`, `moreover`, `a wide range of`,',
      '`a variety of`, or `state-of-the-art`. Rewrite the sentence rather than substituting',
      'other punctuation.',
      '',
    ].join('\n'))
    const cfg = JSON.parse(readFileSync(join(tmp, '.repo-standard.json'), 'utf8'))
    cfg.prose = {
      profile: 'enterprise',
      exempt: [{ path: 'CODE_OF_CONDUCT.md', why: 'the Contributor Covenant text is reproduced verbatim from the standard' }],
    }
    writeFileSync(join(tmp, '.repo-standard.json'), JSON.stringify(cfg, null, 2) + '\n')
    const r = runLint(tmp)
    assert.equal(r.code, 0, `a freshly scaffolded repo must be able to adopt the writing profile without a rewrite\n--- lint output ---\n${r.out}`)
    assert.ok(r.out.includes('✓ RS-prose'), `RS-prose must actually run and pass here\n${r.out}`)
    assert.ok(r.out.includes('prose exemption active: CODE_OF_CONDUCT.md'), `the one exemption must print on every run\n${r.out}`)
  })

  check('TG5 both license templates carry the copyright line and fill it with the real year + holder', () => {
    fill('LICENSE-MIT.txt', join(tmp, 'LICENSE-MIT-sample'))
    const mit = readFileSync(join(tmp, 'LICENSE-MIT-sample'), 'utf8')
    assert.ok(mit.includes('Copyright (c) 2026 Acme Maintainers'), 'MIT fill carries year + holder')
    // the Apache template takes the same two placeholders — a hardcoded copyright line here
    // would stamp someone else's attribution into every repo this ever scaffolds.
    const apache = readFileSync(join(tmp, 'LICENSE'), 'utf8')
    assert.ok(apache.includes('Copyright 2026 Acme Maintainers'), 'Apache fill carries year + holder')
    assert.ok(!apache.includes('{{'), 'Apache LICENSE is fully filled')
    for (const t of ['LICENSE-Apache-2.0.txt', 'LICENSE-MIT.txt']) {
      const src = readFileSync(join(TPL, t), 'utf8')
      assert.ok(/\{\{YEAR\}\}/.test(src) && /\{\{LICENSE_HOLDER\}\}/.test(src), `${t} must take YEAR + LICENSE_HOLDER rather than hardcoding an attribution`)
    }
  })
} finally {
  rmSync(tmp, { recursive: true, force: true })
}

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
