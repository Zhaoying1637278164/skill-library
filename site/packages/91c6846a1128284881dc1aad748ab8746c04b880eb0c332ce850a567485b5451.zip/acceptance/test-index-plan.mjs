#!/usr/bin/env node
/*
 * test-index-plan.mjs: the atlas planner scopes a sweep exactly the way the gate scopes a build.
 *
 * WHY: harness/index-plan.mjs decides which files an atlas run reads and writes a row for, and
 * RS-index decides which files must HAVE a row. Those are two implementations of one rule, in two
 * files that cannot import each other, because the lint ships into target repos as a single
 * self-contained file. If they ever disagree, a sweep writes rows the gate does not want and
 * skips the ones it does, and the operator finds out from a red build after the work is done.
 *
 * The comparison here is behavioural rather than textual. A fixture is built with an index that
 * carries exactly one row, so the lint's own failure message enumerates every OTHER file it wants
 * a row for, and that list plus the covered one is compared to the planner's whole coverage set.
 * Comparing source would prove the two files contain similar code; comparing output proves they
 * answer the same question. The one row is not incidental: RS-index refuses an index that lists
 * nothing before it ever gets as far as saying what is missing.
 *
 * The fixture is built to be awkward on purpose: nested directories, an ignored subtree, two
 * declared extensions, an extensionless file, and a file that matches the extensions but is the
 * index itself. Each of those is somewhere the two implementations could plausibly diverge.
 *
 * Guards:
 *   IP1  the planner's coverage set is exactly the set RS-index demands rows for, over a fixture
 *        built to expose every divergence either implementation could plausibly have.
 *   IP2  the planner agrees with the lint on every index this repo declares: both see the same
 *        gaps, on the real config rather than a fixture. Deliberately not a stated count, which
 *        is a claim that goes stale the next time a directory adopts one.
 *   IP3  every file lands in exactly one chunk, no chunk exceeds either ceiling, and a file
 *        larger than the line ceiling is chunked alone and reported as oversize.
 *   IP4  a row pointing at a file that no longer exists is reported, because a table can be
 *        wrong by rot as well as by omission.
 *   IP5  a file the planner cannot read is named with the reason, never counted as described.
 *   IP6  every refusal is loud: an unknown argument, a target that is not a directory, an
 *        ungoverned repo, an unparseable config, both index spellings at once, and --index
 *        naming an index nobody declared. Closes on the positive half of that last one, because
 *        a refusal check that never proves the accepted path can be satisfied by refusing both.
 *   IP7  exit codes carry the STRUCTURAL verdict and say so in words: 0 when nothing is missing,
 *        rotted, duplicated, or waiting to be offered, 1 when something is.
 *   IP7b a structurally complete index still prices its own re-reading, and the reconciliation
 *        plan is explicitly not what the exit code carries. This is the defect that lost a whole
 *        directory on the first real target: complete was read as finished.
 *   IP8  a directory keeping a README and no index is reported as a CANDIDATE, never planned as
 *        though it had been adopted, and it is PRICED (lines, bytes, per extension) rather than
 *        merely counted.
 *   IP9  a prospective index is priced exactly before anything declares it, lands in the README
 *        by default, and asks rather than assumes when that README already exists.
 *   IP10 an index sitting where a reader browsing the directory never finds it is offered a move,
 *        with the config edit, the docs.extra entry, and every inbound reference attached; and
 *        the move is NOT offered when README.md is itself one of the directory's artifacts.
 *   IP11 a plan larger than the 64 KiB pipe buffer survives being piped. It used to arrive
 *        truncated to exactly 65536 bytes and fail to parse.
 *   IP12 --mode decides what the chunks cover; the exit code never moves with it.
 *   IP13 a per-directory decline is honoured and reported, without silencing the other candidates.
 *   IP14 a path git has to quote (non-ASCII, a space) still owes a row. It used to disappear from
 *        the universe entirely, and a coverage check silently shrank its own input.
 *   IP15 a symlink is owned and named rather than dropped by a walk that yields only real files.
 *   IP16 a child index bounds its parent for the files the CHILD owns, not for its whole
 *        directory: a .json under a .md-only child index belonged to nobody and passed everything.
 *   IP17 one file is never owned by two indexes, and a row appearing in both tables is reported.
 *   IP18 --index narrows what is REPORTED and never what is owned; it used to delete the sibling
 *        declarations before computing ownership and disagree with both the full plan and the gate.
 *   IP19 a kept file no declaration owns is surfaced as a decision, including an extensionless one,
 *        and the directory holding it is offered whether or not it keeps a README.
 *   IP20 an all-kept-files selector exists, because an extension list can never promise complete
 *        coverage of a directory holding a Dockerfile.
 *   IP21 a link target the URI decoder rejects is reported as a bad row, never thrown.
 *   IP22 the planner refuses every index config the gate refuses, so a plan is never made for a
 *        repo CI will reject.
 *
 * Dependency-free: `node acceptance/test-index-plan.mjs`.
 *   IP23e the kept-file UNIVERSE fails closed in both engines: a sparse or skip-worktree entry
 *        and a name that is not valid UTF-8 are NAMED, while a staged deletion is not.
 *   IP23f a migration reports the moving page's own links and never promotes a fenced example.
 *   IP24  the GIT-STATE matrix: present, unstaged deletion, staged deletion, skip-worktree,
 *         gitlink, symlink, and a name that is not valid UTF-8, each asserted as an exact
 *         (planner, gate) pair. The unstaged deletion is the one that shipped wrong: both
 *         engines subtracted `ls-files --deleted`, which means "tracked and not in the
 *         worktree", so a plain `rm` on an uncatalogued tracked file turned 1/1 into 0/0.
 *   IP25  the NON-RENDERING matrix: a complete, correct, column-bound glossary inside an HTML
 *         comment, an indented code block, a fence, and a code span, each of which both engines
 *         credited as full coverage while a reader saw no glossary at all. With the positive
 *         controls beside them, because a rule that also refuses the ordinary idioms is worse.
 *   IP26  the MIGRATION-OCCURRENCE matrix: classification is per occurrence over source offsets,
 *         so two references on one line are two entries and nothing lands in neither list.
 */
import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, symlinkSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const PLANNER = join(ROOT, 'harness', 'index-plan.mjs')
const LINT_SRC = readFileSync(join(ROOT, 'payload', 'acceptance', 'test-repo-standard.mjs'), 'utf8')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

console.log('index-plan standing test (the planner and the gate scope the same sweep)')

const run = (cmd, args, cwd) => {
  try { return { code: 0, out: execFileSync('node', [cmd, ...args], { cwd, encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}
const plan = (dir, extra = []) => run(PLANNER, ['--target', dir, ...extra], dir)
const planJson = (dir, extra = []) => {
  const r = plan(dir, ['--json', ...extra])
  return { code: r.code, data: JSON.parse(r.out) }
}

const build = (files) => {
  const tmp = mkdtempSync(join(tmpdir(), 'rs-index-plan-'))
  for (const [rel, content] of Object.entries(files)) {
    mkdirSync(join(tmp, dirname(rel)), { recursive: true })
    writeFileSync(join(tmp, rel), content)
  }
  // The harness's own artifact: every fixture needs a copy of the lint to run, and it lives in
  // acceptance/. Now that a directory is offered on the strength of holding unowned files rather
  // than of keeping a README, that copy would show up as a candidate in every single fixture and
  // bury whatever the case was actually about. It is declined here, with the reason, exactly the
  // way a real repo would decline a directory nobody should have to read.
  mkdirSync(join(tmp, 'acceptance'), { recursive: true })
  writeFileSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
  // A fixture whose config is deliberately unparseable (the refusal cases) keeps exactly the
  // bytes it was given: rewriting it would repair the very thing under test.
  try {
    const cfg = JSON.parse(files['.repo-standard.json'] ?? 'null')
    if (cfg) {
      cfg.docs ??= {}
      cfg.docs.declined = [...(cfg.docs.declined ?? []), { dir: 'acceptance', why: 'the test harness copies the lint here; it is not part of the fixture under test' }]
      writeFileSync(join(tmp, '.repo-standard.json'), `${JSON.stringify(cfg, null, 2)}\n`)
    }
  } catch { /* left exactly as written */ }
  return tmp
}
// The same fixture under GIT, which is a different universe and therefore a different set of
// bugs. Everything above runs on the filesystem walk, where a path is whatever readdir returned;
// under git a path arrives through `ls-files`, which quotes anything outside plain ASCII and
// lists entries the walk never yields at all. Both engines prefer git when git can answer, so
// every coverage claim has to hold on this side too.
const buildGit = (files) => {
  const tmp = build(files)
  execFileSync('git', ['init', '-q'], { cwd: tmp, stdio: 'ignore' })
  execFileSync('git', ['add', '-A'], { cwd: tmp, stdio: 'ignore' })
  return tmp
}
// Whether the lint agrees, on the same tree, in the same breath. Half the false greens this file
// now guards were invisible because the planner was compared only against the lint's failure
// MESSAGE: when the lint passed, there was no message, and "no missing files" matched "the lint
// never looked".
const lintOf = (dir) => run(join(dir, 'acceptance', 'test-repo-standard.mjs'), [], dir)
// The THIRD engine. It is the cheapest of the three and the one that decides whether the atlas
// pillar is offered at all, and until an external audit compared SETS rather than verdicts it was
// in none of the parity claims here.
const SENSE = join(ROOT, 'harness', 'sense-state.mjs')
const senseJson = (dir) => {
  const r = run(SENSE, ['--target', dir, '--json'], dir)
  return { code: r.code, data: JSON.parse(r.out) }
}

// A fixture designed to be awkward. `lib/` holds the index and files at two depths, `lib/vendor/`
// is ignored, `.mjs` and `.json` are declared while `.txt` and an extensionless file are not, and
// `lib/INDEX.md` is the index rather than a README because that case is the one an obedient agent
// gets wrong.
const FIXTURE = () => ({
  '.repo-standard.json': JSON.stringify({
    version: 1,
    docs: {
      // A declared index has to be governed prose, which is what `extra` does: RS-index refuses
      // an index no sweep reaches, because that is the one page in the directory that could rot
      // without any check here noticing.
      extra: ['lib/INDEX.md'],
      indexes: [{
        file: 'lib/INDEX.md',
        // `.md` is declared so the INDEX ITSELF matches, which is what makes the planner's
        // self-exclusion load-bearing rather than an accident of the extension filter. It also
        // pulls in lib/README.md, which is the contract case that a README which is not the
        // catalog owes a row like any other file.
        extensions: ['.mjs', '.json', '.md'],
        statuses: ['active'],
        reconciled: true,
        ignore: ['lib/vendor'],
      }],
    },
  }, null, 2) + '\n',
  // One real row, because RS-index refuses an index that lists NOTHING before it ever enumerates
  // what is missing. An empty table would fail on a different assertion and prove nothing here.
  'lib/INDEX.md': '# lib/\n\n**The library.**\n\nReconciled against the code: 2026-01-01 (agent sweep)\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | The first thing. | `active` |\n',
  'lib/README.md': '# Not an index\n\nThis is a shipped readme, not the catalog.\n',
  'lib/one.mjs': 'export const one = 1\n',
  'lib/two.json': '{ "two": 2 }\n',
  'lib/notes.txt': 'undeclared extension, so no row is owed\n',
  'lib/runme': '#!/bin/sh\necho no extension at all\n',
  'lib/deep/three.mjs': 'export const three = 3\n',
  'lib/deep/nested/four.mjs': 'export const four = 4\n',
  'lib/vendor/ignored.mjs': 'export const ignored = true\n',
  'lib/vendor/deep/also-ignored.json': '{}\n',
  // A directory keeping a README and no index of its own: the candidate case. lib/ is NOT one,
  // because it already keeps an index, and its README is simply a file that lives there.
  'tools/README.md': '# tools/\n\nScripts nobody has catalogued yet.\n',
  'tools/build.mjs': 'export const build = () => {}\n',
})

/*
 * THE DIFFERENTIAL BASELINE: a fixture BOTH engines call clean, exit 0 against exit 0.
 *
 * The awkward FIXTURE above is deliberately red, which makes it useless for comparing exit
 * CLASSES: every mutation of it is non-zero before and after, so "both engines are unhappy"
 * passes while the two are unhappy in different classes. That is exactly what shipped. The old
 * parity check asserted `lint != 0` and `planner == 2` and called the pair proven, and behind
 * that assertion sat six real divergences (`docs: []` was 1 against 2, a nested `$schema` was 2
 * against 0, an unknown docs key and a broken manifest and a bad version were each 0 against 2,
 * and an existing index carrying no rows was 0 against 1).
 *
 * So this fixture carries the whole meta-doc set the lint requires, and every case below mutates
 * ONE thing off it and asserts the exact pair. A case whose baseline is not 0/0 proves nothing,
 * which is why the baseline itself is a guard.
 */
const CLEAN = () => ({
  '.repo-standard.json': JSON.stringify({
    version: 1,
    docs: {
      extra: ['lib/README.md'],
      indexes: [{ file: 'lib/README.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], ordered: true, reconciled: true, grammar: 2 }],
    },
  }, null, 2) + '\n',
  '.gitignore': '.env\n.env.*\n!.env.example\nnode_modules/\n',
  LICENSE: 'MIT License\n\nCopyright (c) 2026 fixture\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software.\n',
  'README.md': ['# fixture', '', '**A fixture repo.**', '', '## Install', '', 'Clone it.', '',
    '## Usage', '', 'Run it.', '', '## Contributing', '', 'PRs welcome.', '', '## License', '', 'MIT.', ''].join('\n'),
  'CHANGELOG.md': ['# Changelog', '', 'Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).', '',
    '## [Unreleased]', '', '### Added', '', '- A thing.', '', '## [1.0.0] — 2026-01-01', '', '### Added', '', '- Initial release.', ''].join('\n'),
  'CONVENTIONS.md': ['# Conventions', '', '## 1. Scope', '', 'A fixture.', '', '## 2. Voice', '', 'No marketing voice.', '',
    '## 3. Meta docs standard', '', 'CHANGELOG follows Keep a Changelog (keepachangelog.com): only Added / Changed / Deprecated /',
    'Removed / Fixed / Security. README follows standard-readme: Install, Usage, Contributing,', 'License last.', ''].join('\n'),
  'SECURITY.md': '# Security Policy\n\nReport privately.\n',
  'CONTRIBUTING.md': '# Contributing\n\nBe kind.\n',
  'CODE_OF_CONDUCT.md': '# Code of Conduct\n\nCovenant.\n',
  'lib/README.md': '# lib/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | The only engine. | `active` |\n',
  'lib/one.mjs': 'export const one = 1\n',
})
// Mutate the baseline: fn(config, files). A callback that rewrites `.repo-standard.json` itself
// keeps its exact bytes, which the unparseable cases need.
const off = (fn) => {
  const files = CLEAN()
  const before = files['.repo-standard.json']
  const cfg = JSON.parse(before)
  fn(cfg, files)
  if (files['.repo-standard.json'] === before) files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  return files
}

check('IP1 the planner demands rows for exactly the files RS-index demands rows for', () => {
  const dir = build(FIXTURE())
  try {
    const lint = run(join(dir, 'acceptance', 'test-repo-standard.mjs'), [], dir)
    const m = lint.out.match(/does not catalogue \d+ file\(s\) under [^:]+: (.+?) \. A file nobody indexed/s)
    assert.ok(m, `RS-index did not report a missing set to compare against\n--- lint output ---\n${lint.out}`)
    const fromLint = m[1].split(', ').map((s) => s.trim()).sort()
    const { data } = planJson(dir)
    assert.deepEqual([...data.indexes[0].missing].sort(), fromLint,
      'the planner and RS-index disagree about which files owe a row. A sweep scoped by the planner would leave the gate red')
    // The gap the two agree on is only half the rule: the planner also has to agree about the
    // file that is already covered, or it would re-read a directory it had mis-scoped and get the
    // same answer by luck.
    const fromPlanner = data.indexes[0].files.map((f) => f.path).sort()
    assert.deepEqual(fromPlanner, [...fromLint, 'lib/one.mjs'].sort(),
      'the planner\'s coverage set is the missing files plus the ones already carrying a row, and nothing else')
    // And the awkward cases, asserted by name so a future change that breaks one says which.
    assert.ok(fromPlanner.includes('lib/deep/nested/four.mjs'), 'coverage is recursive: a file two directories down still owes a row')
    assert.ok(fromPlanner.includes('lib/README.md'), 'a README that is not the catalog is a file in the directory like any other, and owes a row')
    assert.ok(fromPlanner.includes('lib/notes.txt') === false, '.txt is not declared, so it owes no row')
    assert.ok(fromPlanner.includes('lib/runme') === false, 'a file with no extension can never match an extension rule, so it is never required')
    assert.ok(fromPlanner.every((f) => !f.startsWith('lib/vendor/')), 'an ignored subtree is ignored all the way down')
    assert.ok(!fromPlanner.includes('lib/INDEX.md'), 'the index does not catalogue itself')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP2 the planner and the gate agree on this repo\'s own indexes, on the real config', () => {
  // A fixture proves the rule; this proves the rule against the tree the toolkit actually lives
  // under, which is where an `ignore` entry or a nested directory would surface a divergence a
  // fixture never modelled.
  const { data } = planJson(ROOT)
  const lint = lintOf(ROOT)
  assert.ok(data.indexes.length > 0, 'this repo declares indexes; a run that found none is reading the wrong config')
  for (const ix of data.indexes) {
    // The check has to have RUN. Comparing only against a failure MESSAGE let an empty planner
    // list agree with a lint that refused the config before RS-index was ever reached, which is
    // agreement between a claim and a silence.
    const quoted = ix.file.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    assert.ok(new RegExp(`[✓✗] RS-index ${quoted} catalogues`).test(lint.out),
      `${ix.file}: RS-index never ran for this index, so there is nothing here to agree with\n${lint.out}`)
    const re = new RegExp(`${quoted} does not catalogue \\d+ file\\(s\\)[^:]*: (.+?) \\. A file nobody indexed`, 's')
    const m = lint.out.match(re)
    const fromLint = m ? m[1].split(', ').map((s) => s.trim()).sort() : []
    assert.deepEqual([...ix.missing].sort(), fromLint,
      `${ix.file}: the planner and RS-index disagree about what is missing (planner ${JSON.stringify(ix.missing)}, lint ${JSON.stringify(fromLint)})`)
  }
  // And the strong form. Either engine can be wrong alone; the pair being wrong the SAME way is
  // the failure this file exists to make impossible, and comparing two silences never caught it.
  if (!data.structuralWork.any) {
    assert.equal(lint.code, 0, `the planner reports no structural work on this repo, so the gate has to be green\n${lint.out}`)
  }
})

check('IP3 chunking is total, bounded, and honest about a file too big to share an agent', () => {
  const files = { ...FIXTURE() }
  // One file over the line ceiling, and enough small ones to force a second chunk on count.
  files['lib/huge.mjs'] = `// big\n${'const x = 1\n'.repeat(5000)}`
  for (let i = 0; i < 25; i++) files[`lib/small/f${String(i).padStart(2, '0')}.mjs`] = 'export default 0\n'
  const dir = build(files)
  try {
    const { data } = planJson(dir)
    const ix = data.indexes[0]
    const { maxFiles, maxLines } = data.chunking
    const flat = ix.chunks.flatMap((c) => c.files)
    assert.deepEqual([...flat].sort(), ix.files.map((f) => f.path).sort(),
      'every file must appear in exactly one chunk: a planner that drops one plans a sweep that silently skips it')
    assert.equal(new Set(flat).size, flat.length, 'no file may be planned twice, or two agents write two rows for it')
    for (const c of ix.chunks) {
      assert.ok(c.files.length <= maxFiles, `chunk ${c.index} carries ${c.files.length} files, over the ${maxFiles} ceiling`)
      assert.ok(c.oversize || c.lines <= maxLines, `chunk ${c.index} carries ${c.lines} lines, over the ${maxLines} ceiling, without being declared oversize`)
      if (c.oversize) assert.equal(c.files.length, 1, 'an oversize chunk is one file: that is what makes it oversize rather than badly packed')
    }
    const huge = ix.chunks.find((c) => c.files.includes('lib/huge.mjs'))
    assert.ok(huge?.oversize, 'a file larger than the line ceiling must be chunked alone and reported as oversize, so the offer says so before anyone agrees to it')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP4 a row pointing at a file that is gone is reported, not silently dropped', () => {
  const files = { ...FIXTURE() }
  files['lib/INDEX.md'] += '| [`gone.mjs`](gone.mjs) | A file that was deleted. | `active` |\n'
  const dir = build(files)
  try {
    const { data } = planJson(dir)
    assert.deepEqual(data.indexes[0].orphaned, ['lib/gone.mjs'],
      'an index whose links have rotted reads authoritative and sends people nowhere; a reconciliation run has to be told')
    assert.equal(data.counts.orphaned, 1, 'the orphan count is part of the size the offer states')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP5 a file that cannot be read is named with the reason, never described anyway', () => {
  const files = { ...FIXTURE() }
  const dir = build(files)
  try {
    writeFileSync(join(dir, 'lib', 'blob.json'), Buffer.from([0x7b, 0x00, 0x7d]))
    const { data } = planJson(dir)
    const un = data.indexes[0].unreadable
    assert.deepEqual(un.map((u) => u.path), ['lib/blob.json'], 'a file with a NUL byte cannot be read for a description, and has to be named')
    assert.equal(un[0].why, 'binary', 'the reason is reported, because "could not read it" and "it is binary" call for different answers')
    assert.ok(data.indexes[0].files.some((f) => f.path === 'lib/blob.json' && f.readable === false),
      'an unreadable file still owes a row to the lint, so it stays in the plan and is flagged rather than dropped')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP6 every refusal is loud and says what to do instead', () => {
  const cases = [
    [['--target', join(tmpdir(), 'rs-index-plan-does-not-exist')], 'target is not a directory'],
    [['--nonsense'], 'unknown argument'],
  ]
  for (const [args, needle] of cases) {
    const r = run(PLANNER, args, ROOT)
    assert.equal(r.code, 2, `${args.join(' ')} must exit 2\n${r.out}`)
    assert.ok(r.out.includes(needle), `${args.join(' ')} should say "${needle}"\n${r.out}`)
  }
  const ungoverned = mkdtempSync(join(tmpdir(), 'rs-index-plan-bare-'))
  try {
    const r = plan(ungoverned)
    assert.equal(r.code, 2, 'an ungoverned repo is a refusal, not an empty plan')
    assert.ok(r.out.includes('not governed yet'), `should name the missing config\n${r.out}`)
  } finally { rmSync(ungoverned, { recursive: true, force: true }) }

  const broken = build({ '.repo-standard.json': '{ "version": 1, ' })
  try {
    const r = plan(broken)
    assert.equal(r.code, 2, 'an unparseable config is a refusal')
    assert.ok(r.out.includes('not valid JSON'), `should name the parse failure\n${r.out}`)
  } finally { rmSync(broken, { recursive: true, force: true }) }

  const both = build({ '.repo-standard.json': JSON.stringify({ version: 1, docs: { index: { file: 'docs/README.md' }, indexes: [] } }) })
  try {
    const r = plan(both)
    assert.equal(r.code, 2, 'declaring both spellings is what the lint rejects, so the planner must refuse the same pair')
    assert.ok(r.out.includes('would not match what CI holds'), `should say why the pair matters\n${r.out}`)
  } finally { rmSync(both, { recursive: true, force: true }) }

  const dir = build(FIXTURE())
  try {
    const r = plan(dir, ['--index', 'lib/NOPE.md'])
    assert.equal(r.code, 2, '--index naming an undeclared index is a typo, and a typo that planned nothing would read as a clean repo')
    assert.ok(r.out.includes('lib/INDEX.md'), `the refusal should list what IS declared\n${r.out}`)
    const ok = planJson(dir, ['--index', 'lib/INDEX.md'])
    assert.equal(ok.data.indexes.length, 1, '--index narrows the REPORT to one declared index')
    assert.equal(ok.data.scope.narrowed, true, 'and says so, because an exit code covering more than the detail below it reads as a bug otherwise')
    assert.deepEqual(ok.data.scope.reporting, ['lib/INDEX.md'], 'naming what it reported')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP7 the exit code carries the verdict', () => {
  const dir = build(FIXTURE())
  try {
    assert.equal(plan(dir).code, 1, 'an index missing rows is work to do')
    const rows = ['two.json', 'README.md', 'deep/three.mjs', 'deep/nested/four.mjs']
      .map((p) => `| [\`${p}\`](${p}) | What it is for. | \`active\` |`).join('\n')
    writeFileSync(join(dir, 'lib', 'INDEX.md'), readFileSync(join(dir, 'lib', 'INDEX.md'), 'utf8') + rows + '\n')
    assert.equal(plan(dir).code, 1, 'tools/ still keeps a README with no index, which is a candidate and therefore work')
    rmSync(join(dir, 'tools'), { recursive: true })
    const r = plan(dir)
    assert.equal(r.code, 0, `a complete index with no candidates left is no STRUCTURAL work\n${r.out}`)
    // The exit code carries structure and nothing else, and the output has to say so in words.
    // "nothing to do" used to be the phrase here, and a run read it the way it reads: it stopped
    // on a structurally complete index whose rows had not been re-read in a year. Exit 0 is a
    // claim about coverage and resolution; it is not a claim that a single description is true.
    assert.ok(r.out.includes('no structural work'), `exit 0 must name what it actually checked\n${r.out}`)
    assert.ok(/does NOT mean the rows are accurate/i.test(r.out),
      `exit 0 must say out loud that it is not a claim about accuracy, because the one run that read it otherwise skipped a whole directory\n${r.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP7b a structurally complete index still prices its own re-reading', () => {
  // The exact defect that lost a directory on the first real target: the index was complete, the
  // planner said so, and everything downstream treated "complete" as "finished". A reconciliation
  // plan exists whether or not a row is missing, and it is reported separately from the verdict.
  const files = { ...FIXTURE() }
  delete files['tools/README.md']
  delete files['tools/build.mjs']
  const rows = ['two.json', 'README.md', 'deep/three.mjs', 'deep/nested/four.mjs']
    .map((p) => `| [\`${p}\`](${p}) | What it is for. | \`active\` |`).join('\n')
  files['lib/INDEX.md'] += `${rows}\n`
  const dir = build(files)
  try {
    const { code, data } = planJson(dir)
    assert.equal(code, 0, 'nothing is structurally missing')
    assert.equal(data.structuralWork.any, false, 'and structuralWork says so')
    assert.ok(data.indexes[0].structurallyComplete, 'the index is structurally complete')
    assert.ok(data.reconciliationPlan.files >= 5,
      'but re-reading it is still work, and the plan says how much: every file the index speaks for, not just the uncovered ones')
    assert.ok(data.reconciliationPlan.chunks >= 1, 'and how many agents that would take')
    assert.equal(data.reconciliationPlan.reachedByExitCode, false,
      'the reconciliation plan is explicitly NOT what the exit code carries, so no caller can conflate the two again')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP8 a README with no index is offered as a candidate, never planned as adopted', () => {
  const dir = build(FIXTURE())
  try {
    const { data } = planJson(dir)
    // Keeping a README was never the rule that mattered: the rule is kept files nothing owns.
    // `lib/vendor/` is not here even so, because an ignore entry is a recorded answer rather than
    // a gap, and neither is `acceptance/`, which the harness declines for its own copy of the lint.
    assert.deepEqual(data.candidates.map((c) => c.dir).sort(), ['tools'],
      `a directory is a candidate when it holds kept files nothing owns and no recorded answer covers\n${JSON.stringify(data.candidates.map((c) => c.dir))}`)
    const tools = data.candidates.find((c) => c.dir === 'tools')
    assert.equal(tools.readme, 'tools/README.md', 'the candidate names the README a reader actually lands on')
    assert.equal(tools.readmeExists, true, 'and says whether that page exists yet, because gaining a table and being written from nothing are different offers')
    assert.ok(tools.extensions['.mjs'].files >= 1,
      'a candidate reports what is in the directory, so the extension set is a choice the operator makes rather than a guess the tool makes')
    // A candidate is something the operator is asked to agree to a fan-out over, so it carries the
    // size of that fan-out. Reporting a bare file count forced one run to re-derive the lines with
    // find, wc, and awk, and it arrived at a different number by a different counting rule.
    assert.ok(data.candidates[0].lines >= 1, 'a candidate is PRICED, not just counted: lines, because that is what an agent spends')
    assert.ok(data.candidates[0].bytes >= 1, 'and bytes, because one minified file is a single line and more reading than the rest of the offer put together')
    assert.ok(data.candidates[0].extensions['.mjs'].lines >= 1, 'per extension too, so any subset can be priced without a second run')
    assert.ok(data.candidates[0].suggested.includes('.mjs'), 'with an extension set the skill can offer, drawn from what is actually in there')
    assert.ok(data.candidates[0].priceWith.includes('--candidate tools'), 'and the exact command that prices it down to the chunk')
    assert.ok(!data.indexes.some((ix) => ix.dir === 'tools'),
      'a candidate is never planned as though it had been declared: adopting one is the operator\'s call')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP9 a prospective index is priced exactly, before anything declares it', () => {
  const dir = build(FIXTURE())
  try {
    const { code, data } = planJson(dir, ['--candidate', 'tools', '--extensions', '.mjs'])
    assert.equal(code, 1, 'a directory with no rows yet is work to do')
    const ix = data.indexes[0]
    assert.equal(ix.prospective, true, 'and it is marked prospective, so nobody mistakes the plan for a declaration')
    // A candidate ALWAYS has a README: keeping one with no index is the definition. Adopting the
    // directory means that page gains a table, not that a second catalog appears beside it.
    assert.equal(ix.file, 'tools/README.md', 'the index lands in the README, because that is the page GitHub renders when a reader browses the directory')
    assert.ok(/already exists/.test(ix.confirm), 'and the one thing no engine can decide is asked rather than assumed: whether that README is the front page or an artifact the directory ships')
    const redirected = planJson(dir, ['--candidate', 'tools', '--extensions', '.mjs,.md', '--index-file', 'tools/INDEX.md'])
    assert.equal(redirected.data.indexes[0].file, 'tools/INDEX.md', 'and the operator can redirect it when the README is taken')
    assert.ok(redirected.data.indexes[0].missing.includes('tools/README.md'),
      'in which case the README becomes a file in the directory like any other, and owes a row')
    assert.equal(ix.scope, 'direct', 'a new index owns the files directly in its directory; a nested one keeps its own')
    assert.deepEqual(ix.missing, ['tools/build.mjs'], 'and every file it would owe a row for is named, by path')
    assert.ok(ix.chunks.length >= 1, 'with the fan-out divided into agents, which is the number the operator actually agrees to')
    assert.ok(ix.lines >= 1 && ix.bytes >= 1, 'and the lines and bytes behind that number')
    // Nothing was declared, so nothing about the repo changed.
    const after = planJson(dir).data
    assert.ok(!after.indexes.some((i) => i.dir === 'tools'), 'pricing a candidate never adopts it')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP10 an index sitting where a reader does not find it is offered a move, unless the slot is taken', () => {
  // The miss that produced this whole pass. lib/INDEX.md is a complete, correct index that GitHub
  // does not render when someone browses lib/. Nothing in the toolkit had a way to say so, so the
  // conversion was never offered and never happened.
  const files = { ...FIXTURE() }
  delete files['lib/README.md']
  files['lib/INDEX.md'] = files['lib/INDEX.md'].replace('| [`one.mjs`](one.mjs)', '| [`one.mjs`](one.mjs)')
  files['CONTRIBUTING.md'] = 'See [the library index](lib/INDEX.md) before adding a file.\n'
  const dir = build(files)
  try {
    const { data } = planJson(dir)
    assert.equal(data.migrationOpportunities.length, 1, 'the README slot is free, so the move is offered')
    const m = data.migrationOpportunities[0]
    assert.equal(m.from, 'lib/INDEX.md')
    assert.equal(m.to, 'lib/README.md')
    assert.ok(m.move.startsWith('git mv '), 'a rename, never a copy and a delete: history follows a file through git mv and does not follow it through a new file beside a deletion')
    assert.ok(m.alsoUpdate.some((a) => a.includes('.file')), 'the config declaration moves in the same change, or the lint is pointed at a document that is no longer there')
    assert.ok(m.alsoUpdate.some((a) => a.includes('docs.extra')), 'and the docs.extra entry, or the page silently leaves the prose sweeps')
    assert.ok(m.links.some((i) => i.file === 'CONTRIBUTING.md'),
      'and every inbound link is found FIRST: a rename that leaves dangling links is worse than no rename, because the page is gone and every reference to it now lies')
    assert.equal(data.structuralWork.migrations, 1, 'an unanswered migration is structural work, so the exit code carries it')
    assert.ok(Array.isArray(m.mentions),
      'links and other mentions are reported apart: one can be repointed mechanically and the other is a judgement, and reporting them as one list is what let this offer promise to fix "every inbound reference"')
    assert.ok(m.retainWith.includes('retain'), 'and retaining is offered as a recordable answer, not only as a thing to decline')
    // The recorded answer, honoured. Without it the offer came back every run, the exit code
    // stayed 1 forever, and a finished decision looked exactly like an ignored one.
    const kept = { ...files }
    const cfg = JSON.parse(kept['.repo-standard.json'])
    cfg.docs.indexes[0].retain = 'the release notes link this path by name, and the redirect is not worth the churn'
    kept['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
    const after = build(kept)
    try {
      const r = planJson(after)
      assert.deepEqual(r.data.migrationOpportunities, [], 'a recorded retain is a finished answer, not a question to re-ask')
      assert.equal(r.data.retained.length, 1, 'and it is reported, with its reason, the same way a decline is')
      assert.equal(r.data.structuralWork.migrations, 0, 'so the exit code stops carrying a decision that has already been made')
    } finally { rmSync(after, { recursive: true, force: true }) }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP10b the move is NOT offered when README.md is itself a shipped artifact', () => {
  // The retain case, and it is the common one in this very repo: payload/templates/README.md IS a
  // template the directory ships. An agent following "the index is the directory's README" would
  // overwrite it. The rule is the slot being free, never the filename being INDEX.md.
  const dir = build(FIXTURE())
  try {
    const { data } = planJson(dir)
    assert.deepEqual(data.migrationOpportunities, [],
      'lib/README.md exists and is not the catalog, so the slot is taken and no move is proposed')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP11 a plan larger than a pipe buffer survives being piped', () => {
  // A plan over 64 KiB used to arrive truncated to exactly 65536 bytes and fail to parse, because
  // the engine called process.exit() while stdout was still draining. Every caller of --json pipes
  // it. The fixture is sized past the buffer on purpose.
  const files = { ...FIXTURE() }
  for (let i = 0; i < 400; i++) files[`lib/gen/file-${String(i).padStart(4, '0')}.mjs`] = `export const n${i} = ${i}\n`
  const dir = build(files)
  try {
    const raw = execFileSync('sh', ['-c', `node ${JSON.stringify(PLANNER)} --target ${JSON.stringify(dir)} --json | cat`], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 })
    assert.ok(raw.length > 65536, `the fixture has to exceed the pipe buffer to prove anything (got ${raw.length} bytes)`)
    const data = JSON.parse(raw)
    assert.ok(data.counts.missing >= 400, 'and the whole plan is there, not the first 64 KiB of it')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP12 --mode decides what the chunks cover, and the exit code never moves', () => {
  const dir = build(FIXTURE())
  try {
    const gaps = planJson(dir, ['--mode', 'gaps'])
    const rec = planJson(dir, ['--mode', 'reconcile'])
    assert.equal(gaps.code, rec.code, 'the mode is about what to READ; the verdict is about what is missing, and they are different questions')
    const gapFiles = gaps.data.indexes[0].chunks.flatMap((c) => c.files)
    const recFiles = rec.data.indexes[0].chunks.flatMap((c) => c.files)
    assert.deepEqual(gapFiles.sort(), [...gaps.data.indexes[0].missing].sort(), 'gaps mode chunks exactly the files carrying no row')
    assert.ok(recFiles.length > gapFiles.length,
      'reconcile mode chunks every file, because a run that only reads the new ones cannot notice that an existing row stopped being true')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP13 a directory the operator turned down stays turned down, without silencing the rest', () => {
  const files = { ...FIXTURE() }
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.declined = [{ dir: 'tools', why: 'three build scripts nobody browses; a glossary of them is decorated nothing' }]
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['other/README.md'] = '# other/\n\nA second directory, never asked about.\n'
  files['other/thing.mjs'] = 'export const thing = 1\n'
  const dir = build(files)
  try {
    const { data } = planJson(dir)
    assert.ok(!data.candidates.some((c) => c.dir === 'tools'), 'a recorded no is not asked again')
    assert.ok(data.candidates.some((c) => c.dir === 'other'),
      'but it is a no about ONE directory: a repo-wide decline would suppress the candidates that matter along with the leaf nobody wants catalogued')
    const recorded = data.declined.find((d) => d.dir === 'tools')
    assert.ok(recorded, 'and the decline is reported, never silent')
    assert.ok(recorded.why, 'with the reason on the page, because a no with no reason is indistinguishable from an oversight')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

// ── the git-backed universe ───────────────────────────────────────────────────────────────
// Everything below this line exists because an adversarial pass found files that vanish from
// every coverage claim both engines make while the build stays green. A file nobody indexed is
// the failure RS-index exists to catch; a file nobody can SEE is worse, because the check reports
// success about a set it silently shrank.

check('IP14 a path git has to quote still owes a row', () => {
  // `git ls-files` renders anything outside plain ASCII as a C-quoted string: docs/café.md comes
  // back as "docs/caf\303\251.md", quotes included. Intersecting that against a filesystem walk
  // matched nothing, so the file dropped out of the universe entirely and both engines reported a
  // complete index over a directory with an uncatalogued file in it.
  const files = { ...FIXTURE() }
  files['lib/café.mjs'] = 'export const cafe = 1\n'
  files['lib/two words.mjs'] = 'export const spaced = 1\n'
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    assert.equal(data.universe.kind, 'git', 'the fixture is a git worktree, so the git universe is the one under test')
    const planned = data.indexes[0].files.map((f) => f.path)
    assert.ok(planned.includes('lib/café.mjs'), 'a non-ASCII filename owes a row like any other file')
    assert.ok(planned.includes('lib/two words.mjs'), 'and so does one with a space in it')
    assert.ok(lintOf(dir).out.includes('café.mjs'),
      'and the gate has to demand it too, or the planner sends an agent to write a row CI does not want')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP15 a symlink is owned and named, never silently dropped', () => {
  // git tracks a symlink as a file and a reader browsing the directory sees one, but a walk built
  // on Dirent.isFile() yields neither a file nor a directory for it, so it fell out of both
  // universes. The policy is deliberate and stated: it owes a row, and it is reported AS a symlink
  // rather than read through, because following one double-counts the target's content and a link
  // to a directory would walk forever.
  const files = { ...FIXTURE() }
  const dir = buildGit(files)
  try {
    symlinkSync('one.mjs', join(dir, 'lib', 'alias.mjs'))
    execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'ignore' })
    const { data } = planJson(dir)
    const ix = data.indexes[0]
    assert.ok(ix.files.some((f) => f.path === 'lib/alias.mjs'), 'a tracked symlink is a kept file and owes a row')
    const un = ix.unreadable.find((u) => u.path === 'lib/alias.mjs')
    assert.ok(un, 'and it is named as something an agent must not describe from its contents')
    assert.ok(/symlink/.test(un.why), `the reason says what it is, because "unreadable" and "a link to one.mjs" call for different rows\n${JSON.stringify(un)}`)
    assert.ok(lintOf(dir).out.includes('alias.mjs'), 'and the gate demands the same row')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

// ── one owner per file ────────────────────────────────────────────────────────────────────

const NESTED = () => {
  // A parent that speaks for code and a child that speaks for prose. The interesting file is the
  // one the child's directory holds and the child's extensions do not cover: the parent stopped at
  // the whole directory, the child never claimed it, and it belonged to nobody.
  const cfg = {
    version: 1,
    docs: {
      extra: ['lib/README.md', 'lib/deep/README.md'],
      indexes: [
        { file: 'lib/README.md', extensions: ['.mjs', '.json'], statuses: ['active'], reconciled: true },
        { file: 'lib/deep/README.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true },
      ],
    },
  }
  const row = (p) => `| [\`${p}\`](${p}) | What it is for. | \`active\` |`
  return {
    '.repo-standard.json': `${JSON.stringify(cfg, null, 2)}\n`,
    'lib/README.md': `# lib/\n\n**The library.**\n\nReconciled against the code: 2026-01-01 (agent sweep)\n\n| File | What it is for | Status |\n|---|---|---|\n${row('one.mjs')}\n`,
    'lib/one.mjs': 'export const one = 1\n',
    'lib/deep/README.md': `# lib/deep/\n\n**The nested part.**\n\nReconciled against the code: 2026-01-01 (agent sweep)\n\n| File | What it is for | Status |\n|---|---|---|\n${row('notes.md')}\n`,
    'lib/deep/notes.md': '# notes\n',
  }
}

check('IP16 a child index bounds its parent only for the files it actually owns', () => {
  // The hole: lib/README.md speaks for .json anywhere under lib/, lib/deep/README.md speaks only
  // for .md, and lib/deep/config.json belonged to neither. Adding it left both tables and the
  // whole gate green. A boundary drawn at the child DIRECTORY throws away the child's own
  // declaration, which is the only thing that says what the child is authoritative about.
  const files = NESTED()
  files['lib/deep/config.json'] = '{ "nested": true }\n'
  const dir = build(files)
  try {
    const { code, data } = planJson(dir)
    const parent = data.indexes.find((ix) => ix.file === 'lib/README.md')
    assert.ok(parent.missing.includes('lib/deep/config.json'),
      `the parent speaks for .json under lib/ and the child does not speak for .json at all, so the parent owes this row\n${JSON.stringify(data.indexes.map((i) => ({ f: i.file, missing: i.missing })))}`)
    assert.equal(code, 1, 'and an uncatalogued file is structural work')
    assert.ok(lintOf(dir).out.includes('lib/deep/config.json'), 'and the gate demands it, or the planner and CI disagree about the sweep')
    assert.deepEqual(data.unownedFiles ?? [], [], 'a file the parent owns is owned, not unowned: exactly one index answers for it')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP17 no file is owned by two indexes, and a row in both tables is reported', () => {
  // Two authoritative descriptions of one file, in two tables, with no way to tell which is
  // current. The containment check never saw it: lib/deep/notes.md IS under lib/, so a row for it
  // in the parent resolved, existed, and counted as coverage.
  const files = NESTED()
  files['lib/README.md'] += '| [`deep/notes.md`](deep/notes.md) | The same file, described twice. | `active` |\n'
  const dir = build(files)
  try {
    const { data } = planJson(dir)
    const dupes = data.crossIndexDuplicates ?? []
    assert.equal(dupes.length, 1, `lib/deep/notes.md is catalogued by both indexes and must be reported once\n${JSON.stringify(dupes)}`)
    assert.equal(dupes[0].target, 'lib/deep/notes.md')
    assert.deepEqual([...dupes[0].indexes].sort(), ['lib/README.md', 'lib/deep/README.md'],
      'and the report names both tables, because the fix is deleting one row and only the operator knows which')
    assert.ok(data.structuralWork.crossIndexDuplicates >= 1, 'two owners is structural work: neither table is authoritative while it stands')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP18 narrowing to one index never changes what any index owns', () => {
  // --index deleted the other declarations before ownership was computed, so a narrowed plan
  // claimed files the child index owns and the full plan (and the gate) did not. The declaration
  // list is the config's, and asking about one index is a question about REPORTING, not scope.
  const files = NESTED()
  files['lib/deep/config.json'] = '{ "nested": true }\n'
  const dir = build(files)
  try {
    const full = planJson(dir).data.indexes.find((ix) => ix.file === 'lib/README.md')
    const narrowed = planJson(dir, ['--index', 'lib/README.md']).data.indexes[0]
    assert.deepEqual([...narrowed.missing].sort(), [...full.missing].sort(),
      `a narrowed plan and the full plan must agree about the index they both cover\n narrowed ${JSON.stringify(narrowed.missing)}\n full     ${JSON.stringify(full.missing)}`)
    assert.deepEqual(narrowed.files.map((f) => f.path).sort(), full.files.map((f) => f.path).sort(),
      'and about every file it speaks for, not only the gaps')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP19 a kept file no index owns is surfaced as a decision, never left invisible', () => {
  // The north star is every directory. A `direct` index (which is what the atlas skill declares on
  // every new one) owns the files beside it and nothing below, so a nested directory with no
  // declaration of its own belonged to nobody, was never offered, and read as complete coverage.
  const cfg = {
    version: 1,
    docs: {
      extra: ['lib/README.md'],
      indexes: [{ file: 'lib/README.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], reconciled: true }],
    },
  }
  const dir = build({
    '.repo-standard.json': `${JSON.stringify(cfg, null, 2)}\n`,
    'lib/README.md': '# lib/\n\n**The library.**\n\nReconciled against the code: 2026-01-01 (agent sweep)\n\n| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | The first thing. | `active` |\n',
    'lib/one.mjs': 'export const one = 1\n',
    'lib/deep/two.mjs': 'export const two = 2\n',
    'lib/deep/Dockerfile': 'FROM scratch\n',
  })
  try {
    const { code, data } = planJson(dir)
    assert.ok((data.unownedFiles ?? []).some((f) => f.path === 'lib/deep/two.mjs'),
      `lib/deep/two.mjs is inside an indexed tree and no declaration owns it\n${JSON.stringify(data.unownedFiles)}`)
    assert.ok((data.unownedFiles ?? []).some((f) => f.path === 'lib/deep/Dockerfile'),
      'and so is a file with no extension at all: an extension-only selector omits Dockerfile, Makefile, and every extensionless executable, silently')
    assert.ok(data.candidates.some((c) => c.dir === 'lib/deep'),
      'and the directory is offered for a decision even though it keeps no README, because "has a README" was never the rule that mattered')
    assert.equal(code, 1, 'an undecided directory is structural work: create an index, extend a parent, or record a reasoned decline')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP20 an all-kept-files selector exists, so a directory can be covered completely', () => {
  const cfg = {
    version: 1,
    docs: {
      extra: ['lib/README.md'],
      indexes: [{ file: 'lib/README.md', extensions: ['*'], scope: 'direct', statuses: ['active'], reconciled: true }],
    },
  }
  const dir = build({
    '.repo-standard.json': `${JSON.stringify(cfg, null, 2)}\n`,
    'lib/README.md': '# lib/\n\n**The library.**\n\nReconciled against the code: 2026-01-01 (agent sweep)\n\n| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | The first thing. | `active` |\n',
    'lib/one.mjs': 'export const one = 1\n',
    'lib/Dockerfile': 'FROM scratch\n',
    'lib/Makefile': 'all:\n\ttrue\n',
  })
  try {
    const { data } = planJson(dir)
    const missing = data.indexes[0].missing
    assert.deepEqual([...missing].sort(), ['lib/Dockerfile', 'lib/Makefile'],
      `"*" means every kept file the directory holds, which is the only selector that can promise complete coverage\n${JSON.stringify(missing)}`)
    assert.ok(lintOf(dir).out.includes('lib/Dockerfile'), 'and the gate reads it the same way')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

// ── parsing and refusals ──────────────────────────────────────────────────────────────────

check('IP21 a link target the decoder rejects is reported, never thrown', () => {
  // decodeURI('100%.mjs') throws URIError. The planner died with a stack trace and no JSON at all,
  // which every caller reads as a failed run rather than a bad row, and the exit code it left
  // behind was indistinguishable from "there is work to do".
  const files = { ...FIXTURE() }
  files['lib/100%.mjs'] = 'export const odd = 1\n'
  files['lib/INDEX.md'] += '| [`100%.mjs`](100%.mjs) | A row whose target is not valid percent-encoding. | `active` |\n'
  const dir = build(files)
  try {
    const r = plan(dir, ['--json'])
    const data = JSON.parse(r.out) // must not throw: a crash produces no JSON at all
    const bad = data.indexes[0].undecodable ?? []
    assert.equal(bad.length, 1, `the row is reported as undecodable rather than crashing the run\n${JSON.stringify(data.indexes[0])}`)
    assert.equal(bad[0].raw, '100%.mjs', 'and the raw target is quoted back, because the fix is in the page')
    const lint = lintOf(dir)
    assert.ok(!/URIError/.test(lint.out), `and the gate diagnoses it rather than leaking a decoder stack trace\n${lint.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP22 baseline: the differential fixture is clean to BOTH engines, or every case below proves nothing', () => {
  const dir = buildGit(CLEAN())
  try {
    const p = plan(dir), l = lintOf(dir)
    assert.equal(p.code, 0, `the planner must call the differential baseline clean\n${p.out}`)
    assert.equal(l.code, 0, `the gate must call the differential baseline clean\n${l.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

// EXACT EXIT CLASSES, both engines, one mutation each. `2` is a broken config, `1` is work to do
// (structural for the planner, drifted docs for the gate), `0` is clean. Asserting the PAIR is
// what the old check did not do: it asserted `lint != 0`, which passes when one engine calls a
// config broken and the other calls the same config merely incomplete, and that is the pairing
// that sends an expensive fan-out at a repo the cheap check has already refused.
const DIFFERENTIAL = [
  // ── the config surface ────────────────────────────────────────────────────────────────
  ['docs declared as an array', 2, (c) => { c.docs = [] }],
  ['docs.extra holding a non-string', 2, (c) => { c.docs.extra = [1, 'lib/README.md'] }],
  ['an unknown docs key', 2, (c) => { c.docs.bogus = 1 }],
  ['an unknown top-level key', 2, (c) => { c.bogus = 1 }],
  ['a manifest that is not an object', 2, (c) => { c.manifest = 7 }],
  ['a manifest with no file', 2, (c) => { c.manifest = { statuses: ['NEW'] } }],
  ['a config version that is not 1', 2, (c) => { c.version = 2 }],
  ['docs.indexes that is not an array', 2, (c) => { c.docs.indexes = {} }],
  ['both index spellings at once', 2, (c) => { c.docs.index = { file: 'lib/README.md' } }],
  ['a readme GitHub does not serve', 2, (c) => { c.docs.readme = 'doc/README.md' }],
  ['extensions that are not strings', 2, (c) => { c.docs.indexes[0].extensions = [1] }],
  ['an extension written without its dot', 2, (c) => { c.docs.indexes[0].extensions = ['mjs'] }],
  ['a padded extension', 2, (c) => { c.docs.indexes[0].extensions = [' .mjs '] }],
  ['a padded status word', 2, (c) => { c.docs.indexes[0].statuses = [' active '] }],
  ['a status word outside the canon', 2, (c) => { c.docs.indexes[0].statuses = ['wip'] }],
  ['a non-boolean ordered', 2, (c) => { c.docs.indexes[0].ordered = 'yes' }],
  ['a scope outside the pair', 2, (c) => { c.docs.indexes[0].scope = 'deep' }],
  ['a grammar version that does not exist', 2, (c) => { c.docs.indexes[0].grammar = 3 }],
  ['an ownership mode outside the pair', 2, (c) => { c.docs.ownership = 'total' }],
  ['a retain with no reason', 2, (c) => { c.docs.indexes[0].retain = '' }],
  ['two indexes cataloguing one directory', 2, (c) => { c.docs.extra.push('lib/OTHER.md'); c.docs.indexes.push({ file: 'lib/OTHER.md', statuses: ['active'], reconciled: true }) }],
  ['declines written as bare strings', 2, (c) => { c.docs.declined = ['lib'] }],
  ['a decline with no reason', 2, (c) => { c.docs.declined = [{ dir: 'lib' }] }],
  ['a decline naming a file', 2, (c) => { c.docs.declined = [{ dir: 'lib/one.mjs', why: 'a file' }] }],
  ['a decline that also declares an index', 2, (c) => { c.docs.declined = [{ dir: 'lib', why: 'both at once' }] }],
  // ── the ONE path contract, on every key that carries a path ───────────────────────────
  ['an index declared outside the repo', 2, (c) => { c.docs.indexes[0].file = '../outside/README.md'; c.docs.extra = ['../outside/README.md'] }],
  ['an ignore entry outside the repo', 2, (c) => { c.docs.indexes[0].ignore = ['../outside'] }],
  ['a decline outside the repo', 2, (c) => { c.docs.declined = [{ dir: '/etc', why: 'absolute' }] }],
  ['a docs.extra entry outside the repo', 2, (c) => { c.docs.extra.push('../outside/prose.md') }],
  ['a manifest file outside the repo', 2, (c) => { c.manifest = { file: '../outside/MANIFEST.md', statuses: ['NEW'] } }],
  ['an assets.dir outside the repo', 2, (c) => { c.assets = { dir: '../outside/art' } }],
  ['a changelog outside the repo', 2, (c) => { c.docs.changelog = '../outside/CHANGELOG.md' }],
  // ── the row grammar, which is the page rather than the config ─────────────────────────
  ['a row with no status word', 1, (c, f) => { f['lib/README.md'] = f['lib/README.md'].replace('| `active` |', '|  |') }],
  ['a row dated with a day no calendar has', 1, (c, f) => { c.docs.indexes[0].requireDate = true; f['lib/README.md'] = f['lib/README.md'].replace('| Status |', '| Status | Last verified |').replace('|---|---|---|', '|---|---|---|---|').replace('| `active` |', '| `active` | 2026-99-99 |') }],
  ['an index missing its reconciliation line', 1, (c, f) => { f['lib/README.md'] = f['lib/README.md'].replace(/Reconciled against the code:[^\n]*\n/, '') }],
  ['a reconciliation line dated February 30th', 1, (c, f) => { f['lib/README.md'] = f['lib/README.md'].replace('2026-01-01', '2026-02-30') }],
  ['an index that exists and lists nothing', 1, (c, f) => { f['lib/README.md'] = '# lib/\n\nReconciled against the code: 2026-01-01\n\nNo table at all.\n' }],
  ['a file with no row', 1, (c, f) => { f['lib/two.mjs'] = 'export const two = 2\n' }],
  ['a row pointing at a file that is gone', 1, (c, f) => { f['lib/README.md'] += '| [`gone.mjs`](gone.mjs) | Rotted. | `active` |\n' }],
  ['a row the table carries twice', 1, (c, f) => { f['lib/README.md'] += '| [`one.mjs`](one.mjs) | Described again. | `active` |\n' }],
  ['a row reaching outside the directory', 1, (c, f) => { f['lib/README.md'] += '| [`../README.md`](../README.md) | Out of scope. | `active` |\n' }],
  ['a link that never closes', 1, (c, f) => { f['lib/two.mjs'] = 'export const two = 2\n'; f['lib/README.md'] += '| [`two.mjs`](two.mjs | Never closes. | `active` |\n' }],
  ['rows out of ascending order', 1, (c, f) => { f['lib/a-two.mjs'] = 'export const t = 2\n'; f['lib/README.md'] += '| [`a-two.mjs`](a-two.mjs) | Sorts before one.mjs. | `active` |\n' }],
  ['a declared index that does not exist', 1, (c, f) => { delete f['lib/README.md'] }],
  ['an index no prose sweep governs', 2, (c) => { c.docs.extra = [] }],
  // ── the three cases an external audit found still disagreeing outside this table ──────
  // Each was a real divergence: the planner refused what the gate accepted, or the gate crashed
  // where the planner refused. A crash is its own answer, because node exits 1 and the caller
  // reads a config error as doc drift.
  ['a root config that is JSON null', 2, (c, f) => { f['.repo-standard.json'] = 'null\n' }],
  ['a root config that is a JSON array', 2, (c, f) => { f['.repo-standard.json'] = '[]\n' }],
  ['a manifest of null, which reads as ABSENT to the gate and must here too', 0, (c) => { c.manifest = null }],
  ['a decline spelled with a backslash, before any normaliser can repair it', 2, (c) => { c.docs.declined = [{ dir: 'ghost\\dir', why: 'a directory named with a backslash' }] }],
  ['an assets.coverage.ignore entry outside the repo', 2, (c) => { c.assets = { dir: '.github/assets', coverage: { roots: ['.'], ignore: ['../outside'] } } }],
  // ── the grammar-2 column contract, which neither engine was actually holding ───────────
  ['a link outside the FILE column', 1, (c, f) => { f['lib/README.md'] = f['lib/README.md'].replace('| [`one.mjs`](one.mjs) | The only engine. |', '|  | [`one.mjs`](one.mjs) The only engine. |') }],
  ['a table with no status column while statuses are declared', 1, (c, f) => { f['lib/README.md'] = f['lib/README.md'].replace('| File | What it is for | Status |', '| File | What it is for | Phase |').replace('| The only engine. | `active` |', '| `active`, the only engine. |  |') }],
  ['a table with no verification-date column while requireDate is on', 1, (c, f) => { c.docs.indexes[0].requireDate = true; f['lib/README.md'] = f['lib/README.md'].replace('| File | What it is for | Status |', '| File | What it is for | Status | Added |').replace('|---|---|---|', '|---|---|---|---|').replace('| `active` |', '| `active` | 2026-01-01 |') }],
  ['a fenced table reopened by a "```notclose" line inside it', 1, (c, f) => { f['lib/two.mjs'] = 'export const two = 2\n'; f['lib/README.md'] += '\n```text\n```notclose\n| File | What it is for | Status |\n|---|---|---|\n| [`two.mjs`](two.mjs) | Fenced. | `active` |\n```\n' }],
  ['a link whose closure is answered by a LATER link in the same cell', 1, (c, f) => { f['lib/two.mjs'] = 'export const two = 2\n'; f['lib/README.md'] += '| [`two.mjs`](two.mjs see also [x](one.mjs) | Never closes. | `active` |\n' }],
  ['a row-absolute destination, which GitHub resolves against the domain', 1, (c, f) => { f['lib/README.md'] = f['lib/README.md'].replace('](one.mjs)', '](/one.mjs)') }],
  /*
   * ── SPELLING BEFORE NORMALISATION, on every key that was tidied up first ──────────────
   *
   * Each of these was a live divergence found by an external audit: the planner (or sense) ran
   * `.trim()` BEFORE handing the value to the path contract, so a control character was removed and
   * the value accepted, while the gate judged the same key untrimmed and exited 2. A normaliser
   * that runs first repairs the very spelling the contract exists to refuse, which is the rule the
   * contract states in its own comment and three call sites were breaking.
   */
  ['an index file with a leading control character', 2, (c) => { c.docs.indexes[0].file = '\nlib/README.md' }],
  ['a decline with a leading control character', 2, (c) => { c.docs.declined = [{ dir: '\nghost', why: 'a control character in front of a directory name' }] }],
  ['an assets.coverage.ignore entry with a leading control character', 2, (c) => { c.assets = { dir: '.github/assets', coverage: { roots: ['.'], ignore: ['\nlib'] } } }],
  /*
   * ── ROUTE-SELECTING FIELDS, refused by TYPE rather than defaulted past ────────────────
   *
   * `assets.dir` selects which manifest is read and which generator gets run; `ignore.file`
   * selects which file the secrets ruleset is read from. A wrong type fell through to the default
   * in the planner and in sense while the gate exited 2, so the cheap engines described a
   * directory the config never chose and the expensive one refused the config outright.
   */
  ['an assets block that is not an object', 2, (c) => { c.assets = 7 }],
  ['an assets.dir that is not a string', 2, (c) => { c.assets = { dir: 7 } }],
  ['an ignore block that is not an object', 2, (c) => { c.ignore = 7 }],
  ['an ignore.file that is not a string', 2, (c) => { c.ignore = { file: 7 } }],
  // ── tolerated by BOTH, which is as much a parity claim as a refusal ───────────────────
  ['a nested $schema, which is an editor hint', 0, (c) => { c.docs.indexes[0].$schema = 'x' }],
  ['an operator comment key', 0, (c) => { c.docs.indexes[0]['//why'] = 'because' }],
  ['a leading ./ on a path, which is a spelling', 0, (c) => { c.docs.indexes[0].ignore = ['./lib/nothing'] }],
]

check(`IP23 the two engines return the SAME exit class on all ${DIFFERENTIAL.length} differential cases`, () => {
  const disagreed = []
  for (const [name, want, mutate] of DIFFERENTIAL) {
    const files = off((c, f) => mutate(c, f))
    const dir = buildGit(files)
    try {
      const p = plan(dir), l = lintOf(dir)
      if (p.code !== want || l.code !== want) {
        disagreed.push(`${name}: expected ${want}/${want}, got planner ${p.code} / gate ${l.code}\n      planner: ${(p.out.split('\n').find((x) => x.trim()) ?? '').slice(0, 150)}\n      gate:    ${(l.out.split('\n').filter((x) => /✗|^  - /.test(x))[0] ?? '(no failure line)').slice(0, 150)}`)
      }
    } finally { rmSync(dir, { recursive: true, force: true }) }
  }
  assert.deepEqual(disagreed, [], disagreed.length
    ? `${disagreed.length} case(s) where the planner and the gate do not agree on the exit class:\n    ${disagreed.join('\n    ')}`
    : '')
})

check('IP23e a path git keeps that no engine can see is NAMED, and it fails closed in both', () => {
  /*
   * THE UNIVERSE ITSELF. Both engines listed git's output as a utf8 string and dropped every path
   * whose lstat failed, which quietly excused two kinds of tracked file:
   *   a SPARSE or SKIP-WORKTREE entry, tracked and deliberately not materialised. An uncatalogued
   *     one went from a red build to a green one by being hidden from the worktree.
   *   a filename that is not valid UTF-8, which decodes to U+FFFD, matches nothing on disk, and
   *     left the set with nothing said.
   * Both are false greens over a SMALLER repo than the one git tracks, so both now fail closed.
   */
  const commit = (dir) => {
    execFileSync('git', ['config', 'user.email', 't@t.t'], { cwd: dir, stdio: 'ignore' })
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'ignore' })
    execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'ignore' })
    execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir, stdio: 'ignore' })
  }
  // 1. a tracked file with no row, hidden by skip-worktree.
  let dir = buildGit(CLEAN())
  try {
    writeFileSync(join(dir, 'lib', 'ghost.mjs'), 'export const ghost = 1\n')
    commit(dir)
    assert.equal(plan(dir).code, 1, 'while it is on disk it is an uncatalogued file, and both engines say so')
    assert.equal(lintOf(dir).code, 1, 'including the gate')
    execFileSync('git', ['update-index', '--skip-worktree', 'lib/ghost.mjs'], { cwd: dir, stdio: 'ignore' })
    rmSync(join(dir, 'lib', 'ghost.mjs'))
    const p = plan(dir), l = lintOf(dir)
    assert.equal(p.code, 1, `hiding a tracked file from the worktree must not turn a red plan green\n${p.out}`)
    assert.ok(p.out.includes('lib/ghost.mjs') && p.out.includes('skip-worktree'), `and the planner names the path and why\n${p.out}`)
    assert.equal(l.code, 1, `nor a red gate\n${l.out}`)
    assert.ok(l.out.includes('RS-index (universe)'), `and the gate names the universe as the reason\n${l.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
  // 2. a tracked filename whose bytes are not valid UTF-8.
  dir = buildGit(CLEAN())
  try {
    // The path is handed to fs as BYTES: a name containing 0xFF cannot be written through a
    // JavaScript string without the encoder repairing the very thing under test.
    writeFileSync(Buffer.concat([Buffer.from(`${dir}/lib/bad`), Buffer.from([0xff]), Buffer.from('.mjs')]), 'export const bad = 1\n')
    commit(dir)
    const p = plan(dir), l = lintOf(dir)
    assert.equal(p.code, 1, `a tracked path that cannot be decoded must not leave the set in silence\n${p.out}`)
    assert.ok(p.out.includes('not valid UTF-8'), `and it is named as what it is\n${p.out}`)
    assert.equal(l.code, 1, `the gate agrees\n${l.out}`)
    assert.ok(l.out.includes('RS-index (universe)'), `naming the universe\n${l.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
  // 3. the boundary: a path git itself reports as DELETED is on its way out and owes no row, so
  // this must not redden every repo mid-`git rm`. A rule that fails closed on everything is not a
  // rule, it is an outage.
  dir = buildGit(CLEAN())
  try {
    commit(dir)
    writeFileSync(join(dir, 'lib', 'two.mjs'), 'export const two = 2\n')
    execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'ignore' })
    execFileSync('git', ['commit', '-qm', 'two'], { cwd: dir, stdio: 'ignore' })
    execFileSync('git', ['rm', '-q', '--cached', 'lib/two.mjs'], { cwd: dir, stdio: 'ignore' })
    rmSync(join(dir, 'lib', 'two.mjs'))
    const p = plan(dir), l = lintOf(dir)
    assert.equal(p.code, 0, `a staged deletion is not a hidden file, and it owes no row\n${p.out}`)
    assert.equal(l.code, 0, `and the gate agrees\n${l.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP23f a migration reports the moving page\'s own links, and never promotes a fenced example', () => {
  /*
   * Two ways the change set was incomplete, and one of them was UNSAFE rather than merely thin.
   *   The moving page was skipped in discovery, so `[this page](INDEX.md)` inside the index being
   *     renamed appeared in neither list and dangled after the move.
   *   `blankCode` ended a fence on any line starting with a backtick run, and a closing fence may
   *     not carry an info string (CommonMark 4.5). A ```` ```notclose ```` line inside a block
   *     therefore reopened it here and not on GitHub, and a link in a fenced EXAMPLE was
   *     classified as a verified live link: the one list this offer promises is safe to apply
   *     mechanically.
   */
  const files = CLEAN()
  files['.repo-standard.json'] = JSON.stringify({
    version: 1,
    docs: { extra: ['lib/INDEX.md'], indexes: [{ file: 'lib/INDEX.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }] },
  }, null, 2) + '\n'
  files['lib/INDEX.md'] = files['lib/README.md'].replace('# lib/', '# lib/\n\nA note about [this page](INDEX.md) itself.')
  delete files['lib/README.md']
  files['lib/one.mjs'] = 'export const one = 1\n'
  files['docs/example.md'] = '# Example\n\n```text\n```notclose\n[the index](../lib/INDEX.md)\n```\n'
  const dir = build(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'lib/INDEX.md')
    assert.ok(m, 'the move is offered, or there is nothing to test')
    const selfLinks = m.links.filter((l) => l.file === 'lib/INDEX.md')
    assert.equal(selfLinks.length, 1, `the moving page's own link to itself is a link to REPOINT: skipping the page hid the one reference the rename is guaranteed to break\n${JSON.stringify(m.links, null, 2)}`)
    assert.equal(m.links.filter((l) => l.file === 'docs/example.md').length, 0,
      'and a link inside a code fence is never queued for a mechanical rewrite, whatever backtick runs sit inside the block')
    assert.ok(m.mentions.some((l) => l.file === 'docs/example.md'),
      'it is handed to a person instead, which is what the two lists are for')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP23b a prospective declaration is one the gate would accept', () => {
  // `--candidate` prices a directory that keeps no index YET, and what it prices becomes a
  // declaration somebody writes down. `--extensions mjs` (no dot) was accepted here and exits 2
  // there, so the offer an operator agreed to could not be recorded.
  const dir = buildGit(off((c, f) => { f['tools/build.mjs'] = 'export const b = 1\n' }))
  try {
    const bad = plan(dir, ['--candidate', 'tools', '--extensions', 'mjs'])
    assert.equal(bad.code, 2, `an extensions list the gate exits 2 on must be refused before it is priced\n${bad.out}`)
    assert.ok(bad.out.includes('starting with a dot'), `and the refusal names the rule\n${bad.out}`)
    const ok = planJson(dir, ['--candidate', 'tools', '--extensions', '.mjs'])
    assert.equal(ok.data.indexes[0].prospective, true, 'the accepted form still prices the directory')
    assert.equal(ok.data.indexes[0].grammar, 2, 'and a page this journey would WRITE is priced under the grammar it would write it in')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP23c a configured path that resolves outside the repo is refused by both engines', () => {
  // The lexical rule checks the SPELLING; a symlink is the same hole in a spelling the rule
  // cannot see. An in-repo index that is a link to a sibling checkout was read by both engines
  // and reported structurally complete: a green verdict earned by cataloguing a tree neither
  // governs, which changed when the sibling changed.
  const outside = mkdtempSync(join(tmpdir(), 'rs-outside-'))
  writeFileSync(join(outside, 'external.md'), '# elsewhere\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | Written outside. | `active` |\n')
  const files = CLEAN()
  delete files['lib/README.md']
  const dir = buildGit(files)
  try {
    symlinkSync(join(outside, 'external.md'), join(dir, 'lib', 'README.md'))
    const p = plan(dir), l = lintOf(dir)
    assert.equal(p.code, 2, `the planner must refuse an index whose bytes live outside the repo\n${p.out}`)
    assert.equal(l.code, 2, `and so must the gate, or one of them goes green on prose it does not govern\n${l.out}`)
    for (const [who, out] of [['planner', p.out], ['gate', l.out]]) {
      assert.ok(/resolves OUTSIDE this repo/.test(out), `the ${who} should say the path resolves outside the repo\n${out}`)
    }
    // The same hole in its command-line spelling.
    const cand = plan(dir, ['--candidate', `../${join(outside).split('/').pop()}`, '--extensions', '.md'])
    assert.equal(cand.code, 2, `--candidate must go through the same path contract as a configured one\n${cand.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }); rmSync(outside, { recursive: true, force: true }) }
})

check('IP23d a decline naming a symlink is refused, because git keeps a symlink as one file', () => {
  // stat() follows a link, so a symlink to a directory answered isDirectory() and was accepted as
  // a DIRECTORY decline. That silently excused the symlink itself, which is a kept file that owes
  // a row: an `ignore` entry wearing a decline's clothes, which is the exact substitution the
  // rest of the check refuses.
  const files = CLEAN()
  const dir = buildGit(files)
  try {
    mkdirSync(join(dir, 'real'), { recursive: true })
    writeFileSync(join(dir, 'real', 'x.mjs'), 'export const x = 1\n')
    symlinkSync(join(dir, 'real'), join(dir, 'linked'))
    const cfg = JSON.parse(readFileSync(join(dir, '.repo-standard.json'), 'utf8'))
    cfg.docs.declined = [{ dir: 'linked', why: 'a symlink, not a directory' }]
    writeFileSync(join(dir, '.repo-standard.json'), `${JSON.stringify(cfg, null, 2)}\n`)
    const p = plan(dir), l = lintOf(dir)
    assert.equal(p.code, 2, `the planner must refuse a decline naming a symlink\n${p.out}`)
    assert.equal(l.code, 2, `and so must the gate\n${l.out}`)
    for (const [who, out] of [['planner', p.out], ['gate', l.out]]) {
      assert.ok(/symlink rather than a directory/.test(out), `the ${who} should say what it actually is\n${out}`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})
check('IP24 narrowing to one index never hides a duplicate the full plan catches', () => {
  // A file catalogued by BOTH a parent and its child was caught by the full plan, missed by
  // either narrowed run, and failed at the gate. A reconciliation of one directory could finish
  // clean and leave the build red, which is the worst possible shape for a narrowed run: the
  // cheap check disagrees with the expensive one about a fact, not about scope.
  const files = { ...FIXTURE() }
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['lib/INDEX.md', 'lib/deep/README.md']
  cfg.docs.indexes[0].extensions = ['.mjs', '.json', '.md']
  cfg.docs.indexes.push({ file: 'lib/deep/README.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], reconciled: true })
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['lib/INDEX.md'] = files['lib/INDEX.md'].replace(
    '| [`one.mjs`](one.mjs) | The first thing. | `active` |\n',
    '| [`one.mjs`](one.mjs) | The first thing. | `active` |\n| [`deep/three.mjs`](deep/three.mjs) | Claimed here too. | `active` |\n')
  files['lib/deep/README.md'] = '# lib/deep/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`three.mjs`](three.mjs) | The third thing. | `active` |\n'
  const dir = build(files)
  try {
    assert.notEqual(lintOf(dir).code, 0, 'the gate must reject the duplicate, or this proves nothing')
    assert.equal(plan(dir).code, 1, 'the full plan reports it')
    for (const ix of ['lib/INDEX.md', 'lib/deep/README.md']) {
      const narrowed = plan(dir, ['--index', ix])
      assert.equal(narrowed.code, 1,
        `--index ${ix} must still see the duplicate: narrowing is a question about what gets REPORTED, and it was never a question about what is true\n${narrowed.out}`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP25 strict ownership carries undecided files in the exit code, and answers close it', () => {
  // Under `declared` an undecided file is reported and unjudged, which is honest and is not the
  // north star. `strict` is the mode where "a file added tomorrow reddens the build" is a
  // sentence this toolkit keeps, and the planner has to agree with the gate about that.
  // Its own fixture, STRUCTURALLY COMPLETE, so the only thing left for a verdict to carry is the
  // undecided file. Reusing the awkward fixture above would have measured its deliberate missing
  // rows instead of the mode under test.
  // The index lives at README.md so no migration is on offer either: the only thing this fixture
  // can put in a verdict is the undecided file.
  const owned = (mode, extra = {}) => build({
    '.repo-standard.json': `${JSON.stringify({
      version: 1,
      docs: {
        extra: ['lib/README.md'],
        ...(mode ? { ownership: mode } : {}),
        indexes: [{ file: 'lib/README.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], reconciled: true, ...extra }],
      },
    }, null, 2)}\n`,
    'lib/README.md': '# lib/\n\nReconciled against the code: 2026-01-01\n\n'
      + '| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | The only engine. | `active` |\n',
    'lib/one.mjs': 'export const one = 1\n',
    // The undecided file: .txt is not a declared extension, so no declaration reaches it.
    'lib/notes.txt': 'nobody has said what this is for\n',
  })
  // Whether the gate's ownership contract passed, failed, or was never asserted at all.
  const ownershipVerdict = (dir) => {
    const out = lintOf(dir).out
    if (out.includes('✗ RS-index (ownership)')) return 'fail'
    if (out.includes('✓ RS-index (ownership)')) return 'pass'
    return 'absent'
  }
  let dir = owned(null)
  try {
    const { data, code } = planJson(dir)
    assert.equal(data.counts.unowned, 1, 'the fixture keeps one file no declaration reaches, or this proves nothing')
    assert.equal(data.undecidedFiles.reachedByExitCode, false, 'under "declared" it is reported and not judged')
    assert.equal(code, 0, 'so an otherwise complete repo is exit 0 with it named')
    assert.equal(ownershipVerdict(dir), 'absent', 'and the gate asserts no ownership contract, because none was declared')
  } finally { rmSync(dir, { recursive: true, force: true }) }
  dir = owned('strict')
  try {
    const { data, code } = planJson(dir)
    assert.equal(data.undecidedFiles.reachedByExitCode, true, 'under "strict" the same file is the verdict')
    assert.equal(code, 1, 'and the exit code carries it')
    assert.equal(ownershipVerdict(dir), 'fail', 'which is what the gate does with the same config, or the two disagree about the contract')
  } finally { rmSync(dir, { recursive: true, force: true }) }
  // Answered by an ignore entry, the way an adopter closes it. A mode nothing can satisfy is a
  // mode nobody turns on.
  dir = owned('strict', { ignore: ['lib/notes.txt'] })
  try {
    assert.equal(planJson(dir).code, 0, 'an ignore entry is a decision, so strict is a contract a repo can actually meet')
    assert.equal(ownershipVerdict(dir), 'pass', 'and the gate agrees, which is the only reason the mode is worth having')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP26 a migration resolves link destinations rather than matching the path as a string', () => {
  // The old discovery was one regex for "this line contains the index path" and a second for
  // "a `](` sits in front of it". It got four things wrong at once, and an applier that trusted
  // it would have edited the wrong files and missed the right ones. Every case here is one of
  // the four, and the assertion is on which LIST each lands in.
  const files = CLEAN()
  delete files['lib/README.md']
  delete files['lib/one.mjs']
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['docs/INDEX.md']
  cfg.docs.indexes = [{ file: 'docs/INDEX.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }]
  cfg.docs.declined = [{ dir: 'lib', why: 'not what this case is about' }]
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['docs/INDEX.md'] = '# docs/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`guide.md`](guide.md) | The guide. | `active` |\n'
  files['docs/guide.md'] = '# Guide\n\nText.\n'
  // MISSED entirely by a string match: the same destination, spelled two other legal ways.
  files['a-dot-slash.md'] = '# A\n\nSee [the index](./docs/INDEX.md).\n'
  files['docs/b-climbing.md'] = '# B\n\nSee [the index](../docs/INDEX.md).\n'
  // Classified as a MENTION, when it is the one line that actually needs the rewrite.
  files['c-reference.md'] = '# C\n\nSee [the index][ix].\n\n[ix]: docs/INDEX.md\n'
  // Classified as LINKS, when both are documentation ABOUT the path rather than references to it.
  files['d-fenced.md'] = '# D\n\n```\n[the index](docs/INDEX.md)\n```\n\nAnd `[x](docs/INDEX.md)` in a code span.\n'
  // Not markdown at all, so a link-shaped string in it is a string.
  files['e-source.mjs'] = 'export const help = "see [the index](docs/INDEX.md)"\n'
  files['f-plain.md'] = '# F\n\nSee [the index](docs/INDEX.md).\n'
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'docs/INDEX.md')
    assert.ok(m, `the move must be on offer, or nothing here is being tested\n${JSON.stringify(data.counts)}`)
    const at = (list) => list.map((e) => `${e.file}:${e.line}`).sort()
    assert.deepEqual(at(m.links), ['a-dot-slash.md:3', 'c-reference.md:5', 'docs/b-climbing.md:3', 'f-plain.md:3'],
      'a link is a destination that RESOLVES to the index from the file it sits in, whatever it was spelled like, plus the reference definition that carries the path')
    const mentioned = at(m.mentions)
    for (const need of ['d-fenced.md:4', 'd-fenced.md:7', 'e-source.mjs:1']) {
      assert.ok(mentioned.includes(need), `${need} is documentation about the path, not a reference to it, so it needs a person rather than an applier\n${mentioned.join(', ')}`)
    }
    for (const never of ['d-fenced.md:4', 'd-fenced.md:7', 'e-source.mjs:1']) {
      assert.ok(!at(m.links).includes(never), `${never} must never be queued for mechanical rewriting`)
    }
    // Every hit lands in exactly one list, or "every inbound link is repointed" is a promise
    // over a set that overlaps itself.
    const all = [...at(m.links), ...mentioned]
    assert.equal(new Set(all).size, all.length, `a reference appears in exactly one list\n${all.join(', ')}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP27 a migration hands the identity pillar a change set rather than a hint', () => {
  // The rename is only lint-green afterwards if the identity side moves too, and the case that
  // shipped broken is a directory EXCLUDED from folder-README coverage: the exclusion is nearly
  // always recorded because the directory keeps its front page under another name, which is the
  // very thing the rename changes.
  const files = CLEAN()
  delete files['lib/README.md']
  delete files['lib/one.mjs']
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['docs/INDEX.md']
  cfg.docs.indexes = [{ file: 'docs/INDEX.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }]
  cfg.docs.declined = [{ dir: 'lib', why: 'not what this case is about' }]
  cfg['//assets'] = 'docs/ is ignored because it keeps its front page as docs/INDEX.md.'
  cfg.assets = { dir: '.github/assets', coverage: { roots: ['.'], ignore: ['docs'] } }
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['docs/INDEX.md'] = '# docs/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`guide.md`](guide.md) | The guide. | `active` |\n'
  files['docs/guide.md'] = '# Guide\n\nText.\n'
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'docs/INDEX.md')
    assert.ok(m, 'the move must be on offer')
    const effects = m.identityEffects ?? []
    assert.ok(effects.length, 'a rename into a directory the identity pillar has been told to skip is not a config-free move')
    const exclusion = effects.find((e) => /coverage exclusion/.test(e.what))
    assert.ok(exclusion, `the coverage exclusion has to be named as an effect, not left as one more grep hit\n${JSON.stringify(effects)}`)
    assert.ok(/Remove the exclusion/.test(exclusion.detail) && /declare a banner/.test(exclusion.detail),
      `and it has to say what the identity run does about it\n${exclusion.detail}`)
    assert.ok(/stops being true/.test(exclusion.detail),
      `the recorded reason names the OLD path, so the sentence itself goes false at the rename and no applier can rewrite a rationale\n${exclusion.detail}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP28 the ownership model states the files it does not reach, rather than passing them', () => {
  // A file at the repo root and a file under a dot-directory were both silently green under
  // strict, which made "every kept file" a sentence neither engine kept. Neither can be owned
  // (an index lives inside the directory it catalogues), so the fix is to NAME them.
  const files = CLEAN()
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.ownership = 'strict'
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['ROOT-UNOWNED'] = 'nobody can own me\n'
  files['.hidden/x.mjs'] = 'export const h = 1\n'
  const dir = buildGit(files)
  try {
    const { data, code } = planJson(dir)
    assert.equal(code, 0, 'the boundary is a stated limit, not a failure: strict stays a mode a repo can meet')
    const outside = data.undecidedFiles.outsideModel
    const paths = outside.files.map((f) => f.path)
    for (const need of ['ROOT-UNOWNED', '.hidden/x.mjs']) {
      assert.ok(paths.includes(need), `${need} sits outside the ownership model and must be NAMED there\n${paths.join(', ')}`)
    }
    const out = lintOf(dir)
    assert.equal(out.code, 0, 'the gate agrees the repo passes strict')
    assert.ok(out.out.includes('RS-index (ownership boundary)'), `and prints the boundary, so the count travels with the claim\n${out.out}`)
    for (const need of ['ROOT-UNOWNED', '.hidden/x.mjs']) {
      assert.ok(out.out.includes(need), `naming ${need}, because a silent exclusion reads exactly like coverage\n${out.out}`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP29 strict enforces before the first index exists, and narrowing never hides the verdict', () => {
  // Two separate false greens with one root: the gate's ownership contract was nested inside its
  // "at least one index is declared" branch, and the planner emptied its candidate list whenever
  // --index narrowed the report. Both meant a repo could be told there was nothing to do while
  // the other engine said there was.
  const zero = CLEAN()
  const zcfg = JSON.parse(zero['.repo-standard.json'])
  zcfg.docs = { ownership: 'strict' }
  zero['.repo-standard.json'] = `${JSON.stringify(zcfg, null, 2)}\n`
  delete zero['lib/README.md']
  zero['tools/x.mjs'] = 'export const x = 1\n'
  let dir = buildGit(zero)
  try {
    assert.equal(plan(dir).code, 1, 'the planner sees a directory nobody has decided about')
    const l = lintOf(dir)
    assert.equal(l.code, 1, `and so must the gate: strict has to mean the same thing before the first index exists as after it\n${l.out}`)
    assert.ok(l.out.includes('✗ RS-index (ownership)'), `naming the contract that failed\n${l.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
  // Narrowing changes what is REPORTED and never what is true.
  const narrow = CLEAN()
  narrow['tools/x.mjs'] = 'export const x = 1\n'
  dir = buildGit(narrow)
  try {
    const full = plan(dir), one = plan(dir, ['--index', 'lib/README.md'])
    assert.equal(full.code, 1, 'the full plan sees the undecided directory')
    assert.equal(one.code, full.code,
      `--index must carry the same verdict: a reconciliation of one directory that finishes clean and leaves the build red is the worst possible pairing\n${one.out}`)
    const { data } = planJson(dir, ['--index', 'lib/README.md'])
    assert.equal(data.scope.narrowed, true, 'and says it narrowed, or an exit code covering more than the detail below reads as a bug')
    assert.deepEqual(data.scope.reporting, ['lib/README.md'], 'naming what it reported')
    assert.ok(data.counts.candidates > 0, 'while still counting what it judged')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

/*
 * ─────────────────────────────────────────────────────── THE GIT-STATE MATRIX (IP24)
 *
 * Every state a tracked path can be in, against the ONE question both engines answer from it:
 * is this file in the universe, and does it owe a row. Written as a table rather than as another
 * set of isolated examples, because the defect this replaces was a rule that happened to be right
 * for the three states somebody thought to test and wrong for the fourth.
 *
 * The fourth was an ORDINARY UNSTAGED DELETION. Both engines subtracted `git ls-files --deleted`,
 * believing it meant "staged for removal". It does not: it means "tracked, and not in the
 * worktree", which is a plain `rm` as well. So an uncatalogued tracked file failed the build, and
 * `rm` on it, with nothing staged and nothing committed, turned both engines green. A staged
 * deletion needs no rule at all, because `git rm` takes the path out of the index and it never
 * reaches the universe in the first place: that is the row below that proves the fix did not
 * simply fail closed on everything.
 */
const gitCommit = (dir) => {
  execFileSync('git', ['config', 'user.email', 't@t.t'], { cwd: dir, stdio: 'ignore' })
  execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'ignore' })
  execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'ignore' })
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir, stdio: 'ignore' })
}
const GIT_STATES = [
  {
    id: 'present', why: 'a tracked file with no row is uncatalogued, and both engines say so',
    setup: (dir) => { writeFileSync(join(dir, 'lib', 'ghost.mjs'), 'export const g = 1\n'); gitCommit(dir) },
    planner: 1, lint: 1, names: 'lib/ghost.mjs',
  },
  {
    id: 'unstaged-deletion', why: 'a plain rm leaves the path in the index and off the disk: it is still tracked, and hiding it must not turn a red build green',
    setup: (dir) => {
      writeFileSync(join(dir, 'lib', 'ghost.mjs'), 'export const g = 1\n'); gitCommit(dir)
      rmSync(join(dir, 'lib', 'ghost.mjs'))
    },
    planner: 1, lint: 1, names: 'lib/ghost.mjs', universe: true,
  },
  {
    id: 'staged-deletion', why: 'git rm takes the path OUT of the index, so it never enters the universe and owes nothing: the rule must not redden a repo mid-removal',
    setup: (dir) => {
      writeFileSync(join(dir, 'lib', 'ghost.mjs'), 'export const g = 1\n'); gitCommit(dir)
      execFileSync('git', ['rm', '-q', 'lib/ghost.mjs'], { cwd: dir, stdio: 'ignore' })
    },
    planner: 0, lint: 0,
  },
  {
    id: 'skip-worktree', why: 'a tracked file deliberately not materialised is still tracked and still owes a row',
    setup: (dir) => {
      writeFileSync(join(dir, 'lib', 'ghost.mjs'), 'export const g = 1\n'); gitCommit(dir)
      execFileSync('git', ['update-index', '--skip-worktree', 'lib/ghost.mjs'], { cwd: dir, stdio: 'ignore' })
      rmSync(join(dir, 'lib', 'ghost.mjs'))
    },
    planner: 1, lint: 1, names: 'lib/ghost.mjs', universe: true,
  },
  {
    id: 'gitlink', why: 'a submodule is another repository\'s whole content, and nobody writes a row for a tree they do not own',
    setup: (dir) => {
      gitCommit(dir)
      mkdirSync(join(dir, 'lib', 'vendored'), { recursive: true })
      writeFileSync(join(dir, 'lib', 'vendored', '.keep'), '')
      execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'ignore' })
      execFileSync('git', ['rm', '-q', '--cached', 'lib/vendored/.keep'], { cwd: dir, stdio: 'ignore' })
      execFileSync('git', ['update-index', '--add', '--cacheinfo', '160000,e69de29bb2d1d6434b8b29ae775ad8c2e48c5391,lib/vendored'], { cwd: dir, stdio: 'ignore' })
      rmSync(join(dir, 'lib', 'vendored', '.keep'), { force: true })
    },
    planner: 0, lint: 0,
  },
  {
    id: 'symlink', why: 'git tracks a symlink as one file and a reader browsing the directory sees one, so it owes a row like anything else',
    setup: (dir) => { symlinkSync('one.mjs', join(dir, 'lib', 'link.mjs')); gitCommit(dir) },
    planner: 1, lint: 1, names: 'lib/link.mjs',
  },
  {
    // The FILE-TYPE false green an external audit found. Every engine filtered the listing with one
    // question, "does lstat call this a directory", and a yes was silently dropped. A tracked,
    // uncatalogued blob was red in all three; replacing it with a DIRECTORY at the same path made
    // all three green, because the blob git still carries stopped being a file on disk.
    id: 'file-now-a-directory', why: 'a tracked blob with a directory sitting at its path cannot be read, catalogued, or held to any coverage rule, and dropping it turned a red build green',
    setup: (dir) => {
      writeFileSync(join(dir, 'lib', 'ghost.mjs'), 'export const g = 1\n'); gitCommit(dir)
      rmSync(join(dir, 'lib', 'ghost.mjs'))
      mkdirSync(join(dir, 'lib', 'ghost.mjs'), { recursive: true })
    },
    planner: 1, lint: 1, names: 'lib/ghost.mjs', universe: true,
  },
  {
    // The control that keeps the rule above narrow. `ls-files --others` reports an untracked nested
    // repository as one directory entry, and nothing in the index claims it is a blob: that is the
    // case the directory skip was written for, and it is the only one left in it.
    id: 'untracked-nested-repo', why: 'an untracked nested repository is one directory entry git never called a file, and nobody owes a row for a checkout this repo does not track',
    setup: (dir) => {
      gitCommit(dir)
      mkdirSync(join(dir, 'nested'), { recursive: true })
      execFileSync('git', ['init', '-q'], { cwd: join(dir, 'nested'), stdio: 'ignore' })
      writeFileSync(join(dir, 'nested', 'x.mjs'), 'export const x = 1\n')
    },
    planner: 0, lint: 0,
  },
  {
    id: 'invalid-utf8', why: 'a name no markdown link can spell can carry no row, and it must not leave the set in silence',
    setup: (dir) => {
      writeFileSync(Buffer.concat([Buffer.from(`${dir}/lib/bad`), Buffer.from([0xff]), Buffer.from('.mjs')]), 'export const b = 1\n')
      gitCommit(dir)
    },
    planner: 1, lint: 1, universe: true,
  },
]
for (const state of GIT_STATES) {
  check(`IP24-${state.id} ${state.why}`, () => {
    const dir = buildGit(CLEAN())
    try {
      state.setup(dir)
      const pl = plan(dir), li = lintOf(dir)
      assert.equal(pl.code, state.planner, `planner expected exit ${state.planner}\n${pl.out}`)
      assert.equal(li.code, state.lint, `the gate expected exit ${state.lint}\n${li.out}`)
      if (state.names) {
        assert.ok(pl.out.includes(state.names), `the planner names the path\n${pl.out}`)
        assert.ok(li.out.includes(state.names), `and so does the gate\n${li.out}`)
      }
      if (state.universe) {
        assert.ok(li.out.includes('RS-index (universe)'), `the gate names the UNIVERSE as the reason, not a missing row: the set itself is what went wrong\n${li.out}`)
        assert.ok(pl.out.includes('CANNOT ENTER the universe'), `and the planner says the same about the same set\n${pl.out}`)
        // The THIRD engine, which builds the same universe from the same listing and was the one
        // left out of this matrix. It decides whether the pillar is offered at all, so a set it
        // cannot see is a set it must refuse to reason about rather than one it silently shrinks.
        const s = senseJson(dir)
        assert.ok(s.data.atlas.universeErrors.length > 0, `sense builds the same universe and must lose the same path\n${JSON.stringify(s.data.atlas)}`)
        assert.equal(s.data.plan.find((x) => x.artifact === 'per-directory indexes (.repo-standard.json)').action, 'blocked-universe',
          `and it stops rather than offering work computed from a set with holes in it\n${JSON.stringify(s.data.plan)}`)
      }
    } finally { rmSync(dir, { recursive: true, force: true }) }
  })
}

/*
 * ──────────────────────────────────────────── THE NON-RENDERING MATRIX (IP25)
 *
 * A glossary that is complete, correct, column-bound and INVISIBLE. Every row below carries the
 * whole table, written perfectly, in a context markdown does not render as a table, and both
 * engines reported full coverage on every one of them. Strict ownership could therefore report a
 * repo completely catalogued while a reader browsing the directory saw no glossary at all.
 *
 * The positive controls matter as much as the negatives. A rule that refuses a table in a comment
 * is worthless if it also refuses the ordinary idioms: a status cell in backticks, a filename in
 * backticks inside the link LABEL, a table indented up to three spaces, and a single-hyphen
 * delimiter row, which is valid GFM and which GitHub renders.
 */
const TABLE = ['| File | What it is for | Status |', '|---|---|---|', '| [`one.mjs`](one.mjs) | The only engine. | `active` |']
const withTable = (lines) => {
  const files = CLEAN()
  files['lib/README.md'] = `# lib/\n\nReconciled against the code: 2026-01-01\n\n${lines.join('\n')}\n`
  return files
}
const NON_RENDERING = [
  ['html-comment', 'a table inside an HTML comment renders as nothing at all', ['<!--', ...TABLE, '-->'], 1],
  ['indented-code', 'a table indented four spaces after a blank line is a code block', TABLE.map((l) => `    ${l}`), 1],
  ['fenced', 'a table inside a fence is an EXAMPLE of a table', ['\u0060\u0060\u0060', ...TABLE, '\u0060\u0060\u0060'], 1],
  /*
   * The seven an external audit found still passing after the first three were closed. Each carries
   * a complete, correct, column-bound glossary that no reader can see, and each was full coverage
   * to BOTH engines.
   */
  ['unclosed-html-comment', 'a comment nobody closed swallows the rest of the document on GitHub, and matched nothing at all here', ['<!-- the note that was never closed', ...TABLE], 1],
  ['pre-block', 'a table inside <pre> is raw HTML: markdown never parses it and a reader sees literal text', ['<pre>', ...TABLE, '</pre>'], 1],
  ['indented-under-heading', 'four spaces directly under an ATX heading is a code block, because a heading closes the paragraph an indented block may not interrupt', ['## Example', ...TABLE.map((l) => `    ${l}`)], 1],
  ['indented-pseudo-close', 'a closing fence may be indented at most three spaces (CommonMark 4.5), so four does not close the block and everything after it is still inside it', ['```text', '    ```', ...TABLE, '```'], 1],
  ['escaped-link', 'a backslash-escaped bracket renders as a literal bracket, so the cell holds no link and catalogues nothing',
    ['| File | What it is for | Status |', '|---|---|---|', '| \\[one.mjs](one.mjs) | The only engine. | `active` |'], 1],
  ['image-not-link', 'an image renders the file as a picture: a reader cannot click through to it, and a catalog row is the one place a destination has to be navigable',
    ['| File | What it is for | Status |', '|---|---|---|', '| ![one.mjs](one.mjs) | The only engine. | `active` |'], 1],
  ['html-block', 'a table inside a <div> with no blank line after it is markup up to the next blank line, not a table',
    ['<div align="center">', ...TABLE, '</div>'], 1],
  ['link-in-code-span', 'a link inside a code span renders as literal text and catalogues nothing',
    ['| File | What it is for | Status |', '|---|---|---|', '| `[one.mjs](one.mjs)` | The only engine. | `active` |'], 1],
  ['delimiter-cell-count', 'a delimiter row that does not match the header cell count opens no table (GFM 4.10)',
    ['| File | What it is for | Status |', '| --- | not a delimiter |', '| [`one.mjs`](one.mjs) | The only engine. | `active` |'], 1],
  // The controls: each of these renders, so each of these is coverage.
  ['plain', 'the ordinary table is coverage', TABLE, 0],
  ['single-hyphen-delimiter', 'a single-hyphen delimiter row is valid GFM and GitHub renders it', ['| File | What it is for | Status |', '|-|-|-|', '| [`one.mjs`](one.mjs) | The only engine. | `active` |'], 0],
  ['indented-three', 'a table indented three spaces still renders, so it is still coverage', TABLE.map((l) => `   ${l}`), 0],
  ['aligned-delimiter', 'a colon-aligned delimiter row is a delimiter row', ['| File | What it is for | Status |', '|:---|:---:|---:|', '| [`one.mjs`](one.mjs) | The only engine. | `active` |'], 0],
  // The controls for the six above. A rule that refuses an invisible table is worth nothing if it
  // also refuses the ordinary page: a table after a CLOSED comment, after a closed <pre>, after a
  // heading with the usual blank line under it, and inside a <div> that has one.
  ['after-closed-comment', 'a table after a comment somebody closed is an ordinary table', ['<!-- a note -->', '', ...TABLE], 0],
  ['after-closed-pre', 'a table after a closed <pre> block is an ordinary table', ['<pre>', 'example text', '</pre>', '', ...TABLE], 0],
  ['under-heading-with-blank', 'a table under a heading, indented nothing, is the ordinary idiom', ['## Files', '', ...TABLE], 0],
  ['inside-div-with-blank', 'a blank line ends an HTML block, so the table under a centred div renders', ['<div align="center">', '', ...TABLE, '', '</div>'], 0],
  ['escaped-bang-is-a-link', 'an escaped exclamation mark is a literal one, so what follows is a LINK and catalogues the file',
    ['| File | What it is for | Status |', '|---|---|---|', '| \\![one.mjs](one.mjs) | The only engine. | `active` |'], 0],
]
for (const [id, why, lines, code] of NON_RENDERING) {
  check(`IP25-${id} ${why}`, () => {
    const dir = buildGit(withTable(lines))
    try {
      const pl = plan(dir), li = lintOf(dir)
      assert.equal(pl.code, code, `planner expected exit ${code}\n${pl.out}`)
      assert.equal(li.code, code, `the gate expected exit ${code}: the two engines read one page, so they read it the same way\n${li.out}`)
    } finally { rmSync(dir, { recursive: true, force: true }) }
  })
}

/*
 * ─────────────────────────────────────── THE MIGRATION-OCCURRENCE MATRIX (IP26)
 *
 * Classification is per OCCURRENCE, and an occurrence is a range of bytes rather than a line.
 * Keying on (line, destination) made a LINE the unit, and a line holds more than one thing: each
 * row below is a single line of ordinary prose that the old model got wrong, in a list whose whole
 * promise is that `links` is safe to apply mechanically and `mentions` is what a person reads.
 */
check('IP26 every reference on a line is classified on its own, and nothing lands in neither list', () => {
  const files = CLEAN()
  files['.repo-standard.json'] = JSON.stringify({
    version: 1,
    docs: { extra: ['lib/INDEX.md', 'notes.md'], indexes: [{ file: 'lib/INDEX.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }] },
  }, null, 2) + '\n'
  files['lib/INDEX.md'] = files['lib/README.md']
  delete files['lib/README.md']
  files['notes.md'] = [
    'L1 a live [index](lib/INDEX.md) and a code span `[index](lib/INDEX.md)` together.',
    'L2 a live [index](lib/INDEX.md) and a plain mention of lib/INDEX.md together.',
    'L3 a raw HTML link: <a href="lib/INDEX.md">the index</a>.',
    'L4 a dotted spelling: [x](./lib/INDEX.md).',
    'L5 a full URL: https://github.com/o/r/blob/main/lib/INDEX.md',
    'L6 two mentions: lib/INDEX.md and lib/INDEX.md again.',
    '',
    'L8 a multiline span: `alpha',
    'L9 beta` closed, then a LIVE link: [x](lib/INDEX.md).',
    '',
  ].join('\n')
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'lib/INDEX.md')
    assert.ok(m, 'the move is offered, or there is nothing to classify')
    const at = (list, line) => list.filter((e) => e.file === 'notes.md' && e.line === line).length
    // One live link and one code-span example on one line: two entries, one in each list. Keyed on
    // the line, the code span was reported as a live link and an applier would have rewritten it.
    assert.equal(at(m.links, 1), 1, `L1: the live link is a link\n${JSON.stringify(m.links, null, 2)}`)
    assert.equal(at(m.mentions, 1), 1, `L1: and the identical link inside a code span is a MENTION, not a second live link\n${JSON.stringify(m.mentions, null, 2)}`)
    // A live link and a plain mention on one line. The mention scan skipped any line a link had
    // claimed, so the mention was reported in NEITHER list.
    assert.equal(at(m.links, 2), 1, 'L2: the live link is a link')
    assert.equal(at(m.mentions, 2), 1, 'L2: and the plain mention beside it is still reported')
    // Raw HTML renders as a working link that no markdown rule can repoint: a person's job.
    assert.equal(at(m.links, 3), 0, 'L3: raw HTML is never queued for a mechanical markdown rewrite')
    assert.equal(at(m.mentions, 3), 1, 'L3: it is handed to a person instead')
    assert.equal(at(m.links, 4), 1, 'L4: "./lib/INDEX.md" is the same destination, spelled differently')
    // A path inside a full URL used to match nothing, because the boundary before it refused "/".
    assert.equal(at(m.mentions, 5), 1, 'L5: the path inside a full URL is a mention, not nothing')
    assert.equal(at(m.mentions, 6), 2, 'L6: two mentions on one line are two things to judge')
    // The multiline span shifted every later line number in the blanked copy, so a genuinely live
    // link after one was classified as an example and dropped out of the links list.
    assert.equal(at(m.links, 9), 1, `L9: a live link AFTER a multiline code span is still a live link\n${JSON.stringify(m.mentions, null, 2)}`)
    assert.equal(at(m.mentions, 9), 0, 'L9: and it is not also reported as an example')
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

/*
 * ────────────────────────────── THE MIGRATION-CLASSIFICATION MATRIX (IP30)
 *
 * `links` is the list this offer calls SAFE TO APPLY MECHANICALLY, and that is the whole claim an
 * applier would rest on. An external audit put a disposable fixture and a real repository through
 * it and found the promise broken in both directions at once: contents of comments, indented code,
 * <pre> blocks, escaped syntax and an unclosed link were all PROMOTED into the safe list, while
 * `./INDEX.md`, a percent-encoded spelling and an escaped destination landed in NEITHER list.
 *
 * The golden case is the first row. On the real target the repository's front page carried
 *
 *     - [`docs/INDEX.md`](docs/INDEX.md): the full documentation index.
 *
 * which is one genuine, live, mechanically repointable link, and it was demoted to a mention
 * because an overlap test saw the backticks in the link's LABEL. Atlas reported 0 links and 13
 * mentions on a tree with a real link in it.
 *
 * Every row states the list it must land in. `neither` is never an answer.
 */
const MIGRATION_CASES = [
  ['golden-backticked-label', 'links', 'See [`docs/INDEX.md`](docs/INDEX.md): the full documentation index.',
    'a code span inside a link LABEL is the ordinary idiom, and the link around it is live'],
  ['plain-link', 'links', 'See [the index](docs/INDEX.md).', 'the ordinary case'],
  ['dot-slash-link', 'links', 'See [the index](./docs/INDEX.md).', 'the same destination, spelled with a leading ./'],
  ['escaped-destination', 'links', 'See [the index](docs/INDEX\\.md).',
    'CommonMark 2.4 lets any ASCII punctuation be escaped in a destination, so this names the same file and used to resolve to nothing and match no text scan either'],
  ['in-comment', 'mentions', '<!-- see [the index](docs/INDEX.md) -->', 'a comment renders as nothing at all'],
  ['in-unclosed-comment', 'mentions', '<!-- see [the index](docs/INDEX.md)', 'a comment nobody closed swallows the rest of the page'],
  ['in-pre', 'mentions', '<pre>\n[the index](docs/INDEX.md)\n</pre>', '<pre> content is raw HTML a reader sees as literal text'],
  ['in-indented-code', 'mentions', 'Example:\n\n    [the index](docs/INDEX.md)', 'four spaces after a blank line is a code block'],
  ['escaped-bracket', 'mentions', 'See \\[the index](docs/INDEX.md).', 'an escaped bracket renders as a literal bracket, so this is not a link at all'],
  ['unclosed-link', 'mentions', 'See [the index](docs/INDEX.md and more.', 'a link with no closing parenthesis renders as literal text'],
  ['image', 'mentions', 'See ![the index](docs/INDEX.md).', 'an image is not a navigable link, and what the page meant is a judgement'],
  ['percent-encoded', 'mentions', 'The URL https://example.test/blob/main/docs/INDEX%2Emd names it.',
    'a percent-encoded spelling names the same page and matched no literal scan, so it used to be reported in neither list'],
  ['raw-html', 'mentions', 'See <a href="docs/INDEX.md">the index</a>.', 'GitHub renders it and no markdown rule reaches it'],
]
check(`IP30 every one of the ${MIGRATION_CASES.length} migration-occurrence cases lands in the list it belongs in, and none lands in neither`, () => {
  const files = CLEAN()
  delete files['lib/README.md']
  delete files['lib/one.mjs']
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['docs/INDEX.md', ...MIGRATION_CASES.map(([id]) => `case-${id}.md`)]
  cfg.docs.indexes = [{ file: 'docs/INDEX.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }]
  cfg.docs.declined = [{ dir: 'lib', why: 'not what this case is about' }]
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['docs/INDEX.md'] = '# docs/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`guide.md`](guide.md) | The guide. | `active` |\n'
  files['docs/guide.md'] = '# Guide\n\nText.\n'
  for (const [id, , body] of MIGRATION_CASES) files[`case-${id}.md`] = `# ${id}\n\n${body}\n`
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'docs/INDEX.md')
    assert.ok(m, `the move must be on offer, or nothing here is being tested\n${JSON.stringify(data.counts)}`)
    const wrong = []
    for (const [id, want, , why] of MIGRATION_CASES) {
      const file = `case-${id}.md`
      const inLinks = m.links.some((e) => e.file === file)
      const inMentions = m.mentions.some((e) => e.file === file)
      const got = inLinks && inMentions ? 'both' : inLinks ? 'links' : inMentions ? 'mentions' : 'neither'
      if (got !== want) wrong.push(`${id}: expected ${want}, got ${got} (${why})`)
    }
    assert.deepEqual(wrong, [], wrong.length ? `${wrong.length} occurrence(s) classified wrongly:\n    ${wrong.join('\n    ')}` : '')
    // Every entry carries its SOURCE RANGE, because an applier that has to re-find the occurrence
    // by string matching repeats the whole classification, which is the expensive half.
    for (const e of [...m.links, ...m.mentions]) {
      assert.ok(Number.isInteger(e.start) && Number.isInteger(e.end) && e.end > e.start,
        `every occurrence records the byte range it covers: ${JSON.stringify(e)}`)
    }
    for (const e of m.links) {
      assert.equal(e.resolves, 'docs/INDEX.md', `every link records the destination it RESOLVED to, decoded: ${JSON.stringify(e)}`)
    }
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP30b a bare basename counts where it is written as a path, and unrelated prose about somebody else\'s file does not', () => {
  /*
   * The real repository's roadmap carried a row reading `| 14 | submission-package INDEX.md |`,
   * and it was reported as an inbound reference to docs/INDEX.md, which it has nothing to do with.
   * No rule over the two words alone can tell that from a genuine reference, so the short form
   * counts where the character in front of it says a filename follows. The trade is stated in the
   * engine and asserted here: a bare basename in flowing prose is given up deliberately.
   */
  const files = CLEAN()
  delete files['lib/README.md']
  delete files['lib/one.mjs']
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['docs/INDEX.md', 'docs/roadmap.md', 'docs/refs.md']
  cfg.docs.indexes = [{ file: 'docs/INDEX.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }]
  cfg.docs.declined = [{ dir: 'lib', why: 'not what this case is about' }]
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['docs/INDEX.md'] = '# docs/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`guide.md`](guide.md) | The guide. | `active` |\n'
  files['docs/guide.md'] = '# Guide\n\nText.\n'
  files['docs/roadmap.md'] = '# Roadmap\n\n| 14 | submission-package INDEX.md | targetmap |\n'
  files['docs/refs.md'] = '# Refs\n\nThe catalog is `INDEX.md`.\n\nAlso ./INDEX.md sits beside this page.\n'
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'docs/INDEX.md')
    assert.ok(m, 'the move must be on offer')
    const where = [...m.links, ...m.mentions].map((e) => `${e.file}:${e.line}`)
    assert.ok(!where.some((w) => w.startsWith('docs/roadmap.md')),
      `an unrelated compound noun is not an inbound reference\n${where.join(', ')}`)
    assert.ok(m.mentions.some((e) => e.file === 'docs/refs.md' && e.line === 3), `a basename in a code span is written as a path\n${where.join(', ')}`)
    assert.ok(m.mentions.some((e) => e.file === 'docs/refs.md' && e.line === 5), `and so is "./INDEX.md", which used to land in neither list\n${where.join(', ')}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP30c a changelog occurrence is manual unless it can be PROVEN to sit above released history', () => {
  /*
   * The old guard looked for `## [x]` and treated everything above the first match as safe. A
   * changelog whose headings read `## v1.2.3` matched nothing, the guard never fired, and every
   * link inside shipped history was queued as a mechanical rewrite: the one class of edit this
   * offer promises never to make. The burden is now the other way round.
   */
  const files = CLEAN()
  delete files['lib/README.md']
  delete files['lib/one.mjs']
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['docs/INDEX.md']
  cfg.docs.indexes = [{ file: 'docs/INDEX.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }]
  cfg.docs.declined = [{ dir: 'lib', why: 'not what this case is about' }]
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['docs/INDEX.md'] = '# docs/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`guide.md`](guide.md) | The guide. | `active` |\n'
  files['docs/guide.md'] = '# Guide\n\nText.\n'
  // Headings written without brackets: the spelling the old regex could not see.
  files['CHANGELOG.md'] = ['# Changelog', '', 'Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).', '',
    '## [Unreleased]', '', '### Added', '', '- A pointer to [the index](docs/INDEX.md).', '',
    '## v1.0.0 - 2026-01-01', '', '### Added', '', '- Shipped [the index](docs/INDEX.md).', ''].join('\n')
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'docs/INDEX.md')
    assert.ok(m, 'the move must be on offer')
    const inChangelog = (list) => list.filter((e) => e.file === 'CHANGELOG.md').map((e) => e.line)
    assert.deepEqual(inChangelog(m.links), [9],
      `the [Unreleased] occurrence is above a release boundary this engine could actually find, so it is safe and is the ONLY changelog line that may be\n${JSON.stringify(m.links, null, 2)}`)
    assert.deepEqual(inChangelog(m.mentions), [15],
      `and the one under "## v1.0.0" is shipped history, which the old bracket-only regex could not see at all\n${JSON.stringify(m.mentions, null, 2)}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP30d a changelog whose release boundary cannot be found at all is manual from end to end', () => {
  // The other half of the reversed burden. If no released section can be identified, nothing in
  // the file can be SHOWN to sit above one, so nothing in it is offered for mechanical rewriting.
  const files = CLEAN()
  delete files['lib/README.md']
  delete files['lib/one.mjs']
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.extra = ['docs/INDEX.md']
  cfg.docs.indexes = [{ file: 'docs/INDEX.md', extensions: ['.md'], scope: 'direct', statuses: ['active'], reconciled: true, grammar: 2 }]
  cfg.docs.declined = [{ dir: 'lib', why: 'not what this case is about' }]
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  files['docs/INDEX.md'] = '# docs/\n\nReconciled against the code: 2026-01-01\n\n'
    + '| File | What it is for | Status |\n|---|---|---|\n| [`guide.md`](guide.md) | The guide. | `active` |\n'
  files['docs/guide.md'] = '# Guide\n\nText.\n'
  files['CHANGELOG.md'] = ['# Changelog', '', 'Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).', '',
    '## [Unreleased]', '', '### Added', '', '- A pointer to [the index](docs/INDEX.md).', ''].join('\n')
  const dir = buildGit(files)
  try {
    const { data } = planJson(dir)
    const m = data.migrationOpportunities.find((x) => x.from === 'docs/INDEX.md')
    assert.ok(m, 'the move must be on offer')
    assert.deepEqual(m.links.filter((e) => e.file === 'CHANGELOG.md'), [],
      `with no release section to anchor on, no changelog line is mechanically safe\n${JSON.stringify(m.links, null, 2)}`)
    assert.deepEqual(m.mentions.filter((e) => e.file === 'CHANGELOG.md').map((e) => e.line), [9],
      `and the occurrence is still reported for a person\n${JSON.stringify(m.mentions, null, 2)}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

// ── the three engines, compared on SETS rather than on verdicts ───────────────────────────
/*
 * Exit-class parity proves the two build engines agree about whether something is wrong. It proves
 * nothing about WHAT, and it never reached sense-state at all: an external audit found a
 * force-tracked node_modules/kept.js red in the planner and the gate under strict ownership while
 * sense filtered the directory away, returned strictFailures: 0, and reported `keep` on a repo
 * whose build was already failing. The cheap sensor that decides whether the pillar runs was the
 * one saying there was nothing to do.
 */
check('IP31 the planner and sense agree on the exact universe, candidate and unowned SETS, not merely on a verdict', () => {
  const files = CLEAN()
  const cfg = JSON.parse(files['.repo-standard.json'])
  cfg.docs.ownership = 'strict'
  files['.repo-standard.json'] = `${JSON.stringify(cfg, null, 2)}\n`
  // A kept file inside the indexed directory that no declaration reaches (the index speaks for
  // .mjs), an undeclared directory holding kept files, and a force-tracked node_modules entry.
  files['lib/data.json'] = '{ "kept": true }\n'
  files['tools/build.mjs'] = 'export const build = () => {}\n'
  files['node_modules/kept.js'] = 'module.exports = 1\n'
  const dir = buildGit(files)
  try {
    execFileSync('git', ['add', '-f', 'node_modules/kept.js'], { cwd: dir, stdio: 'ignore' })
    const p = planJson(dir), s = senseJson(dir), l = lintOf(dir)
    const sorted = (a) => [...a].sort()
    assert.deepEqual(sorted(s.data.atlas.unownedFiles), sorted(p.data.unownedFiles.map((f) => f.path)),
      `the two engines list the same unowned files\n  sense:   ${JSON.stringify(s.data.atlas.unownedFiles)}\n  planner: ${JSON.stringify(p.data.unownedFiles.map((f) => f.path))}`)
    assert.deepEqual(sorted(s.data.atlas.candidates), sorted(p.data.candidates.map((c) => c.dir)),
      `and the same candidate directories: a directory git says holds kept files is a candidate in every engine, including node_modules once somebody force-added a file to it\n  sense:   ${JSON.stringify(s.data.atlas.candidates)}\n  planner: ${JSON.stringify(p.data.candidates.map((c) => c.dir))}`)
    assert.ok(s.data.atlas.candidates.includes('node_modules'),
      `a force-tracked node_modules file makes the directory a candidate: the walk's exclusion is a guess about what a repo keeps, and git has already answered it\n${JSON.stringify(s.data.atlas.candidates)}`)
    assert.ok(s.data.atlas.strictFailures > 0, 'strict ownership is on and the tree is not clean, so sense must not report zero failures')
    const atlasEntry = s.data.plan.find((x) => x.artifact === 'per-directory indexes (.repo-standard.json)')
    assert.equal(atlasEntry.action, 'offer', `and it must not report "keep" on a repo whose build is red\n${JSON.stringify(atlasEntry)}`)
    assert.equal(p.code, 1, `the planner exits 1 on this tree\n${p.data.verdict?.means ?? ''}`)
    assert.equal(l.code, 1, `and so does the gate\n${l.out}`)
    // The gate names the same two things by the same names: the unowned FILE inside the indexed
    // directory, and the undecided DIRECTORY outside it. A force-tracked node_modules is the second
    // kind, which is exactly why sense filtering the directory away made it disappear entirely.
    assert.ok(l.out.includes('lib/data.json'), `the gate names the unowned file too\n${l.out}`)
    assert.ok(/node_modules/.test(l.out) && /tools/.test(l.out), `and both undecided directories, so all three engines describe one set\n${l.out}`)
  } finally { rmSync(dir, { recursive: true, force: true }) }
})

check('IP32 a path that resolves outside the repo is refused whether it was DECLARED or defaulted', () => {
  /*
   * Every path key went through the contract when it was written down, and none of them did when
   * the config stayed silent. A key left undeclared is a value the config CHOSE, and a default
   * cannot be misspelled but it can still be SUBSTITUTED: a root README.md that is a symlink into a
   * sibling checkout was read by the planner and by sense, and refused by the gate.
   */
  const outside = mkdtempSync(join(tmpdir(), 'rs-outside-'))
  writeFileSync(join(outside, 'README.md'), '# Elsewhere\n\n**Another repo entirely.**\n')
  const dir = buildGit(CLEAN())
  try {
    rmSync(join(dir, 'README.md'))
    symlinkSync(join(outside, 'README.md'), join(dir, 'README.md'))
    const p = plan(dir), l = lintOf(dir), s = senseJson(dir)
    assert.equal(p.code, 2, `the planner refuses a default that resolves outside the repo\n${p.out}`)
    assert.equal(l.code, 2, `and so does the gate\n${l.out}`)
    assert.ok(p.out.includes('the default'), `and says it was the default that was refused, not a key somebody wrote\n${p.out}`)
    assert.ok(s.data.substitutions.some((x) => x.path === 'README.md'),
      `sense reports the substitution rather than reading through it\n${JSON.stringify(s.data.substitutions)}`)
    assert.equal(s.data.plan.find((x) => x.artifact === 'README.md').action, 'blocked-link',
      `and the plan action is terminal, because there is nothing honest to say about a page whose bytes this repo does not commit\n${JSON.stringify(s.data.plan)}`)
  } finally {
    rmSync(dir, { recursive: true, force: true })
    rmSync(outside, { recursive: true, force: true })
  }
})

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
