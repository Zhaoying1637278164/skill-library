#!/usr/bin/env node
/*
 * test-skill-wiring.mjs — the skill layer is wired to real files with real grants.
 *
 * WHY: SKILL.md is prose the agent follows; a renamed engine, a payload path typo, or a missing
 * tool grant fails silently at runtime, in someone else's repo, mid-scaffold. This test binds the
 * prose to the tree: every engine and payload asset a skill references must exist, and every
 * engine it runs must be granted in its allowed-tools.
 *
 *   W1  the skill roster is exactly the built set (a directory each, with a SKILL.md).
 *   W2  every SKILL.md has frontmatter (name == dir, description, allowed-tools) + the fixed
 *       section anatomy (When to use / Prerequisites / Steps / Automated vs. manual recap /
 *       What feeds the next skill).
 *   W3  every ${CLAUDE_PLUGIN_ROOT}/harness/<engine>.mjs a skill invokes exists AND is granted.
 *   W4  every Bash(node *harness/<x>.mjs *) grant names a real engine (no dead grants).
 *   W5  every ${CLAUDE_PLUGIN_ROOT}/payload/... path a skill references exists on disk.
 *   W6  plugin.json is coherent: parses, points skills at ./skills/, semver version,
 *       and its license id matches the LICENSE file actually shipped.
 *   W7  this repo publishes NO marketplace of its own. A marketplace name is a GLOBAL key in
 *       the user's settings, so a namespace needs exactly one authority: when this repo and
 *       sf-security-review-toolkit each shipped a marketplace.json claiming `runverdict-plugins`
 *       and listing only themselves, `marketplace add` of the second REPLACED the first and
 *       knocked its installed plugins to "failed to load". The catalog lives in
 *       runverdict/plugins, which lists Verdict's published toolkits with github sources;
 *       this repo ships a plugin.json and stays out of the namespace business.
 *   W8  every `gh …` command a skill documents is covered by a Bash grant in its
 *       allowed-tools — a documented command with no grant fails at runtime, mid-scaffold,
 *       in someone else's repo (the same binding W3 gives the harness engines).
 *   W9  the same binding for the engines this toolkit COMMITS INTO a repo and then tells a
 *       skill to run: the installed lint, and the asset generator beside the manifest. Scaffold
 *       instructed itself to re-render an upgraded generator while holding no grant that could
 *       run one.
 *   W10 every frontmatter PARSES as YAML and keeps its fields. W2 checks that the right words
 *       are present; W10 checks that a loader can read them. All four skills once shipped an
 *       unquoted description containing ": ", which YAML refuses, and the loader answers by
 *       dropping every field and loading the skill with empty metadata rather than by failing.
 *   W11 the official `claude plugin validate` accepts the plugin, when the CLI is on this
 *       machine. Named skip when it is not, because CI has no CLI and W10 has to hold there.
 *   W12 a skill that says it INVOKES another one holds the Skill tool. Atlas was told to hand a
 *       migration's identity effects to the identity pillar while granted no tool that could
 *       reach it, so the handoff could only ever be a sentence in a recap.
 *   W13 every `/repo-standard-toolkit:<name>` any skill writes names a skill that exists. A
 *       handoff to a skill nobody ships is a dead end the operator finds, not the build.
 *   W14 the ownership chain is stated where a reader hits it: atlas invokes identity for a
 *       nonempty `identityEffects` or brings back an operator decision, and it may not dispose
 *       of one itself. A run performed a migration, called the resulting identity work out of
 *       scope, kept the coverage exclusion the rename had just falsified, and invoked the atlas
 *       journey afterwards.
 *   W15 the post-write ordering survives in prose: atlas content, then identity, then voice,
 *       then the lint. Each stage writes markdown the next one reads, and a prose scan taken
 *       before identity writes its H1s scans a page that does not exist yet.
 *   W16 scaffold treats an empty or unrecognisable generator preview as a STOP. Invoked through
 *       a path it could not recognise as its own, the generator exited 0 having printed nothing,
 *       which is byte for byte what an up-to-date repo looks like, and the journey replaced an
 *       engine on the strength of a preview that had never run.
 *   W17 the fan-out is priced in CHUNKS and no skill instructs a recap to state a count of
 *       agents. A run priced 38 chunks, launched 34 calls, and reported "38 agents".
 *
 * Dependency-free: `node acceptance/test-skill-wiring.mjs`.
 */
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const read = (rel) => readFileSync(join(ROOT, rel), 'utf8')

let pass = 0, fail = 0, skip = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }
const SKIPPED = Symbol('skipped')
const skipped = (why) => { const e = new Error(why); e[SKIPPED] = true; throw e }
const checkOrSkip = (name, fn) => {
  try { fn(); pass++; console.log(`  ✓ ${name}`) }
  catch (e) {
    if (e[SKIPPED]) { skip++; console.log(`  – ${name} SKIP (${e.message})`) }
    else { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) }
  }
}

const EXPECTED_ROSTER = ['atlas', 'identity', 'scaffold', 'voice']
const REQUIRED_SECTIONS = ['## When to use', '## Prerequisites', '## Steps', '## Automated vs. manual recap', '## What feeds the next skill']

console.log('skill-wiring standing test')

const skillDirs = readdirSync(join(ROOT, 'skills')).filter((d) => statSync(join(ROOT, 'skills', d)).isDirectory()).sort()

check('W1 the skill roster is exactly the built set, each with a non-empty SKILL.md', () => {
  assert.deepEqual(skillDirs, EXPECTED_ROSTER, `skills/ contains [${skillDirs}] — expected [${EXPECTED_ROSTER}]`)
  for (const d of skillDirs) assert.ok(read(`skills/${d}/SKILL.md`).length > 500, `skills/${d}/SKILL.md is suspiciously small`)
})

const frontmatter = (text) => {
  const m = text.match(/^---\n([\s\S]*?)\n---/)
  assert.ok(m, 'SKILL.md must open with YAML frontmatter')
  return m[1]
}

check('W2 every SKILL.md has frontmatter (name == dir, description, allowed-tools) + the fixed anatomy', () => {
  for (const d of skillDirs) {
    const text = read(`skills/${d}/SKILL.md`)
    const fm = frontmatter(text)
    assert.match(fm, new RegExp(`^name: ${d}$`, 'm'), `skills/${d}: frontmatter name must equal the dir basename`)
    assert.match(fm, /^description: \S/m, `skills/${d}: frontmatter needs a description`)
    assert.match(fm, /^allowed-tools: \S/m, `skills/${d}: frontmatter needs allowed-tools (narrowest workable set)`)
    for (const s of REQUIRED_SECTIONS) assert.ok(text.includes(`\n${s}`), `skills/${d}: missing the "${s}" section`)
  }
})

const engineRefs = (text) => [...text.matchAll(/\$\{CLAUDE_PLUGIN_ROOT\}\/harness\/([a-z0-9-]+)\.mjs/g)].map((m) => m[1])
const engineGrants = (fm) => [...fm.matchAll(/Bash\(node \*harness\/([a-z0-9-]+)\.mjs \*\)/g)].map((m) => m[1])
const grantsEngine = (fm, engine) => /(^|\s)Bash(\s|$)/.test(fm.match(/^allowed-tools: (.*)$/m)?.[1] ?? '') || engineGrants(fm).includes(engine)

check('W3 every harness engine a skill invokes exists AND is granted in its allowed-tools', () => {
  for (const d of skillDirs) {
    const text = read(`skills/${d}/SKILL.md`)
    const fm = frontmatter(text)
    for (const engine of new Set(engineRefs(text))) {
      assert.ok(existsSync(join(ROOT, 'harness', `${engine}.mjs`)), `skills/${d} invokes harness/${engine}.mjs which does not exist`)
      assert.ok(grantsEngine(fm, engine), `skills/${d} invokes harness/${engine}.mjs but allowed-tools does not grant Bash(node *harness/${engine}.mjs *)`)
    }
  }
})

check('W4 every engine grant names a real harness engine (no dead grants)', () => {
  for (const d of skillDirs) {
    for (const engine of engineGrants(frontmatter(read(`skills/${d}/SKILL.md`)))) {
      assert.ok(existsSync(join(ROOT, 'harness', `${engine}.mjs`)), `skills/${d} grants harness/${engine}.mjs which does not exist — dead grant`)
    }
  }
})

check('W5 every payload path a skill references exists on disk', () => {
  // Not every skill installs something: the voice sweep edits prose the repo already has and
  // writes one config block, so it has no payload of its own. What must hold is that a
  // reference always resolves, and that the roster as a whole is still installing from
  // payload/ rather than hand-authoring artifacts into people's repos.
  let total = 0
  for (const d of skillDirs) {
    const text = read(`skills/${d}/SKILL.md`)
    const refs = new Set([...text.matchAll(/\$\{CLAUDE_PLUGIN_ROOT\}\/(payload\/[A-Za-z0-9_./-]*[A-Za-z0-9_-])/g)].map((m) => m[1]))
    total += refs.size
    for (const rel of refs) assert.ok(existsSync(join(ROOT, rel)), `skills/${d} references ${rel} which does not exist`)
  }
  assert.ok(total >= 5, `the skill roster references only ${total} payload asset(s) — refusing a vacuous pass; what gets installed lives in payload/`)
})

check('W6 plugin.json is coherent (skills dir, semver version, license matches the shipped LICENSE)', () => {
  const pj = JSON.parse(read('.claude-plugin/plugin.json'))
  assert.equal(pj.skills, './skills/', 'plugin.json skills must point at ./skills/')
  assert.match(pj.version, /^\d+\.\d+\.\d+$/, 'plugin.json version must be plain semver')
  // Derived from the manifest rather than hardcoded on both sides. Two independent literals
  // would fail a CONSISTENT relicense to MIT and pass a manifest that says MIT over an Apache
  // file, which is the one thing this assertion exists to catch, backwards.
  const LICENSE_TEXT = { 'Apache-2.0': /^\s*Apache License/m, MIT: /^MIT License/m, 'MIT-0': /^MIT No Attribution/m }
  assert.ok(LICENSE_TEXT[pj.license], `plugin.json declares license "${pj.license}", which this check has no text fingerprint for; add one rather than letting an unknown id pass unchecked`)
  assert.match(read('LICENSE'), LICENSE_TEXT[pj.license], `the shipped LICENSE file is not the ${pj.license} text plugin.json claims`)
  assert.ok(pj.description.length > 80, 'plugin.json description should say what the plugin does, concretely')
})

check('W7 this repo publishes no marketplace of its own (one namespace, one authority)', () => {
  // A marketplace name is a bare global key in the user's settings (`extraKnownMarketplaces`),
  // and `marketplace add` registers whatever catalog that name resolves to. If this repo also
  // published `runverdict-plugins`, adding it would REPLACE the catalog in
  // runverdict/plugins and every plugin installed from it would stop resolving. That is
  // not hypothetical — it is exactly what happened to sf-security-review-toolkit. The catalog
  // has one home; this repo ships a plugin.json and is listed FROM there.
  assert.ok(!existsSync(join(ROOT, '.claude-plugin', 'marketplace.json')),
    'this repo must not ship .claude-plugin/marketplace.json — the runverdict-plugins catalog lives in runverdict/plugins, and a second repo claiming that name silently breaks every plugin installed from the real one')
  // the README must point installers at the catalog, not at this repo (runverdict/plugins is
  // the canonical name — claude-plugins was the pre-rename name and only works via redirect)
  const rm = read('README.md')
  assert.ok(rm.includes('marketplace add runverdict/plugins'),
    'README Install must add the catalog repo (runverdict/plugins), not this repo — `marketplace add runverdict/repo-standard-toolkit` has no marketplace to find')
  assert.ok(rm.includes(`plugin install ${JSON.parse(read('.claude-plugin/plugin.json')).name}@runverdict-plugins`),
    'README Install must install this plugin from the runverdict-plugins namespace')
})

check('W8 every gh command a skill documents is covered by a Bash grant in allowed-tools', () => {
  let bound = 0
  for (const d of skillDirs) {
    const text = read(`skills/${d}/SKILL.md`)
    const fm = frontmatter(text)
    const grants = [...(fm.match(/^allowed-tools: (.*)$/m)?.[1] ?? '').matchAll(/Bash\(([^)]*)\)/g)].map((m) => m[1])
    // backticked `gh …` commands in the body are what the agent will actually run; the grant
    // patterns here are simple prefix globs (trailing *), which is all this repo uses.
    for (const [, cmd] of text.matchAll(/`(gh [^`]+)`/g)) {
      bound++
      const covered = grants.some((g) => cmd.startsWith(g.endsWith('*') ? g.slice(0, -1) : g))
      assert.ok(covered, `skills/${d} documents \`${cmd}\` but no Bash grant in allowed-tools covers it — the step fails at runtime, mid-scaffold, in someone else's repo`)
    }
  }
  assert.ok(bound >= 2, `expected the documented gh commands to be found (got ${bound}) — refusing a vacuous pass`)
})

// The other half of W3. W3 binds the PLUGIN's engines, which a skill runs out of
// ${CLAUDE_PLUGIN_ROOT}; this binds the engines the toolkit COMMITS INTO the target repo and then
// tells a skill to run: the installed lint, and the asset generator that sits beside the manifest.
// Scaffold instructed itself to re-render an upgraded generator and held no grant that could run
// one, so the step it exists to perform failed at exactly the moment it was needed, in someone
// else's repo, mid-journey.
// A command carrying an <angle> placeholder used to be SKIPPED here, on the reasoning that the
// literal beside it is what gets bound. That reasoning had a hole exactly the size of the
// feature the placeholder exists for: `node <assets.dir>/generate.mjs` was never checked, the
// grants covered `.github/assets/generate.mjs` and `*assets/generate.mjs`, and a repo whose
// `assets.dir` is `.brand` would have had the step fail at the moment it ran. A placeholder is a
// SHAPE, so it is expanded to the values an adopter can really give it and every expansion has
// to be covered.
const PLACEHOLDERS = {
  // The default, plus a custom directory that does not end in "assets": the whole point of the
  // key is that an operator names their own, and every grant written so far assumed the word.
  '<assets.dir>': ['.github/assets', '.brand', 'brand/art'],
}
check('W9 every committed-engine command a skill documents is covered by a Bash grant', () => {
  let bound = 0
  const expand = (cmd) => {
    let out = [cmd]
    for (const [token, values] of Object.entries(PLACEHOLDERS)) {
      if (!out.some((c) => c.includes(token))) continue
      out = out.flatMap((c) => (c.includes(token) ? values.map((v) => c.split(token).join(v)) : [c]))
    }
    return out
  }
  for (const d of skillDirs) {
    const text = read(`skills/${d}/SKILL.md`)
    const fm = frontmatter(text)
    const grants = [...(fm.match(/^allowed-tools: (.*)$/m)?.[1] ?? '').matchAll(/Bash\(([^)]*)\)/g)].map((m) => m[1])
    for (const [, cmd] of text.matchAll(/`(node [^`]+)`/g)) {
      // Engines run out of the plugin are W3's business.
      if (cmd.includes('${CLAUDE_PLUGIN_ROOT}')) continue
      // An <angle> token with no expansion here is still a shape rather than a command, and
      // inventing a literal for it would be this test guessing at a value nobody declared.
      const forms = expand(cmd)
      if (forms.length === 1 && cmd.includes('<')) continue
      for (const form of forms) {
        bound++
        // The grant patterns this repo writes are prefix globs with `*` in the middle or at the
        // end, which is what the permission matcher does with them.
        const re = (g) => new RegExp(`^${g.split('*').map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*')}${g.endsWith('*') ? '' : '$'}`)
        const covered = grants.some((g) => re(g).test(form))
        assert.ok(covered, `skills/${d} documents \`${cmd}\` (which expands to \`${form}\`) but no Bash grant in allowed-tools covers it — the step fails at runtime, in the adopter's repo, at the point the skill was invoked to reach`)
      }
    }
  }
  assert.ok(bound >= 6, `expected the documented committed-engine commands to be found (got ${bound}) — refusing a vacuous pass`)
})

// ── W10/W11: the frontmatter has to PARSE, not merely contain the right words ────────────────
// W2 above matches `^description: \S`, which is satisfied by a line that YAML cannot read. All
// four skills shipped a plain scalar whose text contained ": ", which YAML takes as a nested
// mapping and refuses. Claude Code's loader does not fail loudly on that: it drops every
// frontmatter field and loads the skill with EMPTY METADATA, so the description that decides
// whether the skill is ever invoked, and the allowed-tools that decide what it may touch, both
// silently become nothing. Sixteen green suites and a green CI said nothing, because no test
// parsed what it was asserting about. These two do.
//
// There is no YAML parser in Node and this repo takes no dependencies, so W10 is deliberately a
// VALIDITY check rather than a parser: it refuses the plain-scalar forms that cannot be read, and
// requires every other value to be a form that has no such hazard (a block scalar or a quoted
// one). W11 is the authoritative leg, run against the real validator when the machine has it.

const KEY_LINE = /^([A-Za-z0-9_-]+):(?: (.*))?$/
const BLOCK_HEADER = /^[|>][+-]?[0-9]?$/
// A plain scalar may not begin with any of these; YAML reads them as structure.
const INDICATORS = new Set(['-', '?', ':', ',', '[', ']', '{', '}', '#', '&', '*', '!', '|', '>', "'", '"', '%', '@', '`'])

const parseFrontmatter = (fm, where) => {
  const lines = fm.split('\n')
  const out = new Map()
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    if (line.trim() === '') continue
    const m = line.match(KEY_LINE)
    assert.ok(m, `${where}: line ${i + 1} of the frontmatter is neither a key nor an indented continuation: ${JSON.stringify(line)}`)
    const [, key, rawValue] = m
    assert.ok(!out.has(key), `${where}: duplicate frontmatter key "${key}" — YAML keeps the last and drops the first silently`)
    const value = rawValue ?? ''

    // gather the indented block that belongs to this key
    const body = []
    while (i + 1 < lines.length && (lines[i + 1] === '' || /^\s/.test(lines[i + 1]))) body.push(lines[++i])

    if (BLOCK_HEADER.test(value)) {
      const content = body.filter((l) => l.trim() !== '')
      assert.ok(content.length > 0, `${where}: "${key}" opens a block scalar and then has no content`)
      const indents = new Set(content.map((l) => l.match(/^ */)[0].length))
      assert.ok(Math.min(...indents) > 0, `${where}: "${key}" block scalar content must be indented`)
      if (value.startsWith('>')) {
        // A folded block folds same-indent lines into spaces and KEEPS a newline before any line
        // indented further. A stray extra space would put a line break in the middle of a
        // description without changing a single visible character of the file.
        assert.equal(indents.size, 1, `${where}: "${key}" is a folded (>) block whose lines are not uniformly indented — the deeper lines keep their newlines instead of folding`)
        assert.ok(!body.some((l) => l.trim() === ''), `${where}: "${key}" is a folded (>) block containing a blank line, which folds to a newline`)
      }
      out.set(key, { form: 'block', text: content.map((l) => l.trim()).join(value.startsWith('>') ? ' ' : '\n') })
      continue
    }

    assert.equal(body.filter((l) => l.trim() !== '').length, 0, `${where}: "${key}" has a value on its own line AND indented lines under it`)

    if (value.startsWith('"') || value.startsWith("'")) {
      const q = value[0]
      assert.ok(value.length > 1 && value.endsWith(q), `${where}: "${key}" opens with ${q} and does not close on the same line`)
      out.set(key, { form: 'quoted', text: value.slice(1, -1) })
      continue
    }

    // plain scalar: the form that broke, and the only form with real restrictions
    assert.ok(value !== '', `${where}: "${key}" has no value`)
    assert.ok(!INDICATORS.has(value[0]), `${where}: "${key}" is a plain scalar beginning with the YAML indicator ${JSON.stringify(value[0])}`)
    assert.ok(!value.includes(': '), `${where}: "${key}" is an UNQUOTED value containing ": ", which YAML reads as a nested mapping and refuses. The skill then loads with EMPTY metadata rather than failing. Write it as a folded block (${key}: >-) or quote it`)
    assert.ok(!value.endsWith(':'), `${where}: "${key}" is an unquoted value ending in ":", which YAML reads as a key`)
    assert.ok(!value.includes(' #'), `${where}: "${key}" is an unquoted value containing " #", which starts a YAML comment and truncates it`)
    out.set(key, { form: 'plain', text: value })
  }
  return out
}

check('W10 every SKILL.md frontmatter is valid YAML that keeps its fields (no silently-empty metadata)', () => {
  for (const d of skillDirs) {
    const where = `skills/${d}`
    const fm = parseFrontmatter(frontmatter(read(`${where}/SKILL.md`)), where)
    for (const key of ['name', 'description', 'allowed-tools']) {
      assert.ok(fm.has(key), `${where}: frontmatter is missing "${key}"`)
      assert.ok(fm.get(key).text.trim().length > 0, `${where}: frontmatter "${key}" parses to an empty value`)
    }
    assert.equal(fm.get('name').text, d, `${where}: frontmatter name must equal the dir basename`)
    assert.ok(fm.get('description').text.length > 80, `${where}: the description is what decides whether this skill is ever invoked; ${fm.get('description').text.length} characters is not a description`)
    assert.ok(!fm.get('description').text.includes('\n'), `${where}: the description folded to more than one line`)
  }
})

checkOrSkip('W11 the official validator accepts this plugin (claude plugin validate)', () => {
  // The authoritative leg. W10 is this repo's own reading of the rules; this is the loader's.
  // Absent on a CI runner that has no CLI, which is exactly why W10 exists and is not optional.
  let r
  try {
    r = spawnSync('claude', ['plugin', 'validate', ROOT], { encoding: 'utf8', timeout: 120000 })
  } catch { skipped('the claude CLI could not be run here') }
  if (r.error || r.status === null) skipped(`the claude CLI is not available here (${r.error?.code ?? 'no exit status'}); W10 is the leg that runs everywhere`)
  assert.equal(r.status, 0, `claude plugin validate exited ${r.status}:\n${[r.stdout, r.stderr].filter(Boolean).join('\n').trim()}`)
})

/*
 * ── THE OWNERSHIP CHAIN ────────────────────────────────────────────────────────────────────
 *
 * W3 and W4 bind a skill's prose to the ENGINES it runs. Nothing bound a skill's prose to the
 * SKILLS it says it hands work to, and the gap had a shape: atlas was instructed to hand a
 * migration's `identityEffects` to the identity pillar, held no tool that could invoke one, and
 * the instruction was satisfiable only as a sentence in a recap. A real run then performed the
 * rename, decided the identity work it had just caused was out of scope, kept the coverage
 * exclusion the rename had falsified, and invoked the atlas journey afterwards. Every claim
 * below is one link of the chain that failure crossed.
 *
 * These read PROSE, which is softer than reading a grant, so each one anchors on a phrase the
 * skill has to keep rather than on wording it may reword freely, and each says in its message
 * what breaks in an adopter's repo when it goes.
 */
const allowedTools = (fm) => fm.match(/^allowed-tools: (.*)$/m)?.[1] ?? ''
const grantsTool = (fm, tool) => new RegExp(`(^|\\s)${tool}(\\s|$)`).test(allowedTools(fm))
const SKILL_REF = /\/repo-standard-toolkit:([a-z0-9-]+)/g

check('W12 a skill that invokes another skill holds the Skill tool', () => {
  /*
   * The anchor is the phrase "(the Skill tool)", which is how every invocation site in this repo
   * names the mechanism. Anchoring on the skill NAME instead would miss scaffold, which invokes
   * whichever pillar the operator picked and so names none of them at the call site.
   */
  let bound = 0
  for (const d of skillDirs) {
    const text = read(`skills/${d}/SKILL.md`)
    if (!text.includes('(the Skill tool)')) continue
    bound++
    assert.ok(grantsTool(frontmatter(text), 'Skill'),
      `skills/${d} instructs an invocation with the Skill tool but allowed-tools grants no Skill. The handoff cannot happen, so work this skill causes and does not own is left to whoever reads the recap`)
  }
  assert.ok(bound >= 2, `only ${bound} skill(s) instruct an invocation, refusing a vacuous pass; the chain runs scaffold to a pillar and atlas to identity`)
})

check('W13 every /repo-standard-toolkit:<skill> reference names a skill that exists', () => {
  let total = 0
  for (const d of skillDirs) {
    for (const m of read(`skills/${d}/SKILL.md`).matchAll(SKILL_REF)) {
      total++
      assert.ok(skillDirs.includes(m[1]),
        `skills/${d} refers the operator to /repo-standard-toolkit:${m[1]}, which this plugin does not ship. A handoff to a skill that does not exist is a dead end the operator finds rather than the build`)
    }
  }
  assert.ok(total >= 10, `only ${total} cross-skill reference(s) found, refusing a vacuous pass`)
})

check('W14 atlas hands a nonempty identityEffects over and may not disposition it itself', () => {
  const atlas = read('skills/atlas/SKILL.md')
  assert.match(atlas, /[Ii]nvoke\s+`\/repo-standard-toolkit:identity`\s+\(the Skill tool\)/,
    'skills/atlas must instruct the invocation of the identity skill by name and by tool. Named in a recap alone, the effects of a migration this journey performed belong to nobody')
  assert.match(atlas, /explicit operator decision/,
    'skills/atlas must offer the second honest ending for a nonempty identityEffects: an explicit operator decision brought back. Without it, "hand over or decide" collapses into "mention it"')
  assert.match(atlas, /assets\.coverage/,
    'skills/atlas must name assets.coverage as the identity pillar\'s, because the exclusion a rename falsifies is the effect most easily left standing while the build stays green')
  const identity = read('skills/identity/SKILL.md')
  assert.match(identity, /identityEffects/,
    'skills/identity must name identityEffects as work it receives, or the handoff has a sender and no recipient')
  assert.match(identity, /decline the artwork/,
    'skills/identity must say the operator may decline the artwork and keep the exclusion. The defect was the missing consent, never that artwork must be forced')
})

check('W15 the post-write order is stated: atlas content, then identity, then voice, then the lint', () => {
  const atlas = read('skills/atlas/SKILL.md')
  const identityAt = atlas.search(/[Ii]nvoke\s+`\/repo-standard-toolkit:identity`\s+\(the Skill tool\)/)
  const voiceAt = atlas.search(/Converge the prose/)
  const lintAt = atlas.search(/Verify to green/)
  assert.ok(identityAt > 0 && voiceAt > 0 && lintAt > 0,
    `skills/atlas is missing one of the three ordered stages (identity ${identityAt}, voice ${voiceAt}, lint ${lintAt})`)
  assert.ok(identityAt < voiceAt,
    'skills/atlas puts its prose convergence before the identity handoff. Identity writes banners and generated H1s, so a scan taken first reports on a page that does not exist yet')
  assert.ok(voiceAt < lintAt,
    'skills/atlas runs the lint before the prose convergence, so the verdict it reports is about a tree the run then keeps writing to')
  assert.match(atlas, /Silence is not approval/,
    'skills/atlas must keep the consent boundary on the prose step: a bounded pass over prose the operator wrote is offered, never assumed')
  const voice = read('skills/voice/SKILL.md')
  assert.match(voice, /never write\s*\n?\s*`scaffold\.answers\.PROSE_OFFER`|never write `scaffold\.answers\.PROSE_OFFER`/,
    'skills/voice must forbid a bounded run from recording PROSE_OFFER. A caller declining a six-page cleanup is not the operator declining the pillar, and recording it as one silences an offer nobody made')
})

check('W16 scaffold treats an empty or unrecognisable generator preview as a STOP', () => {
  const scaffold = read('skills/scaffold/SKILL.md')
  assert.match(scaffold, /generate v<version> --check:/,
    'skills/scaffold must name the preamble a real preview carries, or "recognisable output" is a judgement with nothing behind it')
  assert.match(scaffold, /is a preview that did not happen, and it is a STOP/,
    'skills/scaffold must call empty or unrecognisable preview output a STOP. Exit 0 with no output is byte for byte what an up-to-date repo looks like from the outside')
  assert.match(scaffold, /Never read it as "nothing changes"/,
    'skills/scaffold must refuse the specific misreading that replaced an engine on the strength of a preview that never ran')
  assert.match(scaffold, /empty CHANGE LIST inside\s*\n?\s*a well-formed plan|empty change list inside a\s*\n?\s*well-formed plan/,
    'skills/scaffold must keep the distinction it turns on: an empty change list inside a well-formed plan is a repo that is up to date, and zero bytes is a plan nobody has')
})

check('W17 the fan-out is priced in chunks, and no skill instructs a recap to count agents', () => {
  const atlas = read('skills/atlas/SKILL.md')
  assert.match(atlas, /a chunk is a unit of READING rather than a count of\s*\n?\s*agents/,
    'skills/atlas must define the unit it prices in. The planner emits `chunks` and prints that same integer under the noun "agent(s)", which is a label on a price')
  assert.match(atlas, /state no number of agents at all/,
    'skills/atlas must instruct the recap to omit the agent count outright. A run priced 38 chunks, launched 34 calls, and reported "38 agents"')
  assert.match(atlas, /nothing measures whether it held/,
    'skills/atlas must say that one-agent-per-chunk is an intent nothing verifies, or "omit it" reads as caution rather than as the only honest option')
  assert.ok(!/roughly `<K>` agents/.test(atlas),
    'skills/atlas still prices the offer in agents. That template is where the number entered the conversation, and every later misuse inherited from it')
})

console.log(`\n${pass} passed, ${fail} failed, ${skip} skipped`)
process.exit(fail ? 1 : 0)
