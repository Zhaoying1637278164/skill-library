#!/usr/bin/env node
/*
 * test-sense-state.mjs — standing acceptance test for harness/sense-state.mjs, the read-only
 * inventory engine whose classification and per-artifact plan the scaffold skill trusts blindly.
 *
 * WHY: a wrong sense silently scaffolds over a governed repo or skips a greenfield one — the
 * one mistake the plugin promises never to make.
 *
 * Guards:
 *   SS1 empty dir → 'greenfield'; every doc scaffold, lint/config/CI all install
 *   SS2 README.md alone → 'partial'; README audit, CHANGELOG scaffold
 *   SS3 governed fixture (all docs + payload-identical lint + config + CI gate) → 'governed',
 *       lint keep, matchesPayload true (SKIPPED with a note if the payload lint does not exist)
 *   SS4 drifted installed lint at the SAME version → local-edit, matchesPayload false,
 *       classification still 'governed' (drift is not a de-governing; SKIPPED alongside SS3)
 *   SS5 --json parses; two runs are byte-identical; the engine writes nothing into the fixture
 *   SS6 derivation from package.json with no git — projectName/tagline/licenseId derived,
 *       git.isRepo false, hasH1:false reported for a doc without an H1
 *   SS7 bad invocation (file as target, missing dir, unknown flag) → exit 2 with a message
 *   SS8 derivation fallbacks + precise gate detection: licenseId from a recognizable LICENSE
 *       file, tagline from the README's first paragraph, an unrecognizable LICENSE derives
 *       "unrecognized" (never a guess), one unrelated test in a workflow ≠ the gate.
 *   SS9 derivation precision hardenings (each a confirmed review finding): BSD-2 vs BSD-3,
 *       MIT-0 vs MIT, inline-bold taglines, badge skipping, broken-manifest shadowing,
 *       fence-hidden H1s, an H1 whose text repeats earlier in prose, invalid config → repair,
 *       commented-out gates, a real gate in both the inline and block-scalar step shapes,
 *       default-branch detection, bare MIT grants, ancestor-repo signal leaks.
 *   SS10 lint drift is DIRECTED by the embedded version constant: older installed → upgrade,
 *        newer installed → downgrade (with a loud stale-plugin warning), constant-less
 *        installed copy → upgrade (predates versioning), and both versions are reported. It
 *        runs inside the SS3/SS4 branch, so a tree with no payload lint skips all of it, and
 *        the skip line names SS10 as well as SS3 and SS4.
 *   SS11 doc sensing is location-aware (.github/ > root > docs/, GitHub's precedence): a doc
 *        living only in .github/ is sensed and audited (never re-scaffolded at root), and a
 *        cross-location duplicate is reported with the served path named.
 *   SS12 sensing honesty hardenings from the adversarial review: the license filename family
 *        (LICENSE.md / COPYING / …) counts as licensed — matching the lint's RS-license — a
 *        DIRECTORY named like a doc cannot mask the real file, and the tagline fallback reads
 *        the SENSED README, not a hardcoded root path.
 *   SS14 the optional pillars are SENSED, so a re-run asks instead of assuming: an un-adopted
 *        identity, writing profile or index set is an `offer` rather than a gap, and a recorded
 *        decline is terminal; a DECLARED identity and profile report their real scope; both
 *        index spellings are read and a partly indexed repo is still OFFERED the atlas, because
 *        adoption there is not binary, while a per-directory decline retires one directory
 *        without retiring the pillar and an index sitting where a reader never lands is an offer
 *        rather than a finished state; the ignore posture names the exact missing rule and any
 *        negation that re-exposes a secret; and a differing generator is DIRECTED by its own
 *        version constant, so a stale plugin can never downgrade the artwork while calling it
 *        maintenance.
 *   SS13 a recorded scaffold provenance block is reported (version + answers, named in the
 *        human output); a config without one reports null, never a fabricated default.
 *
 * Dependency-free: node acceptance/test-sense-state.mjs
 *        SS13 also covers the atlas STRICT routing: a recorded ATLAS_STRICT_OFFER decline reads
 *        as keep, a repo already running strict is not offered its own mode, and a universe this
 *        engine could not fully see makes strict unavailable.
 *   SS20 a configured path that leaves the repo is REFUSED before it is read, hashed or
 *        routed: this engine is read-only and it ROUTES, and an assets.dir pointing at a
 *        sibling checkout had it report that generator installed and hand the scaffold skill
 *        a directed action for it, on a config both other engines exit 2 on.
 *   SS21 a universe error is TERMINAL in both ownership modes. It was computed, printed, and
 *        routed nowhere, so the cheapest engine (and the one that decides whether the pillar
 *        runs at all) answered keep on a tree the other two called broken.
 */
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync, appendFileSync, copyFileSync, readdirSync, readFileSync, existsSync, symlinkSync, renameSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const ENGINE = join(ROOT, 'harness', 'sense-state.mjs')
const PAYLOAD_LINT = join(ROOT, 'payload', 'acceptance', 'test-repo-standard.mjs')
const DOCS = ['README.md', 'CHANGELOG.md', 'CONVENTIONS.md', 'CONTRIBUTING.md', 'CODE_OF_CONDUCT.md', 'SECURITY.md']

let pass = 0, fail = 0
const check = (name, fn) => {
  try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) }
}

const senseRaw = (dir) => execFileSync('node', [ENGINE, '--target', dir, '--json'], { encoding: 'utf8' })
const sense = (dir) => JSON.parse(senseRaw(dir))
const planAction = (report, artifact) => report.plan.find((p) => p.artifact === artifact)?.action
const listFiles = (dir) => {
  const out = []
  const walk = (d, rel) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const r = rel ? `${rel}/${e.name}` : e.name
      if (e.isDirectory()) walk(join(d, e.name), r)
      else out.push(r)
    }
  }
  walk(dir, '')
  return out.sort()
}
const expectExit2 = (argv, needle) => {
  let err = null
  try { execFileSync('node', [ENGINE, ...argv], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }) } catch (e) { err = e }
  assert.ok(err, `expected exit 2 for [${argv.join(' ')}], but the engine exited 0`)
  assert.equal(err.status, 2, `expected exit 2 for [${argv.join(' ')}], got ${err.status}`)
  const out = `${err.stderr || ''}${err.stdout || ''}`
  assert.ok(out.includes(needle), `expected "${needle}" in engine output, got: ${out.trim()}`)
}
// Governed fixture: all six docs (with H1s) + LICENSE, the installed lint byte-copied from the
// payload, an empty-but-valid config, and a workflow that runs the acceptance suite.
const buildGoverned = (dir) => {
  mkdirSync(join(dir, 'acceptance'), { recursive: true })
  mkdirSync(join(dir, '.github', 'workflows'), { recursive: true })
  for (const doc of DOCS) writeFileSync(join(dir, doc), `# ${doc.replace(/\.md$/, '')}\n\nBody text.\n`)
  writeFileSync(join(dir, 'LICENSE'), 'MIT License\n\nCopyright (c) 2026 Example\n')
  copyFileSync(PAYLOAD_LINT, join(dir, 'acceptance', 'test-repo-standard.mjs'))
  writeFileSync(join(dir, '.repo-standard.json'), '{}')
  writeFileSync(join(dir, '.github', 'workflows', 'x.yml'), 'name: gate\njobs:\n  test:\n    steps:\n      - run: for t in acceptance/test-*.mjs; do node "$t" || exit 1; done\n')
}

console.log('test-sense-state — harness/sense-state.mjs')
const tmp = mkdtempSync(join(tmpdir(), 'sense-state-test-'))
try {
  // ---- SS1: empty dir → greenfield, everything scaffold/install ----
  const empty = join(tmp, 'empty')
  mkdirSync(empty)
  check('SS1: empty dir classifies greenfield', () => {
    assert.equal(sense(empty).classification, 'greenfield')
  })
  check('SS1: plan scaffolds every doc and installs lint, config, CI', () => {
    const r = sense(empty)
    for (const doc of [...DOCS, 'LICENSE']) assert.equal(planAction(r, doc), 'scaffold', `${doc} should be scaffold`)
    assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'install')
    assert.equal(planAction(r, '.repo-standard.json'), 'install')
    assert.equal(planAction(r, '.github/workflows (acceptance gate)'), 'install')
  })

  // ---- SS2: README.md alone → partial; audit what exists, scaffold the gaps ----
  const readmeOnly = join(tmp, 'readme-only')
  mkdirSync(readmeOnly)
  writeFileSync(join(readmeOnly, 'README.md'), '# My Project\n\nA thing.\n')
  check('SS2: README.md alone classifies partial', () => {
    assert.equal(sense(readmeOnly).classification, 'partial')
  })
  check('SS2: existing README is audit, missing CHANGELOG is scaffold', () => {
    const r = sense(readmeOnly)
    assert.equal(planAction(r, 'README.md'), 'audit')
    assert.equal(planAction(r, 'CHANGELOG.md'), 'scaffold')
  })

  // ---- SS3/SS4: governed and drifted-lint fixtures (need the payload lint to compare against) ----
  if (!existsSync(PAYLOAD_LINT)) {
    console.log('  - SS3/SS4 SKIPPED: payload/acceptance/test-repo-standard.mjs does not exist yet; nothing to byte-compare against')
  } else {
    const governed = join(tmp, 'governed')
    mkdirSync(governed)
    buildGoverned(governed)
    check('SS3: fully governed fixture classifies governed', () => {
      assert.equal(sense(governed).classification, 'governed')
    })
    check('SS3: byte-identical installed lint is keep, matchesPayload true', () => {
      const r = sense(governed)
      assert.equal(r.enforcement.lint.matchesPayload, true)
      assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'keep')
    })
    appendFileSync(join(governed, 'acceptance', 'test-repo-standard.mjs'), '\n')
    check('SS4: drifted installed lint at the SAME version is local-edit, matchesPayload false', () => {
      const r = sense(governed)
      assert.equal(r.enforcement.lint.matchesPayload, false)
      // same version constant, different bytes: neither copy can claim to be newer — calling
      // this "upgrade" is exactly the mislabel the version constant exists to kill.
      assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'local-edit')
    })
    check('SS4: lint drift does not de-govern the classification', () => {
      assert.equal(sense(governed).classification, 'governed')
    })

    // ---- SS10: drift direction comes from the version constant, never from assumption ----
    const payloadSrc = readFileSync(PAYLOAD_LINT, 'utf8')
    const payloadVersion = payloadSrc.match(/^const REPO_STANDARD_LINT_VERSION = '([^'\n]+)'/m)?.[1]
    const withLintVersion = (v) => payloadSrc.replace(/^const REPO_STANDARD_LINT_VERSION = '[^'\n]+'/m, `const REPO_STANDARD_LINT_VERSION = '${v}'`)
    const driftFixture = (name, lintSrc) => {
      const d = join(tmp, name)
      buildGoverned(d)
      writeFileSync(join(d, 'acceptance', 'test-repo-standard.mjs'), lintSrc)
      return d
    }
    check('SS10: the payload lint carries a parseable version constant (everything below keys off it)', () => {
      assert.ok(payloadVersion, 'REPO_STANDARD_LINT_VERSION must be parseable from the payload lint')
    })
    check('SS10: an installed lint OLDER than the payload is a directed upgrade, versions reported', () => {
      const r = sense(driftFixture('drift-older', withLintVersion('0.0.1')))
      assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'upgrade')
      assert.equal(r.enforcement.lint.installedVersion, '0.0.1')
      assert.equal(r.enforcement.lint.payloadVersion, payloadVersion)
    })
    check('SS10: an installed lint NEWER than the payload is a downgrade, never an "upgrade"', () => {
      const r = sense(driftFixture('drift-newer', withLintVersion('99.0.0')))
      assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'downgrade')
    })
    check('SS10: the downgrade verdict prints a loud STALE PLUGIN warning in the human output', () => {
      const out = execFileSync('node', [ENGINE, '--target', join(tmp, 'drift-newer')], { encoding: 'utf8' })
      assert.ok(out.includes('STALE PLUGIN'), `the human output must warn, got:\n${out}`)
      assert.ok(out.includes('downgrade'), 'the lint line names the direction')
    })
    check('SS10: an installed copy from before versioning (no constant) is an upgrade', () => {
      const r = sense(driftFixture('drift-preversion', payloadSrc.replace(/^const REPO_STANDARD_LINT_VERSION = '[^'\n]+'\n/m, '')))
      assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'upgrade')
      assert.equal(r.enforcement.lint.installedVersion, null)
    })
  }

  // ---- SS5: --json is valid JSON, deterministic, and the engine is read-only ----
  check('SS5: --json output parses as JSON', () => {
    const r = JSON.parse(senseRaw(readmeOnly))
    assert.equal(typeof r.classification, 'string')
    assert.ok(Array.isArray(r.plan))
  })
  check('SS5: two runs on the same tree are byte-identical', () => {
    assert.equal(senseRaw(readmeOnly), senseRaw(readmeOnly))
  })
  check('SS5: a run creates no files in the fixture (read-only engine)', () => {
    // A fresh fixture the engine has never seen, so the pre-run snapshot cannot be contaminated.
    const untouched = join(tmp, 'untouched')
    mkdirSync(untouched)
    writeFileSync(join(untouched, 'README.md'), '# Untouched\n')
    const before = listFiles(untouched)
    senseRaw(untouched)
    execFileSync('node', [ENGINE, '--target', untouched], { encoding: 'utf8' }) // human format too
    assert.deepEqual(listFiles(untouched), before)
  })

  // ---- SS6: derivation from package.json, no git, hasH1 reporting ----
  const derive = join(tmp, 'derive')
  mkdirSync(derive)
  writeFileSync(join(derive, 'package.json'), JSON.stringify({ name: 'acme-widgets', description: 'Widgets for Acme', license: 'MIT' }))
  writeFileSync(join(derive, 'README.md'), 'no heading here, just prose\n')
  check('SS6: package.json signals derive name, tagline, license without git', () => {
    const r = sense(derive)
    assert.equal(r.derived.projectName, 'acme-widgets')
    assert.equal(r.derived.tagline, 'Widgets for Acme')
    assert.equal(r.derived.licenseId, 'MIT')
    assert.equal(r.signals.git.isRepo, false)
  })
  check('SS6: a doc without an H1 reports hasH1 false', () => {
    const r = sense(derive)
    assert.equal(r.artifacts['README.md'].exists, true)
    assert.equal(r.artifacts['README.md'].hasH1, false)
  })

  // ---- SS11: location-aware doc sensing (.github/ > root > docs/) ----
  check('SS11: a doc living only in .github/ is sensed at its real path and audited, never re-scaffolded', () => {
    const d = join(tmp, 'gh-only')
    mkdirSync(join(d, '.github'), { recursive: true })
    writeFileSync(join(d, '.github', 'CONTRIBUTING.md'), '# Contributing\n\nBody.\n')
    const r = sense(d)
    assert.equal(r.artifacts['CONTRIBUTING.md'].exists, true)
    assert.equal(r.artifacts['CONTRIBUTING.md'].path, '.github/CONTRIBUTING.md')
    assert.equal(planAction(r, 'CONTRIBUTING.md'), 'audit')
  })
  check('SS11: a cross-location duplicate reports the GitHub-served path first and warns in human output', () => {
    const d = join(tmp, 'dup-doc')
    mkdirSync(join(d, '.github'), { recursive: true })
    writeFileSync(join(d, 'CONTRIBUTING.md'), '# Contributing\n\nRoot copy.\n')
    writeFileSync(join(d, '.github', 'CONTRIBUTING.md'), '# Contributing\n\nShadowing copy.\n')
    const r = sense(d)
    assert.equal(r.artifacts['CONTRIBUTING.md'].path, '.github/CONTRIBUTING.md', 'the .github/ copy is what GitHub serves')
    assert.deepEqual(r.artifacts['CONTRIBUTING.md'].duplicates, ['CONTRIBUTING.md'])
    const human = execFileSync('node', [ENGINE, '--target', d], { encoding: 'utf8' })
    assert.ok(human.includes('DUPLICATE'), `the human output must warn about the shadowed duplicate, got:\n${human}`)
  })

  // ---- SS12: sensing honesty hardenings (each was a confirmed adversarial-review finding) ----
  check('SS12: the license filename family counts as licensed (LICENSE.md, COPYING — matching RS-license)', () => {
    const md = join(tmp, 'lic-md')
    mkdirSync(md)
    writeFileSync(join(md, 'LICENSE.md'), 'MIT License\n\nCopyright (c) 2026 Acme\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software.\n\nThe above copyright notice and this permission notice shall be included in all copies.\n')
    const r = sense(md)
    assert.equal(r.artifacts.LICENSE.exists, true, 'LICENSE.md is a license file, not license-less')
    assert.equal(r.artifacts.LICENSE.path, 'LICENSE.md')
    assert.equal(r.derived.licenseId, 'MIT')
    assert.equal(planAction(r, 'LICENSE'), 'audit', 'never scaffold a second license file beside an existing one')
  })
  check('SS12: a DIRECTORY named .github/README.md cannot mask the real root README', () => {
    const d = join(tmp, 'dir-mask')
    mkdirSync(join(d, '.github', 'README.md'), { recursive: true })
    writeFileSync(join(d, 'README.md'), '# real\n\nThe real README.\n')
    const r = sense(d)
    assert.equal(r.artifacts['README.md'].exists, true)
    assert.equal(r.artifacts['README.md'].path, 'README.md', 'the directory is not a candidate; the file is')
  })
  check('SS12: the tagline fallback reads the SENSED README (.github/ or docs/), not only root', () => {
    const d = join(tmp, 'tagline-gh')
    mkdirSync(join(d, '.github'), { recursive: true })
    writeFileSync(join(d, '.github', 'README.md'), '# proj\n\nA tagline that lives in .github.\n')
    assert.equal(sense(d).derived.tagline, 'A tagline that lives in .github.')
  })

  // ---- SS13: recorded scaffold provenance is reported, never invented ----
  check('SS13: a recorded scaffold block is reported (version + answers) and named in human output', () => {
    const d = join(tmp, 'scaffold-block')
    buildGoverned(d)
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({ version: 1, scaffold: { pluginVersion: '0.1.0', answers: { LICENSE_ID: 'MIT' } } }))
    const r = sense(d)
    assert.equal(r.enforcement.config.scaffold.pluginVersion, '0.1.0')
    assert.deepEqual(r.enforcement.config.scaffold.answers, { LICENSE_ID: 'MIT' })
    const human = execFileSync('node', [ENGINE, '--target', d], { encoding: 'utf8' })
    assert.ok(human.includes('scaffolded by plugin 0.1.0'), `human output names the recorded version, got:\n${human}`)
    writeFileSync(join(d, '.repo-standard.json'), '{}')
    assert.equal(sense(d).enforcement.config.scaffold, null, 'no block → null, never a fabricated default')
  })

  // ---- SS7: bad invocation exits 2 with a message ----
  const aFile = join(tmp, 'a-file.txt')
  writeFileSync(aFile, 'not a directory\n')
  check('SS7: --target pointing at a file exits 2', () => {
    expectExit2(['--target', aFile], 'target is not a directory')
  })
  check('SS7: --target pointing at a missing dir exits 2', () => {
    expectExit2(['--target', join(tmp, 'no-such-dir')], 'target is not a directory')
  })
  check('SS7: unknown flag exits 2', () => {
    expectExit2(['--bogus'], 'unknown argument')
  })

  // ---- SS8: derivation fallbacks + precise gate detection (the adversarial-pass hardenings) ----
  const fallbacks = join(tmp, 'fallbacks')
  mkdirSync(join(fallbacks, '.github', 'workflows'), { recursive: true })
  writeFileSync(join(fallbacks, 'LICENSE'), 'MIT License\n\nCopyright (c) 2019 Legacy Co\n\nPermission is hereby granted, free of charge...\n')
  writeFileSync(join(fallbacks, 'README.md'), '# legacy-tool\n\nLegacy tooling for the Fooberg pipeline.\n\n## Notes\n\nx\n')
  // a workflow that runs ONE unrelated acceptance test is NOT the gate
  writeFileSync(join(fallbacks, '.github', 'workflows', 'ci.yml'), 'name: ci\njobs:\n  t:\n    steps:\n      - run: node acceptance/test-always-green.mjs\n')
  check('SS8: licenseId derives from a recognizable LICENSE file when no manifest declares one', () => {
    assert.equal(sense(fallbacks).derived.licenseId, 'MIT')
  })
  check('SS8: tagline falls back to the first paragraph after the existing README H1', () => {
    assert.equal(sense(fallbacks).derived.tagline, 'Legacy tooling for the Fooberg pipeline.')
  })
  check('SS8: a workflow running one unrelated test is NOT the acceptance gate (plan installs one)', () => {
    const r = sense(fallbacks)
    assert.equal(r.enforcement.ci.runsAcceptance, false)
    assert.equal(planAction(r, '.github/workflows (acceptance gate)'), 'install')
  })
  check('SS8: an unrecognizable LICENSE file derives "unrecognized", never a guessed id', () => {
    const odd = join(tmp, 'odd-license')
    mkdirSync(odd)
    writeFileSync(join(odd, 'LICENSE'), 'You may use this for good, not evil.\n')
    assert.equal(sense(odd).derived.licenseId, 'unrecognized')
  })

  // ---- SS9: derivation precision (each was a confirmed code-review finding) ----
  const lic = (name, text) => {
    const d = join(tmp, `lic-${name}`)
    mkdirSync(d, { recursive: true })
    writeFileSync(join(d, 'LICENSE'), text)
    return sense(d).derived.licenseId
  }
  check('SS9: BSD-2-Clause is not mislabeled BSD-3-Clause (the shared preamble is not distinctive)', () => {
    const preamble = 'Redistribution and use in source and binary forms, with or without\nmodification, are permitted provided that the following conditions are met:\n'
    assert.equal(lic('bsd2', `BSD 2-Clause License\n\nCopyright (c) 2026 Acme\n\n${preamble}`), 'BSD-2-Clause')
    assert.equal(lic('bsd3', `BSD 3-Clause License\n\nCopyright (c) 2026 Acme\n\n${preamble}\n3. Neither the name of the copyright holder nor the names of its contributors\n`), 'BSD-3-Clause')
    // an unlabeled BSD variant must say "unrecognized" rather than guess a clause count
    assert.equal(lic('bsdbare', `Copyright (c) 2026 Acme\n\n${preamble}`), 'unrecognized')
  })
  check('SS9: a tagline with mid-line bold survives whole (not truncated at the first **)', () => {
    const d = join(tmp, 'tag-inline')
    mkdirSync(d)
    writeFileSync(join(d, 'README.md'), '# acme\n\nA **fast** JSON parser for embedded targets.\n')
    assert.equal(sense(d).derived.tagline, 'A fast JSON parser for embedded targets.')
  })
  check('SS9: an H1 whose text also appears earlier in prose does not mis-anchor the tagline', () => {
    const d = join(tmp, 'tag-inline-h1')
    mkdirSync(d)
    writeFileSync(join(d, 'README.md'), 'Preamble mentioning `# acme` inline.\n\n# acme\n\nThe real tagline.\n')
    assert.equal(sense(d).derived.tagline, 'The real tagline.')
  })
  check('SS9: badges between the H1 and the tagline are skipped, not mistaken for it', () => {
    const d = join(tmp, 'tag-badge')
    mkdirSync(d)
    writeFileSync(join(d, 'README.md'), '# acme\n\n[![ci](https://img.shields.io/badge/ci-ok-green)](https://e.com)\n\nThe real tagline.\n')
    assert.equal(sense(d).derived.tagline, 'The real tagline.')
  })
  check('SS9: a broken package.json does not shadow a valid pyproject.toml beside it', () => {
    const d = join(tmp, 'mf-broken')
    mkdirSync(d)
    writeFileSync(join(d, 'package.json'), '{ "name": "x", // nope\n}')
    writeFileSync(join(d, 'pyproject.toml'), 'name = "acme-parser"\nversion = "1.0.0"\n')
    assert.equal(sense(d).derived.projectName, 'acme-parser')
  })
  check('SS9: hasH1 is false for a doc whose only "# " is a shell comment inside a fence', () => {
    const d = join(tmp, 'h1-fence')
    mkdirSync(d)
    writeFileSync(join(d, 'README.md'), 'acme\n====\n\nInstall:\n\n```bash\n# install it\nnpm i acme\n```\n')
    assert.equal(sense(d).artifacts['README.md'].hasH1, false)
  })
  check('SS9: an invalid .repo-standard.json is not "governed" — the plan says repair', () => {
    const d = join(tmp, 'bad-config')
    buildGoverned(d)
    writeFileSync(join(d, '.repo-standard.json'), '{ "projectName": "acme",, }')
    const r = sense(d)
    assert.equal(r.enforcement.config.valid, false)
    assert.notEqual(r.classification, 'governed')
    assert.equal(planAction(r, '.repo-standard.json'), 'repair')
  })
  check('SS9: a commented-out or echoed gate line does not count as the CI gate', () => {
    const d = join(tmp, 'gate-comment')
    mkdirSync(join(d, '.github', 'workflows'), { recursive: true })
    writeFileSync(join(d, '.github', 'workflows', 'ci.yml'), 'name: ci\njobs:\n  t:\n    steps:\n      # - run: node acceptance/test-repo-standard.mjs\n      - run: echo "we should run node acceptance/test-repo-standard.mjs someday"\n')
    assert.equal(sense(d).enforcement.ci.runsAcceptance, false)
  })
  check('SS9: a real gate IS still detected in both the inline and block-scalar step shapes', () => {
    const inline = join(tmp, 'gate-inline')
    mkdirSync(join(inline, '.github', 'workflows'), { recursive: true })
    writeFileSync(join(inline, '.github', 'workflows', 'ci.yml'), 'name: ci\njobs:\n  t:\n    steps:\n      - run: node acceptance/test-repo-standard.mjs\n')
    assert.equal(sense(inline).enforcement.ci.runsAcceptance, true, 'inline `- run: node …` is a gate')
    const block = join(tmp, 'gate-block')
    mkdirSync(join(block, '.github', 'workflows'), { recursive: true })
    writeFileSync(join(block, '.github', 'workflows', 'ci.yml'), 'name: ci\njobs:\n  t:\n    steps:\n      - run: |\n          for t in acceptance/test-*.mjs; do node "$t" || exit 1; done\n')
    assert.equal(sense(block).enforcement.ci.runsAcceptance, true, 'a block-scalar run body is a gate')
  })
  check('SS9: defaultBranch is the DEFAULT branch, not the topic branch that happens to be checked out', () => {
    const d = join(tmp, 'branch-topic')
    mkdirSync(d)
    execFileSync('git', ['init', '-b', 'main'], { cwd: d, stdio: 'ignore' })
    execFileSync('git', ['-c', 'user.email=a@b.c', '-c', 'user.name=a', 'commit', '-q', '--allow-empty', '-m', 'i'], { cwd: d, stdio: 'ignore' })
    assert.equal(sense(d).derived.defaultBranch, 'main', 'on the default branch itself')
    execFileSync('git', ['checkout', '-q', '-b', 'feature/spike'], { cwd: d, stdio: 'ignore' })
    // scaffolding almost always happens on a topic branch — this is the common path, and the
    // wrong answer here gets baked into the docs as {{DEFAULT_BRANCH}}.
    assert.equal(sense(d).derived.defaultBranch, 'main', 'a topic branch must not be reported as the default')
    // a master-based repo must not be told it is "main"
    const m = join(tmp, 'branch-master')
    mkdirSync(m)
    execFileSync('git', ['init', '-b', 'master'], { cwd: m, stdio: 'ignore' })
    execFileSync('git', ['-c', 'user.email=a@b.c', '-c', 'user.name=a', 'commit', '-q', '--allow-empty', '-m', 'i'], { cwd: m, stdio: 'ignore' })
    execFileSync('git', ['checkout', '-q', '-b', 'topic'], { cwd: m, stdio: 'ignore' })
    assert.equal(sense(m).derived.defaultBranch, 'master', 'a master repo keeps master')
  })
  check('SS9: a bare MIT grant with no title line still derives MIT (the fallback branch is load-bearing)', () => {
    const d = join(tmp, 'lic-mit-bare')
    mkdirSync(d)
    // the very common MIT LICENSE that omits the "MIT License" title and opens on the copyright —
    // the notice-preservation condition is what makes the untitled text MIT rather than MIT-0.
    writeFileSync(join(d, 'LICENSE'), 'Copyright (c) 2020 Someone\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software...\n\nThe above copyright notice and this permission notice shall be included in\nall copies or substantial portions of the Software.\n')
    assert.equal(sense(d).derived.licenseId, 'MIT')
  })
  check('SS9: MIT-0 is not mislabeled MIT, and a bare grant without the notice condition is unrecognized', () => {
    assert.equal(lic('mit0', 'MIT No Attribution\n\nCopyright (c) 2026 Acme\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software.\n'), 'MIT-0')
    assert.equal(lic('grant-only', 'Copyright (c) 2026 Acme\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software.\n'), 'unrecognized')
  })
  // ---- SS14: the optional pillars are SENSED, so a re-run can ask instead of assuming ----
  check('SS14: an un-adopted repo reports every optional pillar as an OFFER, never as a gap', () => {
    const d = join(tmp, 'ss14-bare')
    mkdirSync(d)
    buildGoverned(d)
    const r = sense(d)
    assert.equal(r.enforcement.assets.declared, false, 'no assets declared')
    assert.equal(r.enforcement.assets.generator.installed, false, 'no generator installed')
    assert.equal(r.enforcement.prose.declared, false, 'no writing profile declared')
    assert.equal(r.enforcement.prose.profile, null, 'and none is invented')
    assert.equal(r.enforcement.indexes.declared, 0, 'no directory says what each file in it is for')
    assert.equal(r.enforcement.indexes.spelling, null, 'and no spelling is assumed on a repo that declared neither')
    assert.equal(planAction(r, '.github/assets/generate.mjs'), 'offer',
      'an un-adopted identity is an OFFER: a scaffold run must never decide someone wants generated artwork')
    assert.equal(planAction(r, 'prose profile (.repo-standard.json)'), 'offer',
      'an un-adopted writing profile is an OFFER, not a missing file')
  })
  check('SS14: a recorded decline turns the offer into `declined`, so a re-run cannot re-ask', () => {
    const d = join(tmp, 'ss14-declined')
    mkdirSync(d)
    buildGoverned(d)
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1,
      scaffold: { pluginVersion: '0.3.0', answers: { PROSE_OFFER: 'declined', IDENTITY_OFFER: 'declined' } },
    }))
    const r = sense(d)
    assert.equal(planAction(r, 'prose profile (.repo-standard.json)'), 'declined',
      'an operator who said no once has answered the question; a plan that kept saying `offer` would have the agent re-asking every session')
    assert.equal(planAction(r, '.github/assets/generate.mjs'), 'declined', 'the same for the identity offer')
    // The decline is durable but not permanent: adopting later still reports as adopted.
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1, prose: { profile: 'enterprise' },
      scaffold: { pluginVersion: '0.3.0', answers: { PROSE_OFFER: 'declined' } },
    }))
    assert.equal(planAction(sense(d), 'prose profile (.repo-standard.json)'), 'keep',
      'a later adoption wins over an older decline')
  })
  check('SS14: both index spellings are sensed, and the pages they point at are reported', () => {
    // Inventory only: which spelling, and which pages. What each index is MISSING is
    // harness/index-plan.mjs, which is a different question and a more expensive one. What this
    // has to get right is that a repo using either spelling reads as adopted, so the atlas is
    // offered once rather than every session.
    const d = join(tmp, 'ss14-indexes')
    mkdirSync(d)
    buildGoverned(d)
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1, docs: { index: { file: 'docs/README.md', statuses: ['active'] } },
    }))
    let r = sense(d)
    assert.equal(r.enforcement.indexes.spelling, 'docs.index', 'the single-index spelling is reported as itself')
    assert.deepEqual(r.enforcement.indexes.files, ['docs/README.md'], 'and it names the page')
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1, docs: { indexes: [{ file: 'docs/README.md' }, { file: 'lib/INDEX.md', extensions: ['.mjs'] }] },
    }))
    r = sense(d)
    assert.equal(r.enforcement.indexes.spelling, 'docs.indexes', 'the list spelling is reported as itself, because the two are not interchangeable in the config')
    assert.equal(r.enforcement.indexes.declared, 2, 'both are counted')
    assert.deepEqual(r.enforcement.indexes.files, ['docs/README.md', 'lib/INDEX.md'], 'an index that is not a README is still an index')
    // `false` is how a repo says it deliberately keeps none, and it must not read as adopted.
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({ version: 1, docs: { index: false } }))
    assert.equal(sense(d).enforcement.indexes.spelling, null, 'an explicit "docs.index": false is a repo declining, not a repo adopting')
  })
  check('SS14: a partly indexed repo still gets the atlas OFFERED, because adoption is not binary', () => {
    // The shape measured on the real target this was built against: one index declared, and
    // directories carrying a README that says nothing about what is in them. Reading that as
    // `keep` would retire the offer on exactly the repo with the most to gain from it.
    const d = join(tmp, 'ss14-partial')
    mkdirSync(d)
    buildGoverned(d)
    for (const sub of ['docs', 'lib', 'tools', 'lib/deep']) {
      mkdirSync(join(d, sub), { recursive: true })
      writeFileSync(join(d, sub, 'README.md'), `# ${sub}/\n\nProse with no glossary behind it.\n`)
    }
    // Two controls for the rule this discovery actually uses. A directory holding SOURCE and no
    // README is a candidate, because the question is what nobody has described rather than which
    // page happens to exist; requiring a README is what let a kept source directory be passed over
    // in silence while an ignored build directory with one was offered as work. And a directory
    // holding nothing is not a candidate, because there is nothing there to describe.
    mkdirSync(join(d, 'no-readme-but-source'), { recursive: true })
    writeFileSync(join(d, 'no-readme-but-source', 'engine.mjs'), 'export const x = 1\n')
    mkdirSync(join(d, 'empty-of-everything'), { recursive: true })
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1, docs: { index: { file: 'docs/README.md', statuses: ['active'] } },
    }))
    const r = sense(d)
    assert.equal(r.enforcement.indexes.declared, 1, 'the one declared index is still reported as adopted')
    // `acceptance/` holds the committed lint and no index speaks for it, so it is a candidate on
    // the same rule as the rest. This is the discovery the planner and the gate make, and sense
    // agreeing with them is the whole point of the rule being shared.
    assert.deepEqual(r.enforcement.indexes.candidates, ['acceptance', 'lib', 'lib/deep', 'no-readme-but-source', 'tools'],
      'every directory holding kept files no index speaks for is a candidate, nested ones included, whether or not it keeps a README; a directory holding nothing is not one')
    assert.equal(planAction(r, 'per-directory indexes (.repo-standard.json)'), 'offer',
      'a repo with directories left to cover gets asked again; `keep` is for a tree with nothing left')
    // And the decline still wins, or the offer becomes the nag the whole `declined` state exists
    // to prevent.
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1,
      docs: { index: { file: 'docs/README.md', statuses: ['active'] } },
      scaffold: { pluginVersion: '0.6.0', answers: { ATLAS_OFFER: 'declined' } },
    }))
    assert.equal(planAction(sense(d), 'per-directory indexes (.repo-standard.json)'), 'declined',
      'an operator who said never again has answered the question, however many directories are left')
    // Nothing left to cover is the only `keep`, and "nothing left" now includes the directory
    // holding the lint: it is answered by a recorded decline like any other.
    for (const sub of ['lib/deep', 'lib', 'tools', 'no-readme-but-source']) rmSync(join(d, sub), { recursive: true, force: true })
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1,
      docs: { index: { file: 'docs/README.md', statuses: ['active'] }, declined: [{ dir: 'acceptance', why: 'the committed lint, which the standard ships rather than describes' }] },
    }))
    assert.equal(planAction(sense(d), 'per-directory indexes (.repo-standard.json)'), 'offer-strict',
      'a declared index and no directory left holding files nobody speaks for is the adopted state, and an adopted atlas still running under "declared" has exactly one thing left to offer')
  })
  check('SS14: one declined directory does not cost the whole repo its offer', () => {
    // The alternative on offer was `ATLAS_OFFER: declined`, which is terminal. A repo that turned
    // down ONE leaf directory would have had to silence the pillar everywhere to stop being asked,
    // and the real target did exactly this: one excluded directory, sensing `offer` forever.
    const d = join(tmp, 'ss14-declined-dir')
    mkdirSync(d)
    buildGoverned(d)
    for (const sub of ['docs', 'zap', 'lib']) {
      mkdirSync(join(d, sub), { recursive: true })
      writeFileSync(join(d, sub, 'README.md'), `# ${sub}/\n\nProse.\n`)
    }
    const cfg = (declined) => JSON.stringify({
      version: 1,
      docs: { index: { file: 'docs/README.md', statuses: ['active'] }, ...(declined ? { declined } : {}) },
    })
    writeFileSync(join(d, '.repo-standard.json'), cfg([{ dir: 'zap', why: 'one scanner config nobody browses' }]))
    let r = sense(d)
    assert.deepEqual(r.enforcement.indexes.candidates, ['acceptance', 'lib'], 'the declined directory stops being a candidate, and the ones nobody has answered for stay')
    assert.deepEqual(r.enforcement.indexes.declined, ['zap'], 'and is reported as declined rather than vanishing')
    assert.equal(planAction(r, 'per-directory indexes (.repo-standard.json)'), 'offer',
      'while every other directory is still offered, which a repo-wide decline could never manage')
    writeFileSync(join(d, '.repo-standard.json'), cfg([{ dir: 'zap', why: 'as above' }, { dir: 'lib', why: 'and this one too' }, { dir: 'acceptance', why: 'the committed lint' }]))
    assert.equal(planAction(sense(d), 'per-directory indexes (.repo-standard.json)'), 'offer-strict',
      'and once every remaining directory has been answered, the pillar is adopted, with strict as the one offer left')
  })
  check('SS14: an index the directory does not render on arrival is sensed as an offer, not as done', () => {
    // The conversion the first real run missed. docs/INDEX.md was complete, correct, and invisible
    // when anyone browsed docs/. Sensing it as `keep` is what meant nothing ever proposed the move.
    const d = join(tmp, 'ss14-migration')
    mkdirSync(d)
    buildGoverned(d)
    mkdirSync(join(d, 'docs'), { recursive: true })
    writeFileSync(join(d, 'docs', 'INDEX.md'), '# Documentation\n\n| File | What it is for |\n|---|---|\n')
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1,
      docs: { extra: ['docs/INDEX.md'], index: { file: 'docs/INDEX.md', statuses: ['active'] }, declined: [{ dir: 'acceptance', why: 'the committed lint, answered so this fixture tests the move and nothing else' }] },
    }))
    let r = sense(d)
    assert.deepEqual(r.enforcement.indexes.migrations, [{ from: 'docs/INDEX.md', to: 'docs/README.md' }],
      'the README slot is free, so the move is surfaced at sense time rather than waiting for someone to notice')
    assert.equal(planAction(r, 'per-directory indexes (.repo-standard.json)'), 'offer',
      'and a complete index in the wrong place is not `keep`')
    // Taken, and it is no longer a move: a README that is one of the directory's own artifacts is
    // not a slot to overwrite.
    writeFileSync(join(d, 'docs', 'README.md'), '# Docs\n\nProse that is not the catalog.\n')
    r = sense(d)
    assert.deepEqual(r.enforcement.indexes.migrations, [], 'an occupied README is not a slot, and no move is proposed')
    assert.equal(planAction(r, 'per-directory indexes (.repo-standard.json)'), 'offer-strict', 'so the pillar reads as adopted, with strict still to offer')
  })
  check('SS14: a move is never proposed for an index that does not exist, or one recorded as retained', () => {
    // Two ways this offered work nobody could do. A DECLARED index that was never written is
    // missing, not misplaced, and proposing `git mv` on it sent a run looking for a page that had
    // never been created. And `retain` is the operator's recorded answer to this exact question,
    // so re-asking it is the failure the record exists to prevent.
    const d = join(tmp, 'ss14-migration-guards')
    mkdirSync(d)
    buildGoverned(d)
    mkdirSync(join(d, 'docs'), { recursive: true })
    const cfg = (extra) => JSON.stringify({
      version: 1, docs: { extra: ['docs/INDEX.md'], index: { file: 'docs/INDEX.md', statuses: ['active'], ...extra } },
    })
    writeFileSync(join(d, '.repo-standard.json'), cfg({}))
    assert.deepEqual(sense(d).enforcement.indexes.migrations, [],
      'docs/INDEX.md is declared and does not exist, so there is nothing to move: writing it is the work, and a rename is not')
    writeFileSync(join(d, 'docs', 'INDEX.md'), '# Documentation\n\n| File | What it is for |\n|---|---|\n')
    assert.equal(sense(d).enforcement.indexes.migrations.length, 1, 'once it exists, the move is on offer again')
    writeFileSync(join(d, '.repo-standard.json'), cfg({ retain: 'the release notes link this path by name' }))
    assert.deepEqual(sense(d).enforcement.indexes.migrations, [],
      'and a recorded retain closes it: an answered question that keeps producing the same prompt is not a record')
  })
  check('SS14: a repo that declared no index and turned every directory down has ANSWERED', () => {
    // The shape where a recorded no went nowhere. With no index declared, the adoption test
    // started with `indexFiles.length &&`, so every decline in the config still produced `offer`,
    // which is the same output the repo would give if nobody had ever been asked.
    const d = join(tmp, 'ss14-all-declined')
    mkdirSync(d)
    buildGoverned(d)
    for (const sub of ['zap', 'lib']) {
      mkdirSync(join(d, sub), { recursive: true })
      writeFileSync(join(d, sub, 'README.md'), `# ${sub}/\n\nProse.\n`)
    }
    const declined = [{ dir: 'zap', why: 'one scanner config nobody browses' }, { dir: 'lib', why: 'three fragments a glossary would decorate' }, { dir: 'acceptance', why: 'the committed lint' }]
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({ version: 1, docs: { declined } }))
    const r = sense(d)
    assert.deepEqual(r.enforcement.indexes.candidates, [], 'every directory was answered, so none is a candidate')
    assert.deepEqual(r.enforcement.indexes.declined.sort(), ['acceptance', 'lib', 'zap'], 'and every answer is reported rather than vanishing')
    assert.equal(planAction(r, 'per-directory indexes (.repo-standard.json)'), 'declined',
      'so the pillar reads as answered, not as a question waiting to be asked again')
  })
  check('SS14: the ignore posture names the missing rules, and a re-exposing negation', () => {
    const d = join(tmp, 'ss14-ignore')
    mkdirSync(d)
    buildGoverned(d)
    let r = sense(d)
    assert.equal(r.enforcement.ignore.present, false, 'no ignore file yet')
    assert.equal(r.enforcement.ignore.secretsCovered, false)
    assert.equal(planAction(r, '.gitignore (secrets ruleset)'), 'install', 'no file means install, not merge')
    writeFileSync(join(d, '.gitignore'), '.env\nnode_modules/\n')
    r = sense(d)
    assert.equal(planAction(r, '.gitignore (secrets ruleset)'), 'merge', 'an existing file is merged, never clobbered')
    assert.deepEqual(r.enforcement.ignore.missingRules, ['.env.<variant>'],
      'a bare .env rule leaves the variants open, and the report says exactly which rule is missing')
    writeFileSync(join(d, '.gitignore'), '.env\n.env.*\n!.env.production\n')
    r = sense(d)
    assert.equal(r.enforcement.ignore.secretsCovered, false, 'a negation that re-exposes a real .env is not covered')
    assert.deepEqual(r.enforcement.ignore.reopeningNegations, ['!.env.production'], 'and the offending line is named')
    writeFileSync(join(d, '.gitignore'), '.env\n.env.*\n!.env.example\n')
    r = sense(d)
    assert.equal(r.enforcement.ignore.secretsCovered, true, 'the example file is the one permitted negation')
    assert.equal(planAction(r, '.gitignore (secrets ruleset)'), 'keep')
  })
  check('SS14: generator drift is DIRECTED by its own version constant, like the lint\'s', () => {
    const d = join(tmp, 'ss14-gen')
    mkdirSync(d)
    buildGoverned(d)
    mkdirSync(join(d, '.github', 'assets'), { recursive: true })
    const payloadGen = readFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), 'utf8')
    const version = payloadGen.match(/^export const REPO_STANDARD_ASSETS_VERSION = '([^'\n]+)'/m)?.[1]
    assert.ok(version, 'the payload generator carries a parseable version constant')
    copyFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), join(d, '.github', 'assets', 'generate.mjs'))
    assert.equal(planAction(sense(d), '.github/assets/generate.mjs'), 'keep', 'a byte-identical generator is keep')
    writeFileSync(join(d, '.github', 'assets', 'generate.mjs'),
      payloadGen.replace(`REPO_STANDARD_ASSETS_VERSION = '${version}'`, "REPO_STANDARD_ASSETS_VERSION = '0.0.1'"))
    assert.equal(planAction(sense(d), '.github/assets/generate.mjs'), 'upgrade', 'an older installed generator is an upgrade')
    writeFileSync(join(d, '.github', 'assets', 'generate.mjs'),
      payloadGen.replace(`REPO_STANDARD_ASSETS_VERSION = '${version}'`, "REPO_STANDARD_ASSETS_VERSION = '99.0.0'"))
    assert.equal(planAction(sense(d), '.github/assets/generate.mjs'), 'downgrade',
      'a NEWER installed generator must never be called an upgrade: replacing it would regress the artwork')
    assert.ok(senseRaw(d).includes('"downgrade"'), 'the JSON report carries the verdict too')
  })
  check('SS14: a declared identity and profile are reported as adopted, with their real scope', () => {
    const d = join(tmp, 'ss14-adopted')
    mkdirSync(d)
    buildGoverned(d)
    mkdirSync(join(d, '.github', 'assets'), { recursive: true })
    copyFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), join(d, '.github', 'assets', 'generate.mjs'))
    writeFileSync(join(d, '.github', 'assets', 'manifest.json'), JSON.stringify({
      version: 1, brand: { name: 'X' }, paletteSource: { kind: 'preset', preset: 'slate' },
      banners: [{ slug: 'a' }, { slug: 'b' }], pills: [{ file: 'v.svg' }],
    }))
    writeFileSync(join(d, '.repo-standard.json'), JSON.stringify({
      version: 1, assets: { dir: '.github/assets' }, prose: { profile: 'enterprise', scan: 'markdown' },
    }))
    const r = sense(d)
    assert.equal(r.enforcement.assets.declared, true)
    assert.deepEqual([r.enforcement.assets.manifest.banners, r.enforcement.assets.manifest.pills], [2, 1],
      'the manifest inventory is reported so a plan can describe the scale of a re-run')
    assert.equal(r.enforcement.assets.manifest.paletteKind, 'preset')
    assert.equal(r.enforcement.prose.profile, 'enterprise')
    assert.equal(r.enforcement.prose.scan, 'markdown', 'the declared reach is reported, not the default')
    assert.equal(planAction(r, 'prose profile (.repo-standard.json)'), 'keep', 'an adopted pillar is never re-offered')
  })

  check('SS9: git signals do not leak from an ancestor repository', () => {
    // tmp itself is not a repo; make one, then sense a plain subdir inside it
    const outer = join(tmp, 'outer-repo')
    mkdirSync(outer)
    execFileSync('git', ['init', '-b', 'main'], { cwd: outer, stdio: 'ignore' })
    execFileSync('git', ['remote', 'add', 'origin', 'git@github.com:acme/outer.git'], { cwd: outer, stdio: 'ignore' })
    const inner = join(outer, 'newproject')
    mkdirSync(inner)
    const r = sense(inner)
    assert.equal(r.signals.git.isRepo, false, 'a plain dir inside a checkout is not itself a repo')
    assert.equal(r.signals.git.remoteUrl, null, 'the ancestor remote must not leak in')
    assert.equal(r.derived.repoSlug, null)
  })
  // ── the atlas pillar's third input ──────────────────────────────────────────────────────
  // The plan action used to be computed from candidates and migrations alone, so a repo running
  // `"docs.ownership": "strict"` with a file no declaration speaks for reported `keep`: the two
  // engines that decide the build agreed it was broken while the sensor that decides whether to
  // offer the pillar said there was nothing to do. And a `declared` adopter sitting at zero was
  // never told that strict exists, so the mode was only ever offered when Atlas happened to run
  // for another reason.
  const atlasRepo = (docs, extra = {}) => {
    const dir = mkdtempSync(join(tmp, 'atlas-'))
    mkdirSync(join(dir, 'lib'), { recursive: true })
    writeFileSync(join(dir, '.repo-standard.json'), `${JSON.stringify({ version: 1, docs }, null, 2)}\n`)
    writeFileSync(join(dir, 'lib', 'README.md'), '# lib/\n\nReconciled against the code: 2026-01-01\n\n'
      + '| File | What it is for | Status |\n|---|---|---|\n| [`one.mjs`](one.mjs) | The only engine. | `active` |\n')
    writeFileSync(join(dir, 'lib', 'one.mjs'), 'export const one = 1\n')
    for (const [rel, body] of Object.entries(extra)) writeFileSync(join(dir, rel), body)
    return dir
  }
  const IX = { file: 'lib/README.md', extensions: ['.mjs'], scope: 'direct', statuses: ['active'], reconciled: true }
  const atlasOf = (dir) => { const r = sense(dir); return { atlas: r.atlas, action: r.plan.find((p) => p.artifact.startsWith('per-directory')).action } }

  check('SS10: sense reports the ownership mode, the unowned count, and strict readiness', () => {
    const { atlas, action } = atlasOf(atlasRepo({ extra: ['lib/README.md'], indexes: [IX] }))
    assert.equal(atlas.ownership, 'declared', 'the mode is reported rather than inferred by every caller')
    assert.equal(atlas.unowned, 0, 'nothing is unowned in a complete tree')
    assert.equal(action, 'offer-strict',
      'and the one thing left is the mode: `keep` here read as finished, so the scaffold stopped and strictAvailable was computed, printed, and routed nowhere')
    assert.equal(atlas.strictAvailable, true,
      'a declared adopter sitting at zero is TOLD that strict exists: that is the setting which turns "a file added tomorrow reddens the build" into a check, and it was only ever offered by accident')
  })

  check('SS11: a strict repo with an unowned file is an OFFER, because its build is red', () => {
    const dir = atlasRepo({ ownership: 'strict', extra: ['lib/README.md'], indexes: [IX] }, { 'lib/notes.txt': 'nobody owns me\n' })
    const { atlas, action } = atlasOf(dir)
    assert.equal(atlas.ownership, 'strict')
    assert.equal(atlas.unowned, 1, 'the file no declaration reaches is counted')
    assert.equal(atlas.strictFailures, 1, 'and under strict it is a build failure, not a note')
    assert.equal(action, 'offer', 'so the pillar has work: reporting `keep` here contradicted the gate and the planner at once')
    assert.equal(atlas.strictAvailable, false, 'strict is already on, so there is nothing to offer about it')
  })

  check('SS12: the same file under `declared` is reported and not judged', () => {
    const dir = atlasRepo({ extra: ['lib/README.md'], indexes: [IX] }, { 'lib/notes.txt': 'nobody owns me\n' })
    const { atlas, action } = atlasOf(dir)
    assert.equal(atlas.unowned, 1, 'still counted, because silence here reads exactly like coverage')
    assert.equal(atlas.strictFailures, 0, 'but `declared` fails nothing: the operator\'s extensions list IS their answer')
    assert.equal(action, 'offer-coverage',
      'so the pillar has something to say: nothing STRUCTURAL is left, strict cannot be turned on yet, and the unowned file is the whole distance between the two. `keep` reported this repo as finished')
    assert.equal(atlas.strictAvailable, false, 'and strict is not offered while turning it on would redden the build')
  })

  check('SS13: a recorded no to strict is durable, and a repo already running it has nothing to offer', () => {
    // The other half of the routing. An offer with no recorded answer comes back every session,
    // which is the failure `docs.declined` exists to prevent one directory at a time; and a repo
    // that already declares strict must not be offered the mode it is running.
    const declinedDocs = { extra: ['lib/README.md'], indexes: [IX] }
    const withAnswer = atlasRepo(declinedDocs)
    writeFileSync(join(withAnswer, '.repo-standard.json'), `${JSON.stringify({
      version: 1, docs: declinedDocs, scaffold: { answers: { ATLAS_STRICT_OFFER: 'declined' } },
    }, null, 2)}\n`)
    assert.equal(atlasOf(withAnswer).action, 'keep',
      'a recorded no reads as adopted from then on: under `declared` the extensions lists ARE the answer for the remainder')
    assert.equal(atlasOf(atlasRepo({ ownership: 'strict', extra: ['lib/README.md'], indexes: [IX] })).action, 'keep',
      'and a repo already running strict with nothing unowned is finished, not offered its own mode back')
  })

  check('SS13: a path git keeps that this engine cannot see makes strict unavailable', () => {
    // The sensor and the two engines that decide the build now build ONE universe. Before this,
    // sense filtered neither gitlinks nor deleted paths and never lstat'd, so it could report a
    // repo ready for a mode the gate would immediately fail it on.
    const dir = atlasRepo({ extra: ['lib/README.md'], indexes: [IX] })
    execFileSync('git', ['init', '-q', '.'], { cwd: dir })
    execFileSync('git', ['config', 'user.email', 't@t.t'], { cwd: dir })
    execFileSync('git', ['config', 'user.name', 't'], { cwd: dir })
    writeFileSync(join(dir, 'lib', 'hidden.mjs'), 'export const hidden = 1\n')
    execFileSync('git', ['add', '-A'], { cwd: dir })
    execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir })
    execFileSync('git', ['update-index', '--skip-worktree', 'lib/hidden.mjs'], { cwd: dir })
    rmSync(join(dir, 'lib', 'hidden.mjs'))
    const { atlas } = atlasOf(dir)
    assert.equal(atlas.universeErrors.length, 1, 'a tracked file hidden by a sparse checkout is NAMED rather than dropped from the set')
    assert.equal(atlas.strictReady, false, 'and a universe this engine could not fully see is not one strict can be turned on over')
    assert.equal(atlas.strictAvailable, false)
  })
} finally {
  rmSync(tmp, { recursive: true, force: true })
  /*
   * ───────────────────────────────────── SS-BLOCK: the two TERMINAL routings (SS20, SS21)
   *
   * This engine is read-only, and it ROUTES. Read-only is not the same as harmless.
   *
   * SS20  A configured path that leaves the repo must be REFUSED before it is read, hashed or
   *       routed. With `assets.dir: "../outside/assets"` this engine read a generator in a sibling
   *       checkout, reported it installed at that copy's version, and emitted a DIRECTED plan
   *       action for it, while the planner and the gate both exited 2 on the same config. The
   *       scaffold skill follows those actions, and one of them is "run this generator".
   * SS21  A universe error beats every other answer. `universeErrors` was computed, printed, and
   *       routed nowhere: a skip-worktree entry (or an unstaged deletion) returned `keep` under
   *       strict and `offer-coverage` under declared, on a tree the planner exits 1 on and the
   *       gate's RS-index (universe) is red on. The cheapest of the three engines, and the one
   *       that decides whether the pillar runs at all, was the one saying nothing was wrong.
   */
  const outsideRoot = join(tmp, 'outside')
  mkdirSync(join(outsideRoot, 'assets'), { recursive: true })
  writeFileSync(join(outsideRoot, 'assets', 'generate.mjs'), "export const REPO_STANDARD_ASSETS_VERSION = '9.9.9'\n")
  writeFileSync(join(outsideRoot, 'ignore-rules'), '.env\n.env.*\n')
  const escaped = join(tmp, 'escaped')
  mkdirSync(escaped)
  buildGoverned(escaped)
  writeFileSync(join(escaped, '.repo-standard.json'), JSON.stringify({
    version: 1, assets: { dir: '../outside/assets' }, ignore: { file: '../outside/ignore-rules' },
  }, null, 2) + '\n')
  check('SS20: a configured path that leaves the repo is refused, not followed', () => {
    const r = sense(escaped)
    assert.equal(r.configPathErrors.length, 2, `both keys are named: ${JSON.stringify(r.configPathErrors)}`)
    assert.ok(r.configPathErrors.some((e) => e.where === 'assets.dir'), 'assets.dir is one of them')
    assert.ok(r.configPathErrors.some((e) => e.where === 'ignore.file'), 'and ignore.file is the other')
    assert.equal(r.enforcement.assets.generator.installed, false,
      'the generator outside the repo was NOT read: reporting it installed is what handed the scaffold skill a path to run')
    assert.equal(r.enforcement.assets.generator.installedVersion, null, 'and its version was never taken from a tree this repo does not govern')
    assert.equal(planAction(r, '.repo-standard.json'), 'repair', 'the config is what needs fixing, so that is the action')
    assert.equal(planAction(r, r.enforcement.assets.generator.path), 'blocked-config', 'and the pillar the bad key points at is BLOCKED rather than answered')
  })
  check('SS21: a universe error is terminal, in both ownership modes', () => {
    for (const ownership of ['declared', 'strict']) {
      const dir = join(tmp, `universe-${ownership}`)
      mkdirSync(join(dir, 'lib'), { recursive: true })
      buildGoverned(dir)
      writeFileSync(join(dir, 'lib', 'README.md'), '# lib/\n\n| File | What | Status |\n|---|---|---|\n| [one.mjs](one.mjs) | x | active |\n')
      writeFileSync(join(dir, 'lib', 'one.mjs'), 'export const one = 1\n')
      writeFileSync(join(dir, '.repo-standard.json'), JSON.stringify({
        version: 1, docs: { ownership, extra: ['lib/README.md'], indexes: [{ file: 'lib/README.md', extensions: ['.mjs'], scope: 'direct' }] },
      }, null, 2) + '\n')
      execFileSync('git', ['init', '-q'], { cwd: dir, stdio: 'ignore' })
      execFileSync('git', ['config', 'user.email', 't@t.t'], { cwd: dir, stdio: 'ignore' })
      execFileSync('git', ['config', 'user.name', 't'], { cwd: dir, stdio: 'ignore' })
      execFileSync('git', ['add', '-A'], { cwd: dir, stdio: 'ignore' })
      execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir, stdio: 'ignore' })
      // A plain rm: still tracked, off the disk, and the case the --deleted subtraction excused.
      rmSync(join(dir, 'lib', 'one.mjs'))
      const r = sense(dir)
      assert.equal(r.atlas.universeErrors.length, 1, `${ownership}: the hidden path is named`)
      assert.equal(planAction(r, 'per-directory indexes (.repo-standard.json)'), 'blocked-universe',
        `${ownership}: a tree this engine cannot enumerate is not a tree to offer work on. Got "${planAction(r, 'per-directory indexes (.repo-standard.json)')}"`)
    }
  })

}

/*
 * ───────────────────────────────── SUBSTITUTED PATHS AND ROUTE SELECTORS (SS-P-*)
 *
 * This engine is read-only, and that is what made these easy to miss and expensive to keep: it
 * ROUTES. The scaffold journey follows what it says, and one of the actions it can follow is
 * "replace this file" and another is "run it". An external audit found a target whose committed
 * gate was a SYMLINK to a clean copy in another checkout reported as `matchesPayload: true` and
 * `keep`, on a repo whose own index was missing a row.
 */
const withGoverned = (fn) => {
  const dir = mkdtempSync(join(tmpdir(), 'rs-sense-physical-'))
  const away = mkdtempSync(join(tmpdir(), 'rs-sense-away-'))
  try { return fn(dir, away) } finally {
    rmSync(dir, { recursive: true, force: true })
    rmSync(away, { recursive: true, force: true })
  }
}
check('SS-P1 a gate committed as a symlink is reported as substituted, never hashed, and never "keep"', () => {
  withGoverned((dir, away) => {
    buildGoverned(dir)
    // The link points at a byte-identical payload copy, which is the case that used to come back
    // `matchesPayload: true`: identical bytes are not the question, WHERE they are committed is.
    copyFileSync(PAYLOAD_LINT, join(away, 'test-repo-standard.mjs'))
    rmSync(join(dir, 'acceptance', 'test-repo-standard.mjs'))
    symlinkSync(join(away, 'test-repo-standard.mjs'), join(dir, 'acceptance', 'test-repo-standard.mjs'))
    const r = sense(dir)
    assert.ok(r.substitutions.some((s) => s.path === 'acceptance/test-repo-standard.mjs'),
      `the substitution is reported\n${JSON.stringify(r.substitutions)}`)
    assert.equal(r.enforcement.lint.matchesPayload, null,
      'nothing about its content is claimed: reading through the link is what produced the false "matches payload"')
    assert.equal(r.enforcement.lint.installed, true,
      'and it is still reported as installed, because telling the scaffold to install over a link would write through it')
    assert.equal(planAction(r, 'acceptance/test-repo-standard.mjs'), 'blocked-link',
      `the action is terminal, not "keep"\n${JSON.stringify(r.plan)}`)
  })
})
check('SS-P2 a symlinked generator is never hashed, versioned, or handed to the scaffold to run', () => {
  withGoverned((dir, away) => {
    buildGoverned(dir)
    mkdirSync(join(dir, '.github', 'assets'), { recursive: true })
    writeFileSync(join(dir, '.repo-standard.json'), JSON.stringify({ version: 1, assets: { dir: '.github/assets' } }, null, 2))
    copyFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), join(away, 'generate.mjs'))
    symlinkSync(join(away, 'generate.mjs'), join(dir, '.github', 'assets', 'generate.mjs'))
    const r = sense(dir)
    assert.equal(r.enforcement.assets.generator.matchesPayload, null, 'no hash is claimed for an engine committed somewhere else')
    assert.equal(r.enforcement.assets.generator.installedVersion, null, 'and no version either')
    assert.equal(planAction(r, '.github/assets/generate.mjs'), 'blocked-link',
      `and the scaffold is stopped rather than told to run it\n${JSON.stringify(r.plan)}`)
  })
})
check('SS-P3 a route-selecting field with the wrong TYPE is a repair, never a silent default', () => {
  /*
   * `assets.dir` selects which generator is hashed, versioned and RUN; `ignore.file` selects which
   * file the secrets ruleset is read from. Both fell straight through to the default here while the
   * gate and the planner exited 2, so this engine described a directory the config never chose and
   * could report a repo's credentials covered by rules in a file it does not use.
   */
  for (const [key, cfg, where] of [
    ['assets', { version: 1, assets: 7 }, 'assets'],
    ['assets.dir', { version: 1, assets: { dir: 7 } }, 'assets.dir'],
    ['ignore', { version: 1, ignore: 7 }, 'ignore'],
    ['ignore.file', { version: 1, ignore: { file: 7 } }, 'ignore.file'],
  ]) {
    withGoverned((dir) => {
      buildGoverned(dir)
      writeFileSync(join(dir, '.repo-standard.json'), JSON.stringify(cfg, null, 2))
      const r = sense(dir)
      assert.ok(r.configPathErrors.some((e) => e.where === where),
        `${key}: the wrong type is reported as a config error, not defaulted past\n${JSON.stringify(r.configPathErrors)}`)
      assert.equal(planAction(r, '.repo-standard.json'), 'repair',
        `${key}: and the config is what has to be fixed before any action here can be trusted`)
    })
  }
})
check('SS-P4 a decline spelled with a control character is refused here exactly as the gate refuses it', () => {
  withGoverned((dir) => {
    buildGoverned(dir)
    writeFileSync(join(dir, '.repo-standard.json'), JSON.stringify({
      version: 1,
      docs: { declined: [{ dir: '\nghost', why: 'a control character in front of a directory name' }] },
    }, null, 2))
    const r = sense(dir)
    assert.ok(r.configPathErrors.some((e) => e.where === 'docs.declined[0].dir'),
      `trimming before the contract repaired the very spelling the contract exists to refuse\n${JSON.stringify(r.configPathErrors)}`)
  })
})

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
