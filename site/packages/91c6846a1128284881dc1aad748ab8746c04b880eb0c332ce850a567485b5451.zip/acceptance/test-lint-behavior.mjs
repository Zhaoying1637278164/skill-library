#!/usr/bin/env node
/*
 * test-lint-behavior.mjs — mutation coverage for the payload lint (the shipped enforcement).
 *
 * WHY: a check that cannot redden is not a gate. This test materializes a KNOWN-CLEAN fixture
 * repo in a temp dir, proves the shipped payload/acceptance/test-repo-standard.mjs passes it,
 * then applies one targeted mutation per rule and proves the lint fails with the right check
 * named. It also proves the exemptions (quoted mentions, fenced code, properNouns, `under`
 * region scoping) do NOT fire, that skips are loud, and that the two failure classes keep their
 * exit codes (2 = broken config, 1 = drifted docs, 0 = clean).
 *
 * Guards:
 *   LB-CLEAN      the clean fixture passes (exit 0) and the run is byte-deterministic.
 *   LB-M-*        one mutation per lint rule → exit 1 and the right RS-id in the output.
 *   LB-C-*        config mutations → exit 2, doc checks not run, offending key named.
 *   LB-S-*        skips and reasoned disables are printed, loud, and honored.
 *   LB-I-*        RS-index: coverage, link resolution, containment inside the indexed directory,
 *                 uniqueness, the status vocabulary and its aliases, ascending order once
 *                 declared, a declared child index bounding its parent, the two ways a date can
 *                 be recorded, and the markdown a naive parser gets wrong (an escaped pipe in a
 *                 cell, an angle-bracket link destination).
 *   LB-A-*        RS-assets, against the SECOND fixture family below: a tree with genuinely
 *                 rendered artwork, so drift, provenance and the README block mutate something
 *                 real rather than a stand-in.
 *   LB-B-*        RS-about: the recorded panel against the README's own tagline, offline.
 *   LB-I-g2-*     the grammar-2 column contract: the link is read from the FILE column, and a
 *                 table missing the status or verification-date column its declared checks read
 *                 is a gap in the page rather than permission to fall back to "any cell".
 *   LB-C-path-*   the PATH REGISTRY: one case per configured key that could reach outside the
 *                 repo (versionManifest, ignore.file, ignore.generated, assets.coverage.*,
 *                 prose.exempt, counts.*, docs.declined, stableDocs), plus the two spellings
 *                 that are NOT escapes (a trailing slash, a leading ./) and the one that is
 *                 (a backslash, refused before any normaliser can repair it).
 *   LB-SP-*       the SPELLING matrix: an ACCEPTED spelling has to MEAN the same thing. Each
 *                 case writes one path key with a leading "./" (or a trailing slash) and
 *                 asserts the whole lint output is byte-identical to the plain spelling, because
 *                 an exit code alone passes on a rule that silently stopped applying.
 *
 * Two rules for adding a case here, both learned from a mutation audit that found six rules
 * surviving deletion with this whole suite green:
 *   1. Assert on the MESSAGE, never a substring of the check's NAME. The `✗` line prints the
 *      check name, so a needle like 'bold tagline' (which is IN the RS-readme name) passes no
 *      matter which assertion fired — a guard that cannot fail.
 *   2. Several assertions share one check name. Plant an input that trips ONLY the one under
 *      test, or an earlier assertion fires first and the rule you meant to prove is untouched.
 * Verify a new case the same way: delete the rule from BOTH lint copies (payload-sync would
 * otherwise redden on the copy instead of the behavior) and confirm this suite goes red.
 *
 * The fixture exercises every configurable surface: manifest reconcile, requireSections,
 * minSections, extraBanned + properNouns, glob / file+lineRegex / agreement-only counts,
 * minMentions, `under` scoping, lockstep via auto-detected package.json.
 *
 * Dependency-free: `node acceptance/test-lint-behavior.mjs`.
 */
import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, copyFileSync, symlinkSync, renameSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
// The banner H1 idiom has ONE source. The fixture builds its READMEs with the same helper the
// lint expects and the generator prints, so a case here can never drift into testing a
// hand-typed approximation of the rule. The literal shape is pinned in test-assets-generator.
import { bannerH1, readmeBlock } from '../payload/assets/generate.mjs'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const LINT_SRC = readFileSync(join(ROOT, 'payload', 'acceptance', 'test-repo-standard.mjs'), 'utf8')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

// ─────────────────────────────────────────────────────────── the known-clean fixture
const BASE_CONFIG = {
  version: 1,
  manifest: { file: 'MANIFEST.md', statuses: ['UNCHANGED', 'NEW'] },
  readme: { requireSections: ['usage', 'caveat|limitation'] },
  conventions: { minSections: 3 },
  voice: { extraBanned: ['synergy'], properNouns: ['Seamless Deploy'] },
  prose: { profile: 'enterprise' },
  counts: {
    widgets: { pattern: '(\\d+)\\s+widget', glob: 'src/widget-*.txt', minMentions: 2 },
    gizmos: { pattern: '([\\d,]+)\\s+gizmos\\b' },
    rows: { pattern: 'of\\s+(\\d+)\\s+rows', file: 'data/rows.txt', lineRegex: '^row:', docs: ['README.md'] },
    sprockets: { pattern: '(\\d+)\\s+sprockets', docs: ['CHANGELOG.md'], under: '^\\[Unreleased\\]' },
  },
  stableDocs: ['SECURITY.md', 'CONTRIBUTING.md', 'CODE_OF_CONDUCT.md'],
}

const baseFiles = () => ({
  '.repo-standard.json': JSON.stringify(BASE_CONFIG, null, 2) + '\n',
  // RS-ignore holds every governed repo to this pair plus the one permitted negation: `.env`
  // alone would leave `.env.local` open, which is the half-fix the check exists to catch.
  '.gitignore': '.env\n.env.*\n!.env.example\nnode_modules/\n',
  'package.json': '{ "name": "fixture", "version": "1.2.3", "license": "MIT" }\n',
  'LICENSE': 'MIT License\n\nCopyright (c) 2026 fixture\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software.\n',
  'src/widget-a.txt': 'w\n',
  'src/widget-b.txt': 'w\n',
  'src/widget-c.txt': 'w\n',
  'data/rows.txt': 'row: 1\nrow: 2\n',
  'README.md': [
    '# fixture', '',
    '**A test fixture repo for the repo-standard lint.**', '',
    '## Install', '', 'Clone it.', '',
    '## Usage', '', 'This repo has 3 widget files and 7 gizmos, loaded from 2 of 2 rows.', '',
    '## Caveats', '', 'Known limits only. Built on Seamless Deploy.', '',
    '## Contributing', '', 'PRs welcome.', '',
    '## License', '', 'MIT.', '',
  ].join('\n'),
  'CHANGELOG.md': [
    '# Changelog', '',
    'Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).', '',
    '## [Unreleased]', '',
    '### Added', '',
    '- A sprocket pipeline carrying 5 sprockets; still 3 widget files and 7 gizmos.', '',
    '## [1.2.3] — 2026-01-01', '',
    '### Added', '',
    '- Initial release with 2 sprockets.', '',
  ].join('\n'),
  'CONVENTIONS.md': [
    '# Conventions', '',
    '## 1. Scope', '', 'A fixture.', '',
    '## 2. Voice', '', 'No marketing voice, and no "synergy" (extra house ban).', '',
    'The enterprise writing profile is on: no em dash in any form, and none of `delve`,',
    '`utilize`, `leverage`, `in order to`, `worth noting`, `it should be noted`,',
    '`needless to say`, `as you can see`, `furthermore`, `moreover`, `a wide range of`,',
    '`a variety of`, or `state-of-the-art`.', '',
    '## 3. Meta docs standard', '',
    'CHANGELOG follows Keep a Changelog (keepachangelog.com): only Added / Changed / Deprecated /',
    'Removed / Fixed / Security. README follows standard-readme: Install, Usage, Contributing,',
    'License last.', '',
  ].join('\n'),
  'MANIFEST.md': [
    '# Manifest', '',
    '| path | status | note |', '|---|---|---|',
    '| `a` | UNCHANGED | x |', '| `b` | NEW | x |', '| `c` | NEW | x |', '',
    'Totals: **1 UNCHANGED · 2 NEW · 3 total.**', '',
  ].join('\n'),
  'SECURITY.md': '# Security Policy\n\nReport privately.\n',
  'CONTRIBUTING.md': '# Contributing\n\nBe kind.\n',
  'CODE_OF_CONDUCT.md': '# Code of Conduct\n\nCovenant.\n',
})

const runLint = (mutate) => {
  const files = baseFiles()
  if (mutate) mutate(files)
  const tmp = mkdtempSync(join(tmpdir(), 'rs-lint-behavior-'))
  try {
    for (const [rel, content] of Object.entries(files)) {
      if (content === null) continue // null = delete from fixture
      mkdirSync(join(tmp, dirname(rel)), { recursive: true })
      writeFileSync(join(tmp, rel), content)
    }
    mkdirSync(join(tmp, 'acceptance'), { recursive: true })
    writeFileSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
    try {
      const out = execFileSync('node', [join(tmp, 'acceptance', 'test-repo-standard.mjs')], { encoding: 'utf8' })
      return { code: 0, out }
    } catch (e) {
      return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` }
    }
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
}

// mutation helper: assert exit code + that every needle appears in the output
const expect = (name, mutate, code, ...needles) => check(name, () => {
  const r = runLint(mutate)
  assert.equal(r.code, code, `expected exit ${code}, got ${r.code}\n--- lint output ---\n${r.out}`)
  for (const n of needles) assert.ok(r.out.includes(n), `output should contain "${n}"\n--- lint output ---\n${r.out}`)
})
const editConfig = (files, edit) => { const c = JSON.parse(files['.repo-standard.json']); edit(c); files['.repo-standard.json'] = JSON.stringify(c, null, 2) + '\n' }

console.log('lint-behavior standing test (mutation coverage of the payload lint)')

// ───────────────────────────────────────────────────────────────────────── clean
check('LB-CLEAN the known-clean fixture passes (exit 0) and the run is deterministic', () => {
  const a = runLint(null), b = runLint(null)
  assert.equal(a.code, 0, `clean fixture should pass\n--- lint output ---\n${a.out}`)
  assert.equal(a.out, b.out, 'two runs over the same fixture must print byte-identical output')
  assert.ok(a.out.includes('0 failed'), 'summary states 0 failed')
})

// ─────────────────────────────────────────────────────────────────── doc mutations
expect('LB-M-changelog an ad-hoc "### Notes" subsection reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('### Added', '### Notes\n\n- x\n\n### Added') }, 1,
  '✗ RS-changelog', 'non-canonical')
expect('LB-M-changelog-dup a repeated "### Added" in one version block reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('- A sprocket', '- x\n\n### Added\n\n- A sprocket') }, 1,
  '✗ RS-changelog', 'repeats')
expect('LB-M-changelog-h2 a non-version H2 ("## Roadmap") reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] += '\n## Roadmap\n\n- soon\n' }, 1,
  '✗ RS-changelog', 'not a version heading')
expect('LB-M-changelog-semver a non-semver version heading reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [v1.2] — 2026-01-01') }, 1,
  '✗ RS-changelog', 'not valid semver')
expect('LB-M-changelog-order ascending version order reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [Unreleased]', '## [Unreleased]\n\n## [0.9.0] — 2025-01-01\n\n### Fixed\n\n- old\n').replace('with 2 sprockets', 'with 2 sprockets kept') }, 1,
  '✗ RS-changelog', 'must descend')
expect('LB-M-changelog-unreleased-pos [Unreleased] not FIRST reddens RS-changelog (Keep a Changelog: on top)',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [Unreleased]\n\n### Added\n\n- A sprocket pipeline carrying 5 sprockets; still 3 widget files and 7 gizmos.\n', '').replace('- Initial release with 2 sprockets.', '- Initial release with 2 sprockets.\n\n## [Unreleased]\n\n### Added\n\n- A sprocket pipeline carrying 5 sprockets; still 3 widget files and 7 gizmos.') }, 1,
  '✗ RS-changelog', 'must be the FIRST')
expect('LB-M-changelog-nodate a dated version heading without its ISO date reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [1.2.3]') }, 1,
  '✗ RS-changelog', 'ISO release date')
expect('LB-M-changelog-dupver a repeated version section reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] += '\n## [1.2.3] — 2026-01-01\n\n### Fixed\n\n- again\n' }, 1,
  '✗ RS-changelog', 'repeats a version heading')
expect('LB-M-changelog-prerelease a prerelease listed above its same-triple release reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [1.2.3-alpha.1] - 2025-12-01\n\n### Added\n\n- alpha cut\n\n## [1.2.3] — 2026-01-01').replace('{ "name": "fixture", "version": "1.2.3" }', '{ "name": "fixture", "version": "1.2.3-alpha.1" }') }, 1,
  '✗ RS-changelog', 'must descend')
expect('LB-S-changelog-hyphen the spec\'s hyphen date separator is accepted alongside the em dash (stays green)',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [1.2.3] - 2026-01-01') }, 0)
expect('LB-S-changelog-yanked a spec-valid "[YANKED]" tag after the date stays green (Keep a Changelog\'s own vocabulary)',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [1.2.3] — 2026-01-01 [YANKED]') }, 0)
expect('LB-M-changelog-badsuffix any OTHER suffix after the date still reddens RS-changelog (the [YANKED] allowance is not a hole)',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [1.2.3] — 2026-01-01 [PULLED]') }, 1,
  '✗ RS-changelog', 'ISO release date')
expect('LB-M-lockstep a manifest version that disagrees with the newest dated CHANGELOG version reddens RS-lockstep',
  (f) => { f['package.json'] = '{ "name": "fixture", "version": "9.9.9" }\n' }, 1,
  '✗ RS-lockstep', 'bump both in lockstep')
expect('LB-M-readme-h1 a second H1 reddens RS-readme',
  (f) => { f['README.md'] += '\n# Another title\n' }, 1,
  '✗ RS-readme', 'exactly one H1')
// NB: RS-readme runs many assertions under ONE check name, and that name literally contains
// "bold tagline" — so a needle like 'bold tagline' is satisfied by the ✗ line itself no matter
// which assertion fired, and cannot tell them apart. Needles here must be substrings of the
// MESSAGE only, never of the check name. These two cases isolate one assertion each.
expect('LB-M-readme-blockquote a blockquote where the short description belongs reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('**A test fixture repo for the repo-standard lint.**', '> a quote instead of a tagline') }, 1,
  '✗ RS-readme', 'must not be a blockquote')
expect('LB-M-readme-tagline a PLAIN (non-bold) short description reddens RS-readme — the house bold rule is real',
  (f) => { f['README.md'] = f['README.md'].replace('**A test fixture repo for the repo-standard lint.**', 'A test fixture repo for the repo-standard lint.') }, 1,
  '✗ RS-readme', 'needs a bold tagline')
expect('LB-M-readme-install a missing Install section reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('## Install', '## Setup') }, 1,
  '✗ RS-readme', 'Install section')
expect('LB-M-readme-last a section after License reddens RS-readme (License must be LAST)',
  (f) => { f['README.md'] += '\n## Extra\n\nafterthought\n' }, 1,
  '✗ RS-readme', 'License section must be LAST')
expect('LB-M-readme-required a missing configured section (caveat|limitation) reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('## Caveats', '## Misc').replace('Known limits only.', 'Notes.') }, 1,
  '✗ RS-readme', 'caveat|limitation')

// ── standard-readme fidelity (the spec rules the adversarial pass found unenforced) ──
expect('LB-M-readme-usage a missing Usage section reddens RS-readme (spec: required by default)',
  (f) => { f['README.md'] = f['README.md'].replace('## Usage', '## Examples') }, 1,
  '✗ RS-readme', 'must have a Usage section')
expect('LB-S-readme-docsonly readme.docsOnly waives Install+Usage per the spec\'s documentation-repository exception (stays green)',
  (f) => {
    editConfig(f, (c) => { c.readme = { requireSections: ['caveat|limitation'], docsOnly: true } })
    f['README.md'] = f['README.md'].replace('## Install\n\nClone it.\n\n', '').replace('## Usage\n\n', '## Notes\n\n')
    f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('Install, Usage, Contributing,\nLicense last.', 'Contributing, License last.')
  }, 0)
expect('LB-S-readme-badges badges between the H1 and the tagline stay green (the spec\'s own section order)',
  (f) => { f['README.md'] = f['README.md'].replace('**A test fixture repo for the repo-standard lint.**', '[![build](https://img.shields.io/badge/build-passing-green)](https://example.com)\n\n**A test fixture repo for the repo-standard lint.**') }, 0)
expect('LB-M-readme-order a spec section out of the spec\'s order reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('## Install\n\nClone it.\n\n', '').replace('## Contributing', '## Install\n\nClone it.\n\n## Contributing') }, 1,
  '✗ RS-readme', 'standard-readme fixes the section order')
expect('LB-M-readme-toc a 100+ line README with no Table of Contents reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('## Caveats', `${'\n<!-- padding -->'.repeat(100)}\n\n## Caveats`) }, 1,
  '✗ RS-readme', 'Table of Contents')
expect('LB-M-readme-longdesc a short description of 120+ characters reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('**A test fixture repo for the repo-standard lint.**', `**${'A very long tagline that runs on and on well past the specification limit for a short description. '.repeat(2)}**`) }, 1,
  '✗ RS-readme', 'less than 120 characters')
expect('LB-S-readme-desc-boundary a 119-char description stays green; the bold markers do not count toward the limit',
  (f) => { f['README.md'] = f['README.md'].replace('**A test fixture repo for the repo-standard lint.**', `**${'x'.repeat(119)}**`) }, 0)
expect('LB-M-conventions-gap a numbering gap reddens RS-conventions',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('## 3. Meta docs standard', '## 4. Meta docs standard') }, 1,
  '✗ RS-conventions', 'numbering breaks')
expect('LB-M-conventions-floor gutting below minSections reddens RS-conventions',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].split('## 3. Meta docs standard')[0] }, 1,
  '✗ RS-conventions')
expect('LB-M-manifest a per-status count that no longer matches its rows reddens RS-manifest',
  (f) => { f['MANIFEST.md'] = f['MANIFEST.md'].replace('**1 UNCHANGED · 2 NEW · 3 total.**', '**2 UNCHANGED · 2 NEW · 4 total.**') }, 1,
  '✗ RS-manifest', 'Totals says 2 UNCHANGED but the table has 1')
// every per-status count CORRECT and only the grand total wrong — the one input that reaches
// the sum assertion, which the per-status cases above always trip first and so never exercise.
expect('LB-M-manifest-total a wrong grand total with correct per-status counts reddens RS-manifest',
  (f) => { f['MANIFEST.md'] = f['MANIFEST.md'].replace('· 3 total.**', '· 99 total.**') }, 1,
  '✗ RS-manifest', '!= the row sum')
expect('LB-M-voice a banned marketing word in prose reddens RS-voice',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it for a seamless setup.') }, 1,
  '✗ RS-voice', 'seamless')
expect('LB-M-voice-extra a config-extended banned word reddens RS-voice',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. Great synergy.') }, 1,
  '✗ RS-voice', 'synergy')
expect('LB-M-voice-propernoun removing the properNouns exemption makes the bare product name redden (the exemption is load-bearing)',
  (f) => editConfig(f, (c) => { delete c.voice.properNouns }), 1,
  '✗ RS-voice', 'seamless')
expect('LB-M-counts-stale a grown glob truth (4th widget) against a stale "3 widget" claim reddens RS-counts',
  (f) => { f['src/widget-d.txt'] = 'w\n' }, 1,
  '✗ RS-counts', 'the repo derives 4')
expect('LB-M-counts-disagree a cross-doc disagreement (7 vs 8 gizmos) reddens RS-counts',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('7 gizmos', '8 gizmos') }, 1,
  '✗ RS-counts', 'disagrees across docs')
expect('LB-M-counts-mentions dropping below minMentions reddens RS-counts',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('still 3 widget files and ', '') }, 1,
  '✗ RS-counts', 'minMentions')
expect('LB-M-counts-under removing `under` scoping makes the historical sprocket number collide (proves the scoping is load-bearing)',
  (f) => editConfig(f, (c) => { delete c.counts.sprockets.under }), 1,
  '✗ RS-counts', 'disagrees across docs')
expect('LB-M-reflexivity a CONVENTIONS that stops documenting a canonical category reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('Deprecated /', '/') }, 1,
  '✗ RS-reflexivity', 'Deprecated')
expect('LB-M-reflexivity-ban an extraBanned word the written standard does not document reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace(', and no "synergy" (extra house ban)', '') }, 1,
  '✗ RS-reflexivity', 'synergy')
expect('LB-M-stable a deleted stable meta file reddens RS-stable-docs',
  (f) => { f['SECURITY.md'] = null }, 1,
  '✗ RS-stable-docs', 'SECURITY.md must exist')
expect('LB-M-stable-h1 a stable meta file without an H1 reddens RS-stable-docs',
  (f) => { f['CONTRIBUTING.md'] = 'Be kind.\n' }, 1,
  '✗ RS-stable-docs', 'must open with an H1')
expect('LB-M-todos a surviving TODO(scaffold) marker reddens RS-todos',
  (f) => { f['README.md'] = f['README.md'].replace('PRs welcome.', 'PRs welcome. <!-- TODO(scaffold): write the real contributing note -->') }, 1,
  '✗ RS-todos', 'TODO(scaffold)')
expect('LB-M-license-missing a deleted license file reddens RS-license (deletable-while-green was the hole)',
  (f) => { f['LICENSE'] = null }, 1,
  '✗ RS-license', 'no license file at the repo root')
expect('LB-M-license-empty an empty license file reddens RS-license',
  (f) => { f['LICENSE'] = '' }, 1,
  '✗ RS-license', 'licenses nothing')
expect('LB-M-license-manifest a manifest license disagreeing with the LICENSE text reddens RS-license',
  (f) => { f['package.json'] = '{ "name": "fixture", "version": "1.2.3", "license": "Apache-2.0" }\n' }, 1,
  '✗ RS-license', 'must agree')
expect('LB-M-license-form the deprecated npm object license form reddens RS-license',
  (f) => { f['package.json'] = '{ "name": "fixture", "version": "1.2.3", "license": { "type": "MIT" } }\n' }, 1,
  '✗ RS-license', 'deprecated object/array form')
expect('LB-M-license-readme a README License section naming a different id reddens RS-license',
  (f) => { f['README.md'] = f['README.md'].replace('## License\n\nMIT.', '## License\n\nApache-2.0.') }, 1,
  '✗ RS-license', 'must name the license')
expect('LB-S-license-unrecognized an unrecognizable license text passes existence and SKIPS agreement, loudly',
  (f) => { f['LICENSE'] = 'You may use this for good, not evil.\n' }, 0,
  'RS-license (id agreement) SKIP')
expect('LB-S-license-expression an SPDX expression containing the detected id stays green',
  (f) => { f['package.json'] = '{ "name": "fixture", "version": "1.2.3", "license": "(MIT OR Apache-2.0)" }\n' }, 0)
expect('LB-S-license-copying the GPL convention (COPYING) counts as the license file',
  (f) => { f['COPYING'] = f['LICENSE']; f['LICENSE'] = null }, 0)
expect('LB-S-license-mit0 a self-consistent MIT-0 repo stays green (the fingerprint no longer guesses MIT)',
  (f) => {
    f['LICENSE'] = 'MIT No Attribution\n\nCopyright (c) 2026 fixture\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software, to deal in the Software without restriction.\n'
    f['package.json'] = '{ "name": "fixture", "version": "1.2.3", "license": "MIT-0" }\n'
    f['README.md'] = f['README.md'].replace('## License\n\nMIT.', '## License\n\nMIT-0.')
  }, 0)
expect('LB-S-license-grant-only a grant sentence WITHOUT the notice-preservation condition is unrecognized, not "MIT"',
  (f) => { f['LICENSE'] = 'Copyright (c) 2026 fixture\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software.\n' }, 0,
  'RS-license (id agreement) SKIP')
expect('LB-M-license-second-manifest a license-less plugin manifest cannot hide a disagreeing package.json (EVERY manifest is consulted)',
  (f) => {
    f['.claude-plugin/plugin.json'] = '{ "name": "fixture", "version": "1.2.3" }\n'
    f['package.json'] = '{ "name": "fixture", "version": "1.2.3", "license": "Apache-2.0" }\n'
  }, 1,
  '✗ RS-license', 'package.json declares license "Apache-2.0"')
expect('LB-S-license-manifest-skip a manifest with no license field prints a named manifest-leg SKIP, never an implied agreement',
  (f) => { f['package.json'] = '{ "name": "fixture", "version": "1.2.3" }\n' }, 0,
  'RS-license (manifest leg) SKIP')
expect('LB-M-placeholders an unfilled {{PLACEHOLDER}} token in prose reddens RS-placeholders',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone {{PROJECT_NAME}} first.') }, 1,
  '✗ RS-placeholders', 'unfilled template placeholder {{PROJECT_NAME}}')
expect('LB-M-placeholders-fence a placeholder inside a FENCED block still reddens (fences are where hand-copied templates hide them)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it.\n\n```bash\n{{INSTALL_COMMAND}}\n```') }, 1,
  '✗ RS-placeholders', '{{INSTALL_COMMAND}}')
expect('LB-M-placeholders-license an unfilled {{YEAR}} in the LICENSE file reddens RS-placeholders',
  (f) => { f['LICENSE'] = f['LICENSE'].replace('Copyright (c) 2026', 'Copyright (c) {{YEAR}}') }, 1,
  '✗ RS-placeholders', '{{YEAR}}')
expect('LB-S-placeholders-named NAMING a token in backticks stays green (a mention is not an unfilled scaffold)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. The scaffolder fills every `{{PROJECT_NAME}}` token.') }, 0)
expect('LB-M-placeholders-fence-quoted a QUOTED token inside a fence still reddens (in code, quotes are syntax, not mentions)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it.\n\n```json\n{ "name": "{{PROJECT_NAME}}" }\n```') }, 1,
  '✗ RS-placeholders', '{{PROJECT_NAME}}')
expect('LB-M-shadow a .github/ copy of a governed stable doc reddens RS-shadow (GitHub would serve the ungoverned copy)',
  (f) => { f['.github/CONTRIBUTING.md'] = '# Contributing\n\nStale shadow.\n' }, 1,
  '✗ RS-shadow', '.github/CONTRIBUTING.md shadows CONTRIBUTING.md')
expect('LB-S-shadow-elsewhere a README in an unrelated subdirectory is not a shadow (only the three GitHub-served locations count)',
  (f) => { f['acceptance/README.md'] = '# acceptance\n\nSuite docs.\n' }, 0)
// README is the one basename with two jobs on GitHub, and the docs/ copy is the second one.
// Getting this wrong pushed a real repo into disabling the whole check, so both directions are
// locked: the conventional docs index stays green, and every genuine shadow still reddens.
expect('LB-S-shadow-docs-readme a docs/README.md beside the root README is a directory index, not a shadow',
  (f) => { f['docs/README.md'] = '# Documentation\n\nThe index for the docs tree.\n' }, 0)
expect('LB-M-shadow-github-readme a .github/README.md beside the root README IS still a shadow',
  (f) => { f['.github/README.md'] = '# fixture\n\nThe copy GitHub would actually serve.\n' }, 1,
  '✗ RS-shadow', '.github/README.md shadows README.md')
expect('LB-M-shadow-docs-other the exemption is README-only: a docs/ copy of another governed doc still reddens',
  (f) => { f['docs/CONTRIBUTING.md'] = '# Contributing\n\nStale copy.\n' }, 1,
  '✗ RS-shadow', 'CONTRIBUTING.md')
expect('LB-M-shadow-readme-decoy configuring the README into docs/ while a root one exists reddens (the exemption is not a hole)',
  (f) => {
    editConfig(f, (c) => { c.docs = { readme: 'docs/README.md' } })
    f['docs/README.md'] = f['README.md']
  }, 1,
  '✗ RS-shadow', 'never the front page')

// ── RS-index: the catalog a documentation tree keeps of itself ──
const withIndex = (f, rows, extra = {}) => {
  editConfig(f, (c) => {
    // `extra` carries the index because RS-index requires every declared index to be governed
    // prose: an index no sweep reaches is the one page in its directory that can rot with nothing
    // here noticing. The atlas journey writes both entries together for the same reason.
    c.docs = {
      ...(c.docs ?? {}),
      extra: [...new Set([...(c.docs?.extra ?? []), 'docs/README.md'])],
      index: { file: 'docs/README.md', statuses: ['active', 'superseded'], requireDate: true },
    }
  })
  f['docs/guide.md'] = '# Guide\n\nHow to use it.\n'
  f['docs/ops/runbook.md'] = '# Runbook\n\nDay two.\n'
  f['docs/README.md'] = ['# Documentation', '', '| File | What it is for | Status | Last verified |', '|---|---|---|---|', ...rows, ''].join('\n')
  Object.assign(f, extra)
}
const ROW_GUIDE = '| [`guide.md`](./guide.md) | How to use it | active | 2026-07-30 |'
const ROW_RUNBOOK = '| [`ops/runbook.md`](./ops/runbook.md) | Day-two operations | active | 2026-07-30 |'

expect('LB-I-clean a complete catalog passes, subdirectories included',
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK]), 0)
expect('LB-I-missing a doc the index never lists reddens RS-index (that is how a docs tree rots)',
  (f) => withIndex(f, [ROW_GUIDE]), 1,
  '✗ RS-index', 'docs/ops/runbook.md')
expect('LB-I-ignore the same doc, declared in docs.index.ignore, stays green',
  (f) => {
    withIndex(f, [ROW_GUIDE])
    editConfig(f, (c) => { c.docs.index.ignore = ['docs/ops'] })
  }, 0)
expect('LB-I-rotten a catalogued link that points nowhere reddens RS-index',
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK, '| [`gone.md`](./gone.md) | Deleted last year | active | 2026-07-30 |']), 1,
  '✗ RS-index', 'sends people nowhere')
expect('LB-I-status a row with a status outside the declared vocabulary reddens RS-index',
  (f) => withIndex(f, [ROW_GUIDE.replace('| active |', '| probably fine |'), ROW_RUNBOOK]), 1,
  '✗ RS-index', "index's statuses")
// A status word is matched where it BEGINS a cell, so the two idioms every real index uses stay
// green: the word in a code span, and the word followed by a qualifier the repo wanted to write.
expect('LB-I-status-decorated a backticked status and a qualified one both match the declared word',
  (f) => withIndex(f, [ROW_GUIDE.replace('| active |', '| `active` |'), ROW_RUNBOOK.replace('| active |', '| `active` (paused) |')]), 0)
// The other half of that: matching by prefix must not degrade into matching anywhere in the row,
// or a Purpose cell that happens to use the word stands in for a status nobody set.
expect('LB-I-status-prose a status word buried in the purpose cell does NOT satisfy the row',
  (f) => withIndex(f, [ROW_GUIDE.replace('| How to use it |', '| Kept active for now |').replace('| active |', '| |'), ROW_RUNBOOK]), 1,
  '✗ RS-index', "index's statuses")
expect('LB-I-date a row with no verification date reddens RS-index',
  (f) => withIndex(f, [ROW_GUIDE.replace(' 2026-07-30 |', ' |'), ROW_RUNBOOK]), 1,
  '✗ RS-index', 'records no verification date')
expect('LB-I-date-shape a date that is not ISO reddens RS-index (the shape is checked, the age never is)',
  (f) => withIndex(f, [ROW_GUIDE.replace('2026-07-30', 'July 2026'), ROW_RUNBOOK]), 1,
  '✗ RS-index', 'YYYY-MM-DD')
// requireDate is OFF until declared, because an index that records no dates is a common and
// honest shape: defaulting it on handed every adopting repo a red check whose quickest fix was to
// invent the dates, which is the one outcome this check exists to prevent. Omitting the key has
// to be as loud as setting it false, or the gap goes unstated.
expect('LB-I-dates-default omitting requireDate leaves dates unchecked and prints the named SKIP',
  (f) => {
    withIndex(f, [ROW_GUIDE.replace(' 2026-07-30 |', ' |'), ROW_RUNBOOK.replace(' 2026-07-30 |', ' |')])
    editConfig(f, (c) => { delete c.docs.index.requireDate })
  }, 0,
  'RS-index (dates)', 'SKIP')
expect('LB-I-no-dates requireDate false opts out and SAYS SO, rather than passing quietly',
  (f) => {
    withIndex(f, [ROW_GUIDE.replace(' 2026-07-30 |', ' |'), ROW_RUNBOOK.replace(' 2026-07-30 |', ' |')])
    editConfig(f, (c) => { c.docs.index.requireDate = false })
  }, 0,
  'RS-index (dates)', 'SKIP')
expect('LB-I-no-statuses an index with no declared vocabulary prints a named SKIP for the gap',
  (f) => {
    withIndex(f, [ROW_GUIDE.replace('| active |', '| |'), ROW_RUNBOOK.replace('| active |', '| |')])
    editConfig(f, (c) => { delete c.docs.index.statuses })
  }, 0,
  'RS-index (status)', 'SKIP')
expect('LB-I-empty an index with no catalog rows at all reddens RS-index',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    f['docs/README.md'] = '# Documentation\n\nComing soon.\n'
  }, 1,
  '✗ RS-index', 'indexes nothing')
expect('LB-I-external an external link in the index is prose, not a catalog entry (stays green)',
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK, '| [the spec](https://example.com/spec) | Upstream reference | active | 2026-07-30 |']), 0)
// An index is not a docs feature. A directory of engines indexes its own files, which is what
// turns a folder README from a summary into a glossary CI can hold.
const withEngineIndex = (f, rows, extra = {}) => {
  editConfig(f, (c) => {
    c.docs = {
      ...(c.docs ?? {}),
      extra: [...new Set([...(c.docs?.extra ?? []), 'lib/README.md'])],
      indexes: [{ file: 'lib/README.md', extensions: ['.mjs'], statuses: ['active', 'superseded'], reconciled: true }],
    }
  })
  f['lib/one.mjs'] = '// one\n'
  f['lib/two.mjs'] = '// two\n'
  f['lib/README.md'] = ['# lib/', '', 'Reconciled against the code: 2026-07-30', '', '| File | What it is for | Status |', '|---|---|---|', ...rows, ''].join('\n')
  Object.assign(f, extra)
}
const ROW_ONE = '| [`one.mjs`](one.mjs) | The first engine | active |'
const ROW_TWO = '| [`two.mjs`](two.mjs) | The second engine | active |'

expect('LB-I-extensions an index over .mjs files catches a source file nobody catalogued',
  (f) => withEngineIndex(f, [ROW_ONE]), 1,
  '✗ RS-index', 'lib/two.mjs')
expect('LB-I-extensions-clean the same index, complete, passes',
  (f) => withEngineIndex(f, [ROW_ONE, ROW_TWO]), 0)
expect('LB-I-reconciled an index declaring a reconciliation date must carry one',
  (f) => {
    withEngineIndex(f, [ROW_ONE, ROW_TWO])
    f['lib/README.md'] = f['lib/README.md'].replace('Reconciled against the code: 2026-07-30\n', '')
  }, 1,
  '✗ RS-index', 'records no reconciliation date')
expect('LB-I-many two indexes are both enforced, each over its own directory',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    const docsIx = { file: 'docs/README.md', statuses: ['active', 'superseded'], requireDate: true }
    editConfig(f, (c) => {
      delete c.docs.index
      c.docs.extra = [...new Set([...(c.docs.extra ?? []), 'docs/README.md', 'lib/README.md'])]
      c.docs.indexes = [docsIx, { file: 'lib/README.md', extensions: ['.mjs'], statuses: ['active', 'superseded'] }]
    })
    f['lib/one.mjs'] = '// one\n'
    f['lib/README.md'] = '# lib/\n\n| File | What it is for | Status |\n|---|---|---|\n'
  }, 1,
  '✗ RS-index', 'carries no catalog rows')

// ── the structural properties a hand audit had to check, now the lint's job ──
// Every rule below was verified by hand on a real target and held by nothing. An index can be
// green and still be ambiguous (the same file described twice), wrong about its own scope (a row
// reaching into another directory), or unparseable in a way that reports a correct row as broken.
expect('LB-I-duplicate the same file catalogued twice reddens, instead of one row silently winning',
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK, '| [`guide.md`](./guide.md) | A second, different description | superseded | 2026-07-30 |']), 1,
  '✗ RS-index', 'more than once', 'no way to tell which one is authoritative')
expect('LB-I-escaping a row pointing outside the indexed directory reddens (the root-relative mistake)',
  // `../CONTRIBUTING.md` resolves clean out of docs/. Note what does NOT work as a probe here:
  // `docs/guide.md` written from inside docs/ resolves to docs/docs/guide.md, which is still
  // inside the directory and fails as rot instead. Containment and resolution are different rules
  // and this case has to trip the one it names.
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK, '| [`../CONTRIBUTING.md`](../CONTRIBUTING.md) | Reaches into another directory | active | 2026-07-30 |']), 1,
  '✗ RS-index', 'pointing outside', 'relative to the INDEX, not to the repo root')
expect('LB-I-escaped-pipe a literal pipe inside a cell does not tear the row into pieces',
  // The description carries `\|`, which is the markdown way to write a pipe. Split naively it
  // becomes two cells, the status lands in the wrong column, and a correct row fails.
  (f) => withIndex(f, ['| [`guide.md`](./guide.md) | Reads a \\| b and picks one | active | 2026-07-30 |', ROW_RUNBOOK]), 0,
  '✓ RS-index')
expect('LB-I-angle-destination a link destination in angle brackets is a row, not prose',
  // CommonMark's only spelling for a path containing a space. Missed, the row is invisible and
  // the file it links is then reported as uncatalogued, which is a confusing way to be wrong.
  (f) => withIndex(f, [ROW_RUNBOOK], { 'docs/two words.md': '# Two words\n\nA page.\n' }),
  1, '✗ RS-index', 'two words.md')
expect('LB-I-angle-destination-clean and that same row, written in angle brackets, satisfies coverage',
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK, '| [`two words.md`](<two words.md>) | A page whose name has a space | active | 2026-07-30 |'],
    { 'docs/two words.md': '# Two words\n\nA page.\n' }), 0,
  '✓ RS-index')
expect('LB-I-order rows out of ascending path order redden once the index declares ordered',
  (f) => {
    withIndex(f, [ROW_RUNBOOK, ROW_GUIDE])
    editConfig(f, (c) => { c.docs.index.ordered = true })
  }, 1,
  '✗ RS-index', 'out of ascending path order')
expect('LB-I-order-default order is unchecked until declared, and the skip says so',
  (f) => withIndex(f, [ROW_RUNBOOK, ROW_GUIDE]), 0,
  '– RS-index (order)', 'rewrite rather than a diff')
expect('LB-I-boundary a declared child index bounds its parent, with no hand-written ignore',
  // Before this was derived from the declarations, the parent had to list every file under the
  // child as well, or hand-write an `ignore` entry saying what the config already implied.
  (f) => {
    withIndex(f, [ROW_GUIDE])
    editConfig(f, (c) => {
      delete c.docs.index
      c.docs.extra = [...new Set([...(c.docs.extra ?? []), 'docs/README.md', 'docs/ops/README.md'])]
      c.docs.indexes = [
        { file: 'docs/README.md', statuses: ['active', 'superseded'], requireDate: true },
        { file: 'docs/ops/README.md', statuses: ['active'], requireDate: true },
      ]
    })
    f['docs/ops/README.md'] = ['# ops/', '', '| File | What it is for | Status | Last verified |', '|---|---|---|---|',
      '| [`runbook.md`](runbook.md) | Day-two operations | active | 2026-07-30 |', ''].join('\n')
  }, 0,
  '✓ RS-index docs/README.md', '✓ RS-index docs/ops/README.md')
// ─── ownership, per file rather than per directory ───────────────────────────────────────
// A declared child used to bound its parent at the whole child DIRECTORY, which threw away the
// child's own declaration. Every case below was green before that changed, including one where a
// file could be added to the tree and catalogued by nobody.
const withNested = (f, { parentExt = ['.md'], childExt = ['.md'], childScope, parentRows = [], childRows = [] } = {}) => {
  editConfig(f, (c) => {
    c.docs = {
      ...(c.docs ?? {}),
      extra: [...new Set([...(c.docs?.extra ?? []), 'docs/README.md', 'docs/ops/README.md'])],
      indexes: [
        { file: 'docs/README.md', extensions: parentExt, statuses: ['active'], requireDate: true },
        { file: 'docs/ops/README.md', extensions: childExt, ...(childScope ? { scope: childScope } : {}), statuses: ['active'], requireDate: true },
      ],
    }
    delete c.docs.index
  })
  f['docs/guide.md'] = '# Guide\n\nHow to use it.\n'
  f['docs/ops/runbook.md'] = '# Runbook\n\nDay two.\n'
  f['docs/README.md'] = ['# Documentation', '', '| File | What it is for | Status | Last verified |', '|---|---|---|---|', ...parentRows, ''].join('\n')
  f['docs/ops/README.md'] = ['# ops/', '', '| File | What it is for | Status | Last verified |', '|---|---|---|---|', ...childRows, ''].join('\n')
}
const ROW_GUIDE_P = '| [`guide.md`](./guide.md) | How to use it | active | 2026-07-30 |'
const ROW_RUNBOOK_C = '| [`runbook.md`](./runbook.md) | Day-two operations | active | 2026-07-30 |'

expect('LB-I-crossext a file the child index does not speak for is still owed to the parent',
  // THE silent hole. The parent speaks for .json anywhere under docs/, the child speaks only for
  // .md, and docs/ops/settings.json belonged to neither. Adding it left both tables, and the whole
  // gate, green: a coverage check reporting success over a file it had stopped looking at.
  (f) => {
    withNested(f, { parentExt: ['.md', '.json'], parentRows: [ROW_GUIDE_P], childRows: [ROW_RUNBOOK_C] })
    f['docs/ops/settings.json'] = '{ "nested": true }\n'
  }, 1,
  '✗ RS-index docs/README.md', 'docs/ops/settings.json')
expect('LB-I-crossindex one file catalogued by two indexes is a refusal, not two opinions',
  (f) => withNested(f, {
    parentRows: [ROW_GUIDE_P, '| [`ops/runbook.md`](./ops/runbook.md) | The same file, described twice | active | 2026-07-30 |'],
    childRows: [ROW_RUNBOOK_C],
  }), 1,
  '✗ RS-index no file is catalogued by two indexes', 'docs/ops/runbook.md')
expect('LB-I-star the "*" selector demands every kept file, extensionless ones included',
  // An extension list can never reach a Dockerfile, so a repo that wanted a directory completely
  // covered had no way to ask for it.
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.index.extensions = ['*'] })
    f['docs/Dockerfile'] = 'FROM scratch\n'
  }, 1,
  '✗ RS-index', 'docs/Dockerfile')
expect('LB-I-unowned a file no declaration speaks for is NAMED in a skip, never counted as covered',
  // Deliberately not a failure: a repo indexing its markdown and not its images has said what it
  // wanted. What it must never be is silent, because "no missing rows" over a set nobody chose
  // reads exactly like coverage.
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    f['docs/diagram.svg'] = '<svg xmlns="http://www.w3.org/2000/svg"></svg>\n'
  }, 0,
  '– RS-index (unowned)', 'docs/diagram.svg')
// ── strict ownership: the mode in which the pillar's promise is a check ────────────────────
// `declared` checks what a declaration reaches, and names the rest in a skip. That is honest and
// it is not the north star: a directory indexed for .mjs could gain a Dockerfile, and a whole new
// top-level directory of source could appear, with committed CI green through both. `strict` is
// the opt-in contract that makes "a file added tomorrow reddens the build" a sentence this
// toolkit keeps.
expect('LB-I-strict an unowned file is a FAILURE once ownership is strict, not a skip',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.ownership = 'strict' })
    f['docs/diagram.svg'] = '<svg xmlns="http://www.w3.org/2000/svg"></svg>\n'
  }, 1,
  '✗ RS-index (ownership)', 'docs/diagram.svg', 'is "strict"')
// The base fixture keeps src/ and data/, which no index speaks for. Under strict they are
// failures until somebody answers for them, which is the rule working rather than around it, so
// every case below that expects green answers them the way a real adopter would.
const BASE_DECLINES = [
  { dir: 'src', why: 'fixture payload, described by the tests that use it' },
  { dir: 'data', why: 'fixture payload, as above' },
  { dir: 'acceptance', why: 'the committed lint, which the standard ships rather than describes' },
]
expect('LB-I-strict-answered and an ignore entry closes it, so strict is a contract a repo can meet',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => {
      c.docs.ownership = 'strict'
      c.docs.index.ignore = ['docs/diagram.svg']
      c.docs.declined = BASE_DECLINES
    })
    f['docs/diagram.svg'] = '<svg xmlns="http://www.w3.org/2000/svg"></svg>\n'
  }, 0,
  '✓ RS-index (ownership)')
// The hole this closes is the one the gate could not see AT ALL. The unowned scan is scoped to
// what sits inside a declared index's directory, so a new top-level directory of kept source was
// invisible here while the planner exited 1 on it.
expect('LB-I-undecided-dir a directory nobody has decided about is NAMED, where it used to be invisible',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    f['brandnew/thing.mjs'] = '// nobody has spoken for this directory\n'
  }, 0,
  '– RS-index (undecided directories)', 'brandnew')
expect('LB-I-undecided-dir-strict and under strict ownership it reddens the build',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.ownership = 'strict' })
    f['brandnew/thing.mjs'] = '// nobody has spoken for this directory\n'
  }, 1,
  '✗ RS-index (ownership)', 'brandnew')
expect('LB-I-undecided-dir-declined a recorded decline answers the directory, in either mode',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => {
      c.docs.ownership = 'strict'
      c.docs.declined = [...BASE_DECLINES, { dir: 'brandnew', why: 'a spike, deleted next week' }]
    })
    f['brandnew/thing.mjs'] = '// answered\n'
  }, 0,
  '✓ RS-index (ownership)')
expect('LB-C-ownership an ownership mode outside the pair is a config refusal',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.ownership = 'total' })
  }, 2,
  '"docs.ownership" must be one of')

// ── the path contract: a configured path that leaves the repo ──────────────────────────────
// Both engines accepted `../outside/README.md`, read a sibling directory, and reported a PASS: a
// green verdict earned by describing a tree neither of them governs.
expect('LB-C-escape an index declared outside the repo is a config refusal, not a green pass',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => {
      c.docs.index.file = '../outside/README.md'
      c.docs.extra = [...new Set([...(c.docs.extra ?? []), '../outside/README.md'])]
    })
  }, 2,
  'must be a repo-relative path that stays inside this repo')
expect('LB-C-escape-ignore the same contract holds for an ignore entry',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.index.ignore = ['../outside'] })
  }, 2,
  'must be a repo-relative path that stays inside this repo')
expect('LB-C-escape-declined and for a declined directory',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.declined = [{ dir: '/etc', why: 'absolute, and not this repo' }] })
  }, 2,
  'must be a repo-relative path that stays inside this repo')
expect('LB-C-declined-file a decline naming a FILE is refused: that is an ignore entry in disguise',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.declined = [{ dir: 'docs/guide.md', why: 'a file, not a directory' }] })
  }, 2,
  'which is a file rather than a directory')

// ── a date with the shape of a date and no day behind it ───────────────────────────────────
expect('LB-I-date-invalid a row dated 2026-99-99 records no date at all',
  (f) => withIndex(f, [ROW_GUIDE.replace('2026-07-30', '2026-99-99'), ROW_RUNBOOK]), 1,
  '✗ RS-index', 'records no verification date')
expect('LB-I-reconciled-invalid and a reconciliation line dated February 30th is not a freshness signal',
  (f) => {
    withEngineIndex(f, [ROW_ONE, ROW_TWO])
    f['lib/README.md'] = f['lib/README.md'].replace('2026-07-30', '2026-02-30')
  }, 1,
  '✗ RS-index', 'names no day')

expect('LB-I-malformed a link that never closes renders as prose, so it is not a catalog row',
  (f) => withIndex(f, [ROW_GUIDE, '| [`ops/runbook.md`](./ops/runbook.md | Day-two operations | active | 2026-07-30 |']), 1,
  '✗ RS-index', 'never closes')
expect('LB-I-undecodable a link target that is not valid percent-encoding is a bad row, not a crash',
  // decodeURI throws on `100%.md`, and uncaught it took the whole run down with a decoder stack
  // trace where a diagnosis belonged.
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK, '| [`100%.md`](./100%.md) | An odd filename | active | 2026-07-30 |'])
    f['docs/100%.md'] = '# odd\n'
  }, 1,
  '✗ RS-index', 'percent-encoding')
expect('LB-I-retain a recorded placement decision is printed, so an answer never looks like an oversight',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.index.retain = 'the release notes link this path by name' })
  }, 0,
  '– RS-index (placement)', 'the release notes link this path by name')
expect('LB-C-retain-why a placement decision with no reason is refused, like every other recorded no',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.index.retain = true })
  }, 2,
  '"docs.index.retain" must be the reason')
expect('LB-I-declined-no-indexes a recorded decline is printed even when the repo declares no index',
  // The one shape where every recorded answer went unmentioned: a repo that turned every
  // directory down declares no index at all, so the whole reporting branch was skipped.
  (f) => editConfig(f, (c) => { c.docs = { ...(c.docs ?? {}), declined: [{ dir: 'src', why: 'three build scripts nobody browses' }] } }), 0,
  '– RS-index (declined) src/', 'three build scripts nobody browses')

expect('LB-C-index-same-dir two catalogs of one directory is a config refusal, not a coverage race',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => {
      delete c.docs.index
      c.docs.extra = [...new Set([...(c.docs.extra ?? []), 'docs/README.md', 'docs/INDEX.md'])]
      c.docs.indexes = [
        { file: 'docs/README.md', statuses: ['active'], requireDate: true },
        { file: 'docs/INDEX.md', statuses: ['active'], requireDate: true },
      ]
    })
    f['docs/INDEX.md'] = '# Documentation\n\n| File | What it is for | Status | Last verified |\n|---|---|---|---|\n'
  }, 2,
  'both declare an index for docs/', 'neither is authoritative')
// A CONFIG refusal (exit 2) rather than doc drift (exit 1), and the class is the point: the fix
// is an edit to .repo-standard.json, and this lint's two failure classes exist to tell the
// operator which file to open. It asserted exit 1 while the planner exited 2 on the same config,
// which is the last exit-class divergence the exhaustive differential table in
// test-index-plan.mjs found between the two engines.
expect('LB-C-index-ungoverned an index no prose sweep reaches is a config refusal, because it is the page most likely to rot',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.extra = (c.docs.extra ?? []).filter((p) => p !== 'docs/README.md') })
  }, 2,
  '✗ RS-config', 'no prose sweep governs', 'docs.extra')
expect('LB-C-declined-no-reason a recorded no with no reason is a config refusal',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.declined = [{ dir: 'lib' }] })
    f['lib/thing.mjs'] = '// thing\n'
  }, 2,
  'must say why', 'indistinguishable from an oversight')
expect('LB-C-declined-and-declared a directory cannot both keep a catalog and have refused one',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.declined = [{ dir: 'docs', why: 'changed our mind twice' }] })
  }, 2,
  'cannot both keep a catalog and have refused one')
expect('LB-I-declined a recorded no is printed as a named skip, never left silent',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.declined = [{ dir: 'lib', why: 'two build scripts nobody browses' }] })
    f['lib/thing.mjs'] = '// thing\n'
  }, 0,
  '– RS-index (declined) lib/', 'two build scripts nobody browses')

// The vocabulary is canon so two governed repos stay comparable. A repo keeps its own words on
// the page by mapping them, which is a declaration rather than a rewrite of its documents.
expect('LB-C-index-foreign a status the canon does not contain exits 2 and hands back the aliases block',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.index.statuses = ['active', 'HONEST-ARTIFACT'] })
  }, 2,
  'which the canon does not contain', '"aliases"')
// Case is presentation, not vocabulary. A table written in caps is using the canon in its own
// register, and making that a migration would be the tool bending a page to suit a comparison.
expect('LB-I-canon-case the canon words in the page\'s own case need no alias at all',
  (f) => {
    withIndex(f, [ROW_GUIDE.replace('| active |', '| `ACTIVE` |'), ROW_RUNBOOK.replace('| active |', '| `SUPERSEDED` (kept for the link) |')])
    editConfig(f, (c) => { c.docs.index.statuses = ['ACTIVE', 'SUPERSEDED'] })
  }, 0)
expect('LB-I-alias a genuinely different word keeps its place on the page by mapping onto the canon',
  (f) => {
    withIndex(f, [ROW_GUIDE.replace('| active |', '| `HONEST-ARTIFACT` |'), ROW_RUNBOOK.replace('| active |', '| `ACTIVE` (paused) |')])
    editConfig(f, (c) => {
      c.docs.index.statuses = ['HONEST-ARTIFACT', 'ACTIVE']
      c.docs.index.aliases = { 'HONEST-ARTIFACT': 'reference' }
    })
  }, 0)
expect('LB-C-index-alias-target an alias pointing at a word the canon does not have exits 2',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    editConfig(f, (c) => { c.docs.index.aliases = { REFERENCE: 'archived' } })
  }, 2,
  'is not one of the canon statuses')
expect('LB-C-index-both declaring index and indexes at once exits 2',
  (f) => editConfig(f, (c) => { c.docs = { ...(c.docs ?? {}), index: { file: 'docs/README.md' }, indexes: [] } }), 2,
  'not both')
expect('LB-S-index-off no index declared prints a named SKIP, never a silent pass',
  null, 0,
  'RS-index SKIP', 'no index declared')
expect('LB-C-index-shape a non-object docs.index exits 2',
  (f) => editConfig(f, (c) => { c.docs = { ...(c.docs ?? {}), index: 'docs/README.md' } }), 2,
  '"docs.index" must be an object')
expect('LB-C-index-root an index outside a directory exits 2 (it catalogues the tree it lives in)',
  (f) => editConfig(f, (c) => { c.docs = { ...(c.docs ?? {}), index: { file: 'INDEX.md' } } }), 2,
  'must live inside the directory it catalogues')

expect('LB-M-shadow-manifest the config-declared manifest doc is governed vocabulary too — a .github/ duplicate reddens RS-shadow',
  (f) => { f['.github/MANIFEST.md'] = '# Manifest\n\nStale copy.\n' }, 1,
  '✗ RS-shadow', '.github/MANIFEST.md shadows MANIFEST.md')

// ── the hardenings from the adversarial pass, each locked so the bypass can never reopen ──
expect('LB-M-voice-spaced a hyphenated ban written with a space ("world class") still reddens RS-voice',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it, a world class experience.') }, 1,
  '✗ RS-voice', 'world-class')
expect('LB-M-voice-contraction apostrophes in prose cannot swallow a banned word ("It\'s simply ... you\'d")',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', "It's simply the cleanest setup you'd want.") }, 1,
  '✗ RS-voice', 'simply')
expect('LB-M-changelog-h4 an ad-hoc H4 subsection under a version reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('### Added', '#### Breaking Changes\n\n- x\n\n### Added') }, 1,
  '✗ RS-changelog', 'only ### category subsections')
// ── the six rules a mutation audit found with NO red-path case: each is deletable with the
// ── whole suite green until these exist, and each is the ONLY thing catching its own drift.
expect('LB-M-changelog-title a CHANGELOG titled something else ("# Release Notes") reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('# Changelog', '# Release Notes') }, 1,
  '✗ RS-changelog', 'must open with a top-level')
expect('LB-M-changelog-cite a CHANGELOG that never names the Keep a Changelog format reddens RS-changelog',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).', 'Format: some format.') }, 1,
  '✗ RS-changelog', 'must name the Keep a Changelog format')
expect('LB-M-conventions-decoy relocating CONVENTIONS while a rotten root CONVENTIONS.md remains reddens RS-conventions',
  (f) => {
    editConfig(f, (c) => { c.docs = { conventions: 'docs/CONVENTIONS.md' } })
    f['docs/CONVENTIONS.md'] = f['CONVENTIONS.md']          // the pristine configured copy
    f['CONVENTIONS.md'] = '# Conventions\n\n## 99. Rotten\n\nThe file contributors actually open.\n'
  }, 1,
  '✗ RS-conventions', 'one conventions doc only')
expect('LB-M-reflexivity-usage CONVENTIONS dropping a required README section ("Usage") reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('Install, Usage, Contributing,', 'Install, Contributing,') }, 1,
  '✗ RS-reflexivity', 'required README section "Usage"')
expect('LB-M-reflexivity-kac CONVENTIONS dropping the Keep a Changelog citation reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('CHANGELOG follows Keep a Changelog (keepachangelog.com):', 'CHANGELOG uses:') }, 1,
  '✗ RS-reflexivity', 'must cite the Keep a Changelog standard')
expect('LB-M-reflexivity-sr CONVENTIONS dropping the standard-readme citation reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('README follows standard-readme:', 'README has:') }, 1,
  '✗ RS-reflexivity', 'must cite the standard-readme standard')

expect('LB-M-changelog-decoy relocating the changelog while a root CHANGELOG.md still exists reddens RS-changelog',
  (f) => {
    editConfig(f, (c) => { c.docs = { changelog: 'docs/CHANGELOG.md' } })
    f['docs/CHANGELOG.md'] = f['CHANGELOG.md'] // pristine copy at the configured path
    f['CHANGELOG.md'] = '# Changelog\n\nrotten decoy shadow\n' // the file contributors would open
  }, 1,
  '✗ RS-changelog', 'shadow')
expect('LB-M-readme-setext a setext (=) heading reddens RS-readme (ATX only, so the lint sees what renders)',
  (f) => { f['README.md'] = f['README.md'].replace('## License', 'Sponsors\n=======\n\nBuy now!\n\n## License') }, 1,
  '✗ RS-readme', 'setext')
expect('LB-M-readme-empty-license a content-free License section reddens RS-readme',
  (f) => { f['README.md'] = f['README.md'].replace('## License\n\nMIT.\n', '## License\n') }, 1,
  '✗ RS-readme', 'License section is empty')
expect('LB-M-todos-case a case/space variant ("todo (scaffold)") still reddens RS-todos',
  (f) => { f['README.md'] = f['README.md'].replace('PRs welcome.', 'PRs welcome. <!-- todo (scaffold): finish -->') }, 1,
  '✗ RS-todos')
expect('LB-S-manifest-prose a "| NEW |" inside a prose sentence does not count as an inventory row (stays green)',
  (f) => { f['MANIFEST.md'] = f['MANIFEST.md'].replace('Totals:', 'A file still tracked as | NEW | in the migration sheet.\n\nTotals:') }, 0)
expect('LB-M-manifest-prose the old bypass — totals inflated to absorb a prose "| NEW |" — now reddens RS-manifest',
  (f) => { f['MANIFEST.md'] = f['MANIFEST.md'].replace('Totals:', 'A file still tracked as | NEW | in the migration sheet.\n\nTotals:').replace('**1 UNCHANGED · 2 NEW · 3 total.**', '**1 UNCHANGED · 3 NEW · 4 total.**') }, 1,
  '✗ RS-manifest', 'Totals says 3 NEW but the table has 2')

// ──────────────────────────────────────────────────────── exemptions must NOT fire
expect('LB-S-todos-named NAMING the TODO(scaffold) marker in backticks stays green (a mention is not an unfinished scaffold)',
  (f) => { f['README.md'] = f['README.md'].replace('PRs welcome.', 'PRs welcome. The scaffolder resolves every `TODO(scaffold)` marker.') }, 0)
expect('LB-S-quoted naming a banned word in quotes stays green (a mention is not marketing)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. We never write "seamless".') }, 0)
expect('LB-S-fenced a banned word inside a fenced code block stays green',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it.\n\n```\nexample: seamless\n```') }, 0)

// ── real-world markdown the lint must NOT false-fail (each was a confirmed review finding) ──
expect('LB-S-bom a UTF-8 BOM on the meta docs does not fail a compliant repo',
  (f) => { for (const d of ['README.md', 'CHANGELOG.md', 'CONVENTIONS.md', 'SECURITY.md']) f[d] = '﻿' + f[d] }, 0)
expect('LB-S-tilde-fence a CommonMark ~~~ fence hides its contents from the prose checks',
  (f) => { f['README.md'] = f['README.md'].replace('This repo has 3 widget', '~~~text\nWIDGET\n======\nRun simply with --help\n~~~\n\nThis repo has 3 widget') }, 0)
expect('LB-S-html-banner the centered `<p align="center">` banner idiom does not hide the tagline',
  (f) => { f['README.md'] = f['README.md'].replace('**A test fixture repo', '<p align="center">\n  <img src="logo.png" alt="fixture">\n</p>\n\n**A test fixture repo') }, 0)
expect('LB-S-html-comment an "=" rule inside an HTML comment is not a setext heading',
  (f) => { f['README.md'] = f['README.md'].replace('## Contributing', '<!--\nmaintainer note\n==============\nkeep in sync\n-->\n\n## Contributing') }, 0)
expect('LB-S-manifest-padded a column-aligned manifest table reconciles exactly like a compact one',
  (f) => { f['MANIFEST.md'] = f['MANIFEST.md'].replace('| `a` | UNCHANGED | x |', '| `a` | UNCHANGED | x |').replace(/\| `b` \| NEW \| x \|/, '| `b` | NEW       | x |').replace(/\| `c` \| NEW \| x \|/, '| `c` | NEW       | x |') }, 0)
expect('LB-M-manifest-padded-drift a padded table with a WRONG Totals line still reddens (the fix did not blind the check)',
  (f) => { f['MANIFEST.md'] = f['MANIFEST.md'].replace(/\| `b` \| NEW \| x \|/, '| `b` | NEW       | x |').replace('**1 UNCHANGED · 2 NEW · 3 total.**', '**1 UNCHANGED · 5 NEW · 6 total.**') }, 1,
  '✗ RS-manifest', 'the table has 2')
expect('LB-M-changelog-prerelease-chain an out-of-order rc chain (rc.9 above rc.1) reddens RS-changelog (semver §11)',
  (f) => {
    f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('## [1.2.3] — 2026-01-01', '## [1.2.3-rc.1] - 2025-11-01\n\n### Added\n\n- first rc\n\n## [1.2.3-rc.9] - 2025-12-01\n\n### Added\n\n- ninth rc\n\n## [1.2.3] — 2026-01-01')
  }, 1,
  '✗ RS-changelog', 'must descend')

// ────────────────────────────────────────── RS-prose: the enterprise writing profile
expect('LB-M-prose-emdash an em dash in governed prose reddens RS-prose',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it — then run it.') }, 1,
  '✗ RS-prose', 'uses an em dash')
expect('LB-M-prose-escape the &mdash; escape reddens RS-prose (it renders as an em dash)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it &mdash; then run it.') }, 1,
  '✗ RS-prose', 'em dash escape')
expect('LB-M-prose-numeric-escape the numeric &#8212; escape reddens RS-prose too',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it &#8212; then run it.') }, 1,
  '✗ RS-prose', 'em dash escape')
expect('LB-M-prose-endash a SPACED en dash reddens RS-prose (an em dash wearing a hat)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it – then run it.') }, 1,
  '✗ RS-prose', 'spaced en dash')
expect('LB-S-prose-range an en dash inside a numeric range stays green (that is what it is for)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. Supported 2019–2024.') }, 0)
expect('LB-M-prose-filler a single-word filler term reddens RS-prose',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Utilize the clone command.') }, 1,
  '✗ RS-prose', 'banned filler "utilize"')
expect('LB-M-prose-multiword a multi-word filler term reddens RS-prose (whitespace-tolerant)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it in  order\nto build.') }, 1,
  '✗ RS-prose', 'banned filler "in order to"')
expect('LB-S-prose-mention naming a banned term in backticks stays green (a mention is not a use)',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. Never write `utilize` here.') }, 0)
expect('LB-S-prose-fence a banned term inside a fenced block stays green',
  (f) => { f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it.\n\n```\nutilize --help\n```') }, 0)
// The history rule is load-bearing: adopting the profile must never demand that a repo rewrite
// what it already shipped, so the scan stops at the first dated version.
expect('LB-S-prose-history an em dash inside a DATED changelog section stays green (released history is a record)',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('- Initial release with 2 sprockets.', '- Initial release with 2 sprockets — a wide range of them, in order to ship.') }, 0)
expect('LB-M-prose-unreleased the same prose ABOVE the first dated version reddens (that part is live)',
  (f) => { f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('- A sprocket pipeline', '- A pipeline — utilized daily; a sprocket pipeline') }, 1,
  '✗ RS-prose')
expect('LB-M-prose-stable-doc the profile reaches the stable meta docs, not just the front matter',
  (f) => { f['SECURITY.md'] = '# Security Policy\n\nReport privately — we respond fast.\n' }, 1,
  '✗ RS-prose', 'SECURITY.md')
expect('LB-M-prose-markdown-scan scan "markdown" reaches an ungoverned .md file',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'markdown' } })
    f['notes/design.md'] = '# Design\n\nWe will delve into the tradeoffs later.\n'
  }, 1,
  '✗ RS-prose', 'notes/design.md')
// The reach is deliberately asymmetric: dashes go as far as prose.scan says, filler stops at
// markdown. Both halves are locked, because the asymmetry is the kind of thing a later reader
// "tidies up" into consistency and thereby breaks.
expect('LB-M-prose-all-dash scan "all" reaches a dash in SOURCE, not just in markdown',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'all' } })
    f['src/tool.mjs'] = '// a comment — with an em dash\nexport const x = 1\n'
  }, 1,
  '✗ RS-prose', 'src/tool.mjs')
expect('LB-S-prose-all-filler scan "all" does NOT flag filler in source (identifiers are not register)',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'all' } })
    // Every one of these is a false positive waiting to happen: an identifier, a data value,
    // and the declaration of the ban list itself. A rule that fires here gets switched off.
    f['src/tool.mjs'] = 'const leverageRatio = 1\nfunction utilizeCache() {}\nconst BANNED = ["delve", "in order to"]\n'
  }, 0)
expect('LB-M-prose-all-markdown-filler ...while the same terms in markdown prose still redden',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'all' } })
    f['notes/x.md'] = '# Notes\n\nWe will delve into it later.\n'
  }, 1,
  '✗ RS-prose', 'notes/x.md')
expect('LB-S-prose-exempt an exempt path is skipped and the reason prints on every run',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'markdown', exempt: [{ path: 'vendor', why: 'third-party text reproduced verbatim' }] } })
    f['vendor/notice.md'] = '# Notice\n\nUpstream text — reproduced verbatim.\n'
  }, 0,
  'prose exemption active: vendor')
expect('LB-M-prose-exempt-narrow an exemption covers only its own path, never the rest of the tree',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'markdown', exempt: [{ path: 'vendor', why: 'third-party text reproduced verbatim' }] } })
    f['vendor/notice.md'] = '# Notice\n\nUpstream text — reproduced verbatim.\n'
    f['notes/design.md'] = '# Design\n\nAlso an em dash — here.\n'
  }, 1,
  '✗ RS-prose', 'notes/design.md')
expect('LB-S-prose-allow an allowance lifts ONE filler term and prints loudly',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', allow: [{ term: 'leverage', why: 'this repo means the financial noun' }] } })
    f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. Leverage ratios are computed here.')
  }, 0,
  'prose allowance active: "leverage"')
expect('LB-M-prose-allow-narrow an allowance lifts only its own term, not the rest of the list',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', allow: [{ term: 'leverage', why: 'this repo means the financial noun' }] } })
    f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. Leverage ratios, and utilize the runner.')
  }, 1,
  '✗ RS-prose', 'banned filler "utilize"')
expect('LB-M-prose-extra a config-extended filler term reddens RS-prose',
  (f) => {
    editConfig(f, (c) => { c.prose = { profile: 'enterprise', extraBanned: ['robust'] } })
    f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('or `state-of-the-art`.', 'or `state-of-the-art`. Also banned here: `robust`.')
    f['README.md'] = f['README.md'].replace('Clone it.', 'Clone it. A robust pipeline.')
  }, 1,
  '✗ RS-prose', 'banned filler "robust"')
expect('LB-M-prose-reflexivity CONVENTIONS dropping a banned filler term reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('`needless to say`, ', '') }, 1,
  '✗ RS-reflexivity', 'needless to say')
expect('LB-M-prose-reflexivity-dash CONVENTIONS dropping the em dash rule reddens RS-reflexivity',
  (f) => { f['CONVENTIONS.md'] = f['CONVENTIONS.md'].replace('no em dash in any form, and none of', 'none of') }, 1,
  '✗ RS-reflexivity', 'must document the em dash rule')
expect('LB-S-prose-off no profile declared prints a named SKIP, never a silent pass',
  (f) => editConfig(f, (c) => { delete c.prose }), 0,
  'RS-prose SKIP', 'no writing profile declared')
expect('LB-C-prose-profile an unknown profile name exits 2',
  (f) => editConfig(f, (c) => { c.prose = { profile: 'chatty' } }), 2,
  '"prose.profile" must be one of enterprise')
expect('LB-C-prose-scan an unknown scan reach exits 2',
  (f) => editConfig(f, (c) => { c.prose = { profile: 'enterprise', scan: 'everything' } }), 2,
  '"prose.scan" must be one of')
expect('LB-C-prose-allow-unknown an allowance for a term the profile does not ban exits 2',
  (f) => editConfig(f, (c) => { c.prose = { profile: 'enterprise', allow: [{ term: 'sparkly', why: 'because' }] } }), 2,
  'is not one of the profile\'s filler terms')
expect('LB-C-prose-allow-nodash the dash rules cannot be allowed away',
  (f) => editConfig(f, (c) => { c.prose = { profile: 'enterprise', allow: [{ term: 'em dash', why: 'we like them' }] } }), 2,
  'The dash rules can never be allowed away')
expect('LB-C-prose-exempt-noreason an exemption without a stated reason exits 2',
  (f) => editConfig(f, (c) => { c.prose = { profile: 'enterprise', exempt: [{ path: 'vendor' }] } }), 2,
  '"prose.exempt[0]" must be')

// ──────────────────────────────────────────────── RS-ignore: the trust ruleset
expect('LB-M-ignore-missing no ignore file at all reddens RS-ignore',
  (f) => { f['.gitignore'] = null }, 1,
  '✗ RS-ignore', 'cannot stop a .env from being committed')
expect('LB-M-ignore-bare a bare ".env" rule leaves every variant open and reddens RS-ignore',
  (f) => { f['.gitignore'] = '.env\nnode_modules/\n' }, 1,
  '✗ RS-ignore', 'does not ignore .env.local')
expect('LB-S-ignore-star a single ".env*" rule covers the whole family (stays green)',
  (f) => { f['.gitignore'] = '.env*\n!.env.example\nnode_modules/\n' }, 0)
expect('LB-M-ignore-negation a negation that re-exposes a real .env variant reddens RS-ignore',
  (f) => { f['.gitignore'] += '!.env.production\n' }, 1,
  '✗ RS-ignore', 're-exposes .env.production through the negation')
expect('LB-S-ignore-example the example file may be negated: that is the whole point of the pair',
  (f) => { f['.gitignore'] = '.env\n.env.*\n!.env.sample\nnode_modules/\n' }, 0)
expect('LB-S-ignore-allow-example a configured extra example name is accepted and prints loudly',
  (f) => {
    editConfig(f, (c) => { c.ignore = { allowExamples: ['.env.dist'] } })
    f['.gitignore'] = '.env\n.env.*\n!.env.dist\nnode_modules/\n'
  }, 0,
  'ignore allowance active: .env.dist')
expect('LB-M-ignore-generated a declared generated path that is not ignored reddens RS-ignore',
  (f) => editConfig(f, (c) => { c.ignore = { generated: ['dist/'] } }), 1,
  '✗ RS-ignore', 'declared generated path "dist/"')
expect('LB-S-ignore-generated-ok the same path, actually ignored, stays green',
  (f) => {
    editConfig(f, (c) => { c.ignore = { generated: ['dist/'] } })
    f['.gitignore'] += 'dist/\n'
  }, 0)
expect('LB-S-ignore-generated-parent a parent-directory rule covers a nested declared path',
  (f) => {
    editConfig(f, (c) => { c.ignore = { generated: ['build/web/assets'] } })
    f['.gitignore'] += 'build/\n'
  }, 0)
expect('LB-C-ignore-example-shape an allowExamples entry that is not a .env name exits 2',
  (f) => editConfig(f, (c) => { c.ignore = { allowExamples: ['secrets.txt'] } }), 2,
  'is not a .env-family filename')
expect('LB-S-ignore-tracked-skip without git, the tracked-file leg prints a named SKIP',
  null, 0,
  'RS-ignore (tracked leg) SKIP', 'git is unavailable here')
expect('LB-S-ignore-disable a reasoned disable skips RS-ignore loudly and keeps the build green',
  (f) => {
    editConfig(f, (c) => { c.checks = { ignore: { enabled: false, why: 'ignore rules live in a shared org-level template' } } })
    f['.gitignore'] = null
  }, 0,
  'ignore is DISABLED in config', 'RS-ignore SKIP')

// ───────────────────────────────────────────────────────── config-error class (exit 2)
expect('LB-C-docs-type a non-string docs.changelog is a config error, not a crash',
  (f) => editConfig(f, (c) => { c.docs = { changelog: 5 } }), 2,
  '"docs.changelog" must be a string path', 'doc checks not run')
expect('LB-C-badglob a non-string counts glob is a config error (exit 2), not a doc failure',
  (f) => editConfig(f, (c) => { c.counts.widgets.glob = 7 }), 2,
  '"counts.widgets.glob" must be a string pattern')
expect('LB-C-badlineregex an uncompilable counts lineRegex is a config error (exit 2), not a doc failure',
  (f) => editConfig(f, (c) => { c.counts.rows.lineRegex = '^row:[' }), 2,
  'does not compile')
expect('LB-C-badrequire an uncompilable readme.requireSections entry is a config error (exit 2)',
  (f) => editConfig(f, (c) => { c.readme.requireSections = ['caveat['] }), 2,
  'does not compile')
expect('LB-C-unknown-key an unknown top-level config key exits 2 and names it (doc checks not run)',
  (f) => editConfig(f, (c) => { c.cheks = {} }), 2,
  'unknown top-level key "cheks"', 'doc checks not run')
expect('LB-C-version an unsupported config version exits 2',
  (f) => editConfig(f, (c) => { c.version = 2 }), 2,
  '"version" must be the number 1')
expect('LB-C-bare-false a bare-false check disable exits 2 (disabling demands a stated reason)',
  (f) => editConfig(f, (c) => { c.checks = { voice: false } }), 2,
  'cannot be silently weakened')
expect('LB-C-decoy pointing docs.readme at a non-rendered path exits 2 (anti-decoy)',
  (f) => editConfig(f, (c) => { c.docs = { readme: 'docs/HIDDEN.md' } }), 2,
  'paths GitHub renders')
expect('LB-C-badcount a count pattern without a capture group exits 2',
  (f) => editConfig(f, (c) => { c.counts.widgets.pattern = '\\d+ widget' }), 2,
  'needs a capture group')
expect('LB-S-scaffold a recorded scaffold provenance block is valid config (stays green)',
  (f) => editConfig(f, (c) => { c.scaffold = { pluginVersion: '0.1.0', answers: { COPYRIGHT_HOLDER: 'Acme Maintainers', LICENSE_ID: 'MIT' } } }), 0)
expect('LB-C-scaffold-shape a non-object scaffold block exits 2',
  (f) => editConfig(f, (c) => { c.scaffold = 5 }), 2,
  '"scaffold" must be an object')
expect('LB-C-scaffold-version a non-semver scaffold.pluginVersion exits 2',
  (f) => editConfig(f, (c) => { c.scaffold = { pluginVersion: 'latest' } }), 2,
  '"scaffold.pluginVersion" must be a semver string')
expect('LB-C-scaffold-key an unknown scaffold key exits 2 and names it',
  (f) => editConfig(f, (c) => { c.scaffold = { pluginVersion: '0.1.0', who: 'me' } }), 2,
  'unknown key "scaffold.who"')
expect('LB-C-scaffold-answer a non-string answer value exits 2',
  (f) => editConfig(f, (c) => { c.scaffold = { answers: { YEAR: 2026 } } }), 2,
  '"scaffold.answers.YEAR" must be a string')
expect('LB-C-scaffold-answers-shape a non-object answers block (array) exits 2',
  (f) => editConfig(f, (c) => { c.scaffold = { answers: ['MIT'] } }), 2,
  '"scaffold.answers" must be an object')
expect('LB-C-scaffold-answer-key an answers key outside the placeholder alphabet exits 2',
  (f) => editConfig(f, (c) => { c.scaffold = { answers: { 'license id': 'MIT' } } }), 2,
  'keys are template placeholder names')

// ─────────────────────────────────── RS-index: the table grammar, in both versions
// Four ways a file could look catalogued when nothing catalogued it. The fenced case is a plain
// bug and is closed under BOTH grammars; the other three are what grammar 2 exists for, and each
// is asserted twice: green under 1 (the documented, default weakness) and red under 2.
const FENCED_EXAMPLE = ['', '```', '| File | What it is for | Status | Last verified |', '|---|---|---|---|',
  '| [`ops/runbook.md`](./ops/runbook.md) | Only inside a fence | active | 2026-07-30 |', '```', ''].join('\n')
expect('LB-I-fence a row inside a code fence is an EXAMPLE, never coverage (both grammars)',
  (f) => { withIndex(f, [ROW_GUIDE]); f['docs/README.md'] += FENCED_EXAMPLE }, 1,
  '✗ RS-index', 'docs/ops/runbook.md')
expect('LB-I-fence-g2 the same, under grammar 2',
  (f) => { withIndex(f, [ROW_GUIDE]); f['docs/README.md'] += FENCED_EXAMPLE; editConfig(f, (c) => { c.docs.index.grammar = 2 }) }, 1,
  '✗ RS-index', 'docs/ops/runbook.md')
// An UNRELATED table whose rows link files and carry a status word.
const ROADMAP = ['', '## Roadmap', '', '| Item | Note | State | When |', '|---|---|---|---|',
  '| [`ops/runbook.md`](./ops/runbook.md) | planned | active | 2026-07-30 |', ''].join('\n')
expect('LB-I-g1-foreign-table grammar 1 counts an unrelated table as coverage, which is what grammar 2 is for',
  (f) => { withIndex(f, [ROW_GUIDE]); f['docs/README.md'] += ROADMAP }, 0)
expect('LB-I-g2-foreign-table grammar 2 reads only the table whose header names a file column',
  (f) => { withIndex(f, [ROW_GUIDE]); f['docs/README.md'] += ROADMAP; editConfig(f, (c) => { c.docs.index.grammar = 2 }) }, 1,
  '✗ RS-index', 'docs/ops/runbook.md')
// A DESCRIPTION cell beginning with a status word, while the status column sits empty.
const STATUS_IN_PROSE = '| [`ops/runbook.md`](./ops/runbook.md) | active maintenance, day two |  | 2026-07-30 |'
expect('LB-I-g1-status-column grammar 1 lets any cell carry the status',
  (f) => withIndex(f, [ROW_GUIDE, STATUS_IN_PROSE]), 0)
expect('LB-I-g2-status-column grammar 2 reads the status from the Status column',
  (f) => { withIndex(f, [ROW_GUIDE, STATUS_IN_PROSE]); editConfig(f, (c) => { c.docs.index.grammar = 2 }) }, 1,
  '✗ RS-index', 'the status column')
// A bare date in a column that is not the verification column.
const DATE_IN_WRONG_COLUMN = (f) => {
  withIndex(f, [])
  f['docs/README.md'] = ['# Documentation', '', '| File | What it is for | Added | Last verified |', '|---|---|---|---|',
    '| [`guide.md`](./guide.md) | How to use it | 2025-01-01 | 2026-07-30 |',
    '| [`ops/runbook.md`](./ops/runbook.md) | Day-two operations | 2025-06-01 |  |', ''].join('\n')
  editConfig(f, (c) => { c.docs.index.statuses = false })
}
expect('LB-I-g1-date-column grammar 1 lets a date in any column answer for the verification date',
  (f) => DATE_IN_WRONG_COLUMN(f), 0)
expect('LB-I-g2-date-column grammar 2 reads the date from the column whose header says when it was checked',
  (f) => { DATE_IN_WRONG_COLUMN(f); editConfig(f, (c) => { c.docs.index.grammar = 2 }) }, 1,
  '✗ RS-index', 'verification-date column')
expect('LB-I-grammar-skip grammar 1 names its own weakness on every run, so a green build never implies the stronger rule',
  (f) => withIndex(f, [ROW_GUIDE, ROW_RUNBOOK]), 0,
  'RS-index (grammar)', 'Set it to 2')
expect('LB-C-grammar-bad a grammar version that does not exist is a config refusal',
  (f) => { withIndex(f, [ROW_GUIDE, ROW_RUNBOOK]); editConfig(f, (c) => { c.docs.index.grammar = 3 }) }, 2,
  '"docs.index.grammar" must be one of 1, 2')

// ───────────────────────── RS-index (ownership): the contract, and the boundary it states
expect('LB-O-strict-zero-index strict enforces before the first index exists (it used to be nested inside "an index is declared")',
  (f) => { editConfig(f, (c) => { c.docs = { ownership: 'strict' } }); f['lib/new.mjs'] = 'export const n = 1\n' }, 1,
  '✗ RS-index (ownership)', 'has been decided about')
expect('LB-O-strict-boundary the files strict does not judge are NAMED, because a silent exclusion reads like coverage',
  (f) => {
    withIndex(f, [ROW_GUIDE, ROW_RUNBOOK])
    // Every directory this fixture keeps has to be ANSWERED, or the case measures the answer it
    // is missing instead of the boundary it is about. `acceptance` is where the harness drops its
    // own copy of the lint under test.
    editConfig(f, (c) => { c.docs.ownership = 'strict'; c.docs.declined = [{ dir: 'src', why: 'fixture data' }, { dir: 'data', why: 'fixture data' }, { dir: 'acceptance', why: 'the harness copies the lint here' }] })
    f['ROOT-UNOWNED'] = 'no declaration can reach me\n'
    f['.hidden/x.mjs'] = 'nor me\n'
  }, 0,
  'RS-index (ownership boundary)', 'ROOT-UNOWNED', '.hidden/x.mjs')
expect('LB-O-declined-quiet a repo that has never declared an index is not handed a wall of directories',
  (f) => { f['lib/new.mjs'] = 'export const n = 1\n' }, 0,
  'RS-index SKIP (no index declared')

// ──────────────────────────────────────── RS-assets: the generated identity
// A second fixture family, deliberately separate from the one above: the identity changes the
// README's H1 into a banner image link, and folding that into the base repo would entangle
// every existing README case with artwork they have nothing to do with.
const SLATE = JSON.parse(readFileSync(join(ROOT, 'payload', 'assets', 'palettes', 'slate.json'), 'utf8')).palette
const ASSET_MANIFEST = {
  version: 1,
  brand: {
    name: 'FIXTURE',
    tagline: 'A fixture repo for the identity checks',
    eyebrow: 'FIXTURE · IDENTITY',
    homepage: 'https://example.com/fixture',
    palette: SLATE,
  },
  pills: [
    { file: 'version.svg', label: 'VERSION', value: '1.2.3', scheme: 'alt', href: 'CHANGELOG.md', source: { file: 'package.json', json: 'version' } },
    // No href, deliberately: the optional case has to be in the CLEAN fixture, or the only thing
    // proven is that a pill which declares one works.
    { file: 'tests.svg', label: 'TESTS', value: 'UNIT + E2E', scheme: 'accent', source: false, why: 'a summary of two suites, not a value any one file states' },
  ],
  banners: [{ slug: 'src', dir: 'src', title: 'src/', desc: 'Application source' }],
}
// The README below the identity block. Built from readmeBlock() for the same reason the H1s are
// built from bannerH1(): a hand-typed approximation of the rule proves the typist agreed with
// themselves. Any case that edits the manifest and still expects green has to re-derive it,
// which is exactly what an operator does after touching a pill.
const ASSET_README_BODY = [
  '', '**A fixture repo for the identity checks.**', '',
  '## Install', '', 'Clone it.', '',
  '## Usage', '', 'Run it.', '',
  '## Contributing', '', 'PRs welcome.', '',
  '## License', '', 'MIT.', '',
].join('\n')
const readmeFor = (manifest) => `${readmeBlock(manifest, { assets: '.github/assets' })}\n${ASSET_README_BODY}`
const assetFiles = () => ({
  '.repo-standard.json': JSON.stringify({
    version: 1,
    readme: { requireSections: ['usage'] },
    conventions: { minSections: 2 },
    assets: { dir: '.github/assets' },
  }, null, 2) + '\n',
  '.gitignore': '.env\n.env.*\n!.env.example\n',
  'package.json': '{ "name": "fixture", "version": "1.2.3", "license": "MIT" }\n',
  'LICENSE': 'MIT License\n\nCopyright (c) 2026 fixture\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software, provided the above copyright notice and this permission notice are included.\n',
  '.github/assets/manifest.json': JSON.stringify(ASSET_MANIFEST, null, 2) + '\n',
  'README.md': readmeFor(ASSET_MANIFEST),
  'src/README.md': [
    bannerH1({ title: 'src/', desc: 'Application source', to: '../.github/assets/banners/src.svg', homepage: 'https://example.com/fixture' }), '',
    'The application source.', '',
  ].join('\n'),
  'CHANGELOG.md': '# Changelog\n\nFormat: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).\n\n## [Unreleased]\n\n## [1.2.3] - 2026-01-01\n\n### Added\n\n- First cut.\n',
  'CONVENTIONS.md': [
    '# Conventions', '',
    '## 1. Assets', '',
    'Banners and pills are generated. Edit the manifest, then run `node .github/assets/generate.mjs`',
    'from the repo root. Never hand-edit an SVG.', '',
    '## 2. Meta docs standard', '',
    'CHANGELOG follows Keep a Changelog (keepachangelog.com): only Added / Changed / Deprecated /',
    'Removed / Fixed / Security. README follows standard-readme: Install, Usage, Contributing,',
    'License last.', '',
  ].join('\n'),
  'SECURITY.md': '# Security Policy\n\nReport privately.\n',
  'CONTRIBUTING.md': '# Contributing\n\nBe kind.\n',
  'CODE_OF_CONDUCT.md': '# Code of Conduct\n\nCovenant.\n',
})

// Build, render for real through the shipped generator, THEN mutate, then run the lint. The
// mutation sees a genuinely generated tree, which is the only way a drift case means anything.
const runAssets = (mutate) => {
  const files = assetFiles()
  const tmp = mkdtempSync(join(tmpdir(), 'rs-assets-'))
  try {
    for (const [rel, content] of Object.entries(files)) {
      if (content === null) continue
      mkdirSync(join(tmp, dirname(rel)), { recursive: true })
      writeFileSync(join(tmp, rel), content)
    }
    mkdirSync(join(tmp, 'acceptance'), { recursive: true })
    writeFileSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
    copyFileSync(join(ROOT, 'payload', 'assets', 'generate.mjs'), join(tmp, '.github', 'assets', 'generate.mjs'))
    execFileSync('node', [join(tmp, '.github', 'assets', 'generate.mjs')], { cwd: tmp, encoding: 'utf8' })
    if (mutate) mutate(tmp)
    try {
      return { code: 0, out: execFileSync('node', [join(tmp, 'acceptance', 'test-repo-standard.mjs')], { encoding: 'utf8' }) }
    } catch (e) {
      return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` }
    }
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
}
const expectAssets = (name, mutate, code, ...needles) => check(name, () => {
  const r = runAssets(mutate)
  assert.equal(r.code, code, `expected exit ${code}, got ${r.code}\n--- lint output ---\n${r.out}`)
  for (const n of needles) assert.ok(r.out.includes(n), `output should contain "${n}"\n--- lint output ---\n${r.out}`)
})
const editManifest = (dir, edit) => {
  const p = join(dir, '.github', 'assets', 'manifest.json')
  const m = JSON.parse(readFileSync(p, 'utf8'))
  edit(m)
  writeFileSync(p, JSON.stringify(m, null, 2) + '\n')
}
// Re-paste the identity block from whatever the manifest now says, the way an operator does
// after editing a pill. A case that changes what the block renders and still expects green has
// to do this; a case that expects red on an earlier assertion does not, and leaving it out is
// what proves the earlier assertion is the one that fired.
const rewriteReadme = (dir) =>
  writeFileSync(join(dir, 'README.md'), readmeFor(JSON.parse(readFileSync(join(dir, '.github', 'assets', 'manifest.json'), 'utf8'))))

check('LB-A-CLEAN a freshly generated identity passes, and the unverifiable pill is named as a SKIP', () => {
  const r = runAssets(null)
  assert.equal(r.code, 0, `the generated fixture should pass\n--- lint output ---\n${r.out}`)
  assert.ok(r.out.includes('RS-assets (pill provenance)') && r.out.includes('stated, not verified'),
    `a source-less pill must print a named skip, never pass silently\n${r.out}`)
})
expectAssets('LB-A-drift a hand-edited SVG reddens RS-assets (drift)',
  (d) => {
    const p = join(d, '.github', 'assets', 'banner.svg')
    writeFileSync(p, readFileSync(p, 'utf8').replace(SLATE.accent, '#ff0000'))
  }, 1,
  '✗ RS-assets (drift)', 'differs from what the manifest renders')
expectAssets('LB-A-missing a declared asset that was never rendered reddens RS-assets (drift)',
  (d) => rmSync(join(d, '.github', 'assets', 'banners', 'src.svg')), 1,
  '✗ RS-assets (drift)', 'is declared in the manifest but missing')
expectAssets('LB-A-orphan an SVG no manifest entry produces reddens RS-assets (drift)',
  (d) => copyFileSync(join(d, '.github', 'assets', 'banner.svg'), join(d, '.github', 'assets', 'stale.svg')), 1,
  '✗ RS-assets (drift)', 'no manifest entry produces')
expectAssets('LB-A-nogenerator a missing generator reddens: nothing about the artwork is verifiable without it',
  (d) => rmSync(join(d, '.github', 'assets', 'generate.mjs')), 1,
  '✗ RS-assets (drift)', 'nothing here is verifiable')
expectAssets('LB-A-root-h1 a root README H1 that is not the generated line reddens RS-assets (idiom)',
  (d) => writeFileSync(join(d, 'README.md'), readFileSync(join(d, 'README.md'), 'utf8').replace(/^# .*$/m, '# Fixture')), 1,
  '✗ RS-assets (idiom)', "H1 is not the generated banner H1")
expectAssets('LB-A-nohomepage a manifest with no homepage renders unlinked H1s and stays green',
  (d) => {
    // The remote-less case, live: no destination, so no link, and the lint expects exactly that.
    editManifest(d, (m) => { delete m.brand.homepage })
    execFileSync('node', [join(d, '.github', 'assets', 'generate.mjs')], { cwd: d, encoding: 'utf8' })
    rewriteReadme(d)
    const p = join(d, 'src', 'README.md')
    writeFileSync(p, readFileSync(p, 'utf8').replace(/^# .*$/m, '# ![src/: Application source](../.github/assets/banners/src.svg)'))
  }, 0)
expectAssets('LB-A-homepage-empty a DECLARED but empty homepage still reddens (omit it, do not blank it)',
  (d) => editManifest(d, (m) => { m.brand.homepage = '   ' }), 1,
  '✗ RS-assets ', 'omit it rather than pointing the banner nowhere')
expectAssets('LB-A-folder-h1 a folder README H1 with the wrong relative path reddens RS-assets (idiom)',
  (d) => writeFileSync(join(d, 'src', 'README.md'), readFileSync(join(d, 'src', 'README.md'), 'utf8').replace('../.github', '.github')), 1,
  '✗ RS-assets (idiom)', 'src/README.md')
expectAssets('LB-A-noreadme a banner declared for a directory with no README reddens RS-assets (idiom)',
  (d) => rmSync(join(d, 'src', 'README.md')), 1,
  '✗ RS-assets (idiom)', 'a banner with no README')
expectAssets('LB-A-pill-orphan a pill no README shows reddens RS-assets (idiom)',
  (d) => writeFileSync(join(d, 'README.md'), readFileSync(join(d, 'README.md'), 'utf8').replace('![TESTS: UNIT + E2E](.github/assets/pills/tests.svg)\n', '')), 1,
  '✗ RS-assets (idiom)', 'never shows it')
// The arrangement. Both cases below leave every pill present, correctly pathed, and sourced: what
// the lint would have called green before the block existed, and what a reader sees as a front
// page that came out wrong.
expectAssets('LB-A-block-uncentred pills present but no longer centred reddens RS-assets (idiom)',
  (d) => writeFileSync(join(d, 'README.md'), readFileSync(join(d, 'README.md'), 'utf8')
    .replace('<div align="center">\n\n', '').replace('\n\n</div>', '')), 1,
  '✗ RS-assets (idiom)', 'is not the same as the page being arranged')
expectAssets('LB-A-block-order the same pills in a different order reddens RS-assets (idiom)',
  (d) => {
    const p = join(d, 'README.md')
    const [a, b] = ['[![VERSION: 1.2.3](.github/assets/pills/version.svg)](CHANGELOG.md)', '![TESTS: UNIT + E2E](.github/assets/pills/tests.svg)']
    writeFileSync(p, readFileSync(p, 'utf8').replace(`${a}\n${b}`, `${b}\n${a}`))
  }, 1,
  '✗ RS-assets (idiom)', 'does not open with the generated identity block')
expectAssets('LB-A-old-generator a generator predating readmeBlock() reddens rather than skipping the arrangement',
  (d) => {
    const p = join(d, '.github', 'assets', 'generate.mjs')
    writeFileSync(p, readFileSync(p, 'utf8').replace('export const readmeBlock', 'const readmeBlock'))
  }, 1,
  '✗ RS-assets (idiom)', 'does not export readmeBlock()')
// href, the optional half of a pill. Optional for the reason brand.homepage is, and checked for
// the reason an index row's link is: a claim that links nowhere reads authoritative and is not.
expectAssets('LB-A-pill-href-rot a pill linking to a file that does not exist reddens RS-assets',
  (d) => editManifest(d, (m) => { m.pills[0].href = 'docs/CHANGELOG.md' }), 1,
  '✗ RS-assets ', 'there is no such file')
expectAssets('LB-A-pill-href-blank a DECLARED but empty href reddens (omit it, do not blank it)',
  (d) => editManifest(d, (m) => { m.pills[0].href = '  ' }), 1,
  '✗ RS-assets ', 'omit it rather than pointing the pill nowhere')
expectAssets('LB-A-pill-href-absolute an off-repo href is left alone, the same as a badge href',
  (d) => { editManifest(d, (m) => { m.pills[1].href = 'https://example.com/fixture/tests' }); rewriteReadme(d) }, 0)
expectAssets('LB-A-pill-stale a pill whose source moved on reddens RS-assets (idiom)',
  (d) => writeFileSync(join(d, 'package.json'), '{ "name": "fixture", "version": "1.4.0", "license": "MIT" }\n'), 1,
  '✗ RS-assets (idiom)', 'the badge advertises a version the repo no longer is')
expectAssets('LB-A-pill-nosource a pill with no source and no stated reason reddens RS-assets (idiom)',
  (d) => editManifest(d, (m) => { delete m.pills[1].source; delete m.pills[1].why }), 1,
  '✗ RS-assets (idiom)', 'a claim with no source cannot be re-verified')
expectAssets('LB-A-pill-nowhy declaring a pill unverifiable without saying why reddens RS-assets (idiom)',
  (d) => editManifest(d, (m) => { delete m.pills[1].why }), 1,
  '✗ RS-assets (idiom)', 'has to say why it is unverifiable')
// The four ways a source could be made to say nothing while the check still passed. The first is
// the one that mattered: `includes('')` is true for every string, so a regex capturing empty let
// a pill assert anything at all and stay green. That is the provenance claim defeating itself.
expectAssets('LB-A-pill-empty-capture a source that captures EMPTY cannot launder an invented value',
  (d) => editManifest(d, (m) => {
    m.pills[0].value = '99.99.99-TOTALLY-FABRICATED'
    m.pills[0].source = { file: 'package.json', match: '"name":\\s*"fixture(x*)"' }
  }), 1,
  '✗ RS-assets (idiom)', 'every string contains the empty string')
expectAssets('LB-A-pill-two-groups a source regex with two capture groups reddens rather than taking the first',
  (d) => editManifest(d, (m) => { m.pills[0].source = { file: 'package.json', match: '"(version)":\\s*"([\\d.]+)"' } }), 1,
  '✗ RS-assets (idiom)', 'it needs exactly one')
expectAssets('LB-A-pill-ambiguous a source matching two DIFFERENT values reddens: the first would win silently',
  (d) => {
    writeFileSync(join(d, 'VERSIONS.md'), '- pinned: 1.0.0\n- pinned: 2.0.0\n')
    editManifest(d, (m) => { m.pills[0].value = '1.0.0'; m.pills[0].source = { file: 'VERSIONS.md', match: '^- pinned: ([\\d.]+)' } })
  }, 1,
  '✗ RS-assets (idiom)', 'the claim moves when the file is reordered')
expectAssets('LB-A-pill-swallowed a longer number cannot swallow the sourced one and call it verified',
  (d) => {
    writeFileSync(join(d, 'COVERAGE.md'), 'coverage: 90 percent\n')
    editManifest(d, (m) => { m.pills[0].value = '1990%'; m.pills[0].source = { file: 'COVERAGE.md', match: '^coverage: (\\d+)' } })
  }, 1,
  '✗ RS-assets (idiom)', 'so a longer number cannot swallow a shorter one')
// The decoration a pill IS allowed: the sourced value survives whole, with prose around it. The
// manifest edit changes what renders, so the fixture is re-rendered before the lint runs, exactly
// as an operator would after touching a pill.
expectAssets('LB-A-pill-decorated a pill may dress the sourced value, as long as it survives whole',
  (d) => {
    writeFileSync(join(d, 'COVERAGE.md'), 'coverage: 90 percent\n')
    editManifest(d, (m) => { m.pills[0].value = '90%'; m.pills[0].source = { file: 'COVERAGE.md', match: '^coverage: (\\d+)' } })
    execFileSync('node', [join(d, '.github', 'assets', 'generate.mjs')], { cwd: d, encoding: 'utf8' })
    rewriteReadme(d)
  }, 0)
expectAssets('LB-A-palette-missing a palette missing one role reddens RS-assets',
  (d) => editManifest(d, (m) => { delete m.brand.palette.accentSoft }), 1,
  '✗ RS-assets ', 'a half-declared palette renders silently wrong')
expectAssets('LB-A-palette-unknown an unknown palette role reddens RS-assets (a colour nobody will see change)',
  (d) => editManifest(d, (m) => { m.brand.palette.emerald = '#00ff00' }), 1,
  '✗ RS-assets ', 'unknown role')
expectAssets('LB-A-contrast a palette below the contrast floor reddens RS-assets',
  (d) => editManifest(d, (m) => { m.brand.palette.textMuted = '#2a3440' }), 1,
  '✗ RS-assets ', 'below the 4.5:1 floor')
expectAssets('LB-A-token-moved a derived palette whose source token changed reddens RS-assets (idiom)',
  (d) => {
    writeFileSync(join(d, 'tokens.css'), ':root {\n  --brand: #0ea5e9;\n}\n')
    editManifest(d, (m) => {
      m.paletteSource = { kind: 'derived', roles: { accent: { file: 'tokens.css', token: '--brand', value: SLATE.accent, transform: 'none' } } }
    })
  }, 1,
  '✗ RS-assets (idiom)', 'The design identity moved')
expectAssets('LB-A-token-held the same ledger, with the token unchanged, stays green',
  (d) => {
    writeFileSync(join(d, 'tokens.css'), `:root {\n  --brand: ${SLATE.accent};\n}\n`)
    editManifest(d, (m) => {
      m.paletteSource = { kind: 'derived', roles: { accent: { file: 'tokens.css', token: '--brand', value: SLATE.accent, transform: 'none' } } }
    })
  }, 0)
expectAssets('LB-A-coverage a directory under a covered root with no banner reddens RS-assets (idiom)',
  (d) => {
    mkdirSync(join(d, 'lib'), { recursive: true })
    writeFileSync(join(d, 'lib', 'index.js'), '// x\n')
    const p = join(d, '.repo-standard.json')
    const c = JSON.parse(readFileSync(p, 'utf8'))
    c.assets.coverage = { roots: ['.'], ignore: ['acceptance', 'src'] }
    writeFileSync(p, JSON.stringify(c, null, 2) + '\n')
  }, 1,
  '✗ RS-assets (idiom)', 'has no banner entry')
// A live badge is the one row entry the repo cannot render, so what is held is that it still
// carries the repo's own colours rather than shields' defaults.
expectAssets('LB-A-badge a live badge line missing from the README reddens RS-assets (idiom)',
  (d) => editManifest(d, (m) => {
    m.badges = [{ label: 'CI', endpoint: 'github/actions/workflow/status/acme/fixture/test.yml', href: 'https://example.com/ci' }]
  }), 1,
  '✗ RS-assets (idiom)', 'palette-styled badge line')
expectAssets('LB-A-badge-styled the same badge, carrying the palette colours, stays green',
  (d) => {
    editManifest(d, (m) => {
      m.badges = [{ label: 'CI', endpoint: 'github/actions/workflow/status/acme/fixture/test.yml', href: 'https://example.com/ci' }]
    })
    // Hand-typed on purpose, rather than re-derived through rewriteReadme: this is the one case
    // that pins the literal shields URL shape against something other than the helper that
    // builds it. It goes inside the centred block, on its own line under the pills, because
    // that is where the arrangement puts a live badge.
    const strip = (h) => h.replace('#', '')
    const url = `https://img.shields.io/github/actions/workflow/status/acme/fixture/test.yml?style=flat&label=CI&labelColor=${strip(SLATE.ground)}&color=${strip(SLATE.pillAccentBg)}`
    const p = join(d, 'README.md')
    writeFileSync(p, readFileSync(p, 'utf8').replace('\n\n</div>', `\n\n[![CI](${url})](https://example.com/ci)\n\n</div>`))
  }, 0)
expectAssets('LB-A-badge-url a full URL where the shields path belongs reddens RS-assets',
  (d) => editManifest(d, (m) => {
    m.badges = [{ label: 'CI', endpoint: 'https://img.shields.io/badge/ci-passing-green', href: 'https://example.com/ci' }]
  }), 1,
  '✗ RS-assets ', 'not a full URL')
expectAssets('LB-A-reflexivity CONVENTIONS that never says the assets are generated reddens RS-reflexivity',
  (d) => writeFileSync(join(d, 'CONVENTIONS.md'), readFileSync(join(d, 'CONVENTIONS.md'), 'utf8').replace('run `node .github/assets/generate.mjs`', 'run the generator')), 1,
  '✗ RS-reflexivity', 'will hand-edit one')
expectAssets('LB-A-manifest-json an unparseable manifest reddens RS-assets, naming the parse error',
  (d) => writeFileSync(join(d, '.github', 'assets', 'manifest.json'), '{ "version": 1, '), 1,
  '✗ RS-assets ', 'is not valid JSON')

// ── RS-about: the panel a stranger reads first ──
const withAbout = (f, description) => editConfig(f, (c) => { c.github = { about: { description } } })
expect('LB-B-clean a recorded About matching the README tagline stays green',
  (f) => withAbout(f, 'A test fixture repo for the repo-standard lint.'), 0,
  '✓ RS-about')
expect('LB-B-stale a recorded About that no longer matches the tagline reddens RS-about',
  (f) => withAbout(f, 'A test fixture repo for something else entirely.'), 1,
  '✗ RS-about', 'gone stale')
expect('LB-B-tagline-edit editing the TAGLINE is what makes it stale, which is the real drift',
  (f) => {
    withAbout(f, 'A test fixture repo for the repo-standard lint.')
    f['README.md'] = f['README.md'].replace('**A test fixture repo for the repo-standard lint.**', '**A fixture, renamed and rescoped.**')
  }, 1,
  '✗ RS-about', 'gone stale')
expect('LB-B-live-skip the live panel is always a named SKIP: this lint takes no network',
  (f) => withAbout(f, 'A test fixture repo for the repo-standard lint.'), 0,
  'RS-about (live panel) SKIP', 'takes no network')
expect('LB-S-about-off no About recorded prints a named SKIP, never a silent pass',
  null, 0,
  'RS-about SKIP', 'no GitHub About recorded')
expect('LB-C-about-long a description past GitHub\'s 350-character limit exits 2',
  (f) => withAbout(f, 'x'.repeat(351)), 2,
  'GitHub truncates the About panel at 350')
// homepage is optional and the engine that derives this block emits null for a repo that
// publishes none, so null has to read as absent: a journey's last step must not be able to wedge
// the gate with the engine's own output. An empty string is the opposite case, and stays an
// error, because it is the nearest exit for an agent that got stuck and it records a falsehood a
// later re-sync could push as a real blanking write.
expect('LB-C-about-homepage-null a null homepage reads as absent, the way the engine emits it',
  (f) => editConfig(f, (c) => { c.github = { about: { description: 'A test fixture repo for the repo-standard lint.', homepage: null } } }), 0,
  '✓ RS-config')
expect('LB-C-about-homepage-blank a declared but empty homepage exits 2 (omit it, do not blank it)',
  (f) => editConfig(f, (c) => { c.github = { about: { description: 'A test fixture repo for the repo-standard lint.', homepage: '   ' } } }), 2,
  'must be a non-empty URL string, or omitted')
expect('LB-C-about-topic an invalid GitHub topic exits 2 and names it',
  (f) => editConfig(f, (c) => { c.github = { about: { description: 'A test fixture repo for the repo-standard lint.', topics: ['Repo Hygiene'] } } }), 2,
  'is not a valid GitHub topic')
expect('LB-C-about-toomany more than 20 topics exits 2',
  (f) => editConfig(f, (c) => { c.github = { about: { description: 'A test fixture repo for the repo-standard lint.', topics: Array.from({ length: 21 }, (_, i) => `topic-${i}`) } } }), 2,
  'GitHub accepts at most 20')

// ──────────────────────────────────────────────────────────── loud skips and disables
expect('LB-S-manifest-skip no manifest declared → a printed SKIP line, not a silent pass',
  (f) => { editConfig(f, (c) => { c.manifest = false }); f['MANIFEST.md'] = null }, 0,
  'RS-manifest SKIP', 'no manifest doc declared')
expect('LB-S-disable a reasoned disable skips the broken check LOUDLY and keeps the build green',
  (f) => {
    editConfig(f, (c) => { c.checks = { changelog: { enabled: false, why: 'migrating a legacy changelog' } } })
    f['CHANGELOG.md'] = f['CHANGELOG.md'].replace('### Added', '### Notes\n\n- x\n\n### Added')
  }, 0,
  'changelog is DISABLED in config: migrating a legacy changelog', 'RS-changelog SKIP')
expect('LB-S-noconfig a missing config runs full-strict defaults (fixture violates none of them)',
  (f) => {
    f['.repo-standard.json'] = null
    f['MANIFEST.md'] = null // no config → no manifest declared → skip
    // no config also means no properNouns exemption — the bare product name must go, which is
    // itself the correct default-strict behavior (proven red in LB-M-voice-propernoun).
    f['README.md'] = f['README.md'].replace(' Built on Seamless Deploy.', '')
  }, 0,
  'defaults, no .repo-standard.json')

// ── the grammar-2 column contract, and the parser holes an audit found behind it ──
// Every case here was GREEN before: the page looked catalogued to the parser and read as prose,
// as an example, or as the wrong column to everyone else. Grammar 2's promise is that each check
// reads the column its header names, and four of these were that promise not being kept.
const G2 = (f, rows, edit) => { withIndex(f, rows); editConfig(f, (c) => { c.docs.index.grammar = 2; if (edit) edit(c) }) }

expect('LB-I-g2-link-column a link outside the FILE column is not a catalog row (the empty-file-cell hole)',
  (f) => G2(f, ['|  | [`guide.md`](./guide.md) How to use it | active | 2026-07-30 |', ROW_RUNBOOK]), 1,
  '✗ RS-index', 'docs/guide.md')
expect('LB-I-g2-status-header a table with no STATUS column does not fall back to "any cell"',
  (f) => {
    G2(f, [ROW_GUIDE, ROW_RUNBOOK])
    f['docs/README.md'] = f['docs/README.md']
      .replace('| File | What it is for | Status | Last verified |', '| File | What it is for | Phase | Last verified |')
      .replace('| How to use it | active |', '| active, and how to use it | |')
  }, 1,
  '✗ RS-index', 'has no status column')
expect('LB-I-g2-date-header a table with no VERIFICATION-DATE column does not let another one answer',
  (f) => {
    G2(f, [ROW_GUIDE, ROW_RUNBOOK])
    f['docs/README.md'] = f['docs/README.md'].replace('| File | What it is for | Status | Last verified |', '| File | What it is for | Status | Added |')
  }, 1,
  '✗ RS-index', 'has no verification-date column')
expect('LB-I-fence-infostring a "```notclose" line inside a fence does NOT end it (CommonMark: a closing fence has no info string)',
  (f) => {
    G2(f, [ROW_GUIDE])
    f['docs/README.md'] += '\n```text\n```notclose\n| File | What it is for | Status | Last verified |\n|---|---|---|---|\n' + ROW_RUNBOOK + '\n```\n'
  }, 1,
  '✗ RS-index', 'docs/ops/runbook.md')
expect('LB-I-link-closure closure is asked of the link that OPENED, not of any later link in the cell',
  (f) => G2(f, ['| [`guide.md`](./guide.md see also [x](./ops/runbook.md) | How to use it | active | 2026-07-30 |', ROW_RUNBOOK]), 1,
  '✗ RS-index', 'never closes')
expect('LB-I-site-absolute a "/guide.md" destination is a SITE path, not this directory joined to it',
  (f) => G2(f, [ROW_GUIDE.replace('](./guide.md)', '](/guide.md)'), ROW_RUNBOOK]), 1,
  '✗ RS-index', 'resolves against the domain')
expect('LB-I-g2-clean the same index, with every column where its header says, stays green',
  (f) => G2(f, [ROW_GUIDE, ROW_RUNBOOK]), 0)

// ── the config surface: a value that parses is not a config, and every path is contained ──
expect('LB-C-root-null a config that is JSON `null` is a config ERROR, never a crash',
  (f) => { f['.repo-standard.json'] = 'null\n' }, 2,
  'must be a JSON OBJECT')
expect('LB-C-root-array a config that is a JSON array is the same refusal',
  (f) => { f['.repo-standard.json'] = '[]\n' }, 2,
  'must be a JSON OBJECT')
// THE PATH REGISTRY, one case per key that was reachable outside the repo. Each of these read,
// walked or globbed a tree this gate does not govern, and reported a verdict about it.
for (const [id, key, mutate] of [
  ['versionManifest', 'versionManifest', (c) => { c.versionManifest = '../outside/package.json' }],
  ['versionManifest-object', 'versionManifest.file', (c) => { c.versionManifest = { file: '../outside/package.json', match: '"version": "(.+)"' } }],
  ['ignore-file', 'ignore.file', (c) => { c.ignore = { file: '../outside/.gitignore' } }],
  ['ignore-generated', 'ignore.generated[0]', (c) => { c.ignore = { generated: ['../outside/dist'] } }],
  ['coverage-roots', 'assets.coverage.roots[0]', (c) => { c.assets = { dir: '.github/assets', coverage: { roots: ['../outside'] } } }],
  ['coverage-ignore', 'assets.coverage.ignore[0]', (c) => { c.assets = { dir: '.github/assets', coverage: { roots: ['.'], ignore: ['../outside'] } } }],
  ['prose-exempt', 'prose.exempt[0].path', (c) => { c.prose = { profile: 'enterprise', exempt: [{ path: '../outside', why: 'x' }] } }],
  ['counts-docs', 'counts.gizmos.docs[0]', (c) => { c.counts.gizmos.docs = ['../outside/NOTES.md'] }],
  ['counts-file', 'counts.rows.file', (c) => { c.counts.rows.file = '../outside/rows.txt' }],
  ['counts-glob', 'counts.widgets.glob', (c) => { c.counts.widgets.glob = '../outside/widget-*.txt' }],
  ['declined-dir', 'docs.declined[0].dir', (c) => { c.docs = { ...(c.docs ?? {}), declined: [{ dir: '../outside', why: 'x' }] } }],
  ['stable-docs', 'stableDocs[0]', (c) => { c.stableDocs = ['../outside/SECURITY.md'] }],
]) {
  expect(`LB-C-path-${id} "${key}" cannot reach outside the repo`, (f) => editConfig(f, mutate), 2, `"${key}"`, 'stays inside this repo')
}
expect('LB-S-path-trailing-slash a trailing slash is a SPELLING, not an escape: "dist/" is still accepted',
  (f) => { editConfig(f, (c) => { c.ignore = { generated: ['dist/'] } }); f['.gitignore'] += 'dist/\n' }, 0)
expect('LB-C-path-backslash a backslash is refused wherever it is written, before any normaliser can repair it',
  (f) => editConfig(f, (c) => { c.docs = { ...(c.docs ?? {}), declined: [{ dir: 'ghost\\dir', why: 'x' }] } }), 2,
  '"docs.declined[0].dir"', 'no backslashes')

/*
 * ────────────────────────────────────────────────────── THE SPELLING MATRIX (LB-SP-*)
 *
 * The registry above proves every configured path can be REFUSED. This proves the other half, and
 * it is the half that shipped broken: that an ACCEPTED spelling means the same thing as the plain
 * one.
 *
 * A leading "./" and a trailing "/" are both accepted, and both used to change semantics. The
 * three measured divergences, each on a config nobody would call wrong:
 *   docs.declined [{ dir: "./lib" }]  excused the directory in the planner and excused nothing
 *     here, which under strict ownership is a green build against a red one.
 *   an index's ignore ["./lib/two.mjs"]  was an exclusion there and no exclusion here.
 *   docs.changelog "./CHANGELOG.md"  stopped matching the CHANGELOG.md git lists, so the
 *     migration offer's released-history guard never fired and shipped history was queued for a
 *     mechanical rewrite.
 *
 * So the assertion is EQUIVALENCE, not merely acceptance: the same fixture, with a path written
 * three ways, has to produce the same lint output byte for byte. An exit code alone would pass on
 * a rule that silently stopped applying, because a rule that checks nothing also exits 0.
 */
const CLEAN_OUT = runLint(null).out
for (const [id, what, mutate] of [
  ['docs-changelog', 'docs.changelog', (c) => { c.docs = { ...(c.docs ?? {}), changelog: './CHANGELOG.md' } }],
  ['docs-conventions', 'docs.conventions', (c) => { c.docs = { ...(c.docs ?? {}), conventions: './CONVENTIONS.md' } }],
  ['docs-readme', 'docs.readme', (c) => { c.docs = { ...(c.docs ?? {}), readme: './README.md' } }],
  ['manifest-file', 'manifest.file', (c) => { c.manifest = { ...c.manifest, file: './MANIFEST.md' } }],
  ['stable-docs', 'stableDocs[0]', (c) => { c.stableDocs = ['./SECURITY.md', 'CONTRIBUTING.md', 'CODE_OF_CONDUCT.md'] }],
  ['counts-file', 'counts.rows.file', (c) => { c.counts.rows.file = './data/rows.txt' }],
  ['counts-docs', 'counts.rows.docs[0]', (c) => { c.counts.rows.docs = ['./README.md'] }],
  ['counts-glob', 'counts.widgets.glob', (c) => { c.counts.widgets.glob = './src/widget-*.txt' }],
  ['ignore-file', 'ignore.file', (c) => { c.ignore = { file: './.gitignore' } }],
  ['version-manifest', 'versionManifest', (c) => { c.versionManifest = './package.json' }],
  ['version-manifest-object', 'versionManifest.file', (c) => { c.versionManifest = { file: './package.json', match: '"version": "([^"]+)"' } }],
]) {
  check(`LB-SP-${id} "${what}" written with a leading "./" means exactly what the plain spelling means`, () => {
    const r = runLint((f) => editConfig(f, mutate))
    assert.equal(r.code, 0, `the "./" spelling is accepted, and accepted has to mean the same thing\n${r.out}`)
    assert.equal(r.out, CLEAN_OUT, `the "./" spelling produced a DIFFERENT verdict from the plain one. An accepted spelling that changes what a rule means is the bug this matrix exists for\n--- with "./" ---\n${r.out}\n--- plain ---\n${CLEAN_OUT}`)
  })
}
// The trailing slash, on the two keys where a directory is the natural thing to write.
check('LB-SP-trailing-generated "dist/" and "dist" are the same declared generated path', () => {
  const a = runLint((f) => { editConfig(f, (c) => { c.ignore = { generated: ['dist'] } }); f['.gitignore'] += 'dist/\n' })
  const b = runLint((f) => { editConfig(f, (c) => { c.ignore = { generated: ['dist/'] } }); f['.gitignore'] += 'dist/\n' })
  assert.equal(a.code, 0, `the plain spelling is clean\n${a.out}`)
  assert.equal(b.out, a.out, `and the trailing-slash spelling is the same declaration, not a second one\n${b.out}`)
})
// A CONTROL CHARACTER is refused everywhere, and refused by the registry sweep rather than by any
// one call site: a path carrying a NUL or a newline reaches git, execFileSync and a printed
// diagnostic before anyone sees it, and none of those three read it the way a Set does.
for (const [id, key, value] of [
  ['nul', 'docs.declined[0].dir', `ghost${String.fromCharCode(0)}dir`],
  ['newline', 'stableDocs[0]', 'SECURITY.md\nCONTRIBUTING.md'],
  ['tab', 'ignore.generated[0]', 'dist\tbuild'],
]) {
  expect(`LB-C-path-control-${id} a control character in "${key}" is refused`, (f) => editConfig(f, (c) => {
    if (key.startsWith('docs.declined')) c.docs = { ...(c.docs ?? {}), declined: [{ dir: value, why: 'x' }] }
    else if (key.startsWith('stableDocs')) c.stableDocs = [value]
    else c.ignore = { generated: [value] }
  }), 2, `"${key}"`, 'no control characters')
}

/*
 * ────────────────────────────────────── ONE CROSS-PILLAR POLICY FOR A SUBMODULE (LB-A-gitlink)
 *
 * RS-index excludes a gitlink from the coverage universe, because a submodule is another
 * repository's whole content and nobody should have to write a row for a tree they do not own.
 * RS-assets coverage walked straight into the same directory and demanded a banner entry and a
 * folder README from it. Two pillars, one directory, opposite answers, and the only way to satisfy
 * both was to write a page into a checkout this repo does not govern.
 */
check('LB-A-gitlink assets coverage does not demand a banner from a submodule, which RS-index already excludes', () => {
  const r = runAssets((tmp) => {
    // Coverage over every top-level directory, which is the setting that walks into a submodule.
    // `acceptance/` is the harness's own copy of the lint and is excluded the way a real repo
    // would exclude it, so the case under test is the only directory left without a banner.
    const cfgPath = join(tmp, '.repo-standard.json')
    const cfg = JSON.parse(readFileSync(cfgPath, 'utf8'))
    cfg.assets = { dir: '.github/assets', coverage: { roots: ['.'], ignore: ['acceptance'] } }
    writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + '\n')
    execFileSync('git', ['init', '-q'], { cwd: tmp, stdio: 'ignore' })
    mkdirSync(join(tmp, 'vendored'), { recursive: true })
    writeFileSync(join(tmp, 'vendored', '.keep'), '')
    execFileSync('git', ['add', '-A'], { cwd: tmp, stdio: 'ignore' })
    execFileSync('git', ['rm', '-q', '--cached', 'vendored/.keep'], { cwd: tmp, stdio: 'ignore' })
    // The empty-blob SHA, which `git add` above put in the object database: git refuses a
    // cacheinfo entry naming an object it does not have, and the ZERO sha is not an object.
    execFileSync('git', ['update-index', '--add', '--cacheinfo', '160000,e69de29bb2d1d6434b8b29ae775ad8c2e48c5391,vendored'], { cwd: tmp, stdio: 'ignore' })
    // The directory stays on disk and empty, which is what an uninitialised submodule looks like
    // and is exactly the shape assets coverage used to walk into.
    rmSync(join(tmp, 'vendored', '.keep'), { force: true })
  })
  assert.ok(!r.out.includes('vendored/ has no banner entry'),
    `a submodule directory owes neither a row nor a banner: RS-index excludes it as another repository's content, and RS-assets demanded a page from it on the same run\n${r.out}`)
  assert.equal(r.code, 0, `and the tree is clean once the two pillars agree about it\n${r.out}`)
})

// The three guards an anti-vacuity pass found MISSING: each fix below was real, and reverting it
// left this whole suite green. A fix nothing can fail on is a fix nobody can keep.
check('LB-SP-index-ignore an index "ignore" written "./lib/two.mjs" excludes exactly what "lib/two.mjs" excludes', () => {
  const plain = runLint((f) => withEngineIndex(f, [ROW_ONE], {}) || undefined)
  // Baseline: two engines, one row, so the un-ignored one is missing and the gate says so.
  assert.equal(plain.code, 1, `the baseline has an uncatalogued file, or this case proves nothing\n${plain.out}`)
  const withPlain = runLint((f) => {
    withEngineIndex(f, [ROW_ONE])
    editConfig(f, (c) => { c.docs.indexes[0].ignore = ['lib/two.mjs'] })
  })
  const withDotted = runLint((f) => {
    withEngineIndex(f, [ROW_ONE])
    editConfig(f, (c) => { c.docs.indexes[0].ignore = ['./lib/two.mjs'] })
  })
  const withSlash = runLint((f) => {
    withEngineIndex(f, [ROW_ONE])
    editConfig(f, (c) => { c.docs.indexes[0].ignore = ['lib/'] })
  })
  assert.equal(withPlain.code, 0, `the plain spelling excludes the file\n${withPlain.out}`)
  assert.equal(withDotted.out, withPlain.out,
    `"./lib/two.mjs" is the same exclusion as "lib/two.mjs". Kept raw, it excluded nothing here while the planner excluded the file, which is one engine planning a repo the other fails\n--- dotted ---\n${withDotted.out}\n--- plain ---\n${withPlain.out}`)
  assert.equal(withSlash.code, 0, `and a trailing slash is a spelling too: "lib/" excludes what "lib" excludes\n${withSlash.out}`)
})
expectAssets('LB-A-palette-source-escape a derived palette cannot be traced to a file outside the repo',
  (dir) => editManifest(dir, (m) => { m.paletteSource = { kind: 'derived', roles: { ground: { file: '../outside/tokens.css', token: '--g', value: '#111827', transform: 'none' } } } }), 1,
  'paletteSource.roles.ground.file', 'stays inside this repo')
expectAssets('LB-A-badge-href-escape a relative badge href cannot resolve outside the repo',
  (dir) => { editManifest(dir, (m) => { m.badges = [{ label: 'ci', endpoint: 'github/actions/workflow/status/o/r/t.yml', href: '../../etc/passwd' }] }); rewriteReadme(dir) }, 1,
  'badges[0].href', 'stays inside this repo')
expectAssets('LB-A-badge-href-missing a relative badge href has to point at a file that exists',
  (dir) => { editManifest(dir, (m) => { m.badges = [{ label: 'ci', endpoint: 'github/actions/workflow/status/o/r/t.yml', href: 'docs/nope.md' }] }); rewriteReadme(dir) }, 1,
  'there is no such file')
expectAssets('LB-A-badge-href-real a relative badge href that resolves is accepted, so the rule is not simply "refuse"',
  (dir) => { editManifest(dir, (m) => { m.badges = [{ label: 'ci', endpoint: 'github/actions/workflow/status/o/r/t.yml', href: 'CHANGELOG.md' }] }); rewriteReadme(dir) }, 0)

/*
 * ───────────────────────────────────────────── PHYSICAL CONTAINMENT (LB-P-*)
 *
 * `escapesOnDisk` answers "does this path land outside the repo". These answer the question
 * underneath it, which is whether the bytes being read, imported, compared or WRITTEN are the ones
 * this repo commits at the path being governed. An external audit demonstrated the whole class at
 * once: a target whose acceptance/test-repo-standard.mjs was a symlink to a clean copy in another
 * checkout printed 29 passed on a repo whose own index was missing a row, and replacing banner.svg
 * with a symlink produced 29 passed AND a generator apply that wrote the rendered artwork through
 * the link onto its target.
 */
const runLintAt = (mutate) => {
  const files = baseFiles()
  const tmp = mkdtempSync(join(tmpdir(), 'rs-lint-physical-'))
  try {
    for (const [rel, content] of Object.entries(files)) {
      if (content === null) continue
      mkdirSync(join(tmp, dirname(rel)), { recursive: true })
      writeFileSync(join(tmp, rel), content)
    }
    mkdirSync(join(tmp, 'acceptance'), { recursive: true })
    writeFileSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
    const outside = mutate(tmp)
    try {
      return { code: 0, out: execFileSync('node', [join(tmp, 'acceptance', 'test-repo-standard.mjs')], { encoding: 'utf8' }) }
    } catch (e) {
      return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` }
    } finally { if (outside) rmSync(outside, { recursive: true, force: true }) }
  } finally { rmSync(tmp, { recursive: true, force: true }) }
}
check('LB-P-lint-symlink a gate committed as a symlink refuses to run, because it would audit the tree it points into', () => {
  const r = runLintAt((tmp) => {
    // A second, CLEAN checkout, exactly as the audit built it: the decoy passes, the real target
    // is missing a row, and the symlink makes the decoy's verdict the target's.
    const decoy = mkdtempSync(join(tmpdir(), 'rs-lint-decoy-'))
    for (const [rel, content] of Object.entries(baseFiles())) {
      if (content === null) continue
      mkdirSync(join(decoy, dirname(rel)), { recursive: true })
      writeFileSync(join(decoy, rel), content)
    }
    mkdirSync(join(decoy, 'acceptance'), { recursive: true })
    writeFileSync(join(decoy, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
    // Break the TARGET so a green result could only have come from the decoy.
    writeFileSync(join(tmp, 'README.md'), '# fixture\n\nNo tagline, no sections, nothing this lint accepts.\n')
    rmSync(join(tmp, 'acceptance', 'test-repo-standard.mjs'))
    symlinkSync(join(decoy, 'acceptance', 'test-repo-standard.mjs'), join(tmp, 'acceptance', 'test-repo-standard.mjs'))
    return decoy
  })
  assert.equal(r.code, 2, `a substituted gate is a refusal, not a verdict\n${r.out}`)
  assert.ok(r.out.includes('SYMLINK'), `and it names what it found\n${r.out}`)
  assert.ok(!r.out.includes('passed'), `it must never print a pass line: the whole failure is that it looked green\n${r.out}`)
})
check('LB-P-lint-parent-symlink a symlinked PARENT DIRECTORY is the same substitution one level up', () => {
  const r = runLintAt((tmp) => {
    const decoy = mkdtempSync(join(tmpdir(), 'rs-lint-decoy-'))
    mkdirSync(join(decoy, 'acceptance'), { recursive: true })
    writeFileSync(join(decoy, 'acceptance', 'test-repo-standard.mjs'), LINT_SRC)
    rmSync(join(tmp, 'acceptance'), { recursive: true, force: true })
    symlinkSync(join(decoy, 'acceptance'), join(tmp, 'acceptance'))
    return decoy
  })
  assert.equal(r.code, 2, `lstat on the leaf cannot see this, so the repository the invocation path sits in is compared as well\n${r.out}`)
  assert.ok(r.out.includes('another checkout'), `and it says which two trees disagree\n${r.out}`)
})
expectAssets('LB-P-svg-symlink a symlinked SVG is an explicit error, not an entry the directory scan cannot see',
  (dir) => {
    const p = join(dir, '.github', 'assets', 'banner.svg')
    const away = join(dir, 'elsewhere.svg')
    renameSync(p, away)
    symlinkSync(away, p)
  }, 1,
  '✗ RS-assets (drift)', 'not regular files', 'render through onto a target it does not govern')
expectAssets('LB-P-manifest-symlink a symlinked manifest is refused before anything is rendered from it',
  (dir) => {
    const p = join(dir, '.github', 'assets', 'manifest.json')
    const away = join(dir, 'elsewhere.json')
    renameSync(p, away)
    symlinkSync(away, p)
  }, 1,
  '✗ RS-assets', 'a SYMLINK')
expectAssets('LB-P-generator-symlink a symlinked generator is never imported, so no drift verdict is claimed from it',
  (dir) => {
    const p = join(dir, '.github', 'assets', 'generate.mjs')
    const away = join(dir, 'elsewhere.mjs')
    renameSync(p, away)
    symlinkSync(away, p)
  }, 1,
  '✗ RS-assets (drift)', 'was not imported')
/*
 * A STALE GENERATED CARRIER: the page a removed banner leaves behind.
 *
 * Every other rule here iterates `manifest.banners`, so deleting an entry deleted the check along
 * with the claim. The SVG goes out as an orphan, the README it headed keeps an H1 pointing at
 * artwork that no longer exists, and the generator's preview and this gate both went green over a
 * page whose first line is a broken image. `assets.coverage` catches some of these and is the wrong
 * instrument: it is opt-in, it reaches one level per root, and the reproduction had it switched off
 * for that very directory.
 */
expectAssets('LB-P-stale-carrier removing a banner leaves the page it headed pointing at nothing, and the page is where that is visible',
  (dir) => {
    editManifest(dir, (m) => { m.banners = [] })
    rewriteReadme(dir)
    rmSync(join(dir, '.github', 'assets', 'banners', 'src.svg'), { force: true })
  }, 1,
  '✗ RS-assets (idiom)', 'src/README.md opens with a generated banner H1', 'declares no banner')
expectAssets('LB-P-dot-slash-banner-dir a banner declared for "./src" is the same directory "src" is, in every rule that reads one',
  (dir) => {
    editManifest(dir, (m) => { for (const b of m.banners) if (b.dir === 'src') b.dir = './src' })
  }, 0)

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
