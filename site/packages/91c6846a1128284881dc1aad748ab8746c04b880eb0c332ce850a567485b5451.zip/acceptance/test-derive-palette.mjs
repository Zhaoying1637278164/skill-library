#!/usr/bin/env node
/*
 * test-derive-palette.mjs — the palette engine reads, never invents.
 *
 * WHY: this engine looks at a stranger's repo and proposes what their README will look like.
 * Two failure modes matter more than anything it gets right. It must not INVENT an identity for
 * a repo that has none (a confident answer to a question nobody asked is worse than "I cannot
 * tell"), and it must not record a colour it made up as if the lint could later re-verify it,
 * because RS-assets re-reads exactly those records forever.
 *
 * Guards:
 *   DP1  deterministic: the same tree proposes byte-identical output, twice.
 *   DP2  provenance is real: a token is reported with the file and line it actually sits on.
 *   DP3  a repo with no design identity gets a refusal with a reason, not a plausible palette.
 *   DP4  a proposal is always complete: all 15 roles, every one a hex colour.
 *   DP5  only file-backed roles reach the manifest, so no unfalsifiable claim is ever recorded.
 *   DP6  the contrast floor is met, or the engine says it could not be met (exit 1).
 *   DP7  what it proposes actually renders through the shipped generator.
 *
 * Dependency-free: `node acceptance/test-derive-palette.mjs`.
 */
import assert from 'node:assert/strict'
import { writeFileSync, mkdirSync, mkdtempSync, rmSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { render, ROLES } from '../payload/assets/generate.mjs'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const ENGINE = join(ROOT, 'harness', 'derive-palette.mjs')

let pass = 0, fail = 0
const check = (name, fn) => { try { fn(); pass++; console.log(`  ✓ ${name}`) } catch (e) { fail++; console.log(`  ✗ ${name}\n    ${e.message}`) } }

const HEX = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/
const build = (files) => {
  const tmp = mkdtempSync(join(tmpdir(), 'rs-palette-'))
  for (const [rel, content] of Object.entries(files)) {
    mkdirSync(join(tmp, dirname(rel)), { recursive: true })
    writeFileSync(join(tmp, rel), content)
  }
  return tmp
}
const run = (dir) => {
  try { return { code: 0, out: execFileSync('node', [ENGINE, '--target', dir, '--json'], { encoding: 'utf8' }) } }
  catch (e) { return { code: e.status, out: `${e.stdout || ''}${e.stderr || ''}` } }
}
const withRepo = (files, fn) => { const d = build(files); try { fn(d) } finally { rmSync(d, { recursive: true, force: true }) } }

// A small but genuine design system: enough named tokens to clear the engine's evidence floor.
const TOKENS = [
  ':root {',
  '  --brand-primary: #2563eb;',
  '  --brand-secondary: #f59e0b;',
  '  --surface-base: #0b1220;',
  '  --text-primary: #eef2f8;',
  '  --text-muted: #94a3b8;',
  '  --border-subtle: #334155;',
  '  --state-danger: #dc2626;',
  '}',
  '',
].join('\n')

console.log('derive-palette standing test (reads, never invents)')

check('DP1 the same tree proposes byte-identical output, twice', () => {
  withRepo({ 'styles/tokens.css': TOKENS }, (d) => {
    const a = run(d), b = run(d)
    assert.equal(a.code, 0, `a real token set should be derivable\n${a.out}`)
    assert.equal(a.out, b.out, 'two runs over the same tree must propose the same palette, byte for byte')
  })
})

check('DP2 provenance is real: the token, the file, and the line it actually sits on', () => {
  withRepo({ 'styles/tokens.css': TOKENS }, (d) => {
    const r = JSON.parse(run(d).out)
    const accent = r.provenance.accent
    assert.equal(accent.kind, 'token', 'the accent must come from a token, not a transform')
    assert.equal(accent.file, 'styles/tokens.css', 'the source file is reported as a repo-relative path')
    assert.equal(accent.token, '--brand-primary', 'the token name is reported')
    assert.equal(accent.value.toLowerCase(), '#2563eb', 'the value is the one the token holds')
    assert.equal(accent.line, 2, 'the line number points at the declaration itself')
    assert.equal(r.provenance.accentAlt.token, '--brand-secondary', 'a declared second brand colour is used rather than a rotation')
  })
})

check('DP3 a repo with no design identity gets a refusal with a reason, not a palette', () => {
  withRepo({ 'README.md': '# nothing\n', 'src/main.js': 'console.log(1)\n' }, (d) => {
    const r = run(d)
    assert.equal(r.code, 1, 'a repo with nothing to read must not produce a proposal')
    const report = JSON.parse(r.out)
    assert.equal(report.ok, false, 'ok must be false')
    assert.ok(/no named colours found/.test(report.reason), `the refusal must say what was missing: ${report.reason}`)
    assert.ok(!report.palette, 'a refusal must carry no palette at all: half an answer is the dangerous kind')
    assert.ok(/preset/.test(report.suggestion), 'the refusal must point at the honest alternative')
  })
  // The evidence floor: two stray hexes in one file are not a design system.
  withRepo({ 'theme.json': '{ "primary": "#2563eb", "alt": "#f59e0b" }\n' }, (d) => {
    const r = run(d)
    assert.equal(r.code, 1, 'below the evidence floor, the engine must refuse rather than extrapolate')
    assert.ok(/below the \d+ it takes/.test(JSON.parse(r.out).reason), 'the refusal names the floor it fell below')
  })
})

check('DP4 a proposal is always complete: all 15 roles, every one a hex colour', () => {
  withRepo({ 'styles/tokens.css': TOKENS }, (d) => {
    const r = JSON.parse(run(d).out)
    for (const role of ROLES) {
      assert.match(r.palette[role], HEX, `${role} must be a hex colour, got ${JSON.stringify(r.palette[role])}`)
      assert.ok(r.provenance[role], `${role} must say how it was obtained`)
    }
    assert.deepEqual(Object.keys(r.palette).sort(), [...ROLES].sort(), 'the proposal carries exactly the generator\'s roles')
  })
})

check('DP5 only file-backed roles reach the manifest (no unfalsifiable claim is recorded)', () => {
  withRepo({ 'styles/tokens.css': TOKENS }, (d) => {
    const r = JSON.parse(run(d).out)
    const recorded = Object.keys(r.manifestPaletteSource.roles)
    assert.ok(recorded.length > 0, 'a derived palette must record at least one real source')
    assert.equal(r.manifestPaletteSource.kind, 'derived', 'the kind is recorded so the lint knows to re-read')
    for (const role of recorded) {
      const p = r.provenance[role]
      assert.equal(p.kind, 'token', `${role} is recorded in the manifest but was ${p.kind}, not read from a file — RS-assets would try to re-verify a colour that never came from one`)
      const rec = r.manifestPaletteSource.roles[role]
      assert.deepEqual([rec.file, rec.token, rec.value], [p.file, p.token, p.value], `${role}'s recorded source must match its provenance`)
    }
    const derivedRoles = Object.entries(r.provenance).filter(([, p]) => p.kind !== 'token').map(([k]) => k)
    for (const role of derivedRoles) assert.ok(!recorded.includes(role), `${role} was derived by transform and must not be recorded as a re-readable source`)
  })
})

check('DP6 the contrast floor is met, or the engine says it could not be (never shipped failing)', () => {
  const lin = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
  const lum = (hex) => {
    const h = hex.replace('#', '')
    const parts = h.length === 3 ? [...h].map((c) => c + c) : [h.slice(0, 2), h.slice(2, 4), h.slice(4, 6)]
    const [r, g, b] = parts.map((p) => lin(parseInt(p, 16) / 255))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b
  }
  const ratio = (a, b) => { const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x); return (hi + 0.05) / (lo + 0.05) }
  const PAIRS = [['text', 'ground'], ['text', 'groundMid'], ['text', 'groundDeep'], ['textMuted', 'ground'],
    ['textMuted', 'groundMid'], ['accentAlt', 'ground'], ['accentAlt', 'groundMid'], ['pillAccentFg', 'pillAccentBg'], ['pillAltFg', 'pillAltBg']]
  // A deliberately hostile identity: a near-black "accent" and a muted grey the engine will
  // have to lift off the ground to clear the floor.
  for (const tokens of [TOKENS, [':root {', '  --brand-primary: #14532d;', '  --brand-secondary: #3f3f46;',
    '  --surface-base: #0a0a0a;', '  --text-muted: #3f3f46;', '  --border-subtle: #262626;',
    '  --state-info: #1e3a8a;', '}'].join('\n')]) {
    withRepo({ 'styles/tokens.css': tokens }, (d) => {
      const r = run(d)
      const report = JSON.parse(r.out)
      if (r.code !== 0) {
        assert.ok(report.failures.length > 0, 'a non-zero exit must name the pairs it could not fix')
        return
      }
      for (const [fg, bg] of PAIRS) {
        const got = ratio(report.palette[fg], report.palette[bg])
        assert.ok(got >= 4.5, `a proposed palette put ${fg} on ${bg} at ${got.toFixed(2)}:1, which the lint will refuse`)
      }
      for (const w of report.warnings) assert.ok(typeof w === 'string' && w.length > 0, 'every adjustment to someone\'s brand colour must be stated')
    })
  }
})

check('DP7 what it proposes actually renders through the shipped generator', () => {
  withRepo({ 'styles/tokens.css': TOKENS }, (d) => {
    const r = JSON.parse(run(d).out)
    const out = render({
      version: 1,
      brand: { name: 'ACME', tagline: 'derived', eyebrow: 'ACME', homepage: 'https://example.com', palette: r.palette },
      pills: [{ file: 'v.svg', label: 'V', value: '1', scheme: 'accent', source: false, why: 'fixture' }],
      banners: [{ slug: 'src', dir: 'src', title: 'src/', desc: 'source' }],
    })
    for (const [k, svg] of Object.entries(out)) {
      assert.match(svg, /^<svg /, `${k} renders as an SVG`)
      assert.ok(!svg.includes('undefined'), `${k} contains "undefined" — a role the generator reads was missing from the proposal`)
    }
  })
})

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
