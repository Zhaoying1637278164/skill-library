# [![docs/: The reference tree · how it works, and why it refuses](../.github/assets/banners/docs.svg)](https://github.com/runverdict/repo-standard-toolkit)

**The depth behind the front page.** The [README](../README.md) is the hub and stays short; these
six pages carry the detail, one concern each. Nothing here repeats the README, and nothing here
is optional reading twice: if a question survives the front page, it is answered on exactly one
of these.

Every page below is governed prose. The voice ban, the placeholder sweep, and the TODO sweep run
over this directory on every push, and `RS-index` holds this table itself: each row has to link a
file that exists, and no document can appear under `docs/` without a row here. The same check
holds five other directories in this repo, which is the point of it: an index is not a docs
feature, it is what any directory owes a reader.

## The catalog

Reconciled against the code: 2026-07-31 (agent sweep)

| File | What it is for | Status |
|---|---|---|
| [`atlas.md`](atlas.md) | The atlas pillar's reference page: the measured failure that motivated it (a hand-written index naming 33 of 101 files), the recorded directory model (one index per directory, a declared child as a boundary, the repository's own file universe), the fixed row grammar handed to every agent in the fan-out, why that fan-out is a consent gate, why structural completeness is not accuracy, and the structural properties `RS-index` holds against the accuracy it cannot. | `active` |
| [`configuration.md`](configuration.md) | Key-by-key reference for `.repo-standard.json` and the canon-versus-scope split that decides what a repo may tune. Covers the count claims, the `prose` and `assets` blocks, the index catalog with its status vocabulary, scope, ordering, reconciliation dates and recorded declines, the ignore ruleset, and the off switch that has to print its reason. | `active` |
| [`design.md`](design.md) | The decision record: the principle that enforcement never depends on the agent, the product boundary the toolkit refuses to cross, the rejections it made on purpose with the reason each one lost, what hand-indexing this repo taught the row grammar, and three journeys that are designed but not built. | `active` |
| [`enforcement.md`](enforcement.md) | Layer-by-layer account of what polices a governed repo: what the scaffold installs, the table of every lint check, what each named skip means, the branch ruleset that makes the CI check the only thing blocking a merge, and the pre-push hook that says out loud it is a convenience rather than a gate. | `active` |
| [`identity.md`](identity.md) | Reference for the generated banner and pill pillar: fixed geometry over a fifteen-role palette, where a palette may come from and why the deriver exits non-zero rather than inventing one, the preview that precedes any write, the three legs of `RS-assets`, and the forked generator it cannot rule out. | `active` |
| [`voice.md`](voice.md) | Reference for the writing pillar: the always-on marketing ban set against the opt-in `enterprise` profile, why the filler family reaches markdown only while the dash rules reach as far as the scan does, what the profile never touches, and the guided sweep that has to clear a repo before the lock. | `active` |

`Status` answers one question: does this page still describe the system as it is? The reconciliation
line above the table is the freshness signal, and it is a fact this repo records rather than one
any tool derives. The lint checks that the line is there and well formed, never how old it is.

This table was previously dated per row, and the switch to one line is the argument in
[Configuration](configuration.md#reconciled-against-requiredate) meeting its own evidence: all five
rows carried the same date, and four of them named a day before the bytes they described existed.
