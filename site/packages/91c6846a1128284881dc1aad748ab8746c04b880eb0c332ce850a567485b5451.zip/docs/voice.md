# Voice

The writing standard, as a check rather than a style guide. A style guide is a document people
mean to follow; `RS-prose` is a build that goes red. The difference matters most on the prose
nobody re-reads, which is most of it.

Run the adoption with `/repo-standard-toolkit:voice`. It is an offer, and the order is fixed:
**sweep first, lock second.** A profile switched on over unswept prose is a red build tomorrow
morning.

## Two layers

The toolkit ships two writing rules, and they are deliberately separate checks.

| Check | Scope | Default |
|---|---|---|
| `RS-voice` | the marketing-language ban: "simply", "seamless", "world-class", "cutting-edge", and the rest | always on, canon |
| `RS-prose` | the enterprise writing profile: dashes and filler | opt-in per repo |

The marketing ban is on everywhere because nobody defends "revolutionary" in a README. The
profile is opt-in because prose style is a house choice in a way that "your CHANGELOG must parse"
is not, and because switching it on mid-life reddens a repo's whole back catalogue at once.

## The `enterprise` profile

Two rule families, both canon once the profile is on. Config chooses whether the profile applies
and how far it reaches, never what it contains.

### No em dash, in any form

The character, its HTML escapes (`&mdash;`, `&#8212;`, `&#x2014;`), and an en dash doing the same
job (spaced, as punctuation between clauses).

The rule is not typographic fussiness. An em dash is usually two sentences avoiding a decision,
and the fix is to make the decision: a colon when what follows explains what came before, a full
stop when it is a second thought, parentheses when it is genuinely an aside, a comma for a short
apposition. **Substituting other punctuation is not a fix**, and a semicolon in the same slot is
the same sentence wearing a disguise.

An en dash inside a numeric range is untouched, because that is what an en dash is for. A double
hyphen is deliberately not flagged: every command-line flag in every docs page would trip it, and
a detector that cries wolf gets disabled, which enforces nothing at all.

### No filler, and no AI-writing tells, in markdown prose

`delve`, `utilize`, `leverage`, `in order to`, `worth noting`, `it should be noted`,
`needless to say`, `as you can see`, `furthermore`, `moreover`, `a wide range of`,
`a variety of`, `state-of-the-art`.

**This family reaches markdown only, whatever `prose.scan` says.** The asymmetry is deliberate.
In source, `leverageRatio` is an identifier rather than register, a fixture may hold "delve" as
data, and the file that declares the ban list necessarily contains every word in it. A rule that
fired on all of those is a rule people learn to switch off, and a switched-off rule enforces
nothing. Register is a property of prose, so it is checked where prose lives. Dashes have no such
problem and reach as far as the scan does.

Small and deterministic on purpose. Every term is one a careful writer can always cut or replace,
so a hit is never a judgment call: "utilize" is "use", "in order to" is "to", "a wide range of"
is a number you can check, and "it should be noted that" is nothing at all. Terms that would need
part-of-speech judgment to adjudicate are banned outright and lifted per repo through
`prose.allow`, one term at a time, with a reason that prints on every run.

Multi-word terms are matched across line breaks, because a hard-wrapped paragraph splits "in
order to" over two lines and a per-line scan would report the repo clean.

## What the profile does not reach

- **Quoted and backticked spans.** A doc that NAMES a banned term (a conventions file listing
  them, as it must) is a mention, not a use.
- **Fenced code blocks**, in markdown.
- **Released CHANGELOG history.** The scan stops at the first dated version, by canon and in both
  tools. Rewriting what already shipped to satisfy a profile adopted later would falsify the
  record the file exists to keep.
- **The license file.** A legal instrument reproduced verbatim, where "rewrite that sentence" is
  not an option a repo has. The same reasoning usually makes `CODE_OF_CONDUCT.md` the first
  entry in `prose.exempt`: the Contributor Covenant text is not this repo's prose.
- **Whatever `prose.exempt` names**, each with a reason that prints on every run. Applied
  migration history, vendored text, generated files, a fixture whose bytes are the test.

One exemption is worth naming in advance, because it is a question of provenance rather than a
workaround: `CODE_OF_CONDUCT.md`, when it carries the Contributor Covenant. That text is
reproduced verbatim from an external standard, and editing it would misrepresent what the repo
says it follows. Whether it currently trips a rule depends on the version: Covenant 3.0 contains
"In order to honor these values" and shows up in a scan; Covenant 2.1 contains no banned term and
no dash, and does not. Check the scan before proposing the entry, and if the file is clean, say
so: an exemption for a file with nothing to exempt is a line printed on every run forever.

Nothing else this toolkit installs needs one. **Every payload file is profile-clean at every
reach**, the lint's own commentary included, and its dash detectors are written with escapes so
that no rule's source matches itself. A repo reaching `all` is never asked to exempt a file it
did not author, because an exemption for the checker's own text would be permanent noise in
every consumer's lint run.

## Reach

| `prose.scan` | What it sweeps |
|---|---|
| `docs` (default) | the governed meta docs plus anything in `docs.extra`: the prose a stranger reads |
| `markdown` | every `.md` in the tree, folder READMEs and design notes included |
| `all` | every text file: comments, strings, and data too |

`docs` is the governed meta docs, which is not the same set as a `docs/` directory: the six root
files plus whatever `docs.extra` names, and nothing else. A repo that keeps a documentation tree
covers it by naming those pages in `docs.extra`, which is bounded, or by widening the scan, which
is not. The scan says how many markdown files it left behind rather than letting the option name
imply the coverage.

Three structural exclusions are not configurable, because none of them is a judgment call: `.git`
is not content, `node_modules` is not this repo's writing, and a binary file has no prose. Every
other exclusion goes through `prose.exempt`, where it can be seen.

## The guided sweep

`harness/voice-scan.mjs` is the finder. The lint answers "is this repo clean?" with a single
failure, because that is what a gate is for; bringing an existing repo up to standard needs the
opposite shape, which is every hit at once, grouped by file, with enough context to rewrite the
sentence without opening it blind.

```bash
node harness/voice-scan.mjs --target . --summary              # the totals, a few hundred bytes
node harness/voice-scan.mjs --target . --scan markdown --summary   # price another reach
node harness/voice-scan.mjs --target . --files-only           # the worst-first file table
node harness/voice-scan.mjs --target . --file README.md       # one file's hits
node harness/voice-scan.mjs --target . --json                 # everything, for a machine
```

It reads the repo's own declared scope when there is one, so a pre-adoption sweep looks exactly
where adoption will look. Exit 0 is clean, exit 1 means hits.

The narrow forms are the point rather than a convenience. A wide reach on a large repo is
hundreds of kilobytes of hits, and an agent harness truncates from the tail, which is exactly
where a report puts its total. So the totals line prints first as well as last, the JSON carries
its `counts` block ahead of the `hits` array, and the sweep is driven from the file table and
then file by file. `--limit` caps the hits shown per file and is off by default: a silent cap
would turn a loud truncation into a quiet wrong answer, so when it is on, what it dropped is
stated in both forms.

The scan is also the sweep's completion condition. RS-prose reports one hit per run because a
gate stops at the first failure, so re-running the lint to find the next sentence is one
invocation per sentence; re-running the scan reports everything still outstanding at once. The
lint runs at the end, once, to confirm.

The skill then rewrites file by file with the operator approving the diffs, documents the
vocabulary in CONVENTIONS (`RS-reflexivity` requires it, on the grounds that a rule about to fail
a contributor's build has to exist somewhere they can read it), and only then writes the `prose`
block. The hard rule of the whole phase: **preserve meaning**. A rewrite that changes what a
sentence claims has introduced a factual error into documentation under cover of a style pass.
When a sentence resists, it gets left and listed for the operator.

## One standard, two tools

The sweep engine and the lint carry the same rule lists as hand-maintained twins, because the
lint ships into target repos as one self-contained file and cannot import a shared module.
`acceptance/test-voice-canon.mjs` parses both files and fails the build if the lists ever differ,
in either direction. A twin that drifted would report a repo clean and then fail its build, which
is the worst outcome this feature has.
