# Atlas

Every directory says what each file in it is for, file by file, in one voice, and the committed
lint holds the result. The name is deliberate: not a summary of a repository, a map of it, at the
scale where each thing has a name.

Run the adoption with `/repo-standard-toolkit:atlas`. It is an offer, and so is the largest thing
it does.

## The gap it closes

A folder README written the ordinary way describes a directory from the outside. Somebody lists
what is in there, writes a paragraph, and picks out the files that came to mind. The result is a
table, and a table reads as complete.

This was measured rather than supposed. Running the identity journey against a real repository
produced an `acceptance/README.md` presenting a table that named **33 of 101 files**, drawn from
a directory listing by a step that had never opened any of them. Nothing was wrong with any row.
Nothing said the other sixty-eight existed. That is the confident lie this product exists to
catch, produced by this product, which is why the pillar exists.

Two things follow, and they are the whole design. Rows are written from the FILES, which means
reading all of them, which means a fan-out. And coverage is a CHECK, so a file added tomorrow
reddens the build until somebody says what it is for.

That second sentence has a scope, and the scope is a setting. Under the default, `"ownership":
"declared"`, the check holds an index to the files its own declaration reaches: add a `.mjs` to a
directory indexed for `.mjs` and the build reddens, add a `Dockerfile` and it does not, because an
extension list is the operator's own answer about what they wanted described. Under `"ownership":
"strict"` the sentence holds over every kept file in every directory the model reaches, and that
mode is what the rest of this page builds toward. Two places the model does not reach, stated here
and printed on every strict run rather than left to be discovered: a file at the repository root,
which no declaration can reach because an index lives inside the directory it catalogues, and a
file under a dot-directory, which is excluded the way `assets.coverage` excludes one.

## The directory model

"Every directory has a glossary of itself" needs a decision behind it, because the sentence has
several readings and the difference between them is thousands of rows. This is the one the
toolkit takes.

**One index per eligible directory, owning the files directly in it.** A declared index is the
authority for its own directory, and a nested directory that wants a glossary declares its own.
That is `"scope": "direct"`, and it is what the atlas journey declares on every new index.

**A declared child index is a boundary, not an overlap, and the boundary runs over FILES.** Every
kept file has exactly one owner, and that owner is the deepest declaration which actually claims
it. Nothing is inferred from the filesystem here, only from what the config declares. Before this
was derived, the parent had to hand-write an `ignore` entry restating what the declarations
already implied, and a repo that forgot ended up demanding every nested file appear in two tables
at once.

Drawing the boundary at the child DIRECTORY instead was the same mistake in the other direction,
and it was worse, because it was silent. A parent speaking for `.json` and a child speaking only
for `.md` left every `.json` under the child owned by nobody: not missing from the parent, not
claimed by the child, catalogued nowhere, and green in both tables and in CI. A file could be
added to that directory and vanish from every coverage claim the toolkit makes. An index is a
declaration rather than content, so no index catalogues another, and one file appearing in two
tables is a check of its own.

**A file no declaration claims is undecided, and undecided is not covered.** The gate names those
files in a skip rather than failing on them, because a repo indexing its markdown and not its
images has said what it wanted and reddening that would impose a scope nobody gave. `["*"]` is the
selector for a directory that should be covered completely: an extension list cannot reach a
`Dockerfile`, a `Makefile`, or an extensionless script, and this repo's own `payload/hooks/pre-push`
sat in an indexed directory carrying a row that nothing enforced until the selector existed.

**Recursive stays supported, as an explicit exception.** `"scope": "recursive"` is the default,
because it is what every configuration written before this decision already means, and a default
that reddened every existing adopter on upgrade would be a migration wearing a bug fix's clothes.
This repo's own `payload/README.md` is recursive on purpose: the directory ships one payload, and
splitting it across six catalogs would describe the plumbing rather than the thing.

**Eligibility is an offer, and a decline is durable.** A directory holding kept files that no
index speaks for is a candidate, and candidates are offered with their size attached, never
adopted. Keeping a README was never the rule, and treating it as one is how the pillar missed its
own north star: an ignored build directory with a README was offered as work while a kept source
directory without one was passed over in silence. A directory
nobody should have to read is a directory that should not get an index: a glossary of three
config fragments is decorated nothing. A no is recorded per directory in `docs.declined` with its
reason, so it survives the session that produced it. It is deliberately not a repo-wide switch,
because one excluded leaf should not cost a repository the offer everywhere else, and that is
exactly what happened on the first tree this met.

**The file universe is what the repository keeps.** Tracked files, plus the ones git does not
ignore. A build directory, a virtualenv, a vendored tree: none of them are files anyone should
have to describe, and demanding rows for them is how an honest adopter concludes the check is
unusable and switches it off. Where git cannot answer, nothing is excluded, which demands more
rows rather than fewer: the fallback can make the check noisier and can never let a gap through.

**The index goes where a reader lands.** GitHub renders `README.md` inline when someone browses a
directory, and `INDEX.md` takes a click. So the catalog is the README, and adopting a directory
means its existing README gains a table rather than growing a second catalog beside it. The one
case that breaks is a README that is itself one of the artifacts the directory ships, which
`payload/templates/README.md` is, and no engine can tell that from the outside. So it is asked.
Where a catalog already sits at `INDEX.md` and the README slot is free, the move is offered with
its whole change set attached: the rename, the declaration, the `docs.extra` entry, and the
inbound references. A rename that leaves dangling links is worse than no rename, because the page
is gone and every reference to it now lies.

Those references come back as two sets rather than one, because they are two different jobs.
Verified markdown links are what a rename has to repoint. Everything else naming the path is
prose, a fenced example, or a released CHANGELOG line, and each is a judgement a person makes:
rewriting a released section would falsify the history the file exists to keep.

The line between the two sets is drawn by what a reader can SEE, and it fails towards the second
set. A link is only a link when its opening bracket sits somewhere markdown renders (not a fence,
not a code span, not an HTML comment, not a `<pre>` block, not indented code), when it closes, when
it is a link rather than an image, and when nothing in a changelog can claim it. Where a code span
sits inside the link's own LABEL is the author's business and changes nothing, which is the case a
whole-link overlap test got wrong on a real repository's front page. A bare basename in the index's
own directory counts only where it is written as a path, which drops an unrelated sentence that
happens to contain the same two words and, deliberately, a genuine mention in flowing prose too.
Until an applier
parses markdown rather than matching strings, this journey repoints the links it verified and
reports the rest. **Leaving the page where it is** is a real answer, recorded as `retain` on the
declaration with its reason. Without somewhere to write that down the offer returned on every run
forever, and a decision somebody had made was indistinguishable from one nobody had.

## The row grammar is the contract

Many agents writing descriptions produce many voices, which fights the consistency that is the
entire point. What makes the fan-out work is that the shape is fixed before anyone writes a word,
and only the reading is agentic. Deterministic contract, agentic execution.

The grammar was drafted, then handed to three agents who indexed this repository by hand, each
reading every file it wrote a row about, each asked to report where the contract failed to decide
something for them. A contract handed to a hundred agents resolves its ambiguities a hundred ways,
so those answers are now in the contract rather than in each agent's judgment:

| The question | The answer, fixed |
|---|---|
| Where does the link point? | At a path relative to the **index**, never to the repo root. From `skills/README.md` the target for `skills/scaffold/SKILL.md` is `scaffold/SKILL.md`. The instinct resolves to `skills/skills/...` and fails both coverage and resolution. |
| What is the link text? | That same path, in backticks. Not a title invented for it: the file is what the row is about, and a title is what the description cell is for. |
| Which files need a row? | Every file matching **that index's** declared `extensions`, minus the index and anything under its `ignore`. Not "every file". A file with no extension can never match an extension rule, so it is never required, though it may be given a row anyway. |
| Which file is the index? | Not always the README. `payload/templates/README.md` IS a template, one of the files that directory ships, and an agent following "the index is the directory's README" would overwrite it. Where the README is taken, the catalog becomes `INDEX.md` and the README gets a row like anything else. |
| How does a nested index open? | With a plain `# <dir>/`. `assets.coverage.roots` is one level deep by design, so a nested directory has no banner, and adding a manifest entry to give it one is not the atlas's call. |
| In what order? | Ascending path order. Mandated rather than chosen: it is the only order a different agent reproduces on a later run, and a re-sort produces a diff that reads as a rewrite. |
| What does a cell not contain? | A raw `|`, which bites immediately on any file whose usage string carries one. Write `\|`. No line breaks either. |

The description cell has a grammar too, because a length band and an opening pattern are what
stop one agent writing forty characters and another writing nine hundred. One to three sentences,
120 to 400 characters, grounded in what the file contains. A file that DOES something when run or
imported opens with a third-person present verb; a file that IS something when read opens with a
noun phrase. That choice is derivable from the file, so it lands the same way across a fan-out.

## The fan-out is a gate

No fan-out begins without an explicit approve or deny, and the offer states the size **before** it
happens: how many directories, how many files, how many lines, roughly how many agents. Those
numbers come from `harness/index-plan.mjs` rather than from the skill's own estimate, because a
tool that guessed at the figure the operator is agreeing to has misunderstood what the agreement
is for.

The capability is assumed. These toolkits run where a fan-out of that size is real work rather
than an aspiration. **The consent is not.** The reasoning behind that rule, and why it was fixed
before any of this code existed, is in [Design](design.md#a-fan-out-is-a-gate).

A decline is not a failed step, and the journey has somewhere to go on every one of them: a
narrower scope, the gaps alone rather than a full re-read, or a hand-off of the grammar and the
file list. A per-directory no goes in `docs.declined` with its reason and is a finished answer. A
repo-wide decline is recorded only when the operator asks never to be asked again, because
`declined` is terminal in sense-state and a pillar walking away is not the same thing.

## Complete is not the same as accurate

The planner answers three questions and reports them separately, because collapsing them is how a
sweep silently skips a directory it was asked to check.

**Structural work** is what is missing: files with no row, rows pointing at a file that is gone, a
file catalogued twice by one index or by two, a row reaching outside the directory, a link that
never closes or cannot be decoded, an index that does not exist yet, a directory holding kept
files no index speaks for, an index sitting where a reader browsing the directory never finds it.
This is what the exit code carries, and it is all the exit code carries. **Undecided files are
reported beside it and deliberately not carried by it**, because the directory holding them has
been decided about and the operator's selector is their answer for it.

**The reconciliation plan** is what re-reading costs, whether or not anything is missing. Every
file the index speaks for, chunked into agents. It exists because an index can carry a row for
every file and have every row be false, and no check anywhere reads a description and knows it
still matches the code.

**Migration opportunities** are catalogs that would serve readers better somewhere else, offered
with the whole coordinated change set rather than as a rename to improvise.

Exit 0 therefore means no structural work. It does not mean the rows are true, and the planner
says so in those words on every run. This is not a hypothetical distinction: the first real sweep
this engine drove read a complete index as a finished one and skipped seventeen files and two
whole chunks, which was the whole directory the operator most wanted checked.

## What the lint holds, and what it cannot

`RS-index` holds these properties, and every one of them is structural:

- **Completeness.** Every file matching the declared extensions has a row. A directory that grows
  a file reddens the build until somebody says what it is for. This is the one the hand-written
  table fails.
- **Resolution.** Every row points at a file that exists. An index whose links have rotted is
  worse than no index: it reads authoritative and sends people nowhere.
- **Containment.** No row reaches outside the directory the index catalogues. A target written
  relative to the repo root instead of to the index is the most common way to get a row wrong,
  and it used to count as coverage for a file the index has no business speaking for.
- **Uniqueness.** No file is catalogued twice. Two rows for one file means two descriptions to
  keep true and no way to tell which is authoritative; held in a map, the second silently won.
- **Presence and shape.** Every row states a status the index declared, matched by the word the
  cell begins with once backticks and emphasis come off, so `` `ACTIVE` (paused) `` is a repo
  saying something true about its own document rather than a lint failure.
- **Order, once declared.** With `"ordered": true` the rows sit in ascending path order. It is
  the only order a later sweep reproduces, so the next run over the directory produces a diff
  instead of a rewrite that buries the one row that changed among a hundred that did not.
- **Governed prose.** Every declared index appears in `docs.extra`. An index no sweep reaches is
  the one page in its directory that can rot with nothing here noticing.
- **The universe itself.** Every one of the properties above is a statement about a SET, so the
  set is checked before anything is judged against it. A path git keeps that the engines cannot
  see is named and fails: a sparse or skip-worktree entry (tracked, in HEAD, deliberately not
  materialised), a filename whose bytes are not valid UTF-8, and a tracked file somebody deleted
  without staging the removal. Each of those turns "every file has a row" into a true sentence
  about a smaller repository than the one git tracks, and the last one is the common case: an
  ordinary `rm` used to take an uncatalogued tracked file out of the set and turn a red build
  green. A submodule is excluded, because it is another repository's whole content and neither
  this pillar nor the identity pillar governs one. A STAGED deletion needs no exclusion: `git rm`
  takes the path out of the index, so it never enters the universe in the first place.

Those four in the middle were verified by hand on a real repository and held by nothing, which is the
reason they are on this list. A table can be green, ambiguous, and wrong about its own scope all
at once, and reading it carefully was the only thing standing in the way.

**Under grammar 2, a check reads the column its header names, and a missing header is a gap.**
That is the whole difference from version 1, and it took two passes to actually mean it. The link
itself is read from the FILE column, so a row with an empty file cell and a link in its
description is not a catalog row; a table declaring statuses with no status column is reported
rather than allowed to fall back to reading every cell, because the fallback silently restores the
version-1 rule the index opted out of; and the same holds for a verification date under a header
that does not say the file was verified. A status column's header begins with `Status`, `State` or
`Lifecycle`; a verification-date column's header contains `verified`, `reconciled`, `checked`,
`reviewed` or `confirmed`.

**How much it holds is a setting, and the default is the smaller one.** The list above is a
contract between an index and the files its own declaration reaches. What it says nothing about
is the file no declaration reaches at all: a `Dockerfile` beside an index declared over `.mjs`, or
a whole new directory nobody has been asked about yet. Under the default that is a named skip and
a green build, on the grounds that an extension list is an answer and reddening it would impose a
scope nobody gave. It was reported by the planner as work and named nowhere by the gate, which is
the shape this standard exists to refuse, so both are now printed either way.

**And a repository sitting at zero is TOLD that the setting exists.** `strict` was computed as
available, printed in the sense report, and routed into no plan action, so an atlas with every row
written and every directory decided came back as `keep`, the scaffold read that as finished, and
the mode that turns this pillar from a description into a check was reachable only by invoking
Atlas by hand for some other reason. Two plan actions now carry it: `offer-strict` where the
repository would pass today (one config line, no fan-out, no Atlas run), and `offer-coverage`
where nothing structural is left and unowned files are the whole distance to being able to turn it
on. `ATLAS_STRICT_OFFER: declined` records the no, and it reads as `keep` from then on, because
under `declared` the operator's extension lists ARE their answer for the remainder.

`"docs.ownership": "strict"` makes them the verdict instead. Every kept file under a declared
index is owned by exactly one index, excluded by an `ignore` entry, or sitting under a directory
recorded in `docs.declined`, and every directory holding kept files that no declaration reaches
fails the build until somebody answers for it. Three answers close it, and all three are the
operator saying something rather than the toolkit assuming it: catalogue the file, ignore it with
the reason on the page, or decline the directory with the reason on the page.

It is opt-in because turning it on is a migration rather than a fix. A repo adopts it once its
atlas is complete, which is the point at which the promise at the top of this page becomes a
sentence the build keeps. This repository runs under it. It enforces the same way **before the
first index exists**: a repo declaring `strict` and no index is a repo where nothing is owned by
anything, and every directory holding kept files fails until it is declared, ignored, or declined.

**Two sets of files sit outside that model, and they are named rather than passed.** A file at the
repository ROOT cannot be owned, because an index lives inside the directory it catalogues and
there is no declaration that could reach one; the root's own pages are governed by `RS-readme`,
`RS-changelog` and the rest instead. A file under a DOT-DIRECTORY is excluded the way
`assets.coverage` excludes one, since those directories hold tooling a reader does not browse, and
declaring an index for such a directory brings it inside like any other. Under `strict` the gate
prints `RS-index (ownership boundary)` on every run, with the count and the paths, whether or not
anything is in it. Both were silently green before that line existed, which made "every kept file"
a phrase neither engine kept. The qualifier travels with the claim, because an exclusion nobody
prints reads exactly like coverage.

**Which table the checks read is a declared grammar.** Under `"grammar": 1` (the default) any line
starting with `|` is a candidate row and any cell answers for anything, so an unrelated table whose
rows link files counts as coverage, a description beginning with a status word satisfies the status
rule while the status column is empty, and a date in any column answers for a blank verification
column. `"grammar": 2` binds each check to the column the header names. The default is the weaker
one because changing what a row means under an existing adopter is a migration, and the gate prints
`RS-index (grammar)` naming the difference on every run it is in force. A table inside a code fence
is an example under both, and its rows were never coverage.

**It cannot hold accuracy.** No lint reads a description and knows it still matches the code. A
row that was true when it was written and is false today passes every check there is. That limit
is stated here, in [Configuration](configuration.md), and in the skill's own recap, rather than
left for a green check to imply.

The reconciliation date is the honest half of the answer. One line above the table,
`Reconciled against the code: YYYY-MM-DD (agent sweep)`, naming the day every row was written or
re-verified against the file it describes and who did it. The lint checks the line is there and
well formed, **never how old it is**: a check whose verdict changes overnight is the
calendar-dependent failure this toolkit refuses everywhere else. The parenthetical is a
convention of this journey rather than something the lint enforces, and `(by hand)` is the other
value. A later partial edit changes neither the date nor the parenthetical, because the claim is
about the whole index and editing three rows does not reconcile it.

## Lying headers are an output, not a side effect

Writing a row about a file turns out to be the most reliable way anyone has found to notice the
file's own header is lying. Indexing this repository by hand found four of them, recorded in
[Design](design.md#what-indexing-this-repo-by-hand-taught); the first fan-out found six more, in
the suite that polices everything else.

No check the toolkit has would have caught any of them, because no lint reads a comment and knows
it is false. So the sweep reports them as a first-class result, with both quotes, and **proposes
rather than applies**: some of them will turn out to be the code that is wrong. The same treatment
goes to any file an agent could not read in full, which is named rather than given a confident row.

## The vocabulary is canon

`active`, `superseded`, `reference`, `design`, `delivered`. Canon rather than scope, so that two
governed repos are comparable rather than merely similarly shaped. A repo with an established word
of its own keeps it on the page through `aliases`, which map that word onto the canon: the reader
sees `HONEST-ARTIFACT`, the lint reads `reference`.

**Case is free once, when the config declares the subset, and fixed everywhere after.** A page
writing `REFERENCE` is using the canon word in its own register, so declaring it that way is
accepted. Matching a cell is then **case-sensitive against the spelling that was declared**, which
is what stops one index drifting between `Active` and `ACTIVE` and passing as both. The rule that
matters for a fan-out is the second half: every agent writing rows is handed the declared spelling
and reproduces it exactly. The full configuration surface is in [Configuration](configuration.md).
