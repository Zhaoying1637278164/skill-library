# Configuration

`.repo-standard.json`, operator-owned, reconciled (never regenerated) on re-runs. A missing file
still runs the full hardcoded canon, with default scope (no counts, no extra sections); the
scaffolder ships a stricter starting config. Keys starting with `//` are comments. Unknown keys
are hard errors, so nothing is silently ignored.

The canon-versus-scope split is the whole design: the standard itself (the six Keep a Changelog
categories, License-last, the voice ban, the writing profile's word lists, the contrast floor)
lives in the lint and cannot be configured away. The config selects which docs are governed,
which numeric claims are machine-checked, which pillars are active, and how far each one reaches.
It can only ever add, except through the one loud off switch described below.

## The surface

```json
{
  "version": 1,
  "docs": {
    "//extra": "every declared index has to be listed here, or RS-index fails: an index no prose sweep reaches is the one page in its directory that can rot unnoticed",
    "extra": ["docs/enforcement.md", "docs/README.md", "acceptance/README.md"],
    "indexes": [
      { "file": "docs/README.md", "statuses": true, "requireDate": true },
      {
        "file": "acceptance/README.md",
        "extensions": [".mjs"],
        "scope": "direct",
        "statuses": ["active", "HONEST-ARTIFACT"],
        "aliases": { "HONEST-ARTIFACT": "reference" },
        "reconciled": true,
        "ordered": true,
        "ignore": ["acceptance/fixtures"]
      }
    ],
    "declined": [{ "dir": "harness/zap", "why": "one scanner config nobody browses" }]
  },
  "manifest": { "file": "COPY-MANIFEST.md", "statuses": ["UNCHANGED", "MODIFIED", "NEW"] },
  "readme": { "requireSections": ["usage", "caveat|limitation"] },
  "conventions": { "minSections": 7 },
  "voice": { "extraBanned": ["frictionless"], "properNouns": ["Seamless Deploy"] },
  "prose": {
    "profile": "enterprise",
    "scan": "docs",
    "exempt": [{ "path": "CODE_OF_CONDUCT.md", "why": "the Covenant text is reproduced verbatim" }],
    "allow": [{ "term": "leverage", "why": "this repo means the financial noun" }]
  },
  "assets": { "dir": ".github/assets", "coverage": { "roots": ["apps"], "ignore": ["apps/legacy"] } },
  "github": { "about": { "description": "The line this repo synced to its About panel.", "topics": ["repo-hygiene"] } },
  "ignore": { "generated": ["dist/", "coverage/"], "allowExamples": [".env.dist"] },
  "counts": {
    "standing-tests": {
      "pattern": "(\\d[\\d,]*)\\s+standing tests",
      "glob": "acceptance/test-*.mjs",
      "minMentions": 2
    }
  },
  "checks": { "lockstep": { "enabled": false, "why": "printed loudly on every run" } }
}
```

## Counts, the anti-drift core

A numeric claim in prose is bound to a derivable fact (a file glob, a line-regex count over a
source file) and to every other doc stating it, so a forgotten update reddens the build instead
of shipping a lie. Each count declares a `pattern` whose first capture group is the number, plus
a source of truth: `glob` (literal directories, `*` only in the basename, deliberately tiny so
the enforcement stays auditable), or `file` and `lineRegex`, or neither for
cross-doc-agreement-only numbers. `minMentions` requires the claim to appear at least N times;
`docs` restricts which docs are scanned; `under` scopes the scan to one heading's region, so a
historical number inside a dated CHANGELOG release block stays history instead of failing forever
once the live count moves on.

## `prose`, the writing profile

`false` or absent is the default, and the check prints a named skip rather than a silent pass.
Set it to opt in. `profile` is the only rule set today (`enterprise`); `scan` chooses the reach
(`docs`, `markdown`, `all`); `extraBanned` adds house terms, which `RS-reflexivity` then requires
the CONVENTIONS doc to document; `exempt` and `allow` are the two escape hatches, and both print
on every run. An `allow` entry can lift a single filler term and nothing else: the dash rules
cannot be allowed away, because a profile whose headline rule can be switched off one entry at a
time is not a profile. See [Voice](voice.md).

## `docs.index` and `docs.indexes`, the catalog a directory keeps of itself

`false` or absent is the default. `docs.index` declares one index; `docs.indexes` declares a list.
Declaring both is a config error, and both spellings normalise to the same list, so a repo that
started with one catalog grows a second without rewriting the first. An index catalogues the
directory it lives in, which is why `file` has to contain a path separator: `docs/README.md`
indexes `docs/`, `acceptance/README.md` indexes `acceptance/`.

The shape on the page is a table with one row per file, saying what the file is for and what state
it is in. No column is named and column order is not fixed, so a catalog a repo already keeps
rarely needs restructuring to pass: a row is any table row carrying a link to a file under the
index's directory. A cell may contain a literal pipe as `\|`, and a link destination may use the
angle-bracket form, `[text](<two words.md>)`, which is the only way to write a path with a space
in it.

Two rules apply to every declared index, with nothing to switch on. A row may not point **outside**
the directory the index catalogues, because a target written relative to the repo root instead of
to the index is the commonest way to get a row wrong and it used to count as coverage for a file
the index has no business speaking for. And no file may be catalogued **twice**, because two rows
for one file means two descriptions to keep true and no way to say which is authoritative.

Every declared index must also appear in `docs.extra`. An index no prose sweep reaches is the one
page in its directory that can rot with nothing in the toolkit noticing, so this is required
rather than advised.

**Upgrading into this rule is breaking, and the config line is the cheap half.** A repo that
declared an index before the rule existed adds one entry and the config is valid again; what
follows is that the page now enters the voice, prose, TODO, and placeholder sweeps for the first
time, and a table nobody swept can carry a lot of drift. Run the lint before committing to the
upgrade, read the failures on that page as a batch rather than one at a time, and expect prose
work rather than a one-line edit. Adding the entry and discovering the size of that afterwards is
the wrong order.

### `scope`, and where one index stops and the next begins

`scope` is `"recursive"` (the default) or `"direct"`. Direct means the index owns the files
directly in its directory and a nested directory keeps its own catalog, which is the model the
atlas journey declares on every new index. Recursive is the default because it is what every
configuration written before this key existed already means.

Either way, **ownership is per file, and a file's owner is the deepest declaration that actually
claims it**. Nothing here is inferred from the filesystem, only from what the config declares. A
declared child index is still a boundary its ancestor stops at, but the boundary runs over the
files the child CLAIMS rather than over its whole directory. That distinction is load-bearing: a
parent speaking for `.json` and a child speaking only for `.md` left every `.json` under the child
owned by nobody, catalogued by nobody, and green in both tables and in CI. A file could be added
to such a directory and disappear from every coverage claim the toolkit makes.

An index is a declaration, not content, so no index catalogues another. Two indexes declaring the
*same* directory is a config error, because then neither is authoritative, and one file appearing
in two different tables is a check of its own for the same reason.

A kept file that no declaration claims is **undecided**, not covered. Under the default ownership
mode, `RS-index (unowned)` names those files in a skip rather than failing on them: a repo that
indexes its markdown and not its images has said what it wanted, and reddening that would be this
toolkit imposing a scope nobody gave it. What it is never allowed to be is silent, because "no
missing rows" over a set nobody chose reads exactly like coverage. A directory holding kept files
that no declaration reaches at all is named the same way, by `RS-index (undecided directories)`.
Answer either by widening `extensions` (see `["*"]` below), adding an `ignore` entry, giving the
directory its own index, or recording it under `docs.declined`.

### `docs.ownership`, and how much the gate may stay silent about

`"declared"` (the default, and what every configuration written before this key already means) is
the behaviour above: an index is held to the files its own declaration reaches, and everything else
is reported and not judged.

`"strict"` makes the undecided set the verdict. Every kept file under a declared index must be
owned by exactly one index, excluded by an `ignore` entry, or sitting under a directory recorded in
`docs.declined`, and every directory holding kept files that no declaration reaches fails the build
until somebody answers for it. Both checks are named `RS-index (ownership)`, and they are printed
when they pass as well as when they fail, because "strict ownership is on and every file is spoken
for" is the sentence the whole pillar exists to earn.

It is opt-in because turning it on is a migration rather than a fix: a default that reddened every
existing adopter on upgrade would be a migration wearing a bug fix's clothes, which is the same
reason `scope` defaults to `recursive`. Adopt it once the atlas is complete. This repository runs
under it, and the [Atlas](atlas.md) page describes what it buys.

Strict enforces the same way **before the first index exists**: a repo declaring `strict` and no
index at all is a repo where nothing is owned by anything, and every directory holding kept files
fails until it is declared, ignored, or declined.

**The boundary strict states, rather than pretends away.** Two sets of kept files sit outside the
ownership model in both modes, and both are named and counted rather than quietly passed:

- **Files at the repository root.** An index must live inside the directory it catalogues, so no
  declaration can reach a root-level file. The root's own pages are governed by `RS-readme`,
  `RS-changelog`, `RS-license` and the rest instead.
- **Files under a dot-directory**, excluded the way `assets.coverage` excludes them: those
  directories hold tooling a reader does not browse. A dot-directory that genuinely wants covering
  is brought inside by declaring an index for it, and is covered from then on like any other.

Under `strict` the gate prints `RS-index (ownership boundary)` on every run, with the count and
the paths, whether or not anything is in it. That line is the qualifier on the phrase "every kept
file", and it is printed because a silent exclusion reads exactly like coverage. The planner
reports the same set under `undecidedFiles.outsideModel`.

### `grammar`, and which table the checks are reading

`grammar` is `1` (the default) or `2`, and it decides how a page is parsed into catalog rows.

Under **version 1** any line starting with `|` is a candidate row, any cell may carry the link, any
cell may carry the status, and any cell may carry the date. That is an honest shape for a page
whose table has no headers, and it is the default because changing what a row MEANS under an
existing adopter is a migration rather than a fix. Three things it cannot see, each of which lets a
file look catalogued when nothing catalogues it: an unrelated table (a roadmap, a compatibility
matrix) whose rows happen to link files and carry a status word counts as coverage; a description
cell BEGINNING with a status word satisfies the status rule while the status column sits empty; and
a bare date in any column answers for a verification column that is blank. While version 1 is in
force the gate prints `RS-index (grammar)` naming exactly that.

Under **version 2** a catalog row is a body row of a markdown table (a header row, a delimiter row,
body rows) whose header names a file column, the status is read from the column whose header says
`status`/`state`/`lifecycle`, and the date from the column whose header says `verified`,
`reconciled`, `checked`, `reviewed`, or `confirmed`. A table with no file column is not a catalog
and its rows are not coverage. The atlas journey writes `File | What it is for | Status`, which
version 2 reads as intended, and every index in this repository declares `2`.

A table inside a **code fence** is an example of a table under BOTH versions, and its rows have
never been coverage. That was a plain defect rather than a version question, and it is fixed in
both engines regardless of what `grammar` says.

The file universe is what the repository keeps: tracked files, plus the ones git does not ignore.
A build directory or a vendored tree owes no rows. It is read NUL-delimited, because git C-quotes
any path outside plain ASCII (`docs/café.md` comes back quoted) and a filename can contain a
newline; a universe that missed those dropped the files entirely rather than reporting them. A
symlink is a kept file and owes a row, reported as a symlink rather than read through, since
following one would describe its target twice. A submodule owes nothing: it is another
repository's content. Where git cannot answer, nothing is excluded, which demands more rows rather
than fewer, so the fallback can be noisier and can never let a gap through. The coverage failure
names which universe it used.

### `retain`, a placement decision that survives the session

An index sitting somewhere GitHub does not render when a reader browses the directory, with
`README.md` free beside it, is offered a move. `"retain": "<reason>"` on the declaration is the
recorded answer that it stays. The reason is required, for the same purpose it is required on a
decline: without somewhere to write the decision down the offer returned on every run forever, the
planner's exit code never reached 0, and a choice somebody had made was indistinguishable from one
nobody had. It prints as a named skip, so the decision stays visible.

### `ordered`, so the next sweep produces a diff

Off until declared, and it prints a named skip while it is off. With it on, rows must sit in
ascending path order. That is the only order a later sweep reproduces, so the next run over the
directory produces a diff instead of a rewrite that buries the one row that changed among a
hundred that did not.

### `docs.declined`, a no that survives the session

`{ "dir": "harness/zap", "why": "one scanner config nobody browses" }`. The reason is required: a
recorded no with no reason cannot be told apart from an oversight later. Each entry prints as a
named skip on every run, so a decline is visible rather than silent, and a declined directory
stops being offered an index without anything else going quiet. It is deliberately per directory
rather than a repo-wide switch, because one excluded leaf should not cost a repository the offer
everywhere else.

### `extensions`, which is what makes this more than a docs feature

`extensions` defaults to `[".md"]`, the documentation case. Set it to `[".mjs"]` and a directory of
engines catalogues its engines. That one key is the difference between a folder README that
summarises whatever its author remembered and a glossary CI can hold to: a file added to the
directory reddens the build until it has a row. An index over `.mjs` is as ordinary as one over
`.md`. This repo dogfoods both, and [`acceptance/README.md`](../acceptance/README.md) is the worked
example: a real index over the standing engines, declared beside the docs index under
`docs.indexes` in `.repo-standard.json`.

`["*"]` means every kept file the directory holds, and it is the only selector that can promise a
directory is completely covered. An extension list cannot reach a `Dockerfile`, a `Makefile`, or
an extensionless script, so a directory catalogued by one is covered exactly as far as the list
goes and no further. Every other file is reported as undecided rather than passing as covered.

### The status vocabulary is canon, not scope

`statuses` is off until declared and prints a named skip while it is off. Set it to `true` for the
whole canon, or to an array drawn from it. The canon is `active`, `superseded`, `reference`,
`design`, and `delivered`, and it lives in the lint rather than in this file on purpose: a standard
whose vocabulary every repo invents leaves two governed repos with a shape in common and no
language in common. Which directories are governed is scope; what the words mean is canon, so the
indexes stay comparable across repos.

Case is presentation and needs no declaration. A page writing `ACTIVE` is using the canon word in
the register its own table uses. Matching is case-sensitive against the spelling the index
declared, so a single index cannot drift between `Active` and `ACTIVE` and pass as both. A
genuinely different **word** is what `aliases` is for: `{ "HONEST-ARTIFACT": "reference" }` keeps
`HONEST-ARTIFACT` on the page while the lint reads `reference`, so a repo with an established
vocabulary adopts the standard without rewriting either.

A status is matched by the word its cell **begins with**, once surrounding code-span and emphasis
marks come off. A cell reading `` `REFERENCE` `` matches the declared status `REFERENCE`, and so
do `` `ACTIVE` (paused) `` and `` `DELIVERED` v0.7.0 ``: a qualifier after the word is the repo
saying something true about its own document, not a second status to enumerate. What this is not
is a containment test: a purpose cell that happens to use the word `DELIVERED` in a sentence never
stands in for a status nobody set.

### `reconciled` against `requireDate`

Both are off by default, and an index declaring neither prints `RS-index (dates)` as a named skip:
nothing then records when that directory was last read against the code.

`reconciled: true` requires one line in the index reading `Reconciled against the code:
YYYY-MM-DD`, naming the day every row in that index was written or re-verified against the file it
describes. One date for a directory is usually the honest one, because it is what a sweep over
that directory can actually attest to. A date per row is a claim per row, and on the day the index
is written those dates are copies of one another wearing different faces.

**Say who did the reconciling**, in a parenthetical after the date:
`Reconciled against the code: 2026-07-31 (agent sweep)`, or `(by hand)`. The lint tolerates
trailing text and does not require this, so it is a convention of the atlas journey rather than a
rule the gate holds, and it is here because the alternative was worse. Once a fan-out can reconcile
forty directories in one afternoon, a bare date on all forty implies a kind of reading that did not
happen, and the fix is to name the reading rather than to soften the claim. **A later partial edit
changes neither the date nor the parenthetical.** The claim is about the whole index, editing three
rows does not reconcile it, and a line rewritten to cover work that was not done is the fabrication
the whole leg exists to prevent.

`requireDate: true` asks instead for a `YYYY-MM-DD` cell in every row, and it is for an index that
genuinely tracks each file separately. It defaults to `false` because an index recording no dates
is a common and honest shape, and defaulting it on would hand an adopting repo a red check whose
quickest fix is to invent the dates: the one outcome this leg exists to prevent.

Either way the lint never reads the clock. It checks that the date line is there and well formed,
never how old it is, which is the same clock independence the rest of this toolkit holds to: a
check whose verdict changes overnight fails a repo nobody touched. Deriving freshness from git
history instead is worse rather than better, because a repo handed over as a single squashed
baseline gives every file the same commit, which is exactly the moment a freshness signal earns
its keep.

### What a green `RS-index` earns, and what it cannot

Every property it holds is structural. **Completeness**: every file the index speaks for has a row,
or is listed in `ignore`. **Resolution**: every row points at a file that exists. **Containment**:
no row reaches outside the directory. **Uniqueness**: no file is catalogued twice. **Presence**:
the status and the date are there, in the declared vocabulary and a well-formed shape. **Order**,
once `ordered` is declared. **Governed prose**: the index is in `docs.extra`.

What it cannot hold is **accuracy**. No lint can read a one-line description of a file and know it
still matches what that file does. Accuracy is established when the index is authored and
re-established when it is next reconciled, by whoever does the reading, and a green check says
only that the structure held since then. Read the check that way rather than as a claim the
descriptions are true.

That boundary is also why no leg here grades the prose. A minimum description length would be the
obvious next check and it is deliberately absent: it is a judgment about writing dressed as a
number, a sixty-character row can be exactly right, and a build reddened by a heuristic teaches
people to pad rows rather than to write them. The authoring side is where description quality is
decided, which is [Atlas](atlas.md), and the contract there is a row grammar rather than a
threshold.

## `assets`, the generated identity

`false` or absent is the default. Set `{ "dir": ".github/assets" }` to declare that this repo
generates its README artwork from a manifest; the manifest and the generator are fixed filenames
inside that directory, because a generator that does not sit beside the manifest it renders is a
puzzle for the next maintainer rather than a configuration win. `coverage.roots` optionally
requires every immediate subdirectory of a root to carry a banner entry, with `coverage.ignore`
for the ones that should not; coverage is one level deep per root, so a nested directory is
policed by naming its parent as a root of its own. See [Identity](identity.md).

## `github.about`, the recorded panel

`false` or absent is the default. The scaffold skill writes here what it synced to the repo's
GitHub About panel, once the operator approved the sync: `description`, `topics`, and a
`homepage` when there is one. Only `description` is ever re-checked, against the README's own
tagline, so the panel cannot quietly go on describing a repo that has moved on. `homepage` and
`topics` are recorded provenance: what was applied, kept where a re-run can read it back. Omit
`homepage` when the repo publishes none of its own, and a `null` reads as absent for the same
reason; an empty string is a config error rather than a quiet way to record nothing. The lint
takes no network, so what GitHub is serving right now is unverified here, and the check says so
as a named skip on every run.

## `ignore`, the trust ruleset

The `.env` leg is canon and needs no configuration. What a repo declares here is `generated`
(paths that must be ignored AND untracked, so build output cannot pollute the tree) and
`allowExamples` (extra `.env`-family filenames a negation is allowed to re-expose, beyond the
`.env.example`, `.env.sample`, `.env.template`, and `.env.defaults` that are already permitted).
Every added example prints on every run.

## The off switch, and why it is loud

A check can be disabled only as `{ "enabled": false, "why": "<reason>" }`, and the reason prints
on every run. A bare `false` is a config error. `voice.properNouns`, `prose.allow`, `prose.exempt`,
and `ignore.allowExamples` all print on every run too. Nothing in this file can be silently
weakened: visibility is the price of every exception.

## Recorded provenance

A `scaffold` block, written by the skill and never by hand, records which plugin version produced
the repo's governance and the operator's confirmed answers. A re-run pre-fills its questions from
it and re-asks only what is missing, and the repo itself can answer which standard version governs
it, with the plugin gone.

It also records a **declined** offer (`IDENTITY_OFFER`, `PROSE_OFFER` set to `declined`).
`harness/sense-state.mjs` reads that back and reports the plan action as `declined` rather than
`offer`, so a no is durable without anyone having to remember the rule. The lint validates the
block's shape and never varies enforcement by it.
