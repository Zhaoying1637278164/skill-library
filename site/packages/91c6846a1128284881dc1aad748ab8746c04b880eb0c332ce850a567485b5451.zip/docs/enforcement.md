# Enforcement

What actually polices a governed repo, layer by layer. The short version: a committed,
dependency-free lint runs in CI on every push; an optional GitHub branch ruleset makes that
check required, which is the only thing that truly blocks a merge; an optional local pre-push
hook saves you the round trip to CI. Only the first two involve any enforcement, and the hook
says so itself.

## What gets installed

Into the target repo, all committed, all dependency-free:

- `acceptance/test-repo-standard.mjs`, the standing lint (the full check list below), copied
  byte-identical from this plugin's payload, never hand-edited into a target.
- `.repo-standard.json`, the repo's declared scope. See [Configuration](configuration.md).
- `.github/workflows/test.yml`, the gate: a read-only token running every
  `acceptance/test-*.mjs`. The workflow this toolkit ships triggers on push, pull request, and
  merge-queue events and pins its one action by commit SHA. Named `repo-standard.yml` instead
  when the repo already has workflows, and installed as the lint-only scoped variant when
  pre-existing acceptance tests are red, so the gate is never born red on someone else's tests.
  A repo whose own workflow already runs the suite keeps that workflow rather than gaining a
  second one, so on those repos the triggers and the pinning are whatever that file declares:
  an existing workflow is never edited in place.
- Ignore rules that make a secrets file unstageable, merged into whatever `.gitignore` the repo
  already had rather than replacing it.
- The meta docs themselves, where missing (README, CHANGELOG, CONVENTIONS, CONTRIBUTING,
  CODE_OF_CONDUCT, SECURITY, LICENSE), filled from templates, with every `TODO(scaffold)` marker
  resolved against the real repo before the gate lets them pass.

Two further sets are installed only by the journeys that own them, and only on a yes:
`.github/assets/` (the identity generator and its manifest) and a `prose` block in the config
(the writing profile).

## The checks

The canon is hardcoded in the lint; config tunes scope only. Exit 1 means the docs drifted (fix
the docs); exit 2 means the config is broken (fix the config); every skipped check is a printed,
named line, never a silent pass.

Exit 2 also covers one thing that is not the config: the gate refuses to run when the path it was
invoked as is not a regular file, or when that path's repository is not the repository the file
now running lives in. Node resolves a script's symlinks before running it, so a gate committed as
a link audits the tree it points INTO while reporting on the tree it was called from. Nothing
below can be true of a repository nobody asked about, so the refusal comes before the first check
rather than as one of them.

| Check | What it holds |
|---|---|
| `RS-config` | the config parses, is version 1, and carries no unknown or malformed keys |
| `RS-changelog` | Keep a Changelog shape: `[Unreleased]` on top, the six canonical categories grouped, dated semver headings in descending order, `[YANKED]` accepted |
| `RS-lockstep` | the newest dated CHANGELOG version equals the version manifest (dormant until a first release) |
| `RS-readme` | standard-readme structure: one H1, the bold tagline, required sections, spec section order, License last |
| `RS-conventions` | numbered `## N.` sections contiguous from §1, with no gaps and no duplicates |
| `RS-manifest` | a declared inventory doc's Totals line reconciles with its own table rows |
| `RS-voice` | the marketing-voice ban across the meta-doc set |
| `RS-prose` | the enterprise writing profile, when a repo declares one: no em dash in any form, no filler or AI-writing tells |
| `RS-counts` | every declared numeric claim equals the derived repo fact and agrees across docs |
| `RS-reflexivity` | the CONVENTIONS doc documents the enforced vocabulary (lint ⟺ spec) |
| `RS-stable-docs` | the stable meta files exist and open with an H1 |
| `RS-todos` | no `TODO(scaffold)` marker survives in a governed doc |
| `RS-license` | a root license file exists; a recognizable license text agrees with the JSON manifests' license fields and the README's License section |
| `RS-placeholders` | no unfilled template placeholder survives, fenced code included, because that is where hand-copied templates hide them |
| `RS-shadow` | no governed doc is duplicated across the GitHub-served locations (`.github/` > root > `docs/`), with README exempted from the `docs/` leg because a `docs/README.md` is a directory index rather than a second front page |
| `RS-about` | the recorded GitHub About still matches the repo's own README tagline. Offline by construction: it proves the record has not gone stale, never that GitHub is serving it |
| `RS-index` | the catalog a directory keeps of itself, for each index a repo declares: every file under it catalogued (`.md` by default, or whatever extensions that index declares), every catalogued link resolving, and, once the repo declares them, a row beginning a cell with a status from the canon and a recorded reconciliation date. A row only counts where a reader can see it: a table inside a fence, a comment (closed or not), a `<pre>` block, an HTML block or an indented code block is not coverage, and a cell whose destination is escaped or is an image carries no navigable link |
| `RS-assets` | the generated identity, when a repo declares one: byte-identical re-render, the exact generated block on the front page and the exact banner H1 in every declared README, no README left heading a banner the manifest no longer declares, live pill provenance, a contrast floor. Every path it reads or compares has to be a regular file at the path it is named by, because a link reads through to bytes the repo does not commit there |
| `RS-ignore` | a secrets file can never become trackable, and declared build output stays out of the tree |

Several of these print more than one line on a run, because they answer more than one question and
a single verdict would hide which one failed. `RS-assets` reports the manifest, the drift, and
the idiom separately, and names any pill declared unverifiable. `RS-ignore` separates the ignore
RULES from the tracked-file evidence, because the second leg needs git and degrades to a named
skip without it. `RS-license` names its agreement legs the same way. `RS-index` prints one line
per declared index and names its status and date legs per index too, so a repo cataloguing two
directories can tell which of them drifted.

## What a skip means

A skip is a check that could not run, printed with the reason, counted separately, and never
folded into the pass total. The common ones:

| Skip | Why |
|---|---|
| `RS-prose` | no writing profile declared; the marketing-voice ban (`RS-voice`) still applies |
| `RS-assets` | no identity assets declared |
| `RS-index` | no index declared, so no directory is catalogued |
| `RS-about` | no GitHub About recorded |
| `RS-about (live panel)` | an About is recorded and the check is on: the lint takes no network, so what GitHub serves right now is unverified here |
| `RS-index (status) <file>` / `RS-index (dates) <file>` | named per index, so the file it belongs to is on the line: that index declares no status vocabulary, or sets neither `requireDate` nor `reconciled`, so nothing records when it was last checked against the code |
| `RS-assets (pill provenance)` | a pill declares `"source": false` with a reason: stated, never verified |
| `RS-ignore (tracked leg)` | git is unavailable, so what is actually committed cannot be checked; the rules were |
| `RS-lockstep` | no version manifest, so there is nothing to hold the changelog in lockstep with |
| `RS-manifest` / `RS-counts` | nothing declared to check |
| `RS-license (manifest leg)` | no manifest declares a license field, so there is no agreement to verify |

The scaffold skill's recap is required to report skips **as skips**. "All checks pass" over a run
with a skip in it is exactly the inflated claim this toolkit exists to police.

## The required-check ruleset

A workflow that runs on every push blocks nothing by itself: a red run turns the badge red while
the merge lands anyway. On GitHub, only a **required status check** stops a merge, and that
requirement lives in a branch ruleset, not in any committed file.

The skill offers `payload/rulesets/repo-standard.json` once the suite is green and the repo has a
GitHub remote, probing first so the question never reaches a plan that cannot take it (rulesets
cover public repos on every plan, private repos on Pro or Team and above). The payload ships with
`"enforcement": "disabled"`: fully configured, inert, POSTable everywhere. Turning it on is the
operator's one deliberate act in Settings, and the required check is pinned to the GitHub Actions
app, so a hand-posted commit status cannot satisfy it. Until the ruleset is active, a red CI run
blocks nothing, and the skill and its recap say so rather than implying otherwise.

Once it is ACTIVE it does more than block a red merge, and a repo should know that before it
flips the switch: every change to the default branch goes through a pull request (zero approvals
required), with no `bypass_actors` declared, so repo admins included; force pushes and branch
deletion are refused; and a branch has to be up to date with the base before it merges. On a
repo whose habit is pushing straight to the default branch, that is the change the operator will
notice first. The four rules are load-bearing together: a required status check on a branch that
still accepts direct pushes is a gate you walk around rather than a gate.

## The optional pre-push check

Once a repo is governed and green, the skill offers one convenience, and only if you say yes:

```
node ${CLAUDE_PLUGIN_ROOT}/harness/install-hook.mjs --target .
```

It installs `.git/hooks/pre-push`, which runs the repo-standard lint (and nothing else; your own
test suite is your business) before each push, so drift fails in your terminal in a moment
rather than in CI a minute later.

**It is a convenience, not a gate**, and the design says so out loud: it is per-clone,
uncommitted, skipped by `git push --no-verify`, and absent for anyone who clones fresh. That is
exactly why it is installed *uncommitted*: committing it would imply it is part of the standard,
and a hook can never be. The gate is the same lint, run by CI, and once the repo requires that
check via the branch ruleset, nobody merges past a red run.

The engine refuses rather than surprising you: it never clobbers a pre-push hook it did not
write, it reports instead of writing into `.git/hooks` when `core.hooksPath` points elsewhere
(husky and friends), and it turns away an ungoverned repo. Remove it any time with
`--uninstall`, or just `rm .git/hooks/pre-push`.

There is deliberately **no push-time prompt asking whether to adopt the standard.** Adoption is a
reviewed change to a repo's front matter; it deserves its own session and its own PR, not an
interruption while you are shipping something else, and a prompt you dismiss on every push is
just noise you have trained yourself to ignore.
