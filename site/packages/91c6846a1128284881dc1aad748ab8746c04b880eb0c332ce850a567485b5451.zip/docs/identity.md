# Identity

A repo's front page is the first thing anyone reads about it, and every generated asset on that
page is a claim. This pillar makes those claims **reproducible** (the artwork re-renders byte for
byte from one manifest) and **checkable** (every value on it is re-read from the file it came
from, on every CI run, forever).

Run it with `/repo-standard-toolkit:identity`. It is an offer, never assumed: a repo with no
banners has not failed anything.

## The pieces

| File | Role |
|---|---|
| `.github/assets/manifest.json` | The source of truth: brand, palette, palette provenance, pills, banners. The only file a human edits. |
| `.github/assets/generate.mjs` | The generator, installed byte-identical from the payload. Renders every asset; writes only when run directly. |
| `.github/assets/banner.svg`, `banners/*.svg`, `pills/*.svg` | Generated output. Committed, and never hand-edited. |
| `assets` in `.repo-standard.json` | The declared scope the lint reads. |

A pill and a **live badge** are different things and the manifest keeps them apart. A pill is a
fact this repo can render, so it is rendered locally and its source is re-read forever. A build
status is not that: it changes without the repo changing, and a locally rendered "passing" would
be a claim that can never go red, which is the exact failure this toolkit exists to prevent. So
live badges stay third-party and what the palette governs is how they look. Declare them under
`badges` with the shields path after the host, and the generator appends the styling; the lint
checks the README carries that exact line. Two limits, both stated rather than designed around:
a third-party renderer will never be pixel-identical to a local one, so the family resemblance is
the colour and the label rather than the height, and shields draws its value text white, so live
badges always take the accent scheme.

```bash
node .github/assets/generate.mjs   # from the repo root; prints the markdown as well as the SVGs
```

**The markdown is generated too, and that is the less obvious half.** The generator emits the
whole opening block of the front page: the banner H1, then a centred `<div>` holding the pill row,
then any live badge on its own line inside it. The arrangement is generated for the same reason
the artwork is, except the failure mode is worse. Where a banner goes wrong the page looks wrong
and somebody fixes it; where the arrangement goes wrong the page looks nearly right, and a pill
row sitting left-aligned under a full-width banner survives every review it will ever get. Three
details carry it and none of them is memorable: markdown needs a blank line on each side of the
`<div>` or the pills render as literal text, the badge sits apart from the pills because a
third-party renderer will never match them for height, and the order is the order. So the
generator prints the block and the lint compares it byte for byte. Paste it whole.

A pill may declare an `href`, which is what it links to, written as it appears in the README
rather than from the repo root. It is optional for the reason `homepage` is: a claim with no real
destination renders as a bare image instead of pointing at an invented page. A relative one has
to resolve, because a badge linking nowhere reads authoritative and is not.

## The visual system

Fixed geometry over brand inputs. Dimensions (1200 by 300 for the root banner, 1200 by 150 for a
folder banner), drifting orbs, the hairline grid, the counter-scrolling wave bands, and the
animated wave-edge mask are all constant, so two repos with different palettes are recognizably
the same family. Type is fitted rather than clipped: a seven-letter wordmark renders at the
design size, a twenty-letter one shrinks to fit and the accent bar follows it.

What varies is `brand` (name, tagline, eyebrow, and an optional homepage) and a
**fifteen-role palette**. The homepage is the link every banner points at; a repo with no remote
and no product site omits it and gets an unlinked banner, because a link to an invented
destination is the same fabricated claim as a badge for a workflow that does not exist. Each
role is named for the job it does in the artwork rather than for a colour, which is the whole
generalization: `accent` is the prism-bar start and the first orb whether it is emerald or
violet.

| Role group | Roles |
|---|---|
| Ground | `groundDeep`, `groundMid`, `ground` |
| Waves | `waveNear`, `waveFar` |
| Type and rules | `text`, `textMuted`, `rim` |
| Accents | `accent`, `accentAlt`, `accentSoft` |
| Pills | `pillAccentBg`, `pillAccentFg`, `pillAltBg`, `pillAltFg` |

Three presets ship in `payload/assets/palettes/`: `forest`, `violet`, and a brand-neutral
`slate`. All three clear the contrast floor, and a standing test proves it.

## Where a palette comes from

In order of preference, and the order the skill offers:

1. **Derived from the repo's own design identity.** `harness/derive-palette.mjs` reads CSS custom
   properties, SCSS and LESS variables, Tailwind and theme config, design-token JSON, and the
   declared browser theme colour. It maps what it finds onto the roles, records the file, line,
   token, and value for each role it could read, and derives the rest by named deterministic
   transforms (`mix-black-42`) from roles it could.
2. **A shipped preset**, recorded as a preset rather than dressed up as derived.
3. **Values the operator supplies**, recorded as custom.

The engine **refuses rather than inventing**. Below six named colours it reports that there is no
design system here to read, quotes what it did find, and exits non-zero; the skill then offers
the presets. A confident answer to a question the repo never answered would be worse than no
answer.

Contrast is repaired, not assumed. The lint enforces 4.5:1 (WCAG 2.2 AA) on nine text pairs, so a
proposal that would fail is nudged in fixed steps until it passes, and **every nudge is reported**,
because those are edits to someone's brand colours. A pair that cannot reach the floor is a
failure, not a shipped palette.

## Nothing is written before it is seen

`harness/preview-assets.mjs` renders the whole proposal to one self-contained HTML page, written
outside the repository: every banner animating on both of GitHub's page backgrounds, the pill
row, the palette with each role's job named, and the measured contrast of all nine enforced
pairs. That page is what an operator approves. Approving a column of hex values is not informed
consent, and previewing is not scaffolding.

## What the lint holds

`RS-assets` runs in three named legs, so a failure says which question failed.

**The manifest leg.** Version 1, a complete brand block, all fifteen palette roles as hex
colours, no unknown roles (a role the generator never reads is a colour nobody will see change),
unique slugs and pill filenames, and the contrast floor on all nine pairs.

**The drift leg.** The lint imports the repo's own generator, re-renders the manifest, and
compares every asset byte for byte. A hand-edited SVG fails. A manifest edited without a
regenerate fails. An SVG no manifest entry produces fails, because a renamed slug leaves the old
file behind and an asset nothing renders is an asset nothing keeps true.

**The idiom leg.** The root README's H1 must be exactly the line the generator prints, and so
must every declared folder README's, relative path included. Every pill must appear somewhere in
the root README, because a pill no README shows is a claim nobody made. Then provenance:

- Each pill declares `{ file, json: "dotted.path" }` or `{ file, match: "<regex>" }`, and the
  extracted truth must appear inside the displayed value. That is what lets `0.115+` front a
  source that says `0.115`, while a version badge can never outlive the version it names.
- A pill with no single source of truth declares `"source": false` with a `why`. The lint prints
  it as a named skip on every run: stated, never verified.
- A derived palette's recorded roles are re-read: the file must still exist and still have a line
  carrying that token and that value. When a design identity moves, the banners are reported as
  drifted rather than left quietly representing a product that changed.
- Optional `coverage` requires every immediate subdirectory of a declared root to have a banner
  entry, so a directory that appears without a README fails rather than going unnoticed. A nested
  directory is reached by naming its parent as a root of its own.

And last, the arrangement: the front page has to carry the generated block whole. It is checked
last on purpose. Every specific failure above also changes the block, and "the block does not
match" is the worst of those diagnoses, so it is what is reported once nothing more precise was
wrong. What it catches on its own is the page that passes every other question and still came out
wrong: the pills present but left-aligned, or in an order somebody re-sorted, or the badge folded
in among them.

## The honest limits

Coverage is one level deep per root, deliberately. A leaf directory holding config fragments has
no banner to earn, and a folder README that says nothing is worse than no folder README, so the
depth a repo wants policed is the list of roots it names rather than a depth knob.

The lint imports a file the repo controls. That proves the committed SVGs still follow from the
committed manifest, which is the drift anyone actually ships. It cannot prove the generator was
not forked to render whatever is already there; no committed file can prove that about a sibling
it imports. Byte-identity of the generator against the published payload is what
`harness/sense-state.mjs` reports on a re-run, exactly as it does for the lint itself, and a
stale plugin is stopped rather than allowed to downgrade a newer committed generator.
