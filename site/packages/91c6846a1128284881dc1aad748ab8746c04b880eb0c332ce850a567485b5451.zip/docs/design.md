# Design

The decisions that shape this toolkit, including the ones that look like missing features and
are not. Recorded so a future contributor (or a future maintainer having a clever idea at
midnight) can see what was already considered and why it lost.

## The load-bearing principle

> **Enforcement lives with the code it gates. Generation lives in the agent. Never make
> enforcement depend on the agent.**

A linter that only fires inside one editor or one AI tool is not a gate: a contributor on a fork
with vim drifts it freely and CI stays green. So the enforcement is a committed lint run in CI,
tool-agnostic, dependency-free. The agent's job is the other half, authoring and installing that
enforcement, which is judgment-heavy, cross-repo, and one-time-ish, and which is exactly what a
plugin is good at. If a proposed check needs the agent at enforcement time, it gets rejected or
redesigned.

## The product boundary

This toolkit owns a repo's **surface**: presentation, hygiene, and truthfulness. What it renders
on the front page, what it claims about itself, whether the claims can be re-checked, and
whether the tree stays clean. It does not own code correctness or security, and it says so in
the places where the line is easy to blur:

- RS-ignore reads ignore RULES and the tracked-file LIST. It never reads file contents looking
  for credentials. Secret scanning is a different product, and a hygiene check that implied
  otherwise would be more dangerous than no check at all, because "the repo was scanned" is
  exactly the sentence someone would remember.
- RS-assets proves the artwork follows from the manifest. It cannot prove the generator was not
  forked, because no committed file can prove that about a sibling it imports.
- The gate proves structure, consistency, and machine-checkable facts. It does not prove prose
  quality, and a scaffold is never a certification. Every run ends in a quoted recap precisely
  because the operator's review is part of the design, not an optional extra.

## Four pillars, one lint

The front matter came first, and it is still the front door. Three later journeys extend the same
committed lint rather than adding new machinery beside it:

- **Identity** (RS-assets) is the presentation layer: generated banners and pills, regenerable
  byte for byte, with every claim on the front page traced to a file the lint re-reads.
- **Voice** (RS-prose) is the prose layer: an enterprise writing standard as a first-class,
  deterministic check rather than a style guide nobody opens.
- **Atlas** (RS-index) is the inventory layer: every governed directory carrying a complete
  glossary of itself, one row per file, written from the files rather than from a listing.

All three are **opt-in, and all three are asked**. That is not politeness, it is the honest read
of what they cost. Generated artwork is a commitment to regenerate it; a writing profile is a
rewrite pass over everything already written and a gate on everything after; an index is a fan-out
now and a row owed by every file added later. A tool that made any of those decisions for a repo
owner would be deciding something that was never its call, which is the same instinct that makes
this toolkit refuse to invent a tagline it cannot verify.

The atlas is where the load-bearing principle earns the most. Enforcement is one more leg in the
same committed lint, which never grows an agent-shaped dependency; generation is a fan-out that
lives entirely in the skill. A second plugin would have needed its own vendored lint, and the
whole architecture is one committed dependency-free file holding every claim.

The lint's canon-versus-scope split is what keeps that safe. Whether a pillar is active is
scope, and lives in `.repo-standard.json`. What the pillar then means is canon, and lives in the
lint where no config can water it down.

## Origin

Born from `ai-readiness-review-toolkit`, a private Verdict toolkit (which is why this section
carries no link), where the project-meta governance system was first built and proven: a
committed lint that fails CI on any drift in README, CHANGELOG, CONVENTIONS, and manifest docs,
grounded in Keep a Changelog and standard-readme. This plugin is that pattern, generalized.
During development the generic core was run against the parent's real meta docs and reproduced
the proven lint's verdict on the same tree, including catching the same live count drift the
parent's own gate catches. (A development-time result, not a standing test; what stands in this
tree is the mutation coverage in `acceptance/test-lint-behavior.mjs`.)

The visual language has its own lineage. It was hand-built for a private repo, ported to
Verdict's product identity, and generalized here: the same geometry (dimensions, drifting orbs,
the hairline grid, counter-scrolling wave bands, the animated wave-edge mask) over a fifteen-role
palette named for what each colour DOES rather than what it is. That naming is the whole
generalization. A violet identity and a forest one differ only in their inputs, which is why
both ship as presets and why a third repo's palette can be read out of its own design tokens.

## Deliberate rejections

Each of these was considered and refused on purpose. The refusal is part of the design.

- **Expiry dates on check disables.** A disable that auto-reactivates on a calendar date makes
  the lint's verdict depend on when you run it, and the same tree must always lint the same.
  Freshness is never age-gated anywhere in the toolkit; the loud printed reason is the pressure
  mechanism instead.
- **Node 22's `fs.globSync`.** A hand-rolled twelve-line basename-only matcher keeps the floor
  at Node 18+ and keeps the matching auditable at a glance. Deeper truths use `file` and
  `lineRegex` instead of a richer glob.
- **A custom-check registry in the config.** Extra `acceptance/test-*.mjs` files already serve
  exactly that purpose: the gate loop runs every one it finds, so a repo extends the standard by
  writing a test, not by configuring one.
- **Monorepo and per-package scoping.** Deliberately out of scope for now: govern the repo root,
  or run per package with separate configs at your own judgment.
- **A committed hook via `core.hooksPath`.** The pre-push check stays per-clone, uncommitted,
  and skippable, because committing it would imply it is part of the standard, and a client-side
  hook can never be enforcement. The CI check, made required via ruleset, is.
- **A push-time prompt to adopt the standard.** Adoption is a reviewed change deserving its own
  session and PR, not an interruption of unrelated work, and a prompt dismissed on every push
  trains you to ignore it.
- **`evaluate` as the shipped ruleset enforcement.** GitHub gates that dry-run mode to
  Enterprise plans; shipping it would fail the documented apply on most repos. The payload ships
  `disabled`, inert everywhere, and activation is the operator's deliberate act.
- **Auto-injected attribution badges in scaffolded repos.** The scaffolded CONVENTIONS carries
  one factual sentence naming what installed the lint; that is the ceiling. Decorative badges
  are the operator's to add, never the tool's.
- **A marketplace of its own.** A marketplace name is a global, once-per-user key, so a
  namespace needs exactly one authority. The catalog lives in
  [runverdict/plugins](https://github.com/runverdict/plugins); this repo ships a plugin manifest
  and stays out of the namespace business.
- **A version field in the catalog entry.** The plugin's own manifest owns the version; a copy
  in the catalog could only ever drift into a lie.
- **The writing profile on by default.** It would redden the entire back catalogue of every
  repo that upgraded, on prose nobody was given a chance to sweep. Opt-in, swept first, locked
  second.
- **A smarter prose detector.** No part-of-speech tagging, no "this sentence feels like an AI
  wrote it" heuristics, no flagging a double hyphen (every command-line flag in every docs page
  would trip it). Every rule in the profile is one a careful writer can always act on, so a hit
  is never a judgment call. A detector that cries wolf gets disabled, and a disabled detector
  enforces nothing.
- **Rewriting released CHANGELOG history to satisfy a profile adopted later.** The file exists
  to record what shipped. The scan stops at the first dated version, in the lint and in the
  sweep engine alike.
- **Content-based secret scanning in RS-ignore.** See the product boundary above.
- **A locally rendered build-status badge.** It would match the pill row pixel for pixel, which
  is exactly what makes it dangerous: a static "passing" cannot go red, so it would be a claim
  the repo could never falsify. Regenerating it from CI would need a write-scoped token, which
  the supply-chain guard forbids outright. So there is a real trilemma here, worth naming because
  it cannot be engineered away: **live status, pixel-matching, honest claims, pick two.** Shields
  exposes the two plate colours and nothing else, so a live badge will always differ in height,
  font, letter case, and label text colour no matter how it is styled. The resolution is to stop
  implying a match rather than to force one: live badges take the palette and sit on their own
  line, so a reader sees two kinds of claim rather than one broken row. A repo that would rather
  have the match than the live signal can drop the badge and add a pill that links to the CI page
  without asserting a status, which is honest and static, just less useful.
- **Enforcing the GitHub About panel in the lint.** The lint takes no network, by a rule older
  than this feature, and a check that phoned an API would make the same tree lint differently
  depending on the network. What the lint holds instead is the offline half: the recorded
  description still matches the repo's own tagline. Whether GitHub is serving it belongs to the
  skill that can actually ask, and both halves say which one they are.
- **A hash lock for the generated assets.** Comparing committed SVGs to a recorded hash proves
  the files did not change; it proves nothing about whether they still follow from the manifest,
  which is the property that matters. The lint re-renders instead.
- **A lint leg that grades an index row.** A minimum description length is the obvious next check
  after coverage, and it is a judgment about writing dressed as a number. A sixty-character row
  can be exactly right, a four-hundred-character one can say nothing, and a build reddened by a
  heuristic teaches people to pad rows rather than to write them. It would also break the
  boundary the whole leg is careful about, which is that CI holds structure and cannot hold
  accuracy. The length band lives in the row grammar the atlas hands each agent, enforced by the
  normalization pass and the operator's approval, where a human can disagree with it.
- **Letting the atlas fix the artwork it finds wrong.** A sweep that reads every file in a
  directory will notice when the banner description no longer matches what is in there, and the
  temptation is to correct it in passing. Refused: that is a manifest edit, which re-renders an
  SVG, which is the identity journey's preview-and-approve gate being walked around by a journey
  the operator opened for a different reason. Reported as a finding, fixed by an identity re-run,
  and the atlas stays re-runnable without touching a single byte of artwork.

## A fan-out is a gate

Decided before the code, because it is the kind of rule that is much cheaper to hold from the
start than to retrofit.

The atlas journey below has to read every file it writes a row for, which on a mature repository
means many agents reading many files. That is only possible at all because these toolkits are
driven by Claude Code on a plan and an effort setting where a fan-out of that size is real work
rather than an aspiration. The capability is assumed. **The consent is not.**

So: no fan-out ever begins without an explicit approve or deny, and the offer states the size
before it happens, not after. How many directories, how many files, roughly how many agents. An
operator who says no is not failing a step, and the journey has to have somewhere to go when they
do (a narrower scope, or a recorded decline, the same way the reach question prices a voice sweep
before anyone commits to it).

Two reasons, and the second is the one that generalises. The obvious one is cost: work that is
possible is not therefore free, and a tool that spends someone's budget without asking has made a
decision that was never its own. The deeper one is that this repo's whole posture is that the
operator sees what is about to happen while they can still stop it. A preview before the artwork
lands, a diff before the About panel is written, a named skip instead of a silent pass. A fan-out
is the largest single action any journey takes, and it would be strange for the largest one to be
the one that just starts.

The README documents this as an explicit step now that the atlas ships, and did not before.
Describing a step that does not exist yet is the same overclaim as a badge for a workflow nobody
wrote.

One thing the implementation added to the rule. **The size in the offer comes from an engine, not
from the skill.** `harness/index-plan.mjs` counts the directories, the files, the lines, and the
chunks, and a standing test proves its coverage set is the one `RS-index` demands rows for. A
consent gate whose numbers the asking party estimated is a worse gate than no gate, because it
looks like information. It also means a decline can be answered with a real alternative rather
than a vaguer version of the same question: the narrower scope has a number too.

## What indexing this repo by hand taught

The five indexes here were written by three agents working from a first draft of the row grammar,
each reading every file it wrote a row about. They were asked to report where the grammar failed
to decide something for them, because a contract handed to a hundred agents resolves its
ambiguities a hundred ways. These are the ones that would have broken the fan-out, and they were
fixed here before the code existed rather than discovered by it. All of them are now in the
contract the fan-out hands each agent, and the table in [Atlas](atlas.md) is where they live as a
rule rather than as a lesson:

- **A link target is relative to the index, not to the repo root.** From `skills/README.md` the
  correct target is `scaffold/SKILL.md`; the instinct is `skills/scaffold/SKILL.md`, which
  resolves to `skills/skills/...`, fails both coverage and resolution, and reports an error that
  does not obviously name the cause. This is the highest-probability silent break in the whole
  journey.
- **"Every file gets a row" is not what the check enforces**, and stating it that way makes an
  agent row the index itself. It is every file matching that index's declared `extensions`. The
  extension set lives in the config, which the writing agent has no reason to open, so it has to
  be handed to it.
- **The index is not always the README.** `payload/templates/README.md` IS a template, one of the
  files the directory ships. An agent following "the index is the directory's README" would have
  overwritten a shipped artifact and reddened the build. Where a README already exists and is not
  itself an index, the catalog takes another name and the README gets a row like anything else.
  A hygiene toolkit has more directories like this than most.
- **A nested directory has no banner**, because `assets.coverage.roots` is one level deep by
  design, so "open with the generated banner H1" is unfollowable below the top level and an agent
  cannot fix that without adding a manifest entry it has no business adding.
- **Row order has to be mandated**, or a later reconciliation by a different agent re-sorts the
  table and produces a diff that reads as a rewrite. Settled as **ascending path order**, on the
  one property that decided it: it is the only order a different agent reproduces. The cost is
  real and was accepted, because it demotes the row an author would have led with. A table is a
  glossary and the prose around it is the argument, which is how `skills/README.md` already read.
- **The link text is the backticked path**, not a title. Three of the five hand-written indexes
  used one form and two used the other, which is precisely what a hundred agents would produce.
  The file is what the row is about; a title is what the description cell is for.
- **A markdown cell cannot contain a raw pipe**, which bites immediately on any file whose own
  usage string carries one.
- **The recorded date meant a human read this and confirmed every row.** A fan-out makes it an
  agent read, on every directory, on the same day, so either the wording changed or the claim did.
  Settled by **naming the sweep**: `Reconciled against the code: 2026-07-31 (agent sweep)`, with
  `(by hand)` as the other value. The date keeps its canon wording, which five indexes and the
  lint's own regex already carry, and gains the one fact that was missing. The obvious hole in it
  is the mixed case, an index a sweep wrote and a person later edited, and that closes on a rule
  the date already implied: the claim is index-level, so a partial edit does not reconcile the
  index and changes neither the date nor the parenthetical.

One further thing the exercise proved, which is why it was worth doing by hand first: **writing a
row about a file is the most reliable way anyone has found to notice the file's own header is
lying.** Four did. The worst recorded a colour transform as `hue-rotate-140` when the arithmetic
is exactly 120 degrees, and shipped that name into manifests as provenance.

## Planned

Designed, not built. Recorded here so the shape is fixed before the code is:

- **A deterministic apply engine for the atlas.** Today the planner is deterministic and the
  WRITING is prose instruction: page assembly, table replacement, config migration and rename
  handling live in the skill, which is why a real run reached for scratchpad files and shell
  assembly to do them. The engine takes approved rows as JSON plus the operator's decisions, and
  owns managed-block insertion, target-keyed row merging that preserves identity markup and
  surrounding prose and unrelated tables and unchanged rows, dirty-file and expected-hash checks,
  the rename together with its config and inbound-link updates, a dry-run full-page diff, and
  idempotence, so a second identical apply produces no diff at all. The standing test it needs is
  a golden fixture of the exact shape the first real target had (identity adopted, an old
  generator, a complete `docs/INDEX.md` with no `docs/README.md`, a custom status alias, linked
  pills, several README candidates, one declined leaf) asserting the whole journey end to end:
  sense, approve, apply, sense again, with the second run byte-empty.
  **Deliberately after the row grammar settled rather than beside it.** The grammar gained
  containment, uniqueness, ordering, escaped pipes and angle-bracket destinations in the same pass
  that identified this gap, and an applier built on a contract still moving buys two rewrites.
  **Still deferred after the 0.8.0 audit, for the same reason and with fresh evidence:** that
  audit moved the table grammar again (the link is now read from the file column, a missing status
  or date header is a gap rather than a fallback), the fence rule (a closing fence carries no info
  string), the link rule (one parsed link answers both destination and closure), the migration
  discovery set (the moving page is in it) and the path contract (spelling before normalisation).
  Five of the six contracts an applier sits on moved in one pass. Building it beside them would
  have bought the second rewrite the first deferral was recorded to avoid.
- **A root-directory ownership model.** An index lives inside the directory it catalogues, so a
  root-level declaration is refused by construction and no index can reach a root file. That is a
  real hole in "every folder carries a glossary of itself", and the honest reading of it is now
  measured rather than argued: each root file reports whether another check governs it, and
  `undecidedFiles.outsideModel.ungovernedRootFiles` counts the ones nothing anywhere holds. On
  this repository that count is zero, because the root holds only the meta docs, the stable docs,
  the licence, the ignore ruleset and the config, each governed by a rule of its own. On a repo
  with a root `Dockerfile`, `Makefile` or `package.json` it will not be zero, and the number is
  the argument for building this rather than a slogan about it.
  **Not built now, because the cheap version is wrong.** The obvious move is to let README.md be
  an index, and README.md is the front page: it is already governed by RS-readme, standard-readme
  fixes its section order, and a catalog table of root files is not a section that specification
  has a place for. The alternative is a second root page nobody browses, which is the exact defect
  the migration offer exists to correct one directory at a time. Whatever this becomes, it needs a
  home a reader arrives at, and that question is not settled by the ownership rule.
- **Truth pass.** Extract the factual claims a repo's docs make (versions, counts, paths,
  commands, capabilities), verify each against the code, and report the divergences. Code wins:
  the docs are what gets corrected. RS-counts is the narrow, fully deterministic ancestor of
  this, and the general case needs the same discipline, which is that a claim the tool cannot
  verify must be reported as unverified rather than assumed true.
- **Handover mode.** The guided clean-baseline ritual for handing a repo to a buyer, an auditor,
  or a new team: a single tagged commit, a CHANGELOG that describes the platform as shipped
  rather than as it was built, and an operator-gated force-push. Every destructive step gated
  and quoted, because this is the one journey that rewrites history on purpose.
- **Docs-inventory classifier.** Sort a repo's documentation into runtime-consumed (something
  serves it), operational (someone follows it), and historical (it records what happened), and
  propose what belongs where. Propose-never-execute: moving someone's docs is not a decision a
  tool makes on its own.
