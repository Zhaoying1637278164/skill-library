#!/usr/bin/env node

import { promises as fs } from "node:fs";
import path from "node:path";
import process from "node:process";

const repoRoot = process.cwd();
const errors = [];
const warnings = [];

const pluginNamePattern = /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/;
const kimiPluginNamePattern = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const marketplaceNamePattern = /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;

function addError(message) {
  errors.push(message);
}

function addWarning(message) {
  warnings.push(message);
}

async function pathExists(targetPath) {
  try {
    await fs.access(targetPath);
    return true;
  } catch {
    return false;
  }
}

async function ensureDirectory(targetPath, context) {
  try {
    const stat = await fs.stat(targetPath);
    if (!stat.isDirectory()) {
      addError(`${context} exists but is not a directory: ${targetPath}`);
      return false;
    }
    return true;
  } catch {
    addError(`${context} directory is missing: ${targetPath}`);
    return false;
  }
}

async function readJsonFile(filePath, context) {
  let raw;
  try {
    raw = await fs.readFile(filePath, "utf8");
  } catch {
    addError(`${context} is missing: ${filePath}`);
    return null;
  }

  try {
    return JSON.parse(raw);
  } catch (error) {
    addError(`${context} contains invalid JSON (${filePath}): ${error.message}`);
    return null;
  }
}

function normalizeNewlines(content) {
  return content.replace(/\r\n/g, "\n");
}

function parseFrontmatter(content) {
  const normalized = normalizeNewlines(content);
  if (!normalized.startsWith("---\n")) {
    return null;
  }

  const closingIndex = normalized.indexOf("\n---\n", 4);
  if (closingIndex === -1) {
    return null;
  }

  const frontmatterBlock = normalized.slice(4, closingIndex);
  const fields = {};

  for (const line of frontmatterBlock.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }
    const separator = line.indexOf(":");
    if (separator === -1) {
      continue;
    }
    const key = line.slice(0, separator).trim();
    const value = line.slice(separator + 1).trim();
    fields[key] = value;
  }

  return fields;
}

async function walkFiles(dirPath) {
  const files = [];
  const stack = [dirPath];

  while (stack.length > 0) {
    const current = stack.pop();
    const entries = await fs.readdir(current, { withFileTypes: true });
    for (const entry of entries) {
      const entryPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        stack.push(entryPath);
      } else if (entry.isFile()) {
        files.push(entryPath);
      }
    }
  }

  return files;
}

function isSafeRelativePath(value) {
  if (typeof value !== "string" || value.length === 0) {
    return false;
  }
  if (value.startsWith("http://") || value.startsWith("https://")) {
    return true;
  }
  if (path.isAbsolute(value)) {
    return false;
  }
  const normalized = path.posix.normalize(value.replace(/\\/g, "/"));
  return !normalized.startsWith("../") && normalized !== "..";
}

function extractPathValues(value) {
  if (typeof value === "string") {
    return [value];
  }

  if (Array.isArray(value)) {
    return value.flatMap((entry) => extractPathValues(entry));
  }

  if (value && typeof value === "object") {
    const candidates = [];
    if (typeof value.path === "string") {
      candidates.push(value.path);
    }
    if (typeof value.file === "string") {
      candidates.push(value.file);
    }
    return candidates;
  }

  return [];
}

async function validateReferencedPath(pluginDir, fieldName, pathValue, pluginName) {
  if (pathValue.startsWith("http://") || pathValue.startsWith("https://")) {
    return;
  }

  if (!isSafeRelativePath(pathValue)) {
    addError(
      `${pluginName}: field "${fieldName}" has invalid path "${pathValue}". Use a relative path without ".." or absolute prefixes.`
    );
    return;
  }

  const resolved = path.resolve(pluginDir, pathValue);
  const exists = await pathExists(resolved);
  if (!exists) {
    addError(`${pluginName}: field "${fieldName}" references missing path "${pathValue}".`);
  }
}

async function validateFrontmatterFile(filePath, componentName, requiredKeys, pluginName) {
  const content = await fs.readFile(filePath, "utf8");
  const parsed = parseFrontmatter(content);
  const relativeFile = path.relative(repoRoot, filePath);

  if (!parsed) {
    addError(`${pluginName}: ${componentName} file missing YAML frontmatter: ${relativeFile}`);
    return;
  }

  for (const key of requiredKeys) {
    if (!parsed[key] || parsed[key].length === 0) {
      addError(`${pluginName}: ${componentName} file missing "${key}" in frontmatter: ${relativeFile}`);
    }
  }
}

async function validateComponentFrontmatter(pluginDir, pluginName) {
  const rulesDir = path.join(pluginDir, "rules");
  if (await pathExists(rulesDir)) {
    const files = await walkFiles(rulesDir);
    for (const file of files) {
      const ext = path.extname(file).toLowerCase();
      if (ext === ".md" || ext === ".mdc" || ext === ".markdown") {
        await validateFrontmatterFile(file, "rule", ["description"], pluginName);
      }
    }
  }

  const skillsDir = path.join(pluginDir, "skills");
  if (await pathExists(skillsDir)) {
    const files = await walkFiles(skillsDir);
    for (const file of files) {
      if (path.basename(file) === "SKILL.md") {
        await validateFrontmatterFile(file, "skill", ["name", "description"], pluginName);
      }
    }
  }

  const agentsDir = path.join(pluginDir, "agents");
  if (await pathExists(agentsDir)) {
    const files = await walkFiles(agentsDir);
    for (const file of files) {
      const ext = path.extname(file).toLowerCase();
      if (ext === ".md" || ext === ".mdc" || ext === ".markdown") {
        await validateFrontmatterFile(file, "agent", ["name", "description"], pluginName);
      }
    }
  }

  const commandsDir = path.join(pluginDir, "commands");
  if (await pathExists(commandsDir)) {
    const files = await walkFiles(commandsDir);
    for (const file of files) {
      const ext = path.extname(file).toLowerCase();
      if (ext === ".md" || ext === ".mdc" || ext === ".markdown" || ext === ".txt") {
        await validateFrontmatterFile(file, "command", ["name", "description"], pluginName);
      }
    }
  }
}

function resolveMarketplaceSource(source, pluginRoot) {
  if (typeof source !== "string" || source.length === 0) {
    return null;
  }
  if (!pluginRoot) {
    return source;
  }
  const normalizedRoot = pluginRoot.replace(/\\/g, "/").replace(/\/+$/, "");
  const normalizedSource = source.replace(/\\/g, "/");
  if (normalizedSource === normalizedRoot || normalizedSource.startsWith(`${normalizedRoot}/`)) {
    return normalizedSource;
  }
  return `${normalizedRoot}/${normalizedSource}`;
}

async function validatePluginDirectory(pluginDir, expectedName, pluginManifest) {
  const pluginName = pluginManifest.name || expectedName;

  if (typeof pluginManifest.name !== "string" || !pluginNamePattern.test(pluginManifest.name)) {
    addError(
      `${expectedName}: "name" in plugin.json must be lowercase and use only alphanumerics, hyphens, and periods.`
    );
  }

  if (pluginManifest.name?.includes("--") || pluginManifest.name?.includes("..")) {
    addError(`${expectedName}: "name" in plugin.json cannot contain consecutive hyphens or periods.`);
  }

  if (pluginManifest.name && pluginManifest.name !== expectedName) {
    addError(
      `${expectedName}: marketplace entry name does not match plugin.json name ("${pluginManifest.name}").`
    );
  }

  for (const field of ["displayName", "version", "description", "license"]) {
    if (typeof pluginManifest[field] !== "string" || pluginManifest[field].trim().length === 0) {
      addError(`${pluginName}: "${field}" is required in plugin.json.`);
    }
  }

  if (!pluginManifest.author || typeof pluginManifest.author.name !== "string" || pluginManifest.author.name.length === 0) {
    addError(`${pluginName}: "author.name" is required in plugin.json.`);
  }

  if (!Array.isArray(pluginManifest.keywords) || pluginManifest.keywords.length === 0) {
    addError(`${pluginName}: "keywords" must be a non-empty array in plugin.json.`);
  }

  const manifestFields = ["logo", "rules", "skills", "agents", "commands", "hooks", "mcpServers"];
  for (const field of manifestFields) {
    const values = extractPathValues(pluginManifest[field]);
    for (const value of values) {
      await validateReferencedPath(pluginDir, field, value, pluginName);
    }
  }

  await validateComponentFrontmatter(pluginDir, pluginName);

  const mcpPath = path.join(pluginDir, "mcp.json");
  if (await pathExists(mcpPath)) {
    const mcpConfig = await readJsonFile(mcpPath, `${pluginName} MCP configuration`);
    if (!mcpConfig?.mcpServers || typeof mcpConfig.mcpServers !== "object" || Array.isArray(mcpConfig.mcpServers)) {
      addError(`${pluginName}: mcp.json must contain an "mcpServers" object.`);
    }
  } else {
    addWarning(`${pluginName}: no mcp.json file found (only needed when using MCP servers).`);
  }
}

async function validateClaudeAdapter(expectedName) {
  const manifestPath = path.join(repoRoot, ".claude-plugin", "plugin.json");
  const manifest = await readJsonFile(manifestPath, "Claude plugin manifest");
  if (!manifest) {
    return;
  }

  if (manifest.$schema !== "https://json.schemastore.org/claude-code-plugin-manifest.json") {
    addError("Claude plugin manifest must use the Claude Code plugin manifest schema.");
  }

  if (typeof manifest.name !== "string" || !pluginNamePattern.test(manifest.name)) {
    addError("Claude plugin name must be lowercase kebab-case.");
  } else if (manifest.name !== expectedName) {
    addError(`Claude plugin name "${manifest.name}" does not match "${expectedName}".`);
  }

  for (const field of ["displayName", "version", "description", "license"]) {
    if (typeof manifest[field] !== "string" || manifest[field].trim().length === 0) {
      addError(`Claude plugin: "${field}" is required.`);
    }
  }

  if (!manifest.author || typeof manifest.author.name !== "string" || manifest.author.name.length === 0) {
    addError('Claude plugin: "author.name" is required.');
  }

  if (!Array.isArray(manifest.keywords) || manifest.keywords.length === 0) {
    addError('Claude plugin: "keywords" must be a non-empty array.');
  }

  for (const field of ["skills", "commands", "agents", "hooks", "mcpServers", "outputStyles", "lspServers"]) {
    for (const value of extractPathValues(manifest[field])) {
      if (!value.startsWith("./")) {
        addError(`Claude plugin field "${field}" must use a path beginning with "./": "${value}".`);
      }
      await validateReferencedPath(repoRoot, field, value, "Claude plugin");
    }
  }

  const mcpConfig = await readJsonFile(path.join(repoRoot, ".mcp.json"), "Claude MCP configuration");
  if (!mcpConfig?.mcpServers || typeof mcpConfig.mcpServers !== "object" || Array.isArray(mcpConfig.mcpServers)) {
    addError('Claude .mcp.json must contain an "mcpServers" object.');
    return;
  }

  for (const [serverName, server] of Object.entries(mcpConfig.mcpServers)) {
    if (!server || typeof server !== "object" || !["http", "streamable-http"].includes(server.type)) {
      addError(`Claude MCP server "${serverName}" must declare type "http" or "streamable-http".`);
    }
    if (typeof server?.url !== "string" || !server.url.startsWith("https://")) {
      addError(`Claude MCP server "${serverName}" must use an HTTPS URL.`);
    }
  }
}

async function validateKimiAdapter(expectedName, expectedVersion) {
  const manifestPath = path.join(repoRoot, "kimi.plugin.json");
  const manifest = await readJsonFile(manifestPath, "Kimi Code plugin manifest");
  if (!manifest) {
    return;
  }

  if (typeof manifest.name !== "string" || !kimiPluginNamePattern.test(manifest.name)) {
    addError("Kimi Code plugin name must match [a-z0-9][a-z0-9_-]{0,63}.");
  } else if (manifest.name !== expectedName) {
    addError(`Kimi Code plugin name "${manifest.name}" does not match "${expectedName}".`);
  }

  for (const field of ["version", "description", "homepage", "license"]) {
    if (typeof manifest[field] !== "string" || manifest[field].trim().length === 0) {
      addError(`Kimi Code plugin: "${field}" is required.`);
    }
  }

  if (manifest.version !== expectedVersion) {
    addError(
      `Kimi Code plugin version "${manifest.version}" does not match adapter version "${expectedVersion}".`
    );
  }

  if (!manifest.author || typeof manifest.author.name !== "string" || manifest.author.name.length === 0) {
    addError('Kimi Code plugin: "author.name" is required.');
  }

  if (!Array.isArray(manifest.keywords) || manifest.keywords.length === 0) {
    addError('Kimi Code plugin: "keywords" must be a non-empty array.');
  }

  for (const value of extractPathValues(manifest.skills)) {
    if (!value.startsWith("./")) {
      addError(`Kimi Code plugin field "skills" must use a path beginning with "./": "${value}".`);
    }
    await validateReferencedPath(repoRoot, "skills", value, "Kimi Code plugin");
  }

  if (!manifest.mcpServers || typeof manifest.mcpServers !== "object" || Array.isArray(manifest.mcpServers)) {
    addError('Kimi Code plugin must contain an "mcpServers" object.');
  } else {
    const hctiServer = manifest.mcpServers.hcti;
    if (!hctiServer || typeof hctiServer !== "object" || Array.isArray(hctiServer)) {
      addError('Kimi Code plugin must declare the "hcti" MCP server.');
    } else if (typeof hctiServer.url !== "string" || !hctiServer.url.startsWith("https://")) {
      addError('Kimi Code MCP server "hcti" must use an HTTPS URL.');
    }
  }

  if (!manifest.interface || typeof manifest.interface !== "object" || Array.isArray(manifest.interface)) {
    addError('Kimi Code plugin must contain an "interface" object.');
  } else {
    for (const field of ["displayName", "shortDescription", "longDescription", "developerName", "websiteURL"]) {
      if (typeof manifest.interface[field] !== "string" || manifest.interface[field].trim().length === 0) {
        addError(`Kimi Code plugin interface: "${field}" is required.`);
      }
    }
    if (
      typeof manifest.interface.websiteURL === "string" &&
      !manifest.interface.websiteURL.startsWith("https://")
    ) {
      addError('Kimi Code plugin interface "websiteURL" must use HTTPS.');
    }
  }
}

async function validateGeminiAdapter(expectedName, expectedVersion) {
  const manifestPath = path.join(repoRoot, "gemini-extension.json");
  const manifest = await readJsonFile(manifestPath, "Gemini CLI extension manifest");
  if (!manifest) {
    return;
  }

  if (typeof manifest.name !== "string" || !marketplaceNamePattern.test(manifest.name)) {
    addError("Gemini CLI extension name must be lowercase kebab-case.");
  } else if (manifest.name !== expectedName) {
    addError(`Gemini CLI extension name "${manifest.name}" does not match "${expectedName}".`);
  }

  for (const field of ["version", "description"]) {
    if (typeof manifest[field] !== "string" || manifest[field].trim().length === 0) {
      addError(`Gemini CLI extension: "${field}" is required.`);
    }
  }

  if (manifest.version !== expectedVersion) {
    addError(
      `Gemini CLI extension version "${manifest.version}" does not match adapter version "${expectedVersion}".`
    );
  }

  if (!manifest.mcpServers || typeof manifest.mcpServers !== "object" || Array.isArray(manifest.mcpServers)) {
    addError('Gemini CLI extension must contain an "mcpServers" object.');
    return;
  }

  const hctiServer = manifest.mcpServers.hcti;
  if (!hctiServer || typeof hctiServer !== "object" || Array.isArray(hctiServer)) {
    addError('Gemini CLI extension must declare the "hcti" MCP server.');
    return;
  }

  if (hctiServer.type !== "http") {
    addError('Gemini CLI MCP server "hcti" must use type "http" for Streamable HTTP.');
  }
  if (typeof hctiServer.url !== "string" || !hctiServer.url.startsWith("https://")) {
    addError('Gemini CLI MCP server "hcti" must use an HTTPS URL.');
  }
  if (hctiServer.command || hctiServer.headers || hctiServer.env) {
    addError('Gemini CLI MCP server "hcti" must use hosted OAuth without a local command, headers, or environment variables.');
  }
}

async function main() {
  const marketplacePath = path.join(repoRoot, ".cursor-plugin", "marketplace.json");
  const rootManifestPath = path.join(repoRoot, ".cursor-plugin", "plugin.json");

  if (await pathExists(rootManifestPath)) {
    if (await pathExists(marketplacePath)) {
      addError("A single-plugin repository must not also contain .cursor-plugin/marketplace.json.");
    }

    const rootManifest = await readJsonFile(rootManifestPath, "Plugin manifest");
    if (rootManifest) {
      const expectedName = typeof rootManifest.name === "string" ? rootManifest.name : "root plugin";
      await validatePluginDirectory(repoRoot, expectedName, rootManifest);
      await validateClaudeAdapter(expectedName);
      await validateKimiAdapter(expectedName, rootManifest.version);
      await validateGeminiAdapter(expectedName, rootManifest.version);
    }
    summarizeAndExit();
    return;
  }

  const marketplace = await readJsonFile(marketplacePath, "Marketplace manifest");
  if (!marketplace) {
    summarizeAndExit();
    return;
  }

  if (typeof marketplace.name !== "string" || !marketplaceNamePattern.test(marketplace.name)) {
    addError(
      'Marketplace "name" must be lowercase kebab-case and start/end with an alphanumeric character.'
    );
  }

  if (!marketplace.owner || typeof marketplace.owner.name !== "string" || marketplace.owner.name.length === 0) {
    addError('Marketplace "owner.name" is required.');
  }

  if (!Array.isArray(marketplace.plugins) || marketplace.plugins.length === 0) {
    addError('Marketplace "plugins" must be a non-empty array.');
    summarizeAndExit();
    return;
  }

  const pluginRoot = marketplace.metadata?.pluginRoot;
  if (pluginRoot !== undefined) {
    if (typeof pluginRoot !== "string" || !isSafeRelativePath(pluginRoot)) {
      addError('Marketplace "metadata.pluginRoot" must be a safe relative path.');
    } else {
      const pluginRootAbs = path.join(repoRoot, pluginRoot);
      await ensureDirectory(pluginRootAbs, 'Marketplace "metadata.pluginRoot"');
    }
  }

  const seenNames = new Set();
  for (const [index, entry] of marketplace.plugins.entries()) {
    const label = `plugins[${index}]`;

    if (!entry || typeof entry !== "object") {
      addError(`${label} must be an object.`);
      continue;
    }

    if (typeof entry.name !== "string" || !pluginNamePattern.test(entry.name)) {
      addError(`${label}.name must be lowercase and use only alphanumerics, hyphens, and periods.`);
      continue;
    }

    if (seenNames.has(entry.name)) {
      addError(`Duplicate plugin name in marketplace manifest: "${entry.name}"`);
    }
    seenNames.add(entry.name);

    const sourcePath = resolveMarketplaceSource(entry.source, pluginRoot ?? "");
    if (!sourcePath) {
      addError(`${label}.source must be a string path.`);
      continue;
    }
    if (!isSafeRelativePath(sourcePath)) {
      addError(`${label}.source is not a safe relative path: "${sourcePath}"`);
      continue;
    }

    const pluginDir = path.join(repoRoot, sourcePath);
    const pluginDirExists = await ensureDirectory(pluginDir, `${label}.source`);
    if (!pluginDirExists) {
      continue;
    }

    const manifestPath = path.join(pluginDir, ".cursor-plugin", "plugin.json");
    const pluginManifest = await readJsonFile(manifestPath, `${entry.name} plugin manifest`);
    if (!pluginManifest) {
      continue;
    }

    await validatePluginDirectory(pluginDir, entry.name, pluginManifest);

    const hooksPath = path.join(pluginDir, "hooks", "hooks.json");
    if (!(await pathExists(hooksPath))) {
      addWarning(`${entry.name}: no hooks/hooks.json file found (only needed when using hooks).`);
    }

  }

  summarizeAndExit();
}

function summarizeAndExit() {
  if (warnings.length > 0) {
    console.log("Warnings:");
    for (const warning of warnings) {
      console.log(`- ${warning}`);
    }
    console.log("");
  }

  if (errors.length > 0) {
    console.error("Validation failed:");
    for (const error of errors) {
      console.error(`- ${error}`);
    }
    process.exit(1);
  }

  console.log("Validation passed.");
}

await main();
