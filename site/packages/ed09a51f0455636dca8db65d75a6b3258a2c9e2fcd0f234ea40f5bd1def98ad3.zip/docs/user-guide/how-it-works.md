# How It Works

**Version:** 1.4
**Date:** 2026-05-25

This page is the mental model. It will not teach you any commands. It will explain why SweetClaude is shaped the way it is, so the rest of the docs make sense.

---

## The Core Bet

SweetClaude is built on one bet: AI coding tools generate convincing-looking output much faster than humans can verify it, and the gap between speed and verification is where bad software comes from.

The response cannot be "slow down." Slowing down forfeits the productivity gain that justifies the tool. Instead, the response is *structure* — phases that prevent skipping, hooks that prevent test/implementation drift, separate AI contexts that prevent rationalization, and persistent state that prevents the system from forgetting what it decided yesterday.

Everything else in this document is a consequence of that bet.

---

## Two Kinds of State

Most workflow tools track one thing: what step are you on? SweetClaude tracks two, because they move at different speeds.

**`version_stage`** is where your *project* is in its release lifecycle. It moves slowly. Values: `PROTOTYPE → ALPHA → BETA → GA → SCALED → MAINTAINED`. A v2 rewrite resets it. You declare it; the system never advances it on you.

**`active_work_item`** is the *specific work* in flight right now. It moves fast. A bug fix work item lives for an hour or two. A net-new feature work item might span weeks. Each work item has a type (one of 19), a workflow (a sequence of phases), and a current phase.

Both live in `.sweetclaude/state/sweetclaude.yaml`:

```yaml
project:
  version_stage: BETA

session:
  deference_level: collaborative

work:
  active:
    id: WI-014
    type: net-new-feature
    workflow: [DISCOVER, DEFINE, DESIGN, PLAN, IMPLEMENT, VERIFY, SHIP]
    phase: IMPLEMENT
    title: "OAuth login flow"
    started: 2026-04-29T14:00:00+00:00
    entry_category: mid-project-planned
```

The two-dimension model matters because it lets the framework do **progressive disclosure**. A PROTOTYPE-stage project does not see compliance work types — those are noise at that stage. A MAINTAINED project gets feature work de-emphasized in favor of operations and security patches. The pipeline you see is appropriate to where the project actually is, not a feature dump.

---

## Phases as Quality Gates

The 7-phase pipeline (DISCOVER → DEFINE → DESIGN → PLAN → IMPLEMENT → VERIFY → SHIP) looks like the standard SDLC, but it is not used the standard way.

In a typical SDLC, phases are time-boxed: "we are in design this sprint." In SweetClaude, phases are **quality gates**. A phase is done when its exit criteria are met. Not when the calendar says so. Not when you feel like it.

This is why SweetClaude refuses to give time estimates. The right question is not "how long will design take?" — it is "have we covered the architecture, the data model, the API contracts, and recorded the key decisions?" When the answer is yes, design is done.

There are two kinds of gates. **Soft gates** are advisory — you can override with "I've addressed this informally — proceed." **Hard gates** (⚠️) cannot be soft-bypassed. They apply to high-blast-radius work at GA+ stages: data migration integrity checks, security patch reviews, infrastructure change rollback plans, technology migration cutover decisions. Hard gate overrides require explicit risk acceptance, logged to the decision log.

The list of soft and hard gates is in [`phases-and-workflows.md`](phases-and-workflows.md).

---

## Phase Dwelling

This is the part most workflow tools get wrong, and SweetClaude treats it as load-bearing.

SweetClaude **never pushes you to advance**. It will not say "ready to move on?" or "shall we proceed to the next phase?" or any variant. After presenting work, it sits available for iteration. You decide when a phase is done.

The reason is that iteration is the work. Most strategy and design problems are not solved on the first pass — they are sharpened. The framework that asks "ready to move on?" every five minutes is fighting the user, not helping them.

If you want to advance, you say so. If you want to dwell, you do nothing — SweetClaude waits.

The cost of this is that some users feel adrift, especially in early phases where it is unclear what "done" looks like. The mitigation is the [phase gates reference](phases-and-workflows.md): each phase has explicit exit criteria. When the criteria are met, you know.

---

## Workflow Shapes

A bug fix does not need discovery. A data migration does not need user stories. SweetClaude has six workflow shapes that cover all 19 work types:

| Shape | Phases | Used for |
|---|---|---|
| `full-pipeline` | DISCOVER → DEFINE → DESIGN → PLAN → IMPLEMENT → VERIFY → SHIP | Net-new features, external integrations |
| `abbreviated` | DEFINE → DESIGN → IMPLEMENT → VERIFY → SHIP | Enhancements, infrastructure changes |
| `extended-abbreviated` | ASSESS → DEFINE → DESIGN → IMPLEMENT → VERIFY → SHIP | Compliance work |
| `diagnostic` | DIAGNOSE → IMPLEMENT → VERIFY → SHIP | Bug fixes, security patches, performance |
| `migration` | ASSESS → DESIGN → PLAN → IMPLEMENT → VERIFY → CUTOVER → CLEANUP | Tech migrations, API deprecations |
| `compressed` | DIAGNOSE → IMPLEMENT → SHIP → POST-MORTEM | Hotfixes |

The work type determines the shape. You do not pick. When you describe the work to `/sweetclaude:go` ("there is a bug in the auth flow"), the framework classifies it (`bug-fix`), reads the shape from config (`diagnostic`), and starts at DIAGNOSE. The diagnostic shape exists because you cannot fix what you cannot reproduce.

---

## 4.x Beta Operating Model

4.x separates framework update, project repair, recovery, and taxonomy
migration. `/sweetclaude:update` syncs framework files inside the installed plugin
channel and reports drift. It does not run project-state or taxonomy migrations
inline. After plugin update and restart, project maintenance starts with
`/sweetclaude:doctor`.

Doctor is the maintenance front door. It runs deterministic checks over
state, hooks, storage, migration readiness, config, files, onboarding, and
environment, then chooses a route:

| Route status | Meaning | Next command |
|---|---|---|
| `recovery-available` | The project is stuck or unsafe to migrate. | `/sweetclaude:recover` |
| `supported-migration-available` | A supported flat v3 `BL-NNN` backlog layout passed preflight. | `/sweetclaude:migrate` |
| `compatibility-mode` | Recovery accepted a legacy taxonomy layout without moving artifacts. | Continue normal work. |
| `no-migration-recommended` | No supported migration is needed. | Continue normal work. |

Migration is deliberately narrow. The supported migrator handles flat v3 backlog
files such as `.sweetclaude/product/backlog/BL-001-example.md`. Unsafe typed
legacy directories such as `stories/`, `bugs/`, `debt/`, and `chores/` route to
recovery instead of blind migration. Recovery can stabilize those projects in
compatibility mode so SweetClaude stops prompting migration until a layout-specific
migrator exists.

4.x also changes the product artifact model. Current issue files use unified
`ISSUE-NNN` IDs, with `type` stored in frontmatter rather than encoded in the
filename. Backlog, roadmap issues, epics, and milestones live under
`.sweetclaude/product/`. Markdown remains the source of truth, but 4.x builds a
derived SQLite cache at `.sweetclaude/cache/roadmap.db` so status, dashboard,
backlog, and routing skills can query the project consistently. The cache is
rebuildable and should not be treated as authoritative project history.

---

## Project Modes

SweetClaude has four project modes that calibrate structure and enforcement to where your project is. You pick a mode at init; enforcement is immediate. Think of it as a dial — Flow Mode is the lightweight end, Agile is the structured end, with Kanban and Shape Up in between.

| Mode | What it signals | TDD level | Key enforcement |
|---|---|---|---|
| **Flow Mode** | Solo exploration, early stage, no ceremony needed | Level 1 | No gates, all skills available. Quietly accumulates thin artifacts in the background. |
| **Kanban** | Continuous delivery, work organized as a flowing board | Level 1 | WIP limit (default 3 in-progress issues, hard block), sprint-planning skills blocked |
| **Shape Up** | 6-week cycles with pitches and a betting table | Level 2 | Sprint and backlog-triage skills blocked, betting table approval required before implementation, ship/no-ship gate at cycle end |
| **Agile** | Sprint-based, structured iteration | Level 2 | Active sprint required to implement (hard block), sprint close required before ship |

There is also **John Wick mode** — an experimental, fully autonomous SDLC pipeline from discovery through PR (TDD Level 3, subagent isolation, QA caucus). Invoked via `/sweetclaude:john-wick`, not through the mode selector.

Modes are not permanent. `/sweetclaude:project-mode` re-assesses or accepts a direct argument. Every shift snapshots state first.

Within the execution layer, the work hierarchy is **Milestone → Sprint → Story** — three levels, that is all. Epics and themes are classification attributes on stories (a `epic_id` and `theme_id` field), not nodes that stories flow through. A sprint in Agile mode anchors to a milestone via `milestone_id`; stories are pulled into it regardless of which epic or theme they belong to. This is the Linear model, not the Jira model — epics are goal lenses and progress metrics, not delivery containers.

Enforcement happens at three layers: (1) `effective-gates.yaml`, compiled at mode selection time into `.sweetclaude/state/`, contains the full rule set for the active mode; (2) `wip-limit.sh`, a PreToolUse hook, blocks tool calls in Kanban mode when the WIP limit is reached; (3) MODE_CHECK blocks inside individual skills reject invocations that are disallowed by the active mode.

Mode selection happens at project init via the `project-assess-shape` five-question interview, and on demand via `/sweetclaude:project-mode`.

---

## TDD by Hook, Not by Prompt

Most TDD documentation is advisory: "write the test first." SweetClaude does not believe in advisory TDD because advisory TDD fails. The implementer (human or AI) ends up touching the test to make it pass, or writes the test after the code so the test rationalizes the implementation rather than specifying behavior.

SweetClaude substantially raises the cost of this at higher levels:

- **Test-guardian hook** (PreToolUse) blocks edits to test files during the IMPLEMENT phase. Not "warns" — blocks.
- **Auto-test-runner hook** (PostToolUse) runs tests automatically after every source edit. Not "reminds" — runs.
- **Subagent isolation** at TDD Level 2-3 means the test writer and implementer are different agents in different contexts. The implementer never sees the spec or the test writer's reasoning. Only the tests.

This sounds extreme until you watch what happens without it: a test passes, you ship, and three weeks later production breaks because the test was passing for the wrong reason. The hooks remove that failure mode.

The four TDD levels (0 through 3) calibrate the discipline to the work. A hotfix does not get the full pipeline. A net-new feature with Gherkin specs does. See [tdd.md](tdd.md) for the full breakdown.

---

## Why Subagents Are Isolated

When the test writer agent reads the user story, writes failing tests, and the implementer reads only those tests, the implementer cannot rationalize a poor test by reasoning about what the spec "really meant." It has to make the tests pass with code, not with arguments.

This is the same principle that produced double-blind clinical trials. Information that flows backward from outcome to design corrupts the design. SweetClaude prevents the flow.

The test-writer/implementer pair is one of three named subagent patterns in the framework. The others are the caucus (parallel isolated agents that synthesize findings) and the John Wick escalation pattern (a privileged agent for enforcement tasks). The active agent definitions live in the `agents/` directory; the user-facing behavior is summarized here and in the skills reference.

---

## Deference Levels

Three levels: collaborative, guided, autonomous.

The honest framing: **deference levels are about how much you trust the framework today**, not about how complex the work is. Your first session should be collaborative because you are still building a model of what SweetClaude does. Your tenth feature in the same project might be autonomous because you have seen the rhythm and you are tired of confirming sub-steps.

Autonomous does not mean unsupervised. The framework still pauses at phase gates. It still respects hard gates. It still saves state. It just stops asking "okay to proceed?" between every micro-step.

The level is changeable mid-session by saying "switch to guided" or "go autonomous." SweetClaude immediately respects the change and updates `sweetclaude.yaml`.

---

## Persistence Across Sessions

Claude Code sessions die. Context windows fill. Networks drop. SweetClaude is designed to survive this.

The structured state files in `.sweetclaude/state/` and product artifacts in `.sweetclaude/product/` are the source of truth — not conversation history and not the derived SQLite cache. Skills re-read state and product files at every step rather than relying on what was said earlier. Decisions go to `decision-log.md`. Assumptions go to `assumption-register.md`. Scope changes go to `scope-changes.md`. Improvement feedback goes to `improvement-register.md`.

When you resume a session, `/sweetclaude:go` reads state, rebuilds or reads the roadmap cache, and re-orients. You do not have to remember what you were doing.

Doctor and recovery write their own run artifacts under `.sweetclaude/state/doctor-runs/` and `.sweetclaude/state/recovery-runs/`. Those records explain what was scanned, what was changed, and how to roll back a recovery. Recovery snapshots can contain copies of project state and product artifacts, so they are operational records rather than source-control history.

`.sweetclaude/` is intentionally separate from your distributable code — SweetClaude keeps its own artifacts there so they never mingle with the codebase you ship. Commit the durable project history: state, product artifacts, plans, and traceability. Keep derived caches and recovery snapshots out of source control.

---

## What Lives Where

```
~/.claude/                          ← Global SweetClaude install
├── skills/sweetclaude/             ← all skills
├── agents/sweetclaude/             ← 8 isolated subagents
├── hooks/sweetclaude/              ← TDD enforcement hooks
├── rules/sweetclaude/              ← Phase gates, TDD levels, interaction model
└── config/sweetclaude/             ← Phase-skill mapping, workflow templates

your-project/.sweetclaude/          ← Per-project state
├── state/
│   ├── sweetclaude.yaml            ← Unified state
│   ├── effective-gates.yaml        ← Compiled mode enforcement rules
│   ├── project.yaml                ← Language, framework, commands
│   ├── decision-log.md
│   ├── assumption-register.md
│   ├── improvement-register.md
│   ├── scope-changes.md
│   ├── doctor-runs/                ← Doctor archives and manifests
│   └── recovery-runs/              ← Recovery snapshots and rollback manifests
├── product/
│   ├── backlog/                    ← Unified ISSUE-NNN backlog items
│   └── roadmap/                    ← Milestones, epics, and roadmap issues
├── cache/
│   └── roadmap.db                  ← Derived SQLite cache; rebuildable
├── plans/                          ← Claude Code plan files
├── traceability/                   ← Story → requirement → test → code
└── disabled                        ← Optional: presence disables SweetClaude
```

The split is intentional. Global install is the framework. Per-project state and product artifacts are your work. They are committed separately. The framework can update without disturbing project history, while doctor and recovery can inspect or stabilize a project without rewriting it blindly.

---

## What SweetClaude Will Not Do

This is the part most documentation skips. SweetClaude has explicit non-goals:

**It will not give time estimates.** AI-assisted solo development does not run on calendar time. If you ask "how long will this take?", SweetClaude redirects: "I'm your implementation partner — I build with you at AI speed, not calendar speed. Let's focus on what needs to be done."

**It will not push you forward.** Phase advancement is the user's call. Always.

**It will not modify tests during implementation.** Hooks block this physically.

**It will not silently skip steps in the corpus pipeline.** The state machine refuses out-of-order operations and explains why if you try.

**It will not assume your stack.** Codebase discovery drives all configuration. Templates, not constants. SweetClaude works on Python, Go, TypeScript, Rust, or anything else because the workflow is the product.

---

## Enforcement Tiers

Not all behavioral properties in SweetClaude are guaranteed equally. Some are enforced deterministically — hooks that fire regardless of what the model does. Others are instruction-guided — rules that Claude is directed to follow, but which are probabilistic by nature.

This distinction matters because deterministic properties are version-stable (a hook doesn't degrade when the underlying model changes) and instruction-guided properties are not.

**Deterministic (hook-enforced):**

| Property | Mechanism | What it guarantees |
|---|---|---|
| Test files cannot be edited during IMPLEMENT | `test-guardian.sh` (PreToolUse) | Edits to test directories are blocked at the tool call level; the user can override via tool approval |
| Tests run after every source edit | `auto-test-runner.sh` (PostToolUse) | Test suite runs automatically after source edits; the user can override via tool approval |
| WIP limit enforced in Kanban mode | `wip-limit.sh` (PreToolUse) | Blocks tool calls that would create new in-progress work when the WIP limit is reached |
| TDD Level 2-3 context isolation | Subagent architecture | Implementer agent never receives the spec or test writer's reasoning |
| Phase advancement phrases removed from responses | `phase-dwelling-guard.sh` (Stop hook) | When Protocol Guardian is active, responses containing "ready to move on?" are blocked before reaching the user |

**Instruction-guided (probabilistic):**

| Property | Mechanism | What it means |
|---|---|---|
| Phase dwelling — never asks "ready to move on?" | `interaction-model.md` rule | Claude is directed to dwell; Protocol Guardian enforces it when active |
| Deference level respect | `interaction-model.md` rule | Claude adjusts how frequently it stops based on the configured level |
| Improvement register capture triggers | `interaction-model.md` rule | Claude is directed to capture feedback at defined trigger points |
| Propose-not-ask interaction mode | `interaction-model.md` rule | Claude defaults to making proposals with reasoning rather than asking open-ended questions |
| Adaptive language matching | `interaction-model.md` rule | Claude matches the user's vocabulary and domain language |

The practical implication: instruction-guided properties are the right implementation choice for behavioral nuance that cannot be mechanically verified. They work well most of the time and degrade gracefully. Deterministic properties are the right choice for correctness guarantees that the framework's value depends on. If a property is described as "load-bearing" in this document and it is instruction-guided, enabling the Protocol Guardian (`/sweetclaude:guardian-on`) upgrades it to deterministic enforcement for that session.

---

## What to Read Next

- Concrete walkthroughs of specific scenarios → [Walkthroughs](walkthroughs.md)
- Reference for all phases and work types → [Phases and Workflows](phases-and-workflows.md)
- Reference for all skills → [Skills Reference](skills-reference.md)
- Honest tradeoffs and when not to use → [FAQ](faq.md)
