# Session Logging Reference

Specification for the `--log` and `--stats` features. Referenced from SKILL.md Phase 6.

---

## Log File Location

`~/.claude/courtroom-sessions.jsonl`

One JSON object per line. Each line is one completed courtroom session.

---

## Schema

```json
{
  "ts": 1712345678,
  "task_hash": "a3f8b2c1d4e5",
  "file_count": 3,
  "rounds": 1,
  "raw_objections": 9,
  "filtered_objections": 2,
  "surviving_objections": 7,
  "accepted": 4,
  "rejected": 1,
  "compromised": 2,
  "codex_verdict": "approved-with-concerns",
  "duration_seconds": 312,
  "mode": "strict",
  "quick": false,
  "dual_plan": false,
  "task_type": "bugfix"
}
```

### Field Definitions

| Field | Type | Description |
|-------|------|-------------|
| `ts` | integer | Unix timestamp (seconds) when the verdict was rendered |
| `task_hash` | string | 12-char hex prefix of SHA-256(salt + task_description). Salt is a fixed random string stored in `~/.claude/courtroom-salt.txt` (created on first use). Prevents rainbow-table guessing of common prompts. |
| `file_count` | integer | Number of affected files. Never raw paths. |
| `rounds` | integer | Number of debate rounds completed (1-3) |
| `raw_objections` | integer | Total objections from Codex before filtering |
| `filtered_objections` | integer | Objections auto-filtered by the catalog |
| `surviving_objections` | integer | Objections that reached the rebuttal phase |
| `accepted` | integer | Objections Claude ACCEPTED |
| `rejected` | integer | Objections Claude REJECTED |
| `compromised` | integer | Objections Claude COMPROMISED |
| `codex_verdict` | string | Final Codex verdict enum value |
| `duration_seconds` | integer | Elapsed wall-clock seconds from Opening Statement to Verdict |
| `mode` | string | `"normal"`, `"strict"`, or `"quick"` |
| `quick` | boolean | Whether `--quick` was active |
| `dual_plan` | boolean | Whether `--dual-plan` was active |
| `task_type` | string | Detected or explicit task type (`"bugfix"`, `"security"`, `"refactor"`, `"feature"`, or `null` if dismissed) |

---

## Salt File

On first `--log` invocation, if `~/.claude/courtroom-salt.txt` does not exist:

```bash
SALT=$(head -c 16 /dev/urandom 2>/dev/null | od -A n -t x1 | tr -d ' \n' || date +%s%N)
printf '%s\n' "$SALT" > "${HOME}/.claude/courtroom-salt.txt"
```

Read the salt before computing any task_hash:

```bash
SALT=$(cat "${HOME}/.claude/courtroom-salt.txt" 2>/dev/null || echo "default-salt")
TASK_HASH=$(printf '%s' "${SALT}${TASK_DESCRIPTION}" | sha256sum 2>/dev/null | cut -c1-12)
if [ -z "$TASK_HASH" ]; then
  TASK_HASH=$(printf '%s' "${SALT}${TASK_DESCRIPTION}" | shasum -a 256 2>/dev/null | cut -c1-12)
fi
if [ -z "$TASK_HASH" ]; then
  TASK_HASH=$(date +%s | head -c 12)
fi
```

If neither `sha256sum` nor `shasum` is available: use the first 12 chars of
`$(date +%s%N | head -c 12)` as a fallback (non-cryptographic, but preserves format).

---

## Append Section

Build the JSON line, then append using the atomic pattern from error-handling.md
(Atomic Append Pattern for Session Logging):

```bash
# Compute fields (re-declare all from conversation context)
LOG_FILE="${HOME}/.claude/courtroom-sessions.jsonl"
SALT=$(cat "${HOME}/.claude/courtroom-salt.txt" 2>/dev/null || echo "default-salt")
TASK_HASH=$(printf '%s' "${SALT}${TASK_DESCRIPTION}" | sha256sum 2>/dev/null | cut -c1-12)
if [ -z "$TASK_HASH" ]; then
  TASK_HASH=$(printf '%s' "${SALT}${TASK_DESCRIPTION}" | shasum -a 256 2>/dev/null | cut -c1-12)
fi
if [ -z "$TASK_HASH" ]; then
  TASK_HASH=$(date +%s | head -c 12)
fi
TS=$(date +%s)
# Build JSON (all values from conversation context)
JSON_LINE="{\"ts\":${TS},\"task_hash\":\"${TASK_HASH}\",\"file_count\":${FILE_COUNT},\"rounds\":${ROUNDS_COMPLETED},\"raw_objections\":${RAW_OBJECTIONS},\"filtered_objections\":${FILTERED_OBJECTIONS},\"surviving_objections\":${SURVIVING_OBJECTIONS},\"accepted\":${ACCEPTED_COUNT},\"rejected\":${REJECTED_COUNT},\"compromised\":${COMPROMISED_COUNT},\"codex_verdict\":\"${CODEX_VERDICT}\",\"duration_seconds\":${DURATION_SECONDS},\"mode\":\"${MODE}\",\"quick\":${QUICK_BOOL},\"dual_plan\":${DUAL_PLAN_BOOL},\"task_type\":${TASK_TYPE_JSON}}"
# Append atomically (see error-handling.md Atomic Append Pattern)
TEMP_LOG="${LOG_FILE}.tmp.$$"
printf '%s\n' "$JSON_LINE" > "$TEMP_LOG" \
  || { echo "WARNING: Failed to write temp log; skipping."; exit 0; }
cat "$TEMP_LOG" >> "$LOG_FILE" \
  || { echo "WARNING: Failed to append to log; skipping."; rm -f "$TEMP_LOG"; exit 0; }
rm -f "$TEMP_LOG"
echo "Session logged: $LOG_FILE"
```

Where `TASK_TYPE_JSON` is `"null"` if task type was dismissed, or `'"bugfix"'` etc. with
quotes included.

---

## Display Stats Section

Invoked when `--stats` flag is used (Phase 1 Step 1.5).

```bash
LOG_FILE="${HOME}/.claude/courtroom-sessions.jsonl"
[ -f "$LOG_FILE" ] || { echo "No session log found at $LOG_FILE"; exit 0; }
# Count total sessions
TOTAL=$(wc -l < "$LOG_FILE" 2>/dev/null || echo 0)
echo "========================================"
echo "  COURTROOM SESSION STATISTICS"
echo "========================================"
echo "Total sessions logged: $TOTAL"
echo ""
echo "Log file: $LOG_FILE"
echo "Run 'cat $LOG_FILE | python3 -m json.tool' to inspect raw entries."
echo "========================================"
```

For richer statistics, Claude should read the JSONL file and compute in-context:
- Average surviving objections per session
- Acceptance rate (accepted / surviving_objections across all sessions)
- Most common codex_verdict values
- Session count by mode (normal / strict / quick)
- Session count by task_type

Display as a formatted table. Do not use external tools — read the file and compute in-context.

---

## Rotation

Rotation runs ONLY when `--stats` is invoked AND the log has more than 500 entries.
Keep the newest 500 lines:

```bash
LOG_FILE="${HOME}/.claude/courtroom-sessions.jsonl"
TOTAL=$(wc -l < "$LOG_FILE" 2>/dev/null || echo 0)
if [ "$TOTAL" -gt 500 ]; then
  TEMP_ROT="${LOG_FILE}.rot.$$"
  tail -n 500 "$LOG_FILE" > "$TEMP_ROT" \
    || { echo "WARNING: Rotation temp write failed; skipping rotation."; rm -f "$TEMP_ROT"; exit 0; }
  mv "$TEMP_ROT" "$LOG_FILE" \
    || { echo "WARNING: Rotation mv failed; skipping rotation."; rm -f "$TEMP_ROT"; exit 0; }
  echo "Log rotated: kept newest 500 entries (was $TOTAL)."
fi
```

`mv` is atomic on the same filesystem. If `mv` fails (cross-device): the rotation is skipped
silently — the log continues to grow until the next `--stats` invocation.
