# Task-Type Priority Checklists

Checklist definitions for each task type. Referenced from cross-examination-procedure.md Step 1b.

Each checklist is injected as the value for `{{TASK_CHECKLIST}}` in the cross-examination prompt.
The placeholder is positioned after `{{PROPOSED_PLAN}}` and before `## Your Review Priorities`.

---

## Checklist Format

```
## Priority Checklist for <taskType> Tasks

Before reviewing all 6 priority categories below, explicitly check each item in this list.
These are the highest-leverage concerns for this specific task type:

- [ ] <item 1>
- [ ] <item 2>
- [ ] <item 3>
- [ ] <item 4>
```

---

## bugfix

```
## Priority Checklist for bugfix Tasks

Before reviewing all 6 priority categories below, explicitly check each item in this list.
These are the highest-leverage concerns for this specific task type:

- [ ] Does the fix address the root cause, or only the symptom?
- [ ] Are all edge cases that could reproduce the original bug covered?
- [ ] Could the fix introduce a regression in adjacent code paths?
- [ ] Is there a case where the fix makes things worse than before?
```

---

## security

```
## Priority Checklist for security Tasks

Before reviewing all 6 priority categories below, explicitly check each item in this list.
These are the highest-leverage concerns for this specific task type:

- [ ] Are all user-controlled inputs validated and sanitized at boundaries?
- [ ] Could an attacker exploit the change (injection, privilege escalation, data exposure)?
- [ ] Are secrets, tokens, or credentials handled correctly?
- [ ] Does the change preserve existing permission checks, or bypass any?
```

---

## refactor

```
## Priority Checklist for refactor Tasks

Before reviewing all 6 priority categories below, explicitly check each item in this list.
These are the highest-leverage concerns for this specific task type:

- [ ] Does the refactor preserve ALL existing behavior, including error paths?
- [ ] Are all callers/importers of changed interfaces updated?
- [ ] Could the refactor introduce performance regressions?
- [ ] Is the new structure actually simpler, or just differently complex?
```

---

## feature

```
## Priority Checklist for feature Tasks

Before reviewing all 6 priority categories below, explicitly check each item in this list.
These are the highest-leverage concerns for this specific task type:

- [ ] Is the feature scoped correctly — not over-engineered, not under-built?
- [ ] Are integration points with existing code explicitly addressed?
- [ ] Are the new public interfaces backward-compatible or properly versioned?
- [ ] Is the feature testable in isolation?
```
