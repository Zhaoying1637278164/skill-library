# Deliberation Procedure

Phase 5 instructions for the Courtroom plugin. Referenced from SKILL.md Phase 5.

---

## Step 1: Build the Deliberation Prompt

Read template from skills/courtroom/references/deliberation-prompt.md.

Replace all placeholders: PROJECT_TYPE, LANGUAGE_FRAMEWORK, ORIGINAL_PLAN,
OBJECTIONS, REBUTTALS, REVISED_PLAN.

Store assembled prompt text in conversation context.

## Step 2: Invoke Codex

Write the prompt to a temp file via bash (printf -- see Step 2c in cross-examination-procedure.md):

```bash
TEMP_DIR="${TEMP:-${TMP:-/tmp}}"
# Normalize Windows backslashes to forward slashes
TEMP_DIR="${TEMP_DIR//\\//}"
# Resolve to absolute path if relative (e.g., $TEMP='tmp' on some Windows setups)
if [[ "$TEMP_DIR" != /* ]]; then
  TEMP_DIR="$(cd "$TEMP_DIR" 2>/dev/null && pwd)" || TEMP_DIR="/tmp"
fi
COURTROOM_DELIB_FILE=$(mktemp "${TEMP_DIR}/courtroom-XXXXXX.md" 2>/dev/null)
if [ -z \"$COURTROOM_DELIB_FILE\" ] || [ ! -f \"$COURTROOM_DELIB_FILE\" ]; then
  COURTROOM_DELIB_FILE=\"${TEMP_DIR}/courtroom-delib-${$}-${RANDOM}.md\"
  (set -o noclobber; > "$COURTROOM_DELIB_FILE") 2>/dev/null \
    || { echo "ERROR: Cannot create temp file safely"; exit 1; }
fi
echo "$COURTROOM_DELIB_FILE" >> "$MANIFEST"
```

Write content via printf (mandatory format string is %s
; content as arguments):

```bash
printf '%s
' \
'First line of deliberation prompt content' \n'Additional lines ...' \n> "$COURTROOM_DELIB_FILE" \
  || { echo "ERROR: Failed to write deliberation prompt"; exit 1; }
[ -s "$COURTROOM_DELIB_FILE" ] \
  || { echo "ERROR: Deliberation prompt file is empty"; exit 1; }
echo "Deliberation prompt: $COURTROOM_DELIB_FILE"
```


Invoke Codex using input redirection from the same workdir as Phase 3 (COURTROOM_WORKDIR):

```bash
test -r "$COURTROOM_DELIB_FILE" || { echo "ERROR: Not readable: $COURTROOM_DELIB_FILE"; exit 1; }
cat "$COURTROOM_DELIB_FILE" | codex exec --skip-git-repo-check -C "$COURTROOM_WORKDIR" - 2>&1
```

Set Claude Code Bash tool timeout to 150,000ms.
Never use "$(cat file)" as argument to codex exec.
Never place --sandbox before --skip-git-repo-check -- see cross-examination-procedure.md Step 2d.

Handle failures same as Phase 3 Step 2e.
If deliberation is skipped (timeout, empty output, user choice):
- Use rebuttal-revised plan as final plan, but only if Phase 4 completed fully
  and the revised plan section is non-empty.
- If Phase 4 was incomplete: fall back to Phase 2 plan with PARTIALLY-REVIEWED label.
- Set deliberation to "skipped" (distinct from null used when cross-exam was skipped).
- Codex Verdict in Phase 6: approved-without-deliberation

Delete the deliberation prompt file immediately after capturing output:

```bash
rm -f "$COURTROOM_DELIB_FILE" 2>/dev/null
```

## Step 3: Parse Deliberation Verdict

Parse Codex output for:
- Accepted objection review: properly-addressed | insufficiently-addressed | introduced-new-issue
- Rejected objection review: concede | sustain
- Compromise review: workable | problematic
- New issues: list or "none"
- Final assessment: approved | approved-with-concerns | needs-further-revision

## Step 4: Handle Additional Rounds

If remaining rounds > 0 AND verdict is needs-further-revision:
- Take sustain objections and insufficiently-addressed items
- Return to Phase 3 with these as forced focus areas
- Decrement remaining rounds
- Display round counter: "Round N of M"

If remaining rounds > 0 AND verdict is approved-with-concerns:
- Still run the next round to see if concerns can be resolved
- Decrement remaining rounds

If remaining rounds = 0, OR verdict is approved (no concerns):
- Proceed to Phase 6.

## Step 5: Display Deliberation Results

```
========================================
  DELIBERATION COMPLETE
========================================

Codex Assessment: <approved | approved-with-concerns | needs-further-revision>

Accepted Objections:
  [1] <target> -> <properly-addressed | insufficiently-addressed>

Rejected Objections:
  [2] <target> -> <concede | sustain>

Compromises:
  [3] <target> -> <workable | problematic>

New Issues: <none | list>
========================================
```

If any rejected objections received "sustain", incorporate into the final verdict as
Dissenting Opinions.

If verdict is needs-further-revision and no rounds remain, note outstanding concerns
but proceed to Phase 6 -- the user will decide.
