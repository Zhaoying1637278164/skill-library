---
description: "Cross-model deliberation — Claude proposes a plan, Codex cross-examines it, they debate, and the verdict gets executed"
argument-hint: "[--task \"description\"] [--files <path,...>] [--rounds <N>] [--auto-execute] [--strict]"
allowed-tools:
- Read
- Bash
- Edit
- Write
- Glob
- Grep
- AskUserQuestion
model: opus
---

# Courtroom: Cross-Model Deliberation

You are the **Courtroom Orchestrator**. Your role is to facilitate a structured debate between Claude (yourself) and OpenAI's Codex CLI to produce a battle-tested implementation plan before writing any code.

## Invocation

The user has invoked `/courtroom`. Parse `$ARGUMENTS` for the following flags:

- `--task "description"` — The task to plan. If not provided, treat the entire argument string as the task description.
- `--files <path,...>` — Comma-separated list of files to scope the plan to. Optional.
- `--rounds <N>` — Number of debate rounds between Claude and Codex. Default: `1`. No upper limit — the user decides how many rounds of scrutiny are needed.
- `--auto-execute` — If set, skip user approval after the verdict and execute immediately.
- `--strict` — If set, tell Codex to use a harsher critique mode (lower confidence threshold).

## Prerequisites

Before starting, verify that `codex` CLI is installed by running:

```bash
codex --version
```

If this fails, inform the user:
> Courtroom requires the OpenAI Codex CLI. Install it with: `npm install -g @openai/codex`

## Workflow

Follow the 7-phase workflow defined in the `courtroom` skill (`skills/courtroom/SKILL.md`). That skill contains the complete phase-by-phase instructions, Codex prompt templates, and report formatting.

Execute all 7 phases in order:
1. **Opening Statements** — Gather context
2. **Prosecution** — Build the implementation plan
3. **Cross-Examination** — Invoke Codex to challenge the plan
4. **Rebuttal** — Respond to each objection
5. **Deliberation** — Invoke Codex to review the revised plan
6. **Verdict** — Present the final plan to the user
7. **Execution** — Implement the verdict (only after user approval or `--auto-execute`)
