# The Courtroom

Cross-model deliberation plugin for Claude Code. Claude proposes an implementation plan, Codex cross-examines it, they debate, and the verdict gets executed.

Two AI models arguing so your code doesn't have to.

## Install

```bash
/plugin marketplace add JustineDaveMagnaye/the-courtroom
/plugin install courtroom
```

## Usage

```bash
/courtroom --task "refactor auth module" --files src/auth.ts
```

### Flags

| Flag | Description |
|------|-------------|
| `--task "description"` | What to plan |
| `--files path,...` | Scope to specific files |
| `--rounds N` | Number of debate rounds (default: 1) |
| `--strict` | Harsher critique mode |
| `--quick` | Fast mode (limited to 3 files) |
| `--dual-plan` | Codex generates its own plan before seeing Claude's |
| `--auto-execute` | Skip user approval |
| `--log` | Log session statistics |
| `--stats` | Show aggregated stats |

## How It Works

| Role | Model |
|------|-------|
| Prosecution | Claude (proposes the plan) |
| Cross-Examiner | Codex CLI (challenges it) |
| Judge | You (approve or reject) |

**7-phase workflow:**

1. **Opening Statements** - Gather context, verify Codex CLI, parse arguments
2. **Prosecution** - Claude builds a detailed implementation plan
3. **Cross-Examination** - Codex challenges the plan (logical flaws, edge cases, architecture, security)
4. **Rebuttal** - Claude responds: ACCEPT / REJECT / COMPROMISE per objection
5. **Deliberation** - Codex reviews the revised plan as neutral arbiter
6. **Verdict** - Final plan presented for approval
7. **Execution** - Approved plan gets implemented

## Key Features

- **Weak Objection Catalog** - Auto-filters 27 known false-positive patterns (style bikeshedding, YAGNI, scope creep, phantom references)
- **Task-Type Checklists** - Bugfix, security, refactor, and feature-specific review priorities injected into cross-examination
- **Dual-Plan Mode** - Codex generates an independent plan before seeing Claude's for comparison
- **Skill Discovery** - Auto-discovers relevant skills from both Claude and Codex
- **Session Logging** - Tracks objection acceptance rates across sessions

## Requirements

- [Claude Code](https://claude.ai/code)
- [Codex CLI](https://github.com/openai/codex) installed and configured

## License

MIT
