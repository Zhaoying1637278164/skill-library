# Skills for Developers Who Care About Quality

[![skills.sh](https://skills.sh/b/mkanat/skills)](https://skills.sh/mkanat/skills)

**Make code simpler, faster, and easier to read.**

[`cleanup`](skills/cleanup/SKILL.md) repeatedly finds duplicated information,
repeated work, unnecessary defensive code, and accidental complexity. In a fully
tested example, it found 32 significant cleanups and made the codebase **1.34×
faster** while using less memory.

```sh
npx skills add mkanat/skills --skill cleanup
```

## Example

You can see a
[report of all the cleanups the `cleanup` skill did on an example codebase](examples/minibuild/README.md),
with short diffs showing many of the improvements.

Here's the full story:

I had Codex build a fully-tested, working incremental build system using GPT-5.6
Sol, called `minibuild`. I had it run a type checker (basedpyright in strict
mode), run a full linter (ruff with `ALL` checks enabled), and do
auto-formatting. I also had it check code coverage and add missing tests, so it
has 100% coverage without any mocking. I did not otherwise review or modify its
code.

You can see the **before** version in
[`examples/minibuild/before/`](examples/minibuild/before/).

I then ran `cleanup` on that codebase. It ran by itself five times in a row and
did 9 significant refactorings. I then manually triggered `cleanup` five more
times. It ran itself in loops a bunch of times and made 23 more cleanups.

The **after** version is in
[`examples/minibuild/after/`](examples/minibuild/after/).

You can see the [full diff](examples/minibuild/cleanup.diff) between `before`
and `after`, if you want.

The cleanup dramatically improved the code structure, but it also made real
functional improvements to the system. It removed repeated work, stopped keeping
multiple copies of the same information, and avoided redoing work when the final
result had not actually changed. On a 10,001-task benchmark, the cleaned-up
version actually ran **1.34× faster** while using less memory. (You can see the
full performance-testing harness and results in
[`examples/minibuild/performance/`](examples/minibuild/performance/).)

## Install

### Any agent supported by skills.sh

The `skills` CLI supports Codex, Claude Code, Cursor, GitHub Copilot, Gemini
CLI, Windsurf, Cline, OpenCode, and many other agents:

```sh
npx skills add mkanat/skills
```

The CLI lets you choose the skill and target agents interactively. To install
`cleanup` non-interactively:

```sh
npx skills add mkanat/skills --skill cleanup
```

### Claude Code plugin

```sh
claude plugin marketplace add mkanat/skills
claude plugin install mkanat-skills@mkanat
```

Invoke the installed skill as `/mkanat-skills:cleanup`.

### Codex plugin

```sh
codex plugin marketplace add mkanat/skills
codex plugin add mkanat-skills@mkanat
```

Invoke the installed skill as `$cleanup`.

### Manual installation

Copy `skills/cleanup` into an agent's skills directory. The common cross-agent
location is `~/.agents/skills/cleanup`; project-local locations include
`.agents/skills/cleanup`, `.claude/skills/cleanup`, and
`.github/skills/cleanup`.

## License

To maximize reuse, this repository is dedicated to the public domain under
[CC0 1.0 Universal](LICENSE). You may copy, modify, and distribute it for any
purpose without asking permission.
