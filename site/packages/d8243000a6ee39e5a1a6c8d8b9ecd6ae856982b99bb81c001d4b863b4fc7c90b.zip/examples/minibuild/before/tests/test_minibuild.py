# SPDX-License-Identifier: CC0-1.0
from __future__ import annotations

import sys
from typing import TYPE_CHECKING

import pytest

from minibuild.config import Project, Target
from minibuild.engine import BuildEngine, BuildResult, BuildStatus
from minibuild.graph import GraphError, TargetGraph
from minibuild.state import StateStore, TargetState

if TYPE_CHECKING:
    from pathlib import Path


def test_reports_the_complete_cycle() -> None:
    targets = {
        "a": target("a", deps=("b",)),
        "b": target("b", deps=("c",)),
        "c": target("c", deps=("a",)),
    }

    with pytest.raises(GraphError, match=r"a -> b -> c -> a"):
        TargetGraph(targets)


def test_closure_excludes_unrelated_targets() -> None:
    graph = TargetGraph(
        {
            "library": target("library"),
            "application": target("application", deps=("library",)),
            "docs": target("docs"),
        }
    )

    assert graph.closure(["application"]) == {"library", "application"}


def test_rejects_unknown_dependency() -> None:
    with pytest.raises(GraphError, match="depends on unknown target"):
        TargetGraph({"application": target("application", deps=("library",))})


def test_diamond_graph_visits_shared_dependency_once() -> None:
    graph = TargetGraph(
        {
            "shared": target("shared"),
            "left": target("left", deps=("shared",)),
            "right": target("right", deps=("shared",)),
            "all": target("all", deps=("left", "right")),
            "unrelated": target("unrelated"),
        },
    )

    selected = graph.closure(["all"])

    assert graph.topological(selected) == ["shared", "left", "right", "all"]
    assert graph.dependents(selected) == {
        "shared": {"left", "right"},
        "left": {"all"},
        "right": {"all"},
    }


def test_graph_queries_can_filter_out_dependencies() -> None:
    graph = TargetGraph(
        {
            "library": target("library"),
            "application": target("application", deps=("library",)),
        },
    )

    assert graph.topological({"application"}) == ["application"]
    assert graph.dependents({"application"}) == {}


def test_build_skips_unchanged_targets_and_rebuilds_dependents(tmp_path: Path) -> None:
    source = tmp_path / "source.txt"
    source.write_text("first")
    project = Project(
        tmp_path,
        {
            "compile": target(
                "compile",
                inputs=("source.txt",),
                outputs=("build/compiled.txt",),
                command=write_command("build/compiled.txt", "source.txt"),
            ),
            "package": target(
                "package",
                deps=("compile",),
                outputs=("dist/package.txt",),
                command=write_command("dist/package.txt", "build/compiled.txt"),
            ),
        },
        tmp_path / ".minibuild/state.json",
    )

    first = BuildEngine(project).build(["package"], jobs=2)
    second = BuildEngine(project).build(["package"], jobs=2)
    source.write_text("second")
    third = BuildEngine(project).build(["package"], jobs=2)

    assert statuses(first) == [BuildStatus.BUILT, BuildStatus.BUILT]
    assert statuses(second) == [BuildStatus.SKIPPED, BuildStatus.SKIPPED]
    assert statuses(third) == [BuildStatus.BUILT, BuildStatus.BUILT]
    assert (tmp_path / "dist/package.txt").read_text() == "second"


def test_modified_output_is_rebuilt(tmp_path: Path) -> None:
    project = Project(
        tmp_path,
        {
            "artifact": target(
                "artifact",
                outputs=("artifact.txt",),
                command=literal_write_command("artifact.txt", "generated"),
            )
        },
        tmp_path / ".minibuild/state.json",
    )
    BuildEngine(project).build(["artifact"])
    (tmp_path / "artifact.txt").write_text("tampered")

    result = BuildEngine(project).build(["artifact"])[0]

    assert result.status == BuildStatus.BUILT
    assert "was modified" in result.reason
    assert (tmp_path / "artifact.txt").read_text() == "generated"


def test_missing_previous_output_is_rebuilt(tmp_path: Path) -> None:
    project = Project(
        tmp_path,
        {
            "artifact": target(
                "artifact",
                outputs=("artifact.txt",),
                command=literal_write_command("artifact.txt", "generated"),
            ),
        },
        tmp_path / ".minibuild/state.json",
    )
    BuildEngine(project).build(["artifact"])
    (tmp_path / "artifact.txt").unlink()

    result = BuildEngine(project).build(["artifact"])[0]

    assert result.status == BuildStatus.BUILT
    assert result.reason == "output artifact.txt is missing"


def test_explain_handles_dependency_without_saved_state(tmp_path: Path) -> None:
    project = Project(
        tmp_path,
        {
            "library": target("library"),
            "application": target("application", deps=("library",)),
        },
        tmp_path / ".minibuild/state.json",
    )

    results = BuildEngine(project).explain(["application"])

    assert statuses(results) == [BuildStatus.BUILT, BuildStatus.BUILT]
    assert all(result.reason == "no previous successful build" for result in results)


def test_fails_when_command_does_not_create_declared_output(tmp_path: Path) -> None:
    project = Project(
        tmp_path,
        {
            "artifact": target(
                "artifact",
                outputs=("missing.txt",),
                command=(sys.executable, "-c", "print('ran without writing')"),
            ),
        },
        tmp_path / ".minibuild/state.json",
    )

    result = BuildEngine(project).build(["artifact"])[0]

    assert result.status == BuildStatus.FAILED
    assert result.reason == "command did not create: missing.txt"
    assert result.output == "ran without writing\n"


def test_failure_blocks_dependent_but_not_independent_target(tmp_path: Path) -> None:
    project = Project(
        tmp_path,
        {
            "failure": target(
                "failure", command=(sys.executable, "-c", "raise SystemExit(3)")
            ),
            "blocked": target("blocked", deps=("failure",)),
            "independent": target(
                "independent",
                outputs=("independent.txt",),
                command=literal_write_command("independent.txt", "ok"),
            ),
            "all": target("all", deps=("blocked", "independent")),
        },
        tmp_path / ".minibuild/state.json",
    )

    results = BuildEngine(project).build(["all"], jobs=3)
    by_name = {result.target: result for result in results}

    assert by_name["failure"].status == BuildStatus.FAILED
    assert by_name["blocked"].status == BuildStatus.BLOCKED
    assert by_name["independent"].status == BuildStatus.BUILT
    assert by_name["all"].status == BuildStatus.BLOCKED


def test_clean_removes_outputs_and_state(tmp_path: Path) -> None:
    project = Project(
        tmp_path,
        {
            "artifact": target(
                "artifact",
                outputs=("build/artifact.txt",),
                command=literal_write_command("build/artifact.txt", "value"),
            )
        },
        tmp_path / ".minibuild/state.json",
    )
    engine = BuildEngine(project)
    engine.build(["artifact"])

    removed = engine.clean()

    assert removed == [tmp_path / "build/artifact.txt"]
    assert not project.state_file.exists()


def test_selective_clean_removes_directory_and_preserves_other_state(
    tmp_path: Path,
) -> None:
    output_directory = tmp_path / "generated"
    output_directory.mkdir()
    (output_directory / "nested.txt").write_text("value")
    project = Project(
        tmp_path,
        {
            "directory": target("directory", outputs=("generated",)),
            "other": target("other"),
        },
        tmp_path / ".minibuild/state.json",
    )
    engine = BuildEngine(project)
    engine.state.put("directory", TargetState("one", {}))
    engine.state.put("other", TargetState("two", {}))

    removed = engine.clean(["directory"])

    reloaded = StateStore(project.state_file)
    reloaded.load()
    assert removed == [output_directory]
    assert not output_directory.exists()
    assert reloaded.get("directory") is None
    assert reloaded.get("other") == TargetState("two", {})

    assert engine.clean(["directory"]) == []


@pytest.mark.parametrize(
    "content",
    [
        "not json",
        "[]",
        '{"targets": []}',
        '{"targets": {"bad": 3}}',
        '{"targets": {"bad": {"fingerprint": 3, "output_fingerprints": {}}}}',
        '{"targets": {"bad": {"fingerprint": "x", "output_fingerprints": {"x": 3}}}}',
    ],
)
def test_state_store_ignores_invalid_state(tmp_path: Path, content: str) -> None:
    path = tmp_path / "state.json"
    path.write_text(content)
    store = StateStore(path)

    store.load()

    assert store.targets == {}


def test_state_store_ignores_unreadable_state_path(tmp_path: Path) -> None:
    path = tmp_path / "state.json"
    path.mkdir()
    store = StateStore(path)

    store.load()

    assert store.targets == {}


def target(
    name: str,
    *,
    deps: tuple[str, ...] = (),
    inputs: tuple[str, ...] = (),
    outputs: tuple[str, ...] = (),
    command: tuple[str, ...] | None = None,
) -> Target:
    return Target(
        name, deps, inputs, outputs, command or (sys.executable, "-c", "pass")
    )


def write_command(output: str, source: str) -> tuple[str, ...]:
    script = (
        "from pathlib import Path; "
        f"p=Path({output!r}); p.parent.mkdir(parents=True, exist_ok=True); "
        f"p.write_text(Path({source!r}).read_text())"
    )
    return (sys.executable, "-c", script)


def literal_write_command(output: str, content: str) -> tuple[str, ...]:
    script = (
        "from pathlib import Path; "
        f"p=Path({output!r}); p.parent.mkdir(parents=True, exist_ok=True); "
        f"p.write_text({content!r})"
    )
    return (sys.executable, "-c", script)


def statuses(results: list[BuildResult]) -> list[BuildStatus]:
    return [result.status for result in results]
