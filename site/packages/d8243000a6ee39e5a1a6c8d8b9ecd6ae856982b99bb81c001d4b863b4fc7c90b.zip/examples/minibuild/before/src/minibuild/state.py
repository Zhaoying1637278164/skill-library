# SPDX-License-Identifier: CC0-1.0
"""Persist successful target fingerprints between builds."""

from __future__ import annotations

import contextlib
import json
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from pathlib import Path


@dataclass(frozen=True)
class TargetState:
    """Record a successful target fingerprint and its generated outputs."""

    fingerprint: str
    output_fingerprints: dict[str, str]


class StateStore:
    """Read and atomically write minibuild's persistent state."""

    def __init__(self, path: Path) -> None:
        """Create a state store at the given path."""
        self.path = path
        self.targets: dict[str, TargetState] = {}

    def load(self) -> None:
        """Load valid state entries, tolerating absent or corrupt state."""
        try:
            raw = cast("object", json.loads(self.path.read_text()))
        except FileNotFoundError:
            return
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            return
        if not isinstance(raw, dict):
            return
        raw_document = cast("dict[str, object]", raw)
        raw_targets_value = raw_document.get("targets", {})
        if not isinstance(raw_targets_value, dict):
            return
        raw_targets = cast("dict[str, object]", raw_targets_value)
        for name, value_object in raw_targets.items():
            if not isinstance(value_object, dict):
                continue
            value = cast("dict[str, object]", value_object)
            fingerprint = value.get("fingerprint")
            outputs = value.get("output_fingerprints")
            if isinstance(fingerprint, str) and isinstance(outputs, dict):
                output_values = cast("dict[object, object]", outputs)
                if all(
                    isinstance(key, str) and isinstance(item, str)
                    for key, item in output_values.items()
                ):
                    typed_outputs = {
                        cast("str", key): cast("str", item)
                        for key, item in output_values.items()
                    }
                    self.targets[name] = TargetState(fingerprint, typed_outputs)

    def save(self) -> None:
        """Atomically save the current target states."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "targets": {
                name: asdict(state) for name, state in sorted(self.targets.items())
            },
        }
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        temporary.replace(self.path)

    def get(self, name: str) -> TargetState | None:
        """Return saved state for a target, if any."""
        return self.targets.get(name)

    def put(self, name: str, state: TargetState) -> None:
        """Set the successful state for a target."""
        self.targets[name] = state

    def remove(self, name: str) -> None:
        """Forget any saved state for a target."""
        self.targets.pop(name, None)

    def clear(self) -> None:
        """Forget all state and remove the persisted state file."""
        self.targets.clear()
        with contextlib.suppress(FileNotFoundError):
            self.path.unlink()
