# SPDX-License-Identifier: CC0-1.0
"""Schedule incremental target builds and maintain their state."""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

from .graph import TargetGraph
from .state import StateStore, TargetState

if TYPE_CHECKING:
    from pathlib import Path

    from .config import Project, Target


class BuildStatus(StrEnum):
    """Describe the outcome of processing a target."""

    BUILT = "built"
    SKIPPED = "skipped"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass(frozen=True)
class BuildResult:
    """Describe one target's build outcome and diagnostic output."""

    target: str
    status: BuildStatus
    reason: str
    output: str = ""


@dataclass(frozen=True)
class BuildDecision:
    """Record whether and why a target needs rebuilding."""

    rebuild: bool
    reason: str
    fingerprint: str


class BuildEngine:
    """Build requested targets with dependency-aware concurrency."""

    def __init__(self, project: Project) -> None:
        """Initialize an engine and load its project's saved state."""
        self.project = project
        self.graph = TargetGraph(project.targets)
        self.state = StateStore(project.state_file)
        self.state.load()

    def build(self, requested: list[str], jobs: int | None = None) -> list[BuildResult]:
        """Build requested targets and dependencies with up to `jobs` workers."""
        selected = self.graph.closure(requested)
        dependents = self.graph.dependents(selected)
        remaining_dependencies = {
            name: {
                dep
                for dep in self.project.targets[name].dependencies
                if dep in selected
            }
            for name in selected
        }
        results: dict[str, BuildResult] = {}
        running: dict[Future[BuildResult], str] = {}
        ready = sorted(
            name for name, deps in remaining_dependencies.items() if not deps
        )
        worker_count = jobs or max(1, os.cpu_count() or 1)

        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            while ready or running:
                while ready and len(running) < worker_count:
                    name = ready.pop(0)
                    dependency_results = [
                        results[dep] for dep in self.project.targets[name].dependencies
                    ]
                    bad_dependencies = [
                        result.target
                        for result in dependency_results
                        if result.status in (BuildStatus.FAILED, BuildStatus.BLOCKED)
                    ]
                    if bad_dependencies:
                        results[name] = BuildResult(
                            name,
                            BuildStatus.BLOCKED,
                            "blocked by " + ", ".join(sorted(bad_dependencies)),
                        )
                        self._release(
                            name, dependents, remaining_dependencies, ready, results
                        )
                        continue
                    future = executor.submit(
                        self._build_one, self.project.targets[name]
                    )
                    running[future] = name

                if not running:
                    continue
                completed, _ = wait(running, return_when=FIRST_COMPLETED)
                for future in completed:
                    name = running.pop(future)
                    results[name] = future.result()
                    self._release(
                        name, dependents, remaining_dependencies, ready, results
                    )

        self.state.save()
        order = self.graph.topological(selected)
        return [results[name] for name in order]

    def explain(self, requested: list[str]) -> list[BuildResult]:
        """Explain current rebuild decisions without running commands."""
        selected = self.graph.closure(requested)
        results: list[BuildResult] = []
        for name in self.graph.topological(selected):
            decision = self._decision(self.project.targets[name])
            status = BuildStatus.BUILT if decision.rebuild else BuildStatus.SKIPPED
            results.append(BuildResult(name, status, decision.reason))
        return results

    def clean(self, requested: list[str] | None = None) -> list[Path]:
        """Remove outputs and state for selected targets or the whole project."""
        names = (
            self.graph.closure(requested) if requested else set(self.project.targets)
        )
        removed: list[Path] = []
        for name in names:
            target = self.project.targets[name]
            for output in target.output_files(self.project.root):
                if output.is_dir():
                    shutil.rmtree(output)
                    removed.append(output)
                elif output.exists():
                    output.unlink()
                    removed.append(output)
            self.state.remove(name)
        if requested:
            self.state.save()
        else:
            self.state.clear()
        return sorted(removed)

    def _build_one(self, target: Target) -> BuildResult:
        decision = self._decision(target)
        if not decision.rebuild:
            return BuildResult(target.name, BuildStatus.SKIPPED, decision.reason)

        for output in target.output_files(self.project.root):
            output.parent.mkdir(parents=True, exist_ok=True)
        # Commands are the explicit purpose of a trusted minibuild project file.
        process = subprocess.run(  # noqa: S603
            target.command,
            cwd=self.project.root,
            capture_output=True,
            text=True,
            check=False,
        )
        combined_output = process.stdout + process.stderr
        if process.returncode:
            self.state.remove(target.name)
            return BuildResult(
                target.name,
                BuildStatus.FAILED,
                f"command exited with status {process.returncode}",
                combined_output,
            )

        missing = [
            str(path.relative_to(self.project.root))
            for path in target.output_files(self.project.root)
            if not path.exists()
        ]
        if missing:
            self.state.remove(target.name)
            return BuildResult(
                target.name,
                BuildStatus.FAILED,
                "command did not create: " + ", ".join(missing),
                combined_output,
            )

        output_fingerprints = {
            str(path.relative_to(self.project.root)): _hash_file(path)
            for path in target.output_files(self.project.root)
        }
        self.state.put(
            target.name, TargetState(decision.fingerprint, output_fingerprints)
        )
        return BuildResult(
            target.name, BuildStatus.BUILT, decision.reason, combined_output
        )

    def _decision(self, target: Target) -> BuildDecision:
        previous = self.state.get(target.name)
        fingerprint = self._fingerprint(target)
        if previous is None:
            return BuildDecision(
                rebuild=True,
                reason="no previous successful build",
                fingerprint=fingerprint,
            )

        for output in target.output_files(self.project.root):
            relative = str(output.relative_to(self.project.root))
            if not output.exists():
                return BuildDecision(
                    rebuild=True,
                    reason=f"output {relative} is missing",
                    fingerprint=fingerprint,
                )
            if previous.output_fingerprints.get(relative) != _hash_file(output):
                return BuildDecision(
                    rebuild=True,
                    reason=f"output {relative} was modified",
                    fingerprint=fingerprint,
                )

        if previous.fingerprint != fingerprint:
            return BuildDecision(
                rebuild=True,
                reason="inputs, command, or dependencies changed",
                fingerprint=fingerprint,
            )
        return BuildDecision(
            rebuild=False,
            reason="inputs and outputs are unchanged",
            fingerprint=fingerprint,
        )

    def _fingerprint(self, target: Target) -> str:
        digest = hashlib.sha256()
        digest.update(b"minibuild-target-v1\0")
        for argument in target.command:
            digest.update(argument.encode())
            digest.update(b"\0")
        for path in target.input_files(self.project.root):
            digest.update(str(path.relative_to(self.project.root)).encode())
            digest.update(b"\0")
            digest.update(_hash_file(path).encode())
            digest.update(b"\0")
        for dependency in target.dependencies:
            dependency_state = self.state.get(dependency)
            digest.update(dependency.encode())
            digest.update(b"\0")
            if dependency_state:
                digest.update(dependency_state.fingerprint.encode())
                for path, fingerprint in sorted(
                    dependency_state.output_fingerprints.items()
                ):
                    digest.update(path.encode())
                    digest.update(fingerprint.encode())
            digest.update(b"\0")
        return digest.hexdigest()

    @staticmethod
    def _release(
        completed: str,
        dependents: dict[str, set[str]],
        remaining: dict[str, set[str]],
        ready: list[str],
        results: dict[str, BuildResult],
    ) -> None:
        for dependent in dependents.get(completed, set()):
            remaining[dependent].discard(completed)
            if (
                not remaining[dependent]
                and dependent not in results
                and dependent not in ready
            ):
                ready.append(dependent)
        ready.sort()


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()
