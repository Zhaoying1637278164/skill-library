# SPDX-License-Identifier: CC0-1.0
"""Validate and query target dependency graphs."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable

    from .config import Target


class GraphError(ValueError):
    """Report an invalid target graph or target request."""


@dataclass(frozen=True)
class TargetGraph:
    """Provide validated dependency-graph operations."""

    targets: dict[str, Target]

    def __post_init__(self) -> None:
        """Validate references and reject cycles after initialization."""
        for target in self.targets.values():
            for dependency in target.dependencies:
                if dependency not in self.targets:
                    msg = (
                        f"target {target.name!r} depends on unknown target "
                        f"{dependency!r}"
                    )
                    raise GraphError(msg)
        self._check_cycles()

    def closure(self, requested: Iterable[str]) -> set[str]:
        """Return requested targets and all their transitive dependencies."""
        selected: set[str] = set()

        def visit(name: str) -> None:
            if name not in self.targets:
                msg = f"unknown target: {name}"
                raise GraphError(msg)
            if name in selected:
                return
            selected.add(name)
            for dependency in self.targets[name].dependencies:
                visit(dependency)

        for name in requested:
            visit(name)
        return selected

    def topological(self, selected: set[str] | None = None) -> list[str]:
        """Return selected targets in dependency-first order."""
        selected = selected or set(self.targets)
        visited: set[str] = set()
        ordered: list[str] = []

        def visit(name: str) -> None:
            if name in visited:
                return
            visited.add(name)
            for dependency in self.targets[name].dependencies:
                if dependency in selected:
                    visit(dependency)
            ordered.append(name)

        for name in self.targets:
            if name in selected:
                visit(name)
        return ordered

    def dependents(self, selected: set[str] | None = None) -> dict[str, set[str]]:
        """Index each selected target by its immediate dependents."""
        selected = selected or set(self.targets)
        result: dict[str, set[str]] = defaultdict(set)
        for name in selected:
            for dependency in self.targets[name].dependencies:
                if dependency in selected:
                    result[dependency].add(name)
        return dict(result)

    def _check_cycles(self) -> None:
        visiting: list[str] = []
        visited: set[str] = set()

        def visit(name: str) -> None:
            if name in visiting:
                start = visiting.index(name)
                cycle = [*visiting[start:], name]
                raise GraphError("dependency cycle: " + " -> ".join(cycle))
            if name in visited:
                return
            visiting.append(name)
            for dependency in self.targets[name].dependencies:
                visit(dependency)
            visiting.pop()
            visited.add(name)

        for name in self.targets:
            visit(name)
