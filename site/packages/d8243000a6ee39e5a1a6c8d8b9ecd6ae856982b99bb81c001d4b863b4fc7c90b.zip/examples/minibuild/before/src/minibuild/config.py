# SPDX-License-Identifier: CC0-1.0
"""Load and validate minibuild project configuration."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from pathlib import Path


class ConfigError(ValueError):
    """Report invalid project configuration."""


@dataclass(frozen=True)
class Target:
    """Describe one executable build target."""

    name: str
    dependencies: tuple[str, ...]
    inputs: tuple[str, ...]
    outputs: tuple[str, ...]
    command: tuple[str, ...]
    description: str = ""

    def input_files(self, root: Path) -> tuple[Path, ...]:
        """Expand this target's input globs beneath the project root."""
        files: list[Path] = []
        for pattern in self.inputs:
            matches = root.glob(pattern)
            files.extend(match for match in matches if match.is_file())
        return tuple(sorted(set(files)))

    def output_files(self, root: Path) -> tuple[Path, ...]:
        """Resolve this target's declared outputs beneath the project root."""
        return tuple(root / output for output in self.outputs)


@dataclass(frozen=True)
class Project:
    """Contain a loaded minibuild project and its targets."""

    root: Path
    targets: dict[str, Target]
    state_file: Path


def load_project(config_path: Path) -> Project:
    """Load a project from a TOML configuration file."""
    config_path = config_path.resolve()
    try:
        with config_path.open("rb") as stream:
            document = cast("dict[str, object]", tomllib.load(stream))
    except FileNotFoundError as error:
        msg = f"configuration not found: {config_path}"
        raise ConfigError(msg) from error
    except tomllib.TOMLDecodeError as error:
        msg = f"invalid TOML in {config_path}: {error}"
        raise ConfigError(msg) from error

    raw_targets_value = document.get("targets")
    if not isinstance(raw_targets_value, dict) or not raw_targets_value:
        msg = "configuration must define at least one [targets.<name>] table"
        raise ConfigError(msg)
    raw_targets = cast("dict[str, object]", raw_targets_value)

    project_options_value = document.get("project", {})
    if not isinstance(project_options_value, dict):
        msg = "[project] must be a table"
        raise ConfigError(msg)
    project_options = cast("dict[str, object]", project_options_value)
    state_name = project_options.get("state_file", ".minibuild/state.json")
    if not isinstance(state_name, str) or not state_name:
        msg = "project.state_file must be a non-empty string"
        raise ConfigError(msg)

    targets: dict[str, Target] = {}
    for name, raw_target_value in raw_targets.items():
        if not isinstance(raw_target_value, dict):
            msg = f"target {name!r} must be a table"
            raise ConfigError(msg)
        raw_target = cast("dict[str, object]", raw_target_value)
        targets[name] = Target(
            name=name,
            dependencies=_string_list(raw_target, "deps", name),
            inputs=_string_list(raw_target, "inputs", name),
            outputs=_string_list(raw_target, "outputs", name),
            command=_required_string_list(raw_target, "command", name),
            description=_optional_string(raw_target, "description", name),
        )

    root = config_path.parent
    return Project(root=root, targets=targets, state_file=root / state_name)


def _string_list(raw: dict[str, object], key: str, target: str) -> tuple[str, ...]:
    value = raw.get(key, [])
    if not isinstance(value, list):
        msg = f"targets.{target}.{key} must be an array of strings"
        raise ConfigError(msg)
    items = cast("list[object]", value)
    if any(not isinstance(item, str) for item in items):
        msg = f"targets.{target}.{key} must be an array of strings"
        raise ConfigError(msg)
    return tuple(cast("str", item) for item in items)


def _required_string_list(
    raw: dict[str, object], key: str, target: str
) -> tuple[str, ...]:
    value = _string_list(raw, key, target)
    if not value:
        msg = f"targets.{target}.{key} must not be empty"
        raise ConfigError(msg)
    return value


def _optional_string(raw: dict[str, object], key: str, target: str) -> str:
    value = raw.get(key, "")
    if not isinstance(value, str):
        msg = f"targets.{target}.{key} must be a string"
        raise ConfigError(msg)
    return value
