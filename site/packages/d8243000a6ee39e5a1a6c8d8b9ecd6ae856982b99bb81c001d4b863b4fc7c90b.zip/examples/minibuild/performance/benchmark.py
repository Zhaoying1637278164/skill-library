# SPDX-License-Identifier: CC0-1.0
"""Benchmark the before and after minibuild implementations."""

from __future__ import annotations

import argparse
import json
import os
import shlex
import statistics
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import cast

REPOSITORY = Path(__file__).resolve().parents[3]
EXAMPLES = REPOSITORY / "examples/minibuild"
IMPLEMENTATIONS = ("before", "after")


@dataclass(frozen=True)
class Measurement:
    """Hold median wall time and peak resident memory for one implementation."""

    seconds: float
    rss_kib: float


def parse_args() -> argparse.Namespace:
    """Parse benchmark settings."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--targets", type=int, default=10_000)
    parser.add_argument("--warmup", type=int, default=3)
    parser.add_argument("--runs", type=int, default=30)
    parser.add_argument("--rss-runs", type=int, default=12)
    return parser.parse_args()


def write_project(root: Path, target_count: int) -> Path:
    """Write a wide graph with one aggregate target."""
    root.mkdir()
    lines = ["[project]", 'state_file = ".minibuild/state.json"', ""]
    dependencies: list[str] = []
    for index in range(target_count):
        name = f"leaf_{index:04d}"
        output = f"build/{name}"
        dependencies.append(f'"{name}"')
        lines.extend(
            (
                f"[targets.{name}]",
                f'outputs = ["{output}"]',
                f'command = ["/usr/bin/touch", "{output}"]',
                "",
            )
        )
    lines.extend(
        (
            "[targets.all]",
            "deps = [" + ", ".join(dependencies) + "]",
            'command = ["/usr/bin/true"]',
            "",
        )
    )
    config = root / "minibuild.toml"
    config.write_text("\n".join(lines))
    return config


def command(config: Path, action: str) -> list[str]:
    """Build a minibuild command for one workload."""
    arguments = [
        sys.executable,
        "-m",
        "minibuild",
        "--config",
        str(config),
        action,
    ]
    if action != "graph":
        arguments.append("all")
    if action == "build":
        arguments.extend(("--jobs", "8"))
    return arguments


def environment(implementation: str) -> dict[str, str]:
    """Select one implementation without installing it."""
    result = os.environ.copy()
    result["PYTHONPATH"] = str(EXAMPLES / implementation / "src")
    return result


def initialize_state(configs: dict[str, Path]) -> None:
    """Perform the initial build required by the incremental workload."""
    for implementation in IMPLEMENTATIONS:
        subprocess.run(
            command(configs[implementation], "build"),
            env=environment(implementation),
            stdout=subprocess.DEVNULL,
            check=True,
        )


def shell_command(implementation: str, config: Path, action: str) -> str:
    """Render a command string for Hyperfine's shell."""
    source = EXAMPLES / implementation / "src"
    arguments = command(config, action)
    return f"PYTHONPATH={shlex.quote(str(source))} {shlex.join(arguments)} > /dev/null"


def timing_samples(
    directory: Path,
    configs: dict[str, Path],
    action: str,
    warmup: int,
    runs: int,
) -> dict[str, list[float]]:
    """Measure both implementations in balanced Hyperfine order."""
    samples: dict[str, list[float]] = {
        implementation: [] for implementation in IMPLEMENTATIONS
    }
    pass_runs = (runs // 2, runs - runs // 2) if runs > 1 else (1,)
    for pass_index, run_count in enumerate(pass_runs):
        output = directory / f"{action}-timing-{pass_index}.json"
        invocation = [
            "hyperfine",
            "--warmup",
            str(warmup),
            "--runs",
            str(run_count),
            "--export-json",
            str(output),
        ]
        order = (
            IMPLEMENTATIONS if pass_index % 2 == 0 else tuple(reversed(IMPLEMENTATIONS))
        )
        for implementation in order:
            invocation.extend(
                (
                    "--command-name",
                    implementation,
                    shell_command(implementation, configs[implementation], action),
                )
            )
        subprocess.run(invocation, check=True)
        document = cast(
            "dict[str, list[dict[str, object]]]", json.loads(output.read_text())
        )
        for result in document["results"]:
            implementation = cast("str", result["command"])
            times = cast("list[float]", result["times"])
            samples[implementation].extend(times)
    return samples


def rss_samples(
    directory: Path,
    configs: dict[str, Path],
    action: str,
    runs: int,
) -> dict[str, list[int]]:
    """Measure per-process peak RSS with GNU time, alternating order."""
    samples: dict[str, list[int]] = {
        implementation: [] for implementation in IMPLEMENTATIONS
    }
    output = directory / "peak-rss.txt"
    for run in range(runs):
        order = IMPLEMENTATIONS if run % 2 == 0 else tuple(reversed(IMPLEMENTATIONS))
        for implementation in order:
            subprocess.run(
                [
                    "/usr/bin/time",
                    "-f",
                    "%M",
                    "-o",
                    str(output),
                    *command(configs[implementation], action),
                ],
                env=environment(implementation),
                stdout=subprocess.DEVNULL,
                check=True,
            )
            samples[implementation].append(int(output.read_text().strip()))
    return samples


def measure(
    directory: Path,
    configs: dict[str, Path],
    action: str,
    warmup: int,
    runs: int,
    rss_runs: int,
) -> dict[str, Measurement]:
    """Measure one workload and summarize its medians."""
    timings = timing_samples(directory, configs, action, warmup, runs)
    memory = rss_samples(directory, configs, action, rss_runs)
    return {
        implementation: Measurement(
            statistics.median(timings[implementation]),
            statistics.median(memory[implementation]),
        )
        for implementation in IMPLEMENTATIONS
    }


def print_table(results: dict[str, dict[str, Measurement]]) -> None:
    """Print a Markdown comparison table."""
    print(
        "| Workload | Before time | After time | Speedup | "
        "Before peak RSS | After peak RSS | RSS reduction |"
    )
    print("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    labels = {"graph": "Graph", "explain": "Explain", "build": "Incremental build"}
    for action, measurements in results.items():
        before = measurements["before"]
        after = measurements["after"]
        speedup = before.seconds / after.seconds
        reduction = (before.rss_kib - after.rss_kib) / before.rss_kib
        print(
            f"| {labels[action]} | {before.seconds * 1_000:.1f} ms | "
            f"{after.seconds * 1_000:.1f} ms | {speedup:.2f}× | "
            f"{before.rss_kib / 1_024:.1f} MiB | {after.rss_kib / 1_024:.1f} MiB | "
            f"{reduction:.1%} |"
        )


def main() -> None:
    """Generate projects, run workloads, and print their comparison table."""
    settings = parse_args()
    with tempfile.TemporaryDirectory(prefix="minibuild-performance-") as temporary:
        directory = Path(temporary)
        configs = {
            implementation: write_project(directory / implementation, settings.targets)
            for implementation in IMPLEMENTATIONS
        }
        initialize_state(configs)
        results = {
            action: measure(
                directory,
                configs,
                action,
                settings.warmup,
                settings.runs,
                settings.rss_runs,
            )
            for action in ("graph", "explain", "build")
        }
        print_table(results)


if __name__ == "__main__":
    main()
