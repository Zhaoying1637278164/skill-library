# minibuild performance report

This report compares the original [`before`](../before/) implementation of
`minibuild` with the cleaned-up [`after`](../after/) implementation. Both
versions perform the same work and pass the same correctness, typing, linting,
formatting, and coverage checks.

The cleanup did more than reduce the amount of code. It removed repeated work,
stopped retaining multiple representations of the same information, and made
incremental scheduling substantially more efficient.

## Results

Lower wall time and peak resident set size (RSS) are better. Each value is the
median of repeated measurements.

| Workload          | Before time | After time | Time reduction | Speedup | Before peak RSS | After peak RSS | RSS reduction |
| ----------------- | ----------: | ---------: | -------------: | ------: | --------------: | -------------: | ------------: |
| Graph             |    174.6 ms |   167.4 ms |           4.1% |   1.04× |        55.7 MiB |       55.2 MiB |          0.9% |
| Explain           |    290.0 ms |   283.2 ms |           2.3% |   1.02× |        55.7 MiB |       55.4 MiB |          0.6% |
| Incremental build |    705.5 ms |   527.1 ms |          25.3% |   1.34× |        57.5 MiB |       56.7 MiB |          1.4% |

The most important result is the fully incremental build. This is the common
case where a project has already been built and nothing has changed. The
cleaned-up implementation completes that work 1.34× as fast, reducing median
wall time by 178.4 ms, or 25.3%.

Graph rendering and rebuild explanations spend more of their time starting
Python, parsing TOML, and producing output, so the cleanup affects a smaller
fraction of their total runtime. They nevertheless improve without a regression
in peak memory.

Peak RSS falls in every workload. The reductions are modest because both
programs still load the same 10,001-target configuration and run in the same
Python interpreter. The largest measured reduction is 0.8 MiB during the
incremental build.

## Workload

The checked-in [`benchmark.py`](benchmark.py) harness generates a wide build
graph with 10,000 independent leaf targets and one aggregate target that depends
on every leaf. This shape is large enough to make graph, state, and scheduling
costs measurable without introducing a long dependency chain that would test
Python's recursion limit instead.

Every leaf:

- declares a distinct output;
- creates that output with `/usr/bin/touch`; and
- has a successful saved state before measurements begin.

The aggregate target therefore selects all 10,001 targets. The real output files
and saved fingerprints exercise configuration parsing, state loading, output
verification, dependency relationships, and scheduler bookkeeping. Command
output is discarded so terminal rendering does not affect measurements.

The harness measures three operations:

- **Graph:** load and validate the project, then render the complete dependency
  graph.
- **Explain:** inspect the aggregate target's full dependency closure and report
  whether each target needs rebuilding.
- **Incremental build:** schedule the full closure with eight workers when every
  output is already current, so no build command needs to run.

## Methodology

Wall-clock measurements use Hyperfine 1.20.0. For each workload and
implementation, the harness performs three warm-ups and records 30 measurements.
It splits those measurements across two Hyperfine passes with reversed command
order, reducing bias from always measuring one implementation first.

Peak RSS is measured separately with GNU `time` 1.9. The report uses the median
of 12 runs per implementation and workload. The harness alternates
implementation order for those runs.

Each implementation receives its own temporary project, outputs, and state file.
Both projects are generated from the same parameters. The harness invokes the
source trees directly through `PYTHONPATH`, avoiding editable installs or
differences in packaging. Temporary data is removed after the run.

These results were recorded on August 24, 2026, using:

- AMD Ryzen 9 9950X, 16 cores and 32 logical CPUs;
- Linux 7.1.8-200.fc44.x86_64; and
- Python 3.14.7.

## Reproducing the results

The benchmark requires Python 3.11 or later, Hyperfine, and GNU `time`. From the
repository root, run:

```sh
python examples/minibuild/performance/benchmark.py
```

The command prints a Markdown results table after completing all measurements.
Use `--help` to see the adjustable target count, warm-up count, timing runs, and
RSS runs. For example, a shorter smoke test is:

```sh
python examples/minibuild/performance/benchmark.py \
  --targets 100 --warmup 1 --runs 4 --rss-runs 2
```

## Interpreting the numbers

This benchmark isolates minibuild's own overhead; it is not intended to model
the runtime of compilers or other expensive build commands. When build commands
dominate total runtime, minibuild's relative contribution will be smaller.

Results will vary with the Python version, processor, operating system, system
load, and filesystem cache. The balanced ordering, warm-ups, repeated samples,
and medians reduce noise, but measurements from another machine should not be
expected to reproduce the exact values above. The checked-in harness exists so
the comparison—not merely these particular numbers—can be reproduced.
