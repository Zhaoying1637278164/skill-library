# What the cleanup skill changed in minibuild

`minibuild` is a small program that decides which jobs need to run when files in
a project change. A job is called a **target**. Targets can depend on other
targets, so minibuild must run them in the right order. After a successful run,
it saves hashes—short summaries called **fingerprints**—so that the next run can
skip work whose inputs and outputs have not changed.

The [`before`](before/) version was already working, fully tested, strictly type
checked, and linted. The repository's [`cleanup`](../../skills/cleanup/SKILL.md)
skill repeatedly inspected it for duplicated information, repeated work, and
unnecessary defensive code. The [`after`](after/) version preserves the same
quality checks and 100% statement and branch coverage.

## What improved

### Minibuild keeps less duplicate information

- A target's name used to be stored both as its lookup key and inside the target
  itself; now the lookup key is the single source of truth.

  ```diff
   class Target:
  -    name: str
       dependencies: tuple[str, ...]
  ```

- Descriptions were read, checked, and stored even though minibuild never
  displayed or used them; that unused feature was removed.

  ```diff
   class Target:
  -    description: str = ""
  ```

- Saved state repeated every output filename even though each target already
  declared its outputs; fingerprints now follow that existing order instead.

  ```diff
  -output_fingerprints: dict[str, str]
  +output_fingerprints: tuple[str, ...]
  ```

- The saved-state file had an outer `targets` layer and a version number that
  conveyed no useful information; both were removed.

  ```diff
  -payload = {"version": 1, "targets": target_states}
  +payload = target_states
  ```

- Running jobs were stored in a table that repeated each job's name, even though
  the completed result already contains it; only the running jobs themselves are
  stored now.

  ```diff
  -running: dict[Future[BuildResult], str] = {}
  +running: set[Future[BuildResult]] = set()
  ```

### Minibuild repeats less work

- Output filenames were converted to paths several times during one decision;
  they are now resolved once and reused.

  ```diff
  -for output in target.output_files(self.project.root):
  +outputs = target.output_files(self.project.root)
  +for output in outputs:
  ```

- Saved-state entries were sorted once by minibuild and then sorted again by the
  JSON writer; only the JSON writer sorts them now.

  ```diff
  -for name, state in sorted(self.targets.items())
  +for name, state in self.targets.items()
  ```

- Graph validation and graph ordering used to walk the same relationships
  separately; one walk now checks references, detects cycles, and records the
  order.

  ```diff
  -self._check_cycles()
  +object.__setattr__(self, "_order", self._validated_order())
  ```

- The recorded graph order used to be recomputed or copied before later
  operations; minibuild now reuses the validated immutable order directly.

  ```diff
  -return list(self._order)
  +return self._order
  ```

- A build created an intermediate list of dependency results only to recover
  names it already had; it now reads the needed results by name.

  ```diff
  -dependency_results = [results[name] for name in target.dependencies]
  -bad_dependencies = [result.target for result in dependency_results if failed(result)]
  +bad_dependencies = [name for name in target.dependencies if failed(results[name])]
  ```

- Blocked dependency names were sorted even though their declared order was
  already stable; minibuild now uses that order directly.

  ```diff
  -", ".join(sorted(bad_dependencies))
  +", ".join(bad_dependencies)
  ```

- Input-file matches were first collected with duplicates and deduplicated
  afterward; they now enter a set as they are discovered.

  ```diff
  -files: list[Path] = []
  -return tuple(sorted(set(files)))
  +files: set[Path] = set()
  +return tuple(sorted(files))
  ```

- A full clean removed saved jobs one by one and then cleared the entire state
  anyway; it now performs only the clear.

### Minibuild relies on facts it has already established

- Once minibuild has selected a target and all of its prerequisites, it no
  longer checks every relationship again to confirm that those prerequisites
  were selected.
- Once the graph has been proven valid and cycle-free, the scheduler no longer
  guards against queue states that cannot occur.
- Unknown names supplied by a user are checked once at the request boundary
  rather than during every recursive step.
- State loading catches the errors that file reading and JSON parsing can
  actually produce instead of listing impossible exceptions.

  ```diff
  -except (json.JSONDecodeError, OSError, TypeError, ValueError):
  +except (json.JSONDecodeError, OSError):
  ```

- Unused graph-query modes and fallbacks that no real command called were
  removed, along with tests that existed only for them.

### The scheduler does less bookkeeping

- The scheduler's “job finished” logic is now local to the build operation,
  where it can directly use the surrounding queue and dependency information
  instead of receiving the same four structures on every call.
- Completing a job with no dependents no longer allocates an empty set or sorts
  an unchanged ready queue.

  ```diff
  -for dependent in dependents.get(completed, set()):
  +for dependent in dependents.get(completed, ()):
  ```

- The scheduler's mutable dependency sets are created directly from the
  already-complete target selection, without filtering the same relationships
  again.
- The reverse lookup from a prerequisite to the jobs waiting for it is built
  directly as a normal dictionary instead of building one dictionary type and
  copying it into another.
- The build's final result uses the graph order computed at the beginning
  instead of traversing the graph again at the end.

### Incremental decisions reflect results, not implementation details

- A target's fingerprint now includes its declared outputs, allowing saved
  output hashes to use a compact ordered representation safely.
- A downstream target now cares about the content produced by its prerequisites,
  not their names or internal commands.

  ```diff
  -digest.update(dependency.encode())
  -digest.update(dependency_state.fingerprint.encode())
   for fingerprint in dependency_state.output_fingerprints:
       digest.update(fingerprint.encode())
  ```

- As a result, changing how a prerequisite works does not force later jobs to
  rerun when the prerequisite still produces exactly the same result.

## Outcome

The cleanup made the program smaller and easier to reason about, but it also
changed measurable behavior: the `after` version was **1.34× faster** on the
checked-in 10,001-target incremental-build benchmark while using less peak
memory. See the full [`performance report`](performance/README.md) for the
workload, methodology, results, and limitations. The complete source change is
available as [`cleanup.diff`](cleanup.diff).
