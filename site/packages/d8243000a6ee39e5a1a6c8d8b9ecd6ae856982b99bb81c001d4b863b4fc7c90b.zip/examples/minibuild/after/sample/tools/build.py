# SPDX-License-Identifier: CC0-1.0
"""Generate artifacts for the sample minibuild project."""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent


def write(path: str, content: str) -> None:
    """Write a generated artifact beneath the sample root."""
    destination = ROOT / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content)


def compile_core() -> None:
    """Compile the core source by converting it to uppercase."""
    write("build/core.upper", (ROOT / "sources/core.txt").read_text().upper())


def bundle() -> None:
    """Combine the compiled core and application-specific source."""
    core = (ROOT / "build/core.upper").read_text()
    application = (ROOT / "sources/app.txt").read_text()
    write("build/application.txt", core + "\n" + application)


def docs() -> None:
    """Render the sample documentation artifact."""
    source = (ROOT / "sources/docs.txt").read_text()
    write(
        "build/docs.txt", "MINIBUILD DOCUMENTATION\n=======================\n" + source
    )


def package() -> None:
    """Create a package manifest containing artifact fingerprints."""
    parts = [ROOT / "build/application.txt", ROOT / "build/docs.txt"]
    lines = ["minibuild sample package", ""]
    for part in parts:
        content = part.read_bytes()
        digest = hashlib.sha256(content).hexdigest()[:12]
        lines.append(f"{part.name}  {len(content):4} bytes  sha256:{digest}")
    write("dist/package.txt", "\n".join(lines) + "\n")


ACTIONS = {
    "compile": compile_core,
    "bundle": bundle,
    "docs": docs,
    "package": package,
}


if __name__ == "__main__":
    try:
        action = ACTIONS[sys.argv[1]]
    except (IndexError, KeyError):
        choices = ", ".join(sorted(ACTIONS))
        msg = f"usage: build.py <{choices}>"
        raise SystemExit(msg) from None
    action()
