# SPDX-License-Identifier: CC0-1.0
from __future__ import annotations

import re
from typing import TYPE_CHECKING

import pytest

from minibuild.config import ConfigError, load_project

if TYPE_CHECKING:
    from pathlib import Path


def test_loads_project_and_expands_recursive_inputs(tmp_path: Path) -> None:
    write_config(
        tmp_path,
        """
        [project]
        state_file = "cache/build-state.json"

        [targets.compile]
        inputs = ["sources/**/*.txt"]
        outputs = ["build/output.txt"]
        command = ["python", "build.py"]
        """,
    )
    (tmp_path / "sources/nested").mkdir(parents=True)
    source = tmp_path / "sources/nested/input.txt"
    source.write_text("input")

    project = load_project(tmp_path / "minibuild.toml")
    target = project.targets["compile"]

    assert project.state_file == tmp_path / "cache/build-state.json"
    assert target.input_files(project.root) == (source,)
    assert target.output_files(project.root) == (tmp_path / "build/output.txt",)


@pytest.mark.parametrize(
    ("document", "message"),
    [
        ("not valid toml =", "invalid TOML"),
        ("[project]\n", "at least one"),
        ("project = 3\n[targets.ok]\ncommand = ['true']", "[project] must be a table"),
        (
            "[project]\nstate_file = 3\n[targets.ok]\ncommand = ['true']",
            "state_file must be a non-empty string",
        ),
        ("targets = { broken = 3 }", "target 'broken' must be a table"),
        ("[targets.ok]\ndeps = 'bad'\ncommand = ['true']", "deps must be an array"),
        ("[targets.ok]\ndeps = [3]\ncommand = ['true']", "deps must be an array"),
        ("[targets.ok]\ncommand = []", "command must not be empty"),
    ],
)
def test_rejects_invalid_configuration(
    tmp_path: Path, document: str, message: str
) -> None:
    write_config(tmp_path, document)

    with pytest.raises(ConfigError, match=re.escape(message)):
        load_project(tmp_path / "minibuild.toml")


def test_reports_missing_configuration(tmp_path: Path) -> None:
    with pytest.raises(ConfigError, match="configuration not found"):
        load_project(tmp_path / "missing.toml")


def write_config(root: Path, document: str) -> Path:
    path = root / "minibuild.toml"
    path.write_text(document)
    return path
