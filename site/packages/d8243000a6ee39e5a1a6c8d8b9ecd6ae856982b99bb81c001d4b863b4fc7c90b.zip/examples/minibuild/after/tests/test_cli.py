# SPDX-License-Identifier: CC0-1.0
from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    import pytest

from minibuild.cli import main


def test_cli_build_explain_graph_and_clean(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    config = write_cli_project(tmp_path)

    assert main(["--config", str(config), "graph"]) == 0
    assert capsys.readouterr().out == "artifact: -\n"

    assert main(["--config", str(config), "build", "artifact", "--jobs", "1"]) == 0
    built = capsys.readouterr().out
    assert "built   artifact: no previous successful build" in built
    assert "command output" in built

    assert main(["--config", str(config), "build", "artifact"]) == 0
    assert (
        "skipped artifact: inputs and outputs are unchanged" in capsys.readouterr().out
    )

    assert main(["--config", str(config), "explain", "artifact"]) == 0
    assert (
        "skip    artifact: inputs and outputs are unchanged" in capsys.readouterr().out
    )

    assert main(["--config", str(config), "clean", "artifact"]) == 0
    assert "removed output.txt" in capsys.readouterr().out
    assert not (tmp_path / "output.txt").exists()


def test_cli_reports_configuration_and_graph_errors(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    missing = tmp_path / "missing.toml"
    assert main(["--config", str(missing), "graph"]) == 2
    assert "configuration not found" in capsys.readouterr().err

    config = write_cli_project(tmp_path)
    assert main(["--config", str(config), "build", "missing"]) == 2
    assert "unknown target" in capsys.readouterr().err

    assert main(["--config", str(config), "build", "artifact", "--jobs", "0"]) == 2
    assert "--jobs must be at least 1" in capsys.readouterr().err


def test_cli_returns_failure_for_a_failed_command(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    config = tmp_path / "minibuild.toml"
    config.write_text(
        f"""
        [targets.failure]
        command = [
            {sys.executable!r},
            "-c",
            "print('failure output'); raise SystemExit(4)",
        ]
        """,
    )

    assert main(["--config", str(config), "build", "failure"]) == 1
    output = capsys.readouterr().out
    assert "failed  failure: command exited with status 4" in output
    assert "failure output" in output


def write_cli_project(root: Path) -> Path:
    config = root / "minibuild.toml"
    script = (
        "from pathlib import Path; "
        "Path('output.txt').write_text('artifact'); "
        "print('command output')"
    )
    config.write_text(
        f"""
        [targets.artifact]
        outputs = ["output.txt"]
        command = [{sys.executable!r}, "-c", {script!r}]
        """,
    )
    return config
