# SPDX-License-Identifier: CC0-1.0
"""Tests for minibuild."""
