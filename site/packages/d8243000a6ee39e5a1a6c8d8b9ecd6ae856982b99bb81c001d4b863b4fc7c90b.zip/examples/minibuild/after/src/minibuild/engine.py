# SPDX-License-Identifier: CC0-1.0
"""Schedule incremental target builds and maintain their state."""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

from .graph import TargetGraph
from .state import StateStore, TargetState

if TYPE_CHECKING:
    from pathlib import Path

    from .config import Project, Target


class BuildStatus(StrEnum):
    """Describe the outcome of processing a target."""

    BUILT = "built"
    SKIPPED = "skipped"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass(frozen=True)
class BuildResult:
    """Describe one target's build outcome and diagnostic output."""

    target: str
    status: BuildStatus
    reason: str
    output: str = ""


@dataclass(frozen=True)
class BuildDecision:
    """Record whether and why a target needs rebuilding."""

    rebuild: bool
    reason: str
    fingerprint: str


class BuildEngine:
    """Build requested targets with dependency-aware concurrency."""

    def __init__(self, project: Project) -> None:
        """Initialize an engine and load its project's saved state."""
        self.project = project
        self.graph = TargetGraph(project.targets)
        self.state = StateStore(project.state_file)
        self.state.load()

    def build(self, requested: list[str], jobs: int | None = None) -> list[BuildResult]:
        """Build requested targets and dependencies with up to `jobs` workers."""
        selected = self.graph.closure(requested)
        order = self.graph.topological(selected)
        dependents = self.graph.dependents(selected)
        remaining_dependencies = {
            name: set(self.project.targets[name].dependencies) for name in selected
        }
        results: dict[str, BuildResult] = {}
        running: set[Future[BuildResult]] = set()
        ready = sorted(
            name for name, deps in remaining_dependencies.items() if not deps
        )
        worker_count = jobs or max(1, os.cpu_count() or 1)

        def release(completed: str) -> None:
            added = False
            for dependent in dependents.get(completed, ()):
                remaining_dependencies[dependent].remove(completed)
                if not remaining_dependencies[dependent]:
                    ready.append(dependent)
                    added = True
            if added:
                ready.sort()

        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            while ready or running:
                while ready and len(running) < worker_count:
                    name = ready.pop(0)
                    bad_dependencies = [
                        dependency
                        for dependency in self.project.targets[name].dependencies
                        if results[dependency].status
                        in (BuildStatus.FAILED, BuildStatus.BLOCKED)
                    ]
                    if bad_dependencies:
                        results[name] = BuildResult(
                            name,
                            BuildStatus.BLOCKED,
                            "blocked by " + ", ".join(bad_dependencies),
                        )
                        release(name)
                        continue
                    future = executor.submit(
                        self._build_one, name, self.project.targets[name]
                    )
                    running.add(future)

                if not running:
                    continue
                completed, running = wait(running, return_when=FIRST_COMPLETED)
                for future in completed:
                    result = future.result()
                    results[result.target] = result
                    release(result.target)

        self.state.save()
        return [results[name] for name in order]

    def explain(self, requested: list[str]) -> list[BuildResult]:
        """Explain current rebuild decisions without running commands."""
        selected = self.graph.closure(requested)
        results: list[BuildResult] = []
        for name in self.graph.topological(selected):
            target = self.project.targets[name]
            decision = self._decision(
                name, target, target.output_files(self.project.root)
            )
            status = BuildStatus.BUILT if decision.rebuild else BuildStatus.SKIPPED
            results.append(BuildResult(name, status, decision.reason))
        return results

    def clean(self, requested: list[str] | None = None) -> list[Path]:
        """Remove outputs and state for selected targets or the whole project."""
        names = self.graph.closure(requested) if requested else self.project.targets
        removed: list[Path] = []
        for name in names:
            target = self.project.targets[name]
            for output in target.output_files(self.project.root):
                if output.is_dir():
                    shutil.rmtree(output)
                    removed.append(output)
                elif output.exists():
                    output.unlink()
                    removed.append(output)
            if requested:
                self.state.remove(name)
        if requested:
            self.state.save()
        else:
            self.state.clear()
        return sorted(removed)

    def _build_one(self, name: str, target: Target) -> BuildResult:
        outputs = target.output_files(self.project.root)
        decision = self._decision(name, target, outputs)
        if not decision.rebuild:
            return BuildResult(name, BuildStatus.SKIPPED, decision.reason)

        for output in outputs:
            output.parent.mkdir(parents=True, exist_ok=True)
        # Commands are the explicit purpose of a trusted minibuild project file.
        process = subprocess.run(  # noqa: S603
            target.command,
            cwd=self.project.root,
            capture_output=True,
            text=True,
            check=False,
        )
        combined_output = process.stdout + process.stderr
        if process.returncode:
            self.state.remove(name)
            return BuildResult(
                name,
                BuildStatus.FAILED,
                f"command exited with status {process.returncode}",
                combined_output,
            )

        missing = [
            str(path.relative_to(self.project.root))
            for path in outputs
            if not path.exists()
        ]
        if missing:
            self.state.remove(name)
            return BuildResult(
                name,
                BuildStatus.FAILED,
                "command did not create: " + ", ".join(missing),
                combined_output,
            )

        output_fingerprints = tuple(_hash_file(path) for path in outputs)
        self.state.put(name, TargetState(decision.fingerprint, output_fingerprints))
        return BuildResult(name, BuildStatus.BUILT, decision.reason, combined_output)

    def _decision(
        self, name: str, target: Target, outputs: tuple[Path, ...]
    ) -> BuildDecision:
        previous = self.state.get(name)
        fingerprint = self._fingerprint(target)
        if previous is None:
            return BuildDecision(
                rebuild=True,
                reason="no previous successful build",
                fingerprint=fingerprint,
            )

        if previous.fingerprint != fingerprint:
            return BuildDecision(
                rebuild=True,
                reason="inputs, command, or dependencies changed",
                fingerprint=fingerprint,
            )

        for output, output_fingerprint in zip(
            outputs, previous.output_fingerprints, strict=True
        ):
            relative = str(output.relative_to(self.project.root))
            if not output.exists():
                return BuildDecision(
                    rebuild=True,
                    reason=f"output {relative} is missing",
                    fingerprint=fingerprint,
                )
            if output_fingerprint != _hash_file(output):
                return BuildDecision(
                    rebuild=True,
                    reason=f"output {relative} was modified",
                    fingerprint=fingerprint,
                )

        return BuildDecision(
            rebuild=False,
            reason="inputs and outputs are unchanged",
            fingerprint=fingerprint,
        )

    def _fingerprint(self, target: Target) -> str:
        digest = hashlib.sha256()
        digest.update(b"minibuild-target-v1\0")
        for output in target.outputs:
            digest.update(output.encode())
            digest.update(b"\0")
        for argument in target.command:
            digest.update(argument.encode())
            digest.update(b"\0")
        for path in target.input_files(self.project.root):
            digest.update(str(path.relative_to(self.project.root)).encode())
            digest.update(b"\0")
            digest.update(_hash_file(path).encode())
            digest.update(b"\0")
        for dependency in target.dependencies:
            dependency_state = self.state.get(dependency)
            if dependency_state:
                for fingerprint in dependency_state.output_fingerprints:
                    digest.update(fingerprint.encode())
        return digest.hexdigest()


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()
