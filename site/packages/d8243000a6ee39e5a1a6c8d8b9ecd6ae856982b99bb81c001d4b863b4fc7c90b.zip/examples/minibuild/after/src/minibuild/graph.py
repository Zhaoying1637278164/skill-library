# SPDX-License-Identifier: CC0-1.0
"""Validate and query target dependency graphs."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable

    from .config import Target


class GraphError(ValueError):
    """Report an invalid target graph or target request."""


@dataclass(frozen=True)
class TargetGraph:
    """Provide validated dependency-graph operations."""

    targets: dict[str, Target]
    _order: tuple[str, ...] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Validate references and reject cycles after initialization."""
        object.__setattr__(self, "_order", self._validated_order())

    def closure(self, requested: Iterable[str]) -> set[str]:
        """Return requested targets and all their transitive dependencies."""
        selected: set[str] = set()

        def visit(name: str) -> None:
            if name in selected:
                return
            selected.add(name)
            for dependency in self.targets[name].dependencies:
                visit(dependency)

        for name in requested:
            if name not in self.targets:
                msg = f"unknown target: {name}"
                raise GraphError(msg)
            visit(name)
        return selected

    def topological(self, selected: set[str] | None = None) -> tuple[str, ...]:
        """Return selected targets in dependency-first order."""
        if selected is None:
            return self._order
        return tuple(name for name in self._order if name in selected)

    def dependents(self, selected: set[str]) -> dict[str, set[str]]:
        """Index each selected target by its immediate dependents."""
        result: dict[str, set[str]] = {}
        for name in selected:
            for dependency in self.targets[name].dependencies:
                if dependency not in result:
                    result[dependency] = set()
                result[dependency].add(name)
        return result

    def _validated_order(self) -> tuple[str, ...]:
        visiting: list[str] = []
        visited: set[str] = set()
        ordered: list[str] = []

        def visit(name: str) -> None:
            if name in visiting:
                start = visiting.index(name)
                cycle = [*visiting[start:], name]
                raise GraphError("dependency cycle: " + " -> ".join(cycle))
            if name in visited:
                return
            visiting.append(name)
            for dependency in self.targets[name].dependencies:
                if dependency not in self.targets:
                    msg = f"target {name!r} depends on unknown target {dependency!r}"
                    raise GraphError(msg)
                visit(dependency)
            visiting.pop()
            visited.add(name)
            ordered.append(name)

        for name in self.targets:
            visit(name)
        return tuple(ordered)
