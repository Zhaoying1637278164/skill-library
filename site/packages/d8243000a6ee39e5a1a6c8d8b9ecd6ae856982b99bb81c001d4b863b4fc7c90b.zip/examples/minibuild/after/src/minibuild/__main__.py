# SPDX-License-Identifier: CC0-1.0
"""Run minibuild as a module."""

from .cli import main

raise SystemExit(main())
