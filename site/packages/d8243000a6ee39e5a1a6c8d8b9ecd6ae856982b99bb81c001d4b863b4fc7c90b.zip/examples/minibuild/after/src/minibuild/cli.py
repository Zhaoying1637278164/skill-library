# SPDX-License-Identifier: CC0-1.0
"""Provide minibuild's command-line interface."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .config import ConfigError, load_project
from .engine import BuildEngine, BuildStatus
from .graph import GraphError


def build_parser() -> argparse.ArgumentParser:
    """Create the minibuild argument parser."""
    parser = argparse.ArgumentParser(prog="minibuild")
    parser.add_argument(
        "--config", type=Path, default=Path("minibuild.toml"), help="project file"
    )
    subparsers = parser.add_subparsers(dest="action", required=True)

    build = subparsers.add_parser("build", help="build targets and their dependencies")
    build.add_argument("targets", nargs="+")
    build.add_argument("-j", "--jobs", type=int)

    explain = subparsers.add_parser("explain", help="explain rebuild decisions")
    explain.add_argument("targets", nargs="+")

    graph = subparsers.add_parser("graph", help="print the dependency graph")
    graph.add_argument("targets", nargs="*")

    clean = subparsers.add_parser("clean", help="remove outputs and saved state")
    clean.add_argument("targets", nargs="*")
    return parser


def main(argv: list[str] | None = None) -> int:
    """Run the minibuild command-line interface."""
    arguments = build_parser().parse_args(argv)
    try:
        engine = BuildEngine(load_project(arguments.config))
        return _dispatch(engine, arguments)
    except (ConfigError, GraphError) as error:
        print(f"minibuild: {error}", file=sys.stderr)
        return 2


def _dispatch(engine: BuildEngine, arguments: argparse.Namespace) -> int:
    if arguments.action == "build":
        return _build(engine, arguments.targets, arguments.jobs)
    if arguments.action == "explain":
        return _explain(engine, arguments.targets)
    if arguments.action == "graph":
        return _graph(engine, arguments.targets)
    return _clean(engine, arguments.targets)


def _build(engine: BuildEngine, targets: list[str], jobs: int | None) -> int:
    if jobs is not None and jobs < 1:
        msg = "--jobs must be at least 1"
        raise ConfigError(msg)
    results = engine.build(targets, jobs)
    for result in results:
        print(f"{result.status.value:7} {result.target}: {result.reason}")
        if result.output:
            end = "" if result.output.endswith("\n") else "\n"
            print(result.output, end=end)
    return int(any(result.status == BuildStatus.FAILED for result in results))


def _explain(engine: BuildEngine, targets: list[str]) -> int:
    for result in engine.explain(targets):
        verb = "rebuild" if result.status == BuildStatus.BUILT else "skip"
        print(f"{verb:7} {result.target}: {result.reason}")
    return 0


def _graph(engine: BuildEngine, targets: list[str]) -> int:
    selected = engine.graph.closure(targets) if targets else None
    for name in engine.graph.topological(selected):
        dependencies = ", ".join(engine.project.targets[name].dependencies) or "-"
        print(f"{name}: {dependencies}")
    return 0


def _clean(engine: BuildEngine, targets: list[str]) -> int:
    removed = engine.clean(targets or None)
    for path in removed:
        print(f"removed {path.relative_to(engine.project.root)}")
    return 0
