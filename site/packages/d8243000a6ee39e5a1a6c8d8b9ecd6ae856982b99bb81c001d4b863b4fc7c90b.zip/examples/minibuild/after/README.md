# minibuild

`minibuild` is a small incremental build system used as an example project for
the repository's `cleanup` skill.

The implementation uses only the Python standard library. It supports:

- TOML project files
- dependency validation and cycle detection
- content-based input and output fingerprints
- persistent incremental build state
- concurrent execution of independent targets
- failure propagation to blocked dependents
- rebuild explanations
- graph inspection and output cleanup

## Try it

From this directory:

```sh
python -m minibuild --config sample/minibuild.toml graph
python -m minibuild --config sample/minibuild.toml build package
python -m minibuild --config sample/minibuild.toml explain package
python -m minibuild --config sample/minibuild.toml clean
```

Set `PYTHONPATH=src` if the package has not been installed:

```sh
PYTHONPATH=src python -m minibuild --config sample/minibuild.toml build package
```

Or let uv create and manage the development environment:

```sh
uv sync
uv run minibuild --config sample/minibuild.toml build package
```

## Configuration

Each target declares dependencies, globbed inputs, expected outputs, and an
argument-vector command:

```toml
[project]
state_file = ".minibuild/state.json"

[targets.bundle]
deps = ["compile"]
inputs = ["src/app.txt"]
outputs = ["build/application.txt"]
command = ["python", "tools/build.py", "bundle"]
```

Commands run from the directory containing `minibuild.toml`. A successful
command must create every declared output. Build state is written atomically
after a run.

## Tests

```sh
uv run pytest
uv run coverage run -m pytest
uv run coverage report
uv run basedpyright
uv run ruff check .
uv run ruff format --check .
```
