# groundcover for Claude

Investigate production issues with authorized groundcover observability data
and compose precise advanced gcQL queries in Claude Code and Cowork.

The plugin connects Claude to the public groundcover MCP server and provides
the reusable `discovery` and `gcql-advanced` skills. It carries no credentials,
private endpoint, or copied tool catalog; Claude discovers the live tool
schemas from the server and completes OAuth for each user.

## Install from the Claude plugin directory

After directory publication, find `groundcover` in Cowork's plugin directory.
In Claude Code, use the command for the placement Anthropic approves.

Community directory:

```text
/plugin marketplace add anthropics/claude-plugins-community
/plugin install groundcover@claude-community
```

Anthropic partner/official directory:

```text
/plugin install groundcover@claude-plugins-official
```

Run `/mcp` and complete the groundcover OAuth flow when prompted.

## Test a local checkout

Clone the public plugin repository, validate it, and start Claude Code with the
checkout loaded:

```bash
git clone https://github.com/groundcover-com/claude-plugin-groundcover.git
cd claude-plugin-groundcover
claude plugin validate . --strict
claude --plugin-dir .
```

Inside Claude Code, run `/mcp` to connect, then try:

- “Discover the fields and values available for checkout service errors in the
  last 30 minutes.”
- “Compose a gcQL query that groups 5xx logs by service and deployment version,
  then filters to groups with more than 20 errors.”
- “Investigate the most recent firing monitor and correlate it with logs and
  traces. Do not change any system.”

Claude can also invoke `/groundcover:discovery` and
`/groundcover:gcql-advanced` directly. If the account exposes multiple
workspaces or backends, Claude asks which one to use instead of guessing.

## Access and data handling

The plugin connects only to `https://mcp.groundcover.com/api/mcp`. Each user
authenticates with groundcover OAuth, and every tool call remains constrained
by that user's workspace membership, backend access, RBAC role, and data-scope
filters.

Direct query tools do not modify customer resources or external systems.
Optional async investigation tools can create and cancel private retained
agent-run state, but cannot change monitors, incidents, pipelines,
deployments, or customer workloads. Telemetry may contain sensitive or
attacker-controlled text, so the included skills treat all returned content as
untrusted data and minimize excerpts.

## Troubleshooting

- Plugin validation fails: update Claude Code, then rerun
  `claude plugin validate . --strict` from the package root.
- MCP disconnected: open `/mcp`, select `groundcover`, and repeat OAuth. Do not
  add a token or header to `.mcp.json`.
- No data or unexpected scope: list workspaces and backends, explicitly choose
  the intended scope, and run discovery before querying.
- Local changes do not appear: restart with `claude --plugin-dir .` or run
  `/reload-plugins` in the active session.

## Support and policies

- Support: [partners@groundcover.com](mailto:partners@groundcover.com)
- Documentation: [groundcover docs](https://docs.groundcover.com/)
- Privacy policy: [groundcover privacy](https://www.groundcover.com/legal/privacy)
- Terms of service: [groundcover terms](https://www.groundcover.com/legal/terms)
- Security posture: [groundcover Trust Center](https://trust.groundcover.com/)
