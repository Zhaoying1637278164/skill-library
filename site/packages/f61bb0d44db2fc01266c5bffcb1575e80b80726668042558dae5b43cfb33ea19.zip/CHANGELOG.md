# Changelog

## 0.1.0 - 2026-09-03

- Add the initial groundcover plugin for Claude Code and Cowork.
- Connect to the public groundcover MCP server with OAuth.
- Package the shared discovery and advanced gcQL skills.
