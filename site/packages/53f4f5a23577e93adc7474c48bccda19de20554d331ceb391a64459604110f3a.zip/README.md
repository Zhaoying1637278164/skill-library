# Global Database — MCP Server

[![Add to Cursor](https://cursor.com/deeplink/mcp-install-dark.svg)](cursor://anysphere.cursor-deeplink/mcp/install?name=global-database&config=eyJ0eXBlIjogImh0dHAiLCAidXJsIjogImh0dHBzOi8vbWNwLmdsb2JhbGRhdGFiYXNlLmNvbS9tY3AifQ==)
[![Install in VS Code](https://img.shields.io/badge/VS_Code-Install_server-0098FF?logo=visualstudiocode&logoColor=white)](https://insiders.vscode.dev/redirect/mcp/install?name=global-database&config=%7B%22type%22%3A%20%22http%22%2C%22url%22%3A%20%22https%3A%2F%2Fmcp.globaldatabase.com%2Fmcp%22%7D)
[![Smithery](https://img.shields.io/badge/Smithery-global--database-7c3aed)](https://smithery.ai/servers/global-database)
[![MCP Registry](https://img.shields.io/badge/MCP_Registry-com.globaldatabase%2Fmcp-1f6feb)](https://registry.modelcontextprotocol.io)

Remote [MCP](https://modelcontextprotocol.io/) server that gives LLM agents access to
[Global Database](https://globaldatabase.com/): company profiles, financials, ownership,
digital insights, people search and contact enrichment, prospecting, and KYB/compliance
lookups against official government registries.

Hosted at **`https://mcp.globaldatabase.com/mcp`** (Streamable HTTP). Nothing to install
or run — you connect to it and sign in with your Global Database API key through the
browser.

## Install

### Cursor

Add to `~/.cursor/mcp.json` (global) or `.cursor/mcp.json` (per project):

```json
{
  "mcpServers": {
    "global-database": {
      "type": "http",
      "url": "https://mcp.globaldatabase.com/mcp"
    }
  }
}
```

### Claude Code

```bash
claude mcp add --transport http global-database https://mcp.globaldatabase.com/mcp
```

Or install the plugin, which adds the server **and** three skills (`company-due-diligence`,
`company-snapshot`, `prospect-list`):

```
/plugin marketplace add global-database/mcp-server
/plugin install global-database@global-database
```

### VS Code (GitHub Copilot)

Use the **Install server** badge above, or add it from the terminal:

```bash
code --add-mcp '{"name":"global-database","type":"http","url":"https://mcp.globaldatabase.com/mcp"}'
```

To commit it for a whole repository instead, put this in `.vscode/mcp.json` — the copy in
this repo is exactly that file, so cloning it and opening the folder in VS Code offers the
server without any further setup:

```json
{
  "servers": {
    "global-database": {
      "type": "http",
      "url": "https://mcp.globaldatabase.com/mcp"
    }
  }
}
```

Note the key is **`servers`**, not `mcpServers`. VS Code differs from Claude Code and Cursor
here, the same way Gemini CLI expects `httpUrl` and Antigravity expects `serverUrl` for the
identical endpoint. Copying the wrong file between clients produces a config that loads
without error and connects to nothing.

A user-level equivalent exists too — run **MCP: Open User Configuration** from the Command
Palette (it lives under the VS Code user profile, not `~/.copilot/mcp-config.json` — that
path belongs to the separate GitHub Copilot CLI and expects `mcpServers`, not `servers`).

Signing in is a browser OAuth flow on first use; there is nothing to paste into the config.

### Gemini CLI

Install the bundled extension straight from this repo:

```bash
gemini extensions install https://github.com/global-database/mcp-server
```

Or add the server to `settings.json` by hand:

```json
{
  "mcpServers": {
    "global-database": {
      "httpUrl": "https://mcp.globaldatabase.com/mcp",
      "authProviderType": "dynamic_discovery"
    }
  }
}
```

### Perplexity

Requires a paid plan (custom connectors are a Pro/Enterprise feature). In **Settings →
Connectors → + Custom connector → Remote**, enter:

| Field | Value |
|---|---|
| Name | Global Database |
| MCP Server URL | `https://mcp.globaldatabase.com/mcp` |
| Authentication | OAuth |
| Transport | Streamable HTTP |

Then open the connector card to run the OAuth sign-in.

### Grok

At [grok.com/connectors](https://grok.com/connectors) → **New Connector → Custom**, enter the
MCP server URL `https://mcp.globaldatabase.com/mcp` and complete the OAuth sign-in. Grok
discovers the tools from the live endpoint.

### Microsoft Copilot Studio

In your agent → **Tools → Add a tool → Model Context Protocol → New MCP server**, enter the
server URL `https://mcp.globaldatabase.com/mcp` and pick **OAuth 2.0** with dynamic
registration / discovery. Leave **Scope empty** — the server publishes no scopes, and a
non-empty one fails the token request.

Copilot Studio ignores the MCP `instructions` field, so the agent starts without the routing
rules every other client receives. Paste
[`copilot-studio-instructions.md`](copilot-studio-instructions.md) into **Agent → Overview →
Instructions** after the connection is created.

### Claude.ai / other MCP clients

Add a custom connector pointing at `https://mcp.globaldatabase.com/mcp`.

## Authentication

OAuth 2.1 with PKCE and Dynamic Client Registration — the client registers itself, so there
is nothing to configure. On first connect your browser opens a Global Database login page
where you paste your API key; the key is held in the access-token claims server-side and is
never passed as a tool argument.

Get an API key at [globaldatabase.com](https://globaldatabase.com/).

## Tools

| Tool | What it does |
|---|---|
| `check_api_key` | Verify the API connection and return current user info. |
| `get_company_by_website` | Look up a company by website URL or domain. |
| `get_company_by_linkedin` | Look up a company by LinkedIn URL or public ID. |
| `get_company_by_identifiers` | Look up a company by name, registration number, VAT, ticker, website, email, or LinkedIn. |
| `get_company_details` | Full company profile by `company_id`. |
| `get_company_financials` | Balance sheet, ratios, and key metrics per year. |
| `get_company_ownership` | Shareholders and corporate group structure. |
| `get_digital_insights` | Web traffic, rankings, traffic sources, WHOIS, technologies. |
| `search_employees` | Find the people at a company, or people by name, role, department, or seniority. |
| `get_employee_details` | Full profile for one person from a `search_employees` row. |
| `find_people_by_domain` | Find people at companies given by web domain, via the contact-enrichment providers. |
| `enrich_employee_contacts` | Find and enrich one named employee/contact — email, phone, socials. |
| `get_nomenclature` | Lookup values for use with prospecting filters. |
| `prospecting` | Search and filter companies by country, industry, size, revenue, and more. |
| `kyb_search` | Search official government registries for KYB/compliance checks. |
| `kyb_company_details` | Official registry details for a company. |
| `kyb_officers` | Directors, secretaries, and officers from the official registry. |
| `kyb_shareholders` | Shareholders from the official registry. |
| `kyb_shareholders_search` | Reverse shareholder lookup by holder name, across jurisdictions. |
| `kyb_group_structure` | Corporate group structure from the official registry. |
| `kyb_financial` | Detailed financial statements across multiple years. |
| `kyb_officers_search` | Reverse officer lookup by person's name, across jurisdictions. |

## Resources and prompts

Beyond tools, the server exposes MCP resources so a client can load reference data once per
conversation instead of spending a tool call (and credits) on it:

| Resource | Contents |
|---|---|
| `gdb://nomenclature/country` | Country list for the `prospecting` location filter. |
| `gdb://nomenclature/kyb-countries` | Country list for `kyb_search`. |
| `gdb://nomenclature/company-status` | Company status values for `prospecting`. |
| `gdb://nomenclature/department` | Department ids for `search_employees`. |
| `gdb://nomenclature/seniority` | Seniority ids for `search_employees`. |
| `gdb://docs/prospecting-filters` | Full prospecting filter catalog — field names and value formats. |
| `gdb://docs/intent-glossary` | Keyword → tool glossary for routing a request. |

Larger, hierarchical nomenclatures (NACE, ISIC, SIC, industry focus, region) stay behind the
`get_nomenclature` tool and its `search` parameter.

Prompts shipped with the server: `company_research`, `due_diligence`, `lead_generation`,
`competitor_analysis`, `market_research`.

## Plugins and skill

The same contents ship as a plugin for both Cursor (`.cursor-plugin/plugin.json`) and
Claude Code (`.claude-plugin/marketplace.json`), so the server can be installed from a
marketplace instead of being wired up by hand. Each plugin bundles:

- the remote MCP server above (all tools), and
- three skills: **`company-due-diligence`** walks the agent through a structured KYB
  review — resolve the entity, then pull registry details, officers, shareholders,
  group structure and financials into one dossier; **`company-snapshot`** gives a fast
  one-screen profile instead of the full dossier; **`prospect-list`** builds a target
  account list from firmographic filters, optionally enriched with contacts.

## Where it is listed

Verified 2026-09-01.

| Directory | Entry |
|---|---|
| [Official MCP Registry](https://registry.modelcontextprotocol.io) | [`com.globaldatabase/mcp`](https://registry.modelcontextprotocol.io/v0/servers?search=globaldatabase) — published from [`server.json`](server.json) |
| [Claude Connectors Directory](https://claude.ai/directory) | [`global-database`](https://claude.ai/directory/global-database) — Community tier |
| [Claude Plugin Directory](https://claude.com/plugins) | `global-database` — **submitted 2026-09-01, pending review**. Ships the MCP server plus three skills |
| [OpenAI ChatGPT](https://chatgpt.com/) | [Global Database](https://chatgpt.com/plugins/plugin_asdk_app_696f807d21a481918a1ed1f43d719ce9) — Apps SDK app |
| [Smithery](https://smithery.ai/servers/global-database) | [`global-database`](https://smithery.ai/servers/global-database) |
| [Glama](https://glama.ai/mcp/servers) | [`com.globaldatabase/mcp`](https://glama.ai/mcp/connectors/com.globaldatabase/mcp) |
| [Cursor Directory](https://cursor.directory/) | [`mcp-global-database-3`](https://cursor.directory/plugins/mcp-global-database-3) |
| [mcptop.com](https://mcptop.com/) | [`openai-global-database`](https://mcptop.com/server/openai-global-database) — third-party leaderboard |

Also installable without a directory:

| Channel | How |
|---|---|
| Claude Code plugins | `/plugin marketplace add global-database/mcp-server` |
| Antigravity CLI | `agy plugin install` against this repo |
| Gemini Enterprise | admin registers it as a custom MCP connection per tenant |

Not listed: PulseMCP (their submissions are paused), mcp.so, and the VS Code / GitHub MCP
gallery — that last one is a curated catalogue of a few hundred servers and is **not** an
ingest of the Official MCP Registry, so publishing there does not reach it. Also not
pursued: Perplexity's curated connector catalog (no self-serve submission exists — only the
custom-connector route above) and Microsoft's MCP server certification for Copilot Studio (a
real Partner Center pipeline, unlike Perplexity's — see `PUBLISHING.md`).

Maintainer notes — publishing, DNS verification and the remaining directories:
[`PUBLISHING.md`](PUBLISHING.md).

## Links

- [Homepage](https://mcp.globaldatabase.com)
- [Smithery listing](https://smithery.ai/servers/global-database)
- [Privacy policy](https://mcp.globaldatabase.com/static/privacy.html)
- [Terms](https://mcp.globaldatabase.com/static/terms.html)

## About this repository

Distribution metadata only (`server.json`, `.mcp.json`, `plugin.json`,
`.claude-plugin/`, `.cursor-plugin/`, `gemini-extension.json`) so MCP directories and
clients can discover the hosted server, plus the client-side extras that ship with it — the
three skills and the Copilot Studio instruction block. MIT covers this
metadata; the server implementation and the Global Database API are not open source.
