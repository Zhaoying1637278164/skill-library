---
so_hieu: 06/2024/TT-BTTTT
loai_van_ban: Thông tư
tier: 4
tieu_de: Thông tư số 06/2024/TT-BTTTT quy định công nhận Tổ chức cung cấp dịch vụ
  chữ ký điện tử nước ngoài; công nhận chữ ký điện tử, chứng thư chữ ký điện
  tử nước ngoài tại Việt Nam
nganh: Thông tin và Truyền thông
linh_vuc: Giáo dục đào tạo
co_quan_ban_hanh: Bộ Thông tin và Truyền thông
organization: Bộ Khoa học và Công nghệ
nguoi_ky: Nguyễn Mạnh Hùng
chuc_danh: Bộ trưởng
ngay_ban_hanh: '2024-07-01'
ngay_co_hieu_luc: '2024-08-15'
ngay_cong_bao: null
ngay_het_hieu_luc: null
tinh_trang: con_hieu_luc
vbpl_guid: '168217'
nguon_url: https://vbpl.vn/van-ban/chi-tiet/168217
quy_dinh_chi_tiet:
- '[[Luat-20-2023]]'
can_cu_ban_hanh:
- '[[Luat-20-2023]]'
- 48/2022/NĐ-CP
tham_chieu_ngoai:
- so_hieu: 48/2022/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/155414
  label: can_cu_ban_hanh
---

# Thông tư 06/2024/TT-BTTTT — Thông tư số 06/2024/TT-BTTTT quy định công nhận Tổ chức cung cấp dịch vụ chữ ký điện tử nước ngoài; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam

## Điều 1. Phạm vi điều chỉnh     ^dieu-1
Thông tư này quy định về công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.

## Điều 2. Đối tượng áp dụng     ^dieu-2
Thông tư này áp dụng đối với tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài đề nghị công nhận tại Việt Nam; tổ chức, cá nhân nước ngoài, tổ chức, cá nhân Việt Nam có nhu cầu giao dịch điện tử với tổ chức, cá nhân nước ngoài mà chữ ký điện tử, chứng thư chữ ký điện tử của tổ chức cung cấp dịch vụ trong nước chưa được công nhận tại nước đó; tổ chức, cá nhân có liên quan đến việc công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.

## Điều 3. Hồ sơ công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam.     ^dieu-3
Hồ sơ công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam gồm các tài liệu giải trình, chứng minh đáp ứng đủ điều kiện quy định tại khoản 1 Điều 26 Luật giao dịch điện tử. Cụ thể như sau:
1. Văn bản đề nghị công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài theo mẫu tại Mẫu số 01 ban hành kèm theo Thông tư này.
2. Tài liệu hợp pháp hóa lãnh sự và bản dịch thuật công chứng giấy phép hoặc giấy chứng nhận chứng minh thành lập và hoạt động hợp pháp tại quốc gia đăng ký hoạt động; Bản cam kết đang hoạt động trong vòng 06 tháng trước ngày nộp hồ sơ.
3. Bản dịch thuật công chứng Báo cáo kiểm toán kỹ thuật của Hệ thống cung cấp dịch vụ chứng thực chữ ký điện tử từ tổ chức kiểm toán hoạt động hợp pháp tại quốc gia đăng ký hoạt động trong vòng 06 tháng trước ngày nộp hồ sơ.
4. Văn bản, tài liệu chứng minh đáp ứng quy định tại điểm b khoản 1 Điều 26 Luật giao dịch điện tử gồm:
Các văn bản, tài liệu kỹ thuật chứng minh chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài do tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài đó cung cấp phù hợp với tiêu chuẩn, quy chuẩn kỹ thuật về chữ ký điện tử, chứng thư chữ ký điện tử theo quy định của pháp luật Việt Nam hoặc điều ước quốc tế mà nước Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên.
5. Văn bản, tài liệu chứng minh đáp ứng điểm c khoản 1 Điều 26 Luật giao dịch điện tử gồm:
a) Tối thiểu 01 chứng thư chữ ký điện tử nước ngoài của thuê bao kèm theo tài liệu đăng ký sử dụng của thuê bao đó.
b) Văn bản chứng minh có quy định về hồ sơ thuê bao, quy định quy trình xác minh, xác thực thông tin định danh của thuê bao.
6. Chứng thư chữ ký điện tử nước ngoài có giá trị pháp lý và được tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài cập nhật trạng thái vào Hệ thống chứng thực dịch vụ tin cậy của Tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử quốc gia. Việc cập nhật trạng thái chứng thư chữ ký điện tử nước ngoài theo hướng dẫn kỹ thuật của Tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử quốc gia.
Các trường thông tin trên chứng thư chữ ký điện tử nước ngoài phải bao gồm các thông tin tối thiểu theo quy định của pháp luật Việt Nam để phục vụ kiểm tra trạng thái chứng thư chữ ký điện tử nước ngoài trên Hệ thống chứng thực dịch vụ tin cậy.
7. Bản sao hợp lệ Giấy chứng nhận đăng ký hoạt động của văn phòng đại diện tại Việt Nam.

## Điều 4. Trình tự, thủ tục công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam.     ^dieu-4
1. Tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài nộp hồ sơ công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam lựa chọn hình thức trực tiếp hoặc qua đường bưu điện hoặc trực tuyến theo hướng dẫn sau:
a) Gửi trực tiếp hoặc theo đường bưu điện đến Bộ Thông tin và Truyền thông (Tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia), địa chỉ số 18 Nguyễn Du - Hai Bà Trưng - Hà Nội.
b) Gửi trực tuyến qua hệ thống dịch vụ công trực tuyến (Cổng dịch vụ công quốc gia, https://dichvucong.gov.vn hoặc Cổng dịch vụ công của Bộ Thông tin và Truyền thông, https://dichvucong.mic.gov.vn).
c) Văn bản do cơ quan, tổ chức có thẩm quyền của nước ngoài cấp, công nhận hoặc chứng nhận phải được hợp pháp hóa lãnh sự theo quy định của pháp luật Việt Nam (trừ trường hợp được miễn hợp pháp hóa lãnh sự theo quy định của pháp luật về hợp pháp hóa lãnh sự) và được dịch thuật công chứng sang tiếng Việt.
2. Trong thời hạn 45 ngày tính từ ngày nhận được hồ sơ hợp lệ, Bộ Thông tin và Truyền thông (Tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia) phối hợp với Bộ Công an xem xét, đánh giá hồ sơ và kiểm tra trạng thái chứng thư chữ ký điện tử của tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử đề nghị công nhận tại Việt Nam.
3. Trường hợp đáp ứng đủ điều kiện theo quy định:
a) Bộ Thông tin và Truyền thông cấp giấy công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam. Mẫu giấy công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài quy định theo Mẫu số 02 ban hành kèm theo Thông tư này.
b) Tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia công nhận chứng thư chữ ký điện tử của cho tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài được công nhận tại Việt Nam và công bố chứng thư chữ ký điện tử đó trên Hệ thống chứng thực dịch vụ tin cậy.
4. Trường hợp không đáp ứng đủ điều kiện, Bộ Thông tin và Truyền thông có thông báo và nêu rõ lý do.
5. Trường hợp tổ chức thực hiện thủ tục hành chính trên môi trường điện tử, dịch vụ công trực tuyến, việc tiếp nhận và xử lý hồ sơ, trả kết quả được thực hiện theo quy định của Chính phủ về thực hiện thủ tục hành chính trên môi trường điện tử, cung cấp dịch vụ công trực tuyến của cơ quan nhà nước trên môi trường điện tử và pháp luật về giao dịch điện tử.

## Điều 5. Thời hạn công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam.     ^dieu-5
1. Thời hạn công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam là thời hạn theo giấy phép cung cấp dịch vụ của tổ chức đó tại nước sở tại và không quá thời hạn của chứng thư chữ ký điện tử của tổ chức đó.
2. Trường hợp thay đổi thông tin dẫn đến thay đổi chứng thư chữ ký điện tử của tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài được công nhận tại Việt Nam, tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài báo cáo việc thay đổi và đề nghị công nhận lại chứng thư chữ ký điện tử theo hồ sơ, trình tự được nêu tại Điều 3, Điều 4 Thông tư này.

## Điều 6. Hồ sơ đề nghị công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam     ^dieu-6
Hồ sơ đề nghị công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam gồm các tài liệu, văn bản giải trình, chứng minh đáp ứng đủ điều kiện quy định tại khoản 2 Điều 26 Luật giao dịch điện tử. Cụ thể như sau:
1. Giấy đề nghị theo mẫu tại Mẫu số 03 ban hành kèm theo Thông tư này.
2. Văn bản, tài liệu kỹ thuật chứng minh Chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài phù hợp với tiêu chuẩn, quy chuẩn kỹ thuật về chữ ký điện tử, chứng thư chữ ký điện tử theo quy định của pháp luật Việt Nam hoặc điều ước quốc tế mà nước Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên.
3. Chứng thư chữ ký điện tử nước ngoài đề nghị công nhận tại Việt Nam có các trường thông tin tối thiểu theo quy định của pháp luật Việt Nam để phục vụ kiểm tra trạng thái chứng thư chữ ký điện tử trên hệ thống chứng thực dịch vụ tin cậy.
4. Các tài liệu sau đây để chứng minh Chứng thư chữ ký điện tử nước ngoài hình thành dựa trên thông tin định danh đã được xác thực của tổ chức, cá nhân nước ngoài, gồm:
a) Đối với tổ chức Việt Nam: Quyết định thành lập hoặc quyết định quy định về chức năng, nhiệm vụ, quyền hạn, cơ cấu tổ chức hoặc giấy chứng nhận đăng ký doanh nghiệp hoặc giấy chứng nhận đầu tư và thẻ căn cước công dân hoặc thẻ căn cước hoặc giấy chứng nhận căn cước hoặc hộ chiếu của người đại diện theo pháp luật của tổ chức; hoặc sử dụng tài khoản định danh điện tử của tổ chức.
b) Đối với cá nhân Việt Nam: Thẻ căn cước hoặc căn cước điện tử hoặc giấy chứng nhận căn cước hoặc hộ chiếu hoặc sử dụng tài khoản định danh điện tử mức độ 2.
c) Đối với tổ chức nước ngoài: Văn bản của cơ quan có thẩm quyền Việt Nam cho phép hoạt động hợp pháp tại Việt Nam.
d) Đối với cá nhân nước ngoài: Hộ chiếu kèm theo visa hoặc văn bản của cơ quan thẩm quyền Việt Nam xác nhận cư trú hợp pháp tại Việt Nam.
đ) Trường hợp được ủy quyền sử dụng chữ ký điện tử nước ngoài, chứng thư điện tử nước ngoài, tổ chức, cá nhân được ủy quyền phải có văn bản ủy quyền cho phép sử dụng hợp pháp chữ ký điện tử và thông tin thuê bao được cấp chứng thư chữ ký điện tử nước ngoài phải phù hợp với thông tin trong văn bản ủy quyền, cho phép.
5. Bản dịch thuật công chứng giấy phép hoặc giấy chứng nhận chứng minh tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài cấp chứng thư chữ ký điện tử nước ngoài đề nghị công nhận tại Việt Nam được thành lập và hoạt động hợp pháp tại quốc gia đăng ký hoạt động.
6. Cá nhân, tổ chức có quyền lựa chọn nộp bản sao từ sổ gốc, bản sao có chứng thực hoặc nộp bản sao trình kèm bản chính để đối chiếu hoặc cung cấp dữ liệu điện tử đã được xác thực.

## Điều 7. Trình tự, thủ tục công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam     ^dieu-7
1. Tổ chức, cá nhân nộp hồ sơ đề nghị công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam, lựa chọn hình thức trực tiếp hoặc đường bưu điện hoặc trực tuyến theo hướng dẫn sau:
a) Gửi trực tiếp hoặc theo đường bưu điện đến Bộ Thông tin và Truyền thông (Tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia), địa chỉ số 18 Nguyễn Du - Hai Bà Trưng - Hà Nội.
b) Gửi trực tuyến qua hệ thống dịch vụ công trực tuyến (Cổng dịch vụ công quốc gia, https://dichvucong.gov.vn hoặc Cổng dịch vụ công của Bộ Thông tin và Truyền thông, https://dichvucong.mic.gov.vn).
c) Văn bản do cơ quan, tổ chức có thẩm quyền của nước ngoài cấp, công nhận hoặc chứng nhận phải được hợp pháp hóa lãnh sự theo quy định của pháp luật Việt Nam (trừ trường hợp được miễn hợp pháp hóa lãnh sự theo quy định của pháp luật về hợp pháp hóa lãnh sự) và được dịch thuật công chứng sang tiếng Việt.
2. Trong thời hạn 30 ngày kể từ khi nhận được đầy đủ hồ sơ hợp lệ, Bộ Thông tin và Truyền thông (Tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia) phối hợp với Bộ Công an xem xét, đánh giá hồ sơ và kiểm tra chứng thư chữ ký điện tử nước ngoài đề nghị công nhận. Trường hợp cần xác minh thông tin trong văn bản, tài liệu, thời hạn trả kết quả công nhận không vượt quá 65 ngày kể từ ngày tiếp nhận hồ sơ hợp lệ.
3. Trường hợp đáp ứng đủ điều kiện theo quy định:
a) Bộ Thông tin và Truyền thông cấp giấy công nhận theo mẫu tại Mẫu số 04 ban hành kèm theo Thông tư này.
b) Tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia cập nhật chứng thư chữ ký điện tử nước ngoài được công nhận vào danh sách tin cậy và công bố trên Hệ thống chứng thực dịch vụ tin cậy.
4. Trường hợp hồ sơ không đáp ứng đủ điều kiện theo quy định, Bộ Thông tin và Truyền thông có thông báo và nêu rõ lý do.
5. Trường hợp cá nhân, tổ chức lựa chọn thực hiện thủ tục hành chính trên môi trường điện tử, dịch vụ công trực tuyến, việc tiếp nhận, xử lý hồ sơ, trả kết quả được thực hiện theo quy định của Chính phủ về thực hiện thủ tục hành chính trên môi trường điện tử, cung cấp dịch vụ công trực tuyến của cơ quan nhà nước trên môi trường điện tử và pháp luật về giao dịch điện tử.

## Điều 8. Thời hạn công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.     ^dieu-8
1. Thời hạn công nhận chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài tại Việt Nam là 05 (năm) năm nhưng không quá thời hạn hiệu lực của chứng thư chữ ký điện tử đó.
2. Trường hợp thay đổi thông tin dẫn đến thay đổi chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài đã được công nhận tại Việt Nam, tổ chức, cá nhân báo cáo việc thay đổi và đề nghị công nhận lại chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài theo hồ sơ, trình tự được nêu tại Điều 6, Điều 7 Thông tư này.

## Điều 9. Tổ chức thực hiện     ^dieu-9
1. Tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài được công nhận tại Việt Nam, định kỳ sau mỗi năm hoạt động cần nộp Báo cáo kiểm toán kỹ thuật và Báo cáo cung cấp dịch vụ tại Việt Nam trong kỳ báo cáo đến Bộ Thông tin và Truyền thông. Thời hạn nộp báo cáo trong vòng 30 ngày đầu tiên của năm hoạt động kế tiếp. Kết quả của báo cáo kiểm toán kỹ thuật và báo cáo tình hình hoạt động là căn cứ để Bộ Thông tin và Truyền thông xem xét:
a) Tiếp tục công nhận nếu kết quả Báo cáo kiểm toán của năm hoạt động đáp ứng tiêu chuẩn, quy chuẩn kỹ thuật về chữ ký điện tử, chứng thư chữ ký điện tử theo quy định của pháp luật hiện hành Việt Nam hoặc tiêu chuẩn quốc tế đã được thừa nhận hoặc điều ước quốc tế mà nước Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên.
b) Ngừng công nhận theo quyết định của Bộ Thông tin và Truyền Thông nếu kết quả Báo cáo kiểm toán của năm hoạt động không đáp ứng tiêu chuẩn, quy chuẩn kỹ thuật về chữ ký điện tử, chứng thư chữ ký điện tử theo quy định của pháp luật hiện hành Việt Nam hoặc tiêu chuẩn quốc tế đã được thừa nhận hoặc điều ước quốc tế mà nước Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên.
2. Tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài được công nhận tại Việt Nam có các trách nhiệm sau:
a) Cung cấp dịch vụ đúng đối tượng, phạm vi và tuân thủ quy định về cấp, thu hồi, tạm dừng chứng thư chữ ký điện tử cho thuê bao tương tự như hoạt động cung cấp dịch vụ chứng thực chữ ký số công cộng tại Việt Nam.
b) Cung cấp cho tổ chức cung cấp dịch vụ chứng thực điện tử quốc gia thông tin về số lượng chứng thư chữ ký điện tử cung cấp tại Việt Nam đang có hiệu lực, bị tạm dừng, bị thu hồi; Thông tin thuê bao và chứng minh thông tin thuê bao trong cơ sở dữ liệu tập trung của tổ chức đã được đối chiếu, xác thực, nhập, lưu trữ, quản lý theo đúng các quy định pháp luật để phục vụ công tác quản lý nhà nước về dịch vụ chứng thực chữ ký điện tử.
3. Tổ chức, cá nhân sử dụng chữ ký điện tử nước ngoài, chứng thư chữ ký điện tử nước ngoài được công nhận tại Việt Nam có trách nhiệm sau:
a) Sử dụng đúng phạm vi, mục đích được quy định tại khoản 3 Điều 26 Luật giao dịch điện tử.
b) Có quyền và trách nhiệm tương tự thuê bao sử dụng dịch vụ chứng thực chữ ký số công cộng trong việc sử dụng chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài được công nhận tại Việt Nam.

## Điều 10. Điều khoản chuyển tiếp     ^dieu-10
Các tổ chức cung cấp dịch vụ chứng thực chữ ký số nước ngoài, các chứng thư số nước ngoài được công nhận tại Việt Nam theo quy định tại Nghị định số 130/2018/NĐ-CP ngày 27 tháng 9 năm 2018 của Chính phủ quy định chi tiết thi hành Luật giao dịch điện tử về chữ ký số và dịch vụ chứng thực chữ ký số được hoạt động và sử dụng tiếp cho đến hết thời hạn được công nhận.

## Điều 11. Hiệu lực thi hành     ^dieu-11
Thông tư có hiệu lực thi hành từ ngày 15 tháng 8 năm 2024 trừ trường hợp quy định tại Điều 10 Nghị định này./.
Nơi nhận:
- Thủ tướng, các Phó Thủ tướng Chính phủ;
- Các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ;
- UBND các tỉnh, thành phố trực thuộc TW;
- Sở TTTT các tỉnh, thành phố trực thuộc TW;
- Cục Kiểm tra văn bản QPPL (Bộ Tư pháp);
- Công báo, Cổng thông tin điện tử Chính phủ;
- Bộ TTTT: Bộ trưởng và các Thứ trưởng,
các cơ quan, đơn vị thuộc Bộ;
- Cổng thông tin điện tử Bộ;
- Lưu: VT, NEAC (20b).
BỘ TRƯỞNG
(Đã ký)
Nguyễn Mạnh Hùng
Mẫu số 01.Thông tư số /2024/TT-BTTTT ngày tháng năm của Bộ trưởng Bộ Thông tin và Truyền thông tư quy định về công nhận t ổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam
(Tên tổ chức)
-------
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
---------------
Số: …
…, ngày … tháng … năm …
GIẤY ĐỀ NGHỊ CẤP GIẤY CÔNG NHẬN TỔ CHỨC CUNG CẤP DỊCH VỤ CHỨNG THỰC CHỮ KÝ ĐIỆN TỬ NƯỚC NGOÀI TẠI VIỆT NAM
Kính gửi: Bộ Thông tin và Truyền thông.
Căn cứ Luật giao dịch điện tử ngày 22 tháng 06 năm 2023;
Căn cứ Nghị định số………..,
Căn cứ Thông tư số …../2024/TT-BTTT ngày ….của Bộ trưởng Bộ Thông tin và Truyền thông quy định về công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.
(Tên tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài) đề nghị Bộ Thông tin và Truyền thông công nhận tại Việt Nam với các nội dung sau:
1. Thông tin về tổ chức
- Tên giao dịch: ……………………………………………………………..
Giấy phép hoặc giấy chứng nhận chứng minh thành lập và hoạt động hợp pháp tại quốc gia đăng ký hoạt động: ...................................................................................................
Địa chỉ:........................................................................................................
Điện thoại: ………………………Fax...........................................................
E-mail: …………………Website:................................................................
Giấy chứng nhận đăng ký hoạt động của văn phòng đại diện:.........................
Địa chỉ:........................................................................................................
Điện thoại: ………………………................................................................
Người đứng đầu văn phòng đại diện:.............................................................
Thông tin liên hệ người đứng đầu văn phòng đại diện....................................
2. Hồ sơ đề nghị công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam gồm
STT
Tên tài liệu
Số lượng
Ghi chú
1
2
…
3. Cam kết
(Tên tổ chức) cam kết chịu trách nhiệm về tính chính xác của thông tin cung cấp nêu trên cùng các tài liệu kèm theo và cam kết tuân thủ các quy định của pháp luật Việt Nam về việc cung cấp dịch vụ chứng thực chữ ký điện tử và pháp luật có liên quan./.
(NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT CỦA TỔ CHỨC)
(Ký, ghi rõ họ tên, chức danh và đóng dấu đối với tổ chức)
Mẫu số 02.Thông tư số /2024/TT-BTTTT ngày tháng năm của Bộ trưởng Bộ Thông tin và Truyền thông tư quy định về công nhận t ổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam
BỘ THÔNG TIN VÀ
TRUYỀN THÔNG
-------
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
---------------
Số: /GCN-BTTTT
Hà Nội, ngày … tháng … năm …
GIẤY CÔNG NHẬN TỔ CHỨC CUNG CẤP DỊCH VỤ CHỨNG THỰC CHỮ KÝ ĐIỆN TỬ NƯỚC NGOÀI TẠI VIỆT NAM
(Có giá trị đến hết ngày …/…/….)
BỘ TRƯỞNG BỘ THÔNG TIN VÀ TRUYỀN THÔNG
Căn cứ Luật giao dịch điện tử ngày 22 tháng 06 năm 2023;
Căn cứ Nghị định số……;
Căn cứ Thông tư số …../2024/TT-BTTT ngày ….của Bộ trưởng Bộ Thông tin và Truyền thông quy định về công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.
Xét Hồ sơ đề nghị công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam của…………….. (tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài);
Theo đề nghị của …,
NAY CÔNG NHẬN
Điều 1. ( Tên tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài ), có trụ sở tại ......., văn phòng đại diện tại.................... được công nhận tại Việt Nam theo các nội dung sau:
1. Tên giao dịch: ………………………………………………………………
2. Phạm vi và đối tượng cung cấp dịch vụ:...................………………………
3. Phương thức lưu khóa bí mật của thuê bao: ………………………………
4. Các quy chuẩn kỹ thuật và tiêu chuẩn áp dụng
……………………………………………………………………………………
Điều 2. Ngoài các quy định tại Điều 1, (Tên tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài) có trách nhiệm tuân thủ các quy định của pháp luật Việt Nam về cung cấp dịch vụ chứng thực chữ ký điện tử tại và pháp luật có liên quan.
Điều 3. Giấy công nhận ………….. có hiệu lực kể từ ngày ký./.
BỘ TRƯỞNG
Mẫu số 03.Thông tư số /2024/TT-BTTTT ngày tháng năm của Bộ trưởng Bộ Thông tin và Truyền thông tư quy định về công nhận t ổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam
(Tên tổ chức, cá nhân)
-------
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
---------------
Số: …
…, ngày … tháng … năm …
ĐƠN ĐỀ NGHỊ CẤP GIẤY CÔNG NHẬN CHỮ KÝ ĐIỆN TỬ, CHỨNG THƯ CHỮ KÝ ĐIỆN TỬ NƯỚC NGOÀI TẠI VIỆT NAM
Kính gửi: Bộ Thông tin và Truyền thông.
Căn cứ Luật giao dịch điện tử ngày 22 tháng 06 năm 2023;
Căn cứ Nghị định số………..;
Căn cứ Thông tư số …../2024/TT-BTTT ngày ….của Bộ trưởng Bộ Thông tin và Truyền thông quy định về công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.
(Tên tổ chức, cá nhân) đề nghị Bộ Thông tin và Truyền thông cấp giấy phép sử dụng chữ ký điện tử và chứng thư chữ ký điện tử nước ngoài tại Việt Nam với các nội dung sau:
1. Thông tin về cá nhân, tổ chức
Tên giao dịch: ……………………………………………………………..
Quyết định thành lập/Giấy phép kinh doanh (đối với tổ chức) số …… do ...cấp ngày ... tháng ... năm ………
Chứng minh thư nhân dân/Hộ chiếu (đối với cá nhân) số ……………............. do
………………………………………….cấp ngày ... tháng ... năm ...
Địa chỉ: ………………………………………………………………………
Điện thoại: …………………Fax (dành cho tổ chức): .................................
E-mail: …………………….Website (dành cho tổ chức): ........……………
Loại chứng thư số: …………………….. do tổ chức (tên tổ chức cung cấp dịch vụ chứng thực chữ ký số nước ngoài) cấp.
Serial number (SN): …………………………………………………………
Common name (CN): ………………………………………………………
Hiệu lực sử dụng từ ngày ………………. đến ngày ………………………
2. Hồ sơ đề nghị
STT
Tên tài liệu
Số lượng
Ghi chú
1
2
…
3. Cam kết
(Tên tổ chức/cá nhân) cam kết chịu trách nhiệm về tính chính xác của thông tin cung cấp nêu trên cùng các tài liệu kèm theo và cam kết tuân thủ các quy định của pháp luật Việt Nam về việc sử dụng chữ ký điện tử và pháp luật có liên quan./.
(CÁ NHÂN/NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT CỦA TỔ CHỨC)
(Ký, ghi rõ họ tên, chức danh và đóng dấu đối với tổ chức)
Mẫu số 04.Thông tư số /2024/TT-BTTTT ngày tháng năm của Bộ trưởng Bộ Thông tin và Truyền thông tư quy định về công nhận t ổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam
BỘ THÔNG TIN VÀ
TRUYỀN THÔNG
-------
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
---------------
Số: /GCN-BTTTT
Hà Nội, ngày … tháng … năm …
GIẤY CÔNG NHẬN CHỮ KÝ ĐIỆN TỬ ,
CHỨNG THƯ ĐIỆN TỬ NƯỚC NGOÀI TẠI VIỆT NAM
(Có giá trị đến hết ngày …/…/….)
BỘ TRƯỞNG BỘ THÔNG TIN VÀ TRUYỀN THÔNG
Căn cứ Luật giao dịch điện tử ngày 22 tháng 06 năm 2023;
Căn cứ Nghị định số……;
Căn cứ Thông tư số …../2024/TT-BTTT ngày ….của Bộ trưởng Bộ Thông tin và Truyền thông quy định về công nhận tổ chức cung cấp dịch vụ chứng thực chữ ký điện tử nước ngoài tại Việt Nam; công nhận chữ ký điện tử, chứng thư chữ ký điện tử nước ngoài tại Việt Nam.
Xét Hồ sơ đề nghị công nhận chữ ký điện tử và chứng thư chữ ký điện tử nước ngoài tại Việt Nam của…………….. (tên tổ chức, cá nhân);
Theo đề nghị của …,
NAY CÔNG NHẬN
Điều 1. (Tên tổ chức, cá nhân) có địa chỉ/trụ sở tại ..., có Quyết định thành lập/Giấy phép kinh doanh/Chứng minh thư nhân dân/Hộ chiếu: ... do ... cấp ngày ... tháng ... năm ..., được sử dụng chữ ký điện tử và chứng thư chữ ký điện tử nước ngoài tại Việt Nam với những nội dung cụ thể như sau:
1. Thông tin chứng thư số nước ngoài
Loại chứng thư số: ………………… do tổ chức (tên tổ chức cung cấp dịch vụ chứng thực chữ ký số nước ngoài) cấp.
Serial number: ……………………………………………………………………
Hiệu lực sử dụng: …………………………………………………………………
2. Phạm vi sử dụng
……………………………………………………………………………………
……………………………………………………………………………………
3. Các thông tin khác (nếu có):
……………………………………………………………………………………
……………………………………………………………………………………
Điều 2. Ngoài các quy định tại Điều 1, (Tên tổ chức/cá nhân) chịu trách nhiệm tuân thủ pháp luật Việt Nam, thực hiện đầy đủ các quyền và nghĩa vụ của tổ chức/cá nhân sử dụng chữ ký điện tử và chứng thư chữ ký điện tử nước ngoài tại Việt Nam được quy định tại Luật giao dịch điện tử , Nghị định số .../.../NĐ-CP ngày ... tháng ... năm ...của Chính phủ quy định ...và các văn bản quy phạm pháp luật khác có liên quan do cơ quan quản lý nhà nước ban hành./.
Điều 3. Giấy công nhận ………….. có hiệu lực kể từ ngày ký./.
BỘ TRƯỞNG
