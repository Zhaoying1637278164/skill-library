---
so_hieu: 09/2020/TT-BLĐTBXH
loai_van_ban: Thông tư
tier: 4
tieu_de: Thông tư số 09/2020/TT-BLĐTBXH Quy định chi tiết và hướng dẫn thi hành một
  số điều của Bộ luật Lao động về lao động chưa thành niên
nganh: Lao động - Thương binh và Xã hội
linh_vuc: Bảo vệ và chăm sóc trẻ em/An toàn lao động
co_quan_ban_hanh: Bộ Lao động - Thương binh và Xã hội
organization: Bộ Nội vụ
nguoi_ky: Đào Ngọc Dung
chuc_danh: Bộ trưởng
ngay_ban_hanh: '2020-11-12'
ngay_co_hieu_luc: '2021-03-15'
ngay_cong_bao: null
ngay_het_hieu_luc: null
tinh_trang: het_hieu_luc_mot_phan
vbpl_guid: '152670'
nguon_url: https://vbpl.vn/van-ban/chi-tiet/152670
quy_dinh_chi_tiet:
- '[[Luat-45-2019]]'
can_cu_ban_hanh:
- '[[Luat-45-2019]]'
- 14/2017/NĐ-
bi_sua_doi_bo_sung_boi:
- '[[TT-08-2023-BLĐTBXH]]'
thay_the:
- 10/2013/TT-BLĐTBXH
- 11/2013/TT-BLĐTBXH
tham_chieu_ngoai:
- so_hieu: 14/2017/NĐ-
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/119527
  label: can_cu_ban_hanh
- so_hieu: 10/2013/TT-BLĐTBXH
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/43821
  label: thay_the
- so_hieu: 11/2013/TT-BLĐTBXH
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/43819
  label: thay_the
---

# Thông tư 09/2020/TT-BLĐTBXH — Thông tư số 09/2020/TT-BLĐTBXH Quy định chi tiết và hướng dẫn thi hành một số điều của Bộ luật Lao động về lao động chưa thành niên

## Điều 1. Phạm vi điều chỉnh     ^dieu-1
Thông tư này quy định chi tiết và hướng dẫn thi hành một số điều, khoản sau đây của Bộ luật Lao động về lao động chưa thành niên:
1. Sử dụng người chưa đủ 15 tuổi làm việc theo quy định tại khoản 4 Điều 145.
2. Danh mục công việc nhẹ người từ đủ 13 tuổi đến chưa đủ 15 tuổi được làm theo quy định tại khoản 3 Điều 143.
3. Danh mục nghề, công việc người từ đủ 15 tuổi đến chưa đủ 18 tuổi có thể được làm thêm giờ, làm việc vào ban đêm theo quy định tại khoản 2 Điều 146.
4. Danh mục công việc, nơi làm việc gây tổn hại đến sự phát triển thể lực, trí lực, nhân cách của người chưa thành niên theo quy định khoản 3 Điều 147.

> [!history] Lịch sử Điều 1
> Sửa đổi bởi [[TT-08-2023-BLĐTBXH#^dieu-1]] (số hiệu 08/2023/TT-BLĐTBXH).

## Điều 2. Đối tượng áp dụng     ^dieu-2
1. Người sử dụng lao động.
2. Người lao động chưa thành niên.
3. Cơ quan, tổ chức, cá nhân khác có liên quan đến việc thực hiện quy định tại Thông tư này.

> [!history] Lịch sử Điều 2
> Sửa đổi bởi [[TT-08-2023-BLĐTBXH#^dieu-2]] (số hiệu 08/2023/TT-BLĐTBXH).

## Điều 3. Điều kiện sử dụng người chưa đủ 15 tuổi làm việc     ^dieu-3
Người sử dụng lao động phải tuân thủ Điều 145 của Bộ luật Lao động khi sử dụng người chưa đủ 15 tuổi làm việc, với các quy định cụ thể sau:
1. Giao kết hợp đồng lao động bằng văn bản với người chưa đủ 15 tuổi và người đại diện theo pháp luật của người đó theo quy định tại Điều 4 của Thông tư này.
2. Bố trí thời giờ làm việc của người chưa đủ 15 tuổi theo quy định tại khoản 1 Điều 146 của Bộ luật Lao động. Người chưa đủ 15 tuổi vừa làm việc vừa học tập hoặc có nhu cầu học tập thì việc bố trí thời giờ làm việc phải bảo đảm không ảnh hưởng đến thời gian học tập của người chưa đủ 15 tuổi.
3. Bố trí các đợt nghỉ giải lao cho người chưa đủ 15 tuổi theo quy định tại khoản 2 Điều 109 của Bộ luật Lao động.
4. Tuân thủ quy định về khám sức khỏe, khám phát hiện bệnh nghề nghiệp và bảo đảm điều kiện làm việc, an toàn, vệ sinh lao động quy định tại điểm c và điểm d khoản 1 Điều 145 của Bộ luật Lao động và Luật An toàn, vệ sinh lao động.
5. Chỉ được tuyển dụng và sử dụng người từ đủ 13 tuổi đến chưa đủ 15 tuổi vào làm công việc nhẹ khi công việc đó đáp ứng các điều kiện sau:
a) Là công việc có trong danh mục quy định tại Điều 8 của Thông tư này;
b) Nơi làm việc không thuộc các trường hợp quy định tại các điểm a, b, c, d khoản 2 Điều 147 của Bộ luật Lao động và khoản 2 Điều 9 của Thông tư này.
6. Không được tuyển dụng và sử dụng người chưa đủ 13 tuổi làm việc, trừ các công việc nghệ thuật, thể dục, thể thao nhưng không làm tổn hại đến sự phát triển thể lực, trí lực, nhân cách của người chưa đủ 13 tuổi và phải có sự đồng ý của Sở Lao động - Thương binh và Xã hội theo quy định tại Điều 5 của Thông tư này.

> [!history] Lịch sử Điều 3
> Sửa đổi bởi [[TT-08-2023-BLĐTBXH#^dieu-3]] (số hiệu 08/2023/TT-BLĐTBXH).

## Điều 4. Giao kết hợp đồng lao động để sử dụng người chưa đủ 15 tuổi làm việc     ^dieu-4
1. Người giao kết hợp đồng lao động bên phía người sử dụng lao động thực hiện theo quy định tại khoản 3 Điều 18 của Bộ luật Lao động và đáp ứng các điều kiện sau:
a) Có phiếu lý lịch tư pháp được cấp không quá 06 tháng kể từ ngày cấp đến ngày giao kết hợp đồng lao động, trong đó không có án tích về hành vi xâm hại trẻ em;
b) Có Bản cam kết chưa từng bị truy cứu trách nhiệm hình sự, xử phạt vi phạm hành chính về hành vi xâm hại trẻ em theo Mẫu số 02 tại Phụ lục I ban hành kèm theo Thông tư này.
2. Hợp đồng lao động với người chưa đủ 15 tuổi phải có các nội dung theo quy định tại Điều 21 của Bộ luật Lao động và các nội dung sau:
a) Họ và tên; ngày, tháng, năm sinh; giới tính; nơi cư trú; số điện thoại (nếu có); số thẻ căn cước công dân hoặc chứng minh nhân dân hoặc hộ chiếu của người đại diện theo pháp luật của người chưa đủ 15 tuổi;
b) Chỗ ở đối với người chưa đủ 15 tuổi làm việc xa gia đình;
c) Việc bảo đảm điều kiện học tập.
3. Hợp đồng lao động đối với người chưa đủ 13 tuổi chỉ có hiệu lực sau khi có văn bản đồng ý của Sở Lao động - Thương binh và Xã hội quy định tại Điều 5 của Thông tư này.

> [!history] Lịch sử Điều 4
> Sửa đổi bởi [[TT-08-2023-BLĐTBXH#^dieu-4]] (số hiệu 08/2023/TT-BLĐTBXH).

## Điều 5. Thẩm quyền đồng ý việc sử dụng người chưa đủ 13 tuổi làm việc     ^dieu-5
Khi tuyển dụng, sử dụng người chưa đủ 13 tuổi làm việc theo quy định tại khoản 3 Điều 145 của Bộ luật Lao động, người sử dụng lao động phải có sự đồng ý của cơ quan sau:
1. Sở Lao động - Thương binh và Xã hội nơi đặt trụ sở chính hoặc nơi có địa chỉ được ghi trong giấy chứng nhận đăng ký doanh nghiệp, hợp tác xã, liên hiệp hợp tác xã hoặc giấy chứng nhận đăng ký đầu tư hoặc văn bản chấp thuận chủ trương đầu tư hoặc quyết định thành lập cơ quan, tổ chức hoặc hợp đồng hợp tác của tổ hợp tác, trong trường hợp người sử dụng lao động là doanh nghiệp, cơ quan, tổ chức, hợp tác xã.
2. Sở Lao động - Thương binh và Xã hội nơi đăng ký hộ khẩu thường trú hoặc tạm trú của hộ gia đình, cá nhân, trong trường hợp người sử dụng lao động là hộ gia đình hoặc cá nhân.

> [!history] Lịch sử Điều 5
> Sửa đổi bởi [[TT-08-2023-BLĐTBXH#^dieu-5]] (số hiệu 08/2023/TT-BLĐTBXH).

## Điều 6. Hồ sơ đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc     ^dieu-6
Hồ sơ đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc gồm có:
1. Văn bản đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc theo Mẫu số 01 tại Phụ lục I ban hành kèm theo Thông tư này.
2. Bản sao giấy chứng nhận đăng ký doanh nghiệp, hợp tác xã, liên hợp tác xã hoặc giấy chứng nhận đăng ký đầu tư hoặc văn bản chấp thuận chủ trương đầu tư hoặc quyết định thành lập cơ quan, tổ chức hoặc hợp đồng hợp tác của tổ hợp tác, trong trường hợp người sử dụng lao động là doanh nghiệp, cơ quan, tổ chức, hợp tác xã. Bản sao sổ hộ khẩu hoặc giấy tạm trú trong trường hợp người sử dụng lao động là hộ gia đình hoặc cá nhân.
3. Bản sao phiếu lý lịch tư pháp của người giao kết hợp đồng lao động bên phía người sử dụng lao động theo quy định tại điểm a khoản 1 Điều 4 của Thông tư này.
4. Bản cam kết chưa từng bị truy cứu trách nhiệm hình sự, xử phạt vi phạm hành chính về hành vi xâm hại trẻ em theo quy định tại điểm b khoản 1 Điều 4 của Thông tư này.
5. Hợp đồng lao động hoặc dự thảo hợp đồng lao động giữa người sử dụng lao động với người chưa đủ 13 tuổi và người đại diện theo pháp luật của người đó. Trong trường hợp dự thảo hợp đồng lao động thì phải có Phiếu đồng ý của người đại diện theo pháp luật của người chưa đủ 13 tuổi làm việc theo Mẫu số 03 tại Phụ lục I ban hành kèm theo Thông tư này.
6. Bản sao giấy khai sinh, giấy khám sức khỏe của người chưa đủ 13 tuổi. Thời khóa biểu hoặc chương trình học tập của cơ sở giáo dục nơi người chưa đủ 13 tuổi đang học tập nếu đang đi học.

## Điều 7. Trình tự, thủ tục đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc     ^dieu-7
1. Khi có nhu cầu sử dụng người chưa đủ 13 tuổi làm việc, người sử dụng lao động gửi trực tiếp hoặc qua đường bưu điện hoặc trực tuyến 01 bộ hồ sơ đối với từng người chưa đủ 13 tuổi làm việc quy định tại Điều 6 của Thông tư này đến Sở Lao động - Thương binh và Xã hội quy định tại Điều 5 của Thông tư này.
2. Sở Lao động - Thương binh và Xã hội tiếp nhận hồ sơ đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc khi có đủ các thành phần hồ sơ quy định tại Điều 6 của Thông tư này.
3. Trong thời hạn 10 ngày làm việc kể từ ngày nhận đủ hồ sơ theo quy định tại khoản 2 Điều này, Sở Lao động - Thương binh và Xã hội phối hợp với các cơ quan, tổ chức có liên quan tiến hành xác minh thông tin (nếu cần), thẩm định hồ sơ và trả lời bằng văn bản cho người sử dụng lao động việc đồng ý sử dụng người chưa đủ 13 tuổi làm việc theo Mẫu số 04 tại Phụ lục I ban hành kèm theo Thông tư này. Trường hợp không đồng ý việc sử dụng người chưa đủ 13 tuổi làm việc, Sở Lao động - Thương binh và Xã hội phải có văn bản trả lời nêu rõ lý do, gửi người sử dụng lao động.

## Điều 8. Danh mục công việc nhẹ người từ đủ 13 tuổi đến chưa đủ 15 tuổi được làm     ^dieu-8
Ban hành kèm theo Thông tư này Phụ lục II - Danh mục công việc nhẹ người từ đủ 13 tuổi đến chưa đủ 15 tuổi được làm.

## Điều 9. Danh mục công việc, nơi làm việc gây tổn hại đến sự phát triển thể lực, trí lực, nhân cách của người chưa thành niên     ^dieu-9
1. Ban hành kèm theo Thông tư này Phụ lục III - Danh mục công việc gây tổn hại đến sự phát triển thể lực, trí lực, nhân cách của người chưa thành niên theo quy định tại điểm h khoản 1 Điều 147 của Bộ luật Lao động.
2. Ban hành kèm theo Thông tư này Phụ lục IV - Danh mục nơi làm việc gây tổn hại đến sự phát triển thể lực, trí lực, nhân cách của người chưa thành niên theo quy định tại điểm đ khoản 2 Điều 147 của Bộ luật Lao động.

## Điều 10. Danh mục nghề, công việc người từ đủ 15 tuổi đến chưa đủ 18 tuổi có thể được làm thêm giờ, làm việc vào ban đêm     ^dieu-10
Ban hành kèm theo Thông tư này Phụ lục V - Danh mục nghề, công việc người từ đủ 15 tuổi đến chưa đủ 18 tuổi có thể được làm thêm giờ, làm việc vào ban đêm.

## Điều 11. Trách nhiệm của Sở Lao động - Thương binh và Xã hội     ^dieu-11
1. Chủ trì, phối hợp với cơ quan chuyên môn thuộc Ủy ban nhân dân tỉnh, thành phố trực thuộc trung ương về y tế, văn hóa, thể thao và du lịch, giáo dục và các cơ quan, tổ chức liên quan thường xuyên đôn đốc, giám sát việc thực hiện Thông tư này.
2. Hướng dẫn, kiểm tra, thanh tra việc sử dụng lao động chưa thành niên làm việc trên địa bàn.
3. Tổ chức đào tạo, bồi dưỡng, nâng cao năng lực chuyên môn, nghiệp vụ về quản lý, kiểm tra, thanh tra việc sử dụng lao động chưa thành niên.
4. Ứng dụng công nghệ thông tin trong quản lý việc sử dụng lao động chưa thành niên.
5. Trước ngày 25 tháng 12 hằng năm, báo cáo Bộ Lao động - Thương binh và Xã hội về tình hình đồng ý sử dụng người chưa đủ 13 tuổi làm việc trên địa bàn theo Mẫu số 05 tại Phụ lục I ban hành kèm theo Thông tư này.

## Điều 12. Trách nhiệm của người sử dụng lao động     ^dieu-12
1. Lập Sổ theo dõi tình hình sử dụng lao động chưa thành niên theo Mẫu số 06 tại Phụ lục I ban hành kèm theo Thông tư này và thường xuyên cập nhật thông tin vào Sổ theo dõi.
2. Tôn trọng, lấy ý kiến của người chưa thành niên về những vấn đề có liên quan đến quyền và lợi ích của họ.
3. Thường xuyên kiểm tra, giám sát bảo đảm an toàn cho người chưa thành niên tại nơi làm việc.
4. Trong trường hợp sức khỏe người chưa thanh niên không còn phù hợp với công việc thì phải thông báo cho người chưa thành niên, đối với trường hợp người chưa đủ 15 tuổi thì đồng thời phải thông báo cho người đại diện theo pháp luật của người đó.
5. Thực hiện đầy đủ các quy định của pháp luật hiện hành về bảo vệ trẻ em.

## Điều 13. Hiệu lực thi hành     ^dieu-13
1. Thông tư này có hiệu lực thi hành kể từ ngày 15 tháng 3 năm 2021.
2. Kể từ ngày Thông tư này có hiệu lực thi hành, các Thông tư sau hết hiệu lực thi hành:
a) Thông tư số 10/2013/TT-BLĐTBXH ngày 10 tháng 6 năm 2013 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội ban hành Danh mục các công việc và nơi làm việc cấm sử dụng lao động là người chưa thành niên;
b) Thông tư số 11/2013/TT-BLĐTBXH ngày 11 tháng 6 năm 2013 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội ban hành Danh mục công việc nhẹ được sử dụng người dưới 15 tuổi làm việc./.
Nơi nhận:
- Thủ tướng và các Phó Thủ tướng Chính phủ;
- Văn phòng Trung ương Đảng và các Ban của Đảng;
- Văn phòng Quốc hội,
- Văn phòng Chủ tịch nước;
- Văn phòng Chính phủ;
- Các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ;
- HĐND, UBND tỉnh, thành phố trực thuộc TW;
- Tòa án nhân dân tối cao;
- Viện Kiểm sát nhân dân tối cao;
- Kiểm toán Nhà nước;
- Cơ quan Trung ương các đoàn thể và các Hội;
- Cục Kiểm tra văn bản QPPL (Bộ Tư pháp);
- Sở LĐTBXH các tỉnh, thành phố trực thuộc Trung ương
- Công báo;
- Cổng thông tin điện tử Chính phủ;
- Cổng thông tin điện tử Bộ LĐTBXH;
- Lưu: Văn thư, Cục TE, Cục ATLĐ (30 bản).
BỘ TRƯỞNG
(Đã ký)
Đào Ngọc Dung
Phụ lục I
(Ban hành kèm theo Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 Bộ trưởng Bộ Lao động - Thương binh và Xã hội)
_______________
Mẫu số 01
Văn bản đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc
Mẫu số 02
Bản cam kết chưa từng bị truy cứu trách nhiệm hình sự, xử phạt vi phạm hành chính về hành vi xâm hại trẻ em
Mẫu số 03
Phiếu đồng ý của người đại diện theo pháp luật của người chưa đủ 13 tuổi làm việc
Mẫu số 04
Văn bản đồng ý việc sử dụng người chưa đủ 13 tuổi làm việc
Mẫu số 05
Báo cáo tình hình đồng ý sử dụng người chưa đủ 13 tuổi làm việc
Mẫu số 06
Sổ theo dõi tình hình sử dụng lao động chưa thành niên
Mẫu số 01. Văn bản đề nghị việc sử dụng người chưa đủ 13 tuổi làm việc
____________________________________
(Tên doanh nghiệp/ Cơ quan/tổ chức/hợp tác xã/hộ gia đình/cá nhân)
_______
Số: ….
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
____________________
... , ngày...tháng...năm...
VĂN BẢN ĐỀ NGHỊ VIỆC SỬ DỤNG NGƯỜI CHƯA ĐỦ 13 TUỔI LÀM VIỆC
Kính gửi: Sở Lao động - Thương binh và Xã hội tỉnh, thành phố....
Căn cứ Bộ luật Lao động năm 2019;
Căn cứ Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội quy định chi tiết và hướng dẫn thi hành một số điều của Bộ luật Lao động về lao động chưa thành niên;
(Tên doanh nghiệp, cơ quan, tổ chức, hợp tác xã; hộ gia đình, cá nhân sử dụng lao động) ... đề nghị Sở Lao động - Thương binh và Xã hội tỉnh, thành phố.... về việc sử dụng người chưa đủ 13 tuổi làm việc, với các nội dung sau:
Phần I. Thông tin về doanh nghiệp/ hộ gia đình, cá nhân
1. Tên doanh nghiệp, cơ quan, tổ chức, hợp tác xã, hộ gia đình, cá nhân (ghi bằng chữ in hoa): …………………..
2. Địa chỉ trụ sở chính của doanh nghiệp, cơ quan, tổ chức, hợp tác xã/ Địa chỉ thường trú/tạm trú của hộ gia đình, cá nhân: ………………..
3. Điện thoại: ..... Fax:...................................... Email:..........................
4. Người đại diện theo pháp luật ký hợp đồng lao động:
Họ và tên:..........................................................................................................................
Chức vụ/Chức danh: .........................................................................................................
Ngày, tháng, năm sinh: .......................................................... Giới tính: .............................
Quốc tịch:..........................................................................................................................
Số chứng minh thư nhân dân (CMND)/Hộ chiếu/căn cước công dân (CCCD): .... ; cấp ngày: ..... tại:
Nơi đăng ký hộ khẩu thường trú: .......................................................................................
Điện thoại:.................................................................. Email:.............................................
Phần II. Tóm tắt thông tin về người chưa đủ 13 tuổi làm việc và nội dung cơ bản của Hợp đồng lao động với người chưa đủ 13 tuổi
1. Người chưa đủ 13 tuổi
Họ và tên:......................................................................................................
Ngày, tháng, năm sinh:.......................................................................................................
Nơi đăng ký hộ khẩu thường trú:........................................................................................
Địa chỉ nơi cư trú:...............................................................................................................
Tình trạng đi học (nếu có): Là học sinh lớp.... Trường..........................................................
Điện thoại (nếu có):............................................................................................................
Số định danh cá nhân/Số hộ chiếu (nếu có): ................ Cấp ngày ..... tại.......
2. Người đại diện của người chưa đủ 13 tuổi
Họ và tên:.............................................................................................................
Mối quan hệ với người chưa đủ 13 tuổi: .............................................................................
Nơi đăng ký hộ khẩu thường trú: .......................................................................................
Địa chỉ nơi cư trú: ..............................................................................................................
Điện thoại: ..................................................................... Email (nếu có)...........................
Số CMND/ Số hộ chiếu/CCCD: ................................................ Cấp ngày ..... tại......
3. Nội dung cơ bản của Hợp đồng lao động với người chưa đủ 13 tuổi (Ghi cụ thể: Công việc; nơi làm việc; thời hạn của Hợp đồng lao động; mức lương; thời giờ làm việc, thời giờ nghỉ ngơi; trang bị bảo hộ lao động cho người chưa đủ 13 tuổi; chỗ ở cho người chưa đủ 13 tuổi Làm việc xa gia đình; việc đảm bảo điều kiện học tập):
Phần III. Hồ sơ kèm theo
1. .....................................................................................................................................
2. .....................................................................................................................................
3. .....................................................................................................................................
Nơi nhận:
- Như trên;
- .....
NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT CỦA DOANH NGHIỆP/CƠ QUAN/ TỔ CHỨC/HỢP TÁC XÃ/ HỘ GIA ĐÌNH/CÁ NHÂN
(Ký, ghi rõ họ tên, chức danh và đóng dấu (nếu có))
Mẫu số 02. Bản cam kết chưa từng bị truy cứu trách nhiệm hình sự, xử phạt vi phạm hành chính về hành vi xâm hại trẻ em
_________________
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
________________________
…, ngày tháng năm
CAM KẾT CHƯA TỪNG BỊ TRUY CỨU TRÁCH NHIỆM HÌNH SỰ, XỬ PHẠT VI PHẠM HÀNH CHÍNH VỀ HÀNH VI XÂM HẠI TRẺ EM
(Dành cho người giao kết hợp đồng lao động bên phía người sử dụng lao động)
Tên tôi là:...........................................................................................................................
Giới tính: ...........................................................................................................................
Quốc tịch................................................................ Sinh... ngày:.......................................
Số CMND/Hộ chiếu/CCCD............................................................ Cấp... ngày .... tại...........
Nơi đăng ký hộ khẩu thường trú: .......................................................................................
Địa chỉ nơi cư trú:...............................................................................................................
Điện thoại: .................................................................. E-mail: ..........................................
Chức vụ/Chức danh: .........................................................................................................
Tôi cam kết chưa từng bị truy cứu trách nhiệm hình sự, xử phạt vi phạm hành chính về hành vi xâm hại trẻ em./.
NGƯỜI CAM KẾT
(Ký, ghi rõ họ tên)
Mẫu số 03. Phiếu đồng ý của người đại diện theo pháp luật của người chưa đủ 13 tuổi làm việc
________________
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
_________________________
PHIẾU ĐỒNG Ý CỦA NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT CỦA NGƯỜI CHƯA ĐỦ 13 TUỔI LÀM VIỆC
Họ và tên:..........................................................................................................................
Mối quan hệ với người chưa đủ 13 tuổi: .............................................................................
Nơi đăng ký hộ khẩu thường trú: .......................................................................................
Địa chỉ nơi cư trú: ..............................................................................................................
Điện thoại: ............................................ Email (nếu có)......................................................
Số CMND/ Số hộ chiếu/CCCD: ........................................... cấp ngày.............. tại..............
Đồng ý cho: ……… (ghi rõ họ và tên của người chưa đủ 13 tuổi làm việc) ký hợp đồng lao động với:
Ông/bà ........................................................................................................ (ghi... rõ họ và tên), chức vụ/chức danh:........................................................................................... , đại diện cho: ………..
Địa chỉ đăng ký kinh doanh: ...............................................................................................
Với các nội dung dự thảo của hợp đồng lao động với người chưa đủ 13 tuổi.
- …..
- …..
- …..
Người đại diện theo pháp luật
(Ký, ghi rõ họ và tên)
Mẫu số 04. Văn bản đồng ý việc sử dụng người chưa đủ 13 tuổi làm việc
____________________
ỦY BAN NHÂN DÂN TỈNH/ THÀNH PHỐ
SỞ LAO Đ ỘNG - THƯƠNG BINH VÀ XÃ HỘI
_________
Số: ...
V/v Sử dụng người chưa đủ 13 tuổi làm việc
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
_______________________
… , ngày...tháng...năm...
Kính gửi:......... (1) ..........
Căn cứ Bộ luật Lao động ngày 20 tháng 11 năm 2019;
Căn cứ Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 của Bộ Lao động - Thương binh và Xã hội quy định chi tiết và hướng dẫn thi hành một số điều của Bộ luật Lao động về lao động chưa thành niên;
Xét đề nghị của................................... (1) ….. tại văn bản ngày................... ,
Sở Lao động - Thương binh và Xã hội tỉnh, thành phố......................................... đồng ý việc sử dụng người chưa đủ 13 tuổi làm việc, với các nội dung sau:
1. Người chưa đủ 13 tuổi
Họ và tên:.................................................................................................
Ngày, tháng, năm sinh:.......................................................................................................
Địa chỉ đăng ký hộ khẩu: ...................................................................................................
Địa chỉ nơi cư trú:...............................................................................................................
Tình trạng đi học (nếu có): Là học sinh lớp.... Trường..........................................................
Điện thoại (nếu có): ...........................................................................................................
Số định danh cá nhân/Số hộ chiếu (nếu có): ......... Cấp ngày .....tại .....
2. Người đại diện của người chưa đủ 13 tuổi
Họ và tên: ...................................................................................................... . . . . . . . .
Mối quan hệ với người chưa đủ 13 tuổi: .............................................................................
Nơi đăng ký hộ khẩu thường trú: .......................................................................................
Địa chỉ nơi cư trú: ..............................................................................................................
Điện thoại: ....................................................... Email (nếu có).........................................
Số CMND/ Số hộ chiếu/CCCD: ...................................... Cấp ngày .............. tại..............
3. Thông tin về người sử dụng lao động
a) Tên doanh nghiệp, cơ quan, tổ chức, hợp tác xã, hộ gia đình, cá nhân (ghi bằng chữ in hoa): ……………………….
b) Địa chỉ trụ sở chính của doanh nghiệp, cơ quan, tổ chức, hợp tác xã/ Địa chỉ thường trú/tạm trú của hộ gia đình, cá nhân:
c) Điện thoại:........................................ Fax:............................. Email:................................
d) Người đại diện theo pháp luật ký hợp đồng lao động:
Họ và tên:..........................................................................................................................
Chức vụ/Chức danh: .........................................................................................................
Ngày, tháng, năm sinh: ............................................... Giới tính: .....................................
Quốc tịch:..........................................................................................................................
Số CMND/Hộ chiếu/CCCD:............................... ; cấp ngày:.................. tại:..........................
Nơi đăng ký hộ khẩu thường trú: .......................................................................................
Điện thoại:................................................. Email:...............................................................
4. Nội dung cơ bản của hợp đồng lao động với người chưa đủ 13 tuổi như sau (Ghi cụ thể: Công việc; nơi làm việc; thời hạn của Hợp đồng lao động; mức lương; thời giờ làm việc, thời giờ nghỉ ngơi; trang bị bảo hộ lao động cho người chưa đủ 13 tuổi; chỗ ở cho người chưa đủ 13 tuổi làm việc xa gia đình; việc đảm bảo điều kiện học tập):
- …..
- …..
Nơi nhận:
- Như trên;
- ....
GIÁM ĐỐC
(Ký, ghi rõ họ tên và đóng dấu)
_______________
Ghi chú:
(1) Tên doanh nghiệp, cơ quan, tổ chức, hợp tác xã, hộ gia đình, cá nhân
Mẫu số 05. Báo cáo tình hình đồng ý sử dụng người chưa đủ 13 tuổi làm việc
_______________
ỦY BAN NHÂN DÂN TỈNH/ THÀNH PHỐ
SỞ LAO Đ ỘNG - THƯƠNG BINH VÀ XÃ HỘI
_________
Số: ...
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
_______________________
… , ngày...tháng...năm...
BÁO CÁO
Tình hình đồng ý sử dụng người chưa đủ 13 tuổi làm việc
(Thời gian: Từ ngày.................. tháng......... năm......... đến ngày.......... tháng........ năm....)
Kính gửi: Bộ Lao động - Thương binh và Xã hội
STT
Người sử dụng lao động
Tổng số người chưa đủ 13 tuổi
Loại hợp đồng lao động
Ghi chú
Nam
Nữ
Không xác định thời hạn
Xác định thời hạn
Dưới 01 tháng
Trên 01 tháng
1
Doanh nghiệp
2
Cơ quan, tổ chức
3
Hợp tác xã
5
Hộ gia đình, cá nhân
GIÁM ĐỐC
(Ký, ghi rõ họ tên và đóng dấu)
Mẫu số 06. Sổ theo dõi tình hình sử dụng lao động chưa thành niên
__________________
Tên doanh nghiệp/ cơ quan/ tổ chức/ hợp tác xã/ hộ gia đình/ cá nhân sử dụng lao động
Địa chỉ:...........................................
SỔ THEO DÕI TÌNH HÌNH SỬ DỤNG LAO ĐỘNG CHƯA THÀNH NIÊN
Trang 1,......... ,n
STT
Người chưa thành niên
Người đại diện theo pháp luật
Họ và tên
Giới tính
Ngày tháng năm sinh
Quốc tịch
Địa chỉ thường trú/tạm trú
Số thẻ căn cước công dân hoặc CMTND hoặc số định danh cá nhân hoặc số hộ chiếu (nếu có)
Tình trạng đi học 1
Hình thức Hợp đồng lao động 2
Công việc đang làm
Kết quả kiểm tra sức khỏe định kỳ 3
Họ và
tên
Quốc tịch
Địa chỉ thường trú hoặc tạm trú
Nghề nghiệp
Số điện thoại (nếu có)
(1)
(2)
(3)
(4)
(5)
(6)
(7)
(8)
(9)
(10)
(11)
(12)
(13)
(14)
(15)
1
2
________________________
Ghi chú :
1 Nếu đang đi học: ghi là học lớp mấy; nếu không còn đi học ghi: Thôi học (trình độ văn hóa cao nhất), ví dụ: Thôi học (Lớp 3).
2 Ghi theo quy định tại Điều 14 Bộ luật Lao động.
3 Về kết quả khám sức khỏe định kỳ: Ghi kết quả phân loại sức khỏe; tóm tắt tình trạng bệnh tật (nếu có).
Phụ lục II
DANH MỤC CÔNG VIỆC NHẸ NGƯỜI TỪ ĐỦ 13 TUỔI ĐẾN CHƯA ĐỦ 15 TUỔI ĐƯỢC LÀM
(Ban hành kèm theo Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội)
1. Biểu diễn nghệ thuật.
2. Vận động viên thể thao.
3. Lập trình phần mềm.
4. Các nghề truyền thống: chấm men gốm; cưa vỏ trai; làm giấy dó; làm nón lá; chấm nón; dệt chiếu; làm trống; dệt thổ cẩm; thêu thổ cẩm; làm bún gạo; làm miến; làm giá đỗ; làm bánh đa; dệt tơ tằm; se sợi hoa sen; vẽ tranh sơn mài, se nhang, làm vàng mã (trừ các công đoạn có sử dụng hóa chất độc hại như sơn ta, hóa chất tẩy rửa, hóa chất dùng để ướp màu, hóa chất tạo mùi, tạo tàn nhang cong...).
5. Các nghề thủ công mỹ nghệ: thêu ren; mộc mỹ nghệ; làm lược sừng; làm tranh dân gian (tranh Đông Hồ, tranh Hàng Trống….); nặn tò he; làm tranh khắc gỗ, biểu tranh lụa; nhặt vỏ sò, điệp để gắn trên tranh mỹ nghệ; mài đánh bóng tranh mỹ nghệ; xâu chuỗi tràng hạt kết cườm, đánh bóng trang sức mỹ nghệ; làm rối búp bê; làm thiếp mừng các sản phẩm từ giấy nghệ thuật trang trí trên thiếp mừng; làm khung tranh mô hình giấy, hộp giấy, túi giấy.
6. Đan lát, làm các đồ gia dụng, đồ thủ công mỹ nghệ từ nguyên liệu tự nhiên như: mây, tre, nứa, dừa, chuối, bèo lục bình, đay, cói, quế, guột, đót, lá nón.
7. Gói nem, gói kẹo, gói bánh (trừ việc vận hành hoặc sử dụng các máy, thiết bị, dụng cụ đóng gói).
8. Nuôi tằm.
9. Làm cỏ vườn rau sạch; thu hoạch rau, củ, quả sạch theo mùa.
10. Chăn thả gia súc tại nông trại.
11. Phụ gỡ lưới cá, đan lưới cá, phơi khô thủy sản.
12. Cắt chỉ, đơm nút, thùa khuyết, đóng gói vào hộp các sản phẩm dệt thủ công.
Phụ lục III
DANH MỤC CÔNG VIỆC GÂY TỔN HẠI ĐẾN SỰ PHÁT TRIỂN THỂ LỰC, TRÍ LỰC, NHÂN CÁCH CỦA NGƯỜI CHƯA THÀNH NIÊN THEO QUY ĐỊNH TẠI ĐIỂM H KHOẢN 1 ĐIỀU 147 CỦA BỘ LUẬT LAO ĐỘNG
(Ban hành kèm theo Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội)
1. Trực tiếp luyện quặng kim loại màu (đồng, chì, thiếc, thuỷ ngân, kẽm, bạc).
2. Đốt và ra lò luyện cốc.
3. Đốt lò đầu máy hơi nước.
4. Vận hành nồi hơi đốt nhiên liệu (than đá, bã mía, củi, mùn cưa, trấu) và nồi hơi sử dụng nhiên liệu lỏng và có khí áp suất làm việc từ 4,0 bar trở lên, công suất trên 0,5 T/h).
5. Vận hành hệ thống điều chế và nạp axetylen, oxy, hydro, clo và các khí hoá lỏng, các trạm khí nén có áp suất 8,0 bar.
6. Vận hành hệ thống lạnh (làm nước đá, đông lạnh).
7. Lắp đặt khuôn máy rèn, dập, ép, cắt kim loại (không phân biệt máy hơi nước, khí nén, điện hoặc cơ).
8. Thu gom bã thải sản xuất cồn công nghiệp.
9. Vận hành máy hồ vải sợi.
10. Nhuộm, hấp, vải sợi.
11. Chủ nhiệm kho, thủ kho, phụ kho kho hóa chất, thuốc nhuộm.
12. Khai thác đá, đập đá thủ công, cậy bẩy đá trên núi.
13. Trực tiếp đưa vật liệu vào máy nghiền đá và làm việc với máy nghiền đá.
14. Tuyển quặng chì.
15. Sử dụng các loại máy cầm tay chạy bằng hơi ép có sức ép từ 4 atmotphe trở lên (như máy khoan, máy búa và các máy tương tự gây những chấn động không bình thường cho thân thể người).
16. Đãi, tuyển vàng, quặng, đá đỏ.
17. Trực tiếp đào gốc cây có đường kính lớn hơn 40cm bằng phương pháp thủ công.
18. Cưa xẻ gỗ 2 người kéo bằng phương pháp thủ công.
19. Đốn hạ những cây có đường kính từ 35cm trở lên, cưa cắt cành, tỉa cành trên cao bằng phương pháp thủ công.
20. Vận xuất gỗ lớn, xeo bắn, bốc xếp gỗ có đường kính từ 35cm trở lên bằng thủ công, bằng máng gỗ, bằng cầu trượt gỗ.
21. Mò vớt gỗ chìm, cánh kéo gỗ trong âu, triền đưa gỗ lên bờ.
22. Xuôi bè mảng trên sông có nhiều ghềnh thác.
23. Lái máy kéo nông nghiệp.
24. Các công việc khai thác phân dơi; khai thác tổ yến tự nhiên ngoài đảo.
25. Xẻ gỗ bằng máy cưa đĩa và máy cưa vòng.
26. Vận hành các máy bào trong nghề gỗ (trừ máy cầm tay).
27. Trực tiếp nuôi, huấn luyện thú dữ hoặc động vật có nọc độc.
28. Sơ chế tre, nứa, mây và cói, nếu có sử dụng hóa chất độc hại.
29. Đốt lò nung gạch chịu lửa, lò vôi, tôi vôi bằng phương pháp thủ công.
30. Công việc phải làm một mình trên đường sắt, hoặc ở nơi tầm nhìn của người công nhân không vượt quá 400m.
31. Công việc di chuyển, nối hoặc tách toa xe trong xưởng máy, trên đường sắt.
32. Điều khiển các phương tiện giao thông vận tải có động cơ có dung tích xi lanh từ 50 cm 3 trở lên.
33. Móc buộc tải trọng cho cầu trục, cần trục, cổng trục, palăng điện.
34. Khảo sát đường sông.
35. Các công việc trên tàu đi biển, trừ trường hợp đủ 16 tuổi trở lên.
36. Lắp đặt giàn khoan.
37. Làm việc ở giàn khoan trên biển.
38. Công việc gác tàu, trông tàu trong âu, triền đà.
39. Khoan thăm dò giếng dầu và khí.
40. Khoan thăm dò, khoan nổ mìn, bắn mìn.
41. Cán ép tấm da lớn, cứng.
42. Tráng paraphin trong bể rượu.
43. Lưu hoá, hình thành, bốc dỡ sản phẩm cao su cỡ lớn như: thùng, két nhiên liệu, lốp ô tô.
44. Công việc tiếp xúc với xăng, dầu trong hang, hầm: giao nhận, bảo quản, vận hành máy bơm và đo xăng, dầu.
45. Đốt lò sinh khí nấu thuỷ tinh, thổi thuỷ tinh bằng miệng.
46. Châm lửa cho máy đốt dầu tiêu thụ từ 400 1/h.
47. Các công việc đóng mới và sửa chữa phương tiện thủy phải mang vác, gá đặt vật gia công có trọng lượng từ 20kg trở lên.
48. Vận hành lò đốt rác và xử lý nước thải.
49. Nấu, tẩy rửa bột giấy bằng clo.
50. Lắp đặt sửa chữa đường dây điện trong cống ngầm hoặc trên cột ngoài trời, đường dây điện cao thế, lắp dựng cột điện cao thế.
51. Lắp đặt, sửa chữa cáp ngầm, cáp treo của đường dây điện thông tin.
52. Vận hành, trực các trạm điện hạ áp, trung áp và cao áp.
53. Kiểm tra, sửa chữa và xử lý các mạch điện có điện thế 700 V trong trường hợp dòng điện một chiều; trên 220V trong trường hợp dòng điện xoay chiều và các vật duy trì mạch điện đó.
54. Công việc ở đài phát thanh, phát sóng tần số rađiô như đài phát thanh, phát hình và trạm rađa, trạm vệ tinh viễn thông... bị ảnh hưởng bởi điện từ trường vượt quá tiêu chuẩn cho phép.
55. Sửa chữa lò, thùng, tháp kín, đường ống trong sản xuất hoá chất.
56. Các công việc tiếp xúc dung môi hữu cơ như: ngâm tẩm tà vẹt, trải nhũ tương giấy ảnh, in hoa trên màng mỏng, in nhãn trên giấy láng mỏng, cán ép nhựa phenon, vận hành nồi đa tụ keo phenon.
57. Trực tiếp tiếp xúc với hoá chất gây biến đổi gien:
57.1. Hóa chất: 5 Flioro- uracil;
57.2. Hóa chất: Benzen.
58. Trực tiếp tiếp xúc với các hoá chất, hợp chất gây tác hại sinh sản lâu dài (như gây thiểu năng tinh hoàn, thiểu năng buồng trứng):
58.1. Estrogen;
58.2. Axít cis-retinoic;
58.3. Cacbaryl;
58.4. Dibromuaclo propan(DBCP);
58.5. Toluendiamin và dinitrotoluen;
58.6. Polyclorin biphenyl (PCBs);
58.7. Polybromua biphenyl (PBBs).
59. Trực tiếp tiếp xúc (bao gồm các khâu: sản xuất, đóng gói, pha chế, phun thuốc, khử trùng kho) với các hoá chất trừ sâu, trừ cỏ, diệt mối mọt, diệt chuột, trừ muỗi có chứa Clo hữu cơ và một số hoá chất có khả năng gây ung thư sau đây:
59.1. Hóa chất: 1,4 butanediol, dimetansunfonat;
59.2. Hóa chất: 4 aminnobiphenyl;
59.3. Amiăng loại amosit, amiăng loại crysotil, amiăng loại crosidolit;
59.4. Asen (hay thạch tín), canxi asenat;
59.5. Dioxin;
59.6. Diclorometyl-ete;
59.7. Các loại muối cromat không tan;
59.8. Nhựa than đá, phần bay hơi nhựa than đá;
59.9. Xyclophotphamit;
59.10. Dietylstilboestol;
59.11. Hóa chất: 2, Naphtylamin;
59.12. Hóa chất: N, N - di (Cloroetyl). 2. Naphtylamin;
59.13. Thori dioxyt;
59.14. Theosufan;
59.15. Vinyl clorua, vinyl clorid;
59.16. Hóa chất: 4- amino, 10- metyl flolic axít;
59.17. Thuỷ ngân, hợp chất metyl thủy ngân, metyl thủy ngân clorua;
59.18. Nitơ pentoxyt;
59.19. Hóa chất: 2,3,7,8 tetracloro dibenzen furan;
59.20. Hóa chất: 2- alphaphenyl-beta axetyletyl;
59.21. Axety salixylic axít;
59.22. Asparagin;
59.23. Benomyl;
59.24. Boric axít;
59.25. Cafein;
59.26. Dimetyl sunfoxid;
59.27. Direct blue-1;
59.28. Focmamid;
59.29. Hydrocortison, Hydrocortission axetat;
59.30. Iod (kim loại);
59.31. Chì, chì axetat, chì nitrat (tiếp xúc với xăng sơn, mực in có chứa chì, sản xuất ắc quy, hàn chì);
59.32. Mercapto, purin;
59.33. Kali bromua, kali iodua;
59.34. Propyl- thio- uracil;
59.35. Ribavirin;
59.36. Natri asenat, natri asenit, natri iodua, natri salixylat;
59.37. Tetrametyl thiuram disunfua;
59.38. Trameinnolon axetonid;
59.39. Triton WR-1339;
59.40. Trypan blue;
59.41. Valproic axít;
59.42. Vincristin sunfat;
59.43. Khí dụng Vinazol.
60. Tiếp xúc thường xuyên với các hoá chất sau đây
60.1. Oxyt cacbon (CO): trong vận hành lò tạo khí than, thải xỉ;
60.2. Các loại thuốc nhuộm có gốc anilin, xylizin, toluzin, auramin;
60.3. Các hợp chất có gốc xianua (-CN-);
60.4. Phốt pho và các hợp chất P 2 O 5 , P 2 S 5 , PCl 3 , H 3 P;
60.5. Trinitro toluen (TNT);
60.6. Mangan dioxyt (MnO 2 );
60.7. Photgein (COCl 2 );
60.8. Disunfua cacbon(CS 2 );
60.9. Oxit nitơ và axít nitric;
60.10. Anhydrit sunfuaric và axít sunfuaric;
60.11. Đất đèn (CaC 2 ) như vận hành lò đất đèn dạng hở, thải xỉ.
61. Làm việc trong thùng chìm.
62. Nạo vét cống ngầm, công việc phải ngâm mình thường xuyên dưới nước bẩn hôi thối.
63. Sản xuất photpho vàng.
64. Mổ tử thi, liệm mai táng người chết, bốc mồ mả, các công việc trong nhà xác.
65. Nhặt hoặc phân loại rác thải, chất thải, các chất thải hoặc phế liệu.
66. Công việc tiếp xúc với hơi thuốc gây mê hàng ngày, làm việc ở khoa hồi sức cấp cứu, khoa chống nhiễm khuẩn, kiểm soát nhiễm khuẩn ở khoa lây của các cơ sở y tế, các trung tâm truyền máu, các cơ sở sản xuất vắcxin phòng bệnh, tham gia dập tắt các ổ dịch, làm việc ở khu điều trị bằng sóng ngắn, siêu âm.
67. Lắp dựng, tháo dỡ hoặc thay đổi giàn giáo.
68. Công việc phải mang, vác, nâng các vật nặng vượt quá thể trạng lao động chưa thành niên:
Tuổi của lao động chưa thành niên
Công việc không thường xuyên (kg)
Công việc thường xuyên (kg)
Nam
Nữ
Nam
Nữ
Từ 15 tuổi (180 tháng) đến dưới 16 tuổi (192 tháng)
≥ 15
≥ 12
≥ 10
≥ 8
Từ 16 tuổi (192 tháng) đến dưới 18 tuổi (216 tháng)
≥ 30
≥ 25
≥ 20
≥15
69. Phân loại, tái chế các sản phẩm có chứa than chì.
Phụ lục IV
DANH MỤC NƠI LÀM VIỆC GÂY TỔN HẠI ĐẾN SỰ PHÁT TRIỂN THỂ LỰC, TRÍ LỰC, NHÂN CÁCH CỦA NGƯỜI CHƯA THÀNH NIÊN THEO QUY ĐỊNH TẠI ĐIỂM Đ KHOẢN 2 ĐIỀU 147 CỦA BỘ LUẬT LAO ĐỘNG
(Ban hành kèm theo Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội)
1. Tiếp xúc với các yếu tố nguy hiểm, yếu tố có hại có trong môi trường lao động nằm ngoài giới hạn cho phép theo tiêu chuẩn, quy chuẩn kỹ thuật quốc gia về vệ sinh lao động, bao gồm: điện từ trường, rung, ồn, nhiệt độ, bụi silic, bụi không chứa silic, bụi bông, bụi amiăng, bụi than, bụi tale; các loại chất, tia phóng xạ; bức xạ bởi tia X, các chất độc hại và các tia có hại khác.
2. Tiếp xúc với các vi sinh vật gây bệnh.
3. Thời gian làm việc trên 04 giờ/ngày trong không gian làm việc gò bó, chật hẹp, công việc có khi phải quỳ gối, nằm, cúi khom.
4. Trên giá cao hay dây treo cao hơn 2 m so với mặt sàn làm việc; địa hình đồi núi dốc trên 30 0 .
5. Các công việc ở trong hố sâu hơn 5m.
6. Làm việc trong nhà tù hoặc trong bệnh viện tâm thần.
Phụ lục V
DANH MỤC NGHỀ, CÔNG VIỆC NGƯỜI TỪ ĐỦ 15 TUỔI ĐẾN CHƯA ĐỦ 18 TUỔI CÓ THỂ ĐƯỢC LÀM THÊM GIỜ, LÀM VIỆC VÀO BAN ĐÊM
(Ban hành kèm theo Thông tư số 09/2020/TT-BLĐTBXH ngày 12 tháng 11 năm 2020 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội)
I. Nghề, công việc người từ đủ 15 tuổi đến chưa đủ 18 tuổi có thể được làm thêm giờ
1. Biểu diễn nghệ thuật.
2. Vận động viên thể thao.
3. Viết văn, viết báo.
4. Lập trình phần mềm.
5. Các nghề truyền thống: chấm men gốm; làm giấy dó; làm nón lá; se nhang; chấm nón; dệt chiếu; làm trống; dệt thổ cẩm; thêu thổ cẩm; làm bún gạo; làm miến; làm giá đỗ; làm bánh đa; dệt tơ tằm; se sợi hoa sen.
6. Các nghề thủ công mỹ nghệ: thêu ren; mộc mỹ nghệ; làm lược sừng; làm tranh dân gian (tranh Đông Hồ, tranh Hàng Trống...); nặn tò he; làm tranh khắc gỗ, biểu tranh lụa; nhặt vỏ sò, điệp... để gắn trên tranh mỹ nghệ; xâu chuỗi tràng hạt kết cườm; làm rối búp bê; làm thiếp mừng các sản phẩm từ giấy nghệ thuật trang trí trên thiếp mừng; làm khung tranh mô hình giấy, hộp giấy, túi giấy.
7. Đan lát, làm các đồ gia dụng, đồ thủ công mỹ nghệ từ nguyên liệu tự nhiên như: mây, tre, nứa, dừa, chuối, bèo lục bình, đay, cói, quế, guột, đót, lá nón.
8. Gói nem, gói kẹo, gói bánh (trừ trường hợp vận hành hoặc sử dụng các máy, thiết bị, dụng cụ đóng gói).
9. Cắt chỉ, đơm nút, thùa khuyết, đóng gói vào hộp các sản phẩm dệt thủ công.
10. Đưa tin, thư bưu phẩm, bưu kiện; đóng gói bưu phẩm.
11. Bán hàng tận nhà; bán hàng qua điện thoại; bán hàng trực tuyến.
12. Đánh giày; chế biến, bán hàng thực phẩm trên hè phố.
13. Gia sư; quét dọn, giúp việc trong các gia đình; phụ giúp vệ sinh nhà cửa.
14. Bảo vệ, trông xe các cơ quan, doanh nghiệp, nhà hàng.
15. Thu tiền từ máy bán hàng tự động, ghi số từ các đồng hồ; thu ngân, bán hàng trong siêu thị.
16. Công việc trong nhà hàng, quán ăn, quán cà phê: lễ tân, pha chế đồ uống, phụ bàn, phụ bếp, đầu bếp, tạp vụ.
17. Công việc văn phòng: photo, đánh máy, trực điện thoại.
18. Dịch vụ bán hàng: quần áo, giày dép, sách báo, tạp hóa.
19. Sơ chế nông sản: phân loại, gọt vỏ, bóc vỏ, tách nhân, đóng gói.
20. Làm cỏ vườn rau sạch; thu hoạch rau, củ, quả sạch theo mùa.
21. Nuôi gia súc, gia cầm, nuôi giun, dế, côn trùng không độc hại, nguy hiểm.
II. Nghề, công việc người từ đủ 15 tuổi đến chưa đủ 18 tuổi có thể được làm ban đêm
1. Biểu diễn nghệ thuật.
2. Vận động viên thể thao./.
