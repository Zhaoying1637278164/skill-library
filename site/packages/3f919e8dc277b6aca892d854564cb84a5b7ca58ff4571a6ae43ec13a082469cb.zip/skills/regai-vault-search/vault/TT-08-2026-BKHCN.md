---
so_hieu: 08/2026/TT-BKHCN
loai_van_ban: Thông tư
tier: 4
tieu_de: Thông tư số 08/2026/TT-BKHCN Hướng dẫn việc xác thực thông tin thuê bao di
  động mặt đất
nganh: Khoa học và công nghệ
linh_vuc: Viễn thông
co_quan_ban_hanh: Bộ Khoa học và Công nghệ
organization: Bộ Khoa học và Công nghệ
nguoi_ky: Nguyễn Mạnh Hùng
chuc_danh: Bộ trưởng
ngay_ban_hanh: '2026-03-31'
ngay_co_hieu_luc: '2026-04-15'
ngay_cong_bao: null
ngay_het_hieu_luc: null
tinh_trang: con_hieu_luc
vbpl_guid: d61f4e40-b172-11f1-a5cd-c3f0385b9a30
nguon_url: https://vbpl.vn/van-ban/chi-tiet/x--d61f4e40-b172-11f1-a5cd-c3f0385b9a30
huong_dan_ap_dung:
- 163/2024/NĐ-CP
can_cu_ban_hanh:
- '[[Luat-91-2025]]'
- 163/2024/NĐ-CP
- 24/2023/QH15
- 26/2023/QH15
- 55/2025/NĐ-CP
- 69/2024/NĐ-CP
- 70/2024/NĐ-CP
tham_chieu_ngoai:
- so_hieu: 163/2024/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/173776
  label: can_cu_ban_hanh
- so_hieu: 24/2023/QH15
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/165912
  label: can_cu_ban_hanh
- so_hieu: 26/2023/QH15
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/165958
  label: can_cu_ban_hanh
- so_hieu: 55/2025/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/175587
  label: can_cu_ban_hanh
- so_hieu: 69/2024/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/168331
  label: can_cu_ban_hanh
- so_hieu: 70/2024/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/168344
  label: can_cu_ban_hanh
- so_hieu: 163/2024/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/173776
  label: huong_dan_ap_dung
---

# Thông tư 08/2026/TT-BKHCN — Thông tư số 08/2026/TT-BKHCN Hướng dẫn việc xác thực thông tin thuê bao di động mặt đất

## Điều 1. Phạm   vi   điều   chỉnh     ^dieu-1
Thông tư này hướng dẫn việc xác thực thông tin thuê bao di động mặt đất (sau đây gọi là xác thực thông tin thuê bao) theo quy định tại khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP ngày 24 tháng 12 năm 2024 của Chính phủ quy định chi tiết một số điều và biện pháp thi hành Luật Viễn thông (sau đây gọi là Nghị định số 163/2024/NĐ-CP ).

## Điều 2. Đối   tượng   áp   dụng     ^dieu-2
1. Tổ chức, cá nhân đăng ký, sử dụng số thuê bao viễn thông dùng cho dịch vụ viễn thông di động mặt đất (sau đây gọi là số thuê bao di động).
2. Doanh nghiệp cung cấp dịch vụ viễn thông di động mặt đất (sau đây gọi là doanh nghiệp viễn thông).
3. Cơ quan, tổ chức, doanh nghiệp có liên quan đến hoạt động quản lý, sử dụng, cung cấp dịch vụ viễn thông di động mặt đất và xác thực thông tin thuê bao.

## Điều 3. Nguyên   tắc   thực   hiện     ^dieu-3
1. Doanh nghiệp viễn thông thực hiện việc xác thực thông tin thuê bao trên cơ sở đánh giá, phân loại các số thuê bao di động căn cứ theo giấy tờ mà tổ chức, cá nhân sử dụng để đăng ký thông tin thuê bao di động và theo quy định của pháp luật có liên quan.
2. Doanh nghiệp, tổ chức, cá nhân có liên quan đến thu nhận, xử lý dữ liệu cá nhân khi thực hiện hoạt động xác thực thông tin thuê bao có nghĩa vụ thiết lập và thực hiện đúng, đầy đủ quy trình, cơ chế giám sát khi xử lý, xác thực thông tin thuê bao tuân thủ quy định của pháp luật về bảo vệ dữ liệu cá nhân và quy định của pháp luật về định danh và xác thực điện tử.
3. Doanh nghiệp viễn thông chỉ được cung cấp dịch vụ viễn thông cho số thuê bao di động đăng ký thông tin thuê bao mới kể từ thời điểm Thông tư có hiệu lực sau khi số thuê bao di động đã hoàn thành đăng ký thông tin thuê bao, xác thực thông tin thuê bao theo đúng quy định.
4. Doanh nghiệp viễn thông có trách nhiệm tạm dừng cung cấp dịch vụ chiều đi (gọi điện thoại, gửi tin nhắn SMS đến số thuê bao di động khác) đối với số thuê bao di động có hoạt động thay đổi thiết bị không thực hiện xác thực thông tin hoặc xác thực thông tin không đầy đủ, không chính xác theo quy định tại Điều 8 Thông tư này.

## Điều 4. Phương   thức   xác   thực   thông   tin   thuê   bao     ^dieu-4
1. Việc xác thực thông tin thuê bao đối với số thuê bao di động (bao gồm xác thực 04 trường thông tin: số định danh cá nhân; họ, chữ đệm và tên; ngày, tháng, năm sinh; thông tin sinh trắc học ảnh khuôn mặt) chỉ được thực hiện thông qua một trong các hình thức sau:
a) Trực tuyến thông qua Ứng dụng định danh quốc gia (sau đây gọi tắt là ứng dụng VNeID);
b) Trực tuyến thông qua ứng dụng của chính doanh nghiệp cung cấp dịch vụ viễn thông di động mặt đất sở hữu theo quy định tại khoản 3 Điều 16 Nghị định số 163/2024/NĐ-CP ;
c) Trực tiếp tại điểm do chính doanh nghiệp cung cấp dịch vụ viễn thông di động mặt đất trực tiếp sở hữu, thiết lập theo quy định tại khoản 1 Điều 16 Nghị định số 163/2024/NĐ-CP .
d) Trực tiếp tại điểm có địa chỉ xác định do doanh nghiệp khác thiết lập, được doanh nghiệp cung cấp dịch vụ viễn thông di động mặt đất ký hợp đồng ủy quyền để thực hiện việc đăng ký thông tin thuê bao theo quy định tại khoản 2 Điều 16 Nghị định số 163/2024/NĐ-CP .
2. Doanh nghiệp viễn thông có nghĩa vụ lưu giữ đầy đủ, chính xác các thông tin, tài liệu chứng minh việc đã triển khai các giải pháp xác thực thông tin thuê bao theo đúng quy định trong suốt thời gian số thuê bao di động hoạt động, trừ trường hợp có quy định khác của pháp luật.

## Điều 5. Xác   thực   thông   tin   thuê   bao   đối   với   người   có   quốc   tịch   Việt   Nam đăng ký số thuê bao di động H2H     ^dieu-5
Doanh nghiệp viễn thông có nghĩa vụ thực hiện xác thực thông tin thuê bao thông qua một trong các biện pháp sau:
1. Sử dụng dịch vụ xác thực điện tử để xác thực đối với 04 trường thông tin bao gồm: số định danh cá nhân; họ, chữ đệm và tên; ngày, tháng, năm sinh; dữ liệu sinh trắc học ảnh khuôn mặt của cá nhân đăng ký sử dụng số thuê bao viễn thông hoặc của cá nhân thuộc tổ chức được giao sử dụng SIM thuê bao, bảo đảm trùng khớp với dữ liệu tại Cơ sở dữ liệu quốc gia về dân cư hoặc Cơ sở dữ liệu căn cước. Các số thuê bao di động đã xác thực điện tử được coi là đã hoàn thành việc thực hiện quy định tại điểm a, điểm b, điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP .
2. Thực hiện xác thực đối với 04 trường thông tin bao gồm: số định danh cá nhân; họ, chữ đệm và tên; ngày, tháng, năm sinh; dữ liệu sinh trắc học ảnh khuôn mặt của cá nhân đăng ký sử dụng số thuê bao viễn thông hoặc của cá nhân thuộc tổ chức được giao sử dụng SIM thuê bao, bảo đảm trùng khớp với dữ liệu tại bộ phận lưu trữ thông tin được mã hóa của thẻ căn cước đã được xác thực chính xác là do cơ quan Công an cấp. Các số thuê bao di động đã xác thực, bảo đảm trùng khớp với dữ liệu tại bộ phận lưu trữ thông tin được mã hóa của thẻ căn cước được coi là đã hoàn thành việc thực hiện quy định tại điểm a, điểm b, điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP .
3. Đối với trường hợp sử dụng thẻ căn cước công dân không gắn chíp và không sử dụng được biện pháp quy định tại khoản 1 Điều này để đăng ký thông tin thuê bao, doanh nghiệp viễn thông thực hiện các yêu cầu sau:
a) Xác thực giữa thông tin trên giấy tờ tùy thân, ảnh chụp trực tiếp khuôn mặt của cá nhân đăng ký sử dụng số thuê bao viễn thông hoặc của cá nhân thuộc tổ chức được giao sử dụng SIM thuê bao với thông tin trong Cơ sở dữ liệu quốc gia về dân cư hoặc Cơ sở dữ liệu căn cước, đảm bảo trùng khớp 04 trường thông tin bao gồm: số định danh cá nhân; họ, chữ đệm và tên; ngày, tháng, năm sinh; ảnh khuôn mặt;
b) Áp dụng giải pháp cuộc gọi ghi hình (video call) theo quy định tại điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP ;
c) Khi đăng ký, kích hoạt từ SIM thuê bao di động H2H thứ hai trở đi phải xác thực thông qua mã xác thực một lần (mã OTP) gửi đến SIM đăng ký, kích hoạt trước đó, theo quy định tại điểm b khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP .

## Điều 6. Xác   thực   thông   tin   thuê   bao   đối   với   người   có   quốc   tịch   nước ngoài đăng ký số thuê bao di động H2H     ^dieu-6
Doanh nghiệp viễn thông có nghĩa vụ thực hiện xác thực thông tin thuê bao thông qua một trong các biện pháp sau:
1. Xác thực điện tử đối với 04 trường thông tin bao gồm: số định danh cá nhân; họ, chữ đệm và tên; ngày, tháng, năm sinh; dữ liệu sinh trắc học ảnh khuôn mặt của cá nhân đăng ký sử dụng số thuê bao viễn thông hoặc của cá nhân thuộc tổ chức được giao sử dụng số thuê bao bảo đảm trùng khớp với dữ liệu tại Cơ sở dữ liệu quốc gia về xuất nhập cảnh. Các số thuê bao di động đã xác thực điện tử được coi là đã hoàn thành việc thực hiện quy định tại điểm a, điểm b, điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP .
2. Các biện pháp xác thực khác chỉ được thực hiện theo phương thức quy định tại điểm c, điểm d khoản 1 Điều 4 Thông tư này, đồng thời thực hiện các yêu cầu sau:
a) Đối với người có quốc tịch nước ngoài sử dụng hộ chiếu còn thời hạn sử dụng ở Việt Nam theo thị thực nhập cảnh hoặc theo thời hạn lưu trú tối đa với các nước được miễn thị thực để đăng ký thông tin thuê bao: doanh nghiệp viễn thông phải thực hiện đầy đủ các biện pháp xác thực theo quy định tại điểm b, điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP đối với từng số thuê bao mà cá nhân đăng ký.
b) Đối với người có quốc tịch nước ngoài sử dụng tài khoản định danh điện tử để đăng ký thông tin thuê bao: doanh nghiệp viễn thông thực hiện các biện pháp xác thực theo quy định tại điểm b, điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP .

## Điều 7. Xác thực thông tin thuê bao đối với người gốc Việt Nam chưa   xác định được quốc tịch đăng ký số thuê bao di động H2H     ^dieu-7
1. Việc xác thực thông tin thuê bao của số thuê bao di động H2H với trường hợp người đăng ký hoặc cá nhân thuộc tổ chức được giao sử dụng số thuê bao là người gốc Việt Nam chưa xác định được quốc tịch theo quy định của pháp luật về căn cước chỉ được thực hiện theo phương thức quy định tại điểm c, điểm d khoản 1 Điều 4 Thông tư này.
2. Doanh nghiệp viễn thông thực hiện các biện pháp xác thực theo quy định tại điểm b, điểm c khoản 2 Điều 18 Nghị định số 163/2024/NĐ-CP đối với từng số thuê bao di động mà cá nhân đăng ký.

## Điều 8. Xác thực thông tin đối với thuê bao có hoạt động thay đổi thiết bị đầu cuối     ^dieu-8
Trong thời gian tối đa 02 giờ kể từ thời điểm thuê bao có hoạt động thay đổi thiết bị so với thiết bị đã gắn số thuê bao sử dụng dịch vụ viễn thông trước đó, doanh nghiệp viễn thông có nghĩa vụ triển khai biện pháp rà soát, phát hiện và tạm dừng cung cấp dịch vụ viễn thông chiều đi (gọi điện thoại, gửi tin nhắn SMS đến số thuê bao di động khác), đồng thời thông báo yêu cầu thuê bao thực hiện lại xác thực sinh trắc học ảnh khuôn mặt thông qua một trong các biện pháp sau:
1. Sử dụng dịch vụ xác thực điện tử để xác thực hình ảnh chụp trực tiếp khuôn mặt của thuê bao bảo đảm trùng khớp với dữ liệu trong Cơ sở dữ liệu quốc gia về dân cư hoặc Cơ sở dữ liệu căn cước hoặc Cơ sở dữ liệu quốc gia về xuất nhập cảnh hoặc thực hiện xác thực hình ảnh chụp trực tiếp khuôn mặt của thuê bao bảo đảm trùng khớp với dữ liệu được lưu tại bộ phận lưu trữ thông tin được mã hóa của thẻ căn cước đã được xác thực chính xác là do cơ quan Công an cấp.
2. Đối chiếu, so sánh hình ảnh chụp trực tiếp khuôn mặt của thuê bao bảo đảm trùng khớp với thông tin sinh trắc học đã được lưu giữ hợp pháp tại cơ sở dữ liệu thông tin thuê bao của doanh nghiệp. Doanh nghiệp viễn thông chịu trách nhiệm về tính chính xác và trùng khớp của thông tin sinh trắc học khuôn mặt được xác thực với thông tin sinh trắc học khuôn mặt của thuê bao di động đã hoàn thành xác thực theo quy định tại Điều 5, Điều 6, Điều 7 Thông tư này trước khi có hoạt động thay đổi thiết bị. Việc xác thực thông tin trùng khớp với thông tin sinh trắc học ảnh khuôn mặt phải đáp ứng các yêu cầu sau:
a) Có độ chính xác được xác định theo tiêu chuẩn Việt Nam hoặc tiêu chuẩn quốc tế tương ứng với tiêu chí: Có tỷ lệ từ chối sai < 5% với tỷ lệ chấp nhận sai
<0,01% theo tiêu chuẩn FIDO Biometric Requirement (áp dụng đối với tập mẫu tối thiểu 10.000 mẫu);
b) Có khả năng phát hiện tấn công giả mạo thông tin sinh trắc học của vật thể sống (Presentation Attack Detection - PAD) dựa trên tiêu chuẩn quốc tế (như NIST Special Publication 800-63B Digital Identity Guidelines: Authentication and Lifecycle Management hoặc ISO 30107 - Biometric presentation attack detection hoặc FIDO Biometric Requirements) để phòng, chống gian lận, giả mạo khách hàng qua hình ảnh, video, mặt nạ 3D;
c) Thông tin chứng minh đã xác thực sinh trắc học ảnh khuôn mặt phải thể hiện được thời gian (ngày, giờ) thực hiện xác thực của từng số thuê bao.
3. Với số thuê bao di động H2H, trong vòng 30 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông chiều đi, thuê bao phải hoàn thành thực hiện lại xác thực sinh trắc học ảnh khuôn mặt, sau thời hạn này nếu thuê bao không thực hiện, doanh nghiệp viễn thông có nghĩa vụ tạm dừng cung cấp dịch vụ viễn thông hai chiều đồng thời thông báo thuê bao sẽ bị thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông nếu không thực hiện; thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông sau 05 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông hai chiều nếu cá nhân, tổ chức không thực hiện.

## Điều 9. Hiệu   lực   thi hành     ^dieu-9
1. Thông tư này có hiệu lực thi hành kể từ ngày tháng 4 năm 2026 , trừ trường hợp quy định tại khoản 2 Điều này.
2. Điều 8 Thông tư này có hiệu lực thi hành kể từ ngày tháng 6 năm 2026 .

## Điều 10. Quy   định   chuyển   tiếp     ^dieu-10
1. Đối với các số thuê bao di động đã được thuê bao sử dụng tài khoản định danh điện tử mức độ 2 hoặc thẻ căn cước hoặc thẻ căn cước công dân có gắn chíp điện tử để đăng ký, xác thực thông tin thuê bao hoặc số thuê bao di động mà thuê bao đã sử dụng để đăng ký tài khoản định danh điện tử mức độ 2: thuê bao không phải xác thực lại thông tin thuê bao, không phải xác thực sinh trắc học ảnh khuôn mặt trừ trường hợp thay đổi thiết bị đầu cuối theo quy định tại Điều 8 Thông tư này.
2. Đối với các số thuê bao di động H2H đã được thuê bao sử dụng tài khoản định danh điện tử mức độ 02 hoặc thẻ căn cước hoặc thẻ căn cước công dân có gắn chíp điện tử để đăng ký và đã được thuê bao thông qua Ứng dụng VNeID trực tiếp xác nhận bản thân đang sử dụng: thuê bao không phải xác thực lại thông tin thuê bao, không phải xác thực sinh trắc học ảnh khuôn mặt trừ trường hợp thay đổi thiết bị đầu cuối theo quy định tại Điều 8 Thông tư này.
3. Đối với các số thuê bao di động H2H đã được thuê bao sử dụng chứng minh nhân dân 9 số để đăng ký, xác thực thông tin thuê bao và được thuê bao thông qua Ứng dụng VNeID trực tiếp xác nhận bản thân đang sử dụng:
a) Doanh nghiệp viễn thông hoàn thành việc cập nhật lại thông tin thuê bao, bổ sung xác thực sinh trắc học ảnh khuôn mặt của thuê bao trong vòng 60 ngày kể từ ngày doanh nghiệp nhận được thông tin qua Ứng dụng VneID về việc thuê bao trực tiếp xác nhận bản thân đang sử dụng;
b) Doanh nghiệp viễn thông tạm dừng cung cấp dịch vụ viễn thông chiều đi (gọi điện thoại, gửi tin nhắn SMS đến số thuê bao khác) đối với các thuê bao không thực hiện việc cập nhật lại thông tin thuê bao, không bổ sung xác thực sinh trắc học ảnh khuôn mặt hoặc xác thực sinh trắc học ảnh khuôn mặt không đầy đủ, không chính xác.
4. Đối với các số thuê bao di động H2H được cá nhân thông qua Ứng dụng VNeID trực tiếp xác nhận bản thân không đăng ký, không sử dụng:
a) Doanh nghiệp viễn thông có nghĩa vụ thông báo liên tục trong vòng 05 ngày, kể từ ngày doanh nghiệp nhận được thông tin qua Ứng dụng VNeID về việc cá nhân trực tiếp xác nhận bản thân không đăng ký, không sử dụng, mỗi ngày ít nhất một lần yêu cầu cá nhân đang sử dụng số thuê bao di động thực hiện lại việc giao kết hợp đồng theo quy định và xác thực sinh trắc học ảnh khuôn mặt của thuê bao. Trường hợp cá nhân đang sử dụng số thuê bao không thực hiện theo yêu cầu, doanh nghiệp viễn thông tạm dừng cung cấp dịch vụ viễn thông chiều đi (gọi thoại, gửi tin nhắn SMS đến số thuê bao khác).
b) Trong vòng 60 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông chiều đi, doanh nghiệp viễn thông phải hoàn thành việc cập nhật, chuẩn hóa thông tin thuê bao và bổ sung xác thực sinh trắc học ảnh khuôn mặt của thuê bao;
c) Sau thời điểm nêu tại điểm b Khoản này, đối với các thuê bao không hoàn thành việc cập nhật, chuẩn hóa thông tin thuê bao và bổ sung xác thực sinh trắc học ảnh khuôn mặt, doanh nghiệp viễn thông có nghĩa vụ tạm dừng cung cấp dịch vụ viễn thông hai chiều đồng thời thông báo thuê bao sẽ bị thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông nếu không thực hiện; thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông sau 05 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông hai chiều nếu cá nhân, tổ chức không thực hiện.
5. Đối với các số thuê bao di động H2H của người có quốc tịch Việt Nam không thuộc các trường hợp quy định tại khoản 1, khoản 2, khoản 3, khoản 4 Điều này:
a) Trong vòng 30 ngày kể từ ngày Thông tư này có hiệu lực, doanh nghiệp viễn thông gửi thông báo đề nghị thuê bao cập nhật, chuẩn hóa thông tin và xác thực sinh trắc học ảnh khuôn mặt của thuê bao;
b) Trong vòng 60 ngày kể từ ngày Thông tư này có hiệu lực, doanh nghiệp viễn thông tạm dừng cung cấp dịch vụ viễn thông chiều đi (gọi điện thoại, gửi tin nhắn SMS đến số thuê bao khác) và gửi thông báo đề nghị thuê bao cập nhật, chuẩn hóa thông tin;
c) Trong vòng 60 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông chiều đi, doanh nghiệp viễn thông phải hoàn thành việc cập nhật, chuẩn hóa thông tin thuê bao và bổ sung xác thực sinh trắc học ảnh khuôn mặt của thuê bao;
d) Sau thời điểm nêu tại điểm c khoản này, đối với các thuê bao không hoàn thành việc cập nhật thông tin thuê bao và bổ sung xác thực sinh trắc học ảnh khuôn mặt, doanh nghiệp viễn thông có nghĩa vụ tạm dừng cung cấp dịch vụ viễn thông hai chiều đồng thời thông báo thuê bao sẽ bị thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông nếu không thực hiện; thanh lý hợp đồng, chấm dứt cung
cấp dịch vụ viễn thông sau 05 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông hai chiều nếu cá nhân, tổ chức không thực hiện.
6. Đối với các số thuê bao do người có quốc tịch nước ngoài sử dụng hộ chiếu để đăng ký thông tin thuê bao:
a) Trong vòng 60 ngày kể từ ngày Thông tư này có hiệu lực: doanh nghiệp viễn thông phải thông báo, hoàn thành xác thực lại thông tin thuê bao theo quy định tại Điều 6 Thông tư này.
b) Doanh nghiệp viễn thông có nghĩa vụ tạm dừng cung cấp dịch vụ viễn thông chiều đi (gọi điện thoại, gửi tin nhắn SMS đến số thuê bao khác) đối với các thuê bao không thực hiện xác thực lại hoặc xác thực lại không đầy đủ, không chính xác. Sau thời điểm nêu tại điểm a khoản này, đối với các thuê bao không hoàn thành việc xác thực lại hoặc xác thực không đầy đủ, không chính xác, doanh nghiệp viễn thông có nghĩa vụ tạm dừng cung cấp dịch vụ viễn thông hai chiều đồng thời thông báo thuê bao sẽ bị thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông nếu không thực hiện; thanh lý hợp đồng, chấm dứt cung cấp dịch vụ viễn thông sau 05 ngày kể từ ngày tạm dừng cung cấp dịch vụ viễn thông hai chiều nếu cá nhân, tổ chức không thực hiện.
7. Trong vòng 30 ngày kể từ ngày Thông tư có hiệu lực, doanh nghiệp viễn thông có nghĩa vụ gửi danh sách, thông tin các số thuê bao di động đã được đăng ký, sử dụng trước ngày Thông tư này có hiệu lực về cơ quan quản lý căn cước của Bộ Công an để cập nhật vào Cơ sở dữ liệu quốc gia về dân cư, thực hiện xác thực thông tin, cụ thể như sau:
a) Đối với các thuê bao đăng ký bằng tài khoản định danh điện tử, thẻ căn cước, thẻ căn cước công dân thực hiện gửi các thông tin bao gồm: số điện thoại, số giấy tờ.
b) Đối với các thuê bao đăng ký bằng giấy tờ khác, thông tin bao gồm: số giấy tờ; số điện thoại; họ và tên; ngày, tháng, năm sinh.

## Điều 11. Tổ   chức   thực   hiện     ^dieu-11
1. Chánh Văn phòng, Cục trưởng Cục Viễn thông, Thủ trưởng các cơ quan, đơn vị thuộc Bộ Khoa học và Công nghệ và các tổ chức, cá nhân có liên quan chịu trách nhiệm thi hành Thông tư này.
2. Định kỳ 06 tháng hoặc khi có yêu cầu, Cục Viễn thông chủ trì, phối hợp với các cơ quan có liên quan tổ chức kiểm tra, đánh giá việc thực hiện các quy định tại Thông tư này của các doanh nghiệp viễn thông và kịp thời xử lý theo thẩm quyền hoặc báo cáo cấp có thẩm quyền xử lý hành vi vi phạm theo quy định của pháp luật.
3. Trong quá trình thực hiện, nếu có vướng mắc, đề nghị các cơ quan, tổ chức, cá nhân kịp thời phản ánh về Bộ Khoa học và Công nghệ (Cục Viễn thông) để được hướng dẫn hoặc xem xét, giải quyết./.
Nơi nhận:
- Thủ tướng Chính phủ, các Phó Thủ tướng Chính phủ;
- Các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ;
- UBND các tỉnh, Thành phố trực thuộc TW;
- Sở KH&CN các tỉnh, Thành phố trực thuộc TW;
- Cục Kiểm tra văn bản và Tổ chức thi hành pháp luật, Bộ Tư pháp;
- Cổng TTĐT Chính phủ, Công báo;
- Bộ KHCN: Bộ trưởng và các Thứ trưởng; các cơ quan, đơn vị thuộc Bộ; Cổng TTĐT Bộ;
- Các doanh nghiệp cung cấp dịch vụ viễn thông di động mặt đất ;
- Lưu: VT, CVT.
BỘ TRƯỞNG
Nguyễn Mạnh Hùng
