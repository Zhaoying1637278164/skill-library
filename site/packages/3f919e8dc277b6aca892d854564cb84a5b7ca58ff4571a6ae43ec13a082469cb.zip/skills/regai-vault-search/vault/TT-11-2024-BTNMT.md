---
so_hieu: 11/2024/TT-BTNMT
loai_van_ban: Thông tư
tier: 4
tieu_de: Thông tư số 11/2024/TT-BTNMT Quy định kỹ thuật điều tra, đánh giá đất đai;
  kỹ thuật bảo vệ, cải tạo, phục hồi đất
nganh: Lao động - Thương binh và Xã hội
linh_vuc: Chưa phân loại
co_quan_ban_hanh: Bộ Tài nguyên và Môi trường
organization: Bộ Nông nghiệp và Môi trường
nguoi_ky: Lê Minh Ngân
chuc_danh: Thứ trưởng
ngay_ban_hanh: '2024-07-31'
ngay_co_hieu_luc: '2024-08-01'
ngay_cong_bao: null
ngay_het_hieu_luc: null
tinh_trang: con_hieu_luc
vbpl_guid: '173541'
nguon_url: https://vbpl.vn/van-ban/chi-tiet/173541
can_cu_ban_hanh:
- '[[Luat-43-2024]]'
- '[[ND-101-2024]]'
- 31/2024/QH15
- 68/2022/NĐ-CP
bi_sua_doi_bo_sung_boi:
- '[[TT-23-2025-BNNMT]]'
thay_the:
- 14/2012/TT-BTNMT
- 35/2014/TT-BTNMT
- 60/2015/TT-BTNMT
tham_chieu_ngoai:
- so_hieu: 31/2024/QH15
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/177815
  label: can_cu_ban_hanh
- so_hieu: 68/2022/NĐ-CP
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/156234
  label: can_cu_ban_hanh
- so_hieu: 046/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/184058
  label: duoc_dan_chieu_boi
- so_hieu: 09/2025/NQ-HĐND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/180216
  label: duoc_dan_chieu_boi
- so_hieu: 26/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/178635
  label: duoc_dan_chieu_boi
- so_hieu: 04/2025/NQ-HĐND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/180957
  label: duoc_quy_dinh_chi_tiet_boi
- so_hieu: 14/2012/TT-BTNMT
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/27978
  label: thay_the
- so_hieu: 35/2014/TT-BTNMT
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/37902
  label: thay_the
- so_hieu: 60/2015/TT-BTNMT
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/106201
  label: thay_the
- so_hieu: 04/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/186515
  label: van_ban_ap_dung
- so_hieu: 046/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/184058
  label: van_ban_ap_dung
- so_hieu: 10/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/178421
  label: van_ban_ap_dung
- so_hieu: 10/2026/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/186763
  label: van_ban_ap_dung
- so_hieu: 12/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/177596
  label: van_ban_ap_dung
- so_hieu: 15/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/177819
  label: van_ban_ap_dung
- so_hieu: 150/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/185585
  label: van_ban_ap_dung
- so_hieu: 151/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/184654
  label: van_ban_ap_dung
- so_hieu: 19/2026/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/26ed0e10-4905-11f1-b2bc-a5ed75839cd0
  label: van_ban_ap_dung
- so_hieu: 21/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/182224
  label: van_ban_ap_dung
- so_hieu: 21/2026/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/187764
  label: van_ban_ap_dung
- so_hieu: 234/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/184955
  label: van_ban_ap_dung
- so_hieu: 24/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/183173
  label: van_ban_ap_dung
- so_hieu: 28/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/178431
  label: van_ban_ap_dung
- so_hieu: 29/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/182751
  label: van_ban_ap_dung
- so_hieu: 29/2026/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/187350
  label: van_ban_ap_dung
- so_hieu: 32/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/178586
  label: van_ban_ap_dung
- so_hieu: 33/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/184163
  label: van_ban_ap_dung
- so_hieu: 33/2026/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/3d6d8b70-4832-11f1-a49f-8155e06f8765
  label: van_ban_ap_dung
- so_hieu: 36/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/179176
  label: van_ban_ap_dung
- so_hieu: 41/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/177367
  label: van_ban_ap_dung
- so_hieu: 47/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/177885
  label: van_ban_ap_dung
- so_hieu: 51/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/178564
  label: van_ban_ap_dung
- so_hieu: 53/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/181156
  label: van_ban_ap_dung
- so_hieu: 55/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/178220
  label: van_ban_ap_dung
- so_hieu: 60/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/185751
  label: van_ban_ap_dung
- so_hieu: 69/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/184274
  label: van_ban_ap_dung
- so_hieu: 75/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/181768
  label: van_ban_ap_dung
- so_hieu: 85/2025/QĐ-UBND
  nguon_url: https://vbpl.vn/van-ban/chi-tiet/183380
  label: van_ban_ap_dung
---

# Thông tư 11/2024/TT-BTNMT — Thông tư số 11/2024/TT-BTNMT Quy định kỹ thuật điều tra, đánh giá đất đai; kỹ thuật bảo vệ, cải tạo, phục hồi đất

## Điều 1. Phạm vi điều chỉnh     ^dieu-1
Thông tư này quy định kỹ thuật điều tra, đánh giá đất đai; kỹ thuật bảo vệ, cải tạo, phục hồi đất, bao gồm:
1. Kỹ thuật điều tra, đánh giá đất đai gồm:
a) Kỹ thuật điều tra, đánh giá về chất lượng đất, tiềm năng đất đai quy định tại khoản 1 Điều 53 Luật Đất đai;
b) Kỹ thuật điều tra, đánh giá thoái hóa đất quy định tại khoản 2 Điều 53 Luật Đất đai;
c) Kỹ thuật điều tra, đánh giá ô nhiễm đất quy định tại khoản 3 Điều 53 Luật Đất đai;
d) Kỹ thuật quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất quy định tại khoản 4 Điều 53 Luật Đất đai;
đ) Kỹ thuật điều tra, đánh giá đất đai theo chuyên đề quy định tại khoản 2 Điều 52 Luật Đất đai.
2. Kỹ thuật bảo vệ, cải tạo, phục hồi đất quy định tại Điều 54 Luật Đất đai.

> [!history] Lịch sử Điều 1
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-1]] (số hiệu 23/2025/TT-BNNMT).

## Điều 2. Đối tượng áp dụng     ^dieu-2
Thông tư này áp dụng đối với các cơ quan quản lý nhà nước về đất đai, cơ quan có chức năng quản lý đất đai ở địa phương, các tổ chức, cá nhân thực hiện điều tra, đánh giá đất đai; bảo vệ, cải tạo, phục hồi đất và các tổ chức, cá nhân có liên quan.

> [!history] Lịch sử Điều 2
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-2]] (số hiệu 23/2025/TT-BNNMT).

## Điều 3. Giải thích từ ngữ     ^dieu-3
Trong Thông tư này các từ ngữ dưới đây được hiểu như sau:
1. Bản đồ chất lượng đất là bản đồ thể hiện việc phân bố các khoanh đất theo phân mức chất lượng đất tại một thời điểm xác định.
2. Bản đồ đất bị ô nhiễm là bản đồ thể hiện việc phân bố các khoanh đất theo loại hình, phân mức ô nhiễm đất và vị trí các điểm ô nhiễm tại một thời điểm xác định.
3 . Bản đồ tiềm năng đất đai là bản đồ thể hiện việc phân bố các khoanh đất theo phân mức tiềm năng đất đai tại một thời điểm xác định.
4. Bản đồ thoái hóa đất là bản đồ thể hiện việc phân bố các khoanh đất theo phân mức thoái hóa đất tại một thời điểm xác định.
5. Chất lượng đất là đặc điểm thổ nhưỡng, địa hình, tính chất vật lý, tính chất hóa học, tính chất sinh học và điều kiện khác theo phân mức đánh giá.
6. Khoanh đất là vùng được hình thành bởi một hoặc nhiều thửa đất liền kề có cùng đặc tính, ranh giới ngoài cùng khép kín.
7. Khu vực cần bảo vệ, cải tạo, phục hồi đất là các khu vực đất bị thoái hóa, đất bị ô nhiễm đã được khoanh vùng theo kết quả hoạt động điều tra, đánh giá đất đai.
8. Ô nhiễm đất là sự gia tăng hàm lượng của một số chất, hợp chất so với giới hạn tối đa cho phép quy định Thông tư này.
9. Quan trắc chất lượng đất là hoạt động theo dõi có hệ thống các chỉ tiêu về tính chất vật lý, tính chất hóa học của đất.
10. Quan trắc ô nhiễm đất là hoạt động theo dõi có hệ thống về hàm lượng kim loại nặng có trong đất và dư lượng hóa chất bảo vệ thực vật phốt pho hữu cơ có trong đất đối với đất trồng cây hằng năm và đất trồng cây lâu năm.
11. Quan trắc thoái hóa đất là hoạt động theo dõi có hệ thống các chỉ tiêu đất bị suy giảm độ phì; đất bị xói mòn; đất bị khô hạn, hoang mạc hóa, sa mạc hóa; đất bị kết von, đá ong hóa; đất bị mặn hóa; đất bị phèn hóa.
12. Tiềm năng đất đai là khả năng về số lượng, chất lượng đất và hiệu quả kinh tế, xã hội, môi trường cho các loại đất nông nghiệp, phi nông nghiệp.
13. Quy định viết tắt
BVTV
Bảo vệ thực vật
CEC
Khả năng trao đổi cation của đất (Cation Exchange Capacity)
GIS
Hệ thống thông tin địa lý (Geographic Information System)
GPS
Hệ thống định vị toàn cầu (Global Positioning System)

> [!history] Lịch sử Điều 3
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-3]] (số hiệu 23/2025/TT-BNNMT).

## Điều 4. Đối tượng điều tra, đánh giá đất đai; bảo vệ, cải tạo, phục hồi đất     ^dieu-4
1. Đối tượng điều tra, đánh giá chất lượng đất, thoái hóa đất cả nước, các vùng kinh tế - xã hội (sau đây gọi là cấp vùng), các tỉnh, thành phố trực thuộc Trung ương (sau đây gọi là cấp tỉnh) bao gồm các loại đất nông nghiệp và đất chưa sử dụng (trừ đất núi đá không có rừng cây).
2. Đối tượng điều tra, đánh giá tiềm năng đất đai cả nước, cấp vùng, cấp tỉnh bao gồm các loại đất nông nghiệp, đất phi nông nghiệp, đất chưa sử dụng.
3. Đối tượng điều tra, đánh giá ô nhiễm đất
a) Đối tượng điều tra, đánh giá ô nhiễm đất cả nước, cấp vùng bao gồm các loại đất nông nghiệp và đất chưa sử dụng (trừ đất núi đá không có rừng cây);
b) Đối tượng điều tra, đánh giá ô nhiễm đất cấp tỉnh là các loại đất có nguồn gây ô nhiễm, gồm: các loại đất nông nghiệp; đất chưa sử dụng (trừ đất núi đá không có rừng cây); đất được quy hoạch xây dựng khu dân cư đô thị, nông thôn.
4. Đối tượng quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất là các loại đất quy định tại khoản 1 và khoản 3 Điều này được xác định theo mạng lưới các điểm quan trắc cố định trên phạm vi cả nước.
5. Đối tượng điều tra, đánh giá đất đai theo chuyên đề là một hoặc nhiều loại đất quy định tại Điều 9 Luật Đất đai do cơ quan Nhà nước có thẩm quyền quyết định tổ chức thực hiện việc điều tra, đánh giá đất đai theo chuyên đề xác định trong nhiệm vụ khi phê duyệt.
6. Đối tượng bảo vệ, cải tạo, phục hồi đất là các loại đất trong khu vực bị thoái hóa, bị ô nhiễm.

> [!history] Lịch sử Điều 4
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-4]] (số hiệu 23/2025/TT-BNNMT).

## Điều 5. Quy định về bản đồ điều tra thực địa điều tra, đánh giá đất đai     ^dieu-5
1. Quy định về bản đồ điều tra thực địa
a) Bản đồ điều tra thực địa đối với điều tra, đánh giá chất lượng đất, thoái hóa đất, ô nhiễm đất cả nước, cấp vùng được lập trên nền bản đồ hiện trạng sử dụng đất cấp tỉnh cùng kỳ;
b) Bản đồ điều tra thực địa đối với điều tra, đánh giá chất lượng đất, thoái hóa đất cấp tỉnh được lập trên nền bản đồ hiện trạng sử dụng đất cấp huyện cùng kỳ;
c) Bản đồ điều tra thực địa đối với điều tra, đánh giá ô nhiễm đất cấp tỉnh được lập cho từng khu vực đất bị ô nhiễm tùy thuộc vào phạm vi ảnh hưởng của nguồn gây ô nhiễm trên nền bản đồ hiện trạng sử dụng đất cấp xã cùng kỳ tỷ lệ từ 1:2.000 đến 1:5.000 hoặc cấp huyện cùng kỳ tỷ lệ 1:10.000 đến 1:25.000 đối với khu vực điều tra, đánh giá ô nhiễm đất nằm trên địa bàn 02 xã trở lên.
2. Quy định về nội dung bản đồ điều tra thực địa
a) Các yếu tố kế thừa từ bản đồ hiện trạng sử dụng đất gồm: nhóm lớp cơ sở toán học và các nội dung liên quan; nhóm lớp biên giới, địa giới; nhóm lớp địa hình; nhóm lớp giao thông, thủy hệ và các đối tượng có liên quan; nhóm lớp đối tượng kinh tế, xã hội; nhóm lớp hiện trạng sử dụng đất;
b) Ranh giới khoanh đất điều tra chất lượng đất, tiềm năng đất đai; thoái hóa đất; ô nhiễm đất. Ký hiệu ranh giới khoanh đất điều tra được thể hiện theo quy định tại Mục 2 Phần B của Phụ lục I ban hành kèm theo Thông tư này.
Diện tích khoanh đất nhỏ nhất được xác định căn cứ vào ranh giới khoanh đất tại thực địa và tỷ lệ bản đồ, cụ thể như sau:
Tỷ lệ
bản đồ
Diện tích khoanh đất tối thiểu thể hiện trên bản đồ (mm 2 )
Diện tích khoanh đất tối thiểu tại thực địa (ha)
1:2.000
100
0,04
1:5.000
100
0,25
1:10.000
100
1,00
1:25.000
100
6,25
1:50.000
100
25
1:100.000
100
100
c) Nhãn khoanh đất điều tra
Nhãn khoanh đất điều tra chất lượng đất, thoái hóa đất thể hiện thông tin điều tra theo thứ tự: ký hiệu viết tắt tên địa danh; số thứ tự khoanh đất (thể hiện bằng chữ số Ả Rập, từ 01 đến hết trong phạm vi điều tra, thứ tự đánh số từ trái sang phải, từ trên xuống dưới); ký hiệu loại thổ nhưỡng; ký hiệu địa hình.
Nhãn khoanh đất điều tra ô nhiễm đất cấp vùng thể hiện thông tin điều tra theo thứ tự: ký hiệu viết tắt tên địa danh; số thứ tự khoanh đất (thể hiện bằng chữ số Ả Rập, từ 01 đến hết trong phạm vi điều tra, thứ tự đánh số từ trái sang phải, từ trên xuống dưới); ký hiệu loại đất, tên đơn vị hành chính cấp xã.
Nhãn khoanh đất điều tra ô nhiễm đất cấp tỉnh thể hiện thông tin điều tra theo thứ tự: ký hiệu viết tắt tên địa danh; số thứ tự khoanh đất (thể hiện bằng chữ số Ả Rập, từ 01 đến hết trong phạm vi điều tra, thứ tự đánh số từ trái sang phải, từ trên xuống dưới); ký hiệu loại đất; ký hiệu nguồn gây ô nhiễm;
d) Vị trí điểm điều tra trên bản đồ điều tra thực địa được thể hiện dưới dạng điểm;
đ) Tên bản đồ, tỷ lệ bản đồ, đơn vị xây dựng và chú dẫn (gồm: ký hiệu của các yếu tố kế thừa từ bản đồ hiện trạng sử dụng đất, ranh giới khoanh đất điều tra, nhãn khoanh đất điều tra và ký hiệu điểm điều tra).

> [!history] Lịch sử Điều 5
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-5]] (số hiệu 23/2025/TT-BNNMT).

## Điều 7. &nbsp;Quy định về lưu trữ và trình bày dữ liệu điều tra, đánh giá đất đai và bảo vệ, cải tạo, phục hồi đất     ^dieu-7
1. Dữ liệu lưu trữ
a) Dữ liệu lưu trữ bao gồm: dữ liệu không gian, dữ liệu thuộc tính của sơ đồ mạng lưới điểm điều tra phẫu diện, điểm lấy mẫu, điểm điều tra; các lớp thông tin của bản đồ kết quả điều tra, đánh giá đất đai; kết quả thực hiện bảo vệ, cải tạo, phục hồi đất; các lớp thông tin của bản đồ kết quả bảo vệ, cải tạo, phục hồi đất và các dữ liệu khác có liên quan (kết quả điều tra thực địa; báo cáo tổng hợp; hệ thống biểu kết quả điều tra, đánh giá đất đai; bảo vệ, cải tạo, phục hồi đất);
b) Nội dung dữ liệu lưu trữ điều tra, đánh giá đất đai; dữ liệu lưu trữ bảo vệ, cải tạo, phục hồi đất theo quy định tại Bảng số 04/QĐC của Phụ lục I ban hành kèm theo Thông tư này.
2. Định dạng dữ liệu lưu trữ
a) Dữ liệu được lưu trữ dưới dạng số;
b) Tệp tin dữ liệu lưu trữ ở một trong các định dạng gồm: *.pdf, *.docx, *.xlsx, *.shp, *.gdb, *.qdb, *.xml, *.gml, *.json, *.geojson. Tệp tin phải ở dạng mở, cho phép chỉnh sửa, cập nhật thông tin khi cần thiết, đảm bảo tính toàn vẹn về dữ liệu khi thực hiện chuyển đổi định dạng, cấu trúc;
c) Cấu trúc, kiểu thông tin của dữ liệu lưu trữ theo quy định tại Phần D của Phụ lục II, Phần D của Phụ lục III, Phần D của Phụ lục IV, Phần Đ của Phụ lục V và Bảng số 05/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này.
3. Dữ liệu trình bày
a) Dữ liệu trình bày được tổ chức theo các lớp thông tin, thể hiện đầy đủ thuộc tính của các khoanh đất, trong đó ranh giới các khoanh đất thuộc cùng một hệ thống chỉ tiêu được xác định trong cùng lớp thông tin bản đồ;
b) Tệp tin dữ liệu trình bày kết quả điều tra, đánh giá đất đai; dữ liệu trình bày kết quả bảo vệ, cải tạo, phục hồi đất ở một trong các định dạng: *.wor, *.mxd, *.mpk, *.qgz.

> [!history] Lịch sử Điều 7
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-7]] (số hiệu 23/2025/TT-BNNMT).

## Điều 8. Xây dựng nhiệm vụ điều tra, đánh giá đất đai; nhiệm vụ bảo vệ, cải tạo, phục hồi đất     ^dieu-8
1. Thu thập tài liệu phục vụ xây dựng nhiệm vụ
a) Thu thập các tài liệu, số liệu, bản đồ có liên quan đến việc xây dựng nhiệm vụ;
b) Thu thập các chương trình, dự án, đề tài đã nghiên cứu trước đây có liên quan đến nhiệm vụ.
2. Xác định mục tiêu, nhiệm vụ của nhiệm vụ.
3. Xác định địa bàn, quy mô diện tích, đối tượng điều tra và bản đồ cần sử dụng trong nhiệm vụ.
4. Đánh giá chất lượng, tính thời sự và độ tin cậy của các tài liệu, số liệu, bản đồ đã thu thập; lựa chọn những tài liệu đã thu thập phục vụ xây dựng nhiệm vụ.
5. Xác định nội dung, khối lượng, phương pháp thực hiện và sản phẩm của nhiệm vụ, bao gồm:
a) Xác định nội dung, khối lượng của từng bước công việc thực hiện;
b) Xác định phương pháp, biện pháp kỹ thuật, giải pháp kinh tế, xã hội;
c) Xác định sản phẩm của nhiệm vụ và thời gian hoàn thành;
d) Xác định thời gian thực hiện, chủ đầu tư, chủ quản đầu tư nhiệm vụ.
6. Xây dựng dự toán kinh phí theo nội dung khối lượng công việc, bao gồm:
a) Xác định căn cứ lập dự toán kinh phí;
b) Xác định tổng dự toán kinh phí của nhiệm vụ;
c) Xác định dự toán chi tiết cho từng hạng mục công việc của nhiệm vụ.
7. Hoàn thiện nhiệm vụ điều tra, đánh giá đất đai; nhiệm vụ bảo vệ, cải tạo, phục hồi đất trình cấp có thẩm quyền phê duyệt.

> [!history] Lịch sử Điều 8
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-8]] (số hiệu 23/2025/TT-BNNMT).

## Điều 9. Thu thập thông tin, tài liệu, số liệu, bản đồ và khảo sát sơ bộ tại thực địa phục vụ điều tra, đánh giá chất lượng đất, tiềm năng đất đai     ^dieu-9
1. Thu thập các thông tin, tài liệu, số liệu, bản đồ về kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai; kết quả quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất đã thực hiện trên địa bàn gồm: kết quả điều tra thực địa, dữ liệu trung gian, sản phẩm chính và hồ sơ tài liệu khác.
2. Thu thập các thông tin, tài liệu, số liệu, bản đồ về điều kiện tự nhiên, tài nguyên thiên nhiên; kinh tế - xã hội và tình hình quản lý, sử dụng đất có liên quan đến chất lượng đất, tiềm năng đất đai trong vòng 5 năm trước thời điểm điều tra, bao gồm:
a) Nhóm thông tin, tài liệu, số liệu, bản đồ về điều kiện tự nhiên (địa hình, khí hậu, chế độ nước), tài nguyên thiên nhiên;
b) Nhóm thông tin, tài liệu, số liệu về tình hình phát triển kinh tế - xã hội; chiến lược, quy hoạch, kế hoạch phát triển kinh tế - xã hội;
c) Nhóm thông tin, tài liệu, số liệu về hiện trạng sử dụng đất, biến động sử dụng đất và tình hình quản lý, sử dụng đất; tình hình chuyển đổi cơ cấu sử dụng đất, các mô hình sử dụng đất nông nghiệp, diễn biến năng suất, sản lượng, sản phẩm chính, phụ và kỹ thuật canh tác sử dụng đất theo từng loại hình sử dụng đất nông nghiệp;
d) Nhóm thông tin, tài liệu, số liệu về bảng giá đất, hệ số điều chỉnh giá đất và các thông tin khác có liên quan đến giá đất;
đ) Phương pháp điều tra thu thập thông tin, tài liệu, số liệu thứ cấp quy định tại khoản 1 Mục I Phần A của Phụ lục II ban hành kèm theo Thông tư này.
3. Khảo sát sơ bộ để xác định hướng tuyến điều tra
a) Xác định tuyến điều tra trên bản đồ điều tra thực địa;
b) Khảo sát sơ bộ các tuyến điều tra theo đặc trưng về địa hình, thổ nhưỡng, hiện trạng sử dụng đất;
c) Xây dựng báo cáo kết quả điều tra, khảo sát sơ bộ.

> [!history] Lịch sử Điều 9
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-9]] (số hiệu 23/2025/TT-BNNMT).

## Điều 10. &nbsp; Đánh giá, lựa chọn các thông tin, tài liệu, số liệu, bản đồ đã thu thập     ^dieu-10
1. Tổng hợp, phân tích, đánh giá tính chính xác, khách quan, thời sự của thông tin, tài liệu, số liệu, bản đồ đã thu thập
a) Sắp xếp, phân loại theo chuyên mục, nguồn gốc hay thời gian tổng hợp xây dựng;
b) Đối chiếu các số liệu cũ với hiện trạng để xác định sự phù hợp với thực tế của từng nguồn số liệu;
c) Phân tích, đánh giá tính chính xác, khách quan và thời sự của thông tin, tài liệu, số liệu, bản đồ đã thu thập được.
2. Lựa chọn những thông tin, tài liệu, số liệu, bản đồ có thể sử dụng.
3. Xây dựng báo cáo kết quả thu thập thông tin, tài liệu, số liệu, bản đồ.

> [!history] Lịch sử Điều 10
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-10]] (số hiệu 23/2025/TT-BNNMT).

## Điều 11. Xác định nội dung và kế hoạch điều tra thực địa     ^dieu-11
1. Chuẩn bị bản đồ điều tra thực địa
a) Biên tập, chuẩn hóa các yếu tố kế thừa từ bản đồ hiện trạng sử dụng đất theo quy định tại Điều 5 của Thông tư này;
b) Tạo lập lớp thông tin khoanh đất điều tra, lớp thông tin điểm điều tra phẫu diện đất và các trường thông tin dữ liệu thuộc tính theo quy định tại Mục 1 Phần D của Phụ lục II ban hành kèm theo Thông tư này;
c) Xác định số lượng phẫu diện, khoanh đất điều tra theo quy định tại Mục 1 Phần B Phụ lục II ban hành kèm theo Thông tư này;
d) Xây dựng lớp thông tin khoanh đất điều tra: chuyển đổi, rà soát, chuẩn hóa và nhập thông tin thuộc tính về thổ nhưỡng, địa hình (độ dốc hoặc địa hình tương đối), độ dày tầng đất vào lớp thông tin tại điểm b khoản này từ các thông tin, tài liệu, số liệu thu thập; xác định ranh giới khoanh đất và số thứ tự khoanh đất theo quy định tại điểm b và điểm c khoản 2 Điều 5 của Thông tư này;
đ) Xây dựng lớp thông tin điểm điều tra phẫu diện đất: xác định vị trí điểm điều tra phẫu diện đất theo quy định tại điểm d khoản 2 Điều 5 của Thông tư này; xây dựng sơ đồ mạng lưới điểm điều tra phẫu diện đất theo quy định tại Mục II Phần A Phụ lục II ban hành kèm theo Thông tư này và nhập thông tin thuộc tính vào lớp thông tin tại điểm b khoản này;
e) Xác định nội dung điều tra khoanh đất theo các tuyến điều tra thực địa trên địa bàn cấp tỉnh;
g) Cập nhật thông tin thuộc tính của lớp điểm điều tra phẫu diện, kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai kỳ trước (nếu có) vào lớp thông tin khoanh đất điều tra;
h) Biên tập và in bản đồ điều tra thực địa.
2. Thống kê số lượng khoanh đất và đặc trưng của khoanh đất điều tra theo Mẫu số 01/CLĐ của Phụ lục II ban hành kèm theo Thông tư này; tạo lập bảng dữ liệu phục vụ nhập thông tin kết quả điều tra thực địa theo Mẫu số 03/CLĐ của Phụ lục II ban hành kèm theo Thông tư này.
3. Chuẩn bị bản mô tả khoanh đất điều tra, bản tả phẫu diện đất theo các mẫu số 02/CLĐ, 04/CLĐ, 05/CLĐ và 06/CLĐ của Phụ lục II ban hành kèm theo Thông tư này.
4. Xây dựng báo cáo kế hoạch điều tra thực địa.

> [!history] Lịch sử Điều 11
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-11]] (số hiệu 23/2025/TT-BNNMT).

## Điều 12. Điều tra, lấy mẫu đất phục vụ đánh giá chất lượng đất, tiềm năng đất đai     ^dieu-12
1. Khoanh vùng, xác định vị trí khoanh đất điều tra; rà soát, chỉnh lý ranh giới khoanh đất điều tra theo đặc điểm thổ nhưỡng và đặc điểm địa hình theo quy định tại Mục II Phần A Phụ lục II ban hành kèm theo Thông tư này; điều tra, mô tả thông tin khoanh đất theo bản mô tả đã chuẩn bị tại khoản 3 Điều 11 của Thông tư này.
2. Xác định vị trí điểm điều tra phẫu diện tại thực địa, tọa độ điểm điều tra phẫu diện được xác định bằng thiết bị định vị; cập nhật bổ sung vị trí điểm điều tra phẫu diện lên bản đồ điều tra thực địa (nếu có sự thay đổi); thực hiện đo độ ẩm đất, pH đất bằng máy đo cầm tay.
3. Điều tra phẫu diện đất
a) Đào (khoan) phẫu diện chính, phẫu diện phụ và phẫu diện thăm dò;
b) Chụp ảnh mặt cắt phẫu diện đất, ảnh cảnh quan khu vực điều tra phẫu diện;
c) Mô tả phẫu diện đất;
d) Lấy mẫu đất, tiêu bản đất, đóng gói và bảo quản mẫu đất.
e) Phương pháp điều tra phẫu diện của các điểm a, b, c và d khoản này quy định tại Mục I Phần A Phụ lục II ban hành kèm theo Thông tư này.
4. Rà soát, cập nhật kết quả điều tra thực địa tại các khoản 1, 2 và 3 Điều này vào bảng dữ liệu điều tra đã tạo lập tại khoản 2 Điều 11 của Thông tư này.
5. Xây dựng báo cáo kết quả điều tra, lấy mẫu đất tại thực địa.

> [!history] Lịch sử Điều 12
> Sửa đổi bởi [[TT-23-2025-BNNMT#^dieu-12]] (số hiệu 23/2025/TT-BNNMT).

## Điều 13. Tổng hợp, xử lý thông tin nội nghiệp và ngoại nghiệp&nbsp;     ^dieu-13
1. Tổng hợp, xử lý kết quả điều tra
a) Rà soát, đối chiếu, chỉnh lý, bổ sung thông tin đảm bảo tính chính xác thống nhất về kết quả điều tra giữa bản đồ điều tra thực địa với bản tả phẫu diện, ảnh điều tra, tiêu bản đất và bảng dữ liệu điều tra;
b) Lập bảng thống kê danh sách phẫu diện điều tra và mẫu đất; sắp xếp tiêu bản đất, mẫu đất và bản tả theo danh sách; lựa chọn mẫu đất phân tích; bàn giao mẫu đất cho đơn vị phân tích.
2. Phân tích mẫu đất
Các chỉ tiêu phân tích gồm: vi sinh vật tổng số; thành phần cơ giới (cát, limon, sét); dung trọng; tỷ trọng; độ chua của đất (pH KCl ); chất hữu cơ tổng số (OM%); nitơ tổng số (N%); phốt pho tổng số (P 2 O 5 %); kali tổng số (K 2 O%), CEC. Đối với khu vực ven biển phân tích thêm chỉ tiêu lưu huỳnh tổng số và chỉ tiêu tổng số muối tan.
Phương pháp phân tích mẫu đất theo quy định tại Mục III Phần A của Phụ lục II ban hành kèm theo Thông tư này.
3. Tổng hợp, xử lý thông tin phục vụ đánh giá chất lượng đất
a) Xác định và phân cấp chỉ tiêu đánh giá chất lượng đất theo quy định tại Mục I Phần C của Phụ lục II ban hành kèm theo Thông tư này;
b) Tổng hợp kết quả điều tra về thổ nhưỡng gồm loại thổ nhưỡng và độ dày tầng đất;
c) Tổng hợp kết quả điều tra về địa hình (độ dốc hoặc địa hình tương đối);
d) Tổng hợp kết quả phân tích về tính chất vật lý - hóa học - sinh học của đất theo loại thổ nhưỡng và loại đất;
đ) Tổng hợp kết quả điều tra khí hậu (lượng mưa, tổng tích ôn, số tháng khô hạn).
4. Tổng hợp, xử lý thông tin phục vụ đánh giá tiềm năng đất đai cho các loại đất hiện trạng và định hướng sử dụng đất
a) Xác định và phân cấp đánh giá tiềm năng đất đai theo quy định tại Mục II Phần C của Phụ lục II ban hành kèm theo Thông tư này;
b) Xác định diện tích của mỗi loại đất trong từng khoanh đất điều tra;
c) Tổng hợp kết quả điều tra về chế độ nước theo loại đất trong từng khoanh đất điều tra;
d) Tổng hợp kết quả đánh giá hiệu quả kinh tế cho từng khoanh đất và từng khu vực trên địa bàn điều tra;
đ) Tổng hợp kết quả đánh giá hiệu quả xã hội cho từng khoanh đất và từng khu vực trên địa bàn điều tra;
e) Tổng hợp kết quả đánh giá hiệu quả môi trường cho từng khoanh đất và từng khu vực trên địa bàn điều tra;
g) Tổng hợp, xử lý thông tin phục vụ đánh giá tiềm năng đất đai cho các loại đất phục vụ định hướng sử dụng đất.
5. Xây dựng báo cáo kết quả tổng hợp, xử lý thông tin nội và ngoại nghiệp.

## Điều 14. Xây dựng bản đồ chất lượng đất, tiềm năng đất đai     ^dieu-14
1. Chuẩn hóa các yếu tố nền bản đồ chất lượng đất, bản đồ tiềm năng đất đai theo quy định tại điểm a và điểm c khoản 2, điểm a và điểm d khoản 3 Điều 6 của Thông tư này.
2. Tạo lập các lớp thông tin và trường thông tin dữ liệu thuộc tính trong mỗi lớp thông tin chuyên đề theo cấu trúc, kiểu thông tin quy định tại Phần D của Phụ lục II ban hành kèm theo Thông tư này, bao gồm:
a) Lớp thông tin về đặc điểm thổ nhưỡng;
b) Lớp thông tin về địa hình;
c) Lớp thông tin về tính chất vật lý - hóa học - sinh học của đất;
d) Lớp thông tin về khí hậu;
đ) Lớp thông tin về loại đất;
e) Lớp thông tin phân mức chất lượng đất;
g) Lớp thông tin chế độ nước;
h) Lớp thông tin về hiệu quả kinh tế;
i) Lớp thông tin về hiệu quả xã hội;
k) Lớp thông tin về hiệu quả môi trường;
l) Lớp thông tin phân mức tiềm năng đất đai;
m) Lớp thông tin khoanh vùng các khu vực đất cần bảo vệ, cải tạo và phục hồi.
3. Xây dựng lớp thông tin loại đất
a) Chuyển đổi định dạng dữ liệu từ bản đồ hiện trạng sử dụng đất cùng cấp với bản đồ kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai;
b) Rà soát chỉnh lý ranh giới khoanh đất theo kết quả điều tra thực địa;
c) Chuẩn hóa và nhập các thông tin loại đất quy định tại Bảng số 01/QĐC và Bảng số 02/QĐC của Phụ lục I ban hành kèm theo Thông tư này vào lớp thông tin tại điểm đ khoản 2 Điều này.
4. Xây dựng bản đồ chất lượng đất
a) Rà soát, chỉnh lý ranh giới khoanh đất trong lớp thông tin khoanh đất điều tra của bản đồ điều tra thực địa quy định tại khoản 1 Điều 11 của Thông tư này theo kết quả tổng hợp xử lý thông tin tại điểm b và điểm c khoản 3 Điều 13 của Thông tư này;
b) Nhập kết quả phân tích mẫu đất vào lớp thông tin đã xây dựng tại điểm e khoản 1 Điều 11 của Thông tư này theo kết quả tổng hợp xử lý thông tin tại điểm d khoản 3 Điều 13 của Thông tư này;
c) Xây dựng các lớp thông tin chuyên đề về đặc điểm thổ nhưỡng, địa hình, tính chất vật lý - hóa học - sinh học của đất, khí hậu: chuyển ranh giới và nhập thông tin thuộc tính vào lớp thông tin tại các điểm a, b, c và d khoản 2 Điều này;
d) Chồng xếp các lớp thông tin chuyên đề đã xây dựng ở điểm c khoản này để khoanh vùng, xây dựng lớp thông tin phân mức chất lượng đất;
đ) Chồng xếp lớp thông tin phân mức chất lượng đất với lớp thông tin loại đất tại khoản 3 Điều này để xác định chất lượng đất theo loại đất;
e) Xuất dữ liệu phục vụ phân tích đánh giá chất lượng đất;
g) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ.
h) Trình tự xây dựng bản đồ chất lượng đất minh họa chi tiết tại Sơ đồ số 02/CLĐ của Phụ lục II ban hành kèm theo Thông tư này.
5. Khoanh vùng các khu vực đất cần bảo vệ, cải tạo và phục hồi
a) Xác định các khu vực đất cần bảo vệ, cải tạo và phục hồi từ kết quả phân mức chất lượng đất tại điểm d khoản 4 Điều này;
b) Chuyển ranh giới và nhập các thông tin thuộc tính các khu vực đất cần bảo vệ, xử lý, cải tạo và phục hồi vào lớp thông tin tại điểm m khoản 2 Điều này.
6. Xây dựng bản đồ tiềm năng đất đai
a) Nhập kết quả tổng hợp xử lý thông tin tại khoản 4 Điều 13 của Thông tư này vào lớp thông tin đã xây dựng tại khoản 3 Điều này;
b) Xây dựng các lớp thông tin chuyên đề về chế độ nước, hiệu quả kinh tế, hiệu quả xã hội, hiệu quả môi trường: chuyển ranh giới và nhập các thông tin thuộc tính vào các lớp thông tin tại các điểm g, h, i và k khoản 2 Điều này;
c) Chồng xếp các lớp thông tin chuyên đề tại điểm b khoản này và điểm d khoản 4 Điều này để khoanh vùng, xây dựng lớp thông tin phân mức đánh giá tiềm năng đất đai;
d) Xây dựng các lớp thông tin chuyên đề tiềm năng đất đai phục vụ định hướng sử dụng đất cho từng loại đất theo kết quả tổng hợp xử lý thông tin tại điểm g khoản 4 Điều 13 của Thông tư này;
đ) Xuất dữ liệu phục vụ phân tích đánh giá tiềm năng đất đai, định hướng sử dụng đất;
e) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ.
g) Trình tự xây dựng bản đồ tiềm năng đất đai minh họa chi tiết tại Sơ đồ số 03/CLĐ của Phụ lục II ban hành kèm theo Thông tư này.
7. Xây dựng dữ liệu về chất lượng đất, tiềm năng đất đai
a) Chuẩn hóa dữ liệu liên quan đến chất lượng đất, tiềm năng đất đai theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai;
b) Quét các dữ liệu khác có liên quan.
8. Cập nhật dữ liệu về chất lượng đất, tiềm năng đất đai vào cơ sở dữ liệu quốc gia về đất đai theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai.

## Điều 15. Phân tích đánh giá chất lượng đất, tiềm năng đất đai, đề xuất các giải pháp bảo vệ, cải tạo đất     ^dieu-15
1. Tổng hợp, phân tích, đánh giá chất lượng đất
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá chất lượng đất theo quy định tại điểm a khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá các quá trình hình thành, biến đổi chất lượng đất;
c) Phân tích, đánh giá ảnh hưởng của điều kiện tự nhiên, kinh tế - xã hội, tình hình quản lý và sử dụng đất đến chất lượng đất;
d) Phân tích, đánh giá chất lượng đất theo loại đất;
đ) Tổng hợp đánh giá chất lượng đất.
2. Tổng hợp, phân tích, đánh giá tiềm năng đất đai
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá tiềm năng đất đai theo quy định tại điểm b khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá ảnh hưởng của điều kiện tự nhiên đến tiềm năng đất đai;
c) Phân tích, đánh giá ảnh hưởng của phát triển kinh tế - xã hội đến tiềm năng đất đai;
d) Phân tích, đánh giá tình hình quản lý và sử dụng đất tác động đến tiềm năng đất đai;
đ) Phân tích, đánh giá hiệu quả sử dụng đất (hiệu quả kinh tế, xã hội và môi trường);
e) Phân tích, đánh giá tiềm năng đất đai theo loại đất và định hướng sử dụng đất.
3. Phân tích, đánh giá xu thế biến đổi chất lượng đất, tiềm năng đất đai so với kỳ điều tra trước đối với địa bàn đã thực hiện điều tra, đánh giá chất lượng đất, tiềm năng đất đai
a) Đánh giá sự thay đổi chất lượng đất so với kỳ điều tra trước;
b) Đánh giá sự thay đổi tiềm năng đất đai so với kỳ điều tra trước;
c) Phân tích, đánh giá xu hướng và nguyên nhân sự thay đổi về chất lượng và tiềm năng đất đai so với kỳ điều tra trước.
4. Đề xuất các giải pháp bảo vệ, cải tạo đất.
5. Xây dựng báo cáo chuyên đề đánh giá chất lượng đất, tiềm năng đất đai.

## Điều 16. Xây dựng báo cáo kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai     ^dieu-16
1. Xây dựng các phụ lục, bản đồ thu nhỏ đính kèm báo cáo.
2. Biên soạn báo cáo tổng hợp kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai.
3. Xây dựng báo cáo tóm tắt, báo cáo tổng kết nhiệm vụ.

## Điều 17. Thu thập thông tin, tài liệu, số liệu, bản đồ và khảo sát sơ bộ ngoài thực địa phục vụ điều tra, đánh giá thoái hóa đất     ^dieu-17
1. Thu thập nhóm các thông tin, tài liệu, số liệu, bản đồ về kết quả điều tra, đánh giá chất lượng đất, thoái hóa đất; kết quả quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất đã thực hiện trên địa bàn gồm: kết quả điều tra thực địa, dữ liệu trung gian, sản phẩm chính và hồ sơ tài liệu khác.
2. Thu thập nhóm các thông tin, tài liệu, số liệu, bản đồ về điều kiện tự nhiên, tài nguyên thiên nhiên; kinh tế - xã hội và tình hình quản lý, sử dụng đất có liên quan đến thoái hóa đất thực hiện theo quy định tại các điểm a, b và c khoản 2 Điều 9 của Thông tư này.
Phương pháp điều tra thu thập thông tin, tài liệu, số liệu thứ cấp theo quy định tại khoản 1 Mục I Phần A của Phụ lục III ban hành kèm theo Thông tư này.
3. Khảo sát sơ bộ tại thực địa
a) Khảo sát sơ bộ xác định hướng tuyến điều tra theo quy định tại điểm a và điểm b khoản 3 Điều 9 của Thông tư này;
b) Khảo sát sơ bộ các tuyến điều tra để xác định các khu vực có loại hình thoái hóa đặc trưng xuất hiện trên địa bàn theo kết quả điều tra, đánh giá thoái hóa đất đã có trên địa bàn;
c) Xây dựng báo cáo kết quả khảo sát sơ bộ.

## Điều 18. Đánh giá, lựa chọn các thông tin, tài liệu, số liệu, bản đồ đã thu thập     ^dieu-18
1. Tổng hợp, phân tích, đánh giá tính chính xác, khách quan, thời sự của thông tin, tài liệu, số liệu, bản đồ đã thu thập theo quy định tại khoản 1 Điều 10 của Thông tư này.
2. Lựa chọn những thông tin, tài liệu, số liệu, bản đồ có thể sử dụng.
3. Xây dựng báo cáo kết quả thu thập thông tin, tài liệu, số liệu, bản đồ.

## Điều 19. Xác định nội dung và kế hoạch điều tra thực địa     ^dieu-19
1. Chuẩn bị bản đồ điều tra thực địa
a) Biên tập, chuẩn hóa các yếu tố kế thừa từ bản đồ hiện trạng sử dụng đất theo quy định tại Điều 5 của Thông tư này;
b) Tạo lập lớp thông tin khoanh đất điều tra, lớp thông tin điểm điều tra các loại hình thoái hóa và các trường thông tin dữ liệu thuộc tính theo quy định tại Phần D của Phụ lục III ban hành kèm theo Thông tư này;
c) Xác định số lượng khoanh đất, điểm điều tra thực hiện theo quy định tại Phần B Phụ lục III của Thông tư này;
d) Xây dựng lớp thông tin khoanh đất điều tra: chuyển đổi, rà soát, chuẩn hóa và nhập thông tin thuộc tính về thổ nhưỡng, địa hình (độ dốc hoặc địa hình tương đối), độ dày tầng đất vào lớp thông tin tại điểm b khoản này từ các thông tin, tài liệu, số liệu thu thập; xác định ranh giới khoanh đất và số thứ tự khoanh đất theo quy định tại điểm b và điểm c khoản 2 Điều 5 của Thông tư này;
đ) Xây dựng lớp thông tin điểm điều tra thoái hóa: vị trí điểm điều tra thoái hóa theo quy định tại điểm d khoản 2 Điều 5 của Thông tư này; xây dựng sơ đồ mạng lưới điểm điều tra thoái hóa (vị trí điểm điều tra thoái hóa đất trùng với vị trí điểm điều tra phẫu diện đất trong cùng khoanh đất) và nhập thông tin thuộc tính vào lớp thông tin tại điểm b khoản này;
e) Xác định nội dung điều tra khoanh đất theo các tuyến điều tra thực địa trên địa bàn cấp tỉnh;
g) Cập nhật thông tin thuộc tính của lớp điểm điều tra các loại hình thoái hóa và kết quả điều tra, đánh giá thoái hóa đất kỳ trước (nếu có) vào lớp thông tin khoanh đất điều tra;
h) Biên tập và in bản đồ điều tra thực địa.
2. Thống kê số lượng khoanh đất và đặc trưng của khoanh đất điều tra theo Mẫu số 01/THĐ của Phụ lục III ban hành kèm theo Thông tư này; tạo lập bảng dữ liệu phục vụ nhập thông tin kết quả điều tra thực địa theo Mẫu số 03/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
3. Chuẩn bị bản mô tả kết quả điều tra các loại hình thoái hóa theo Mẫu số 02/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
4. Xây dựng báo cáo kế hoạch điều tra thực địa.

## Điều 20. Điều tra thực địa phục vụ đánh giá thoái hóa đất     ^dieu-20
1. Khoanh vùng, xác định vị trí khoanh đất điều tra; rà soát, chỉnh lý ranh giới khoanh đất điều tra theo các đặc điểm về thổ nhưỡng, địa hình, chế độ nước, loại đất, loại hình sử dụng đất, tỷ lệ che phủ đất, phương thức canh tác bảo vệ đất và các đặc trưng của các loại hình thoái hóa lên bản đồ điều tra thực địa theo quy định tại Mục I Phần A Phụ lục III ban hành kèm theo Thông tư này.
2. Xác định vị trí điểm điều tra thoái hóa tại thực địa: vị trí các điểm điều tra này trùng với vị trí điểm điều tra phẫu diện quy định tại khoản 2 Điều 12 của Thông tư này.
3. Điều tra các loại hình thoái hóa và mô tả kết quả điều tra vào bản mô tả đã chuẩn bị tại khoản 3 Điều 19 của Thông tư này.
4. Đối với địa bàn đã thực hiện điều tra, đánh giá thoái hóa đất thì xác định sự thay đổi hiện trạng sử dụng đất và các khu vực thoái hóa theo từng loại hình thoái hóa: điều tra xác định khu vực thoái hóa đất mới, các loại hình thoái hóa đã bị thay đổi mức độ thoái hóa gồm điều tra khoanh vẽ tại thực địa nhằm chỉnh lý ranh giới các khoanh đất được xác định có sự thay đổi về mức độ thoái hóa lên bản đồ điều tra thực địa, mô tả thông tin điều tra các loại hình thoái hóa vào bản mô tả đã chuẩn bị tại khoản 3 Điều 19 của Thông tư này.
5. Chụp ảnh minh họa cảnh quan khu vực, điểm điều tra; thực hiện đo độ ẩm đất, pH đất bằng máy đo cầm tay.
6. Rà soát, cập nhật kết quả điều tra thực địa tại các khoản 1, 2, 3, 4 và 5 Điều này vào bảng dữ liệu điều tra đã tạo lập tại khoản 2 Điều 19 của Thông tư này.
7. Xây dựng báo cáo kết quả điều tra thực địa.

## Điều 21. Tổng hợp, xử lý thông tin nội nghiệp và ngoại nghiệp     ^dieu-21
1. Tổng hợp, xử lý kết quả điều tra
a) Rà soát, đối chiếu, chỉnh lý, bổ sung thông tin đảm bảo tính chính xác thống nhất về kết quả điều tra giữa bản đồ điều tra thực địa với bản mô tả các loại hình thoái hóa, ảnh điều tra và bảng dữ liệu điều tra;
b) Lựa chọn kết quả phân tích quy định tại điểm d khoản 3 Điều 13 của Thông tư này của mẫu đất tầng mặt các phẫu diện.
2. Tổng hợp, xử lý thông tin phục vụ đánh giá thoái hóa đất
a) Xác định và phân cấp chỉ tiêu đánh giá thoái hóa đất theo quy định tại Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Tổng hợp kết quả điều tra theo quy định tại các điểm b, c, d, đ khoản 3 và điểm c khoản 4 Điều 13 của Thông tư này;
c) Tổng hợp kết quả điều tra phục vụ đánh giá đất bị suy giảm độ phì; đất bị xói mòn; đất bị khô hạn, hoang mạc hóa, sa mạc hóa; đất bị kết von, đá ong hóa; đất bị mặn hóa; đất bị phèn hóa theo chỉ tiêu phân cấp quy định tại điểm a khoản này.
3. Xây dựng báo cáo kết quả tổng hợp, xử lý thông tin nội và ngoại nghiệp.

## Điều 22. Xây dựng bản đồ thoái hóa đất     ^dieu-22
1. Chuẩn hóa các yếu tố nền của bản đồ thoái hóa đất theo quy định tại điểm a và điểm c khoản 2, điểm a và điểm d khoản 3 Điều 6 của Thông tư này.
2. Tạo lập các lớp thông tin và trường thông tin dữ liệu thuộc tính trong mỗi lớp thông tin chuyên đề theo cấu trúc, kiểu thông tin quy định tại Phần D của Phụ lục III ban hành kèm theo Thông tư này, bao gồm:
a) Lớp thông tin về đặc điểm thổ nhưỡng;
b) Lớp thông tin về địa hình;
c) Lớp thông tin về tính chất vật lý - hóa học của đất;
d) Lớp thông tin về khí hậu;
đ) Lớp thông tin về loại đất;
e) Lớp thông tin chế độ nước;
g) Lớp thông tin đất bị suy giảm độ phì;
h) Lớp thông tin đất bị xói mòn;
i) Lớp thông tin đất bị khô hạn, hoang mạc hóa, sa mạc hóa;
k) Lớp thông tin đất bị kết von, đá ong hóa;
l) Lớp thông tin đất bị mặn hóa;
m) Lớp thông tin đất bị phèn hóa;
n) Lớp thông tin thoái hóa đất;
o) Lớp thông tin khoanh vùng các khu vực đất bị thoái hóa cần xử lý, cải tạo và phục hồi.
3. Xây dựng lớp thông tin loại đất
a) Chuyển đổi định dạng dữ liệu từ bản đồ hiện trạng sử dụng đất cùng cấp với bản đồ kết quả điều tra, đánh giá thoái hóa đất;
b) Rà soát chỉnh lý ranh giới khoanh đất theo kết quả điều tra thực địa;
c) Chuẩn hóa và nhập các thông tin loại đất quy định tại Bảng số 01/QĐC của Phụ lục I ban hành kèm theo Thông tư này vào lớp thông tin tại điểm đ khoản 2 Điều này.
4. Rà soát, chỉnh lý ranh giới khoanh đất điều tra trong lớp thông tin khoanh đất của bản đồ điều tra thực địa quy định tại khoản 1 Điều 19 của Thông tư này theo kết quả tổng hợp xử lý thông tin tại điểm b khoản 2 Điều 21 của Thông tư này.
5. Xây dựng bản đồ đất bị suy giảm độ phì
a) Xác định và phân cấp chỉ tiêu đánh giá đất bị suy giảm độ phì theo Mục 6 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Xây dựng lớp thông tin về độ phì đất hiện tại theo chỉ tiêu quy định tại điểm a khoản này;
c) Chồng xếp các lớp thông tin về độ phì đất hiện tại; lớp thông tin về độ phì đất đã có trong quá khứ và lớp thông tin khoanh đất điều tra tại khoản 4 Điều này theo chỉ tiêu quy định tại điểm a khoản này để xây dựng lớp thông tin đất bị suy giảm độ phì;
d) Chồng xếp lớp thông tin đất bị suy giảm độ phì và lớp thông tin loại đất để xác định phân mức suy giảm độ phì theo loại đất;
đ) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị suy giảm độ phì;
e) Trình tự xây dựng bản đồ đất bị suy giảm độ phì minh họa chi tiết tại Sơ đồ số 02/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
6. Xây dựng bản đồ đất bị xói mòn
a) Xác định và phân cấp chỉ tiêu đánh giá đất bị xói mòn theo quy định tại Mục 7 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Xây dựng các lớp thông tin hệ số xói mòn do mưa (R), hệ số xói mòn của đất (K), hệ số chiều dài sườn dốc (L), hệ số độ dốc (S), hệ số lớp phủ thực vật và quản lý đất (C), hệ số do áp dụng các biện pháp canh tác bảo vệ đất (P);
c) Chồng xếp các lớp thông tin tại điểm b khoản này và lớp thông tin khoanh đất điều tra tại khoản 4 Điều này để xây dựng lớp thông tin đất bị xói mòn;
d) Chồng xếp lớp thông tin đất bị xói mòn và lớp thông tin về loại đất để xác định phân mức xói mòn theo loại đất;
đ) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị xói mòn;
e) Trình tự xây dựng bản đồ đất bị xói mòn minh họa chi tiết tại Sơ đồ số 03/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
7. Xây dựng bản đồ đất bị khô hạn, hoang mạc hóa, sa mạc hóa
a) Xác định và phân cấp chỉ tiêu đánh giá đất bị khô hạn, hoang mạc hóa, sa mạc hóa theo quy định tại Mục 8 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Xây dựng các lớp thông tin về chế độ tưới; lớp thông tin về khí hậu; lớp thông tin kết quả điều tra khô hạn, hoang mạc hóa, sa mạc hóa theo chỉ tiêu phân cấp tại điểm a khoản này;
c) Chồng xếp các lớp thông tin tại điểm b khoản này và lớp thông tin khoanh đất điều tra tại khoản 4 Điều này để xây dựng lớp thông tin đất bị khô hạn, hoang mạc hóa, sa mạc hóa;
d) Chồng xếp lớp thông tin đất bị khô hạn, hoang mạc hóa, sa mạc hóa và lớp thông tin loại đất để xác định phân mức khô hạn, hoang mạc hóa, sa mạc hóa theo loại đất;
đ) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị khô hạn, hoang mạc hóa, sa mạc hóa;
e) Trình tự xây dựng bản đồ đất bị khô hạn, hoang mạc hóa, sa mạc hóa minh họa chi tiết tại Sơ đồ số 04/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
8. Xây dựng bản đồ đất bị kết von, đá ong hóa
a) Xác định và phân cấp chỉ tiêu đánh giá đất bị kết von, đá ong hóa theo quy định tại Mục 9 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Xây dựng lớp thông tin đất bị kết von, đá ong hóa từ kết quả điều tra đất bị kết von, đá ong hóa và kết quả đánh giá từ tài liệu thu thập theo chỉ tiêu phân cấp tại điểm a khoản này;
c) Chồng xếp lớp thông tin đất bị kết von, đá ong hóa và lớp thông tin loại đất để xác định phân mức kết von, đá ong hóa theo loại đất;
d) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị kết von, đá ong hóa;
đ) Trình tự xây dựng bản đồ đất bị kết von, đá ong hóa minh họa chi tiết tại Sơ đồ số 05/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
9. Xây dựng bản đồ đất bị mặn hóa
a) Xác định và phân cấp chỉ tiêu đánh giá đất bị mặn hóa theo quy định tại Mục 10 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Xây dựng lớp thông tin về tổng số muối tan hiện tại theo chỉ tiêu quy định tại điểm a khoản này;
c) Chồng xếp các lớp thông tin về tổng số muối tan hiện tại; lớp thông tin về tổng số muối tan trong quá khứ và lớp thông tin khoanh đất điều tra tại khoản 4 Điều này theo chỉ tiêu quy định tại điểm a khoản này để xây dựng lớp thông tin đất bị mặn hóa;
d) Chồng xếp lớp thông tin đất bị mặn hóa và lớp thông tin loại đất để xác định phân mức mặn hóa theo loại đất;
đ) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị mặn hóa;
e) Trình tự xây dựng bản đồ đất bị mặn hóa minh họa chi tiết tại Sơ đồ số 06/THĐ của Phụ lục III ban hành kèm theo Thông tư này .
10. Xây dựng bản đồ đất bị phèn hóa
a) Xác định và phân cấp chỉ tiêu đánh giá đất bị phèn hóa theo quy định tại Mục 11 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Xây dựng lớp thông tin về lưu huỳnh tổng số hiện tại theo chỉ tiêu quy định tại điểm a khoản này;
c) Chồng xếp các lớp thông tin về lưu huỳnh tổng số hiện tại; lớp thông tin về lưu huỳnh tổng số trong quá khứ và lớp thông tin khoanh đất điều tra tại khoản 4 Điều này theo chỉ tiêu quy định tại điểm a khoản này để xây dựng lớp thông tin đất bị phèn hóa;
d) Chồng xếp lớp thông tin đất bị phèn hóa và lớp thông tin loại đất để xác định mức độ phèn hóa theo loại đất;
đ) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị phèn hóa;
e) Trình tự xây dựng bản đồ đất bị phèn hóa minh họa chi tiết tại Sơ đồ số 07/THĐ của Phụ lục III ban hành kèm theo Thông tư này.
11. Xây dựng bản đồ thoái hóa đất
a) Phân cấp các chỉ tiêu đánh giá thoái hóa đất theo quy định tại Mục 12 Phần C của Phụ lục III ban hành kèm theo Thông tư này;
b) Chồng xếp các lớp thông tin về đất bị suy giảm độ phì; đất bị xói mòn; đất bị khô hạn, hoang mạc hóa, sa mạc hóa; đất bị kết von, đá ong hóa; đất bị mặn hóa; đất bị phèn hóa để xây dựng lớp thông tin thoái hóa đất theo chỉ tiêu phân cấp tại điểm a khoản này;
c) Chồng xếp lớp thông tin thoái hóa đất và lớp thông tin loại đất để xác định mức độ thoái hóa theo loại đất;
d) Xác định diện tích khoanh đất thoái hóa theo loại hình thoái hóa và loại đất thoái hóa trên bản đồ;
đ) Xuất dữ liệu phục vụ đánh giá thoái hóa đất;
e) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ thoái hóa đất;
g) Trình tự xây dựng bản đồ thoái hóa đất minh họa chi tiết tại Sơ đồ số 08/THĐ của Phụ lục III ban hành kèm theo Thông tư này .
12. Khoanh vùng các khu vực đất bị thoái hóa cần xử lý, cải tạo và phục hồi
a) Xác định các khu vực đất bị thoái hóa từ kết quả phân mức thoái hóa đất tại điểm b khoản 11 Điều này;
b) Chuyển ranh giới và nhập các thông tin thuộc tính các khu vực đất cần xử lý, cải tạo và phục hồi vào lớp thông tin tại điểm o khoản 2 Điều này.
13. Xây dựng dữ liệu thoái hóa đất
a) Chuẩn hóa dữ liệu liên quan đến thoái hóa đất theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai;
b) Quét các dữ liệu khác có liên quan.
14. Cập nhật dữ liệu thoái hóa đất vào cơ sở dữ liệu quốc gia về đất đai theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai.

## Điều 23. Phân tích đánh giá thực trạng, nguyên nhân thoái hóa đất, đề xuất giải pháp giảm thiểu thoái hóa đất&nbsp;     ^dieu-23
1. Tổng hợp, phân tích, đánh giá thực trạng thoái hóa đất
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá thoái hóa đất theo quy định tại điểm c khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá ảnh hưởng của điều kiện tự nhiên, kinh tế - xã hội, tình hình quản lý và sử dụng đất đến thoái hóa đất;
c) Phân tích, đánh giá thoái hóa đất theo loại hình thoái hóa và loại đất;
d) Tổng hợp đánh giá thoái hóa đất.
2. Xác định xu hướng, nguyên nhân và dự báo nguy cơ thoái hóa đất
a) So sánh kết quả đánh giá thoái hóa đất với kết quả kỳ trước (nếu có) theo loại hình thoái hóa và loại đất;
b) Xác định nguyên nhân thoái hóa đất;
c) Đánh giá kết quả thực hiện các biện pháp kỹ thuật, giải pháp kinh tế, xã hội trong xử lý, cải tạo và phục hồi đất bị thoái hóa kỳ điều tra trước (nếu có);
d) Dự báo nguy cơ thoái hóa đất.
3. Đề xuất các biện pháp, giải pháp giảm thiểu thoái hóa đất.
4. Xây dựng báo cáo chuyên đề điều tra, đánh giá thoái hóa đất.

## Điều 25. Thu thập thông tin, tài liệu, số liệu, bản đồ và khảo sát sơ bộ tại thực địa phục vụ điều tra, đánh giá ô nhiễm đất     ^dieu-25
1. Thu thập nhóm các thông tin, tài liệu, số liệu, bản đồ về điều kiện tự nhiên, tài nguyên thiên nhiên; kinh tế - xã hội; tình hình quản lý và sử dụng đất có liên quan đến ô nhiễm đất thực hiện theo quy định tại các điểm a, b và c khoản 2 Điều 9 của Thông tư này.
2. Thu thập nhóm thông tin, tài liệu, số liệu, bản đồ liên quan đến ô nhiễm đất đối với điều tra, đánh giá ô nhiễm đất cấp vùng
a) Nhóm thông tin, tài liệu, số liệu, bản đồ về kết quả điều tra, đánh giá ô nhiễm đất cấp vùng (nếu có) gồm: kết quả điều tra thực địa, dữ liệu trung gian, sản phẩm chính và hồ sơ tài liệu khác;
b) Nhóm thông tin, tài liệu, số liệu, bản đồ về tình hình sử dụng phế phụ phẩm, phân bón, hóa chất BVTV, nguồn nước tưới bị ô nhiễm trong sản xuất nông nghiệp; thức ăn, hóa chất và thực trạng chất lượng cấp và tiêu thoát nước trong nuôi trồng thủy sản;
c) Nhóm thông tin, tài liệu, số liệu, bản đồ có liên quan đến thực trạng, mức độ ô nhiễm môi trường đất, nước theo quy định của pháp luật về bảo vệ môi trường đã thực hiện cấp vùng bị ảnh hưởng từ canh tác nông nghiệp, sử dụng nước tưới bị ô nhiễm và các nguồn gây ô nhiễm khác.
3. Thu thập nhóm thông tin, tài liệu, số liệu, bản đồ liên quan đến ô nhiễm đất đối với điều tra, đánh giá ô nhiễm đất cấp tỉnh
a) Nhóm thông tin, tài liệu, số liệu, bản đồ về kết quả điều tra, đánh giá ô nhiễm đất cấp tỉnh (nếu có) gồm: kết quả điều tra thực địa, dữ liệu trung gian, sản phẩm chính và hồ sơ tài liệu khác;
b) Nhóm thông tin, tài liệu, số liệu, bản đồ về thực trạng xử lý môi trường tại các khu vực có nguồn gây ô nhiễm là khu công nghiệp, cụm công nghiệp; khu tiểu thủ công nghiệp, làng nghề; khu khai thác, chế biến khoáng sản; bãi thải, xử lý chất thải và các nguồn ô nhiễm khác;
c) Nhóm thông tin, tài liệu, số liệu, bản đồ có liên quan đến thực trạng, mức độ ô nhiễm môi trường đất, nước theo quy định của pháp luật về bảo vệ môi trường bị ảnh hưởng từ các nguồn gây ô nhiễm từ khu công nghiệp, cụm công nghiệp; khu tiểu thủ công nghiệp, làng nghề; khu khai thác, chế biến khoáng sản; bãi thải, xử lý chất thải và các nguồn ô nhiễm khác.
4. Phương pháp điều tra thu thập thông tin, tài liệu, số liệu thứ cấp quy định tại khoản 2 và khoản 3 Điều này thực hiện theo quy định tại khoản 1 Mục I Phần A của Phụ lục IV ban hành kèm theo Thông tư này.
5. Khảo sát sơ bộ để xác định hướng tuyến điều tra
a) Khảo sát sơ bộ xác định các khu vực đất nông nghiệp theo từng tuyến điều tra, theo mức độ sử dụng phế phụ phẩm, phân bón, hóa chất BVTV; các khu vực nuôi trồng thủy sản sử dụng nhiều thức ăn, hóa chất hoặc nguồn nước tưới bị ô nhiễm đối với điều tra, đánh giá ô nhiễm đất cấp vùng;
b) Khảo sát sơ bộ theo tuyến điều tra xác định khu vực có nguồn gây ô nhiễm, tác nhân gây ô nhiễm do nước thải, chất thải của các khu công nghiệp, cụm công nghiệp; khu tiểu thủ công nghiệp, làng nghề; khu khai thác, chế biến khoáng sản; bãi thải, xử lý chất thải và các nguồn ô nhiễm khác đối với điều tra, đánh giá ô nhiễm đất cấp tỉnh;
c) Xây dựng báo cáo kết quả điều tra, khảo sát sơ bộ.

## Điều 26. Đánh giá, lựa chọn các thông tin, tài liệu, số liệu, bản đồ đã thu thập&nbsp;     ^dieu-26
1. Tổng hợp, phân tích, đánh giá tính chính xác, khách quan, thời sự của thông tin, tài liệu, số liệu, bản đồ đã thu thập theo quy định tại khoản 1 Điều 10 của Thông tư này.
2. Lựa chọn những thông tin, tài liệu, số liệu, bản đồ có thể sử dụng.
3. Xây dựng báo cáo kết quả thu thập thông tin, tài liệu, số liệu, bản đồ.

## Điều 27. Xác định nội dung và kế hoạch điều tra thực địa&nbsp;     ^dieu-27
1. Chuẩn bị bản đồ điều tra thực địa
a) Biên tập, chuẩn hóa các yếu tố kế thừa từ bản đồ hiện trạng sử dụng đất theo quy định tại Điều 5 của Thông tư này;
b) Tạo lập lớp thông tin khoanh đất điều tra ô nhiễm, lớp thông tin điểm điều tra ô nhiễm và các trường thông tin dữ liệu thuộc tính theo quy định tại Phần D của Phụ lục IV ban hành kèm theo Thông tư này;
c) Xác định số lượng điểm điều tra, lấy mẫu đất; khoanh đất điều tra theo quy định tại Mục I Phần B Phụ lục IV ban hành kèm theo Thông tư này;
d) Xây dựng lớp thông tin khoanh đất điều tra
Đối với điều tra, đánh giá ô nhiễm đất cấp vùng thực hiện như sau: chuyển đổi, rà soát, chuẩn hóa và nhập thông tin thuộc tính về loại đất, đơn vị hành chính cấp xã vào lớp thông tin tại điểm b khoản này từ các thông tin, tài liệu, số liệu thu thập; xác định ranh giới khoanh đất và số thứ tự khoanh đất theo quy định tại điểm b và điểm c khoản 2 Điều 5 của Thông tư này.
Đối với điều tra, đánh giá ô nhiễm đất cấp tỉnh thực hiện như sau: chuyển đổi, rà soát, chuẩn hóa và nhập thông tin thuộc tính về nguồn ô nhiễm, loại đất vào lớp thông tin tại điểm b khoản này từ các thông tin, tài liệu, số liệu thu thập; xác định ranh giới khoanh đất và số thứ tự khoanh đất theo quy định tại điểm b và điểm c khoản 2 Điều 5 của Thông tư này;
đ) Xây dựng lớp thông tin điểm điều tra: xác định vị trí điểm điều tra theo quy định tại điểm d khoản 2 Điều 5 của Thông tư này; xây dựng sơ đồ mạng lưới điểm điều tra theo quy định tại Mục II Phần A Phụ lục IV ban hành kèm theo Thông tư này và nhập thông tin thuộc tính vào lớp thông tin tại điểm b khoản này;
e) Xác định nội dung điều tra khoanh đất theo các tuyến điều tra thực địa trên địa bàn cấp tỉnh;
g) Cập nhật thông tin thuộc tính của lớp điểm điều tra và kết quả điều tra, đánh giá ô nhiễm đất kỳ trước (nếu có) vào lớp thông tin khoanh đất điều tra;
h) Biên tập và in bản đồ điều tra thực địa.
2. Thống kê số lượng khoanh đất và đặc trưng của khoanh đất điều tra theo Mẫu số 01/ONĐ và Mẫu số 02/ONĐ của Phụ lục IV ban hành kèm theo Thông tư này; tạo lập bảng dữ liệu phục vụ nhập thông tin kết quả điều tra thực địa theo tại Mẫu số 05/ONĐ và Mẫu số 06/ONĐ của Phụ lục IV ban hành kèm theo Thông tư này.
3. Chuẩn bị bản mô tả kết quả điều tra, phiếu lấy mẫu đất theo Mẫu số 03/ONĐ và Mẫu số 04/ONĐ của Phụ lục IV ban hành kèm theo Thông tư này.
4. Xây dựng báo cáo kế hoạch điều tra thực địa.

## Điều 28. Điều tra, lấy mẫu phục vụ đánh giá ô nhiễm đất     ^dieu-28
1. Đối với điều tra, đánh giá ô nhiễm cấp vùng
a) Khoanh vùng xác định và chỉnh lý ranh giới các khoanh đất theo các tác nhân gây ảnh hưởng đến đất từ lượng phân bón vô cơ, hóa chất BVTV, thức ăn và hóa chất dùng trong nuôi trồng thủy sản hoặc nguồn nước tưới bị ô nhiễm và mô tả kết quả điều tra vào bản mô tả đã chuẩn bị tại khoản 3 Điều 27 của Thông tư này;
b) Xác định vị trí điểm lấy mẫu đất tại thực địa, tọa độ điểm lấy mẫu đất được xác định bằng thiết bị định vị; cập nhật bổ sung vị trí điểm lấy mẫu lên bản đồ điều tra thực địa (nếu có sự thay đổi);
c) Lấy mẫu đất;
d) Chụp ảnh cảnh quan khu vực điều tra, điểm lấy mẫu đất;
đ) Viết phiếu lấy mẫu đất;
e) Đóng gói và bảo quản mẫu đất;
g) Rà soát, cập nhật kết quả điều tra thực địa tại các điểm a, b, c, d và đ khoản này vào bảng dữ liệu điều tra đã tạo lập tại khoản 2 Điều 27 của Thông tư này;
h) Xây dựng báo cáo kết quả điều tra, lấy mẫu đất tại thực địa.
2. Đối với điều tra, đánh giá ô nhiễm cấp tỉnh
a) Điều tra xác định hướng lan tỏa ô nhiễm; điều tra xác định các yếu tố địa hình, địa vật có khả năng ngăn cản hoặc chặn hướng lan tỏa ô nhiễm; khoanh vùng xác định và chỉnh lý ranh giới các khoanh đất theo các nguồn gây ô nhiễm đất, tác nhân gây ô nhiễm và mô tả kết quả điều tra vào bản mô tả đã chuẩn bị tại khoản 3 Điều 27 của Thông tư này;
b) Điều tra, lấy mẫu đất, cập nhật kết quả điều tra thực địa quy định tại các điểm b, c, d, đ, e và g khoản 1 Điều này;
c) Xây dựng báo cáo kết quả điều tra, lấy mẫu đất tại thực địa;
d) Việc điều tra các nội dung theo quy định tại khoản này chỉ thực hiện đối với các khu vực chưa có kết quả điều tra, đánh giá, phân loại ô nhiễm môi trường đất theo quy định của pháp luật về bảo vệ môi trường.

## Điều 29. Tổng hợp, xử lý thông tin nội nghiệp và ngoại nghiệp     ^dieu-29
1. Tổng hợp, xử lý sau điều tra thực địa
a) Rà soát, đối chiếu, chỉnh lý, bổ sung thông tin đảm bảo tính chính xác, thống nhất về kết quả điều tra giữa bản đồ điều tra thực địa với phiếu lấy mẫu đất; ảnh điều tra và bảng dữ liệu điều tra;
b) Lập bảng thống kê danh sách mẫu đất, lựa chọn chỉ tiêu phân tích; bàn giao mẫu đất cho đơn vị phân tích.
2. Phân tích mẫu đất
Chỉ tiêu phân tích gồm các chỉ tiêu kim loại nặng (Cu, Pb, Zn, Cd, As, Cr, Hg, Ni). Đối với điều tra, đánh giá ô nhiễm đất cấp vùng phân tích thêm các chỉ tiêu nhóm hóa chất BVTV phốt pho hữu cơ.
Phương pháp phân tích theo quy định tại Mục III Phần A của Phụ lục IV ban hành kèm theo Thông tư này.
3. Tổng hợp, xử lý thông tin phục vụ đánh giá ô nhiễm đất
a) Xác định và phân cấp chỉ tiêu đánh giá ô nhiễm đất theo quy định tại Mục 1 Phần C của Phụ lục IV ban hành kèm theo Thông tư này;
b) Tổng hợp, đánh giá kết quả phân tích mẫu đất theo khoanh đất, điểm điều tra.
4. Xây dựng báo cáo kết quả tổng hợp, xử lý thông tin nội và ngoại nghiệp.

## Điều 30. Xây dựng bản đồ đất bị ô nhiễm&nbsp;     ^dieu-30
1. Chuẩn hóa các yếu tố nền của bản đồ đất bị ô nhiễm theo quy định tại điểm a và điểm c khoản 2, điểm a và điểm d khoản 3 Điều 6 của Thông tư này.
2. Tạo lập các lớp thông tin và trường thông tin dữ liệu thuộc tính trong mỗi lớp thông tin chuyên đề theo cấu trúc, kiểu thông tin quy định tại Phần D của Phụ lục IV ban hành kèm theo Thông tư này, bao gồm:
a) Lớp thông tin loại đất;
b) Lớp thông tin phân mức ô nhiễm;
c) Lớp thông tin khoanh vùng các khu vực cần xử lý, cải tạo và phục hồi đất.
3. Xây dựng lớp thông tin loại đất
a) Chuyển đổi định dạng dữ liệu từ bản đồ hiện trạng sử dụng đất cùng cấp với bản đồ kết quả điều tra, đánh giá ô nhiễm đất;
b) Rà soát chỉnh lý ranh giới khoanh đất theo kết quả điều tra thực địa;
c) Chuẩn hóa và nhập các thông tin loại đất quy định tại Bảng số 03/QĐC của Phụ lục I ban hành kèm theo Thông tư này vào lớp thông tin tại điểm a khoản 2 Điều này.
4. Rà soát, chỉnh lý ranh giới khoanh đất điều tra trong lớp thông tin khoanh đất của bản đồ điều tra thực địa quy định tại khoản 1 Điều 27 của Thông tư này theo kết quả tổng hợp xử lý thông tin tại khoản 3 Điều 29 của Thông tư này.
5. Xây dựng bản đồ đất bị ô nhiễm
a) Xây dựng lớp thông tin phân mức ô nhiễm theo chỉ tiêu quy định tại điểm a khoản 3 Điều 29 của Thông tư này;
b) Xuất dữ liệu phục vụ phân tích, đánh giá thực trạng đất bị ô nhiễm;
c) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ đất bị ô nhiễm;
d) Trình tự xây dựng bản đồ đất bị ô nhiễm minh họa chi tiết tại Sơ đồ số 02/ONĐ của Phụ lục IV ban hành kèm theo Thông tư này.
6. Khoanh vùng các khu vực đất bị ô nhiễm cần thực hiện xử lý, cải tạo và phục hồi
a) Xác định các khu vực đất bị ô nhiễm từ kết quả phân mức ô nhiễm tại điểm a khoản 5 Điều này;
b) Chuyển ranh giới và nhập các thông tin thuộc tính các khu vực đất cần xử lý, cải tạo và phục hồi vào lớp thông tin tại điểm c khoản 2 Điều này.
7. Xây dựng dữ liệu ô nhiễm đất
a) Chuẩn hóa dữ liệu liên quan đến ô nhiễm đất theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai;
b) Quét các dữ liệu khác có liên quan.
8. Cập nhật dữ liệu về ô nhiễm đất vào cơ sở dữ liệu quốc gia về đất đai theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai.

## Điều 31. Phân tích đánh giá thực trạng, nguyên nhân ô nhiễm đất, đề xuất giải pháp giảm thiểu ô nhiễm đất     ^dieu-31
1. Tổng hợp, phân tích, đánh giá thực trạng, nguyên nhân ô nhiễm đất
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá ô nhiễm đất theo quy định tại điểm d khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá thực trạng, nguyên nhân ô nhiễm đất theo loại đất;
c) Đánh giá kết quả thực hiện các biện pháp kỹ thuật, giải pháp kinh tế, xã hội trong xử lý, cải tạo và phục hồi đất bị ô nhiễm đã thực hiện (nếu có).
2. Cảnh báo, dự báo nguy cơ ô nhiễm đất.
3. Đề xuất các giải pháp giảm thiểu ô nhiễm đất.

## Điều 32. Xây dựng báo cáo kết quả điều tra, đánh giá ô nhiễm đất     ^dieu-32
1. Xây dựng các phụ lục, bản đồ thu nhỏ đính kèm báo cáo.
2. Biên soạn báo cáo tổng hợp kết quả điều tra, đánh giá ô nhiễm đất.
3. Xây dựng báo cáo tóm tắt, báo cáo tổng kết nhiệm vụ.

## Điều 33. Điều tra, đánh giá chất lượng đất cả nước     ^dieu-33
Kết quả điều tra, đánh giá chất lượng đất cả nước được tổng hợp, khái quát hóa từ kết quả điều tra, đánh giá chất lượng đất cấp vùng theo quy định tại Chương II như sau:
1. Xây dựng bản đồ chất lượng đất
a) Tích hợp, tiếp biên bản đồ chất lượng đất của các vùng kinh tế - xã hội tỷ lệ 1:250.000;
b) Tổng hợp, khái quát hóa các nội dung bản đồ chất lượng đất của cả nước tỷ lệ 1:1.000.000;
c) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ chất lượng đất cả nước.
2. Phân tích, đánh giá chất lượng đất cả nước
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá chất lượng đất theo quy định tại điểm a khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá các quá trình hình thành, biến đổi chất lượng đất;
c) Phân tích, đánh giá ảnh hưởng của điều kiện tự nhiên, kinh tế - xã hội, tình hình quản lý và sử dụng đất đến chất lượng đất;
d) Phân tích, đánh giá thực trạng chất lượng đất theo loại đất;
đ) Tổng hợp đánh giá chất lượng đất cả nước.

## Điều 34. Điều tra, đánh giá tiềm năng đất đai cả nước     ^dieu-34
Kết quả điều tra, đánh giá tiềm năng đất đai cả nước được tổng hợp, khái quát hóa từ kết quả điều tra, đánh giá tiềm năng đất đai cấp vùng theo quy định tại Chương II như sau:
1. Xây dựng bản đồ tiềm năng đất đai cả nước
a) Tích hợp, tiếp biên bản đồ tiềm năng đất đai của các vùng kinh tế - xã hội tỷ lệ 1:250.000;
b) Tổng hợp, khái quát hóa các nội dung bản đồ tiềm năng đất đai của cả nước tỷ lệ 1:1.000.000;
c) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ tiềm năng đất đai cả nước.
2. Phân tích, đánh giá tiềm năng đất đai cả nước
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá tiềm năng đất đai theo quy định tại điểm b khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá ảnh hưởng của điều kiện tự nhiên, kinh tế - xã hội, tình hình quản lý và sử dụng đất đến tiềm năng đất đai;
c) Phân tích, đánh giá hiệu quả sử dụng đất (hiệu quả kinh tế, xã hội và môi trường);
d) Phân tích, đánh giá thực trạng tiềm năng đất đai theo loại đất;
đ) Tổng hợp đánh giá tiềm năng đất đai cả nước.

## Điều 35. Điều tra, đánh giá thoái hóa đất cả nước     ^dieu-35
Kết quả điều tra, đánh giá thoái hóa đất cả nước được tổng hợp, khái quát hóa từ kết quả điều tra, đánh giá thoái hóa đất cấp vùng theo quy định tại Chương III như sau:
1. Xây dựng bản đồ thoái hóa đất
a) Tích hợp, tiếp biên bản đồ thoái hóa đất của các vùng kinh tế - xã hội tỷ lệ 1:250.000;
b) Tổng hợp, khái quát hóa các nội dung bản đồ thoái hóa đất của cả nước tỷ lệ 1:1.000.000;
c) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ thoái hóa đất cả nước.
2. Phân tích, đánh giá thoái hóa đất cả nước
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá thoái hóa đất theo quy định tại điểm c khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá ảnh hưởng của điều kiện tự nhiên, kinh tế - xã hội, tình hình quản lý và sử dụng đất đến thoái hóa đất;
c) Phân tích, đánh giá thoái hóa đất theo loại hình thoái hóa và loại đất thoái hóa;
d) Tổng hợp đánh giá thoái hóa đất cả nước.

## Điều 36. Điều tra, đánh giá ô nhiễm đất cả nước     ^dieu-36
Kết quả điều tra, đánh giá ô nhiễm đất cả nước được tổng hợp, khái quát hóa từ kết quả điều tra, đánh giá ô nhiễm đất cấp vùng theo quy định tại Chương IV như sau:
1. Xây dựng bản đồ ô nhiễm đất
a) Tích hợp, tiếp biên bản đồ ô nhiễm đất của các vùng kinh tế - xã hội tỷ lệ 1:250.000;
b) Tổng hợp, khái quát hóa các nội dung bản đồ ô nhiễm đất của cả nước tỷ lệ 1:1.000.000;
c) Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ ô nhiễm đất cả nước.
2. Phân tích, đánh giá ô nhiễm đất cả nước
a) Tổng hợp hệ thống biểu kết quả điều tra, đánh giá ô nhiễm đất theo quy định tại điểm d khoản 4 Điều 6 của Thông tư này;
b) Phân tích, đánh giá ô nhiễm đất theo loại đất;
c) Tổng hợp đánh giá ô nhiễm đất cả nước.

## Điều 37. Xây dựng báo cáo tổng hợp kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai; thoái hóa đất; ô nhiễm đất cả nước     ^dieu-37
1. Xây dựng các phụ lục, bản đồ thu nhỏ đính kèm báo cáo.
2. Biên soạn báo cáo tổng hợp kết quả điều tra, đánh giá chất lượng đất, tiềm năng đất đai; thoái hóa đất; ô nhiễm đất cả nước.
3. Xây dựng báo cáo tóm tắt.

## Điều 38. Xây dựng mạng lưới các điểm quan trắc cố định trên phạm vi cả nước và xác định chỉ tiêu, tần suất quan trắc     ^dieu-38
1. Xây dựng mạng lưới các điểm quan trắc cố định trên phạm vi cả nước được thực hiện như sau:
a) Xác định các điểm quan trắc cố định theo nguyên tắc, tiêu chí quy định tại Phần A của Phụ lục V ban hành kèm theo Thông tư này và lập sơ đồ mạng lưới các điểm quan trắc cố định trên phạm vi cả nước được thể hiện trên nền bản đồ hiện trạng sử dụng đất cấp vùng tỷ lệ 1:250.000;
b) Lập danh mục các điểm quan trắc cố định trên phạm vi cả nước theo Mẫu số 03/QTĐ của Phụ lục V ban hành kèm theo Thông tư này;
c) Tạo lập bảng dữ liệu phục vụ nhập thông tin kết quả điều tra thực địa theo Mẫu số 04/QTĐ của Phụ lục V ban hành kèm theo Thông tư này.
2. Xác định chỉ tiêu, tần suất quan trắc, bao gồm:
a) Chỉ tiêu quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất theo quy định tại Phần C của Phụ lục V ban hành kèm theo Thông tư này;
b) Tần suất quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất được thực hiện hằng năm. Trường hợp xảy ra sự cố do thiên tai hoặc hoạt động của con người có nguy cơ làm cho đất bị ô nhiễm hoặc suy thoái bất thường thì thực hiện việc quan trắc đột xuất theo yêu cầu của cơ quan nhà nước có thẩm quyền.

## Điều 39. Điều tra, lấy mẫu, phân tích mẫu quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất     ^dieu-39
1. Điều tra, lấy mẫu quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất
a) Chuẩn bị các điều kiện cần thiết để phục vụ công tác điều tra, lấy mẫu quan trắc, bao gồm: chuẩn bị về nhân lực, vật tư, thiết bị, dụng cụ, tài liệu; lập kế hoạch chi tiết điều tra, lấy mẫu quan trắc theo từng vùng; xây dựng báo cáo kế hoạch điều tra, lấy mẫu quan trắc;
b) Tổ chức điều tra, lấy mẫu quan trắc ngoài thực địa và thực hiện bảo quản mẫu đất. Phương pháp điều tra, lấy mẫu quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất và bảo quản mẫu đất theo quy định tại Phần B của Phụ lục V ban hành kèm theo Thông tư này;
c) Rà soát, cập nhật kết quả điều tra thực địa vào bảng dữ liệu điều tra theo Mẫu số 04/QTĐ của Phụ lục V ban hành kèm theo Thông tư này;
d) Rà soát, phân loại, lập danh mục mẫu đất và lập bảng các chỉ tiêu phân tích;
đ) Bàn giao mẫu đất cho đơn vị phân tích;
e) Xây dựng báo cáo kết quả điều tra, lấy mẫu quan trắc tại thực địa theo từng vùng.
2. Thực hiện phân tích mẫu đất. Phương pháp phân tích mẫu đất theo quy định tại Mục III Phần A của Phụ lục II và Mục III Phần A của Phụ lục IV ban hành kèm theo Thông tư này.

## Điều 40. Theo dõi biến động chất lượng đất, thoái hóa đất, ô nhiễm đất và dự báo, cảnh báo sớm các biến đổi bất thường&nbsp;     ^dieu-40
1. Tổng hợp hệ thống biểu kết quả quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất theo quy định tại điểm đ khoản 4 Điều 6 của Thông tư này.
2. So sánh với kết quả quan trắc của lần trước liền kề (nếu có) để phân tích, đánh giá sự biến động về chất lượng đất, thoái hóa đất, ô nhiễm đất
a) Lập biểu so sánh kết quả quan trắc của năm hiện tại với năm trước liền kề hoặc của lần quan trắc đột xuất gần nhất;
b) Phân tích, đánh giá sự biến động, xu hướng biến đổi về chất lượng đất, thoái hóa đất, ô nhiễm đất.
3. Xác định và cảnh báo sớm các khu vực có điểm quan trắc xuất hiện sự biến đổi bất thường về chất lượng đất, thoái hóa đất, ô nhiễm đất.
4. Xác định nguyên nhân và đề xuất giải pháp cần thực hiện tại những khu vực có điểm quan trắc đất xuất hiện sự biến đổi bất thường về chất lượng đất, thoái hóa đất, ô nhiễm đất tại khoản 3 Điều này.
5. Rà soát hệ thống các điểm quan trắc, thay thế hoặc bổ sung các điểm quan trắc (nếu có) theo nguyên tắc, tiêu chí quy định tại Phần A của Phụ lục V ban hành kèm theo Thông tư này.
6. Xây dựng báo cáo kết quả quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất theo Mẫu số 05/QTĐ của Phụ lục V ban hành kèm theo Thông tư này.

## Điều 41. Cập nhật dữ liệu quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất vào cơ sở dữ liệu quan trắc tài nguyên môi trường và cơ sở dữ liệu quốc gia về đất đai     ^dieu-41
1. Chuẩn hóa dữ liệu liên quan đến quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất theo quy định của pháp luật về cơ sở dữ liệu quan trắc tài nguyên môi trường và cơ sở dữ liệu quốc gia về đất đai; quét các dữ liệu khác có liên quan.
2. Cập nhật dữ liệu về quan trắc chất lượng đất, thoái hóa đất, ô nhiễm đất vào cơ sở dữ liệu quan trắc tài nguyên môi trường và cơ sở dữ liệu quốc gia về đất đai.

## Điều 42. Phân loại các khu vực bảo vệ, cải tạo, phục hồi đất&nbsp;     ^dieu-42
1. Thu thập và xử lý thông tin, tài liệu số liệu
a) Kết quả khoanh vùng các khu vực đất bị thoái hóa, đất bị ô nhiễm cần bảo vệ, cải tạo, phục hồi theo quy định tại khoản 12 Điều 22 và khoản 6 Điều 30 của Thông tư này;
b) Các biện pháp, giải pháp đến từng khu vực cần bảo vệ, cải tạo, phục hồi đất đã đề xuất theo quy định tại khoản 3 Điều 23 và khoản 3 Điều 31 của Thông tư này;
c) Các dự án, đề án, phương án đã thực hiện bảo vệ, cải tạo, phục hồi đất trên địa bàn (nếu có);
d) Tổng hợp diện tích các khu vực đất bị thoái hóa; đất bị ô nhiễm cần bảo vệ, cải tạo, phục hồi đất theo Mẫu số 30/QĐC và Mẫu số 31/QĐC của Phụ lục I ban hành kèm theo Thông tư này;
đ) Tổng hợp các biện pháp kỹ thuật, giải pháp kinh tế, xã hội đến từng khu vực cần bảo vệ, cải tạo, phục hồi đất theo Mẫu số 32/QĐC của Phụ lục I ban hành kèm theo Thông tư này.
2. Phân loại các khu vực đất cần bảo vệ, cải tạo, phục hồi
a) Phân loại đất bị thoái hóa, đất bị ô nhiễm theo loại đất;
b) Phân loại mức độ đất bị thoái hóa, đất bị ô nhiễm theo loại hình thoái hóa, loại hình ô nhiễm;
c) Phân loại các biện pháp kỹ thuật, giải pháp kinh tế, xã hội đã đề xuất khi thực hiện điều tra, đánh giá đất đai đối với các khu vực đất bị thoái hóa, đất bị ô nhiễm theo loại hình, mức độ thoái hóa, ô nhiễm.

## Điều 43. Tổng hợp, xác định phạm vi và mức độ cần bảo vệ, cải tạo, phục hồi đất     ^dieu-43
1. Xác định phạm vi khu vực đất bị thoái hóa cần bảo vệ, cải tạo, phục hồi theo loại hình thoái hóa theo Mẫu số 33/QĐC của Phụ lục I ban hành kèm theo Thông tư này và xác định các mức độ cần bảo vệ, cải tạo, phục hồi đất bị thoái hóa theo quy định tại Bảng số 02/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này.
2. Xác định phạm vi khu vực đất bị ô nhiễm và mức độ cần bảo vệ, cải tạo, phục hồi theo quy định của pháp luật về bảo vệ môi trường.
3. Tổng hợp các khu vực đất cần bảo vệ, cải tạo, phục hồi theo Mẫu số 34/QĐC của Phụ lục I ban hành kèm theo Thông tư này.

## Điều 44. Xây dựng kế hoạch bảo vệ, cải tạo, phục hồi đất     ^dieu-44
1. Xác định căn cứ pháp lý, sự cần thiết, quan điểm, mục tiêu, yêu cầu của kế hoạch bảo vệ, cải tạo, phục hồi đất.
2. Xác định nội dung, khối lượng các nhiệm vụ bảo vệ, cải tạo, phục hồi đất
a) Xác định nội dung công việc thực hiện cho từng khu vực cần bảo vệ, cải tạo, phục hồi đất trên địa bàn;
b) Xác định khối lượng công việc thực hiện cho từng khu vực cần bảo vệ, cải tạo, phục hồi đất trên địa bàn theo các biện pháp kỹ thuật, giải pháp kinh tế, xã hội theo Mẫu số 35/QĐC của Phụ lục I ban hành kèm theo Thông tư này.
3. Đề xuất các nhiệm vụ, chương trình, dự án theo thứ tự ưu tiên để thực hiện kế hoạch bảo vệ, cải tạo, phục hồi các khu vực đất bị thoái hoá, đất bị ô nhiễm quy định tại khoản 1 và khoản 2 Điều 43 của Thông tư này.
4. Xác định lộ trình thực hiện các nhiệm vụ, chương trình, dự án cho từng khu vực bảo vệ, cải tạo, phục hồi đất quy định tại các khoản 1, 2 và 3 Điều này, bao gồm:
a) Xác định nguồn kinh phí thực hiện kế hoạch;
b) Xác định lộ trình thực hiện kế hoạch;
c) Xác định trách nhiệm của các cơ quan, tổ chức, cá nhân liên quan;
d) Xác định cơ chế giám sát, báo cáo thực hiện.
5. Tổng hợp, hoàn thiện hồ sơ xây dựng kế hoạch bảo vệ, cải tạo, phục hồi đất bị thoái hoá; đất bị ô nhiễm.
6. Trình phê duyệt kế hoạch bảo vệ, cải tạo, phục hồi đất.

## Điều 45. Xác định các biện pháp kỹ thuật, giải pháp kinh tế, xã hội để thực hiện nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất     ^dieu-45
1. Xác định các biện pháp kỹ thuật, giải pháp kinh tế, xã hội cần áp dụng đến từng khu vực cần xử lý, bảo vệ, cải tạo, phục hồi đất bị thoái hóa theo quy định tại Bảng số 01/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này, bao gồm:
a) Xác định, phân tích các biện pháp kỹ thuật, giải pháp kinh tế, xã hội và lựa chọn các phương án tối ưu;
b) Quyết định phương án thực hiện các biện pháp kỹ thuật, giải pháp kinh tế, xã hội đến từng khu vực cần xử lý, bảo vệ, cải tạo, phục hồi đất bị thoái hóa.
2. Xác định các biện pháp kỹ thuật, giải pháp kinh tế, xã hội đến từng khu vực cần xử lý, bảo vệ, cải tạo, phục hồi đất bị ô nhiễm theo quy định của pháp luật về bảo vệ môi trường.

## Điều 46. Thực hiện nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất     ^dieu-46
1. Tổ chức, triển khai các biện pháp kỹ thuật, giải pháp kinh tế, xã hội theo nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất đã được phê duyệt.
2. Đánh giá kết quả thực hiện nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất, bao gồm:
a) Đánh giá khối lượng, chất lượng, tiến độ thực hiện nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất đã được phê duyệt;
b) Đánh giá kết quả thực hiện nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất quy định tại điểm c khoản 1 Điều 47 của Thông tư này.
3. Lập hồ sơ tổng kết nhiệm vụ xử lý, bảo vệ, cải tạo, phục hồi đất, bao gồm:
a) Xây dựng các phụ lục, bảng biểu, số liệu;
b) Lập báo cáo kết quả bảo vệ, cải tạo, phục hồi đất theo Mẫu số 04/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này;
c) Xây dựng báo cáo tóm tắt, báo cáo tổng kết nhiệm vụ;
d) Các văn bản, tài liệu khác có liên quan.

## Điều 47. Giám sát, kiểm soát quá trình xử lý, bảo vệ, cải tạo, phục hồi đất     ^dieu-47
1. Giám sát, kiểm soát quá trình xử lý, bảo vệ, cải tạo, phục hồi đất đối với các khu vực đất bị thoái hóa theo nhiệm vụ đã được phê duyệt
a) Giám sát, kiểm soát việc thực hiện các biện pháp kỹ thuật, giải pháp kinh tế, xã hội đối với các khu vực đất cần xử lý, bảo vệ, cải tạo, phục hồi về chất lượng, khối lượng và các chỉ tiêu kỹ thuật trong thi công các công trình theo yêu cầu của nhiệm vụ đã được phê duyệt;
b) Giám sát, kiểm soát về tiến độ triển khai nhiệm vụ đã được phê duyệt;
c) Giám sát, kiểm soát kết quả xử lý, bảo vệ, cải tạo, phục hồi đất của từng nhiệm vụ để đánh giá mức độ phục hồi đất được thực hiện theo quy định tại Bảng số 03/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này;
d) Đề xuất điều chỉnh biện pháp kỹ thuật, giải pháp kinh tế, xã hội trong trường hợp không đáp ứng được các nội dung quy định tại khoản 2 và khoản 5 Điều 8 của Thông tư này.
2. Giám sát, kiểm soát quá trình xử lý, cải tạo, phục hồi đất đối với các khu vực đất bị ô nhiễm thực hiện theo quy định của pháp luật về bảo vệ môi trường.

## Điều 48. Lập bản đồ kết quả bảo vệ, cải tạo, phục hồi đất&nbsp;     ^dieu-48
1. Chuẩn bị bản đồ nền để lập bản đồ kết quả bảo vệ, cải tạo, phục hồi đất theo quy định tại điểm b khoản 2, điểm a và điểm d khoản 3 Điều 6 của Thông tư này.
2. Tạo lập các trường thông tin dữ liệu thuộc tính cho các lớp thông tin theo từng khu vực cần bảo vệ, cải tạo, phục hồi đất. Nội dung, cấu trúc, kiểu thông tin theo quy định tại Bảng số 05/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này
a) Lớp thông tin về các khu vực cần bảo vệ, cải tạo, phục hồi đất theo quy định tại khoản 12 Điều 22 của Thông tư này;
b) Lớp thông tin về mức độ bảo vệ, cải tạo, phục hồi đất;
c) Lớp thông tin về kế hoạch thực hiện bảo vệ, cải tạo, phục hồi đất;
d) Lớp thông tin về kết quả giám sát, kiểm soát quá trình xử lý, bảo vệ, cải tạo, phục hồi đất;
đ) Lớp thông tin về kết quả bảo vệ, cải tạo, phục hồi đất;
e) Lớp thông tin khoanh vùng, cảnh báo không cho phép hoặc hạn chế hoạt động trên đất.
3. Rà soát, chỉnh lý ranh giới và nhập thông tin thuộc tính vào các lớp thông tin đã tạo lập tại khoản 2 Điều này.
4. Chồng xếp các lớp thông tin tại khoản 3 Điều này để thành lập lớp thông tin kết quả bảo vệ, cải tạo, phục hồi đất đến từng khu vực.
5. Xác định diện tích đất đã được bảo vệ, cải tạo, phục hồi.
6. Biên tập, xây dựng báo cáo thuyết minh bản đồ và in bản đồ kết quả bảo vệ, cải tạo, phục hồi đất.
7. Xây dựng dữ liệu về bảo vệ, cải tạo, phục hồi đất
a) Chuẩn hóa dữ liệu liên quan đến bảo vệ, cải tạo, phục hồi đất theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai;
b) Quét các dữ liệu khác có liên quan.
8. Cập nhật dữ liệu về bảo vệ, cải tạo, phục hồi đất vào cơ sở dữ liệu quốc gia về đất đai theo quy định của pháp luật về cơ sở dữ liệu quốc gia về đất đai.
9. Trình tự xây dựng bản đồ kết quả bảo vệ, cải tạo, phục hồi đất quy định từ khoản 1 đến khoản 6 Điều này minh họa chi tiết tại Sơ đồ 02/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này.

## Điều 49. Đánh giá kết quả thực hiện kế hoạch và kiểm soát các khu vực đất bị thoái hóa, đất bị ô nhiễm chưa được bảo vệ, cải tạo, phục hồi     ^dieu-49
1. Thống kê, tổng hợp kết quả thực hiện việc bảo vệ, cải tạo, phục hồi đất theo kế hoạch theo Mẫu số 36/QĐC của Phụ lục I ban hành kèm theo Thông tư này.
2. Thống kê các khu vực đất bị thoái hoá, đất bị ô nhiễm chưa được bảo vệ, cải tạo, phục hồi đất theo kế hoạch bảo vệ, cải tạo, phục hồi đất được duyệt theo Mẫu số 37/QĐC của Phụ lục I ban hành kèm theo Thông tư này.
3. Xây dựng báo cáo kết quả thực hiện kế hoạch bảo vệ, cải tạo, phục hồi đất, bao gồm:
a) Xây dựng các phụ lục, bảng biểu;
b) Đề xuất các khu vực cảnh báo không cho phép hoặc hạn chế hoạt động trên đất nhằm giảm thiểu tác động xấu đến đất;
c) Lập báo cáo kết quả thực hiện kế hoạch bảo vệ, cải tạo, phục hồi đất theo Mẫu số 03/BVĐ của Phụ lục VI ban hành kèm theo Thông tư này.

## Điều 50. Quy định về điều tra, đánh giá đất đai theo chuyên đề     ^dieu-50
1. Kỹ thuật điều tra, đánh giá về chất lượng đất, tiềm năng đất đai theo chuyên đề đối với loại đất cụ thể thực hiện theo quy định tại Chương II của Thông tư này.
2. Kỹ thuật điều tra, đánh giá thoái hóa đất theo chuyên đề đối với loại đất cụ thể thực hiện theo quy định tại Chương III của Thông tư này.
3. Kỹ thuật điều tra, đánh giá ô nhiễm đất theo chuyên đề đối với loại đất cụ thể thực hiện theo quy định tại Chương IV của Thông tư này.
4. Quy mô, phạm vi thực hiện điều tra, đánh giá đất đai theo chuyên đề do cơ quan Nhà nước có thẩm quyền quyết định tổ chức thực hiện việc điều tra, đánh giá đất đai theo chuyên đề xác định trong nhiệm vụ khi phê duyệt.

## Điều 51. Quy định chuyển tiếp     ^dieu-51
Đối với hệ thống điểm quan trắc tài nguyên đất quốc gia trên địa bàn các vùng kinh tế - xã hội đã được Bộ trưởng Bộ Tài nguyên và Môi trường phê duyệt trước ngày Thông tư này có hiệu lực được sử dụng để rà soát, điều chỉnh, bổ sung xây dựng mạng lưới các điểm quan trắc cố định trên phạm vi cả nước theo quy định tại khoản 1 Điều 38 của Thông tư này.

## Điều 52. Hiệu lực thi hành     ^dieu-52
1. Thông tư này có hiệu lực thi hành kể từ ngày 01 tháng 8 năm 2024.
2. Các thông tư sau đây hết hiệu lực kể từ ngày Thông tư này có hiệu lực thi hành:
a) Thông tư số 14/2012/TT-BTNMT ngày 26 tháng 11 năm 2012 của Bộ trưởng Bộ Tài nguyên và Môi trường ban hành Quy định kỹ thuật điều tra thoái hoá đất;
b) Thông tư số 35/2014/TT-BTNMT ngày 30 tháng 6 năm 2014 của Bộ trưởng Bộ Tài nguyên và Môi trường Quy định việc điều tra, đánh giá đất đai;
c) Thông tư số 60/2015/TT-BTNMT ngày 15 tháng 12 năm 2015 của Bộ trưởng Bộ Tài nguyên và Môi trường Quy định về kỹ thuật điều tra, đánh giá đất đai.
3. Cục trưởng Cục Quy hoạch và Phát triển tài nguyên đất, Chủ tịch Ủy ban nhân dân các tỉnh, thành phố trực thuộc Trung ương, Giám đốc Sở Tài nguyên và Môi trường cấp tỉnh, Thủ trưởng các đơn vị thuộc Bộ Tài nguyên và Môi trường và các tổ chức, cá nhân có liên quan chịu trách nhiệm thi hành Thông tư này.
Trong quá trình thực hiện, nếu có khó khăn, vướng mắc, đề nghị các cơ quan, tổ chức, cá nhân phản ánh kịp thời về Bộ Tài nguyên và Môi trường để xem xét, quyết định./.
Nơi nhận:
- Thủ tướng Chính phủ và các Phó Thủ tướng Chính phủ;
- Văn phòng Chính phủ, các Bộ, cơ quan ngang bộ, cơ quan thuộc Chính phủ;
- HĐND, UBND các tỉnh, thành phố trực thuộc Trung ương;
- Văn phòng Trung ương Đảng và các Ban của Đảng;
- Văn phòng Tổng Bí thư;
- Văn phòng Chủ tịch nước;
- Hội đồng Dân tộc và các Ủy ban của Quốc hội;
- Văn phòng Quốc hội;
- Tòa án nhân dân tối cao;
- Viện Kiểm sát nhân dân tối cao;
- Kiểm toán Nhà nước;
- Ủy ban Trung ương Mặt trận Tổ quốc Việt Nam;
- Bộ trưởng, các Thứ trưởng Bộ Tài nguyên và Môi trường;
- Cục Kiểm tra văn bản QPPL, Bộ Tư pháp;
- Sở Tài nguyên và Môi trường các tỉnh, thành phố trực thuộc Trung ương;
- Công báo, Cổng TTĐT Chính phủ;
- Các đơn vị trực thuộc Bộ Tài nguyên và Môi trường, Cổng TTĐT Bộ Tài nguyên và Môi trường;
- Lưu: VT, QHPTTNĐ.
KT. BỘ TRƯỞNG
THỨ TRƯỞNG
(Đã ký)
Lê Minh Ngân
