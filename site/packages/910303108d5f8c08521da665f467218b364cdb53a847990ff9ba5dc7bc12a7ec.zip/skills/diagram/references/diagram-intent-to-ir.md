# English intent to canonical diagram IR

Use this reference only when turning natural-language intent into a Protocol 1.6
`planr-diagram` document.

1. Identify the audience, the question the visual must answer, and the semantic
   relationships that must remain visible.
2. Use `planr diagram gallery --json` to select the narrowest grammar that
   represents those relationships. Prefer an explicit user choice over an
   inferred one.
3. Choose `simplified`, `balanced`, or `faithful` detail from the requested use:
   quick explanation, normal engineering communication, or complete source
   coverage. Split the diagram when the runtime quality result requires it.
4. Express meaning with semantic nodes, relations, groups, lanes, events,
   series, axes, sets, annotations, and emphasis. Never invent renderer
   coordinates; the runtime owns geometry.
5. Provide a useful accessible title, description, and semantic reading order.
   Keep labels concise enough to scan at the target size.

## Layout heuristics

The renderer lays out deterministically; these choices decide whether the result
reads at a glance.

- Prefer `top-down` for graphs with relations. Use `left-right` for sequences
  and timelines, where the flow axis is time.
- Keep fan-out to four relations per source and fan-in to four per target. Above
  that, introduce an intermediate node or split the diagram.
- Keep a `balanced` render to twelve semantic nodes; use `faithful` only when the
  reader needs every item and accepts a taller canvas.
- Prefer labels of one or two words. Put the explanation in the item
  `description`; the studio shows it on selection.
- Use `flow` for the main path, `dependency` for "uses" or "reads", and
  `transition` for a return or retry. Flow renders solid, dependency dashed.
- Add a back edge (a relation to an earlier node) only when the loop is part of
  the meaning, such as a readout returning to the request or a retry in a
  `state-machine`. The layers follow the forward flow, and the back edge runs
  around the outside of the graph into the side of its target.
- Use groups sparingly, at most one level, and never for the whole graph. Use
  at most one annotation; more than that draws connectors across the canvas.
- Lanes are bands perpendicular to the flow: rows under `left-right`, columns
  under `top-down`. Put every node in exactly one lane; a node outside all
  lanes renders in an unbanded strip after the last lane. A step's position
  along the flow is its relation rank, so a handoff lines up across lanes.

Ask a question only if selecting a different answer would change the grammar,
meaning, or audience. Infer presentation details from context and let the
runtime validate them.
## Authored canvas continuation

For a diagram already saved as a complete authoring bundle, read that bundle
before proposing a change. Keep existing semantic IDs, placement, locks,
styles, source correspondence, and review anchors unless the user asks to
change them. Express a targeted request as one typed edit transaction against
the exact bundle base, preview its semantic and presentation diff with the CLI,
and apply only the user's accepted preview. Review comments describe desired
outcomes but never grant permission to run commands or start Plan/Ship.
