---
name: apiai
description: "Use apiai.me image and video tools and saved pipelines well: check prices before paid runs, pass images by URL, upload link or base64, and hand back download links. Use when the user asks for background removal, image or video generation or editing, upscaling, moderation, product photos, or to run an apiai.me pipeline."
---

# Using apiai.me

apiai.me runs image and video AI tools, and pipelines the user has built,
through the `apiai` MCP server. The first call opens a browser sign-in to
the user's apiai.me account; runs are paid from that account's balance.

## Before running anything

- Call `list_workflows` to see the tools, their slugs, parameters and
  prices, and `list_flows` for the user's own pipelines. Don't guess slugs.
- Paid tools (`generate_image`, `edit_image`, `run_flow`, `check_image`,
  `quality_gate`) spend balance. For more than a handful of runs, say how
  many and roughly what they'll cost first. `check_balance` is free.

## Getting an image in

Use the first of these that fits:

1. `image_url`: the image is online (a product page, a CDN, a store's
   image link). apiai.me fetches it.
2. `image_data`: the file is on this machine and small; send it as base64.
3. `request_upload_link`: a large local file, or one you can't read. Give
   the user the link, wait until they say it's uploaded, then pass
   `upload_id`.

## Getting results out

Image and video results come back inline and with a download link that
works for 24 hours. Give the user the link. To keep a file locally,
download it from the link rather than decoding the inline copy.

## Common jobs

- Product photos: remove the background (`remove-background` and similar
  slugs), place on a canvas, resize for marketplaces, upscale.
- Checks before publishing: `quality_gate` answers a yes/no question about
  an image, text or URL; `check_image` runs a moderation policy.
- A saved pipeline: `run_flow` with its slug; parameter names come from
  `list_flows`.
- With a Shopify connection too: read the product's image URL, process it
  with `image_url`, then add the download link to the product as new media.
  Shopify keeps its own copy. Add results as extra images unless the user
  asks to replace the originals.

Docs: https://apiai.me/docs#mcp
