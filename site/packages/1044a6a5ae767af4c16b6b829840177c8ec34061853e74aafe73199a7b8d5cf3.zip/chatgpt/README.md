# ChatGPT skill

The skill uploaded with the apiai.me plugin in OpenAI's plugin portal
(platform.openai.com/plugins, Skills step). It differs from `skills/apiai`,
which Claude Code and Gemini CLI install: no local-file or base64 steps
(ChatGPT has no local machine, and attached images go through the upload
link), no instructions for other connectors such as Shopify, and
`agents/openai.yaml` declares the apiai.me MCP server.

To upload it again, zip the `apiai` folder so the archive contains
`apiai/SKILL.md` and `apiai/agents/openai.yaml`.
