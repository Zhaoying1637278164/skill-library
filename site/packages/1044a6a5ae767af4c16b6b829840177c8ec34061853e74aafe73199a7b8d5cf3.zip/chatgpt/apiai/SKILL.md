---
name: apiai
description: "Process product and marketing images with apiai.me: remove backgrounds, generate or edit images, upscale, run the user's saved pipelines, and check images before publishing. Use when the user asks for these image tasks with apiai.me. Not for describing images, writing text or converting documents."
---

# Using apiai.me

apiai.me runs image AI tools and pipelines the user has saved in their
apiai.me account. Runs are paid from the user's prepaid apiai.me balance.

## Before running anything

1. Call `list_workflows` to see the available tools, their slugs,
   parameters and prices. Call `list_flows` for the user's saved pipelines.
   Use slugs exactly as listed; don't guess them.
2. Paid tools are `generate_image`, `edit_image`, `run_flow`, `check_image`
   and `quality_gate`. Before running more than a few, tell the user how many
   runs you plan and roughly what they will cost. `check_balance` is free.

## Getting an image in

- If the image is online, pass its address as `image_url`.
- Otherwise, including images attached in the chat, call
  `request_upload_link`, give the user the link, and wait until they say the
  upload is done. Then pass the returned `upload_id`.

## Giving results back

Results come back as an image plus a download link that works for 24 hours.
Show the image and give the user the link.

## Common jobs

- Product photos: remove the background (for example the
  `remove-background` slug), place the product on a clean canvas, resize,
  upscale.
- Checks before publishing: `quality_gate` answers a yes or no question
  about an image, text or URL; `check_image` runs a moderation policy.
- Saved pipelines: `run_flow` with the pipeline's slug and the parameter
  names shown by `list_flows`.
- Batches: `list_batches` and `get_batch` show progress. Only call
  `cancel_batch` when the user asks to stop a batch.
