# apiai.me for Claude Code and Gemini CLI

Image and video AI tools, and your own pipelines, from [apiai.me](https://apiai.me),
inside your coding assistant: background removal, image generation and
editing, upscaling, resizing, video generation and moderation checks.

This repo is both a **Claude Code plugin** and a **Gemini CLI extension**. Each
connects to the hosted apiai.me MCP server at `https://apiai.me/api/mcp`, adds
a short guide on using it well, and nothing else: there's no local code.

## Install

**Claude Code**

```
/plugin marketplace add antonstroberg/apiai-plugins
/plugin install apiai@apiai
```

**Gemini CLI**

```
gemini extensions install https://github.com/antonstroberg/apiai-plugins
```

The first time a tool is used, a browser window opens to sign in to your
apiai.me account and approve the connection. There's no API key to copy. You
can disconnect at any time under *Use in AI tools* in the apiai.me dashboard.

## What it costs

The plugin is free. Runs are paid from your prepaid apiai.me balance, and
each result says what it cost. Browsing tools, pipelines and your balance is
free.

## Other assistants

Claude.ai, ChatGPT, Cursor, VS Code, Codex and others connect to the same
server; see [Use in AI tools](https://apiai.me/dashboard/connect) and the
[MCP docs](https://apiai.me/docs#mcp).

## Privacy and support

[Privacy policy](https://apiai.me/privacy) · [Terms](https://apiai.me/terms) ·
[Contact](https://apiai.me/contact)

## License

MIT
