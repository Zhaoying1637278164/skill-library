# elixir-ls-lsp

Elixir language server (ElixirLS) for Claude Code, providing code intelligence and diagnostics.

## Supported Extensions
`.ex`, `.exs`, `.heex`

## Installation

ElixirLS requires Elixir and Erlang to be installed first.

### Via Homebrew (macOS)

```bash
brew install elixir-ls
```

### Via Nix (if using NixOS/nix-darwin)

Already available if `elixir-ls` is in your system packages.

### Manual build

```bash
git clone https://github.com/elixir-lsp/elixir-ls.git
cd elixir-ls
mix deps.get && mix compile
mix elixir_ls.release2 -o release
```

Then add the `release` directory to your PATH.

## More Information
- [ElixirLS GitHub Repository](https://github.com/elixir-lsp/elixir-ls)
- [ElixirLS Documentation](https://hexdocs.pm/elixir_ls)
