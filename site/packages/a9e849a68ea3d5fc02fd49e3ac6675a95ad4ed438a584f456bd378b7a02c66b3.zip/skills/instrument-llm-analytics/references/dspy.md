> AI agents: this is one page from PostHog's docs. Full index of Markdown docs for LLMs: https://posthog.com/llms.txt

# DSPy AI Observability installation - Docs

Copy page

# DSPy AI Observability installation - Docs

![](https://res.cloudinary.com/dmukukwp6/image/upload/texture_tan_9608fcca70)

![](https://res.cloudinary.com/dmukukwp6/image/upload/texture_tan_dark_a92b0e022d)

Let AI instrument your LLM calls for you

Skip the manual setup — run this in your project and the wizard installs the SDK and wires up AI Observability for you.

`npx @posthog/wizard ai-observability`

[Learn more](/wizard.md)

![PostHog Wizard hedgehog](https://res.cloudinary.com/dmukukwp6/image/upload/wizard_3f8bb7a240.png)

![](https://res.cloudinary.com/dmukukwp6/image/upload/wizard_3f8bb7a240.png)Let AI instrument your LLM calls for you

1.  1

    ## Install the PostHog SDK

    Required

    Setting up analytics starts with installing the PostHog SDK. The DSPy integration uses PostHog's LiteLLM callback.

    ```bash
    pip install posthog
    ```

2.  2

    ## Install DSPy and LiteLLM

    Required

    Install DSPy and LiteLLM. DSPy uses LiteLLM natively for provider access, and PostHog integrates with LiteLLM's callback system.

    ```bash
    pip install dspy litellm
    ```

3.  3

    ## Configure PostHog with LiteLLM

    Required

    Set your PostHog project token and host as environment variables, then configure LiteLLM to use PostHog as a callback handler. You can find your project token in [your project settings](https://app.posthog.com/settings/project).

    ```python
    import os
    import dspy
    import litellm
    # Set PostHog environment variables
    os.environ["POSTHOG_API_KEY"] = "<ph_project_token>"
    os.environ["POSTHOG_API_URL"] = "https://us.i.posthog.com"
    # Enable PostHog callbacks in LiteLLM
    litellm.success_callback = ["posthog"]
    litellm.failure_callback = ["posthog"]
    # Configure DSPy to use an LLM
    lm = dspy.LM(
        "openai/gpt-5-mini",
        api_key="your_openai_api_key",
        metadata={
            "user_id": "user_123",  # Maps to PostHog distinct_id
            "$ai_session_id": "conversation-abc",  # Groups calls into one session
        },
    )
    dspy.configure(lm=lm)
    ```

    **How this works**

    DSPy uses LiteLLM under the hood for LLM provider access. By configuring PostHog as a LiteLLM callback, all LLM calls made through DSPy are automatically captured as `$ai_generation` events.

4.  4

    ## Run DSPy modules

    Required

    Use DSPy as normal. PostHog automatically captures an `$ai_generation` event for each LLM call made through LiteLLM.

    ```python
    from posthog import Posthog
    import time, uuid
    posthog = Posthog("<ph_project_token>", host="https://us.i.posthog.com")
    trace_id = str(uuid.uuid4())
    lm = dspy.LM(
        "openai/gpt-5-mini",
        api_key="your_openai_api_key",
        metadata={
            "user_id": "user_123",
            "$ai_session_id": "conversation-abc",
            "$ai_trace_id": trace_id,
        },
    )
    dspy.configure(lm=lm)
    # Define a simple signature
    class QA(dspy.Signature):
        """Answer the question."""
        question: str = dspy.InputField()
        answer: str = dspy.OutputField()
    predictor = dspy.Predict(QA)
    result = predictor(question="What's a fun fact about hedgehogs?")
    print(result.answer)
    ```

    You can expect captured `$ai_generation` events to have the following properties:

    | Property | Description |
    | --- | --- |
    | $ai_model | The specific model, like gpt-5-mini or claude-4-sonnet |
    | $ai_latency | The latency of the LLM call in seconds |
    | $ai_time_to_first_token | Time to first token in seconds (streaming only) |
    | $ai_tools | Tools and functions available to the LLM |
    | $ai_input | List of messages sent to the LLM |
    | $ai_input_tokens | The number of tokens in the input (often found in response.usage) |
    | $ai_output_choices | List of response choices from the LLM |
    | $ai_output_tokens | The number of tokens in the output (often found in response.usage) |
    | $ai_total_cost_usd | The total cost in USD (input + output) |
    | [[...]](/docs/ai-observability/generations.md#event-properties) | See [full list](/docs/ai-observability/generations.md#event-properties) of properties |

5.  5

    ## Capture tool calls as spans

    Optional

    Capture tool calls as a span yourself, as the example below does before calling `predictor`.

    ```python
    # retrieve() is your existing retrieval setup
    start = time.time()
    context = retrieve("hedgehog facts")
    posthog.capture(
        distinct_id="user_123",
        event="$ai_span",
        properties={
            "$ai_trace_id": trace_id,
            "$ai_session_id": "conversation-abc",
            "$ai_span_id": str(uuid.uuid4()),
            "$ai_span_name": "retrieve",
            "$ai_input_state": "hedgehog facts",
            "$ai_output_state": context,
            "$ai_latency": time.time() - start,
        },
    )
    question = f"Using this context, answer what a fun fact about hedgehogs is: {context}"
    result = predictor(question=question)
    ```

    See [spans](/docs/ai-observability/spans.md) for the full list of span properties.

6.  ## Verify traces and generations

    Recommended

    *Confirm LLM events are being sent to PostHog*

    Let's make sure LLM events are being captured and sent to PostHog. Under **AI Observability**, you should see rows of data appear in the **Traces** and **Generations** tabs.

    ![LLM generations in PostHog](https://res.cloudinary.com/dmukukwp6/image/upload/SCR_20250807_syne_ecd0801880.png)![LLM generations in PostHog](https://res.cloudinary.com/dmukukwp6/image/upload/SCR_20250807_syjm_5baab36590.png)

    [Check for LLM events in PostHog](https://app.posthog.com/ai-observability/generations)

7.  6

    ## Next steps

    Recommended

    Now that you're capturing AI conversations, continue with the resources below to learn what else AI Observability enables within the PostHog platform.

    | Resource | Description |
    | --- | --- |
    | [Basics](/docs/ai-observability/basics.md) | Learn the basics of how LLM calls become events in PostHog. |
    | [Generations](/docs/ai-observability/generations.md) | Read about the $ai_generation event and its properties. |
    | [Traces](/docs/ai-observability/traces.md) | Explore the trace hierarchy and how to use it to debug LLM calls. |
    | [Spans](/docs/ai-observability/spans.md) | Review spans and their role in representing individual operations. |
    | [Anaylze LLM performance](/docs/ai-observability/dashboard.md) | Learn how to create dashboards to analyze LLM performance. |

### Still have questions?

Ask PostHog AI

### Was this page useful?

HelpfulCould be better