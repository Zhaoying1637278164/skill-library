> AI agents: this is one page from PostHog's docs. Full index of Markdown docs for LLMs: https://posthog.com/llms.txt

# Instructor AI Observability installation - Docs

Copy page

# Instructor AI Observability installation - Docs

![](https://res.cloudinary.com/dmukukwp6/image/upload/texture_tan_9608fcca70)

![](https://res.cloudinary.com/dmukukwp6/image/upload/texture_tan_dark_a92b0e022d)

Let AI instrument your LLM calls for you

Skip the manual setup — run this in your project and the wizard installs the SDK and wires up AI Observability for you.

`npx @posthog/wizard ai-observability`

[Learn more](/wizard.md)

![PostHog Wizard hedgehog](https://res.cloudinary.com/dmukukwp6/image/upload/wizard_3f8bb7a240.png)

![](https://res.cloudinary.com/dmukukwp6/image/upload/wizard_3f8bb7a240.png)Let AI instrument your LLM calls for you

1.  1

    ## Install dependencies

    Required

    **Full working examples**

    See the complete [Node.js](https://github.com/PostHog/posthog-js/tree/main/examples/example-ai-instructor) and [Python](https://github.com/PostHog/posthog-python/tree/master/examples/example-ai-instructor) examples on GitHub. If you use the PostHog SDK wrapper instead of OpenTelemetry: see the [Node.js wrapper](https://github.com/PostHog/posthog-js/tree/e08ff1be/examples/example-ai-instructor) and [Python wrapper](https://github.com/PostHog/posthog-python/tree/7223c52/examples/example-ai-instructor) examples instead.

    Install the OpenTelemetry SDK, the OpenAI instrumentation, and Instructor.

    PostHog AI

    ### Python

    ```bash
    pip install instructor openai opentelemetry-sdk "posthog[otel]" opentelemetry-instrumentation-openai-v2
    ```

    ### Node

    ```bash
    npm install @instructor-ai/instructor openai zod @posthog/ai @opentelemetry/sdk-node @opentelemetry/resources @opentelemetry/instrumentation-openai
    ```

2.  2

    ## Set up OpenTelemetry tracing

    Required

    Configure OpenTelemetry to auto-instrument OpenAI SDK calls and export traces to PostHog. PostHog converts `gen_ai.*` spans into `$ai_generation` events automatically.

    PostHog AI

    ### Python

    ```python
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.resources import Resource, SERVICE_NAME
    from posthog.ai.otel import PostHogSpanProcessor
    from opentelemetry.instrumentation.openai_v2 import OpenAIInstrumentor
    resource = Resource(attributes={
        SERVICE_NAME: "my-app",
        "posthog.distinct_id": "user_123", # optional: identifies the user in PostHog
        "foo": "bar", # custom properties are passed through
    })
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(
        PostHogSpanProcessor(
            api_key="<ph_project_token>",
            host="https://us.i.posthog.com",
        )
    )
    trace.set_tracer_provider(provider)
    OpenAIInstrumentor().instrument()
    ```

    ### Node

    ```typescript
    import { NodeSDK } from '@opentelemetry/sdk-node'
    import { resourceFromAttributes } from '@opentelemetry/resources'
    import { PostHogSpanProcessor } from '@posthog/ai/otel'
    import { OpenAIInstrumentation } from '@opentelemetry/instrumentation-openai'
    const sdk = new NodeSDK({
      resource: resourceFromAttributes({
        'service.name': 'my-app',
        'posthog.distinct_id': 'user_123', // optional: identifies the user in PostHog
        foo: 'bar', // custom properties are passed through
      }),
      spanProcessors: [
        new PostHogSpanProcessor({
          projectToken: '<ph_project_token>',
          host: 'https://us.i.posthog.com',
        }),
      ],
      instrumentations: [new OpenAIInstrumentation()],
    })
    sdk.start()
    ```

3.  3

    ## Extract structured data

    Required

    Use Instructor to extract structured data from LLM responses. PostHog automatically captures an `$ai_generation` event for each call made through the OpenAI SDK that Instructor wraps.

    PostHog AI

    ### Python

    ```python
    import instructor
    import openai
    from pydantic import BaseModel
    class User(BaseModel):
        name: str
        age: int
    client = instructor.from_openai(openai.OpenAI(api_key="your_openai_api_key"))
    user = client.chat.completions.create(
        model="gpt-4o-mini",
        response_model=User,
        messages=[{"role": "user", "content": "Extract: John is 30 years old"}],
    )
    print(user)
    ```

    ### Node

    ```typescript
    import OpenAI from 'openai'
    import Instructor from '@instructor-ai/instructor'
    import { z } from 'zod'
    const oai = new OpenAI({ apiKey: 'your_openai_api_key' })
    const client = Instructor({ client: oai, mode: 'TOOLS' })
    const UserSchema = z.object({
      name: z.string(),
      age: z.number(),
    })
    const user = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      response_model: { schema: UserSchema, name: 'User' },
      messages: [{ role: 'user', content: 'Extract: John is 30 years old' }],
    })
    console.log(user)
    ```

    > **Note:** If you want to capture LLM events anonymously, omit the `posthog.distinct_id` resource attribute. See our docs on [anonymous vs identified events](/docs/data/anonymous-vs-identified-events.md) to learn more.

    You can expect captured `$ai_generation` events to have the following properties:

    | Property | Description |
    | --- | --- |
    | $ai_model | The specific model, like gpt-5-mini or claude-4-sonnet |
    | $ai_latency | The latency of the LLM call in seconds |
    | $ai_time_to_first_token | Time to first token in seconds (streaming only) |
    | $ai_tools | Tools and functions available to the LLM |
    | $ai_input | List of messages sent to the LLM |
    | $ai_input_tokens | The number of tokens in the input (often found in response.usage) |
    | $ai_output_choices | List of response choices from the LLM |
    | $ai_output_tokens | The number of tokens in the output (often found in response.usage) |
    | $ai_total_cost_usd | The total cost in USD (input + output) |
    | [[...]](/docs/ai-observability/generations.md#event-properties) | See [full list](/docs/ai-observability/generations.md#event-properties) of properties |

4.  4

    ## Group traces into sessions

    Optional

    PostHog groups traces into a session when they share an `$ai_session_id`. Set it if your product has multi-turn conversations, so the Sessions tab can reconstruct them. Workloads that finish in a single trace, like batch jobs or one-shot generation, do not need it.

    The instrumentation creates the LLM span for you, so there is no call to pass the session ID to. Add a span processor that sets the `$ai_session_id` attribute as each span starts. PostHog forwards span attributes it does not recognize onto the event, so the value arrives as the `$ai_session_id` property.

    PostHog AI

    ### Python

    ```python
    import contextvars
    from collections.abc import Iterator
    from contextlib import contextmanager
    from typing import Optional
    from opentelemetry.context import Context
    from opentelemetry.sdk.trace import Span, SpanProcessor
    session_id_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
        "ai_session_id", default=None
    )
    class SessionIdSpanProcessor(SpanProcessor):
        def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
            session_id = session_id_var.get()
            if session_id is not None:
                span.set_attribute("$ai_session_id", session_id)
    @contextmanager
    def ai_session(session_id: str) -> Iterator[None]:
        token = session_id_var.set(session_id)
        try:
            yield
        finally:
            session_id_var.reset(token)
    # Register it on the same provider as PostHogSpanProcessor
    provider.add_span_processor(SessionIdSpanProcessor())
    # Resetting on exit keeps the ID off the next request that reuses this thread
    with ai_session("conversation-abc"):
        reply = handle_turn(user_message)
    ```

    ### Node

    ```typescript
    import { AsyncLocalStorage } from 'node:async_hooks'
    import type { Span, SpanProcessor } from '@opentelemetry/sdk-trace-base'
    const sessionStore = new AsyncLocalStorage<string>()
    class SessionIdSpanProcessor implements SpanProcessor {
      onStart(span: Span): void {
        const sessionId = sessionStore.getStore()
        if (sessionId) {
          span.setAttribute('$ai_session_id', sessionId)
        }
      }
      onEnd(): void {}
      async shutdown(): Promise<void> {}
      async forceFlush(): Promise<void> {}
    }
    // Every span started inside the callback carries this session ID
    const reply = await sessionStore.run('conversation-abc', () => handleTurn(userMessage))
    ```

    On Node, add `new SessionIdSpanProcessor()` to the `spanProcessors` array of the `NodeSDK` you configured earlier, next to `PostHogSpanProcessor`. Keep the rest of that setup as it is, including `instrumentations` and the `sdk.start()` call.

    If a process only ever handles one session, set `$ai_session_id` as a resource attribute next to `service.name` instead. Resource attributes apply to every span the process emits, so that only works when the process and the session are the same thing.

5.  ## Verify traces and generations

    Recommended

    *Confirm LLM events are being sent to PostHog*

    Let's make sure LLM events are being captured and sent to PostHog. Under **AI Observability**, you should see rows of data appear in the **Traces** and **Generations** tabs.

    ![LLM generations in PostHog](https://res.cloudinary.com/dmukukwp6/image/upload/SCR_20250807_syne_ecd0801880.png)![LLM generations in PostHog](https://res.cloudinary.com/dmukukwp6/image/upload/SCR_20250807_syjm_5baab36590.png)

    [Check for LLM events in PostHog](https://app.posthog.com/ai-observability/generations)

6.  5

    ## Next steps

    Recommended

    Now that you're capturing AI conversations, continue with the resources below to learn what else AI Observability enables within the PostHog platform.

    | Resource | Description |
    | --- | --- |
    | [Basics](/docs/ai-observability/basics.md) | Learn the basics of how LLM calls become events in PostHog. |
    | [Generations](/docs/ai-observability/generations.md) | Read about the $ai_generation event and its properties. |
    | [Traces](/docs/ai-observability/traces.md) | Explore the trace hierarchy and how to use it to debug LLM calls. |
    | [Spans](/docs/ai-observability/spans.md) | Review spans and their role in representing individual operations. |
    | [Anaylze LLM performance](/docs/ai-observability/dashboard.md) | Learn how to create dashboards to analyze LLM performance. |

### Still have questions?

Ask PostHog AI

### Was this page useful?

HelpfulCould be better