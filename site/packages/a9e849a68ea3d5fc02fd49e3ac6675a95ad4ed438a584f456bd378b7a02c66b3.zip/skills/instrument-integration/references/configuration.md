> AI agents: this is one page from PostHog's docs. Full index of Markdown docs for LLMs: https://posthog.com/llms.txt

# iOS SDK configuration - Docs

Copy page

# iOS SDK configuration - Docs

## Autocapture configuration

You can enable or disable autocapture through the `PostHogConfig` object.

## Tracing headers

Use `tracingHeaders` to connect iOS network requests to backend events, errors, and LLM traces captured by a server-side PostHog SDK:

Swift

PostHog AI

```swift
let configuration = PostHogConfig(projectToken: "<ph_project_token>", host: "https://us.i.posthog.com")
configuration.tracingHeaders = ["api.example.com"]
PostHogSDK.shared.setup(configuration)
```

Hostnames are matched exactly and should not include protocols, paths, ports, or wildcard subdomains. Matching `URLSession` requests include `X-POSTHOG-DISTINCT-ID` and `X-POSTHOG-SESSION-ID` when those values are available.

Tracing headers require method swizzling, so `configuration.enableSwizzling` must remain `true`.

## Flush configuration

The iOS SDK uses an internal queue to make calls fast and non-blocking. It also batches requests and flushes asynchronously, making it perfect to use in any part of your mobile app.

You can configure how many events queue before flushing with `flushAt`. Setting this to `1` will send events immediately and will use more battery. The default is `20`.

You can also configure the flush interval with `flushIntervalSeconds` (default `30`), after which queued events are sent regardless of how many have been gathered:

Swift

PostHog AI

```swift
configuration.flushAt = 1
configuration.flushIntervalSeconds = 30
```

You can also manually flush the queue to start sending events immediately instead of waiting for the next batch:

Swift

PostHog AI

```swift
PostHogSDK.shared.capture("logged_out")
PostHogSDK.shared.flush()
```

Flushing is best-effort and asynchronous – it starts sending queued events in the background but doesn't wait for the request to finish, so it isn't a delivery guarantee.

## Amending, dropping or sampling events

Since version 3.28.0, you can provide a `BeforeSendBlock` function when initializing the SDK to amend, drop or sample events before they are sent to PostHog.

> **⚠️ Note:** This replaces the deprecated `propertiesSanitizer` option and provides more flexibility in modifying events. You can achieve the same functionality as `propertiesSanitizer` by using a `BeforeSendBlock` that mutates the event's properties in place.

> **🚨 Warning:** Amending and sampling events is advanced functionality that requires careful implementation. Core PostHog features may require 100% of unmodified events to function properly. We recommend only modifying or sampling your own custom events if possible, and preserving all PostHog internal events in their original form.

### Redacting information in events

`BeforeSendBlock` gives you one place to edit or redact information before it is sent to PostHog. For example:

Redact URLs in event properties

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.setBeforeSend { event in
    // Redact URLs
    if let url = event.properties["url"] as? String {
        event.properties["url"] = url.map { _ in "*" }.joined()
    }
    return event
}
```

Redact sensitive information from event properties

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.setBeforeSend { event in
    // Redact sensitive information
    if let email = event.properties["email"] as? String {
        event.properties["email"] = email.map { _ in "*" }.joined()
    }
    return event
}
```

Drop events by event name

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.setBeforeSend { event in
    // Drop all events named "Stale Event"
    if event.event == "Stale Event" {
        return nil
    }
    return event
}
```

Filter autocaptured screen views

You can stop specific screens from being autocaptured by filtering them in your before-send hook. Return `null` for any `$screen` event whose `$screen_name` matches a screen you don't want to track, and it's dropped before being sent – keeping unwanted screen views out of your event log.

Because it's just a function, you can filter however you like – an **ignorelist** (drop the screens you name), an **allowlist** (invert the check to capture only the screens you name), or any custom rule such as a name prefix, a regex, or a check against the event's properties.

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
let ignoredScreens: Set<String> = ["Splash", "Debug"]
config.setBeforeSend { event in
    if event.event == "$screen",
       let screenName = event.properties["$screen_name"] as? String,
       ignoredScreens.contains(screenName) {
        return nil
    }
    return event
}
```

### Sampling events

Sampling lets you choose to send only a percentage of events to PostHog. It is a good way to control your costs without having to completely turn off features of the SDK.

Sample events by event name

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.setBeforeSend { event in
    // Sample 10% of Sampled Event events
    if event.event == "Sampled Event" {
        if Double.random(in: 0...1) < 0.1 {
            event.properties["$sample_type"] = ["sampleByEvent"]
            event.properties["$sample_threshold"] = 0.1
            event.properties["$sampled_events"] = ["Sampled Event"]
            return event
        }
        return nil
    }
    return event
}
```

### Chaining multiple BeforeSendBlocks

You can provide an array of `BeforeSendBlock` functions to be called one after the other:

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.setBeforeSend(
    // First block: Drop all events named "Stale Event"
    { event in
        if event.event == "Stale Event" {
            return nil
        }
        return event
    },
    // Second block: Redact sensitive information
    { event in
        if let email = event.properties["email"] as? String {
            event.properties["email"] = email.map { _ in "*" }.joined()
        }
        return event
    }
)
```

**Note:** When chaining beforeSend blocks, order is important. The first block is executed first and the mutated event is passed along to the second block, and so on. If at any point in the chain the event is dropped, any subsequent blocks will not be executed.

## Setting up app groups

1.  **Configure App Groups**: Set up an [App Group](https://developer.apple.com/documentation/xcode/configuring-app-groups) in Xcode for your main app and extension targets
2.  **Configure PostHog**: Use the same App Group identifier in all targets:

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.appGroupIdentifier = "group.com.yourcompany.yourapp"
PostHogSDK.shared.setup(config)
```

## Method swizzling

Method swizzling is a technique that enables the SDK to intercept and modify method calls at runtime to provide advanced features like screen view tracking, element interactions, session replay, surveys, and more.

Method swizzling is enabled by default, but can be disabled by setting the relevant config option to `false` in the `PostHogConfig` object:

| Feature | Description | Config option |
| --- | --- | --- |
| Screen view tracking | Automatically captures when view controllers are presented | config.captureScreenViews |
| Element interactions | Automatically tracks user interactions with UI elements | config.captureElementInteractions |
| Rage clicks | Automatically captures $rageclick events for rapid repeated taps in the same area (iOS/macCatalyst, UIKit) | config.rageClickConfig.enabled |
| Session replay | Records user sessions | config.sessionReplay |
| Surveys | Displays surveys at appropriate times | config.surveys |
| Advanced metrics tracking | Provides more precise session ID calculation and rotation by detecting user activity and idleness | N/A |

### Disabling all method swizzling

Since version 3.34.0, you can opt out of all swizzling using the `enableSwizzling` configuration option. When you disable swizzling, the SDK disables the features listed above.

Swift

PostHog AI

```swift
let config = PostHogConfig(projectToken: "<ph_project_token>", host: "<ph_api_client_host>")
config.enableSwizzling = false
PostHogSDK.shared.setup(config)
```

> **Note:** When method swizzling is disabled, features that depend on it will not work even if they are individually enabled in the config. For example, if you set `config.sessionReplay = true` and `config.enableSwizzling = false`, session replay will **not** be enabled.

### Session metrics management

Method swizzling is particularly important for accurate [session metrics tracking](/tutorials/session-metrics.md). With swizzling enabled, the SDK can better detect user activity and idle times to provide a better session rotation.

With swizzling disabled, the SDK only uses application open/backgrounded events to detect user activity, which can lead to a sub-optimal session calculation.

## Custom keyboard extensions

Custom keyboard extensions have stricter security rules than other extension types. To use PostHog in a custom keyboard, the keyboard must have [Open Access permission](https://developer.apple.com/documentation/uikit/configuring-open-access-for-a-custom-keyboard) enabled. This permission is required for network requests and write access to shared containers.

Users must explicitly grant Open Access in **Settings > General > Keyboard > Keyboards > \[Your Keyboard\] > Allow Full Access**.

## All configuration options

The [`PostHogConfig` object](https://github.com/PostHog/posthog-ios/blob/main/PostHog/PostHogConfig.swift) contains several other settings you can toggle:

| Attribute | Description |
| --- | --- |
| flushAtType: IntegerDefault: 20 (5 on tvOS) | The number of queued events that the posthog client should flush at. Setting this to 1 will not queue any events and will use more battery. |
| flushIntervalSecondsType: TimeIntervalDefault: 30 | The amount of time to wait before each tick of the flush timer, in seconds. Smaller values will make events delivered in a more real-time manner and also use more battery. A value smaller than 10 seconds will seriously degrade overall performance. |
| maxQueueSizeType: IntegerDefault: 1000 (100 on tvOS) | The maximum number of items to queue before starting to drop old ones. This should be a value greater than zero, the behavior is undefined otherwise. |
| maxBatchSizeType: IntegerDefault: 50 | Number of maximum events in a batch call. |
| maxRetriesType: IntegerDefault: 3 | Maximum number of consecutive flush attempts before the entire queue is dropped to avoid infinite retries against a permanently-broken backend (e.g. wrong API key, exhausted quota, deterministic 5xx). Increments on every retriable failure including HTTP 413 cap halving; resets on a successful 2xx response. |
| captureApplicationLifecycleEventsType: BooleanDefault: true | Whether the posthog client should automatically make a capture call for application lifecycle events, such as "Application Installed", "Application Updated" and "Application Opened". |
| captureScreenViewsType: BooleanDefault: true | Whether the posthog client should automatically make a screen call when a view controller is added to a view hierarchy. Because the underlying implementation uses method swizzling, we recommend initializing the posthog client as early as possible (before any screens are displayed), ideally during the Application delegate's applicationDidFinishLaunching method. |
| enableSwizzlingType: BooleanDefault: true | Enable method swizzling for SDK functionality that depends on it. When disabled, functionality that requires swizzling (like autocapture, screen views, session replay, surveys) will not be installed. |
| captureElementInteractionsType: BooleanDefault: false | (UIKit only) Whether the posthog client should automatically make a capture call when the user interacts with an element in a screen. |
| rageClickConfigType: ObjectDefault: .init() | (iOS/macCatalyst, UIKit) Rage click detection configuration. Includes enabled (default true), minimumTapCount (default 3), thresholdPoints (default 30), and timeoutInterval (default 1.0). Works independently of captureElementInteractions. Available in version 3.51.0+. |
| sendFeatureFlagEventType: BooleanDefault: true | Send a $feature_flag_called event when a feature flag is used automatically. |
| preloadFeatureFlagsType: BooleanDefault: true | Preload feature flags automatically. |
| evaluationContextsType: Array of StringsDefault: undefined | Evaluation context tags that constrain which feature flags are evaluated. When set, only flags with matching evaluation context tags (or no evaluation context tags) will be returned. See [evaluation contexts documentation](/docs/feature-flags/evaluation-contexts.md) for more details. Available in version 3.38.0+. The legacy parameter evaluationEnvironments (version 3.33.0+) is also supported for backward compatibility. |
| debugType: BooleanDefault: false | Logs the SDK messages to the Xcode console. |
| optOutType: BooleanDefault: false | Prevents capturing any data if enabled. |
| getAnonymousIdType: FunctionDefault: undefined | Hook that allows for modification of the default mechanism for generating anonymous id (which as of now is just random UUID v7). |
| dataModeType: EnumDefault: .any | Controls when queued data is flushed. Use .wifi to flush only on Wi-Fi; .cellular is a legacy value and behaves like .any. |
| personProfilesType: EnumDefault: .identifiedOnly | Determines the behavior for processing user profiles. |
| setDefaultPersonPropertiesType: BooleanDefault: true | Automatically set common device and app properties (such as $app_version, $os_name, and $device_type) as person properties for feature flag evaluation. See [property overrides](/docs/feature-flags/property-overrides.md) for more details. |
| sessionReplayType: BooleanDefault: false | Enable Recording of Session Replays. |
| sessionReplayConfigType: ObjectDefault: .init() | Session Replay configuration. See [Session Replay installation](/docs/session-replay/installation/ios.md) for more details. |
| tracingHeadersType: Array of StringsDefault: nil | Exact hostnames that should receive PostHog tracing headers when the SDK instruments URLSession requests. |
| errorTrackingConfigType: ObjectDefault: .init() | Error Tracking configuration. See the [error tracking docs](/docs/error-tracking.md) for more details. |
| logsType: ObjectDefault: .init() | Structured Logs configuration. See [Logs installation](/docs/logs/installation/ios.md) for more details. |
| surveysConfigType: ObjectDefault: .init() | Surveys configuration, including custom survey delegates and display language overrides. |
| urlSessionConfigurationType: URLSessionConfigurationDefault: .default | Custom URLSessionConfiguration used by the SDK for PostHog API requests. |
| appGroupIdentifierType: StringDefault: nil | The identifier of the App Group that should be used to store shared analytics data. PostHog will try to get the physical location of the App Group's shared container, otherwise fallback to the default location. |
| reuseAnonymousIdType: BooleanDefault: false | Whether the SDK should reuse the anonymous Id between user changes. When enabled, a single Id will be used for all anonymous users on this device. |
| surveysType: BooleanDefault: true | Enable Surveys. |
| setBeforeSendType: FunctionDefault: undefined | Hook that allows for amending, sampling, or dropping events before they are sent to PostHog. |
| bootstrapType: PostHogBootstrapConfigDefault: nil | Seeds identity (distinctId, isIdentifiedId) and feature-flag state (featureFlags, featureFlagPayloads) before the first /flags response. Bootstrapped identity applies to the first session; only enabled flags are served, until the first /flags response replaces them. See [SDK bootstrapping](/docs/libraries/bootstrapping.md#behavior-on-mobile-sdks). |

### Still have questions?

Ask PostHog AI

### Was this page useful?

HelpfulCould be better