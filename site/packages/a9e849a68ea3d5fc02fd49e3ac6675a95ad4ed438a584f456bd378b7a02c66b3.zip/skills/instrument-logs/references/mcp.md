> AI agents: this is one page from PostHog's docs. Full index of Markdown docs for LLMs: https://posthog.com/llms.txt

# Use Logs over PostHog MCP - Docs

Copy page

# Use Logs over PostHog MCP - Docs

The [PostHog MCP server](/docs/model-context-protocol.md) gives coding agents direct access to your logs. Ask your agent to search, filter, and analyze log data without leaving your editor, then fix the bug in the same session.

This works in any MCP client – Cursor, Codex, Claude Code, Windsurf, VS Code, and others.

## Before you start

1.  **Set up Logs** – [send them to PostHog with an OpenTelemetry client](/docs/logs/installation.md) so there's something to read.
2.  **Connect the MCP server** – [install it in your AI tool](#set-up) and give it access to your project.

## What you can do here

Through MCP tools, your agent can:

-   **Query and count logs** – filter by severity, service, time range, and free text, and pull counts or sparklines to see how a problem is trending.
-   **Discover what's available** – list log attributes and their values, and list the services sending logs with their volume and error rate, so it can build a targeted query instead of guessing.
-   **Break counts down by facet** – group matching logs by any attribute to see where a spike is concentrated.
-   **Mine and diff patterns** – group similar log lines into templates, and compare two time ranges to see which patterns are new or spiking.
-   **Manage alerts** – create, read, update, and delete [log alerts](/docs/logs/alerts.md), attach or remove Slack, webhook, and Teams destinations, read an alert's event history, and simulate a threshold against historical logs before committing to it.

Saved views, sampling rules, and metric rules aren't exposed over MCP – manage those in the [web app](/docs/logs/surfaces/web-app.md) or with the [Logs API](/docs/logs/surfaces/api.md).

For the full list of tools and how to scope a session to a subset, see the [MCP tools reference](/docs/model-context-protocol/tools.md).

## Example prompts

| Goal | Ask your agent |
| --- | --- |
| Triage | Show me all error logs from the last hour |
| Narrow by service | What services are logging errors? Search for error logs from the payments service |
| Follow a request | Find logs related to trace ID abc123 |
| Explore the schema | What log attributes are available? Show me the values for service.name |
| Spot what changed | Compare log patterns from today against yesterday and show me what's new |
| Cut noise | Show me warning and error logs from the last 24 hours, excluding debug noise |

Because your agent has both your codebase and your logs in one session, it can connect a log line to the exact code path that emitted it and draft the fix.

A useful order of operations: list attributes and their values to learn the schema, count matching logs to check the result set is a sane size, then query. Log records carry trace and span IDs, so your agent can follow a single request across services.

## Set up

Connect the PostHog MCP server to your AI tool of choice, then grant it access to your project. The [MCP overview](/docs/model-context-protocol.md) covers install and authentication for each client.

To browse logs visually, mine patterns interactively, or watch the session replay behind a log line, use the [web app](/docs/logs/surfaces/web-app.md).

## Related

-   Browse and pivot through logs in the [web app](/docs/logs/surfaces/web-app.md).
-   Script the same operations with the [Logs API](/docs/logs/surfaces/api.md).
-   Learn what your agent is creating in [Set up log alerts](/docs/logs/alerts.md).
-   See how templates are built in [Log patterns](/docs/logs/patterns.md).

### Still have questions?

Ask PostHog AI

### Was this page useful?

HelpfulCould be better