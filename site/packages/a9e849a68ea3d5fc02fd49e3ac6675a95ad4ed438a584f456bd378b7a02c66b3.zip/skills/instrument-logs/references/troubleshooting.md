> AI agents: this is one page from PostHog's docs. Full index of Markdown docs for LLMs: https://posthog.com/llms.txt

# Logs troubleshooting - Docs

Copy page

# Logs troubleshooting - Docs

This page covers troubleshooting for Logs. For setup, see the [installation guide](/docs/logs/installation.md).

## Authentication errors

**Problem**: Getting 401 Unauthorized errors when sending logs.

**Solutions**:

-   Verify you're using the correct project token from [Project Settings](https://app.posthog.com/settings/project)
-   Check the Authorization header format: `Bearer <ph_project_token>`
-   If using query parameter, verify the format: `?token=<ph_project_token>`
-   Ensure your project token hasn't been rotated or revoked

## Connection issues

**Problem**: Cannot connect to the PostHog Logs endpoint.

**Solutions**:

-   Verify the endpoint URL: `https://us.i.posthog.com/i/v1/logs`
-   Check that your application can make outbound HTTPS requests
-   Ensure firewall rules allow outbound connections to PostHog
-   For self-hosted instances, verify the endpoint is correct for your deployment

## Logs not appearing in PostHog

**Problem**: Logs are being sent but don't appear in the PostHog interface.

**Solutions**:

-   Verify your project token is correct and associated with the right project
-   Check that logs are being sent in the correct OTLP format
-   Ensure your project has access to the Logs feature in PostHog
-   Check the network tab in your browser/application to verify requests are succeeding (200 status)

## Early startup logs are missing

**Problem**: Console output from the first moments of a page load – React hydration warnings, errors thrown during bootstrap – never reaches Logs, while console calls made later arrive fine.

**Solutions**:

-   Upgrade to posthog-js **1.422.0** or later, which buffers `console.*` calls made while the logs script is still loading and backfills them once it is ready.
-   Enable capture with `logs: { captureConsoleLogs: true }` in `posthog.init()` rather than only with the **Capture console logs** project setting. With the project setting alone, a visitor's first page load does not start capturing until remote config responds; the `init()` option starts at `posthog.init()` on every load.
-   Check that the calls are among the levels captured: `console.log`, `console.info`, `console.debug`, `console.warn`, and `console.error`.
-   If more than `logs.maxBufferSize` console calls (100 by default) happen before the script loads, only the earliest are kept.

## Performance issues

**Problem**: High memory usage or slow log processing.

**Solutions**:

-   Adjust the batch size in your OpenTelemetry configuration
-   Use BatchLogRecordProcessor instead of SimpleLogRecordProcessor for better performance
-   Consider filtering logs on the client side to reduce volume
-   Check for network latency between your application and PostHog

## Log format problems

**Problem**: Logs are being received but not parsed correctly.

**Solutions**:

-   Ensure you're using the standard [OTLP log format](https://opentelemetry.io/docs/specs/otel/logs/data-model/)
-   Verify log levels are set correctly (INFO, WARN, ERROR, etc.)
-   Check that log attributes are properly structured
-   Use the OpenTelemetry logging APIs instead of raw log libraries

## Logs not appearing on a person's profile

**Problem**: Logs are searchable in the **Logs** view, but the person profile's **Logs** tab is empty (or missing logs you expected to see).

**Solutions**:

-   Confirm each log record carries the attribute `posthogDistinctId` (camelCase, lowercase `p`) — see [Link logs to a person](/docs/logs/link-person.md). `distinct_id`, `posthog_distinct_id`, and `user_id` are **not** equivalent unless you've explicitly configured one as the [custom attribute key](/docs/logs/link-person.md#customizing-the-attribute-key).
-   The value of the attribute must equal one of the person's `distinct_id`s exactly — partial or prefixed matches are not picked up.
-   If your team has customized the attribute key (via the `logs_config` endpoint), the person profile's Logs tab shows a hint above the chart indicating which key is being used. Make sure your pipeline emits logs under that exact key.
-   Date range: the person Logs tab respects the same date range picker as the main Logs view. Expand the range if the logs are older than the default window.

## Project token authentication issues

**Problem**: Confused about which key to use or how to authenticate.

**Solutions**:

-   Use your **project token** (the same one you use for capturing events)
-   Find it in [Project Settings](https://app.posthog.com/settings/project)
-   You can authenticate in two ways:
    -   **Header**: `Authorization: Bearer <ph_project_token>`
    -   **Query param**: `?token=<ph_project_token>`
-   Do not use your personal API key or other authentication methods

## Self-hosted endpoint issues

**Problem**: Logs not working with self-hosted PostHog.

**Solutions**:

-   Use your self-hosted instance URL instead of `https://us.i.posthog.com`
-   Verify the logs endpoint is enabled on your self-hosted instance
-   Check that the endpoint path is correct: `/logs`
-   Ensure your PostHog version supports the logs feature

## Still having issues?

If you're still experiencing problems:

1.  Verify your OpenTelemetry client configuration matches the examples in the [installation guide](/docs/logs/installation.md)
2.  Test with a simple log message first before sending complex logs
3.  Check the network requests to see the actual HTTP status codes and error messages
4.  Contact PostHog support with your specific error messages and configuration details

### Still have questions?

Ask PostHog AI

### Was this page useful?

HelpfulCould be better