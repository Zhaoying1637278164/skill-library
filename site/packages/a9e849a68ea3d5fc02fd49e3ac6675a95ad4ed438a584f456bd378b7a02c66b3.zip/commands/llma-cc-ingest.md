---
name: posthog:llma-cc-ingest
description: Manually send a Claude Code session log to PostHog LLM Analytics
argument-hint:
- session-id or path
allowed-tools: Bash(python3:*),Bash(ls:*),Bash(echo:*)
---

# LLM Analytics — Ingest Session

Manually send a Claude Code session log to PostHog LLM Analytics.

## Usage

The argument `$ARGUMENTS` can be:
- A session ID (e.g. `14a1687c-1937-4719-921d-cb2400d7a114`)
- A path to a JSONL file (e.g. `~/.claude/projects/-Users-me-myproject/14a1687c.jsonl`)
- Empty — will use the most recent session log for the current project

## Steps

1. Resolve the session log path from the argument
2. Run the ingest script
3. Report the results

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/llma_cc_ingest.py $ARGUMENTS
```

If no argument is provided, list recent sessions and let the user choose:

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/llma_cc_ingest.py --list
```
