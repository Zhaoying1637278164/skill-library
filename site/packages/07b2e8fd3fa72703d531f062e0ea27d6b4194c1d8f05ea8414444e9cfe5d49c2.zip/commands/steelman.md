---
description: Make the strongest case for the option you are leaning against. Usage - /naysayer:steelman <the option you rejected>
---

The user is leaning against an option. Make the strongest honest case for it, so they know what they are giving up.

The option: $ARGUMENTS

If no option was given, look for the most recent choice in the conversation where the user preferred one option over another, and steelman the one they did not pick. If there is none, ask which option they mean and stop.

Write:

1. The option, restated fairly in one sentence, the way its best advocate would put it.
2. The three strongest reasons to choose it, strongest first. One or two sentences each. Use reasons that apply to the user's actual situation, not generic virtues.
3. One line starting "You would regret skipping this if:" with the specific circumstance where passing on this option hurts most.

Do not argue against the option, do not compare it point by point with the user's preferred choice, and do not tell the user what to decide. Keep it under 200 words.
