---
name: project-premortem
description: Run a premortem on a real Linear project, grounded in its actual tickets. Use when the user asks for a premortem on a Linear project, asks what could sink a project they track in Linear, asks which tickets put a launch at risk, or runs /naysayer:project-premortem <project name or URL>.
---

# Project premortem (Linear)

Imagine the project has failed, then work backwards using what its Linear tickets actually show.

## 1. Read the project

Use the Linear MCP server. This skill is read-only.

1. Find the project the user named (`$ARGUMENTS`, or the project mentioned in the conversation). If more than one project matches, list the matches and ask which one. If none was named, ask and stop.
2. Read the project's details: status, target date, lead.
3. List its issues with status, priority, assignee and last-updated date. One listing call is usually enough; page only if the project has more issues than one call returns.

If the Linear server is not connected or needs sign-in, tell the user to authenticate it with `/mcp` and stop.

**Never create, edit, assign, re-prioritise, comment on or close anything in Linear.** If the user asks for a change while this skill is running, tell them what you would change and let them do it.

## 2. Look for these signals

- Urgent or high-priority issues with no assignee.
- Urgent or high-priority issues that have not been started, measured against the target date.
- Issues marked in progress that have not been updated in over a week.
- One person holding most of the open high-priority work.
- A target date that the open count makes implausible, or no target date at all.
- Issues whose titles suggest an external dependency (legal, security review, another team, a vendor).
- Recently added urgent issues, which suggest scope is still growing.

Only report a signal you can back with specific issues.

## 3. Write the premortem

Start with one line: the project name, its target date, and counts of open issues by priority.

Then the five most likely causes of failure, most likely first:

| # | What went wrong | Evidence in Linear | Earliest warning sign | Cheapest thing to do now |
| --- | --- | --- | --- | --- |

- "Evidence in Linear" names issue identifiers (for example ABC-123). Give titles only; do not paste issue descriptions or comments.
- If the tickets do not support five causes, give fewer. Do not pad the table with generic risks.
- Include one row about people or ownership if the data supports it.

End with one line naming the single issue or gap you would look at first, and why.

## Rules

- A premortem finds risks; it does not predict failure. Say so if the user reads it as a forecast.
- Do not rank or judge individual people. Report load and ownership as facts ("4 of 6 open urgent issues are assigned to one person").
- Keep the reply under 350 words.
