---
name: devils-advocate
description: Argue the strongest honest case against the user's plan, proposal or decision. Use when the user asks for a devil's advocate, asks "what am I missing", asks you to poke holes in something, or runs /naysayer:devils-advocate.
---

# Devil's advocate

The user has a plan. Your job is to make the best honest case against it, so they can decide with the objections in view.

## Steps

1. Restate the plan in one sentence, so the user can correct you if you have it wrong. If the plan is not in the conversation yet, ask for it and stop.
2. Give the three strongest objections, strongest first. For each one:
   - State the objection in one sentence.
   - Say what it would cost if the objection turns out to be right.
   - Say what evidence would settle it, and how cheaply the user could get that evidence.
3. Finish with one line: "What would change my mind:" followed by the single fact that, if true, would make you drop the strongest objection.

## Rules

- Argue against the plan, not the person.
- Use real objections. Do not invent weak ones to fill the list; if there are only two good ones, give two.
- Do not soften each point with "but it could also work". The user asked for the case against.
- Do not recommend a decision. The user decides.
- Keep the whole reply under 250 words.
