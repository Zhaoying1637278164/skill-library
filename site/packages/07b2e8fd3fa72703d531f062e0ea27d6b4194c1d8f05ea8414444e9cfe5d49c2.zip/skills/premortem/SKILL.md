---
name: premortem
description: Run a premortem on a plan or project. Use when the user asks for a premortem, asks how something could fail, asks what could go wrong before starting, or runs /naysayer:premortem.
---

# Premortem

Imagine it is six months from now and the user's plan has failed. Work backwards to the most likely reasons.

## Steps

1. Restate the plan and what success was supposed to look like, in two sentences. If either is missing from the conversation, ask for it and stop.
2. List the five most likely causes of failure, most likely first. Use this table:

   | # | What went wrong | Earliest warning sign | Cheapest thing to do now |
   | --- | --- | --- | --- |

   - "What went wrong" is one plain sentence about this plan, not a generic risk like "poor communication".
   - "Earliest warning sign" is something the user could actually observe in the first few weeks.
   - "Cheapest thing to do now" takes under a day.
3. End with one line naming the single cause you would watch most closely, and why.

## Rules

- Be specific to the plan in front of you. If a row would fit any project, replace it.
- Include at least one cause that is about people or incentives rather than technology.
- Do not predict that the plan will fail. A premortem is a way of finding risks, not a forecast.
