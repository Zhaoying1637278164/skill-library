# Privacy policy for naysayer

Last updated: 2026-09-24

## What this plugin is

naysayer is a plugin for Claude that stress-tests plans: a devil's advocate, a premortem, a steelman, a skeptic that reads documents, and a premortem that reads a Linear project.

## What the plugin author collects

Nothing. The plugin has no server of its own, no analytics, and no telemetry. The author never receives your plans, your documents, your Linear data, or Claude's replies.

## Where your data goes

Most of the plugin works only from your conversation with Claude and touches no outside service.

One skill, `project-premortem`, connects to Linear's MCP server at `https://mcp.linear.app/mcp`:

- You sign in to Linear yourself, through Linear's own sign-in page. The plugin never sees your password or token.
- The skill reads one project you name: its details and its list of issues (status, priority, assignee, dates, titles).
- It is read-only. It never creates, edits, assigns, comments on or closes anything in Linear.
- What it reads is passed to Claude, inside your own Claude session, to write the premortem. It is handled under the terms and privacy policy of your Claude account.
- The reply refers to issues by identifier and title. It does not reproduce issue descriptions or comments.

Linear's handling of your data is covered by Linear's privacy policy: https://linear.app/privacy

## Data retention

The plugin stores nothing. It writes no files and keeps no history.

## Removing access

Uninstall the plugin, or disconnect its Linear server from your Claude app's connector settings (in Claude Code, `/mcp`). You can also revoke the app's access from your Linear workspace settings.

## Contact

Open an issue at https://github.com/ajribeiro/naysayer/issues
