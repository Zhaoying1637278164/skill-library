# naysayer

Stress-test a plan before you commit to it. Naysayer argues the other side so you can decide with the objections in view. It never tells you what to decide.

## What's in it

| Piece | What it does |
| --- | --- |
| `devils-advocate` skill | The three strongest honest objections to your plan, and what would settle each |
| `premortem` skill | "It is six months later and this failed": the five likeliest causes, the earliest warning sign for each, and the cheapest thing to do now |
| `steelman` command | The strongest case for the option you are leaning against |
| `skeptic` agent | Reads a plan or design document and returns a ranked list of objections |
| `project-premortem` skill | A premortem on a real Linear project, grounded in its tickets: unowned urgent work, stalled issues, dates the open count makes implausible. Read-only |

Everything here is instructions for Claude. There are no scripts, hooks or executables. The plugin bundles one remote MCP server, Linear's (`https://mcp.linear.app/mcp`), which only the `project-premortem` skill uses; the rest works without it.

## Install

From a marketplace that lists it:

```
/plugin install naysayer@<marketplace>
```

Or try it locally without installing:

```
claude --plugin-dir ./naysayer
```

## Use

```
/naysayer:devils-advocate
/naysayer:premortem
/naysayer:steelman the option you rejected
/naysayer:project-premortem <Linear project name or URL>
```

Or just ask: "play devil's advocate on this plan", "run a premortem", "have the skeptic read this doc".

## Set up Linear (only for project-premortem)

Sign in to the plugin's `linear` server when your Claude app asks, or in Claude Code run `/mcp`, pick `linear`, and authenticate in the browser.

## Permissions

- `devils-advocate`, `premortem` and `steelman` use no tools. They work from the conversation.
- `project-premortem` reads one Linear project and its issues. It never creates, edits or comments on anything in Linear.
- The `skeptic` agent can read files (`Read`, `Grep`, `Glob`) so it can review a document by path. It cannot edit anything or run commands.

## Privacy

See the [Privacy policy](PRIVACY.md). In short: the plugin author collects nothing, and the only remote service involved is Linear's own MCP server, used read-only by one skill.

## Changelog

- 0.2.0: added `project-premortem`, which reads a Linear project through Linear's MCP server.
- 0.1.0: first release.

## License

MIT
