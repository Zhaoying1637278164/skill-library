# napkin-math

Back-of-the-envelope estimates for Claude. Ask "roughly how much?" and get a few multiplied factors, each one defensible, with an honest range. Or hand it a number someone quoted at you and find out whether it holds up.

## What's in it

| Piece | What it does |
| --- | --- |
| `estimate` skill | A Fermi estimate: three to six factors with low, likely and high values, the arithmetic shown, and the one factor that moves the answer most |
| `sanity-check` skill | An independent estimate of a number someone quoted, with a verdict: plausible, a stretch, or doesn't add up |
| `handy-numbers.md` | A bundled reference of round numbers both skills draw on: time, data sizes, latencies, throughput, population, rules of thumb |

Everything here is instructions and a reference file. There are no scripts, hooks, executables or MCP servers, and the skills call no tools, so the plugin works the same way in every Claude app that supports plugins.

## Install

From a marketplace that lists it:

```
/plugin install napkin-math@<marketplace>
```

Or try it locally without installing:

```
claude --plugin-dir ./napkin-math
```

## Use

```
/napkin-math:estimate how many plugin submissions will a developer directory get in its first week?
/napkin-math:sanity-check "our API handles 10 billion requests a day"
```

Or just ask: "ballpark this for me", "does this number make sense?".

## Privacy

The plugin has no server, collects nothing, and sends nothing anywhere.

## Changelog

- 0.1.0: first release.

## License

MIT
