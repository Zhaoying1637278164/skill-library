---
name: sanity-check
description: Check whether a number someone quoted is plausible, using a quick independent estimate. Use when the user asks "does this number make sense", "is this plausible", "sanity check this figure", pastes a claim with a number in it and asks if it holds up, or runs /napkin-math:sanity-check <claim>.
---

# Napkin math: sanity check

Someone has quoted a number. Decide whether it is plausible by estimating it independently, without looking it up.

The claim: $ARGUMENTS (or the one in the conversation). If there is no number to check, ask for it and stop.

## Steps

1. Restate the claim with its number and units in one sentence.
2. Build your own rough estimate of the same quantity from three to five factors, the same way the `estimate` skill does: round numbers, one short reason each. For well-known constants use `../estimate/references/handy-numbers.md`.
3. Compare. Give one of three verdicts:
   - **Plausible**: within about 3x of your estimate.
   - **Stretch**: between 3x and 30x off. Say which assumption would have to be true for the claim to hold.
   - **Doesn't add up**: more than 30x off. Say what the claim implies that cannot be right (for example "that would mean every adult in the country uses it twice a day").
4. Finish with the single question the user should ask the person who quoted the number.

## Rules

- Judge the number, not the person who quoted it.
- Check units and time periods first. Many bad numbers are per-month figures quoted as per-day, or millions quoted as billions.
- Do not search the web or call tools.
- If you cannot build an independent estimate, say so rather than guessing a verdict.
- Keep the reply under 200 words.
