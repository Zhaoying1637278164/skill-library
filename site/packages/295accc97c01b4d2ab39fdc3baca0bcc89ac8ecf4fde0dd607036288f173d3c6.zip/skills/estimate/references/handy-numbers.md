# Handy numbers

Round numbers for back-of-the-envelope estimates. They are meant to be easy to multiply, not precise.

## Time

| Thing | Round number |
| --- | --- |
| Seconds in a minute / hour / day | 60 / 3,600 / ~86,000 (use 100,000 for one significant figure) |
| Seconds in a year | ~30 million (3 x 10^7) |
| Hours in a year | ~8,800 |
| Working hours in a year | ~2,000 |
| Working days in a year | ~250 |
| Weeks in a year | 52 |

## Data sizes

| Thing | Round number |
| --- | --- |
| Bytes in a KB / MB / GB / TB | 10^3 / 10^6 / 10^9 / 10^12 |
| A character of English text | ~1 byte |
| A page of text | ~2 KB |
| A typical web page with assets | ~2 MB |
| A phone photo | ~3 MB |
| A minute of compressed audio | ~1 MB |
| A minute of HD video | ~100 MB |

## Computing latencies (orders of magnitude)

| Operation | Time |
| --- | --- |
| Main memory reference | ~100 ns |
| Read 1 MB sequentially from memory | ~100 microseconds |
| SSD random read | ~100 microseconds |
| Round trip inside a data centre | ~0.5 ms |
| Read 1 MB sequentially from SSD | ~1 ms |
| Disk seek (spinning disk) | ~10 ms |
| Round trip across a continent | ~50 ms |
| Round trip across an ocean | ~150 ms |

## Throughput

| Thing | Round number |
| --- | --- |
| 1 request per second, per day | ~86,000 requests (use 100,000) |
| 1 request per second, per month | ~2.6 million |
| 1 million requests per day | ~12 per second on average; peak is often 3 to 10 times the average |

## People and places

| Thing | Round number |
| --- | --- |
| World population | ~8 billion |
| United States population | ~330 million |
| People per household (US) | ~2.5 |
| Waking hours per day | ~16 |
| Human walking speed | ~5 km/h (3 mph) |
| Reading speed | ~250 words per minute |
| Speaking speed | ~150 words per minute |

## Rules of thumb

- Rule of 72: years to double is about 72 divided by the percentage growth rate.
- 10% compounded for 7 years roughly doubles.
- A 1% daily improvement compounds to about 37x in a year.
- "Nines" of availability: 99% is ~3.7 days of downtime a year, 99.9% is ~9 hours, 99.99% is ~50 minutes.
