---
name: estimate
description: Make a back-of-the-envelope estimate with stated assumptions and a range. Use when the user asks roughly how much, how many, how long or how big something is, asks for a Fermi estimate, a ballpark, or napkin math, or runs /napkin-math:estimate <question>.
---

# Napkin math: estimate

Answer "roughly how much?" questions the way a good engineer does on a napkin: a few multiplied factors, each one defensible, with an honest range.

The question: $ARGUMENTS (or the one in the conversation). If there is no question yet, ask for it and stop.

## Steps

1. Restate what is being estimated, with units, in one sentence.
2. Break it into three to six factors that multiply or add up to the answer. Prefer factors the user could check.
3. For each factor give a low, a likely and a high value, and one short reason. Use round numbers.
   - When a factor is a well-known constant (seconds in a day, bytes in a gigabyte, typical latencies, working hours in a year), take it from `references/handy-numbers.md` rather than from memory.
   - If the user gave a number, use theirs and say so.
4. Multiply through and show the result as a table, then one line:

   **About X (likely between L and H).**

5. Name the one factor that moves the answer most, and what the user could look up to pin it down.

## Rules

- One significant figure is usually enough. Never report more than two.
- Keep the arithmetic visible so the user can swap in their own numbers.
- Do not search the web or call tools. The point is reasoning from rough numbers. If the user wants a looked-up figure instead, say this skill does not do that.
- If low and high are more than 100x apart, say the estimate is weak and which factor is to blame.
- Keep the reply under 250 words.
