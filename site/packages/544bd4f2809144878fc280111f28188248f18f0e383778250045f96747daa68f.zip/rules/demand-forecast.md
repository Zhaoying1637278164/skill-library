# Demand Forecast Rules

需要予測（自動発注／在庫最適化／フードロス削減／売上予測）に関わる開発・分析の不変ポリシー。本ルールは Claude Code が需要予測に関連する議題を検出した時点で自動適用され、5つの Skill（`demand-forecast-pipeline` / `-eda` / `-feature-engineering` / `-modeling` / `-error-analysis`）の上位レイヤーとして機能する。

## 起動条件

次のいずれかが議題に出た時点で常時適用：
- 需要予測 / 自動発注 / 売上予測 / フードロス予測 / 在庫最適化 / 予測モデル精度改善
- 「予測精度を上げたい」「ベースラインに勝てない」型の相談
- Walk-Forward Validation / Time Series CV / バックテスト
- ADI / CV² / 間欠需要 / Croston / SBA
- LightGBM / skforecast / StatsForecast / HierarchicalForecast を時系列文脈で利用

---

## 1. 基本原則 (Core Principles)

### 1.1 データリーク（Data Leakage）の防止 — **CRITICAL**

時系列予測において未来の情報が過去の学習に混入することは厳禁。特徴量の生成（移動平均など）やスケーリングは、常に**予測時点より過去のデータのみ**を使用する。

- ローリング統計量は必ず `target.shift(1).rolling(N)` の形式（`shift(1)` 抜きは即停止対象）
- 標準化／正規化／分位点計算は train fold 内のみで実施、test fold へは fit 結果を流用
- 特徴量選択（Boruta／SHAP／LASSO）も train 期間限定
- `demand-forecast-feature-engineering` Skill の `templates/leakage_check.py` で 5項目を機械検証

### 1.2 ベースラインの確立 — **CRITICAL**

複雑な機械学習モデルを構築する前に、必ず `Naive`（直近値）／ `Seasonal Naive`（前周期同曜日）／ `Moving Average` / `SES` などのシンプル統計モデルでベースラインを作成し、**費用対効果（精度向上幅）を検証**すること。

- 検証は `StatsForecast` を推奨（数万 SKU でも数秒）
- 高度モデルとベースラインは**同じ Walk-Forward 設定**で評価し、フェアな比較を担保

**3段階の採用判定**（`demand-forecast-modeling` Skill §9 で機械化）：

| 結果 | status | 採用判定 |
|---|---|---|
| advanced_mape < baseline_mape × 0.95 | success | 採用（5%以上の有意改善） |
| baseline_mape × 0.95 ≤ advanced_mape < baseline_mape | success（marginal） | 採用可、ただし warnings 添付 |
| advanced_mape ≥ baseline_mape | **error 即停止** | **採用禁止**（G1切替 or baseline 採用 or abort） |

3つ目（ベースライン未満）は CRITICAL 違反として扱い、modeling Skill が `status=error` で即停止し、`decision.json` で `model_family_switch` or `abort` を強制する。

### 1.3 Walk-Forward Validation の厳守 — **CRITICAL**

データをランダムに分割する（`train_test_split` / K-Fold CV）ことは禁止。必ず時間をスライドさせながら評価するバックテスト（Time Series Cross-Validation）を使用。

- 推奨：`skforecast.model_selection.TimeSeriesFold` ＋ `backtesting_forecaster`
- `cv_steps` / `initial_train_size` / `refit` は**実業務サイクル**に合わせる（例：週1再学習・次7日予測なら steps=7, refit=True）
- `gap` でリードタイム（発注から納品までの日数）を再現

### 1.4 確率的予測の重視 — **HIGH**

ビジネス上の意思決定（在庫最適化など）に直結させるため、単一の点予測ではなく、**予測区間（分位点予測）**や**確率分布**を出力するモデル設計を優先する。

- `interval_method='bootstrapping'` ＋ `interval=[5, 95]`（90%予測区間）が標準
- `n_boot=200` が一般的、メモリ制約時は 50 まで縮小可
- 実績の `interval_coverage` が 0.85〜0.95 が健全

### 1.5 重大分岐ゲート（G1/G2）でのユーザー承認 — **CRITICAL**

ループ実行中に次の重大変更が必要になった場合、ユーザー承認なしの自動進行は禁止：

- **G1: モデル系統切替**（例：LightGBM → Croston）
- **G2: 因果仮説の根本変更**（既存仮説 3 連続不支持時など）

`demand-forecast-pipeline` Skill `references/loop-control.md` でゲート条件を定義済み。

---

## 2. 探索的データ分析 (EDA) と前処理

### 2.1 欠損値補間 — **HIGH**

単純な平均値補完は避け、時間的な連続性を考慮する：

- **線形補間（時間考慮）**：`df['value'].interpolate(method='time')`
- **前方補間（フォールバック）**：`df['value'].ffill()` （連続欠損が長い区間）
- **スプライン／多項式補間**：滑らかな曲線が欲しい場合のみ

### 2.2 時系列分解 (STL Decomposition) — **HIGH**

データを「トレンド」「季節性」「残差」に分解：

- `statsmodels.tsa.seasonal.STL(series, period=7, robust=True)` を標準
- 複数周期（日次×年次）は `MSTL`
- **残差成分に対して 3σ ルール**で異常値（イベントや外れ値）を特定 → 削除ではなく `is_event` フラグ列化

### 2.3 変化点検知 — **MEDIUM**

`ruptures` ライブラリでトレンドや分散が構造的に変化したタイミング（レジームシフト）を特定し、**学習データの期間選定**に活用：

- `rpt.Dynp(model="l2", min_size=7).fit(signal).predict(n_bkps=3)`
- 大規模データなら `rpt.Binseg` / `rpt.Pelt` を選ぶ
- 検出された最新変化点以降のみを学習対象とする運用が一般的

### 2.4 ADI × CV² 4象限分類 — **HIGH**

EDA の最後に必ず実施し、**推奨モデル系統**を出力：

| 象限 | 基準 | 推奨 |
|---|---|---|
| Smooth | ADI < 1.32 ∧ CV² < 0.49 | ARIMA／SES／Holt-Winters／LightGBM(exog豊富時) |
| Erratic | ADI < 1.32 ∧ CV² ≥ 0.49 | LightGBM_with_exog／SBA |
| Intermittent | ADI ≥ 1.32 ∧ CV² < 0.49 | Croston／SBA／TSB／ADIDA（**LightGBM 禁忌**）|
| Lumpy | ADI ≥ 1.32 ∧ CV² ≥ 0.49 | SBA／確率的予測／Dual CNN |

詳細は `demand-forecast-eda` Skill。

---

## 3. 特徴量エンジニアリング (Feature Engineering)

### 3.1 ラグとローリング特徴量 — **CRITICAL（shift(1) 必須）**

- ラグ特徴量：`target.shift(k)` で過去 k 期前の値（`k > 0` 必須、`shift(-k)` は未来漏洩で禁止）
- ローリング特徴量：`target.shift(1).rolling(N).mean()` の形式（**`shift(1)` 抜きは CRITICAL 違反**）
- EWMA（指数加重移動平均）も同様：`target.shift(1).ewm(alpha=α).mean()`
- 推奨ラグ集合：Smooth=[1,7]／Erratic=[1,7,14,28]／Intermittent=[7,14,28]／Lumpy=限定使用
- ACF / PACF で確認した主要ラグも参考

**`shift(1)` 不要な例外ケース**：
- STL/MSTL 分解の残差成分（`statsmodels.STL` は in-sample 計算で過去のみ使用）
- 既知の外生変数（祝日カレンダー、価格表）：未来の値が確定済みなので shift 不要
- カテゴリ集約統計（store_id 別 mean 等）：時系列方向を使わない場合のみ
- 上記は SKILL 内 Anti-Patterns ではなく **rule の例外** として明示

### 3.2 周期性のエンコーディング (Cyclical Encoding) — **HIGH**

月（1〜12）／曜日（0〜6）／時間（0〜23）などを**そのままの数値で扱わない**。三角関数で円周上の座標に変換：

```python
df['month_sin'] = np.sin(df['month'] * (2 * np.pi / 12))
df['month_cos'] = np.cos(df['month'] * (2 * np.pi / 12))
```

`feature_engine.creation.CyclicalFeatures` で対象列の最大値を自動検出する手もある。

### 3.3 外部変数（外生変数）の組み込み — **HIGH**

- **連続変数**：プロモ強度／気温（Degree-day 等）／価格／マクロ指標
- **離散イベント**：祝日／プロモ／キャンペーンを 3アプローチ
  1. **バイナリフラグ**：その日が該当か（最もシンプル）
  2. **イベント種類の細分化**：「クリスマス」「特定プロモ」を個別カテゴリ化（影響の質が違う）
  3. **前後ウィンドウ**：駆け込み需要（`shift(-N)`）／反動減（`shift(N)`）

`is_weekend` は `dayofweek.isin([5, 6])` で定義（pandas 規約：月=0, 日=6）。

### 3.4 特徴量選択 — **MEDIUM**

`BorutaShap`（時系列に堅牢、第一推奨）／ `LASSO`（L1正則化、高次元向け粗選別）でノイズ除去し、過学習を防ぐ。**train 期間のみ**で実施（漏洩防止）。

詳細は `demand-forecast-feature-engineering` Skill。

---

## 4. モデリング戦略 (Modeling Strategy)

### 4.1 需要パターンに応じた手法選択 — **HIGH**

ADI × CV² 分類（§2.4）に従って手法を切り替える。

- **Smooth / Erratic**：LightGBM / XGBoost / CatBoost / AutoARIMA / AutoETS。履歴が十分なら**ニューラル**も対応（表形式 `mlp`、系列ネイティブ `NBEATS`/`NHITS`/`TFT`）
- **Intermittent / Lumpy**：Croston / SBA / TSB / ADIDA（間欠需要専用）。Lumpy のみ確率的 `DeepAR` を任意併用（点予測ニューラルは不可）
- 系統を逆転（例：Intermittent に LightGBM・点予測ニューラル）すると、ゼロ需要に引きずられて全体平坦化

**ニューラル対応のガードレール（必須）**：①最小履歴を満たす系列のみ（既定 180 期、`models.neural_min_obs` で調整）②**確率出力**（区間/分布）を必ず出す（点予測のみ不可）③**Walk-Forward 厳守**（`gap=lead_time`）④**3段階採用判定**に通す（ベースライン未満は採用禁止）⑤すべて**オプション依存**＝未導入時は `lightgbm`→`ridge` に自動フォールバック。`input.json` の `models.enable_neural`/`backends`/`neural_min_obs` で制御。

### 4.2 コールドスタート問題 — **MEDIUM**

履歴のない新商品の予測には次のいずれか：

- **メタデータ活用グローバルモデル**（DeepAR / LightGBM with item attributes）
- **時系列基盤モデル**（Chronos / TimeGPT / TimesFM）でゼロショット ← `models.py` の `foundation` アダプタで対応
- **CDLF（条件付き拡散モデル）**で確率的ライフサイクル予測
- 古典的：**Bass モデル**

`recommend()` は n_obs<28 を cold start とみなし `foundation(chronos/timegpt/timesfm)` + `bass` を提案（`models.enable_neural` 連動）。基盤モデルは未導入時に自動フォールバック。
詳細は `demand-insight-modeling` の `templates/models.py` / `demand-insight-eda` 4象限判定の延長。

### 4.3 階層的予測 (Hierarchical Forecasting) — **HIGH**

SKU・店舗・全社などの階層構造がある場合、各層で独立予測すると合計が一致しない。`HierarchicalForecast` の **MinTrace（mint_shrink 推奨）** で誤差の分散共分散行列から全体が整合するように予測値を調整（Reconciliation）。

- 代替方式：Bottom-Up / Top-Down / Middle-Out
- 共分散行列が特異化しやすい場合は `mint_shrink`（shrinkage 推定）が安定

詳細は `demand-forecast-error-analysis` Skill `templates/reconcile.py`。

---

## 5. バックテストと評価 (Backtesting & Evaluation)

### 5.1 ビジネス指標翻訳の必須化 — **CRITICAL**

精度数値（MAPE / RMSE）だけでの報告は禁止。必ず以下に翻訳：

- **在庫切れ件数／月**
- **廃棄金額／月**
- **発注作業時間／日**

`input.json.business_kpi` で対象 KPI を定義、未定義なら status=warning で業務担当ヒアリング推奨。

### 5.2 非対称コストの考慮 — **HIGH**

欠品コストと余剰コストは通常異なる。RMSE 最小ではなく**総ビジネスコスト最小**を主指標に：

```python
def asymmetric_inventory_cost(y_true, y_pred,
                              shortage_penalty=5.0, excess_penalty=1.0):
    error = y_pred - y_true
    cost = np.where(error < 0, -error * shortage_penalty, error * excess_penalty)
    return float(np.mean(cost))
```

`skforecast.backtesting_forecaster(metric=asymmetric_inventory_cost)` でバックテストに直接組み込み可。

### 5.3 確率的予測の質評価 — **HIGH**

予測区間が安全在庫の根拠として機能するか確認：

- **Pinball Loss**：指定分位点（例：90%）の予測精度
- **CRPS**：予測分布全体の質（`properscoring.crps_ensemble`）
- **interval coverage**：実績が予測区間に収まる率（90%区間なら 0.85〜0.95 が健全）

### 5.4 モデルの解釈性確保 — **MEDIUM**

`SHAP`（`TreeExplainer` for GBDT）で予測の根拠を可視化し、**ビジネス側への説明責任**を果たす：

```python
import shap
explainer = shap.TreeExplainer(forecaster.regressor_)
shap_values = explainer.shap_values(X_train)
shap.summary_plot(shap_values, X_train)
shap.plots.waterfall(explainer.expected_value, shap_values[0,:], X_train.iloc[0,:])
```

特徴量重要度は `demand-forecast-error-analysis` Skill が**次仮説の手がかり**としても消費する。

---

## 6. 推奨ライブラリ (Recommended Libraries)

| 用途 | ライブラリ |
|---|---|
| 統計的ベースライン／間欠需要 | `StatsForecast`（AutoARIMA, AutoETS, ADIDA, Croston, SBA, TSB） |
| 機械学習パイプライン | `skforecast`（ForecasterRecursive + RollingFeatures + backtesting_forecaster） |
| 階層的予測 | `HierarchicalForecast`（MinTrace, Top-Down, Bottom-Up, Middle-Out） |
| 説明可能性 (XAI) | `SHAP`（TreeExplainer / KernelExplainer） |
| 特徴量選択 | `BorutaShap` / `feature_engine`（CyclicalFeatures） |
| 時系列分解 | `statsmodels.tsa.seasonal.STL` / `MSTL` |
| 変化点検知 | `ruptures`（Dynp / Binseg / Pelt） |
| 欠損可視化 | `missingno`（matrix / heatmap） |
| ニューラル（表形式 / 系列ネイティブ） | `torch`（`mlp`）／ `neuralforecast`（NBEATS, NHITS, TFT, DeepAR） ※すべてオプション |
| 基盤モデル | `chronos`（Amazon）／ `nixtla.NixtlaClient`（TimeGPT）／ `timesfm`（Google） ※すべてオプション |

---

## 7. Skill レイヤーとの接続

本ルールは「**何を絶対守るか／何を推奨するか**」を定義し、**「どう実装するか」**は5つの Skill に委譲する。

| Skill | 担当ステージ | 本ルール対応箇所 |
|---|---|---|
| `demand-forecast-pipeline` | メタ：ループ制御＋G1/G2＋状態管理＋最終レポート | §1.5（ゲート） |
| `demand-forecast-eda` | Stage 1+2：EDA + ADI×CV² 分類 | §2 全体 |
| `demand-forecast-feature-engineering` | Stage 3：特徴量設計＋データ漏洩防止 | §1.1 / §3 全体 |
| `demand-forecast-modeling` | Stage 4：ベースライン＋高度モデル＋Walk-Forward＋確率予測 | §1.2 / §1.3 / §1.4 / §4 全体 |
| `demand-forecast-error-analysis` | Stage 5+6：誤差分析＋仮説更新＋次アクション判定＋階層調整 | §4.3 / §5 全体 |

各 Skill の **Anti-Patterns** セクションは本ルールを文脈別に補強するもので、矛盾は無い設計。

---

## 重大度サマリ

| 重大度 | 該当項目 | 違反時 |
|---|---|---|
| **CRITICAL** | §1.1 データ漏洩防止／§1.2 ベースライン確立／§1.3 Walk-Forward 厳守／§1.5 ゲート承認／§3.1 shift(1) 必須／§5.1 業務指標翻訳必須 | 即停止、修正要求 |
| **HIGH** | §1.4 確率的予測／§2.1 欠損補間／§2.2 STL分解／§2.4 ADI×CV²／§3.2 Cyclical／§3.3 外生変数／§4.1 系統選択／§4.3 階層調整／§5.2 非対称コスト／§5.3 確率予測質 | 警告＋再検討要求 |
| **MEDIUM** | §2.3 変化点検知／§3.4 特徴量選択／§4.2 コールドスタート／§5.4 解釈性 | 提案を促す |
