---
description: Run the demand-insight workflow — hearing, the 8-step forecasting loop, or productionization. Pass a subcommand; blank = start from hearing/init.
argument-hint: <init|hearing|run|eda|classify|features|model|evaluate|report|productionize>
---

# /demand-insight

Use-case-driven demand forecasting & data analysis. Honors the CRITICAL policies in
`rules/demand-forecast.md` (leakage prevention, baseline-first, Walk-Forward, decide-by-comparison,
business-KPI translation).

**Input**: `$ARGUMENTS`

## Dispatch

Parse the first token of `$ARGUMENTS` as the subcommand (default: `init`).

- **init** / **(blank)** → Invoke the `demand-insight` skill. Conduct the **H1–H8 hearing** (use case,
  data pattern P1/P2/P3 from column structure, horizon, lead time, external data, fulfillment/cost,
  classification approach, output). Write `input.json` (per `schemas/input.schema.json`) and initialize
  `state.json` (`{step:"hearing", iteration:0, history:[]}`).
- **hearing** → Re-run only the H1–H8 hearing and update `input.json`.
- **run** → Hand off to the `demand-insight-orchestrator` agent to run the full loop with G1/G2 gates.
- **eda** → Invoke `demand-insight-eda` (Step 1).
- **classify** → Invoke `demand-insight-classification` (Steps 2–3).
- **features** → Invoke `demand-insight-features` (Step 4).
- **model** → Invoke `demand-insight-modeling` (Steps 5/7). Append `--advanced` for hard segments.
- **evaluate** → Invoke `demand-insight-evaluation` (Step 6).
- **report** → Invoke `demand-insight-evaluation`'s `excel_report.py` (Step 8, Excel output).
- **productionize** → Invoke `demand-insight-productionize` (only if a model is accepted).

## Notes
- Never skip Step 0 hearing — use case drives all downstream output/eval/branching.
- Pause at G1 (model-family switch) and G2 (causal-hypothesis overhaul) for user approval.
- Remaining args after the subcommand (e.g. a data path or input.json path) are passed through to the skill.
