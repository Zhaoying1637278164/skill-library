"""Tests for the demand-insight advanced-model registry (models.py).

Covers the always-available ridge path, graceful skipping of unavailable models,
selection precedence/fallback, token normalization, and (when torch is installed)
the tabular MLP fit/predict + MC-dropout interval contract.
"""
import os
import sys

import numpy as np
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(HERE, "..", "skills", "demand-insight-modeling", "templates")
sys.path.insert(0, os.path.abspath(TEMPLATES))

import models  # noqa: E402


def _xy(n=80, d=3, seed=0):
    rng = np.random.RandomState(seed)
    X = rng.rand(n, d)
    y = X @ np.array([1.0, 2.0, 3.0]) + rng.rand(n) * 0.1
    return X, y


# --- ridge: always available, leakage-safe, non-negative ---------------------
def test_ridge_always_available():
    a = models.resolve("ridge")
    assert a is not None and a.name == "ridge" and a.kind == "tabular"


def test_ridge_fit_predict_nonneg():
    X, y = _xy()
    pred = models.RidgeAdapter().fit_predict(X[:60], y[:60], X[60:])
    assert pred.shape == (20,)
    assert (pred >= 0).all()


# --- unavailable / non-tabular tokens are skipped, never crash ----------------
@pytest.mark.parametrize("name", ["croston", "tsb", "sba", "ets", "arima", "cold_start", "bass"])
def test_statistical_tokens_not_served_here(name):
    assert models.resolve(name) is None


def test_normalize_aliases():
    assert models._normalize("lightgbm_exog") == "lightgbm"
    assert models._normalize("foundation(chronos/timegpt/timesfm)") == "foundation"
    assert models._normalize("chronos") == "foundation"
    assert models._normalize("croston") is None  # stat -> skipped


# --- selection precedence and guaranteed fallback ----------------------------
def test_select_falls_back_to_available_tabular():
    # only statistical tokens -> must fall through to lightgbm or ridge
    a = models.select(["croston", "ets", "sba"], {})
    assert a is not None and a.name in ("lightgbm", "ridge")


def test_select_backends_override_still_safe():
    a = models.select([], {"models": {"backends": ["mlp", "nbeats"]}})
    # torch/nf may be absent -> guaranteed a working tabular adapter
    assert a is not None and a.kind in ("tabular", "series")


def test_select_enable_neural_false_returns_tabular():
    a = models.select(["mlp", "nbeats", "lightgbm"], {"models": {"enable_neural": False}})
    assert a.name in ("lightgbm", "ridge")


def test_select_returns_adapter_even_with_empty_input():
    a = models.select([], {})
    assert a is not None and a.name in ("lightgbm", "ridge")


# --- mlp path (only when torch is installed) ---------------------------------
def _has_torch():
    try:
        import torch  # noqa: F401
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _has_torch(), reason="torch not installed")
def test_mlp_fit_predict_and_intervals():
    X, y = _xy(n=120, d=4)
    a = models.resolve("mlp")
    assert a is not None and a.kind == "tabular"
    pred = a.fit_predict(X[:90], y[:90], X[90:], seed=42)
    assert pred.shape == (30,) and (pred >= 0).all()
    point, samples = a.fit_predict_samples(X[:90], y[:90], X[90:], seed=42, n=50)
    assert point.shape == (30,)
    assert samples.shape == (50, 30)
    lo, hi = np.percentile(samples, 5, axis=0), np.percentile(samples, 95, axis=0)
    assert (hi >= lo).all()


@pytest.mark.skipif(not _has_torch(), reason="torch not installed")
def test_mlp_auto_selected_when_recommended_and_torch_present():
    a = models.select(["lightgbm", "mlp"], {"models": {"enable_neural": True}})
    assert a.name == "mlp"  # PRIORITY ranks mlp above lightgbm
