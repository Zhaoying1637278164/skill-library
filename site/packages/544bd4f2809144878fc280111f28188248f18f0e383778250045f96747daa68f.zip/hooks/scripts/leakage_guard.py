#!/usr/bin/env python3
"""demand-insight PreToolUse guard — warn on time-series data-leakage patterns.

Reads the Write/Edit hook payload from stdin, scans the to-be-written Python
content for leakage patterns, and prints a warning. Non-blocking (always exit 0):
it advises, it does not prevent the write. Robust by design — any error → exit 0.

Detected patterns (CRITICAL per rules/demand-forecast.md):
  - `.rolling(` / `.ewm(` on a target without a preceding `.shift(`  → uses current period
  - `.shift(-k)` on the target                                       → future information
  - `train_test_split` / `KFold` on time series                      → random split (use Walk-Forward)
"""
import sys
import re
import json


def _content_from_payload(payload: dict) -> tuple[str, str]:
    ti = payload.get("tool_input") or {}
    path = ti.get("file_path") or ti.get("path") or ""
    # Write → content ; Edit → new_string ; MultiEdit → edits[].new_string
    content = ti.get("content") or ti.get("new_string") or ""
    if not content and isinstance(ti.get("edits"), list):
        content = "\n".join(e.get("new_string", "") for e in ti["edits"])
    return path, content


def scan(content: str) -> list[str]:
    warnings = []
    lines = content.splitlines()
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if s.startswith("#"):
            continue
        # rolling/ewm without shift on the same line (heuristic)
        if re.search(r"\.(rolling|ewm)\s*\(", line) and ".shift(" not in line:
            warnings.append(f"L{i}: `.rolling()/.ewm()` without `.shift(1)` - "
                            f"target-derived rolling features must use target.shift(1).rolling(N).")
        # future shift on target
        if re.search(r"\.shift\(\s*-\s*\d+", line):
            warnings.append(f"L{i}: `.shift(-k)` detected - negative shift leaks future information.")
        # random split on time series
        if re.search(r"\btrain_test_split\b", line) or re.search(r"\bKFold\b", line):
            warnings.append(f"L{i}: random split (`train_test_split`/`KFold`) — use Walk-Forward / TimeSeriesFold.")
    return warnings


def main() -> int:
    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw.strip() else {}
    except Exception:
        return 0
    try:
        path, content = _content_from_payload(payload)
        if not path.endswith(".py") or not content:
            return 0
        # only inspect files that look like feature / model code
        if not re.search(r"feature|model|train|forecast|lag|rolling|pipeline", path, re.I) \
           and not re.search(r"\.(rolling|ewm|shift)\(", content):
            return 0
        warnings = scan(content)
        if warnings:
            sys.stderr.write("\n[demand-insight] WARNING: possible data leakage in "
                             f"{path}:\n  - " + "\n  - ".join(warnings) +
                             "\n  See rules/demand-forecast.md section 1.1 / 3.1.\n")
    except Exception:
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
