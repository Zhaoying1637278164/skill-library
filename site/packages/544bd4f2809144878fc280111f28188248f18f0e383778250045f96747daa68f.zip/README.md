# demand-insight

A self-contained Claude Code **plugin** for use-case-driven demand forecasting & data analysis.
Bring your sales/shipment actuals (and optional weather/calendar/promotions); it runs an 8-step
iterative loop, supports your decisions at each step, and finally generates a **production
implementation (code + tests + deploy)**.

Independent of any other forecasting skills.

## Why

- **Use-case driven** — predictive (①simple/②ordering/③landing) or diagnostic (A–E) determines output, metrics, and branching.
- **No data leakage by construction** — rolling features must use `shift(1)`; lags `< horizon` are dropped; a PreToolUse hook flags violations as you write code.
- **Baseline-first** — Naive/Seasonal-Naive/MA/SES always built; advanced models adopted only when they beat baseline by a meaningful margin.
- **Pluggable model registry** — statistical, LightGBM, **neural nets** (tabular MLP, NBEATS/NHITS/TFT/DeepAR) and **foundation models** (Chronos/TimeGPT/TimesFM) behind one interface. Auto-selected per ADI×CV² quadrant; all optional with graceful fallback to `lightgbm`→`ridge`.
- **Walk-Forward Validation only** — no random splits; lead time modeled via `gap`.
- **Decide by comparison, not fixed thresholds** — ADI/CV² and segment cuts are starting points; distributions are presented for you to choose (transparent, reproducible).
- **Business-KPI translation** — results in stockouts/month, waste cost/month, ordering hours/day — with asymmetric stockout-vs-overstock cost. Reports as **Excel (.xlsx)**.

## Install

```
/plugin marketplace add norihiro-kajita/demand-insight
/plugin install demand-insight
```

(Or local: `/plugin marketplace add <path-to-this-repo>`.)

## Usage

```
/demand-insight init           # H1–H8 hearing + scaffold input.json/state.json
/demand-insight run            # run the iterative loop (G1/G2 gates pause for approval)
/demand-insight eda|classify|features|model|evaluate|report   # individual steps
/demand-insight productionize  # generate src/ + tests/ + deploy after acceptance
```

### The 8-step loop

| Step | Skill | Highlights |
|---|---|---|
| 0 Hearing | `demand-insight` | H1–H8 (use case, P1/P2/P3, horizon, lead time, external data, fulfillment, approach, output) |
| 1 EDA | `demand-insight-eda` | missing(time-interp)/outlier(3σ→is_event)/STL/ACF·PACF/ADF/change points |
| 2–3 Classification | `demand-insight-classification` | 4 axes + SBC quadrants + hierarchical segments + rule-based vs ML; per-segment unit/horizon |
| 4 Features | `demand-insight-features` | calendar/cyclical/lag/rolling(`shift(1)`)/exog, horizon-availability constrained |
| 5/7 Modeling | `demand-insight-modeling` | baselines → model registry: LightGBM/Croston/SBA + optional neural (mlp/NBEATS/NHITS/DeepAR) + foundation (Chronos/TimeGPT/TimesFM), Walk-Forward, intervals, SHAP |
| 6 Error analysis | `demand-insight-evaluation` | accuracy/fulfillment/bias, asymmetric cost, Pinball/CRPS, `decision.json` |
| 8 Report | `demand-insight-evaluation` | Excel (.xlsx), function-first |
| Productionize | `demand-insight-productionize` | `src/` + pytest + deploy config |
| Meta | `demand-insight` + `demand-insight-orchestrator` agent | loop control, G1/G2, state.json |

## Configuration (`input.json`)

Carries a `data_source` block plus use-case / horizon / hearing fields. See [`schemas/`](schemas/)
and the worked example in [`examples/input.json`](examples/input.json). Policy: [`rules/demand-forecast.md`](rules/demand-forecast.md).

## Try it

A synthetic P3 (store × SKU) dataset is bundled. See [`examples/walkthrough.md`](examples/walkthrough.md)
for `init → run → report → productionize` end to end.

## Requirements

Python 3.10+. Libraries: `statsforecast`, `skforecast`, `lightgbm`, `statsmodels`, `ruptures`, `shap`,
`openpyxl`, `hierarchicalforecast`. (The generated production code falls back to a ridge model if LightGBM is absent.)

Optional neural / foundation models (all opt-in; the pipeline auto-falls back to `lightgbm`→`ridge` when absent):
`torch` (tabular `mlp` with MC-dropout intervals), `neuralforecast` (NBEATS/NHITS/TFT/DeepAR),
`chronos` / `nixtla` (TimeGPT) / `timesfm` (zero-shot foundation models for cold start). Control via the
`models` block in `input.json` (`enable_neural`, `neural_min_obs`, `backends`) or `advanced_model.py --model NAME`.

## Acceptance criteria

EDA report from actuals; advanced model beats baseline by ≥5%; leakage auto-verified; KPI-translated
Excel report; production test coverage ≥80%; Walk-Forward matches the business cycle.

## Roadmap / TODO

- GitHub Actions CI to run `pytest` on the generated reference implementation.
- Connectors for economic indicators / competitor data.
- Foundation-model cold start (TimeGPT / Chronos / TimesFM).
- Time-series shape clustering (DTW) — lightweight now, approximate for large catalogs.

## License

MIT — see [LICENSE](LICENSE).
