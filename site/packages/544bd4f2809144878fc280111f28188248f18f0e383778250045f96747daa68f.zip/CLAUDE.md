# CLAUDE.md — demand-insight plugin

This repository **is** a self-contained Claude Code plugin named `demand-insight`. It implements a
generic demand-forecasting & data-analysis workflow as an installable plugin, and it is
**independent** of any other demand-forecast skills on the machine.

## What it does

Given user-supplied actuals (sales/shipment/inventory) and optional external data (weather, calendar,
promotions), it runs a **use-case-driven, 8-step iterative loop**, supports decisions at each step, and
finally generates a **production implementation (code + tests + deploy)**.

```
Step 0  Hearing            H1–H8 runtime questions (use case, data pattern, horizon, lead time, external data, fulfillment, classification approach, output)
Step 1  EDA / preprocess   missing(time-interp) / outlier(3σ→is_event) / STL / ACF·PACF / ADF / change points
Step 2  Classification     4 axes (volume/ADI/CV²/trend) + SBC quadrants + hierarchical segments + rule-based vs ML clustering (compare)   ← core
Step 3  Segment spec       per-segment forecast unit & horizon (lead-time aware)
Step 4  Features           calendar / cyclical sin·cos / lag / rolling (shift(1)!) / exogenous (horizon-availability constrained)
Step 5  Modeling           baselines (Naive/SNaive/MA/SES) → advanced via model registry (LightGBM/Croston/SBA… + optional neural: mlp/NBEATS/NHITS/DeepAR + foundation: Chronos/TimeGPT/TimesFM), Walk-Forward + intervals
Step 6  Error analysis     accuracy / fulfillment / bias (asymmetric cost), feedback loop
Step 7  Advanced methods   only for hard segments
Step 8  Report             Excel (.xlsx), function-first
```

## Components (plugin layout)

- `skills/` — `demand-insight` (entry/orchestration), `-eda`, `-classification`, `-features`, `-modeling`,
  `-evaluation`, and `-productionize` (generates the production scaffold).
- `agents/demand-insight-orchestrator.md` — drives the loop across iterations.
- `commands/demand-insight.md` — `/demand-insight <init|hearing|run|eda|classify|features|model|evaluate|report|productionize>`.
- `hooks/` — PreToolUse leakage guard (flags `rolling(...)` without `shift(1)`, `shift(-k)`, future-target refs).
- `schemas/` — `input.schema.json`, `state.schema.json`, `decision.schema.json`.
- `examples/` — synthetic P3 (store × SKU) dataset + end-to-end walkthrough.
- `rules/demand-forecast.md` — embedded cross-cutting policy (self-contained copy).

## Non-negotiable policies (CRITICAL — see `rules/demand-forecast.md`)

1. **No data leakage.** Rolling stats MUST be `target.shift(1).rolling(N)`. `shift(-k)` on the target is
   forbidden. With horizon `h`, lags `< h` are future information (Direct method). Scale/select on train fold only.
2. **Baseline first.** Always build Naive/Seasonal-Naive/MA/SES. Adopt an advanced model only if it beats
   baseline; `advanced ≥ baseline` → stop (no adoption).
3. **Walk-Forward Validation only.** Never `train_test_split` / random K-Fold. Use `gap` for lead time.
4. **Decide by comparison, not fixed thresholds.** ADI/CV² (1.32/0.49) and segment cuts are starting points;
   present distributions and let the user decide. Keep it transparent and reproducible.
5. **Translate metrics to business KPIs.** Never report MAPE/RMSE alone — translate to stockouts, waste cost,
   ordering hours; weight stockout vs overstock asymmetrically.

## Conventions

- `input.json` carries a `data_source` block (`path`, `time_column`, `target_column`, `id_columns`,
  `exog_columns`) plus use-case / horizon / hearing fields. See `schemas/input.schema.json`.
- Templates are runnable: `python skills/<skill>/templates/<script>.py input.json`.
- Python 3.10+. Libraries: statsforecast, skforecast, lightgbm, statsmodels, ruptures, shap, openpyxl, hierarchicalforecast.
  Optional neural/foundation (graceful fallback to lightgbm→ridge if absent): torch (`mlp`), neuralforecast (NBEATS/NHITS/TFT/DeepAR), chronos/nixtla/timesfm (foundation). Selected via `input.json` `models` block / `--model`. See `skills/demand-insight-modeling/templates/models.py`.
- Fix random seeds; version data/model/code. Output reports as Excel (function-first).

## Quick start

```
/plugin marketplace add <this repo>
/plugin install demand-insight
/demand-insight init        # hearing (H1–H8) + scaffold input.json/state.json
/demand-insight run         # run the iterative loop
/demand-insight productionize
```

See [`README.md`](README.md) for installation and usage.
