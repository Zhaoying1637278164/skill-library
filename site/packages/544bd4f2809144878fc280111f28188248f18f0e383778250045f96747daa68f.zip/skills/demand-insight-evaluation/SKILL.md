---
name: demand-insight-evaluation
description: Use this skill for Steps 6 & 8 of demand-insight — error analysis, business-KPI translation, and the Excel report. Computes accuracy metrics (MAE/RMSE/MAPE/MASE/WMAPE), fulfillment metrics (stockout/overstock), asymmetric business cost, probabilistic quality (Pinball/CRPS, interval coverage), detects systematic bias (by weekday/period/segment), updates hypotheses, recommends next_action (decision.json), optionally reconciles hierarchies (MinTrace), and emits a function-first Excel (.xlsx) report. Use after each modeling iteration, or to produce the final report.
---

# demand-insight-evaluation (Step 6+8: 誤差分析 + レポート)

精度だけでなく**業務指標へ翻訳**し、バイアスを是正し、意思決定（next_action）を出す（要件 §9/§10/§12）。

## CRITICAL（要件 §1.4 / §5.1 / §5.2）
- MAPE/RMSE 単独報告は禁止。**在庫切れ件数/月・廃棄金額/月・発注作業時間/日**へ翻訳（`decision.json.business_kpi`）。
- 欠品≠過剰の**非対称コスト**を主指標化（`shortage_penalty`/`excess_penalty`）。間欠需要は MAPE が壊れる→MASE/WMAPE。
- 確率予測の質: Pinball / CRPS / interval_coverage（90%区間で 0.85〜0.95）。

## Run
```bash
python templates/error_analysis.py input.json     # 指標 + 非対称コスト + Pinball + バイアス + 業務KPI翻訳 + decision.json
python templates/excel_report.py input.json --out reports/demand_insight_report.xlsx   # 最終 Excel（要件 §12）
```
階層調整（MinTrace / mint_shrink）は hierarchy 構造がある場合のオプション。`HierarchicalForecast` を導入し
セグメント→店舗→全社の整合を取る（将来拡張、`references` 参照）。

## 誤差分析（Step6）→ フィードバック
- バイアス検出: 系統的な過小/過大が曜日・期間・セグメントに偏っていないか。
- 是正方針 → `next_action`: `feature_refinement` / `model_family_switch`(G1) / `segment_revision` /
  `causal_hypothesis_overhaul`(G2, 仮説3連続不支持) / `accept` / `abort`。`decision.json`（`schemas/decision.schema.json`）。

## Excel レポート（Step8, §12）
`excel_report.py` が以下シートを出力（機能優先・ブランド様式なし）:
ヒアリング(H1-H8) / データ品質 / 分類(4軸・セグメント・ルール vs ML) / セグメント別仕様 / 採用特徴量 /
手法比較表 / 誤差・バイアス分析 / 最終予測・診断 / 前提・選定根拠。依存: `openpyxl`。

## Hand-off
`accept` なら `demand-insight-productionize` へ。継続なら `next_action` に従い Step4〜6 を再実行（G1/G2 はユーザー承認）。

## Anti-patterns
- 精度数値だけ報告 / 対称コストで評価 / バイアスを見ずに特徴量だけ足す。
