"""demand-insight Step 6 — error analysis, business-KPI translation, decision (functional).

Reads backtest_iter_001.csv + baseline_metrics.json + state.best_model, computes:
  - accuracy (MAPE/RMSE/MAE/bias), asymmetric cost, interval coverage,
  - Pinball loss (q=0.95 upper) as a probabilistic-quality proxy,
  - systematic bias by weekday,
  - business-KPI translation (stockouts/month, waste cost/month, fill rate),
  - next_action recommendation → decision.json (schemas/decision.schema.json).

Usage:
    python error_analysis.py input.json [--backtest backtest_iter_001.csv]
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import pandas as pd


def pinball(y, q_pred, q=0.95):
    y, q_pred = np.asarray(y, float), np.asarray(q_pred, float)
    e = y - q_pred
    return float(np.mean(np.maximum(q * e, (q - 1) * e)))


def main():
    ap = argparse.ArgumentParser(description="demand-insight error analysis")
    ap.add_argument("input")
    ap.add_argument("--backtest", default="backtest_iter_001.csv")
    a = ap.parse_args()
    cfg = json.load(open(a.input, encoding="utf-8"))
    bk = cfg.get("business_kpi", {})
    sp, ep = bk.get("shortage_penalty", 5.0), bk.get("excess_penalty", 1.0)
    unit_cost = bk.get("unit_cost", ep)

    if not os.path.exists(a.backtest):
        print("ERROR: backtest not found; run advanced_model.py first", file=sys.stderr); sys.exit(2)
    bt = pd.read_csv(a.backtest, parse_dates=["date"])
    y, p = bt["actual"].to_numpy(float), bt["forecast"].to_numpy(float)
    err = p - y
    horizon_days = int(cfg.get("horizon", 7))
    n_test_days = max(bt["date"].dt.normalize().nunique(), 1)

    mask = y > 0
    metrics = {
        "MAPE": round(float(np.mean(np.abs(err[mask] / y[mask])) * 100), 3) if mask.any() else None,
        "RMSE": round(float(np.sqrt(np.mean(err ** 2))), 3),
        "MAE": round(float(np.mean(np.abs(err))), 3),
        "ME_bias": round(float(np.mean(err)), 3),
        "asymmetric_cost": round(float(np.mean(np.where(err < 0, -err * sp, err * ep))), 3),
    }
    if {"lo_5", "hi_95"}.issubset(bt.columns):
        cov = float(((bt["actual"] >= bt["lo_5"]) & (bt["actual"] <= bt["hi_95"])).mean())
        metrics["interval_coverage"] = round(cov, 3)
        metrics["pinball_q95"] = round(pinball(y, bt["hi_95"].to_numpy(float), 0.95), 3)

    # bias by weekday
    bt["dow"] = bt["date"].dt.dayofweek
    bt["_err"] = bt["forecast"] - bt["actual"]
    bias_dow = {int(k): round(float(v), 3) for k, v in bt.groupby("dow")["_err"].mean().items()}
    max_dow_bias = max(abs(v) for v in bias_dow.values()) if bias_dow else 0.0

    # business KPI translation (estimates, scaled to per-month)
    days_per_month = 30.0
    scale = days_per_month / n_test_days
    stockout_units = float(np.sum(np.maximum(y - p, 0)))      # under-forecast
    waste_units = float(np.sum(np.maximum(p - y, 0)))         # over-forecast
    fill_rate = float(1 - stockout_units / max(np.sum(y), 1))
    business_kpi = {
        "stockouts_per_month": round(stockout_units * scale, 1),
        "waste_cost_per_month": round(waste_units * unit_cost * scale, 1),
        "fill_rate": round(fill_rate, 3),
        "ordering_hours_per_day": round(0.0, 1),  # set from ops process; placeholder
    }

    # next_action
    best = {}
    if os.path.exists("state.json"):
        try:
            best = json.load(open("state.json", encoding="utf-8")).get("best_model", {})
        except Exception:
            pass
    adoption = best.get("adoption", "unknown")
    if adoption == "reject":
        action, gate, rat = "model_family_switch", "G1", "advanced ≥ baseline; switch family or revert to baseline."
    elif max_dow_bias > 0.25 * (np.mean(y) or 1):
        action, gate, rat = "feature_refinement", None, "systematic weekday bias — add calendar/event features."
    elif adoption in ("adopt", "adopt_marginal"):
        action, gate, rat = "accept", None, "advanced beats baseline and KPIs translated."
    else:
        action, gate, rat = "feature_refinement", None, "baseline missing or inconclusive — iterate."

    decision = {
        "next_action": action, "gate_required": gate, "confidence": 0.7,
        "rationale": rat, "business_kpi": business_kpi,
        "evidence": {"metrics": metrics, "bias_by_dow": bias_dow,
                     "baseline": (json.load(open("baseline_metrics.json", encoding="utf-8")).get("best_metrics")
                                  if os.path.exists("baseline_metrics.json") else None),
                     "advanced": best},
    }
    json.dump(decision, open("decision.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    try:
        state = json.load(open("state.json", encoding="utf-8")) if os.path.exists("state.json") else {"iteration": 0}
        state["error_profile"] = {"metrics": metrics, "bias_by_dow": bias_dow}
        state["decision"] = decision
        state["step"] = "report" if action == "accept" else "features"
        json.dump(state, open("state.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except Exception:
        pass

    print("metrics:", json.dumps(metrics, ensure_ascii=False))
    print("business KPI (est/month):", json.dumps(business_kpi, ensure_ascii=False))
    print(f"next_action: {action}  gate={gate}  - {rat}")


if __name__ == "__main__":
    main()
