"""Function-first Excel (.xlsx) report for demand-insight (要件定義 §12).

Aggregates hearing (H1-H8), data quality, classification (rule vs ML),
per-segment spec, adopted features, model comparison, error/bias, final
forecast/diagnosis, and assumptions/rationale into one workbook.

Reads whatever artifacts exist (input.json, state.json, segments_*.json,
decision.json, backtest_*.csv) and degrades gracefully when some are absent.

Usage:
    python excel_report.py <input.json> [--state state.json] [--out reports/demand_insight_report.xlsx]
"""
import sys
import os
import json
import argparse
import glob


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _ws_table(ws, rows):
    """Write a list of rows (each a list) to a worksheet."""
    for r in rows:
        ws.append(r)


def build(cfg, state, out_path):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        print("ERROR: openpyxl not installed. `pip install openpyxl`", file=sys.stderr)
        sys.exit(2)

    wb = Workbook()
    bold = Font(bold=True)

    # 1) Hearing (H1-H8)
    ws = wb.active
    ws.title = "Hearing"
    ws.append(["項目", "値"]); ws["A1"].font = bold; ws["B1"].font = bold
    hearing = (state or {}).get("hearing") or cfg.get("hearing") or {}
    base = {
        "H1 用途 (use_case)": cfg.get("use_case"),
        "H2 データパターン": cfg.get("data_pattern") or (state or {}).get("data_pattern"),
        "H3 ホライズン/頻度": f"{cfg.get('horizon')} / {cfg.get('frequency')}",
        "H4 リードタイム": cfg.get("lead_time"),
        "H5 外部データ": cfg.get("exogenous"),
        "H6 充足/コスト": cfg.get("business_kpi"),
        "H7 分類アプローチ": cfg.get("classification_approach"),
        "H8 出力体裁": (cfg.get("output") or {}).get("report_format", "xlsx"),
    }
    for k, v in base.items():
        ws.append([k, json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v])
    for k, v in hearing.items():
        ws.append([str(k), json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v])

    # 2) Data quality
    ws = wb.create_sheet("DataQuality")
    ws.append(["指標", "値"]); ws["A1"].font = bold; ws["B1"].font = bold
    eda = (state or {}).get("eda_summary") or {}
    if eda:
        for k, v in eda.items():
            ws.append([str(k), json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v])
    else:
        ws.append(["(eda_summary 未生成)", "demand-insight-eda を先に実行してください"])

    # 3) Classification (rule vs ML)
    ws = wb.create_sheet("Classification")
    seg_rule = _load_json("segments_rule.json")
    if seg_rule and isinstance(seg_rule, list) and seg_rule:
        cols = list(seg_rule[0].keys())
        ws.append(cols)
        for c in range(1, len(cols) + 1):
            ws.cell(row=1, column=c).font = bold
        for row in seg_rule:
            ws.append([json.dumps(row.get(c), ensure_ascii=False) if isinstance(row.get(c), (dict, list)) else row.get(c) for c in cols])
    else:
        ws.append(["(分類結果 segments_rule.json 未生成)"])

    # 4) Segment spec
    ws = wb.create_sheet("SegmentSpec")
    segs = (state or {}).get("segments") or []
    if segs:
        cols = ["segment_id", "sbc_quadrant", "abc", "trend", "forecast_unit", "horizon", "recommended_models"]
        ws.append(cols)
        for c in range(1, len(cols) + 1):
            ws.cell(row=1, column=c).font = bold
        for s in segs:
            ws.append([s.get("segment_id"), s.get("sbc_quadrant"), s.get("abc"), s.get("trend"),
                       s.get("forecast_unit"), s.get("horizon"),
                       ",".join(s.get("recommended_models", []) or [])])
    else:
        ws.append(["(segments 未確定)"])

    # 5) Features
    ws = wb.create_sheet("Features")
    fp = _load_json("feature_plan.json") or (state or {}).get("feature_plan") or {}
    if fp:
        ws.append(["feature_plan"]); ws["A1"].font = bold
        ws.append([json.dumps(fp, ensure_ascii=False, indent=2)])
    else:
        ws.append(["(feature_plan.json 未生成)"])

    # 6) Model comparison
    ws = wb.create_sheet("ModelComparison")
    ws.append(["model", "MAPE", "RMSE", "asymmetric_cost", "interval_coverage", "note"])
    for c in range(1, 7):
        ws.cell(row=1, column=c).font = bold
    base_m = (state or {}).get("baseline_metrics") or {}
    best = (state or {}).get("best_model") or {}
    if base_m:
        ws.append(["baseline", base_m.get("MAPE"), base_m.get("RMSE"),
                   base_m.get("asymmetric_cost"), base_m.get("interval_coverage"), "StatsForecast"])
    if best:
        ws.append([best.get("name", "advanced"), best.get("MAPE"), best.get("RMSE"),
                   best.get("asymmetric_cost"), best.get("interval_coverage"), best.get("note", "")])
    if not base_m and not best:
        ws.append(["(モデル指標 未生成)", "", "", "", "", ""])

    # 7) Error / bias + decision
    ws = wb.create_sheet("ErrorBias")
    ws.append(["項目", "値"]); ws["A1"].font = bold; ws["B1"].font = bold
    ep = (state or {}).get("error_profile") or {}
    for k, v in ep.items():
        ws.append([str(k), json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v])
    dec = _load_json("decision.json") or (state or {}).get("decision") or {}
    if dec:
        ws.append(["--- decision ---", ""])
        for k, v in dec.items():
            ws.append([str(k), json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v])

    # 8) Forecast / diagnosis (peek at latest backtest)
    ws = wb.create_sheet("Forecast")
    bt = sorted(glob.glob("backtest_*.csv"))
    if bt:
        ws.append([f"latest backtest: {os.path.basename(bt[-1])}"]); ws["A1"].font = bold
        try:
            import csv
            with open(bt[-1], encoding="utf-8") as f:
                for i, line in enumerate(csv.reader(f)):
                    ws.append(line)
                    if i > 200:
                        ws.append(["... (truncated)"]); break
        except Exception as e:
            ws.append([f"(read error: {e})"])
    else:
        ws.append(["(backtest_*.csv 未生成)"])

    # 9) Assumptions / rationale
    ws = wb.create_sheet("Assumptions")
    ws.append(["前提・選定根拠"]); ws["A1"].font = bold
    ws.append(["プロジェクト", cfg.get("project_name")])
    ws.append(["用途駆動", "出力・評価・分岐は use_case から派生"])
    ws.append(["閾値方針", "ADI/CV²/ABC は起点。分布提示→ユーザー比較で確定"])
    ws.append(["リーク防止", "rolling は shift(1)、horizon 未満ラグ除外、train fold のみ fit"])
    ws.append(["評価", "ベースライン先行・Walk-Forward・非対称コスト・業務KPI翻訳"])
    ws.append(["random_seed", cfg.get("random_seed", 42)])

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    wb.save(out_path)
    print(f"wrote {out_path} ({len(wb.sheetnames)} sheets: {', '.join(wb.sheetnames)})")


def main():
    ap = argparse.ArgumentParser(description="demand-insight Excel report")
    ap.add_argument("input", help="input.json path")
    ap.add_argument("--state", default="state.json")
    ap.add_argument("--out", default=os.path.join("reports", "demand_insight_report.xlsx"))
    args = ap.parse_args()
    cfg = _load_json(args.input) or {}
    state = _load_json(args.state)
    build(cfg, state, args.out)


if __name__ == "__main__":
    main()
