"""demand-insight — data-leakage verification on a built features table (functional).

Checks (CRITICAL per rules/demand-forecast.md):
  1. No future-shift columns (lead_*, *shift_-*).
  2. All lag_k columns satisfy k >= horizon (feature_plan.horizon).
  3. rolling/std columns are first-NaN (i.e. shift(1) applied — cannot be computed from row 0).
  4. feature_plan declares the leakage rules.
Exit code 0 = all pass; 1 = CRITICAL violation (caller should stop).

Usage:
    python leakage_check.py input.json [--features features_train.parquet] [--plan feature_plan.json]
"""
from __future__ import annotations

import os
import sys
import re
import json
import argparse

import pandas as pd


def _read_table(path):
    if path.endswith(".parquet") and os.path.exists(path):
        try:
            return pd.read_parquet(path)
        except Exception:
            pass
    csv = os.path.splitext(path)[0] + ".csv"
    if os.path.exists(csv):
        return pd.read_csv(csv)
    if os.path.exists(path):
        return pd.read_csv(path)
    return None


def run(features_path, plan_path):
    checks = []
    plan = json.load(open(plan_path, encoding="utf-8")) if os.path.exists(plan_path) else {}
    horizon = int(plan.get("horizon", 1))
    df = _read_table(features_path)

    # 4. plan declares rules
    checks.append(("feature_plan declares leakage rules", "leakage_rules" in plan, "CRITICAL"))

    if df is None:
        checks.append(("features table present", False, "CRITICAL"))
        return _report(checks)

    cols = list(df.columns)
    # 1. no future columns
    future = [c for c in cols if c.startswith("lead_") or re.search(r"shift_-\d+", c)]
    checks.append((f"no future-shift columns {future or ''}", not future, "CRITICAL"))

    # 2. lags >= horizon
    bad_lags = [c for c in cols if re.match(r"^lag_\d+$", c) and int(c.split("_")[1]) < horizon]
    checks.append((f"all lags >= horizon({horizon}) {bad_lags or ''}", not bad_lags, "CRITICAL"))

    # 3. rolling columns must have leading NaN (shift(1) applied)
    roll = [c for c in cols if c.startswith("roll_mean_") or c.startswith("roll_std_")]
    bad_roll = []
    for c in roll:
        # the very first observation cannot have a past-only rolling value
        if df[c].notna().iloc[0]:
            bad_roll.append(c)
    checks.append((f"rolling cols start with NaN (shift(1)) {bad_roll or ''}", not bad_roll, "CRITICAL"))

    return _report(checks)


def _report(checks):
    print("# Leakage check")
    crit = 0
    for name, ok, sev in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] ({sev}) {name}")
        if not ok and sev == "CRITICAL":
            crit += 1
    print(f"RESULT: {'ALL PASS' if crit == 0 else f'{crit} CRITICAL violation(s)'}")
    return crit


def main():
    ap = argparse.ArgumentParser(description="demand-insight leakage check")
    ap.add_argument("input", nargs="?")
    ap.add_argument("--features", default="features_train.parquet")
    ap.add_argument("--plan", default="feature_plan.json")
    a = ap.parse_args()
    crit = run(a.features, a.plan)
    sys.exit(1 if crit else 0)


if __name__ == "__main__":
    main()
