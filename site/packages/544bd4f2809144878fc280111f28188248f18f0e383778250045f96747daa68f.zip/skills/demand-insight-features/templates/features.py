"""demand-insight Step 4 — leakage-safe feature engineering (functional).

Calendar + cyclical + lag + rolling (shift(1)!) + exogenous features, with the
horizon-availability constraint (Direct: lags < h are future info → dropped).
Writes feature_plan.json and a features table (parquet if pyarrow, else csv).

Usage:
    python features.py input.json [--out-features features_train.parquet]
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import pandas as pd

QUAD_LAGS = {"Smooth": [1, 7], "Erratic": [1, 7, 14, 28],
             "Intermittent": [7, 14, 28], "Lumpy": [7, 28]}


def add_calendar(df, date_col):
    d = df[date_col].dt
    df["month"] = d.month
    df["dayofweek"] = d.dayofweek
    df["is_weekend"] = (d.dayofweek >= 5).astype(int)
    df["day"] = d.day
    df["month_sin"] = np.sin(df["month"] * (2 * np.pi / 12))
    df["month_cos"] = np.cos(df["month"] * (2 * np.pi / 12))
    df["dow_sin"] = np.sin(df["dayofweek"] * (2 * np.pi / 7))
    df["dow_cos"] = np.cos(df["dayofweek"] * (2 * np.pi / 7))
    return df, ["month", "dayofweek", "is_weekend", "day",
                "month_sin", "month_cos", "dow_sin", "dow_cos"]


def add_lags(df, tgt, group_cols, lags, horizon):
    valid = sorted({k for k in lags if k >= horizon})  # drop lags < h (future info)
    cols = []
    g = df.groupby(group_cols)[tgt] if group_cols else None
    for k in valid:
        col = f"lag_{k}"
        df[col] = (g.shift(k) if group_cols else df[tgt].shift(k))
        cols.append(col)
    return df, cols, valid


def add_rolling(df, tgt, group_cols, windows):
    cols = []
    base = (df.groupby(group_cols)[tgt].shift(1) if group_cols else df[tgt].shift(1))  # shift(1) FIRST
    for w in windows:
        m, s = f"roll_mean_{w}", f"roll_std_{w}"
        if group_cols:
            gb = base.groupby([df[c] for c in group_cols])
            df[m] = gb.rolling(w).mean().reset_index(level=list(range(len(group_cols))), drop=True)
            df[s] = gb.rolling(w).std().reset_index(level=list(range(len(group_cols))), drop=True)
        else:
            df[m] = base.rolling(w).mean()
            df[s] = base.rolling(w).std()
        cols += [m, s]
    return df, cols


def dominant_quadrant():
    try:
        segs = json.load(open("segments_rule.json", encoding="utf-8"))
        from collections import Counter
        c = Counter(s.get("sbc_quadrant", "Smooth") for s in segs)
        return c.most_common(1)[0][0]
    except Exception:
        return "Smooth"


def main():
    ap = argparse.ArgumentParser(description="demand-insight features")
    ap.add_argument("input", nargs="?")
    ap.add_argument("--data"); ap.add_argument("--date-col"); ap.add_argument("--target-col")
    ap.add_argument("--id-cols", default=""); ap.add_argument("--horizon", type=int, default=7)
    ap.add_argument("--out-features", default="features_train.parquet")
    a = ap.parse_args()

    exog_cols = []
    if a.input:
        cfg = json.load(open(a.input, encoding="utf-8"))
        ds = cfg["data_source"]
        data, date_col, tgt = ds["path"], ds["time_column"], ds["target_column"]
        group_cols = ds.get("id_columns") or []
        exog_cols = ds.get("exog_columns") or []
        horizon = int(cfg.get("horizon", 7))
    else:
        data, date_col, tgt = a.data, a.date_col, a.target_col
        group_cols = [c for c in a.id_cols.split(",") if c]
        horizon = a.horizon

    df = pd.read_csv(data, parse_dates=[date_col])
    df = df.sort_values((group_cols or []) + [date_col]).reset_index(drop=True)
    df[tgt] = df.groupby(group_cols)[tgt].transform(lambda s: s.interpolate().ffill()) if group_cols \
        else df[tgt].interpolate().ffill()
    df[tgt] = df[tgt].fillna(0)

    q = dominant_quadrant()
    lags = QUAD_LAGS.get(q, [1, 7])
    windows = [7, 28]

    df, cal_cols = add_calendar(df, date_col)
    df, lag_cols, valid_lags = add_lags(df, tgt, group_cols, lags, horizon)
    df, roll_cols = add_rolling(df, tgt, group_cols, windows)

    feat_cols = cal_cols + lag_cols + roll_cols + [c for c in exog_cols if c in df.columns]
    plan = {
        "dominant_quadrant": q,
        "horizon": horizon,
        "lags": valid_lags,
        "lags_requested": lags,
        "lags_dropped_below_horizon": sorted([k for k in lags if k < horizon]),
        "windows": windows,
        "calendar": cal_cols,
        "exogenous": [c for c in exog_cols if c in df.columns],
        "selected_features": feat_cols,
        "leakage_rules": "rolling uses shift(1); lags>=horizon; no shift(-k); fit on train only",
    }
    json.dump(plan, open("feature_plan.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    keep = [date_col] + (group_cols or []) + [tgt] + feat_cols
    out_df = df[keep]
    out = a.out_features
    try:
        out_df.to_parquet(out, index=False)
    except Exception:
        out = os.path.splitext(out)[0] + ".csv"
        out_df.to_csv(out, index=False)

    try:
        state = json.load(open("state.json", encoding="utf-8")) if os.path.exists("state.json") else {"iteration": 0}
        state["feature_plan"] = plan
        state["step"] = "modeling"
        json.dump(state, open("state.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except Exception:
        pass

    print(f"feature_plan.json: quadrant={q} lags={valid_lags} (dropped {plan['lags_dropped_below_horizon']}) "
          f"windows={windows}")
    print(f"wrote {out} ({len(out_df)} rows, {len(feat_cols)} features)")


if __name__ == "__main__":
    main()
