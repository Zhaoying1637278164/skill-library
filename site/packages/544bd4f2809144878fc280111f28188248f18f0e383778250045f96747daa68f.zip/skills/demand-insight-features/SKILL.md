---
name: demand-insight-features
description: Use this skill for Step 4 of demand-insight — building forecast features with strict data-leakage prevention. Generates calendar, cyclical (sin/cos), holiday (incl. pre/post), lag, rolling, and exogenous features, enforcing shift(1) on all target-derived features and the horizon-availability constraint (lags < h are future information for Direct forecasting). Outputs feature_plan.json and a Walk-Forward-safe features table. Use after classification, or when error analysis calls for new explanatory power.
---

# demand-insight-features (Step 4: 特徴量設計)

業務知識を候補プールにしつつ、**どの特徴量が効くかは分析で選定**（要件 §7）。データリーク防止が最優先。

## CRITICAL — リーク防止（要件 §6 / §1.1）
- ローリング統計は必ず `target.shift(1).rolling(N)`（`shift(1)` 抜きは即停止）。EWMA も `shift(1)` 後。
- ラグは `target.shift(k)`、`k>0`。**Direct 方式で horizon h のとき使えるラグは `k >= h`**（lag1..h-1 は未来情報）。
- `shift(-k)`（未来参照）は target で禁止。スケーリング/特徴量選択は train fold のみ。
- **例外（shift(1)不要）**: 確定済み外生変数（祝日カレンダー・価格表）、STL 残差（in-sample 過去のみ）。

## 生成する特徴量
- カレンダー: year/month/day/dayofweek/`is_weekend`(dow∈{5,6})、月内位置
- 祝日: 祝日 + 前後ウィンドウ（連休初日/最終日）。国は `exogenous.holidays_country`
- 周期: cyclical `sin/cos`（month=12, dow=7, etc.）
- ラグ/ローリング: 象限別の推奨ラグ集合（Smooth=[1,7]/Erratic=[1,7,14,28]/Intermittent=[7,14,28]/Lumpy=限定）。h 制約で自動フィルタ
- 外生: 気象（予報範囲内のみ）・プロモ（計画確定分のみ）。`exogenous` に実在するもののみ採用

## Run
```bash
python templates/features.py input.json
# or with horizon: python templates/features.py --data data/sales.csv --date-col date --target-col qty --id-cols store_id,sku_id --horizon 7
# リーク自己検証（5項目）:
python templates/leakage_check.py input.json
```
Out: `feature_plan.json`（採用特徴量とラグ/窓・採否根拠）、`features_train.parquet`。`leakage_check.py` は PreToolUse フックと同ロジック。

## Hand-off
`feature_plan.json` / `features_train.parquet` を `demand-insight-modeling` に渡す。

## Anti-patterns
- `rolling` を `shift(1)` 無しで使う / horizon 未満ラグを残す / 仮説なしに特徴量を大量追加（要件 §7.1: 重要度で選定）。
