---
name: demand-insight
description: Use this skill to start or coordinate a use-case-driven demand-forecasting & data-analysis project — running the 8-step iterative loop (hearing → EDA → classification → segment spec → features → modeling → error analysis → report). It conducts the H1–H8 runtime hearing, detects the data pattern (P1/P2/P3) from column structure, initializes input.json/state.json, routes to the stage skills, applies acceptance criteria, and decides the next action. Use when the user says "start demand forecasting", "improve forecast accuracy", "run the whole loop", or invokes /demand-insight.
---

# demand-insight (entry / orchestration)

需要予測・データ分析プロジェクトの**入口とループ制御**。`要件定義.md` の用途駆動 8 ステップを回し、各ステップで
ユーザーの意思決定を支援する。単発ステージは各 `demand-insight-*` スキルを直接呼んでもよい。

## CRITICAL policies (see `../../rules/demand-forecast.md`)
- データリーク防止（`shift(1)` 必須、horizon h 未満ラグ禁止）／ベースライン先行／Walk-Forward 厳守
- 閾値は固定せず**分布提示→ユーザー決定**（透明性・再現性）／業務KPI翻訳／欠品≠過剰の非対称コスト

## Step 0 — Hearing (H1–H8)  ※毎回ここから
対話で以下を確定し `input.json.hearing` と関連フィールドへ記録（`schemas/input.schema.json` 準拠）。
| | 確認 | input.json への反映 |
|---|---|---|
| H1 | 用途（予測①②③/診断A〜E） | `use_case` |
| H2 | データパターン P1/P2/P3 | `data_pattern`（列構成から提案） |
| H3 | ホライズン・頻度 | `horizon`, `frequency` |
| H4 | リードタイム | `lead_time`（無ければ一律値/手入力） |
| H5 | 外部データ有無・仕様 | `exogenous`（無ければ不採用） |
| H6 | 充足基準（SL・コスト比） | `business_kpi`（具体値は分布を見て後で） |
| H7 | 分類アプローチ | `classification_approach` |
| H8 | 出力体裁 | `output.report_format`（既定 xlsx） |

データパターン判定: 列の一意キーを調べ、`日付`のみ=P1 / `日付×商品`=P2 / `店舗×商品×日付`=P3 を**提案**し齟齬は指摘。

## Steps 1–8 → stage skills
| Step | Skill |
|---|---|
| 1 EDA/前処理 | `demand-insight-eda` |
| 2 系列分類（核心） | `demand-insight-classification` |
| 3 セグメント別仕様/ホライズン | `demand-insight-classification`（後半） |
| 4 特徴量 | `demand-insight-features` |
| 5 モデリング | `demand-insight-modeling` |
| 6 誤差分析 | `demand-insight-evaluation` |
| 7 高度手法（難系列のみ） | `demand-insight-modeling`（--advanced） |
| 8 レポート（Excel） | `demand-insight-evaluation`（report） |
| 本番化 | `demand-insight-productionize` |

## Loop control / gates
- 反復ごとに `demand-insight-evaluation` が `decision.json` を出力。`next_action` に従い Step4〜6 を回す。
- **G1（モデル系統切替）/ G2（因果仮説の根本変更）はユーザー承認必須**。詳細 `references/loop-control.md`。
- 受け入れ基準（`input.acceptance`）達成で `step=done` → 必要なら `demand-insight-productionize`。
- 大規模ループは `demand-insight-orchestrator` エージェントに委譲可。状態は `state.json`（`schemas/state.schema.json`）。

## init（最小実行）
```bash
# 1) input.json を作る（hearing 結果を反映）  2) state.json を初期化
python - <<'PY'
import json
json.dump({"step":"hearing","iteration":0,"history":[]}, open("state.json","w"), indent=2)
PY
```

## Output / report
最終出力は **Excel（.xlsx）機能優先**（要件 §12）。`demand-insight-evaluation` の `excel_report.py` が
ヒアリング結果・データ品質・分類・採用特徴量・手法比較・誤差/バイアス・最終予測・前提/根拠をまとめる。

## Anti-patterns
- Step0 ヒアリングを飛ばして分析を始める（用途未確定は出力設計が崩れる）。
- 閾値（ADI 1.32 / CV² 0.49）を絶対視（→ 分布提示し比較で決める）。
- ベースライン未測定で高度モデルを採用。
