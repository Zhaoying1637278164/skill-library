# Loop Control & Gate Decision Logic

`demand-insight` メタスキル（と `demand-insight-orchestrator` エージェント）のループ制御・G1/G2 ゲート判定の
詳細条件。SKILL.md の "Loop control / gates" から参照される補助ドキュメント。

## next_action 判定フロー

`demand-insight-evaluation` が出力する `decision.json.next_action`（`schemas/decision.schema.json`）を
次の順序で評価する：

```
1. status == "error"            → 即停止（CRITICAL 違反）
2. next_action == "abort"       → ループ終了（最終レポート）
3. next_action == "accept"      → 受け入れ基準確認 → 達成ならループ終了
4. next_action == "model_family_switch"          → G1 ゲート発動
5. next_action == "causal_hypothesis_overhaul"   → G2 ゲート発動
6. next_action == "segment_revision"             → Step2（classification）へ
7. next_action == "feature_refinement"           → Step4（features）へ（自動継続）
```

## 受け入れ基準（acceptance）

`input.json.acceptance` で定義。primary と（あれば）secondary の**両方**を満たした時のみ `accept`：

```json
{
  "primary_metric": "MAPE",
  "min_improvement_vs_baseline": 0.05,
  "min_test_coverage": 0.80,
  "max_iterations": 5
}
```

- baseline 比 5% 以上改善（§1.2 採用判定）→ accept 候補
- `max_iterations` 到達 → abort（暫定ベスト採用）
- advanced ≥ baseline → 採用禁止（G1 切替 or baseline 採用 or abort）

## G1: モデル系統切替ゲート

### 発動条件（いずれか）
- `decision.json.next_action == "model_family_switch"`
- `demand-insight-evaluation` が systematic_bias を3イテレーション連続で検出
- ADI×CV² 再判定で象限が変化（例：Erratic → Lumpy）／advanced ≥ baseline

### 動作
1. ループを停止
2. 現状・推奨切替先・代替案（期待利得/コスト）を提示
   - 切替先候補は統計系（Croston/SBA/TSB…）／GBDT（LightGBM）／**ニューラル**（`mlp`/`nbeats`/`nhits`/`deepar`）／**基盤モデル**（`foundation`）。`models.py` の PRIORITY と各ライブラリ導入状況を踏まえて提示。
3. `state.json.gate_status.G1 = "pending"` を設定
4. ユーザー承認待ち（自動進行しない）
5. 承認 → 新 family で `demand-insight-modeling` を再起動（`input.json` の `models.backends` か `--model` で系統指定）／却下 → 現 family 継続 or baseline 採用

## G2: 因果仮説の根本変更ゲート

### 発動条件
- 業務仮説が3サイクル連続で不支持（`hypotheses[].consecutive_unsupported >= 3`）
- 既存仮説では説明不能な構造変化を検出

### 動作
1. ループを停止
2. 現行仮説・新仮説体系・論拠を提示
3. `state.json.gate_status.G2 = "pending"` を設定
4. ユーザー承認待ち
5. 承認 → 新仮説に基づき `demand-insight-features` が特徴量を再設計／却下 → 現仮説維持

## イテレーション制御
- `acceptance.max_iterations`（既定 5）でループ上限
- 各イテレーション境界で `state.history` に `{iteration, step, metrics, next_action}` を追記
- 改善が `min_improvement_vs_baseline` 未満が3連続 → G1 ゲート発動候補
