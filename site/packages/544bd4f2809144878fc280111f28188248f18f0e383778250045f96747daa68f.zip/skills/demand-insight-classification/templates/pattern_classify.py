"""demand-insight Steps 2-3 — series classification & per-segment spec (functional).

Per series: ADI, CV², SBC quadrant (Smooth/Erratic/Intermittent/Lumpy), ABC volume
class (Pareto), trend sign, recommended model family, and a per-segment forecast
unit + horizon (lead-time aware). Optional ML clustering (k-means via sklearn) for
comparison. Thresholds are starting points — see SKILL.md (decide by comparison).

Usage:
    python pattern_classify.py input.json [--output segments_rule.json]
    python pattern_classify.py --data data.csv --date-col date --target-col qty --id-cols store_id,sku_id
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import pandas as pd

ADI_THR = 1.32
CV2_THR = 0.49
NEURAL_MIN_OBS = 180  # min history before neural nets are auto-suggested (override: input.json models.neural_min_obs)


def adi_cv2(demand: pd.Series):
    d = demand.fillna(0)
    nz = d[d > 0]
    if len(nz) == 0:
        return float("inf"), 0.0
    adi = len(d) / len(nz)
    cv2 = (nz.std() / nz.mean()) ** 2 if nz.mean() > 0 else 0.0
    return float(adi), float(cv2)


def quadrant(adi, cv2):
    if adi < ADI_THR and cv2 < CV2_THR:
        return "Smooth"
    if adi < ADI_THR and cv2 >= CV2_THR:
        return "Erratic"
    if adi >= ADI_THR and cv2 < CV2_THR:
        return "Intermittent"
    return "Lumpy"


def trend_sign(series: pd.Series):
    y = series.fillna(0).to_numpy(dtype=float)
    if len(y) < 4:
        return "flat"
    x = np.arange(len(y))
    slope = np.polyfit(x, y, 1)[0]
    rng = (y.max() - y.min()) or 1.0
    norm = slope * len(y) / rng
    return "up" if norm > 0.1 else ("down" if norm < -0.1 else "flat")


def recommend(q, has_exog, n_obs, enable_neural=True, neural_min_obs=NEURAL_MIN_OBS):
    """Recommend a model family per quadrant (starting point — decide by comparison).

    Neural nets are appended (not prepended) only for non-intermittent quadrants with
    enough history, so baselines/LightGBM stay first and the 3-stage adoption rule in
    modeling remains the gate. Intermittent stays purely statistical (neural禁忌);
    Lumpy may use a probabilistic DeepAR. Cold start prefers zero-shot foundation
    models. See rules/demand-forecast.md §4.1 / §4.2.
    """
    if n_obs < 28:
        # cold start: zero-shot foundation models / Bass diffusion
        rec = ["cold_start"]
        if enable_neural:
            rec.append("foundation(chronos/timegpt/timesfm)")
        rec.append("bass")
        return rec
    base = {
        "Smooth": (["lightgbm", "ets", "arima"] if has_exog else ["ets", "arima"]),
        "Erratic": (["lightgbm_exog", "sba"] if has_exog else ["sba", "lightgbm"]),
        "Intermittent": ["croston", "tsb", "sba"],
        "Lumpy": ["sba", "tsb", "probabilistic"],
    }[q]
    if enable_neural and n_obs >= neural_min_obs:
        if q == "Smooth":
            base = base + ["mlp", "nbeats"]
        elif q == "Erratic":
            base = base + ["mlp", "nhits"]
        elif q == "Lumpy":
            base = base + ["deepar"]  # probabilistic only; no point-forecast NN on intermittent demand
    return base


def forecast_unit(q, lead_time):
    if q in ("Intermittent", "Lumpy"):
        return "lead_time_cumulative"
    return "lead_time_cumulative" if (isinstance(lead_time, int) and lead_time > 7) else "daily_point"


def abc_classes(totals: dict):
    items = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
    grand = sum(v for _, v in items) or 1.0
    out, cum = {}, 0.0
    for k, v in items:
        cum += v
        share = cum / grand
        out[k] = "A" if share <= 0.7 else ("B" if share <= 0.9 else "C")
    return out


def classify(df, date_col, tgt, group_cols, has_exog, lead_time, horizon,
             enable_neural=True, neural_min_obs=NEURAL_MIN_OBS):
    rows = {}
    totals = {}
    if group_cols:
        for key, g in df.groupby(group_cols):
            sid = key if isinstance(key, str) else "-".join(map(str, key if isinstance(key, tuple) else [key]))
            s = g.sort_values(date_col)[tgt]
            adi, cv2 = adi_cv2(s)
            q = quadrant(adi, cv2)
            rows[sid] = {"segment_id": sid, "adi": round(adi, 3), "cv2": round(cv2, 3),
                         "sbc_quadrant": q, "trend": trend_sign(s), "n_obs": int(len(s)),
                         "recommended_models": recommend(q, has_exog, len(s), enable_neural, neural_min_obs),
                         "forecast_unit": forecast_unit(q, lead_time), "horizon": horizon}
            totals[sid] = float(s.fillna(0).sum())
    else:
        s = df.sort_values(date_col)[tgt]
        adi, cv2 = adi_cv2(s)
        q = quadrant(adi, cv2)
        rows["all"] = {"segment_id": "all", "adi": round(adi, 3), "cv2": round(cv2, 3),
                       "sbc_quadrant": q, "trend": trend_sign(s), "n_obs": int(len(s)),
                       "recommended_models": recommend(q, has_exog, len(s), enable_neural, neural_min_obs),
                       "forecast_unit": forecast_unit(q, lead_time), "horizon": horizon}
        totals["all"] = float(s.fillna(0).sum())
    abc = abc_classes(totals)
    for sid, r in rows.items():
        r["abc"] = abc.get(sid, "C")
    return list(rows.values())


def maybe_cluster(rows):
    """Optional ML clustering on (adi, cv2, trend, volume) for comparison vs rule-based."""
    try:
        from sklearn.cluster import KMeans
        from sklearn.preprocessing import StandardScaler
    except Exception:
        return None
    if len(rows) < 4:
        return None
    tmap = {"down": -1, "flat": 0, "up": 1}
    X = np.array([[r["adi"] if np.isfinite(r["adi"]) else 5.0, r["cv2"],
                   tmap[r["trend"]], np.log1p(r["n_obs"])] for r in rows])
    Xs = StandardScaler().fit_transform(X)
    best_k, best_s, best_labels = 2, -1, None
    try:
        from sklearn.metrics import silhouette_score
        for k in range(2, min(6, len(rows))):
            km = KMeans(n_clusters=k, random_state=42, n_init=10).fit(Xs)
            if len(set(km.labels_)) < 2:
                continue
            sc = silhouette_score(Xs, km.labels_)
            if sc > best_s:
                best_k, best_s, best_labels = k, sc, km.labels_
    except Exception:
        km = KMeans(n_clusters=2, random_state=42, n_init=10).fit(Xs)
        best_labels = km.labels_
    return {"k": int(best_k), "silhouette": round(float(best_s), 3),
            "labels": {rows[i]["segment_id"]: int(best_labels[i]) for i in range(len(rows))}}


def main():
    ap = argparse.ArgumentParser(description="demand-insight classification")
    ap.add_argument("input", nargs="?")
    ap.add_argument("--data"); ap.add_argument("--date-col"); ap.add_argument("--target-col")
    ap.add_argument("--id-cols", default="")
    ap.add_argument("--output", default="segments_rule.json")
    a = ap.parse_args()

    has_exog, lead_time, horizon = False, 0, 7
    enable_neural, neural_min_obs = True, NEURAL_MIN_OBS
    if a.input:
        cfg = json.load(open(a.input, encoding="utf-8"))
        ds = cfg["data_source"]
        data, date_col, tgt = ds["path"], ds["time_column"], ds["target_column"]
        group_cols = ds.get("id_columns") or []
        has_exog = bool(ds.get("exog_columns")) or bool(cfg.get("exogenous"))
        lt = cfg.get("lead_time", 0)
        lead_time = lt if isinstance(lt, int) else (lt or {}).get("default", 0)
        horizon = int(cfg.get("horizon", 7))
        approach = cfg.get("classification_approach", "both")
        mcfg = cfg.get("models") or {}
        enable_neural = mcfg.get("enable_neural", True)
        neural_min_obs = int(mcfg.get("neural_min_obs", NEURAL_MIN_OBS))
    else:
        data, date_col, tgt = a.data, a.date_col, a.target_col
        group_cols = [c for c in a.id_cols.split(",") if c]
        approach = "both"

    df = pd.read_csv(data, parse_dates=[date_col])
    rows = classify(df, date_col, tgt, group_cols, has_exog, lead_time, horizon,
                    enable_neural, neural_min_obs)
    result = {"thresholds": {"ADI": ADI_THR, "CV2": CV2_THR,
                             "note": "starting points — confirm by comparing distributions"},
              "segments": rows}
    if approach in ("ml_clustering", "both"):
        cl = maybe_cluster(rows)
        result["ml_clustering"] = cl or "(sklearn 不在 or 系列<4 → スキップ)"

    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False, default=str)
    with open("classification_report.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False, default=str)

    # merge into state
    try:
        state = json.load(open("state.json", encoding="utf-8")) if os.path.exists("state.json") else {"iteration": 0}
        state["segments"] = rows
        state["step"] = "features"
        json.dump(state, open("state.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except Exception:
        pass

    dist = {}
    for r in rows:
        dist[r["sbc_quadrant"]] = dist.get(r["sbc_quadrant"], 0) + 1
    print(f"classified {len(rows)} series -> {a.output}")
    print("SBC distribution:", dist)
    if isinstance(result.get("ml_clustering"), dict):
        print("ML clusters:", result["ml_clustering"]["k"], "silhouette", result["ml_clustering"]["silhouette"])


if __name__ == "__main__":
    main()
