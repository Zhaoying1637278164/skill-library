---
name: demand-insight-classification
description: Use this skill for Steps 2–3 of demand-insight — the core series classification and per-segment spec. Computes the 4 axes (volume/ADI/CV²/trend), assigns SBC quadrants (Smooth/Erratic/Intermittent/Lumpy), builds hierarchical segments (~8–12), optionally runs ML clustering (k-means / shape / PCA) and compares it against the rule-based result, then proposes a per-segment forecast unit & horizon (lead-time aware). Thresholds are presented as starting points; the user decides. Use after EDA, or to re-classify on pattern change / new stores.
---

# demand-insight-classification (Step 2+3: 分類 — 核心)

需要特性で系列を分類し、セグメントごとに最適手法・予測単位・ホライズンを割り当てる土台を作る。
**一律手法を避ける**ための中核ステップ（要件 §5）。

## CRITICAL
- 閾値（ADI 1.32 / CV² 0.49、ABC のパレート切り）は**起点**。分布（ヒストグラム/散布図）を提示し、
  **切る位置はユーザーが比較して決定**（要件 §5.5、固定値で当てない）。
- ML クラスタリングは**解釈性担保**：各クラスタを統計量（平均出数・ADI・CV²・トレンド）で必ず説明。
- 系統逆転禁止：Intermittent/Lumpy に LightGBM を素当てしない（ゼロに引かれ平坦化）。

## 4軸 → SBC → 階層セグメント
- 4軸: ①ボリューム(ABC) ②間欠性(ADI) ③変動性(CV²) ④トレンド(±/0)
- 第1階層 = SBC 4象限（②×③）、第2階層 = 各象限を ①ボリュームで再分割、横断フラグ = ④トレンド（逓減=廃盤予備軍）→ 実 8〜12 セグメント。

## Run
```bash
# ルールベース（ADI×CV² 4象限 + 推奨モデル系統）
python templates/pattern_classify.py input.json --output segments_rule.json
# 列構成からの直接指定も可:
python templates/pattern_classify.py --data data/sales.csv --date-col date --target-col qty --id-cols store_id,sku_id
```
ML クラスタリング（`classification_approach: ml_clustering|both` のとき）: 統計量ベクトル(ADI,CV²,平均,ピーク,傾き)で
k-means/階層/GMM、k はエルボー・シルエットを提示してユーザー判断。ルールベースと**比較レポート**（整合/乖離）。

## Step 3 — セグメント別 予測単位/ホライズン（要件 §6.4）
| セグメント | 予測単位 | ホライズン |
|---|---|---|
| Smooth×短LT | 日次点 | 短い・高SL |
| Smooth×長LT | L期間集計 | L をカバー |
| Intermittent/Lumpy | L期間累積（点予測しない） | 長め・過剰抑制 |
ホライズン h は「リードタイム L + レビュー間隔」をカバー。割り当てルール自体も比較で確定。結果は `state.json.segments`。

## 推奨モデル（recommended_models）— 象限から自動
`recommend()` が象限ごとに候補を出す（modeling のレジストリが利用可能な最優先を採用）。
- Smooth/Erratic で**履歴が十分**（既定 `models.neural_min_obs`=180 以上）なら末尾に**ニューラル**を自動追加（Smooth: `mlp`,`nbeats` / Erratic: `mlp`,`nhits`）。統計系・LightGBM を先頭に維持（baseline-first）。
- Intermittent は統計系のみ（ニューラル禁忌）。Lumpy は確率的 `deepar` を任意追加。
- コールドスタート（n_obs<28）は `foundation(chronos/timegpt/timesfm)` + `bass`。
- `input.json` の `models.enable_neural=false` で無効化、`models.neural_min_obs` で閾値調整。採用可否は modeling の3段階判定が門番。

## Hand-off
セグメント定義を `demand-insight-features` / `demand-insight-modeling` に渡す（系統別にモデルを切替）。

## Anti-patterns
- 閾値を絶対視して比較材料を出さない / ブラックボックスのまま ML クラスタを採用 / 全系列に同一モデル。
