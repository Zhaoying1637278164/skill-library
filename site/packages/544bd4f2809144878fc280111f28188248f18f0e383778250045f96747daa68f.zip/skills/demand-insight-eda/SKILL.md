---
name: demand-insight-eda
description: Use this skill for Step 1 of demand-insight — data understanding, preprocessing, and quality checks. Runs missing-value pattern analysis (time-aware interpolation), outlier detection (3σ residual → is_event flag, not deletion), STL/MSTL decomposition, ACF/PACF, ADF stationarity, and change-point detection. Outputs an EDA report and merges a summary into state.json for downstream classification. Use after the H1–H8 hearing or when data is refreshed.
---

# demand-insight-eda (Step 1: EDA / preprocessing / quality)

生データを多角的に理解し、前処理方針（補間・イベントフラグ化・学習期間）を決める材料を作る。

## CRITICAL
- 異常値は**削除せず** `is_event` フラグ化（要件 §2.2 / §7）。欠損は**時間考慮の補間**（`interpolate('time')`、長期欠損は ffill）。
- ここでは予測しない。Walk-Forward 安全な記述統計のみ。

## Inputs / Outputs
- In: `input.json`（`data_source` ブロック）
- Out: `reports/eda/`（サマリ、図）、`state.json.eda_summary`

## Run
```bash
python templates/eda.py input.json
# or: python templates/eda.py --data data/sales.csv --date-col date --target-col qty --id-cols store_id,sku_id
```
依存: `statsmodels`, `ruptures`（無い場合は該当分析をスキップし警告）。

## What it produces
- 欠損マップ / 欠損率、外れ値（IQR・3σ）→ `is_event` 候補
- STL/MSTL（period は frequency に依存: D→7, M→12。複数周期は MSTL）
- ACF/PACF（主要ラグ → 特徴量設計の手がかり）、ADF（定常性）
- 変化点（`ruptures`）→ 学習期間の起点候補（最新変化点以降）

## Hand-off
EDA サマリを `demand-insight-classification` に渡す。複数系列で構造が割れる場合は分類で系列群を分ける。

## Anti-patterns
- 平均値での欠損補完 / 異常値の無条件削除 / 分解を見ずに季節周期を仮定。
