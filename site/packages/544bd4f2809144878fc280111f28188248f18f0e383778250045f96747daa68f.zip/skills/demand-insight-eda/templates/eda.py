"""demand-insight Step 1 — EDA / preprocessing / data quality (functional).

Reads input.json (data_source block), profiles quality, runs STL (if statsmodels),
ADF (if statsmodels), and change-point detection (if ruptures), and writes
reports/eda/eda_summary.md + eda_summary.json. pandas/numpy only for the core;
optional libraries degrade gracefully.

Usage:
    python eda.py input.json [--out reports/eda]
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import pandas as pd


def load_cfg(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def load_data(cfg):
    ds = cfg["data_source"]
    df = pd.read_csv(ds["path"], parse_dates=[ds["time_column"]])
    return df, ds


def _series_total(df, ds, freq):
    s = (df.groupby(ds["time_column"])[ds["target_column"]].sum()
           .asfreq(freq))
    return s


def _adf(series):
    try:
        from statsmodels.tsa.stattools import adfuller
        s = series.dropna()
        if len(s) < 12:
            return None
        stat, p = adfuller(s)[:2]
        return {"adf_stat": round(float(stat), 4), "p_value": round(float(p), 4),
                "stationary": bool(p < 0.05)}
    except Exception:
        return None


def _stl_period(freq):
    return {"D": 7, "W": 52, "M": 12, "H": 24}.get(freq, 7)


def _changepoints(series):
    try:
        import ruptures as rpt
        sig = series.fillna(0).to_numpy()
        if len(sig) < 21:
            return []
        idx = rpt.Binseg(model="l2", min_size=7).fit(sig).predict(n_bkps=3)[:-1]
        return [str(series.index[i]) for i in idx if 0 <= i < len(series)]
    except Exception:
        return []


def run(cfg, out_dir):
    df, ds = load_data(cfg)
    date_col, tgt = ds["time_column"], ds["target_column"]
    grp = ds.get("id_columns") or []
    freq = cfg.get("frequency", "D")
    n = len(df)
    miss = int(df[tgt].isna().sum())
    q1, q3 = df[tgt].quantile(0.25), df[tgt].quantile(0.75)
    iqr = q3 - q1
    iqr_out = int(((df[tgt] < q1 - 1.5 * iqr) | (df[tgt] > q3 + 1.5 * iqr)).sum())
    n_series = df.groupby(grp).ngroups if grp else 1

    total = _series_total(df, ds, freq)
    adf = _adf(total)
    cps = _changepoints(total)

    summary = {
        "rows": n, "n_series": int(n_series),
        "date_min": str(df[date_col].min()), "date_max": str(df[date_col].max()),
        "missing": miss, "missing_pct": round(100 * miss / n, 2) if n else 0.0,
        "iqr_outliers": iqr_out, "stl_period": _stl_period(freq),
        "adf": adf, "change_points": cps,
        "zero_share": round(float((df[tgt].fillna(0) == 0).mean()), 3),
    }

    os.makedirs(out_dir, exist_ok=True)
    md = [
        f"# EDA Summary — {cfg.get('project_name', 'demand-insight')}",
        "",
        f"- data=`{ds['path']}` target=`{tgt}` freq=`{freq}` use_case=`{cfg.get('use_case')}`",
        f"- range: {summary['date_min']} → {summary['date_max']}  |  series: {n_series}",
        "",
        "## Data quality",
        f"- rows={n}  missing={miss} ({summary['missing_pct']}%)  IQR-outliers={iqr_out}",
        f"- zero share={summary['zero_share']}  (high → intermittent demand likely)",
        "- 補間方針: 短期欠損=interpolate('time') / 長期=ffill。異常値は削除せず is_event 化。",
        "",
        "## Stationarity (ADF)",
        f"- {adf if adf else '(statsmodels 不在 or 系列短)'}",
        "",
        "## Change points (regime shifts)",
        f"- {cps if cps else '(なし or ruptures 不在)'}  → 最新変化点以降を学習対象候補に。",
        "",
        "## Next",
        "- demand-insight-classification で ADI×CV² 分類とセグメント別仕様を決める。",
    ]
    with open(os.path.join(out_dir, "eda_summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    with open(os.path.join(out_dir, "eda_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    # merge into state.json if present
    _merge_state(summary)
    print(f"wrote {out_dir}/eda_summary.md + eda_summary.json")
    print(json.dumps(summary, ensure_ascii=False, indent=2)[:800])
    return summary


def _merge_state(summary, path="state.json"):
    try:
        state = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {"iteration": 0}
    except Exception:
        state = {"iteration": 0}
    state["eda_summary"] = summary
    state["step"] = "classification"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


def main():
    ap = argparse.ArgumentParser(description="demand-insight EDA")
    ap.add_argument("input")
    ap.add_argument("--out", default=os.path.join("reports", "eda"))
    a = ap.parse_args()
    run(load_cfg(a.input), a.out)


if __name__ == "__main__":
    main()
