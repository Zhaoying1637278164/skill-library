# Productionization reference

## Generated project layout
```
project/
├── input.json            # carried from the analysis run
├── feature_plan.json     # adopted features/lags/windows (drives src/features.py)
├── requirements.txt
├── src/
│   ├── preprocessing.py  # interpolate + is_event (pure functions)
│   ├── features.py       # leakage-safe feature builder (shift(1), horizon constraint)
│   ├── train.py          # fit accepted family (LightGBM or ridge fallback), save model + resid scale
│   └── predict.py        # batch inference + bootstrap intervals
├── tests/                # pytest: no-leakage, reproducibility, pipeline smoke
└── deploy/               # schedule.md, monitoring.md
```

## Reproducibility checklist
- `random_seed` fixed in train/predict; outputs identical across runs (test_backtest_repro).
- Persist `models/model_meta.json` (kind, n_features, resid_std, seed).
- Version the data snapshot, feature_plan.json, and code (git SHA) per run.

## Leakage guarantees (enforced + tested)
- Rolling features = `target.shift(1).rolling(N)` — never see the current period.
- Direct forecasting at horizon `h`: lags `< h` are dropped (future information).
- No `target.shift(-k)` features.
- Fitted statistics (scalers, encoders) are saved at train time and reused at inference — never recomputed on the inference window.

## From analysis to production
1. Loop accepts a model (`decision.json.next_action == "accept"`).
2. `scaffold.py input.json --out project` expands templates + injects feature_plan/best_model.
3. `pytest -q project/tests` → all green, coverage ≥ 80%.
4. Wire `deploy/schedule.md` (retrain = refit period, gap = lead time) and `deploy/monitoring.md`.
5. Hand to ops; keep the demand-insight loop available for periodic re-evaluation.

## Coverage target
- ≥ 80% line coverage (`pytest --cov=src`). The bundled tests already cover the leakage-critical paths.
```bash
cd project && python -m pytest -q --cov=src --cov-report=term-missing tests
```
