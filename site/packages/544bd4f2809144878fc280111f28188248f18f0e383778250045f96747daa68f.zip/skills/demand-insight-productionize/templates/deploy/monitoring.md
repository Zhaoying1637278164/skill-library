# Deployment — monitoring (template)

Track these after go-live; alert when they breach thresholds.

## Forecast health
- **Interval coverage**: share of actuals within [lo, hi]. Healthy 0.85–0.95 for a 90% interval.
  Sustained < 0.85 → intervals too tight (underestimating uncertainty).
- **Bias (ME)**: rolling mean error by weekday / segment. Persistent sign → systematic over/under.
- **MAPE / MASE / WMAPE**: vs the accepted baseline. Re-open the loop if it regresses past baseline.

## Business KPIs (translate, don't report raw error)
- Stockouts / month, waste cost / month, ordering hours / day, fill rate.

## Data / model drift
- Input drift: distribution shift in target & key exogenous (PSI / KS).
- Concept drift: rising error after a stable period → trigger retrain or re-classification (G1/G2).
- Change points (ruptures) on residuals → regime shift; consider retraining window.

## Runbook
- Coverage breach → widen intervals (raise n_boot / revisit resid model).
- Baseline regression → halt auto-orders for affected segments, re-run demand-insight loop.
