# Deployment — batch schedule (template)

Fill in to match the business cycle. The retrain cadence should equal the
Walk-Forward `refit` period; the forecast `gap` should equal the order lead time.

## Cadence
- **Retrain**: weekly (e.g. Mon 02:00) — `python src/train.py input.json`
- **Predict**: daily (e.g. 03:00) — `python src/predict.py input.json --out predictions.csv`
- **Horizon**: <h> periods (must cover lead time L + review interval)
- **Lead time (gap)**: <L> periods

## Example (cron)
```
0 2 * * 1  cd /opt/demand-insight && python src/train.py input.json
0 3 * * *  cd /opt/demand-insight && python src/predict.py input.json --out out/$(date +\%F).csv
```

## Reproducibility
- Pin `random_seed`, data snapshot date, and model version (models/model_meta.json).
- Archive each run's input snapshot + predictions for audit.
