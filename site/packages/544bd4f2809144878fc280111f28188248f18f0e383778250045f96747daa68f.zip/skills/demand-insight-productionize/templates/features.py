"""Production feature builder for demand-insight — leakage-safe by construction.

CRITICAL invariants (enforced and unit-tested in tests/test_no_leakage.py):
- Every target-derived rolling feature uses target.shift(1).rolling(N) (strictly past).
- Lag k uses target.shift(k) with k >= horizon for Direct forecasting (lags < h are future info).
- No target.shift(-k) (future) features.
- Calendar / cyclical features are deterministic and known in advance (no shift needed).
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def add_calendar(df: pd.DataFrame, date_col: str) -> pd.DataFrame:
    d = df[date_col].dt
    df["month"] = d.month
    df["dayofweek"] = d.dayofweek
    df["is_weekend"] = (d.dayofweek >= 5).astype(int)
    df["day"] = d.day
    # cyclical encoding
    df["month_sin"] = np.sin(df["month"] * (2 * np.pi / 12))
    df["month_cos"] = np.cos(df["month"] * (2 * np.pi / 12))
    df["dow_sin"] = np.sin(df["dayofweek"] * (2 * np.pi / 7))
    df["dow_cos"] = np.cos(df["dayofweek"] * (2 * np.pi / 7))
    return df


def add_lags(df: pd.DataFrame, target_col: str, group_cols: list[str] | None,
             lags: list[int], horizon: int) -> pd.DataFrame:
    valid = [k for k in lags if k >= horizon]  # Direct: drop lags < horizon (future info)
    grp = df.groupby(group_cols)[target_col] if group_cols else df[target_col]
    for k in valid:
        df[f"lag_{k}"] = grp.shift(k) if group_cols else df[target_col].shift(k)
    return df


def add_rolling(df: pd.DataFrame, target_col: str, group_cols: list[str] | None,
                windows: list[int]) -> pd.DataFrame:
    # shift(1) FIRST, then rolling -> never uses the current period's target
    if group_cols:
        base = df.groupby(group_cols)[target_col].shift(1)
    else:
        base = df[target_col].shift(1)
    for w in windows:
        if group_cols:
            df[f"roll_mean_{w}"] = base.groupby([df[c] for c in group_cols]).rolling(w).mean().reset_index(level=list(range(len(group_cols))), drop=True)
            df[f"roll_std_{w}"] = base.groupby([df[c] for c in group_cols]).rolling(w).std().reset_index(level=list(range(len(group_cols))), drop=True)
        else:
            df[f"roll_mean_{w}"] = base.rolling(w).mean()
            df[f"roll_std_{w}"] = base.rolling(w).std()
    return df


def build_features(df: pd.DataFrame, date_col: str, target_col: str,
                   group_cols: list[str] | None = None,
                   lags: list[int] | None = None,
                   windows: list[int] | None = None,
                   horizon: int = 1) -> pd.DataFrame:
    """Build the leakage-safe feature table. `lags`/`windows` typically come from feature_plan.json."""
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    by = (group_cols or []) + [date_col]
    df = df.sort_values(by).reset_index(drop=True)
    df = add_calendar(df, date_col)
    df = add_lags(df, target_col, group_cols, lags or [horizon, horizon + 6], horizon)
    df = add_rolling(df, target_col, group_cols, windows or [7, 28])
    return df


def feature_columns(df: pd.DataFrame, date_col: str, target_col: str,
                    group_cols: list[str] | None) -> list[str]:
    exclude = set([date_col, target_col] + (group_cols or []))
    return [c for c in df.columns if c not in exclude]
