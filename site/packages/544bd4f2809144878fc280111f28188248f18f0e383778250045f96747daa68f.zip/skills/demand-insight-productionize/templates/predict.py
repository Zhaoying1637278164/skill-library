"""Production batch prediction for demand-insight.

Loads the trained artifact and produces point forecasts plus bootstrapped
prediction intervals (safety-stock basis). Deterministic given the fixed seed.
"""
from __future__ import annotations

import os
import json
import pickle
import argparse

import numpy as np
import pandas as pd

from preprocessing import preprocess
from features import build_features
from train import _predict_raw, _load_feature_plan

SEED = 42


def load_artifact(model_dir="models"):
    with open(os.path.join(model_dir, "model.pkl"), "rb") as f:
        return pickle.load(f)


def predict(cfg: dict, model_dir="models", interval=(5, 95), n_boot=200) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    art = load_artifact(model_dir)
    ds = cfg["data_source"]
    date_col, target_col = ds["time_column"], ds["target_column"]
    group_cols = ds.get("id_columns") or None
    horizon = int(art.get("horizon", cfg.get("horizon", 1)))

    df = pd.read_csv(ds["path"], parse_dates=[date_col])
    df = preprocess(df, date_col, target_col, group_cols)
    fp = _load_feature_plan()
    df = build_features(df, date_col, target_col, group_cols,
                        lags=fp.get("lags"), windows=fp.get("windows"), horizon=horizon)

    feats = art["features"]
    pred_df = df.dropna(subset=feats).copy()
    X = pred_df[feats].to_numpy(dtype=float)
    yhat = _predict_raw(art["kind"], art["model"], X)
    yhat = np.clip(yhat, 0, None)  # demand is non-negative

    # bootstrap residual intervals
    sd = art.get("resid_std", 1.0) or 1.0
    draws = rng.normal(0, sd, size=(n_boot, len(yhat)))
    samples = np.clip(yhat[None, :] + draws, 0, None)
    lo = np.percentile(samples, interval[0], axis=0)
    hi = np.percentile(samples, interval[1], axis=0)

    out = pred_df[[date_col] + (group_cols or [])].copy()
    out["forecast"] = yhat
    out[f"lo_{interval[0]}"] = lo
    out[f"hi_{interval[1]}"] = hi
    return out.reset_index(drop=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--model-dir", default="models")
    ap.add_argument("--out", default="predictions.csv")
    a = ap.parse_args()
    with open(a.input, encoding="utf-8") as f:
        res = predict(json.load(f), a.model_dir)
    res.to_csv(a.out, index=False)
    print(f"wrote {a.out} ({len(res)} rows)")
