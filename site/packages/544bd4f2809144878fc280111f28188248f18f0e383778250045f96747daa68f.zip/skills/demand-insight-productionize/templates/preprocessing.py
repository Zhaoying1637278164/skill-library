"""Production preprocessing for demand-insight.

Time-aware interpolation of the target and 3σ event flagging (no deletion).
Pure functions so they are trivial to unit-test and reuse at inference time.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def sort_frame(df: pd.DataFrame, date_col: str, group_cols: list[str] | None) -> pd.DataFrame:
    by = (group_cols or []) + [date_col]
    return df.sort_values(by).reset_index(drop=True)


def interpolate_target(df: pd.DataFrame, date_col: str, target_col: str,
                       group_cols: list[str] | None) -> pd.DataFrame:
    """Time-aware interpolation within each series; long gaps fall back to ffill then 0."""
    df = df.copy()

    def _interp(g: pd.DataFrame) -> pd.DataFrame:
        s = g.set_index(date_col)[target_col]
        s = s.interpolate(method="time").ffill().fillna(0.0)
        g[target_col] = s.values
        return g

    if group_cols:
        df = df.groupby(group_cols, group_keys=False).apply(_interp)
    else:
        df = _interp(df)
    return df.reset_index(drop=True)


def flag_events(df: pd.DataFrame, target_col: str, group_cols: list[str] | None,
                k: float = 3.0) -> pd.DataFrame:
    """Flag 3σ outliers as is_event (kept, not deleted). σ computed per series, past-agnostic
    here because event flags are descriptive labels, not predictive target-derived features."""
    df = df.copy()

    def _flag(g: pd.DataFrame) -> pd.DataFrame:
        v = g[target_col].astype(float)
        mu, sd = v.mean(), v.std(ddof=0)
        g["is_event"] = ((v - mu).abs() > k * sd).astype(int) if sd > 0 else 0
        return g

    if group_cols:
        df = df.groupby(group_cols, group_keys=False).apply(_flag)
    else:
        df = _flag(df)
    return df.reset_index(drop=True)


def preprocess(df: pd.DataFrame, date_col: str, target_col: str,
               group_cols: list[str] | None = None) -> pd.DataFrame:
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df = sort_frame(df, date_col, group_cols)
    df = interpolate_target(df, date_col, target_col, group_cols)
    df = flag_events(df, target_col, group_cols)
    return df
