"""Production training for demand-insight.

Trains the accepted model family recorded in state.json (best_model.model_name):
  - mlp        torch MLP + dropout (optional: torch)
  - lightgbm   gradient-boosted trees (optional: lightgbm)
  - ridge      numpy-only ridge — ALWAYS available final fallback
Series-native accepted models (neuralforecast/foundation) fall back to lightgbm/ridge
here so the generated project stays self-contained; serve those with their own
library if needed (see deploy/monitoring.md). Each path is graceful: if the desired
library is absent it degrades, so training never breaks. Fixes the random seed and
saves the model plus the in-sample residual scale (for bootstrap intervals).
"""
from __future__ import annotations

import os
import json
import pickle
import argparse

import numpy as np
import pandas as pd

from preprocessing import preprocess
from features import build_features, feature_columns

SEED = 42


def _desired_kind() -> str:
    """The accepted model name recorded by the modeling stage (best_model.model_name)."""
    try:
        st = json.load(open("state.json", encoding="utf-8"))
        return (st.get("best_model") or {}).get("model_name", "") or ""
    except Exception:
        return ""


def _fit_mlp(X: np.ndarray, y: np.ndarray):
    """torch MLP + dropout. Returns ('mlp', artifact-dict) or raises if torch absent."""
    import torch
    import torch.nn as nn
    torch.manual_seed(SEED)
    hidden, dropout, epochs, lr = 64, 0.1, 200, 1e-3
    mu = X.mean(axis=0); sd = X.std(axis=0); sd = np.where(sd == 0, 1.0, sd)
    Xs = (X - mu) / sd
    net = nn.Sequential(
        nn.Linear(Xs.shape[1], hidden), nn.ReLU(), nn.Dropout(dropout),
        nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(dropout),
        nn.Linear(hidden, 1),
    )
    opt = torch.optim.Adam(net.parameters(), lr=lr)
    lossf = nn.MSELoss()
    xt = torch.tensor(Xs, dtype=torch.float32)
    yt = torch.tensor(y.reshape(-1, 1), dtype=torch.float32)
    n = len(xt); bs = min(256, n) or 1
    gen = torch.Generator().manual_seed(SEED)
    net.train()
    for _ in range(epochs):
        perm = torch.randperm(n, generator=gen)
        for i in range(0, n, bs):
            idx = perm[i:i + bs]
            opt.zero_grad()
            lossf(net(xt[idx]), yt[idx]).backward()
            opt.step()
    artifact = {"state_dict": net.state_dict(),
                "arch": {"n_in": int(Xs.shape[1]), "hidden": hidden, "dropout": dropout},
                "mu": mu, "sd": sd}
    return ("mlp", artifact)


def _fit_lightgbm(X: np.ndarray, y: np.ndarray):
    import lightgbm as lgb
    model = lgb.LGBMRegressor(n_estimators=300, learning_rate=0.05,
                              random_state=SEED, n_jobs=-1)
    model.fit(X, y)
    return ("lightgbm", model)


def _fit_ridge(X: np.ndarray, y: np.ndarray):
    Xb = np.column_stack([np.ones(len(X)), X])
    lam = 1.0
    A = Xb.T @ Xb + lam * np.eye(Xb.shape[1])
    coef = np.linalg.solve(A, Xb.T @ y)
    return ("ridge", coef)


def _fit_model(X: np.ndarray, y: np.ndarray, desired: str = ""):
    """Train the desired model with graceful fallback (mlp -> lightgbm -> ridge)."""
    desired = (desired or _desired_kind()).lower()
    if desired == "ridge":
        cascade = [_fit_ridge]
    elif desired == "mlp":
        cascade = [_fit_mlp, _fit_lightgbm, _fit_ridge]
    else:  # lightgbm / series-native / unknown -> tabular surrogate
        cascade = [_fit_lightgbm, _fit_ridge]
    for fit in cascade:
        try:
            return fit(X, y)
        except Exception:
            continue
    return _fit_ridge(X, y)


def train(cfg: dict, out_dir: str = "models") -> dict:
    np.random.seed(SEED)
    ds = cfg["data_source"]
    date_col, target_col = ds["time_column"], ds["target_column"]
    group_cols = ds.get("id_columns") or None
    horizon = int(cfg.get("horizon", 1))

    df = pd.read_csv(ds["path"], parse_dates=[date_col])
    df = preprocess(df, date_col, target_col, group_cols)
    fp = _load_feature_plan()
    df = build_features(df, date_col, target_col, group_cols,
                        lags=fp.get("lags"), windows=fp.get("windows"), horizon=horizon)

    feats = feature_columns(df, date_col, target_col, group_cols)
    train_df = df.dropna(subset=feats + [target_col])
    X = train_df[feats].to_numpy(dtype=float)
    y = train_df[target_col].to_numpy(dtype=float)

    kind, model = _fit_model(X, y)
    resid_std = float(np.std(y - _predict_raw(kind, model, X))) if len(y) else 1.0

    os.makedirs(out_dir, exist_ok=True)
    artifact = {"kind": kind, "model": model, "features": feats,
                "resid_std": resid_std, "seed": SEED, "horizon": horizon}
    with open(os.path.join(out_dir, "model.pkl"), "wb") as f:
        pickle.dump(artifact, f)
    meta = {"kind": kind, "n_features": len(feats), "n_train": int(len(train_df)),
            "resid_std": resid_std, "seed": SEED}
    with open(os.path.join(out_dir, "model_meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(f"trained {kind} on {len(train_df)} rows, {len(feats)} features -> {out_dir}/model.pkl")
    return artifact


def _build_mlp(arch):
    import torch.nn as nn
    return nn.Sequential(
        nn.Linear(arch["n_in"], arch["hidden"]), nn.ReLU(), nn.Dropout(arch["dropout"]),
        nn.Linear(arch["hidden"], arch["hidden"]), nn.ReLU(), nn.Dropout(arch["dropout"]),
        nn.Linear(arch["hidden"], 1),
    )


def _predict_raw(kind, model, X):
    if kind == "lightgbm":
        return model.predict(X)
    if kind == "mlp":
        import torch
        net = _build_mlp(model["arch"])
        net.load_state_dict(model["state_dict"])
        net.eval()
        Xs = (np.asarray(X, float) - model["mu"]) / model["sd"]
        with torch.no_grad():
            return net(torch.tensor(Xs, dtype=torch.float32)).numpy().ravel()
    Xb = np.column_stack([np.ones(len(X)), X])
    return Xb @ model


def _load_feature_plan(path="feature_plan.json") -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out", default="models")
    a = ap.parse_args()
    with open(a.input, encoding="utf-8") as f:
        train(json.load(f), a.out)
