"""CRITICAL: verify features are leakage-safe by construction."""
import numpy as np
import pandas as pd

from features import build_features, add_rolling


def _series(n=40):
    dates = pd.date_range("2024-01-01", periods=n, freq="D")
    return pd.DataFrame({"date": dates, "qty": np.arange(1, n + 1, dtype=float)})


def test_rolling_uses_only_past():
    df = _series()
    out = add_rolling(df.copy(), "qty", None, windows=[7])
    # roll_mean_7 at index i must equal mean of qty[i-7 .. i-1] (strictly past, via shift(1))
    i = 20
    expected = df["qty"].iloc[i - 7:i].mean()
    assert np.isclose(out["roll_mean_7"].iloc[i], expected)
    # and must NOT include the current period
    naive = df["qty"].iloc[i - 6:i + 1].mean()
    assert not np.isclose(out["roll_mean_7"].iloc[i], naive)


def test_first_rows_are_nan_not_filled_from_future():
    df = _series()
    out = add_rolling(df.copy(), "qty", None, windows=[7])
    # shift(1)+rolling(7) → first 7 rows cannot be computed from the past
    assert out["roll_mean_7"].iloc[:7].isna().all()


def test_horizon_drops_short_lags():
    df = _series()
    out = build_features(df.copy(), "date", "qty", None,
                         lags=[1, 3, 7, 14], windows=[7], horizon=7)
    # Direct forecasting at h=7: lags 1 and 3 are future info and must be absent
    assert "lag_1" not in out.columns
    assert "lag_3" not in out.columns
    assert "lag_7" in out.columns and "lag_14" in out.columns


def test_no_future_shift_columns():
    df = _series()
    out = build_features(df.copy(), "date", "qty", None, lags=[1], windows=[7], horizon=1)
    assert not any(c.startswith("lead_") or "shift_-" in c for c in out.columns)
