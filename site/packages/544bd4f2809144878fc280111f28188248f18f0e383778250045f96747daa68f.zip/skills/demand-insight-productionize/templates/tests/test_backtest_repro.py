"""Reproducibility: same seed + same data → identical model and predictions."""
import os
import json
import tempfile

import numpy as np
import pandas as pd

import train as train_mod
import predict as predict_mod


def _make_cfg(tmp):
    n = 120
    dates = pd.date_range("2024-01-01", periods=n, freq="D")
    rng = np.random.default_rng(0)
    qty = 10 + 3 * np.sin(np.arange(n) * 2 * np.pi / 7) + rng.normal(0, 1, n)
    csv = os.path.join(tmp, "s.csv")
    pd.DataFrame({"date": dates, "qty": np.clip(qty, 0, None)}).to_csv(csv, index=False)
    return {"data_source": {"path": csv, "time_column": "date", "target_column": "qty"},
            "horizon": 1, "random_seed": 42}


def test_training_is_reproducible():
    with tempfile.TemporaryDirectory() as tmp:
        cfg = _make_cfg(tmp)
        cwd = os.getcwd()
        os.chdir(tmp)
        try:
            train_mod.train(cfg, out_dir="m1")
            train_mod.train(cfg, out_dir="m2")
            p1 = predict_mod.predict(cfg, model_dir="m1")
            p2 = predict_mod.predict(cfg, model_dir="m2")
            assert np.allclose(p1["forecast"].to_numpy(), p2["forecast"].to_numpy())
        finally:
            os.chdir(cwd)
