"""Make src modules importable whether tests run from the plugin templates layout
(templates/ + templates/tests/) or the scaffolded project layout (src/ + tests/)."""
import os
import sys

_here = os.path.dirname(os.path.abspath(__file__))
for cand in (os.path.dirname(_here), os.path.join(os.path.dirname(_here), "src")):
    if os.path.isdir(cand) and cand not in sys.path:
        sys.path.insert(0, cand)
