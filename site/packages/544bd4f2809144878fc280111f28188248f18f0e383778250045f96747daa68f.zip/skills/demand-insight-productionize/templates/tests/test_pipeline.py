"""End-to-end smoke: preprocess → features → train → predict produces sane output."""
import os
import tempfile

import numpy as np
import pandas as pd

from preprocessing import preprocess
import train as train_mod
import predict as predict_mod


def test_preprocess_flags_and_fills():
    # steady low demand with one unambiguous spike (>3σ above the rest)
    dates = pd.date_range("2024-01-01", periods=20, freq="D")
    qty = [5, 6, np.nan, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 500]
    df = pd.DataFrame({"date": dates, "qty": qty})
    out = preprocess(df, "date", "qty", None)
    assert out["qty"].isna().sum() == 0          # interpolation filled the gap
    assert "is_event" in out.columns
    assert out["is_event"].iloc[-1] == 1          # the 500 spike is flagged


def test_end_to_end_predict_nonnegative_with_intervals():
    with tempfile.TemporaryDirectory() as tmp:
        n = 90
        dates = pd.date_range("2024-01-01", periods=n, freq="D")
        rng = np.random.default_rng(1)
        qty = np.clip(8 + 2 * np.sin(np.arange(n) * 2 * np.pi / 7) + rng.normal(0, 1, n), 0, None)
        csv = os.path.join(tmp, "s.csv")
        pd.DataFrame({"date": dates, "qty": qty}).to_csv(csv, index=False)
        cfg = {"data_source": {"path": csv, "time_column": "date", "target_column": "qty"},
               "horizon": 1, "random_seed": 42}
        cwd = os.getcwd(); os.chdir(tmp)
        try:
            train_mod.train(cfg, out_dir="models")
            res = predict_mod.predict(cfg)
            assert len(res) > 0
            assert (res["forecast"] >= 0).all()
            assert (res["hi_95"] >= res["lo_5"]).all()
        finally:
            os.chdir(cwd)
