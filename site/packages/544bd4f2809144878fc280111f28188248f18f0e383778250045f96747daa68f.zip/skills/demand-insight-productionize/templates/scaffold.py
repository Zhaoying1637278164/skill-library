"""Expand the production templates into a user project directory.

Copies preprocessing/features/train/predict into <out>/src, tests into <out>/tests,
deploy notes into <out>/deploy, and injects feature_plan.json / best_model settings
when present. Idempotent.

Usage:
    python scaffold.py input.json --out project
"""
import os
import shutil
import json
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_FILES = ["preprocessing.py", "features.py", "train.py", "predict.py"]


def scaffold(cfg_path: str, out: str):
    src = os.path.join(out, "src")
    tests = os.path.join(out, "tests")
    deploy = os.path.join(out, "deploy")
    for d in (src, tests, deploy):
        os.makedirs(d, exist_ok=True)

    for f in SRC_FILES:
        shutil.copy(os.path.join(HERE, f), os.path.join(src, f))
    # tests
    tdir = os.path.join(HERE, "tests")
    for f in os.listdir(tdir):
        if f.endswith(".py"):
            shutil.copy(os.path.join(tdir, f), os.path.join(tests, f))
    # deploy notes + requirements
    ddir = os.path.join(HERE, "deploy")
    if os.path.isdir(ddir):
        for f in os.listdir(ddir):
            shutil.copy(os.path.join(ddir, f), os.path.join(deploy, f))
    req = os.path.join(HERE, "requirements.txt")
    if os.path.exists(req):
        shutil.copy(req, os.path.join(out, "requirements.txt"))

    # carry over config + plan if present
    if os.path.exists(cfg_path):
        shutil.copy(cfg_path, os.path.join(out, "input.json"))
    for plan in ("feature_plan.json", "state.json"):
        if os.path.exists(plan):
            shutil.copy(plan, os.path.join(out, plan))

    print(f"scaffolded production project at {out}/ (src, tests, deploy)")
    print("next: cd", out, "&& python -m pytest -q tests")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out", default="project")
    a = ap.parse_args()
    scaffold(a.input, a.out)
