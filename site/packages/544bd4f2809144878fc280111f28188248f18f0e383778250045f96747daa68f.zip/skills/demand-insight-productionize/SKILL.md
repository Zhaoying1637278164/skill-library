---
name: demand-insight-productionize
description: Use this skill once a model has been accepted (acceptance criteria met / next_action=accept) to generate a production implementation — preprocessing, feature building (leakage-safe), training, batch prediction with intervals, a pytest suite (leakage + backtest reproducibility), and deployment config. Copies and parameterizes the templates into the user's project src/ and tests/. Use when the user says "productionize", "generate production code", "make it deployable", or after the loop accepts a model.
---

# demand-insight-productionize (本番実装の生成)

受け入れ基準達成後、`state.json` / `feature_plan.json` / `best_model` を元に**動く本番コード一式**を生成する。

## Precondition
- `decision.json.next_action == "accept"` または `input.acceptance` 達成。未達なら本スキルは実行しない。

## 生成物（user プロジェクトの `project/` 配下に出力）
```
project/
├── src/preprocessing.py     # 欠損補間 + is_event フラグ（学習時 fit を保存し推論で再利用）
├── src/features.py          # feature_plan.json 駆動・リーク防止内蔵（shift(1)/horizon制約）
├── src/train.py             # best_model 再学習・シード固定・models/ へ保存
├── src/predict.py           # バッチ推論 + 予測区間
├── tests/test_no_leakage.py        # 特徴量にリークが無いことを機械検証
├── tests/test_backtest_repro.py    # 同条件で同結果（再現性）
├── tests/test_pipeline.py          # end-to-end スモーク
├── deploy/schedule.md      # バッチ再学習/推論スケジュール雛形
├── deploy/monitoring.md    # ドリフト/カバレッジ監視雛形
└── requirements.txt
```

## 手順
1. `templates/` を `project/src` `project/tests` `project/deploy` へコピー。
2. `feature_plan.json` の採用特徴量・ラグ・窓・horizon を `src/features.py` の設定に反映。
3. `state.json.best_model` の系統・パラメータを `src/train.py` に反映。
4. `pytest -q project/tests` を実行し、`test_no_leakage` パス・カバレッジ ≥80% を確認。
5. `deploy/` の運用設定（再学習周期=Walk-Forward の refit 周期、リードタイム=gap）を業務サイクルに合わせ記入。

## Run
```bash
python templates/scaffold.py input.json --out project    # テンプレを project/ に展開し feature_plan/best_model を注入
cd project && python -m pytest -q tests
```

## CRITICAL（生成コードが守る不変条件）
- リーク防止: `rolling` は `shift(1)`、horizon 未満ラグ除外、スケーラ/選択は train のみ fit→推論で再利用。
- 再現性: `random_seed` 固定、データ/モデル/コードのバージョンを記録。
- 確率出力: 予測区間（bootstrapping）を必ず出す（安全在庫の根拠）。

## references
- `references/productionization.md` — ディレクトリ規約・再現性・運用移行の詳細。

## Anti-patterns
- 受け入れ前に本番化 / 学習統計を推論時に再計算（fit を保存しない）/ 点予測のみで区間を捨てる。
