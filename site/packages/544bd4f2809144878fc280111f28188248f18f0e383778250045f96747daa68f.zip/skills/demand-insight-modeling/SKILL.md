---
name: demand-insight-modeling
description: Use this skill for Steps 5 & 7 of demand-insight — build, backtest, and interpret per-segment models. First builds Naive/Seasonal-Naive/MA/SES baselines via StatsForecast, then applies the segment-appropriate advanced model (LightGBM/Croston/SBA/TSB) with skforecast, runs Walk-Forward Validation with bootstrapped prediction intervals (lead-time gap), and extracts feature importance / SHAP. Adopts an advanced model only if it beats baseline. Use after feature engineering, after a G1 model-family switch, or to measure baselines alone.
---

# demand-insight-modeling (Step 5+7: モデリング)

セグメントごとに最適手法を比較選定し、Walk-Forward で公平に評価、確率予測区間を出す（要件 §8）。

## CRITICAL — ベースライン先行 & Walk-Forward（要件 §1.2 / §1.3）
- 必ず `Naive / SeasonalNaive / WindowAverage(MA) / SES` を先に構築（StatsForecast、数万系列でも高速）。
- 高度モデルとベースラインは**同じ Walk-Forward 設定**で比較。`gap=lead_time` でリードタイム再現、`refit` は業務サイクル。
- ランダム分割（train_test_split / K-Fold）禁止。
- **3段階採用判定**: advanced<baseline×0.95→採用 / ×0.95〜baseline→marginal採用(warning) / **≥baseline→採用禁止・即停止（G1切替 or baseline採用 or abort）**。

## 系統選択（分類結果に従う / モデルレジストリ `templates/models.py`）
- Smooth/Erratic: LightGBM/XGBoost/CatBoost、AutoARIMA/AutoETS。**履歴が十分**（既定 `models.neural_min_obs`=180 以上）なら **ニューラル**も自動候補化（表形式 `mlp` / 系列ネイティブ `nbeats`・`nhits`）。
- Intermittent/Lumpy: Croston/SBA/TSB/ADIDA（**LightGBM 禁忌**）。Lumpy のみ確率的 `deepar` を任意追加（点予測ニューラルは入れない）。
- コールドスタート（履歴僅少）: 基盤モデル `foundation`（Chronos/TimeGPT/TimesFM ゼロショット）。
- 難系列のみ（Step7）: スタッキング/アンサンブル/データ拡張。
- すべて**オプション依存**：ライブラリ未導入時は自動で `lightgbm`→`ridge` にフォールバック（パイプラインは止まらない）。`input.json` の `models.enable_neural=false` でニューラル無効化、`models.backends` で明示指定。

## Run
```bash
python templates/baseline.py input.json          # ベースライン（Walk-Forward 内蔵: SeasonalNaive/Naive/MA）
python templates/advanced_model.py input.json    # レジストリで自動選択 + Walk-Forward + 予測区間 + 3段階採用判定
python templates/advanced_model.py input.json --model mlp   # モデルを明示指定（mlp/nbeats/nhits/deepar/lightgbm/ridge…）
```
モデル選択順：`--model` > `input.json` の `models.backends` > 各セグメントの `recommended_models`（象限から自動）。`PRIORITY`（mlp→nbeats→…→lightgbm→ridge）で利用可能な最優先を採用。
Walk-Forward（expanding window, `gap=lead_time`, `step=horizon`, 複数 fold）は両スクリプトに内蔵。表形式（mlp 含む）は**リーク安全な特徴量表をそのまま使用**＝構造的に安全。系列ネイティブは harness が `gap/horizon` を渡してリーク防止を強制。
ライブラリ不在/実行時失敗は自動で `lightgbm`→`ridge` にフォールバック。
確率予測: `mlp` は MC-dropout、DeepAR 等は分布、その他は bootstrap 残差で `interval=[5,95]`(90%区間), `n_boot=200`。`interval_coverage` 0.85〜0.95 が健全。
解釈性: SHAP（TreeExplainer）で寄与可視化 → 誤差分析の次仮説に渡す（ニューラルは feature gradients / attention で代替可）。

## Hand-off
`backtest_iter_NNN.csv` / `state.json.best_model`（系統・パラメータ・指標・区間）を `demand-insight-evaluation` に渡す。

## Anti-patterns
- ベースライン未測定で advanced 採用 / Intermittent に LightGBM・点予測ニューラル / 単一点予測のみ（区間を出さない）。
- 短履歴（`neural_min_obs` 未満）や間欠・コールドスタート系列にニューラルを強制 / ニューラルをベースライン比較なしで採用（3段階採用判定は系統に関わらず門番）。
- torch データローダで `shift(1)` 無しの window 生成（リーク）。表形式 mlp は既存のシフト済み特徴量を使うため安全。
