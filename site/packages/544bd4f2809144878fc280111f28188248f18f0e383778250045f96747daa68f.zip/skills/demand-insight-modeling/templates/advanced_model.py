"""demand-insight Steps 5/7 — advanced model via Walk-Forward (functional).

Selects the segment-appropriate advanced model from the model registry (models.py)
— tabular (ridge / lightgbm / mlp) or series-native (neuralforecast / foundation) —
fits it on the leakage-safe features with an expanding-window Walk-Forward backtest
(gap=lead_time, step=horizon), produces prediction intervals (MC-dropout / native /
bootstrapped residuals), compares against the baseline (baseline_metrics.json) using
the 3-stage adoption rule, and writes backtest_iter_001.csv + state.best_model.

Model selection (rules/demand-forecast.md §4.1, auto from quadrant):
  - candidates come from state.segments[].recommended_models (or input.json
    models.backends override); models.select() picks the highest-PRIORITY one whose
    library is installed, falling back lightgbm -> ridge so the run never breaks.
  - neural models are tried only when their library is present and
    input.json models.enable_neural is not false.

3-stage adoption (rules/demand-forecast.md §1.2):
  advanced < baseline*0.95          → adopt (success)
  baseline*0.95 <= advanced < base  → adopt with warning (marginal)
  advanced >= baseline              → DO NOT adopt (error → G1 switch / baseline / abort)

Usage:
    python advanced_model.py input.json [--features features_train.parquet] [--model NAME]
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import pandas as pd

from importlib import import_module


def _mod(name):
    """Import a sibling template module (baseline.py / models.py)."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    return import_module(name)


def fit_predict(Xtr, ytr, Xte, seed=42):
    """Backwards-compatible tabular helper: lightgbm if available, else ridge.

    Kept for callers/tests that import this directly; new code paths go through the
    model registry (models.select / models.resolve).
    """
    M = _mod("models")
    adapter = M.resolve("lightgbm", seed) or M.RidgeAdapter()
    return adapter.fit_predict(Xtr, ytr, Xte, seed), adapter.name


def _naive_resid_std(tr, date_col, tgt):
    """Leakage-free interval scale for series models that lack native intervals:
    std of the train target's first difference (naive one-step residual)."""
    s = tr.sort_values(date_col)[tgt].to_numpy(float)
    if len(s) < 2:
        return float(np.std(s)) or 1.0
    return float(np.std(np.diff(s))) or 1.0


def _predict_fold(adapter, tr, te, feats, date_col, tgt, group_cols, exog_cols,
                  horizon, gap, seed, n_boot, rng):
    """Return (pred, lo, hi) for one fold, dispatching on adapter.kind."""
    if adapter.kind == "series":
        preds, lo, hi = adapter.fit_predict_series(
            tr, te, date_col, tgt, group_cols, exog_cols, horizon, gap, seed)
        if lo is None or hi is None:
            sd = _naive_resid_std(tr, date_col, tgt)
            draws = rng.normal(0, sd, size=(n_boot, len(preds)))
            samples = np.clip(preds[None, :] + draws, 0, None)
            lo, hi = np.percentile(samples, 5, axis=0), np.percentile(samples, 95, axis=0)
        return preds, lo, hi

    # tabular
    Xtr, ytr = tr[feats].to_numpy(float), tr[tgt].to_numpy(float)
    Xte = te[feats].to_numpy(float)
    if hasattr(adapter, "fit_predict_samples"):  # e.g. mlp MC-dropout
        pred, samples = adapter.fit_predict_samples(Xtr, ytr, Xte, seed, n=n_boot)
        lo, hi = np.percentile(samples, 5, axis=0), np.percentile(samples, 95, axis=0)
        return pred, lo, hi
    pred = adapter.fit_predict(Xtr, ytr, Xte, seed)
    resid_std = float(np.std(ytr - adapter.fit_predict(Xtr, ytr, Xtr, seed))) or 1.0
    draws = rng.normal(0, resid_std, size=(n_boot, len(pred)))
    samples = np.clip(pred[None, :] + draws, 0, None)
    lo, hi = np.percentile(samples, 5, axis=0), np.percentile(samples, 95, axis=0)
    return pred, lo, hi


def run_wf(adapter, df, folds, feats, date_col, tgt, group_cols, exog_cols,
           horizon, gap, seed, n_boot=200):
    """Run the Walk-Forward backtest for one adapter. Raises on adapter failure."""
    rng = np.random.default_rng(seed)
    rows, ys, ps = [], [], []
    for fi, (train_end, test_dates) in enumerate(folds):
        tr = df[df[date_col] <= train_end].dropna(subset=feats + [tgt])
        te = df[df[date_col].isin(test_dates)].dropna(subset=feats + [tgt])
        if len(tr) < 20 or len(te) == 0:
            continue
        pred, lo, hi = _predict_fold(adapter, tr, te, feats, date_col, tgt, group_cols,
                                     exog_cols, horizon, gap, seed, n_boot, rng)
        y = te[tgt].to_numpy(float)
        ys.append(y); ps.append(np.asarray(pred, float))
        for j in range(len(te)):
            rows.append({"fold": fi, "date": str(te[date_col].iloc[j]),
                         "actual": float(y[j]), "forecast": float(pred[j]),
                         "lo_5": float(lo[j]), "hi_95": float(hi[j])})
    if not rows:
        raise RuntimeError("no folds produced predictions")
    return rows, np.concatenate(ys), np.concatenate(ps)


def _recommended_from_state(path="state.json"):
    """Collect recommended_models tokens across segments (for auto-selection)."""
    try:
        st = json.load(open(path, encoding="utf-8"))
    except Exception:
        return []
    toks = []
    for seg in (st.get("segments") or []):
        for t in (seg.get("recommended_models") or []):
            if t not in toks:
                toks.append(t)
    return toks


def main():
    ap = argparse.ArgumentParser(description="demand-insight advanced model")
    ap.add_argument("input")
    ap.add_argument("--features", default="features_train.parquet")
    ap.add_argument("--out", default="backtest_iter_001.csv")
    ap.add_argument("--model", default=None, help="force a registry model (mlp/nbeats/lightgbm/...)")
    a = ap.parse_args()
    B = _mod("baseline")
    M = _mod("models")
    cfg = json.load(open(a.input, encoding="utf-8"))
    ds = cfg["data_source"]
    date_col, tgt = ds["time_column"], ds["target_column"]
    group_cols = ds.get("id_columns") or []
    exog_cols = ds.get("exog_columns") or []
    horizon = int(cfg.get("horizon", 7))
    lt = cfg.get("lead_time", 0)
    gap = lt if isinstance(lt, int) else (lt or {}).get("default", 0)
    bk = cfg.get("business_kpi", {})
    sp, ep = bk.get("shortage_penalty", 5.0), bk.get("excess_penalty", 1.0)
    seed = int(cfg.get("random_seed", 42))

    df = B.read_table(a.features)
    if df is None:
        print("ERROR: features table not found; run features.py first", file=sys.stderr); sys.exit(2)
    df[date_col] = pd.to_datetime(df[date_col])
    exclude = set([date_col, tgt] + group_cols)
    feats = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]
    folds = B.wf_folds(df[date_col], horizon, gap)
    if not folds:
        print("ERROR: not enough data for Walk-Forward", file=sys.stderr); sys.exit(2)

    # --- model selection (CLI override > input.json backends > segment recommendations) ---
    if a.model:
        adapter = M.resolve(a.model, seed) or M.select([], cfg, seed)
    else:
        recommended = _recommended_from_state()
        adapter = M.select(recommended, cfg, seed)

    # --- Walk-Forward with graceful fallback if the chosen model fails at runtime ---
    try:
        rows, y, p = run_wf(adapter, df, folds, feats, date_col, tgt, group_cols,
                            exog_cols, horizon, gap, seed)
    except Exception as e:
        print(f"WARNING: model '{adapter.name}' failed ({e}); falling back to lightgbm/ridge",
              file=sys.stderr)
        adapter = M.resolve("lightgbm", seed) or M.RidgeAdapter()
        rows, y, p = run_wf(adapter, df, folds, feats, date_col, tgt, group_cols,
                            exog_cols, horizon, gap, seed)

    bt = pd.DataFrame(rows)
    bt.to_csv(a.out, index=False)
    cov = float(((bt["actual"] >= bt["lo_5"]) & (bt["actual"] <= bt["hi_95"]).astype(bool)).mean())
    adv = {"name": f"advanced_{adapter.name}", "model_name": adapter.name, "kind": adapter.kind,
           "MAPE": round(B.mape(y, p), 3), "RMSE": round(B.rmse(y, p), 3),
           "asymmetric_cost": round(B.asym_cost(y, p, sp, ep), 3), "interval_coverage": round(cov, 3),
           "n_features": len(feats), "folds": len(folds)}

    # 3-stage adoption vs baseline
    base = {}
    if os.path.exists("baseline_metrics.json"):
        base = (json.load(open("baseline_metrics.json", encoding="utf-8")).get("best_metrics") or {})
    bmape = base.get("MAPE")
    if bmape is not None and bmape == bmape and adv["MAPE"] == adv["MAPE"]:
        if adv["MAPE"] < bmape * 0.95:
            adv["adoption"] = "adopt"
        elif adv["MAPE"] < bmape:
            adv["adoption"] = "adopt_marginal"; adv["warning"] = "improvement < 5%"
        else:
            adv["adoption"] = "reject"; adv["warning"] = "advanced >= baseline → G1 switch / baseline / abort"
    else:
        adv["adoption"] = "unknown(baseline missing)"

    try:
        state = json.load(open("state.json", encoding="utf-8")) if os.path.exists("state.json") else {"iteration": 0}
        state["best_model"] = adv
        state["step"] = "error_analysis"
        json.dump(state, open("state.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except Exception:
        pass

    print(f"advanced model: {adv['name']} ({adv['kind']}) over {len(folds)} folds")
    print(f"  MAPE={adv['MAPE']} RMSE={adv['RMSE']} cost={adv['asymmetric_cost']} coverage={adv['interval_coverage']}")
    print(f"  baseline MAPE={bmape}  -> adoption: {adv['adoption']} {adv.get('warning','')}")
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
