"""demand-insight model registry — pluggable advanced models with graceful fallback.

Registers two families of advanced models behind one interface:

  tabular (consume the leakage-safe feature matrix, same as LightGBM):
    - ridge       numpy-only ridge regression — ALWAYS available (final fallback)
    - lightgbm    gradient-boosted trees (optional: lightgbm)
    - mlp         torch MLP + dropout, MC-dropout prediction intervals (optional: torch)

  series-native (consume the raw per-series target + exog; do their own windowing):
    - neuralforecast   NBEATS / NHITS / TFT / DeepAR  (optional: neuralforecast + torch)
    - foundation       zero-shot Chronos / TimeGPT / TimesFM (optional, for cold start)

Every adapter is OPTIONAL. resolve()/select() probe each library and skip the ones
that are absent, falling back lightgbm -> ridge. ridge needs only numpy, so the
pipeline never breaks regardless of what is installed.

Adapter contracts
-----------------
tabular:
    fit_predict(Xtr, ytr, Xte, seed, **params) -> np.ndarray   (clipped >= 0)
    [optional] fit_predict_samples(Xtr, ytr, Xte, seed, n, **params)
               -> (point: np.ndarray, samples: np.ndarray[n, m])   # for intervals
series:
    fit_predict_series(train_df, test_df, date_col, tgt, group_cols, exog_cols,
                       horizon, gap, seed, **params)
               -> (preds: np.ndarray, lo: np.ndarray|None, hi: np.ndarray|None)
               # preds aligned row-for-row to test_df

Leakage safety
--------------
- tabular adapters read the already-shift(1)-applied feature table, so they are
  leakage-safe by construction (rules/demand-forecast.md §1.1 / §3.1).
- series adapters receive only rows up to the fold's train_end as context and are
  given gap (= lead_time) + horizon so each library reproduces the lead-time gap.
  The target is never shifted by a negative amount.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


class ModelUnavailable(Exception):
    """Raised by an adapter whose backing library is not installed/usable."""


# --------------------------------------------------------------------------- #
# Tabular adapters
# --------------------------------------------------------------------------- #
class _Adapter:
    name = "base"
    kind = "tabular"

    def available(self) -> bool:
        return True


class RidgeAdapter(_Adapter):
    name = "ridge"
    kind = "tabular"

    def fit_predict(self, Xtr, ytr, Xte, seed=42, lam=1.0, **params):
        Xtr, ytr, Xte = np.asarray(Xtr, float), np.asarray(ytr, float), np.asarray(Xte, float)
        Xb = np.column_stack([np.ones(len(Xtr)), Xtr])
        A = Xb.T @ Xb + float(lam) * np.eye(Xb.shape[1])
        coef = np.linalg.solve(A, Xb.T @ ytr)
        Xteb = np.column_stack([np.ones(len(Xte)), Xte])
        return np.clip(Xteb @ coef, 0, None)


class LightGBMAdapter(_Adapter):
    name = "lightgbm"
    kind = "tabular"

    def available(self) -> bool:
        try:
            import lightgbm  # noqa: F401
            return True
        except Exception:
            return False

    def fit_predict(self, Xtr, ytr, Xte, seed=42, n_estimators=300, learning_rate=0.05, **params):
        try:
            import lightgbm as lgb
        except Exception as e:  # pragma: no cover - exercised only when lib absent
            raise ModelUnavailable("lightgbm not installed") from e
        m = lgb.LGBMRegressor(n_estimators=int(n_estimators), learning_rate=float(learning_rate),
                              random_state=int(seed), n_jobs=-1, verbose=-1)
        m.fit(np.asarray(Xtr, float), np.asarray(ytr, float))
        return np.clip(m.predict(np.asarray(Xte, float)), 0, None)


class MLPAdapter(_Adapter):
    """Tabular torch MLP with dropout. Reuses the leakage-safe feature matrix.

    Prediction intervals use MC-dropout: dropout is kept active at inference and the
    network is sampled n times, feeding the same interval/coverage logic the harness
    already applies to bootstrap residuals.
    """
    name = "mlp"
    kind = "tabular"

    def available(self) -> bool:
        try:
            import torch  # noqa: F401
            return True
        except Exception:
            return False

    @staticmethod
    def _standardize(Xtr):
        mu = Xtr.mean(axis=0)
        sd = Xtr.std(axis=0)
        sd = np.where(sd == 0, 1.0, sd)
        return mu, sd

    def _train(self, Xtr, ytr, seed, hidden, dropout, epochs, lr):
        import torch
        import torch.nn as nn
        torch.manual_seed(int(seed))
        mu, sd = self._standardize(Xtr)
        Xs = (Xtr - mu) / sd
        net = nn.Sequential(
            nn.Linear(Xs.shape[1], hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, 1),
        )
        opt = torch.optim.Adam(net.parameters(), lr=lr)
        lossf = nn.MSELoss()
        xt = torch.tensor(Xs, dtype=torch.float32)
        yt = torch.tensor(ytr.reshape(-1, 1), dtype=torch.float32)
        n = len(xt)
        bs = min(256, n) or 1
        gen = torch.Generator().manual_seed(int(seed))
        net.train()
        for _ in range(int(epochs)):
            perm = torch.randperm(n, generator=gen)
            for i in range(0, n, bs):
                idx = perm[i:i + bs]
                opt.zero_grad()
                loss = lossf(net(xt[idx]), yt[idx])
                loss.backward()
                opt.step()
        return net, mu, sd

    def fit_predict(self, Xtr, ytr, Xte, seed=42, hidden=64, dropout=0.1, epochs=200, lr=1e-3, **params):
        try:
            import torch
        except Exception as e:  # pragma: no cover
            raise ModelUnavailable("torch not installed") from e
        Xtr, ytr, Xte = np.asarray(Xtr, float), np.asarray(ytr, float), np.asarray(Xte, float)
        net, mu, sd = self._train(Xtr, ytr, seed, int(hidden), float(dropout), int(epochs), float(lr))
        net.eval()
        with torch.no_grad():
            xs = torch.tensor((Xte - mu) / sd, dtype=torch.float32)
            pred = net(xs).numpy().ravel()
        return np.clip(pred, 0, None)

    def fit_predict_samples(self, Xtr, ytr, Xte, seed=42, n=200, hidden=64, dropout=0.1,
                            epochs=200, lr=1e-3, **params):
        try:
            import torch
        except Exception as e:  # pragma: no cover
            raise ModelUnavailable("torch not installed") from e
        Xtr, ytr, Xte = np.asarray(Xtr, float), np.asarray(ytr, float), np.asarray(Xte, float)
        net, mu, sd = self._train(Xtr, ytr, seed, int(hidden), float(dropout), int(epochs), float(lr))
        xs = torch.tensor((Xte - mu) / sd, dtype=torch.float32)
        # point forecast (dropout off)
        net.eval()
        with torch.no_grad():
            point = np.clip(net(xs).numpy().ravel(), 0, None)
        # MC-dropout samples (dropout on, deterministic given seed)
        torch.manual_seed(int(seed) + 1)
        net.train()
        draws = []
        with torch.no_grad():
            for _ in range(int(n)):
                draws.append(net(xs).numpy().ravel())
        net.eval()
        samples = np.clip(np.vstack(draws), 0, None)
        return point, samples


# --------------------------------------------------------------------------- #
# Series-native adapters
# --------------------------------------------------------------------------- #
def _long_frame(df, date_col, tgt, group_cols, exog_cols):
    """Reshape a feature/raw table into a neuralforecast long frame."""
    cols = [date_col, tgt] + list(group_cols or []) + list(exog_cols or [])
    cols = [c for c in dict.fromkeys(cols) if c in df.columns]
    d = df[cols].copy()
    if group_cols:
        d["unique_id"] = d[group_cols].astype(str).agg("-".join, axis=1)
    else:
        d["unique_id"] = "all"
    d = d.rename(columns={date_col: "ds", tgt: "y"})
    d["ds"] = pd.to_datetime(d["ds"])
    return d


class NeuralForecastAdapter(_Adapter):
    """neuralforecast NBEATS / NHITS / TFT / DeepAR (series-native, multi-series)."""
    kind = "series"

    def __init__(self, model_name="nbeats"):
        self.name = model_name  # nbeats | nhits | tft | deepar

    def available(self) -> bool:
        try:
            import neuralforecast  # noqa: F401
            return True
        except Exception:
            return False

    def fit_predict_series(self, train_df, test_df, date_col, tgt, group_cols, exog_cols,
                           horizon, gap, seed, **params):
        try:
            import torch
            from neuralforecast import NeuralForecast
            from neuralforecast.models import NBEATS, NHITS, TFT, DeepAR
        except Exception as e:
            raise ModelUnavailable("neuralforecast/torch not installed") from e
        try:
            torch.manual_seed(int(seed))
            h = int(gap) + int(horizon)
            futr = [c for c in (exog_cols or []) if c in train_df.columns]
            ctor = {"nbeats": NBEATS, "nhits": NHITS, "tft": TFT, "deepar": DeepAR}[self.name]
            max_steps = int(params.get("max_steps", 200))
            input_size = int(params.get("input_size", max(2 * h, 16)))
            kw = dict(h=h, input_size=input_size, max_steps=max_steps, random_seed=int(seed))
            use_futr = bool(futr) and self.name == "tft"
            if use_futr:
                kw["futr_exog_list"] = futr
            model = ctor(**kw)
            dates_sorted = sorted(pd.to_datetime(train_df[date_col]).unique())
            freq = pd.infer_freq(dates_sorted) or "D"
            nf = NeuralForecast(models=[model], freq=freq)
            train_long = _long_frame(train_df, date_col, tgt, group_cols, futr)
            fit_cols = ["unique_id", "ds", "y"] + (futr if use_futr else [])
            nf.fit(df=train_long[fit_cols])
            fcst = nf.predict()
            ycol = [c for c in fcst.columns if c not in ("unique_id", "ds")][0]
            fcst = fcst.rename(columns={ycol: "yhat"})
            fcst["ds"] = pd.to_datetime(fcst["ds"])
            key = _long_frame(test_df, date_col, tgt, group_cols, [])[["unique_id", "ds"]].copy()
            key["__order"] = np.arange(len(key))
            merged = key.merge(fcst[["unique_id", "ds", "yhat"]], on=["unique_id", "ds"], how="left")
            merged = merged.sort_values("__order")
            preds = merged["yhat"].to_numpy(float)
            fill = float(np.nanmean(preds)) if np.isfinite(np.nanmean(preds)) else 0.0
            preds = np.clip(np.nan_to_num(preds, nan=fill), 0, None)
            return preds, None, None
        except ModelUnavailable:
            raise
        except Exception as e:  # any runtime failure -> degrade gracefully
            raise ModelUnavailable(f"neuralforecast runtime error: {e}") from e


class FoundationAdapter(_Adapter):
    """Zero-shot foundation models (Chronos / TimeGPT / TimesFM) for cold start."""
    name = "foundation"
    kind = "series"

    def __init__(self, backend="chronos"):
        self.backend = backend

    def available(self) -> bool:
        for mod in ("chronos", "nixtla", "timesfm"):
            try:
                __import__(mod)
                return True
            except Exception:
                continue
        return False

    def fit_predict_series(self, train_df, test_df, date_col, tgt, group_cols, exog_cols,
                           horizon, gap, seed, **params):
        try:
            from chronos import ChronosPipeline
            import torch
        except Exception as e:
            raise ModelUnavailable("chronos not installed") from e
        try:
            pipe = ChronosPipeline.from_pretrained(
                params.get("repo", "amazon/chronos-t5-small"),
                device_map=params.get("device", "cpu"), torch_dtype=torch.float32)
            h = int(gap) + int(horizon)
            tr = _long_frame(train_df, date_col, tgt, group_cols, [])
            te = _long_frame(test_df, date_col, tgt, group_cols, [])
            te = te.reset_index(drop=True)
            te["__order"] = np.arange(len(te))
            out = np.full(len(te), np.nan)
            for uid, g in tr.groupby("unique_id"):
                ctx = torch.tensor(g.sort_values("ds")["y"].to_numpy(float))
                fc = pipe.predict(ctx, h)  # [1, num_samples, h]
                median = np.median(fc[0].numpy(), axis=0)  # [h]
                last = g["ds"].max()
                sub = te[te["unique_id"] == uid]
                for _, r in sub.iterrows():
                    step = (pd.Timestamp(r["ds"]) - pd.Timestamp(last)).days
                    if 1 <= step <= h:
                        out[int(r["__order"])] = median[step - 1]
            fill = float(np.nanmean(out)) if np.isfinite(np.nanmean(out)) else 0.0
            out = np.clip(np.nan_to_num(out, nan=fill), 0, None)
            return out, None, None
        except ModelUnavailable:
            raise
        except Exception as e:
            raise ModelUnavailable(f"foundation runtime error: {e}") from e


# --------------------------------------------------------------------------- #
# Registry + resolution
# --------------------------------------------------------------------------- #
# Built lazily so importing this module is cheap and never touches optional libs.
def _registry():
    return {
        "ridge": RidgeAdapter(),
        "lightgbm": LightGBMAdapter(),
        "mlp": MLPAdapter(),
        "nbeats": NeuralForecastAdapter("nbeats"),
        "nhits": NeuralForecastAdapter("nhits"),
        "tft": NeuralForecastAdapter("tft"),
        "deepar": NeuralForecastAdapter("deepar"),
        "foundation": FoundationAdapter(),
    }


# Preference order when several candidates are available. Neural first so an
# eligible quadrant auto-selects it; statistical fallbacks last. Adoption is still
# gated by the 3-stage baseline comparison downstream, so this is safe.
PRIORITY = ["mlp", "nbeats", "nhits", "tft", "deepar", "foundation", "lightgbm", "ridge"]

# Map the free-form tokens recommend() emits onto registry keys.
_ALIASES = {
    "lightgbm_exog": "lightgbm",
    "lgbm": "lightgbm",
    "chronos": "foundation",
    "timegpt": "foundation",
    "timesfm": "foundation",
}

# Tokens that this stage cannot serve (handled by baselines/StatsForecast or N/A).
# They are skipped during selection so we fall through to lightgbm -> ridge.
_NON_TABULAR_STATS = {"ets", "arima", "ses", "croston", "tsb", "sba", "adida",
                      "probabilistic", "cold_start", "bass"}


def _normalize(token):
    t = str(token).strip().lower()
    # strip wrappers like "foundation(chronos/timegpt/timesfm)"
    base = t.split("(")[0]
    if base.startswith("foundation"):
        return "foundation"
    base = _ALIASES.get(base, base)
    if base in _NON_TABULAR_STATS:
        return None
    return base


def resolve(name, seed=42):
    """Return an available adapter for `name`, or None if its library is absent."""
    key = _normalize(name)
    if key is None:
        return None
    adapter = _registry().get(key)
    if adapter is None:
        return None
    try:
        return adapter if adapter.available() else None
    except Exception:
        return None


def select(recommended_models, cfg=None, seed=42):
    """Pick the best available adapter from candidate tokens.

    Order of precedence:
      1. cfg["models"]["backends"] explicit override (if provided)
      2. the segments' recommended_models tokens
      3. always-available fallbacks: lightgbm -> ridge
    Within candidates, PRIORITY decides. Honors cfg.models.enable_neural=False.
    """
    cfg = cfg or {}
    mcfg = (cfg.get("models") or {})
    enable_neural = mcfg.get("enable_neural", True)

    tokens = list(mcfg.get("backends") or []) or list(recommended_models or [])
    keys = []
    for tok in tokens:
        k = _normalize(tok)
        if k and k not in keys:
            keys.append(k)
    # always have a working fallback
    for fb in ("lightgbm", "ridge"):
        if fb not in keys:
            keys.append(fb)

    neural_keys = {"mlp", "nbeats", "nhits", "tft", "deepar", "foundation"}
    ordered = sorted(keys, key=lambda k: PRIORITY.index(k) if k in PRIORITY else 999)
    for k in ordered:
        if not enable_neural and k in neural_keys:
            continue
        adapter = resolve(k, seed)
        if adapter is not None:
            return adapter
    return RidgeAdapter()  # guaranteed
