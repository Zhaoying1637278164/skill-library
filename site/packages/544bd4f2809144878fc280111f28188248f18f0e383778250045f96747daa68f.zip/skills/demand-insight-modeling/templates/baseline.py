"""demand-insight Step 5 — baselines via Walk-Forward (functional).

Builds row-level baselines from the leakage-safe features table and evaluates them
with an expanding-window Walk-Forward backtest (gap = lead_time, step = horizon):
  - SeasonalNaive  = lag_{season}   (uses the existing lag_7 / season column)
  - MovingAverage  = roll_mean_{w}
  - Naive          = smallest available lag
Writes baseline_metrics.json and merges into state.json. StatsForecast is preferred
when installed for the aggregate series; otherwise these column-based baselines are used.

Usage:
    python baseline.py input.json [--features features_train.parquet]
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import pandas as pd


def mape(y, yhat):
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    m = y > 0
    return float(np.mean(np.abs((y[m] - yhat[m]) / y[m])) * 100) if m.any() else float("nan")


def rmse(y, yhat):
    return float(np.sqrt(np.mean((np.asarray(y, float) - np.asarray(yhat, float)) ** 2)))


def asym_cost(y, yhat, sp=5.0, ep=1.0):
    e = np.asarray(yhat, float) - np.asarray(y, float)
    return float(np.mean(np.where(e < 0, -e * sp, e * ep)))


def read_table(path):
    if path.endswith(".parquet") and os.path.exists(path):
        try:
            return pd.read_parquet(path)
        except Exception:
            pass
    csv = os.path.splitext(path)[0] + ".csv"
    return pd.read_csv(csv) if os.path.exists(csv) else (pd.read_csv(path) if os.path.exists(path) else None)


def wf_folds(dates, horizon, gap, n_folds=4, min_train_frac=0.5):
    u = np.array(sorted(pd.unique(dates)))
    n = len(u)
    start = max(int(n * min_train_frac), 1)
    folds = []
    cut = start
    while cut + gap + horizon <= n and len(folds) < n_folds:
        train_end = u[cut - 1]
        test = u[cut + gap: cut + gap + horizon]
        if len(test):
            folds.append((train_end, test))
        cut += horizon
    return folds


def main():
    ap = argparse.ArgumentParser(description="demand-insight baselines")
    ap.add_argument("input")
    ap.add_argument("--features", default="features_train.parquet")
    a = ap.parse_args()
    cfg = json.load(open(a.input, encoding="utf-8"))
    ds = cfg["data_source"]
    date_col, tgt = ds["time_column"], ds["target_column"]
    horizon = int(cfg.get("horizon", 7))
    lt = cfg.get("lead_time", 0)
    gap = lt if isinstance(lt, int) else (lt or {}).get("default", 0)
    season = {"D": 7, "W": 52, "M": 12}.get(cfg.get("frequency", "D"), 7)
    bk = cfg.get("business_kpi", {})
    sp, ep = bk.get("shortage_penalty", 5.0), bk.get("excess_penalty", 1.0)

    df = read_table(a.features)
    if df is None:
        print("ERROR: features table not found; run features.py first", file=sys.stderr)
        sys.exit(2)
    df[date_col] = pd.to_datetime(df[date_col])

    lag_cols = sorted([c for c in df.columns if c.startswith("lag_")], key=lambda c: int(c.split("_")[1]))
    roll_cols = sorted([c for c in df.columns if c.startswith("roll_mean_")], key=lambda c: int(c.split("_")[2]))
    snaive_col = f"lag_{season}" if f"lag_{season}" in df.columns else (lag_cols[0] if lag_cols else None)
    naive_col = lag_cols[0] if lag_cols else None
    ma_col = roll_cols[0] if roll_cols else None

    folds = wf_folds(df[date_col], horizon, gap)
    if not folds:
        print("ERROR: not enough data for Walk-Forward folds", file=sys.stderr)
        sys.exit(2)

    baselines = {"SeasonalNaive": snaive_col, "Naive": naive_col, "MovingAverage": ma_col}
    results = {}
    for name, col in baselines.items():
        if not col:
            continue
        ys, ps = [], []
        for _, test_dates in folds:
            te = df[df[date_col].isin(test_dates)].dropna(subset=[col, tgt])
            ys.append(te[tgt].to_numpy()); ps.append(te[col].to_numpy())
        y = np.concatenate(ys); p = np.concatenate(ps)
        results[name] = {"MAPE": round(mape(y, p), 3), "RMSE": round(rmse(y, p), 3),
                         "asymmetric_cost": round(asym_cost(y, p, sp, ep), 3), "based_on": col}

    best = min((r for r in results.values()), key=lambda r: (r["MAPE"] if r["MAPE"] == r["MAPE"] else 1e9), default=None)
    best_name = min(results, key=lambda k: (results[k]["MAPE"] if results[k]["MAPE"] == results[k]["MAPE"] else 1e9)) if results else None
    out = {"folds": len(folds), "gap": gap, "horizon": horizon, "season": season,
           "baselines": results, "best_baseline": best_name, "best_metrics": best}
    json.dump(out, open("baseline_metrics.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    try:
        state = json.load(open("state.json", encoding="utf-8")) if os.path.exists("state.json") else {"iteration": 0}
        state["baseline_metrics"] = best or {}
        state["baseline_metrics"]["best_baseline"] = best_name
        json.dump(state, open("state.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except Exception:
        pass
    print(f"baselines over {len(folds)} Walk-Forward folds (gap={gap}, horizon={horizon}):")
    for k, v in results.items():
        print(f"  {k:14s} MAPE={v['MAPE']} RMSE={v['RMSE']} cost={v['asymmetric_cost']}")
    print(f"BEST baseline: {best_name} -> {best}")


if __name__ == "__main__":
    main()
