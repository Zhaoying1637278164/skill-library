# demand-insight — end-to-end walkthrough (example)

A self-contained run on the bundled synthetic **P3** dataset (3 stores × 4 SKUs, daily,
~540 days) with mixed demand patterns, weekly/yearly seasonality, holiday spikes, and a
few missing values.

## 0. Setup

```bash
pip install pandas numpy statsmodels ruptures statsforecast skforecast lightgbm shap openpyxl pytest
python examples/gen_sample.py            # → examples/data/sample_sales.csv
```

`examples/input.json` is preconfigured (use_case = predictive_ordering, P3, horizon 7, lead time 3,
shortage:excess = 5:1, classification = both).

## 1–8. Run the loop

Via Claude Code (recommended):

```
/demand-insight init           # confirms H1–H8 (already captured in examples/input.json) + state.json
/demand-insight run            # orchestrator runs eda → classify → features → model → evaluate, G1/G2 gated
/demand-insight report         # Excel report
/demand-insight productionize  # after a model is accepted
```

Or run the stage templates directly (cwd = repo root):

```bash
python skills/demand-insight-eda/templates/eda.py examples/input.json
python skills/demand-insight-classification/templates/pattern_classify.py examples/input.json --output segments_rule.json
python skills/demand-insight-features/templates/features.py examples/input.json
python skills/demand-insight-features/templates/leakage_check.py examples/input.json
python skills/demand-insight-modeling/templates/baseline.py examples/input.json
python skills/demand-insight-modeling/templates/advanced_model.py examples/input.json   # auto-selects from the registry (lightgbm here)
python skills/demand-insight-evaluation/templates/error_analysis.py examples/input.json
python skills/demand-insight-evaluation/templates/excel_report.py examples/input.json --out reports/demand_insight_report.xlsx
```

### Optional: neural / foundation models

Neural nets are auto-suggested for Smooth/Erratic segments with enough history and
used automatically when their library is installed (otherwise the run falls back to
`lightgbm`→`ridge`, so the commands above always work):

```bash
pip install torch                 # enables the tabular `mlp` model (MC-dropout intervals)
# pip install neuralforecast      # NBEATS / NHITS / TFT / DeepAR (series-native)
# pip install chronos-forecasting # zero-shot foundation model for cold start

python skills/demand-insight-modeling/templates/advanced_model.py examples/input.json --model mlp
```

Control via the `models` block in `input.json`:
`{"models": {"enable_neural": true, "neural_min_obs": 180, "backends": ["mlp", "nbeats", "lightgbm"]}}`.
Adoption is still gated by the 3-stage baseline comparison, so neural is used only when it actually wins.

## Production scaffold + tests

```bash
python skills/demand-insight-productionize/templates/scaffold.py examples/input.json --out project
cd project && python -m pytest -q --cov=src tests
```

Expected: leakage / reproducibility / pipeline tests pass; coverage ≥ 80% on `src/`.

## Acceptance check (要件 §7)
- EDA report produced from the actuals.
- Classification (rule-based vs ML) + per-segment spec.
- Baseline (Naive/SNaive/MA/SES) measured; advanced adopted only if it beats baseline by ≥5%.
- Leakage auto-verified (`leakage_check.py` + the PreToolUse guard).
- Excel report with business-KPI translation (stockouts / waste / ordering hours).
- Production tests green, coverage ≥ 80%.
