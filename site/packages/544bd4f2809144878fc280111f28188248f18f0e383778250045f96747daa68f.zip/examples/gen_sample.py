"""Generate a synthetic P3 (store × SKU × date) demand dataset for demand-insight.

Deterministic (fixed seed). Mixes demand patterns (smooth / erratic / intermittent),
weekly + yearly seasonality, holiday/event spikes, and a few missing values — so the
EDA, classification, modeling, and evaluation stages all have something to find.

Usage:
    python gen_sample.py [--out data/sample_sales.csv] [--days 540]
"""
import argparse
import os

import numpy as np
import pandas as pd

SEED = 42


def gen(days: int = 540) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    start = pd.Timestamp("2023-01-01")
    dates = pd.date_range(start, periods=days, freq="D")
    t = np.arange(days)

    stores = ["S01", "S02", "S03"]
    # (sku, base_level, pattern)
    skus = [
        ("SKU_A", 40, "smooth"),
        ("SKU_B", 25, "erratic"),
        ("SKU_C", 6, "intermittent"),
        ("SKU_D", 12, "smooth"),
    ]
    # simple JP-ish holiday spikes (relative day indices)
    holidays = set((pd.to_datetime(["2023-01-01", "2023-05-03", "2023-05-04", "2023-05-05",
                                    "2023-12-24", "2023-12-25", "2024-01-01", "2024-05-03",
                                    "2024-05-04", "2024-05-05"]) - start).days)

    weekly = lambda d: 1.0 + 0.25 * np.sin(d * 2 * np.pi / 7)
    yearly = lambda d: 1.0 + 0.15 * np.sin((d + 20) * 2 * np.pi / 365)

    rows = []
    for store in stores:
        store_mult = {"S01": 1.2, "S02": 1.0, "S03": 0.7}[store]
        for sku, base, pattern in skus:
            level = base * store_mult
            for d in t:
                season = weekly(d) * yearly(d)
                hol = 1.8 if d in holidays else 1.0
                if pattern == "smooth":
                    val = level * season * hol * (1 + rng.normal(0, 0.10))
                elif pattern == "erratic":
                    val = level * season * hol * (1 + rng.normal(0, 0.45))
                else:  # intermittent
                    occurs = rng.random() < 0.30
                    val = (level * season * hol * (1 + rng.normal(0, 0.3))) if occurs else 0.0
                qty = max(0, round(val))
                rows.append((dates[d], store, sku, qty, int(d in holidays)))

    df = pd.DataFrame(rows, columns=["date", "store_id", "sku_id", "qty", "is_holiday"])
    # inject a few missing values (S02 / SKU_B span)
    mask = (df["store_id"] == "S02") & (df["sku_id"] == "SKU_B") & \
           (df["date"].between("2023-06-10", "2023-06-13"))
    df.loc[mask, "qty"] = np.nan
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "data", "sample_sales.csv"))
    ap.add_argument("--days", type=int, default=540)
    a = ap.parse_args()
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    df = gen(a.days)
    df.to_csv(a.out, index=False)
    print(f"wrote {a.out}: {len(df)} rows, "
          f"{df['store_id'].nunique()} stores x {df['sku_id'].nunique()} SKUs, "
          f"{df['date'].min().date()}..{df['date'].max().date()}")
