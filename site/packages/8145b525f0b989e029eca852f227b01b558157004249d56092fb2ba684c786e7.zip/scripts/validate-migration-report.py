#!/usr/bin/env python3
"""Validate migration-report.html completeness after Generate phase.

Checks required section IDs, TOC anchor integrity, minimum appendix content,
artifact-derived cost markers, and customer-facing readability rules. Exit 0
on PASS, 1 on FAIL.

Usage:
  python3 validate-migration-report.py /path/to/migration-report.html
  python3 validate-migration-report.py report.html \\
      --estimation-infra estimation-infra.json \\
      --estimation-ai estimation-ai.json

Script location: this file lives at
  advisor/plugins/aws-startup-advisor/scripts/validate-migration-report.py
Agents should invoke it via Path(__file__) resolution or:
  python3 "$(dirname ...)/scripts/validate-migration-report.py" ...
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from html import unescape
from pathlib import Path

# Plugin root: advisor/plugins/aws-startup-advisor/
PLUGIN_ROOT = Path(__file__).resolve().parent.parent

REQUIRED_SECTION_IDS = [
    "decision-summary",
    "exec-assumptions",
    "exec-services",
    "exec-costs",
    "exec-timeline",
    "exec-risks",
    "appendix-services",
    "appendix-costs",
    "appendix-steps",
    "appendix-artifacts",
]

# Decision mode (decision-report.html rendered at the post-Estimate Decision
# gate, choice A): executive sections + CTA only — appendices are forbidden
# because no Generate artifacts exist yet.
DECISION_REQUIRED_SECTION_IDS = [
    "decision-summary",
    "exec-assumptions",
    "exec-services",
    "exec-costs",
    "exec-timeline",
    "exec-risks",
    "decision-cta",
]

OPTIONAL_SECTION_IDS = [
    "exec-share",
    "exec-tco",
    "exec-architecture",
    "exec-security-teaser",
    "exec-optimization",
    "what-if-scenarios",
    "appendix-ai",
    "appendix-config",
    "appendix-security",
    "appendix-security-gap",
    "appendix-assumptions",
    "appendix-optimization",
    "appendix-glossary",
]

FORBIDDEN_PATTERNS = [
    (r"\[placeholder\]", "placeholder text"),
    (r"\bTODO\b", "TODO marker"),
]

# Customer-facing readability rules (enforced unless --no-readability).
# These move the de-jargoning and no-numbering conventions from "example in the
# fixture" to "enforced gate", so a stray internal scoring trace or a patched
# "Section 0/1b" heading fails the report instead of silently shipping.
READABILITY_PATTERNS = [
    (
        r"(?<![-_])\bTCO\b|Total\s+Cost\s+of\s+Ownership",
        'misleading ownership-cost label ("TCO") — use "estimated AWS monthly '
        'run rate"; the report does not price staffing or operating labor',
    ),
    (
        r"Rubric:",
        'internal scoring trace ("Rubric:") — drop it or gate behind a '
        '<details> "Why this mapping?" block',
    ),
    (
        r"\d+\s*(?:–|-|to)\s*\d+\s*(?:engineering\s+|effort\s+)?hours\b",
        "effort-hours range — the plugin has no calibrated effort data and "
        "hour figures get pasted into budgets; communicate time as stage "
        "sequence + duration drivers (migration-complexity.md § Provenance)",
    ),
    (
        r"(?<!uncalibrated\):\s)(?<!uncalibrated\): )\b\d+\s*(?:–|-|to)\s*\d+\+?\s*weeks\b",
        'bare week-range estimate — durations are uncalibrated; either drop it '
        'or label it "Legacy planning heuristic (uncalibrated): N–M weeks"',
    ),
    (
        r"Section\s+0\b",
        'literal "Section 0" heading — drop numeric "Section N" prefixes from '
        "customer-facing headings; let the table of contents carry structure",
    ),
    (
        r"<h[1-6][^>]*>\s*Section\s+\d+[a-z]?\s*[—-]",
        'numbered "Section N —" heading — drop numeric prefixes from headings; '
        "let the table of contents carry structure",
    ),
    (
        r"\b(?:very|significantly|extremely|vastly)\b",
        "vague intensifier (very/significantly/extremely/vastly) — quantify the "
        'claim from artifact data instead ("-32% ($497/mo lower)"), or drop it',
    ),
    (
        r"\b\d{1,2}/\d{1,2}/\d{4}\b",
        "slash-format date (N/N/YYYY reads differently across locales) — use "
        "ISO YYYY-MM-DD for all dates",
    ),
]

# Visual readability contract for generated reports. This intentionally checks
# structural CSS capabilities rather than pixel-perfect declarations: agents
# may refine colors and spacing, but they must not regress to unboxed prose on
# a plain white page or uneven inline-block metric cards.
VISUAL_CONTRACT_CHECKS = [
    (
        r"body\s*\{[^}]*background\s*:\s*(?:var\([^)]*\)|#f6f8fa)",
        "body must use a contrasting page background",
    ),
    (
        r"\.(?:report|container)\s*\{[^}]*max-width\s*:",
        "report shell must constrain line length with max-width",
    ),
    (
        r"section\s*\{[^}]*background\s*:[^;}]+;?[^}]*border\s*:[^;}]+;?"
        r"[^}]*border-radius\s*:",
        "sections must render as bordered surface cards",
    ),
    (
        r"\.metrics\s*\{[^}]*display\s*:\s*grid[^}]*grid-template-columns\s*:",
        "executive metrics must use a responsive CSS grid",
    ),
    (
        r"\.metric\s*\{[^}]*border\s*:[^;}]+;?[^}]*border-radius\s*:",
        "metric cards must have a bordered card treatment",
    ),
    (
        r"\.verdict\s*\{[^}]*background\s*:[^;}]+;?[^}]*border\s*:",
        "recommendation must have a visually distinct callout treatment",
    ),
    (
        r"\.savings\s*\{[^}]*color\s*:",
        "supported savings values must have a reusable visual treatment",
    ),
    (
        r"\.appendix-header\s*\{",
        "full/decision shared shell must define an appendix divider",
    ),
    (
        r":focus-visible\s*\{",
        "keyboard focus must be visibly styled",
    ),
    (
        r"@media\s*\([^)]*max-width\s*:\s*700px[^)]*\)",
        "mobile readability breakpoint (700px) is required",
    ),
    (
        r"@media\s+print\s*\{",
        "print-specific styling is required",
    ),
]

# Executive-flow sections must speak the reader's language, not the system's.
# Artifact filenames and Terraform resource IDs are internal build vocabulary —
# they belong in the technical appendices, not the executive summary. (Enforced
# unless --no-readability.)
EXEC_SECTION_IDS = (
    "decision-summary",
    "exec-share",
    "exec-tco",
    "exec-services",
    "exec-costs",
    "exec-architecture",
    "exec-security-teaser",
    "exec-optimization",
    "what-if-scenarios",
    "exec-timeline",
    "exec-risks",
)

ARTIFACT_FILENAME_RE = re.compile(r"\b[a-z0-9][a-z0-9_-]*\.json\b", re.IGNORECASE)
TERRAFORM_RESOURCE_RE = re.compile(r"\baws_[a-z0-9_]+\.[a-z0-9_]+\b")

APPENDIX_STUB_PATTERNS = [
    re.compile(
        r'<section[^>]*id="appendix-costs"[^>]*>.*?Full artifacts:\s*<code>estimation-infra\.json</code>',
        re.DOTALL | re.IGNORECASE,
    ),
    re.compile(
        r'<section[^>]*id="appendix-services"[^>]*>\s*<p>\s*See\s*<code>aws-design\.json</code>',
        re.DOTALL | re.IGNORECASE,
    ),
]

MIN_CONTENT_DEPTH = {
    "appendix-costs": 3,
    "appendix-services": 2,
    "appendix-steps": 2,
}

SECTION_OPEN = re.compile(
    r"<section\b[^>]*\bid=(['\"])([^'\"]+)\1",
    re.IGNORECASE,
)

# Migration ID baked into the reference fixture. If this appears in a real
# $MIGRATION_DIR run, the agent copied the golden file verbatim (fixture bleed).
FIXTURE_CANARY_ID = "0611-0606"
MIGRATION_ID_RE = re.compile(r"\b(\d{4}-\d{4})\b")

# NOTE: _section_html uses non-greedy match to first </section>. This assumes
# sections are NOT nested. Do not nest <section> elements in migration reports.


def plugin_script_path() -> Path:
    """Return absolute path to this validator (for agent invocation)."""
    return Path(__file__).resolve()


def _section_html(html: str, section_id: str) -> str | None:
    pattern = re.compile(
        rf"<section\b[^>]*\bid=\"{re.escape(section_id)}\"[^>]*>(.*?)</section>",
        re.DOTALL | re.IGNORECASE,
    )
    match = pattern.search(html)
    return match.group(1) if match else None


def _section_id_counts(html: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for match in SECTION_OPEN.finditer(html):
        sid = match.group(2)
        counts[sid] = counts.get(sid, 0) + 1
    return counts


def _validate_required_sections(
    html: str, required_ids: list[str] | None = None
) -> list[str]:
    errors: list[str] = []
    counts = _section_id_counts(html)
    for section_id in required_ids if required_ids is not None else REQUIRED_SECTION_IDS:
        n = counts.get(section_id, 0)
        if n == 0:
            errors.append(f'missing required <section id="{section_id}">')
        elif n > 1:
            errors.append(f'duplicate <section id="{section_id}"> ({n} occurrences)')
    return errors


def _toc_hrefs(html: str) -> list[str]:
    nav_match = re.search(
        r"<nav\b[^>]*\bclass=[\"'][^\"']*toc[^\"']*[\"'][^>]*>(.*?)</nav>",
        html,
        re.DOTALL | re.IGNORECASE,
    )
    if not nav_match:
        return []
    return re.findall(r'href="#([^"]+)"', nav_match.group(1), re.IGNORECASE)


def _validate_toc(html: str, required_ids: list[str] | None = None) -> list[str]:
    if required_ids is None:
        required_ids = REQUIRED_SECTION_IDS
    errors: list[str] = []
    hrefs = _toc_hrefs(html)
    if not hrefs:
        return errors  # TOC optional if nav.toc absent; spec requires it in generated reports

    section_ids = set(_section_id_counts(html).keys())
    for href in hrefs:
        if href not in section_ids:
            errors.append(f'TOC broken link href="#{href}" — no matching <section id="{href}">')

    # Every required section must be linked from the TOC.
    for section_id in required_ids:
        if section_id in section_ids and section_id not in hrefs and hrefs:
            errors.append(
                f'TOC missing link to required section id="{section_id}" '
                f'(add <a href="#{section_id}">)'
            )
    return errors


def _validate_decision_first(html: str) -> list[str]:
    """The verdict is the report thesis and must precede navigation."""
    decision = re.search(
        r'<section\b[^>]*\bid=["\']decision-summary["\']',
        html,
        re.IGNORECASE,
    )
    toc = re.search(
        r'<nav\b[^>]*\bclass=["\'][^"\']*\btoc\b[^"\']*["\']',
        html,
        re.IGNORECASE,
    )
    if decision and toc and decision.start() > toc.start():
        return [
            "decision-summary must appear before the table of contents "
            "(show the report thesis before navigation)"
        ]
    return []


def _count_table_rows(section_html: str) -> int:
    tbody = re.search(r"<tbody>(.*?)</tbody>", section_html, re.DOTALL | re.IGNORECASE)
    if not tbody:
        return 0
    return len(re.findall(r"<tr\b", tbody.group(1), re.IGNORECASE))


def _section_content_depth(section_id: str, section_html: str) -> int:
    rows = _count_table_rows(section_html)
    if section_id == "appendix-services":
        clusters = len(re.findall(r'class="cluster-block"', section_html))
        return max(rows, clusters)
    if section_id == "appendix-steps":
        phases = len(re.findall(r"<h3>Phase\s+\d", section_html, re.IGNORECASE))
        return max(rows, phases)
    return rows


def _security_scoped_html(html: str) -> str:
    chunks: list[str] = []
    for sid in ("appendix-security", "appendix-costs", "exec-security-teaser"):
        part = _section_html(html, sid)
        if part:
            chunks.append(part)
    return "\n".join(chunks)


def _dollar_amount_present(amount: float | int, text: str) -> bool:
    """True when a dollar-formatted value appears in text (not bare CSS integers)."""
    normalized = text.replace(",", "")
    v = float(amount)
    candidates: list[str] = []
    if v == int(v):
        i = int(v)
        candidates.extend([f"${i}", f"${i}.00", f"${i}.0"])
    candidates.append(f"${v:.2f}")
    return any(c in normalized for c in candidates)


def _has_guardduty_or_baseline(html: str, estimation_infra: dict | None) -> tuple[bool, str]:
    scope = _security_scoped_html(html)
    if not scope:
        return False, "missing security content in appendix-security or appendix-costs sections"

    if re.search(r"GuardDuty", scope, re.IGNORECASE):
        return True, ""

    if not estimation_infra:
        return False, "missing GuardDuty mention in security/cost appendix sections"

    breakdown = estimation_infra.get("projected_costs", {}).get("breakdown", {})
    baseline = breakdown.get("security_baseline")
    if not baseline:
        return True, ""  # no baseline in estimate — nothing to cross-check

    components = baseline.get("components") or {}
    for _key, val in components.items():
        if val is not None and float(val) > 0 and _dollar_amount_present(val, scope):
            return True, ""

    return False, (
        "appendix-security/appendix-costs must mention GuardDuty or include dollar-formatted "
        "security_baseline component costs from estimation-infra.json "
        "(e.g. GuardDuty $13.00, CloudTrail $1.50)"
    )


def _readability_scope(html: str) -> str:
    """Body only, excluding <style> blocks so CSS class names like .rubric or
    selectors never trip the readability patterns."""
    no_style = re.sub(r"<style\b.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
    body = re.search(r"<body\b[^>]*>(.*?)</body>", no_style, re.DOTALL | re.IGNORECASE)
    return body.group(1) if body else no_style


def _validate_readability(html: str) -> list[str]:
    errors: list[str] = []
    scope = _readability_scope(html)
    for pattern, label in READABILITY_PATTERNS:
        if re.search(pattern, scope, re.IGNORECASE):
            errors.append(f"readability: {label}")
    return errors


def _validate_visual_contract(html: str) -> list[str]:
    """Validate the shared report shell's minimum visual readability contract."""
    style_blocks = re.findall(
        r"<style\b[^>]*>(.*?)</style>",
        html,
        re.DOTALL | re.IGNORECASE,
    )
    if not style_blocks:
        return ["visual readability: missing inline <style> report shell"]
    css = "\n".join(style_blocks)
    errors: list[str] = []
    for pattern, label in VISUAL_CONTRACT_CHECKS:
        if not re.search(pattern, css, re.DOTALL | re.IGNORECASE):
            errors.append(f"visual readability: {label}")
    return errors


def _validate_exec_vocabulary(html: str) -> list[str]:
    """Executive-flow sections must name what the reader controls, not how the
    system is built. Artifact filenames (*.json) and Terraform resource IDs
    (aws_<resource>.<name>) are internal vocabulary and belong in the technical
    appendices. Appendix sections are exempt by design."""
    errors: list[str] = []
    for sid in EXEC_SECTION_IDS:
        section = _section_html(html, sid)
        if not section:
            continue
        filenames = sorted(set(m.lower() for m in ARTIFACT_FILENAME_RE.findall(section)))
        resources = sorted(set(TERRAFORM_RESOURCE_RE.findall(section)))
        if filenames:
            errors.append(
                f'exec vocabulary: <section id="{sid}"> exposes artifact filename(s) '
                f"{filenames} — name what the reader controls in the executive flow; "
                "keep artifact filenames in the technical appendices"
            )
        if resources:
            errors.append(
                f'exec vocabulary: <section id="{sid}"> exposes Terraform resource ID(s) '
                f"{resources} — move resource names to the appendix; the executive flow "
                "names what the reader controls"
            )
    return errors


def _has_security_baseline(estimation_infra: dict | None) -> bool:
    if not estimation_infra:
        return False
    return bool(
        estimation_infra.get("projected_costs", {}).get("breakdown", {}).get("security_baseline")
    )


def _validate_security_teaser(html: str, estimation_infra: dict | None) -> list[str]:
    """When a security baseline exists, the executive flow must carry a compact
    teaser (exec-security-teaser) — not the full control table inline."""
    if not _has_security_baseline(estimation_infra):
        return []
    if _section_id_counts(html).get("exec-security-teaser", 0) >= 1:
        return []
    return [
        'security_baseline exists but no <section id="exec-security-teaser"> — keep a compact '
        "teaser in the executive flow and the full control table in appendix-security"
    ]


def _validate_action_lists(html: str) -> list[str]:
    """Key decisions ahead and Next steps must be ordered lists — actionable sequence."""
    errors: list[str] = []
    summary = _section_html(html, "decision-summary") or ""
    for heading in ("Key decisions ahead", "Next steps"):
        pattern = re.compile(
            rf"<h3[^>]*>\s*{re.escape(heading)}\s*</h3>\s*<(ul|ol)\b",
            re.IGNORECASE | re.DOTALL,
        )
        match = pattern.search(summary)
        if match and match.group(1).lower() == "ul":
            errors.append(
                f'decision-summary: "{heading}" must use <ol class="compact"> (ordered action '
                "items), not a bullet list"
            )
    return errors


def _validate_decision_language(
    html: str, estimation_infra: dict | None
) -> list[str]:
    """Keep whole-stack decisions distinct from track-scoped holds."""
    summary = _section_html(html, "decision-summary") or ""
    errors: list[str] = []
    recommendation = (estimation_infra or {}).get("recommendation") or {}
    has_stay_reasons = bool(recommendation.get("stay_if"))
    expected_heading_count = len(
        re.findall(
            r"<h[1-6][^>]*>\s*Stay\s+entirely\s+if\s*</h[1-6]>",
            summary,
            re.I,
        )
    )
    if has_stay_reasons and expected_heading_count != 1:
        errors.append(
            "decision-summary has recommendation.stay_if reasons and must contain "
            'exactly one "Stay entirely if" heading '
            f"(found {expected_heading_count})"
        )
    elif re.search(r"<h[1-6][^>]*>\s*Stay\s+if\s*</h[1-6]>", summary, re.I):
        errors.append(
            'decision-summary heading "Stay if" is ambiguous — use '
            '"Stay entirely if" for whole-stack reasons'
        )
    if re.search(r'class=["\'][^"\']*\bbadge-verdict-', summary, re.I):
        errors.append(
            "decision-summary must use a typography-first verdict headline and "
            "plain-text metadata, not badge-verdict-* pills"
        )
    return errors


OPTIMIZATION_EXEC_ID = "exec-optimization"
OPTIMIZATION_APPENDIX_ID = "appendix-optimization"
_SP_RE = re.compile(r"savings\s*plans?", re.I)
_RI_RE = re.compile(r"reserved\s+(?:instances?|capacity|nodes?)", re.I)
_COMMITMENT_SERVICE_RE = re.compile(
    r"\b(?:rds|aurora|fargate|lambda|elasticache|dynamodb|ec2)\b", re.I
)
_NON_STACK_RE = re.compile(
    r"(?:not\s+additive|do\s+not\s+add|already\s+embed|already\s+includes|"
    r"not\s+a\s+sum|already\s+assume)",
    re.I,
)


def _optimization_opportunities(
    estimation_infra: dict | None,
    estimation_ai: dict | None,
) -> list[dict]:
    rows: list[dict] = []
    for artifact in (estimation_infra, estimation_ai):
        if not artifact:
            continue
        for item in artifact.get("optimization_opportunities") or []:
            if isinstance(item, dict):
                rows.append(item)
    return rows


def _opp_blob(item: dict) -> str:
    targets = item.get("target_services")
    if isinstance(targets, list):
        target_text = " ".join(str(t) for t in targets)
    else:
        target_text = str(targets or "")
    return " ".join(
        [
            str(item.get("opportunity") or ""),
            str(item.get("type") or ""),
            str(item.get("description") or ""),
            target_text,
        ]
    )


def _has_optimization_columns(section: str) -> bool:
    """True if ANY <thead> in the section has the required columns.

    Section 3c allows a decision-mode exec-optimization to render a posture
    comparison table *and* the opportunity table in the same section. Only
    the opportunity table needs these columns — checking just the first
    <thead> rejects a valid report whenever the posture table (which has its
    own, different columns) happens to come first.
    """
    headers = re.findall(r"<thead\b[^>]*>(.*?)</thead>", section, re.DOTALL | re.IGNORECASE)
    for header in headers:
        text = unescape(re.sub(r"<[^>]+>", " ", header)).lower()
        if (
            "optimization" in text
            and "target" in text
            and "commitment" in text
            and "effort" in text
            and "saving" in text
        ):
            return True
    return False


def _table_rows_text(section: str) -> str:
    """Plain text from every <tbody> in a section — data rows only.

    Headings, explanatory prose, and links can legitimately say "Savings
    Plans and Reserved Instances" while the actual commitment-discount rows
    were removed. Presence checks for a specific product must look at
    rendered data, not surrounding copy.
    """
    bodies = re.findall(r"<tbody\b[^>]*>(.*?)</tbody>", section, re.DOTALL | re.IGNORECASE)
    if not bodies:
        return ""
    return unescape(re.sub(r"<[^>]+>", " ", " ".join(bodies)))


def _thead_has_optimization_columns(thead_html: str) -> bool:
    """True if this <thead> is the opportunity table's header (not the posture table)."""
    text = unescape(re.sub(r"<[^>]+>", " ", thead_html)).lower()
    return (
        "optimization" in text
        and "target" in text
        and "commitment" in text
        and "effort" in text
        and "saving" in text
    )


def _opportunity_table_optimization_cells(section: str) -> list[str]:
    """First-column (Optimization) text of each data row in the *opportunity* table.

    A Section 3c optimization section can carry two tables: a posture
    comparison (Balanced / Savings Plan / Optimized rows, whose cells and
    caveats name "Savings Plan") and the line-level opportunity table (the
    one with Optimization / Target / Commitment / Effort columns). Presence of
    a product must be proven by an opportunity row, so this isolates the
    table whose <thead> matches the required columns and returns the
    Optimization cell (first <td>) of every <tbody> data row. Posture rows,
    heading prose, and Optimized-tier caveats are therefore never counted, and
    an empty opportunity <tbody> yields no cells.
    """
    cells: list[str] = []
    for table in re.findall(r"<table\b[^>]*>(.*?)</table>", section, re.DOTALL | re.IGNORECASE):
        thead = re.search(r"<thead\b[^>]*>(.*?)</thead>", table, re.DOTALL | re.IGNORECASE)
        if not thead or not _thead_has_optimization_columns(thead.group(1)):
            continue
        for body in re.findall(r"<tbody\b[^>]*>(.*?)</tbody>", table, re.DOTALL | re.IGNORECASE):
            for row in re.findall(r"<tr\b[^>]*>(.*?)</tr>", body, re.DOTALL | re.IGNORECASE):
                first_cell = re.search(
                    r"<t[dh]\b[^>]*>(.*?)</t[dh]>", row, re.DOTALL | re.IGNORECASE
                )
                if first_cell:
                    cells.append(unescape(re.sub(r"<[^>]+>", " ", first_cell.group(1))).strip())
    return cells


def _opp_classification_blob(item: dict) -> str:
    """Text used ONLY to classify an opportunity as a Savings Plan / RI product.

    Deliberately excludes `description` and `target_services`: description is
    explanatory prose that can state a product does NOT apply (e.g. "Database
    Savings Plans do not cover ElastiCache for Redis OSS or Memcached"), which
    would otherwise get matched as evidence the artifact contains that
    product. Classification uses only the structured `opportunity` name and
    `type` (underscores normalized to spaces so `elasticache_reserved_nodes`
    matches the same regex as "ElastiCache Reserved Nodes").
    """
    type_text = str(item.get("type") or "").replace("_", " ")
    return f"{item.get('opportunity') or ''} {type_text}"


def _design_has_commitment_eligible(aws_design: dict | None) -> bool:
    if not aws_design:
        return False
    return bool(_COMMITMENT_SERVICE_RE.search(json.dumps(aws_design)))


def _opportunities_target_commitment_eligible(opportunities: list[dict]) -> bool:
    return any(_COMMITMENT_SERVICE_RE.search(_opp_blob(item)) for item in opportunities)


def _validate_optimization_sections(
    html: str,
    estimation_infra: dict | None,
    estimation_ai: dict | None,
    aws_design: dict | None,
    *,
    mode: str,
    require_toc: bool,
) -> list[str]:
    """Dedicated Cost Optimization section is required when Estimate emitted rows.

    A table buried only under appendix-costs is not enough — that is how
    Savings Plans / RI content was dropped from generated reports.
    """
    opportunities = _optimization_opportunities(estimation_infra, estimation_ai)
    if not opportunities:
        return []

    errors: list[str] = []
    counts = _section_id_counts(html)
    exec_n = counts.get(OPTIMIZATION_EXEC_ID, 0)
    appendix_n = counts.get(OPTIMIZATION_APPENDIX_ID, 0)

    if exec_n == 0:
        errors.append(
            "optimization_opportunities exist but no "
            f'<section id="{OPTIMIZATION_EXEC_ID}"> — render a standalone Cost '
            "Optimization section (Balanced on-demand vs Savings Plans / Reserved "
            "Instances). A table buried only in appendix-costs does not satisfy this gate"
        )
    elif exec_n > 1:
        errors.append(f'duplicate <section id="{OPTIMIZATION_EXEC_ID}"> ({exec_n} occurrences)')

    if mode == "full":
        if appendix_n == 0:
            errors.append(
                "optimization_opportunities exist but no "
                f'<section id="{OPTIMIZATION_APPENDIX_ID}"> — the opportunity table '
                "must be its own appendix section, not only a subsection of appendix-costs"
            )
        elif appendix_n > 1:
            errors.append(
                f'duplicate <section id="{OPTIMIZATION_APPENDIX_ID}"> ({appendix_n} occurrences)'
            )

    if require_toc:
        hrefs = _toc_hrefs(html)
        if hrefs:
            if exec_n and OPTIMIZATION_EXEC_ID not in hrefs:
                errors.append(
                    f'TOC missing link to required section id="{OPTIMIZATION_EXEC_ID}" '
                    f'(add <a href="#{OPTIMIZATION_EXEC_ID}">)'
                )
            if mode == "full" and appendix_n and OPTIMIZATION_APPENDIX_ID not in hrefs:
                errors.append(
                    f'TOC missing link to required section id="{OPTIMIZATION_APPENDIX_ID}" '
                    f'(add <a href="#{OPTIMIZATION_APPENDIX_ID}">)'
                )

    exec_html = _section_html(html, OPTIMIZATION_EXEC_ID) or ""
    appendix_html = _section_html(html, OPTIMIZATION_APPENDIX_ID) or ""
    table_scope = appendix_html if mode == "full" else exec_html
    if table_scope and not _has_optimization_columns(table_scope):
        where = OPTIMIZATION_APPENDIX_ID if mode == "full" else OPTIMIZATION_EXEC_ID
        errors.append(
            f"{where} table must include Optimization, Target, Monthly savings "
            "(or Est. savings), Commitment, and Effort columns"
        )

    if exec_html:
        if not re.search(r"balanced", exec_html, re.I):
            errors.append(
                "exec-optimization must compare commitment savings to the Balanced "
                "on-demand baseline"
            )
        if re.search(r"optimized", exec_html, re.I) and not _NON_STACK_RE.search(exec_html):
            errors.append(
                "exec-optimization mentions Optimized but does not warn that Savings "
                "Plans / RI savings are incremental to Balanced and must not be added "
                "on top of the Optimized tier"
            )

    # Classify using only the structured opportunity name/type — never
    # `description`, which can state a product does NOT apply (see
    # _opp_classification_blob docstring).
    has_sp_opp = any(_SP_RE.search(_opp_classification_blob(item)) for item in opportunities)
    has_ri_opp = any(_RI_RE.search(_opp_classification_blob(item)) for item in opportunities)

    # Presence in the report must be a rendered opportunity row, not a
    # heading, a caveat paragraph, or a posture-comparison row that merely
    # names the product. Bind the check to the opportunity table (identified
    # by its required columns) and read only its Optimization cells, so an
    # empty opportunity <tbody> or an Optimized-tier caveat cannot substitute
    # for an actual Savings Plan / RI option row. The opportunity table lives
    # in appendix-optimization (full mode) or exec-optimization (decision mode).
    opp_cells = _opportunity_table_optimization_cells(appendix_html) + (
        _opportunity_table_optimization_cells(exec_html)
    )
    opp_row_text = "\n".join(opp_cells)

    if has_sp_opp and not _SP_RE.search(opp_row_text):
        errors.append(
            "optimization_opportunities include a Savings Plan but the opportunity "
            "table (appendix-optimization / exec-optimization) has no Savings Plans "
            "data row — a heading, caveat, or posture-comparison row does not satisfy this gate"
        )
    if has_ri_opp and not _RI_RE.search(opp_row_text):
        errors.append(
            "optimization_opportunities include a Reserved Instance (or reserved "
            "capacity/nodes) but the opportunity table (appendix-optimization / "
            "exec-optimization) has no Reserved Instances data row — a heading, caveat, "
            "or posture-comparison row does not satisfy this gate"
        )
    if (
        not has_sp_opp
        and not has_ri_opp
        and (
            _design_has_commitment_eligible(aws_design)
            or _opportunities_target_commitment_eligible(opportunities)
        )
        and not (_SP_RE.search(opp_row_text) or _RI_RE.search(opp_row_text))
    ):
        errors.append(
            "RDS, Aurora, Fargate, or Lambda is in the design (or opportunity targets) "
            "but the opportunity table has no Savings Plans or Reserved Instances row"
        )

    return errors


def _validate_share_section(
    html: str,
    estimation_infra: dict | None,
    estimation_ai: dict | None,
) -> list[str]:
    """A copy-ready leadership brief is required when estimates are available."""
    if estimation_infra is None and estimation_ai is None:
        return []
    section = _section_html(html, "exec-share")
    if section is None:
        return [
            "monthly estimation artifacts exist but no <section id=\"exec-share\"> "
            "copy-ready leadership brief was rendered"
        ]
    errors: list[str] = []
    card = re.search(
        r'<(?P<tag>div|aside)\b[^>]*class=["\'][^"\']*\bshare-card\b[^"\']*["\'][^>]*>'
        r"(?P<body>.*?)</(?P=tag)>",
        section,
        re.I | re.DOTALL,
    )
    if not card:
        errors.append('exec-share must contain a class="share-card" decision brief')
        return errors
    paragraphs = re.findall(
        r"<p\b[^>]*>(.*?)</p>", card.group("body"), re.I | re.DOTALL
    )
    if len(paragraphs) != 1:
        errors.append(
            "exec-share share-card must contain exactly one standalone <p> "
            f"(found {len(paragraphs)})"
        )
    else:
        text = unescape(re.sub(r"<[^>]+>", " ", paragraphs[0]))
        word_count = len(re.findall(r"\b[\w'-]+\b", text))
        if word_count < 20:
            errors.append(
                "exec-share share-card paragraph must contain a substantive "
                f"copy-ready brief of at least 20 words (found {word_count})"
            )
    if re.search(r"<(?:button|script|input|textarea)\b", section, re.I):
        errors.append(
            "exec-share must be a static copy-ready paragraph without buttons, "
            "scripts, or editable controls"
        )
    return errors


def _validate_appendix_config(html: str) -> list[str]:
    """When appendix-config is present, require provenance columns."""
    section = _section_html(html, "appendix-config")
    if not section:
        return []
    errors: list[str] = []
    if not re.search(r"<table\b", section, re.IGNORECASE):
        errors.append("appendix-config must contain an HTML table of configuration choices")
        return errors
    header = re.search(r"<thead\b.*?</thead>", section, re.DOTALL | re.IGNORECASE)
    if not header:
        errors.append("appendix-config table must have <thead> with column headers")
        return errors
    hdr_text = header.group(0).lower()
    if "question" not in hdr_text and "assumption" not in hdr_text:
        errors.append(
            'appendix-config table must include a "Question" or "Assumption" column (from preferences.prompt)'
        )
    if "consequence" not in hdr_text:
        errors.append(
            "appendix-config table must include a Design consequence column (from preferences.design_consequence)"
        )
    rows = _count_table_rows(section)
    if rows < 2:
        errors.append(f"appendix-config must have >=2 configuration rows (found {rows})")
    return errors


def _validate_verdict(html: str, estimation_infra: dict | None) -> list[str]:
    """When a recommendation block exists, the decision summary must state a
    one-sentence verdict in a visually distinct class="verdict" callout."""
    if not estimation_infra or not estimation_infra.get("recommendation"):
        return []
    summary = _section_html(html, "decision-summary") or ""
    if re.search(r'class="[^"]*\bverdict\b[^"]*"', summary, re.IGNORECASE):
        return []
    return [
        "recommendation block exists but decision-summary has no verdict banner "
        '(wrap the one-sentence recommendation in class="verdict")'
    ]


def _validate_activate_link(html: str) -> list[str]:
    """Keep the Activate action attached to its executive-summary benefit."""
    summary = _section_html(html, "decision-summary") or ""
    if not re.search(r"AWS\s+Activate|Activate\s+(?:Founders|Portfolio|credits)", summary, re.I):
        return []
    if re.search(
        r'href=["\']https://aws\.amazon\.com/startups/credits/?["\']',
        summary,
        re.IGNORECASE,
    ):
        return []
    return [
        "decision-summary mentions AWS Activate but has no clickable official "
        "apply link (https://aws.amazon.com/startups/credits/)"
    ]


def _validate_glossary_table(html: str) -> list[str]:
    """Full reports present terms and meanings in a scannable two-column table."""
    section = _section_html(html, "appendix-glossary")
    if section is None:
        return [
            'full report must include a dedicated <section id="appendix-glossary">'
        ]
    match = re.search(
        r'<table\b[^>]*class=["\'][^"\']*\bglossary-table\b[^"\']*["\'][^>]*>'
        r"(.*?)</table>",
        section,
        re.DOTALL | re.IGNORECASE,
    )
    if not match:
        return [
            'full report glossary must use <table class="glossary-table"> '
            "with distinct Term and Meaning cells"
        ]
    table = match.group(1)
    header = re.search(r"<thead\b[^>]*>(.*?)</thead>", table, re.DOTALL | re.I)
    if not header or not re.search(r">\s*Term\s*<", header.group(1), re.I) or not re.search(
        r">\s*Meaning\s*<", header.group(1), re.I
    ):
        return ['glossary-table must have "Term" and "Meaning" column headers']
    if _count_table_rows(f"<table>{table}</table>") < 3:
        return ["glossary-table must contain at least 3 term-definition rows"]
    return []


def _validate_accessibility(html: str) -> list[str]:
    """Dependency-free checks for high-value WCAG-oriented HTML semantics."""
    errors: list[str] = []
    if not re.search(r"<html\b[^>]*\blang=[\"'][a-z]{2}(?:-[A-Za-z0-9]+)?[\"']", html, re.I):
        errors.append('accessibility: <html> must declare a valid lang attribute')

    body = re.sub(r"<style\b.*?</style>", "", html, flags=re.I | re.S)
    if len(re.findall(r"<h1\b", body, re.I)) != 1:
        errors.append("accessibility: report must contain exactly one <h1>")

    for index, table_match in enumerate(re.finditer(r"<table\b[^>]*>.*?</table>", body, re.I | re.S), 1):
        table = table_match.group(0)
        if not re.search(r"<caption\b", table, re.I):
            errors.append(f"accessibility: table {index} must include a <caption>")
        for th in re.findall(r"<th\b[^>]*>", table, re.I):
            if not re.search(r"\bscope=[\"'](?:col|row)[\"']", th, re.I):
                errors.append(
                    f'accessibility: table {index} header cells must declare scope="col" or scope="row"'
                )
                break

    for index, figure_match in enumerate(
        re.finditer(r"<figure\b[^>]*>.*?</figure>", body, re.I | re.S), 1
    ):
        figure = figure_match.group(0)
        opening = re.match(r"<figure\b[^>]*>", figure, re.I)
        opening_tag = opening.group(0) if opening else ""
        if not re.search(r'\brole=["\']img["\']', opening_tag, re.I):
            errors.append(f'accessibility: figure {index} must declare role="img"')
        if not re.search(r'\baria-label=["\'][^"\']+["\']', opening_tag, re.I):
            errors.append(f"accessibility: figure {index} must have an aria-label")
        if not re.search(r"<figcaption\b", figure, re.I):
            errors.append(f"accessibility: figure {index} must include a <figcaption>")
    return errors


def _validate_fixture_bleed(html: str, migration_dir: Path | None) -> list[str]:
    """Catch agents that copied the reference fixture verbatim into a real run.

    Only active when --migration-dir is passed (i.e. validating a real
    $MIGRATION_DIR report, not the fixture itself). Fails if the fixture canary
    ID appears, or if the report's stated migration ID does not match the run dir.
    """
    if migration_dir is None:
        return []  # fixture-self-exemption: no run dir → don't flag the canary

    errors: list[str] = []
    dir_name = migration_dir.name
    body = _readability_scope(html)

    if FIXTURE_CANARY_ID in body and dir_name != FIXTURE_CANARY_ID:
        errors.append(
            f'fixture bleed: reference canary migration ID "{FIXTURE_CANARY_ID}" appears in a '
            f'real run (--migration-dir={dir_name}) — the report was copied from the fixture'
        )

    ids_in_report = {m.group(1) for m in MIGRATION_ID_RE.finditer(body)}
    if re.fullmatch(r"\d{4}-\d{4}", dir_name) and ids_in_report and dir_name not in ids_in_report:
        errors.append(
            f'migration ID mismatch: report references {sorted(ids_in_report)} but '
            f"--migration-dir is {dir_name} — verify the report belongs to this run"
        )
    return errors


def validate_report(
    html: str,
    estimation_infra: dict | None = None,
    estimation_ai: dict | None = None,
    aws_design: dict | None = None,
    *,
    require_toc: bool = True,
    check_readability: bool = True,
    migration_dir: Path | None = None,
    mode: str = "full",
) -> list[str]:
    errors: list[str] = []

    required_ids = DECISION_REQUIRED_SECTION_IDS if mode == "decision" else REQUIRED_SECTION_IDS
    errors.extend(_validate_required_sections(html, required_ids))

    if mode == "decision":
        # No Generate artifacts exist at decision time: appendices are forbidden.
        counts = _section_id_counts(html)
        for sid in counts:
            if sid.startswith("appendix-"):
                errors.append(
                    f'decision mode forbids <section id="{sid}"> — the decision report '
                    "has no appendices; the full migration report (Generate) carries them"
                )

    if require_toc:
        if not _toc_hrefs(html):
            errors.append('missing <nav class="toc"> with href="#section-id" links')
        errors.extend(_validate_toc(html, required_ids))
        errors.extend(_validate_decision_first(html))

    for pattern, label in FORBIDDEN_PATTERNS:
        if re.search(pattern, html, re.IGNORECASE):
            errors.append(f"forbidden content: {label}")

    if check_readability:
        errors.extend(_validate_readability(html))
        errors.extend(_validate_exec_vocabulary(html))
        errors.extend(_validate_decision_language(html, estimation_infra))
        # Normal generated reports require a TOC. Use the same signal to
        # enforce the visual shell while preserving --no-require-toc as the
        # lightweight escape hatch for deliberately minimal unit fixtures.
        if require_toc:
            errors.extend(_validate_visual_contract(html))
    # Accessibility semantics are independent of prose/readability checks.
    # --no-require-toc remains the deliberate escape hatch for minimal unit
    # fixtures, but --no-readability must never disable HTML accessibility.
    if require_toc:
        errors.extend(_validate_accessibility(html))

    for section_id, min_depth in MIN_CONTENT_DEPTH.items():
        section = _section_html(html, section_id)
        if section is None:
            continue
        depth = _section_content_depth(section_id, section)
        if depth < min_depth:
            errors.append(
                f"appendix section id={section_id} has insufficient content ({depth}), "
                f"need >= {min_depth}"
            )

    for stub in APPENDIX_STUB_PATTERNS:
        if stub.search(html):
            errors.append(
                "appendix appears to be a stub (links to JSON only) — "
                "expand per generate-artifacts-report.md"
            )

    if "draft for review" not in html.lower():
        errors.append('footer must contain "draft for review" disclaimer')

    if estimation_infra and estimation_infra.get("projected_costs", {}).get("breakdown", {}).get(
        "security_baseline"
    ):
        ok, msg = _has_guardduty_or_baseline(html, estimation_infra)
        if not ok:
            errors.append(msg)

    # Combined AWS monthly run-rate section required only when BOTH estimate
    # artifacts exist (not AI-only runs). exec-tco is a legacy structural ID.
    if estimation_infra is not None and estimation_ai is not None:
        counts = _section_id_counts(html)
        if counts.get("exec-tco", 0) != 1:
            errors.append(
                "when both estimation-infra.json and estimation-ai.json exist, "
                'include exactly one <section id="exec-tco"> with the combined '
                "infra+AI estimated AWS monthly run rate"
            )

    # Security teaser must exist in the exec flow when a baseline is estimated.
    errors.extend(_validate_security_teaser(html, estimation_infra))

    # Decision summary must state a one-sentence verdict when a recommendation exists.
    errors.extend(_validate_verdict(html, estimation_infra))
    errors.extend(_validate_activate_link(html))
    if require_toc:
        errors.extend(_validate_share_section(html, estimation_infra, estimation_ai))
    if mode == "full" and require_toc:
        errors.extend(_validate_glossary_table(html))

    # Ordered action lists and configuration provenance (when sections present).
    errors.extend(_validate_action_lists(html))
    errors.extend(_validate_appendix_config(html))

    # Dedicated Cost Optimization section when Estimate emitted opportunities.
    errors.extend(
        _validate_optimization_sections(
            html,
            estimation_infra,
            estimation_ai,
            aws_design,
            mode=mode,
            require_toc=require_toc,
        )
    )

    # Catch verbatim copies of the reference fixture into a real run.
    errors.extend(_validate_fixture_bleed(html, migration_dir))

    # What-if workshop scenario table — required when ≥2 scenarios were snapshotted.
    if migration_dir is not None:
        index_path = migration_dir / "scenarios" / "index.json"
        if index_path.is_file():
            try:
                index = json.loads(index_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                index = None
            scenarios = (index or {}).get("scenarios") or []
            counts = _section_id_counts(html)
            if len(scenarios) >= 2 and counts.get("what-if-scenarios", 0) < 1:
                errors.append(
                    'scenarios/index.json has ≥2 scenarios but no '
                    '<section id="what-if-scenarios"> (workshop compare table is '
                    "required in the migration report when variants exist)"
                )

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate migration-report.html")
    parser.add_argument("report_path", type=Path, help="Path to migration-report.html")
    parser.add_argument("--estimation-infra", type=Path, default=None)
    parser.add_argument("--estimation-ai", type=Path, default=None)
    parser.add_argument(
        "--aws-design",
        type=Path,
        default=None,
        help="aws-design.json. When RDS/Aurora/Fargate/Lambda is in the design, "
        "the Cost Optimization section must include a Savings Plan or Reserved "
        "Instance row if optimization_opportunities exist.",
    )
    parser.add_argument(
        "--migration-dir",
        type=Path,
        default=None,
        help="Migration output dir ($MIGRATION_DIR). Enables fixture-bleed detection: "
        "the report's migration ID must match this folder, and the reference fixture's "
        "canary ID must not appear in a real run.",
    )
    parser.add_argument(
        "--no-require-toc",
        action="store_true",
        help="Skip TOC requirement (for minimal test fixtures)",
    )
    parser.add_argument(
        "--no-readability",
        action="store_true",
        help="Skip customer-facing readability checks (Rubric:/Section N/intensifiers/dates)",
    )
    parser.add_argument(
        "--mode",
        choices=["full", "decision"],
        default="full",
        help="full = migration-report.html (default); decision = decision-report.html "
        "written at the post-Estimate Decision gate (exec sections + CTA, no appendices)",
    )
    args = parser.parse_args()

    if not args.report_path.is_file():
        print(f"REPORT_FAIL | file={args.report_path} | reason=not_found", file=sys.stderr)
        return 1

    html = args.report_path.read_text(encoding="utf-8")

    estimation_infra = None
    if args.estimation_infra and args.estimation_infra.is_file():
        estimation_infra = json.loads(args.estimation_infra.read_text(encoding="utf-8"))

    estimation_ai = None
    if args.estimation_ai and args.estimation_ai.is_file():
        estimation_ai = json.loads(args.estimation_ai.read_text(encoding="utf-8"))

    aws_design = None
    if args.aws_design and args.aws_design.is_file():
        aws_design = json.loads(args.aws_design.read_text(encoding="utf-8"))

    errors = validate_report(
        html,
        estimation_infra,
        estimation_ai,
        aws_design,
        require_toc=not args.no_require_toc,
        check_readability=not args.no_readability,
        migration_dir=args.migration_dir,
        mode=args.mode,
    )
    if errors:
        print("REPORT_FAIL | migration-report.html", file=sys.stderr)
        for err in errors:
            print(f"  - {err}", file=sys.stderr)
        return 1

    counts = _section_id_counts(html)
    optional_present = [sid for sid in OPTIONAL_SECTION_IDS if counts.get(sid, 0) >= 1]
    required_count = len(
        DECISION_REQUIRED_SECTION_IDS if args.mode == "decision" else REQUIRED_SECTION_IDS
    )
    mode_tag = "" if args.mode == "full" else f"mode={args.mode} | "
    print(
        f"REPORT_OK | {mode_tag}structure=complete | sections="
        + str(required_count)
        + f"/{required_count}"
        + (f" | optional={','.join(optional_present)}" if optional_present else "")
        + " | note=verify dollar figures against estimation JSON before sign-off"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
