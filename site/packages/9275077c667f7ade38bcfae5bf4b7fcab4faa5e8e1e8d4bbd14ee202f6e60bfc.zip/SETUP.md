---
name: setup
description: Connect the Botify plugin, or explain why it cannot be connected. Use when the user installs or first activates it, when a Botify tool fails to authenticate, or when the user asks how to get access.
---

# Connecting Botify

The Botify tools read and act on a customer's own data in the Botify platform: their crawls, their
log files, their Search Console history, their projects. Access therefore requires a Botify account
on a plan that includes agent access. There is no free tier, trial, or demo dataset reachable this
way, and no API key to paste — everything goes through the user's own Botify sign-in.

Establish which of the three situations below applies before making any Botify tool call.

## The user has a Botify account

Nothing needs configuring. The first Botify tool call opens Botify's sign-in in the browser, the
user authorizes the connection once, and the tools work from then on. Clients register themselves
automatically, so there is no client ID, secret, or callback URL for the user to obtain.

If the sign-in never appears, or a call keeps failing to authenticate, have the user remove and
re-add the Botify connection from their client's plugin or connector settings, which restarts the
authorization from scratch.

## The user does not have a Botify account

Say so plainly and early — do not attempt tool calls hoping one succeeds, and do not offer to work
around the requirement. Explain that this plugin connects to the Botify platform and needs a Botify
subscription, then point them to Botify to talk to the team:

https://www.botify.com/platform/activation/botify-mcp?utm_source=ai-platform&utm_medium=referral&utm_campaign=botify-mcp-ai-agent&utm_content=skill

Then offer to help with what you can do without Botify data, rather than leaving the conversation
on a dead end.

## Sign-in works, but the tools return nothing

Two causes, and they need different people:

- **No projects are visible.** The account is real but has no access to any Botify project. The
  user's own Botify administrator grants that.
- **Calls are refused even though projects exist.** Agent access can be switched off for an entire
  Botify account, and only Botify can switch it back on. Give them the support address,
  help@botify.com.

In both cases the plugin and the connection are fine, so suggest the administrator rather than
proposing a reinstall.
