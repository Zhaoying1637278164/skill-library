# Botify plugins for AI agents

Ask your AI agent about your site the way you'd ask a colleague — which pages Google is crawling,
where traffic is slipping, what's worth fixing first — and get answers straight from your crawls,
log files, and Search Console history.

## What you can ask

- Which pages does Google crawl but not index?
- Where has organic traffic dropped most in the last 30 days?
- Which page templates are wasting the most crawl budget?
- What keywords does this URL rank for, and which ones are close to page 1?
- Draft a better title and description for these pages, and push it to Botify.

That last one is the point: the agent can act on what it finds, not just report it back.

## Install

**Claude Code**

```shell
/plugin marketplace add botify-hq/ai-plugins
/plugin install botify@botify
```

**Claude Cowork** — *Customize → Plugins → Add marketplace*, enter `botify-hq/ai-plugins`, then
install **Botify** from the list.

**Cursor** — *Customize → Install plugin from source*, using this repository's git URL.

**GitHub Copilot / VS Code** — run **Chat: Install Plugin From Source** and pass this repository's
git URL.

**ChatGPT / Codex** — install **Botify** from the plugin directory once the listing is published.

Since Claude Chat doesn't use plugins, add the Botify MCP from the Connectors directory instead.

When installed, just ask a question about your site, and the LLM will guide you through signing in
the first time.

## What you need

Access to a [Botify](https://www.botify.com) project, other than Guest collaborators. Not a Botify
customer yet? [Talk to us](https://www.botify.com/platform/activation/botify-mcp?utm_source=github&utm_medium=referral&utm_campaign=botify-mcp-marketplace&utm_content=readme).

## Signing in, and what the agent can reach

You sign in with your own Botify account the first time the agent needs it. You log in as usual, and
that's it — nothing to set up in advance.

Everything runs through Botify's server at `https://mcp.botify.com`. The agent reaches the same
projects, data, and permissions, and can write on-page changes to Botify when you ask. Your Botify
administrator can disable agent access for the whole account.

## What's in the package

| Component | Status |
| --- | --- |
| Connection to Botify | ✅ Available now |
| Skills — ready-made workflows | ✅ Available now |

More skills arrive in later releases. Nothing to reinstall or reconfigure — your agent picks them up
on its own.

The package carries a manifest in each client's own format. This enables the same repository to
install cleanly in every LLM (e.g., Claude, Cursor, Copilot), with no per-client variant to choose.

## Something not working?

Found a bug or want a workflow the plugin doesn't cover? Write to help@botify.com.

## License

Apache License 2.0 — see [LICENSE](LICENSE).

"Botify" and the Botify logo are trademarks of Botify, and the licence grants no permission to use
them (see section 6). Fork the package and adapt it freely; ship it under a name that is yours.
