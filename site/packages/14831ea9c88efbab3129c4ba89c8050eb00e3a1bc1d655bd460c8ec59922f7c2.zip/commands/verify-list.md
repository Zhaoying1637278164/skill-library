---
name: verify-list
description: Clean an email list with ClearBounce — extract addresses from a file, verify them in bulk, and report which ones are safe to send to.
---

Clean the email list the user pointed at: $ARGUMENTS

Follow the `email-verification` skill's list-cleaning workflow:

1. Read the file (CSV, spreadsheet export, or plain text). Extract addresses, normalise and de-duplicate them, and tell the user the unique count.
2. State the cost (1 credit per unique address). If the list has more than 500 addresses, call `check_credits` first and stop if the balance is insufficient (point to https://clearbounce.net/pricing).
3. Ask for confirmation before spending credits.
4. Start `verify_bulk` (split into jobs of at most 10,000). Poll `check_bulk_status` with pauses until each job completes.
5. Report the summary — deliverable / undeliverable / risky / unknown / catch-all — and what share of the list should be removed.
6. If the user wants a cleaned file, point them to the `resultsUrl` from `check_bulk_status` to download the full results as CSV. Once they tell you where the file is, write new files next to the original (`<name>.clean.csv`, `<name>.risky.csv`, `<name>.remove.csv`). Never overwrite the original file, and do not look for an API key on the user's machine to fetch results yourself.

Do not paste the full address list into the conversation.
