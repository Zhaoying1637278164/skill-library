---
name: email-verification
description: Verify email addresses or clean an email list with ClearBounce. Use when the user asks whether an address is valid/deliverable, wants to clean, validate or de-bounce a list (CSV, spreadsheet, text), wants to find someone's business email, or asks about their ClearBounce credits.
---

# Email verification with ClearBounce

ClearBounce checks whether an address will actually accept mail: syntax, MX records, a live mailbox check, disposable/role/catch-all detection and typo suggestions. It is exposed through the `clearbounce` MCP server bundled with this plugin.

## Tools (MCP server `clearbounce`)

| Tool | Cost | Use for |
|---|---|---|
| `verify_email` | 1 credit | One address, immediate result |
| `verify_bulk` | 1 credit per unique address | 2–10,000 addresses as one background job |
| `check_bulk_status` | free | Progress + summary of a bulk job |
| `find_email` | free (verification of candidates costs 1 credit each) | Business email from full name + company domain |
| `check_credits` | free | Remaining balance |

If a tool returns 401 / "not authenticated", tell the user to run `/mcp` and connect the `clearbounce` server (OAuth login; new accounts get free credits). An API key from https://clearbounce.net/dashboard/api-keys also works.

## Result statuses

- **deliverable** — mailbox exists and accepts mail. Safe to send.
- **undeliverable** — does not exist / rejected / invalid domain or syntax. Remove from the list.
- **risky** — mail may or may not arrive: catch-all domain, disposable provider, role address (info@, sales@), low quality. Keep in a separate segment; do not treat as clean.
- **unknown** — the mail server did not answer in time. Not a rejection. Re-verify later before deleting.

`subStatus`/`reason` explains why (e.g. `rejected_email`, `invalid_domain`, `low_deliverability`, `unavailable_smtp`). `score` is 0–100.

## Workflow: single address

1. Call `verify_email`.
2. Report status, reason, score and the checks that matter (disposable, role, catch-all, typo suggestion). One or two sentences — no raw JSON unless asked.
3. Mention `creditsRemaining` only when it is low or the user asks.

## Workflow: cleaning a list

1. **Extract** the addresses from the file (CSV column, spreadsheet, plain text). Trim whitespace, lowercase the domain part, drop empty rows and obvious non-emails, and de-duplicate. Tell the user how many unique addresses you found.
2. **Confirm cost before verifying**: unique count = credits. Check the balance with `check_credits` if the list is large; if credits are short, give https://clearbounce.net/pricing (pay-as-you-go from $4 per 1,000, credits never expire).
3. **Run** `verify_bulk` with the unique addresses (max 10,000 per job; split larger lists into several jobs). Never loop `verify_email` over a list — bulk is cheaper in time and more accurate.
4. **Poll** `check_bulk_status` with the `jobId`. Typical jobs take 1–10 minutes; wait between polls instead of hammering it.
5. **Report** the summary: deliverable / undeliverable / risky / unknown / catch-all counts and the estimated share of the list that should not be mailed. Do not paste every address back.
6. **Per-address results** (needed to write a cleaned file) are not returned by the MCP tools. When the job completes, `check_bulk_status` returns a `resultsUrl`: the dashboard page where the user downloads the full result file. When the user wants a cleaned CSV, ask them to download it as CSV and tell you where it is, then write a new file (never overwrite the original) with a `status` column, or split into `clean.csv`, `risky.csv`, `remove.csv`. Do not look for an API key on the user's machine to fetch the results yourself.

## Workflow: finding a business email

1. Call `find_email` with the full name and company domain. It is free and returns pattern-based candidates ordered by confidence, plus any addresses already published at that domain.
2. Show the candidates and say that confirming one costs 1 credit per check. Ask before verifying.
3. With approval, `verify_email` the candidates one at a time from the highest confidence and stop at the first `deliverable`. Report how many were checked and the credits used.

## Rules

- Never invent a verification result. If a tool fails, say so.
- Never send test messages to addresses; verification is passive.
- Verify only lists the user has a legitimate right to mail. Refuse scraped or purchased lists that clearly belong to third parties.
- Keep results private: do not echo full lists into chat, commit them, or post them anywhere.
- Never read ClearBounce API keys from the user's environment or files. The MCP tools sign in with OAuth and need no key.
