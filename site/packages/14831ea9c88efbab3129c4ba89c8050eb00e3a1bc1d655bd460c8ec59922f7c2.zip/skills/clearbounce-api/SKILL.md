---
name: clearbounce-api
description: Integrate ClearBounce email verification into code — signup forms, checkout flows, CRM syncs, batch jobs. Use when the user wants to call the ClearBounce REST API, needs the endpoint/response shapes, wants to test without spending credits (sandbox keys), or asks how to handle verification results in their app.
---

# ClearBounce REST API

Base URL `https://clearbounce.net` (alias `https://api.clearbounce.net`). Auth header on every call: `X-API-Key: <key>`. Keys are created in Dashboard → API. Full reference: https://docs.clearbounce.net — machine-readable spec: https://clearbounce.net/openapi.json (fetch it when you need exact schemas).

## Endpoints

| Method | Path | Purpose | Cost |
|---|---|---|---|
| POST | `/api/v1/verify` | Verify one address — body `{"email": "..."}` | 1 credit |
| POST | `/api/v1/bulk/upload` | Start a batch — body `{"emails": ["...", ...]}` (1–10,000) | 1 credit per unique address |
| GET | `/api/v1/bulk/status/{jobId}` | Progress + summary counts | free |
| GET | `/api/v1/bulk/results/{jobId}` | Full per-address results | free |
| GET | `/api/v1/credits` | Remaining balance | free |

### Single verification response

```json
{
  "success": true,
  "data": {
    "email": "jane@example.com",
    "status": "deliverable",        // deliverable | undeliverable | risky | unknown
    "subStatus": "accepted_email",
    "reason": "Mailbox accepted the address",
    "score": 95,                    // 0-100
    "isDeliverable": true,
    "toxicity": 0,                  // 0-5
    "checks": { "syntax": true, "mxRecords": true, "isDisposable": false, "isRoleBased": false, "isCatchAll": false, "hasTypo": false },
    "riskFactors": []
  },
  "creditsRemaining": 999
}
```

Errors: `401` bad or missing key, `402` `INSUFFICIENT_CREDITS` (send the user to https://clearbounce.net/pricing), `400` validation. On any other failure or a timeout, retry once with backoff and fail open.

### Batch flow

`POST /api/v1/bulk/upload` returns `jobId`, `totalEmails`, `duplicateCount`, `estimatedTimeSeconds`. Poll `GET /api/v1/bulk/status/{jobId}` every 10–30 s until `job.status` is `completed` or `failed`; the status object carries `progress` and the deliverable/undeliverable/risky/unknown/catchAll counts. Then `GET /api/v1/bulk/results/{jobId}` for the per-address array (same shape as `data` above).

## Recommended handling in an app

- **Signup / checkout (real time):** call `/verify`; block `undeliverable`; accept `deliverable`; for `risky` and `unknown` accept but flag (or ask the user to double-check the address). Use a short timeout and fail open — never block signup because the verifier was unreachable.
- **Typo suggestions:** when `checks.hasTypo` is true, offer the suggested domain ("Did you mean gmail.com?") instead of rejecting.
- **List hygiene (batch):** suppress `undeliverable`, segment `risky`, re-verify `unknown` after a day or two.
- **Caching:** a result is good for weeks for most domains; don't re-verify the same address on every request.
- Keep the API key server-side. Never ship it in browser or mobile code; proxy through your backend.

## API keys and this skill

This skill is for code that runs in the user's own application; the key belongs in that application's server-side secret configuration, and the code you write should receive it from there. Never search the user's machine (environment variables, dotfiles, config files) for a ClearBounce key, and never send a key the user did not give you for that call. Inside Claude, verification goes through the ClearBounce MCP tools, which sign in with OAuth and need no key.

## Sandbox — test without spending credits

Create a **Test (Sandbox)** key in Dashboard → API. Test keys start with `cb_test_`, never consume credits, return `"sandbox": true`, and work only on `/verify` and `/credits`. The result is chosen by the local part of the address (anything else → `deliverable`):

| Local part | Result |
|---|---|
| `undeliverable@`, `invalid@` | undeliverable, `rejected_email` |
| `invalid-domain@`, `nomx@` | undeliverable, `invalid_domain` |
| `invalid-syntax@` | undeliverable, `invalid_syntax` |
| `disabled@`, `fullmailbox@` | undeliverable with account flags |
| `risky@`, `low-quality@` | risky, `low_quality` |
| `catch-all@`, `catchall@` | risky, `isCatchAll: true` |
| `disposable@` | risky, `isDisposable: true` |
| `role@` | risky, `isRoleBased: true` |
| `unknown@` | unknown |
| `timeout@` | unknown, `unavailable_smtp` |
| `insufficient-credits@` | HTTP 402 |
| `typo@` | deliverable with a typo suggestion |

Plus-addressing works too: `jane+risky@example.com` → risky. Use the sandbox in unit tests and CI; in production, switch to a live key stored in the app's server-side secret configuration.

## Example (Node.js)

```js
// Runs on your server. `apiKey` comes from your app's server-side secret configuration.
async function verifyEmail(email, apiKey) {
  const res = await fetch('https://clearbounce.net/api/v1/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
    body: JSON.stringify({ email }),
  });
  if (res.status === 402) throw new Error('Out of ClearBounce credits');
  const { data } = await res.json();
  return data; // reject data.status === 'undeliverable'; see "Recommended handling" above
}
```

Other clients: official WordPress plugin, Zapier, Make, n8n, Postman collection and the MCP server for AI assistants — see https://clearbounce.net/integrations.
