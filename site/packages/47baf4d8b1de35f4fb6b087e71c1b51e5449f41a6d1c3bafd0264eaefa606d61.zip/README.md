# LivingMeeting for Claude, ChatGPT, and Codex

LivingMeeting is the AI-native meeting room. This official plugin connects your
AI agents to the meetings, agendas, transcripts, artifacts, and action items
your team already shares in LivingMeeting.

The package works with Claude and Codex, and provides the same MCP server and
skill used by the LivingMeeting listing for ChatGPT. It contains no passwords,
API keys, or workspace data.

## What you can do

- Find meetings by title, topic, tag, project, or transcript text.
- Read agendas, transcripts, summaries, artifacts, and pinned work.
- Review open and completed action items across meetings.
- Create meetings and update their titles, times, and agendas.
- Carry meeting context into the AI tools your team already uses.

## Install in Claude

Add the public marketplace and install the plugin from Claude Code:

```text
/plugin marketplace add pgerlich/livingmeeting-plugin
/plugin install livingmeeting@livingmeeting
```

Start a new Claude session after installation so the skill and MCP connection
load from the plugin cache.

## Install in Codex

Add the public marketplace and install the plugin:

```sh
codex plugin marketplace add pgerlich/livingmeeting-plugin
codex plugin add livingmeeting@livingmeeting
```

The ChatGPT listing is installed from the ChatGPT plugin directory after its
marketplace approval.

## Connect your workspace

The first request that needs LivingMeeting opens the LivingMeeting OAuth flow.
Sign in, choose the workspace you want to use, and approve access. OAuth keeps
the selected workspace scoped to your connection. You do not need to copy an
API key into the plugin.

The production MCP endpoint is:

```text
https://livingmeeting.com/api/mcp
```

## Try it

- Show me my open action items from recent meetings.
- Find the meeting where we discussed the launch date.
- Summarize my latest project update meeting.
- Add the pricing review to Thursday's agenda without removing existing topics.

## Safety behavior

The bundled skill tells the agent to read a meeting before changing it, resolve
ambiguous meeting names, preserve existing agenda topics, avoid duplicate agenda
items, verify agenda replacements, and confirm destructive meeting deletion.

## Package contents

- `.claude-plugin/plugin.json` identifies the Claude plugin.
- `.codex-plugin/plugin.json` identifies the Codex plugin and listing assets.
- `.mcp.json` connects both hosts to the production MCP server.
- `skills/livingmeeting/SKILL.md` provides safe meeting workflows.
- `.claude-plugin/marketplace.json` makes the repository a Claude marketplace.
- `.agents/plugins/marketplace.json` makes the repository a Codex marketplace.

## Documentation and support

- [Setup guide](https://livingmeeting.com/docs/ai-agents)
- [Support](https://livingmeeting.com/support)
- [Security](https://livingmeeting.com/security)
- [Privacy policy](https://livingmeeting.com/privacy)
- [Terms of service](https://livingmeeting.com/terms)

Copyright 2026 LivingMeeting. Released under the MIT License.
