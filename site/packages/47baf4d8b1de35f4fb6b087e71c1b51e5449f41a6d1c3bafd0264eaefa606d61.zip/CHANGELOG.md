# Changelog

All notable changes to the LivingMeeting plugin are documented here.

## 1.1.1 - 2026-07-16

- Replaced the obsolete marketplace wordmark with the current terracotta
  LivingMeeting pulse mark.
- Removed the obsolete logo asset from the universal plugin package.

## 1.1.0 - 2026-07-16

- Published one universal package for Claude, ChatGPT, and Codex.
- Added OAuth-backed access to the full LivingMeeting MCP server.
- Added safe workflows for meetings, agendas, transcripts, summaries,
  artifacts, pinned items, and action items.
- Added read-before-write, agenda preservation, duplicate prevention, and
  deletion confirmation guidance.
- Added marketplace metadata, public product assets, and reviewer materials.

## 1.0.0

- Introduced the LivingMeeting remote MCP connector.
