---
name: livingmeeting
description: Work with the user's authenticated LivingMeeting workspace through the LivingMeeting MCP server. Use when the user asks to find or review meetings, agendas, transcripts, summaries, artifacts, pinned items, or action items, or asks to create, update, delete, or set the agenda for a LivingMeeting meeting.
---

# LivingMeeting

Use the LivingMeeting MCP tools to retrieve meeting context and make requested changes in the user's current workspace.

## Choose the right tool

- Use `list_meetings` to browse recent meetings or filter by status or project.
- Use `search_meetings` to find meetings by a topic, title, tag, or transcript text.
- Use `get_meeting` for the complete meeting record, including agenda, participants, and accepted action items.
- Use `get_agenda`, `get_transcript`, `get_summary`, or `get_artifacts` when the user asks for one specific part of a meeting.
- Use `list_action_items` for outstanding work or ownership questions across meetings.
- Use `list_pinned_items` for charts, notes, questions, and actions saved to the workspace library.
- Use `create_meeting`, `update_meeting`, `delete_meeting`, and `set_agenda` only for an explicitly requested change.

## Work safely

1. Resolve the meeting before acting. Search or list meetings first when the user has not supplied a meeting ID.
2. Ask a concise clarification when more than one meeting reasonably matches.
3. Read the current record before updating it.
4. Treat `set_agenda` as a full replacement. Read the existing agenda and preserve any item the user did not ask to remove.
5. Compare agenda topic text case-insensitively before adding a topic. Do not create a duplicate, and read the agenda again after replacement to verify the final list.
6. Confirm the exact meeting immediately before `delete_meeting` unless the user explicitly requested that deletion in the current turn.
7. Report the completed change and include the meeting title and scheduled time when available.

## Compose useful answers

- Lead with the answer, not raw tool output.
- Keep speaker names attached to transcript statements.
- Separate decisions, open questions, and action items when summarizing.
- Include the source meeting for action items and pinned content.
- Never invent a participant, owner, meeting ID, date, or transcript statement.
- If a tool returns `Meeting not found`, search within the workspace and ask the user to choose when needed.

## Example requests

- "What action items are still open from the Acme meetings?"
- "Find the meeting where we discussed the launch date and summarize the decision."
- "Create a project update meeting next Tuesday with an agenda for risks, milestones, and owners."
- "Add the pricing review to Thursday's agenda without removing the existing topics."
