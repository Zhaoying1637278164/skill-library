//! `mergify stack squash <SRC>... into <TARGET> [-m <msg>]
//! [--dry-run]` — combine several commits into a target.
//!
//! Port of `mergify_cli/stack/squash.py::stack_squash`. Reorders
//! every SRC adjacent to TARGET and rewrites the SRC verbs as
//! `fixup` (so they fold without opening an editor and TARGET's
//! message survives). When `-m` is given, the new combined
//! message is applied via an `exec git commit --amend -F <file>`
//! line inserted right after the last fixed-up commit — same
//! tempfile-leak pattern as `stack reword -m`.

use std::io::Write;
use std::path::{Path, PathBuf};

use mergify_core::CliError;

use crate::change_id;
use crate::git::{resolve_repo_toplevel, run_git_capture, shell_quote, spawn_rebase};
use crate::local_commits::{self, LocalCommit};
use crate::plan_display::PlanRow;
use crate::trunk;

#[derive(Debug, Clone, PartialEq, Eq)]
struct OrderedCommit {
    sha: String,
    subject: String,
    change_id: String,
}

#[derive(Debug, Clone)]
pub enum Outcome {
    /// Squash ran to completion. `plan` is the reordered full stack
    /// (sources folded behind the target) with `[fixup]` tags on
    /// the source rows.
    Squashed {
        plan: Vec<PlanRow>,
    },
    /// `--dry-run` short-circuit. Same full-stack `plan`, no rebase.
    DryRun {
        plan: Vec<PlanRow>,
    },
    EmptyStack,
}

pub struct Options<'a> {
    pub repo_dir: Option<&'a Path>,
    pub src_prefixes: &'a [String],
    pub target_prefix: &'a str,
    pub message: Option<&'a str>,
    pub dry_run: bool,
    pub mergify_binary: &'a Path,
}

pub fn run(opts: &Options<'_>) -> Result<Outcome, CliError> {
    if opts.src_prefixes.is_empty() {
        return Err(CliError::InvalidState(
            "at least one source commit required".to_string(),
        ));
    }
    let repo_dir = resolve_repo_toplevel(opts.repo_dir)?;
    let trunk = trunk::get_trunk(Some(&repo_dir)).map_err(|e| {
        CliError::StackNotFound(format!(
            "could not determine trunk branch ({e}). Please set \
             upstream tracking or set a base manually."
        ))
    })?;
    let base = run_git_capture(Some(&repo_dir), &["merge-base", &trunk.refspec(), "HEAD"])?;
    let commits = local_commits::read(&repo_dir, &base, "HEAD")?;
    if commits.is_empty() {
        return Ok(Outcome::EmptyStack);
    }

    let target = match_commit(opts.target_prefix, &commits)?;

    let mut srcs: Vec<OrderedCommit> = Vec::with_capacity(opts.src_prefixes.len());
    let mut seen_src = std::collections::HashSet::new();
    for prefix in opts.src_prefixes {
        let matched = match_commit(prefix, &commits)?;
        if matched.sha == target.sha {
            return Err(CliError::InvalidState(
                "a source commit cannot be the same as the target".to_string(),
            ));
        }
        if !seen_src.insert(matched.sha.clone()) {
            return Err(CliError::InvalidState(format!(
                "duplicate — source prefix '{prefix}' resolves to the same commit as another"
            )));
        }
        srcs.push(matched);
    }

    // Build new order: non-src commits in their original order,
    // with the src list reinserted immediately after target.
    let src_sha_set: std::collections::HashSet<&str> =
        srcs.iter().map(|s| s.sha.as_str()).collect();
    let mut new_order: Vec<OrderedCommit> = Vec::with_capacity(commits.len());
    for c in &commits {
        if src_sha_set.contains(c.commit_sha.as_str()) {
            continue;
        }
        new_order.push(OrderedCommit {
            sha: c.commit_sha.clone(),
            subject: c.title.clone(),
            change_id: c.change_id.clone(),
        });
        if c.commit_sha == target.sha {
            new_order.extend(srcs.iter().cloned());
        }
    }

    let plan: Vec<PlanRow> = new_order
        .iter()
        .map(|c| PlanRow {
            sha: c.sha.clone(),
            subject: c.subject.clone(),
            change_id: c.change_id.clone(),
            action: src_sha_set
                .contains(c.sha.as_str())
                .then(|| "fixup".to_string()),
        })
        .collect();

    if opts.dry_run {
        return Ok(Outcome::DryRun { plan });
    }

    let ordered_shas: Vec<String> = new_order.iter().map(|c| c.sha.clone()).collect();
    let fixup_shas: Vec<String> = srcs.iter().map(|s| s.sha.clone()).collect();
    let (exec_after_sha, exec_command) = if let Some(msg) = opts.message {
        let msg_path = write_temp_message(msg)?;
        let command = format!(
            "git commit --amend -F {}",
            shell_quote(&msg_path.to_string_lossy())
        );
        let last_src = srcs.last().expect("non-empty validated above").sha.clone();
        (Some(last_src), Some(command))
    } else {
        (None, None)
    };

    spawn_squash_rebase(
        &repo_dir,
        &base,
        opts.mergify_binary,
        &ordered_shas,
        &fixup_shas,
        exec_after_sha.as_deref(),
        exec_command.as_deref(),
    )?;
    Ok(Outcome::Squashed { plan })
}

fn match_commit(prefix: &str, commits: &[LocalCommit]) -> Result<OrderedCommit, CliError> {
    let (matches, field): (Vec<&LocalCommit>, &str) = if change_id::is_prefix(prefix) {
        (
            commits
                .iter()
                .filter(|c| c.change_id.starts_with(prefix))
                .collect(),
            "Change-Id",
        )
    } else {
        (
            commits
                .iter()
                .filter(|c| c.commit_sha.starts_with(prefix))
                .collect(),
            "SHA",
        )
    };
    match matches.as_slice() {
        [] => Err(crate::match_commit::not_found(field, prefix)),
        [only] => Ok(OrderedCommit {
            sha: only.commit_sha.clone(),
            subject: only.title.clone(),
            change_id: only.change_id.clone(),
        }),
        many => {
            let candidates: Vec<crate::match_commit::Candidate<'_>> = many
                .iter()
                .map(|c| crate::match_commit::Candidate {
                    commit_sha: &c.commit_sha,
                    title: &c.title,
                    change_id: &c.change_id,
                })
                .collect();
            Err(crate::match_commit::ambiguous(field, prefix, &candidates))
        }
    }
}

fn write_temp_message(message: &str) -> Result<PathBuf, CliError> {
    let mut tmp = tempfile::Builder::new()
        .prefix("mergify_squash_msg_")
        .suffix(".txt")
        .tempfile()
        .map_err(|e| CliError::Generic(format!("create squash tempfile: {e}")))?;
    tmp.write_all(message.as_bytes())
        .map_err(|e| CliError::Generic(format!("write squash tempfile: {e}")))?;
    tmp.flush()
        .map_err(|e| CliError::Generic(format!("flush squash tempfile: {e}")))?;
    let (_, path) = tmp
        .keep()
        .map_err(|e| CliError::Generic(format!("persist squash tempfile: {e}")))?;
    Ok(path)
}

fn spawn_squash_rebase(
    repo_dir: &Path,
    base: &str,
    mergify_binary: &Path,
    ordered_shas: &[String],
    fixup_shas: &[String],
    exec_after_sha: Option<&str>,
    exec_command: Option<&str>,
) -> Result<(), CliError> {
    let bin = shell_quote(&mergify_binary.to_string_lossy());
    let ordered = shell_quote(&ordered_shas.join(","));
    let fixup = shell_quote(&fixup_shas.join(","));
    let mut editor = format!(
        "{bin} _internal rebase-todo-rewrite --action squash --shas {ordered} --fixup-shas {fixup}"
    );
    if let (Some(after), Some(cmd)) = (exec_after_sha, exec_command) {
        editor.push_str(" --sha ");
        editor.push_str(&shell_quote(after));
        editor.push_str(" --command ");
        editor.push_str(&shell_quote(cmd));
    }
    spawn_rebase(repo_dir, base, Some(&editor), false)
}
