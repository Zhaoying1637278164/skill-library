//! Resolve `--token`, `--api-url`, and `--repository` with the
//! same fallback order the Python CLI used.
//!
//! Token: `--token` flag → `MERGIFY_TOKEN` env → `GITHUB_TOKEN`
//! env → `gh auth token` (the GitHub CLI). Mirrors Python's
//! `utils.get_default_token`.
//!
//! That one chain feeds two unrelated services: the Mergify API
//! ([`resolve_mergify_token`]) and, for the `stack` command group,
//! the GitHub REST API ([`resolve_github_token`]). They resolve
//! identically today and are still two functions, because only one
//! of them is going to grow — the Mergify side gains the credential
//! `mergify auth login` stores and deprecates the two GitHub
//! fallbacks, while `stack` keeps sending GitHub exactly what it
//! sends it now. A single resolver could not do one without doing
//! the other.
//!
//! Repository: `--repository` flag → `GITHUB_REPOSITORY` env →
//! `git config --get remote.origin.url` parsed into `<owner>/<repo>`.
//! Mirrors Python's `utils.get_default_repository` + `utils.get_slug`.
//!
//! API URL: `--api-url` flag → `MERGIFY_API_URL` env → default
//! `https://api.mergify.com`.
//!
//! Each ported command resolves these once before doing any
//! network or interactive work. The Rust copies that previously
//! lived in `mergify-config::simulate`, `mergify-ci::scopes_send`,
//! and `mergify-queue::auth` were missing the `gh auth token` and
//! `git config` fallbacks — that's why this module exists.

use std::process::Command;

use url::Url;

use crate::CliError;
use crate::env::var_non_empty;

const DEFAULT_API_URL: &str = "https://api.mergify.com";

/// Resolve the bearer token for **Mergify API** calls.
///
/// Precedence: explicit `--token`, then `MERGIFY_TOKEN`, then
/// `GITHUB_TOKEN`, then the output of `gh auth token`. Errors when
/// none of those produce a non-empty value.
pub fn resolve_mergify_token(explicit: Option<&str>) -> Result<String, CliError> {
    resolve_token_chain(explicit)
}

/// Resolve the bearer token for **GitHub REST** calls — the
/// `ApiFlavor::GitHub` client the `stack` command group talks to
/// `api.github.com` with.
///
/// Same precedence as [`resolve_mergify_token`]: explicit
/// `--token`, then `MERGIFY_TOKEN`, then `GITHUB_TOKEN`, then the
/// output of `gh auth token`.
pub fn resolve_github_token(explicit: Option<&str>) -> Result<String, CliError> {
    resolve_token_chain(explicit)
}

/// The shared `--token` → `MERGIFY_TOKEN` → `GITHUB_TOKEN` →
/// `gh auth token` chain both resolvers currently answer with.
fn resolve_token_chain(explicit: Option<&str>) -> Result<String, CliError> {
    if let Some(value) = explicit.filter(|s| !s.is_empty()) {
        return Ok(value.to_string());
    }
    for env_name in ["MERGIFY_TOKEN", "GITHUB_TOKEN"] {
        if let Some(value) = var_non_empty(env_name) {
            return Ok(value);
        }
    }
    if let Ok(token) = gh_auth_token()
        && !token.is_empty()
    {
        return Ok(token);
    }
    Err(CliError::Configuration(
        "please set the 'MERGIFY_TOKEN' or 'GITHUB_TOKEN' environment variable, \
         or make sure that the gh client is installed and you are authenticated"
            .to_string(),
    ))
}

/// Resolve the Mergify API base URL. Falls back to the
/// `MERGIFY_API_URL` env var, then the default
/// `https://api.mergify.com`.
pub fn resolve_api_url(explicit: Option<&str>) -> Result<Url, CliError> {
    let raw = explicit
        .filter(|s| !s.is_empty())
        .map(str::to_string)
        .or_else(|| var_non_empty("MERGIFY_API_URL"))
        .unwrap_or_else(|| DEFAULT_API_URL.to_string());
    Url::parse(&raw).map_err(|e| CliError::Configuration(format!("invalid --api-url {raw:?}: {e}")))
}

/// Resolve the repository (`<owner>/<repo>`).
///
/// Precedence: explicit `--repository`, then `GITHUB_REPOSITORY`
/// env, then `git config --get remote.origin.url` parsed via
/// [`parse_slug`]. Errors when none of those yield a slug.
pub fn resolve_repository(explicit: Option<&str>) -> Result<String, CliError> {
    if let Some(value) = explicit.filter(|s| !s.is_empty()) {
        return Ok(value.to_string());
    }
    if let Some(value) = var_non_empty("GITHUB_REPOSITORY") {
        return Ok(value);
    }
    if let Some(slug) = repository_from_git_remote() {
        return Ok(slug);
    }
    Err(CliError::Configuration(
        "--repository not provided, GITHUB_REPOSITORY env var is unset, and \
         the local git config has no usable `remote.origin.url`"
            .to_string(),
    ))
}

/// Repository slug (`<owner>/<repo>`) parsed from the local
/// `git config --get remote.origin.url`, or `None` when the working
/// tree isn't a git repo or has no usable `remote.origin.url`.
///
/// Exposed so `mergify-ci`'s CI-aware resolver can share the same
/// git-remote fallback instead of reimplementing it.
#[must_use]
pub fn repository_from_git_remote() -> Option<String> {
    parse_slug(&git_remote_origin_url()?)
}

/// Run `gh auth token` and return stdout (trimmed). Returns an
/// `Err` when `gh` is missing or the command fails, which the
/// caller treats as "no token from gh".
fn gh_auth_token() -> Result<String, std::io::Error> {
    let output = Command::new("gh").args(["auth", "token"]).output()?;
    if !output.status.success() {
        return Err(std::io::Error::other("`gh auth token` exited non-zero"));
    }
    let token = String::from_utf8(output.stdout)
        .map_err(|e| std::io::Error::other(format!("`gh auth token` non-UTF-8 output: {e}")))?
        .trim()
        .to_string();
    Ok(token)
}

/// Run `git config --get remote.origin.url` in the current
/// directory and return stdout (trimmed). Returns `None` when git
/// isn't available, the working tree isn't a git repo, or the
/// remote isn't configured.
fn git_remote_origin_url() -> Option<String> {
    let output = Command::new("git")
        .args(["config", "--get", "remote.origin.url"])
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let value = String::from_utf8(output.stdout).ok()?.trim().to_string();
    (!value.is_empty()).then_some(value)
}

/// Parse a git remote URL into `<owner>/<repo>`.
///
/// Handles both HTTPS (`https://github.com/owner/repo.git`) and
/// SSH (`git@github.com:owner/repo.git`) shapes; `.git` suffix and
/// trailing slashes are stripped. Returns `None` when the URL
/// doesn't decompose into at least two path segments.
fn parse_slug(url: &str) -> Option<String> {
    let url = url.trim();

    // A scheme (`://`) means an HTTPS-style URL: the slug is the
    // path after the host. Anything without a scheme is treated
    // as the SSH form `git@host:owner/repo[.git]`: the slug is
    // whatever follows the first `:`.
    let path = if let Some(scheme_end) = url.find("://") {
        let after_scheme = &url[scheme_end + 3..];
        after_scheme.split_once('/')?.1.to_string()
    } else {
        let colon = url.find(':')?;
        url[colon + 1..].to_string()
    };

    let path = path.trim_end_matches('/').trim_start_matches('/');
    let (owner, rest) = path.split_once('/')?;
    let repo = rest
        .trim_end_matches('/')
        .strip_suffix(".git")
        .unwrap_or(rest);
    let repo = repo.trim_end_matches('/');
    if owner.is_empty() || repo.is_empty() {
        return None;
    }
    Some(format!("{owner}/{repo}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolve_mergify_token_prefers_explicit_over_env() {
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", Some("env-mergify")),
                ("GITHUB_TOKEN", Some("env-github")),
            ],
            || {
                assert_eq!(
                    resolve_mergify_token(Some("explicit-token")).unwrap(),
                    "explicit-token",
                );
            },
        );
    }

    #[test]
    fn resolve_mergify_token_falls_back_to_mergify_env() {
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", Some("env-mergify")),
                ("GITHUB_TOKEN", Some("env-github")),
            ],
            || {
                assert_eq!(resolve_mergify_token(None).unwrap(), "env-mergify");
            },
        );
    }

    #[test]
    fn resolve_mergify_token_falls_back_to_github_env_when_mergify_unset() {
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", None),
                ("GITHUB_TOKEN", Some("env-github")),
            ],
            || {
                assert_eq!(resolve_mergify_token(None).unwrap(), "env-github");
            },
        );
    }

    #[test]
    fn resolve_mergify_token_error_message_mentions_gh() {
        // When env vars are unset and `gh auth token` is unavailable
        // (or fails), the user-facing error must mention the gh
        // fallback so the user knows there's a third option.
        // Forcing PATH to a directory with no `gh` keeps the test
        // hermetic on machines that do have the GitHub CLI installed.
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", None),
                ("GITHUB_TOKEN", None),
                ("PATH", Some("/nonexistent-directory-for-test")),
            ],
            || {
                let err = resolve_mergify_token(None).unwrap_err();
                let msg = err.to_string();
                assert!(msg.contains("MERGIFY_TOKEN"), "got {msg:?}");
                assert!(msg.contains("gh client"), "got {msg:?}");
            },
        );
    }

    // The GitHub resolver is what `stack` sends to `api.github.com`.
    // Pinning its whole chain here — rather than asserting it equals
    // whatever the Mergify one returns — is the point: the two
    // diverge on the Mergify side, and this test has to keep failing
    // if that divergence ever reaches the GitHub side.
    #[test]
    fn resolve_github_token_prefers_explicit_over_env() {
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", Some("env-mergify")),
                ("GITHUB_TOKEN", Some("env-github")),
            ],
            || {
                assert_eq!(
                    resolve_github_token(Some("explicit-token")).unwrap(),
                    "explicit-token",
                );
            },
        );
    }

    #[test]
    fn resolve_github_token_falls_back_to_mergify_env() {
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", Some("env-mergify")),
                ("GITHUB_TOKEN", Some("env-github")),
            ],
            || {
                assert_eq!(resolve_github_token(None).unwrap(), "env-mergify");
            },
        );
    }

    #[test]
    fn resolve_github_token_falls_back_to_github_env_when_mergify_unset() {
        temp_env::with_vars(
            [
                ("MERGIFY_TOKEN", None),
                ("GITHUB_TOKEN", Some("env-github")),
            ],
            || {
                assert_eq!(resolve_github_token(None).unwrap(), "env-github");
            },
        );
    }

    #[test]
    fn resolve_api_url_default() {
        temp_env::with_var("MERGIFY_API_URL", None::<&str>, || {
            let url = resolve_api_url(None).unwrap();
            assert_eq!(url.as_str(), "https://api.mergify.com/");
        });
    }

    #[test]
    fn resolve_api_url_prefers_explicit() {
        temp_env::with_var("MERGIFY_API_URL", Some("https://from-env.example/"), || {
            let url = resolve_api_url(Some("https://explicit.example/")).unwrap();
            assert_eq!(url.as_str(), "https://explicit.example/");
        });
    }

    #[test]
    fn resolve_api_url_uses_env_var_when_explicit_empty() {
        temp_env::with_var("MERGIFY_API_URL", Some("https://from-env.example/"), || {
            let url = resolve_api_url(None).unwrap();
            assert_eq!(url.as_str(), "https://from-env.example/");
        });
    }

    #[test]
    fn resolve_api_url_rejects_garbage() {
        temp_env::with_var("MERGIFY_API_URL", None::<&str>, || {
            let err = resolve_api_url(Some("not a url")).unwrap_err();
            assert!(err.to_string().contains("invalid --api-url"));
        });
    }

    #[test]
    fn resolve_repository_prefers_explicit() {
        temp_env::with_var("GITHUB_REPOSITORY", Some("owner-from-env/repo"), || {
            assert_eq!(
                resolve_repository(Some("explicit/repo")).unwrap(),
                "explicit/repo",
            );
        });
    }

    #[test]
    fn resolve_repository_falls_back_to_env() {
        temp_env::with_var("GITHUB_REPOSITORY", Some("owner/repo"), || {
            assert_eq!(resolve_repository(None).unwrap(), "owner/repo");
        });
    }

    #[test]
    fn parse_slug_https_with_dot_git() {
        assert_eq!(
            parse_slug("https://github.com/owner/repo.git").as_deref(),
            Some("owner/repo"),
        );
    }

    #[test]
    fn parse_slug_https_without_dot_git() {
        assert_eq!(
            parse_slug("https://github.com/owner/repo").as_deref(),
            Some("owner/repo"),
        );
    }

    #[test]
    fn parse_slug_https_with_trailing_slash() {
        assert_eq!(
            parse_slug("https://github.com/owner/repo/").as_deref(),
            Some("owner/repo"),
        );
    }

    #[test]
    fn parse_slug_ssh_form() {
        assert_eq!(
            parse_slug("git@github.com:owner/repo.git").as_deref(),
            Some("owner/repo"),
        );
    }

    #[test]
    fn parse_slug_ssh_without_dot_git() {
        assert_eq!(
            parse_slug("git@github.com:owner/repo").as_deref(),
            Some("owner/repo"),
        );
    }

    #[test]
    fn parse_slug_rejects_empty_owner() {
        assert!(parse_slug("https://github.com//repo.git").is_none());
    }

    #[test]
    fn parse_slug_rejects_path_without_repo() {
        assert!(parse_slug("https://github.com/owner").is_none());
    }
}
