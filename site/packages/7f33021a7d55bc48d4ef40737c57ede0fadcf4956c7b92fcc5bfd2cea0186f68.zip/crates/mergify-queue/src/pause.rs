//! `mergify queue pause` — pause the merge queue for a repository.
//!
//! PUTs ``{"reason": "..."}`` to
//! ``/v1/repos/<repo>/merge-queue/pause``. Prints a "⚠  Queue
//! paused" confirmation with the reason (and a coarse relative
//! "since" delta if the API returned a pause timestamp).
//!
//! Confirmation flow:
//!
//! - ``--yes-i-am-sure`` skips the prompt.
//! - Interactive (TTY): asks "Proceed? [y/N]"; anything other than
//!   "y"/"yes" aborts with a generic error.
//! - Non-interactive (no TTY, no ``--yes-i-am-sure``): refuses with
//!   an ``INVALID_STATE`` error matching Python's behavior.

use std::io::IsTerminal;
use std::io::Write;

use chrono::Utc;
use mergify_core::CliError;
use mergify_core::CommandContext;
use mergify_core::Output;
use mergify_tui::relative_time;
use serde::Deserialize;
use serde::Serialize;

const MAX_REASON_LEN: usize = 255;

pub struct PauseOptions<'a> {
    pub repository: Option<&'a str>,
    pub token: Option<&'a str>,
    pub api_url: Option<&'a str>,
    pub reason: &'a str,
    pub yes_i_am_sure: bool,
}

/// Clap value-parser for the positional `--reason` flag.
///
/// # Errors
///
/// Returns a message when `value` exceeds 255 user-visible
/// characters. We count via [`str::chars`] (Unicode scalar values)
/// rather than [`str::len`] (UTF-8 bytes), so non-ASCII reasons
/// such as `"déploiement"` aren't rejected for being below 255
/// chars but above 255 bytes.
pub fn parse_reason(value: &str) -> Result<String, String> {
    if value.chars().count() > MAX_REASON_LEN {
        Err("must be 255 characters or fewer".to_string())
    } else {
        Ok(value.to_string())
    }
}

#[derive(Serialize)]
struct PauseRequest<'a> {
    reason: &'a str,
}

#[derive(Deserialize)]
struct PauseResponse {
    // Both fields are optional defensively: the API has historically
    // tolerated `reason: null` (the deleted Python `QueuePauseResponse`
    // typed it as `str | None`), so the Rust port matches that
    // shape rather than aborting deserialization on a missing or
    // null value.
    #[serde(default)]
    reason: Option<String>,
    #[serde(default)]
    paused_at: Option<String>,
}

/// Run the `queue pause` command.
pub async fn run(opts: PauseOptions<'_>, output: &mut dyn Output) -> Result<(), CliError> {
    // Resolve auth/repo first so the prompt names the *actual* repo
    // (including the `GITHUB_REPOSITORY` fallback) and so a missing
    // repo or token fails loudly *before* we ask for confirmation.
    let ctx = CommandContext::resolve(opts.repository, opts.token, opts.api_url)?;

    confirm(
        opts.yes_i_am_sure,
        std::io::stdin().is_terminal(),
        &ctx.repository,
    )?;

    output.status(&format!(
        "Pausing merge queue for {repo}…",
        repo = ctx.repository,
    ))?;

    let client = ctx.mergify_client()?;
    let path = format!("/v1/repos/{}/merge-queue/pause", ctx.repository);
    let resp: PauseResponse = client
        .put(
            &path,
            &PauseRequest {
                reason: opts.reason,
            },
        )
        .await?;

    emit_confirmation(output, &resp)?;
    Ok(())
}

/// Decide whether to proceed with a destructive queue-pause.
///
/// `is_tty` is taken as a parameter (rather than read from
/// `std::io::stdin()` here) so unit tests can exercise the
/// non-TTY branch deterministically — `cargo test` happens to run
/// without a terminal stdin most of the time, but that's not
/// something we want to depend on, especially when developers run
/// `cargo test` from inside an interactive shell.
fn confirm(skip: bool, is_tty: bool, repository: &str) -> Result<(), CliError> {
    if skip {
        return Ok(());
    }
    if !is_tty {
        return Err(CliError::InvalidState(
            "refusing to pause without confirmation. Pass --yes-i-am-sure to proceed.".to_string(),
        ));
    }
    // Prompt goes to stderr (matches click's `confirm`/`prompt`
    // behavior) so users can pipe stdout cleanly without the
    // prompt text mixed in.
    let mut err = std::io::stderr().lock();
    write!(
        err,
        "You are about to pause the merge queue for {repository}. Proceed? [y/N]: ",
    )
    .map_err(CliError::from)?;
    err.flush().map_err(CliError::from)?;
    drop(err);

    let mut line = String::new();
    std::io::stdin()
        .read_line(&mut line)
        .map_err(CliError::from)?;
    match line.trim().to_ascii_lowercase().as_str() {
        "y" | "yes" => Ok(()),
        _ => Err(CliError::Generic("aborted by user".to_string())),
    }
}

fn emit_confirmation(output: &mut dyn Output, response: &PauseResponse) -> std::io::Result<()> {
    output.emit(&(), &mut |w: &mut dyn Write| {
        match &response.reason {
            Some(r) => write!(w, "⚠  Queue paused: \"{r}\"")?,
            None => write!(w, "⚠  Queue paused")?,
        }
        if let Some(ts) = &response.paused_at {
            let rel = relative_time(ts, Utc::now(), false);
            if !rel.is_empty() {
                write!(w, " (since {rel})")?;
            }
        }
        writeln!(w)
    })
}

#[cfg(test)]
mod tests {
    use mergify_test_support::Captured;
    use wiremock::Mock;
    use wiremock::MockServer;
    use wiremock::ResponseTemplate;
    use wiremock::matchers::body_json;
    use wiremock::matchers::header;
    use wiremock::matchers::method;
    use wiremock::matchers::path;

    use super::*;

    #[test]
    fn parse_reason_accepts_short() {
        assert_eq!(
            parse_reason("deploying hotfix").unwrap(),
            "deploying hotfix"
        );
    }

    #[test]
    fn parse_reason_rejects_over_255() {
        let long = "a".repeat(256);
        assert!(parse_reason(&long).is_err());
    }

    #[test]
    fn parse_reason_counts_chars_not_bytes() {
        // 200 user-visible characters but well above 255 *bytes*
        // because each `é` is a 2-byte UTF-8 sequence — we keep it.
        let multibyte = "é".repeat(200);
        assert!(multibyte.len() > MAX_REASON_LEN);
        assert!(multibyte.chars().count() <= MAX_REASON_LEN);
        assert!(parse_reason(&multibyte).is_ok());
    }

    #[test]
    fn confirm_refuses_without_yes_when_non_tty() {
        // Pass `is_tty = false` explicitly so the test exercises
        // the non-TTY branch without depending on the runtime
        // shape of `cargo test`'s stdin (which can be a TTY when
        // run from an interactive shell).
        let err = confirm(false, false, "owner/repo").unwrap_err();
        assert!(
            matches!(err, CliError::InvalidState(_)),
            "expected InvalidState, got {err:?}"
        );
        assert_eq!(err.exit_code(), mergify_core::ExitCode::InvalidState);
        assert!(
            err.to_string().contains("--yes-i-am-sure"),
            "message should mention the override flag, got: {err}"
        );
    }

    #[test]
    fn confirm_skips_when_yes_i_am_sure_is_set() {
        // `skip = true` must bypass the TTY check — it's the
        // contract of `--yes-i-am-sure`, including in CI where
        // stdin isn't a terminal. The `is_tty` value passed here
        // is irrelevant.
        confirm(true, false, "owner/repo").unwrap();
    }

    #[tokio::test]
    async fn run_pauses_and_prints_confirmation() {
        let server = MockServer::start().await;
        Mock::given(method("PUT"))
            .and(path("/v1/repos/owner/repo/merge-queue/pause"))
            .and(header("Authorization", "Bearer t"))
            .and(body_json(serde_json::json!({"reason": "deploy freeze"})))
            .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({
                "reason": "deploy freeze",
                "paused_at": "2026-04-23T12:34:56Z",
            })))
            .expect(1)
            .mount(&server)
            .await;

        let mut cap = Captured::human();
        let api_url = server.uri();
        run(
            PauseOptions {
                repository: Some("owner/repo"),
                token: Some("t"),
                api_url: Some(&api_url),
                reason: "deploy freeze",
                yes_i_am_sure: true,
            },
            &mut cap.output,
        )
        .await
        .unwrap();

        let stdout = cap.stdout();
        assert!(stdout.contains("⚠  Queue paused"), "got: {stdout:?}");
        assert!(stdout.contains("deploy freeze"), "got: {stdout:?}");
        // `paused_at` renders as a coarse relative delta (e.g.
        // "5m ago"), not the raw RFC-3339 timestamp.
        assert!(stdout.contains("(since "), "got: {stdout:?}");
        assert!(stdout.contains(" ago)"), "got: {stdout:?}");
        assert!(!stdout.contains("2026-04-23"), "got: {stdout:?}");
    }
}
