---
description: Review underwriting assumption controls for a deal — open, blocking, and IC-readiness state. Walks the middle-office assumption ledger that gates IC approval.
---

# Assumption Controls

Underwriting assumptions are first-class controls in OloLand. An analyst owns each statement, with a status (unverified / verified / mitigated / invalidated / accepted) and priority (low / medium / high / critical). Open high/critical tracked assumptions block IC approval; resolving them clears the gate.

This command walks the assumption ledger for a deal and reports the IC-blocker state.

## Usage

```
/assumption-controls <deal_id> [filter]
```

## Arguments

- `deal_id` (required) — The deal whose assumption controls to review.
- `filter` (optional) — `open` | `blocking` | `resolved` | `all`. Default: `blocking` (the IC-relevant subset).

## Execution

1. Call `get_assumption_control_summary` with the `deal_id`. This returns `total`, `open_count`, `resolved_count`, `blocking_count`, `ic_blocked`, `by_status`, `by_category`, and the top-10 `blocking_assumptions`.
2. If `ic_blocked` is true:
   - List each blocking assumption with statement, category, priority, status, owner, and sensitivity_score.
   - Group by category so the analyst can see where the gaps cluster.
3. Call `get_assumption_evidence_pack` to retrieve the evidence ledger and `quality_flags`. For each blocking assumption, surface its `evidence_strength` (none / weak / partial / supported) and any `missing_links`.
4. Call `list_deal_assumptions` with `priority=critical` and `priority=high` to verify nothing in the tracked-but-not-blocking state has been overlooked (e.g., suggested assumptions waiting to be promoted).
5. Render the result as a structured review:

   - **IC status**: Clear / Blocked (with count)
   - **Blockers**: table of `id`, `statement`, `category`, `priority`, `status`, `evidence_strength`, `missing_links`
   - **By category**: count of open assumptions per category (financial / commercial / operational / market / legal / regulatory / hr / technical / financing / growth / margin / capex / wacc / terminal / other)
   - **Recommended next actions**: for each blocker, the most concrete next step (verify with X document; mitigate via Y; mark accepted with a risk-acknowledgment note; invalidate if the underlying premise no longer holds).

## Status transitions

When the analyst is ready to resolve an assumption, call `set_assumption_status` with the `assumption_id`, the target `status` (`verified` / `mitigated` / `invalidated` / `accepted` / `unverified` to reopen), and an optional `note`. Allowed transitions:

| From | To |
|---|---|
| unverified | verified, mitigated, invalidated, accepted |
| verified | accepted, invalidated, unverified (reopen) |
| mitigated | accepted, invalidated, unverified (reopen) |
| invalidated | unverified (reopen only) |
| accepted | unverified (reopen only) |

Do NOT attempt other transitions — the service returns a validation error.

## Why this matters

Most AI tools generate analysis. OloLand also enforces the middle-office controls that turn analysis into an approved IC decision. Surfacing assumption state in chat — and letting the analyst transition it without leaving Cowork — is the workflow loop that competing AI assistants don't ship.

## Example

```
/assumption-controls deal_acme_2026 blocking
```

Returns: "IC BLOCKED — 3 open blockers (2 critical, 1 high). Critical: 'FY27 revenue growth of 22% requires entry into new geography' (status=unverified, evidence_strength=none, no commercial DD attached). Critical: 'Customer concentration <30% by closing' (status=unverified, evidence_strength=weak, conflicting source). High: 'Working-capital normalization $4M' (status=unverified, evidence_strength=partial). Recommended: schedule customer DD calls; pull most recent A/R aging; have CFO confirm WC bridge."

## Related commands

- `/ic-approve-readiness` — pre-flight check before attempting to approve an IC package
- `/risk-report` — separate surface for risk taxonomy, not assumption controls

## Output URL Conventions (STRICT)

Domain is `app.ololand.ai`. Surface for assumption controls:
- `https://app.ololand.ai/deals/{deal_id}/analysis/assumptions`
