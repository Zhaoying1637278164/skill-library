---
description: "Browse recent AI financial-services moves captured by OloNet's competitive scanner — competitor product launches, partner integrations, regulatory signals, pricing changes, personnel moves. Each move includes a source URL, signal strength, and the recommended OloLand response surface."
---

# /ai-finserv-moves

You are reading OloNet's persisted AI financial-services competitive-intel feed. Use this to pull recent context about competitors, partners, or the broader AI-in-finance market into a deal narrative, pitch deck, or strategy review.

## Required inputs

None — but the feed is large. Default to a filtered query.

Optional filters:
- **actor** — substring match on the actor name (e.g. `Anthropic`, `BlackRock`, `Sequoia`).
- **move_type** — `product_launch`, `partnership`, `regulatory`, `pricing`, `personnel`, etc.
- **workflow_surface** — `dd`, `cim`, `risk`, `valuation`, `pricing`, etc. — surface the move pertains to.
- **limit** — default 50, cap 200.
- **offset** — pagination.

## Action

Call `mcp__ololand__list_ai_finserv_moves` with the chosen filters.

## Output

Render in reverse-chronological order:

```
<n> AI finserv moves (filters: <filters>)

<collected_at>  <actor_name>
  Move type:    <move_type>
  Surface:      <workflow_surface>
  Signal:       <signal_strength>
  Source:       <source_url>
  Summary:      <summary or facts excerpt>
  Recommended:  <recommended_response>
...
```

If the user asks for a deeper look at one move, surface its full `extracted_facts` JSON and the source-record metadata.

## When to use

- Pre-meeting prep when a competitor or partner is on the agenda.
- Updating a `/compare` page when a competitor ships something new.
- Researching market context for a deal in a competitive segment.
- Adding live competitive color to a CIM, IC memo, or strategy deck.

## When NOT to use

- For *deal-specific* intel — use `mcp__ololand__research_market` or `mcp__ololand__deep_market_research`. This feed is firm-wide, not deal-scoped.
- For *historical* M&A deals — use `mcp__ololand__search_ma_deals` instead.
- For *real-time* breaking news — the feed is gateway-ingested with up-to-14-day freshness; for sub-day signal, route to OloNet directly.

## Ingestion is not exposed here

The matching ingest endpoint (`POST /api/ma/ai-finserv-moves/ingest`) is HMAC-keyed and reserved for the headless OloNet/OpenClaw gateway. There is no MCP write surface for new moves — feed corrections happen at the gateway, not via plugin. If a user sees a wrong move, ask them to flag it and route to the OloNet operator; do not attempt to mutate via MCP.

Companion skill: `cmd-ai-finserv-moves` (auto-loads).
