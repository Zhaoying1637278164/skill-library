---
description: "Queue a regulator export pack — a tarball of every agent_run + agent_spans + output_artifacts in a date window, mapped to a compliance framework's controls. Admin / compliance role required. The defensible-audit-trail deliverable."
---

# /regulator-export

You are queueing a compliance-framework export. The Celery task `tasks.regulator_export_tasks.generate_regulator_export` builds a tarball with:

- Every `agent_runs` row in the window (id, snapshots, grader verdicts, cost, status).
- All `agent_spans` for those runs (tool calls, model calls, compactions).
- All `output_artifacts` produced (CIMs, IC memos, forensic PDFs).
- Control-map metadata for the named compliance framework so each artifact is keyed to the relevant control.

**This command requires admin or compliance role.**

## Required inputs

1. **framework** — compliance framework id. The tool validates against `available_frameworks()` and returns the list on a bad input. Ask the user if unclear.
2. **from_date** — ISO `YYYY-MM-DD`, inclusive.
3. **to_date** — ISO `YYYY-MM-DD`, inclusive.

Optional:
- **deal_ids** — list of specific deals to restrict the export to. Omit for company-wide.

## Action

1. Call `mcp__ololand__request_regulator_export` with the collected fields.

2. On success, the response is a `RegulatorExport` row in `status: "queued"`. Surface:
   ```
   Regulator export queued
     Export id:    <id>
     Framework:    <framework>
     Window:       <from_date> to <to_date>
     Deals:        <all|specific list>
     Status:       queued
   ```
   Tell the user to poll `mcp__ololand__get_regulator_export <export_id>` for completion. Typical latency: minutes to hours depending on window size and corpus.

3. When polling shows `status: "completed"`, surface `tarball_uri`, `tarball_sha256` (for chain-of-custody attestation), and `expires_at`. The URI is a signed download link.

4. On error from the request, surface the `error_code` and explanation:
   - `bad_request` (unknown framework) — surface the `available` list verbatim.
   - `insufficient_role` — user is not admin/compliance.
   - `no_company` — agent key is not company-scoped.

## When to use

- A regulator (SEC, FINRA, FCA, etc.) requests a defensible audit trail.
- Internal compliance review (SOC 2 controls, ISO 27001, EU AI Act conformity).
- IC-mandated reproducibility exercise for a closed deal.
- Periodic compliance archive (monthly / quarterly).

## When NOT to use

- For one-off "show me the audit trail for this run" — use `/inspect-run` directly. Regulator exports are tarballs and asynchronous; not the right tool for a single-run query.
- For commercial-grade reports for non-compliance audiences — use `mcp__ololand__generate_investment_memo` or `mcp__ololand__generate_cim` instead.

## SHA-256 attestation

When you surface `tarball_sha256` to the user, include the recommendation that they record the hash separately from the OloLand system at the moment of download. The hash is what makes the tarball tamper-evident to a downstream regulator — if it changes, the chain-of-custody is broken.

Companion commands: `/inspect-run`, `/replay-run`.
