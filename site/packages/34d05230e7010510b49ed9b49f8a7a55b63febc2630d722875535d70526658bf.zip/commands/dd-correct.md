---
description: "Submit a correction on a claim in an OloLand agent output (e.g., a wrong number, a missing citation). The correction lands in OloLand's analyst_corrections store stamped surface=cowork and feeds the SFT pipeline."
---

# /dd-correct

You are submitting a claim-level correction on an OloLand agent output via the Cowork plugin.

## Required inputs

Ask the user for these if any are missing:

1. **run_id** — the OloLand agent run that produced the output. Format: starts with `run-` or is a UUID.
2. **span_id** — the agent_span ID for the specific LLM call that emitted the claim. Visible in the OloLand admin replay UI; ask the user to paste it.
3. **claim_id** — the inline `[N]` marker number on the claim being flagged.
4. **claim_text** — the verbatim text of the flagged claim (so the correction is human-readable later).
5. **delta_type** — one of: `factual`, `missing_evidence`, `scope_drift`, `tone`, `citation_wrong`, `other`. If unclear, ask the user to pick.
6. **deal_id** — the OloLand deal this output is about.

Optional:
- **correction_text** — what the claim should say instead.
- **severity** — `low`, `medium`, or `high`. Default `medium`.
- **citation_doc** — name of the source document being miscited.
- **citation_page** — page number being miscited.

## Action

Call the OloLand MCP tool `submit_agent_claim_correction` with the collected fields. The tool stamps `surface: cowork` automatically.

After success, confirm to the user with the returned correction id and a one-line summary of what was flagged.
