"""Tests for Prefect docs MCP server."""

import json
import os

import pytest
from fastmcp import FastMCP
from fastmcp.client import Client
from mcp.types import TextContent
from syrupy.assertion import SnapshotAssertion

pytestmark = pytest.mark.timeout(30)


@pytest.fixture(autouse=True)
def mock_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    """
    Mock credentials for testing.

    Bypassed if environment variables are already set to enable recording.
    """
    if os.getenv("TURBOPUFFER_API_KEY") is None:
        monkeypatch.setenv("TURBOPUFFER_API_KEY", "test-api-key")

    if os.getenv("OPENAI_API_KEY") is None:
        monkeypatch.setenv("OPENAI_API_KEY", "test-api-key")


@pytest.fixture
def docs_mcp_server() -> FastMCP:
    """Defers the import of the docs MCP server to avoid settings errors."""
    from docs_mcp_server._server import app as docs_mcp

    return docs_mcp


async def test_docs_mcp_server_has_documentation_tools(
    snapshot: SnapshotAssertion, docs_mcp_server: FastMCP
) -> None:
    """Test that the docs MCP server exposes its documentation tools."""
    async with Client(docs_mcp_server) as client:
        tools = await client.list_tools()
        tool_names = [t.name for t in tools]

        assert "search_prefect" in tool_names
        assert "get_release_notes" in tool_names

        # Verify tool has expected properties
        search_tool = next((t for t in tools if t.name == "search_prefect"), None)
        assert search_tool == snapshot

        for tool in tools:
            assert tool.annotations is not None
            assert tool.annotations.title
            assert tool.annotations.readOnlyHint is True
            assert tool.annotations.openWorldHint is False
            assert tool.annotations.destructiveHint is False


async def test_docs_tool_descriptions_do_not_route_between_tools(
    docs_mcp_server: FastMCP,
) -> None:
    async with Client(docs_mcp_server) as client:
        tools = await client.list_tools()

    for tool in tools:
        description = tool.description or ""
        for other_tool in tools:
            if other_tool.name != tool.name:
                assert other_tool.name not in description

    descriptions = {tool.name: tool.description or "" for tool in tools}
    assert "use" not in descriptions["search_prefect"].lower()
    assert "instead of" not in descriptions["get_release_notes"].lower()


@pytest.mark.vcr
async def test_search_prefect_successful_query(
    snapshot: SnapshotAssertion, docs_mcp_server: FastMCP
) -> None:
    """Test successful search returns expected response structure."""
    async with Client(docs_mcp_server) as client:
        result = await client.call_tool(
            "search_prefect", {"query": "how to create a flow", "top_k": 1}
        )

        # Ensure no error is returned
        assert isinstance(result.content[0], TextContent)
        assert json.loads(result.content[0].text).get("error") is None

        assert result == snapshot


async def test_search_prefect_empty_query(
    snapshot: SnapshotAssertion, docs_mcp_server: FastMCP
) -> None:
    """Test that empty query raises validation error."""
    async with Client(docs_mcp_server) as client:
        result = await client.call_tool(
            "search_prefect", {"query": "   "}, raise_on_error=False
        )

        # Should return error for empty query
        assert result.is_error is True
        assert isinstance(result.content[0], TextContent)
        assert "empty" in result.content[0].text.lower()

        assert result == snapshot


async def test_search_prefect_reports_missing_configuration(
    docs_mcp_server: FastMCP,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from docs_mcp_server._server import settings

    monkeypatch.setattr(settings.turbopuffer, "api_key", None)

    async with Client(docs_mcp_server) as client:
        result = await client.call_tool(
            "search_prefect",
            {"query": "how to create a flow"},
        )

    assert result.data["results"] == []
    assert "TURBOPUFFER_API_KEY" in result.data["error"]


@pytest.mark.vcr
async def test_search_prefect_handles_validation_error(
    snapshot: SnapshotAssertion, docs_mcp_server: FastMCP
) -> None:
    """Test that validation errors are handled gracefully."""
    async with Client(docs_mcp_server) as client:
        result = await client.call_tool(
            "search_prefect",
            {"query": "how to create a flow", "top_k": 999},
            raise_on_error=False,
        )

        # Ensure error is returned
        assert result.is_error is True
        assert isinstance(result.content[0], TextContent)

        assert result == snapshot
