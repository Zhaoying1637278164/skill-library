"""Settings for Prefect MCP server."""

from datetime import timedelta
from typing import Literal

from logfire import LevelName
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class DocsMcpSettings(BaseSettings):
    """Docs MCP proxy settings."""

    model_config = SettingsConfigDict(
        env_prefix="PREFECT_DOCS_MCP_", extra="ignore", env_file=".env"
    )

    url: str = Field(
        default="https://prefect-docs.fastmcp.app/mcp",
        description="URL for the Prefect docs MCP server to proxy",
    )

    init_timeout: float = Field(
        default=10.0,
        description="Timeout in seconds for initializing the docs proxy connection",
    )


class LogfireSettings(BaseSettings):
    """Logfire settings."""

    model_config = SettingsConfigDict(
        env_prefix="LOGFIRE_", extra="ignore", env_file=".env"
    )

    service_name: str = Field(
        default="prefect-mcp-server",
        description="Service name attached to Logfire telemetry",
    )

    token: str | None = Field(
        default=None,
        description="Logfire token",
    )

    environment: str | None = Field(
        default=None,
        description="Environment for Logfire",
    )

    send_to_logfire: Literal["if-token-present"] | None = Field(
        default="if-token-present",
        description="Whether to send logs to Logfire",
    )

    sampling_head_rate: float = Field(
        default=0.1,
        ge=0.0,
        le=1.0,
        description="Fraction of traces to sample upfront",
    )

    sampling_level_threshold: LevelName = Field(
        default="warn",
        description="Minimum log level to always retain",
    )

    sampling_duration_threshold: float = Field(
        default=5.0,
        ge=0.0,
        description="Minimum duration in seconds to always retain",
    )

    sampling_background_rate: float = Field(
        default=0.01,
        ge=0.0,
        le=1.0,
        description="Fraction of otherwise unsampled traces to retain",
    )


class ExperimentalSettings(BaseSettings):
    """Experimental MCP feature settings."""

    model_config = SettingsConfigDict(
        env_prefix="PREFECT_MCP_EXPERIMENTAL_",
        extra="ignore",
        env_file=".env",
    )

    execution_plans_enabled: bool = Field(
        default=False,
        description="Whether to enable the experimental execution-plan authoring MCP surface",
    )


class Settings(BaseSettings):
    """Settings for the Prefect MCP server."""

    model_config = SettingsConfigDict(env_file=[".env"], extra="ignore")

    events_default_lookback: timedelta = Field(
        default=timedelta(hours=1),
        description="Default time window to look back for events",
    )

    openai_apps_challenge_token: str | None = Field(
        default=None,
        description="Token returned for OpenAI public plugin domain verification",
    )

    docs_mcp: DocsMcpSettings = Field(
        default_factory=DocsMcpSettings,
        description="Docs MCP proxy settings",
    )

    logfire: LogfireSettings = Field(
        default_factory=LogfireSettings,
        description="Logfire settings",
    )

    experimental: ExperimentalSettings = Field(
        default_factory=ExperimentalSettings,
        description="Experimental MCP feature settings",
    )


settings = Settings()
