#!/usr/bin/env bash
# Installs skills from this folder into Claude Code (~/.claude/skills) and/or
# Codex ($CODEX_HOME/skills, default ~/.codex/skills). Both agents read the
# same SKILL.md format, so the skill files are identical.
#
# Usage:
#   ./install.sh                      # install ALL skills for Claude Code
#   ./install.sh off-by-none another-skill  # install only the named skills
#   ./install.sh --codex              # install into Codex instead
#   ./install.sh --all-agents         # install into both
#   ./install.sh --list               # show installable skills
#
# A skill = a real directory (not symlink) under skills/ containing SKILL.md.
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_ROOT="$HOME/.claude/skills"
CODEX_ROOT="${CODEX_HOME:-$HOME/.codex}/skills"
dest_roots=()

available() {
  local d
  for d in "$SRC_DIR"/skills/*/; do
    d="${d%/}"
    [ -L "$d" ] && continue
    [ -f "$d/SKILL.md" ] || continue
    basename "$d"
  done
}

if [ "${1:-}" = "--list" ]; then
  available
  exit 0
fi

skills=()
names=()
for arg in "$@"; do
  case "$arg" in
    --codex) dest_roots+=("$CODEX_ROOT") ;;
    --claude) dest_roots+=("$CLAUDE_ROOT") ;;
    --all-agents) dest_roots+=("$CLAUDE_ROOT" "$CODEX_ROOT") ;;
    -*) echo "error: unknown option '$arg'" >&2; exit 1 ;;
    *) names+=("$arg") ;;
  esac
done
[ ${#dest_roots[@]} -eq 0 ] && dest_roots=("$CLAUDE_ROOT")

set -- ${names[@]+"${names[@]}"}
if [ $# -ge 1 ]; then
  for name in "$@"; do
    if [ ! -f "$SRC_DIR/skills/$name/SKILL.md" ]; then
      echo "error: unknown skill '$name' — run $0 --list" >&2
      exit 1
    fi
    skills+=("$name")
  done
else
  while IFS= read -r s; do skills+=("$s"); done < <(available)
fi

if [ ${#skills[@]} -eq 0 ]; then
  echo "error: no skills found next to this script" >&2
  exit 1
fi

installed=0
for root in "${dest_roots[@]}"; do
  for name in "${skills[@]}"; do
    src="$SRC_DIR/skills/$name"
    dest="$root/$name"
    if [ "$src" = "$dest" ]; then
      echo "skip $name (already in place)"
      continue
    fi
    [ -f "$dest/SKILL.md" ] && echo "overwrite $name"
    mkdir -p "$dest"
    cp -R "$src/." "$dest/"
    echo "installed $name -> $dest"
    installed=$((installed + 1))
  done
done

echo
echo "Done: $installed skill(s) installed."
echo "Restart any running Claude Code / Codex session to pick them up."
