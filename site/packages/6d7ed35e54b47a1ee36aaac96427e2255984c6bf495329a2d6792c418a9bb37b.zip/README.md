<p align="center">
  <img src="./assets/cypress-logotype-dark.svg#gh-light-mode-only" alt="Cypress" width="240" />
  <img src="./assets/cypress-logotype.svg#gh-dark-mode-only" alt="Cypress" width="240" />
</p>

<p align="center">
  <a href="https://on.cypress.io/discord">
    <img src="https://img.shields.io/badge/chat-on%20Discord-brightgreen" alt="Discord chat" />
  </a>
</p>

# ✨ Cypress AI Toolkit

Open-source Cypress AI skills, built by the Cypress team. Works with Claude, Cursor, GitHub Copilot, and more.

Your AI tool is capable. It just does not know Cypress the way you do. The toolkit fixes that with skills, context, and guidance built by the team that built Cypress.

Cypress also ships AI capabilities in the App and Cypress Cloud - such as [`cy.prompt()`](https://docs.cypress.io/api/commands/prompt), Studio AI, Cloud MCP, Test Intent and Error Summaries, and UI Coverage test generation. Learn more in the [Cypress AI documentation](https://docs.cypress.io/cloud/features/cypress-ai-features).

## The problem this solves

AI tools can work with Cypress. What they struggle with is applying it consistently and correctly.

Without guidance, AI tools fall back on generic patterns — underusing the Cypress API, misapplying selectors, skipping best practices that experienced Cypress developers internalize over time. The result is output that technically runs but that you can't rely on.

The Cypress AI Toolkit gives your AI tools the Cypress-specific context they need to produce output you can actually build on — consistently, across your team and your workflows.

## What's in the toolkit

### Model Context Protocol (MCP)

The Cypress Cloud MCP server connects your AI coding assistants directly to Cypress Cloud, giving them access to data regarding your application's health and stability.

More information about the Cypress Cloud MCP is available [here](https://docs.cypress.io/cloud/integrations/cloud-mcp).

_Note:_ The MCP connection will utilize OAuth by default. If you would prefer to use a Personal Access Token (PAT) you will need to adjust the `.mcp.json` file for your agent.

### Skills

Skills are instruction sets your AI tool loads to apply Cypress-specific knowledge when generating or reviewing test code. They fill the gap between what an AI learned during training and what current, well-written Cypress tests actually look like.

Five skills are available now:

- **[`cypress-author`](./skills/README.md#cypress-author)** — Improves how AI tools create, update, and fix Cypress tests. Use it when you're writing new tests or fixing broken ones.
- **[`cypress-explain`](./skills/README.md#cypress-explain)** — Helps you understand, describe, and critique existing tests. Use it when auditing a suite, onboarding a new team member, or investigating a brittle test before rewriting it.
- **[`cypress-docs`](./skills/README.md#cypress-docs)** - Helps your agent research and retrieve information about Cypress more efficiently and reliably.
- **[`cypress-tap`](./skills/README.md#cypress-tap)** — Drives a running Cypress open-mode session to run specs, inspect results, diagnose failures, and query the app under test without GUI interaction.
- **[`cypress-cloud-cli`](./skills/README.md#cypress-cloud-cli)** — Investigates Cypress Cloud runs, tests, failures, screenshots, and Test Replay data through the Cypress Cloud CLI.

Skills work with any AI tool that accepts custom instructions, including Claude, Cursor, and GitHub Copilot.

See the [skills documentation](./skills/README.md) for installation instructions, example prompts, and troubleshooting.

### What's coming

We're building toward a broader toolkit.

The community will help shape what gets prioritized. If you're already unlocking AI-powered Cypress workflows, we want to hear how. [Open an issue](https://github.com/cypress-io/ai-toolkit/issues) or [open a PR](https://github.com/cypress-io/ai-toolkit/pulls).

## Getting started

### Plugin

The Cypress AI toolkit is published as a plugin for installation into your agent. This is the easiest way to install and configure the various capabilities in this package and also enables an auto-update capability.

_Note: Our listing in the Cursor official plugin marketplace is currently pending. This README will be updated once it is available. Until then, this repository can be cloned and installed as a local plugin in your agent of choice._

#### Claude

The plugin is published in the Claude Community Plugins marketplace - see the the [instructions here](https://github.com/anthropics/claude-plugins-community#using-this-marketplace) for configuring your Claude instance to use this marketplace. Once the marketplace is configured you can search for the `cypress` plugin.

### Manual Installation

If you're using another agent or prefer to pick-and-choose you can pick the portions of this repository you want.

1. Install the skills using command-line tools

 * [`skills`](https://skills.sh/) package:
   ```sh
   npx skills add cypress-io/ai-toolkit
   ```
  
  * [`GitHub CLI`](https://cli.github.com/manual/gh_skill):
    ```sh
    gh skill install cypress-io/ai-toolkit
    ```

2. Prompt your AI tool as you normally would. The skills will activate automatically when relevant, or invoke one directly with a slash command (e.g. `/cypress-author`).

    For manual installation, example prompts, and more, see the [skills documentation](./skills/README.md) or the [Cypress AI Skills docs](https://docs.cypress.io/app/tooling/ai-skills).

3. The Cypress Cloud MCP configuration can be copied into your agent, or you can follow the [configuration instructions here](https://docs.cypress.io/cloud/integrations/cloud-mcp).

## Who this is for

This toolkit is for Cypress developers who use AI coding tools and want consistent, reliable output — not just code that runs.

It's the right fit if you want your AI tool to:

- Follow Cypress conventions and best practices without being told every time
- Produce workflows you can repeat and build on, not just one-off completions
- Behave consistently across your team, regardless of who's prompting

You do not need AI expertise to use it. You need Cypress and an AI coding tool.

## Contributing

We welcome contributions of all kinds: new skills, improvements to existing ones, bug reports, and ideas.

If you've built something that makes AI tools smarter about Cypress, this is the right place to share it.

Read the [contributing guide](./CONTRIBUTING.md) to get started.

## Releases
### PR Checks
Any change to a skill should have a corresponding semver update to the `version` frontmatter field in the `SKILL.md` file.

Changes to any functional toolkit content (skills and mcp, not documentation for example) should update the `version` metadata under `.cursor-plugin` and `.claude-plugin` so that plugin marketplaces can see and update accordingly.

### Post-PR Actions
After an update with skill changes is merged run `gh skill publish` **from the `main` branch**. Preview changes with `--dry-run`. Version to match the plugin version above - this likely will *not* match the version of individual skills, but should be thought of as a "package" version.

## License

[MIT](./LICENSE)
