## [0.6.0](https://github.com/holistics/skills/compare/holistics-development-v0.5.5...holistics-development-v0.6.0) (2026-08-12)

### Features

* **plugins.development:** add build-dashboard skill
* **plugins.development:** add build-custom-chart and build-dashboard-theme skills ([06e49db](https://github.com/holistics/skills/commit/06e49db39dab3994432a2d8e2c06b56d6d5e54fd))
* **plugins.development:** update build-custom-chart with render-safety fixes ([d361d99](https://github.com/holistics/skills/commit/d361d99e952f61616d9ff1eb6cf25344a924a1b5))
* **plugins.development:** update build-dashboard-theme to 5.0.0 ([fadebfb](https://github.com/holistics/skills/commit/fadebfb41930ac82e64b416dc1a3903a9d14f67e))

### Bug Fixes

* **native:** write library files under .holistics/library ([765dd8e](https://github.com/holistics/skills/commit/765dd8e9f6f53ffce0d4c07c7eede6e8835737c0))

## [0.5.5](https://github.com/holistics/skills/compare/holistics-development-v0.5.4...holistics-development-v0.5.5) (2026-06-22)

### Bug Fixes

* **plugins.development:** make hooks compatible with codex ([02e97a3](https://github.com/holistics/skills/commit/02e97a3fa47efad98f226738c7c8bb2b2b7d0081))

## [0.5.4](https://github.com/holistics/skills/compare/holistics-development-v0.5.3...holistics-development-v0.5.4) (2026-06-19)

### Bug Fixes

* **plugins.common:** default AML field references to the new r() syntax ([f51b538](https://github.com/holistics/skills/commit/f51b5381595bea97cbd885663595cfcbf83ebce4))

## [0.5.3](https://github.com/holistics/skills/compare/holistics-development-v0.5.2...holistics-development-v0.5.3) (2026-06-15)

### Bug Fixes

* **plugins.development:** setup-amql-development - do not to stop sync code on conflict ([c62c2bd](https://github.com/holistics/skills/commit/c62c2bd7e8deb2b50614169464d045120153ee11))

## [0.5.2](https://github.com-holistics/holistics/skills/compare/holistics-development-v0.5.1...holistics-development-v0.5.2) (2026-06-04)

### Bug Fixes

* **plugins.common,plugins.development,plugins.reporting:** document search_docs question param ([8350777](https://github.com-holistics/holistics/skills/commit/8350777b5275be0e6f0f09c8605a2d184b5396be))

## [0.5.1](https://github.com/holistics/skills/compare/holistics-development-v0.5.0...holistics-development-v0.5.1) (2026-06-01)

### Bug Fixes

* **plugins.development:** place skills under settings/ai/skills/ ([7f905be](https://github.com/holistics/skills/commit/7f905be043cc7a3a18567dcafbc06c2c9acecf52))

## [0.5.0](https://github.com/holistics/skills/compare/holistics-development-v0.4.0...holistics-development-v0.5.0) (2026-05-28)

### Features

* **plugins.development:** add hook to validate after editing aml files ([15485af](https://github.com/holistics/skills/commit/15485aff89d0f3fd3c1325845673301273e21d83))
* **plugins.development:** guide the agent to update CLAUDE.md ([860cdb3](https://github.com/holistics/skills/commit/860cdb35cf1f5acf8c051c82b5c9bd6680312375))

## [0.4.0](https://github.com/holistics/skills/compare/holistics-development-v0.3.0...holistics-development-v0.4.0) (2026-05-27)

### Features

* **plugins.development:** rewrite create-holistics-skill SKILL.md ([7f6c4cc](https://github.com/holistics/skills/commit/7f6c4ccbef0271104cea32ecb347e7db3a698dc7))
* **plugins.development:** split conversion guidance into its own skill ([88e2628](https://github.com/holistics/skills/commit/88e262885aa10666525e44afea1028edeec3a4c1))

## [0.3.0](https://github.com/holistics/skills/compare/holistics-development-v0.2.0...holistics-development-v0.3.0) (2026-05-21)

### Features

* **plugins.development:** using MCP via CLI ([7de9752](https://github.com/holistics/skills/commit/7de9752278efbc9ee9041e18cf41b0d954465c21))

## [0.2.0](https://github.com/holistics/skills/compare/holistics-development-v0.1.0...holistics-development-v0.2.0) (2026-05-13)

### Features

* update mcp to use OAuth ([e559e34](https://github.com/holistics/skills/commit/e559e349365e2b0d19052378fe19ec9190ca2789))

## [0.1.0](https://github.com/holistics/skills/compare/holistics-development-v0.0.4...holistics-development-v0.1.0) (2026-05-05)

### Features

* add create-holistics-skill ([629bf39](https://github.com/holistics/skills/commit/629bf396656dd63a7ba13656b6d31c4b24897b25))

## [0.0.4](https://github.com/holistics/skills/compare/holistics-development-v0.0.3...holistics-development-v0.0.4) (2026-04-27)

## 0.0.3 (2026-04-08)

### Features

* improve mcp setup ([168ea57](https://github.com/holistics/skills/commit/168ea57d6b25050af667cdaf91998a8b36e335db))

## 0.0.2 (2026-04-04)

### Features

* various improvements ([5ed2e38](https://github.com/holistics/skills/commit/5ed2e382a78dd7d8ccabe2aff78c0bd57966b860))
