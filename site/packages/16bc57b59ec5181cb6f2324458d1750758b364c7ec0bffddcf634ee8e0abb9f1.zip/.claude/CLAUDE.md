See [AGENTS.md](../AGENTS.md) for the repository guide.

Quick notes for Claude Code specifically:

- Error auto-detection ships two ways. Installed as a **plugin**, `hooks/hooks.json` registers the
  `PostToolUse` hook automatically — never offer to install it. Installed via the `skills` CLI, the
  skill can install it with `skills/steadwing/scripts/install_hook.py`; offer that only once, after
  the first successful registration, and only in Claude Code.
- The hook is passive — it detects production-style errors and asks before any RCA is triggered.
  Never POST to `/api/mcp/analyze` without explicit user confirmation.
- Credentials live at `~/.steadwing/credentials.json`. On `401`, delete and re-register.
