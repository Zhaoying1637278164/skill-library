# coding-skills

Engineering skills for Claude Code, aimed at the bugs that pass code review and fail in production.

Your load test reports a p99 of 4ms. It is measuring the wrong thing, and the real number can be a hundred times worse. Two transactions each check the same invariant, each commit cleanly, and together break it, raising no error anywhere. At 85% CPU you have throughput headroom and no latency headroom at all.

Each skill covers one failure of that kind. You never pick a skill by name. Describe the problem in normal words and the right one loads itself.

## Install

```bash
npx skills add auralshin/coding-skills
```

Or as a Claude Code plugin:

```bash
claude plugin marketplace add auralshin/coding-skills
```

```bash
claude plugin install coding-skills@coding-skills
```

## Try it

Ask any of these the way you would ask a colleague, without naming a skill:

| What you say | What loads |
|---|---|
| "Two requests both checked the balance and both succeeded" | `isolation-anomalies` |
| "Our load test says p99 is 4ms but users complain" | `coordinated-omission` |
| "It came back up and immediately fell over again" | `retry-amplification` |
| "Rename a column on a live table" | `expand-contract` |
| "We have full coverage and still shipped a bug" | `mutation-testing` |
| "Page 900 of this list times out" | `keyset-pagination` |

To browse instead, run `/find-skill`, or `/find-skill deep pagination is slow` to jump straight to one.

## Skills

### Code structure

| Skill | Covers |
|---|---|
| [cyclomatic-complexity](skills/cyclomatic-complexity/SKILL.md) | Counting decision points, thresholds, refactors that actually lower the score |
| [connascence](skills/connascence/SKILL.md) | A precise taxonomy for coupling: name, meaning, position, algorithm, order, timing, value, identity |
| [code-hotspots](skills/code-hotspots/SKILL.md) | churn x complexity from git history, change coupling, bus factor |
| [module-depth](skills/module-depth/SKILL.md) | Deep vs shallow modules, information leakage, when "small classes" is wrong |

### Correctness and design

| Skill | Covers |
|---|---|
| [parse-dont-validate](skills/parse-dont-validate/SKILL.md) | Encode checks in types, kill shotgun parsing, illegal states unrepresentable |
| [isolation-anomalies](skills/isolation-anomalies/SKILL.md) | Write skew, lost update, why REPEATABLE READ means two different things |
| [expand-contract](skills/expand-contract/SKILL.md) | Zero-downtime schema and API change, with per-operation recipes |
| [hyrums-law](skills/hyrums-law/SKILL.md) | Implicit interfaces, and deliberately randomizing unspecified behavior |
| [floating-point](skills/floating-point/SKILL.md) | Catastrophic cancellation, Kahan summation, why money is never a float |
| [unicode-pitfalls](skills/unicode-pitfalls/SKILL.md) | Grapheme clusters, NFC and NFD, the Turkish dotless i, safe truncation |
| [clocks-and-time](skills/clocks-and-time/SKILL.md) | Monotonic vs wall clock, NTP jumps, DST arithmetic, hybrid logical clocks |

### Performance and reliability

| Skill | Covers |
|---|---|
| [coordinated-omission](skills/coordinated-omission/SKILL.md) | The bug making p99 wrong by 100x, and why percentiles cannot be averaged |
| [queueing-and-utilization](skills/queueing-and-utilization/SKILL.md) | Little's Law, the utilization knee, why 90% CPU means 10x latency |
| [tail-latency](skills/tail-latency/SKILL.md) | Fan-out amplification, hedged and tied requests, deadline propagation |
| [universal-scalability-law](skills/universal-scalability-law/SKILL.md) | Where adding capacity starts hurting, and fitting the curve to real data |
| [retry-amplification](skills/retry-amplification/SKILL.md) | Retry storms, metastable failure, retry budgets, jitter, load shedding |
| [cache-stampede](skills/cache-stampede/SKILL.md) | Stampede, penetration, avalanche, hot keys, probabilistic early expiration |
| [consistent-hashing](skills/consistent-hashing/SKILL.md) | Rings, rendezvous hashing, jump hash, hot shards |

### Databases

| Skill | Covers |
|---|---|
| [query-plans](skills/query-plans/SKILL.md) | Reading EXPLAIN ANALYZE, where estimate versus actual is the whole game |
| [index-design](skills/index-design/SKILL.md) | Composite column order, sargability, partial and covering indexes, UUID locality |
| [mvcc-and-bloat](skills/mvcc-and-bloat/SKILL.md) | Why DELETE grows the table, what blocks autovacuum, HOT updates, wraparound |
| [connection-pooling](skills/connection-pooling/SKILL.md) | Why fewer connections is faster, PgBouncer modes and what each breaks |
| [keyset-pagination](skills/keyset-pagination/SKILL.md) | OFFSET is O(n) and skips rows, plus seek pagination and safe batch processing |
| [database-queues](skills/database-queues/SKILL.md) | `FOR UPDATE SKIP LOCKED` queues, and the transactional outbox |
| [write-amplification](skills/write-amplification/SKILL.md) | The RUM conjecture, LSM vs B-tree, compaction tuning |

### Testing and supply chain

| Skill | Covers |
|---|---|
| [mutation-testing](skills/mutation-testing/SKILL.md) | Whether tests detect bugs at all, versus whether lines merely ran |
| [metamorphic-testing](skills/metamorphic-testing/SKILL.md) | Testing without an oracle, via relations between outputs |
| [algorithmic-complexity-attacks](skills/algorithmic-complexity-attacks/SKILL.md) | ReDoS, hash flooding, zip bombs, billion laughs |
| [dependency-confusion](skills/dependency-confusion/SKILL.md) | Registry resolution, typosquatting, lockfiles, hash pinning |

Plus [start-here](skills/start-here/SKILL.md), a router that loads only when a question is too broad to match one skill.

## How loading works

Skills use progressive disclosure, so the set is never in context all at once.

| Level | What loads | Cost |
|---|---|---|
| Always | every skill's `name` and `description` | ~2.9k tokens |
| On match | the matching body, alone | ~850 words |
| Never automatically | every other body | nothing |

Bodies stay near 850 words, well under the 5k ceiling. Descriptions carry explicit handoffs, so `cache-stampede` says *for retry storms use `retry-amplification`* and overlapping areas route to one skill instead of three.

## Conventions

Each skill follows one shape: what the thing is in plain language, how to measure or detect it, concrete thresholds and runnable code, the fixes ranked, tooling, and an honest note on when it does not apply.

Writing rules, enforced by the validator wherever a machine can check them:

- **Payload first, provenance second.** Open with the claim, not the citation. "One slow server sets the latency of every request that touches it" leads, and "From Dean and Barroso, 2013" follows.
- **Concrete over abstract.** Name the number, the failure, the command. Sentences average 13 words and none runs past 45.
- **Imperative voice**, per Anthropic's skill-authoring guidance, with third-person trigger descriptions.
- **No em dashes, no semicolons, no counts in prose.** A count goes stale the moment a skill is added.
- **Comments under 10 words**, carrying the why rather than the what.

## Validating

```bash
python3 scripts/validate.py
```

Checks the manifests, frontmatter, third-person descriptions, trigger-phrase count, body budget, imperative voice, comment length, and that every skill appears in both the README and the command catalog.

## Adding a skill

```bash
mkdir -p skills/<name>
```

```markdown
---
name: <name>
description: This skill should be used when the user asks "<phrase>", "<phrase>", or is <situation>.
---
```

The description is the only thing Claude reads before deciding to load, so write it as the situations that should pull it in, phrased the way a developer would actually say them, rather than as a topic label. Then add the skill to `commands/find-skill.md` and to the tables above, and run the validator.

## License

MIT
