#!/usr/bin/env python3
"""Validate the coding-skills plugin against Anthropic's skill-authoring rules."""
import json, re, glob, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
MAX_BODY_WORDS = 5000
MAX_COMMENT_WORDS = 9
errors, warnings = [], []

def prose_only(md):
    # voice rules apply to prose, not quoted sources or literal identifiers
    md = re.sub(r'```.*?```', '', md, flags=re.S)
    md = re.sub(r'`[^`]*`', '', md)
    md = re.sub(r'^\s*>.*$', '', md, flags=re.M)
    md = re.sub(r'^\s*\|.*$', '', md, flags=re.M)
    return re.sub(r'\*[^*]+\*', '', md)

def comments(md):
    for lang, block in re.findall(r'```([a-z]*)\n(.*?)```', md, re.S):
        for line in block.split('\n'):
            m = re.search(r'(?<!\S)(?:#|//)\s*(.+)$', line) or re.search(r'--\s+(.+)$', line)
            if m and m.group(1).strip():
                yield m.group(1).strip()

for f in ('.claude-plugin/plugin.json', '.claude-plugin/marketplace.json'):
    try:
        json.load(open(f))
    except Exception as e:
        errors.append(f"{f}: invalid JSON: {e}")

names, meta_chars, body_words = set(), 0, []
for path in sorted(glob.glob('skills/*/SKILL.md')):
    d = os.path.basename(os.path.dirname(path))
    text = open(path).read()
    m = re.match(r'^---\n(.*?)\n---\n(.*)$', text, re.S)
    if not m:
        errors.append(f"{d}: missing YAML frontmatter")
        continue
    fm, body = m.group(1), m.group(2)
    name = re.search(r'^name:\s*(\S+)$', fm, re.M)
    desc = re.search(r'^description:\s*(.+)$', fm, re.M)
    if not name or not desc:
        errors.append(f"{d}: frontmatter needs both name and description")
        continue
    if name.group(1) != d:
        errors.append(f"{d}: name '{name.group(1)}' does not match directory")
    if not desc.group(1).startswith('This skill should be used'):
        errors.append(f"{d}: description must be third person")
    if len(re.findall(r'"[^"]+"', desc.group(1))) < 3:
        warnings.append(f"{d}: fewer than 3 quoted trigger phrases")
    w = len(body.split())
    if w > MAX_BODY_WORDS:
        errors.append(f"{d}: body {w} words exceeds {MAX_BODY_WORDS}")
    if '—' in text:
        errors.append(f"{d}: contains an em dash")
    if ';' in prose_only(text):
        errors.append(f"{d}: semicolon in prose")
    if re.search(r'\b(you|your|yours)\b', prose_only(body), re.I):
        errors.append(f"{d}: second person in prose")
    if '](../' in text:
        errors.append(f"{d}: relative cross-skill link, reference by skill name")
    for c in comments(body):
        if ';' in c:
            errors.append(f"{d}: semicolon in comment: {c[:40]}")
        if '—' in c:
            errors.append(f"{d}: em dash in comment: {c[:40]}")
        if len(c.split()) > MAX_COMMENT_WORDS:
            errors.append(f"{d}: comment over {MAX_COMMENT_WORDS} words: {c[:50]}")
    names.add(d)
    meta_chars += len(d) + len(desc.group(1))
    body_words.append(w)

for f in ('skills/start-here/SKILL.md', 'commands/find-skill.md'):
    if not os.path.exists(f):
        errors.append(f"missing {f}")
        continue
    for ref in set(re.findall(r'`([a-z][a-z0-9]+(?:-[a-z0-9]+)+)`', open(f).read())):
        if ref not in names and ref not in ('other-skill', 'for-x'):
            warnings.append(f"{f}: references '{ref}' which is not a skill")

readme, cmd = open('README.md').read(), open('commands/find-skill.md').read()
for n in sorted(names):
    if n not in readme:
        errors.append(f"README.md does not list {n}")
    if n not in cmd and n != 'start-here':
        errors.append(f"commands/find-skill.md does not list {n}")

print(f"skills            {len(names)}")
print(f"resident metadata ~{meta_chars // 4:,} tokens (always in context)")
print(f"body size         avg {sum(body_words)//len(body_words)}, max {max(body_words)} words (loaded on match)")
print()
for w in warnings:
    print(f"warning: {w}")
if errors:
    print()
    for e in errors:
        print(f"FAIL: {e}")
    sys.exit(1)
print("All checks pass.")
