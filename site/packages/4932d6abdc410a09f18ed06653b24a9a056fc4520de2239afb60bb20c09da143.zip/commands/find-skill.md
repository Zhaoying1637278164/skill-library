---
description: Find which coding skill applies to a problem, or list them all
argument-hint:
- describe the problem
- or leave blank to list everything
allowed-tools: Skill
---

## Task

The user's problem: **$ARGUMENTS**

Skills in this plugin trigger automatically from a description of a problem, so this command exists for browsing and for cases where the right one is unclear.

**If arguments were given**, identify the single best-matching skill from the table below and invoke it with the Skill tool. Match on the symptom described, not on vocabulary the user happened to use. If nothing matches well, say so and answer the question directly rather than loading an approximate match.

**If no arguments were given**, print the table grouped by area, and add one line explaining that describing a problem in normal words is enough to load the right skill automatically.

## Catalog

**Code structure**
| Symptom | Skill |
|---|---|
| Function has too many branches, hard to follow | `cyclomatic-complexity` |
| Changing one thing forces changes elsewhere | `connascence` |
| Unsure what to refactor first | `code-hotspots` |
| Unsure if an abstraction, wrapper, or split is worth it | `module-depth` |

**Correctness**
| Symptom | Skill |
|---|---|
| Same check repeated everywhere, null assertions deep in code | `parse-dont-validate` |
| Concurrent requests corrupt an invariant | `isolation-anomalies` |
| Change a schema, API, or event format with no downtime | `expand-contract` |
| An "internal" change broke a consumer | `hyrums-law` |
| Money off by a cent, float comparison, NaN | `floating-point` |
| String length, truncation, accents, emoji, case matching | `unicode-pitfalls` |
| Elapsed time, event ordering across machines, time zones, DST | `clocks-and-time` |

**Performance and reliability**
| Symptom | Skill |
|---|---|
| Benchmark p99 looks too good, prod worse than load test | `coordinated-omission` |
| Pool sizing, or latency rose without more traffic | `queueing-and-utilization` |
| p99 bad while p50 fine, request fans out widely | `tail-latency` |
| Throughput drops as servers or threads are added | `universal-scalability-law` |
| Still down after the cause was fixed, retry storms | `retry-amplification` |
| Load spikes when a cache key expires | `cache-stampede` |
| Sharding keys across a changing set of nodes | `consistent-hashing` |

**Databases**
| Symptom | Skill |
|---|---|
| One query is slow, need to read the plan | `query-plans` |
| Choosing, ordering, or auditing indexes | `index-design` |
| Table grows despite deletes, vacuum warnings | `mvcc-and-bloat` |
| Out of connections, pool tuning | `connection-pooling` |
| Deep pagination slow, or a backfill skips rows | `keyset-pagination` |
| Job queue, or publishing an event atomically with a write | `database-queues` |
| Picking a storage engine, disk far exceeds data size | `write-amplification` |

**Testing and supply chain**
| Symptom | Skill |
|---|---|
| Are our tests actually catching anything | `mutation-testing` |
| Testing something with no known correct answer | `metamorphic-testing` |
| Regex over user input, CPU spike on one request, zip or XML bombs | `algorithmic-complexity-attacks` |
| Private registries, lockfiles, package trust | `dependency-confusion` |

## Commonly confused

| Question | Skill |
|---|---|
| Is the p99 trustworthy? | `coordinated-omission` |
| How do I lower the p99? | `tail-latency` |
| What size should this pool be? | `queueing-and-utilization` |
| Why does more capacity make it slower? | `universal-scalability-law` |
| Why is this query slow? | `query-plans` |
| Which index should exist? | `index-design` |
| Herd from cache expiry | `cache-stampede` |
| Herd from retries | `retry-amplification` |
