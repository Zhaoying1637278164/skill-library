# nsolid-skills-plugin

N|Solid performance and security agent skills for Claude Code, Codex CLI, and
Antigravity.

This plugin ships **skills only**: it contains no MCP registration files, no
MCP bridge runtime, and no CLI. The `nsolid-plugin` CLI (installed separately
through `npx`) is responsible for authentication and for writing the
direct-HTTP MCP configuration your harness uses. All commands below pin
`nsolid-plugin@1.1.0`.

## Supported harnesses

- Claude Code
- Codex CLI
- Antigravity

OpenCode and Pi are not supported and are not included in the manifests.

## What this plugin includes

All 18 N|Solid skills:

`ns-advanced-memory-leak-hunter`, `ns-analyze-asset`, `ns-analyze-event`,
`ns-analyze-tracing`, `ns-analyze-vulnerabilities`, `ns-audit-dependencies`,
`ns-benchmark-run`, `ns-cpu-spike-analysis`, `ns-download-asset`,
`ns-generate-asset`, `ns-generate-sbom`, `ns-memory-spike-analysis`,
`ns-node-upgrade`, `ns-optimize-function`, `ns-replace-package`,
`ns-switch-org`, `ns-upgrade-package`, `ns-validate-optimization`.

Skills that need raw diagnostics assets ship their own bundled helpers
(`fetch-asset.cjs`, `wait.cjs`, `workspace-delta.cjs`,
`fetch-node-releases.cjs`, audit helpers) inside each skill directory, so
they survive installation with the skill.

## Prerequisites

- Node.js and npm (the `nsolid-plugin` CLI requires Node.js >= 22.3.0).
- A NodeSource account with access to your N|Solid console organization.
- A harness (Claude Code, Codex CLI, or Antigravity).

## Install

The canonical marketplace name is `nodesource`, and the plugin install ID
for Claude Code and Codex CLI is `nsolid-skills-plugin@nodesource`.

```sh
claude plugin marketplace add https://github.com/nodesource/nsolid-skills-plugin
claude plugin install nsolid-skills-plugin@nodesource

# Codex CLI reads the same marketplace manifest:
codex plugin marketplace add nodesource/nsolid-skills-plugin
codex plugin add nsolid-skills-plugin@nodesource
```

## Authenticate and configure direct-HTTP MCP

This plugin does not register MCP servers itself. Run the CLI's direct-HTTP
mode, which authenticates you and writes MCP entries into your harness
configuration without provisioning any bridge runtime:

```sh
npx -y nsolid-plugin@1.1.0 setup --harness claude --external-mcp
```

What this does:

1. Opens a browser OAuth flow (callback on local port 8765) and stores one
   set of shared NodeSource credentials.
2. Writes direct-HTTP MCP server entries (`nsolid-console`, `ns-benchmark`,
   `ncm`) with their authentication headers into the selected harness's
   configuration. No `mcp-remote` runtime is downloaded, checked, or
   modified.
3. Reports per-server success or failure. Partial failure is reported as
   failure, not as success.

Use `--harness codex` or `--harness antigravity` for the other harnesses.
The flag is rejected for other harnesses.

## Direct-HTTP credentials: what is stored where, and who reads it

- **One shared credential file:** `~/.agents/.nodesource-auth.json` in your
  home directory. It holds the console URL, the service token, and the
  active organization. Every harness configured by the CLI shares it; there
  is no per-harness credential isolation.
- **Per-harness MCP configuration:** the CLI writes the server URLs and
  authentication headers into each harness's own config. These copies are
  **not** refreshed automatically when credentials or the organization
  change — re-run `setup --external-mcp` per harness to refresh them, then
  reconnect/restart that harness.
- **Bundled skill helpers read the same file.** `fetch-asset.cjs` (asset
  downloads) and the dependency-audit helper (Bearer token to
  `api.ncm.nodesource.com`) read `~/.agents/.nodesource-auth.json`
  directly. If you remove or corrupt that file, those helpers fail with an
  authentication error until you re-run setup.
- **Never edit the credential file by hand.** If authentication fails, fix
  it by re-running setup, not by manual edits.

### External services contacted

| Service | Contacted by | Authentication |
| --- | --- | --- |
| `accounts.nodesource.com` | CLI setup / switch-org (browser OAuth) | OAuth, local callback port 8765 |
| Your N|Solid console (URL from your account) | `nsolid-console` MCP transport; `fetch-asset.cjs` downloads | `X-Nsolid-Service-Token` header |
| `benchmark.mcp.saas.nodesource.io` | `ns-benchmark` MCP transport | `X-Nsolid-Service-Token` + `X-Nsolid-Org-Id` headers |
| `mcp.ncm.nodesource.com` | `ncm` MCP transport | `X-Nsolid-Service-Token` header |
| `api.ncm.nodesource.com` | `ns-audit-dependencies` helper | `Authorization: Bearer <service token>` (or `NCM_TOKEN` env override) |
| `endoflife.date` | `ns-node-upgrade` helper (release schedule) | none |

`fetch-asset.cjs` enforces HTTPS and refuses console URLs that resolve to
loopback or private addresses (override only with the
`NSOLID_ALLOW_INSECURE_CONSOLE` environment variable, which you should not
set in production). Downloaded assets are written under `.nsolid/assets/`
in the project directory where you run the skill, and the dependency-audit
helper writes its report under the same folder.

## Switching organizations

```sh
npx -y nsolid-plugin@1.1.0 switch-org --harness claude --external-mcp
```

Switching changes the single shared login for **every** harness configured
with these credentials. Afterwards: reconnect/restart the harness you
switched, and re-run `setup --harness <harness> --external-mcp` for each
other harness to refresh its MCP headers. The `ns-switch-org` skill in this
plugin walks through this.

## Uninstall

Remove one harness's complete N|Solid installation:

```sh
npx -y nsolid-plugin@1.1.0 uninstall --harness claude
```

Use `--harness codex` or `--harness antigravity` for the other harnesses
supported here. `uninstall` is scoped to the selected harness and removes
everything the N|Solid installation created there: the skills, the MCP
entries (including the direct-HTTP entries written by `setup --external-mcp`),
any previously installed N|Solid plugin, and that harness's marketplace
registration. It
leaves other harnesses, unrelated plugins sharing the same marketplace, and
shared skills that another harness still uses, untouched.

**Refusal instead of silent collateral (preflight).** Before changing
anything, `uninstall` inspects the whole selection and refuses the entire
command, with nothing removed, when it cannot prove safe ownership: the
ownership tracking file is missing or unreadable where ownership evidence is
required, a recorded external-MCP entry no longer matches the fingerprint
recorded when it was written (edited or replaced), a marketplace registration
also feeds an unrelated plugin, or a Claude marketplace registration spans
more than one scope. The refusal lists what it found and asks you to resolve
the ambiguity and retry. These checks cover the ownership evidence the command
actually recorded — the external-MCP entry fingerprints and the shape of the
tracked selection — so they are not a general detection of every possible
unrelated local edit.

**Partial failure after a clear preflight.** Preflight resolves ownership and
scope ambiguity only; the cleanup itself then runs as successive stages — MCP
entries, skills, any previously installed N|Solid plugin, and finally the
marketplace registration. If a later plugin-removal or marketplace operation
fails, the command reports
each stage as `removed`, `not-present`, `unsupported`, or `failed`, exits
non-zero, and leaves the stages it already completed in place. Rerunning the
same `uninstall` command is safe: it preflights the new state and resumes the
remaining stages, because already-completed stages report as `not-present`.

Shared state is preserved: `uninstall` never deletes the shared credential
file (`~/.agents/.nodesource-auth.json`) or any shared runtime. Signing out is
a separate, explicit action (`logout`).

## License

MIT — see [LICENSE](LICENSE).
