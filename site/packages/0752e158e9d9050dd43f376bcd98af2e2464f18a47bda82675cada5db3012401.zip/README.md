# Flutter Skills for Claude Code

A comprehensive set of skills that teach Claude Code how to build Flutter apps and games using modern best practices (2026).

## What's Included

### App Development Skills

| Skill | Command | Description |
|-------|---------|-------------|
| **flutter-dev** | *(auto)* | Background knowledge — Riverpod 3.0, Freezed, go_router, feature-first architecture. Activates automatically when writing Dart/Flutter code. |
| **flutter-feature** | `/flutter-skills:flutter-feature reward` | Scaffold a complete feature module (model, state, provider, repository, GQL, screen, test) |
| **flutter-model** | `/flutter-skills:flutter-model user name:String age:int` | Generate Freezed data model with JSON serialization and optional state class |
| **flutter-provider** | `/flutter-skills:flutter-provider reward rewards` | Generate Riverpod 3.0 provider with AwBaseNotifier lifecycle |
| **flutter-test** | `/flutter-skills:flutter-test features/reward` | Generate tests with mockito mocks and Riverpod overrides |
| **flutter-screen** | `/flutter-skills:flutter-screen detail rewards` | Generate screen with go_router routing and Skeletonizer loading |

### Game Development Skill

| Skill | Command | Description |
|-------|---------|-------------|
| **flutter-game** | `/flutter-skills:flutter-game platformer A 2D platformer` | Complete game development guide with Flame 1.36, flame_riverpod, physics, audio, monetization |

The game skill includes 5 detailed reference documents:
- **Architecture** — FCS, scene management, Riverpod+Flame bridge patterns
- **Flame Reference** — Components, input, collision, physics (Forge2D), tilemaps, particles
- **Assets & Animations** — Rive state machines, sprite sheets, flutter_soloud audio, effects
- **Performance** — Impeller, thread merge, Wasm, object pooling, viewport culling
- **Monetization & Backend** — AdMob, IAP, Nakama multiplayer, leaderboards, save system

## Verified Package Versions (March 2026)

All package references have been verified against pub.dev:

| Package | Version | Purpose |
|---------|---------|---------|
| `flame` | 1.36.0 | Core 2D game engine |
| `flame_riverpod` | 5.5.3 | Riverpod bridge for Flame |
| `flame_forge2d` | 0.19.2+5 | Box2D physics |
| `flame_tiled` | 3.1.0 | Tiled map editor support |
| `flame_audio` | 2.12.0 | Simple game audio |
| `flame_rive` | 1.11.0 | Rive animation integration |
| `flame_test` | 2.2.3 | Testing utilities |
| `flutter_soloud` | 3.4.10 | Advanced audio (C++ SoLoud, 3D, effects) |
| `rive` | 0.13.20 | Rive animations with State Machines |
| `google_mobile_ads` | 7.0.0 | AdMob ads |
| `in_app_purchase` | 3.2.3 | In-app purchases |
| `nakama` | 1.3.0 | Multiplayer game server |

## Installation

```bash
claude plugin install github:YOUR_USERNAME/claude-flutter-skills
```

Or test locally:

```bash
claude --plugin-dir /path/to/claude-flutter-skills
```

## Architecture Patterns

These skills encode real-world patterns from production Flutter apps:

- **Feature-first architecture** with strict module isolation
- **Riverpod 3.0** with `@riverpod` code generation, `AwBaseNotifier` lifecycle
- **Freezed** models with `AwBaseState`, `@JsonKey`, `@Default`, extensions
- **go_router** with static `routePath`/`routeName`, type-safe navigation helpers
- **GraphQL** via `AwGqlApiService` with repository pattern
- **Testing** with `ProviderContainer` overrides, `@GenerateMocks`, test helpers
- **RTL support** with `EdgeInsetsDirectional`, `AlignmentDirectional`
- **Game development** with Flame Component System, flame_riverpod bridge, overlay HUD

## Customization

These skills are designed as starting points. Fork and adapt:

- Edit `flutter-dev/SKILL.md` to match your project's conventions
- Modify model/provider/screen templates for your naming patterns
- Add your own GraphQL/REST API patterns
- Extend the game skill with your preferred packages

## License

MIT
