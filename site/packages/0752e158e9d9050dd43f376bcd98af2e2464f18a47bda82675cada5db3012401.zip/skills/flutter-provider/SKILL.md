---
name: flutter-provider
description: Generate a Riverpod 3.0 provider with notifier, state management, and AwBaseNotifier lifecycle. Use when creating state management for features.
argument-hint: "[provider_name] [feature_name]"
allowed-tools: Read, Write, Edit, Bash(dart run build_runner *)
---

# Generate Riverpod Provider: $ARGUMENTS

Parse arguments: first arg is provider name, second is the feature it belongs to.

## Steps

### 1. Check prerequisites
- Verify the feature directory exists at `lib/features/{feature}/`
- Verify the state model exists. If not, create it first (see flutter-model skill pattern)
- Verify the repository exists. If not, create it first

### 2. Create the provider

**File:** `lib/features/{feature}/data/providers/{name}_provider.dart`

```dart
import 'package:aworld/common/data/providers/_aw_base_notifier.dart';
import 'package:aworld/common/data/providers/_aw_base_notifier_status.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../models/states/{name}_state.dart';
import '../repositories/{name}_repository.dart';

part '{name}_provider.g.dart';

@Riverpod(keepAlive: true)
class {PascalName}Notifier extends _${PascalName}Notifier with AwBaseNotifier {
  @override
  {PascalName}State build() => const {PascalName}State();

  // Lazy dependency getters — NEVER call ref.read() in build()
  {PascalName}Repository get _repository => ref.read({camelName}RepositoryProvider);

  @override
  Future<void> init() async {
    state = state.copyWith(status: AwBaseNotifierStatus.loading);
    try {
      final items = await _repository.getAll();
      state = state.copyWith(
        items: items,
        status: AwBaseNotifierStatus.ready,
      );
    } catch (e) {
      state = state.copyWith(
        status: AwBaseNotifierStatus.error,
        errorMessage: e.toString(),
      );
    }
  }

  @override
  void reset() => state = const {PascalName}State();

  /// Load next page (pagination)
  Future<void> loadMore() async {
    if (!state.hasMore || state.isLoadingNext) return;
    state = state.copyWith(status: AwBaseNotifierStatus.loadingNext);
    try {
      final response = await _repository.getAll(nextToken: state.nextToken);
      state = state.copyWith(
        items: [...state.items, ...response.items],
        nextToken: response.nextToken,
        status: AwBaseNotifierStatus.ready,
      );
    } catch (e) {
      state = state.copyWith(status: AwBaseNotifierStatus.ready);
    }
  }
}
```

### 3. Provider variations

**Simple provider (no notifier, just a value):**
```dart
@riverpod
{Type} {camelName}(Ref ref) => {Type}();
```

**Family provider (parameterized):**
```dart
@riverpod
class {PascalName} extends _${PascalName} {
  @override
  {State} build(String id) => const {State}();
  // Methods...
}
```

**Non-keepAlive provider (auto-disposed):**
```dart
@riverpod  // No keepAlive — disposed when no longer watched
class {PascalName} extends _${PascalName} {
  @override
  {State} build() => const {State}();
}
```

### 4. Key patterns to follow

- **keepAlive:** Use `@Riverpod(keepAlive: true)` for global persistent state (user, auth, actions). Use plain `@riverpod` for screen-scoped state.
- **Dependencies:** Always use lazy getters (`get _repo => ref.read(...)`) for dependencies. Never `ref.read()` in `build()`.
- **State updates:** Always use `state = state.copyWith(...)`. Never mutate state directly.
- **Error handling:** Wrap async operations in try-catch, set `status: AwBaseNotifierStatus.error`.
- **Loading states:** Set loading before async operations, ready/error after.
- **Timeouts:** Use `.timeout(Duration(seconds: 10))` for critical init operations.

### 5. Run code generation
```sh
dart run build_runner build --delete-conflicting-outputs
```

### 6. Verify
- Check that `{name}_provider.g.dart` was generated
- Verify imports are correct
- Run `dart analyze` to check for errors
