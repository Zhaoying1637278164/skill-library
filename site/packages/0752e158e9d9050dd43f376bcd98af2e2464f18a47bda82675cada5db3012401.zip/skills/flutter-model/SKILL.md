---
name: flutter-model
description: Generate a Freezed data model with JSON serialization, optional state class, and factory. Use when creating new data models or DTOs.
argument-hint: "[model_name] [field1:type field2:type ...]"
allowed-tools: Read, Write, Edit, Bash(dart run build_runner *)
---

# Generate Freezed Model: $ARGUMENTS

Parse the arguments to extract the model name and fields. Example: `user_profile name:String age:int email:String? isActive:bool`

## Rules

1. **Determine the correct location:**
   - If the model belongs to a feature → `lib/features/{feature}/data/models/`
   - If shared across features → `lib/common/data/models/`
   - Ask the user if unclear

2. **Create the model file** following this exact pattern:

```dart
import 'package:freezed_annotation/freezed_annotation.dart';

part '{snake_name}.freezed.dart';
part '{snake_name}.g.dart';

@freezed
abstract class {PascalName} with _${PascalName} {
  const factory {PascalName}({
    // required fields first, then optional with @Default
    required String id,
    @Default('') String name,
    @JsonKey(name: 'server_field_name') String? mappedField,
    @JsonKey(includeToJson: false) DateTime? readOnlyField,
    @Default(false) bool isActive,
    @Default([]) List<String> items,
  }) = _{PascalName};

  factory {PascalName}.fromJson(Map<String, dynamic> json) =>
      _${PascalName}FromJson(json);
}
```

3. **Add private constructor** only if custom methods are needed:
```dart
const {PascalName}._(); // Add BEFORE factory constructors
```

4. **Use extensions** for domain logic instead of polluting the model:
```dart
extension {PascalName}Extension on {PascalName} {
  {PascalName} merge({PascalName} other) { ... }
  bool get isValid => ...;
}
```

5. **Field conventions:**
   - Use `@Default(value)` for optional fields with defaults
   - Use `@JsonKey(name: 'snake_case')` when API field names differ
   - Use `@JsonKey(includeToJson: false)` for read-only fields
   - Use `DateTime?` (nullable) for optional dates
   - Use specific types, never `dynamic`
   - Enum types: define in same file or separate file if shared

6. **If a state model is needed**, also create `states/{snake_name}_state.dart`:
```dart
@freezed
abstract class {PascalName}State with _${PascalName}State implements AwBaseState {
  const {PascalName}State._();

  const factory {PascalName}State({
    @Default(AwBaseNotifierStatus.idle) AwBaseNotifierStatus status,
    @Default({PascalName}()) {PascalName} item,
    @Default([]) List<{PascalName}> items,
    String? nextToken,
    String? errorMessage,
  }) = _{PascalName}State;

  @override
  bool get isLoading => status == AwBaseNotifierStatus.loading;
  @override
  bool get isLoadingNext => status == AwBaseNotifierStatus.loadingNext;
  @override
  bool get isSending => status == AwBaseNotifierStatus.sending;
  @override
  bool get isReady => status == AwBaseNotifierStatus.ready;

  bool get hasMore => nextToken != null;
}
```

7. **Run code generation** after creating:
```sh
dart run build_runner build --delete-conflicting-outputs
```

8. **Verify** the generated `.freezed.dart` and `.g.dart` files compile without errors.
