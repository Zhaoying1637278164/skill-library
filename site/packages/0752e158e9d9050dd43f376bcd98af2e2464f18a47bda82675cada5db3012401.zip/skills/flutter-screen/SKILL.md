---
name: flutter-screen
description: Generate a Flutter screen with go_router routing, Riverpod state management, and proper lifecycle. Use when creating new pages/screens.
argument-hint: "[screen_name] [feature_name]"
allowed-tools: Read, Write, Edit
---

# Generate Flutter Screen: $ARGUMENTS

Parse arguments: first arg is screen name, second is the feature it belongs to.

## Step 1: Determine screen type

Ask the user or infer:
- **Detail screen** (loads data by ID) → needs route params, initState loading
- **List screen** (shows a list) → needs pagination, refresh
- **Form screen** (user input) → needs form validation, submit
- **Simple screen** (static content) → minimal state

## Step 2: Create the screen

**File:** `lib/features/{feature}/views/screens/{name}_screen.dart`

### Detail Screen (most common)

```dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:aworld/common/views/widgets/aw_app_bar.dart';
import '../../data/providers/{name}_provider.dart';

class {PascalName}Screen extends ConsumerStatefulWidget {
  static const routePath = '/{kebab-name}/:id';
  static const routeName = '/{kebab-name}';

  /// Push this screen onto the navigation stack
  static void push(BuildContext context, {required String id}) {
    context.pushNamed(routeName, pathParameters: {'id': id});
  }

  final String id;
  const {PascalName}Screen({required this.id, super.key});

  @override
  ConsumerState<{PascalName}Screen> createState() => _{PascalName}ScreenState();
}

class _{PascalName}ScreenState extends ConsumerState<{PascalName}Screen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      ref.read({camelName}NotifierProvider.notifier).load(widget.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch({camelName}NotifierProvider);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AwAppBar(titleString: '', frostedGlass: true),
      body: Skeletonizer(
        enabled: state.isLoading,
        child: RefreshIndicator(
          onRefresh: () async {
            await ref.read({camelName}NotifierProvider.notifier).refresh();
          },
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Content here
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```

### List Screen

```dart
class {PascalName}Screen extends ConsumerStatefulWidget {
  static const routePath = '/{kebab-name}';
  static const routeName = '/{kebab-name}';

  const {PascalName}Screen({super.key});

  @override
  ConsumerState<{PascalName}Screen> createState() => _{PascalName}ScreenState();
}

class _{PascalName}ScreenState extends ConsumerState<{PascalName}Screen> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    Future.delayed(Duration.zero, () {
      ref.read({camelName}NotifierProvider.notifier).init();
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      ref.read({camelName}NotifierProvider.notifier).loadMore();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch({camelName}NotifierProvider);

    return Scaffold(
      appBar: AwAppBar(titleString: context.translator.{name}_title),
      body: RefreshIndicator(
        onRefresh: () async {
          await ref.read({camelName}NotifierProvider.notifier).refresh();
        },
        child: Skeletonizer(
          enabled: state.isLoading,
          child: ListView.builder(
            controller: _scrollController,
            itemCount: state.items.length + (state.isLoadingNext ? 1 : 0),
            itemBuilder: (context, index) {
              if (index == state.items.length) {
                return const Center(child: CircularProgressIndicator());
              }
              final item = state.items[index];
              return ListTile(title: Text(item.id));
            },
          ),
        ),
      ),
    );
  }
}
```

## Step 3: Register the route

Add to `lib/common/data/providers/routing_provider.dart`:

```dart
GoRoute(
  path: {PascalName}Screen.routePath,
  name: {PascalName}Screen.routeName,
  builder: (context, state) {
    final id = state.pathParameters['id']!;
    return {PascalName}Screen(id: id);
  },
),
```

Place it inside the appropriate `ShellRoute` if it needs bottom navigation, or at root level if it's a modal/fullscreen page.

## Step 4: Screen conventions

- **Always** define `routePath` and `routeName` as static constants
- **Always** add a static `push()` method for type-safe navigation
- Use `ConsumerStatefulWidget` when you need `initState`, lifecycle, or controllers
- Use `ConsumerWidget` for simple screens with no lifecycle needs
- Load data in `initState` via `Future.delayed(Duration.zero, () { ... })`
- Use `Skeletonizer` for loading states (not CircularProgressIndicator alone)
- Use `RefreshIndicator` for pull-to-refresh
- Use `AwAppBar` instead of raw `AppBar`
- Use `AwSecureScreen` wrapper if the screen shows sensitive data
- Use `EdgeInsetsDirectional` for RTL support in padding
- Access translations via `context.translator`
- Access theme colors via `context.theme.appColors`
