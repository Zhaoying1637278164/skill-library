# Game Architecture & Patterns

## Core Architecture: Flame Component System (FCS)

Flame uses an **Entity Component System** where everything is a `Component`. Components form a tree (like Flutter's widget tree) with parent-child relationships.

```
FlameGame (root)
├── World
│   ├── Player (SpriteAnimationComponent)
│   ├── EnemyManager (Component)
│   │   ├── Enemy1 (SpriteComponent)
│   │   └── Enemy2 (SpriteComponent)
│   ├── TileMapComponent
│   └── ParallaxComponent
├── CameraComponent
└── HudComponent (overlay via Flutter widgets)
```

### Rules:
- **Every game entity is a Component** — player, enemies, bullets, UI elements, managers
- **Components have lifecycle:** `onLoad()` → `update(dt)` → `render(canvas)` → `onRemove()`
- **Use `onLoad()` for async initialization** (loading sprites, sounds)
- **Use `update(dt)` for game logic** — `dt` is delta time in seconds
- **Use mixins** for behavior: `HasCollisionDetection`, `KeyboardHandler`, `DragCallbacks`, etc.

---

## Main Game Class

```dart
import 'package:flame/game.dart';
import 'package:flame/events.dart';
import 'package:flame/components.dart';

class MyGame extends FlameGame
    with HasCollisionDetection, HasKeyboardHandlerComponents {

  late final Player player;
  late final World gameWorld;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Load shared assets once
    await images.loadAll([
      'player_spritesheet.png',
      'enemies_spritesheet.png',
      'tileset.png',
    ]);

    // Create the game world
    gameWorld = World();
    add(gameWorld);

    // Add camera following player
    player = Player();
    gameWorld.add(player);

    final camera = CameraComponent(world: gameWorld)
      ..viewfinder.anchor = Anchor.center
      ..follow(player);
    add(camera);
  }

  @override
  void update(double dt) {
    super.update(dt);
    // Global game logic here (score, game over check, etc.)
  }

  // Pause/resume
  void togglePause() {
    if (paused) {
      resumeEngine();
    } else {
      pauseEngine();
      overlays.add('PauseMenu'); // Show Flutter overlay
    }
  }
}
```

---

## Scene / Level Management

### Pattern: World-based scenes

```dart
/// Base class for all game scenes
abstract class GameScene extends World {
  /// Called when entering this scene
  Future<void> onEnter();

  /// Called when leaving this scene
  void onExit();
}

class MenuScene extends GameScene {
  @override
  Future<void> onEnter() async {
    // Setup menu components
  }

  @override
  void onExit() {
    // Cleanup
  }
}

class PlayScene extends GameScene {
  final int level;
  PlayScene({required this.level});

  @override
  Future<void> onEnter() async {
    // Load level data
    // Spawn player, enemies, etc.
  }

  @override
  void onExit() {
    removeAll(children);
  }
}

// In your FlameGame:
class MyGame extends FlameGame {
  GameScene? _currentScene;

  Future<void> switchScene(GameScene newScene) async {
    _currentScene?.onExit();
    _currentScene?.removeFromParent();

    _currentScene = newScene;
    add(newScene);
    await newScene.onEnter();

    // Update camera to follow new world
    camera.world = newScene;
  }
}
```

---

## State Management: flame_riverpod (Recommended)

The official `flame_riverpod` package (5.5.3) provides a direct bridge between Flame components and Riverpod providers. This is the recommended approach for AWorld since the project already uses Riverpod.

### Setup

```yaml
dependencies:
  flame: ^1.36.0
  flame_riverpod: ^5.5.3
  flutter_riverpod: ^2.6.0  # or your current Riverpod version
```

### Three key pieces:

1. **`RiverpodAwareGameWidget`** — replaces `GameWidget`
2. **`RiverpodGameMixin`** — mixin on your `FlameGame` class
3. **`RiverpodComponentMixin`** — mixin on components that need provider access

### Game State Provider (Riverpod — project standard)

```dart
// Provider for game state (persisted, accessible from both Flame and Flutter)
@Riverpod(keepAlive: true)
class GameState extends _$GameState {
  @override
  GameStateModel build() => const GameStateModel();

  void addScore(int points) {
    state = state.copyWith(score: state.score + points);
  }

  void loseLife() {
    state = state.copyWith(lives: state.lives - 1);
    if (state.lives <= 0) {
      state = state.copyWith(status: GameStatus.gameOver);
    }
  }

  void reset() => state = const GameStateModel();
}

@freezed
abstract class GameStateModel with _$GameStateModel {
  const factory GameStateModel({
    @Default(0) int score,
    @Default(3) int lives,
    @Default(1) int level,
    @Default(GameStatus.menu) GameStatus status,
  }) = _GameStateModel;
}

enum GameStatus { menu, playing, paused, gameOver, victory }
```

### Game Class with RiverpodGameMixin

```dart
class MyGame extends FlameGame
    with HasCollisionDetection, RiverpodGameMixin {

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    world.add(Player());
    world.add(ScoreDisplay());
    overlays.add('HUD');
  }
}
```

### Screen hosting the game (RiverpodAwareGameWidget)

```dart
class GameScreen extends ConsumerStatefulWidget {
  static const routeName = '/game';
  const GameScreen({super.key});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen> {
  late final MyGame _game = MyGame();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RiverpodAwareGameWidget<MyGame>(
        game: _game,
        overlayBuilderMap: {
          'HUD': (context, game) => const GameHudOverlay(),
          'PauseMenu': (context, game) => PauseMenuOverlay(
            onResume: () {
              game.overlays.remove('PauseMenu');
              game.resumeEngine();
            },
          ),
          'GameOver': (context, game) => GameOverOverlay(
            onRestart: () {
              ref.read(gameStateProvider.notifier).reset();
              game.overlays.remove('GameOver');
            },
          ),
        },
        initialActiveOverlays: const ['HUD'],
      ),
    );
  }
}
```

### Accessing Providers FROM Flame Components

Use `RiverpodComponentMixin` on any component. Register subscriptions in `onMount()` via `addToGameWidgetBuild()` — subscriptions auto-dispose when component is removed:

```dart
class ScoreDisplay extends TextComponent with RiverpodComponentMixin {
  @override
  void onMount() {
    // Register BEFORE super.onMount()
    addToGameWidgetBuild(() {
      // ref.watch — rebuilds when value changes
      final score = ref.watch(gameStateProvider.select((s) => s.score));
      text = 'Score: $score';
    });

    // ref.listen — react to changes with callback
    addToGameWidgetBuild(() {
      ref.listen(gameStateProvider.select((s) => s.status), (prev, next) {
        if (next == GameStatus.gameOver) {
          game.overlays.add('GameOver');
          game.pauseEngine();
        }
      });
    });

    super.onMount();
  }
}

// Writing to providers from game components
class Collectible extends SpriteComponent
    with CollisionCallbacks, RiverpodComponentMixin {

  @override
  void onCollisionStart(Set<Vector2> points, PositionComponent other) {
    if (other is Player) {
      // Mutate Riverpod state from Flame component
      ref.read(gameStateProvider.notifier).addScore(10);
      removeFromParent();
    }
  }
}
```

### Flutter Overlay Widgets (standard Riverpod access)

Overlay widgets are normal Flutter widgets — use `ConsumerWidget` to access providers:

```dart
class GameHudOverlay extends ConsumerWidget {
  const GameHudOverlay({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final score = ref.watch(gameStateProvider.select((s) => s.score));
    final lives = ref.watch(gameStateProvider.select((s) => s.lives));

    return SafeArea(
      child: Padding(
        padding: const EdgeInsetsDirectional.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Score: $score', style: const TextStyle(color: Colors.white, fontSize: 20)),
            Row(
              children: List.generate(
                lives,
                (_) => const Icon(Icons.favorite, color: Colors.red, size: 24),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

### Architecture Pattern Summary

Both Flame components and Flutter overlay widgets access the SAME Riverpod providers:

```
┌─────────────────────────────────────────┐
│  Riverpod Providers (single truth)      │
│  GameState, Settings, Progress          │
├──────────────┬──────────────────────────┤
│ Flame Side   │ Flutter Side             │
│              │                          │
│ Components   │ Overlay Widgets          │
│ (ref.watch)  │ (ref.watch)              │
│ (ref.read)   │ (ref.read)              │
│ (ref.listen) │                          │
│              │ HUD, Menus, Dialogs      │
│ Player,      │ use ConsumerWidget       │
│ Enemies,     │ with standard Riverpod   │
│ Collectibles │                          │
└──────────────┴──────────────────────────┘
```

---

## Overlay System (Flutter widgets on top of Flame)

Overlays are the bridge between Flame rendering and Flutter widgets. Use them for:
- **HUD** (score, lives, minimap)
- **Menus** (pause, game over, settings)
- **Dialogs** (shop, inventory, achievements)

```dart
GameWidget(
  game: myGame,
  overlayBuilderMap: {
    'HUD': (context, game) => Positioned(
      top: 16,
      left: 16,
      child: Consumer(
        builder: (context, ref, _) {
          final state = ref.watch(gameStateProvider);
          return Row(
            children: [
              Text('Score: ${state.score}', style: gameTextStyle),
              const SizedBox(width: 16),
              Row(
                children: List.generate(
                  state.lives,
                  (_) => const Icon(Icons.favorite, color: Colors.red, size: 24),
                ),
              ),
            ],
          );
        },
      ),
    ),
    'PauseMenu': (context, game) => Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('PAUSED', style: TextStyle(fontSize: 32)),
              ElevatedButton(
                onPressed: () {
                  game.overlays.remove('PauseMenu');
                  game.resumeEngine();
                },
                child: const Text('Resume'),
              ),
            ],
          ),
        ),
      ),
    ),
  },
  initialActiveOverlays: const ['HUD'],
);

// In game code, show/hide overlays:
overlays.add('PauseMenu');
overlays.remove('HUD');
```

---

## Game Loop Best Practices

```dart
class Player extends SpriteAnimationComponent with HasGameRef<MyGame> {
  static const double speed = 200.0; // pixels per second
  Vector2 velocity = Vector2.zero();

  @override
  void update(double dt) {
    super.update(dt);

    // ALWAYS multiply movement by dt for frame-rate independence
    position += velocity * dt;

    // Clamp to world bounds
    position.clamp(
      Vector2.zero(),
      gameRef.size - size,
    );
  }
}
```

### Delta Time Rules:
- **Always multiply by `dt`** — ensures consistent behavior at any frame rate
- **Cap `dt`** to avoid physics explosions after pauses: `dt = dt.clamp(0, 0.05)`
- **Use fixed timestep** for physics-heavy games:

```dart
class MyGame extends FlameGame {
  static const double fixedDt = 1.0 / 60.0; // 60 Hz physics
  double _accumulator = 0;

  @override
  void update(double dt) {
    _accumulator += dt;
    while (_accumulator >= fixedDt) {
      _fixedUpdate(fixedDt);
      _accumulator -= fixedDt;
    }
    super.update(dt);
  }

  void _fixedUpdate(double dt) {
    // Physics calculations here
  }
}
```

---

## Save/Load Game State

```dart
// Repository for persisting game progress
@riverpod
GameRepository gameRepository(Ref ref) => GameRepository();

class GameRepository {
  static const _key = 'game_progress';

  Future<void> saveProgress(GameProgress progress) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(progress.toJson()));
  }

  Future<GameProgress?> loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_key);
    if (data == null) return null;
    return GameProgress.fromJson(jsonDecode(data));
  }
}

@freezed
abstract class GameProgress with _$GameProgress {
  const factory GameProgress({
    @Default(1) int currentLevel,
    @Default(0) int highScore,
    @Default(0) int totalCoins,
    @Default({}) Map<int, bool> completedLevels,
    DateTime? lastPlayed,
  }) = _GameProgress;

  factory GameProgress.fromJson(Map<String, dynamic> json) =>
      _$GameProgressFromJson(json);
}
```
