# Flame Engine Reference

## Package Overview (Verified March 2026)

Core and commonly used Flame packages (all by flame-engine.org, MIT license):

| Package | Version | Purpose |
|---------|---------|---------|
| `flame` | 1.36.0 | Core 2D engine — FCS, rendering, input, camera, effects |
| `flame_riverpod` | 5.5.3 | Riverpod bridge — provider access in components |
| `flame_forge2d` | 0.19.2+5 | Box2D physics — rigid bodies, joints, collision |
| `flame_tiled` | 3.1.0 | Tiled map editor `.tmx` support |
| `flame_audio` | 2.12.0 | Simple audio (wraps audioplayers) |
| `flame_rive` | 1.11.0 | Rive animation integration |
| `flame_bloc` | 1.12.22 | Bloc/Cubit state in components |
| `flame_test` | 2.2.3 | Testing utilities |
| `flame_svg` | 1.12.0 | SVG rendering |
| `flame_behaviors` | 1.3.4 | Entity/Behavior separation |
| `flame_noise` | — | Procedural noise generation (Perlin, simplex) |
| `flame_isolate` | — | Heavy computation offloading |

```yaml
# pubspec.yaml — recommended game setup
dependencies:
  flame: ^1.36.0
  flame_riverpod: ^5.5.3
  flame_audio: ^2.12.0
  flame_forge2d: ^0.19.2
  flame_tiled: ^3.1.0
  flame_rive: ^1.11.0
  flutter_soloud: ^3.4.10  # Advanced audio (3D, effects)
```

### Flame 1.36.0 Highlights
- **`ComponentPool`** — built-in object pooling for bullets, particles, etc. (reduces GC pressure)
- **`IconComponent`** — render Flutter `IconData` in game
- **`dispose()`** method on `FlameGame` — proper cleanup
- **Hot reload propagation** through component tree
- **`buildContext`** available during `onLoad` and `onMount`

---

## Components

### SpriteComponent (Static image)

```dart
class Obstacle extends SpriteComponent with HasGameRef {
  Obstacle({required Vector2 position})
      : super(
          position: position,
          size: Vector2(64, 64),
          anchor: Anchor.center,
        );

  @override
  Future<void> onLoad() async {
    sprite = await gameRef.loadSprite('obstacle.png');
  }
}
```

### SpriteAnimationComponent (Animated sprite)

```dart
class Player extends SpriteAnimationComponent
    with HasGameRef, KeyboardHandler, CollisionCallbacks {

  late final SpriteAnimation idleAnimation;
  late final SpriteAnimation runAnimation;
  late final SpriteAnimation jumpAnimation;

  Player() : super(size: Vector2(64, 64), anchor: Anchor.bottomCenter);

  @override
  Future<void> onLoad() async {
    // Load from spritesheet
    final spriteSheet = SpriteSheet(
      image: gameRef.images.fromCache('player_spritesheet.png'),
      srcSize: Vector2(32, 32),
    );

    idleAnimation = spriteSheet.createAnimation(row: 0, stepTime: 0.15, from: 0, to: 4);
    runAnimation = spriteSheet.createAnimation(row: 1, stepTime: 0.1, from: 0, to: 8);
    jumpAnimation = spriteSheet.createAnimation(row: 2, stepTime: 0.15, from: 0, to: 6, loop: false);

    animation = idleAnimation;

    // Add hitbox for collision detection
    add(RectangleHitbox(size: Vector2(48, 60), position: Vector2(8, 4)));
  }

  void setAnimation(SpriteAnimation anim) {
    if (animation != anim) {
      animation = anim;
    }
  }
}
```

### PositionComponent (Base for custom rendering)

```dart
class HealthBar extends PositionComponent {
  double maxHealth;
  double currentHealth;

  HealthBar({
    required this.maxHealth,
    required this.currentHealth,
    required Vector2 position,
  }) : super(position: position, size: Vector2(50, 6));

  @override
  void render(Canvas canvas) {
    // Background
    canvas.drawRRect(
      RRect.fromRectAndRadius(size.toRect(), const Radius.circular(3)),
      Paint()..color = const Color(0xFF333333),
    );

    // Health fill
    final healthPercent = (currentHealth / maxHealth).clamp(0.0, 1.0);
    final healthColor = healthPercent > 0.5
        ? const Color(0xFF00FF00)
        : healthPercent > 0.25
            ? const Color(0xFFFFFF00)
            : const Color(0xFFFF0000);

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.x * healthPercent, size.y),
        const Radius.circular(3),
      ),
      Paint()..color = healthColor,
    );
  }
}
```

---

## Input Handling

### Keyboard

```dart
class Player extends SpriteAnimationComponent with KeyboardHandler {
  final Set<LogicalKeyboardKey> _keysPressed = {};

  @override
  bool onKeyEvent(KeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    _keysPressed.clear();
    _keysPressed.addAll(keysPressed);
    return true; // handled
  }

  @override
  void update(double dt) {
    super.update(dt);
    final direction = Vector2.zero();

    if (_keysPressed.contains(LogicalKeyboardKey.arrowLeft)) {
      direction.x = -1;
    }
    if (_keysPressed.contains(LogicalKeyboardKey.arrowRight)) {
      direction.x = 1;
    }
    if (_keysPressed.contains(LogicalKeyboardKey.space)) {
      jump();
    }

    position += direction.normalized() * speed * dt;
  }
}
```

### Touch / Tap / Drag

```dart
class DraggableItem extends SpriteComponent with DragCallbacks {
  @override
  void onDragStart(DragStartEvent event) {
    priority = 100; // Bring to front
  }

  @override
  void onDragUpdate(DragUpdateEvent event) {
    position += event.localDelta;
  }

  @override
  void onDragEnd(DragEndEvent event) {
    priority = 0;
    snapToGrid();
  }
}

class TappableEnemy extends SpriteComponent with TapCallbacks {
  @override
  void onTapDown(TapDownEvent event) {
    takeDamage(10);
  }
}
```

### Joystick (Mobile controls)

```dart
class MyGame extends FlameGame {
  @override
  Future<void> onLoad() async {
    final joystick = JoystickComponent(
      knob: CircleComponent(radius: 20, paint: Paint()..color = Colors.white),
      background: CircleComponent(radius: 50, paint: Paint()..color = Colors.white24),
      margin: const EdgeInsets.only(left: 40, bottom: 40),
    );

    final player = Player(joystick: joystick);
    world.add(player);
    add(joystick); // Add to game, not world (stays on screen)
  }
}

class Player extends SpriteComponent {
  final JoystickComponent joystick;
  Player({required this.joystick});

  @override
  void update(double dt) {
    super.update(dt);
    if (!joystick.delta.isZero()) {
      position += joystick.relativeDelta * speed * dt;
      angle = joystick.delta.screenAngle();
    }
  }
}
```

---

## Collision Detection

```dart
// Enable on the game
class MyGame extends FlameGame with HasCollisionDetection { ... }

// Add hitboxes to components
class Player extends SpriteComponent with CollisionCallbacks {
  @override
  Future<void> onLoad() async {
    add(RectangleHitbox()); // Full component size
    // Or custom size:
    // add(CircleHitbox(radius: 20, position: Vector2(12, 12)));
    // add(PolygonHitbox([Vector2(0, 0), Vector2(64, 0), Vector2(32, 64)]));
  }

  @override
  void onCollisionStart(Set<Vector2> points, PositionComponent other) {
    if (other is Enemy) {
      takeDamage(other.attackPower);
    }
    if (other is Collectible) {
      other.collect();
    }
  }

  @override
  void onCollisionEnd(PositionComponent other) {
    // Collision ended
  }
}
```

### Forge2D Physics (realistic physics)

```dart
import 'package:flame_forge2d/flame_forge2d.dart';

class PhysicsGame extends Forge2DGame {
  PhysicsGame() : super(gravity: Vector2(0, 10)); // Earth gravity

  @override
  Future<void> onLoad() async {
    // Create ground
    add(Ground(size: Vector2(worldSize.x, 2)));

    // Create physics ball
    add(PhysicsBall(position: Vector2(worldSize.x / 2, 5)));
  }
}

class PhysicsBall extends BodyComponent {
  final Vector2 initialPosition;

  PhysicsBall({required this.initialPosition});

  @override
  Body createBody() {
    final shape = CircleShape()..radius = 1.0;
    final fixtureDef = FixtureDef(shape)
      ..restitution = 0.8  // Bounciness
      ..density = 1.0
      ..friction = 0.5;
    final bodyDef = BodyDef(
      position: initialPosition,
      type: BodyType.dynamic,
    );
    return world.createBody(bodyDef)..createFixture(fixtureDef);
  }
}
```

---

## Camera & Viewport

```dart
class MyGame extends FlameGame {
  @override
  Future<void> onLoad() async {
    final world = World();
    add(world);

    final player = Player();
    world.add(player);

    // Camera follows player with smooth lerp
    final camera = CameraComponent(world: world)
      ..viewfinder.anchor = Anchor.center
      ..viewfinder.zoom = 2.0  // 2x zoom
      ..follow(player, maxSpeed: 200, snap: false);
    add(camera);

    // Set world bounds (camera won't go beyond)
    camera.setBounds(
      Rectangle.fromLTWH(0, 0, levelWidth, levelHeight),
    );
  }
}
```

---

## Tile Maps

```dart
import 'package:flame_tiled/flame_tiled.dart';

class LevelScene extends World {
  @override
  Future<void> onLoad() async {
    // Load Tiled map
    final tiledMap = await TiledComponent.load(
      'level_1.tmx',
      Vector2.all(16), // tile size
    );
    add(tiledMap);

    // Access object layers for spawn points, triggers, etc.
    final spawnLayer = tiledMap.tileMap.getLayer<ObjectGroup>('spawns');
    for (final obj in spawnLayer?.objects ?? []) {
      if (obj.class_ == 'player_spawn') {
        add(Player(position: Vector2(obj.x, obj.y)));
      }
      if (obj.class_ == 'enemy_spawn') {
        add(Enemy(position: Vector2(obj.x, obj.y)));
      }
    }

    // Collision layer
    final collisionLayer = tiledMap.tileMap.getLayer<ObjectGroup>('collision');
    for (final obj in collisionLayer?.objects ?? []) {
      add(CollisionBlock(
        position: Vector2(obj.x, obj.y),
        size: Vector2(obj.width, obj.height),
      ));
    }
  }
}
```

---

## Particle Effects

```dart
class Explosion extends Component with HasGameRef {
  final Vector2 position;
  Explosion({required this.position});

  @override
  Future<void> onLoad() async {
    final particle = ParticleSystemComponent(
      particle: AcceleratedParticle(
        speed: Vector2(0, -100),
        acceleration: Vector2(0, 200),
        child: ComponentParticle(
          component: CircleComponent(
            radius: 3,
            paint: Paint()..color = Colors.orange,
          ),
        ),
      ),
      position: position,
    );
    gameRef.add(particle);
  }
}

// Composed particle effect
ParticleSystemComponent createExplosion(Vector2 pos) {
  return ParticleSystemComponent(
    position: pos,
    particle: Particle.generate(
      count: 20,
      lifespan: 0.8,
      generator: (i) => AcceleratedParticle(
        speed: Vector2(
          Random().nextDouble() * 200 - 100,
          Random().nextDouble() * -200,
        ),
        acceleration: Vector2(0, 300),
        child: CircleParticle(
          radius: 2.0 + Random().nextDouble() * 3,
          paint: Paint()
            ..color = [Colors.red, Colors.orange, Colors.yellow][i % 3],
        ),
      ),
    ),
  );
}
```

---

## Spawners & Object Pooling

### Built-in ComponentPool (Flame 1.36.0+)

Flame now has a built-in `ComponentPool` for efficient object recycling:

```dart
// Use ComponentPool for frequently created/destroyed objects
final bulletPool = ComponentPool<Bullet>(
  createComponent: () => Bullet(),
);

// Acquire from pool (reuses existing or creates new)
final bullet = bulletPool.acquire();
bullet.position = spawnPosition;
bullet.direction = aimDirection;
world.add(bullet);

// Return to pool when done (instead of removeFromParent)
bulletPool.release(bullet);
```

### Manual Pool (for custom logic)

```dart
class BulletPool extends Component with HasGameRef {
  final List<Bullet> _pool = [];
  static const int poolSize = 50;

  @override
  Future<void> onLoad() async {
    for (int i = 0; i < poolSize; i++) {
      final bullet = Bullet()..removeFromParent();
      _pool.add(bullet);
    }
  }

  Bullet? spawn(Vector2 position, Vector2 direction) {
    if (_pool.isEmpty) return null;
    final bullet = _pool.removeLast();
    bullet
      ..position = position
      ..direction = direction
      ..isActive = true;
    gameRef.world.add(bullet);
    return bullet;
  }

  void recycle(Bullet bullet) {
    bullet
      ..removeFromParent()
      ..isActive = false;
    _pool.add(bullet);
  }
}
```

---

## Testing Flame Components (flame_test 2.2.3)

```dart
import 'package:flame_test/flame_test.dart';
import 'package:flutter_test/flutter_test.dart';

// Create a game tester
final gameTester = FlameTester(MyGame.new);

void main() {
  // Test with full game context
  gameTester.testGameWidget(
    'player spawns at correct position',
    setUp: (game, tester) async {
      await game.ready();
    },
    verify: (game, tester) async {
      final player = game.world.children.whereType<Player>().first;
      expect(player.position, Vector2(100, 100));
    },
  );

  // Test individual components
  testWithFlameGame<MyGame>(
    'enemy takes damage on collision',
    (game) async {
      final enemy = Enemy();
      await game.world.add(enemy);
      await game.ready();

      enemy.takeDamage(10);
      expect(enemy.health, 90);
    },
  );
}
```

Enable visual debugging:
```dart
class MyGame extends FlameGame {
  @override
  bool get debugMode => true; // Renders hitboxes, component bounds
}
```

---

## Timer & Spawning

```dart
class EnemySpawner extends Component with HasGameRef {
  late final TimerComponent _spawnTimer;
  final double spawnInterval;
  final Random _random = Random();

  EnemySpawner({this.spawnInterval = 2.0});

  @override
  Future<void> onLoad() async {
    _spawnTimer = TimerComponent(
      period: spawnInterval,
      repeat: true,
      onTick: _spawnEnemy,
    );
    add(_spawnTimer);
  }

  void _spawnEnemy() {
    final x = _random.nextDouble() * gameRef.size.x;
    gameRef.world.add(
      Enemy(position: Vector2(x, -50)),
    );
  }
}
```
