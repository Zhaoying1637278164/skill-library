# Monetization, Backend & Multiplayer

## Monetization

### AdMob (Banner, Interstitial, Rewarded)

```yaml
dependencies:
  google_mobile_ads: ^5.2.0  # Check pub.dev for latest
```

```dart
/// Ad manager for game monetization
class GameAdManager {
  static final GameAdManager _instance = GameAdManager._();
  factory GameAdManager() => _instance;
  GameAdManager._();

  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;
    await MobileAds.instance.initialize();
    _isInitialized = true;
    _loadInterstitial();
    _loadRewarded();
  }

  /// Show interstitial between levels
  void showInterstitialBetweenLevels({VoidCallback? onDismissed}) {
    if (_interstitialAd == null) {
      onDismissed?.call();
      return;
    }
    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _loadInterstitial();
        onDismissed?.call();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _loadInterstitial();
        onDismissed?.call();
      },
    );
    _interstitialAd!.show();
    _interstitialAd = null;
  }

  /// Show rewarded ad (extra lives, power-ups)
  void showRewardedAd({
    required void Function(int amount) onReward,
    VoidCallback? onFailed,
  }) {
    if (_rewardedAd == null) {
      onFailed?.call();
      return;
    }
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _loadRewarded();
      },
    );
    _rewardedAd!.show(
      onUserEarnedReward: (ad, reward) {
        onReward(reward.amount.toInt());
      },
    );
    _rewardedAd = null;
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: _interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (error) => _interstitialAd = null,
      ),
    );
  }

  void _loadRewarded() {
    RewardedAd.load(
      adUnitId: _rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewardedAd = ad,
        onAdFailedToLoad: (error) => _rewardedAd = null,
      ),
    );
  }

  // Use test ad unit IDs during development
  String get _interstitialAdUnitId => kDebugMode
      ? 'ca-app-pub-3940256099942544/1033173712' // Test ID
      : 'YOUR_PRODUCTION_AD_UNIT_ID';

  String get _rewardedAdUnitId => kDebugMode
      ? 'ca-app-pub-3940256099942544/5224354917' // Test ID
      : 'YOUR_PRODUCTION_AD_UNIT_ID';
}
```

### In-App Purchases

```yaml
dependencies:
  in_app_purchase: ^3.2.0  # Check pub.dev for latest
```

```dart
/// IAP manager for game purchases
class GameIAPManager {
  final InAppPurchase _iap = InAppPurchase.instance;
  late StreamSubscription<List<PurchaseDetails>> _subscription;

  static const Set<String> _productIds = {
    'remove_ads',
    'coin_pack_100',
    'coin_pack_500',
    'premium_monthly',
  };

  Future<void> init() async {
    final available = await _iap.isAvailable();
    if (!available) return;

    _subscription = _iap.purchaseStream.listen(
      _onPurchaseUpdate,
      onError: (error) => debugPrint('IAP Error: $error'),
    );

    // Load product details
    final response = await _iap.queryProductDetails(_productIds);
    if (response.notFoundIDs.isNotEmpty) {
      debugPrint('Products not found: ${response.notFoundIDs}');
    }
    // Store response.productDetails for UI display
  }

  Future<void> buyConsumable(ProductDetails product) async {
    final purchaseParam = PurchaseParam(productDetails: product);
    await _iap.buyConsumable(purchaseParam: purchaseParam);
  }

  Future<void> buyNonConsumable(ProductDetails product) async {
    final purchaseParam = PurchaseParam(productDetails: product);
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  void _onPurchaseUpdate(List<PurchaseDetails> purchaseDetailsList) {
    for (final purchase in purchaseDetailsList) {
      if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        _deliverProduct(purchase);
      }
      if (purchase.pendingCompletePurchase) {
        _iap.completePurchase(purchase);
      }
    }
  }

  void _deliverProduct(PurchaseDetails purchase) {
    switch (purchase.productID) {
      case 'remove_ads':
        // Disable ads permanently
        break;
      case 'coin_pack_100':
        // Add 100 coins
        break;
    }
  }

  void dispose() {
    _subscription.cancel();
  }
}
```

### Monetization Best Practices

| Strategy | When to Use | Implementation |
|----------|-------------|---------------|
| Rewarded ads | Extra lives, continue, power-ups | Show between attempts, never interrupt gameplay |
| Interstitial | Level transitions | Every 3-5 levels, never mid-gameplay |
| Remove ads IAP | Core offering | Non-consumable, restore purchases |
| Coin/gem packs | Virtual currency | Consumable IAP |
| Season pass | Regular content | Auto-renewable subscription |

**Rules:**
- **Never show ads during active gameplay** — only on menus, level complete, or game over
- **Always preload ads** before showing them
- **Provide a "Remove Ads" option** — required for good user experience
- **Use test ad unit IDs** during development
- **Validate purchases server-side** for competitive games

---

## Backend Integration

### Firebase (for AWorld project)

This project already uses Firebase. For game features:

```dart
// Leaderboard using Firestore
class LeaderboardRepository {
  final _firestore = FirebaseFirestore.instance;

  Future<void> submitScore(String userId, int score) async {
    await _firestore.collection('leaderboard').doc(userId).set({
      'score': score,
      'timestamp': FieldValue.serverTimestamp(),
      'displayName': /* user display name */,
    }, SetOptions(merge: true));
  }

  Future<List<LeaderboardEntry>> getTopScores({int limit = 50}) async {
    final snapshot = await _firestore
        .collection('leaderboard')
        .orderBy('score', descending: true)
        .limit(limit)
        .get();

    return snapshot.docs
        .map((doc) => LeaderboardEntry.fromJson(doc.data()))
        .toList();
  }
}
```

### Nakama Game Server (Recommended for Multiplayer)

Nakama is an open-source game server by Heroic Labs with an official Flutter client (`nakama` 1.3.0).

```yaml
dependencies:
  nakama: ^1.3.0
```

```dart
import 'package:nakama/nakama.dart';

class NakamaService {
  late final Client _client;
  late final Session _session;
  NakamaWebsocketClient? _socket;

  Future<void> init() async {
    _client = getNakamaClient(
      host: 'your-server.com',
      ssl: true,
      serverKey: 'defaultkey',
    );
  }

  /// Authenticate player
  Future<void> authenticate({required String deviceId}) async {
    _session = await _client.authenticateDevice(deviceId: deviceId);
  }

  /// Connect real-time WebSocket
  Future<void> connectRealtime() async {
    _socket = NakamaWebsocketClient.init(
      host: 'your-server.com',
      ssl: true,
      token: _session.token,
    );

    // Listen for match data
    _socket!.onMatchData.listen((data) {
      // Handle game state updates from other players
    });

    // Listen for matchmaking
    _socket!.onMatchmakerMatched.listen((matched) {
      // Join the matched game
    });
  }

  /// Submit score to leaderboard
  Future<void> submitScore(String leaderboardId, int score) async {
    await _client.writeLeaderboardRecord(
      session: _session,
      leaderboardId: leaderboardId,
      score: score,
    );
  }

  /// Find a match
  Future<void> findMatch({int minPlayers = 2, int maxPlayers = 4}) async {
    await _socket?.addMatchmaker(
      minCount: minPlayers,
      maxCount: maxPlayers,
      query: '*',
    );
  }

  /// Send game state to match
  void sendMatchState(String matchId, int opCode, List<int> data) {
    _socket?.sendMatchData(matchId: matchId, opCode: opCode, data: data);
  }
}
```

**Nakama provides:** Authentication, matchmaking, real-time WebSocket, leaderboards, chat, storage, RPC for custom server logic.

### WebSocket (Custom Real-Time Multiplayer)

For custom servers without Nakama, use `web_socket_channel` (3.0.3):

```dart
import 'package:web_socket_channel/web_socket_channel.dart';

class MultiplayerService {
  WebSocketChannel? _channel;
  final _messageController = StreamController<GameMessage>.broadcast();

  Stream<GameMessage> get messages => _messageController.stream;

  Future<void> connect(String roomId) async {
    _channel = WebSocketChannel.connect(
      Uri.parse('wss://your-server.com/game/$roomId'),
    );

    _channel!.stream.listen(
      (data) {
        final message = GameMessage.fromJson(jsonDecode(data));
        _messageController.add(message);
      },
      onError: (error) => _handleError(error),
      onDone: () => _handleDisconnect(),
    );
  }

  void sendPlayerState(PlayerState state) {
    _channel?.sink.add(jsonEncode(state.toJson()));
  }

  void sendAction(GameAction action) {
    _channel?.sink.add(jsonEncode(action.toJson()));
  }

  void disconnect() {
    _channel?.sink.close();
    _channel = null;
  }
}

// Usage in game
class MultiplayerGame extends FlameGame {
  late final MultiplayerService _multiplayer;
  final Map<String, RemotePlayer> _remotePlayers = {};

  @override
  Future<void> onLoad() async {
    _multiplayer = MultiplayerService();
    await _multiplayer.connect('room-123');

    _multiplayer.messages.listen((msg) {
      switch (msg.type) {
        case 'player_move':
          _updateRemotePlayer(msg);
          break;
        case 'player_join':
          _addRemotePlayer(msg);
          break;
        case 'player_leave':
          _removeRemotePlayer(msg);
          break;
      }
    });
  }

  @override
  void update(double dt) {
    super.update(dt);
    // Send local player state at fixed rate (e.g., 20Hz)
    _sendPlayerState();
  }
}
```

---

## Analytics for Games

### Using Mixpanel (AWorld standard)

```dart
// Track game events
class GameAnalytics {
  static void trackLevelStart(int level) {
    AnalyticsService().track('game_level_start', {
      'level': level,
    });
  }

  static void trackLevelComplete(int level, int score, Duration time) {
    AnalyticsService().track('game_level_complete', {
      'level': level,
      'score': score,
      'time_seconds': time.inSeconds,
    });
  }

  static void trackGameOver(int score, int level) {
    AnalyticsService().track('game_over', {
      'score': score,
      'level_reached': level,
    });
  }

  static void trackPurchase(String productId, double price) {
    AnalyticsService().track('game_purchase', {
      'product_id': productId,
      'price': price,
    });
  }

  static void trackAdWatched(String adType) {
    AnalyticsService().track('game_ad_watched', {
      'ad_type': adType,
    });
  }
}
```

---

## Save System

### Local Persistence

```dart
import 'package:shared_preferences/shared_preferences.dart';

class GameSaveManager {
  static const _progressKey = 'game_progress';
  static const _settingsKey = 'game_settings';

  Future<void> saveProgress(GameProgress progress) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_progressKey, jsonEncode(progress.toJson()));
  }

  Future<GameProgress> loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_progressKey);
    if (data == null) return const GameProgress();
    return GameProgress.fromJson(jsonDecode(data));
  }

  Future<void> saveSettings(GameSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_settingsKey, jsonEncode(settings.toJson()));
  }

  Future<GameSettings> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_settingsKey);
    if (data == null) return const GameSettings();
    return GameSettings.fromJson(jsonDecode(data));
  }
}

@freezed
abstract class GameSettings with _$GameSettings {
  const factory GameSettings({
    @Default(true) bool sfxEnabled,
    @Default(true) bool musicEnabled,
    @Default(0.7) double sfxVolume,
    @Default(0.4) double musicVolume,
    @Default(false) bool hapticEnabled,
  }) = _GameSettings;

  factory GameSettings.fromJson(Map<String, dynamic> json) =>
      _$GameSettingsFromJson(json);
}
```

### Cloud Sync (via AWorld backend)

```dart
// Sync game progress with server
class GameCloudSync {
  final _gqlApi = AwGqlApiService();

  Future<void> syncToCloud(GameProgress progress) async {
    await _gqlApi.mutation(
      gameProgressUpdate,
      params: {'input': progress.toJson()},
    );
  }

  Future<GameProgress?> loadFromCloud() async {
    final response = await _gqlApi.query(gameProgressGet);
    final data = response.data['gameProgressGet'];
    if (data == null) return null;
    return GameProgress.fromJson(data);
  }

  /// Merge local and cloud progress (take best values)
  GameProgress mergeProgress(GameProgress local, GameProgress cloud) {
    return GameProgress(
      highScore: max(local.highScore, cloud.highScore),
      currentLevel: max(local.currentLevel, cloud.currentLevel),
      totalCoins: max(local.totalCoins, cloud.totalCoins),
      completedLevels: {...local.completedLevels, ...cloud.completedLevels},
      lastPlayed: local.lastPlayed?.isAfter(cloud.lastPlayed ?? DateTime(0)) == true
          ? local.lastPlayed
          : cloud.lastPlayed,
    );
  }
}
```
