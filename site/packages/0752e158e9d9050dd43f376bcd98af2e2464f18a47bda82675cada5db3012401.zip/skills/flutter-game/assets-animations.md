# Assets, Animations & Audio

## Rive Animations (State Machine Driven)

Rive is the best choice for interactive, state-driven animations in Flutter games. Instead of triggering animations by name, you change **inputs** and the state machine handles transitions automatically.

### Setup

```yaml
dependencies:
  rive: ^0.13.0        # Check pub.dev for latest
  flame_rive: ^1.11.0   # For Flame integration
```

### Rive in Flutter Widgets (menus, UI)

```dart
class AnimatedCharacter extends StatefulWidget {
  final bool isWalking;
  final bool isJumping;
  final double speed;

  const AnimatedCharacter({
    required this.isWalking,
    this.isJumping = false,
    this.speed = 1.0,
    super.key,
  });

  @override
  State<AnimatedCharacter> createState() => _AnimatedCharacterState();
}

class _AnimatedCharacterState extends State<AnimatedCharacter> {
  StateMachineController? _controller;
  SMIBool? _isWalking;
  SMIBool? _isJumping;
  SMINumber? _speed;

  void _onRiveInit(Artboard artboard) {
    _controller = StateMachineController.fromArtboard(artboard, 'CharacterFSM');
    if (_controller != null) {
      artboard.addController(_controller!);
      _isWalking = _controller!.findInput<bool>('isWalking') as SMIBool?;
      _isJumping = _controller!.findInput<bool>('isJumping') as SMIBool?;
      _speed = _controller!.findInput<double>('speed') as SMINumber?;
    }
  }

  @override
  void didUpdateWidget(AnimatedCharacter oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Just change the inputs — Rive handles transitions
    _isWalking?.value = widget.isWalking;
    _isJumping?.value = widget.isJumping;
    _speed?.value = widget.speed;
  }

  @override
  Widget build(BuildContext context) {
    return RiveAnimation.asset(
      'assets/animations/character.riv',
      onInit: _onRiveInit,
      fit: BoxFit.contain,
    );
  }
}
```

### Rive in Flame Components

```dart
import 'package:flame_rive/flame_rive.dart';

class RiveEnemy extends RiveComponent with HasGameRef {
  late SMIBool _isAttacking;
  late SMINumber _health;

  RiveEnemy()
      : super(
          artboard: /* loaded artboard */,
          size: Vector2(64, 64),
        );

  @override
  Future<void> onLoad() async {
    // Load Rive file
    final data = await gameRef.assets.readBinaryFile('assets/enemy.riv');
    final file = RiveFile.import(ByteData.sublistView(data));
    final artboard = file.mainArtboard.instance();

    final controller = StateMachineController.fromArtboard(artboard, 'EnemyFSM');
    artboard.addController(controller!);

    _isAttacking = controller.findInput<bool>('isAttacking') as SMIBool;
    _health = controller.findInput<double>('health') as SMINumber;
  }

  void attack() {
    _isAttacking.value = true;
    Future.delayed(const Duration(milliseconds: 500), () {
      _isAttacking.value = false;
    });
  }

  void setHealth(double value) {
    _health.value = value;
  }
}
```

### Rive Best Practices
- **Design state machines in Rive editor** — don't manage animation states in code
- **Use inputs (bool, number, trigger)** to drive animations, not direct animation names
- **Keep vector paths simple** — complex vectors are harder on GPU than bitmaps
- **Export `.riv` files** to `assets/animations/`
- **Preload Rive files** in `onLoad()` to avoid runtime stutters

---

## Sprite Sheets

### Loading

```dart
// Method 1: SpriteSheet utility
final spriteSheet = SpriteSheet(
  image: game.images.fromCache('spritesheet.png'),
  srcSize: Vector2(32, 32), // Each frame size
);

// Create animation from row
final walkAnimation = spriteSheet.createAnimation(
  row: 0,          // Row index
  stepTime: 0.1,   // Seconds per frame
  from: 0,         // Start column
  to: 8,           // End column (exclusive)
);

// Method 2: Individual sprites
final sprite = await Sprite.load(
  'tileset.png',
  srcPosition: Vector2(32, 0),  // Position in sheet
  srcSize: Vector2(32, 32),     // Frame size
);
```

### Sprite Sheet Organization
```
assets/images/
├── player/
│   ├── idle.png          # 4 frames, 32x32 each → 128x32
│   ├── run.png           # 8 frames → 256x32
│   ├── jump.png          # 6 frames → 192x32
│   └── attack.png        # 5 frames → 160x32
├── enemies/
│   ├── slime.png
│   └── bat.png
├── tiles/
│   └── tileset.png       # Tiled-compatible tileset
├── ui/
│   ├── buttons.png
│   └── icons.png
└── effects/
    ├── explosion.png
    └── sparkle.png
```

---

## Audio

### Choosing an Audio Package

| Package | Version | Best For | Features |
|---------|---------|----------|----------|
| **flutter_soloud** | 3.4.10 | Games (recommended) | C++ SoLoud engine, 3D audio, effects (reverb, echo, bass boost), FFT, multiple voices, low latency |
| **flame_audio** | 2.12.0 | Simple Flame games | Wrapper around audioplayers, easy API, audio caching, AudioPool |
| **audioplayers** | 6.0.0 | General purpose | Cross-platform, simple play/loop/stop |
| **flutter_pcm_sound** | — | Procedural audio | Real-time PCM synthesis, zero dependencies |

> **flutter_soloud** is featured in the [official Flutter cookbook](https://docs.flutter.dev/cookbook/audio/soloud) and is the strongest choice for games needing low latency, 3D positional audio, or real-time effects.

### flutter_soloud (Recommended for Games)

```yaml
dependencies:
  flutter_soloud: ^3.4.10
```

```dart
import 'package:flutter_soloud/flutter_soloud.dart';

class GameAudioManager {
  static final GameAudioManager _instance = GameAudioManager._();
  factory GameAudioManager() => _instance;
  GameAudioManager._();

  late final SoLoud _soloud;
  final Map<String, AudioSource> _sources = {};
  bool _sfxEnabled = true;
  bool _musicEnabled = true;
  double _sfxVolume = 0.7;
  double _musicVolume = 0.4;

  Future<void> init() async {
    _soloud = SoLoud.instance;
    await _soloud.init();

    // Preload sound effects
    _sources['jump'] = await _soloud.loadAsset('assets/audio/sfx/jump.wav');
    _sources['coin'] = await _soloud.loadAsset('assets/audio/sfx/coin.wav');
    _sources['explosion'] = await _soloud.loadAsset('assets/audio/sfx/explosion.wav');
    _sources['bgm'] = await _soloud.loadAsset('assets/audio/music/level1.mp3');
  }

  /// Play a sound effect
  SoundHandle? playSfx(String name) {
    if (!_sfxEnabled) return null;
    final source = _sources[name];
    if (source == null) return null;
    return _soloud.play(source, volume: _sfxVolume);
  }

  /// Play a sound with 3D positioning
  SoundHandle? play3D(String name, {required double x, required double y, double z = 0}) {
    if (!_sfxEnabled) return null;
    final source = _sources[name];
    if (source == null) return null;
    return _soloud.play3d(source, x, y, z, volume: _sfxVolume);
  }

  /// Start background music (looping)
  SoundHandle? playMusic(String name) {
    if (!_musicEnabled) return null;
    final source = _sources[name];
    if (source == null) return null;
    return _soloud.play(source, volume: _musicVolume, looping: true);
  }

  void toggleSfx() => _sfxEnabled = !_sfxEnabled;
  void toggleMusic() {
    _musicEnabled = !_musicEnabled;
    if (!_musicEnabled) _soloud.stopAll();
  }

  void dispose() {
    for (final source in _sources.values) {
      _soloud.disposeSource(source);
    }
    _soloud.deinit();
  }
}
```

### flame_audio (Simpler alternative)

```dart
import 'package:flame_audio/flame_audio.dart';

class MyGame extends FlameGame {
  @override
  Future<void> onLoad() async {
    await FlameAudio.audioCache.loadAll([
      'sfx/jump.wav',
      'sfx/coin.wav',
      'music/level1.mp3',
    ]);
  }

  void playJumpSound() {
    FlameAudio.play('sfx/jump.wav', volume: 0.5);
  }

  void startBackgroundMusic() {
    FlameAudio.bgm.play('music/level1.mp3', volume: 0.3);
  }

  void stopBackgroundMusic() {
    FlameAudio.bgm.stop();
  }

  @override
  void onDetach() {
    FlameAudio.bgm.stop();
    super.onDetach();
  }
}
```

### Audio Best Practices
- **Use `.wav` for SFX** (low latency, small files)
- **Use `.mp3` or `.ogg` for music** (compressed, streamed)
- **Preload all audio in `init()`/`onLoad()`** — never load during gameplay
- **Respect device settings** — provide volume controls and mute toggle
- **Stop audio on pause/background** — use app lifecycle callbacks
- **3D audio** (flutter_soloud): position sounds relative to the listener for immersion
- **Web caveat**: browsers block autoplay — require user interaction before first sound

---

## Parallax Backgrounds

```dart
class MyGame extends FlameGame {
  @override
  Future<void> onLoad() async {
    final parallax = await loadParallaxComponent(
      [
        ParallaxImageData('backgrounds/sky.png'),
        ParallaxImageData('backgrounds/clouds.png'),
        ParallaxImageData('backgrounds/mountains.png'),
        ParallaxImageData('backgrounds/trees.png'),
        ParallaxImageData('backgrounds/ground.png'),
      ],
      baseVelocity: Vector2(20, 0),
      velocityMultiplierDelta: Vector2(1.6, 0), // Each layer 1.6x faster
      repeat: ImageRepeat.repeatX,
    );
    add(parallax);
  }
}
```

---

## Effects & Transitions

Flame has a built-in effects system:

```dart
// Move component to position over 1 second
component.add(
  MoveToEffect(
    Vector2(200, 100),
    EffectController(duration: 1.0, curve: Curves.easeOutBack),
  ),
);

// Scale up and down (pulse)
component.add(
  ScaleEffect.by(
    Vector2.all(1.2),
    EffectController(
      duration: 0.3,
      reverseDuration: 0.3,
      infinite: true,
    ),
  ),
);

// Opacity fade
component.add(
  OpacityEffect.fadeOut(
    EffectController(duration: 0.5),
    onComplete: () => component.removeFromParent(),
  ),
);

// Color tint (damage flash)
component.add(
  ColorEffect(
    const Color(0xFFFF0000),
    EffectController(duration: 0.1, reverseDuration: 0.1),
    opacityTo: 0.6,
  ),
);

// Sequence of effects
component.add(
  SequenceEffect([
    MoveByEffect(Vector2(0, -20), EffectController(duration: 0.2)),
    MoveByEffect(Vector2(0, 20), EffectController(duration: 0.2)),
  ]),
);
```
