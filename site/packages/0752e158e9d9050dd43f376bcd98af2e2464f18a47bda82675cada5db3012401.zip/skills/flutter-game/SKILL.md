---
name: flutter-game
description: Create 2D/3D games with Flutter using Flame Engine, Rive animations, and modern game architecture. Use when building games, mini-games, or gamified features.
argument-hint: "[game_type] [description]"
allowed-tools: Read, Write, Edit, Bash(flutter *), Bash(dart *), Glob, Grep
effort: max
---

# Flutter Game Development: $ARGUMENTS

You are building a game with Flutter. Follow these patterns and best practices.

Before writing any code, read the detailed reference guides:
- [Architecture & Patterns](architecture.md) — game structure, FCS, scenes, Riverpod+Flame bridge
- [Flame Engine Reference](flame-reference.md) — components, rendering, physics, input
- [Assets & Animations](assets-animations.md) — Rive, sprites, audio (SoLoud), effects
- [Performance & Platform](performance-platform.md) — Impeller, thread merge, Wasm, optimization
- [Monetization & Backend](monetization-backend.md) — ads, IAP, multiplayer (Nakama), analytics

## Verified Package Versions (March 2026)

| Package | Version | Purpose |
|---------|---------|---------|
| `flame` | 1.36.0 | Core 2D game engine (FCS, rendering, input, camera) |
| `flame_riverpod` | 5.5.3 | Riverpod bridge — `RiverpodAwareGameWidget`, `RiverpodComponentMixin` |
| `flame_forge2d` | 0.19.2+5 | Box2D physics (rigid bodies, joints, collision shapes) |
| `flame_tiled` | 3.1.0 | Tiled map editor `.tmx` support |
| `flame_audio` | 2.12.0 | Simple audio (wraps audioplayers) |
| `flame_rive` | 1.11.0 | Rive animation integration |
| `flame_bloc` | 1.12.22 | Bloc state management bridge |
| `flame_test` | 2.2.3 | Testing utilities for Flame components |
| `flutter_soloud` | 3.4.10 | Advanced game audio (C++ SoLoud engine, 3D, effects, FFT) |
| `rive` | 0.13.20 | Rive animations with State Machines |
| `google_mobile_ads` | 7.0.0 | AdMob ads (banner, interstitial, rewarded) |
| `in_app_purchase` | 3.2.3 | IAP (consumables, subscriptions) |
| `nakama` | 1.3.0 | Multiplayer game server client |

## Quick Decision Tree

**What kind of game?**

| Type | Engine | State Management | Key Packages |
|------|--------|-----------------|--------------|
| Simple mini-game / gamification | Flame | flame_riverpod (project standard) | `flame`, `flame_riverpod`, `flame_audio` |
| 2D platformer / action | Flame + Forge2D | FCS + flame_riverpod | `flame`, `flame_forge2d`, `flame_tiled`, `flutter_soloud` |
| 2D with rich animations | Flame + Rive | FCS + flame_riverpod | `flame`, `flame_rive`, `rive`, `flutter_soloud` |
| Puzzle / card game | Flutter widgets only | Riverpod | `flutter_animate`, `rive` |
| Multiplayer real-time | Flame + Nakama | flame_riverpod + FCS | `flame`, `nakama`, `flutter_soloud` |

> **3D note:** `flame_3d` (0.1.1+7) exists but is experimental, requires Impeller, and supports only iOS/Android/macOS. NOT production-ready. For 3D games, use Unity/Godot with Flutter for UI.

## Step-by-Step Process

### 1. Project Setup

If integrating into THIS project (AWorld), create the game as a feature:
```
lib/features/{game_name}/
├── data/
│   ├── models/           # Game data models (Freezed)
│   │   └── states/       # Game state (score, level, lives)
│   ├── providers/        # Riverpod providers for game state
│   └── repositories/     # Save/load game data, leaderboards
└── views/
    ├── game/             # Flame game classes
    │   ├── {name}_game.dart        # Main FlameGame class
    │   ├── components/             # Game components (player, enemies, etc.)
    │   ├── worlds/                 # Game worlds/levels
    │   └── overlays/               # Flutter widget overlays (HUD, menus)
    ├── screens/          # Game entry/exit screens
    └── widgets/          # Reusable game UI widgets
```

If standalone game project:
```sh
flutter create --template=app my_game
cd my_game
flutter pub add flame flame_audio rive
```

### 2. Scaffold the Game

Create the main game class, entry screen, and basic game loop. Use the patterns from [architecture.md](architecture.md).

### 3. Build Components

Create game entities as Flame Components following [flame-reference.md](flame-reference.md).

### 4. Add Animations & Audio

Integrate Rive state machines and audio following [assets-animations.md](assets-animations.md).

### 5. Optimize

Follow [performance-platform.md](performance-platform.md) for 60/120fps targets.

### 6. Monetize (if applicable)

Add ads, IAP, or backend integration following [monetization-backend.md](monetization-backend.md).
