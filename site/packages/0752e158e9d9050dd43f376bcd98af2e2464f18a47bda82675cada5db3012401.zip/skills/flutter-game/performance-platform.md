# Performance & Platform Optimization

## Impeller Rendering Engine

Impeller is Flutter's rendering backend, replacing Skia. As of 2026:

| Platform | Impeller Status |
|----------|----------------|
| iOS | **Sole renderer** since Flutter 3.27 — Skia removed entirely, no opt-out |
| Android | **Default** on API 29+ (Android 10+). Flutter 3.38 deprecated opt-out. Devices < API 29 fallback to Skia/OpenGL |
| macOS | Available (opt-in) |
| Web | Not applicable (uses CanvasKit or skwasm/Wasm) |

### Key Benefits for Games
- **No shader compilation jank** — all shaders and pipeline state objects compiled AOT at build time
- **Consistent frame rates** — eliminates first-run stutters entirely
- **Lower GPU memory** — more efficient texture management

### Thread Merge (Flutter 3.29+)

Flutter 3.29 merged the **UI thread and platform thread** on iOS and Android by default. This:
- Eliminates async overhead for platform channel calls (~2ms latency reduction)
- Enables synchronous FFI — critical for game engines calling native code
- Extended to macOS/Windows in Flutter 3.35

> The raster thread remains separate. See [flutter/flutter#150525](https://github.com/flutter/flutter/issues/150525).

### Impeller-Specific Tips
- **Avoid `saveLayer()`** — expensive on Impeller. Minimize opacity layers.
- **Use `BackdropFilter` sparingly** — still costly. For blur effects, use pre-blurred assets.
- **Canvas clipping** is faster on Impeller — use `ClipRect` freely for occlusion culling.
- **Profile on real devices** — Impeller performance varies between Vulkan and OpenGL backends.

---

## Performance Targets

| Game Type | Target FPS | Max Frame Time |
|-----------|-----------|---------------|
| Casual / puzzle | 60 fps | 16.6ms |
| Action / platformer | 60 fps | 16.6ms |
| Fast-paced / competitive | 120 fps | 8.3ms |

### Measuring Performance

```dart
// In debug mode, enable performance overlay
class MyGame extends FlameGame {
  @override
  void update(double dt) {
    super.update(dt);

    // Log slow frames
    if (dt > 0.018) { // > 18ms = dropped frame at 60fps
      debugPrint('Slow frame: ${(dt * 1000).toStringAsFixed(1)}ms');
    }
  }
}
```

Use **Flutter DevTools → Performance** tab to:
- Monitor frame rendering times
- Identify jank sources
- Track GPU vs UI thread usage

---

## Optimization Strategies

### 1. Object Pooling (Critical for Action Games)

Avoid creating/destroying objects during gameplay. Pool them:

```dart
class ProjectilePool {
  final Queue<Projectile> _available = Queue();
  final Set<Projectile> _active = {};

  Projectile acquire(Vector2 position, Vector2 velocity) {
    final projectile = _available.isNotEmpty
        ? _available.removeFirst()
        : Projectile(); // Create only if pool empty

    projectile
      ..position = position
      ..velocity = velocity
      ..isActive = true;

    _active.add(projectile);
    return projectile;
  }

  void release(Projectile projectile) {
    projectile.isActive = false;
    _active.remove(projectile);
    _available.addLast(projectile);
  }
}
```

### 2. Viewport Culling

Only update/render what's visible:

```dart
class CulledComponent extends SpriteComponent with HasGameRef {
  @override
  void renderTree(Canvas canvas) {
    // Skip rendering if off-screen
    final cameraRect = gameRef.camera.visibleWorldRect;
    if (!toRect().overlaps(cameraRect)) return;
    super.renderTree(canvas);
  }

  @override
  void update(double dt) {
    // Skip expensive updates if far off-screen
    final cameraRect = gameRef.camera.visibleWorldRect;
    final expandedRect = cameraRect.inflate(100); // Buffer zone
    if (!toRect().overlaps(expandedRect)) return;
    super.update(dt);
  }
}
```

### 3. Spatial Hashing for Collision

For many entities, replace brute-force collision with spatial partitioning:

```dart
class SpatialHash {
  final double cellSize;
  final Map<int, Set<Component>> _cells = {};

  SpatialHash({this.cellSize = 64});

  int _hash(double x, double y) {
    final cx = (x / cellSize).floor();
    final cy = (y / cellSize).floor();
    return cx * 73856093 ^ cy * 19349669;
  }

  void insert(PositionComponent component) {
    final key = _hash(component.position.x, component.position.y);
    _cells.putIfAbsent(key, () => {}).add(component);
  }

  Set<Component> getNearby(PositionComponent component) {
    final key = _hash(component.position.x, component.position.y);
    return _cells[key] ?? {};
  }

  void clear() => _cells.clear();
}
```

### 4. Texture Atlas

Batch draw calls by using a single spritesheet:

```dart
// BAD: Multiple textures = multiple draw calls
final tree = await Sprite.load('tree.png');
final rock = await Sprite.load('rock.png');
final bush = await Sprite.load('bush.png');

// GOOD: Single atlas = single draw call
final atlas = await game.images.load('environment_atlas.png');
final tree = Sprite(atlas, srcPosition: Vector2(0, 0), srcSize: Vector2(32, 32));
final rock = Sprite(atlas, srcPosition: Vector2(32, 0), srcSize: Vector2(32, 32));
final bush = Sprite(atlas, srcPosition: Vector2(64, 0), srcSize: Vector2(32, 32));
```

### 5. Reduce Widget Rebuilds in Overlays

```dart
// BAD: Rebuilds entire HUD every frame
overlayBuilderMap: {
  'HUD': (context, game) => Consumer(
    builder: (ctx, ref, _) {
      final state = ref.watch(gameStateProvider); // Rebuilds on ANY change
      return HudWidget(state: state);
    },
  ),
}

// GOOD: Select specific fields
overlayBuilderMap: {
  'HUD': (context, game) => Consumer(
    builder: (ctx, ref, _) {
      final score = ref.watch(gameStateProvider.select((s) => s.score));
      final lives = ref.watch(gameStateProvider.select((s) => s.lives));
      return HudWidget(score: score, lives: lives);
    },
  ),
}
```

---

## Web (Wasm) Deployment

Flutter supports compiling to WebAssembly (WasmGC) for significantly better web performance. Stable since Flutter 3.24+.

```sh
# Build with Wasm (recommended for games)
flutter build web --wasm

# Fallback to JS if Wasm not supported by browser
flutter build web
```

### Verified Performance Gains
- **Up to 2x faster** frame rendering vs JS compilation
- **Up to 3x improvement** in 99th-percentile worst-case frame times
- **~40% faster** load times with WasmGC
- The `skwasm` renderer (Wasm + Impeller) has noticeably better startup than `canvaskit` (JS)

### Wasm Considerations for Games
- **Supported browsers:** Chrome 119+, Firefox 120+, Edge 119+ work well. **Safari has a WasmGC bug** blocking Flutter's Wasm renderer — all iOS browsers affected (WebKit-based)
- **File size:** Wasm binary is typically smaller than JS equivalent
- **Audio:** Web audio has autoplay restrictions — require user interaction before first sound
- **No file system:** Use `SharedPreferences` (web-compatible) or IndexedDB for saves
- **2026 roadmap** targets making Wasm the default web compilation target

---

## Platform-Specific Tips

### Mobile (iOS & Android)
- **Target 60fps minimum** — test on low-end devices
- **Reduce texture resolution** on older devices: check `MediaQuery.of(context).devicePixelRatio`
- **Battery:** Reduce update frequency when game is idle (pause engine)
- **Memory:** Monitor with `dart:developer` Timeline — keep under 200MB for older devices
- **Haptics:** Use `HapticFeedback.mediumImpact()` for game events (hits, collectibles)

### Desktop (macOS, Windows, Linux)
- **Keyboard controls** are primary — ensure comprehensive key mapping
- **Window resizing** — handle `onGameResize()` in FlameGame
- **Higher resolution** — provide 2x/3x assets or vector graphics

### Web
- **Loading screen** — show progress while assets download
- **Responsive canvas** — handle browser resize
- **No file system** — use `SharedPreferences` (web-compatible) or IndexedDB for saves
- **Performance varies wildly** — test on mobile Chrome, not just desktop
