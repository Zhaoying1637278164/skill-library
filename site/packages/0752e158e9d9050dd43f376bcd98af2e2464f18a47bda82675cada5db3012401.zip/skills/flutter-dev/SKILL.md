---
name: flutter-dev
description: Flutter development best practices with Riverpod 3.0, Freezed, go_router, and feature-first architecture. Auto-invoked when writing Flutter/Dart code.
user-invocable: false
---

# Flutter Development Guide

You are working on a Flutter app with a strict feature-first architecture. Follow these patterns exactly.

## Architecture Rules

### Feature Structure
Every feature lives in `lib/features/{feature_name}/` with this layout:
```
{feature_name}/
├── data/
│   ├── gql/                    # GraphQL queries & mutations
│   │   ├── gql_query_{name}.dart
│   │   └── gql_mutation_{name}.dart
│   ├── models/                 # Freezed data models
│   │   ├── {name}.dart
│   │   └── states/             # State models (implement AwBaseState)
│   │       └── {name}_state.dart
│   ├── providers/              # Riverpod providers (@riverpod)
│   │   └── {name}_provider.dart
│   └── repositories/           # Data access layer
│       └── {name}_repository.dart
└── views/
    ├── screens/                # Full-page screens
    │   └── {name}_screen.dart
    └── widgets/                # Feature-specific widgets
        └── {name}_widget.dart
```

Shared code goes in `lib/common/` — never import between features directly.

### State Management — Riverpod 3.0

**Provider pattern:**
```dart
@Riverpod(keepAlive: true)
class FeatureNotifier extends _$FeatureNotifier with AwBaseNotifier {
  @override
  FeatureState build() => const FeatureState();

  // Lazy dependency access — NEVER read providers in build()
  FeatureRepository get _repository => ref.read(featureRepositoryProvider);

  @override
  Future<void> init() async {
    state = state.copyWith(status: AwBaseNotifierStatus.loading);
    try {
      final data = await _repository.getData();
      state = state.copyWith(data: data, status: AwBaseNotifierStatus.ready);
    } catch (e) {
      state = state.copyWith(status: AwBaseNotifierStatus.error);
    }
  }

  @override
  void reset() => state = const FeatureState();
}
```

**Key rules:**
- Use `@Riverpod(keepAlive: true)` for persistent global state
- Mix in `AwBaseNotifier` for init/reset/refresh lifecycle
- Access dependencies via lazy getters with `ref.read()`, never in `build()`
- Use `state = state.copyWith(...)` for immutable updates
- Use `.select()` when watching specific properties for optimized rebuilds
- Use `ref.watch()` in widgets for reactive state, `ref.read()` for one-time access

### Data Models — Freezed

**Model pattern:**
```dart
@freezed
abstract class FeatureModel with _$FeatureModel {
  const FeatureModel._(); // Only if you need custom methods

  const factory FeatureModel({
    required String id,
    @Default('') String name,
    @JsonKey(name: 'created_at', includeToJson: false) DateTime? createdAt,
    @Default(false) bool isActive,
  }) = _FeatureModel;

  factory FeatureModel.fromJson(Map<String, dynamic> json) =>
      _$FeatureModelFromJson(json);
}
```

**State pattern (implements AwBaseState):**
```dart
@freezed
abstract class FeatureState with _$FeatureState implements AwBaseState {
  const FeatureState._();

  const factory FeatureState({
    @Default(AwBaseNotifierStatus.idle) AwBaseNotifierStatus status,
    @Default([]) List<FeatureModel> items,
    String? errorMessage,
  }) = _FeatureState;

  @override
  bool get isLoading => status == AwBaseNotifierStatus.loading;
  @override
  bool get isLoadingNext => status == AwBaseNotifierStatus.loadingNext;
  @override
  bool get isSending => status == AwBaseNotifierStatus.sending;
  @override
  bool get isReady => status == AwBaseNotifierStatus.ready;
}
```

### Screens — go_router

```dart
class FeatureScreen extends ConsumerStatefulWidget {
  static const routePath = '/feature/:id';
  static const routeName = '/feature';

  static void push(BuildContext context, {required String id}) {
    context.pushNamed(routeName, pathParameters: {'id': id});
  }

  final String id;
  const FeatureScreen({required this.id, super.key});

  @override
  ConsumerState<FeatureScreen> createState() => _FeatureScreenState();
}
```

- Define `routePath` and `routeName` as static constants
- Add static `push()` helper for navigation
- Use `ConsumerStatefulWidget` when you need `initState`, otherwise `ConsumerWidget`

### Widgets

- Prefix custom widget filenames with `aw_` (e.g., `aw_feature_card.dart`)
- Prefix custom widget classes with `Aw` (e.g., `AwFeatureCard`)
- Use `const` constructors wherever possible
- Use `EdgeInsetsDirectional` instead of `EdgeInsets.only` for RTL support
- Use `AlignmentDirectional` instead of `Alignment` for RTL support
- Access theme via `context.theme.appColors`
- Access translations via `context.translator`

### GraphQL

```dart
/// Get feature by id
const String featureGet = r'''
query FeatureGet($input: FeatureGetInput!) {
  featureGet(input: $input) {
    id
    name
    createdAt
  }
}
''';
```

- Store as `const String` with documentation comments
- Use raw strings (`r'''`) for queries with variables
- Call via `AwGqlApiService().query(featureGet, params: {'input': {...}})`
- Call mutations via `AwGqlApiService().mutation(featureMutation, params: {...})`

### Repository Pattern

```dart
@riverpod
FeatureRepository featureRepository(Ref ref) => FeatureRepository();

class FeatureRepository {
  final _gqlApi = AwGqlApiService();

  Future<FeatureModel> getFeature(String id) async {
    try {
      final response = await _gqlApi.query(featureGet, params: {'input': {'id': id}});
      return FeatureModel.fromJson(response.data['featureGet']);
    } catch (e, s) {
      throw AwException('Error fetching feature: $e', s);
    }
  }
}
```

### Testing

- Use `@GenerateMocks([...])` with mockito for auto-generating mocks
- Create `ProviderContainer` with `overrides` for isolated provider testing
- Set `AnalyticsService.testMode = true` in `setUp()` to disable external services
- Use test helpers: `wrapWithProviderScope()`, `wrapWithGoRouter()`, `wrapWithLocalization()`
- Mock ALL provider dependencies including indirect ones
- Run `flutter test --coverage --test-randomize-ordering-seed random`

### Code Quality

- Never use `print()` — use `AwLogger` from `common/utils/logger.dart`
- Run `dart analyze` before committing
- Use `const` constructors wherever possible
- Require trailing commas for multi-line parameters
- Type annotations required for public APIs
- Single responsibility per file
- TODOs format: `TODO(feature_name): description`
- Comments explain "why" not "what"

### Code Generation

After creating/modifying models or providers, run:
```sh
dart run build_runner build --delete-conflicting-outputs
```
