---
name: flutter-test
description: Generate comprehensive tests for Flutter providers, repositories, and widgets with mockito mocks and Riverpod overrides
argument-hint: "[file_or_feature_path]"
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(flutter test *), Bash(dart run build_runner *)
---

# Generate Tests for: $ARGUMENTS

## Step 1: Analyze the target

Read the file or feature path provided. Determine what needs testing:
- **Provider** → Unit test with ProviderContainer and mocked dependencies
- **Repository** → Unit test with mocked API services
- **Widget/Screen** → Widget test with wrappers and provider overrides
- **Feature (directory)** → All of the above

## Step 2: Create tests

### Provider Test Template

**File:** `test/unit/features/{feature}/data/providers/{name}_provider_test.dart`

```dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:aworld/common/services/mixpanel/analytics_service.dart';
// Import the provider, repository, and models
import 'package:aworld/features/{feature}/data/providers/{name}_provider.dart';
import 'package:aworld/features/{feature}/data/repositories/{name}_repository.dart';
import 'package:aworld/features/{feature}/data/models/{name}.dart';

@GenerateMocks([{ClassName}Repository])
import '{name}_provider_test.mocks.dart';

void main() {
  late ProviderContainer container;
  late Mock{ClassName}Repository mockRepository;

  // Sample test data
  final sampleItem = {ClassName}(id: 'test-1', /* fields */);
  final sampleItems = [sampleItem];

  setUp(() {
    AnalyticsService.testMode = true;
    mockRepository = Mock{ClassName}Repository();

    // Setup default mock responses
    when(mockRepository.getAll(nextToken: anyNamed('nextToken')))
        .thenAnswer((_) async => GqlListResponse(items: sampleItems));

    container = ProviderContainer(
      overrides: [
        {camelName}RepositoryProvider.overrideWithValue(mockRepository),
        // Override ALL indirect dependencies too
      ],
    );
  });

  tearDown(() {
    AnalyticsService.testMode = false;
    container.dispose();
  });

  group('{ClassName}Notifier', () {
    test('initial state is idle', () {
      final state = container.read({camelName}NotifierProvider);
      expect(state.items, isEmpty);
      expect(state.status.name, 'idle');
    });

    test('init loads data successfully', () async {
      await container.read({camelName}NotifierProvider.notifier).init();

      final state = container.read({camelName}NotifierProvider);
      expect(state.items, equals(sampleItems));
      expect(state.isReady, isTrue);
      verify(mockRepository.getAll(nextToken: anyNamed('nextToken'))).called(1);
    });

    test('init handles errors gracefully', () async {
      when(mockRepository.getAll(nextToken: anyNamed('nextToken')))
          .thenThrow(Exception('Network error'));

      await container.read({camelName}NotifierProvider.notifier).init();

      final state = container.read({camelName}NotifierProvider);
      expect(state.status.name, 'error');
    });

    test('reset clears state', () async {
      await container.read({camelName}NotifierProvider.notifier).init();
      container.read({camelName}NotifierProvider.notifier).reset();

      final state = container.read({camelName}NotifierProvider);
      expect(state.items, isEmpty);
      expect(state.status.name, 'idle');
    });
  });
}
```

### Widget Test Template

```dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:aworld/features/{feature}/views/widgets/{name}_widget.dart';
import '../../../../helpers/widget_test_helpers.dart';

void main() {
  testWidgets('{ClassName}Widget renders correctly', (tester) async {
    await tester.pumpWidget(
      wrapWithProviderScope(
        overrides: [
          // Provider overrides
        ],
        child: const {ClassName}Widget(),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byType({ClassName}Widget), findsOneWidget);
  });

  testWidgets('{ClassName}Widget shows loading state', (tester) async {
    // Test with loading state override
  });
}
```

### Screen Test Template (with GoRouter)

```dart
testWidgets('{ClassName}Screen navigates correctly', (tester) async {
  await tester.pumpWidget(
    wrapWithGoRouter(
      builder: (context, state) => const {ClassName}Screen(id: 'test'),
      overrides: [
        // Provider overrides with mock data
      ],
    ),
  );
  await tester.pumpAndSettle();

  expect(find.byType({ClassName}Screen), findsOneWidget);
});
```

## Step 3: Generate mocks

After writing the test file with `@GenerateMocks`:
```sh
dart run build_runner build --delete-conflicting-outputs
```

## Step 4: Run the tests

```sh
flutter test test/unit/features/{feature}/ --coverage
```

## Key Testing Rules

- **Mock ALL dependencies** including indirect ones (providers that the tested provider watches)
- **Use `AnalyticsService.testMode = true`** in setUp to disable Mixpanel
- **Use `container.dispose()`** in tearDown
- **Test the state, not the implementation** — verify state changes, not internal method calls
- **Use `verify()`** to confirm expected API calls were made
- **Use `wrapWithProviderScope()`** for widgets, `wrapWithGoRouter()` for screens
- **Use `wrapWithLocalization()`** for widgets using `context.translator`
- **Factories:** If the feature has a factory class (e.g., `{name}_factory.dart`), use it for test data
- **Avoid testing generated code** (Freezed copyWith, JSON serialization)
- **Test edge cases:** empty lists, null values, error states, loading states
