---
name: flutter-feature
description: Scaffold a complete new feature with models, providers, repositories, screens, widgets, and tests following feature-first architecture
argument-hint: "[feature_name]"
allowed-tools: Read, Write, Edit, Bash(dart run build_runner *)
---

# Scaffold Flutter Feature: $ARGUMENTS

Create a complete feature module for **$ARGUMENTS** following the project's feature-first architecture.

## Step 1: Understand the feature

Before creating files, clarify with the user:
- What data does this feature manage?
- Does it need GraphQL queries/mutations?
- Does it need a screen with routing?
- What are the main model fields?

If the user provided enough context, proceed. Otherwise ask.

## Step 2: Create the feature structure

Create all files under `lib/features/$ARGUMENTS/` following this exact structure:

### Model (`data/models/{name}.dart`)
```dart
import 'package:freezed_annotation/freezed_annotation.dart';

part '{name}.freezed.dart';
part '{name}.g.dart';

@freezed
abstract class {ClassName} with _${ClassName} {
  const factory {ClassName}({
    required String id,
    // Add fields based on feature requirements
  }) = _{ClassName};

  factory {ClassName}.fromJson(Map<String, dynamic> json) =>
      _${ClassName}FromJson(json);
}
```

### State (`data/models/states/{name}_state.dart`)
```dart
import 'package:aworld/common/data/models/states/_aw_base_state.dart';
import 'package:aworld/common/data/providers/_aw_base_notifier_status.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import '../{name}.dart';

part '{name}_state.freezed.dart';
part '{name}_state.g.dart';

@freezed
abstract class {ClassName}State with _${ClassName}State implements AwBaseState {
  const {ClassName}State._();

  const factory {ClassName}State({
    @Default(AwBaseNotifierStatus.idle) AwBaseNotifierStatus status,
    // Add state fields
  }) = _{ClassName}State;

  @override
  bool get isLoading => status == AwBaseNotifierStatus.loading;
  @override
  bool get isLoadingNext => status == AwBaseNotifierStatus.loadingNext;
  @override
  bool get isSending => status == AwBaseNotifierStatus.sending;
  @override
  bool get isReady => status == AwBaseNotifierStatus.ready;
}
```

### Repository (`data/repositories/{name}_repository.dart`)
```dart
import 'package:aworld/common/data/models/aw_exception.dart';
import 'package:aworld/common/services/gql/aw_gql_api_service.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../gql/gql_query_{name}.dart';
import '../models/{name}.dart';

part '{name}_repository.g.dart';

@riverpod
{ClassName}Repository {camelName}Repository(Ref ref) => {ClassName}Repository();

class {ClassName}Repository {
  final _gqlApi = AwGqlApiService();

  Future<{ClassName}> get{ClassName}(String id) async {
    try {
      final response = await _gqlApi.query({camelName}Get, params: {'input': {'id': id}});
      return {ClassName}.fromJson(response.data['{camelName}Get']);
    } catch (e, s) {
      throw AwException('Error fetching {name}: $e', s);
    }
  }
}
```

### Provider (`data/providers/{name}_provider.dart`)
```dart
import 'package:aworld/common/data/providers/_aw_base_notifier.dart';
import 'package:aworld/common/data/providers/_aw_base_notifier_status.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../models/states/{name}_state.dart';
import '../repositories/{name}_repository.dart';

part '{name}_provider.g.dart';

@Riverpod(keepAlive: true)
class {ClassName}Notifier extends _${ClassName}Notifier with AwBaseNotifier {
  @override
  {ClassName}State build() => const {ClassName}State();

  {ClassName}Repository get _repository => ref.read({camelName}RepositoryProvider);

  @override
  Future<void> init() async {
    state = state.copyWith(status: AwBaseNotifierStatus.loading);
    try {
      // Load initial data
      state = state.copyWith(status: AwBaseNotifierStatus.ready);
    } catch (e) {
      state = state.copyWith(status: AwBaseNotifierStatus.error);
    }
  }

  @override
  void reset() => state = const {ClassName}State();
}
```

### GraphQL (`data/gql/gql_query_{name}.dart`)
```dart
/// Get {name} by id
const String {camelName}Get = r'''
query {ClassName}Get($input: {ClassName}GetInput!) {
  {camelName}Get(input: $input) {
    id
  }
}
''';
```

### Screen (`views/screens/{name}_screen.dart`)
```dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:skeletonizer/skeletonizer.dart';
import '../../data/providers/{name}_provider.dart';

class {ClassName}Screen extends ConsumerStatefulWidget {
  static const routePath = '/{name}/:id';
  static const routeName = '/{name}';

  static void push(BuildContext context, {required String id}) {
    context.pushNamed(routeName, pathParameters: {'id': id});
  }

  final String id;
  const {ClassName}Screen({required this.id, super.key});

  @override
  ConsumerState<{ClassName}Screen> createState() => _{ClassName}ScreenState();
}

class _{ClassName}ScreenState extends ConsumerState<{ClassName}Screen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      ref.read({camelName}NotifierProvider.notifier).init();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch({camelName}NotifierProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('{ClassName}')),
      body: Skeletonizer(
        enabled: state.isLoading,
        child: const Center(child: Text('{ClassName} Screen')),
      ),
    );
  }
}
```

### Widget placeholder (`views/widgets/{name}_card.dart`)
Create a basic widget placeholder.

### Test (`test/unit/features/{name}/data/providers/{name}_provider_test.dart`)
```dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:aworld/common/services/mixpanel/analytics_service.dart';
import 'package:aworld/features/{name}/data/repositories/{name}_repository.dart';
import 'package:aworld/features/{name}/data/providers/{name}_provider.dart';

@GenerateMocks([{ClassName}Repository])
import '{name}_provider_test.mocks.dart';

void main() {
  late ProviderContainer container;
  late Mock{ClassName}Repository mockRepository;

  setUp(() {
    AnalyticsService.testMode = true;
    mockRepository = Mock{ClassName}Repository();
    container = ProviderContainer(
      overrides: [
        {camelName}RepositoryProvider.overrideWithValue(mockRepository),
      ],
    );
  });

  tearDown(() {
    AnalyticsService.testMode = false;
    container.dispose();
  });

  test('initial state is idle', () {
    final state = container.read({camelName}NotifierProvider);
    expect(state.status.name, 'idle');
  });
}
```

## Step 3: Run code generation

```sh
dart run build_runner build --delete-conflicting-outputs
```

## Step 4: Register route

Add the new route to `lib/common/data/providers/routing_provider.dart` if a screen was created.

## Step 5: Summary

List all created files and explain the next steps (adding fields, connecting to API, etc.).
