<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# Influencer Marketing Agent

> Role Agent · run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client. Read-only public-data research — **eyes, not hands**.

The Influencer Marketing Agent turns a campaign brief into a full-funnel operating pack: creator discovery, audience-fit checks, pricing forecasts, confirm / negotiate / pass decisions, content-review criteria, launch watchlists, and public-results reporting. It stays read-only: the operator sends outreach, signs contracts, schedules posts, and connects any private conversion data.

## Who it's for

- Marketing teams planning and operating creator sponsorship campaigns
- Founders comparing influencer targets before a launch
- Agencies that want repeatable matching, pricing, confirmation, and reporting evidence

## Skills in this agent

- [`creator-campaign-ops`](creator-campaign-ops/) — Plan, match, price, confirm, track, and report an influencer campaign from public creator evidence. _(enhanced)_
- [`creator-shortlist`](creator-shortlist/) — Find creators by niche, audience language, recent momentum, and platform fit. _(enhanced)_
- [`audience-fit-check`](audience-fit-check/) — Vet a single creator's audience fit and brand-safety from public posts and engagement before outreach. _(enhanced)_
- [`kol-pricing`](kol-pricing/) — Estimate Twitter/X KOL rates from public engagement, audience fit, and risk. _(enhanced)_

## What you get

- Campaign spec with platform mix, budget assumptions, and matching plan
- Ranked creator shortlist with audience-fit, safety, and confidence notes
- Estimated price ranges, predicted CPM/CPC, and confirm / negotiate / pass calls
- Content-review checklist, launch watchlist, public-results report, and operator handoffs

## Install & run

Connect in a couple of steps — prompt, web connector, or plugin, all read-only with OAuth sign-in (new workspaces get free trial credits):

**Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, Goose — any agent that manages its own MCP servers): ask it to add the UnifAPI MCP server at `https://mcp.unifapi.com` — a remote streamable-HTTP, read-only server — and run the OAuth sign-in. No API key to paste.

**Web connector — no terminal** (Claude, ChatGPT, Perplexity, Grok): add a custom connector pointed at `https://mcp.unifapi.com`, then authorize over OAuth.

**Add the skills** in any client with `npx skills add unifapi-agent/agents`. Claude-compatible hosts (Claude Code, Claude Desktop, OpenClaw) can instead install skills + MCP together as a plugin: `/plugin marketplace add unifapi-agent/agents` then `/plugin install unifapi@unifapi`.

Step-by-step for every client → https://unifapi.com/mcp

Then ask your assistant:

```text
Plan a full-funnel creator campaign for an AI developer-tool launch across X and YouTube. Build the campaign spec, discover and rank 15 creators, estimate pricing and predicted CPM/CPC, make confirm / negotiate / pass calls, draft the content-review checklist, define the launch watchlist, and list the operator handoffs.
```

## Reads from

UnifAPI APIs: **twitter, youtube, tiktok, instagram** — public data only.

## FAQ

### Does it give exact creator rates?

No — it gives evidence-backed ranges from public engagement so you can negotiate with context. Final pricing depends on package, exclusivity, usage rights, and scope. See the KOL Pricing Skill for the detailed pricing workflow.

### Can it send outreach for me?

No. It drafts outreach angles, follow-up questions, and confirmation checklists; you or your own assistant send the messages from your own accounts. UnifAPI reads public data and does not message creators on your behalf.

### Can it track campaign results?

It can track public post metrics once you provide live post URLs or IDs. Private clicks, promo-code revenue, checkout events, and UTM conversions need user-provided exports or a separate analytics API.

### Which platforms does it cover?

X / Twitter is the primary surface for pricing; YouTube, TikTok, and Instagram add cross-platform audience and content context. All four are live in the API catalog.

## Links

- Agent page: https://unifapi.com/agents/influencer-marketing
- Install & all clients: https://unifapi.com/mcp
- MCP server: `https://mcp.unifapi.com`
- All agents: https://unifapi.com/agents · Docs: https://docs.unifapi.com

<sub>Topics: influencer search tool · find influencers for your brand · influencer discovery tool · influencer marketing tool · creator research tool · influencer rate calculator · creator vetting · influencer campaign tracking · KOL pricing</sub>
