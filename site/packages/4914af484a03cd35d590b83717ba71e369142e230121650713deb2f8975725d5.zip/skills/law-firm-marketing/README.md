<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# Law Firm Marketing Agent

> Vertical Agent · run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client. Read-only public-data research — **eyes, not hands**.

The Law Firm Marketing Agent recombines local SEO, social listening, content strategy, and AI visibility for legal marketing. It audits local and organic search presence by practice area, mines the questions clients ask, and checks AI-answer visibility for attorney-search prompts.

**Powered by:** [Local SEO](../local-seo-agent/) · [Social listening](../social-listening-agent/) · [Content strategy](../content-strategy-agent/) · [AI visibility](../ai-visibility-agent/)

## Who it's for

- Law firms and solo attorneys marketing by practice area
- Legal marketing agencies serving multiple firms
- Marketers planning content from real client questions

## Skills in this agent

- [`practice-area-rank-audit`](practice-area-rank-audit/) — Audit a firm's rank for every practice-area + city query and flag where thin content is the reason it's losing. _(enhanced)_
- [`attorney-reputation-benchmark`](attorney-reputation-benchmark/) — Benchmark a firm's public reviews and local-pack presence against competing firms and quantify the gap. _(enhanced)_

## What you get

- Local and organic rankings for practice-area + city queries
- Content demand from real client questions
- AI-answer visibility for 'lawyer near me'-style prompts
- Reputation and listing gaps vs competing firms

## Install & run

Connect in a couple of steps — prompt, web connector, or plugin, all read-only with OAuth sign-in (new workspaces get free trial credits):

**Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, Goose — any agent that manages its own MCP servers): ask it to add the UnifAPI MCP server at `https://mcp.unifapi.com` — a remote streamable-HTTP, read-only server — and run the OAuth sign-in. No API key to paste.

**Web connector — no terminal** (Claude, ChatGPT, Perplexity, Grok): add a custom connector pointed at `https://mcp.unifapi.com`, then authorize over OAuth.

**Add the skills** in any client with `npx skills add unifapi-agent/agents`. Claude-compatible hosts (Claude Code, Claude Desktop, OpenClaw) can instead install skills + MCP together as a plugin: `/plugin marketplace add unifapi-agent/agents` then `/plugin install unifapi@unifapi`.

Step-by-step for every client → https://unifapi.com/mcp

Then ask your assistant:

```text
Audit law firm marketing visibility for my practice in Chicago, IL. Check rankings for "personal injury lawyer" and "family law attorney", find content topics from common client questions, and check whether we're cited in AI answers for attorney-search prompts.
```

## Reads from

UnifAPI APIs: **maps, local, seo, geo, news** — public data only.

> This is a marketing agent — read-only research and visibility. It is not a licensed professional in this industry, it does not replace one, and it never posts, advertises, or changes anything on your behalf.

## FAQ

### Does it give legal advice?

No. It is a marketing agent for law firms and researches online visibility only. It does not provide legal advice and is not a substitute for a licensed attorney.

### Is the content compliant with bar advertising rules?

It surfaces topics and demand evidence; you and your firm remain responsible for reviewing any published content against your jurisdiction's attorney-advertising rules.

### What powers it under the hood?

Local SEO, Content Strategy, Social Listening, and AI Visibility Role Agents tuned for legal queries, on the same public-data APIs.

## Links

- Agent page: https://unifapi.com/agents/law-firm-marketing
- Install & all clients: https://unifapi.com/mcp
- MCP server: `https://mcp.unifapi.com`
- All agents: https://unifapi.com/agents · Docs: https://docs.unifapi.com

<sub>Topics: law firm marketing · attorney marketing · legal marketing · law firm SEO · marketing ideas for lawyers · AI SEO for lawyers · law firm AI visibility · legal content marketing</sub>
