<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# TikTok Data Skill

> The deterministic guide to reading public TikTok data through UnifAPI — creators, videos, comments, hashtags, music, and search.

The TikTok Data Skill is the source-sliced data guide a Platform Agent owns: it names the concrete `tiktok/...` operations, response shapes, and gotchas for reading public TikTok data through UnifAPI MCP, so any creator or trend research (shortlisting, audience-fit, demand-radar, local-buzz) runs from one deterministic workflow. Read-only — it never posts.

A source-sliced **data skill** you run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client — the deterministic, read-only path to one platform's public data. It names the operations and response shapes; the marketing skills in the same agent turn those records into briefs, prices, and signals. **Eyes not hands** — it never posts.

## What it's good for

- Any TikTok-first research that needs creators, videos, or hashtag trends
- Skills that shortlist, vet, or price creators, or track rising demand
- Operators who want one deterministic TikTok read path, not ad-hoc discovery

## What you get

- The concrete `tiktok/...` operations for each common creator/trend read job
- Response-contract and shape notes for users, videos, hashtags, music
- Deterministic recipes: resolve creators, read engagement, discover trends
- Platform gotchas (resolve username to id first, cursor pagination, billing)

## What it reads

Live public data through the shared [`unifapi`](../../unifapi/) data skill — UnifAPI APIs: **tiktok**. Connect once over OAuth; no scraping to maintain and no keys to rotate. Every figure in the output is cited to the record it came from.

## Example prompt

```text
Using the TikTok Data Skill, research creators for a skincare niche: search users and videos for the topic, resolve the strongest handles to ids, read their follower and video engagement, and surface rising hashtags. Return a cited brief. Read-only.
```

## Install

Run it in any MCP client. **Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, …) to add the UnifAPI public-data MCP server at `https://mcp.unifapi.com` over OAuth — read-only, no API key — then add the marketing skills with `npx skills add unifapi-agent/agents`.

Prefer a **web connector** (Claude · ChatGPT · Perplexity · Grok), or the one-shot **plugin** for Claude-compatible hosts:

```text
/plugin marketplace add unifapi-agent/agents
/plugin install unifapi@unifapi
```

Every client, step by step: https://unifapi.com/mcp

## Related

- Part of the **[TikTok Agent](../)**
- Shared data skill: [`unifapi`](../../unifapi/)

## Links

- Skill page: https://unifapi.com/skills/tiktok
- The skill itself: [SKILL.md](./SKILL.md)
- Install & all clients: https://unifapi.com/mcp
- Docs: https://docs.unifapi.com

<sub>Topics: TikTok research tool · TikTok creator research · TikTok data · find TikTok creators · TikTok hashtag trends · TikTok video analytics · TikTok MCP server</sub>
