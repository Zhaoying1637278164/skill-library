<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# Listing Accuracy Audit

> Read a business's public map/local listing and flag where the details are inconsistent, incomplete, or wrong.

A wrong category, stale phone number, or missing address quietly suppresses local-pack rank and sends ready-to-buy customers to a competitor. This skill reads the public listing field by field, flags every gap or inconsistency, and checks whether the listing even surfaces for the business's own name + city — read-only.

An atomic marketing skill you run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client — read-only public-data research, **eyes not hands**. It diagnoses, prices, and drafts evidence; your own assistant and accounts take any action.

## What it's good for

- Local businesses verifying their public listing is correct
- Multi-location brands checking listing consistency at scale
- Agencies auditing client NAP and profile completeness

## What you get

- Field-by-field table: listing value vs expected, with pass/fix flags
- Prioritized list of inconsistencies and gaps
- Whether the listing surfaces for the business's own name + city
- Every value cited to the public listing record

## What it reads

Live public data through the shared [`unifapi`](../../unifapi/) data skill — UnifAPI APIs: **maps, local, seo**. Connect once over OAuth; no scraping to maintain and no keys to rotate. Every figure in the output is cited to the record it came from.

## Example prompt

```text
Audit my business's public Google listing field by field — name, address, category, phone, rating, reviews — and flag anything inconsistent, missing, or that looks wrong.
```

## Install

Run it in any MCP client. **Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, …) to add the UnifAPI public-data MCP server at `https://mcp.unifapi.com` over OAuth — read-only, no API key — then add the marketing skills with `npx skills add unifapi-agent/agents`.

Prefer a **web connector** (Claude · ChatGPT · Perplexity · Grok), or the one-shot **plugin** for Claude-compatible hosts:

```text
/plugin marketplace add unifapi-agent/agents
/plugin install unifapi@unifapi
```

Every client, step by step: https://unifapi.com/mcp

## Related

- Part of the **[Local SEO Agent](../)**
- Shared data skill: [`unifapi`](../../unifapi/)

## Links

- Skill page: https://unifapi.com/skills/listing-accuracy-audit
- The skill itself: [SKILL.md](./SKILL.md)
- Install & all clients: https://unifapi.com/mcp
- Docs: https://docs.unifapi.com

<sub>Topics: Google Business Profile audit · business listing accuracy · NAP consistency check · local listing audit · business listing check · GBP audit</sub>
