<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# Reddit Agent

> Platform Agent · run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client. Read-only public-data research — **eyes, not hands**.

The Reddit Agent turns public Reddit into community research: subreddit profiles and rules, thread comments, user activity, and trending searches. It owns the Reddit Data Skill — the deterministic read path, honest about Reddit's no-keyword-search limits — and composes the Role-Agent Skills behind community research, social-listening, and voice-of-customer work — and never posts or comments.

**Powered by:** [Social listening](../social-listening-agent/) · [Content strategy](../content-strategy-agent/)

## Who it's for

- Marketers mining community pains, questions, and language
- Founders validating a niche from real subreddit discussion
- Brand teams listening to unfiltered Reddit sentiment

## Skills in this agent

- [`reddit`](reddit/) — The deterministic guide to reading public Reddit data through UnifAPI — subreddits, threads, comments, users, and trending searches. _(data)_
- [`reddit-community-research`](../social-listening-agent/reddit-community-research/) — Map subreddits, recurring questions, objections, and language for a niche. _(enhanced · shared)_
- [`reddit-thread-fit-check`](../social-listening-agent/reddit-thread-fit-check/) — Score Reddit threads by relevance, intent, rules, timing, and account risk before anyone replies. _(enhanced · shared)_
- [`social-listening-brief`](../social-listening-agent/social-listening-brief/) — Track public mentions and return a concise brief instead of a dashboard. _(enhanced · shared)_
- [`customer-research`](../content-strategy-agent/customer-research/) — Mine authentic customer language, pains, and objections from public communities to inform messaging and content. _(enhanced · shared)_

## What you get

- Subreddit map with size, rules, and outreach-safety read
- Recurring questions, objections, and verbatim language
- Example threads and power-user signal, each linked
- A note on coverage (Reddit has no keyword search — seeds are named)

## Install & run

Connect in a couple of steps — prompt, web connector, or plugin, all read-only with OAuth sign-in (new workspaces get free trial credits):

**Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, Goose — any agent that manages its own MCP servers): ask it to add the UnifAPI MCP server at `https://mcp.unifapi.com` — a remote streamable-HTTP, read-only server — and run the OAuth sign-in. No API key to paste.

**Web connector — no terminal** (Claude, ChatGPT, Perplexity, Grok): add a custom connector pointed at `https://mcp.unifapi.com`, then authorize over OAuth.

**Add the skills** in any client with `npx skills add unifapi-agent/agents`. Claude-compatible hosts (Claude Code, Claude Desktop, OpenClaw) can instead install skills + MCP together as a plugin: `/plugin marketplace add unifapi-agent/agents` then `/plugin install unifapi@unifapi`.

Step-by-step for every client → https://unifapi.com/mcp

Then ask your assistant:

```text
Research the Reddit communities for my niche: map the relevant subreddits and their rules, mine recent threads for recurring questions and complaints, and pull verbatim language. Return a sourced brief — read-only, do not post or comment.
```

## Reads from

UnifAPI APIs: **reddit** — public data only.

> This is a read-only research agent for one platform. It reads public data and returns evidence — it never logs into, posts to, comments on, or messages on the platform, and it never holds your account credentials.

## FAQ

### Can it search Reddit by keyword?

Reddit's public surface has no keyword search, so the agent seeds from subreddits you name plus trending and popular feeds, then drills into threads. It says clearly that coverage is seed-driven, not exhaustive.

### Does it post or reply on Reddit?

No. It is read-only research. Any participation is done by you from your own account; UnifAPI never holds Reddit credentials.

## Links

- Agent page: https://unifapi.com/agents/reddit
- Install & all clients: https://unifapi.com/mcp
- MCP server: `https://mcp.unifapi.com`
- All agents: https://unifapi.com/agents · Docs: https://docs.unifapi.com

<sub>Topics: Reddit research tool · Reddit social listening · Reddit research agent · subreddit research tool · Reddit brand monitoring · Reddit MCP server</sub>
