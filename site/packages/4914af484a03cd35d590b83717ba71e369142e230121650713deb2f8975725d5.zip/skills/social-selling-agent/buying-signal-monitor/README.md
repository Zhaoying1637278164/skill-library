<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# Buying Signal Monitor

> Watch public X and LinkedIn for buying intent and return warm leads, each anchored to the post that proves it.

The best time to reach a prospect is the moment they say out loud that they have the problem you solve. This skill watches the public X/Twitter and LinkedIn surface for intent — asking for a tool, venting about a vendor, posting a relevant job req — and returns a ranked warm-lead list with the proving post and a tailored outreach angle. Read-only: the operator sends from their own account.

An atomic marketing skill you run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client — read-only public-data research, **eyes not hands**. It diagnoses, prices, and drafts evidence; your own assistant and accounts take any action.

## What it's good for

- SDRs and reps who want warm openings, not cold lists
- Founders selling from public intent signals
- Teams monitoring 'who is asking for what we sell' on X and LinkedIn

## What you get

- Ranked warm-lead list: name/handle, company, role, signal type, warmth
- The proving post (quote or link + date) for each lead
- A tailored one-line outreach angle per lead
- Flags on leads needing human verification before outreach

## What it reads

Live public data through the shared [`unifapi`](../../unifapi/) data skill — UnifAPI APIs: **twitter, linkedin, news**. Connect once over OAuth; no scraping to maintain and no keys to rotate. Every figure in the output is cited to the record it came from.

## Example prompt

```text
Watch X and LinkedIn this week for people asking for a YouTube data API or complaining about scraping rate limits, and return a warm-lead list with the proving post and a one-line outreach angle for each.
```

## Install

Run it in any MCP client. **Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, …) to add the UnifAPI public-data MCP server at `https://mcp.unifapi.com` over OAuth — read-only, no API key — then add the marketing skills with `npx skills add unifapi-agent/agents`.

Prefer a **web connector** (Claude · ChatGPT · Perplexity · Grok), or the one-shot **plugin** for Claude-compatible hosts:

```text
/plugin marketplace add unifapi-agent/agents
/plugin install unifapi@unifapi
```

Every client, step by step: https://unifapi.com/mcp

## Related

- Part of the **[Social Selling Agent](../)**
- Shared data skill: [`unifapi`](../../unifapi/)

## Links

- Skill page: https://unifapi.com/skills/buying-signal-monitor
- The skill itself: [SKILL.md](./SKILL.md)
- Install & all clients: https://unifapi.com/mcp
- Docs: https://docs.unifapi.com

<sub>Topics: buying signals · buyer intent · social selling tool · warm lead finder · LinkedIn buying signals · trigger event monitoring</sub>
