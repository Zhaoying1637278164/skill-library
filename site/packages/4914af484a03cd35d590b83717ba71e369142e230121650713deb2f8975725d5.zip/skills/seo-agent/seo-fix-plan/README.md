<!-- Generated file — do not edit by hand. Propose changes via an issue or PR; see CONTRIBUTING.md. -->

# SEO Fix Plan

> Convert live SEO audit evidence into prioritized fixes, owners, and acceptance checks.

Turn SEO audit findings into a concrete remediation plan: deduplicate issues into fix units, rank them by impact, confidence, effort, and dependency, and attach acceptance checks so the operator knows exactly what to change and how to verify it.

An atomic marketing skill you run inside Claude, ChatGPT, Claude Code, Cursor, Codex, OpenClaw, Hermes, or any MCP client — read-only public-data research, **eyes not hands**. It diagnoses, prices, and drafts evidence; your own assistant and accounts take any action.

## What it's good for

- Teams that already have audit evidence and need to know what to fix first
- Founders turning SEO findings into code, CMS, and content tasks
- Agencies standardizing SEO remediation handoffs across clients

## What you get

- Prioritized fix table with type, evidence, action, owner, and acceptance check
- Quick wins separated from crawl/indexation blockers and longer content work
- Template-level grouping so repeated issues become one executable fix
- Re-check plan with the live operations to run after changes ship

## What it reads

Live public data through the shared [`unifapi`](../../unifapi/) data skill — UnifAPI APIs: **seo, browser**. Connect once over OAuth; no scraping to maintain and no keys to rotate. Every figure in the output is cited to the record it came from.

## Example prompt

```text
Turn this SEO audit for example.com into a prioritized fix plan. Group repeated issues into template-level tasks, rank quick wins vs blockers, and include acceptance checks for each fix.
```

## Install

Run it in any MCP client. **Paste one prompt** (Claude Code, Codex, Cursor, OpenClaw, …) to add the UnifAPI public-data MCP server at `https://mcp.unifapi.com` over OAuth — read-only, no API key — then add the marketing skills with `npx skills add unifapi-agent/agents`.

Prefer a **web connector** (Claude · ChatGPT · Perplexity · Grok), or the one-shot **plugin** for Claude-compatible hosts:

```text
/plugin marketplace add unifapi-agent/agents
/plugin install unifapi@unifapi
```

Every client, step by step: https://unifapi.com/mcp

## FAQ

### Does it edit my site?

No. It turns evidence into an execution plan. Your own assistant, CMS, or site team makes the change and runs the checks.

### How is this different from SEO Audit?

SEO Audit diagnoses what is wrong. SEO Fix Plan decides what to do first, groups repeated issues into tasks, and defines how each fix will be verified.

## Related

- Part of the **[SEO Agent](../)**
- [`seo-audit`](../seo-audit/) — Audit crawlability, on-page, and content against live SERP and ranking evidence — not a static checklist.
- [`keyword-research`](../keyword-research/) — Turn a seed list into ranked keyword opportunities and competitor gaps from live SERP and volume data.
- [`schema`](../schema/) — Choose and implement the right schema.org types for a page, with valid JSON-LD the assistant can write.
- Shared data skill: [`unifapi`](../../unifapi/)

## Links

- Skill page: https://unifapi.com/skills/seo-fix-plan
- The skill itself: [SKILL.md](./SKILL.md)
- Install & all clients: https://unifapi.com/mcp
- Docs: https://docs.unifapi.com

<sub>Topics: SEO fix plan · how to fix SEO issues · on-page SEO checklist · AI SEO recommendations · SEO action plan · technical SEO fixes · prioritize SEO issues · SEO to-do list</sub>
