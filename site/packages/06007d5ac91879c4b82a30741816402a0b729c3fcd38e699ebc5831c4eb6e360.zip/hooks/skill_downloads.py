"""Exposes each skill's canonical SKILL.md as a downloadable static asset.

Every skill page links to a "Download SKILL.md" button so visitors can save
the exact source file used by skills/<skill-id>/SKILL.md to their own
computer. MkDocs converts any *.md file it finds under docs_dir into a themed
HTML page, so we can't just drop a copy into docs/ with a .md extension --
it would get rendered instead of served raw. This hook copies the file with
a plain .md extension too, but that's safe here because the copy lands in
site_dir (the build *output*) via on_post_build, not in docs_dir (the
*source*). By the time on_post_build runs, MkDocs has already finished
converting every *.md file under docs_dir into its HTML page, so a .md file
dropped into site_dir afterward is never picked up as a page to render --
it's just an inert static file that gets served as-is. The
`download="<skill-id>-SKILL.md"` attribute on each link restores the
correct filename when the browser saves it.

This runs on every build/serve, so the copies always match the current
skills sources -- nothing here needs to be hand-maintained.

IMPORTANT: this writes into site_dir (the *build output*), not docs_dir (the
*source*), and does so in on_post_build rather than on_pre_build. `mkdocs
serve` watches docs_dir for changes and rebuilds on every write there. If
this hook wrote its copies into docs_dir instead, every rebuild would
re-touch docs/assets/skill-downloads/*.md, which the watcher would see
as a new change, triggering another rebuild, which touches those files
again -- an infinite restart loop. Writing to site_dir after the build
completes sidesteps that: site_dir is never watched, so these copies can
never trigger a rebuild. Because MkDocs does not see these post-build files,
it also does not rewrite their links for directory URLs. This hook therefore
adjusts generated skill-page links from `../assets/...` to `../../assets/...`
before the redirect hook mirrors the site under its deployment prefixes.
"""
from pathlib import Path
import shutil


DOWNLOAD_HREF = 'href="../assets/skill-downloads/'
BUILT_DOWNLOAD_HREF = 'href="../../assets/skill-downloads/'


def on_post_build(config):
    project_root = Path(config["config_file_path"]).parent
    skill_library_dir = project_root / "skills"
    if not skill_library_dir.exists():
        return

    dest_dir = Path(config["site_dir"]) / "assets" / "skill-downloads"
    dest_dir.mkdir(parents=True, exist_ok=True)

    for skill_md in sorted(skill_library_dir.glob("*/SKILL.md")):
        skill_id = skill_md.parent.name
        shutil.copyfile(skill_md, dest_dir / f"{skill_id}.md")

    # The download assets do not exist until this post-build hook runs, so
    # MkDocs cannot recognize and rewrite their source-relative links. With
    # directory URLs, a skill page is served as /skills/<skill-id>/ and the
    # unchanged ../assets link incorrectly resolves to /skills/assets. Adjust
    # the built HTML by one level while keeping the Markdown source path valid.
    for html_file in (Path(config["site_dir"]) / "skills").rglob("*.html"):
        html = html_file.read_text(encoding="utf-8")
        updated = html.replace(DOWNLOAD_HREF, BUILT_DOWNLOAD_HREF)
        if updated != html:
            html_file.write_text(updated, encoding="utf-8")
