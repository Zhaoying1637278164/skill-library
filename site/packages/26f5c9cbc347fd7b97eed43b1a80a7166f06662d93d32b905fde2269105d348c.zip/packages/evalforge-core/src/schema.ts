import { z } from 'zod';
import * as jsYaml from 'js-yaml';
import { CODE_TAG, REPO_PREFIX } from './evalforge';

const NamePattern = /^[a-z0-9][a-z0-9/_-]*$/;
export const RESERVED_TAG_PREFIXES = ['draft:', 'pending:', 'rejected:', REPO_PREFIX] as const;
export const RESERVED_TAGS = [CODE_TAG] as const;

const ParamScalarSchema = z.union([z.string(), z.number(), z.boolean()]);

const ParamValueSchema = z.union([
  ParamScalarSchema,
  z.array(ParamScalarSchema),
]);

// For api_call expectedResponse/requestBody/requestHeaders: accept a YAML object/array (mapper
// JSON-stringifies it) or a literal JSON string (passed through).
const JsonStringOrStructured = z.union([
  z.string(),
  z.record(z.string(), z.unknown()),
  z.array(z.unknown()),
]);

const ToolCallAssertionSchema = z.object({
  type: z.literal('tool_called_with_param').optional(),
  tool: z.string().min(1),
  params: z.record(z.string(), ParamValueSchema).optional(),
  negate: z.boolean().optional(),
}).strict();

const AssertionParameterSchema = z.object({
  name: z.string().min(1),
  label: z.string().min(1),
  type: z.enum(['string', 'number', 'boolean']),
  required: z.boolean(),
  defaultValue: z.union([z.string(), z.number(), z.boolean()]).optional(),
  advanced: z.boolean().optional(),
}).strict();

const LlmJudgeAssertionSchema = z.object({
  type: z.literal('llm_judge'),
  prompt: z.string().min(1),
  // Floor for numeric judges: one whose minScore it can never fail (0) does not gate,
  // and an omitted minScore silently defers to a server-side default. Boolean-scoringMode
  // judges pass/fail without a score, so the requirement (below) exempts them.
  minScore: z.number().int()
    .min(7, 'minScore must be at least 7 — a judge that cannot fail does not gate (see docs/eval-scenarios.md)')
    .max(10)
    .optional(),
  model: z.string().optional(),
  maxTokens: z.number().int().positive().optional(),
  temperature: z.number().min(0).max(1).optional(),
  scoringMode: z.enum(['numeric', 'boolean']).optional(),
  browserTools: z.boolean().optional(),
  parameters: z.array(AssertionParameterSchema).optional(),
  negate: z.boolean().optional(),
}).strict().superRefine((a, ctx) => {
  if (a.scoringMode !== 'boolean' && a.minScore === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'minScore is required for numeric llm_judge assertions (integer 7-10) — a judge that cannot fail does not gate',
      path: ['minScore'],
    });
  }
});

const ApiCallAssertionSchema = z.object({
  type: z.literal('api_call'),
  url: z.string().min(1),
  method: z.enum(['GET', 'POST']).optional(),
  requestBody: JsonStringOrStructured.optional(),
  expectedResponse: JsonStringOrStructured,
  requestHeaders: JsonStringOrStructured.optional(),
  timeoutMs: z.number().int().positive().optional(),
  negate: z.boolean().optional(),
}).strict();

const CostAssertionSchema = z.object({
  type: z.literal('cost'),
  maxCostUsd: z.number().positive(),
  negate: z.boolean().optional(),
}).strict();

const TimeLimitAssertionSchema = z.object({
  type: z.literal('time_limit'),
  maxDurationMs: z.number().int().positive(),
  negate: z.boolean().optional(),
}).strict();

const SkillWasCalledAssertionSchema = z.object({
  type: z.literal('skill_was_called'),
  skillNames: z.array(z.string().min(1)).min(1),
  referenceFiles: z.record(z.string(), z.array(z.string().min(1)).min(1)).optional(),
  negate: z.boolean().optional(),
}).strict();

const BuildPassedAssertionSchema = z.object({
  type: z.literal('build_passed'),
  command: z.string().optional(),
  expectedExitCode: z.number().int().optional(),
  negate: z.boolean().optional(),
}).strict();

const TokenCountAssertionSchema = z.object({
  type: z.literal('token_count'),
  maxTokens: z.number().int().positive(),
  negate: z.boolean().optional(),
}).strict();

const AssertionSchema = z.union([
  ToolCallAssertionSchema,
  LlmJudgeAssertionSchema,
  ApiCallAssertionSchema,
  CostAssertionSchema,
  TimeLimitAssertionSchema,
  SkillWasCalledAssertionSchema,
  BuildPassedAssertionSchema,
  TokenCountAssertionSchema,
]);

export type ToolCallAssertion = z.infer<typeof ToolCallAssertionSchema>;
export type LlmJudgeAssertion = z.infer<typeof LlmJudgeAssertionSchema>;
export type ApiCallAssertion = z.infer<typeof ApiCallAssertionSchema>;
export type CostAssertion = z.infer<typeof CostAssertionSchema>;
export type TimeLimitAssertion = z.infer<typeof TimeLimitAssertionSchema>;
export type SkillWasCalledAssertion = z.infer<typeof SkillWasCalledAssertionSchema>;
export type BuildPassedAssertion = z.infer<typeof BuildPassedAssertionSchema>;
export type TokenCountAssertion = z.infer<typeof TokenCountAssertionSchema>;
export type Assertion = z.infer<typeof AssertionSchema>;

// Optional per-scenario site provisioning. Only `template` mode is supported.
const SiteBootstrapStepSchema = z.object({
  label: z.string().optional(),
  method: z.enum(['get', 'post', 'put', 'patch', 'delete']),
  url: z.string().min(1),
  body: z.record(z.string(), z.unknown()).optional(),
}).strict();

const SiteBootstrapSchema = z.object({
  steps: z.array(SiteBootstrapStepSchema).default([]),
}).strict();

// `templateId` is a Wix template alias (e.g. "ecommerce") or a template GUID, resolved at
// provisioning time — any non-empty string is accepted here.
const SiteSetupSchema = z.object({
  mode: z.literal('template').default('template'),
  templateId: z.string().min(1),
  bootstrap: SiteBootstrapSchema.optional(),
}).strict();

export type SiteBootstrapStep = z.infer<typeof SiteBootstrapStepSchema>;
export type SiteSetup = z.infer<typeof SiteSetupSchema>;

export const ScenarioSchema = z.object({
  name: z.string().min(1).regex(NamePattern, 'name must match /^[a-z0-9][a-z0-9/_-]*$/'),
  description: z.string(),
  triggerPrompt: z.string().min(10),
  // Optional scenario-level template the run scaffolds from (an EvalForge template
  // id/alias). Distinct from `siteSetup` (which provisions a site). Omit when unused.
  templateId: z.string().min(1).optional(),
  tags: z.array(z.string().min(1)).min(1).refine(
    tags => tags.every(t =>
      !RESERVED_TAG_PREFIXES.some(p => t.startsWith(p)) && !RESERVED_TAGS.some(r => t === r)),
    { message: 'tags must not include reserved namespaces (draft:*, pending:*, rejected:*, repo:*) or reserved tags (created-via-code) — the action manages those' },
  ),
  maxTokens: z.number().int().positive().optional(),
  assertions: z.array(AssertionSchema).min(1),
  siteSetup: SiteSetupSchema.optional(),
}).strict().superRefine((data, ctx) => {
  // A provisioned site supplies the site id, so siteSetup can't be combined with a {{site-id}} variable.
  if (data.siteSetup && /\{\{\s*site-id\s*\}\}/.test(data.triggerPrompt)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'siteSetup cannot be combined with a {{site-id}} run variable in triggerPrompt — the provisioned site replaces it',
      path: ['triggerPrompt'],
    });
  }
});

export type Scenario = z.infer<typeof ScenarioSchema>;

export function isLlmJudge(a: Assertion): a is LlmJudgeAssertion {
  return a.type === 'llm_judge';
}

export function isApiCall(a: Assertion): a is ApiCallAssertion {
  return a.type === 'api_call';
}

export function isCost(a: Assertion): a is CostAssertion {
  return a.type === 'cost';
}

export function isTimeLimit(a: Assertion): a is TimeLimitAssertion {
  return a.type === 'time_limit';
}

export function isToolCall(a: Assertion): a is ToolCallAssertion {
  return a.type === undefined || a.type === 'tool_called_with_param';
}

export function isSkillWasCalled(a: Assertion): a is SkillWasCalledAssertion {
  return a.type === 'skill_was_called';
}

export function isBuildPassed(a: Assertion): a is BuildPassedAssertion {
  return a.type === 'build_passed';
}

export function isTokenCount(a: Assertion): a is TokenCountAssertion {
  return a.type === 'token_count';
}

export function parseScenario(raw: string): Scenario {
  // CORE_SCHEMA refuses unsafe YAML tags (e.g. !!js/function); defense in depth before Zod.
  const parsed = jsYaml.load(raw, { schema: jsYaml.CORE_SCHEMA });
  // Pre-flight: nested-object params get a clearer message than Zod's union error.
  // Only applies to tool-call assertions (which use `params`); other types have their own shapes.
  const obj = parsed as { assertions?: { type?: string; params?: Record<string, unknown>; minScore?: unknown; scoringMode?: unknown }[] } | null | undefined;
  if (obj?.assertions) {
    for (const a of obj.assertions) {
      // Same union-error problem for a missing minScore: Zod reports "Invalid input"
      // instead of naming the field, so say it plainly here. Boolean-scoringMode judges
      // pass/fail without a score and are exempt.
      if (a?.type === 'llm_judge' && a.minScore === undefined && a.scoringMode !== 'boolean') {
        throw new Error('llm_judge requires minScore (integer 7-10) — a judge that cannot fail does not gate');
      }
      const isToolCallShape = a?.type === undefined || a?.type === 'tool_called_with_param';
      if (!isToolCallShape || !a?.params) continue;
      for (const [k, v] of Object.entries(a.params)) {
        if (v && typeof v === 'object' && !Array.isArray(v)) {
          throw new Error(`nested object not allowed in tool params — params must be primitives or arrays of primitives. Offending key: assertions.params.${k}`);
        }
      }
    }
  }
  const result = ScenarioSchema.safeParse(parsed);
  if (result.success) return result.data;
  throw new Error(describeIssues(result.error));
}

/**
 * Zod's own `message` is the serialised issue array, so it reached the PR comment as ~15 lines of
 * JSON for a one-line problem. One `path: message` per issue instead.
 */
function describeIssues(error: z.ZodError): string {
  return error.issues
    .map(issue => (issue.path.length === 0 ? issue.message : `${issue.path.join('.')}: ${issue.message}`))
    .join('; ');
}
