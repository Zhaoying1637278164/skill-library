import { readFileSync } from 'node:fs';
import { posix } from 'node:path';
import { glob } from 'glob';
import { parseScenario, type Scenario } from './schema';

export type LoadedScenario = { path: string; scenario: Scenario };
export type LoadError = { path: string; message: string };

/**
 * The directory a scenario glob covers, so an author can be told where to add one: the leading
 * wildcard-free prefix of the pattern. With no wildcard at all the last segment is a filename,
 * so it is dropped. See the tests for the concrete patterns.
 */
export function scenarioDirFromGlob(globPattern: string): string {
  const segments = globPattern.split('/');
  const firstWildcard = segments.findIndex(segment => /[*?{[]/.test(segment));
  const directory = firstWildcard === -1 ? segments.slice(0, -1) : segments.slice(0, firstWildcard);
  return directory.join('/');
}

export function loadScenarios(root: string, globPattern: string): {
  scenarios: Map<string, LoadedScenario>;
  errors: LoadError[];
} {
  const found = glob.sync(globPattern, {
    cwd: root,
    nodir: true,
    ignore: ['**/node_modules/**', '**/dist/**', '.action-src/**'],
    posix: true,
  });

  const scenarios = new Map<string, LoadedScenario>();
  const errors: LoadError[] = [];

  for (const rel of found.sort()) {
    let parsed: Scenario;
    try {
      parsed = parseScenario(readFileSync(posix.join(root, rel), 'utf8'));
    } catch (e) {
      errors.push({ path: rel, message: e instanceof Error ? e.message : String(e) });
      continue;
    }
    const existing = scenarios.get(parsed.name);
    if (existing) {
      errors.push({
        path: rel,
        message: `duplicate name "${parsed.name}" — also declared at ${existing.path}`,
      });
      continue;
    }
    scenarios.set(parsed.name, { path: rel, scenario: parsed });
  }

  return { scenarios, errors };
}
