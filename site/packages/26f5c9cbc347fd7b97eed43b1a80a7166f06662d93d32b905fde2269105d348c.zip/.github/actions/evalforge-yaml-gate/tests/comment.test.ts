import { describe, it, expect } from 'vitest';
import * as c from '../src/utils/comment';
import type { CompareGroupComplete, ScenarioComparison, ScenarioRunResult } from '../src/utils/eval-pipeline';

function run(over: Partial<ScenarioRunResult> = {}): ScenarioRunResult {
  return {
    runId: 'r1',
    name: 'scenario-a',
    passed: 1,
    failed: 0,
    totalCostUsd: 0.001,
    totalTokens: 1000,
    durationMs: 1000,
    assertions: [{ name: 'a', type: 'llm', status: 'passed' }],
    ...over,
  };
}

function scenario(over: Partial<ScenarioComparison> = {}): ScenarioComparison {
  return {
    scenarioId: 's1',
    scenarioName: 'scenario-a',
    required: true,
    reason: 'because',
    with: run({ runId: 'pr-run', name: 'scenario-a' }),
    without: run({ runId: 'prod-run', name: 'scenario-a' }),
    pairwiseJudgement: { winner: 'with', confidence: 'high', reasoning: 'PR is better' },
    ...over,
  };
}

function group(
  scenarios: ScenarioComparison[],
  resultOver: Partial<CompareGroupComplete['result']> = {},
): CompareGroupComplete {
  return {
    status: 'complete',
    completedRuns: scenarios.length,
    totalRuns: scenarios.length,
    result: { comparisonGroupId: 'cg1', verdict: 'not-required', tag: 'draft:wix/skills#1', scenarios, ...resultOver },
  };
}

describe('comment formatters', () => {
  it('formatLoadErrors lists each error', () => {
    const out = c.formatLoadErrors([{ path: 'a/b.yml', message: 'bad' }]);
    expect(out).toContain('a/b.yml');
    expect(out).toContain('bad');
    expect(out).toContain(c.COMMENT_MARKER);
  });

  it('formatUncovered includes canonical URL hint and the expected evals path', () => {
    const out = c.formatUncovered([{ file: 'skills/wix-manage/references/events/x.md', canonicalUrl: 'https://example/x', area: 'events' }]);
    expect(out).toContain('https://example/x');
    expect(out).toContain('yaml/wix-manage-evals/events/');
  });

  it('formatForeignDraftConflicts resolves PR URLs from tag format', () => {
    const out = c.formatForeignDraftConflicts(
      [{ kind: 'FOREIGN_DRAFT', name: 'blog/x', foreignTags: ['draft:wix/skills#99'] }],
      { owner: 'wix', repo: 'skills' },
    );
    expect(out).toContain('https://github.com/wix/skills/pull/99');
  });

  it('formatForeignDraftConflicts falls back to raw tag if malformed', () => {
    const out = c.formatForeignDraftConflicts(
      [{ kind: 'FOREIGN_DRAFT', name: 'blog/x', foreignTags: ['draft:malformed'] }],
      { owner: 'wix', repo: 'skills' },
    );
    expect(out).toContain('draft:malformed');
  });

  it('formatOrphanedMds lists each file', () => {
    expect(c.formatOrphanedMds(['skills/wix-manage/references/blog/foo.md']))
      .toContain('skills/wix-manage/references/blog/foo.md');
  });

  it('formatServiceError icon switches by blocking flag', () => {
    expect(c.formatServiceError('boom', true)).toContain('❌');
    expect(c.formatServiceError('boom', false)).toContain('⚠️');
  });

  it('formatDocsEntryProblems renders a reason line per problem kind', () => {
    const base = { file: 'skills/wix-manage/references/seo/a.md', yamlPath: 'yaml/wix-manage/seo/documentation.yaml', title: 'A', docsEntry: 'https://dev.wix.com/docs/api-reference/x' };
    const out = c.formatDocsEntryProblems([
      { ...base, kind: 'portal-not-found' },
      { ...base, kind: 'node-not-found' },
      { ...base, kind: 'not-a-category', nodeType: 'RESOURCE', suggestion: 'https://dev.wix.com/docs/api-reference/parent' },
    ]);
    expect(out).toContain('does not match any docs portal');
    expect(out).toContain('does not exist in the docs menu');
    expect(out).toContain('an API page, not a category');
    expect(out).toContain('https://dev.wix.com/docs/api-reference/parent');
    expect(out).toContain('or pick/create a different one');
    expect(out).toContain('yaml/wix-manage/seo/documentation.yaml');
    expect(out).toContain(c.COMMENT_MARKER);
  });

  it('formatDocsEntryProblems calls a SECTION target a section and falls back when there is no suggestion', () => {
    const out = c.formatDocsEntryProblems([
      { file: 'f.md', yamlPath: 'y.yaml', title: 'A', docsEntry: 'https://dev.wix.com/docs/api-reference/tools', kind: 'not-a-category', nodeType: 'SECTION' },
    ]);
    expect(out).toContain('a section, not a category');
    expect(out).not.toContain('the category that groups it');
    expect(out).toContain('Point it at an existing category, or create one in the docs menu.');
  });

  it('formatEvalPassed includes pass rate + run link', () => {
    const metrics = { totalAssertions: 1, passed: 1, failed: 0, skipped: 0, errors: 0, passRate: 100, avgDuration: 0, totalDuration: 0 };
    const out = c.formatEvalPassed(metrics, 'run-1', 'https://bo.wix.com/pages/evalforge/proj-1/results?runId=run-1');
    expect(out).toContain('100%');
    expect(out).toContain('run-1');
    expect(out).toContain('(https://bo.wix.com/pages/evalforge/proj-1/results?runId=run-1)');
  });

  it('formatNoChanges signals success', () => {
    expect(c.formatNoChanges()).toContain('No Gated Changes');
  });

  it('formatComparisonResult warns and drops the green tick when judging was partial', () => {
    const tie = scenario({ pairwiseJudgement: undefined, required: false });
    const out = c.formatComparisonResult(group([tie], { judgeCoverage: { judged: 1, total: 3 } }), 'proj-1');

    // A not-required verdict from partial judging must not read as a pass.
    // Scoped to the heading, since ✅/⚠️ also appear in the scenario rows.
    const heading = out.split('\n').find(l => l.startsWith('## '))!;
    expect(out).toContain('Only 1/3 scenarios were judged');
    expect(heading).toContain('⚠️');
    expect(heading).not.toContain('✅');
  });

  it('formatComparisonResult keeps the green tick at full coverage', () => {
    const tie = scenario({ pairwiseJudgement: { winner: 'tie', confidence: 'high', reasoning: 'same' }, required: false });
    const out = c.formatComparisonResult(group([tie], { judgeCoverage: { judged: 1, total: 1 } }), 'proj-1');
    const heading = out.split('\n').find(l => l.startsWith('## '))!;

    expect(out).not.toContain('scenarios were judged');
    expect(heading).toContain('✅');
  });

  it('formatComparisonResult is unchanged when the pipeline reports no coverage', () => {
    const tie = scenario({ pairwiseJudgement: { winner: 'tie', confidence: 'high', reasoning: 'same' }, required: false });
    const out = c.formatComparisonResult(group([tie]), 'proj-1');

    // Older pipeline builds omit the field; absent must not mean degraded.
    const heading = out.split('\n').find(l => l.startsWith('## '))!;
    expect(out).not.toContain('scenarios were judged');
    expect(heading).toContain('✅');
  });

  it('formatComparisonResult adds a Runs column with PR + prod run links', () => {
    const out = c.formatComparisonResult(group([scenario()]), 'proj-1');
    expect(out).toContain('Runs (PR / prod)');
    // top-level table cell links (not only inside <details>)
    expect(out).toContain('[PR](https://bo.wix.com/pages/evalforge/proj-1/results?runId=pr-run&name=scenario-a)');
    expect(out).toContain('[prod](https://bo.wix.com/pages/evalforge/proj-1/results?runId=prod-run&name=scenario-a)');
  });

  it('formatComparisonResult falls back to — when projectId is missing', () => {
    const out = c.formatComparisonResult(group([scenario()]));
    expect(out).toContain('Runs (PR / prod)');
    expect(out).not.toContain('bo.wix.com');
    expect(out).toContain('| — / — |');
  });

  it('formatComparisonResult falls back to — for a run with no runId', () => {
    const s = scenario({ with: run({ runId: undefined, name: 'scenario-a' }), without: run({ runId: 'prod-run' }) });
    const out = c.formatComparisonResult(group([s]), 'proj-1');
    expect(out).toContain('— / [prod](https://bo.wix.com/pages/evalforge/proj-1/results?runId=prod-run');
  });

  it('formatComparisonResult renders View run links inside details for both modes', () => {
    const out = c.formatComparisonResult(group([scenario()]), 'proj-1');
    expect(out).toContain('[View run (PR)](https://bo.wix.com/pages/evalforge/proj-1/results?runId=pr-run');
    expect(out).toContain('[View run (prod)](https://bo.wix.com/pages/evalforge/proj-1/results?runId=prod-run');
  });

  it('formatComparisonResult handles a scenario with no pairwiseJudgement', () => {
    // The pipeline omits pairwiseJudgement when pairwise judging is off or the judge fails.
    const out = c.formatComparisonResult(group([scenario({ pairwiseJudgement: undefined })]), 'proj-1');
    // renders a placeholder winner instead of throwing on the missing field
    expect(out).toContain('| scenario-a | ✅ | — |');
    expect(out).not.toContain('Compare result:');
  });

  it('formatTooManyNewSkills includes count and file names', () => {
    const out = c.formatTooManyNewSkills(2, 1, [
      'skills/wix-manage/references/payments/process.md',
      'skills/wix-manage/references/invoicing/create.md',
    ]);
    expect(out).toContain('2');
    expect(out).toContain('payments/process.md');
    expect(out).toContain('invoicing/create.md');
    expect(out).toContain('Too Many New Skills');
    expect(out).toContain(c.COMMENT_MARKER);
  });

  it('formatTooManyNewSkills suggests splitting PRs', () => {
    const out = c.formatTooManyNewSkills(2, 1, ['a.md', 'b.md']);
    expect(out).toContain('Split across multiple PRs');
  });

  it('formatTooManyNewSkills shows configured limit', () => {
    const out = c.formatTooManyNewSkills(4, 3, ['a.md', 'b.md', 'c.md', 'd.md']);
    expect(out).toContain('3');
  });

  it('formatTooManyNewSkills lists all files', () => {
    const files = ['area-one/skill.md', 'area-two/skill.md', 'area-three/skill.md'];
    const out = c.formatTooManyNewSkills(files.length, 1, files);
    files.forEach(file => {
      expect(out).toContain(`\`${file}\``);
    });
  });

  it('formatTokenBudgetExceeded lists budget details and the PR run link', () => {
    const out = c.formatTokenBudgetExceeded([{
      scenarioName: 'ecommerce/ecom-load-context',
      maxTokens: 25_000,
      prTokens: 31_420,
      prodTokens: 18_000,
      prRunId: 'run-pr',
      prRunName: 'PR run',
    }], 'project-1');

    expect(out).toContain('Token Budget Exceeded');
    expect(out).toContain('ecommerce/ecom-load-context');
    expect(out).toContain('25,000');
    expect(out).toContain('31,420');
    expect(out).toContain('18,000');
    expect(out).toContain('run-pr');
    expect(out).toContain(c.COMMENT_MARKER);
  });

  it('formatComparisonResult reports no winner when both runs fail the LLM judge', () => {
    const out = c.formatComparisonResult({
      status: 'complete',
      completedRuns: 2,
      totalRuns: 2,
      result: {
        comparisonGroupId: 'cmp-1',
        verdict: 'not-required',
        tag: 'draft:wix/skills#473',
        scenarios: [{
          scenarioId: 'scenario-1',
          scenarioName: 'bookings/diagnose-availability-issues',
          required: false,
          reason: 'pairwise judge: with-skill wins',
          with: {
            passed: 1,
            failed: 1,
            totalCostUsd: 0.312,
            totalTokens: 121_503,
            durationMs: 55_900,
            assertions: [
              { name: 'Tool called with param', type: 'tool', status: 'passed' },
              { name: 'LLM judge', type: 'llm_judge', status: 'failed', score: 4, message: 'incomplete' },
            ],
          },
          without: {
            passed: 1,
            failed: 1,
            totalCostUsd: 0.411,
            totalTokens: 159_736,
            durationMs: 62_800,
            assertions: [
              { name: 'Tool called with param', type: 'tool', status: 'passed' },
              { name: 'LLM judge', type: 'llm_judge', status: 'failed', score: 0, message: 'wrong level of detail' },
            ],
          },
          pairwiseJudgement: {
            winner: 'with',
            confidence: 'high',
            reasoning: 'Response A better serves the task.',
          },
        }],
      },
    });

    expect(out).toContain('## ⚠️ EvalForge YAML Gate: Eval Comparison');
    expect(out).toContain('| bookings/diagnose-availability-issues | ❌ | - |');
    expect(out).toContain('**No winner:** both runs failed the LLM judge.');
    expect(out).not.toContain('⬆️ with (high)');
  });
});
