import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import * as core from '@actions/core';
import * as jsYaml from 'js-yaml';
import { REVIEW_SEVERITIES, type ReviewFinding, type ReviewSeverity } from './review-comment';

/**
 * `--tools` is the closed set. Bash is wider than the grant below, though: `ls`, `cat`, `grep` and
 * read-only `git` run unprompted in every mode, and that set is not configurable.
 */
const TOOLS = 'Read,Grep,Glob,Bash';
const ALLOWED_TOOLS = 'Read,Grep,Glob,Bash(git diff:*)';

/**
 * The working directory is the PR's own tree, which holds `.mcp.json`, `.claude/` and `AGENTS.md`.
 *
 * `--bare` is load-bearing: without it a `-p` run connects that `.mcp.json`'s servers and runs its
 * hooks with no trust dialog, and reads its CLAUDE.md — so a PR could hand itself network access
 * and write instructions to the agent reviewing it. `--restricted` confines the file tools to the
 * working directory and refuses bypassPermissions.
 */
const SANDBOX_ARGS = ['--bare', '--restricted', '--permission-prompts', 'none'];

/**
 * Built up, never filtered down. Actions materialises every input as `INPUT_<NAME>` — including
 * `INPUT_GITHUB-TOKEN` and `INPUT_EVALFORGE-APP-SECRET` — alongside `ACTIONS_RUNTIME_TOKEN`, and
 * inheriting `process.env` would put all of it inside a process whose job is to read text an
 * outside contributor wrote. A denylist would have to track every variable the runner adds.
 */
const INHERITED_ENV = ['PATH', 'HOME', 'SHELL', 'LANG', 'LC_ALL', 'TZ', 'TMPDIR'] as const;

const MAX_STDERR_CHARS = 2000;
const MAX_STDOUT_BYTES = 8 * 1024 * 1024;
const SIGKILL_GRACE_MS = 5000;

/** Built from `REVIEW_SEVERITIES`, so a new severity cannot be accepted here and rejected there. */
const OUTPUT_SCHEMA = JSON.stringify({
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          file: {
            type: 'string',
            description: 'Path from the repository root. The file the finding is on, or the skill that should be unified with others.',
          },
          line: { type: 'integer', description: 'The line in that file, where the finding is about specific text' },
          section: {
            type: 'string',
            description: 'The guide section, when one covers it — e.g. CONTRIBUTING.md#stay-agnostic-to-agent-and-client',
          },
          severity: { enum: [...REVIEW_SEVERITIES] },
          quote: { type: 'string', description: 'The offending line' },
          suggestion: { type: 'string', description: 'The change that resolves the finding' },
          consequence: { type: 'string', description: 'What an agent or a user gets wrong because of this — the failure itself, not the fix' },
        },
        required: ['file', 'severity', 'suggestion', 'consequence'],
        additionalProperties: false,
      },
    },
  },
  required: ['findings'],
  additionalProperties: false,
});

export type AgentInvocation = {
  cwd: string;
  task: string;
  apiKey: string;
  baseUrl: string;
  model: string;
  effort: string;
  timeoutSeconds: number;
};

export type AgentOutcome =
  | { ok: true; findings: ReviewFinding[]; discarded: number }
  | { ok: false; reason: string };

type CliResult =
  | { kind: 'completed'; code: number; stdout: string; stderrTail: string }
  | { kind: 'timeout' }
  | { kind: 'not-installed' }
  | { kind: 'oversized' }
  | { kind: 'spawn-failed'; message: string };

export function buildAgentEnv(apiKey: string, baseUrl: string): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {};
  for (const name of INHERITED_ENV) {
    const value = process.env[name];
    if (value !== undefined) env[name] = value;
  }
  return {
    ...env,
    ANTHROPIC_API_KEY: apiKey,
    ANTHROPIC_BASE_URL: baseUrl,
    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
  };
}

export const REVIEW_AGENT = 'skill-review';

const AGENT_DIR = '.claude/agents';

type AgentFrontmatter = {
  name?: string;
  description?: string;
  tools?: string;
};

export function agentPath(workspace: string): string {
  return join(workspace, AGENT_DIR, `${REVIEW_AGENT}.md`);
}

function buildAgents(workspace: string): string {
  const raw = readFileSync(agentPath(workspace), 'utf8');

  const match = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/.exec(raw);
  if (match === null) throw new Error(`${AGENT_DIR}/${REVIEW_AGENT}.md has no frontmatter`);

  const front = (jsYaml.load(match[1]) ?? {}) as AgentFrontmatter;
  if (front.name !== REVIEW_AGENT) {
    throw new Error(`${AGENT_DIR}/${REVIEW_AGENT}.md declares name "${front.name}", which must match its filename`);
  }
  if (front.description === undefined || front.description.trim() === '') {
    throw new Error(`${AGENT_DIR}/${REVIEW_AGENT}.md has no description`);
  }

  const prompt = match[2].trim();
  if (prompt === '') throw new Error(`${AGENT_DIR}/${REVIEW_AGENT}.md has no prompt body`);

  const tools = (front.tools ?? '').split(',').map(entry => entry.trim()).filter(entry => entry !== '');

  return JSON.stringify({
    [REVIEW_AGENT]: {
      description: front.description.trim(),
      prompt,
      ...(tools.length > 0 ? { tools } : {}),
    },
  });
}

function buildArgs(invocation: AgentInvocation): string[] {
  return [
    '-p',
    ...SANDBOX_ARGS,
    '--tools', TOOLS,
    '--agents', buildAgents(invocation.cwd),
    '--agent', REVIEW_AGENT,
    '--allowedTools', ALLOWED_TOOLS,
    '--json-schema', OUTPUT_SCHEMA,
    '--output-format', 'json',
    '--model', invocation.model,
    '--effort', invocation.effort,
  ];
}

function runCli(invocation: AgentInvocation): Promise<CliResult> {
  return new Promise(resolve => {
    const child = spawn('claude', buildArgs(invocation), {
      cwd: invocation.cwd,
      env: buildAgentEnv(invocation.apiKey, invocation.baseUrl),
      stdio: ['pipe', 'pipe', 'pipe'],
      // Explicit though it is the default: a shell would re-parse this argv.
      shell: false,
      // Its own process group, so the timeout kill reaches grandchildren. Otherwise a stuck one
      // holds the stdout pipe open, `close` never fires, and the job hangs to its own timeout.
      detached: true,
    });

    let settled = false;
    let stdout = '';
    let stdoutBytes = 0;
    let stderrTail = '';

    const killGroup = (signal: NodeJS.Signals): void => {
      try {
        if (child.pid) process.kill(-child.pid, signal);
      } catch {
        try { child.kill(signal); } catch { /* already gone */ }
      }
    };

    const finish = (result: CliResult): void => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(result);
    };

    const timer = setTimeout(() => {
      killGroup('SIGTERM');
      setTimeout(() => killGroup('SIGKILL'), SIGKILL_GRACE_MS).unref();
      finish({ kind: 'timeout' });
    }, invocation.timeoutSeconds * 1000);

    // Prevent characters cutting between chunks.
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');

    child.stdout.on('data', (chunk: string) => {
      stdoutBytes += Buffer.byteLength(chunk);
      if (stdoutBytes > MAX_STDOUT_BYTES) {
        killGroup('SIGKILL');
        finish({ kind: 'oversized' });
        return;
      }
      stdout += chunk;
    });

    // Tail only, and it never reaches the PR comment: stderr can carry an upstream error page.
    child.stderr.on('data', (chunk: string) => {
      stderrTail = (stderrTail + chunk).slice(-MAX_STDERR_CHARS);
    });

    child.on('error', (error: NodeJS.ErrnoException) => finish(
      error.code === 'ENOENT'
        ? { kind: 'not-installed' }
        : { kind: 'spawn-failed', message: error.message },
    ));

    child.on('close', code => finish({ kind: 'completed', code: code ?? -1, stdout, stderrTail }));

    // stdin, not argv: argv has a length ceiling and is readable through /proc. EPIPE is swallowed
    // because the child may exit before it finishes reading.
    child.stdin.on('error', () => {});
    child.stdin.end(invocation.task, 'utf8');
  });
}

type Envelope = {
  structured_output?: { findings?: ReviewFinding[] };
  terminal_reason?: unknown;
  result?: unknown;
  errors?: unknown;
  num_turns?: unknown;
  duration_ms?: unknown;
  total_cost_usd?: unknown;
  permission_denials?: unknown;
};

/** `result` holds the text on most failures, but a turn-limit stop carries `errors` instead. */
function describeEnvelope(envelope: Envelope): string {
  const detail = typeof envelope.result === 'string' ? envelope.result
    : Array.isArray(envelope.errors) ? envelope.errors.join('; ')
    : '';
  const reason = String(envelope.terminal_reason ?? 'unknown');
  return detail === '' ? reason : `${reason}: ${detail}`;
}

function parseEnvelope(stdout: string): Envelope | undefined {
  try {
    return JSON.parse(stdout) as Envelope;
  } catch {
    return undefined;
  }
}

/**
 * Denials are why this exists: a refused tool is not an error in `-p` mode — the model is told no
 * and carries on — so a mis-scoped allowlist quietly produces a thinner review behind a green check.
 */
function logRunStats(envelope: Envelope): void {
  const turns = typeof envelope.num_turns === 'number' ? envelope.num_turns : '?';
  const cost = typeof envelope.total_cost_usd === 'number' ? envelope.total_cost_usd : '?';
  const took = typeof envelope.duration_ms === 'number' ? envelope.duration_ms : '?';
  core.info(`Reviewer run: took ${took} ms, cost ${cost} usd, ${turns} turns.`);

  const denials = Array.isArray(envelope.permission_denials) ? envelope.permission_denials : [];
  if (denials.length > 0) {
    core.info(`The reviewer was denied ${denials.length} tool call(s) — check the allowlist: ${JSON.stringify(denials).slice(0, 500)}`);
  }
}

// One pass over everything the agent wrote
function sanitize<T>(value: T, apiKey: string): T {
  if (value === undefined) return value;
  const json = JSON.stringify(value).replace(/<!--/g, '&lt;!--');
  // Guarded: splitting on an empty key would redact between every character.
  return JSON.parse(apiKey === '' ? json : json.split(apiKey).join('[redacted]')) as T;
}

function isSeverity(value: unknown): value is ReviewSeverity {
  return typeof value === 'string' && (REVIEW_SEVERITIES as readonly string[]).includes(value);
}

function isReportable(finding: ReviewFinding): boolean {
  return isSeverity(finding.severity);
}

function parseFindings(
  output: Envelope['structured_output'],
): { findings: ReviewFinding[]; discarded: number } | undefined {
  const list = output?.findings;
  if (!Array.isArray(list)) return undefined;

  const findings = list.filter(isReportable);
  return { findings, discarded: list.length - findings.length };
}

function describeFailure(result: CliResult): string {
  switch (result.kind) {
    case 'timeout': return 'it exceeded its time limit and was stopped';
    case 'not-installed': return 'the reviewer is not installed on this runner';
    case 'oversized': return 'it returned an unreadable amount of output';
    case 'spawn-failed': return 'the reviewer could not be started';
    case 'completed': return `the reviewer exited with code ${result.code}`;
  }
}

/** No retry here: the CLI already re-rolls a schema failure five times by default. */
export async function runReviewAgent(invocation: AgentInvocation): Promise<AgentOutcome> {
  const result = await runCli(invocation);

  if (result.kind !== 'completed' || result.code !== 0) {
    if (result.kind === 'completed') {
      // A failure inside the run is reported as the result on stdout; stderr is startup only.
      const envelope = parseEnvelope(result.stdout);
      if (envelope !== undefined) {
        core.info(`Reviewer failure — ${describeEnvelope(envelope).slice(0, 500)}`);
      }
      if (result.stderrTail !== '') core.info(`Reviewer stderr (tail): ${result.stderrTail}`);
    }
    return { ok: false, reason: describeFailure(result) };
  }

  const envelope = parseEnvelope(result.stdout);
  if (envelope === undefined) {
    return { ok: false, reason: "the reviewer's output was not a JSON envelope" };
  }
  logRunStats(envelope);

  const parsed = parseFindings(sanitize(envelope.structured_output, invocation.apiKey));
  if (!parsed) {
    core.warning(`The reviewer returned no structured output — ${describeEnvelope(envelope)}.`);
    return { ok: false, reason: 'it did not return findings in the expected format' };
  }

  return { ok: true, ...parsed };
}

export const testables = { buildArgs };
