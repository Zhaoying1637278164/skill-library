import * as core from '@actions/core';
import { TokenProvider } from '@wix/evalforge-core';

// Fixed public OAuth token endpoint (same as the EvalForge V1 client).
const OAUTH_TOKEN_URL = 'https://www.wixapis.com/oauth2/token';

export type ComparisonResult = { comparisonGroupId: string };

export type ScenarioAssertion = {
  name: string;
  type: string;
  status: string;
  score?: number;
  verdict?: string;
  message?: string;
};

export type ScenarioRunResult = {
  runId?: string;
  name?: string;
  passed: number;
  failed: number;
  totalCostUsd: number;
  totalTokens: number;
  durationMs: number;
  assertions: ScenarioAssertion[];
};

export type ScenarioComparison = {
  scenarioId: string;
  scenarioName: string;
  required: boolean;
  reason: string;
  with: ScenarioRunResult;
  without: ScenarioRunResult;
  // Optional: the pipeline omits it when pairwise judging is disabled or the judge call fails.
  pairwiseJudgement?: {
    winner: 'tie' | 'with' | 'without';
    confidence: string;
    reasoning: string;
    dimensions?: Record<string, { winner: string; reasoning: string }>;
  };
};

export type ComparisonGroupResult = {
  comparisonGroupId: string;
  verdict: string;
  tag: string;
  scenarios: ScenarioComparison[];
  // How many scenarios actually obtained a pairwise judgement. A verdict built
  // from partial judging is a weaker claim than one built from all of it, and
  // `verdict` alone cannot express that. Absent when the pipeline ran no judge.
  judgeCoverage?: { judged: number; total: number };
};

export type CompareGroupComplete = {
  status: 'complete';
  completedRuns: number;
  totalRuns: number;
  result: ComparisonGroupResult;
};

export type CompareGroupStatus =
  | { status: 'running'; completedRuns: number; totalRuns: number }
  | CompareGroupComplete;

const POLL_INTERVAL_MS = 2 * 60_000;
const POLL_TIMEOUT_MS = 30 * 60 * 1_000;
const RETRY_LIMIT = 5;
const RETRY_DELAY_MS = 10_000;

const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;

/**
 * The completion poll does substantially more work server-side than the
 * intermediate "still running" polls, so it can legitimately take much longer
 * than a normal call.
 *
 * Deliberately longer than any deadline the server side applies to itself, so
 * that the client is the last participant to give up. Aborting locally first
 * loses the real error and, because an abort counts as retriable, re-issues a
 * request whose work had already succeeded.
 */
const COMPARE_GROUP_TIMEOUT_MS = 65_000;

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
}

function isRetriable(e: unknown): boolean {
  const status = (e as { status?: number }).status;
  if (status && status >= 500) return true;
  if (e instanceof Error && (e.name === 'AbortError' || e.name === 'TimeoutError')) return true;
  return false;
}

export class EvalPipelineClient {
  private readonly tokens: TokenProvider;

  constructor(
    private readonly baseUrl: string,
    appId: string,
    appSecret: string,
  ) {
    // The pipeline authorizes the caller by gateway identity, so it needs a Bearer
    // token from the app's OAuth credentials — the legacy x-app-id/x-app-secret
    // headers no longer resolve the app identity once the app is public.
    this.tokens = new TokenProvider(OAUTH_TOKEN_URL, appId, appSecret);
  }

  private async post<T>(path: string, body: unknown, timeoutMs = DEFAULT_REQUEST_TIMEOUT_MS): Promise<T> {
    // No 401 refresh-retry: /run-comparison is non-idempotent (it queues eval runs)
    // and getToken() re-mints proactively before expiry, so a 401 here is a
    // permission denial, not a stale token — retrying would only double-fire.
    const token = await this.tokens.getToken();
    const res = await fetch(`${this.baseUrl}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({})) as { error?: string };
      throw Object.assign(
        new Error(`EvalPipeline POST ${path} → ${res.status}: ${err.error ?? ''}`),
        { status: res.status },
      );
    }
    return res.json() as Promise<T>;
  }

  async runComparison(tags: string[], agentName: string, commitSha?: string, skillsRepo?: string, scenarioIds?: string[]): Promise<ComparisonResult> {
    return this.post<ComparisonResult>('/run-comparison', { tags, agentName, commitSha, skillsRepo, scenarioIds });
  }

  async compareGroup(comparisonGroupId: string): Promise<CompareGroupStatus> {
    return this.post<CompareGroupStatus>('/compare-group', { comparisonGroupId }, COMPARE_GROUP_TIMEOUT_MS);
  }
}

export async function pollUntilComparisonDone(
  client: EvalPipelineClient,
  comparisonGroupId: string,
): Promise<CompareGroupComplete> {
  const deadline = Date.now() + POLL_TIMEOUT_MS;

  while (Date.now() < deadline) {
    let result: CompareGroupStatus | undefined;

    for (let attempt = 0; attempt <= RETRY_LIMIT; attempt++) {
      try {
        result = await client.compareGroup(comparisonGroupId);
        break;
      } catch (e) {
        if (isRetriable(e) && attempt < RETRY_LIMIT) {
          core.warning(`compare-group poll failed (retry ${attempt + 1}/${RETRY_LIMIT}): ${e instanceof Error ? e.message : String(e)}`);
          await delay(RETRY_DELAY_MS);
        } else {
          throw e;
        }
      }
    }

    if (result!.status === 'complete') {
      core.info(`compare-group complete response: ${JSON.stringify(result)}`);
      return result as CompareGroupComplete;
    }

    const r = result as Extract<CompareGroupStatus, { status: 'running' }>;
    core.info(`Comparison ${comparisonGroupId}: ${r.completedRuns}/${r.totalRuns} runs complete...`);
    await delay(Math.min(POLL_INTERVAL_MS, deadline - Date.now()));
  }

  throw new ComparisonTimeoutError(`Comparison ${comparisonGroupId} timed out after 30 minutes`);
}

export class ComparisonTimeoutError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ComparisonTimeoutError';
  }
}
