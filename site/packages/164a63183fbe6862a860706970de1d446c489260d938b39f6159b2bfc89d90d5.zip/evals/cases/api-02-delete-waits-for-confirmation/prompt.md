Delete my latest creative.
