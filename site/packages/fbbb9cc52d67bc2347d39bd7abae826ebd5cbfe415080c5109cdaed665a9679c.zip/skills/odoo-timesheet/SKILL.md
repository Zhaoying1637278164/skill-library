---
name: odoo-timesheet
description: "Use this skill when the user mentions Odoo timesheets, asks about logging time, wants to configure the timesheet plugin, or asks why a session wasn't logged. Also use when interpreting the task-matching JSON response from the Stop hook.\n"
---

# Odoo Timesheet Plugin

This plugin automatically logs Claude Code sessions as Odoo timesheets.

## How it works

1. **Session starts** → `UserPromptSubmit` hook records the start time
2. **Session ends** → `Stop` hook calculates duration, fetches Odoo tasks, prints matching prompt
3. **Claude picks task** → responds with JSON `{"action": "match", "task_id": X}` or `{"action": "create", "task_name": "..."}`
4. **Timesheet logged** → `odoo_log.py` creates/finds the task and logs `account.analytic.line`

## Timesheet entry contains
- Duration in hours (converted from minutes)
- Summary of what was worked on
- Token count as a note
- Session ID timestamp

## Commands
- `/odoo-timesheet:setup` — configure Odoo connection
- `/odoo-timesheet:test` — verify connection and list tasks
- `/odoo-timesheet:log` — manually trigger logging for current session

## Config location

Config is **project-scoped** — stored in the project's `.claude/odoo-timesheet/config.json`.
Each project can have its own Odoo connection and project ID.

Resolution order:
1. `$CLAUDE_PROJECT_DIR/.claude/odoo-timesheet/config.json` (if env var set)
2. Auto-detect: walks up from cwd to find a directory containing `.git` or `.claude`, uses `<that dir>/.claude/odoo-timesheet/config.json`
3. Global fallback: `~/.claude/plugins/data/odoo-timesheet/config.json`

Runtime state (active session, pending log) always uses the global dir.

## Config options

| Key | Description | Default |
|-----|-------------|---------|
| `odoo_url` | Odoo server URL | required |
| `odoo_db` | Database name | required |
| `odoo_user` | Login email | required |
| `odoo_password` | Password or API key | required |
| `project_id` | Odoo project ID | required |
| `employee_id` | Employee ID (null = auto) | null |
| `ai_matching` | `claude_code` or `keyword` | `claude_code` |
| `auto_create_task` | Create task if no match | true |
| `min_duration_seconds` | Minimum session to log | 30 |
| `task_name_prefix` | Prefix added to auto-created task names (e.g. `[Claude] `) | `""` |
| `scripts_path` | Path to plugin scripts dir | auto-detected |

## Troubleshooting

**Sessions not being logged:**
- Check config is complete: `/odoo-timesheet:test`
- Check session was longer than `min_duration_seconds`
- Verify hooks are enabled in Claude Code settings

**Employee not found:**
- Odoo admin needs to link your user to an `hr.employee` record
- Or set `employee_id` manually in config

**Authentication errors:**
- For Odoo Online: use API key (Settings → Users → [your user] → API Keys)
- For self-hosted: username + password works directly
