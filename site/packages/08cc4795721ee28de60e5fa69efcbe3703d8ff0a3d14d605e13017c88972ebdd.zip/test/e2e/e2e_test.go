// SPDX-FileCopyrightText: Copyright 2026 Dash0 Inc.
// SPDX-License-Identifier: Apache-2.0

//go:build e2e

package e2e

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestE2EHookInvocation simulates what Claude Code does when firing a hook:
// builds the binary, invokes claude-on-event.sh with a SessionStart event on stdin,
// and verifies the mock OTLP server receives the connectivity check.
func TestE2EHookInvocation(t *testing.T) {
	pluginDir := findPluginDir(t)
	binary := buildClaudeBinary(t, pluginDir)

	var (
		mu       sync.Mutex
		requests []capturedRequest
	)

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		mu.Lock()
		requests = append(requests, capturedRequest{
			path:   r.URL.Path,
			auth:   r.Header.Get("Authorization"),
			body:   body,
			method: r.Method,
		})
		mu.Unlock()
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	dataDir := t.TempDir()

	t.Run("SessionStart fires connectivity check", func(t *testing.T) {
		event := `{"hook_event_name":"SessionStart","session_id":"e2e-test-session","model":"claude-opus-4-7"}`
		runBinary(t, binary, event, dataDir, srv.URL)

		time.Sleep(500 * time.Millisecond)

		mu.Lock()
		defer mu.Unlock()

		var traceReqs []capturedRequest
		for _, r := range requests {
			if r.path == "/v1/traces" {
				traceReqs = append(traceReqs, r)
			}
		}

		assert.NotEmpty(t, traceReqs, "connectivity check should hit /v1/traces on SessionStart")
		if len(traceReqs) > 0 {
			assert.Equal(t, "Bearer e2e-test-token", traceReqs[0].auth)
		}
	})

	t.Run("full turn produces chat and tool spans", func(t *testing.T) {
		mu.Lock()
		requests = nil
		mu.Unlock()

		// UserPromptSubmit — creates trace context.
		runBinary(t, binary, `{"hook_event_name":"UserPromptSubmit","session_id":"e2e-test-session","prompt":"hello"}`, dataDir, srv.URL)

		// PostToolUse — emits a tool span.
		runBinary(t, binary, `{"hook_event_name":"PostToolUse","session_id":"e2e-test-session","tool_name":"Bash","tool_use_id":"tu1","tool_input":"ls","tool_response":"file.txt","duration_ms":100}`, dataDir, srv.URL)

		// Stop — emits a chat span.
		runBinary(t, binary, `{"hook_event_name":"Stop","session_id":"e2e-test-session","model":"claude-opus-4-7","stop_reason":"end_turn"}`, dataDir, srv.URL)

		time.Sleep(500 * time.Millisecond)

		mu.Lock()
		defer mu.Unlock()

		var traceReqs []capturedRequest
		for _, r := range requests {
			if r.path == "/v1/traces" {
				traceReqs = append(traceReqs, r)
			}
		}

		// Expect at least 2 trace exports: tool span + chat span.
		assert.GreaterOrEqual(t, len(traceReqs), 2, "expected tool span + chat span")

		// Verify spans contain expected attributes.
		for _, r := range traceReqs {
			body := string(r.body)
			assert.Contains(t, body, "e2e-test-session", "span should contain conversation ID")
		}
	})

	t.Run("SessionEnd cleans up session directory", func(t *testing.T) {
		sessionDir := filepath.Join(dataDir, "e2e-test-session")
		require.DirExists(t, sessionDir, "session dir should exist before SessionEnd")

		runBinary(t, binary, `{"hook_event_name":"SessionEnd","session_id":"e2e-test-session"}`, dataDir, srv.URL)

		assert.NoDirExists(t, sessionDir, "session dir should be cleaned up after SessionEnd")
	})
}

func TestE2EFullFlowWithClaude(t *testing.T) {
	claudeBin, err := exec.LookPath("claude")
	if err != nil {
		t.Fatal("claude CLI not found in PATH — install with: npm install -g @anthropic-ai/claude-code")
	}
	// Either credential works: the CLI reads both from the environment cmd.Env
	// forwards below. CI supplies ANTHROPIC_API_KEY; CLAUDE_CODE_OAUTH_TOKEN is
	// the local path, so a developer with a Pro/Max subscription can run this
	// without holding an API key. When both are set the API key wins, matching the
	// CLI's own precedence.
	if os.Getenv("ANTHROPIC_API_KEY") == "" && os.Getenv("CLAUDE_CODE_OAUTH_TOKEN") == "" {
		t.Fatal("no Claude auth available — set ANTHROPIC_API_KEY (CI), or CLAUDE_CODE_OAUTH_TOKEN from `claude setup-token` (local)")
	}

	pluginDir := findPluginDir(t)
	binary := buildClaudeBinary(t, pluginDir)

	var (
		mu       sync.Mutex
		requests []capturedRequest
	)

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		mu.Lock()
		requests = append(requests, capturedRequest{
			path:   r.URL.Path,
			auth:   r.Header.Get("Authorization"),
			body:   body,
			method: r.Method,
		})
		mu.Unlock()
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	// Stage the plugin with the REAL claude/claude-on-event.sh (not a stub), then place
	// the freshly built binary where that script resolves it so it skips the
	// GitHub download and execs our binary. For a --plugin-dir load, Claude computes
	// CLAUDE_PLUGIN_DATA=<config-dir>/plugins/data/<plugin-name>-inline (it
	// ignores any preset value), so the binary must land under that path.
	stageDir := t.TempDir()
	copyDir(t, filepath.Join(pluginDir, ".claude-plugin"), filepath.Join(stageDir, ".claude-plugin"))
	copyDir(t, filepath.Join(pluginDir, "claude"), filepath.Join(stageDir, "claude"))

	// Give Claude its own config directory. A real "dash0-agent-plugin" install
	// already on this machine (via the marketplace) otherwise wins over the
	// --plugin-dir copy — Claude logs "blocked by managed settings" and silently
	// runs the installed plugin's hooks instead, so the test would pass or fail
	// for a reason that has nothing to do with the code under test. Isolation
	// also keeps the run out of the developer's real ~/.claude.
	configDir := t.TempDir()
	ver := claudePluginVersion(t, pluginDir)
	// claude/claude-on-event.sh derives this name from `uname`, normalizing
	// mingw/msys/cygwin to "windows" and appending ".exe" there. runtime.GOOS/
	// GOARCH already give the normalized form directly, matching the GoReleaser
	// asset names the script's download path expects.
	exe := ""
	if runtime.GOOS == "windows" {
		exe = ".exe"
	}
	binDir := filepath.Join(configDir, "plugins", "data", claudePluginName(t, pluginDir)+"-inline", "bin")
	require.NoError(t, os.MkdirAll(binDir, 0o755))
	staged := filepath.Join(binDir, fmt.Sprintf("on-event-%s-%s-%s%s", ver, runtime.GOOS, runtime.GOARCH, exe))
	copyExecutable(t, binary, staged)

	workDir := t.TempDir()

	// Deliver the mock OTLP config via the settings file the real script loads.
	// A project-level file (resolved against the hook's cwd) takes precedence over
	// any global ~/.claude/dash0-agent-plugin.local.md a dev may have, so the test
	// can never leak spans to a real endpoint.
	require.NoError(t, os.MkdirAll(filepath.Join(workDir, ".claude"), 0o755))
	settings := fmt.Sprintf("---\notlp_url: %q\nauth_token: \"e2e-test-token\"\n---\n", srv.URL)
	require.NoError(t, os.WriteFile(filepath.Join(workDir, ".claude", "dash0-agent-plugin.local.md"), []byte(settings), 0o644))

	args := []string{
		"--print",
		"--plugin-dir", stageDir,
		"--dangerously-skip-permissions",
		"-p", "respond with exactly: hello",
		"--model", "haiku",
	}
	// --max-budget-usd is an API-billing guard: under subscription (OAuth token)
	// auth the CLI rejects the run outright with "Exceeded USD budget", before
	// producing any output or firing a single hook. Only pass it on the
	// API-key path, where it actually guards spend.
	if os.Getenv("ANTHROPIC_API_KEY") != "" {
		args = append(args, "--max-budget-usd", "0.05")
	}
	cmd := exec.Command(claudeBin, args...)
	cmd.Dir = workDir
	cmd.Env = append(os.Environ(), "CLAUDE_CONFIG_DIR="+configDir)

	output, cmdErr := cmd.CombinedOutput()
	t.Logf("claude output (err=%v): %s", cmdErr, string(output))

	// Give hooks time to flush.
	time.Sleep(3 * time.Second)

	mu.Lock()
	defer mu.Unlock()

	t.Logf("requests received: %d", len(requests))
	for _, r := range requests {
		t.Logf("  %s %s auth=%q (%d bytes)", r.method, r.path, r.auth, len(r.body))
	}

	require.NotEmpty(t, requests, "expected at least one OTLP request from the Claude session with the plugin loaded")

	var traceReqs []capturedRequest
	for _, r := range requests {
		if r.path == "/v1/traces" {
			traceReqs = append(traceReqs, r)
		}
	}
	assert.NotEmpty(t, traceReqs, "expected at least one /v1/traces request (connectivity check on SessionStart)")
}

// buildClaudeBinary compiles cmd/claude-on-event into a temp dir and returns its path.
func buildClaudeBinary(t *testing.T, pluginDir string) string {
	t.Helper()
	name := "on-event"
	if runtime.GOOS == "windows" {
		// go build honors -o verbatim: without the extension, Windows refuses to
		// exec the file directly ("executable file not found in %PATH%"), even
		// with a full path.
		name += ".exe"
	}
	bin := filepath.Join(t.TempDir(), name)
	build := exec.Command("go", "build", "-o", bin, "./cmd/claude-on-event")
	build.Dir = pluginDir
	out, err := build.CombinedOutput()
	require.NoError(t, err, "build failed: %s", string(out))
	return bin
}

// claudePluginVersion reads the pinned VERSION from claude/claude-on-event.sh so the
// pre-staged binary path matches what the shipped script derives.
func claudePluginVersion(t *testing.T, pluginDir string) string {
	t.Helper()
	data, err := os.ReadFile(filepath.Join(pluginDir, "claude", "claude-on-event.sh"))
	require.NoError(t, err)
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "VERSION=") {
			return strings.Trim(strings.TrimPrefix(line, "VERSION="), `"`)
		}
	}
	t.Fatal("VERSION= not found in claude/claude-on-event.sh")
	return ""
}

// claudePluginName reads the plugin name from .claude-plugin/plugin.json. Claude
// derives the --plugin-dir data dir as "<name>-inline".
func claudePluginName(t *testing.T, pluginDir string) string {
	t.Helper()
	data, err := os.ReadFile(filepath.Join(pluginDir, ".claude-plugin", "plugin.json"))
	require.NoError(t, err)
	var manifest struct {
		Name string `json:"name"`
	}
	require.NoError(t, json.Unmarshal(data, &manifest))
	require.NotEmpty(t, manifest.Name, "plugin.json name is empty")
	return manifest.Name
}

// copyDir recursively copies src to dst.
func copyDir(t *testing.T, src, dst string) {
	t.Helper()
	require.NoError(t, filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(src, path)
		target := filepath.Join(dst, rel)
		if info.IsDir() {
			return os.MkdirAll(target, info.Mode())
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		return os.WriteFile(target, data, info.Mode())
	}))
}

type capturedRequest struct {
	path   string
	auth   string
	body   []byte
	method string
}

func runBinary(t *testing.T, binary, event, dataDir, otlpURL string) {
	t.Helper()
	cmd := exec.Command(binary)
	cmd.Stdin = stringReader(event)
	cmd.Env = []string{
		"CLAUDE_PLUGIN_DATA=" + dataDir,
		"CLAUDE_PLUGIN_OPTION_OTLP_URL=" + otlpURL,
		"CLAUDE_PLUGIN_OPTION_AUTH_TOKEN=e2e-test-token",
		"CLAUDE_PLUGIN_OPTION_OMIT_USER_INFO=false",
		"CLAUDE_PLUGIN_OPTION_OMIT_IO=false",
		// A temp home, not the developer's: config lookups fall back to
		// ~/.claude/dash0-agent-plugin.local.md, and its auth_token outranks the
		// prefixed option below, so a configured machine would send its own token
		// here. The binary only needs os.UserHomeDir to resolve to something.
		"HOME=" + t.TempDir(),
		"PATH=" + os.Getenv("PATH"),
	}
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Logf("binary output: %s (err: %v)", string(out), err)
	}
}

func stringReader(s string) *os.File {
	r, w, _ := os.Pipe()
	go func() {
		w.Write([]byte(s))
		w.Close()
	}()
	return r
}

func findPluginDir(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	require.NoError(t, err)
	for {
		if _, err := os.Stat(filepath.Join(dir, ".claude-plugin", "plugin.json")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("could not find plugin root (no .claude-plugin/plugin.json)")
		}
		dir = parent
	}
}
