# Corner Cases → Real-World Postmortems Index

A reference map: every corner case nova-thesis challenges → a real incident where skipping it cost millions.

> **Note — this is a frozen seed list (last updated 2026-04).** It is a *starting point*, not an authoritative database. When challenging an implementation, always run `WebSearch` / `WebFetch` first to find current postmortems matching the specific context — then use the rows below as fallback anchors for canonical failure patterns. Dated rows with specific companies are the most reliable starting references; rows without dates (e.g., "widespread", "universal pattern") are genre hints, not citations.

---

## 💸 Payments / Transactions

| Corner Case | Real Incident | Cost |
|---|---|---|
| No idempotency key on retries | Double-charge bugs (every major fintech) | Customer trust, chargebacks |
| Partial failure (charge succeeds, DB fails) | Knight Capital 2012 | $440M in 45 min |
| No rollback plan | Knight Capital 2012 | Business destroyed |
| Missing circuit breaker | Robinhood March 2020 | Platform down on highest-volume day |
| Unverified Stripe webhooks | Widespread fintech fraud | Revenue loss |

---

## 🤖 AI / ML Models

| Corner Case | Real Incident | Cost |
|---|---|---|
| Distribution shift / model drift | Zillow 2021 | $500M loss, business unit shut down |
| Biased test set masks real failure rate | Amazon Rekognition 2018 | Reputational damage, ACLU lawsuits |
| No input validation | Microsoft Tay 2016 | Offline in 16 hours |
| Feedback loop amplifying bias | Meta Ads Algorithm | Ongoing regulatory pressure globally |
| No fallback when model is down | Any undefended ML API | 500s surface to users |
| No drift detection | Zillow 2021 | Model degraded silently for months |

---

## ⏰ "Ship It" / Time Pressure

| Corner Case | Real Incident | Cost |
|---|---|---|
| Untested rollback | GitLab 2017 | 6 hours of production data permanently lost |
| Fat-finger + no dry-run | AWS S3 2017 | 4-hour global S3 outage |
| Unload-tested regex | Cloudflare 2019 | 27-min worldwide outage |
| "Patch it later" on known CVE | Equifax 2017 | 147M people's data, $700M settlement |
| No feature flag | Widespread | Can't disable without full redeploy |

---

## 🗄️ Database Migrations

| Corner Case | Real Incident | Cost |
|---|---|---|
| Schema migration locks large table | GitHub 2012 (MySQL migration) | Hours of degraded writes |
| I/O saturation from table rebuild | GitHub 2012 | Cascading write degradation under prod load |
| Lock escalation under production concurrency | Stack Overflow 2016 | Full site outage from connection pool exhaustion |
| Deploy/migration ordering mismatch | PagerDuty 2014 | NullPointerExceptions on live data, alerting down |
| NOT NULL column + no default + old code writing | Braintree / PayPal pattern | Immediate payment insert failures |
| No dry run on production-sized data | Universal migration pattern | 4-second staging migration = 6-hour prod migration |
| Missing index on new column | Any large-table migration | Full table scans on every query touching the new column |
| No rollback script | Any failed migration | Stuck mid-migration with no path back to clean state |
| Accidental DROP in wrong environment | GitLab 2017 | Production data loss |
| No backup verification | GitLab 2017 | 4 of 5 backup methods were broken |

---

## 🏗️ Infrastructure Changes (Terraform / Cloud)

| Corner Case | Real Incident | Cost |
|---|---|---|
| Wrong capacity parameter under pressure | AWS S3 2017 | 4-hour global S3 outage |
| No `terraform plan` review before apply | Widespread RDS pattern | Accidental production database destroy/recreate |
| State drift causes destructive reconciliation | Cloudflare 2023 (Cloudforce One) | Deleted in-use resources, manual reconstruction required |
| RDS resize triggers reboot / forces new resource | Terraform community (universal) | Production DB offline, 20–45 min recovery window |
| Large blast radius of "one-line" change | Atlassian April 2022 | 400 customers offline up to 14 days, data unrecoverable |
| No backup before destructive infra operation | Atlassian 2022 | Permanent data loss for subset of customers |
| No confirmation gate / dry-run | AWS S3 2017 | One typo = global outage |
| Terraform state file not version-controlled | General best practice gap | State corruption = unknown infra state, manual recovery |

---

## 🌐 Microservices / APIs

| Corner Case | Real Incident | Cost |
|---|---|---|
| Cascading failure, no circuit breaker | Netflix Christmas Eve 2012 | Hours of streaming down |
| No circuit breaker — holiday traffic spike | Netflix 2012 | Directly caused creation of open-source Hystrix |
| Synchronous REST chain — latency multiplies | Uber "Death Star" 2015–2018 | Years of retrofitting, circular dependency graph |
| No distributed tracing | Uber / Universal microservice pattern | MTTR goes from minutes to hours during incidents |
| No saga / compensation for distributed txns | Any payment microservice split | Charge succeeds, order never created — no automatic rollback |
| Data consistency across service DBs | Any split with shared entities | Stale data served — wrong emails, wrong prices, wrong state |
| All services dependent on shared infra | Facebook October 2021 | Engineers locked out of building, 6-hour global outage |
| BGP / config change without staged rollout | Facebook 2021 | All services unreachable globally ($60B market cap hit) |
| No fallback for internal tooling | Facebook 2021 | Recovery tools also unreachable — can't fix the outage |
| No timeout on downstream calls | Any undefended microservice | Thread exhaustion, service death |
| Premature decomposition before tooling maturity | Amazon internal / MonolithFirst pattern | Distributed systems complexity without distributed systems ops |
| No API versioning between services | Universal microservice anti-pattern | Breaking change in one service silently breaks all dependents |

---

## 🖥️ Frontend / Web Performance

| Corner Case | Real Incident | Cost |
|---|---|---|
| No bundle size gate — incremental bloat | Facebook Messenger 2019 | Multi-year rebuild (Project LightSpeed) |
| Lab metrics mask real-world performance | Walmart 2012 correlation study | 2% conversion loss per second of load time |
| Third-party script bloat invisible in audits | Twitter/X 2023 pattern | Degraded UX, invisible in Lighthouse |
| No performance budget enforcement | Universal frontend pattern | Gradual regression to unusable on low-end devices |

---

## 📡 API Versioning / Contracts

| Corner Case | Real Incident | Cost |
|---|---|---|
| Forced sunset breaks ecosystem trust | Twitter API v1.0 2012–2013 | 18+ months of extensions, developer exodus |
| No version translation layer | Stripe versioning (ongoing, positive) | Stripe maintains 100+ versions — gold standard |
| Breaking changes in "non-breaking" updates | Facebook Graph API 2018 | Thousands of broken apps, repeated across versions |
| No per-client migration tracking | Universal API pattern | "Migrate over time" = never migrate |

---

## 🏢 Multi-Tenancy / Data Isolation

| Corner Case | Real Incident | Cost |
|---|---|---|
| Permission scope failure leaks cross-tenant data | Salesforce 2019 | Services taken offline, unknown breach extent |
| Tenant isolation bypassed via alternative path | Zendesk 2019 | Cross-customer ticket access |
| Permission propagation race during migration | Notion 2021 | Private pages temporarily visible across workspaces |
| Missing WHERE clause on tenant_id | Universal SaaS pattern | Silent data leak — often discovered by customers |

---

## 💰 Cloud Cost / Billing

| Corner Case | Real Incident | Cost |
|---|---|---|
| Lambda costs exceed EC2 at sustained volume | Segment 2018 | Migrated BACK to containers |
| Recursive Lambda invocation — infinite loop | Multiple companies 2020–2024 | $10K–$50K surprise bills |
| CloudWatch logging costs exceed compute | Adobe / Netflix pattern | Log ingestion > Lambda cost |
| NAT gateway hidden data transfer charges | Universal Lambda-in-VPC pattern | $0.045/GB adds up silently |

---

## 🔄 CI/CD / Deployment Pipelines

| Corner Case | Real Incident | Cost |
|---|---|---|
| Build pipeline compromised — supply chain attack | SolarWinds 2020 | 18,000 customers compromised, US government breach |
| CI dependency exfiltrates secrets | Codecov 2021 | Twitch, HashiCorp, hundreds of companies affected |
| Script injection via PR metadata | GitHub Actions 2022 pattern | Untrusted code executes with deploy credentials |
| No rollback automation | Universal deploy pattern | 10+ minutes through CI to revert — too slow during incident |

---

## 📨 Event-Driven Architecture

| Corner Case | Real Incident | Cost |
|---|---|---|
| No schema registry — producer breaks consumers | Uber Kafka 2019–2020 | Frequent consumer failures, custom tooling required |
| Event cascade with no staged rollout | CrowdStrike 2024 | 8.5M machines affected simultaneously |
| Consumer rebalancing storm halts processing | LinkedIn Kafka 2019 | Minutes of zero message processing |
| Out-of-order cross-partition delivery | Universal Kafka pattern | Orphan records, inconsistent state |

---

## 🔐 Security

| Corner Case | Real Incident | Cost |
|---|---|---|
| Known CVE not patched ("later") | Equifax 2017 | $700M settlement, regulatory action |
| No rate limiting on sensitive endpoint | Countless API breaches | Data enumeration, credential stuffing |
| Logging sensitive fields | Twitter 2018 (plaintext passwords in logs) | Forced global password reset |
| Missing SSRF protection | Capital One 2019 | 100M records, $80M fine |
| IDOR (missing auth check) | Uber 2016 | 57M records, $148M settlement |

---

## Pattern: The Three Lies of "It's Fine"

Every major incident has at least one of these at its root:

1. **"It works in testing"** — test environments never match production scale, distribution, or adversarial inputs
2. **"We'll fix it later"** — later becomes never, or becomes too late
3. **"Someone else reviewed it"** — diffusion of responsibility, no one actually owned the hard questions

nova-thesis exists to ask the hard questions **before** any of these become the lead sentence of a postmortem.
