const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const {
  failSoft,
  readHookInput,
  sessionIdOf,
  scratchPath,
  scratchDir,
  legacyPath,
  readScratchFile,
  readAllScratchFiles,
} = require('./hook-io');

failSoft();

// PostToolUse hook that, once planning is done, prompts the agent to ASK the
// user whether to upload the plan to baz. Uploading is deliberately not
// automatic: `mcp__baz__update_plan` publishes the plan to Baz, where the org
// can read and comment on it, so the user gets to decide. This hook never
// authorizes the call — it supplies the authoritative arguments and instructs
// the agent to obtain consent first. Three trigger paths converge here:
//
//   1. CC's ExitPlanMode — agent used plan mode and the user approved.
//   2. CC's Write to the plan-mode plan file at ~/.claude/plans/<name>.md —
//      agent has drafted the plan but the user hasn't approved yet. We fire
//      here so the offer to upload is made as soon as the plan exists, without
//      waiting on approval — but the upload itself still waits on the user's
//      yes. If the user later approves and ExitPlanMode fires, the agent is
//      told to honor the answer it already has rather than re-ask, and any
//      duplicate update_plan call is deduped server-side by content hash
//      (identical content → same version).
//   3. File-write tools (Write/Edit/apply_patch/edit_file/write_file) — agent
//      planned inline and wrote its final plan to .baz-plan-<sessionId>.md in
//      the plugin's scratch directory (see hook-io.js)
//      per SKILL.md / .cursor/rules / AGENTS.md. The primary path — every
//      platform, including Claude Code.
//
// For path 2 we inspect the tool's *destination path* fields (not the full
// tool_input JSON) so a Write/Edit whose *content* happens to mention the
// plan filename doesn't spuriously trigger completion. Each platform uses a
// different field: CC Write/Edit uses `file_path`, Cursor edit_file/write_file
// uses `path` or `target_file`, Codex apply_patch encodes the path in a
// `command` envelope (e.g. "*** Add File: <path>"). We match by basename
// because the host may resolve or rewrite the directory before the path
// reaches the hook (macOS turns /tmp into /private/tmp, for one).
//
// argv[2] is the vendor name ('claude-code' | 'codex' | 'cursor'); the
// per-platform hook manifest passes it so we can dispatch token extraction.

const SAFE_VENDOR = /^[A-Za-z0-9._-]{1,64}$/;
const SAFE_REPO = /^[A-Za-z0-9._-]+\/[A-Za-z0-9._-]+$/;
// A `repository` argument is the short leaf name (`baz`) or the full `owner/repo`.
const SAFE_REPO_ARG = /^[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+)?$/;

const vendorArg = process.argv[2] || '';
const vendor = SAFE_VENDOR.test(vendorArg) ? vendorArg : '';

// --- Pure helpers -----------------------------------------------------------

function tryParseJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

function safeReadFile(filePath) {
  try { return fs.readFileSync(filePath, 'utf8'); } catch { return null; }
}

function safeUnlink(filePath) {
  try { fs.unlinkSync(filePath); } catch {}
}

// Keep in sync with plan-attach.js.
function pendingPayloadPath(sid) {
  return scratchPath('plan-pending', sid, 'json');
}

// False if it cannot be parked, so the caller falls back to inlining the plan.
// That includes having no private scratch directory at all: we never park a
// plan in a directory other accounts can read.
function writePendingPayload(sid, payload) {
  const target = pendingPayloadPath(sid);
  if (!target) return false;
  try {
    fs.writeFileSync(target, JSON.stringify(payload), { mode: 0o600 });
    return true;
  } catch { return false; }
}

function readJsonlObjects(filePath) {
  const raw = safeReadFile(filePath);
  if (raw === null) return [];
  return raw.split('\n')
    .filter(Boolean)
    .map(tryParseJson)
    .filter(obj => obj !== null);
}

function basenameOf(p) {
  if (typeof p !== 'string') return '';
  const idx = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\'));
  return idx >= 0 ? p.slice(idx + 1) : p;
}

function coerceToolInput(raw) {
  if (raw && typeof raw === 'object') return raw;
  if (typeof raw === 'string') return tryParseJson(raw);
  return null;
}

function normalizePlan(text) {
  return typeof text === 'string' && text.length > 0 ? text : null;
}

// --- Trigger detection ------------------------------------------------------

// Returns the matched destination path, or null. The path matters as well as
// the match: it is the file the agent actually wrote, so extractPlan() reads it
// rather than guessing which carrier holds the plan.
function toolWritesPlanFile(hookInput, planFilename) {
  const input = coerceToolInput(hookInput.tool_input);
  if (!input) return null;

  const directPaths = ['file_path', 'path', 'target_file', 'notebook_path']
    .map(k => input[k])
    .filter(p => typeof p === 'string');
  for (const p of directPaths) {
    if (basenameOf(p) === planFilename) return p;
  }

  // Codex apply_patch: destination lives in a `command` envelope like
  // "*** Add File: <path>" / "*** Update File: <path>" / "*** Move to: <path>".
  if (typeof input.command === 'string') {
    const re = /\*\*\* (?:(?:Add|Update|Delete) File|Move to):\s*([^\n]+)/g;
    for (const m of input.command.matchAll(re)) {
      const dest = m[1].trim();
      if (basenameOf(dest) === planFilename) return dest;
    }
  }

  return null;
}

// The basename match alone is deliberately loose (hosts rewrite the directory:
// macOS turns /tmp into /private/tmp), but it must not let a write to some
// unrelated directory pull in whatever this session has staged. A matched
// destination is only trusted when it resolves into a directory we own — the
// scratch directory or the pre-upgrade /tmp — after symlinks are resolved.
function isOurPlanCarrier(destPath) {
  if (typeof destPath !== 'string' || !destPath) return false;
  const roots = [scratchDir(), '/tmp'].filter(Boolean);
  let destDir;
  try {
    destDir = fs.realpathSync(path.dirname(path.resolve(destPath)));
  } catch {
    return false;
  }
  for (const root of roots) {
    let resolved;
    try { resolved = fs.realpathSync(root); } catch { continue; }
    if (destDir === resolved) return true;
  }
  return false;
}

// Claude Code plan mode writes its plan to ~/.claude/plans/<random-name>.md.
// The filename is assigned by the harness, so we can't match by basename;
// instead we match by containing directory. When this trigger fires we can
// read the plan content directly from the file the tool just wrote.
function claudeCodePlanFilePath(hookInput) {
  const input = coerceToolInput(hookInput.tool_input);
  if (!input || typeof input.file_path !== 'string') return null;
  const home = process.env.HOME || '';
  if (!home) return null;
  const plansDir = path.join(home, '.claude', 'plans') + path.sep;
  const fp = input.file_path;
  if (!fp.startsWith(plansDir)) return null;
  if (!fp.endsWith('.md')) return null;
  return fp;
}

// --- Usage extractors -------------------------------------------------------
// Each returns { tokens, modelId } or null. Either field may be null on its
// own if only one signal is available.

// Claude Code: transcript JSONL, per-message usage on assistant lines.
// Deduplicate by message.id (CC streams — same id appears multiple times as
// the message is generated; keep the entry with the highest output_tokens).
// Input tokens include cache reads/creation. modelId is the last non-empty
// `message.model` seen (the model at the moment planning completed).
function extractClaudeCodeUsage(transcriptPath) {
  if (!transcriptPath) return null;
  const byMessage = new Map();
  let modelId = null;
  for (const obj of readJsonlObjects(transcriptPath)) {
    if (obj.type !== 'assistant') continue;
    const msg = obj.message;
    if (!msg) continue;
    if (typeof msg.model === 'string' && msg.model) modelId = msg.model;
    if (!msg.id || !msg.usage) continue;
    const out = Number(msg.usage.output_tokens) || 0;
    const existing = byMessage.get(msg.id);
    if (existing && existing.output_tokens >= out) continue;
    const inTok =
      (Number(msg.usage.input_tokens) || 0) +
      (Number(msg.usage.cache_creation_input_tokens) || 0) +
      (Number(msg.usage.cache_read_input_tokens) || 0);
    byMessage.set(msg.id, { input_tokens: inTok, output_tokens: out });
  }
  if (byMessage.size === 0 && !modelId) return null;
  let input_tokens = 0, output_tokens = 0;
  for (const u of byMessage.values()) {
    input_tokens += u.input_tokens;
    output_tokens += u.output_tokens;
  }
  const tokens = byMessage.size > 0 ? { input_tokens, output_tokens } : null;
  return { tokens, modelId };
}

// Codex: rollout JSONL. `event_msg` lines with `type === 'token_count'` carry
// cumulative `total_token_usage`; last one wins. Model id can appear on
// `evt.model` (any event) or on `evt.info.model` (token_count events).
function extractCodexUsage(transcriptPath) {
  if (!transcriptPath) return null;
  let last = null;
  let modelId = null;
  for (const obj of readJsonlObjects(transcriptPath)) {
    if (obj.type !== 'event_msg') continue;
    const evt = obj.payload;
    if (!evt) continue;
    if (typeof evt.model === 'string' && evt.model) modelId = evt.model;
    if (evt.type !== 'token_count') continue;
    const info = evt.info;
    const usage = info && info.total_token_usage;
    if (usage) last = usage;
    if (info && typeof info.model === 'string' && info.model) modelId = info.model;
  }
  const tokens = last ? {
    input_tokens:
      (Number(last.input_tokens) || 0) +
      (Number(last.cached_input_tokens) || 0),
    output_tokens:
      (Number(last.output_tokens) || 0) +
      (Number(last.reasoning_output_tokens) || 0),
  } : null;
  if (!tokens && !modelId) return null;
  return { tokens, modelId };
}

// Cursor: per-turn tally accumulated by stop-token-tally.js. Both
// tokens and model id come from Cursor's stop hook payload (model_id preferred
// over the display-name `model`); the tally file is last-write-wins for model
// id across turns.
function extractCursorUsage(sid) {
  // A session that was mid-flight when the plugin was upgraded has turns tallied
  // in both places: the old /tmp file from the previous stop-token-tally.js and
  // the private one from this version. Both are summed, so the plan's token
  // count covers the whole session. Read, never consume: the tally is cumulative
  // and this hook re-runs on every plan revision. session-end.js cleans up.
  const found = readAllScratchFiles('tokens', sid, 'json');
  if (found.length === 0) return null;
  let input_tokens = 0, output_tokens = 0, modelId = null, sawTokens = false;
  for (const { content } of found) {
    const parsed = tryParseJson(content);
    if (
      !parsed ||
      typeof parsed !== 'object' ||
      Array.isArray(parsed) ||
      // Number.isFinite, not typeof: JSON.parse('1e400') yields Infinity, whose
      // typeof is 'number' and which JSON.stringify writes back as null — the
      // plan would carry `tokensUsed: {"input_tokens": null}`.
      !Number.isFinite(parsed.input_tokens) ||
      !Number.isFinite(parsed.output_tokens)
    ) continue;
    input_tokens += parsed.input_tokens;
    output_tokens += parsed.output_tokens;
    sawTokens = true;
    // Private file first in the list, so the first model id seen is the most
    // recent writer's.
    if (!modelId && typeof parsed.model_id === 'string' && parsed.model_id) {
      modelId = parsed.model_id;
    }
  }
  if (!sawTokens) return null;
  return { tokens: { input_tokens, output_tokens }, modelId };
}

// --- Plan extraction --------------------------------------------------------
// Read the plan text authoritatively from the source (tool_input for
// ExitPlanMode, plan file on disk otherwise), not from the model's memory.
// This removes the "did the model relay it verbatim?" risk and keeps the
// value deterministic.

function extractPlan(hookInput, sid) {
  if ((hookInput.tool_name || '') === 'ExitPlanMode') {
    // CC emits ExitPlanMode's plan on `tool_response.plan`, not
    // `tool_input.plan`. Fall back to `tool_input.plan` in case a fork or
    // future version puts it there instead.
    const response = coerceToolInput(hookInput.tool_response);
    const input = coerceToolInput(hookInput.tool_input);
    const plan =
      (response && typeof response.plan === 'string' && response.plan) ||
      (input && typeof input.plan === 'string' && input.plan) ||
      null;
    return normalizePlan(plan);
  }
  // Claude Code plan mode: read from the file we just detected. We must NOT
  // unlink it — the harness owns that file and shows it to the user for
  // approval.
  const ccPlanPath = claudeCodePlanFilePath(hookInput);
  if (ccPlanPath) {
    const content = safeReadFile(ccPlanPath);
    return normalizePlan(content);
  }
  // Prefer the file the tool actually wrote, when the trigger identified one we
  // own — that is the plan by definition, and it removes any question of which
  // carrier is current. Otherwise the private path, then the pre-upgrade /tmp
  // one, since a session already running when the plugin was upgraded still has
  // its plan there. Only the file actually consumed is unlinked.
  const matched = toolWritesPlanFile(hookInput, `.baz-plan-${sid}.md`);
  if (matched && isOurPlanCarrier(matched)) {
    const content = safeReadFile(matched);
    if (content !== null && content.length > 0) {
      safeUnlink(matched);
      return normalizePlan(content);
    }
  }
  const found = readScratchFile('plan', sid, 'md');
  if (!found) return null;
  safeUnlink(found.path);
  return normalizePlan(found.content);
}

// --- Repos related to the plan ----------------------------------------------
// post-tool-use.js accumulates the `repository` / `sessionRepository` argument
// from every baz MCP tool call into .baz-repos-<sessionId>.json. We also
// derive the session's own repo from cwd so the plan is always attributed to
// where the user is actually working.

function repoFromCwd(cwd) {
  if (!cwd) return null;
  let remote;
  try {
    remote = execSync('git config --get remote.origin.url', {
      cwd,
      stdio: ['ignore', 'pipe', 'ignore'],
      encoding: 'utf8',
    }).trim();
  } catch {
    return null;
  }
  const m = remote.match(/[:/]([^/:]+\/[^/:]+?)(?:\.git)?\/?$/);
  return m && SAFE_REPO.test(m[1]) ? m[1] : null;
}

function collectRepos(sid, cwd) {
  const seen = new Set();
  const cwdRepo = repoFromCwd(cwd);
  if (cwdRepo) seen.add(cwdRepo);

  // Read, never consume: this hook re-runs on every plan revision and the last
  // fire's repo list is the one that ships. session-end.js cleans up. Both
  // namespaces are merged, for a session upgraded mid-flight.
  //
  // Validate every name, not just the cwd one: these are agent-supplied and end
  // up interpolated into instruction text.
  for (const { content } of readAllScratchFiles('repos', sid, 'json')) {
    for (const line of content.split('\n')) {
      const name = line.trim();
      if (name && SAFE_REPO_ARG.test(name)) seen.add(name);
    }
  }
  return [...seen];
}

function cwdFromHookInput(hookInput) {
  if (hookInput.cwd) return hookInput.cwd;
  if (Array.isArray(hookInput.workspace_roots) && hookInput.workspace_roots.length > 0) {
    return hookInput.workspace_roots[0];
  }
  return '';
}

// --- Main flow --------------------------------------------------------------

const d = readHookInput();
if (!d) process.exit(0);

const sessionId = sessionIdOf(d);
if (!sessionId) process.exit(0);

if ((d.tool_name || '') !== 'ExitPlanMode') {
  const hasCcPlanFile = claudeCodePlanFilePath(d) !== null;
  const hasScratchPlanFile = toolWritesPlanFile(d, `.baz-plan-${sessionId}.md`) !== null;
  if (!hasCcPlanFile && !hasScratchPlanFile) process.exit(0);
}

// update_plan requires content — if we couldn't extract the plan, there's
// nothing to persist and no viable tool call to nudge. Exit quietly rather
// than firing a broken instruction; the planner session stays open in baz
// until a later hook supplies a plan.
const planContent = extractPlan(d, sessionId);
if (planContent === null) process.exit(0);

const usage =
  vendor === 'claude-code' ? extractClaudeCodeUsage(d.transcript_path) :
  vendor === 'codex'       ? extractCodexUsage(d.transcript_path) :
  vendor === 'cursor'      ? extractCursorUsage(sessionId) :
  null;
const tokens = usage && usage.tokens;
const modelId = usage && usage.modelId;

const repoNames = collectRepos(sessionId, cwdFromHookInput(d));

// Claude Code: plan-attach.js (PreToolUse) fills the plan in, so it never
// re-enters the conversation. Codex/Cursor have no updatedInput and keep
// receiving it inline below.
const attachesLocally =
  vendor === 'claude-code' && writePendingPayload(sessionId, {
    content: planContent,
    tokensUsed: tokens,
    modelId,
    repoNames,
    agentVendor: vendor,
  });

// Only the call shape differs between the two paths; the consent contract
// around it is the same either way.
const callShape = attachesLocally
  ? [
      `If — and only if — they say yes, call \`mcp__baz__update_plan\` exactly` +
        ` once with NO arguments at all. The session id, plan text, token` +
        ` counts, model id and repo names are attached automatically before the` +
        ` call is sent. Re-typing the plan wastes tokens and risks drift.`,
      `Revisions go in the plan file: edit it there and this hook re-runs, so` +
        ` the version that reaches Baz is always the file's current text.`,
    ]
  : [
      `If — and only if — they say yes, call \`mcp__baz__update_plan\` exactly once` +
        ` with \`sessionId: "${sessionId}"\` and` +
        ` \`content: ${JSON.stringify(planContent)}\` — this is the authoritative` +
        ` plan text (read from the tool input or the plan file on disk); pass the` +
        ` string exactly as given.`,
      tokens &&
        `Also pass \`tokensUsed: ${JSON.stringify(tokens)}\` — this is the` +
        ` authoritative token count for this session, computed from the host` +
        ` transcript. Pass the object exactly as given.`,
      modelId &&
        `Also pass \`modelId: ${JSON.stringify(modelId)}\` — this is the model id` +
        ` read from the host transcript for this session. Pass the string exactly` +
        ` as given.`,
      repoNames.length > 0 &&
        `Also pass \`repoNames: ${JSON.stringify(repoNames)}\` — this is the set of` +
        ` repositories relevant to this plan (the session's root repo plus every` +
        ` repo you named in a baz MCP tool call; repos that an org-wide` +
        ` \`repo_search\` merely returned are not included). Pass the array exactly` +
        ` as given so the plan is discoverable under each of these repos.`,
    ];

// Each host invokes this command differently; see the table in README.md.
const commentsCommand =
  vendor === 'claude-code' ? '`/baz:get-plan-comments`' :
  vendor === 'cursor'      ? '`/get-plan-comments`' :
  vendor === 'codex'       ? 'the `get-plan-comments` skill' :
  'the `get-plan-comments` command';

const supersedes = attachesLocally
  ? `the attached content supersedes any earlier draft`
  : `using the \`content\` in THIS instruction: it supersedes any earlier draft,` +
    ` so the version the user ultimately approved is what lands in Baz`;

const instruction = [
  `ASK THE USER — DO NOT UPLOAD YET: You just finished planning. Baz can` +
    ` persist this plan and close the planner session, which publishes it to` +
    ` Baz, where your teammates can open and comment on it the way they would a` +
    ` pull request. This is` +
    ` NOT automatic and this instruction is NOT the user's permission.` +
    ` In your next message, ask the user plainly whether to upload the plan to` +
    ` Baz, and wait for their answer.`,
  ...callShape,
  `If they say no, do not call the tool and do not raise it again this session;` +
    ` the plan is simply never published and the planner session stays open, which is the` +
    ` accepted cost of not uploading.`,
  `If you already asked during this session, do NOT ask again — reuse the answer` +
    ` you were given. If that answer was yes, call the tool again now, ${supersedes}.` +
    ` Identical content is deduped server-side, so a redundant call costs nothing.`,
  `The tool result contains a shareable plan link — include that link in your` +
    ` reply so the user can open the uploaded plan, and tell them they can use` +
    ` ${commentsCommand} any time to pull the plan's comments back into this` +
    ` session.`,
].filter(Boolean).join(' ');

process.stdout.write(JSON.stringify({
  hookSpecificOutput: {
    hookEventName: 'PostToolUse',
    additionalContext: instruction,
  },
}));
