---
name: sl
description: "Switch Claude Code status line theme or detail level. Usage: /sl [theme] [detail]"
argument-hint: "[powerline|minimal|compact|full] [low|medium|high]"
allowed-tools:
- Read
- Bash
- Edit
- Write
---

# Status Line Switcher

You are managing the Claude Code status line configuration.

## Config file
The config lives at `~/.claude/statusline-config.json` with format:
```json
{ "theme": "powerline", "detail": "high" }
```

## Available themes
- **powerline** — bold segments with `│` separators: `❯ project │ main* │ ctx:70% │ Opus 4.6 │ $7.85`
- **minimal** — clean and simple: `project main* $7.85`
- **compact** — project-focused: `project (main*) · 70% ctx · $7.85`
- **full** — everything: `user:~/path main* ctx:70% opus-4.6 $7.85 5h:47% +1410/-68 42m`

## Detail levels
- **low** — project name + branch only
- **medium** — + context %, model, session cost
- **high** — + rate limits (5h/7d), LOC delta (+/-), duration, todos

## KPIs available
| Metric | Detail | Description |
|--------|--------|-------------|
| Project name | all | Git repo name or directory |
| Git branch | all | Current branch + dirty indicator |
| Context used % | medium+ | How much context window is consumed |
| Model name | medium+ | Active model (Opus 4.6, Sonnet, etc.) |
| Session cost | medium+ | Total USD spent this session |
| Rate limits | high | 5-hour and 7-day API quota usage |
| LOC delta | high | Lines added/removed this session |
| Duration | high | Session wall-clock time |
| Todos | high | Active todo count from transcript |

## What to do

1. Read the current config from `~/.claude/statusline-config.json`
2. Parse the user's arguments:
   - If they passed a theme name → update `theme`
   - If they passed a detail level (`low`/`medium`/`high`) → update `detail`
   - If they passed both → update both
   - If no arguments → show current config and a preview table of all themes × detail levels
3. Write the updated config back to the file
4. Tell the user the change is live (status line refreshes automatically)

## Preview table (when no args)

Show a formatted table like:
```
Current: powerline @ medium

Theme       low                 medium                                       high
powerline   ❯ project │ main    ❯ project │ main │ ctx:% │ model │ $cost    + rate limits + LOC + duration
minimal     project             project main $cost                           + ctx:% + 5h:%
compact     project             project (main) · % ctx · $cost              + rate limits + LOC
full        user:project main   user:~/path main ctx:% model $cost          + rate limits + LOC + duration + todos
```

## Important
- The status line updates live — no restart needed after changing the config
- If the config file doesn't exist, create it with defaults: `{ "theme": "powerline", "detail": "high" }`
- Users can also create custom themes by placing `.js` files in `~/.claude/statusline-themes/`
- Rate limit colors: gray (<60%), orange (60-79%), red (80%+) — visual warning when burning through quota
