---
name: setup
description: "Install or configure the statusline plugin in your settings.json"
allowed-tools:
- Read
- Bash
- Edit
- Write
- Grep
- Glob
---

# Status Line Setup

You are setting up the statusline plugin's status line in the user's Claude Code settings.

## What to do

1. **Find the plugin's installed location** by running:
   ```bash
   find ~/.claude/plugins/cache -path "*/statusline/*/lib/statusline.js" 2>/dev/null | head -1
   ```
   If not found, try the broader search:
   ```bash
   find ~/.claude/plugins -name "statusline.js" -path "*/lib/*" 2>/dev/null | head -1
   ```

2. **Read the user's `~/.claude/settings.json`**

3. **Check if `statusLine` is already configured**:
   - If yes, ask if they want to replace it
   - If no, add it

4. **Add the statusLine config**:
   ```json
   {
     "statusLine": {
       "type": "command",
       "command": "node \"<RESOLVED_PATH>/lib/statusline.js\"",
       "description": "statusline: themeable status line (config: ~/.claude/statusline-config.json)"
     }
   }
   ```
   Where `<RESOLVED_PATH>` is the absolute path you found in step 1.

5. **Ensure `~/.claude/statusline-config.json` exists** with defaults:
   ```json
   { "theme": "powerline", "detail": "high" }
   ```

6. **Confirm to the user** that setup is complete and tell them:
   - The status line will appear on their next session (or immediately if already running)
   - Use `/statusline:sl` to switch themes and detail levels
   - Available themes: powerline, minimal, compact, full
   - Detail levels: low, medium, high
   - Custom themes can be added to `~/.claude/statusline-themes/`

## Uninstall

If the user says "uninstall" or "remove":
1. Remove the `statusLine` key from `~/.claude/settings.json`
2. Optionally remove `~/.claude/statusline-config.json`
3. Tell them the status line is removed
