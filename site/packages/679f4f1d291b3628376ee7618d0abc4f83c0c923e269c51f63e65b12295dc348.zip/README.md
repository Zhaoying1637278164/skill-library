# statusline

**Stop guessing which project you're in.** When you're running 5+ Claude Code sessions across different repos, every tab looks the same. You waste time clicking through tabs trying to find the right one, or worse — you start coding in the wrong project.

`statusline` puts a persistent, color-coded status bar at the bottom of every Claude Code session showing exactly where you are and what's happening.

![demo](demo/demo.gif)

## The problem

Claude Code's default UI doesn't show which project or repo you're working in. When you're deep in a session, you can't tell at a glance:

- Which repo am I in?
- Is this branch dirty?
- How much context window is left?
- Am I about to hit my rate limit?
- How many lines has Claude changed this session?

This plugin solves all of that with a single glance.

## Install

```bash
# Add the marketplace (one-time)
claude plugins marketplace add dan1d/claude-marketplace

# Install the plugin
claude plugins install statusline@dan1d
```

Then run `/statusline:setup` inside Claude Code to activate the status line.

## What you get

```
❯ my-project │ main ✗ │ ctx:47% │ Opus 4.6 │ session +1410/-68 │ uncommitted +23/-5 │ time 42m │ 5h quota 49% resets ~2h38m │ 7d quota 64%
```

At a glance: project name, branch with dirty indicator, context usage, model, lines changed, uncommitted diff, session duration, and quota usage with reset countdowns.

## Themes

Four built-in themes — switch anytime with `/statusline:sl <theme>`:

### powerline (default)
```
❯ my-project │ main ✗ │ ctx:70% │ Opus 4.6 │ session +1410/-68 │ time 42m │ 5h quota 49% resets ~2h38m
```

### minimal
```
my-project main ✗ rate 5h:49%
```

### compact
```
my-project (main ✗) · 70% ctx · rate 5h:49%
```

### full
```
r1:~/projects/my-project main ✗ ctx:70% Opus 4.6 rate 5h:49% ~2h38m lines +1410/-68 time 42m
```

## Detail levels

Control how much info you see. Default is `high`.

| Level      | What's shown |
|------------|--------------|
| **low**    | Project name, branch, dirty indicator (✗) |
| **medium** | + context %, model, cost or rate limit |
| **high**   | + session lines, uncommitted diff, duration, todos, quota resets |

## Metrics

| Metric | Description |
|--------|-------------|
| **Project name** | Git repo name or directory basename |
| **Branch + dirty** | Current branch with red ✗ for uncommitted changes |
| **Context %** | How much context window is consumed |
| **Model** | Active model (Opus 4.6, Sonnet, etc.) |
| **Session lines** | Lines added/removed by Claude this session |
| **Uncommitted diff** | Lines in your uncommitted git changes |
| **Duration** | Session wall-clock time |
| **Quota (5h/7d)** | Rolling rate limit usage with reset countdown |
| **Session cost** | USD spent (API billing users only) |
| **Todos** | Active todo count |

### Smart billing detection

The plugin auto-detects subscription vs API billing:

- **Max plan subscribers** see rate limit quotas with reset countdowns
- **API billing users** see session cost in USD

Rate limits are color-coded: gray (< 60%), orange (60-79%), red (80%+).

## Switch on the fly

```
/statusline:sl powerline        # switch theme
/statusline:sl high             # switch detail level
/statusline:sl minimal low      # switch both
/statusline:sl                  # preview all themes
```

Or edit `~/.claude/statusline-config.json` directly — changes apply immediately.

## Custom themes

Create `~/.claude/statusline-themes/mytheme.js`:

```js
'use strict';

function render(data) {
  // data.project, data.branch, data.dirty (' ✗' or '')
  // data.model, data.contextUsedPct, data.detail
  // data.isSubscription, data.costUsd, data.rateLimit5h, data.rateLimit7d
  // data.resetIn5h, data.resetIn7d (seconds)
  // data.linesAdded, data.linesRemoved (session totals)
  // data.diffAdded, data.diffRemoved (uncommitted git diff)
  // data.durationMs, data.todoCount
  // data.user, data.cwd, data.raw (full JSON from Claude Code)

  return `${data.project} [${data.branch}${data.dirty}]`;
}

module.exports = { render };
```

Then `/statusline:sl mytheme` to activate.

## Uninstall

```
/statusline:setup uninstall
```

## License

[MIT](LICENSE)
