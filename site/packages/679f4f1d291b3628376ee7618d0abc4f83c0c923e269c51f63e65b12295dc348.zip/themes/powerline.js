'use strict';

// Theme: powerline — bold segments with separators
// Subscription (Max plan):
//   low:    ❯ project │ main ✗
//   medium: ❯ project │ main ✗ │ ctx:70% │ Opus 4.6
//   high:   ❯ project │ main ✗ │ ctx:70% │ Opus 4.6 │ lines +1410/-68 │ time 42m │ 5h quota 49% resets ~2h38m │ 7d quota 64% resets ~4d
// API billing:
//   medium: ❯ project │ main ✗ │ ctx:70% │ Opus 4.6 │ $7.85
//   high:   ❯ project │ main ✗ │ ctx:70% │ Opus 4.6 │ $7.85 │ lines +1410/-68 │ time 42m

const R = '\x1b[0m';
const B = '\x1b[1m';
const CYAN = '\x1b[38;2;23;146;153m';
const GREEN = '\x1b[38;2;64;160;43m';
const YELLOW = '\x1b[38;2;223;142;29m';
const MAGENTA = '\x1b[38;2;136;57;239m';
const GRAY = '\x1b[38;2;76;79;105m';
const RED = '\x1b[38;2;220;50;47m';
const ORANGE = '\x1b[38;2;245;166;35m';
const BLUE = '\x1b[38;2;30;102;245m';
const DIM = '\x1b[2m';

const SEP = `${DIM}${GRAY} \u2502 ${R}`;

function fmtCost(usd) {
  if (usd == null) return null;
  return usd < 0.01 ? '<$0.01' : `$${usd.toFixed(2)}`;
}

function fmtDuration(ms) {
  if (ms == null) return null;
  const totalSec = Math.floor(ms / 1000);
  if (totalSec < 60) return `${totalSec}s`;
  const min = Math.floor(totalSec / 60);
  if (min < 60) return `${min}m`;
  const hr = Math.floor(min / 60);
  return `${hr}h${min % 60}m`;
}

function fmtReset(seconds) {
  if (seconds == null || seconds <= 0) return '';
  const min = Math.floor(seconds / 60);
  if (min < 60) return ` ~${min}m`;
  const hr = Math.floor(min / 60);
  const rm = min % 60;
  return rm > 0 ? ` ~${hr}h${rm}m` : ` ~${hr}h`;
}

function rlColor(pct) {
  if (pct >= 80) return RED;
  if (pct >= 60) return ORANGE;
  return GRAY;
}

function render(data) {
  const detail = data.detail || 'medium';
  const parts = [];

  // Always: project name
  parts.push(`${CYAN}${B}\u276f ${data.project}${R}`);

  if (detail === 'low') {
    if (data.branch) parts.push(`${GREEN}${data.branch}${RED}${data.dirty}${R}`);
    return parts.join(SEP);
  }

  // ── medium+ ────────────────────────────────────────────────────────────────

  if (data.branch) {
    parts.push(`${GREEN}${data.branch}${RED}${data.dirty}${R}`);
  }

  if (data.contextUsedPct != null) {
    const color = data.contextUsedPct > 80 ? RED : MAGENTA;
    parts.push(`${color}ctx:${data.contextUsedPct}%${R}`);
  }

  if (data.model) {
    parts.push(`${GRAY}${data.model}${R}`);
  }

  if (!data.isSubscription) {
    const costStr = fmtCost(data.costUsd);
    if (costStr) parts.push(`${YELLOW}${costStr}${R}`);
  }

  if (detail === 'medium') return parts.join(SEP);

  // ── high ───────────────────────────────────────────────────────────────────

  // Session LOC delta (from Claude's cost data)
  if (data.linesAdded != null || data.linesRemoved != null) {
    parts.push(`${GREEN}session +${data.linesAdded || 0}/-${data.linesRemoved || 0}${R}`);
  }

  // Uncommitted git diff
  if (data.diffAdded != null || data.diffRemoved != null) {
    parts.push(`${YELLOW}uncommitted +${data.diffAdded || 0}/-${data.diffRemoved || 0}${R}`);
  }

  // Duration
  const durStr = fmtDuration(data.durationMs);
  if (durStr) {
    parts.push(`${BLUE}time ${durStr}${R}`);
  }

  // Todos
  if (data.todoCount > 0) {
    parts.push(`${CYAN}todo:${data.todoCount}${R}`);
  }

  // Rate limits (subscription) — at the end, less urgent
  if (data.isSubscription) {
    if (data.rateLimit5h != null) {
      const c = rlColor(data.rateLimit5h);
      const reset = fmtReset(data.resetIn5h);
      parts.push(`${c}5h quota ${data.rateLimit5h}%${DIM} resets${reset}${R}`);
    }
    if (data.rateLimit7d != null) {
      const c = rlColor(data.rateLimit7d);
      const reset = fmtReset(data.resetIn7d);
      parts.push(`${c}7d quota ${data.rateLimit7d}%${DIM} resets${reset}${R}`);
    }
  }

  return parts.join(SEP);
}

module.exports = { render };
