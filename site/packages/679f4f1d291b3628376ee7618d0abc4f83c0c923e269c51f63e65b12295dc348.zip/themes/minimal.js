'use strict';

// Theme: minimal — clean and simple
// Subscription:
//   low:    project
//   medium: project main* 5h:49%
//   high:   project main* ctx:70% 5h:49% 7d:64%
// API billing:
//   medium: project main* $7.85
//   high:   project main* ctx:70% $7.85

const R = '\x1b[0m';
const CYAN = '\x1b[38;2;23;146;153m';
const GREEN = '\x1b[38;2;64;160;43m';
const YELLOW = '\x1b[38;2;223;142;29m';
const MAGENTA = '\x1b[38;2;136;57;239m';
const RED = '\x1b[38;2;220;50;47m';
const ORANGE = '\x1b[38;2;245;166;35m';
const GRAY = '\x1b[38;2;76;79;105m';

function rlColor(pct) {
  if (pct >= 80) return RED;
  if (pct >= 60) return ORANGE;
  return GRAY;
}

function render(data) {
  const detail = data.detail || 'medium';

  let out = `${CYAN}${data.project}${R}`;
  if (detail === 'low') return out;

  // medium+
  if (data.branch) {
    out += ` ${GREEN}${data.branch}${RED}${data.dirty}${R}`;
  }

  if (data.isSubscription) {
    if (data.rateLimit5h != null) {
      out += ` ${rlColor(data.rateLimit5h)}rate 5h:${data.rateLimit5h}%${R}`;
    }
  } else if (data.costUsd != null) {
    out += ` ${YELLOW}$${data.costUsd.toFixed(2)}${R}`;
  }

  if (detail === 'medium') return out;

  // high
  if (data.contextUsedPct != null) {
    const color = data.contextUsedPct > 80 ? RED : MAGENTA;
    out += ` ${color}ctx:${data.contextUsedPct}%${R}`;
  }

  if (data.isSubscription && data.rateLimit7d != null) {
    out += ` ${rlColor(data.rateLimit7d)}rate 7d:${data.rateLimit7d}%${R}`;
  }

  return out;
}

module.exports = { render };
