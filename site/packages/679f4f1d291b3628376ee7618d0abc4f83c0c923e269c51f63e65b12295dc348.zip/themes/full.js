'use strict';

// Theme: full — everything visible
// Subscription:
//   low:    user:project main
//   medium: user:~/path main* ctx:70% opus-4.6 5h:49% ~2h38m
//   high:   user:~/path main* ctx:70% opus-4.6 5h:49% ~2h38m 7d:64% +1410/-68 42m todos:3
// API billing:
//   medium: user:~/path main* ctx:70% opus-4.6 $7.85
//   high:   user:~/path main* ctx:70% opus-4.6 $7.85 +1410/-68 42m todos:3

const R = '\x1b[0m';
const BLUE = '\x1b[38;2;30;102;245m';
const GREEN = '\x1b[38;2;64;160;43m';
const YELLOW = '\x1b[38;2;223;142;29m';
const MAGENTA = '\x1b[38;2;136;57;239m';
const CYAN = '\x1b[38;2;23;146;153m';
const GRAY = '\x1b[38;2;76;79;105m';
const RED = '\x1b[38;2;220;50;47m';
const ORANGE = '\x1b[38;2;245;166;35m';
const DIM = '\x1b[2m';

function rlColor(pct) {
  if (pct >= 80) return RED;
  if (pct >= 60) return ORANGE;
  return GRAY;
}

function fmtReset(seconds) {
  if (seconds == null || seconds <= 0) return '';
  const min = Math.floor(seconds / 60);
  if (min < 60) return ` ~${min}m`;
  const hr = Math.floor(min / 60);
  const rm = min % 60;
  return rm > 0 ? ` ~${hr}h${rm}m` : ` ~${hr}h`;
}

function render(data) {
  const detail = data.detail || 'medium';
  const home = process.env.HOME || '';

  if (detail === 'low') {
    let out = `${CYAN}${data.user}${R}:${BLUE}${data.project}${R}`;
    if (data.branch) out += ` ${GREEN}${data.branch}${R}`;
    return out;
  }

  // medium+
  const shortPath = home ? data.cwd.replace(home, '~') : data.cwd;
  let out = `${CYAN}${data.user}${R}:${BLUE}${shortPath}${R}`;

  if (data.branch) {
    out += ` ${GREEN}${data.branch}${RED}${data.dirty}${R}`;
  }

  if (data.contextUsedPct != null) {
    const color = data.contextUsedPct > 80 ? RED : MAGENTA;
    out += ` ${color}ctx:${data.contextUsedPct}%${R}`;
  }

  if (data.model) {
    out += ` ${GRAY}${data.model}${R}`;
  }

  if (data.isSubscription) {
    if (data.rateLimit5h != null) {
      const c = rlColor(data.rateLimit5h);
      const reset = fmtReset(data.resetIn5h);
      out += ` ${c}rate 5h:${data.rateLimit5h}%${DIM}${reset}${R}`;
    }
  } else if (data.costUsd != null) {
    out += ` ${YELLOW}$${data.costUsd.toFixed(2)}${R}`;
  }

  if (detail === 'medium') return out;

  // high
  if (data.isSubscription && data.rateLimit7d != null) {
    const c = rlColor(data.rateLimit7d);
    const reset = fmtReset(data.resetIn7d);
    out += ` ${c}rate 7d:${data.rateLimit7d}%${DIM}${reset}${R}`;
  }

  if (data.linesAdded != null || data.linesRemoved != null) {
    out += ` ${GREEN}lines +${data.linesAdded || 0}/-${data.linesRemoved || 0}${R}`;
  }

  if (data.durationMs != null) {
    const sec = Math.floor(data.durationMs / 1000);
    const min = Math.floor(sec / 60);
    const dur = min < 60 ? `${min}m` : `${Math.floor(min / 60)}h${min % 60}m`;
    out += ` ${BLUE}time ${dur}${R}`;
  }

  if (data.todoCount > 0) {
    out += ` ${CYAN}todos:${data.todoCount}${R}`;
  }

  return out;
}

module.exports = { render };
