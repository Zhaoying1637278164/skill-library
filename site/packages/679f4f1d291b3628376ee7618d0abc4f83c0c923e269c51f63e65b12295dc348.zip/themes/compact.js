'use strict';

// Theme: compact — project-focused
// Subscription:
//   low:    project
//   medium: project (main*) · 70% ctx · 5h:49%
//   high:   project (main*) · 70% ctx · 5h:49% ~2h38m · 7d:64% · +1410/-68
// API billing:
//   medium: project (main*) · 70% ctx · $7.85
//   high:   project (main*) · 70% ctx · $7.85 · +1410/-68

const R = '\x1b[0m';
const B = '\x1b[1m';
const CYAN = '\x1b[38;2;23;146;153m';
const GREEN = '\x1b[38;2;64;160;43m';
const MAGENTA = '\x1b[38;2;136;57;239m';
const GRAY = '\x1b[38;2;76;79;105m';
const YELLOW = '\x1b[38;2;223;142;29m';
const RED = '\x1b[38;2;220;50;47m';
const ORANGE = '\x1b[38;2;245;166;35m';
const DIM = '\x1b[2m';

const DOT = `${GRAY}\u00b7${R}`;

function rlColor(pct) {
  if (pct >= 80) return RED;
  if (pct >= 60) return ORANGE;
  return GRAY;
}

function fmtReset(seconds) {
  if (seconds == null || seconds <= 0) return '';
  const min = Math.floor(seconds / 60);
  if (min < 60) return ` ~${min}m`;
  const hr = Math.floor(min / 60);
  const rm = min % 60;
  return rm > 0 ? ` ~${hr}h${rm}m` : ` ~${hr}h`;
}

function render(data) {
  const detail = data.detail || 'medium';

  let out = `${CYAN}${B}${data.project}${R}`;
  if (detail === 'low') return out;

  // medium+
  if (data.branch) {
    out += ` ${GRAY}(${GREEN}${data.branch}${RED}${data.dirty}${GRAY})${R}`;
  }

  if (data.contextUsedPct != null) {
    const color = data.contextUsedPct > 80 ? RED : MAGENTA;
    out += ` ${DOT} ${color}${data.contextUsedPct}% ctx${R}`;
  }

  if (data.isSubscription) {
    if (data.rateLimit5h != null) {
      const c = rlColor(data.rateLimit5h);
      out += ` ${DOT} ${c}rate 5h:${data.rateLimit5h}%${R}`;
    }
  } else if (data.costUsd != null) {
    out += ` ${DOT} ${YELLOW}$${data.costUsd.toFixed(2)}${R}`;
  }

  if (detail === 'medium') return out;

  // high
  if (data.isSubscription) {
    // Add reset countdown to 5h
    if (data.resetIn5h != null) {
      const reset = fmtReset(data.resetIn5h);
      if (reset) out += `${DIM}${reset}${R}`;
    }
    if (data.rateLimit7d != null) {
      const c = rlColor(data.rateLimit7d);
      out += ` ${DOT} ${c}rate 7d:${data.rateLimit7d}%${R}`;
    }
  }

  if (data.linesAdded != null || data.linesRemoved != null) {
    out += ` ${DOT} ${GREEN}lines +${data.linesAdded || 0}/-${data.linesRemoved || 0}${R}`;
  }

  return out;
}

module.exports = { render };
