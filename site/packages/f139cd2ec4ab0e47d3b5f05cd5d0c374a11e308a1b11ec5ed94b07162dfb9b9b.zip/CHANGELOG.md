# Changelog

Release history at a glance. Detailed notes for each release live on the corresponding [GitHub Releases](https://github.com/ggrigo/align/releases) page.

Format follows [Keep a Changelog](https://keepachangelog.com/) for the per-version sections; versioning is [SemVer](https://semver.org/).

---

## [v0.9.0] — 2026-07-18

**Form standardization — the archive's retro of /align itself.** A full-corpus
pass (23 submitted forms, ~730 claims, plus a census of all 36 live `.html`
forms — 28 of which had drifted off-template) produced
`references/v0.9-standardization-design.md` and this release:

- **Decision cards** — `kind: "decision"` claim objects with 2–4 options
  (+ auto-appended "Other — see note"; recommended option first, suffixed
  "(Recommended)"). Keys 1–N pick; counted separately ("n/m decided");
  exported under a new `## Decisions` section. Ends the #1 cause of bespoke
  form forks.
- **Autosave** — every rating/choice/note/missing edit persists to
  localStorage (`align:{slug}:{date}`) and restores on reload.
- **"？ unclear as written" quick-chip** — the standard home for "I don't
  understand this claim" (found filed under ❌/🔷/🤷 across the archive):
  rates 🔷 and prefixes the note `Unclear as written: `.
- **Export fixes** — all six Summary rows always emitted (sum-invariant by
  construction); unrated claims listed as "⬜ Skipped (unrated)" instead of
  vanishing; live DOM text flushed at export (kills the recurring mid-word
  note truncation); one confirm nudge when corrections have empty notes.
- **Interaction repairs** — `E` expand-detail implemented (was advertised
  only); `N` opens notes on any verdict (was focusing a hidden textarea);
  v0.7's revisit-ratings banner restored (5/10/20/50 thresholds, dismissal
  persisted); below 1080px the Missing box + Download button fold into the
  main column instead of disappearing with the rail; ≤760px single-column
  layout.
- **Self-contained again** — Google Fonts CDN links removed; system font
  stacks per preset. A populated form renders fully offline and makes zero
  external requests (matters for confidential-content forms).
- **SKILL.md rules** — Phase 1 must copy the template byte-for-byte (never
  regenerate from memory); ≤ ~25 claims per form (fatigue: a 93-claim form
  left 76 unrated); Phase 2 applies `## Decisions` as owner rulings and keeps
  🤷 claims open.

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.9.0)

## [v0.8.3] — 2026-07-13

**Vocabulary patch (`name-purge`).** Renamed the public "Claim Adapter Contract" → **"claim shape"** across every skill and doc surface, per the estate-wide retirement of the coined term "contract" (owner ruling 2026-07-13). Vocabulary only — the claim-object schema, modes, and producer responsibilities are unchanged; only the name of the interface moved. Genuinely legal/business-sense uses of "contract" were left untouched (example "contract amounts" in the smart-memory-filter docs, the Sony-contract example claim, and the MIT `LICENSE` liability clause).

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.8.3)

## [v0.8.2] — 2026-05-28

**Doc + spec-polish patch.** Eight PRs (#59–#67) since v0.8.1, all documentation, examples, or skill-spec guidance — no code-behavior changes.

- Trio examples set completed: `walkthrough-diagnose-pass.md` + `walkthrough-retro-pass.md` join the existing `walkthrough-readme-pass.md` in `examples/` (#63, #64). New users see worked end-to-end walkthroughs for all three skills.
- README discoverability: four shields.io badges (release / MIT / stars / `maintained by agent ggrigo`) at the top (#60); new §Worked examples section links the walkthroughs (#65).
- `CHANGELOG.md` at repo root (#61) — release history at a glance.
- `archive-format.md` §Archive folder layout extended to document `retro-output/` (v0.6+) and `diagnose-<slug>-<date>.md` (v0.8+) (#59) — closes a cross-doc citation drift surfaced by the maintainer's `/diagnose` dogfood pass.
- `walkthrough-readme-pass.md` canonical taxonomy preamble updated to v0.8 6-shape (#66); historical body preserved accurately for the v0.7.0-era pass it documents.
- `skills/align/SKILL.md` Phase-1 extraction guidance: cross-doc citations (`"per X.md"`) are themselves falsifiable claims worth extracting (#67) — derived from `/retro pass-4` synthesis on the maintainer's own archive.

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.8.2)

## [v0.8.1] — 2026-05-26

**Patch:** fix Cowork marketplace validation (drop `commands/`).

Cowork's marketplace validator rejected v0.8.0 because the plugin shipped both `commands/<name>.md` and `skills/<name>/SKILL.md` for the same names. Removed the three thin command wrappers (`commands/align.md`, `commands/retro.md`, `commands/diagnose.md`); the skills now own the slash-command entry directly. No functional change — `/align`, `/retro`, `/diagnose` still work. Build automation added: `.github/workflows/release.yml` auto-builds the `.plugin` zip on every `v*` tag push.

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.8.1)

## [v0.8.0] — 2026-05-26

**Closes the diagnostic loop.** Three additive landings:

- **`/diagnose` skill** — backward-trace each ❌/🔶/🔷 claim back to the stale instruction that caused it. Reads `CLAUDE.md`, `skills/*/SKILL.md`, `references/`, `TASKS.md` (smart-memory opt-in). Quoted-evidence citations, 0–100 confidence, threshold-80 filtering. Read-only.
- **`/retro` analyst pass** — per-producer accuracy variance + recurring-claim detection across the archive. Additive output; no public-contract change.
- **6-shape canonical taxonomy** — dropped `➖ Irrelevant` (the form never had a button for it; archive had zero ➖ rows across 16 sessions). New invariant: `✅+❌+🔶+🔷+🤷+⬜ = Claims`.

The trio (`/align` captures → `/diagnose` traces → `/retro` synthesizes) is now structurally complete.

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.8.0)

## [v0.7.0] — 2026-05-25

**Three-pane redesign + the apply side of `/retro`.**

- **`/retro apply`** — patch-applying side of the synthesis loop with explicit per-patch human-approval gate. `--dry-run` previews without writing.
- **Three-pane HTML form redesign** with three aesthetic presets (`editorial` / `modern` / `terminal`); keyboard-first rating (1–6 rate, ↑↓/jk navigate, N notes, auto-advance).
- **Multi-skill restructure** — namespaced invocations `/align:align` and `/align:retro` alongside legacy entrypoints; additive, no breaking change.
- **Opt-in smart-memory filter** declared in `CLAUDE.md`; default unfiltered.
- **Revisit-ratings banner** surfaces stale archive entries.
- **Marketplace + adoption surfaces** — `.claude-plugin/marketplace.json` added; `examples/walkthrough-readme-pass.md` first public worked walkthrough; `examples/producer-adapter.md` authoring guide.

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.7.0)

## [v0.6.0] — 2026-05-23

**`/retro` skill — synthesis side of the archive loop.** Reads accumulated `.align/` rows, writes a single pass document per run with aggregate metrics, failure-mode clusters, and proposed patches. Saturation check at Step 4.5. Plus contributor + security docs (`CONTRIBUTING.md`, `SECURITY.md`), template hardening, and the per-claim Claim Adapter Contract surfaced as the producer-side public interface.

[Release notes →](https://github.com/ggrigo/align/releases/tag/v0.6.0)

## [v0.5.0] — 2026-05-22

**First public publish** + Claim Adapter Contract promoted to first-class. Producer-side interface defined: any producer (rhythm, digest, todo, code-review, financial recon, ad-hoc Claude turn) that emits a claim array matching the schema can be aligned. Cross-surface install (`--plugin-dir` for Claude Code; `.plugin` zip upload for Cowork) via a single artifact.

(Tag-only; predates the GitHub Releases workflow.)

---

[v0.9.0]: https://github.com/ggrigo/align/releases/tag/v0.9.0
[v0.8.3]: https://github.com/ggrigo/align/releases/tag/v0.8.3
[v0.8.2]: https://github.com/ggrigo/align/releases/tag/v0.8.2
[v0.8.1]: https://github.com/ggrigo/align/releases/tag/v0.8.1
[v0.8.0]: https://github.com/ggrigo/align/releases/tag/v0.8.0
[v0.7.0]: https://github.com/ggrigo/align/releases/tag/v0.7.0
[v0.6.0]: https://github.com/ggrigo/align/releases/tag/v0.6.0
[v0.5.0]: https://github.com/ggrigo/align/compare/v0.5.0...v0.6.0
