# Collected value → payload key

How each collected row becomes a resolved row. Read this once, at the end of
[Phase 0.5](engine.md#phase-05--configure-the-issuance), when the collect has its answers.

One entry per stakeholder, **each carrying its own full field set**. There are no batch-wide
scalars left to stamp: every row carries its own terms, so a single batch can genuinely mix
`so_type`s and currencies.

Apply the mapping below to **each row individually**. `relationship` may be `""` when the user
left it blank — [Phase 1](engine.md#phase-1--resolve-each-row--reconcile-share-classes) only
honors it for stakeholders with no roster match.

**Omission rule (both types):** an empty string, `false`, or `null` on a pass-through field
means **omit the key entirely** from the payload — see [Row templates](engine.md#row-templates).

---

## Option grant, per row

| Collected as | Becomes | Notes |
|---|---|---|
| `option_type` | `so_type` | then apply that row's `so_type` autofill for `currency` / `exemption` ([payload-reference.md § so_type auto-fill rules](payload-reference.md#so_type-auto-fill-rules)) |
| `exercise_price` | `exercise_price` | ZEPO hard-sets `"0"` |
| `issue_date` | `issue_date` | |
| `board_approval` + `board_approval_date` | `needs_board_approval` | `pending` → `true`, else `false` |
| `vesting_template_id` | `vesting_template` | `null` on **No vesting** — warn, atypical for a grant |
| `vesting_start_date` | `vesting_start_date` | reformat to `MM/DD/YYYY` |
| `document_set_id` | `document_set_id` | |
| `stakeholder_kind` | `stakeholder_kind` | Phase 1 decides whether this or the roster's own value wins |

**Pass through unchanged:** `acceleration_template` (`null` on **No acceleration**), `notes`, `custom_label`, `early_exercise`, `auto_exercise_at_vest`,
`is_flexible_issue_date`, `grant_reason`.

`is_hmrc_notified` / `hmrc_notified`, `ato_notified`, and `employment_related` are already
conditionally absent from the row unless that row's `so_type` matched (EMI, the three AU
types, and `Unapproved`, respectively), so no additional gating is needed here.

Pass `employment_related` through as the boolean it is — **do not coerce a `false` to omitted**.
`false` ("No") is the answer that satisfies the Unapproved validation; only a missing value
fails it.

`fund_structure` follows the same tri-state rule on **both** security types, but it is never
collected: it is present only when an import sheet supplied it or a prior `validate_drafts`
block was recovered. Carry whatever the row holds — `true`, `false`, or
absent — and never synthesize a value the admin didn't give.

---

## Certificate, per row

| Collected as | Becomes | Notes |
|---|---|---|
| `share_class_prefix` | `prefix` | |
| `price_per_share` | `law_firm_price` | |
| `issue_date` | `issue_date` | |
| `board_approval` + `board_approval_date` | `needs_board_approval` | certs need a date — there is no `pending` |
| `legend_id` | `legend_id` | never the body — but **do** stamp the resolved legend's body as `legend_body`, a [review-only field](certificate-fields.md#review-only-fields-certificate--never-sent-to-the-mutate) |
| `rule_144_mode` / `rule_144_date` | `rule_144_date` | `issue_date` mode → set it to `issue_date` in `MM/DD/YYYY`; `other` → reformat, and read `rule_144_reason` off the row (already collected inline) and stamp it as `rule_144_difference_reason` — see [Rule 144 difference reason](certificate-fields.md#rule-144-difference-reason) |
| `vesting_template_id` | `vesting_template` | `null` on **No vesting** — this is the certificate default, so unlike a grant, do **not** warn |
| `vesting_start_date` | `vesting_start_date` | reformat to `MM/DD/YYYY`, only when a real template is set |

**Defaults:** `exemption = "Section 4(a)(2)"`; `currency` per the resolved jurisdiction.

**Pass through unchanged:** `acceleration_template` (`null` on **No acceleration**), `notes`, `prefix_number`, `cash_paid`, `debt_canceled`.

Finally, drive the [Dividend accrual start date
resolution](certificate-fields.md#dividend-accrual-start-date-resolution) from each class's
`dividend` field.

---

## PIU, per row

| Collected as | Becomes | Notes |
|---|---|---|
| `share_class_prefix` | `prefix` | the **unit class** |
| `option_plan` | `option_plan` | **omit when empty** — empty is a real answer that issues off the unit class, not a missing one. Stamp the resolved plan's name as the review-only `equity_plan_label` |
| `threshold_value` | `threshold_value` | never defaulted; a `0` survives |
| `threshold_value_type` | `threshold_value_type` | `Unit` or `Overall` only |
| `issue_date` | `issue_date` | |
| `board_approval_date` | `board_approval_date` | **there is no `needs_board_approval` on a PIU** — that field does not exist on the model and sending it fails the whole mutate. An empty date omits the key |
| `vesting_template_id` | `vesting_template` | `null` on **No vesting** — the PIU default, so like a certificate and unlike a grant, do **not** warn |
| `vesting_start_date` | `vesting_start_date` | reformat to `MM/DD/YYYY`, only when a real template is set |
| `document_set_id` | `document_set_id` | server resolves both doc slots from it |
| `corresponding_interest` | `corresponding_interest` | send `true`/`false`/`null` only when the question was asked, and omit the key otherwise. **Exception — the user explicitly asked for one:** send `true` even when the question wasn't asked, and surface the server's verdict ([piu-fields.md](piu-fields.md#an-explicit-request-is-never-silently-dropped)). Never drop an explicit request |

**Defaults:** `exemption = "Section 4(a)(2)"`; `currency` per the resolved jurisdiction.

**Pass through unchanged:** `acceleration_template` (`null` on **No acceleration**), `notes`, `prefix_number`, `cash_paid`, `is_flexible_issue_date`.

**Never emit:** `price_per_share`/`law_firm_price`, `legend_id`, `rule_144_*`,
`exercise_price`, `so_type`, `grant_expiration_date`, `equity_plan_id`.
