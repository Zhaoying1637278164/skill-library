# /// script
# requires-python = ">=3.9"
# ///
"""Assemble the self-contained captable-home live artifact from its source parts.

Inlines the CSS + config + app JS into the template and substitutes the Carta MCP
connector name, producing ONE self-contained HTML file the Artifact tool publishes
by path. The model never has to read the large HTML: to change what the
directory shows, edit resources/captable-home.config.js; to change logic, edit
resources/captable-home.app.js; then re-run this.

Source parts (all in the skill's resources/ dir):
  captable-home.template.html  — HTML skeleton + <style>/<script> injection markers
  captable-home.css            — styles          (marker: /* __CAPTABLE_HOME_CSS__ */)
  captable-home.tracker.js     — Snowplow UI tracker bundle (marker: /* __CAPTABLE_HOME_TRACKER_JS__ */)
  captable-home.config.js      — DIR_CATEGORIES  (marker: /* __CAPTABLE_HOME_CONFIG_JS__ */)
  captable-home.app.js         — app logic       (marker: /* __CAPTABLE_HOME_APP_JS__ */)

The artifact's version comes from the plugin's skill-versions registry, keyed by this
skill (placeholder: {{ARTIFACT_VERSION}}). It lives there rather than beside the skill
because carta-mcp serves it to the running artifact from the published carta/plugins
mirror, and a skill that has not opted into publishing never reaches that mirror —
whereas .claude-plugin/ is plugin-level metadata and is always published.

The `{{CARTA_MCP_SERVER}}` placeholder (throughout the template + app) is replaced with
the Carta connector's display name — what the artifact runtime's mcp capability
addresses a connector by.

One built page serves one company: `{{CORPORATION_ID}}`, `{{COMPANY_NAME_JSON}}` and
`{{PAGE_TITLE}}` are baked in, and the artifact is published as "Carta Home - <company>".
Build again to serve another company.

The title has to come from the file. The Artifact tool reads `<title>` out of the HTML and
only falls back to its own `title` parameter when the file carries none — so a template
with a fixed title publishes every company's page under that one name.

Usage:
  uv run scripts/build_artifact.py --mcp-server <connector-display-name> \
      --corporation-id <corporation_id> --company-name "<company legal name>" \
      --out <path>/captable-home-<slug>.html
"""
import argparse
import hashlib
import json
import re
import sys
from html import escape
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
RES = SKILL_DIR / "resources"
VENDOR_DIR = SKILL_DIR.parent.parent / "vendor"  # plugin root / vendor/

SKILL_NAME = SKILL_DIR.name
VERSIONS_FILE = SKILL_DIR.parent.parent / ".claude-plugin" / "skill-versions.json"
# A built artifact can never update itself, so it carries its version with it and
# compares against the published one at runtime. Strict major.minor.patch.
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")

# App-layer JS is assembled from these files, concatenated in this order into the
# single __CAPTABLE_HOME_APP_JS__ slot below. Add new feature files here.
APP_JS_PARTS = [
    "captable-home.app.js",
    "app/ownership.js",
    "app/option-pool.js",
    "app/stakeholders.js",
    "app/drafts.js",
    "app/dashboards.js",
    "app/capabilities.js",
    "app/whats-new.js",
    "app/version-check.js",
    "app/live-content.js",
]

MARKERS = {
    "captable-home.css": r"/\*\s*__CAPTABLE_HOME_CSS__\s*\*/",
    "captable-home.tracker.js": r"/\*\s*__CAPTABLE_HOME_TRACKER_JS__\s*\*/",
    "captable-home.config.js": r"/\*\s*__CAPTABLE_HOME_CONFIG_JS__\s*\*/",
}
VENDOR_MARKERS = {
    # chart.js v4.5.1 — replace vendor/chart.umd.min.js and bump this comment to upgrade
    "chart.umd.min.js": r"/\*\s*__CAPTABLE_HOME_CHART_JS__\s*\*/",
}
APP_JS_MARKER = r"/\*\s*__CAPTABLE_HOME_APP_JS__\s*\*/"

CORP_ID_PREFIX = "corporation_pk:"

# The published artifact's name, and the key SKILL.md Step 2 matches on to find this
# company's existing page. One company per page, so one title per company.
TITLE_PREFIX = "Carta Home - "


def page_title(company_name):
    """The `<title>` text for this company's page.

    Escapes only the three characters that would end the tag or start an entity —
    a company named `Smith & Sons <Holdings>` otherwise produces malformed HTML.
    Quotes are left alone: this is element text, not an attribute.
    """
    return escape(TITLE_PREFIX + company_name, quote=False)


def compute_build_id(template, parts):
    """Short content hash of all source parts — changes only when a source changes,
    so a visible `build <id>` makes it obvious whether a panel shows the latest build."""
    h = hashlib.sha256()
    h.update(template.encode("utf-8"))
    for name in sorted(parts):
        h.update(name.encode("utf-8"))
        h.update(parts[name].encode("utf-8"))
    return h.hexdigest()[:8]


def read_version():
    """Return this skill's version from the plugin's skill-versions registry.

    Fails the build rather than defaulting: a wrong version is worse than no build.
    """
    label = "{}[{}]".format(VERSIONS_FILE.name, SKILL_NAME)
    if not VERSIONS_FILE.exists():
        sys.exit("ERROR: {} is missing".format(VERSIONS_FILE))
    try:
        data = json.loads(VERSIONS_FILE.read_text())
    except ValueError as exc:
        sys.exit("ERROR: {} is not valid JSON: {}".format(VERSIONS_FILE.name, exc))
    entry = data.get(SKILL_NAME)
    if not isinstance(entry, dict):
        sys.exit('ERROR: {} needs an entry like {{"version": "1.2.3"}}'.format(label))
    version = entry.get("version")
    if not isinstance(version, str) or not SEMVER_RE.match(version):
        sys.exit('ERROR: {} needs a "version" like "1.2.3", got {!r}'.format(label, version))
    return version


def normalize_corporation_id(raw):
    """Reject an id that still carries list_accounts' `corporation_pk:` prefix.

    Every cap_table command wants the bare pk, and a prefixed one fails at runtime
    inside a published page — far from here. Fail at build time instead.
    """
    value = (raw or "").strip()
    if not value:
        sys.exit("ERROR: --corporation-id is empty")
    if value.startswith(CORP_ID_PREFIX):
        sys.exit(
            "ERROR: --corporation-id must be the bare pk, not {!r} — strip the {!r} prefix".format(
                value, CORP_ID_PREFIX
            )
        )
    return value


def build(mcp_server, corporation_id, company_name):
    template = (RES / "captable-home.template.html").read_text()
    parts = {name: (RES / name).read_text() for name in MARKERS}
    parts.update({name: (VENDOR_DIR / name).read_text() for name in VENDOR_MARKERS})
    parts.update({name: (RES / name).read_text() for name in APP_JS_PARTS})
    build_id = compute_build_id(template, parts)

    out = template
    for filename, marker in {**MARKERS, **VENDOR_MARKERS}.items():
        content = parts[filename]
        if not re.search(marker, out):
            sys.exit("ERROR: marker for {} missing from template".format(filename))
        # Use a function replacement so backslashes / $-refs in the content are literal.
        out = re.sub(marker, lambda _m, c=content: c, out, count=1)

    app_js = "\n\n".join(parts[name] for name in APP_JS_PARTS)
    if not re.search(APP_JS_MARKER, out):
        sys.exit("ERROR: marker for app JS missing from template")
    out = re.sub(APP_JS_MARKER, lambda _m, c=app_js: c, out, count=1)

    # Leftover build-time markers would mean an incomplete assembly — fail loudly.
    for token in ("__CAPTABLE_HOME_CSS__", "__CAPTABLE_HOME_TRACKER_JS__", "__CAPTABLE_HOME_CHART_JS__", "__CAPTABLE_HOME_CONFIG_JS__", "__CAPTABLE_HOME_APP_JS__"):
        if token in out:
            sys.exit("ERROR: unresolved marker {} after assembly".format(token))

    out = out.replace("{{CARTA_MCP_SERVER}}", mcp_server)
    if "{{CARTA_MCP_SERVER}}" in out:
        sys.exit("ERROR: {{CARTA_MCP_SERVER}} still present after substitution")

    out = out.replace("{{CORPORATION_ID}}", corporation_id)
    if "{{CORPORATION_ID}}" in out:
        sys.exit("ERROR: {{CORPORATION_ID}} still present after substitution")

    # JSON-encode: the name lands inside a JS string literal in one concatenated
    # <script>, so a quote or backslash in it would be a SyntaxError killing every card.
    out = out.replace("{{COMPANY_NAME_JSON}}", json.dumps(company_name))
    if "{{COMPANY_NAME_JSON}}" in out:
        sys.exit("ERROR: {{COMPANY_NAME_JSON}} still present after substitution")

    out = out.replace("{{PAGE_TITLE}}", page_title(company_name))
    if "{{PAGE_TITLE}}" in out:
        sys.exit("ERROR: {{PAGE_TITLE}} still present after substitution")

    out = out.replace("{{BUILD_ID}}", build_id)

    version = read_version()
    out = out.replace("{{ARTIFACT_VERSION}}", version)
    if "{{ARTIFACT_VERSION}}" in out:
        sys.exit("ERROR: {{ARTIFACT_VERSION}} still present after substitution")

    return out, build_id, version


def main():
    ap = argparse.ArgumentParser(description="Assemble the captable-home artifact.")
    ap.add_argument("--mcp-server", required=True,
                    help="Carta connector display name (the {{CARTA_MCP_SERVER}} value)")
    ap.add_argument("--corporation-id", required=True,
                    help="bare corporation pk this page is built for (no corporation_pk: prefix)")
    ap.add_argument("--company-name", required=True,
                    help="company display name — shown on the page and, as "
                         "'Carta Home - <name>', in the page's <title> and so the "
                         "published artifact's name")
    ap.add_argument("--out", required=True, help="output HTML path")
    args = ap.parse_args()

    company_name = args.company_name.strip()
    if not company_name:
        sys.exit("ERROR: --company-name is empty")

    html, build_id, version = build(
        args.mcp_server, normalize_corporation_id(args.corporation_id), company_name
    )
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html)
    print(
        'wrote {} ({} bytes) — v{} build {} — publishes as "{}{}"'.format(
            out_path, len(html.encode("utf-8")), version, build_id,
            TITLE_PREFIX, company_name,
        )
    )


if __name__ == "__main__":
    main()
