import assert from "node:assert/strict";
import { execFileSync, spawnSync } from "node:child_process";
import { chmodSync, cpSync, existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, readlinkSync, realpathSync, readdirSync, rmSync, symlinkSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, extname, isAbsolute, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
delete process.env.XDG_CONFIG_HOME;
delete process.env.OPENCODE_CONFIG_DIR;
const PACKAGE_VERSION = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")).version;
const CONTRACT = JSON.parse(read("tests/fixtures/core-contract.json"));

function pathFromRoot(path) {
  return join(ROOT, path);
}

function read(path) {
  return readFileSync(pathFromRoot(path), "utf8");
}

function json(path) {
  return JSON.parse(read(path));
}

function filesUnder(path) {
  const absolute = pathFromRoot(path);
  if (!existsSync(absolute)) return [];
  if (!statSync(absolute).isDirectory()) return [path];

  return readdirSync(absolute, { withFileTypes: true }).flatMap((entry) => {
    const child = join(path, entry.name);
    if (entry.isDirectory() && [".git", ".hyperflow", "node_modules"].includes(entry.name)) return [];
    if (entry.isDirectory()) return filesUnder(child);
    return entry.isFile() ? [child] : [];
  });
}

function shippedFiles() {
  return execFileSync("git", ["ls-files", "--cached", "--others", "--exclude-standard", "-z"], { cwd: ROOT })
    .toString()
    .split("\0")
    .filter((path) => path && path !== "docs/internal/maintainer-log.md" && existsSync(pathFromRoot(path)) && statSync(pathFromRoot(path)).isFile());
}

function words(markdown) {
  return markdown.match(/[\p{L}\p{N}][\p{L}\p{N}'’_-]*/gu)?.length ?? 0;
}

function laneWindow(text, lane) {
  const index = text.toLowerCase().indexOf(lane.toLowerCase());
  assert.notEqual(index, -1, `${lane} lane is missing from the core contract`);
  return text.slice(Math.max(0, index - 240), index + 1800);
}

function assertNear(text, subject, pattern, message) {
  assert.match(laneWindow(text, subject), pattern, message);
}

function currentSurface(path) {
  const source = read(path);
  const migrationDocs = new Set(["README.md", "PRIVACY.md", "docs/installation.md", "install.sh"]);
  if (!migrationDocs.has(path)) return source;

  const htmlStart = "<!-- hyperflow:legacy-migration:start -->";
  const htmlEnd = "<!-- hyperflow:legacy-migration:end -->";
  const shellStart = "# hyperflow:legacy-migration:start";
  const shellEnd = "# hyperflow:legacy-migration:end";
  assert.equal(source.split(htmlStart).length - 1, source.split(htmlEnd).length - 1, `${path} has an unbalanced HTML migration block`);
  assert.equal(source.split(shellStart).length - 1, source.split(shellEnd).length - 1, `${path} has an unbalanced shell migration block`);
  return source
    .replace(/<!-- hyperflow:legacy-migration:start -->[\s\S]*?<!-- hyperflow:legacy-migration:end -->/g, "")
    .replace(/# hyperflow:legacy-migration:start[\s\S]*?# hyperflow:legacy-migration:end/g, "");
}

test("core manifests parse and share one version", () => {
  const pkg = json("package.json");
  const claude = json(".claude-plugin/plugin.json");
  const codex = json(".codex-plugin/plugin.json");
  const marketplace = json(".claude-plugin/marketplace.json");
  const version = pkg.version;

  assert.equal(pkg.name, "hyperflow");
  assert.match(version, /^\d+\.\d+\.\d+$/);
  assert.equal(claude.version, version);
  assert.equal(codex.version, version);
  assert.equal(marketplace.metadata.version, version);
  assert.ok(marketplace.plugins.length > 0);
  for (const plugin of marketplace.plugins) assert.equal(plugin.version, version);
  assert.equal(read("skills/hyperflow/VERSION").trim(), version);
  for (const skill of CONTRACT.skills) {
    const frontmatterVersion = read(`skills/${skill}/SKILL.md`).match(/^version:\s*([^\s]+)$/m)?.[1];
    assert.equal(frontmatterVersion, version, `${skill}/SKILL.md version must match ${version}`);
  }

  for (const instructions of ["AGENTS.md", "CLAUDE.md"]) {
    if (!existsSync(pathFromRoot(instructions))) continue;
    assert.match(
      read(instructions),
      new RegExp(`hyperflow:doctrine:start version=${version.replaceAll(".", "\\.")}`),
      `${instructions} doctrine marker must match ${version}`,
    );
  }
});

test("only the seven public skills and seven specialist profiles ship", () => {
  const skills = readdirSync(pathFromRoot("skills"), { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && existsSync(pathFromRoot(`skills/${entry.name}/SKILL.md`)))
    .map((entry) => entry.name)
    .sort();
  const specialists = filesUnder("agents")
    .filter((path) => extname(path) === ".md")
    .map((path) => basename(path, ".md"))
    .sort();

  assert.deepEqual(skills, [...CONTRACT.skills].sort());
  assert.deepEqual(specialists, [...CONTRACT.specialists].sort());
});

test("specialist profiles identify the package author", () => {
  const expectedAuthor = json("package.json").author.name;
  for (const specialist of CONTRACT.specialists) {
    const frontmatter = read(`agents/${specialist}.md`).match(/^---\n([\s\S]*?)\n---/)?.[1] ?? "";
    assert.equal(
      frontmatter.match(/^author:\s*(.+)$/m)?.[1].trim(),
      expectedAuthor,
      `${specialist} must declare package.json author.name`,
    );
  }
});

test("Direct, Focused, and Deep lanes retain their routing and call budgets", () => {
  const kernel = [
    "skills/hyperflow/SKILL.md",
    "skills/plan/SKILL.md",
    "skills/dispatch/SKILL.md",
    "AGENTS.md",
    "CLAUDE.md",
  ].map(read).join("\n");

  for (const [lane, fixture] of Object.entries(CONTRACT.lanes)) {
    const window = laneWindow(kernel, lane);
    for (const signal of fixture.signals) {
      assert.match(window, new RegExp(signal.replace("-", "[-–—]?"), "i"), `${lane} must retain ${signal}`);
    }
  }

  assertNear(kernel, "Direct", /Direct[^\n]*(?:\|\s*0\s*\||(?:zero|0) child (?:agents|calls))/i, "Direct must use no child agents");
  assertNear(kernel, "Focused", /(?:at most|maximum|max(?:imum)?)[^\n]{0,80}(?:two|2)[^\n]{0,40}(?:child|investigator|reviewer)/i, "Focused planning must cap child calls at two");
  assertNear(kernel, "Deep", /(?:at most|maximum|max(?:imum)?)[^\n]{0,80}(?:five|5) child calls/i, "Deep planning must cap child calls at five");
  assertNear(kernel, "Focused", /(?:at most|maximum|max(?:imum)?)[^\n]{0,80}(?:four|4)[^\n]{0,40}(?:child calls|full chain|plan plus build|plan \+ build)/i, "Focused full chain must cap child calls at four");
  assertNear(kernel, "Deep", /(?:at most|maximum|max(?:imum)?)[^\n]{0,80}(?:eight|8)[^\n]{0,40}(?:child calls|full chain|plan plus build|plan \+ build)/i, "Deep full chain must cap child calls at eight");

  assert.match(kernel, /Focused[^\n]{0,120}(?:6,?000|6k) planning tokens|(?:6,?000|6k) planning tokens[^\n]{0,120}Focused/i);
  assert.match(kernel, /Deep[^\n]{0,120}(?:18,?000|18k) planning tokens|(?:18,?000|18k) planning tokens[^\n]{0,120}Deep/i);
  assert.match(kernel, /Focused[^\n]{0,120}(?:20,?000|20k)[^\n]{0,40}(?:full chain|non-cached tokens)|(?:20,?000|20k)[^\n]{0,120}Focused/i);
  assert.match(kernel, /Deep[^\n]{0,120}(?:60,?000|60k)[^\n]{0,40}(?:full chain|non-cached tokens)|(?:60,?000|60k)[^\n]{0,120}Deep/i);
});

test("security floor retains blocked files and commands", () => {
  for (const path of ["AGENTS.md", "CLAUDE.md", "skills/hyperflow/SKILL.md"]) {
    const security = read(path);
    for (const pattern of CONTRACT.blockedFiles) {
      assert.ok(security.includes(pattern), `${path} is missing blocked file pattern: ${pattern}`);
    }
    for (const command of CONTRACT.blockedCommands) {
      assert.ok(security.includes(command), `${path} is missing blocked command: ${command}`);
    }
    assert.match(security, /SECURITY_VIOLATION:/, `${path} must retain the halt signal`);
  }
});

test("every shipped JSON document parses", () => {
  for (const path of shippedFiles().filter((path) => extname(path) === ".json")) {
    assert.doesNotThrow(() => json(path), path);
  }
});

test("briefs and skill entrypoints stay within structural budgets", () => {
  const worker = read("skills/hyperflow/worker-brief.md");
  const reviewer = read("skills/hyperflow/reviewer-brief.md");
  assert.ok(words(worker) <= CONTRACT.budgets.workerBriefWords, `worker brief is ${words(worker)} words`);
  assert.ok(words(reviewer) <= CONTRACT.budgets.reviewerBriefWords, `reviewer brief is ${words(reviewer)} words`);
  assert.match(read("skills/plan/SKILL.md"), /(?:under|at most|maximum)[^\n]{0,40}1,?200 words/i);

  for (const skill of CONTRACT.skills) {
    const body = read(`skills/${skill}/SKILL.md`);
    const lines = body.split(/\r?\n/).length;
    assert.ok(lines <= CONTRACT.budgets.skillEntrypointLines, `${skill}/SKILL.md is ${lines} lines`);
  }
});

test("shipped footprint and prompt-bearing text stay below regression ceilings", () => {
  const files = shippedFiles();
  const bytes = files.reduce((total, path) => total + statSync(pathFromRoot(path)).size, 0);
  assert.ok(files.length <= CONTRACT.budgets.shippedFilesMax, `shipped files: ${files.length}`);
  assert.ok(bytes <= CONTRACT.budgets.shippedBytesMax, `shipped bytes: ${bytes}`);

  for (const doctrine of ["AGENTS.md", "CLAUDE.md"]) {
    assert.ok(read(doctrine).length <= CONTRACT.budgets.portableDoctrineCharsMax, `${doctrine} is ${read(doctrine).length} characters`);
  }
  assert.ok(read("skills/plan/SKILL.md").length <= CONTRACT.budgets.planCharsMax);
  assert.ok(read("skills/dispatch/SKILL.md").length <= CONTRACT.budgets.dispatchCharsMax);
  assert.ok(read("skills/hyperflow/SKILL.md").length <= CONTRACT.budgets.hyperflowCharsMax);

  const componentDescriptions = [
    ...CONTRACT.skills.map((skill) => read(`skills/${skill}/SKILL.md`).match(/^description:.*$/m)?.[0] ?? ""),
    ...CONTRACT.specialists.map((specialist) => read(`agents/${specialist}.md`).match(/^description:.*$/m)?.[0] ?? ""),
  ].join("\n");
  assert.ok(componentDescriptions.length <= CONTRACT.budgets.componentDescriptionsCharsMax, `component descriptions: ${componentDescriptions.length} characters`);
});

test("installed runtime has no hooks, Python, dashboard, viewer, or legacy visual stack", () => {
  const allFiles = filesUnder(".");
  const pythonFiles = allFiles.filter((path) => extname(path) === ".py");
  assert.deepEqual(pythonFiles, []);

  assert.deepEqual(filesUnder("hooks"), [], "hooks directory must contain no shipped files");
  assert.deepEqual(filesUnder("viewer"), [], "viewer directory must contain no shipped files");
  assert.equal(Object.hasOwn(json(".codex-plugin/plugin.json"), "hooks"), false, "Codex manifest must not register hooks");

  const currentRoots = [
    ".claude-plugin",
    ".codex-plugin",
    ".github",
    "agents",
    "config",
    "docs",
    "scripts",
    "skills",
    "templates",
  ];
  const currentFiles = ["AGENTS.md", "CLAUDE.md", "PRIVACY.md", "README.md", "RELEASING.md", "install.sh", "package.json"]
    .filter((path) => existsSync(pathFromRoot(path)))
    .concat(currentRoots.flatMap(filesUnder))
    .filter((path) => !path.startsWith("docs/archive/"));
  const shipped = currentFiles
    .filter((path) => ![".png", ".gif", ".mp4", ".ttf"].includes(extname(path)))
    .map((path) => `${path}\n${currentSurface(path)}`)
    .join("\n");

  assert.doesNotMatch(shipped, /\bpython3\b|(?:^|\s)python\s+-|\.py\b|#![^\n]*python/i);
  assert.doesNotMatch(shipped, /viewer\/|hyperflow view|viewer["']?\s*:\s*\{|dashboard["']?\s*:\s*\{|\/(?:admin-)?dashboard\b/i);
  assert.doesNotMatch(shipped, /hooks\/session-start|hooks\/pre-compact|scripts\/hook-runtime|"SessionStart"|"PreCompact"/i);
  assert.doesNotMatch(shipped, /\.hyperflow\/artefacts|artefact\.schema|render-artefact|open-artefact/i);
});

test("installer exposes every public skill to OpenCode and Antigravity and uninstall removes owned links", () => {
  const installer = read("install.sh");
  const declared = installer.match(/CORE_SKILLS=\(([^)]+)\)/)?.[1].trim().split(/\s+/).sort();
  assert.deepEqual(declared, [...CONTRACT.skills].sort());
  assert.match(installer, /\.opencode\/skills/);
  assert.match(installer, /\.gemini\/config\/skills/);
  assert.match(installer, /remove_owned_links/);
  assert.match(installer, /readlink/);
  assert.match(installer, /validate_checkout/);
  assert.match(installer, /validate_fetched_checkout/);
  assert.match(installer, /OPENCODE_CONFIG_DIR/);
  assert.match(installer, /OPENCODE_ROOT/);
  assert.match(installer, /cat-file -e FETCH_HEAD:package\.json/);
  assert.match(installer, /config --get remote\.origin\.url/);
  assert.match(installer, /\.config\/opencode\/skills/);
  assert.match(installer, /accept-major-migration/);
  assert.match(installer, /link-only/);
  assert.match(installer, /status --porcelain --untracked-files=all/);
  assert.match(installer, /merge-base --is-ancestor HEAD FETCH_HEAD/);
  assert.match(installer, /Unable to fetch origin\/main/);
  assert.match(installer, /Unable to fast-forward origin\/main/);
  assert.doesNotMatch(installer, /\.cursor\/skills|\.grok\/skills/);
  assert.doesNotMatch(installer, /\bCODEX_[A-Z0-9_]+\b/);

  const temp = mkdtempSync(join(tmpdir(), "hyperflow-install-test-"));
  try {
    const installRoot = join(temp, "checkout");
    const skillsRoot = join(temp, ".opencode", "skills");
    const agySkillsRoot = join(temp, ".gemini", "config", "skills");
    const foreign = join(temp, "foreign-skill");
    mkdirSync(join(installRoot, "skills", "hyperflow"), { recursive: true });
    mkdirSync(skillsRoot, { recursive: true });
    mkdirSync(agySkillsRoot, { recursive: true });
    mkdirSync(foreign, { recursive: true });
    symlinkSync(join(installRoot, "skills", "hyperflow"), join(skillsRoot, "hyperflow"));
    symlinkSync(join(installRoot, "skills", "hyperflow"), join(agySkillsRoot, "hyperflow"));
    symlinkSync(foreign, join(skillsRoot, "plan"));

    const uninstall = spawnSync("bash", [pathFromRoot("install.sh"), "--uninstall"], {
      encoding: "utf8",
      env: { ...process.env, HOME: temp, HYPERFLOW_HOME: installRoot, PATH: "/usr/bin:/bin" },
    });
    assert.equal(uninstall.status, 0, uninstall.stderr);
    assert.equal(existsSync(join(skillsRoot, "hyperflow")), false, "owned link must be removed from OpenCode");
    assert.equal(existsSync(join(agySkillsRoot, "hyperflow")), false, "owned link must be removed from Antigravity");
    assert.equal(lstatSync(join(skillsRoot, "plan")).isSymbolicLink(), true, "foreign link must remain");
    assert.equal(existsSync(installRoot), true, "checkout must remain");

    const untrusted = join(temp, "untrusted");
    mkdirSync(untrusted);
    execFileSync("git", ["init", "-q", untrusted]);
    execFileSync("git", ["-C", untrusted, "remote", "add", "origin", "https://example.com/not-hyperflow.git"]);
    const rejected = spawnSync("bash", [pathFromRoot("install.sh")], {
      encoding: "utf8",
      env: { ...process.env, HOME: temp, HYPERFLOW_HOME: untrusted, PATH: "/usr/bin:/bin" },
    });
    assert.notEqual(rejected.status, 0, "an unrelated checkout must be rejected");
    assert.match(rejected.stderr, /not the Hyperflow repository/);

    const noHostHome = join(temp, "no-host");
    mkdirSync(noHostHome);
    const noHost = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], {
      encoding: "utf8",
      env: { ...process.env, HOME: noHostHome, HYPERFLOW_HOME: ROOT, PATH: "/usr/bin:/bin" },
    });
    assert.notEqual(noHost.status, 0, "an install with no detected host must not report success");
    assert.match(noHost.stderr, /No supported host was detected/);

    const conflictHome = join(temp, "conflict-host");
    const conflictSkills = join(conflictHome, ".config", "opencode", "skills");
    mkdirSync(conflictSkills, { recursive: true });
    symlinkSync(foreign, join(conflictSkills, "hyperflow"));
    const conflict = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], {
      encoding: "utf8",
      env: { ...process.env, HOME: conflictHome, HYPERFLOW_HOME: ROOT, PATH: "/usr/bin:/bin" },
    });
    assert.notEqual(conflict.status, 0, "a partial OpenCode link set must not report success");
    assert.match(conflict.stderr, /skill path conflict/);
    assert.equal(existsSync(join(conflictSkills, "plan")), false, "a conflict must not leave a partial link set");

    const relativeHome = join(temp, "relative-home");
    const relativeCheckout = join(relativeHome, "checkout");
    const fakeNativeBin = join(temp, "fake-native-bin");
    mkdirSync(relativeHome, { recursive: true });
    mkdirSync(fakeNativeBin, { recursive: true });
    symlinkSync("/bin/false", join(fakeNativeBin, "claude"));
    cpSync(pathFromRoot("skills"), join(relativeCheckout, "skills"), { recursive: true });
    execFileSync("git", ["init", "-q", relativeCheckout]);
    execFileSync("git", ["-C", relativeCheckout, "remote", "add", "origin", "ssh://git@github.com/Mohammed-Abdelhady/hyperflow.git"]);
    mkdirSync(join(relativeHome, ".config", "opencode"), { recursive: true });
    mkdirSync(join(relativeHome, ".gemini", "config"), { recursive: true });
    const incomplete = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], { cwd: relativeHome, encoding: "utf8", env: { ...process.env, HOME: relativeHome, HYPERFLOW_HOME: "checkout", PATH: `${fakeNativeBin}:/usr/bin:/bin` } });
    assert.notEqual(incomplete.status, 0, "a partial checkout must not report a successful link-only install");
    assert.match(incomplete.stderr, /Incomplete Hyperflow checkout: missing package\.json/);
    cpSync(pathFromRoot("package.json"), join(relativeCheckout, "package.json"));
    const relativeInstall = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], {
      cwd: relativeHome,
      encoding: "utf8",
      env: { ...process.env, HOME: relativeHome, HYPERFLOW_HOME: "checkout", PATH: `${fakeNativeBin}:/usr/bin:/bin` },
    });
    assert.equal(relativeInstall.status, 0, relativeInstall.stderr);
    const linkTarget = readlinkSync(join(relativeHome, ".config", "opencode", "skills", "hyperflow"));
    const expectedTarget = join(relativeHome, "checkout", "skills", "hyperflow");
    // Compare resolved paths: a host that reports a physical $PWD (macOS /private/var)
    // yields a different literal string for the same checkout. Absoluteness is the
    // property under test, so assert it directly rather than inferring it from equality.
    assert.equal(isAbsolute(linkTarget), true, "relative HYPERFLOW_HOME must create an absolute skill link");
    assert.equal(
      realpathSync(linkTarget),
      realpathSync(expectedTarget),
      "relative HYPERFLOW_HOME must link to this checkout",
    );
    assert.equal(
      readFileSync(join(relativeHome, ".config", "opencode", "skills", "hyperflow", "SKILL.md"), "utf8"),
      readFileSync(join(relativeCheckout, "skills", "hyperflow", "SKILL.md"), "utf8"),
      "relative HYPERFLOW_HOME must create a working link",
    );

    const customOpenCodeHome = join(temp, "custom-opencode-home");
    const customOpenCodeRoot = join(temp, "custom-opencode-config");
    mkdirSync(customOpenCodeRoot, { recursive: true });
    const customOpenCodeEnv = { ...process.env, HOME: customOpenCodeHome, HYPERFLOW_HOME: ROOT, OPENCODE_CONFIG_DIR: customOpenCodeRoot, PATH: "/usr/bin:/bin" };
    const customOpenCodeInstall = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], { encoding: "utf8", env: customOpenCodeEnv });
    assert.equal(customOpenCodeInstall.status, 0, customOpenCodeInstall.stderr);
    assert.equal(realpathSync(join(customOpenCodeRoot, "skills", "hyperflow")), realpathSync(join(ROOT, "skills", "hyperflow")));
    assert.equal(existsSync(join(customOpenCodeHome, ".config", "opencode")), false);
    const customOpenCodeUninstall = spawnSync("bash", [pathFromRoot("install.sh"), "--uninstall"], { encoding: "utf8", env: customOpenCodeEnv });
    assert.equal(customOpenCodeUninstall.status, 0, customOpenCodeUninstall.stderr);
    assert.equal(existsSync(join(customOpenCodeRoot, "skills", "hyperflow")), false);

    for (const skill of CONTRACT.skills) {
      const agyLink = join(relativeHome, ".gemini", "config", "skills", skill);
      assert.equal(lstatSync(agyLink).isSymbolicLink(), true, `Antigravity must link ${skill}`);
      assert.equal(
        realpathSync(agyLink),
        realpathSync(join(relativeCheckout, "skills", skill)),
        `Antigravity link for ${skill} must resolve to this checkout`,
      );
    }

    const worktreeHome = join(temp, "worktree-home");
    const upstream = join(temp, "upstream");
    mkdirSync(upstream, { recursive: true });
    cpSync(pathFromRoot("skills"), join(upstream, "skills"), { recursive: true });
    cpSync(pathFromRoot("package.json"), join(upstream, "package.json"));
    execFileSync("git", ["init", "-q", upstream]);
    execFileSync("git", ["-C", upstream, "config", "user.name", "Hyperflow Test"]);
    execFileSync("git", ["-C", upstream, "config", "user.email", "test@example.invalid"]);
    execFileSync("git", ["-C", upstream, "remote", "add", "origin", "https://github.com/Mohammed-Abdelhady/hyperflow.git"]);
    execFileSync("git", ["-C", upstream, "add", "skills", "package.json"]);
    execFileSync("git", ["-C", upstream, "commit", "-qm", "test: worktree fixture"]);
    execFileSync("git", ["-C", upstream, "worktree", "add", "-q", "--detach", worktreeHome]);
    mkdirSync(join(temp, "worktree-home-parent", ".config", "opencode"), { recursive: true });
    const worktreeHomeParent = join(temp, "worktree-home-parent");
    rmSync(worktreeHomeParent, { recursive: true, force: true });
    mkdirSync(join(worktreeHomeParent, ".config", "opencode"), { recursive: true });
    const worktreeInstall = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], {
      encoding: "utf8",
      env: { ...process.env, HOME: worktreeHomeParent, HYPERFLOW_HOME: worktreeHome, PATH: "/usr/bin:/bin" },
    });
    assert.equal(worktreeInstall.status, 0, worktreeInstall.stderr);
    assert.equal(statSync(join(worktreeHome, ".git")).isFile(), true, "fixture must use a worktree .git file");
    assert.equal(
      realpathSync(join(worktreeHomeParent, ".config", "opencode", "skills", "hyperflow")),
      realpathSync(join(worktreeHome, "skills", "hyperflow")),
      "Git worktree checkouts must be linkable",
    );

    const dirtyHome = join(temp, "dirty-home");
    const dirtyCheckout = join(dirtyHome, "checkout");
    cpSync(pathFromRoot("skills"), join(dirtyCheckout, "skills"), { recursive: true });
    cpSync(pathFromRoot("package.json"), join(dirtyCheckout, "package.json"));
    execFileSync("git", ["init", "-q", dirtyCheckout]);
    execFileSync("git", ["-C", dirtyCheckout, "config", "user.name", "Hyperflow Test"]);
    execFileSync("git", ["-C", dirtyCheckout, "config", "user.email", "test@example.invalid"]);
    execFileSync("git", ["-C", dirtyCheckout, "remote", "add", "origin", "https://github.com/Mohammed-Abdelhady/hyperflow.git"]);
    execFileSync("git", ["-C", dirtyCheckout, "add", "skills", "package.json"]);
    execFileSync("git", ["-C", dirtyCheckout, "commit", "-qm", "test: dirty update fixture"]);
    writeFileSync(
      join(dirtyCheckout, "package.json"),
      readFileSync(join(dirtyCheckout, "package.json"), "utf8").replace(
        `"version": "${PACKAGE_VERSION}"`,
        `"version": "${PACKAGE_VERSION}-local"`,
      ),
    );
    mkdirSync(join(dirtyHome, ".config", "opencode"), { recursive: true });
    const dirtyUpdate = spawnSync("bash", [pathFromRoot("install.sh")], {
      encoding: "utf8",
      env: { ...process.env, HOME: dirtyHome, HYPERFLOW_HOME: dirtyCheckout, PATH: "/usr/bin:/bin" },
    });
    assert.notEqual(dirtyUpdate.status, 0, "a dirty checkout must not be updated");
    assert.match(dirtyUpdate.stderr, /Refusing to update dirty checkout/);
    assert.equal(existsSync(join(dirtyCheckout, ".git", "FETCH_HEAD")), false, "dirty preflight must run before fetch");
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});

test("source-managed updates preflight fetched trees and preserve the checkout on failure", () => {
  const temp = mkdtempSync(join(tmpdir(), "hyperflow-installer-update-test-"));
  const seed = join(temp, "seed");
  const remote = join(temp, "remote.git");
  const checkout = join(temp, "checkout");
  const home = join(temp, "home");
  const gitConfig = join(temp, "gitconfig");
  const repoUrl = "https://github.com/Mohammed-Abdelhady/hyperflow.git";
  try {
    for (const path of shippedFiles()) {
      const target = join(seed, path);
      mkdirSync(dirname(target), { recursive: true });
      cpSync(pathFromRoot(path), target);
    }
    execFileSync("git", ["init", "-q", seed]);
    execFileSync("git", ["-C", seed, "config", "user.name", "Hyperflow Test"]);
    execFileSync("git", ["-C", seed, "config", "user.email", "test@example.invalid"]);
    execFileSync("git", ["-C", seed, "add", "-A"]);
    execFileSync("git", ["-C", seed, "commit", "-qm", "test: seed installer update fixture"]);
    execFileSync("git", ["-C", seed, "branch", "-M", "main"]);
    execFileSync("git", ["init", "--bare", "-q", remote]);
    execFileSync("git", ["-C", seed, "remote", "add", "origin", `file://${remote}`]);
    execFileSync("git", ["-C", seed, "push", "-q", "origin", "main"]);
    execFileSync("git", ["--git-dir", remote, "symbolic-ref", "HEAD", "refs/heads/main"]);
    execFileSync("git", ["clone", "-q", `file://${remote}`, checkout]);
    execFileSync("git", ["-C", checkout, "remote", "set-url", "origin", repoUrl]);
    mkdirSync(join(home, ".config", "opencode"), { recursive: true });

    const env = {
      ...process.env,
      HOME: home,
      HYPERFLOW_HOME: checkout,
      PATH: "/usr/bin:/bin",
      GIT_CONFIG_GLOBAL: gitConfig,
      GIT_CONFIG_NOSYSTEM: "1",
    };
    const baseHead = execFileSync("git", ["-C", checkout, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();

    writeFileSync(gitConfig, `[url "file:///missing-hyperflow-remote"]\n\tinsteadOf = ${repoUrl}\n`);
    const fetchFailure = spawnSync("bash", [pathFromRoot("install.sh")], { encoding: "utf8", env });
    assert.notEqual(fetchFailure.status, 0, "a fetch failure must fail the update");
    assert.match(fetchFailure.stderr, /Unable to fetch origin\/main/);
    assert.equal(execFileSync("git", ["-C", checkout, "rev-parse", "HEAD"], { encoding: "utf8" }).trim(), baseHead);

    writeFileSync(join(seed, "skills", "hyperflow", "SKILL.md"), `${readFileSync(join(seed, "skills", "hyperflow", "SKILL.md"), "utf8")}\n<!-- fast-forward fixture -->\n`);
    execFileSync("git", ["-C", seed, "add", "skills/hyperflow/SKILL.md"]);
    execFileSync("git", ["-C", seed, "commit", "-qm", "test: publish installer update"]);
    execFileSync("git", ["-C", seed, "push", "-q", "origin", "main"]);
    writeFileSync(gitConfig, `[url "file://${remote}"]\n\tinsteadOf = ${repoUrl}\n`);

    const update = spawnSync("bash", [pathFromRoot("install.sh")], { encoding: "utf8", env });
    assert.equal(update.status, 0, update.stderr);
    const updatedHead = execFileSync("git", ["-C", checkout, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();
    assert.notEqual(updatedHead, baseHead, "a reachable fast-forward must update the checkout");
    assert.match(readFileSync(join(checkout, "skills", "hyperflow", "SKILL.md"), "utf8"), /fast-forward fixture/);

    execFileSync("git", ["-C", seed, "rm", "-q", "skills/handoff/SKILL.md"]);
    execFileSync("git", ["-C", seed, "commit", "-qm", "test: publish incomplete installer update"]);
    execFileSync("git", ["-C", seed, "push", "-q", "origin", "main"]);

    const incomplete = spawnSync("bash", [pathFromRoot("install.sh")], { encoding: "utf8", env });
    assert.notEqual(incomplete.status, 0, "an incomplete fetched tree must fail before merge");
    assert.ok(incomplete.stderr.includes("Fetched origin/main is incomplete: missing skills/handoff/SKILL.md"), incomplete.stderr);
    assert.equal(execFileSync("git", ["-C", checkout, "rev-parse", "HEAD"], { encoding: "utf8" }).trim(), updatedHead);
    assert.equal(existsSync(join(checkout, "skills", "handoff", "SKILL.md")), true, "the checked-out skill must survive the rejected update");
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});

test("failed first-time clone cleans its install path", () => {
  const temp = mkdtempSync(join(tmpdir(), "hyperflow-clone-test-"));
  const checkout = join(temp, "checkout");
  try {
    const result = spawnSync("bash", [pathFromRoot("install.sh")], {
      env: {
        HOME: temp,
        HYPERFLOW_HOME: checkout,
        GIT_CONFIG_COUNT: "1",
        GIT_CONFIG_KEY_0: "url.file:///x.insteadOf",
        GIT_CONFIG_VALUE_0: "https://",
      },
    });
    assert.notEqual(result.status, 0, "a failed clone must fail the install");
    assert.equal(existsSync(checkout), false, "a failed clone must not leave a partial checkout");
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});

test("installer rolls back provider links when a host link operation fails", () => {
  const temp = mkdtempSync(join(tmpdir(), "hyperflow-installer-link-rollback-test-"));
  const home = join(temp, "home");
  const fakeBin = join(temp, "bin");
  const fakeLn = join(fakeBin, "ln");
  try {
    mkdirSync(join(home, ".config", "opencode"), { recursive: true });
    mkdirSync(fakeBin, { recursive: true });
    writeFileSync(fakeLn, "#!/usr/bin/env bash\nfor arg in \"$@\"; do case \"$arg\" in */skills/plan) exit 42;; esac; done\nexec /usr/bin/ln \"$@\"\n");
    chmodSync(fakeLn, 0o755);

    const result = spawnSync("bash", [pathFromRoot("install.sh"), "--link-only"], {
      encoding: "utf8",
      env: { ...process.env, HOME: home, HYPERFLOW_HOME: ROOT, PATH: `${fakeBin}:/usr/bin:/bin` },
    });
    assert.notEqual(result.status, 0, "a host link failure must fail the install");
    assert.match(result.stderr, /failed to link skills; rolled back without a partial link set/);
    for (const skill of CONTRACT.skills) {
      assert.equal(
        existsSync(join(home, ".config", "opencode", "skills", skill)),
        false,
        `failed provider linking must not leave a partial ${skill} link`,
      );
    }
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});

test("release path validates locally, stamps portable docs, and never pushes", () => {
  const release = read("scripts/release.sh");
  const bump = read("scripts/bump-version.sh");
  assert.match(release, /npm run validate-plugin/);
  assert.match(release, /npm run unittest/);
  assert.match(release, /npm run evals/);
  assert.match(release, /bash -n install\.sh scripts\/\*\.sh/);
  assert.match(release, /bump-version\.sh/);
  assert.match(release, /git tag -a/);
  assert.match(release, /Unreleased migration boundary requires a major version/);
  assert.doesNotMatch(release, /^\s*git push/m);
  assert.match(bump, /AGENTS\.md/);
  assert.match(bump, /CLAUDE\.md/);
  assert.match(bump, /hyperflow:doctrine:start version=/);
  assert.match(bump, /setReference\(updated, "Unreleased", `\$\{compareBase\}\/v\$\{version\}\.\.\.HEAD`\)/);
});

test("the pending migration boundary rejects patch releases", () => {
  const temp = mkdtempSync(join(tmpdir(), "hyperflow-major-release-test-"));
  const copyRoot = join(temp, "repo");
  try {
    for (const path of shippedFiles()) {
      const target = join(copyRoot, path);
      mkdirSync(dirname(target), { recursive: true });
      cpSync(pathFromRoot(path), target);
    }
    const changelogPath = join(copyRoot, "CHANGELOG.md");
    const changelog = readFileSync(changelogPath, "utf8");
    writeFileSync(changelogPath, changelog.replace("## [Unreleased]\n", "## [Unreleased]\n\n### Migration\n- Test major boundary.\n"));
    execFileSync("git", ["init", "-q", copyRoot]);
    execFileSync("git", ["-C", copyRoot, "config", "user.name", "Hyperflow Test"]);
    execFileSync("git", ["-C", copyRoot, "config", "user.email", "test@example.invalid"]);
    execFileSync("git", ["-C", copyRoot, "add", "-A"]);
    execFileSync("git", ["-C", copyRoot, "commit", "-qm", "test: fixture"]);

    const result = spawnSync("bash", [join(copyRoot, "scripts", "release.sh"), "patch", "--dry-run"], {
      cwd: copyRoot,
      encoding: "utf8",
    });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /requires a major version/);
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});

test("version stamping executes against an isolated release tree", () => {
  const temp = mkdtempSync(join(tmpdir(), "hyperflow-release-test-"));
  const copyRoot = join(temp, "repo");
  const releaseVersions = [...read("CHANGELOG.md").matchAll(/^## \[(\d+\.\d+\.\d+)\]/gm)].map((match) => match[1]);
  const previousRelease = releaseVersions.find((version) => version !== PACKAGE_VERSION);
  assert.ok(previousRelease, "the changelog must contain a release before the current package version");
  try {
    mkdirSync(join(copyRoot, "scripts"), { recursive: true });
    for (const path of ["package.json", ".claude-plugin", ".codex-plugin", "skills", "AGENTS.md", "CLAUDE.md", "README.md", "CHANGELOG.md"]) {
      cpSync(pathFromRoot(path), join(copyRoot, path), { recursive: true });
    }
    cpSync(pathFromRoot("scripts/bump-version.sh"), join(copyRoot, "scripts", "bump-version.sh"));
    execFileSync("bash", [join(copyRoot, "scripts", "bump-version.sh"), "9.8.7"], {
      env: { ...process.env, HYPERFLOW_RELEASE_PREPARE: "1" },
      stdio: "pipe",
    });

    assert.equal(JSON.parse(readFileSync(join(copyRoot, "package.json"), "utf8")).version, "9.8.7");
    assert.equal(readFileSync(join(copyRoot, "skills", "hyperflow", "VERSION"), "utf8").trim(), "9.8.7");
    for (const skill of CONTRACT.skills) assert.match(readFileSync(join(copyRoot, "skills", skill, "SKILL.md"), "utf8"), /^version: 9\.8\.7$/m);
    assert.match(readFileSync(join(copyRoot, "AGENTS.md"), "utf8"), /hyperflow:doctrine:start version=9\.8\.7/);
    assert.match(readFileSync(join(copyRoot, "README.md"), "utf8"), /\[!\[version v9\.8\.7\]/);
    assert.match(readFileSync(join(copyRoot, "README.md"), "utf8"), /version-v9\.8\.7/);
    const changelog = readFileSync(join(copyRoot, "CHANGELOG.md"), "utf8");
    assert.match(changelog, /## \[9\.8\.7\] — \d{4}-\d{2}-\d{2}/);
    assert.match(changelog, /^\[Unreleased\]: https:\/\/github\.com\/Mohammed-Abdelhady\/hyperflow\/compare\/v9\.8\.7\.\.\.HEAD$/m);
    const currentVersionPattern = PACKAGE_VERSION.replaceAll(".", "\\.");
    const previousVersionPattern = previousRelease.replaceAll(".", "\\.");
    assert.match(changelog, new RegExp(`^\\[9\\.8\\.7\\]: https://github\\.com/Mohammed-Abdelhady/hyperflow/compare/v${currentVersionPattern}\\.\\.\\.v9\\.8\\.7$`, "m"));
    assert.match(changelog, new RegExp(`^\\[${currentVersionPattern}\\]: https://github\\.com/Mohammed-Abdelhady/hyperflow/compare/v${previousVersionPattern}\\.\\.\\.v${currentVersionPattern}$`, "m"));
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});

test("natural-language routing preserves plan stop, build continuation, and push separation", () => {
  const kernel = read("skills/hyperflow/SKILL.md");
  const plan = read("skills/plan/SKILL.md");
  const dispatch = read("skills/dispatch/SKILL.md");
  const deploy = read("skills/deploy/SKILL.md");

  for (const signal of ["brainstorm", "explore", "what if", "should we", "unsure about"]) assert.match(kernel, new RegExp(signal, "i"));
  assert.match(plan, /plan-and-build[\s\S]{0,220}dispatch/i);
  assert.match(plan, /plan\/design\/explore\/decompose[\s\S]{0,120}stop/i);
  assert.match(dispatch, /explicit build or fix request authorizes local execution/i);
  assert.match(deploy, /Local completion never implies remote authorization/i);
  assert.match(deploy, /Push`?\s*\/\s*`?Hold/);
});

test("current Markdown documentation has no broken local links", () => {
  const documents = ["README.md", "PRIVACY.md", "RELEASING.md", ...filesUnder("docs").filter((path) => extname(path) === ".md")];
  for (const document of documents) {
    const source = read(document);
    for (const match of source.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
      const target = match[1].split("#", 1)[0];
      if (!target || /^(?:https?:|mailto:)/.test(target)) continue;
      assert.equal(existsSync(join(dirname(pathFromRoot(document)), decodeURIComponent(target))), true, `${document} -> ${target}`);
    }
  }
});
