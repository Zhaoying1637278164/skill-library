import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const packageJson = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"));

function run(script, args = []) {
  return execFileSync("node", [join(ROOT, "scripts", script), ...args], { cwd: ROOT, encoding: "utf8" });
}

function workflowFiles() {
  return readdirSync(join(ROOT, ".github", "workflows"))
    .filter((path) => /\.ya?ml$/.test(path))
    .map((path) => join(ROOT, ".github", "workflows", path));
}

test("maintainer gates are wired and pass in the current checkout", () => {
  assert.equal(packageJson.scripts["validate-plugin"], "node scripts/validate-plugin.mjs");
  assert.equal(packageJson.scripts.unittest, "node --test tests/*.test.js");
  assert.equal(packageJson.scripts.evals, "node scripts/run-evals.mjs");
  assert.match(run("validate-plugin.mjs"), /^PASS plugin-validation/m);
  assert.match(run("run-evals.mjs"), /\d+\/\d+ evals passed/);
});

test("eval harness supports listing and machine-readable output", () => {
  assert.match(run("run-evals.mjs", ["--list"]), /core-surface/);
  const output = JSON.parse(run("run-evals.mjs", ["--json"]));
  assert.equal(output.passed, output.total);
  assert.ok(output.total >= 3);
});

test("handoff eval covers the Markdown task pointer and Git refs", () => {
  const output = JSON.parse(run("run-evals.mjs", ["--json"]));
  const result = output.results.find((task) => task.id === "handoff-round-trip");
  assert.ok(result, "handoff round-trip eval must be registered");
  assert.equal(result.ok, true);
  assert.ok(result.checks.some((check) => check.spec.type === "handoff_round_trip"));
});

test("review-memory eval enforces accepted-only bounded audit pointers", () => {
  const output = JSON.parse(run("run-evals.mjs", ["--json"]));
  const result = output.results.find((task) => task.id === "review-memory");
  assert.ok(result, "review-memory eval must be registered");
  assert.equal(result.ok, true);
  assert.ok(result.checks.some((check) => check.spec.type === "review_memory"));
});

test("decision-memory eval enforces approved-only bounded task pointers", () => {
  const output = JSON.parse(run("run-evals.mjs", ["--json"]));
  const result = output.results.find((task) => task.id === "decision-memory");
  assert.ok(result, "decision-memory eval must be registered");
  assert.equal(result.ok, true);
  assert.ok(result.checks.some((check) => check.spec.type === "decision_memory"));
});

test("roadmap eval protects the monorepo workspace-boundary record", () => {
  const output = JSON.parse(run("run-evals.mjs", ["--json"]));
  const result = output.results.find((task) => task.id === "roadmap-contract");
  assert.ok(result, "roadmap contract eval must be registered");
  assert.equal(result.ok, true);
  assert.ok(result.checks.some((check) => check.spec.type === "workspace_boundary"));
});

test("GitHub workflows use Node 24-based action majors", () => {
  const workflows = workflowFiles().map((path) => readFileSync(path, "utf8")).join("\n");
  assert.match(workflows, /actions\/checkout@v7\b/);
  assert.match(workflows, /actions\/setup-node@v7\b/);
  assert.doesNotMatch(workflows, /actions\/(?:checkout|setup-node)@v[1-6](?:\b|\.)/);
});
