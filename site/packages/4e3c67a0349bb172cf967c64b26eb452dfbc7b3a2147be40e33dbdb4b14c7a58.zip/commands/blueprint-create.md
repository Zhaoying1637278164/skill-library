---
description: Create a complete product blueprint from the product foundation. Works section-by-section with the product owner to transform validated facts into concrete product design with hypothesis, flows, views, rules, and success metrics.
---

# Command: /waves:blueprint-create

> **Artifacts directory:** `waves_files/` is the canonical Waves artifacts directory (v3.1+). On an unmigrated project — no `waves_files/` but `ai_files/` exists — read every `waves_files/` path in this command as `ai_files/`, and suggest running `/waves:upgrade` once.

You are executing the waves blueprint creation command. Follow these instructions exactly.

## Multi-project scope

Apply the **Multi-project Path Resolution** helper from `plugin/skills/waves-protocol/SKILL.md` before any other step:

- Parse `--project <name>` from the command arguments.
- If present: set `base_path = projects/<name>/waves_files/` and validate that projects/<name>/ exists (abort with a "scope not found" error if it does not).
- If absent: set `base_path = waves_files/` (backwards-compatible default — identical to pre-3.x single-project behavior).

Use `base_path` for every `waves_files/...` reference in the steps below. When the steps say `waves_files/<artifact>` they mean `<base_path><artifact>` in multi-project mode.

When `--project` is present, also write the **session marker** via bash BEFORE any artifact operation — this is what makes the active scope visible to hooks (`plugin/hooks/_lib/scope-resolve.sh`) when they fire on subsequent Edit/Write:

```bash
mkdir -p "${CLAUDE_PLUGIN_DATA}/markers/${CLAUDE_SESSION_ID:-default}"
printf '%s=%s\n' "$(printf '%s' "$PWD" | { md5 -q 2>/dev/null || md5sum | awk '{print $1}'; })" "<scope_name>" \
  > "${CLAUDE_PLUGIN_DATA}/markers/${CLAUDE_SESSION_ID:-default}/active-scope"
```

Idempotent (overwrite-safe). The marker maps `<cwd_md5>=<scope_name>` so a session that traverses multiple cwds keeps one line per cwd. When `--project` is absent, **do not write** the marker — hooks fall back to root naturally.

## Your Role

You are the product architect. You consume the product foundation (validated facts from feasibility) and work with the product owner section-by-section to create a complete product blueprint. You propose, the owner validates. You do NOT fill sections speculatively — every section must be validated by the owner before proceeding.

**Key principle:** The foundation gives you WHAT was learned. Your job is to transform it into WHAT we build and WHY. Fields repeat from the foundation but at a higher specificity — the problem becomes a testable hypothesis, capabilities gain acceptance criteria, users become flow participants.

**Progressive refinement:** Foundation says "The user can publish a project" → Blueprint says "The user can publish a project with title, description, budget range, location, category, and up to 10 photos. Published projects are visible to all contractors in the matching category within the project's geographic area."

## Step -1: Prerequisites Check (CRITICAL)

**Multi-project note (root-only validation):** prerequisite artifacts (`user_pref.json`, `project_manifest.json`, `project_rules.json`, plus any required blueprint/roadmap) are validated at root (`waves_files/<artifact>`) regardless of whether the `--project <name>` flag is set. Scopes inherit root prerequisites. If a root prerequisite is missing in multi-project mode, abort with a message pointing to root setup (e.g., "Run /waves:project-init at root first — multi-project scopes inherit root prerequisites.") — NEVER to a per-scope path. The `base_path` from the Multi-project scope helper applies to WORK artifacts (logbooks, scoped rules/manifest/blueprint), not to prerequisite existence checks.

Check if `waves_files/user_pref.json` exists.
- If found: Extract `preferred_language` for all interactions AND `project_context.project_type` for terminology adaptation (see Step -0.5).
- If not found: EXIT with message: "user_pref.json not found. Please run /waves:project-init first."

**From this point, conduct ALL interactions in the user's preferred language.**

## Step -0.5: Agentic Terminology Adaptation (when project_type === "agentic")

The `product_blueprint_schema.json` is structurally agnostic and serves all three project types (software, general, agentic). The conceptual model — problem, target users, hypothesis, capabilities, flows, views, design principles, success metrics — applies to every product. **What changes for agentic projects is the semantic interpretation of certain fields, not the schema.**

IF `project_type === "agentic"`:

Apply the following conceptual mappings throughout the rest of this command. The blueprint JSON uses the same field names; only how you elicit and frame content with the owner changes:

| Standard field | Agentic interpretation |
|---|---|
| `essential_capabilities[]` | **subagent_capabilities**: what each subagent (or the system as a whole) is able to do for the owner — "the orchestrator can dispatch extraction across N parallel subagents", "the auditor can flag policy violations with structural citations", etc. Capabilities still capture WHAT the product enables; the unit of delivery is a subagent or skill, not a UI screen. |
| `user_flows[]` | **orchestration_patterns**: how subagents coordinate to deliver a capability — "ingestion flow: orchestrator dispatches browser_extractor → validator → indexer → state_updater, with verifier monitoring asynchronously". Steps describe role-to-role handoffs. |
| `system_flows[]` | **internal orchestration**: pipelines + state transitions internal to the system (often map 1:1 to pipelines declared in the agentic manifest). |
| `views[]` | **interaction surfaces**: where and how the owner converses with the primary agent — "Claude Desktop conversation", "Claude Code session", "CLI invocation". Most agentic projects have 1-3 views; some have zero (fully background). |
| `design_principles[]` | Apply IDENTICALLY — principles like SRP, separation of concerns, single-writer-per-file, deterministic state transitions, audit trails apply at agent boundaries the same way they apply at module boundaries in software. |
| `product_rules[]` | Apply IDENTICALLY — rules that constrain behavior (e.g. "never indexers write to browser-owned files", "all approval gates require structural citation in audit log"). |
| `success_metrics[]` | Apply with agentic-flavored metrics: throughput per role, audit pass rate, escape-hatch invocation count, end-to-end latency, cost per task. |

**Practical guidance for the elicitation:**
- When asking "what are the essential capabilities?", explicitly frame as "what can each subagent (or the system as a whole) DO for you?". Use real examples from agentic projects (corpus pipeline, customer ops hub, compliance center) if the owner needs unblocking.
- When asking "what are the user flows?", frame as "describe an end-to-end orchestration: which role starts, what artifact gets produced, who consumes it next, where does it terminate?".
- When asking "what are the views?", clarify that for agentic projects this may be just "owner talks to primary agent in Claude Code" — and that is valid.
- Cross-reference the agentic manifest's `roles[]`, `pipelines[]`, and `handoff_contracts[]` when discussing flows and capabilities — they are the source of truth for who-does-what.

IF `project_type !== "agentic"`: Skip this step entirely. Proceed as before — the terminology adaptation does not apply.

This step adds NO new fields to the blueprint schema. The output of `blueprint-create` for an agentic project is a `product_blueprint.json` that validates against the same `product_blueprint_schema.json` used by software and general projects.

## Step 0: Load Foundation & Validate Readiness

1. Check if `waves_files/foundation.json` exists
2. IF NOT EXISTS:
   - Check for `waves_files/feasibility.json`
   - If feasibility exists → EXIT: "Foundation not found. Run /waves:foundation-create first."
   - If nothing exists → EXIT: "No foundation or feasibility found. Run /waves:feasibility-analyze first."
3. IF EXISTS: Read completely into memory
4. Check `blueprint_readiness.ready`:
   - If `false`: Show blocking issues. Ask: "Proceed anyway? (Yes / No)"
   - If "No" → EXIT
5. Extract product name from `foundation.meta.product_name` (or use parameter)
6. Check if `waves_files/blueprint.json` already exists → warn if so
7. Optionally load `waves_files/feasibility.json` for deeper context if available
8. Load `waves_files/project_manifest.json` if exists (for tech stack context)

## Step 1: Set Blueprint Type & Owner

Ask the product owner:
```
📘 Blueprint creation for: [product_name]

Foundation: [evidence_strength] evidence, [N] essential capabilities, readiness: [status]

1. What type of product?
   a. Standard (app, platform, tool, service)
   b. Autonomous entity (AI coach, conversational agent, autonomous companion)

2. Who is the product owner validating decisions?
```

Store `blueprint_type` and `meta.owner`.

## Step 2: Problem (Foundation → Blueprint)

The foundation has `validated_problem` with enriched pain/reality/unsolved.

Present it and ask the owner:
```
📋 PROBLEM (from foundation, evidence: [strength])

🔴 PAIN: [foundation.validated_problem.pain]
📊 REALITY: [foundation.validated_problem.reality]
❓ UNSOLVED: [foundation.validated_problem.unsolved]

For the blueprint, you may sharpen or refine this.
Confirm as-is, or refine?
```

The blueprint version may be more specific — this is progressive refinement.
Store as `blueprint.problem`.

## Step 3: Target Users (Foundation → Blueprint)

Present foundation.target_users with their narrative descriptions.

Transform to blueprint format:
- Keep `id` and `description`
- Foundation details (persona_source, willingness_to_pay, acquisition_channel) stay in foundation for reference

Ask owner: "Confirm? Add user? Remove? Refine a description?"
Store as `blueprint.target_users[]`.

## Step 4: Product Hypothesis, Mission & Vision

**These are NEW in the blueprint — they don't exist in the foundation.**

Generate drafts from foundation data:

| Field | Draft source |
|-------|-------------|
| `product_hypothesis` | "[Product] will [solve validated_problem.pain] by [enabling essential_capabilities]" |
| `mission` | "With [Product], users [daily action from essential_capabilities + target_users]" |
| `vision` | "When fully realized, [Product] [end state from validated_problem.unsolved + revenue_model]" |

Present all three as drafts. The owner MUST validate and may rewrite completely.

Store `product_hypothesis`, `mission`, `vision`.

## Step 5: Out of Scope

Generate suggestions from:
- Foundation capabilities classified as `desired` → candidates for exclusion
- Foundation SWOT threats → things to not compete on
- Foundation remaining_unknowns with low impact → defer

Each exclusion should "hurt a little" — if it doesn't hurt, it's not a real boundary.

Present. Ask owner to confirm/add/remove.
Store as `blueprint.out_of_scope[]`.

## Step 6: Design Principles

Generate principles from foundation:

| Source | Principle type |
|--------|---------------|
| SWOT strengths | Principles that leverage advantages |
| SWOT threats | Principles that defend against risks |
| Top sensitivity variables | Principles that optimize key revenue drivers |
| Unfair advantages | Principles that protect differentiators |
| Positioning recommendation | Positioning/brand principle |

For each principle, generate 2-3 `rules_preview` items showing practical impact.

Present. Each principle must generate at least one product rule — if it doesn't, it's aspirational noise.

Ask owner to confirm/add/remove/modify.
Store as `blueprint.design_principles[]`.

## Step 7: Essential Capabilities (Foundation → Blueprint)

Transform foundation's essential capabilities (only `classification = "essential"`):
- Foundation format: `{ id: "CAP-001", content: "...", classification: "essential", ... }`
- Blueprint format: `{ id: 1, capability: "...", depends_on: [ids] }`

**Progressive refinement:** Foundation's "The user can [action]" becomes more specific in the blueprint. Add scope boundaries, specify what the capability covers AND what it does not.

**Details for complex capabilities:** When a capability includes multiple concrete characteristics (e.g., a dashboard with specific metrics, an editor with specific features), add a `details` array listing each characteristic. If the capability is simple enough that the description says it all, omit `details`.

Example (simple — no details needed):
- `{ "id": 1, "capability": "The user can authenticate via Magic Link email" }`

Example (complex — details expand what the capability includes):
- `{ "id": 5, "capability": "The user can see a dashboard with project progress and ecosystem health", "details": ["Progress bar per project from milestones achieved / total", "Per-wave progress breakdown", "Ecosystem average across all active projects", "Delivery velocity: milestones completed per week", "Filter by project name", "Version chips: production tag and main version"] }`

Present. Ask owner: "Confirm? Add? Remove? Refine? Add details to any capability?"
Store as `blueprint.essential_capabilities[]`.

## Step 8: Non-Essential Capabilities

Transform foundation capabilities classified as `important` and `desired`:
- `important[]` ← foundation classification "important"
- `desired[]` ← foundation classification "desired" + proactive_insights.differentiation_ideas

Apply same progressive refinement as essential. Include `details` for complex capabilities.

Present grouped. Ask for confirmation.
Store as `blueprint.non_essential_capabilities`.

## Step 9: Autonomous Entity Identity (ONLY if blueprint_type = "autonomous_entity")

IF `blueprint_type === "standard"` → SKIP entirely.

IF `blueprint_type === "autonomous_entity"`:

Work through 5 subsections WITH the owner (do NOT generate speculatively):

1. **Identity**: Who is the entity? Self-presentation, personality, foundational discourse.
2. **Voice**: Tone, style, phrases used/never used, context variations.
3. **Operation modes**: Behavioral modes (coaching, listening, alert...) and transition triggers.
4. **Operational limits**: Can do autonomously / needs rules / MUST NEVER do.
5. **Relationship evolution**: First contact → early use → sustained use → re-engagement.

For each, ask the owner directly. Present previous subsections as context for the next.

Store as `blueprint.autonomous_entity_identity`.

## Step 10: Essential Flows, Views & System Flows

**Expand foundation.essential_flows_draft into full blueprint flows:**

For each foundation flow:
1. Keep name, entry_point, termination
2. EXPAND description with step-by-step detail (happy path ONLY)
3. Map capability_refs to new blueprint capability IDs
4. Ask owner for wireframe/Figma references if available

**Generate views:** For each essential flow, identify screens the user sees:
- Each view in `success` state (data populated, no errors, no empty states)
- Describe: what the user sees + what actions are available
- Ask owner for visual references

**Generate system flows:** For each essential capability, identify invisible backend processes:
- trigger → result → description
- Only flows without which essential capabilities cannot function

Present all three (user_flows, views, system_flows).
Ask owner: "Confirm / Add / Modify / Remove"
Store as `blueprint.essential_flows_and_views`.

## Step 11: Secondary Flows, Views & System Flows

Generate from:
- Error handling for each essential flow
- Empty states for each essential view
- Edge cases from capability analysis
- Alternative success paths
- Error recovery system flows

Present. Ask owner to confirm/modify/add.
Store as `blueprint.secondary_flows_and_views`.

## Step 12: Product Rules (from Design Principles)

For each design_principle, generate concrete rules:
- Format: "If [condition], then [behavior]"
- Each rule: `id`, `rule`, `principle_refs[]`, `applies_to`
- Must be unambiguous — developer implements without asking

A principle without rules is noise. A rule without a principle is an orphan.

Present grouped by originating principle.
Ask owner to confirm. Iterate until done.
Store as `blueprint.product_rules[]`.

## Step 13: Success Metrics (Dual-Signal)

Generate from:
- Foundation revenue_targets → revenue metrics
- Foundation sensitivity variables → operational metrics
- Foundation kill_criteria → failure thresholds
- product_hypothesis → hypothesis validation metric

**EVERY metric MUST have both:**
- `success_signal`: How we know it works
- `failure_signal`: How we know it's failing (NOT optional)

Present. Ask owner to confirm/add/modify.
Store as `blueprint.success_metrics[]`.

## Step 14: Tech Stack

Check sources:
- `waves_files/project_manifest.json` → extract framework, language, infrastructure
- Owner knowledge

Ask owner:
```
🛠️ TECH STACK

[If manifest found:] From project: [framework, language, etc.]
[If not:] What technologies will this product use?

Include: languages, frameworks, infrastructure, cloud, integrations,
deployment targets (web/mobile/desktop), hard constraints.
```

Store as `blueprint.tech_stack` (prose string).

## Step 15: Initial Decisions & Open Questions

**Product decisions:** Record every decision made during blueprint creation:
- Blueprint type selection
- Tech stack choice
- Capability classifications
- Scope exclusions
- Design principle selections
- Each with: id, created_at, decision, context, impact_on

**Open questions:** Generate from:
- Foundation remaining_unknowns with high impact
- Unresolved ambiguities from blueprint creation
- Each with: id, created_at, question, status: "open"

Present both. Ask owner for additions.
Store as `blueprint.product_decisions[]` and `blueprint.open_questions[]`.

## Step 16: Generate & Save Blueprint JSON

1. Read schema from `${CLAUDE_PLUGIN_ROOT}/skills/waves-protocol/references/product_blueprint_schema.json`
2. Build complete JSON with ALL sections from Steps 1-15
3. Set `meta`:
   - `product_name`: from foundation
   - `product_codename`: ask if different (optional)
   - `owner`: from Step 1
   - `created_at`: current UTC ISO 8601
   - `last_updated`: current UTC ISO 8601
   - `blueprint_type`: from Step 1
4. Validate against schema
5. Write to `waves_files/blueprint.json`

## Step 17: Summary

```
✅ Product Blueprint created!

📁 File: waves_files/blueprint.json

📊 Summary:
• Product: [name] ([type])
• Owner: [owner]
• Essential capabilities: [N]
• Non-essential: [N] important + [N] desired
• Flows: [N] essential user + [N] essential views + [N] essential system
        [N] secondary user + [N] secondary views + [N] secondary system
• Design principles: [N] → Product rules: [N]
• Success metrics: [N] (all dual-signal)
• Decisions: [N] | Open questions: [N]

🎯 Next step:
  /waves:roadmap-create [product-name]

  The roadmap will use this blueprint to plan development phases,
  with full context of capabilities, flows, and business rules.
```

---

## Subagents

This command does NOT use subagents. All steps are executed directly by the main agent to preserve full context from the foundation and ensure consistent cross-referencing between all blueprint sections. The agent needs to remember every capability ID, principle reference, and flow when generating rules and metrics — this requires single-agent context.

END OF COMMAND
