# Detailed pitfalls and edge cases

The high-frequency pitfalls are in `SKILL.md` (§ Pitfalls and conventions). This file covers detailed edge cases. Read it when something looks unusual or you're hitting an error pattern not covered in the main skill.

---

## E1 — "Document not found" when resolving a project brief

**Symptom.** `marcora:update_project(project_brief_id=<bad-uuid>)` returns `"Document not found"`.

**Cause.** The UUID doesn't match any content document in the team, and this is the error that comes back.

**What to do.** Verify the UUID. Common mistakes:
- Pasting a `project_id` where a content UUID was expected.
- Pasting a project document's numeric id instead of a content UUID.

---

## E2 — `get_relevant_context` returns chunks, not full items

**Symptom.** You expected a complete document and got a few hundred words.

**Cause.** `marcora:get_relevant_context` returns RAG chunks (typically a few hundred words each) plus a `sources[]` array — one entry per parent item, each with its `context_item_id` and a `link_url`.

**What to do.** For the full body of a surfaced item, call `marcora:get_context_item(context_item_id)` (take the ID from `sources[]`), or hand the user the source's `link_url` to open it in the Marcora app. For most "what context exists about X?" questions, the chunks themselves are sufficient.

---

## E2b — The project brief isn't among the chunks

**Symptom.** You searched a project with `get_relevant_context(project_id=…)` and none of the chunks come from the project's brief.

**Cause.** The brief is a Content document, not a context item, so relevancy search never indexes it. It reaches you as a separate `project_brief` block instead — on the first call for that project (`include_project_brief` defaults to `true`), or from `get_project`.

**What to do.** Read the `project_brief` block (and `get_content` when `truncated` is `true`). If you passed `include_project_brief: false` and don't have the brief yet, call again without it, or call `get_project`.

---

## E3 — Pagination for `get_relevant_context`

**Symptom.** Repeating a `get_relevant_context` call returns the same chunks.

**Cause.** Without pagination, every call returns the top-N most relevant chunks — same set.

**What to do.** Pass `context_rag_ids` (the IDs returned in the previous call) to exclude already-seen chunks. Effectively paginates.

---

## E4 — Project context items are included verbatim — no relevancy filtering

**Symptom.** A project with many large context items has slow generations or hits limits.

**Cause.** Project context items (Layer 3) are included in full during in-project generations — no relevancy scoring, unlike Reference Library (Layer 2).

**What to do.** Suggest the user prune project context to items still relevant to the initiative. Universally-useful items belong in the Reference Library (top-level) instead.

---

## E5 — Content `category_id` doesn't change generation behavior

**Symptom.** User expects setting a category to affect output style. It doesn't.

**Cause.** `category_id` is purely organizational — helps the user find content later. Generation behavior is shaped by the blueprint (if any), `instructions`, context layers, and targeting dimensions.

**What to do.** Don't promise category-driven generation differences. If the user wants category-style output, recommend a blueprint instead.

---

## E6 — `import_community_blueprint` requires the exchange ID, not a blueprint UUID

**Symptom.** Import fails with an invalid ID error.

**Cause.** `marcora:list_community_blueprints` returns items with their own `blueprint_exchange_id` — distinct from a regular blueprint UUID. Use that exchange ID for `get_community_blueprint_details` and `import_community_blueprint`. The imported blueprint then has a fresh team-level UUID.

---

## E7 — A private document as a project brief

When `update_project` sets a private Content item as a project's brief, Marcora automatically makes it visible to the project's members. You don't need to change its privacy yourself.

---

## E8 — Project document `purpose` field

`marcora:get_project` returns documents with a `purpose` field:
- `core_output` — the project's main work product
- `supporting` — background material (the brief defaults to this)

Most agents don't need to set or change `purpose` — it's surfaced for the UI. Treat it as informational. There's no MCP tool to change it.

**Don't use `purpose` to find the brief.** The brief's entry carries `is_project_brief: true` and is sorted first in `documents`; `get_project` also returns it separately as the top-level `project_brief` block. Use those.

---

## E10 — Surface human-readable identifiers, not UUIDs

Don't show the user a UUID like `7b2c4f...` as an identifier. Surface the human-readable name + the `link_url` instead. UUIDs are for tool calls, not user-facing references.

---

## E11 — `convert_markdown_to_word_doc` doesn't auto-fetch by ID

**Symptom.** Calling the conversion tool with a content ID instead of markdown content fails.

**Cause.** This tool takes `markdown_content` as a parameter — it does not pull content by ID.

**What to do.** Two-step: `marcora:get_content(content_id)` → `marcora:convert_markdown_to_word_doc(markdown_content=...)`. Optionally pass `document_url` (the original content's `link_url`) so the .docx footer links back.

---

## E12 — `check_content_grounding` with `content` + `content_id` overwrites the whole document

**Symptom.** You ground "just this paragraph" of an existing document, and the rest of the document is gone.

**Cause.** `content` combined with `content_id` is a **full-body replacement**, identical to `update_content`. It is not a partial or fragment check. Whatever you pass in `content` becomes the entire document.

**What to do.** To check part of an existing document, pass **`content_id` alone** — the scan reads the document as it currently stands. Only pass `content` alongside `content_id` when you genuinely intend to replace the document, and then pass the **full revised document**, never an excerpt.

---

## E13 — Polling grounding with `content_id` returns the previous scan

**Symptom.** `check_content_grounding` returned `running`; you poll with the `content_id` and immediately get `status: "complete"` — but the findings are from an earlier scan.

**Cause.** `get_grounding_result` with a `content_id` and no `scan_id` returns the latest **completed** grounding, deliberately skipping a scan that is still in flight. During your scan, the latest completed one is the *previous* result.

**What to do.** Poll with the **`scan_id`** that `check_content_grounding` returned. That reads the exact run you started, whatever its status. Reserve the `content_id` form for "what is this document's grounding state right now", when nothing is running.

---

## E14 — A brand-new account answers every tool with "setup underway"

**Symptom.** Every tool you call — any tool — comes back with "Your Marcora account setup is still underway. We are importing your top web pages right now to build your context. Please try again in a few minutes.", sometimes with a progress suffix like `(3 of 7 setup steps complete.)`. Nothing errors; the server lists all its tools normally.

**Cause.** The account was created recently and its context is still being built. While a new account is still being set up, tools reply with this "setup underway" message instead of doing the work. That is expected, not an error, and the connection itself is healthy — which is why the integration looks fine while no tool does anything.

**What to do.** Tell the user setup is still running and try again in a few minutes — the progress suffix advances, so re-calling is a reasonable way to watch it. Do **not** treat it as a tool failure, do **not** retry in a tight loop, and do **not** suggest reconnecting the server or signing up again — a second signup splits their context across two accounts. If it persists beyond about an hour, setup has stalled rather than being slow: tell them to contact support.

---

## E15 — Telling the user a workflow "is running" when it isn't

**Symptom.** You create a workflow, set it Active, and tell the user it's live — and nothing ever runs on its schedule. Or the user asks to "pause" a workflow and `update_workflow status:"paused"` is refused.

**Cause.** A workflow has two independent switches. The workflow is **Active** or **Inactive**; its schedule is **On** or **Paused**. Scheduled runs need both — Active **and** On. `create_workflow` saves the workflow Inactive and every schedule Paused, and no MCP tool can turn a schedule On: only the user can, in the app, with **Resume schedule**. There is no `paused` workflow status; `status` accepts only `active`, `inactive` and `archived`.

**What to do.** Read `next_step` (from `create_workflow` / `update_workflow`) or `run_state` (from `get_workflow`) and lead your reply with it — it is computed from what was actually saved. Whenever you say a workflow is Active, say in the same sentence whether its schedule is On, Paused, or absent. If the schedule is Paused, hand the user the workflow's `link_url` exactly as returned and ask them to click **Resume schedule**. To stop scheduled runs but keep manual runs, the user pauses the schedule in the app; to stop everything, set the workflow `inactive`.

---

## Linking the user to their Brand Foundation

**Symptom.** You update the user's Brand Foundation, link them to it, and the link 404s — they land on `/home` and the conversation they were in is gone.

**Cause.** Guessing the URL. `https://app.marcora.ai/brand-foundation` reads like the obvious route but does not exist. Brand Foundation is a tab of the Context Hub, not a page of its own.

**What to do.** Use the `link_url` that `update_brand_foundation` and `get_brand_foundation` return, exactly as returned — it points at `/context-hub?tab=brand-foundation`. This holds generally: every Marcora tool that returns a `link_url` returns the correct one. Never assemble a Marcora URL from a pattern you inferred.

---

## When you encounter something not in this list

1. Surface the raw error to the user — don't silently retry.
2. State what you tried and what came back.
3. Suggest plausible next steps (verify a parameter, retry, reconnect).
4. Don't assume a workaround that creates the wrong artifact in the wrong place — confirm with the user first.
