import path from "node:path";
import { getLang, t } from "./i18n.ts";
import { formatDateTime, formatFullDateTime, formatRemaining } from "./time.ts";
import type { Limit, Snapshot } from "./types.ts";

const PROVIDER_NAME = { claude: "Claude", codex: "Codex" } as const;
const PROVIDER_ORDER = { claude: 0, codex: 1 } as const;
/** 別枠のリセット日時が全体の週間枠とこれ以上ずれていれば別に表示する */
const SAME_RESET_TOLERANCE_MS = 5 * 60_000;
const BAR_CELLS = 10;

export type ReportInput = {
  fresh: Snapshot[];
  /** 今回は取得できず、前回値を表示するアカウント */
  cached: Snapshot[];
  /** 表示しなかったフォルダと理由（未ログイン等） */
  excluded: string[];
  problems: string[];
  /** 表のあとに出す「ひとこと」1 行（commentary.ts） */
  comment?: string;
  now: Date;
  host: string;
  timeZone: string;
};

export function remainingPercent(usedPercent: number): number {
  return Math.max(0, Math.min(100, Math.round(100 - usedPercent)));
}

/**
 * 残りを 10 マスの棒で表す。わずかでも残っていれば 1 マスは塗り、少しでも使っていれば満タンにしない
 * （0 と 100 の見た目は本当に 0% / 100% のときだけ）。
 */
export function indicator(remainingPct: number): string {
  let filled = Math.round(remainingPct / (100 / BAR_CELLS));
  if (remainingPct > 0) filled = Math.max(filled, 1);
  if (remainingPct < 100) filled = Math.min(filled, BAR_CELLS - 1);
  return "█".repeat(filled) + "░".repeat(BAR_CELLS - filled);
}

function percentText(r: number): string {
  return r < 20 ? `**${r}%**` : `${r}%`;
}

function paren(s: string): string {
  return getLang() === "ja" ? `（${s}）` : ` (${s})`;
}

function remaining(limit: Limit): string {
  return percentText(remainingPercent(limit.usedPercent));
}

/** 週間 残りの列。キャッシュも最後の取得値を表示し、回復を推測しない。 */
function weeklyRemaining(limit: Limit): string {
  const r = remainingPercent(limit.usedPercent);
  return `${indicator(r)} ${percentText(r)}`;
}

function resetText(limit: Limit, now: Date, timeZone: string): string {
  if (!limit.resetsAt) return t("notStarted");
  if (limit.resetsAt <= now) return t("resetDone", { time: formatDateTime(limit.resetsAt, timeZone) });
  return `${formatDateTime(limit.resetsAt, timeZone)}${paren(formatRemaining(now, limit.resetsAt))}`;
}

/** Fable などモデル別の週間枠。リセット日時が全体の週間枠と同じなら省く */
function scopedCell(s: Snapshot, weekly: Limit | undefined, now: Date, timeZone: string): string {
  const scoped = s.limits.filter((l) => l.kind === "scoped");
  if (scoped.length === 0) return "—";
  return scoped
    .map((l) => {
      const sameReset =
        l.resetsAt &&
        weekly?.resetsAt &&
        Math.abs(l.resetsAt.getTime() - weekly.resetsAt.getTime()) < SAME_RESET_TOLERANCE_MS;
      const when = !l.resetsAt
        ? t("notStarted")
        : l.resetsAt <= now
          ? t("resetPassedShort")
          : t("resetAt", { time: formatDateTime(l.resetsAt, timeZone) });
      return `${l.scope ?? "?"} ${remaining(l)}${sameReset ? "" : paren(when)}`;
    })
    .join(getLang() === "ja" ? "、" : ", ");
}

/** 5 時間枠など週間より短い枠 */
function shortTermCell(s: Snapshot, now: Date, timeZone: string): string {
  const short = s.limits.filter((l) => l.kind === "short");
  if (short.length === 0) return "—";
  return short
    .map((l) => {
      const when = !l.resetsAt
        ? t("notStarted")
        : l.resetsAt <= now
          ? t("resetDoneShort")
          : formatDateTime(l.resetsAt, timeZone);
      return `${t("hoursWindow", { h: l.windowHours ?? "?" })} ${remaining(l)}${paren(when)}`;
    })
    .join(getLang() === "ja" ? "、" : ", ");
}

/** 付与の名前は長い（例: "Claude Opus 5.5 launch: one usage-limit reset for Team members"）ので「:」より前だけ出す */
function shortTitle(title: string): string | undefined {
  if (title === "Full reset" || title === "reset") return undefined;
  const head = title.split(":")[0].trim();
  return head.length > 40 ? `${head.slice(0, 39)}…` : head;
}

function creditsCell(s: Snapshot, now: Date, timeZone: string): string {
  if (s.resetCreditsOff) return t("bankedUnsupported"); // 0 件と区別できるよう「—」だけにしない
  if (!s.resetCredits) return t("bankedNotFetched");
  const { items, available, note } = s.resetCredits;
  const usable = items.filter((i) => !i.expiresAt || i.expiresAt > now);
  // 前回値では失効済みのものを数えない。明細が無い場合はサーバーの保有数を使う
  const count = items.length > 0 ? usable.reduce((sum, i) => sum + i.count, 0) : available;
  if (count === 0) return note ? `0${paren(note)}` : "0";
  const details = usable.map((i) =>
    [
      shortTitle(i.title),
      usable.length > 1 && i.count > 1 ? t("bankedTimes", { n: i.count }) : undefined,
      i.startsAt && i.startsAt > now ? t("startsFrom", { time: formatDateTime(i.startsAt, timeZone) }) : undefined,
      i.expiresAt ? t("expires", { time: formatDateTime(i.expiresAt, timeZone) }) : t("noExpiry"),
      i.paused ? t("paused") : undefined,
    ]
      .filter(Boolean)
      .join(" · "),
  );
  const total = t("bankedCount", { n: count });
  return details.length > 0 ? `${total}${paren(details.join(getLang() === "ja" ? "、" : "; "))}` : total;
}

function accountCell(s: Snapshot, stale: boolean, timeZone: string): string {
  const detail = [s.plan, s.sources.map((p) => path.basename(p)).join(" / ")].filter(Boolean).join(" · ");
  const staleNote = stale ? ` 〔${t("staleAt", { time: formatDateTime(s.fetchedAt, timeZone) })}〕` : "";
  return `${s.email}${paren(detail)}${staleNote}`;
}

/**
 * 週間リセットの近い順（サービスをまたいで並べる）。リセット日時が未定の行と、
 * 前回値でリセット日時を過ぎた行（次のリセットが分からない）は最後に回す。
 */
function sortKey(s: Snapshot, now: Date): [number, number, string] {
  const reset = s.limits.find((l) => l.kind === "weekly")?.resetsAt;
  const upcoming = reset && reset > now ? reset.getTime() : Number.POSITIVE_INFINITY;
  return [upcoming, PROVIDER_ORDER[s.provider], s.email];
}

function compare(a: [number, number, string], b: [number, number, string]): number {
  return a[0] - b[0] || a[1] - b[1] || a[2].localeCompare(b[2]);
}

/** 表の中身。Markdown（renderReport）とターミナル（terminal.ts）が同じものを描く */
export type ReportModel = {
  title: string;
  headers: string[];
  /** 1 アカウント 1 行。残りが少ない値は **…** で囲む */
  rows: string[][];
  comment?: string;
  notes: string[];
};

/** 取得結果を表の中身にする。1 アカウント 1 行で、Fable 等の別枠と短期枠は専用の列に出す */
export function buildReport(input: ReportInput): ReportModel {
  const { now, timeZone } = input;
  const entries = [
    ...input.fresh.map((s) => ({ s, stale: false })),
    ...input.cached.map((s) => ({ s, stale: true })),
  ].sort((a, b) => compare(sortKey(a.s, now), sortKey(b.s, now)));

  const rows = entries.map(({ s, stale }) => {
    const weekly = s.limits.find((l) => l.kind === "weekly");
    return [
      weekly ? resetText(weekly, now, timeZone) : "—",
      PROVIDER_NAME[s.provider],
      accountCell(s, stale, timeZone),
      weekly ? weeklyRemaining(weekly) : "—",
      scopedCell(s, weekly, now, timeZone),
      shortTermCell(s, now, timeZone),
      creditsCell(s, now, timeZone),
    ];
  });

  const notes: string[] = [];
  if (input.cached.length > 0) notes.push(t("noteStale"));
  if (entries.some((r) => !r.s.resetCredits && !r.s.resetCreditsOff)) notes.push(t("noteNotFetched"));
  if (entries.some((r) => r.s.resetCreditsOff)) notes.push(t("noteBankedOff"));
  if (input.excluded.length > 0) notes.push(t("noteExcluded", { list: input.excluded.join(getLang() === "ja" ? "、" : ", ") }));
  for (const p of input.problems) notes.push(t("noteFailed", { detail: p }));

  return {
    title: t("title", { time: formatFullDateTime(now, timeZone), host: input.host }),
    headers: [t("hReset"), t("hService"), t("hAccount"), t("hWeekly"), t("hScoped"), t("hShort"), t("hBanked")],
    rows,
    comment: input.comment,
    notes,
  };
}

/** 表の中身を Markdown にする（スキルとして動くとき、出力先がターミナルでないとき） */
export function renderMarkdown(model: ReportModel): string {
  const { headers } = model;
  const lines = [`### ${model.title}`, "", `| ${headers.join(" | ")} |`, `|${headers.map(() => "---").join("|")}|`];
  for (const cells of model.rows) lines.push(`| ${cells.join(" | ")} |`);
  if (model.rows.length === 0) lines.push(`| — | — | ${t("noAccounts")} | | | | |`);
  if (model.comment) lines.push("", `> 💬 ${model.comment}`);
  if (model.notes.length > 0) lines.push("", ...model.notes.map((n) => `- ${n}`));
  return lines.join("\n");
}

/** 取得結果を Markdown の表にする */
export function renderReport(input: ReportInput): string {
  return renderMarkdown(buildReport(input));
}
