# Subscriber API contract

Validated September 2026 against a publication with a custom domain using the
existing session-cookie client. These are unofficial endpoints and can change.

## Read

`POST /api/v1/subscriber-stats` accepts `{filters, limit, offset}`. Exact email
lookup uses `filters.user_email_address_string_is`; a top-level search is not
equivalent. The MCP checks returned addresses and counts, failing closed if a
filter appears ignored. Live exact-email queries against a publication with
over a thousand subscribers returned filtered `count: 1` for a listed address
and `count: 0` for an absent one. Both paths were exercised through the built
MCP tools. Pages are bounded to 50 records and default to 10.

Case behavior was also checked live: a mixed-case stored address matched both
its original spelling and a lower-case query, and an upper-case query matched
another existing member. The exact filter is case-insensitive in these checks.

The response includes `subscribers`, `count`, and a potentially stale
`lastSync`. Membership is established by an exact row with a subscription ID.
The field `is_subscribed` represents paid-content access, **not** free newsletter
membership, and is intentionally omitted from tool output.

### Segmentation

`search_subscribers` performs one authenticated, read-only subscriber-stats request per page. It accepts a 1–50 row `limit` (default 10), `offset`, `subscription_types` (`free`, `paid`, `comp`), activity rating bounds (0–5), creation-date bounds (`YYYY-MM-DD`), a trimmed name/email `search` term, and `sort` (`created_desc` by default, `created_asc`, `activity_desc`, `activity_asc`). `created_on_or_after` maps to Substack's `subscription_created_at_gte`. `created_before` maps to `subscription_created_at_is_on_or_before` and means **created before the start of this date**. This upper bound is exclusive; Substack's day boundary timezone is not verified. The two dates must satisfy `created_on_or_after < created_before`. Returned timestamps are checked as instants with up to 14 hours of timezone slack around each UTC date boundary. Filters and sorting run on Substack's side. The result echoes `applied_filters`, `total_matching`, `returned`, `has_more` and `next_offset`. `total_matching` is Substack's count at read time; dashboard data can lag writes and pages are not a snapshot.

The default row includes only email, subscription ID and interval. Request `include` groups to add `activity_rating`, `created_at`, `flags` (comp, founding, gift, free trial), or `revenue`. Included fields can be `null`; if a requested filter needs a null field to check a returned row, the tool reports `filter_not_honored`. Names, photos, user IDs, chart counts, imports and batch actions are never returned. The tool rejects upstream HTTP 400 as `filter_rejected`, malformed or oversized responses, and checkable rows that contradict requested filters as `filter_not_honored`. Invalid dates and inverted ranges return `invalid_input` with the affected field names before any request. Search matching is Substack's filtering claim. Free-only and free-excluding results are checked against the returned subscription interval; comp membership is checked where the requested types make it decidable. `list_subscribers` and exact-email `get_subscriber` keep their original contracts.

Live checks on 2026-09-23 verified the `free`, `paid`, `comp`, `free+paid`, and `paid+comp` type selections. `free+paid` returned the sum of the separate free and paid counts; a free-only type array matched the free scalar filter. Free rows had interval `free`, and paid rows did not. Among 500 scanned rows, activity rating, creation time, revenue, and the four flags were never null. Observed timestamps used nine fractional digits and a `+00:00` offset. A subscriber created at or after 08:00 UTC on date D was excluded by the upstream “on or before D” filter; the upstream `gte: D` filter returned rows with UTC dates on or after D. These observations do not establish Substack's day boundary timezone.

## Write

`POST /api/v1/subscriber/add` uses:

```json
{"email":"reader@example.org","subscription":false,"sendEmail":false}
```

`send_welcome_email` defaults to false in the MCP tool. Set it to true to send
`sendEmail: true` for a new live addition. Existing members and dry runs never
request an email. Membership verification does not establish email delivery; an
uncertain request must not be repeated merely to resend the welcome email.

The field names are shown in the publisher's [working request screenshots](https://substack.com/@huryn/note/c-181571328).

A real opted-in address absent from the membership query received HTTP 400:
`No valid emails found. This could be because an email previously unsubscribed.`
The tool reports `blocked`; it does not infer that an unsubscribe definitely
occurred, attempt another endpoint, or offer a force-resubscribe option.

Three earlier UI additions were reconciled through exact API lookups. The
dashboard had initially not shown them. This establishes why immediate absence
is not a failed-write signal. The new add tool's successful-write sequence is
covered with mocked API responses; production verification must state separately
which paths were exercised live. No invented subscriber is added as a test.

## Automation contract

Only an explicit newsletter opt-in authorizes an addition. A booking or contact
address by itself does not. For calendar integrations, bind the answer to the
`Booked by` email, use the latest answer per address, and exclude negative,
ambiguous, or already-subscribed answers. A later booking No blocks a new add;
it is not an instruction to remove an existing subscriber.

Live adds require `consent_evidence` containing a nonempty `source` reference
and an ISO `recorded_at` timestamp. The tool echoes this attestation and the
publication key for caller audit logs; it cannot independently authenticate a
caller's evidence. Retain the underlying record privately.

Persist an attempt before calling a live add, keyed by publication and email.
Unknown outcomes require read-only reconciliation, including after a process
crash. Do not use inbox/unread status as processing state: booking notices may
already be archived. Never use approximate audience counts to verify an add.
