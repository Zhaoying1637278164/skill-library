import { readFileSync } from 'node:fs';

const readJson = (path) => JSON.parse(readFileSync(path, 'utf8'));
const pkg = readJson('package.json');
const lock = readJson('package-lock.json');
const server = readJson('server.json');
const plugin = readJson('.codex-plugin/plugin.json');
const mcp = readJson('.mcp.json');
const claude = readJson('.claude-plugin/plugin.json');
const marketplace = readJson('.claude-plugin/marketplace.json');
const containerGuide = readFileSync('docs/containers.md', 'utf8');
const containerTags = [...containerGuide.matchAll(/ghcr\.io\/conorbronsdon\/substack-mcp:([0-9][^\s]*)/g)];

const errors = [];
const requireEqual = (source, actual, expected) => {
  if (actual !== expected) {
    errors.push(`${source}: ${actual ?? '<missing>'} (expected ${expected})`);
  }
};

if (typeof pkg.version !== 'string' || pkg.version.length === 0) {
  errors.push('package.json version is missing');
}
if (typeof pkg.name !== 'string' || pkg.name.length === 0) {
  errors.push('package.json name is missing');
}
if (typeof pkg.mcpName !== 'string' || pkg.mcpName.length === 0) {
  errors.push('package.json mcpName is missing');
}

if (typeof server.description !== 'string' || server.description.length < 1 || server.description.length > 100) {
  errors.push('server.json description must contain 1-100 characters (MCP Registry schema)');
}

requireEqual('package-lock.json version', lock.version, pkg.version);
requireEqual('package-lock.json name', lock.name, pkg.name);
requireEqual('package-lock.json root version', lock.packages?.['']?.version, pkg.version);
requireEqual('package-lock.json root name', lock.packages?.['']?.name, pkg.name);
requireEqual('server.json version', server.version, pkg.version);
requireEqual('server.json name', server.name, pkg.mcpName);
requireEqual('.codex-plugin/plugin.json version', plugin.version, pkg.version);
requireEqual('.claude-plugin/plugin.json version', claude.version, pkg.version);
requireEqual('.claude-plugin/plugin.json name', claude.name, plugin.name);
requireEqual('.claude-plugin/marketplace.json version', marketplace.plugins?.[0]?.version, pkg.version);
requireEqual('.claude-plugin/marketplace.json name', marketplace.plugins?.[0]?.name, plugin.name);
requireEqual('.claude-plugin/marketplace.json source', marketplace.plugins?.[0]?.source, './');
requireEqual('.mcp.json launcher', JSON.stringify(mcp.mcpServers?.substack?.args),
  JSON.stringify(['-y', `${pkg.name}@${pkg.version}`]));
requireEqual('docs/containers.md current image example count', containerTags.length, 3);
containerTags.forEach((match, index) => {
  requireEqual(`docs/containers.md image example ${index + 1}`, match[1], pkg.version);
});

if (!Array.isArray(server.packages) || server.packages.length === 0) {
  errors.push('server.json packages must contain at least one package');
} else {
  server.packages.forEach((entry, index) => {
    requireEqual(`server.json packages[${index}] version`, entry.version, pkg.version);
    if (entry.registryType === 'npm') {
      requireEqual(`server.json packages[${index}] identifier`, entry.identifier, pkg.name);
    }
  });
}

if (errors.length > 0) {
  console.error('Release metadata is inconsistent:');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`Release metadata agrees for ${pkg.name}@${pkg.version}.`);
