// Synthetic transport checks. No live publication or credentials are used.
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import net from 'node:net';
import { randomUUID } from 'node:crypto';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import pkg from '../package.json' with { type: 'json' };
import { assertExpectedTools } from './expected-tools.mjs';
import { waitForHealth } from './container-readiness.mjs';

const [image, revision] = process.argv.slice(2);
assert.ok(image && !image.startsWith('-'), 'Provide a Docker image reference');
assert.match(revision ?? '', /^[a-f0-9]{40}$/, 'Provide the source commit SHA');
const docker = (...args) => execFileSync('docker', args, { encoding: 'utf8', timeout: 60000, maxBuffer: 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
const info = JSON.parse(docker('image', 'inspect', image))[0];
assert.equal(info.Config.User, 'node');
for (const [key, value] of Object.entries({ version: pkg.version, revision, source: 'https://github.com/conorbronsdon/substack-mcp', licenses: 'MIT' })) {
  assert.equal(info.Config.Labels[`org.opencontainers.image.${key}`], value);
}
const env = ['-e', 'SUBSTACK_PUBLICATION_URL=https://example.invalid', '-e', 'SUBSTACK_SESSION_TOKEN=example-container-token', '-e', 'SUBSTACK_USER_ID=1', '-e', 'SUBSTACK_REQUEST_TIMEOUT_MS=1000'];
const status = JSON.parse(docker('run', '--rm', '--network', 'none', ...env, '--entrypoint', 'node', image, 'dist/index.js', 'status', '--json'));
assert.equal(status.version, pkg.version);
const catalog = async client => {
  assert.equal(client.getServerVersion().version, pkg.version);
  const { tools } = await client.listTools();
  assertExpectedTools(tools);
};
const prefix = `substack-smoke-${randomUUID()}`;
let stdio, http;
try {
  stdio = new Client({ name: 'container-stdio-check', version: '1' });
  await stdio.connect(new StdioClientTransport({ command: 'docker', args: ['run', '--name', `${prefix}-stdio`, '-i', '--rm', '--network', 'none', ...env, image], stderr: 'pipe' }));
  await catalog(stdio);
  await stdio.close(); stdio = undefined;
  const reservation = net.createServer();
  await new Promise(resolve => reservation.listen(0, '127.0.0.1', resolve));
  const port = reservation.address().port;
  await new Promise((resolve, reject) => reservation.close(error => error ? reject(error) : resolve()));
  // If another process takes the port, Docker fails; no alternate interface is used.
  docker('run', '-d', '--name', `${prefix}-http`, '--rm', '-p', `127.0.0.1:${port}:8080`, ...env,
    '-e', 'MCP_TRANSPORT=http', '-e', 'MCP_HTTP_HOST=0.0.0.0', '-e', 'MCP_HTTP_TOKEN=example-http-token',
    '-e', `MCP_HTTP_ALLOWED_HOSTS=127.0.0.1:${port}`, image);
  const url = new URL(`http://127.0.0.1:${port}/mcp`);
  const headers = { Authorization: 'Bearer example-http-token' };
  await waitForHealth(url, headers);
  for (const authorization of [undefined, 'Bearer example-wrong-token']) {
    const response = await fetch(url, { method: 'POST', headers: authorization ? { Authorization: authorization } : {}, signal: AbortSignal.timeout(3000) });
    assert.equal(response.status, 401); await response.arrayBuffer();
  }
  http = new Client({ name: 'container-http-check', version: '1' });
  await http.connect(new StreamableHTTPClientTransport(url, { requestInit: { headers } }));
  await catalog(http);
  console.log(JSON.stringify({ version: pkg.version, revision, user: 'node', stdio: true, authenticated_http: true, rejects_missing_and_wrong_bearer: true, live_api: false }));
} finally {
  await http?.close().catch(() => {}); await stdio?.close().catch(() => {});
  for (const suffix of ['stdio', 'http']) { try { docker('rm', '-f', `${prefix}-${suffix}`); } catch { /* already removed */ } }
}
