/**
 * Resolve credentials for one or more Substack publications.
 *
 * - No `SUBSTACK_PUB_<KEY>_*` vars present: falls back to the existing
 *   single-publication `resolveCredentials()` (plain `SUBSTACK_*` env vars,
 *   with the stored-session fallback), wrapped as a single internal entry.
 *   This is the zero-touch path every existing single-publication deployment
 *   stays on — no `publication` field is ever added to a tool's schema in
 *   this case (see server.ts).
 * - One or more `SUBSTACK_PUB_<KEY>_*` vars present: one entry per triplet,
 *   keyed by a slugified `<KEY>` (e.g. `KEVIN_MULDOON` becomes
 *   `kevin-muldoon`). An incomplete triplet throws at startup — this is new,
 *   explicitly opt-in config, so a partial triplet is almost certainly a typo,
 *   not something to silently drop. Legacy unprefixed vars are ignored (with a
 *   warning) in this mode, rather than treated as an implicit unnamed extra
 *   publication.
 *
 * ## Why a variable's *name* is what establishes intent
 *
 * The rule here is that a matching variable name creates the group, before its
 * value is looked at. Skipping empty values instead — `if (!value) continue` —
 * makes an all-empty triplet vanish, and a vanished group is not an error, it
 * is a different configuration:
 *
 * - All-empty triplet on its own: no groups remain, so resolution falls back to
 *   the legacy path and can pick up a *stored browser-login session* the
 *   operator never intended this process to use.
 * - Valid A plus an all-empty B: one group remains, the server decides it is in
 *   single-publication mode, every tool loses its `publication` parameter, and
 *   a call meant for B routes silently to A. `create_note` publishes
 *   immediately and cannot be undone, so that is an uncorrectable mistake.
 *
 * Both were reachable at eaa84bb. Creating the group first turns each into a
 * startup error naming the offending key.
 *
 * Slug collisions are an error for the same reason: `SUBSTACK_PUB_ALPHA_*` and
 * `SUBSTACK_PUB_Alpha_*` are two distinct variables on a POSIX host but one
 * slug, so last-writer-wins would silently merge two publications — and can
 * pair one publication's URL with another's session cookie, per field, in
 * whatever order the environment happens to enumerate.
 *
 * SUBSTACK_PROFILES explicitly selects stored named sessions and rejects any
 * simultaneous publication credential variables. Missing or invalid selected
 * profiles fail closed; stored profiles are never activated by discovery.
 */
import { resolveCredentials, type ResolvedCredentials } from "./resolve-credentials.js";
import { loadSession, type StoredSession } from "./session-store.js";
import { loadProfile, profileKey } from "./profiles.js";
import { createKeychain, credentialStore } from "./keychain.js";

export interface PublicationCredentials {
  /** Tool-facing `publication` enum value, e.g. "kevin-muldoon". Never surfaced when only one publication is configured. */
  key: string;
  /** Human-readable label derived from `key`, e.g. "Kevin Muldoon". Used only in startup logs and the `publication` field's description. */
  label: string;
  publicationUrl: string;
  sessionToken: string;
  userId: string;
  source: ResolvedCredentials["source"];
  missing: string[];
}

type Field = "publicationUrl" | "sessionToken" | "userId";

const PREFIXED_VAR_RE = /^SUBSTACK_PUB_([A-Za-z0-9_]+)_(PUBLICATION_URL|SESSION_TOKEN|USER_ID)$/;

/**
 * "This name is trying to be a publication variable."
 *
 * Leading whitespace is tolerated and the prefix matched case-insensitively so
 * that a typo is *caught* rather than skipped. The trailing underscore is what
 * keeps the legacy `SUBSTACK_PUBLICATION_URL` out — `SUBSTACK_PUBL…` does not
 * start with `SUBSTACK_PUB_`.
 */
const PUB_PREFIX_RE = /^\s*SUBSTACK_PUB_/i;

/** One publication under construction: its fields, plus every raw `<KEY>` that mapped to it. */
interface Group {
  fields: Partial<Record<Field, string>>;
  rawKeys: Set<string>;
}

const ALL_FIELDS: Field[] = ["publicationUrl", "sessionToken", "userId"];

const SUFFIX_BY_FIELD: Record<Field, string> = {
  publicationUrl: "PUBLICATION_URL",
  sessionToken: "SESSION_TOKEN",
  userId: "USER_ID",
};

const FIELD_BY_SUFFIX: Record<string, Field> = {
  PUBLICATION_URL: "publicationUrl",
  SESSION_TOKEN: "sessionToken",
  USER_ID: "userId",
};

function slugify(rawKey: string): string {
  return rawKey.toLowerCase().replace(/_/g, "-");
}

function labelFromKey(key: string): string {
  return key
    .split("-")
    .filter(Boolean)
    .map((word) => word[0].toUpperCase() + word.slice(1))
    .join(" ");
}

/** Blank client config fields select the same legacy path as an unset variable. */
function selectedProfileKeys(env: NodeJS.ProcessEnv): string[] | undefined {
  const raw = env.SUBSTACK_PROFILES;
  if (raw === undefined || raw.trim() === "") return undefined;
  const keys = raw.split(",");
  if (keys.length > 32 || new Set(keys).size !== keys.length) throw new Error("Select at most 32 distinct profile keys.");
  keys.forEach(profileKey);
  return keys;
}

export function resolvePublications(
  env: NodeJS.ProcessEnv = process.env,
  loader: () => StoredSession | null = loadSession,
  profileLoader: (key: string) => StoredSession = loadProfile,
): PublicationCredentials[] {
  const keys = selectedProfileKeys(env);
  if (keys !== undefined) {
    if (Object.keys(env).some(key => PUB_PREFIX_RE.test(key) || ["SUBSTACK_PUBLICATION_URL", "SUBSTACK_SESSION_TOKEN", "SUBSTACK_USER_ID"].includes(key))) {
      throw new Error("SUBSTACK_PROFILES cannot be combined with publication credential environment variables. Choose one configuration source.");
    }
    return keys.map(key => ({ key, label: labelFromKey(key), ...profileLoader(key), source: "stored" as const, missing: [] }));
  }
  const groups = new Map<string, Group>();
  const malformed: string[] = [];

  for (const envName of Object.keys(env)) {
    const match = PREFIXED_VAR_RE.exec(envName);
    if (!match) {
      // A name that announces itself as a publication variable but does not
      // match the grammar is intent too, and silently skipping it is the same
      // failure as skipping an empty value: `SUBSTACK_PUB_B-PUB_*` (a hyphen
      // in the key) used to vanish entirely, so a valid A plus a complete
      // hyphenated B resolved to A alone, in single-publication mode, and a
      // call meant for B landed on A. A lone malformed group fell all the way
      // back to the stored browser-login session.
      if (PUB_PREFIX_RE.test(envName)) malformed.push(envName);
      continue;
    }
    const [, rawKey, suffix] = match;
    const slug = slugify(rawKey);
    // The name creates the group; the value is judged afterwards. See the
    // module comment for what skipping empty values here used to allow.
    const group = groups.get(slug) ?? { fields: {}, rawKeys: new Set<string>() };
    group.rawKeys.add(rawKey);
    group.fields[FIELD_BY_SUFFIX[suffix]] = env[envName] ?? "";
    groups.set(slug, group);
  }

  // Before the fallback, so a process configured only with malformed names can
  // never reach `resolveCredentials()` and its stored-session path.
  if (malformed.length > 0) {
    throw new Error(
      `Unrecognized SUBSTACK_PUB_<KEY>_* variable name(s): ${malformed.map((n) => JSON.stringify(n)).join(", ")}. ` +
        "Each must be exactly SUBSTACK_PUB_<KEY>_PUBLICATION_URL, _SESSION_TOKEN, or _USER_ID, " +
        "where <KEY> is ASCII letters, digits, and underscores only — no hyphens, no surrounding whitespace, " +
        "and the suffix uppercase.",
    );
  }

  if (groups.size === 0) {
    const creds = resolveCredentials(env, loader);
    return [
      {
        key: "default",
        label: "default",
        publicationUrl: creds.publicationUrl,
        sessionToken: creds.sessionToken,
        userId: creds.userId,
        source: creds.source,
        missing: creds.missing,
      },
    ];
  }

  if (env.SUBSTACK_PUBLICATION_URL || env.SUBSTACK_SESSION_TOKEN || env.SUBSTACK_USER_ID) {
    console.error(
      "Warning: both SUBSTACK_PUB_<KEY>_* and legacy SUBSTACK_* env vars are set. " +
        "The legacy vars are ignored — remove them, or fold that publication into a SUBSTACK_PUB_<KEY>_* triplet.",
    );
  }

  // Two env-var names that slugify to the same key are two publications the
  // operator meant to keep apart. Merging them is silent and can cross
  // credentials, so it is fatal rather than a warning.
  const collisions = [...groups]
    .filter(([, group]) => group.rawKeys.size > 1)
    .map(([slug, group]) => `${slug} (from ${[...group.rawKeys].sort().join(", ")})`);
  if (collisions.length > 0) {
    throw new Error(
      `Conflicting SUBSTACK_PUB_<KEY>_* names resolve to the same publication key: ${collisions.join("; ")}. ` +
        "Keys are compared case-insensitively with _ as -; give each publication a distinct key.",
    );
  }

  const incomplete: string[] = [];
  const result: PublicationCredentials[] = [];
  for (const [slug, { fields }] of groups) {
    // `undefined` (name never seen) and `""` (name seen, value empty) are both
    // unusable, and both are reported — an empty value is a typo, not a
    // decision to disable that publication.
    const badFields = ALL_FIELDS.filter((f) => !fields[f]?.trim());
    if (badFields.length > 0) {
      const detail = badFields.map((f) => `_${SUFFIX_BY_FIELD[f]}${fields[f] === undefined ? "" : " (empty)"}`);
      incomplete.push(`${slug} (${detail.join(", ")})`);
      continue;
    }
    result.push({
      key: slug,
      label: labelFromKey(slug),
      publicationUrl: fields.publicationUrl!,
      sessionToken: fields.sessionToken!,
      userId: fields.userId!,
      source: "env",
      missing: [],
    });
  }

  if (incomplete.length > 0) {
    throw new Error(
      `Incomplete SUBSTACK_PUB_<KEY>_* configuration for: ${incomplete.join(", ")}. ` +
        "Each publication needs all three of _PUBLICATION_URL, _SESSION_TOKEN, and _USER_ID with a non-empty value.",
    );
  }

  return result;
}

/** The synchronous file resolver remains the existing public contract. */
export async function resolveSelectedPublications(env: NodeJS.ProcessEnv = process.env, keychain = createKeychain()): Promise<PublicationCredentials[]> {
  if (credentialStore(env) === "file") return resolvePublications(env);
  const keys = selectedProfileKeys(env);
  if (keys !== undefined) {
    const sessions = new Map(await Promise.all(keys.map(async key => [key, await keychain.read(key)] as const)));
    return resolvePublications(env, () => null, key => {
      const value = sessions.get(key);
      if (!value) throw new Error(`Keychain profile "${key}" is missing; no fallback session was selected.`);
      return value;
    });
  }
  const hasNamedEnv = Object.keys(env).some(key => /^\s*SUBSTACK_PUB_/i.test(key));
  const needsStored = !hasNamedEnv && ["SUBSTACK_PUBLICATION_URL", "SUBSTACK_SESSION_TOKEN", "SUBSTACK_USER_ID"].some(key => !env[key]);
  const session = needsStored ? await keychain.read("default") : null;
  return resolvePublications(env, () => session);
}
