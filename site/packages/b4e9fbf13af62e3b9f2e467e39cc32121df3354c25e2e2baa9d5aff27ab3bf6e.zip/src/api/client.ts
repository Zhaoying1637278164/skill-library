import {
  SubstackUser,
  SubstackPost,
  SubstackDraft,
  SubstackComment,
  SubstackNote,
  NoteCreatePayload,
  NoteAttachment,
  DraftCreatePayload,
  DraftUpdatePayload,
  ImageUploadResult,
  SubstackSection,
  SubstackScheduledPost,
} from "./types.js";
import { requestJson, requestText } from "./request.js";
import { DEFAULT_BROWSER_USER_AGENT } from "./browser-user-agent.js";
import { SubscriberService } from "./subscribers.js";
import { searchPosts } from "./search.js";
import { getPublication } from "./publication.js";
import { updateDraftTags, type DraftTagsInput } from "./draft-tags.js";
import { listPublicationTags, getPostTags } from "./tags.js";
import { rankPosts } from "./rankings.js";
import { getPublicationStats, getGrowthSources } from "./publication-analytics.js";
import { listIncomingRecommendations, listOutgoingRecommendations, listOutgoingRecommendationStats, PublicationIdentityUnavailableError } from "./recommendations.js";
import { z } from "zod";
import { ResponseError, SubstackAPIError } from "../utils/errors.js";
import { validateCredentials } from "../auth/validate-credentials.js";

/**
 * Per-request deadline applied to every outbound fetch.
 *
 * Node's default is no request timeout at all — only undici's 10s *connect*
 * timeout — so a host that accepts the connection and then goes quiet hangs the
 * call forever. 30s is long enough for a base64 image upload on a slow link and
 * short enough that a dropped connection becomes an error instead of a stall.
 * Override per client via the constructor (SUBSTACK_REQUEST_TIMEOUT_MS at the
 * entry point).
 */
export const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;

/**
 * Largest `limit` Substack's post_management endpoints will accept.
 *
 * Probed directly against `/api/v1/post_management/published` (2026-08-02):
 * `limit=50` → HTTP 200, `limit=51` → HTTP 400
 * `{"errors":[{"location":"query","param":"limit","value":51,"msg":"Invalid value"}]}`,
 * `limit=100` → 400. So 51 is the exact boundary and 50 is the largest page the
 * API will serve. Never send a `limit` above this — the request fails outright
 * rather than returning a truncated page.
 */
export const MAX_PAGE_SIZE = 50;

/** Pages `getPostAnalytics` will scan before giving up. */
export const ANALYTICS_MAX_PAGES = 10;

/**
 * How many of the most recent published posts `getPostAnalytics` searches.
 * Derived, not stated: tool descriptions that quote this bound must interpolate
 * it so they can't rot when either factor changes.
 */
export const ANALYTICS_SCAN_DEPTH = MAX_PAGE_SIZE * ANALYTICS_MAX_PAGES;

/** Outcome of searching the published feed for one post's analytics. */
export interface PostAnalyticsSearch {
  post: SubstackPost | null;
  outcome: "found" | "archive_exhausted" | "scan_bound_reached" | "feed_incomplete";
  /** Published posts examined before stopping. */
  scanned: number;
  /** The feed's `isCapped` flag from the last page read, uninterpreted; null when absent. */
  feed_capped: boolean | null;
}

/**
 * Parse Substack's order-of-magnitude subscriber bucket into a number.
 *
 * Values look like "1K+", "2.5K+", "750+", "1M+". Exported for tests.
 *
 * The previous implementation did `.replace("K", "000")`, which turns "2.5K"
 * into "2.5000" and then NaN — so any publication in a fractional-K bucket
 * silently lost its count.
 */
export function parseMagnitude(raw: string): number | null {
  const m = raw.trim().replace(/,/g, "").match(/^([\d.]+)\s*([KMkm]?)\+?$/);
  if (!m) return null;
  const base = parseFloat(m[1]);
  if (!Number.isFinite(base)) return null;
  const scale = m[2].toUpperCase() === "M" ? 1_000_000 : m[2].toUpperCase() === "K" ? 1_000 : 1;
  const n = Math.round(base * scale);
  return n > 0 ? n : null;
}

export class SubstackClient {
  /** Validated configured origin; never includes credentials. */
  get origin(): string { return this.publicationUrl; }
  readonly subscribers = new SubscriberService((path, options) =>
    this.request(`${this.publicationUrl}${path}`, options));
  private publicationUrl: string;
  private cookie: string;
  private userId: number;
  private userAgent: string;
  private timeoutMs: number;

  constructor(
    publicationUrl: string,
    sessionToken: string,
    userId: string,
    userAgent?: string,
    timeoutMs?: number,
  ) {
    const validated = validateCredentials(publicationUrl, sessionToken, userId);
    this.publicationUrl = validated.origin;
    this.cookie = validated.cookie;
    this.userId = validated.userId;
    // Substack sits behind Cloudflare, which rejects non-browser User-Agents
    // (the default Node/undici UA, "node", etc.) with HTTP 403 "error code:
    // 1010" on some publications — notably custom domains. Default to a browser
    // UA; allow override via SUBSTACK_USER_AGENT.
    this.userAgent = userAgent || DEFAULT_BROWSER_USER_AGENT;
    // A zero, negative, or non-finite override would abort every request
    // instantly (or never), so it falls back to the default rather than
    // silently breaking the client.
    this.timeoutMs =
      typeof timeoutMs === "number" && Number.isFinite(timeoutMs) && timeoutMs > 0
        ? timeoutMs
        : DEFAULT_REQUEST_TIMEOUT_MS;

  }

  private async request<T>(
    url: string,
    options: RequestInit = {},
  ): Promise<T> {
    const headers: Record<string, string> = {
      Cookie: this.cookie,
      "User-Agent": this.userAgent,
      Accept: "application/json, text/plain, */*",
      // Without a Referer, Substack 301-redirects canonical *.substack.com API
      // calls to the publication's custom domain; following that redirect lands
      // on a 401. Presenting the publish UI as referer keeps the request
      // first-party and served directly.
      Referer: `${this.publicationUrl}/publish/home`,
      ...(options.headers as Record<string, string> || {}),
    };

    // Only send Content-Type when there's a body. A bodyless GET carrying
    // Content-Type is a non-browser signature — the same class of tell the
    // browser UA/Referer above exist to avoid. Respect a caller override.
    if (options.body && !("Content-Type" in headers)) {
      headers["Content-Type"] = "application/json";
    }

    return requestJson<T>(url, { ...options, headers }, this.timeoutMs);
  }

  async validateAuth(): Promise<{ authentication: "authenticated_read_succeeded"; user_identity: "not_verified" }> {
    const data = await this.request<unknown>(`${this.publicationUrl}/api/v1/post_management/drafts?offset=0&limit=1&order_by=draft_updated_at&order_direction=desc`);
    if (!data || typeof data !== "object" || !("posts" in data) || !Array.isArray(data.posts)) {
      throw new Error("Authentication read returned an unexpected response.");
    }
    // A successful publication read proves neither the configured account ID nor
    // a post author's identity. Never infer the signed-in user from a byline.
    return { authentication: "authenticated_read_succeeded", user_identity: "not_verified" };
  }

  searchPosts(input: Parameters<typeof searchPosts>[0]) {
    return searchPosts(input, path => this.request(`${this.publicationUrl}${path}`));
  }

  getPublication() {
    return getPublication(this.publicationUrl, path => this.request(`${this.publicationUrl}${path}`, {
      headers: { Referer: `${this.publicationUrl}/publish/settings` },
    }));
  }

  listPublicationTags(input: Parameters<typeof listPublicationTags>[0]) {
    return listPublicationTags(input, () => this.getPublication(), path => this.request(`${this.publicationUrl}${path}`));
  }

  getPostTags(input: Parameters<typeof getPostTags>[0]) {
    return getPostTags(input, () => this.getPublication(), path => this.request(`${this.publicationUrl}${path}`));
  }

  updateDraftTags(input: DraftTagsInput, publication: string) {
    return updateDraftTags(input, publication, {
      getPublication: () => this.getPublication(),
      getDraft: id => this.getDraft(id),
      request: (path, options) => this.request(`${this.publicationUrl}${path}`, options),
      origin: this.publicationUrl,
    });
  }

  rankPosts(input: Parameters<typeof rankPosts>[0]) {
    return rankPosts(input, path => this.request(`${this.publicationUrl}${path}`));
  }

  publicationStats(input: Parameters<typeof getPublicationStats>[0]) {
    return getPublicationStats(input, path => this.request(`${this.publicationUrl}${path}`));
  }

  growthSources(input: Parameters<typeof getGrowthSources>[0]) {
    return getGrowthSources(input, path => this.request(`${this.publicationUrl}${path}`));
  }

  /**
   * Recommendation reads resolve the publication ID from the host-verified
   * publication record first, so every row can be checked against the selected
   * publication before anything is returned.
   */
  private async recommendationRead<T>(run: (publicationId: number, read: (path: string) => Promise<unknown>) => Promise<T>): Promise<T> {
    let id: number;
    try { id = (await this.getPublication()).data.id; }
    catch (error) {
      if (error instanceof SubstackAPIError && (error.statusCode === 403 || error.statusCode === 404)) throw new PublicationIdentityUnavailableError(error.statusCode);
      throw error;
    }
    return run(id, path => this.request(`${this.publicationUrl}${path}`, { headers: { Referer: `${this.publicationUrl}/publish/recommendations` } }));
  }

  incomingRecommendations(input: Parameters<typeof listIncomingRecommendations>[0]) {
    return this.recommendationRead((id, read) => listIncomingRecommendations(input, id, read));
  }

  outgoingRecommendations(input: Parameters<typeof listOutgoingRecommendations>[0]) {
    return this.recommendationRead((id, read) => listOutgoingRecommendations(input, id, read));
  }

  outgoingRecommendationStats(input: Parameters<typeof listOutgoingRecommendationStats>[0]) {
    return this.recommendationRead((id, read) => listOutgoingRecommendationStats(input, id, read));
  }

  /**
   * Subscriber count, with its precision stated rather than implied.
   *
   * As of 2026-07, `publication_launch_checklist` no longer returns
   * `subscriber_count`/`subscriberCount` — it returns `subscribers` as an
   * ~11-item paginated SAMPLE. This method used to fall back to that array's
   * length, which reported "11 subscribers" for a publication with over a
   * thousand. A wrong number with a caveat attached is still a wrong number:
   * callers (and models reading the tool result) use the integer, not the prose.
   * So the sample is never counted.
   *
   * Substack rounds the free subscriber count on every surface reachable without
   * its internal dashboard API — the public page AND the authenticated
   * /publish/home payload both report e.g. "1,000" for a true 1,073. So
   * `approximate` is the honest ceiling for the fallback path, and callers should
   * render it hedged ("1,000+") rather than as an exact figure.
   */
  async getSubscriberCount(): Promise<{
    count: number;
    precision: "exact" | "approximate" | "unavailable";
    note: string;
  }> {
    try {
      const data = await this.request<Record<string, unknown>>(
        `${this.publicationUrl}/api/v1/publication_launch_checklist`,
      );
      // Kept in case Substack restores these fields.
      if (typeof data.subscriber_count === "number") {
        return { count: data.subscriber_count, precision: "exact", note: "Exact count from the publication API." };
      }
      if (typeof data.subscriberCount === "number") {
        return { count: data.subscriberCount, precision: "exact", note: "Exact count from the publication API." };
      }
    } catch {
      // Fall through to the public page.
    }

    const rounded = await this.getRoundedSubscriberCount();
    if (rounded !== null) {
      return {
        count: rounded,
        precision: "approximate",
        note:
          `Approximate — Substack rounds this value, so the true count is ${rounded} or higher. ` +
          "Render it hedged (e.g. \"" + rounded.toLocaleString("en-US") + "+\"), not as exact. " +
          "The publication API no longer exposes an exact count; see your Substack dashboard.",
      };
    }

    return {
      count: -1,
      precision: "unavailable",
      note: "Could not retrieve subscriber count. Check your Substack dashboard.",
    };
  }

  /**
   * Scrape the rounded free-subscriber count off the publication page.
   * Returns null when no count can be parsed. Never throws.
   */
  private async getRoundedSubscriberCount(): Promise<number | null> {
    let html: string;
    try {
      html = await requestText(`${this.publicationUrl}/`, {
        headers: { "User-Agent": this.userAgent },
      }, this.timeoutMs);
    } catch {
      return null;
    }

    // Substack embeds JSON in script tags with escaped quotes.
    const normalized = html.replace(/\\"/g, '"');

    const exactish = normalized.match(/"freeSubscriberCount"\s*:\s*"?([\d,]+)"?/);
    if (exactish) {
      const n = parseInt(exactish[1].replace(/,/g, ""), 10);
      if (Number.isFinite(n) && n > 0) return n;
    }

    // Order-of-magnitude bucket, e.g. "1K+", "2.5K+", "750+".
    const oom = normalized.match(/"freeSubscriberCountOrderOfMagnitude"\s*:\s*"([^"]+)"/);
    if (oom) {
      const n = parseMagnitude(oom[1]);
      if (n !== null) return n;
    }

    return null;
  }

  async getPublishedPosts(
    offset = 0,
    limit = 25,
  ): Promise<{ posts: SubstackPost[]; total: number; reported_total: number | null; capped: boolean | null }> {
    const data = await this.request<{ posts: SubstackPost[]; total: number; offset: number; limit: number; isCapped?: unknown }>(
      `${this.publicationUrl}/api/v1/post_management/published?offset=${offset}&limit=${limit}&order_by=post_date&order_direction=desc`,
    );
    // isCapped is passed through uninterpreted; its meaning is not documented.
    const reported_total = typeof data.total === "number" && Number.isSafeInteger(data.total) && data.total >= 0 ? data.total : null;
    return { posts: data.posts || [], total: data.total || 0, reported_total, capped: typeof data.isCapped === "boolean" ? data.isCapped : null };
  }

  async getDrafts(offset = 0, limit = 25): Promise<SubstackDraft[]> {
    // The bare /api/v1/drafts collection returns 403 "Not authorized" on many
    // publications; /api/v1/post_management/drafts is the endpoint the Substack
    // editor itself uses. It requires explicit ordering params and returns the
    // drafts wrapped in { posts, total } rather than a bare array.
    const data = await this.request<{ posts: SubstackDraft[]; total?: number }>(
      `${this.publicationUrl}/api/v1/post_management/drafts?offset=${offset}&limit=${limit}&order_by=draft_updated_at&order_direction=desc`,
    );
    return data.posts || [];
  }

  async getDraft(id: number): Promise<SubstackDraft> {
    return this.request<SubstackDraft>(
      `${this.publicationUrl}/api/v1/drafts/${id}`,
    );
  }

  async getPost(id: number): Promise<SubstackPost> {
    // /posts/:slug treats a numeric ID as a slug and returns 404 (#125).
    // The numeric route returns { post, publication, publicationSettings }.
    const data = await this.request<{ post?: SubstackPost & { wordcount?: number } }>(
      `${this.publicationUrl}/api/v1/posts/by-id/${id}`,
    );
    const post = data?.post;
    if (!post || post.id !== id) {
      throw new Error("Unexpected published post response; requested post cannot be verified.");
    }
    // This route calls the count `wordcount`; keep the public tool field stable.
    return { ...post, word_count: post.word_count ?? post.wordcount };
  }

  async createDraft(
    title: string,
    body?: string,
    subtitle?: string,
    audience: string = "everyone",
  ): Promise<SubstackDraft> {
    const payload: DraftCreatePayload = {
      draft_title: title,
      draft_bylines: [{ id: this.userId, is_guest: false }],
      audience: audience as DraftCreatePayload["audience"],
      type: "newsletter",
    };

    if (subtitle) payload.draft_subtitle = subtitle;
    if (body) payload.draft_body = body;

    return this.request<SubstackDraft>(
      `${this.publicationUrl}/api/v1/drafts`,
      {
        method: "POST",
        body: JSON.stringify(payload),
      },
    );
  }

  /** One-shot transport adapter. Use planDraftUpdate/applyDraftUpdate for draft changes. */
  async writeDraft(
    id: number,
    updates: DraftUpdatePayload,
  ): Promise<SubstackDraft> {
    return this.request<SubstackDraft>(
      `${this.publicationUrl}/api/v1/drafts/${id}`,
      {
        method: "PUT",
        body: JSON.stringify(updates),
      },
    );
  }

  async uploadImage(imageBase64: string): Promise<ImageUploadResult> {
    return this.request<ImageUploadResult>(
      `${this.publicationUrl}/api/v1/image`,
      {
        method: "POST",
        body: JSON.stringify({ image: imageBase64 }),
      },
    );
  }

  async getPostComments(
    postId: number,
    limit = 20,
  ): Promise<SubstackComment[]> {
    const data = await this.request<{ comments: SubstackComment[] }>(
      `${this.publicationUrl}/api/v1/post/${postId}/comments`,
    );
    const comments = data.comments || [];
    return comments.slice(0, limit);
  }

  async getSections(): Promise<SubstackSection[]> {
    // Substack exposes no dedicated sections endpoint; the sections list rides
    // along on the subscriptions payload, one entry per publication you belong
    // to. Pick the entry whose hostname (or custom domain) matches this
    // publication. Mirrors python-substack's approach, extended to also match
    // on custom_domain so custom-domain publications resolve correctly.
    const data = await this.request<{
      publications?: Array<{
        hostname?: string;
        custom_domain?: string | null;
        sections?: SubstackSection[];
      }>;
    }>(`${this.publicationUrl}/api/v1/subscriptions`);

    const publications = data.publications || [];
    // Match on exact host, not substring — the subscriptions payload lists
    // every publication you follow, so `includes` would let an unrelated
    // `ample.substack.com` match `example.substack.com` and return the wrong
    // sections.
    let host: string;
    try {
      host = new URL(this.publicationUrl).hostname;
    } catch {
      host = this.publicationUrl;
    }
    const match = publications.find(
      (p) => p.hostname === host || p.custom_domain === host,
    );
    return match?.sections || [];
  }

  async getScheduledPosts(
    offset = 0,
    limit = 25,
  ): Promise<SubstackScheduledPost[]> {
    // `scheduled` is a distinct post_management view (sibling of `published`
    // and `drafts`). Each row carries a `trigger_at` future publish time.
    const data = await this.request<{ posts?: SubstackScheduledPost[] }>(
      `${this.publicationUrl}/api/v1/post_management/scheduled?offset=${offset}&limit=${limit}&order_by=trigger_at&order_direction=asc`,
    );
    return data.posts || [];
  }

  async getPostAnalytics(postId: number): Promise<SubstackPost | null> {
    return (await this.findPostAnalytics(postId)).post;
  }

  async findExactPostAnalytics(postId: number): Promise<PostAnalyticsSearch & { source: "post_detail" | "published_feed_scan"; detail_fallback_reason?: "not_found" | "malformed" | "id_mismatch" | "forbidden" | "not_published" | "upstream_error" }> {
    const path = `/api/v1/post_management/detail/${postId}?offset=0&limit=1`;
    let fallback: "not_found" | "malformed" | "id_mismatch" | "forbidden" | "not_published" | "upstream_error" | undefined;
    try {
      const raw = await this.request<unknown>(`${this.publicationUrl}${path}`);
      const count = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).nullish();
      const stats = z.object({ views: count, sent: count, delivered: count, opened: count, signups: count, subscribes: count, estimated_value: z.number().finite().nullish() });
      const detail = z.object({ posts: z.array(z.object({ id: z.number().int().positive().max(Number.MAX_SAFE_INTEGER), title: z.string().max(10_000).nullish(), post_date: z.string().max(100).nullish(), is_published: z.boolean().nullish(), stats: stats.nullish(), comment_count: count, reaction_count: count })).length(1) });
      const parsed = detail.safeParse(raw);
      if (!parsed.success) fallback = "malformed";
      else if (parsed.data.posts[0].id !== postId) fallback = "id_mismatch";
      else if (parsed.data.posts[0].is_published !== true || !parsed.data.posts[0].post_date) fallback = "not_published";
      else return { post: parsed.data.posts[0] as unknown as SubstackPost, outcome: "found", scanned: 1, feed_capped: null, source: "post_detail" };
    } catch (error) {
      if (error instanceof SubstackAPIError && error.statusCode === 401) throw error;
      if (error instanceof SubstackAPIError && error.statusCode === 429) throw error;
      if (error instanceof SubstackAPIError && error.statusCode === 404) fallback = "not_found";
      else if (error instanceof SubstackAPIError && error.statusCode === 403) fallback = "forbidden";
      else if (error instanceof ResponseError && ["malformed_json", "unexpected_html"].includes(error.code)) fallback = "malformed";
      else fallback = "upstream_error";
    }
    const search = await this.findPostAnalytics(postId);
    return { ...search, source: "published_feed_scan", detail_fallback_reason: fallback };
  }

  /**
   * Search the published feed for a post's stats row, reporting why it was not found.
   * Each row of the published feed
   * already carries a `stats` object, so page through the feed (newest first)
   * until the matching id turns up. Bounded so a bad id can't scan forever:
   * ANALYTICS_SCAN_DEPTH most recent published posts, awaited one page at a
   * time. A found post short-circuits.
   *
   * Outcomes use the feed's reported `total` when Substack sends one:
   * - `archive_exhausted`: the scan reached the end of the feed as paged (a short
   *   final page with no contradicting total, or full pages exactly reaching the
   *   reported total). Pages are separate offset reads, not an atomic snapshot:
   *   a post published and another deleted between reads can shift a post past
   *   an offset boundary without changing the total, so this is not proof that
   *   the post never existed.
   * - `scan_bound_reached`: the bound was hit before the end; an older post may
   *   exist, and its analytics are unknown here, not absent.
   * - `feed_incomplete`: the pages do not form one consistent snapshot, so the
   *   search cannot claim the post is absent. That covers a short page while the
   *   total says more posts remain, a total that changes between pages or is
   *   reported on only some pages, more posts than the total, and a post ID
   *   repeated across pages.
   */
  async findPostAnalytics(postId: number): Promise<PostAnalyticsSearch> {
    const pageSize = MAX_PAGE_SIZE;
    let scanned = 0;
    let feed_capped: boolean | null = null;
    const totals: (number | null)[] = [];
    const seen = new Set<number>();
    let duplicate = false;
    // Exhaustion can only be claimed from pages that agree with each other.
    const consistency = () => {
      const reported = totals.some((t) => t !== null);
      const stable = reported && totals.every((t) => t === totals[0]);
      const total = stable ? totals[0] : null;
      const inconsistent = duplicate || (reported && !stable) || (total !== null && scanned > total);
      return { inconsistent, total };
    };
    for (let page = 0; page < ANALYTICS_MAX_PAGES; page++) {
      const { posts, reported_total, capped } = await this.getPublishedPosts(page * pageSize, pageSize);
      feed_capped = capped;
      totals.push(reported_total);
      scanned += posts.length;
      for (const p of posts) {
        if (seen.has(p.id)) duplicate = true;
        seen.add(p.id);
      }
      const found = posts.find((p) => p.id === postId);
      if (found) return { post: found, outcome: "found", scanned, feed_capped };
      if (posts.length < pageSize) {
        const { inconsistent, total } = consistency();
        const outcome = inconsistent || (total !== null && scanned < total) ? "feed_incomplete" : "archive_exhausted";
        return { post: null, outcome, scanned, feed_capped };
      }
    }
    const { inconsistent, total } = consistency();
    const outcome = inconsistent ? "feed_incomplete" : total !== null && scanned === total ? "archive_exhausted" : "scan_bound_reached";
    return { post: null, outcome, scanned, feed_capped };
  }

  async createNote(
    bodyJson: NoteCreatePayload["bodyJson"],
    attachmentIds?: string[],
  ): Promise<SubstackNote> {
    const payload: NoteCreatePayload = {
      bodyJson,
      tabId: "for-you",
      surface: "feed",
      replyMinimumRole: "everyone",
    };
    if (attachmentIds?.length) {
      payload.attachmentIds = attachmentIds;
    }
    return this.request<SubstackNote>(
      `${this.publicationUrl}/api/v1/comment/feed`,
      {
        method: "POST",
        body: JSON.stringify(payload),
      },
    );
  }

  async createNoteAttachment(url: string): Promise<NoteAttachment> {
    return this.request<NoteAttachment>(
      `${this.publicationUrl}/api/v1/comment/attachment`,
      {
        method: "POST",
        body: JSON.stringify({ url, type: "link" }),
      },
    );
  }
}
