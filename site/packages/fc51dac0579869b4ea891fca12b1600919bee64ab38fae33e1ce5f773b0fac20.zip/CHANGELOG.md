# Changelog

## 1.3.6 — 2026-09-27

- Zoom is included on every plan; the skill's plan note lists it with the everyday effects.

## 1.3.5 — 2026-09-27

- Manifest names the terms of service, the support page and the documentation page for directory listings.

## 1.3.4 — 2026-09-27

- README: the API-key example shows a placeholder instead of an environment variable.

## 1.3.3 — 2026-09-27

- Plugin manifest carries an icon, the privacy policy and the docs page; the README says exactly what the
  plugin sends to Screen Browser and what never leaves your machine.

## 1.3.2 — 2026-09-26

- The repository is an [Agent Plugins](https://agent-plugins.org/) package as well: `plugin.json` and
  `mcp.json` at the root, so Cursor, VS Code, GitHub Copilot and other clients of the standard install
  it from the repository URL. Nothing changes for Claude Code.
- The MCP server's tools now carry titles, annotations, a description on every parameter and an
  output schema; results also arrive as structured content.

## 1.3.1 — 2026-09-24

- `update_project` takes `title_line`, the words the narrator says over the opening (`{title}`
  fills in the video title). The narrated opening is off by default.

## 1.3.0 — 2026-09-24

- Openings and endings: the skill gives each main guide a `video_title` for the branded opening,
  skips `[HEADLINE]` when the project already opens with the title, and knows the new
  `update_project` fields for a project's own opening and ending (style, 3–10 s length, call to
  action, fade, narrated title). They are free and uploads stay in the app.

## 1.2.0 — 2026-09-20

- The skill now says which effect fits which moment (a ring before a click, a zoom aimed at the
  card rather than its heading, a tooltip on the side that covers nothing, an annotation for what
  the video cannot show, one chapter card per section), asks for a caption before every action the
  viewer should hear about, and has the agent review the video at the moment of every effect
  before handing it over. The free check runs after every edit. Written from one real Claude Code
  session and its twelve takes of the same guide.

## 1.1.1 — 2026-09-15

- Listing metadata for the plugin marketplace: `displayName` ("Screen Browser"), a `mcpServers`
  declaration in `plugin.json`, contact email on author/owner, and discovery keywords/tags led by
  video, audio and screen recording. Sharper descriptions and a tagline — "Screen recordings with
  AI voiceover, from your code." No behaviour change.

## 1.1.0 — 2026-09-09

- Mobile web: `create_project`, `update_project` and `start_run` take `device` (a current iPhone,
  Pixel, iPad or Galaxy Tab preset), `frame` (portrait, widescreen landscape, or none) and
  `backdrop` (neutral or brand). `get_run` reports the run's `output`. The skill says how to write
  guides for touch devices.

## 1.0.0 — 2026-09-05

- First release: the `screenbrowser` skill (write auth + main guides from source code, validate, run,
  fetch the video) and the MCP server configuration for Claude Code.
- Guide syntax reference and a complete example (Chatamatic, "Create your first keyword campaign").
