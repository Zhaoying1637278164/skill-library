<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/logo-dark.png">
  <img src="assets/logo-light.png" alt="Referent" width="72" height="72">
</picture>

# Referent — Legal AI Native CRM

Claude plugin for [Referent](https://referent.law), the Legal AI Native CRM. It connects Claude to your firm's workspace over MCP — clients, matters, tasks, time tracking, calendar, documents, billing, and activity — and adds skills that teach Claude how legal practice work is actually done.

## Install

**Claude Code**

```
/plugin marketplace add Referent-Law/claude-plugin
/plugin install referent@referent-law
```

**Claude Cowork**

Install from the plugin directory at [claude.com/plugins](https://claude.com/plugins/).

On first use, Claude opens a browser window to sign in to your Referent account (OAuth 2.1). There are no API keys to manage and the plugin stores no credentials.

## What it provides

### MCP server

A remote MCP server at `https://mcp.referent.law/mcp` exposing your firm's workspace. Access is scoped to your user and your organization — a connected app sees exactly what your Referent account sees, under the same role-based permissions — and every write is audited.

### Skills

Four skills that fire automatically when the work calls for them:

| Skill | Fires when | What it does |
|---|---|---|
| `matter-intake` | New client, new enquiry, opening a matter, conflicts check | Runs conflicts before substance, captures parties and scope, records the fee arrangement, opens the matter, and drafts the engagement letter for signature |
| `time-entry` | Logging time, reconstructing a timesheet, cleaning up entries | Writes narratives that survive line-item review — active verb, named document or party, stated purpose, no block billing — at the matter's rounding increment and task codes |
| `billing-prep` | Billing, invoicing, pre-bill, month-end, WIP review | Assembles the pre-bill, audits every line against the fee agreement, flags vague or duplicated entries, and recommends write-offs |
| `matter-brief` | "Where are we on…", status update, handover, hearing prep | One page: where things stand, what is due, what changed and why it matters, decisions needed, and the financial position |

## The lawyer still signs

The skills are written so Claude prepares work and a lawyer approves it. Claude does not clear conflicts, send engagement letters, issue invoices, write off time, or treat a computed limitation date as settled — it flags each of those for a human decision and says what it could not verify.

## Data handling

- Authentication is OAuth 2.1 against Referent's own authorization server. The plugin ships no executable code and stores no credentials.
- All access is scoped to the signed-in user's role-based permissions within their firm's workspace; writes are recorded in Referent's audit trail.
- Do not use this integration to process PHI or payment card data.

## Support

- Product and documentation: [referent.law](https://referent.law) · [referent.law/mcp](https://referent.law/mcp/)
- Issues with the plugin: [open an issue](https://github.com/Referent-Law/claude-plugin/issues)

## License

MIT — see [LICENSE](LICENSE).
