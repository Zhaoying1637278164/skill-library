---
name: billing-prep
description: Assemble and review a pre-bill in Referent before an invoice goes to a client — collecting unbilled time and disbursements, auditing narratives, flagging write-off candidates, and checking the bill against the fee agreement. Use when the user mentions billing, invoicing, a pre-bill, month-end, WIP review, or getting bills out.
---

# Preparing a bill in Referent

A bill is a client-facing document that will be read line by line, sometimes by someone looking for reasons not to pay. Everything below exists to catch problems while they are still fixable internally.

## 1. Assemble

Pull from Referent for the matter and period:

- Unbilled time entries, with fee earner, date, duration, rate, and narrative
- Unbilled disbursements and expenses, and whether each is supported by a receipt or invoice
- Any payment on account or funds held, and any prior unpaid bills on the matter
- The fee arrangement and any estimate or cap recorded at intake

## 2. Audit the time entries

Go through every line and flag — do not silently edit:

- **Block billing.** Multiple tasks in one entry. These get reduced first.
- **Vague narratives.** "Attention to file", "review documents", "various correspondence", "general advice". Anything that does not say what was done and why.
- **Long entries without justification.** A 6.0 entry needs a narrative that explains six hours; quantify it or split it.
- **Duplicated effort.** Two fee earners on the same call or the same document review, with no explanation of why both were needed.
- **Seniority mismatch.** Partner rate on document management, bundling, or scheduling. Either the work should have been delegated or the rate needs adjusting.
- **Internal conferences** between fee earners on the same matter — recoverable sometimes, scrutinised always. Make sure the narrative earns them.
- **Administrative and clerical time**, file opening, and time spent correcting the firm's own error. These are usually write-offs.
- **Entries outside scope** as recorded at intake — either they need a scope variation on file or they should not be billed.
- **Rate check.** Every entry at the rate agreed in the engagement letter, including any rate increase and whether the client was notified of it.

## 3. Check against the fee agreement

- Fixed fee: is anything being billed above the fixed fee, and was it agreed in writing as a variation?
- Capped fee: does the running total breach the cap?
- Estimate: how does the cumulative bill compare with the estimate given at intake? If the bill will exceed the estimate, that is a conversation to have with the client **before** the invoice goes out, not after. Say so explicitly.
- Hourly: confirm the increment used matches the agreement.

## 4. Disbursements

Separate disbursements from fees. Check each is supported, correctly categorised for tax, and actually incurred on this matter. Flag any unsupported item rather than including it.

## 5. Write-off recommendations

Propose write-offs with a reason and a number, and let the lawyer decide. Common candidates: learning curve after a fee-earner change, work redone, time over an estimate the client was not warned about, and small entries that cost more in argument than they recover.

Never write off, discount, or delete a time entry on your own initiative — record the recommendation and leave the entry intact until the lawyer approves. The audit trail matters more than the tidiness of the pre-bill.

## 6. Hand back the pre-bill

Present:

- Total fees, disbursements, and tax, plus the period covered
- The narrative summary of work done, if the matter bills with one
- A flagged-issues list, grouped by type, each with the entry it refers to and a suggested fix
- Fee-agreement check result, and any estimate or cap breach called out at the top
- Recommended write-offs with reasons and totals
- Funds held and prior unpaid bills

Then stop. The bill goes out when a lawyer approves it — do not send, finalise, or issue an invoice to a client without explicit instruction to do so.
