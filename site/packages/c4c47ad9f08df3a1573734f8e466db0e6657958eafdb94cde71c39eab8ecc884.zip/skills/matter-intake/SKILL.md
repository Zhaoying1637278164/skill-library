---
name: matter-intake
description: Run new client and new matter intake in Referent — conflicts check, party capture, scope and fee terms, opening the matter, and preparing an engagement letter for the lawyer to sign. Use when the user mentions a new client, a new enquiry, opening a matter, onboarding, or running a conflicts check.
---

# Opening a new matter in Referent

Intake is where a firm takes on risk. The order of operations below is not arbitrary — conflicts before substance, engagement terms before work.

## 1. Conflicts first

Run the conflicts check **before** recording detailed confidential information about the matter and before any advice is given. Search Referent across clients, matters, counterparties, and related parties for:

- The prospective client (all known trading names, former names, and abbreviations)
- Every counterparty and opposing party
- Directors, shareholders, parent and subsidiary entities where the client is a company
- Witnesses, experts, insurers, and referral sources where known
- Family members and connected parties in private-client and family work

Search variants, not just the exact string: misspellings, initials, maiden names, "Ltd"/"Limited", trading-as names.

Report what you found and what it means, but do **not** clear a conflict yourself. A name match is a flag for a lawyer to resolve; so is a former client on the other side, a current client adverse to the prospect, and any personal interest disclosed. Present the hits with enough context to decide — which matter, when, which side, whether it is closed — and stop there. If the check is clean, say that it is clean and note what you searched, so the record shows the scope of the search.

Where a conflict exists but may be waivable, that is a lawyer's judgment call and usually needs informed written consent. Flag it; do not draft the waiver as though the decision were made.

## 2. Capture the parties and the enquiry

Once conflicts are cleared, record in Referent:

- **Client**: full legal name, entity type and registration number if a company, address, and the individuals who can give instructions
- **Counterparties** and their representatives, if known
- **The enquiry**: what the client wants, what has happened so far, and any deadline or limitation date already in play
- **Source** of the referral

Where the client is a company, be explicit about who the client is — the entity, not the director you are speaking to — and note that distinction if the caller seems to assume otherwise.

## 3. Flag limitation and urgency immediately

If anything in the enquiry suggests a limitation period, an appeal window, a notice period, or a hearing date, surface it at the top of your summary rather than burying it in the chronology. Give the date the client told you and mark it as unverified. Do not compute a limitation date and present it as settled — the rule depends on jurisdiction, cause of action, and facts that may not be established yet. Say what needs checking and by when.

## 4. Scope and fee arrangement

Record the agreed scope precisely, including what is **out** of scope — scope creep is the root of most fee disputes. Capture the fee basis (hourly with rates by fee earner, fixed fee, capped, contingency/conditional), any estimate given, the billing cycle, and whether a payment on account or retainer is required before work starts.

If the client has been given an estimate, record it. Estimates create expectations that bind the firm in practice even when they are not contractual.

## 5. Open the matter

Create the matter in Referent with a clear name (client — subject — counterparty), the practice area, the responsible and supervising fee earners, the fee arrangement, and the billing increment. Set up the initial tasks and any known dates.

## 6. Engagement letter

Prepare the engagement letter or client care letter as a **draft for the responsible lawyer to review and sign**. Never send it yourself. Base it on the firm's template in Referent where one exists rather than composing terms from scratch. Cover the identified client, scope, fees and billing, who will do the work, complaints procedure, and termination.

Flag anything you could not fill in, rather than inserting placeholder terms that read as though they were agreed.

## Verification and money laundering checks

Note what client identity verification is outstanding. Do not treat the matter as ready to work on until the lawyer confirms verification is complete, and say so in your summary.

## What to hand back

A short intake summary: conflicts result and what was searched, the parties, the enquiry, any date that needs urgent verification, scope and fees as agreed, what you created in Referent, and an explicit list of what still needs a lawyer's decision or signature.
