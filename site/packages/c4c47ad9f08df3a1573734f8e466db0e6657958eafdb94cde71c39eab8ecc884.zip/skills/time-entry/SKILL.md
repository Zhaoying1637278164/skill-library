---
name: time-entry
description: Capture billable time into Referent and write client-ready narratives. Use when the user wants to log time, bill hours, record what they worked on, reconstruct a timesheet from the day's work, or clean up vague or block-billed entries before they reach a client.
---

# Recording billable time in Referent

Unbilled time is the largest silent write-off at most firms. The job here is to turn what the lawyer actually did into entries that survive a client's line-item review — accurate, specific, and attributable to a matter.

## Before writing anything

Get three things straight. Ask only for what you cannot infer:

1. **Which matter.** Search Referent for the matter by client name, matter name, or the counterparty mentioned. If several plausibly match, list them and ask — never guess between two matters of the same client.
2. **How long.** Accept natural phrasing ("about an hour and a half") and convert to the firm's increment.
3. **What was done.** Enough detail to write a narrative that names the task and its purpose.

Check the matter's billing setup before drafting. A flat-fee or contingency matter still needs time recorded for profitability and for any fee application, but the narrative is written for internal use rather than a client's eye, and you should say so rather than silently applying billing conventions that do not apply.

## Rounding

Use the firm's increment as configured on the matter — most commonly 0.1h (6 minutes), sometimes 0.25h. Round to the nearest increment; do not round up by default. If a task genuinely took two minutes, 0.1 is the floor, and several two-minute tasks on the same day are better recorded as one entry describing the group than as six separate 0.1s.

## Writing the narrative

The test: could a cost assessor, a client's GC, or a taxing officer read this line and understand what was done, for whom, and why it was necessary — without any other document?

Structure each entry as **action → object → purpose**:

- "Review and annotate defendant's supplementary disclosure (142 pp.) to identify documents responsive to Category 4 of the disclosure order"
- "Telephone attendance on client re instructions on settlement range ahead of 14 March mediation"
- "Draft and revise clause 7 (limitation of liability) of the supply agreement following counterparty's mark-up"

Rules that matter:

- **Start with an active verb.** Draft, review, revise, attend, telephone, correspond, research, prepare, settle, advise.
- **Name the document, party, or issue.** "Review correspondence" is worthless; "Review counterparty's letter of 3 March re extension of time" is billable.
- **Give the purpose** when it is not self-evident. The purpose is what makes the time recoverable.
- **One task per entry.** Block billing — "Draft submissions; call client; review disclosure — 6.0" — is the single most commonly reduced entry type. Split it.
- **Quantify** where it justifies the duration: page counts, number of documents reviewed, length of a hearing.
- **Never** use "attention to file", "work on matter", "various", "general", "miscellaneous", or "as per attendance note" as the whole narrative.
- Keep to one or two sentences. Precision, not prose.

Avoid describing internal inefficiency in a client-facing narrative — supervision, file familiarisation after a staffing change, or correcting your own error. Record the time honestly against the right billing status rather than dressing it up; flag it for the lawyer to decide whether to write it off.

## Task codes

If the matter uses UTBMS/LEDES codes (common for insurer and corporate panel work), set the phase, task, and activity codes on each entry. Ask which code set applies if the matter does not specify. Do not invent codes.

## Non-billable time

Record it, marked non-billable, rather than dropping it: business development, internal training, administrative work, and time the lawyer decides to write off. It is the only way the firm sees true matter profitability. Do not quietly reclassify non-billable time as billable to improve a number.

## Reconstructing a day

When asked to rebuild a timesheet after the fact, work from evidence, not memory: emails sent and received, documents created or edited, calendar entries, and call logs in Referent. Present the reconstruction as a draft for the lawyer to confirm before writing entries, and mark any entry you inferred rather than observed. Flag gaps ("2:00–4:30 has no activity I can see") instead of filling them with a plausible-sounding guess. Inventing time is a billing fraud risk, not a rounding question.

## Before you save

Show the lawyer the entries — matter, date, duration, narrative, billable status — and get confirmation. Then write them to Referent and confirm what was recorded, including the total for the day and anything you flagged.
