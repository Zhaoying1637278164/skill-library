---
name: matter-brief
description: Get up to speed on a matter in Referent — status, chronology, upcoming deadlines, recent documents and correspondence, open tasks, and financial position. Use when the user asks what is happening on a matter, wants a status update or handover note, is preparing for a client call or hearing, or asks what is due this week.
---

# Briefing on a matter

The point of a brief is that the lawyer can walk into a call or a hearing having read one page instead of a file. Prioritise ruthlessly: what changed, what is due, what needs a decision.

## Identify the matter

Search Referent by client, matter name, counterparty, or reference. If more than one matter matches, list the candidates with enough detail to distinguish them and ask — briefing on the wrong matter of the right client is worse than asking.

## Gather

From Referent, pull:

- Matter status, stage, responsible and supervising fee earners
- Key dates: hearings, filing deadlines, limitation dates, contractual notice periods, review dates
- Open tasks, with owner and due date
- Recent activity — documents filed, emails in and out, calls, attendance notes — since the last brief or over a sensible window
- Financial position: WIP, unbilled disbursements, bills issued, amounts outstanding, funds on account
- The parties and their representatives

## Structure the brief

Lead with what is time-critical, not with a chronology.

**1. Where things stand.** Two or three sentences: the current posture of the matter and what it is waiting on.

**2. What is due.** Every date in the next period, soonest first, with what has to be done and who owns it. Mark anything overdue or undated clearly. If a date in Referent looks like it has passed with no corresponding activity, say so — a missed deadline is the single most important thing a brief can surface.

**3. What changed.** Developments since the last update, in date order, each with its significance rather than just its existence. "Counterparty served evidence on 3 March — their expert disputes causation, which we have not yet answered" beats "Evidence received 3 March."

**4. Open questions and decisions needed.** Things waiting on the lawyer or on the client.

**5. Money**, where relevant: WIP, billed and unpaid, and funds held.

## Judgment

- **Distinguish what the file says from what you infer.** Attribute facts to the document or entry they came from, and mark inference as inference.
- **Say what is missing.** A brief that quietly omits the gap is worse than one that names it: no attendance note for a key call, no confirmation the filing was accepted, an unanswered letter.
- **Do not compute court deadlines and present them as settled.** Report what is recorded in Referent. If a date needs to be calculated from a rule, say which rule appears to apply and that it needs checking against the current procedural rules for the jurisdiction — you are not the docketing system of record.
- **Do not soften bad news.** An adverse development stated plainly is the useful version.
- Where the brief is for a handover or a client update, say who the audience is and adjust the register — a client update explains, an internal handover assumes knowledge.

## Preparing for something specific

If the brief is for a call, hearing, or mediation, add a short section on what the lawyer is likely to be asked and what is not yet answerable from the file. Pull the documents they will want open, and list them by name and location in Referent so they can be found in seconds.
