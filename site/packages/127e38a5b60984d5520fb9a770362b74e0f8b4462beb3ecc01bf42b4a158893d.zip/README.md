# Breeze plugin for Claude

Manage your [Breeze](https://www.breeze.pm) projects from Claude — projects, cards, to-dos,
comments, time tracking, estimates, stages, and project discussions — via the hosted Breeze
MCP server.

This plugin bundles:

- **The Breeze MCP connector** (`.mcp.json`) — a remote server at `https://mcp.breeze.pm/mcp`,
  authenticated with OAuth. Nothing runs locally.
- **A `breeze` skill** — teaches Claude the Breeze conventions (resolve names to ids first, use
  the natural shortcuts, and follow the two-step preview→confirm flow for writes).
- **A `/weekly-review` slash command** — a read-only weekly summary across your projects.

## Install

### From this marketplace

```
/plugin marketplace add breezepm/breeze-plugin
/plugin install breeze
```

Then open Breeze from the connectors/authentication prompt and approve the OAuth login. The
first time a Breeze tool is used, Claude will ask you to connect your Breeze account.

### Requirements

- A [Breeze](https://www.breeze.pm) account. Grant the **read** scope for viewing and the
  **write** scope to create or change data.
- Claude Code, or another Claude surface that supports plugins.

## What Claude can do

Read: your workspaces, projects, cards, to-dos, comments, time entries, tags, activity, and
project messages; keyword and semantic search; project stats.

Write (needs the `write` scope): create/update/delete cards, to-dos, checklists, comments,
project messages, time entries, and estimates; manage stages, projects, and members; archive
and restore. Bulk creates/updates and every delete are confirmed in two steps before anything
changes.

## Privacy & support

- Privacy policy: https://www.breeze.pm/privacy
- Support: support@breeze.pm

## License

MIT — see [LICENSE](LICENSE).
