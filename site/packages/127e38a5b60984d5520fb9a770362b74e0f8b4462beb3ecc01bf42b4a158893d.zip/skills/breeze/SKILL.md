---
name: breeze
description: Conventions for working with the Breeze project-management tools (breeze_* MCP tools). Use whenever the user asks to view, create, update, or delete Breeze projects, cards, to-dos, comments, time entries, estimates, stages, or project messages — e.g. "add a card", "log my time", "what's overdue", "move this task to Done".
---

# Working with Breeze

Breeze is a Kanban tool: a Team owns Workspaces and Projects; a Project has ordered Stages
(board columns) containing Cards (tasks) with comments, to-dos, time entries, estimates and
tags. The `breeze_*` tools are provided by the connected Breeze MCP server.

## Orient first

Start with `breeze_get_me` to learn who you are acting as (identity, role, permissions, and
whether the connection has write access). Then use `breeze_list_projects` /
`breeze_get_project` to find the project and its stage/status ids.

## Resolve names to ids before filtering

Card / comment / to-do filters take **numeric ids**, not names. When the user names a person,
stage, status, or project, resolve the id first, then pass it:

- People → `breeze_list_team_members`
- A project's stages and statuses → `breeze_get_project`
- A vague / fuzzy project or card name → `breeze_semantic_search`; an exact known term →
  `breeze_search`

## Prefer the natural shortcuts

- `breeze_list_my_cards` for "my tasks".
- The `due` filter (`overdue` / `today` / `this_week` / `upcoming` / `none`) on
  `breeze_list_cards` and `breeze_list_my_cards` — don't compute date ranges by hand.
- `unassigned: true` for unowned cards / to-dos.
- `breeze_list_activity` with `created_after` / `created_before` for "what changed this week".

## Writes are two-step — respect the confirm flow

Creating or updating **more than one** item, and **any delete** (even a single one), is a
two-step operation:

1. Call the tool **without** `confirm`. The server returns a **preview** (an error result with
   `confirmation_required: true` and a `NOT_WRITTEN` / `NOT_DELETED` status). Nothing changed.
2. **Show that preview to the user and wait for their answer.** Only then call again with the
   **identical** arguments plus `confirm: true`.

Rules:
- Creating / updating exactly one item runs immediately (no confirm). Restores never confirm.
- Never send `confirm: true` on the first call — it's refused ("no preview was issued").
- Don't change the item set between preview and confirm, or the confirm is refused.
- If a write is refused for a **rate limit** or **permission**, stop and tell the user — do
  not retry in a loop. `breeze_get_me` reports remaining hourly write budget.

## Presentation

Answer in plain language about the work itself. Don't echo internal JSON field names, ids, or
raw empty/null values. Render project, card, and attachment names as markdown links to their
`url`.
