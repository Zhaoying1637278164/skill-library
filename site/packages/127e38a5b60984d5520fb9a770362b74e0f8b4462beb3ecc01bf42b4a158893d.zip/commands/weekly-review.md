---
description: Summarize the week across your Breeze projects — progress, what changed, and what's due.
argument-hint: "[project name or id (optional)]"
---

Produce a concise weekly review from Breeze for the user.

Steps:
1. Call `breeze_get_me` to confirm identity and permissions.
2. Determine scope: if `$ARGUMENTS` names a project, resolve it to an id
   (`breeze_semantic_search` or `breeze_list_projects`); otherwise cover the user's active
   projects.
3. For the project(s), gather:
   - `breeze_get_project_stats` — done vs. open, counts by stage/assignee, due buckets.
   - `breeze_list_activity` with `created_after` set to the start of the last 7 days — what
     was created, moved, updated, or completed.
   - `breeze_list_my_cards` with `due: "overdue"` and `due: "this_week"` — the user's own
     attention list.
4. Write a short narrative (not raw JSON): what progressed, what's newly overdue, what's due
   this week, and any project that stalled. Render project and card names as markdown links to
   their `url`.

This is a read-only summary — do not create, update, or delete anything.
