# {{PROJECT_NAME}} — Research Dossier

Research run started {{YYYY-MM-DD}}. **Goal: gather, NOT implement.** Capture evidence
and design a strategy; implementation happens only after owner sign-off.

## Files
- `01-market-competitors.md` — who exists, sentiment, whitespace, real threats
- `02-keyword-demand.md` — demand from real user search moments, buyer-fit filtered
- `03-audience-buyer-language.md` — verbatim ICP pains from where they actually talk
- `04-case-studies-playbooks.md` — concrete wins (numbers) + the stack used
- `05-distribution-channels.md` — where/how to launch; anti-ban / anti-patterns
- `oss-scan.md` — ★ existing OSS/tools to reuse + build-vs-adopt-vs-fork verdict (`ship-oss-scout`)
- `seo-strategy.md` — ★ go-to-market: keywords, competitor SERP, channels, content plan (`ship-seo-strategy`)
- `08-ANALYSIS-{{name}}.md` — ★ CAPSTONE: synthesis + recommended strategy + open questions
- `10-execution-plan-grounded.md` — ★ plan grounded in the real repo/stack
- `monitoring/<date>.md` — optional standing radar

## Method notes
- {{how data was gathered; tools; rate-limit workarounds; keep raw dumps out of context}}

## Status
- [ ] Market / competitors
- [ ] Keyword / demand
- [ ] Audience / buyer language
- [ ] Case studies / playbooks
- [ ] Distribution
- [ ] OSS reuse scan (build-vs-adopt-vs-fork verdict)
- [ ] SEO / go-to-market strategy (if marketing surface)
- [ ] ★ Capstone analysis + strategy (with open questions for owner)
- [ ] ★ Grounded execution plan
- [ ] ⛔ Owner approved strategy — THEN and only then, exit to Spec

## Open questions for the owner
1. {{...}}
2. {{...}}
