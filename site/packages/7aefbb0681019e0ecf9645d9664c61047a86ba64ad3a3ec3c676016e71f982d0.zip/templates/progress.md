# Progress

> Dated changelog — newest entries on top. When it disagrees with the code, trust the code and
> update this file. Add a `## YYYY-MM-DD` section per meaningful change (what changed, why, result,
> pipeline phase).

## Pending
### Urgent

### Backlog

## Deploy log
| Date | What shipped | Result | Rollback point |
|---|---|---|---|
