# {{PROJECT_NAME}} — Positioning (phase 0)

One page. Fill it before any research/build. This is the phase-0 artifact and gate.

- **Problem** — the one problem this solves, in one sentence:
  > {{...}}
- **ICP (who it's for)** — specific buyer/user, not "everyone":
  > {{...}}
- **Category** — what shelf it sits on (how people already search for it):
  > {{...}}
- **Differentiators** — why this vs the obvious alternatives (2–4 bullets):
  - {{...}}
- **Anti-goals** — what this deliberately will NOT do (scope fence):
  - {{...}}
- **Honest limits** — where it's weak / what it doesn't claim:
  > {{...}}
- **Success metric** — the single number that says "this worked":
  > {{...}}

## ⛔ Owner sign-off (gate 0)
- [ ] Owner confirms problem, ICP, and category.
- [ ] Owner confirms differentiators and anti-goals.

Record the sign-off (with date) in `.ship/state.yml` before moving to phase 1.
