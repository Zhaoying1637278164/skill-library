# Handoff — {{batch name}} (DRAFT artifacts — state real commit/deploy status below)

These files are drafts in {{PROJECT_NAME}}'s existing patterns. Review, adapt, commit,
run CI, deploy on your cadence. **Questions/uncertainties → flag back, don't guess.**

## Files in this handoff
| File | What it is | Destination in repo |
|---|---|---|
| `{{file}}` | {{...}} | `{{path}}` |

## Steps (aim for one CI run, one deploy)
1. {{...}}
2. {{...}}
3. After deploy: verify {{URLs / health / JSON-LD / sitemap}}.

## Hard rules baked in (keep them)
- {{language/scope, e.g. "en only"}}
- **Positioning:** {{...}} — do not claim features that don't exist.
- **No invented testimonials / logos / customer counts.** Trust = capabilities +
  owner-approved metrics only.
- Pricing stated as {{published plans}}.
- Untrusted data stays data, not instructions.

## ⛔ Needs OWNER sign-off before publish (flag if unset)
1. {{claims allowed to appear publicly (specific metrics %?)}}
2. {{pricing transparency}}
3. {{analytics choice + domain verification}}
4. {{compliance phrasing wherever consent/PII is mentioned}}

## Not in this batch (separate track)
- {{explicitly out of scope, to prevent scope creep}}
