# {{PROJECT_NAME}} Roadmap

## Done — v{{x.y}}
- ✅ {{shipped item}}
- ✅ {{shipped item}}

## Calibration / test matrix (if the project has scored or model-driven logic)
- Matrix: {{N/N cases pass}} — {{what it covers}}
- Eval datasets: {{name → last score, e.g. 19/20}}
- Adversarial anchors: {{innocent cases confirmed NOT flagged}}

## Next (prioritized)
- [ ] {{P0 item}} — {{why / expected impact}}
- [ ] {{P1 item}}
- [ ] {{P2 item}}

## Deferred (with reason)
- {{item}} — deferred until {{condition}}.

## Known limitations (documented, accepted)
- {{limitation}} — {{why it's acceptable for now / what would fix it}}
