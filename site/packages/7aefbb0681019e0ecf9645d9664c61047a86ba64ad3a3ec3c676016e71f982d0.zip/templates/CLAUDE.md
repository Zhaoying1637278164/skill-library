# {{PROJECT_NAME}} — Claude Code guide

> One-paragraph description: what this is, for whom, and the single source of truth
> for its core logic/data.

**Read `PROJECT.md` first** for the full reference and code map. Don't explore blindly.

## Hard rules (must not bypass)

The non-negotiable principles live in **`CONSTITUTION.md`** — the single source, injected
into every ship phase and every reviewer. Read it first. Project-specific hard rules only:

- {{HARD_RULE_1 — e.g. "Publishing status is always `draft`. No exceptions."}}
- {{HARD_RULE_2 — e.g. "All money math goes through <module>; never bypass it."}}

## Stack

| Layer | Choice |
|---|---|
| App / server | {{...}} |
| Language / runtime | {{...}} |
| Storage | {{...}} |
| Frontend | {{...}} |
| Proxy / host (prod) | {{...}} |
| Auth / billing | {{...}} |

## Code map

- `{{path}}` — {{what it does}}
- `{{path}}` — {{what it does}}

## Verification (run after changes)

```
{{test command}}
{{typecheck / lint command}}
{{build / health check}}
```

## Gotchas

- {{non-obvious thing that will bite the next session}}

## Pipeline state

Current phase: **{{0 Idea | 1 Research | … | 9 Monitor}}**. See `ROADMAP.md` for Next
and `progress.md` for the dated changelog. Managed with the `ship` plugin pipeline.
