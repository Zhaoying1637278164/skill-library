# {{PROJECT_NAME}} — Acceptance criteria (machine-checkable)

Write criteria the QA/eval layer can grade against — not prose. Two accepted forms:

## 0. Core promise (the #1 criterion — required, never optional)
The single thing the product promises the user must actually work end-to-end. State it as a
checkable path and keep it at the top:
- **Primary path:** Given {{the user}}, when they {{do the main thing}}, then {{the promised
  outcome actually happens}} — e.g. "when they click Copy/Install, the content is actually
  copied/installed", not "a link opens". If the positioning/metric implies an action, that action
  is here and is **required** (QA fails the gate if it's missing or fake).

## EARS (Easy Approach to Requirements Syntax)
One of these shapes per requirement:
- **Ubiquitous:** The `<system>` shall `<response>`.
- **Event:** When `<trigger>`, the `<system>` shall `<response>`.
- **State:** While `<state>`, the `<system>` shall `<response>`.
- **Unwanted:** If `<condition>`, then the `<system>` shall `<response>`.
- **Optional:** Where `<feature>`, the `<system>` shall `<response>`.

Examples:
- When a scan request exceeds the plan's daily quota, the API shall return HTTP 429.
- If the uploaded file is larger than {{N}} MB, then the system shall reject it with a clear error.

## Given-When-Then (for flows)
```
Given <context/precondition>
When <action>
Then <observable, checkable outcome>
```
Example:
```
Given an anonymous user
When they submit the scan form without a Turnstile token
Then the request is rejected and no scan job is created
```

## Rules
- Every criterion must be **observable and checkable** (a test/eval can pass or fail it).
- Cover the unwanted/error cases, not just the happy path (feeds the adversarial QA pass).
- These criteria are the bar the phase-4 QA gate grades against — keep them current.
