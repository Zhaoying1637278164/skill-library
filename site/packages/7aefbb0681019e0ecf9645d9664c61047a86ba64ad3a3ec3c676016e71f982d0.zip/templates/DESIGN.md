# {{PROJECT_NAME}} — Design direction (UI projects)

Fill this in **Spec (phase 2)** and get the owner's sign-off on the *look* **before** Build
generates all the pages. Goal: a current, credible product — not a doc/prototype.

## ★ Design principle — distinctive, not templated (the north star)
Aim for a design that could **only belong to this product** — an identity that expresses **this
project's idea and positioning** (see `POSITIONING.md`), memorable and opinionated, while staying
**professional and usable**. Deliberately avoid the default "starter-kit / AI-generated" look: one
stock blue on white, a centered hero, three generic feature cards, an untouched component-library
theme. Pick a real point of view — a signature (type pairing, color story, layout rhythm, motion,
or illustrative/graphic device) that a user would recognize.
**Uniqueness serves the idea; it is never novelty for its own sake** — it must not cost clarity,
accessibility, or the core promise. Professional ≠ interchangeable.

## Competitor references
- {{competitor}} — what's good / what to beat (screenshot or link). **Note what everyone in this
  space does the same way — then choose at least one axis to deliberately differ on.**

## Direction (pick ONE — present 2–3 genuinely DIFFERENT directions, owner chooses)
> Not three shades of the same template — three distinct points of view. For each, name the ONE
> signature move that makes it *this* product's own.
- **A — {{name}}:** {{one-line vibe}} (e.g. "editorial, high-contrast, oversized type") — signature: {{...}}.
- **B — {{name}}:** {{...}} — signature: {{...}}.
- **C — {{name}}:** {{...}} — signature: {{...}}.
> ⛔ **Chosen:** {{A/B/C}} — owner approved on {{date}}.

## Design tokens (the chosen direction)
- **Type scale:** {{font family + sizes, e.g. Inter / 14–16–20–28–40}} — a real hierarchy, not system-default.
- **Palette:** {{a deliberate set — bg, surface, text, 1 accent, states}}; light **and** dark.
- **Spacing / radius / density:** {{scale}}.
- **Motion / states:** hover, focus-visible, active, loading, empty — defined, not absent.

## Wireframes (rough is fine — layout intent)
- **Home:** {{hero + primary action + key modules; no duplicated sections}}.
- **Catalog / list:** {{grid/filters/search prominence}}.
- **Detail:** {{2-col? sticky action panel? trust/freshness?}}.

## Non-negotiables for Build
- The chosen direction's **signature move actually ships** — the built pages read as *this* product,
  distinctive and on-idea, not a swapped-logo generic template.
- Primary CTA is obvious and does the promised action (see `ACCEPTANCE.md` core promise).
- Mobile composes at ~390px (header/hero don't break); no module shown twice.
- Brand identity beyond a text string (mark/logo, consistent voice).
