# {{PROJECT_NAME}} — Project Reference

> **{{PROJECT_NAME}}** {{one-line what it is}}.
> **Live:** {{url}} · **Version:** {{x.y.z}} · **Owner:** {{owner}}

## 1. What it is & positioning
- **Problem it solves:** {{...}}
- **ICP (who it's for):** {{...}}
- **Category:** {{...}}
- **Differentiators:** {{...}}
- **Honest limits:** {{...}}

## 2. Tech stack
{{table: layer → choice}}

## 3. Repository layout
```
{{tree with one line per important file}}
```

## 4. Core engine / logic
{{how the main thing works; stages; weights/rules if scored}}

## 5. Lifecycle / main flow
{{step-by-step of the primary user/request flow}}

## 6. Data model
| Table/Collection | Purpose |
|---|---|
| {{...}} | {{...}} |

All access parameterized; reads/writes owner-scoped.

## 7. Routes & API
- **Public / indexable:** {{...}}
- **App / noindex:** {{...}}
- **Authed:** {{...}}
- **Admin:** {{...}}
- **Webhooks:** {{...}}

## 8. Auth, plans, quotas, billing
{{auth method; plan/limit table; billing + webhook events}}

## 9. Security posture
{{authn/z, injection defense, SSRF, secret handling, headers}}

## 10. Deployment & operations
| | Local (dev) | Staging | Production |
|---|---|---|---|
| Host | {{...}} | {{prod-like}} | {{...}} |
| Keys | test | test / prod-like | live |
| URL | {{localhost}} | {{staging}} | {{domain}} |

See `production_runbook.md` for the full ops checklist.

## 11. Configuration (env vars)
{{key vars; which are secret; which differ across local/staging/prod. Mirror in .env.example}}

## 12. Status & roadmap
See `ROADMAP.md`.
