# {{PROJECT_NAME}} Production Runbook

The box should be rebuildable from this file. Every box: check it or mark N/A + reason.

## Required services
- [ ] {{app server}} — start: `{{cmd}}`
- [ ] {{worker}} — start: `{{cmd}}`
- [ ] {{database}} ({{prod engine, e.g. Postgres}})
- [ ] {{reverse proxy / TLS}} in front
- [ ] {{cache / rate-limit store}} (before multi-instance)
- [ ] Error monitoring ({{Sentry/…}}) + uptime checks

## Required environment variables (prod)
Set on the server only; file perms `600`; never commit.
```
{{VAR=... — one per line; mark which are secret}}
```

## Deployment steps
> Build once → deploy to staging → smoke → promote the **same** artifact to prod. Record the
> artifact + rollback point in `.ship/state.yml`.
1. Build ({{image / `npm run build` — redirect output to a file, never pipe}}).
2. Run migrations (idempotent); flip persistence flag only after migration succeeds.
3. Ship the **promoted artifact** (pull the image tag / scp the release) — never rebuild in
   prod (build-once); keep env & secrets on the host.
4. Restart services (`systemctl restart …` / `docker compose up -d`) — no `--build`.
5. Purge CDN/Cloudflare cache if static changed.
6. Verify: `/health`, `/robots.txt`, `/sitemap.xml`, canonical redirects, one real flow.

## systemd / process
```
{{unit names; enable --now; list-timers}}
```
Logs: `journalctl -u {{service}} -f`.

## Domain / TLS / redirects
- [ ] Canonicalization: www→apex (301), http→https (308 / Always-HTTPS).
- [ ] Certs auto-renew.
- [ ] Legacy path redirects: {{...}}
- [ ] DNS records: {{A/AAAA/CNAME}}; Cloudflare proxied; WAF/Turnstile if public.

## Security
- [ ] Security headers (XFO, XCTO, Referrer-Policy, HSTS).
- [ ] Private services bound to localhost/private net.
- [ ] Cloud metadata IP blocked (169.254.169.254).
- [ ] Webhooks signature-verified.

## Backups & ops
- [ ] Scheduled backup of {{volume/DB}} (cron/systemd timer): `{{cmd}}`.
- [ ] **Restore test performed** on {{date}} — result: {{...}}.
- [ ] Uptime → alert channel ({{Telegram/email}}); alert test fired.
- [ ] Ops metrics tracked: {{queue depth, failed count, latency, cost}}.

## Email deliverability (if sending)
- [ ] SPF, DKIM, DMARC configured; relay via port 587.

## Rollback
- Previous {{image tag / snapshot}}; procedure: {{...}}.

## Remaining before scale
- {{...}}
