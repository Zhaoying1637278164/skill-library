---
name: ship-monitor
description: Phase 9 of the ship pipeline — monitor in production and feed iteration. Confirm uptime/alerting works, set up a standing monitoring cadence, watch errors/metrics, and turn findings into the next ROADMAP items. Use after launch, or when the user wants ongoing monitoring, a post-launch check, or to plan the next iteration.
---

# Phase 9 — Monitor & iterate

Launch is the start, not the end. Close the loop back into the pipeline.

## Standing monitoring

- [ ] Uptime checks alerting to a real channel (verify one *fires* — trigger a test).
- [ ] Error monitoring reviewed (Sentry/logs); no unhandled spikes.
- [ ] Ops metrics tracked (queue depth, processing/stale/failed counts, latency, cost).
- [ ] Record DORA-style signals in `.ship/state.yml.signals` (deploy frequency, change-fail
      rate, recovery time) as **private feedback, NOT targets** (weaponizing them invites Goodhart-gaming).
- [ ] A dated `monitoring/<date>.md` (or `*-latest.md`) cadence for domain signals
      (rankings, competitors, mentions, usage) where relevant.

## Feed iteration

- [ ] Turn incidents + monitoring findings into `ROADMAP.md` "Next" items (prioritized).
- [ ] **Append the lesson from each incident/regression to `CONSTITUTION.md` as a one-line `-` bullet**
      (under `## Learned rules`) so it's enforced on every future phase and project — the pipeline only
      injects `-` bullets into protected context, so prose there is NOT enforced. This closes the loop.
- [ ] **Marketing surface?** Re-run `ship-seo-strategy` against real Search Console / rank
      data (at-risk pages, what to double down on) and feed results into `ROADMAP.md` Next.
- [ ] Keep `progress.md` dated: what changed, decisions, metrics.
- [ ] Re-enter the pipeline at the right phase for each new item (research/spec/build).

## Health of the practice

- [ ] Backups still running and periodically restore-tested.
- [ ] Secrets rotation on schedule for anything long-lived.
- [ ] Docs match reality (code > stale docs — fix the doc when they diverge).

## Cadence

Small changes: build → QA (targeted) → deploy. Large changes: full pipeline from the
appropriate phase. The monitoring artifacts are the trigger for the next loop.
