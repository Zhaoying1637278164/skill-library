---
name: ship-expert-qa
description: Phase 4 of the ship pipeline — layered QA. Run functional tests + eval/calibration, then fan out a parallel panel of expert reviewers (SEO, code, UI/UX, security, devops), each writing an audit file, then triage findings into critical/major/minor. Use when a build is ready for review, when the user says "QA this", "review before launch", or "run the expert panel".
---

# Phase 4 — Layered QA

Three layers, in order. Don't stop at layer 1.

## Layer A — functional + CI (RUN; failures become findings, not gate-blocks)

> A red test/lint/eval at phase 4 is a **finding** that routes to Fix (see `spec/pipeline.yml`),
> NOT a blocker to *completing* QA. Finding failures is QA's job.

- [ ] Run unit/integration tests (`unittest` / `vitest` / project runner) — failures → findings.
- [ ] **Grade against `ACCEPTANCE.md`** — check each EARS / Given-When-Then criterion; misses → findings.
- [ ] Type check + lint — failures → findings (warnings noted).
- [ ] `verify` skill (external — if absent, use the project's own verify command): drive the real flow end-to-end (not just tests).

## Layer A.5 — browser journey (MANDATORY for any project with a UI)

This needs a real browser (Claude in Chrome, Claude Desktop's in-app browser, Playwright, or an MCP
equivalent — see the README Requirements). The reviewer subagents do NOT have one, so it happens
**here**, in the driving session. **If no browser is available, do NOT skip silently and do NOT assume
it passed** — record the UI journey as **UNREVIEWED/BLOCKED** (a hard finding: the core promise is
unverified) and tell the owner to enable a browser. When a browser IS available, serve the built site
and walk the real journeys on **desktop AND mobile (~390px)**:
- home → browse → a card → its detail page (every hop **HTTP 200**).
- **search → type a query → click a result → detail (HTTP 200)** — the single most common miss.
- every primary CTA / nav link → its expected destination (no bare `github.com`, no `TBD`, no 404).
- 404 / empty / loading states render sanely; mobile header composes (logo + nav don't break).
- **crawl the built site's internal links → zero 404s.**
- **Capture screenshots** of each key page on **desktop + mobile** and save them to
  `audits/screenshots/` — these are what `ship-qa-verifier`/`ship-uiux-reviewer` judge the *look*
  from (the reviewer subagents have no browser; they open these paths with Read).
A broken primary path is a **critical finding** — the product isn't working — no matter how clean
the code review looked. (Skip this layer only for headless/no-UI projects.)

## Layer B — eval / calibration (for scored or model-driven logic)

- [ ] Run the eval datasets / calibration matrix (e.g. 17/17 site matrix, 19/20).
- [ ] **Adversarial pass**: confirm innocent/negative cases are NOT flagged/broken
      *before* celebrating true positives.
- [ ] Record results (pass rate + regressions) in `audits/eval.md`.

## Layer C — expert agent panel (fan-out, parallel)

Launch the reviewers **in parallel** (one Agent call each, in a single message).
Pick the ones relevant to the project type:

| Reviewer (agent) | Focus | Output |
|---|---|---|
| `ship-seo-expert` | indexability, metadata, schema, canonicalization, content quality | `audits/seo.md` |
| `ship-code-reviewer` | correctness bugs, edge cases, reuse/simplification | `audits/code.md` |
| `ship-uiux-reviewer` | **product design** (modernity, **distinctiveness vs generic template**, hierarchy, density, discoverability, trust, CTA) + a11y/mobile — feed it the desktop+mobile screenshots from Layer A.5 | `audits/uiux.md` |
| `ship-security-reviewer` | authn/z, injection, SSRF, secrets, untrusted-data boundary | `audits/security.md` |
| `ship-devops-reviewer` | deploy repeatability, backups, monitoring, env hygiene | `audits/devops.md` |

Each reviewer returns findings as: **severity · file:line · what's wrong · concrete
failure/repro · fix**. Rules that keep the panel reliable instead of noisy (grounded in
the multi-agent-QA evidence):
- **Right-size the panel to the spend mode + the change** (caps live in `spec/pipeline.yml`
  `spend_modes`): **lean** → only the reviewers a real risk surface demands (often 1–2);
  **standard** → 2–3 by real risk; **deep** → the full panel. Never run all 5 by reflex on a
  small diff. A cheaper mode shrinks the panel but **never** waives a `quality_floor` item
  (deterministic tests, security on untrusted input, browser E2E, the rendered UI check).
- **"No findings" is a valid, complete result.** Never require an audit file to be filled;
  a reviewer must report nothing on a clean diff. Forcing output makes it fabricate flaws
  (the self-critique paradox — worst on high-confidence, clean work).
- **Scope each reviewer to the diff + minimal surrounding context**, not the whole repo
  (cuts cost and context-rot). **Review deletions too** — a removed auth check / validation /
  rollback is a critical finding, so never skip deletion hunks.
- **Vary the review lens/prompt across reviewers**; they share a base model (all `sonnet`), so
  treat their agreement as *coverage, not extra confidence*; **never** have them debate toward
  consensus.

## Layer C.5 — verification (before any human sees findings)

Run **`ship-qa-verifier`** on the panel's raw findings — it MUST be a **separate agent call**,
never the same agent (or you) that wrote or fixed the code (independence is the whole point). It re-checks each against the
actual code, **drops fabrications, requires a concrete repro, dedups, and re-ranks by
verified severity**, and **writes the result to `audits/verified.md`** — the canonical,
persistent fix-list that phase 5 works from (agent chat output is transient; the file isn't).
Only verified findings reach triage — this is the step (which best-in-class reviewers include
and `ship` used to lack) that stops the human absorbing the panel's false positives. A finding
counts as a real, gate-relevant issue **only if the verifier confirmed a repro** — use the
Layer B adversarial/negative cases as the CRITICAL bar.

## Triage (you do this on the VERIFIED findings)

- **Critical** (verified repro) → **routes to Fix (phase 5)** (loop 5↔4 until clean).
- **Major** → phase 5 backlog before launch.
- **Minor / nice-to-have** → `ROADMAP.md` Next. Cap minor/nit at ~5; summarize the rest as a count.
- On re-runs after a fix, suppress already-seen nits — report only NEW blocking issues.
- Record each verified finding's outcome so you can track reviewer precision over time.

## Gate — exit QA (complete, not necessarily clean)

QA is **complete** (ready to route) when:
- ✅ Layers A & B were **run** and their failures captured as findings — a red test is a
  *finding to fix*, not a blocker to *completing* QA (that's the point of QA).
- ✅ **(UI projects) Layer A.5 done**: browser journey walked **desktop + mobile**, internal-link
  crawl = 0 broken, screenshots saved to `audits/screenshots/`. A broken primary path blocks.
- ✅ Panel run **and verified** (`ship-qa-verifier` → `audits/verified.md`); findings triaged.
- ✅ `ship-gate-judge` (qa rubric) ≥ threshold; score recorded in `.ship/state.yml`.

The **all-green** bar (tests pass, zero verified-critical, majors closed) is the
**quality-clean** gate to *leave Fix* (5→6), not the gate to *complete QA*.

Then **route** (do not treat "no criticals" as the gate to enter Fix — that's the deadlock):
- `audits/verified.md` has **verified-criticals or majors → phase 5 (Fix)**; loop back to QA
  until clean. "Zero verified-critical" is the gate to **leave Fix (5→6)**.
- Clean → **skip Fix, go to phase 6**.
- ⛔ OWNER sign-off on anything user-facing that makes claims (metrics, testimonials).
