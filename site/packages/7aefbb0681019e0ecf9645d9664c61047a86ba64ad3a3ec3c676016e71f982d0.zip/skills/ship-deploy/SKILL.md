---
name: ship-deploy
description: Phase 8 of the ship pipeline — deploy to production and smoke-test. Push code, run migrations, restart services, verify /health + robots/sitemap + redirects, and purge CDN cache. Use when the host is provisioned and a build is ready to go live, or to run a routine deploy.
---

# Phase 8 — Deploy & smoke-test

A deploy is only done when it's **verified live**. Report failures with output.

> Assumes a self-managed host (Linux + systemd/Docker + Caddy/nginx + scp/git — the
> stack in these projects). For serverless/managed platforms (Vercel/Fly/Render), adapt
> the deploy loop to that platform's CLI; the smoke test still applies verbatim.

> **lite** projects skip staging + promotion (a single throwaway target): build → deploy →
> smoke, keeping the secret guardrail. The steps below are the full-pipeline flow.

## Deploy loop (build once, promote one artifact)

- [ ] **Build ONE immutable artifact** (image tag / release bundle — never pipe build output;
      redirect to a file). Record it in `.ship/state.yml` `prod.artifact`.
- [ ] **Deploy that artifact to staging first** and run the smoke test there.
- [ ] **Promote the SAME artifact** to prod — do not rebuild (rebuilding reintroduces drift).
      Write a `promotion_record` (artifact, checks passed, date) to `.ship/state.yml`.
- [ ] Run DB migrations (idempotent); switch persistence flag only after migration succeeds.
- [ ] Restart services (`systemctl restart …` / `docker compose up -d`).
- [ ] Purge CDN/Cloudflare cache if static changed.
- [ ] **Capture the rollback point** (previous artifact tag / snapshot) in `prod.rollback_point`.

## Smoke test (must pass)

- [ ] `GET /health` (or `/api/health`) → expected version/status.
- [ ] `/robots.txt` and `/sitemap.xml` resolve.
- [ ] Canonicalization: `www→apex`, `http→https` land on the canonical URL.
- [ ] One real end-to-end action through the live app (sign in / run the core flow).
- [ ] Security headers present on a live response.
- [ ] (If billing) a test transaction path works and webhook events are received.

## Safety

Deploying is outward-facing. For first launch or anything irreversible, confirm with
the owner before flipping DNS or taking the app public. Log the deploy (what shipped,
when, result) in `progress.md`.

## Gate → phase 9

- ✅ Smoke test green on **staging**, then the **same artifact** promoted and smoke-green on prod.
- ✅ Deploy recorded in `progress.md`; `promotion_record` + `rollback_point` in `.ship/state.yml`.
- ✅ **One-command rollback + a short runbook** (redeploy / roll back / check health / find logs)
      exist in `production_runbook.md` — at 2am there's no teammate, the runbook is the team.
