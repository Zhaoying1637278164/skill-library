---
name: ship-research
description: Phase 1 of the ship pipeline — research a project idea WITHOUT implementing. Gather market/competitor/keyword/audience/buyer-language evidence, synthesize a capstone analysis and a repo-grounded execution plan, and end with open questions for the owner. Use when the user says "research this", "before we build", or the ship orchestrator enters phase 1.
---

# Phase 1 — Research (gather, do NOT implement)

Discipline (from `SEO/research/_INDEX.md`): **the research phase produces evidence
and a strategy, never code or committed product changes.** It ends with open
questions for the owner. Implementation happens only after sign-off.

## Output artifacts

Create under `research/` (this is where the research docs first appear — `/ship:new-project` deferred
them so their `{{...}}` never reach an earlier gate; base `_INDEX.md` on `templates/RESEARCH_INDEX.md`):
- `_INDEX.md` — dossier index (list every file + one-line purpose + status checklist).
- `NN-<topic>.md` — one file per strand (numbered).
- `NN-ANALYSIS-<name>.md` — ★ capstone: synthesis + recommended strategy + open questions.
- `NN-execution-plan-grounded.md` — ★ plan grounded in the *real* repo/stack (not generic).
- `oss-scan.md` — ★ existing OSS/tools to reuse + build-vs-adopt-vs-fork verdict (`ship-oss-scout`).
- `seo-strategy.md` — ★ go-to-market plan (`ship-seo-strategy`), if there's a marketing surface.
- `monitoring/<date>.md` — optional standing radar for ongoing signals.

## Checklist

- [ ] **Positioning locked** (from phase 0): what it is, ICP, category, differentiators.
- [ ] **Market / competitor teardown** — who exists, sentiment, whitespace, real threats.
- [ ] **Keyword / demand** — from *real user search moments*, filtered by buyer-fit.
- [ ] **Audience / buyer language** — verbatim pains from where the ICP actually talks.
- [ ] **Case studies / playbooks** — concrete wins with numbers + the stack they used.
- [ ] **Distribution channels** — where to launch, what works, anti-ban/anti-pattern notes.
- [ ] **OSS reuse scan** (`ship-oss-scout`) — BEFORE building anything, scan similar
      open-source projects/libraries/tools; capture pros/cons and a **build-vs-adopt-vs-fork
      verdict**. Don't reinvent what already exists well; flag genuine white space. → `research/oss-scan.md`.
- [ ] **SEO / go-to-market strategy** (`ship-seo-strategy`, if there's a marketing surface) —
      keyword demand, competitor SERP, channels, content/distribution plan. → `research/seo-strategy.md`.
- [ ] **Capstone ANALYSIS** — synthesize all strands into ONE strategy doc.
- [ ] **Grounded execution plan** — mapped to this project's actual code/patterns.
- [ ] **Open questions for owner** listed at the end of the capstone.

## Method notes

- **Respect the spend mode's caps** (single source: `spec/pipeline.yml` `spend_modes`): **lean** ≤2
  research directions / ~12 web searches; **standard** ≤3 / ~20; **deep** uncapped (explicit owner
  request or high-risk). Cap concurrent research agents at 2–3.
- **Stopping rule** (all modes): stop when **two consecutive searches surface no new actionable fact**,
  or every important decision already has a sufficient primary source. Don't search to feel thorough.
- Prefer the `deep-research` skill (external — if not installed, sweep directly with WebSearch/WebFetch)
  for the heavy multi-source sweep; **save raw dumps to `research/raw/`** (excluded from context packs),
  digest into the `NN-*.md` strands and return a summary, not the dump (`spec/observation-policy.md`).
- Keep raw data (`reddit/`, `raw/*.json`) separate from synthesized `.md`.
- Cite sources; separate fact from inference; flag low-confidence claims.

## Gate → phase 2

- ✅ Capstone analysis exists with a clear recommended strategy.
- ✅ Execution plan is grounded in the real repo/stack.
- ✅ **OSS reuse verdict** (build/adopt/fork) produced; reinvention risks acknowledged.
- ⛔ OWNER answered the open questions / approved the strategy.

Do not start Spec until the owner approves. If they say "just build it", still
capture the strategy first — one page is enough — then proceed.
