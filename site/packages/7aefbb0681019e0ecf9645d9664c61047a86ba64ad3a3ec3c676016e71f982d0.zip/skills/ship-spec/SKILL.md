---
name: ship-spec
description: Phase 2 of the ship pipeline — turn approved research into a frozen spec. Extend the phase-0 CONSTITUTION.md (non-negotiable principles, the single source) with project-specific rules, and write PROJECT.md (full reference), CLAUDE.md (the Claude Code guide — project-specific rules + code map), ACCEPTANCE.md (machine-checkable criteria), ROADMAP.md, and the env matrix. Use when research is approved and it's time to define data model, routes, and non-negotiable rules before building.
---

# Phase 2 — Spec (freeze the design)

Produce the documents that make the build unambiguous and keep the AI on-rails.

## Clarify first (cheapest defect prevention)
Before writing the spec, resolve underspecification: list the ambiguities/open questions from
the idea + research, ask the owner the blocking ones, and record the answers. Ambiguity
tolerated here becomes rabbit-holes and rework in build (the #1 failure mode of autonomous
agents). Cheap now, expensive later.

## Output artifacts (authored HERE — from `templates/`)

> `/ship:new-project` **deferred** most of these (a raw `{{...}}` copy would deadlock earlier gates).
> Create each in the project root now from `templates/<name>` (or `.ship/baseline/<version>/`) and fill
> **every** `{{...}}` — no placeholder may survive into the phase-2 gate. **Exception: `CONSTITUTION.md`
> already exists** (scaffolded placeholder-free at phase 0 with the universal guardrails) — **extend**
> it, don't re-create it.

- `CONSTITUTION.md` — **the single source** for non-negotiable principles. It was scaffolded at phase 0
  with the universal guardrails (untrusted-data-is-data, secrets, owner-gates). **Extend** it here with
  the project's durable positioning + stack-specific hard rules (append under the existing headings);
  keep it SHORT. Do NOT overwrite the universal guardrails or leave any `{{...}}`.
- `CLAUDE.md` — the operational Claude Code guide: overview, stack, **project-specific**
  hard rules (pointing at `CONSTITUTION.md` for the non-negotiables), code map, verification
  commands, gotchas. What every future Claude Code session reads first.
- `ACCEPTANCE.md` — machine-checkable acceptance criteria (EARS / Given-When-Then); the bar
  the phase-4 QA/eval gate grades against. **Lead with the core product promise / primary user
  path** — if the promise implies an action (copy/install/submit), that action must work and must
  NOT be marked optional.
- `DESIGN.md` *(UI projects)* — the visual direction: 2–3 options → the chosen one, 1–2 competitor
  references, design tokens (type scale, palette, spacing), and wireframes for the home / catalog /
  detail pages. The owner signs off on the **look** here, before Build generates all the pages.
- `PROJECT.md` (or `spec.md`) — full reference: positioning, stack, repo layout,
  core engine/logic, **data model**, **routes/API**, auth/plans, security posture,
  deploy overview, config (env vars).
- `ROADMAP.md` — versioned plan: Done / Next, with a **calibration/test matrix** if
  the project has scored logic.

## Checklist

- [ ] **Stack chosen** and justified (table: layer → choice).
- [ ] **Repo layout** sketched (tree with one-line-per-file intent).
- [ ] **Data model** defined (tables/collections + purpose; parameterized access).
- [ ] **Routes / API surface** enumerated (public vs authed vs admin; indexable vs noindex).
- [ ] **Non-negotiable hard rules** written/confirmed in `CONSTITUTION.md` (the single
      source — e.g. draft-only, engine-only trades, untrusted-data boundary); `CLAUDE.md`
      carries only project-specific operational rules + a pointer to it.
- [ ] **Env matrix**: every var, which value it takes per env (local/staging/prod), what's secret.
- [ ] **Security posture** stated (authn/z, injection defense, SSRF, secrets).
- [ ] **Environment plan**: how local (test) → staging (prod-like) → prod (live) differ (see `spec/pipeline.yml`).
- [ ] **Verification commands** listed in `CLAUDE.md` (tests, typecheck, lint, health).
- [ ] **Acceptance criteria** written machine-checkable (EARS / Given-When-Then) in
      `ACCEPTANCE.md` — the bar the phase-4 QA/eval gate grades against.
- [ ] **Core product promise = the #1 acceptance criterion.** The main user path ("user can
      <do the main thing>") is explicit and required; a promised action must actually work.
- [ ] **Design direction** *(UI projects)*: `DESIGN.md` written; owner approved the **look**
      (don't let Build generate all pages against an unapproved design).

## Gate → phase 3

- ✅ `CONSTITUTION.md` + `CLAUDE.md` + `PROJECT.md` exist and cover the checklist.
- ✅ Data model + routes + non-negotiable rules are unambiguous.
- ✅ Env matrix distinguishes local/staging/prod keys and marks secrets.
- ✅ Acceptance criteria are machine-checkable, and the **core promise / primary path** is a
  required one (not optional).
- ⛔ OWNER approves scope for v1 (and what's explicitly deferred).
- ⛔ OWNER approves the **visual direction** (`DESIGN.md`) — UI projects, before Build.
