---
name: ship-prod-prep
description: Phase 6 of the ship pipeline — prepare production. Fill the production runbook, TLS/reverse proxy, DNS + domain canonicalization + redirects, Cloudflare/WAF, secrets with locked perms, backups/snapshots on a schedule, uptime + alerting, and email deliverability (SPF/DKIM/DMARC). Use when QA passes and the project is heading to launch.
---

# Phase 6 — Prod-prep (fill the runbook)

Produce `production_runbook.md` here from `templates/production_runbook.md` (or
`.ship/baseline/<version>/`) — `/ship:new-project` deferred it so its `{{...}}` never reached an
earlier gate. Every box below must be checked or explicitly marked N/A with a reason, and no
`{{...}}` may survive into the phase-6 gate.

> The runbook file is the **canonical checklist**; this skill is the how-to. If they
> diverge, the runbook wins — update this skill to match.

## CI / paved road (generate working config, not docs)
- [ ] Confirm `.github/workflows/ci.yml` has the gitleaks secret-scan job **and** the real
      build/test/lint jobs added during Build (no `{{...}}` placeholders remain); the workflow is green.
- [ ] Include the **gitleaks CI job** as the server-side secret-scan backstop — **enforce it with
      required branch protection** (the local git-native pre-commit hook covers only one machine and is
      skipped by `--no-verify`).
- [ ] Generate provisioning/deploy config as code where possible — not prose (see phases 7–8).

## Services & config

- [ ] Required services listed (app, worker, DB, proxy, cache) with start commands.
- [ ] Prod env vars enumerated; live keys set on the server only, file perms `600`.
- [ ] Prod persistence chosen (e.g. Postgres) + migration path from dev store.

## Network / domain

- [ ] TLS/reverse proxy in front (Caddy/nginx) — auto Let's Encrypt or Cloudflare.
- [ ] **Domain canonicalization**: `www` → apex (301), `http` → `https` (308/Always-HTTPS).
      All host variants converge on one canonical URL.
- [ ] DNS records correct (A/AAAA/CNAME); Cloudflare proxied; WAF/Turnstile if public.
- [ ] Redirect rules for legacy/renamed paths captured.

## Security

- [ ] Security headers (X-Frame-Options, X-Content-Type-Options, Referrer-Policy, HSTS).
- [ ] Internal/private services bound to localhost / private net, never exposed.
- [ ] Metadata endpoint blocked (e.g. iptables DROP to 169.254.169.254) if on a cloud VM.
- [ ] Webhook endpoints signature-verified (Stripe events list, etc.).

## Backups & ops

- [ ] Backup **strategy defined**: what/where/schedule. (The timer + a **restore test** run in
      phase 7, once the host exists — you can't restore-test a backup before there's a box.)
- [ ] Uptime checks on `/health` (+ key public URLs) → alert channel (Telegram/email).
- [ ] Log access documented (`journalctl -u …` / container logs).

## Email deliverability (if the app sends mail)

- [ ] SPF, DKIM, DMARC configured for the sending domain.
- [ ] SMTP relay port (587) — many clouds block 25; verify send-as identities.

## Gate → phase 7/8

- ✅ Runbook checklist complete (or N/A justified).
- ✅ Backup strategy defined (the timer + restore test are phase-7 provision items).
- ⛔ OWNER provides: domain, DNS access, live keys, payment/business verification.
