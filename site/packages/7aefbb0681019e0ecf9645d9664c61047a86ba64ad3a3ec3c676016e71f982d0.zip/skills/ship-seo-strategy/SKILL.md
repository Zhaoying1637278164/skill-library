---
name: ship-seo-strategy
description: Plan how a project gets found and adopted — SEO/go-to-market research and a promotion plan. Use when the user asks how to promote/market/rank a project, wants keyword or competitor research, a content/distribution plan, or during the ship research phase for anything with a marketing surface. Not an on-page audit (that's ship-seo-expert / the QA phase) — this is growth strategy.
---

# SEO / go-to-market strategy

Answers "how does this get discovered and adopted?" — produced during **research** (phase 1)
for anything with a marketing surface, and revisited in **monitor** (phase 9) with real data.

## How to run
1. Confirm positioning (problem, ICP, category) from `POSITIONING.md`.
2. Run the **`ship-seo-strategist`** agent (web-capable) to research demand, competitor SERP,
   audience/channels, and a content + distribution plan. Reuse the owner's existing SEO practice
   if the repo has one (e.g. an `SEO/` research folder) instead of starting cold.
3. Save the result as `research/seo-strategy.md`.
4. Feed the prioritized, buyer-fit actions into `ROADMAP.md` "Next".

> This skill is the discoverable entry point (invokable directly when you ask "how do I
> promote/rank X"); the **`ship-seo-strategist`** agent carries the full method and output
> format — this file does not restate it.

## In the monitor phase
Re-run with real Search Console / rank data: which pages are at risk (rising effort, falling
clicks), what to double down on, and next content. Turn findings into `ROADMAP.md` Next.

## Boundaries
- White-hat, durable tactics only; no invented metrics, no manipulative SEO.
- Growth strategy ≠ on-page audit. The QA phase's `ship-seo-expert` checks the built pages'
  indexability/metadata/schema; this skill decides what to build and how to promote it.
