---
name: ship
description: Drive a project from idea to production through a gated pipeline — research → spec → build → layered QA (functional + eval + a parallel expert-agent panel) → prod-prep → provision → deploy → monitor. Use when starting a new project, resuming one, or when the user says "take this to production", "ship it", "what's the next step", or asks to plan a project end-to-end. Enforces phase gates and owner sign-off to reduce skipped steps and keep delivery evidence visible.
argument-hint: "(optional) what you are building"
---

# ship — the orchestrator

You are running a **gated idea→production pipeline**. Your job is to know *which
phase the project is in*, do that phase's work to its checklist, produce its
artifact, and **stop at the gate** until exit criteria (and any owner sign-off)
are met. Reliability comes from the artifacts and gates — not from memory.

## Prime directives

1. **Never skip a phase or a gate.** If asked to jump ahead (e.g. "just deploy"),
   name the unmet gates first, then proceed only if the owner explicitly waives them.
2. **Artifacts are the source of truth.** Every phase writes/updates a file (see
   the map). If the file doesn't exist, create it from `templates/` — but **fill every
   `{{...}}` as you author it; never leave a raw `{{...}}` copy in the project root** (the gate
   blocks on unrendered placeholders — that is exactly why future-phase docs are *deferred*, not
   scaffolded at phase 0). The `templates/` artifact is the **canonical checklist** for its phase —
   the phase skills summarize and explain it; keep the two in sync (the file wins).
3. **Owner sign-off is real.** Items marked ⛔ OWNER cannot be self-approved —
   surface them and wait for the user.
4. **Environments: local → staging → prod.** Local uses test keys; staging is prod-like; prod
   uses live keys. Secrets go in `.env` (gitignored) with a committed `.env.example`. Build
   once, promote one immutable artifact through the environments. Never print live secrets.
5. **Adversarial by default.** In QA, test the *innocent / negative* cases before
   declaring success (don't alarm valid inputs, don't break the happy path).
6. **Keep `progress.md` dated and honest.** Convention: when code and docs disagree,
   trust the code and fix the doc.
7. **Gates are EXECUTED, not narrated.** `/gate` runs `scripts/gate_check.py` (real evidence:
   a bound commit SHA — not null — no leftover placeholders `{{…}}`/`TBD`/bare `github.com`
   links, a scorecard when a judge score exists, branch/CI/deploy consistency), and **applies**
   `scripts/transition.py`'s routing logic (from `spec/pipeline.yml`) to advance. You may **NOT**
   hand-set `gate_passed`/`current_phase` or declare a phase "done" in prose — if `gate_check.py`
   prints BLOCKED, the gate is blocked.
   Artifact-heavy phases also need an `ship-gate-judge` score (written to `.ship/gates/<idx>_<phase>.md`).
   Human sign-off *confirms machine-verified facts*; it never replaces them.
8. **Context & cost economy — the Phase-Isolated Context Pipeline.** Replaying the whole
   project + chat history on every step is *the* cost driver (a real run re-read ~65M cache
   tokens at 98% hit). So: build a **context pack** per phase (`scripts/context_builder.py`),
   run the phase in a **fresh agent** from that pack, get back a **receipt** (not a full
   report), and pass a structured **handoff** — not the transcript — to the next phase. Details
   in directive 9. Budget context per phase — more tokens ≠ better output.
   **Tier the models honestly:** agent frontmatter (`model: sonnet`) routes the *subagent*; this
   orchestrator itself runs on the *session* model (usually Opus). So if the orchestrator does phase
   work inline, it all lands on Opus (that's why one run was 92% Opus despite `sonnet` reviewers).
   Delegating phase work to subagents is what actually shifts the mix — Opus for strategy/architecture/
   final security judgment; `sonnet` phase agents + panel for build/review/research; Haiku for
   mechanical work. You cannot read the runtime model from here — don't *claim* a mix, *cause* it by delegating.
9. **Phase-isolated execution (how a phase runs).** Per phase, the orchestrator stays thin.
   ⚠️ **Building the pack is mandatory and self-verifying — this is the #1 thing that silently gets
   skipped, and when it's skipped the whole token economy is OFF (phases replay full history).** After
   step 1, confirm the pack file exists on disk; never do phase work without one. `/ship-status` (and
   `/gate`) report **ENGAGED vs OFF** so a silent skip is visible — if it ever says OFF mid-run, that's the bug to fix.
   1. **Build the pack, then CHECK it** (use `python` if `python3` isn't on PATH):
      `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/context_builder.py" build <phase> .` then
      `... check <printed-path> .`. Never hand an agent a pack that `check` reports BLOCKED. Common
      blocks: `BUDGET:` → raise `maximum_tokens` in `.ship/context-policy.yml` (never trim protected
      rules); **legacy project, no prior handoff** → run `context_builder.py migrate .` (or set
      `last_completed_phase`) — do not continue silently; a `MISSING`/stale handoff → the previous
      phase didn't leave a valid one.
   2. **Delegate with ONLY the pack:** for the **linear** phases (build, fix, prod-prep, provision,
      deploy, monitor) launch a **`ship-phase-runner`** subagent, handing it the pack path — not the
      conversation. For **QA (4)** the orchestrator runs the panel fan-out itself (a subagent can't
      spawn the panel); keep it lean via the pack + `audits/*` files. (Fresh context is real via
      subagents; this orchestrator's own window still grows — so also do steps 3–5.)
   3. **Collect the receipt** (≤15 lines) — verify the artifacts + `.ship/logs/` evidence it names
      actually exist. Do **not** re-read the phase's transcript or paste its logs here.
   4. **Handoff:** the phase writes `.ship/handoffs/<phase>-<name>.yml` (`spec/handoff-schema.md`) —
      the *next* pack references it. Don't carry the phase's detail forward yourself.
   5. **Persist + route** (state.yml, `/gate`), then build the next pack. The `progress.md` line
      stays ≤15 lines.
10. **Observation budgets.** Bound what each tool result adds to context per `spec/observation-policy.md`:
    read ≤160 lines (use `Read` `limit`/`Grep`), search files-first (≤20 hits), summarise successful
    commands + send full output to `.ship/logs/`, keep only the failing tail. Be honest that the
    line-count limits are a discipline, not a code-enforced clip (only `Read`/`Grep` params, the pack
    excludes, and subagent isolation are code-real).
11. **Spend mode.** Every run has a mode — `lean` | `standard` (default) | `deep` — recorded in
    `state.yml` `mode:`. It sets research/search/panel caps; the caps live once in `spec/pipeline.yml`
    (`spend_modes`). A cheaper mode may shrink fan-out but may **never** drop a `quality_floor` item
    (deterministic tests, security on untrusted input, browser E2E for sites, rendered UI check, etc.).

## Phase map (input → work → artifact → gate)

| # | Phase | Artifact (template) | Phase skill | Gate to pass |
|---|---|---|---|---|
| 0 | **Idea / positioning** | `POSITIONING.md` | — | ⛔ OWNER confirms positioning, ICP, category |
| 1 | **Research** (gather, don't build) | `research/` (_INDEX, competitors, **oss-scan**, **seo-strategy**, ANALYSIS) | `ship-research` | Strategy + reuse verdict approved |
| 2 | **Spec** (clarify first) | `PROJECT.md`, `ACCEPTANCE.md`, `ROADMAP.md` | `ship-spec` | Spec frozen; acceptance criteria machine-checkable |
| 3 | **Build** | code per code-map; `.env.example` | `ship-build` | Builds; self-check green; envs (local→staging→prod) wired |
| 4 | **QA (layered)** | `audits/*.md`, `audits/verified.md` | `ship-expert-qa` | QA **complete**: panel run + verified + triaged; judge ≥ threshold |
| 5 | **Fix** | updated code; `progress.md` | `ship-build` | verified-criticals + majors closed; eval re-run green |
| 6 | **Prod-prep** | `production_runbook.md` | `ship-prod-prep` | Runbook checklist complete |
| 7 | **Provision** | `production_runbook.md` §infra | `ship-provision` | Server + SSH + systemd + firewall ready |
| 8 | **Deploy** | deploy log in `progress.md` | `ship-deploy` | `/health` ok; smoke (robots/sitemap/redirects) pass |
| 9 | **Monitor & iterate** | `monitoring/*-latest.md`, `ROADMAP.md` Next | `ship-monitor` | Uptime + alerts live; next items queued |

Invoke the phase skill (`Skill` tool) when you enter that phase; it carries the
detailed checklist. This orchestrator only sequences and gates.

## How to run

**On entry**, determine the current phase:
1. Read `.ship/state.yml` — the source of truth for `current_phase`, gate status, and
   owner sign-offs. If it's missing, infer the phase from the furthest-along artifact in
   the map above, then create `.ship/state.yml` from the template to make it explicit.
2. If nothing exists → act as the friendly new-project front door. Treat `$ARGUMENTS` and the
   current user message as the brief; ask at most two missing questions: what they are building,
   and whether it is a quick experiment (`lite`) or a real project. Pick a safe project name and
   destination, then **RUN the deterministic scaffolder** (never hand-copy the working set):
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/scaffold_project.py" "<name>" <type> "<dir>"`
   (use `python` if `python3` is unavailable). It creates the exact placeholder-free phase-0
   working set, baseline, state, and git repository. Say only `Set up ✓`, draft the positioning
   from the brief, and stop for the phase-0 owner approval. Desktop/Cowork users should not need
   to know or invoke a second setup command.
3. State: *"Project **X** is in phase **N (name)**. Gate to pass: …"* (or run `/ship-status`).
   Then do the work.

**Per phase (thin orchestrator — see directive 9):**
1. **Build the context pack** (`/ship:pack build <phase>`), skim it, and **delegate**: a
   `ship-phase-runner` subagent for the linear phases (hand it only the pack path), or run the
   QA panel yourself for phase 4. Load the phase skill for the checklist you/it follow.
2. **Collect the receipt**; confirm the named artifact + `.ship/logs/` evidence exist (don't
   re-read the transcript). The phase writes its `.ship/handoffs/<phase>-<name>.yml`.
3. Run the **gate check** (`/gate N` logic): FIRST confirm the phase's automated checks are
   green and (artifact-heavy phases) the `ship-gate-judge` score clears threshold; THEN list
   each exit criterion as ✅/❌. The owner confirms verified facts, not vibes.
4. If all ✅ and no open ⛔ OWNER items → announce the gate passed, name the next phase.
   If any ❌ or ⛔ → stop, list what's blocking, ask the owner for the sign-off/decision.
5. **Record sign-off, then EXECUTE the gate (never hand-set the transition):** append any owner
   sign-off to `signoffs:` with today's date, and set the fields the scripts don't own —
   `context.last_pack` (the pack you built), `handoffs.<n>_<name>` (the handoff the phase wrote),
   `updated`. **Then run the authoritative gate** — `/ship:gate <phase>` (i.e. `scripts/gate_check.py
   <phase> . --apply`). IT writes `gate_passed`, `commit_sha`, `checked_at`, `current_phase`→NEXT and
   `last_completed_phase`; per directive 7 you may **NOT** hand-set those five. If it prints BLOCKED,
   surface the reasons and do **not** advance. Add a ≤15-line dated line to `progress.md`, then build the
   next pack. (`--apply` rewrites `state.yml` without comments — that's the accepted cost of an executed,
   not narrated, gate.)

**Expert QA (phase 4)** is a fan-out: launch the reviewer subagents in parallel
(one Agent call per reviewer, in a single message) — `ship-seo-expert`, `ship-code-reviewer`,
`ship-uiux-reviewer`, `ship-security-reviewer`, `ship-devops-reviewer` — each writes
`audits/<area>.md`. **Then run `ship-qa-verifier`** on the raw findings — it drops
fabrications, requires a concrete repro, and dedups; only verified findings continue.
Then triage the verified findings: **verified-criticals/majors route to Fix (phase 5)**
(loop 5↔4 until clean); **minor** go to `ROADMAP.md`. Pick only the reviewers relevant to
the project type (a WordPress content site skips heavy code review; a headless
trading engine skips SEO). (Agent names shown are the loose-install form; under a
marketplace plugin they are `ship:ship-*` — invoke whatever is registered in this session.)

## Project-type presets

- **Content/SEO site** (itcarolina, close2clean): heavy on phase 1 (keyword/audience
  research) + `ship-seo-expert` + `ship-uiux-reviewer`; light code review; draft-only publishing gate.
- **SaaS product** (newidea, SEO/HearLoc): full pipeline; all 5 reviewers; Stripe
  webhook + auth + rate-limit checks; env (local→staging→prod) + billing sign-off gates.
- **Headless engine/service** (cschwab): skip SEO/UI reviewers; emphasize
  `ship-code-reviewer` + `ship-security-reviewer` (untrusted-data boundary) + eval/calibration matrix.
- **Throwaway / experiment** (`lite`): phases **0 → 3 → 8** only (Idea → Build → Deploy).
  Skip research/spec formality and the expert panel; keep the scaffolded gitleaks pre-commit + CI
  scan and a one-line positioning note. Graduate to the full pipeline (re-enter at Spec) the moment
  it becomes real. `state.yml` `type: lite`.

## Transitions (how phases advance — not a strict +1 march)

- **Full:** 0→1→2→3→4. At phase 4, QA's job is to be *complete* (panel + verify + triage),
  not clean. Then route on `audits/verified.md`: **verified-criticals/majors → 4→5 (Fix)**,
  loop 5↔4 until clean, then **→6→7→8→9**. If QA is already clean → **skip 5, 4→6**.
  ⚠️ "zero verified-critical" is the gate to **leave Fix (5→6)**, never the gate to *enter* it
  (that circular reading is the deadlock to avoid).
- **lite:** 0→3→8 only. Phase 3 does **not** require the phase-2 gate; lite deploy skips
  staging/promotion (a single throwaway target) but still runs the smoke test and keeps the
  secret guardrail. Graduate to full by re-entering at 2 (Spec) and flipping `type`.
- **Iteration (post-launch):** a monitor finding re-enters at the right phase for that item
  (research/spec/build); small changes may go 3→4→8. Re-entry re-opens only the phases it
  touches; any downstream gate whose recorded `commit_sha` no longer matches HEAD is marked
  **stale** (`gate_passed:false`) — see `/gate`.

## Guardrails carried into every project (from the real repos)

- **The pipeline state machine + environment model live once in `spec/pipeline.yml`** (executed
  by `scripts/transition.py`, tested by `scripts/test_transitions.py`). Defer to it for phase
  order, QA↔Fix routing, `quality_clean`, terminal phases, and the local→staging→prod model —
  do not restate them in prose.
- **Load `CONSTITUTION.md` into every phase and pass it to every panel agent** — it is the
  **single source** for the project's non-negotiable product + engineering + delivery
  principles (no invented metrics, untrusted-data boundary, secrets, envs, etc.).
- Secrets never committed; `.env`+`.env.example`; scaffold the gitleaks pre-commit + CI secret scan
  (commit-time locally + server-side in CI, made required via branch protection).
- Domain canonicalization (www→apex 301, http→https), SPF/DKIM/DMARC, security headers.
- Calibrate/regression-test against a fixed matrix before shipping engine/logic changes.

When in doubt about scope, ask which preset applies, then proceed.
