---
name: ship-provision
description: Phase 7 of the ship pipeline — stand up the server and access. Provision the VM, create and lock down SSH keys, install systemd services + timers, configure the firewall, and record it all in the runbook. Use when it's time to create/configure the production host, set up SSH, or wire systemd/backups on the server.
---

# Phase 7 — Provision (server + SSH)

Turn an empty host into a repeatable, secured runtime. Record every step in
`production_runbook.md` so the box is reproducible.

> Assumes a Linux VM (systemd, SSH). On managed/serverless platforms the provider
> handles most of this — skip to the parts that still apply (secrets, domains, backups).

## Host

- [ ] Provision VM (right size; region near users). Note provider, ID, region, IP.
- [ ] OS baseline: updates, non-root deploy user, timezone, swap if small.
- [ ] Docker/Compose or the language runtime installed as the spec requires.

## SSH & access

- [ ] Generate a **dedicated ed25519 keypair** for this host — never reuse across hosts.
      `ssh-keygen -t ed25519 -C "deploy@<project>" -f <name>`
- [ ] Install the public key; **disable password auth**; deploy user in sudoers as needed.
- [ ] Private key stored securely (see the secrets policy); reference it in the runbook,
      never paste the private key into committed files.
- [ ] Record host in `~/.ssh/config` with an alias.

## Services

- [ ] systemd units for each service (+ `enable --now`); `restart: unless-stopped` for containers.
- [ ] Timers for scheduled jobs (backups, retention cleanup) — verify with `systemctl list-timers`.
- [ ] **Backup timer installed + a restore test performed** (a backup you haven't restored is a
      hope, not a backup — this needs the live host, so it lives here, not phase 6).
- [ ] **Provision the staging slot** — a prod-like target (same host with a separate compose/port,
      or a small separate VM) so deploy can build-once → staging → prod.
- [ ] Reverse proxy (Caddy/nginx) installed and pointed at the app port.

## Firewall / hardening

- [ ] Only required ports open (80/443 + SSH); everything else closed.
- [ ] Private services bound to `127.0.0.1`; cloud metadata IP blocked.
- [ ] Fail2ban / rate limiting on SSH if internet-facing.

## Safety

Provisioning is outward-facing and hard to reverse. **Confirm before**: destroying/
recreating hosts, changing DNS, opening ports, or rotating live keys. Do not execute
financial or account-creation steps for the owner — hand those back.

## Gate → phase 8

- ✅ Host reachable via key-only SSH; services enabled; timers listed.
- ✅ Firewall verified; private services not publicly reachable.
- ✅ Backup restore test passed; staging slot reachable.
- ✅ Runbook updated so the host can be rebuilt from it.
