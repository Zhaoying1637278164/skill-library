---
description: Check whether a ship pipeline phase's gate is met and compute the next phase — executable validation (checks/QA/judge/quality/owner) + transition, then record evidence to .ship/state.yml.
argument-hint: "<phase-number 0-9 | phase-name>"
---

Evaluate the gate for phase **$ARGUMENTS** of the current project. Be strict — the gate exists
to stop things being forgotten. **The script is authoritative for both the pass/block decision
and the next phase; you do not compute transitions by hand.**

0. **Order & re-check.** `$ARGUMENTS` must be the **current** phase (from `.ship/state.yml`) to
   *advance*. A **prior** phase may be re-checked to re-certify it, but a re-check must **NOT
   lower `current_phase`**.

1. **Run the executable gate.** In the project, run
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/gate_check.py" $ARGUMENTS .`
   (use `python` if `python3` is unavailable). It validates REAL readiness — not just git
   cleanliness — and now checks:
   - a bound commit SHA (not null) + a clean worktree for **evidence phases (1–8)** — phase 0 (Idea)
     is sign-off-only / pre-evidence, so it needs no commit SHA;
   - **every required `checks:` value is green** (null/false → BLOCKED) for check-gated phases;
   - **QA(4)**: `qa.execution_status == complete` AND `qa.panel_verified == true`;
   - **judge** score ≥ threshold for artifact-heavy phases (research/spec/qa);
   - no leftover placeholders (`{{…}}`, `TBD`, bare `github.com`), a scorecard when a judge score
     exists, and branch/CI/deploy consistency;
   - an **owner sign-off** entry for owner-gated phases (phases 0, 1, 2 — see `owner_signoff_phases`).
   If it prints **BLOCKED**, the gate is BLOCKED — you may **NOT** set `gate_passed` or advance.
   List the reasons it printed. On **PASS** it prints `NEXT: <n> <name>` — the transition computed
   **through `transition.py`** (QA→Fix vs skip-to-6, Fix loop 5↔4, terminal). Use that number; do
   not infer the next phase yourself.

2. **Owner sign-off (⛔).** If the phase has ⛔ OWNER items, surface them as questions and wait —
   the script can only confirm a signoff *entry exists*, not that the human truly approved this run.

3. **Record evidence + advance.** On PASS with no open ⛔, run the same command with **`--apply`**. That
   is the authoritative write — it sets `gate_passed`, `commit_sha` (evidence phases), a UTC `checked_at`,
   `current_phase`→NEXT and `last_completed_phase`→this phase. **Do NOT hand-edit those fields** (it skips
   the checks and the `checked_at` stamp and drifts state from reality — the exact failure this gate
   exists to prevent). It rewrites `state.yml` and does **not** preserve comments; that trade-off is
   deliberate — the executable gate owns these fields.
   - From **monitor(9)** do NOT create phase 10 — set `pipeline_status: live`, keep phase 9.
4. **Invalidate stale gates.** If any already-passed downstream phase's recorded `commit_sha` no
   longer matches current (clean) HEAD, set its `gate_passed: false` — the code it certified changed.
   (This downward invalidation is the *only* permitted hand-edit of `gate_passed`; **certifying** a gate
   to `true` and moving `current_phase`/`last_completed_phase` always goes through `--apply`, never by hand.)
