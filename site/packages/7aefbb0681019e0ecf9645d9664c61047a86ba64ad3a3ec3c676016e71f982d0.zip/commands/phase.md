---
description: Run a specific ship pipeline phase (research, spec, build, qa, fix, prod, provision, deploy, monitor) for the current project.
argument-hint: "<research|spec|build|qa|fix|prod|provision|deploy|monitor>"
---

Run pipeline phase **$ARGUMENTS** for the current project (the phase name is the argument;
if it's empty, use `current_phase` from `.ship/state.yml`). This goes **through the
Phase-Isolated Context Pipeline** — same path as the `ship` orchestrator, not a bypass.

1. Confirm readiness from `.ship/state.yml` against the project `type`'s **Transitions**
   (`spec/pipeline.yml`): the prior phase must be complete.
   - **QA↔Fix:** "no verified-criticals" is the gate to LEAVE fix, not to enter it (5↔4 loop).
   - **lite** (0→3→8): build's prior phase is 0 (not 2); deploy skips staging/promotion.
   Don't skip ahead without an explicit owner waiver.
2. **Build + check the context pack — NOT optional, and "actually run it", not "intend to"** (use
   `python` if `python3` isn't on PATH):
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/context_builder.py" build $ARGUMENTS .` then
   `... check <the-printed-path> .`. **Confirm the pack file exists on disk** before any phase work. If
   check is BLOCKED (e.g. missing prior handoff on a legacy project → run `context_builder.py migrate .`),
   fix that first. ⚠️ **If you ever find yourself doing phase work without a pack for this phase
   (`.ship/context/<run>/$ARGUMENTS-*.yml`), STOP** — that is the exact silent failure this pipeline
   exists to prevent: phases running inline replay the whole history and the token economy is OFF. Build
   the pack now. `/ship-status` reports whether the pipeline is ENGAGED or OFF.
3. **Run the phase:**
   - **Linear phases** (build, fix, prod/prod_prep, provision, deploy, monitor) → delegate to a
     **`ship-phase-runner`** subagent, handing it **only the pack path**. It reads the pack's
     `phase_skill` for the checklist, does the work, writes the artifact + `.ship/handoffs/` + logs,
     and returns a receipt.
   - **Owner-interactive / fan-out phases** (idea, research, spec, qa) → the **main session** runs
     them: idea and spec need owner dialogue and sign-off; research and qa spawn their own panels
     (a subagent can't). They still work from the pack + `phase_inputs` + audit files; use
     `/ship:expert-review` for QA.
4. Verify the receipt's artifacts/evidence exist, then run the **authoritative gate with `--apply`** —
   `/ship:gate $ARGUMENTS` (i.e. `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/gate_check.py" $ARGUMENTS .
   --apply`; use `python` if `python3` is unavailable). That script writes `gate_passed`, `commit_sha`,
   `checked_at`, `current_phase`→NEXT and `last_completed_phase` — **never hand-edit those fields**. If it
   prints BLOCKED, surface the exact reasons and do **not** advance. (Append any owner sign-off to
   `signoffs:` first; the script requires that entry for owner-gated phases.)
