---
description: Scaffold a new project at phase 0 — the placeholder-free working set (positioning, constitution, progress, env, gitignore, pre-commit, secret-scan CI, .ship state). Future-phase docs (CLAUDE.md, PROJECT.md, ACCEPTANCE.md, …) are authored by their own phase, not scaffolded raw here.
argument-hint: "<project-name> [type: content|saas|engine|lite]"
---

Bootstrap a new project workspace using the ship pipeline.

Arguments (as passed): **$ARGUMENTS** — first token = project name, optional second token
= type (`content` | `saas` | `engine` | `lite`). If the type is missing, ask (step 3).

Steps:
1. Confirm the target directory — default **`./<name>`** (a sub-folder of the current working
   directory; cross-platform). Create it if missing. Only use an absolute path if the owner gives one.
2. **RUN the deterministic scaffolder** — do NOT hand-copy templates or hand-author `.ship/state.yml`
   (a drifted hand-scaffold once dropped `CONSTITUTION.md`, leaving empty protected rules; gate 0 now
   hard-blocks an incomplete set):
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/scaffold_project.py" "<name>" <type> "<dir>"` (use `python` if
   `python3` is unavailable). It creates **exactly** the phase-0 working set — `POSITIONING.md`,
   `CONSTITUTION.md`, `progress.md`, `.env.example`, `.gitignore`, `.pre-commit-config.yaml`,
   `.github/workflows/ci.yml`, `.ship/context-policy.yml`, `.ship/state.yml` (with `type`,
   `current_phase: 0`, `template_provenance`) — **identical for full and lite**; snapshots the COMPLETE
   pristine baseline to `.ship/baseline/<version>/` (for `/ship-update` 3-way diffs); and `git init -b
   main`s the project. It does **NOT** create the deferred docs (below). The owner then fills
   `POSITIONING.md` — the phase-0 deliverable.
3. If the type is missing/unknown, ask first: content/SEO site · SaaS product · headless engine ·
   lite (throwaway) — then pass it to the scaffolder. Lite uses the **same** phase-0 working set (keeps
   `CONSTITUTION.md` + secret-scan); a placeholder-free minimal `CLAUDE.md` is authored when lite reaches
   **Build**, never a raw `{{...}}` copy.

   **Deferred docs — authored by their own phase, NOT scaffolded here** (they carry `{{...}}` only their
   phase can fill; the scaffolder omits them, and they live pristine in `.ship/baseline/<version>/`):
   | Document(s) | Created + filled in |
   |---|---|
   | `research/_INDEX.md` (+ numbered strands) | **Research (phase 1)** |
   | `CLAUDE.md`, `PROJECT.md`, `ACCEPTANCE.md`, `DESIGN.md` *(UI)*, `ROADMAP.md` (+ **extend** `CONSTITUTION.md`) | **Spec (phase 2)** |
   | `production_runbook.md` | **Prod-prep (phase 6)** |
   | `_HANDOFF.md` | on demand via `/ship:handoff` |
4. Do NOT create any real `.env` with secrets — the scaffolded `.env.example` keeps placeholders. `git
   init -b main` (done by the scaffolder) **prepares the later evidence gates** (phases 1–8 bind to a
   commit SHA + clean worktree); **phase 0 (Idea) is sign-off-only / pre-evidence and needs no commit**.
   **If** `pre-commit` is installed, run `pre-commit install` so gitleaks scans every commit (optional —
   the CI gitleaks job is the backstop).
5. Print the phase map, run `/ship-status`, and state the project is at **phase 0 (Idea)**;
   list the phase-0 gate (owner confirms positioning/ICP/category, and signs off). Because only
   placeholder-free files exist, the gate should block **only** on the owner sign-off (+ an unfilled
   `POSITIONING.md`), not on future-phase document placeholders.

**Gate authority (same rule the orchestrator follows):** when the owner signs off phase 0, append their
decision to `signoffs:`, then **execute the gate** — `/ship:gate 0` (or `python3
"${CLAUDE_PLUGIN_ROOT}/scripts/gate_check.py" 0 . --apply`). The script writes `gate_passed`,
`checked_at`, and `current_phase`→NEXT (lite/full 0 → next phase). **Never hand-edit `gate_passed`,
`current_phase`, or `last_completed_phase`.** If it prints BLOCKED, surface the reasons and do not advance.

Then invoke the `ship` skill to drive from phase 0.
