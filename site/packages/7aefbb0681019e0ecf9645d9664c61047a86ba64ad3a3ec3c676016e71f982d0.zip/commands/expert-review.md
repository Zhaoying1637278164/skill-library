---
description: Run the parallel expert-QA panel (SEO, code, UI/UX, security, devops) on the current project and triage the findings.
argument-hint: "[area1 area2 ...] (default: auto-pick by project type)"
---

Run the ship expert-QA panel on the current project. Requested areas (as passed): **$ARGUMENTS** — if empty, auto-pick by project type (step 1).

1. Decide which reviewers to run — **sized by the spend mode** (`state.yml` `mode:`; caps in
   `spec/pipeline.yml` `spend_modes`): **lean** → only the reviewers a real risk surface demands
   (often 1–2); **standard** → 2–3 by real risk; **deep** → the full panel. Then narrow by project
   type (content → seo + uiux; SaaS → +security/code; headless → code + security + devops). If
   explicit areas were passed, run exactly those.
2. **Build the QA context pack** for scope (use `python` if `python3` isn't on PATH):
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/context_builder.py" build qa .`. **Launch the reviewers
   in parallel** — one `Agent` call per reviewer in a single message (`ship-seo-expert`,
   `ship-code-reviewer`, `ship-uiux-reviewer`, `ship-security-reviewer`, `ship-devops-reviewer`).
   Give each **the pack's `changed_files` / `repo_map` / `phase_inputs` as its scope** (the diff +
   minimal context — not "review the whole repo"), the project path, and the live URL if any; tell
   it to write `audits/<area>.md`. (UI reviewers also get the Layer A.5 screenshots.)
3. When all return, run **`ship-qa-verifier`** on the raw findings: it re-checks each
   against the actual code, drops fabrications, requires a concrete repro, dedups, and
   re-ranks by verified severity. Only verified findings continue.
4. **Triage the verified findings** into a single summary:
   - CRITICAL (verified repro) → **routes to Fix (phase 5)**; loop 5↔4 until clean.
   - MAJOR → also Fix (phase 5) before launch.
   - MINOR → `ROADMAP.md` Next (cap nits at ~5).
5. Run `ship-gate-judge` (qa rubric); record the score in `.ship/state.yml`.
6. Print the consolidated triage table (area · severity · title · file) and state whether
   **QA is complete** (panel+verify+triage+judge done) and whether it's **clean** (→ phase 6)
   or **routes to Fix** (verified-criticals/majors → phase 5). "Zero verified-critical" is the
   gate to *leave Fix*, not to complete QA.

(Agent names shown are the loose-install form; under a marketplace plugin prefix them with
`ship:` — e.g. `ship:ship-code-reviewer`. Use whatever is registered in this session.)
