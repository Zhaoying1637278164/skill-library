---
description: Generate a _HANDOFF.md that packages draft artifacts for another agent/session — with hard rules baked in and explicit owner sign-off items.
argument-hint: "[batch-name]"
---

Create a handoff document for the current work. Name it `deliverables/_HANDOFF.md`, or `deliverables/_HANDOFF-<batch>.md` if a batch name was passed (**$ARGUMENTS**).

Model it on the ship `templates/_HANDOFF.md`. It must contain:
1. **What this is** — one paragraph; artifacts are DRAFT for review. State explicitly what (if
   anything) is already committed/deployed for this batch — don't assume "nothing" at a late phase.
2. **Files table** — each file · what it is · destination in the repo.
3. **Steps** — ordered, minimal, one CI run / one deploy where possible.
4. **Hard rules baked in** — the non-negotiables to preserve (positioning, "no invented
   testimonials/metrics", language scope, pricing accuracy, untrusted-data boundary).
5. **⛔ Needs OWNER sign-off before publish** — a numbered list of decisions only the
   owner can make (claims allowed public, pricing transparency, analytics/verification,
   compliance phrasing). Tell the receiver to flag uncertainties, not guess.
6. **Not in this batch** — explicitly out of scope, to prevent scope creep.

Keep it short and actionable. Do not include real secrets.
