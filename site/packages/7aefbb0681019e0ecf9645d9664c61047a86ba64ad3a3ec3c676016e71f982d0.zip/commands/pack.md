---
description: Build or validate a phase context pack — the minimal-sufficient context handed to a fresh phase agent (Phase-Isolated Context Pipeline).
argument-hint: "build <phase> | check <pack.yml>"
---

Manage the **context pack** for the current project (see `spec/context-schema.md`). A pack is the
*minimum sufficient* context for one phase; a fresh phase agent works from it instead of re-reading
the whole project + chat history. **$ARGUMENTS**

**`build <phase>`** — run
`python3 "${CLAUDE_PLUGIN_ROOT}/scripts/context_builder.py" build <phase> .`
It writes `.ship/context/<run-id>/<phase>-<name>.yml` and prints the path. Then:
1. Skim the pack — confirm the objective, protected rules, changed files, and required checks look
   right for this phase. It is generated; don't hand-edit it (rebuild instead).
2. Hand **only this pack** (its path) to the phase agent / phase skill — not the whole conversation.
   If the builder printed `BUDGET:`, protected context alone exceeds the budget: raise
   `maximum_tokens` in `.ship/context-policy.yml` — do **not** trim the rules to fit.

**`check <pack.yml>`** — run
`python3 "${CLAUDE_PLUGIN_ROOT}/scripts/context_builder.py" check <pack.yml> .`
Exit 0 = the pack is sound; `BLOCKED` (exit 1) means one of: over budget, an excluded path leaked
in, a **critical rule dropped**, an **owner sign-off removed**, source drift, a **missing prior
handoff**, or a **stale commit_sha**. Fix the cause (usually: rebuild the pack) — never wave it through.

Use `python` if `python3` isn't on PATH (Windows). Two more subcommands:
- **`check-handoff <handoff.yml>`** — validate a handoff (schema, required fields, size, safe
  evidence paths) on its own.
- **`migrate`** — for a project upgraded from v0.7.x with no prior handoff: writes a *synthetic*
  predecessor handoff so the pipeline isn't hard-blocked (review it, and set `last_completed_phase`).

If no phase is given, default to the project's `current_phase` from `.ship/state.yml`.
