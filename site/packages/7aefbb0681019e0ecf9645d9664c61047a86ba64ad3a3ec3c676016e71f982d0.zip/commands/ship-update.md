---
description: Reconcile a project's ship templates with the installed plugin via a real 3-way diff (baseline vs owner's file vs new template). Non-destructive — never overwrites owner content; reports conflicts to merge.
argument-hint: "(none)"
---

Reconcile the current project's scaffolded ship artifacts with the installed plugin. This is
a **3-way** reconciliation using the baseline recorded at scaffold time — the owner's content
always wins.

1. Read `.ship/state.yml` → `template_provenance` (`plugin_version` + `baseline_dir`, the
   per-file snapshot taken at scaffold time — the base for a real 3-way).
   - **No baseline snapshot?** Do NOT just stamp the current version and declare the project up
     to date (that hides drift). Fall back to a **2-way**: ADD missing files, and for existing
     files show the diff vs the new template for the owner to merge. Then take a fresh baseline
     snapshot (this is honest add-missing + report-diff, not a claimed 3-way).
2. If `plugin_version` == the installed version AND no scaffolded file is missing/modified vs
   `baseline_dir` → "up to date", stop. (A version match alone isn't enough — files may have been deleted.)
3. Otherwise, **per file**, do the 3-way — `baseline` (from `baseline_dir`), `project` (owner's
   current file), `plugin` (the new template):
   - project == baseline (owner never touched it) → safe to update to the new template.
   - project != baseline AND the template changed → **conflict**: show the diff, do NOT
     auto-overwrite; let the owner merge.
   - New files the plugin added (e.g. `ci-workflow.yml`, `pre-commit-config.yaml`) → offer to add.
   - **Deferred docs** (`research/_INDEX.md`; `CLAUDE.md`, `PROJECT.md`, `ACCEPTANCE.md`, `DESIGN.md`,
     `ROADMAP.md`; `production_runbook.md`; `_HANDOFF.md`) are **authored by their own phase**
     (Research / Spec / Prod-prep / `/ship:handoff`), so at an early phase
     they exist in `baseline_dir` but not the root — that is **deferred, NOT missing**. **Never offer
     to add one whose authoring phase is ahead of the project's `current_phase`** (a raw `{{...}}` copy
     would deadlock the gate). Only 3-way / offer a deferred doc once its phase has authored it.
4. Apply only what the owner approves:
   - **Render placeholders** — new template files carry `{{...}}`; fill them from the project's
     existing values (name, stack, owner) before writing. Never leave a raw `{{PROJECT_NAME}}`.
   - **Per-file baseline** — advance `baseline_dir` for each file **only when its update is
     accepted**. Keep unresolved conflicts (all three versions) in a `.ship/update-conflicts.md`
     ledger until the owner resolves them — never overwrite the ancestor for a still-conflicted file.
5. When all conflicts are resolved, bump `template_provenance.plugin_version`.

Drift control: scaffolding is a living relationship, not a one-time copy — but never at the
cost of clobbering the owner's edits.
