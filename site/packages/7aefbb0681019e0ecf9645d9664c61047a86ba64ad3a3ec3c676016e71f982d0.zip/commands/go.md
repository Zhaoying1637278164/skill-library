---
description: Compatibility alias for Claude Code's namespaced command surface. The primary Desktop/Cowork entry is the ship skill.
argument-hint: "(optional) one line about what you're building"
---

This is a backward-compatible alias for the `ship` skill's friendly front door. Follow the same
workflow below. The user does NOT need to learn phases, skills, or state files — just guide them.
Keep it human.

1. **Ask up to two plain questions** (skip any already answered in $ARGUMENTS):
   - "What are you building?" (a sentence or two).
   - "Quick experiment, or a real project you'll ship?" → experiment ⇒ type `lite`; real ⇒
     infer the type from the idea (content site / saas / engine) and just tell them what you picked.
2. **Set it up by RUNNING the scaffolder** (don't hand-copy files — the script guarantees the exact set):
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/scaffold_project.py" "<name>" <type> "<dir>"` (use `python` if
   `python3` is unavailable). It writes the placeholder-free phase-0 working set (incl. `CONSTITUTION.md`,
   the secret-scan pre-commit + CI, and `.ship/state.yml`), snapshots the baseline, and `git init -b
   main`s the project; future-phase docs are authored by their own phase. **Do NOT hand-author
   `.ship/state.yml` or pick a subset** — the script is the single source of the required set, and gate 0
   blocks an incomplete scaffold. Don't dump a file list — just say "Set up ✓".
3. **Then drive the pipeline yourself** via the `ship` orchestrator skill, phase by phase:
   - Do each phase's real work; tell the user ONE plain sentence about what you did.
   - At each gate / owner decision, ask ONE simple question ("Approve the positioning? y/n",
     "Ship to production? y/n"). Never surface phase numbers or internal mechanics unless asked.
   - `lite` runs only Idea → Build → Deploy.
4. **Keep momentum:** after a gate the user approves, continue automatically to the next phase.
   Stop only for decisions that are genuinely theirs (or a blocker).

**Gate authority (do this exactly — it's the difference between a real gate and theater):** when the
owner approves a gate, first append their decision to `signoffs:` in `.ship/state.yml` (the one field you
write by hand — it records a human choice), then **run the authoritative executable gate** — `/ship:gate
<phase>`, or `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/gate_check.py" <phase> . --apply` (use `python` if
`python3` is unavailable). That script — not you — writes the transition fields (`gate_passed`,
`commit_sha`, `checked_at`, `current_phase`→NEXT, `last_completed_phase`).
You must **NEVER** directly set or hand-edit `gate_passed`, `current_phase`, or `last_completed_phase` (nor "declare a phase done" in prose).
If the gate prints **BLOCKED**, surface its exact reasons to the owner and **do not advance** — an approval is
permission to *run* the gate, not permission to skip it. (Phase 0/Idea is a sign-off-only, pre-evidence
gate — it needs no commit SHA; the commit-bound evidence gates are phases 1–8.)

The user's whole experience should be: answer a couple of questions, then approve things as you go.
Everything else (phases, the expert-QA panel, gates, state) happens under the hood.
