---
description: Show the ship pipeline status for the current project — the 10-phase map, the current phase and its gate, open owner sign-offs, and the prod/rollback pointer. Read-only.
argument-hint: (none)
---

Report the ship pipeline status for the current project. **Read-only** — do not change state.

1. Read `.ship/state.yml`.
   - If it's missing: say the project isn't initialized for ship. Offer to infer the
     phase from existing artifacts (CLAUDE.md, PROJECT.md, research/, audits/,
     production_runbook.md, live deploy) and create `.ship/state.yml`. Do NOT invent state.
2. Render the 10-phase map, one line per phase, each marked:
   - `✅` done (gate passed)
   - `▶` current / in progress
   - `⛔` blocked awaiting owner sign-off
   - `⬜` not started
   Example:
   ```
   ✅ 0 Idea        ✅ 1 Research     ▶ 2 Spec
   ⬜ 3 Build       ⬜ 4 QA           ⬜ 5 Fix
   ⬜ 6 Prod-prep   ⬜ 7 Provision    ⬜ 8 Deploy    ⬜ 9 Monitor
   ```
   (For a `lite`-type project, show only phases 0, 3, 8.)
3. **Phase-Isolated pipeline engagement (token economy on/off).** Run
   `python3 "${CLAUDE_PLUGIN_ROOT}/scripts/context_builder.py" status .` (use `python` if needed) and
   show its line verbatim. It reports **ENGAGED** (N context packs built) or **OFF** (0 packs — phases
   ran inline, replaying full history, no token saving). If it says **OFF**, surface that prominently as
   a ⚠ — it means the whole point of the pipeline isn't active for this run; the fix is to build a pack
   per phase (`/ship:phase` should do it automatically; if it isn't, that's the thing to correct).
4. Below the map, print:
   - **Current phase** + its gate criteria (from the `ship` skill) as ✅/❌/⛔.
   - **Open owner sign-offs** (⛔ items not yet in `signoffs`) as direct questions.
   - **Pipeline status:** `pipeline_status` (building / live / archived).
   - **Prod:** url · staging url · last deploy · artifact · rollback point.
5. End with the single **next action**.

To advance a phase use `/phase`; to check a gate use `/gate`.
