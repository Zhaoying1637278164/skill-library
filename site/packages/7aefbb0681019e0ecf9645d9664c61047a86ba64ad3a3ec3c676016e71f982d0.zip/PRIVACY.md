# Privacy Policy for Ship

Last updated: July 24, 2026

Ship is an open-source, local workflow plugin for Claude Code and Cowork. The Ship maintainer does
not operate a Ship backend, hosted service, user-account system, analytics service, or telemetry
pipeline.

## Information Ship accesses

When you use Ship, Claude and Ship's local helper scripts may access:

- files in the project directory you choose;
- Git repository metadata and command output;
- the plans, state, handoffs, context packs, QA findings, and other files Ship creates in that
  project.

Access remains subject to the permissions and approvals provided by Claude Code or Cowork. Ship's
helper scripts do not intentionally collect or transmit project contents or secrets to the Ship
maintainer.

## Collection and transmission

Ship itself:

- collects no personal information;
- sends no telemetry or analytics;
- uses no cookies;
- has no MCP server or remote API;
- sends no project data to the Ship maintainer.

Claude Code, Cowork, and Claude process information under Anthropic's terms and
[Privacy Policy](https://www.anthropic.com/legal/privacy).
Optional tools used during a Ship workflow—such as web search, GitHub, package managers, CI
services, gitleaks, hosting providers, or deployment tools—may process data under their own terms
and privacy policies. Ship only directs Claude to use those tools when the workflow requires them
and the user's permissions allow it.

## Storage and retention

Ship stores workflow artifacts locally inside the selected project. The user controls those files
and may edit or delete them. Files committed to Git may remain in local or remote Git history until
the user removes them using the controls provided by the relevant Git hosting service.

Because the Ship maintainer receives no project data or telemetry, the maintainer has no
Ship-collected user data to retain or delete.

## Security

Ship scaffolds optional gitleaks pre-commit and CI checks to help detect accidentally committed
secrets. These checks do not replace the user's responsibility to review files and permissions.
Security issues should be reported privately as described in [SECURITY.md](SECURITY.md).

## Changes to this policy

Material changes will be published in this file with an updated date. The version available in the
public Ship repository is the current policy.

## Contact

For privacy questions, open an issue in the
[Ship issue tracker](https://github.com/vadimsv1/ship-plugin/issues). For sensitive security or
privacy reports, use
[GitHub Private Vulnerability Reporting](https://github.com/vadimsv1/ship-plugin/security/advisories/new).
