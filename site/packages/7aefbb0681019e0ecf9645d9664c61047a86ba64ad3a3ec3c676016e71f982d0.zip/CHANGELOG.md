# Changelog

All notable public changes to the **Ship** plugin are recorded here.

## [0.10.5] — 2026-07-24

Desktop/Cowork entry-point compatibility patch.

### Fixed

- The visible `/ship` skill is now the single public entry point in Desktop/Cowork and handles
  deterministic new-project setup itself.
- README examples no longer tell Desktop/Cowork users to invoke `/ship:go`, which is not available
  on that surface.
- Claude Code users can still use its namespaced skill surface; the old `go` command remains as a
  compatibility alias.
- `ship-doctor` now guards the primary skill's scaffolder wiring and the public README entry point.

## [0.10.4] — 2026-07-24

Initial public beta.

Ship turns Claude Code into a gated idea-to-production workflow:
research → spec → build → layered QA → prod-prep → provision → deploy → monitor.

### Included

- **Friendly entry point:** `/ship:go` asks for a short brief, chooses a full or lite
  workflow, scaffolds the project, and drives the phases while stopping for owner decisions.
- **Deterministic phase-0 scaffolding:** the exact protected working set, gitleaks
  pre-commit/CI configuration, context policy, state, and complete template baseline are
  created by executable code rather than model-authored file copying.
- **Executable phase gates:** automated checks, owner sign-offs, commit evidence, and UTC
  timestamps determine whether a phase can advance. The state machine computes the route,
  including QA → Fix → re-QA loops and the shorter lite flow.
- **Layered expert QA:** functional checks plus focused SEO, UI/UX, code, security, and
  DevOps reviewers; a verifier filters unsupported findings before triage.
- **Phase-isolated context packs:** `/ship:pack` creates bounded, protected per-phase
  context and durable handoffs to reduce repeated full-history reads without dropping
  owner decisions or critical rules.
- **Reusable delivery artifacts:** positioning, constitution, specification, acceptance,
  design, roadmap, research, runbook, deployment, and handoff templates.
- **Cross-platform release checks:** strict manifest validation, runtime plugin load smoke,
  executable Python suites, and `ship-doctor` on Windows, macOS, and Linux.
- **Secret protection:** scaffolded gitleaks pre-commit and CI checks. Ship bundles no
  shell-command-parsing security hook.

### Beta note

Interfaces and templates may still change. Ship itself is free and MIT-licensed; Claude
Code/model usage is billed through the user's Anthropic setup.
