# ship — worked walkthrough

A concrete run of the pipeline on a fictional SaaS, **"RankPulse"** (a keyword-rank
tracker). Shows the artifacts each phase produces and how gates + state work. Use it as
a reference for what "done" looks like per phase.

---

## Kickoff

```
/new-project RankPulse saas
```
Creates `./RankPulse/` (a sub-folder of your current directory) with the **phase-0 working set**
(`POSITIONING.md`, `progress.md`, `.env.example`, `.gitignore`, pre-commit, a secret-scan `ci.yml`) and
`.ship/state.yml`. Future-phase docs (CLAUDE/PROJECT/ACCEPTANCE/…) are authored by their own phase:
```yaml
project: "RankPulse"
type: "saas"
current_phase: 0
phases:
  0_idea: { status: in_progress, gate_passed: false }
  ...
```
`/ship-status` →
```
▶ 0 Idea   ⬜ 1 Research   ⬜ 2 Spec   ⬜ 3 Build   ⬜ 4 QA
⬜ 5 Fix   ⬜ 6 Prod-prep  ⬜ 7 Provision  ⬜ 8 Deploy  ⬜ 9 Monitor
Next: fill POSITIONING.md, get owner sign-off.
```

## Phase 0 — Idea
Fill `POSITIONING.md`: problem (indie SEOs overpay for rank tracking), ICP (solo SEO
consultants), category (rank tracker), differentiators (flat price, API-first),
anti-goals (no backlink tooling), success metric (50 paying users in 90 days).
**Gate:** owner signs off → append to `state.yml.signoffs` with the date, then `/ship:gate 0` executes
the gate and advances to `current_phase: 1` (the script writes it — not hand-edited).

## Phase 1 — Research
`/phase research` → `research/` dossier: competitors, keyword demand, buyer language,
a capstone `08-ANALYSIS-rankpulse.md` (strategy + open questions), and a grounded
execution plan. **Gate:** ⛔ owner approves strategy.

## Phase 2 — Spec
`/phase spec` (clarify first) → **extends** `CONSTITUTION.md` (scaffolded placeholder-free at phase 0
with the universal guardrails — untrusted-data-is-data, secrets in .env, envs local→staging→prod; Spec
adds the project's durable rules), `CLAUDE.md` (Claude Code guide + code map),
`PROJECT.md` (data model, routes, plans), `ACCEPTANCE.md` (EARS / Given-When-Then criteria),
`ROADMAP.md`. **Gate:** spec frozen; acceptance criteria machine-checkable.

## Phase 3 — Build
`/phase build` → implement to the code map; `.env.example` complete; local/staging/prod envs
wired. Run verification commands. **Gate:** builds clean, self-check green.

## Phase 4 — QA
```
/expert-review
```
Fans out 5 agents in parallel; each writes an audit:
```
audits/seo.md       ship-seo-expert       2 major · 3 minor
audits/code.md      ship-code-reviewer    1 critical · 2 major
audits/uiux.md      ship-uiux-reviewer    4 minor
audits/security.md  ship-security-reviewer 1 critical
audits/devops.md    ship-devops-reviewer  2 major
```
Then `ship-qa-verifier` re-checks the raw findings against the code (drops fabrications,
requires a repro, dedups). Triage the **verified** findings: 2 verified-critical **route to
Fix (phase 5)**, loop 5↔4 until clean. (Adversarial eval run first; `ship-gate-judge` scores the rubric.)

## Phase 5 — Fix
`/phase fix` → close the 2 criticals + majors; re-run eval; audits marked resolved.
**Gate:** zero open criticals.

## Phase 6 — Prod-prep
`/phase prod` → complete `production_runbook.md`: TLS/Caddy, DNS + www→apex + http→https,
Cloudflare/Turnstile, secrets @ 600, Postgres migration, **backup strategy defined**, CI +
gitleaks generated, uptime→Telegram, SPF/DKIM/DMARC, Stripe webhook events. **Gate:** runbook
complete. (The backup *timer + restore test* run in phase 7 — you can't restore-test before the host exists.)

## Phase 7 — Provision
`/phase provision` → GCP VM, dedicated ed25519 key, systemd units + timers, firewall,
metadata IP blocked, **backup timer + restore test**, **staging slot** provisioned.
**Gate:** key-only SSH; services enabled; restore test passed; staging reachable.

## Phase 8 — Deploy
`/phase deploy` → **build ONE artifact → deploy to staging → smoke → promote the SAME artifact
to prod** → migrate → restart → smoke (`/health`, robots, sitemap, redirects, one real flow,
headers) → purge cache. `state.yml.prod` gets `artifact` + `promotion_record` + url + rollback
point. **Gate:** staging smoke green, then the same artifact promoted + prod smoke green.

## Phase 9 — Monitor
`/phase monitor` → verify alert fires, watch errors/metrics, `monitoring/<date>.md`,
turn findings into `ROADMAP.md` Next. Loop back to the right phase for each new item.

---

## Lite variant
```
/new-project scratchpad-tool lite
```
Only the phase-0 working set: `POSITIONING.md` (one line), `progress.md`, `.env.example`, `.gitignore`,
`.pre-commit-config.yaml`, secret-scan `ci.yml`, `.ship/state.yml` — lite keeps the secret scan. A minimal
placeholder-free `CLAUDE.md` is written at **Build** (never a raw `{{...}}` copy).
Phases **0 → 3 → 8**. Graduate to the full pipeline (re-enter at Spec) when it gets real.
