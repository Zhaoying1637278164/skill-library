#!/usr/bin/env python3
"""ship doctor helper: parse ALL frontmatter + EVERY yaml/json (recursive) + check manifest
required fields (CLI-independent, so CI without the Claude CLI still validates manifests)."""
import glob, sys, json, os

try:
    import yaml
except Exception:
    print("  pyyaml missing (pip install pyyaml)"); sys.exit(1)

bad = 0

# 1) frontmatter of commands / agents / skills
for pat in ("commands/*.md", "agents/*.md", "skills/*/SKILL.md"):
    for p in sorted(glob.glob(pat)):
        t = open(p, encoding="utf-8").read()
        if not t.startswith("---"):
            print("  no frontmatter:", p); bad = 1; continue
        end = t.find("\n---", 3)
        try:
            d = yaml.safe_load(t[3:end])
            for k in ("description", "argument-hint", "name", "model"):
                if k in d and not isinstance(d[k], str):
                    print("  not a string:", p, k); bad = 1
        except Exception as e:
            print("  YAML error:", p, str(e).splitlines()[0]); bad = 1

# 2) EVERY yaml/json in the tree (recursive) — a new file can't slip past the checker
for pat in ("**/*.yml", "**/*.yaml"):
    for p in glob.glob(pat, recursive=True):
        if p.startswith(".git" + os.sep):
            continue
        try:
            yaml.safe_load(open(p, encoding="utf-8"))
        except Exception as e:
            print("  YAML error:", p, str(e).splitlines()[0]); bad = 1
for p in glob.glob("**/*.json", recursive=True):
    if p.startswith(".git" + os.sep):
        continue
    try:
        json.load(open(p, encoding="utf-8"))
    except Exception as e:
        print("  JSON error:", p, e); bad = 1

# 3) manifest required fields (does NOT rely on the Claude CLI being installed)
try:
    pj = json.load(open(".claude-plugin/plugin.json"))
    assert pj.get("name") and pj.get("version"), "plugin.json missing name/version"
except Exception as e:
    print("  plugin.json:", e); bad = 1
try:
    mj = json.load(open(".claude-plugin/marketplace.json"))
    assert mj.get("name") and mj.get("owner") and mj.get("plugins"), "marketplace.json missing name/owner/plugins"
except Exception as e:
    print("  marketplace.json:", e); bad = 1

sys.exit(1 if bad else 0)
