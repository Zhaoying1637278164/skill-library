#!/usr/bin/env python3
"""ship scaffold_project — the DETERMINISTIC phase-0 scaffolder and single source of truth for the
exact phase-0 working set. The primary `ship` skill and the compatibility/new-project commands invoke
THIS instead of copying files by
hand: model-driven scaffolding drifted (a weak agent dropped CONSTITUTION.md and the secret-scan/CI,
re-opening the empty-critical_rules P0). This script copies a fixed set, fills only the known scaffold
placeholders, snapshots a COMPLETE baseline, and `git init -b main`s the project. Deferred docs
(CLAUDE/PROJECT/ACCEPTANCE/DESIGN/ROADMAP/runbook/_HANDOFF/research) are authored by their own phase, so
they are NOT created here. gate_check.py verifies this inventory exists at gate 0.

    python3 scaffold_project.py <project-name> <content|saas|engine|lite> [dest_dir]

Exit 0 = scaffold complete (required inventory present). Exit 1 = incomplete. Exit 2 = usage error.
"""
import os, sys, shutil, subprocess, json

PLUGIN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TPL = os.path.join(PLUGIN, "templates")

# template basename -> destination (relative to the project). The phase-0 WORKING SET — identical for
# full and lite; only state.yml's `type` differs. Deferred docs are intentionally absent.
WORKING_SET = {
    "POSITIONING.md":        "POSITIONING.md",
    "CONSTITUTION.md":       "CONSTITUTION.md",
    "progress.md":           "progress.md",
    "env.example":           ".env.example",
    "gitignore":             ".gitignore",
    "pre-commit-config.yaml": ".pre-commit-config.yaml",
    "ci-workflow.yml":       ".github/workflows/ci.yml",
    "context-policy.yml":    ".ship/context-policy.yml",
    "state.yml":             ".ship/state.yml",
}


def plugin_version():
    try:
        return json.load(open(os.path.join(PLUGIN, ".claude-plugin", "plugin.json"), encoding="utf-8"))["version"]
    except Exception:
        return "0.0.0"


def _today():
    from datetime import date
    return date.today().isoformat()


def _fill(text, name, ptype, version, today):
    # Fill ONLY the known scaffold placeholders. The owner-fill `{{...}}` in POSITIONING (the phase-0
    # deliverable) is left intact so gate 0 blocks until the owner writes the positioning.
    return (text.replace("{{PROJECT_NAME}}", name)
                .replace("{{content|saas|engine|lite}}", ptype)
                .replace("{{YYYY-MM-DD}}", today)
                .replace("{{x.y.z}}", version))


def required_files():
    """The gate-0 required inventory — single source: spec/pipeline.yml `phase0_required_files`."""
    import yaml
    spec = yaml.safe_load(open(os.path.join(PLUGIN, "spec", "pipeline.yml"), encoding="utf-8"))
    return list(spec.get("phase0_required_files") or WORKING_SET.values())


def scaffold(name, ptype, dest):
    version, today = plugin_version(), _today()
    os.makedirs(dest, exist_ok=True)
    # 1) working set (placeholder-filled where known)
    for tpl, rel in WORKING_SET.items():
        dst = os.path.join(dest, rel)
        os.makedirs(os.path.dirname(dst) or dest, exist_ok=True)
        text = open(os.path.join(TPL, tpl), encoding="utf-8").read()
        with open(dst, "w", encoding="utf-8", newline="\n") as f:
            f.write(_fill(text, name, ptype, version, today))
    # 2) COMPLETE baseline snapshot (pristine templates) for /ship-update 3-way diffs
    bdir = os.path.join(dest, ".ship", "baseline", version)
    os.makedirs(bdir, exist_ok=True)
    for tpl in sorted(os.listdir(TPL)):
        s = os.path.join(TPL, tpl)
        if os.path.isfile(s):
            shutil.copyfile(s, os.path.join(bdir, tpl))
    # 3) git init -b main (prepares the later evidence gates; phase 0 itself is pre-evidence)
    if not os.path.isdir(os.path.join(dest, ".git")):
        subprocess.run(["git", "init", "-q", "-b", "main", dest], check=False, capture_output=True)
    return version, bdir


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("usage: scaffold_project.py <project-name> <content|saas|engine|lite> [dest_dir]")
        sys.exit(2)
    name, ptype = sys.argv[1], sys.argv[2]
    if ptype not in ("content", "saas", "engine", "lite"):
        print(f"unknown type '{ptype}' (expected content|saas|engine|lite)")
        sys.exit(2)
    dest = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.getcwd(), name)
    version, bdir = scaffold(name, ptype, dest)
    missing = [r for r in required_files() if not os.path.exists(os.path.join(dest, r))]
    print(f"scaffolded '{name}' ({ptype}) at {dest} from ship templates v{version}")
    print("phase-0 working set: " + ", ".join(WORKING_SET.values()))
    print(f"baseline: .ship/baseline/{version}/ ({len(os.listdir(bdir))} templates snapshotted)")
    print("deferred (authored by their phase, NOT scaffolded here): CLAUDE.md, PROJECT.md, ACCEPTANCE.md, "
          "DESIGN.md, ROADMAP.md, research/_INDEX.md, production_runbook.md, _HANDOFF.md")
    if missing:
        print("INCOMPLETE — missing required file(s): " + ", ".join(missing))
        sys.exit(1)
    print("required phase-0 inventory: COMPLETE")
    sys.exit(0)
