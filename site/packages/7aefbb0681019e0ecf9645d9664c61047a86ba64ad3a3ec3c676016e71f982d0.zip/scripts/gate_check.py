#!/usr/bin/env python3
"""ship gate_check — EXECUTABLE gate validator + transition. Run against a project during /gate.

Gates used to be prose the agent could "declare passed" (commit_sha: null, no scorecards,
placeholders left in, verifier = same agent). Worse, the earlier executable check only looked at
git cleanliness — it PASSED a build with `checks: build=false` and a QA phase with
`execution_status: not_run, judge=1/80`. This makes the evidence checks real AND computes the next
phase THROUGH the state machine (transition.py), so the model no longer narrates transitions.

    python3 gate_check.py <phase-name-or-number> [project_dir] [--apply]

Exit 0 = the gate MAY be passed (prints `NEXT: <n> <name>`). Exit 1 = BLOCKED (reasons printed).
`--apply` is the AUTHORITATIVE way to record a transition: it writes gate_passed, commit_sha (evidence
phases), a UTC `checked_at`, and current_phase/last_completed_phase to .ship/state.yml. A BLOCKED gate
(exit 1) never applies. Do NOT hand-edit those fields instead — that skips the checks and the checked_at
stamp and drifts state from reality (the class of bug this guards). It rewrites the YAML and does not
preserve comments; that trade-off is deliberate — the executable gate owns these fields.
"""
import os, sys, re, subprocess, glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import transition as T  # the state machine (single source: spec/pipeline.yml)

PLUGIN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_spec():
    import yaml
    return yaml.safe_load(open(os.path.join(PLUGIN, "spec", "pipeline.yml"), encoding="utf-8"))


def phase_index(spec, phase):
    if str(phase).isdigit():
        return int(phase)
    names = spec["phases"]
    p = str(phase).strip().lower().replace("-", "_")
    p = {"prod": "prod_prep", "prodprep": "prod_prep"}.get(p, p)
    return names.index(p) if p in names else None


def state_path(project):
    return os.path.join(project, ".ship", "state.yml")


def load_state(project):
    import yaml
    p = state_path(project)
    if not os.path.exists(p):
        return None
    return yaml.safe_load(open(p, encoding="utf-8"))


def phase_key(spec, idx):
    return f"{idx}_{spec['phases'][idx]}"


def git(project, *args):
    try:
        return subprocess.run(["git", "-C", project, *args], capture_output=True,
                              encoding="utf-8", errors="replace", timeout=15)
    except Exception:
        return None


def is_git_repo(project):
    r = git(project, "rev-parse", "--is-inside-work-tree")
    return bool(r and r.returncode == 0 and r.stdout.strip() == "true")


def git_head(project):
    r = git(project, "rev-parse", "HEAD")
    sha = r.stdout.strip() if r and r.returncode == 0 else None
    st = git(project, "status", "--porcelain")
    clean = bool(st and st.returncode == 0 and st.stdout.strip() == "")
    return sha, clean


SKIP_DIRS = {".git", "node_modules", "dist", ".ship", ".astro", "build", ".next", "vendor"}
SCAN_EXT = {".md", ".astro", ".html", ".ts", ".tsx", ".js", ".jsx", ".json", ".yml", ".yaml", ".css", ".mjs", ".txt"}
PLACEHOLDER_PATTERNS = [
    # ship template placeholders are `{{NAME}}`. The `(?<!\$)` skips GitHub Actions / other `${{ ... }}`
    # expressions (e.g. `${{ secrets.GITHUB_TOKEN }}` in a real ci.yml), which are NOT unrendered placeholders.
    (r"(?<!\$)\{\{[^}]+\}\}", "unrendered template placeholder {{...}}"),
    (r"\bTBD\b", "TBD left in"),
    (r"https://github\.com/[\"'>\s]", "bare github.com link (no repo path)"),
]


def find_placeholders(project):
    hits = []
    for root, dirs, files in os.walk(project):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if os.path.splitext(f)[1].lower() not in SCAN_EXT:
                continue
            fp = os.path.join(root, f)
            rel = os.path.relpath(fp, project)
            try:
                text = open(fp, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            for rx, desc in PLACEHOLDER_PATTERNS:
                if re.search(rx, text):
                    hits.append((rel, desc))
    return hits


def branch_ci_mismatch(project):
    issues = []
    r = git(project, "branch", "--show-current")
    branch = r.stdout.strip() if r and r.returncode == 0 else None
    if not branch:
        return issues
    wf_branches = set()
    for wf in glob.glob(os.path.join(glob.escape(project), ".github", "workflows", "*.y*ml")):
        txt = open(wf, encoding="utf-8", errors="ignore").read()
        for m in re.finditer(r"branches:\s*\[([^\]]*)\]", txt):
            for b in m.group(1).split(","):
                wf_branches.add(b.strip().strip("'\""))
        for m in re.finditer(r"branches:\s*((?:\n\s*-\s*\S+)+)", txt):
            for bm in re.finditer(r"-\s*(\S+)", m.group(1)):
                wf_branches.add(bm.group(1).strip("'\""))
    if wf_branches and branch not in wf_branches:
        issues.append(f"current branch '{branch}' not in any CI workflow branches {sorted(wf_branches)}")
    for doc in ("_HANDOFF.md", "production_runbook.md"):
        dp = os.path.join(project, doc)
        if os.path.exists(dp):
            t = open(dp, encoding="utf-8", errors="ignore").read()
            for m in re.finditer(r"origin\s+(\w[\w./-]*)", t):
                if m.group(1) not in (branch, "origin") and re.match(r"(main|master|deploy|prod)$", m.group(1)):
                    if m.group(1) != branch:
                        issues.append(f"{doc} says 'origin {m.group(1)}' but the branch is '{branch}'")
    return issues


def _truthy(v):
    return v is True or (isinstance(v, (int, float)) and not isinstance(v, bool) and v) or \
        (isinstance(v, str) and v.strip().lower() in ("true", "pass", "passed", "green", "ok", "yes"))


def _as_dict(v):
    return v if isinstance(v, dict) else {}


def _int(x, default=0):
    try:
        return int(x)
    except (TypeError, ValueError):          # null / 'abc' / list -> default (never crash the gate)
        return default


def _utc_now_iso():
    """ISO-8601 UTC timestamp (second precision, trailing 'Z') stamped as gate evidence on apply."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def check_state_readiness(spec, state, idx, name):
    """The real readiness gate: required checks green, QA executed + counts recorded, judge >=
    threshold, owner sign-off present. Fields that should be mappings are coerced defensively so a
    malformed legacy state.yml yields a clean BLOCKED, not a traceback."""
    reasons = []
    phases = _as_dict(state.get("phases"))
    pk = phase_key(spec, idx)
    ph = _as_dict(phases.get(pk))

    # required checks: validate against the REQUIRED key list (from spec), not just whatever keys
    # happen to be present — an empty/absent checks dict must NOT satisfy the gate.
    if idx in spec.get("check_gated_phases", []):
        checks = _as_dict(ph.get("checks"))
        required = list((spec.get("gate_required_checks") or {}).get(idx) or list(checks.keys()))
        if state.get("type") == "lite":          # lite skips staging/promotion checks at deploy
            required = [c for c in required if c not in (spec.get("lite_skip_checks") or [])]
        if not required:
            reasons.append(f"no required checks known for phase {idx} and none recorded — cannot pass")
        for k in required:
            if k not in checks or checks.get(k) is None:
                reasons.append(f"check '{k}' not run (missing/null) — run it and record the result")
            elif not _truthy(checks.get(k)):
                reasons.append(f"check '{k}' is failing ({checks.get(k)!r}) — fix it before the gate")

    # QA(4): panel executed + verified, AND the verified counts were actually recorded (so routing
    # to skip-Fix vs enter-Fix is based on real triage, not an unset field defaulting to 0).
    if idx == 4:
        qa = _as_dict(ph.get("qa"))
        if qa.get("execution_status") != "complete":
            reasons.append(f"QA execution_status is {qa.get('execution_status')!r}, expected 'complete'")
        if not _truthy(qa.get("panel_verified")):
            reasons.append("QA panel not verified (panel_verified is not true)")
        if spec.get("qa_requires_recorded_counts", True):
            for k in ("verified_critical", "verified_major"):
                v = qa.get(k)
                if v is None or isinstance(v, bool) or not isinstance(v, int):
                    reasons.append(f"QA {k} not recorded as an integer — triage the panel before routing")

    # judge score >= threshold for artifact-heavy phases
    if idx in spec.get("judge_phases", []):
        judge = _as_dict(ph.get("judge"))
        score, thr = judge.get("score"), judge.get("threshold", 80)
        if score is None:
            reasons.append("judge score not recorded — run ship-gate-judge")
        elif not isinstance(score, (int, float)) or isinstance(score, bool) or score < (thr or 80):
            reasons.append(f"judge score {score} below threshold {thr}")

    # Fix(5) is NOT hard-blocked on quality_clean — that is a ROUTING decision: transition_for(5)
    # sends a not-clean Fix back to QA(4) and a clean Fix forward to 6 (the 5<->4 loop). See transition.py.

    # owner sign-off present for owner-gated phases
    if idx in spec.get("owner_signoff_phases", []):
        if not any(_as_dict(s).get("phase") == idx for s in (state.get("signoffs") or [])):
            reasons.append(f"awaiting OWNER sign-off for phase {idx} (no signoffs entry with phase: {idx})")

    return reasons


def _verified_counts(state):
    phases = _as_dict(state.get("phases"))
    qa = _as_dict(_as_dict(phases.get("4_qa")).get("qa"))
    fx = _as_dict(_as_dict(phases.get("5_fix")).get("fix"))
    vc = qa.get("verified_critical")
    vm = qa.get("verified_major")
    if vc is None:
        vc = fx.get("verified_critical", 0)
    if vm is None:
        vm = fx.get("verified_major", 0)
    return _int(vc), _int(vm)


def transition_for(spec, state, idx):
    ptype = state.get("type", "full")
    if idx == 4:
        vc, vm = _verified_counts(state)
        return T.next_phase(spec, ptype, 4, "qa_complete", verified_critical=vc, verified_major=vm)
    if idx == 5:
        fx = _as_dict(_as_dict(_as_dict(state.get("phases")).get("5_fix")).get("fix"))
        try:
            vc, vm = int(fx.get("verified_critical") or 0), int(fx.get("verified_major") or 0)
        except (TypeError, ValueError):
            vc, vm = 1, 1                        # garbage counts -> NOT clean -> loop back to QA (fail-closed)
        return T.next_phase(spec, ptype, 5, "gate_pass", verified_critical=vc, verified_major=vm,
                            required_tests_green=fx.get("required_tests_green", False))
    return T.next_phase(spec, ptype, idx, "gate_pass")


def check_gate(project, phase):
    spec = load_spec()
    idx = phase_index(spec, phase)
    if idx is None:
        return False, [f"unknown phase: {phase}"], None
    name = spec["phases"][idx]
    reasons = []
    state = load_state(project)
    if state is None:
        return False, ["no .ship/state.yml — not a ship project"], None

    # 1) git evidence for code/artifact phases
    if idx in spec.get("evidence_phases", []) and is_git_repo(project):
        sha, clean = git_head(project)
        if not sha:
            reasons.append("git repo but no commit yet — commit this phase's work so the gate binds to a SHA")
        elif not clean:
            reasons.append("worktree is dirty — commit (or the gate must record commit_sha: dirty and warn)")

    # 2) placeholders anywhere = not production-ready
    for rel, desc in find_placeholders(project):
        reasons.append(f"placeholder in {rel}: {desc}")

    # 2b) phase-0 scaffold completeness — the deterministic scaffolder (scaffold_project.py) writes a
    #     fixed working set; gate 0 HARD-BLOCKS if any required file is missing, so a drifted or
    #     hand-rolled scaffold (e.g. one that dropped CONSTITUTION.md -> empty critical_rules) can't pass.
    if idx == 0:
        for rel in (spec.get("phase0_required_files") or []):
            if not os.path.exists(os.path.join(project, *rel.split("/"))):
                reasons.append(f"phase-0 scaffold incomplete: missing required file {rel}")

    # 3) NEW — real readiness: checks / QA / judge / quality_clean / owner sign-off
    reasons += check_state_readiness(spec, state, idx, name)

    # 4) scorecard must exist if a judge score is recorded for this phase. Accept BOTH the canonical
    #    `<idx>_<name>.md` and the bare `<name>.md` some docs used, so a real gate isn't falsely blocked.
    pk = phase_key(spec, idx)
    judge = _as_dict(_as_dict(_as_dict(state.get("phases")).get(pk)).get("judge"))
    if judge.get("score") is not None:
        gdir = os.path.join(project, ".ship", "gates")
        if not any(os.path.exists(os.path.join(gdir, f"{n}.md")) for n in (pk, name)):
            reasons.append(f"judge.score recorded but no scorecard at .ship/gates/{pk}.md")

    # 5) branch / CI / deploy consistency — hard fail at deploy(8), warn earlier
    bmis = branch_ci_mismatch(project)
    if bmis:
        reasons.extend(bmis if idx == 8 else [f"(warn) {m}" for m in bmis])

    # 6) pipeline-engagement signal (soft) — no context pack for an evidence phase means the
    #    Phase-Isolated pipeline (the token economy) was probably not engaged for this phase.
    #    glob.escape(project) so a project path with [ ] * ? isn't parsed as a glob pattern (false warn),
    #    and require a real FILE (a dir named like a pack is not a pack).
    if idx in spec.get("evidence_phases", []):
        _packs = [p for p in glob.glob(os.path.join(glob.escape(project), ".ship", "context",
                                                    "*", f"{idx}-*.yml")) if os.path.isfile(p)]
        if not _packs:
            reasons.append(f"(warn) no context pack for phase {idx} — the Phase-Isolated pipeline may not be "
                           f"engaged (token economy off); see `/ship-status` or `/ship:pack build {idx}`")

    hard = [r for r in reasons if not r.startswith("(warn)")]
    nxt = transition_for(spec, state, idx) if not hard else None
    return (len(hard) == 0), reasons, nxt


def _write_state(project, state):
    import yaml
    with open(state_path(project), "w", encoding="utf-8", newline="\n") as f:
        yaml.safe_dump(state, f, sort_keys=False, allow_unicode=True)


def apply_transition(project, idx, nxt):
    """Write the transition to state.yml (rewrites YAML — comments are NOT preserved). Two ORTHOGONAL
    decisions, so the Fix(5) edge cases stop tangling:

      (A) PHASE STAMP — does phase `idx` get marked done? Depends ONLY on (idx, nxt): a Fix(5) that
          routes back to QA(4) is not a clean completion (in_progress); everything else is done. This
          is identical whether it's the current phase or a re-check — a re-check reflects reality.
      (B) POINTER MOVE — do current_phase/last_completed_phase move? ONLY when idx is the current phase
          (a re-check never moves the pointer), and current_phase never REGRESSES except the Fix(5)->QA(4)
          loop. A missing/null current_phase is treated as 'this is the live phase'.

    Returns: 're-certify' (pointer untouched) | 'loop-back' (Fix->QA) | 'advance' (normal forward)."""
    state = load_state(project)
    spec = load_spec()
    pk = phase_key(spec, idx)
    phases = state.setdefault("phases", {})
    ph = _as_dict(phases.get(pk))
    phases[pk] = ph
    cur = state.get("current_phase")
    cur_int = cur if (isinstance(cur, int) and not isinstance(cur, bool)) else None
    sha, _ = git_head(project)
    fix_loopback = (idx == 5 and nxt == 4)       # Fix routing back to QA — NOT a clean completion

    # (A) stamp phase idx's own gate result. checked_at is written on EVERY successful apply
    # (advance / loop-back / re-certify); commit_sha is recorded whenever a HEAD exists — evidence
    # phases (1..8) only reach apply once check_gate confirmed a bound, clean SHA, so theirs is validated.
    ph["gate_passed"] = not fix_loopback
    ph["status"] = "in_progress" if fix_loopback else "done"
    if sha:
        ph["commit_sha"] = sha
    ph["checked_at"] = _utc_now_iso()

    # (B) only the CURRENT phase moves the pipeline pointer (null current == treat idx as current)
    if cur_int is not None and idx != cur_int:
        _write_state(project, state)
        return "re-certify"

    state["last_completed_phase"] = idx          # ledger: the phase that just ran feeds the next pack
    if nxt is not None and (cur_int is None or nxt >= cur_int or fix_loopback):
        state["current_phase"] = nxt             # never regress except the sanctioned Fix(5)->QA(4) loop
    # QA(4) exiting clean to 6 closes out a lingering Fix(5) record — but ONLY if that Fix is genuinely
    # quality_clean per its own data (incl. required_tests_green). A Fix that looped back because tests
    # were red must NOT be force-certified "done" by an unrelated QA re-triage (that broke the canonical
    # quality_clean invariant). If it isn't clean, leave it in_progress — an honest, visible loose end.
    # (No count-zeroing needed: the redesign makes a later stale re-check a harmless 're-certify'.)
    if idx == 4 and nxt == 6:
        fk = phase_key(spec, 5)
        fx = _as_dict(phases.get(fk))
        if fx and not fx.get("gate_passed"):
            ff = _as_dict(fx.get("fix"))
            try:  # a GARBAGE count means we can't confirm clean -> leave it in_progress (fail-closed)
                clean = T.quality_clean(int(ff.get("verified_critical") or 0),
                                        int(ff.get("verified_major") or 0),
                                        ff.get("required_tests_green", False))
            except (TypeError, ValueError):
                clean = False
            if clean:
                fx["gate_passed"] = True
                fx["status"] = "done"
                phases[fk] = fx
    _write_state(project, state)
    return "loop-back" if fix_loopback else "advance"


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--apply"]
    do_apply = "--apply" in sys.argv
    if not args:
        print("usage: gate_check.py <phase> [project_dir] [--apply]"); sys.exit(2)
    phase = args[0]
    project = args[1] if len(args) > 1 else os.getcwd()
    ok, reasons, nxt = check_gate(project, phase)
    for r in reasons:  # ASCII only — Windows consoles (cp1251/1252) can't encode ✗/⚠
        print(("  ! " if r.startswith("(warn)") else "  x ") + r.replace("(warn) ", ""))
    spec = load_spec()
    idx = phase_index(spec, phase)
    print(f"gate_check[{phase}]: {'PASS' if ok else 'BLOCKED'}")
    if ok and nxt is not None:
        term = T.is_terminal(spec, (load_state(project) or {}).get("type", "full"), idx)
        print(f"NEXT: {nxt} {spec['phases'][nxt]}" + ("  (terminal — stays put)" if nxt == idx and term else ""))
        if do_apply:
            mode = apply_transition(project, idx, nxt)
            if mode == "re-certify":
                print(f"re-certified phase {idx} only (it is not the current phase {(load_state(project) or {}).get('current_phase')}); "
                      f"current_phase/last_completed_phase left unchanged")
            else:
                print(f"applied ({mode}): current_phase -> {nxt}, last_completed_phase -> {idx} (state.yml rewritten)")
    sys.exit(0 if ok else 1)
