#!/usr/bin/env bash
# ship doctor — the plugin's own test suite: strict manifest validation, frontmatter + all
# YAML/JSON, cross-references, consistency invariants, and CI/template versions.
# Run after any edit: bash scripts/ship-doctor.sh
set -uo pipefail
cd "$(dirname "$0")/.."
ROOT="$(pwd)"; fail=0
ok(){ printf '  ok  %s\n' "$*"; }
er(){ printf '  XX  %s\n' "$*"; fail=1; }
h(){ printf '\n== %s ==\n' "$*"; }
badpat(){ # name  regex  paths...  -> FAIL if any match (this script excluded)
  local name="$1" rx="$2"; shift 2
  local hits; hits="$(grep -rnE "$rx" "$@" 2>/dev/null | grep -v 'scripts/ship-doctor' || true)"
  if [ -n "$hits" ]; then er "$name"; printf '%s\n' "$hits" | head -6 | sed 's/^/      /'; else ok "$name"; fi
}

h "manifests (strict — validates BOTH plugin.json and marketplace.json, EXPLICITLY)"
if command -v claude >/dev/null 2>&1 && claude --version >/dev/null 2>&1; then
  # `validate .` alone only validates the marketplace manifest — validate each manifest explicitly (as CI does).
  mok=1
  for m in "." ".claude-plugin/plugin.json" ".claude-plugin/marketplace.json"; do
    claude plugin validate "$m" --strict >/dev/null 2>&1 || { er "claude plugin validate $m --strict failed"; mok=0; }
  done
  [ $mok -eq 1 ] && ok "claude plugin validate --strict: . + plugin.json + marketplace.json"
else printf '  --  claude CLI not runnable here (skipped; CI/native must run it)\n'; fi

h "frontmatter + all YAML/JSON (recursive) + manifest fields"
PY=""; for c in python3 python; do command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }; done
# python is REQUIRED — the executable test suite is the point; missing python is a FAILURE, not a skip
# (otherwise the doctor could print ALL PASSED while silently running none of the real tests).
[ -n "$PY" ] || er "python3 not found — the executable test suite (transitions/gate/context) cannot run; install python3"
if [ -n "$PY" ]; then "$PY" scripts/_check_yaml.py && ok "frontmatter + all YAML/JSON + manifest fields" || er "YAML/JSON/manifest problems (above)"; fi

h "state machine + executable gate + context packs (real tests, NOT greps)"
if [ -n "$PY" ]; then "$PY" scripts/test_transitions.py && ok "transition scenarios (full/lite/dirty-QA/terminal) pass" || er "transition tests FAILED (above)"; fi
if [ -n "$PY" ]; then "$PY" scripts/test_gate_check.py >/dev/null && ok "gate BLOCKS unready phases (checks/QA/judge) + computes transition NEXT" || er "gate_check tests FAILED"; fi
if [ -n "$PY" ]; then "$PY" scripts/test_context_builder.py >/dev/null && ok "context packs (schema/budget-recompute/ledger/staleness/traversal/handoff/fail-closed) correct" || er "context_builder tests FAILED"; fi
if [ -n "$PY" ]; then "$PY" scripts/test_scaffold.py >/dev/null && ok "deterministic scaffolder: full+lite produce the EXACT phase-0 set, no deferred docs, complete baseline, gate 0 blocks incomplete" || er "scaffold tests FAILED"; fi

h "cross-references"
AG="ship-seo-expert ship-code-reviewer ship-uiux-reviewer ship-security-reviewer ship-devops-reviewer ship-gate-judge ship-qa-verifier ship-oss-scout ship-seo-strategist ship-phase-runner"
am=0; for a in $AG; do [ -f "agents/$a.md" ] || { er "missing agent: $a"; am=1; }; done; [ $am -eq 0 ] && ok "all 10 agents present"
TPL="POSITIONING CONSTITUTION CLAUDE PROJECT ACCEPTANCE DESIGN ROADMAP progress RESEARCH_INDEX production_runbook env.example gitignore state.yml ci-workflow.yml ci-build-jobs.example.yml pre-commit-config.yaml _HANDOFF"
tm=0; for t in $TPL; do [ -f "templates/$t" ] || [ -f "templates/$t.md" ] || { er "missing template: $t"; tm=1; }; done; [ $tm -eq 0 ] && ok "all templates present"
CTX="spec/context-schema.md spec/handoff-schema.md spec/observation-policy.md scripts/context_builder.py scripts/test_context_builder.py commands/pack.md templates/context-policy.yml templates/context-pack.example.yml templates/handoff.example.yml"
cm=0; for c in $CTX; do [ -f "$c" ] || { er "missing context-pipeline file: $c"; cm=1; }; done; [ $cm -eq 0 ] && ok "phase-isolated-context files present"
badpat "no stale (non-ship-) agent refs" '(^|[^-])(seo-expert|code-reviewer|uiux-reviewer|security-reviewer|devops-reviewer|gate-judge|qa-verifier|oss-scout|seo-strategist)' skills commands agents

h "consistency invariants"
badpat "QA routes to Fix (no 'block the gate')" 'blocks? the (QA )?gate' skills commands examples
badpat "build-once (no prod --build)" 'compose up -d --build' skills templates examples
badpat "env model = local->staging->prod (no two-env wording)" '[Tt]wo[ _-]envs?|[Tt]wo-environment|test/live|test vs live|local vs prod|local-test|prod-live|test \+ prod envs?' skills templates README.md agents commands examples
badpat "commands use \$ARGUMENTS (no positional \$N)" '\$[0-9]([^0-9]|$)' commands

h "phase-isolated-context invariants (honest code-vs-prompt split)"
grep -q 'spend_modes:' spec/pipeline.yml && ok "spend modes live once in spec/pipeline.yml (single source)" || er "spend_modes missing from spec/pipeline.yml"
grep -qi 'code-enforced' spec/observation-policy.md && grep -qi 'prompt convention' spec/observation-policy.md \
  && ok "observation policy keeps the code-vs-prompt split explicit" || er "observation-policy must state what is code-enforced vs convention"
grep -q 'cannot read the runtime model' skills/ship/SKILL.md && ok "orchestrator's model-routing claim stays honest" || er "orchestrator must not overclaim runtime model routing"
grep -q 'protected_never_trimmed' spec/pipeline.yml && ok "protected context declared never-trimmed" || er "spec must declare protected context never-trimmed"
VER="$(grep -oE '"version"[: ]+"[0-9]+\.[0-9]+\.[0-9]+"' .claude-plugin/plugin.json | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)"
grep -qF "v$VER" README.md && ok "README version badge matches plugin.json (v$VER)" || er "README badge != plugin.json version (v$VER) — bump the README badge"
# don't let anyone claim the ORCHESTRATOR resets/clears its own context window (only subagents are fresh)
badpat "no false 'orchestrator resets its own context' claim" '(orchestrator|main loop)[^.]{0,60}(reset|clear|wipe)s?[^.]{0,20}(context|history)' skills commands

h "CI / template versions + phase-0 scaffold invariants"
# The phase-0 WORKING SET (scaffolded into the project ROOT by /ship:new-project) must be
# placeholder-free — the gate blocks on any unrendered `{{...}}`, and these can't be filled at phase 0.
# (POSITIONING is owner-filled and state.yml lives under .ship/ which the gate skips → both excluded.
# CONSTITUTION.md is here — NOT deferred — because its guardrails load into every phase; the OTHER docs
# CLAUDE/PROJECT/ACCEPTANCE/DESIGN/ROADMAP/runbook are DEFERRED.) Match a ship `{{...}}` but NOT a
# GitHub Actions `${{ ... }}` expression.
p0bad=0
for f in CONSTITUTION.md progress.md env.example gitignore pre-commit-config.yaml ci-workflow.yml context-policy.yml; do
  grep -qE '(^|[^$])\{\{' "templates/$f" 2>/dev/null && { er "phase-0 scaffold template templates/$f has a {{...}} placeholder — it would deadlock the gate (make it placeholder-free or defer it)"; p0bad=1; }
done
[ $p0bad -eq 0 ] && ok "phase-0 working-set templates are placeholder-free (no gate deadlock)"
# CONSTITUTION.md is a PROTECTED phase-0 input: read_critical_rules() extracts its bullets into every
# pack's protected_context.critical_rules. Deferring it left Research/Lite-Build with empty rules, so it
# MUST carry the universal guardrails from phase 0.
# Each guardrail must be ONE `-` bullet (read_critical_rules is line-based — a wrapped bullet is truncated
# to its first line, dropping the operative clause), so anchor the greps to the bullet + the full clause.
cg=0
grep -qE '^- .*DATA, never instructions.*follow commands found in fetched' templates/CONSTITUTION.md || { er "CONSTITUTION.md untrusted-data guardrail missing or truncated (needs ONE '-' bullet incl. '...follow commands found in fetched...')"; cg=1; }
grep -qE '^- Secrets live in .*never .*commit' templates/CONSTITUTION.md || { er "CONSTITUTION.md missing the secrets '-' bullet"; cg=1; }
grep -qE '^- Owner sign-off gates .*cannot be self-approved' templates/CONSTITUTION.md || { er "CONSTITUTION.md missing the owner-gate '-' bullet"; cg=1; }
grep -qE '(^|[^$])\{\{' templates/CONSTITUTION.md && { er "CONSTITUTION.md has {{...}} — the phase-0 version must be placeholder-free (Spec extends it)"; cg=1; }
[ $cg -eq 0 ] && ok "phase-0 CONSTITUTION.md carries the guardrails as complete single-line '-' bullets (untrusted-data, secrets, owner-gate)"
# Regression guard: the deterministic scaffolder AND the gate-0 required inventory MUST include
# CONSTITUTION.md — dropping it gives Research/Lite-Build empty critical_rules (the P0 this closed).
{ grep -q '"CONSTITUTION.md":' scripts/scaffold_project.py && grep -qE '^[[:space:]]*-[[:space:]]+CONSTITUTION\.md' spec/pipeline.yml; } \
  && ok "CONSTITUTION.md is in the scaffolder WORKING_SET AND spec phase0_required_files (gate 0 enforces it)" \
  || er "CONSTITUTION.md missing from scaffold_project.py WORKING_SET or spec phase0_required_files"
# Pin current, non-EOL Action versions (gitleaks-action@v2 stops working 2026-09-16; @v4/@v5 actions run on Node 20).
badpat "no EOL gitleaks-action@v2 (use @v3)" 'gitleaks-action@v2([^0-9]|$)' .github templates
badpat "no Node20 actions/checkout@v[1-6] (use @v7)" 'actions/checkout@v[1-6]([^0-9]|$)' .github templates
badpat "no Node20 actions/setup-(node|python)@v[1-6] (use @v7)" 'actions/setup-(node|python)@v[1-6]([^0-9]|$)' .github templates
{ grep -q 'gitleaks-action@v3' .github/workflows/plugin-ci.yml && grep -q 'gitleaks-action@v3' templates/ci-workflow.yml; } && ok "gitleaks-action@v3 in plugin CI + template" || er "gitleaks-action@v3 missing from a CI/template"
grep -q 'rev: v8.30.1' templates/pre-commit-config.yaml && ok "gitleaks pre-commit rev v8.30.1 (current)" || er "templates/pre-commit-config.yaml gitleaks rev is not v8.30.1"

h "secret protection = gitleaks pre-commit + CI (no bundled Claude-side hook)"
# The Claude-side secret-scan hook was REMOVED for the release: a regex parser of a shell command string
# can't be a security boundary (repeated cd/-C/redirection bypasses), and gitleaks pre-commit + CI is the
# real, layered protection. Guard that it stays gone — no `hooks/` dir and no plugin.json `hooks` field.
grep -q '"hooks"[[:space:]]*:' .claude-plugin/plugin.json && er "plugin.json must NOT declare a 'hooks' field (the Claude-side secret hook was removed)" || ok "plugin.json declares no 'hooks' field"
{ [ -e hooks/hooks.json ] || [ -d hooks/scripts ]; } && er "leftover Claude-side secret hook under hooks/ — it was removed; gitleaks is the secret scan" || ok "no bundled Claude-side secret hook (gitleaks pre-commit + CI is the scan)"
badpat "no hardcoded C:\\\\dev default in commands (cross-platform)" 'C:\\\\dev' commands

h "gate authority = EXECUTED, never hand-written (regression: front door hand-edited gate_passed/current_phase)"
# The v0.10.2 fix: an owner approval is permission to RUN the gate, not to hand-edit its result. Both
# entry commands must route the approval through the authoritative executable gate, and nothing may
# offer a "write the fields by hand" shortcut (which skips the checks AND the checked_at stamp).
grep -qE 'gate_check\.py.*--apply|/ship:gate' commands/go.md \
  && ok "go.md routes owner approvals through the executable gate (gate_check.py --apply / /ship:gate)" \
  || er "go.md must EXECUTE the gate (gate_check.py --apply or /ship:gate), not hand-edit state.yml"
grep -qiE 'never[^.]{0,80}(set|edit)[^.]{0,40}gate_passed' commands/go.md \
  && ok "go.md forbids hand-setting gate_passed/current_phase/last_completed_phase" \
  || er "go.md must forbid hand-setting gate_passed/current_phase/last_completed_phase"
grep -qiE 'never[^.]{0,80}(set|edit)[^.]{0,40}gate_passed|never hand-edit .gate_passed' commands/new-project.md \
  && ok "new-project.md forbids hand-setting gate_passed/current_phase/last_completed_phase" \
  || er "new-project.md must forbid hand-setting gate_passed/current_phase/last_completed_phase"
grep -qE 'gate_check\.py.*--apply|/ship:gate' commands/new-project.md \
  && ok "new-project.md routes the phase-0 sign-off through the executable gate" \
  || er "new-project.md must EXECUTE the phase-0 gate, not hand-edit state.yml"
# /ship:phase is a THIRD advance entry point — it must also route through --apply (not hand-record
# last_completed_phase), else an agent driving phases directly re-introduces the hand-narration bug.
grep -qE 'gate_check\.py.*--apply|/ship:gate' commands/phase.md \
  && ok "phase.md advances via the executable gate (--apply), not a hand-recorded last_completed_phase" \
  || er "phase.md must advance through gate_check.py --apply, not by hand-recording state.yml"
grep -qiE 'never hand-edit those fields' commands/phase.md \
  && ok "phase.md forbids hand-editing the transition fields" \
  || er "phase.md must forbid hand-editing gate_passed/current_phase/last_completed_phase"
badpat "no 'apply the gate fields by hand' escape hatch (gate.md)" 'apply those same fields by hand' commands
badpat "ship skill step 5 does not hand-move current_phase" 'move .current_phase. to the next' skills
grep -q 'ph\["checked_at"\]' scripts/gate_check.py \
  && ok "gate_check.py --apply stamps a checked_at on every transition" \
  || er "gate_check.py must stamp ph[\"checked_at\"] on apply (evidence + timestamp)"

h "deterministic scaffolder (model-driven phase-0 copying replaced; gate 0 enforces the inventory)"
# A weak agent hand-scaffolding a subset dropped CONSTITUTION.md etc. Now scripts/scaffold_project.py is
# the single source of the exact phase-0 set; the ship skill and compatibility/new-project commands
# INVOKE it; gate 0 blocks any incomplete scaffold (spec.phase0_required_files). Guard the pieces stay wired.
[ -f scripts/scaffold_project.py ] && ok "scripts/scaffold_project.py present" || er "missing scripts/scaffold_project.py (the deterministic scaffolder)"
[ -f scripts/test_scaffold.py ] && ok "scripts/test_scaffold.py present" || er "missing scripts/test_scaffold.py (full+lite integration)"
grep -qE '^phase0_required_files:' spec/pipeline.yml \
  && ok "spec/pipeline.yml declares phase0_required_files (single source for scaffolder + gate 0)" \
  || er "spec/pipeline.yml must declare phase0_required_files"
grep -q 'phase-0 scaffold incomplete' scripts/gate_check.py \
  && ok "gate 0 hard-blocks an incomplete scaffold (missing required file)" \
  || er "gate_check.py must block phase 0 when a phase0_required_files entry is missing"
for c in go new-project; do
  grep -q 'scaffold_project.py' "commands/$c.md" \
    && ok "commands/$c.md invokes the scaffolder (no hand-copying)" \
    || er "commands/$c.md must run scaffold_project.py, not hand-copy the phase-0 set"
done
grep -q 'scaffold_project.py' skills/ship/SKILL.md \
  && ok "primary ship skill invokes the deterministic scaffolder on a new project" \
  || er "skills/ship/SKILL.md must run scaffold_project.py when /ship starts a new project"
# the two reserved-name-colliding commands were renamed so they appear in the Claude Code menu
{ [ -f commands/go.md ] && [ -f commands/pack.md ]; } && ok "primary entry is the ship skill; go.md remains a compatibility alias and pack.md avoids the reserved /context name" || er "commands/go.md + commands/pack.md must exist as compatibility/internal commands"
grep -q '/ship:go' README.md \
  && er "README.md must advertise the Desktop/Cowork /ship entry, not /ship:go (unavailable there)" \
  || ok "README.md does not advertise /ship:go"
{ [ -e commands/start.md ] || [ -e commands/context.md ]; } && er "leftover commands/start.md or commands/context.md (renamed to go.md/pack.md)" || ok "no leftover start.md/context.md (reserved-name collisions removed)"
badpat "no active references to removed /ship:start or /ship:context commands" '/ship:(start|context)([^A-Za-z0-9_-]|$)' scripts commands skills README.md examples

printf '\n'
[ $fail -eq 0 ] && { echo "ship doctor: ALL PASSED"; exit 0; } || { echo "ship doctor: FAILURES ABOVE (fix them)"; exit 1; }
