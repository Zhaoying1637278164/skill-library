#!/usr/bin/env python3
"""ship context_builder — the Phase-Isolated Context Pipeline.

Builds a compact, budget-bounded CONTEXT PACK for ONE pipeline phase, and validates
(`check`) that a pack is well-formed, inside budget, and has NOT silently dropped
protected context (owner permissions / critical rules). The point: each phase runs in
a fresh agent that receives the *minimum sufficient* context — the phase's inputs
(spec/design/code-map + the diff since the previous phase) — instead of re-reading the
whole project and chat history every step (the real cost driver — 65M cache-read tokens
on the Skillbin run).

Usage:
    python3 context_builder.py build <phase> [project]        # -> writes a pack, prints its path
    python3 context_builder.py check <pack.yml> [project]     # exit 0 = ok, 1 = BLOCKED
    python3 context_builder.py check-handoff <handoff.yml>    # validate a handoff file
    python3 context_builder.py migrate [project]              # synthesize a prior handoff (legacy projects)

Consistent with the repo's other tooling (transition.py, gate_check.py): Python 3 +
PyYAML only. No NEW dependency, no network, no AST library — a regex/stdlib repo-map with
a safe fallback for unknown languages. Degrades to a clear error if PyYAML is missing.
Fail-CLOSED: a corrupt state/policy raises rather than silently dropping owner permissions.
"""
import os, sys, re, math, hashlib, subprocess

try:
    import yaml
except Exception:  # same graceful degradation as _check_yaml.py
    sys.stderr.write("context_builder: pyyaml missing (pip install pyyaml)\n")
    sys.exit(3)

PLUGIN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCHEMA_VERSION = 1
DEFAULT_MAX_TOKENS = 2500
HANDOFF_MAX_TOKENS = 2000          # a handoff bigger than this defeats the token economy
TOKEN_METHOD = "chars/3.5 heuristic (no tokenizer dependency; conservative — over-counts vs real BPE)"

DEFAULT_EXCLUDES = [
    "node_modules", "dist", ".astro", "coverage", ".next", "build", "vendor", "target",
    ".git", ".ship", "research/raw", "__pycache__",  # .ship = ship's own control dir, not project changes
]
LOCK_FILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock",
              "Cargo.lock", "composer.lock", "Gemfile.lock"}
BINARY_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".pdf", ".zip", ".gz",
              ".woff", ".woff2", ".ttf", ".mp4", ".mov", ".exe", ".dll", ".so", ".dylib", ".pyc"}

HEADER = ("# ship context pack — minimal sufficient context for ONE phase (generated; do not hand-edit).\n"
          "# schema: spec/context-schema.md · rebuild: /ship:pack build <phase> · verify: /ship:pack check <file>\n")

PHASE_OBJECTIVE = {
    "idea": "Confirm positioning / ICP / category with the owner.",
    "research": "Gather strategy + prior-art/reuse verdict (do NOT build).",
    "spec": "Freeze a buildable spec with machine-checkable acceptance criteria.",
    "build": "Implement to the spec; wire envs; self-check green.",
    "qa": "Verify the built product (functional + browser + expert panel + verify).",
    "fix": "Close verified criticals/majors; re-run eval green.",
    "prod_prep": "Complete the production runbook checklist.",
    "provision": "Ready server + SSH + services + firewall + backup-restore.",
    "deploy": "Promote the immutable artifact; smoke test staging then prod.",
    "monitor": "Confirm uptime + alerts; queue the next items.",
}
PHASE_DEFAULT_CHECKS = {
    "build": ["build", "unit/integration tests", "typecheck + lint", "secret-scan"],
    "qa": ["tests", "typecheck + lint", "grade ACCEPTANCE.md", "browser: primary journey (UI)"],
    "fix": ["re-run the failing tests", "re-run eval/calibration"],
    "prod_prep": ["runbook checklist", "CI generated", "backup plan"],
    "provision": ["ssh key-only", "firewall", "services + timers", "backup restore test"],
    "deploy": ["artifact equal across envs", "staging smoke", "prod smoke", "rollback point"],
    "monitor": ["alert fires", "error review", "backup ok"],
}
# Phase-relevant input docs (the architecture/design/spec a fresh agent needs). Always-relevant
# docs (CONSTITUTION/CLAUDE) are added on top. CONSTITUTION/ACCEPTANCE also live in protected source_files.
PHASE_INPUTS = {
    "idea": ["POSITIONING.md"],
    "research": ["POSITIONING.md", "PROJECT.md", "research/_INDEX.md"],
    "spec": ["POSITIONING.md", "PROJECT.md", "DESIGN.md", "research/_INDEX.md"],
    "build": ["PROJECT.md", "DESIGN.md", "ACCEPTANCE.md"],
    "qa": ["PROJECT.md", "DESIGN.md", "ACCEPTANCE.md", "audits/verified.md"],
    "fix": ["audits/verified.md", "ACCEPTANCE.md", "PROJECT.md"],
    "prod_prep": ["production_runbook.md", "PROJECT.md"],
    "provision": ["production_runbook.md"],
    "deploy": ["production_runbook.md", "PROJECT.md"],
    "monitor": ["ROADMAP.md", "production_runbook.md"],
}
ALWAYS_INPUTS = ["CONSTITUTION.md", "CLAUDE.md"]
# phase name aliases: /phase uses "prod"; the sequence uses "prod_prep".
_ALIASES = {"prod": "prod_prep", "prodprep": "prod_prep"}


class BudgetError(Exception):
    pass


class StateError(Exception):
    """Raised when state/policy is corrupt — fail CLOSED, never silently drop permissions."""


class PackError(Exception):
    pass


# ---- tokens -----------------------------------------------------------------
def est_tokens(text):
    return math.ceil(len(text) / 3.5)


def _as_dict(v):
    return v if isinstance(v, dict) else {}


def _as_list(v):
    return v if isinstance(v, list) else []


# ---- paths ------------------------------------------------------------------
def norm(p):
    return p.replace("\\", "/")


def _within(base, target):
    """True iff realpath(target) is inside realpath(base) — blocks ../ and symlink escapes."""
    try:
        base_r = os.path.realpath(base)
        tgt_r = os.path.realpath(target)
        return os.path.commonpath([base_r, tgt_r]) == base_r
    except Exception:
        return False


def _is_abs_path(s):
    """Absolute on ANY platform — os.path.isabs is platform-dependent (on Linux a Windows drive path
    'C:/Windows/win.ini' is NOT absolute), so a crafted pack could smuggle it past a POSIX checker.
    Reject POSIX-root, Windows drive (C:\\ or C:/), and UNC (\\\\server) explicitly."""
    s = str(s)
    u = s.replace("\\", "/")
    return (os.path.isabs(s) or u.startswith("/")
            or bool(re.match(r"^[A-Za-z]:", u))           # C:\ / C:/ (absolute) AND C:temp (drive-relative)
            or u.startswith("//"))                        # UNC \\server\share


def _safe_project_join(project, rel):
    """Join a PACK-SUPPLIED path under project, or None if it is absolute, empty, or escapes the root.
    A crafted pack must never turn `check` into an arbitrary-file read/hash oracle (or hash a dir)."""
    if rel is None:
        return None
    s = str(rel)
    if not s.strip():                          # empty/whitespace would resolve to the project root
        return None
    if _is_abs_path(s):                         # absolute on ANY OS (POSIX-root / Windows drive / UNC)
        return None
    ap = os.path.join(project, s)
    return ap if _within(project, ap) else None


# ---- git (same shape as gate_check.py; never shells a split string) ----------
def git(project, *args):
    try:
        # utf-8 decode (not locale) so non-ASCII paths survive on Windows cp1251 consoles.
        return subprocess.run(["git", "-C", project, *args],
                              capture_output=True, encoding="utf-8", errors="replace", timeout=15)
    except Exception:
        return None


def is_git(project):
    r = git(project, "rev-parse", "--is-inside-work-tree")
    return bool(r and r.returncode == 0 and r.stdout.strip() == "true")


def head_sha(project):
    r = git(project, "rev-parse", "HEAD")
    return r.stdout.strip() if r and r.returncode == 0 else None


def worktree_status(project):
    r = git(project, "status", "--porcelain")
    if not (r and r.returncode == 0):
        return None
    return "clean" if r.stdout.strip() == "" else "dirty"


def _parse_paths(text):
    # porcelain v1: "XY PATH" — 2 status chars, a space, then the path from column 3.
    out = set()
    for line in text.splitlines():
        if len(line) < 4:
            continue
        p = line[3:].strip()
        if " -> " in p:                        # rename: "old -> new"
            p = p.split(" -> ", 1)[1].strip()
        p = p.strip('"')
        if p:
            out.add(p)
    return out


def status_changed(project):
    """staged + unstaged + untracked, handling renames and quoted/spaced paths."""
    if not is_git(project):
        return set()
    r = git(project, "-c", "core.quotePath=false", "status", "--porcelain", "--untracked-files=all")
    return _parse_paths(r.stdout) if (r and r.returncode == 0) else set()


def diff_changed(project, prev_sha):
    """files changed between the previous phase's commit and HEAD — so a *clean* worktree
    still yields the diff of what this phase's predecessor produced."""
    if not (prev_sha and is_git(project)):
        return set()
    r = git(project, "-c", "core.quotePath=false", "diff", "--name-only", prev_sha, "HEAD")
    if not (r and r.returncode == 0):
        return set()
    return {l.strip().strip('"') for l in r.stdout.splitlines() if l.strip()}


# ---- exclusion --------------------------------------------------------------
def is_excluded(rel, excludes):
    r = norm(rel)
    base = os.path.basename(r)
    if base in LOCK_FILES:                      # always excluded in v1 (see spec/context-schema.md)
        return True
    if os.path.splitext(base)[1].lower() in BINARY_EXT:
        return True
    segs = r.split("/")
    for ex in excludes:
        e = norm(ex).strip("/")
        if not e:
            continue
        if "/" in e:                            # multi-segment: prefix match (e.g. .ship/baseline)
            if r == e or r.startswith(e + "/"):
                return True
        elif e in segs[:-1]:                    # single dir name: interior segment only, not the filename
            return True
    return False


def _rank(rel):
    """budget-trim priority: real source first, then config, then docs, then tests/generated."""
    r = norm(rel).lower()
    if re.search(r"(test|spec|__tests__|\.stories\.)", r):
        return 3
    if r.endswith((".md", ".txt", ".rst")):
        return 2
    if r.endswith((".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".env.example")):
        return 1
    return 0                                    # source code — keep first


# ---- repo map (regex, one level of imports; safe fallback; NO project escape) ----
SYM_PATTERNS = {
    ".py": [r"^\s*(?:async\s+)?def\s+(\w+)", r"^\s*class\s+(\w+)"],
    ".js": [r"^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)", r"^\s*(?:export\s+)?class\s+(\w+)",
            r"^\s*export\s+(?:const|let)\s+(\w+)"],
    ".mjs": [r"^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)", r"^\s*export\s+(?:const|let)\s+(\w+)"],
    ".ts": [r"^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)", r"^\s*(?:export\s+)?class\s+(\w+)",
            r"^\s*export\s+(?:const|interface|type|enum)\s+(\w+)"],
    ".astro": [r"^\s*export\s+(?:const|function|class|interface)\s+(\w+)"],
    ".go": [r"^\s*func\s+(\w+)", r"^\s*type\s+(\w+)"],
    ".rs": [r"^\s*(?:pub\s+)?fn\s+(\w+)", r"^\s*(?:pub\s+)?struct\s+(\w+)", r"^\s*(?:pub\s+)?enum\s+(\w+)"],
}
SYM_PATTERNS[".jsx"] = SYM_PATTERNS[".js"]
SYM_PATTERNS[".tsx"] = SYM_PATTERNS[".ts"]
IMPORT_PATTERNS = [
    r"""import\s+[^;\n]*?from\s+['"]([^'"]+)['"]""",
    r"""require\(\s*['"]([^'"]+)['"]\s*\)""",
]


def resolve_import(project, from_rel, spec):
    if not spec.startswith("."):
        return None                             # bare package — not a local related file
    base = os.path.normpath(os.path.join(os.path.dirname(from_rel), spec))
    for c in [base] + [base + e for e in (".ts", ".tsx", ".js", ".jsx", ".mjs", ".astro", ".py")] \
            + [os.path.join(base, "index" + e) for e in (".ts", ".js", ".mjs")]:
        ap = os.path.join(project, c)
        if os.path.isfile(ap) and _within(project, ap):        # never escape the project root
            rel = os.path.relpath(os.path.realpath(ap), os.path.realpath(project))
            if not rel.startswith(".."):
                return norm(c)
    return None


def repo_map(project, files, excludes, cap_symbols=12, cap_files=25):
    out = []
    for rel in files[:cap_files]:
        ap = os.path.join(project, rel)
        entry = {"file": norm(rel), "symbols": [], "related_files": []}
        if os.path.isfile(ap) and _within(project, ap):
            ext = os.path.splitext(rel)[1].lower()
            try:
                text = open(ap, encoding="utf-8", errors="ignore").read()
            except Exception:
                text = ""
            syms = []
            for rx in SYM_PATTERNS.get(ext, []):     # fallback: unknown ext -> no symbols, still listed
                for m in re.finditer(rx, text, re.M):
                    if m.group(1) not in syms:
                        syms.append(m.group(1))
            rel_files = []
            for rx in IMPORT_PATTERNS:
                for m in re.finditer(rx, text):
                    r = resolve_import(project, rel, m.group(1))
                    if r and not is_excluded(r, excludes) and r not in rel_files:
                        rel_files.append(r)
            entry["symbols"] = syms[:cap_symbols]
            entry["related_files"] = rel_files[:8]
        out.append(entry)
    if len(files) > cap_files:                  # signal the map is incomplete (mirror the trim markers)
        out.append({"file": f"(+{len(files) - cap_files} more changed files — not mapped)",
                    "symbols": [], "related_files": []})
    return out


# ---- protected context + inputs ---------------------------------------------
def sha256_file(ap):
    h = hashlib.sha256()
    with open(ap, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def read_critical_rules(project):
    """CONSTITUTION.md is all non-negotiables -> every real bullet. Else the CLAUDE.md Hard-rules
    section only. These are PROTECTED: never silently truncated (build errors instead)."""
    cp = os.path.join(project, "CONSTITUTION.md")
    if os.path.exists(cp):
        rules = [re.sub(r"^[-*]\s+", "", l.strip())
                 for l in open(cp, encoding="utf-8", errors="ignore").read().splitlines()
                 if re.match(r"[-*]\s+\S", l.strip()) and "{{" not in l]
        if rules:
            return rules
    clp = os.path.join(project, "CLAUDE.md")
    if os.path.exists(clp):
        rules, capture = [], False
        for l in open(clp, encoding="utf-8", errors="ignore").read().splitlines():
            h = re.match(r"#{1,6}\s+(.*)", l)
            if h:
                capture = bool(re.search(r"(?i)hard rule|non-negotiab|must not", h.group(1)))
                continue
            s = l.strip()
            if capture and re.match(r"[-*]\s+\S", s) and "{{" not in s:
                rules.append(re.sub(r"^[-*]\s+", "", s))
        return rules
    return []


def _sha_docs(project, names):
    out = []
    for name in names:
        ap = os.path.join(project, name)
        if os.path.isfile(ap) and _within(project, ap):   # isfile, not exists — never hash a directory
            out.append({"path": norm(name), "sha256": sha256_file(ap)})
    return out


def source_files(project):
    return _sha_docs(project, ("CONSTITUTION.md", "ACCEPTANCE.md"))


def phase_inputs(project, name):
    seen, names = set(), []
    for n in (PHASE_INPUTS.get(name, []) + ALWAYS_INPUTS):
        if n not in seen:
            seen.add(n)
            names.append(n)
    return _sha_docs(project, names)


def read_acceptance(project):
    ap = os.path.join(project, "ACCEPTANCE.md")
    if not os.path.exists(ap):
        return []
    lines = []
    for l in open(ap, encoding="utf-8", errors="ignore").read().splitlines():
        s = l.strip()
        if "{{" in s:
            continue
        if re.match(r"[-*]\s+\S", s) or re.search(r"\b(Given|When|Then)\b", s):
            lines.append(re.sub(r"^[-*]\s+", "", s))
    return lines[:20]


def read_verify_commands(project):
    p = os.path.join(project, "CLAUDE.md")
    if not os.path.exists(p):
        return []
    t = open(p, encoding="utf-8", errors="ignore").read()
    m = re.search(r"Verification.*?\n```[^\n]*\n(.*?)```", t, re.S)
    if not m:
        return []
    return [l.strip() for l in m.group(1).splitlines() if l.strip() and "{{" not in l]


# ---- spec / state (fail-closed) ---------------------------------------------
def load_spec():
    return yaml.safe_load(open(os.path.join(PLUGIN, "spec", "pipeline.yml"), encoding="utf-8"))


def load_state(project):
    """Return the parsed state, or {} if the file is ABSENT. A file that EXISTS but is corrupt
    raises StateError — never silently drop owner permissions / sign-offs (fail-closed)."""
    p = os.path.join(project, ".ship", "state.yml")
    if not os.path.exists(p):
        return {}
    try:
        d = yaml.safe_load(open(p, encoding="utf-8"))
    except Exception as e:
        raise StateError(f".ship/state.yml is not valid YAML - fix it (fail-closed): {str(e).splitlines()[0]}")
    if d is None:
        return {}
    if not isinstance(d, dict):
        raise StateError(".ship/state.yml is not a YAML mapping - fix it (fail-closed)")
    return d


def load_policy(project):
    spec_default = DEFAULT_MAX_TOKENS
    try:
        spec_default = int((load_spec().get("context") or {}).get("default_max_tokens") or DEFAULT_MAX_TOKENS)
    except Exception:
        spec_default = DEFAULT_MAX_TOKENS
    p = os.path.join(project, ".ship", "context-policy.yml")
    pol = {}
    if os.path.exists(p):
        try:
            pol = yaml.safe_load(open(p, encoding="utf-8")) or {}
        except Exception as e:
            raise StateError(f".ship/context-policy.yml is not valid YAML - fix it (fail-closed): "
                             f"{str(e).splitlines()[0]}")
        if not isinstance(pol, dict):
            raise StateError(".ship/context-policy.yml is not a YAML mapping - fix it (fail-closed)")
    excludes = list(pol.get("excluded_paths") or []) + DEFAULT_EXCLUDES
    maximum = int(pol.get("maximum_tokens") or spec_default)
    return excludes, maximum


def _norm_phase(phase):
    if not isinstance(phase, str):
        return phase
    p = phase.strip().lower().replace("-", "_")
    return _ALIASES.get(p, p)


def phase_index(spec, phase):
    names = spec["phases"]
    if str(phase).isdigit():
        i = int(phase)
        return i if 0 <= i < len(names) else None   # bounds-check -> unknown phase, not an IndexError
    p = _norm_phase(phase)
    return names.index(p) if p in names else None


SAFE_RID = re.compile(r"[^A-Za-z0-9._-]")


def _safe_run_id(rid):
    rid = SAFE_RID.sub("-", str(rid))
    rid = rid.replace("..", "-").strip(".-")
    return rid[:64] or None


def run_id_for(project, state):
    """Never trust a project-supplied run_id verbatim (path traversal). Sanitize it; if it's
    unusable, derive an opaque id from the project path ONLY (stable across commits)."""
    rid = state.get("run_id")
    if rid:
        safe = _safe_run_id(rid)
        if safe:
            return safe
    return hashlib.sha1(os.path.abspath(project).encode("utf-8")).hexdigest()[:12]


# ---- prior handoff via the transition ledger (NOT the linear predecessor) ----
def prior_handoff_ref(project, state, spec, workflow, idx):
    """The previous phase is what ACTUALLY completed (state.last_completed_phase), not idx-1 —
    branches (QA 4->6, Fix 5->4, iteration 3->4->8) break the linear assumption."""
    seq = spec["sequences"].get(workflow, spec["sequences"]["full"])
    if idx in seq and seq.index(idx) == 0:
        return None                              # first phase in the sequence — no predecessor
    hdir = os.path.join(project, ".ship", "handoffs")
    lcp = state.get("last_completed_phase")
    if isinstance(lcp, int) and not isinstance(lcp, bool):
        name = spec["phases"][lcp] if 0 <= lcp < len(spec["phases"]) else str(lcp)
        pp = os.path.join(hdir, f"{lcp}-{name}.yml")
        if os.path.isfile(pp):                             # isfile, not exists — a dir is not a handoff
            return {"phase": lcp, "path": norm(os.path.relpath(pp, project)), "sha256": sha256_file(pp)}
        return {"phase": lcp, "path": norm(f".ship/handoffs/{lcp}-{name}.yml"),
                "sha256": None, "status": "MISSING"}
    # No ledger. Legacy project: infer from the highest handoff that PRECEDES this phase (n < idx).
    existing = []
    if os.path.isdir(hdir):
        for f in os.listdir(hdir):
            m = re.match(r"(\d+)-\w+\.yml$", f)
            if m and int(m.group(1)) < idx and os.path.isfile(os.path.join(hdir, f)):
                existing.append((int(m.group(1)), f))
    if existing:
        n, f = max(existing)
        pp = os.path.join(hdir, f)
        return {"phase": n, "path": norm(os.path.relpath(pp, project)),
                "sha256": sha256_file(pp), "status": "legacy-inferred"}
    return {"path": None, "sha256": None, "status": "NEEDS_MIGRATION"}


def _handoff_commit(project, ref):
    if not (ref and ref.get("path")):
        return None
    try:
        h = yaml.safe_load(open(os.path.join(project, ref["path"]), encoding="utf-8"))
        return (h or {}).get("commit_sha")
    except Exception:
        return None


# ---- assemble ---------------------------------------------------------------
def assemble(project, phase):
    spec = load_spec()
    idx = phase_index(spec, phase)
    if idx is None:
        raise ValueError(f"unknown phase: {phase}")
    name = spec["phases"][idx]
    state = load_state(project)                  # may raise StateError (fail-closed)
    ptype = state.get("type", "full")
    workflow = "lite" if ptype == "lite" else "full"
    excludes, maximum = load_policy(project)

    head = head_sha(project)
    ws = worktree_status(project)
    prior = prior_handoff_ref(project, state, spec, workflow, idx)
    prev_commit = _handoff_commit(project, prior)

    changed_set = status_changed(project) | diff_changed(project, prev_commit)
    changed = sorted(c for c in changed_set if not is_excluded(c, excludes))
    changed.sort(key=lambda c: (_rank(c), c))    # importance-ranked (source first), stable

    sos = [s for s in (state.get("signoffs") or []) if isinstance(s, dict)]  # tolerate a malformed entry
    owner_permissions = [f'{s.get("item", "?")} (phase {s.get("phase", "?")}, {s.get("date", "?")})'
                         for s in sos]
    owner_signoffs = [{"decision": s.get("item"), "approved_at": s.get("date")} for s in sos]

    checks = read_verify_commands(project) or PHASE_DEFAULT_CHECKS.get(name, [])
    inputs = phase_inputs(project, name)

    # per-included-file hashes so a CONTENT change (same filename) makes the pack stale.
    fhashes = {}
    for rel in changed:
        ap = os.path.join(project, rel)
        if os.path.isfile(ap) and _within(project, ap):
            fhashes[norm(rel)] = sha256_file(ap)

    pack = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id_for(project, state),
        "phase": idx,
        "phase_name": name,
        "workflow": workflow,
        "mode": state.get("mode", "standard"),
        "objective": PHASE_OBJECTIVE.get(name, f"Run phase {name}."),
        "phase_skill": norm(os.path.join(PLUGIN, "skills", _skill_dir(name), "SKILL.md")),
        "protected_context": {
            "owner_permissions": owner_permissions,
            "critical_rules": read_critical_rules(project),
            "source_files": source_files(project),
        },
        "owner_signoffs": owner_signoffs,
        "phase_inputs": inputs,
        "state": {
            "current_phase": state.get("current_phase", idx),
            "commit_sha": head,
            "worktree_status": ws,
            "is_git": is_git(project),
        },
        "prior_handoff": prior,
        "changed_files": [norm(c) for c in changed],
        "file_hashes": fhashes,
        "repo_map": repo_map(project, changed, excludes),
        "acceptance": read_acceptance(project),
        "required_checks": checks,
        "context_policy": {
            "estimated_tokens": 0,
            "maximum_tokens": maximum,
            "token_method": TOKEN_METHOD,
            "excluded_paths": excludes,
        },
        "metadata": {"generated_by": "context_builder.py", "schema": "spec/context-schema.md"},
    }
    return _fit_budget(pack, maximum)


_SKILL_DIR = {"build": "ship-build", "fix": "ship-build", "qa": "ship-expert-qa",
              "research": "ship-research", "spec": "ship-spec", "prod_prep": "ship-prod-prep",
              "provision": "ship-provision", "deploy": "ship-deploy", "monitor": "ship-monitor",
              "idea": "ship"}


def _skill_dir(name):
    return _SKILL_DIR.get(name, "ship")


def _protected_size(pack):
    keep = ("objective", "protected_context", "owner_signoffs", "phase_inputs", "state", "required_checks")
    sub = {k: pack[k] for k in keep if k in pack}
    return est_tokens(yaml.safe_dump(sub, sort_keys=False, allow_unicode=True))


def _measure(pack):
    pack["context_policy"]["estimated_tokens"] = 0
    return est_tokens(HEADER + render(pack))


def _trim_one(pack):
    rm = pack.get("repo_map") or []
    for e in rm:
        if e.get("symbols"):
            e["symbols"] = []
            return True
        if e.get("related_files"):
            e["related_files"] = []
            return True
    # Collapse by REAL entries (ignore any '(+…)' sentinel) so it's idempotent and the count is true —
    # folding in any pre-existing cap-25 'not mapped' sentinel count so the total isn't undercounted.
    not_mapped = sum(int(m.group(1)) for e in rm
                     for m in [re.match(r"\(\+(\d+) more", str(e.get("file", "")))] if m)
    real = [e for e in rm if not str(e.get("file", "")).startswith("(")]
    if len(real) > 3:
        dropped = (len(real) - 3) + not_mapped
        pack["repo_map"] = real[:3] + [{"file": f"(+{dropped} more changed files — omitted for budget)",
                                        "symbols": [], "related_files": []}]
        return True
    cf = pack.get("changed_files") or []
    if len(cf) > 10 and not (cf and str(cf[-1]).startswith("(+")):
        dropped = len(cf) - 10
        pack["changed_files"] = cf[:10] + [f"(+{dropped} more)"]
        return True
    fh = pack.get("file_hashes")                # prune hashes to the (possibly capped) changed_files
    if isinstance(fh, dict) and fh:
        cf_real = {c for c in (pack.get("changed_files") or []) if not str(c).startswith("(+")}
        pruned = {k: v for k, v in fh.items() if k in cf_real}
        if len(pruned) < len(fh):
            pack["file_hashes"] = pruned
            return True
    ac = pack.get("acceptance") or []
    if len(ac) > 3 and not (ac and str(ac[-1]).startswith("(+")):
        dropped = len(ac) - 3
        pack["acceptance"] = ac[:3] + [f"(+{dropped} more — see ACCEPTANCE.md)"]
        return True
    return False


def _fit_budget(pack, maximum):
    pmin = _protected_size(pack)
    if pmin > maximum:
        raise BudgetError(
            f"protected context (rules/permissions/inputs/state) ~{pmin} tok exceeds maximum_tokens "
            f"{maximum}; raise the budget in .ship/context-policy.yml - refusing to drop protected context")
    est = _measure(pack)
    while est > maximum and _trim_one(pack):
        est = _measure(pack)
    if est > maximum:
        raise BudgetError(
            f"context pack ~{est} tok still exceeds maximum_tokens {maximum} after trimming all "
            f"non-protected sections; raise the budget in .ship/context-policy.yml")
    pack["context_policy"]["estimated_tokens"] = est
    return pack


def render(pack):
    return yaml.safe_dump(pack, sort_keys=False, allow_unicode=True,
                          default_flow_style=False, width=100)


def write_pack(project, phase):
    pack = assemble(project, phase)
    ctxroot = os.path.join(project, ".ship", "context")
    d = os.path.join(ctxroot, str(pack["run_id"]))
    if not _within(ctxroot, d):                  # defense-in-depth vs a crafted run_id
        raise PackError(f"refusing to write a pack outside .ship/context (run_id={pack['run_id']!r})")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{pack['phase']}-{pack['phase_name']}.yml")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(HEADER + render(pack))
    return path


# ---- handoff validation -----------------------------------------------------
HANDOFF_REQUIRED = ["schema_version", "phase", "phase_name", "status", "commit_sha", "verification"]


def check_handoff(path, max_tokens=HANDOFF_MAX_TOKENS):
    try:
        raw = open(path, encoding="utf-8", errors="ignore").read()
    except Exception as e:
        return False, [f"handoff unreadable: {e}"]
    try:
        h = yaml.safe_load(raw)
    except Exception as e:
        return False, [f"handoff not valid YAML: {str(e).splitlines()[0]}"]
    if not isinstance(h, dict):
        return False, ["handoff is not a YAML mapping (a raw blob is not a handoff)"]
    rs = []
    if h.get("schema_version") != 1:
        rs.append(f"handoff schema_version is {h.get('schema_version')!r}, expected 1")
    for k in HANDOFF_REQUIRED:
        if k not in h:
            rs.append(f"handoff missing required field: {k}")
        elif k in ("commit_sha", "phase_name", "status") and h.get(k) in (None, ""):
            rs.append(f"handoff required field {k} is empty/null")
    if "status" in h and h.get("status") not in ("completed", "blocked", "partial"):
        rs.append(f"handoff status invalid: {h.get('status')!r} (completed|blocked|partial)")
    size = est_tokens(raw)
    if size > max_tokens:
        rs.append(f"handoff too large (~{size} tok > {max_tokens}) — token economy defeated; "
                  f"summarize and move logs to .ship/logs (reference by evidence path)")
    ver = h.get("verification")
    if ver is not None and not isinstance(ver, list):   # non-list would crash the loop below
        rs.append(f"handoff verification must be a list, got {type(ver).__name__}")
        ver = []
    for v in (ver or []):
        ev = (v or {}).get("evidence") if isinstance(v, dict) else None
        if ev:
            e = str(ev).replace("\\", "/")
            # reject absolute on ANY OS (drive/UNC/POSIX-root) and any .. segment
            if _is_abs_path(ev) or ".." in e.split("/"):
                rs.append(f"handoff evidence path unsafe: {ev}")
    return (len(rs) == 0), rs


# ---- pack schema validation -------------------------------------------------
_REQUIRED_TYPES = {
    "schema_version": int, "run_id": str, "phase": int, "phase_name": str,
    "workflow": str, "objective": str, "protected_context": dict, "state": dict,
    "required_checks": list, "context_policy": dict,
}
# optional fields that, WHEN PRESENT, must have the right type (so a malformed one BLOCKS, not just
# gets silently coerced away — the check must be honest about a broken pack).
_OPTIONAL_TYPES = {
    "mode": str, "phase_skill": str, "owner_signoffs": list, "phase_inputs": list,
    "prior_handoff": dict, "changed_files": list, "file_hashes": dict, "repo_map": list,
    "acceptance": list, "metadata": dict,
}
_KNOWN_KEYS = set(_REQUIRED_TYPES) | set(_OPTIONAL_TYPES)


def validate_schema(pack):
    rs = []
    for k, t in _REQUIRED_TYPES.items():
        if k not in pack:
            rs.append(f"missing required field: {k}")
        elif not isinstance(pack[k], t) or (t is int and isinstance(pack[k], bool)):
            rs.append(f"field {k!r} has wrong type ({type(pack[k]).__name__}, expected {t.__name__})")
    for k, t in _OPTIONAL_TYPES.items():        # None is allowed (e.g. prior_handoff on the first phase)
        if k in pack and pack[k] is not None and not isinstance(pack[k], t):
            rs.append(f"field {k!r} has wrong type ({type(pack[k]).__name__}, expected {t.__name__})")
    et = (pack.get("context_policy") or {}).get("estimated_tokens")
    if et is not None and (not isinstance(et, int) or isinstance(et, bool)):
        rs.append("context_policy.estimated_tokens is not an integer")
    for k, v in pack.items():                    # no smuggling huge unknown fields past the budget
        if k not in _KNOWN_KEYS:
            try:
                size = est_tokens(yaml.safe_dump({k: v}, allow_unicode=True))
            except Exception:
                size = 999
            if size > 150:
                rs.append(f"unknown oversized field {k!r} (~{size} tok) — not part of the schema")
    return rs


# ---- check ------------------------------------------------------------------
def _derive_project(pack_file):
    d = os.path.abspath(pack_file)              # <project>/.ship/context/<run>/<n>-<name>.yml -> up 4
    for _ in range(4):
        d = os.path.dirname(d)
    return d


def check_pack(pack_file, project=None):
    reasons = []
    try:
        pack = yaml.safe_load(open(pack_file, encoding="utf-8"))
    except Exception as e:
        return False, [f"corrupted context pack: {str(e).splitlines()[0]}"]
    if not isinstance(pack, dict):
        return False, ["corrupted context pack: not a YAML mapping"]

    reasons += validate_schema(pack)
    if pack.get("schema_version") != SCHEMA_VERSION:
        reasons.append(f"schema_version is {pack.get('schema_version')!r}, expected {SCHEMA_VERSION}")
    project = project or _derive_project(pack_file)

    try:
        spec = load_spec()
        excludes, maximum = load_policy(project)
        state = load_state(project)
    except StateError as e:
        return False, [f"state/policy error (fail-closed): {e}"]

    # budget — RECOMPUTE from canonical content; never trust the pack's own estimated_tokens.
    try:
        p2 = dict(pack)
        p2["context_policy"] = dict(pack.get("context_policy") or {})
        p2["context_policy"]["estimated_tokens"] = 0
        actual = est_tokens(HEADER + render(p2))
    except Exception:
        actual = None
    et = (pack.get("context_policy") or {}).get("estimated_tokens")
    if actual is not None and actual > maximum:
        reasons.append(f"context budget exceeded: recomputed size {actual} > maximum {maximum} "
                       f"(pack claims {et})")
    elif actual is not None and isinstance(et, int) and not isinstance(et, bool) \
            and abs(et - actual) > max(60, int(actual * 0.3)):
        reasons.append(f"(warn) estimated_tokens {et} disagrees with recomputed {actual} — rebuild the pack")

    # nothing excluded may appear  (coerce pack-supplied fields — a malformed type must BLOCK, not crash)
    for c in _as_list(pack.get("changed_files")):
        if not str(c).startswith("(+") and is_excluded(c, excludes):
            reasons.append(f"excluded path leaked into changed_files: {c}")
    for e in _as_list(pack.get("repo_map")):
        f = e.get("file", "") if isinstance(e, dict) else ""
        if not str(f).startswith("(") and is_excluded(f, excludes):
            reasons.append(f"excluded path leaked into repo_map: {f}")

    # protected context intact vs source
    prot = _as_dict(pack.get("protected_context"))
    rules_pack = _as_list(prot.get("critical_rules"))
    for r in read_critical_rules(project):
        if r not in rules_pack:
            reasons.append(f"critical rule dropped from pack: {r[:60]}")
    for sf in (_as_list(prot.get("source_files")) + _as_list(pack.get("phase_inputs"))):
        if not isinstance(sf, dict):
            continue
        ap = _safe_project_join(project, sf.get("path", ""))   # traversal guard on pack-supplied path
        if ap is None:
            reasons.append(f"unsafe path in pack (absolute/empty or escapes project): {sf.get('path')!r}")
            continue
        if os.path.isfile(ap):
            if sha256_file(ap) != sf.get("sha256"):
                reasons.append(f"input/source file changed since pack built (stale): {sf.get('path')}")
        elif os.path.exists(ap):
            reasons.append(f"pack path is not a regular file: {sf.get('path')}")
        else:
            reasons.append(f"file recorded in pack no longer exists: {sf.get('path')}")

    # per-file content staleness (a same-named file whose CONTENT changed makes the pack stale)
    for rel, sha in _as_dict(pack.get("file_hashes")).items():
        ap = _safe_project_join(project, rel)                  # traversal guard on pack-supplied key
        if ap is None:
            reasons.append(f"unsafe path in pack file_hashes (absolute/empty or escapes project): {rel!r}")
            continue
        if os.path.isfile(ap) and sha256_file(ap) != sha:
            reasons.append(f"included file content changed since pack built (stale): {rel}")

    # owner permissions not removed vs state
    perms_pack = " || ".join(str(x) for x in _as_list(prot.get("owner_permissions"))) + " || " + \
        " || ".join(str(s.get("decision")) for s in _as_list(pack.get("owner_signoffs")) if isinstance(s, dict))
    for s in (state.get("signoffs") or []):
        if not isinstance(s, dict):
            continue
        item = str(s.get("item", ""))
        if item and item not in perms_pack:
            reasons.append(f"owner sign-off missing from pack: {item[:60]}")

    # prior handoff — by the LEDGER, not the linear predecessor
    ph = pack.get("prior_handoff")
    if isinstance(ph, dict):
        st = ph.get("status")
        if st == "NEEDS_MIGRATION":
            reasons.append("no prior handoff and no transition ledger (legacy project) — run "
                           "`context_builder.py migrate .` or set last_completed_phase; do not continue silently")
        elif st == "MISSING":
            reasons.append(f"prior handoff missing for last_completed_phase {ph.get('phase')}: {ph.get('path')}")
        elif ph.get("path"):
            hp = _safe_project_join(project, ph["path"])       # traversal guard on pack-supplied path
            if hp is None:
                reasons.append(f"unsafe prior_handoff path (absolute/empty or escapes project): {ph['path']}")
            elif not os.path.isfile(hp):                       # a directory (e.g. '.ship') must not be hashed
                reasons.append(f"prior handoff path is not a regular file: {ph['path']}")
            elif ph.get("sha256") and sha256_file(hp) != ph.get("sha256"):
                reasons.append("prior handoff changed since pack built (stale)")
            else:
                try:
                    _, hr = check_handoff(hp)
                except Exception as e:            # never let a malformed handoff crash `check`
                    hr = [f"handoff could not be validated: {str(e).splitlines()[0]}"]
                for r in hr:
                    reasons.append(f"prior handoff invalid: {r}")

    # git freshness
    stt = pack.get("state") or {}
    if is_git(project):
        head = head_sha(project)
        if stt.get("commit_sha") and stt.get("commit_sha") != head:
            reasons.append(f"stale commit_sha: pack {str(stt.get('commit_sha'))[:8]} != HEAD {str(head)[:8]}")
        ws = worktree_status(project)
        if stt.get("worktree_status") and ws and stt.get("worktree_status") != ws:
            reasons.append(f"(warn) worktree drifted since build: pack '{stt.get('worktree_status')}' now '{ws}'")
    elif stt.get("commit_sha"):
        reasons.append("pack records a commit_sha but project is not a git repo")

    hard = [r for r in reasons if not r.startswith("(warn)")]
    return (len(hard) == 0), reasons


# ---- migration --------------------------------------------------------------
def migrate(project):
    """Create a synthetic prior handoff for a legacy project (upgraded from v0.7.x) so the
    Phase-Isolated pipeline doesn't hard-block it. Review the result before trusting it."""
    spec = load_spec()
    state = load_state(project)
    cur = state.get("current_phase")
    idx = cur if (isinstance(cur, int) and not isinstance(cur, bool)) else 0   # garbage -> 0, no crash
    workflow = "lite" if state.get("type") == "lite" else "full"
    seq = spec["sequences"].get(workflow, spec["sequences"]["full"])
    if idx not in seq or seq.index(idx) == 0:
        sys.stderr.write("migrate: current phase is the first in its sequence — no predecessor to synthesize\n")
        return 0
    prev = seq[seq.index(idx) - 1]
    # Don't blindly assume the linear predecessor: the QA-clean skip route enters prod_prep(6) from
    # QA(4), not Fix(5). If entering 6 and QA recorded 0 verified crit/major, the predecessor is 4.
    if idx == 6:
        qa = _as_dict(_as_dict(_as_dict(state.get("phases")).get("4_qa")).get("qa"))
        if (qa.get("verified_critical") in (0, None)) and (qa.get("verified_major") in (0, None)) \
                and not os.path.exists(os.path.join(project, ".ship", "handoffs", "5-fix.yml")):
            prev = 4
    name = spec["phases"][prev]
    sys.stderr.write(f"migrate: guessing predecessor phase {prev} ({name}) — REVIEW this; set "
                     f"last_completed_phase explicitly if wrong\n")
    hdir = os.path.join(project, ".ship", "handoffs")
    os.makedirs(hdir, exist_ok=True)
    p = os.path.join(hdir, f"{prev}-{name}.yml")
    if os.path.exists(p):
        print(f"migrate: handoff already exists — {p}")
        return 0
    doc = {
        "schema_version": 1, "phase": prev, "phase_name": name, "status": "completed",
        "commit_sha": head_sha(project) or "unknown",
        "decisions": ["(synthetic migration handoff reconstructed from state — review before trusting)"],
        "verification": [{"command": "(legacy — predates the pipeline)", "status": "unknown",
                          "evidence": ".ship/logs/"}],
        "risks": ["synthetic handoff: this phase ran before the Phase-Isolated pipeline existed"],
        "migration": True,
    }
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write("# synthetic migration handoff — reconstructed from state; REVIEW before trusting.\n")
        f.write(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True))
    print(f"migrate: wrote {p}")
    print(f"migrate: also set `last_completed_phase: {prev}` in .ship/state.yml so the ledger is explicit")
    return 0


# ---- pipeline engagement status ---------------------------------------------
def pipeline_status(project):
    """Report whether the Phase-Isolated pipeline is ACTUALLY engaged (packs being built) so a silent
    no-op — phases running inline with no token economy — becomes visible instead of invisible."""
    spec = load_spec()
    try:
        state = load_state(project)
    except StateError as e:
        return {"error": str(e)}
    workflow = "lite" if state.get("type") == "lite" else "full"
    seq = spec["sequences"].get(workflow, spec["sequences"]["full"])
    cur = state.get("current_phase")
    cur = cur if (isinstance(cur, int) and not isinstance(cur, bool)) else 0
    # count packs across ANY run dir (don't depend on matching run_id — a pack anywhere counts as engaged)
    packs = {}
    croot = os.path.join(project, ".ship", "context")
    if os.path.isdir(croot):
        for run in os.listdir(croot):
            rd = os.path.join(croot, run)
            if os.path.isdir(rd):
                for f in os.listdir(rd):
                    m = re.match(r"(\d+)-\w+\.yml$", f)
                    if m and os.path.isfile(os.path.join(rd, f)):   # a dir named like a pack is NOT a pack
                        packs[int(m.group(1))] = os.path.join(run, f)
    hdir = os.path.join(project, ".ship", "handoffs")
    handoffs = len([f for f in os.listdir(hdir)
                    if f.endswith(".yml") and os.path.isfile(os.path.join(hdir, f))]) if os.path.isdir(hdir) else 0
    # phases that should have run so far (in this type's sequence, up to current)
    started = [p for p in seq if isinstance(cur, int) and p <= cur and p != 0]  # phase 0 has no pack
    missing = [p for p in started if p not in packs]
    return {"engaged": len(packs) > 0, "packs": len(packs), "handoffs": handoffs,
            "started": started, "missing": missing,
            "phase_names": {p: spec["phases"][p] for p in seq if 0 <= p < len(spec["phases"])}}


def print_pipeline_status(project):
    st = pipeline_status(project)
    if st.get("error"):
        safe = str(st["error"]).encode("ascii", "replace").decode()   # never crash a cp1251 console
        print(f"  x state error (fail-closed): {safe}"); return 5
    names = st["phase_names"]
    # ASCII only — Windows consoles (cp1251/1252) can't encode em-dashes/arrows (would garble or crash).
    if st["engaged"]:
        print(f"Phase-Isolated pipeline: ENGAGED - {st['packs']} context pack(s), {st['handoffs']} handoff(s).")
        if st["missing"]:
            miss = ", ".join(f"{p} {names.get(p, p)}" for p in st["missing"])
            print(f"  ! phases with NO pack yet: {miss} (build them so those phases get the token economy too)")
        return 0
    print("Phase-Isolated pipeline: OFF - 0 context packs built. Phases are running INLINE (full history")
    print("  replayed each step = NO token economy). Engage it by building a pack per phase:")
    print("    /ship:pack build <phase>    (the orchestrator / /ship:phase should do this automatically)")
    return 1


# ---- CLI --------------------------------------------------------------------
def _emit(reasons):
    for r in reasons:
        print(("  ! " if r.startswith("(warn)") else "  x ") + r.replace("(warn) ", ""))


def _main(argv):
    cmd = argv[1] if len(argv) > 1 else ""
    if cmd == "build":
        if len(argv) < 3:
            print("usage: context_builder.py build <phase> [project_dir]"); return 2
        project = argv[3] if len(argv) > 3 else os.getcwd()
        try:
            print(write_pack(project, argv[2])); return 0
        except BudgetError as e:
            sys.stderr.write(f"BUDGET: {e}\n"); return 4
        except (StateError, PackError) as e:
            sys.stderr.write(f"ERROR: {e}\n"); return 5
        except ValueError as e:
            sys.stderr.write(f"{e}\n"); return 2
    if cmd == "check":
        if len(argv) < 3:
            print("usage: context_builder.py check <pack.yml> [project_dir]"); return 2
        ok, reasons = check_pack(argv[2], argv[3] if len(argv) > 3 else None)
        _emit(reasons); print(f"context_check: {'PASS' if ok else 'BLOCKED'}")
        return 0 if ok else 1
    if cmd == "check-handoff":
        if len(argv) < 3:
            print("usage: context_builder.py check-handoff <handoff.yml>"); return 2
        ok, reasons = check_handoff(argv[2])
        _emit(reasons); print(f"handoff_check: {'PASS' if ok else 'BLOCKED'}")
        return 0 if ok else 1
    if cmd == "migrate":
        return migrate(argv[2] if len(argv) > 2 else os.getcwd())
    if cmd == "status":
        return print_pipeline_status(argv[2] if len(argv) > 2 else os.getcwd())
    print("usage: context_builder.py build <phase> [project] | check <pack.yml> [project] | "
          "check-handoff <handoff.yml> | migrate [project] | status [project]")
    return 2


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
