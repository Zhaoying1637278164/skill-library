#!/usr/bin/env python3
"""Executable transition tests — the state machine must BEHAVE, not just parse.
Covers the failure classes three external reviews flagged: QA->Fix deadlock, lite flow,
terminal phase, quality_clean predicate. Run by ship-doctor."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import transition as T

spec = T.load()
fails = []


def check(name, got, want):
    if got != want:
        fails.append(f"{name}: got {got!r}, want {want!r}")


# --- full happy path ---
check("full 0->1", T.next_phase(spec, "full", 0, "gate_pass"), 1)
check("full 3->4", T.next_phase(spec, "full", 3, "gate_pass"), 4)
check("full 8->9", T.next_phase(spec, "full", 8, "gate_pass"), 9)
check("full 9 terminal (no phase 10)", T.next_phase(spec, "full", 9, "gate_pass"), 9)

# --- QA->Fix: the deadlock class. QA completes even with RED tests, and routes to Fix. ---
check("qa with findings + red tests -> Fix (NOT blocked)",
      T.next_phase(spec, "full", 4, "qa_complete", verified_critical=2, verified_major=1, required_tests_green=False), 5)
check("qa clean -> skip Fix -> 6",
      T.next_phase(spec, "full", 4, "qa_complete", verified_critical=0, verified_major=0), 6)
check("fix not clean -> loop to QA(4)",
      T.next_phase(spec, "full", 5, "gate_pass", verified_critical=1, verified_major=0, required_tests_green=True), 4)
check("fix quality-clean -> 6",
      T.next_phase(spec, "full", 5, "gate_pass", verified_critical=0, verified_major=0, required_tests_green=True), 6)

# --- canonical quality_clean predicate ---
check("quality_clean true", T.quality_clean(0, 0, True), True)
check("quality_clean false: open major", T.quality_clean(0, 1, True), False)
check("quality_clean false: red tests", T.quality_clean(0, 0, False), False)
check("quality_clean false: open critical", T.quality_clean(1, 0, True), False)

# --- lite: 0->3->8, no staging need, 8 terminal (never 9) ---
check("lite 0->3 (build's prior is 0, not 2)", T.next_phase(spec, "lite", 0, "gate_pass"), 3)
check("lite 3->8", T.next_phase(spec, "lite", 3, "gate_pass"), 8)
check("lite 8 terminal (no phase 9)", T.next_phase(spec, "lite", 8, "gate_pass"), 8)
check("lite is_terminal(8)", T.is_terminal(spec, "lite", 8), True)
check("full is_terminal(9)", T.is_terminal(spec, "full", 9), True)
check("full is_terminal(8) == False", T.is_terminal(spec, "full", 8), False)

if fails:
    print("TRANSITION TESTS FAILED:")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("transition tests: 18 scenarios PASSED")
sys.exit(0)
