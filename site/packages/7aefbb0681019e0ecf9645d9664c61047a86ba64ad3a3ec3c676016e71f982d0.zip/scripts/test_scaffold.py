#!/usr/bin/env python3
"""Integration tests for the deterministic scaffolder (scaffold_project.py) + its gate-0 contract.
Full (saas) and lite scaffolds must: contain the EXACT required phase-0 files, omit all deferred docs,
snapshot a COMPLETE baseline, and be on git branch `main`; gate 0 must BLOCK the fresh (unfilled/unsigned)
scaffold and PASS once the owner fills POSITIONING and signs off, routing to the type's next phase."""
import os, sys, tempfile, shutil, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import yaml
import scaffold_project as S
import gate_check as G

fails = []
def check(name, ok):
    print(("  ok  " if ok else "  XX  ") + name)
    if not ok:
        fails.append(name)

def git(d, *a):
    return subprocess.run(["git", "-C", d, *a], capture_output=True, encoding="utf-8", errors="replace")

VERSION = S.plugin_version()
TPL_FILES = sorted(f for f in os.listdir(S.TPL) if os.path.isfile(os.path.join(S.TPL, f)))
DEFERRED = ["CLAUDE.md", "PROJECT.md", "ACCEPTANCE.md", "DESIGN.md", "ROADMAP.md",
            "production_runbook.md", "_HANDOFF.md"]

for ptype, expect_next in (("saas", 1), ("lite", 3)):
    tmp = tempfile.mkdtemp()
    dest = os.path.join(tmp, "proj")
    S.scaffold("Demo " + ptype, ptype, dest)

    # 1) EXACT required phase-0 files present
    req = S.required_files()
    check(f"[{ptype}] gate inventory exactly matches the scaffolder working set",
          set(req) == set(S.WORKING_SET.values()))
    missing = [r for r in req if not os.path.exists(os.path.join(dest, *r.split("/")))]
    check(f"[{ptype}] all {len(req)} required phase-0 files present", not missing)

    # 2) deferred documents ABSENT from the project root
    present = [x for x in DEFERRED if os.path.exists(os.path.join(dest, x))]
    if os.path.isdir(os.path.join(dest, "research")):
        present.append("research/")
    check(f"[{ptype}] deferred docs absent (found: {present})", not present)

    # 3) baseline COMPLETE (every template snapshotted)
    bdir = os.path.join(dest, ".ship", "baseline", VERSION)
    snap = sorted(os.listdir(bdir)) if os.path.isdir(bdir) else []
    check(f"[{ptype}] baseline complete ({len(snap)}/{len(TPL_FILES)} templates)", snap == TPL_FILES)

    # 4) git branch is main
    br = git(dest, "symbolic-ref", "--short", "HEAD").stdout.strip()
    check(f"[{ptype}] git branch is main (got {br!r})", br == "main")

    # state.yml correctly filled — type, phase, provenance, and no leftover scaffold placeholders
    raw = open(os.path.join(dest, ".ship", "state.yml"), encoding="utf-8").read()
    stt = yaml.safe_load(raw)
    check(f"[{ptype}] state.yml type/phase/version filled, no leftover {{{{...}}}}",
          stt.get("type") == ptype and stt.get("current_phase") == 0
          and (stt.get("template_provenance") or {}).get("plugin_version") == VERSION
          and "{{" not in raw)

    # 5a) gate 0 BLOCKS the fresh scaffold (POSITIONING still has owner-fill {{...}} + no sign-off)
    check(f"[{ptype}] gate 0 BLOCKS the unfilled/unsigned fresh scaffold", not G.check_gate(dest, "idea")[0])

    # 5b) fill POSITIONING + record the owner sign-off -> gate 0 PASSES and routes to the type's next phase
    open(os.path.join(dest, "POSITIONING.md"), "w", encoding="utf-8").write(
        "# Demo\nProblem: X. ICP: devs. Category: tools. Differentiators: flat price. Anti-goals: none.\n")
    stt["signoffs"] = [{"phase": 0, "item": "positioning approved", "date": "2026-01-01"}]
    with open(os.path.join(dest, ".ship", "state.yml"), "w", encoding="utf-8", newline="\n") as f:
        yaml.safe_dump(stt, f, sort_keys=False, allow_unicode=True)
    for a in (["config", "user.email", "t@t.t"], ["config", "user.name", "t"],
              ["add", "-A"], ["-c", "commit.gpgsign=false", "commit", "-qm", "scaffold"]):
        git(dest, *a)
    ok, reasons, nxt = G.check_gate(dest, "idea")
    check(f"[{ptype}] gate 0 PASSES once filled + signed ({reasons})", ok)
    check(f"[{ptype}] gate 0 routes to the {ptype} next phase {expect_next} (got {nxt})", nxt == expect_next)

    shutil.rmtree(tmp, ignore_errors=True)

print()
if fails:
    print("scaffold tests: %d FAILED" % len(fails))
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("scaffold tests: all scenarios PASSED")
sys.exit(0)
