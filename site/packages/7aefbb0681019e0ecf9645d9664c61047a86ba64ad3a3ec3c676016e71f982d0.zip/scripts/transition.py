#!/usr/bin/env python3
"""ship transition engine — the executable state machine. Single source: spec/pipeline.yml.

This is what makes the pipeline testable instead of prose. /gate and /phase should compute the
next phase THROUGH this logic (conceptually), and scripts/test_transitions.py asserts it behaves.
"""
import os, sys, yaml

SPEC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "spec", "pipeline.yml")


def load():
    return yaml.safe_load(open(SPEC, encoding="utf-8"))


def quality_clean(verified_critical=0, verified_major=0, required_tests_green=False):
    """The ONE canonical predicate for leaving Fix (5 -> 6)."""
    return int(verified_critical) == 0 and int(verified_major) == 0 and bool(required_tests_green)


def next_phase(spec, ptype, current, event, **ctx):
    """Compute the next phase. Never invents a phase past the type's sequence (no 'phase 10')."""
    seq = spec["sequences"].get(ptype, spec["sequences"]["full"])

    # QA(4) completes regardless of tests, then routes on findings.
    if current == 4 and event == "qa_complete":
        crit = int(ctx.get("verified_critical", 0))
        maj = int(ctx.get("verified_major", 0))
        return 5 if (crit > 0 or maj > 0) else 6

    # Fix(5): advance only if quality_clean, else loop back to re-QA(4).
    if current == 5 and event == "gate_pass":
        if quality_clean(ctx.get("verified_critical", 0), ctx.get("verified_major", 0),
                         ctx.get("required_tests_green", False)):
            return 6
        return 4

    # Terminal: the last index in the type's sequence stays put (lite: 8; full: 9).
    if current == seq[-1]:
        return current

    # Default: the next phase in this type's sequence.
    if current in seq:
        i = seq.index(current)
        return seq[i + 1]
    return current  # unknown phase for this type -> no move


def is_terminal(spec, ptype, phase):
    return phase == spec["sequences"].get(ptype, spec["sequences"]["full"])[-1]


if __name__ == "__main__":
    # CLI: transition.py <type> <current> <event> [k=v ...]  -> prints next phase
    spec = load()
    ptype, current, event = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    ctx = {}
    for kv in sys.argv[4:]:
        k, v = kv.split("=", 1)
        ctx[k] = int(v) if v.lstrip("-").isdigit() else (v == "true") if v in ("true", "false") else v
    print(next_phase(spec, ptype, current, event, **ctx))
