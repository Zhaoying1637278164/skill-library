# Security policy

Ship is a local Claude Code plugin — its own scripts (Python/shell, `git`, and optionally
`pre-commit`/`gitleaks`) run on your machine, with **no server, no MCP, no telemetry, no accounts, and
they transmit nothing themselves.** (Claude Code itself sends context to Anthropic, and tools you invoke
*through* Ship — WebSearch, GitHub Actions, package managers, deploy tooling — use the network as usual;
that is outside Ship's own code.) For secret protection, Ship scaffolds a **gitleaks** pre-commit hook +
CI job (`templates/pre-commit-config.yaml`, `templates/ci-workflow.yml`) — those are the secret scan; the
plugin bundles no Claude-side secret hook.

## Reporting a vulnerability — privately

Please do **not** open a public issue for a security problem. Use the private channel:

- **GitHub private advisory (preferred):** the repo's **Security → Report a vulnerability** tab
  (GitHub Security Advisories) — https://github.com/vadimsv1/ship-plugin/security/advisories/new

Include: the version (`plugin.json` `version`), your OS, a minimal repro, and the impact. If you have
a fix in mind, a patch or PR link is welcome (but please report privately first).

**Response:** acknowledgement within ~72 hours; a fix or mitigation plan for confirmed issues as fast
as is practical, released as a new version with credit in the changelog (unless you prefer to stay
anonymous). This is a small solo/beta project — timelines are best-effort, not contractual.

## Supported versions

The **latest released version** is supported. Fixes land on `main` and ship in the next release; there
are no long-term-support branches during beta.

## Scope / threat model

In scope:
- The plugin's executable scripts (`scripts/*.py`, `scripts/ship-doctor.sh`) — e.g. path traversal, a
  crafted context pack turning a validator into a file-read oracle.
- Guidance that could lead Claude to take an unconfirmed external/irreversible action.

Out of scope:
- The security of *your* project that Ship drives (that's your codebase).
- Model behavior / prompt-injection of Claude itself (report those to Anthropic).
- Anything requiring an attacker who already controls your machine or your `.ship/` state files.
