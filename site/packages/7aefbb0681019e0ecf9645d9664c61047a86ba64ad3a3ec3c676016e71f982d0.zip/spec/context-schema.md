# Context-pack schema (v1) — the Phase-Isolated Context Pipeline

A **context pack** is the *minimum sufficient* context for **one** phase. The orchestrator builds
it (`scripts/context_builder.py build <phase>`), hands it to a **fresh phase agent**, and that agent
works from the pack + retrieval-on-demand instead of re-reading the whole project and chat history.
This is what cuts the cost driver (the Skillbin run re-read ~65M cache tokens because the full
history rode along on every step).

- **Location:** `.ship/context/<run-id>/<phase>-<name>.yml`
- **Builder:** `scripts/context_builder.py` (Python 3 + PyYAML — same stack as the other tooling; no new dep)
- **Default budget:** 2500 estimated tokens (`.ship/context-policy.yml` overrides)
- **Generated — never hand-edit.** Rebuild it; validate with `/ship:pack check <file>`.

## Fields

| Field | Meaning | Protected? |
|---|---|---|
| `schema_version` | always `1` | — |
| `run_id` | opaque id grouping one project run's packs | — |
| `phase` / `phase_name` | index (0–9) + name | — |
| `workflow` | `full` \| `lite` (iteration resolves at runtime) | — |
| `mode` | spend mode: `lean` \| `standard` \| `deep` (see `spec/pipeline.yml`) | — |
| `objective` | the one thing this phase must achieve | ✅ |
| `phase_skill` | absolute path to the phase's SKILL.md the phase agent must follow | — |
| `protected_context.owner_permissions` | owner sign-offs, verbatim | ✅ **never dropped** |
| `protected_context.critical_rules` | `CONSTITUTION.md` bullets (or CLAUDE Hard-rules) | ✅ **never dropped** |
| `protected_context.source_files` | `{path, sha256}` for CONSTITUTION/ACCEPTANCE — lets `check` detect drift | ✅ |
| `owner_signoffs` | structured `{decision, approved_at}` | ✅ |
| `phase_inputs` | `{path, sha256}` for the phase's input docs (PROJECT/DESIGN/CLAUDE/…) — so a Build agent gets the architecture + approved design even on a **clean** worktree | ✅ |
| `state` | `current_phase`, `commit_sha`, `worktree_status`, `is_git` | — |
| `prior_handoff` | reference to the **last-completed** phase's handoff via the ledger (`last_completed_phase`), NOT the linear phase-1 — `{phase, path, sha256}` or `status: MISSING`/`NEEDS_MIGRATION` | — |
| `changed_files` | git status changes **∪ diff(prev-phase commit, HEAD)**, minus excluded paths, importance-ranked | — |
| `file_hashes` | `{path: sha256}` for each included changed file — so `check` detects a **content** change under an unchanged filename | — |
| `repo_map` | per changed file: `symbols` + one level of local `related_files` (never escapes the project root) | — |
| `acceptance` | acceptance criteria (core-promise first; the first N acceptance-shaped lines of `ACCEPTANCE.md`, **not** phase-filtered in v1) | — |
| `required_checks` | commands/gates this phase must satisfy (from `CLAUDE.md` verify block or phase default) | — |
| `context_policy` | `estimated_tokens`, `maximum_tokens`, `token_method`, `excluded_paths` | — |
| `metadata` | provenance | — |

## Formation rules (enforced by the builder + `check`)

**Include:** current objective; workflow + mode; owner-approved decisions; critical rules; current
phase state; **a reference to the previous handoff** (`path` + `sha256` — the phase agent opens it
for its decisions/risks; the pack does not inline the handoff body); changed/staged/new files; a
small repo map; acceptance criteria (core-promise first); required checks.

**Never auto-include:** `node_modules`, `dist`, `.astro`, `coverage`, `build`, `.next`, `vendor`,
`target`; the whole `.ship/` control dir; binaries & generated files; **lock files (always excluded
in v1** — dependency-task inclusion isn't wired yet); full successful build/test logs; raw research
dumps (`research/raw/`); irrelevant prior-phase documents.

**Budget is a hard rule, not a suggestion.** `estimated_tokens` uses a documented conservative
heuristic (`chars/3.5`, recorded in `token_method` — no tokenizer dependency). If the pack is over
budget the builder trims **non-protected** sections in order (repo-map symbols → repo-map entries →
changed-file list → acceptance detail). **Protected context (critical rules + owner permissions) is
never trimmed**: if it alone exceeds the budget the builder **errors** (`BudgetError`) telling you to
raise `maximum_tokens` — it will not silently drop a rule or a permission.

## What `check` verifies (all executable — `scripts/test_context_builder.py`)

Strict schema (required fields + types; a bare `{schema_version: 1}` is rejected; no smuggled
oversized unknown fields) · **budget RECOMPUTED from canonical content** (a spoofed-low
`estimated_tokens` is caught; non-int is a typed error) · no excluded path leaked · every real
changed file present (unless budget-truncated) · **no critical rule dropped** · **no owner sign-off
removed** · source/input files unchanged (sha) · **included-file content unchanged** (`file_hashes`)
· the **ledger** predecessor handoff exists, matches, and is itself a **valid handoff**
(`check-handoff`: schema, required fields, ≤~2000 tok, safe evidence paths) — or a clear
`NEEDS_MIGRATION` block · `commit_sha` == HEAD (stale) · worktree drift (warn) · corrupt state is
**fail-closed** · non-git handled explicitly. See `spec/handoff-schema.md` for the between-phase record.
