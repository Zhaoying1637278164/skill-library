# Observation policy — bound what tool results add to context

Big tool outputs are the second cost driver after replayed history: a single `cat` of a bundle, a
full green test log, or 200 search hits can dwarf a whole context pack. This policy bounds what an
agent *pulls into context* per observation.

## The rules

| Observation | Rule |
|---|---|
| Read a file | default ≤ **160 lines**; use `Read` `offset`/`limit` or `Grep` to target, don't slurp |
| Search | **files + match counts first**, then open only the top hits; **≤ 20 results** per query |
| Command that **succeeds** | keep a **short summary** (exit 0 + headline numbers); full output → `.ship/logs/` |
| Command that **fails** | keep the **last ~120 lines** (the actual error); full output → `.ship/logs/` |
| Large web research | write straight to `research/` (or `research/raw/`), return a summary, not the dump |
| Phase → orchestrator | a **receipt** (≤15 lines), never the raw log or full report |

## Honesty: what is code-enforced vs a prompt convention

Claude Code does not expose a hook to cap a native tool's *raw* output length, so most of this is a
**discipline the agent follows**, reinforced by the phase agent's brief and the receipt contract —
**not** something a script clips after the fact. Be honest about the split:

**Code-enforced (real):**
- `Read` `limit`/`offset` and `Grep` `head_limit` are actual tool parameters — the agent chooses to
  bound the read, and the harness honours it.
- `context_builder.py` **excludes** `node_modules`/`dist`/logs/raw research from packs (tested).
- Writing full logs to `.ship/logs/` and referencing them by path in the handoff keeps them **out**
  of the pack and the receipt (the handoff `evidence:` field points at them).
- A phase run in a **subagent** returns only its final message — so a verbose phase genuinely does
  **not** replay into the orchestrator's window (this is the isolation that makes receipts real).

**Prompt convention (not code-enforced — do not claim otherwise):**
- The "≤160 lines" / "≤120 lines on failure" / "summarise a success" limits are instructions in the
  phase brief and the skills. There is no post-hoc clipper. If a future Claude Code exposes a
  tool-output hook, wire it here and move the row to "code-enforced".

`ship-doctor` checks that this file exists and that the skills reference it; it cannot check that a
running agent obeyed a prose limit — that's the honest boundary.
