# Handoff schema (v1) — the between-phase record

A **handoff** is the *structured* result a phase leaves for the next one — a ≤~1000-token record,
**not** the phase's chat transcript. The next phase's context pack references it by path + sha256, so
the orchestrator never has to replay a phase's full conversation to know what it produced.

- **Location:** `.ship/handoffs/<phase>-<name>.yml`  (e.g. `.ship/handoffs/3-build.yml`)
- **Written by:** the phase agent at the end of its phase (or `/ship:handoff` for a doc batch).
- **Read by:** `context_builder.py` when building the *next* phase's pack (`prior_handoff`).
- **Commit it.** Unlike context packs (regenerable), handoffs are the durable phase-to-phase trail.

## Fields

```yaml
schema_version: 1
phase: 3
phase_name: build
status: completed          # completed | blocked | partial
commit_sha: "13fed60"      # the SHA this phase's work is bound to

decisions:                 # the choices the next phase must respect
  - "Astro static build"
  - "Pagefind post-build indexing"

changed_files:             # globs are fine here (the pack expands specifics)
  - "src/pages/**"

artifacts:
  - { path: "dist/", status: generated }

verification:              # what ran, with EVIDENCE pointers (logs live in .ship/logs/, not inline)
  - { command: "npm run check", status: passed, evidence: ".ship/logs/3-build/check.log" }
  - { command: "npm run build", status: passed, evidence: ".ship/logs/3-build/build.log" }

open_findings: []          # anything unresolved handed forward
risks:
  - "browser search flow not yet verified"
next_phase_inputs:
  - "Run a real browser smoke test"
```

## Rules

- **Default size ≈ 1000 tokens.** Summaries and pointers, not pasted output. Full stdout/stderr goes
  to `.ship/logs/<phase>/` and is referenced by `evidence:`.
- **Critical constraints, permissions and owner sign-offs are preserved verbatim or by
  hash-referenced source — never replaced by a free LLM paraphrase.** (The context pack re-derives
  them from `CONSTITUTION.md` / `state.yml`, so a paraphrase here can't quietly weaken them.)
- `status: blocked` with an `open_findings` entry is a valid handoff — it routes the next step, it
  doesn't hide the problem.

`templates/handoff.example.yml` is a filled example. The verbose, prose handoff for a *human/agent
doc batch* (drafts for review) is a different artifact — `templates/_HANDOFF.md` via `/ship:handoff`.
