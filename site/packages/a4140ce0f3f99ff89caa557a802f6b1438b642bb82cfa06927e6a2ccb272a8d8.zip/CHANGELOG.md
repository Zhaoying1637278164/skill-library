# Changelog

All notable changes to the AxiomCore plugin. Versioning: [semver](https://semver.org); users receive an update only when the `version` in `plugin.json` is bumped.

## 1.2.0 — 2026-08-03

One naming rule for every file the agent produces.

- **New naming rule** `<acr>-<address>-<NNN>-<name>.<ext>`, replacing the previous one-time / renewable split. `<NNN>` is a running number allocated per work package or work area from the same registry that hands out WP and task numbers. No dates and no version strings in filenames any more — both live inside the document, so a link to a deliverable survives every revision. Applies at both tiers; simple tier manages the numbers silently.
- **Document skeleton**: every markdown deliverable carries a `Version` / `Acronym` / `Last changed` header block under the H1 and a `## Changelog` table as its last section (newest on top). Spreadsheets get a `Changelog` sheet, documents and decks a final changelog section or slide; images carry none. New template `.claude/templates/output-document-template.md`, scaffolded by `/axiom start`.
- **Registries**: `/project` and `/ws` now carry a `Next output` counter per WP and work area, allocated at creation alongside `Next task`.
- **Setup files** follow the rule under the acronym `SU`: `su-<NNN>-<name>.md`, number allocated by `/setup new` at drafting from the new `setup/README.md` register and kept when the file is archived to `setup/done/`. Hierarchy migrations become `su-<NNN>-<acr>-hierarchy-change.md`.
- **`/dev`** documents follow the rule; feature documents are the one exception — `f###` replaces the running number, since it is already the ID the coding project cites.
- **`/lint structure`**: new check for produced filenames, counters that have fallen behind, leftover dates or version strings in filenames, and deliverables missing header or changelog. Reports only; user uploads are never checked.
- Forward-only: existing workspaces keep their current filenames, and no migration is shipped. `/lint` will list them as violations — rename at your own pace or ignore the report.

## 1.1.0 — 2026-07-29

Onboarding clarity and predictive project creation.

- `/axiom start`: new interview step explaining the naming convention (kebab-case, acronym and number prefixes, task IDs at advanced tier), with a pointer to `/setup new` for customizing the convention system-wide.
- `/axiom start`: intro now explains the project vs. workstation distinction (temporary bounded goal vs. permanent recurring routines); the first-win proposal restates it in one line.
- `/project new project` and `/ws new WS`: new **creation mode** choice — **agile** (default, build structure incrementally) or **predictive** (upfront breakdown: WBS on the project side, routine inventory on the workstation side → full proposed tree → approval → one-pass scaffold of registry, folders, and vault mirror).
- README and plugin description repositioned: dedicated project management agent for professional and personal use.

## 1.0.0 — 2026-07-24

First public release.

- `/axiom`: guided onboarding (language, tier, modules), workspace scaffolding, module activation/deactivation, tier and language switching, status.
- Core structure engine: `/project`, `/ws`, `/ingest`, `/lint`, `/setup` with hierarchy, naming, and task-ID protocols; vault wiki memory.
- Optional modules: Voice (soul.md), Brand (brand config), Todos (vault-only, optional Notion mirror), Dev Planning (`/dev`).
- Subagents: planner, reviewer, vault-gardener.
- Progressive disclosure: simple and advanced tiers.
- Language support: agent converses and writes content in the user's language; structure names are Latin-alphabet kebab-case.
