# AxiomCore Configuration

<!-- Owned by /axiom. Other skills read this file but never write it. Do not edit manually unless you know what you're doing — /axiom status shows a friendly view. -->

Configured: {{DATE}}

| Setting | Value |
| :--- | :--- |
| Language | {{LANGUAGE}} |
| Tier | {{TIER}} <!-- simple / advanced --> |
| Nudges | on <!-- on / off --> |

## Modules

| Module | Status | Mode |
| :--- | :--- | :--- |
| M1-core | active | — |
| M2-voice | {{M2V_STATUS}} | — |
| M2-brand | {{M2B_STATUS}} | — |
| M3-todos | {{M3_STATUS}} | {{M3_MODE}} <!-- vault-only / notion --> |
| M4-dev | {{M4_STATUS}} | — |

## Nudge Log

<!-- One line per suggestion: date | nudge | accepted/declined. Declined = 30-day cooldown. -->

| Date | Nudge | Outcome |
| :--- | :--- | :--- |
