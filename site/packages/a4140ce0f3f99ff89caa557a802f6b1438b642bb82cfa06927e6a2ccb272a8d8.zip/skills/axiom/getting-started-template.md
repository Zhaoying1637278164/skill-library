# Getting Started with AxiomCore

AxiomCore is a dedicated project management agent for professional and personal use. It keeps everything you work on in one enforced structure — numbered folders, consistent names, unique task IDs, and a wiki memory that mirrors it all — and works in a disciplined loop: plan → your approval → step-by-step execution.

## Setup (once)

1. **Install the plugin.** Add the AxiomCore marketplace and install the plugin (see `README.md` for the exact commands for Claude Code / Cowork).
2. **Open this folder** with your Claude agent (Cowork: select this folder; Claude Code: start in this directory).
3. **Run `/axiom start`.** A ~5-minute interview sets your language, mode (simple or advanced), and optional modules — Voice, Brand, Todos, Dev Planning. Everything optional can be skipped and activated later.

That's it. The interview replaces `CLAUDE.md` with your configured system and offers to create your first project.

## Daily use

| You want to... | Say / run |
| :--- | :--- |
| Start something new and bounded | `/project new project` |
| Set up a recurring routine | `/ws new WS`, then define its routine |
| Run a routine | `/ws run <area>` |
| Track a task | `/todos new` (Todos module) |
| Check overall status | `/axiom status` (or `/todos status` with the Todos module) |
| Feed documents into the system's memory | Drop them in `vault/sources/`, then `/ingest all` |
| Health-check the whole system | `/lint all` |
| Teach the system a new capability | `/setup new <idea>` |
| Add a skipped module, switch mode or language | `/axiom activate` / `tier` / `language` |

## The structure in one minute

- **Projects** (`projects/`) are temporary — done once. Work happens only in numbered **work packages** inside them.
- **Workstations** (`workstations/`) are permanent — repeated routines. Work happens only in numbered **work areas**.
- **The vault** (`vault/`) is the agent's wiki memory. It mirrors your structure, one page per topic, cross-linked. Browse it with [Obsidian](https://obsidian.md) if you like — optional.
- Folder and file names are always Latin-alphabet kebab-case, in any language (`03-prodvizhenie-sajta` is as valid as `03-marketing`). That one rule keeps the structure stable.

## Where things live

| Folder | What |
| :--- | :--- |
| `projects/` | Temporary work, one folder per project |
| `workstations/` | Recurring routines |
| `vault/` | The agent's wiki memory (sources are read-only) |
| `setup/` | Capability installers; `done/` holds the installed ones |
| `axiom-config.md` | Your configuration (managed by `/axiom`) |

## Feedback

Found a bug or have an idea? Open an issue: <https://github.com/protonium-labs/axiomcore-plugin/issues>.
