# `<Document Title>`

Version: **V001**
Acronym: **`<XX>`**
Last changed: **YYYY-MM-DD**

<!--
Skeleton for every markdown file you produce as a deliverable (CLAUDE.md, Output Hygiene & Naming).

- Filename: <acr>-<address>-<NNN>-<file-name>.md, the number from the owning unit's
  registry (Next output in ids.md / areas.md).
- The header block sits directly under the H1, before any body text. Acronym is the
  owning unit's acronym in uppercase.
- No date and no version in the filename - both live here, so a revision never breaks
  a reference to the document.
- Bumping a version updates Version and Last changed AND adds a changelog row.
- Delete these comments in the produced file.

Rendered into .claude/templates/ by /axiom start; copied, not filled - the placeholders
belong to the produced document, not to this file.
-->

`<body>`

## Changelog

<!-- Last section of the document. Newest version on top. -->

| Version | Date | Summary |
| :--- | :--- | :--- |
| V001 | YYYY-MM-DD | Initial version |
