# brand-config.md

<!-- Filled by the M2-brand interview (/axiom activate M2-brand). Read before generating any presentation, spreadsheet, PDF, or image. -->

Last updated: {{DATE}}

| Setting | Value |
| :--- | :--- |
| Primary color | {{PRIMARY_HEX}} |
| Accent color | {{ACCENT_HEX}} |
| Font (headings) | {{HEADING_FONT}} |
| Font (body) | {{BODY_FONT}} |
| Logo | `brand/images/{{LOGO_FILE}}` |
| Tone | {{BRAND_TONE}} |

## Templates

| File | Use for |
| :--- | :--- |
| `brand/templates/template.pptx` | Presentations (if present) |
| `brand/templates/template.xlsx` | Spreadsheets (if present) |

Rules: logo on title slides only unless asked; spreadsheets use real formulas, never hardcoded values; skip silently if a template file is absent.
