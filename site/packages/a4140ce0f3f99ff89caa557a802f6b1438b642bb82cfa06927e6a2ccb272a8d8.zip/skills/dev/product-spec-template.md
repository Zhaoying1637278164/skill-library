# `<Project Name>` — Product Specification

Version: **V001**
Acronym: **`<ACR>`**
Last changed: **YYYY-MM-DD**

<!-- The WHAT and WHY. No technology choices here - those belong in the tech spec. -->

## Problem (Core Idea)

<!-- What pain exists today, for whom, and the one-sentence value proposition. -->

## Users / Personas

| Persona | Needs |
| :--- | :--- |
| `<persona>` | `<what they need from the product>` |

## User Stories

<!-- Stable IDs, never reused. Format: As a <persona>, I want <goal>, so that <benefit>. Acceptance criteria per story. -->

### US-01 — `<short title>`

As a `<persona>`, I want `<goal>`, so that `<benefit>`.

Acceptance criteria:

- `<criterion>`

## Core Features

<!-- Feature areas at product level (not yet implementation features). Reference the US-IDs they serve. -->

| Area | Description | Serves |
| :--- | :--- | :--- |
| `<area>` | `<one line>` | US-01 |

## Out of Scope

<!-- Explicit non-goals for the current version. YAGNI. -->

## Monetization

<!-- Plans, pricing, limits. Delete section if not applicable. -->

## Roadmap

<!-- Phases: MVP / later phases / future ideas. Reference US-IDs. -->

## Open Points

<!-- Points the user deferred or that remain unclear. Never resolved by the agent. Blockers for /dev feature on affected requirements. -->

| Point | Affects | Raised | Status |
| :--- | :--- | :--- | :--- |
| `<open question>` | US-01 | YYYY-MM-DD | open |

## Status

<!-- In planning | In development | Live -->

## Changelog

<!-- Last section of the document. Newest version on top. -->

| Version | Date | Summary |
| :--- | :--- | :--- |
| V001 | YYYY-MM-DD | Initial specification |
