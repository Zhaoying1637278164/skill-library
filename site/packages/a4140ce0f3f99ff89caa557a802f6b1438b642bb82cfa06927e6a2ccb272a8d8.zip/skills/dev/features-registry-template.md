# `<project>` — Feature Registry

Registry for the Software Development Planning Protocol (root CLAUDE.md, Software Development Planning Protocol). Single source of
truth for the feature counter. Created by `/dev spec`, updated by `/dev feature`. IDs are
monotonic and never reused.

Acronym: **`<ACR>`**
Next feature: **001**
Planning WP: `projects/<project>/<wp>`
Specs: `<acr>-<address>-<NNN>-product-spec.md` · `<acr>-<address>-<NNN>-tech-spec.md` (current version: V001)

| ID | File | Type | Modifies | Implements | Spec | Created |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |

Status of features (done / ongoing) is tracked via `/todos`; todos reference feature IDs, not
vice versa.
