# `<Project Name>` — Project Plan

Version: **V001**
Acronym: **`<ACR>`**
Last changed: **YYYY-MM-DD**
Baseline: product spec **`<V###>`**, tech spec **`<V###>`**

<!-- The WHEN and IN WHAT ORDER. No new requirements here - those belong in the specs (/dev revise). -->

## Purpose

<!-- What this plan covers: which phase / release, which requirement range. What is explicitly outside it. -->

<!-- State the effort rule verbatim: effort is given in hours of work only. No durations, no dates, no calendar - pace is the user's to set, and a schedule built on a guessed pace is wrong from day one. -->

## How this plan is structured

<!-- Name the streams and justify the shape. Foundation packages are horizontal (a repo cannot be sliced before it exists); everything from the first domain package on is a vertical slice - model + API + UI + tests for one coherent behaviour, deployable and demonstrable alone. Say why: layer-shaped packages finish months apart, show nothing in between, and defer integration risk to the end. -->

```mermaid
flowchart LR
    A[A: `<stream>`<br/>P01-P0n<br/>`<h>` h] --> B[B: `<stream>`<br/>P0n-P0n<br/>`<h>` h]
```

**Package IDs are `P##`** — deliberately distinct from task IDs (`XX-WW-TT`, root CLAUDE.md, Task ID Protocol) and feature IDs (`XX-F###`), which they never collide with.

**Definition of done**, every package from the first vertical slice on: `<criterion - e.g. API endpoint and UI screen both present, tests green, deployed and exercised on live infrastructure>`.

## Stream A — `<name>`

<!-- One table per stream. Every package: what is in it, which US/TR it covers, what it waits on, its effort in hours. -->

| # | Package | Contents | Covers | Depends on | Effort |
| :--- | :--- | :--- | :--- | :--- | ---: |
| P01 | **`<package name>`** | `<what is built>` | US-01, TR-01 | — | `<h>` h |

**Stream A: `<h>` h.** <!-- One line on what gates this stream, or what runs in parallel inside it. -->

## Milestones

<!-- Gates, not dates. Each is a decision point. Call out the one that retires the most integration risk and say why. -->

| # | Milestone | Reached when |
| :--- | :--- | :--- |
| M1 | **`<name>`** | `<packages done, and what is demonstrably true>` |

## Effort summary

| Stream | Packages | Effort |
| :--- | :--- | ---: |
| A — `<name>` | P01–P0n | `<h>` h |
| **Total** | **P01–P0n** | **`<h>` h** |

Estimate class: `<order of magnitude / budget / definitive>`, **range `<low>`–`<high>` h**. <!-- State whose hours these are and what they include (e.g. the user's own hours, review included - not agent wall-clock). -->

## Requirement coverage

<!-- Mandatory. Every in-scope US and TR maps to exactly one owning package. Requirements deferred to a later phase are named as absent, not silently missing. This table is what proves nothing was dropped between spec and plan. -->

| Requirement | Package |
| :--- | :--- |
| US-01 `<short title>` | P0n |
| TR-01 `<short title>` | P0n |

## Assumptions

<!-- Numbered. Whose hours, what baseline spec versions, what is assumed available, what is excluded from the estimate. An assumption that changes re-versions the plan. -->

1. `<assumption>`

## Delivery risks

<!-- Distinct from the product risks in the product spec: these threaten the plan, not the product. Oversized packages, review throughput, structural friction, work that cannot be compressed by adding hours, scope pull from later phases. -->

| Risk | Assessment |
| :--- | :--- |
| **`<risk>`** | `<why it threatens delivery, and what to do about it>` |

## Out of scope of this plan

<!-- Later phases, non-delivery work, and the boundary to the coding project (root CLAUDE.md, Software Development Planning Protocol: this document plans the work, the coding project performs it). -->

## Open Points

<!-- Plan-level open points only - delivery questions, not requirements. Requirement gaps belong in the specs. IDs OP-P##, never reused. Unlike the specs' open points, these do not block: an unresolved spec open point becomes a package. -->

| Point | Affects | Raised | Status |
| :--- | :--- | :--- | :--- |
| OP-P01 — `<delivery question>` | P0n | YYYY-MM-DD | open |

## Status

<!-- In planning | Approved as the delivery baseline | Superseded -->

## Changelog

<!-- Last section of the document. Newest version on top. -->

| Version | Date | Summary |
| :--- | :--- | :--- |
| V001 | YYYY-MM-DD | Initial delivery plan against product spec `<V###>` / tech spec `<V###>` |
