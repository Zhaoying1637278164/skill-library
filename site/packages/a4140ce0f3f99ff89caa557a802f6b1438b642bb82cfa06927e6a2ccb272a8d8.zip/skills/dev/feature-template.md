---
id: <ACR>-F###
title: <short feature title>
type: new            # new | change
modifies: []         # e.g. [<ACR>-F025] for type: change
implements: []       # e.g. [US-12, TR-04]
spec_version: V001   # spec version this feature was planned against
created: YYYY-MM-DD
---

<!-- Document title comes from the frontmatter `title` field; markdownlint (MD025) treats it as the H1. Body starts at ## level. -->

## Goal

<!-- One or two sentences: what exists when this feature is done. For type: change - what changes relative to the modified feature, delta only. -->

## Spec References

<!-- Quote or summarize the relevant US/TR requirements so the coding agent does not need the full specs. -->

<!--
DESIGN SECTIONS (between Spec References and Tasks) — the four sections below are CONDITIONAL: keep one
only when the feature warrants it (see each section's rule), delete the rest entirely. Everything here
is pseudo-code / pseudo-signatures, never copied source. Binding rule: when the coding repo is readable
via git MCP the sections reflect the real code and are binding; on a greenfield feature they are a
proposed reference design (banner) the coder may deviate from — except Data & Error Flow and any public
interface, which are always binding. Delete this comment in the finished document.
-->

## Affected Structure

<!--
INCLUDE when the feature creates or modifies more than one file, or adds folders.
OMIT (delete this section) when a single existing file changes trivially — instead note
`Files: <path> (modified)` in the relevant task.
Real paths when the repo is readable (binding); otherwise a proposed tree — prefix it with:
"> Proposed reference design — the coding agent may deviate, rationale recorded in History."
Markers: + created, ~ modified, - deleted. Replace the example.
-->

```text
src/
  payments/
  + charge.py          # new: charge orchestration
  ~ __init__.py        # export payCart
  ~ models.py          # + Receipt, Txn
tests/
  + test_charge.py     # new
```

## Logic

<!--
INCLUDE when control flow is non-trivial (branching, loops, retries, state transitions).
OMIT (delete this section) when the flow is linear.
Binding when the repo is readable, else proposed (add the banner). Pseudo-code labels, never source.
Keep ONE copy of the legend, above the FIRST diagram in the document (move it under Data & Error Flow
if Logic is omitted); delete the other copy. Shared vocabulary — shape carries the role, muted colour
reinforces: Start/End ([ ]) · Process [ ] · Decision { } · I/O [/ /] · Loop {{ }} · Data store [( )] ·
File/data [[ ]] 📄 · Error [ ] ✗.
-->

<!-- LEGEND — render once, above the first diagram present: -->

```mermaid
flowchart LR
  a([Start · End]):::startend
  b[Process]:::func
  c{Decision}:::decision
  d[/Input · Output/]:::io
  e{{Loop}}:::loop
  f[(Data store)]:::store
  h[[📄 File · data]]:::file
  g[✗ Error]:::error
  a ~~~ b ~~~ c ~~~ d ~~~ e ~~~ f ~~~ h ~~~ g
  classDef startend fill:#ececea,stroke:#9a9a90,color:#0b0b0b;
  classDef func     fill:#e0f5e9,stroke:#3a9e69,color:#0b0b0b;
  classDef decision fill:#fbeecc,stroke:#c99524,color:#0b0b0b;
  classDef io       fill:#dbe8fb,stroke:#4884d4,color:#0b0b0b;
  classDef loop     fill:#e7e2f6,stroke:#6f61c4,color:#0b0b0b;
  classDef store    fill:#d8f2e8,stroke:#3aa985,color:#0b0b0b;
  classDef file     fill:#f7dfe9,stroke:#cf5a86,color:#0b0b0b;
  classDef error    fill:#fae8e8,stroke:#d5595a,color:#0b0b0b;
```

<!-- LOGIC diagram — replace with this feature's control flow: -->

```mermaid
%%{init: {'flowchart': {'nodeSpacing': 45, 'rankSpacing': 55, 'curve': 'basis'}}}%%
flowchart TD
  S([payCart called]):::startend
  IN[/cart/]:::io
  E1{cart empty?}:::decision
  EMP[✗ EmptyCart error]:::error
  L{{loop items}}:::loop
  D1{stock == 0?}:::decision
  ACC[total += price]:::func
  CH[charge total]:::func
  D2{charge ok?}:::decision
  RT{{"retries < 3?"}}:::loop
  DL[✗ dead-letter → PayError]:::error
  OUT[/Receipt/]:::io
  END([return]):::startend

  S --> IN --> E1
  E1 -- yes --> EMP --> END
  E1 -- no --> L
  L --> D1
  D1 -- yes --> L
  D1 -- no --> ACC --> L
  L -- done --> CH --> D2
  D2 -- no --> RT
  RT -- yes --> CH
  RT -- no --> DL --> END
  D2 -- yes --> OUT --> END

  classDef startend fill:#ececea,stroke:#9a9a90,color:#0b0b0b;
  classDef func     fill:#e0f5e9,stroke:#3a9e69,color:#0b0b0b;
  classDef decision fill:#fbeecc,stroke:#c99524,color:#0b0b0b;
  classDef io       fill:#dbe8fb,stroke:#4884d4,color:#0b0b0b;
  classDef loop     fill:#e7e2f6,stroke:#6f61c4,color:#0b0b0b;
  classDef error    fill:#fae8e8,stroke:#d5595a,color:#0b0b0b;
```

## Data & Error Flow

<!--
INCLUDE when data crosses a boundary (UI↔API↔DB, external service) or there are error paths worth
naming. OMIT (delete this section) when pure in-memory, no I/O, no failure modes.
ALWAYS binding — it states requirements, not code arrangement.
Pick ONE form and delete the other: Pipeline (flowchart LR) reuses the legend above; Sequence
(sequenceDiagram) has no node shapes, so success/error are shaded regions (green/red).
-->

<!-- PIPELINE form (default): -->

```mermaid
%%{init: {'flowchart': {'nodeSpacing': 40, 'rankSpacing': 60, 'curve': 'basis'}}}%%
flowchart LR
  CFG[[📄 pricing rules]]:::file
  REQ[/POST #47;api#47;pay/]:::io
  V[validate]:::func
  CH[charge via PSP]:::func
  D{charge result?}:::decision
  RT{{"retries < 3?"}}:::loop
  SAVE[(Receipt store)]:::store
  DL[✗ dead-letter]:::error
  OK[/200 receipt_id/]:::io
  DEC[/402 reason/]:::io
  E500[/500/]:::io

  CFG --> V
  REQ --> V --> CH --> D
  D -- ok --> SAVE --> OK
  D -- declined --> DEC
  D -- provider error --> RT
  RT -- yes --> CH
  RT -- no --> DL --> E500

  classDef func     fill:#e0f5e9,stroke:#3a9e69,color:#0b0b0b;
  classDef decision fill:#fbeecc,stroke:#c99524,color:#0b0b0b;
  classDef io       fill:#dbe8fb,stroke:#4884d4,color:#0b0b0b;
  classDef loop     fill:#e7e2f6,stroke:#6f61c4,color:#0b0b0b;
  classDef store    fill:#d8f2e8,stroke:#3aa985,color:#0b0b0b;
  classDef file     fill:#f7dfe9,stroke:#cf5a86,color:#0b0b0b;
  classDef error    fill:#fae8e8,stroke:#d5595a,color:#0b0b0b;
```

<!-- SEQUENCE form (when request/response timing across actors matters): -->

```mermaid
%%{init: {'theme':'base'}}%%
sequenceDiagram
  autonumber
  participant UI
  participant API
  participant PSP as Payment provider
  participant DB
  UI->>API: POST /api/pay {amount, currency}
  API->>PSP: charge(amount)
  rect rgb(224, 245, 233)
    Note over API,DB: success
    PSP-->>API: txn_id
    API->>DB: insert Receipt
    API-->>UI: 200 {receipt_id}
  end
  rect rgb(250, 232, 232)
    Note over API,UI: failure
    PSP-->>API: 402 declined
    API-->>UI: 402 {reason}
    PSP-->>API: provider error (after 3 retries)
    API->>DB: insert dead-letter
    API-->>UI: 500
  end
```

## Interfaces

<!--
INCLUDE when the feature exposes or changes functions, classes, endpoints, or schemas.
OMIT (delete this section) for pure style/markup with no callable surface.
Public surface always binding; internal signatures binding if the repo is readable, else proposed.
Language-neutral pseudo-signatures, never source. Replace the example.
-->

```text
HTTP
  POST /api/pay
    req  { amount: int (cents), currency: str }
    resp 200 { receipt_id: str } | 402 { reason: str } | 500

Functions
  payCart(cart: list[Item]) -> Receipt          # public, binding
  charge(amount: Money, retries: int = 3) -> Txn # internal
  apply_discount(total: Money, code: str) -> Money

Schemas
  Receipt { id: str, total: Money, txn: Txn }
  Txn     { id: str, status: "ok" | "declined" }
```

## Tasks

<!-- Bite-sized, numbered, self-contained. No placeholders: no TBD, no "add error handling", no "similar to...". Exact file paths where the codebase was readable at planning time; otherwise WHAT + acceptance criteria. -->

### T1 — `<task title>`

`<what to do>`

Acceptance criteria:

- `<criterion>`

### T2 — `<task title>`

`<what to do>`

Acceptance criteria:

- `<criterion>`

## Out of Scope

<!-- What this feature deliberately does NOT include. -->

## Notes

<!-- Anything extra the coding agent should know. Delete if empty. -->

## History

<!-- Earliest to latest. Maintained in the coding project during implementation. -->

- YYYY-MM-DD — Created (V001)
