# `<Project Name>` — Technical Specification

Version: **V001**
Acronym: **`<ACR>`**
Last changed: **YYYY-MM-DD**

<!-- The HOW. Every technical decision the coding agent must respect. -->

## Tech Stack

| Category | Choice | Notes |
| :--- | :--- | :--- |
| Framework | `<choice>` | |
| Language | `<choice>` | |
| Database | `<choice>` | |
| Auth | `<choice>` | |
| Deployment | `<choice>` | |

## Technical Requirements

<!-- Stable IDs, never reused. Hard constraints, conventions, non-functional requirements (performance, security, privacy, accessibility, i18n). -->

### TR-01 — `<short title>`

`<requirement, testable where possible>`

## Data Model

<!-- Schema draft (e.g. Prisma, SQL, ERD). Mark as evolving if not final. -->

```text
<schema>
```

## Architecture

<!-- Components and data flow. Mermaid diagrams welcome. -->

## Auth Flow

<!-- Delete section if not applicable. -->

## External Services / APIs

<!-- Third-party dependencies, keys, rate limits. Delete if none. -->

## Development Conventions

<!-- Branching, testing expectations, CI, monitoring - anything the coding project must follow. -->

## Open Points

<!-- Points the user deferred or that remain unclear. Never resolved by the agent. Blockers for /dev feature on affected requirements. -->

| Point | Affects | Raised | Status |
| :--- | :--- | :--- | :--- |
| `<open question>` | TR-01 | YYYY-MM-DD | open |

## Changelog

<!-- Last section of the document. Newest version on top. -->

| Version | Date | Summary |
| :--- | :--- | :--- |
| V001 | YYYY-MM-DD | Initial specification |
