---
name: skill-name
description: One sentence saying what this skill does. Mention the available actions so Claude knows when the skill is relevant.
---

# Task

Execute the requested action: $ARGUMENTS

Calling rule: `/<skill> <action> <arguments>`. An action is: command + argument + (other inputs). Similar or nested actions may be merged into one block.

If the requested action is ambiguous or contradictory (matches multiple actions, arguments conflict with the action, or the intent is unclear), do NOT guess: flag the ambiguity and ask for clarification before executing.

---

## If action is empty

Describe this skill: its purpose and the actions table from "overview". Do not execute anything.

## If action is "overview" (or unknown)

Show all options in tabular form:

| Argument | Action |
| :--- | :--- |
| `action-one <required-arg>` | <!-- one line --> |
| `action-two [optional-arg]` | <!-- one line --> |
| `overview` | This table |

If the action was unknown, say so first, then show the table.

---

## If action is "action-one"

1. Check $ARGUMENTS (after "action-one"):
   - If `<expected form>`: proceed.
   - If empty: error — "action-one requires `<required-arg>`".
2. <!-- Numbered, concrete steps. -->
3. Confirm the result to the user.

---

## If action is "action-two"

1. <!-- Steps. Reuse logic from other actions by reference, don't duplicate. -->

---

## After any action

- Append to `vault/log.md`.
- Update `vault/index.md` if pages were added or removed.

## Notes

<!-- Constraints, edge cases, supporting files in this folder. -->
