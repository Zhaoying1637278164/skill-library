# AxiomCore

**A dedicated project management agent for Claude (Cowork and Claude Code) — a disciplined helper for project managers, consultants, and anyone who runs projects and routines, professionally or personally.**

Most AI assistants answer questions and forget. AxiomCore turns Claude into a system that *keeps order*: every project, file, and note gets one enforced place and one consistent name — numbered folders, unique task IDs, and a wiki memory that mirrors your whole structure. Nothing gets lost, and nothing gets invented behind your back: the agent always works in a disciplined loop — **plan → your approval → step-by-step execution**.

## Why AxiomCore

1. **Structure that enforces itself.** Projects and routines live in a fixed hierarchy with numbered folders (`01-launch`, `02-marketing`) and globally unique task IDs (`PW-01-03`). The agent applies the rules on every action — you never tidy up after it.
2. **A memory that compounds.** The vault is a cross-linked wiki the agent maintains as you work: goals, decisions, run histories, reusable knowledge. Browseable in [Obsidian](https://obsidian.md), owned by you, plain markdown.
3. **You stay in control.** Nothing structural happens without a plan you approved; execution is step-by-step with validation. Tasks are never put on your plate without your explicit OK.
4. **It stays healthy.** `/lint` audits the whole system on demand — broken links, orphan pages, naming violations, registry drift.
5. **It grows with you.** `/setup` installs new capabilities through a drafted, reviewable installer file — the system extends without restructuring.

## Install

```text
/plugin marketplace add https://github.com/protonium-labs/protonium-marketplace
/plugin install axiomcore@protonium
```

Open a new folder (or a copy of the [workspace template](https://github.com/protonium-labs/axiomcore-template)) and run:

```text
/axiom start
```

### Reinstalling or setting up a second workspace

AxiomCore keeps no global state — everything lives in the workspace folder (`axiom-config.md`, `CLAUDE.md`, `vault/`). A new folder is always a fresh install. If the agent still "remembers" a previous workspace, the context is coming from the session, not the plugin: run `/axiom start` in a **new session** with only the target folder open (Claude Code: `cd` into the folder, start a fresh session, and don't nest it inside an existing workspace; Cowork: new chat with only the target folder connected — and if the app's own memory recalls the old setup, tell it to forget it). The old workspace is never touched.

## What onboarding looks like

`/axiom start` runs a ~5-minute interview: your working language → simple or advanced mode → the naming convention (explained, customizable) → which optional modules you want → what you're working on right now. It then scaffolds the workspace and offers to create your first project from your own answer — so the first thing you see is the system working on *your* work. Everything optional is skippable; the agent suggests skipped modules later, only when your usage would clearly benefit, and never more than once per session.

## Modules

| Module | What it adds | Default |
| :--- | :--- | :--- |
| **Core — Structure Engine** | Projects, workstations (routines), vault memory, `/lint`, `/setup` | Always on |
| **Voice** | A `soul.md` voice profile so drafts sound like you | Optional |
| **Brand** | Colors, fonts, logo, tone applied to generated documents | Optional |
| **Todos** | Task tracking with confirmation gate; optional Notion Kanban mirror | Optional |
| **Dev Planning** | Software planning: spec → delivery plan → immutable feature documents | Optional (advanced) |

Two disclosure tiers: **simple** (2-level projects, numbering managed silently) and **advanced** (3-level hierarchies, exposed ID protocol, `/dev`). Switch anytime with `/axiom tier`.

## Skills & agents

| Skill | Purpose |
| :--- | :--- |
| `/axiom` | Onboarding, module activation, tier & language switches, status |
| `/project` | Projects → work packages → tasks, with registries and unique IDs |
| `/ws` | Workstations: routines defined once, run repeatedly, compared across runs |
| `/todos` | Tasks in your files; optional Notion board (fully functional without it) |
| `/ingest` | Turn dropped documents into linked wiki-memory pages |
| `/lint` | Health checks: links, orphans, naming, structure, registries |
| `/setup` | Teach the system new capabilities; structural migrations |
| `/dev` | Product spec → tech spec → delivery plan → feature documents |

Subagents: **planner** (numbered plans with open questions), **reviewer** (pre-handoff quality gate), **vault-gardener** (memory freshness audits).

## Languages

The agent starts in English and asks your preferred language first — conversation and all generated content then follow it. One rule keeps the structure stable in every language: folder and file names use Latin-alphabet kebab-case, in any language (`03-prodvizhenie-sajta` is as valid as `03-marketing`).

## Requirements

Claude Code or Claude Cowork with plugin support. Optional: Node.js (for markdownlint in `/lint`), a Notion connector (for the Todos board mirror), Obsidian (for browsing the vault).

## Feedback

Bugs and feature requests: [GitHub Issues](https://github.com/protonium-labs/axiomcore-plugin/issues). Questions and ideas: [Discussions](https://github.com/protonium-labs/axiomcore-plugin/discussions).

## License

MIT — see [LICENSE](LICENSE). Dev-planning methodology adapted from the MIT-licensed [Superpowers](https://github.com/obra/superpowers) project.

---

AxiomCore is a **Protonium** product. Marketplace: [protonium-labs/protonium-marketplace](https://github.com/protonium-labs/protonium-marketplace).
