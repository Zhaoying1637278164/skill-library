<div align="center">
  <a href="https://www.cognee.ai">
    <img src="https://raw.githubusercontent.com/topoteretes/cognee-integrations/main/assets/cognee-logo.svg" alt="Cognee" width="260">
  </a>
  <p><strong>Cognee memory for Claude Code</strong> — persistent knowledge-graph memory with automatic capture of prompts and tool traces, and relevant recall on every turn.</p>
  <p>
    <a href="https://docs.cognee.ai">Docs</a> ·
    <a href="https://discord.gg/NQPKmU5CCg">Discord</a> ·
    <a href="https://github.com/topoteretes/cognee">Cognee core</a>
  </p>
</div>

# Cognee Memory Plugin for Claude Code

Adds persistent memory to Claude Code through Cognee.

The integration:
- captures prompts, tool traces, and assistant responses into session memory
- injects relevant context on prompt submit
- syncs session memory into graph memory on session end/final exit

## Install

**Requirements.** Any Python 3.9 or newer available as `python3` (or `python`) on PATH — the hooks are stdlib-only HTTP clients and never import cognee, so the Python 3.9.6 that ships with macOS's Xcode Command Line Tools is enough. In local mode the plugin brings its own runtime for the Cognee server: it fetches [uv](https://docs.astral.sh/uv/) into `~/.cognee-plugin/uv` and builds a Python 3.12 virtualenv with it (reusing a 3.12 already on the machine, otherwise downloading a ~66 MB standalone build). Only when uv is absent *and* cannot be downloaded does the plugin fall back to the host interpreter, and that fallback needs Python 3.10 or newer: on an older host it refuses, logs `host_python_too_old_for_venv` to `hook.log`, and every session start says so until uv or a newer python3 is installed. Cloud mode never builds a runtime. (SDK-based integrations such as LangGraph or CrewAI import cognee in-process and need Python 3.10+; see [`CONFIGURATION.md`](../CONFIGURATION.md#python-version-requirements).)

Install from the Claude Code marketplace. The recommended way is from your shell, *before* launching Claude Code, so the first `claude` launch is a clean session that runs the plugin bootstrap automatically — no in-app restart needed:

```bash
claude plugin marketplace add topoteretes/cognee-integrations
claude plugin install cognee-memory@cognee
```

These CLI subcommands use the exact same plugin manager as the in-chat `/plugin` commands — same marketplace clone, same install cache, same global state — they just run before you enter the terminal. Default install scope is `user` (global); pass `--scope project` or `--scope local` to confine it.

Then configure your runtime mode — **once** — in `~/.cognee/.env`. The file is created with a commented template on the first session start; values in it act exactly like shell exports (a real `export` in your shell still overrides the file, per terminal). It is shared with the Codex plugin, so both read the same configuration. Lines may optionally start with `export `, so existing export lines can be pasted verbatim. Pick one of the two modes below — or configure **both** and flip a terminal with a single export (see [Which mode wins, and how to switch](#which-mode-wins-and-how-to-switch)).

**Cognee Cloud or a remote server** — set both (one paste, no editor needed):

```bash
mkdir -p ~/.cognee
cat >> ~/.cognee/.env <<'EOF'
COGNEE_BASE_URL="https://your-instance.cognee.ai"
COGNEE_API_KEY="ck_..."
EOF
chmod 600 ~/.cognee/.env
```

> The plugin is an HTTP client in both modes; the hooks never import cognee in-process. Cloud mode does **not** install a local Cognee runtime. The bundled virtualenv (`~/.cognee-plugin/venv`) is built only in local mode, where it runs the local Cognee server the hooks talk to.

**Local mode** (default when `COGNEE_BASE_URL` is not set) — the plugin bootstraps a local Cognee API at `http://localhost:8011`. `COGNEE_API_KEY` is auto-minted if absent. The server needs an LLM for cognify: either give it a provider key of your own —

```bash
mkdir -p ~/.cognee
cat >> ~/.cognee/.env <<'EOF'
LLM_API_KEY="sk-..."
EOF
chmod 600 ~/.cognee/.env
```

— or set nothing at all and let it run on your **Claude subscription**: with no `LLM_API_KEY` configured and the `claude` CLI on PATH, session start switches the local server's LLM calls to the [Claude observer](#claude-observer-local-mode-on-your-claude-subscription) (`claude -p` behind a loopback OpenAI-compatible shim) and embeddings to a local model. No key, no extra account.

**Default user and its password.** The local server is started with `DEFAULT_USER_EMAIL=default_user@example.com` and `DEFAULT_USER_PASSWORD=default_password`, which is how cognee 1.6.0 and later create the default user at all (a server started without `DEFAULT_USER_PASSWORD` creates no default account, and the password is set once and never rewritten). The plugin logs in as that user to mint its owner API key, so a fresh install needs no manual step and an existing install keeps working. Exporting `DEFAULT_USER_EMAIL`/`DEFAULT_USER_PASSWORD` yourself overrides what the plugin passes; `COGNEE_USER_EMAIL`/`COGNEE_USER_PASSWORD` pick the user the plugin logs in as, and a non-default user must already exist on the server. When pointing at a server you run yourself (`COGNEE_BASE_URL`), either start it with `DEFAULT_USER_PASSWORD` set to the same value as `COGNEE_USER_PASSWORD`, or set `COGNEE_API_KEY` so no login is needed; a server without either answers the login with an error that says so.

**Windows (PowerShell)** — same idea, same file:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.cognee" | Out-Null
@'
COGNEE_BASE_URL="https://your-instance.cognee.ai"
COGNEE_API_KEY="ck_..."
'@ | Add-Content "$env:USERPROFILE\.cognee\.env"
```

Re-running any of these blocks is safe: when a key appears more than once, the **last value wins**, so pasting again with a new value updates the configuration. Editing the file directly (`nano ~/.cognee/.env`) works too. Changes apply on the next session launch. Plain shell `export`s in the launching terminal still take precedence over `~/.cognee/.env` — useful to override the shared config for one terminal. See [Managing the env file](#managing-the-env-file) for the file format and how to add, change, or remove variables later.

### Which mode wins, and how to switch

You can configure **both modes at once** — keep `COGNEE_BASE_URL` + `COGNEE_API_KEY` *and* `LLM_API_KEY` in the file together. The mode is then decided per terminal, by three rules in order:

1. **A `COGNEE_BACKEND` export wins.** `export COGNEE_BACKEND=local` (or `=cloud`) pins that terminal to that mode. Nothing else needs to change.
2. **Otherwise, cloud wins when configured.** If `COGNEE_BASE_URL` is set (in the file or the shell), the plugin connects to it.
3. **Otherwise, local.** With no URL anywhere, the plugin boots the local server.

So with both modes in `~/.cognee/.env`:

```bash
claude                          # → cloud (the configured URL routes)
COGNEE_BACKEND=local claude     # → local, this launch only
export COGNEE_BACKEND=local     # → local for every launch from this shell
```

Details worth knowing:

- **The switch is pinned.** `COGNEE_BACKEND=cloud` with no `COGNEE_BASE_URL` configured still counts as cloud: the plugin does **not** silently fall back to local, and the status line shows `✕ (missing_cognee_base_url)` so you know exactly what to fix.
- **To go local, use the switch — not `unset COGNEE_BASE_URL`.** Unsetting doesn't work: the env file re-injects the URL at the next launch. (Deleting the line from the file works, but that changes the default for *every* terminal.)
- The shared `COGNEE_BACKEND` flips both the Claude Code **and** Codex plugins in that terminal. To flip only one, use `COGNEE_CLAUDE_BACKEND` / `COGNEE_CODEX_BACKEND` — the plugin-specific name beats the shared one.
- Accepted values: `local` (aliases: `native`, `sdk`) and `cloud` (aliases: `http`, `api`, `server`). Anything else is ignored.
- `COGNEE_BACKEND` can also live in `~/.cognee/.env` to make a mode the durable default; a shell export still overrides it per terminal.
- Not sure what a terminal resolved? The status line's mode field shows it live, and `doctor.py` prints the decision with its cause, e.g. `Mode: Local — forced by COGNEE_BACKEND=local`.

Then launch `claude`. All setup happens in the `SessionStart` hook, which fires once per fresh launch — so with the shell install above, the first launch connects memory with no extra steps.

If you instead installed **from inside the chat** with the `/plugin` slash commands, you must **restart Claude Code** (start a new session) before memory connects: `/reload-plugins` makes the skills and agents available in the current session but does not run `SessionStart`. On a first-run marketplace install the marketplace is also fetched asynchronously, so `SessionStart` may not fire that session even with a reload. Either way, make sure your configuration is in `~/.cognee/.env` (or exported in the shell you launch from).

On startup you should see a "Cognee Memory Connected" system message.

## Auth

The integration authenticates with **one principal** (one API key, one user), and —
on servers that support it — a **plugin identity** derived from that principal: a
dedicated agent sub-user with its own labeled API key, provisioned via
`POST /api/v1/integrations/plugins/claude-code/provision`. Running under a plugin
identity lets the cognee dashboard attribute sessions, traces and datasets to this
plugin; datasets the plugin creates are automatically shared with your user.

Key resolution order for data-plane traffic:
1. `~/.cognee-plugin/claude-code/agent_key.json` (the provisioned plugin identity)
2. `COGNEE_API_KEY` env var
3. `~/.cognee-plugin/api_key.json` (cached from a previous mint)
4. Auto-mint from the default local user (local mode only), then cache to `api_key.json`

Provisioning policy:
- `COGNEE_PLUGIN_IDENTITY` selects the identity policy:
  - `auto` (default) — an identity **in service of shared agent memory** (below). When
    shared memory is on, session start provisions one (create-only, never rotating a key
    another machine holds), wires the shared role, and pins the canonical dataset; if that
    wiring cannot be done (older server, not the tenant owner, tenant-less user who already
    owns data) the plugin stays on the principal key and says why in `cognee-doctor`. With
    shared memory off it stays on the principal.
  - `true` — explicit identity: provisioning is required and never falls back to the owner.
    Servers without the SDK's `create_only` capability, a cached credential bound to another
    principal, or rejected credentials stop with an error instead of rotating keys or
    silently using the owner's authority.
  - `false` — principal mode; a cached identity is ignored.
- A cached credential is bound to its server and principal. Under `auto`, a credential the
  server rejected or that belongs to another account is not used and the plugin runs as
  the principal (logged); under `true` that is an error, and reconnecting a revoked
  identity requires explicit reconnection.
- Use dataset UUIDs for shared write targets. Dataset switching checks effective write
  permissions. Set `COGNEE_PLUGIN_READ_DATASET_IDS` to a JSON array of allowed UUIDs for
  graph recall across datasets you granted yourself; it takes precedence over the datasets
  shared memory resolved, and session history stays scoped to its own dataset.

### Shared agent memory

A plugin identity is its own cognee user, and grants only flow child→parent: your user
sees what the agent writes, but the agent sees nothing your user (or another plugin's
agent) owns. Left alone, that would silo memory per plugin — Claude Code could not recall
what Codex stored. **Shared agent memory, on by default, makes every plugin agent of
your user share one memory:**

- Session start ensures your user owns a tenant (one is created for a fresh, tenant-less
  install) and a `cognee-agent` role in it, adds the agent to both, and grants the role
  read+write on your datasets. Grants are backfilled on every session start and every
  ~60 s by the idle watcher, so a dataset another plugin creates becomes visible here
  without a restart.
- The launch's dataset is a **canonical, user-owned dataset addressed by UUID** (the
  launch record's `dataset_id` for writes, `dataset_ids` for recall — including any
  same-named per-agent copies from before). Every hook and skill addresses it that way;
  a plain name would only resolve among datasets the agent itself owns.
- All tenant/role/grant calls run as your user, never as the agent — the server only
  lets the tenant owner manage roles, so an agent key cannot widen its own access.

Turn it off with `"shared_agent_memory": false` in `config.json` or
`COGNEE_SHARED_AGENT_MEMORY=false` for separated, per-plugin memory (name-addressed,
agent-owned datasets). Opting out removes the agent from the shared role — it can no
longer read or write your datasets — and starts it on a private dataset; it does not move
data, so what it shared before stays in your user's dataset. Re-enabling puts the agent
back into the same role and dataset. `cognee-doctor` shows the current state under
**Memory Sharing**.

#### How the two settings combine

`COGNEE_PLUGIN_IDENTITY` decides *who the plugin authenticates as, and how strictly*;
`COGNEE_SHARED_AGENT_MEMORY` decides *what an agent identity can see*. Sharing is a
property of agent identities — your own user sees everything regardless — so the second
setting only matters once an identity exists.

| `COGNEE_PLUGIN_IDENTITY` \ `COGNEE_SHARED_AGENT_MEMORY` | `true` (default) | `false` |
|---|---|---|
| `auto` (default) | **Shared memory, graceful.** Provisions an identity when the server allows it, wires the shared role, and falls back to your principal key whenever that cannot be done. | **Principal, unless already provisioned.** A fresh install never provisions (`auto` provisions only in service of sharing). An identity provisioned earlier is kept, leaves the shared role, and writes to its own private dataset. |
| `true` | **Shared memory, strict.** Same wiring; any obstacle (no `create_only` support, a credential bound to another principal, a rejected key) is an error — never a silent fall back to the owner's key. | **Separated identities, strict.** Each plugin is its own agent with its own private memory, blind to your other datasets. This is the isolation mode: a leaked or revoked plugin key affects only that plugin. |
| `false` | **Principal only.** The sharing setting has no effect. | **Principal only.** Identical to the cell above. |

Practical reading: leave both at their defaults for one memory across all of your plugins;
set `COGNEE_PLUGIN_IDENTITY=true` when you want the strict guarantees; add
`COGNEE_SHARED_AGENT_MEMORY=false` to that for fully separated per-plugin memory. Setting
`COGNEE_PLUGIN_IDENTITY=false` makes the sharing setting irrelevant. `cognee-doctor` reports the
resulting state under **API Key Source** and **Memory Sharing**.

## Mode selection rules

At startup (`SessionStart`):
- `COGNEE_BACKEND` (or `COGNEE_CLAUDE_BACKEND`) exported → that mode, pinned — see [Which mode wins](#which-mode-wins-and-how-to-switch)
- otherwise `COGNEE_BASE_URL` set → `managed_endpoint`, either local, or on Cognee Cloud (API key needed in cloud case)
- otherwise → `integration_local` (local API bootstrap)

A forced-local switch also scrubs `COGNEE_BASE_URL`/`COGNEE_API_KEY` from the process environment, so the per-prompt recall/remember calls and every spawned worker resolve the same local endpoint — not just `SessionStart`. A forced-cloud switch with no URL configured never boots the local server; the connection attempt fails visibly instead (status line + doctor).

At hook runtime:
- hooks resolve the endpoint through runtime endpoint auth (env + `api_key.json`), not only config intent
- every hook talks to that endpoint over HTTP; there is no in-process (SDK) fallback

The hooks emit `mode_decision` logs with `mode` (always `http`), `service_url`, `url_source`, `key_source`, `api_key_present`.

## Sessions

Each terminal launch maintains a small map file:

```
~/.cognee-plugin/claude-code/sessions/<host_session_id>.json
  → { "conn_uuid": "...", "session_id": "...", "host_key": "..." }
```

- **`session_id`** — which Cognee session this terminal writes to and recalls from. Fixed at launch.
- **`conn_uuid`** — per-launch liveness handle used for agent registration and server shutdown counting.

By default a new `session_id` is generated each launch. Set `COGNEE_SESSION_ID` to resume a specific session:

```bash
export COGNEE_SESSION_ID="my-project"
```

Two terminals can deliberately share a session by setting the same `COGNEE_SESSION_ID`.

## Dataset

All writes and recall are scoped to a single dataset. By default both the Claude Code and Codex plugins use `agent_sessions`, so memory is shared across both integrations automatically.

Set a custom dataset at launch:

```bash
export COGNEE_PLUGIN_DATASET="my-project-memory"
```

`COGNEE_PLUGIN_DATASET` seeds the dataset at launch. Recall searches only the active dataset (but see
[Searching another dataset without switching](#searching-another-dataset-without-switching)).
Data added outside of Claude to the dataset (via SDK or the server for example) is visible in Claude via the Cognee plugin.

### Switching datasets mid-session

Run `/cognee-memory:cognee-switch-datasets` (optionally with a dataset name) to move the
running session to another dataset. Without a name it lists the datasets you can write to —
those owned by the principal behind your API key; datasets you can only read are counted but
never offered — and asks you to pick one. A name that is not listed is created for you.

A Cognee session never spans two datasets, so the switch:

1. syncs the current session into its dataset (aborts if that fails — nothing changes);
2. registers a **new** Cognee session on the chosen dataset under a fresh connection handle,
   then releases the old handle (register-then-unregister, so a local agent-mode server never
   sees zero connections);
3. repoints this launch's record so every hook, the shell wrappers, the idle/exit watchers and
   the status line follow it.

The choice lives in the launch record (`~/.cognee-plugin/claude-code/sessions/<host id>.json`),
so it survives `--resume` and beats the shell's `COGNEE_PLUGIN_DATASET` (and a pinned
`COGNEE_SESSION_ID`) for the rest of the launch. Retired sessions stay in the record's `touched`
list and the session-end sync covers them again as a safety net. The script behind the skill is
`scripts/switch-dataset.py` (`--list [--json]`, `<name> [--force] [--json]`,
`--session-key <host id>` when several launches share a directory).

### Searching another dataset without switching

Recall only ever reads the active dataset. On every prompt the server answers, the hook also
appends a block to the injected context naming **every other dataset you can read** (with their
UUIDs — nothing ranks them, so you choose; read-only ones included, since a search needs no write
access) and the command to search one of them. Whether the recalled context actually answers you
is a call only the model can make — graph retrieval returns its nearest matches from any populated
dataset, relevant or not — so the block is worded for it to act on only when memory did not answer.
If you are asking Claude to recall something and the active dataset did not have it, it offers those datasets as a picker; pick one and Claude runs a **one-off, graph-only search** on
it and tells you which dataset the answer came from. Nothing else moves: the active dataset,
the Cognee session and where writes go stay as they were — this is for looking something up
elsewhere, not for working there (that is what the switch above is for).

The same flow is available on demand through the `cognee-search` skill when an explicit search comes
back empty. Under the hood:

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/list-datasets.py" --others   # the candidates
"${CLAUDE_PLUGIN_ROOT}/scripts/cognee-search.sh" "<query>" 10 --graph --dataset-id <uuid>
```

Every search reads the knowledge graph (or, with `--code`, a repository's code graph); the
session cache is written, never searched. The session id is bound to the active dataset, so the
wrapper drops it for any other dataset; the active dataset named by hand keeps it. Datasets are
addressed by UUID because a name only resolves among the
datasets your identity owns. The listing behind the hint is cached per plugin
(`~/.cognee-plugin/claude-code/readable-datasets.json`) and refreshed at most every
`COGNEE_DATASETS_CACHE_TTL` seconds (default `300`), inside what is left of the recall budget,
so the prompt path never waits on it.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_RECALL_DATASET_HINT` | `on` | Set `off` to stop the per-prompt hook from naming the other datasets. The explicit skill flow is unaffected. |
| `COGNEE_DATASETS_CACHE_TTL` | `300` | Seconds the cached readable-datasets listing is served before one bounded refresh. |

## Hooks

| Hook | Behavior |
|---|---|
| `SessionStart` | mode select, identity setup, dataset readiness, watcher bootstrap |
| `UserPromptSubmit` | dataset-scoped context lookup + async prompt staging |
| `PreToolUse` (`Read`) | [file-scoped context](#file-context-on-read): code-graph facts about the file about to be read, injected as `additionalContext` |
| `PostToolUse` | async trace write |
| `Stop` | assistant answer write + optional transcript clear hook |
| `PreCompact` | memory anchor build before compaction |
| `SessionEnd` | trigger detached final sync worker |

Claude-specific contracts are preserved:
- `hookSpecificOutput` payload format
- async hook behavior for write hooks

## Memory preference

With the plugin active, Cognee is the **preferred** memory system: relevant memory is
auto-recalled into context on every `UserPromptSubmit` and writes are captured
automatically, so Claude consults Cognee first when answering. To reinforce this, the
`SessionStart` hook injects an `additionalContext` instruction telling Claude to treat
Cognee as authoritative and prefer the Cognee tools/skills over Claude Code's built-in
file memory (`MEMORY.md`).

Note: a plugin **cannot reliably disable** Claude Code's native auto memory
(`MEMORY.md` is injected as context, not a tool call that hooks can intercept). This
feature steers the model toward Cognee rather than hard-disabling native memory. To
turn the steer off, set `COGNEE_PREFER_MEMORY=false`. To additionally suppress native
auto memory yourself, disable it in Claude Code (e.g. `CLAUDE_CODE_DISABLE_AUTO_MEMORY=1`
in the launching shell, if your Claude Code version supports it).

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_PREFER_MEMORY` | `true` | Inject SessionStart steer asserting Cognee as the preferred memory |

## Session sync and watchers

Session→graph sync runs through Cognee's session-aware `improve` endpoint: the server bridges the session from its own session cache (feedback weights, Q&A persist, compact trace-feedback persist, distillation, enrichment) instead of the plugin re-posting the full accumulated session text — which used to trigger a complete re-cognify of the whole transcript on every sync. There is no fallback: a server without session-aware improve (`/api/v1/improve` answering 404/405/422) is logged as `improve_unsupported` and the session is reported as not synced.

An idle watcher runs in the background for the lifetime of each launch. It polls activity every `COGNEE_IDLE_POLL` seconds and fires an improve when the session has been quiet for `COGNEE_IDLE_THRESHOLD` seconds. An automatic improve also fires every `COGNEE_AUTO_IMPROVE_EVERY` stored tool calls/stops (`0` disables it).

Both of those automatic triggers share one **per-session cooldown**: after any successful improve of a session (idle, auto, manual or final), no further idle/auto improve runs for `COGNEE_IMPROVE_COOLDOWN` seconds, and none runs at all until at least one new prompt, tool call or answer has been stored since. The timestamp and turn count are persisted per session under `~/.cognee-plugin/claude-code/improve-state/`, so they survive the watcher process, which exits after each bridge and is respawned on the next prompt. (Until 1.4.4 the cooldown lived only in that process's memory and was reset on every respawn, so in practice an improve ran after every prompt.) The session-end final sync, the `/cognee-memory:cognee-sync` skill and the dataset-switch sync ignore the cooldown and always run.

A **failed** attempt arms the same window as a **backoff**: if the submit timed out, the server was unreachable, or the server answered *busy* (its per-session improve lock is held by another run), no automatic improve of that session runs again until `COGNEE_IMPROVE_COOLDOWN` seconds have passed. A busy answer is never retried by the plugin — the in-flight improve persists everything above the session's server-side watermark, and the next trigger covers whatever landed after it. (Until 1.5.3 only a success armed the cooldown, the plugin held its own per-session lock, and a busy answer was re-submitted every 15 seconds for up to ten minutes, each re-submit counted by the server as one more improve.)

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_IDLE_POLL` | `10` | Poll interval in seconds |
| `COGNEE_IDLE_THRESHOLD` | `60` | Seconds of inactivity before idle improve fires |
| `COGNEE_IMPROVE_COOLDOWN` | `1800` | Minimum seconds between automatic (idle/auto) improves of one session; persisted per session |
| `COGNEE_AUTO_IMPROVE_EVERY` | `150` | Stored tool calls/stops between automatic improves (`0` disables) |
| `COGNEE_IMPROVE_SUBMIT_TIMEOUT` | `420` | Read timeout for the improve POST (agent-context extraction and distillation run inside the request) |

Final sync on session end is triggered by the `SessionEnd` detached worker, with an exit watcher as fallback if the process exits without firing `SessionEnd`.

## Skills

- `/cognee-memory:cognee-remember`
- `/cognee-memory:cognee-search`
- `/cognee-memory:cognee-sync`
- `/cognee-memory:cognee-code`
- `/cognee-memory:cognee-forget`
- `/cognee-memory:cognee-switch-datasets`

## Remember (write) behavior

`cognee-remember` and the auto-capture hooks POST to the server's `/api/v1/remember`
and ask it to build the graph **in the background** (`run_in_background=true`), so the
write returns as soon as it's enqueued instead of blocking the turn on a synchronous
cognify. A synchronous build can take tens of seconds, exceed the client timeout, and be
misread as "server unreachable" — which then triggers a `cognee-cli` fallback that can
double-write. The graph populates shortly after the call, so a recall in the same breath
may not see the new entry yet.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_REMEMBER_BACKGROUND` | `true` | Build the graph in the background; set `false` for a synchronous, immediately-queryable write |

A write that *times out* is reported as "submitted; timed out waiting for confirmation"
and does **not** fall back to `cognee-cli` (the write likely landed — a fallback would
risk a duplicate). Only a genuine connection failure falls back.

## Code graph

Repositories can be indexed into a deterministic **code graph** (symbols, calls,
imports, endpoints, dependencies) via cognee's enola-backed pipeline. Indexing makes
**no LLM or embedding calls** — it is fast and costs no tokens. Requires a cognee
server >= 1.5.3.

Opening the agent inside a git repository indexes it automatically at session start
(background, never blocking the first prompt), and re-indexes it after any turn that
changed the working tree. Index one explicitly — a different repo, a git URL, or one
automation declined — with:

```bash
"${CLAUDE_PLUGIN_ROOT}/scripts/cognee-index-repo.sh" <repo-path-or-git-url> [--dataset <name>] [--index-vectors] [--wait <seconds>]
```

Query it with `cognee-search.sh ... --code` (see the `cognee-code` skill for the
operations: `query_facts`, `explore`, `traverse`, `find_path`, `impact_analysis`,
`delta`). Prompts that mention an identifier-shaped token inside an indexed repo also
get code facts injected automatically by the per-prompt recall hook.

Each indexed repository gets its own dataset, named
`codebase-<repo-name>-<digest>` where the digest identifies the indexed path.
Narrow datasets keep code searches fast, and the digest matters for
correctness: with cognee's default backend every dataset is a separate graph
database, and two checkouts sharing a basename (`~/work/a/service`,
`~/work/b/service`) landing in one database would let each re-index's
stale-node sweep delete the other's nodes. `--code` searches resolve the
dataset from the current checkout, so the generated name rarely needs typing.

Indexing writes enola's snapshot into the indexed repository itself, at
`<repo>/.enola/` (untracked). Add `.enola/` to the repository's `.gitignore` or
your global excludes; the plugin's change detection already ignores it, so the
indexer's own output never triggers a re-index.

### What the graph reflects: working tree vs. pushed commits

**The freshness model differs by where the server runs.** This is a property of the
architecture, not a limitation to work around — but it is worth knowing which one you
are using, because the output looks identical either way.

| Server | Indexed from | Graph reflects | Updated by |
|---|---|---|---|
| **Local** (default) | The repository path on this machine | Your working tree, **including uncommitted and untracked changes** | Every turn that changes a file |
| **Cloud / remote** | A git URL the server clones | The **last pushed commit** on the cloned branch | Pushing, then re-indexing |

A remote server cannot read your disk. It only ever sees code you have pushed, so a
local edit — however recent — is invisible to it until it lands on the remote. The
plugin therefore does not re-submit URL-indexed repositories after local edits: doing
so would re-pull the same commits and change nothing.

The practical consequence on cloud: if you refactor locally and ask about the old
symbol, the graph answers from the pushed state and the answer *looks* authoritative.
**Push before relying on code answers about work in progress**, or use a local server
for branches you are actively editing. `{"operation": "delta"}` reports what the last
index actually changed, which is the quickest way to confirm what the graph currently
knows.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_CODE_AUTOINDEX` | `auto` | `auto`: auto-index new repositories only when the server is local (code never leaves the machine) · `always`: also auto-index against a remote server · `off`: never auto-index new repositories (explicitly indexed ones still refresh) |

Automatic indexing skips directories that are not git repositories, hold no source
files, or exceed 3000 source files. Explicit indexing has no size cap.

### File context on Read

Every `Read` of a source file inside an indexed repository is preceded by a
`PreToolUse` hook (`file-context.py`) that hands the model what the code graph knows
about that file *before* the contents arrive — a map, so it can jump to the right line
instead of scrolling, and see which other files the read one leans on:

```
## Cognee: about base_config.py
Symbols in cognee/base_config.py (name:line):
  classes: BaseConfig:22
  functions: _tracing_explicitly_disabled:15 (private), get_base_config:168
  methods: BaseConfig.validate_personalization_knobs:60, BaseConfig.validate_paths:78, BaseConfig.to_dict:156
Calls out to: cognee/root_dir (ensure_absolute_path, get_absolute_path); cognee/shared/logging_utils (get_logger)
Imports: base64, cognee.modules.observability.observers, cognee.root_dir, ...
(Cognee file context — from the code graph; for callers or impact use `cognee-search.sh "<symbol>" --code`.)
```

It is purely additive (never blocks or alters the read), deterministic (a
`query_facts` lookup filtered to the file — no LLM, no embedding call), and cheap: one
request against the repo's own dataset, typically ~100 ms warm, bounded by a budget.
Each file is served **once per session** (per `COGNEE_FILE_CONTEXT_TTL`) — the model
already has the map after the first read. It stays silent for files outside every
indexed repo, non-code files, sensitive paths (the capture deny list: `.env`, keys,
credentials), a server known to be down, or an open circuit breaker; every skip is
logged as `file_context_skipped` with its reason.

| Variable | Default | Effect |
|---|---|---|
| `COGNEE_FILE_CONTEXT` | `true` | `false` turns the hook off. |
| `COGNEE_FILE_CONTEXT_SCOPES` | `code` | Lanes to run. Add `graph` (`code,graph`) to also inject up to 3 knowledge-graph hits about the file (notes, decisions, prior-session facts) — a HYBRID_COMPLETION search over the session dataset, so it costs a graph round trip on every first read of a file. |
| `COGNEE_FILE_CONTEXT_BUDGET` | `3.0` | Seconds for the whole hook; a lane that cannot finish inside it is dropped. |
| `COGNEE_FILE_CONTEXT_TTL` | `1800` | Seconds before the same file is served again in the same session. |
| `COGNEE_FILE_CONTEXT_MAX_SYMBOLS` | `40` | Cap on listed symbols (the rest is summarised as a count). |

## Forget (delete) behavior

`cognee-forget` deletes memory the user asks to forget ("forget what we talked about
tennis"). The agent syncs the live session first (so unsynced content becomes a
deletable document), reads candidate documents' raw content to decide what matches,
confirms with the user, and deletes each matching document via `POST /api/v1/forget` —
which removes the raw data, its derived graph knowledge, and — best-effort — the session
Q&A turns whose answers cited the deleted graph elements (plus guidance derived from
them; agent trace entries are not matched). All server access goes through
`scripts/cognee-forget.sh`, which resolves the API key like the other wrappers (env →
`~/.cognee/.env` → the auto-minted local `api_key.json`) and always authenticates; it
refuses to run without a key rather than send requests that can only 401. Deletion is
irreversible; dataset-wide or delete-everything scopes require an explicit, unambiguous
user request.

## Claude observer: local mode on your Claude subscription

> **It spends your Claude usage.** With the observer on, every cognify/improve call the
> local server makes is a real `claude -p` run billed to your Claude subscription and
> counted against its usage limits — and building the graph is token-heavy. Session
> start announces it every time it is in use. Set `LLM_API_KEY` to use a provider of
> your own, or `COGNEE_LLM_OBSERVER=false` to turn it off.

Local mode needs an LLM for cognify, improve and graph completion. When no
`LLM_API_KEY` (and no `LLM_PROVIDER`) is configured, session start runs those calls
through **Claude Code itself** instead of asking for a key:

1. `_observer.py` decides, before the cognee install/boot, that this launch has no LLM
   of its own and the `claude` CLI is available. "Of its own" includes the `.env` the
   server itself loads (cognee's `load_dotenv(override=True)` finds the first `.env`
   walking up from the plugin venv: `~/.cognee-plugin/venv`, `~/.cognee-plugin`, `~`,
   …): an `LLM_API_KEY` or `LLM_PROVIDER` there keeps the observer off;
2. it points cognee's `custom` provider at a loopback OpenAI-compatible shim
   (`LLM_PROVIDER=custom`, `LLM_MODEL=openai/claude-observer`,
   `LLM_ENDPOINT=http://127.0.0.1:8017/v1`) and, unless you configured an embedder of
   your own, sets embeddings to a local model (`EMBEDDING_PROVIDER=fastembed`,
   `BAAI/bge-small-en-v1.5`, 384 dims — installed into the plugin venv like any other
   provider extra);
3. it starts the shim, `claude-observer.py`, detached. Every `/v1/chat/completions`
   the server sends becomes one `claude -p --safe-mode --output-format json` run —
   `--json-schema` carries cognee's structured-output schemas, `--safe-mode` keeps
   your OAuth login but disables hooks, plugins and CLAUDE.md in the child so the
   plugin never re-enters itself (every hook also exits at once when
   `COGNEE_OBSERVER_CHILD` is set). The child keeps your Claude Code login
   (`CLAUDE_CONFIG_DIR`, `CLAUDE_CODE_OAUTH_TOKEN`, Bedrock/Vertex settings) but not
   `ANTHROPIC_API_KEY`, so the calls stay on the subscription. The shim retires itself
   a few minutes after the cognee server is gone.

The shim listens on loopback only and requires a bearer token on every route but
`/health`: `~/.cognee-plugin/observer/token` (created once, mode 0600), which cognee
receives as its `LLM_API_KEY`. Requests carrying an `Origin` header are refused, so a
web page cannot drive it.

A running server keeps the LLM config it booted with. The server's pidfile records
whether it was started on the observer, and a session joining it follows that record:
a server booted on the observer keeps the shim running (and keeps using the
subscription) even after you set a key, until it restarts — it stops on its own once
every session using it has closed.

**Embeddings and datasets.** Vectors from different embedding models cannot be
compared, so a dataset is tied to the embedder that built it. Turning the observer on
switches embeddings to fastembed (384 dims), and turning it off (by setting
`LLM_API_KEY`) switches them back to your provider's model. Either way, switch to a
new dataset (`/cognee-memory:cognee-switch-datasets`, or `COGNEE_PLUGIN_DATASET`)
rather than reusing one built with the other embedder. Session start and `doctor.py`
repeat this whenever the observer is in use.

Session start says so in its system message (`⚠ LLM: Claude Code (observer) …`),
`doctor.py` shows it in the `LLM` row, and the status line's key check asks the shim
instead of litellm: a Claude login problem shows as `✕ (claude_not_logged_in)`, not as
an incorrect key. The tokens are billed to your Claude subscription (`haiku` by
default); each completion is logged with model, duration and token count in
`~/.cognee-plugin/observer/observer-events.log`, the shim's own log is
`observer.log` next to it. The server still needs the local runtime, so the
requirements above (uv / Python 3.12 venv) are unchanged.

Setting `LLM_API_KEY` in `~/.cognee/.env` switches back to a provider of your own on
the next launch; cloud mode never uses the observer (the remote server owns its LLM).

| Variable | Default | Effect |
|---|---|---|
| `COGNEE_LLM_OBSERVER` | `auto` | `auto`: observer when no `LLM_API_KEY`/`LLM_PROVIDER` is configured (in the environment, `~/.cognee/.env` or the server's `.env`) and `claude` is found. `true`: always (a missing CLI is reported at session start). `false`: never — local mode then needs a key as before. |
| `COGNEE_OBSERVER_MODEL` | `haiku` | Claude model for the server's LLM calls (`haiku`, `sonnet`, `opus`, or a full model id). A value that cannot be a model name (spaces, a leading `-`, shell characters) is ignored with a warning at session start and in `doctor.py`, and `haiku` is used. |
| `COGNEE_OBSERVER_CLAUDE` | found on PATH | Path to the `claude` executable. |
| `COGNEE_OBSERVER_PORT` | `8017` | Loopback port of the shim. |
| `COGNEE_OBSERVER_CONCURRENCY` | `2` | Parallel `claude -p` runs the shim allows. |
| `COGNEE_OBSERVER_TIMEOUT` | `240` | Seconds per completion before the shim answers 504. |

`python3 "${CLAUDE_PLUGIN_ROOT}/scripts/claude-observer.py" status|probe|stop` inspects
the shim, checks that `claude` can actually answer (one tiny real call), or stops it.

## Status line

The status line displays `cognee: <dataset> · <mode>`, for example:

```
cognee: agent_sessions · local
cognee: my-project · cloud
```

`<dataset>` is the active Cognee dataset. `<mode>` is `local` when no `COGNEE_BASE_URL` is set or when it points to localhost, and `cloud` when it points to a remote host; an exported `COGNEE_BACKEND` / `COGNEE_CLAUDE_BACKEND` switch overrides that, so the bar always shows the mode the terminal actually resolved. The mode is rendered **bold and coloured** — cyan for `local`, magenta for `cloud` — because it is the one field worth a double-take: it tells you which memory you are about to write to. (Red/green/amber are left to the health glyph and the warnings; bold and colour are set together so a terminal that ignores one still shows the other.)

A connection glyph precedes the line:

```
● cognee: agent_sessions · cloud          # connected (server up and authenticated)
✕ (incorrect_cognee_api_key) cognee: … · cloud   # server reachable, but COGNEE_API_KEY was rejected
✕ (unreachable) cognee: … · cloud         # server positively absent (connection refused / DNS)
✕ (server_error) cognee: … · cloud        # server returned a 5xx
✕ (not_responding) cognee: … · cloud      # server up, but N consecutive recalls timed out
✕ (missing_cognee_base_url) cognee: … · cloud   # COGNEE_BACKEND=cloud is exported, but no COGNEE_BASE_URL is configured
```

`●` shows once the server is confirmed up **and** authenticated. On a failure the glyph flips to `✕ (<reason>)` — `incorrect_cognee_api_key` (a missing, wrong, or expired `COGNEE_API_KEY`), `unreachable` (server positively absent: connection refused or DNS failure, including a server that dies mid-session), `server_error` (5xx), or `not_responding` (the server accepts connections but hasn't answered for several consecutive prompts — a single slow response never triggers it, so a busy server is not misreported as unreachable). One reason is special: `missing_cognee_base_url` means the terminal was pinned to cloud with the `COGNEE_BACKEND` switch but no `COGNEE_BASE_URL` is configured anywhere — a misconfiguration the renderer proves directly from the environment, shown immediately rather than after a failed connection attempt. The state is recorded by the hooks that already talk to the server (SessionStart, and the per-prompt recall), so the line stays green until a failure is actually observed, and clears back to `●` on the next success. The glyph is read from local state only — no network on refresh. It is **colour-coded**: a bold green `●` when the connection is confirmed good, and a bold red `✕ (<reason>)` — reason included, so the whole verdict reads as one unit — when it is confirmed bad. The LLM-key failure is red as well — the two are told apart by the reason itself (`incorrect_cognee_api_key` for the key this plugin uses to reach the server, `incorrect_llm_api_key` for the key the local server uses to reach the LLM) rather than by colour.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_READY_PROBE_TIMEOUT` | `1.0` | Seconds the per-prompt readiness probe waits before giving up and skipping recall for that turn. It sits on the keystroke→answer path, so the default is deliberately tight; raise it on a slow or loaded server that is otherwise healthy. |

**Local-mode LLM key.** In local mode the plugin also surfaces problems with `LLM_API_KEY` (the key the local server uses to call the LLM) **in that same leading glyph slot**, with its own reasons:

```
✕ (incorrect_llm_api_key) cognee: agent_sessions · local   # missing, or rejected by the provider
```

The slot holds one sign, by precedence: a server-connection failure wins (if the server can't be reached or authenticated, its LLM key isn't the actionable problem), otherwise an LLM-key failure is shown **in place of** the green `●` — the `llm_*` reason already tells you the server side itself is fine, so you never see a contradictory `●` and `✕` side by side.

Both cases show the same reason — the fix is the same either way, and `llm-state.json` still records which of the two it was. Both verdicts come from a single authority: the background idle watcher (never the prompt path). It resolves the key exactly as the server does — Cognee's own config, so a key in `LLM_API_KEY`, a `.env`, or Cognee's config file all count — and validates it with one tiny `max_tokens=1` call through the same LLM stack Cognee uses. That makes it **provider-agnostic**: a rejection is caught for **any** provider (OpenAI, Anthropic, Gemini, Azure, Bedrock, …), not just OpenAI. Only a `401`/`403` counts as a key failure — providers authenticate before validating anything else, so any other response (including the `400` that reasoning models return when one token is too few to finish a message) proves the key works. A transport failure with no HTTP status is inconclusive and leaves the previous verdict alone. It runs once per idle-watcher launch — at session start, and again on any prompt that finds no live watcher (the watcher exits after each idle-bridge cycle) — never more often than once per `COGNEE_LLM_CHECK_INTERVAL` seconds; there is no periodic timer. The verdict clears once the key checks out, and expires after 30 minutes, so one left behind by a session that has ended never haunts the bar. See **Per-terminal status** below for how two terminals that disagree about the key each show their own truth. Local mode only (in cloud the LLM key lives on the remote server). Disable with `COGNEE_LLM_KEY_CHECK=false`.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_LLM_KEY_CHECK` | `true` | Background, provider-agnostic `LLM_API_KEY` validation (local mode) surfacing `✕ (incorrect_llm_api_key)` |
| `COGNEE_LLM_CHECK_INTERVAL` | `300` | Minimum seconds between LLM-key checks |

**Memory hits.** The line ends with what memory actually did — this turn, then (faint) over the session:

```
● cognee: agent_sessions · local · 5 memory hits · 12/40 turns had hits this session
```

`5 memory hits` is how many memory blocks this turn's lookup found and injected into context (the memory request, plus code-graph facts when that lane is armed). `12/40 turns had hits this session` is the running total — 40 prompts so far, memory fired on 12 of them. A session that has not had a single hit yet shows `memory warming up (7 turns)` instead of a bare `0/7`: the graph is usually still filling up. `UserPromptSubmit` writes these to `~/.cognee-plugin/claude-code/recall/<session>.json`, so the renderer stays network-free, and the counts are stamped with the session that produced them so a second terminal's numbers never show up here. The per-scope breakdown (`recall 4s/5t/0g/1a · saved 2p/41t/2a` — `s`ession turns, `t`races, `g`raph context, `a`gent guidance; saves as `p`rompts, `t`races, `a`nswers) is still available with `COGNEE_STATUSLINE_COUNTS=full`; hide the segment with `false`.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_STATUSLINE_COUNTS` | `true` | `true`: `N memory hits · H/T turns had hits this session`; `full`: per-scope `recall …/saved …` strip; `false`: hidden |

**Per-terminal status.** Every signal in the line answers *for this terminal*, not for the machine. That matters because terminals legitimately disagree: one shell exported `LLM_API_KEY` and another didn't, or two hold different `COGNEE_API_KEY`s against the same server. Both sessions show the truth at the same time:

```
terminal A (key exported)  →  ● cognee: agent_sessions · local
terminal B (no key)        →  ✕ (incorrect_llm_api_key) cognee: agent_sessions · local
```

Each writer keeps two records: the machine-wide marker (`server-ready.json`, `llm-state.json`) which stays **coordination** state — it gates recall and is shared with the Codex plugin, since both talk to one server — and a per-session copy under `conn-state/<session_key>.json`, `llm-state/<session_key>.json`, and `recall/<session_key>.json`, which is the **display** state the bar reads. Without the split, a single file meant the last writer decided what every other bar showed: a keyless launch's `not_set` reddening a healthy session, or a healthy one's `ok` hiding a genuinely missing key.

Resolution, in order: this session's own record wins; **except** that a fresher **server-wide** failure in the shared marker takes precedence — `unreachable` or `server_error`, because the server really is shared and a just-observed outage applies to everyone. `incorrect_cognee_api_key` is deliberately **not** propagated: it describes the credential the other session used, not the server, so a keyless cloud terminal starting up can't red a healthy local one. Nor does a fresher shared `ready` clear your own failure — their working key says nothing about yours. With no record of your own, the shared marker is used only when it is unattributed (an older writer, or a write made before the session key was known); a record belonging to another session is ignored and no glyph is drawn, exactly as during warm-up.

**Internal variables — do not set these.** A few `COGNEE_*` names in the environment
are the plugin's own inter-process plumbing, written by one hook and read back by the
detached workers it spawns: `COGNEE_USER_ID` (the resolved Cognee user for this
launch), `COGNEE_SESSION_KEY` (the host session key every hook of a launch resolves
through), `COGNEE_AGENT_SESSION_NAME`, `COGNEE_PLUGIN_IN_VENV` (the re-exec guard),
and `COGNEE_SYNC_DATASET` / `COGNEE_SYNC_SESSION_ID` (arguments to the final-sync
worker). Setting them yourself does not configure anything — the plugin overwrites
them during startup — and a stale value can misroute identity or session resolution.
Use `COGNEE_SESSION_ID` to pin a session and `COGNEE_PLUGIN_DATASET` to seed the dataset
(a mid-session `/cognee-memory:cognee-switch-datasets` overrides both for that launch).

It is configured automatically on first launch when no custom status line is already configured. SessionStart writes the correct path into `~/.claude/settings.json` and Claude Code hot-reloads it, so the status line appears from your first interaction onward. Existing non-Cognee `statusLine` settings are preserved; set `COGNEE_STATUSLINE=false` before launching Claude Code to opt out entirely.

The entry sets `refreshInterval: 2`, so Claude re-runs the (network-free, local-only) renderer every 2 seconds in addition to its event-driven updates. Without it, Claude only refreshes the status line on events (a new message, `/compact`, etc.), which go quiet while the session is idle — so a connection change detected right after launch (e.g. a rejected API key) wouldn't show until your next prompt. Tune it with `COGNEE_STATUSLINE_REFRESH_INTERVAL` (seconds; a value below `1`, e.g. `0`, disables idle polling and reverts to event-only refresh).

The status line reads only local state — no network calls on every refresh:
1. Dataset: this launch's record (`sessions/<host id>.json`, written at SessionStart and by a dataset switch), otherwise `COGNEE_PLUGIN_DATASET`, otherwise `agent_sessions`
2. Mode: `COGNEE_BACKEND` / `COGNEE_CLAUDE_BACKEND` switch, then `COGNEE_BASE_URL` env var
3. Default mode: `local`
4. Connection glyph: `conn-state/<session>.json`, then `server-ready.json` + `recall-breaker.json`
5. LLM key: `llm-state/<session>.json`, then `llm-state.json`
6. Counts: `recall/<session>.json`, then `last_recall.json`

## Auto-clear demo hook

For demo flows where each response should clear local transcript context:

```bash
export COGNEE_CLAUDE_CLEAR_AFTER_MESSAGE=true
```

This clears the transcript file on `Stop` after memory capture.

## Logs and state

Claude Code-specific plugin state and logs are written under:

```bash
~/.cognee-plugin/claude-code/
```

Useful logs:

```bash
tail -f ~/.cognee-plugin/claude-code/hook.log
tail -f ~/.cognee-plugin/claude-code/subprocess.log
tail -f ~/.cognee-plugin/claude-code/watcher.log
tail -f ~/.cognee-plugin/claude-code/exit-watcher.log
tail -f ~/.cognee-plugin/claude-code/recall-audit.log
```

Every log is capped: when one passes `COGNEE_PLUGIN_LOG_MAX_BYTES` (default 20 MiB) it
is rotated to `<name>.1` and started fresh, so a log is never bigger than twice
the cap and the stretch just before a failure survives in the `.1` file. Set the
variable (in `~/.cognee/.env` or the shell) to change the ceiling; `0` disables
rotation. The local server's own log lives under `~/.cognee/logs/` (rotated by
cognee, ten files kept); `bootstrap.log` holds only the plugin's bootstrap
worker output, and `server-console.log` the first megabyte of the server's
console output for the current boot (previous boot in `server-console.log.1`) —
where a boot that failed before the server could open its own log explains itself.

At every SessionStart the plugin also sweeps its own state directory: per-session
files whose session is over (status markers, bridge caches and pending buffers
untouched for a week; launch records a week after their host process died, or
after 30 days), improve-state files untouched for a week, and files and
directories older versions left behind (such as `improve-locks/`). It
never touches another plugin's subdirectory. One `state_sweep` line in
`hook.log` records what was removed.

Shared state (used by both Claude Code and Codex plugins):

```bash
~/.cognee-plugin/api_key.json     # cached API key
~/.cognee-plugin/venv/            # shared Cognee virtualenv
```

## Usage metrics

For an offline usage rollup compiled purely from the local files above — no
network, no `cognee` import — run:

```bash
"${CLAUDE_PLUGIN_ROOT}/scripts/cognee-plugin" metrics          # readable rollup
"${CLAUDE_PLUGIN_ROOT}/scripts/cognee-plugin" metrics --json   # JSON
```

It reports sessions, recalls and hit-rate, saves (prompt/trace/answer), the
local-vs-cloud mode split, and how often an open recall breaker skipped recall.

## Updating

The plugin is versioned with [semver](https://semver.org/) — see
[`CHANGELOG.md`](./CHANGELOG.md). Claude Code offers an update only when the
plugin's `version` changes (it's pinned in the marketplace entry), so a plain
reinstall of the same version reuses the cached copy.

**Update on demand:**

```
/plugin marketplace update cognee     # refresh the marketplace catalog
/plugin update cognee-memory@cognee   # apply a newer version if one exists
```

`/plugin update` reports "already at the latest version" when your installed
version matches the published one.

**Automatic updates (recommended):** Claude Code can refresh marketplaces and
update installed plugins in the background after startup, then prompt you to run
`/reload-plugins`. Auto-update is **enabled by default only for official
Anthropic marketplaces** — for the third-party `cognee` marketplace you must opt
in via Claude Code's per-marketplace auto-update setting (see the "Configure
auto-updates" section of the Claude Code plugin docs). With it on, new releases
land without any manual `/plugin update`.

**If updates still don't appear**, re-add the marketplace source and reinstall:

```
/plugin uninstall cognee-memory@cognee
/plugin marketplace remove cognee
/plugin marketplace add topoteretes/cognee-integrations
/plugin install cognee-memory@cognee
```

### Update notifications

When a newer version is published, the plugin surfaces it automatically — no
configuration needed to receive them:

- **Status line:** an amber `⬆ Cognee update available <installed>→<latest>`
  segment appears, and disappears once you update.
- **SessionStart:** a one-time message per new version, e.g. *"Cognee update
  available 1.0.0 → 1.1.0 — run `/plugin update cognee-memory@cognee`."*

A background check in the idle watcher runs **at most once per day** and fetches a
single public file — the marketplace manifest on the tracked git ref, via
`raw.githubusercontent.com` — to read the published version. It sends no data and
no telemetry, uses a conditional (ETag) request, fails silently when offline, and
skips local-path (dev) installs. Turn it off with `COGNEE_UPDATE_CHECK=false`.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_UPDATE_CHECK` | `true` | Background "update available" check + status-line/SessionStart nudges |
| `COGNEE_UPDATE_CHECK_INTERVAL` | `3600` | Minimum seconds between checks |

## Remove

```
/plugin uninstall cognee-memory@cognee
```

## Troubleshooting

**Terminal connects to cloud when you wanted local (or the reverse)**
- The mode is routed by `COGNEE_BASE_URL`: configured anywhere (env file or shell) → cloud; otherwise → local. An exported `COGNEE_BACKEND=local` / `=cloud` overrides that for the terminal — see [Which mode wins](#which-mode-wins-and-how-to-switch).
- `unset COGNEE_BASE_URL` does **not** go local: the env file re-injects the URL at the next launch. Export `COGNEE_BACKEND=local` instead.
- Check what the terminal actually resolved: the status line's mode field shows it live, and `doctor.py` prints the decision with its cause (`Mode: Local — forced by COGNEE_BACKEND=local`).
- If a mode seems stuck, check for a forgotten `COGNEE_BACKEND` / `COGNEE_CLAUDE_BACKEND` export in the shell or in `~/.cognee/.env` — the plugin-specific name silently beats the shared one.

**Recall returns empty but data was ingested**
- Recall is scoped to the active dataset (the one in the status line — `COGNEE_PLUGIN_DATASET` / `agent_sessions` at launch, or whatever you switched to).
- Data written via the Python SDK or `client.py` goes to `default_dataset` by default, if dataset not otherwise specified.
- To verify, call the recall API directly without a dataset filter: `curl -X POST "$COGNEE_BASE_URL/api/v1/recall" -d '{"query":"..."}'`

**Session not resolving / wrong session shown**
- Check `~/.cognee-plugin/claude-code/sessions/<host_session_id>.json` — this is the map file for your terminal.
- If it's missing, SessionStart may not have completed; check `~/.cognee-plugin/claude-code/hook.log`.

**Unauthorized / key errors**
- Check `~/.cognee-plugin/api_key.json`. Delete it to force a re-mint.
- Relevant logs: `api_key_cached`, `api_key_minted`, `agent_register_result`.

**Missing session key at startup**
- If the payload session key is missing, SessionStart refuses registration.
- Relevant logs: `session_key_resolved`, `missing_payload_session_id`.

**Final sync diagnostics**
- Check `~/.cognee-plugin/claude-code/hook.log` and `~/.cognee-plugin/claude-code/exit-watcher.log`.
- Relevant logs: `sync_deferred_to_shutdown_worker`, `final_sync_once_*`, `agent_unregister_result`.

## Configuration reference

Config precedence:
1. env vars (shell exports)
2. `~/.cognee/.env` (one-time setup file, shared with the Codex plugin; loaded into the environment at process start, so every env var below can live here)
3. defaults

There is no `config.json`. Older versions wrote `~/.cognee-plugin/claude-code/config.json` and SessionStart read a `base_url` from it while the per-turn hooks did not, so a stale URL there could point the two halves of the plugin at different servers. SessionStart now deletes a leftover file; put everything in `~/.cognee/.env` instead.

One exception sits above all three layers: the `COGNEE_BACKEND` / `COGNEE_CLAUDE_BACKEND` mode switch. When exported, it pins the mode regardless of where the connection variables are defined — forced local ignores a configured `COGNEE_BASE_URL` entirely (it is scrubbed from the process environment), and forced cloud stays cloud even when the URL is missing. See [Which mode wins](#which-mode-wins-and-how-to-switch).

`~/.cognee/.env` is created with a commented template on first session start (permissions `0600`; the path can be overridden with `COGNEE_ENV_FILE`). Run `doctor.py` to see which keys the file defines, which are overridden by shell exports, and — in the mode row — whether a backend switch forced the mode decision.

### Managing the env file

`~/.cognee/.env` is a plain dotenv text file. Every env var in the table below can live in it, and you can manage it entirely from the command line — or open it in any editor.

**Add or change a variable without an editor** — append it. When a key appears more than once, the **last value wins**, so appending the same key again with a new value is also how you *change* it:

```bash
echo 'COGNEE_PLUGIN_DATASET="my-project-memory"' >> ~/.cognee/.env
```

```powershell
Add-Content "$env:USERPROFILE\.cognee\.env" 'COGNEE_PLUGIN_DATASET="my-project-memory"'
```

For secrets (`COGNEE_API_KEY`, `LLM_API_KEY`), prefer the editor route below — an `echo` puts the key into your shell history.

**Edit the file manually** — open it in any editor:

```bash
nano ~/.cognee/.env          # or vim, code, open -e (macOS)
```

```powershell
notepad "$env:USERPROFILE\.cognee\.env"
```

Since the file starts as a commented template, editing usually means uncommenting a line and filling in your value. The format:

```bash
# Comments start with '#'; blank lines are ignored.
COGNEE_BASE_URL="https://your-instance.cognee.ai"
COGNEE_API_KEY=ck_abc123                # quotes are optional
export LLM_API_KEY="sk-..."             # a leading 'export ' is tolerated, so
                                        # shell profile lines paste verbatim
```

Keys are letters, digits, and underscores. Values are taken literally — no `$VAR` interpolation, no multi-line values. Malformed lines are skipped silently, never fatal, and process-critical variables (`PATH` and friends) are ignored by design.

**Remove a variable** — delete (or comment out) its line in the editor. To switch modes you usually don't need to remove anything: keep both modes' variables in the file and export the switch instead — `export COGNEE_BACKEND=local` (see [Which mode wins](#which-mode-wins-and-how-to-switch)). Remove the `COGNEE_BASE_URL` line only when you want local to become the permanent default for every terminal.

**Apply and verify** — the file is read at session start, so changes take effect on the next `claude` launch. If a value seems to be ignored, check whether the same variable is `export`ed in your shell: real exports always win over the file. The doctor's **Env File** row lists which keys the file defines and flags any that a shell export is overriding.

| Key | Env var(s) | Default | Notes |
|---|---|---|---|
| `dataset` | `COGNEE_PLUGIN_DATASET` | `agent_sessions` | Dataset for writes and recall at launch; `/cognee-memory:cognee-switch-datasets` changes it mid-session (config value is informational-only) |
| `session_id` | `COGNEE_SESSION_ID` | auto-generated per launch | Override to resume a named session |
| `session_strategy` | `COGNEE_SESSION_STRATEGY` | `per-directory` | `per-directory`, `git-branch`, `static` |
| `session_prefix` | `COGNEE_SESSION_PREFIX` | `cc` | Prefix for auto-generated session IDs |
| `base_url` | `COGNEE_BASE_URL` | unset | Set to enable managed endpoint mode |
| `api_key` | `COGNEE_API_KEY` | unset | API key; auto-minted if absent in local mode |
| mode switch | `COGNEE_BACKEND` | unset | `local` or `cloud` — pins the terminal's mode, overriding the URL rule; flips the Claude Code **and** Codex plugins |
| plugin-only mode switch | `COGNEE_CLAUDE_BACKEND` | unset | Same, for this plugin only; beats `COGNEE_BACKEND` |
| local URL override | `COGNEE_LOCAL_API_URL` | `http://localhost:8011` | Local API base URL |
| local LLM | `LLM_API_KEY`, `LLM_MODEL` | unset | Required for local mode runtime |
| demo auto-clear | `COGNEE_CLAUDE_CLEAR_AFTER_MESSAGE` | disabled | Clear transcript on Stop after capture |
| idle watcher poll | `COGNEE_IDLE_POLL` | `10` | Idle watcher poll interval in seconds |
| idle watcher threshold | `COGNEE_IDLE_THRESHOLD` | `60` | Seconds of inactivity before idle improve fires |
| improve cooldown | `COGNEE_IMPROVE_COOLDOWN` | `1800` | Minimum seconds between automatic (idle/auto) improves of one session |
| auto-improve threshold | `COGNEE_AUTO_IMPROVE_EVERY` | `150` | Stored tool calls/stops between automatic improves (`0` disables) |
| improve submit timeout | `COGNEE_IMPROVE_SUBMIT_TIMEOUT` | `420` | Read timeout for the improve POST |

### Automatic capture controls

Set these in `~/.cognee/.env` or the host environment. Shell environment values
win over the shared file. Changes apply when a new hook process starts.

| Variable | Default | Effect |
|---|---|---|
| `COGNEE_CAPTURE` | `true` | Set `false` to disable automatic prompt, answer and tool capture, including buffered replay. Recall and explicit remember remain available. |
| `COGNEE_CAPTURE_TOOLS` | all registered tools | Pipe-separated tool names or globs, e.g. `Grep|Glob`; excludes other tools from capture. |
| `COGNEE_CAPTURE_DENY_PATHS` | sensitive file patterns | Comma-separated patterns or a JSON array extending the built-in `.env`, credential and private-key exclusions. |
| `COGNEE_CAPTURE_REDACT` | `true` | Redacts common credentials, authorization values, database URLs and private-key blocks before truncation, persistence or upload. |
| `COGNEE_CAPTURE_REDACT_PATTERNS` | empty | JSON array of additional regular expressions. Invalid expressions prevent the affected content from being captured. |

Redaction is best effort. The master switch is the strict control for repositories
where automatic content capture is inappropriate. Disabling capture does not erase
existing memory or retained buffers; use the forget workflow to remove stored data.
Sensitive-path exclusions inspect structured tool path arguments, not arbitrary
shell command syntax.

### HTTP backend compatibility

The memory data plane uses `/health` for reachability. A 404 from optional agent
registration/unregistration is logged as an unsupported lifecycle API and does not
prevent session startup. Authentication errors (401/403), transport failures and
server errors remain failures. Prompt recall has an elapsed-time deadline in
addition to socket timeouts; late read results are discarded.


### Project tags and companion sessions

`COGNEE_PROJECT_NODE_SET=auto` tags captured QA and traces with a readable project
name plus a hash of the canonical path; a fixed value provides an explicit tag.
The setting is pinned for the session, including buffered writes and detached
improve workers. The backend must expose `node_set` on typed QA/trace entries and
preserve it through improve. Older backends leave capture queued with an explicit
`project_memory_prepared` error instead of silently losing the tags.

`COGNEE_SESSION_COMPANION_DATASET=true` asks the backend to provision
`<primary>-agent_sessions`. Writes and improve use the companion only after the
server attests its permission snapshot. Graph recall reads both datasets in
separate requests so primary graph reads do not conflict with the session binding.
Unsupported routes, insufficient rights, collisions and permission mismatches
fall back to the primary. The client never reads local SQL tables for remote ACLs.

These options require the server project-tags/session-companion extension. The
companion endpoint currently requires the primary owner and copies an ACL snapshot;
later sharing changes must be reconciled explicitly. Connection credentials are
hashed in the local decision record, and a changed principal cannot reuse it.
Defaults remain off. Start a new host session when changing project routing policy.
