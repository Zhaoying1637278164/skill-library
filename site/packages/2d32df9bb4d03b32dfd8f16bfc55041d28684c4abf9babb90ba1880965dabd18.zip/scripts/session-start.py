#!/usr/bin/env python3
"""Initialize Cognee memory at session start.

Runs on the SessionStart hook. Responsibilities:
  1. Load config (file + env vars)
  2. Compute per-directory session ID
  3. Connect to Cognee Cloud if configured
  4. Configure local LLM if local mode
  5. Register the current Claude session as an active agent connection
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from contextlib import contextmanager
from pathlib import Path

# Add scripts dir to path for config import
sys.path.insert(0, os.path.dirname(__file__))
from _logfiles import console_capture_tail as _console_capture_tail
from _logfiles import rotate_if_oversized as _rotate_log_if_oversized
from _logfiles import start_console_capture as _start_console_capture
from _plugin_common import (
    _COGNEE_CACHE_DIR,
    _COGNEE_DATA_DIR,
    _COGNEE_HOME,
    _COGNEE_SYSTEM_DIR,
    _VENV_DIR,
    _VENV_PYTHON,
    _VENV_READY_MARKER,
    PRESENCE_ABSENT,
    PRESENCE_READY,
    _https_context,
    _reexec_into_venv,
    apply_cognee_env,
    clear_server_pidfile,
    ensure_launch_record,
    get_session_key,
    hook_log,
    is_observer_child,
    probe_health,
    quiet_hook_output,
    resolve_session_key_from_payload,
    server_presence,
    server_ready_hint,
    service_url_is_local,
    set_session_key,
    touch_activity,
    write_connection_state,
    write_server_pidfile,
)
from _proc import find_host_ancestor_windows
from _proc import pid_alive as _pid_alive
from config import (
    _cloud_http_request,
    _user_id_via_api,
    ensure_cognee_ready,
    ensure_dataset_ready_via_api,
    get_dataset,
    is_cloud_mode,
    load_config,
)

_STATE_DIR = Path.home() / ".cognee-plugin" / "claude-code"
_GLOBAL_STATE_DIR = Path.home() / ".cognee-plugin"
_WATCHER_PID = _STATE_DIR / "watcher.pid"
_WATCHER_STOP = _STATE_DIR / "watcher.stop"
_WATCHER_SCRIPT = Path(__file__).with_name("idle-watcher.py")
_EXIT_WATCHER_SCRIPT = Path(__file__).with_name("exit-watcher.py")
_EXIT_WATCHERS_DIR = _STATE_DIR / "exit-watchers"
_LOCAL_SERVICE_URL = "http://localhost:8011"
_HEALTH_URL = f"{_LOCAL_SERVICE_URL}/health"
_HEALTH_TIMEOUT_SECONDS = 30
_HEALTH_POLL_SECONDS = 1.0
_SERVER_BOOT_LOCK = _GLOBAL_STATE_DIR / "server-bootstrap.lock"
_SERVER_BOOT_LOCK_STALE_SECONDS = 2 * _HEALTH_TIMEOUT_SECONDS
_SERVER_BOOT_LOCK_WAIT_SECONDS = _HEALTH_TIMEOUT_SECONDS + 5.0
_SERVER_BOOT_LOCK_POLL_SECONDS = 0.2

# Lazy bootstrap: defer server boot + registration to a detached worker so the
# SessionStart hook returns fast and migrations never time out the 15s budget.
_BOOTSTRAP_ARG = "--bootstrap"
_BOOTSTRAP_LOCK = _GLOBAL_STATE_DIR / "server-bootstrap-worker.lock"
_SERVER_BOOT_DEADLINE_SECONDS = float(os.environ.get("COGNEE_SERVER_BOOT_DEADLINE", "") or 600.0)
_BOOTSTRAP_LOCK_STALE_SECONDS = _SERVER_BOOT_DEADLINE_SECONDS + 60.0
_LAZY_BOOTSTRAP = os.environ.get("COGNEE_LAZY_BOOTSTRAP", "1").strip().lower() not in (
    "0",
    "false",
    "no",
)

# --- Self-managed cognee install ---------------------------------------------
# uv is kept self-contained under ~/.cognee-plugin so we never touch the user's
# Python or PATH. A uv-managed Python guarantees a cognee-compatible runtime
# (cognee requires 3.10-3.14) regardless of what's installed on the machine.
# The hooks themselves need only a stdlib python3 of 3.9+ (see SDK-617): the
# host interpreter never imports cognee, it only builds and talks to the venv.
_UV_DIR = _GLOBAL_STATE_DIR / "uv"
_UV_BIN = _UV_DIR / ("uv.exe" if os.name == "nt" else "uv")
_UV_PYTHON_DIR = _GLOBAL_STATE_DIR / "python"
_UV_INSTALL_URL = "https://astral.sh/uv/install.sh"
_PINNED_PYTHON = os.environ.get("COGNEE_PLUGIN_PYTHON", "") or "3.12"
# Floor for the HOST interpreter, enforced only on the uv-less fallback, which
# builds the runtime venv from sys.executable and so inherits its version.
_FALLBACK_VENV_MIN_PYTHON = (3, 10)
# Written when that fallback is refused; read by the next SessionStart so the
# refusal reaches the user as a systemMessage (the worker that hits it runs
# detached, with nothing it prints visible). Cleared once a venv is ready.
_HOST_PYTHON_MARKER = _GLOBAL_STATE_DIR / "host-python-unsupported.json"
_PINNED_COGNEE_VERSION = "1.6.0"
_INSTALL_TIMEOUT_SECONDS = float(os.environ.get("COGNEE_INSTALL_TIMEOUT", "") or 600.0)

# Maps a configured backend provider env var to the cognee package "extra" that
# provides its driver. A bare `cognee==<version>` install has none of these, so
# the server crashes on first use of any non-default backend (#232): Postgres
# needs psycopg2/asyncpg (via `postgres-binary`), Neo4j needs its driver, a
# local Ollama LLM needs the `ollama` extra, and `fastembed` embeddings need
# their own extra. The env var names are the ones cognee's own config classes
# read (verified against 1.5.3's infrastructure/*/config.py field names, which
# pydantic-settings matches case-insensitively; GRAPH_DATABASE_PROVIDER is even
# explicit there). Values already sit in os.environ by the time the install
# runs: ensure_cognee_installed() calls apply_cognee_env() first, and the
# ~/.cognee/.env file is injected at process start (_env_file.py), so both
# exported and file-configured providers are seen. `postgres`/`pgvector` share
# one driver set, so VECTOR_DB_PROVIDER=pgvector maps to the same extra as
# DB_PROVIDER=postgres rather than a separate one.
_PROVIDER_EXTRAS = (
    ("DB_PROVIDER", {"postgres": "postgres-binary", "postgresql": "postgres-binary"}),
    ("VECTOR_DB_PROVIDER", {"pgvector": "postgres-binary"}),
    ("GRAPH_DATABASE_PROVIDER", {"neo4j": "neo4j"}),
    ("EMBEDDING_PROVIDER", {"fastembed": "fastembed"}),
    ("LLM_PROVIDER", {"ollama": "ollama"}),
)


def _detect_required_extras() -> list:
    """Detect the cognee extras actually needed from the configured backend
    providers, so the install below brings in exactly what's needed instead of
    either a bare install (missing drivers, #232) or unconditionally installing
    every possible extra regardless of what's actually configured."""
    extras: list[str] = []
    for env_var, mapping in _PROVIDER_EXTRAS:
        value = os.environ.get(env_var, "").strip().lower()
        extra = mapping.get(value)
        if extra and extra not in extras:
            extras.append(extra)
    return extras


def _cognee_install_spec() -> str:
    """The pip requirement to install: the pinned cognee, plus the extras the
    configured providers need."""
    extras = ",".join(_detect_required_extras())
    return (
        f"cognee[{extras}]=={_PINNED_COGNEE_VERSION}"
        if extras
        else f"cognee=={_PINNED_COGNEE_VERSION}"
    )


# Install single-flight. Distinct from the server boot lock (which is short, on
# the assumption a boot completes in ~a minute): a cold cognee install can take
# minutes, so concurrent sessions must NOT install into the same venv at once.
_VENV_INSTALL_LOCK = _GLOBAL_STATE_DIR / "venv-install.lock"
_VENV_INSTALL_LOCK_STALE_SECONDS = _INSTALL_TIMEOUT_SECONDS + 60.0
_VENV_INSTALL_WAIT_SECONDS = _INSTALL_TIMEOUT_SECONDS + 60.0
_VENV_INSTALL_POLL_SECONDS = 0.5


def _find_uv() -> str:
    """Locate uv: prefer our self-managed copy, then anything on PATH."""
    if _UV_BIN.exists():
        return str(_UV_BIN)
    found = shutil.which("uv")
    return found or ""


def _host_python_label() -> str:
    """``<sys.executable> (Python X.Y.Z)`` — names the interpreter a user must replace."""
    return "{} (Python {}.{}.{})".format(sys.executable, *sys.version_info[:3])


def _refuse_fallback_venv() -> None:
    """Record why the uv-less fallback will not build the runtime venv.

    Three readers: hook.log (forensics), this process's stderr (the bootstrap
    log when detached, the terminal when not), and the marker the next
    SessionStart turns into a systemMessage via ``_apply_host_python_warning``.
    """
    message = (
        "Cognee Memory: cannot build the local Cognee runtime. uv is unavailable, and the "
        "fallback would build the venv from {}, but that needs Python 3.10 or newer. Install "
        "uv (https://docs.astral.sh/uv/) or a Python 3.10+ python3, then start a new "
        "session.".format(_host_python_label())
    )
    detail = {
        "python": sys.executable,
        "version": "{}.{}.{}".format(*sys.version_info[:3]),
        "required": "{}.{}".format(*_FALLBACK_VENV_MIN_PYTHON),
    }
    hook_log("host_python_too_old_for_venv", detail)
    print(message, file=sys.stderr)
    try:
        _HOST_PYTHON_MARKER.parent.mkdir(parents=True, exist_ok=True)
        _HOST_PYTHON_MARKER.write_text(
            json.dumps({"message": message, "updated_at": time.time(), **detail}),
            encoding="utf-8",
        )
    except Exception as exc:
        hook_log("host_python_marker_write_failed", {"error": str(exc)[:200]})


def _apply_host_python_warning(output: dict) -> dict:
    """Append the recorded fallback refusal (if any) to the hook's systemMessage.

    The marker outlives the session that wrote it on purpose: every launch on
    the broken host repeats the message until a venv is built (which clears it
    in ``_write_venv_ready``) — this is the loud failure SDK-617 asks for.
    """
    try:
        if not _HOST_PYTHON_MARKER.exists():
            return output
        message = str(
            json.loads(_HOST_PYTHON_MARKER.read_text(encoding="utf-8")).get("message") or ""
        )
    except Exception as exc:
        hook_log("host_python_marker_read_failed", {"error": str(exc)[:200]})
        return output
    if not message:
        return output
    result = dict(output or {})
    hso = dict(result.get("hookSpecificOutput") or {})
    hso.setdefault("hookEventName", "SessionStart")
    existing = str(hso.get("systemMessage") or "").strip()
    hso["systemMessage"] = "{}\n\n{}".format(existing, message) if existing else message
    result["hookSpecificOutput"] = hso
    # Also at the top level: that is where Claude Code documents the universal
    # ``systemMessage`` field, and where the Antigravity adapter reads it.
    top = str(result.get("systemMessage") or "").strip()
    result["systemMessage"] = "{}\n\n{}".format(top, message) if top else message
    return result


def _install_uv() -> str:
    """Install the standalone uv binary into ~/.cognee-plugin/uv (no PATH edits)."""
    try:
        _UV_DIR.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        # UV_UNMANAGED_INSTALL drops the binary in the given dir without editing
        # shell profiles or managing updates — exactly what we want.
        env["UV_UNMANAGED_INSTALL"] = str(_UV_DIR)
        subprocess.run(
            ["sh", "-c", f"curl -LsSf {_UV_INSTALL_URL} | sh"],
            env=env,
            check=True,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if _UV_BIN.exists():
            return str(_UV_BIN)
    except Exception as exc:
        hook_log("uv_install_failed", {"error": str(exc)[:300]})
    return ""


def _venv_cognee_version() -> str:
    """Installed cognee version inside the plugin venv, or '' if unimportable."""
    if not _VENV_PYTHON.exists():
        return ""
    try:
        out = subprocess.run(
            [
                str(_VENV_PYTHON),
                "-c",
                "import importlib.metadata as m; print(m.version('cognee'))",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if out.returncode == 0:
            return out.stdout.strip()
    except Exception as exc:
        hook_log("cognee_version_probe_failed", {"error": str(exc)[:200]})
    return ""


# One distribution per extra whose presence in the venv proves that extra's
# drivers are installed (verified against cognee 1.6.0's optional-dependencies:
# fastembed and codegraph are empty extras there, their packages being core).
# Probing the venv is deliberately preferred over recording installed extras in
# venv-ready.json: that marker is shared with plugins that don't know about
# extras (codex/openclaw), whose rewrites would wipe the record and force a
# reinstall on every cold boot after theirs — the exact churn skip-at-pin
# exists to avoid. `asyncpg` is common to the `postgres` and `postgres-binary`
# extras, so either variant satisfies the postgres-binary requirement.
_EXTRA_SENTINEL_DISTS = {
    "postgres-binary": "asyncpg",
    "neo4j": "neo4j",
    "fastembed": "fastembed",
    "ollama": "transformers",
}


def _venv_missing_extras(extras: list) -> list:
    """Which of the required extras' driver packages are absent from the venv.

    Ground truth for the skip-at-pin gate: the venv being at the pinned cognee
    version says nothing about extras — a provider configured AFTER the venv
    was built (or a bare install done by an extras-unaware plugin sharing this
    venv) leaves the pin satisfied but the drivers missing, and #232 comes
    right back. Fails soft (reports nothing missing, logged) on probe errors:
    a venv broken enough to fail this probe also fails the version probe, and
    the install path handles that.
    """
    if not extras:
        return []
    if not _VENV_PYTHON.exists():
        return list(extras)
    dists = [_EXTRA_SENTINEL_DISTS[extra] for extra in extras]
    try:
        out = subprocess.run(
            [
                str(_VENV_PYTHON),
                "-c",
                "import importlib.metadata as m, sys\n"
                "for d in sys.argv[1:]:\n"
                "    try:\n"
                "        m.version(d)\n"
                "    except Exception:\n"
                "        print(d)",
                *dists,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if out.returncode != 0:
            hook_log("extras_probe_failed", {"stderr": out.stderr[:200]})
            return []
        missing_dists = set(out.stdout.split())
        return [extra for extra, dist in zip(extras, dists) if dist in missing_dists]
    except Exception as exc:
        hook_log("extras_probe_failed", {"error": str(exc)[:200]})
        return []


def _write_venv_ready(version: str) -> None:
    try:
        payload = {
            "cognee_version": version,
            "python": str(_VENV_PYTHON),
            "updated_at": time.time(),
        }
        tmp = _VENV_READY_MARKER.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload), encoding="utf-8")
        os.replace(tmp, _VENV_READY_MARKER)
    except Exception as exc:
        hook_log("venv_ready_write_failed", {"error": str(exc)[:200]})
    try:
        # A usable venv exists, so the host-python refusal (if any) is moot.
        _HOST_PYTHON_MARKER.unlink(missing_ok=True)
    except Exception as exc:
        hook_log("host_python_marker_unlink_failed", {"error": str(exc)[:200]})


def ensure_cognee_installed(timeout: float = _INSTALL_TIMEOUT_SECONDS) -> bool:
    """Ensure the plugin venv exists and holds the pinned cognee version.

    Called from the server-boot critical section (so it is already
    single-flighted) and only at boot points where the server is POSITIVELY
    absent (see server_presence) — a merely unresponsive server may be busy and
    still holding the graph store's file lock, and upgrading the venv under it
    corrupts the databases. Always installs the exact pinned version
    (_PINNED_COGNEE_VERSION) so the server's FastAPI lifespan migrations run on
    a known-good release, plus the extras the configured backend providers
    need (_cognee_install_spec, #232).

    Fails soft: if the install can't run (e.g. offline) but a usable cognee is
    already present, returns True with whatever version is there. Returns False
    only when no importable cognee venv exists afterwards.
    """
    apply_cognee_env()
    for directory in (_COGNEE_SYSTEM_DIR, _COGNEE_DATA_DIR, _COGNEE_CACHE_DIR):
        try:
            directory.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            hook_log(
                "cognee_data_dir_mkdir_failed", {"dir": str(directory), "error": str(exc)[:200]}
            )

    owner = f"install:{os.getpid()}"
    acquired = False
    deadline = time.monotonic() + _VENV_INSTALL_WAIT_SECONDS
    try:
        _VENV_INSTALL_LOCK.parent.mkdir(parents=True, exist_ok=True)
        while True:
            now = time.time()
            if _VENV_INSTALL_LOCK.exists():
                stale = False
                try:
                    raw = json.loads(_VENV_INSTALL_LOCK.read_text(encoding="utf-8"))
                    pid = int(raw.get("pid", 0) or 0)
                    created_at = float(raw.get("created_at", 0) or 0)
                    stale = (not _pid_alive(pid)) or (
                        now - created_at > _VENV_INSTALL_LOCK_STALE_SECONDS
                    )
                except Exception:
                    stale = True
                if stale:
                    try:
                        _VENV_INSTALL_LOCK.unlink()
                    except Exception as exc:
                        hook_log("venv_install_lock_unlink_failed", {"error": str(exc)[:200]})

            try:
                fd = os.open(str(_VENV_INSTALL_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump({"owner": owner, "pid": os.getpid(), "created_at": now}, fh)
                acquired = True
                break
            except FileExistsError:
                # Another process owns the install. Don't install concurrently —
                # wait for it to produce a usable venv, then reuse it. The venv
                # must satisfy our extras too: the other installer may be an
                # extras-unaware plugin doing a bare install, in which case we
                # keep waiting for the lock and add the drivers ourselves.
                if _venv_cognee_version() == _PINNED_COGNEE_VERSION and not _venv_missing_extras(
                    _detect_required_extras()
                ):
                    return True
                if time.monotonic() >= deadline:
                    return bool(_venv_cognee_version())
                time.sleep(_VENV_INSTALL_POLL_SECONDS)

        # Already at the pin AND holding the configured providers' drivers:
        # there is nothing to install, so do not touch the venv. The install
        # used to run unconditionally at every cold boot; on a machine where
        # two plugins with different pins share this venv that made each boot
        # flip the version back and forth — and a `pip install` is a mutation
        # window the shared runtime is better off without. The version alone
        # is not enough, though: a provider configured after the venv was
        # built leaves the pin satisfied with its drivers missing (#232), so
        # extras are probed too and a miss falls through to the install.
        # The marker is (re)written so every plugin reading it sees the truth.
        current = _venv_cognee_version()
        required_extras = _detect_required_extras()
        missing_extras = _venv_missing_extras(required_extras)
        if current == _PINNED_COGNEE_VERSION:
            if not missing_extras:
                _write_venv_ready(current)
                hook_log(
                    "cognee_install_skipped_at_pin",
                    {"version": current, "extras": required_extras},
                )
                return True
            hook_log("cognee_extras_missing_at_pin", {"missing": missing_extras})

        uv = _find_uv() or _install_uv()
        venv_present = _VENV_PYTHON.exists()

        if uv:
            env = os.environ.copy()
            env.setdefault("UV_PYTHON_INSTALL_DIR", str(_UV_PYTHON_DIR))
            try:
                if not venv_present:
                    subprocess.run(
                        [uv, "venv", str(_VENV_DIR), "--python", _PINNED_PYTHON],
                        env=env,
                        cwd=str(_GLOBAL_STATE_DIR),
                        check=True,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                    )
                subprocess.run(
                    [
                        uv,
                        "pip",
                        "install",
                        "--upgrade",
                        "--python",
                        str(_VENV_PYTHON),
                        _cognee_install_spec(),
                    ],
                    env=env,
                    cwd=str(_GLOBAL_STATE_DIR),
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )
            except Exception as exc:
                hook_log("cognee_install_failed", {"via": "uv", "error": str(exc)[:300]})
        elif not venv_present:
            # Last-resort fallback: stdlib venv + pip. Slower, and the venv inherits
            # this interpreter, so the host python3 must itself satisfy cognee's
            # floor (3.10-3.14). The hooks run on any 3.9+, so check explicitly
            # rather than build a venv cognee could never install into.
            if sys.version_info < _FALLBACK_VENV_MIN_PYTHON:
                _refuse_fallback_venv()
                return False
            try:
                subprocess.run(
                    [sys.executable, "-m", "venv", str(_VENV_DIR)],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )
                subprocess.run(
                    [
                        str(_VENV_PYTHON),
                        "-m",
                        "pip",
                        "install",
                        "--upgrade",
                        _cognee_install_spec(),
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )
            except Exception as exc:
                hook_log("cognee_install_failed", {"via": "venv_pip", "error": str(exc)[:300]})

        version = _venv_cognee_version()
        if not version:
            hook_log("cognee_venv_unusable", {"venv_python": str(_VENV_PYTHON)})
            return False
        _write_venv_ready(version)
        hook_log("cognee_install_ready", {"version": version, "extras": required_extras})
        return True
    finally:
        if acquired:
            try:
                _VENV_INSTALL_LOCK.unlink()
            except Exception as exc:
                hook_log("venv_install_lock_release_failed", {"error": str(exc)[:200]})


def _parse_host_port(url: str) -> tuple[str, int]:
    parsed = urllib.parse.urlparse(url if "://" in url else f"http://{url}")
    return (parsed.hostname or "localhost"), (parsed.port or 8011)


def _is_local_url(url: str) -> bool:
    """True if the URL points at this machine (so we may boot a server on it)."""
    host, _ = _parse_host_port(url)
    return host in ("localhost", "127.0.0.1", "0.0.0.0", "::1")


def _with_scheme(url: str) -> str:
    """Ensure the URL has a scheme so urllib + downstream HTTP helpers accept it."""
    url = str(url or "").strip()
    if url and "://" not in url:
        url = f"http://{url}"
    return url.rstrip("/")


def _health_url(service_url: str) -> str:
    return f"{_with_scheme(service_url or _LOCAL_SERVICE_URL)}/health"


def _health_ok(url: str = _HEALTH_URL, timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout, context=_https_context()) as response:
            return response.status == 200
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def _wait_for_health(deadline_seconds: float, health_url: str = _HEALTH_URL) -> bool:
    """Poll /health until the server is serving or the deadline elapses.

    Used by bootstrap workers that did not win the boot single-flight: they
    don't spawn uvicorn, they just wait for whichever worker did to finish
    booting (including migrations) before registering.
    """
    deadline = time.monotonic() + deadline_seconds
    while True:
        if _health_ok(health_url):
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(_HEALTH_POLL_SECONDS)


def _ensure_local_server_running(
    config: dict, health_timeout: float = _HEALTH_TIMEOUT_SECONDS
) -> None:
    # Target the configured local URL (any port) or the default; boot uvicorn on
    # that URL's port if it's not already serving.
    service_url = _with_scheme(config.get("base_url", "") or _LOCAL_SERVICE_URL)
    health_url = _health_url(service_url)
    _, port = _parse_host_port(service_url)

    def _ready() -> None:
        config["base_url"] = service_url
        os.environ["COGNEE_BASE_URL"] = service_url

    if _health_ok(health_url):
        _ready()
        return

    # A missed probe is NOT absence: a server that is busy (cognifying, event
    # loop saturated) misses the health deadline exactly like a dead one, but
    # only a dead one may be installed/booted over — a busy server still holds
    # the graph store's file lock, and upgrading + migrating under it corrupts
    # the databases (2026-08-13 incident). Only a positively-absent verdict
    # from the full-evidence presence check licenses going further.
    def _require_absent(stage: str) -> bool:
        """True when the server turned out to be serving (caller returns);
        raises unless it is positively absent."""
        verdict, evidence = server_presence(service_url, confirm_absent=(stage == "pre_install"))
        if verdict == PRESENCE_READY:
            return True
        if verdict != PRESENCE_ABSENT:
            hook_log(
                "boot_refused_server_present",
                {"stage": stage, "verdict": verdict, **evidence},
            )
            raise RuntimeError(
                f"server at {service_url} is present but not serving "
                f"(verdict={verdict}, stage={stage}); refusing to install or boot over it"
            )
        return False

    if _require_absent("pre_install"):
        _ready()
        return

    # The server is positively absent and we're at a boot point: ensure the
    # venv holds the latest cognee BEFORE booting, so the server's lifespan
    # migrations run on the upgraded code. Single-flighted on its own (long)
    # lock, separate from the short boot lock below, since a cold install can
    # take minutes.
    if not ensure_cognee_installed():
        raise RuntimeError("cognee runtime unavailable (install/upgrade failed)")

    # A cold install can take minutes — long enough for the world to change.
    # Re-verify the premise before proceeding to the boot lock.
    if _require_absent("post_install"):
        _ready()
        return

    owner = f"session-start:{os.getpid()}"
    acquired = False
    deadline = time.monotonic() + _SERVER_BOOT_LOCK_WAIT_SECONDS
    try:
        _SERVER_BOOT_LOCK.parent.mkdir(parents=True, exist_ok=True)
        while True:
            now = time.time()
            if _SERVER_BOOT_LOCK.exists():
                stale = False
                try:
                    raw = json.loads(_SERVER_BOOT_LOCK.read_text(encoding="utf-8"))
                    pid = int(raw.get("pid", 0) or 0)
                    created_at = float(raw.get("created_at", 0) or 0)
                    stale = (not _pid_alive(pid)) or (
                        now - created_at > _SERVER_BOOT_LOCK_STALE_SECONDS
                    )
                except Exception:
                    stale = True
                if stale:
                    try:
                        _SERVER_BOOT_LOCK.unlink()
                        hook_log("server_bootstrap_lock_stale_reaped", {"owner": owner})
                    except Exception as exc:
                        hook_log("server_bootstrap_lock_unlink_failed", {"error": str(exc)[:200]})

            try:
                fd = os.open(str(_SERVER_BOOT_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump({"owner": owner, "pid": os.getpid(), "created_at": now}, fh)
                acquired = True
                hook_log("server_bootstrap_lock_acquired", {"owner": owner})
                break
            except FileExistsError:
                if _health_ok(health_url):
                    _ready()
                    return
                if time.monotonic() >= deadline:
                    raise RuntimeError("server bootstrap lock timeout")
                time.sleep(_SERVER_BOOT_LOCK_POLL_SECONDS)

        # Final re-check under the lock: waiting for it may have taken a while,
        # and only a still-absent server may be spawned over the port.
        if _require_absent("in_lock"):
            _ready()
            return

        server_env = os.environ.copy()
        # Data-dir pins + CACHING are already in os.environ via apply_cognee_env(),
        # so the copy carries them to the server process.
        # Run in agent mode: the server tears itself down once all registered
        # agents disconnect.
        server_env["COGNEE_AGENT_MODE"] = "true"
        # cognee >= 1.6.0 creates the default user at startup only when
        # DEFAULT_USER_PASSWORD is set, and never rewrites a stored password. Hand
        # the server the well-known local credentials so a fresh install gets the
        # same default user it always had and the owner-key bootstrap below can log
        # in. The server binds localhost only. setdefault: an operator's own
        # DEFAULT_USER_* export wins. COGNEE_USER_EMAIL/COGNEE_USER_PASSWORD still
        # pick the user the plugin logs in as; a non-default user must already exist.
        server_env.setdefault("DEFAULT_USER_EMAIL", _LOCAL_DEFAULT_USER_EMAIL)
        server_env.setdefault("DEFAULT_USER_PASSWORD", _LOCAL_DEFAULT_USER_PASSWORD)
        # The server's console output must not inherit this worker's stdio
        # (bootstrap.log — that is how it reached gigabytes: every line the
        # server printed for as long as it ran), but it must not vanish either:
        # a boot that dies before cognee opens its own log (import error,
        # broken venv, port bind) explains itself only on stderr. So it goes to
        # a capture pump that keeps the first megabyte of each boot in
        # server-console.log (previous boot in .1) and discards the rest.
        console_log = _STATE_DIR / "server-console.log"
        pump = _start_console_capture(console_log)
        if pump is None:
            hook_log("server_console_capture_unavailable", {"path": str(console_log)})
        server_proc = subprocess.Popen(
            [str(_VENV_PYTHON), "-m", "uvicorn", "cognee.api.client:app", "--port", str(port)],
            # Import the installed runtime even when the host opened a Cognee checkout.
            cwd=str(_VENV_DIR),
            env=server_env,
            stdin=subprocess.DEVNULL,
            stdout=pump.stdin if pump else subprocess.DEVNULL,
            stderr=subprocess.STDOUT if pump else subprocess.DEVNULL,
            start_new_session=True,
        )
        if pump is not None and pump.stdin is not None:
            pump.stdin.close()  # the server holds the write end now
        # Presence evidence for future boot points: covers the spawn-to-bind
        # window where neither the health probe nor the TCP listener sees it.
        write_server_pidfile(
            port,
            server_proc.pid,
            version=_PINNED_COGNEE_VERSION,
            llm_observer=server_env.get("COGNEE_LLM_OBSERVER_ACTIVE", "") == "1",
        )

        health_deadline = time.monotonic() + health_timeout
        while time.monotonic() < health_deadline:
            if _health_ok(health_url):
                _ready()
                return
            exit_code = server_proc.poll()
            if exit_code is not None:
                clear_server_pidfile(port)
                # An immediate exit is usually a failed port bind — something
                # claimed the port between our absence check and the spawn. If
                # that something is serving, connect to it instead of failing.
                if _health_ok(health_url):
                    _ready()
                    return
                tail = _console_capture_tail(console_log)
                hook_log(
                    "server_exited_before_healthy", {"rc": exit_code, "console_tail": tail[-600:]}
                )
                raise RuntimeError(
                    f"server process exited (rc={exit_code}) before becoming "
                    f"healthy at {health_url}; console: {console_log}"
                    + (f"\n{tail}" if tail else "")
                )
            time.sleep(_HEALTH_POLL_SECONDS)

        raise RuntimeError(
            f"Cognee server did not become healthy at {health_url} within {health_timeout}s; "
            f"console: {console_log}; server log: newest file in {_COGNEE_HOME / 'logs'}"
        )
    finally:
        if acquired:
            try:
                _SERVER_BOOT_LOCK.unlink()
                hook_log("server_bootstrap_lock_released", {"owner": owner})
            except Exception as exc:
                hook_log("server_bootstrap_lock_release_failed", {"error": str(exc)[:200]})


def _normalize_service_url(service_url: str) -> str:
    return str(service_url or "").strip().rstrip("/")


# The credentials a server booted by this plugin is given (DEFAULT_USER_EMAIL /
# DEFAULT_USER_PASSWORD) and the ones config.py logs in with by default. They
# must agree, or a fresh install cannot mint its owner API key.
_LOCAL_DEFAULT_USER_EMAIL = "default_user@example.com"
_LOCAL_DEFAULT_USER_PASSWORD = "default_password"
_NO_PASSWORD_MARKER = "does not have a password"
_BAD_CREDENTIALS_MARKER = "LOGIN_BAD_CREDENTIALS"


def _login_failure_message(status: int, body: str) -> str:
    """One actionable sentence for a failed default-user login.

    cognee >= 1.6.0 creates the default user without a password unless the server
    was started with DEFAULT_USER_PASSWORD, and logging into such a user answers
    400 "does not have a password". A server this plugin boots gets the variable
    itself, so that answer means an externally managed server, whose environment
    the plugin cannot set.
    """
    head = f"default-user login failed ({status}: {body[:200]})."
    if status == 400 and _NO_PASSWORD_MARKER in body:
        return (
            f"{head} The server's default user has no password: cognee >= 1.6.0 "
            "creates none unless the server is started with DEFAULT_USER_PASSWORD set. "
            "Start the server with DEFAULT_USER_PASSWORD set to the same value as "
            "COGNEE_USER_PASSWORD, or set COGNEE_API_KEY to skip the login."
        )
    if status == 400 and _BAD_CREDENTIALS_MARKER in body:
        return (
            f"{head} The server rejected COGNEE_USER_EMAIL/COGNEE_USER_PASSWORD; point "
            "them at a user that exists on that server, or set COGNEE_API_KEY."
        )
    return f"{head} Set COGNEE_USER_EMAIL/COGNEE_USER_PASSWORD correctly, or set COGNEE_API_KEY."


async def _login_default_user_for_owner_api_key(service_url: str, config: dict) -> str:
    base = _normalize_service_url(service_url)
    email = config.get("user_email", "")
    password = config.get("user_password", "")

    status, body = _cloud_http_request(
        f"{base}/api/v1/auth/login",
        method="POST",
        form_body={"username": email, "password": password},
        timeout=30.0,
    )
    if status != 200:
        raise RuntimeError(_login_failure_message(status, body))
    login_data = json.loads(body) if body else {}
    jwt = str(login_data.get("access_token", "") or "")
    if not jwt:
        raise RuntimeError("default-user login returned no access token")

    status, body = _cloud_http_request(
        f"{base}/api/v1/auth/api-keys",
        method="GET",
        cookies={"auth_token": jwt},
        timeout=30.0,
    )
    if status == 200:
        keys = json.loads(body) if body else []
        if isinstance(keys, list) and keys:
            key = str(keys[0].get("key", "") or "")
            if key:
                return key

    status, body = _cloud_http_request(
        f"{base}/api/v1/auth/api-keys",
        method="POST",
        json_body={"name": "claude-owner-bootstrap"},
        cookies={"auth_token": jwt},
        timeout=30.0,
    )
    if status != 200:
        raise RuntimeError(f"default-user API key creation failed ({status}: {body[:200]})")
    payload = json.loads(body) if body else {}
    key = str(payload.get("key", "") or "")
    if not key:
        raise RuntimeError("default-user API key creation returned empty key")
    return key


def _resolve_agent_name(config: dict, cwd: str) -> str:
    def _normalize(name: str) -> str:
        raw = str(name or "").strip()
        if raw.endswith("@cognee.agent"):
            raw = raw[: -len("@cognee.agent")]
        suffix = "_claude"
        if raw.endswith(suffix):
            return raw
        return f"{raw}{suffix}"

    configured = str(config.get("agent_name", "") or "").strip()
    if configured:
        return _normalize(configured)
    return _normalize(f"claude-{Path(cwd).name}")


async def _resolve_single_principal_key(service_url: str, config: dict) -> str:
    """Resolve the PRINCIPAL key for this deployment.

    Order: env ``COGNEE_API_KEY`` -> single cached key -> mint once from the
    default user (and cache it).

    The provisioned plugin-agent key is explicitly NOT a principal: earlier
    steps in this same process may have stamped it into the env / config (see
    ``_api_key_with_source``), and provisioning authenticated as the agent
    would nest a new agent under the agent. Skip it wherever it leaked in.
    """
    from _plugin_common import (
        load_cached_agent_key,
        load_cached_api_key,
        save_cached_api_key,
    )

    agent_key = load_cached_agent_key(service_url)
    api_key = str(config.get("api_key", "") or os.environ.get("COGNEE_API_KEY", "")).strip()
    if agent_key and api_key == agent_key:
        api_key = ""
    if not api_key:
        api_key = os.environ.get("COGNEE_PRINCIPAL_API_KEY", "") or load_cached_api_key(service_url)
    if not api_key:
        api_key = await _login_default_user_for_owner_api_key(service_url, config)
        if api_key:
            save_cached_api_key(service_url, api_key)
    return api_key


# Shared-memory outcomes that no retry within this deployment can change: the
# server predates the permissions API or cannot store session entries by
# dataset UUID, the user is not the owner of its tenant, or a tenant-less user
# already owns data (activating a tenant would hide it). Under identity mode
# ``auto`` an install that hit one of these stays on the principal instead of
# probing and provisioning again every launch.
_STRUCTURAL_SHARED_MEMORY_FAILURES = frozenset(
    {"unsupported", "typed_dataset_unsupported", "not_tenant_owner", "tenantless_with_data"}
)


async def _ensure_plugin_identity(service_url: str, config: dict, principal_key: str) -> str:
    """Resolve the plugin's dedicated agent key, provisioning when the mode allows.

    ``plugin_identity`` / ``COGNEE_PLUGIN_IDENTITY`` selects the policy:
      - ``false``: principal only; a cached identity is ignored.
      - ``true``: explicit identity. Provision (create-only — never rotating a
        key another machine may hold) when none is cached. Anything that
        prevents that — a server without the create-only contract, a cached
        key bound to another principal, a key the server rejected — is an
        error, never a silent fall back to the owner's authority.
      - ``auto`` (default): identity in service of shared agent memory. With
        shared memory on, provision when none is cached; the caller then wires
        the shared role and reverts to the principal if that fails, so nothing
        the principal owns is ever stranded. With shared memory off, or after a
        structural shared-memory failure, stay on the principal. A blocked or
        foreign cached key is not used: the launch runs as the principal and
        says so in the log.

    A cached key that passes its checks always wins — provisioning again would
    rotate it out from under every other machine of this user.
    """
    from _plugin_common import (
        _AGENT_KEY_CACHE,
        _installed_plugin_version,
        _load_json_file,
        _principal_fingerprint,
        load_cached_agent_key,
        load_cached_api_key,
        load_shared_memory_marker,
        plugin_identity_lock,
        plugin_identity_mode,
        provision_plugin_agent_via_http,
        save_cached_agent_key,
        save_cached_api_key,
        shared_memory_enabled,
    )

    mode = plugin_identity_mode(config)
    if mode == "disabled":
        return ""
    strict = mode == "enabled"
    with plugin_identity_lock():
        key = load_cached_agent_key(service_url)
        record = _load_json_file(_AGENT_KEY_CACHE)
        if key:
            if record.get("blocked"):
                if strict:
                    raise RuntimeError(
                        "Plugin identity is disconnected; explicit reconnect is required"
                    )
                hook_log("plugin_identity_skipped", {"reason": "blocked"})
                return ""
            if record.get("principal_fingerprint") != _principal_fingerprint(principal_key):
                if strict:
                    raise RuntimeError(
                        "Cached plugin identity does not match this principal; reconnect explicitly"
                    )
                hook_log("plugin_identity_skipped", {"reason": "principal_mismatch"})
                return ""
            return key
        if not strict:
            if not shared_memory_enabled(config):
                return ""
            marker = load_shared_memory_marker(service_url)
            prior = str(marker.get("reason") or "")
            if prior in _STRUCTURAL_SHARED_MEMORY_FAILURES:
                # Structural for the plugin version that recorded it. After an
                # update the limitation may be gone (server-side fixes ship
                # with plugin bumps), so try once more instead of never again.
                if marker.get("plugin_version") == _installed_plugin_version():
                    hook_log("plugin_provision_skipped", {"status": "shared_memory_" + prior})
                    return ""
                hook_log("plugin_provision_retry_after_update", {"prior_reason": prior})
        status, body = provision_plugin_agent_via_http(
            principal_key=principal_key, service_url=service_url
        )
        if status != "provisioned":
            if strict:
                raise RuntimeError(
                    f"Plugin provisioning {status}; owner fallback is disabled. "
                    "Safe create-only SDK support is required."
                )
            # ``auto``: no identity on this server (no create-only contract, or
            # an agent that already exists without a key here) — the principal
            # sees everything anyway, so shared memory has nothing to add.
            hook_log("plugin_provision_skipped", {"status": status})
            return ""
        key = str(body.get("api_key") or "").strip()
        save_cached_agent_key(
            service_url, key, str(body.get("agent_id") or ""), principal_key=principal_key
        )
        # Keep the PRINCIPAL reachable for later control-plane work (grant
        # backfills from the idle watcher): an env-provided key only lives in
        # this process's environment.
        if not load_cached_api_key(service_url):
            save_cached_api_key(service_url, principal_key)
        config["_provisioned_now"] = True
        hook_log(
            "plugin_agent_provisioned",
            {
                "agent_id": str(body.get("agent_id") or ""),
                "created": bool(body.get("created")),
                "reason": "explicit" if strict else "shared_memory",
            },
        )
        return key


def _wire_shared_memory(
    service_url: str, config: dict, principal_key: str, agent_key: str, session_key: str
) -> dict:
    """Run the shared-memory wiring for the active agent and pin the launch's
    canonical dataset ids. Returns ``ensure_shared_memory``'s outcome."""
    from _plugin_common import (
        ensure_shared_memory,
        hook_log,
        load_cached_agent_id,
        set_launch_dataset_ids,
    )

    shared = ensure_shared_memory(
        service_url=service_url,
        principal_key=principal_key,
        agent_key=agent_key,
        agent_id=load_cached_agent_id(service_url),
        dataset=str(config.get("dataset", "") or "").strip(),
        allow_setup=True,
        config=config,
    )
    set_launch_dataset_ids(session_key, shared["dataset_id"], shared["dataset_ids"])
    hook_log(
        "shared_memory_resolved",
        {
            "mode": shared["mode"],
            "reason": shared["reason"],
            "dataset_id": shared["dataset_id"],
            "read_ids": len(shared["dataset_ids"]),
        },
    )
    return shared


async def _ensure_agent_credentials_and_register(
    config: dict, cwd: str, session_id: str, agent_session_name: str, session_key: str
) -> tuple[str, str, str, bool]:
    service_url = _normalize_service_url(str(config.get("base_url", "") or ""))
    if not service_url:
        return "", "", "", False

    from _plugin_common import (
        block_cached_agent_key,
        clear_cached_agent_key,
        plugin_identity_mode,
        register_agent_via_http,
        set_launch_dataset_ids,
    )

    principal_key = await _resolve_single_principal_key(service_url, config)
    if not principal_key:
        return "", "", "", False

    os.environ["COGNEE_PRINCIPAL_API_KEY"] = principal_key
    agent_key = await _ensure_plugin_identity(service_url, config, principal_key)

    # Shared agent memory: wire the agent into the user's shared role and pin
    # the canonical dataset ids on the launch record. Under identity mode
    # ``auto`` the agent was provisioned only on the promise that shared memory
    # keeps the principal's datasets reachable — if that wiring did not happen,
    # honour the promise by staying on the principal (the agent key is dropped
    # and its server-side key revoked; a structural reason also stops the next
    # launch from provisioning again). An explicit identity (``true``) is kept
    # regardless: the user asked for it.
    shared = {
        "mode": "separated",
        "reason": "no_agent_identity",
        "dataset_id": "",
        "dataset_ids": [],
    }
    if agent_key:
        shared = _wire_shared_memory(service_url, config, principal_key, agent_key, session_key)
        if (
            shared["mode"] != "shared"
            and config.get("_provisioned_now")
            and plugin_identity_mode(config) != "enabled"
        ):
            hook_log(
                "plugin_identity_reverted",
                {"reason": shared["reason"], "detail": "shared memory unavailable"},
            )
            from _plugin_common import disconnect_plugin_agent_via_http

            # Nobody will hold the key just minted: revoke it server-side (the
            # agent user stays for a later, successful migration).
            disconnect_plugin_agent_via_http(principal_key=principal_key)
            clear_cached_agent_key()
            agent_key = ""
            set_launch_dataset_ids(session_key, "", [])
    api_key = agent_key or principal_key

    os.environ["COGNEE_API_KEY"] = api_key
    config["api_key"] = api_key

    # The effective identity's user id (best-effort) — used for dataset
    # readiness + watchers. Under a plugin identity this is the agent
    # sub-user, which is exactly the user the data plane operates as.
    user_id = await _user_id_via_api(service_url, api_key)

    def _register() -> tuple[bool, dict]:
        # Registration is a lifecycle counter + connection registry under the
        # effective identity. The connection handle IS the Cognee session id.
        # Under shared memory the binding is the canonical dataset's UUID.
        return register_agent_via_http(
            agent_session_name=agent_session_name,
            session_id=session_id,
            dataset_names=[str(config.get("dataset", "") or "").strip()],
            dataset_ids=[shared["dataset_id"]] if shared.get("dataset_id") else None,
        )

    registered, registration = _register()
    if not registered and registration.get("auth_failed") and agent_key:
        # The provisioned key was revoked out-of-band (dashboard disconnect or
        # a rotation elsewhere). It is blocked so no later hook reuses it, and
        # never re-provisioned: the create-only contract refuses an agent that
        # already exists, and rotating would revoke another machine's key.
        block_cached_agent_key(agent_key)
        if plugin_identity_mode(config) == "enabled":
            raise RuntimeError(
                "Plugin identity rejected; automatic re-provision and owner fallback are disabled"
            )
        # ``auto``: this launch runs as the principal; shared memory is off
        # until the identity is reconnected explicitly.
        hook_log("plugin_identity_rejected_fallback", {"agent_key_blocked": True})
        agent_key = ""
        api_key = principal_key
        shared = {
            "mode": "separated",
            "reason": "identity_rejected",
            "dataset_id": "",
            "dataset_ids": [],
        }
        set_launch_dataset_ids(session_key, "", [])
        os.environ["COGNEE_API_KEY"] = api_key
        config["api_key"] = api_key
        user_id = await _user_id_via_api(service_url, api_key)
        registered, registration = _register()
    # Optional lifecycle routes (older / minimal servers, lifecycle_supported is
    # False): the session runs unregistered rather than failing. Anything else
    # is a real failure on a server that has the route — raise with the HTTP
    # status so the caller can classify it (auth vs server error).
    if not registered and registration.get("lifecycle_supported") is not False:
        status = registration.get("status_code")
        message = f"Failed to register session '{session_id}' on {service_url}."
        if status:
            raise urllib.error.HTTPError(service_url, status, message, None, None)
        raise RuntimeError(message)

    hook_log(
        "agent_register_result",
        {
            "agent_session_name": agent_session_name,
            "registered": registered,
            "connection_id": str(registration.get("id", "")),
            "session_id": session_id,
            "user_id": user_id,
        },
    )

    return user_id, api_key, agent_session_name, registered


def _watcher_alive() -> bool:
    if not _WATCHER_PID.exists():
        return False
    try:
        pid = int(_WATCHER_PID.read_text(encoding="utf-8").strip())
    except Exception:
        return False
    return _pid_alive(pid)


def _spawn_idle_watcher(
    session_id: str, dataset: str, user_id: str, config: dict, session_key: str
) -> None:
    """Launch the idle watcher as a detached background process.

    Idempotent: if a watcher is already alive (from an earlier session
    on the same machine), we kill it so the new one picks up the new
    session. Launched with its own session via ``start_new_session=True``
    so it survives the parent shell closing.
    """
    if _watcher_alive():
        try:
            pid = int(_WATCHER_PID.read_text(encoding="utf-8").strip())
            os.kill(pid, signal.SIGTERM)
        except Exception as exc:
            hook_log("idle_watcher_kill_failed", {"error": str(exc)[:200]})

    # Clear any stale stop sentinel from a previous run.
    try:
        if _WATCHER_STOP.exists():
            _WATCHER_STOP.unlink()
    except Exception as exc:
        hook_log("watcher_stop_unlink_failed", {"error": str(exc)[:200]})

    # Only the non-secret surface of config needs to travel — the
    # watcher re-runs ``ensure_cognee_ready`` on its own.
    bootstrap = {
        "session_id": session_id,
        "dataset": dataset,
        "user_id": user_id,
        "session_key": session_key,
        "config": {
            "base_url": config.get("base_url", ""),
            "llm_model": config.get("llm_model", ""),
            "dataset": dataset,
        },
    }

    log_path = _STATE_DIR / "watcher.log"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        _rotate_log_if_oversized(log_path)  # the child writes it; cap it at handover
        log_fh = log_path.open("a", encoding="utf-8")
    except Exception as exc:
        hook_log("watcher_log_open_failed", {"error": str(exc)[:200]})
        log_fh = subprocess.DEVNULL

    try:
        env = os.environ.copy()
        if session_key:
            env["COGNEE_SESSION_KEY"] = session_key
        subprocess.Popen(
            [sys.executable, str(_WATCHER_SCRIPT), json.dumps(bootstrap)],
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
            env=env,
            start_new_session=True,
            close_fds=True,
        )
        print("cognee-plugin: idle watcher started", file=sys.stderr)
    except Exception as e:
        print(f"cognee-plugin: idle watcher launch failed ({e})", file=sys.stderr)


def _find_claude_parent_pid() -> int:
    """Find the live Claude host process for this hook.

    Claude Code exports its own pid as ``CLAUDE_PID`` to every subprocess; when
    that pid is alive it IS the host, so use it before walking the process tree.
    The walk below stops at the *nearest* ``claude`` ancestor, which on the
    Windows desktop app is the short-lived hook-runner rather than the session
    runtime: the exit watcher then sees ``parent_exited`` within a second of
    session start, runs the final sync early and unregisters the live connection
    (topoteretes/cognee-integrations#391).
    """
    try:
        host_pid = int(str(os.environ.get("CLAUDE_PID", "") or "0").strip() or 0)
    except ValueError:
        host_pid = 0
    if host_pid > 1 and _pid_alive(host_pid):
        return host_pid
    fallback = os.getppid()
    if sys.platform == "win32":
        return find_host_ancestor_windows(fallback, "claude")
    try:
        raw = subprocess.check_output(
            ["ps", "-axo", "pid=,ppid=,command="],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception as exc:
        hook_log("find_claude_parent_failed", {"error": str(exc)[:200]})
        return fallback

    table: dict[int, tuple[int, str]] = {}
    for line in raw.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) < 3:
            continue
        try:
            pid = int(parts[0])
            ppid = int(parts[1])
        except ValueError:
            continue
        table[pid] = (ppid, parts[2])

    import re

    # Match "claude" as an executable basename anywhere in the command line,
    # tolerant of spaces in the executable path (a naive split()[0] mis-tokenizes
    # paths like "/…/Application Support/…/claude").
    host_re = re.compile(r"(?:^|/)claude(?:-[\w.]+)?(?:\s|$)")
    pid = fallback
    seen: set[int] = set()
    while pid > 1 and pid not in seen:
        seen.add(pid)
        ppid, command = table.get(pid, (0, ""))
        if command and host_re.search(command):
            return pid
        pid = ppid
    return fallback


def _spawn_exit_watcher(
    session_id: str,
    dataset: str,
    *,
    session_key: str = "",
    agent_session_name: str = "",
    api_key: str = "",
    service_url: str = "",
) -> None:
    """Launch a detached watcher that syncs only after Claude exits."""

    # Cleanup stale watcher pidfiles so the directory does not grow forever.
    try:
        if _EXIT_WATCHERS_DIR.exists():
            for pidfile in _EXIT_WATCHERS_DIR.glob("*.pid"):
                try:
                    pid = int(pidfile.read_text(encoding="utf-8").strip())
                    if not _pid_alive(pid):
                        pidfile.unlink()
                except Exception:
                    continue
    except Exception as exc:
        hook_log("exit_watcher_prune_failed", {"error": str(exc)[:200]})

    parent_pid = _find_claude_parent_pid()
    watcher_pidfile = _EXIT_WATCHERS_DIR / f"{parent_pid}.pid"
    try:
        if watcher_pidfile.exists():
            existing = int(watcher_pidfile.read_text(encoding="utf-8").strip())
            if _pid_alive(existing):
                hook_log(
                    "exit_watcher_already_running",
                    {"parent_pid": parent_pid, "pidfile": str(watcher_pidfile)},
                )
                return
    except Exception:
        pass

    bootstrap = {
        "parent_pid": parent_pid,
        "session_id": session_id,
        "dataset": dataset,
        "session_key": session_key,
        "agent_session_name": agent_session_name,
        "base_url": service_url,
        "pidfile": str(watcher_pidfile),
    }
    log_path = _STATE_DIR / "exit-watcher.log"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        _EXIT_WATCHERS_DIR.mkdir(parents=True, exist_ok=True)
        _rotate_log_if_oversized(log_path)  # the child writes it; cap it at handover
        log_fh = log_path.open("a", encoding="utf-8")
    except Exception as exc:
        hook_log("exit_watcher_log_open_failed", {"error": str(exc)[:200]})
        log_fh = subprocess.DEVNULL

    try:
        env = os.environ.copy()
        # Credentials must not be serialized into process arguments.
        if api_key:
            env["COGNEE_API_KEY"] = api_key
        if session_key:
            env["COGNEE_SESSION_KEY"] = session_key
        subprocess.Popen(
            [sys.executable, str(_EXIT_WATCHER_SCRIPT), json.dumps(bootstrap)],
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
            env=env,
            start_new_session=True,
            close_fds=True,
        )
        hook_log(
            "exit_watcher_started",
            {
                "parent_pid": parent_pid,
                "session_id": session_id,
                "dataset": dataset,
                "pidfile": str(watcher_pidfile),
            },
        )
    except Exception as e:
        hook_log("exit_watcher_launch_failed", {"error": str(e)[:300]})


def _purge_legacy_resolved_files() -> None:
    legacy = _STATE_DIR / "resolved.json"
    scoped_dir = _STATE_DIR / "resolved"
    # config.json: an older config layer that SessionStart read but the per-turn
    # hooks never did, so a stale base_url in it split the plugin across two
    # servers (SDK-466). Nothing reads it any more; remove it so it cannot be
    # mistaken for live configuration. ~/.cognee/.env is the one setup file.
    legacy_config = _STATE_DIR / "config.json"
    try:
        if legacy_config.exists():
            legacy_config.unlink()
            hook_log("legacy_config_json_removed", {"path": str(legacy_config)})
    except Exception as exc:
        hook_log("legacy_config_json_unlink_failed", {"error": str(exc)[:200]})
    try:
        if legacy.exists():
            legacy.unlink()
    except Exception as exc:
        hook_log("legacy_resolved_unlink_failed", {"error": str(exc)[:200]})
    try:
        if scoped_dir.exists():
            shutil.rmtree(scoped_dir)
    except Exception as exc:
        hook_log("legacy_resolved_dir_remove_failed", {"error": str(exc)[:200]})


@contextmanager
def _bootstrap_singleflight():
    """Allow exactly one detached bootstrap worker at a time (machine-wide).

    The marker is global because Claude and Codex share one local server, so
    only one of them should drive the boot + migration at any moment.
    """
    acquired = False
    try:
        _BOOTSTRAP_LOCK.parent.mkdir(parents=True, exist_ok=True)
        now = time.time()
        if _BOOTSTRAP_LOCK.exists():
            stale = False
            try:
                raw = json.loads(_BOOTSTRAP_LOCK.read_text(encoding="utf-8"))
                pid = int(raw.get("pid", 0) or 0)
                created_at = float(raw.get("created_at", 0) or 0)
                stale = (not _pid_alive(pid)) or (now - created_at > _BOOTSTRAP_LOCK_STALE_SECONDS)
            except Exception:
                stale = True
            if stale:
                try:
                    _BOOTSTRAP_LOCK.unlink()
                except Exception as exc:
                    hook_log("bootstrap_lock_unlink_failed", {"error": str(exc)[:200]})
        try:
            fd = os.open(str(_BOOTSTRAP_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"pid": os.getpid(), "created_at": now}, fh)
            acquired = True
        except FileExistsError:
            acquired = False
        yield acquired
    finally:
        if acquired:
            try:
                _BOOTSTRAP_LOCK.unlink()
            except Exception as exc:
                hook_log("bootstrap_lock_release_failed", {"error": str(exc)[:200]})


def _spawn_bootstrap(
    config: dict,
    cwd: str,
    session_id: str,
    agent_session_name: str,
    session_key: str,
    dataset: str,
) -> None:
    """Launch the detached server-bootstrap worker (this script, --bootstrap)."""
    bootstrap = {
        "cwd": cwd,
        "session_id": session_id,
        "session_key": session_key,
        "dataset": dataset,
        "agent_session_name": agent_session_name,
        "base_url": str(config.get("base_url", "") or _LOCAL_SERVICE_URL),
    }
    log_path = _STATE_DIR / "bootstrap.log"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        _rotate_log_if_oversized(log_path)  # the child writes it; cap it at handover
        log_fh = log_path.open("a", encoding="utf-8")
    except Exception as exc:
        hook_log("bootstrap_log_open_failed", {"error": str(exc)[:200]})
        log_fh = subprocess.DEVNULL
    try:
        env = os.environ.copy()
        if session_key:
            env["COGNEE_SESSION_KEY"] = session_key
        subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), _BOOTSTRAP_ARG, json.dumps(bootstrap)],
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
            env=env,
            start_new_session=True,
            close_fds=True,
        )
        hook_log("bootstrap_spawned", {"session_id": session_id})
    except Exception as exc:
        hook_log("bootstrap_spawn_failed", {"error": str(exc)[:300]})


def _status_from_error(message: str) -> int:
    """Extract an HTTP status embedded as ``(<status>: ...)`` in an error string.

    ``ensure_cognee_ready`` and ``ensure_dataset_ready_via_api`` both format their
    RuntimeError as ``... (<status>: <body>)``; return 0 when none is present
    (e.g. a connection error carries no HTTP status).
    """
    import re

    if isinstance(message, urllib.error.HTTPError):
        return message.code
    m = re.search(r"\((\d{3})[:\s)]", str(message or ""))
    return int(m.group(1)) if m else 0


def _classify_conn_status(status: int) -> str:
    """Map an HTTP status to a connection-failure state."""
    if status in (401, 403):
        return "auth_failed"
    if status >= 500:
        return "server_error"
    return "unreachable"


async def _run_heavy(
    config: dict,
    cwd: str,
    session_id: str,
    agent_session_name: str,
    session_key: str,
    dataset: str,
    *,
    managed_endpoint: bool,
    boot_timeout: float,
) -> tuple[str, str, bool]:
    """Slow session bootstrap shared by the inline (legacy) path and the
    detached worker: server boot wait, cognee init, agent registration, dataset
    creation, and the server-ready marker.

    Returns ``(user_id, agent_api_key, ok)``. ``ok`` is False only on a hard
    cloud-registration failure (mirrors the legacy early-abort).
    """
    if not managed_endpoint:
        try:
            _ensure_local_server_running(config, health_timeout=boot_timeout)
        except Exception as exc:
            hook_log("server_bootstrap_warning", {"error": str(exc)[:200]})

    # On a cold start this worker began under the host python3, so the
    # _plugin_common import-time guard could not re-exec us. The boot above
    # (via ensure_cognee_installed) has now built the venv, so flip into it so
    # the rest of this bootstrap runs under the plugin-owned interpreter. No-op
    # when the venv is absent (connect/managed mode never builds one) or when
    # we are already inside it (warm start).
    _reexec_into_venv()

    # Track the cloud connection outcome so the status line can show a precise
    # "✕ (<reason>)". Stays None in local mode (handled by the health probe at
    # the tail).
    _conn_state = None
    _conn_detail = ""

    # Configure cognee (cloud or local)
    try:
        await ensure_cognee_ready(config)
    except Exception as e:
        print(f"cognee-plugin: init warning ({e})", file=sys.stderr)
        if is_cloud_mode(config):
            status = _status_from_error(e)
            _conn_state = _classify_conn_status(status) if status else "unreachable"
            _conn_detail = str(e)[:200]

    # Register agent identity.
    user_id = ""
    agent_api_key = ""
    agent_id = ""
    agent_name = _resolve_agent_name(config, cwd)
    os.environ["COGNEE_AGENT_NAME"] = agent_name

    # HTTP path: resolve the single principal key (env / cache / mint from the
    # default user) and register this session as an agent-mode connection.
    if is_cloud_mode(config):
        try:
            (
                agent_id,
                agent_api_key,
                agent_name,
                _registered,
            ) = await _ensure_agent_credentials_and_register(
                config, cwd, session_id, agent_session_name, session_key
            )
            if agent_id:
                user_id = agent_id
        except Exception as exc:
            message = str(exc)[:300]
            hook_log("agent_lifecycle_error", {"error": message})
            print(f"cognee-plugin: agent lifecycle failed ({message})", file=sys.stderr)
            # Classify for the status line. Preserve an earlier health-derived
            # state; otherwise a reachable server rejecting registration is almost
            # always auth, while a positively-absent one is a connection failure.
            # A timed-out probe is NO verdict (busy != down): keep the prior
            # recorded state rather than stamp a false "unreachable".
            status = _status_from_error(exc)
            if _conn_state is None and status:
                _conn_state, _conn_detail = _classify_conn_status(status), message
            if _conn_state is None:
                try:
                    health = probe_health(
                        _normalize_service_url(str(config.get("base_url", "") or "")), timeout=1.5
                    )
                except Exception:
                    health = "unknown"
                if health == "down":
                    _conn_state, _conn_detail = "unreachable", message
            if _conn_state:
                write_connection_state(
                    _conn_state, str(config.get("base_url", "") or ""), detail=_conn_detail
                )
            else:
                hook_log(
                    "conn_state_unverified",
                    {"reason": "probe returned no verdict after registration failure"},
                )
            return "", "", False

    try:
        # Cloud: the API key IS the identity (the server derives the principal
        # from X-Api-Key), so dataset creation must NOT be gated on user_id —
        # servers without /users/me (e.g. cloud tenants) leave user_id empty
        # while auth works fine.
        # Under shared memory the canonical dataset was already resolved (and
        # created as the parent when absent) by the credential step; creating
        # it here as the agent would fork an agent-owned copy of the same name.
        from _plugin_common import resolve_active_dataset_ids

        if is_cloud_mode(config) and not resolve_active_dataset_ids(session_key)[0]:
            await ensure_dataset_ready_via_api(
                config.get("base_url", ""),
                agent_api_key or config.get("api_key", ""),
                dataset,
            )
    except Exception as e:
        print(f"cognee-plugin: dataset warning ({e})", file=sys.stderr)
        if is_cloud_mode(config):
            status = _status_from_error(e)
            # An authed 401/403 here is a definitive auth failure — let it win.
            if status in (401, 403):
                _conn_state, _conn_detail = "auth_failed", str(e)[:200]
            elif status >= 500 and _conn_state is None:
                _conn_state, _conn_detail = "server_error", str(e)[:200]
    from _project_memory import prepare as prepare_project_memory

    project_state = prepare_project_memory(dataset, session_id)
    if project_state:
        hook_log("project_memory_prepared", project_state)
    if user_id:
        os.environ["COGNEE_USER_ID"] = user_id

    # Record the connection outcome so the status line shows "● " (ready) or
    # "✕ (<reason>)". Cloud: use the classified state gathered above, else confirm
    # ready. Local/managed: a health probe decides ready-vs-unreachable.
    service_url = _normalize_service_url(str(config.get("base_url", "") or ""))
    if not service_url and not managed_endpoint:
        service_url = _LOCAL_SERVICE_URL
    if is_cloud_mode(config):
        if _conn_state and _conn_state != "ready":
            write_connection_state(
                _conn_state, str(config.get("base_url", "") or ""), detail=_conn_detail
            )
        elif service_url:
            health = probe_health(service_url, timeout=1.5)
            if health == "ready":
                write_connection_state("ready", service_url)
            elif health == "down":
                write_connection_state(
                    "unreachable", str(config.get("base_url", "") or service_url)
                )
            else:
                # "slow"/"unknown": no verdict — keep whatever state is already
                # recorded instead of branding a busy server unreachable.
                hook_log("conn_state_unverified", {"base_url": service_url, "health": health})
    elif service_url and probe_health(service_url, timeout=1.5) == "ready":
        write_connection_state("ready", service_url)

    # Code graph: index the repository this session opened in, or refresh it if
    # the tree moved while the agent was away. Deliberately last and inside the
    # detached worker — it must never delay the first prompt — and best-effort:
    # a failure here costs code facts, not the session.
    try:
        from _code_graph import autoindex_on_session_start

        code_outcome = autoindex_on_session_start(
            cwd,
            service_url,
            os.environ.get("COGNEE_API_KEY", ""),
            is_local_server=service_url_is_local(service_url),
        )
        if code_outcome:
            hook_log("code_autoindex", code_outcome)
    except Exception as exc:
        hook_log("code_autoindex_error", {"error": str(exc)[:200]})

    return user_id, agent_api_key, True


async def _run_bootstrap(bootstrap: dict) -> None:
    """Detached worker body.

    Two distinct concerns, deliberately decoupled:
      1. Boot the local server EXACTLY ONCE — single-flighted on _BOOTSTRAP_LOCK
         so concurrent agents don't each spawn uvicorn. Workers that don't win
         the lock just wait for /health instead of returning.
      2. Register THIS agent/session — runs for EVERY agent, regardless of who
         booted, because registration is per-session (the connection handle is
         the Cognee session id) under the single principal.
    """
    config = load_config()
    cwd = str(bootstrap.get("cwd") or os.getcwd())
    session_id = str(bootstrap.get("session_id", "") or "")
    session_key = str(bootstrap.get("session_key", "") or "")
    dataset = str(bootstrap.get("dataset", "") or get_dataset(config))
    agent_session_name = str(bootstrap.get("agent_session_name", "") or session_id)
    if session_key:
        os.environ["COGNEE_SESSION_KEY"] = session_key
    if session_id:
        os.environ["COGNEE_SESSION_ID"] = session_id
    service_url = _with_scheme(bootstrap.get("base_url", "") or _LOCAL_SERVICE_URL)
    health_url = _health_url(service_url)
    config["base_url"] = service_url
    os.environ["COGNEE_BASE_URL"] = service_url

    # 1. Ensure the server is up. Only the single-flight winner spawns uvicorn;
    #    everyone else waits for /health (the winner may still be migrating).
    if not _health_ok(health_url):
        with _bootstrap_singleflight() as acquired:
            if acquired:
                try:
                    _ensure_local_server_running(
                        config, health_timeout=_SERVER_BOOT_DEADLINE_SECONDS
                    )
                except Exception as exc:
                    hook_log("server_bootstrap_warning", {"error": str(exc)[:200]})
            else:
                hook_log("bootstrap_waiting_for_peer", {"session_id": session_id})
        if not _wait_for_health(_SERVER_BOOT_DEADLINE_SECONDS, health_url):
            hook_log("bootstrap_server_unhealthy", {"session_id": session_id})
            return

    # 2. Register this agent/session. Runs for every agent — NOT gated by the
    #    boot single-flight. _run_heavy's _ensure_local_server_running is a
    #    no-op now that the server is healthy.
    try:
        await _run_heavy(
            config,
            cwd,
            session_id,
            agent_session_name,
            session_key,
            dataset,
            managed_endpoint=False,
            boot_timeout=_SERVER_BOOT_DEADLINE_SECONDS,
        )
        hook_log("bootstrap_complete", {"session_id": session_id})
    except Exception as exc:
        hook_log("bootstrap_failed", {"error": str(exc)[:300]})


def _running_server_observer(target_url: str) -> tuple[bool, bool | None]:
    """(a local server is already up, whether it was spawned with the observer).

    The second value is None when that is unknown: a server booted by another
    integration or an older build, or one this plugin did not spawn at all.
    """
    if not target_url or not _is_local_url(target_url):
        return False, None
    try:
        from _plugin_common import live_server_record

        port = urllib.parse.urlparse(target_url).port or 80
        record = live_server_record(port)
    except Exception:
        record = {}
    if record:
        stamp = record.get("llm_observer")
        return True, (bool(stamp) if isinstance(stamp, bool) else None)
    return _health_ok(_health_url(target_url), timeout=1.0), None


def _apply_observer(config: dict, target_url: str) -> dict:
    """Decide the Claude observer for this launch, apply its env, start the shim.

    Returns the decision (``_observer.resolve_observer``) extended with
    ``shim_running``, ``server_running`` and ``server_observer``. Never raises:
    the observer is a convenience over the regular local mode, and a failure
    here must leave that mode intact — except under ``COGNEE_LLM_OBSERVER=true``,
    whose refusal is recorded so the user learns why the server has no LLM.

    The environment only reaches a server this launch spawns. When one is
    already running, its own boot-time config is what serves cognify, so that —
    not this launch's decision — sets ``active``: a server booted on the
    observer keeps needing the shim even after the user adds a key, and one
    booted with a key ignores the observer until it restarts.
    """
    try:
        from _observer import apply_observer_env, ensure_observer_running, resolve_observer

        decision = resolve_observer(config)
        server_running, server_observer = _running_server_observer(target_url)
        decision["wanted"] = bool(decision.get("active"))
        decision["server_running"] = server_running
        decision["server_observer"] = server_observer
        if server_running and server_observer is not None:
            decision["active"] = server_observer
        if decision.get("error"):
            hook_log("observer_refused", {"error": decision["error"]})
        if not decision.get("active"):
            hook_log(
                "observer_skipped",
                {
                    "reason": decision.get("reason", ""),
                    "setting": decision.get("setting", ""),
                    "server_running": server_running,
                    "server_observer": server_observer,
                },
            )
            decision["shim_running"] = False
            return decision
        if not decision.get("claude"):
            # A running observer server this launch would not have chosen (the
            # CLI is gone): nothing to start, but say what the server expects.
            decision["shim_running"] = False
            return decision
        applied = apply_observer_env(decision)
        running = ensure_observer_running(decision, cognee_url=target_url, wait=2.0)
        decision["shim_running"] = running
        hook_log(
            "observer_applied",
            {
                "claude": decision.get("claude", ""),
                "model": decision.get("model", ""),
                "model_warning": decision.get("model_warning", ""),
                "endpoint": decision.get("endpoint", ""),
                "embedding": os.environ.get("EMBEDDING_PROVIDER", ""),
                "applied": sorted(applied),
                "shim_running": running,
                "server_running": server_running,
                "server_observer": server_observer,
            },
        )
        if not running:
            hook_log("observer_shim_start_failed", {"endpoint": decision.get("endpoint", "")})
        return decision
    except Exception as exc:
        hook_log("observer_error", {"error": str(exc)[:200]})
        return {"active": False, "reason": "error", "shim_running": False}


def _record_observer(decision: dict) -> None:
    """Note the observer on this launch's record (read by the status line + doctor)."""
    try:
        from _plugin_common import _read_map_record, _write_map_record, get_session_key

        host_key = get_session_key()
        if not host_key:
            return
        record = _read_map_record(host_key)
        if not record:
            return
        record["llm_observer"] = {
            "active": bool(decision.get("active")),
            "model": str(decision.get("model") or ""),
            "endpoint": str(decision.get("endpoint") or ""),
        }
        _write_map_record(host_key, record)
    except Exception as exc:
        hook_log("observer_record_failed", {"error": str(exc)[:200]})


def _observer_note(observer: dict) -> str:
    """The SessionStart systemMessage line about the observer, or ''."""
    from _observer import SPEND_WARNING, embedding_warning

    active = bool(observer.get("active"))
    wanted = bool(observer.get("wanted", active))
    server_running = bool(observer.get("server_running"))
    server_observer = observer.get("server_observer")
    restart = (
        "It keeps that config until it restarts (it stops on its own once every "
        "session using it has closed)."
    )
    if wanted and server_running and server_observer is None:
        # Nothing records how this server booted (another integration, an older
        # build, or a server started outside the plugin). The env this launch
        # applied does not reach it, so do not claim the observer serves it.
        return (
            "Cognee Memory: a Cognee server was already running and it is unknown which "
            "LLM it was started with, so the Claude observer may not be serving it. If it "
            f"is, cognify/improve use your Claude subscription. {restart}"
        )
    if active:
        lines = [
            f"⚠ LLM: Claude Code (observer), model {observer.get('model')}. {SPEND_WARNING}",
            embedding_warning(),
        ]
        if observer.get("model_warning"):
            lines.append(f"Warning: {observer['model_warning']}")
        if server_running and server_observer is True and not wanted:
            lines.append(
                "The running Cognee server was started on the observer, so it still uses "
                f"your subscription although this session would not have chosen it. {restart}"
            )
        else:
            lines.append(
                "To use a provider key instead, set LLM_API_KEY in ~/.cognee/.env; "
                "COGNEE_LLM_OBSERVER=false turns the observer off."
            )
        if not observer.get("shim_running"):
            lines.append(
                "Warning: the observer shim is not running — check "
                "~/.cognee-plugin/observer/observer.log; the server has no LLM until it runs."
            )
        return "\n".join(lines)
    if wanted and server_running and server_observer is False:
        return (
            "Cognee Memory: the Claude observer was not applied — the running Cognee "
            f"server was started with its own LLM config. {restart}"
        )
    if observer.get("error"):
        return f"Cognee Memory: {observer['error']}"
    return ""


def _with_observer_note(output: dict, observer: dict) -> dict:
    """Tell the user (systemMessage) when the server's LLM is the Claude subscription,
    what that costs, or why a requested observer could not be honoured."""
    try:
        note = _observer_note(observer)
    except Exception as exc:
        hook_log("observer_note_failed", {"error": str(exc)[:200]})
        note = ""
    if not note:
        return output
    result = dict(output or {})
    hso = dict(result.get("hookSpecificOutput") or {})
    hso.setdefault("hookEventName", "SessionStart")
    existing = str(hso.get("systemMessage") or "").strip()
    hso["systemMessage"] = f"{existing}\n\n{note}" if existing else note
    result["hookSpecificOutput"] = hso
    # Claude Code shows only the top-level ``systemMessage`` to the user; the
    # nested one is kept for readers of hookSpecificOutput (Antigravity adapter).
    top = str(result.get("systemMessage") or "").strip()
    result["systemMessage"] = f"{top}\n\n{note}" if top else note
    return result


def _session_start_guidance(mode: str, dataset: str, session_id: str, ready: bool) -> dict:
    if ready:
        message = (
            "## Cognee Memory Connected\n"
            f"Mode: {mode} | Dataset: {dataset} | Session: {session_id}\n\n"
            "Cognee organizes knowledge into three categories.\n"
            "- user_context: user preferences and personal facts\n"
            "- project_docs: repository and project knowledge\n"
            "- agent_actions: tool traces and agent findings\n\n"
            "Use /cognee-memory:cognee-remember to store permanent memory, "
            "and /cognee-memory:cognee-search to query by node set."
        )
    else:
        message = (
            "## Cognee Memory Connecting\n"
            f"Mode: {mode} | Dataset: {dataset} | Session: {session_id}\n\n"
            "The local Cognee server is starting up (first run or database "
            "migrations can take a little while). Your prompts work normally now; "
            "memory recall activates automatically once the server is ready."
        )
    return {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "systemMessage": message,
        }
    }


def _ensure_statusline_configured() -> None:
    """Write the statusLine entry to ~/.claude/settings.json when safe.

    Claude Code hot-reloads settings.json, so the status line becomes active on
    the next status refresh without requiring a restart.
    """
    if os.environ.get("COGNEE_STATUSLINE", "").lower() in {"0", "false", "no", "off"}:
        hook_log("statusline_setup_skipped", {"reason": "disabled_by_env"})
        return

    plugin_root = os.environ.get("CLAUDE_PLUGIN_ROOT", "")
    if plugin_root:
        statusline_sh = Path(plugin_root) / "scripts" / "cognee-statusline.sh"
    else:
        statusline_sh = Path(__file__).resolve().parent / "cognee-statusline.sh"

    if not statusline_sh.exists():
        hook_log(
            "statusline_setup_skipped", {"reason": "script_not_found", "path": str(statusline_sh)}
        )
        return

    settings_path = Path.home() / ".claude" / "settings.json"
    # Guard on the script's existence at run time. Claude Code does not remove
    # this statusLine entry when the plugin is uninstalled, and the command runs
    # through a shell — so if the plugin's files are later purged from the cache,
    # a bare path would fail on every refresh. The `[ -x ] && exec … || true`
    # guard degrades to a clean, empty status line instead. (When the files
    # linger but the plugin is disabled, the renderer self-evicts this entry.)
    guarded_command = f'[ -x "{statusline_sh}" ] && exec "{statusline_sh}" || true'
    desired = {"type": "command", "command": guarded_command}
    # Re-run the (network-free, local-only) renderer on a fixed timer in addition
    # to Claude's event-driven updates, so the connection glyph reflects a change
    # (e.g. a bad key detected at SessionStart, or the server dying) while the
    # session is idle — event triggers go quiet when idle, and settings changes
    # are not themselves a refresh trigger. Default 2s; COGNEE_STATUSLINE_REFRESH_INTERVAL
    # overrides, and a value < 1 (e.g. 0) omits it to disable idle polling.
    try:
        _interval = int(float(os.environ.get("COGNEE_STATUSLINE_REFRESH_INTERVAL", "") or 2))
    except ValueError:
        _interval = 2
    if _interval >= 1:
        desired["refreshInterval"] = _interval

    try:
        settings: dict = {}
        if settings_path.exists():
            text = settings_path.read_text(encoding="utf-8").strip()
            if text:
                settings = json.loads(text)

        existing = settings.get("statusLine")
        if existing == desired:
            return

        existing_command = existing.get("command") if isinstance(existing, dict) else None
        is_cognee_owned = (
            isinstance(existing_command, str) and "cognee-statusline.sh" in existing_command
        )
        if existing and not is_cognee_owned:
            hook_log("statusline_setup_skipped", {"reason": "user_statusline_exists"})
            return

        settings["statusLine"] = desired
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=settings_path.parent, prefix=".settings-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(settings, f, indent=2)
                f.write("\n")
            os.replace(tmp, settings_path)
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        hook_log("statusline_configured", {"path": str(statusline_sh)})
    except Exception as exc:
        hook_log("statusline_setup_failed", {"error": str(exc)[:200]})


_MEMORY_PREFERENCE_STEER = (
    "Memory policy for this session: Cognee is the preferred, authoritative long-term "
    "memory. On every user request, Cognee memory relevant to the prompt is "
    "automatically recalled and injected into your context before you answer — consult "
    "that recalled Cognee context FIRST. When you need to look up or store durable "
    "information, use the Cognee tools/skills (cognee-search, cognee-remember) in "
    "preference to Claude Code's built-in file memory (MEMORY.md), and do not duplicate "
    "durable knowledge into MEMORY.md. Cognee is the source of truth for memory."
)


def _apply_memory_preference(output: dict) -> dict:
    """Steer Claude to treat Cognee as the preferred memory over native auto-memory.

    Claude Code's built-in auto memory (MEMORY.md) can't be reliably disabled by a
    plugin, so instead we assert Cognee as the authoritative memory via a SessionStart
    ``additionalContext`` instruction (injected into the model's context, not shown to
    the user). Applied across all SessionStart branches. Opt out with
    ``COGNEE_PREFER_MEMORY=false``.
    """
    try:
        val = load_config().get("prefer_cognee_memory", True)
    except Exception:
        val = True
    if str(val).strip().lower() in {"0", "false", "no", "off"}:
        return output

    result = dict(output or {})
    hso = dict(result.get("hookSpecificOutput") or {})
    hso.setdefault("hookEventName", "SessionStart")
    existing = str(hso.get("additionalContext") or "").strip()
    hso["additionalContext"] = (
        f"{existing}\n\n{_MEMORY_PREFERENCE_STEER}" if existing else _MEMORY_PREFERENCE_STEER
    )
    result["hookSpecificOutput"] = hso
    return result


def _apply_update_nudge(output: dict) -> dict:
    """Append a one-time 'update available' systemMessage (once per new version).

    The version comparison + marker are produced by the background check in the
    idle watcher; here we only READ the marker (no network). The status line
    surfaces the same info ambiently on every refresh — this message is the
    actionable, one-shot nudge. Shown once per newly-detected version (tracked
    via ``notified_version``) so it never nags, and auto-stops once updated.
    """
    try:
        from _plugin_common import mark_update_notified, read_update_status

        status = read_update_status()
    except Exception:
        return output
    if not status:
        return output
    installed = str(status.get("installed_version") or "")
    latest = str(status.get("latest_version") or "")
    if not (installed and latest) or status.get("notified_version") == latest:
        return output

    message = (
        f"Cognee update available {installed} → {latest} — run "
        "`/plugin update cognee-memory@cognee` (or enable marketplace auto-update)."
    )
    result = dict(output or {})
    hso = dict(result.get("hookSpecificOutput") or {})
    hso.setdefault("hookEventName", "SessionStart")
    existing = str(hso.get("systemMessage") or "").strip()
    hso["systemMessage"] = f"{existing}\n\n{message}" if existing else message
    result["hookSpecificOutput"] = hso
    try:
        mark_update_notified(latest)
    except Exception:
        pass
    return result


async def _start(payload: dict | None = None) -> dict:
    _ensure_statusline_configured()
    config = load_config()
    payload = payload or {}
    cwd = str(payload.get("cwd") or os.environ.get("CLAUDE_CWD") or os.getcwd())
    # The service URL is the sole router (api_key is optional auth, with a
    # default-user fallback in registration). COGNEE_AGENT_MODE is NOT decided
    # here: it's set only when we actually boot a server (in
    # _ensure_local_server_running), so connecting to an already-running server
    # never claims ownership of its teardown.
    configured_url = _with_scheme(str(config.get("base_url", "") or "").strip())
    api_key = str(config.get("api_key", "") or "").strip()
    # Forced cloud (backend switch) with no URL configured: there is nothing to
    # boot and nothing to fall back to — keep the target empty so no local
    # server is spawned, let the connection attempt fail, and let the status
    # line report the missing URL. Everything else keeps the localhost default.
    forced_cloud_unconfigured = not configured_url and config.get("_forced_backend") == "cloud"
    target_url = configured_url or ("" if forced_cloud_unconfigured else _LOCAL_SERVICE_URL)
    config["base_url"] = target_url
    os.environ["COGNEE_BASE_URL"] = target_url
    if api_key:
        os.environ["COGNEE_API_KEY"] = api_key

    # Claude observer: local mode with no LLM key of its own runs the server's
    # LLM calls through Claude Code (`claude -p --safe-mode`) behind a loopback
    # OpenAI-compatible shim, with embeddings on fastembed. Decided and applied
    # HERE, before the install/boot below: the install reads EMBEDDING_PROVIDER
    # to add the fastembed extra, and the server inherits the provider variables
    # at spawn. The shim is started detached now so the server's first LLM call
    # (and the watcher's key check) find it listening.
    observer = _apply_observer(config, target_url)

    # NOTE: the local server's LLM_API_KEY health is deliberately NOT judged here.
    # A hook-env read (config's llm_api_key / OPENAI_API_KEY) is blind to a key that
    # lives in cognee's own config or a .env the server loads, so a session launched
    # from a shell without the export wrote "not_set" into a marker that EVERY
    # session's status line reads — a false ✕ (incorrect_llm_api_key) for sessions whose key is
    # fine. The idle watcher is the sole authority instead: it resolves the key the
    # same way the server does (cognee's get_llm_config) and validates it against
    # the provider, so the verdict matches reality. It runs at session start, so the
    # signal still appears within seconds of launch.

    # The host (Claude) session id is a local correlation key only: it keeps every
    # hook process of this launch resolving the SAME Cognee session id (via the
    # host-keyed map). It is never sent to Cognee as an identity.
    session_candidate, session_source = resolve_session_key_from_payload(payload)
    session_key = set_session_key(session_candidate)
    if not session_key:
        # The mid-bootstrap venv re-exec (_run_heavy) replays this script after
        # stdin was already consumed, so the payload is gone — but the pre-exec
        # run exported COGNEE_SESSION_KEY, which execv preserves.
        session_key = get_session_key()
        if session_key:
            session_source = "env_session_key"
    if not session_key:
        hook_log("missing_payload_session_id", {"cwd": cwd, "payload": payload})
        print(
            "cognee-plugin: missing payload session_id; refusing to register",
            file=sys.stderr,
        )
        return {
            "hookSpecificOutput": {
                "hookEventName": "SessionStart",
                "systemMessage": "Cognee Memory: session key missing in SessionStart payload.",
            }
        }
    os.environ["COGNEE_SESSION_KEY"] = session_key

    # Resolve (and persist) this launch's record: session_id (data scoping, unique
    # per launch) + conn_uuid (liveness handle for registration/counting). Written
    # synchronously here so prompt hooks read back the identical ids before any run.
    # The record also seeds the launch's active dataset (env/default) and stores
    # the host pid + cwd so switch-dataset.py, which runs under the shell tool
    # with no hook payload, can find this launch. A resumed record keeps the
    # dataset it already has — including one chosen by a switch.
    session_id, conn_uuid = ensure_launch_record(
        session_key,
        cwd,
        dataset=str(config.get("dataset", "") or "").strip(),
        host_pid=_find_claude_parent_pid(),
    )
    # The launch record is what the status line and doctor read — neither has
    # this process's environment — so the observer decision lands on it here,
    # once the record exists.
    _record_observer(observer)
    from _project_memory import begin as begin_project_memory

    begin_project_memory(get_dataset(config), session_id, cwd)
    os.environ["COGNEE_SESSION_ID"] = session_id
    agent_session_name = conn_uuid
    dataset = get_dataset(config)
    # Registration and the bootstrap worker read the dataset off config: keep it
    # in step with the record so a resumed, switched launch re-binds correctly.
    config["dataset"] = dataset
    hook_log(
        "session_resolved",
        {
            "source": session_source,
            "session_key": session_key,
            "session_id": session_id,
            "conn_uuid": conn_uuid,
            "dataset": dataset,
        },
    )

    # Boot-vs-connect is decided purely by whether the server is already up:
    #   * up                -> connect (we don't boot, so agent mode is left as-is)
    #   * down + local URL  -> boot it; agent mode is set at the uvicorn spawn so
    #                          the server tears down once all agents disconnect
    #   * down + remote URL -> can't boot a remote host; connect and degrade
    user_id = ""
    agent_api_key = ""
    # An empty target (forced cloud, no URL) must never boot: _is_local_url("")
    # parses to localhost, so gate on the URL being present at all.
    # Local endpoints get the full-evidence presence check (quick form — the
    # boot path re-verifies rigorously before any install), so the recorded
    # decision distinguishes a busy server from an absent one. Remote endpoints
    # keep the plain HTTP probe: there is no local evidence for them, and they
    # are never booted. will_boot means "enter the local bootstrap path" — the
    # actual install/boot license is enforced inside _ensure_local_server_running,
    # so a busy server still gets a worker that waits for it instead of a boot.
    presence_verdict, presence_evidence = "", {}
    if target_url and _is_local_url(target_url):
        presence_verdict, presence_evidence = server_presence(target_url, confirm_absent=False)
        server_live = presence_verdict == PRESENCE_READY
    else:
        server_live = bool(target_url) and _health_ok(_health_url(target_url))
    will_boot = (not server_live) and bool(target_url) and _is_local_url(target_url)
    hook_log(
        "endpoint_mode_selected",
        {
            "base_url": target_url,
            "server_live": server_live,
            "will_boot": will_boot,
            **(
                {"presence": presence_verdict, "evidence": presence_evidence}
                if presence_verdict
                else {}
            ),
        },
    )
    if will_boot and _LAZY_BOOTSTRAP:
        _spawn_bootstrap(config, cwd, session_id, agent_session_name, session_key, dataset)
        user_id = os.environ.get("COGNEE_USER_ID", "")
    else:
        user_id, agent_api_key, ok = await _run_heavy(
            config,
            cwd,
            session_id,
            agent_session_name,
            session_key,
            dataset,
            managed_endpoint=not will_boot,
            boot_timeout=_HEALTH_TIMEOUT_SECONDS,
        )
        if not ok:
            if _LAZY_BOOTSTRAP and target_url and _is_local_url(target_url):
                # Inline attempt failed; retry the heavy path out of band.
                _spawn_bootstrap(config, cwd, session_id, agent_session_name, session_key, dataset)
            else:
                return {}

    # Remove legacy resolved cache files. Runtime state now comes from HTTP endpoints.
    _purge_legacy_resolved_files()
    # Per-session files nothing else deletes (launch records, status markers,
    # bridge caches, pending buffers, dead improve locks) and oversized logs.
    from _plugin_common import sweep_stale_state

    sweep_stale_state()

    # Reset the idle clock for this Claude process before the watcher
    # starts, otherwise a stale timestamp from a prior session can cause
    # an immediate improve on startup.
    touch_activity()

    # Launch the idle watcher (syncs session memory to graph after the agent
    # goes idle). Runs in both local-server and cloud modes — the watcher picks
    # the HTTP or local sync path itself. COGNEE_IDLE_DISABLED opts out.
    if os.environ.get("COGNEE_IDLE_DISABLED", "").lower() not in (
        "1",
        "true",
        "yes",
    ):
        _spawn_idle_watcher(session_id, dataset, user_id, config, session_key)

    _spawn_exit_watcher(
        session_id,
        dataset,
        session_key=session_key,
        agent_session_name=agent_session_name,
        api_key=agent_api_key,
        service_url=str(config.get("base_url", "") or ""),
    )

    mode = "cloud" if config.get("base_url") else "local"
    print(
        f"cognee-plugin: session ready (mode={mode}, "
        f"session={session_id}, dataset={dataset}, user={user_id[:8]}...)",
        file=sys.stderr,
    )

    ready = server_live or server_ready_hint(str(config.get("base_url", "") or ""))
    return _with_observer_note(_session_start_guidance(mode, dataset, session_id, ready), observer)


def main():
    if is_observer_child():
        return
    # First run: leave a commented ~/.cognee/.env template so one-time config
    # has a documented file to land in. Values (if any) were already loaded
    # into os.environ when _plugin_common was imported.
    from _env_file import ensure_env_file_template, env_file_path

    if ensure_env_file_template():
        hook_log("env_file_template_created", {"path": str(env_file_path())})

    # Detached bootstrap mode: run the slow server boot + registration out of
    # band so the SessionStart hook itself returns fast.
    if _BOOTSTRAP_ARG in sys.argv:
        idx = sys.argv.index(_BOOTSTRAP_ARG)
        raw = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else ""
        try:
            bootstrap = json.loads(raw) if raw.strip() else {}
        except json.JSONDecodeError:
            bootstrap = {}
        try:
            asyncio.run(_run_bootstrap(bootstrap))
        except Exception as exc:
            hook_log("bootstrap_main_exception", {"error": str(exc)[:200]})
        return

    payload_raw = sys.stdin.read()
    try:
        payload = json.loads(payload_raw) if payload_raw.strip() else {}
    except json.JSONDecodeError:
        payload = {}

    output = {}
    try:
        with quiet_hook_output("session-start"):
            output = asyncio.run(_start(payload))
    except Exception as exc:
        hook_log("session_start_exception", {"error": str(exc)[:200]})
    output = _apply_memory_preference(output)
    output = _apply_update_nudge(output)
    output = _apply_host_python_warning(output)
    print(json.dumps(output or {}))


if __name__ == "__main__":
    main()
