#!/usr/bin/env python3
"""Cognee Doctor — unified diagnostics for the Claude Code plugin.

Read-only command that aggregates configuration, connectivity, and
circuit-breaker state into a single diagnostic report.

Usage:
    python doctor.py           # human-readable table
    python doctor.py --json    # machine-readable JSON

Never modifies configuration, initialises databases, registers
resources, writes files, or mutates state.
"""

from __future__ import annotations

import json
import os
import pathlib
import subprocess
import sys
import time
import urllib.error
import urllib.request

# Ensure the scripts directory is on sys.path so sibling modules resolve.
_SCRIPTS_DIR = str(pathlib.Path(__file__).resolve().parent)
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)


def _resolve_local_cognee_version() -> str:
    """Cognee version installed in the plugin's managed venv.

    The plugin installs cognee into ~/.cognee-plugin/venv at session start;
    probe that interpreter directly. Returns "Not installed" when the venv is
    absent and "Unknown" if the probe fails.
    """
    from _plugin_common import _VENV_PYTHON

    if not _VENV_PYTHON.exists():
        return "Not installed"
    try:
        probe = "import importlib.metadata as m; print(m.version('cognee'))"
        out = subprocess.run(
            [str(_VENV_PYTHON), "-c", probe],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    return "Unknown"


def _resolve_mode() -> str:
    """Return the resolved operating mode: Local, Local Managed, or Cloud.

    - No base_url configured → Local (or Cloud when the backend switch forces
      cloud — the mode is pinned even though there is nothing to connect to)
    - base_url pointing to localhost / 127.0.0.1 / ::1 → Local Managed
    - Remote base_url → Cloud
    """
    import urllib.parse

    from config import load_config

    cfg = load_config()
    base_url = str(cfg.get("base_url") or "").strip()

    if not base_url:
        return "Cloud" if cfg.get("_forced_backend") == "cloud" else "Local"

    hostname = urllib.parse.urlparse(base_url).hostname or ""
    if hostname in ("localhost", "127.0.0.1", "::1"):
        return "Local Managed"

    return "Cloud"


def _mode_annotation() -> str:
    """Suffix for the mode row when the backend switch forced the decision."""
    from _env_file import forced_backend_with_source
    from config import load_config

    forced, var = forced_backend_with_source()
    if not forced:
        return ""
    note = f" — forced by {var}={forced}"
    if forced == "cloud" and not str(load_config().get("base_url") or "").strip():
        note += " (missing COGNEE_BASE_URL — nothing to connect to)"
    return note


def _resolve_server_url() -> tuple:
    """Return (display_url, raw_url).

    In local mode the display value is "-" (no remote server), but the
    raw_url is still resolved so the health-check can probe localhost.
    Forced cloud with no URL configured has nothing to probe at all.
    """
    from _plugin_common import _local_api_url_with_source
    from config import load_config

    mode = _resolve_mode()
    if mode == "Cloud" and not str(load_config().get("base_url") or "").strip():
        return "-", ""
    url, _source = _local_api_url_with_source()
    display = "-" if mode == "Local" else url
    return display, url


_KEY_SOURCE_LABELS = {
    "plugin_agent_key": "Plugin identity",
    "env_api_key": "ENV",
    "cache_single_key": "Config",
    "missing": "Default",
}


def _resolve_api_key_source() -> str:
    """Return a human-friendly label for where the API key came from."""
    from _env_file import env_file_path, parse_env_file
    from _plugin_common import _api_key_with_source

    key, source = _api_key_with_source()
    label = _KEY_SOURCE_LABELS.get(source, source)
    if source == "env_api_key" and key:
        # The env layer is fed by both real exports and ~/.cognee/.env
        # (setdefault); tell them apart for debuggability.
        file_key = parse_env_file(env_file_path()).get("COGNEE_API_KEY", "")
        if file_key and file_key == key:
            label = "Env file"
    return label


def _resolve_memory_sharing() -> str:
    """How this plugin's memory relates to the user's other agents.

    ``shared (role: cognee-agent)`` when the agent is wired into the shared
    role; otherwise ``separated`` with the reason: the user opted out, the
    plugin runs as the principal (no agent identity — the principal sees
    everything anyway), or the wiring was skipped (older server, not the
    tenant owner, tenant-less install that already owns data).
    """
    from _plugin_common import (
        AGENT_ROLE_NAME,
        active_agent_key,
        load_shared_memory_marker,
        shared_memory_enabled,
    )

    if not shared_memory_enabled():
        return "separated (opt-out)"
    marker = load_shared_memory_marker()
    if not active_agent_key():
        # An install that could not be wired (or whose identity is blocked or
        # bound to another principal) runs as the principal; say why, so "no
        # agent identity" is not mistaken for a broken install.
        reason = str(marker.get("reason") or "").replace("_", " ")
        return (
            f"principal (shared memory unavailable: {reason})"
            if reason
            else ("principal (no agent identity)")
        )
    if marker.get("mode") == "shared":
        return f"shared (role: {AGENT_ROLE_NAME})"
    reason = str(marker.get("reason") or "not wired yet").replace("_", " ")
    return f"separated ({reason})"


def _check_health(server_url: str, timeout: float = 5.0) -> dict:
    """Probe GET /health and return reachability + latency.

    Returns a dict with keys: reachable (bool), latency_ms (float|None),
    and raw_body (dict|None) for downstream consumers.
    """
    base = server_url.rstrip("/") if server_url else ""
    if not base:
        return {"reachable": False, "latency_ms": None, "raw_body": None}
    from _plugin_common import _https_context

    try:
        t0 = time.monotonic()
        with urllib.request.urlopen(
            f"{base}/health", timeout=timeout, context=_https_context()
        ) as resp:
            latency = (time.monotonic() - t0) * 1000  # ms
            body_text = resp.read().decode("utf-8", errors="replace")
            try:
                body = json.loads(body_text)
            except (json.JSONDecodeError, ValueError):
                body = None
            if resp.status == 200:
                return {"reachable": True, "latency_ms": round(latency, 1), "raw_body": body}
        return {"reachable": False, "latency_ms": None, "raw_body": None}
    except (urllib.error.URLError, TimeoutError, OSError):
        return {"reachable": False, "latency_ms": None, "raw_body": None}


def _resolve_server_version(health_body: dict | None) -> str:
    """Extract a server version from the health response, if present."""
    if isinstance(health_body, dict):
        version = health_body.get("version")
        if version and str(version).strip():
            return str(version).strip()
    return "Unknown"


def _resolve_circuit_breaker() -> str:
    """Return a human description of the circuit breaker state."""
    from _cognee_client import breaker_open

    is_open, retry = breaker_open()
    if is_open:
        return f"Open (retry in ~{retry}s)"
    return "Closed"


def _resolve_embedding() -> tuple[str, str]:
    """Embedding model + dimensions from the environment cognee reads.

    cognee resolves embeddings from EMBEDDING_MODEL / EMBEDDING_DIMENSIONS; no
    HTTP endpoint exposes them, so we surface what the local environment sets
    (the values that govern local mode). "Default" means unset — cognee falls
    back to its built-in default.
    """
    model = (os.environ.get("EMBEDDING_MODEL") or "").strip() or "Default"
    dims = (os.environ.get("EMBEDDING_DIMENSIONS") or "").strip() or "Default"
    return model, dims


def _resolve_llm() -> str:
    """Where the local server's LLM calls go: a configured provider key, or the
    Claude observer (Claude Code's own subscription via ``claude -p``).

    Local mode only — a remote server owns its own LLM. Read-only: decides as
    session-start would (``resolve_observer``) and asks the shim's ``/health``;
    it never starts the shim or touches the environment.
    """
    from _observer import observer_alive, resolve_observer
    from config import load_config

    cfg = load_config()
    mode = _resolve_mode()
    if mode == "Cloud":
        return "Remote server (not applicable)"
    try:
        decision = resolve_observer(cfg)
    except Exception as exc:
        return f"Unknown ({str(exc)[:80]})"
    if decision.get("active"):
        from _observer import SPEND_WARNING, embedding_warning

        shim = "shim running" if observer_alive(decision.get("port")) else "shim not running"
        return (
            f"Claude Code observer (`claude -p`, model {decision.get('model')}, "
            f"{decision.get('endpoint')}, {shim}). {SPEND_WARNING} {embedding_warning()}"
            + (f" Warning: {decision['model_warning']}" if decision.get("model_warning") else "")
        )
    if decision.get("error"):
        return f"None — {decision['error']}"
    reason = str(decision.get("reason") or "")
    if reason in ("llm_key_configured", "llm_provider_configured"):
        provider = (os.environ.get("LLM_PROVIDER") or "").strip() or "openai (default)"
        model = (os.environ.get("LLM_MODEL") or "").strip() or "Default"
        return f"Configured provider ({provider}, model {model})"
    if reason == "server_dotenv_configured":
        return f"Configured provider (in the server's {decision.get('dotenv') or '.env'})"
    if reason == "claude_cli_missing":
        return "None — no LLM_API_KEY and no `claude` executable for the observer"
    if reason == "disabled":
        return "None — no LLM_API_KEY; observer disabled (COGNEE_LLM_OBSERVER=false)"
    return "None — no LLM_API_KEY configured"


def _resolve_env_file() -> str:
    """One-time config file (~/.cognee/.env): presence, key names, overrides.

    Values are never shown — only which keys the file defines, and which of
    them are shadowed by a real shell export (exports win over the file).
    """
    from _env_file import env_file_status

    status = env_file_status()
    path = status.get("path", "")
    if not status.get("exists"):
        return f"Not found ({path})"
    keys = status.get("keys") or []
    desc = f"{path} ({len(keys)} key{'s' if len(keys) != 1 else ''}: {', '.join(keys)})"
    overridden = status.get("overridden") or []
    if overridden:
        desc += f" — overridden by shell env: {', '.join(overridden)}"
    return desc


def collect_report() -> dict:
    """Gather all diagnostic fields into an ordered dict."""
    mode = _resolve_mode()
    display_url, raw_url = _resolve_server_url()
    api_key_source = _resolve_api_key_source()
    memory_sharing = _resolve_memory_sharing()
    health = _check_health(raw_url)
    cognee_server = _resolve_server_version(health["raw_body"])
    cognee_local = _resolve_local_cognee_version()
    circuit_breaker = _resolve_circuit_breaker()
    embedding_model, embedding_dimensions = _resolve_embedding()

    return {
        "mode": mode + _mode_annotation(),
        "env_file": _resolve_env_file(),
        "server_url": display_url if display_url != "-" else None,
        "api_key_source": api_key_source,
        "memory_sharing": memory_sharing,
        "reachable": health["reachable"],
        "latency_ms": health["latency_ms"],
        "cognee_local": cognee_local,
        "cognee_server": cognee_server,
        "llm": _resolve_llm(),
        "embedding_model": embedding_model,
        "embedding_dimensions": embedding_dimensions,
        "circuit_breaker": circuit_breaker,
    }


_DISPLAY_ORDER = [
    ("Mode", "mode"),
    ("Env File", "env_file"),
    ("Server URL", "server_url"),
    ("API Key Source", "api_key_source"),
    ("Memory Sharing", "memory_sharing"),
    ("Reachable", "reachable"),
    ("Latency", "latency_ms"),
    ("Cognee (local)", "cognee_local"),
    ("Cognee (server)", "cognee_server"),
    ("LLM", "llm"),
    ("Embedding Model", "embedding_model"),
    ("Embedding Dims", "embedding_dimensions"),
    ("Circuit Breaker", "circuit_breaker"),
]


def _format_value(key: str, value) -> str:
    """Format a single report value for human display."""
    if key == "server_url":
        return str(value) if value else "-"
    if key == "reachable":
        return "Yes" if value else "No"
    if key == "latency_ms":
        if value is None:
            return "N/A"
        return f"{value} ms"
    if value is None:
        return "N/A"
    return str(value)


def format_human(report: dict) -> str:
    """Render the report as a human-readable table."""
    lines = ["", "Cognee Doctor", ""]
    for label, key in _DISPLAY_ORDER:
        value = _format_value(key, report.get(key))
        lines.append(f"{label + ':':<21}{value}")
    lines.append("")
    return "\n".join(lines)


def format_json(report: dict) -> str:
    """Render the report as pretty-printed JSON."""
    return json.dumps(report, indent=2)


def main(argv: list[str] | None = None) -> None:
    args = argv if argv is not None else sys.argv[1:]
    use_json = "--json" in args

    report = collect_report()

    if use_json:
        print(format_json(report))
    else:
        print(format_human(report))


if __name__ == "__main__":
    main()
