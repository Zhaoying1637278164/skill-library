#!/usr/bin/env python3
"""Server-first remember against Cognee's ``/api/v1/remember``.

Standalone, stdlib-only, so it runs under the system ``python3`` without the
plugin venv (the same constraint ``cognee-search.sh`` already works under).

Contract — what gets printed to stdout:
  * ``{"ok": true}`` on a 2xx response.
  * the sentinel ``UNREACHABLE`` ONLY when the server cannot be reached
    (connection refused, timeout, DNS). The caller may then fall back to the
    local CLI as a degraded path.
  * a JSON **error object** ``{"error", "status", "authoritative": false}`` on
    any HTTP error (5xx, 4xx, and especially **401/403** auth rejections). The
    caller MUST NOT fall back to the local CLI here: the server was reachable and
    rejected/failed the request, so falling back could bypass auth boundaries
    or silently double-write to a different backend.

Diagnostics also go to stderr so the caller can surface them.
"""

from __future__ import annotations

import json
import os
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

UNREACHABLE = "UNREACHABLE"


def _multipart_body(fields, files):
    boundary = f"----cogneeRemember{uuid.uuid4().hex}"
    chunks = []
    for name, value in fields.items():
        chunks.append(f"--{boundary}\r\n".encode("utf-8"))
        chunks.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode("utf-8"))
        chunks.append(str(value).encode("utf-8"))
        chunks.append(b"\r\n")
    for field_name, filename, content in files:
        chunks.append(f"--{boundary}\r\n".encode("utf-8"))
        chunks.append(
            (
                f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'
                "Content-Type: text/plain; charset=utf-8\r\n\r\n"
            ).encode("utf-8")
        )
        chunks.append(content if isinstance(content, bytes) else content.encode("utf-8"))
        chunks.append(b"\r\n")
    chunks.append(f"--{boundary}--\r\n".encode("utf-8"))
    return b"".join(chunks), boundary


def _error(status, message):
    """An error envelope — reachable server, but the request was rejected/failed.

    Distinct from UNREACHABLE so the caller does NOT fall back to the local CLI.
    """
    return {"error": message, "status": status, "authoritative": False}


def _background_flag():
    """Whether the server should cognify in the background (default: yes).

    A synchronous cognify (run_in_background=false) can take tens of seconds: it
    blocks the agent's turn and risks the client read-timeout that gets misread as
    "server unreachable" (then a CLI fallback that can double-write). Background lets
    the POST return as soon as the work is enqueued. Set COGNEE_REMEMBER_BACKGROUND=false
    for a synchronous, immediately-queryable write.
    """
    val = os.environ.get("COGNEE_REMEMBER_BACKGROUND", "").strip().lower()
    return "false" if val in {"0", "false", "no", "off"} else "true"


def _timeout_result(timeout):
    """A write timeout is NOT 'unreachable': the request likely reached the server and
    the write may have landed. Returning UNREACHABLE would make the caller re-write via
    the CLI and risk a duplicate, so surface a non-fatal note instead — the caller
    prints it and does NOT fall back. Background writes make this path rare.
    """
    sys.stderr.write(
        "[cognee-remember] timed out after %ss waiting for confirmation; the write may "
        "have succeeded — NOT falling back to local CLI\n" % timeout
    )
    return _error(0, "remember submitted; timed out after %ss waiting for confirmation" % timeout)


def _float_env(name, default):
    try:
        raw = os.environ.get(name, "").strip()
        return float(raw) if raw else default
    except (TypeError, ValueError):
        return default


def _explicit_wait_seconds():
    """Seconds the explicit "remember this" waits for the cognify to become queryable.

    Default 8s: a background submit returns immediately, so without a short wait an
    immediate recall sees the not-yet-cognified graph. 0 disables (fire-and-forget).
    """
    return _float_env("COGNEE_REMEMBER_WAIT_SECONDS", 8.0)


def _poll_status(
    service_url,
    api_key,
    dataset_id,
    deadline_seconds,
    *,
    opener=urllib.request.urlopen,
    interval_seconds=3.0,
    request_timeout=10.0,
):
    """Poll /api/v1/datasets/status (cognify_pipeline) until terminal or the deadline.

    Returns "completed" | "errored" | "timeout" | "unknown". The only cognify
    poller in the plugin: stdlib-only and opener-injectable so this module keeps
    running under bare python3 (no plugin venv) and remains test-mockable.
    """
    if not dataset_id:
        return "unknown"
    url = (
        service_url.rstrip("/")
        + "/api/v1/datasets/status?dataset="
        + urllib.parse.quote(str(dataset_id))
        + "&pipeline=cognify_pipeline"
    )
    headers = {}
    # Always attach the key when present: cognee >=1.2.2 enforces auth even on
    # localhost; a server with auth disabled ignores the header.
    if api_key:
        headers["X-Api-Key"] = api_key
    deadline = time.monotonic() + max(0.0, deadline_seconds)
    while True:
        status = ""
        try:
            req = urllib.request.Request(url, headers=headers, method="GET")
            with opener(req, timeout=request_timeout) as resp:
                raw = resp.read().decode("utf-8")
            parsed = json.loads(raw or "{}")
            if isinstance(parsed, dict) and parsed:
                val = parsed.get(str(dataset_id))
                if val is None and len(parsed) == 1:
                    val = next(iter(parsed.values()))
                if isinstance(val, dict):
                    val = val.get("cognify_pipeline")
                status = str(val or "").upper()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return "unknown"  # older server without the status route
            # transient — fall through to the deadline check
        except Exception:
            pass  # transient (URLError/timeout/parse) — keep polling until deadline
        if status.endswith("COMPLETED"):
            return "completed"
        if status.endswith("ERRORED"):
            return "errored"
        if time.monotonic() >= deadline:
            return "timeout"
        time.sleep(max(0.1, interval_seconds))  # floor avoids a tight spin if misconfigured to 0


def do_remember(
    service_url,
    api_key,
    content,
    dataset,
    node_set,
    *,
    file_path=None,
    dataset_id="",
    opener=urllib.request.urlopen,
    timeout=120.0,
):
    """POST content to the server. Return {"ok": true}, an error envelope, or UNREACHABLE.

    ``dataset_id`` addresses the target by UUID (sent as ``datasetId``, which
    the endpoint accepts in place of ``datasetName``). Under shared agent
    memory that is the canonical parent-owned dataset; by name, an agent would
    silently create and write its own empty copy instead.

    With ``file_path``, the file's bytes are uploaded under its REAL basename
    instead of the synthetic ``{node_set}.txt``. The filename extension is the
    server's loader-routing signal: a ``.py``/``.ts``/... upload rides the
    zero-LLM code-graph route (cognify CODE route, cognee >= 1.5.x), while the
    ``.txt`` rename would silently ingest code as prose through the LLM
    pipeline. Reading the file here (not in the shell) also avoids ARG_MAX
    limits on large sources.
    """
    url = service_url.rstrip("/") + "/api/v1/remember"
    filename = f"{node_set or 'content'}.txt"
    if file_path:
        try:
            with open(file_path, "rb") as fh:
                content = fh.read()
        except OSError as e:
            return _error(0, "cannot read %s: %s" % (file_path, str(e)[:160]))
        filename = os.path.basename(str(file_path).rstrip("/")) or filename
    from _dataset_access import dataset_id as parse_dataset_id

    # The explicit UUID (shared memory's canonical dataset) wins; otherwise a
    # UUID-shaped dataset is sent as datasetId and a name as datasetName.
    ident = str(dataset_id or "").strip() or parse_dataset_id(dataset)
    fields = {"node_set": node_set, "run_in_background": _background_flag()}
    if ident:
        fields["datasetId"] = ident
    else:
        fields["datasetName"] = dataset
    body, boundary = _multipart_body(
        fields,
        [("data", filename, content.encode("utf-8") if isinstance(content, str) else content)],
    )
    headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}
    # Always attach the key when present: cognee >=1.2.2 enforces auth on its
    # API routes even on localhost (the local key is auto-minted at bootstrap),
    # and a server running with auth disabled simply ignores the header.
    if api_key:
        headers["X-Api-Key"] = api_key

    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with opener(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            msg = "unauthorized (HTTP %s) — check COGNEE_API_KEY / credentials" % e.code
        else:
            msg = "server returned HTTP %s for /api/v1/remember" % e.code
        sys.stderr.write("[cognee-remember] %s — NOT falling back to local CLI\n" % msg)
        return _error(e.code, msg)
    except (TimeoutError, socket.timeout):
        return _timeout_result(timeout)
    except urllib.error.URLError as e:
        # A read timeout arrives wrapped in URLError on some platforms — treat it as
        # a timeout, not "unreachable" (the request likely reached the server).
        if isinstance(getattr(e, "reason", None), (TimeoutError, socket.timeout)):
            return _timeout_result(timeout)
        sys.stderr.write(
            "[cognee-remember] server unreachable at %s: %s\n" % (service_url, str(e)[:160])
        )
        return UNREACHABLE
    except Exception as e:
        sys.stderr.write(
            "[cognee-remember] server unreachable at %s: %s\n" % (service_url, str(e)[:160])
        )
        return UNREACHABLE

    # The server responded with 2xx. A body we can't parse is fine —
    # the important thing is the server accepted the request.
    try:
        data = json.loads(raw or "{}")
    except (json.JSONDecodeError, ValueError):
        return {"ok": True}

    if isinstance(data, dict) and data.get("error"):
        msg = str(data.get("error"))[:200]
        sys.stderr.write("[cognee-remember] server returned error: %s\n" % msg)
        return _error(200, msg)

    result = {"ok": True}
    if isinstance(data, dict):
        if data.get("dataset_id"):
            result["dataset_id"] = str(data["dataset_id"])
        if data.get("pipeline_run_id"):
            result["pipeline_run_id"] = str(data["pipeline_run_id"])
        if data.get("status"):
            result["status"] = str(data["status"])

    # A background submit returns as soon as the cognify is enqueued, so the graph
    # isn't queryable yet. Optionally wait (bounded) and report whether it landed,
    # so an immediate recall isn't stale. Synchronous writes already completed.
    wait_seconds = _explicit_wait_seconds()
    if wait_seconds > 0 and result.get("dataset_id") and _background_flag() == "true":
        outcome = _poll_status(
            service_url,
            api_key,
            result["dataset_id"],
            wait_seconds,
            opener=opener,
            interval_seconds=_float_env("COGNEE_COGNIFY_POLL_INTERVAL", 3.0),
            request_timeout=_float_env("COGNEE_STATUS_REQUEST_TIMEOUT", 10.0),
        )
        result["wait_outcome"] = outcome
        result["queryable"] = outcome == "completed"
        if outcome == "errored":
            sys.stderr.write(
                "[cognee-remember] cognify ERRORED for dataset %s\n" % result["dataset_id"]
            )
    return result


def main(argv):
    # argv: service_url, api_key, content, dataset, node_set[, file_path[, dataset_id]]
    # With file_path set (arg 6), content (arg 3) is ignored: the file's bytes
    # are uploaded under their real basename so code files route as code.
    # dataset_id (arg 7) addresses the dataset by UUID instead of the name.
    a = list(argv) + [""] * 7
    result = do_remember(a[0], a[1], a[2], a[3], a[4], file_path=a[5] or None, dataset_id=a[6])
    print(UNREACHABLE if result == UNREACHABLE else json.dumps(result))
    if result != UNREACHABLE:
        # Refresh the status-line credits marker, attributing the spend delta
        # to this remember (cloud-only; the fetch itself no-ops on a local
        # server). Lazy, guarded import: this module is standalone by design,
        # and the opt-out env stops _plugin_common's venv re-exec — an execv
        # here would re-run main() and double-submit the remember.
        try:
            os.environ.setdefault("COGNEE_PLUGIN_IN_VENV", "1")
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from _plugin_common import (
                clear_payment_required,
                record_payment_required,
                refresh_credits,
            )

            # A 402 is the server refusing to pay for this remember; note it
            # for the status line. A remember that got through clears the note.
            if isinstance(result, dict) and result.get("status") == 402:
                record_payment_required("remember")
            elif isinstance(result, dict) and not result.get("error"):
                clear_payment_required()
            refresh_credits("remember")
        except Exception:
            pass


if __name__ == "__main__":
    main(sys.argv[1:])
