# Changelog

All notable changes to the **cognee-memory** Claude Code plugin are documented here.

The version here must match the `version` field in both `.claude-plugin/plugin.json`
and the plugin's entry in the repository-root `.claude-plugin/marketplace.json` — Claude
Code only offers an update when that string changes. Tag releases as
`cognee-memory-vX.Y.Z` (matching the repo's per-plugin tag convention).

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this
project adheres to [Semantic Versioning](https://semver.org/).

## [1.6.1]

### Added
- **Local mode without an LLM key: the Claude observer.** Local mode used to be a
  dead end for anyone without a provider key — the server booted, but every
  cognify/improve call failed. Now, when no `LLM_API_KEY` (and no `LLM_PROVIDER`) is
  configured and the `claude` CLI is on PATH, session start routes the local server's
  LLM calls through Claude Code itself: `_observer.py` points cognee's `custom` provider
  at a loopback OpenAI-compatible shim (`claude-observer.py`, port 8017) and each
  `/v1/chat/completions` becomes one `claude -p --safe-mode --output-format json` run,
  with `--json-schema` carrying cognee's structured-output schemas. Embeddings default
  to a local model (`EMBEDDING_PROVIDER=fastembed`, `BAAI/bge-small-en-v1.5`, installed
  as a venv extra like any other provider) unless an embedder is already configured.
  The decision is made and applied *before* the install/boot so the server inherits it;
  the shim is started detached and retires itself once the cognee server is gone.
  `--safe-mode` keeps the OAuth login but disables hooks/plugins in the child, and every
  hook additionally exits at once under `COGNEE_OBSERVER_CHILD`, so the plugin cannot
  re-enter itself. Surfaced in the SessionStart system message, `doctor.py`'s new `LLM`
  row, and the status line: the idle watcher's key check asks the shim
  (`/v1/observer/probe`) instead of litellm, and a login problem renders as
  `✕ (claude_not_logged_in)` rather than as an incorrect key. Knobs:
  `COGNEE_LLM_OBSERVER` (`auto`|`true`|`false`), `COGNEE_OBSERVER_MODEL` (`haiku`; a
  value that cannot be a model name falls back to it with a warning),
  `COGNEE_OBSERVER_CLAUDE`, `COGNEE_OBSERVER_PORT`, `COGNEE_OBSERVER_CONCURRENCY`,
  `COGNEE_OBSERVER_TIMEOUT`. Setting `LLM_API_KEY` switches back on the next launch;
  cloud mode never uses it. Session start and `doctor.py` warn every time it is in use
  that the calls spend the Claude subscription's usage, and that a dataset is tied to
  its embedder (switch datasets when switching between the observer and a key). A key
  or provider in the `.env` the server itself loads keeps `auto` off. The shim requires
  a bearer token (`~/.cognee-plugin/observer/token`, handed to cognee as its
  `LLM_API_KEY`, created atomically so concurrent session starts agree on it) and
  refuses requests with an `Origin` header; its `claude` child drops only the parent
  session's variables (keeping `CLAUDE_CODE_OAUTH_TOKEN` and
  Bedrock/Vertex settings) plus `ANTHROPIC_API_KEY`. The server pidfile records whether
  the server booted on the observer, so a session joining a running server follows the
  config it actually has.
- **File-scoped context on `Read` (`PreToolUse`).** A new hook, `file-context.py`,
  runs before every `Read` of a source file inside an indexed repository and injects
  what the code graph knows about that file as `additionalContext`: symbols grouped by
  kind with line numbers, cross-file calls, and imports — a map the model gets before
  the territory. Deterministic (`query_facts` filtered to the file; no LLM or embedding
  call), ~100 ms warm against the repo's own dataset, bounded by
  `COGNEE_FILE_CONTEXT_BUDGET` (3 s), and served once per file per session
  (`COGNEE_FILE_CONTEXT_TTL`, 30 min). Never blocks or alters the read. Silent for
  files outside indexed repos, non-code files, sensitive paths (capture deny list), a
  server known down, or an open breaker. `COGNEE_FILE_CONTEXT_SCOPES=code,graph` adds
  up to three knowledge-graph hits about the file (opt-in: it costs a graph search).
  `COGNEE_FILE_CONTEXT=false` turns it off. When the file changed after the repo was
  last indexed, the map carries a note that line numbers may have shifted.

### Changed
- `write_llm_state` accepts an optional `reason` the status line renders in place of
  the default `incorrect_llm_api_key` label.
- `~/.cognee/.env` template documents `COGNEE_LLM_OBSERVER` / `COGNEE_OBSERVER_MODEL`.
- New events: `file_context.{injected,skipped,error}`, `observer.{applied,skipped,
  refused,shim_start_failed,record_failed,error}` (hooks) and
  `observer.{started,stopped,completion,completion_failed,probe,retire,signal,
  handler_exception}` (shim, in `~/.cognee-plugin/observer/observer-events.log`).

## [1.6.0]

### Changed
- **Bundled cognee is 1.6.0** (was 1.5.4; `_PINNED_COGNEE_VERSION`). The shared
  `~/.cognee-plugin/venv` is upgraded on the next local-mode session start, which
  runs that release's migrations. 1.6.0 made `fastembed` and `onnxruntime` core
  dependencies (the `fastembed` and `codegraph` extras are now empty shims), so the
  venv grows and a cold install takes longer. Search and recall now answer an
  unresolvable dataset name, or a dataset without a graph yet, with `404` instead
  of an empty list; the explicit search path (`cognee-search.sh`) treats that as an
  empty result rather than an error, as the prompt hook already did.
- **One recall request per prompt, and the memory block is what the LLM would have
  been given (SDK-741, cognee #5085).** With `only_context=true`, a completion search
  type on cognee 1.6.0 returns one item per dataset whose `text` is the full LLM
  input: the conversation history for the session, the question with the retrieved
  graph context rendered through the retriever's template, and the session guidance
  block (a separate `system_prompt` field carries the task template and is ignored).
  `session-context-lookup.py` therefore no longer fans out over the `session`, `trace`, `session_context` and `graph` scopes: The single request is
  `scope=["graph"]`, `HYBRID_COMPLETION`, `only_context=true`, with the session id —
  kept explicit because the server's `auto` scope would add raw session entries next
  to the prompt (or short-circuit the graph on a session hit) and an unpinned type
  lets the router pick `CHUNKS`, which builds no prompt. The item's `text` is injected
  whole under `=== Cognee memory ===` (label `[cognee-memory]`, formerly
  `[graph-snapshot]`); the 1500-character cap is gone, since the context sits in the
  middle of that string and the guidance at its end, so a cut removed exactly what
  memory is for — `top_k` bounds the size server-side. The header reads `Cognee memory: recall N memory` (plus `/ N code` when the lane is armed); `last_recall.json` keeps all five `hits` keys, the retired ones at zero, and `per_scope` lists only the scopes dispatched. The optional
  code-graph lane is unchanged and still runs only on identifier-shaped prompts.
  Against a pre-1.6.0 server the item holds the bare retrieval context and is
  rendered the same way; the session layers are then not injected.
- **PreCompact anchor is the same memory text.** `pre-compact.py` builds its query
  from the session's recent rows (`GET /api/v1/sessions/{id}`) and makes one graph
  recall; the item's `text` — history, context and guidance — is the anchor, uncapped
  (the 300/400-character cuts are gone). When memory has nothing yet (fresh install,
  graph not built) the recent QA and trace rows stand in, as before. The empty-query
  seed recall, which matched nothing by design, is gone.

- **Automatic improves run at most every 30 minutes** per session (was 10):
  `COGNEE_IMPROVE_COOLDOWN` now defaults to `1800`. The idle and auto triggers honour
  it, and a failed attempt arms the same window as a backoff; the session-end sync,
  the sync skill and a dataset switch still improve regardless.
- **Search is graph and code only.** `cognee-search.sh` no longer has a `--session`
  mode and no longer defaults to session-then-graph; every search is a graph-scope
  recall (or `--code`). The session cache is written and bridged, never searched:
  on cognee 1.6.0 the graph item's prompt already carries this session's history.
- **The "from past sessions" count is gone** from the memory header, the status
  line and `last_recall.json` (`cross_session_hits`). It guessed provenance by
  looking for the session id inside each graph passage; the 1.6.0 memory item is one
  rendered prompt that mixes history, retrieved context and guidance, so no substring
  can say where a fact came from, and memory is graph-only recall now anyway.

### Fixed
- **Fresh installs against cognee 1.6.0 could not mint their owner API key
  (SDK-740).** cognee 1.6.0 stopped baking `default_password` into the default user:
  the server creates that user at startup only when `DEFAULT_USER_PASSWORD` is set,
  sets the password once, and never rewrites a stored one. The owner-key bootstrap
  logs in as `default_user@example.com` / `default_password`, so on a fresh venv the
  login answered `400 "This user does not have a password"` and the plugin never got
  a key. The server this plugin boots is now started with
  `DEFAULT_USER_EMAIL=default_user@example.com` and
  `DEFAULT_USER_PASSWORD=default_password` (the literals every Cognee plugin shares,
  since they all share one server and one database), `setdefault` so an operator's
  own `DEFAULT_USER_*` export wins. Existing installs are untouched: their user row
  already holds that password. `COGNEE_USER_EMAIL`/`COGNEE_USER_PASSWORD` still pick
  the user the plugin logs in as, and a non-default user must already exist. Against
  a server the plugin did not start, the two 400 answers now produce an actionable
  message (start the server with `DEFAULT_USER_PASSWORD` matching
  `COGNEE_USER_PASSWORD`, or set `COGNEE_API_KEY`) instead of the generic "set the
  credentials correctly". README gains a paragraph on where the default user's
  password comes from and what to set for an externally managed server.

## [1.5.7]

### Fixed
- **Every hook was dead on an install whose plugin root contains a space
  ([#5154](https://github.com/topoteretes/cognee/issues/5154)).** The hook commands
  interpolated `${CLAUDE_PLUGIN_ROOT}` unquoted. Hook commands run through a shell, so
  a root with a space word-split and the interpreter died on a truncated filename —
  `can't open file '/Users/<you>/Library/Application'`. The `|| python` fallback added
  for Windows did not help: both halves split on the same space. The plugin root is not
  ours to choose, it follows the host's config home, and the managed defaults contain a
  space on both platforms (`/Library/Application Support/Claude/org-plugins`,
  `%ProgramFiles%\Claude\org-plugins`), so managed Windows installs were affected
  too — this was never Mac-specific. `PreCompact` was the only event loud enough to
  notice, exiting non-zero so Claude Code refused to compact; the rest are async or
  non-blocking and failed silently, which meant memory capture and recall simply
  stopped with nothing to indicate why. All 20 references are now quoted.
- **The skills and the agent handed the model commands that broke the same way.** The
  37 `${CLAUDE_PLUGIN_ROOT}/scripts/...` invocations across the skills, the recall
  agent and the README are run by the model in Bash, so on such a root none of them
  could start — including the cross-dataset search the prompt hook suggests on every
  answered prompt, which is built at run time from the resolved script path. Quoted
  throughout.

## [1.5.6]

### Added
- **The status bar says when credits are not enough, and where to top up.** Until now a
  cloud tenant that ran out of credits saw nothing: every recall, save and improve came
  back `HTTP 402 Payment Required`, the plugin logged it as a generic `recall_error` and
  moved on, and the credits segment kept showing the last balance it had read — or
  nothing at all on a tenant whose billing overview could not be fetched. Now a 402 from
  any billable route (recall, trace/answer save, `/remember`, improve) is recorded on the
  tenant's credits marker as `payment_required: {op, at}`, and the segment renders it:
  - balance above a dollar but refused: `credits: $2.04 (not enough for recall)` — the
    number stays green, only the refusal is red;
  - a dollar or less left: the whole `credits: $0.61` turns red, followed by a green
    `top up: https://platform.cognee.ai/billing` — the cloud refuses requests before the
    balance reaches zero, so the threshold is a dollar, not zero;
  - refused with no balance reading at all (the platform fetch itself failed): the red
    `credits: not enough for recall`, with the top-up link.

  The top-up link is the production billing page; staging and dev sessions set
  `COGNEE_BILLING_URL` (the web frontend's host is not derivable from the tenant host).
  The platform API host the balance is fetched from IS derived from the service URL:
  beside a `tenant-<id>.<env>.cognee.ai` data plane it is `api.<env>.cognee.ai`, so a dev
  tenant asks the dev platform instead of production (which answered `401` and left the
  segment blank). A non-tenant URL falls back to the production platform;
  `COGNEE_PLATFORM_API_URL` overrides.

  The next billable operation that succeeds clears the note, so a top-up shows through
  on the following prompt. The note is written under the same per-tenant lock as the
  balance and survives the balance refresh: a small positive balance can still be "not
  enough", and only a successful operation knows otherwise. New events:
  `credits_payment_required`, `credits_payment_cleared`, `credits_marker_write_failed`.
  The link is a plain URL rather than an OSC 8 hyperlink escape — terminals linkify it
  themselves, and the host's status line is not known to pass hyperlink escapes through.
- **Search another dataset without switching.** Recall reads only the active dataset,
  so information living in another dataset was invisible unless the user switched —
  a full switch (sync, new Cognee session, repointed launch record) just to look
  something up. Now, on every prompt the server answers, the recall hook appends an
  `Other Cognee datasets you can search` block to the injected context: every other
  dataset the identity can read (read-only ones included), with UUIDs, plus the
  command to search one. It rides along on hits too: graph retrieval is
  nearest-neighbour and returns something from any populated dataset, so "zero
  hits" never happens and only the model can tell whether the recalled context
  answers the user. If the user is recalling something the active dataset did not
  have, Claude offers those datasets with a picker; the chosen one gets a one-off
  **graph-only** search and the answer names its source dataset. The active dataset,
  session and write target are untouched. The same flow is spelled out in the
  `cognee-search` skill and the `cognee-recall` agent (which no longer claims to span all datasets) for when an explicit search comes back empty.
  - `scripts/list-datasets.py [--others]` lists every readable dataset (JSON) with
    the active one marked (`switch-dataset.py --list` still shows only switch
    targets). `list_readable_datasets` is the shared listing both build on.
  - `cognee-search.sh --dataset-id <uuid>` addresses a dataset by UUID (a name only
    resolves among owned datasets). Any dataset other than the active one is forced
    to graph scope with the session id dropped — session history is bound to the
    active dataset — with a note on stderr; the active dataset named by hand keeps
    the full scope.
  - The hint's listing comes from a per-plugin cache
    (`~/.cognee-plugin/claude-code/readable-datasets.json`, keyed by server and identity)
    refreshed at most every `COGNEE_DATASETS_CACHE_TTL` seconds (default 300) and
    only inside what remains of the recall budget, so the prompt path never waits on
    it. `COGNEE_RECALL_DATASET_HINT=off` disables the hint. Every other readable
    dataset is named — nothing ranks them, so the user chooses.
  - New hook events: `recall.dataset_hint`, `datasets.readable_refresh_failed`,
    `datasets.list_failed`.

### Removed
- **The `· switched` status-line tag.** After `/cognee-switch-datasets` the bar appended
  a faint `· switched` after the mode. The dataset name beside it already says which
  dataset the session is on, so the tag added nothing, cluttered the line, and read
  as a state that wanted acting on. Gone; the launch record still carries
  `switched_at` for the hooks.

### Fixed
- **Repo indexing submitted the repository under a field the server had stopped
  reading, so every index 400'd ([#420](https://github.com/topoteretes/cognee-integrations/issues/420)).**
  cognee 1.5.4 renamed the form field that carries the repository spec on
  `POST /api/v1/remember` with `content_type=code` from `repositories` to
  `raw_data`. The plugin still sent the old name, and an unrecognised multipart part is
  dropped by the server rather than refused — so each request arrived naming no
  repository at all and came back `HTTP 400: content_type='code' requires at least
  one repository path or git URL in 'raw_data'`. Local paths and git URLs failed
  alike. The spec now goes in `raw_data`. The bundled server has been pinned to 1.5.4
  since the previous release, so a fresh install hit this on its first
  `/cognee-code`.
- **A 400 the server could explain was reported as "your server is too old".** The
  error branch treated any 400 whose body mentioned `content_type` as a server
  predating `content_type='code'`. Every 400 the server's code branch raises names
  that field — including the one above — so the actionable message was overwritten
  with advice to upgrade a deployment that was already new enough, and the reporter
  of #420 spent the session chasing the wrong problem. Only the server's own
  "Unsupported content_type" wording counts as a version problem now; every other
  400 is passed through verbatim.

## [1.5.5]

### Fixed
- **The recall header no longer reports buffered writes as saved (SDK-467).** While
  the server was unreachable for two and a half weeks, every prompt's header kept
  reading `saved last turn 1 prompt / 6 trace / 1 answer` — the store hooks
  diverted every trace and answer to the warmup buffer and bumped the same save
  counter as a real write, so a durable outage produced no visible signal at all.
  Buffered writes now have their own counter kinds (`trace_buffered`,
  `answer_buffered`) and the header shows them as their own segment, followed by
  what still waits for replay across every session on the machine and how long
  the oldest entry has waited:

  ```
  Cognee memory: recall 0 session / 0 trace / 0 graph / 0 agent; saved last turn 1 prompt / 0 trace / 0 answer; buffered last turn 6 trace / 1 answer (not saved yet); 7 awaiting replay, oldest 20d
  ```

  Nothing is added when nothing was buffered and nothing awaits
  replay, so the healthy header reads exactly as before. To make the age
  visible, every buffered entry now carries a `_buffered_at` stamp in
  `~/.cognee-plugin/claude-code/bridge/`; like the ambiguous-replay marker it is
  stripped before the entry is sent, so nothing new reaches the server. Entries
  buffered before this release take their file's mtime, a lower bound on their age.
- **A prompt whose recall is skipped because the server is known bad now gets a
  header too.** It used to return nothing — no header, no sign that memory was
  off — and because the save counter was only read on a successful recall, the
  first header after recovery presented weeks of buffered writes as one turn's
  saves. The header now reads `Cognee memory: recall skipped (server unreachable)`
  (or `auth failed` / `server error` / `server not responding`), followed by the saved,
  buffered and awaiting-replay segments, and the counter is read and reset on
  every prompt. The model receives the same line as its context.
- **`cognee-plugin metrics` reports buffered writes apart from saves.** The
  offline rollup added warmup-buffered writes to the saved totals and ignored the
  after-error buffering entirely. It now has a `buffered` section (`trace` /
  `answer`) fed by `store_buffered_warming`, `trace_buffered_after_error` and
  `store_buffered_after_error`, and `saves` counts only what the server received.
- **The recommended "server-first" `curl` 401'd in local mode, which read as a
  server fault (SDK-622).** `cognee-search`'s category-filter and
  ground-truth examples sent `-H "X-Api-Key: ${COGNEE_API_KEY:-}"`, but in local
  mode that variable is empty: the key is minted into
  `~/.cognee-plugin/api_key.json` and never exported to the shell. The
  authoritative path therefore failed with a misleading 401, and the skill's own
  rule then sent the agent to the `cognee-cli` fallback. Both forms now resolve
  credentials with `eval "$(scripts/cognee-forget.sh env)"` in the same shell
  invocation, and the skill states that a `401` without the resolver proves
  nothing.
- **`cognee-cli` fallbacks read as an equal alternative.** `cognee-search` and
  `cognee-remember` now carry the same explicit rules block: the server is first
  in both modes, and the CLI is a last resort reachable only on a machine holding
  a cognee **source checkout** (in cloud mode the plugin's venv is never built at
  all). A missing CLI is documented as "not a Cognee fault to report" — say the
  server is unreachable and show `scripts/cognee-doctor.sh` instead, and never
  report a write as saved when neither path persisted it.
- **`cognee-switch-datasets` pointed at a slash command that does not exist.**
  Error code 2 told the agent to run `/cognee-memory:cognee-doctor`; the plugin
  ships no doctor skill. It now names `scripts/cognee-doctor.sh` — as
  `cognee-forget` already did — and mentions `--session-key <host session id>`
  for directories shared by several launches.
- **A local server's redirect broke every by-name dataset switch (SDK-622).**
  `switch-dataset.py` failed with a bare `307` for any dataset named rather than
  addressed by UUID, so the dataset picker could not switch at all. Real Cognee
  servers disagree about the trailing slash on `/api/v1/datasets` and answer 307
  to the spelling they do not serve — in **opposite** directions: cloud tenants
  redirect the bare path to the slashed one, a local server redirects the slashed
  path to the bare one. The clients hard-coded the slash for the cloud's benefit,
  and urllib's `HTTPRedirectHandler` refuses to replay a POST across a 307 (it
  raises `HTTPError` instead), so the create surfaced as a 307 the caller treated
  as a failure. Because `ensure_dataset_ready_via_api` runs unconditionally on the
  by-name path, an *existing* dataset failed exactly like a new one.

  Both HTTP helpers (`_json_http_request` and `config._cloud_http_request`) now
  replay a 307/308 themselves, preserving method and body, so either spelling
  works against either server shape. The replay is **same-origin only** — these
  requests carry `X-Api-Key`, which must never be sent to another host — and
  bounded to two hops, so a redirect loop cannot spin a hook. A cross-origin
  target, a missing `Location`, or any other status leaves the original error
  untouched. The two `# trailing slash on purpose` workarounds are gone.

  The suite missed this because the mock server accepted both spellings
  unconditionally. It can now redirect either way
  (`set_collection_redirect`), and the regression tests assert dataset creation
  through both helpers in both directions, plus the same-origin gate and the
  refusals.

## [1.5.4]

### Fixed
- **Hotfix: the hooks run on Python 3.9 again (SDK-617).** Every hook script
  failed at import time under a 3.9 `python3` — the one macOS ships with the
  Xcode Command Line Tools — with `TypeError: unsupported operand type(s) for |`,
  because `X | None` annotations are evaluated when a function is defined.
  Nothing in the hooks needs 3.10 at runtime: they are stdlib HTTP clients, and
  cognee runs in the uv-managed Python 3.12 venv the bootstrap builds. Every
  script now carries `from __future__ import annotations`, so the plugin works
  on any Python 3.9+ host; the shared suite runs on 3.9 in CI to keep it that
  way. Shipped in place, without a version bump.
- **The uv-less install fallback refuses a host python older than 3.10.** When
  uv is unavailable and cannot be downloaded, the bootstrap builds the runtime
  venv from the host interpreter, which then inherits cognee's 3.10+ floor.
  Instead of building a venv cognee cannot install into, it now logs
  `host_python_too_old_for_venv` to `~/.cognee-plugin/claude-code/hook.log`, prints the interpreter path and
  version to stderr, and leaves a marker that every following SessionStart turns
  into a systemMessage naming the fix (install uv or a 3.10+ python3) until a
  venv is built. README states the requirement up front: 3.9+ for the hooks,
  3.10+ only for that fallback.

### Changed
- **Per-prompt recall dispatches every scope at once.** The scopes (`session`,
  `trace`, `session_context`, `graph`, plus the `code` lane when it is armed)
  were requested one after another, so every cheap scope was a full round trip
  on top of the graph search — three of them against a cloud server — and an
  armed code lane could burn seconds before graph even started. All scopes are
  now in flight together and the prompt waits for the slowest one, not the sum;
  the results are folded into the same injected context, in the same order.
  With the graph search the only expensive call, a prompt's recall now costs
  about what the graph search alone costs.
  - The per-prompt recall now has one knob: `COGNEE_RECALL_BUDGET` (default
    12s) is the deadline every scope gets. With the scopes concurrent, a
    per-scope timeout and a whole-recall budget bounded the same interval, so
    `COGNEE_RECALL_TIMEOUT` is no longer read by this hook (it still bounds the
    explicit `cognee-search` path). `recall_budget_exceeded` fires only when
    the budget is too small for any request at all.
  - A refused connection or a 401/403 no longer cuts the fan-out short (every
    request is already in flight and fails in the same round trip); it is still
    recorded as one verdict per prompt, never one per scope.
  - `per_scope` in the `context_lookup_*` events keeps its canonical order and
    per-scope `elapsed_ms`, which now overlap rather than add up.

- **No background credits polling.** The exit watcher polled the billing
  overview every 5 minutes for the life of every open terminal so the
  status-line balance would not age out of its 15-minute TTL while idle. That
  was the plugin's only idle network traffic, and its throttle read a marker
  field that does not exist until a refresh has succeeded for the connected
  tenant — with no tenant binding (self-hosted remote server, unresolved
  connection lookup) it fell through to a refresh attempt every 2 seconds and
  ~14k `credits_refresh_skipped_no_tenant` log lines a day. The balance cannot
  move from this machine while it is idle, so the poll is gone: the hook-time
  refreshes (prompt start, turn end, remember, improve) are the whole cadence.
  The renderer no longer hides an old reading; past 15 minutes it appends an
  age hint (`credits: $14.23 (2h ago)`), and hides only once the entry is
  older than the marker's own 7-day prune. `COGNEE_CREDITS_CHECK_INTERVAL` and
  the `exit-watcher:credits_check_error` event are retired.

## [1.5.3]

### Fixed
- **One improve per trigger, and no improve at all on the idle watcher's way
  out.** Three things multiplied improve submits — and every submit is
  recorded by the server as an improve operation, whether or not it did any
  work:
  - The idle watcher ran a last "shutdown" improve when it was stopped by the
    SessionEnd hook, whenever anything had happened since its previous improve
    (after a Stop hook: always). The SessionEnd sync that stops it spawns the
    session's final improve itself, and the exit watcher spawns the same worker
    when the host dies without a SessionEnd, so the flush only ever collided
    with the final sync. Removed; `shutdown_trigger` / `shutdown_bridge_*` events
    are gone.
  - A busy answer from the server (its per-session improve lock held by another
    run) was re-submitted every 15 s for up to ten minutes, and the final sync
    then retried that whole loop three times. In one local log that was 13,915
    busy re-submits against 1,819 real improves, and one session accumulated
    ~640 submits over three days with no successful bridge. Repeated and
    parallel improves are safe server-side — every stage is guarded by a
    per-session watermark or dedups by content hash — so waiting on the lock
    bought nothing: the in-flight run persists everything above the watermark
    and the next trigger covers the rest. A busy answer is now reported and
    left alone. The final sync logs it as `sync_bridge_deferred_busy` and no
    longer counts it as incomplete, so its strict retries fire only for
    transport failures, timed-out submits and undelivered warmup entries.
    `COGNEE_IMPROVE_BUSY_DEADLINE` and `COGNEE_IMPROVE_BUSY_RETRY_INTERVAL` are
    gone.
  - The plugin's own machine-wide per-session improve lock (`improve-locks/`),
    which existed only to pre-empt that busy loop, is removed with it; the
    `improve_lock_*` / `improve_skipped_concurrent` events are gone and the
    state sweep removes the leftover directory.
- **A failed improve now arms the cooldown too.** Only a success used to write
  the per-session improve state, so a server that was busy, slow or down was
  re-submitted after every 60-second pause. Any attempt that does not land
  (busy, timed out, unreachable, HTTP error) stamps `last_failed_at`, and the
  idle/auto triggers honour it as a `backoff` for `COGNEE_IMPROVE_COOLDOWN`
  seconds. The session-end, manual and dataset-switch syncs still always run.

- **A failed idle improve no longer disables the watcher for the rest of the
  session.** The idle watcher used to set a process-local flag after one
  failed attempt and keep polling without ever improving again, while its
  liveness stopped the next prompt from respawning it. It now exits after one
  attempt, landed or not (`bridge_done` / `bridge_failed`), so the next prompt
  respawns it and the failure backoff decides when it tries again.
  `bridge_disabled_after_failure` is gone.

### Changed
- **Pipeline-status polling after an improve submit is gone.** It was
  observability only (it never changed the outcome) and cost one
  `GET /datasets/status` every 3 s for up to ten minutes per improve.
  `COGNEE_IMPROVE_POLL_DEADLINE` and `_plugin_common.wait_for_cognify` are
  removed; the remember path keeps its own bounded poll.
- **One default for the improve submit timeout.** `COGNEE_IMPROVE_SUBMIT_TIMEOUT`
  now has a single source of truth (`IMPROVE_SUBMIT_TIMEOUT_DEFAULT_SECONDS`,
  420 s) instead of an import-time environment default, a function fallback and
  a README value that disagreed.
- `run_session_improve` is replaced by `run_session_improve_detailed`, which
  returns `{"ok", "reason", "error"}` with `reason` one of `busy`,
  `unreachable`, `incomplete_drain` or `failed`, so callers can tell "someone
  else is bridging" from "nothing was bridged".

## [1.5.2]

### Changed
- **Per-prompt recall waits long enough for growing graphs.** The defaults
  for `COGNEE_RECALL_TIMEOUT` (per scope) and `COGNEE_RECALL_BUDGET` (whole
  hook) go from 2.5s/4s to 10s/12s. Graph search time grows with the dataset
  and with the round trip to a remote (cloud) server, and a scope that
  overruns its timeout is recorded as zero hits, so the old caps could
  silently drop graph memory from recall once a graph got large.
  Both values remain overridable via the environment or `~/.cognee/.env`. The
  cheap scopes are unaffected, so a fast prompt is not slower; only a slow
  graph query is now allowed to complete instead of being discarded.

## [1.5.1]

### Removed
- **The in-process "local SDK" execution path is gone.** Every hook is now an
  HTTP client to the Cognee server (the one the plugin boots on localhost, or a
  remote one via `COGNEE_BASE_URL`); no hook imports `cognee` any more. The
  path had been unreachable for the per-prompt hooks since endpoint resolution
  started defaulting to the local server URL, but two places still executed
  cognee in-process against the local server's own database files from a
  second process: PreCompact ran the unbounded SDK `setup()` and read the
  session cache through the session manager, and the empty-recall
  embedding-dimension probe opened the local LanceDB directly. Deleted:
  `config.ensure_identity` / `_ensure_identity_via_sdk` /
  `_ensure_local_databases` / `ensure_dataset_ready` /
  `improve_session_local` / `is_local_mode`, `_plugin_common.resolve_user`,
  `sync_lock`, the embedding-dimension probe
  (`bounded_dim_mismatch_hint` and helpers), the `local_sdk` runtime mode,
  and the SDK branches in `store-to-session`, `store-user-prompt`,
  `session-context-lookup`, `session-start`, `idle-watcher`,
  `sync-session-to-graph` and `pre-compact`. Their log events
  (`resolve_user_failed`, `trace_fallback_*`, `sync_lock_*`,
  `precompact_direct_fetch_error`, `precompact_*_dump_failed`,
  `prompt_prepare_warning`, `context_lookup_dim_mismatch`,
  `dim_check_error`, `improve_local_unsupported`,
  `default_user_resolve_failed`, `bridge_skipped_lock_busy`,
  `sync_lock_import_error`, `sync_skipped_lock_busy`) are retired.

### Changed
- **PreCompact builds its anchor over HTTP.** It now resolves the endpoint like
  every other hook (`resolve_runtime_mode`), recalls through `/api/v1/recall`,
  and, when the empty-query seed recall returns nothing, reads the recent QA
  and trace rows from `GET /api/v1/sessions/{id}` instead of the in-process
  session manager. Against a remote server this is the first time the anchor
  is produced at all: the old direct read only worked when the plugin had
  booted the server under the same HOME. New events:
  `precompact_server_unusable` (skipped because the server is known down),
  `auto_improve_skipped_no_auth`, `sync_skipped_no_auth` and
  `idle-watcher:bridge_skipped_no_auth` (an improve had no server credentials
  to submit with; previously these fell through to the local SDK path).

## [1.5.0]

### Added
- **Plugin identity: the plugin can now run as its own cognee agent sub-user.**
  Cognee servers that expose `POST /api/v1/integrations/plugins/claude-code/provision`
  mint a dedicated agent identity (sub-user + labeled API key) per plugin, so the
  dashboard attributes sessions, traces, and datasets to *this plugin* instead of
  the shared principal key. The provisioned key is cached per service URL at
  `~/.cognee-plugin/claude-code/agent_key.json` and outranks the env/cached
  principal for data-plane traffic; datasets the agent creates are auto-shared
  to the parent user.
  - **Identity policy is `COGNEE_PLUGIN_IDENTITY` = `auto` (default) / `true` /
    `false`.** `auto` provisions only in service of shared agent memory (below) and
    reverts to the principal when that cannot be wired, so nothing the principal
    owns is ever stranded; `true` is explicit and strict — provisioning is required
    and never falls back to the owner; `false` runs as the principal and ignores a
    cached identity.
  - **Safe create-only provisioning, credentials bound to server and principal.**
    Provisioning uses the SDK's `create_only` contract and never rotates an existing
    key; a credential the server rejected is blocked and never reused, and one bound
    to another principal is never used. Under `true` those stop with an error; under
    `auto` the plugin runs as the principal and logs why. Local startup is serialized
    with an OS lock; credential files are written atomically with owner-only
    permissions. Servers without `create_only` (or the provision endpoint) leave
    `auto` installs on the principal.
  - `cognee-doctor` reports the new key source as **Plugin identity**.
- **Shared agent memory (default): one memory across all of your plugin
  agents.** A plugin identity is its own user, and cognee's grants flow
  child→parent only — left alone, per-plugin identities would silo memory
  (Claude Code could not recall what Codex stored). Session start now wires
  the agent into a shared `cognee-agent` role in your tenant (created for a
  tenant-less fresh install) with read+write on your datasets, backfilled on
  every launch and every ~60s by the idle watcher so a dataset another plugin
  creates shows up without a restart. The launch's dataset becomes a
  canonical, user-owned dataset addressed by UUID (`dataset_id`/`dataset_ids`
  on the launch record) — a name only resolves among datasets the caller owns,
  which would fork an empty per-agent copy — and recall, remember, the
  session-entry store, improve and the skills all address it that way;
  pre-existing same-named copies stay in the recall set.
  - **Opt out** with `"shared_agent_memory": false` in config.json or
    `COGNEE_SHARED_AGENT_MEMORY=false` for separated, per-plugin memory (the
    previous behaviour, name-addressed). The agent is removed from the
    shared role — it can no longer read or write your datasets — keeps its
    identity, and starts writing to its own, private dataset; what it shared
    before stays in your user's dataset (still yours, still visible in the
    dashboard). Re-enabling puts it back into the same role and dataset.
  - Degrades to separated memory — never fails a session — when the server
    has no permissions API or cannot store session entries by dataset UUID,
    when you are not the owner of your tenant, or when a tenant-less user
    already owns datasets (activating a tenant would hide them). Under
    `auto` an install that hits one of those stays on the principal.
  - Every tenant/role/grant call runs as the *principal*: an agent key can
    never widen its own access (server-enforced, owner-only).
  - `cognee-doctor` shows **Memory Sharing** (`shared (role: cognee-agent)` /
    `separated (<reason>)` / `principal (...)`).
- **Dataset UUIDs throughout registration, remember, improve, recall, and
  switching.** A UUID-shaped dataset is addressed as an id; effective write
  permissions (not ownership alone) determine the datasets you can switch to,
  and a failed switch persistence keeps the previous session and unregisters
  the unused new connection.
- **Explicit graph read datasets** through `COGNEE_PLUGIN_READ_DATASET_IDS`
  (a JSON array of UUIDs): federated graph recall separate from the session's
  single write dataset; it takes precedence over the datasets shared memory
  resolved.

### Changed
- Native plugin connection types replace the generic API type.
- Identity provisioning requires `COGNEE_PLUGIN_IDENTITY=true` in `~/.cognee/.env`.
  `false` explicitly disables cached identities; there is no config.json setting.
- Safe identity provisioning requires an SDK exposing the `create_only` parameter.

## [1.4.4]

### Fixed
- **The improve cooldown now actually works.** `COGNEE_IMPROVE_COOLDOWN` (600 s)
  was kept as a variable inside the idle-watcher process, and that process
  exits after every bridge and is respawned on the next prompt with the
  variable reset to zero — so since 2026-05-07 the cooldown gated nothing and
  a server-side improve ran after essentially every prompt followed by a
  minute of quiet (one real log: 62 improves on a single session). The last
  successful improve is now recorded per session on disk
  (`~/.cognee-plugin/claude-code/improve-state/<sha1(session)>.json`, written by the improve functions
  themselves on a confirmed submit), and both automatic triggers — the idle
  watcher and the every-`COGNEE_AUTO_IMPROVE_EVERY`-entries fire — consult it:
  no automatic improve runs inside the cooldown, and none runs at all until a
  new prompt, tool call or answer has been stored since the last one. A
  throttled watcher keeps polling instead of exiting, so a quiet stretch that
  outlasts the cooldown still gets exactly one bridge. The session-end final
  sync, `/cognee-memory:cognee-sync` and the dataset-switch sync always run.
- `COGNEE_AUTO_IMPROVE_EVERY=0` now disables the every-N trigger, as the
  README always claimed; it used to fall back to the default of 150.
- The watcher's shutdown bridge (SIGTERM from the SessionEnd sync) now runs
  only when activity is newer than the last recorded improve, instead of
  always — it used to double the final sync.

### Removed
- **The legacy full-document bridges.** Any 404/405/422 from
  `/api/v1/improve` used to mark the server "improve-unsupported" for 24 hours
  and switch every sync to re-posting the whole accumulated session — every
  prompt, answer and raw tool output — through `/remember` for a complete
  re-cognify, per sync. The local-SDK path had a sibling fallback on
  `TypeError`. Both are gone, along with the `improve-unsupported.json`
  marker, the per-session qa/trace text mirror in the bridge buffer, and the
  `COGNEE_BRIDGE_POLL_DEADLINE` / `COGNEE_BRIDGE_SUBMIT_TIMEOUT` knobs. A
  server without session-aware improve is now logged as `improve_unsupported`
  and the session is reported as not synced.

## [1.4.3]

### Fixed
- **Local mode: configured backend providers now get their drivers installed
  (#232).** The self-managed install ran a bare `cognee==<pin>`, which carries
  no Postgres/Neo4j/Ollama/fastembed drivers, so pointing the plugin at any
  non-default backend (`DB_PROVIDER=postgres`, `VECTOR_DB_PROVIDER=pgvector`,
  `GRAPH_DATABASE_PROVIDER=neo4j`, `EMBEDDING_PROVIDER=fastembed`,
  `LLM_PROVIDER=ollama`) crashed the spawned server on its first use of that
  backend. The install now detects the configured providers from the same env
  vars cognee's own config classes read — exports and `~/.cognee/.env` alike —
  and installs exactly the matching cognee extras. Continues @GrowDev1's work
  in #271.
- **A backend configured after the venv was built no longer stays broken.**
  The at-pin install skip checked only the cognee version, so the drivers for
  a provider configured later never arrived — the pin was satisfied and the
  install never re-ran. The skip now also probes the venv for the required
  drivers and falls through to the install only when one is missing; a bare
  install done by another plugin sharing the venv can no longer strand a
  configured backend either.

### Changed
- The `~/.cognee/.env` template now lists the backend provider variables, so a
  local Postgres/Neo4j/Ollama/fastembed setup is discoverable in the same file
  that already holds the LLM key.

## [1.4.2]

### Fixed
- **Recall no longer reports an error for a graph that simply doesn't exist yet.**
  A dataset nobody has cognified yet has no graph, and the server answers the
  graph recall scope with 404 until the first sync lands — on a fresh install
  that is every prompt of the first session. That expected answer was logged as
  `recall_error` and counted against connection health alongside real failures.
  It is now logged as `recall_graph_not_built` (debug, not error) and kept out
  of the health accounting, so genuine failures stay visible.
- **The pending-prompt buffer no longer leaves an empty file behind per session.**
  Consuming the last buffered prompt wrote `{}` back instead of removing the
  file, so `pending/` collected one 2-byte husk per session forever. The buffer
  file is now deleted when its last entry is consumed, and the session-start
  sweep clears the husks older versions already left.
- **Cloud: creating a dataset through the API no longer fails on a redirect.**
  Cloud tenants answer `POST /api/v1/datasets` with a 307 to the trailing-slash
  path, and the stdlib HTTP client will not replay a POST body across a 307, so
  ensuring the target dataset (setup, and switching datasets mid-session) failed
  against cloud with a redirect status. The client now posts to
  `/api/v1/datasets/` directly.
- **Status line: a stale red ✕ now heals itself while you are idle.** Recovery
  from a recorded failure verdict (`unreachable`, `server_error`,
  `not_responding`, `auth_failed`) was prompt-driven: nothing re-checked the
  shared marker until a hook ran, so a server that came back while the terminal
  sat idle kept a red glyph on the bar for up to the 30-minute fade — long
  enough to tempt a needless restart. The session-long exit watcher now
  re-probes about once a minute (`COGNEE_CONN_REPROBE_INTERVAL`) while, and
  only while, the marker holds a failure state for this session's own
  `base_url`, and writes `ready` on success. Only a positive verdict is ever
  written — timeouts stay no-verdict, so this can clear a wrong red but never
  paint one — and `auth_failed` clears only on an authenticated success, since
  `/health` answering 200 says nothing about the key.

## [1.4.1]

### Changed
- **Status line: memory hits in plain words, plus a per-session total.** The
  `recall 4s/5t/0g/1a · saved 2p/41t/2a` strip is replaced by
  `5 memory hits · 12/40 turns had hits this session` — how many memories this
  turn's lookup injected — with `(3 from past sessions)` for the graph passages
  that came from an earlier session or a remembered document, i.e. what this
  conversation alone could not have supplied — then (faint) on how many of this
  session's prompts memory fired at all. A session with no hit yet reads `memory warming up
  (7 turns)` rather than `0/7`. The running total is accumulated by
  `session-context-lookup.py` in the per-session marker
  (`recall/<session>.json`, `session_totals`), so it costs no extra call, resets
  on `/clear` and continues across `--resume`. `COGNEE_STATUSLINE_COUNTS=full`
  restores the per-scope diagnostic strip; `false` still hides the segment.

## [1.4.0]

### Added
- **Switch datasets mid-session: `/cognee-memory:cognee-switch-datasets`.** Lists the
  datasets you can write to (owned by the principal behind your API key — `GET
  /api/v1/datasets` returns everything readable, so read-only ones are filtered out
  and counted), lets you pick one, and moves the launch: the current session is
  synced into its dataset first (`sync-session-to-graph.py --strict`; the switch
  aborts if that fails, `--force` to proceed anyway), a **new** Cognee session is
  registered on the target dataset under a fresh connection handle, and only then
  is the old handle released — so a local agent-mode server never drops to zero
  connections. Backed by `scripts/switch-dataset.py` (`--list [--json]`, `<name>
  [--force] [--json]`, `--session-key`).

- **`cognee-forget` skill — user-directed deletion of memory.** "Forget what we
  talked about tennis" now has a first-class flow: the agent syncs the live
  session (so unsynced content becomes a deletable document), lists the plugin
  dataset, judges candidate documents by their raw content, confirms with the
  user, and deletes each match via `POST /api/v1/forget`. Documents from the
  same session are treated as a group — deleting one while keeping its siblings
  would leave the topic recallable.
- **`scripts/cognee-forget.sh`** — the skill's server access. Subcommands
  (`sync`, `datasets`, `data`, `raw`, `forget`, `env`) each resolve credentials
  per invocation the same way the other wrappers do (shell env →
  `~/.cognee/.env` → the auto-minted local `api_key.json`), because exported
  variables don't survive across the agent's separate Bash calls. Every API
  command appends a final `HTTP <status>` line; with no key resolvable the
  helper exits 2 with guidance instead of sending a request that can only 401.
  The helper deliberately supports single-document deletion only — dataset-wide
  and `everything` scopes stay behind an explicit-user-request warning in the
  skill. Ids are validated as UUIDs and the request body is built with `json.dumps` rather than string interpolation, so a crafted id cannot redirect the request to another endpoint or append body fields — an injected `everything: true` would have deleted every dataset the user owns.
- **Mock-server forget surface + e2e tests.** `MockCogneeServer` now serves
  `GET /api/v1/datasets`, `GET /datasets/<id>/data`, `GET .../raw`, and
  `POST /api/v1/forget`; `tests/e2e/test_forget_script.py` runs the wrapper as
  a subprocess against it (credential resolution incl. the `api_key.json`
  fallback and the exit-2 path, payload shape, status trailer, 404 pass-through).

- **Code graph.** Repositories can be indexed into cognee's deterministic,
  enola-backed code graph (symbols, calls, imports, endpoints, dependencies)
  and queried from the plugin — with **no LLM or embedding calls** on either
  side. Requires a cognee server >= 1.5.3.
  - **Automatic indexing**: opening a session inside a git repository indexes
    it in the background at session start (never blocking the first prompt)
    and refreshes an already-indexed repo whose tree changed. New repos are
    auto-indexed only against a *local* server, where the code stays on the
    machine; a remote server needs `COGNEE_CODE_AUTOINDEX=always` or an explicit
    index. Non-git directories, repos with no source files, and repos over 3000
    source files are skipped (explicit indexing has no cap).
  - **Freshness**: the Stop hook re-submits an indexed repo when a turn changed
    its working tree, detected by a git fingerprint (HEAD, dirty set, tracked
    diff, untracked stats). Failures keep the fingerprint — the edits stay
    pending — behind an escalating backoff (30s → 15min cap) so an unresolved
    failure cannot re-submit once per turn forever; a new session always gets
    one attempt.
  - **Auto-recall code lane**: prompts naming an identifier-shaped token
    (`process_payment`, `UserService`, `billing/api.py`) inside an indexed repo
    get code facts injected under `=== Code graph facts ===`. The lane is
    additive to the semantic scopes, gated syntactically, and contributes
    nothing when it misses — conversational prompts are unchanged.
  - **Explicit tools**: `cognee-index-repo.sh <path-or-git-url>`,
    `cognee-search.sh "<seed>" --code [--code-query '<json>']` (operations:
    `query_facts`, `explore`, `traverse`, `find_path`, `impact_analysis`,
    `delta`), `cognee-remember.sh --file <path>` (uploads under the real
    filename so code routes as code, not prose), and a new `cognee-code` skill.
- One dataset per indexed repository, `codebase-<repo>-<digest>`. The path
  digest is load-bearing: same-basename checkouts sharing a dataset would share
  a graph database, where cognee's repo-scoped stale-node sweep would let each
  re-index delete the other's nodes. `--code` searches resolve the dataset from
  the current checkout.

### Fixed
- **cognee-search SKILL.md no longer claims searches span all authorized
  datasets.** The wrapper has always scoped recall to the plugin dataset
  (`COGNEE_PLUGIN_DATASET`, default `agent_sessions`); the doc now says so, and
  the raw `curl` examples pass `datasets` explicitly so following them doesn't
  search every readable dataset.

### Changed
- **Pinned cognee bumped to 1.5.3** (`_PINNED_COGNEE_VERSION` in
  `session-start.py`). 1.5.3 carries the session-invalidation work the forget
  skill depends on: deleting a document now also removes
  the session Q&A turns whose answers cited the deleted graph elements, the
  feedback and distilled guidance descending from them, and clamps the persist
  watermark to the surviving entry count so post-delete turns are not silently
  skipped by the next sync. Dataset-level deletes drop every session attributed
  to the dataset. The plugin always installs the exact pin so the server's
  lifespan migrations run on a known-good release.

  Documented core limit, reflected in the skill: agent **trace** entries carry
  no graph-element ids and are not matched, so trace content is not invalidated
  by a document delete and a later sync can re-persist it as new trace
  documents. The skill states this rather than promising the session cache is
  clean.

- **The active dataset now lives in the launch record**
  (`~/.cognee-plugin/claude-code/sessions/<host id>.json`), seeded at SessionStart
  from `COGNEE_PLUGIN_DATASET`/default. `config.get_dataset`, `load_resolved`, the
  `cognee-search.sh`/`cognee-remember.sh` wrappers, the idle and exit watchers and
  the status line all read it, so a switch is followed everywhere and survives
  `--resume`. A switched record beats an exported `COGNEE_SESSION_ID`.
- **Status line** shows the launch's recorded dataset and a faint `· switched` tag
  once it differs from the launch-time one.
- **Final sync covers every session the launch touched.** The record keeps a
  `touched` list of `{session_id, dataset, conn_uuid}` triples; the SessionEnd /
  exit-watcher sync bridges each pair (current last) and releases every handle, so a
  write that raced a switch is never lost.
- `sync-session-to-graph.py --strict` exits non-zero on an incomplete bridge.

- **Pinned cognee version is now `1.5.3`** (was `1.5.0`) — the release that
  opened `content_type="code"` on `/api/v1/remember` and the `code` recall
  scope. Installed into the managed venv on next session start.
- The freshness model is documented as a property of where the server runs:
  a local server reflects the working tree (uncommitted changes included); a
  cloud server reflects the last *pushed* commit, since its clone cannot see
  local edits.

## [1.3.3]

### Fixed
- **A replayed write can no longer duplicate a turn the server already holds.**
  The v1.3.2 failure buffering treated every retryable error the same, but a
  write that *times out* (or dies on a gateway 500/502/504) may still have
  committed server-side — and `/remember/entry` has no idempotency: every
  accepted write creates and embeds a fresh entry, so replaying a committed
  write stored the same content twice and fed the duplicate to the next
  improve. Failures are now classified at the buffering point
  (`write_outcome_ambiguous`): connection-refused/DNS failures and 503s
  provably never reached the cache and replay blind as before, while
  ambiguous outcomes are marked in the buffer and verified by the drain —
  one `GET /api/v1/sessions/{id}` per drain (only when an ambiguous entry is
  actually pending) supplies the server's recent QA/trace tails, and an entry
  whose content is already there is consumed without being re-sent (reported
  as `deduped` in the `warmup_drained` event). A failed verification read
  degrades to the old replay-everything behavior: a rare duplicate beats a
  lost turn. Also corrected two comments that claimed `/remember/entry`
  writes are "deduped server-side" — they never were; the single-drainer
  lock and this verify pass are the real guards.

### Changed
- **Pinned cognee version is now `1.5.0`** (was `1.4.2`). The plugin installs
  this into its own managed venv on session start, so existing installs pick it
  up on the next session; the local server's lifespan migrations handle any
  database upgrades on first start. Cognee 1.5.0 is a minor release with no
  user-facing breaking changes — it hardens large-scale dataset migrations,
  improves Ladybug graph-adapter reliability and performance, and adds
  `LLM_TEMPERATURE`/`LLM_SEED` plumbing. No plugin-side behavior changes.

## [1.3.2]

### Fixed
- **A turn captured while the server is down is no longer lost.** Writes were
  buffered to the warmup spillway only when `server_usable()` already reported
  False. That check relies on a ready marker with a 30s TTL, so a server dying
  inside that window left it returning True: the write was attempted for real,
  it raised, and the `except` branch only logged `stop_store_error` — the entry
  was buffered nowhere and the turn was gone. Both the Stop (QA) and PostToolUse
  (trace) paths now buffer on failure and replay when the server returns.

  Failures that cannot succeed on replay are *not* buffered. A 4xx is dropped
  with `"buffered": false` in the log, because the drain stops at the first entry
  it cannot send and only removes what it drained — a permanently rejected entry
  would sit at the head of the queue and block everything behind it. Transport
  failures and 5xx are retried; new events: `store_buffered_after_error`,
  `trace_buffered_after_error`.

### Known issues
- **The PreCompact anchor is empty in server mode.** `pre-compact.py` now recalls
  over HTTP, but its seed recall deliberately sends an empty query (there is no
  user question at compaction time) and the server matches nothing on one, so no
  session or trace entries come back and no anchor is printed. Per-prompt recall
  is unaffected — this costs the summary carried across a compaction, not memory
  itself. The fix is server-side.

## [1.3.1]

### Fixed
- **Boot points no longer mistake a busy server for an absent one.** The boot
  decision previously rested on a single 2s `/health` probe, so a server busy
  cognifying could miss the deadline, be declared absent, and have the venv
  upgraded and migrations run underneath it while it still held the graph
  store's file lock (2026-08-13 incident). Server presence is now judged from
  three evidence sources — the classified HTTP probe, the bare TCP handshake
  (a busy server still accepts it; a dead one refuses), and a server pidfile
  written at uvicorn spawn — and only a positively-absent verdict (refused
  port, no live server pid, confirmed by a delayed re-probe) licenses
  installing or booting. The verdict and its evidence are recorded on every
  `endpoint_mode_selected` decision, the license is re-verified after the
  (minutes-long) install and again under the boot lock, and a spawned server
  that dies before becoming healthy (e.g. lost port-bind race) is detected
  instead of being waited out.

## [1.3.0]

### Added
- **`COGNEE_BACKEND` per-terminal mode switch.** `~/.cognee/.env` may now hold
  the cloud vars (`COGNEE_BASE_URL`, `COGNEE_API_KEY`) *and* the local vars
  (`LLM_API_KEY`, …) together; with nothing exported, cloud wins as before.
  `export COGNEE_BACKEND=local` (or `=cloud`) flips a single terminal — the
  shared name switches both the Claude Code and Codex plugins at once, while
  `COGNEE_CLAUDE_BACKEND` targets this plugin only and beats the shared name.
- **Forced cloud is pinned, and misconfiguration is surfaced.** With
  `COGNEE_BACKEND=cloud` but no `COGNEE_BASE_URL`, the plugin no longer
  silently falls back to local (no local server boot, no venv build); the
  status line shows `✕ (missing_cognee_base_url)` and `cognee doctor`'s mode
  row explains what forced the decision and what is missing.

### Fixed
- **`COGNEE_CLAUDE_BACKEND=local` now holds on the HTTP hot paths.** The
  switch used to clear the cloud URL only in `load_config()`'s view, while
  recall/remember read `COGNEE_BASE_URL` from the environment — where the env
  file had already injected the cloud URL — so those calls still went to the
  cloud. A forced-local switch now scrubs `COGNEE_BASE_URL`/`COGNEE_API_KEY`
  from the process environment itself (with empty strings, so re-running the
  loader in child processes cannot re-inject the file's values).
- `COGNEE_CODEX_BACKEND` no longer flips this plugin: an export targeting the
  Codex plugin used to switch Claude Code's backend too.

## [1.2.6]

### Changed
- **Pinned cognee version is now `1.4.2`** (was `1.4.0`). The plugin installs
  this into its own managed venv on session start, so existing installs pick it
  up on the next session. No plugin-side behavior changes: cognee 1.4.1+ resolves
  an *omitted* session id to a per-dataset default (`default_session_<dataset_id>`),
  but the plugin always sends its explicit per-conversation session id, which
  passes through unchanged.

## [1.2.5]

### Added
- **Cloud credits in the status bar.** Cloud sessions now show the
  connected tenant's balance right after the mode — `credits: $14.23` in
  green, red once negative (a negative balance is real unfunded spend, the
  one state that must not hide) — followed by the approximate cost of the
  last memory operation, e.g. `· last turn ~$0.04`. Motivated by an incident
  where a tenant overshot its budget by ~$159 through the integration path
  with no client-side visibility at any point.
  - **Costs appear when the turn finishes, not one prompt later.** A dedicated
    hook (`credits-refresh.py`, async on `Stop` AND `StopFailure` — errored
    turns spend real money too) diffs the tenant's spend counter against the
    turn-start baseline and attributes the delta as `turn`; explicit
    `remember` and `improve` operations are attributed at their own
    completion points. Costs carry a `~` on purpose: the cloud aggregates
    spend asynchronously and concurrent operations overlap, so the delta is
    an attribution, not an invoice. Most conversational turns genuinely cost
    ~$0 — recall runs with `only_context=true` (no LLM completion) — so the
    label typically moves on improve/remember, while the balance refreshes
    every turn.
  - **Multi-tenant correct.** The balance comes from the platform API's
    per-tenant spend records (`/api/v1/billing/credits/overview` on
    `COGNEE_PLATFORM_API_URL`, default `https://api.aws.cognee.ai` — the
    tenant data plane has no billing routes), selected by the tenant id the
    `connections/me` lookup already returns (zero extra calls). The marker
    (`credits.json`) is a map keyed by tenant id, so several terminals
    connected to different tenants each display their own balance, and one
    tenant's spend can never be misattributed to another's turn. Entries are
    written atomically under a lock (per-pid staging files), so concurrent
    refreshes can't tear the file or drop each other's tenants.
  - The status-line renderer stays pure-local (reads only the marker, 15-min
    staleness TTL). Strictly the connected tenant's budget or nothing: the
    segment hides entirely for local servers (no credits concept) and
    whenever the connected tenant cannot be determined — never another
    workspace's number, never the all-tenants aggregate. Refresh cadence: per turn (prompt + turn end)
    plus a session-long background poll (`COGNEE_CREDITS_CHECK_INTERVAL`,
    300s), so the balance stays fresh through long idle stretches. Opt
    out with `COGNEE_STATUSLINE_CREDITS=off`.

## [1.2.4]

### Fixed
- **The "update available" nudge now clears in the same session the update is
  applied in.** The v1.1.1 fix compared the marker against the *running* plugin
  version, but installs are version-pinned directories: after `/plugin update`
  the old copy keeps rendering the status line until a restart re-points it, so
  the running version never moved and the nudge survived the whole session.
  Both surfaces (status-line segment and SessionStart message) now also consult
  Claude Code's install registry (`~/.claude/plugins/installed_plugins.json`),
  which is rewritten the moment an update lands: once it records a version at or
  past the marker's `latest_version`, the nudge is suppressed — the status line
  clears on its next refresh (~2s), no restart needed. A missing or malformed
  registry changes nothing (previous behaviour). The Codex plugin is unaffected:
  it updates in place, so its existing running-version guard already clears
  mid-session.

## [1.2.3]

### Fixed
- **False `✕ (unreachable)` in the status line.** Probe and recall
  timeouts were classified as "unreachable" and persisted into the shared
  connection state, so a busy-but-healthy server randomly turned the bar red
  and skipped recall — in both local and cloud mode. Timeouts are now a
  no-verdict: transport failures are classified (connection refused / DNS →
  `unreachable`; timeout → keep prior state), and `unreachable` is only ever
  written on positive absence.
  - The recall attempt itself is now the health probe: a successful scope call
    marks ready, a refused connection marks `unreachable`, a 401/403 marks
    `auth_failed` (detected from the real request, remaining scopes skipped),
    and all-5xx marks `server_error`. The synthetic pre-recall probe survives
    only as a re-entry check while the marker holds a failure state.
  - The recall circuit breaker is keyed by `base_url` (cloud failures no
    longer red a local bar, and vice versa), counts failures in a sliding
    window instead of forever, re-arms half-open after cooldown, never counts
    timeouts, and the status line renders its real trip reason.
  - The renderer shows a red ✕ only for fresh, definitive failures (30 min
    TTL); stale or ambiguous state renders no glyph.
  - Breaker state writes use tmp + atomic replace so readers never see a torn
    file.

### Added
- **`✕ (not_responding)` status** — distinct from `unreachable`: the server
  accepts connections but hasn't answered for N consecutive timeout-only
  prompts (default 3, `COGNEE_SLOW_STREAK_THRESHOLD`; streak window
  `COGNEE_SLOW_STREAK_WINDOW`, 600s). A single slow response never triggers
  it. Lifted back to `●` by the next successful probe or recall.

## [1.2.2]

### Fixed
- **Prompts no longer stall 10–30s replaying the warmup buffer** (#298). The
  ready marker (30s TTL) is only refreshed on the prompt path, so during any
  long agent turn it expired while the server was healthy; every tool trace
  then piled into the warmup buffer, and the next prompt's lookup hook —
  reading TTL expiry as "the server just came up" — synchronously replayed the
  whole backlog (N sequential `/remember/entry` calls, ~1s each, no deadline)
  before recall even started. Users paid a 10–30s frozen prompt after every
  long turn, often ending in a hook timeout that also discarded the recall
  context. Three moves, per the excellent analysis in #298:
  - **The buffer stops filling against a healthy server.** The per-tool-call
    store hook now uses `server_usable()`: on a stale marker it makes one
    bounded 1s `/health` probe and re-marks ready on success, keeping the
    marker fresh for the whole turn. It buffers only when the server is
    actually unreachable, and a failed probe is memoized for 10s so a real
    outage costs one probe per window, not one per tool call.
  - **The drain is off the keystroke path.** `session-context-lookup.py` never
    replays the buffer anymore; `store-user-prompt.py` — the async sibling on
    the same UserPromptSubmit event — drains instead, after its fast
    bookkeeping, so nothing user-visible waits on it. Entries buffered at the
    tail of a turn may land one turn later; that is the accepted trade for
    never stalling the prompt.
  - **The drain itself is time-boxed.** An overall budget
    (`COGNEE_DRAIN_BUDGET`, 20s; the detached SessionEnd/idle sync uses
    `COGNEE_DRAIN_BUDGET_FINAL`, 120s) stops the replay with the unreplayed
    tail preserved, and each entry's socket timeout is clamped to the budget
    remaining so one hung call cannot eat it all.
- **A poisoned session backlog can no longer be retried forever** (#298). One
  real incident had a SessionEnd worker grinding against a server that 503'd
  every write for 6.5 hours. Consecutive HTTP-status drain failures now back
  the session off exponentially (60s doubling, capped at 1h, logged as
  `warmup_drain_backoff`), skipped before any network I/O; progress resets the
  streak. Network errors deliberately don't count — the readiness gates
  already cover a down server, and backing off on them would delay recovery
  after a restart.

## [1.2.1]

### Fixed
- **One graph search per prompt, not two.** The per-prompt recall hook queried
  both `graph_context` and `graph` as separate scopes — a design from when
  `graph_context` was a cheap lookup of the distilled `improve()` snapshot. On
  cognee ≥ 1.4 the server aliases `graph_context` to `graph` (with a deprecation
  warning), so the pair silently ran the *same* full graph retrieval twice per
  prompt: once auto-routed to GRAPH_COMPLETION, once as the explicit
  HYBRID_COMPLETION. The two scopes are now folded into a single `graph` scope
  using HYBRID_COMPLETION, halving the most expensive part of every recall and
  removing the server-side deprecation warning. Results from the `graph` scope
  are still bucketed under the historical `graph_context` label, so the status
  line counters, `last_recall.json`, and the `g` count render unchanged.
- **Recall scopes run cheap-first, so agent guidance is never starved.** The
  scope order was session → trace → graph_context → graph → session_context;
  with both graph searches routinely consuming their full 2.5s timeout, the
  4-second recall budget was exhausted before `session_context` — standing agent
  guidance, ~50ms when it runs — ever fired, and it was silently skipped on
  every degraded prompt. The order is now session → trace → session_context →
  graph, so the only call that can eat a whole timeout runs last, against
  whatever budget remains.
- **Per-scope timeouts are clamped to the remaining recall budget.** The budget
  deadline was only checked *between* scopes, so a scope dispatched just before
  it could run a full `COGNEE_RECALL_TIMEOUT` past it — two slow scopes pushed a
  "4-second" recall to 5–7s of keystroke-to-answer latency, mathematically
  guaranteeing a `recall_budget_exceeded` event. Each call now gets
  `min(recall_timeout, budget remaining)`, and a scope with less than 0.2s of
  budget left is skipped outright instead of being dispatched with a doomed
  deadline. The budget is a hard ceiling now; `recall_budget_exceeded` only
  fires when the budget was genuinely spent on useful work.

## [1.2.0]

### Added
- **One-time configuration via `~/.cognee/.env`.** API keys and URLs
  (`COGNEE_BASE_URL`, `COGNEE_API_KEY`, `LLM_API_KEY`, and every other env var the
  plugin reads) no longer need to be exported in each shell: values placed in
  `~/.cognee/.env` — the durable cognee home shared with the Codex plugin — are
  injected into the environment at process start with setdefault semantics, so a
  real shell export still wins per terminal, and spawned processes (local server,
  watchers) inherit them unchanged. The file accepts pasted `export KEY=value`
  lines, is created with a commented template (mode `0600`) on first session
  start, and its location can be overridden with `COGNEE_ENV_FILE`. `doctor.py`
  gained an **Env File** row showing which keys the file defines (names only,
  never values) and which are overridden by shell exports. The parser tolerates
  Windows-written files: a UTF-8 BOM (PowerShell 5.1) is stripped, UTF-16 (a PS5
  `>` redirect) is decoded, and CRLF line endings are handled — so copy/paste
  setup blocks work from any shell.

## [1.1.2]

### Fixed
- **Per-prompt recall now names its dataset.** `/api/v1/recall` was the only
  data-plane call that omitted one, so the server resolved *every* dataset the user
  can read and searched all of them on every prompt — on a machine with several
  datasets that is the graph scope paying for unrelated stores, one of which can be
  orders of magnitude larger than the plugin's own. It now sends
  `datasets: [<dataset>]`, matching the explicit-search path
  (`cognee-search.sh`), which has always scoped this way. The dataset is the usual
  one — `COGNEE_PLUGIN_DATASET` if set, otherwise `agent_sessions` — and the key is
  omitted entirely when no dataset is known, so a standalone invocation behaves as
  before.
- **One improve per session, instead of up to three at once.** The idle watcher,
  the store hook and the SessionEnd sync all bridge sessions, and the cross-hook
  `sync_lock` is bypassed in API mode — so in HTTP/cloud mode nothing stopped two of
  them submitting the *same* session concurrently. The server's own per-session lock
  answered the loser with a busy response, which drove a 15-second retry loop for up
  to ten minutes; in one real log that accounted for two thirds of all sessions and
  7,144 retry events. Improves are now claimed per session locally before submitting
  (`improve_session_lock`), so the loser skips immediately instead of waiting on work
  the winner is already doing. Freshness is unaffected: a skip reports not-synced, so
  the caller re-drives the whole drain+improve, and the server-side busy retry still
  covers a later attempt landing on a still-running pipeline. The claim covers both
  the HTTP and local-SDK paths, is released on exceptions, reclaims a dead holder's
  lock, and fails open — lock bookkeeping must never be why a session goes unsynced.

## [1.1.1]

### Fixed
- **The "update available" nudge now clears as soon as the update is applied.** The
  marker is a snapshot from the background check, and nothing rewrote it when the
  plugin actually updated — so the status line kept advertising an update that was
  already installed until the next check. Both surfaces now compare the marker's
  `installed_version` against the version *running* and suppress the nudge on a
  mismatch, so the status line clears on its next refresh (~2s) instead of up to an
  interval later. The comparison is against the running version, not the newest copy
  on disk, so a background auto-update that a session has not reloaded yet correctly
  keeps nudging.

### Changed
- **Pinned cognee version is now `1.4.0`** (was `1.2.2.dev3`). The plugin installs
  this into its own managed venv on session start, so existing installs pick it up
  on the next session.
- **Update check now runs at most hourly instead of daily.**
  `COGNEE_UPDATE_CHECK_INTERVAL` defaults to `3600` (was `86400`). The check is a
  conditional `If-None-Match` request, so the steady state is a 304 with an empty
  body — cheap enough that a published release gets noticed within the hour rather
  than after up to a day. Still bounded regardless of how often the idle watcher
  relaunches, and still opt-out via `COGNEE_UPDATE_CHECK=off`.

## [1.1.0]

Status-line release. The line now says whether memory is actually working, which
server it is talking to, and what it just did — answered **per terminal**, since two
sessions on one machine can legitimately disagree.

```
● cognee: agent_sessions · local · recall 4s/5t/0g/1a · saved 2p/41t/2a
│                          │       └ what memory did this turn
│                          └ bold cyan = local, bold magenta = cloud
└ green ● healthy · red ✕ (reason) when not — connection and LLM key share this slot
```

### Added
- **Server-connection glyph, colour-coded.** A bold green `●` once the server is
  confirmed up **and** authenticated; on failure a bold red `✕ (<reason>)` with the
  reason inside the colour, so the verdict reads as one unit —
  `incorrect_cognee_api_key` for a missing, wrong, or expired `COGNEE_API_KEY`,
  `unreachable` for a server that is down or dies mid-session, or `server_error` for a
  5xx. Recorded by the hooks that already talk to the server, so the line stays green
  until a failure is actually observed and clears on the next success. A cold start
  still migrating stays silent rather than flashing a false red. Read from local
  markers only — no network on refresh.
- **Local-mode `LLM_API_KEY` health, in that same slot.** A bold red
  `✕ (incorrect_llm_api_key)` when no key is configured anywhere the server would
  look, or when the provider rejects the one that is — one reason for both, because
  the fix is the same either way (`llm-state.json` still records which it was). The
  two failure classes are told apart by the reason rather than by colour:
  `incorrect_cognee_api_key` is the key this plugin uses to reach the server,
  `incorrect_llm_api_key` is the key the local server uses to reach the LLM. An
  LLM-key failure *replaces* the `●` rather than sitting beside it, and a
  server-connection failure outranks it — if the server can't be reached, its LLM key
  is not the actionable problem. The key is resolved exactly as
  the server resolves it (Cognee's own config, so an env var, a `.env`, or Cognee's
  config file all count) and validated in the background idle watcher — never on the
  prompt path — with one `max_tokens=1` call through the same LLM stack Cognee uses.
  That makes it **provider-agnostic**: only `401`/`403` counts as an auth failure,
  any other response proves the key was accepted (including the `400` reasoning
  models return when one token is too few to finish a message), and a transport
  error with no HTTP status is inconclusive and leaves the previous verdict alone.
  Local mode only; verdicts expire after 30 minutes so a dead session's verdict never
  lingers.
- **Per-terminal status.** Every signal answers for *this* terminal — one shell may
  have exported `LLM_API_KEY` while another didn't, or two may hold different
  `COGNEE_API_KEY`s against one server, and both now show the truth at once. Each
  writer keeps the machine-wide marker as **coordination** state (it gates recall and
  is shared with the Codex plugin, since both talk to one server on one port) plus a
  per-session copy — `conn-state/<session>.json`, `llm-state/<session>.json`,
  `recall/<session>.json` — as the **display** state the bar reads. Your own record
  wins, except that a fresher **server-wide** failure in the shared marker takes
  precedence (`unreachable` / `server_error`), because the server really is shared
  and a just-observed outage applies to everyone. `incorrect_cognee_api_key` is *not*
  propagated — it describes the other session's credential rather than the server, so
  a keyless cloud terminal starting up cannot turn a healthy local one red. Nor does a
  fresher shared `ready` clear your own failure: another terminal's working key says
  nothing about yours.
- **Recall counts at the end of the line.** `· recall 4s/5t/0g/1a · saved 2p/41t/2a`
  — `recall` is what this turn's lookup found (`s`ession turns, `t`races, `g`raph
  context, `a`gent guidance), `saved` is what the previous turn persisted
  (`p`rompts, `t`races, `a`nswers). The same numbers the Codex plugin injects into
  model context, rendered faint here so they stay secondary. Read from a marker the
  prompt hook already wrote, so the renderer stays network-free.
- **The mode stands out** — `local` in bold cyan, `cloud` in bold magenta. It is the
  one field worth a double-take, since it says which memory you are about to write
  to; red and green are left to the health glyph, amber to the update nudge.
- **Idle refresh.** The `statusLine` entry now sets `refreshInterval: 2`, so the bar
  keeps updating while a session sits idle. Without it Claude Code refreshes only on
  events, and a failure detected right after launch wouldn't surface until the next
  prompt.

| Env var | Default | Effect |
|---|---|---|
| `COGNEE_LLM_KEY_CHECK` | `true` | Background, provider-agnostic `LLM_API_KEY` validation (local mode) |
| `COGNEE_LLM_CHECK_INTERVAL` | `300` | Minimum seconds between LLM-key checks |
| `COGNEE_STATUSLINE_COUNTS` | `true` | Show the trailing `recall …/saved …` counts |
| `COGNEE_STATUSLINE_REFRESH_INTERVAL` | `2` | Status-line idle refresh in seconds; below `1` reverts to event-only |

### Changed
- **The per-prompt readiness gate now prefers an authenticated probe**, so a bad or
  expired key is classified as `incorrect_cognee_api_key` instead of being masked as
  healthy by an unauthenticated `/health` 200 — and recall skips the turn rather than
  attempting against a backend that will reject it. Falls back to `/health` when the
  authed probe can't classify (no key, or an older server without the endpoint).
- **The status line now resolves its own server URL** instead of leaving it empty when
  nothing is configured, mirroring the hooks' resolution exactly
  (`COGNEE_LOCAL_API_URL` → `COGNEE_BASE_URL` → config file → `http://localhost:8011`).
  A marker is only trusted when its `base_url` matches this session's; with no URL of
  our own that check could never fire, so a record written for a different server —
  another terminal's cloud tenant, say — was accepted by a local session. This is what
  gives that guard teeth in the default local setup, where nothing is exported.
- **Documented two long-standing environment variables** that previously existed only
  in the source: `COGNEE_READY_PROBE_TIMEOUT` (the per-prompt readiness probe's
  timeout, default `1.0s`), plus a note naming the `COGNEE_*` variables that are the
  plugin's own inter-process plumbing — `COGNEE_USER_ID`, `COGNEE_SESSION_KEY`,
  `COGNEE_AGENT_SESSION_NAME`, `COGNEE_PLUGIN_IN_VENV`, `COGNEE_SYNC_*` — which are
  overwritten during startup and should not be set by hand. Neither is new in this
  release; both were simply undocumented.

## [1.0.0]

First release under formal semantic versioning — marks the official start of
versioning for this plugin. Supersedes the unversioned `0.2.0` baseline and
bundles all changes since, from the automatic install/server-bootstrap work
onward.

### Added
- **Automatic Cognee installation + server bootstrap.** A self-managed,
  `uv`-provisioned virtualenv under `~/.cognee-plugin/venv`, with data pinned to
  `~/.cognee` so it survives venv rebuilds and cognee upgrades.
- **Lazy bootstrap.** SessionStart spawns a detached worker to boot the local
  server (including DB migrations), so the hook returns fast and never times out.
- **Automatic status-line setup.** The plugin writes/enables its status line into
  `~/.claude/settings.json` on first run — no manual configuration.
- **Server-first recall client** with a circuit breaker and bounded timeouts;
  falls back to the CLI only on a genuine failure, never on an empty result.
- **Background remember + cognify status polling.** Writes enqueue and poll to
  completion instead of holding one request open past the cloud's request ceiling.
- **Memory-preference steer.** SessionStart asserts Cognee as the preferred
  memory over Claude Code's native `MEMORY.md` (opt out with `COGNEE_PREFER_MEMORY`).
- **Status-line cleanup on uninstall/disable.** The renderer self-evicts its
  `statusLine` entry from `~/.claude/settings.json` when the plugin is no longer
  enabled, and the entry is written as an existence-guarded command so an
  uninstalled plugin never leaves a broken status-line command behind.

### Changed
- **Single-principal / session-id model.** Session IDs are the point of contact
  with agents; removed per-agent user creation.
- **Dataset-scoped model.** Removed session switching in favor of datasets, with
  one shared default dataset (`agent_sessions`) across the Claude and Codex plugins.
- **Deterministic session naming** as `{agent}_{host_session_id}`.
- **Session→graph sync via session-aware `improve`**, replacing full-transcript
  re-cognify on every sync; the legacy document bridge remains as a fallback.
- **New session distillation logic.**
- **Cloud mode is now a pure thin client.** The cloud/remote setup path (health
  check, `/users/me`, dataset ensure, default-user key mint) uses stdlib `urllib`
  instead of `aiohttp`, so connecting to Cognee Cloud no longer requires the
  plugin's local virtualenv. The venv is now built only in local mode.
- Renamed the `service_url` config/env to `base_url`.

### Fixed
- **TLS certificate verification for cloud/HTTPS.** All `urllib` HTTPS calls now
  share a certifi-backed SSL context (falling back to `SSL_CERT_FILE` / system
  cert bundles), fixing `CERTIFICATE_VERIFY_FAILED` against Cognee Cloud on macOS
  Python builds that lack root CAs in the default context.
- Concurrency-safe pending-prompt and bridge buffers (per-session files, no
  lost-update races).
- `base_url` handling and connecting to an existing dataset; dataset name/config
  resolution; `/users/me` identity resolution; and bridge-POST network/HTTP-error
  handling with bounded poll deadlines.

## [0.2.0]

- Baseline release: session-aware capture (prompts, tool traces, assistant
  responses), auto-routing recall on prompt submit, session→graph sync on
  session end, local and Cognee Cloud modes, and automatic Cognee bootstrap for
  local mode.
