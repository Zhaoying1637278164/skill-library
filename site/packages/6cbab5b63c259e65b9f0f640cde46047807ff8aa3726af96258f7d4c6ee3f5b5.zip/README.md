# Vibee plugin for Claude Code

[Vibee](https://vibee.one) builds small internal tools through conversation. Describe a fleet log, a library,
a document archive or a lead tracker, and Claude creates the tables, forms, filters, charts and web pages in
your Vibee account. Apps can be public or require sign-in, and each one can expose its own HTTP endpoints.

This plugin connects Claude Code to the hosted Vibee MCP server at `https://vibee.one/mcp`.

## Install

```
/plugin marketplace add vibee-one/claude-plugin
/plugin install vibee@vibee
```

Then run `/mcp`, select **vibee** and sign in. A free Vibee account is required (you can create one during
sign-in); usage limits apply.

Without the plugin, the same server can be added directly:

```
claude mcp add --transport http vibee https://vibee.one/mcp
```

## What it can do

- **Tables** – create, alter and drop tables; query, insert, update and delete rows
- **Apps** – create and update apps, set color schemes, publish on a custom domain
- **Endpoints** – create public or API-key protected HTTP endpoints per app
- **Access** – add and manage users who can sign in to an app
- **Files** – list and delete uploaded files

Example prompts:

- "Create a vehicle fleet log with a form for trips and a monthly mileage chart."
- "Add a priority column to the tasks table and let me filter by it."
- "Give my colleague jana@example.com access to the lead tracker."

Destructive tools (dropping tables or columns, deleting rows, apps, endpoints, users and files) are annotated
as such, so Claude asks for confirmation before running them.

## Links

- Website: https://vibee.one
- Support: https://vibee.one/support
- Privacy policy: https://vibee.one/privacy
- Terms: https://vibee.one/terms

## License

The plugin configuration in this repository is MIT licensed. The Vibee service is subject to its
[terms](https://vibee.one/terms).
