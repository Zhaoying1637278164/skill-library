# How skills reach agents

No installation required for most agents. Open this repo in your tool and skills are available immediately.

| Agent          | Mechanism                                                  | Notes                                                                                     |
|----------------|------------------------------------------------------------|-------------------------------------------------------------------------------------------|
| Claude Code    | Reads `CLAUDE.md` → copy of `AGENTS.md`                    | Auto on repo open                                                                         |
| GitHub Copilot | Reads `.github/copilot-instructions.md`                    | Auto on repo open                                                                         |
| Cursor         | Reads `.cursor/skills/*/SKILL.md` (+ short always-on rule) | Skills synced by `sync-providers.yml`; brief pointer in `.cursor/rules/xsolla-ai-kit.mdc` |
| Codex CLI      | Reads `AGENTS.md` at root                                  | Auto on repo open                                                                         |
| Windsurf       | Reads `AGENTS.md` at root                                  | Auto on repo open                                                                         |
| Roo Code       | Reads `AGENTS.md` at root                                  | Auto on repo open                                                                         |
| Augment        | Reads `AGENTS.md` at root                                  | Auto on repo open                                                                         |
| Amp            | Reads `AGENTS.md` at root                                  | Auto on repo open                                                                         |

## Long-term: `xsolla install`

Once `xsolla/xsolla-cli` ships to production, `xsolla install xsolla-ai-kit` will sync skills into the developer's current project automatically. Skills in this repo are the source of truth.
