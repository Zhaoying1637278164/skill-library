---
name: find-moments
description: 'Finds moments in a StarZero library: searches transcripts for what was said and visuals for what is on screen, returns time ranges, then pulls out a frame, a signed URL, a download, or one preview video of the hits. Use when the user says "find where they talk about", "search my library for", "which clip shows", "grab a frame at", "download the original", or "compile those moments".'
argument-hint: "[what to look for]"
---

# Find moments

Searches a library for `$ARGUMENTS` in the spoken words or on screen and returns time ranges with media ids. From there it hands over a thumbnail, a link, a file, or a watermarked compilation of the hits.

## Prerequisites

- This skill runs the `starzero` CLI in the shell. Every `starzero ...` below is run as `${CLAUDE_PLUGIN_ROOT}/scripts/starzero ...`: that launcher installs the pinned CLI on first use and hands over to it. Without a shell (claude.ai chat), the plugin's StarZero connector offers the same API as tools and carries its own instructions; the commands in this skill apply where a shell exists.
- Exit 3 from any command means the login has expired (browser logins last 5 days), or the credential is missing, invalid or lacks a scope. Log in again by the procedure in `${CLAUDE_PLUGIN_ROOT}/reference/auth.md` ("Logging in from a skill"), then re-run the command; when that fails, the user runs `/starzero:setup`.

## Steps

1. Pick the library with `starzero library list` unless one was chosen earlier in this session. Ask when several match. `--library` is required on every command below.
2. Scope the media with `starzero media list --library <id> --status completed`. Narrow with `--folder /path` (`--recursive` for subfolders) and `--name <substring>`; page with `--limit` and `--offset`. The command fetches the whole library every time, so filter before paging. Only `completed` media are searchable. Keep the names next to the ids for the report.
3. Search. Run both when the request mixes speech and visuals.
   - Spoken words: `starzero search transcript --library <id> --query "<what was said>" [--media <id...>] [--threshold <0-1>] [--limit <n>]`.
   - On screen: `starzero search visual --library <id> --query "<description>" [--media <id...>] [--limit <n>]`, or `--image <file>` instead of `--query`; exactly one of the two.
   Each hit carries `mediaId` and a time range in seconds. Searches may be metered, cheaply.
4. Hand back the moments: media name, media id, the range in seconds, and the matched text or score. Ask which ones to act on when the user has not said.
5. Deliver what the user asked for, per moment. Ids come from step 2 or step 3, in this session.
   - A frame: `starzero media thumbnail --library <id> --at <seconds> [--height <px>] [--out <path>] <mediaId>`. Default name `<mediaId>-<seconds>s.jpg`.
   - A link: `starzero media url --library <id> [--which original|thumbnail|audio|audio-vocals|audio-background] <mediaId>`. The URL carries no key; pass it through as printed.
   - A file: `starzero media download --library <id> [--which ...] [--out <path>] <mediaId>`. Default name is the original filename in the current directory. A download is for the user's own use (sending the original on, archiving); an edit of the footage is `/starzero:chat`, never a local tool on the downloaded file.
   - One preview video of the hits: `starzero output render --library <id> --clip <mediaId>:<start>-<end> [--clip ...] [--aspect 9:16] [--height <px>]`. Clips play in the order given; seconds take decimals. Watermarked by default and free. It is a preview of the moments, joined as found: anything meant to be delivered, or that changes the footage beyond joining the ranges (a target length, captions, reframing, graphics, audio, pacing, a clean render), is a `/starzero:chat` task, and the media ids and ranges found here go into that brief. The command blocks until the render is done with no limit of its own, so run it in the background as `${CLAUDE_PLUGIN_ROOT}/reference/waiting.md` describes. The result is `url`, `durationSeconds` and `urlExpiresInSeconds`; save it with `curl -o <file> "<url>"` while the URL is valid (about a day). A temporary render has no record: the URL is the whole result, and `output url` and `output share` cannot serve it.
6. `--no-watermark` on `output render` gives a clean render and bills credits: see the section below.

See `starzero <group> <command> --help` for the remaining flags.

## Billing

The only billed command here is `starzero output render ... --no-watermark`: currently 250 credits per rendered minute, and the CLI sends it once, without retry. Before running it:

1. Run `starzero credits` (free), then state the exact command, what it bills ("a clean render of N seconds", N being the summed clip lengths; `durationSeconds` of a watermarked trial is the same number) and `creditsLeft`.
2. Ask once, in words, and wait for the answer: one question that carries the command, the billing and the balance ("Clean render of 42 s of clips, about 175 credits, 12,400 left. Go ahead?"). The user can waive this question for the session (`credits.md`, "Waiving the question"); the statement in step 1 still comes first. The Bash call's `description` repeats the billing line, for example `Clean render of 42 s of clips (billed; 12,400 credits left)`.
3. Run it once, after the yes. Exit 6 cancelled it; a second run is a second bill and is asked about again.

Every other command in this skill is free, with the search caveat above.

## Report back

- The moments as a table: media name, media id, start-end in seconds, matched text or score.
- Files written, with their paths.
- URLs exactly as the CLI printed them, with their expiry.
- For a compilation: `durationSeconds`, the URL, its expiry, and the local file if downloaded.
- Deleting media happens in the StarZero app; the CLI has no delete command.

## Failure modes

| Symptom | Meaning | What to do |
| --- | --- | --- |
| no hits | media not `completed`, or the query is off | `starzero media get --library <id> <mediaId>` to check status; `/starzero:ingest-media` watches processing; then widen the query or lower `--threshold` |
| exit 2 on `search` | empty `--query`, or `visual` got both or neither of `--query` / `--image` | fix the flags; `--help` lists them |
| exit 2 on any id | the id is not 24-hex | take it from `media list` or a search hit |
| exit 8 `FILE_EXISTS` on `download` / `thumbnail` | the local file exists | choose another `--out`, or ask before `--force` |
| `--which audio-vocals` or `audio-background` fails | speech separation has not been run on this media | use `--which audio` or `original` |
| exit 1 with an API code such as `NO_ACCESS_TO_LIBRARY` | the key cannot see that library; this is an API refusal, not exit 3 | pick a library from `library list` |
| exit 6 on `output render` | the wait ended early and the render was cancelled | re-run in the background; a clean render needs a fresh yes |
| `media list` slow | the whole library is fetched per call | filter with `--folder`, `--name`, `--status` before paging |
| `curl -o` returns 404 or 403 | the signed URL expired | run `media url` or `output render` again |

## Reference files

- `${CLAUDE_PLUGIN_ROOT}/reference/ids-and-links.md`: read before taking an id from anything other than a list or search output.
- `${CLAUDE_PLUGIN_ROOT}/reference/renders.md`: read before the first `output render`.
- `${CLAUDE_PLUGIN_ROOT}/reference/credits.md`: read before `--no-watermark`.
- `${CLAUDE_PLUGIN_ROOT}/reference/cli-conventions.md`: read for the exit code table and the JSON envelope.
