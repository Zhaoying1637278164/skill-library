# Review Times plugin

[![Claude Plugins review](https://reviewtimes.fyi/badge/claude-plugins.svg)](https://reviewtimes.fyi/claude-plugins)
[![ChatGPT Plugins review](https://reviewtimes.fyi/badge/chatgpt.svg)](https://reviewtimes.fyi/chatgpt)
[![Muse review](https://reviewtimes.fyi/badge/muse.svg)](https://reviewtimes.fyi/muse)

Live review times for AI app, connector and plugin stores, inside your agent: ChatGPT plugins, Claude connectors and plugins, Meta Muse, Grok, Cursor, Microsoft 365 Agent Store, Gemini CLI and the Docker MCP Catalog.

Ask before you submit ("how long is Claude plugin review taking?"), set expectations in a launch plan, or check whether a stalled review is normal. With your go-ahead it can also report your own submission, so the numbers get better for everyone.

## What's inside

- **MCP server** at `https://reviewtimes.fyi/mcp` (no key): `review_times` and `report_submission`. Reports made through the MCP server email their private update link to the reporter rather than returning it in the chat.
- **Skill** `review-times`: when to check, how to read the numbers, how to report.

## Install

Claude Code:

```
/plugin marketplace add stevysmith/review-times-plugin
/plugin install review-times@review-times
```

Any MCP client: add `https://reviewtimes.fyi/mcp` as a remote (streamable HTTP) server. From a terminal: `curl reviewtimes.fyi`.

## Data

Typical wait is a Kaplan-Meier median of days from submission to decision, counting submissions still waiting. Grok and Docker come from their public pull-request queues; other stores from developer reports and public posts, each linked to its source. Method: https://reviewtimes.fyi/#method

MIT licensed.
