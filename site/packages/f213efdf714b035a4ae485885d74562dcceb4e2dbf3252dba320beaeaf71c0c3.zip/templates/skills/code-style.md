---
name: "code-style"
description: "Стиль кода, именование, форматирование"
user-invocable: false
---

# Skill: Code Style — {LANG}/{FRAMEWORK}

## Именование

| Элемент | Конвенция | Пример |
|---------|-----------|--------|
| Классы | {CLASS_NAMING} | {CLASS_EXAMPLE} |
| Методы | {METHOD_NAMING} | {METHOD_EXAMPLE} |
| Переменные | {VAR_NAMING} | {VAR_EXAMPLE} |
| Константы | {CONST_NAMING} | {CONST_EXAMPLE} |
| Файлы | {FILE_NAMING} | {FILE_EXAMPLE} |
{ADDITIONAL_NAMING_RULES}

## Типизация

- Режим: {TYPING_MODE}
{TYPING_RULES}

## Структура файла

```{LANG_EXT}
{FILE_STRUCTURE_TEMPLATE}
```

## DI / Инъекция зависимостей

- Паттерн: {DI_PATTERN}
{DI_RULES}

## Антипаттерны

{ANTIPATTERNS}

## Примеры

### Правильно
```{LANG_EXT}
{GOOD_EXAMPLE}
```

### Неправильно
```{LANG_EXT}
{BAD_EXAMPLE}
```

## Правила из CLAUDE.md

{EXTRACTED_CLAUDE_RULES}
