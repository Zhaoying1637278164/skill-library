# Sample App

A tiny demo service used to test the Network Footprint plugin.

## Docs

- API reference: https://docs.acme-service.com/reference (documentation link - no data transfer)
- Deployment guide lives on the wiki: https://wiki.internal.example/deploy

This README URL should be classified as a **Documentation** reference (no active data flow).
