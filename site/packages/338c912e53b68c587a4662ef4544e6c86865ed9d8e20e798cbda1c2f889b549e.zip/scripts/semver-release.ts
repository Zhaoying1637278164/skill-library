import { dirname, resolve } from 'node:path'
import { $ } from 'bun'

type Bump = 'none' | 'patch' | 'minor' | 'major' | 'initial'

type ReleaseUnit = {
  bump: Bump
  paths: string[]
  rationale: string[]
}

type ReleasePlan = {
  schemaVersion: 1
  baseRef: string
  headRef: string
  generatedAt: string
  changes: string[]
  units: {
    skills: Record<string, ReleaseUnit>
    plugins: Record<string, ReleaseUnit>
    npm: Record<string, ReleaseUnit>
    clawhub: Record<string, ReleaseUnit>
  }
}

const defaultRepoRoot = resolve(import.meta.dir, '..')
const pluginManifests = [
  'plugin.json',
  '.plugin/plugin.json',
  '.claude-plugin/plugin.json',
  '.codex-plugin/plugin.json',
  '.cursor-plugin/plugin.json',
  '.kimi-plugin/plugin.json',
  '.grok-plugin/plugin.json',
]
const pluginMarketplaces = [
  '.claude-plugin/marketplace.json',
  '.agents/plugins/marketplace.json',
  '.cursor-plugin/marketplace.json',
  '.github/plugin/marketplace.json',
  '.grok-plugin/marketplace.json',
]
const pluginMcpConfigs = ['mcp.json', '.mcp.json']
const pluginReleasePaths = [...pluginManifests, ...pluginMarketplaces, ...pluginMcpConfigs]
const npmPackages = {
  '@youdotcom-oss/opencode': 'packages/opencode/package.json',
  '@youdotcom-oss/pi': 'packages/pi/package.json',
  '@youdotcom-oss/openclaw': 'packages/openclaw/package.json',
  '@youdotcom-oss/dsh-plugin': 'packages/dsh-plugin/package.json',
} as const
const packageBuildDirectories = ['packages/opencode', 'packages/openclaw', 'packages/pi', 'packages/dsh-plugin']
// 'initial' outranks semantic bumps: a brand-new package publishes its declared
// version as-is regardless of any other changes in the same diff.
const bumpOrder: Bump[] = ['none', 'patch', 'minor', 'major', 'initial']

const maxBump = (left: Bump, right: Bump): Bump => (bumpOrder.indexOf(left) > bumpOrder.indexOf(right) ? left : right)

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value)

const isBump = (value: unknown): value is Bump =>
  value === 'none' || value === 'patch' || value === 'minor' || value === 'major' || value === 'initial'

const isStringArray = (value: unknown): value is string[] =>
  Array.isArray(value) && value.every((item) => typeof item === 'string')

const unique = (values: string[]) => Array.from(new Set(values)).sort()

const bumpVersion = (version: string, bump: Bump) => {
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version)
  if (!match) {
    throw new Error(`Invalid semver: ${version}`)
  }

  const major = Number(match[1])
  const minor = Number(match[2])
  const patch = Number(match[3])

  if (bump === 'initial') {
    return version
  }

  if (bump === 'major') {
    return `${major + 1}.0.0`
  }

  if (bump === 'minor') {
    return `${major}.${minor + 1}.0`
  }

  if (bump === 'patch') {
    return `${major}.${minor}.${patch + 1}`
  }

  return version
}

const updateReleaseUnit = (
  unit: ReleaseUnit | undefined,
  bump: Bump,
  path: string,
  rationale: string,
): ReleaseUnit => ({
  bump: maxBump(unit?.bump ?? 'none', bump),
  paths: unique([...(unit?.paths ?? []), path]),
  rationale: unique([...(unit?.rationale ?? []), rationale]),
})

export const isPluginReleasePath = (path: string) =>
  pluginReleasePaths.some((releasePath) => path === releasePath || path.startsWith(`${dirname(releasePath)}/`))

export const isInitialPackage = (statuses: { status: string; path: string }[], directory: string): boolean => {
  const packageChanges = statuses.filter((item) => item.path.startsWith(`${directory}/`))
  return packageChanges.length > 0 && packageChanges.every((item) => item.status.startsWith('A'))
}

const readChangedPaths = async (baseRef: string) => {
  const names = await $`git -C ${defaultRepoRoot} diff --name-only ${baseRef}`.text()
  return names
    .split('\n')
    .map((path) => path.trim())
    .filter(Boolean)
}

const readChangedStatuses = async (baseRef: string) => {
  const names = await $`git -C ${defaultRepoRoot} diff --name-status ${baseRef}`.text()
  return names
    .split('\n')
    .map((line) => line.trim().split(/\s+/))
    .filter((parts) => parts.length >= 2)
    .map(([status, path]) => ({ status: status ?? '', path: path ?? '' }))
}

const changedSkillBump = async ({ baseRef, path, isAdded }: { baseRef: string; path: string; isAdded: boolean }) => {
  if (isAdded) {
    return { bump: 'minor' as const, rationale: 'new skill' }
  }

  if (!path.endsWith('/SKILL.md')) {
    return { bump: 'patch' as const, rationale: 'skill resource change' }
  }

  const diff = await $`git -C ${defaultRepoRoot} diff ${baseRef} -- ${path}`.text()
  if (/^[+-](name|description):/m.test(diff) || diff.includes('mcp_servers')) {
    return { bump: 'minor' as const, rationale: 'skill activation or MCP contract changed' }
  }

  return { bump: 'patch' as const, rationale: 'skill instructions changed' }
}

const createReleasePlan = async (baseRef: string): Promise<ReleasePlan> => {
  const changes = await readChangedPaths(baseRef)
  const statuses = await readChangedStatuses(baseRef)
  const addedPaths = new Set(statuses.filter((item) => item.status.startsWith('A')).map((item) => item.path))
  const deletedPaths = new Set(statuses.filter((item) => item.status.startsWith('D')).map((item) => item.path))
  const headRef = (await $`git -C ${defaultRepoRoot} rev-parse --short HEAD`.text()).trim()
  const plan: ReleasePlan = {
    schemaVersion: 1,
    baseRef,
    headRef,
    generatedAt: new Date().toISOString(),
    changes,
    units: {
      skills: {},
      plugins: {},
      npm: {},
      clawhub: {},
    },
  }

  for (const path of changes) {
    const skillMatch = /^skills\/([^/]+)\//.exec(path)
    if (skillMatch?.[1]) {
      if (deletedPaths.has(path)) {
        continue
      }

      const { bump, rationale } = await changedSkillBump({ baseRef, path, isAdded: addedPaths.has(path) })
      plan.units.skills[skillMatch[1]] = updateReleaseUnit(plan.units.skills[skillMatch[1]], bump, path, rationale)
      plan.units.plugins.you = updateReleaseUnit(plan.units.plugins.you, bump, path, `skill ${skillMatch[1]} changed`)
      plan.units.npm['@youdotcom-oss/opencode'] = updateReleaseUnit(
        plan.units.npm['@youdotcom-oss/opencode'],
        bump,
        path,
        `bundled skill ${skillMatch[1]} changed`,
      )
      plan.units.npm['@youdotcom-oss/pi'] = updateReleaseUnit(
        plan.units.npm['@youdotcom-oss/pi'],
        bump,
        path,
        `bundled skill ${skillMatch[1]} changed`,
      )
      plan.units.npm['@youdotcom-oss/openclaw'] = updateReleaseUnit(
        plan.units.npm['@youdotcom-oss/openclaw'],
        bump,
        path,
        `bundled skill ${skillMatch[1]} changed`,
      )
      plan.units.npm['@youdotcom-oss/dsh-plugin'] = updateReleaseUnit(
        plan.units.npm['@youdotcom-oss/dsh-plugin'],
        bump,
        path,
        `bundled skill ${skillMatch[1]} changed`,
      )
      plan.units.clawhub.you = updateReleaseUnit(
        plan.units.clawhub.you,
        bump,
        path,
        `bundled skill ${skillMatch[1]} changed`,
      )
      continue
    }

    if (isPluginReleasePath(path)) {
      plan.units.plugins.you = updateReleaseUnit(plan.units.plugins.you, 'patch', path, 'plugin manifest changed')
      continue
    }

    for (const [name, packagePath] of Object.entries(npmPackages)) {
      const directory = dirname(packagePath)
      if (path.startsWith(directory)) {
        const isInitial = isInitialPackage(statuses, directory)
        plan.units.npm[name] = updateReleaseUnit(
          plan.units.npm[name],
          isInitial ? 'initial' : 'patch',
          path,
          isInitial ? 'new package: publish declared version as-is' : 'package implementation changed',
        )
        if (name === '@youdotcom-oss/openclaw') {
          plan.units.clawhub.you = updateReleaseUnit(
            plan.units.clawhub.you,
            isInitial ? 'initial' : 'patch',
            path,
            isInitial ? 'new package: publish declared version as-is' : 'OpenClaw package changed',
          )
        }
      }
    }
  }

  return plan
}

const validateReleaseUnit = (value: unknown, path: string): ReleaseUnit => {
  if (!isRecord(value) || !isBump(value.bump) || !isStringArray(value.paths) || !isStringArray(value.rationale)) {
    throw new TypeError(`${path} must be a release unit`)
  }

  return {
    bump: value.bump,
    paths: value.paths,
    rationale: value.rationale,
  }
}

const validateReleaseUnitGroup = (value: unknown, path: string) => {
  if (!isRecord(value)) {
    throw new TypeError(`${path} must be an object`)
  }

  return Object.fromEntries(
    Object.entries(value).map(([name, unit]) => [name, validateReleaseUnit(unit, `${path}.${name}`)]),
  )
}

const readReleasePlan = async ({ repoRoot, path }: { repoRoot: string; path: string }): Promise<ReleasePlan> => {
  const parsed: unknown = await Bun.file(resolve(repoRoot, path)).json()
  if (!isRecord(parsed) || parsed.schemaVersion !== 1 || !isRecord(parsed.units)) {
    throw new TypeError(`${path} must be a release plan`)
  }

  return {
    schemaVersion: 1,
    baseRef: typeof parsed.baseRef === 'string' ? parsed.baseRef : '',
    headRef: typeof parsed.headRef === 'string' ? parsed.headRef : '',
    generatedAt: typeof parsed.generatedAt === 'string' ? parsed.generatedAt : '',
    changes: isStringArray(parsed.changes) ? parsed.changes : [],
    units: {
      skills: validateReleaseUnitGroup(parsed.units.skills, 'units.skills'),
      plugins: validateReleaseUnitGroup(parsed.units.plugins, 'units.plugins'),
      npm: validateReleaseUnitGroup(parsed.units.npm, 'units.npm'),
      clawhub: validateReleaseUnitGroup(parsed.units.clawhub, 'units.clawhub'),
    },
  }
}

const readJson = async ({ repoRoot, path }: { repoRoot: string; path: string }): Promise<Record<string, unknown>> => {
  const parsed: unknown = await Bun.file(resolve(repoRoot, path)).json()
  if (!isRecord(parsed)) {
    throw new TypeError(`${path} must contain a JSON object`)
  }

  return parsed
}

const bumpJsonVersion = async ({ repoRoot, path, bump }: { repoRoot: string; path: string; bump: Bump }) => {
  const json = await readJson({ repoRoot, path })
  if (typeof json.version !== 'string') {
    throw new TypeError(`${path} must contain a version string`)
  }

  json.version = bumpVersion(json.version, bump)
  return { path, content: `${JSON.stringify(json, null, 2)}\n` }
}

const bumpMarketplaceVersion = async ({ repoRoot, path, bump }: { repoRoot: string; path: string; bump: Bump }) => {
  const json = await readJson({ repoRoot, path })
  const plugins = json.plugins
  if (!Array.isArray(plugins)) {
    throw new TypeError(`${path} must contain a plugins array`)
  }

  const plugin = plugins.find((item) => isRecord(item) && item.name === 'you')
  if (!isRecord(plugin) || typeof plugin.version !== 'string') {
    throw new TypeError(`${path} must contain a you plugin version string`)
  }

  plugin.version = bumpVersion(plugin.version, bump)
  return { path, content: `${JSON.stringify(json, null, 2)}\n` }
}

const bumpSkillVersion = async ({ repoRoot, skillName, bump }: { repoRoot: string; skillName: string; bump: Bump }) => {
  const path = `skills/${skillName}/SKILL.md`
  const content = await Bun.file(resolve(repoRoot, path)).text()
  const match = /^---\n([\s\S]*?)\n---/.exec(content)
  if (!match?.[1]) {
    throw new Error(`${path} must contain frontmatter`)
  }

  const frontmatter: unknown = Bun.YAML.parse(match[1])
  if (!isRecord(frontmatter) || !isRecord(frontmatter.metadata) || typeof frontmatter.metadata.version !== 'string') {
    throw new TypeError(`${path} must contain metadata.version`)
  }

  const version = bumpVersion(frontmatter.metadata.version, bump)
  const updated = content.replace(
    /^---\n([\s\S]*?\n {2}version: )\d+\.\d+\.\d+(\n[\s\S]*?\n---)/,
    `---\n$1${version}$2`,
  )
  if (updated === content) {
    throw new Error(`${path} metadata.version could not be updated`)
  }

  return { path, content: updated }
}

const writeUpdates = async (updates: { path: string; content: string }[]) => {
  for (const update of updates) {
    await Bun.write(resolve(defaultRepoRoot, update.path), update.content)
  }
}

const buildPackages = async () => {
  for (const directory of packageBuildDirectories) {
    await $`bun run build`.cwd(resolve(defaultRepoRoot, directory))
  }
}

export const createVersionUpdates = async ({ repoRoot, planPath }: { repoRoot: string; planPath: string }) => {
  const plan = await readReleasePlan({ repoRoot, path: planPath })
  const updates: { path: string; content: string }[] = []

  for (const [skillName, unit] of Object.entries(plan.units.skills)) {
    if (unit.bump !== 'none') {
      if (!(await Bun.file(resolve(repoRoot, `skills/${skillName}/SKILL.md`)).exists())) {
        continue
      }

      updates.push(await bumpSkillVersion({ repoRoot, skillName, bump: unit.bump }))
    }
  }

  const pluginUnit = plan.units.plugins.you
  if (pluginUnit?.bump && pluginUnit.bump !== 'none') {
    for (const manifest of pluginManifests) {
      updates.push(await bumpJsonVersion({ repoRoot, path: manifest, bump: pluginUnit.bump }))
    }

    for (const marketplace of pluginMarketplaces) {
      updates.push(await bumpMarketplaceVersion({ repoRoot, path: marketplace, bump: pluginUnit.bump }))
    }
  }

  for (const [name, unit] of Object.entries(plan.units.npm)) {
    const path = npmPackages[name as keyof typeof npmPackages]
    if (path && unit.bump !== 'none' && unit.bump !== 'initial') {
      updates.push(await bumpJsonVersion({ repoRoot, path, bump: unit.bump }))
      if (name === '@youdotcom-oss/openclaw') {
        updates.push(
          await bumpJsonVersion({ repoRoot, path: 'packages/openclaw/openclaw.plugin.json', bump: unit.bump }),
        )
      }
    }
  }

  return updates
}

const applyReleasePlan = async (planPath: string) => {
  const updates = await createVersionUpdates({ repoRoot: defaultRepoRoot, planPath })
  await writeUpdates(updates)
  await buildPackages()
}

const printUsage = () => {
  process.stderr.write(
    'Usage: bun scripts/semver-release.ts plan [--base HEAD~1] [--out /tmp/release-plan.json] | apply [--plan /tmp/release-plan.json]\n',
  )
}

const readArg = (name: string, fallback: string) => {
  const index = Bun.argv.indexOf(name)
  return index === -1 ? fallback : (Bun.argv[index + 1] ?? fallback)
}

const main = async () => {
  const command = Bun.argv[2]
  if (command === 'plan') {
    const baseRef = readArg('--base', process.env.RELEASE_BASE_REF ?? 'HEAD~1')
    const out = readArg('--out', '/tmp/agent-skills-release-plan.json')
    const plan = await createReleasePlan(baseRef)
    await Bun.write(resolve(defaultRepoRoot, out), `${JSON.stringify(plan, null, 2)}\n`)
    await Bun.write(Bun.stdout, `${JSON.stringify(plan, null, 2)}\n`)
    return
  }

  if (command === 'apply') {
    await applyReleasePlan(readArg('--plan', '/tmp/agent-skills-release-plan.json'))
    return
  }

  printUsage()
  process.exit(1)
}

if (import.meta.main) {
  await main()
}
