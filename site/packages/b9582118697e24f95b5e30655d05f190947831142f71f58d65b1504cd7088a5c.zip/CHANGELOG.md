# Changelog

All notable changes to the `stride-ideation` plugin are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Release record — tags without a GitHub release

*This is a record-keeping note, not a release. It describes no change to this plugin and carries no version.*

A fleet-wide audit found **1 tag** in this repository that is tagged and pushed but has no corresponding GitHub release. **The gap is accepted and will not be backfilled.** It is recorded here so the next release engineer does not rediscover and re-litigate it:

- `v0.1.0` — 2026-05-12

This is the plugin's original `v0.1.0` tag, cut at first publication before the release ritual settled.

Why accepted rather than backfilled:

- **Nothing resolved through this release.** A GitHub release is a human-readable record, not a resolution mechanism — nothing installs *through* one. The missing release cost nothing at the time and costs nothing now.
- **Backfilling would be worse than the gap.** A release created today against a commit from May would be dated today, and would manufacture a record for a state no user ever resolved through — misrepresenting the very history it claims to document.
- **The convention itself is unchanged.** This is an omission from one early cycle, not a policy shift. Every tag still gets a release going forward.

The audit also found **zero** GitHub releases without a matching tag, so the record is incomplete in only this one direction.

## [0.11.1] - 2026-08-21

A housekeeping release: no behavior change to `/ideate` or `/stridify`. The `lean` profile's README description stops defining itself by reference to a version number, and the repo now ignores the Stride agent's local credential file.

### Fixed

- **The `lean` profile row in the README's profile table described the profile as "byte-for-byte equivalent to v0.3.0 behavior".** That tells a reader what `lean` was, not what it does — and the reference gets less useful with every release that moves past it, since reconstructing v0.3.0's behavior means reading a changelog backwards. The cell now states the profile positively: `lean` adds no augmentations and runs the shared core only — the seven hard-gated sections plus the mandatory round-3 framing checkpoint, round-4 premortem, and challenge gate — with no extra forcing questions, no optional document sections, and no profile-specific reviewer checks. The other three rows already described themselves this way; `lean` was the odd one out.

### Security

- **`.stride_auth.md` is now in `.gitignore`.** The file holds a live Stride API token and is written into any repo where the agent workflow runs, this one included. Nothing had committed it, but the only thing standing between the token and a push was that nobody had run `git add -A` at the wrong moment.

## [0.11.0] - 2026-07-02

An accuracy-and-behavior release: the decomposer contract, calibration fixtures, and batch validator now all enforce and model the five review-queue scored fields; shipped goals are attributed via `created_by_agent`; and every stale doc claim surfaced by the audit is corrected. Eight entries below (W1460–W1467).

### Fixed — orphaned drift check reframed as a documented standalone helper (W1466)

`lib/run_smoke_test.sh` claimed it "composes every helper the slash command body invokes — in the same order" while its Stage 2 runs `drift_check.py`, a helper `/stridify` deliberately does not invoke (the command writes and POSTs the batch in one invocation, so source drift cannot occur — per stridify.md's "Drift check omitted" note). The header now says it exercises every shipped lib helper, command-invoked plus standalone, naming Stage 2's drift check as the standalone one; stage numbering and logic untouched. The README marks `drift_check.py` as a standalone consistency tool not wired into `/stridify`, explains when it is still useful (hand-edited or reused batch JSONs), and adds a verified usage example with the exit-code semantics. stridify.md unchanged.

### Fixed — stale removed-command references across the lib scripts (W1465)

Six lib files still cited the pre-merge `/stride-ideation:decompose` and `/stride-ideation:ship` commands (and `commands/decompose.md`, a file that no longer exists) in their headers and docstrings — stale pointers that turned test debugging into archaeology. All comment/docstring-only corrections: `test-stamping.sh` now points at `/stridify` (Step 6 computes the SHA; Step 8b stamps) and describes the drift check as historical and omitted; `test-ship-helpers.sh` describes its two helpers against the current `/stridify` steps (9a strip, Step 3 auth preflight) with a parenthetical explaining its legacy filename (not renamed — nothing external references it); `validate_batch.py`, `strip_audit_fields.py`, `run_smoke_test.sh`, and `filename.sh` docstrings/headers now name `/stridify` with current step anchors. Zero assertion changes — all 12 suites and the smoke test pass with identical counts.

### Added — batch validator scored-field warnings and length-limit checks (W1467)

Two new client-side checks in `lib/validate_batch.py` catch defect classes that previously sailed through local validation and failed opaquely (or invisibly) in production. A new fatal check `(f) length_limit` fails validation with the offending JSON path and length when a goal/task `title` or any `security_considerations` element exceeds 255 Unicode code points — exactly the fields the server binds to `varchar(255)`; `pitfalls` elements and `key_files` notes are deliberately excluded because they are JSONB (unbounded) on the server, so checking them would reject batches the API accepts. After all fatal checks pass, an advisory scored-field completeness pass warns on stdout (never changing the exit code) for any task whose review-queue scored field is missing or empty — surfacing empty-pill risk before the POST instead of after the goal ships; warnings go to stdout because stridify's Step 8a captures only stderr. `lib/test-validate-batch.sh` doubled from 15 to 30 assertions (multibyte CJK tests pin code-point-not-byte counting; missing-key vs empty-array vs whitespace-string warning shapes pinned; an ordering test proves warnings never precede a fatal exit; all three repo fixtures assert silent passes), and stridify.md's Step 8a documents the six checks plus the advisory pass accurately.

### Fixed — stale version, smoke-test, and test-count claims in README and submission audit (W1464)

Three factual refreshes, each in release-stable wording so they do not rot again. The README's Changelog section no longer names a specific "current release" (it pointed at v0.9.0 two releases back) — it now defers to the CHANGELOG's topmost entry. The README's smoke-test expectation ("five stages, ten ✓ markers, 10 passed, 0 failed" — the dry harness actually has six stages and reports 14/0) now describes the output shape with `0 failed` as the invariant and notes the live-POST stage runs only under `--live`. SUBMISSION-AUDIT.md's test-scripts row preserves the historically-accurate audit-time result (all 11 scripts then present passed, 2026-06-22) and appends a dated 2026-07-02 re-verification: 12 scripts, 168 assertions, 0 failures — real output quoted, not computed. CHANGELOG history untouched.

### Fixed — reviewer check-count contradiction and ideate enforcement-list omissions (W1463)

`agents/requirements-reviewer.md` said "All three checks are advisory" while the same file said "five conditional checks" and "All five checks" — the three was a v0.4.0-era count never updated when v0.5.0 added the two lean-startup checks; all three references now consistently say five. The `commands/ideate.md` "The skill enforces:" list carried the round-3 framing checkpoint as its own bullet but left the mandatory round-4 premortem and the lean-startup Round-5 MVP-design batch as mere timing anchors inside the challenge-gate bullet; each is now its own enforcement bullet (the round-5 bullet stating it is skipped under any profile other than `lean-startup`), matching how SKILL.md marks both Mandatory.

### Fixed — calibration fixtures now carry the five scored fields on every task (W1462)

The three fixture batch JSONs are the calibration reference for good decomposer output, yet none of their 35 tasks carried `testing_strategy` or `security_considerations`, and the notifications-system and replace-test-suite fixtures additionally omitted `pitfalls`, `patterns_to_follow`, and task-level `why`/`what`/`where_context` — anyone calibrating from them reproduced the empty-pill omission. Every task in all three fixtures now carries the five review-queue scored fields with scenario-realistic values (substantive security entries where a real surface exists — signed unsubscribe tokens, SMTP header-injection, PII in payloads — and the none-with-reason convention for measurement and styling tasks), and the two thin fixtures gained per-task `why`/`what`/`where_context` to match the dark-mode fixture's richness. Changes are strictly additive: task counts, titles, dependencies, and `source_spec`/`source_spec_sha256` are byte-identical; all three fixtures pass `lib/validate_batch.py`; the smoke test stays green (14/0). `fixtures/README.md` documents the new five-field invariant and clarifies that `source_spec_sha256` hashes the requirements doc, so field-only batch edits need no SHA bump.

### Added — created_by_agent stamped on shipped goals in the stridify pipeline (W1461)

Goals shipped through `/stridify` never carried `created_by_agent`, so the Stride agents activity feed attributed them to nobody — and because the field is create-only (forbidden on PATCH), every batch shipped without it was permanently unattributed. Step 8b now stamps `created_by_agent` on **every goal object** (the server propagates the goal value to nested child tasks) with the running agent's plain name, per the canonical creating-goals rule — the exact same value sent as `agent_name` on claim and complete. The stamp happens before the write/commit, so the committed batch artifact and the POST body both carry it identically; unlike the three root audit fields it is **never stripped** (`lib/strip_audit_fields.py` gains a guard comment forbidding it from the strip set, and `lib/test-stamping.sh` gains a two-goal stamp-then-strip round-trip regression proving survival plus audit-field removal). This fulfills the "stamps it at ship time" promise in the decomposer's do-not-emit list.

### Fixed — requirements-decomposer aligned on the five review-queue scored fields (W1460)

The decomposer agent was internally inconsistent about the task field set: its canonical skeleton documented `testing_strategy` but no worked example carried it, and `security_considerations` appeared exactly once (a type-shape aside) — in no skeleton, example, or callout — so an agent following the definition would never emit it, leaving empty review-queue pills on every task of every goal shipped through `/stridify`. The canonical task skeleton now carries all five scored fields (`acceptance_criteria`, `testing_strategy`, `security_considerations`, `pitfalls`, `patterns_to_follow`), with `security_considerations` annotated with the none-with-reason convention and the `testing_strategy` placeholders no longer modeling empty arrays. All four example task objects across the three worked examples gained realistic `testing_strategy` and `security_considerations` values in the existing voice. A new "The five review-queue scored fields (never omit these)" callout names the fields and the empty-pill consequence, mirroring the canonical stride plugin skills. `created_by_agent` joined the do-not-emit list (a runtime value the decomposer cannot know; stamped at ship time).

## [0.10.0] - 2026-06-26

Adds a **challenge gate** to the `/stride-ideation:ideate` loop — a mandatory, profile-independent step that stress-tests the design before the requirements doc is committed. The premortem (round 4) inverts the framing to surface the single most likely failure mode; the challenge gate is deliberately broader, auditing confidence in *every* assumption, scanning for blind spots the premortem misses, and forcing a comparison against real alternatives. Like the reviewer pass, it is advisory and never blocks the write.

### Added

- **The challenge gate — a new mandatory step in the ideation protocol** (`skills/stride-ideation/SKILL.md`). It runs after the round-4 premortem (and the Round-5 MVP-design batch under `profile=lean-startup`) and before the advisory reviewer pass, with four components: (1) an **assumption-confidence audit** that rates every Assumptions entry `high`/`medium`/`low`; (2) a **blind-spot scan** for unstated dependencies, omitted stakeholders, untested edge cases, and failure modes the premortem missed; (3) **alternative generation** producing two distinct alternative approaches; and (4) a **trade-off analysis** comparing the proposed design against the two alternatives across cost, risk, complexity, and timeline. The gate is profile-independent (identical under `lean`/`product`/`discovery`/`lean-startup`), runs even on `--continue`, and is advisory — the option set always includes an explicit **"Challenge nothing — write as-is"** choice, so it never blocks the write.
- **A new optional `## Design challenge` document section.** The gate's confidence ratings fold back into the `## Assumptions` entries in place (`(high)`/`(medium)`/`(low)` alongside the `(R)` riskiest marker); the blind spots, the two alternatives, and the trade-off comparison fold into this new optional section. Like `Sketch` and `Open questions` it is ungated and is **not** added to the round recap (which still lists only the seven hard-gated sections).
- **Command-surface wiring in `commands/ideate.md`.** The gate is added to the Step-5 mandatory-steps list (surfaced via a single multi-select `AskUserQuestion`, ≤ 4 questions) and the optional `## Design challenge` section plus the confidence-rated Assumptions are added to the Step-6 doc template.
- **A challenge-gate fixture and smoke/unit coverage.** `fixtures/2026-05-12T120300-saved-filters-challenge-gate-requirements.md` demonstrates the gate output (a `## Design challenge` section with two alternatives and a cost/risk/complexity/timeline trade-off, plus confidence-rated Assumptions). `lib/test-challenge-gate.sh` (8 assertions incl. three negative controls) and a new `Stage 6` in `lib/run_smoke_test.sh` assert the output shape offline (`run_smoke_test.sh` now reports `14 passed, 0 failed`).
- **README documentation** of the challenge gate in the `/ideate` flow (Session experience table) alongside the framing checkpoint, premortem, and reviewer pass.

## [0.9.0] - 2026-06-26

A documentation, packaging, and security-audit release that makes `stride-ideation` ready for public plugin-directory submission. There are **no functional changes** to `/stride-ideation:ideate` or `/stride-ideation:stridify` — runtime behavior is byte-for-byte identical to v0.8.0. Every change here is metadata, reviewer-facing documentation, or a recorded audit.

### Added

- **Reviewer-facing `SECURITY.md`.** A standalone security document describing exactly what the plugin runs on your machine, its single network egress (the `/stridify` `POST` of the decomposed batch to your configured Stride server), how the bearer token is read and never logged or committed, what is written to disk (only the requirements doc, the batch JSON, and the gitignored `.stride/` draft scratch file), and what the plugin deliberately does **not** do. The README's two security callouts and its Security section now link to it.
- **Completed `.claude-plugin/plugin.json` manifest for directory listing.** The manifest now carries the full set of fields a public listing needs — `author` (name, email, URL), `homepage`, `repository`, `license`, and `keywords` — alongside the existing name/description/version, so the plugin presents correctly in the directory.
- **`SUBMISSION-AUDIT.md` — a recorded credential-hygiene and packaging audit** of the repository (the baseline go/no-go evidence the README's Security section now references).
- **`SUBMISSION-READINESS.md` — a go/no-go submission checklist** capturing the resolved follow-ups (repo pushed, listing blurb trimmed, repository URL confirmed) so the directory submission is reproducible.

### Changed

- **The README is now directory-self-contained.** It no longer assumes the surrounding monorepo context: installation, prerequisites, the two commands, profiles, the resilience model, the smoke test, and security all read correctly when the plugin is viewed standalone on its own repository page, with cross-links to `SECURITY.md` and `SUBMISSION-AUDIT.md`.

### Security

- **Credential-hygiene sweep of the repository — all clear.** Audited the tracked files for accidentally committed secrets (no `.stride_auth.md`, no bearer tokens, no API keys); the result is recorded in `SUBMISSION-AUDIT.md`.
- **Audit: the install path does not overwrite a project-root context file (no fix needed).** Reviewed the Claude Code install path for the `AGENTS.md`-overwrite class of bug found in the OpenCode/Codex ideation installers. This plugin has no `install.sh`/`install.ps1`; it installs exclusively via the marketplace flow (`/plugin marketplace add cheezy/stride-marketplace` then `/plugin install stride-ideation@stride-marketplace`), which places the plugin inside Claude Code's managed plugin cache. `.claude-plugin/plugin.json` is a flat manifest (name, description, version, author, license, keywords) — it declares no hooks, no install scripts, and no directive that writes any file to the user's project root; `.claude-plugin/` contains only `plugin.json` (no `hooks.json`). The plugin ships no `AGENTS.md`/`CLAUDE.md`/context file, and commands/skills/agents are auto-discovered from the cache with "no further configuration needed." Conclusion: safe — no project-root context file is ever written or clobbered, so the managed-block guard applied to the OpenCode/Codex installers is unnecessary here.

### Migration

- **No migration needed.** This release changes only documentation, manifest metadata, and audit records. `/ideate` and `/stridify` behave exactly as in v0.8.0.

## [0.8.0] - 2026-06-15

This release turns `/stride-ideation:ideate` from a one-way interrogation into a guided, recoverable, human-in-control session, and adds a preview-and-approval gate to `/stride-ideation:stridify` so generated tasks are never shipped sight-unseen. Six `/ideate` session-experience features plus one `/stridify` safety gate. Every change is additive — `--profile=lean` (and flag-free) invocations remain byte-for-byte compatible with v0.7.0 on the happy path.

### Added

- **Per-round section-completeness recap on `/ideate` (`## Round recap` in `SKILL.md`).** Before every round — including round 1 (all empty) and the gap-fill rounds — the skill prints a compact recap of the seven hard-gated sections with a per-section `solid` / `thin` / `empty` status plus a one-line note of the round's target sections. It is **display-only narration**: never an extra `AskUserQuestion`, never changes the gate, the round order, or the `≤ 4`-questions budget. It lists only the seven gated sections (never profile-exclusive optional sections), so it renders identically under every profile. On `--continue`, inherited-substantive sections start at `solid`.
- **"I'm not sure — propose candidates" uncertainty path on every question (`## Uncertainty path` in `SKILL.md`).** Every gated-section question and every profile-specific forcing question (JTBD, Why-now, MVP design) now carries a first-class option, with phrasing identical across rounds, that flips the skill into teaching mode for that section: it proposes 2–4 concrete, topic-tailored candidate answers each with a one-line rationale, then the human picks, edits, or asks for a fresh batch. **Hard rule:** a proposed candidate can never auto-satisfy the gate — it counts as substantive content only after the human confirms one, and repeated picks keep proposing without ever silently filling a section. The option lives within a question, so it never breaches the `≤ 4` budget.
- **Profile recommendation when `--profile` is omitted on `/ideate`.** Instead of silently defaulting to lean, an omitted `--profile` now runs a single recommendation question before the rounds: a best-guess profile is offered first (labeled `(recommended)` with a one-line rationale), the other three as alternatives, defaulting to lean when inference is weak or the topic is ambiguous. An explicit `--profile` skips the recommendation entirely, the unknown-value fast-fail is unchanged, and a resolved `lean` is byte-for-byte identical to passing `--profile=lean`.
- **`--input <file>` brain-dump seed on `/ideate`.** A new optional flag (both `--input <path>` and `--input=<path>` forms), distinct from `--continue`: `/ideate` reads the freeform notes file **read-only**, pre-populates draft sections wherever the notes clearly map to a gated section, then focuses the rounds on the gaps. The input file is never written, moved, or `git add`-ed, and its contents are treated as untrusted prose (never executed/eval'd, never echoed into a commit message or log). `--input` and `--continue` are independent and composable; seeded content never satisfies a hard gate on its own — every pre-filled section is still confirmed with the human in the rounds.
- **Intra-session draft autosave and resume on `/ideate` (new `lib/draft.sh`).** The in-progress draft (answered sections + round state) is now autosaved after every round to a **gitignored** scratch file under `.stride/`, so an interruption mid-session is recoverable rather than losing every answer (previously nothing was written until the hard gate passed). On `/ideate` start, an unfinished draft for the **same slug** is detected and the human is offered resume-or-fresh; on a successful commit the scratch file is deleted. `lib/draft.sh` is a pure-shell helper mirroring `lib/filename.sh`: `sti_draft_path`, `sti_draft_find` (resume keys on the slug, with a dash-delimited glob so `auth` never matches `oauth`, ignoring empty/partial drafts), `sti_draft_save`, `sti_draft_load`, `sti_draft_exists`, `sti_draft_clear`. `.stride/` is added to `.gitignore`; the scratch file never holds the Stride API token or any secret.
- **Advisory reviewer findings surfaced as an explicit human decision on `/ideate` (`## Reviewer pass` in `SKILL.md`).** When the `requirements-reviewer` returns `verdict: "issues_found"`, the skill now presents the findings as a single multi-select `AskUserQuestion` — one line per finding, tagged with its `severity` (`blocking` / `advisory`) and `section` — including an explicit **"Address none — write as-is"** choice. The human chooses which findings feed the single refinement round. Both load-bearing contracts are preserved and stated explicitly: **at most one** refinement round (never a second, no matter how many findings are selected) and the reviewer **never blocks the write** (write-as-is is always available, so even `blocking`-severity findings cannot hold the document hostage). An `approved` verdict with zero findings shows no prompt at all.
- **Human preview-and-approval gate before the `/stridify` POST, with a `--yes` bypass (new Step 8.5 in `commands/stridify.md`).** Between writing/committing the batch JSON (Step 8) and POSTing it (Step 9), `/stridify` now renders the decomposed goal/task tree — each goal title, its task count, its task titles, and the cross-goal claim order from `decomposition_notes` — and requires explicit human approval before the POST. A new `--yes` / `--auto-approve` flag (explicit only, never inferred) bypasses the gate, preserving the historical fire-and-forget behavior byte-for-byte for scripted callers. On decline the command stops cleanly (exit 0) leaving the already-committed batch JSON untouched on disk as the recovery artifact — no POST is attempted. The preview reads only the on-disk JSON and never prints the API token.

### Test coverage

- **`lib/test-stridify-preview.sh`** (14 assertions) — `--yes` / `--auto-approve` parse in both presence forms + absence, the bypass path reaching the POST with no prompt, the decline path attempting no POST and leaving the on-disk JSON byte-for-byte unchanged (SHA-asserted), the approve path reaching the POST, the multi-goal task-count + cross-goal claim-order render, the single-goal scoped render, and a token-hygiene guard.
- **`lib/test-ideate-input.sh`** (11 assertions) — `--input` parse (both forms) and consumption, file-exists validation (happy + missing-file → one-line error + non-zero), the read-only invariant (input file SHA unchanged + still present), the `--input`/`--continue` precedence, and the empty-file → fresh-session fallback.
- **`lib/test-draft.sh`** (21 assertions) — deterministic path generation, save/load round-trip, the non-empty `exists` predicate, idempotent `clear`, `find` (same-slug-only, `auth`-vs-`oauth` non-collision, latest-timestamp-wins, empty-only ignored, absent-dir safe), the `mkdir`-failure branch, and the three edge cases (no file → fresh, empty/partial → fresh, two slugs → only matching).

Full plugin test suite is now **155 assertions across 11 sibling suites, all green** (up from 109 across 8).

### Migration

- **No migration needed; back-compat is preserved on the happy path.** A flag-free or `--profile=lean` `/ideate` invocation behaves as in v0.7.0 except for the additive session affordances (the recap is display-only; the uncertainty path is an extra option, never forced; the reviewer decision replaces a silent skill choice but keeps the one-round cap and never blocks the write; autosave writes only to a gitignored scratch path). The profile recommendation runs only when `--profile` is omitted and resolves to the same `lean` default if the user accepts it.
- **`/stridify` gains a human gate by default — scripted callers must pass `--yes`.** This is the one behavior change that affects automation: a non-interactive `/stridify` invocation that previously POSTed immediately will now pause for approval unless `--yes` / `--auto-approve` is supplied. Under `--yes` the flow is byte-for-byte identical to v0.7.0. Interactive users get the preview-and-approval gate automatically.
- **New gitignored directory.** `.stride/` is now used for intra-session draft autosave and is added to `.gitignore`; it is never committed and never holds secrets.

## [0.7.0] - 2026-05-20

### Added

- **Bounded subagent-dispatch retry on `/stride-ideation:stridify` Step 7.** The `Agent` dispatch is now wrapped in a 3-attempt retry loop with ~30s / ~90s backoff (total budget ~2 min) when the failure classifies as transient (HTTP 529 Overloaded, transient network error like DNS / connection refused / timeout / TLS handshake, or an explicit `overloaded` classification string). Terminal classifications (bad `subagent_type`, hard 4xx other than 529, contract violation — no fenced JSON, multiple ambiguous fenced blocks, or unparseable JSON inside the fence) still fail fast on attempt 1; retrying would not change the result. The Stride API POST in Step 9 is unchanged — it is **not** retried, for per-task idempotency reasons documented in Step 9's "No retries." paragraph.
- **`--goal <name|index>` flag on `/stride-ideation:stridify` for per-seam decomposition.** Optional flag that scopes the decomposer dispatch to a single surface from the requirements doc's `## Decomposition seams` section. Resolution accepts both 1-based integer indices and slug-matching strings (case-insensitive, hyphen-tolerant); both `--goal <value>` and `--goal=<value>` forms parse identically to `/ideate`'s `--continue` and `--profile` flags. Errors loudly on no-match with a listing of the available seams; errors when the seams section is absent or empty AND `--goal` was set. Per-goal runs produce a sibling batch JSON named `<source-slug>-<goal-slug>-stride-batch.json` and a commit message that names the goal. Three new helpers in `lib/filename.sh`: `sti_extract_seams`, `sti_resolve_goal`, `sti_scope_doc_to_seam`. The seams section itself remains freeform and emergent — the ideation skill does NOT gate it.
- **Retry-exhaustion fallback (new Step 7.5).** When the Step 7 retry loop hits its 3-attempt cap with all transient failures, `/stridify` writes a sibling `<source-stem>-decomposer-prompt.md` file next to the requirements doc containing: an ISO8601 timestamp, the source path + SHA-256, the per-goal scope (or "all goals"), the verbatim last subagent error, the literal assembled prompt fenced in a four-backtick block (so the prompt's own ` ```json ` fences nest cleanly), and a recovery README naming the next concrete action (paste into a fresh Claude session, save the response as the computed target path, then run `lib/validate_batch.py` and the manual POST per Step 9). The Stride API POST is **not** attempted in this branch — Steps 8 and 9 are both skipped. The saved file contains no auth material; `sti_unique_path`'s `-2`/`-3` discriminator prevents overwrites on repeat exhaustions.
- **Preflight advisory for many-surface decompositions (Step 2 sub-check 4).** When a doc contains a `## Decomposition seams` section enumerating more than 3 surfaces AND `--goal` is not set, `/stridify` prints a single advisory line to stderr suggesting the user run `/stridify --goal <name|index>` N times instead. Max-across-shapes count heuristic (level-3 headings / numbered items / bulleted items) avoids over-counting when the section mixes a primary numbered list with secondary cross-cutting bullets. The advisory is informational only — never blocks execution.
- **`## Resilience model` subsection in `commands/stridify.md`** that summarizes the four layers in execution order (preflight advisory → per-goal partitioning → subagent-dispatch retry → retry-exhaustion fallback) and explicitly contrasts the new "retry the subagent" policy with the unchanged "do not retry the POST" policy.

### Changed

- **`commands/stridify.md` "What this command does NOT do" section.** The historical "Retry on transient failures — fail fast" bullet is now split into a more specific "Retry the Stride API POST on transient failures" bullet that explicitly distinguishes POST retry (still NO — partial-batch idempotency risk) from subagent dispatch retry (now YES, with bounded exponential backoff — subagent dispatch has no Stride-side side effects). A new bullet documents that the on-disk goal title is not re-validated against the requested `--goal` value (semantic-match check is out of scope; root-shape gating in Step 8a is unchanged).
- **`skills/stride-ideation/SKILL.md` "What this skill does NOT cover" section.** The existing `/stridify` bullet now enumerates the four resilience features so a reader learns about them when reading about the downstream command. The strict three-line "Terminal state" prints-exactly contract is preserved unchanged — none of the new behavior changes how the ideation skill exits.
- **`commands/ideate.md` Step 6.** Added a new paragraph after the gated/optional sections discussion that names the freeform `## Decomposition seams` section, gives the canonical shape (`1. **Surface name** — description`), and cross-links to `/stride-ideation:stridify --goal <name|index>` for per-surface dispatch. This puts the cross-link where the user is naturally authoring a many-surface requirements doc — discovery-natural rather than buried in a separate "advanced usage" page.

### Test coverage

- **`lib/test-stridify-retry.sh`** — 13 assertions covering retry classification (transient / terminal / success), 2× transient → success on attempt 3, 3× transient → exhaust with verbatim last-error, contract-violation fail-fast on attempt 1, and a log-conciseness assertion guarding the "no prompt echo on retry" pitfall.
- **`lib/test-stridify-per-goal.sh`** — 21 assertions covering integer-index resolution, slug-match resolution including hyphenated slugs, both `--goal value` and `--goal=value` parse forms, verbatim "no seams section" and "did not match" errors, the integer-vs-slug heuristic on a seam literally named `"1"`, multi-line item bodies, items missing the `**bold**` marker, target-path construction with and without `--goal`, conditional commit message, repeat-invocation `-2` suffix, and prompt-scoping output structure (matched item present, other items dropped, sections outside seams preserved).
- **`lib/test-stridify-fallback.sh`** — 16 assertions covering file-write at the expected sibling path, all required sections + source SHA + verbatim last error + literal prompt body, POST sentinel absent, `-2` re-invocation suffix on repeat exhaustion, per-goal scope reflected in both filename and metadata, terminal recovery summary content, and regression guards for token leakage and partial-batch-JSON.

Full plugin test suite is now 109 assertions across 8 sibling suites, all green.

### Migration

- **No migration needed; back-compat is preserved.** Without `--goal`, `/stridify` behavior is byte-identical to v0.6.0 — the retry loop activates only on transient failures (previously a single failure would have aborted), the fallback only when retries exhaust (previously the same condition would have aborted), and the preflight advisory is purely informational. Existing requirements docs work unchanged; the `## Decomposition seams` section is only required when `--goal` is invoked.
- **No command-surface breaking changes.** Both slash commands accept all their v0.6.0 arguments unchanged. The new `--goal` flag is strictly additive on `/stridify`.

## [0.6.0] - 2026-05-14

### Changed

- **Default output directory moved from `docs/superpowers/specs/` to `docs/ideation/`.** New requirements documents written by `/stride-ideation:ideate` and new decomposition JSON files written by `/stride-ideation:stridify` land under the new directory. The name change is the substantive one — `docs/ideation/` is shorter, doesn't borrow the `superpowers` name from an unrelated upstream skill, and reads more naturally to a first-time user.
- Three files updated, all pure string replacements — the `lib/filename.sh` helpers are path-agnostic, so no helper edits were needed:
  - `commands/ideate.md` — 4 references (command description, the `sti_unique_path` call documented in Step 4, the `TARGET_PATH` example, and the `mkdir -p` line in Step 8).
  - `agents/requirements-decomposer.md` — 1 example path inside the agent description.
  - `lib/test-filename.sh` — 1 fixture path on line 108. All 18 test assertions still pass.

### Migration

- **No migration needed. Back-compat is preserved for `/stride-ideation:stridify`.** The command takes the requirements doc path as an argument, not a hardcoded scan target — so existing requirements docs already on disk under `docs/superpowers/specs/` continue to work as `/stridify` inputs. Only **new** docs land under the new directory. Users with an existing `docs/superpowers/specs/` tree can leave it in place indefinitely; no rename, no symlink, no migration script.
- **No command surface changes.** The two slash commands and their arguments are byte-identical to v0.5.0. Only the default output directory changed.
- **Profile behavior is unchanged.** All four profiles (`lean`, `product`, `discovery`, `lean-startup`) work identically to v0.5.0 — the directory change is orthogonal to round structure and reviewer rubric.

## [0.5.0] - 2026-05-13

### Added

- **`lean-startup` profile on `/stride-ideation:ideate --profile`.** A fourth named profile that extends the `--profile` enum introduced in v0.4.0 (parser shape unchanged — only the valid-value set grows). Pick this profile when the topic is a genuinely novel feature, the team is uncertain whether the underlying user need actually exists, and the next step should be a deliberate validation experiment rather than a full build. Source techniques:
  - **Eric Ries, *The Lean Startup*** — the Build-Measure-Learn cycle as the unit of progress on a project whose hypotheses are not yet validated. The Round-5 batch operationalizes that cycle around a single riskiest assumption rather than the project as a whole.
  - **Steve Blank, *Customer Development*** — get out of the building and validate the riskiest assumption before scaling the build. Round 5 forces the user to design an experiment whose result triggers a deliberate pivot-or-persevere decision, not a "ship and see" outcome.
  - **Giff Constable, *Riskiest Assumption Test* (RAT)** — already cited in v0.3.0 for the `(R)`-marker convention on the ranked Assumptions list. v0.5.0 turns that marker into the explicit anchor of a designed experiment: the Round-5 prompt MUST lift the `(R)`-marked entry verbatim and use it as the assumption-to-test.
- **Mandatory Round 5: MVP design (lean-startup profile only).** A new round inserted between the round-4 premortem and the advisory reviewer pass. Runs as a single batched `AskUserQuestion` (≤ 4 questions — the same hard upper bound as every other round) whose answers describe the smallest experiment capable of validating or falsifying the `(R)`-marked assumption. The four questions are: (Q1) what observable signal would prove the riskiest assumption wrong? (Q2) what's the smallest/fastest thing you could build, fake, or measure to produce that signal? (Q3) how long would the experiment take and what does it cost? (Q4) what pivot-or-persevere decision will the result trigger? If no Assumptions entry is marked `(R)` (e.g., refining a pre-G104 doc under `--continue`), the round falls back to lifting the topmost entry as the anchor and notes the missing marker inline rather than aborting. Round 5 runs even on `--continue` mode under this profile — gap-fill is exactly when it catches things.
- **Optional `MVP / Validation experiment` section in the requirements doc.** Unlocked exclusively under `profile=lean-startup`. The section opens by quoting the `(R)`-marked Assumptions entry verbatim, then lists five authored sub-fields: experiment design (what to build, fake, or measure), success criteria (observable signal that validates), failure criteria (observable signal that falsifies), time box (when results are expected), and pivot-or-persevere decision (what happens based on result). The section is optional (not part of the seven hard-gated sections) and is never gated — its absence under `lean-startup` is a reviewer advisory, not a write-blocker.
- **Two new profile-aware advisory checks in `agents/requirements-reviewer.md`** — (a) **MVP / Validation experiment presence** flags an absent or thin MVP section under `lean-startup`, and an MVP section appearing under any other profile; (b) **falsifiable success/failure criteria** flags obviously non-falsifiable language ("users will love it", "it will be fast enough", "people will use it") in the Success/Failure criteria sub-fields. Both checks are advisory only, never blocking — they extend the existing rubric and do NOT introduce a new hard-block path. The reviewer's calling contract (at most one refinement round; never edits the document) is unchanged.

### Changed

- The round-summary table in `skills/stride-ideation/SKILL.md` splits the former Round 5+ row into a new Round 5 (MVP design — lean-startup only) and a renumbered Round 6+ (gap-fill). The default-focus column remains identical across all four profiles; only the augmentations column and the `lean-startup`-specific Round-5 attendance change.
- The Profiles subsection in `skills/stride-ideation/SKILL.md` grows from three bullets to four, and the Optional auxiliary sections list grows from three entries to four. The exclusivity prose now notes that Concrete Example and MVP / Validation experiment never overlap — a single document is produced under exactly one profile and may include at most one of these two profile-exclusive sections.
- The plugin description in `.claude-plugin/plugin.json` and the slash-command frontmatter on `commands/ideate.md` now enumerate the four profile values (`lean|product|discovery|lean-startup`).
- The README Profiles table gains a fourth row for `lean-startup` documenting when to pick it and what it adds.

### Migration

- **No migration needed. The existing three profiles (`lean`, `product`, `discovery`) and the default `lean` behavior are unchanged** — `/stride-ideation:ideate` invocations that omit `--profile` or pass any of the three v0.4.0 values are byte-identical under v0.5.0. Backward compatibility under every pre-existing profile is a load-bearing claim of this release.
- **No command surface changes beyond the new `--profile` enum value.** The two slash commands (`/ideate`, `/stridify`) and their existing arguments are byte-identical to v0.4.0. The new `lean-startup` value is purely additive.
- **In-flight v0.4.0 requirements docs** (docs produced under `lean`, `product`, or `discovery`) are valid v0.5.0 documents — no rework needed. The `MVP / Validation experiment` section MUST NOT appear in such docs and a v0.5.0 reviewer will flag it as profile drift if it does.

## [0.4.0] - 2026-05-13

### Added

- **`--profile <name>` flag on `/stride-ideation:ideate`.** Selects one of three named profiles that shape which forcing questions run inside the rounds and which optional sections the document may include. The seven hard-gated section names and the mandatory round-3 framing and round-4 premortem are identical across all profiles — only the augmentations change. Pick a profile based on the audience and the part of the framing that's riskiest:
  - **`lean`** (default). The bare-minimum round structure — no profile-specific forcing questions, no profile-specific optional sections, no profile-specific reviewer checks. Use for engineering-only audiences, small topics, and the shortest path to a committed doc. Byte-for-byte equivalent to v0.3.0 behavior.
  - **`product`**. Adds a Round-1 JTBD (jobs-to-be-done) four-forces forcing question framing Problem and Goal around the user's job, the forces pulling them toward and away from a solution, and the habits they're abandoning. Unlocks an optional **Concrete Example** section (named user, trigger, current bad path, desired good path). The advisory reviewer rubric gains two profile-aware checks (JTBD framing presence, Concrete Example presence). Source technique: Clayton Christensen + Bob Moesta's *Jobs to Be Done* — for product/design audiences, persona-bound scenarios beat feature lists for framing trade-offs.
  - **`discovery`**. Adds a Round-2 Why-now + Alternative-options forcing question that asks what makes this problem worth solving *now* (versus later) and which other options were considered and rejected. The advisory reviewer rubric gains one profile-aware check (Why-now content presence). The Why-now content folds into the existing Problem and Assumptions sections — no new optional section. Source techniques: the Sequoia "Why now?" memo tradition (urgency-of-timing as a first-class section of an investment thesis) and Specification by Example's emphasis on naming alternatives that were rejected (Gojko Adzic).
- **Profile-aware advisory checks in `agents/requirements-reviewer.md`.** Three new conditional checks: Concrete Example presence (product-only), JTBD-derived Problem framing (product-only), Why-now content (discovery-only). All three are advisory, never blocking — they extend the existing advisory rubric and do NOT introduce a new hard-block path. The reviewer's calling contract (at most one refinement round; never edits the document) is unchanged.

### Changed

- The round-summary table in `skills/stride-ideation/SKILL.md` gains a per-profile **augmentations** column. The default-focus column is identical across all profiles — only the augmentations differ. Under `lean`, the augmentation column is empty (byte-for-byte v0.3.0).
- The plugin description in `.claude-plugin/plugin.json` and the slash-command frontmatter on `commands/ideate.md` now mention the `--profile` flag and name the three profiles.
- The README gains a Profiles subsection (one paragraph + a three-row table) showing what each profile adds and when to pick it.

### Migration

- **No migration needed.** `--profile` is optional and defaults to `lean`. v0.3.0 invocations of `/stride-ideation:ideate` are byte-identical under v0.4.0 — the round loop, the seven gated sections, the round-3 framing, the round-4 premortem, and the advisory reviewer pass all behave exactly as in v0.3.0 when the flag is omitted. Backward compatibility under the default profile is a load-bearing claim of this release.
- **No command surface changes beyond the optional flag.** The two slash commands (`/ideate`, `/stridify`) and their existing arguments are byte-identical to v0.3.0. The new flag is purely additive.
- **In-flight v0.3.0 requirements docs** (docs that pass the v0.3.0 hard gate but were produced without an explicit profile) are valid v0.4.0 lean documents — no rework needed.

## [0.3.0] - 2026-05-13

### Added

- **Round 4 — Premortem (mandatory).** After the round-3 framing checkpoint and before the advisory `requirements-reviewer` pass, `/stride-ideation:ideate` now runs a single batched premortem question that asks the user to invert the framing ("imagine it's six months after we ship and this initiative quietly underperformed — what's the most likely reason?"). The answer is folded into the Assumptions section as one or more failure-mode entries. Source technique: Gary Klein's *premortem* (Harvard Business Review, 2007) — the round-1-to-3 loop reliably surfaces expected design properties rather than the failure modes the design depends on NOT happening, and the premortem inverts that bias before the doc is committed. The round runs even on `--continue` mode — refining a v0.2.0 doc is exactly when the premortem catches things, so there is no skip carve-out.
- **Riskiest-assumption ranking.** The Assumptions section is now hard-gated on shape, not just presence: entries must be ordered highest-to-lowest risk and exactly one must be marked `(R)` (or `**(riskiest)**`). Either marker form is accepted by the reviewer rubric. The marker is what makes the ranking auditable — a sorted list with no marker reads the same as an unsorted one. Source technique: Giff Constable's *riskiest assumption test* (RAT) — focusing scarce validation effort on the one assumption whose failure changes the design more than any other.
- **Leading + lagging Success Metrics.** The Success Metrics section is now hard-gated on shape: it must contain at least one leading indicator (observable while the work is in flight, predicts the outcome) AND at least one lagging indicator (the outcome itself, observable only after it has occurred). All-leading or all-lagging metrics fail the gate. Source technique: leading-vs-lagging indicator literature commonly cited in the OKR / KPI world — all-lagging metrics can only be observed after it is too late to correct, and all-leading metrics never confirm the outcome itself.

### Changed

- `requirements-reviewer.md` rubric: the **Assumptions** row gains two advisory checks (no entry appears premortem-derived; no entry is marked riskiest) and the **Success Metrics** row gains one advisory check (only leading-or-only-lagging indicators). All three additions are advisory-only — they extend the existing advisory rubric and do NOT introduce a new hard-block path. The reviewer's calling contract (at most one refinement round; never edits the document) is unchanged.
- The round-summary table in `skills/stride-ideation/SKILL.md` is reshaped: Round 4 is now Premortem; gap-fill moves to Round 5+. Round 5+ remains a single bucket — no further structural slicing.
- The skill `description:` frontmatter field is updated to mention the mandatory round-4 premortem and the new shape requirements on Assumptions and Success Metrics; the seven required-section names themselves are unchanged.

### Migration

- **In-flight v0.2.0 requirements docs** (docs that pass the v0.2.0 hard gate but pre-date the new shape requirements) will fail the v0.3.0 reviewer rubric with three advisory findings — they will NOT be hard-blocked from being written or stridified, but the new advisory pass will flag the gaps. To bring an existing doc up to v0.3.0:
  ```bash
  /stride-ideation:ideate --continue path/to/<existing>-requirements.md
  ```
  The `--continue` mode preserves the existing content as read-only context and emits a sibling timestamped doc with the round-4 premortem run, the Assumptions ranked, and any missing indicator type added to Success Metrics. The source doc is never modified.
- The on-disk template in `commands/ideate.md` Step 6 has changed: the Success metrics block now shows labeled leading / lagging sub-bullets, and the Assumptions block shows ordered entries with a `(R)` marker on the riskiest. Documents written prior to v0.3.0 do not match this template but remain valid input to `/stride-ideation:stridify` — the decomposer only requires the seven gated sections to be present and substantive.
- **No command surface changes.** The two slash commands (`/ideate`, `/stridify`) and their argument shapes are byte-identical to v0.2.0.

## [0.2.0] - 2026-05-13

### Changed

- **BREAKING: Three-command surface collapsed to two.** The standalone `/stride-ideation:decompose` and `/stride-ideation:ship` commands are removed; both flows are merged into a single new command `/stride-ideation:stridify <path-to-requirements.md>` that runs the full pipeline end-to-end (validate → preflight auth → dispatch decomposer → stamp audit metadata → write + commit batch JSON → strip audit fields → POST → render G/W identifiers). The intermediate `*-stride-batch.json` artifact and its commit are preserved exactly as before — the merge is a UX collapse, not a data-model change.
- **Auth read is now a preflight step** (Step 3 of `/stridify`, before the decomposer dispatch) so a misconfigured `.stride_auth.md` fails fast without first burning a subagent pass and writing a batch JSON that can't be shipped. The historical `/ship`-side late auth read is gone.
- **Drift check removed.** The historical `/ship` command ran a `source_spec_sha256` drift check to catch the case where a user hand-edited the requirements doc between `/decompose` and `/ship`. In the merged `/stridify` flow the batch JSON is written by the same invocation, so source drift cannot have occurred and the check is omitted with an explicit one-line justification in the command body.
- **`requirements-decomposer` and `requirements-reviewer` agents are unchanged** — only the outer command surface changes. The `lib/` helpers (`validate_batch.py`, `read_auth.py`, `strip_audit_fields.py`, `filename.sh`) are reused verbatim by `/stridify`. `lib/drift_check.py` is no longer called by any shipping command (all 7 of its unit tests still pass; left in place for potential future reuse).
- All internal cross-references (in `commands/ideate.md`, `skills/stride-ideation/SKILL.md`, both agent prompts, the fixture README + smoke-test note, and the marketplace manifest description) have been updated to reference `/stride-ideation:stridify`.

### Migration

- Replace any scripted invocations of the old two-command form with the new one-command form:
  - Before: `/stride-ideation:decompose <doc>` then `/stride-ideation:ship <batch-json>`
  - After: `/stride-ideation:stridify <doc>` (one invocation, same on-disk artifacts as before)
- If you previously ran `/stride-ideation:decompose` and want to ship the existing on-disk batch JSON without re-decomposing, the old `/ship`-style invocation is no longer available. The `lib/strip_audit_fields.py` and `curl … /api/tasks/batch` paths are still available as a manual escape hatch — the recipe is documented inline in `commands/stridify.md` Steps 9a-9c.
- Re-installation: `/plugin update stride-marketplace` once the marketplace manifest catches up to the renamed plugin entry, OR `/plugin uninstall stride-ideation` then `/plugin install stride-ideation@stride-marketplace` for a clean re-install.

## [0.1.0] - 2026-05-12

Initial public release. Distributed via [stride-marketplace](https://github.com/cheezy/stride-marketplace); install with:

```text
/plugin marketplace add cheezy/stride-marketplace
/plugin install stride-ideation@stride-marketplace
```

### Added

- **`/stride-ideation:ideate [<topic>] [--continue <path>]`** — interactive ideation command. Captures the session timestamp once at invocation, runs the round-based question loop defined in `skills/stride-ideation/SKILL.md` (≤ 4 batched `AskUserQuestion` per round; mandatory round-3 framing checkpoint; seven hard-gated requirements sections), auto-dispatches the `requirements-reviewer` subagent for an advisory pass, then writes and commits a timestamped `*-requirements.md`. The terminal state is the written doc — the command does NOT auto-invoke `/decompose`. `--continue <path>` refines an existing requirements doc in read-only mode (source file is never modified) under a fresh timestamp.
- **`/stride-ideation:decompose <path>`** — converts a requirements doc into a Stride batch JSON document. Validates that all seven hard-gated sections are present in the source doc, dispatches the `requirements-decomposer` subagent, stamps `source_spec` + lowercase `source_spec_sha256` at the JSON root for drift detection, runs the structural validator (`lib/validate_batch.py`), and writes a timestamped sibling file at the same prefix as the requirements doc.
- **`/stride-ideation:ship <path>`** — POSTs a Stride batch JSON to `/api/tasks/batch`. Validates structure, runs the source-spec drift check (`lib/drift_check.py`) and prompts the user on mismatch with `[y/N]` default-no, reads auth from `.stride_auth.md` via `lib/read_auth.py`, strips the three local-audit fields from the in-memory payload via `lib/strip_audit_fields.py` (the on-disk file is never modified), POSTs with token hygiene (no `curl -v`, no token in logs or error messages), surfaces 4xx / 5xx response bodies verbatim, and renders the created G / W identifiers in a two-column table on success.
- **`skills/stride-ideation/SKILL.md`** — the ideation protocol contract: seven hard-gated sections (Goal, Problem, Outcome, Assumptions, Constraints, Non-goals, Success Metrics), batched questioning loop, round-3 framing checkpoint, advisory reviewer pass before commit, neutral terminal state. Replaces the `superpowers:brainstorming` skill for Stride projects.
- **`agents/requirements-decomposer.md`** — subagent prompt that turns a requirements doc into a Stride batch JSON. Embeds the canonical batch shape, the four most common batch-API mistakes (root key `goals` not `tasks`; `verification_steps` as object array; `dependencies` by array index within a goal; `key_files` as object array), the two-reason multi-goal split rule (code-coupling + ~10-task soft cap), and the explicit do-not-emit list of orchestrator- and server-controlled fields. Worked examples cover single-goal, multi-goal independent, and 14-task multi-goal coupled shapes.
- **`agents/requirements-reviewer.md`** — advisory subagent prompt that audits a draft requirements doc against a calibrated rubric covering all seven hard-gated sections + five cross-section consistency checks. Returns a single fenced JSON document; never edits the doc; never demands more than one refinement round.
- **`lib/`** — pure helpers that the slash commands compose: `filename.sh` (slug + unique-path generation with collision discriminator), `validate_batch.py` (five named structural-validity checks with path-precise error messages), `drift_check.py` (source-spec drift detection with three exit codes), `read_auth.py` (auth extraction with token-leak hardening and onboarding-doc links), `strip_audit_fields.py` (in-memory removal of local-audit fields; on-disk file unchanged).
- **`fixtures/`** — three paired requirements docs + batch JSONs demonstrating small / multi-goal independent / 14-task multi-goal coupled decomposition shapes. Each batch passes the structural validator; each `source_spec_sha256` matches the actual SHA of its paired requirements doc.
- **`lib/run_smoke_test.sh`** — end-to-end pipeline driver. Dry mode (default) composes every helper the slash commands invoke with deterministic fixture inputs and a canned 2xx response; `--live <path>` adds a real HTTP POST against the Stride instance in `.stride_auth.md`. 36 unit tests across the per-helper harnesses (`lib/test-*.sh`) plus 10 dry-mode composition stages.
