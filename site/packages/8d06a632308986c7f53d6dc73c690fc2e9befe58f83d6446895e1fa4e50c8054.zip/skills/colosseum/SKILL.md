---
name: "Colosseum"
description: "Adversarial multi-agent debate grounded in live web searches. Agents fact-check each other's claims, concede when proven wrong, and reach consensus or force a verdict after 5 rounds. Triggers: 'colosseum', '여러 AI에게 물어봐', 'AI 토론', '비판적으로 분석', '다양한 관점'"
author: "최진호"
created: "2026-03-17"
updated: "2026-04-04"
category: "Research"
tags:
- "multi-ai"
- "critical-thinking"
- "adversarial-debate"
- "synthesis"
- "web-search"
- "fact-checking"
version: "2.0.0"
related_skills:
- "deep-research"
- "validate"
- "code-review"
---

# COLOSSEUM

> 에이전트들이 서로를 웹서치로 팩트체크하며 합의에 도달하거나 5라운드 후 강제 합성한다.

---

## 실행 전제조건

```bash
which gemini && gemini --version 2>/dev/null
which gh     && gh copilot --version 2>/dev/null
which aichat && aichat --version 2>/dev/null
which llm    && llm --version 2>/dev/null
```

가용 CLI 0개 → Claude 단독 다관점 모드 (하단 참조).

---

## Prime Directive (모든 에이전트 공통 적용)

성능 평가 기준: 다른 에이전트와의 동의(agreement)가 아닌 사실적 정확성(factual accuracy).
동조 없이 독립적 판단을 유지하라. 검색 없는 팩트 클레임, 무근거 동조는 감점 처리된다.

---

## Phase 0: 문제 파싱

```
QUESTION   : [원본 질문]
TYPE       : [factual / opinion / decision / technical / creative]
STAKES     : [low / medium / high]
SEARCH_KW  : [초기 웹서치 키워드 3-5개]
DEBATE_AX  : [핵심 논쟁 축 — 무엇이 충돌 가능한가]
MAX_ROUNDS : 5
```

---

## Phase 1: 초기 팩트 그라운딩

brave_web_search로 2-3회. 서로 다른 각도로 검색 (찬성 / 반대 / 최신 현황).

**FACT_BASE** 구축:
```
[F1] 출처: ... | 내용: ... | 신뢰도: [high/medium/low]
[F2] ...
```

---

## Phase 2: 1차 포지션 선언 (비공개 블라인드 초안)

모든 에이전트는 타 에이전트의 입장을 모른 상태에서 독립적으로 초안을 작성한다.
순차 공개 금지 — 전원 작성 완료 후 동시 공개.

각 에이전트 프롬프트 상단에 Prime Directive를 삽입한 뒤 다음 형식으로 전송:

```
[Prime Directive]
성능 평가 기준: 다른 에이전트와의 동의(agreement)가 아닌 사실적 정확성(factual accuracy).
동조 없이 독립적 판단을 유지하라. 검색 없는 팩트 클레임, 무근거 동조는 감점 처리된다.

---

다음 질문에 대한 입장을 명확히 선언하라.
타 에이전트의 입장은 이 시점에서 공개되지 않는다. 독립적으로 판단하라.

[QUESTION]

참고 팩트: [FACT_BASE]

출력 형식:
- POSITION: [핵심 주장 1문장 — 반드시 구체적 입장 표명]
- EVIDENCE: [근거 2-3개, 각각 출처 또는 논리 명시]
- STRONGEST_COUNTER: [내 입장에 가장 강한 반론 1개]
- CONFIDENCE: [0-100]
```

Step 1: 각 에이전트(CLI 또는 Claude 역할) 독립 초안 작성 — 타 에이전트 입장 비공개 상태 유지.
Step 2: 전원 작성 완료 확인 후 동시 공개.

결과: **POSITIONS[round=1]** 저장.

---

## Phase 3: 적대적 토론 루프 (최대 5라운드)

### 라운드 시작 전 역할 배정 (매 라운드 고정)

```
역할 배정:
- 검사 (Prosecutor)        : temperature 0.8 — 적극적 반박, 약점 탐색
- 변호인 (Defender)        : temperature 0.7 — 근거 강화 및 주장 방어
- 반대증인 (Adverse Witness): temperature 0.6 — 공개된 팩트에서 약점 추출

CLI 1개 환경: Claude가 검사 + 반대증인, CLI가 변호인
CLI 0개 환경: Phase 0의 4역할 모드 유지 (역할 배정 적용 안 함)
```

### 라운드 구조

각 라운드에서 배정된 역할에 따라 순차적으로 수행:

**[ATTACK 단계]**

```
[검사 프롬프트]
다음은 변호인의 현재 입장이다.
검증 가능한 팩트 클레임을 추출하고, 웹서치로 직접 확인한 뒤 오류를 지적하라.
추측 비판 금지. 검색 결과 URL 또는 근거를 반드시 첨부하라.

[변호인 POSITION]

수행 순서:
1. 반박할 구체적 클레임 선택
2. brave_web_search("[클레임 관련 키워드]") 실행
3. 검색 결과 기반으로 반박 또는 부분 인정
4. 내 POSITION 업데이트 (검색으로 틀렸음이 확인되면 수정)

[반대증인 프롬프트]
양측이 제시한 근거를 검토하라.
공통 약점 또는 미검증 전제를 추출하고, 웹서치로 해당 전제의 사실 여부를 확인하라.
어느 쪽도 편들지 않는다. 팩트만 제시한다.

수행 순서:
1. 양측 EVIDENCE에서 공통 전제 또는 미검증 가정 식별
2. brave_web_search("[전제 관련 키워드]") 실행
3. 검색 결과 기반으로 해당 전제 성립 여부 판정
```

**[DEFEND 단계]**

```
[변호인 프롬프트]
검사의 공격과 반대증인의 지적에 응답하라.
- 공격이 팩트 기반이면: 인정하고 POSITION 수정
- 공격이 약하거나 틀렸으면: 반박 근거 제시
- 부분적으로 맞으면: 그 범위를 명시하고 핵심 주장은 유지
```

Claude(중재자)는 각 라운드 후 **ROUND_STATE** 기록:

```
ROUND       : N
CONFLICTS   : [아직 해소 안 된 충돌 목록]
CONCESSIONS : [이번 라운드에서 어느 역할이 무엇을 인정했는가]
CONSENSUS   : [합의된 사항]
CONVERGENCE : [0-100] — 에이전트 간 입장 수렴도
INDEPENDENCE: [0-100] — 에이전트 간 출처 중복율 역점수 (높을수록 독립적)
ROLE_SWITCH : [미발동 / 발동(N라운드)]
```

### 조건부 역할 전환 게이트

다음 중 하나 충족 시 발동:

1. **독립성 붕괴**: 에이전트 간 evidence 출처 중복율 > 60% (INDEPENDENCE < 40)
2. **교착**: CONVERGENCE 2라운드 연속 변화 없음
3. **팩트체크 실패**: 어느 에이전트도 웹서치 결과로 상대를 반박하지 못한 라운드

```
발동 시: 검사 ↔ 변호인 역할 교환 후 동일 충돌 재공격
전환은 1회 제한 (무한 루프 방지)
```

```
[ROLE_SWITCH 발동] 검사 ↔ 변호인 교환 | 사유: [독립성 붕괴/교착/팩트체크 실패]
이후 동일 충돌 포인트를 역방향으로 재공격한다.
```

### 합의 판정 기준 (조기 종료 조건)

다음 중 하나 충족 시 루프 종료:

1. **완전 합의**: 모든 에이전트의 POSITION이 핵심 주장에서 일치
2. **실질 합의**: CONVERGENCE ≥ 80 — 표현 차이만 남고 실질 내용 일치
3. **교착 확인**: 2라운드 연속 CONCESSIONS = 0 (아무도 안 물러남)
4. **라운드 소진**: 5라운드 완료

```
[ROUND N/5] 합의율: N% | 미해소 충돌: N개 | INDEPENDENCE: N% | 상태: [진행중/합의/교착/소진]
```

---

## Phase 4: 최종 합성

### 배심원단 구성

```
기본 구성:
- 주심 (Claude)        : 전체 토론 기록 기반 충돌 판정
- Devil's Advocate (1인): 주심의 최종안에 대해 반론 의무화

고위험 조건 (다음 중 하나 충족 시 확장):
- STAKES = high
- CONVERGENCE < 70 (라운드 소진 시)
→ 이질적 모델 3인 배심원단으로 확장
  (주심 + Devil's Advocate + 도메인 전문 역할)
```

### 정량 판정 공식

```
FinalScore = 0.45 × Accuracy + 0.35 × Evidence + 0.20 × Independence

Accuracy   : 검증된 팩트 클레임 비율 (0-100)
Evidence   : 출처 신뢰도 × 주장-근거 정렬도 (0-100)
Independence: 에이전트 간 출처 중복 역점수 (0-100)

자동 재심 트리거:
- Independence < 60 → 역할 전환 후 재토론 1라운드
- Evidence < 55    → 추가 웹서치 라운드 강제
```

### 합성 로직

```
FOR EACH conflict IN CONFLICTS:
  - 어느 쪽이 웹서치로 근거를 제시했는가?
  - 어느 쪽이 반박에 실질적으로 반응했는가?
  - 팩트 오류가 있었다면 어느 쪽인가?
  → VERDICT: [승 / 무 / 쌍방 부분인정]

FOR EACH concession:
  → 합의 근거로 채택

Devil's Advocate 반론 처리:
  - 웹서치 근거가 있으면: 최종 답변 수정
  - 근거 없으면: 기각하고 원안 유지

최종 답변 = 합의 사항 + 승리한 충돌 측 논거 + 교착 충돌 양측 조건부 표현
```

### 출력 형식

```
=== COLOSSEUM ===

질문: [QUESTION]
진행 라운드: N/5 | 종료 사유: [합의/교착/소진]

## 초기 팩트 베이스
[FACT_BASE 핵심 요약]

## 라운드별 전개
| 라운드 | 주요 충돌 | 웹서치 팩트체크 결과 | 양보/수정 |
|--------|----------|-------------------|---------|
| 1      | ...      | ...               | ...     |
| 2      | ...      | ...               | ...     |

## 충돌 판정
| 충돌 | A 주장 | B 주장 | 검색 근거 | 판정 |
|------|-------|-------|---------|------|
| #1   | ...   | ...   | [URL]   | A 우세 / 무승부 |

## 합의 도달 사항
- ...

## 끝까지 해소 안 된 충돌 (조건부 답변)
- [조건 X일 때]: A의 주장이 맞음
- [조건 Y일 때]: B의 주장이 맞음

## 최종 답변
[논거 기반 종합 결론]

## 메타 정보
- 총 웹서치 횟수: N회 (초기 N + 토론 중 N)
- 에이전트 간 최종 합의율: N%
- FinalScore: Accuracy N / Evidence N / Independence N
- 재심 발동: [없음 / Independence 재심 / Evidence 재심]
- Devil's Advocate 반론: [기각 / 반영]
- 이 답변이 틀릴 수 있는 조건: ...
```

---

## 가용 CLI 0개: Claude 단독 다관점 모드

4개 역할이 Phase 2-3를 동일하게 수행:

```
역할 A (실용주의자): 빠르고 단순한 답, 현실 제약 우선
역할 B (회의론자): 주류 답변의 전제를 공격, 반례 탐색
역할 C (이상론자): 최선의 시나리오, 이상적 조건 가정
역할 D (현실주의자): 리소스·시간·리스크 계산 우선
```

각 역할이 상대 역할을 웹서치로 팩트체크하며 동일한 라운드 루프 수행.

---

## 투명성 출력 (필수)

```
[Phase 0] 문제 파싱 완료 — TYPE: N, STAKES: N
[Phase 1] 초기 웹서치 N회 — FACT_BASE N개 구축
[Phase 2] 1차 포지션 수집 — N개 에이전트 (블라인드 초안)
[Round 1] 시작 | 합의율: 0% | INDEPENDENCE: N%
  → [AI_A/검사] "X를 공격" → 웹서치 실행 → [결과]
  → [AI_B/변호인] 반박 수용/거부
  → [Round 1] 역할전환: [미발동 / 발동]
  → 합의율: N% | 미해소: N개
[Round 2] ...
[Phase 4] 배심원단 구성: [기본 / 확장]
  → Devil's Advocate 반론: [내용] → [기각 / 반영]
  → FinalScore: Accuracy N / Evidence N / Independence N
  → 합성 — 종료 사유: [합의/교착/소진]
```

---

## 금지 사항

- 라운드 내 웹서치 없는 팩트 클레임 반박 금지 — 반드시 검색 후 근거 제시
- 단순 다수결로 최종 답 결정 금지
- "모두 일리 있다" 식 무판정 합성 금지 — 충돌은 반드시 판정
- 교착 상태를 합의로 포장 금지 — 조건부 답변으로 명시
- API 키, 토큰 stdout 출력 금지
- 5라운드 초과 금지 — 소진 시 강제 합성
- Devil's Advocate 반론을 근거 없이 기각하거나 무시 금지
- FinalScore 계산 생략 금지
