"""Tests for ForgeProof provenance engine (forgeproof.py).

Run with: python -m pytest test_forgeproof.py -v
Integration tests require ssh-keygen: python -m pytest test_forgeproof.py -m integration -v
"""

from __future__ import annotations

import importlib.util
import inspect
import io
import json
import os
import re
import shlex
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch, MagicMock
from urllib.parse import urlsplit

import pytest

# ---------------------------------------------------------------------------
# Import forgeproof.py as a module (it's not a package)
# ---------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
FORGEPROOF_PY = SCRIPT_DIR / "forgeproof.py"
FIXTURE_V101 = SCRIPT_DIR / "fixtures" / "v101"
FIXTURE_V110 = SCRIPT_DIR / "fixtures" / "v110"
FIXTURE_V122 = SCRIPT_DIR / "fixtures" / "v122"
FIXTURE_V130 = SCRIPT_DIR / "fixtures" / "v130"

spec = importlib.util.spec_from_file_location("forgeproof", FORGEPROOF_PY)
fp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fp)


# ---------------------------------------------------------------------------
# Signing helpers for tests
#
# v1.2.1 makes verify REQUIRE a present, canonical, valid signature (and a
# present public_key), so any bundle that must verify GREEN has to be really
# signed — the "fake-signature" mock cannot satisfy signature_is_canonical +
# verify_signature. One ephemeral ssh-keygen keypair is generated on first use
# and shared across the suite; tests that build signed bundles gate on
# ssh-keygen the same way the frozen-fixture compat tests do.
# ---------------------------------------------------------------------------

import shutil  # noqa: E402  (also imported later; needed by the helpers below)


def _skip_without_sshkeygen() -> None:
    """Skip locally when ssh-keygen is absent; fail loudly in CI (where it is
    always installed). Mirrors TestV101Compat._require_sshkeygen."""
    if not shutil.which("ssh-keygen"):
        if os.environ.get("CI"):
            pytest.fail("ssh-keygen missing in CI — signing test must not be skipped")
        pytest.skip("ssh-keygen not available")


_TEST_SIGNING_KEY: "tuple[Path, str] | None" = None


def _test_signing_key() -> "tuple[Path, str]":
    """(private_key_path, public_key_text) for one shared ephemeral Ed25519
    keypair, generated once via ssh-keygen. Call _skip_without_sshkeygen first."""
    global _TEST_SIGNING_KEY
    if _TEST_SIGNING_KEY is None:
        priv, pub = fp.generate_ephemeral_keypair("testsign")
        _TEST_SIGNING_KEY = (priv, pub.read_text().strip())
    return _TEST_SIGNING_KEY


def _sign_bundle(bundle: dict) -> dict:
    """Sign a bundle in place exactly as cmd_finalize does: set public_key, then
    compute root_digest over everything except root_digest/signature, then sign
    that digest. Returns the same dict so callers can chain. Requires ssh-keygen
    (gate with _skip_without_sshkeygen before calling)."""
    priv, pub_text = _test_signing_key()
    bundle.pop("root_digest", None)
    bundle.pop("signature", None)
    bundle["public_key"] = pub_text
    bundle["root_digest"] = fp.sha256_hex(fp.canonical_json(bundle))
    bundle["signature"] = fp.sign_ed25519(bundle["root_digest"], priv)
    return bundle


def _shape_valid_bundle_json() -> str:
    """A structurally valid (shape-only) bundle for gate tests. The PR gate
    checks format + non-empty signature/public_key/root_digest strings, NOT the
    cryptography (it runs under a 10s hook budget), so a placeholder signature
    is sufficient and realistic for exercising the gate's allow path."""
    return json.dumps({
        "format": fp.RPACK_FORMAT,
        "version": fp.RPACK_VERSION,
        "signature": "-----BEGIN SSH SIGNATURE-----\nAAAA\n-----END SSH SIGNATURE-----",
        "public_key": "ssh-ed25519 AAAA test",
        "root_digest": "0" * 64,
    })


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _isolated_system_temp(tmp_path_factory, monkeypatch):
    """Keep every engine temp-dir operation away from the real system temp.
    Without this, cmd_reset --all (which globs and DELETES
    forgeproof_*_ed25519* in tempfile.gettempdir()) would destroy real
    in-progress signing keys machine-wide when the tests run, and key-file
    assertions would flake on leftovers."""
    tdir = tmp_path_factory.mktemp("fp-system-temp")
    monkeypatch.setattr(tempfile, "gettempdir", lambda: str(tdir))
    return tdir


@pytest.fixture
def tmp_chain_dir(tmp_path, monkeypatch):
    """Redirect CHAIN_DIR to a temp directory."""
    monkeypatch.setattr(fp, "CHAIN_DIR", tmp_path)
    return tmp_path


@pytest.fixture
def sample_chain(tmp_chain_dir):
    """Create a sample initialized chain (genesis block, no real keypair)."""
    issue = "99"
    genesis = {
        "index": 0,
        "timestamp": "2026-01-01T00:00:00+00:00",
        "action": "genesis",
        "data": {
            "issue": 99,
            "title": "Test issue",
            "requirements": ["REQ-1: Do something", "REQ-2: Test it"],
        },
        "prev_hash": fp.GENESIS_PREV_HASH,
        "hash": "",
        "signature": "",
    }
    # Compute real hash
    block_for_hash = {k: v for k, v in genesis.items() if k not in ("hash", "signature")}
    genesis["hash"] = fp.sha256_hex(fp.canonical_json(block_for_hash))

    fp.save_chain(issue, [genesis])
    return issue, [genesis]


# ---------------------------------------------------------------------------
# Utility function tests
# ---------------------------------------------------------------------------


class TestSha256:
    def test_sha256_hex_empty_string(self):
        # Known SHA-256 of empty string
        assert fp.sha256_hex("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

    def test_sha256_hex_known_value(self):
        assert fp.sha256_hex("hello") == "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"

    def test_sha256_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert fp.sha256_file(f) == fp.sha256_hex("hello")

    def test_sha256_file_binary(self, tmp_path):
        f = tmp_path / "bin.dat"
        f.write_bytes(b"\x00\x01\x02")
        result = fp.sha256_file(f)
        assert len(result) == 64  # valid hex digest


class TestCanonicalJson:
    def test_sorted_keys(self):
        result = fp.canonical_json({"b": 2, "a": 1})
        assert result == '{"a":1,"b":2}'

    def test_no_whitespace(self):
        result = fp.canonical_json({"key": "value"})
        assert " " not in result

    def test_deterministic(self):
        obj1 = {"z": 1, "a": 2, "m": 3}
        obj2 = {"a": 2, "m": 3, "z": 1}
        assert fp.canonical_json(obj1) == fp.canonical_json(obj2)

    def test_nested(self):
        obj = {"outer": {"b": 2, "a": 1}}
        result = fp.canonical_json(obj)
        assert '"a":1' in result
        assert result.index('"a"') < result.index('"b"')


# ---------------------------------------------------------------------------
# cmd_preflight tests
# ---------------------------------------------------------------------------


class TestCmdPreflight:
    def test_preflight_never_spawns_sshkeygen(self, capsys, monkeypatch):
        """Regression: preflight used to call `ssh-keygen -h`, which is NOT a
        help flag — it starts interactive key generation and blocks forever
        on its stdin prompt (froze live sessions for minutes while Claude
        Code backgrounded and retried it). ssh-keygen availability must come
        from a PATH lookup only."""
        def fake_run(cmd, **kwargs):
            assert cmd[0] != "ssh-keygen", (
                "preflight must not spawn ssh-keygen — PATH lookup only")
            return subprocess.CompletedProcess(
                cmd, 0, stdout="gh version 2.0.0\n", stderr="")

        monkeypatch.setattr(fp, "run", fake_run)
        monkeypatch.setattr(fp.shutil, "which", lambda name: f"/usr/bin/{name}")
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_preflight(MagicMock())
        assert exc_info.value.code == 0
        out = json.loads(capsys.readouterr().out)
        checks = {c["dependency"]: c for c in out["checks"]}
        assert checks["ssh-keygen"]["ok"] is True

    def test_cli_output_is_utf8_on_every_platform(self, tmp_path):
        """Regression: `summary` emits an em dash; on Windows a piped stdout
        defaulted to a legacy codepage and produced mojibake. The CLI must
        emit UTF-8 regardless of platform or console."""
        chain_dir = tmp_path / ".forgeproof"
        chain_dir.mkdir()
        shutil.copyfile(FIXTURE_V101 / "issue-999.rpack",
                        chain_dir / "issue-999.rpack")
        env = dict(os.environ)
        env.pop("PYTHONIOENCODING", None)  # must not rely on the env
        result = subprocess.run(
            [sys.executable, str(FORGEPROOF_PY), "summary", "--issue", "999"],
            cwd=tmp_path, capture_output=True, timeout=60, env=env)
        assert result.returncode == 0, result.stderr
        text = result.stdout.decode("utf-8")  # strict: raises on mojibake
        assert "ForgeProof Provenance — Issue #999" in text
        assert "�" not in text

    def test_run_closes_stdin_by_default(self, monkeypatch):
        """No engine subprocess may inherit an open stdin — any child that
        prompts interactively would hang the whole hook/skill invocation."""
        captured = {}

        def fake_subprocess_run(cmd, **kwargs):
            captured.clear()
            captured.update(kwargs)
            return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

        monkeypatch.setattr(fp.subprocess, "run", fake_subprocess_run)
        fp.run(["anything"])
        assert captured.get("stdin") == subprocess.DEVNULL
        # Callers that feed stdin via input= must still work (subprocess.run
        # forbids combining stdin= and input=)
        fp.run(["anything"], input="data")
        assert "stdin" not in captured
        assert captured.get("input") == "data"


# ---------------------------------------------------------------------------
# Chain operation tests
# ---------------------------------------------------------------------------


class TestChainOperations:
    def test_chain_path(self, tmp_chain_dir):
        assert fp.chain_path("42") == tmp_chain_dir / "chain-42.json"

    def test_save_and_load_roundtrip(self, tmp_chain_dir):
        chain = [{"index": 0, "action": "genesis", "data": {}}]
        fp.save_chain("1", chain)
        loaded = fp.load_chain("1")
        assert loaded == chain

    def test_load_chain_missing_exits(self, tmp_chain_dir):
        with pytest.raises(SystemExit):
            fp.load_chain("nonexistent")

    def test_build_block_computes_hash(self):
        block = fp.build_block(
            index=0, action="genesis", data={"test": True},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        assert "hash" in block
        assert len(block["hash"]) == 64

    def test_build_block_hash_is_correct(self):
        block = fp.build_block(
            index=0, action="genesis", data={"test": True},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        # Recompute manually
        block_for_hash = {k: v for k, v in block.items() if k not in ("hash", "signature")}
        expected = fp.sha256_hex(fp.canonical_json(block_for_hash))
        assert block["hash"] == expected

    def test_build_block_chain_linkage(self):
        b0 = fp.build_block(
            index=0, action="genesis", data={},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        b1 = fp.build_block(
            index=1, action="file-edit", data={"path": "a.py"},
            prev_hash=b0["hash"], key_path=None,
        )
        assert b1["prev_hash"] == b0["hash"]
        assert b1["hash"] != b0["hash"]

    def test_build_block_without_key_empty_signature(self):
        block = fp.build_block(
            index=0, action="genesis", data={},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        assert block["signature"] == ""

    def test_get_key_path_missing(self):
        assert fp.get_key_path("nonexistent_99999") is None


# ---------------------------------------------------------------------------
# cmd_init tests
# ---------------------------------------------------------------------------


class TestCmdInit:
    def _make_args(self, issue="1", title=None, requirements=(), force=False):
        argv = ["init", "--issue", issue]
        if title is not None:
            argv += ["--title", title]
        for r in requirements:
            argv += ["--requirement", r]
        if force:
            argv.append("--force")
        return fp.build_parser().parse_args(argv)

    def _mock_keygen_and_sign(self, tmp_chain_dir):
        """Context manager that mocks both keypair generation and signing."""
        priv = tmp_chain_dir / "key"
        pub = tmp_chain_dir / "key.pub"
        priv.write_text("fake_private")
        pub.write_text("ssh-ed25519 AAAA fake")
        keygen_patch = patch.object(fp, "generate_ephemeral_keypair", return_value=(priv, pub))
        sign_patch = patch.object(fp, "sign_ed25519", return_value="fake-signature")
        return keygen_patch, sign_patch

    def test_init_creates_chain(self, tmp_chain_dir):
        keygen_patch, sign_patch = self._mock_keygen_and_sign(tmp_chain_dir)
        with keygen_patch, sign_patch, patch("sys.stdout"):
            fp.cmd_init(self._make_args(
                issue="1",
                title="Test",
                requirements=("REQ-1: Do it",),
            ))

        assert (tmp_chain_dir / "chain-1.json").exists()
        chain = json.loads((tmp_chain_dir / "chain-1.json").read_text())
        assert len(chain) == 1
        assert chain[0]["action"] == "genesis"
        assert chain[0]["data"]["title"] == "Test"
        assert chain[0]["data"]["requirements"] == ["REQ-1: Do it"]

    def test_init_title_survives_quotes(self, tmp_chain_dir):
        """The whole point of the flag surface: titles containing quote
        characters reach the chain intact (v1.0.x quoted-JSON --data broke)."""
        title = """He said "don't" — 100% of $titles `work` now"""
        keygen_patch, sign_patch = self._mock_keygen_and_sign(tmp_chain_dir)
        with keygen_patch, sign_patch, patch("sys.stdout"):
            fp.cmd_init(self._make_args(issue="8", title=title))
        chain = json.loads((tmp_chain_dir / "chain-8.json").read_text())
        assert chain[0]["data"]["title"] == title

    def test_init_data_flag_rejected(self, tmp_chain_dir, capsys):
        with pytest.raises(SystemExit) as exc_info:
            fp.build_parser().parse_args(["init", "--issue", "1", "--data", "{}"])
        assert exc_info.value.code == 2
        err = capsys.readouterr().err
        assert "removed in v1.1.0" in err
        assert "--title" in err

    def test_init_rejects_non_numeric_issue_before_keygen(
            self, tmp_chain_dir, capsys, _isolated_system_temp):
        """Validation must precede side effects: a bad --issue must not leave
        orphaned key files in the temp directory."""
        with patch.object(fp, "generate_ephemeral_keypair",
                          side_effect=AssertionError("keygen must not run")):
            with pytest.raises(SystemExit):
                fp.cmd_init(self._make_args(issue="not-a-number"))
        assert "--issue must be a canonical number" in capsys.readouterr().err
        assert list(_isolated_system_temp.iterdir()) == []

    def test_init_rejects_leading_zero_issue(self, tmp_chain_dir, capsys):
        """Leading-zero issue numbers made the filename ('007') and the bundle
        int (7) disagree, so a tampered chain was never checked -> false green.
        Reject non-canonical numbers before any side effect."""
        with patch.object(fp, "generate_ephemeral_keypair",
                          side_effect=AssertionError("keygen must not run")):
            with pytest.raises(SystemExit):
                fp.cmd_init(self._make_args(issue="007"))
        assert "canonical" in capsys.readouterr().err

    def test_init_rejects_unicode_digit_issue(self, tmp_chain_dir, capsys):
        """'³'/'①' pass str.isdigit() but crash int(); must be rejected
        cleanly before the keypair is generated."""
        with patch.object(fp, "generate_ephemeral_keypair",
                          side_effect=AssertionError("keygen must not run")):
            with pytest.raises(SystemExit):
                fp.cmd_init(self._make_args(issue="³"))
        assert "canonical" in capsys.readouterr().err

    def test_init_rejects_colonless_requirement(self, tmp_chain_dir, capsys):
        """A requirement without a colon was silently dropped at finalize and
        inflated coverage to 100%/pass; reject it at init."""
        with patch.object(fp, "generate_ephemeral_keypair",
                          side_effect=AssertionError("keygen must not run")):
            with pytest.raises(SystemExit):
                fp.cmd_init(self._make_args(
                    issue="1", requirements=("REQ-1 no colon here",)))
        assert "REQ-1: text" in capsys.readouterr().err

    def test_init_genesis_block_structure(self, tmp_chain_dir):
        keygen_patch, sign_patch = self._mock_keygen_and_sign(tmp_chain_dir)
        with keygen_patch, sign_patch, patch("sys.stdout"):
            fp.cmd_init(self._make_args(issue="5"))

        chain = json.loads((tmp_chain_dir / "chain-5.json").read_text())
        genesis = chain[0]
        assert genesis["index"] == 0
        assert genesis["action"] == "genesis"
        assert genesis["prev_hash"] == fp.GENESIS_PREV_HASH

    def test_init_dies_if_chain_exists_no_force(self, tmp_chain_dir):
        (tmp_chain_dir / "chain-1.json").write_text("[]")
        with pytest.raises(SystemExit):
            fp.cmd_init(self._make_args(issue="1"))

    def test_init_force_overwrites(self, tmp_chain_dir):
        (tmp_chain_dir / "chain-1.json").write_text("[]")
        (tmp_chain_dir / "issue-1.rpack").write_text("{}")

        keygen_patch, sign_patch = self._mock_keygen_and_sign(tmp_chain_dir)
        with keygen_patch, sign_patch, patch("sys.stdout"):
            fp.cmd_init(self._make_args(issue="1", force=True))

        chain = json.loads((tmp_chain_dir / "chain-1.json").read_text())
        assert len(chain) == 1
        assert chain[0]["action"] == "genesis"
        # Old rpack should be deleted
        assert not (tmp_chain_dir / "issue-1.rpack").exists()


# ---------------------------------------------------------------------------
# cmd_record tests
# ---------------------------------------------------------------------------


class TestCmdRecord:
    def _parse(self, *argv):
        return fp.build_parser().parse_args(["record", *argv])

    def _record(self, *argv):
        with patch.object(fp, "get_key_path", return_value=None), patch("sys.stdout"):
            fp.cmd_record(self._parse(*argv))

    def test_record_appends_block(self, sample_chain, tmp_chain_dir, tmp_path,
                                   monkeypatch):
        issue, chain = sample_chain
        monkeypatch.chdir(tmp_path)
        f = tmp_path / "test.py"
        f.write_text("print('x')\n")
        self._record("--issue", issue, "--action", "file-edit",
                     "--path", "test.py", "--operation", "create")

        loaded = fp.load_chain(issue)
        assert len(loaded) == 2
        assert loaded[1]["action"] == "file-edit"
        assert loaded[1]["data"]["path"] == "test.py"
        # The engine computed the hash natively — no shell, no sha256sum
        assert loaded[1]["data"]["sha256"] == fp.sha256_file(f)

    def test_record_rejects_absolute_path(self, sample_chain, tmp_chain_dir,
                                          tmp_path, monkeypatch, capsys):
        """An absolute --path verifies GREEN on any other checkout even if the
        file there was modified (verify resolves it relative to cwd and just
        reports 'not found'). Reject absolute paths at record time."""
        issue, _ = sample_chain
        monkeypatch.chdir(tmp_path)
        f = tmp_path / "abs.py"
        f.write_text("x = 1\n")
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "file-edit",
                         "--path", str(f), "--operation", "create")
        assert "must be relative" in capsys.readouterr().err

    def test_record_normalizes_path_spelling(self, sample_chain, tmp_chain_dir,
                                             tmp_path, monkeypatch):
        """Different spellings of one physical file must dedup to one artifact:
        record stores a normalized forward-slash relative path."""
        issue, _ = sample_chain
        monkeypatch.chdir(tmp_path)
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "x.py").write_text("y = 1\n")
        for spelling in ("src/x.py", "src/../src/x.py", "./src/x.py"):
            self._record("--issue", issue, "--action", "file-edit",
                         "--path", spelling, "--operation", "modify")
        paths = {b["data"]["path"] for b in fp.load_chain(issue)
                 if b["action"] == "file-edit"}
        assert paths == {"src/x.py"}, f"path not normalized: {paths}"

    def test_record_increments_index(self, sample_chain, tmp_chain_dir):
        issue, chain = sample_chain
        self._record("--issue", issue, "--action", "decision",
                     "--context", "test", "--choice", "a", "--rationale", "because")

        loaded = fp.load_chain(issue)
        assert loaded[1]["index"] == 1

    def test_record_links_prev_hash(self, sample_chain, tmp_chain_dir):
        issue, chain = sample_chain
        self._record("--issue", issue, "--action", "decision",
                     "--context", "c", "--choice", "x", "--rationale", "r")

        loaded = fp.load_chain(issue)
        assert loaded[1]["prev_hash"] == loaded[0]["hash"]

    def test_record_rejects_invalid_action(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit) as exc_info:
            self._parse("--issue", issue, "--action", "invalid-action")
        assert exc_info.value.code == 2
        capsys.readouterr()

    def test_record_rejects_data_flag(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit) as exc_info:
            self._parse("--issue", issue, "--action", "decision", "--data", '{"x": 1}')
        assert exc_info.value.code == 2
        err = capsys.readouterr().err
        assert "removed in v1.1.0" in err
        assert "--context" in err


class TestCmdRecordFlags:
    """The discrete-flag surface must produce data dicts byte-identical in
    shape to what the v1.0.x --data JSON produced (bundle compat)."""

    def _record(self, issue, *argv):
        with patch.object(fp, "get_key_path", return_value=None), patch("sys.stdout"):
            fp.cmd_record(fp.build_parser().parse_args(
                ["record", "--issue", issue, *argv]))

    def test_shapes_match_v101_literals(self, sample_chain, tmp_chain_dir,
                                        tmp_path, monkeypatch):
        issue, _ = sample_chain
        monkeypatch.chdir(tmp_path)
        f = tmp_path / "x.py"
        f.write_text("y = 1\n")
        cases = [
            (
                ["--action", "branch-create", "--branch", "forgeproof/1",
                 "--base", "main", "--base-sha", "abc123"],
                {"branch": "forgeproof/1", "base": "main", "base_sha": "abc123"},
            ),
            (
                ["--action", "file-edit", "--path", "x.py", "--operation", "create"],
                {"path": "x.py", "operation": "create", "sha256": fp.sha256_file(f)},
            ),
            (
                ["--action", "decision", "--context", "ctx",
                 "--choice", "ch", "--rationale", "why"],
                {"context": "ctx", "choice": "ch", "rationale": "why"},
            ),
            (
                ["--action", "test-result", "--suite", "pytest",
                 "--passed", "3", "--failed", "1",
                 "--covers", "REQ-1=test_a,test_b", "--covers", "REQ-2=test_c",
                 "--failed-test", "test_d"],
                {"suite": "pytest", "passed": 3, "failed": 1,
                 "coverage": {"REQ-1": ["test_a", "test_b"], "REQ-2": ["test_c"]},
                 "failed_tests": ["test_d"]},
            ),
            (
                ["--action", "lint-result", "--tool", "ruff",
                 "--errors", "0", "--warnings", "2"],
                {"tool": "ruff", "errors": 0, "warnings": 2},
            ),
        ]
        for argv, expected in cases:
            self._record(issue, *argv)
            assert fp.load_chain(issue)[-1]["data"] == expected, argv

    def test_shapes_match_fixture_blocks(self):
        """Key sets must equal what the real v1.0.1 engine wrote (the frozen
        fixture), not just what this suite believes v1.0.1 wrote."""
        chain = json.loads((FIXTURE_V101 / "chain-999.json").read_text())
        by_action = {b["action"]: b["data"] for b in chain}
        assert set(by_action["file-edit"]) == {"path", "operation", "sha256"}
        assert set(by_action["decision"]) == {"context", "choice", "rationale"}
        assert set(by_action["test-result"]) == {
            "suite", "passed", "failed", "coverage", "failed_tests"}

    def test_file_edit_missing_file_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record(issue, "--action", "file-edit",
                         "--path", "does/not/exist.py", "--operation", "create")
        assert "file not found" in capsys.readouterr().err

    def test_wrong_flags_for_action_die(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record(issue, "--action", "decision",
                         "--context", "c", "--choice", "x", "--rationale", "r",
                         "--branch", "nope")
        err = capsys.readouterr().err
        assert "unexpected --branch" in err
        assert "--context" in err  # names the expected set

    def test_missing_required_flag_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record(issue, "--action", "test-result", "--suite", "pytest")
        err = capsys.readouterr().err
        assert "missing" in err
        assert "--passed" in err

    def test_covers_malformed_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record(issue, "--action", "test-result", "--suite", "pytest",
                         "--passed", "1", "--failed", "0", "--covers", "no-equals-sign")
        assert "--covers" in capsys.readouterr().err

    def test_zero_counts_are_recorded(self, sample_chain, tmp_chain_dir):
        issue, _ = sample_chain
        self._record(issue, "--action", "test-result", "--suite", "pytest",
                     "--passed", "0", "--failed", "0")
        data = fp.load_chain(issue)[-1]["data"]
        assert data["passed"] == 0 and data["failed"] == 0
        assert data["coverage"] == {} and data["failed_tests"] == []


# ---------------------------------------------------------------------------
# cmd_verify tests (using pre-built bundles)
# ---------------------------------------------------------------------------


class TestCmdVerify:
    def _build_minimal_bundle(self, tmp_chain_dir, issue="1"):
        """Build a minimal validly-signed bundle for testing verification.
        v1.2.1 requires a real signature to verify, so this signs for real and
        the callers gate on ssh-keygen via the skip below."""
        _skip_without_sshkeygen()
        genesis = fp.build_block(
            index=0, action="genesis",
            data={"issue": 1, "title": "Test", "requirements": ["REQ-1: X"]},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        fp.save_chain(issue, [genesis])

        bundle = {
            "version": fp.RPACK_VERSION,
            "format": fp.RPACK_FORMAT,
            "issue": {"number": 1, "title": "Test", "url": ""},
            "requirements": [{"id": "REQ-1", "text": "X", "status": "covered", "tests": ["t1"]}],
            "artifacts": [],
            "decisions": [],
            "evaluation": {
                "status": "pass",
                "tests_passed": 1,
                "tests_failed": 0,
                "lint_errors": 0,
                "requirement_coverage": "100%",
                "uncovered_requirements": [],
                "failed_tests": [],
            },
            "chain_hash": fp.sha256_hex(fp.chain_path(issue).read_text()),
        }
        _sign_bundle(bundle)

        rpack_path = tmp_chain_dir / f"issue-{issue}.rpack"
        rpack_path.write_text(json.dumps(bundle, indent=2))
        return rpack_path, bundle

    def test_verify_valid_bundle(self, tmp_chain_dir, capsys):
        rpack_path, _ = self._build_minimal_bundle(tmp_chain_dir)
        args = MagicMock()
        args.rpack = str(rpack_path)

        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        assert exc_info.value.code == 0  # verified

        output = json.loads(capsys.readouterr().out)
        assert output["verified"] is True
        assert output["errors"] == []

    def test_verify_rejects_whitespace_signature_trailer(self, tmp_chain_dir, capsys):
        """End-to-end (v1.2.2): a whitespace-only trailer on an otherwise valid
        signature must turn verify red. The signature is excluded from
        root_digest, so only the canonical check catches this — ssh-keygen
        itself ignores the trailing bytes and would still pass."""
        rpack_path, bundle = self._build_minimal_bundle(tmp_chain_dir)
        bundle["signature"] = bundle["signature"] + "\n"
        rpack_path.write_text(json.dumps(bundle, indent=2))
        args = MagicMock()
        args.rpack = str(rpack_path)
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        assert exc_info.value.code == 1
        output = json.loads(capsys.readouterr().out)
        assert output["verified"] is False
        assert any("canonical" in e.lower() for e in output["errors"])

    def test_verify_tampered_bundle_fails(self, tmp_chain_dir, capsys):
        rpack_path, bundle = self._build_minimal_bundle(tmp_chain_dir)
        # Tamper with the bundle
        bundle["evaluation"]["tests_passed"] = 999
        rpack_path.write_text(json.dumps(bundle, indent=2))

        args = MagicMock()
        args.rpack = str(rpack_path)

        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        assert exc_info.value.code == 1  # failed

        output = json.loads(capsys.readouterr().out)
        assert output["verified"] is False
        assert any("Root digest mismatch" in e for e in output["errors"])

    def test_verify_missing_bundle_exits(self, tmp_chain_dir):
        args = MagicMock()
        args.rpack = str(tmp_chain_dir / "nonexistent.rpack")
        with pytest.raises(SystemExit):
            fp.cmd_verify(args)

    def test_verify_tampered_chain(self, tmp_chain_dir, capsys):
        rpack_path, bundle = self._build_minimal_bundle(tmp_chain_dir)
        # Tamper with the chain file
        chain_file = fp.chain_path("1")
        chain_file.write_text("[]")

        args = MagicMock()
        args.rpack = str(rpack_path)

        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)

        output = json.loads(capsys.readouterr().out)
        assert any("Chain hash mismatch" in e for e in output["errors"])


# ---------------------------------------------------------------------------
# cmd_detect tests
# ---------------------------------------------------------------------------


class TestCmdDetect:
    def test_detect_python_project(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text('[project]\nname = "test"\n')

        args = MagicMock()
        args.project_root = str(tmp_path)

        # Mock subprocess for runtime checks
        with patch.object(fp, "run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="Python 3.11.0")
            fp.cmd_detect(args)

        output = json.loads(capsys.readouterr().out)
        assert output["detected"] is True
        assert output["languages"][0]["language"] == "python"

    def test_detect_no_config(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        args = MagicMock()
        args.project_root = str(tmp_path)

        fp.cmd_detect(args)

        output = json.loads(capsys.readouterr().out)
        assert output["detected"] is False


# ---------------------------------------------------------------------------
# cmd_reset tests
# ---------------------------------------------------------------------------


class TestCmdReset:
    def _make_args(self, issue=None, all_flag=False):
        args = MagicMock()
        args.issue = issue
        # Use setattr for 'all' since it's a keyword
        args.all = all_flag
        return args

    def test_reset_single_issue(self, tmp_chain_dir, capsys):
        (tmp_chain_dir / "chain-5.json").write_text("[]")
        (tmp_chain_dir / "issue-5.rpack").write_text("{}")
        (tmp_chain_dir / "issue-5.sigstore.json").write_text("{}")
        (tmp_chain_dir / "issue-5.pub.pem").write_text("PEM")

        fp.cmd_reset(self._make_args(issue="5"))

        assert not (tmp_chain_dir / "chain-5.json").exists()
        assert not (tmp_chain_dir / "issue-5.rpack").exists()
        assert not (tmp_chain_dir / "issue-5.sigstore.json").exists()
        assert not (tmp_chain_dir / "issue-5.pub.pem").exists()
        output = json.loads(capsys.readouterr().out)
        assert output["count"] == 4

    def test_reset_all(self, tmp_chain_dir, capsys):
        (tmp_chain_dir / "chain-1.json").write_text("[]")
        (tmp_chain_dir / "chain-2.json").write_text("[]")
        (tmp_chain_dir / "issue-1.rpack").write_text("{}")
        (tmp_chain_dir / "issue-1.sigstore.json").write_text("{}")
        (tmp_chain_dir / "issue-2.pub.pem").write_text("PEM")

        fp.cmd_reset(self._make_args(all_flag=True))

        assert not (tmp_chain_dir / "chain-1.json").exists()
        assert not (tmp_chain_dir / "chain-2.json").exists()
        assert not (tmp_chain_dir / "issue-1.rpack").exists()
        assert not (tmp_chain_dir / "issue-1.sigstore.json").exists()
        assert not (tmp_chain_dir / "issue-2.pub.pem").exists()
        output = json.loads(capsys.readouterr().out)
        assert output["count"] == 5

    def test_reset_nonexistent_issue(self, tmp_chain_dir, capsys):
        fp.cmd_reset(self._make_args(issue="999"))
        output = json.loads(capsys.readouterr().out)
        assert output["count"] == 0

    def test_reset_no_args_exits(self, tmp_chain_dir):
        with pytest.raises(SystemExit):
            fp.cmd_reset(self._make_args())


# ---------------------------------------------------------------------------
# cmd_summary tests
# ---------------------------------------------------------------------------


class TestCmdSummary:
    def test_summary_outputs_markdown(self, tmp_chain_dir, capsys):
        bundle = {
            "version": fp.RPACK_VERSION,
            "format": fp.RPACK_FORMAT,
            "issue": {"number": 1, "title": "Test", "url": ""},
            "requirements": [{"id": "REQ-1", "text": "Do it", "status": "covered", "tests": ["test_x"]}],
            "artifacts": [{"path": "src/a.py", "operation": "create", "sha256": "abc"}],
            "decisions": [],
            "evaluation": {
                "status": "pass", "tests_passed": 5, "tests_failed": 0,
                "lint_errors": 0, "requirement_coverage": "100%",
                "uncovered_requirements": [], "failed_tests": [],
            },
            "root_digest": "abc123",
            "public_key": "",
            "signature": "",
            "chain_hash": "",
        }
        (tmp_chain_dir / "issue-1.rpack").write_text(json.dumps(bundle))

        args = MagicMock()
        args.issue = "1"
        fp.cmd_summary(args)

        output = capsys.readouterr().out
        assert "## ForgeProof Provenance" in output
        assert "REQ-1" in output
        assert "PASS" in output
        assert "test_x" in output

    def test_summary_missing_rpack_exits(self, tmp_chain_dir):
        args = MagicMock()
        args.issue = "999"
        with pytest.raises(SystemExit):
            fp.cmd_summary(args)

    @pytest.mark.parametrize("bad_digest", [7, None, ["x"], {"a": 1}])
    def test_summary_non_string_root_digest_dies_cleanly(
            self, tmp_chain_dir, bad_digest):
        """A non-string root_digest used to traceback on the [:16] slice; it must
        die cleanly through the required-field guard instead (v1.2.2)."""
        bundle = {
            "version": fp.RPACK_VERSION, "format": fp.RPACK_FORMAT,
            "issue": {"number": 1, "title": "Test", "url": ""},
            "requirements": [], "artifacts": [], "decisions": [],
            "evaluation": {"status": "pass", "tests_passed": 1, "tests_failed": 0,
                           "lint_errors": 0, "requirement_coverage": "100%",
                           "uncovered_requirements": [], "failed_tests": []},
            "root_digest": bad_digest, "public_key": "", "signature": "",
            "chain_hash": "",
        }
        (tmp_chain_dir / "issue-1.rpack").write_text(json.dumps(bundle))
        args = MagicMock()
        args.issue = "1"
        with pytest.raises(SystemExit):
            fp.cmd_summary(args)


class TestCmdGatePr:
    """PreToolUse hook gate for 'gh pr create'."""

    def _run_gate(self, event: dict | str | None) -> int:
        stdin_text = "" if event is None else (
            event if isinstance(event, str) else json.dumps(event)
        )
        with patch("sys.stdin", new=__import__("io").StringIO(stdin_text)):
            with pytest.raises(SystemExit) as exc_info:
                fp.cmd_gate_pr(MagicMock())
        code = exc_info.value.code
        return 0 if code is None else code

    def test_allows_when_bundle_exists(self, tmp_chain_dir):
        (tmp_chain_dir / "issue-1.rpack").write_text(_shape_valid_bundle_json())
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 0

    def test_blocks_when_bundle_is_garbage(self, tmp_chain_dir, capsys):
        """A file merely named *.rpack must not satisfy the gate — pre-v1.2.1 it
        did (existence-only glob), letting a garbage file bypass the gate."""
        (tmp_chain_dir / "issue-1.rpack").write_text("not a signed bundle")
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2
        assert "BLOCK" in capsys.readouterr().err

    def test_blocks_when_bundle_missing_signature(self, tmp_chain_dir):
        """Valid JSON with the wrong shape (no signing fields) is not a bundle."""
        (tmp_chain_dir / "issue-1.rpack").write_text(json.dumps({
            "format": fp.RPACK_FORMAT, "root_digest": "0" * 64, "public_key": "x"}))
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2

    def test_allows_when_one_of_several_is_valid(self, tmp_chain_dir):
        """A garbage candidate alongside a valid one still allows."""
        (tmp_chain_dir / "garbage.rpack").write_text("{}")
        (tmp_chain_dir / "issue-1.rpack").write_text(_shape_valid_bundle_json())
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 0

    def test_blocks_on_deeply_nested_bundle(self, tmp_chain_dir, capsys):
        """A deeply nested .rpack makes json.loads raise RecursionError. The
        gate must swallow it and fail CLOSED (exit 2), never crash to a
        fail-open exit 1 that lets 'gh pr create' through (v1.2.2)."""
        (tmp_chain_dir / "deep.rpack").write_text("[" * 2000 + "]" * 2000)
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2
        assert "BLOCK" in capsys.readouterr().err

    def test_blocks_when_signature_not_sshsig(self, tmp_chain_dir):
        """A non-empty but non-SSHSIG signature is not a signed bundle — the
        gate shape-checks the signing fields, not just their presence (v1.2.2)."""
        (tmp_chain_dir / "issue-1.rpack").write_text(json.dumps({
            "format": fp.RPACK_FORMAT, "signature": "notasignature",
            "public_key": "ssh-ed25519 AAAA", "root_digest": "0" * 64}))
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2

    def test_blocks_when_public_key_not_ssh(self, tmp_chain_dir):
        (tmp_chain_dir / "issue-1.rpack").write_text(json.dumps({
            "format": fp.RPACK_FORMAT,
            "signature": "-----BEGIN SSH SIGNATURE-----\nAAAA\n-----END SSH SIGNATURE-----",
            "public_key": "notakey", "root_digest": "0" * 64}))
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2

    def test_blocks_when_root_digest_not_hex(self, tmp_chain_dir):
        (tmp_chain_dir / "issue-1.rpack").write_text(json.dumps({
            "format": fp.RPACK_FORMAT,
            "signature": "-----BEGIN SSH SIGNATURE-----\nAAAA\n-----END SSH SIGNATURE-----",
            "public_key": "ssh-ed25519 AAAA", "root_digest": "nothex" + "0" * 58}))
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2

    def test_deeply_nested_event_exits_cleanly(self, tmp_chain_dir):
        """A deeply nested hook EVENT on stdin (separate from the candidate-file
        parse) made json raise RecursionError → exit 1 + traceback. An
        unparseable event must exit cleanly — the gate's fail-safe is allow, not
        crash (v1.2.2)."""
        assert self._run_gate("[" * 2000 + "]" * 2000) == 0

    def test_blocks_when_no_bundle(self, tmp_chain_dir, capsys):
        event = {"tool_name": "Bash", "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2
        captured = capsys.readouterr()
        assert "BLOCK" in captured.err
        # Dual-protocol: deny JSON on stdout for exit-code-independent blocking
        decision = json.loads(captured.out)["hookSpecificOutput"]
        assert decision["permissionDecision"] == "deny"
        assert decision["hookEventName"] == "PreToolUse"

    def test_allows_unrelated_bash_command(self, tmp_chain_dir):
        event = {"tool_name": "Bash", "tool_input": {"command": "ls -la"}}
        assert self._run_gate(event) == 0

    def test_blocks_powershell_tool(self, tmp_chain_dir, capsys):
        """Claude Code on Windows has a first-class PowerShell tool; the gate
        must cover it or 'gh pr create' via PowerShell bypasses provenance."""
        event = {"tool_name": "PowerShell",
                 "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 2
        captured = capsys.readouterr()
        assert "BLOCK" in captured.err
        assert json.loads(captured.out)[
            "hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_allows_powershell_with_bundle(self, tmp_chain_dir):
        (tmp_chain_dir / "issue-1.rpack").write_text(_shape_valid_bundle_json())
        event = {"tool_name": "PowerShell",
                 "tool_input": {"command": "gh pr create --fill"}}
        assert self._run_gate(event) == 0

    def test_allows_non_shell_tool(self, tmp_chain_dir):
        event = {"tool_name": "Edit", "tool_input": {"file_path": "/tmp/x"}}
        assert self._run_gate(event) == 0

    def test_allows_when_stdin_unparseable(self, tmp_chain_dir):
        assert self._run_gate("not json {") == 0

    def test_allows_when_stdin_empty(self, tmp_chain_dir):
        assert self._run_gate("") == 0


# ---------------------------------------------------------------------------
# cmd_finalize artifact recheck
# ---------------------------------------------------------------------------


class TestFinalizeRecheck:
    """finalize must refuse to sign a bundle whose recorded artifacts no
    longer match disk — and must not corrupt the chain when it refuses."""

    def _setup(self, tmp_chain_dir, tmp_path, monkeypatch, issue="3"):
        monkeypatch.chdir(tmp_path)
        priv = tmp_path / "key"
        pub = tmp_path / "key.pub"
        priv.write_text("fake_private")
        pub.write_text("ssh-ed25519 AAAA fake")
        artifact = tmp_path / "art.py"
        artifact.write_text("a = 1\n")
        with patch.object(fp, "generate_ephemeral_keypair", return_value=(priv, pub)), \
             patch.object(fp, "sign_ed25519", return_value="sig"), patch("sys.stdout"):
            fp.cmd_init(fp.build_parser().parse_args(
                ["init", "--issue", issue, "--title", "recheck", "--force"]))
        self._record(issue, priv, "--action", "file-edit",
                     "--path", "art.py", "--operation", "create")
        return issue, artifact, priv

    def _record(self, issue, priv, *argv):
        with patch.object(fp, "get_key_path", return_value=priv), \
             patch.object(fp, "sign_ed25519", return_value="sig"), patch("sys.stdout"):
            fp.cmd_record(fp.build_parser().parse_args(
                ["record", "--issue", issue, *argv]))

    def _finalize(self, issue, priv):
        args = fp.build_parser().parse_args(
            ["finalize", "--issue", issue, "--commit", "0" * 40])
        # load_attestation_signer is patched with a REAL signer from a fixed
        # seed (this class feeds finalize a literal fake_private file the
        # OpenSSH parser would rightly reject); everything downstream —
        # statement build, DSSE signing, sidecar writes — still runs for real.
        with patch.object(fp, "get_key_path", return_value=priv), \
             patch.object(fp, "sign_ed25519", return_value="sig"), \
             patch.object(fp, "delete_private_key"), \
             patch.object(fp.shutil, "which", return_value=None), \
             patch.object(fp, "load_attestation_signer",
                          return_value=fp.EphemeralEd25519Signer(bytes(32))), \
             patch("sys.stdout"):
            fp.cmd_finalize(args)

    def test_finalize_dies_on_stale_artifact(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        issue, artifact, priv = self._setup(tmp_chain_dir, tmp_path, monkeypatch)
        chain_len_before = len(fp.load_chain(issue))
        artifact.write_text("a = 2  # modified after recording\n")

        with pytest.raises(SystemExit):
            self._finalize(issue, priv)
        err = capsys.readouterr().err
        assert "artifact recheck failed" in err
        assert "art.py" in err
        # The refused finalize must not have appended a finalize block
        assert len(fp.load_chain(issue)) == chain_len_before

    def test_finalize_dies_on_missing_artifact(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        issue, artifact, priv = self._setup(tmp_chain_dir, tmp_path, monkeypatch)
        artifact.unlink()
        with pytest.raises(SystemExit):
            self._finalize(issue, priv)
        assert "missing from disk" in capsys.readouterr().err

    def test_finalize_succeeds_when_clean(
            self, tmp_chain_dir, tmp_path, monkeypatch):
        issue, artifact, priv = self._setup(tmp_chain_dir, tmp_path, monkeypatch)
        self._finalize(issue, priv)
        bundle = json.loads((tmp_chain_dir / f"issue-{issue}.rpack").read_text())
        assert bundle["artifacts"] == [
            {"path": "art.py", "operation": "create",
             "sha256": fp.sha256_file(artifact)}]

    def test_reedited_file_rechecks_latest_and_dedups(
            self, tmp_chain_dir, tmp_path, monkeypatch):
        """Earlier records of a re-edited file are superseded, not stale: the
        recheck uses the latest record per path, and the bundle lists the file
        once with the hash that matches disk."""
        issue, artifact, priv = self._setup(tmp_chain_dir, tmp_path, monkeypatch)
        artifact.write_text("a = 2\n")
        self._record(issue, priv, "--action", "file-edit",
                     "--path", "art.py", "--operation", "modify")
        self._finalize(issue, priv)
        bundle = json.loads((tmp_chain_dir / f"issue-{issue}.rpack").read_text())
        assert bundle["artifacts"] == [
            {"path": "art.py", "operation": "modify",
             "sha256": fp.sha256_file(artifact)}]


# ---------------------------------------------------------------------------
# cmd_lint_hook (PostToolUse hook)
# ---------------------------------------------------------------------------


class TestCmdLintHook:
    def _invoke(self, stdin_text: str) -> int:
        with patch("sys.stdin", io.StringIO(stdin_text)):
            with pytest.raises(SystemExit) as exc_info:
                fp.cmd_lint_hook(MagicMock())
        code = exc_info.value.code
        return 0 if code is None else code

    def _detection(self, argv=("lintx", "check", "."), language="python"):
        return {"detected": True, "languages": [{
            "language": language,
            "config_files": ["pyproject.toml"],
            "runtime_available": True,
            "test_runner": None,
            "linter": {"name": "lintx", "command": " ".join(argv), "argv": list(argv)},
        }]}

    def _event(self, path) -> str:
        return json.dumps({"tool_name": "Edit", "tool_input": {"file_path": str(path)}})

    def test_deeply_nested_event_exits_cleanly(self, tmp_chain_dir):
        """A deeply nested hook event must not traceback; lint-hook always
        no-ops on an unparseable event (exit 0) (v1.2.2)."""
        assert self._invoke("[" * 2000 + "]" * 2000) == 0

    def test_malformed_stdin_silent(self, tmp_chain_dir, capsys):
        assert self._invoke("not json {") == 0
        assert capsys.readouterr().out == ""

    def test_no_active_chain_silent(self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "x.py"
        target.write_text("x = 1\n")
        # No chain-*.json in CHAIN_DIR: the hook must not even detect/lint
        with patch.object(fp, "detect_toolchain",
                          side_effect=AssertionError("must not detect without a chain")):
            assert self._invoke(self._event(target)) == 0
        assert capsys.readouterr().out == ""

    def _activate_chain(self, tmp_chain_dir):
        (tmp_chain_dir / "chain-1.json").write_text("[]")

    def test_clean_file_silent(self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        self._activate_chain(tmp_chain_dir)
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "x.py"
        target.write_text("x = 1\n")
        clean = subprocess.CompletedProcess([], 0, stdout="", stderr="")
        with patch.object(fp, "detect_toolchain", return_value=self._detection()), \
             patch.object(fp, "run", return_value=clean) as mock_run:
            assert self._invoke(self._event(target)) == 0
        assert capsys.readouterr().out == ""
        # Lint ran against the single edited file, not the project
        assert mock_run.call_args[0][0] == ["lintx", "check", "x.py"]

    def test_findings_emitted_as_additional_context(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        self._activate_chain(tmp_chain_dir)
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "x.py"
        target.write_text("import os\n")
        dirty = subprocess.CompletedProcess(
            [], 1, stdout="x.py:1:1: F401 'os' imported but unused\n", stderr="")
        with patch.object(fp, "detect_toolchain", return_value=self._detection()), \
             patch.object(fp, "run", return_value=dirty):
            assert self._invoke(self._event(target)) == 0  # findings never block
        out = json.loads(capsys.readouterr().out)
        hook_out = out["hookSpecificOutput"]
        assert hook_out["hookEventName"] == "PostToolUse"
        assert "F401" in hook_out["additionalContext"]
        assert "x.py" in hook_out["additionalContext"]

    def test_findings_truncated_to_20_lines(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        self._activate_chain(tmp_chain_dir)
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "x.py"
        target.write_text("x = 1\n")
        many = "\n".join(f"x.py:{i}:1: E501 line too long" for i in range(1, 100))
        dirty = subprocess.CompletedProcess([], 1, stdout=many, stderr="")
        with patch.object(fp, "detect_toolchain", return_value=self._detection()), \
             patch.object(fp, "run", return_value=dirty):
            self._invoke(self._event(target))
        context = json.loads(capsys.readouterr().out)[
            "hookSpecificOutput"]["additionalContext"]
        # header line + at most 20 finding lines
        assert len(context.splitlines()) <= 21

    def test_file_outside_project_silent(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys, tmp_path_factory):
        self._activate_chain(tmp_chain_dir)
        monkeypatch.chdir(tmp_path)
        outside = tmp_path_factory.mktemp("elsewhere") / "y.py"
        outside.write_text("y = 1\n")
        with patch.object(fp, "detect_toolchain",
                          side_effect=AssertionError("must not lint outside files")):
            assert self._invoke(self._event(outside)) == 0
        assert capsys.readouterr().out == ""

    def test_extension_language_mismatch_silent(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        self._activate_chain(tmp_chain_dir)
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "notes.md"
        target.write_text("# notes\n")
        with patch.object(fp, "detect_toolchain", return_value=self._detection()), \
             patch.object(fp, "run",
                          side_effect=AssertionError("must not lint .md with a python linter")):
            assert self._invoke(self._event(target)) == 0
        assert capsys.readouterr().out == ""

    def test_project_scope_linter_skipped(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        """golangci-lint has no per-file mode; the hook must not run a
        project-wide lint on every edit (that is the v1.0.x behavior this
        release removes)."""
        self._activate_chain(tmp_chain_dir)
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "m.go"
        target.write_text("package m\n")
        detection = self._detection(argv=("golangci-lint", "run"), language="go")
        with patch.object(fp, "detect_toolchain", return_value=detection), \
             patch.object(fp, "run",
                          side_effect=AssertionError("must not run project-scope lint")):
            assert self._invoke(self._event(target)) == 0
        assert capsys.readouterr().out == ""


# ---------------------------------------------------------------------------
# Portable toolchain detection
# ---------------------------------------------------------------------------


class TestDetectPortable:
    def test_find_project_python_prefers_venv(self, tmp_path):
        if os.name == "nt":
            venv_py = tmp_path / ".venv" / "Scripts" / "python.exe"
        else:
            venv_py = tmp_path / ".venv" / "bin" / "python"
        venv_py.parent.mkdir(parents=True)
        venv_py.write_text("")
        assert fp.find_project_python(tmp_path) == str(venv_py)

    def test_find_project_python_falls_back_to_engine(self, tmp_path):
        assert fp.find_project_python(tmp_path) == sys.executable

    def test_find_js_tool_filesystem_first(self, tmp_path, monkeypatch):
        bin_dir = tmp_path / "node_modules" / ".bin"
        bin_dir.mkdir(parents=True)
        for name in ("eslint", "eslint.cmd", "eslint.exe"):
            (bin_dir / name).write_text("")
        monkeypatch.setattr(fp.shutil, "which",
                            lambda _: pytest.fail("PATH consulted before node_modules/.bin"))
        found = fp.find_js_tool(tmp_path, "eslint")
        assert found is not None
        assert "node_modules" in found

    def test_find_js_tool_never_probes_npx(self, tmp_path, monkeypatch):
        """A missing JS tool is 'unavailable', never a network fetch."""
        monkeypatch.setattr(fp.shutil, "which", lambda _: None)
        with patch.object(fp, "run",
                          side_effect=AssertionError("no subprocess probes for JS tools")):
            assert fp.find_js_tool(tmp_path, "eslint") is None

    def test_detect_structured_no_shell(self, tmp_path, monkeypatch):
        """Simulated minimal machine (nothing on PATH): detection must use
        list-form subprocess calls only and degrade gracefully."""
        (tmp_path / "pyproject.toml").write_text("[project]\n")
        (tmp_path / "package.json").write_text("{}\n")
        (tmp_path / "go.mod").write_text("module x\n")
        monkeypatch.setattr(fp.shutil, "which", lambda _: None)

        calls = []

        def fake_run(cmd, **kwargs):
            assert isinstance(cmd, list), f"string command passed to run(): {cmd!r}"
            assert not kwargs.get("shell"), f"shell=True used: {cmd!r}"
            calls.append(cmd)
            return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

        monkeypatch.setattr(fp, "run", fake_run)
        result = fp.detect_toolchain(tmp_path)

        assert result["detected"] is True
        langs = {l["language"]: l for l in result["languages"]}
        assert set(langs) == {"python", "javascript", "go"}
        # No node on PATH, no node_modules: JS runtime and tools unavailable
        assert langs["javascript"]["runtime_available"] is False
        assert langs["javascript"]["linter"] is None
        assert langs["javascript"]["test_runner"]["available"] is False
        assert langs["go"]["runtime_available"] is False
        # Python probes ran (list-form) and produced argv + command pairs
        assert calls
        runner = langs["python"]["test_runner"]
        assert isinstance(runner["argv"], list)
        assert all(isinstance(a, str) for a in runner["argv"])
        assert isinstance(runner["command"], str)

    def test_engine_source_has_no_shell_isms(self):
        source = FORGEPROOF_PY.read_text()
        for banned in ("shell=True", "sha256sum", "head -20", "2>/dev/null",
                       '"which ', "shell_run"):
            assert banned not in source, f"shell-ism found in engine: {banned}"


# ---------------------------------------------------------------------------
# Malformed-input robustness (clean die / fail-safe, never a traceback)
# ---------------------------------------------------------------------------


class TestMalformedInputRobustness:
    """Adversarial stress found raw tracebacks on corrupt files and wrong-shape
    hook events. Every entry point must die cleanly or fail safe."""

    def _cli(self, cwd, *args, stdin=None):
        return subprocess.run(
            [sys.executable, str(FORGEPROOF_PY), *args], cwd=cwd,
            input=stdin, capture_output=True, text=True, timeout=60)

    def _no_traceback(self, result):
        assert "Traceback (most recent call last)" not in result.stderr, (
            f"raw traceback leaked:\n{result.stderr}")

    @pytest.mark.parametrize("content", ["", "   ", "{ truncated", "not json",
                                         "﻿{}", "[]"])
    def test_verify_malformed_rpack_dies_clean(self, tmp_path, content):
        rpack = tmp_path / "bad.rpack"
        rpack.write_text(content, encoding="utf-8")
        r = self._cli(tmp_path, "verify", "--rpack", "bad.rpack")
        self._no_traceback(r)
        assert r.returncode != 0

    def test_verify_rpack_is_a_directory_dies_clean(self, tmp_path):
        (tmp_path / "adir.rpack").mkdir()
        r = self._cli(tmp_path, "verify", "--rpack", "adir.rpack")
        self._no_traceback(r)
        assert r.returncode != 0

    def test_verify_corrupt_chain_beside_intact_bundle_fails_closed(self, tmp_path):
        """A real signed bundle whose chain file is later corrupted must fail
        closed with a clean message, not traceback."""
        fixture = FIXTURE_V101
        cd = tmp_path / ".forgeproof"
        cd.mkdir()
        shutil.copyfile(fixture / "issue-999.rpack", cd / "issue-999.rpack")
        (cd / "chain-999.json").write_text("{ corrupt", encoding="utf-8")
        (tmp_path / "src").mkdir()
        shutil.copyfile(fixture / "src" / "example.py", tmp_path / "src" / "example.py")
        r = self._cli(tmp_path, "verify", "--rpack", ".forgeproof/issue-999.rpack")
        self._no_traceback(r)
        assert r.returncode != 0

    @pytest.mark.parametrize("event", ["42", '"hello"', '["x"]', "null",
                                       '{"tool_input": "notadict"}',
                                       '{"tool_name": "Bash", "tool_input": {"command": 5}}'])
    def test_gate_wrong_shape_event_never_crashes(self, tmp_path, event):
        r = self._cli(tmp_path, "gate-pr", stdin=event)
        self._no_traceback(r)
        # No positively-identified gh pr create -> allow (exit 0), never crash
        assert r.returncode == 0

    @pytest.mark.parametrize("event", ["42", '"hello"', '["x"]', "null",
                                       '{"tool_input": {"file_path": 123}}',
                                       '{"tool_input": {"file_path": ["a.js"]}}'])
    def test_lint_hook_wrong_shape_event_always_exit_0(self, tmp_path, event):
        (tmp_path / ".forgeproof").mkdir()
        (tmp_path / ".forgeproof" / "chain-1.json").write_text("[]", encoding="utf-8")
        r = self._cli(tmp_path, "lint-hook", stdin=event)
        self._no_traceback(r)
        assert r.returncode == 0
        assert r.stdout.strip() == ""

    def test_record_on_corrupt_chain_dies_clean(self, tmp_path):
        cd = tmp_path / ".forgeproof"
        cd.mkdir()
        (cd / "chain-5.json").write_text("{ truncated", encoding="utf-8")
        r = self._cli(tmp_path, "record", "--issue", "5", "--action", "decision",
                      "--context", "a", "--choice", "b", "--rationale", "c")
        self._no_traceback(r)
        assert r.returncode != 0
        assert "not valid JSON" in r.stderr

    # Wrong-SHAPE (well-formed JSON, wrong structure) — the class an
    # independent audit surfaced beyond malformed-JSON. Every one must die
    # cleanly or return a red verdict, never traceback.

    def _make_bundle(self, tmp_path):
        cd = tmp_path / ".forgeproof"
        cd.mkdir()
        shutil.copyfile(FIXTURE_V101 / "issue-999.rpack", cd / "issue-999.rpack")
        shutil.copyfile(FIXTURE_V101 / "chain-999.json", cd / "chain-999.json")
        src = tmp_path / "src"
        src.mkdir()
        shutil.copyfile(FIXTURE_V101 / "src" / "example.py", src / "example.py")
        return cd / "issue-999.rpack", cd / "chain-999.json"

    def test_verify_issue_field_wrong_type_dies_clean(self, tmp_path):
        rpack, _ = self._make_bundle(tmp_path)
        b = json.loads(rpack.read_text(encoding="utf-8"))
        b["issue"] = 7  # an int, not the object verify expects
        rpack.write_text(json.dumps(b), encoding="utf-8")
        r = self._cli(tmp_path, "verify", "--rpack", ".forgeproof/issue-999.rpack")
        self._no_traceback(r)
        assert r.returncode != 0

    def test_verify_null_chain_block_is_red_not_crash(self, tmp_path):
        rpack, chain = self._make_bundle(tmp_path)
        chain.write_text("[null]", encoding="utf-8")
        r = self._cli(tmp_path, "verify", "--rpack", ".forgeproof/issue-999.rpack")
        self._no_traceback(r)
        assert r.returncode == 1
        assert '"verified": false' in r.stdout

    def test_summary_empty_object_bundle_dies_clean(self, tmp_path):
        rpack, _ = self._make_bundle(tmp_path)
        rpack.write_text("{}", encoding="utf-8")
        r = self._cli(tmp_path, "summary", "--issue", "999")
        self._no_traceback(r)
        assert r.returncode != 0
        assert "missing required fields" in r.stderr

    def test_record_dict_chain_dies_clean(self, tmp_path):
        _, chain = self._make_bundle(tmp_path)
        chain.write_text("{}", encoding="utf-8")  # object, not a list of blocks
        r = self._cli(tmp_path, "record", "--issue", "999", "--action", "decision",
                      "--context", "a", "--choice", "b", "--rationale", "c")
        self._no_traceback(r)
        assert r.returncode != 0
        assert "corrupt" in r.stderr


class TestMalformedBundleRobustness:
    """Well-typed JSON of the wrong SHAPE (or pathological nesting) must yield a
    clean verdict or a clean error, never a raw Python traceback — the project's
    clean-error guarantee. Regressions fixed in v1.2.2."""

    def test_non_string_root_digest_is_clean_red(self, tmp_chain_dir, capsys):
        """root_digest as a non-string (e.g. 7) used to crash on
        stored_digest[:16] ('int' object is not subscriptable). It must be a
        clean red verdict instead."""
        rpack = tmp_chain_dir / "issue-1.rpack"
        rpack.write_text(json.dumps({
            "format": fp.RPACK_FORMAT, "version": fp.RPACK_VERSION,
            "issue": {"number": 1, "title": "x", "url": ""},
            "requirements": [], "artifacts": [], "decisions": [],
            "root_digest": 7, "signature": "", "public_key": "",
        }), encoding="utf-8")
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        assert code == 1
        data = json.loads(out)
        assert data["verified"] is False
        assert any("Root digest mismatch" in e for e in data["errors"])

    def test_non_string_root_digest_with_signature_no_traceback(self, tmp_chain_dir, capsys):
        """Second crash path: with a signature present, a non-string digest was
        handed to verify_signature and crashed on write_text(7). The isinstance
        guard short-circuits (so this needs no ssh-keygen) and fails cleanly."""
        rpack = tmp_chain_dir / "issue-1.rpack"
        rpack.write_text(json.dumps({
            "format": fp.RPACK_FORMAT, "version": fp.RPACK_VERSION,
            "issue": {"number": 1, "title": "x", "url": ""},
            "requirements": [], "artifacts": [], "decisions": [],
            "root_digest": 7,
            "signature": "-----BEGIN SSH SIGNATURE-----\nAAAA\n-----END SSH SIGNATURE-----",
            "public_key": "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5 test",
        }), encoding="utf-8")
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        assert code == 1
        data = json.loads(out)
        assert data["verified"] is False

    def test_deeply_nested_bundle_verify_dies_cleanly(self, tmp_chain_dir):
        """A deeply nested .rpack makes json raise RecursionError; verify must
        convert it to a clean die(), not leak a traceback."""
        rpack = tmp_chain_dir / "issue-1.rpack"
        rpack.write_text("[" * 2000 + "]" * 2000, encoding="utf-8")
        args = fp.build_parser().parse_args(["verify", "--rpack", str(rpack)])
        with pytest.raises(SystemExit):
            fp.cmd_verify(args)

    def test_read_json_file_catches_recursion_error(self, tmp_path, monkeypatch):
        """read_json_file is the shared reader for every chain/bundle load; if
        json raises RecursionError on pathological input it must die cleanly, not
        leak the traceback. Forced via monkeypatch rather than real deep nesting
        because the depth at which json actually raises is platform/build-
        dependent — 2000 levels trips CPython on Windows/macOS/Ubuntu but parses
        fine on some builds (e.g. Debian's python3), so a real-nesting assertion
        here is flaky. The other deep-JSON tests (verify/gate/lint-hook) stay
        real-nesting: they have a shape fallback (a deep list isn't a dict), so
        they exit cleanly on every build regardless."""
        p = tmp_path / "x.json"
        p.write_text("[]", encoding="utf-8")
        def raise_recursion(*_a, **_k):
            raise RecursionError("maximum recursion depth exceeded")
        monkeypatch.setattr(fp.json, "loads", raise_recursion)
        with pytest.raises(SystemExit):
            fp.read_json_file(p, "bundle")


class TestSignatureCanonical:
    """A bundle signature must be exactly the SSHSIG armor ssh-keygen emitted;
    ssh-keygen -Y verify ignores trailing bytes, so without a canonical check
    the signature field could be altered post-signing and still verify."""

    def test_canonical_accepts_real_signature(self):
        bundle = json.loads((FIXTURE_V101 / "issue-999.rpack").read_text(encoding="utf-8"))
        assert fp.signature_is_canonical(bundle["signature"])

    @pytest.mark.parametrize("mutate", [
        lambda s: s + "x",                       # trailing char after END
        lambda s: s + "\nFORGED-TRAILER",        # trailing junk line
        lambda s: "prefix" + s,                  # leading junk
        lambda s: s.replace("SIGNATURE", "sig"), # broken markers
    ])
    def test_canonical_rejects_trailing_or_altered(self, mutate):
        bundle = json.loads((FIXTURE_V101 / "issue-999.rpack").read_text(encoding="utf-8"))
        assert not fp.signature_is_canonical(mutate(bundle["signature"]))

    @pytest.mark.parametrize("mutate", [
        lambda s: s + "\n",        # trailing newline
        lambda s: s + " ",         # trailing space
        lambda s: s + "\t",        # trailing tab
        lambda s: s + "\n\n",      # trailing blank line
        lambda s: s + "\r\n",      # trailing CRLF
        lambda s: " " + s,         # leading space
        lambda s: "\n" + s,        # leading newline
    ])
    def test_canonical_rejects_whitespace_trailers(self, mutate):
        """Regression (v1.2.2): the canonical check used sig.strip(), so a
        whitespace-only trailer survived it and a whitespace-appended signature
        verified green — violating the promise that ANY post-signing change to
        the signature turns verify red. ssh-keygen -Y verify also ignores
        trailing bytes, so this canonical check is the only thing that catches
        it."""
        bundle = json.loads((FIXTURE_V101 / "issue-999.rpack").read_text(encoding="utf-8"))
        assert not fp.signature_is_canonical(mutate(bundle["signature"]))

    def test_verify_rejects_signature_with_trailing_data(self, tmp_path):
        if not shutil.which("ssh-keygen"):
            pytest.skip("ssh-keygen not available")
        cd = tmp_path / ".forgeproof"
        cd.mkdir()
        (tmp_path / "src").mkdir()
        shutil.copyfile(FIXTURE_V101 / "src" / "example.py",
                        tmp_path / "src" / "example.py")
        shutil.copyfile(FIXTURE_V101 / "chain-999.json", cd / "chain-999.json")
        bundle = json.loads((FIXTURE_V101 / "issue-999.rpack").read_text(encoding="utf-8"))
        bundle["signature"] = bundle["signature"] + "x"
        (cd / "issue-999.rpack").write_text(json.dumps(bundle, indent=2), encoding="utf-8")
        r = subprocess.run(
            [sys.executable, str(FORGEPROOF_PY), "verify",
             "--rpack", ".forgeproof/issue-999.rpack"],
            cwd=tmp_path, capture_output=True, text=True, timeout=60)
        assert r.returncode == 1
        out = json.loads(r.stdout)
        assert out["verified"] is False
        assert any("trailing or altered" in e for e in out["errors"])


# ---------------------------------------------------------------------------
# Hooks configuration (the loud PR-gate regression test)
# ---------------------------------------------------------------------------

PLUGIN_ROOT = SCRIPT_DIR.parents[2]
HOOKS_JSON = PLUGIN_ROOT / "hooks" / "hooks.json"


class TestHooksConfig:
    """Guards the v1.0.0 silent-failure class: these tests assert the exact
    matcher and handler shape AND spawn the exact configured commands against
    a block-scenario event. A never-fires misconfiguration (wrong matcher,
    wrong path, wrong form) fails loudly here — it cannot pass silently.

    Shape note: entries are single-command SHELL strings, not exec-form
    (command + args array). Exec form is documented, but Claude Code 2.1.128
    silently ignored the args array at runtime (verified live 2026-07-03):
    the manager spawned a bare `python`, which swallowed the stdin event and
    exited 0 — the gate never fired and nothing errored. Keep these tests
    asserting shell-string form until a live plugin-loaded retest proves
    exec form works."""

    _COMMAND_RE = re.compile(
        r'^(python3?) "\$\{CLAUDE_PLUGIN_ROOT\}/skills/[^"]+/forgeproof\.py" (gate-pr|lint-hook)$'
    )

    def _config(self) -> dict:
        return json.loads(HOOKS_JSON.read_text(encoding="utf-8"))

    def _argv(self, handler) -> list[str]:
        """The argv the shell would produce from the configured command, with
        ${CLAUDE_PLUGIN_ROOT} substituted the way Claude Code does."""
        resolved = handler["command"].replace("${CLAUDE_PLUGIN_ROOT}", str(PLUGIN_ROOT))
        return shlex.split(resolved)

    def _real_interpreters(self, handlers):
        """(handler, argv) for each handler whose interpreter is a *working*
        Python — on Windows, `python3` may resolve to the Microsoft Store
        stub, which exists on PATH but is not an interpreter (exactly the
        case the dual-entry design tolerates: its noise is non-blocking while
        the real interpreter delivers the verdict)."""
        available = []
        for handler in handlers:
            argv = self._argv(handler)
            exe = shutil.which(argv[0])
            if not exe:
                continue
            probe = subprocess.run([exe, "--version"], capture_output=True, text=True)
            if probe.returncode == 0 and "Python" in (probe.stdout + probe.stderr):
                available.append((handler, [exe] + argv[1:]))
        return available

    def test_structure(self):
        cfg = self._config()
        hooks = cfg["hooks"]  # top-level wrapper required by the plugin schema
        assert set(hooks) == {"PreToolUse", "PostToolUse"}

        pre = hooks["PreToolUse"]
        assert len(pre) == 1
        assert pre[0]["matcher"] == "Bash|PowerShell"
        post = hooks["PostToolUse"]
        assert len(post) == 1
        assert post[0]["matcher"] == "Edit|Write"

        for event_name, subcommand in (("PreToolUse", "gate-pr"),
                                       ("PostToolUse", "lint-hook")):
            handlers = hooks[event_name][0]["hooks"]
            interpreters = []
            for handler in handlers:
                assert handler["type"] == "command"
                assert isinstance(handler["timeout"], int)
                m = self._COMMAND_RE.match(handler["command"])
                assert m, (
                    f"hook command must be a single quoted engine invocation: "
                    f"{handler['command']}")
                assert m.group(2) == subcommand
                interpreters.append(m.group(1))
                # script path resolves to a real file
                argv = self._argv(handler)
                assert Path(argv[1]).is_file(), f"hook target missing: {argv[1]}"
            # dual interpreter, python3 first
            assert interpreters == ["python3", "python"]

    def test_no_shell_chaining_in_hooks(self):
        """The v1.0.1 fail-open bug lived in shell chaining (`||` converted a
        block into exit 127) and PowerShell 5.1 cannot even parse `||`. Each
        command must stay a single simple invocation."""
        cfg = self._config()
        for event in cfg["hooks"].values():
            for entry in event:
                for handler in entry["hooks"]:
                    cmd = handler["command"]
                    for banned in ("||", "&&", "2>/dev/null", "|", ";", "$(", ">"):
                        assert banned not in cmd, (
                            f"shell syntax crept back into hook command: "
                            f"{banned!r} in {cmd}")

    def test_matcher_semantics(self):
        """Matchers are exact-or-regex against the tool NAME only. The v1.0.0
        bug was permission-rule syntax ('Bash(gh pr create)') here — assert
        exact equality so any drift fails CI."""
        cfg = self._config()
        pre_matcher = cfg["hooks"]["PreToolUse"][0]["matcher"]
        assert pre_matcher == "Bash|PowerShell"
        assert re.fullmatch(pre_matcher, "Bash")
        # Windows sessions expose a first-class PowerShell tool — the gate
        # must fire for it too, or PRs bypass provenance there
        assert re.fullmatch(pre_matcher, "PowerShell")
        assert not re.fullmatch(pre_matcher, "Edit")
        assert pre_matcher != "Bash(gh pr create)"

        post_matcher = cfg["hooks"]["PostToolUse"][0]["matcher"]
        assert re.fullmatch(post_matcher, "Edit")
        assert re.fullmatch(post_matcher, "Write")
        assert not re.fullmatch(post_matcher, "Bash")

    def test_gate_dispatch_blocks_without_bundle(self, tmp_path):
        """Spawn the exact configured command the way the hook manager would:
        event JSON on stdin, cwd without a bundle. Must block via BOTH
        protocols: permissionDecision deny JSON on stdout (shell- and
        exit-code-independent) and exit 2 with the reason on stderr."""
        entry = self._config()["hooks"]["PreToolUse"][0]
        event = json.dumps(
            {"tool_name": "Bash", "tool_input": {"command": "gh pr create --title x"}})
        assert re.fullmatch(entry["matcher"], "Bash")

        available = self._real_interpreters(entry["hooks"])
        assert available, "no working python interpreter found on this machine"
        for handler, argv in available:
            result = subprocess.run(argv, input=event, capture_output=True,
                                    text=True, cwd=tmp_path,
                                    timeout=handler["timeout"])
            assert result.returncode == 2, (
                f"gate must BLOCK (exit 2), got {result.returncode}; "
                f"stderr: {result.stderr}")
            assert ".rpack" in result.stderr
            decision = json.loads(result.stdout)["hookSpecificOutput"]
            assert decision["hookEventName"] == "PreToolUse"
            assert decision["permissionDecision"] == "deny"
            assert ".rpack" in decision["permissionDecisionReason"]

    def test_gate_dispatch_allows_with_bundle(self, tmp_path):
        entry = self._config()["hooks"]["PreToolUse"][0]
        event = json.dumps(
            {"tool_name": "Bash", "tool_input": {"command": "gh pr create --title x"}})
        (tmp_path / ".forgeproof").mkdir()
        (tmp_path / ".forgeproof" / "issue-1.rpack").write_text(
            _shape_valid_bundle_json())

        available = self._real_interpreters(entry["hooks"])
        assert available
        for handler, argv in available:
            result = subprocess.run(argv, input=event, capture_output=True,
                                    text=True, cwd=tmp_path,
                                    timeout=handler["timeout"])
            assert result.returncode == 0, result.stderr
            assert result.stdout.strip() == ""  # silence = defer to normal flow

    def test_lint_hook_dispatch_silent_without_chain(self, tmp_path):
        entry = self._config()["hooks"]["PostToolUse"][0]
        target = tmp_path / "x.py"
        target.write_text("x = 1\n")
        event = json.dumps(
            {"tool_name": "Edit", "tool_input": {"file_path": str(target)}})

        available = self._real_interpreters(entry["hooks"])
        assert available
        for handler, argv in available:
            result = subprocess.run(argv, input=event, capture_output=True,
                                    text=True, cwd=tmp_path,
                                    timeout=handler["timeout"])
            assert result.returncode == 0
            assert result.stdout.strip() == ""


# ---------------------------------------------------------------------------
# Skill contract: SKILL.md examples must parse against the real CLI
# ---------------------------------------------------------------------------

SKILLS_DIR = SCRIPT_DIR.parent.parent

_REDIRECT_TOKENS = {">", ">>", "|", "||", "&&", ";", "2>&1"}


def _candidate_lines(text: str):
    """Every place a SKILL.md can document an engine invocation: lines inside
    fenced code blocks, plus inline code spans in prose (e.g. a numbered-list
    step like: Run: `"$FP_PY" "$FP" issues --assignee @me`)."""
    for fence in re.findall(r"```[^\n]*\n(.*?)```", text, re.DOTALL):
        joined = re.sub(r"\\\n\s*", " ", fence)  # join line continuations
        yield from joined.splitlines()
    without_fences = re.sub(r"```[^\n]*\n.*?```", "", text, flags=re.DOTALL)
    yield from re.findall(r"`([^`\n]+)`", without_fences)


def _extract_engine_argvs(text: str):
    """Yield (line, argv) for each documented engine invocation."""
    for raw in _candidate_lines(text):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "$FP" not in line and "forgeproof.py" not in line:
            continue
        # unwrap VAR=$(engine ...) command substitutions
        m = re.match(r"^(?:export\s+)?[A-Za-z_]\w*=\$\((.+)\)$", line)
        if m:
            line_cmd = m.group(1).strip()
        elif re.match(r"^(?:export\s+)?[A-Za-z_]\w*=", line):
            continue  # plain assignment, e.g. FP=${CLAUDE_PLUGIN_ROOT}/...
        else:
            line_cmd = line
        line_cmd = line_cmd.replace("$(git rev-parse HEAD)", "0" * 40)
        try:
            tokens = shlex.split(line_cmd)
        except ValueError:
            # untokenizable engine line = broken example; surface it
            yield line, ["<<untokenizable>>"]
            continue
        # locate the engine script token
        idx = None
        for i, tok in enumerate(tokens):
            if tok == "$FP" or tok.endswith("forgeproof.py"):
                idx = i
                break
        if idx is None:
            continue
        argv = tokens[idx + 1:]
        for stop in _REDIRECT_TOKENS:
            if stop in argv:
                argv = argv[:argv.index(stop)]
        if not argv:
            continue  # prose mention of `$FP` itself, not an invocation
        if "..." in argv or "<subcommand>" in line_cmd:
            continue  # pseudo-syntax illustration, not a runnable example
        # placeholders and shell variables -> parseable dummies
        argv = [re.sub(r"<[^<>]+>", "1", tok) for tok in argv]
        argv = [re.sub(r"\$\{?\w+\}?", "1", tok) for tok in argv]
        yield line, argv


class TestSkillContract:
    """Every engine invocation documented in any SKILL.md must parse against
    the real argparse surface — a stale example is a loud CI failure, not a
    silent runtime break inside a Claude session."""

    def test_skill_examples_parse(self, capsys, tmp_path, monkeypatch):
        """Two levels: argparse must accept the example, and for `record`
        the per-action runtime validation must accept it too (an example
        that parses but dies in _record_data_from_flags is just as broken)."""
        monkeypatch.chdir(tmp_path)  # documented paths are repo-relative
        stand_in = "example-artifact.py"
        (tmp_path / stand_in).write_text("x = 1\n")
        failures = []
        checked = 0
        for skill_md in sorted(SKILLS_DIR.glob("*/SKILL.md")):
            for line, argv in _extract_engine_argvs(skill_md.read_text(encoding="utf-8")):
                checked += 1
                try:
                    ns = fp.build_parser().parse_args(argv)
                    if ns.command == "record":
                        if ns.path is not None:
                            ns.path = stand_in
                        fp._record_data_from_flags(ns)
                except SystemExit as e:
                    if e.code not in (0, None):
                        failures.append(f"{skill_md.parent.name}: {line}")
        capsys.readouterr()  # swallow argparse usage noise
        assert checked >= 17, (
            f"only {checked} engine invocations found across SKILL.md files — "
            "the extractor is broken or the skills no longer document the engine"
        )
        assert failures == [], "\n".join(failures)

    def test_push_guard_bundle_filename_matches_engine(self):
        """push Step 2 gates on the literal bundle filename; if the engine
        renames its .rpack output, the guard silently never fires."""
        push_md = (SKILLS_DIR / "push" / "SKILL.md").read_text(encoding="utf-8")
        assert "issue-$ISSUE.rpack" in push_md
        assert "issue-{issue}.rpack" in FORGEPROOF_PY.read_text(encoding="utf-8")

    def test_skill_documented_engine_path_resolves(self):
        """Each SKILL.md states the engine path in prose; a stale path there
        sends Claude to a nonexistent file at runtime."""
        pattern = re.compile(r"\$\{CLAUDE_PLUGIN_ROOT\}/(\S+?forgeproof\.py)")
        for skill_md in sorted(SKILLS_DIR.glob("*/SKILL.md")):
            text = skill_md.read_text(encoding="utf-8")
            matches = pattern.findall(text)
            assert matches, f"{skill_md.parent.name}: engine path not documented"
            for rel in matches:
                resolved = PLUGIN_ROOT / rel.rstrip("`")
                assert resolved.is_file(), (
                    f"{skill_md.parent.name}: documented engine path does not "
                    f"exist: {rel}")


# ---------------------------------------------------------------------------
# v1.0.x compatibility (forever contract — ROADMAP Principle 1)
# ---------------------------------------------------------------------------


class TestV101Compat:
    """The checked-in fixture bundle was generated by the unmodified v1.0.1
    engine. Any `.rpack` ever signed must verify with every future version of
    the verifier — this test must never be weakened and the fixture must never
    be regenerated. If a change breaks it, the change is wrong.
    """

    def _require_sshkeygen(self):
        # The fixture carries a real Ed25519 signature. In CI this dependency
        # is guaranteed (installed in every job); locally, skip rather than
        # error on machines without OpenSSH.
        if not shutil.which("ssh-keygen"):
            if os.environ.get("CI"):
                pytest.fail("ssh-keygen missing in CI — compat test must not be skipped")
            pytest.skip("ssh-keygen not available")

    def _deploy(self, tmp_path):
        """Lay the fixture out the way a real checkout looks: chain and bundle
        under .forgeproof/, artifact at its recorded relative path."""
        chain_dir = tmp_path / ".forgeproof"
        chain_dir.mkdir()
        shutil.copyfile(FIXTURE_V101 / "chain-999.json", chain_dir / "chain-999.json")
        shutil.copyfile(FIXTURE_V101 / "issue-999.rpack", chain_dir / "issue-999.rpack")
        src = tmp_path / "src"
        src.mkdir()
        shutil.copyfile(FIXTURE_V101 / "src" / "example.py", src / "example.py")
        return chain_dir / "issue-999.rpack"

    def _verify(self, rpack_path, capsys) -> tuple[int, dict]:
        args = MagicMock()
        args.rpack = str(rpack_path)
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        code = exc_info.value.code
        return (0 if code is None else code), json.loads(capsys.readouterr().out)

    def test_fixture_files_present(self):
        assert (FIXTURE_V101 / "chain-999.json").exists()
        assert (FIXTURE_V101 / "issue-999.rpack").exists()
        assert (FIXTURE_V101 / "src" / "example.py").exists()

    def test_fixture_is_byte_exact(self):
        """Guards against EOL conversion or accidental edits. Fixture files are
        stored LF-only (see .gitattributes): the artifact hash covers raw bytes,
        and chain_hash covers the text the engine sees via read_text() — with
        LF bytes on disk the two views are identical on every platform."""
        for rel in ("chain-999.json", "issue-999.rpack", "src/example.py"):
            assert b"\r" not in (FIXTURE_V101 / rel).read_bytes(), (
                f"fixture file {rel} gained CR bytes (EOL conversion?)"
            )
        bundle = json.loads((FIXTURE_V101 / "issue-999.rpack").read_bytes())
        [artifact] = bundle["artifacts"]
        assert artifact["path"] == "src/example.py"
        actual = fp.sha256_file(FIXTURE_V101 / "src" / "example.py")
        assert actual == artifact["sha256"], (
            "fixture artifact bytes changed on disk"
        )
        chain_text = (FIXTURE_V101 / "chain-999.json").read_bytes().decode("utf-8")
        assert fp.sha256_hex(chain_text) == bundle["chain_hash"], (
            "fixture chain file bytes changed on disk"
        )

    def test_v101_bundle_verifies(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["artifacts_checked"] == 1
        assert output["artifacts_missing"] == 0
        assert output["artifacts_tampered"] == 0

    def test_v101_tampered_artifact_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        artifact = tmp_path / "src" / "example.py"
        data = bytearray(artifact.read_bytes())
        data[0] ^= 0xFF  # flip one byte
        artifact.write_bytes(bytes(data))
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert output["artifacts_tampered"] == 1

    def test_v101_tampered_chain_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        chain_file = tmp_path / ".forgeproof" / "chain-999.json"
        chain = json.loads(chain_file.read_text())
        chain[2]["data"]["choice"] = "history, rewritten"
        chain_file.write_text(json.dumps(chain, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("hash mismatch" in e.lower() for e in output["errors"])

    def test_v101_tampered_signature_fails(self, tmp_path, monkeypatch, capsys):
        """Exercises the Ed25519 failure branch specifically: the signature
        field is excluded from the root digest, so corrupting it leaves the
        digest intact — only real signature verification can catch it. A
        verify_signature that false-positives makes this test fail."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text())
        # Corrupt the base64 payload inside the SSHSIG armor
        lines = bundle["signature"].splitlines()
        middle = len(lines) // 2
        lines[middle] = lines[middle][::-1]
        bundle["signature"] = "\n".join(lines)
        rpack.write_text(json.dumps(bundle, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("signature verification FAILED" in e for e in output["errors"])

    # -- v1.2.0 additive coverage (strict mode must honor the forever
    #    contract: old bundles with all evidence present pass --strict) -----

    def test_v10x_bundle_passes_strict(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        code = exc_info.value.code
        output = json.loads(capsys.readouterr().out)
        assert (0 if code is None else code) == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["strict"] is True
        assert output["complete"] is True

    def test_v10x_strict_fails_when_artifact_removed(
            self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        [artifact] = bundle["artifacts"]
        (tmp_path / artifact["path"]).unlink()
        monkeypatch.chdir(tmp_path)
        # lenient stays green (forever contract untouched)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["artifacts_missing"] == 1
        # strict goes red on the missing evidence
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        strict_code = exc_info.value.code
        strict_output = json.loads(capsys.readouterr().out)
        assert (0 if strict_code is None else strict_code) == 1
        assert strict_output["verified"] is False
        assert any(e.startswith("[strict] Artifact not found")
                   for e in strict_output["errors"])
        assert strict_output["complete"] is False

    def test_attestation_skipped_silent_and_format_names_bundle_version(
            self, tmp_path, monkeypatch, capsys):
        """v1.3 forever-contract additions: an absent attestation is SILENT —
        all three attestation checks skipped, zero errors, zero warnings — in
        lenient AND strict mode, and the format check's detail names the
        BUNDLE's version, never the verifier's. Shared across all three frozen
        fixture classes via method aliasing."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        for strict in (False, True):
            args = MagicMock()
            args.rpack = str(rpack)
            args.strict = strict
            with pytest.raises(SystemExit) as exc_info:
                fp.cmd_verify(args)
            code = exc_info.value.code
            output = json.loads(capsys.readouterr().out)
            assert (0 if code is None else code) == 0
            assert output["errors"] == []
            assert output["warnings"] == []
            statuses = {c["name"]: c["status"] for c in output["checks"]}
            assert statuses["attestation"] == "skipped"
            assert statuses["attestation_signature"] == "skipped"
            assert statuses["attestation_subjects"] == "skipped"
            fmt = [c for c in output["checks"] if c["name"] == "format"][0]
            assert fmt["status"] == "ok"
            assert "1.0.0" in fmt["detail"]


# ---------------------------------------------------------------------------
# v1.1.0 compatibility (forever contract — ROADMAP Principle 1)
# ---------------------------------------------------------------------------


class TestV110Compat:
    """The checked-in fixture bundle was generated by the unmodified v1.1.0
    engine. Any `.rpack` ever signed must verify with every future version of
    the verifier — this test must never be weakened and the fixture must never
    be regenerated. If a change breaks it, the change is wrong.
    """

    # Same capability gate and verify driver as TestV101Compat — reused
    # verbatim so both forever contracts stay behaviourally identical.
    _require_sshkeygen = TestV101Compat._require_sshkeygen
    _verify = TestV101Compat._verify
    test_attestation_skipped_silent_and_format_names_bundle_version = (
        TestV101Compat
        .test_attestation_skipped_silent_and_format_names_bundle_version)

    def _deploy(self, tmp_path):
        """Lay the fixture out the way a real checkout looks: chain and bundle
        under .forgeproof/, artifact at its recorded relative path."""
        chain_dir = tmp_path / ".forgeproof"
        chain_dir.mkdir()
        shutil.copyfile(FIXTURE_V110 / "chain-998.json", chain_dir / "chain-998.json")
        shutil.copyfile(FIXTURE_V110 / "issue-998.rpack", chain_dir / "issue-998.rpack")
        src = tmp_path / "src"
        src.mkdir()
        shutil.copyfile(FIXTURE_V110 / "src" / "example2.py", src / "example2.py")
        return chain_dir / "issue-998.rpack"

    def test_fixture_files_present(self):
        assert (FIXTURE_V110 / "chain-998.json").exists()
        assert (FIXTURE_V110 / "issue-998.rpack").exists()
        assert (FIXTURE_V110 / "src" / "example2.py").exists()

    def test_fixture_is_byte_exact(self):
        """Guards against EOL conversion or accidental edits. Fixture files are
        stored LF-only (see .gitattributes): the artifact hash covers raw bytes,
        and chain_hash covers the text the engine sees via read_text() — with
        LF bytes on disk the two views are identical on every platform."""
        for rel in ("chain-998.json", "issue-998.rpack", "src/example2.py"):
            assert b"\r" not in (FIXTURE_V110 / rel).read_bytes(), (
                f"fixture file {rel} gained CR bytes (EOL conversion?)"
            )
        bundle = json.loads((FIXTURE_V110 / "issue-998.rpack").read_bytes())
        [artifact] = bundle["artifacts"]
        assert artifact["path"] == "src/example2.py"
        actual = fp.sha256_file(FIXTURE_V110 / "src" / "example2.py")
        assert actual == artifact["sha256"], (
            "fixture artifact bytes changed on disk"
        )
        chain_text = (FIXTURE_V110 / "chain-998.json").read_bytes().decode("utf-8")
        assert fp.sha256_hex(chain_text) == bundle["chain_hash"], (
            "fixture chain file bytes changed on disk"
        )

    def test_v110_bundle_verifies(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["artifacts_checked"] == 1
        assert output["artifacts_missing"] == 0
        assert output["artifacts_tampered"] == 0

    def test_v110_tampered_artifact_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        artifact = tmp_path / "src" / "example2.py"
        data = bytearray(artifact.read_bytes())
        data[0] ^= 0xFF  # flip one byte
        artifact.write_bytes(bytes(data))
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert output["artifacts_tampered"] == 1

    def test_v110_tampered_chain_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        chain_file = tmp_path / ".forgeproof" / "chain-998.json"
        chain = json.loads(chain_file.read_text())
        chain[2]["data"]["choice"] = "history, rewritten"
        chain_file.write_text(json.dumps(chain, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("hash mismatch" in e.lower() for e in output["errors"])

    def test_v110_tampered_signature_fails(self, tmp_path, monkeypatch, capsys):
        """Exercises the Ed25519 failure branch specifically: the signature
        field is excluded from the root digest, so corrupting it leaves the
        digest intact — only real signature verification can catch it. A
        verify_signature that false-positives makes this test fail."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text())
        # Corrupt the base64 payload inside the SSHSIG armor
        lines = bundle["signature"].splitlines()
        middle = len(lines) // 2
        lines[middle] = lines[middle][::-1]
        bundle["signature"] = "\n".join(lines)
        rpack.write_text(json.dumps(bundle, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("signature verification FAILED" in e for e in output["errors"])

    # -- v1.2.0 additive coverage (strict mode must honor the forever
    #    contract: old bundles with all evidence present pass --strict) -----

    def test_v110_bundle_passes_strict(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        code = exc_info.value.code
        output = json.loads(capsys.readouterr().out)
        assert (0 if code is None else code) == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["strict"] is True
        assert output["complete"] is True

    def test_v110_strict_fails_when_artifact_removed(
            self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        [artifact] = bundle["artifacts"]
        (tmp_path / artifact["path"]).unlink()
        monkeypatch.chdir(tmp_path)
        # lenient stays green (forever contract untouched)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["artifacts_missing"] == 1
        # strict goes red on the missing evidence
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        strict_code = exc_info.value.code
        strict_output = json.loads(capsys.readouterr().out)
        assert (0 if strict_code is None else strict_code) == 1
        assert strict_output["verified"] is False
        assert any(e.startswith("[strict] Artifact not found")
                   for e in strict_output["errors"])
        assert strict_output["complete"] is False


# ---------------------------------------------------------------------------
# v1.2.2 compatibility (forever contract — ROADMAP Principle 1)
# ---------------------------------------------------------------------------


class TestV122Compat:
    """The checked-in fixture bundle was generated by the unmodified v1.2.2
    engine — the last pre-attestation bundle format. Any `.rpack` ever signed
    must verify with every future version of the verifier — this test must
    never be weakened and the fixture must never be regenerated. If a change
    breaks it, the change is wrong.
    """

    # Same capability gate and verify driver as TestV101Compat — reused
    # verbatim so all forever contracts stay behaviourally identical.
    _require_sshkeygen = TestV101Compat._require_sshkeygen
    _verify = TestV101Compat._verify
    test_attestation_skipped_silent_and_format_names_bundle_version = (
        TestV101Compat
        .test_attestation_skipped_silent_and_format_names_bundle_version)

    def _deploy(self, tmp_path):
        """Lay the fixture out the way a real checkout looks: chain and bundle
        under .forgeproof/, artifact at its recorded relative path."""
        chain_dir = tmp_path / ".forgeproof"
        chain_dir.mkdir()
        shutil.copyfile(FIXTURE_V122 / "chain-997.json", chain_dir / "chain-997.json")
        shutil.copyfile(FIXTURE_V122 / "issue-997.rpack", chain_dir / "issue-997.rpack")
        src = tmp_path / "src"
        src.mkdir()
        shutil.copyfile(FIXTURE_V122 / "src" / "example3.py", src / "example3.py")
        return chain_dir / "issue-997.rpack"

    def test_fixture_files_present(self):
        assert (FIXTURE_V122 / "chain-997.json").exists()
        assert (FIXTURE_V122 / "issue-997.rpack").exists()
        assert (FIXTURE_V122 / "src" / "example3.py").exists()

    def test_fixture_is_byte_exact(self):
        """Guards against EOL conversion or accidental edits. Fixture files are
        stored LF-only (see .gitattributes): the artifact hash covers raw bytes,
        and chain_hash covers the text the engine sees via read_text() — with
        LF bytes on disk the two views are identical on every platform."""
        for rel in ("chain-997.json", "issue-997.rpack", "src/example3.py"):
            assert b"\r" not in (FIXTURE_V122 / rel).read_bytes(), (
                f"fixture file {rel} gained CR bytes (EOL conversion?)"
            )
        bundle = json.loads((FIXTURE_V122 / "issue-997.rpack").read_bytes())
        [artifact] = bundle["artifacts"]
        assert artifact["path"] == "src/example3.py"
        actual = fp.sha256_file(FIXTURE_V122 / "src" / "example3.py")
        assert actual == artifact["sha256"], (
            "fixture artifact bytes changed on disk"
        )
        chain_text = (FIXTURE_V122 / "chain-997.json").read_bytes().decode("utf-8")
        assert fp.sha256_hex(chain_text) == bundle["chain_hash"], (
            "fixture chain file bytes changed on disk"
        )

    def test_v122_bundle_verifies(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["artifacts_checked"] == 1
        assert output["artifacts_missing"] == 0
        assert output["artifacts_tampered"] == 0

    def test_v122_tampered_artifact_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        artifact = tmp_path / "src" / "example3.py"
        data = bytearray(artifact.read_bytes())
        data[0] ^= 0xFF  # flip one byte
        artifact.write_bytes(bytes(data))
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert output["artifacts_tampered"] == 1

    def test_v122_tampered_chain_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        chain_file = tmp_path / ".forgeproof" / "chain-997.json"
        chain = json.loads(chain_file.read_text())
        chain[2]["data"]["choice"] = "history, rewritten"
        chain_file.write_text(json.dumps(chain, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("hash mismatch" in e.lower() for e in output["errors"])

    def test_v122_tampered_signature_fails(self, tmp_path, monkeypatch, capsys):
        """Exercises the Ed25519 failure branch specifically: the signature
        field is excluded from the root digest, so corrupting it leaves the
        digest intact — only real signature verification can catch it. A
        verify_signature that false-positives makes this test fail."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text())
        # Corrupt the base64 payload inside the SSHSIG armor
        lines = bundle["signature"].splitlines()
        middle = len(lines) // 2
        lines[middle] = lines[middle][::-1]
        bundle["signature"] = "\n".join(lines)
        rpack.write_text(json.dumps(bundle, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("signature verification FAILED" in e for e in output["errors"])

    def test_v122_bundle_passes_strict(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        code = exc_info.value.code
        output = json.loads(capsys.readouterr().out)
        assert (0 if code is None else code) == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["strict"] is True
        assert output["complete"] is True

    def test_v122_strict_fails_when_artifact_removed(
            self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        [artifact] = bundle["artifacts"]
        (tmp_path / artifact["path"]).unlink()
        monkeypatch.chdir(tmp_path)
        # lenient stays green (forever contract untouched)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["artifacts_missing"] == 1
        # strict goes red on the missing evidence
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        strict_code = exc_info.value.code
        strict_output = json.loads(capsys.readouterr().out)
        assert (0 if strict_code is None else strict_code) == 1
        assert strict_output["verified"] is False
        assert any(e.startswith("[strict] Artifact not found")
                   for e in strict_output["errors"])
        assert strict_output["complete"] is False


# ---------------------------------------------------------------------------
# v1.3.0 compatibility (forever contract — ROADMAP Principle 1)
# ---------------------------------------------------------------------------


class TestV130Compat:
    """The checked-in fixture bundle was generated by the unmodified v1.3.0
    engine — format 1.1.0, the first bundle format with an attestation. Any
    `.rpack` ever signed must verify with every future version of the
    verifier — this test must never be weakened and the fixture must never be
    regenerated. If a change breaks it, the change is wrong.
    """

    # Same capability gate and verify driver as TestV101Compat — reused
    # verbatim so all forever contracts stay behaviourally identical.
    _require_sshkeygen = TestV101Compat._require_sshkeygen
    _verify = TestV101Compat._verify

    def _deploy(self, tmp_path):
        """Lay the fixture out the way a real checkout looks: chain and bundle
        under .forgeproof/, artifact at its recorded relative path."""
        chain_dir = tmp_path / ".forgeproof"
        chain_dir.mkdir()
        shutil.copyfile(FIXTURE_V130 / "chain-996.json", chain_dir / "chain-996.json")
        shutil.copyfile(FIXTURE_V130 / "issue-996.rpack", chain_dir / "issue-996.rpack")
        src = tmp_path / "src"
        src.mkdir()
        shutil.copyfile(FIXTURE_V130 / "src" / "example_v130.py",
                        src / "example_v130.py")
        return chain_dir / "issue-996.rpack"

    def test_fixture_files_present(self):
        assert (FIXTURE_V130 / "chain-996.json").exists()
        assert (FIXTURE_V130 / "issue-996.rpack").exists()
        assert (FIXTURE_V130 / "src" / "example_v130.py").exists()

    def test_fixture_is_byte_exact(self):
        """Guards against EOL conversion or accidental edits. Fixture files are
        stored LF-only (see .gitattributes): the artifact hash covers raw bytes,
        and chain_hash covers the text the engine sees via read_text() — with
        LF bytes on disk the two views are identical on every platform."""
        for rel in ("chain-996.json", "issue-996.rpack", "src/example_v130.py"):
            assert b"\r" not in (FIXTURE_V130 / rel).read_bytes(), (
                f"fixture file {rel} gained CR bytes (EOL conversion?)"
            )
        bundle = json.loads((FIXTURE_V130 / "issue-996.rpack").read_bytes())
        [artifact] = bundle["artifacts"]
        assert artifact["path"] == "src/example_v130.py"
        actual = fp.sha256_file(FIXTURE_V130 / "src" / "example_v130.py")
        assert actual == artifact["sha256"], (
            "fixture artifact bytes changed on disk"
        )
        chain_text = (FIXTURE_V130 / "chain-996.json").read_bytes().decode("utf-8")
        assert fp.sha256_hex(chain_text) == bundle["chain_hash"], (
            "fixture chain file bytes changed on disk"
        )

    def test_v130_bundle_verifies(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["artifacts_checked"] == 1
        assert output["artifacts_missing"] == 0
        assert output["artifacts_tampered"] == 0

    def test_attestation_ok_silent_and_format_names_bundle_version(
            self, tmp_path, monkeypatch, capsys):
        """The first frozen fixture that carries an attestation: all three
        attestation checks ok (not skipped), zero errors, zero warnings — in
        lenient AND strict mode, and the format check's detail names the
        BUNDLE's version (1.1.0)."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        for strict in (False, True):
            args = MagicMock()
            args.rpack = str(rpack)
            args.strict = strict
            with pytest.raises(SystemExit) as exc_info:
                fp.cmd_verify(args)
            code = exc_info.value.code
            output = json.loads(capsys.readouterr().out)
            assert (0 if code is None else code) == 0
            assert output["errors"] == []
            assert output["warnings"] == []
            statuses = {c["name"]: c["status"] for c in output["checks"]}
            assert statuses["attestation"] == "ok"
            assert statuses["attestation_signature"] == "ok"
            assert statuses["attestation_subjects"] == "ok"
            fmt = [c for c in output["checks"] if c["name"] == "format"][0]
            assert fmt["status"] == "ok"
            assert "1.1.0" in fmt["detail"]

    def test_v130_tampered_artifact_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        artifact = tmp_path / "src" / "example_v130.py"
        data = bytearray(artifact.read_bytes())
        data[0] ^= 0xFF  # flip one byte
        artifact.write_bytes(bytes(data))
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert output["artifacts_tampered"] == 1

    def test_v130_tampered_chain_fails(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        chain_file = tmp_path / ".forgeproof" / "chain-996.json"
        chain = json.loads(chain_file.read_text())
        chain[2]["data"]["choice"] = "history, rewritten"
        chain_file.write_text(json.dumps(chain, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("hash mismatch" in e.lower() for e in output["errors"])

    def test_v130_tampered_signature_fails(self, tmp_path, monkeypatch, capsys):
        """Exercises the Ed25519 failure branch specifically: the signature
        field is excluded from the root digest, so corrupting it leaves the
        digest intact — only real signature verification can catch it. A
        verify_signature that false-positives makes this test fail."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text())
        # Corrupt the base64 payload inside the SSHSIG armor
        lines = bundle["signature"].splitlines()
        middle = len(lines) // 2
        lines[middle] = lines[middle][::-1]
        bundle["signature"] = "\n".join(lines)
        rpack.write_text(json.dumps(bundle, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        assert any("signature verification FAILED" in e for e in output["errors"])

    def test_v130_tampered_attestation_fails(self, tmp_path, monkeypatch, capsys):
        """The attestation is embedded BEFORE root_digest is computed, so one
        flipped byte inside it turns the root digest red."""
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text())
        env = bundle["attestation"]["dsseEnvelope"]
        payload = env["payload"]
        env["payload"] = ("B" if payload[0] == "A" else "A") + payload[1:]
        rpack.write_text(json.dumps(bundle, indent=2) + "\n")
        monkeypatch.chdir(tmp_path)
        code, output = self._verify(rpack, capsys)
        assert code == 1
        assert output["verified"] is False
        statuses = {c["name"]: c["status"] for c in output["checks"]}
        assert statuses["root_digest"] == "fail"

    def test_v130_bundle_passes_strict(self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        monkeypatch.chdir(tmp_path)
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        code = exc_info.value.code
        output = json.loads(capsys.readouterr().out)
        assert (0 if code is None else code) == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["strict"] is True
        assert output["complete"] is True

    def test_v130_strict_fails_when_artifact_removed(
            self, tmp_path, monkeypatch, capsys):
        self._require_sshkeygen()
        rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        [artifact] = bundle["artifacts"]
        (tmp_path / artifact["path"]).unlink()
        monkeypatch.chdir(tmp_path)
        # lenient stays green (forever contract untouched)
        code, output = self._verify(rpack, capsys)
        assert code == 0
        assert output["verified"] is True
        assert output["artifacts_missing"] == 1
        # strict goes red on the missing evidence
        args = fp.build_parser().parse_args(
            ["verify", "--rpack", str(rpack), "--strict"])
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(args)
        strict_code = exc_info.value.code
        strict_output = json.loads(capsys.readouterr().out)
        assert (0 if strict_code is None else strict_code) == 1
        assert strict_output["verified"] is False
        assert any(e.startswith("[strict] Artifact not found")
                   for e in strict_output["errors"])
        assert strict_output["complete"] is False


# ---------------------------------------------------------------------------
# v1.2.0 verify v2 (bundle-anchored paths, strict/complete, structured output)
# ---------------------------------------------------------------------------


def _deploy_v12_project(proj: Path, issue: str = "1") -> Path:
    """Deploy a minimal validly-signed bundle the way a real checkout looks:
    chain + bundle under proj/.forgeproof/, one artifact at its recorded
    relative path. Mirrors TestCmdVerify._build_minimal_bundle (copied, not
    shared — that class is frozen) but writes a real .forgeproof layout so
    anchoring and strictness can be exercised. Signs for real (v1.2.1 requires
    a valid signature to verify), so callers gate on ssh-keygen via the skip
    below."""
    _skip_without_sshkeygen()
    fdir = proj / ".forgeproof"
    fdir.mkdir(parents=True, exist_ok=True)
    src = proj / "src"
    src.mkdir(parents=True, exist_ok=True)
    artifact = src / "anchored.py"
    artifact.write_text("ANSWER = 42\n", encoding="utf-8")

    genesis = fp.build_block(
        index=0, action="genesis",
        data={"issue": int(issue), "title": "Anchor test",
              "requirements": ["REQ-1: X"]},
        prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
    )
    edit = fp.build_block(
        index=1, action="file-edit",
        data={"path": "src/anchored.py", "operation": "create",
              "sha256": fp.sha256_file(artifact)},
        prev_hash=genesis["hash"], key_path=None,
    )
    fin = fp.build_block(
        index=2, action="finalize",
        data={"commit_sha": "c" * 40, "chain_length": 3},
        prev_hash=edit["hash"], key_path=None,
    )
    chain_file = fdir / f"chain-{issue}.json"
    chain_file.write_text(json.dumps([genesis, edit, fin], indent=2) + "\n",
                          encoding="utf-8")

    bundle = {
        "version": fp.RPACK_VERSION,
        "format": fp.RPACK_FORMAT,
        "issue": {"number": int(issue), "title": "Anchor test", "url": ""},
        "requirements": [{"id": "REQ-1", "text": "X", "status": "covered",
                          "tests": ["t1"]}],
        "artifacts": [{"path": "src/anchored.py", "operation": "create",
                       "sha256": fp.sha256_file(artifact)}],
        "decisions": [{"context": "how to anchor", "choice": "bundle parent",
                       "rationale": "portable verification"}],
        "evaluation": {
            "status": "pass",
            "tests_passed": 1,
            "tests_failed": 0,
            "lint_errors": 0,
            "requirement_coverage": "100%",
            "uncovered_requirements": [],
            "failed_tests": [],
        },
        "chain_hash": fp.sha256_hex(chain_file.read_text(encoding="utf-8")),
    }
    _sign_bundle(bundle)
    rpack = fdir / f"issue-{issue}.rpack"
    rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
    return rpack


def _run_verify(argv: list[str], capsys) -> tuple[int, str]:
    """Drive cmd_verify in-process through the real argparse surface,
    returning (exit code, raw stdout)."""
    args = fp.build_parser().parse_args(["verify", *argv])
    with pytest.raises(SystemExit) as exc_info:
        fp.cmd_verify(args)
    code = exc_info.value.code
    return (0 if code is None else code), capsys.readouterr().out


class TestVerifyRequiresSignature:
    """v1.2.1 security fix: a bundle without a present, canonical, valid
    signature (and a present public_key) must NOT verify. Before this, a
    missing/blank signature was only a warning, so an attacker could rewrite
    an artifact, re-record its hash, strip the signature, and recompute the
    (public, keyless) root_digest to get verified:true — a complete forgery.

    These are RED-path tests and deliberately need no ssh-keygen: the whole
    point is that an unsigned-but-digest-consistent bundle is rejected. A
    non-empty placeholder public_key string is used only to steer which branch
    is exercised; it is never cryptographically checked when no signature is
    present. Tamper payloads are inert marker strings — verify only hashes
    artifact bytes, never executes them."""

    DUMMY_PUBKEY = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAITESTPLACEHOLDER test"

    def _consistent_bundle(self, tmp_chain_dir, *, artifact=None):
        """Build a bundle whose root_digest is internally consistent (the exact
        thing an attacker can forge with no key), leaving signature/public_key
        for the caller to set. Returns (rpack_path, bundle-dict) NOT yet written
        with sig/pubkey — caller finalizes and writes."""
        issue = "1"
        genesis = fp.build_block(
            index=0, action="genesis",
            data={"issue": 1, "title": "Test", "requirements": ["REQ-1: X"]},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        fp.save_chain(issue, [genesis])
        artifacts = []
        if artifact is not None:
            path, content = artifact
            fpath = tmp_chain_dir / path
            fpath.parent.mkdir(parents=True, exist_ok=True)
            fpath.write_text(content, encoding="utf-8")
            artifacts = [{"path": path, "operation": "create",
                          "sha256": fp.sha256_file(fpath)}]
        bundle = {
            "version": fp.RPACK_VERSION,
            "format": fp.RPACK_FORMAT,
            "issue": {"number": 1, "title": "Test", "url": ""},
            "requirements": [{"id": "REQ-1", "text": "X", "status": "covered",
                              "tests": ["t1"]}],
            "artifacts": artifacts,
            "decisions": [],
            "evaluation": {"status": "pass", "tests_passed": 1, "tests_failed": 0,
                           "lint_errors": 0, "requirement_coverage": "100%",
                           "uncovered_requirements": [], "failed_tests": []},
            "chain_hash": fp.sha256_hex(fp.chain_path(issue).read_text()),
        }
        return tmp_chain_dir / f"issue-{issue}.rpack", bundle

    def _seal_and_write(self, rpack_path, bundle):
        """Recompute root_digest over the bundle as it stands (public_key must
        already be set if present), exactly as the verifier will recompute it,
        then write. This is the attacker's keyless reseal."""
        digest_view = {k: v for k, v in bundle.items()
                       if k not in ("root_digest", "signature")}
        bundle["root_digest"] = fp.sha256_hex(fp.canonical_json(digest_view))
        rpack_path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")

    def test_missing_signature_key_is_red(self, tmp_chain_dir, capsys):
        rpack_path, bundle = self._consistent_bundle(tmp_chain_dir)
        bundle["public_key"] = self.DUMMY_PUBKEY  # present, but no signature
        self._seal_and_write(rpack_path, bundle)  # no "signature" key at all
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert any("signature" in e.lower() for e in output["errors"])

    def test_blank_signature_is_red(self, tmp_chain_dir, capsys):
        rpack_path, bundle = self._consistent_bundle(tmp_chain_dir)
        bundle["public_key"] = self.DUMMY_PUBKEY
        self._seal_and_write(rpack_path, bundle)
        bundle["signature"] = ""
        rpack_path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert any("signature" in e.lower() for e in output["errors"])

    def test_blank_public_key_is_red(self, tmp_chain_dir, capsys):
        # public_key stripped and resealed, a stale signature left in place so
        # the pubkey branch (not the missing-signature branch) is exercised.
        rpack_path, bundle = self._consistent_bundle(tmp_chain_dir)
        bundle["public_key"] = ""
        self._seal_and_write(rpack_path, bundle)
        bundle["signature"] = "-----BEGIN SSH SIGNATURE-----\nAAAA\n-----END SSH SIGNATURE-----"
        rpack_path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert any("public key" in e.lower() or "public_key" in e.lower()
                   for e in output["errors"])

    def test_full_forge_is_red_even_lenient(self, tmp_chain_dir, capsys):
        # The exact attack: attacker-controlled artifact content, its hash
        # re-recorded so the artifact check passes, no signature, digest
        # resealed. Even in LENIENT mode (no --strict) this must be red — the
        # signature is the gate, unconditionally. Inert marker payload; verify
        # only SHA-256s the bytes, never runs them.
        rpack_path, bundle = self._consistent_bundle(
            tmp_chain_dir, artifact=("src/evil.py", "INJECTED_TAMPER_MARKER = 1\n"))
        bundle["public_key"] = self.DUMMY_PUBKEY
        self._seal_and_write(rpack_path, bundle)  # consistent digest, no signature
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert output["artifacts_checked"] == 1  # the forged artifact hashes clean...
        assert output["artifacts_tampered"] == 0  # ...digest is consistent; sig is the gate
        assert any("signature" in e.lower() for e in output["errors"])

    def test_forge_renders_verification_failed_not_tamper(self, tmp_chain_dir, capsys):
        rpack_path, bundle = self._consistent_bundle(tmp_chain_dir)
        bundle["public_key"] = self.DUMMY_PUBKEY
        self._seal_and_write(rpack_path, bundle)
        code, out = _run_verify(
            ["--rpack", str(rpack_path), "--format", "markdown"], capsys)
        assert code == 1
        assert "VERIFICATION FAILED" in out
        assert "TAMPER" not in out


class TestVerifyAnchoring:
    """Issue #8: verify resolves the chain file and artifacts against the
    bundle's location (anchor), not the caller's cwd — with a cwd fallback
    preserving every pre-v1.2.0 layout."""

    def test_verify_green_from_unrelated_cwd(self, tmp_path, monkeypatch, capsys):
        proj = tmp_path / "proj"
        rpack = _deploy_v12_project(proj)
        elsewhere = tmp_path / "elsewhere"
        elsewhere.mkdir()
        monkeypatch.chdir(elsewhere)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert not any("Chain file not found" in w for w in output["warnings"])
        assert output["artifacts_checked"] == 1
        assert output["artifacts_missing"] == 0

    def test_explicit_project_root_wins(self, tmp_path, monkeypatch, capsys):
        proj = tmp_path / "proj"
        rpack = _deploy_v12_project(proj)
        bare = tmp_path / "bare"
        bare.mkdir()
        moved = bare / "issue-1.rpack"
        shutil.copyfile(rpack, moved)
        elsewhere = tmp_path / "elsewhere"
        elsewhere.mkdir()
        monkeypatch.chdir(elsewhere)
        code, out = _run_verify(
            ["--rpack", str(moved), "--project-root", str(proj)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert output["artifacts_checked"] == 1
        assert not any("Chain file not found" in w for w in output["warnings"])
        assert output["anchor"] == str(proj)

    def test_lone_bundle_cwd_fallback_preserved(self, tmp_path, monkeypatch, capsys):
        """Today's behavior: a bundle copied to a bare directory, verified
        with cwd at the project, still finds chain and artifacts via cwd."""
        proj = tmp_path / "proj"
        rpack = _deploy_v12_project(proj)
        bare = tmp_path / "bare"
        bare.mkdir()
        moved = bare / "issue-1.rpack"
        shutil.copyfile(rpack, moved)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(moved)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert output["artifacts_checked"] == 1
        assert not any("Chain file not found" in w for w in output["warnings"])

    def test_anchor_field_reported(self, tmp_path, monkeypatch, capsys):
        proj = tmp_path / "proj"
        rpack = _deploy_v12_project(proj)
        monkeypatch.chdir(tmp_path)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        assert code == 0
        # bundle sits in proj/.forgeproof -> anchor is proj
        assert output["anchor"] == str(proj)


class TestVerifyStrict:
    """Issue #9: --strict turns missing evidence into errors; `complete`
    reports whether all evidence was present, in both modes."""

    def _deploy(self, tmp_path):
        proj = tmp_path / "proj"
        return proj, _deploy_v12_project(proj)

    def test_missing_artifact_lenient_warns(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / "src" / "anchored.py").unlink()
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert any("Artifact not found" in w for w in output["warnings"])
        assert output["artifacts_missing"] == 1
        assert output["complete"] is False
        assert output["strict"] is False

    def test_missing_artifact_strict_fails(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / "src" / "anchored.py").unlink()
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack), "--strict"], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert any(e.startswith("[strict] Artifact not found")
                   for e in output["errors"])
        assert output["artifacts_missing"] == 1
        assert output["complete"] is False
        assert output["strict"] is True

    def test_missing_chain_lenient_warns(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / ".forgeproof" / "chain-1.json").unlink()
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert any("Chain file not found" in w for w in output["warnings"])
        assert output["complete"] is False

    def test_missing_chain_strict_fails(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / ".forgeproof" / "chain-1.json").unlink()
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack), "--strict"], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert any(e.startswith("[strict] Chain file not found")
                   for e in output["errors"])
        assert output["complete"] is False

    def test_fully_present_strict_green(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack), "--strict"], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert output["errors"] == []
        assert output["complete"] is True
        assert output["strict"] is True


class TestVerifyContract:
    """The seven legacy verify JSON keys are a frozen contract consumed by the
    verify skill, CI, and the future GitHub Action. Snapshot their VALUES for
    a green and a tampered bundle so any drift is a loud failure."""

    LEGACY_KEYS = ["verified", "evaluation_status", "errors", "warnings",
                   "artifacts_checked", "artifacts_missing",
                   "artifacts_tampered"]

    def _build_minimal_bundle(self, tmp_chain_dir, issue="1"):
        """Copied from TestCmdVerify._build_minimal_bundle (frozen class), now
        validly signed (v1.2.1 requires a signature to verify). Gates on
        ssh-keygen via the skip below."""
        _skip_without_sshkeygen()
        genesis = fp.build_block(
            index=0, action="genesis",
            data={"issue": 1, "title": "Test", "requirements": ["REQ-1: X"]},
            prev_hash=fp.GENESIS_PREV_HASH, key_path=None,
        )
        fp.save_chain(issue, [genesis])

        bundle = {
            "version": fp.RPACK_VERSION,
            "format": fp.RPACK_FORMAT,
            "issue": {"number": 1, "title": "Test", "url": ""},
            "requirements": [{"id": "REQ-1", "text": "X", "status": "covered", "tests": ["t1"]}],
            "artifacts": [],
            "decisions": [],
            "evaluation": {
                "status": "pass",
                "tests_passed": 1,
                "tests_failed": 0,
                "lint_errors": 0,
                "requirement_coverage": "100%",
                "uncovered_requirements": [],
                "failed_tests": [],
            },
            "chain_hash": fp.sha256_hex(fp.chain_path(issue).read_text()),
        }
        _sign_bundle(bundle)

        rpack_path = tmp_chain_dir / f"issue-{issue}.rpack"
        rpack_path.write_text(json.dumps(bundle, indent=2))
        return rpack_path, bundle

    def test_green_bundle_legacy_values_snapshot(self, tmp_chain_dir, capsys):
        rpack_path, _ = self._build_minimal_bundle(tmp_chain_dir)
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["verified"] is True
        assert output["evaluation_status"] == "pass"
        assert output["errors"] == []
        assert output["warnings"] == []  # v1.2.1: a valid signature emits no warning
        assert output["artifacts_checked"] == 0
        assert output["artifacts_missing"] == 0
        assert output["artifacts_tampered"] == 0
        # legacy keys come first, in their pre-v1.2.0 order
        assert list(output)[:7] == self.LEGACY_KEYS

    def test_tampered_bundle_legacy_values_snapshot(self, tmp_chain_dir, capsys):
        rpack_path, bundle = self._build_minimal_bundle(tmp_chain_dir)
        bundle["evaluation"]["tests_passed"] = 999
        rpack_path.write_text(json.dumps(bundle, indent=2))
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 1
        assert output["verified"] is False
        assert output["evaluation_status"] == "pass"  # sealed claim, key intact
        # root_digest mismatch fires; the signature (over the unchanged stored
        # digest) still validates, so it stays the single error.
        assert len(output["errors"]) == 1
        assert output["errors"][0].startswith("Root digest mismatch: computed ")
        assert output["warnings"] == []
        assert output["artifacts_checked"] == 0
        assert output["artifacts_missing"] == 0
        assert output["artifacts_tampered"] == 0
        assert list(output)[:7] == self.LEGACY_KEYS

    def test_new_keys_shape(self, tmp_chain_dir, capsys):
        rpack_path, _ = self._build_minimal_bundle(tmp_chain_dir)
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert isinstance(output["anchor"], str)
        assert output["strict"] is False
        assert output["complete"] is True
        assert [c["name"] for c in output["checks"]] == [
            "format", "root_digest", "signature", "chain_hash",
            "chain_linkage", "artifacts", "coverage",
            "attestation", "attestation_signature", "attestation_subjects"]
        for c in output["checks"]:
            assert c["status"] in ("ok", "fail", "warn", "skipped")
            assert isinstance(c["detail"], str)
        statuses = {c["name"]: c["status"] for c in output["checks"]}
        assert statuses["format"] == "ok"
        assert statuses["root_digest"] == "ok"
        assert statuses["signature"] == "ok"  # v1.2.1: minimal bundle is now signed
        assert statuses["chain_hash"] == "ok"
        assert statuses["chain_linkage"] == "ok"
        assert statuses["artifacts"] == "ok"
        assert statuses["coverage"] == "ok"
        # v1.3: absent attestation is SILENT — skipped, no errors, no warnings.
        assert statuses["attestation"] == "skipped"
        assert statuses["attestation_signature"] == "skipped"
        assert statuses["attestation_subjects"] == "skipped"
        assert output["warnings"] == []
        # New result keys stay strictly after the frozen seven + v1.2.0 set.
        assert list(output)[7:] == ["anchor", "strict", "complete", "checks",
                                    "bundle", "attestation"]
        assert output["attestation"] == {
            "present": False, "predicate_type": None, "subject_count": None,
            "key_id": None, "builder": None, "approvals": []}
        b = output["bundle"]
        assert set(b) == {"issue", "title", "root_digest", "public_key",
                          "chain_length", "first_timestamp", "last_timestamp",
                          "commit_sha", "evaluation_status"}
        assert b["issue"] == 1
        assert b["title"] == "Test"
        assert b["chain_length"] == 1
        assert isinstance(b["first_timestamp"], str)
        assert b["first_timestamp"] == b["last_timestamp"]
        assert b["commit_sha"] is None  # minimal chain has no finalize block
        assert b["evaluation_status"] == "pass"

    def test_checks_skipped_without_chain(self, tmp_chain_dir, capsys):
        rpack_path, _ = self._build_minimal_bundle(tmp_chain_dir)
        fp.chain_path("1").unlink()
        code, out = _run_verify(["--rpack", str(rpack_path)], capsys)
        output = json.loads(out)
        assert code == 0
        statuses = {c["name"]: c["status"] for c in output["checks"]}
        assert statuses["chain_hash"] == "warn"
        assert statuses["chain_linkage"] == "skipped"
        b = output["bundle"]
        assert b["chain_length"] is None
        assert b["first_timestamp"] is None
        assert b["last_timestamp"] is None
        assert b["commit_sha"] is None


class TestVerifyMarkdown:
    """--format markdown renders the same result dict as an audit report:
    identical exit codes to JSON mode, human-readable verdict on stdout."""

    def _deploy(self, tmp_path):
        proj = tmp_path / "proj"
        return proj, _deploy_v12_project(proj)

    def test_green_renders_verified_headline(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        monkeypatch.chdir(proj)
        json_code, _ = _run_verify(["--rpack", str(rpack)], capsys)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code == 0
        assert code == json_code
        assert "## ✅ VERIFIED" in out
        assert "TAMPER" not in out
        assert "incomplete" not in out.splitlines()[0]
        # the sealed-claims disclaimer must be present verbatim
        assert "claims recorded at signing time" in out
        # markdown, not JSON
        assert not out.lstrip().startswith("{")

    def test_green_report_sections(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        monkeypatch.chdir(proj)
        _, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert "### Checks" in out
        assert "### Provenance timeline" in out
        assert "### Artifacts" in out
        assert "src/anchored.py" in out
        assert "### Decisions" in out
        assert "### Evaluation (recorded claims)" in out
        assert "Strict mode: off" in out

    def test_tampered_renders_tamper_headline(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / "src" / "anchored.py").write_text("ANSWER = 43\n",
                                                  encoding="utf-8")
        monkeypatch.chdir(proj)
        json_code, _ = _run_verify(["--rpack", str(rpack)], capsys)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code == 1
        assert code == json_code
        assert "## ❌ TAMPER DETECTED" in out
        assert not out.lstrip().startswith("{")

    def test_strict_incomplete_renders_warning_with_failed_note(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / "src" / "anchored.py").unlink()
        monkeypatch.chdir(proj)
        json_code, _ = _run_verify(["--rpack", str(rpack), "--strict"], capsys)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--strict", "--format", "markdown"], capsys)
        assert code == 1
        assert code == json_code
        # missing evidence is not tampering: the wording must not cry wolf
        assert "## ⚠️ VERIFIED (incomplete — evidence missing)" in out
        assert "TAMPER" not in out
        assert "FAILED" in out
        assert not out.lstrip().startswith("{")

    def test_lenient_incomplete_renders_warning_headline(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._deploy(tmp_path)
        (proj / "src" / "anchored.py").unlink()
        monkeypatch.chdir(proj)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code == 0
        assert "## ⚠️ VERIFIED (incomplete — evidence missing)" in out
        assert "FAILED" not in out

    @staticmethod
    def _reseal(rpack, bundle):
        """Re-sign a mutated bundle so only the mutation under test is visible
        to the verifier. v1.2.1 requires a valid signature, so this signs for
        real with the shared test key rather than blanking the signature.
        Callers reach here via _deploy (→ _skip_without_sshkeygen), so
        ssh-keygen is available."""
        _sign_bundle(bundle)
        rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")

    def test_bundle_controlled_markdown_is_neutralized(
            self, tmp_path, monkeypatch, capsys):
        """The report is posted as a PR comment / job summary where bundle
        content is attacker-controlled (fork PRs): links, images, emphasis,
        code spans and HTML smuggled into the issue title, artifact paths or
        decision fields must come out inert."""
        proj, rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        nasty = "`backticks` [link](https://evil.example) **bold** <img>"
        bundle["issue"]["title"] = nasty
        bundle["artifacts"][0]["path"] = f"src/{nasty}.py"
        bundle["decisions"][0]["context"] = nasty
        bundle["decisions"][0]["choice"] = nasty
        bundle["decisions"][0]["rationale"] = nasty
        self._reseal(rpack, bundle)
        monkeypatch.chdir(proj)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code == 0
        # no active markdown from bundle-controlled strings survives
        assert "[link](" not in out
        assert "**bold**" not in out
        assert "<img>" not in out
        assert "`backticks`" not in out
        # the payload is still present, backslash-escaped and readable
        assert "\\[link\\](" in out
        # verdict and report structure are intact (artifact path was changed
        # to the nasty name, so the recorded file is now "missing")
        assert "## ⚠️ VERIFIED (incomplete — evidence missing)" in out
        assert "### Checks" in out
        assert "### Artifacts" in out
        assert "### Decisions" in out
        assert "| format | ok |" in out

    def test_wrong_format_renders_failed_not_tamper(
            self, tmp_path, monkeypatch, capsys):
        """An unrecognized format is 'cannot verify', not tamper evidence:
        the bundle was never valid, so the report must not cry tamper."""
        proj, rpack = self._deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        bundle["format"] = "not-forgeproof"
        self._reseal(rpack, bundle)
        monkeypatch.chdir(proj)
        json_code, _ = _run_verify(["--rpack", str(rpack)], capsys)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code == 1
        assert code == json_code
        assert "## ❌ VERIFICATION FAILED" in out
        assert "TAMPER" not in out


# ---------------------------------------------------------------------------
# v1.2.0 record guards (#6, #7)
# ---------------------------------------------------------------------------


class TestRecordGuards:
    """Record-input guards: negative counts and malformed --covers specs die
    with actionable messages (#6); a finalized chain refuses further records
    without mutating the chain file (#7)."""

    def _record(self, *argv):
        with patch.object(fp, "get_key_path", return_value=None), patch("sys.stdout"):
            fp.cmd_record(fp.build_parser().parse_args(["record", *argv]))

    def test_negative_passed_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "-5", "--failed", "0")
        err = capsys.readouterr().err
        assert "--passed" in err
        assert "negative" in err

    def test_negative_passed_with_real_failures_dies(
            self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "-1", "--failed", "3")
        assert "--passed" in capsys.readouterr().err

    def test_negative_failed_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "3", "--failed", "-2")
        assert "--failed" in capsys.readouterr().err

    def test_negative_lint_errors_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "lint-result",
                         "--tool", "ruff", "--errors", "-1", "--warnings", "0")
        err = capsys.readouterr().err
        assert "--errors" in err
        assert "negative" in err

    def test_covers_empty_test_list_dies(self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "1", "--failed", "0",
                         "--covers", "REQ-2=")
        err = capsys.readouterr().err
        assert "--covers" in err
        assert "must not contain '='" in err

    def test_covers_whitespace_test_list_dies(
            self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "1", "--failed", "0",
                         "--covers", "REQ-2=  , ,")
        assert "--covers" in capsys.readouterr().err

    def test_covers_empty_requirement_id_dies(
            self, sample_chain, tmp_chain_dir, capsys):
        issue, _ = sample_chain
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "1", "--failed", "0",
                         "--covers", "=name")
        err = capsys.readouterr().err
        assert "--covers" in err
        assert "must not contain '='" in err

    def test_guard_rejection_leaves_chain_unmodified(
            self, sample_chain, tmp_chain_dir):
        issue, _ = sample_chain
        chain_file = tmp_chain_dir / f"chain-{issue}.json"
        bytes_before = chain_file.read_bytes()
        with pytest.raises(SystemExit):
            self._record("--issue", issue, "--action", "test-result",
                         "--suite", "pytest", "--passed", "-5", "--failed", "0")
        assert chain_file.read_bytes() == bytes_before

    def test_record_after_finalize_dies_chain_untouched(
            self, tmp_chain_dir, tmp_path, monkeypatch, capsys):
        """#7: init -> record -> finalize -> record again must die loudly and
        must not mutate the finalized chain file."""
        issue = "77"
        monkeypatch.chdir(tmp_path)
        priv = tmp_path / "key"
        pub = tmp_path / "key.pub"
        priv.write_text("fake_private")
        pub.write_text("ssh-ed25519 AAAA fake")
        (tmp_path / "art.py").write_text("a = 1\n")
        with patch.object(fp, "generate_ephemeral_keypair", return_value=(priv, pub)), \
             patch.object(fp, "sign_ed25519", return_value="sig"), patch("sys.stdout"):
            fp.cmd_init(fp.build_parser().parse_args(
                ["init", "--issue", issue, "--title", "guard", "--force"]))
        with patch.object(fp, "get_key_path", return_value=priv), \
             patch.object(fp, "sign_ed25519", return_value="sig"), patch("sys.stdout"):
            fp.cmd_record(fp.build_parser().parse_args(
                ["record", "--issue", issue, "--action", "file-edit",
                 "--path", "art.py", "--operation", "create"]))
        with patch.object(fp, "get_key_path", return_value=priv), \
             patch.object(fp, "sign_ed25519", return_value="sig"), \
             patch.object(fp, "delete_private_key"), \
             patch.object(fp.shutil, "which", return_value=None), \
             patch.object(fp, "load_attestation_signer",
                          return_value=fp.EphemeralEd25519Signer(bytes(32))), \
             patch("sys.stdout"):
            fp.cmd_finalize(fp.build_parser().parse_args(
                ["finalize", "--issue", issue, "--commit", "0" * 40]))
        chain_file = tmp_chain_dir / f"chain-{issue}.json"
        bytes_before = chain_file.read_bytes()
        with pytest.raises(SystemExit):
            with patch.object(fp, "get_key_path", return_value=priv), \
                 patch.object(fp, "sign_ed25519", return_value="sig"), \
                 patch("sys.stdout"):
                fp.cmd_record(fp.build_parser().parse_args(
                    ["record", "--issue", issue, "--action", "decision",
                     "--context", "c", "--choice", "x", "--rationale", "r"]))
        assert "already finalized" in capsys.readouterr().err
        assert chain_file.read_bytes() == bytes_before


# ---------------------------------------------------------------------------
# v1.2.0 detect robustness (#5-partial)
# ---------------------------------------------------------------------------


class TestDetectBrokenVenv:
    """A broken venv interpreter (0-byte python executable) must degrade to
    runtime_available: false — `detect` must ALWAYS emit valid JSON, never an
    OSError traceback. Subprocess pattern: the guarantee is process-level
    (exit code + clean stderr)."""

    def test_detect_survives_zero_byte_venv_python(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text('[project]\nname = "broken"\n')
        win_py = tmp_path / ".venv" / "Scripts" / "python.exe"
        posix_py = tmp_path / ".venv" / "bin" / "python"
        for stub in (win_py, posix_py):
            stub.parent.mkdir(parents=True, exist_ok=True)
            stub.write_bytes(b"")
        os.chmod(posix_py, 0o755)  # executable-but-empty on POSIX (ENOEXEC)
        result = subprocess.run(
            [sys.executable, str(FORGEPROOF_PY), "detect"],
            cwd=tmp_path, capture_output=True, text=True, timeout=60)
        assert "Traceback (most recent call last)" not in result.stderr, (
            f"detect raised on a broken venv interpreter:\n{result.stderr}")
        assert result.returncode == 0, result.stderr
        out = json.loads(result.stdout)
        assert out["detected"] is True
        py = next(l for l in out["languages"] if l["language"] == "python")
        assert py["runtime_available"] is False


# ---------------------------------------------------------------------------
# Integration test (requires ssh-keygen)
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestEndToEnd:
    """Full pipeline: init → record → finalize → verify → tamper → verify fails.

    Requires ssh-keygen on PATH. Skip with: pytest -m 'not integration'
    """

    def test_full_pipeline(self, tmp_chain_dir, tmp_path, capsys, monkeypatch):
        if not shutil.which("ssh-keygen"):
            pytest.skip("ssh-keygen not available")

        issue = "42"
        monkeypatch.chdir(tmp_path)  # artifacts are recorded repo-relative

        # Create a source file to reference as an artifact
        src = tmp_path / "src"
        src.mkdir()
        test_file = src / "hello.py"
        test_file.write_text("print('hello')")
        file_hash = fp.sha256_file(test_file)

        # 1. Init
        fp.cmd_init(fp.build_parser().parse_args([
            "init", "--issue", issue, "--force",
            "--title", "Integration test",
            "--requirement", "REQ-1: Print hello",
        ]))
        capsys.readouterr()  # clear output

        def record(*argv):
            fp.cmd_record(fp.build_parser().parse_args(
                ["record", "--issue", issue, *argv]))
            capsys.readouterr()

        # 2. Record branch-create
        record("--action", "branch-create",
               "--branch", "forgeproof/42", "--base", "main", "--base-sha", "abc")

        # 3. Record file-edit (engine hashes the file natively)
        record("--action", "file-edit",
               "--path", "src/hello.py", "--operation", "create")

        # 4. Record test-result
        record("--action", "test-result", "--suite", "pytest",
               "--passed", "1", "--failed", "0", "--covers", "REQ-1=test_hello")

        # 5. Record lint-result
        record("--action", "lint-result", "--tool", "ruff",
               "--errors", "0", "--warnings", "0")

        # 6. Finalize
        fp.cmd_finalize(fp.build_parser().parse_args(
            ["finalize", "--issue", issue, "--commit", "abc123def456"]))
        capsys.readouterr()

        rpack_path = tmp_chain_dir / f"issue-{issue}.rpack"
        assert rpack_path.exists()

        bundle = json.loads(rpack_path.read_text())
        assert bundle["evaluation"]["status"] == "pass"
        assert bundle["root_digest"]
        assert bundle["signature"]
        assert bundle["artifacts"][0]["sha256"] == file_hash

        # 7. Verify — should pass
        ver_args = MagicMock()
        ver_args.rpack = str(rpack_path)
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(ver_args)
        assert exc_info.value.code == 0

        capsys.readouterr()

        # 8. Tamper with an artifact and re-verify — should fail
        test_file.write_text("print('TAMPERED')")

        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_verify(ver_args)
        assert exc_info.value.code == 1

        output = json.loads(capsys.readouterr().out)
        assert output["verified"] is False
        assert output["artifacts_tampered"] == 1


# Need shutil for the integration test
import shutil


# ---------------------------------------------------------------------------
# v1.3.0 Phase 1 — raw Ed25519 (RFC 8032), OpenSSH seed extraction, DSSE and
# Sigstore-bundle encoding primitives. Pure functions; nothing lifecycle-wired.
# ---------------------------------------------------------------------------

import base64  # noqa: E402
import time  # noqa: E402

# RFC 8032 section 7.1 test vectors (TEST 1, 2, 3). The RFC's "SECRET KEY" is
# the 32-byte seed, so each drops straight into the engine's seed-based API.
RFC8032_VECTORS = [
    (
        "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
        "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a",
        "",
        "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
        "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b",
    ),
    (
        "4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb",
        "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c",
        "72",
        "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da"
        "085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00",
    ),
    (
        "c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7",
        "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025",
        "af82",
        "6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac"
        "18ff9b538d16f290ae67f760984dc6594a7c15e9716ed28dc027beceea1ec40a",
    ),
]

# Group order L, restated independently of the engine (RFC 8032 section 5.1).
ED25519_L_INDEPENDENT = 2**252 + 27742317777372353535851937790883648493
ED25519_P_INDEPENDENT = 2**255 - 19

TEST1_SEED = bytes.fromhex(RFC8032_VECTORS[0][0])
TEST1_PUB = bytes.fromhex(RFC8032_VECTORS[0][1])
TEST1_SIG = bytes.fromhex(RFC8032_VECTORS[0][3])
TEST2_PUB = bytes.fromhex(RFC8032_VECTORS[1][1])


class TestEd25519Primitive:
    """RFC 8032 known-answer vectors plus fixed hostile-encoding vectors."""

    def test_rfc8032_known_answers(self):
        for seed_hex, pub_hex, msg_hex, sig_hex in RFC8032_VECTORS:
            seed = bytes.fromhex(seed_hex)
            msg = bytes.fromhex(msg_hex)
            assert fp.ed25519_public_from_seed(seed).hex() == pub_hex
            assert fp.ed25519_sign(seed, msg).hex() == sig_hex
            assert fp.ed25519_verify(
                bytes.fromhex(pub_hex), msg, bytes.fromhex(sig_hex)
            )

    def test_signing_is_deterministic(self):
        a = fp.ed25519_sign(TEST1_SEED, b"determinism probe")
        b = fp.ed25519_sign(TEST1_SEED, b"determinism probe")
        assert a == b

    def test_verify_rejects_wrong_message(self):
        assert not fp.ed25519_verify(TEST1_PUB, b"x", TEST1_SIG)

    def test_verify_rejects_flipped_signature(self):
        bad = bytearray(TEST1_SIG)
        bad[0] ^= 0x01
        assert not fp.ed25519_verify(TEST1_PUB, b"", bytes(bad))

    def test_verify_rejects_wrong_key(self):
        assert not fp.ed25519_verify(TEST2_PUB, b"", TEST1_SIG)

    def test_malleability_s_plus_l_rejected(self):
        # The exact malleability class this repo patched twice at the SSHSIG
        # tier: s' = s + L verifies under a naive verifier. Must be rejected.
        r_part = TEST1_SIG[:32]
        s = int.from_bytes(TEST1_SIG[32:], "little")
        s_mall = s + ED25519_L_INDEPENDENT
        mall = r_part + s_mall.to_bytes(32, "little")
        assert fp.ed25519_verify(TEST1_PUB, b"", TEST1_SIG)  # sanity
        assert not fp.ed25519_verify(TEST1_PUB, b"", mall)

    def test_truncated_signature_rejected(self):
        assert not fp.ed25519_verify(TEST1_PUB, b"", TEST1_SIG[:63])
        assert not fp.ed25519_verify(TEST1_PUB, b"", b"")
        assert not fp.ed25519_verify(TEST1_PUB, b"", TEST1_SIG + b"\x00")

    def test_wrong_length_public_key_rejected(self):
        assert not fp.ed25519_verify(TEST1_PUB[:31], b"", TEST1_SIG)
        assert not fp.ed25519_verify(TEST1_PUB + b"\x00", b"", TEST1_SIG)
        assert not fp.ed25519_verify(b"", b"", TEST1_SIG)

    def test_noncanonical_y_ge_p_rejected(self):
        # y = p encoded little-endian: numerically 0 mod p but a non-canonical
        # encoding. Rejected as the public key AND as the signature's R point.
        bad_point = ED25519_P_INDEPENDENT.to_bytes(32, "little")
        assert not fp.ed25519_verify(bad_point, b"", TEST1_SIG)
        bad_sig = bad_point + TEST1_SIG[32:]
        assert not fp.ed25519_verify(TEST1_PUB, b"", bad_sig)

    def test_nonsquare_x_rejected(self):
        # y = 2: (y^2-1)/(d*y^2+1) is a quadratic non-residue mod p, so no x
        # exists — decoding must fail (computed independently of the engine).
        bad_point = (2).to_bytes(32, "little")
        assert not fp.ed25519_verify(bad_point, b"", TEST1_SIG)
        bad_sig = bad_point + TEST1_SIG[32:]
        assert not fp.ed25519_verify(TEST1_PUB, b"", bad_sig)

    def test_invalid_sign_bit_x0_rejected(self):
        # y = 1 decodes to x = 0; RFC 8032 5.1.3: "if x = 0 and x_0 = 1,
        # decoding fails". Rejected as public key and as R.
        bad_point = (1 | (1 << 255)).to_bytes(32, "little")
        assert not fp.ed25519_verify(bad_point, b"", TEST1_SIG)
        bad_sig = bad_point + TEST1_SIG[32:]
        assert not fp.ed25519_verify(TEST1_PUB, b"", bad_sig)

    def test_public_from_seed_rejects_bad_length(self):
        with pytest.raises(ValueError):
            fp.ed25519_public_from_seed(b"\x00" * 31)

    def test_signing_timing_floor(self):
        start = time.perf_counter()
        fp.ed25519_sign(TEST1_SEED, b"x" * 100_000)
        assert time.perf_counter() - start < 1.0


# ---------------------------------------------------------------------------
# Hand-built openssh-key-v1 containers, written from the format spec
# independently of the engine parser (the round-trip doubles as a format
# cross-check). Layout: magic, cipher, kdf, kdfoptions, nkeys, public blob(s),
# then the private section (check-int x2, keytype, pub, priv=seed||pub,
# comment, 1,2,3... padding to the 8-byte "none"-cipher block size).
# ---------------------------------------------------------------------------


def _ssh_str(b: bytes) -> bytes:
    return len(b).to_bytes(4, "big") + b


def _openssh_private_key_text(
    seed: bytes,
    pub: bytes,
    cipher: bytes = b"none",
    kdf: bytes = b"none",
    keytype: bytes = b"ssh-ed25519",
    checkints_match: bool = True,
    truncate_at: "int | None" = None,
) -> str:
    check = b"\x12\x34\x56\x78"
    check2 = check if checkints_match else b"\x87\x65\x43\x21"
    private_section = (
        check
        + check2
        + _ssh_str(keytype)
        + _ssh_str(pub)
        + _ssh_str(seed + pub)
        + _ssh_str(b"forgeproof-test@example")
    )
    pad = 1
    private_section = bytearray(private_section)
    while len(private_section) % 8:
        private_section.append(pad)
        pad += 1
    blob = (
        b"openssh-key-v1\x00"
        + _ssh_str(cipher)
        + _ssh_str(kdf)
        + _ssh_str(b"")
        + (1).to_bytes(4, "big")
        + _ssh_str(_ssh_str(keytype) + _ssh_str(pub))
        + _ssh_str(bytes(private_section))
    )
    if truncate_at is not None:
        blob = blob[:truncate_at]
    b64 = base64.b64encode(blob).decode()
    lines = [b64[i:i + 70] for i in range(0, len(b64), 70)]
    return (
        "-----BEGIN OPENSSH PRIVATE KEY-----\n"
        + "\n".join(lines)
        + "\n-----END OPENSSH PRIVATE KEY-----\n"
    )


def _ssh_pub_line(pub: bytes, keytype: bytes = b"ssh-ed25519",
                  comment: str = "User@PC with spaces") -> str:
    blob = _ssh_str(keytype) + _ssh_str(pub)
    return f"ssh-ed25519 {base64.b64encode(blob).decode()} {comment}"


class TestOpenSSHKeyParse:
    """openssh_ed25519_seed + ssh_ed25519_pubkey_bytes: happy path against
    hand-built containers and a real ssh-keygen key; every structural surprise
    dies cleanly (no traceback)."""

    def _write(self, tmp_path, text):
        p = tmp_path / "key"
        p.write_text(text, encoding="utf-8", newline="\n")
        return p

    def test_parses_handbuilt_container(self, tmp_path):
        p = self._write(
            tmp_path, _openssh_private_key_text(TEST1_SEED, TEST1_PUB))
        assert fp.openssh_ed25519_seed(p) == TEST1_SEED

    def test_real_sshkeygen_roundtrip(self):
        _skip_without_sshkeygen()
        priv, pub = fp.generate_ephemeral_keypair("katparse")
        try:
            seed = fp.openssh_ed25519_seed(priv)
            derived = fp.ed25519_public_from_seed(seed)
            blob = fp.ssh_ed25519_pubkey_bytes(pub.read_text().strip())
            assert derived == blob
            sig = fp.ed25519_sign(seed, b"cross-check")
            assert fp.ed25519_verify(blob, b"cross-check", sig)
        finally:
            fp.delete_private_key(priv)

    def _assert_dies(self, path, capsys, fragment=""):
        with pytest.raises(SystemExit):
            fp.openssh_ed25519_seed(path)
        err = capsys.readouterr().err
        assert "forgeproof: error:" in err
        assert "Traceback" not in err
        if fragment:
            assert fragment in err

    def test_missing_file_dies(self, tmp_path, capsys):
        self._assert_dies(tmp_path / "absent", capsys)

    def test_garbage_file_dies(self, tmp_path, capsys):
        self._assert_dies(self._write(tmp_path, "not a key\n"), capsys)

    def test_truncated_container_dies(self, tmp_path, capsys):
        text = _openssh_private_key_text(TEST1_SEED, TEST1_PUB, truncate_at=40)
        self._assert_dies(self._write(tmp_path, text), capsys)

    def test_encrypted_key_dies(self, tmp_path, capsys):
        text = _openssh_private_key_text(
            TEST1_SEED, TEST1_PUB, cipher=b"aes256-ctr", kdf=b"bcrypt")
        self._assert_dies(self._write(tmp_path, text), capsys, "encrypted")

    def test_non_ed25519_key_dies(self, tmp_path, capsys):
        text = _openssh_private_key_text(
            TEST1_SEED, TEST1_PUB, keytype=b"ssh-rsa")
        self._assert_dies(self._write(tmp_path, text), capsys)

    def test_checkint_mismatch_dies(self, tmp_path, capsys):
        text = _openssh_private_key_text(
            TEST1_SEED, TEST1_PUB, checkints_match=False)
        self._assert_dies(self._write(tmp_path, text), capsys)

    def test_derived_pub_mismatch_dies(self, tmp_path, capsys):
        # Internally consistent container whose embedded public key is NOT the
        # one derived from the seed — the parse-bug tripwire must die loudly
        # rather than sign with the wrong key.
        text = _openssh_private_key_text(TEST1_SEED, TEST2_PUB)
        self._assert_dies(self._write(tmp_path, text), capsys)

    def test_pub_line_parses_with_spacey_comment(self):
        line = _ssh_pub_line(TEST1_PUB)
        assert fp.ssh_ed25519_pubkey_bytes(line) == TEST1_PUB

    def test_pub_line_rejects_non_ed25519(self):
        line = _ssh_pub_line(TEST1_PUB).replace(
            "ssh-ed25519 ", "ssh-rsa ", 1)
        with pytest.raises(ValueError):
            fp.ssh_ed25519_pubkey_bytes(line)

    def test_pub_line_rejects_bad_base64(self):
        with pytest.raises(ValueError):
            fp.ssh_ed25519_pubkey_bytes("ssh-ed25519 !!notbase64!! c")

    def test_pub_line_rejects_wrong_blob_header(self):
        blob = _ssh_str(b"ssh-rsa") + _ssh_str(TEST1_PUB)
        line = f"ssh-ed25519 {base64.b64encode(blob).decode()} c"
        with pytest.raises(ValueError):
            fp.ssh_ed25519_pubkey_bytes(line)

    def test_pub_line_rejects_wrong_key_length(self):
        blob = _ssh_str(b"ssh-ed25519") + _ssh_str(TEST1_PUB[:31])
        line = f"ssh-ed25519 {base64.b64encode(blob).decode()} c"
        with pytest.raises(ValueError):
            fp.ssh_ed25519_pubkey_bytes(line)

    def test_pub_line_rejects_empty(self):
        with pytest.raises(ValueError):
            fp.ssh_ed25519_pubkey_bytes("")


class TestDSSEEncoding:
    """PAE, SPKI PEM, envelope + Sigstore bundle builders, and the signer seam.
    Wrapper layout is the amendment-v2 contract: keyid-free signature, empty
    publicKey identifier."""

    def test_pae_known_answer(self):
        # Example from the DSSE protocol spec.
        assert fp.dsse_pae("http://example.com/HelloWorld", b"hello world") == (
            b"DSSEv1 29 http://example.com/HelloWorld 11 hello world"
        )

    def test_pae_empty_payload(self):
        assert fp.dsse_pae("t", b"") == b"DSSEv1 1 t 0 "

    def test_spki_pem_golden(self):
        pem = fp.ed25519_spki_pem(TEST1_PUB)
        assert pem == (
            "-----BEGIN PUBLIC KEY-----\n"
            "MCowBQYDK2VwAyEA11qYAYKxCrfVS/7TyWQHOg7hcvPapiMlrwIaaPcHURo=\n"
            "-----END PUBLIC KEY-----\n"
        )

    def test_spki_pem_body_prefix_invariant(self):
        # Every Ed25519 SPKI body starts with the DER prefix's base64 form.
        body = fp.ed25519_spki_pem(TEST2_PUB).splitlines()[1]
        assert body.startswith("MCowBQYDK2VwAyEA")

    def _signer(self):
        return fp.EphemeralEd25519Signer(TEST1_SEED)

    def test_signer_seam_members(self):
        signer = self._signer()
        assert signer.public_bytes == TEST1_PUB
        assert signer.verification_material() == {"publicKey": {}}
        assert signer.sign(b"m") == fp.ed25519_sign(TEST1_SEED, b"m")

    def test_envelope_shape_and_signature(self):
        signer = self._signer()
        payload = json.dumps({"probe": 1}).encode()
        env = fp.build_dsse_envelope(payload, signer)
        assert set(env.keys()) == {"payload", "payloadType", "signatures"}
        assert env["payloadType"] == "application/vnd.in-toto+json"
        assert len(env["signatures"]) == 1
        # Amendment v2: the signature object carries sig ONLY — no keyid.
        assert set(env["signatures"][0].keys()) == {"sig"}
        # Standard base64 WITH padding, byte-identical on round-trip.
        for value in (env["payload"], env["signatures"][0]["sig"]):
            assert base64.b64encode(base64.b64decode(value)).decode() == value
        assert base64.b64decode(env["payload"]) == payload
        pae = fp.dsse_pae(env["payloadType"], payload)
        assert fp.ed25519_verify(
            signer.public_bytes, pae,
            base64.b64decode(env["signatures"][0]["sig"]))

    def test_bundle_shape(self):
        signer = self._signer()
        env = fp.build_dsse_envelope(b"{}", signer)
        bundle = fp.build_sigstore_bundle(env, signer)
        # protojson rejects unknown fields: nothing ForgeProof-specific in the
        # wrapper, dsseEnvelope a SIBLING of verificationMaterial.
        assert set(bundle.keys()) == {
            "mediaType", "verificationMaterial", "dsseEnvelope"}
        assert bundle["mediaType"] == (
            "application/vnd.dev.sigstore.bundle.v0.3+json")
        # Amendment v2: empty publicKey identifier — no hint, no keyid anywhere.
        assert bundle["verificationMaterial"] == {"publicKey": {}}
        assert bundle["dsseEnvelope"] is env


# ---------------------------------------------------------------------------
# v1.3.0 Phase 2 — approval action, builder identity, attestation emission
# ---------------------------------------------------------------------------


class TestApprovalAction:
    """The approval chain action: shape, engine-filled approver, bounded
    decision values, silent-drop guards, and the explicit fallthrough."""

    def _data(self, argv, approver="dev@example.com"):
        args = fp.build_parser().parse_args(["record", "--issue", "7", *argv])
        with patch.object(fp, "_approver_email", return_value=approver):
            return fp._record_data_from_flags(args)

    def test_approval_block_shape(self):
        data = self._data(["--action", "approval", "--gate", "plan",
                           "--decision", "approved", "--note", "LGTM"])
        assert data == {"gate": "plan", "decision": "approved",
                        "note": "LGTM", "approver": "dev@example.com"}

    def test_note_optional_defaults_empty(self):
        data = self._data(["--action", "approval", "--gate", "plan",
                           "--decision", "rejected"])
        assert data["note"] == ""
        assert data["decision"] == "rejected"

    def test_missing_required_flag_dies(self, capsys):
        args = fp.build_parser().parse_args(
            ["record", "--issue", "7", "--action", "approval",
             "--decision", "approved"])
        with pytest.raises(SystemExit):
            fp._record_data_from_flags(args)
        assert "--gate" in capsys.readouterr().err

    def test_cross_action_misuse_rejected(self, capsys):
        # A stray approval flag on another action must be rejected, not
        # silently dropped (the _RECORD_DATA_FLAGS trap).
        args = fp.build_parser().parse_args(
            ["record", "--issue", "7", "--action", "decision",
             "--context", "c", "--choice", "x", "--rationale", "r",
             "--gate", "plan"])
        with pytest.raises(SystemExit):
            fp._record_data_from_flags(args)
        assert "unexpected --gate" in capsys.readouterr().err

    def test_decision_value_is_bounded(self):
        with pytest.raises(SystemExit):
            fp.build_parser().parse_args(
                ["record", "--issue", "7", "--action", "approval",
                 "--gate", "plan", "--decision", "maybe"])

    def test_approver_from_git_config(self):
        result = MagicMock(returncode=0, stdout="dev@example.com\n")
        with patch.object(fp.shutil, "which", return_value="git"), \
                patch.object(fp, "run", return_value=result):
            assert fp._approver_email() == "dev@example.com"

    def test_approver_git_absent_is_empty(self):
        with patch.object(fp.shutil, "which", return_value=None):
            assert fp._approver_email() == ""

    def test_approver_git_failure_is_empty(self):
        result = MagicMock(returncode=1, stdout="")
        with patch.object(fp.shutil, "which", return_value="git"), \
                patch.object(fp, "run", return_value=result):
            assert fp._approver_email() == ""

    def test_approver_no_identity_is_empty(self):
        # git present but no user.email configured: empty stdout, rc 0.
        result = MagicMock(returncode=0, stdout="\n")
        with patch.object(fp.shutil, "which", return_value="git"), \
                patch.object(fp, "run", return_value=result):
            assert fp._approver_email() == ""

    def test_approver_timeout_is_empty(self):
        with patch.object(fp.shutil, "which", return_value="git"), \
                patch.object(fp, "run",
                             side_effect=subprocess.TimeoutExpired("git", 10)):
            assert fp._approver_email() == ""

    def test_unbranched_action_dies_loudly(self, capsys):
        # A future action added to RECORD_FLAG_SPEC without a data-builder
        # branch must fail loudly, never seal a wrong-shaped dict.
        ns = fp.argparse.Namespace(
            action="futureaction",
            **{f: None for f in fp._RECORD_DATA_FLAGS})
        with patch.dict(fp.RECORD_FLAG_SPEC,
                        {"futureaction": {"required": [], "optional": []}}):
            with pytest.raises(SystemExit):
                fp._record_data_from_flags(ns)
        assert "no data builder" in capsys.readouterr().err

    def test_removed_data_flag_mentions_approval(self, capsys):
        with pytest.raises(SystemExit):
            fp.build_parser().parse_args(
                ["record", "--issue", "7", "--action", "approval",
                 "--data", "{}"])
        assert "approval --gate --decision" in capsys.readouterr().err


def _real_attested_run(tmp_path, monkeypatch, capsys, issue="41",
                       with_artifact=True, model=None):
    """Drive the REAL lifecycle (init → records → approval → finalize) with a
    real ssh-keygen key, returning the emitted bundle, paths, and finalize's
    result JSON. shutil.which is nulled during finalize so the gh and claude
    probes stay offline-deterministic (repo_url "", version "unknown")."""
    _skip_without_sshkeygen()
    monkeypatch.setattr(fp, "CHAIN_DIR", tmp_path / ".forgeproof")
    monkeypatch.chdir(tmp_path)
    parse = fp.build_parser().parse_args
    fp.cmd_init(parse(["init", "--issue", issue, "--title", "Attest run",
                       "--requirement", "REQ-1: emit attestation"]))
    if with_artifact:
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "thing.py").write_text("VALUE = 1\n", encoding="utf-8")
        fp.cmd_record(parse([
            "record", "--issue", issue, "--action", "file-edit",
            "--path", "src/thing.py", "--operation", "create"]))
    fp.cmd_record(parse([
        "record", "--issue", issue, "--action", "test-result",
        "--suite", "pytest", "--passed", "1", "--failed", "0",
        "--covers", "REQ-1=test_thing"]))
    with patch.object(fp, "_approver_email", return_value="ryan@example.com"):
        fp.cmd_record(parse([
            "record", "--issue", issue, "--action", "approval",
            "--gate", "plan", "--decision", "approved", "--note", "LGTM"]))
    capsys.readouterr()
    argv = ["finalize", "--issue", issue, "--commit", "a" * 40]
    if model:
        argv += ["--model", model]
    with patch.object(fp.shutil, "which", return_value=None):
        fp.cmd_finalize(parse(argv))
    result = json.loads(capsys.readouterr().out)
    chain_dir = tmp_path / ".forgeproof"
    rpack = chain_dir / f"issue-{issue}.rpack"
    return {
        "bundle": json.loads(rpack.read_text(encoding="utf-8")),
        "rpack": rpack,
        "sidecar": chain_dir / f"issue-{issue}.sigstore.json",
        "pem": chain_dir / f"issue-{issue}.pub.pem",
        "chain": chain_dir / f"chain-{issue}.json",
        "result": result,
        "issue": issue,
    }


class TestFinalizeAttestation:
    """Attestation emission: shapes, byte contracts, subject rules, rollback."""

    def _statement(self, bundle):
        env = bundle["attestation"]["dsseEnvelope"]
        return json.loads(base64.b64decode(env["payload"]))

    def test_emits_three_files_with_contracted_shapes(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys)
        bundle = run["bundle"]
        assert bundle["version"] == "1.1.0"
        att = bundle["attestation"]
        assert att["mediaType"] == (
            "application/vnd.dev.sigstore.bundle.v0.3+json")
        assert att["verificationMaterial"] == {"publicKey": {}}
        env = att["dsseEnvelope"]
        assert env["payloadType"] == "application/vnd.in-toto+json"
        assert len(env["signatures"]) == 1
        assert set(env["signatures"][0]) == {"sig"}
        # Emission invariant: sidecar bytes == canonical embedded copy, no
        # newline bytes of either kind, pure ASCII.
        raw = run["sidecar"].read_bytes()
        assert raw == fp.canonical_json(att).encode("utf-8")
        assert b"\x0a" not in raw and b"\x0d" not in raw
        raw.decode("ascii")
        pem_bytes = run["pem"].read_bytes()
        assert b"\r" not in pem_bytes
        body = run["pem"].read_text(encoding="utf-8").splitlines()[1]
        assert body.startswith("MCowBQYDK2VwAyEA")
        spki = base64.b64decode(body)
        assert spki[12:] == fp.ssh_ed25519_pubkey_bytes(bundle["public_key"])

    def test_finalize_result_lists_sidecar_paths(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="44")
        result = run["result"]
        # The existing six keys are untouched; the two new ones are additive.
        assert set(result) == {
            "rpack_path", "root_digest", "evaluation_status", "chain_length",
            "artifacts_count", "requirements_count",
            "attestation_path", "public_key_path"}
        assert result["attestation_path"].endswith("issue-44.sigstore.json")
        assert result["public_key_path"].endswith("issue-44.pub.pem")

    def test_dsse_signature_verifies_and_binds_to_bundle_key(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="45")
        bundle = run["bundle"]
        env = bundle["attestation"]["dsseEnvelope"]
        payload = base64.b64decode(env["payload"])
        pae = fp.dsse_pae(env["payloadType"], payload)
        pub = fp.ssh_ed25519_pubkey_bytes(bundle["public_key"])
        sig = base64.b64decode(env["signatures"][0]["sig"])
        assert fp.ed25519_verify(pub, pae, sig)

    def test_statement_subjects_equal_artifacts(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="46")
        bundle = run["bundle"]
        stmt = self._statement(bundle)
        assert stmt["_type"] == "https://in-toto.io/Statement/v1"
        assert stmt["predicateType"] == "https://slsa.dev/provenance/v1"
        subjects = {(s["name"], s["digest"]["sha256"])
                    for s in stmt["subject"]}
        artifacts = {(a["path"], a["sha256"]) for a in bundle["artifacts"]}
        assert subjects == artifacts
        assert len(stmt["subject"]) == len(bundle["artifacts"]) > 0
        for s in stmt["subject"]:
            assert "sha256" in s["digest"]

    def test_zero_artifact_run_emits_single_chain_subject(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="47",
                                 with_artifact=False)
        bundle = run["bundle"]
        stmt = self._statement(bundle)
        assert stmt["subject"] == [{
            "name": ".forgeproof/chain-47.json",
            "digest": {"sha256": bundle["chain_hash"]}}]

    def test_predicate_carries_approvals_builder_and_chain_metadata(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="48",
                                 model="claude-fable-5")
        bundle = run["bundle"]
        pred = self._statement(bundle)["predicate"]
        approvals = pred["buildDefinition"]["externalParameters"]["approvals"]
        assert approvals == [{
            "gate": "plan", "decision": "approved", "note": "LGTM",
            "approver": "ryan@example.com", "evidence": "agent-recorded"}]
        builder = pred["buildDefinition"]["internalParameters"]["builder"]
        assert builder["model"] == {"id": "claude-fable-5",
                                    "source": "self-reported"}
        assert builder["claude_code"] == {"version": "unknown",
                                          "source": "measured"}
        assert builder["plugin"] == {"version": fp.PLUGIN_VERSION,
                                     "source": "engine-constant"}
        chain_blocks = json.loads(run["chain"].read_text(encoding="utf-8"))
        meta = pred["runDetails"]["metadata"]
        assert meta["invocationId"] == chain_blocks[0]["hash"]
        assert meta["startedOn"] == chain_blocks[0]["timestamp"]
        assert meta["finishedOn"] == chain_blocks[-1]["timestamp"]
        chain_desc = [b for b in pred["runDetails"]["byproducts"]
                      if b["name"] == ".forgeproof/chain-48.json"]
        assert len(chain_desc) == 1
        # The byproduct digest is the SAME chain_hash the bundle seals —
        # LF-normalized decoded text, never a byte re-hash (finding 8).
        assert chain_desc[0]["digest"]["sha256"] == bundle["chain_hash"]
        # finalize block carries builder; approval block carries approver
        assert chain_blocks[-1]["data"]["builder"] == builder
        approval_blocks = [b for b in chain_blocks
                           if b["action"] == "approval"]
        assert len(approval_blocks) == 1
        assert approval_blocks[0]["data"]["approver"] == "ryan@example.com"

    def test_verify_green_and_attestation_covered_by_root_digest(
            self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="49")
        code, out = _run_verify(["--rpack", str(run["rpack"])], capsys)
        assert code == 0
        assert json.loads(out)["errors"] == []
        # Flip one value INSIDE the embedded attestation: root_digest must go
        # red — the attestation is NOT in the bundle_for_hash denylist.
        bundle = run["bundle"]
        bundle["attestation"]["mediaType"] = "application/x-evil"
        run["rpack"].write_text(json.dumps(bundle, indent=2) + "\n",
                                encoding="utf-8")
        code, out = _run_verify(["--rpack", str(run["rpack"])], capsys)
        output = json.loads(out)
        assert code == 1
        statuses = {c["name"]: c["status"] for c in output["checks"]}
        assert statuses["root_digest"] == "fail"
        assert any(e.startswith("Root digest mismatch") for e in output["errors"])

    def test_denylist_source_grep(self):
        # The one line that makes the whole design work (finding 1): the
        # root-digest denylist must stay exactly root_digest + signature.
        source = FORGEPROOF_PY.read_text(encoding="utf-8")
        assert 'if k not in ("root_digest", "signature")' in source

    def test_gate_accepts_v13_bundle(self, tmp_path, monkeypatch, capsys):
        run = _real_attested_run(tmp_path, monkeypatch, capsys, issue="50")
        assert run["rpack"].is_file()
        event = json.dumps({"tool_name": "Bash",
                            "tool_input": {"command": "gh pr create --fill"}})
        monkeypatch.setattr("sys.stdin", io.StringIO(event))
        with pytest.raises(SystemExit) as exc_info:
            fp.cmd_gate_pr(fp.argparse.Namespace())
        capsys.readouterr()
        assert exc_info.value.code in (0, None)

    # -- failure paths: fake-key fixture, patched signing ---------------------

    def _fake_setup(self, tmp_path, monkeypatch, issue="43"):
        monkeypatch.setattr(fp, "CHAIN_DIR", tmp_path / ".forgeproof")
        monkeypatch.chdir(tmp_path)
        priv = tmp_path / "key"
        pub = tmp_path / "key.pub"
        priv.write_text("fake_private")
        pub.write_text("ssh-ed25519 AAAA fake")
        artifact = tmp_path / "art.py"
        artifact.write_text("a = 1\n")
        with patch.object(fp, "generate_ephemeral_keypair",
                          return_value=(priv, pub)), \
                patch.object(fp, "sign_ed25519", return_value="sig"), \
                patch("sys.stdout"):
            fp.cmd_init(fp.build_parser().parse_args(
                ["init", "--issue", issue, "--title", "x", "--force"]))
            with patch.object(fp, "get_key_path", return_value=priv):
                fp.cmd_record(fp.build_parser().parse_args(
                    ["record", "--issue", issue, "--action", "file-edit",
                     "--path", "art.py", "--operation", "create"]))
        return issue, priv

    def test_unparseable_key_dies_before_chain_mutation(
            self, tmp_path, monkeypatch, capsys):
        issue, priv = self._fake_setup(tmp_path, monkeypatch)
        chain_file = fp.chain_path(issue)
        before = chain_file.read_bytes()
        args = fp.build_parser().parse_args(
            ["finalize", "--issue", issue, "--commit", "0" * 40])
        with patch.object(fp, "get_key_path", return_value=priv), \
                patch.object(fp, "sign_ed25519", return_value="sig"), \
                patch.object(fp.shutil, "which", return_value=None), \
                patch("sys.stdout"):
            with pytest.raises(SystemExit):
                fp.cmd_finalize(args)
        err = capsys.readouterr().err
        assert "Traceback" not in err
        assert chain_file.read_bytes() == before  # chain never mutated
        assert not (fp.CHAIN_DIR / f"issue-{issue}.rpack").exists()
        assert not (fp.CHAIN_DIR / f"issue-{issue}.sigstore.json").exists()
        assert not (fp.CHAIN_DIR / f"issue-{issue}.pub.pem").exists()
        assert priv.exists()  # retryable: key retained

    def test_attestation_failure_rolls_back_chain(
            self, tmp_path, monkeypatch, capsys):
        issue, priv = self._fake_setup(tmp_path, monkeypatch, issue="51")
        chain_file = fp.chain_path(issue)
        before = chain_file.read_bytes()
        args = fp.build_parser().parse_args(
            ["finalize", "--issue", issue, "--commit", "0" * 40])
        with patch.object(fp, "get_key_path", return_value=priv), \
                patch.object(fp, "sign_ed25519", return_value="sig"), \
                patch.object(fp.shutil, "which", return_value=None), \
                patch.object(fp, "load_attestation_signer",
                             return_value=fp.EphemeralEd25519Signer(bytes(32))), \
                patch.object(fp, "build_attestation",
                             side_effect=RuntimeError("injected failure")), \
                patch("sys.stdout"):
            with pytest.raises(SystemExit):
                fp.cmd_finalize(args)
        err = capsys.readouterr().err
        assert "Traceback" not in err
        assert "restored" in err
        assert chain_file.read_bytes() == before  # rolled back byte-for-byte
        assert not (fp.CHAIN_DIR / f"issue-{issue}.rpack").exists()
        assert not (fp.CHAIN_DIR / f"issue-{issue}.sigstore.json").exists()
        assert not (fp.CHAIN_DIR / f"issue-{issue}.pub.pem").exists()
        assert priv.exists()

    def test_sidecar_write_failure_rolls_back(
            self, tmp_path, monkeypatch, capsys):
        issue, priv = self._fake_setup(tmp_path, monkeypatch, issue="52")
        chain_file = fp.chain_path(issue)
        before = chain_file.read_bytes()
        args = fp.build_parser().parse_args(
            ["finalize", "--issue", issue, "--commit", "0" * 40])
        with patch.object(fp, "get_key_path", return_value=priv), \
                patch.object(fp, "sign_ed25519", return_value="sig"), \
                patch.object(fp.shutil, "which", return_value=None), \
                patch.object(fp, "load_attestation_signer",
                             return_value=fp.EphemeralEd25519Signer(bytes(32))), \
                patch.object(fp, "ed25519_spki_pem",
                             side_effect=OSError("disk full")), \
                patch("sys.stdout"):
            with pytest.raises(SystemExit):
                fp.cmd_finalize(args)
        assert chain_file.read_bytes() == before
        # No partial outputs left behind either.
        assert not (fp.CHAIN_DIR / f"issue-{issue}.rpack").exists()
        assert not (fp.CHAIN_DIR / f"issue-{issue}.sigstore.json").exists()
        assert not (fp.CHAIN_DIR / f"issue-{issue}.pub.pem").exists()
        assert priv.exists()

    def test_model_from_magicmock_namespace_is_empty_string(
            self, tmp_path, monkeypatch, capsys):
        # A MagicMock namespace returns a truthy Mock for .model; the
        # cmd_verify:v1.2 discipline (isinstance str) must coerce it to "".
        issue, priv = self._fake_setup(tmp_path, monkeypatch, issue="53")
        args = MagicMock()
        args.issue = issue
        args.commit = "0" * 40
        with patch.object(fp, "get_key_path", return_value=priv), \
                patch.object(fp, "sign_ed25519", return_value="sig"), \
                patch.object(fp.shutil, "which", return_value=None), \
                patch.object(fp, "load_attestation_signer",
                             return_value=fp.EphemeralEd25519Signer(bytes(32))), \
                patch("sys.stdout"):
            fp.cmd_finalize(args)
        chain_blocks = json.loads(fp.chain_path(issue).read_text(encoding="utf-8"))
        assert chain_blocks[-1]["data"]["builder"]["model"]["id"] == ""


class TestVersionAndFormat:
    """Format version 1.1.0: membership-only recognition, manifest sync."""

    def test_plugin_version_syncs_with_manifest(self):
        manifest = json.loads(
            (SCRIPT_DIR.parent.parent.parent / ".claude-plugin" /
             "plugin.json").read_text(encoding="utf-8"))
        assert fp.PLUGIN_VERSION == manifest["version"]

    def test_rpack_version_and_membership_set(self):
        assert fp.RPACK_VERSION == "1.1.0"
        # Append-only, membership-only — NEVER an ordering (finding 12).
        assert fp.KNOWN_RPACK_VERSIONS == frozenset({"1.0.0", "1.1.0"})

    def _reversioned(self, tmp_path, version, issue="1"):
        proj = tmp_path / "proj"
        rpack = _deploy_v12_project(proj, issue=issue)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        bundle["version"] = version
        _sign_bundle(bundle)
        rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
        return proj, rpack

    def test_known_old_version_verifies_without_warning(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._reversioned(tmp_path, "1.0.0")
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        assert code == 0
        assert output["warnings"] == []
        fmt = [c for c in output["checks"] if c["name"] == "format"][0]
        assert fmt["status"] == "ok"
        # The detail must print the BUNDLE's version, not the engine's.
        assert "1.0.0" in fmt["detail"]

    def test_unknown_version_warns_with_bundle_version(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._reversioned(tmp_path, "9.9.9")
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        assert code == 0  # unknown version alone is a warning, never an error
        assert len(output["warnings"]) == 1
        assert "9.9.9" in output["warnings"][0]
        fmt = [c for c in output["checks"] if c["name"] == "format"][0]
        assert fmt["status"] == "warn"


# ---------------------------------------------------------------------------
# v1.3.0 Phase 3 — verification of the attestation
# ---------------------------------------------------------------------------


def _attested_deploy(tmp_path, issue="1", approvals=None, builder=None):
    """An attested, validly-signed v1.1.0 bundle deployed like a real
    checkout. The DSSE tier signs with the SAME key as the SSHSIG tier — the
    shared test keypair's seed is parsed with the engine's own parser — so
    the key-binding check has a true-positive baseline."""
    proj = tmp_path / "proj"
    rpack = _deploy_v12_project(proj, issue=issue)
    bundle = json.loads(rpack.read_text(encoding="utf-8"))
    priv, _pub_text = _test_signing_key()
    signer = fp.EphemeralEd25519Signer(fp.openssh_ed25519_seed(priv))
    chain = json.loads((proj / ".forgeproof" / f"chain-{issue}.json")
                       .read_text(encoding="utf-8"))
    if builder is not None:
        # Inject a builder identity into the statement's view of the finalize
        # block (the chain FILE is untouched, so chain_hash stays green).
        chain = [dict(b) for b in chain]
        chain[-1] = dict(chain[-1], data=dict(chain[-1]["data"],
                                              builder=builder))
    core = {k: v for k, v in bundle.items()
            if k not in ("root_digest", "signature", "attestation")}
    statement = fp.build_intoto_statement(core, chain, approvals or [], "")
    bundle["attestation"] = fp.build_attestation(statement, signer)
    _sign_bundle(bundle)
    rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
    return proj, rpack


def _retamper_attested(rpack, mutate_statement=None, resign_dsse=True,
                       signer_seed=None, mutate_bundle=None):
    """Tamper helper: optionally mutate the decoded statement and/or the
    bundle, optionally re-sign the DSSE tier, then ALWAYS re-sign the SSHSIG
    tier so root_digest stays green — isolating the attestation checks from
    the root-digest check."""
    bundle = json.loads(rpack.read_text(encoding="utf-8"))
    if mutate_statement is not None:
        env = bundle["attestation"]["dsseEnvelope"]
        statement = json.loads(base64.b64decode(env["payload"]))
        mutate_statement(statement)
        if resign_dsse:
            if signer_seed is None:
                priv, _ = _test_signing_key()
                signer_seed = fp.openssh_ed25519_seed(priv)
            bundle["attestation"] = fp.build_attestation(
                statement, fp.EphemeralEd25519Signer(signer_seed))
        else:
            env["payload"] = base64.b64encode(
                fp.canonical_json(statement).encode("utf-8")).decode("ascii")
    elif signer_seed is not None:
        # Re-sign the UNCHANGED statement with a foreign key.
        env = bundle["attestation"]["dsseEnvelope"]
        statement = json.loads(base64.b64decode(env["payload"]))
        bundle["attestation"] = fp.build_attestation(
            statement, fp.EphemeralEd25519Signer(signer_seed))
    if mutate_bundle is not None:
        mutate_bundle(bundle)
    _sign_bundle(bundle)
    rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
    return bundle


class TestVerifyAttestation:
    """The three additive checks: silent when absent, tamper-class on any
    broken invariant, plain FAILED on signed-malformed input."""

    NEW_MARKERS = ("Attestation signature invalid", "Attestation key mismatch",
                   "Attestation subjects", "Attestation chain digest")

    def _marker_hits(self, err):
        return sum(marker in err for marker in fp.TAMPER_ERROR_MARKERS)

    def _attestation_errors(self, output):
        return [e for e in output["errors"] if e.startswith("Attestation")]

    def test_attested_bundle_green_all_checks_ok(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = _attested_deploy(tmp_path)
        monkeypatch.chdir(proj)
        for strict in (False, True):
            argv = ["--rpack", str(rpack)] + (["--strict"] if strict else [])
            code, out = _run_verify(argv, capsys)
            output = json.loads(out)
            assert code == 0
            assert output["errors"] == []
            assert output["warnings"] == []
            statuses = {c["name"]: c["status"] for c in output["checks"]}
            assert statuses["attestation"] == "ok"
            assert statuses["attestation_signature"] == "ok"
            assert statuses["attestation_subjects"] == "ok"
        att = output["attestation"]
        assert att["present"] is True
        assert att["predicate_type"] == "https://slsa.dev/provenance/v1"
        assert att["subject_count"] == 1
        assert isinstance(att["key_id"], str) and att["key_id"]

    def test_no_attestation_is_silent_in_every_mode(
            self, tmp_path, monkeypatch, capsys):
        proj = tmp_path / "proj"
        rpack = _deploy_v12_project(proj)
        monkeypatch.chdir(proj)
        for strict in (False, True):
            argv = ["--rpack", str(rpack)] + (["--strict"] if strict else [])
            code, out = _run_verify(argv, capsys)
            output = json.loads(out)
            assert code == 0
            assert output["errors"] == []
            assert output["warnings"] == []
            statuses = {c["name"]: c["status"] for c in output["checks"]}
            assert statuses["attestation"] == "skipped"
            assert statuses["attestation_signature"] == "skipped"
            assert statuses["attestation_subjects"] == "skipped"
        assert output["attestation"] == {
            "present": False, "predicate_type": None, "subject_count": None,
            "key_id": None, "builder": None, "approvals": []}

    # -- tamper matrix: each invariant broken individually ------------------

    def _assert_tamper(self, output, code, failing_check):
        assert code == 1
        errs = self._attestation_errors(output)
        assert len(errs) == 1
        assert self._marker_hits(errs[0]) == 1  # exactly one marker matches
        statuses = {c["name"]: c["status"] for c in output["checks"]}
        assert statuses[failing_check] == "fail"
        assert statuses["root_digest"] == "ok"  # isolation: tamper re-signed

    def test_payload_edit_without_resign_is_tamper(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = _attested_deploy(tmp_path)
        _retamper_attested(
            rpack, resign_dsse=False,
            mutate_statement=lambda s: s["predicate"].update(evil=True))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        self._assert_tamper(output, code, "attestation_signature")
        assert "Attestation signature invalid" in output["errors"][0]
        # And the markdown verdict calls it tampering.
        code_md, out_md = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code_md == 1
        assert "TAMPER DETECTED" in out_md

    def test_signature_byte_flip_is_tamper(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = _attested_deploy(tmp_path)

        def flip_sig(bundle):
            env = bundle["attestation"]["dsseEnvelope"]
            sig = bytearray(base64.b64decode(env["signatures"][0]["sig"]))
            sig[0] ^= 0x01
            env["signatures"][0]["sig"] = base64.b64encode(
                bytes(sig)).decode("ascii")

        _retamper_attested(rpack, mutate_bundle=flip_sig)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_tamper(json.loads(out), code, "attestation_signature")

    def test_foreign_dsse_key_is_tamper(self, tmp_path, monkeypatch, capsys):
        # A DSSE tier re-signed with a DIFFERENT key than the bundle's own
        # ssh-ed25519 key must fail: the key binding is the payoff of the
        # one-key design.
        proj, rpack = _attested_deploy(tmp_path)
        _retamper_attested(rpack, signer_seed=b"\x01" * 32)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        self._assert_tamper(output, code, "attestation_signature")
        assert "Attestation signature invalid" in output["errors"][0]

    def test_subject_digest_edit_is_tamper(self, tmp_path, monkeypatch, capsys):
        proj, rpack = _attested_deploy(tmp_path)

        def edit_subject(statement):
            statement["subject"][0]["digest"]["sha256"] = "0" * 64

        _retamper_attested(rpack, mutate_statement=edit_subject)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        self._assert_tamper(output, code, "attestation_subjects")
        assert "Attestation subjects" in output["errors"][0]
        code_md, out_md = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert "TAMPER DETECTED" in out_md

    def test_chain_byproduct_edit_is_tamper(self, tmp_path, monkeypatch, capsys):
        proj, rpack = _attested_deploy(tmp_path)

        def edit_byproduct(statement):
            for b in statement["predicate"]["runDetails"]["byproducts"]:
                if b["name"].startswith(".forgeproof/chain-"):
                    b["digest"]["sha256"] = "f" * 64

        _retamper_attested(rpack, mutate_statement=edit_byproduct)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        output = json.loads(out)
        self._assert_tamper(output, code, "attestation_subjects")
        assert "Attestation chain digest" in output["errors"][0]

    # -- malformed matrix: root digest intact => FAILED, never TAMPER --------

    def _assert_malformed(self, output, code):
        assert code == 1
        errs = self._attestation_errors(output)
        assert len(errs) == 1
        assert errs[0].startswith("Attestation malformed")
        assert self._marker_hits(errs[0]) == 0  # matches NO tamper marker
        statuses = {c["name"]: c["status"] for c in output["checks"]}
        assert statuses["attestation"] == "fail"
        assert statuses["attestation_signature"] == "skipped"
        assert statuses["attestation_subjects"] == "skipped"

    def _malform(self, tmp_path, mutate_bundle):
        proj, rpack = _attested_deploy(tmp_path)
        _retamper_attested(rpack, mutate_bundle=mutate_bundle)
        return proj, rpack

    def test_attestation_wrong_type_is_failed_not_tamper(
            self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._malform(
            tmp_path, lambda b: b.update(attestation="not an object"))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)
        code_md, out_md = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code_md == 1
        assert "VERIFICATION FAILED" in out_md
        assert "TAMPER" not in out_md

    def test_payload_not_base64_is_failed(self, tmp_path, monkeypatch, capsys):
        proj, rpack = self._malform(
            tmp_path,
            lambda b: b["attestation"]["dsseEnvelope"].update(payload="!!!"))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    def test_payload_not_json_is_failed(self, tmp_path, monkeypatch, capsys):
        garbage = base64.b64encode(b"not json").decode("ascii")
        proj, rpack = self._malform(
            tmp_path,
            lambda b: b["attestation"]["dsseEnvelope"].update(payload=garbage))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    def test_statement_missing_keys_is_failed(
            self, tmp_path, monkeypatch, capsys):
        payload = base64.b64encode(
            fp.canonical_json({"foo": 1}).encode("utf-8")).decode("ascii")
        proj, rpack = self._malform(
            tmp_path,
            lambda b: b["attestation"]["dsseEnvelope"].update(payload=payload))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    def test_subject_wrong_type_is_failed(self, tmp_path, monkeypatch, capsys):
        proj, rpack = _attested_deploy(tmp_path)
        _retamper_attested(
            rpack, resign_dsse=False,
            mutate_statement=lambda s: s.update(subject="nope"))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    def test_two_signatures_is_failed(self, tmp_path, monkeypatch, capsys):
        def dup_sig(bundle):
            sigs = bundle["attestation"]["dsseEnvelope"]["signatures"]
            sigs.append(dict(sigs[0]))
        proj, rpack = self._malform(tmp_path, dup_sig)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    def test_deeply_nested_payload_fails_cleanly(
            self, tmp_path, monkeypatch, capsys):
        # Real nesting with a shape fallback (per house rule): on builds where
        # json survives 2000 levels the result is a list, not an object — the
        # same clean malformed error either way. The forced-condition variant
        # is the next test.
        deep = base64.b64encode(
            ("[" * 2000 + "]" * 2000).encode("ascii")).decode("ascii")
        proj, rpack = self._malform(
            tmp_path,
            lambda b: b["attestation"]["dsseEnvelope"].update(payload=deep))
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    def test_forced_recursionerror_in_payload_parse_fails_cleanly(
            self, tmp_path, monkeypatch, capsys):
        # Force the condition (never assert platform-dependent natural
        # nesting): RecursionError raised ONLY for the attestation payload
        # parse — the bundle read itself must keep working.
        proj, rpack = _attested_deploy(tmp_path)
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        payload_text = base64.b64decode(
            bundle["attestation"]["dsseEnvelope"]["payload"]).decode("utf-8")
        real_loads = fp.json.loads

        def loads_forced(s, *a, **k):
            if isinstance(s, str) and s == payload_text:
                raise RecursionError("forced")
            return real_loads(s, *a, **k)

        monkeypatch.setattr(fp.json, "loads", loads_forced)
        monkeypatch.chdir(proj)
        code, out = _run_verify(["--rpack", str(rpack)], capsys)
        self._assert_malformed(json.loads(out), code)

    # -- report + marker hygiene --------------------------------------------

    def test_markdown_attestation_section(self, tmp_path, monkeypatch, capsys):
        approvals = [{"gate": "plan", "decision": "approved",
                      "note": "[evil](x)", "approver": "ryan@example.com"}]
        builder = {"model": {"id": "claude-fable-5", "source": "self-reported"},
                   "plugin": {"version": fp.PLUGIN_VERSION,
                              "source": "engine-constant"}}
        proj, rpack = _attested_deploy(tmp_path, approvals=approvals,
                                       builder=builder)
        monkeypatch.chdir(proj)
        code, out = _run_verify(
            ["--rpack", str(rpack), "--format", "markdown"], capsys)
        assert code == 0
        assert "### Attestation" in out
        assert "cosign verify-blob-attestation" in out
        assert "claude-fable-5" in out
        assert "self-reported" in out
        assert "agent-recorded" in out
        # Attacker-controlled note is escaped by md_cell.
        assert "\\[evil\\]" in out
        assert "[evil](x)" not in out
        # The checks table picked up the three new rows automatically.
        assert "| attestation |" in out
        assert "| attestation_signature |" in out
        assert "| attestation_subjects |" in out

    def test_new_tamper_markers_registered_and_clean(self):
        for marker in self.NEW_MARKERS:
            assert marker in fp.TAMPER_ERROR_MARKERS
            # New markers must not collide with the legacy substring traps.
            assert "hash mismatch" not in marker
            assert "prev_hash" not in marker


# ---------------------------------------------------------------------------
# v1.4.0 — format identity: the normative spec, the emission profile, and the
# registration wording discipline
# ---------------------------------------------------------------------------


class TestFormatIdentity:
    """rpack-format.md is the normative specification; these tests keep its
    load-bearing sentences true of the engine and of every frozen fixture."""

    SPEC_PATH = "skills/run/references/rpack-format.md"
    SCHEMA_PATH = "schemas/forgeproof-rpack-1.schema.json"
    MIME_XML = "share/mime/packages/forgeproof-rpack.xml"
    MAGIC_FILE = "share/magic/forgeproof"
    MEDIA_TYPE = "application/vnd.forgeproof.rpack+json"
    MEDIA_TYPE_DOC = PLUGIN_ROOT / "docs" / "media-type.md"
    FIXTURE_BUNDLES = (
        FIXTURE_V101 / "issue-999.rpack",
        FIXTURE_V110 / "issue-998.rpack",
        FIXTURE_V122 / "issue-997.rpack",
        FIXTURE_V130 / "issue-996.rpack",
    )

    def test_spec_anchor_frozen(self):
        """The spec's path and the buildType heading are sealed into every
        attestation (predicate.buildDefinition.buildType) — neither may move,
        and no second heading may take over the anchor slug."""
        assert fp.FORGEPROOF_BUILD_TYPE.endswith(
            f"/{self.SPEC_PATH}#slsa-buildtype-v1")
        lines = (PLUGIN_ROOT / self.SPEC_PATH).read_text(
            encoding="utf-8").splitlines()
        headings = [line for line in lines if line.startswith("#")
                    and line.lstrip("#").strip().lower() == "slsa buildtype v1"]
        assert headings == ["### SLSA buildType v1"]

    def test_canonical_form_matches_spec(self):
        """The spec defines the canonical serialization by one exact
        expression; the engine must agree with it: members sorted by code
        point (not UTF-16 code unit), compact, everything outside printable
        ASCII escaped."""
        spec_text = (PLUGIN_ROOT / self.SPEC_PATH).read_text(encoding="utf-8")
        assert ('`json.dumps(obj, sort_keys=True, separators=(",", ":"))`'
                in spec_text)
        nested = {"b": [2, {"z": 1, "a": "\xe9\U00002713"}],
                  "\U0001f600": None, "\U0000fffd": True,
                  "a": {"d": -1, "c": "\x7f/"}}
        expected = ('{"a":{"c":"\\u007f/","d":-1},'
                    '"b":[2,{"a":"\\u00e9\\u2713","z":1}],'
                    '"\\ufffd":true,"\\ud83d\\ude00":null}')
        assert json.dumps(nested, sort_keys=True,
                          separators=(",", ":")) == expected
        assert fp.canonical_json(nested) == expected

    def test_no_floats_in_fixtures(self):
        """The spec says every number is an integer (float formatting is
        implementation-defined, so it has no place in a canonical form)."""
        for rpack in self.FIXTURE_BUNDLES:
            floats: list[str] = []
            json.loads(rpack.read_text(encoding="utf-8"),
                       parse_float=floats.append)
            assert floats == [], f"{rpack.name} carries non-integer numbers"

    def test_schema_is_structurally_sane(self):
        """The published JSON Schema, checked with the stdlib alone (the
        pinned validator runs in one CI job only, stress/validate_schema.py):
        an immutable identity, the engine's own constants, and the spec's
        tolerances — unknown members at every level, an optional attestation,
        and mediaType / verificationMaterial described but never required or
        constrained ("What binds a verifier")."""
        schema = json.loads((PLUGIN_ROOT / self.SCHEMA_PATH).read_text(
            encoding="utf-8"))
        assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema"
        schema_id = urlsplit(schema["$id"])
        assert schema_id.scheme == "https" and schema_id.netloc
        assert "#" not in schema["$id"]
        assert schema_id.path.endswith("/" + self.SCHEMA_PATH)
        # The path segment before the schema's own repo path is the TAG the
        # $id is pinned to (immutable), never a branch such as "main".
        tag = schema_id.path[:-len("/" + self.SCHEMA_PATH)].rsplit("/", 1)[1]
        assert re.fullmatch(r"v\d+\.\d+\.\d+", tag), tag

        props = schema["properties"]
        assert props["format"]["const"] == fp.RPACK_FORMAT
        pattern = props["version"]["pattern"]
        for version in sorted(fp.KNOWN_RPACK_VERSIONS):
            assert re.search(pattern, version), version
        assert not re.search(pattern, "2.0.0")
        assert "attestation" not in schema["required"]

        tolerated = {"mediaType", "verificationMaterial"}

        def walk(node):
            if isinstance(node, (dict, list)):
                yield node
                for child in (node.values() if isinstance(node, dict) else node):
                    yield from walk(child)

        for node in walk(schema):
            if isinstance(node, dict):
                assert node.get("additionalProperties") is not False
                assert node.get("unevaluatedProperties") is not False
            else:  # required, dependentRequired, enum: no list may name them
                assert not tolerated & {v for v in node if isinstance(v, str)}

        attestation = props["attestation"]
        if "$ref" in attestation:
            assert attestation["$ref"].startswith("#/")
            target = schema
            for part in attestation["$ref"][2:].split("/"):
                target = target[part]
            attestation = target
        assert attestation["required"] == ["dsseEnvelope"]
        for name in sorted(tolerated):
            assert set(attestation["properties"][name]) <= {
                "$comment", "description", "title"}, name

    def test_format_marker_in_prefix(self, tmp_path, monkeypatch, capsys):
        """Emission profile item 1, which the detection rules key on: `{` at
        byte 0 and the format marker within the first 256 bytes — for every
        frozen fixture and for whatever the writer emits on this platform."""
        markers = (b'"format": "forgeproof-rpack"', b'"format":"forgeproof-rpack"')

        def conforms(data: bytes) -> bool:
            return data[:1] == b"{" and any(m in data[:256] for m in markers)

        for rpack in self.FIXTURE_BUNDLES:
            assert conforms(rpack.read_bytes()), rpack.name
        fresh = _real_attested_run(tmp_path, monkeypatch, capsys)
        assert conforms(fresh["rpack"].read_bytes())

    def test_detection_files_single_sourced(self):
        """The opt-in detection files under share/ name the same type as the
        spec, the schema, and docs/media-type.md — one spelling, everywhere —
        and key on the extension the engine writes. Static checks only: the
        tools that consume these files run in one CI job
        (stress/check_detection.py), never in this suite."""
        for rel in (self.MIME_XML, self.MAGIC_FILE, self.SPEC_PATH,
                    self.SCHEMA_PATH, "docs/media-type.md"):
            text = (PLUGIN_ROOT / rel).read_text(encoding="utf-8")
            spellings = set(re.findall(
                r"application/vnd\.forgeproof(?:[.+-]?\w+)*", text))
            assert spellings == {self.MEDIA_TYPE}, rel

        ns = {"m": "http://www.freedesktop.org/standards/shared-mime-info"}
        mime_types = ET.parse(PLUGIN_ROOT / self.MIME_XML).getroot().findall(
            "m:mime-type", ns)
        assert [t.get("type") for t in mime_types] == [self.MEDIA_TYPE]
        assert [g.get("pattern") for g in mime_types[0].findall(
            "m:glob", ns)] == ["*.rpack"]

        magic = (PLUGIN_ROOT / self.MAGIC_FILE).read_text(encoding="utf-8")
        mimes = re.findall(r"^!:mime\s+(\S+)\s*$", magic, re.M)
        exts = re.findall(r"^!:ext\s+(\S+)\s*$", magic, re.M)
        assert mimes and set(mimes) == {self.MEDIA_TYPE}
        assert len(exts) == len(mimes) and set(exts) == {"rpack"}

    def test_engine_never_mentions_consumer_tools(self):
        """The schema validator and the MIME/magic tools are consumer-side:
        they run in one CI job only. The engine — preflight above all — never
        names them, so none can become a runtime dependency."""
        engine = FORGEPROOF_PY.read_text(encoding="utf-8")
        preflight = inspect.getsource(fp.cmd_preflight)
        for tool in ("jsonschema", "xdg-mime", "update-mime-database", "gio",
                     "file -m"):
            pattern = rf"(?<![\w-]){re.escape(tool)}(?![\w-])"
            assert not re.search(pattern, engine), tool
            assert not re.search(pattern, preflight), tool
        # file(1) in list-form subprocess spelling: ["file", "-m", ...].
        assert not re.search(r"""["']file["']""", engine)
        assert not re.search(r"""["']file["']""", preflight)

    def test_skills_never_write_repo_config(self):
        """Zero footprint: repository, desktop, and editor configuration is
        documented for users (README, docs/media-type.md) and never performed
        — no skill names the files or the tools that would do it."""
        skills = sorted(SKILLS_DIR.glob("*/SKILL.md"))
        assert {"push", "reset", "run", "verify"} <= {
            s.parent.name for s in skills}
        for skill_md in skills:
            text = skill_md.read_text(encoding="utf-8")
            for token in (".gitattributes", "update-mime-database",
                          "xdg-mime", "files.associations",
                          "linguist-language", "settings.json"):
                assert token not in text, f"{skill_md.parent.name}: {token}"

    def test_forbidden_phrases(self):
        """Registration confers no trust, and nothing may claim it happened
        before it has: the status lives on ONE ledger line in
        docs/media-type.md, and that line is the only place the words
        "registered with IANA" may ever appear. The PLAN_v* records and this
        file are skipped — they quote the list in order to define it."""
        forbidden = ("iana-approved", "approved by iana", "iana approved",
                     "iana-registered", "official media type",
                     "standardized media type")
        claim = "registered with iana"
        ledger = [line for line in self.MEDIA_TYPE_DOC.read_text(
            encoding="utf-8").splitlines() if "Registration status:" in line]
        assert len(ledger) == 1, "docs/media-type.md must carry ONE ledger line"
        assert ledger[0].startswith(
            "Media type: `application/vnd.forgeproof.rpack+json` "
            "(vendor tree). Registration status: ")
        offenders = []
        for root, dirs, files in os.walk(PLUGIN_ROOT):
            dirs[:] = [d for d in dirs if d in (".github", ".claude-plugin")
                       or not (d.startswith(".") or d == "__pycache__")]
            for name in files:
                path = Path(root) / name
                if path == Path(__file__).resolve() or (
                        Path(root) == PLUGIN_ROOT and name.startswith("PLAN_v")):
                    continue
                try:
                    text = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    continue  # not a text file
                flat = " ".join(text.lower().split())
                hits = [p for p in forbidden if p in flat]
                allowed = (ledger[0].lower().count(claim)
                           if path == self.MEDIA_TYPE_DOC else 0)
                if flat.count(claim) > allowed:
                    hits.append(claim)
                if hits:
                    offenders.append(f"{path.relative_to(PLUGIN_ROOT)}: {hits}")
        assert offenders == []

    def test_attestation_wrapper_tolerance_matches_spec(
            self, tmp_path, monkeypatch, capsys):
        """The spec's "What binds a verifier": a verifier MUST NOT reject a
        document over extra members of the signature object, the value or
        absence of mediaType, or the absence, type, or contents of
        verificationMaterial — that member is opaque to the format (a later
        producer may populate it)."""
        def add_keyid(b):
            b["attestation"]["dsseEnvelope"]["signatures"][0]["keyid"] = "abc"

        def certificate_material(b):
            b["attestation"]["verificationMaterial"] = {
                "certificate": {"rawBytes": "AAAA"},
                "tlogEntries": [{"logIndex": "1"}]}

        def drop_material(b):
            del b["attestation"]["verificationMaterial"]

        def empty_material(b):
            b["attestation"]["verificationMaterial"] = {}

        def string_material(b):
            b["attestation"]["verificationMaterial"] = "junk"

        def other_media_type(b):
            b["attestation"]["mediaType"] = "application/x-anything"

        def drop_media_type(b):
            del b["attestation"]["mediaType"]

        for i, mutate in enumerate((add_keyid, certificate_material,
                                    drop_material, empty_material,
                                    string_material, other_media_type,
                                    drop_media_type)):
            proj, rpack = _attested_deploy(tmp_path / str(i))
            _retamper_attested(rpack, mutate_bundle=mutate)
            monkeypatch.chdir(proj)
            for mode in ([], ["--strict"]):
                code, out = _run_verify(["--rpack", str(rpack), *mode], capsys)
                output = json.loads(out)
                assert (code, output["errors"]) == (0, []), mutate.__name__
                statuses = {c["name"]: c["status"] for c in output["checks"]}
                assert statuses["attestation_signature"] == "ok", mutate.__name__

    def test_verify_resolves_recorded_paths_as_given(
            self, tmp_path, monkeypatch, capsys):
        """Pins a DOCUMENTED LIMITATION of the reference verifier, not a
        feature: verify confines neither the recorded artifact paths nor the
        chain-file name it builds from issue.number to the project root, in
        any mode (docs/media-type.md, security considerations — which is why
        that text says SHOULD and says what the verifier does). When verify
        is hardened, change this test and that text together."""
        outside = tmp_path / "outside" / "secret.txt"
        outside.parent.mkdir()
        outside.write_text("outside the project root\n", encoding="utf-8")
        for i, recorded in enumerate((outside.as_posix(),
                                      "../../outside/secret.txt")):
            proj = tmp_path / str(i) / "proj"
            rpack = _deploy_v12_project(proj)
            bundle = json.loads(rpack.read_text(encoding="utf-8"))
            bundle["artifacts"] = [{"path": recorded, "operation": "modify",
                                    "sha256": fp.sha256_file(outside)}]
            _sign_bundle(bundle)
            rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
            monkeypatch.chdir(proj)
            for mode in ([], ["--strict"]):
                code, out = _run_verify(["--rpack", str(rpack), *mode], capsys)
                output = json.loads(out)
                assert (code, output["errors"]) == (0, []), recorded
                assert output["artifacts_checked"] == 1, recorded
                assert output["artifacts_missing"] == 0, recorded

        # The chain-file leg: the only chain file lives OUTSIDE the project,
        # and a string issue.number steers the read to it. (POSIX resolves
        # "chain-1/.." only if that directory exists; Windows needs nothing.)
        proj = tmp_path / "chain" / "proj"
        rpack = _deploy_v12_project(proj)
        (proj / ".forgeproof" / "chain-1").mkdir()
        shutil.move(str(proj / ".forgeproof" / "chain-1.json"),
                    str(tmp_path / "outside" / "stolen.json"))
        bundle = json.loads(rpack.read_text(encoding="utf-8"))
        bundle["issue"]["number"] = "1/../../../../outside/stolen"
        _sign_bundle(bundle)
        rpack.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
        monkeypatch.chdir(proj)
        for mode in ([], ["--strict"]):
            code, out = _run_verify(["--rpack", str(rpack), *mode], capsys)
            output = json.loads(out)
            assert (code, output["errors"], output["warnings"]) == (0, [], [])
            statuses = {c["name"]: c["status"] for c in output["checks"]}
            assert statuses["chain_hash"] == "ok"
