<h1 align="center">coodle-moodle45agentskills</h1>

<p align="center">
  <em>Your coding agent, fluent in Moodle 4.5.</em>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/moodle-4.5%20LTS-orange?style=flat-square" alt="Moodle 4.5 LTS">
  <img src="https://img.shields.io/badge/skills-4-blue?style=flat-square" alt="4 skills">
  <img src="https://img.shields.io/badge/references-33-blue?style=flat-square" alt="33 reference files">
  <img src="https://img.shields.io/badge/license-GPL--3.0-green?style=flat-square" alt="GPL-3.0 license">
</p>

<p align="center"><a href="README.md">English</a> · <a href="README.es.md">Español</a></p>

---

Ask a stock coding agent for a Moodle plugin and you get a generic PHP package: hardcoded strings, raw SQL against prefixed table names, no capability checks, no `db/upgrade.php`, a style that fails phpcs on the first line. Moodle has its own way of doing almost everything — and it is all documented, just spread across hundreds of pages the agent never reads.

This plugin fixes that. It is a suite of **agent skills** distilled offline from the official Moodle 4.5 developer documentation — [moodledev.io/docs/4.5](https://moodledev.io/docs/4.5) and the [coding style policy](https://moodledev.io/general/development/policies/codingstyle) — packaged so Claude Code, Codex, and any AGENTS.md-aware agent can use them. Your agent loads a compact router per topic and only the reference files the task actually needs: no network fetches, no Docusaurus boilerplate, no guessing from stale training data.

## Table of Contents

- [How it works](#how-it-works)
- [What's inside](#whats-inside)
- [Installation](#installation)
  - [Claude Code](#claude-code)
  - [Codex](#codex)
  - [Other agents (AGENTS.md)](#other-agents-agentsmd)
- [Example session](#example-session)
- [Design principles](#design-principles)
- [Accuracy and verification](#accuracy-and-verification)
- [Known gaps](#known-gaps)
- [Updating the content](#updating-the-content)
- [Contributing](#contributing)
- [License](#license)

## How it works

Each skill is a folder with a `SKILL.md` router and a `references/` directory. The router's frontmatter description tells the agent *when* to load it; the router body tells it *which* reference file covers the task at hand. A question about `$DB->get_records()` pulls in one ~330-line database reference — not the whole suite.

```
You: "Add a scheduled task to my local plugin that emails inactive users."

Agent loads: moodle-plugin-development  → references/common-files.md   (db/tasks.php)
             moodle-core-apis           → references/events-tasks.md   (task class)
                                        → references/other-apis.md     (messaging)
             moodle-coding-style        → SKILL.md                     (while writing)
```

The skills trigger automatically — you never invoke them by hand. You just have an agent that knows that strings go through `get_string()`, schema changes need both `install.xml` and an upgrade step, and every external function validates its context.

## What's inside

### `moodle-plugin-development`

Plugin anatomy and per-type requirements. Start here for any new plugin.

| Reference | Covers |
|---|---|
| `common-files.md` | Frankenstyle naming, version.php, lang/, every in-scope db/ file (access, install.xml, upgrade, tasks, events, services, caches, hooks, renamed/legacy classes), classes/ autoloading, settings.php, lib.php |
| `activity-modules.md` | mod plugins: lib.php callbacks, mod_form, FEATURE_* flags, class-based completion rules, course page display |
| `blocks.md` / `local-plugins.md` | block_base API, instance config; local plugin structure and when to use one |
| `themes.md` | config.php, Boost inheritance, SCSS, layouts, template/renderer overrides |
| `filters.md` / `course-formats.md` | 4.5 `\core_filters\text_filter` convention; `core_courseformat\base` and output classes |
| `repositories.md` / `enrolment.md` | repository class contract; enrol_plugin workflow and subsystem API |
| `question-types.md` | qtype and qbank plugins, question engine basics |
| `other-plugin-types.md` | The complete 4.5 plugin-type catalogue plus AI providers/placements, tiny, antivirus, availability, customfield, sms, and more |
| `subplugins.md` | db/subplugins.json, database field types, book tools, TinyMCE Behat testing, course-format migration |
| `workflow-guides.md` | Git workflow, plugin upgrade API, profiling, Bootstrap 5 migration, 4.5 requirements and dev-update highlights |

### `moodle-core-apis`

One reference per core API — the router maps task → file.

| Reference | Covers |
|---|---|
| `database.md` | $DB/DML methods, placeholders, transactions, sql_* helpers, XMLDB/DDL |
| `forms.md` | moodleform lifecycle, element catalog, validation, file elements |
| `output-templates.md` | $PAGE/$OUTPUT, renderers, renderables, Mustache syntax and helpers |
| `events-tasks.md` | Event classes and observers; scheduled and adhoc tasks |
| `caching.md` / `files.md` | MUC definitions and usage; File API, pluginfile serving, draft areas |
| `access-roles.md` | Contexts, capabilities, has_capability/require_login |
| `webservices.md` | `\core_external\external_api` functions, db/services.php, core/ajax |
| `privacy.md` | GDPR provider classes, metadata, export/delete |
| `hooks-di.md` | 4.5 Hooks API, dependency injection, \core\clock, deprecation |
| `javascript.md` | AMD/ESM modules, grunt, core/str, core/modal, promise rules |
| `javascript-advanced.md` | Core reactive library, comboboxsearch, legacy YUI recognition |
| `webservices-advanced.md` | 4.5 Routing subsystem (`/api/rest/v2`), testing external functions, WS file upload/download |
| `backup-restore.md` | Backup/restore tasks and stepslib for activities, blocks, and admin tools |
| `more-subsystems.md` | Editor, plagiarism, xAPI, favourites, time/clock, communication, AI and SMS subsystems, question engine overview |
| `files-advanced.md` | File browsing, document converters, storage internals, DML drivers, privacy CLI utils |
| `other-apis.md` | Strings, messaging, navigation, report builder, custom fields, admin settings, calendar, tags, groups, and more |

### `moodle-coding-style`

The official coding style in one file: GPL boilerplate, MOODLE_INTERNAL rules, naming, whitespace, PHPDoc tags, namespaces, exceptions, and SQL style. Loads whenever the agent writes Moodle code.

### `moodle-testing`

| Reference | Covers |
|---|---|
| `phpunit.md` | init/run commands, advanced_testcase, data generators, sinks, coverage |
| `behat.md` | .feature structure, tags, custom steps, entity generators |
| `ci-tools.md` | phpcs + moodle-cs, GitHub Actions CI, grunt, plugin submission checklist |

## Installation

The repository uses one shared `skills/` directory and thin manifests for its supported agent integrations. Install once per harness you use.

### Claude Code

Register this repository as a marketplace and install:

```bash
/plugin marketplace add catalanml/coodle-moodle45agentskills
/plugin install coodle-moodle45agentskills@coodle
```

Or without publishing, copy the skills into your user or project skills directory:

```bash
cp -r skills/* ~/.claude/skills/
```

### Codex

`.codex-plugin/plugin.json` declares the shared `skills/` directory. Install the repository as a plugin from the Codex plugin interface (`/plugins`), or point Codex at a local clone. `AGENTS.md` gives Codex the routing instructions even without plugin support: clone the repo and reference it from your project's `AGENTS.md`.

### Other agents (AGENTS.md)

Any agent that reads `AGENTS.md` (OpenCode, Cursor, Copilot CLI, …) can use the suite: clone this repo somewhere stable and add a line to your project's agent instructions:

```markdown
Before writing Moodle code, read /path/to/coodle-moodle45agentskills/AGENTS.md
and follow the skill routing it describes.
```

Skills are plain markdown — there are no hooks, no scripts, no runtime dependencies.

## Example session

> **You:** Create a block plugin that shows the five most recently graded assignments for the current user.
>
> **Agent:** *loads `moodle-plugin-development` (common-files + blocks), `moodle-core-apis` (database, access-roles), `moodle-coding-style` — then scaffolds `blocks/recentgrades/` with a correct version.php, `db/access.php` with `block/recentgrades:addinstance` + `myaddinstance`, a `block_recentgrades` class using `$DB->get_records_sql()` with `{grade_grades}` placeholders and a proper capability check, lang strings for every visible label, and GPL boilerplate that passes phpcs.*

## Design principles

- **Distilled, not vendored.** The raw 4.5 docs are hundreds of pages of Docusaurus. Each reference file is a compact, self-contained rewrite (100–450 lines) with the load-bearing facts: class names, signatures, file paths, real code examples.
- **Router + references.** Agents have finite context. `SKILL.md` files stay small and point to exactly one file per topic, so a forms question never pays for the caching docs.
- **Docs-only facts.** Content comes from the official documentation, not model memory. Where the 4.5 docs are silent, the files say so and point to the legacy wiki rather than inventing an API.
- **4.5-accurate over doc-faithful.** Where the official docs are stale (they still show a completion callback removed in 4.3), the skills teach the current API and note the discrepancy.

## Accuracy and verification

The source audit uses the current `moodle/devdocs` 4.5 tree: 188 Markdown/MDX
files in total, consisting of 148 content/example pages plus 40 reusable
snippets. The 148 pages are routed into the 33 references; the snippets are
folded into the references for their parent topic. Orientation-only index pages
are represented by the routers and README. Load-bearing claims (class names,
method signatures, paths, constants, and commands) were checked against the
source clone, and stale upstream examples that would produce invalid 4.5 code
are called out inline.

## Known gaps

Things the official 4.5 documentation simply does not cover — the files flag these inline with pointers to the legacy wiki (`docs.moodle.org/dev`):

- Gradebook API (`grade_update()`, grade items) — only Advanced Grading is documented in 4.5.
- Full String API and Events API pages — sourced from the legacy wiki, flagged as such.
- SCSS theme presets and qtype form internals — docs link out instead of documenting.
- The activity restore doc literally ends "(to be continued)" upstream; `backup-restore.md` flags what's missing.
- The Moodle App (mobile) docs are intentionally out of scope.

Every non-App page in the 4.5 versioned tree is distilled into a reference file.

## Updating the content

The content was distilled from [moodle/devdocs](https://github.com/moodle/devdocs)
(`versioned_docs/version-4.5/` plus the coding-style policy pages) at source
commit `6347680795082ad2824e3cf5fc73caa96be318c5` on **2026-08-15**. Moodle
4.5 is an LTS release, so drift is slow, but to refresh: re-clone devdocs,
re-run the distillation against the same source paths, and re-verify. The
Moodle App pages and `db/mobile.php` are intentionally excluded. For a future
5.x edition, fork the suite and re-distill from `versioned_docs/version-5.x`.

## Contributing

1. Fork the repository and branch from `main`.
2. Keep the rules: plain GitHub markdown, no Docusaurus syntax, facts sourced from the official docs (cite the source page in your PR), routers stay short.
3. One topic per reference file; put breadth in the `other-*` files.
4. Submit a PR describing which doc pages back your change.

## License

GPL-3.0-or-later. Content derived from the Moodle developer documentation, which is part of the Moodle project (GPL).
