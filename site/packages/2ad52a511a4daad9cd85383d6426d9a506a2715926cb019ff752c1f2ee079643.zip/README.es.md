<h1 align="center">coodle-moodle45agentskills</h1>

<p align="center">
  <em>Tu agente de programación, experto en Moodle 4.5.</em>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/moodle-4.5%20LTS-orange?style=flat-square" alt="Moodle 4.5 LTS">
  <img src="https://img.shields.io/badge/skills-4-blue?style=flat-square" alt="4 skills">
  <img src="https://img.shields.io/badge/references-33-blue?style=flat-square" alt="33 archivos de referencia">
  <img src="https://img.shields.io/badge/license-GPL--3.0-green?style=flat-square" alt="Licencia GPL-3.0">
</p>

<p align="center"><a href="README.md">English</a> · <a href="README.es.md">Español</a></p>

---

Si le pides a un agente de programación genérico que cree un plugin de Moodle, obtendrás un paquete PHP genérico: cadenas de texto codificadas, SQL directo contra nombres de tablas con prefijo, ausencia de comprobaciones de capacidades, ningún `db/upgrade.php` y un estilo que falla phpcs desde la primera línea. Moodle tiene su propia forma de hacer casi todo — y está documentada, pero repartida en cientos de páginas que el agente nunca lee.

Este repositorio resuelve ese problema. Es un conjunto de **skills para agentes** destiladas sin conexión a partir de la documentación oficial de desarrollo de Moodle 4.5 — [moodledev.io/docs/4.5](https://moodledev.io/docs/4.5) y la [política de estilo de código](https://moodledev.io/general/development/policies/codingstyle) — empaquetado para que pueda usarlo un agente compatible con Claude Code, Codex o `AGENTS.md`. El agente carga un router compacto por tema y solo los archivos de referencia que necesita la tarea: sin descargar contenido de la red, sin boilerplate de Docusaurus y sin adivinar a partir de datos de entrenamiento desactualizados.

## Tabla de contenidos

- [Cómo funciona](#cómo-funciona)
- [Qué incluye](#qué-incluye)
- [Instalación](#instalación)
  - [Claude Code](#claude-code)
  - [Codex](#codex)
  - [Otros agentes (`AGENTS.md`)](#otros-agentes-agentsmd)
- [Sesión de ejemplo](#sesión-de-ejemplo)
- [Principios de diseño](#principios-de-diseño)
- [Precisión y verificación](#precisión-y-verificación)
- [Limitaciones conocidas](#limitaciones-conocidas)
- [Actualizar el contenido](#actualizar-el-contenido)
- [Contribuir](#contribuir)
- [Licencia](#licencia)

## Cómo funciona

Cada skill es una carpeta con un router `SKILL.md` y un directorio `references/`. La descripción del frontmatter del router indica al agente *cuándo* cargarla; el cuerpo del router le indica *qué* archivo de referencia cubre la tarea. Una pregunta sobre `$DB->get_records()` carga una referencia de base de datos de unas 330 líneas — no todo el conjunto.

```
Tú: «Añade una tarea programada a mi plugin local que envíe un correo a los usuarios inactivos».

El agente carga: moodle-plugin-development → references/common-files.md   (db/tasks.php)
                 moodle-core-apis           → references/events-tasks.md   (clase de tarea)
                                             → references/other-apis.md     (mensajería)
                 moodle-coding-style        → SKILL.md                     (mientras escribe)
```

Las skills se activan automáticamente: nunca tienes que invocarlas manualmente. Solo necesitas un agente que sepa que las cadenas pasan por `get_string()`, que los cambios de esquema requieren tanto `install.xml` como un paso de actualización y que toda función externa debe validar su contexto.

## Qué incluye

### `moodle-plugin-development`

Anatomía de plugins y requisitos de cada tipo. Empieza aquí para cualquier plugin nuevo.

| Referencia | Cubre |
|---|---|
| `common-files.md` | Nombres Frankenstyle, version.php, lang/, todos los archivos db/ incluidos en el alcance (access, install.xml, upgrade, tasks, events, services, caches, hooks, clases renombradas/legacy), autocarga de classes/, settings.php, lib.php |
| `activity-modules.md` | Plugins mod: callbacks de lib.php, mod_form, indicadores FEATURE_*, reglas de finalización basadas en clases y visualización en la página del curso |
| `blocks.md` / `local-plugins.md` | API block_base y configuración de instancias; estructura de plugins locales y cuándo usar uno |
| `themes.md` | config.php, herencia de Boost, SCSS, layouts y overrides de templates/renderers |
| `filters.md` / `course-formats.md` | Convención `\core_filters\text_filter` de 4.5; `core_courseformat\base` y clases de salida |
| `repositories.md` / `enrolment.md` | Contrato de la clase repository; flujo de `enrol_plugin` y API del subsistema |
| `question-types.md` | Plugins qtype y qbank, conceptos básicos del motor de preguntas |
| `other-plugin-types.md` | Catálogo completo de tipos de plugin de 4.5, además de proveedores/ubicaciones de IA, TinyMCE, antivirus, availability, customfield, sms y otros |
| `subplugins.md` | db/subplugins.json, tipos de campos de base de datos, herramientas de Book, pruebas Behat de TinyMCE y migración de formatos de curso |
| `workflow-guides.md` | Flujo de Git, API de actualización de plugins, profiling, migración a Bootstrap 5, requisitos de 4.5 y novedades de dev-update |

### `moodle-core-apis`

Una referencia por cada API principal — el router asigna cada tarea a su archivo.

| Referencia | Cubre |
|---|---|
| `database.md` | Métodos de `$DB`/DML, placeholders, transacciones, helpers `sql_*`, XMLDB/DDL |
| `forms.md` | Ciclo de vida de moodleform, catálogo de elementos, validación y elementos de archivos |
| `output-templates.md` | `$PAGE`/`$OUTPUT`, renderers, renderables, sintaxis Mustache y helpers |
| `events-tasks.md` | Clases de eventos y observadores; tareas programadas y ad hoc |
| `caching.md` / `files.md` | Definiciones y uso de MUC; File API, servicio pluginfile y áreas de borrador |
| `access-roles.md` | Contextos, capacidades, has_capability/require_login |
| `webservices.md` | Funciones `\core_external\external_api`, db/services.php y core/ajax |
| `privacy.md` | Clases provider de RGPD, metadatos, exportación y borrado |
| `hooks-di.md` | Hooks API de 4.5, inyección de dependencias, `\core\clock` y deprecaciones |
| `javascript.md` | Módulos AMD/ESM, grunt, core/str, core/modal y reglas de promesas |
| `javascript-advanced.md` | Biblioteca reactiva principal, comboboxsearch y reconocimiento de YUI legacy |
| `webservices-advanced.md` | Subsistema de Routing de 4.5 (`/api/rest/v2`), pruebas de funciones externas y subida/descarga de archivos WS |
| `backup-restore.md` | Tareas y stepslib de backup/restore para actividades, bloques y herramientas de administración |
| `more-subsystems.md` | Subsistemas de editor, plagiarism, xAPI, favourites, time/clock, communication, IA y SMS, además de una introducción al motor de preguntas |
| `files-advanced.md` | Exploración de archivos, convertidores de documentos, internals de almacenamiento, drivers DML y utilidades CLI de privacidad |
| `other-apis.md` | Cadenas, mensajería, navegación, report builder, campos personalizados, configuración de administración, calendario, etiquetas, grupos y más |

### `moodle-coding-style`

El estilo de código oficial en un solo archivo: boilerplate GPL, reglas MOODLE_INTERNAL, nombres, espacios, etiquetas PHPDoc, namespaces, excepciones y estilo SQL. Se carga cuando el agente escribe código Moodle.

### `moodle-testing`

| Referencia | Cubre |
|---|---|
| `phpunit.md` | Comandos de inicialización/ejecución, advanced_testcase, generadores de datos, sinks y cobertura |
| `behat.md` | Estructura `.feature`, etiquetas, pasos personalizados y generadores de entidades |
| `ci-tools.md` | phpcs + moodle-cs, CI con GitHub Actions, grunt y lista de comprobación para enviar plugins |

## Instalación

El repositorio utiliza un directorio compartido `skills/` y manifiestos pequeños para sus integraciones de agentes. Instálalo una vez por cada entorno que uses.

### Claude Code

Registra este repositorio como marketplace e instálalo:

```bash
/plugin marketplace add catalanml/coodle-moodle45agentskills
/plugin install coodle-moodle45agentskills@coodle
```

O, sin publicarlo, copia las skills al directorio de skills de usuario o del proyecto:

```bash
cp -r skills/* ~/.claude/skills/
```

### Codex

`.codex-plugin/plugin.json` declara el directorio compartido `skills/`. Instala el repositorio como plugin desde la interfaz de plugins de Codex (`/plugins`) o apunta Codex a un clon local. `AGENTS.md` proporciona el enrutamiento incluso sin soporte de plugins: clona este repositorio y referencia `AGENTS.md` desde las instrucciones de agente de tu proyecto.

### Otros agentes (`AGENTS.md`)

Cualquier agente que lea `AGENTS.md` puede usar el conjunto: clona este repositorio en una ubicación estable y añade una línea a las instrucciones de agente de tu proyecto:

```markdown
Antes de escribir código Moodle, lee /ruta/a/coodle-moodle45agentskills/AGENTS.md
y sigue el enrutamiento de skills que describe.
```

Las skills son Markdown plano: no hay hooks, scripts ni dependencias de ejecución.

## Sesión de ejemplo

> **Tú:** Crea un plugin de bloque que muestre las cinco tareas más recientemente calificadas para el usuario actual.
>
> **Agente:** *carga `moodle-plugin-development` (common-files + blocks), `moodle-core-apis` (database, access-roles), `moodle-coding-style` — y crea `blocks/recentgrades/` con un version.php correcto, `db/access.php` con `block/recentgrades:addinstance` + `myaddinstance`, una clase `block_recentgrades` que usa `$DB->get_records_sql()` con placeholders `{grade_grades}` y una comprobación de capacidad adecuada, cadenas de idioma para cada etiqueta visible y boilerplate GPL que pasa phpcs.*

## Principios de diseño

- **Destilado, no incluido como vendor.** La documentación bruta de 4.5 son cientos de páginas de Docusaurus. Cada archivo de referencia es una reescritura compacta y autónoma (100–450 líneas) con los datos esenciales: nombres de clases, firmas, rutas de archivos y ejemplos de código reales.
- **Router + referencias.** Los agentes tienen un contexto finito. Los archivos `SKILL.md` se mantienen pequeños y apuntan a exactamente un archivo por tema, para que una pregunta sobre formularios no cargue también la documentación de caching.
- **Datos provenientes de la documentación.** El contenido proviene de la documentación oficial, no de la memoria del modelo. Cuando la documentación 4.5 no cubre algo, los archivos lo indican y apuntan a la wiki legacy en vez de inventar una API.
- **Precisión para 4.5 antes que fidelidad literal.** Cuando la documentación oficial está desactualizada (por ejemplo, muestra un callback de finalización eliminado en 4.3), las skills enseñan la API actual y anotan la discrepancia.

## Precisión y verificación

La auditoría de fuentes utiliza el árbol 4.5 actual de `moodle/devdocs`: 188 archivos Markdown/MDX en total, compuestos por 148 páginas de contenido/ejemplos y 40 snippets reutilizables. Las 148 páginas están distribuidas entre las 33 referencias; los snippets se integran en las referencias de su tema. Las páginas índice que solo sirven de orientación están representadas por los routers y este README. Las afirmaciones importantes (nombres de clases, firmas de métodos, rutas, constantes y comandos) se comprobaron contra el clon de las fuentes, y los ejemplos upstream desactualizados que producirían código 4.5 inválido se señalan dentro de los archivos.

## Limitaciones conocidas

Aspectos que la documentación oficial de 4.5 sencillamente no cubre — los archivos los señalan e incluyen referencias a la wiki legacy (`docs.moodle.org/dev`):

- API de Gradebook (`grade_update()`, elementos de calificación): en 4.5 solo está documentado Advanced Grading.
- Páginas completas de String API y Events API: provienen de la wiki legacy y están marcadas como tales.
- Presets SCSS de temas e internals de formularios qtype: la documentación enlaza a otros recursos en lugar de documentarlos.
- La documentación de restore de actividades termina literalmente con «(to be continued)» upstream; `backup-restore.md` señala lo que falta.
- La documentación de Moodle App (móvil) está intencionalmente fuera del alcance.

Cada página no relacionada con App del árbol versionado 4.5 está destilada en un archivo de referencia.

## Actualizar el contenido

El contenido se destiló desde [moodle/devdocs](https://github.com/moodle/devdocs) (`versioned_docs/version-4.5/` más las páginas de política de estilo de código) en el commit de fuente `6347680795082ad2824e3cf5fc73caa96be318c5` del **2026-08-15**. Moodle 4.5 es una versión LTS, por lo que el drift es lento, pero para actualizarlo: vuelve a clonar devdocs, repite la destilación con las mismas rutas de origen y vuelve a verificar. Las páginas de Moodle App y `db/mobile.php` están intencionalmente excluidas. Para una edición futura de 5.x, crea una copia del conjunto y vuelve a destilar desde `versioned_docs/version-5.x`.

## Contribuir

1. Haz fork de este repositorio y crea una rama desde `main`.
2. Mantén las reglas: Markdown plano de GitHub, sin sintaxis de Docusaurus, datos basados en la documentación oficial (cita la página fuente en tu PR) y routers breves.
3. Un tema por archivo de referencia; coloca la amplitud en los archivos `other-*`.
4. Envía un PR describiendo qué páginas de documentación respaldan tu cambio.

## Licencia

GPL-3.0-or-later. El contenido deriva de la documentación de desarrollo de Moodle, que forma parte del proyecto Moodle (GPL).
