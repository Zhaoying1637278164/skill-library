# Moodle 4.5 Text Filter Plugins

Scope: structure, class conventions, filter() method, local configuration and dynamic-content handling for `filter_*` plugins, per Moodle 4.5 developer docs.

Filters automatically transform content before output (e.g. TeX to images, media links to players, glossary auto-linking). They are applied to all content passed through `format_text()` (headers and content) and `format_string()` (headers only) from the Output API.

## File structure

Filter plugins live in `/filter`. Minimal layout for `filter_pluginname`:

```console
 filter/pluginname/
 |-- lang
 |   `-- en
 |       `-- filter_pluginname.php
 |-- classes
 |   `-- text_filter.php
 `-- version.php
```

- `classes/text_filter.php` (required): the main filter class. Filters have only one mandatory class, extending the core `\core_filters\text_filter` class. Note: in 4.5 the docs place the filter class in `classes/text_filter.php` with namespace `filter_pluginname` and base class `\core_filters\text_filter` (not the legacy `filter.php` / `moodle_text_filter`).
- `version.php` (required): standard plugin version file.
- `lang/en/filter_pluginname.php` (required): language strings, e.g.

```php
$string['filtername'] = 'Activity names auto-linking';
```

## The filter class and filter() method

```php
// filter/pluginname/classes/text_filter.php
namespace filter_pluginname;

class text_filter extends \core_filters\text_filter {
    function filter(string $text, array $options = []) {
        // Return the modified text.
        return $text;
    }
}
```

`filter()` receives the text and an options array, and must return the (possibly modified) text.

## Testing a filter

Enable the filter in the filters administration screen (set it "On"). Add content to a label resource; viewing the course should show the transformed text.

## Performance

Every active filter runs on every `format_text()` / `format_string()` call, so filters can cause big performance problems. Use caching if the filter hits the database or similar sources. If the filter depends on a special syntax or substring, do a cheap `strpos()`/`stripos()` check before any regex work:

```php
public function filter($text, array $options = []) {
    if (!is_string($text) or empty($text)) {
        // Non-string data can not be filtered anyway.
        return $text;
    }
    if (stripos($text, '</a>') === false) {
        // Performance shortcut - if there is no </a> tag, nothing can match.
        return $text;
    }
    // Complex operations on <a> links here.
}
```

## Local (per-context) configuration

Filters can be configured differently per context (e.g. the glossary filter linking a different glossary in Forum A vs Forum B). Provide a `filterlocalsettings.php` file defining a form that subclasses the filter local settings form class; besides standard formslib methods you must define a `save_changes` method.

```php
// filterlocalsettings.php
class pluginfile_filter_local_settings_form extends \core_filters\form\local_settings_form {
    protected function definition_inner(\MoodleQuickForm $mform) {
        $mform->addElement(
            'text',
            'word',
            get_string('word', 'filter_helloworld'),
            ['size' => 20]
        );
        $mform->setType('word', PARAM_NOTAGS);
    }
}
```

Local configuration is available in the filter class via `$this->localconfig`:

```php
namespace filter_pluginname;

class text_filter extends \core_filters\text_filter {
    public function filter(string $text, array $options = []) {
        $search = $this->localconfig['word'] ?? 'default';
        return str_replace($search, "Hello $search!", $text);
    }
}
```

## Filtering dynamic (AJAX-loaded) content

Content added after page load has already been PHP-filtered, but filters that need JS post-processing (e.g. MathJax) can listen for the content-updated event from the `core_filters/events` module:

```js
import {eventTypes} from 'core_filters/events';

export const init = () => {
    document.addEventListener(eventTypes.filterContentUpdated, contentUpdatedHandler);
};

const contentUpdatedHandler = (event) => {
    const updatedContent = event.detail.nodes;
    updatedContent.forEach(content => {
        // Alter any updated content.
    });
};
```
