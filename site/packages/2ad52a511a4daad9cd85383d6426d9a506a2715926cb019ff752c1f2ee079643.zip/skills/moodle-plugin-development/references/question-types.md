# Question Types and Question Bank Plugins (Moodle 4.5)

Reference for developing question type (`qtype_`) and question bank (`qbank_`) plugins, plus the question engine concepts qtype authors need.

## Question subsystem overview

The question subsystem has two main subcomponents, each served by its own plugin types:

**The question engine** makes questions work when users attempt them. Main core user is `mod_quiz` (also `qbank_previewquestion`, and contrib plugins like `filter_embedquestion`). It orchestrates two plugin types:

- **Question types (`qtype_`)** define what the question *is* — multiple choice, drag-drop, shortanswer, numerical, or complex types like crossword or coderunner.
- **Question behaviours (`qbehaviour_`)** define how a student *interacts* with questions:
  - `qbehaviour_deferredfeedback` — classic exam style: answers submitted, graded and feedback given later.
  - `qbehaviour_immediatefeedback` — a 'Check' button per question for immediate grading.
  - `qbehaviour_interactive` — after a wrong first try, the student can 'Try again' using the feedback.

**The question bank** is the UI where teachers create, edit and manage questions. Core question bank code mainly ties together features supplied by plugins:

- **Question bank plugins (`qbank_`)** add features to the question bank (since 4.0, MDL-70329).
- **Question import/export plugins (`qformat_`)** provide import/export formats, used by `qbank_exportquestions`, `qbank_importquestions`, `qbank_exporttoxml`.
- **Question types (`qtype_`)** also integrate with the bank so their questions can be created and edited.

### Key question engine classes

When a question is attempted with a behaviour, the core engine orchestrates both plugins, stores progress in the DB (efficiently, in bulk), and presents a uniform API to consumers like a quiz attempt:

1. `question_engine` — main entry point into this part of the API.
2. `question_attempt` — a user's attempt at one question. Users usually attempt a group of questions together, so `question_usage_by_activity` is even more important.
3. `question_state` — tracks the state of each question in a way consumers (e.g. quiz) can understand, without restricting how behaviours work.
4. `question_display_options` — how the consumer (e.g. quiz) controls which parts (grade, feedback, ...) are visible when a question is rendered. Behaviour plugins can further modify display options based on the current `question_attempt` state during rendering.
5. `core_question_renderer` — renders the overall question layout, working with the applicable `qtype_` and `qbehaviour_` renderers for the details.

## Question type (qtype_) plugin structure

Question types live in `question/type/<name>/` and must provide:

1. `edit_..._form.php` — editing form so teachers can create and edit questions of this type.
2. `questiontype.php` (docs: `questiontypes.php`) — class handling loading/saving data from that form, plus:
   - related methods providing metadata about the question type;
   - import and export in any question formats the type wants to support.
3. `question.php` — the class representing one instance of the question while it is being attempted. It must:
   - start a new attempt (e.g. multiple choice randomly shuffles the choices here);
   - or, when continuing an existing attempt, re-initialise the question to the same state from DB data;
   - tell the question engine what submitted data this question type expects;
   - analyse submitted responses: has it changed? is it complete?
   - automatically grade the response to a 'fraction' (mark between 0 and 1) and a state (correct / partially correct / incorrect);
   - check access to files for the File API.
4. `renderer.php` — displays the key bits of the question type, for `core_question_renderer` to combine into the overall question display.
5. Backup and restore, plus all standard Moodle plugin parts (DB tables, lang strings, version.php, ...).
6. Optionally, defaults for new questions (below).

## Defaults for new questions

Question types can remember a teacher's preferred settings (as user preferences) and reuse them as defaults when creating a *new* question. Preferences are saved only when a new question is created and saved — never when editing an existing question (which may have been created by someone else).

**Which settings to save:** not name or question text (those uniquely define a question). Good candidates are presentation options, e.g. whether multiple-choice answers are numbered 'a, b, c', '1, 2, 3', or not at all. Search core for implementations of `save_defaults_for_new_questions` for consistent examples.

**In the form class** — replace hard-coded defaults with `get_default_value`:

```php
// Before:
$mform->setDefault('shuffleanswers', 1);

// After:
$mform->setDefault('shuffleanswers', $this->get_default_value('shuffleanswers', 1));
```

**In the question-type class** — override `save_defaults_for_new_questions`:

```php
public function save_defaults_for_new_questions(stdClass $fromform): void {
    parent::save_defaults_for_new_questions($fromform);
    $this->set_default_value('shuffleanswers', $fromform->shuffleanswers);
}
```

Save the same settings that the form fetches with `get_default_value`. Calling `parent` is required because core saves some settings applying to all question types.

**Privacy provider:** since this uses user preferences, your privacy provider must declare them — including the ones saved by core. Easiest approach: copy another question type, e.g. `question/type/match/classes/privacy/provider.php` in moodle core.

**Tests:** unit tests for the privacy provider (see `question/type/match/tests/privacy/provider_test.php`) and a Behat test showing saved settings are reused (many qtypes have a `tests/behat/add.feature` where coverage is easy to add).

## Question bank (qbank_) plugins

Since Moodle 4.0 (MDL-70329). Located in `question/bank/<name>/`. They can extend the question bank with:

- Table columns
- Action menu items
- Bulk actions
- Navigation node (tabs)
- Question preview additions (via callback)
- Question filters (since 4.3, MDL-72321)

The starting point for most features is a class `classes/plugin_features.php` (class `plugin_feature`, extending `core_question\local\bank\plugin_features_base`) declaring which features the plugin adds. Core `qbank_*` plugins are the reference implementations to copy from.

## Question bank filters

Filters apply when viewing the question bank, are included in the URL (shareable filtered views), and define criteria for adding random questions to a quiz.

A filter condition has two parts:

- a backend **condition** PHP class (name, options, how it applies to the question bank query), extending `core_question\local\bank\condition`;
- a frontend **filter** JavaScript class (UI, passing selected values back), by default `core/datafilter/filtertype` — overridable.

### Minimal implementation

Condition class:

```php
// question/bank/myplugin/classes/myfilter_condition.php
namespace qbank_myplugin;

use core_question\local\bank\condition;

class myfilter_condition extends condition {

}
```

Register it from `plugin_feature::get_question_filters()`:

```php
// question/bank/myplugin/classes/plugin_feature.php
namespace qbank_myplugin;

class plugin_feature extends core_question\local\bank\plugin_features_base {
    public function get_question_filters(?core_question\local\bank\view $qbank = null): array {
        return [
            new myfilter_condition($qbank),
        ];
    }
}
```

Required condition methods:

```php
public function get_name(): string {
    return get_string('myfilter_name', 'myplugin');   // Label shown in the filter UI.
}

public function get_condition_key(): string {
    return 'myfilter';   // Unique machine-readable ID used in filter parameters.
}
```

The query itself — `build_query_from_filter()` returns an SQL `WHERE` fragment and params. `$filter` contains `'values'` (selected values) and `'jointype'` (`JOINTYPE_ANY`, `JOINTYPE_ALL`, or `JOINTYPE_NONE`). Conditions from all filters are combined in `core_question\local\bank\view::build_query()`.

```php
public function build_query_from_filter(array $filter): array {
    $andor = ' AND ';
    $equal = '=';
    if ($filter['jointype'] === self::JOINTYPE_ANY) {
        $andor = ' OR ';
    } else if ($filter['jointype'] === self::JOINTYPE_NONE) {
        $equal = '!=';
    }
    $conditions = [];
    $params = [];
    // In real life we'd probably use $DB->get_in_or_equal here.
    foreach ($filter['values'] as $key => $value) {
        $conditions[] = 'q.fieldname ' . $equal . ' :myfilter' . $key;
        $params['myfilter' . $key] = $value;
    }
    return [
        '(' . implode($andor, $conditions) . ')',
        $params,
    ];
}
```

### Optional condition overrides

| Method | Purpose |
|---|---|
| `get_initial_values(): array` | Pre-defined selectable values, an array of `['value' => ..., 'title' => ...]` entries, searchable in the autocomplete field. |
| `allow_custom(): bool` | Return `false` to restrict terms to those from `get_initial_values()`. |
| `get_join_list(): array` | Restrict join types, e.g. `[datafilter::JOINTYPE_ANY, datafilter::JOINTYPE_NONE]` when `JOINTYPE_ALL` makes no sense. |
| `allow_multiple(): bool` | Return `false` to allow only a single value at a time. |
| `allow_empty(): bool` | Return `false` to make selecting a value compulsory when the condition is added. |
| `is_required(): bool` | Return `true` to always display the condition. |
| `get_filter_class(): string` | Namespaced path to a custom JS filter class, e.g. `'qbank_myplugin/datafilter/filtertype/myfilter'`. |
| `get_filteroptions(): object` | Extra options for how values are applied (e.g. include child categories). Read current options in the constructor and use them in `build_query_from_filter()`. |

### Custom JavaScript filter class

Default (`core/datafilter/filtertype`) provides a single autocomplete for numeric IDs with text labels. To customise, either reuse another core type from `/lib/amd/src/datafilter/filtertypes`, or create `amd/src/datafilter/filtertypes/myfilter.js` exporting a default class extending `core/datafilter/filtertype`:

- Override `get values()` for textual (non-`parseInt`) values — see `qbank_viewquestiontype/datafilter/filtertypes/type`.
- Override `addValueSelector()` for a different value-selection UI.
- For filter options: override the constructor to add the options UI and `get filterOptions()` to return current values — see `qbank_managecategories/datafilter/filtertypes/categories` (JS) and `qbank_managecategories\category_condition` (PHP).

### Context-sensitive configuration

The condition constructor receives the current `$qbank` view object; extract data from it for use in other methods. Example: the tag condition (`qbank_tagquestion\tag_condition`) uses the current page context to control which tags the filter offers.

## Core examples to copy from

- `question/type/match` — defaults-for-new-questions, privacy provider, and Behat patterns.
- `question/bank/managecategories` — filter options (PHP condition + JS filter class).
- `question/bank/tagquestion` — context-sensitive filter condition.
- `question/bank/viewquestiontype` — custom JS filter type with textual values.
- Core `qbank_*` plugins generally — reference implementations for columns, actions, bulk actions, tabs.
