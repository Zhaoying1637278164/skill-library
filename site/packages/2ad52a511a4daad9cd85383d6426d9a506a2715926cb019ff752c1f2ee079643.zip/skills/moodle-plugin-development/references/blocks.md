# Block plugins (Moodle 4.5)

Reference for developing block plugins: file structure, block class API, instance and global configuration, capabilities, and page-type restrictions.

Block plugins show supplemental information and features within different parts of Moodle. They live in the `/blocks` directory, one subdirectory per plugin.

## File structure

```console
blocks/pluginname/
|-- db
|   `-- access.php
|-- lang
|   `-- en
|       `-- block_pluginname.php
|-- pix
|   `-- icon.png
|-- block_pluginname.php
|-- edit_form.php (optional)
`-- version.php
```

Required files: `block_pluginname.php` (block definition class), `db/access.php` (capabilities), `lang/en/block_pluginname.php`, `version.php`. `edit_form.php` is only needed if the block has per-instance configuration.

The easiest way to scaffold a new block is [tool_pluginskel](https://moodle.org/plugins/tool_pluginskel).

## Block class: block_pluginname.php

All blocks must provide a main class extending one of two base classes:

- `block_base` - default base class for content blocks.
- `block_list` - for blocks that display a list of items.

```php
class block_pluginname extends block_base {

    public function init() {
        $this->title = get_string('pluginname', 'block_pluginname');
    }

    public function get_content() {
        global $OUTPUT;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->footer = '';

        // Add logic here to define your template data or any other content.
        $data = ['YOUR DATA GOES HERE'];

        $this->content->text = $OUTPUT->render_from_template('block_yourplugin/content', $data);

        return $this->content;
    }

    public function applicable_formats() {
        return [
            'admin' => false,
            'site-index' => true,
            'course-view' => true,
            'mod' => false,
            'my' => true,
        ];
    }
}
```

### Class attributes

- `$this->config` - block instance configuration. Empty object by default; if the block has `edit_form.php`, holds the form data.
- `$this->content` - the actual displayed content; NULL or a stdClass whose members depend on the base class.
- `$this->page` - the page the block is displayed on.
- `$this->context` - the context the block is displayed in.
- `$this->title` - the block title.

### init()

Essential for all blocks; called before the block is displayed to give values to class member variables. It runs **before** `$this->config` is set — if a config value is needed for global attributes like the title, use `specialization()` instead.

### specialization()

Called right after an instance is loaded. Used to customize title and other attributes depending on page type, context, configuration, etc.

```php
function specialization() {
    if (isset($this->config->title)) {
        $this->title = format_string($this->config->title, true, ['context' => $this->context]);
    } else {
        $this->title = get_string('newhtmlblock', 'block_html');
    }
}
```

### get_content()

Produces the on-screen content. It can be called several times during page rendering, so return early if `$this->content` is already set (see example above).

For a `block_list` block, populate `items`, `icons` and `footer` instead:

```php
class block_pluginname extends block_list {

    public function get_content() {
        global $OUTPUT;
        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = (object) [
            'items'  => [],
            'icons'  => [],
            'footer' => 'Footer here...',
        ];

        $this->content->items[] = 'An item of pluginname block';
        $this->content->icons[] = $OUTPUT->pix_icon('i/course', get_string('course'));

        return $this->content;
    }
}
```

If the content is empty (`text` and `footer` for block_base; empty `items` array for block_list), Moodle's `is_empty()` check hides the block entirely.

### Other overridable methods

```php
// Allow more than one instance per page (default: one). Admins can still
// disallow this per-block in site administration.
public function instance_allow_multiple() {
    return true;
}

// Hide the standard block header (ignored in edit mode).
public function hide_header() {
    return true;
}

// Inject extra HTML attributes into the block wrapper.
public function html_attributes() {
    $attributes = parent::html_attributes();
    $attributes['class'] .= ' block_' . $this->name();
    return $attributes;
}
```

## Instance configuration: edit_form.php

Add an `edit_form.php` with a class extending `block_edit_form`; settings then appear in `$this->config`.

```php
class block_pluginname_edit_form extends block_edit_form {
    protected function specific_definition($mform) {
        // Section header title according to language file.
        $mform->addElement('header', 'config_header', get_string('blocksettings', 'block'));
        // A sample string variable with a default value.
        $mform->addElement('text', 'config_text', get_string('blockstring', 'block_pluginname'));
        $mform->setDefault('config_text', 'default value');
        $mform->setType('config_text', PARAM_TEXT);
    }
}
```

Caveats:

- All field names must start with `config_`, otherwise they are not saved and not available via `$this->config`.
- `$this->config` is available in all block methods **except init()**; use `specialization()`.
- Do not use the `checkbox` form element (once set it stays set); use `advcheckbox`.

### instance_config_save() (optional)

By default all `config_*` settings are base64-encoded into the `configdata` field of the `block_instances` table and decoded into `$this->config` on load. To store data elsewhere or alter it before saving:

```php
public function instance_config_save($data, $nolongerused = false) {
    // Example of add new data.
    $data->somenewattribute = 'Some new value';

    // Example of alter the current data.
    $data->text = 'Some new text';

    // Call the parent method to store the data inside block_instances.configdata.
    return parent::instance_config_save($data, $nolongerused);
}
```

## Global settings: settings.php + has_config()

Site-wide settings go in `blocks/pluginname/settings.php` (standard admin settings file). Unlike other plugin types, blocks must also override `has_config()`:

```php
function has_config() {
    return true;
}
```

Global settings are not part of the block instance; read them with:

```php
$settingvalue = get_config('block_pluginname', 'settingname');
```

## Capabilities: db/access.php

Blocks require the `addinstance` and `myaddinstance` capabilities:

```php
$capabilities = [
    'block/pluginname:myaddinstance' => [
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [
            'user' => CAP_ALLOW
        ],
        'clonepermissionsfrom' => 'moodle/my:manageblocks'
    ],
    'block/pluginname:addinstance' => [
        'riskbitmask' => RISK_SPAM | RISK_XSS,
        'captype' => 'write',
        'contextlevel' => CONTEXT_BLOCK,
        'archetypes' => [
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ],
        'clonepermissionsfrom' => 'moodle/site:manageblocks'
    ],
];
```

Language file must include the capability strings:

```php
$string['pluginname'] = 'Pluginname';
$string['pluginname:addinstance'] = 'Add a new pluginname block';
$string['pluginname:myaddinstance'] = 'Add a new pluginname block to the My Moodle page';
```

## Limiting the block to specific page types

`applicable_formats()` returns an associative array mapping page format keys to booleans. Conventions:

- `all` - catch-all; `['all' => true]` allows any page.
- `site-index` - Moodle frontpage.
- `course-view` - course page, any format.
- `course-view-FORMATNAME` - course page with a given format (e.g. `course-view-weeks`).
- `mod` - any activity page.
- `mod-MODNAME-view` - a specific activity page (e.g. `mod-forum-view`).
- `my` - the Dashboard.
- `admin` - any administration page.
