# Moodle 4.5 Theme Plugins

Reference for building theme plugins (`theme_*`): structure, config.php, Boost inheritance, SCSS, layouts, and overriding templates/renderers/images/fonts.

## File structure

Themes live in `/theme/<themename>`:

```console
theme/example
|-- amd
|   └-- src
|-- classes
|   └-- output
|-- fonts
|-- fonts_core
|-- fonts_plugins
|   └-- plugintype
|        └-- pluginname
|-- lang
|   └-- en
|       └-- theme_example.php
|-- layout
|-- pix
|   └-- favicon.ico
|   └-- screenshot.png
|-- pix_plugins
|   └-- plugintype
|        └-- pluginname
|-- style
|-- scss
|-- templates
|-- config.php
|-- settings.php
└-- version.php
```

Required language strings in `lang/en/theme_<themename>.php`:

```php
$string['pluginname'] = 'Boost';
$string['choosereadme'] = 'Boost is a modern, highly-customisable theme. ...';
$string['configtitle'] = 'Boost';
```

- `pluginname` — name shown in the Theme selector (without it the theme shows as `[pluginname]`).
- `choosereadme` — text beneath the theme info screenshot.
- `configtitle` — settings title. Add further strings for settings form controls.

`version.php` must set `$plugin->component = 'theme_<themename>';`. The theme selector `screenshot` (in `pix/`) should be about 500 x 400 px.

## config.php

All theme options go on the `$THEME` object. Boost's own config (abridged):

```php
defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/lib.php');

$THEME->name = 'boost';
$THEME->sheets = [];
$THEME->editor_sheets = [];
$THEME->editor_scss = ['editor'];
$THEME->usefallback = true;
$THEME->scss = function($theme) {
    return theme_boost_get_main_scss_content($theme);
};

$THEME->layouts = [ /* see Layouts below */ ];

$THEME->parents = [];
$THEME->enable_dock = false;
$THEME->extrascsscallback = 'theme_boost_get_extra_scss';
$THEME->prescsscallback = 'theme_boost_get_pre_scss';
$THEME->precompiledcsscallback = 'theme_boost_get_precompiled_css';
$THEME->yuicssmodules = [];
$THEME->rendererfactory = 'theme_overridden_renderer_factory';
$THEME->requiredblocks = '';
$THEME->addblockposition = BLOCK_ADDBLOCK_POSITION_FLATNAV;
$THEME->iconsystem = \core\output\icon_system::FONTAWESOME;
$THEME->haseditswitch = true;
$THEME->usescourseindex = true;
$THEME->activityheaderconfig = ['notitle' => true];
```

Key settings:

- `$THEME->name` — theme name, normally the directory name.
- `$THEME->sheets` — CSS stylesheet names (no directory, no extension) assumed to live in `{theme}/style/*.css`. Not required when using SCSS.
- `$THEME->editor_sheets` — stylesheets included inside text editors (Tiny) so content resembles its final appearance.
- `$THEME->parents` — themes to inherit from. If the parent itself has a parent, list the grandparent too. Inheriting from Boost:

```php
$THEME->parents = ['boost'];
```

- `$THEME->scss` — name of a SCSS file in the theme's `scss/` folder compiled on the fly (sheets with the same name are ignored), or a closure returning SCSS, in which case `@import` paths are relative to the `scss` folder of this theme or any parent.
- `$THEME->prescsscallback` — function returning SCSS injected at the *beginning* of the SCSS from `$THEME->scss` (used to inject variables from settings).
- `$THEME->extrascsscallback` — function returning SCSS injected at the *end*.
- `$THEME->rendererfactory` — almost all themes must set `theme_overridden_renderer_factory`, or the theme cannot customise any core renderers.
- `$THEME->layouts` — page-type-to-layout-file map (below).
- `$THEME->csstreepostprocessor` — function manipulating an in-memory CSS tree (e.g. `theme_boost\autoprefixer` for vendor prefixes); `$THEME->csspostprocess` — function all CSS passes through before delivery.
- `$THEME->parents_exclude_sheets` / `$THEME->parents_exclude_javascripts` — arrays NOT to inherit from parents; `$THEME->plugins_exclude_sheets` — plugin sheets to skip.
- `$THEME->hidefromselector` — hide from the theme selector unless theme designer mode is on.
- `$THEME->undeletableblocktypes` — block types that must exist on all pages (auto-created if missing).
- `$THEME->addblockposition` — `BLOCK_ADDBLOCK_POSITION_FLATNAV`, `_DEFAULT`, or `_CUSTOM`.
- `$THEME->yuicssmodules` — legacy; set to empty to prevent YUI CSS being included.
- `$THEME->javascripts` / `$THEME->javascripts_footer` — deprecated; use AMD modules in `amd/src` instead.

Tip: read the config.php of themes shipped with Moodle to see working combinations. A theme extending another theme does not need to define any layouts (or layout files) if it makes no layout changes.

## SCSS and styles

Moodle supports SASS/SCSS (recommended over plain CSS). Set `$THEME->scss = 'filename';` (a file in `scss/`) and Moodle compiles it with its built-in pre-processor on first load — or on every load when `themedesignermode` is enabled. SCSS compiled on the fly exists specifically to allow dynamic customisation of SCSS variables (e.g. from theme settings via `prescsscallback`).

Plain CSS alternative: put sheets in `theme/<themename>/style/*.css` and list them in `$THEME->sheets`. Sheets from the current theme are included after parents', so its rules take precedence. Plugins ship their own `styles.css` (`mod/<modname>/styles.css`, etc.); theme-specific plugin styles belong in the theme.

Standard themes list one main SCSS file named `moodle` which `@import`s everything else. Boost builds its SCSS via a callback (`theme_boost_get_main_scss_content($theme)`) plus `theme_boost_get_pre_scss` / `theme_boost_get_extra_scss`; a child of Boost reuses this pattern with its own callbacks in its `lib.php`.

Writing rules — every page body gets an ID from the URI and path classes, e.g. `/mod/forum/view.php`:

```html
<body id="page-mod-forum-view"
    class="format-weeks path-mod path-mod-forum dir-ltr lang-en
        pagelayout-incourse course-11 context-616 cmid-202 category-1 jsenabled">
```

```css
/* one page */
#page-mod-forum-view .forumpost { border: 1px solid blue; }
/* whole forum module */
.path-mod-forum .forumpost { border: 1px solid blue; }
```

Other body classes: `jsenabled`, `dir-rtl`/`dir-ltr`, `lang-<code>`, `notloggedin`, `format-<courseformat>`, `pagelayout-<layout>`. Write as few rules as possible; Bootstrap-based themes can do most things with Bootstrap classes alone.

## Layouts

Defined in `$THEME->layouts`. Each entry:

```php
$THEME->layouts = [
    'standard' => [
        'theme' => 'boost',           // Optional: take the layout file from another theme.
        'file' => 'columns2.php',     // Required: file in layout/.
        'regions' => ['side-pre'],    // Required: block regions.
        'defaultregion' => 'side-pre',// Required if regions is non-empty.
        'options' => [],              // Optional: available as $PAGE->layout_options.
    ],
];
```

Boost maps nearly all layout types to `drawers.php`; `login` uses `login.php`, `popup`/`frametop`/`print` use `columns1.php`, `embedded`/`redirect` use `embedded.php`, `maintenance` uses `maintenance.php`, `secure` uses `secure.php`. Common `options` include `langmenu`, `nonavbar`, `nofooter`, `nocoursefooter`, `activityheader` (`notitle`, `nocompletion`, `nodescription`), `noactivityheader`.

Layout types: `base`, `standard`, `course`, `coursecategory`, `incourse`, `frontpage`, `admin`, `mycourses`, `mydashboard`, `mypublic`, `login`, `popup`, `frametop`, `embedded`, `maintenance`, `print`, `redirect`, `report`, `secure`.

Layout options are read in layout files:

```php
$hasnavbar = (empty($PAGE->layout_options['nonavbar']) && $PAGE->has_navbar());
$hasfooter = (empty($PAGE->layout_options['nofooter']));
```

### Layout files

Best practice: gather data into a context and render a mustache template.

```php
// theme/boost/layout/columns1.php
$bodyattributes = $OUTPUT->body_attributes([]);

$templatecontext = [
    'sitename' => format_string($SITE->shortname, true,
        ['context' => context_course::instance(SITEID), "escape" => false]),
    'output' => $OUTPUT,
    'bodyattributes' => $bodyattributes
];

echo $OUTPUT->render_from_template('theme_boost/columns1', $templatecontext);
```

Minimal layout template — treat every `output.*` call below as required:

```handlebars
{{{ output.doctype }}}
<html {{{ output.htmlattributes }}}>
<head>
    <title>{{{ output.page_title }}}</title>
    <link rel="shortcut icon" href="{{{ output.favicon }}}" />
    {{{ output.standard_head_html }}}
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body {{{ bodyattributes }}}>
<div id="page-wrapper">
    {{{ output.standard_top_of_body_html }}}
    <div id="page" class="container-fluid">
        <div id="page-content" class="row">
            <div id="region-main-box" class="col-xs-12">
                <section id="region-main">
                    <div class="card card-block">
                    {{{ output.course_content_header }}}
                    {{{ output.main_content }}}
                    {{{ output.course_content_footer }}}
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>
{{{ output.standard_end_of_body_html }}}
</body>
</html>
{{#js}}
require(['theme_boost/loader']);
{{/js}}
```

Block regions: for each region declared in config.php, render its HTML in the layout:

```php
$blockshtml = $OUTPUT->blocks('side-pre');
$hasblocks = strpos($blockshtml, 'data-block=') !== false;
$templatecontext += ['sidepreblocks' => $blockshtml, 'hasblocks' => $hasblocks];
```

```handlebars
{{#hasblocks}}
<section data-region="blocks-column" class="hidden-print">
    {{{ sidepreblocks }}}
</section>
{{/hasblocks}}
```

All themes must include at least the divs (same ids, e.g. `page-header`) present in Boost, or modules/plugins may misbehave.

## Overriding templates

Any component's mustache template can be overridden by placing a copy at `theme/<themename>/templates/<componentname>/<templatename>.mustache` and editing it. With theme designer mode on, changes show immediately; otherwise purge caches. Remove the documentation comment from the copy if the parent's still applies.

| Original template | Component | Theme override path |
| --- | --- | --- |
| `blocks/myoverview/templates/view-summary.mustache` | `block_myoverview` | `theme/mytheme/templates/block_myoverview/view-summary.mustache` |
| `group/templates/group_details.mustache` | `core_group` | `theme/mytheme/templates/core_group/group_details.mustache` |
| `lib/templates/modal.mustache` | `core` | `theme/mytheme/templates/core/modal.mustache` |
| `theme/boost/templates/navbar.mustache` | `theme_boost` | `theme/mytheme/templates/theme_boost/navbar.mustache` |

## Overriding renderers

Set `$THEME->rendererfactory = 'theme_overridden_renderer_factory';` in config.php (without it the theme cannot customise core renderers). Plugins expose `plugin_renderer_base` subclasses with `render_<renderable>` methods; a theme provides its own version of such a renderer (in `classes/output/`) to change any render method — manipulate the exported data or render a different template. Plugins using the `templatable`/`named_templatable` interfaces route data to templates automatically, so often overriding the template alone is enough.

## Overriding images and fonts

Images used by the theme go in `pix/` (subdirectories allowed). Reference them without file extension:

```php
$templatecontext = [
    $imageone => $OUTPUT->pix_url('imageone', 'theme'),
    $imagetwo => $OUTPUT->pix_url('subdir/imagetwo', 'theme'),
];
```

```css
.divone { background-image: url([[pix:theme|imageone]]); }
.divtwo { background-image: url([[pix:theme|subdir/imagetwo]]); }
```

Override core/plugin images by mirroring their path (any image format works as replacement):

- `/pix/moodlelogo.png` → `/theme/<themename>/pix_core/moodlelogo.png`
- `/pix/i/user.svg` → `/theme/<themename>/pix_core/i/user.svg`
- `/mod/chat/pix/monologo.svg` → `/theme/<themename>/pix_plugins/mod/chat/monologo.svg`

Fonts: theme fonts go in `fonts/` (no subdirectories; lowercase alphanumeric + underscore names; WOFF recommended). Override core fonts in `fonts_core/` and plugin fonts in `fonts_plugins/plugintype_pluginname/`. In CSS:

```css
@font-face {
    font-family: goodDogFont;
    src: url([[font:theme|good_dog.woff]]);
}
```

(`[[font:mod_book|3dumb.woff]]` references `/mod/book/fonts/3dumb.woff`.)

## Settings

A theme may ship a `settings.php` like any plugin (standard admin settings file); define lang strings for each form control and for information about the theme. The `configtitle` string titles the settings page. A common pattern (as in Boost) is exposing SCSS-affecting settings and injecting their values via `prescsscallback` / `extrascsscallback`.

## CSS caching

Outside theme designer mode, compiled CSS is cached at:

```
<moodledata>/localcache/theme/<global_theme_revision>/<theme_name>/css/all_<theme subrevision>.css
```

The path uses the global `themerev` config and the per-theme `themesubrev`; incrementing either regenerates the file. Build a theme's CSS cache from the CLI:

```bash
php admin/cli/build_theme_css.php --themes boost
```
