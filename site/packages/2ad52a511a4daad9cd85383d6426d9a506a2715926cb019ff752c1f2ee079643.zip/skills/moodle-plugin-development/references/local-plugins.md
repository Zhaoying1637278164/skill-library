# Local plugins (Moodle 4.5)

Reference for `local` plugins: when to use them, how they differ from standard plugin types, and common extension patterns (navigation hooks, admin settings).

## Purpose: when to choose local vs other types

The recommended way to add functionality to Moodle is a standard plugin type (activity, block, authentication, enrol, ...). The `local` plugin type is for things that do not fit any standard type. Typical cases:

- event consumers communicating with external systems
- custom definitions of web services and external functions
- applications that extend Moodle at the system level (for example hub server, amos server)
- custom admin settings
- extending the navigation block with custom menus
- new database tables used in core hacks (**strongly discouraged**)
- new capability definitions used in core hacks (**strongly discouraged**)

## Differences from standard plugins

- Always executed **last** during install and upgrade (guaranteed by their order in `get_plugin_types()`).
- Expected to use event handlers — event subscriptions are intended for core-to-plugin communication, making local plugins the ideal candidate.
- Can add admin settings to **any** settings page; they are loaded last when constructing the admin tree to enable this.
- Do not need any UI (other plugin types are usually visible somewhere in the interface).

## File structure

Local plugins live in `/local/pluginname/` and support the standard plugin files used by other plugin types (`version.php`, `lang/en/local_pluginname.php`, `lib.php`, `settings.php`, `db/`, etc.). No files beyond the common ones are specific to this type.

## Examples

### Adding an element to the settings menu

Define `local_[pluginname]_extend_settings_navigation` in the plugin's `lib.php`. It is called when Moodle builds the settings block.

```php
function local_[pluginname]_extend_settings_navigation($settingsnav, $context) {
    global $CFG, $PAGE;

    // Only add this settings item on non-site course pages.
    if (!$PAGE->course or $PAGE->course->id == 1) {
        return;
    }

    // Only let users with the appropriate capability see this settings item.
    if (!has_capability('moodle/backup:backupcourse', context_course::instance($PAGE->course->id))) {
        return;
    }

    if ($settingnode = $settingsnav->find('courseadmin', navigation_node::TYPE_COURSE)) {
        $strfoo = get_string('foo', 'local_[pluginname]');
        $url = new moodle_url('/local/[pluginname]/foo.php', array('id' => $PAGE->course->id));
        $foonode = navigation_node::create(
            $strfoo,
            $url,
            navigation_node::NODETYPE_LEAF,
            '[pluginname]',
            '[pluginname]',
            new pix_icon('t/addcontact', $strfoo)
        );
        if ($PAGE->url->compare($url, URL_MATCH_BASE)) {
            $foonode->make_active();
        }
        $settingnode->add_node($foonode);
    }
}
```

### Modifying the navigation menu

`local_[pluginname]_extend_navigation()` in `lib.php` can modify existing navigation components. Example removing the "Site Home" link:

```php
function local_[pluginname]_extend_navigation(global_navigation $navigation) {
    if ($home = $navigation->find('home', global_navigation::TYPE_SETTING)) {
        $home->remove();
    }
}
```

### Adding site-wide settings

In `settings.php`. Note: unlike most plugin types, `$settings` is **not** pre-defined for local plugins (it is null), so create the settings page yourself:

```php
// Ensure the configurations for this site are set.
if ($hassiteconfig) {

    // Create the new settings page
    // - in a local plugin this is not defined as standard, so normal $settings->methods will throw an error as
    // $settings will be null.
    $settings = new admin_settingpage('local_[pluginname]', 'Your Settings Page Title');

    $ADMIN->add('localplugins', $settings);

    // Add a setting field to the settings for this page.
    $settings->add(new admin_setting_configtext(
        // This is the reference you will use to your configuration.
        'local_[pluginname]/apikey',
        // This is the friendly title for the config, which will be displayed.
        'External API: Key',
        // This is helper text for this config field.
        'This is the key used to access the External API',
        // This is the default value.
        'No Key Defined',
        // This is the type of Parameter this config is.
        PARAM_TEXT
    ));
}
```

Read the value back with `get_config('local_[pluginname]', 'apikey')`.
