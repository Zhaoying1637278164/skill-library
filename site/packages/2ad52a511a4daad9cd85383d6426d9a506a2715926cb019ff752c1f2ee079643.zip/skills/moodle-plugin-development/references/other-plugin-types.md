# Moodle 4.5 Plugin Types Reference

Breadth reference: the complete Moodle 4.5 plugin type catalogue, plus quick-start notes for less common types. Depth for major types (mod, block, qtype, etc.) lives in sibling reference files.

## Naming rules

Machine names must match `/^[a-z](?:[a-z0-9_](?!__))*[a-z0-9]+$/` — start with a lowercase letter; lowercase letters, digits, underscores only; no hyphens; end with a letter or digit. Exception: activity modules (`mod`) may not contain underscores. Validation: `core_component::is_valid_plugin_name()`. Invalid names are silently ignored.

## All plugin types (Moodle 4.5)

| Plugin type | Frankenstyle prefix | Path | Purpose |
| --- | --- | --- | --- |
| Activity modules | mod | /mod | Course activities (Forum, Quiz, Assignment) |
| Antivirus plugins | antivirus | /lib/antivirus | Virus-scan uploaded files via third-party tools (e.g. ClamAV) |
| Assignment submission | assignsubmission | /mod/assign/submission | Different forms of assignment submissions |
| Assignment feedback | assignfeedback | /mod/assign/feedback | Different forms of assignment feedback |
| Book tools | booktool | /mod/book/tool | Tools for the Book activity |
| Custom fields | customfield | /customfield/field | Custom field types (used in custom course fields) |
| Database fields | datafield | /mod/data/field | Data types for the Database activity |
| Database presets | datapreset | /mod/data/preset | Pre-defined templates for the Database activity |
| LTI sources | ltisource | /mod/lti/source | Custom handlers to process LTI messages |
| File converters | fileconverter | /files/converter | Conversion between file types (e.g. .doc to PDF) |
| LTI services | ltiservice | /mod/lti/service | Implement IMS LTI services |
| ML backends | mlbackend | /lib/mlbackend | Prediction processors for the Analytics API |
| Forum reports | forumreport | /mod/forum/report | Reports in the forum activity |
| Quiz reports | quiz | /mod/quiz/report | Analyse quiz results / extend quiz behaviour |
| Quiz access rules | quizaccess | /mod/quiz/accessrule | Conditions on when/where quizzes can be attempted |
| SCORM reports | scormreport | /mod/scorm/report | Analysis of SCORM attempts |
| Workshop grading strategies | workshopform | /mod/workshop/form | Grading form type and submission grade calculation |
| Workshop allocation | workshopallocation | /mod/workshop/allocation | How submissions are assigned for assessment |
| Workshop evaluation | workshopeval | /mod/workshop/eval | Grading-grade calculation for assessments |
| Blocks | block | /blocks | Movable information displays/tools on pages |
| Question types | qtype | /question/type | Question types (multiple-choice, drag-and-drop, ...) |
| Question behaviours | qbehaviour | /question/behaviour | How students interact with questions during attempts |
| Question formats | qformat | /question/format | Import/export question definitions |
| Text filters | filter | /filter | Automatically convert/highlight posted text |
| Editors | editor | /lib/editor | Alternative text editors |
| Atto plugins | atto | /lib/editor/atto/plugins | Extra functionality for the Atto editor |
| Enrolment plugins | enrol | /enrol | Control who is enrolled in courses |
| Authentication plugins | auth | /auth | External authentication sources |
| Admin tools | tool | /admin/tool | Site administration/maintenance utilities |
| Log stores | logstore | /admin/tool/log/store | Event log storage back-ends |
| Availability conditions | availability | /availability/condition | Restrict access to activities and sections |
| Calendar types | calendartype | /calendar/type | How dates are displayed |
| Messaging consumers | message | /message/output | Targets for messages/notifications (email, sms, ...) |
| Course formats | format | /course/format | Course layout of activities and blocks |
| Data formats | dataformat | /dataformat | Data export/download formats |
| User profile fields | profilefield | /user/profile/field | New data types for user profiles |
| Reports | report | /report | Site-wide data views for admins and teachers |
| Course reports | coursereport | /course/report | Legacy (up to 2.1; use `report` since 2.2) |
| Gradebook export | gradeexport | /grade/export | Export grades in various formats |
| Gradebook import | gradeimport | /grade/import | Import grades in various formats |
| Gradebook reports | gradereport | /grade/report | Display/edit grades in various layouts |
| Advanced grading | gradingform | /grade/grading/form | Grading interfaces (e.g. rubrics) |
| MNet services | mnetservice | /mnet/service | Remote services for MNet (deprecated) |
| Webservice protocols | webservice | /webservice | Web service protocols (SOAP, REST, ...) |
| Repository plugins | repository | /repository | Connect to external file sources |
| Portfolio plugins | portfolio | /portfolio | External portfolio destinations |
| Search engines | search | /search/engine | Search engine back-ends for global search |
| Media players | media | /media/player | Pluggable media players |
| Plagiarism plugins | plagiarism | /plagiarism | External services to process submitted content |
| Cache stores | cachestore | /cache/stores | Cache storage back-ends |
| Cache locks | cachelock | /cache/locks | Cache lock implementations |
| Themes | theme | /theme | Change look via HTML/CSS |
| Local plugins | local | /local | Generic local customisations |
| Content bank types | contenttype | /contentbank/contenttype | Content types for the content bank |
| H5P libraries | h5plib | /h5p/h5plib | Versions of the H5P integration library |
| Question bank plugins | qbank | /question/bank | Extend question bank functionality |
| AI providers | aiprovider | /ai/provider | Interface between AI subsystem and external AI services |
| AI placements | aiplacement | /ai/placement | UX/UI for AI-backed functionality |
| Communication providers | communication | /communication/provider | Communication rooms (chat) for courses/instances |
| SMS gateways | smsgateway | /sms/gateway | SMS sending back-ends (4.5+) |
| TinyMCE plugins | tiny | /lib/editor/tiny/plugins | Subplugins for the TinyMCE editor |

Note: to list the exact types known to a site, use `core_plugin_manager::instance()->get_plugin_types()`.

## AI providers (`aiprovider_*`) — /ai/provider

- Provider class extends `\core_ai\provider`. Golden rule: Providers and Placements never know about each other; all communication goes through the Manager (`core_ai\manager`).
- Required methods:
  - `get_action_list(): array` — supported action classes, e.g. `\core_ai\aiactions\generate_text::class`, `generate_image::class`, `summarise_text::class`.
  - `is_provider_configured(): bool` — e.g. check API key/endpoint set; defaults to `false`.
- For each supported action, implement a `process_<action>` class (e.g. `process_generate_image`) extending `\core_ai\process_base`, with a `process()` method that calls the external API and returns an Action Response object. Recommended: a shared `abstract_processor` extending `process_base`.
- `settings.php`: use `core_ai\admin\admin_settingspage_provider` for the settings page.
- Rate limiting recommended: implement `is_request_allowed(aiactions\base $action): array|bool` using `\core\di::get(\core_ai\rate_limiter::class)` (`check_user_rate_limit()`, `check_global_rate_limit()`); return `['success' => false, 'errorcode' => 429, ...]` on limit.
- Core examples: `aiprovider_openai`, `aiprovider_azureai`.

## AI placements (`aiplacement_*`) — /ai/placement

- Placement class extends `\core_ai\placement`; must implement `get_action_list(): array`.
- Placements own access control: define capabilities in `db/access.php` (e.g. `aiplacement/editor:generate_image`); Providers never check access.
- Workflow: instantiate an action (`new \core_ai\aiactions\generate_image(contextid:, userid:, prompttext:, ...)`), then `$manager = \core\di::get(\core_ai\manager::class); $response = $manager->process_action($action);` — response is a `responses\response_base` instance; the placement checks success/failure.
- Typical files: `classes/placement.php`, `classes/external/*` (web services), `db/access.php`, `db/services.php`, `settings.php` (also uses `admin_settingspage_provider`).
- Core examples: `aiplacement_courseassist`, `aiplacement_editor`.

## Antivirus (`antivirus_*`) — /lib/antivirus

- `classes/scanner.php`: class `scanner` in the plugin namespace, extends `\core\antivirus\scanner`.
- Compulsory methods:
  - `is_configured(): bool`
  - `scan_file($file, $filename, $deleteinfected): void` — must throw `\core\antivirus\scanner_exception` if a virus is found.
- Other files: `version.php`, `settings.php` (e.g. `admin_setting_configexecutable` for scanner path), `lang/en/antivirus_<name>.php`.
- Test with doubles for the external scanner (see `antivirus_clamav` unit tests).

## Availability conditions (`availability_*`) — /availability/condition

- `classes/condition.php`: extends `\core_availability\condition`. Key methods:
  - `__construct($structure)` — restore from JSON structure stored in DB
  - `save()` — return plain object, e.g. `(object)['type' => 'name', 'allow' => $this->allow]`
  - `is_available($not, \core_availability\info $info, $grabthelot, $userid)` — the access decision; honour `$not`
  - `get_description($full, $not, \core_availability\info $info)` — text shown on editing screens
  - `get_debug_string()` — short dev representation
  - For "permanent" conditions (like groups), also implement `is_applied_to_user_lists()` and `filter_user_list()`.
- `classes/frontend.php`: extends `\core_availability\frontend`; optional overrides `get_javascript_strings()`, `get_javascript_init_params($course, $cm, $section)`, `allow_add($course, $cm, $section)`.
- The editing-form UI must be a YUI module (`yui/src/form/`) registering `M.availability_<name>.form` from `Y.Object(M.core_availability.plugin)` with `initInner`, `getNode(json)`, `fillValue(value, node)`, optional `fillErrors(errors, node)`; call `M.core_availability.form.update()` on change. Depends on `moodle-core_availability-form`.
- Good starting example: `availability_grouping` in `/availability/condition/grouping`.

## Communication providers (`communication_*`) — /communication/provider

- Single required class `communication_feature` (exact name) in `classes/communication_feature.php`, implementing interfaces for supported features:
  - `\core_communication\communication_provider` (mandatory): `load_for_instance()` — factory from a `core_communication\processor`.
  - `user_provider`: `create_members()`.
  - `room_chat_provider`: `create_chat_room()`, `update_chat_room()`, `delete_chat_room()` (all return bool), `generate_room_url()`.
  - `room_user_provider`: `add_members_to_room()`, `update_room_membership()`, `remove_members_from_room()` (arrays of user ids).
  - `synchronise_provider`: `synchronise_room_members()` — used by scheduled task `core_communication\task\synchronise_providers_task`.
- Changes are applied asynchronously via scheduled/ad-hoc tasks. Real example: `communication_matrix`.
- Docs marked as draft.

## Custom fields (`customfield_*`) — /customfield/field

- Two controller classes required:
  - `classes/field_controller.php`: `field_controller` extending `\core_customfield\field_controller`. Minimum: `TYPE` constant (= plugin name) and `config_form_definition()`. Optional: `config_form_validation($formdata, $formfiles)`. Config form element names must be `configdata[configname]`.
  - `classes/data_controller.php`: `data_controller` extending `\core_customfield\data_controller`. Minimum: `datafield(): string` and `instance_form_definition()`.
- `datafield()` returns which DB column stores the value: `intvalue` (indexed int), `decvalue` (decimal), `shortcharvalue` (255 chars, indexed), `charvalue` (1333 chars, not indexed), `value` (unlimited text).
- Minimal file set: the two controllers, `classes/privacy/provider.php`, `lang/en/customfield_<name>.php`, `version.php`. Core example: `customfield_checkbox`.

## File converters (`fileconverter_*`) — /files/converter

- `classes/converter.php`: class `converter` implementing `\core_files\converter_interface`. Key methods (static unless noted):
  - `are_requirements_met()` — lightweight availability check (e.g. `extension_loaded(...)`)
  - `start_document_conversion()` / `poll_conversion_status()` — set `\core_files\conversion::STATUS_IN_PROGRESS` (and update the record) on start; on failure set `STATUS_FAILED` and return; on success set `STATUS_COMPLETE` and store the result via `store_destfile_from_string()` or `store_destfile_from_path()`
  - `supports($from, $to)` — whether conversion between two formats is supported
  - `get_supported_conversion()` — informational, for the admin UI
- Files: `classes/converter.php`, `settings.php`, `lang/`, `version.php`. Core example: `fileconverter_unoconv`.

## Log stores (`logstore_*`) — /admin/tool/log/store

- Custom event log storage back-ends. The 4.5 dev docs page is a stub ("hasn't been documented yet") — use core plugins `logstore_standard` / `logstore_database` as reference.

## TinyMCE plugins (`tiny_*`) — /lib/editor/tiny/plugins

- TinyMCE is the standard editor from Moodle 4.1. Subplugin JS lives in `amd/src/` (compile with `grunt`), conventionally split into:
  - `plugin.js` — entrypoint; default export is a `Promise` that awaits `getTinyMCE()` (from `editor_tiny/loader`), `getPluginMetadata(component, pluginName)` and setup, then calls `tinyMCE.PluginManager.add(pluginName, (editor) => {...})` and `resolve([pluginName, Configuration])`. All async work must finish before `PluginManager.add` — it is synchronous.
  - `commands.js` — `getSetup()` async function returning a per-editor-instance setup function that calls `editor.ui.registry.addIcon/addButton/addToggleButton/addMenuItem/addToggleMenuItem`.
  - `options.js` — register/parse per-instance options; `common.js` — shared constants (component, button/menu names).
- `classes/plugininfo.php`: `plugininfo extends \editor_tiny\plugin`; optionally implements `\editor_tiny\plugin_with_configuration` with `get_plugin_configuration_for_context(context $context, array $options, array $fpoptions, ?\editor_tiny\editor $editor = null): array` to pass PHP values to the JS options.
- Recommended: generate the skeleton with `tool_pluginskel` (`php admin/tool/pluginskel/cli/generate.php tiny_example.yml`), then `grunt` to build AMD.

## Atto plugins (`atto_*`) — /lib/editor/atto/plugins

- Legacy: Atto was replaced by TinyMCE in 4.1 and removed in Moodle 5.0. Buttons are YUI modules.
- The plugin must register a class at `Y.M.atto_PLUGINNAME.button` (in `yui/src/button/`), provide a constructor, and should extend `Y.M.editor_atto.EditorPlugin`.
- Useful `EditorPlugin` methods: `addBasicButton` (document.execCommand-based), `addButton` (custom callback), `addToolbarMenu`, `markUpdated` (call after changing content), `getDialogue`.
- Files: `version.php`, optional `lib.php` and `settings.php`, `lang/en/atto_<name>.php`.

## SMS gateways (`smsgateway_*`) — /sms/gateway (new in 4.5)

- `classes/gateway.php`: class `gateway` extends `\core_sms\gateway`. Key methods:
  - `send(message $message): message` — send via external service, return `$message->with(status: $status)`
  - `get_send_priority(message $message): int`
- `classes/hook_listener.php` + `db/hooks.php`: listen to `after_sms_gateway_form_hook` to add gateway-specific config fields to the settings form (guard with `if ($hook->plugin !== 'smsgateway_<name>') return;`).
- Used by e.g. MFA for SMS verification. Production example: `smsgateway_aws`.

## Assignment subplugins (`assignsubmission_*`, `assignfeedback_*`)

- `mod_assign` has two subplugin types: submission (`/mod/assign/submission`) and feedback (`/mod/assign/feedback`). Main class lives in `locallib.php`.
- Naming/table limits: table names max 53 chars (28 pre-4.3); plugin name max 36 chars for `assignsubmission_`, 38 for `assignfeedback_` prefixes.
- Both extend `assign_plugin` (base for both kinds; gives `$this->assignment`, plus `get_config()`/`set_config()` for per-instance settings).
- Submission plugins: class extends `assign_submission_plugin`. Key methods:
  - `get_name()` (abstract, required), `get_settings(MoodleQuickForm $mform)` / `save_settings()` (assignment settings form)
  - `get_form_elements()` (student submission form), `save(stdClass $submission, stdClass $data)`
  - `is_empty(stdClass $submission)`, `submission_is_empty()` (pre-save check), `get_files()`, `get_file_areas()`
  - `view_summary()`, `view()`, `copy_submission()`, `format_for_log()`, `delete_instance()`
  - Upgrade path from old Assignment 2.2: `can_upgrade()`, `upgrade_settings()`, `upgrade()`
  - `settings.php` should include a `default` setting (enabled by default on new assignments). Reference implementation: `assignsubmission_onlinetext`.
- Feedback plugins: class extends `assign_feedback_plugin`. Key methods:
  - `get_name()` (required), `get_settings()` / `save_settings()`
  - `get_form_elements_for_user($grade, MoodleQuickForm $mform, stdClass $data, $userid)` — return true if the form was modified
  - `is_feedback_modified(stdClass $grade, stdClass $data)` (defaults true; `save()` skipped when false), `save(stdClass $grade, stdClass $data)`
  - `view_summary()`, `view()`, `is_empty()`, `get_file_areas()`, `delete_instance()`
  - Gradebook: `format_for_gradebook(stdClass $grade)`, `text_for_gradebook(stdClass $grade)` (only one feedback plugin pushes comments to the gradebook); quick grading: `supports_quickgrading()`, `get_quickgrading_html($userid, $grade)`. Reference implementation: `assignfeedback_file`.

## Machine learning backends (`mlbackend_*`) — /lib/mlbackend

- Process datasets from the Analytics API for training, prediction, and model evaluation. Communication with Moodle is file-based (processors may be PHP, Python, other languages, or cloud services) and must scale to big files/batch reading.
- Main class: `classes/processor.php`. Interfaces:
  - **Predictor** (base, required): `is_ready()`, `clear_model($uniqueid, $modelversionoutputdir)`, `delete_output_dir($modeloutputdir, $uniqueid)`
  - **Classifier** (extends Predictor): `train_classification($uniqueid, \stored_file $dataset, $outputdir)`, `classify($uniqueid, \stored_file $dataset, $outputdir)`, `evaluate_classification($uniqueid, $maxdeviation, $niterations, \stored_file $dataset, $outputdir)`
  - **Regressor** (extends Predictor; not implemented by core backends): `train_regression()`, `estimate()`, `evaluate_regression()` (same signature style)
- Core backends: `mlbackend_php` (logistic regression, no dependencies) and `mlbackend_python` (TensorFlow feed-forward NN; requires the `moodlemlbackend` pip package; recommended — faster and more accurate).
