# Moodle 4.5 Course Format Plugins

Scope: structure, `core_courseformat\base` class, output classes/templates, section and activity rendering, format options, and course editor integration for `format_*` plugins, per Moodle 4.5 developer docs.

Course formats determine the layout of `/course/view.php` in view and editing mode, build the course navigation tree (navigation block, course index, breadcrumb), organize content in sections, and can add options to the course edit form and content to the header/footer of any course page.

## File structure

All files live in `course/format/pluginname`:

```console
 course/format/pluginname/
 |-- classes
 |   `-- output
 |       `-- courseformat
 |           `-- (Overridden outputs)
 |       `-- renderer.php
 |-- db
 |   `-- access.php
 |-- lang
 |   `-- en
 |       `-- format_pluginname.php
 |-- format.php
 |-- lib.php
 `-- version.php
```

- `format.php` (required): renders the course; included from `course/view.php`.
- `lib.php` (required): must contain a class `format_pluginname` extending `core_courseformat\base` (the "format base class"). For compatibility, this class has no namespace and stays in `lib.php`.
- `classes/output/renderer.php` (required): unlike most plugins, all course formats must provide a renderer, namespaced `format_pluginname\output`, class named `renderer`, extending `core_courseformat\output\section_renderer`.
- `classes/output/courseformat/`: output classes placed here automatically override the core ones (since 4.0).
- `templates/` and `templates/local/`: plugin mustache templates.
- Format names cannot exceed 21 characters. Easiest scaffold: `tool_pluginskel` with `requires` >= 4.0; or copy the topics/weeks format.

## format.php

```php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/filelib.php');
require_once($CFG->libdir . '/completionlib.php');

// Retrieve course format option fields and add them to the $course object.
$format = core_courseformat\base::instance($course);
$course = $format->get_course();
$context = context_course::instance($course->id);

// Make sure section 0 is created.
course_create_sections_if_missing($course, 0);

$renderer = $format->get_renderer($PAGE);

if (!empty($displaysection)) {
    $format->set_section_number($displaysection);
}
// Output course content.
$outputclass = $format->get_output_classname('content');
$widget = new $outputclass($format);
echo $renderer->render($widget);
```

Output classes implement `named_templatable`, so they are passed straight to `$renderer->render()` (not `render_from_template`).

## Format base class (lib.php)

```php
class format_pluginname extends core_courseformat\base {
    public function uses_sections() {
        return true;
    }
    public function uses_indentation(): bool {
        return false;
    }
    public function uses_course_index() {
        return true;
    }
    public function supports_ajax() {
        $ajaxsupport = new stdClass();
        $ajaxsupport->capable = true;
        return $ajaxsupport;
    }
    public function supports_components() {
        return true;
    }
    public function can_delete_section($section) {
        return true;
    }
    public function supports_news() {
        return true;
    }
    public function get_section_name($section) {
        $section = $this->get_section($section);
        if ((string)$section->name !== '') {
            return format_string($section->name, true,
                ['context' => context_course::instance($this->courseid)]);
        }
        return $this->get_default_section_name($section);
    }
}

// Required for the inplace section name editor.
function format_pluginname_inplace_editable($itemtype, $itemid, $newvalue) {
    global $DB, $CFG;
    require_once($CFG->dirroot . '/course/lib.php');
    if ($itemtype === 'sectionname' || $itemtype === 'sectionnamenl') {
        $section = $DB->get_record_sql(
            'SELECT s.* FROM {course_sections} s JOIN {course} c ON s.course = c.id WHERE s.id = ? AND c.format = ?',
            [$itemid, 'pluginname'], MUST_EXIST);
        $format = core_courseformat\base::instance($section->course);
        return $format->inplace_editable_update_section_name($section, $itemtype, $newvalue);
    }
}
```

### Key overridable methods on `core_courseformat\base`

Sections: `uses_sections()`, `get_default_section_name()`, `get_section_name()` (use only fields cached in `section_info`), `get_view_url()`, `is_section_current()`, `get_section_highlighted_name()`, `set_section_number()` / `get_section_number()` (single-section display), `get_course_display()` (`COURSE_DISPLAY_SINGLEPAGE` / `COURSE_DISPLAY_MULTIPAGE`), `get_last_section_number()`, `get_max_sections()`, `page_title()`. Sections are stored in `course_sections`; section 0 always exists; any change to sections must be followed by `rebuild_course_cache()`. Always define `$string['sectionname']` even if the format does not use sections.

Course features: `ajax_section_move()`, `uses_course_index()` (course index drawer; Boost themes only, not classic), `uses_indentation()`, `supports_components()` (enables the reactive 4.x course editor), `supports_news()`, `get_default_blocks()` (admin can override via `$CFG->defaultblocks_override` / `$CFG->defaultblocks_pluginname`), `extend_course_navigation()`.

Helpers (usually not overridden): `get_course()` (course row + format options), `get_section()` (`section_info` + section options), `get_sections()`, `get_modinfo()`, `get_renderer()`, `get_output_classname()`, `show_editor()` (page editing mode + capabilities check; defaults to `moodle/course:manageactivities`, pass an array to check others).

### Course format options

Stored in the `course_format_options` table, for the course or per section. Option names must not clash with `course` / `course_sections` columns nor completion/conditional form fields. If old and new format share an option name, its value is copied on format change. Options are backed up as extra `course` fields — never store IDs of courses/sections in them (section numbers are safe; they are relative). Webservices pass options as additional entities, though `numsections`, `hiddensections` and `coursedisplay` are also accepted as course fields for backward compatibility.

Methods: `course_format_options()`, `section_format_options()` (cached with section info), `get_format_options()`, `create_edit_form_elements()` (default builds simple elements for each option), `edit_form_validation()`, `update_format_options()`, `update_course_format_options()`, `update_section_format_options()`, `editsection_form()`, `get_default_course_enddate()` (override for time-based formats), `delete_format_data()` (cleanup hook on course deletion).

## Renderer (classes/output/renderer.php)

```php
namespace format_pluginname\output;

use core_courseformat\base as format_base;
use core_courseformat\output\section_renderer;

class renderer extends section_renderer {
    // Required to enable the inplace section title editor.
    public function section_title($section, $course) {
        return $this->render(format_base::instance($course)->inplace_editable_render_section_name($section));
    }
    public function section_title_without_link($section, $course) {
        return $this->render(format_base::instance($course)->inplace_editable_render_section_name($section, false));
    }
}
```

Renderer methods used to refresh page fragments:

- `render_content`: full course (optional; the content output is used by default).
- `course_section_updated`: renders a single section (default: `core_courseformat\output\local\content\section`). Used mostly when a section is created.
- `course_section_updated_cm_item`: renders a full course module list item, not just the activity card (default: `core_courseformat\output\local\content\section\cmitem`).

## Output classes and templates

Rendering uses per-element output classes in `course/format/classes/output/local/` and mustache templates in `course/format/templates/`. `get_output_classname('content\\section')` resolves to the plugin override in `format_pluginname\output\courseformat\...` if it exists, else core. Example: to extend the section action menu, override `core_courseformat\output\local\content\section\controlmenu` with `format_pluginname\output\courseformat\content\section\controlmenu` (see `course/format/topics/classes/output/courseformat/content/section/controlmenu.php`).

Recommended minimum overrides — `content`, `content\section`, `content\section\cmitem` — each at least overriding `get_template_name()` (and optionally `export_for_template()`):

```php
// classes/output/courseformat/content.php
namespace format_pluginname\output\courseformat;
use core_courseformat\output\local\content as content_base;

class content extends content_base {
    public function get_template_name(\renderer_base $renderer): string {
        return 'format_pluginname/local/content';
    }
}
```

Equivalents: `format_pluginname\output\courseformat\content\section` extends `core_courseformat\output\local\content\section` returning `'format_pluginname/local/content/section'`; `...\content\section\cmitem` extends `...\content\section\cmitem` returning `'format_pluginname/local/content/section/cmitem'`.

### Minimum mustache structure

Mustache files cannot be extended, so core_courseformat templates include sub-templates via blocks (`{{$ path }}{{> path }}{{/ path }}`), which parents can replace, wrap, or fill with alternative HTML. Minimum three templates:

```handlebars
{{! templates/local/content.mustache }}
{{< core_courseformat/local/content }}
    {{$ core_courseformat/local/content/section }}
        {{> format_pluginname/local/content/section }}
    {{/ core_courseformat/local/content/section }}
{{/ core_courseformat/local/content }}
```

```handlebars
{{! templates/local/content/section.mustache }}
{{< core_courseformat/local/content/section }}
    {{$ core_courseformat/local/content/section/cmitem }}
        {{> format_pluginname/local/content/section/cmitem }}
    {{/ core_courseformat/local/content/section/cmitem }}
{{/ core_courseformat/local/content/section }}
```

```handlebars
{{! templates/local/content/section/cmitem.mustache }}
{{< core_courseformat/local/content/section/cmitem }}
    {{! Add any cm item blocks override here. }}
{{/ core_courseformat/local/content/section/cmitem }}
```

Override strategies: (1) small tweaks — put override blocks directly in the 3 main templates (fewer files, may need refactoring later); (2) big UI change — mirror the whole intermediate template chain with matching output classes per level (more files, stable long-term); (3) fully custom format — keep your own structure but add the data attributes below, implement `course_section_updated` / `course_section_updated_cm_item` on the renderer, and prefer `local/content` as the main template and `output\local\content` (or `render_content`) as the entry point.

## Course editor integration

The 4.x editor is reactive: state loaded via `core_courseformat_get_state`, mutations via the `core_courseformat_update_course` webservice, components registered on `core_courseformat/local/courseeditor` watch the state and update the UI. Enable it in your base class:

```php
public function supports_components() {
    return true;
}
```

The editor locates elements by data attributes (not CSS classes) — keep them in any altered template:

| Concept | Required data attributes |
|---------|------------------------|
| Section | `data-for="section"`, `data-id={SECTION.ID}`, `data-number={SECTION.NUM}` |
| Section header | `data-for="section_title"`, `data-id={SECTION.ID}`, `data-number={SECTION.NUM}` |
| Course module item | `data-for="cmitem"`, `data-id={CM.ID}` |
| Course sections list | `data-for="course_sectionlist"` |
| Section course modules list | `data-for="cmlist"` |
| Course module action link | `data-action={ACTIONNAME}`, `data-id={CM.ID}` |
| Section action link | `data-action={ACTIONNAME}`, `data-id={SECTION.ID}` |
| Section info | `data-for="sectioninfo"` |

If a custom content.mustache breaks editor initialization, add `id="{{uniqid}}-course-format"` to the content div and:

```handlebars
{{#js}}
require(['core_courseformat/local/content'], function(component) {
    component.init('{{uniqid}}-course-format', {}, {{sectionreturn}});
});
{{/js}}
```

Verify via developer debug footer > "Reactive instances" > CourseEditorXXXX > Highlight ON: registered elements get blue borders.

## Activity badge (since 4.3)

Activity modules (not formats) can show a plain-text badge near the activity name by implementing `mod_PLUGINNAME\output\courseformat\activitybadge` extending `core_courseformat\output\activitybadge`, overriding `update_content()` to set `content`, `style` (one of `self::STYLES`: none/dark/danger/warning/info), `url`, `elementid`, `extraattributes`. Rendered by the `core_courseformat/local/content/cm/activitybadge` template, which format plugins can override like any other.
