# Moodle 4.5 Workflow Guides

Distilled from the official Moodle 4.5 developer docs: Git workflow, the plugin Upgrade API, PHP profiling, Bootstrap 5 migration preparation, platform requirements, and the 4.5 developer update.

## Git workflow for Moodle developers

Moodle recommends the MDK (Moodle Developer Kit) tool to streamline Git-based development (`mdk update` keeps official remotes synced).

### General workflow

1. Commit changes to your personal (local) repository.
2. Push to your public repository (usually a GitHub fork of `moodle/moodle`) and publish links to your changes in the Moodle Tracker.
3. Request a peer review from another developer.
4. When the peer reviewer is happy, they submit the issue for integration.
5. Moodle integrators pull your changes and, if approved, merge them into Moodle's integration repository.
6. Integrated changes are tested and pushed to Moodle's production repository (moodle.git).
7. You synchronise your local repository with production and the cycle repeats.

The workflow runs in weekly cycles: integration Monday/Tuesday, testing Wednesday, production update Thursday (or Friday). New Tracker users cannot self-assign or send issues for peer review until their first fix is integrated — comment with a link to your branch instead.

### Setup

```bash
git config --global user.name "Your Name"        # real name, proper capitalisation
git config --global user.email yourmail@domain.tld
git config --global core.filemode false          # don't push file-permission changes
git config --global core.autocrlf false          # Moodle uses LF only
```

Fork `github.com/moodle/moodle`, set up your SSH key, then:

```bash
git clone git@github.com:YOUR_GITHUB_USERNAME/moodle.git
git remote add upstream git://git.moodle.org/moodle.git
```

Optionally enable GitHub Actions on your fork so your code is verified automatically before review.

### Syncing your fork

Never commit directly to `main` or `MOODLE_XXX_STABLE` branches — they must stay fast-forwardable. Sync weekly (upstream updates roughly once a week; safe to cron):

```bash
git fetch upstream
for BRANCH in MOODLE_{19..39}_STABLE MOODLE_{310..311}_STABLE MOODLE_{400..405}_STABLE main; do
    git push origin refs/remotes/upstream/$BRANCH:refs/heads/$BRANCH
done
```

If Moodle creates a new stable branch your fork lacks, `git checkout MOODLE_XX_STABLE && git push origin MOODLE_XX_STABLE:MOODLE_XX_STABLE` (then optionally delete the local copy).

### Preparing and submitting a patch

Always work on a topic branch forked off the standard branch it should merge into — stable fixes off `MOODLE_XXX_STABLE` (e.g. `MOODLE_405_STABLE` for a 4.5 fix), new features for the next major version off `main`:

```bash
git checkout -b MDL-xxxxx-main_brief_name origin/main
# ... work ...
git add .
git commit -m "MDL-XXXXX component: Brief description"   # follow coding-style commit rules
git push origin MDL-xxxxx-main_brief_name
```

To fix commits after CI (CiBot) feedback, either `git reset --mixed origin/main` and re-commit, or `git rebase --interactive`, then force-push: `git push -f origin MDL-xxxxx-main_brief_name`.

### Rebasing

You may be asked to rebase if your branch is based on an outdated commit: `git rebase main MDL-xxxxx-main_topic_branch`. Rebasing rewrites history — never rebase a branch others may have based work on, and never base your branches on branches submitted for integration (they are potentially rebased). On conflicts: fix files, `git add`, `git rebase --continue`.

### Applying a fix to multiple branches

Stable branches are maintained separately from `main` and never merged into it; contributors typically prepare one branch per affected stable branch plus one for `main`.

Cherry-pick a single commit into another checkout:

```bash
cd ~/public_html/moodle_main
git checkout -b MDL-xxxxx-main_topic origin/main
git fetch ../moodle_400 MDL-xxxxx-400_topic
git cherry-pick FETCH_HEAD        # or: git cherry-pick A^..B for a range
```

For multiple commits, export and re-apply with three-way merge fallback:

```bash
git format-patch -o .patches MOODLE_400_STABLE..MDL-xxxxx-400_topic
git am -3 ../moodle_400/.patches/*    # git am --continue / --abort on conflicts
```

### Reviewing someone else's branch

```bash
git fetch git://github.com/alice/moodle.git wip-feature
git log -p FETCH_HEAD                     # inspect
git checkout -b alice-wip-feature FETCH_HEAD   # or git merge FETCH_HEAD
git diff ...FETCH_HEAD                    # preview merge without changing anything
```

### Housekeeping

List merged (safe-to-delete) branches with `git branch --merged upstream/main` (add `-r` for remote-tracking). Delete local: `git branch -d NAME`; delete on origin: `git push origin :NAME`.

## Plugin upgrades (Upgrade API)

The Upgrade API lets a plugin manage its own installation and upgrades. Plugins can only be upgraded, never downgraded.

### Key files

- `version.php` — plugin version. Bump it after any change to `db/`, JavaScript, new autoloaded classes, new settings, or language packs: a new version triggers the upgrade procedure and resets all caches.
- `db/install.xml` — database tables created on initial installation only. Must always describe the up-to-date structure. Must be created/maintained with the XMLDB Editor.
- `db/upgrade.php` — steps to migrate from an older installed version. Database field definitions here must also come from the XMLDB Editor.
- `db/upgradelib.php` (optional) — helper functions for non-trivial upgrade steps; these can be unit-tested.

### How it works

On first install (version.php exists on disk, no version row in `config_plugins`), Moodle uses `install.xml`. On upgrade (disk version newer than the stored one), Moodle runs `xmldb_[plugintype]_[pluginname]_upgrade($oldversion)` in `db/upgrade.php`:

```php
function xmldb_[plugintype]_[pluginname]_upgrade($oldversion): bool {
    global $CFG, $DB;
    $dbman = $DB->get_manager(); // DDL manager and xmldb classes.

    if ($oldversion < 2019031200) {
        // Perform the upgrade step, then mark the savepoint:
        // upgrade_plugin_savepoint(true, 2019031200, 'plugintype', 'pluginname');
    }
    return true;
}
```

Helpers callable from upgrade.php:

- `upgrade_set_timeout()` — increase timeout before a long-running step.
- `upgrade_(main|mod|block|plugin)_savepoint()` — mark a step completed (runs once only) and reset timeouts.

Related: `xmldb_..._install()` in `db/install.php`, `xmldb_..._uninstall()` in `db/uninstall.php` (use `main` for core, frankenstyle name for plugins, e.g. `xmldb_block_example_install()`).

### Upgrade code restrictions

- Upgrade code may always use the basic DML database API.
- Plugin upgrade code must not call any of the plugin's own functions (plugin data is still old) — manipulate the database directly instead. Calling core functions is allowed (core data is already current, since core upgrades first).
- Core upgrade code must not call core functions either (both core and plugin data are old), except functions explicitly marked safe such as `set_config`/`get_config`.

### Delaying upgrade work

When a step needs structures not yet present, needs operations unavailable during upgrade (e.g. course cache rebuild throws), or is long-running, queue an ad-hoc task instead:

```php
if ($oldversion < 2020031001) {
    $task = new \plugintype_pluginname\task\migrate_course_completion();
    \core\task\manager::queue_adhoc_task($task, true);
    upgrade_plugin_savepoint(true, 2020031001, 'plugintype', 'pluginname');
}
```

### Core stable-branch DB changes (advanced, rare)

Because users can upgrade via different paths (stable-to-stable, stable-to-next-major), any DB change made on a stable branch must be idempotent, e.g. `if (!$dbman->table_exists($table)) { $dbman->create_table($table); }` instead of an unconditional `create_table`. Choose version numbers on each branch carefully and test all upgrade paths.

## Profiling PHP

Two profiler families:

- **XHProf** — function-level hierarchical profiler (C extension), suitable for production. Reports inclusive/exclusive wall time, memory, CPU, call counts; supports run comparison and aggregation. Built into Moodle.
- **Xdebug** — profiler outputting cachegrind files; not recommended for production.

### XHProf in Moodle

With an xhprof extension installed, a "Profiling" option appears under Site administration > Development. Enable "Enable profiling" and specify paths to profile, relative to the Moodle directory (wildcards allowed, e.g. `mod/*/view.php`). Visit the pages, then view runs under Site administration > Development > Profiling runs, as a data table or a callgraph (callgraph requires Graphviz and `pathtodot` configured). Runs on the same page can be compared.

Since 3.6 (MDL-63031), a plugin can handle XHProf data instead of the database: set `$CFG->disableprofilingtodatabase = false;` in config.php and provide a `store_profiling_data` function.

### Xdebug profiler

Install the Xdebug 3 extension (typically via pecl), restart the webserver, then in php.ini:

```ini
xdebug.mode = profile
xdebug.start_with_request = trigger    ; omit to profile every request
xdebug.trigger_value = ProfileMe       ; optional: require a specific value
```

With trigger mode, append `XDEBUG_PROFILE` to the URL (e.g. `...view.php?id=5&XDEBUG_PROFILE=ProfileMe`); the trigger variable is checked in `$_ENV`, `$_GET`, `$_POST`, and cookies (browser extensions can set the cookie for POST/AJAX profiling). Output goes to `xdebug.output_dir` as `cachegrind.out.*` files; analyse with KCachegrind, WinCacheGrind, xdebugtoolkit, or Webgrind.

## Bootstrap 5 migration preparation

Moodle is migrating from Bootstrap 4 to 5 gradually. Steps: (1) PopperJS v2 upgrade (v1 and v2 co-exist until BS4 usages are migrated), (2) SCSS deprecation process, (3) refactoring BS4 features dropped in BS5, (4) a BS5 "bridge", (5) the BS5 upgrade itself, (6) a BS4 backwards-compatibility layer so third-party plugins can update gradually, (7) final deprecation. Steps 1–3 landed in Moodle 4.4; the bridge (MDL-79917) landed in 4.5.

### Refactors to apply now (BS4 features dropped in BS5) — since 4.4

- **Badges**: `.badge-*` colour classes → background utilities plus a text colour for contrast (`.badge-danger` → `.bg-danger .text-white`); `.badge-pill` → `.rounded-pill`.
- **Media component**: `.media`/`.media-left`/`.media-body` → utility classes: `.d-flex` with `.flex-shrink-0` and `.flex-grow-1 ml-3`.
- **Forms**: `.form-group` → margin utilities (e.g. `.mb-3`); `.form-inline` → `.d-flex .flex-wrap .align-items-center`.
- **Card decks**: `.card-deck` → grid utilities (`.row .row-cols-1 .row-cols-sm-2` with `.col` wrappers).
- **Dropped SCSS mixins** (replace with plain CSS): `hover`, `hover-focus`, `plain-hover-focus`, `hover-focus-active`, `float-left/right/none`, `nav-divider`, `img-retina`, `text-hide`, `invisible`, `form-control-focus`, `text-emphasis-variant`, `size`, `make-container-max-widths`, `g-variant`, `bg-gradient-variant`. E.g. `@include hover-focus() { ... }` → `&:hover, &:focus { ... }`.

### The BS5 bridge — since 4.5

`theme/boost/scss/moodle/bs5-bridge.scss` makes BS5 syntax work now (e.g. `.g-0 { @extend .no-gutters; }`), so code can adopt BS5 names in advance:

- `.no-gutters` → `.g-0`
- `.close` → `.btn-close`
- Directional → logical utility names: `.float-left/.float-right` → `.float-start/.float-end`; `.border-left/right` → `.border-start/end`; `.rounded-left/right` → `.rounded-start/end`; `.ml-*/.mr-*` → `.ms-*/.me-*`; `.pl-*/.pr-*` → `.ps-*/.pe-*`; `.text-left/right` → `.text-start/end`.
- SCSS function `theme-color-level($name, $level)` (removed in BS5) → `shift-color($color, $weight)`: use the colour variable instead of the name, and percentages instead of levels — each level ≈ 10% (`theme-color-level('primary', 1)` → `shift-color($primary, 10%)`; `-2` → `-20%`).

## Platform requirements

Moodle is a PHP application backed by a relational database. Required PHP extensions: iconv, mbstring, curl, openssl, ctype, zip, zlib, simplexml, spl, pcre, dom, xml, xmlreader, intl, json, hash, fileinfo.

Supported databases (with required PHP extension): MariaDB 10.2.29+ (mysqli), MySQL 5.7+ (mysqli), PostgreSQL 10+ (pgsql), Microsoft SQL Server 14.0+ (sqlsrv), Oracle 11.2+ (oci8).

Note: the requirements page bundled with the 4.5 docs is stale — it still says "Moodle 4.0 supports PHP 7.3/7.4/8.0" and lists 4.0-era database minimums. For the actual 4.5 minimums (PHP 8.1–8.3 and raised DB versions), consult the Moodle 4.5 release notes, which the docs point to as authoritative.

## Moodle 4.5 developer update highlights

### Badges

- `badges/newbadge.php` deprecated (MDL-43938), removed in Moodle 6.0 — use `badges/edit.php` (`newbadge.php?id=x` redirects to `edit.php?courseid=x&mode=new`).
- `badges/view.php` deprecated (MDL-82503), removed in 6.0 — use `badges/index.php`. The `course_badges` system report is merged into (and deprecated in favour of) the `badges` system report.

### Core

- **Autoloader with `ABORT_AFTER_CONFIG`** (MDL-80275): the class autoloader is now available to scripts using `ABORT_AFTER_CONFIG` (DB/session limitations still apply).
- **Legacy class autoloading** (MDL-81919): the autoloader can load legacy (non-namespaced) classes declared in `db/legacyclasses.php` (one class per file), e.g. `\moodle_exception::class => 'exception/moodle_exception.php'`.
- **SMS API**: new subsystem introduced.

### Course reset page

"Delete"/"Remove" words were removed from reset options. Plugins implementing reset should add a static "Delete" heading element before their options in `_reset_course_form_definition` (`$mform->addElement('static', 'assigndelete', get_string('delete'));`) and strip Delete/Remove from their reset strings.

### Deprecations and filters

- **Icon deprecation** (MDL-82212): new mechanism for deprecating icons.
- **Filter plugins** (MDL-82427): filters now use standard class autoloading. Move `filter_[pluginname]` from `filter/[pluginname]/filter.php` to `classes/text_filter.php` with namespace `filter_[pluginname]` and class name `text_filter`. To also support 4.4 and earlier, keep `filter.php` containing only: `class_alias(\filter_[pluginname]\text_filter::class, \filter_[pluginname]::class);`

### TinyMCE

Editor plugins no longer need the `helplinktext` language string; `pluginname` is used in the help dialogue.

### Theme

- **Context header** (MDL-82160): `core_renderer::render_context_header($contextheader)` deprecated — use `core_renderer::render($contextheader)`. Themes can still customise it by overriding `context_header()`, adding a `render_context_header()` method to their `core_renderer`, or overriding the `core/context_header.mustache` template.
- **BS5 bridge** (MDL-79917): see the Bootstrap 5 migration section above.
- **FontAwesome families** (MDL-82210): icons mapped via `icon_system::FONTAWESOME` can now specify FA6 families — prefix the icon name with `fa-regular`, `fa-brands`, or `fa-solid` (e.g. `'core:i/scheduled' => 'fa-regular fa-calendar-check'`).
- **Icon refresh** (MDL-77537): core icons updated to FA6 SVGs; PNG/JPG/GIF removed where possible. Plugins using `get_fontawesome_icon_map()` should align: pencil → pen; cog only for settings; import/upload → `fa-upload`, export/download → `fa-download`; eye for visibility and preview. The Component library's Icons page lists all core icons.
