# Moodle 4.5 Activity Modules (mod plugins)

Compact reference for developing `mod_[modname]` activity module plugins against Moodle 4.5, distilled from the official developer docs.

Activity modules are the primary delivery method for learning content. Plugin type is `mod`, frankenstyle name `mod_[modname]`, located in `/mod/[modname]/`. Replace `[modname]` with your module's name throughout.

## Folder layout

Typical layout (example based on the core `folder` plugin; not every file is mandatory):

```
mod/[modname]/
├── backup/
│   ├── moodle1/lib.php
│   └── moodle2/
│       ├── backup_[modname]_activity_task.class.php
│       ├── backup_[modname]_stepslib.php
│       ├── restore_[modname]_activity_task.class.php
│       └── restore_[modname]_stepslib.php
├── classes/
│   ├── event/                  (course_module_viewed.php, course_module_instance_list_viewed.php, ...)
│   ├── privacy/provider.php
│   ├── search/activity.php
│   └── external.php
├── db/
│   ├── access.php              (capability definitions - required)
│   ├── install.xml             (database schema - required)
│   ├── upgrade.php             (upgrade steps)
│   ├── events.php              (event observers)
│   ├── log.php, services.php, install.php
├── lang/en/[modname].php       (language strings - required)
├── lib.php                     (required callbacks)
├── locallib.php
├── mod_form.php                (instance create/edit form - required)
├── index.php                   (instance list - required)
├── view.php                    (activity view page - required)
├── pix/
│   ├── icon.png
│   └── icon.svg                (activity icon shown in course/activity chooser)
├── settings.php
├── tests/
└── version.php                 (required)
```

## version.php

Plugin metadata: version number, dependencies, minimum Moodle version, maturity. Must never contain `require_once` or any file inclusion — it is parsed in performance-sensitive bootstrap paths and must remain a plain data file with no side effects.

```php
defined('MOODLE_INTERNAL') || die();

$plugin->version = 2024100700;          // YYYYMMDDXX
$plugin->requires = 2024100700;         // Minimum Moodle version (4.5.0).
$plugin->supported = [405, 405];        // Moodle 3.9+.
$plugin->component = 'mod_[modname]';
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';
$plugin->dependencies = [
    'mod_forum' => 2022042100,
];
```

## db/install.xml — required table and fields

Moodle requires a table whose name exactly matches the plugin name (e.g. plugin `certificate` must have table `certificate`). Required fields:

| Field | Properties | Keys / Notes |
| --- | --- | --- |
| `id` | `INT(10)`, auto sequence | primary key |
| `course` | `INT(10)` | foreign key to `course` table |
| `name` | `CHAR(255)` | user-specified name of the activity instance |
| `timemodified` | `INT(10)` | timestamp of last modification |
| `intro` | `TEXT` | standard user-defined activity description (see `FEATURE_MOD_INTRO`) |
| `introformat` | `INT(4)` | format of the `intro` field |

Schema changes after release go in `db/upgrade.php` upgrade steps, as with any plugin.

## db/access.php — capabilities

Two capabilities are **required** for activities:

- `mod/[modname]:addinstance` — whether a user may create a new instance
- `mod/[modname]:view` — whether a user may view an instance

Recommended configuration (editing teachers/managers can add; all roles can view — users remain subject to enrolment and other access controls):

```php
$capabilities = [
    'mod/[modname]:addinstance' => [
        'riskbitmask' => RISK_XSS,
        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW,
        ],
        'clonepermissionsfrom' => 'moodle/course:manageactivities',
    ],
    'mod/[modname]:view' => [
        'captype' => 'read',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => [
            'guest' => CAP_ALLOW,
            'student' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW,
        ],
    ],
];
```

## lang/en/[modname].php

```php
$string['pluginname'] = 'The name of your activity';
```

If `FEATURE_QUICKCREATE` is supported, also provide a `quickcreatename` string used as the name of quick-created instances.

## lib.php — required callbacks

For an activity you **must** define:

```php
function [modname]_add_instance($instancedata, $mform = null): int;   // Called on creation form submit; returns new instance id.
function [modname]_update_instance($instancedata, $mform): bool;      // Called on edit form submit.
function [modname]_delete_instance($id): bool;                        // Called on confirmed deletion; must remove all instance data.
```

Note: `lib.php` is one of the older parts of Moodle; functionality is gradually migrating to class-based calls.

### [modname]_supports — feature flags

```php
function [modname]_supports(string $feature): bool|string|null;
```

Return `true` if supported, `false` if not, `null` if unknown, or a string for some features (module purpose). Constants live in `lib/moodlelib.php`. Notable features:

- `FEATURE_GROUPS`, `FEATURE_GROUPINGS` — group/grouping support
- `FEATURE_MOD_INTRO` — uses the standard intro/introformat description
- `FEATURE_SHOW_DESCRIPTION` — description can show on the course page
- `FEATURE_COMPLETION` — supports activity completion (currently affects bulk completion settings)
- `FEATURE_COMPLETION_TRACKS_VIEWS` — completion 'on view'
- `FEATURE_COMPLETION_HAS_RULES` — custom completion rules
- `FEATURE_GRADE_HAS_GRADE` — the activity provides a grade; also enables completion 'on grade'
- `FEATURE_BACKUP_MOODLE2` — implements Moodle 2 backup/restore
- `FEATURE_QUICKCREATE` — `[modname]_add_instance()` can create an instance with defaults, without showing the form (used by the `core_courseformat_new_module` webservice)
- `FEATURE_NO_VIEW_LINK` — module has no view page (like Label); removes the link from course page and navigation
- `FEATURE_MOD_PURPOSE` — classifies the activity in the activity chooser

```php
function [modname]_supports($feature) {
    return match ($feature) {
        FEATURE_GROUPS => true,
        FEATURE_GROUPINGS => true,
        FEATURE_MOD_INTRO => true,
        FEATURE_COMPLETION_TRACKS_VIEWS => true,
        FEATURE_GRADE_HAS_GRADE => true,
        FEATURE_BACKUP_MOODLE2 => true,
        FEATURE_SHOW_DESCRIPTION => true,
        FEATURE_MOD_PURPOSE => MOD_PURPOSE_COLLABORATION,
        default => null,
    };
}
```

Purposes: `MOD_PURPOSE_ADMINISTRATION`, `MOD_PURPOSE_ASSESSMENT` (Assignment, Quiz, Workshop), `MOD_PURPOSE_COLLABORATION` (Database, Forum, Glossary, Wiki), `MOD_PURPOSE_COMMUNICATION` (Chat, Choice, Feedback...), `MOD_PURPOSE_INTERACTIVECONTENT` (H5P, Lesson, SCORM...), `MOD_PURPOSE_CONTENT` (Book, File, Page, URL...), `MOD_PURPOSE_OTHER`.

### Activity chooser callbacks

Implement `[modname]_get_course_content_items()` in lib.php to add items to the activity chooser (replaces deprecated `{plugin}_get_shortcuts()`). Each content item's ID must be unique to your component, must not change, and must be an integer (see `lti_get_course_content_items()` in core). For admin recommendations to work, also implement `[modname]_get_all_content_items()` returning all content items across all courses.

## mod_form.php — instance create/edit form

Class must be named `mod_[modname]_mod_form` extending `moodleform_mod` (a current exception to class autoloading rules, see MDL-74472). Sample implementation (not a complete file):

```php
require_once($CFG->dirroot.'/course/moodleform_mod.php');

class mod_certificate_mod_form extends moodleform_mod {

    function definition() {
        $mform =& $this->_form;

        $mform->addElement('header', 'general', get_string('general', 'certificate'));

        $mform->addElement('text', 'name', get_string('certificatename', 'certificate'), ['size' => '64']);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');

        $mform->addElement('select', 'usecode', get_string('usecode', 'certificate'),
            [0 => get_string('no'), 1 => get_string('yes')]);
        $mform->setDefault('usecode', 0);
        $mform->addHelpButton('usecode', 'usecode', 'certificate');

        // Standard Moodle course module elements (visibility, groups, completion, etc.).
        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }

    function validation($data, $files) {
        $errors = [];
        if (empty($data['name'])) {
            $errors['name'] = get_string('errornoname', 'certificate');
        }
        return $errors;
    }

    function data_preprocessing(&$default_values) {
        // Set default values for form fields before display.
    }
}
```

## view.php and index.php

`view.php` (required): Moodle links to the activity via `/mod/[modname]/view.php?id=CMID` where `id` is the **course module id**:

```php
require(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT);
[$course, $cm] = get_course_and_cm_from_cmid($id, '[modname]');
$instance = $DB->get_record('[modname]', ['id' => $cm->instance], '*', MUST_EXIST);
```

`index.php` (required): lists all instances the current user can access in a course:

```php
require(__DIR__ . '/../../config.php');

$id = required_param('id', PARAM_INT);   // Course id.
$course = $DB->get_record('course', ['id' => $id], '*', MUST_EXIST);
require_course_login($course);

$modinfo = get_fast_modinfo($course);
foreach ($modinfo->get_instances_of('[modname]') as $instanceid => $cm) {
    // Display information about your activity.
}
```

## Activity completion

With no changes, an activity supports only 'manual' completion (user ticks a box). Everything else requires feature flags in `[modname]_supports` (see above).

### Completion on view

Return `true` for `FEATURE_COMPLETION_TRACKS_VIEWS`, then run this whenever a user successfully views the activity (before printing the page header, so navigation reflects it):

```php
$completion = new completion_info($course);
$completion->set_module_viewed($cm);
```

Cheap when 'on view' completion is not enabled; the viewed state is cached.

### Completion on grade

Return `true` for `FEATURE_GRADE_HAS_GRADE`. No other action needed — the activity is marked complete when the user receives a grade.

### Custom completion rules

Return `true` for `FEATURE_COMPLETION_HAS_RULES`, then:

1. **Store settings** in your activity's main table (e.g. forum's `completionposts` — 0 or the number of posts required). Add via install.xml/upgrade.php as usual.
2. **Back up the fields**: add them to your `backup_nested_element` field list in `backup_[modname]_stepslib.php`; restore code must default them sensibly when absent.
3. **Expose them via `[modname]_get_coursemodule_info($coursemodule)`** returning `cached_cm_info`, populating `$result->customdata['customcompletionrules']` as key => value pairs only when `$coursemodule->completion == COMPLETION_TRACKING_AUTOMATIC`. Also set `$result->name`, and `$result->content = format_module_intro(...)` when `$coursemodule->showdescription`.
4. **Form controls** in `mod_form.php`:
   - `add_completion_rules()` — adds elements; must return the top-level element name(s) so they disable when automatic completion is off. **Since 4.3 (MDL-78528), element names must be suffixed with `$this->get_suffix()`** to avoid duplicate IDs.
   - `completion_rule_enabled($data)` — returns whether at least one custom rule is selected (validation errors otherwise).
   - Override `get_data()` for checkbox-driven rules: zero the value when the enabling checkbox is unticked — but only inside a `!empty($data->completionunlocked)` check, since completion settings are locked once users have completions.
   - `data_preprocessing()` — set the checkbox state from the stored value.

```php
public function add_completion_rules() {
    $mform = $this->_form;
    $group = [
        $mform->createElement('checkbox', $this->get_suffixed_name('completionpostsenabled'), ' ',
            get_string('completionposts', 'forum')),
        $mform->createElement('text', $this->get_suffixed_name('completionposts'), ' ', ['size' => 3]),
    ];
    $mform->setType('completionposts', PARAM_INT);
    $mform->addGroup($group, $this->get_suffixed_name('completionpostsgroup'),
        get_string('completionpostsgroup', 'forum'), [' '], false);
    $mform->disabledIf($this->get_suffixed_name('completionposts'),
        $this->get_suffixed_name('completionpostsenabled'), 'notchecked');
    return [$this->get_suffixed_name('completionpostsgroup')];
}

protected function get_suffixed_name(string $fieldname): string {
    return $fieldname . $this->get_suffix();
}
```

5. **State class** `mod_[modname]\completion\custom_completion` (in
   `classes/completion/custom_completion.php`), extending
   `\core_completion\activity_custom_completion`. Implement:
   - `get_state(string $rule): int` — return `COMPLETION_COMPLETE` or
     `COMPLETION_INCOMPLETE` for the rule/user (`$this->cm`, `$this->userid`).
   - `get_defined_custom_rules(): array` — rule names, matching the
     `customcompletionrules` keys from `get_coursemodule_info`.
   - `get_custom_rule_descriptions(): array` — rule name => human-readable
     description (used on the course page dropdown).
   - `get_sort_order(): array` — display order of all completion rules
     including core ones (`completionview`, `completionusegrade`).

   Do NOT implement the pre-3.11 `[modname]_get_completion_state()` /
   `mod_[modname]_get_completion_active_rule_descriptions()` lib.php
   callbacks — they were removed in Moodle 4.3 (MDL-71196). (The 4.5
   activity-completion doc page still shows them; it is stale.)

6. **Notify the completion system** whenever a rule's underlying value may change, passing the possible result — `COMPLETION_COMPLETE` (change can only complete, e.g. adding a post), `COMPLETION_INCOMPLETE` (can only un-complete, e.g. deleting a post), or `COMPLETION_UNKNOWN` (slow; avoid in frequent code). Pass the optional `$userid` when updating someone other than the current user (e.g. teacher deletes a student's post):

```php
$completion = new completion_info($course);
if ($completion->is_enabled($cm) && $forum->completionposts) {
    $completion->update_state($cm, COMPLETION_COMPLETE);
}
```

In cron tasks, `require_once($CFG->dirroot.'/lib/completionlib.php');` first.

## Course page display (lib.php callbacks)

- `[modname]_get_coursemodule_info($cm)` — returns `cached_cm_info`; cached in course modinfo, so DB queries are fine here. Settable: `name`, `icon`/`iconcomponent`, `content` (HTML below the link), `customdata` (avoid complex objects — serialization can break on Postgres), `extraclasses`, `onclick`. Do not use renderers here (MDL-41074); put data in `customdata` and render in `_cm_info_view()`.
- `[modname]_cm_info_dynamic(cm_info $cm)` — runs on every course page load; must make **no DB queries**. Can affect access/navigation, e.g. `$cm->set_user_visible(false)` based on capabilities.
- `[modname]_cm_info_view(cm_info $cm)` — runs only on the course view page; limited DB queries OK. E.g. `$cm->set_after_link('Last tadpole: 22:17')`. Cannot change access flags here (throws `coding_exception`).

Always obtain `$cm` from `get_fast_modinfo($course)` (returns `course_modinfo` with `cm_info` objects; `$modinfo->get_cm($cmid)`); type-hint `cm_info` when you rely on its extra fields like `uservisible`. Classes live in `lib/modinfolib.php`.

## Events

- Standard event classes live in `classes/event/` (e.g. `course_module_viewed`, `course_module_instance_list_viewed`).
- `db/events.php` defines event **observers** (subscriptions to events generated elsewhere). Do not subscribe to another plugin's events without declaring a dependency on it.

```php
$observers = [
    [
        'eventname' => '\core\event\course_module_created',
        'callback'  => '\mod_[modname]\event\observer\course_module_created::store',
        'priority'  => 1000,
    ],
];
```

## Backup and restore

If your plugin stores data, implement the backup feature (backup, restore, duplication) under `backup/moodle2/`: `backup_[modname]_activity_task.class.php`, `backup_[modname]_stepslib.php`, and the matching `restore_*` files; `backup/moodle1/lib.php` handles Moodle 1.x conversion. Declare `FEATURE_BACKUP_MOODLE2` in `_supports`. In the stepslib, list every instance field (including custom completion fields) in the `backup_nested_element`. See "Backup 2.0 for developers" and "Restore 2.0 for developers" docs for details.

## Icon

Provide `pix/icon.svg` (and optionally `pix/icon.png`) — used on the course page and in the activity chooser. The icon can be overridden per-instance via `cached_cm_info::$icon`/`$iconcomponent`.

## Activity sub-plugins (examples from core)

Some activities define their own sub-plugin types:

- `mod_book` — extensible via `booktool` sub-plugins.
- `mod_data` — two sub-plugin types: database **field types** (custom field data types) and **presets** (legacy, shared configurations).
- `mod_forum` — extensible via `forumreport` sub-plugins.
