# Moodle PHPUnit Reference (Moodle 4.5)

Setup, structure, and patterns for writing and running PHPUnit tests in Moodle 4.5 (PHPUnit 9.6).

## Setup

PHPUnit is a Composer dependency, not part of the Moodle install:

```bash
cd /path/to/moodle
php composer.phar install   # or: composer install
```

Add a dedicated test prefix and dataroot to `config.php` (examples in `config-dist.php`):

```php
$CFG->phpunit_prefix = 'phpu_';
$CFG->phpunit_dataroot = '/home/example/phpu_moodledata';
```

Optionally use a separate database for tests (standard DB settings used otherwise):

```php
$CFG->phpunit_dbtype    = 'pgsql';      // 'pgsql', 'mariadb', 'mysqli', 'mssql', 'sqlsrv' or 'oci'
$CFG->phpunit_dblibrary = 'native';
$CFG->phpunit_dbhost    = '127.0.0.1';
$CFG->phpunit_dbname    = 'mytestdb';
$CFG->phpunit_dbuser    = 'postgres';
$CFG->phpunit_dbpass    = 'some_password';
```

Initialise the test environment:

```bash
php admin/tool/phpunit/cli/init.php
```

Repeat init after any upgrade, plugin (un)installation, or after adding tests to a plugin you are developing. Ensure the `en_AU` locale is installed and `php` CLI is on your PATH.

## Running tests

Run everything from `$CFG->dirroot`:

```bash
vendor/bin/phpunit
```

Run a subset:

```bash
# Single test class (by class name)
vendor/bin/phpunit --filter metadata_registry_test

# Single test method
vendor/bin/phpunit --filter test_get_registry_metadata_count

# Single test file
vendor/bin/phpunit cohort/tests/lib_test.php

# Single method in a file
vendor/bin/phpunit --filter test_function_name path/to/file.php

# Whole component testsuite (name from phpunit.xml)
vendor/bin/phpunit --testsuite mod_forum_testsuite
vendor/bin/phpunit --testsuite core_privacy_testsuite --filter test_component_is_compliant

# By @group annotation (recommended: tag tests with your plugin's Frankenstyle name)
vendor/bin/phpunit --group qtype_stack

# Show each test name as it runs
vendor/bin/phpunit --debug
```

Per-component config files:

```bash
php admin/tool/phpunit/cli/util.php --buildcomponentconfigs
vendor/bin/phpunit -c mod/forum
vendor/bin/phpunit -c question/type/calculated
```

Note: running a test by file path may execute tests not included in a normal run (e.g. wrongly located files) — do at least one full or `--group` run to confirm the test is found.

## Test file location and naming

Test files:

- MUST live in the `tests` directory of the component (e.g. `mod/myplugin/tests/`);
- MUST be named in lowercase, ending in `_test.php`;
- MUST contain exactly one test class whose name matches the filename;
- the class MUST extend a `_testcase` class (e.g. `\advanced_testcase`);
- SHOULD use the same namespace as the unit under test (namespace rules for `**/tests` mirror `**/classes`).

```php
// mod/myplugin/tests/sample_test.php
namespace mod_myplugin;

class sample_test extends \advanced_testcase {
    public function test_adding() {
        $this->assertEquals(2, 1 + 2);
    }
}
```

Custom shared testcase classes are allowed but MUST be abstract, MUST contain no tests, and MUST be named with the `_testcase` suffix (never `_test` on abstract classes).

Prefer autoloading; when not possible, load fixtures/code under test in `setUpBeforeClass()`.

## Testcase classes

- `basic_testcase` — pure unit tests that do not modify the database, filesystem, or PHP globals.
- `advanced_testcase` — adds Moodle test helpers (state reset, data generators, sinks, user switching).

### Automatic state reset (`resetAfterTest`)

State resets to a fresh install between tests. If your test modifies the DB or globals, call `$this->resetAfterTest()` — otherwise you get "Warning: unexpected database modification, resetting DB state".

```php
public function test_deleting() {
    global $DB;
    $this->resetAfterTest(true);
    $DB->delete_records('user');
    $this->assertEmpty($DB->get_records('user'));
}
```

Best practice:

- Call `resetAfterTest` immediately before the first data insertion, in the test function or a helper it calls (multiple calls are fine).
- Do NOT call `resetAfterTest` or create fixtures in a shared `setUp()` — this is banned for new code (slows every test in the class, causes memory bloat since testcase instances live for the whole run).
- Avoid `resetAfterTest` where you can — it slows tests; prefer mockable code.

### Switching users

By default no user is logged in; only `guest` and `admin` exist.

```php
$this->setUser($user1);      // simulate login
$this->setAdminUser();
$this->setGuestUser();
$this->setUser(null);        // back to not logged in
```

## Data generators

Use from `advanced_testcase` test methods via `$this->getDataGenerator()`:

```php
// Users
$user = $this->getDataGenerator()->create_user();
$user1 = $this->getDataGenerator()->create_user(['email' => 'user1@example.com', 'username' => 'user1']);

// Categories and courses
$category = $this->getDataGenerator()->create_category();
$course = $this->getDataGenerator()->create_course(['category' => $category->id]);

// Activity modules (module generators live in plugindir/tests/generator/lib.php)
$page = $this->getDataGenerator()->create_module('page', ['course' => $course->id]);
// Equivalent long form:
$generator = $this->getDataGenerator()->get_plugin_generator('mod_page');
$generator->create_instance(['course' => $course->id]);

// Enrolments (self/manual enrol plugins)
$this->getDataGenerator()->enrol_user($userid, $courseid);
$this->getDataGenerator()->enrol_user($userid, $courseid, $teacherroleid, 'manual');

// Others
$cohort = $this->getDataGenerator()->create_cohort();
$this->getDataGenerator()->create_scale([...]);
$this->getDataGenerator()->create_role(['shortname' => $shortname, 'archetype' => $archetype]);
$this->getDataGenerator()->create_tag([...]);
$this->getDataGenerator()->create_group(['courseid' => $courseid]);
$this->getDataGenerator()->create_group_member(['userid' => $userid, 'groupid' => $groupid]);
$this->getDataGenerator()->create_grouping(['courseid' => $courseid]);
$this->getDataGenerator()->create_grouping_group(['groupingid' => $groupingid, 'groupid' => $groupid]);
$this->getDataGenerator()->create_repository($type, $record, $options);
$this->getDataGenerator()->create_grade_category(['courseid' => $courseid]);
$this->getDataGenerator()->create_grade_item(['itemtype' => $itemtype, 'itemname' => $itemname]);
$this->getDataGenerator()->create_grade_outcome();
```

### Plugin generators

Any plugin can define its own generator in `tests/generator/lib.php`. It MUST extend `\component_generator_base` (activity modules should extend `testing_module_generator` for consistent method names):

```php
$mygenerator = $this->getDataGenerator()->get_plugin_generator('my_componentname');
```

## Data providers

Powerful for testing many conditions, with strict rules:

- Data providers MUST NOT instantiate or create data (no generators, no `setUser`) — they only define it. Providers run before any test; the DB is reset before each test runs.
- Keep resettable data needing `resetAfterTest` to a minimum.

```php
/**
 * @dataProvider foobar_provider
 */
public function test_foobar(int $foo, int $bar) {
    // Perform the tests here.
}

public function foobar_provider(): \Generator {
    yield 'Same numbers' => ['foo' => 42, 'bar' => 42];
    yield 'Different numbers' => ['foo' => 21, 'bar' => 84];
}
```

## Message and email sinks

Redirect messages sent via `message_send()` into a sink. Message sending is deferred until after transactions close, so disable test-in-transaction first:

```php
$this->preventResetByRollback();
$sink = $this->redirectMessages();

// ... code that sends messages

$messages = $sink->get_messages();
$this->assertEquals(3, count($messages));

// Since 4.4:
$messages = $sink->get_messages_by_component('mod_forum');
$messages = $sink->get_messages_by_component_and_type('core', 'messagecontactrequests');
```

Emails sent via `email_to_user()`:

```php
unset_config('noemailever');
$sink = $this->redirectEmails();

// ... code that sends email

$messages = $sink->get_messages();
$this->assertEquals(1, count($messages));
```

## Testing events via logstores

To test events written to a logstore, disable transactions, enable a logstore, and disable buffering:

```php
$this->preventResetByRollback();
set_config('enabled_stores', 'logstore_standard', 'tool_log');
set_config('buffersize', 0, 'logstore_standard');
get_log_manager(true);
```

## Coverage

### coverage.php

Declare which files count for coverage in `tests/coverage.php` (paths relative to the plugin root). Since Moodle 4.0 a default is applied (includes `classes`, `tests/generator`, `externallib.php`, `lib.php`, `locallib.php`, `renderer.php`, `rsslib.php`); supply `coverage.php` only to add more:

```php
return new class extends phpunit_coverage_info {
    protected $includelistfolders = ['classes', 'externallib.php'];
    protected $includelistfiles = [];
    protected $excludelistfolders = [];
    protected $excludelistfiles = [];
};
```

### @covers annotations

Each test class MUST declare what it intends to cover. On PHPUnit 9.6 (Moodle 4.4-4.5) use annotations with fully-qualified class names; define coverage at class level where possible:

```php
/**
 * @coversDefaultClass \mod_myplugin\example
 */
class example_test extends \advanced_testcase {
    /**
     * @covers ::some_method
     */
    public function test_some_method(): void {}
}

// Or cover a whole class:
/** @covers \mod_myplugin\example */
```

PHP attributes (`#[\PHPUnit\Framework\Attributes\CoversClass(example::class)]`) only work from Moodle 5.0 / PHPUnit 10 — do not use them in plugins that must support 4.5.

## Extra settings and misc

- `$CFG` from `config.php` is intentionally unavailable in tests. Inject custom settings as constants defined in `phpunit.xml` or in `config.php` (e.g. `define('TEST_EXTERNAL_FILES_HTTP_URL', 'http://localhost/moodle-exttests');`).
- Large data sets: see `\advanced_testcase::createXMLDataSet()` and `createCsvDataSet()`.
- Tests taking >10s should run only when long tests are enabled.
- Prefer testing public APIs; use reflection only as a last resort.
- Use `SomeClass::class` constants in assertions and coverage (supports class aliasing across Moodle versions).
- PHPUnit 9.6 deprecations to avoid (removed in PHPUnit 10): `assertObjectHasAttribute()` (use `assertObjectHasProperty()`), `expectDeprecation()`/`expectWarning()`/`expectError()`/`expectNotice()` families, mock `->withConsecutive()`.
