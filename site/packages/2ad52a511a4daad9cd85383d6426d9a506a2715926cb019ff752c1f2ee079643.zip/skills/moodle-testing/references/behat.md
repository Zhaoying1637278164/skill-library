# Moodle Behat Reference (Moodle 4.5)

Setup, running, and writing Behat acceptance tests for Moodle 4.5 plugins and core.

## Setup

Behat runs against a parallel test site (own wwwroot/dataroot/prefix), never the production data. Requirements: a browser plus its WebDriver (chromedriver/geckodriver), optionally Selenium (needs a Java runtime).

In `config.php` (before the `require_once(__DIR__ . '/lib/setup.php');` line):

```php
$CFG->behat_dataroot = '/path/to/the/dataroot/you/created';  // new, dedicated dir
$CFG->behat_wwwroot = 'http://127.0.0.1/path/to/your/site';  // MUST differ from $CFG->wwwroot
$CFG->behat_prefix = 'beh_';
```

Recommended: the [moodle-browser-config](https://github.com/andrewnicols/moodle-browser-config) tool for ready-made browser profiles:

```php
require_once('/path/to/moodle-browser-config/init.php');
```

Initialise (installs Composer deps, installs the test site, writes config; rerun after adding new step definitions or features, or use `php admin/tool/behat/cli/util.php --enable`):

```bash
php admin/tool/behat/cli/init.php
```

## Running tests

Start Selenium (`java -jar selenium-server-standalone-3.141.59.jar`) or a driver directly (`chromedriver`, or `geckodriver` — port 4444, not alongside Selenium). Then run the command init printed:

```bash
vendor/bin/behat --config /path/to/behat_dataroot/behatrun/behat/behat.yml

# Filter by tag / file / line / scenario name
vendor/bin/behat --config .../behat.yml --tags=@mod_forum
vendor/bin/behat --config .../behat.yml `pwd`/mod/forum/tests/behat/private_replies.feature
vendor/bin/behat --config .../behat.yml `pwd`/mod/forum/tests/behat/private_replies.feature:38
vendor/bin/behat --config .../behat.yml --name="As a teacher I can see my own response"

# Browser profile (default is firefox)
vendor/bin/behat --config .../behat.yml --profile=headlesschrome
vendor/bin/behat --config .../behat.yml --profile=geckodriver
```

Useful profiles from moodle-browser-config: `firefox`, `chrome`, `edge` (via Selenium), `headlessfirefox`, `headlesschrome`, and Selenium-free `chromedriver`, `geckodriver`, `headlesschromedriver`, `headlessgeckodriver`.

Other options:

- `--rerun` — rerun only the previously failed scenarios; the Moodle runner also has `--auto-rerun`.
- `--format=pretty --out=/tmp/pretty.txt --format=moodle_progress --out=std` — multiple outputs; formats include `progress`, `pretty`, `junit`, `moodle_progress`, `moodle_list`, `moodle_stepcount`, `moodle_screenshot`.
- `-vv` — verbose output when error messages are useless.
- Themes: init with `php admin/tool/behat/cli/init.php --add-core-features-to-theme`, then `--suite=classic` (boost = suite `default`).
- Parallel runs: `php admin/tool/behat/cli/init.php --parallel=3` then `php admin/tool/behat/cli/run.php --tags="@tool_myplugin"` (wrapper accepts `--tags`, `--name`, `--feature`, `--suite`, `--replace`, `--fromrun`, `--torun`).
- Slow machine timeouts: `$CFG->behat_increasetimeout = 2;`
- Custom browser profiles without moodle-browser-config: `$CFG->behat_profiles = ['chrome' => ['browser' => 'chrome', 'tags' => '@javascript']];`

## Feature files

Behat tests live in `tests/behat/` of a plugin, in `*.feature` files, written in Gherkin:

```gherkin
@mod @mod_yourplugin @javascript
Feature: Here comes a description of your user story.

  Background:
    Given the following "courses" exist:
      | fullname | shortname | category | groupmode |
      | Course 1 | C1        | 0        | 1         |
    And the following "users" exist:
      | username | firstname | lastname | email                |
      | teacher1 | Theo      | Teacher  | teacher1@example.com |

  Scenario: Description of your scenario, which you want to test.
    When I log in as "student1"
    And I am on "Course 1" course homepage
    Then I should see "..."
```

Rules and conventions:

- **Given** = set-up, **When** = actions, **Then** = assertions. Use each keyword only ONCE per scenario; chain further steps with **And** / **But** (policy MDLSITE-3778). Tear-down is automatic between scenarios.
- Test one thing per scenario.
- Set-up (Given) should NOT use the UI — use generator steps like `the following "courses" exist:` that insert directly into the database.
- A feature can hold multiple scenarios (same feature only); shared Given steps go in a `Background:`.
- Tags in the feature header apply to all its scenarios.
- Avoid XPath/CSS selectors (`css_element`, `xpath_element`); if you need them, that usually signals an accessibility bug. Prefer `I set the field "Answer" to "frog"`.

### Tags

- `@javascript` — scenario needs a real browser (Selenium or a driver); JS tests are much slower, so only use when needed.
- `@_file_upload` — involves file uploads; run only when Selenium runs on the same machine as the tests.
- `@_alert`, `@_switch_window`, `@_switch_iframe`, `@_cross_browser` — mark OS/browser-sensitive steps.
- `@componentname` — tag features with the Frankenstyle component name (e.g. `@mod_forum`).

### Providing values to steps

- Strings in double quotes (`I press "Save and return to course"`); escape quotes as `\"`.
- Tables for forms/data (steps ending in `:`); PyStrings for multiline values.
- Selectors pair a locator with a type: `I click on "User Name" "link"`. Types include: field, link, button, link_or_button, select, checkbox, radio, file, optgroup, option, dialogue, filemanager, block, section, activity, region, table_row, table, icon, fieldset, css_element, xpath_element. Container ("text selector") types for `... in the "Community finder" "block"` include dialogue, block, section, activity, region, table_row, table, fieldset, list_item, css_element, xpath_element.
- Table checks:

  ```gherkin
  Then "STRING_IN_ROW" row "COLUMN_HEADER" column of "TABLE_ID" table should contain "VALUE_TO_CHECK"
  Then the following should exist in the "TABLE_ID" table:
      | COLUMN_HEADER1 | COLUMN_HEADER2 |
      | VALUE_IN_ROW_1 | VALUE_IN_ROW_1 |
  ```

- Field groups (dates, durations): `myDate[day]`, `myDuration[unit]` in `I set the following fields to these values:` tables.
- Relative dates: `##yesterday##`, `##2 days ago##`, optionally with a format: `##yesterday##%d##` (any PHP datetime format/relative format).
- File uploads: `I upload "lib/tests/fixtures/users.csv" file to "Files" filemanager` — fixture files live in `COMPONENT/tests/fixtures/`, paths relative to the codebase root with `/` separators; tag the scenario `@_file_upload`.
- Navigation steps (prefer these over clicking through menus — faster and immune to navigation changes):

  ```gherkin
  Given I am on the "Quiz 1" "mod_quiz > View" page logged in as "manager"
  Given I am on the "C1" "Course" page
  ```

Browse all available steps at Site administration > Development > Acceptance testing (requires the behat site to be installed), which lists and filters every step definition.

## Custom step definitions

Steps are PHP methods in a class `behat_plugintype_pluginname` in `tests/behat/behat_plugintype_pluginname.php`, annotated with `@Given`/`@When`/`@Then` regexes in the PHPDoc. Pick the annotation by meaning (Given = setup, When = action, Then = verification) — matching ignores it. Name steps so they are clearly plugin-specific (e.g. "... in the CodeRunner question type", not "I disable UI plugins").

```php
/**
 * Toggles the specified admin switch.
 *
 * @When /^I toggle the "(?P<element_string>(?:[^"]|\\")*)" admin switch "(?P<state_string>on|off)"$/
 */
public function i_toggle_admin_switch($element, $state) {
    if (!$this->running_javascript()) {
        throw new \Behat\Mink\Exception\DriverException('Switches are only available with JavaScript enabled');
    }
    $node = $this->get_selected_node('checkbox', $element);
    $this->ensure_node_is_visible($node);
    $field = $node->getAttribute('id');
    if ($state == "on") {
        $this->execute('behat_forms::i_set_the_field_to', [$field, 1]);
    } else {
        $this->execute('behat_forms::i_set_the_field_to', [$field, 0]);
    }
}
```

When a custom step performs actions (click, press, fill), call existing steps via `$this->execute('context::method', [args])` — do not call `->click()` on a NodeElement directly (bypasses error detection and JS waits).

Also implementable in your `behat_plugintype_pluginname` class:

- Custom selectors (`... in the "..." "..."`, e.g. `core_message > Message`): implement `behat_component_named_selector`-style functions (see PHPDoc in `lib/behat/behat_base.php`).
- Custom navigation targets (`I am on the "..." "..." page`): implement `resolve_page_url` and `resolve_page_instance_url`.

Deprecating a step: create `tests/behat/behat_pluginname_deprecated.php` extending `behat_deprecated_base`; the method calls `$this->deprecated_message('...')` then performs the original behaviour. Deprecated steps fail tests unless `$CFG->behat_usedeprecated` is set.

Theme overrides: contexts in `/theme/{MYTHEME}/tests/behat/` named `behat_theme_{MYTHEME}_<context>`; selectors via `behat_theme_{MYTHEME}_behat_selectors`; disable contexts/features per theme with `/theme/{MYTHEME}/tests/behat/blacklist.json`.

## Generators in Given steps

Reuse your PHPUnit data generator (`tests/generator/lib.php`) in Behat via a behat generator class in `tests/generator/behat_local_myplugin_generator.php`:

```php
// tests/generator/lib.php
class local_myplugin_generator extends component_generator_base {
    public function create_thing($thing) {
        global $DB;
        $DB->insert_record('local_myplugin_things', $thing);
    }
}

// tests/generator/behat_local_myplugin_generator.php
class behat_local_myplugin_generator extends behat_generator_base {
    protected function get_creatable_entities(): array {
        return [
            'things' => [
                'datagenerator' => 'thing',   // -> create_thing()
                'required' => ['name'],
            ],
        ];
    }
}
```

```gherkin
Given the following "local_myplugin > things" exist:
  | name   |
  | thing1 |
  | thing2 |
```

## Generator tool (test data outside Behat runs)

With debugging set to DEVELOPER, `admin/tool/generator` can build test data:

```bash
php admin/tool/generator/cli/maketestcourse.php --shortname=SIZE_S --size=S

# Execute a behat generator .feature (generator/set-config steps only, no Background,
# no browser) against the current instance:
php admin/tool/generator/cli/runtestscenario.php --feature=/path/to/some/testing/scenario.feature
```

Web equivalents: Site administration > Development > Make test course / Create testing scenarios. Example scenario files: `admin/tool/generator/tests/fixtures/testscenario/scenario.feature`.
