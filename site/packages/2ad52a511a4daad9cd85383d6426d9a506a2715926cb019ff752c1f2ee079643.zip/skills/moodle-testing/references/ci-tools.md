# Moodle CI and Code-Quality Tools (Moodle 4.5)

Reference for phpcs/moodle-cs, GitHub Actions CI (core and moodle-plugin-ci for plugins), grunt/NodeJS tooling, MDK, composer, and plugin-contribution validation.

## PHP CodeSniffer with moodle-cs

Moodle publishes two phpcs rulesets matching the Moodle Coding Style:

- `moodle` — standard ruleset, meets all variants of the coding style
- `moodle-extra` — includes recommended best practices (recommended, especially for new code)

### Installation

Recommended: global composer install so one copy serves all code.

```console
composer global config minimum-stability dev
composer global require moodlehq/moodle-cs
```

Check for / apply updates (not automatic):

```console
composer global show -l
composer global update
```

### Configuration

Since Moodle 4.1.0 / 4.0.1 / 3.11.7 a phpcs configuration ships in the Moodle codebase, so the correct ruleset is picked up automatically. Run `grunt ignorefiles` to generate an additional config that ignores third-party libraries.

To layer `moodle-extra` on top in core, create `.phpcs.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ruleset name="MoodleCore">
  <rule ref="./phpcs.xml"/>
  <rule ref="moodle-extra"/>
</ruleset>
```

For a plugin developed outside the Moodle directory, create `phpcs.xml.dist` at the repository root:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ruleset name="MoodleCore">
  <rule ref="moodle"/>
</ruleset>
```

(If you don't want it committed: `echo phpcs.xml.dist >> .git/info/exclude`.)

Setting a system-wide default (`phpcs --config-set default_standard moodle`) works but is not recommended.

### Running

```console
phpcs path/to/file.php            # single file, full report
phpcs -n index.php                # -n ignores warnings, errors only
phpcs --report=summary blocks/html   # recursive on a folder, summary per file
```

Report formats: `full` (default), `summary`, `xml`, `csv`, `checkstyle`. The summary output notes how many violations `phpcbf` can fix automatically.

Editor integration is automatic since 3.11.7/4.0.1/4.1.0. If your IDE reports 'ERROR: Referenced sniff "moodle" does not exist', point it at the composer-installed binary (e.g. `~/.config/composer/vendor/bin/phpcs`) and select "Automatic" as the standard.

## GitHub Actions

### Moodle core

Since Moodle 3.5.16, core ships a GitHub Actions workflow that runs a matrix of databases/PHP versions. Enable Actions on your fork (Settings > Actions, "Allow all" — the workflow reuses actions from different sources). Every push to any branch queues a build; results appear in the Actions tab, and pass/fail badges show on matching Tracker issues. Moodle HQ's Jenkins (https://ci.moodle.org/) remains the canonical CI; GHA is early warning for developers.

Since 3.11.8 / 4.0.2, PHPUnit runs can be configured by creating a repository secret named `phpunit_options` whose value is passed as PHPUnit CLI options.

### Moodle plugins: moodle-plugin-ci

The devdocs delegate plugin CI to the Moodle Plugin CI project: https://moodlehq.github.io/moodle-plugin-ci/ (GitHub Actions instructions and a template `.github/workflows/*.yml` live there). Typical workflow shape from that project: a job matrix over PHP version, Moodle branch (e.g. `MOODLE_405_STABLE`) and database (`pgsql`, `mariadb`); install with

```bash
composer create-project -n --no-dev --prefer-dist moodlehq/moodle-plugin-ci ci ^4
moodle-plugin-ci install --plugin ./plugin --db-host=127.0.0.1
```

then run the standard checks:

```bash
moodle-plugin-ci phplint
moodle-plugin-ci phpmd
moodle-plugin-ci phpcs          # a.k.a. codechecker (Moodle coding style)
moodle-plugin-ci phpdoc
moodle-plugin-ci validate
moodle-plugin-ci savepoints
moodle-plugin-ci mustache
moodle-plugin-ci grunt
moodle-plugin-ci phpunit
moodle-plugin-ci behat
```

Consult the moodle-plugin-ci site for the current workflow template — it is the authoritative source; the devdocs only link to it.

### CiBot (Tracker prechecks)

Core issues awaiting peer review or integration are checked automatically by CiBot (unless labelled `ci`). Add the label `cime` to an issue to request a check on demand (polled every 20 min; the label is removed after the run). Failing checks don't auto-reject an issue, but fix style problems on lines your patch touches; don't reformat unrelated existing code.

## NodeJS and Grunt

Grunt lints, transpiles, minifies and packages Moodle's JavaScript and CSS. After changing any JS or CSS in Moodle you must run grunt before the change is served.

### Node version

Install NodeJS via NVM (nvm-windows >= 1.1.9 on Windows). Moodle ships a `.nvmrc` pinning the correct Node version — from the Moodle directory:

```bash
nvm install
nvm use
npm install            # install build dependencies (grunt, eslint, ...)
npm install -g grunt-cli   # optional; or use npx grunt
```

### Common grunt tasks

```
grunt amd                          # ignorefiles + eslint:amd + rollup
grunt js                           # amd + yui
grunt css                          # scss + rawcss
grunt stylelint
grunt eslint --show-lint-warnings  # pedantic JS lint warnings
grunt componentlibrary
grunt                              # context-aware: amd in amd/, shifter in yui/src/, else css+js
grunt watch                        # rebuild on file change (needs watchman)
```

Notes: `cd` into your plugin's `amd/` folder before `grunt amd` to compile only that plugin's AMD sources; add `-v` for verbose output; on Windows pass `--root=admin/tool/templatelibrary`-style paths. `grunt watch` may require installing watchman and raising `fs.inotify.max_user_watches`.

For plugins outside core, the root `Gruntfile.js` handles AMD/YUI builds; compiling plugin SCSS needs a local `package.json` + `Gruntfile.js` in the plugin root (loading core's Gruntfile via `grunt-load-gruntfile`) with `grunt-contrib-sass`/`watch`/`clean` dev dependencies.

## MDK (Moodle Development Kit) — brief

Python tool managing multiple Moodle instances (one directory per version/DB combo):

```bash
mdk create -i -v 24 -e pgsql -r dev users     # create + install instance, dev config, test users
mdk fix 12345 ; mdk push -t                   # branch for MDL-12345, push + update tracker
mdk pull 12345 -t                             # pull a tracker patch into a testing branch
mdk phpunit -r                                # init and run PHPUnit
mdk phpunit -r -u repository/tests/repository_test.php
mdk backport --versions 37 38 --push --update-tracker
```

## Composer — brief

Core's `composer.json`/`composer.lock` pin the PHPUnit and Behat toolchain; run `composer install` in the Moodle root. When changing `composer.json`, regenerate the lock file on the lowest PHP version the branch supports: `rm composer.lock && rm -fr vendor && php composer.phar clearcache && php composer.phar update`, then verify phpunit/behat still run.

## Plugin contribution: validation before moodle.org submission

Note: the historic Plugins Directory approval process is legacy guidance — the directory has moved to Moodle Marketplace; check the current Marketplace submission guidelines. The technical checklist below still reflects what the automated prechecks and reviewers look at.

Automated prechecks run on every uploaded plugin version: **phplint** (PHP syntax), **phpcs** (Moodle coding style), **js**, **css**, **phpdoc**, **savepoint** (upgrade savepoints), **thirdparty** (`thirdpartylibs.xml`), **grunt** (build artifacts up to date), **mustache** (templates). Aim for zero errors/warnings.

Checklist essentials:

- Repository named `moodle-{plugintype}_{pluginname}`; public source-control URL, bug tracker URL, documentation URL, description, screenshots.
- Supports at least one currently maintained Moodle version.
- GPL v3+ boilerplate and `@copyright` tag in every interface file; third-party libraries GPL-compatible and declared in `thirdpartylibs.xml`.
- Installs cleanly from the ZIP via the plugin installation UI; no composer step required of admins; dependencies declared in `version.php`.
- No PHP warnings/notices with developer debugging on; works on both MySQL and PostgreSQL (use the DML API).
- Frankenstyle everywhere: DB tables, settings, functions, classes, constants prefixed `plugintype_pluginname_...`; no unprefixed globals.
- Settings in `config_plugins` (names `plugintype_pluginname/settingname` in settings.php; read with `get_config()`).
- All UI text via `get_string()`; ship only English strings (`lang/en/`); string files are pure `$string['id'] = 'value';` data — no concatenation/heredoc.
- CSS selectors namespaced to the plugin (e.g. `.path-mod-mymodule .contentarea`).
- Security: `required_param()`/`optional_param()` not superglobals, SQL placeholders, `sesskey` checks, `require_login()`, capability checks before display and action; avoid `eval()`/`unserialize()`/`call_user_func()` on user data.
- Privacy API implemented (required for plugins integrating with external systems); activity modules must implement backup/restore.

Approval blockers include: no public issue tracker, SQL failing on PostgreSQL, frankenstyle collisions, security guideline violations, missing privacy API (external integrations), missing backup/restore (activity modules), trademark/site-policy violations.
