# JavaScript in Moodle (4.5)

ES2015+ modules in `amd/src`, built with grunt, loaded via RequireJS; core helpers for AJAX, strings, templates, and modals.

## Module format and naming

- All new JS must be ES module (ESM) format; Babel transpiles it to AMD/CommonJS and RequireJS loads it. AMD `define()` syntax is legacy but interoperable.
- Source: `<componentdir>/amd/src/modulename.js` -> module name `component_name/modulename` (Frankenstyle component, no `.js` extension).
- Built output: `<componentdir>/amd/build/modulename.min.js` — commit the build files too.
- Subdirectories: first directory must be a Moodle API name or `local`. Conventions: `local/<feature>/selectors.js` for CSS selectors, `local/<feature>/repository.js` for web service calls. Examples: `mod_forum/discussion`, `core_user/local/participants/selectors`.
- Only exported functions are callable from outside. ESM named exports and default export cannot be mixed in one file (default wins if both used).
- Suffix a file `-lazy.js` to make it load on first use instead of on every page (require it with the `-lazy` name).

```js
// mod/example/amd/src/helloworld.js
export const init = () => {
    window.console.log('Hello, world!');
};
```

## Build tooling (grunt)

```bash
npx grunt amd     # build all AMD/ESM modules
npx grunt watch   # rebuild changed files during development (recommended)
```

Development mode: set `$CFG->cachejs = false;` — Moodle still serves minified JS but sends source maps. If `npm-shrinkwrap.json` changed after installing extras: `git checkout npm-shrinkwrap.json && npm ci`.

## Including modules

From PHP (`js_call_amd` on the page requirements manager):

```php
$PAGE->requires->js_call_amd('mod_forum/discussion', 'init');
$PAGE->requires->js_call_amd('mod_forum/discussion', 'init', [$course->id]);
// Multi-dimensional array -> destructure in JS:
$PAGE->requires->js_call_amd('mod_forum/discussion', 'init', [[
    'courseid' => $course->id,
    'categoryid' => $course->category,
]]);
```

```js
export const init = ({courseid, categoryid}) => { /* ... */ };
```

Params must be `json_encode`-able; > 1Kb triggers a developer warning. Prefer data attributes in the DOM or AJAX over large params.

From a Mustache template (must be inside `{{#js}}`; keep inline JS minimal — it is not transpiled/minified):

```handlebars
<div id="mod_forum-discussion-wrapper-{{uniqid}}">...</div>

{{#js}}
require(['mod_forum/discussion'], function(Discussion) {
    Discussion.init(document.querySelector("mod_forum-discussion-wrapper-{{uniqid}}"));
});
{{/js}}
```

`{{uniqid}}` is one unique string per rendered template — combine it with other identifiers.

Dynamic import from JS (advanced): `import(`local_examples/local/types/type_${modname}`).then(...)`.

## DOM event conventions

One delegated listener; selectors in a private (non-exported) `Selectors` object using namespaced `data-*` attributes (not classes); match with `e.target.closest()`:

```js
import Selectors from './local/helloworld/selectors';

const registerEventListeners = () => {
    document.addEventListener('click', e => {
        if (e.target.closest(Selectors.actions.showAlertButton)) {
            window.alert("Thank you for clicking on the button");
        }
    });
};

export const init = () => {
    registerEventListeners();
};
```

```js
// local/helloworld/selectors.js
export default {
    actions: {
        showAlertButton: '[data-action="mod_example/helloworld-update_button"]',
    },
};
```

## AJAX: core/ajax

Call Moodle web service functions directly. The function must have `'ajax' => true` in `db/services.php` (bump the plugin version after changing service definitions). Convention: wrap all calls in a `repository.js` module.

```js
// mod/assign/amd/src/repository.js
import {call as fetchMany} from 'core/ajax';

export const submitGradingForm = (
    assignmentid,
    userid,
    data,
) => fetchMany([{
    methodname: 'mod_assign_submit_grading_form',
    args: {
        assignmentid,
        userid,
        jsonformdata: JSON.stringify(data),
    },
}])[0];
```

```js
import {submitGradingForm} from './repository';

export const doSomething = async() => {
    const response = await submitGradingForm(assignmentId, userId, data);
    window.console.log(response);
};
```

`fetchMany([...requests])` chains multiple WS calls in one HTTP request and returns one promise per request. Considerations:

- WS text output must go through `external_format_text`/`external_format_string` with the most specific context.
- After adding dynamic content, notify filters via `M.core.event.FILTER_CONTENT_UPDATED`.
- Session-less calls (rare, 100% public data only): `'loginrequired' => false` in `db/services.php` and pass `false` as the 3rd argument to `call`.

## Strings: core/str

Strings are fetched from Moodle and cached in LocalStorage.

- `getString` / `getStrings` — native Promises (preferred, 4.3+)
- `get_string` / `get_strings` — jQuery Promises (required if supporting Moodle <= 4.2)

```js
import {getString} from 'core/str';

getString('close', 'core')
.then((closeString) => {
    window.console.log(closeString);
    return closeString;
})
.catch();
```

Prefetch assets for perceived performance:

```js
import Prefetch from 'core/prefetch';
Prefetch.prefetchString('discussion', 'mod_forum');
Prefetch.prefetchStrings('core', ['yes', 'no', 'maybe']);
Prefetch.prefetchTemplate('core/toast');
Prefetch.prefetchTemplates(['core/toast', 'core/modal']);
```

## Templates: core/templates

`Templates.render(templateName, context)` returns a promise; usable anywhere a string/HTML/Promise is accepted (e.g. modal bodies):

```js
import Templates from 'core/templates';

const bodyPromise = Templates.render('mod_example/example_modal_content', {id: 42});
```

## Modals: core/modal

Since 4.3, call static `create()` on the modal class (ModalFactory is deprecated since 4.3; required only for <= 4.2 support).

```js
import Modal from 'core/modal';

export const init = async() => {
    const modal = await Modal.create({
        title: 'Test title',
        body: '<p>Example body content</p>',
        footer: 'An example footer content',
        show: true,
        removeOnClose: true,
    });
};
```

Standard types: delete/cancel, save/cancel, cancel. Title/body/footer accept strings or Promises (getString, Templates.render).

```js
import ModalSaveCancel from 'core/modal_save_cancel';
import ModalEvents from 'core/modal_events';
import {get_string as getString} from 'core/str';

export const init = async() => {
    const modal = await ModalSaveCancel.create({
        title: 'test title',
        body: getString('confirmchange', 'mod_example'),
    });

    modal.getRoot().on(ModalEvents.save, (e) => {
        // e.g. validate before saving.
    });
};
```

Custom modal type (4.3+): extend `core/modal` with `TYPE` and `TEMPLATE` static properties; the template extends the `core/modal` core template overriding `{{$title}}`, `{{$body}}`, `{{$footer}}` blocks. Override `configure(modalConfig)` (calling `super.configure(modalConfig)`) for default options or custom arguments.

```js
import Modal from 'core/modal';

export default class MyModal extends Modal {
    static TYPE = "mod_example/my_modal";
    static TEMPLATE = "mod_example/my_modal";
}

// Usage: const modal = await MyModal.create({}); modal.show();
```

## jQuery policy

jQuery is strongly discouraged in new code and not generally accepted in core (deprecated direction since 3.8); use vanilla JS/ESM. When interfacing with legacy code, import it: `import jQuery from 'jquery';` (or AMD `define(['jquery'], ...)`). jQuery UI must not be used in core and is highly discouraged in plugins (theme/bootstrap conflicts); if unavoidable: `$PAGE->requires->jquery_plugin('ui');` before any output.

## Promises

- Use `then`/`catch` consistently; you must return at the end of a thennable.
- Never use `.done` or `.fail` — jQuery-only, absent from native Promises.
- A function whose main job is creating a Promise should return it:

```js
const getModal = questionBody => {
    return Modal.create({
        title: getString('my_title', 'mod_example'),
        body: renderTemplate('mod_example/example_body', questionBody),
        removeOnClose: true,
    })
    .then(modal => {
        modal.show();
        return modal;
    });
};
```

## Other core modules

- `core/dropzone` (4.4+): accessible drop zones — `new Dropzone(container, 'image/*', files => {...})`, then `dropZone.setLabel('...')`, `dropZone.init()`.
- Reactive state (4.0+): core ships a framework-independent ad-hoc reactive library for core UIs; third-party code may use any framework.
