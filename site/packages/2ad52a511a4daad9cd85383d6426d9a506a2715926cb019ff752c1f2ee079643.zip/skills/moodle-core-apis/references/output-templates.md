# Moodle 4.5 Output API and Mustache Templates

Compact reference for page output ($PAGE/$OUTPUT), renderers/renderables, Mustache templates, output formatting functions, and html_writer, distilled from the official Moodle 4.5 developer docs.

## Page setup and output journey

`$PAGE` is a global `moodle_page` instance (`lib/pagelib.php`) tracking page state: context, URL, layout, title, headings. `$PAGE->requires` is a `page_requirements_manager` (`lib/outputrequirementslib.php`) for queuing JS/CSS in the correct place. `$OUTPUT` is the generic core renderer; plugins should use a plugin-specific renderer obtained via `$PAGE->get_renderer()`.

Typical page (admin tool example):

```php
<?php
require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir.'/adminlib.php');

admin_externalpage_setup('tooldemo'); // Admin pages: setup + permission checks.

// Set up the page.
$title = get_string('pluginname', 'tool_demo');
$pagetitle = $title;
$url = new moodle_url("/admin/tool/demo/index.php");
$PAGE->set_url($url);
$PAGE->set_title($title);
$PAGE->set_heading($title);

$output = $PAGE->get_renderer('tool_demo');

echo $output->header();
echo $output->heading($pagetitle);

$renderable = new \tool_demo\output\index_page('Some text');
echo $output->render($renderable);

echo $output->footer();
```

Notes:
- Do all logic (DB queries, params, access checks) before creating the renderable; pass results as data.
- `footer()` also prints everything queued in the requirements manager. All JavaScript goes in the footer for performance — never inline in content or the head.
- Non-admin pages set context/URL themselves, e.g. `$PAGE->set_context(context_system::instance()); $PAGE->set_url('/');`.

## Renderables and templatable

A renderable is a plugin class holding all data needed to display something:

```php
namespace tool_demo\output;

use renderable;
use renderer_base;
use templatable;
use stdClass;

class index_page implements renderable, templatable {
    /** @var string $sometext Some text to show how to pass data to a template. */
    private $sometext = null;

    public function __construct($sometext) {
        $this->sometext = $sometext;
    }

    public function export_for_template(renderer_base $output): stdClass {
        $data = new stdClass();
        $data->sometext = $this->sometext;
        return $data;
    }
}
```

- `renderable` has no methods; `templatable` requires `export_for_template()`.
- `export_for_template()` must return only simple, JSON-serialisable types (`array`, `stdClass`, `bool`, `int`, `float`, `string`, or `Stringable`).
- Constructors do not have a return type; omit the `: void` shown in some
  older upstream snippets.
- To choose an arbitrary template, implement `named_templatable` (extends `templatable`) and add:

```php
public function get_template_name(\renderer_base $renderer): string {
     return 'tool_demo/index_page';
}
```

## Renderers

Plugin renderer with a `render_<name>` method per renderable:

```php
namespace tool_demo\output;

use plugin_renderer_base;

class renderer extends plugin_renderer_base {
    public function render_index_page($page): string {
        $data = $page->export_for_template($this);
        return parent::render_from_template('tool_demo/index_page', $data);
    }
}
```

You do NOT need a renderer/render method if you use templates and either:

1. implement `templatable` and have a template with the same name in the same namespace (e.g. `mywidget` class + `templates/mywidget.mustache`), or
2. implement `named_templatable`.

Then `$OUTPUT->render($widget)` infers the template, calls `export_for_template()` and `render_from_template()` automatically. An explicit `render_<name>` method, if present, wins over the automatic routing. Themers can override renderers and templates to customise output.

## Rendering templates from PHP

```php
$data = [
    'name' => 'Lorem ipsum',
    'description' => format_text($description, FORMAT_HTML),
];

echo $OUTPUT->render_from_template($templatename, $data);
```

Caution: do not name context variables after helpers (`str`, `js`, `pix`, ...) — they will silently fail.

## Template files

- Location: `templates/*.mustache` in a component. Identified as `frankenstyle_component/filename` (no extension): `mod_lesson/timer` → `mod/lesson/templates/timer.mustache`. Sub-directories allowed since 3.8 (first level must follow namespace level-2 naming rules).
- Every template starts with a GPL comment plus a documentation comment:

```handlebars
{{!
    @template plugintype_pluginname/template_name

    Template purpose and description.

    Classes required for JS:
    * none

    Data attributes required for JS:
    * none

    Context variables required for this template:
    * none

    Example context (json):
    {
    }
}}
```

The "Example context (json)" is used by the Template library to preview the template.

## Mustache syntax

- `{{name}}` — variable, HTML-escaped, looked up in current then parent contexts.
- `{{{description}}}` — raw unescaped HTML. Only for values already processed by `format_text()` or similar.
- Sections `{{#key}}...{{/key}}` — hidden when key is false/empty list; repeated per item when key is a non-empty list (context becomes the item); when value is callable (lambda), it is invoked — e.g. calling `core_renderer` methods via `output`:

```handlebars
{{#output.should_display_navbar_logo}}
    <img src="{{output.get_compact_logo_url}}">
{{/output.should_display_navbar_logo}}
```

- Inverted sections `{{^key}}...{{/key}}` — rendered when key is missing/false/empty.
- Comments `{{! ... }}`.
- Partials `{{> core/loading }}` — include another template, sharing the parent's context.
- Blocks (Moodle-enabled BLOCKS pragma): parent template defines replaceable blocks with `{{$name}}default{{/name}}`; a child extends it:

```handlebars
{{< tool_demo/section }}
    {{$heading}} Latest news {{/heading}}
    {{$content}} Today I learned how to use blocks in Mustache! {{/content}}
{{/ tool_demo/section}}
```

- `{{uniqid}}` — generates a page-unique ID prefix; the only acceptable way to use IDs (for one-to-one JS/template links):

```handlebars
<div id="{{uniqid}}-somethingspecific">
</div>
{{#js}}
    callFunction('{{uniqid}}-somethingspecific');
{{/js}}
```

## Mustache helpers

- `{{#str}} helloworld, mod_greeting {{/str}}` — get_string. Optional third param is `$a`:
  - `{{#str}} backto, core, {{name}} {{/str}}`
  - Non-scalar `$a` as JSON: `{{#str}} counteditems, core, { "count": "42", "items": "courses" } {{/str}}`
  - Help icons are NOT a helper: use the `{{>core/help_icon}}` partial.
- `{{#quote}}` — escape variables inserted into `{{#str}}` JSON arguments:
  `{{#str}} counteditems, core, { "count": {{count}}, "items": {{#quote}} {{itemname}} {{/quote}} } {{/str}}`
- `{{#pix}} t/edit, core, Edit this section {{/pix}}` — pix icon: identifier, component, alt text.
- `{{#userdate}} {{time}}, {{#str}} strftimedate, core_langconfig {{/str}} {{/userdate}}` — format a UNIX timestamp with the user's timezone; prefer core format strings via `{{#str}}`.
- `{{#shortentext}} 15, {{{description}}} {{/shortentext}}` — shorten text to a length, word- and HTML-preserving, with trailing ellipsis.
- `{{#js}}...{{/js}}` — JavaScript that must run when the template is added to the page. PHP rendering appends it to the footer after requirejs loads; JS rendering returns it separately. Keep real logic in AMD modules and just load them:

```handlebars
{{#js}}
require(['theme_boost/form-display-errors'], function(module) {
    module.enhance({{#quote}}{{element.id}}{{/quote}});
});
{{/js}}
```

## Rendering templates from JavaScript

```javascript
import {exception as displayException} from 'core/notification';
import Templates from 'core/templates';

const context = {
    name: 'Tweety bird',
    intelligence: 2,
};

Templates.renderForPromise('block_looneytunes/profile', context)
.then(({html, js}) => {
    // Templates object has append, prepend and replace functions.
    Templates.appendNodeContents('.block_looneytunes .content', html, js);
})
.catch((error) => displayException(error));
```

`core/templates` loads and caches templates via AJAX, fetches missing lang strings in one request, and splits JS from HTML. After inserting HTML yourself, run its JS with `templates.runTemplateJS(javascript);`. Report errors with `displayException` from `core/notification`. Other insertion helpers: `Templates.replaceNodeContents(node, html, js)`.

## Context data rules and gotchas

- PHP arrays must be sequentially indexed from 0 to iterate in Mustache; fix with `array_values($myarray)`.
- You cannot portably test "non-empty array": `{{#users.0}}` works only in PHP, `{{#users.length}}` only in JS. Provide a boolean like `hasusers` instead.
- Squash significant whitespace between tags with comments:

```handlebars
<a href="blah">{{!
}}{{icon}}{{!
}}{{name}}</a>
```

- `{{globals.config.wwwroot}}`, `{{globals.config.sesskey}}` etc. (same properties as exposed to JavaScript) are available ONLY in client-side JS rendering, not PHP rendering.

## Overriding templates in a theme

Copy the template into `theme/<yourtheme>/templates/<component>/<name>.mustache` and edit it. Examples:

| Original | Component | Theme override |
| --- | --- | --- |
| `blocks/myoverview/templates/view-summary.mustache` | `block_myoverview` | `theme/mytheme/templates/block_myoverview/view-summary.mustache` |
| `lib/templates/modal.mustache` | `core` | `theme/mytheme/templates/core/modal.mustache` |
| `theme/boost/templates/navbar.mustache` | `theme_boost` | `theme/mytheme/templates/theme_boost/navbar.mustache` |

Templates are cached: purge caches (or use theme designer mode) to see changes.

## Template coding style

- GPL header and documentation comment in every template (override may omit docs if parent's still apply).
- Use data-attributes for JS hooks — not classes (styling only) or IDs (must be unique per page).
- Prefer bootstrap/framework classes over new custom CSS; re-use core templates; wrap each template in one node classed after it (e.g. `<div class="core_user_header">`); lower-case hyphenated class names.
- Core reusable templates: use `{{$block}}` variables around parts callers will want to replace, and split into small partials so includers don't copy internal HTML.

## Building reusable core templates

Core templates should enforce a stable, accessible structure without requiring
callers to provide one exact context shape. Put likely customization points in
Mustache blocks, keep JavaScript coupled to semantic `data-*`/ARIA attributes
rather than DOM nesting or CSS classes, and split repeated items into partials.
This lets a theme or caller change context values without copying the core HTML.

For a reusable component, prefer this progression:

1. Start with one template and a realistic example context.
2. Add blocks around structural regions and repeated content that callers may
   need to replace.
3. Extract repeated pieces into partial templates and expose only small blocks
   such as the item label or item content.

Example pattern for a reusable tabs component:

```handlebars
{{! templates/tabs.mustache }}
<div id="{{uniqid}}-tabs" data-region="tabs">
    {{$tabheader}}
        <ul role="tablist" class="nav nav-tabs">
            {{$tablist}}
                {{#tabs}}
                    {{> mod_example/tab_header_item}}
                {{/tabs}}
            {{/tablist}}
        </ul>
    {{/tabheader}}
    {{$tabbody}}
        <div class="tab-content">
            {{$tabcontent}}
                {{#tabs}}
                    {{> mod_example/tab_content_item}}
                {{/tabs}}
            {{/tabcontent}}
        </div>
{{/tabbody}}
</div>
{{#js}}
require(['jquery', 'core/tabs'], function($, tabs) {
    tabs.create($('#{{uniqid}}-tabs'));
});
{{/js}}
```

The caller can override `tablist` and `tabcontent` blocks while preserving the
component's JavaScript contract. Keep the template's example context in valid
JSON and document every context field, required class, and required data
attribute so the Template library preview remains useful.

## String formatting functions

Always format output through these:

- `s($var, $strip=false)` / `p($var, $strip=false)` — escape `< > " ' &`; `s()` returns, `p()` prints. For form field values and plain user-entered text. `strip=true` only for non-DB (HTTP request) data.
- `format_text($text, $format = FORMAT_MOODLE, $options)` — any html/plain/markdown/moodle text (posts, descriptions...). Cleans dangerous content, applies filters, caches. Formats: `FORMAT_MOODLE`, `FORMAT_HTML`, `FORMAT_PLAIN`, `FORMAT_MARKDOWN`. Key options: `noclean` (never true for user content), `trusted`, `filter`, `context` (always pass the right context — module context for module info etc.), `para`, `newlines`, `overflowdiv`, `allowid`, `blanktarget`.
- `format_string($text, $striplinks = true, ['context' => $context, 'escape' => true, 'filter' => true])` — short non-HTML strings needing filters (activity names, subjects). No cleaning: input must have been cleaned with `xxx_param()`.

Apply filters only at output time (e.g. language filters depend on the viewing user).

## Simple element rendering (renderer methods)

Semantic replacements for `html_writer::tag()`; overridable by component renderers. Use templates for anything complex.

```php
$output->container(string $contents, ?string $classes = null, ?string $id = null): string // <div>
$output->paragraph(string $contents, ?string $classes = null, ?string $id = null): string // <p>
$output->sr_text(string $contents): string // screen-reader-only <span class="sr-only">
```

`classes` is a space/comma-separated string, not an array.

## html_writer essentials

`html_writer` outputs basic HTML tags, typically inside renderer methods. Prefer templates where possible.

```php
html_writer::div('anonymous');                       // <div>anonymous</div>
html_writer::div('kermit', 'frog');                  // <div class="frog">kermit</div>
html_writer::div('Mr', 'toad', array('id' => 'tophat')); // <div class="toad" id="tophat">Mr</div>
html_writer::start_span('zombie') . 'BRAINS' . html_writer::end_span(); // <span class="zombie">BRAINS</span>

html_writer::tag($tagname, $contents, $attributes = null);
html_writer::start_tag($tagname, $attributes = null);
html_writer::end_tag($tagname);
html_writer::empty_tag($tagname, $attributes = null);
html_writer::nonempty_tag($tagname, $content, $attributes = null);
html_writer::attribute($name, $value);
html_writer::attributes($attributesarray);
```

## Progress bars

Standard (renders while page loads; needs `define('NO_OUTPUT_BUFFERING', true);` outside CLI):

```php
$pb = new \core\output\progress_bar('bar', 500);
$pb->create();
$pb->update($current, $total, 'message');
```

Stored (DB-backed, live AJAX updates; usable in CLI or tasks):

```php
$progress = new \core\output\stored_progress_bar('example-cli-bar');
$progress->start();
$progress->update($current, $total, 'message'); // or update_full() to set % directly.
```

In scheduled/adhoc tasks: `use \core\task\stored_progress_task_trait;`, call `$this->start_stored_progress();` then `$this->progress->update(...)`.

## Inplace editable

Mini-API for editing a value in place (e.g. section/activity names). Components:
class `\core\output\inplace_editable` (templatable), template `core/inplace_editable`, JS module `core/inplace_editable`, AJAX web service `core_update_inplace_editable`.

1. Define callback `<component>_inplace_editable($itemtype, $itemid, $newvalue)` in the plugin's `lib.php`. Inside it: `\external_api::validate_context(...)` (system/course/module context), `require_capability(...)`, `clean_param($newvalue, ...)`, update the record, and return a new `\core\output\inplace_editable(component, itemtype, itemid, editable, displayvalue, value, edithint, editlabel)`. The web service only checks login — all capability checks happen in the callback.
2. Where the value is displayed, build the same `inplace_editable` (with `has_capability()` for `$editable`) and `echo $OUTPUT->render($tmpl);`.
3. UI variants: `$tmpl->set_type_select($optionsmenu)` (dropdown; `$value` must be an existing key, `$displayvalue` may be null) or `$tmpl->set_type_toggle([0, 1])`.

JQuery events for success/failure are available via `core/local/inplace_editable/events` (`elementUpdated`, `elementUpdateFailed`).

## Notifications (JS)

Use `core/notification` in JavaScript for error display; the documented pattern is `import {exception as displayException} from 'core/notification';` and `.catch((error) => displayException(error));` on template-render promises.
