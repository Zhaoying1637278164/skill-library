# Backup and Restore API (Moodle 4.5)

Quick reference for including plugin data in course backups (Backup API) and restoring it from backup files (Restore API), per the official 4.5 subsystem docs.

## Concepts

- A **backup plan** consists of **backup tasks**; each task consists of one or more **backup steps**. A plugin developer implements one backup task for the plugin's data.
- Most plugins use a single step: the one that creates the XML file with data from the plugin's tables. Some activities need more (e.g. Quiz uses three steps: quiz settings plus the questions used by the quiz).
- Restore mirrors this: a **restore plan** of **restore tasks**, each with one or more **restore steps**. Most plugins use a single restore step that parses the plugin XML file and puts the data into its tables.
- The backup code organisation differs subtly between plugin types (activity modules, blocks, themes, course reports).

## Backup API — activity modules

### File layout

All backup files live in `backup/moodle2/` inside the plugin folder, e.g. `mod/foobar/backup/moodle2/`:

- `backup_foobar_activity_task.class.php` — the activity task class
- `backup_foobar_stepslib.php` — all backup step classes
- `backup_foobar_settingslib.php` — optional; only if the module declares its own backup settings beyond the core-provided common activity settings. Most modules do not need this.

### Backup task class

`backup_foobar_activity_task.class.php` must provide a single class `backup_foobar_activity_task` extending `backup_activity_task`. Three methods must be defined:

- `protected function define_my_settings()` — add settings defined in `backup_foobar_settingslib.php`. Most modules leave the body empty.
- `protected function define_my_steps()` — typically one or more `$this->add_step()` calls defining the task as a sequence of steps.
- `static public function encode_content_links($content)` — URLs referencing the activity instance (e.g. `http://my.moodle.site/mod/foobar/view.php?id=42`) are not valid after restore elsewhere, so the backup stores them encoded in a transportable form. Restore applies the reverse process, replacing encoded URLs with new ones valid for the target site.

### Backup structure step class

Steps added in `define_my_steps()` are implemented in `backup_foobar_stepslib.php`. Most plugins define a single class `backup_foobar_activity_structure_step` extending `backup_activity_structure_step`, implementing `protected function define_structure()`, which must:

1. Create `backup_nested_element` instances describing the plugin's data.
2. Connect them into a hierarchy with their `add_child()` method.
3. Set data sources on the elements via methods like `set_source_table()` or `set_source_sql()`.

The method must return the root `backup_nested_element` processed by `prepare_activity_structure()` (which wraps your structure in a common envelope).

## Backup API — blocks

### File layout

Files live in `blocks/foobar/backup/moodle2/`:

- `backup_foobar_block_task.class.php` — required
- `backup_foobar_stepslib.php` — only if the block has its own DB tables to back up
- `backup_foobar_settingslib.php` — only if the block declares its own backup settings (rare)

### Block task class

Class `backup_foobar_block_task` extends `backup_block_task`. Five methods must be defined:

- `protected function define_my_settings()` — usually empty.
- `protected function define_my_steps()` — empty if the block has no own tables; otherwise `$this->add_step()` calls.
- `public function get_fileareas()` — returns the array of file area names within the block context.
- `public function get_configdata_encoded_attributes()` — blocks usually store data in the configuration tables (see `instance_config_save()`); this returns the config elements that must be processed before storage, typically ones holding links to embedded media. Most blocks return an empty array.
- `static public function encode_content_links($content)` — encode URLs referencing the block instance; most blocks return `$content` unmodified.

## Backup API — admin tools

Files live in `admin/tool/foobar/backup/moodle2/`. The file `backup_tool_foobar_plugin.class.php` provides a class extending `backup_tool_plugin`. Minimal example from the docs:

```php
require_once($CFG->dirroot . '/backup/moodle2/backup_tool_plugin.class.php');

class backup_tool_foobar_plugin extends backup_tool_plugin {

    protected function define_course_plugin_structure() {
        $this->step->log('Yay, backup!', backup::LOG_DEBUG);
        return $plugin;
    }

}
```

Note the step-level logging call: `$this->step->log($message, backup::LOG_DEBUG)`.

## Backup API — themes and reports

The 4.5 docs only link out to legacy wiki pages ("Backup 2.0 theme data", "Backup 2.0 course report data") without inline content.

## Restore API — activity modules

### File layout

Restore files live in the same `backup/moodle2/` folder as the backup files, e.g. `mod/foobar/backup/moodle2/`:

- `restore_foobar_activity_task.class.php` — the activity task class
- `restore_foobar_stepslib.php` — all restore step classes

The official 4.5 activity-module restore section ends here (the page is marked "(to be continued)").

## Restore API — admin tools

Files live in `admin/tool/foobar/backup/moodle2/`. The class `restore_tool_foobar_task` extends `restore_tool_plugin`. Minimal example from the docs:

```php
require_once($CFG->dirroot . '/backup/moodle2/restore_tool_plugin.class.php');

class restore_tool_foobar_plugin extends restore_tool_plugin {

    protected function define_course_plugin_structure() {
        $paths = array();
        $this->step->log('Yay, restore!', backup::LOG_DEBUG);
        return $paths;
    }

}
```

`define_course_plugin_structure()` returns an array of paths (element paths the step will process); logging is again via `$this->step->log()`.

## Restoring from Moodle 1.x backups

Supported via the separate Backup conversion API (legacy wiki page; not documented in the 4.5 docs tree).

## Coverage note (doc-limited)

The official 4.5 pages for this subsystem are brief quick-references and defer detail to the legacy wiki ("Backup 2.0", "Backup 2.0 for developers", "Restore 2.0 for developers"). The following commonly needed topics are **not covered** by the 4.5 docs and are therefore omitted here rather than reconstructed from memory:

- File/id annotations in backup steps (`annotate_files()`, `annotate_ids()`, `set_source_alias()`, userinfo handling)
- Restore structure step internals: `define_structure()` path definitions, `process_xxx()` methods, `apply_activity_instance()`, id mapping (`get_mappingid()` / `set_mapping()`), `after_execute()` and `add_related_files()` for file restore
- Restore task methods: `define_decode_contents()`, `define_decode_rules()`, `define_restore_log_rules()`
- Backup/restore settings classes (settingslib) beyond the note that they exist and are rarely needed
- Log restore rules and backup logging beyond the single `$this->step->log()` call shown above

For those, consult Moodle core examples (e.g. `mod/label/backup/moodle2/`, `mod/quiz/backup/moodle2/`) or the legacy developer wiki tutorials referenced by the docs.
