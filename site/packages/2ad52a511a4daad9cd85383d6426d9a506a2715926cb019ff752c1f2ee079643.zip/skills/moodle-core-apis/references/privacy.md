# Privacy API (Moodle 4.5)

GDPR compliance for plugins: declare stored personal data, export it, and delete it via a `provider` class.

## Provider class location

Every plugin needs exactly one class:

- Class: `provider` in namespace `\your_pluginname\privacy`
- File: `path/to/your/plugin/classes/privacy/provider.php`
- Implements the relevant metadata interface plus zero, one, or two request interfaces.

## Plugins storing NO personal data: null_provider

For plugins with no external links, no DB tables with user data (incl. IP addresses), and no user preferences (typical: themes, blocks, filters, editors). Note: a plugin that *causes* data to be stored elsewhere (e.g. via the comments subsystem) must NOT use the null provider.

```php
namespace block_calendar_month\privacy;

class provider implements \core_privacy\local\metadata\null_provider {
    public static function get_reason(): string {
        return 'privacy:metadata';
    }
}
```

```php
// lang/en/block_calendar_month.php
$string['privacy:metadata'] = 'The Calendar block only displays existing calendar data.';
```

## Plugins storing personal data

Implement `\core_privacy\local\metadata\provider` (describes data) plus `\core_privacy\local\request\plugin\provider` and `\core_privacy\local\request\core_userlist_provider` (export/delete). All descriptions are lang string identifiers.

### get_metadata

```php
namespace mod_forum\privacy;
use core_privacy\local\metadata\collection;

class provider implements \core_privacy\local\metadata\provider {
    public static function get_metadata(collection $collection): collection {
        // Own database tables.
        $collection->add_database_table('forum_discussion_subs', [
            'userid' => 'privacy:metadata:forum_discussion_subs:userid',
            'discussionid' => 'privacy:metadata:forum_discussion_subs:discussionid',
            'preference' => 'privacy:metadata:forum_discussion_subs:preference',
        ], 'privacy:metadata:forum_discussion_subs');

        // Data stored in a core subsystem (files, ratings, comments, tags, questions...).
        $collection->add_subsystem_link('core_files', [], 'privacy:metadata:core_files');

        // Site-wide user preferences (general name only, without variable suffix).
        $collection->add_user_preference('tool_usertours_tour_completion_time',
            'privacy:metadata:preference:tool_usertours_tour_completion_time');

        // Data sent to an external service (describe the *type* of destination).
        $collection->add_external_location_link('lti_client', [
            'userid' => 'privacy:metadata:lti_client:userid',
            'fullname' => 'privacy:metadata:lti_client:fullname',
        ], 'privacy:metadata:lti_client');

        return $collection;
    }
}
```

### Request provider: required methods

`\core_privacy\local\request\plugin\provider` requires:

- `get_contexts_for_userid(int $userid): contextlist` — where the user has data
- `export_user_data(approved_contextlist $contextlist)` — export it
- `delete_data_for_all_users_in_context(\context $context)` — context expiry
- `delete_data_for_user(approved_contextlist $contextlist)` — right to be forgotten

`\core_privacy\local\request\core_userlist_provider` additionally requires:

- `get_users_in_context(userlist $userlist)` — users with data in one context (no subcontexts)
- `delete_data_for_users(approved_userlist $userlist)` — delete several users in one context

### get_contexts_for_userid

Add SQL returning context ids only (performance matters — this runs across the whole site):

```php
public static function get_contexts_for_userid(int $userid): contextlist {
    $contextlist = new \core_privacy\local\request\contextlist();

    $sql = "SELECT c.id
              FROM {context} c
        INNER JOIN {course_modules} cm ON cm.id = c.instanceid AND c.contextlevel = :contextlevel
        INNER JOIN {modules} m ON m.id = cm.module AND m.name = :modname
        INNER JOIN {forum} f ON f.id = cm.instance
         LEFT JOIN {forum_discussions} d ON d.forum = f.id
             WHERE d.userid = :discussionuserid";

    $contextlist->add_from_sql($sql, [
        'modname' => 'forum',
        'contextlevel' => CONTEXT_MODULE,
        'discussionuserid' => $userid,
    ]);
    return $contextlist;
}
```

Subsystem joins are available, e.g. ratings: `\core_rating\privacy\provider::get_sql_join('rat', 'mod_forum', 'post', 'p.id', $userid)` returns an object with `->join`, `->userwhere`, `->params` to splice into your SQL.

### get_users_in_context

```php
public static function get_users_in_context(userlist $userlist) {
    $context = $userlist->get_context();
    if (!$context instanceof \context_module) {
        return;
    }
    $params = ['instanceid' => $context->instanceid, 'modulename' => 'forum'];
    $sql = "SELECT d.userid
              FROM {course_modules} cm
              JOIN {modules} m ON m.id = cm.module AND m.name = :modulename
              JOIN {forum} f ON f.id = cm.instance
              JOIN {forum_discussions} d ON d.forum = f.id
             WHERE cm.id = :instanceid";
    $userlist->add_from_sql('userid', $sql, $params);
    // Repeat add_from_sql for each table holding user data. No return value.
}
```

### export_user_data

`approved_contextlist` has the user record plus contexts (`get_user()`, `get_contexts()`, `get_contextids()`, or iterate). Export with the writer, always against a context; the `$subcontext` array represents nesting (forum > discussion > post):

```php
use core_privacy\local\request\writer;

writer::with_context($context)
    ->export_data($subcontext, $post)                                    // main data (stdClass)
    ->export_area_files($subcontext, 'mod_forum', 'post', $post->id)     // files
    ->export_metadata($subcontext, 'postread', (object) ['firstread' => $firstread],
        new \lang_string('privacy:export:post:postread'));

// Text fields supporting embedded files must be rewritten:
$post->message = writer::with_context($context)
    ->rewrite_pluginfile_urls($subcontext, 'mod_forum', 'post', $post->id, $post->message);
```

### User preferences

If any site-wide preferences exist, also implement `\core_privacy\local\request\user_preference_provider`:

```php
public static function export_user_preferences(int $userid) {
    $pref = get_user_preferences('markasreadonnotification', null, $userid);
    if (null !== $pref) {
        $desc = $pref ? get_string('markasreadonnotificationyes', 'mod_forum')
                      : get_string('markasreadonnotificationno', 'mod_forum');
        writer::export_user_preference('mod_forum', 'markasreadonnotification', $pref, $desc);
    }
}
```

Context-specific preferences are instead handled in the regular plugin provider (identified in `get_contexts_for_userid`, exported in `export_user_data`, deleted in both delete methods).

### Delete methods

```php
public static function delete_data_for_all_users_in_context(\context $context) {
    global $DB;
    // Called for EVERY expiring context — check it belongs to this plugin.
    if ($context->contextlevel != CONTEXT_MODULE) {
        return;
    }
    $cm = get_coursemodule_from_id('choice', $context->instanceid);
    if (!$cm) {
        return;
    }
    $DB->delete_records('choice_answers', ['choiceid' => $cm->instance]);
}

public static function delete_data_for_user(approved_contextlist $contextlist) {
    global $DB;
    if (empty($contextlist->count())) {
        return;
    }
    $userid = $contextlist->get_user()->id;
    foreach ($contextlist->get_contexts() as $context) {
        $instanceid = $DB->get_field('course_modules', 'instance', ['id' => $context->instanceid], MUST_EXIST);
        $DB->delete_records('choice_answers', ['choiceid' => $instanceid, 'userid' => $userid]);
    }
}

public static function delete_data_for_users(approved_userlist $userlist) {
    global $DB;
    $context = $userlist->get_context();
    $cm = $DB->get_record('course_modules', ['id' => $context->instanceid]);
    $chat = $DB->get_record('chat', ['id' => $cm->instance]);
    [$userinsql, $userinparams] = $DB->get_in_or_equal($userlist->get_userids(), SQL_PARAMS_NAMED);
    $params = array_merge(['chatid' => $chat->id], $userinparams);
    $DB->delete_records_select('chat_messages', "chatid = :chatid AND userid {$userinsql}", $params);
}
```

## Subplugins and subsystem-called plugins

- A plugin *defining* subplugins declares an interface extending `\core_privacy\local\request\plugin\subplugin_provider` (e.g. `\mod_assign\privacy\assignsubmission_provider`) and collects subplugin data itself. Skip this if no data flows to subplugins (e.g. Atto).
- A subplugin implements its parent's interface, e.g. `class provider implements \core_privacy\local\metadata\provider, \mod_assign\privacy\assignsubmission_provider`.
- Plugins only called via a subsystem (e.g. plagiarism) implement that subsystem's provider, e.g. `\core_plagiarism\privacy\plugin_provider`.

## FAQs / edge cases

- Messages/notifications sent: no declaration or export needed (`core_messages` owns them).
- Session data: not declared.
- Only sends data externally, stores nothing locally: declare via `add_external_location_link()` AND implement the request plugin provider with empty methods.
- Stores nothing but writes to logs/another subsystem: implement the metadata provider (subsystem link) only; no request interfaces.
- Multi-branch support (pre-3.5.3): use `\core_privacy\local\legacy_polyfill` trait with underscore-prefixed methods (`_get_metadata`), and conditionally-defined interfaces for `core_userlist_provider`.
- Unit tests: extend `core_privacy\tests\provider_testcase` (not `advanced_testcase` — it does not reset the content_writer between tests).
