# Moodle 4.5 — Other Core APIs Reference

Compact reference for Moodle 4.5 core/subsystem APIs: strings, messaging, navigation, preferences, report builder, custom fields, grading, calendar, admin settings, tags, checks, locking, availability, analytics, backup, groups, user APIs.

## String API (get_string / lang files)

Each plugin defines language strings in `lang/en/<frankenstyle>.php` (e.g. `auth/ldap/lang/en/auth_ldap.php`). Every plugin must define `pluginname`. Lang files must never contain `require_once` or any file inclusion — plain key-value definitions only.

```php
// lang/en/local_myplugin.php
$string['pluginname'] = 'My plugin';
$string['newsectionname'] = 'New name for section {$a}';  // {$a} placeholder

// Usage anywhere:
get_string('pluginname', 'local_myplugin');
get_string('newsectionname', 'format_topics', $sectionname);  // 3rd arg fills {$a}
```

`{$a}` may be a scalar or an object/array (`{$a->name}` style access). In admin trees prefer `new lang_string(...)` (lazy proxy, evaluated only when displayed). Best practice for setting descriptions: `_desc` suffix; help strings: `_help` suffix.

## Message API

`message_send()` (in `lib/messagelib.php`, auto-loaded) sends a message. Register providers in `db/messages.php` (bump plugin version after changes):

```php
// mod/quiz/db/messages.php
defined('MOODLE_INTERNAL') || die();
$messageproviders = [
    'submission' => ['capability' => 'mod/quiz:emailnotifysubmission'], // capability checked at system context
    'posts' => [],                                                     // visible to all users
    'mynotification' => [
        'defaults' => [
            'pop-up' => MESSAGE_PERMITTED + MESSAGE_DEFAULT_ENABLED,
            'email' => MESSAGE_PERMITTED,
        ],
    ],
];
```

Lang strings: `$string['messageprovider:submission'] = 'Notification of quiz submissions';`

```php
$message = new \core\message\message();
$message->component = 'mod_yourmodule';
$message->name = 'mynotification';            // provider name from messages.php
$message->userfrom = core_user::get_noreply_user();
$message->userto = $user;
$message->subject = 'message subject 1';
$message->fullmessage = 'message body';
$message->fullmessageformat = FORMAT_MARKDOWN;
$message->fullmessagehtml = '<p>message body</p>';
$message->smallmessage = 'small message';
$message->notification = 1;                   // 0 only for user-to-user messages
$message->contexturl = (new \moodle_url('/course/'))->out(false);
$message->contexturlname = 'Course list';
$messageid = message_send($message);
```

Since 3.5 notifications live in `mdl_notifications`; user messages in `mdl_messages` + conversation tables. Only `\core\message\message` objects are accepted (since 3.6).

## Navigation API

Three structures on `$PAGE`: `$PAGE->navigation` (main tree), `$PAGE->settingsnav` (settings), `$PAGE->navbar` (breadcrumbs). Generated lazily after `$PAGE` context/course/cm/url are set (usually by `require_login()` / `$PAGE->set_url()`).

```php
// Add nodes in code (e.g. lib.php):
$previewnode = $PAGE->navigation->add(get_string('preview'),
    new moodle_url('/a/link.php'), navigation_node::TYPE_CONTAINER);
$thingnode = $previewnode->add(get_string('thingname'), new moodle_url('/a/link.php'));
$thingnode->make_active();

// Find existing course node and extend:
$coursenode = $PAGE->navigation->find($courseid, navigation_node::TYPE_COURSE);

// Navbar:
$PAGE->navbar->ignore_active();
$PAGE->navbar->add(get_string('preview'), new moodle_url('/a/link.php'));
```

Plugin callbacks in `lib.php` (called automatically):

```php
function {modulename}_extend_navigation($node, $course, $module, $cm);
function {modulename}_extend_settings_navigation($settings, $node);
function local_{pluginname}_extend_navigation(global_navigation $nav);
function local_{pluginname}_extend_settings_navigation(settings_navigation $nav, context $context);
function <component>_extend_navigation_course(navigation_node $parentnode, stdClass $course, context_course $context);
function <component>_extend_navigation_user_settings(navigation_node $parentnode, stdClass $user, context_user $context, stdClass $course, context_course $coursecontext);
function <component>_extend_navigation_category_settings(navigation_node $parentnode, context_coursecat $context);
function <component>_extend_navigation_frontpage(navigation_node $parentnode, stdClass $course, context_course $context);
function <component>_extend_navigation_user(navigation_node $parentnode, stdClass $user, context_user $context, stdClass $course, context_course $coursecontext);
```

Insert before a sibling: `$parent->create(...)` then `$parent->add_node($node, 'siblingkey')`. If the active page isn't matched: `navigation_node::override_active_url(new moodle_url(...))`.

## Preference API

User preferences, stored in DB (session for guests). Operate on current user by default; pass user id/object as last arg. Don't store defaults — apply them in code.

```php
set_user_preference('foo_nameformat', 'long');
get_user_preferences('foo_nameformat');           // 'long'
get_user_preferences('foo_x', 'default');         // with default
get_user_preferences();                           // all prefs as array
set_user_preferences(['foo_displaynum' => '100', 'foo_nameformat' => 'short']);
unset_user_preference('foo_showavatars');
```

## Report Builder API

Entities (reusable column/filter collections) extend `\core_reportbuilder\local\entities\base` and implement `get_default_tables()`, `get_default_entity_title()`, `initialise()`.

```php
// Column (in entity initialise()):
$columns[] = (new column('starttime', new lang_string('task_starttime', 'admin'), $this->get_entity_name()))
    ->add_joins($this->get_joins())
    ->set_type(column::TYPE_TIMESTAMP)
    ->add_field("{$tablealias}.timestart")
    ->set_is_sortable(true)
    ->add_callback([format::class, 'userdate']);

// Filter:
$filters[] = (new filter(course_selector::class, 'courseselector', new lang_string('courses'),
    $this->get_entity_name(), "{$tablealias}.id"))->add_joins($this->get_joins());
```

Filter classes live in `reportbuilder/classes/local/filters/` (text, date, number, boolean_select, select, course_selector, duration, tags, autocomplete, category). Always use `$this->get_table_alias('tablename')` in SQL fragments.

System report — extend `\core_reportbuilder\system_report`:

```php
protected function initialise(): void {
    $entitymain = new task_log();
    $entitymainalias = $entitymain->get_table_alias('task_log');
    $this->set_main_table('task_log', $entitymainalias);
    $this->add_entity($entitymain);
    $this->add_base_fields("{$entitymainalias}.id");  // needed for action :placeholders

    $entityuser = new user();
    $entituseralias = $entityuser->get_table_alias('user');
    $this->add_entity($entityuser->add_join(
        "LEFT JOIN {user} {$entituseralias} ON {$entituseralias}.id = {$entitymainalias}.userid"));

    $this->add_columns_from_entities(['task_log:name', 'user:fullname', 'task_log:starttime']);
    $this->add_filters_from_entities(['task_log:name', 'task_log:timestart']);
    $this->add_action((new action(
        new moodle_url('/admin/tasklogs.php', ['logid' => ':id']),
        new pix_icon('t/download', ''), [], new lang_string('downloadtasklog', 'report_tasklogs'))));
    $this->set_downloadable(true);
    $this->set_initial_sort_column('task_log:starttime', SORT_DESC);
}
```

Custom report data source — extend `\core_reportbuilder\datasource` in the `reportbuilder\datasource` namespace; same `initialise()` pattern plus `get_name()`, `get_default_columns()`, `get_default_filters()`, `get_default_conditions()`; optionally `get_default_column_sorting()`, `get_default_condition_values()`, and `$this->add_all_from_entities()`. Test with `core_reportbuilder_testcase` (`require_once "$CFG->dirroot/reportbuilder/tests/helpers.php"`) and its stress helpers (`datasource_stress_test_columns()` etc.).

## Custom Fields API

Components define handler `<PLUGIN>\customfield\<AREA>_handler` extending `\core_customfield\handler` (autoloaded in `classes/customfield/`). Get via `HANDLERCLASS::create($itemid)` or `\core_customfield\handler::get_handler('core_course', 'course')`.

Instance edit form integration:

```php
$handler->instance_form_definition($mform);
$handler->instance_form_before_set_data();
$handler->instance_form_definition_after_data();
$handler->instance_form_validation();
$handler->instance_form_save($data);   // after save; $data must have id
$handler->delete_instance();           // on instance deletion
```

Retrieving values:

```php
$handler = \core_customfield\handler::get_handler('core_course', 'course');
foreach ($handler->get_instance_data($courseid) as $data) {
    if (empty($data->get_value())) { continue; }
    $shortname = $data->get_field()->get('shortname');
    $value = $data->get_value();
}
```

Also: `export_instance_data()`, `display_custom_fields_data()`, `get_fields()`, `get_categories_with_fields()`. Custom field type plugins live in `/customfield/field/` and must define `field_controller` and `data_controller` classes.

## Advanced Grading API

Entities: grading **area** (managed by `grading_manager`), form **definition** (rules, e.g. rubric criteria, table `grading_definitions`), form **instance** (one per evaluation, `INSTANCE_STATUS_ACTIVE` / `INSTANCE_STATUS_NEEDUPDATE`).

Module support:

```php
function [activityname]_supports(string $feature): ?bool {
    switch ($feature) {
        case FEATURE_ADVANCED_GRADING: return true;
    }
}
// Also define [activityname]_grading_areas_list().

if ($controller = get_grading_manager(...)->get_active_controller()) {
    $controller->set_grade_range(...);
    $gradinginstance = $controller->get_or_create_instance(...);
    // Form element:
    $mform->addElement('grading', 'ELEMENTNAME', '...', ['gradinginstance' => $gradinginstance]);
    // On submit:
    $grade = $gradinginstance->submit_and_get_grade($data->ELEMENTNAME, ...);
    // Display: $controller->render_grade(...);  Preview: $controller->render_preview($PAGE);
}
```

Note: the low-level gradebook API (`grade_update()`, grade items) is documented separately at docs.moodle.org/dev/Gradebook_API, not in the 4.5 devdocs apis tree.

## Calendar API

`require_once($CFG->dirroot.'/calendar/lib.php');`

```php
$event = new stdClass();
$event->eventtype = SCORM_EVENT_TYPE_OPEN;          // your own string identifier
$event->type = CALENDAR_EVENT_TYPE_STANDARD;        // or CALENDAR_EVENT_TYPE_ACTION (+ $event->timesort)
$event->name = get_string('calendarstart', 'scorm', $scorm->name);
$event->description = format_module_intro('scorm', $scorm, $cmid, false);
$event->format = FORMAT_HTML;
$event->courseid = $scorm->course;
$event->groupid = 0;
$event->userid = 0;
$event->modulename = 'scorm';
$event->instance = $scorm->id;
$event->timestart = $scorm->timeopen;
$event->visible = instance_is_visible('scorm', $scorm);
$event->timeduration = 0;
calendar_event::create($event);

// Update / delete:
$event = calendar_event::load($eventid);
$event->update($data);
$event->delete($repeats);
```

Overrides: `$event->priority = null` (normal), `CALENDAR_EVENT_USER_OVERRIDE_PRIORITY` (user override, wins), positive int for group overrides (lower = higher priority).

Action events (shown on dashboard/timeline) — module callbacks:

```php
function mod_xyz_core_calendar_is_event_visible(calendar_event $event): bool;
function mod_xyz_core_calendar_provide_event_action(calendar_event $event, \core_calendar\action_factory $factory) {
    return $factory->create_instance(get_string('enter', 'scorm'),
        new \moodle_url('/mod/scorm/view.php', ['id' => $cm->id]),
        1 /* itemcount */, $actionable /* bool */);   // return null to hide from timeline
}
function mod_xyz_core_calendar_event_action_shows_item_count(calendar_event $event, $itemcount = 0): bool;
```

Drag & drop support: implement `mod_xyz_core_calendar_event_timestart_updated(\calendar_event $event, \stdClass $instance)` (required; update activity dates from moved event) and `mod_xyz_core_calendar_get_valid_event_timestart_range()` returning `[$mindate, $maxdate]` where each is `[timestamp, 'error string']` or null (return `false` to block dragging).

Non-module plugins (3.9+): set `$event->component = 'tool_yourtool'`, `$event->modulename = ''`; site events use `courseid = SITEID`, user events set `userid` with courseid/categoryid 0. Component events can't be edited by users.

## Admin Settings

Tree of `admin_root` → `admin_category` → `admin_settingpage` / `admin_externalpage` → `admin_setting` subclasses (`admin_setting_configtext`, `admin_setting_configcheckbox`, ...). Library in `lib/adminlib.php`; plugin settings go in the plugin's `settings.php`.

```php
// local plugin settings.php
defined('MOODLE_INTERNAL') || die();
if ($hassiteconfig) {   // shorthand for moodle/site:config check
    $settingspage = new admin_settingpage('managelocalhelloworld', new lang_string('manage', 'local_helloworld'));
    if ($ADMIN->fulltree) {   // performance: only build settings when needed
        $settingspage->add(new admin_setting_configcheckbox(
            'local_helloworld/showinnavigation',   // slash => stored in config_plugins, read via get_config()
            new lang_string('showinnavigation', 'local_helloworld'),
            new lang_string('showinnavigation_desc', 'local_helloworld'),
            1));
    }
    $ADMIN->add('localplugins', $settingspage);
}
```

`admin_setting_configtext` constructor: `($name, $visiblename, $description, $defaultsetting, $paramtype = PARAM_RAW, $size = null)`. Names without a slash go to global `config` / `$CFG` — discouraged for plugins.

Activity defaults with lock/advanced flags, plus `$this->apply_admin_defaults();` at end of the mod_form constructor:

```php
$setting = new admin_setting_configcheckbox('assign/teamsubmission', $name, $description, 1);
$setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
$setting->set_locked_flag_options(admin_setting_flag::ENABLED, false);
$settings->add($setting);
```

Post-update callback: `$setting->set_updatedcallback('theme_reset_all_caches');`
External pages: `$ADMIN->add('localplugins', new admin_externalpage('name', $title, $url));` — the page must call `admin_externalpage_setup($pagename)` then use `$OUTPUT->header()/footer()`. Prefer admin_settings over external pages (searchable, CLI-manageable via `admin/cli/cfg.php`, cached, force-able in config.php, config-change logged).

## Tag API

Main classes: `core_tag_tag`, `core_tag_collection`, `core_tag_area` (in `tag/classes/`). A **tag area** = component + itemtype (itemtype must be a DB table name). Define in `db/tag.php` (bump version + upgrade after changes):

```php
$tagareas = [[
    'itemtype' => 'wiki_pages',
    'component' => 'mod_wiki',
    'callback' => 'mod_wiki_get_tagged_pages',
    'callbackfile' => '/mod/wiki/locallib.php',
]];
// Lang string: $string['tagarea_wiki_pages'] = 'Wiki pages';
```

```php
// Form element (auto-hides if area disabled):
$mform->addElement('tags', 'tags', get_string('tags'),
    ['itemtype' => 'wiki_pages', 'component' => 'mod_wiki']);
// Check enabled: core_tag_tag::is_enabled('mod_wiki', 'wiki_pages')
// Save:
core_tag_tag::set_item_tags('mod_wiki', 'wiki_pages', $pageid, $modulecontext, $data->tags);
// Load into form:
$data->tags = core_tag_tag::get_item_tags_array('mod_wiki', 'wiki_pages', $pageid);
// Display:
echo $OUTPUT->tag_list(core_tag_tag::get_item_tags('mod_wiki', 'wiki_pages', $page->id), null, 'wiki-tags');
// Delete:
core_tag_tag::remove_all_item_tags($component, $itemtype, $itemid);
core_tag_tag::delete_instances($component, $itemtype = null, $contextid = null);
core_tag_tag::add_item_tag($component, $itemtype, $itemid, $context, $rawname); // e.g. during restore
```

Use `core_tag_tag::get_items_tags()` for multiple item ids (performance). The search callback (`mod_wiki_get_tagged_pages`) should use `core_tag_index_builder` and return `core_tag\output\tagindex`.

## Check API

Runtime checks (security/status/performance/environment), report at `/report/status/index.php` etc., CLI `php admin/cli/checks.php`. Result states: N/A, OK, INFO, UNKNOWN, WARNING, ERROR, CRITICAL.

```php
// mod/myplugin/classes/check/foobar.php
namespace mod_myplugin\check;
use core\check\check;
use core\check\result;

class foobar extends check {
    public function get_action_link(): ?\action_link {
        return new \action_link(new \moodle_url('/mod/myplugin/dosomething.php'),
            get_string('sitepolicies', 'admin'));
    }
    public function get_result(): result {
        if (some_check()) {
            return new result(result::ERROR, get_string('check_foobar_error', 'mod_myplugin'), $details);
        }
        return new result(result::OK, get_string('check_foobar_ok', 'mod_myplugin'), $details);
    }
}
```

Register via lib.php callback named for the report type: `function mod_myplugin_security_checks(): array { return [new \mod_myplugin\check\foobar()]; }` (also `_status_checks`, `_performance_checks`). Multiple instances need unique `get_id()`. Defer expensive detail lookups to a custom `result::get_details()`. Reuse in settings pages: `$page->add(new admin_setting_check('antivirus/checkantivirus', new \core\check\environment\antivirus()));`

## Lock API

Cluster-safe mutual exclusion (correct, not fast — don't use in hot paths). Always release, even on failure.

```php
$locktype = 'mod_assign_download_submissions';  // namespace, prefix with component
$resource = 'user:' . $USER->id;                // unique resource key
$lockfactory = \core\lock\lock_config::get_lock_factory($locktype);
if ($lock = $lockfactory->get_lock($resource, 5 /* timeout secs */)) {
    // ... exclusive work ...
    $lock->release();
} else {
    throw new moodle_exception('locktimeout');
}
```

Lock backend configurable via `$CFG->lock_factory` (custom implementations implement `\core\lock\lock_factory`).

## Availability API

Controls access to activities/sections. Normally automatic (`require_login` enforces it; forms include the controls). Direct use:

```php
$modinfo = get_fast_modinfo($course);           // optionally pass a userid
$cm = $modinfo->get_cm($cmid);
if ($cm->uservisible) {
    // User can access the activity.
} else if ($cm->availableinfo) {
    // Shown greyed-out with an explanation (HTML).
}
// Section: same properties on section_info. Activity check already includes its section.

// Filter a user list to those who can see the activity:
$info = new \core_availability\info_module($cm);
$filtered = $info->filter_user_list($users);
```

Programmatically set restrictions (JSON in `course_modules.availability`):

```php
$restriction = \core_availability\tree::get_root_json([
    \availability_group\condition::get_json($group->id),
]);
// Or date range:
$dates = [\availability_date\condition::get_json(">=", $start),
          \availability_date\condition::get_json("<", $end)];
$restriction = \core_availability\tree::get_root_json($dates, \core_availability\tree::OP_AND, [true, true]);

$DB->set_field('course_modules', 'availability', json_encode($restriction), ['id' => $cmid]);
rebuild_course_cache($course->id, true);
```

## Analytics API

Prediction models = target + indicators (+ analysis interval). Key classes: `\core_analytics\model` (manages evaluate/train/predict; not extended), analysers extend `\core_analytics\local\analyser\by_course` or site-wide (provide samples via `get_all_samples()`), targets extend `\core_analytics\local\target\base` (the predicted variable, defines insights/actions), indicators extend `\core_analytics\local\indicator\base` (calculated values in range -1..1), analysis intervals extend `\core_analytics\local\time_splitting\base`. Declare default models in the plugin's `db/analytics.php`.

```php
$target = \core_analytics\manager::get_target('\mod_yours\analytics\target\spammer_users');
$indicator1 = \core_analytics\manager::get_indicator('\mod_yours\analytics\indicator\posts_straight_after_new_account_created');
$indicators = [$indicator1->get_id() => $indicator1];
$model = \core_analytics\model::create($target, $indicators,
    '\core\analytics\time_splitting\single_range', '\mlbackend_python\processor');
$model->enable();  // models start disabled
```

## Backup API (brief)

Backup code lives in `<plugin>/backup/moodle2/`. Activity modules provide `backup_foobar_activity_task.class.php` (class `backup_foobar_activity_task` extends `backup_activity_task`; implement `define_my_settings()`, `define_my_steps()` — `$this->add_step()` calls — and static `encode_content_links($content)`), and `backup_foobar_stepslib.php` with `backup_foobar_activity_structure_step extends backup_activity_structure_step` whose `define_structure()` builds `backup_nested_element` instances, links them with `add_child()`, sets sources via `set_source_table()`/`set_source_sql()`, and returns the root wrapped by `prepare_activity_structure()`. Blocks use `backup_foobar_block_task extends backup_block_task` (adds `get_fileareas()` and `get_configdata_encoded_attributes()`). Restore is the mirror API (`backup/moodle2/restore_*`, see Restore API docs).

## Groups API

Functions in `lib/grouplib.php`, prefixed `groups_`. Modes: `NOGROUPS`, `SEPARATEGROUPS`, `VISIBLEGROUPS`. `moodle/site:accessallgroups` bypasses separation. Visibility constants: `GROUPS_VISIBILITY_ALL|MEMBERS|OWN|NONE`; `moodle/course:viewhiddengroups` sees all.

```php
$cm = get_coursemodule_from_id('forum', $id, 0, false, MUST_EXIST);
$currentgroupid = groups_get_activity_group($cm);
$currentgroupname = groups_get_group_name($currentgroupid);

if (groups_get_activity_groupmode($cm)) {
    $groups = groups_get_activity_allowed_groups($cm);
}
groups_print_activity_menu($cm, $url);   // group selection dropdown

// Visibility-safe SQL:
[$visibilitywhere, $visibilityparams] = \core_group\visibility::sql_group_visibility_where($userid);
```

`groups_get_all_groups()` with `$participationonly = true` returns only participation-enabled groups (usually what activities want). Use core functions (`groups_get_members()` etc.) — they respect visibility.

## User-related APIs

- `core_user::get_profile_picture($user, $context, $options)` — options include `size`, `link`, `courseid`, `includefullname`.
- `core_user::get_profile_url($user, $context)`, `core_user::get_fullname($user, $context, $options)` (4.3+).
- Field validation/cleaning: `core_user::validate($data)`, `core_user::clean_data($data)`, `core_user::clean_field($value, $field)`, `core_user::get_property_type($field)` — use these instead of `clean_param()` for user fields.
- User selector widget: subclass `user_selector_base` (`user/selector/lib.php`).
- Always sort user lists with `users_order_by_sql()`.
