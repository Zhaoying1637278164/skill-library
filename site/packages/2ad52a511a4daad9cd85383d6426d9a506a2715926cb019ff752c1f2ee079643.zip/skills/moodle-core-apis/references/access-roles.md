# Access and Roles API (Moodle 4.5)

Scope: contexts, defining capabilities in `db/access.php`, checking capabilities (`has_capability`, `require_capability`, `require_login`), roles, permissions, and archetypes.

## Core model

Moodle uses role-based access control. Entities are represented by **contexts** arranged in a tree (the context tree). A **role** is a set of capability definitions; roles are defined at the System context (top of the tree) and can be overridden in contexts further down. User access is calculated from the combination of roles assigned to the user.

Always ask "Does the user have capability to do something?" — never "Does the user have a role somewhere?".

## Contexts

| Class | Constant | Level | Represents | Immediate contents |
| --- | --- | --- | --- | --- |
| `context_system` | `CONTEXT_SYSTEM` | 10 | The site as a whole (root, only one) | user, course category, module, block |
| `context_user` | `CONTEXT_USER` | 30 | An individual user | block |
| `context_coursecat` | `CONTEXT_COURSECAT` | 40 | A course category | course category, course, block |
| `context_course` | `CONTEXT_COURSE` | 50 | A single course | module, block |
| `context_module` | `CONTEXT_MODULE` | 70 | An activity | block |
| `context_block` | `CONTEXT_BLOCK` | 80 | A block | none |

### Fetching context instances

```php
$systemcontext = context_system::instance();
$usercontext = context_user::instance($user->id);
$categorycontext = context_coursecat::instance($category->id);
$coursecontext = context_course::instance($course->id);
$contextmodule = context_module::instance($cm->id);   // note: cm id, not module instance id
$contextblock = context_block::instance($this->instance->id);

// By context id:
$context = context::instance_by_id($contextid);
```

Notes: by default an exception is thrown if the context cannot be created; deleted users no longer have contexts. Context instances are created/deleted automatically by the system.

## Defining capabilities in db/access.php

Capability names are `plugintype/pluginname:capabilityname`. Define them in the plugin's `db/access.php`:

```php title="mod/folder/db/access.php"
$capabilities = [
    'mod/folder:managefiles' => [
        'riskbitmask' => RISK_SPAM,
        'captype' => 'write',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => [
            'editingteacher' => CAP_ALLOW,
        ],
    ],
];
```

| Key | Meaning |
| --- | --- |
| `riskbitmask` | associated risks (see Risk bitmask below) |
| `captype` | `read` or `write`; the system prevents all write capabilities for guest and not-logged-in users |
| `contextlevel` | typical context level where checked; may be checked at lower levels too (e.g. `moodle/site:accessallgroups` checked with `CONTEXT_MODULE`) |
| `archetypes` | defaults per role archetype, applied on install/upgrade/role reset; use only `CAP_ALLOW` here |
| `clonepermissionsfrom` | copy per-role permissions from an existing capability, e.g. `'clonepermissionsfrom' => 'moodle/quiz:attempt'` |

After any change to `db/access.php`, bump the plugin version number so upgrade scripts run.

Name each capability in the plugin language file (string key `pluginname:capabilityname`):

```php title="mod/folder/lang/en/folder.php"
$string['folder:managefiles'] = 'Manage files in folder module';
```

### Risk bitmask values

- `RISK_SPAM` — user can add visible content, send messages to other users
- `RISK_PERSONAL` — access to private personal information (e.g. backups with user details, hidden email)
- `RISK_XSS` — user can submit content that is not cleaned (HTML with active content, unprotected files)
- `RISK_CONFIG` — user can change global configuration; actions missing sanity checks
- `RISK_MANAGETRUST` — manage trust bitmasks of other users
- `RISK_DATALOSS` — can destroy large amounts of unrecoverable information

Default expectation: Guest role has only risk-free capabilities; Student may add SPAM; Teacher may add PERSONAL and XSS; admins have everything.

### Deprecating a capability

Remove it from `$capabilities` and add it to `$deprecatedcapabilities` in the same file. Optional keys: `replacement` (checks route to the replacement capability) and `message`. Checking a deprecated capability emits a `DEBUG_DEVELOPER` debugging message.

```php title="mod/folder/db/access.php"
$deprecatedcapabilities = [
    'mod/folder:managefiles' => [
        'replacement' => 'mod/folder:newmanagefiles',
        'message' => 'This was replaced with another capability'
    ],
];
```

## Checking capabilities

### has_capability()

```php
function has_capability(
    string $capability,
    context $context,
    object $user = null,
    bool $doanything = true
): bool;
```

```php
$context = context_module::instance($cm->id);
if (has_capability('mod/folder:managefiles', $context)) {
    // Do or display something.
}
```

Defaults to the current user; returns true for admins by default (`$doanything` — not recommended to pass false).

### require_capability()

Same check, but throws an access control exception on failure:

```php
function require_capability($capability, context $context, $userid = null, $doanything = true, $errormessage = 'nopermissions', $stringfile = '')
```

### require_login() and friends

```php
function require_login($courseorid = null, $autologinguest = true, $cm = null, $setwantsurltome = true, $preventredirect = false)
function require_course_login($courseorid, $autologinguest = true, $cm = null, $setwantsurltome = true, $preventredirect = false)
function isguestuser($user = null)
function isloggedin()
function is_siteadmin($user_or_id = null)
function is_guest(context $context, $user = null)
function is_viewing(context $context, $user = null, $withcapability = '')
```

Every plugin page script must call `require_login()` or `require_course_login()` after setting `$PAGE->url`. `require_login()`:

- verifies the user is logged in before accessing any course/activity
- verifies access to hidden courses and activities
- verifies availability restrictions for the given activity (`$cm`)
- verifies the user is enrolled, has `moodle/course:view`, or has temporary guest access from an enrol plugin
- logs course access

`require_course_login()` is only for activities allowing read access to frontpage content without login (viewing resource files, glossary entries, etc.).

`isguestuser()`/`isloggedin()`/`is_siteadmin()` are usually unnecessary — write/risky capabilities are automatically denied to special accounts by `has_capability()`. Using `is_siteadmin()` in activity modules is strongly discouraged; use capabilities and enrolment status.

To access course data, one of these must be true for the user:

- `is_enrolled()` — active record in user_enrolments
- `is_viewing()` — has `moodle/course:view` (access without being a participant)
- `is_guest()` — temporary guest access granted by an enrolment plugin

`get_users_by_capability(context $context, $capability, ...)` returns users holding a capability; it ignores enrolment status and should only be used above the course context.

## Roles, permissions, archetypes

A **permission** is the level at which a capability applies to a role:

- `CAP_INHERIT` — no value set; inherited from a more general context
- `CAP_ALLOW`
- `CAP_PREVENT`
- `CAP_PROHIBIT` — cannot be overridden; prohibit always wins across all the user's roles

Setting a different value for the same capability in a more specific context is an **override**. Roles are assigned to users in a context (e.g. Teacher in a particular course).

Special automatic roles: not-logged-in users get `$CFG->notloggedinroleid`; the guest account gets `$CFG->guestroleid`; all authenticated users get `$CFG->defaultuserroleid`, plus `$CFG->defaultfrontpageroleid` in the frontpage context. None of these can be assigned manually.

### Role archetypes

Archetypes act as templates for roles; a capability's `archetypes` defaults apply to every role based on that archetype:

- **manager** — system-level, manages courses without enrolment
- **coursecreator** — system-level, creates new courses
- **editingteacher** — course-level, grades students and manages the course
- **teacher** — course-level, grades students but cannot add/edit activities
- **student** — course-level participant, completes activities
- **guest** — non-authenticated access; not supposed to change anything
- **user** — assigned to every authenticated user
- **frontpage** — all authenticated users on the site home page

```php
$archetypes = get_role_archetypes();
```

### Rarely needed role functions

Prefer per-user capability checks. In rare cases:

```php
// Roles holding a capability in a context:
[$roleids] = get_roles_with_cap_in_context($context, 'moodle/course:manageactivities');

// Custom enrolment plugin development only:
$ras = get_user_roles($context, $user, $checkparentcontexts);
role_assign($roleid, $userid, $contextid, $component, $enrolmentpluginid);
```
