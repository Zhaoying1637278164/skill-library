# Web Services: Advanced (Routing, Testing, Files) — Moodle 4.5

Covers the 4.5 Routing subsystem (routes, parameters, responses, route testing), unit testing external functions, and file upload/download in web services.

## Routing subsystem (new in 4.5, MDL-81301)

Built on Slim Framework + FastRoute. Routes are classes in a component's `route` L2 namespace, with methods tagged by the `\core\router\route` attribute. The L3 namespace is the route *group*; unknown groups are ignored. Currently supported group:

| Route Group | Namespace | URI Prefix | Purpose |
| --- | --- | --- | --- |
| API | `api` | `/api/rest/v2` | REST Web Services |

Full path = group prefix + component + attribute path. Route groups apply middleware (CORS, input/output sanitisation, path normalisation). Method parameters are resolved via Dependency Injection plus path/query/header parameter resolution. Class-level `route` attributes may define a prefix and defaults but cannot handle a route themselves.

```php
// mod/example/classes/route/api/example.php
namespace mod_example\route\api;

use core\router\schema\response\payload_response;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class example {
    #[\core\router\route(
        // Resolves to https://example.com/moodle/api/rest/v2/mod_example/example
        path: '/example',
    )]
    public function example_route(
        ServerRequestInterface $request,
        ResponseInterface $response,
    ): ResponseInterface {
        return new payload_response(request: $request, response: $response, payload: []);
    }
}
```

Routes may also describe HTTP methods, header parameters, responses, and examples in the attribute.

### Path parameters

Placeholders in the path (`{name}`) must be described in the `pathtypes` array with `\core\router\schema\parameters\path_parameter` instances. Types are cases of the `\core\param` enum (e.g. `param::ALPHANUM`, `param::TEXT`) and validate input before it reaches your method.

```php
#[route(
    path: '/users/{username}',
    pathtypes: [
        new path_parameter(name: 'username', type: param::ALPHANUM),
    ],
)]
public function get_user_information(
    string $username,   // by name...
    array $args,        // ...or via $args['username']
): ResponseInterface {}
```

Optional segments use `[]` braces: `path: '/users[/{username}]'` creates both `/users` and `/users/{username}`. Unspecified optional parameters default to `null` (so a named method parameter must be nullable, e.g. `?string $name`) or to the `default` property of the `path_parameter`. Nest for multiple optionals: `'/users[/{name}/[{pet}]]'`. Everything after the first optional parameter must be optional — `'/users[/{name}]/example'` is invalid. Defaults cannot be set on required parameters.

### Query parameters

Declared in the `queryparams` array with `query_parameter` instances; optional by default, `required: true` to require. Fetch via `$request->getQueryParams()`:

```php
#[route(
    path: '/users/{name}',
    queryparams: [
        new query_parameter(name: 'pet', type: param::TEXT),
        new query_parameter(name: 'type', type: param::TEXT, required: true),
    ],
)]
public function get_user_information(ServerRequestInterface $request, ?string $name): ResponseInterface {
    $params = $request->getQueryParams();
    $params['pet'];
}
```

### Header parameters

Declared in `headerparams` with `\core\router\schema\parameters\header_object` instances. Support `required`, `default`, and `multiple: true` (accept several values). Read with `$request->getHeader('X-Users')` (array) or `$request->getHeaderLine('X-Users')` (comma-separated string).

```php
#[route(
    path: '/users',
    headerparams: [
        new \core\router\schema\parameters\header_object(
            name: 'Filters',
            description: 'Whether Moodle Filters should be applied to text in the response',
            type: param::BOOL,
        ),
    ],
)]
```

### Reusable parameters

Extend the relevant parameter class and implement the empty `\core\router\schema\referenced_object` interface so the OpenAPI generator emits a shared component reference (smaller schema):

```php
// lib/classes/router/parameters/path_themename.php
namespace core\router\parameters;

class path_themename extends \core\router\schema\parameters\path_parameter
    implements referenced_object {
    public function __construct(string $name = 'themename', ...$args) {
        $args['name'] = $name;
        $args['type'] = param::ALPHANUMEXT;
        $args['description'] = 'The name of a Moodle theme.';
        parent::__construct(...$args);
    }
}
```

### Mapped parameters

Implement `\core\router\schema\parameters\mapped_property_parameter` (one method: `add_attributes_for_parameter_value`) to map a raw path value to an object, attached as request attributes of the same name. Prefixes let one parameter accept multiple identifier forms (e.g. course id, `idnumber:...`, `name:...` shortname); use only unique values.

```php
class path_course extends \core\router\schema\parameters\path_parameter implements
    referenced_object,
    mapped_property_parameter
{
    #[\Override]
    public function add_attributes_for_parameter_value(
        ServerRequestInterface $request,
        string $value,
    ): ServerRequestInterface {
        $course = $this->get_course_for_value($value); // throws not_found_exception if missing.

        return $request
            ->withAttribute($this->name, $course)
            ->withAttribute("{$this->name}_context", \core\context\course::instance($course->id));
    }
}
```

Override `get_schema_from_type(param $type)` to add an OpenAPI regex `pattern` describing accepted forms.

### Parameter examples

Any parameter takes an `examples` array of `\core\router\schema\example` instances:

```php
new path_parameter(
    name: 'themename',
    type: param::ALPHANUMEXT,
    examples: [
        new \core\router\schema\example(name: 'The Boost theme', value: 'boost'),
    ],
)
```

### Responses

Routes must return either a PSR-7 `\Psr\Http\Message\ResponseInterface` or a `\core\router\schema\response\payload_response`. Web service routes should almost always return `payload_response`: it is serialised to JSON and validated against the route's response schema (and could support other formats such as XML/YAML). Do not return raw JSON.

```php
return new payload_response(
    payload: ['users' => ['charlie', 'john', 'david']], // Any JSON-encodable array.
    request: $request,   // The ServerRequestInterface passed into the method.
    response: $response, // Provide the passed-in ResponseInterface where possible.
);
```

Add response headers by modifying the response before wrapping it — the body is always replaced by the payload:

```php
$response = $response->withHeader('X-Example', 'This header is added to the Response');
return new payload_response(payload: $data, request: $request, response: $response);
```

### Testing routes

Extend `\route_testcase` (loaded by the PHPUnit bootstrap). `get_router()` returns a fully-configured Moodle Router — containing *all* routes. Prefer the `mocking_route_loader` path: add only the routes under test, **before** calling `get_router()` (routes are injected via DI at router initialisation).

```php
final class my_test extends \route_testcase {
    public function test_example(): void {
        // One route:
        $this->add_route_to_route_loader(my_route::class, 'my_route_method');
        // Or all routes in a class:
        $this->add_class_routes_to_route_loader(my_route::class);

        $router = $this->get_router();

        // Manual request handling:
        $request = $this->create_request('GET', '/path/to/route', route_loader_interface::ROUTE_GROUP_API);
        $response = $router->get_app()->handle($request); // Runs all middleware.

        // Shortcut (create request + router + handle):
        $response = $this->process_api_request('GET', '/path/to/route');
    }
}
```

`create_request()` defaults to the REST API route group; any valid `ROUTE_GROUP` is supported. `process_request()` / `process_api_request()` also accept headers and query parameters. Parameter classes (especially mapped parameters) can be unit tested for validation too.

## Unit testing external functions

One testcase per external function file: `classes/external/get_fruit.php` → `tests/external/get_fruit_test.php`. Extend `externallib_advanced_testcase` after requiring the webservice test helpers:

```php
namespace mod_kitchen\external;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot . '/webservice/tests/helpers.php');

class get_fruit_test extends externallib_advanced_testcase {
    public function test_capabilities(): void {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $cm = $this->getDataGenerator()->create_module('mod_kitchen', ['course' => $course->id]);

        // Assign the capability the function requires.
        $contextid = context_module::instance($cm->cmid)->id;
        $roleid = $this->assignUserCapability('moodle/CAPABILITYNAME', $contextid);

        $returnvalue = get_fruit::execute(['course' => $course->id, 'cmid' => $cm->id]);

        // Clean return values to simulate the web service server.
        $returnvalue = \core_external\external_api::clean_returnvalue(
            get_fruit::execute_returns(),
            $returnvalue
        );
        $this->assertNotNull($returnvalue);
    }

    public function test_capabilities_missing(): void {
        $this->resetAfterTest(true);
        // ...create course/module as above...
        $this->unassignUserCapability('moodle/CAPABILITYNAME', $contextid, $roleid);

        $this->expectException(required_capability_exception::class);
        get_fruit::execute(['course' => $course->id, 'cmid' => $cm->id]);
    }
}
```

Key patterns: `resetAfterTest(true)`, data generators, `assignUserCapability()` / `unassignUserCapability()`, calling `execute()` directly, and always running `external_api::clean_returnvalue()` against `execute_returns()`.

## File handling in web services

Two mechanisms:

1. **Web service functions** — `core_files_get_files()` and `core_files_upload()`; file content is base64-encoded. Not recommended for large files (memory limits on many devices).
2. **Dedicated endpoints** (recommended) — `/webservice/upload.php` (upload) and `/webservice/pluginfile.php` (download), both authenticated by web service token.

### Upload: `/webservice/upload.php`

`POST` with a token; files land in the user's **draft file area**. Optional arguments: `itemid` (default `0` — a new draft item id is generated if unset) and `filepath` (default `/`). To put several files in the same draft area, take the `itemid` from the first upload's response and pass it to subsequent uploads. Returns JSON (file info on success, error message on failure):

```bash
curl -X POST -F "file_1=@users.csv" https://SITENAME/webservice/upload.php?token=TOKEN
# → [{"component":"user","contextid":567,"filearea":"draft","filename":"users.csv",
#     "filepath":"/","itemid":880413555,"license":"allrightsreserved",...}]
```

Then call a web service function (e.g. `mod_assign_save_submission`) with the draft `itemid` so it can process the uploaded files. The service must allow "files download" (Administration > Plugins > Web services > Manage services > Edit service > Advanced); in a `db/services.php` custom service declaration this maps to the `downloadfiles` / `uploadfiles` keys.

### Download: `/webservice/pluginfile.php`

Same URL structure as `/pluginfile.php` and `/tokenpluginfile.php`, but token-authenticated (plain `/pluginfile.php` needs a login session; `/tokenpluginfile.php` also works with an appropriate token). The service must allow "files download".

### Returning file areas from external functions

Use `external_util::get_area_files()` plus the `external_files` structure (returns the common file fields WS clients need):

```php
$forum->introfiles = external_util::get_area_files($context->id, 'mod_forum', 'intro', false, false);

public static function execute_returns(): external_multiple_structure {
    return new external_multiple_structure(
        new external_single_structure([
            'id' => new external_value(PARAM_INT, 'Forum id'),
            'introfiles' => new external_files('Files in the introduction text', VALUE_OPTIONAL),
        ])
    );
}
```
