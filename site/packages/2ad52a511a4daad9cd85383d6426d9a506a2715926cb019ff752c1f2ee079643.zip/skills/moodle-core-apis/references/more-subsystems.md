# More Moodle 4.5 Subsystems

Compact reference for additional Moodle 4.5 core subsystems: Editor, Plagiarism, xAPI, Favourites, Time, Communication, AI, SMS, Question, and Conditional activities/availability — from the consumer (plugin developer) perspective.

## Editor API

Docs are a draft stub; core content is in `lib/editorlib.php`. Normally you do not use this API directly — include an `editor` element in a Moodle form and setup is automatic.

To attach an editor to an existing HTML textarea:

```php
$editor = editors_get_preferred_editor(FORMAT_HTML);
$editor->use_editor('mytextareaid');
```

`use_editor()` accepts an options array:

- `context` — current context object
- `enable_filemanagement` — `false` disables the file management plugin
- `autosave` — `false` disables autosave
- `atto:toolbar` (Atto-specific) — override toolbar buttons

```php
$attobuttons = 'style1 = bold, italic' . PHP_EOL . 'list = unorderedlist, orderedlist';
$editor->use_editor($id, [
    'context' => $context,
    'autosave' => false,
    'atto:toolbar' => $attobuttons
], [
    'return_types' => FILE_EXTERNAL,
]);
```

## Plagiarism API

Docs are a draft stub with no code — an overview of the flow only. The Plagiarism API lets Moodle code send user-submitted content to plagiarism-prevention systems. Supported modules: Assignment, Forum, Workshop.

Flow: (1) when plagiarism tools are enabled, participating modules get extra settings; (2) a user submits content/files; (3) an event is triggered with user/module/submission details; (4) event handlers in the plagiarism plugin process it; (5) hooks display returned information to student and teacher. See legacy docs "Developing a Plagiarism Plugin" and "How to add support for a Plagiarism Plugin to my activity module" on docs.moodle.org/dev.

## xAPI Subsystem (core_xapi)

Not a full LRS — a library so any plugin can handle xAPI statements ("Actor executes Verb on Object") and, since 4.2, states. Webservices: `core_xapi_statement_post`, `core_xapi_post_state`, `core_xapi_get_state`, `core_xapi_delete_state` (each takes a component frankenstyle name).

Key classes: `\core_xapi\handler` (extend it in your plugin as `\PLUGINNAME\xapi\handler`), `\core_xapi\iri`, `\core_xapi\local\statement`, `\core_xapi\local\state`, item classes in `\core_xapi\local\statement\` (`item_agent`, `item_group`, `item_verb`, `item_activity`, `item_definition`, `item_result`, `item_score`, `item_context`, `item_attachment`).

Generate a statement in PHP:

```php
use core_xapi\local\statement;
use core_xapi\local\statement\item_agent;
use core_xapi\local\statement\item_verb;
use core_xapi\local\statement\item_activity;

$statement = new statement();
$statement->set_actor(item_agent::create_from_user($USER));
$statement->set_verb(item_verb::create_from_id('bake'));           // plain string or full IRI
$statement->set_object(item_activity::create_from_id('cake'));
```

Group actors: `item_group::create_from_group(groups_get_group($groupid))`.

Plugin adaptation (statements): extend `\core_xapi\handler` and override
`statement_to_event(statement $statement): core\event\base` (must check permission and return a valid Moodle event to trigger) and optionally `supports_group_actors(): bool`. Every statement MUST map to a Moodle event.

Useful `statement` accessors: `get_user()`, `get_all_users()`, `get_group()`, `get_verb_id()`, `get_activity_id()`, `minify()`, `get_actor()/get_verb()/get_object()/get_context()/get_result()/get_timestamp()/get_attachments()`.

States: build with `new state(item_agent::create_from_user($USER), item_activity::create_from_id('cake'), $stateid, $statedata, $registration)`; handler overrides `validate_state(state $state): bool`. Storage defaults to the `xapi_states` table (customisable via `core_xapi\state_store`). Helpers in `core_xapi\api`: `remove_states_from_component(string $component)`, `execute_state_cleanup()`.

Post from JS via `core/ajax`:

```javascript
require(['core/ajax'], function(ajax) {
    var promises = ajax.call([{
        methodname: 'core_xapi_statement_post',
        args: {component: 'mod_h5p', requestjson: JSON.stringify(statement)}
    }]);
    promises[0].done(function(response) { /* ... */ }).fail(function(ex) { /* ... */ });
});
```

With an array of statements the response is an array of booleans (per-statement success).

## Favourites API (core_favourites, "Starred")

Marks arbitrary items as favourites per user. A favourite is identified by 4 fields: `component` (frankenstyle), `itemtype` (any string unique within the component), `itemid` (any unique int), `contextid` (context in which it is favourited — e.g. course context for courses, user context for personal conversations).

```php
$ufservice = \core_favourites\service_factory::get_service_for_user_context($usercontext);
// Returns \core_favourites\local\service\user_favourite_service.

// Create (core courses use type {'core_course', 'courses'}):
$favourite = $ufservice->create_favourite('core_course', 'courses', $course->id, $coursecontext);

// Delete:
$ufservice->delete_favourite('core_course', 'courses', $course->id, $coursecontext);
```

Read methods on the service:

```php
public function count_favourites_by_type(string $component, string $itemtype, \context $context = null): int;
public function find_favourites_by_type(string $component, string $itemtype, int $limitfrom = 0, int $limitnum = 0): array;
public function favourite_exists(string $component, string $itemtype, int $itemid, \context $context): bool;
public function get_favourite(string $component, string $itemtype, int $itemid, \context $context): favourite;
```

For performance-sensitive SQL, embed favourite info in your own query:

```php
list($favsql, $favparams) = $ufservice->get_join_sql_by_type('core_course', 'courses', 'favalias', 'c.id');
$sql = "SELECT c.id, c.name, favalias.id as favouriteid
          FROM {course} c
       $favsql
         WHERE c.category = :category";
$courses = $DB->get_records_sql($sql, ['category' => 3] + $favparams);
// LEFT JOIN: add "AND favouriteid IS NOT NULL" to keep only favourites.
```

## Time API

Moodle stores all times as Unix timestamps. Distinguish System Time (server, tasks) from User Time (per-user timezone display). Key classes: `\core\clock` (PSR-20, since 4.4, via DI — preferred over `time()` / `new DateTime()`) and `core_date` (DateTimeZone handling).

```php
$clock = \core\di::get(\core\clock::class);
$now = $clock->now();          // \DateTimeImmutable (modifiers return NEW objects)
$ts  = $clock->time();         // current Unix timestamp
$tomorrow = $clock->now()->modify('+1 day')->getTimestamp();
```

Display functions (user time): `userdate` (formats a timestamp for the user; format strings are `strftime()`-style), `usergetmidnight`, `usertimezone`, `make_timestamp`. System time helpers: `format_time`, `dst_offset_on`, `find_day_in_month`, `days_in_month`, `dayofweek`. Legacy, avoid: `usergetdate`, `usertime`.

```php
echo userdate(\core\di::get(\core\clock::class)->time());
// Specific format from core_langconfig:
echo userdate(
    \core\di::get(\core\clock::class)->time(),
    get_string('strftimedaydate', 'core_langconfig'),
);
```

Use `MINSECS`/`HOURSECS`-style constants (lib/moodlelib.php) only for UI option lists — never for date arithmetic (no DST/leap handling); use `\DateTimeImmutable` for calculations. Timezone formats supported: UTC−11..+11, numeric offsets, and named zones (`Australia/Perth`).

## Communication API (core_communication)

Draft docs; experimental feature — enable `enablecommunicationsubsystem` under Site administration > Development > Experimental. Manages provider rooms (e.g. Matrix) and their members. All actions are queued as ad-hoc tasks (no immediate effect), except member deletion when the user is being deleted. Interact only via the public API `\core_communication\api`; core actions reach it through the Hooks API (`communication\hook_listener`, registrations in `lib/db/hooks.php`).

```php
$communication = \core_communication\api::load_by_instance(
    context: $context,
    component: 'core_course',
    instancetype: 'coursecommunication',
    instanceid: $course->id,
    provider: 'communication_matrix',   // optional; defaults to the enabled provider
);

$communication->create_and_configure_room(
    communicationroomname: $course->fullname,
    avatar: $courseimage ?: null,
    instance: $course,
);
```

Other methods (all queue tasks):

- `update_room(?int $active, ?string $communicationroomname, ?\stored_file $avatar, ?\stdClass $instance)`
- `delete_room()` — destructive; removes members then the room
- `configure_room_and_membership_by_provider(provider:, instance:, communicationroomname:, users:, instanceimage:)` — migrate to a new provider
- `add_members_to_room(array $userids, bool $queue = true)`; `update_room_membership(...)`; `remove_members_from_room(...)`; `remove_all_members_from_room()`
- `show_communication_room_status_notification()` — room-creation status UI string
- `form_definition(\MoodleQuickForm $mform, string $selectdefaultcommunication = processor::PROVIDER_NONE)` plus `set_data()` — embed provider/room settings in your form (see `communication/configure.php`)

## AI Subsystem (core_ai, new in 4.5)

Components: **Placements** (UI plugins users interact with), **Actions** (classes describing what to do: `generate_text`, `generate_image`, `summarise_text` in `\core_ai\aiactions`), **Providers** (plugins bridging to external AI), and the **Manager** (`\core_ai\manager`). Golden rule: placements and providers never talk directly — everything goes via the Manager.

Consumer entry point: instantiate an action (constructor always takes a `contextid` plus action-specific args) and pass it to `\core_ai\manager::process_action(base $action): responses\response_base`. The manager picks a provider, logs the call, and returns a `response_<action_name>` object (extends `\core_ai\aiactions\responses\response_base`); read the result with `$response->get_response_data()` (array).

Custom actions must extend `\core_ai\aiactions\base`, implement `__construct()` (with `contextid`) and `store(response_base $response): int` (persist to a table named `ai_action_<action_name>`). Responses implement `set_response_data(array)` / `get_response_data(): array`.

AI User Policy — placements must gate usage on acceptance:

```php
\core_ai\manager::get_user_policy_status(int $userid): bool  // accepted?
\core_ai\manager::user_policy_accepted(int $userid, int $contextid): bool  // record acceptance
```

Webservices for Ajax workflows: `core_ai_get_policy_status`, `core_ai_set_policy_status`.

## SMS Subsystem (core_sms, new in 4.5)

`\core_sms\manager` (fetch via DI) sends messages, fetches them, checks status, and lists gateway plugin instances (plugin type `smsgateway`). Max message length: 480 UTF-8 chars (longer is rejected).

```php
$message = \core\di::get(\core_sms\manager::class)->send(
    recipientnumber: '+61987654321',
    content: 'This is the content of the message',
    component: 'mod_example',
    messagetype: 'demonstrationmessage',
    recipientuserid: $user->id,
    issensitive: false,   // true = content never stored in the log; cannot be async
    async: false,         // async not yet implemented (MDL-81015)
);
```

Always set accurate `component` and `messagetype` for reporting. Fetch and check status (`\core_sms\message`, status is a PHP enum):

```php
$manager = \core\di::get(\core_sms\manager::class);
$message  = $manager->get_message(['id' => $id]);
$messages = $manager->get_messages(['recipientuserid' => $userid]);
$message->is_failed(); $message->is_in_progress(); $message->is_sent(); $message->description();
```

Gateways: `$manager->get_gateway_records()` (optionally filtered, e.g. `['id' => $id]`), `$manager->get_enabled_gateway_instances()`. Hooks `before_gateway_deleted` / `before_gateway_disabled` are dispatched before a gateway is removed/disabled — listen and call `$hook->stop_propagation()` if your component still uses that gateway.

## Question Subsystem

Draft overview doc; two subcomponents:

**Question engine** — runs questions when users attempt them (main consumer: mod_quiz). Plugin types: question types (`qtype_`, define what the question is) and question behaviours (`qbehaviour_`, define interaction flow, e.g. `qbehaviour_deferredfeedback`, `qbehaviour_immediatefeedback`, `qbehaviour_interactive`). Key classes:

- `question_engine` — main entry point
- `question_attempt` — one user's attempt at one question; `question_usage_by_activity` groups related attempts
- `question_state` — tracks per-question state without constraining behaviours
- `question_display_options` — controls what is visible when rendering (behaviours may adjust per state)
- `core_question_renderer` — overall layout, delegating to qtype/qbehaviour renderers

**Question bank** — teacher UI for creating/managing questions. Plugin types: `qbank_` (bank features), `qformat_` (import/export formats, used by `qbank_importquestions`/`qbank_exportquestions`), plus `qtype_` for editing forms.

## Conditional Activities / Availability

The doc covers the pre-2.7 **deprecated** Conditional activities API (`condition_info` in `lib/conditionlib.php`) — replaced since Moodle 2.7 by the Availability API (`apis/subsystems/availability`), which controls access to activities and sections; new code should use that instead. Availability is about *access*; the separate Completion API tracks *progress*.

Legacy `condition_info` methods (for reading old code only): `get_full_course_module()`, `get_full_information()` (human-readable condition summary), `is_available($information, $grabthelot = false, $userid = 0, $modinfo = null)` (does NOT check visibility settings or `viewhiddenactivities` — check those separately), `show_availability()`, `fill_availability_conditions($cm)`, `add_completion_condition($cmid, $requiredcompletion)`, `add_grade_condition($gradeitemid, $min, $max, $updateinmemory = false)`, `update_cm_from_form($cm, $fromform, $wipefirst = true)`, `wipe_conditions()`.

```php
$ci = new condition_info((object) ['id' => $cmid], CONDITION_MISSING_EVERYTHING);
$bool = $ci->is_available($text, false, 0);
```

Gated site-wide by `$CFG->enableavailability`. Custom condition plugins: see the `availability` plugin type docs.
