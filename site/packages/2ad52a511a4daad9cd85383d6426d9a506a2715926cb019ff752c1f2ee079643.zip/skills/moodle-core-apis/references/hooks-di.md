# Hooks, DI, Clock and Deprecation APIs (Moodle 4.5)

PSR-14 hooks (replacement for lib.php one-to-many callbacks), the PSR-11 DI container, the PSR-20 clock, and the deprecation attribute/helper.

## Hooks API (since 4.3)

Replaces lib.php callbacks implemented via `get_plugins_with_function()`, `plugin_callback()`, or `component_callback()`. PSR-14 mapping: Event = Hook, Listener = Hook callback, Dispatcher/Listener Provider = Hook manager.

Naming rules (4.4+): `before`/`after` only as prefixes; subsystem hooks live in that subsystem's namespace (e.g. `\core_course\hook\before_course_visibility_changed`). Hooks placed in any `*\hook\*` namespace are auto-discovered for the admin "Hooks overview" page; otherwise you must provide a `\core\hook\discovery_agent` implementation in class `[component]\hooks`.

### Defining a hook class

Any final PHP class, normally in `some_component\hook\*`. Describe it with attributes (or implement `\core\hook\described_hook` with `get_hook_description()` / `get_hook_tags()`). Use constructor property promotion with readonly properties for data:

```php
// /mod/activity/classes/hook/installation_finished.php
namespace mod_activity\hook;

#[\core\attribute\label('Hook dispatched at the very end of installation of mod_activity plugin.')]
#[\core\attribute\tags('installation')]
final class installation_finished {
    public function __construct(
        public readonly string $version,
    ) {
    }
}
```

### Dispatching

```php
$hook = new \mod_activity\hook\installation_finished('1.0');
\core\di::get(\core\hook\manager::class)->dispatch($hook);
```

(Pre-4.4 style, harder to test: `\core\hook\manager::get_instance()->dispatch($hook);`)

### Registering callbacks: db/hooks.php

```php
// /local/stuff/classes/local/hook_callbacks.php
namespace local_stuff\local;
use mod_activity\hook\installation_finished;

class hook_callbacks {
    public static function activity_installation_finished(installation_finished $hook): void {
        if (during_initial_install()) {
            return;
        }
        if (!get_config('local_stuff', 'version')) {
            return;
        }
        // Do something...
    }
}
```

```php
// /local/stuff/db/hooks.php
$callbacks = [
    [
        'hook' => mod_activity\hook\installation_finished::class,
        'callback' => [\local_stuff\local\hook_callbacks::class, 'activity_installation_finished'],
        'priority' => 500,
    ],
];
```

Notes:

- Array callback notation requires 4.4+; for 4.3 compatibility use string notation `'some\class\name::static_method'`.
- Callbacks run highest priority first, and ARE executed during install/upgrade — guard with `during_initial_install()` / your plugin's version config.
- Registrations are cached: bump the plugin version or purge caches after editing `db/hooks.php`.
- Admins can disable/override callbacks via `$CFG->hooks_callback_overrides` in config.php.

### Stoppable hooks

Implement `Psr\EventDispatcher\StoppableEventInterface` (`isPropagationStopped(): bool`); a callback calls e.g. `$hook->stop()` and later callbacks are skipped.

### Migrating a legacy lib.php callback

1. Create the hook class with `#[\core\attribute\hook\replaces_callbacks('after_config')]` (or implement `core\hook\deprecated_callback_replacement` with `get_deprecated_plugin_callbacks(): array`).
2. At the emit site, pass `$migratedtohook = true` as the 4th argument to `get_plugins_with_function('after_config', 'lib.php', true, true)`, then dispatch the hook immediately after the legacy loop.
3. The hook manager emits deprecation debugging for plugins still using the lib.php callback. A plugin may ship BOTH the legacy callback and the hook callback (for multi-branch support); the legacy one is auto-ignored when a hook callback exists.

### Testing hooks

```php
\core\di::set(
    \core\hook\manager::class,
    \core\hook\manager::phpunit_get_instance([
        'test_plugin1' => __DIR__ . '/fixtures/.../hooks_fixture.php', // a $callbacks array file
    ]),
);
```

## Dependency Injection (since 4.4)

PSR-11 container (PHP-DI) accessed via `\core\di`. Most classes resolve by class name with no configuration.

```php
// Outside classes / legacy code:
$client = \core\di::get(\core\http_client::class);
$manager = \core\di::get(thing_manager::class);

// Inside classes: constructor injection (promoted readonly properties recommended).
class thing_manager {
    public function __construct(
        protected readonly \moodle_database $db,
    ) {
    }

    public function get_things(): array {
        return $this->db->get_records('example_things');
    }
}
```

- Do not inject `\Psr\Container\ContainerInterface` itself; always go through `\core\di`.
- `\core\di::reset_container()` exists but is for unit-test-like situations only (auto-reset between unit tests).
- Mock in tests with `\core\di::set(\core\http_client::class, $mockclient);` — set BEFORE fetching the service that uses it.

Configure complex definitions (rare, legacy) via the `\core\hook\di_configuration` hook: register a callback in `db/hooks.php`, then in the listener call `$hook->add_definition(id: complex_client::class, definition: function (\moodle_database $db): complex_client { ... });`.

## Clock (\core\clock, since 4.4)

PSR-20 clock; use instead of `time()` so tests can mock time.

```php
$clock = \core\di::get(\core\clock::class);
$clock->now();   // \DateTimeImmutable
$clock->time();  // Unix timestamp (Moodle convenience method)

// Preferred: constructor injection.
class post {
    public function __construct(
        protected readonly \core\clock $clock,
        protected readonly \moodle_database $db,
    ) {
    }
}
```

Unit testing helpers on the standard testcase (mock BEFORE fetching your service; DI resets after each test):

```php
$clock = $this->mock_clock_with_incrementing();        // +1s per call; optional start time arg
$clock = $this->mock_clock_with_frozen();              // fixed time; optional time arg
$clock->set_to(12345678);                              // frozen clock: set time
$clock->bump(4);                                       // frozen clock: advance 4s (default 1)
```

Custom clocks: any class implementing `\core\clock`, injected via `\core\di::set(\core\clock::class, $clock)`.

## Deprecation API (since 4.4)

`#[\core\attribute\deprecated]` attribute + `\core\deprecation` helper. Complements (does not replace) the `@deprecated` phpdoc annotation. Applies to classes/traits/interfaces/enums, enum cases, global functions, class constants/properties/methods.

```php
/** @deprecated since 4.3 */
#[\core\attribute\deprecated('random_bytes', since: '4.3')]
function random_bytes_emulate($length) {
    \core\deprecation::emit_deprecation_if_present(__FUNCTION__); // debugging notice
    return random_bytes($length);
}

// Final deprecation -> emit_deprecation_if_present throws an exception.
#[\core\attribute\deprecated(replacement: 'Events API', since: '2.3', final: true)]
function add_to_log() {
    \core\deprecation::emit_deprecation_if_present(__FUNCTION__);
}

// Full argument set:
#[\core\attribute\deprecated(
    replacement: '\core\example::do_something',
    since: '4.3',
    reason: 'No longer required',
    mdl: 'MDL-12345',
)]
public function do_something(): void {}
```

Inspection helpers:

```php
\core\deprecation::is_deprecated(\core\param::INTEGER);            // enum case
\core\deprecation::is_deprecated(\core\task\manager::class);       // class name
\core\deprecation::is_deprecated(new \moodle_url('/example/'));    // instance
\core\deprecation::is_deprecated([\moodle_url::class, 'out']);     // method
\core\deprecation::emit_deprecation_if_present($value);            // notice/exception if deprecated
```
