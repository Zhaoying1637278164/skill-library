# External API / Web Services (Moodle 4.5)

Scope: writing external functions (`\core_external\external_api`), declaring them in `db/services.php`, security (validate_parameters/validate_context/capabilities), calling them from JS via `core/ajax`, and service/protocol overview.

## Overview

Moodle's Web Service framework plus the External API provide self-describing endpoints. Moodle uses them internally for AJAX interactions in the web UI and for integrations. Flow: client authenticates (username/password against a login endpoint, receiving a token), then calls functions through a protocol server which checks access, invokes the external function, and validates the return values against the declared structure before responding. Since 4.5 there is also a routing subsystem exposing REST endpoints under `/api/rest/v2` (see Routing below).

Naming convention for function names: `[frankenstyle_component]_[verb]_[noun]`, verb usually one of get/create/delete/update, noun usually plural — e.g. `local_groupmanager_create_groups`.

## Declaring functions: db/services.php

Functions must be declared in the plugin's `db/services.php`; a service discovery process stores them in the DB during install/upgrade (bump the plugin version after any change).

```php title="local/groupmanager/db/services.php"
$functions = [
    'local_groupmanager_create_groups' => [
        // The name of the namespaced class that the function is located in.
        'classname'   => 'local_groupmanager\external\create_groups',

        // A brief, human-readable, description of the web service function.
        'description' => 'Creates new groups.',

        // Options include read, and write.
        'type'        => 'write',

        // Whether the service is available for use in AJAX calls from the web.
        'ajax'        => true,

        // An optional list of predeclared services where the function will be included.
        'services'    => [
            'myintegration',
        ],
    ],
];
```

Advanced (optional / legacy) keys:

```php
'capabilities' => 'moodle/course:creategroups,moodle/course:managegroups', // advisory list for admins
// No longer recommended:
'methodname'  => 'execute',                          // defaults to 'execute'
'classpath'   => 'local/groupmanager/externallib.php', // do not use with autoloaded classes
'loginrequired' => false, // rare: callable without a session (100% public data only, e.g. core_get_string)
```

### Custom service declarations (rare)

A `$services` array in the same file can pre-build a service; admins cannot add/remove functions from a pre-built service:

```php
$services = [
    'myintegration' => [
        'functions' => ['local_groupmanager_create_groups'],
        'requiredcapability' => 'local_groupmanager/integration:access',
        'restrictedusers' => 0,
        'enabled' => 1,
        'shortname' => '',      // required if restrictedusers is set
        'downloadfiles' => 0,
        'uploadfiles'  => 0,
    ]
];
```

## The external function class

Located in the component's `external` namespace: for `local_groupmanager_create_groups`, class `local_groupmanager\external\create_groups` in `local/groupmanager/classes/external/create_groups.php`. It:

- _must_ extend `\core_external\external_api`
- _must_ declare `execute_parameters()`, `execute()`, and `execute_returns()`
- _may_ declare `execute_is_deprecated()` (return true to mark deprecated)

(For plugins that must also run on Moodle < 4.2: `require_once` `lib/externallib.php` and extend `external_api` instead; deprecation notices for that pathway start in 4.6.)

```php title="local/groupmanager/classes/external/create_groups.php"
<?php

namespace local_groupmanager\external;

use core_external\external_function_parameters;
use core_external\external_multiple_structure;
use core_external\external_single_structure;
use core_external\external_value;

class create_groups extends \core_external\external_api {
    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'groups' => new external_multiple_structure(
                new external_single_structure([
                    'courseid'  => new external_value(PARAM_INT, 'The course to create the group for'),
                    'idnumber'    => new external_value(
                        PARAM_RAW,
                        'An arbitrary ID code number perhaps from the institution',
                        VALUE_DEFAULT,
                        null
                    ),
                    'name' => new external_value(
                        PARAM_RAW,
                        'The name of the group'
                    ),
                    'description' => new external_value(
                        PARAM_TEXT,
                        'A description',
                        VALUE_OPTIONAL
                    ),
                ]),
                'A list of groups to create'
            ),
        ]);
    }

    public static function execute(array $groups): array {
        // Validate all of the parameters.
        [
            'groups' => $groups,
        ] = self::validate_parameters(self::execute_parameters(), [
            'groups' => $groups,
        ]);

        // Perform security checks, for example:
        $coursecontext = \context_course::instance($courseid);
        self::validate_context($coursecontext);
        require_capability('moodle/course:creategroups', $coursecontext);

        // Create the group using existing Moodle APIs.
        $createdgroups = \local_groupmanager\util::create_groups($groups);

        // Return a value as described in the returns function.
        return [
            'groups' => $createdgroups,
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'groups' => new external_multiple_structure([
                'id' => new external_value(PARAM_INT, 'Id of the created user'),
                'name' => new external_value(PARAM_RAW, 'The name of the group'),
            ])
        ]);
    }
}
```

### Describing parameters and returns

- list => `external_multiple_structure`
- object => `external_single_structure`
- primitive => `external_value(PARAM_*, 'description')` — PARAM types are defined in `lib/moodlelib.php` (PARAM_INT, PARAM_TEXT, PARAM_RAW, PARAM_BOOL, ...)
- `execute_parameters()` returns an `external_function_parameters` (empty array if the function takes none); `execute_returns()` describes the return the same way.

Requiredness: third arg of `external_value` is `VALUE_REQUIRED` (default), `VALUE_OPTIONAL`, or `VALUE_DEFAULT` (fourth arg is the default):

```php
'yearofstudy' => new external_value(PARAM_INT, 'year of study', VALUE_DEFAULT, 1979),
```

`VALUE_OPTIONAL` cannot be used on top-level parameters (some protocols are strict about argument counts) — nest optional values inside an `external_single_structure`, or use `VALUE_DEFAULT` at top level.

Return-value validation by the server: undescribed values are skipped; missing `VALUE_REQUIRED` values or type mismatches cause a server error. Cast returned objects to arrays.

## Security inside execute()

1. **Always** validate parameters first — returns validated/cleaned values, throws on missing/malformed input:

```php
$params = self::validate_parameters(self::execute_parameters(), ['groups' => $groups]);
```

Parameters of `execute()` must be in the same order as declared in `execute_parameters()`.

2. **Always** call `self::validate_context($context)` with the _most specific_ context of the data before operating on it (activity context for activity data, course context for course data). For multiple contexts (e.g. a list of courses), validate each one right before producing data for it. It also sets up `$PAGE`/`$OUTPUT`, theme, language, and filters for rendering. Do NOT use `require_login()` or `$PAGE->set_context()` in an external function.

3. Check capabilities with the standard functions: `has_capability()`, `has_any_capability()`, `has_all_capability()`, `require_capability()`, `require_all_capabilities()`.

```php
$context = context_course::instance($group->courseid);
self::validate_context($context);
require_capability('moodle/course:managegroups', $context);
```

Exceptions thrown in `execute()` (e.g. `invalid_parameter_exception`) are handled automatically by the web service servers; put details in `$debuginfo` — generic messages are shown when DEBUG < NORMAL. `$DB->start_delegated_transaction()` / `$transaction->allow_commit()` can wrap multi-record writes so exceptions roll everything back.

## Calling from JavaScript (core/ajax)

Requires `'ajax' => true` in the function's `db/services.php` entry. Convention: put all `core/ajax` usage in a `repository.js` module.

```js title="mod/assign/amd/src/repository.js"
import {call as fetchMany} from 'core/ajax';

export const submitGradingForm = (
    assignmentid,
    userid,
    data,
) => fetchMany([{
    methodname: 'mod_assign_submit_grading_form',
    args: {
        assignmentid,
        userid,
        jsonformdata: JSON.stringify(data),
    },
}])[0];
```

```js
import {submitGradingForm} from './repository';
const response = await submitGradingForm(assignmentId, userId, data);
```

`fetchMany([...])` accepts multiple `{methodname, args}` requests chained in a single HTTP request and returns an array of promises. Considerations:

- Text returned from a web service must be filtered via `external_format_text` / `external_format_string` with the correct (most specific) context.
- Notify filters after adding dynamic content: `M.core.event.FILTER_CONTENT_UPDATED`.
- After changing `db/services.php`, bump the version and run the upgrade or AJAX cannot find the function.
- Session-less calls (rare, public data only): `'loginrequired' => false` in the declaration and pass `false` as the 3rd argument to `call`.

## Protocols and endpoints overview

- Protocol servers validate declared parameters and return values and can build WSDL/other protocol documents from the descriptions.
- Live API documentation for a site: **Site administration > Server > Web services > API Documentation**. New services appear under *Administration > Plugins > Web Services > Manage services* after the version bump/upgrade.
- Dedicated endpoints exist for file upload and download (see the external files-handling docs; custom services opt in via `downloadfiles`/`uploadfiles`).
- **Routing (new in 4.5, MDL-81301)**: REST routes are defined as classes in a component's `route\api` namespace using the `#[\core\router\route(path: '/example')]` attribute on methods; the `api` route group maps to the `/api/rest/v2` URI prefix (full path `/api/rest/v2/{component}{path}`) and applies middleware for CORS, input/output sanitisation, etc. Method parameters are resolved via dependency injection plus path/query/header parameters; return a `core\router\schema\response\payload_response`.
