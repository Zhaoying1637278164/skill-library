---
name: setup
description: Connect this Claude to the user's AI Passport, grant the memory and messaging permissions, and register it as one of their agents. Use when the AI Passport tools are missing, return an authentication error, or the user asks to set up AI Passport.
disable-model-invocation: true
---

# Set up AI Passport

Walk the user through connecting, one step at a time. Wait for each step to finish before the next.

1. Check for Switchboard first. If Switchboard tools or a Switchboard channel are available in this session, Switchboard already handles agent messaging and local sync for the coding agents on this machine. In that case skip steps 4 and 5 below: do not register a second messaging identity through AI Passport. Memory still goes through the AI Passport tools.
2. Connect the `ai-passport` MCP server.
   - In Claude Code: ask the user to run `/mcp`, choose `ai-passport`, and sign in on the AI Passport page with the account that owns their passport.
   - In Cowork: the sign-in prompt appears when the plugin is installed. If it was skipped, ask the user to open the plugin under Customize, then Plugins, open its connector page, and sign in there.
   The server uses OAuth with dynamic client registration, so there is no client id or secret to enter.
3. On the consent page, the user allows memory and, if they want agent messaging, the separate messaging permission. If messaging permission is missing, tell the owner to disconnect and reconnect AI Passport in this app to add it. Relay the returned connectors URL and do not retry the tool call.
4. Call `passport_status`. Report the granted permissions, whether memory is unlocked, and the pending message count. Say plainly which permissions are missing rather than guessing. If messaging permission is missing, relay the reconnect guidance and stop before registration.
5. If messaging is granted and Switchboard is absent, call `passport_register_agent` once with a short `label` such as "Claude Code on <machine or project>" or "Cowork on <machine>", and `runtime` set to `claude-code` or `cowork` to match the host. Repeat calls are safe and return the same agent.
6. Confirm where the user manages things: proposals in the Inbox at https://my.ego.ist/inbox, memory and connector passes at https://my.ego.ist/passes, linked sources at https://my.ego.ist/connectors.

Never approve, grant, or broaden a pass yourself. If a step fails, quote the error and stop; do not retry in a loop.
