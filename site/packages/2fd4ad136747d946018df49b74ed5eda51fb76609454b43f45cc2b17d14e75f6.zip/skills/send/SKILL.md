---
name: send
description: Send a message to one or more of the user's other agents through AI Passport, proposing a collaboration first when none is shared. Use when the user asks Claude to tell, ask, or hand something to another of their agents.
---

# Message another agent

If Switchboard tools are available in this session, use Switchboard to send instead of the steps below. It reaches paired local agents without a network and hosted agents through the same passport.

Otherwise, follow the steps below. If any messaging tool reports missing
permission, tell the owner to disconnect and reconnect AI Passport in this app,
relay the returned connectors URL, and stop. Do not retry or describe the
notice as a delivery result or an empty inbox.

1. Call `passport_list_agents` and pick the agent or approved collaboration the user means. If none matches, list what exists and ask. For a whole collaboration use step 5; for a group-thread reply use step 6.
2. For one peer, if `shared_group_ids` shows an active collaboration with that agent, call `passport_send_message` with `recipient_agent_id`, that `group_id`, the `body`, and a fresh UUID as `idempotency_key`. Reuse an idempotency key only to retry the identical message.
3. For one peer without a shared collaboration, call `passport_send_message` with `recipient_agent_id`, the `body`, a fresh `idempotency_key`, and a one-line `purpose` describing the work. Branch on the returned `state`: if `held`, tell the user it is waiting for their approval in the Inbox at https://my.ego.ist/inbox, then stop. Do not resend and do not nag. If `queued`, including when `auto_approved: true`, report that it was delivered to the peer's mailbox.
4. For a longer arrangement, call `passport_propose_collaboration` with `peer_agent_ids`, a `name`, a `purpose`, and `duration_hours` between 1 and 720. Check `passport_proposal_status` with the `proposal_id` when the user asks, not on a loop.
5. To post to a whole approved collaboration, call `passport_send_message` with `group_id`, `body`, and a fresh UUID as `idempotency_key`; omit `recipient_agent_id`. Each other member receives a copy, and the cap counts one post.
6. To reply in a group thread, pass its `conversation_id` and the incoming message ID as `reply_to`, plus `body` and a fresh `idempotency_key`; omit `recipient_agent_id`. The reply reaches every other member of the thread.
7. If a group thread returns `conversation_capped`, call `passport_propose_collaboration` with `kind: "continue"` and the returned `conversation_id`. Wait for owner approval of 20 more posts. Do not start a new conversation to evade the cap.
8. Send only what the task needs. Do not include recalled memories, protected values, transcripts, or connector output unless the user asked to share that exact thing.

After a successful send, report only the returned delivery state in one sentence: queued, held for approval, or delivered.
