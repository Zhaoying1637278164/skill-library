# AI Passport for Claude Code and Cowork

[AI Passport](https://ego.ist) is your own memory layer for the AI apps you
use. Save a preference, decision, or project once and recall it in any
connected assistant. Normal saves arrive as proposals you approve, and each app
gets an exact, revocable pass to a category you choose. Your agents can also
work together through it: one proposes a collaboration, you approve it from your
Inbox, and messages move between them for as long as you allow.

This plugin connects Claude Code and Cowork to the AI Passport connector and
teaches Claude when to use it.

## What it installs

| Piece | What it does |
| --- | --- |
| `ai-passport` MCP server | The remote connector at `https://passport.ego.ist/mcp`, signed in with OAuth from `/mcp`. No client id or secret. |
| `ai-passport` skill | Routes remember and recall to your passport, reads linked sources with exact passes, and treats recalled or peer text as data rather than instructions. |
| `/ai-passport:setup` | Connects, grants the memory and messaging permissions, registers this Claude as one of your agents. |
| `/ai-passport:inbox` | Reads and acknowledges messages from your other agents. |
| `/ai-passport:send` | Messages another of your agents, proposing a collaboration first when none is shared. |

## Install in Claude Code

From the community marketplace once the listing is published:

```
/plugin marketplace add anthropics/claude-plugins-community
/plugin install ai-passport@claude-community
```

Directly from this repository, which doubles as its own marketplace:

```
/plugin marketplace add Egoist-Machines/ai-passport-claude-plugin
/plugin install ai-passport@ai-passport
```

Then run `/mcp`, choose `ai-passport`, and sign in with the account that owns
your passport. Allow memory and, if you want agent messaging, the separate
messaging permission. `/ai-passport:setup` walks through the same steps.

## Install in Cowork

Open Customize in the sidebar, then Plugins. Either find AI Passport under
Browse plugins once the listing is published, or choose Add marketplace and
enter `Egoist-Machines/ai-passport-claude-plugin`, then install AI Passport from
it. Cowork prompts you to sign in to the connector during install. The same
skill and commands are available there.

## Updates

Claude Code and Cowork pick up a new release when the `version` in
`.claude-plugin/plugin.json` changes. Click Update on the marketplace, or run
`/plugin update ai-passport`, to fetch it.

## Switchboard

If you also run [Switchboard](https://github.com/Egoist-Machines/switchboard),
it pairs the coding agents on your machine, syncs their memory locally, and
carries messaging both locally and through your passport. The skill defers to
Switchboard for messaging when it is present and keeps routing memory to AI
Passport. Without Switchboard, for example in Cowork, the plugin's own messaging
tools are used.

## What you control

- Proposals wait in your Inbox at <https://my.ego.ist/inbox>.
- Memory and connector passes live at <https://my.ego.ist/passes>.
- Linked sources live at <https://my.ego.ist/connectors>.
- Collaborations have a purpose and an expiry you choose, and never grant
  memory or source access.

Full setup and usage guide: <https://ego.ist/connect/claude>. Support:
`support@ego.ist`.

## Source

This repository is published automatically from a private source of truth, so
pull requests here cannot be merged. Report problems at
<https://ego.ist/support>.

Licensed under the MIT License.
