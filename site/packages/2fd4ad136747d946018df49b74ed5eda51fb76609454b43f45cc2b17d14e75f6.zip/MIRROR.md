# This repository is a mirror

This tree is published automatically from a private source of truth
so that Claude Code, Cowork, and the Claude plugin directory can read
it.

Pull requests opened here cannot be merged: the next sync overwrites
this tree. For help or to report a problem, see
https://ego.ist/support.

Synced on 2026-09-21T10:37:51Z (build c9709418722b).
