# Connecting Forms Through MCP

This document is the working contract for an AI agent that edits a static
website through MCP and needs to connect a form managed in Newlogic Online.
The relevant tools are `list-site-forms`, `get-site-form`, and
`create-site-form`. Form metadata must never be guessed or hand-written from
database IDs.

## Invariants

1. A form belongs to the site, not to one version of the site.
2. The form's `public_id` and endpoint are identical for Test, Production, and
   archived versions.
3. Never create a separate copy of a form per site version.
4. Test and production submissions are distinguished automatically by the
   source domain.
5. Only the public endpoint belongs in the static site. Never embed
   credentials, session cookies, or administration APIs.
6. Never guess UUIDs, field keys, or allowed values — always use the current
   metadata of the selected form.
7. Verify the correct namespace and site before any change. The same form slug
   can exist on multiple sites.
8. Creating a form requires an active edit session; the `session_id` proves the
   MCP connection, selected site, and source version server-side.
9. The form definition is not versioned and takes effect immediately for the
   whole site. Abandoning the edit session does not delete a newly created
   form.
10. MCP never returns submissions, e-mail recipients, or other personal data.
11. The default integration is a native HTML form with `action` and
    `method="post"`. JavaScript JSON transport is a deliberate progressive
    enhancement only, for handling the response without leaving the page.

## Required MCP procedure

1. Perform normal site selection via `list-accessible-sites` and `select-site`.
2. Call `get-site-overview` and, when starting from a non-default source,
   obtain the explicit source choice via `list-version-sources`.
3. All HTML work targets Test. Production is a source only.
4. Call `list-site-forms` with the same `site_context`.
5. If exactly one existing form matches, load its exact metadata via
   `get-site-form`. If several could match, ask the user and wait.
6. For a new form, first call `begin-edit-session`, then `create-site-form`
   with the returned `session_id` and the complete ordered field list.
7. Use the endpoint and field keys only from the `get-site-form` or
   `create-site-form` response. Never send a numeric `site_id` or `form_id`.
8. Edit the HTML in the working session and deploy it to Test. The form itself
   belongs to the site; the HTML belongs to the deployed version.

## What to obtain before touching HTML

Safe metadata from `get-site-form` has this shape:

```json
{
  "form": {
    "public_id": "4b603159-9782-4bdb-9716-813c3c9869ae",
    "reference": "kontakt",
    "name": "Kontaktní formulář",
    "slug": "kontakt",
    "is_active": true,
    "scope": "site",
    "versioned": false,
    "effective_immediately": true,
    "fields": [
      {
        "key": "name",
        "label": "Jméno",
        "type": "text",
        "is_required": true,
        "position": 1,
        "options": []
      },
      {
        "key": "email",
        "label": "E-mail",
        "type": "email",
        "is_required": true,
        "position": 2,
        "options": []
      },
      {
        "key": "topic",
        "label": "Téma",
        "type": "select",
        "is_required": true,
        "position": 3,
        "options": ["Obchod", "Podpora"]
      }
    ],
    "integration": {
      "endpoint": "https://space.example/api/v1/forms/4b603159-9782-4bdb-9716-813c3c9869ae/submissions",
      "allowed_origins": [
        "https://bright-harbor.newlogic.space",
        "https://www.paprika.cz"
      ],
      "method": "POST",
      "content_type": "application/json",
      "preferred_transport": "native_html_form",
      "requires_javascript": false,
      "accepted_content_types": [
        "application/x-www-form-urlencoded",
        "application/json"
      ],
      "native_html": {
        "action": "https://space.example/api/v1/forms/4b603159-9782-4bdb-9716-813c3c9869ae/submissions",
        "method": "POST",
        "enctype": "application/x-www-form-urlencoded",
        "field_name_pattern": "data[{field_key}]",
        "honeypot_name": "_gotcha",
        "return_path_name": "_return_path",
        "checkbox_checked_value": "1",
        "success_fragment": "form-success",
        "error_fragment": "form-error"
      },
      "json": {
        "content_type": "application/json",
        "data_envelope": "data",
        "success_status": 202,
        "supports_idempotency_key": true
      }
    }
  },
  "contains_personal_data": false
}
```

Stop and ask for a decision when:

- no namespace or site is selected;
- more than one form matches the name or request;
- the form is inactive;
- the form has no fields;
- the testing domain is missing from `allowed_origins`;
- a field the HTML needs does not exist in the form configuration.

Do not change the form configuration just to match already-written HTML unless
the user explicitly asks for it.

## Field types

Every native control name must have the form `data[{field.key}]`. In JSON, the
keys of the `data` object must match `field.key` exactly. The server rejects
unknown keys in both modes.

| Type | Native HTML | JSON | Constraint |
| --- | --- | --- | --- |
| `text` | string | string | max 1,000 characters |
| `textarea` | string | string | max 10,000 characters |
| `email` | string | string | valid e-mail address, max 254 characters |
| `tel` | string | string | max 100 characters |
| `number` | numeric string | number or numeric string | must be numeric |
| `select` | string | string | exact value from `options`, case-sensitive |
| `checkbox` | checked value `1` | boolean | a required checkbox must be checked; in JSON send `true` |
| `date` | string | string | format `YYYY-MM-DD` |

Omit an empty optional field entirely. Required fields must always be present
and valid.

## Public HTTP contract

### Native HTML form — the default

Build a standard form without a JavaScript submit handler first:

```html
<form
  action="https://space.example/api/v1/forms/4b603159-9782-4bdb-9716-813c3c9869ae/submissions"
  method="post"
>
  <div>
    <label for="contact-name">Jméno</label>
    <input
      id="contact-name"
      name="data[name]"
      type="text"
      autocomplete="name"
      required
    >
  </div>

  <div>
    <label for="contact-email">E-mail</label>
    <input
      id="contact-email"
      name="data[email]"
      type="email"
      autocomplete="email"
      required
    >
  </div>

  <div>
    <label for="contact-topic">Téma</label>
    <select id="contact-topic" name="data[topic]" required>
      <option value="">Vyberte téma</option>
      <option value="Obchod">Obchod</option>
      <option value="Podpora">Podpora</option>
    </select>
  </div>

  <div class="form-honeypot" aria-hidden="true">
    <label for="contact-company-website">Web společnosti</label>
    <input
      id="contact-company-website"
      name="_gotcha"
      type="text"
      tabindex="-1"
      autocomplete="off"
    >
  </div>

  <input type="hidden" name="_return_path" value="/kontakt">

  <button type="submit">Odeslat</button>
  <p id="form-success" class="form-result" role="status">
    Děkujeme, formulář byl odeslán.
  </p>
  <p id="form-error" class="form-result" role="alert">
    Zkontrolujte vyplněná pole a zkuste to znovu.
  </p>
</form>

<style>
  .form-honeypot {
    position: absolute;
    left: -10000px;
    width: 1px;
    height: 1px;
    overflow: hidden;
  }

  .form-result {
    display: none;
  }

  .form-result:target {
    display: block;
  }
</style>
```

Adapt the example to the actual fields and the site's language — never copy
`name`, `email`, or `topic` blindly when they are not in the form metadata.
Visible labels and messages belong in the language of the website.

`_return_path` must be the current page's relative path starting with a single
`/`. It must not contain a domain or `//`. That way the same HTML snapshot
returns safely to the right path on both Test and Production, even when the
browser sends no full `Referer`.

After a successful submission the server redirects the visitor with `303` to
that path on the verified source domain with the `#form-success` fragment;
server-side validation failures use `#form-error`. The browser itself already
validates `required`, `email`, `number`, and `date`. When neither a safe return
path nor a safe `Referer` exists, the server renders a plain HTML status page
instead of redirecting.

Hide the honeypot by moving it off-viewport. Do not use `hidden` or
`display: none`. The native form needs no cookies, CSRF token, bearer token, or
JavaScript. Do not add `enctype="multipart/form-data"` — forms do not support
file uploads.

### JSON — optional progressive enhancement only

JSON transport is available when the user explicitly needs inline server
errors, a no-navigation submit state, or idempotent retries:

```http
POST /api/v1/forms/{publicId}/submissions
Accept: application/json
Content-Type: application/json
Idempotency-Key: <UUID for one logical visitor attempt>
```

```json
{
  "data": {
    "name": "Anna Nováková",
    "email": "anna@example.cz",
    "topic": "Podpora"
  },
  "_gotcha": ""
}
```

A successful JSON response is `202 Accepted` with `accepted: true` and a
`submissionId`. Validation failures are `422` with an `errors` object. A
required JSON checkbox must be a real boolean `true`, not a string. A retry of
the same logical attempt must reuse the same `Idempotency-Key`; a freshly
filled form gets a new UUID.

Do not use `mode: "no-cors"`, cookies, or `credentials: "include"` — the
browser sets `Origin` automatically. Insert error texts into the page as text,
never through unescaped `innerHTML`.

### Error responses

| Status | Meaning | Recommended handling |
| --- | --- | --- |
| `403` | request did not come from an allowed origin | check `allowed_origins` |
| `404` | UUID does not exist or the form is inactive | do not try other UUIDs |
| `422` | invalid or unknown fields | fix the schema or values |
| `429` | too many attempts | allow a later retry |
| `5xx` | temporary server error | offer a retry |

## Safe schema changes

The form configuration is shared by all versions of the site. That is by
design, but it has an important consequence: a restored archived version may
contain older HTML while the server always validates against the current form
schema.

Risky changes:

- renaming a `field.key`;
- deleting a field that older HTML still sends;
- changing values in `select.options`;
- making an optional field required;
- adding a new required field.

Any of these can immediately break Production or a future restore of an
archived version, because the server rejects unknown fields and missing
required fields.

Preferred procedure:

1. Treat existing field keys as a public API.
2. Add a new field as optional first.
3. Update the Test HTML and verify a submission labeled `Test`.
4. Publish the testing version to Production.
5. Make the field required only when it is acceptable that older archived
   versions become incompatible after a restore.
6. When a safe rollback must stay possible, keep the old key and leave the new
   field optional as long as restorable versions with the old HTML exist.

Never present a schema change as a change to one site version — it takes
effect for Test and Production immediately.

## Verification before finishing

Complete the integration only after verifying:

1. The updated HTML is deployed to the testing version.
2. The form submits from the exact testing domain — not from `file://` or a
   random localhost.
3. A native submission returns to `#form-success`; the JSON variant returns
   `202`.
4. The administration shows the new submission under the correct form.
5. The submission's environment is `Test`.
6. All field values match what was sent.
7. An invalid e-mail or a missing required field produces a clear error.
8. With JSON transport, a retry with the same idempotency key creates no
   duplicate.
9. After publishing, the same endpoint stores submissions as `Production`.

An automated integration test can simulate the testing site, for example:

```bash
curl --request POST \
  --url 'https://space.example/api/v1/forms/FORM_PUBLIC_ID/submissions' \
  --header 'Accept: application/json' \
  --header 'Content-Type: application/json' \
  --header 'Idempotency-Key: 745d40a3-8ecb-4dc9-8897-14cca821ec86' \
  --header 'Origin: https://bright-harbor.newlogic.space' \
  --data '{
    "data": {
      "name": "AI integration test",
      "email": "integration-test@example.cz",
      "topic": "Podpora"
    },
    "_gotcha": ""
  }'
```

A test submission is genuinely stored. Never run one against the production
domain without explicit consent, and label the values clearly as an
integration test.

## Limits and current state

- At most 30 fields per form and 50 options per `select` field.
- Maximum submission data payload is 128 kB.
- Rate limits: 30 requests per minute per IP, 10 per minute per form+IP
  combination, 120 per minute per form.
- Payloads and the historical field snapshot are stored encrypted.
- The public endpoint only accepts submissions. It cannot read them or change
  the form configuration.

## MCP tool contract

- `list-site-forms` requires `site_context` and returns a safe summary for the
  selected site only.
- `get-site-form` requires the same `site_context` plus the slug or
  `public_id` returned by the list. It returns the native HTML integration as
  the preferred transport and JSON metadata as a compatible fallback.
- `create-site-form` requires an active `session_id` and creates the form, all
  fields, and two default disabled e-mail templates in one transaction.
- No tool accepts numeric site or form IDs.
- No tool returns submissions, e-mail recipients, or internal database IDs.
- MCP provides no tool for sending a test submission; verify through the
  public endpoint from an allowed testing origin only.

## Agent checklist

- [ ] Namespace and site are confirmed.
- [ ] The session source is the default Test or an explicit user choice.
- [ ] I am using an existing active form of the correct site, or created a new
      one through an active `session_id`.
- [ ] I have the current `public_id`, endpoint, `allowed_origins`, and the
      complete field schema.
- [ ] Native names use `data[{field.key}]`; JSON keys match `field.key`
      exactly.
- [ ] Submission is primarily native `action` + `method="post"` without
      JavaScript.
- [ ] No unknown fields and no secrets in client-side code.
- [ ] `_gotcha` is a hidden honeypot and normally stays empty.
- [ ] With the JSON fallback, one retry keeps the same `Idempotency-Key`.
- [ ] Native status fragments or JSON statuses are handled correctly.
- [ ] The integration is verified on the testing domain and the submission is
      labeled `Test`.
- [ ] The schema change breaks neither Production nor a required rollback.
