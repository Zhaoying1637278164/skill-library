---
name: newlogic-online
description: Edit, build, and deploy static websites hosted on Newlogic Online through its MCP server. Use whenever the user wants to change, create, preview, or publish a website managed by Newlogic Online — discover accessible sites, run an edit session, download and rebuild a project or edit files directly, deploy to Test, upload media, connect site forms, manage backups and rollback, or publish to Production.
---

# Newlogic Online — Website Editing Playbook

Newlogic Online hosts static websites so the owner never deals with hosting: they point a domain at the platform and manage everything else here. Agents edit those websites through this MCP connection. Respond in the user's language — this skill is written in English, the conversation is not.

Every site has two environments. **Test** is where all work lands and where the user previews changes on the site's testing domain. **Production** is the live site on the user's own domain; it changes only through the explicit `publish-to-production` tool, never as a side effect of anything else.

There are two kinds of sites, reported as `requires_local_build` by `get-site-overview`:

- **Build sites** — the stored project contains sources, configuration, lockfile, and build output together. You download the whole project, edit sources locally, run the build, and upload the whole tree back. Requires a shell and a local toolchain.
- **Static sites (no build step)** — files are served as-is. You edit individual files in a server-side workspace through tool calls alone, so even a plain AI chat with MCP can do this work.

## Ground rules

- No connection, no work: every action in this skill happens through the Newlogic Online MCP server. If its tools are missing or unauthenticated, stop and get the user signed in first (step 0) — never continue as if the connection worked.
- Work fast and don't ask unnecessary questions. The kickoff questions below go in **one message**; after that, iterate without interrupting the user.
- MCP is orchestration only. Project archives travel out of band over signed HTTP URLs, never through tool calls.
- Never request, infer, or send a numeric ID. Use only the references, contexts, hashes, and session IDs the tools return, and never invent or reuse them across connections.
- One connection is the connected user's access within one namespace — not one site, and not every site. Never choose among multiple matching sites for the user.
- Whenever a site project is handled locally, keep every local project artifact inside the current working directory captured at the start of the workflow. Never use a system temporary directory or any path outside that directory for downloads, extraction, editing, dependency installation, builds, or upload staging.
- On build sites, treat the served output as generated. Except for a genuinely minor copy-only text substitution, change the sources and run the project's build; never use hand-editing both the sources and generated output as the normal implementation path.
- Always upload the **complete project tree** exactly as it exists on disk — sources, configuration, lockfile, and build output together. Never upload only the build directory.
- Every upload must be built from the tree unpacked from **this session's** `create-source-download` (or created fresh in a `start_from_scratch` session). Never edit, build, or upload a pre-existing local copy, however identical it looks — the platform may hold a newer version than the local disk, and deploying the local tree would silently push files that were never part of the current Test. The only exception is a site whose Test is **empty** because nothing was ever deployed: there is no server version to be stale against, so the local project the user wants to deploy is uploaded as it stands.
- `node_modules`, `.git`, and real `.env` files are silently dropped from uploads and reported back as `skipped_paths`. A deployed `.env` would be publicly served, so keep secrets out of the project tree; templates such as `.env.example` stay in.
- Media lives in the site's Files module, outside the versioned project. Insert the exact returned URL into the code.
- Forms are site-scoped and effective immediately, not versioned files. Never read or expose form submissions, e-mail recipients, or other personal data.
- Never reveal, log, commit, or paste the bearer token anywhere.

## Workflow

### 0. Verify the MCP connection first

Before anything else, confirm the Newlogic Online MCP tools are actually available — `list-accessible-sites` must exist in your tool list and respond. The connection is missing or logged out when the server's tools are absent, when calls fail as unauthenticated/unauthorized, or when the MCP initialization itself fails.

In that case **stop immediately** and say plainly that the Newlogic Online MCP server is not connected or not authenticated:

- If your client can trigger the MCP authentication flow (OAuth login for this server), start it right away.
- Otherwise tell the user exactly what to do in their client — e.g. `/mcp` in Claude Code, the connector settings in Claude, or the MCP/plugin settings of their tool — and wait until the tools appear.

Never mask a missing connection: do not ask what the user wants to edit as if everything worked, do not answer from memory, and do not fall back to editing local files — without the connection nothing can reach the website.

### 1. Discover and select the site

Call `list-accessible-sites` before any other site or version tool.

- **Zero sites:** stop and tell the user this connection has no available website.
- **One site:** call `select-site` with its `reference` and `selection_reason: only_accessible_site`. Do not ask.
- **Multiple sites, and the request uniquely names one** (by name, domain, or reference): select it with `selection_reason: user_selected`.
- **Multiple sites, ambiguous:** list the relevant choices, ask, and wait. Never prefer the first, newest, or any other default.

Keep the returned opaque `site_context`. It is short-lived and bound to this connection — never reconstruct or reuse it. For work across multiple websites, repeat discovery and selection per site and never mix their contexts, hashes, or session IDs.

If the user explicitly wants a **brand new website**, call `create-site` (name, optional `production_domain`, and `public_directory` for a build project). It returns a `site_context`, so skip discovery. Never create a site speculatively — deleting one is an administration-only action.

Call `get-site-overview` with the `site_context`, confirm the site is the one the user meant, and note `requires_local_build` and `public_directory`.

### 2. Source decision (usually implicit)

`begin-edit-session` defaults to the current Test — for a normal edit request, that is correct and needs no question. Call `list-version-sources` and ask only when the user wants to start from somewhere else: Production or a named backup (`source_hash`), or an explicitly empty start (`start_from_scratch: true`).

One case resolves itself without asking: when the site has **no deployed version yet** (a brand-new site, empty Test), start with `start_from_scratch: true` — there is nothing to download, and a project the user already has on disk is simply what gets uploaded. On a site that **does** have deployed content, the normal source rules stay in force even when the user says the project already exists locally: the platform may hold a newer version than the local disk, so the session still starts from Test and the download still happens.

### 3. Start the session and ask the kickoff questions — one message

Call `begin-edit-session` with the `site_context`, a concise `intent`, and `source_hash`/`start_from_scratch` only when the user chose one. Record the returned `session_id` and expiry.

Then ask everything that needs asking **in a single message**, and only what applies:

1. **Browser preview** — first inspect the available capabilities; do not assume browser control is unavailable merely because its skill or tool has not been loaded yet. If browser control is available and the user has not already requested or declined preview, offer to open the site's testing URL. If the user already requested preview, open Test immediately without asking again. If the user accepts the offer, invoke browser control in the same next turn; do not merely promise to open Test, and do not claim it is open until the browser action succeeds. If browser control is unavailable or the user declined it, preview is resolved and you will share the testing URL after each deploy instead.
2. **Backup** — only if the response reports `backup_recommended: true`, ask whether to save the current Test with `create-backup` first, or whether this is a minor change and no backup is needed. Ask **at most once per conversation**; never repeat it for later iterations or follow-up sessions, and never ask when the flag is false (the server already suppresses it when the current Test comes from your own recent deploy). Never ask it when Test is empty or the site has never been deployed — an empty version holds nothing worth backing up, so skip the question even if the flag were true.
3. **Unfinished Test changes** — only if the response reports `unpublished_test_changes: true`: Test differs from the published Production, someone left unfinished work there. Unless the user is knowingly continuing it, ask whether to continue with the unfinished changes or replace Test with a copy of Production via `restore-version-to-test` with the Production hash from `list-version-sources` — a single server-side call, never a download/upload round trip. Never discard Test content on your own.
4. **Session takeover** — if the response reports another active session, show its start time and intent; send `take_over_session_id` only after explicit confirmation.

If any item applies, ask all applicable questions in the one kickoff message and wait for the user's answer. Do not call any edit-loop tool from step 4 or 5 until every applicable kickoff item is resolved. Browser preview is resolved only when browser control is unavailable, the user declined it, or the requested browser-open attempt has completed.

These four items are the **complete** kickoff list — do not pad session start with invented confirmations (such as backing up an empty Test); they stall the work for nothing. This restraint applies to the kickoff only. Questions that other steps of this skill explicitly call for are still required — an ambiguous site selection, clearing a non-empty directory before unpacking, choosing which backup to delete when the limit is full, confirming a publish to Production — and when a step is genuinely ambiguous or destructive and no rule here covers it, asking the user remains the right call.

Session-start complications never replace the kickoff: after a takeover, an unfinished-changes decision, or a Test restore, still send the kickoff message with every remaining applicable item — the browser-preview offer is the one most often lost this way.

If none of them applies, ask nothing and start editing immediately.

### 4. Edit loop — build sites (shell required)

The goal is that the user sees a result on Test as soon as possible. Download immediately, edit, upload back:

1. Before downloading, capture the process's current working directory — it becomes the **project root** for the entire workflow. The project unpacks **directly into it**, never into a dated or nested subdirectory:
   - **Empty directory** (or containing only `.git`/`.idea`): unpack straight into it without asking.
   - **Holds anything else — including what looks like this very project from earlier work:** ask whether you may clear it (everything except `.git` and `.idea`) before unpacking, or let the user point you to a different directory. Never clear or overwrite silently, and never edit the leftovers instead of unpacking.
   - **Exception — `start_from_scratch` sessions.** With no source there is no download and nothing to unpack, so the two rules above do not apply: never ask to clear the directory and never delete anything in it — build and upload the project the user wants to deploy exactly as it sits on disk. This changes nothing about when `start_from_scratch` is allowed (step 2): automatic only on an empty Test, otherwise only on the user's explicit choice.

   The download **and unpack are mandatory at the start of every session** on a site with deployed content and have no substitute. A leftover local tree — however identical it looks — may be stale: Test changes between sessions through other sessions, restores, and rollbacks, and uploading such a tree would silently deploy files that were never part of the current Test. Calling `create-source-download` without actually fetching and unpacking the ZIP counts as skipping it. A `start_from_scratch` session skips the download (there is nothing to fetch), and so does a site whose Test is still empty; within one session, iterate on the tree you unpacked — a new session downloads again.

   Fetch the URL with a single HTTP GET, unpack, and delete the downloaded archive immediately. Everything — extraction, dependency installation, build output, upload staging — stays inside this directory. Never use `/tmp`, `/private/tmp`, `$TMPDIR`, or any other outside path, even for staging; if the directory is not writable, stop and explain instead of silently falling back elsewhere.
2. Follow the project's own toolchain: the lockfile picks the package manager (`package-lock.json` → npm, the most common; `pnpm-lock.yaml` → pnpm; `yarn.lock` → yarn; `bun.lock`/`bun.lockb` → bun), and `package.json` `engines` or `.nvmrc` pick the runtime version when present. The default path is to install dependencies once per session, edit the sources, and run the build script defined by `package.json`. Manually applying the same change to both sources and the generated `public_directory` is allowed only for a genuinely minor literal text substitution that changes no markup, styling, behavior, assets, configuration, dependencies, generated filenames, or source maps. If there is any doubt, install and build. For every other change, never hand-edit generated output; if installation or the build fails, diagnose it or report the blocker instead of silently falling back to duplicate source/output edits without the user's explicit approval.
3. `create-upload-ticket`, then pack and HTTP PUT the **entire project tree**. Pack from inside the project root so the archive root is the project root — `zip -r out.zip <folder>` would add a wrapper folder and break the deploy:

   ```bash
   zip -qr .newlogic-upload.zip . -x '.newlogic-upload.zip' -x '.git/*' -x 'node_modules/*'
   curl --fail -sS -T .newlogic-upload.zip '<upload_url>'
   rm .newlogic-upload.zip
   ```

   Delete the archive right after the PUT and never leave `*.zip` artifacts in the project directory. Send `Content-Length` (curl's `-T` does); the server compares it against what arrived, so a dropped connection fails loudly instead of storing a truncated archive. A failed upload burns the ticket — request a new one and retry.
4. `deploy-to-test` with the same `upload_id` and a short description of the iteration.
5. Report the result (step 6), then repeat from step 2 in the same still-active session.

A session started from scratch has no source and refuses the download — use the project already in the working directory (or create one there) and go straight to the upload.

If the environment has **no shell** and the site requires a build, say so: sources cannot be rebuilt here, so source edits would not be visible. Do not pretend otherwise and do not misuse `public_directory` to fake a build.

### 5. Edit loop — static sites (works from plain chat)

Edit only the relevant files directly in the server-side workspace — no download or upload involved:

1. `get-edit-manifest` — returns the file list and a `revision`. Files are marked `text` or `binary_asset` by inspecting their actual bytes, not their extension: any UTF-8 file is editable, including `.svg`, `.gitignore`, or `Dockerfile`.
2. `read-edit-files` for just the files you need.
3. `apply-edit-changes` with `upserts`/`deletes` and the `expected_revision` from the latest manifest, so a concurrent change fails loudly instead of being overwritten.
4. `deploy-to-test` **without** `upload_id`.

This path carries file content inside tool calls, so it handles text only. A binary file can only be kept or explicitly deleted — replace binaries through the Files module or the full-project ZIP path. Shell-capable agents may still use the ZIP path for large refactors; for small text edits, file-by-file is the fastest route.

### 6. After every deploy

`deploy-to-test` returns `testing_url`, `testing_version_hash`, `skipped_paths`, and `rollback_available`.

- Share the testing URL and state that Production is untouched.
- If a browser preview is open, reload it. The preview always shows Test — never preview changes on Production.
- Report `skipped_paths` when non-empty so the user knows what was left out.
- Keep iterating in the same session without re-asking about source, backup, or preview.
- When the deploy completes what the user asked for and you are handing the turn back, end that same message with the wrap-up guidance from step 7. Never end a finished task with a bare deploy report.

### 7. Wrap-up — only when the requested batch is done

Do **not** ask closing questions between deploys while you are still working through one request. But **every** message that hands the turn back with the requested work finished must end with this guidance, in one message:

1. Any further changes?
2. Publish the current Test to Production now?
3. Or is everything done, so the edit session can be closed?

Call `close-edit-session` only when the user explicitly says the work is finished or when switching to another website. Otherwise keep the session open between tasks — sessions expire on inactivity by themselves, and `deploy-to-test` never closes one.

### 8. Publishing to Production

Publish only after an explicit yes — offering it in the wrap-up is fine, publishing without confirmation is not.

- A production domain must be set first. If missing, offer `update-site-settings` and explain that the domain's DNS must point at the platform — the vhost and certificate are created when a signed-in user publishes. Link the help article: <https://outline.newlogic.cz/doc/domeny-8qzrkAiQ1B>.
- When Production already has content, ask whether to keep it as a backup and pass an explicit `backup_current_production` — a kept release counts into the shared backup limit.
- Call `publish-to-production` with the `session_id` and the `testing_version_hash` from the latest deploy as confirmation. It publishes the current Test, leaves Test unchanged, and keeps the session active. Report the returned production URL.

### 9. Media

Call `upload-media-file` for images, video, audio, fonts, PDFs, and archives: `session_id`, file `name`, `content_base64` (max 10 MB decoded), and a stable UUID `upload_key` so a retry of the same upload is safe. Insert the **exact returned URL** into the code.

Media lives outside the project snapshot: a downloaded project ZIP never contains it, a missing local file is not a broken reference, and an uploaded file must not be copied into the project tree — reference it by URL. If the user deletes it in the administration, the link stops working; that is expected, not a defect to repair.

### 10. Forms

Read [the forms integration reference](references/forms-integration.md) completely before changing or connecting a form. The essentials:

- `list-site-forms` with `site_context`; one unique match → `get-site-form` with its slug or `public_id`; multiple candidates → ask and wait. Never guess identifiers.
- `create-site-form` only inside an active edit session, with the complete ordered field schema. Creating a form changes the site-wide schema immediately and is not undone by abandoning the session.
- Default to the native HTML form: the returned `native_html.action` with `method="post"`, field names `data[{field.key}]`, checkbox checked value `1`, the `_gotcha` honeypot, `_return_path` as a relative path starting with one `/`, and `#form-success` / `#form-error` status fragments. JSON transport is an explicitly requested enhancement only.

### 11. Site settings

`update-site-settings` changes only the site `name` (cosmetic) and `production_domain`. Omitted fields stay unchanged, and neither touches files, versions, or backups. Identify the site with `site_context`, or with `session_id` while a session runs — the session outlives the shorter-lived context. A production domain can be set or replaced but **never cleared** through MCP.

`public_directory` is **not** a site setting — it is a per-version routing detail naming the folder nginx serves inside the deployed project. Change it via the `public_directory` parameter of `deploy-to-test` (for example `dist` for a build project, `/` for a plain static site). It only reconfigures routing and never moves, deletes, or invalidates any stored file, version, or backup.

### 12. Backups and undo

- `create-backup` saves the current Test; with `environment: production` it saves the current Production instead — pass that only on explicit request. Backups from both environments share one limit of six and are never rotated silently. When full, show the returned list and call `delete-backup` only for the exact backup the user chooses.
- `rollback-test` swaps Test with the single internal rollback slot. Calling it again redoes the swap, so it undoes exactly one deploy.
- `restore-version-to-test` replaces Test server-side with a copy of Production or a backup by its hash — one call, no download/upload round trip. The previous Test lands in the rollback slot.

### 13. Recover from interruption

Resume an unexpired session only with its recorded `session_id`. For file-by-file work, refresh the manifest (and `revision`) before writing; for the ZIP path, request a new upload ticket. If the session or site context expired, access changed, or an identifier is missing, restart from `list-accessible-sites` and obtain a fresh source decision.

## Tool quick reference

| Tool | Purpose |
| --- | --- |
| `list-accessible-sites` | List sites visible to this connection; always the first call |
| `select-site` | Lock onto one site; returns the short-lived `site_context` |
| `get-site-overview` | Site details incl. `requires_local_build` and `public_directory` |
| `create-site` | Create a brand new site; returns a `site_context` directly |
| `update-site-settings` | Change site name and/or production domain |
| `list-version-sources` | Production/Test/backup versions usable as a session source |
| `begin-edit-session` | Start an edit session; returns `session_id`, `backup_recommended` |
| `create-source-download` | One-time signed URL for the project ZIP (build sites) |
| `create-upload-ticket` | Signed PUT URL + `upload_id` for the full-project ZIP |
| `deploy-to-test` | Deploy upload or server workspace to Test; returns `testing_url` |
| `get-edit-manifest` / `read-edit-files` / `apply-edit-changes` | File-by-file editing of UTF-8 text in the server workspace |
| `upload-media-file` | Upload media to the Files module; returns the public URL |
| `list-site-forms` / `get-site-form` / `create-site-form` | Inspect and create site-scoped forms |
| `create-backup` / `delete-backup` | Explicit backups of Test or Production (shared limit of six) |
| `rollback-test` | Swap Test with the rollback slot (undo/redo one deploy) |
| `restore-version-to-test` | Replace Test with a copy of Production or a backup by hash |
| `publish-to-production` | Publish the current Test live; explicit user request only |
| `close-edit-session` | End the session; only when the user says the work is done |
