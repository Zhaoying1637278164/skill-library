# Newlogic Online — Claude Code plugin

Edit, build, preview, and publish static websites hosted on
[Newlogic Online](https://newlogic.online) directly from Claude Code.

The plugin ships two things:

- the `newlogic-online` **skill** — the full website-editing playbook: site
  discovery, edit sessions, local builds, file-by-file edits, media uploads,
  site forms, backups, rollback, and explicit publishing to Production,
- the `newlogic-online` **MCP server** — the authenticated HTTP connection to
  `https://app.newlogic.online/mcp` that every action in the skill goes through.

## Requirements

- Claude Code v2.1 or later
- an account on [Newlogic Online](https://newlogic.online) with access to at
  least one website

## Install

```shell
/plugin marketplace add anthropics/claude-plugins-community
```

```shell
/plugin install newlogic-online@claude-community
```

Then sign in to the MCP server: run `/mcp`, pick `newlogic-online`, and complete
the OAuth login. Without an authenticated connection the skill refuses to work,
by design — nothing can reach the website.

## Use

The skill is model-invoked, so just describe what you want:

- “Create a new website in Newlogic Online.”
- “Update my website and deploy the changes to Test.”
- “Review Test and publish it to Production.”

You can also invoke it explicitly with `/newlogic-online:newlogic-online`.

Claude answers in your language — the skill itself is written in English, the
conversation does not have to be.

## How it handles your sites

Every site has two environments, and the plugin keeps them strictly apart:

- **Test** is where all work lands, previewed on the site's testing domain.
- **Production** is the live site on your own domain. It changes only through an
  explicit publish, after you confirm — never as a side effect of an edit.

Two kinds of sites are supported. **Build sites** are downloaded as a complete
project, built locally with the project's own toolchain, and uploaded back.
**Static sites** are edited file by file in a server-side workspace, so they work
even in a chat client with no shell.

Safety properties worth knowing:

- `node_modules`, `.git`, and real `.env` files are never uploaded.
- Backups and rollback are explicit; nothing is rotated or discarded silently.
- Form submissions, e-mail recipients, and other personal data are never read or
  exposed.

## Develop

Clone this repository and load the plugin without installing it:

```shell
claude --plugin-dir .
```

Run `/reload-plugins` after editing the skill to pick up changes.

Validate before committing — the community review pipeline runs the same check:

```shell
claude plugin validate . --strict
```

## Contents

```
.claude-plugin/plugin.json          plugin manifest
.mcp.json                           Newlogic Online MCP server (HTTP + OAuth)
skills/newlogic-online/SKILL.md     the website-editing playbook
skills/newlogic-online/references/  supplementary docs loaded on demand
```

## License

MIT — see [LICENSE](LICENSE).
