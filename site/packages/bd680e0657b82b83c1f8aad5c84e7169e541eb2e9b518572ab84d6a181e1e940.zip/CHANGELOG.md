# Changelog

## 0.1.0

- First release: the `newlogic-online` skill and the Newlogic Online MCP server
  connection, covering site discovery, edit sessions, build and static editing
  paths, media, forms, backups, rollback, and publishing to Production.
