----
name: recipe-tracker log
type: log
----

# LOG

## 2026-04-20

- Created as the SMDD plugin's example project.
- Scope locked to V1 (list, CRUD, single-tag filter). Multi-user, images, shopping lists deferred to V2.
- Tag model decision still open — free-form vs enum. Leaning free-form.
- Next: fill out `docs/backend/schemas/recipe.md` and the api md so the pair is aligned.
