----
name: recipe-tracker status
type: status
----

# STATUS

## Phase

Example project — used for illustrating SMDD layout. Not actively built.

## Component checklist

- [x] `docs/ui/home.md`
- [x] `docs/ui/pages/recipe-list.md` (pairs with `docs/backend/apis/recipes.md`)
- [x] `docs/ui/pages/recipe-detail.md` (pairs with `docs/backend/apis/recipes.md`)
- [x] `docs/backend/apis/recipes.md`
- [x] `docs/backend/schemas/recipe.md`
- [x] `docs/config/env.md`
- [ ] `src/` — example stops at docs; not built.

## Open decisions

- Tag model: free-form strings or a curated enum? Leaning free-form for V1 simplicity.

## Risks

None at V1 scope.

## Links

- Paradigm: `../../docs/paradigm.md`
