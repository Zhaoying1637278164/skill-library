----
name: home
type: ui rules
----

# home

The app has no landing page, no marketing. First route the user hits is the recipe list at `/`. That's the home.

## Layout

- Header: app name on the left, "Add recipe" button on the right.
- Body: the recipe-list page. See `pages/recipe-list.md`.
- No footer.

## Why

One user, one purpose (find a recipe to cook). A landing page would be friction.
