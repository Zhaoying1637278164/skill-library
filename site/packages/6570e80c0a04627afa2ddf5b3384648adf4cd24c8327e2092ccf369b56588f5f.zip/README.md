# Chuck — Smart Context for Claude Code

> Give Claude the right rules at the right time. Nothing more.

Chuck is a Claude Code plugin that automatically injects relevant rules into each prompt, remembers your architectural decisions, and catches contradictions in real-time — without a bloated `CLAUDE.md`.

---

## What Chuck does

**Context injection** — Reads your prompt, scores it against your domain rules using semantic matching (TF-IDF), and injects only what's relevant. React rules when building components. Git rules when committing. Nothing for unrelated prompts.

**Decision Ledger** — Stores architectural decisions with reasoning (`use Zustand, not Redux — boilerplate`) and automatically injects them when the topic surfaces. Claude never re-suggests what you already rejected.

**Quality Monitor** — Watches every Write/Edit and warns immediately if Claude starts writing code that contradicts an active decision. Zero tokens when clean, ~30–50t only on contradiction.

---

## Installation

Install this plugin through the Claude Code plugin manager. Chuck requires Python 3.

After installing, initialize Chuck in your project:

```bash
npm install -g chuck-core
chuck init
```

---

## Setup

After `chuck init`, your project will have a `.chuck/` directory:

```
.chuck/
├── manifest.json       # Domain config and token budget
├── domains/            # Rule files per domain
├── decisions/          # Architectural decision records
└── sessions/           # Local usage data (gitignored)
```

### Visual setup (recommended)

Use the built-in Chuck Setup Wizard to generate your `manifest.json` visually — select your stack, adjust the token budget, and copy the result.

### Log a decision

```bash
chuck decide "Use Zustand for state management" --tags state,react
# Prompts for rejected alternatives and reason
```

---

## Commands

```bash
chuck init              # Auto-detect stack and generate starter rules
chuck list              # Show active domains and token costs
chuck stats             # See which rules are firing
chuck suggest           # Get suggestions based on unmatched prompts
chuck sync              # Push/pull rules via git
chuck decide            # Log and manage architectural decisions
chuck decide:audit      # Find stale decisions that never fired
chuck compact           # Generate session handoff brief
```

---

## Playgrounds

This plugin includes two interactive HTML tools:

**Chuck Setup Wizard** (`/chuck:setup-wizard`) — visually configure your `manifest.json`. Pick your stack, set token budget, copy the result.

**Chuck Decision Logger** (`/chuck:decision-logger`) — log decisions through a form. Fill in decision, rejected alternatives, and reason. Copies the pre-filled `chuck decide` command.

---

## Links

- **chuck-core on npm** — `npm install -g chuck-core`
- **GitHub** — https://github.com/cssmith615/chuck
- **Plugin repo** — https://github.com/cssmith615/chuck-plugin

---

## License

Apache 2.0
