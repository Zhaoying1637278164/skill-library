---
name: Bug report
about: A skill misfired, produced wrong output, or broke
labels: bug
---

## What you were trying to do

<!-- What kind of software were you building? (CLI, web app, API, etc.) What was the user-visible task? -->

## What the skill did

<!-- Paste the relevant prompt/response. Redact anything sensitive. -->

## What you expected instead

## Skill affected

<!-- e.g. ux-discover, persona-builder, telemetry-designer -->

## Environment

- Claude Code version:
- Plugin version:
- OS:
