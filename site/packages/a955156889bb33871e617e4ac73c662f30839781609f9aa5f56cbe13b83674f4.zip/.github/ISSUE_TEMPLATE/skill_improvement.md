---
name: Skill improvement
about: A skill could ask better questions, handle an edge case, or produce better output
labels: enhancement
---

## Skill

<!-- Which skill? -->

## What triggered this

<!-- Real project context is the best evidence. What were you building when you noticed this? -->

## What's missing or wrong

<!-- Wrong question, missed scenario, confusing output, etc. -->

## Proposed change

<!-- Optional — if you have a concrete suggestion -->
