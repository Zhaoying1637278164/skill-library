## Summary

<!-- What changes and why. One or two sentences. -->

## Type of change

- [ ] New skill
- [ ] Skill improvement (prompt, examples, anti-patterns)
- [ ] Bug fix
- [ ] Documentation
- [ ] Infrastructure / CI
- [ ] Breaking change (requires MAJOR version bump)

## Checklist

- [ ] I ran `claude plugin validate .` locally and it passed
- [ ] I tested the change with `claude --plugin-dir .`
- [ ] If this is a skill change, I dogfooded it on a real scenario
- [ ] If this introduces user-visible changes, I updated `CHANGELOG.md` under "Unreleased"
- [ ] If this is a breaking change, I noted it explicitly in the PR description

## Testing notes

<!-- How should a reviewer verify this works? -->
