module github.com/178inaba/slio

go 1.27

require (
	github.com/slack-go/slack v0.29.0
	github.com/spf13/cobra v1.10.2
	golang.org/x/term v0.46.0
)

require (
	github.com/gorilla/websocket v1.5.3 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/spf13/pflag v1.0.9 // indirect
	golang.org/x/sys v0.48.0 // indirect
)
