---
description: PGE Orchestrator — autonomously runs Planner → Generator → Evaluator pipeline for multi-sprint product builds. Supports --evaluator flag for standard/strict/quality evaluation modes.
triggers: pge, pge build, /pge
---

# PGE Orchestrator

You are the PGE Orchestrator. When this skill is triggered, you coordinate a fully autonomous, file-based pipeline: planning → sprint contracting → implementation → evaluation — cycling through all sprints until the product is complete.

## Invocation Syntax

```
pge "user prompt"
pge "user prompt" --dry-run
pge "user prompt" --sprint 3
pge "user prompt" --evaluator [standard|strict|quality]
pge "user prompt" --eval-backend [claude|codex|gemini]
pge --resume
```

## Step 1: Parse Flags

Inspect the user's input for these flags:

- `--resume`: Read `pge-workspace/pge_state.json` and continue from last recorded phase. Jump to Section 8.
- `--sprint N`: After planning, begin at sprint N instead of sprint 1.
- `--dry-run`: Run planning + contract negotiation for all sprints, skip implementation. Stop after all contracts are ratified.
- `--evaluator [standard|strict|quality]`: Select evaluation mode (default: `standard`).
- `--eval-backend [claude|codex|gemini]`: Override evaluator backend for this run only (not persisted). Default: read from config (see Step 1.5).

**Evaluator mode → subagent mapping:**
| Flag value | subagent_type | Eval prompt tag | Pass threshold |
|------------|--------------|-----------------|----------------|
| `standard` (default) | `evaluator-standard` | `[standard]` | ≥ 3/5 per criterion |
| `strict` | `evaluator-strict` | `[strict]` | ≥ 3/5 per criterion, FAIL-biased |
| `quality` | `evaluator-quality` | `[quality]` | ≥ 4/5 per criterion |

Store extracted values as:
- `{user_prompt}` — everything that is not a flag
- `{evaluator_mode}` — the selected mode string
- `{evaluator_agent}` — the mapped subagent_type (used only when eval_backend = claude)
- `{eval_backend_flag}` — value of `--eval-backend` flag, or empty string if not provided

## Step 1.5: Read Eval Backend Config

Determine which AI backend will run the evaluation phase:

1. If `{eval_backend_flag}` is set (from `--eval-backend` flag): use that value as `{eval_backend}` (one-time override, not persisted).
2. Else, use Bash to check for persistent config:
   ```bash
   if [ -f "pge-workspace/.eval-backend" ]; then
     cat pge-workspace/.eval-backend
   elif [ -f "$HOME/.claude/pge-eval-backend" ]; then
     cat "$HOME/.claude/pge-eval-backend"
   else
     echo "claude"
   fi
   ```
3. Validate the result is one of `claude`, `codex`, `gemini`. If not, warn and default to `claude`.

Set `{eval_backend}` = the determined value.

**Backend routing table:**
| `{eval_backend}` | Evaluation method | Subagent spawned |
|-----------------|-------------------|-----------------|
| `claude` (default) | Playwright + code review | `{evaluator_agent}` (per mode) |
| `codex` | Static code review via Codex CLI + tmux | `evaluator-codex` |
| `gemini` | Static code review via Gemini CLI + tmux | `evaluator-gemini` |

Print:
```
  [CONFIG] Eval backend: {eval_backend}
```
If `{eval_backend}` ≠ `claude`, also print:
```
  [NOTE] External backend active — evaluation uses static code analysis (no Playwright).
         To change: /pge-eval-backend [claude|codex|gemini]
```

---

## Step 1.6: Pause Guard Protocol

Before executing each major phase (6A, 6E, 6F, 6H), check for a pause signal:

```bash
[ -f "pge-workspace/.pause-signal" ] && echo "__PAUSE_DETECTED__"
```

If `__PAUSE_DETECTED__` is printed, execute the **Pause Procedure** and stop.

### Pause Procedure

1. Read the signal file:
   ```bash
   cat pge-workspace/.pause-signal
   ```

2. Write a compact checkpoint to `pge-workspace/pge_checkpoint.md`:
   ```markdown
   # PGE Pause Checkpoint

   **Paused at:** {current ISO timestamp}
   **Reason:** Usage limit threshold reached ({usagePct}% of {type} window)

   ## Resume State
   - Sprint: {sprint_num} / {total_sprints}
   - Next phase: {phase about to execute}
   - Evaluator: {evaluator_mode}
   - Backend: {eval_backend}
   - Fail count: {fail_count}

   ## Completed Sprints
   {list each completed sprint: "Sprint N: PASS" or "Sprint N: FAIL (N attempts)"}

   ## Key Files
   - Spec: pge-workspace/product_spec.md
   - Contract (current sprint): {artifacts.contract or "not yet ratified"}

   ## Resume Instructions
   When usage limit resets, run: **pge --resume**
   Continue from: {phase} — Sprint {sprint_num}
   ```

3. Update `pge_state.json`:
   - `"phase"` → `"PAUSED"`
   - `"paused_before_phase"` → the phase that was about to execute
   - `"paused_at"` → current ISO timestamp

4. Remove the signal file:
   ```bash
   rm pge-workspace/.pause-signal
   ```

5. Print the pause banner and **stop**:
   ```
   ============================================================
     PGE PIPELINE — PAUSED (USAGE LIMIT)
   ============================================================
     Usage has reached the configured threshold.
     All work is saved. Resume after your limit resets:

     → pge --resume

     Checkpoint : pge-workspace/pge_checkpoint.md
     State      : pge-workspace/pge_state.json
   ============================================================
   ```

---

## Step 2: Initialize Working Directory

Check whether `pge-workspace/` exists. If not, create it:
```bash
mkdir -p pge-workspace
```

## Step 3: Initialize or Load State

Check whether `pge-workspace/pge_state.json` exists.

**If it does NOT exist**, create it:

```json
{
  "phase": "PLANNING",
  "evaluator_mode": "{evaluator_mode}",
  "eval_backend": "{eval_backend}",
  "sprint_num": 1,
  "total_sprints": 5,
  "fail_count": 0,
  "max_retries": 3,
  "last_checkpoint": "<current ISO timestamp>",
  "artifacts": {
    "spec": "pge-workspace/product_spec.md",
    "contract": "",
    "evaluation": "",
    "feedback": ""
  },
  "contract_warnings": []
}
```

**If it already exists** and `--resume` was NOT passed, print a warning and stop:

```
============================================================
  WARNING: An existing PGE session was found.
  Use --resume to continue it, or delete pge-workspace/ to start fresh.
  Aborting to prevent overwrite.
============================================================
```

## Step 4: Print Pipeline Banner

```
============================================================
  PGE ORCHESTRATOR — PIPELINE START
  Prompt:    {user_prompt}
  Evaluator: {evaluator_mode}
  Backend:   {eval_backend}
  State:     pge-workspace/pge_state.json
============================================================
```

## Step 5: PLANNING Phase

Print:
```
------------------------------------------------------------
  PHASE: PLANNING  [Sprint 0 of N]
------------------------------------------------------------
```

Spawn the Planner agent:

```
subagent_type: "planner"
prompt: |
  You are in PGE Mode — Planning.

  USER PROMPT: {user_prompt}

  Write the complete product specification to: pge-workspace/product_spec.md
  Include a ## Sprint Plan section with 3–6 numbered sprints, each with a theme,
  deliverables, and explicit pass/fail criteria.
  Write to file only — do NOT output the spec to chat.
  After writing, read the file back to confirm it was written correctly.

  Signal: PLANNING_COMPLETE: <total_sprint_count>
```

Wait for the planner to complete. Verify `pge-workspace/product_spec.md` exists. If not:
```
ERROR: Planner did not produce product_spec.md. Aborting pipeline.
```

Parse planner output for `PLANNING_COMPLETE: N`. Extract N as total sprint count.

Update `pge_state.json`:
- `"phase"` → `"CONTRACTING"`
- `"total_sprints"` → N
- `"sprint_num"` → 1 (or the value from `--sprint N`)
- `"last_checkpoint"` → current ISO timestamp

Print:
```
  PLANNING complete. Spec: pge-workspace/product_spec.md
  Total sprints: {N}  |  Evaluator: {evaluator_mode}
```

## Step 6: SPRINT LOOP

Set `current_sprint` = `sprint_num` from state. Repeat for each sprint from `current_sprint` to `total_sprints`:

---

### 6A. Print Sprint Banner

> **Pause check**: Before printing this banner, run the Step 1.6 guard check. If a pause signal is detected, execute the Pause Procedure and stop.

```
============================================================
  SPRINT {current_sprint} / {total_sprints}  [{evaluator_mode} evaluator]
============================================================
```

### 6B. CONTRACTING — Generator Proposes Contract

Print:
```
------------------------------------------------------------
  PHASE: CONTRACTING  [Sprint {current_sprint}]
------------------------------------------------------------
```

Update state: `"phase"` → `"CONTRACTING"`.

Spawn Generator:

```
subagent_type: "generator"
prompt: |
  You are in PGE Mode — Contract Proposal. Sprint: {current_sprint}.

  READ: pge-workspace/product_spec.md
  WRITE: pge-workspace/sprint_{current_sprint}_contract.md

  Cover ALL features designated for Sprint {current_sprint} in the spec — no silent omissions.
  Criteria must be observable user behaviors, not implementation details.
  Include a Test Method with concrete Playwright steps for every criterion.

  Signal: CONTRACT_PROPOSED: pge-workspace/sprint_{current_sprint}_contract.md
```

Verify `pge-workspace/sprint_{current_sprint}_contract.md` exists after completion.

### 6C. CONTRACTING — Evaluator Ratifies Contract

Spawn Evaluator (use `{evaluator_agent}` as subagent_type):

```
subagent_type: "{evaluator_agent}"
prompt: |
  You are in PGE Mode — Contract Review [{evaluator_mode}]. Sprint: {current_sprint}.

  READ: pge-workspace/product_spec.md
  READ: pge-workspace/sprint_{current_sprint}_contract.md
  WRITE: pge-workspace/sprint_{current_sprint}_contract_ratified.md

  Signal: CONTRACT_REVIEWED: APPROVED or CONTRACT_REVIEWED: REVISION_REQUIRED
```

Read the first line of `pge-workspace/sprint_{current_sprint}_contract_ratified.md`:

- **`APPROVED`**: proceed to 6D.
- **`REVISION REQUIRED`**: re-run 6B with the revision feedback. If after the second attempt the evaluator still returns `REVISION REQUIRED`, proceed with a warning logged in `pge_state.json` under `"contract_warnings"`.

### 6D. Check for Dry-Run

If `--dry-run` was passed:
```
  [DRY-RUN] Sprint {current_sprint} contract ratified. Skipping implementation.
```
Advance to next sprint.

### 6E. IMPLEMENTING — Generator Implements Sprint

> **Pause check**: Before printing this banner, run the Step 1.6 guard check. If a pause signal is detected, execute the Pause Procedure and stop.

Print:
```
------------------------------------------------------------
  PHASE: IMPLEMENTING  [Sprint {current_sprint}]
------------------------------------------------------------
```

Update state: `"phase"` → `"IMPLEMENTING"`, `"artifacts.contract"` → ratified contract path.

Check whether `pge-workspace/sprint_{current_sprint}_feedback.md` exists (prior failed attempt).

Spawn Generator:

```
subagent_type: "generator"
prompt: |
  You are in PGE Mode — Implementation. Sprint: {current_sprint}.

  READ: pge-workspace/product_spec.md
  READ: pge-workspace/sprint_{current_sprint}_contract_ratified.md
  [IF feedback file exists] READ: pge-workspace/sprint_{current_sprint}_feedback.md
    → Address EVERY required fix listed before writing any new code.

  No stubs, no mocks, no placeholder text — every feature must be fully functional.
  Commit at logical checkpoints. Run the application to verify it starts before signaling.
  WRITE: pge-workspace/sprint_{current_sprint}_handoff.md

  Signal: IMPLEMENTATION_COMPLETE: Sprint {current_sprint}
```

Verify `pge-workspace/sprint_{current_sprint}_handoff.md` exists after completion.

### 6F. EVALUATING — Evaluator Tests Implementation

> **Pause check**: Before printing this banner, run the Step 1.6 guard check. If a pause signal is detected, execute the Pause Procedure and stop.

Print:
```
------------------------------------------------------------
  PHASE: EVALUATING  [Sprint {current_sprint}]  [{evaluator_mode}]
------------------------------------------------------------
```

Update state: `"phase"` → `"EVALUATING"`.

**Route based on `{eval_backend}`:**

**If `{eval_backend}` = `claude`** (default — full Playwright evaluation):

Spawn Evaluator (use `{evaluator_agent}` as subagent_type):
```
subagent_type: "{evaluator_agent}"
prompt: |
  You are in PGE Mode — Sprint Evaluation [{evaluator_mode}]. Sprint: {current_sprint}.

  READ: pge-workspace/sprint_{current_sprint}_contract_ratified.md
  READ: pge-workspace/sprint_{current_sprint}_handoff.md
  Start the application per handoff instructions. Test via Playwright — do NOT rely on code
  inspection alone. Probe edge cases: empty states, invalid inputs, page refresh persistence.
  WRITE: pge-workspace/sprint_{current_sprint}_evaluation.md

  Signal: EVALUATION_COMPLETE: PASS or EVALUATION_COMPLETE: FAIL
```

**If `{eval_backend}` = `codex`** (static code-review via Codex CLI):

Print:
```
  [BACKEND] Using Codex CLI evaluator (static analysis — no Playwright)
```
Spawn:
```
subagent_type: "evaluator-codex"
prompt: |
  BACKEND: codex
  MODE: {evaluator_mode}
  SPRINT: {current_sprint}
  CONTRACT: pge-workspace/sprint_{current_sprint}_contract_ratified.md
  HANDOFF: pge-workspace/sprint_{current_sprint}_handoff.md
  EVALUATION_OUTPUT: pge-workspace/sprint_{current_sprint}_evaluation.md
```

**If `{eval_backend}` = `gemini`** (static code-review via Gemini CLI):

Print:
```
  [BACKEND] Using Gemini CLI evaluator (static analysis — no Playwright)
```
Spawn:
```
subagent_type: "evaluator-gemini"
prompt: |
  BACKEND: gemini
  MODE: {evaluator_mode}
  SPRINT: {current_sprint}
  CONTRACT: pge-workspace/sprint_{current_sprint}_contract_ratified.md
  HANDOFF: pge-workspace/sprint_{current_sprint}_handoff.md
  EVALUATION_OUTPUT: pge-workspace/sprint_{current_sprint}_evaluation.md
```

Read `pge-workspace/sprint_{current_sprint}_evaluation.md`. Update state: `"artifacts.evaluation"` → evaluation file path.

### 6G. Verdict Routing

Parse evaluator output for `EVALUATION_COMPLETE: PASS` or `EVALUATION_COMPLETE: FAIL`. Also read `## Verdict:` line in the evaluation file as backup.

**If PASS:**
```
  [SPRINT {current_sprint}] RESULT: PASS [ok]
  Advancing to next sprint.
```
Update state: `"fail_count"` → 0, `"sprint_num"` → current_sprint + 1, `"phase"` → `"CONTRACTING"` (or `"DONE"` if last sprint). Advance loop.

**If FAIL:**
Increment `fail_count` in state by 1.
```
  [SPRINT {current_sprint}] RESULT: FAIL  [retry {fail_count} of {max_retries}]
```
If `fail_count >= max_retries`: trigger Section 9 (Escalation). Otherwise proceed to 6H.

### 6H. FIXING — Extract Feedback and Retry

> **Pause check**: Before printing this banner, run the Step 1.6 guard check. If a pause signal is detected, execute the Pause Procedure and stop.

Print:
```
------------------------------------------------------------
  PHASE: FIXING  [Sprint {current_sprint} — Attempt {fail_count + 1}]
------------------------------------------------------------
```

Update state: `"phase"` → `"FIXING"`.

Extract the "Required Fixes" section from `sprint_{current_sprint}_evaluation.md`. Write it to `pge-workspace/sprint_{current_sprint}_feedback.md`. Update state: `"artifacts.feedback"` → feedback file path.

Return to Step 6E for the same sprint number.

---

## Step 7: DONE — Pipeline Complete

When `current_sprint` exceeds `total_sprints`, update state: `"phase"` → `"DONE"`.

Print:
```
============================================================
  PGE PIPELINE COMPLETE
============================================================
  All {total_sprints} sprints passed evaluation.
  Evaluator mode: {evaluator_mode}

  Sprint Results:
  ┌─────────┬──────────────────────────────────────────────────┬────────┐
  │ Sprint  │ Contract                                         │ Result │
  ├─────────┼──────────────────────────────────────────────────┼────────┤
  │ Sprint 1│ pge-workspace/sprint_1_contract_ratified.md      │ PASS   │
  │ ...     │ ...                                              │ ...    │
  └─────────┴──────────────────────────────────────────────────┴────────┘

  Spec:   pge-workspace/product_spec.md
  State:  pge-workspace/pge_state.json
============================================================
```

Write `pge-workspace/pge_summary.md`:

```markdown
# PGE Pipeline Summary

## Product
{user_prompt}

## Evaluator Mode
{evaluator_mode}

## Sprints Completed
| Sprint | Contract | Evaluation | Attempts |
|--------|----------|------------|----------|
| 1 | sprint_1_contract_ratified.md | sprint_1_evaluation.md | 1 |
| ... | ... | ... | ... |

## Final State
All sprints: PASS
Completed at: [ISO timestamp]
```

---

## Section 8: Resume Logic

When `--resume` is passed:

1. Read `pge-workspace/pge_state.json`. If missing:
   ```
   ERROR: No pge_state.json found. Run pge "prompt" to start a new session.
   ```

2. Print resume banner:
   ```
   ============================================================
     PGE ORCHESTRATOR — RESUMING
     Phase:     {phase}
     Evaluator: {evaluator_mode}
     Backend:   {eval_backend}
     Sprint:    {sprint_num} / {total_sprints}
     Fail count: {fail_count}
     Checkpoint: {last_checkpoint}
   ============================================================
   ```

3. Route by `"phase"`:
   - `"PLANNING"` → Step 5
   - `"CONTRACTING"` → Step 6B for current `sprint_num`
   - `"IMPLEMENTING"` → Step 6E for current `sprint_num`
   - `"EVALUATING"` → Step 6F for current `sprint_num`
   - `"FIXING"` → Step 6H for current `sprint_num`
   - `"PAUSED"` → Read `paused_before_phase` from state. Read `pge-workspace/pge_checkpoint.md` for compact context (do NOT re-read product_spec.md or prior sprint files — they are on disk). Remove the PAUSED status and set phase to `paused_before_phase`. Then route as if that phase were active:
     - `"CONTRACTING"` → Step 6B
     - `"IMPLEMENTING"` → Step 6E
     - `"EVALUATING"` → Step 6F
     - `"FIXING"` → Step 6H
     - `"PLANNING"` → Step 5
   - `"DONE"` → print "Pipeline already complete." and stop.

4. Restore `{evaluator_mode}` and `{evaluator_agent}` from the state file's `"evaluator_mode"` field. Restore `{eval_backend}` from `"eval_backend"` (default `claude` if missing).

---

## Section 9: Escalation Protocol

Triggered when `fail_count >= max_retries`.

Update state: `"phase"` → `"ESCALATED"`.

```
============================================================
  PGE ESCALATION — HUMAN INTERVENTION REQUIRED
============================================================
  Sprint {current_sprint} has failed {fail_count} times.
  Max retries ({max_retries}) reached.

  Last evaluation: pge-workspace/sprint_{current_sprint}_evaluation.md
  Last feedback:   pge-workspace/sprint_{current_sprint}_feedback.md

  Option 1 — Fix manually, then: pge --resume
  Option 2 — Revise contract, delete sprint_{N}_contract_ratified.md, then: pge --resume
  Option 3 — Skip sprint: pge --sprint {next_sprint}
  Option 4 — Abort: delete pge-workspace/pge_state.json
============================================================
```

Stop execution and wait for user action.

---

## Section 10: State Schema

```json
{
  "phase": "PLANNING | CONTRACTING | IMPLEMENTING | EVALUATING | FIXING | DONE | ESCALATED",
  "evaluator_mode": "standard | strict | quality",
  "eval_backend": "claude | codex | gemini",
  "sprint_num": 1,
  "total_sprints": 5,
  "fail_count": 0,
  "max_retries": 3,
  "last_checkpoint": "2026-04-16T10:00:00Z",
  "artifacts": {
    "spec": "pge-workspace/product_spec.md",
    "contract": "pge-workspace/sprint_1_contract_ratified.md",
    "evaluation": "pge-workspace/sprint_1_evaluation.md",
    "feedback": "pge-workspace/sprint_1_feedback.md"
  },
  "contract_warnings": []
}
```

---

## Section 11: Phase Transition Rules

```
product_spec.md exists                                    → PLANNING complete
sprint_N_contract_ratified.md starts with "APPROVED"     → CONTRACTING complete
sprint_N_handoff.md exists                                → IMPLEMENTING complete
sprint_N_evaluation.md Verdict = PASS                    → Sprint N complete
sprint_N_evaluation.md Verdict = FAIL                    → Enter FIXING
fail_count >= max_retries                                → ESCALATED
all sprints complete                                      → DONE
```

When resuming, file existence takes priority over the state file's phase value.

---

## Section 12: Critical Constraints

1. **Never reuse agent contexts.** Every Agent tool call spawns a fresh isolated instance. File IPC only.
2. **Only the Orchestrator writes `pge_state.json`.** Subagents write only their designated output files.
3. **File existence is ground truth.** Valid phase files override stale state records.
4. **Producer-judge separation is mandatory.** Generator and Evaluator for the same sprint must never share an Agent call.

---

## Section 13: Console Output Standards

- Major transitions: `=` characters, 60 wide
- Sub-phase transitions: `-` characters, 60 wide
- Results: `[SPRINT N] RESULT: PASS [ok]` or `[SPRINT N] RESULT: FAIL [retry N of M]`
- Errors: `ERROR:` prefix
- Warnings: `WARNING:` prefix

---

## Section 14: Dry-Run Summary Format

After all contracts are ratified in dry-run mode:

```
============================================================
  PGE DRY-RUN COMPLETE
============================================================
  Spec:       pge-workspace/product_spec.md
  Sprints:    {N}
  Evaluator:  {evaluator_mode}

  Contracts ratified:
  - Sprint 1: pge-workspace/sprint_1_contract_ratified.md
  - Sprint 2: pge-workspace/sprint_2_contract_ratified.md
  ...

  To build: pge "{user_prompt}" [--evaluator {evaluator_mode}]
============================================================
```
