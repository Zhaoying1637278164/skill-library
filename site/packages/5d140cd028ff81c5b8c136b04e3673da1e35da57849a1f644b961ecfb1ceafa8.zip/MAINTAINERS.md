## Overview

This document contains a list of maintainers in this repo. See [opensearch-project/.github/RESPONSIBILITIES.md](https://github.com/opensearch-project/.github/blob/main/RESPONSIBILITIES.md#maintainer-responsibilities) that explains what the role of maintainer means, what maintainers do in this and other repos, and how they should be doing it. If you're interested in contributing, and becoming a maintainer, see [CONTRIBUTING](CONTRIBUTING.md).

## Current Maintainers

| Maintainer        | GitHub ID                                                 | Affiliation |
| ----------------- | --------------------------------------------------------- | ----------- |
| Arjun kumar Giri  | [arjunkumargiri](https://github.com/arjunkumargiri)       | Amazon      |
| Sarat Vemulapalli | [saratvemulapalli](https://github.com/saratvemulapalli)   | Amazon      |
| Sean Zheng        | [sean-zheng-amazon](https://github.com/sean-zheng-amazon) | Amazon      |
| Fen Qin           | [fen-qin](https://github.com/fen-qin)                     | Amazon      |
