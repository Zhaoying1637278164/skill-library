---
name: Feature Request
about: Suggest an idea for Stackpilot
title: "[Feature] "
labels: enhancement
assignees: ""
---

## Problem

A clear description of the problem you're trying to solve.

## Proposed Solution

Describe the solution you'd like.

## Alternatives Considered

Any alternative solutions or features you've considered.

## Additional Context

Any other context, mockups, or references.
