# Loops Agent Skills and Plugin

Official installable Loops skills and plugin for AI coding agents.

This repository packages `SKILL.md`-based skills for working with Loops. It is intended to help agents use the Loops API, official SDKs, the Loops CLI, LMX email markup, and email-sending best practices more accurately.

These skills are designed for agent environments that support installable skills, such as Claude Code, Codex, Cursor, and other tools that work with the `skills` CLI.

## Install skills

For `skills` CLI setup, agent-specific install targets, and the full list of flags, use the official docs:

- https://skills.sh/docs/cli

This README only documents the Loops-specific install commands.

```bash
# See what this repo contains
npx skills add loops-so/skills --list

# Install all Loops skills globally (recommended)
npx skills add loops-so/skills --global

# Install specific Loops skills globally
npx skills add loops-so/skills --global --skill loops-api
npx skills add loops-so/skills --global --skill loops-cli
npx skills add loops-so/skills --global --skill loops-lmx
npx skills add loops-so/skills --global --skill loops-email-sending-best-practices
```

Project-level installs are also supported. Omit `--global` if you want the skills scoped to the current repository instead of user-level.

### Pin a release

This repo is versioned with GitHub Releases. For stable installs, pin a release tag instead of installing from the default branch:

```bash
npx skills add loops-so/skills#v1.0.0 --global
```

### Upgrading from unprefixed skill names

Older installs used the unprefixed skill names `api`, `cli`, `email-sending-best-practices`, and `lmx`. Installing the renamed `loops-*` skills does not automatically remove those old local skills. After installing the prefixed skills, remove the old names:

```bash
npx skills remove api cli email-sending-best-practices lmx --global
```

## Install plugin

This repo can also be installed as a Plugin in certain agent environments.

### ChatGPT / Codex

Install the plugin from the [ChatGPT Plugin directory](https://chatgpt.com/plugins/plugin_asdk_app_6a76060a3cbc81919eaaca7e37e830fe).

### Claude

Install the plugin from the [Claude Plugin directory](https://claude.ai/directory/loops).

### Cursor

In the Cursor desktop app:

1. Go to Settings > Customize (or if in the Agents Window, click Customize in the left sidebar).
1. Click **Browse Marketplace** and then the **All** option in the search bar. **Skills**.
1. Select **Add Marketplace** and **Import from GitHub**. Paste in `https://github.com/loops-so/skills` and click **Import**.
1. Once the Loops listing appears, click **Add**.

## How to invoke skills

| Platform        | Typical invocation                                                                                       |
| --------------- | -------------------------------------------------------------------------------------------------------- |
| **Claude Code** | `/loops-api`, `/loops-cli`, `/loops-lmx`, `/loops-email-sending-best-practices`  |
| **Cursor**      | `/loops-api`, `/loops-cli`, `/loops-lmx`, `/loops-email-sending-best-practices` in Agent chat (type `/`) |
| **Codex**       | Describe the task, or `@loops` / `@` and choose a skill                                                  |

## Verify install

After installation, try a task that should trigger one of the skills:

- "Add a contact to Loops from my Next.js backend."
- "Install the Loops CLI and authenticate against the right team."
- "Send a transactional email with the Loops CLI."
- "Design a new onboarding email using existing Loops themes/components, then write it in LMX."
- "Write an LMX onboarding email template."
- "Audit this onboarding email flow for deliverability issues."

## What's included

This repo currently ships:

- four installable skills that auto-load when relevant
- detailed reference files for API, SDK, CLI, LMX, and email-program guidance

This repo does not currently ship:

- slash commands
- MCP servers

## Available skills

### `loops-api`

Use this skill when you need to:

- create, update, find, or delete contacts
- create and manage custom contact properties
- read mailing lists and update mailing-list membership
- send Loops events from backend code
- send transactional emails with the API or SDKs
- create draft campaigns and update email-message content
- create and update themes and reusable email components
- create, update, and delete workflows and workflow nodes
- receive and verify inbound Loops webhooks
- upload images for use in email LMX content
- choose between official SDKs and raw HTTP requests
- handle rate limits, idempotency keys, and server-side-only constraints

Example prompts:

- "Add this user to Loops after signup."
- "Check whether this Loops API key is valid."
- "Send this event from my Rails app."
- "Verify Loops webhooks in my Next.js app."

Skill file: [skills/loops-api/SKILL.md](./skills/loops-api/SKILL.md)

### `loops-cli`

Use this skill when you need to:

- install or update the Loops CLI
- authenticate from the terminal and manage stored team keys
- validate credentials with the CLI
- run one-off contact, list, event, or transactional-email commands
- create draft campaigns, update email-message content and upload images from the shell
- list themes and components for LMX authoring
- inspect CLI output in text or JSON from the shell

Example prompts:

- "Install the Loops CLI on macOS."
- "Log into the CLI for the staging team."
- "Send a transactional email from the terminal."

Skill file: [skills/loops-cli/SKILL.md](./skills/loops-cli/SKILL.md)

### `loops-email-sending-best-practices`

Use this skill when you need to:

- review inbox-placement or sender-reputation problems
- improve consent flows, list hygiene, or unsubscribe behavior
- improve subject lines, preview text, sender identity, or template design
- decide between lifecycle, campaign, and transactional email
- review a Loops setup for quality or deliverability gaps

Example prompts:

- "Review this welcome email for deliverability risk."
- "Should this message be transactional or marketing?"
- "How should we clean up this stale audience?"

Skill file: [skills/loops-email-sending-best-practices/SKILL.md](./skills/loops-email-sending-best-practices/SKILL.md)

### `loops-lmx`

Use this skill when you need to:

- create or edit Loops email content in LMX
- design net-new Loops emails from existing Loops themes/components and a visual reference when needed
- review LMX markup for valid tags, nesting, attributes, and variables
- use contact properties, components, sections, dynamic links, or dynamic images in Loops email content
- apply Loops email design guidance while producing valid LMX

Example prompts:

- "Design a new onboarding email using existing Loops themes/components, then write it in LMX."
- "Write a product update campaign in LMX."
- "Convert this lifecycle email copy into Loops LMX."
- "Review this LMX for compatibility."

Skill file: [skills/loops-lmx/SKILL.md](./skills/loops-lmx/SKILL.md)

## Stability notes

- This repo is maintained by Loops.
- The Loops CLI has its own skill in this repo.
- The Loops CLI itself is still pre-release and may change faster than the API and SDK docs.
- The LMX skill tracks documented LMX behavior in the Loops editor and campaign editing API endpoints.

## Versioning and releases

Loops skills are versioned as a single repo-level bundle with GitHub Releases and semver-style tags such as `v1.0.0`.

- Major releases include breaking install or behavior changes, such as renamed or removed skills. Release notes must include migration steps.
- Minor releases add skills, broaden documented capabilities, or refresh substantial product behavior.
- Patch releases correct docs, examples, references, or narrow behavior details without changing install names.

Use the GitHub release notes as the changelog for user-facing upgrade guidance.

## Source of truth

This repo is the installable Loops entry point for agent skills. When product behavior changes faster than this repo, verify against the official Loops resources:

- Docs: https://loops.so/docs
- API reference: https://loops.so/docs/api-reference/intro
- JavaScript SDK: https://loops.so/docs/sdks/javascript
- OpenAPI spec: https://app.loops.so/openapi.json
- CLI repo: https://github.com/loops-so/cli

## Contributing

Pull requests are welcome.

When updating a skill:

- keep `SKILL.md` concise and move detailed material into `references/`
- avoid duplicating the same guidance across `SKILL.md` and references
- verify product-specific details against official Loops sources
- re-run `npx skills add . --list` before merging

## Local validation

```bash
git clone https://github.com/loops-so/skills.git
cd skills
npx skills add . --list
```

## Repository structure

```text
skills/
  loops-api/
    SKILL.md
    references/
  loops-cli/
    SKILL.md
    references/
  loops-lmx/
    SKILL.md
    references/
  loops-email-sending-best-practices/
    SKILL.md
    references/
.cursor-plugin/plugin.json       # Cursor install
.claude-plugin/                  # Claude install
.agents/plugins/marketplace.json # General/Codex marketplace
```
