---
name: check
description: Health check for notify — verifies terminal-notifier/notify-send installed, notify.sh script exists, hook entries in settings.json, and notify-config.json. Use when user asks whether notifications are working, wants to verify notify setup, or mentions missing notifications.
---

# Check Skill — Health Check

You are running a health check for the notify plugin. Verify that all components are installed and configured correctly.

## Scope Detection

Before running checks, detect which scopes have notifications installed:

1. Check if `$HOME/.claude/hooks/notify.sh` exists → **Global** scope found
2. Check if `$PWD/.claude/hooks/notify.sh` exists → **Project** scope found (label as "Project: `$PWD/.claude`")

If both exist, run checks for each scope separately, labeled accordingly. If neither exists, report that no installation was found.

---

## Checks

Run through each check per discovered scope. The notifier backend check is shared (run once).

### 1. Notifier backend (shared)

Detect the platform first with `uname -s`, then check the matching backend:

- **macOS (`Darwin`)** — run `command -v terminal-notifier`.
  - **Pass**: `terminal-notifier` found at [path]
  - **Fail**: `terminal-notifier` is not installed. Run `/notify:setup` to install it.
- **Linux** — run `command -v notify-send`.
  - **Pass**: `notify-send` found at [path]
  - **Fail**: `notify-send` is not installed. Install `libnotify` (e.g. `apt install libnotify-bin`) or run `/notify:setup` for distro-specific instructions.

On Linux, note that sounds map to urgency levels and click-to-focus is unavailable.

### 2. Notification Script

For each discovered scope (`$SCOPE_DIR` = the base directory):

Check if `$SCOPE_DIR/hooks/notify.sh` exists and is executable.

- **Pass**: `notify.sh` exists and is executable
- **Fail**: `notify.sh` is missing or not executable. Run `/notify:setup` to create it.

### 3. Hook Configuration

Read `$SCOPE_DIR/settings.json` and check for notification hooks (Stop, Notification, SubagentStop events referencing `notify.sh`).

Validate that hook commands use the new simplified format (`notify.sh stop`, `notify.sh notification`, `notify.sh subagentStop`) rather than the old format with positional args (`notify.sh 'Claude Code' 'Task completed' ...`).

- **Pass**: Found hooks for [list events] with dynamic command format
- **Warn**: Found hooks but using old static format — re-run `/notify:setup` to upgrade
- **Fail**: No notification hooks found in settings.json. Run `/notify:setup` to configure them.

### 4. Config File

Read `$SCOPE_DIR/notify-config.json` and display current settings.

- **Pass**: Config found. Display as a table, highlighting the `enabled` flag prominently:

> **Current notification settings:**
>
> | Event | Enabled | Fallback Message | Sound | App |
> |-------|---------|------------------|-------|-----|
> | Task completed | ... | ... | ... | ... |
> | Needs attention | ... | ... | ... | ... |
> | Subagent done | ... | ... | ... | ... |
>
> Edit `notify-config.json` to change these — changes take effect immediately.

- **Fail**: Config file not found. The script will use hardcoded defaults. Run `/notify:setup` to generate a config file.

### Summary

Present a summary. When both scopes are active, include a Scope column:

**Single scope:**
> **Health Check Results:**
> | Component | Status |
> |-----------|--------|
> | notifier backend | Pass/Fail |
> | notify.sh | Pass/Fail |
> | Hook config | Pass/Fail |
> | notify-config.json | Pass/Fail |

**Both scopes active:**
> **Health Check Results:**
> | Component | Scope | Status |
> |-----------|-------|--------|
> | notifier backend | Shared | Pass/Fail |
> | notify.sh | Global | Pass/Fail |
> | notify.sh | Project | Pass/Fail |
> | Hook config | Global | Pass/Fail |
> | Hook config | Project | Pass/Fail |
> | notify-config.json | Global | Pass/Fail |
> | notify-config.json | Project | Pass/Fail |

If all pass:
> Everything looks good! Would you like me to send a test notification?

If any fail:
> Some components need attention. Run `/notify:setup` to fix the issues above.

### Test Notification

If the developer requests a test:

**Single scope:** Run the test against that scope's notify.sh by piping mock JSON:
```bash
echo '{"last_assistant_message":"Health check — notifications working!"}' | "$SCOPE_DIR/hooks/notify.sh" stop
```

**Both scopes active:** Ask which scope to test:
> Both global and project-level notifications are configured. Which would you like to test?
> 1. **Global** (`$HOME/.claude`)
> 2. **Project** (`$PWD/.claude`)
> 3. **Both**

Then run the test for the chosen scope(s).

Report whether it succeeded.

## Key Rules

- **Never write any file** — this skill is fully read-only. All Steps are observation and reporting only; no config or hook files are created or modified.
- **Scope detection always runs first** — check both `$HOME/.claude/hooks/notify.sh` and `$PWD/.claude/hooks/notify.sh` before running any per-scope checks. If neither is found, report "no installation found" and stop; do not guess at a scope.
- **Hook format validation is mandatory** — distinguish old static-arg format from the current dynamic format (Step 3). Report an upgrade warning for old format hooks; do not silently accept them as passing.
- **Test notification is opt-in, not automatic** — only run the test notification when the developer explicitly requests it after seeing the summary. Never send a system notification without user confirmation.
- **Both-scope test requires explicit scope selection** — when both global and project scopes are active, use `AskUserQuestion` to confirm which scope(s) to test. Never run tests against both scopes without the developer choosing "Both" explicitly.
