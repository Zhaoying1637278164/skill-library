# notify

> Part of [`claude-plugins`](../README.md) — see also [`onboard`](../onboard/) and [`handoff`](../handoff/).

Cross-platform system notifications for Claude Code. Get notified when tasks complete or Claude needs your attention. Intentionally minimal — see the root README's [notify section](../README.md#notify) for an honest comparison against richer community alternatives.

## Install

```bash
claude plugin install notify@apurvbazari-plugins
```

Then run `/notify:setup` to install the platform backend (`terminal-notifier` on macOS, `notify-send` on Linux) and configure hooks.

## Skills

All skills are invoked with the `/notify:<name>` slash syntax. `check` is auto-invocable; `setup` and `uninstall` require explicit invocation.

### `/notify:setup` *(destructive — user-invoked only)*

Installs the platform backend (`terminal-notifier` via Homebrew on macOS, or `notify-send` from `libnotify` on Linux), detects your editor + bundle ID for click-to-focus, asks whether to install global or per-project, configures hooks for the chosen events, and sends a test notification.

**When to use:** first-time install on a new machine, or when adding per-project overrides on a project that already has global notify configured.

**Edge cases:**
- **Partial completion** — if a previous setup was interrupted (no `notify-config.json` written, but hooks added to `settings.json`), re-running `/notify:setup` detects the partial state and offers to repair, replace, or roll back.
- **Existing global config + new per-project request** — setup reads global as the base and layers your per-project answers as overrides. Doesn't blow away global.
- **Permission prompts (macOS)** — first notification after `terminal-notifier` install triggers a macOS Notification permission prompt; setup warns about this before sending the test notification.

### `/notify:check`

Health check. Reports which scopes have notify installed (global / per-project / both) and the current event configuration (sounds, cooldowns, enabled flags) for each. Offers to send a test notification on request.

**When to use:** after editing `notify-config.json` by hand, after changing editors, when notifications stop firing for an unclear reason, or as a sanity check before relying on notify for a long task.

### `/notify:uninstall` *(destructive — user-invoked only)*

Removes notify hooks from `settings.json` and deletes `notify-config.json`. The platform backend (`terminal-notifier` / `notify-send`) is left installed.

**When to use:** decommissioning notify, switching to a richer alternative (see [the root README's notify section](../README.md#notify) for community options), or troubleshooting a broken setup by starting clean.

**Side effects:**
- Removes hook entries that match notify's command line; **does not** touch unrelated hooks in the same `settings.json`.
- Per-project uninstall does not affect global config, and vice versa — they're independent scopes.

## Hook event model

Three notification events, each independently configurable:

| Event | When | Default |
|---|---|---|
| `stop` | Claude finishes a response | Enabled · `Hero` sound · `minDurationSeconds: 0` (no cooldown) |
| `notification` | Claude needs user attention | Enabled · `Glass` sound · `minDurationSeconds: 0` |
| `subagentStop` | A subagent finishes work | Disabled (too noisy) |

Notification content is extracted from Claude's actual last message — not generic static text. Each notification carries a contextual subtitle (`repo / branch`) so you know which project the alert is from when several Claude sessions are running.

## Example

`/notify:setup` on macOS with a `30`-second cooldown set on `stop`, then two Stop hooks close together — the second suppressed by the cooldown, the first delivered:

```
> /notify:setup

Detecting platform … macOS
Checking for terminal-notifier … installing via Homebrew
Editor detected: VS Code (com.microsoft.VSCode)

Where should notifications be installed?
  (a) Global — fire in every Claude Code session
  (b) This project only

> a

Configuring three events:
  stop          enabled   sound: Hero    minDurationSeconds: 30
  notification  enabled   sound: Glass   minDurationSeconds: 0
  subagentStop  disabled  (too noisy by default)

Writing notify-config.json to ~/.claude/
Adding hooks to ~/.claude/settings.json (Stop, Notification)
Sending test notification … ✓

Setup complete. Edit ~/.claude/notify-config.json anytime — changes take effect immediately.

# ── first stop fires ────────────────────────
[Stop hook fires]
[notify.sh: no recent notification → notify; cooldown clock starts]

  ┌──────────────────────────────────────┐
  │ Claude Code                          │
  │ feedback-saas / feat/onboarding-flow │
  │ Refactored auth middleware …         │
  └──────────────────────────────────────┘

  Sound: Hero · Click brings VS Code to front

# ── second stop, 8s later ───────────────────
[Stop hook fires]
[notify.sh: 8s < 30s cooldown → silently skip]
(no notification — within the cooldown window)
```

## Install scopes

Notifications can be installed globally or per-project:

| Scope | Path | When hooks fire |
|---|---|---|
| **Global** (default) | `~/.claude/` | Every Claude Code session |
| **Per-project** | `<project>/.claude/` | Only when running in that project directory |

Both scopes can coexist — per-project hooks add to global, they don't replace.

## Configuration

Settings live in `notify-config.json` within the chosen scope directory. Edit the file directly — changes take effect immediately, no need to re-run `/notify:setup`. The only setting that requires re-running setup is the `Notification` matcher (which is in `settings.json`, not `notify-config.json`).

### Scope resolution

The runtime hook reads exactly one config: the **project-local** `notify-config.json` when it exists, otherwise the **global** one. There is no key-level merge between scopes — each scope's config stands alone. To change project behaviour, edit that project's `notify-config.json`; to change the default everywhere, edit the global one.

## Customisation

Per event you can configure:

- **Fallback message** — shown when contextual content can't be extracted from Claude's response
- **Sound** — Hero, Glass, Ping, Purr, Pop, Submarine, and more (macOS); urgency level (Linux)
- **App to activate** — VS Code, Cursor, Terminal, iTerm2, or none (macOS click-to-focus)
- **Enabled / disabled** — toggle any event without re-running setup
- **`minDurationSeconds` (notification cooldown)** — a leading-edge cooldown. After a `stop`/`subagentStop` notification fires, further ones are suppressed until this many seconds have elapsed since the one that fired — so at most one notification per `N` seconds. The cooldown clock is tracked per session in a temp file (`$TMPDIR/claude-notify-session-<id>`, or a per-user key when no session id is available). Default `0` (no cooldown). `notification` events are never cooldown-filtered, so attention prompts always fire.

## Platform support

| Platform | Backend | Sound | Click-to-focus | Cooldown |
|---|---|---|---|---|
| macOS | `terminal-notifier` | 14 system sounds | Yes (bundle ID) | Yes |
| Linux | `notify-send` (libnotify) | Urgency levels only | No | Yes |

- **WSL.** Under WSL, `notify-send` reaches the Linux desktop only if a notification daemon is running; for Windows-side toasts, route through a Windows notifier (e.g. `wsl-notify-send`) or run Claude Code natively on Windows.

## Troubleshooting

- **No notifications appearing (macOS)** — Open System Settings → Notifications → terminal-notifier, ensure notifications are allowed. Check that Do Not Disturb / Focus mode is off.
- **Wrong app activates on click** — Edit `notify-config.json`, update the `activate` bundle ID for the affected event, then run `/notify:setup` to re-apply.
- **Notification sound not playing (macOS)** — Verify the sound name is valid: `terminal-notifier -title Test -message Test -sound <SoundName>`. See `/System/Library/Sounds/` for available names.
- **Setup partially completed** — Re-run `/notify:setup`. It detects existing config and offers to update or replace.
- **Permissions issues** — If `terminal-notifier` was installed but notifications don't appear, try `brew reinstall terminal-notifier`, then open it once from Finder to trigger the macOS permission prompt.

## Prerequisites

**macOS:**
- [Homebrew](https://brew.sh) (for installing `terminal-notifier`)
- `jq` (recommended, installed during setup) or `python3` (fallback for JSON parsing)

**Linux:**
- `notify-send` (from `libnotify`, available on most distributions)
- `jq` (recommended) or `python3` (fallback)

**Both platforms:** Claude Code, `git` (used to build the `repo / branch` subtitle).

## Internals

For the hook event model, JSON parsing pattern, script safety rules, and detection logic used by `/onboard:start` to probe whether notify is already configured, see [`notify/CONVENTIONS.md`](./CONVENTIONS.md).

## License

[MIT](../LICENSE)
