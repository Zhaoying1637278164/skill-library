---
description: Full IQland property report for an address (6 sections — classification, parcel metrics, development potential, neighborhood, market, demographics)
argument-hint:
- address
---

Produce a complete IQland property report for: **$ARGUMENTS**

Steps:
1. Call the `overview` IQland tool with this address (it auto-resolves the parcel).
2. Follow the `report_instructions` and per-section `guidance` in the result.
3. Render all six sections in order, with these exact titles, as a polished
   Markdown report (headings, metric tables, bold labels):
   1. Property Classification
   2. Parcel Metrics & Analysis
   3. Development Potential
   4. Neighborhood & Location Analysis
      - Neighborhood Amenities & Services
      - Lifestyle Implications
   5. Housing Trends & Market Analysis
   6. Demographic Data & Community Profile

Expand each section with interpretation, not just raw fields. Where the backend
has no parcel-level data (walk/transit scores, city-wide trends, demographics),
supplement from public knowledge of the City, ST and clearly label those as
estimates. If anything couldn't be resolved, say so plainly.
