---
description: Pull IQland comparable sales for a property and summarize the local market
argument-hint:
- address or parcel_id
---

Get comparable sales for: **$ARGUMENTS**

Steps:
1. If given an address, resolve it with `find_parcel` first; otherwise use the
   parcel_id directly.
2. Call `get_comparable_sales` (lookup_type `parcel_id` or `address`).
3. Present the comps as a Markdown table: address, beds/baths, GLA (ft²), year,
   distance, sold date, sale price, $/ft².
4. Add a short market summary: number of comps, median sale price, price range,
   and median $/ft². Note explicitly that this is a local comp snapshot, not a
   city-wide figure.
