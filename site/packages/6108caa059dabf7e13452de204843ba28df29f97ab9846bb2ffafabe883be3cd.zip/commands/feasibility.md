---
description: Run an IQland SmartBuild build-feasibility analysis for a parcel address
argument-hint:
- parcel address
---

Run a build-feasibility analysis for: **$ARGUMENTS**

Steps:
1. Call the `smartbuild` IQland tool with this parcel address.
2. Present the result as an IQland SmartBuild report:
   - **Zoning regulations** row: Max FAR, Max height, Min lot area, Optimal build range.
   - **Top recommended plan**: name, specs (beds/baths/stories/sqft/width×depth),
     construction cost, est. market value, projected value (90d), equity.
   - **Other matched plans** ranked by value/equity.
   - **Feasibility verdict** callout: is ground-up development viable here? Explain
     the equity math and what would change the answer (land cost, subsidy, rehab).

Show negative equity explicitly. SmartBuild needs a specific street address — if
only a city/zip was given, ask for the full address first.
