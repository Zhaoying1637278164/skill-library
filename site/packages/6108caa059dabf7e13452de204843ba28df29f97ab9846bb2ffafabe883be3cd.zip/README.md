# IQland plugin for Claude Code

Connects Claude to the **IQland MCP server** (`https://d-mcp.iqland.ai/mcp`) for
U.S. real-estate development: parcel & zoning lookup, construction cost, build
feasibility, comparable sales, appraisals and property analytics.

The server uses OAuth 2.1 — the first time the connector loads, Claude Code opens
a browser to sign you in with your IQland account (email + one-time code). The
token is stored in your system keychain and refreshed automatically.

## What's included

- **MCP server** (`.mcp.json`) — the `iqland` remote HTTP MCP server with ~15
  tools (`overview`, `find_parcel`, `get_parcel_zoning`, `get_zoning_regulations`,
  `estimate_construction_cost`, `get_development_kpis`, `get_comparable_sales`,
  `smartbuild`, `appraisal`, …), exposed as `mcp__iqland__*`.
- **Agent** — `iqland-analyst`, a property-analysis subagent that runs the tools
  and renders IQland-style reports.
- **Commands**:
  - `/property-report <address>` — full 6-section property report
  - `/feasibility <parcel address>` — SmartBuild build-feasibility analysis
  - `/comps <address|parcel_id>` — comparable sales + local market summary

## Install

### Option A — as a marketplace (recommended)

From a Claude Code session:

```
/plugin marketplace add /absolute/path/to/IQLand-MCservice-Backend/claude_plugin
/plugin install iqland@iqland
```

Or once this folder is pushed to GitHub:

```
/plugin marketplace add <owner>/<repo>
/plugin install iqland@iqland
```

(CLI equivalents: `claude plugin marketplace add …` / `claude plugin install iqland@iqland`.)

After installing, run `/mcp` and complete the IQland sign-in when prompted.

### Option B — just the MCP server (no plugin)

If you only want the connector without the agent/commands, add the server
directly:

```
claude mcp add --transport http iqland https://d-mcp.iqland.ai/mcp
```

then `/mcp` to authenticate.

## Usage

```
/property-report 6734 W 3 St S, Tulsa, OK 74127
/feasibility 6734 W 3 St S, Tulsa, OK 74127
/comps 6734 W 3 St S, Tulsa, OK 74127
```

Or just ask in plain language ("What can I build on 786 Ruby St, Marietta GA?")
and the `iqland-analyst` agent will use the tools and present a report.

## Verify the plugin

```
claude plugin validate /absolute/path/to/claude_plugin
```
