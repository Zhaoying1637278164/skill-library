# Changelog

## 1.0.0 (2026-03-30)

### Added
- Shopify Liquid skill — complete templating reference
- Theme Development skill — architecture, CLI, performance, accessibility
- Shopify Developer agent — production theme builder
