# liquid-dev

A Shopify Liquid development toolkit for Claude Code. Built by a developer with 13+ years of Shopify experience.

## What's Included

### Skills

- **`/liquid-dev:liquid`** — Complete Shopify Liquid reference: objects, tags, filters, section schemas, blocks, JSON templates, metafields, dynamic sources, and performance patterns.
- **`/liquid-dev:theme-dev`** — Theme development guide: Online Store 2.0 architecture, Shopify CLI workflows, Dawn customization, settings schema design, asset optimization, accessibility, and deployment.

### Agent

- **Shopify Developer** — An expert agent that builds production Shopify themes. Opinionated: vanilla CSS/JS, merchant-friendly settings, performance-first, mobile-first. Treats themes as products, not one-off projects.

## Installation

From the Claude Code plugin marketplace:

```
/plugin install liquid-dev
```

## Usage

The skills are auto-invoked when Claude detects you're working on Shopify themes. You can also invoke them directly:

```
/liquid-dev:liquid
/liquid-dev:theme-dev
```

To use the Shopify Developer agent:

```
/agents
```

Select "shopify-developer" from the list.

## What This Plugin Knows

- Liquid objects, tags, filters, and their real-world usage
- Section architecture — schemas, blocks, presets, settings types
- JSON templates and section groups (Online Store 2.0)
- Metafields, metaobjects, and dynamic sources
- Shopify CLI commands — dev, push, pull, check
- Dawn-based customization vs. forking
- Theme settings design (settings_schema.json)
- Asset management — CSS/JS organization without frameworks
- Responsive image optimization with Shopify CDN
- Performance targets — Lighthouse, Core Web Vitals, LCP, CLS
- Accessibility — semantic HTML, ARIA, focus management, contrast
- Deployment workflows — Git, CI/CD, preview links
- Merchant UX — presets, labels, defaults, info text

## Author

**Hamza Shahbaz** — Founder of Hamza Digital, a Shopify Development Studio.

## License

MIT
