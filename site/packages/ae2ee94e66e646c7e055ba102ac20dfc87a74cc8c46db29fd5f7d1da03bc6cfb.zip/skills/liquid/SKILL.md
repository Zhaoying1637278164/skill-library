---
name: liquid
description: "Shopify Liquid templating reference — objects, tags, filters, section schemas, blocks, JSON templates, metafields, dynamic sources, and performance patterns. Use when building or modifying Shopify theme templates, sections, or snippets."
---

# Shopify Liquid

## Liquid Basics

### Objects (Output)
```liquid
{{ product.title }}
{{ collection.description }}
{{ shop.name }}
```

### Tags (Logic)
```liquid
{% if product.available %}
  <button>Add to cart</button>
{% else %}
  <button disabled>Sold out</button>
{% endif %}

{% for product in collection.products %}
  {{ product.title }}
{% endfor %}
```

### Filters
```liquid
{{ product.price | money }}
{{ product.title | upcase }}
{{ 'now' | date: '%Y-%m-%d' }}
{{ product.description | strip_html | truncate: 150 }}
```

## Key Shopify Objects

| Object | Access | Common Properties |
|--------|--------|-------------------|
| `product` | Product pages, collections | `.title`, `.price`, `.variants`, `.images`, `.available`, `.tags`, `.metafields` |
| `collection` | Collection pages | `.title`, `.products`, `.products_count`, `.sort_by`, `.filters` |
| `cart` | Everywhere | `.items`, `.total_price`, `.item_count`, `.currency` |
| `customer` | When logged in | `.first_name`, `.email`, `.orders`, `.addresses`, `.tags` |
| `shop` | Everywhere | `.name`, `.url`, `.currency`, `.locale` |
| `page` | Custom pages | `.title`, `.content`, `.handle`, `.metafields` |
| `article` | Blog posts | `.title`, `.content`, `.author`, `.published_at`, `.tags`, `.image` |
| `request` | Everywhere | `.host`, `.path`, `.locale`, `.page_type`, `.design_mode` |

## Section Architecture

### Section File Structure
```
sections/
  header.liquid          # Global section
  hero-banner.liquid     # Template section
  featured-collection.liquid
  rich-text.liquid
```

### Section Schema
```liquid
{% schema %}
{
  "name": "Hero Banner",
  "tag": "section",
  "class": "hero-banner",
  "limit": 1,
  "settings": [
    {
      "type": "image_picker",
      "id": "image",
      "label": "Background image"
    },
    {
      "type": "text",
      "id": "heading",
      "label": "Heading",
      "default": "Welcome"
    },
    {
      "type": "richtext",
      "id": "description",
      "label": "Description"
    },
    {
      "type": "url",
      "id": "button_link",
      "label": "Button link"
    },
    {
      "type": "select",
      "id": "layout",
      "label": "Layout",
      "options": [
        { "value": "left", "label": "Left aligned" },
        { "value": "center", "label": "Centered" },
        { "value": "right", "label": "Right aligned" }
      ],
      "default": "center"
    },
    {
      "type": "color",
      "id": "text_color",
      "label": "Text color",
      "default": "#ffffff"
    }
  ],
  "presets": [
    {
      "name": "Hero Banner",
      "settings": {
        "heading": "Welcome to our store"
      }
    }
  ]
}
{% endschema %}
```

### Setting Types Reference

| Type | Use Case | Returns |
|------|----------|---------|
| `text` | Short text, headings | String |
| `textarea` | Multi-line text | String |
| `richtext` | Formatted content | HTML string |
| `image_picker` | Image upload | Image object |
| `url` | Links (internal/external) | URL string |
| `select` | Dropdown options | Option value |
| `checkbox` | Toggle on/off | Boolean |
| `range` | Numeric slider | Number |
| `color` | Color picker | Hex string |
| `color_scheme` | Theme color scheme | Scheme ID |
| `font_picker` | Typography | Font object |
| `liquid` | Custom Liquid code | Rendered HTML |
| `video` | Video upload | Video object |
| `video_url` | YouTube/Vimeo URL | Video URL object |

## Blocks

Blocks let merchants add, remove, and reorder content within a section.

```liquid
{% schema %}
{
  "name": "Content Blocks",
  "max_blocks": 6,
  "blocks": [
    {
      "type": "heading",
      "name": "Heading",
      "settings": [
        { "type": "text", "id": "text", "label": "Heading text" }
      ]
    },
    {
      "type": "image",
      "name": "Image",
      "settings": [
        { "type": "image_picker", "id": "image", "label": "Image" }
      ]
    },
    {
      "type": "text",
      "name": "Text",
      "settings": [
        { "type": "richtext", "id": "content", "label": "Content" }
      ]
    }
  ]
}
{% endschema %}

{% for block in section.blocks %}
  <div {{ block.shopify_attributes }}>
    {% case block.type %}
      {% when 'heading' %}
        <h2>{{ block.settings.text }}</h2>
      {% when 'image' %}
        {{ block.settings.image | image_url: width: 800 | image_tag }}
      {% when 'text' %}
        {{ block.settings.content }}
    {% endcase %}
  </div>
{% endfor %}
```

## JSON Templates (Online Store 2.0)

JSON templates define which sections appear and in what order. Merchants customize via the theme editor.

```json
// templates/product.json
{
  "sections": {
    "main": {
      "type": "main-product",
      "settings": {}
    },
    "recommendations": {
      "type": "product-recommendations",
      "settings": {
        "heading": "You may also like"
      }
    }
  },
  "order": ["main", "recommendations"]
}
```

### Section Groups
For global areas like headers and footers:
```json
// sections/header-group.json
{
  "type": "header",
  "name": "Header",
  "sections": {
    "announcement": { "type": "announcement-bar" },
    "header": { "type": "header" }
  },
  "order": ["announcement", "header"]
}
```

## Metafields

### Access in Liquid
```liquid
{{ product.metafields.custom.care_instructions.value }}
{{ product.metafields.custom.ingredients | metafield_tag }}
{{ page.metafields.custom.faq_items.value }}
```

### Common Types
| Type | Example | Access |
|------|---------|--------|
| `single_line_text_field` | SKU prefix | `.value` |
| `multi_line_text_field` | Care instructions | `.value` |
| `rich_text_field` | Formatted description | `| metafield_tag` |
| `number_integer` | Sort order | `.value` |
| `boolean` | Featured flag | `.value` |
| `date` | Launch date | `.value` |
| `json` | Structured data | `.value` (parse with Liquid) |
| `file_reference` | PDF, image | `.value` |
| `product_reference` | Related product | `.value` (product object) |
| `list.product_reference` | Multiple products | `.value` (array) |

### Dynamic Sources
Connect metafields to section settings via the theme editor — no code needed. Define in schema:
```json
{
  "type": "text",
  "id": "subtitle",
  "label": "Subtitle",
  "info": "Connect to a metafield for dynamic content"
}
```

Merchants can then connect this setting to any compatible metafield in the editor.

## Key Filters

### Money
```liquid
{{ product.price | money }}                    → $29.99
{{ product.price | money_with_currency }}      → $29.99 USD
{{ product.price | money_without_trailing_zeros }} → $29
```

### Images
```liquid
{{ product.featured_image | image_url: width: 600 | image_tag: loading: 'lazy' }}
{{ image | image_url: width: 400, height: 400, crop: 'center' }}
```

### Date
```liquid
{{ article.published_at | date: '%B %d, %Y' }}  → March 28, 2026
{{ 'now' | date: '%Y' }}                         → 2026
```

### String
```liquid
{{ product.title | truncate: 50 }}
{{ product.handle | replace: '-', ' ' | capitalize }}
{{ 'cart.general.title' | t }}  → Localized string
```

### Asset
```liquid
{{ 'styles.css' | asset_url | stylesheet_tag }}
{{ 'script.js' | asset_url | script_tag }}
{{ 'logo.png' | asset_url }}
```

## Performance Patterns

### Assign Outside Loops
```liquid
{% comment %} BAD — recalculates every iteration {% endcomment %}
{% for product in collection.products %}
  {{ settings.currency_symbol }}{{ product.price }}
{% endfor %}

{% comment %} GOOD — assign once {% endcomment %}
{% assign currency = settings.currency_symbol %}
{% for product in collection.products %}
  {{ currency }}{{ product.price }}
{% endfor %}
```

### Use render Over include
```liquid
{% comment %} PREFERRED — encapsulated scope, better performance {% endcomment %}
{% render 'product-card', product: product %}

{% comment %} AVOID — pollutes parent scope {% endcomment %}
{% include 'product-card' %}
```

### Preload Critical Resources
```liquid
<link rel="preload" href="{{ 'base.css' | asset_url }}" as="style">
<link rel="preload" href="{{ 'theme.js' | asset_url }}" as="script">
```

### Lazy Load Below-the-Fold Images
```liquid
{% for product in collection.products %}
  {{ product.featured_image | image_url: width: 400 | image_tag:
    loading: 'lazy',
    decoding: 'async',
    sizes: '(min-width: 750px) 25vw, 50vw'
  }}
{% endfor %}
```

### Minimize Liquid Output Size
- Use `{% comment %}` not HTML comments (HTML comments ship to browser)
- Strip whitespace with `{%- -%}` and `{{- -}}`
- Avoid rendering hidden sections (check `request.design_mode` for editor-only content)

## Pagination
```liquid
{% paginate collection.products by 12 %}
  {% for product in collection.products %}
    {% render 'product-card', product: product %}
  {% endfor %}

  {{ paginate | default_pagination }}
{% endpaginate %}
```

## Localization
```liquid
{{ 'products.product.add_to_cart' | t }}
{{ 'products.product.price' | t: price: product.price | money }}
```

Locale files in `locales/en.default.json`:
```json
{
  "products": {
    "product": {
      "add_to_cart": "Add to cart",
      "price": "Price: {{ price }}"
    }
  }
}
```

## Anti-Patterns

- **Too many sections per template** — More than 25 sections causes editor slowness
- **Over-nesting blocks** — Keep block hierarchy flat (max 1 level deep)
- **Excessive Liquid logic** — If you need complex conditional logic, move it to JavaScript
- **Hardcoded content** — Always use settings or metafields for merchant-editable content
- **Unused sections** — Remove sections that aren't used in any template (dead code)
- **String concatenation in loops** — Use `{% capture %}` outside loops instead
- **Not using section.id** — Always scope CSS/JS to `{{ section.id }}` for multiple instances
