# Plumb — Manifesto

> **Keep every project true to its sources.**

This is the "why" behind Plumb. The two contracts that follow from it are
[`GATE-STANDARD.md`](GATE-STANDARD.md) (how a gate must behave) and
[`KB-STANDARD.md`](KB-STANDARD.md) (where knowledge lives and how it's written).

---

## The problem: recall under load

Project documentation and state drift — not from laziness, but from **recall under
load**. By the time a change is done, the working context is full of diffs and
debugging, and the instruction to update several scattered docs has decayed. The
obvious docs (the changelog) get updated; the conditional ones fall off. The same is
true for an AI agent working the repo: its always-on context grows, copies of the same
fact disagree, and nobody notices until a stale fact misleads someone.

**Louder instructions don't fix recall-under-load.** "Remember to update the docs" in
bold, in three places, still depends on remembering. The fix is to stop relying on
memory and move the work to mechanisms that don't forget.

> Observed concretely on the origin project before Plumb: the always-on core claimed 74
> pages, the state doc said 73, the product actually had 75; the agent's own memory
> still named a branch deleted three sessions earlier; two finished audit scripts gated
> nothing. None of these were caused by carelessness — each was a fact that lived in a
> place nothing kept true.

---

## The core principle

> **Route each kind of drift to the mechanism that matches its nature.**
> Then the always-on context only states *rules* and *points to sources* — it never
> copies them.

Everything in Plumb is one of four moves:

| Kind of thing | Mechanism | Enforced by | Example |
|---|---|---|---|
| **Mechanical / checkable** | a **gate** (script exits non-zero) | the machine (CI) | broken links, schema, types, stale `lastVerified` |
| **Volatile state** | a **single source of truth** + a pointer | structure | counts, versions, inventory live in one file |
| **A decision that's really a value** | **encode in source** (token / config) | construction | design tokens, thresholds propagate automatically |
| **Judgment that lives only in a conversation** | a **ritual** + a harness **hook** | habit, made reliable | decisions, roadmap changes, new conventions |

The power is the **triage**, not any single mechanism. For each thing that could drift,
ask "what kind is it?" and send it to **gate / source / code / ritual**. What's left
after that — the irreducibly human judgment — is small, and one ritual catches it.

### Why each move works

- **A gate** turns a checkable fact into a build failure. It cannot be forgotten,
  argued with, or skipped silently — it names the culprit and exits non-zero. See
  [`GATE-STANDARD.md`](GATE-STANDARD.md).
- **A single source of truth** removes the second copy. Two copies of a fact are two
  things to keep in sync, which is one guaranteed drift. The always-on core points to
  the one home instead of repeating it. See [`KB-STANDARD.md`](KB-STANDARD.md).
- **Encoding a value in source** means a change propagates *by construction*. Change the
  token, and every consumer follows — there is no per-file sweep and no doc to keep in
  sync. One standing convention ("use the token, never hardcode") covers every such
  decision at once.
- **A ritual + hook** is for the residue that no gate can see: a decision made in
  conversation, a convention agreed verbally, a backlog item dropped for a reason. The
  ritual is a fixed checklist ([`/plumb-closeout`](skills/closeout/SKILL.md)); the harness
  hook fires it reliably, independent of what the agent remembers.

---

## Two layers

What was proven on the origin project was only *half* a documentation framework. Plumb
is both halves:

| Layer | Governs | Status at extraction |
|---|---|---|
| **A. Structure (the KB)** | *what* docs exist, how organized, how written, how found | a working **seed** (the doc spine) |
| **B. Integrity (the engine)** | keeping those docs **true and current** | **built and proven** |

The KB says where knowledge goes; the engine keeps it true. Most teams have one without
the other — structure that rots, or integrity checks over no structure. **Plumb is the
pair.**

---

## What this means in practice

1. The always-on core (`CLAUDE.md` / `AGENTS.md`) holds **rules + pointers + a few
   stable bootstrap facts** — never volatile data that has a canonical home elsewhere.
2. Anything mechanically checkable becomes a **gate** that runs in CI and blocks on real
   problems.
3. Anything that is really a value lives in a **token/config**, referenced everywhere,
   hardcoded nowhere.
4. The end of every working session runs **one ritual** to capture the judgment that
   only existed in the conversation.

If a fact in this repo can drift, it is a bug in the triage: it has not yet been routed
to a mechanism. The fix is never "say it louder."
