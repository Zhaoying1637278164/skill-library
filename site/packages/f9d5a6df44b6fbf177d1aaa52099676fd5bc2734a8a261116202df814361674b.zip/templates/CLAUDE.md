# {{PROJECT_NAME}} — AI Assistant Context

> This file is read by Claude Code (and other AI assistants) at the start of every
> session. **Keep it lean and current** — it is the always-on core: rules + pointers +
> a few stable bootstrap facts. Volatile state lives in the docs it points to, never
> here. Last updated: {{DATE}}.
> **[CONTINUOUSLY UPDATED]** · History → `docs/changelog.md` · State → `docs/project-state.md` · Backlog → `docs/roadmap/current.md`
>
> Plumbed with [Plumb](https://github.com/pukaradhikari/plumb) · `plumbVersion: {{PLUMB_VERSION}}`

---

## What this project is

{{ONE_PARAGRAPH_DESCRIPTION — what it is, who it's for, the hard constraints. Stable
facts only; nothing that changes session to session.}}

- **Stack (summary):** {{STACK_SUMMARY}} — full detail in the architecture docs (below).
- {{KEY_CONSTRAINT_OR_AUDIENCE_NOTE}}

---

## References (read on demand) — the doc-map

This file is the always-on core. Detail lives in dedicated files — read the relevant
slice when you need it.

| Need | File |
|---|---|
| Current state, inventory (pages/modules/data) | `docs/project-state.md` |
| Session history / changelog | `docs/changelog.md` |
| Active backlog & next tasks | `docs/roadmap/current.md` |
| Why decisions were made (ADRs) | `docs/decisions/` |
| Architecture (overview, stack, data flows) *(optional slot)* | `docs/architecture/` |
| Operational procedures *(optional slot)* | `docs/runbooks/` |
| Feature / tool specs *(optional slot)* | `docs/specs/` |

> **Deliberately NOT canonical** (do not re-add as a source of truth): {{ARCHIVES_OR_ONE_OFFS, e.g. docs/archive/}}.

---

## Conventions

{{PROJECT CONVENTIONS — naming, file structure, styling, etc. State each rule and point
to where it's enforced. Do not re-enumerate data that has a canonical home.}}

---

## Current state

The real bootstrap context is the rest of this file (what the project is, conventions,
the canonical homes below). The volatile **snapshot** — build status, counts, versions,
inventory — lives **once** in `docs/project-state.md`; it drifts the moment it's copied,
so it is deliberately NOT re-pinned here.

> **Hard cap: ≤ ~3 lines of status here. No PR numbers, no dates, no narrative** — those
> live in `docs/project-state.md` / the changelog. This is the most-rewritten section in
> the spine and accretes detail unless capped; the audit flags bloat here as drift.

- **Build / gates:** keep the build green; the gates run on every PR (see the workflows).
- **Read before you touch related work:**
  - inventory / state → `docs/project-state.md`
  - what's next / backlog → `docs/roadmap/current.md`
  - recent changes and why → `docs/changelog.md`

---

## Maintenance — the plumb line (canonical homes)

Where a fact has a canonical home, this file states the **rule** and **points to the
source** — it does not re-enumerate the data. Canonical homes for this project:

| Kind of knowledge | Canonical home |
|---|---|
| Current state / inventory | `docs/project-state.md` |
| Decisions (why) | `docs/decisions/` |
| {{e.g. design tokens}} | {{e.g. src/styles/tokens.css}} |
| {{e.g. structured data X}} | {{e.g. src/data/X.json}} |

Rules:
- New session notes → `docs/changelog.md` (newest first).
- Inventory / state changes → `docs/project-state.md` (in place).
- Backlog / next tasks → `docs/roadmap/current.md` (in place, with the reason on drops).
- This file's "Current state" is updated **in place** and stays pointer-only. CLAUDE.md
  should stop growing.
- Decisions: jot the ADR stub **at the moment of choice** — closeout only catches what
  survives to session end.
- End of session: run **`/plumb-closeout`** to capture decisions, conventions, roadmap and
  inventory changes that only exist in the conversation.
