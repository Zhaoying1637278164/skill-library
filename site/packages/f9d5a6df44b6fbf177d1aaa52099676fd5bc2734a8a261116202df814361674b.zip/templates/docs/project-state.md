# Project state — {{PROJECT_NAME}}

> The single home for the live snapshot + inventory. **Inventory/state changes go here**,
> never re-pinned in the always-on core (`CLAUDE.md`). Updated **in place** (this
> describes *now*, not history — history is `docs/changelog.md`).
> Backlog → [`docs/roadmap/current.md`](roadmap/current.md) · History → [`docs/changelog.md`](changelog.md).

## Build snapshot

- **Build:** {{e.g. ✅ green, 0 errors}}.
- **Repo / CI:** {{repo url + CI status}}.
- **Workflow / branching:** {{branch model}}.
- **Environments:** {{staging / production status}}.
- **Gates:** {{which gates run, where — link the workflows}}.

---

## Inventory

> The narrative inventory of what exists. Keep it current as things are added, removed, or
> renamed. This is judgment-bearing (it explains, not just lists) — which is why it is
> hand-maintained, not generated.

{{Tables / lists of the project's units — pages, modules, components, endpoints, data
files, etc. Whatever "the things this project is made of" are for this stack.}}

---

## Single-source data files (the plumb line, expanded)

> The canonical data files and what consumes them — so an edit happens in one place and
> propagates. Mirrors the canonical-homes table in `CLAUDE.md`.

- `{{path/to/data.json}}` — **single source of truth for {{X}}**. Consumed by {{...}}.
  {{Carries `lastVerified` if it's a monitored/volatile file.}}

---

## What is NOT yet built

> The launch-blocking / pending-work snapshot. The full prioritised backlog is
> [`docs/roadmap/current.md`](roadmap/current.md); this is the at-a-glance "not done yet".

- {{item}}
