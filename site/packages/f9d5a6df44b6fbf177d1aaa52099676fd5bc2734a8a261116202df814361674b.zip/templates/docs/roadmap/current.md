# Roadmap — current

**[CONTINUOUSLY UPDATED — the living backlog for this project]**
Last updated: {{DATE}}

> Prioritised next work, updated **in place**. When an item is completed, deferred, or
> **dropped**, record it with the **reason** — a removed item says *why* it went, not just
> that it's gone. History of *what was done* lives in
> [`docs/changelog.md`](../changelog.md); this is *what's next*.

## Status legend
- 🔴 Blocked  ·  🟡 In progress  ·  🟢 Done  ·  ⬜ Not started

---

## Next round (immediate priorities)

| # | Task | Status | Notes |
|---|------|--------|-------|
| 1 | {{task}} | ⬜ | {{notes / why / acceptance}} |

---

## Later

| # | Task | Notes |
|---|------|-------|
| | {{task}} | {{notes}} |

---

## Done

> Move items here (or summarise in the changelog) as they complete — keep the active
> lists above lean.

| # | Task | Completed | Notes |
|---|------|-----------|-------|
| | {{task}} | {{date}} | {{notes}} |
