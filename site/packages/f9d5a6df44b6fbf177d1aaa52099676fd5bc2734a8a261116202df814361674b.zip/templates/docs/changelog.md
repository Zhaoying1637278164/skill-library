# Changelog — {{PROJECT_NAME}}

> Session-by-session history, **newest first**. The narrative record: what changed and
> *why*. **Keep each entry to 3–5 sentences** and point to the PR/commits for detail —
> the entry summarises; the diff enumerates. When several entries share a date, add a
> sequence tag ("(b)", "session N cont.") so ordering stays unambiguous. Append-only —
> entries are never edited away; a correction is a new entry.
> Live snapshot → [`project-state.md`](project-state.md) · backlog → [`roadmap/current.md`](roadmap/current.md).

## {{YYYY-MM-DD}} — {{Short title}}

{{What changed and why, in 3–5 sentences. Include anything a future session must know
that the diff won't show. Name or link the PR/commit rather than restating its detail.}}
