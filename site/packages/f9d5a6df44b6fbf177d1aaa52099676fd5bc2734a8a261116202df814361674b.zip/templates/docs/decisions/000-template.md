# ADR-{{NNN}} — {{Decision title}}

**Date:** {{YYYY-MM-DD}}
**Status:** {{Proposed | Accepted | Superseded by ADR-XXX}}
**Decider:** {{who}}
**Related:** {{links to related ADRs / docs, if any}}

> One ADR = one decision. Copy this file to `NNN-short-slug.md` (next number). If this
> decision reverses or supersedes an earlier one, say so here **and** add a "Superseded
> by ADR-{{NNN}}" banner to the old one.

## Context

{{What forces are at play — the problem, constraints, and goals that make a decision
necessary. Enough that a reader in a year understands *why this came up*.}}

## Decision

{{The decision, stated plainly in one or two sentences.}}

## Rationale

{{Why this option. The reasoning that would otherwise live only in the conversation.}}

## Alternatives considered

| Option | Reason rejected |
|---|---|
| {{option}} | {{why not}} |

## Consequences

{{What follows — what becomes true, what work it implies, what trade-offs are now
accepted. Include the downsides honestly.}}
