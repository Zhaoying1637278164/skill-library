# Plumb — Gate Standard

> The contract every gate obeys. This is what makes a pile of scripts feel like one
> framework. Adapters ([`adapters/`](adapters/)) are bundles of gates; each gate in
> every adapter must satisfy this contract.

A **gate** is the mechanism Plumb uses for *mechanical, checkable* drift — the first row
of the triage table in [`MANIFESTO.md`](MANIFESTO.md). If a problem can be detected by a
script, it should be a gate, not a line in a doc asking someone to remember.

---

## The contract

A gate is a **script that exits non-zero on a real problem, and zero otherwise.** Beyond
that, every gate must obey all of the following:

1. **Exit code is the signal.** Exit `1` (non-zero) if and only if there is an
   ERROR-severity finding. Exit `0` otherwise — including when there are WARN-severity
   findings. CI keys off the exit code; nothing else.

2. **Two severities, clearly separated.**
   - **ERROR** — a real defect. Blocks the merge. (broken link, missing required tag,
     schema violation, type error, overdue `lastVerified`.)
   - **WARN** — worth reporting but a judgment call, not a blocker. Printed in the log,
     never affects the exit code. (orphan page, duplicate/over-length metadata, a date
     that's *due soon* but not yet overdue.)

   Keep gates **coarse and trustworthy**. A gate that blocks on judgment calls trains
   people to route around it.

3. **Names the culprit.** Every finding prints **what's wrong and where** — file (and
   line/key/url where applicable). A gate that just says "failed" makes people re-run it
   locally to learn anything; a gate that says
   `[ERROR] Broken internal links (1)  /about/  →  /old-services/` is actionable on sight.

4. **Path-filtered on PRs.** A gate runs on a PR **only when relevant paths change**, so
   it never blocks unrelated work. (A content gate triggers on content/build paths; a
   data gate triggers on the data directory.) Path filters live in the workflow, not the
   script.

5. **Time-based gates also run on a schedule.** Freshness/cadence drift is driven by the
   **calendar**, not by a PR — nobody opening a PR is what makes a `lastVerified` date go
   stale. So any gate that can fail purely from the passage of time **also** runs on
   `cron`, and fails loudly when a file crosses its review window. (It still runs on PRs
   that touch the relevant data, to catch a bad date introduced by that PR.)

6. **Has an escape hatch — logged, never silent.** There must be a way to bypass a gate
   for a legitimate exception (`[skip-<gate>]` in the commit message, or a PR label), so
   a gate never becomes the thing people quietly disable repo-wide. The bypass is
   **visible** (in the commit/PR record) so it can be reviewed. A gate with no escape
   hatch gets deleted the first time it's inconvenient; that's worse than a logged skip.

7. **Read-only and deterministic.** A gate inspects; it does not mutate the repo. Same
   inputs → same result. (Fixing is a separate, explicit action — never a side effect of
   checking.)

8. **Self-contained and fast.** Prefer zero or minimal dependencies and a short timeout.
   The freshness monitor, for example, imports only Node built-ins so CI needs no
   install step. A gate that is slow or flaky gets skipped.

---

## Severity in practice (from the origin crawl gate)

The origin project's crawl gate is the reference implementation of severities. It
classifies, by nature of the finding:

| Finding | Severity | Why |
|---|---|---|
| Broken internal link | ERROR | objectively wrong; ships a 404 |
| Missing `<title>` / meta description / `<h1>` | ERROR | required for a valid, indexable page |
| Multiple `<h1>` | ERROR | structural defect |
| Missing canonical | ERROR | required by the project's SEO contract |
| Orphan page (built, never linked) | WARN | often intentional (utility pages) |
| Duplicate / over-length title or description | WARN | a judgment call; SERP cosmetics |
| Image missing `alt` | WARN | already gated harder elsewhere (axe) — don't double-block |

The rule of thumb: **ERROR = "this is broken," WARN = "look at this."** When unsure,
make it a WARN. A trusted gate that under-blocks is more useful than a distrusted gate
that over-blocks.

---

## Freshness / time-based gates (from the origin data-currency monitor)

A time-based gate adds two things to the contract:

- **A review cadence per source** (`maxAgeDays`). Past it → ERROR (OVERDUE). Within a
  grace window of it → WARN (DUE SOON). Missing or unparseable date → ERROR.
- **A `cron` trigger** in addition to the path-filtered PR trigger, so calendar drift is
  caught without waiting for someone to open a PR.

The monitor checks **only freshness, not facts** — it asserts that a human re-verified
the data recently (by bumping a date), not that the data is correct. Bumping the date is
a human assertion; never bump it on a guess.

---

## How a gate is delivered ([ADR-0001](docs/decisions/0001-spec12-resolutions.md), decision c)

Gate **logic** ships as a **versioned package** (the gate CLI), not as scripts copied
into each repo — because copies drift, the exact thing Plumb prevents. A plumbed repo
carries only:

- a thin **config** (paths / thresholds / which gates / freshness sources), and
- a small **workflow file** that runs `npx <gate-cli> <gate>` against that config.

A fix to a gate reaches every repo on the next version bump; nothing needs re-copying.
See [`gates/`](gates/) for the CLI seed and [`adapters/web-static/`](adapters/web-static/)
for the config + workflow templates that invoke it.

---

## Checklist for a new gate

- [ ] Exits non-zero **only** on ERROR-severity findings.
- [ ] Separates ERROR from WARN; WARN never affects the exit code.
- [ ] Prints file + location for every finding.
- [ ] Workflow path-filters it to the relevant paths.
- [ ] If it can fail from time alone, it also runs on `cron`.
- [ ] Has a logged `[skip-<gate>]` / label escape hatch.
- [ ] Read-only, deterministic, minimal dependencies.
- [ ] Logic lives in the versioned gate CLI; only config + workflow are repo-local.
