# Plumb — AI Assistant Context

> This file is read by Claude Code (and other AI assistants) at the start of every
> session. **Keep it lean and current** — it is the always-on core: rules + pointers +
> a few stable bootstrap facts. Volatile state lives in the docs it points to, never
> here. Last updated: 2026-08-08.
> **[CONTINUOUSLY UPDATED]** · History → `docs/changelog.md` · State → `docs/project-state.md` · Backlog → `docs/roadmap/current.md`
>
> Plumbed with [Plumb](https://github.com/pukaradhikari/plumb) · `plumbVersion: 1.0.0`

---

## What this project is

Plumb is a documentation-integrity framework for AI-assisted repos, delivered as a
Claude Code plugin plus a kit. It defines where project knowledge lives (the doc spine,
Layer A) and keeps it true to the code (gates, audit, and one end-of-session ritual,
Layer B). This repo is the framework itself — the plugin, the standards, the templates,
the gate CLI — not a product built with it. It is also its own first consumer: Plumb is
plumbed with Plumb.

- **Stack (summary):** Markdown skills + Claude Code plugin packaging; a zero-dependency
  Node (>=18) gate CLI in `gates/`; no build step.
- **Hard constraint:** this repo is PUBLIC. No client names, no client repo URLs, no
  absolute local paths, no lifted-from-client examples — "the origin project" / "the
  second canary" / "a third canary" are the sanctioned generics. The private archive
  holds pre-release history.

---

## References (read on demand) — the doc-map

This file is the always-on core. Detail lives in dedicated files — read the relevant
slice when you need it.

| Need | File |
|---|---|
| Current state, inventory | `docs/project-state.md` |
| Session history / changelog | `docs/changelog.md` |
| Active backlog & next tasks | `docs/roadmap/current.md` |
| Why decisions were made (ADRs) | `docs/decisions/` |
| The principle + drift triage | `MANIFESTO.md` |
| The gate contract | `GATE-STANDARD.md` |
| Doc-spine taxonomy + authoring rules | `KB-STANDARD.md` |
| One-page orientation (derived, never canonical) | `docs/blueprint.html` |

> **Deliberately NOT canonical:** `SPEC.md` (frozen design intent, bannered) ·
> `docs/blueprint.html` (derived overview, as-at dated — ADR-0002).

---

## Conventions

- **The four skills are the product.** Editing `skills/*/SKILL.md` changes behaviour for
  every installed user — treat skill edits like API changes and record them in the
  changelog.
- **Writing rules for anything user-facing** (README, skill prose a stranger reads):
  plain English, sentence case headings, Australian English, no emoji, no em-dashes in
  the README, banned-word list per the owner's global rules.
- **Field feedback is re-verified before it becomes a fix** — the friction in a canary
  report is real; the attribution often isn't (see changelog 2026-07-12).
- **Sessions working in OTHER repos never write to this one** — the kit is read-only to
  its own tooling; feedback routes to the user (init/audit/closeout ground rules).

---

## Current state

The volatile snapshot — versions, publish status, inventory — lives **once** in
`docs/project-state.md`; it is deliberately not re-pinned here.

- **Read before you touch related work:**
  - inventory / state → `docs/project-state.md`
  - what's next / backlog → `docs/roadmap/current.md`
  - recent changes and why → `docs/changelog.md`

---

## Maintenance — the plumb line (canonical homes)

Where a fact has a canonical home, this file states the **rule** and **points to the
source** — it does not re-enumerate the data. Canonical homes for this repo:

| Kind of knowledge | Canonical home |
|---|---|
| Current state / inventory | `docs/project-state.md` |
| Decisions (why) | `docs/decisions/` |
| The principle / triage | `MANIFESTO.md` |
| Gate contract | `GATE-STANDARD.md` |
| Spine taxonomy + authoring rules | `KB-STANDARD.md` |
| Gate logic | `gates/` (`@pukaradhikari/plumb-gates`) |
| Plugin + marketplace metadata | `.claude-plugin/` |

Rules:
- New session notes → `docs/changelog.md` (newest first, append-only).
- Inventory / state changes → `docs/project-state.md` (in place).
- Backlog / next tasks → `docs/roadmap/current.md` (in place, with the reason on drops).
- Decisions: jot the ADR stub **at the moment of choice** — closeout only catches what
  survives to session end.
- End of session: run **`/plumb-closeout`** to capture decisions, conventions, roadmap
  and inventory changes that only exist in the conversation.
