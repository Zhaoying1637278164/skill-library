# Plumb

> Keep every project true to its sources.

Plumb is a documentation-integrity framework for AI-assisted repos, built as a Claude
Code plugin plus a kit. It gives project knowledge a fixed home, and it keeps what the
docs say true to what the code does. It is built for people using Claude Code who want a
project to remain understandable when the model, the coding tool, or the developer
changes.

The personal version of this page: [Why I built Plumb](./WHY.md).

> **1.0.0 is the first public release.** Validation to date is dogfooding and field use:
> the kit runs itself, and three private projects hardened the skills before release.
> Read [What Plumb does not do](#what-plumb-does-not-do) before relying on it.

## The problem: recall under load

Docs don't drift because people are lazy. They drift because keeping them current
depends on memory at the worst moment: the work is done, the context is full of diffs
and debugging, and the instruction to update three scattered docs has decayed. The
obvious doc gets updated. The conditional ones fall off.

On the project Plumb was extracted from, one page count had three answers. The always-on
AI context said 74. The state doc said 73. The site had 75. The agent's own memory still
pointed at a branch deleted three sessions earlier.

In an AI-assisted repo this costs more than a stale wiki, because the doc spine is
loaded into every session as context. A stale roadmap steers the agent: "the backlog
says X is open, let's build X". Shipped work gets rebuilt. Finished work gets
deprioritised.

Louder reminders don't fix it. "Remember to update the docs", in bold, in three places,
still depends on remembering.

## The fix: route each kind of drift to a mechanism that doesn't forget

| Kind of thing | Mechanism | Enforced by | Example |
|---|---|---|---|
| Mechanical / checkable | a **gate** (script exits non-zero) | the machine (CI) | broken links, schema, stale `lastVerified` |
| Volatile state | a **single source of truth** plus a pointer | structure | counts, versions, inventory live in one file |
| A decision that's really a value | **encode in source** (token / config) | construction | design tokens, thresholds propagate automatically |
| Judgment that lives only in a conversation | a **ritual** plus a harness **hook** | habit, made reliable | decisions, roadmap changes, new conventions |

The power is the triage, not any single mechanism. What's left after it, the judgement
that only exists in conversation, is small. One ritual catches it. The full argument is
in [`MANIFESTO.md`](MANIFESTO.md).

## Start with one audit

You don't need to adopt anything to find out whether your docs are lying. `/plumb-audit`
runs on any repo with docs.

It lists every claim the docs make that code could confirm or refute (open roadmap
items, done items, inventory counts, status fields), checks each one against the repo,
and reports a drift table with evidence and a direction on every error: work done but
still recorded as open, or recorded done but missing. It edits nothing until you
confirm.

First run against Plumb's own repo: 30 claims checked, 22 clean, 8 drifting. Five of the
eight were finished work still recorded as open.

## The two directions PR tools can't see

Plenty of tools react when code changes and product docs go stale. Plumb covers the two
directions they can't:

- **Conversation to docs.** `/plumb-closeout` is an end-of-session ritual, primed by a
  SessionStart hook so it doesn't rely on anyone remembering. It captures what produced
  no diff: decisions made or killed, conventions agreed, backlog items dropped and why.
  A PR-scoped tool has nothing to react to here.
- **Docs to code.** `/plumb-audit`, above. Claim-level checking, not churn heuristics.

## What Plumb provides

Four Claude Code skills:

| Skill | Purpose |
|---|---|
| `/plumb-init` | Scaffold or retrofit the documentation spine in a repository. |
| `/plumb-closeout` | Run the end-of-session documentation sync ritual. |
| `/plumb-audit` | Check documentation claims against the code and propose corrections. |
| `/plumb-blueprint` | Generate or refresh a self-contained HTML project overview. |

The spine gives each kind of knowledge one home:

```txt
CLAUDE.md                 Stable bootstrap facts, rules, and pointers
AGENTS.md                 Thin cross-tool pointer to CLAUDE.md
docs/project-state.md     Current project state and inventory
docs/changelog.md         Newest-first session history
docs/roadmap/current.md   Lightweight live roadmap
docs/decisions/           Decision records
docs/blueprint.html       Derived visual overview, when generated
```

The kit behind the skills: the three standards ([`MANIFESTO.md`](MANIFESTO.md),
[`GATE-STANDARD.md`](GATE-STANDARD.md), [`KB-STANDARD.md`](KB-STANDARD.md)), the
[`templates/`](templates/), a SessionStart [hook](hooks/) that nudges the ritual once
per session, the [`gates/`](gates/) CLI, and the first stack adapter
([`adapters/web-static/`](adapters/web-static/)). The decisions that shaped the build
are in [`docs/decisions/`](docs/decisions/).

## How it works

Plumb is a Claude Code plugin whose useful parts are skills. There is no `plumb`
command-line binary. The skills work through a plan-first pattern:

1. Inspect the existing documentation and relevant code.
2. Present a proposed mapping, drift table, or change plan.
3. Wait for your confirmation before writing.
4. Update documentation and configuration artefacts only.
5. Prepare changes for review, without pushing or merging.

`/plumb-init` preserves useful existing documentation rather than replacing it. It maps
documents by content, proposes actions such as keep, move, merge, split, or
mark-not-canonical, then asks for approval before changing files.

## The blueprint

`/plumb-blueprint` creates `docs/blueprint.html`, a single self-contained handover view:
business context, architecture, actors and permissions, data model, core workflows,
security posture, and what is built versus pending.

> Machines read the Markdown. Humans read the blueprint.

The blueprint is derived from the spine and the real implementation sources. It is not
a second source of truth: it carries an as-at date, and the closeout ritual refreshes it
when the underlying project changes. It must never include secrets, credentials, keys,
or demo logins.

## Who it's for

Plumb is most useful if you are:

- building software with Claude Code, where the docs are load-bearing AI context
- working across several projects and losing the thread
- returning to a project after time away
- preparing to bring in a human developer, collaborator, or co-founder
- trying to reduce repeated context rebuilding across coding sessions

You may not need it if your existing documentation system stays current and works for
your team. And it is not for product-documentation teams: tools like Swimm and Mintlify
handle docs-for-your-users sync; Plumb is about a repo's internal working knowledge.

## Safety and privacy

Plumb's skills are instructed to modify documentation and configuration artefacts, not
application source code, and the gate CLI is read-only. That said, the safety model is
behavioural, not a sandbox: the skills rely on Claude Code following the
plan-and-confirm instructions. Review every proposed change before approving it.

Plumb runs inside Claude Code. When a skill reads repository files, that content enters
the Claude Code session the same way it would during normal use. Plumb adds no telemetry
and no separate external destination, but you should understand Claude Code's data
handling before using it on private, regulated, or sensitive repositories.

There is no dedicated backup, rollback, or dry-run command. Use git branches and pull
requests as the safety net; the skills stage changes and never push.

## The gates

A small dependency-free Node CLI (`@pukaradhikari/plumb-gates` on npm, Node 18+):

| Gate | Checks |
|---|---|
| `crawl` | Static-site links, metadata, H1, and canonical checks over a built site. |
| `freshness` | Whether configured data files carry a recent `lastVerified` date. |

Gates are read-only and exit non-zero only on error-severity findings. The freshness
gate verifies that a human re-verified the data recently; it does not prove the data is
correct.

## What Plumb does not do

- There is no `plumb` command-line binary. `plumb init` is a skill: interactive, plan
  first, approval before any write. `plumb doctor` and `plumb upgrade` are on the
  roadmap, not built.
- Two gates exist, for static HTML builds only; `web-static` is the only adapter.
- Nothing gates the doc spine in CI yet. The audit runs when a person asks; a scheduled
  headless mode is on the roadmap. Plumb is interactive and plan-first today, not a tool
  for unattended runs.
- The audit checks code-checkable claims only, and its results depend on model
  judgement: a structured review with evidence, not a proof.
- Closeout has to run to work. The hook primes it once per session; a session that dies
  mid-work records nothing. The blueprint can go stale if closeout is skipped: check its
  as-at date.
- There are no committed automated tests or fixtures yet. Validation to date is
  dogfooding and field use.
- Claude Code only. Other tools can read `AGENTS.md`, but they do not get the skills,
  the ritual, the audit, or the hook.

## Installing

```
/plugin marketplace add pukaradhikari/plumb
/plugin install plumb@plumb
```

This makes the four skills and the SessionStart prime available in every repo, and they
propagate on plugin update (no per-repo copies). To test a local clone instead, run
`claude --plugin-dir ./` from this repo.

### Suggested first run

1. Install the plugin (above).
2. Open the repository you want to document.
3. Run `/plumb-audit` for a read-only look at what your docs currently claim, or
   `/plumb-init` to scaffold or retrofit the spine.
4. Read the proposed plan or drift table before approving anything.
5. Run `/plumb-blueprint` when you want the first visual overview.
6. Use `/plumb-closeout` at the end of meaningful work sessions.

## Status

Current state lives in [`docs/project-state.md`](docs/project-state.md), the backlog in
[`docs/roadmap/current.md`](docs/roadmap/current.md), history in
[`docs/changelog.md`](docs/changelog.md). This README doesn't repeat them: Plumb is
plumbed with Plumb, and those files are kept true by the framework itself.

## Vocabulary

| Term | Meaning |
|---|---|
| **the plumb line** | the registry of single sources of truth (what's canonical where) |
| **the gates** | CI checks that verify the project is still true |
| **out of plumb** | drift a gate or ritual caught |
| **`/plumb-closeout`** | the ritual that re-trues the docs at end of session |
| **plumbing a repo** | running `/plumb-init` to stamp a project with the framework |
| **adapter** | a per-stack bundle of gates obeying the gate standard |

## Licence

MIT. See [LICENSE](./LICENSE).
