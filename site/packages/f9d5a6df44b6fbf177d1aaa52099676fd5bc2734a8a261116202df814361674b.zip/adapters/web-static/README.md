# Adapter: `web-static`

The first Plumb stack adapter — a bundle of gates for a **static web build** (Astro,
React/Vite static output, or any SSG that emits HTML to a build dir). Generalized from the
origin project's crawl + data-freshness audits.

An adapter is the **only per-product part** of Plumb. The core (manifesto, standards,
spine, ritual, hook) covers every stack unchanged; an adapter just adds gates that obey
[`../../GATE-STANDARD.md`](../../GATE-STANDARD.md).

## Gates

| Gate | Checks | Trigger |
|---|---|---|
| `crawl` | broken internal links, missing/dup/over-length title+description, missing/multiple H1, missing canonical, missing alt, orphan pages | PR (path-filtered) |
| `freshness` | every monitored single-source data file's `lastVerified` is within its review cadence | daily cron **+** PR (data paths) |

Gate logic lives in the versioned CLI ([`@pukaradhikari/plumb-gates`](../../gates/));
this adapter provides only the **config** + the **workflow templates** that invoke it.

## Installing into a repo

1. Copy `plumb.config.example.json` → the repo root as `plumb.config.json`; edit the
   `gates.crawl` knobs and the `gates.freshness.sources` list for the project.
2. Copy `workflows/audit.yml` and `workflows/freshness.yml` → `.github/workflows/`, and
   fill the `{{...}}` placeholders:
   - `{{BUILD_COMMAND}}` — how the site builds (e.g. `npm run build`).
   - `{{SRC_GLOB}}` / `{{PUBLIC_GLOB}}` / `{{DATA_GLOB}}` — the path filters.
   - `{{CRON}}` — daily off-peak UTC time for the freshness check.
   - Pin the `@pukaradhikari/plumb-gates@^x.y.z` version in both.
3. Ensure `crawl`'s `distDir`/`publicDir` in the config match the build output.

> `plumb init` (Phase 1) automates this — inferring the build command, paths, and a draft
> freshness source list, then confirming with the owner.

## Package note

`@pukaradhikari/plumb-gates` is published to public npm (ADR-0004), so
`npx @pukaradhikari/plumb-gates@^x.y.z` resolves on any CI runner with no registry
auth. The package has zero runtime dependencies; the `freshness` job needs no install
step at all.

## Not included here

The full `web-static` gate set in `SPEC.md` §7 also lists a11y (axe), Lighthouse, and
build/typecheck gates. Those existed in the origin project as separate workflows and are
**deferred to Phase 2/3** (more adapters + gate-standard library). This Phase-0 adapter
ships the two gates that were distilled into the gate standard: `crawl` and `freshness`.
