# Why I built Plumb

I started building products with Claude Code and hit a problem earlier than I expected.

The code moved quickly. The understanding of the code did not.

Even on a basic static site, decisions started to disappear into chat threads, commits, and my own memory. Which stack did we choose? Why this module rather than that one? What did we decide about the data, the workflow, the security posture, or the next thing to build?

On a more complex product, that becomes expensive. You can find parts of the answer in commit history, but not easily. You can keep opening old chats, but that is not a dependable system. You can ask a new model to reread the repository, but that burns context just to get back to a point you had already reached.

I did not want a heavy documentation platform. I wanted a simple spine.

A project should have one current place to understand its state, its important decisions, its roadmap, and the structure of the application. A human developer should be able to pick up the project without calling the original builder. A coding agent should be able to find the relevant context without scanning blindly. Future me should be able to return after a few weeks and know where I left things.

That is what Plumb is for.

## The problem is getting sharper

Documentation has always been the bit people leave until later. Strong engineers avoid it. Small teams postpone it. Solo builders assume they will remember.

AI-assisted development makes that habit more dangerous.

More people can now build software without coming from a conventional engineering background. That is good. But a product can outgrow the memory of the person building it. It can outgrow one chat thread. It can outgrow one model. At some point, you may need a different coding tool, a co-founder, a professional developer, or a larger team.

If the product knowledge lives only in the builder’s head, in scattered chats, or in a giant repository that nobody has time to read, the project becomes harder to hand over and harder to trust.

I have seen a version of this in enterprise technology for years. Internal products get frozen when the person or team who understood them moves on. The next person inherits code, partial documentation, and a long reconstruction job.

AI-assisted projects can repeat that problem at a smaller scale and at much higher speed.

## A documentation spine, not another source of truth

Plumb creates a small set of durable documentation artefacts: current project state, roadmap, changelog, decisions, and pointers that help the next tool or person find the right material.

It also creates an HTML blueprint. That blueprint is not the source of truth. It is a readable, visual overview derived from the documentation spine. It can show the business context, architecture, roles, workflows, data model, security posture, and what is built versus what is still pending.

The simple version is this:

> Machines read the Markdown. Humans read the blueprint.

The purpose is not to avoid reading code. It is to reduce the amount of code a person or model needs to read before they know where to start.

## What I hope it helps with

Plumb is for builders who want a project to remain understandable when the tool, model, or developer changes.

It is useful if you are:

- working across more than one project and losing the thread
- building with Claude Code and want a better end-of-session habit
- preparing to hand work to a human developer or collaborator
- returning to a codebase after time away
- trying to avoid repeatedly rebuilding context from scratch

It is probably not for you if you already have a documentation system that stays current and works, or if you are comfortable keeping the full context of one small project in your head and its commit history.

## Why MIT

I built Plumb for myself first. It came from repeated friction, not a grand plan.

I am releasing it under MIT because it may help other people building in a similar way. Take the parts that are useful. Change the parts that are not. If you find a better way to keep project knowledge current, contribute it back.

This is an early tool. It is lightweight by design. It will not be right for every team.

But I think the underlying problem is real: the code is not the only thing a project needs to survive. The reasoning around it needs somewhere durable to live too.
