---
name: plumb-audit
description: On-demand audit of docs→code drift — walk the doc spine's checkable claims (open/done roadmap items, inventory counts, status fields in queue/data files) against the actual codebase, report a drift table, and correct confirmed findings. The inverse of closeout — closeout asks "what did this conversation produce?"; the audit asks "is what the docs assert still true of the code?". Use when the user says "/plumb-audit", "audit the docs", "verify the docs/roadmap against the code", "is the roadmap still true", suspects the docs are stale — and especially BEFORE a "what should we work on next" planning conversation, which is when a stale backlog does the most damage.
---

# plumb audit — are the docs still true of the code?

Plumb's other layers each cover one drift direction: the **gates** catch mechanical
drift (links, schema, freshness); **closeout** catches conversation→docs drift (facts a
session produced that the docs lack). This skill catches the inverse, which neither can
see: **statements the docs make that the codebase contradicts.** Closeout can't catch it
by design — it only looks at what *this session* produced, and the contradiction usually
predates the session.

This matters most in AI-assisted repos: the doc spine is loaded as always-on context, so
a stale roadmap doesn't just mislead a reader — it actively steers every future session
("the backlog says X is open, let's build X" — duplicating shipped work, or
deprioritising something believed done).

**Ground rules**
- **Scope = the current working directory ONLY.** The Plumb kit and every other repo are
  untouchable — no edits, commits, or GitHub objects there. Findings about Plumb itself
  go **to the user** in your report.
- **Read → report → confirm → correct.** The audit is read-only until the user confirms
  the drift table. Never silently "fix" a doc while scanning.
- **Corrections follow each doc's own convention:** roadmap and project-state update
  **in place**; the changelog is **append-only** — a correction there is a new row
  ("correction: …"), never a rewrite of an old entry.
- The doc paths below are the Plumb defaults; the repo's actual spine paths are in its
  always-on core (`CLAUDE.md`) — use those.

## 1. Pick the pass size

Ask (or infer from how you were invoked):

- **medium (default)** — roadmap + project-state only. The two docs that steer
  sessions; the best value-per-token.
- **full** — adds status/queue data files (topic queues, todo JSONs) and spec claims.
  No changelog archaeology — the changelog records what *was* true; auditing it is
  rarely worth the cost.
- **targeted** — one named doc or one suspicious claim.

**Cost note:** unlike closeout (cheap, conversation-local), this reads broadly across
the repo, and the work scales with the spine's claim count. **The evidence-gathering
scan (step 3) is read-only and well-suited to a subagent** (e.g. an Explore agent, or a
smaller model) — delegate the searching; keep the judgment (steps 4–5) in the main loop.
**Trust, but re-verify:** before the drift table, the main loop must independently
re-check (a) **any subagent finding that would flag a done-item as broken** (false
positives here accuse finished work), and (b) **any row where the subagent's evidence
and its verdict point in different directions** (e.g. evidence "0 found vs 8 claimed"
stamped "CONFIRMED"). Field run: one false positive and one false negative both survived
the subagent's own summary table — the main loop caught them only by re-reading.

## 2. Extract the checkable claims

From the in-scope docs, list every claim the codebase could confirm or refute:

- roadmap items marked **open / pending / in-progress**
- roadmap + state items marked **done** (with the artefacts they name)
- **inventory counts and enumerations** in the state doc (page counts, component lists,
  data-file lists)
- **status fields** in queue/data files (`pending`, `draft`, `ready`, `published`…)
- **enumerations buried inside done-item prose** (city lists, feature lists, "includes
  X·Y·Z" notes) — check these against the **current canonical data**, not just the code
  they describe: a done-item can accurately describe code that is itself stale (field
  case: an email footer's city list still showed an office closed three sessions
  earlier; the doc was "right" about wrong code)
- **claims that contradict other claims in the same spine** (one roadmap row vs another)
- **the always-on core's status / current-state section** — flag **bloat** as drift: PR
  numbers, dates, more than ~3 lines, or any volatile fact whose canonical home is
  project-state/changelog. Field data: the most-rewritten, most drift-prone artifact in
  the spine — it accretes what belongs elsewhere.

Skip claims that aren't code-checkable (intentions, opinions, external-world facts —
those belong to the freshness gate and human review).

## 3. Verify each claim against the code

For each claim, gather evidence from the file tree — don't trust the doc's own
cross-references:

1. **Marked open** → search for evidence the work already exists (named files, routes,
   components, data entries, published content). Flag **"marked open but apparently
   shipped"** — the optimistic-direction error, and the most damaging one.
2. **Marked done** → verify the named artefacts actually exist at the stated paths.
   Flag **"marked done but artefact missing/renamed."**
3. **Counts / enumerations** → recount from the file tree; flag mismatches with both
   numbers.
4. **Status fields** → cross-check each against the artefact it describes (e.g. a queue
   entry `pending` whose post is published `draft: false`; a tool "ready" whose data
   file says draft-pending-review and has no UI).
5. **Cross-claim consistency** → verify enumerations and claims against the canonical
   data files *and against each other* — a fact established in one place (an office
   closed, a feature removed) versus a list embedded elsewhere (an email template's
   city dots, a done-item's feature note). This catches the case where no single claim
   is "wrong" in isolation but the spine — or code it accurately describes — contradicts
   current reality.

Record the **direction** of every error — **optimistic** (work done, recorded as
outstanding), **stale-done** (recorded done, artefact missing/changed), or
**cross-claim inconsistency** — the user triages them differently.

## 4. Report the drift table — then STOP

| Claim | Doc location | Code evidence | Direction | Suggested correction |
|---|---|---|---|---|

One row per finding, evidence concrete (file paths, counts, frontmatter values). If the
audit is clean, say so explicitly — a verified-clean spine is a real result, not a
failure to find things. **Do not edit anything until the user confirms** (they may know
context the code doesn't show — e.g. work intentionally recorded as open pending review).

## 5. Apply confirmed corrections

Fix each confirmed finding in its **canonical home** (per the plumb line), following
each doc's update convention (in-place vs append). If a correction is substantial,
note it for the session's closeout/changelog row.

## 6. Summarise + cadence

Report: claims checked, findings by direction, corrections applied vs declined, and
anything unverifiable (flag, don't guess). Suggest a rhythm if drift was found: **re-run
every N sessions, and always before a planning conversation** — that's when a stale
backlog does the most damage. Feedback about this skill or Plumb itself goes to the
user, never into the Plumb repo.
