---
name: plumb-blueprint
description: Build or refresh the project's solution blueprint — a single self-contained HTML page giving a business + technical overview (roles/permissions matrix, ERD, core workflow swimlane, architecture, security posture) to someone who doesn't know the project. Use when the user says "/blueprint", "solution blueprint", "overview pack", "handover doc", asks for a one-page explainer of the whole system, or when plumb-closeout's blueprint axis flags drift in an existing blueprint.
---

# Solution blueprint — the one-page handover artefact

The blueprint is a **curated pack, not a wiki**: one navigable HTML page a newcomer can
read top to bottom and come away understanding both what the product is (business) and how
it works (technical). The doc spine holds the truth in depth; the blueprint is the
*orientation layer* over it — always derived, never a second source of truth. (It is the
one sanctioned exception to the no-duplication rule — see ADR-0002: its drift is routed,
via the as-at date and closeout's blueprint axis, rather than forbidden.)

**Canonical home: `docs/blueprint.html`** (git-tracked, adjust per repo). On first
creation, add it to the always-on core's doc-map and plumb line so closeout knows to
watch it. (No always-on core yet — repo not plumbed, or its core is pending? Register it
in the state doc's plumb-line table instead, and note that a future `plumb init` /
core-creation should lift it into the doc-map.) If the harness supports rendered artifacts, an artifact copy is optional for
comfortable reading — the repo copy is the one that counts.

## Required sections

Adapt names and emphasis to the project; the *coverage* is non-negotiable. For non-app
projects (frameworks, libraries, CLIs): the permissions matrix may be **behavioral**
(which actor may write which resource, with the enforcing rule/clause named), and the
data model may be **artifact/package structure** — the coverage survives the translation;
don't force an app-shaped section onto a repo that has no such thing.

1. **Business context** — the problem, who has it, the value proposition, positioning.
   Lead with 3–5 stat tiles that make the pain concrete.
2. **Architecture** — the nodes, what runs where, the trust boundaries, and the hard
   constraints called out explicitly (residency, key handling, security boundary).
3. **Actors and surfaces** — every kind of user (including non-login and system actors)
   and which surface/gate each one sees.
4. **Roles and permissions matrix** — resources × roles with a graded chip legend
   (Full / Own / Read / Partial / none) **plus an enforcement column** citing the real
   mechanism by name (e.g. an RLS policy, middleware, route guard, trigger, gate
   component — whatever the stack actually uses). A matrix without the enforcement
   column is marketing; with it, it's engineering.
5. **Data model** — a core-spine ERD as SVG (see below) plus a complete table inventory
   in collapsible per-domain groups, plus file/blob storage and its rules.
6. **Core workflow** — the hero flow as a swimlane (one lane per actor/system), phased,
   with the data that moves named on each step.
7. **Secondary workflows** — shorter, list form.
8. **Security posture** — the principles, stated as practices not aspirations.
9. **Current status** — built vs pending, honestly.
10. **Footer** — sources (the doc-spine files it condenses) and an **as-at date**. The
    date is the refresh contract; never omit it.

## Method

**1. Resolve sources from the doc spine.** Read the always-on core's doc-map and pull the
real homes: state/inventory, architecture, security, decisions, business docs — and for
the data model, **the migrations/schema source itself, not the narrative doc** (narrative
docs drift; DDL doesn't).

**2. Fan out parallel research agents.** Research is grunt work — delegate it to
subagents (a smaller/faster model tier is fine); assembly is not. Three briefs with
exclusive territory, launched concurrently:
- *Roles and permissions*: actor types, how roles are represented in the data model, a
  per-resource matrix with the enforcing mechanism named, key security principles,
  surfaces and gates.
- *Data model*: every current table with purpose, key columns and FK targets; logical
  domain grouping; relationship list with cardinality; file/blob storage; enums. Insist
  on the real schema source and on flagging dropped/deprecated tables so they stay out
  of the ERD.
- *Workflows and business context*: problem/value-prop source material, the hero workflow
  as a swimlane spec (lane, action, data moved, per step), secondary workflows, tech
  architecture summary, status one-liner.

Each brief ends: "return structured markdown; your final message is raw data for the
orchestrator, not user-facing prose." **The lead assembles.** Do not delegate assembly:
information design, user-facing copy (especially in regulated domains), and honesty
calls are judgement work.

**3. Design with the project's own identity.** If the project has a design-token source
(check the doc-map / plumb line for the visual-system home — e.g. a `tokens.css`), derive
everything from it: palette, radii, shadows, type. No token source? Use a restrained
neutral default — don't invent a brand. Build **both themes token-level**
(`prefers-color-scheme` + `data-theme` overrides). Follow the repo's copy rules file if
one exists. Single file, no external requests (CSP-safe): system-stack font fallback,
inline SVG, no CDN anything. Sticky section nav — with a scroll-spy that highlights the
section being read (plain inline JS; it is the page's only script). Every wide element
(matrix, ERD, swimlane) scrolls inside its own `overflow-x: auto` container.

**Visual floor (applies whether or not the project has tokens):**
- **Type scale as tokens, ≤ 7 steps.** Define every font size once as CSS variables at
  the top of the file and reference them everywhere — SVG labels and chips included.
  Never type a raw font-size twice.
- **Minimums:** 16px body; nothing below ~12.5px anywhere, including diagram text.
- **Contrast:** WCAG AA — 4.5:1 for text, 3:1 for large text and graphics. Meaningful
  indicators are text, not decoration: a permission marker or status glyph must meet
  4.5:1, however subtle it looks.
- **Palette budget:** neutrals + one accent. Extra hues only as *declared semantic
  encodings* (swimlane lanes, statuses) — name them as such in a CSS comment so a
  reviewer can tell encoding from decoration.
- **One spacing scale** (4 or 8px base) for every margin, padding and gap.
- 1–2 font families, maximum.

**4. Diagram strategy — clarity beats completeness, captions carry precision.**
- *ERD*: don't draw all tables. Draw the core spine (~8–10 boxes) with the structural
  hubs visually distinguished, plus dashed **domain group boxes** containing the rest as
  chips. Arrows = FK, many-to-one, pointing at the referenced table; dashed = soft ref.
  Where you abbreviate, **say so in the caption** — a simplified diagram with an honest
  caption beats a spaghetti diagram. Full coverage lives in the collapsible inventory.
- *Swimlane*: CSS grid, one column per lane, lane-coloured left borders, phase divider
  rows, numbered steps with a bold action and a muted "what data moves" line.

**5. Truthfulness rules (hard).**
- **No secrets, credentials, demo logins, or keys — ever.** Even ones sitting in
  CLAUDE.md. Assume the page will someday be seen by someone it wasn't made for.
- Separate **built from designed** explicitly; never present a spec as a feature.
- Cite real names (ADRs, policies, RPCs, tables) — they make claims checkable.
- Where a fact has a canonical home, the blueprint states it and points; it never
  elaborates beyond what the source says.

**6. Deliver.** Write the repo copy with a full HTML skeleton (doctype, lang, charset,
viewport). Offer — don't assume — an artifact copy where the harness supports one, and
if the content is sensitive, say plainly that artifacts are private by default and
sharing is the user's opt-in.

## Refresh mode (what closeout invokes)

A refresh is a **diff pass, not a rebuild**:

1. Read the blueprint's as-at date from its footer.
2. Scan the changelog entries since that date, plus `git log` over the schema source,
   routes/gates, and integration paths.
3. Map what changed onto the section list above; touch **only the affected sections**;
   bump the as-at date.
4. If the drift is structural (new domain, schema counts wrong, a new actor or surface),
   re-run the affected research agent rather than hand-patching — hand-patched structure
   is how blueprints start lying.
5. If nothing blueprint-visible changed, say so and change nothing — an untouched
   as-at date is information too.

## Scale

A fresh build is a substantial pass (three agents + assembly) — offer it as its own
chunk of work, not a side effect. On a small repo, collapse the three briefs into one
agent — exclusive territory only matters when there are multiple. A refresh should
usually be minutes: most sessions touch nothing a newcomer-level overview asserts.
**Refresh is closeout's job, not the user's memory:** the blueprint axis checks for
drift every closeout and refreshes only when something blueprint-visible changed — the
user should never need to remember to re-run this skill manually.
