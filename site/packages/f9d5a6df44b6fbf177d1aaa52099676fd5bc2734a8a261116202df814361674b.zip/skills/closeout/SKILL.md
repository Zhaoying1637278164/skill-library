---
name: plumb-closeout
description: End-of-session doc-sync ritual for sessions that produced substantial work — capture what exists only in this conversation (decisions made or killed, roadmap changes, new conventions, inventory or state changes) into the project's docs before it is lost. Use when the user says "/plumb-closeout" or "/closeout", asks to wrap up or finish after a meaningful chunk of work, or when the session made a decision or established a convention that isn't recorded anywhere yet. Skip it (or say "nothing to record") for trivial sessions — a typo fix or a Q&A session with no repo changes doesn't need the ritual.
---

# Closeout — keep the docs true to the session

This ritual catches the one kind of drift **no gate or script can detect**: decisions
and conventions that exist only in this conversation, and the judgment calls about what's
worth recording. The CI gates already cover mechanical drift (links, schema, types,
freshness); this covers the human part. (See the triage in the plugin's `MANIFESTO.md`.)

Work the checklist top to bottom. For each item: **if nothing applies, say so and move
on — don't invent work.** If something applies, make the edit now; if it's clearly out of
scope for this session, flag it to the user as a follow-up task rather than dropping it.

**Scale the pass to the change.** A one-line copy fix doesn't need the full eight-axis
ceremony — scan the axes quickly and skip what's irrelevant (the "say so and move on" clause
is how you scale *down*). Substantial work (a feature, a decision, an inventory change) earns
the full walk; that's where the breadth pays off.

**Know which mode you're in.** In a repo where docs ride every PR, the file-state items
(roadmap, inventory, changelog) are usually already done by closeout time — the pass is then
a **sweep for conversation residue** (decisions, conventions, memory), not re-verification.
In batch-docs repos, all eight axes carry full weight.

This skill is **stack-agnostic**. It refers to the canonical doc spine by role; the
actual file paths for this repo are in the always-on core (`CLAUDE.md` / `AGENTS.md`)
under its References / Maintenance section. Use those paths — the defaults below are the
Plumb spine if the repo hasn't customised them.

**No always-on core yet (repo not plumbed)?** Write to the repo's **existing** doc homes
rather than creating the Plumb-default files alongside them — a new `docs/roadmap/current.md`
next to an existing `docs/roadmap.md` is exactly the duplication this framework exists to
kill. Note in your report that a later `/plumb-init` will re-house them into the spine.

## Checklist

1. **Decisions** — did this session make, change, or *kill* a technical/architectural
   decision (a tradeoff, a "we'll do X not Y", an approach rejected)?
   → If it's ADR-worthy, add the next `docs/decisions/NNN-*.md` and reference it.
   → If it reverses or supersedes an existing ADR, say so in the new one and link it.
   → **Going forward, don't wait for closeout:** when a choice you'd repeat is made
     mid-session, jot the ADR stub *at the moment of choice* — reconstructing it at
     session end loses the reasoning (field case: a pattern was implemented three times
     before closeout finally named it).

2. **Roadmap** — did we complete, add, defer, or abandon a backlog item?
   → Update `docs/roadmap/current.md` (mark done / add / remove). Removing a planned item
     counts — record *why* it was dropped, not just that it's gone.
   → **A completed row is one line + a link** (to the changelog entry / PR). Don't restate
     the narrative in the roadmap — that's the changelog's job, and twin paragraphs are
     exactly the duplication the plumb line exists to kill.

3. **Conventions / rules** — did we establish a new rule about how work is done (a
   naming rule, a styling rule, a "never do X")?
   → Add it where the rule is enforced: the always-on core (the lean rule + a pointer),
     or the relevant source-of-truth doc. **State the rule, point to the source — don't
     re-enumerate data.**

4. **Inventory / state** — did the project's inventory change (pages, components,
   modules, endpoints, data files added / removed / renamed; build status; versions)?
   → Update `docs/project-state.md` (the single home for the snapshot + inventory). **Do
     NOT re-pin counts or status in the always-on core** — that's the duplication the
     structure removes.

5. **Data currency** — did any monitored single-source data file change (the kind the
   freshness gate watches)?
   → Confirm its `lastVerified` (or equivalent) was bumped and the freshness gate is
     green. Bumping a date asserts a human re-verified it — **don't bump on a guess.**
   → If this session introduced a *new* canonical data file, add it to the freshness
     config and to the plumb line in the core.

6. **Changelog** — is there a `docs/changelog.md` entry (newest first) summarising this
   session's work and *why*? This is the narrative record; write it if the work was
   substantial.
   → **Keep it to roughly 3–5 sentences:** what changed, why, and anything a future session
     must know that the diff won't show. Detail belongs in the PR description and commit
     messages — **name or link the PR rather than restating it** (the entry states the
     summary and points to the source; restating is duplication). If you need numbered
     sub-items, that's usually a sign the session should be multiple entries or the detail
     should move to the PR.
   → **The length rule beats house precedent.** If the repo's existing changelog format
     fights brevity (e.g. single-cell table rows that swallow paragraphs), keep the entry
     short anyway and suggest migrating to headings + bullets (holds entries better, merges
     cleaner). Migrate as a deliberate **whole-file, one-time pass** — entries preserved
     verbatim (a re-housing, not a rewrite; append-only intact) — never a gradual per-entry
     switch that leaves the file half-table, half-headings. When several entries share a
     date, add a sequence tag — "(b)", "session N cont." — so ordering stays unambiguous.
   → **Verify the entry is true to the diff.** Run `git status` + `git diff --stat` and check
     the entry against reality: right files named, nothing claimed that isn't in the diff,
     nothing material omitted. **The entry summarises the work truthfully — it does not
     enumerate it.** Completeness lives in the diff/PR; the check is that the summary *names*
     the work right, not that it lists every change.

7. **Blueprint** — if the repo keeps a solution blueprint (look for `docs/blueprint.html`
   or its row in the doc-map / plumb line), did this session change anything the blueprint
   *asserts*? Its visible surface is: schema/tables, roles/permissions and their
   enforcement, surfaces and gates, integrations, the core workflows, security posture,
   business positioning, or built-vs-pending status.
   → Nothing blueprint-visible changed (the common case): say so and move on.
   → Something did: run the `plumb-blueprint` skill in **refresh mode** — touch only the
     affected sections, bump the as-at date, and stage the file with this session's doc
     edits so the blueprint rides the same PR as the change it describes. A section-level
     refresh is cheap — just do it. If the drift is **structural** (re-running research
     agents, or a rebuild), name the cost and get a go-ahead first — don't silently
     balloon the ritual into a multi-agent pass.
   → No blueprint exists but the project has grown to where a handover pack would earn
     its keep? Suggest creating one (`/plumb-blueprint`) — it's its own chunk of work,
     don't build it inside closeout.

8. **PR hygiene — prepare, don't deploy.** Group this session's related doc/config edits so
   they're **PR-shaped**: stage the related files **explicitly** (never `git add -A`), keep the
   changelog + project-state + roadmap updates with the chunk of work they describe, and draft
   the commit/PR message. **Closeout ≠ deploy:** whether to actually commit, push, or merge is
   the **user's call**. If their workflow is "wait for my go," stop at staged-and-ready, say so,
   and don't push or merge unless asked.

## Closeout is not a one-shot

If substantial work lands **after** the ritual has run (a bug fix, a deploy-blocking
issue, a CI failure that leads to real changes, a new decision), **run the checklist
again for the delta** before the session actually ends — scaled to the new work, same
as always. **Append** to the session's records rather than rewriting them (e.g. a
"session N cont." changelog row), so the original closeout stays true to what it
described at the time. The scaling clause keeps repeat runs cheap: most axes will be
"nothing new — skip."

## After the checklist

Briefly tell the user what you recorded and where (one line per doc touched), and what
you deliberately skipped ("no new decisions; no inventory change"). If a memory-worthy
fact about *how the user wants to work* surfaced, save it to memory too.

**Feedback about the tooling itself goes to the user — never into another repo.** If you
have observations or improvement ideas about Plumb (or any framework/dependency), put them in
your report to the user. Do **not** file issues/PRs, commit, or otherwise write them into the
Plumb repo or any repo other than the one you're working in — the user decides what to record
upstream, and where.
