---
name: plumb-init
description: Scaffold or retrofit the CURRENT project with the Plumb doc-sync framework — a five-slot doc spine (CLAUDE.md + AGENTS.md core, project-state, changelog, roadmap, decision records), a registry of canonical sources (the plumb line), and CI drift gates where the stack supports them. Use when the user says "/plumb-init" or "set up Plumb", OR asks in their own words to set up project documentation or an AI-context structure for a repo — e.g. "scaffold CLAUDE.md and docs for this project", "set up a docs system so future sessions have context", "organise our scattered docs", "add ADRs and a changelog structure". Works greenfield or mid-project (retrofit maps existing docs into the spine). Do NOT use for one-off edits to an existing doc.
---

# plumb init — stamp a project with Plumb

This is the skill form of `plumb init`: **you (Claude) perform the setup in the user's
current project, as if running the command.** Bring the project under Plumb — Layer A
(the doc spine) and, where it fits, Layer B (the gates).

**Ground rules**
- **Scope = the current working directory ONLY.** The project being plumbed is `cwd`. Assess
  only files under `cwd`. Do **not** import names, facts, decisions, or inventory about *other*
  projects from memory, earlier sessions, or other repos that happen to be on disk (the kit
  search in step 1 may surface other repos — irrelevant here). **Important distinction:** ignore
  memory as a *source of state facts*, but you still **scan memory as an artifact** to flag stale
  pointers (steps 2 + 8). "Ignore memory" must not cancel the memory-pointer scan.
- **The Plumb kit is READ-ONLY.** Read templates/adapters from the kit located in step 1;
  never write to it, or to any repo other than the current project — no file edits, no
  commits, no GitHub objects (issues, PRs, discussions, comments). Feedback about Plumb
  itself goes **to the user in your summary** (step 8); they decide what to record upstream.
- **Discover and plan before you change anything.** Show the plan; get approval; then act.
- **Ask before writing or overwriting any file.** Never clobber existing content blindly.
- **If the project is a git repo, work on a new branch** (e.g. `chore/plumb-init`) and
  open/offer a PR at the end — don't commit to the default branch, don't merge.
- **Confirm, don't guess.** Propose; let the user correct.
- **No *invented* content — but relocating real history is fine.** Empty spine slots stay empty
  until the project earns that knowledge. For retrofits, the line: **relocating rationale or
  decisions that were already recorded** (in prose, design/schema docs, or an archived monolith)
  **into ADR/spine format is legitimate** — it's a move, not invention; cite where it came from.
  **Inventing** rationale/decisions that were never written down is the forbidden fake content.
- Rationale, if needed: the kit's `MANIFESTO.md` / `KB-STANDARD.md` / `GATE-STANDARD.md`.

## 1. Locate the Plumb kit (fast + deterministic — NEVER scan the whole disk)

Find the kit root (the directory containing `MANIFESTO.md` and `templates/`). Try these **in
order and STOP at the first hit**. **Do NOT run `find ~` or any broad home-directory scan** —
it is slow and can trigger OS file-access permission prompts.

```bash
# (a) Plugin install (the normal case) — the plugin root IS the kit root. Instant.
[ -n "$CLAUDE_PLUGIN_ROOT" ] && [ -f "$CLAUDE_PLUGIN_ROOT/MANIFESTO.md" ] && echo "$CLAUDE_PLUGIN_ROOT"
# (b) User-level skill install — skills may be SYMLINKED to a local checkout, so the
#     kit root is two levels up from the link target. Instant, no scan.
for s in ~/.claude/skills/plumb-init ~/.claude/skills/plumb-closeout; do
  t=$(readlink "$s" 2>/dev/null) && [ -n "$t" ] && (cd "$(dirname "$t")/.." && pwd) && break
done
# (c) Installed plugin cache (bounded — the plugins dir is small):
find ~/.claude/plugins -maxdepth 5 -path '*plumb*/templates/CLAUDE.md' 2>/dev/null | head -1
# (d) Common dev locations — instant stat, no traversal:
for d in ~/plumb ~/Projects/plumb ~/code/plumb ~/dev/plumb ~/src/plumb ~/repos/plumb ~/Desktop/plumb; do
  [ -f "$d/MANIFESTO.md" ] && echo "$d" && break
done
```

If none of (a)–(d) hit, **ASK the user for the Plumb repo path** — do not fall back to scanning
the home directory. Verify the chosen root contains `MANIFESTO.md` + `templates/CLAUDE.md`, then
read templates/adapter files from it by absolute path. **Read-only** — copy *from* the kit into
the current project; never write back to the kit (see ground rules).

## 2. Discover what's already here

Build a complete picture **before** proposing anything.

- **Enumerate** every doc-like file and every candidate canonical source:
  ```bash
  git ls-files 2>/dev/null | grep -iE '\.(md|mdx|rst|txt)$|(^|/)(docs|adr|decisions)/|readme|changelog|roadmap'
  # fallback if not a git repo:
  find . -path ./node_modules -prune -o -type f \( -iname '*.md' -o -ipath '*/docs/*' \) -print 2>/dev/null
  ```
  Also note **plumb-line candidates**: the package manifest (versions), token/config
  files, `data/*.json` or similar single-source data, and the build-output dir.
- **Read each doc** — at least its title, headings, and opening lines. Classification is
  by **content**, not filename alone (a file called `notes.md` may be a changelog).
- **Verify load-bearing doc claims against the CODE — before classifying (retrofits).** This is
  the single highest-value step. Stale docs are the *norm* in any project with history, and
  classification trusts doc content — so trusting a stale doc copies a *lie* into the new spine
  (a tidier copy of wrong information). For each load-bearing claim (architecture, auth model,
  where logic runs, data flow, "current state"), check it against the actual code/config. **Flag
  contradictions**, and plan to record the **verified truth** in the spine, not the doc's claim.
  *(Field example: docs said an LLM ran "client-side" with "no auth"; the code had been
  server-side Edge Functions with auth-scoped RLS for weeks.)*
- Note the **stack**, whether there's a **static web build** (a `web-static` candidate),
  and whether the project is **greenfield** or has **real history** to map.
- **Check where current truth lives (branch divergence).** Don't assume the init base branch
  holds the latest docs. List branches by recency (`git for-each-ref --sort=-committerdate
  --format='%(refname:short) %(committerdate:relative)' refs/heads`). If the most-recently-active
  branch differs from the base you'd init from, **STOP and ask**: "which branch holds current
  truth — should I sync those docs onto the init branch?" And warn up front about the two
  consequences if you sync: docs will momentarily **lead** the base's code, and that feature
  branch will need a **rebase** after the init PR merges (spine files move/rename under it).
- **Scan for external memory pointers** that reference docs you might move/archive. Check
  the harness's project memory if it keeps one (e.g. `~/.claude/projects/<cwd-slug>/memory/`),
  plus `./CLAUDE.local.md` and `./.claude/`, for mentions
  of doc paths (e.g. a memory note saying "read `docs/ROADMAP.md` — source of truth"). Memory
  lives **outside** the repo, so the doc-map and link checks can't see it — note any pointer
  that will dangle after the retrofit, for the closing summary.

## 3. Classify & map — produce the retrofit plan (then confirm)

Classify each doc into a spine slot using Plumb's taxonomy (KB-STANDARD: Diátaxis kind +
a temporal axis). **Content wins over filename.** Signals:

| If the doc is… | Typical signals | → Spine slot |
|---|---|---|
| index / rules + pointers for the repo | root `CLAUDE.md`/`AGENTS.md`, "for contributors", links outward | **always-on core** (`CLAUDE.md`) |
| a live snapshot / inventory / status | "current state", counts, lists of what exists | `docs/project-state.md` (reference) |
| a dated log of changes | `CHANGELOG`, dated entries, version headings | `docs/changelog.md` (past) |
| a backlog / plan / TODO / next steps | `ROADMAP`, `TODO`, "planned", checkboxes | `docs/roadmap/current.md` (future) |
| a decision + rationale ("why X not Y") | `ADR-`, `decisions/`, context/decision/consequences | `docs/decisions/NNN-*.md` (explanation) |
| system design / architecture / data flow | "architecture", "overview", stack, diagrams | `docs/architecture/` (optional) |
| a step-by-step operational procedure | "how to", "setup", "deploy", "runbook" | `docs/runbooks/` (optional) |
| a feature/tool spec or requirements | "spec", "requirements", a schema | `docs/specs/` (optional) |
| a one-off / superseded / archive | "old", "archive", "draft", clearly stale | **mark NOT canonical** (note in the doc-map) |
| unclear | — | **ASK the user** |

From that, assemble a **retrofit plan** — a table the user approves before anything is
touched:

| Existing file | What it is | → Action |
|---|---|---|
| `README.md` | project intro | keep; lift any rules/pointers into `CLAUDE.md` |
| `NOTES.md` | mixed state + todos | **split**: state → `project-state.md`, todos → `roadmap` |
| `docs/old-plan.md` | superseded | **mark not-canonical** |
| (no decisions found) | — | **create** empty `docs/decisions/` + template |

Each action is one of: **create** (empty, from template) · **move** · **merge** (into a
spine file, keeping content) · **keep in place** (already a good home — just point to it) ·
**split** (one file → several slots) · **banner-partial** (see below) · **mark not-canonical** ·
**collapse duplicate**.

**Partial canonicity is first-class — don't force a whole-file verdict.** Real docs are often
internally mixed: part durable, part stale. The right action is frequently *intra-document* —
keep the durable sections, add a `> ⚠ Not current — see docs/project-state.md` **banner** over
the stale sections, and point their state claims at the canonical home. Name in the plan which
sections are canonical vs stale. (Field example: a context doc whose §1–3 product context was
durable but §4–5 current-state was stale → keep §1–3, banner §4–5.)

**`split` hides a depth decision — surface it.** Splitting a large fused doc (e.g. a 700-line
ledger) into the changelog forces "how far back do I backfill?" Put it to the user: **recent
entries + a pointer to the archived original**, or a **full backfill**? Don't decide silently.

Also surface, in the plan:
- **Duplicated facts** — the same count / version / decision living in two places →
  choose one canonical home, replace the copies with pointers (this is the core fix; see
  `KB-STANDARD.md` §2).
- **Gaps** — core slots with no existing doc → create from template, empty.

**Present this plan and get confirmation before changing any file.**

## 4. Apply the plan (scaffold + merge Layer A)

Execute the approved plan, filling template placeholders (`{{PROJECT_NAME}}`, `{{DATE}}`,
`{{PLUMB_VERSION}}` = the kit's version, etc.).
- **Merge** into an existing `CLAUDE.md` — keep its content; add the missing Plumb bones
  (References doc-map, Maintenance / plumb-line section, the `/plumb-closeout` pointer).
  Don't overwrite a working core.
- Add an **`AGENTS.md`** thin pointer if none exists.
- Prefer **move/merge with a pointer** over deletion; never remove content without the
  user's ok.
- **Record verified truth, not stale claims.** Where step 2 flagged a doc claim that contradicts
  the code, correct it to reality (with the user) as it lands in the spine — don't carry the
  wrong fact forward into a tidier home.
- **Move first, then banner (link gotcha).** Adding a not-canonical banner *before* `git mv`
  breaks root-relative links after the move. Either move the file first then banner it, or author
  the banner's links relative to the destination. (A deterministic `plumb init` must encode this
  ordering.)

## 5. Record the plumb line (infer, then confirm)

From the plumb-line candidates found in step 2, **propose a "canonical homes" table** —
which file is the single source for which kind of fact — let the user confirm/edit, then
write it into `CLAUDE.md`'s Maintenance section. Greenfield → ask a couple of seed
questions instead of inferring.

## 6. Wire the gates (only where they fit)

Adapters are added **lazily** — only when there's a checkable surface.
- **Static web build → `web-static` adapter:** copy `plumb.config.example.json` →
  `plumb.config.json`; set `distDir`/`publicDir`, title/description limits, and the
  freshness `sources` (the volatile single-source data files + cadence) **with the user**.
- **Run locally now:** add scripts invoking the published CLI, e.g.
  `"audit": "npx @pukaradhikari/plumb-gates crawl"`,
  `"freshness": "npx @pukaradhikari/plumb-gates freshness"`.
- **CI:** copy the adapter workflows and fill their placeholders — they call
  `npx @pukaradhikari/plumb-gates …`, which resolves from public npm with no registry
  auth.
- **No checkable surface yet?** Skip gates and note it.

## 7. The ritual is already there (check how)

If the Plumb **plugin** is installed, `/plumb-closeout` + the SessionStart prime come with
it — nothing to scaffold. If the skills are installed another way (e.g. user-level, no
plugin), wire the prime manually: merge `templates/settings.fragment.json` into the repo's
`.claude/settings.json` and copy the kit's `hooks/closeout-prime.txt` to
`.claude/hooks/closeout-prime.txt` (the path the fragment's command reads — note the
prime lives in the kit's `hooks/`, not `templates/`). Either way, if the
project had its own closeout copies, offer to retire them and point `CLAUDE.md` at
`/plumb-closeout`.

## 8. Finish — give the user a clear summary

Report, concisely:
- **Discovered:** how many docs were found and how each was classified.
- **Mapping applied:** the file → slot → action table, as actually executed (created vs
  moved vs merged vs kept vs marked not-canonical vs split).
- **Duplications collapsed:** what was de-duplicated and where the single source now lives.
- **Gaps filled:** which empty spine slots were created.
- **Plumb line:** the confirmed canonical-homes table.
- **Gates:** wired (and how to run them) or deferred, with the reason.
- **Stale memory pointers:** any out-of-repo memory files (from the step-2 scan) that referenced
  docs you moved/archived — list them and recommend repointing at `CLAUDE.md`/the spine. **Do not
  edit user memory yourself** — flag and offer.
- **Branch / PR** opened (not merged).
- **Friction worth improving Plumb** (the canary loop): **report it here, to the user.** Do NOT
  write or commit it into the Plumb kit/framework repo — the user decides what to record there.
