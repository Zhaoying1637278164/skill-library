# Plumb — specification (v0 draft)

> **Historical blueprint — frozen design intent (2026-06-05).** The repo now exists and
> Phase 0 is built; the header below reflects the design session, not the present. The
> §12 open questions were resolved in
> [ADR-0001](docs/decisions/0001-spec12-resolutions.md); live status →
> [`docs/project-state.md`](docs/project-state.md). This file is deliberately not
> rewritten (the plumb line records it as frozen design intent).

> **Plumb keeps every project true to its sources.**
>
> A portable framework for documentation + project knowledge that does two things at once:
> defines *where* knowledge lives (the KB structure) and keeps it *true and current* (the
> evergreen engine). Extracted from a method first forged on a live production project.
>
> Status: design draft, session 20 (2026-06-05). Not yet a repo. This document is the blueprint.

---

## 1. Why Plumb exists

Project documentation and state drift — not from laziness, but from **recall under load**. By the
time a change is done, the context is full of diffs and debugging, and the instruction to update
several scattered docs has decayed. The obvious docs (changelog) get updated; the conditional ones
fall off. The same is true for an AI agent working the repo: the always-on context grows, copies of
facts disagree, and nobody notices until a stale fact misleads someone.

**Louder instructions don't fix recall-under-load.** The fix is to stop relying on memory and move the
work to mechanisms that don't forget.

Observed concretely on the origin project before Plumb: the always-on core claimed 74 pages, the state doc
said 73, the product actually had 75; the agent's own memory still named a branch deleted three sessions
earlier; two finished audit scripts gated nothing.

---

## 2. The core principle

> **Route each kind of drift to the mechanism that matches its nature.**
> Then the always-on context only states *rules* and *points to sources* — it never copies them.

Everything in Plumb is one of four moves:

| Kind of thing | Mechanism | Enforced by | Example |
|---|---|---|---|
| Mechanical / checkable | a **gate** (script exits non-zero) | the machine (CI) | broken links, schema, types, stale `lastVerified` |
| Volatile state | a **single source of truth** + a pointer | structure | counts, versions, inventory live in one file |
| A decision that's really a value | **encode in source** (token / config) | construction | design tokens, thresholds propagate automatically |
| Judgment that lives only in a conversation | a **ritual** + a harness **hook** | habit, made reliable | decisions, roadmap changes, new conventions |

The power is the **triage**, not any single mechanism: for each thing that could drift, ask "what
kind is it?" and send it to gate / source / code / ritual. What's left after that — the irreducibly
human judgment — is small, and one ritual catches it.

---

## 3. Two layers

What was proven on the origin project was only *half* a documentation framework. Plumb is both halves:

| Layer | Governs | Status at extraction |
|---|---|---|
| **A. Structure (the KB)** | *what* docs exist, how organized, how written, how found | a working **seed** (the doc spine) |
| **B. Integrity (the evergreen engine)** | keeping those docs **true and current** | **built and proven** |

The KB says where knowledge goes; the engine keeps it true. Most teams have one without the other —
structure that rots, or integrity checks over no structure. Plumb is the pair.

---

## 4. Layer A — the KB / documentation structure

### 4.1 The doc spine (taxonomy) — tiered

A tiered spine avoids both failure modes — empty ceremony (too much) vs no home for a fact (too little).
Every project gets the **core**; it grows into the **optional** slots only when it actually has that kind
of knowledge.

**Core (every project):**

| Slot | Kind | Purpose | Canonical file |
|---|---|---|---|
| **The always-on core** | index | rules + pointers; agent/human bootstrap | `CLAUDE.md` / `AGENTS.md` |
| **Current state** | reference | live snapshot + inventory | `docs/project-state.md` |
| **History (past)** | temporal | session log, newest first | `docs/changelog.md` |
| **Backlog (future)** | temporal | prioritised next work | `docs/roadmap/current.md` |
| **Decisions** | explanation | *why* — tradeoffs made/rejected | `docs/decisions/NNN-*.md` |

**Optional (add when the project has this knowledge):**

| Slot | Kind | Add when |
|---|---|---|
| **Architecture** | explanation/reference | the system is non-trivial (data flows, stack rationale) |
| **How-to / runbooks** | how-to | there are repeatable operational procedures |
| **Specs** | reference | features/tools are built to a written spec |

Mapping: Diátaxis (explanation / how-to / reference / tutorial) **plus** a temporal axis (past/future)
Diátaxis lacks, **plus** the always-on core as the index. Product-facing tutorials, if any, are an
optional slot — not part of the internal spine.

> **Note on rigour:** this taxonomy is a *reasoned hypothesis* (Diátaxis + the origin project's organic
> structure), **not** the output of formal research. Treat the varied portfolio (web, PWA, mobile, lib,
> API) as the validation set — refine slot definitions as real projects reveal a missing or redundant
> home. The core five are the safe bet; the optional three are where to expect churn.

### 4.2 Per-slot templates
Each slot ships a template (ADR template, runbook template, etc.) so structure is consistent across
projects. The ADR/changelog/project-state/roadmap templates are lifted from the origin project.

### 4.3 Authoring standard (the voice rules)
- **State the rule, point to the source.** Never re-enumerate data that has a canonical home.
- **Lean always-on core.** `CLAUDE.md` holds rules + pointers + the few stable bootstrap facts; volatile
  state is referenced, not pinned.
- **Append vs in-place:** changelog appends (newest first); project-state/roadmap update in place;
  the core's "current state" is pointers only.
- **No duplication.** Two copies of a fact = two things to keep in sync = guaranteed drift.

### 4.4 The doc-map
A single index (in `CLAUDE.md` / a `docs/README.md`) answering "where does knowledge of type X live?"
so a human or agent never guesses. v1 = hand-maintained index. v2 = generated + coverage-checked.

---

## 5. Layer B — the integrity engine

### 5.1 The plumb line (single-source registry)
The per-project list of *what is canonical where* — design tokens → `tokens.css`; offices → `offices.json`;
current state → `project-state.md`; etc. Captured into `CLAUDE.md` at init. This is project-specific and
is the reference everything else is checked "true" against.

### 5.2 The gate standard (the contract every gate obeys)
This is what makes a pile of scripts feel like one framework:
- A gate is a **script that exits non-zero on a real problem**, zero otherwise.
- **Severity:** ERROR blocks; WARN reports but doesn't block.
- **Path-filtered:** runs on PRs only when relevant paths change (don't block unrelated work).
- **Time-based gates** (freshness/cadence) also run on a **schedule** (cron), since calendar drift
  isn't triggered by a PR.
- **Escape hatch:** a logged `[skip-...]` bypass, so a gate never becomes something people route around.
- **Names the culprit** in its output (file + line + what's wrong).

### 5.3 Encode-as-value
Decisions that are really values (theme, thresholds, copy constants) live in tokens/config/semantic
classes so a change propagates by construction — no per-file sweep, no doc to keep in sync. One standing
convention ("use the token, never hardcode") covers every such decision at once.

### 5.4 The ritual + hook (for what no gate can catch)
- **`/closeout`** — a skill: a fixed end-of-session checklist (decisions/ADRs, roadmap, conventions,
  inventory, data currency, changelog, PR hygiene). The only thing that captures conversation-only judgment.
- **SessionStart hook** — primes the ritual once per session (no per-turn noise). Harness-executed, so it
  fires regardless of what the agent remembers.

---

## 6. Architecture & delivery

**Primary form: a Claude Code plugin + a kit.** (Install once → available in every repo; framework fixes
propagate to all projects. This is itself the single-source principle applied to the framework.)

```
plumb/                         # the plugin + kit repo (NOT inside any product repo)
├─ MANIFESTO.md                # §2 principle + the triage table (the "why")
├─ GATE-STANDARD.md            # §5.2 the contract every adapter's gates obey
├─ KB-STANDARD.md              # §4 taxonomy + authoring standard
├─ skills/closeout/SKILL.md    # the ritual (stack-agnostic)
├─ hooks/                      # SessionStart prime + settings fragment
├─ commands/
│   ├─ init                    # scaffold a target repo (see §6.1)
│   ├─ upgrade                 # re-sync scaffolded copies to latest (see §8)
│   └─ doctor                  # report drift between repo and plumb version
├─ templates/                  # CLAUDE.md, ADR, project-state, changelog, roadmap skeletons
└─ adapters/                   # per-stack gate bundles (see §7)
    ├─ web-static/  ts-lib/  python-api/  react-pwa/  mobile-native/  generic/
```

### 6.1 `plumb init` (how a new product gets plumbed)
1. Install the Plumb plugin in Claude Code (once, global).
2. In the target repo: `plumb init`.
3. It asks two questions: **stack?** and **what are your canonical sources?** (the plumb line).
4. It scaffolds Layer A (CLAUDE.md core + doc spine + templates), wires the `.claude/` ritual + hook,
   records the plumb line into `CLAUDE.md`, installs the chosen **adapter's** gates + CI workflows,
   and opens a PR.
5. From then on: the hook primes `/closeout`, gates run on PRs, docs stay plumb.

### 6.2 Greenfield vs retrofit
`plumb init` serves both, and is **incremental + re-runnable** — you needn't have every decision on day one:
- **Greenfield (new project):** run `init` right after the repo is created — you start plumb from commit 1.
  Structure + templates are scaffolded; slots begin empty and fill as the project grows (no fake content).
  The adapter can be added later via `plumb add-adapter` once the stack solidifies. **This is the cleaner
  path** (no existing mess to reconcile) and the intended default for a new product.
- **Retrofit (mid-project):** `init` scaffolds what's missing, helps map existing docs into the spine, and
  flags duplication to collapse into single sources. More reconciliation, same end state.

So: **Plumb is among the first things you fire up on a new project** (right after repo creation), not only
a retrofit tool. Retrofit is the path for projects already underway.

---

## 7. Stack adapters

Adapters are the **only per-product part**. The core covers every stack unchanged; an adapter is just a
bundle of gates that obey §5.2. Build them **lazily — one per product as it's onboarded**, not up front.

| Adapter | Representative gates |
|---|---|
| `web-static` (Astro/React) | crawl (links/meta/H1/canonical), a11y (axe), data freshness, Lighthouse |
| `react-pwa` | web gates + manifest/service-worker checks, install/offline smoke |
| `ts-lib` | typecheck, unit, **public-API-surface diff**, dependency audit |
| `python-api` | ruff, mypy, contract/schema tests, data freshness |
| `mobile-native` (iOS/Android) | build, unit/UI tests, app-size budget, asset-catalog/a11y lint — **run in native CI** (Xcode/fastlane, Gradle), not Node |
| `generic` | doc-sync presence, changelog-touched, freshness |

**Mobile note:** the gates run in native CI and check different things, but the **core + ritual + hook
still apply** (they run through Claude Code regardless of stack). Mobile gets the full core + a thinner,
native-CI adapter.

---

## 8. Keeping Plumb itself evergreen (self-application)

Plumb must eat its own dog food, or it's a hypocrite:

- **Plugin parts** (skill, hook, commands) propagate automatically on plugin update. ✓
- **Scaffolded parts** (templates/adapters copied into a repo) are *copies* — and copies drift, the exact
  thing Plumb prevents. So: **minimize copies.** Keep the universal core *in the plugin* (referenced),
  scaffold only the genuinely project-specific bits (the plumb line, the chosen adapter config).
- For unavoidable copies: each repo records `plumbVersion`; **`plumb upgrade`** re-syncs them to the latest
  templates and **`plumb doctor`** reports drift. (The gate-and-ritual pattern, applied to the framework.)
- **The origin project is the canary.** Every Plumb improvement is retrofitted to the first plumbed
  project first; if it can't keep that project evergreen, it isn't ready for the others.

---

## 9. Vocabulary

| Term | Meaning |
|---|---|
| **the plumb line** | the registry of single sources of truth (what's canonical where) |
| **the gates** | CI checks that verify the project is still true |
| **out of plumb** | drift a gate or ritual caught |
| **`/closeout`** | the ritual that re-trues the docs at end of session |
| **plumbing a repo** | running `plumb init` to stamp a project with the framework |
| **adapter** | a per-stack bundle of gates obeying the gate standard |

---

## 10. Scope & build order

### v1 (lean) — what makes a product fully plumb-able
- MANIFESTO + GATE-STANDARD + KB-STANDARD
- the doc-spine taxonomy + per-slot templates + authoring standard + a hand-maintained doc-map
- `/closeout` skill + SessionStart hook (generalized from the origin project)
- `plumb init`
- 1–2 adapters for the first products onboarded
- `plumbVersion` + `plumb doctor` (drift report)

### v2 (flagged, not built yet)
- Richer KB tooling: generated doc-map, link-graph, **coverage checks** ("what's missing")
- **Cross-product family KB**: one canonical source for design tokens / API contracts / version that
  feeds web + PWA + mobile, with a gate in each repo that fails if it drifts from the shared source
- `plumb upgrade` with 3-way merge
- A template repo as a greenfield complement to the plugin

### Build order
- **Phase 0** — extract + generalize the 3 universal artifacts from the origin project → plugin core + the three standards docs.
- **Phase 1** — `plumb init` scaffolds a fresh repo.
- **Phase 2** — the first 1–2 adapters (driven by which product is onboarded next).
- **Phase 3** — gate standard library, more adapters, `doctor`/`upgrade`, then v2.

---

## 11. Phase-0 extraction checklist (from the origin project)

Lift from the origin repo and **strip project-specifics → generalize**:

- [ ] `/closeout` skill (`.claude/skills/closeout/SKILL.md`) — remove domain-specific checklist items; keep the generic spine.
- [ ] SessionStart hook + `closeout-prime.txt` + the `.claude/settings.json` fragment.
- [ ] `CLAUDE.md` structure → a template: the lean "Current state = pointers" section, the reference index, the maintenance rules. (Strip project content; keep the shape.)
- [ ] Doc-spine templates: ADR, `project-state.md`, `changelog.md`, `roadmap/current.md` skeletons.
- [ ] The gate standard, distilled from the origin project's crawl + freshness audit behaviour (exit codes, ERROR/WARN severity, path filters, daily cron, escape hatch).
- [ ] `web-static` adapter v1 = generalized crawl + freshness scripts + the audit/freshness workflow templates (parameterize paths/project-specifics).
- [ ] Write `MANIFESTO.md` from §2; `KB-STANDARD.md` from §4; `GATE-STANDARD.md` from §5.2.

After Phase 0: **retrofit the origin project to consume Plumb** (replace its bespoke copies with the plugin), proving the propagation loop.

---

## 12. Open questions + draft recommendations

These are *leanings* to confirm or challenge with the owner, not locked decisions.

**a. Core filename: `CLAUDE.md` vs `AGENTS.md`?**
→ **Draft: `CLAUDE.md` as primary (Claude Code reads it natively), with the filename abstracted as an
`init` config so switching costs nothing.** Optionally generate a thin `AGENTS.md` pointer for cross-tool
portability later. Don't hardcode the name anywhere in the kit.

**b. How opinionated should `init` be about the plumb line?**
→ **Draft: infer, then confirm.** `init` scans the repo for likely canonical sources (package manifest,
token/config files, data files) and proposes a draft plumb line; the owner confirms/edits. Full-auto bakes
in wrong guesses; full-manual gets skipped. On a greenfield repo there's little to infer, so it asks a
couple of seed questions instead.

**c. Gates referenced (plugin) or scaffolded into each repo?**
→ **Draft: referenced, via an installable gate CLI.** Gate *logic* ships as a versioned package; CI runs
`npx @org/plumb-gates <gate>` against a thin repo-local **config** (paths/thresholds/which-gates) + a small
workflow file. This keeps gate logic single-sourced and propagating (fixes reach every repo on version
bump) while still working on CI runners that don't have the plugin. Only the config + workflow are scaffolded.

**d. Versioning / distribution?**
→ **Draft: private GitHub repo + git-based plugin install; gate CLI via a private package (GitHub Packages
or private npm).** Semver the framework; each plumbed repo pins `plumbVersion`. Avoid building a public
registry. Simplest viable path first.

**e. Minimum viable `doctor` (v1)?**
→ **Draft: read-only drift report covering** (1) repo `plumbVersion` vs latest; (2) the core-five doc-spine
files exist; (3) the SessionStart hook + `/closeout` skill are wired in settings; (4) the gate workflow(s)
exist and pin a current gate-CLI version; (5) the plumb-line registry in the core file is non-empty.
`doctor` only *reports*; fixing is `upgrade`'s job.
