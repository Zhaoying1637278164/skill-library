# Plumb — KB Standard

> Where knowledge lives, how it's organized, and how it's written. This is Layer A (the
> structure). The companion contract is [`GATE-STANDARD.md`](GATE-STANDARD.md) (Layer B,
> integrity); the "why" behind both is [`MANIFESTO.md`](MANIFESTO.md).

The KB Standard answers one question for a human or an agent: **"where does knowledge of
type X live?"** — so nobody has to guess, and no fact has two homes.

---

## 1. The doc spine (taxonomy) — tiered

A tiered spine avoids both failure modes: **empty ceremony** (too many mandated docs,
half of them stubs) and **no home for a fact** (too few, so facts scatter). Every
project gets the **core**; it grows into the **optional** slots only when it actually
has that kind of knowledge.

### Core (every project)

| Slot | Kind | Purpose | Canonical file |
|---|---|---|---|
| **The always-on core** | index | rules + pointers; agent/human bootstrap | `CLAUDE.md` (+ `AGENTS.md` pointer) |
| **Current state** | reference | live snapshot + inventory | `docs/project-state.md` |
| **History (past)** | temporal | session log, newest first | `docs/changelog.md` |
| **Backlog (future)** | temporal | prioritised next work | `docs/roadmap/current.md` |
| **Decisions** | explanation | *why* — tradeoffs made / rejected | `docs/decisions/NNN-*.md` |

### Optional (add when the project has this knowledge)

| Slot | Kind | Add when |
|---|---|---|
| **Architecture** | explanation / reference | the system is non-trivial (data flows, stack rationale) |
| **How-to / runbooks** | how-to | there are repeatable operational procedures |
| **Specs** | reference | features / tools are built to a written spec |

> **The mapping:** Diátaxis (explanation / how-to / reference / tutorial) **plus** a
> temporal axis (past / future) that Diátaxis lacks, **plus** the always-on core as the
> index. Product-facing tutorials, if any, are an optional slot — not part of the
> internal spine.

> **Note on rigour:** this taxonomy is a *reasoned hypothesis* (Diátaxis + the origin
> project's organic structure), **not** the output of formal research. The core five are
> the safe bet; the optional three are where to expect churn. Treat a varied portfolio of
> real projects (web, PWA, mobile, library, API) as the validation set — refine the slot
> definitions when a real project reveals a missing or redundant home.

Templates for every core slot live in [`templates/`](templates/). New projects start
from those, with empty slots — **no fake content**; a slot fills as the project earns
that knowledge.

---

## 2. The authoring standard (the voice rules)

These four rules are how the spine stays lean and drift-proof. They apply to every doc,
but most sharply to the always-on core.

1. **State the rule, point to the source.** Never re-enumerate data that has a canonical
   home. The core says *"design tokens are canonical in `tokens.css`; reference them,
   never hardcode"* — it does **not** list the token values. A pointer can't drift from
   its target; a copy always can.

2. **Keep the always-on core lean.** `CLAUDE.md` holds rules + pointers + the few stable
   bootstrap facts (what the project is, the hard constraints). Volatile state —
   counts, versions, inventory, status — is **referenced, not pinned**. The core should
   stop growing.

3. **Append vs update-in-place, by slot.**
   - The **changelog** appends (newest first); entries are never edited away.
   - **project-state** and **roadmap** update **in place** (they describe *now*, not
     history).
   - The core's "current state" is **pointers only**.

4. **No duplication.** Two copies of a fact = two things to keep in sync = guaranteed
   drift. If you find yourself writing a fact that already lives somewhere, link to it
   instead. If two docs genuinely need the same fact, one is canonical and the other
   points to it.
   *One sanctioned exception:* a **derived orientation artefact** (the solution
   blueprint, `docs/blueprint.html`) may restate facts — it is never canonical, carries
   an as-at date, and is kept true by closeout's blueprint axis. See
   [ADR-0002](docs/decisions/0002-blueprint-derived-artifact.md).

> These are not stylistic preferences — they are the structural half of the triage. Rule
> 1 and rule 4 are what let the integrity engine work: a gate can keep one source true,
> but it cannot chase a fact that has been copied into five places.

---

## 3. The doc-map

A single index — kept in the always-on core (a "References" table) and/or a
`docs/README.md` — answering *"where does knowledge of type X live?"* so a human or agent
never guesses.

- **v1 (now):** a hand-maintained index table. (See the `## References` section in
  [`templates/CLAUDE.md`](templates/CLAUDE.md).)
- **v2 (flagged):** generated + coverage-checked ("what slot has no home / what file is
  in no slot").

The doc-map should also name what is **deliberately not canonical** (archives, one-off
artifacts) so nobody resurrects a retired doc as a source of truth.

---

## 4. The plumb line (per-project single-source registry)

The **plumb line** is the project-specific list of *what is canonical where*: design
tokens → `tokens.css`; offices → `offices.json`; current state → `project-state.md`;
stack → `architecture/stack.md`; and so on. It is captured into the always-on core (a
"Maintenance / canonical homes" section) when a repo is plumbed, and it is the reference
that everything else is checked "true" against.

The plumb line is the **bridge between the two layers**: Layer A decides a fact has one
home; the plumb line records which home; Layer B's gates verify the repo still agrees
with that home.

---

## 5. Authoring conventions for each core slot

| Slot | Convention |
|---|---|
| **`CLAUDE.md`** | Rules + pointers + stable bootstrap facts. A `References` doc-map table. A `Maintenance` section listing canonical homes (the plumb line). No volatile counts. |
| **`AGENTS.md`** | A **thin pointer** to `CLAUDE.md` for cross-tool portability — never a second copy of its content. |
| **`project-state.md`** | The single home for the live snapshot + inventory. Updated in place. Narrative is allowed (inventory carries judgment, e.g. "absorbed the old services depth") — this is why it is not auto-generated. |
| **`changelog.md`** | Append newest-first. One entry per substantial session: what changed and *why*, with PR/ref pointers. |
| **`roadmap/current.md`** | The prioritised living backlog. Mark done / add / defer / drop **with the reason** — a removed item records *why* it was dropped, not just that it's gone. |
| **`decisions/NNN-*.md`** | One ADR per decision: context → decision → rationale → alternatives → consequences. A decision that reverses an earlier one says so and links it. |

---

## 6. How this gets stamped onto a repo

`plumb init` (Phase 1) scaffolds Layer A from [`templates/`](templates/): the always-on
core, the core doc spine, the per-slot templates; records the plumb line into the core;
and wires the ritual + hook. The plugin itself carries the universal parts (the
`/plumb-closeout` skill, the SessionStart hook) so they **propagate on update** rather than
being copied — see [`MANIFESTO.md`](MANIFESTO.md) §"What this means in practice" and the
self-application note in `SPEC.md` §8. Only the genuinely project-specific bits (the
plumb line, the chosen adapter config) are scaffolded as copies.
