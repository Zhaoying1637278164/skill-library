# ADR-0001 — SPEC §12 open-question resolutions

**Date:** 2026-06-05
**Status:** Accepted · decision **d** superseded by [ADR-0004](0004-public-release-distribution.md) (public npm + public repo, 2026-08-08)
**Decider:** Pukar Adhikari (confirmed in session)
**Related:** [`SPEC.md`](../../SPEC.md) §12, §6, §7, §8

## Context

`SPEC.md` §12 listed five open questions, each with a draft recommendation, to confirm
before building the affected pieces. Phase 0 depends on three of them (core filename,
gate delivery, distribution); the other two govern later phases. These were put to the
owner at the start of Phase 0.

## Decision

| # | Question | Resolution |
|---|---|---|
| **a** | Core filename: `CLAUDE.md` vs `AGENTS.md`? | **Generate both.** `CLAUDE.md` is canonical (native Claude Code pickup); `AGENTS.md` is a **thin pointer** to it, never a content copy (preserves the no-duplication rule). The filename stays abstracted as an `init` config var. |
| **b** | How opinionated should `init` be about the plumb line? | **Infer, then confirm** (accepted draft). `init` scans for likely canonical sources and proposes a draft plumb line; the owner confirms/edits. Greenfield repos get seed questions instead. *(Phase 1 — revisable then.)* |
| **c** | Gates referenced or scaffolded? | **Referenced via a versioned gate CLI.** Gate logic ships as `@plumb/gates` (versioned package); CI runs `npx @plumb/gates <gate>` against a thin repo-local config + workflow. Only config + workflow are scaffolded; fixes propagate on version bump. |
| **d** | Versioning / distribution? | **Private GitHub + git-based plugin install**, gate CLI via a private package (GitHub Packages or private npm). Semver the framework; each repo pins `plumbVersion`. No public registry. |
| **e** | Minimum viable `doctor` (v1)? | **Read-only drift report** (accepted draft): plumbVersion vs latest; core-five spine files exist; hook + `/closeout` wired; gate workflow(s) exist and pin a current gate-CLI version; plumb-line registry non-empty. `doctor` only reports; fixing is `upgrade`'s job. *(Phase 3.)* |

## Rationale

- **(a) Both, with `AGENTS.md` as a pointer** gives cross-tool portability without
  creating a second copy that would drift — the duplication the framework exists to
  prevent. The cost over "CLAUDE.md only" is one trivial pointer file.
- **(c) Versioned CLI** is the single-source principle applied to the gates themselves:
  scaffolded scripts are copies, and copies drift. The trade is building/publishing a
  package, accepted as worth it.
- **(d) Private + simplest viable path** avoids standing up a public registry before
  there's a second consumer; semver + pinned `plumbVersion` gives controlled propagation.

## Consequences

- Phase 0 ships: a `CLAUDE.md` template **and** an `AGENTS.md` pointer template; the gate
  logic as the `@plumb/gates` CLI seed with config + workflow templates that invoke it;
  plugin packaging for private git-based install.
- `@plumb/gates` package scope and the marketplace/repo URL carry `{{OWNER}}`/`@plumb`
  **placeholders** until the GitHub org + private registry are chosen — to be filled when
  the remote is supplied. Tracked in [`../roadmap/current.md`](../roadmap/current.md).
- `init` (b) and `doctor` (e) are accepted as drafts for Phases 1 and 3 and may be
  revisited when built.
