# ADR-0004 — Public release distribution (supersedes ADR-0001 decision d)

**Date:** 2026-08-08
**Status:** Accepted
**Decider:** Pukar Adhikari (confirmed in session)
**Related:** [ADR-0001](0001-spec12-resolutions.md) (decision d, superseded) · [ADR-0003](0003-positioning-audit-first.md) · `docs/roadmap/current.md` items 5, 18

## Context

ADR-0001 decision d chose "private GitHub + git-based plugin install, gate CLI via a
private package, no public registry" — right for a personal framework in June. The
public release (positioning locked in ADR-0003, content blockers closed) reverses every
part of that: the repo goes public, the plugin distributes through the Claude Code
plugin marketplace, and a private gates registry would now be pure friction. Two facts
enable the reversal: the Claude Code installer bugs that forced user-level symlink
delivery are fixed in current CC, and MIT licensing (release item 17) removed the reason
to keep the package private. One fact constrains it: the private repo's git history and
PRs contain pre-scrub client content and can never be made public.

## Decision

1. **Gate CLI → public npm** as `@pukaradhikari/plumb-gates`, version 1.0.0, MIT,
   `LICENSE` in the package. Workflow templates pin `^1.0.0`.
2. **Public repo is born fresh:** the private repo is renamed to `plumb-archive` (kept
   private, full history and PRs preserved); a new public `pukaradhikari/plumb` starts
   from a single squashed commit of the clean tip. Published URLs stay valid.
3. **Plugin releases at 1.0.0 explicit semver** (updates reach users on version bump,
   not on every commit), self-hosted marketplace at the repo root (`source: "."`), with
   submission to the `anthropics/claude-plugins-community` marketplace after validation.

## Rationale

Publishing the gates keeps ADR-0001c intact (versioned delivery; copies drift). The
fresh-repo path is forced, not stylistic: GitHub retains PR diffs, issue content, and
dangling commits, so flipping the existing repo public would leak pre-scrub client
content even after a history rewrite. Explicit semver fits a published plugin whose
users should get deliberate releases, not every commit.

## Alternatives considered

| Option | Reason rejected |
|---|---|
| Vendor the gates into each repo | Reverses ADR-0001c; gate copies drift — the failure the framework exists to prevent. |
| Rewrite history in place, flip the repo public | PR diffs and issues still expose pre-scrub content; unsafe regardless of rewrite. |
| Commit-SHA plugin versioning | Ships every commit to every user; wrong cadence for a public 1.0. |

## Consequences

- ADR-0001 decision d carries a superseded banner pointing here.
- Roadmap items 2 and 18 close together (they were the same task); item 5 closes once
  the native install is verified on current Claude Code.
- The archive remote holds pre-release history; the public repo's changelog starts with
  the condensed pre-release entry that already exists.
