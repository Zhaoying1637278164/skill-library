# ADR-0002 — The solution blueprint: a sanctioned exception to the no-duplication rule

**Date:** 2026-07-09
**Status:** Accepted
**Decider:** Pukar Adhikari (confirmed in session)
**Related:** [`KB-STANDARD.md`](../../KB-STANDARD.md) §2 rule 4 · [`skills/blueprint/SKILL.md`](../../skills/blueprint/SKILL.md) · [`skills/closeout/SKILL.md`](../../skills/closeout/SKILL.md) axis 7

## Context

KB-STANDARD rule 4 forbids duplication: two copies of a fact are two things to keep in
sync, which is one guaranteed drift. But field use surfaced a real need no pointer can
serve — a **handover / orientation artefact**: one self-contained page a newcomer (or a
stakeholder who will never read the spine) can absorb top to bottom, covering business
context, architecture, roles/permissions, data model, workflows, and honest status. By
construction such a page *restates* facts that have canonical homes. The question: does
shipping a blueprint skill violate the framework's own core rule?

## Decision

Ship `/plumb-blueprint` (`skills/blueprint/SKILL.md`) producing `docs/blueprint.html` as
a **deliberately derived artefact** — the one sanctioned exception to rule 4. Its drift
is not forbidden but **routed**, per the manifesto's triage:

- it is **never canonical** — it states and points, and must not elaborate beyond its
  sources;
- it carries an **as-at date** in its footer — the refresh contract, and the honest
  staleness signal when it isn't refreshed;
- **closeout gains an eighth axis** (blueprint, item 7; PR hygiene becomes 8) that asks
  once per session whether anything blueprint-visible changed, and invokes the skill's
  cheap **refresh mode** (diff pass, affected sections only) when it did.

## Rationale

An orientation layer has value a pointer cannot deliver: the spine answers "where does
fact X live?"; the blueprint answers "what *is* this thing?" for someone who doesn't yet
know which questions to ask. The duplication cost is real but bounded — the blueprint is
one file, dated, watched by a ritual, and honest about abbreviation (captions name what
was simplified). This is the same move the manifesto makes everywhere: don't rely on
remembering to keep the copy true; attach a mechanism.

## Alternatives considered

| Option | Reason rejected |
|---|---|
| No blueprint (rule 4 absolute) | Field demand is real; without a sanctioned form, ad-hoc overview docs appear anyway — undated, unwatched, and canonical-by-accident. |
| Blueprint as a canonical doc | Inverts the spine — the overview would compete with the sources it condenses. |
| Fully generated from sources | v2-class tooling (see roadmap); generation without judgement produces spaghetti ERDs and marketing matrices. Revisit when the KB tooling phase lands. |

## Consequences

- KB-STANDARD rule 4 gains a one-line exception note pointing here.
- Closeout is an eight-axis ritual; its axis-count prose updated.
- The blueprint's as-at date is ritual-watched only for now. A future `freshness` gate
  extension (reading the date out of `blueprint.html`'s footer, not just JSON) would add
  mechanical calendar-drift detection — recorded on the roadmap, not built.
- Every blueprint must be added to its repo's doc-map and plumb line at creation, marked
  as derived/not-canonical, so the audit skill and future readers treat it correctly.
