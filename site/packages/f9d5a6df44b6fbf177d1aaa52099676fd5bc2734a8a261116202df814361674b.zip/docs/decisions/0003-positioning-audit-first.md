# ADR-0003 — Positioning: audit-first, à la carte, niche named

**Date:** 2026-07-09
**Status:** Accepted
**Decider:** Pukar Adhikari (confirmed in session, after a competitive scan)
**Related:** [`../roadmap/current.md`](../roadmap/current.md) items 24–26 · `README.md`

## Context

Before the public push, the owner asked the honest question: does the market already
solve this? A four-sweep competitive scan (2026-07-09) found an active adjacent space:
code→docs sync SaaS (Falconer, DeepDocs, Doc Holiday, Swimm, Mintlify), free per-PR
drift checkers (doc-drift; CAI Drift Check, itself a Claude Code skill), session-handoff
skills, and memory/persistence ecosystems. Every one of them is single-direction (code
changed → fix the docs) or persistence-only (write more context down). None found does:

1. **Conversation→docs capture** — decisions and conventions that produced *no diff*
   (closeout's territory; PR-scoped tools are structurally blind to it), or
2. **Claim-level docs→code audit** with direction tagging and confirm-before-correct
   (nearest competitors work from diffs and git-churn heuristics, not claims).

Meanwhile Plumb's spine/templates are commodity — many CLAUDE.md template packs exist.

## Decision

Position Plumb **audit-first and à la carte**, not as "a doc framework with skills
attached":

- The README leads with the manifesto (recall under load, the 74/73/75 story, the
  four-move triage) and the **audit as the zero-cost entry point** — runnable on any
  repo with docs, plumbed or not. The spine is what a repo graduates to.
- The **drift score** (claims checked / clean / drifting, by direction) is the standard,
  shareable output of every audit.
- The **niche is named, and so is the non-audience**: for repos where docs are
  load-bearing AI context; not for product-documentation teams (Swimm/Mintlify serve
  those), and Claude Code-only today.

## Rationale

The demo that converts is watching your own repo lie to you: one audit, one drift table
with receipts. Framework adoption is a cliff; a single skill run is a step. And the
durable differentiator is the *idea* (the triage), which can't be copied by shipping a
feature — Diátaxis won as an idea. Naming the non-audience costs nothing and buys trust.

## Alternatives considered

| Option | Reason rejected |
|---|---|
| Lead with the spine/templates | Looks like the thirteenth CLAUDE.md template pack; the commodity part, not the differentiated part. |
| Compete with code→docs SaaS on their ground | Wrong battlefield: they own product-docs sync; Plumb's edge is the two directions they can't see. |
| Don't publish (space too crowded) | The crowd validates the problem; the two unique operations found no equivalent in the scan. |

## Consequences

- README rewritten to this positioning (2026-07-09), in plain English per the owner's
  writing rules.
- Three feature items follow from it (roadmap 24–26): a headless CI audit mode, explicit
  standalone-audit support with the standard drift-score line, and memory-bank/HANDOFF
  layout recognition in init's discovery (a migration path from the most popular free
  patterns, not a fight with them).
- The competitive claims above are as-at 2026-07-09; re-verify before making them in
  marketing copy later.
