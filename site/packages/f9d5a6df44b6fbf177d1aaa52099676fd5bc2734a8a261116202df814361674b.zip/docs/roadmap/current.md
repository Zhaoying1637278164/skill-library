# Roadmap — Plumb (current)

**[CONTINUOUSLY UPDATED — the living backlog]**
Last updated: 2026-08-08

> Prioritised next work, updated in place. History of what's done → [`changelog.md`](../changelog.md).

## Status legend
- 🔴 Blocked  ·  🟡 In progress  ·  🟢 Done  ·  ⬜ Not started

---

## Immediate (finish Phase 0 setup)

| # | Task | Status | Notes |
|---|------|--------|-------|
| 1 | Wire GitHub remote | 🟢 | Done 2026-06-05 — https://github.com/pukaradhikari/plumb (private); `{{OWNER}}` filled in plugin/marketplace/README; pushed `main`. |
| 2 | Finalize gates scope + registry | 🟢 | Resolved with item 18 (single task, was double-tracked): `@pukaradhikari/plumb-gates` on public npm, [ADR-0004](../decisions/0004-public-release-distribution.md). |
| 3 | Smoke-test the gate CLI | 🟢 | Done 2026-06-05 (see changelog "Repo created + Phase 0 done"): `crawl` + `freshness` run against a fixture — correct ERROR/WARN split and exit codes; both freshness modes work. *(Status corrected 2026-07-05 by `/plumb-audit` — was left ⬜.)* |
| 4 | Self-plumb: add a top-level `CLAUDE.md` | 🟢 | Done 2026-08-08 (release pass): `CLAUDE.md` + `AGENTS.md` instantiated from the templates; plumb line recorded. Completes the dogfood. |
| 5 | Proper global plugin install | 🟢 | Unblocked 2026-08-08: the CC 2.0.65 bugs are fixed in current Claude Code (verified in docs; the EINVAL bug still reproduces on a 2.0.65 machine, confirming it was version-bound, not layout-bound). Plugin validates clean; marketplace layout (`source: "./"`) correct. **Proven end-to-end 2026-08-08 on CC 2.1.226:** `marketplace add pukaradhikari/plumb` + `install plumb@plumb` succeed from the public repo; all four skills + hook present in the install; user-level symlinks retired. |

---

## Phase 0 wrap

| # | Task | Status | Notes |
|---|------|--------|-------|
| 14 | Retrofit the origin project to consume Plumb | 🟢 (ritual) | *(Renumbered from 5 — duplicate id, 2026-07-05.)* **Merged** (origin retrofit PR, 2026-06-05): local closeout skill+hook retired; ritual now delivered globally via the **user-level `/plumb-closeout` skill** (reconciled from the plugin path, which is blocked on CC 2.0.65) and propagates from this repo. Origin is the live canary (§8). **Remaining:** gates stay local until `@plumb/gates` is published (item 2 / decision C) — then swap the origin's `audit.yml`/`freshness.yml` to `npx @plumb/gates`. |

---

## Phase 1 — `plumb init`

| # | Task | Notes |
|---|------|-------|
| 6 | Build `plumb init` | 🟡 **Skill MVP shipped** (`skills/init/SKILL.md` → `/plumb-init`): Claude scaffolds/retrofits the current project — discovers the kit at runtime, scaffolds Layer A from `templates/`, infers-then-confirms the plumb line, wires gates where they fit (local via the `npm link`ed CLI; CI deferred until the package publishes), points at `/plumb-closeout`. Greenfield + retrofit paths. **Later:** a fuller deterministic/programmatic version. |
| 11 | `plumb init`: handle base-branch ≠ current-docs divergence | 🟢 Done 2026-06-05 (skill discovery now detects active-branch vs base, asks which holds truth, warns about lead + rebase). **Canary (second retrofit, 2026-06-05).** When the live doc content lives on a different branch than the chosen init base (latest docs on a feature branch; base is `main`), the skill silently assumes the base is current. Discovery should: detect the most-recently-active branch vs the base, surface "which branch holds current truth? sync those docs onto the init branch?" as an explicit confirmation, and **warn up front** about the two consequences — docs leading the base's code, and the feature branch needing a rebase after the init PR merges (spine files move under it). |
| 12 | `plumb init`: flag stale external memory pointers | 🟢 Done 2026-06-05 (skill scans memory locations in discovery; summary flags dangling pointers, never auto-edits memory). **Canary (second retrofit, 2026-06-05).** Retrofit moves/archives the very docs that out-of-repo Claude Code **auto-memory** points at (e.g. a project memory file saying "read `docs/ROADMAP.md` — source of truth"), leaving a dangling pointer that the doc-map and link checks can't see. Discovery should scan likely memory locations (`~/.claude/projects/<slug>/memory/*`, `CLAUDE.local.md`) for references to docs being moved/archived; the closing summary must flag them for repointing at `CLAUDE.md`/the spine. (Init must not edit user memory unprompted — flag + offer, don't auto-write.) |

---

## Skills (shipped from canary feedback)

| # | Task | Notes |
|---|------|-------|
| 13 | `/plumb-audit` — docs→code drift audit | 🟢 Shipped 2026-06-10 (`skills/audit/SKILL.md`, canary feature request from origin-project regular use). The inverse of closeout: walks the spine's checkable claims (open/done items, counts, status fields) against the codebase, drift table + confirm-then-correct, medium pass default, scan delegable to a subagent. Partially delivers the v2 "coverage checks" idea as a skill. **Distinct from Phase-3 `doctor`** — doctor = repo-vs-framework drift; audit = docs-vs-code drift. |
| 22 | `/plumb-blueprint` — solution blueprint + closeout's eighth axis | 🟢 Shipped 2026-07-09 (`skills/blueprint/SKILL.md`, [ADR-0002](../decisions/0002-blueprint-derived-artifact.md)) — see the changelog entry. |
| 23 | `freshness` gate: read the blueprint's as-at date | ⬜ Not started. The blueprint's footer date is functionally a `lastVerified`, but the gate only parses JSON. Extend it (regex the date from `blueprint.html`'s footer, or an HTML `mode`) so blueprint staleness gets **mechanical** calendar detection, not just the ritual. From ADR-0002 consequences. |

---

## Phase 2 — adapters (lazy, per onboarded product)

| # | Task | Notes |
|---|------|-------|
| 7 | Next adapter(s) | Driven by which product is onboarded next: `ts-lib`, `python-api`, `react-pwa`, `mobile-native` (native CI), `generic`. Each obeys `GATE-STANDARD.md`. **Concrete signal (second canary — an authed React 19/Vite/Supabase SPA):** `web-static`'s crawl/Lighthouse gates don't fit an authed SPA at all; the useful default gate set for a **react-pwa/SPA adapter** is `freshness` (regulatory/legal data) + an **RLS smoke test** + `tsc --noEmit`. Build this adapter when an SPA is onboarded. |
| 8 | Round out `web-static` | Add the deferred gates (a11y/axe, Lighthouse, build/typecheck) to the adapter. |

---

## Phase 3 — `doctor` / `upgrade`, then v2

| # | Task | Notes |
|---|------|-------|
| 9 | `plumb doctor` | Read-only drift report (ADR-0001 e): plumbVersion, core-five exist, hook+skill wired, gate workflow pins a current CLI version, plumb-line non-empty. |
| 10 | `plumb upgrade` | Re-sync scaffolded copies; 3-way merge (v2). |
| 15 | v2 KB tooling | *(Renumbered from 11 — duplicate id, 2026-07-05.)* Generated doc-map, link-graph, coverage checks; cross-product family KB (SPEC §10 v2). |

---

## Public release prep (from the 2026-07-05 release review)

> Surfaced by a full read-through for public open-sourcing. The four blockers gate release;
> the rest is polish. Internal doc drift was already fixed by the same-day self-audit.

| # | Task | Status | Notes |
|---|------|--------|-------|
| 16 | Scrub the client trail | 🟢 | Done 2026-07-09 — see the changelog entry "(b) Client-trail scrub + MIT license". **Residual:** the private repo's *git history* still contains pre-scrub content; the public repo must start from a fresh history at publish time. |
| 17 | Choose a license | 🟢 | Done 2026-07-09 — **MIT** (owner choice). `LICENSE` added; `plugin.json` + `gates/package.json` updated. |
| 18 | Publish the gate CLI | 🟢 | Done 2026-08-08 — `@pukaradhikari/plumb-gates@1.0.0` on public npm ([ADR-0004](../decisions/0004-public-release-distribution.md)); verified from a scratch repo (fresh → exit 0, overdue → exit 1). Workflows pin `^1.0.0`. |
| 19 | Fix `plumb init` kit discovery for installed users | 🟢 | Done 2026-07-09 — `${CLAUDE_PLUGIN_ROOT}` is now step (a) of discovery; symlink/cache/dev-dir checks are the fallbacks. See changelog entry (e). |
| 20 | Canonicalise skill command names + rewrite two descriptions | 🟢 | Done 2026-07-09 — canonical names are `/plumb-init`, `/plumb-closeout`, `/plumb-audit`, `/plumb-blueprint`, swept repo-wide (SPEC.md left frozen); init + closeout descriptions now fire on brand-free prompts. See changelog entry (e). |
| 21 | Portability + dead-weight sweep | 🟢 | Done 2026-07-09 — citations inlined, `spawn_task` generalised, memory paths hedged, OS framing neutralised, template link fixed, ground rules trimmed, "What Plumb does not do" added to the README, `permissions: contents: read` in both workflows. See changelog entry (e). |

---

## Positioning + launch (from the 2026-07-09 competitive scan, ADR-0003)

| # | Task | Status | Notes |
|---|------|--------|-------|
| 24 | Headless CI audit mode | ⬜ | A small GitHub Action wrapping `claude -p "/plumb-audit medium"` on a weekly cron; posts the drift table as an issue (or PR comment). Puts the differentiated operation on autopilot — the audit currently fires only when a human remembers, which is the failure mode the framework exists to kill. |
| 25 | Standalone audit + the drift score | ⬜ | Make explicit in `skills/audit/SKILL.md` that the audit runs on **any** repo with docs (unplumbed included — infer doc roles when no spine exists), and standardise the one-line result: "N claims · N clean · N drifting (N optimistic)". The shareable number is the demo. |
| 26 | init discovery: recognise memory-bank + HANDOFF layouts | ⬜ | Classification already maps by content; add explicit recognition of memory-bank patterns (`projectbrief.md`, `activeContext.md`, `progress.md`) and `HANDOFF.md` files → spine slots. A migration path from the most popular free patterns. |
