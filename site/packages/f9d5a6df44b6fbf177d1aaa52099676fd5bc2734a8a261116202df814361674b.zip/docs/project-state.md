# Project state — Plumb

> The single home for Plumb's live snapshot + inventory. Updated **in place**. History →
> [`changelog.md`](changelog.md) · Backlog → [`roadmap/current.md`](roadmap/current.md).

## Build snapshot

- **Stage:** released — **v1.0.0 public** (ADR-0004). Phase 1 remains a skill MVP
  (`skills/init/SKILL.md`); the programmatic CLI form is later work.
- **Repo:** https://github.com/pukaradhikari/plumb (public from v1.0.0), `main`.
  Pre-release history lives in the private `plumb-archive`.
- **Plugin:** v1.0.0, self-hosted marketplace at the repo root (`source: "."`); install
  via `/plugin marketplace add pukaradhikari/plumb` + `/plugin install plumb@plumb`.
  The CC 2.0.65 installer bugs that forced user-level symlink delivery are fixed.
- **Gate CLI:** `@pukaradhikari/plumb-gates` v1.0.0 on public npm (zero dependencies).

## Inventory — the kit

**Standards / the "why":**
- `MANIFESTO.md` — the principle + four-move triage table.
- `GATE-STANDARD.md` — the gate contract (severities, path filters, cron, escape hatch).
- `KB-STANDARD.md` — the tiered doc spine + authoring rules + the plumb line.

**Plugin parts (propagate on update — not scaffolded per repo):**
- `skills/closeout/SKILL.md` — the stack-agnostic end-of-session ritual.
- `skills/init/SKILL.md` — `plumb init` as a skill (scaffold/retrofit the current project).
- `skills/audit/SKILL.md` — docs→code drift audit (the inverse of closeout).
- `skills/blueprint/SKILL.md` — the solution blueprint: one-page handover pack, derived
  + as-at dated (the sanctioned rule-4 exception — ADR-0002).
- `hooks/hooks.json` + `hooks/closeout-prime.txt` — SessionStart prime.
- `.claude-plugin/plugin.json` + `.claude-plugin/marketplace.json` — packaging.

**Templates (scaffolded into a plumbed repo):**
- `templates/CLAUDE.md`, `templates/AGENTS.md` (pointer), `templates/settings.fragment.json`.
- `templates/docs/{project-state,changelog}.md`, `templates/docs/roadmap/current.md`,
  `templates/docs/decisions/000-template.md`.

**Gate CLI + adapter:**
- `gates/` — `bin/plumb-gates.mjs`, `lib/crawl.mjs`, `lib/data-freshness.mjs`,
  `package.json`, `README.md`.
- `adapters/web-static/` — `plumb.config.example.json`, `workflows/{audit,freshness}.yml`,
  `README.md`.

**Plumb's own KB spine (dogfood):**
- `CLAUDE.md` (always-on core, instantiated 2026-08-08 — the self-plumb) + `AGENTS.md`
  pointer.
- `WHY.md` — the owner's personal origin essay (2026-08-10), linked from the README;
  personal voice, deliberately separate from `MANIFESTO.md` (the framework's voice).
- `README.md`, `docs/changelog.md`, `docs/project-state.md`, `docs/roadmap/current.md`,
  `docs/decisions/` (ADR-0001 through ADR-0004). (Carried over from design: `SPEC.md`.
  The design-handoff `CONTEXT.md` was deleted in the 2026-07-09 release scrub.)
- `docs/blueprint.html` — the solution blueprint (derived orientation artifact, as-at
  2026-07-09; first field test of `/plumb-blueprint`, run on Plumb itself).

## Single-source data files (the plumb line)

| Kind of knowledge | Canonical home |
|---|---|
| The principle / triage | `MANIFESTO.md` |
| Gate contract | `GATE-STANDARD.md` |
| Doc-spine taxonomy + authoring rules | `KB-STANDARD.md` |
| Gate logic | `gates/` (`@pukaradhikari/plumb-gates`) |
| Locked design decisions | `docs/decisions/` |
| Live state / inventory | this file |
| Design spec (frozen design intent) | `SPEC.md` |
| Orientation overview (derived, **never canonical**, as-at dated) | `docs/blueprint.html` — watched by closeout's blueprint axis (ADR-0002) |

## Open placeholders (fill when known)

- None. (The gates scope resolved to `@pukaradhikari/plumb-gates`, ADR-0004. The
  `{{...}}` placeholders inside `templates/` and the adapter workflows are intentional —
  `init` fills them per plumbed project.)

## What is NOT yet built

- `plumb init` as a programmatic/deterministic CLI (the skill MVP exists); `upgrade` /
  `doctor` (Phase 3).
- Adapters beyond `web-static` (`ts-lib`, `python-api`, `react-pwa`, `mobile-native`,
  `generic`) — built lazily per onboarded product (Phase 2).
- Origin-project **gate** swap to `npx @pukaradhikari/plumb-gates` — unblocked by the
  publish (ADR-0004); do it on the next origin-project session. The ritual half of the
  retrofit is done (merged 2026-06-05).
