# Plumb — agent context

> **The canonical AI/agent context for this project is [`CLAUDE.md`](CLAUDE.md).**
>
> This file exists only as a cross-tool pointer. It is intentionally **not** a second
> copy of that content — two copies would drift (see the project's KB standard). Any tool
> that reads `AGENTS.md` should read `CLAUDE.md` for the rules, pointers, doc-map, and
> the plumb line (canonical homes).
