# Changelog

## [1.7.1] - 2026-09-09

### Fixed
- **Fuzzy and regex search were wrongly listed as unsupported.** Both work in
  full-text search, under `type: "query_string"` only: fuzzy as `term~N` (edit
  distance 0-2; a bare `~` picks a distance from term length) and regex as
  `field:/pattern/`, matched against analyzed tokens rather than raw field text.
  Under `type: "text"` the `~` and `/.../` characters are treated as literals.
  Both operators are now in the query-syntax table in the querying reference.
- **Bulk import from object storage was wrongly listed as unsupported.** Pinecone
  supports it for document-shaped indexes using JSON Lines files. This skill does
  not implement it; the skill now says so and points at `documents.upsert` /
  `documents.batch_upsert` for ingestion here.

The two remaining platform limitations are unchanged and still accurate: indexes
holding a `full_text_search` field cannot be created in CMEK-enabled projects,
and backup and restore are not yet supported.

## [1.7.0] - 2026-09-03

### Changed
- **Full-text search now requires `pinecone` Python SDK >= 10.0.0.** The document-schema
  API graduated out of `pinecone.preview` and is a first-class, SemVer-covered part of the
  SDK, reached directly off the client: `pc.indexes`, `pc.index(name)`. The wire API
  version is `2026-07`.
- `scripts/ingest.py` pins `pinecone==10.0.0` and calls `pc.index(name)` in place of
  `pc.preview.index(name)`.
- `--batch-size` on `scripts/ingest.py` now defaults to 50 rather than 100, with the
  large-vector guidance moved from 50 to 25. Fewer payload-size errors out of the box.

### Removed
- **`pinecone.preview` is deleted in SDK 10.0.0 — there is no shim.** Importing it raises
  `ModuleNotFoundError`. The skill keeps migration notes for anyone carrying code over
  from the preview API, including the traps that changed shape rather than disappearing.

### Added
- **Per-field updates.** `documents.update(...)` replaces the fetch, modify, re-upsert
  workaround the preview API forced.
- **Namespace management.** Create, describe, list, and delete namespaces through the API.
  The preview API could write to a namespace but not manage one.
- **`documents.list(...)`** enumerates document IDs in a namespace, lazily paginated,
  sorted by `_id`, optionally filtered by `prefix`.

### Fixed
- **Filterable metadata does not belong in the schema.** On a managed index the server
  rejects any schema-declared filterable field with a `400` — string, string list, float,
  and boolean alike. Put those fields on upserted documents instead, where they
  auto-index for filtering with nothing to configure.
- **A hybrid index must declare its `sparse_vector` field at create time.** `metric="dotproduct"`
  on the dense field is no longer a hybrid declaration by itself. The create call succeeds
  either way, but without a declared `sparse_vector` field the sparse writes are refused
  later, often from a different part of the codebase. Schemas are immutable, so fixing it
  means creating a new index.

## [1.6.0] - 2026-08-11

### Added
- **Three missing assistant reference files.** `references/context.md`, `references/list.md`, and `references/sync.md`. The `context`, `list`, and `sync` operations were listed in the assistant skill but had no reference documentation, so the agent had nothing to read before running them.
- The n8n skill now states how to invoke it: `/pinecone:n8n`.

### Fixed
- **Full-text search: `add_integer_field()` does not exist.** The FTS skill named it in eight places across `SKILL.md`, `references/schema-design.md`, and `references/onboarding-walkthrough.md`. Calling it raises `AttributeError`, so an agent following the documented schema-design path failed before it could create an index. Use `add_float_field()` — `float` is the only numeric wire type.
- **`add_boolean_field()` does exist.** The docs said it didn't and recommended an `add_custom_field("name", {"type": "boolean", ...})` workaround.
- **`include_fields` default was wrong.** Omitting it does not return `_id` + `_score` only. The key is left off the request and the server returns every stored field.

### Changed
- API key guidance now covers `.env` files alongside shell export, in the help, query, quickstart, and assistant skills.
- Skills state once, up front, that `AskUserQuestion` is the way to offer choices, instead of naming it at each individual step.
- `source_tag` operation names changed on two quickstart scripts: `quickstart_complete` → `index_quickstart`, and `quickstart_upsert` → `upsert`. If you filter analytics on those exact strings, update them.
- `chat.py` and `ingest.py` are no longer marked executable. Both are invoked with `uv run`, so this does not affect how they are used.

### Note for contributors
Everything under `skills/` is now generated from [pinecone-io/skills](https://github.com/pinecone-io/skills) and arrives by pull request. Edits made directly here are overwritten by the next sync — send changes to the source repository instead.

## [1.5.1] - 2026-08-05
### Fixed
- **Pinecone SDK 9.1.0 compatibility.** The bundled scripts pinned `pinecone>=8.0.0`, which now resolves to 9.1.0 — where the assistant API moved and the data plane became keyword-only. Five of nine scripts were broken; `chat.py` failed at import.
  - Assistant: `chat.py` imports the chat `Message` type from its new location; `chat`, `context`, `upload`, `sync`, and `list` use the current assistant API (`pc.assistant.Assistant(...)` was removed in v9); `context.py` reports the real snippet type instead of always `"text"`.
  - Quickstart: `upsert_records` arguments are passed by keyword as v9 requires, and search results read `id` / `score` to match the current response fields.
- **`list` display.** Assistant and file status values are colour-coded again — the API returns `Ready` / `Available` and the comparison was lowercase. Removed the `Region` column, which always showed `unknown` because the API does not return a region on that response.

### Changed
- All scripts pin `pinecone==9.1.0` and declare `requires-python = ">=3.10"`. The previous floating pin is why these broke with no change in this repo.

## [1.5.0] - 2026-07-08
### Added
- **SessionStart auth-check hook**: On session start (and resume), the plugin checks your Pinecone setup and guides you through authentication if anything is missing.
  - Checks whether `PINECONE_API_KEY` is present and whether the Pinecone CLI (`pc`) is installed. 
  - Shows a friendly one-line status via `systemMessage`; hands Claude detailed next steps via `additionalContext`, including verifying the key is actually live via the MCP `list-indexes` tool on first Pinecone use, and pointing you at the `pinecone:quickstart` and `pinecone:cli` skills.
  - Stays quiet-but-visible when healthy; only prompts guidance when action is needed.
  - Silence it anytime with `export PINECONE_SKIP_AUTH_CHECK=1` (survives plugin updates).

## [1.4.1] - 2026-06-06
- Version bump and plugin metadata/keyword updates.

## [1.4.0] - 2026-06-06
- **New skill — full-text-search (FTS)**: end-to-end workflow for Pinecone's full-text-search preview API (`2026-01.alpha`) — document schema design, safe bulk ingestion, and `documents.search(...)` query construction (BM25 `text`/`query_string`, `dense_vector`/`sparse_vector` scoring, and `$match_phrase`/`$match_all`/`$match_any` text-match filters).
- Updates across the rest of the plugin to accompany the new skill.

## [1.3.0] - 2026-03-06
- source tag fixes

## [1.2.0] - 2026-03-04
- contextualize: adapt synced skills for this plugin
- refactor: consolidate skills, remove redundant commands, add cli/mcp/…
- contextualize: adapt synced skills for this plugin
- fix: repair broken triple-quoted strings in assistant scripts
- fix: quickstart prereq uses MCP list-indexes instead of echo, add mis…
- refactor: rename skill directories to remove pinecone- prefix
- fix: improve release and contextualize workflows
- fix: generate changelog from commit messages instead of PR body
## [1.1.2] - 2026-01-27
### Fixed

More issues with script path resolution
- explictly added invocation of assistant skill before subcommands
- explictly added permissions for skill usage
- passes internal testing


## [1.1.1] - 2026-01-26

### Fixed
- **Script Path Resolution**: Fixed script paths to use correct relative paths for marketplace installation
  - SKILL.md now uses `scripts/` (relative to skill directory)
  - Commands now use `skills/assistant/scripts/` (relative to plugin root)
  - Added documentation note explaining path structure
  - Scripts now properly accessible when plugin is installed from marketplace

## [1.1.0] - 2026-01-26

### Added

#### Pinecone Assistant Integration
- **New Skill**: Full Pinecone Assistant skill with natural language support for creating, managing, and chatting with document-based Q&A assistants
- **Natural Language Mode**: Proactive recognition of assistant-related requests without requiring slash commands
- **Conversation Memory**: Tracks last assistant used for seamless multi-turn interactions

#### New Commands
- **`/pinecone:assistant-create`** - Create new Pinecone Assistants with custom configuration, instructions, and regional deployment
- **`/pinecone:assistant-upload`** - Upload files or entire directories to assistants for document Q&A
- **`/pinecone:assistant-sync`** - Sync local files with assistants (only uploads new/changed files, with optional deletion of missing files)
- **`/pinecone:assistant-chat`** - Chat with assistants and receive cited responses with source references
- **`/pinecone:assistant-context`** - Retrieve relevant context snippets without generating full chat responses
- **`/pinecone:assistant-list`** - List all assistants in your account with status and configuration details
- **`/pinecone:join-discord`** - Opens link to join the Pinecone Discord community for help, support, and connecting with the Pinecone team


#### Python Scripts
- `skills/assistant/scripts/create.py` - Assistant creation script
- `skills/assistant/scripts/upload.py` - File upload script
- `skills/assistant/scripts/sync.py` - Incremental sync script
- `skills/assistant/scripts/chat.py` - Interactive chat script with citations
- `skills/assistant/scripts/context.py` - Context retrieval script
- `skills/assistant/scripts/list.py` - List assistants script

## [1.0.0] - 2026-01-06

### Added

#### Core Plugin Features
- **Pinecone MCP Server Integration**: Full integration with the Pinecone Model Context Protocol server for seamless vector database operations
- **Slash Commands**: Quick access to common Pinecone operations directly from Claude Code
- **Semantic Search**: Query vector indexes using natural language

#### Available Commands
- **`/pinecone:help`** - Display help information, API key configuration instructions, and troubleshooting tips
- **`/pinecone:quickstart`** - Interactive quickstart tutorial that:
  - Downloads and generates an AGENTS.md file optimized for Claude Code
  - Walks through Python quickstart tutorial
  - Guides through first index creation and semantic search setup
- **`/pinecone:query`** - Query Pinecone indexes using natural language with support for:
  - Index and namespace selection
  - Optional reranking models for improved relevance
  - Interactive guidance for missing parameters
  - Only works with integrated indexes using Pinecone hosted embedding models

#### MCP Server Tools
- **`list-indexes`** - List all available Pinecone indexes
- **`describe-index`** - Get index configuration and namespaces
- **`describe-index-stats`** - Get statistics including record counts and namespaces
- **`search-records`** - Search records with optional metadata filtering and reranking
- **`create-index-for-model`** - Create new indexes with integrated embeddings
- **`upsert-records`** - Insert or update records in an index
- **`rerank-documents`** - Rerank documents using specified reranking models
- **`search-docs`** - Search Pinecone documentation for relevant information

**Note**: For installation instructions and detailed usage, see [README.md](./README.md)
