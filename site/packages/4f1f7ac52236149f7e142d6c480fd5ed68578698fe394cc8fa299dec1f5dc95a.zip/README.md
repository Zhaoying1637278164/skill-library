<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/assets/goodfellow-hero-dark.svg">
    <img src="docs/assets/goodfellow-hero-light.svg" alt="Goodfellow — your good fellow for shipping code" width="880">
  </picture>
</p>

<p align="center">
  <a href="LICENSE"><img alt="License: MIT" src="https://img.shields.io/badge/license-MIT-475569?style=flat-square"></a>
  <a href="https://github.com/easelyte/goodfellow/actions/workflows/ci.yml"><img alt="CI" src="https://img.shields.io/github/actions/workflow/status/easelyte/goodfellow/ci.yml?branch=main&style=flat-square&label=CI"></a>
  <img alt="Python 3.10+" src="https://img.shields.io/badge/python-3.10%2B-475569?style=flat-square&logo=python&logoColor=white">
  <img alt="Claude Code plugin" src="https://img.shields.io/badge/Claude_Code-plugin-7c3aed?style=flat-square">
  <img alt="Version 0.2.0" src="https://img.shields.io/badge/version-0.2.0-7c3aed?style=flat-square">
</p>

An opinionated development lifecycle for Claude Code.
Your system gets smarter every time you ship.

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/assets/goodfellow-pipeline-dark.svg">
    <img src="docs/assets/goodfellow-pipeline-light.svg" alt="Goodfellow lifecycle: Brainstorm to Spec (spec-review + research) to Plan (plan-review + research) to Execute (verify) to Ship (review · PR + merge), with a feedback loop where Ship writes to a knowledge store and Brainstorm reads from it — your system gets smarter every cycle" width="960">
  </picture>
</p>

Adversarial review at every stage. Knowledge that compounds. Nothing that slips.

## Why Goodfellow?

Every chain run extracts what you learned and feeds it into the next one.
Safety-critical and major deferred findings become tracked loops — triaged, not forgotten.
Polish-tier (minor) findings go to your knowledge file as gotchas.
Your 50th feature ships with the wisdom of the first 49.

**What's different:**
- **Multi-model adversarial review** — Claude + Codex/GPT reviewers catch what single-model review misses
- **Research injection** — factual claims in review findings are verified via web search before acting on them
- **Verifier pass** — before fixing a round 2+ finding, checks if it's still real. Prevents infinite fix-find-fix loops
- **Knowledge compounding** — `.goodfellow/knowledge.md` accumulates principles, patterns, and gotchas across chain runs
- **Seeded principles out of the box** — ships with curated, battle-tested universal design principles so a fresh install starts smart, not empty (see Memory backends below)
- **Pluggable memory** — keep the zero-config flat knowledge file, or opt into a rich per-fact backend with a regenerated index and crash-safe migration
- **Follow-up tracking** — safety-critical and major deferred findings become loops in `.goodfellow/loops.json`, triaged with a two-reviewer system; polish-tier (minor) goes to knowledge gotchas

## Install

Goodfellow ships its own single-repo marketplace manifest (`.claude-plugin/marketplace.json`) at the repo root, so it installs **directly from this public GitHub repo**. This works today and does not depend on the Anthropic plugin directory — no directory listing is required for any of the commands below.

**Inside Claude Code (recommended):**
```text
/plugin marketplace add easelyte/goodfellow
/plugin install goodfellow@goodfellow
/reload-plugins
```
`/plugin install goodfellow@goodfellow` reads `plugin@marketplace` — both are named `goodfellow` here (the plugin lives at the marketplace repo root, `source: "./"`).

**One command** (Claude Code v2.1.275+):
```text
/plugin install goodfellow --marketplace easelyte/goodfellow
```

**From your shell** (non-interactive / scripting):
```bash
claude plugin marketplace add easelyte/goodfellow
claude plugin install goodfellow@goodfellow
```

**Session-only** (for testing, no persistent install):
```bash
claude --plugin-dir /path/to/goodfellow
```
This loads the plugin for the current session only from a local checkout — nothing is registered or persisted.

> **The Anthropic directory is optional — for discovery, not for installing.** `/plugin marketplace add easelyte/goodfellow` clones this repo and reads the manifest straight from GitHub; it never touches Anthropic's plugin directory. Being listed in [`claude-plugins-community`](https://github.com/anthropics/claude-plugins-community) only adds discoverability (browsing `/plugin` → **Discover**). Once that listing lands you can also `/plugin install goodfellow@claude-community`, but the direct-from-repo commands above always work and track `main` on every marketplace refresh — no commit-pin, no nightly-sync lag.

## Quick Start

```bash
# 1. Start a design
/goodfellow:brainstorm "Add user authentication with OAuth"

# 2. Each skill auto-dispatches the next:
#    brainstorm -> spec-review -> plan -> plan-review -> execute -> ship
#    Rounds 1-3 are gateless; round 4+ asks once. Knowledge compounds across runs.

# 3. Check what accumulated
cat .goodfellow/knowledge.md

# 4. Close the session cleanly
/goodfellow:close
```

## The Knowledge Loop

Every skill in the chain participates in a read-extract-persist cycle:

| Skill | Reads | Writes |
|---|---|---|
| brainstorm | All sections (Principles, Patterns, Gotchas) + seeded principles | — |
| spec-review / plan-review | Principles + Gotchas + seeded principles (flags violations by `P-NNN`) | — |
| plan | Principles + seeded principles (per-task principles pass) | — |
| execute | Gotchas + seeded principles (catches footguns at code-writing stage) | — |
| ship | — | New entries with `[pending]` tag |
| snap-compact | — | Extracts learnings before context loss |
| close | — | Promotes `[pending]` to confirmed |

**Seeded universal principles.** Goodfellow ships with a curated set of battle-tested, stack-agnostic design principles (`knowledge/principles.md`) so a fresh install starts with accumulated wisdom rather than an empty knowledge file. These are plugin-owned and read-only (updated via plugin update, never clobbering your `.goodfellow/knowledge.md`). A web supplement (`knowledge/principles-web.md`, JS/React/Next.js/Postgres/RLS rules) is read only when web context is opted in — see `GOODFELLOW_PRINCIPLES_WEB` below, or auto-detected by a `package.json` at the project root.

The chain skills load the principles by **progressive disclosure**, the same way Agent Skills load: every run injects only the lightweight *index* (each principle's `P-NNN` id, title, and one-line rule), and the model pulls a principle's full body on demand once it decides the principle is relevant. This keeps the always-loaded footprint small (~2.8k tokens for the whole core set, vs ~17k for the full bodies) so a growing corpus never crowds out the task — see [`docs/instruction-density-budget.md`](docs/instruction-density-budget.md) for the measured budget and the "growth is displacement, not accumulation" rule enforced in CI. Violations are still cited by stable `P-NNN` id.

The knowledge file (`.goodfellow/knowledge.md`) is append-only by default, human-curated, and intentionally unbounded. Entries follow a lightweight convention:

```markdown
## Principles
- 2026-06-02: Always validate at the boundary, never trust upstream sanitization

## Patterns
- 2026-06-02: Convergence-based review termination — stop when severity drops, not when count hits zero

## Gotchas
- [pending] 2026-06-02: The Codex CLI has no --file flag — use codex exec review with --commit/--base/--uncommitted
```

## Memory Backends

Goodfellow's accumulated knowledge has two backends, selected by `GOODFELLOW_MEMORY` (the seeded principles above are read in both):

- **`flat` (default, zero-config).** The single append-only `.goodfellow/knowledge.md` shown above. Human-curated, unbounded, dead simple. Nothing to set up.
- **`rich` (opt-in: `GOODFELLOW_MEMORY=rich`).** One file per fact under `.goodfellow/memory/*.md` (typed frontmatter), a regenerated index `.goodfellow/MEMORY.md`, and per-domain registries. Built for scale: writes are atomic + file-locked + transactional, the first rich write **auto-migrates** an existing `knowledge.md` (crash-resumable, non-destructive), and chain skills read the index with an ordered fallback so recall never silently degrades.

Switching is safe and reversible — `flat` is never modified, and the rich path is entirely additive. Most users never need `rich`; reach for it when your knowledge file grows large enough that a single flat file becomes unwieldy. Tuning: `GOODFELLOW_MEMORY_WARN_KB` (advisory index-size warning). All three memory env vars fail loud on invalid values.

## Follow-Up Tracking

At ship time, deferred review findings are routed by their severity tier
(`blocker` > `major` > `minor`):
- **Safety-critical / blocker (security/data-loss/correctness):** blocks PR creation. Must be fixed or explicitly waived by the operator — filing as a loop is not sufficient, so a blocker is resolved at ship time rather than deferred.
- **Major:** does **not** block the PR, but is filed as a loop in `.goodfellow/loops.json` for follow-up. Substantive work, never dropped and never downgraded to a gotcha.
- **Polish-tier / minor:** added to the knowledge file as gotchas (not filed as loops).

Spec-review and plan-review don't file loops — their unresolved findings carry forward to the next chain stage.

```bash
# File a follow-up manually
/goodfellow:ship  # (blocks on safety-critical, files non-blocking as loops)

# List open loops (inside Claude Code — CLAUDE_PLUGIN_ROOT is set automatically)
python3 "${CLAUDE_PLUGIN_ROOT}/scripts/loop_store.py" list

# Seed a brainstorm from a loop
/goodfellow:brainstorm --from-loop 3

# Triage accumulated loops
/goodfellow:triage
```

**Priority scale:** p1 = critical, p2 = high, p3 = medium (default), p4 = low (round 4+ findings).

**Anti-whack-a-mole design:**
- Blocker (safety-critical) and major findings become loops; polish-tier (minor) goes to knowledge gotchas
- Round 4+ findings file at lowest priority (except safety-critical)
- Soft cap warning at 15 active loops
- Triage has a 3-cycle hard cap on "still unclear" — forces a decision

## Autopilot Mode

```bash
# Full auto — chain runs hands-off with strategic halts
GOODFELLOW_AUTOPILOT=1

# Dry run first — logs decisions without mutating project code
# (the decision log itself IS written to .goodfellow/runs/ — that's the audit trail)
GOODFELLOW_AUTOPILOT=dry-run
```

**Strategic halts** — the chain stops itself rather than guessing:
- Parent self-review (spec-review/plan-review step 0.5) hits a finding that needs an operator decision

**Planned** (not yet wired into the chain):
- `confidence: low` in spec frontmatter (architecture-changing unknowns)
- Verifier flags >50% of findings as stale/noise in a round
- Unresolved questions that would change the architecture

Decision log written to `.goodfellow/runs/<timestamp>-<pid>.jsonl` for auditability.

## Triage

When loops accumulate, `/goodfellow:triage` helps separate real defects from noise:

1. Two independent reviewers assess each loop (Claude + Codex when available, single Claude otherwise)
2. Reconciliation: both agree (high confidence), one opinion + one unclear (medium), disagree (low)
3. Operator confirms/overrides in a batch table
4. Decisions logged to `.goodfellow/triage-log.jsonl` for calibration

## Skills Reference

### The Chain (7 skills)

| Skill | Invocation | Codex? | Autopilot? |
|---|---|---|---|
| brainstorm | `/goodfellow:brainstorm [--from-loop N]` | No | Picks own approach |
| grill | `/goodfellow:grill "<topic>"` | No | Write-from-context (`=1`) |
| spec-review | `/goodfellow:spec-review <path>` | Optional | Full loop |
| plan | `/goodfellow:plan <spec-path>` | No | Auto-dispatches |
| plan-review | `/goodfellow:plan-review <path>` | Optional | Full loop |
| execute | `/goodfellow:execute <plan-path>` | Optional | All tasks |
| ship | `/goodfellow:ship [--quick]` | Optional | Full auto |

`brainstorm` and `grill` are sibling design front-ends that produce the same spec artifact and both
auto-dispatch spec-review. Routing is by intent: **clear intent → `brainstorm`** (default, ≤3
questions); **fuzzy or high-stakes intent → `grill`** (explicit invocation only — `/goodfellow:grill`
or "grill me on X" / "interview me about X"; a relentless one-question-at-a-time interview that
self-terminates when its decision ledger is empty). `grill` never auto-selects over `brainstorm`.

`execute` runs a plan's tasks **serially by default**. When a phase has enough genuinely independent
work (roughly ≥3 tasks with no dependency edge between them), it can fan out **worktree-isolated
parallel implementers** — one agent per task, each running in its own runtime-isolated git worktree
branched off a checkpoint commit, with results reconciled by merge. Because no two children ever
write the same working tree, concurrent implementers can't clobber or strand each other's commits;
the isolation is enforced at the runtime layer (not by prose), and file overlap becomes a
merge-cleanliness hint rather than a corruption hazard. Fan-out is the justified exception, not a
default mode — below the floor, or without runtime-enforced isolation, `execute` stays serial.

### Review and Triage (2 skills)

| Skill | Invocation | Codex? |
|---|---|---|
| codex-review | `/goodfellow:codex-review` | Optional (single-Claude fallback) |
| triage | `/goodfellow:triage` | Optional |

### Session Lifecycle (4 skills)

| Skill | Invocation |
|---|---|
| snap-compact | `/goodfellow:snap-compact` |
| close | `/goodfellow:close` |
| branch | `/goodfellow:branch <topic>` |
| prune-stale | `/goodfellow:prune-stale` |

## Codex Integration (Optional)

The [Codex CLI](https://github.com/openai/codex) is where the real adversarial value lives. When present, review skills run cross-model review (Claude + Codex/GPT) — two different model families catching different defect classes. Without Codex, reviews fall back to a single Claude reviewer. It still works, but you lose the cross-model diversity that makes adversarial review genuinely adversarial.

**Recommended setup:** Opus as your main session, Codex + Sonnet as the reviewers. Three perspectives: Opus reconciles, Sonnet reviews, Codex catches what Claude misses. For the full benefit, [install the free Codex CLI](https://github.com/openai/codex).

These are practical recommendations from daily use, not formal benchmarks.

### Why Codex specifically: cost

A second, *independent* model reviewing the change beats one model reviewing its
own work — it catches the failures the author's model rationalized away. The
reason to make that second model Codex is **cost**:

- **Near-zero marginal cost.** Run direct via the Codex API, per-token pricing is
  low; run it through a Codex CLI subscription, the included limits are generous
  enough that an adversarial pass on every change is effectively free at the
  margin. You are not paying premium-model rates to review every diff.
- **A different model family** from the one writing the code, so its blind spots
  differ — the whole point of an adversarial second opinion.
- **The result:** adversarial review you can afford to run on *every* change, plus
  a second grounding pass (below) that drops the reviewer's own weak findings, at
  the same near-zero marginal cost.

### Two-stage generator + judge

On the Codex path, `codex-review` (and the review step of `execute`/`ship`) runs
two passes: a **generator** emits structured per-finding blocks, then a **judge**
grounds-or-drops each one (evidence + confidence threshold + diff-boundary scope).
A real blocker is never silently dropped — any judge/validation problem fails OPEN
to the unjudged findings plus a degradation banner. The final review carries a
`## Judge audit` table. The single-Claude fallback path is UNJUDGED and says so.

### Optional static-analysis pre-pass (D1)

For `--commit` and `--base` code reviews the bridge can prepend a deterministic
static-analysis digest (as corroborating signal, not the finding list). Every
analyzer is **optional and auto-detected** — if the binary is not installed the
pre-pass skips it with a note and the review proceeds. Install whichever you want:

| Tool | Detects | Runs by default |
|---|---|---|
| [`ruff`](https://github.com/astral-sh/ruff) | Python lint (`--isolated`, no repo config) | Yes, if installed |
| [`shellcheck`](https://www.shellcheck.net/) | Shell lint (`--norc`, no repo config) | Yes, if installed |
| [`gitleaks`](https://github.com/gitleaks/gitleaks) | Secrets in the reviewed history | Yes, if installed (uses the vendored `configs/gitleaks.toml`) |
| [`semgrep`](https://github.com/semgrep/semgrep) | Generic footguns (vendored local ruleset, never `--config auto`) | Yes, if installed |
| `eslint` / `tsc` / `mypy` | JS/TS/Python (executing analyzers) | Only with `GOODFELLOW_TRUST_ANALYZERS=1` |

Executing analyzers (`eslint`/`tsc`/`mypy`) stay OFF by default — they load
project config and execute in the repo; opt in with `GOODFELLOW_TRUST_ANALYZERS=1`
only for repos you trust.

```bash
# Force-disable Codex even when installed
GOODFELLOW_CODEX=0

# Set the Claude reviewer model
GOODFELLOW_REVIEW_MODEL=opus    # Strongest — no-Codex fallback default
GOODFELLOW_REVIEW_MODEL=sonnet  # Cheaper; the spec/plan-review parallel-reviewer default
GOODFELLOW_REVIEW_MODEL=haiku   # Quick passes on small diffs
```

`GOODFELLOW_REVIEW_MODEL` names the Claude reviewer model. It is honored in two
places: the bridge's single-Claude reviewer when Codex is absent (a script env
read), and the parallel Claude reviewer that `spec-review` / `plan-review`
dispatch alongside Codex (a prose-directed model choice in those skills). It never
reaches the Codex/GPT path (that path takes `GOODFELLOW_CODEX_MODEL`).

Two defaults apply when the variable is UNSET, by design:
- **No-Codex bridge fallback → `opus`.** With no Codex there is no cross-family
  reviewer, so verifier strength is the only lever; under-tiering the sole
  reviewer below the code's generator gives false confidence. This is the only
  default this change flips.
- **`spec-review`/`plan-review` parallel Claude reviewer → `sonnet`** (the value
  written in those skills). Codex/GPT already supplies the cross-family
  verification, so the parallel Claude reviewer stays cheap without weakening the
  gate.

The table below describes the **bridge reviewer** the review skills call. In
addition, `spec-review` and `plan-review` always dispatch their own parallel
Claude Reviewer-1 (default `sonnet`) — so those two skills run two reviewers even
when Codex is absent (parallel Sonnet + the bridge's Claude fallback).

**How the bridge reviewer composes:**

| Codex | GOODFELLOW_REVIEW_MODEL | Bridge reviewer | Notes |
|---|---|---|---|
| Present | (any) | Codex/GPT (judged) | Cross-family reviewer; this variable does not reach the Codex path |
| Absent | opus (default) | Single Opus reviewer | Strongest verifier when there is no cross-family reviewer |
| Absent | sonnet | Single Sonnet reviewer | Correct when your generator is Sonnet; cheaper |
| Absent | haiku | Single Haiku reviewer | Quick passes on small diffs |

## Philosophy

- **Cross-model review catches what single-model misses** — different training lineages find different defect classes; same-model duplication adds little
- **Research injection grounds findings in verified facts** — factual claims are web-searched, not assumed
- **Convergence-based, not round-count-based** — stop when severity drops, not at an arbitrary round number
- **Verifier-before-fix prevents infinite loops** — don't burn fix cycles on stale findings
- **Knowledge should compound** — every chain run makes the next one better
- **Follow-ups need tracking, not just noting** — deferred findings become loops, triaged, not forgotten
- **Sessions deserve closing rituals** — persist learnings, check loops, clean up

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `GOODFELLOW_AUTOPILOT` | unset | `1` for full auto, `dry-run` for observe mode |
| `GOODFELLOW_CODEX` | `1` | `0` to force-disable Codex |
| `GOODFELLOW_CODEX_MODEL` | unset | GPT model id for the Codex path only (unset → codex default). Never receives a Claude model name. |
| `GOODFELLOW_REVIEW_MODEL` | `opus` fallback / `sonnet` parallel | Claude reviewer model (`opus`/`sonnet`/`haiku`). When set, drives BOTH the no-Codex fallback reviewer and the spec/plan-review parallel Claude reviewer. Unset defaults differ: `opus` for the fallback, `sonnet` for the parallel reviewer. Never reaches the Codex/GPT path. |
| `GOODFELLOW_TRUST_ANALYZERS` | unset | `1` enables the executing D1 analyzers (`eslint`/`tsc`/`mypy`) — only for trusted repos |
| `GOODFELLOW_CODEX_STAGE_TIMEOUT` | `300` | Per-stage Codex timeout (seconds). The pipeline runs Codex twice (generator + judge), so total wall-clock is up to 2×. |
| `GOODFELLOW_TAVILY_KEY` | unset | Tavily API key for batch research verification (optional — falls back to WebSearch) |
| `GOODFELLOW_TRIAGE_RETENTION_DAYS` | `90` | Days to keep closed-loop triage entries |
| `GOODFELLOW_RUNS_RETENTION_DAYS` | `90` | Days to keep autopilot run logs |
| `GOODFELLOW_PRINCIPLES_WEB` | unset | `1` forces reading the web supplement (`knowledge/principles-web.md`) alongside core (and hard-errors if that file is missing — packaging drift). Unset or empty → auto-detected by a `package.json` at the project root (best-effort: core-only if the supplement isn't present). Any other non-empty value hard-errors. |
| `GOODFELLOW_MEMORY` | `flat` | Memory backend. `flat` (default): append-only `.goodfellow/knowledge.md` with `[pending]→confirmed` promotion — zero-config, unchanged. `rich`: per-fact files (`.goodfellow/memory/*.md`) + regenerated index (`.goodfellow/MEMORY.md`) + domain registries + hybrid recall; first rich write auto-migrates an existing `knowledge.md`. Any other value hard-errors (no silent fall-back). The gate is enforced at the **chain-skill dispatch** level — skills resolve the mode (via `memory_config.py`) before choosing the flat or rich path. `scripts/memory_index.py` is the rich backend implementation invoked once rich is selected; it is not itself mode-gated, so don't invoke it directly while in `flat` mode. |
| `GOODFELLOW_MEMORY_WARN_KB` | `16` | Rich-mode advisory size threshold (KB). When `MEMORY.md` exceeds it, regenerate prints a stderr warning suggesting `/goodfellow:triage`. Must be a positive integer; any other value hard-errors. Warning only — regeneration always completes. |
| `GOODFELLOW_GUARDS` | `1` | Tool-layer PreToolUse guards (see below). `0` disables the built-in universal guards; user BLOCK rules in `.goodfellow/guards.json` still run. `CLAUDE_HOOK_BYPASS=1` disables everything for one command. |

### Tool-layer guards

A constraint whose violation is expensive to reverse does not belong in prose. Compaction is optimized for task accuracy, so nothing measures whether a "never do X" instruction survives the rewrite — and once it is gone, the session that inherits the summary was never told the rule. The fix that works is enforcement at the tool layer: a `PreToolUse` hook (`hooks/hooks.json` → `scripts/guard_engine.py`) that fires deterministically on every tool call regardless of what the context still holds.

**Built-in universal guards** (on by default, no project knowledge required):

- `git add -A` / `git add .` / `git add --all` — stage specific files; a blanket add is how secrets and stray artifacts leak into a commit.
- `--dangerously-skip-permissions` — this flag disables the permission prompt for every tool call.
- Force-push to a protected branch (`main`/`master` by default) — rewriting shared history can destroy other people's commits. Force-pushing a *feature* branch is not blocked.

Matching is shlex-token based, not substring, and the built-ins inspect only the `Bash` tool's command — so writing or documenting a blocked flag in a file, or mentioning it inside a quoted commit message, never trips a guard.

**Declarative project rules.** Drop a `.goodfellow/guards.json` to enforce your own expensive-to-reverse rules at the tool layer instead of hoping a prose instruction survives. See `configs/guards.example.json`. Shape:

```json
{
  "protected_branches": ["main", "master"],
  "disable_builtins": [],
  "block": [
    {
      "id": "no-prod-db-writes",
      "match": "regex",
      "pattern": "psql.*(prod|production)",
      "flags": "i",
      "reason": "Prod DB writes need an operator greenlight.",
      "tools": ["Bash"],
      "bypass_env": "PROD_DB_OK"
    }
  ]
}
```

Each rule needs `id`, `pattern`, and `reason`. `match` is `substring` (default) or `regex`; `tools` defaults to `["Bash"]` and may include `Write`/`Edit`; an optional `bypass_env` names an env var that, set to `1`, waives that one rule. Validate a config with `python3 scripts/guard_engine.py --validate` and inspect the enforced set with `--selfcheck`.

**Failure posture.** The live hook fails *safe-open* on a malformed `guards.json`: it skips the user rules (built-ins still enforce), warns on stderr, and never deadlocks the session into a state where you cannot even edit the file to fix it. `--validate` fails *loud* (non-zero) for CI and pre-compaction checks. The `snap-compact` skill snapshots the active guard set with `--selfcheck` and re-asserts it after the compaction boundary, so governance that lives on disk is verified to have survived rather than assumed.


### Rich-mode recall hook (best-effort)

In rich mode, a plugin `SessionStart` hook (`hooks/hooks.json` → `scripts/recall_pointer.py`) injects a one-line pointer (`Goodfellow memory: N entries — read .goodfellow/MEMORY.md before design/review.`) when `.goodfellow/MEMORY.md` exists. This is **best-effort**: SessionStart hooks do not fire for local file-based / git-clone-installed plugins ([#11509](https://github.com/anthropics/claude-code/issues/11509), closed "not planned"), which is goodfellow's primary install method. The load-bearing recall path is the in-chain index read the chain skills perform every run — the design does not depend on the hook firing. Verify hook firing empirically on a marketplace install if you rely on it; flat-mode sessions get nothing injected.

## Platform Support

**Best on macOS and Linux.** On Unix, the loop store uses `fcntl` file locking for concurrent session safety. Windows works for single-session use, but file locking is skipped — avoid running multiple Goodfellow sessions on the same project simultaneously (duplicate loop IDs possible).

**Worktree-first execution recommended** — `/goodfellow:execute` nudges you to use `/goodfellow:branch <topic>` before execution. This isolates feature work from your main workspace, keeps your root clean, and avoids the Windows-specific issue where Codex temp folders require admin rights to delete after a session ends. The nudge is advisory, not mandatory.

## Contributing

Contributions welcome. Please run the test suite before submitting:

```bash
cd scripts && python -m pytest -v
```

## License

MIT
