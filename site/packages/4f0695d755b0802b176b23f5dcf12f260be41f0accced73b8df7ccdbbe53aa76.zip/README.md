# Kontext for Claude Code

Persistent, portable memory for your work.

Kontext gives Claude Code a Space of your own — Projects, Tasks, Documents, quick saves, and
reusable Agent Skills — reachable from every MCP client you connect. A decision recorded in
a terminal session is there tomorrow in Claude Desktop, ChatGPT, or Cursor. Nothing is tied
to one checkout, one client, or one conversation.

## Install

```bash
/plugin marketplace add TheKontextCo/kontext-claude-plugin
```

```bash
/plugin install kontext@kontext
```

### Installing from a zip (while the plugin awaits marketplace approval)

Download the zip from the
[releases page](https://github.com/TheKontextCo/kontext-claude-plugin/releases), then
either:

**Try it instantly** (Claude Code 2.1.128+; session-only, not persisted):

```bash
claude --plugin-url https://github.com/TheKontextCo/kontext-claude-plugin/releases/latest/download/kontext-claude-plugin-v0.3.0.zip
```

**Install persistently** — unzip the archive anywhere, then add the unzipped folder as a
local marketplace:

```bash
/plugin marketplace add /path/to/unzipped/kontext-claude-plugin
/plugin install kontext@kontext
```

On first use, Claude Code opens the Kontext authorization screen in your browser. Continue
with Google or verify an email address; both paths resolve to the same account. The client
receives its own revocable OAuth grant — signing out one client leaves the others connected.

No API key, no environment variable, and nothing to run locally. The MCP server is hosted at
`https://thekontextco.ai/mcp`.

## Commands

| Command | What it does |
| --- | --- |
| `/kontext:catch-up [project]` | Rebuilds context for the current repository — project state, open tasks, prior decisions — before you start work |
| `/kontext:recall <query>` | Searches your Space for prior work, decisions, or notes on a topic |
| `/kontext:save [what]` | Saves what this session produced, minus anything git already records |
| `/kontext:log-decision <decision>` | Records a decision with its rationale, rejected alternatives, and consequences |
| `/kontext:save-skill <name>` | Packages a local Agent Skill into Kontext, available from any client |
| `/kontext:status` | Confirms the connection and summarises what is in your Space |

## Automatic use

Four skills from the [kontext-skills](https://github.com/TheKontextCo/kontext-skills)
collection are bundled and activate on their own:

- **kontext-context** — treats Kontext as the system of record for durable AI work:
  checking whether work already exists before starting, recording projects, tasks,
  documents, and decisions so they survive the conversation, and keeping status current.
- **kontext-memory** — frictionless capture of durable facts, decisions, and observations
  via `save_to_kontext`, with recall through `search_context`.
- **kontext-tasks** — runs non-trivial work through Kontext's task loop: tracking,
  resuming, reporting progress and blockers.
- **kontext-sharing** — working correctly with records shared to or by you, respecting
  read-only versus edit permissions.

It will not save secrets, and it will not delete anything without previewing exactly what
would be removed first.

## Tools

The plugin bundles the hosted Kontext MCP server, which provides:

- **Context** — `get_my_context`, `search_context`, `get_timeline`, `kontext_status`
- **Projects** — `list_projects`, `manage_project`
- **Tasks** — `list_tasks`, `manage_task`, `manage_task_relationship`
- **Documents** — `list_documents`, `manage_document`, `read_document`
- **Quick saves** — `save_to_kontext`
- **Skills** — `list_skills`, `get_skill`, `read_skill_file`, `save_skill`, `manage_skill`
- **Imported history** — `list_conversations`, `read_conversation`
- **Relationships** — `manage_relationship` (with `manage_task_relationship` and
  `manage_context_relationship` as deprecated aliases)
- **Account** — `sign_out`, `request_account_deletion`

Projects, tasks, documents, and quick saves archive without losing metadata, relationships,
revisions, or bodies. Deletion always previews first and requires explicit confirmation.

## Sharing

Any project, task, document, quick save, or Skill can be shared from the web Library with up
to 20 email addresses at a time, as view or edit access. Shared records appear in normal MCP
results marked with their permission; Kontext keeps them in the owner's Space rather than
copying them.

## Privacy and data

Your Space is yours. Kontext stores what you save to it and nothing else — it does not read
your repository, and it has no access to a session beyond the tool calls Claude Code makes.

- Account deletion: <https://thekontextco.ai/account>, or the `request_account_deletion`
  tool, which requires two explicit confirmations and fresh email verification.
- Privacy policy and support: <https://thekontextco.ai/support>
- Questions, bugs, or plugin feedback: <support@thekontextco.ai>

## Links

- Product: <https://thekontextco.ai>
- Library: <https://thekontextco.ai/library>
- Developer guide: <https://thekontextco.ai/developers>
- MCP server card: <https://thekontextco.ai/.well-known/mcp/server-card.json>

## License

MIT — see [LICENSE](LICENSE).
