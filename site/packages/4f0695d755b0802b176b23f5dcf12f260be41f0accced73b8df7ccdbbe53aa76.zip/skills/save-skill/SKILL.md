---
name: save-skill
description: Save a reusable Agent Skill to Kontext so it is available from any MCP client
argument-hint: <skill name or path>
allowed-tools:
- mcp__plugin_kontext_kontext__save_skill
- mcp__plugin_kontext_kontext__list_skills
- mcp__plugin_kontext_kontext__get_skill
- mcp__plugin_kontext_kontext__read_skill_file
- mcp__plugin_kontext_kontext__manage_skill
- Read
- Glob
disable-model-invocation: true
---

# Save a Skill to Kontext

Package and store the Skill: **$ARGUMENTS**

Kontext keeps complete, portable Skill packages, so a Skill saved from this repository is
retrievable from every MCP client the user connects.

## Assemble the package

1. Locate the Skill root — the directory holding `SKILL.md`. `$ARGUMENTS` may be a path or
   a name; with a name, glob for `**/skills/<name>/SKILL.md` and `**/<name>/SKILL.md`.
2. Read `SKILL.md`. Its frontmatter `name` and `description` become the Skill's identity in
   Kontext, so check they are actually present and that the description states *when* to
   use the Skill, not just what it does.
3. Glob the whole package and read every supporting text file — references, examples,
   scripts. Paths are relative to the Skill root.

`files` is the authoritative snapshot, not a patch: it must carry the root `SKILL.md` plus
every supporting file, and any path present on a previous save but omitted now is deleted.
Never call `save_skill` with a partial file list.

Binary assets cannot be stored. If the package depends on one, save the rest and tell the
user which file was dropped and that the Skill will not be complete without it.

## Check for an existing copy

Call `list_skills` first. Saving the same name replaces the stored package outright.

- If a Skill with this name already exists, `get_skill` and tell the user what will be
  replaced before you overwrite it.
- If the local copy is *older* than the stored one, stop and say so rather than
  silently reverting their work. `read_skill_file` pulls a single stored file when you need
  to compare one rather than the whole package.
- To retire a Skill rather than replace it, use `manage_skill` — archive is reversible,
  deletion is not and needs a preview plus explicit confirmation.

## Save and confirm

Call `save_skill`, then report the name, the file count, and the `markdownLink`.
