# Sales Retriever for Claude

Connect Claude Code and compatible Cowork plugin clients to Sales Retriever's Remote MCP service. Search Japanese companies, departments, employees, personnel movements, event speakers, and lists available to your Sales Retriever account.

This repository contains only plugin metadata, a remote connection URL, and documentation. It does not contain Sales Retriever's application source, customer data, passwords, API keys, a local bridge, or executable hooks.

## Requirements

- A Sales Retriever account with access to the requested data and MCP service. Service subscription and usage limits apply; installing this plugin does not grant a subscription or additional permissions.
- A Claude client and plan that support plugins and remote MCP authentication. Organization administrators may restrict plugin installation.
- Complete browser-based Sales Retriever OAuth sign-in when prompted. Use your Sales Retriever credentials, not your Claude password. Never put a password or access token in this repository or chat.

## Install in Claude Code

In an interactive Claude Code session:

```text
/plugin marketplace add Sales-Retriever/claude-plugin
/plugin install sales-retriever@sales-retriever-plugins
```

Choose the appropriate installation scope in the client. Reload plugins or restart Claude Code if requested. Open `/mcp`, select the plugin's Sales Retriever server, and complete authentication in the browser.

This is the publisher-maintained marketplace. Availability in Anthropic's official directory requires separate approval; this README does not claim official-directory approval.

## Cowork

Use Cowork's plugin installation UI when the client supports this marketplace. After installation, follow its connection/sign-in prompt for Sales Retriever. Organization policy and client support may affect availability. See [Anthropic's plugin documentation](https://code.claude.com/docs/en/plugins) for current installation options.

## Try it

- `Sales Retrieverで利用できるリストを1ページ目、20件取得してください。実際のツール結果だけを回答してください。`
- `Sales Retrieverで「トヨタ自動車株式会社」を検索してください。他の絞り込みは付けず、実際に返った会社名と法人番号を示してください。`
- `Sales Retrieverで企業を検索し、その企業の部署と従業員を調べてください。取得できない情報は推測せず、その旨を示してください。`

This plugin is intended for read-only research using the service's advertised read scopes. Available tools and records depend on the signed-in account and granted scopes. Empty results are different from authentication or execution errors; ask Claude to distinguish them and use returned records rather than inventing results. Check current source information before making business decisions.

## Authentication and troubleshooting

Endpoint: `https://sales-retriever.com/api/mcp` (Streamable HTTP over HTTPS).

OAuth discovery and token handling are performed by the MCP client. No shared client secret or API key is bundled. Your query and required tool arguments are sent to Sales Retriever; returned records become available to Claude in the conversation.

If authentication fails, use `/mcp` in Claude Code to reconnect, ensure you can sign in to Sales Retriever, and check your organization's access policy and usage limits. Do not disable MFA or other account protections to troubleshoot. For support, share the error text and timestamp, but never tokens or passwords.

Avoid configuring the same endpoint as both a manual MCP server and this plugin unless you intentionally need duplicate connections.

## Links

- [Sales Retriever](https://sales-retriever.jp)
- [Privacy policy](https://sales-retriever.jp/privacypolicy/)
- [Claude Code plugins](https://code.claude.com/docs/en/plugins)
- [Plugin marketplaces](https://code.claude.com/docs/en/plugin-marketplaces)
- [Claude Code MCP authentication](https://code.claude.com/docs/en/mcp)
- Support: support@sales-retriever.com

## License

The plugin distribution files in this repository are licensed under the [MIT License](LICENSE). This license does not apply to the Sales Retriever service, private application source, or data returned by the service; access remains subject to the service's terms and your account permissions.
