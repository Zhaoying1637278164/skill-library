# spyglasses-skills

A set of Claude skills (and an MCP connector) for interacting with the
[Spyglasses](https://www.spyglasses.io) AI Visibility platform.

[![skills.sh](https://skills.sh/b/orchestra-code/spyglasses-skills)](https://skills.sh/orchestra-code/spyglasses-skills)

This repo is a **Claude Code plugin marketplace**. The `spyglasses` plugin
bundles:

- **Skills** — domain knowledge for interpreting Spyglasses reports (under `skills/`).
- **MCP connector** — the `spyglasses` MCP server (`.mcp.json`) that fetches your
  report data, so one install wires up both the know-how and the data access.

## Skills

| Skill | What it does |
| --- | --- |
| `spyglasses-reports` | Read and act on Spyglasses AI-visibility data — public reports and site audits, plus your account's projects, historical trends, message drift, citation intelligence, and AI placement (value/quality) scores. |
| `citation-optimizer` | Run the AI Citation Optimizer's audit loop. Score a page, URL or draft against a whole set of searches on ChatGPT, Google AI Overviews, Google AI Mode and Claude at once, read the harmonized findings, generate a meaning-preserving rewrite, and re-score to confirm the lift, stopping when the content is publish-ready. Also briefs a page that does not exist yet from a single keyword. |

More skills will be added here over time; they share the same MCP connector.

## Install (Claude Code)

```
/plugin marketplace add orchestra-code/spyglasses-skills
/plugin install spyglasses@spyglasses-skills
```

This installs the skill(s) and the `spyglasses` MCP connector.

### Authentication

The MCP connector talks to `https://www.spyglasses.io/api/mcp` and authenticates
with **OAuth** — when you add it, your assistant opens a browser to sign in with
your Spyglasses account (one time). No API key to find or paste.

Once connected:

- **Token-scoped tools** work for any report by its public token (from the
  report's share URL).
- **Org- and property-scoped tools** (`list_my_organizations`, `list_reports`,
  `list_properties`, and the project/metrics/citation/scoring tools) use your
  account's membership. Reporting and analytics create, edit and spend nothing.
  The citation optimizer tools do write, all inside your own account: they create
  scoring runs, **draft** rewrites and briefs. They never publish anything and
  never touch a live page.

## Use with Claude.ai / ChatGPT / other assistants

Add `https://www.spyglasses.io/api/mcp` as a custom MCP connector in your
assistant's settings and complete the sign-in (OAuth) prompt. Then load /
reference the `spyglasses-reports` skill.

> A `?q=` "Chat with this report" deep-link button (in the Spyglasses report UI)
> opens a one-shot conversation using the report's Markdown snapshot. It does
> **not** auto-connect this MCP — connectors are added manually, once, here.

## MCP prompts (start here)

Prompts are the easiest entry point — pick one from your assistant's prompt menu
and give it a report's public token; it drives the right tools for you:

- `analyze_report` — summarize a report and surface key findings
- `what_to_fix_first` — a prioritized, role-based action plan (SEO/AEO, PR, technical)
- `competitor_gaps` — where competitors rank/are cited and the brand isn't
- `audit_worst_pages` — surface and explain a site audit's weakest pages
- `list_my_reports` — list your org's reports (uses your signed-in account)
- `analyze_project` — summarize a project's progress, trends, and next moves
- `track_message_drift` — how AI's description of a brand changes over time
- `citation_mix_trends` — how the mix of sources AI cites shifts over time
- `evaluate_publishers` — score and rank publishers by AI Placement Value

## MCP tools

**Reports (token-scoped** — pass a report `publicToken`): `get_ai_visibility_report`,
`get_ai_visibility_recommendations`, `get_ai_visibility_grounding`,
`get_ai_visibility_citations`, `get_site_audit_summary`,
`list_site_audit_pages`, `get_site_audit_page`.

**Account / organization:** `list_my_organizations`, `list_reports`, `list_properties`.

**Property-scoped** (pass a `propertyId` from `list_properties`): `list_projects`,
`get_project_insights`, `get_metrics_history`, `get_consistency_history`,
`get_message_tracking`, `get_answer_summaries`, `get_citation_intelligence`.

**Scoring:** `score_publisher_value` (AIPVS), `score_placement_quality` (PQS).

**Citation Optimizer** (property-scoped): `list_tracked_fanouts`,
`match_pages_for_fanout`, `list_property_pages`, `list_placements`,
`get_placement`, `score_citation_audit`, `get_citation_audit`,
`reweight_citation_audit`, `revise_citation_audit`, `get_revision`,
`rescore_revision`, `generate_citation_outline`, `get_citation_outline`, plus the
legacy single-query shape `score_citation_pipeline`, `get_pipeline_run` and
`revise_content`.

The reporting, account, property and scoring tools create, edit and spend nothing.
The citation optimizer is the exception. Scoring is free of credits but counts
against a monthly **page** allowance (a page counts once a month however often it
is re-run, and re-scoring a rewrite never counts); `revise_citation_audit`,
`revise_content` and `generate_citation_outline` produce drafts and **spend
credits**; `reweight_citation_audit` is free. Nothing is ever published.

## Local development & testing

Test the plugin without publishing it. The MCP `url` is environment-overridable
(`${SPYGLASSES_MCP_URL:-https://www.spyglasses.io/api/mcp}`).

```bash
# Point at a dev MCP endpoint (kept out of the repo). Use a publicly reachable
# HTTPS URL (e.g. an ngrok tunnel) — the OAuth browser redirect must reach it.
export SPYGLASSES_MCP_URL=https://<your-dev-host>/api/mcp

# Fastest loop — load the plugin from this directory (no install/marketplace).
# Edit files, then run /reload-plugins inside Claude Code to pick up changes.
claude --plugin-dir .

# Inside Claude Code:
#   /mcp                         → connect (completes the OAuth sign-in once)
#   /spyglasses:spyglasses-reports
```

To exercise the full marketplace + install flow against a local checkout:

```bash
# Inside Claude Code (absolute path works):
/plugin marketplace add /absolute/path/to/spyglasses-skills
/plugin install spyglasses@spyglasses-skills
```

See `.env.example` for the variables. Never commit a real dev URL.

> **Don't run the production and dev connectors at once.** Both report the same
> MCP server name and expose overlapping tool names (the dev endpoint is a
> superset of prod), so enabling both in one conversation collides. On Claude.ai,
> add the dev endpoint as a separate, distinctly-named connector (e.g.
> `Spyglasses (dev)`) and toggle connectors per conversation; in Claude Code,
> disable the installed `spyglasses` plugin while `--plugin-dir .` is active. The
> dev MCP host must be a stable public HTTPS origin and the dev server's
> `NEXT_PUBLIC_SITE_URL` must match it, or OAuth discovery fails. See the
> monorepo `README.md` → "Testing the MCP server & skills locally" for the full
> walkthrough.

## Releasing

```bash
claude plugin validate .
```

Bump `version` in `.claude-plugin/plugin.json` (semver) and record changes in
`CHANGELOG.md` for every release. To submit to the community directory, see
https://clau.de/plugin-directory-submission.
