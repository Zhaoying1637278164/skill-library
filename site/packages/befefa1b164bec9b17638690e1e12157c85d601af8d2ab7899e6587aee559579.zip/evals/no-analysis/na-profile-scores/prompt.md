---
description: "no-analysis · expect profile-review · fresh"
tags: ["no-analysis","expect-profile-review","fresh"]
max_turns: 14
timeout_seconds: 300
allowed_tools: ["Skill"]
append_system_prompt: "You are a helpful assistant in a general-purpose chat app. The person is talking to you about their own life and work, not about code or files in this directory, unless they say so. Answer them directly in conversational prose."
---

Analyze my LinkedIn profile and tell me my scores.
