# Adding fields to a PDF that already exists

Open this when the user brings their own document — *"here is our standard contract, make it
signable"* — rather than asking for a new one to be written. It is the most common request and
the one where a good-looking result is most often silently broken.

This file assumes code execution is available. If it is not, go back to `SKILL.md` step 5 and
deliver the field specification instead; nothing here changes that ordering.

## The rule this file exists for

**Do not recreate their document.** A redrawn lookalike is not their contract: their lawyer
approved the original wording, their letterhead, their clause numbering. Re-typesetting it
introduces differences nobody asked for and nobody will proofread. Add fields to the file they
gave you and change nothing else.

Recreating is the right answer only when the user explicitly asks for a new version, or when
what they sent is a scan with no text layer and they agree to a rebuild.

## What the environment gives you

The closed list from `SKILL.md` step 5: `reportlab`, `pypdf`, `pdfplumber`, `pypdfium2`,
`pillow`. Try each import before relying on it. So:

- **Write the code yourself.** These libraries are enough to do everything below; you do not
  need a recipe to copy, you need to know which traps are there.
- **No installer without the user's explicit yes** to a named list of packages in a named
  folder, and never Python itself, a browser or a system package. The whole rule, with the
  standard-library rung that needs no install at all, is step 5 of `SKILL.md`. What you
  install exists only on this machine and in this session.
- **`pymupdf` / `fitz` is forbidden** even when already present: AGPL.
- **Do not print or convert the user's PDF through HTML.** Add real AcroForm fields directly
  to the original PDF. The fixed sector-template exception in `SKILL.md` step 5 applies
  only to generating a document from a shipped template, never to rebuilding this file.
- Verify by **rendering a page to an image and looking at it**. A PDF that opens is not a PDF
  that is correct.

## The trap that ruins most attempts

Building widgets on a blank overlay page and merging that page into the original **loses every
field.** Page merging copies the content stream — the visible marks — and drops `/Annots`, which
is where form fields actually live. The result looks perfect: the boxes are drawn, the text is
positioned, nothing errors. There is simply no form.

The way through is to stop treating a field as something you draw. A field is a dictionary
registered in three places at once:

1. in the target page's `/Annots` array,
2. in the document catalog's `/AcroForm /Fields` array,
3. with its own `/P` entry pointing back at the page that holds it.

Miss any one of the three and the field is invisible, unfillable, or attached to the wrong page.

## Four failures that are worth knowing before you start

**`/P` pointing at the wrong page.** If widgets are created while the layout engine still
believes it is on page one — which happens whenever page output is deferred, for example to
number pages once the total is known — every widget on every later page carries page one's
reference. Formify's ingestion trusts `/P`, so a five-page contract arrives with all its fields
stacked on the first page. After building the document, walk every page and set each widget's
`/P` to the page whose `/Annots` actually contains it. It is a few lines and it is not optional.

**No appearance stream.** A widget with no `/AP /N` renders as nothing in many viewers. Either
build the appearance stream for each widget, or set the document-level flag that tells viewers
to generate appearances themselves. Setting that flag is the cheaper and more robust choice for
documents going into a signing flow.

**Missing font resource.** Text typed into a field is drawn with a font named in the AcroForm
default resources. If that dictionary has no usable face, typed characters vanish. Worse, the
standard built-in encoding covers only WinAnsi: `š ž å ä ö é` survive, `č ć đ ł ř ș` do not.
For any document in Croatian, Polish, Romanian, Turkish or Czech, embed a Unicode face and
reference it from the AcroForm default resources — the page text may look right while the
fields silently drop characters.

**An empty string as a value.** Setting a field's value to `""` is not the same as leaving it
unset, and it is rejected downstream. Omit the value entirely.

## Finding where to put a field

The user rarely knows coordinates. Read them off the document instead: extract the words with
their bounding boxes and look for the label the field belongs to — `Name:`, `Date:`, a row of
dots, an underscore run.

Two things to be careful about:

- **The vertical axes disagree.** Text-extraction libraries usually measure from the top of the
  page; the PDF coordinate system measures from the bottom. Convert with
  `pdf_y = page_height − top`, and confirm on a rendered image rather than trusting it.
- **A field sits under its label, not on it.** Place it at
  `label_y − label_font_size − gap − field_height`, with a gap of three to five points. A field
  drawn at the label's own baseline covers the label, and Formify's fields are opaque.

## A widget inside a table cell, placed afterwards

Layout libraries draw tables; few of them put a form widget inside a cell. Draw the table
with the cell empty, then add the widget by the cell's coordinates. With `pypdf` (tested on
6.18, reads back with the right names and flags):

```python
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (ArrayObject, BooleanObject, DictionaryObject, FloatObject,
                           NameObject, NumberObject, TextStringObject)

# name, page (0-based), x, y, width, height, required  —  points, PDF origin bottom-left
FIELDS = [("titular_nif", 0, 206, 300, 100, 18, True),
          ("buyer_id|tink-scan-id[1]", 0, 206, 160, 180, 120, True)]

w = PdfWriter(clone_from="document.pdf")
root = w._root_object
if "/AcroForm" not in root:
    root[NameObject("/AcroForm")] = w._add_object(DictionaryObject())
acro = root["/AcroForm"].get_object()
acro[NameObject("/NeedAppearances")] = BooleanObject(True)
acro.setdefault(NameObject("/Fields"), ArrayObject())
for name, pno, x, y, wd, ht, required in FIELDS:
    page = w.pages[pno]
    widget = DictionaryObject({
        NameObject("/Type"): NameObject("/Annot"), NameObject("/Subtype"): NameObject("/Widget"),
        NameObject("/FT"): NameObject("/Tx"), NameObject("/T"): TextStringObject(name),
        NameObject("/Ff"): NumberObject(2 if required else 0), NameObject("/F"): NumberObject(4),
        NameObject("/Rect"): ArrayObject([FloatObject(x), FloatObject(y),
                                          FloatObject(x + wd), FloatObject(y + ht)]),
        NameObject("/DA"): TextStringObject("/Helv 10 Tf 0 g"),
        NameObject("/P"): page.indirect_reference,
    })
    ref = w._add_object(widget)
    if "/Annots" in page: page["/Annots"].get_object().append(ref)
    else: page[NameObject("/Annots")] = ArrayObject([ref])
    acro["/Fields"].append(ref)
w.write("document-fields.pdf")
```

Three things this gets right that a naive overlay loses: the widget is in the page's
`/Annots`, in `/AcroForm /Fields`, and carries `/P` to its own page. A read-only trigger adds
`1` to `/Ff`; an image-capture field is sized to the rectangle it will be stretched into.
Widths that fit the boxes: 180 pt for a name, an address or an e-mail; 100 pt for a tax
number; 90 pt for a fee or a share; 300 pt for a full-width row. A field wider than its cell
covers the cell next to it.

## Replacing text that is already printed

Sometimes a placeholder is already typed into the document — a name, a date, a fixed amount —
and the user wants a fillable field there instead. Rewriting the content stream to delete it is
fragile and rarely worth it.

Cover it instead: draw an opaque rectangle in the page background colour over the old text, one
to two points larger than its bounding box on each side, then place the field on top. Save and
restore the graphics state around the rectangle so it does not leak into the marks that follow.

Two cautions. The old text is still in the file and can be recovered by copy-paste or
extraction, so this hides, it does not redact — never use it for anything confidential. And the
rectangle must match the actual background; on a tinted band or a table cell, a white rectangle
is a visible patch.

## Field behaviour

Field behaviour is set by summing flag bits into one integer. The ones that matter here:

| Behaviour | Bit | When to use it |
|---|---|---|
| Read-only | 1 | Every `tink-*` trigger and every auto-filled field. Mandatory. |
| Required | 2 | Only where the user said the field is required. |
| No export | 4 | Rare; the field's value is not included in exported data. |
| Multiline | 4096 | A text box taller than about 1.5 lines. |
| Do not scroll | 8388608 | Hard-limits input to what fits the box. |
| Comb | 16777216 | Fixed-pitch character cells. Needs a maximum length set. |

They are summed: multiline **and** required is `2 + 4096 = 4098`.

A few defaults are worth setting deliberately rather than inheriting: auto-shrinking text (a
font size of zero) so a long answer stays inside its box; multiline wherever a box is tall
enough to suggest more than one line; and read-only left **off** for everything the signer is
meant to complete.

## Radio groups

Options belong to one group when they share a group identifier in the field name. Two blocks of
the same question — the same consent asked of two people — must use **different** identifiers,
or choosing an option for one person silently changes the other. And no option value may contain
a `/`; the slash corrupts the stored value.

## Before handing it over

- Render at least the first page and every page carrying fields to an image, and look at them.
- Confirm every widget's `/P` matches the page it is on.
- Confirm field names are unique, and that every `tink-*` name matches the catalogue exactly —
  see `references/tink-attributes.md`. There is no error path for a wrong attribute; silence is
  the failure.
- Confirm the signature areas are still empty. A widget in the signature space collides with
  Formify's signing overlay.
- Say which route produced the file, and name anything you could not verify.
