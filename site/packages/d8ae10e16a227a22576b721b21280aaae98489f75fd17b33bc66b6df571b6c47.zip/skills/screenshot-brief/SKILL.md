---
name: screenshot-brief
description: "Use to prepare screenshot copy, screenshot order, creative briefs, and App Store / Google Play visual messaging."
metadata:
  version: '1.0.0'
---

# Screenshot Brief

Create screenshot copy, creative direction, ordering, localization notes, and ASO.dev uploader readiness.

## Inputs

- App positioning
- Target country/locale
- Audience
- Top features
- Competitor screenshot patterns
- CPP/PPO/Default page
- Device sizes
- Existing screenshots
- Existing app previews/videos
- Upload target: default page, CPP, PPO, Google Play, or all locales

## Platform notes

- App Store: first 2-3 screenshots carry most conversion weight; app preview videos should communicate the hook in the first 3 seconds.
- Google Play: at least 2 screenshots are required; the feature graphic is a major store-listing creative asset and should match the title/short description promise.

## Output

```md
# Screenshot Brief

Country:
Locale:
Page type:

## Screenshot sequence
| # | Headline | Subtext | Visual | Purpose |
|---:|---|---|---|---|

## Copy options
### Direct
...
### Benefit-led
...
### Premium
...

## Localization notes
-

## ASO.dev uploader readiness
- Folder/file structure:
- Device detection:
- Screenshot order:
- App preview/video issues:
- Missing locales/devices:

## Validation
- Claims supported:
- Text short enough:
- First 3 screenshots strong:
- Preview video first 3 seconds strong:
- Google Play feature graphic aligned:
- Matches metadata:
- Ready for mass uploader:
```

## Rules

* First screenshot must communicate the main value.
* The first 2-3 screenshots are the conversion-critical sequence; use them for the core promise, proof, and key workflow before secondary features.
* For app preview videos, the first 3 seconds must make the value obvious even on mute.
* Avoid tiny text.
* Use high contrast and large overlay text when screenshots include captions.
* Do not promise unsupported results.
* Keep screenshot/app preview copy aligned with the exact locale and product page.
* For videos, flag audio/format issues before upload when the user mentions App Store Connect rejection.
