---
name: whats-new-release-notes
description: "Use to write App Store What's New / release notes for updates, bug fixes, new features, and launch communication."
metadata:
  version: '1.0.0'
---

# What's New and Release Notes

Write clear release notes.

## Inputs

- Version
- Release date
- New features
- Improvements
- Bug fixes
- User impact
- Tone
- Countries/locales

## Output

```md
# What's New

## Recommended
...

Characters: ...

## Short version
...

## More detailed version
...

## Localization notes
-
```

## Rules

* Lead with user benefit.
* Do not overstate bug fixes.
* Keep it human and specific.
* Avoid "minor fixes" only when there are real improvements.
