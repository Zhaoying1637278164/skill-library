---
name: coach
description: Send a rough request to the prompt-coach agent and get back suggestions and an improved prompt
disable-model-invocation: true
---
If the request below is empty, don't run the subagent: ask me what I want
coached and stop there. The subagent can't ask me anything, so an empty
request would just produce a guess.

Use the prompt-coach subagent to review this request:

$ARGUMENTS

Show me the subagent's full answer exactly as returned.
Do NOT start implementing. Wait until I approve or edit the improved prompt.

When I approve, paste, or use an edited version of the improved prompt, first
save the "Learning note" from the answer, then start the work:
- Append it under the `## Entries` heading of `.claude/coach/learning-notes.md`,
  below a `### YYYY-MM-DD` heading (today's date). If the file doesn't exist,
  create it with the headings `# Prompt learning notes`, `## Recurring gaps`,
  `## Entries`.
- Update "Recurring gaps": at most 5 one-line gaps, the most frequent first.
- If the file is over ~100 lines, merge the oldest entries into Recurring gaps.

If I reject the prompt or move on without using it, don't write a note.
