# analytics-skills

Analytics skills for Claude, Cursor, and other AI agents. Read web analytics like a senior analyst: diagnose traffic changes, judge channel quality, read funnels, declare typed events, and read A/B tests without the usual rookie mistakes. Ships with tool-maps for [Amplitude](tool-maps/amplitude.md), [Clamp](tool-maps/clamp.md), [GA4](tool-maps/ga4.md), [Mixpanel](tool-maps/mixpanel.md), and [PostHog](tool-maps/posthog.md); add your own under [`tool-maps/`](tool-maps/). The schema-authoring and experiment-reading skills are built on the open [Event Schema spec](https://github.com/clamp-sh/event-schema).

## What's in the box

| Skill | What it does |
|---|---|
| [`analytics-profile-setup`](skills/analytics-profile-setup/SKILL.md) | One-time interview that captures your business context (model, primary conversion, traffic range, ICP, data stack) into a local `analytics-profile.md`. Every other skill reads this file so answers are calibrated to your industry and scale. Run this first. |
| [`analytics-diagnostic-method`](skills/analytics-diagnostic-method/SKILL.md) | The spine. Five-step method: load profile, frame the question, build a MECE hypothesis tree, triangulate, present with the Pyramid Principle. Covers signal vs noise and Simpson's paradox. Referenced by every other skill. |
| [`traffic-change-diagnosis`](skills/traffic-change-diagnosis/SKILL.md) | Drill path for "why did traffic change". Fingerprints for tracking regressions, bot spikes, deploy-correlated drops, campaign ramps, SEO decay, and platform changes. Measurement checks first, always. |
| [`channel-and-funnel-quality`](skills/channel-and-funnel-quality/SKILL.md) | Volume × engagement × conversion as a matrix. Vanity-traffic detection. Expected drop-off ranges per funnel step type. Mix-shift handling. Industry-specific benchmarks. |
| [`metric-context-and-benchmarks`](skills/metric-context-and-benchmarks/SKILL.md) | What's a good bounce / engagement / duration / CVR / churn / LTV:CAC / activation, by model. When each metric lies. Minimum sample sizes before trusting a rate. |
| [`event-schema-author`](skills/event-schema-author/SKILL.md) | Authors `event-schema.yaml` from existing `track()` calls. A portable, typed declaration of every product analytics event the codebase fires. The CLI generates a TypeScript type so call sites are autocompleted and type-checked at build time. Vendor-neutral; works with any analytics SDK. |
| [`experiment-result-reader`](skills/experiment-result-reader/SKILL.md) | Read a running A/B test honestly. Pulls per-variant exposure and conversion counts, computes lift, applies sample-size and sequential-testing discipline, checks for mix-shift and sample-ratio mismatch, and returns a verdict with caveats instead of a false-positive. Reads the experiment from the `experiments:` section of `event-schema.yaml` when present. |
| [`bayesian-experiment-reader`](skills/bayesian-experiment-reader/SKILL.md) | Bayesian counterpart to `experiment-result-reader`. Beta-Binomial for CVR, Normal-Normal for continuous. Returns P(variant beats control), credible intervals, and expected loss. Ship-decision rule: ship if P(better)>95% AND expected loss < tolerance, instead of "stat sig yes/no." |
| [`sequential-monitoring`](skills/sequential-monitoring/SKILL.md) | mSPRT and confidence sequences for honest peeking. Answers "can I call this early?" without α-inflation from looking at the dashboard every day. Pairs with both experiment readers. |
| [`causal-query-classifier`](skills/causal-query-classifier/SKILL.md) | Pearl's three-rung hierarchy as a query classifier. Tags every analytics question as rung-1 (association), rung-2 (intervention), or rung-3 (counterfactual). Refuses to escalate rung-1 findings into rung-2 recommendations without an identification strategy. |
| [`causal-dag-builder`](skills/causal-dag-builder/SKILL.md) | Emits a Mermaid causal DAG before answering "did X cause Y" on observational data. Applies the back-door criterion to pick the adjustment set. Surfaces confounders, mediators, and colliders explicitly instead of "controlling for everything." |
| [`causal-evidence-checklist`](skills/causal-evidence-checklist/SKILL.md) | Bradford Hill's 9 viewpoints as a rubric before recommending a rollback/ship action. Refuses "high confidence" verdicts when fewer than ~5 criteria pass. |
| [`anomaly-detection-time-series`](skills/anomaly-detection-time-series/SKILL.md) | STL decomposition, Bayesian online changepoint detection, Prophet, quantile regression, SPRT, Granger causality. Use when `traffic-change-diagnosis` fingerprints match ambiguously, the change date is contested, or the user asks "is this real?" |

## Install

### Claude Code (recommended)

```bash
/plugin marketplace add clamp-sh/analytics-skills
/plugin install analytics-skills@clamp-sh
```

Skills auto-load and become available as `/analytics-skills:<name>` when the task matches.

### Other clients

- **Cursor / Copilot / any [Skills-spec](https://skills.sh) client**: `npx skills add clamp-sh/analytics-skills`
- **Codex CLI**: `git clone https://github.com/clamp-sh/analytics-skills.git` then `cp -R analytics-skills/skills/* ~/.codex/skills/`
- **claude.ai**: download per-skill zips from the [latest release](https://github.com/clamp-sh/analytics-skills/releases) and upload via **Settings → Features → Skills**
- **Manual (any Claude Code, no plugin)**: `git clone` then `cp -R skills/* ~/.claude/skills/`

## Usage

These are model-invoked skills. You don't need to call them by name; just ask real analytics questions and Claude will load the relevant skill.

**First run, on a new project:**

```
Set me up. I want the skills calibrated to my business.
```

This loads `analytics-profile-setup`, walks a 5-minute interview, and writes `analytics-profile.md` to the repo root. Every subsequent question gets industry-aware answers.

**After setup, ask real questions:**

```
Traffic dropped 30% on Tuesday. What happened?
```

Loads `traffic-change-diagnosis`. Walks the hypothesis tree (measurement → time-shape → channel → cohort → content), pulls numbers from your analytics source, returns a diagnosis. Not a screenshot of a chart.

```
Is our signup funnel broken? Pricing → checkout is converting at 14%.
```

Loads `channel-and-funnel-quality` and `metric-context-and-benchmarks`. Compares against expected step drop-off, slices by cohort, flags whether 14% is low, normal, or suspicious given your sample size and model.

```
Our bounce rate is 68%. Is that bad?
```

Loads `metric-context-and-benchmarks`. Handles the GA4 vs UA definition gotcha, looks up the relevant page-type range, flags the sample-size caveat if needed.

## Supported analytics platforms

The skills are platform-neutral; per-platform MCP invocations live in [`tool-maps/`](tool-maps/). One file per supported analytics tool, all covering the same canonical 17-row workflow taxonomy.

| Tool | Tool-map | Surface |
|---|---|---|
| [Amplitude](https://amplitude.com) | [`amplitude.md`](tool-maps/amplitude.md) | `query_amplitude_data` covers most rows; cohorts and experiments are dedicated tools |
| [Clamp](https://clamp.sh) | [`clamp.md`](tool-maps/clamp.md) | dedicated MCP tool per row of the canonical taxonomy |
| [GA4](https://analytics.google.com) | [`ga4.md`](tool-maps/ga4.md) | `run_report` for aggregate rows; funnels and cohort retention not exposed by the wrapper |
| [Mixpanel](https://mixpanel.com) | [`mixpanel.md`](tool-maps/mixpanel.md) | `Run-Query` types (insights, funnels, flows, retention) |
| [PostHog](https://posthog.com) | [`posthog.md`](tool-maps/posthog.md) | Trends/Funnels/Retention/Paths insights plus HogQL |

The full row-by-row coverage matrix is at [`tool-maps/capability-matrix.md`](tool-maps/capability-matrix.md). `analytics-profile-setup` records the active platform in `analytics-profile.md` under `tool_map:`; downstream skills load the matching tool-map automatically.

Using a different analytics source? The method still applies. Add a tool-map for it (see [`tool-maps/README.md`](tool-maps/README.md) for the template).

## Contributing

Issues and PRs welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for how to add a skill and the style conventions we follow.

## License

MIT. See [LICENSE](LICENSE).

## References

Frameworks and benchmarks the skills lean on:

- **Method**: Minto's MECE and Pyramid Principle (1985), Simpson (1951) for the mix-shift trap, standard 95% CI sample-size rules for noise-vs-signal calls.
- **Benchmarks**: [Unbounce 2024](https://unbounce.com/conversion-benchmark-report/) (57M conversions), [Wordstream 2025](https://www.wordstream.com/blog/ws/2025/05/21/search-advertising-benchmarks), [Ruler 2025](https://www.ruleranalytics.com/blog/insight/conversion-rate-by-industry/) (100M+ data points by industry), [Littledata Shopify 2023](https://www.littledata.io/benchmarks/shopify), [Imperva *Bad Bot Report*](https://www.imperva.com/resources/resource-library/reports/bad-bot-report/), [Mixpanel](https://mixpanel.com/blog/product-benchmarks/), [ChartMogul](https://chartmogul.com/reports/saas-benchmarks-report/), [David Skok SaaS Metrics 2.0](https://www.forentrepreneurs.com/saas-metrics-2/).
- **Definitions**: GA4 metric definitions taken from [Google's docs](https://support.google.com/analytics/answer/12195621) (note: GA4 bounce rate is *not* the UA single-pageview bounce rate).
