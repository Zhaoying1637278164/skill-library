---
type: regex
target: last_message
match: not_contains
weight: 0.5
---
!
