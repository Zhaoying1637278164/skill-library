#!/usr/bin/env bash
# Checks the repo is a valid plugin + skills.sh source and that no origin residue is left.
set -uo pipefail
cd "$(dirname "$0")/.."
fail=0
err() { echo "FAIL: $*" >&2; fail=1; }

# 1. Every skill dir has a SKILL.md whose name matches the directory and has a description.
for dir in skills/*/; do
  name=$(basename "$dir")
  f="$dir/SKILL.md"
  [ -f "$f" ] || { err "$dir has no SKILL.md"; continue; }
  fm_name=$(sed -n '2,20p' "$f" | grep -m1 '^name:' | sed 's/^name:[[:space:]]*//; s/^"//; s/"$//')
  [ "$fm_name" = "$name" ] || err "$f frontmatter name '$fm_name' != dir '$name'"
  sed -n '2,20p' "$f" | grep -q '^description:[[:space:]]*.\+' || err "$f has no description"
  # skills.sh drops a skill whose frontmatter is not valid YAML (an unquoted ": " inside a value does it).
  python3 - "$f" <<'PY' || err "$f frontmatter does not parse as YAML"
import sys, re
text = open(sys.argv[1]).read().split('\n---', 2)[0].split('\n', 1)[1]
try:
    import yaml; yaml.safe_load(text)
except ImportError:
    for line in text.split('\n'):
        m = re.match(r'^([\w-]+):\s*(.*)$', line)
        if m and not m.group(2).startswith(('"', "'")) and ': ' in m.group(2):
            sys.exit(1)
PY
done

# 2. Agent paths in plugin.json exist and the generated agent matches its source.
for p in $(python3 -c 'import json;print(" ".join(json.load(open(".claude-plugin/plugin.json")).get("agents",[])))'); do
  [ -f "$p" ] || err "plugin.json agent path missing: $p"
done
scripts/sync-assets.sh --check || err "shared assets are out of sync"
scripts/test-persona.sh || err "persona synchronization fixtures failed"
python3 -B -m unittest discover -s scripts -p 'test_reliability.py' || err "reliability fixtures failed"
python3 -B scripts/verify_packages.py || err "standalone packages failed"
python3 -B evals/workflows/run.py --check || err "workflow definitions failed"
python3 -B -m unittest discover -s evals/workflows -p 'test_*.py' || err "workflow grader fixtures failed"
scripts/test-ward.sh || err "PR attendance fixtures failed"
scripts/test-scry-map.sh || err "scry map closeout fixtures failed"
scripts/test-build-tickets.sh || err "build ticket adapter fixtures failed"
scripts/test-open-pr.sh || err "open-pr conflict fixtures failed"
scripts/test-ultima.sh || err "ultima audit fixtures failed"
scripts/test-leyline.sh || err "leyline conformance fixtures failed"
python3 -B -m unittest discover -s evals/semantic -p 'test_*.py' || err "semantic eval runner fixtures failed"

# 2a. Every output style has the frontmatter the Claude Code picker needs.
for f in output-styles/*.md; do
  [ -e "$f" ] || continue
  for key in name description keep-coding-instructions; do
    sed -n '2,10p' "$f" | grep -q "^$key:[[:space:]]*.\+" || err "$f frontmatter lacks $key"
  done
done

# 2b. The plugin prefix agrees across both manifests and every /prefix:skill in the README exists.
python3 - <<'PY' || err "plugin naming is inconsistent"
import json, pathlib, re, sys
plugin = json.load(open(".claude-plugin/plugin.json"))
market = json.load(open(".claude-plugin/marketplace.json"))
names = [e["name"] for e in market["plugins"]]
bad = []
if plugin["name"] not in names:
    bad.append(f"plugin.json name {plugin['name']!r} is not in marketplace.json plugins {names}")
prefix = plugin["name"]
dirs = {d.name for d in pathlib.Path("skills").iterdir() if d.is_dir()}
readme = pathlib.Path("README.md").read_text()
for used_prefix, skill in sorted(set(re.findall(r"/([a-z0-9-]+):([a-z0-9-]+)", readme))):
    if used_prefix != prefix:
        bad.append(f"README uses /{used_prefix}:{skill} but the plugin prefix is {prefix}")
    elif skill not in dirs:
        bad.append(f"README uses /{used_prefix}:{skill} but skills/{skill} does not exist")
for name in sorted(dirs):
    if f"/{prefix}:{name}" not in readme:
        bad.append(f"skills/{name} is never shown as /{prefix}:{name} in README.md")
for line in bad:
    print(line, file=sys.stderr)
sys.exit(1 if bad else 0)
PY

# 3. Manifests parse.
for j in .claude-plugin/plugin.json .claude-plugin/marketplace.json skills/scan/references/findings-schema.json skills/ultima/references/candidates-schema.json; do
  python3 -c "import json,sys;json.load(open('$j'))" 2>/dev/null || err "$j is not valid JSON"
done

# 4. No residue from the repos these skills were originally forked from, no em dashes in prose.
banned='EveryInc|compound-engineering|\bce-[a-z]|\blfg\b|babysit|julik|\bcora\b|pr-comment-resolver|Comment Sicko|Sicko|pr-feedback|MUST KILL|pstack|safe_auto|/how\b|/why\b|/architect\b'
hits=$(grep -rnE "$banned" skills agents CLAUDE.md 2>/dev/null || true)   # README names the origins on purpose
[ -z "$hits" ] || { err "origin residue found:"; echo "$hits" >&2; }
# dispel/SKILL.md and scan voice.md quote dashes as examples of what not to write.
dashes=$(grep -rn --include='*.md' -e '—' -e '–' skills agents output-styles README.md CLAUDE.md 2>/dev/null \
  | grep -v -e 'skills/dispel/SKILL.md' -e 'skills/scan/references/voice.md' || true)
[ -z "$dashes" ] || { err "em/en dashes found:"; echo "$dashes" >&2; }

# 4b. A bundled script is invoked by its literal path. A worktree-isolated session refuses
# an interpreter whose script path is hidden behind a shell variable.
indirect=$(grep -rnE '(bash|sh|python3?|node) +"?\$[A-Za-z_][A-Za-z0-9_]*/' --include='*.md' skills agents 2>/dev/null \
  | grep -v '\$VAR/script\.sh' || true)   # the convention paragraphs quote the refused form
[ -z "$indirect" ] || { err "script path behind a shell variable, use \"<SKILL_DIR>/...\":"; echo "$indirect" >&2; }

# 5. Scripts are executable and parse.
for s in skills/*/scripts/* scripts/*.sh; do
  [ -e "$s" ] || continue
  [ -x "$s" ] || err "$s is not executable"
  head -1 "$s" | grep -q bash && { bash -n "$s" || err "$s does not parse"; }
done

# 5c. Every scan persona has the shared shape and its stub names its own file.
for p in skills/scan/references/personas/*.md; do
  stem=$(basename "$p" .md)
  for h in '## Mandate' '## Where to look' '## Not a finding' '## Evidence bar' '## Output'; do
    grep -qF "$h" "$p" || err "$p lacks '$h'"
  done
  grep -qF "\"reviewer\": \"$stem\"" "$p" || err "$p stub does not name $stem"
done

# 5d. Every ultima lens has the shared shape and its stub names its own file.
for p in skills/ultima/references/lenses/*.md; do
  stem=$(basename "$p" .md)
  for h in '## Mandate' '## Where to look' '## Not a finding' '## Evidence bar' '## Output'; do
    grep -qF "$h" "$p" || err "$p lacks '$h'"
  done
  grep -qF "\"lens\": \"$stem\"" "$p" || err "$p stub does not name $stem"
done

# 6. Claude Code's own validator, when available.
if command -v claude >/dev/null 2>&1; then
  claude plugin validate . >/dev/null 2>&1 || { claude plugin validate . >&2; err "claude plugin validate failed"; }
fi

[ $fail -eq 0 ] && echo "ok" || exit 1
