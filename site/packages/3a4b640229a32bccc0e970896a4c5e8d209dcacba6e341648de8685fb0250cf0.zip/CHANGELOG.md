# Changelog

## 0.36.2

- Bind reused authorization to the repository and target it covers, with the same allowed actions. Simplify repeated read-only request guidance. Reject masked local verification results and prohibited PR-message attempts after a rejected repair push in the offline workflow grader. Add regressions and a changed-target scope scenario.

## 0.36.1

- Honor user instructions and prior authorization consistently across skill workflows. Reuse supplied review actions, slices, and triage decisions without requiring special tokens or repeated confirmation. Keep local review fixes separate from permission to commit or push. On a rejected repair push, preserve the local commit and leave fix threads open for separate history recovery. Add focused workflow scenarios and offline grader coverage.

## 0.36.0

- Add optional Performance & Delivery audits with separate performance and build/deployment specialists. Discover execution and release boundaries without running project commands, distinguish source cost hypotheses from attributable existing measurements, and preserve examined-scope gaps in the offline report. Add synthetic cost and release fixtures with independent specialist evaluation.

## 0.35.0

- Add optional Security audits to `ultima`, with focused access-control, input-boundary and sensitive-data specialists. Profile security surfaces, verify enclosing controls and source traces, preserve qualified static claims, redact sensitive evidence, and show coverage in the offline report. Security findings become planning or decision briefs. Add synthetic boundary fixtures and independent specialist evaluation.

## 0.34.1

- Trim repeated Ultima report summaries. Keep category status in Coverage, show totals once, and omit generic recommendation text when the ranked work list already explains the order.

## 0.34.0

- Expand `ultima` to whole-project audits with UX, Architecture, and Data & Reliability categories. Profile backend and monorepo scopes, verify shared system context, and dispatch specialists for system boundaries, data integrity, and failure recovery alongside the frontend lenses. Accept sourced flow traces for single boundary defects, rank impact separately from confidence, preserve stable finding IDs, and distinguish accepted decisions from violations or decisions needing review. The offline report adds keyboard-accessible category and confidence controls with coverage status and printable findings. Structural changes become migration briefs; immediate fixes cover the entire verified pattern. Add backend, trace, reconciliation, and report regressions.

## 0.33.0

- Add `leyline`, which checks that a project gives agents an honest way to find a feature, run the app, and report what happened. The project owns a control CLI and a feature map; `leyline` holds them to the `control/0` contract in `references/contract.md`. `conform.sh static` reads the `Control:` line, the control skill, feature and scenario records, literal `scenario(...)` registrations in tests, and break patches without running project code. `conform.sh report` rejects a run report whose status and exit disagree, that passes with zero executed or unexecuted expected cases, or that passes with a missing prerequisite or a changed checkout. `conform.sh dynamic --trust` runs the project's CLI in a worktree of HEAD and probes list, describe, an unknown id, a baseline run, a declared break patch that must fail naming its scenario, the restored run, and two concurrent runs. Every probe input comes from HEAD, and a break patch that fails to revert blocks the restore and parallel probes. A fake control CLI covers each violation in `scripts/test-leyline.sh`.

## 0.32.1

- Describe the plugin, marketplace, and README by what the skills do instead of whose they are.

## 0.32.0

- `scry` ends every session by shipping the files it wrote. Stage 1 records the working tree before any write. The new Stage 4 compares against it, lists the research notes, glossary and ADR edits, owning docs, prototypes, and local ticket files the session left behind, and asks whether to open a pull request for them. On a yes it branches off the default branch when needed, commits only those paths so the user's own changes stay out, pushes, opens or updates the pull request with no closing keyword, and comments the link on the ticket, or on the map when charting. `pr` skips the question and `no-pr` leaves the files uncommitted. Prototypes stay out of the pull request unless the user adds them.

## 0.31.1

- Reject Git index changes in workflow eval cases that disallow commits, including staging an otherwise allowed edit or unstaging pre-existing user work. Add regressions for both cases.

## 0.31.0

- Distinguish visual demonstrations from executed checks and unverified claims in build and PR workflows. Preserve proving-command failures when rendering output and report stale or unavailable evidence accurately.
- Quote temporary body-file paths in GitHub issue creation dry runs so paths containing spaces remain usable.
- Centralize shared-asset ownership and synchronization, verify all standalone skill payloads, and add offline regression coverage plus an optional isolated workflow eval pilot for maintainers.

## 0.30.0

- Ground roadmaps in project scope and existing work, explain milestone priorities, and require outcome evidence for completion. Reuse clear existing-work matches before proposing new planning, report unresolved associations, and add a verifying state for missing proof. Replace the fixed report table and empty fields with a concise assessment. Identify roadmaps by pointer or label while retaining legacy marker compatibility. Add scenario-based roadmap regressions.

## 0.29.2

- Add an optional maintainer tool to grade saved prose-skill outputs with Jev, with synthetic seed cases and offline tests. Reports preserve probabilities and token usage. Pilot findings document missed scope changes; installed skills remain unchanged and live grading stays outside CI.

## 0.29.1

- Fix roadmap creation with a dedicated label and bundle the map frontier reader for standalone installs. Keep roadmap workflow instructions in stage-loaded references, reuse supplied decisions and authorization, and read project documents only to resolve relevant gaps. Shorten roadmap and settings discovery descriptions.

## 0.29.0

- Add `vision`, a roadmap above the ticket level. The roadmap is one tracker issue marked `Work kind: roadmap` with a destination and ordered milestones. Maps and build efforts point up at it with a `Milestone:` line in their own bodies, so closing them writes nothing to the roadmap and two sessions finishing at once cannot collide. `vision` is the only writer: it charts the roadmap through a milestone-grain interview, and on every later run derives each milestone's status (`planned`, `deciding`, `building`, `done`) from the linked issues, rewrites the body under the same expected-body guard scry uses, and reports the current milestone, what is left, unattached work, and one prompt to start next. `add`, `done`, `reopen`, and `order` edit the milestones. No dates, no estimates.
- `scry` asks which milestone a new map serves when the repo has a roadmap and writes the line into the map's Notes. `conjure` copies it into the build parent. `portal` shows a Roadmap row and routes to `vision` when the board is otherwise clear. `attune roadmap` sets the `Roadmap:` pointer line, and `setup-mana` offers the skill at the end.

## 0.28.0

- Branch names no longer carry the skill's name or the user's login. `cast` used to create `cast/<id>-<slug>` from the default branch and keep whatever branch a worktree tool handed it, which is how `cast/62-macos-14-x64-exclusion` and `frankieramirez/portal-59` ended up on pull requests. The name now comes from a `Branches:` line in the `## Agent skills` block, `<id>-<slug>` when the line is absent, so the same tickets give `62-macos-14-x64-exclusion` and `59-<slug>`. A tool-made branch that has no commits of its own and no upstream is renamed to the pattern before the first edit; one with commits or a remote is left alone. `attune branches` sets or removes the line. `scan` and the pull request closing line read the ticket id from the start of the branch name after any prefix, so older `cast/` branches still resolve.

## 0.27.1

- Make `portal` honor recommendation-only requests and prior handoff authorization. Route closed targets before workflow labels, read unresolved PR threads and complete check state, and use question tools only when permitted. Split board and target routing into stage-loaded references, defer lower-priority detail, and report only inspected context for named targets. Shorten its discovery description.

## 0.27.0

- Add `portal`, a read-only router. Run it with nothing and it reads the current branch, open maps and their frontiers, open build efforts and their members, the oldest ready ticket, and the triage inbox, then names one skill and one ticket and asks whether to step through. On a yes it reads that skill's own SKILL.md and follows it with the ticket as the argument, so the routed skill makes the first write. Run it with an issue id and it classifies that issue (map, map ticket, build effort, ready ticket, blocked ticket, waiting on a person, untriaged, pull request, closed) and routes it the same way. `go` skips the question. Build order wins over the global ready queue, a ticket you already hold comes first, and a blocked ticket routes to its first open blocker.
- `tickets.sh` gains `blocked ID`, which prints the open blockers of an issue one per line and exits 1 when there are none, on GitHub through the dependencies API with the `Blocked by:` line as the fallback, and on Linear and Jira through their relations. Portal and the build progress checks read it instead of guessing from the body.
- `scry` no longer charts a map from build work. Given an issue that carries `Work kind: build`, a `Build parent:` line, or the ready label, it says what the issue is and hands over the implementation or progress prompt instead of seeding a new map from it.

## 0.26.1

- `cast` now ends in a rendered table instead of a wall of text. The report template was a fenced block of `Key: value` lines, so the final response came out as preformatted text that a terminal shows as one unformatted blob, and the runs that did look good were the model reformatting on its own. The template is markdown now: a heading, a two-column table of the fixed fields, and the `Build effort` and `Next step` lines under it, with one line per cell and links left bare so they stay clickable.

## 0.26.0

- `dispel` no longer invents facts to replace the wording it strips. Asked to rewrite prose sitting next to a code block, it read a constant out of the code and documented the schedule that constant produces, in 3 of 3 runs, where the same model without the skill did so in 0 of 3. The rules told it to replace vague wording by naming the mechanism or the number and never said what to do when the source supplies neither. A new Fidelity section scopes the substitution rules to facts the source states, makes exempt text read-only in both directions, and adds a self-check for anything carried out of it. After the change the same case is clean in 3 of 3 runs. The PR description case moved the same way, from inventing a key-rotation reason the prompt never gave in 3 of 3 runs to stating the behavior without a reason in 3 of 3, while the same model without the skill still invents it every time.
- Make the eval suite's invention graders deterministic. `no-invented-mechanics` and `no-invented-rationale` were LLM judges whose verdicts flipped on wording that did not differ in substance, which hid the regression above behind register scores. Both are regex now, matching `no-invented-numbers`. They catch less, and what they catch is stable across runs.

## Unreleased

- Add the `dispel` eval suite under `evals/`: six cases that expect the skill to fire and two negative cases that expect it to stay out of the way. Run artifacts under `evals/results/` stay untracked. No change to shipped skill behavior, so no version bump.

## 0.25.3

- Rename grilling to interrogation in scry and sift, with `interrogate.md` references and the `scry:interrogation` ticket type. Existing `scry:grilling` tickets remain readable.

## 0.25.2

- Ultima makes report delivery unconditional before Stage 6, including explicit action modes. The absolute path and browser-opening command fallback also precede those actions.

## 0.25.1

- Ultima delivers a clickable report link before asking what to do next, repeats it in the action question, and opens a local preview when supported. Explicit action modes also receive the report before proceeding. Delivery explains that reports use temporary storage.

## 0.25.0

- Completed maps save an actionable handoff. Implementation gets a separate build parent with resumable ticket filing, legacy ticket reuse, and a first-ticket prompt. Build sessions and parent revisits check delivery evidence before closeout, keeping efforts open while PRs await review. Tracker adapters support build membership and guarded parent updates, including local fallback. Build markers and membership links are read the same way when a body was edited in the GitHub web UI and carries CRLF line endings.

## 0.24.0

- Add `ultima` to audit a whole frontend codebase instead of a diff. Four read-only lenses look for repeated patterns: raw values where design tokens exist, screens with no loading, empty, or error state, elements the keyboard cannot reach, and component props that mirror their implementation. A bundled script profiles the checkout, merges and ranks what the lenses find against recent git churn, and renders a self-contained HTML report with no script tag and every quoted line escaped. The report follows a dark Claude Design layout: the mana wordmark, count tiles, lens status tiles, a ranked list with strength bars, cards with an accent line and token swatches, and a Start here block that names what to fix first; the Strong and Moderate filter tabs are CSS only. The skill then asks whether to report only, file one ticket per strong candidate through the shared tracker script, or fix the top candidate on the current branch after a printed five-check walk.

## 0.23.1

- Cast automatically audits comments added or modified during implementation before its spec check. The bundled reviewer preserves protected comments, keeps repairs inside the ticket, and requires fresh validation after cleanup edits. Runs without changed code comments skip the pass.

## 0.23.0

- Add `ward` to attend an open PR until it merges or closes. It handles later review feedback and branch-caused CI failures, validates and pushes repairs, and keeps watching after green checks. Private state remembers handled feedback, two repair attempts per recurring issue, and one justified flaky rerun per head across invocations. It posts no PR comments and stops for conflicts or human decisions. Existing one-pass feedback and publishing workflows keep their behavior.

- Simplify ward to one atomic ledger and exact feedback acknowledgments. Remove the readiness classifier, per-poll workflow lookup, and duplicate thread helper. Fetch workflow details only when diagnosing a failure, and use the post-push snapshot to resume attendance.

## 0.22.1

- Cast reconsiders the implementation from first principles before committing, challenges weak assumptions, and prefers deletion before simplification. Changes need a concrete benefit within scope; a clean pass leaves good work alone instead of forcing every single-consumer helper or interface to be removed.

## 0.22.0

- PR shipping checks for conflicts against the fetched base before writing and verifies GitHub mergeability afterward. Conflicts block ready PR creation, drafts can preserve blocked work, and unknown results stay explicit. Cast resolves conflicts within the implementation scope and refreshes validation and proof; reveal reports a concrete resolution handoff.

## 0.21.2

- Mend pushes completed changes by default after successful checks when invoked directly, including clean merges. It honors requests to hold changes locally and asks when the push destination or a history rewrite needs a decision. Delegated resolutions return to the caller unless pushing is authorized, and the report includes the push outcome.

## 0.21.1

- Scry checks parent-map closeout when resuming and after recording work, including charting research. It closes maps once all children are closed and the destination is reached with no unresolved in-scope fog, records a completion note, and explains what keeps unfinished maps open. New map commands enumerate all children and guard parent closure against open tickets or failed reads; an empty frontier is no longer treated as proof of completion.

- Scry map body updates can guard against a stale snapshot and expose a raw body read for closeout. The guard rejects missing snapshots, read failures, and concurrent edits before writing, while documenting the residual read/write race.

## 0.21.0

- Scan reads the pull request a second time. Bots comment while the reviewers run, so a review that harvested feedback only at the start missed whatever CodeRabbit posted in the meantime and the user had to run remedy afterward to pick it up. The new items go through the same Lore Bard verification, merge gates, and validator as everything else, and the report says which findings arrived mid-review. Fix mode and comment mode check once more before acting, since the question at the end of a review can sit for a while: fix mode adds anything new to its queue, and comment mode stops posting a point a bot already made.

## 0.20.1

- Prompt audit against the current model generation. Dropped two anti-laziness boosters from remedy's judgment rule and rubric, the findings cap on Havoc Demon Hunter's quick depth, a reinforcement sentence in scan's execution spine, the scolding phrasing in Lore Bard's check-failed rule, and a version pin in the scry GitHub operations note. The reviewer template no longer tells subagents that long `why_it_matters` entries are truncated downstream, since the merge script keeps the longest one and never truncates.

## 0.20.0

- Mend takes a pull request number or URL, a branch, or `base:<ref>`, and starts the merge when nothing is in progress: it fetches the base, merges it into the current branch, and resolves the conflicts through the existing stages. The PR's head must be the checked-out branch, the tree must be clean, and a clean merge stops with the merge commit reported. A bare `/mend` still refuses to start anything.

## 0.19.3

- Remedy loads the shared verifier checks before choosing inline or delegated verification. Single-item and fallback runs now check for unnecessary abstractions with the same rules as multi-item runs.

## 0.19.2

- Building, review fixes, and applied findings use the smallest shape that satisfies the ask. A helper, option, or abstraction needs a consumer that exists now, which matches the maintainability reviewer's existing rule against demanding one for variants that may arrive later. Cast names the rule as YAGNI, checks the diff for single-consumer shape before committing, and writes one plain line when one line does the job.

## 0.19.1

- Skills write the bundled script's absolute path into the command instead of setting `SKILL_DIR` first. A worktree-isolated or sandboxed session refuses `bash "$VAR/script.sh"`, because it cannot resolve the path to read the script, so every skill that ran a bundled script lost turns to a refusal before falling back to the literal path. The path is now a `<SKILL_DIR>` placeholder the model substitutes.

## 0.19.0

- The plugin ships Archmage as a Claude Code output style. It appears as `mana:archmage` under `/config`, Output style, keeps the coding instructions, and stays on for every turn of the session. `scripts/sync-persona.sh` generates `output-styles/archmage.md` from the attune references, and `scripts/link-local.sh` links it for local development.
- New `attune style` setting for hosts without an output style. `attune style archmage` writes `docs/agents/archmage.md` and a `Style:` line in the `## Agent skills` block that tells Codex, Cursor, Copilot, and Gemini CLI to read the voice at session start; `attune style off` removes both. Skills keep the voice on after a workflow when the line is set, and setup reruns preserve it.
- The voice guide no longer ends the persona itself; the setting that loaded it says how long it lasts.

## 0.18.1

- Persona synchronization preserves text outside its managed block and rejects symlink destinations before writing. Fixtures cover blank-line preservation and external targets.
- Attune records the project root before reading settings and uses it for later edits. Persona references name their loading stage, and the narration exception follows the prose conventions.

## 0.18.0

- Add an opt-in Archmage persona inspired by Khadgar from Warcraft. `attune persona archmage` enables immersive lead-agent narration for the project; `attune persona off` removes the setting. Persona configuration works without a tracker, and setup reruns preserve existing preferences.
- Every skill bundles the same voice reference and reads the project preference at invocation. Individual installations work without sibling skills. Replies written as the user and structured outputs retain their contracts; specialists keep their own identities.
- `scripts/sync-persona.sh` synchronizes persona references and activation sections, and validation checks for drift. Plain-language editing allows intentional character dialogue in persona narration while preserving deliverable style and punctuation rules.

## 0.17.1

- Skills honor explicit user instructions and decisions already supplied in the conversation, and explain any skill rule that still requires a pause. A rule a skill states with never, or as read-only, stays in force whatever the conversation says. Setup reuses the selected tracker, and under `you-pick` with nothing detected it reports the missing choice and stops instead of asking; comment cleanup reuses authorization for constraint enforcement.
- Review and feedback workflows collect asynchronous agent results through the host's supported wait mechanism. Reviewer model routing uses available tiers and inherits the session model when an override is unavailable.
- Building applies TDD to testable behavior changes and reuses successful validation when no later edit or unresolved concern calls for another run. Required project checks still run.
- Ghost reads `.mimic.md` on refresh and preserves punctuation in verbatim samples. Reply drafting keeps its reply-only output contract, and prose style rules exempt verbatim evidence.

## 0.17.0

- `setup-mana` asks one question: where the tickets live. GitHub Issues, Linear, Jira, markdown files under `.scratch/`, or a tracker described in a paragraph. The question is asked every run, and the detected answer is listed first and labelled as detected. Detection now ranks its signals and puts a GitHub remote last, since nearly every repo has one and that alone is not evidence of where the tickets are. A ticket key prefix in recent commit subjects (`ENG-12`) is a Linear or Jira signal.
- `setup-mana` writes the tracker file even when the key or the token is missing. The report marks the check unverified and names the variable to set, instead of stopping on that tracker. It never falls back to a tracker the user did not pick.
- `setup-mana` records `Validation:` only when the detected command runs clean, and never asks about it. It writes no `Proof:`, `Domain docs:`, or `Peer reviewer:` line, so a review still sends nothing off the machine unless someone asks for it. Triage labels default to the role name, and `docs/agents/triage-labels.md` is written only when the repo already has a label that means the same thing. With neither `CLAUDE.md` nor `AGENTS.md` present, it creates `AGENTS.md` without asking.
- New skill `attune` changes one setting after setup: the triage label names, the validation command, proof capture, domain docs, a second opinion reviewer CLI, the worktree files, whether pull requests enter triage as requests, the tracker key, and which file holds the block. Run bare it lists every current setting and which skills read it. `attune <setting> <value>` writes one and asks nothing. `attune key` is the repair path for a setup run that wrote the config before the key was there. Switching trackers stays in `setup-mana`.
- `attune` carries `tickets.sh` for `check` and `ensure-labels`, plus a copy of the label template. `.worktreeinclude` and `orca.yaml` move out of setup into `attune worktree`.

## 0.16.0

- `remedy`: on a large batch (more than 12 new items, or more than 6 files) read-only scouts gather the evidence per file cluster in one foreground batch, and the orchestrator still judges every item from their returns. `references/scout-prompt.md` is the brief; the rubric says which scout field feeds which verdict.
- `remedy`: a verifier reads the combined diff against every fix-list item before the validation run: site changed, ask answered, in the file's conventions, and no hunk nobody asked for. A miss goes back to the same fixer once with a corrected note, then to the skip-list with the edit reverted. `references/verifier-prompt.md` is the brief; a single fix is checked inline.
- `remedy`: every run writes `fetch.json`, `items.json`, `summary.md`, and `metadata.json` under `/tmp/remedy-<uid>/<run-id>/`. The next run on the same PR reads them: a reopened thread, a `needs-human` still waiting, and a comment already fixed are named instead of re-judged.
- `remedy`: fixers dispatch as one foreground batch sized to the host's agent cap, with an explicit one-at-a-time path when the host cannot spawn subagents.

## 0.15.0

- `scan`: reviewer personas are class specializations with one shared file shape: Protection Warrior (correctness), Subtlety Rogue (security), Havoc Demon Hunter (adversarial), Marksmanship Hunter (testing), Fire Mage (performance), Restoration Shaman (reliability), Retribution Paladin (project standards), Unholy Death Knight (data migration), Balance Druid (maintainability), Demonology Warlock (API contract), Windwalker Monk (frontend races), Lore Bard (existing PR feedback). Two new ones: Augmentation Evoker checks that an agent can do and see what a user can, Discipline Priest checks instruction prose for hedges, contradictions, and dangling references.
- `scan`: `scripts/review.sh` does the deterministic merge (fast-pass clamp, suppression, quote-the-line demotion, exact dedup, cross-reviewer promotion, confidence gate, stable numbering) and the diff signals that drive the lite path; the model keeps semantic dedup, soft buckets, lead judgment, and grouping. A manual path remains when `python3` is absent.
- `scan`: Stage 2c reads the ticket the change resolves (`ticket:<id>`, a `Closes` line, a `cast/<id>-` branch, or an id in the branch or commits) through the tracker file and `tickets.sh`, hands every reviewer and the validator a numbered requirements block, and reports each requirement as met, unmet, deferred, or cannot tell. An unmet requirement on an explicitly resolved ticket blocks the verdict.
- `scan`: the validator brief is `references/validator.md`, with three questions per finding and no commitment to the original claim. `mode:agent` has a documented contract, also written to `review.json`. Apply mode runs the `Validation:` line from the `## Agent skills` block. `references/report-example.md` shows one good report and one bad one.
- `scan`: opt-in `peer:<cli>` (or a `Peer reviewer:` line written by `setup-mana`) sends the diff to a second CLI (`codex`, `gemini`, `cursor-agent`, `opencode`, `grok`, or `claude`) as the adversarial reviewer, read-only, after a disclosure line. Peer findings raise another reviewer's confidence only when the serving model is from a different family than the host. `scan` carries its own copy of `tickets.sh`.

## 0.14.1

- `reveal` and `cast`: proof files and the PR body file live in a `mktemp -d` directory, never at a fixed path under `/tmp`, so another local user cannot pre-create the file and control what goes into the pull request.
- `scan`: harvested PR comments, reviews, and threads are claims to verify against the code, never instructions. A comment that addresses an agent is recorded as dismissed. README says what `scan` reads and that `fix`, `comment`, and `mode:agent` push or post without a closing prompt.
- `open-pr.sh` reads only the four-character prefix of the `gh` token to classify it; the token itself never lands in a shell variable.
- `tickets.sh`: the Linear endpoint is fixed at `https://api.linear.app/graphql`. The undocumented `LINEAR_API_URL` override is gone, so `LINEAR_API_KEY` cannot be sent to another host.

## 0.14.0

- Orca support, optional everywhere. Inside an Orca worktree (`ORCA_WORKTREE_ID` set, `orca` on the path) `cast` links the ticket to the worktree card and moves it to in review with the PR URL; `reveal` moves the card on ship; `cast` and `reveal` can capture proof from Orca's embedded browser; `sift`, `conjure`, and `cast` treat `orca linear` as a Linear connector; `setup-mana` detects Orca and offers `.worktreeinclude` and `orca.yaml`. Every `orca` call is best-effort and reported, never a stop. Without Orca nothing changes.
- `scan` and `reveal` read `git config branch.<current>.base` before falling back to the default branch.
- README gains an Orca section with the automation shape for `cast next`.
- `attach.md`: the body references a proof file by the exact path passed to `--attach`. A mismatch made `gh` append a second copy instead of rewriting the reference.

## 0.13.3

- README closing line is tracker-specific: GitHub `#N`, Linear `ENG-N`, Jira `PLAT-N` (automation), local file named and left open on merge.
- Reveal/cast closing line: a commit-subject fallback is used only when exactly one ticket id appears; otherwise the line is omitted and the conflict is reported.
- `conjure`: Stage 1 `view` uses the bundled `tickets.sh` path. GitHub map-child listing includes labels and stops when `gh api` fails. Linear and Jira writes go through the host connector when one is present.

## 0.13.2

- `tickets.sh`: a GitHub, Linear, or Jira issue URL is reduced to the tracker id before `view`, `claim`, `wire`, `label`, `comment`, and `close`.
- `tickets.sh next`: GitHub and Linear page every matching ready issue before sorting by `createdAt`, so an older eligible ticket past the first 100 is not starved.
- `tickets.sh next --claim` assigns the chosen ticket, re-reads it, and releases it if it is closed, missing the ready label, or blocked. `cast next` uses that path so a parallel session cannot slip in between `next` and `claim`.

## 0.13.1

- `tickets.sh`: refuse non-HTTPS Linear and Jira URLs, and refuse redirects that change host or scheme, so Authorization is not forwarded elsewhere. Jira search pages on `nextPageToken` (Jira Cloud may omit `isLast`). `create --dry-run` leaves the body file in place and says to delete it.

## 0.13.0

- `setup-mana`: one skill that sets a repository up for the rest. Explores first, then asks in sections with a recommended answer: which issue tracker (GitHub, Linear, Jira, local files, or one you describe), which label names, what command proves the project works, and how proof gets captured. Writes `docs/agents/issue-tracker.md`, `docs/agents/triage-labels.md`, and an `## Agent skills` block in whichever of `CLAUDE.md` or `AGENTS.md` exists. Nothing is written until the tracker answers a read-only check. Secrets stay in the environment.
- Linear and Jira as issue trackers. `sift`, `conjure`, and `cast` read the tracker file, use the host's Linear or Jira connector when one is present, and otherwise pass the adapter flags to `tickets.sh`, which now speaks GitHub (`git` and `gh`), Linear (GraphQL, `LINEAR_API_KEY`), and Jira Cloud (REST, `JIRA_BASE_URL`, `JIRA_EMAIL`, `JIRA_API_TOKEN`) with the same subcommands. `scry` on those trackers follows the wayfinding prose in the tracker file. Pull requests stay on GitHub, and the closing line uses the tracker's key.
- `conjure`: turn a finished decision map, a spec, or the plan in the conversation into `ready-for-agent` issues. Each ticket is one vertical slice sized to one build session, carries an agent brief, and is wired to the tickets it waits on. Posts the build order on the map. Falls back to `.scratch/<slug>/tickets/` when the token cannot write issues.
- `cast next` claims the oldest unclaimed, unblocked `ready-for-agent` issue and builds it. Every ticket gets claimed before work, so two sessions cannot build the same one. A session that starts on the default branch creates `cast/<id>-<slug>` before any edit; nothing commits to `main`. The pull request body ends with a closing line for the ticket.
- `sift you-pick` triages without waiting, at most 10 issues per run, and never closes an issue as rejected on its own.
- `cast`, `mend`, and `remedy` run the `Validation:` command from the `## Agent skills` block before guessing a test command.
- README gains a lifecycle section: where to start, the order the skills hand off in, and the tokens that make each one safe to run on a schedule.

## 0.12.0

- `augur`: find what a change could break beyond its diff, name the one fact it is safe because of, and prove that fact by running real code. Five-rung evidence ladder; anything below "ran it" is reported as unproven. The proving script stays on disk. Inspired by the blast-radius skill in Cursor's pstack plugin (MIT), written from scratch.
- `dispel`: a plain-speech pass after the register ban. Metaphor nouns (substrate, wedge, vector, ratchet) get their concrete word, passive voice names its actor, adverbs become the number, and a sentence that could appear unchanged in another project's docs is cut. Inspired by pstack's unslop rules, written from scratch.
- `scan`: the report gains a Dismissed section listing every finding synthesis dropped and why, so the user can override it. Three lead-judgment filters run before validation: nitpick gravity, consistent with the codebase, and code the diff did not touch. The header and `metadata.json` carry base SHA, head SHA, and a `git patch-id` stamp, and a rerun on the same diff points at the earlier report. Inspired by pstack's interrogate lead-judgment notes, written from scratch.
- `remedy`: reads CI before judging. A failure in code the PR touched joins the fix list and the same push; a failure in untouched code is checked for a stale base with `git merge-base --is-ancestor`; a suspected flake gets at most one `gh run rerun --failed` after the push. Comment text never reaches a shell command as an argument or interpolation.

## 0.11.0

- `scry` files maps and tickets under its own labels, `scry:map` and `scry:<type>`, instead of the `wayfinder:*` names carried over from the loop it replaced. `ensure-labels` creates only the new set. Reads still accept `wayfinder:*`, so a map you already have walks without relabelling; that fallback goes away in a later release.

## 0.10.0

- `reveal`: open or update a pull request and put a screenshot, recording, or command-output SVG in the description via `gh --attach`. The body is a sentence plus a compact tree or structural diff a reviewer can scan. `cast` now ships the same way after a successful build (push, creating the upstream if needed). Pass `no-pr` to stop after the commit. When attach cannot run, the PR still opens and the script prints why.

## 0.9.0

- `mend` and the Weaver agent: finish an in-progress merge, rebase, cherry-pick, or revert by reading both sides of each hunk, keeping both intents when they commute, running the project's checks, and continuing the git operation. Never aborts. Inspired by the merge-conflict skill in mattpocock/skills (MIT), written from scratch.

## 0.8.2

- `cast` loads a spec path or the conversation before writing intent, stages only this session's diff, and classifies suite failures against the pre-change baseline. `map.sh` passes `--repo` on every `gh issue` and `gh label` call, and label create fails through to exit 3 unless the label already exists. `scry` examples set `GH_HOST`. `sift` will not apply a state-only override until the issue has one category.

## 0.8.1

- `map.sh`: a 403 on attach or wire writes `Part of #` / `Blocked by:` instead of aborting into a second local map. Frontier discovers children from those links and task-list lines, not every `#N` in the map body. `claim` refuses when someone else already holds the ticket.

## 0.8.0

- `scry`, `cast`, and `sift`: the planning loop I actually run. `scry` charts a GitHub map of decision tickets and walks them one at a time. `cast` builds a ready ticket on the current branch. `sift` moves the inbox through the same triage states. Inspired by the engineering skills in mattpocock/skills (MIT), written from scratch. Existing maps keep the `wayfinder:*` labels.

## 0.7.3

- `scripts/validate.sh` checks that the plugin name agrees across both manifests, that no README slash command points at a skill that does not exist, and that every skill directory is shown in the README.
- The naming convention is written down: the skill name is the spell, the description stays plain English.
- `.mimic.md` is gitignored, since `mimic setup project` writes one into whatever repo it runs in.

## 0.7.2

- The marketplace is named `frankieramirez`, so the install is `mana@frankieramirez`. A marketplace names a publisher, not a product, and it shows up where provenance is the useful thing to know. `mana` carries the brand in every slash command. The plugin name and every skill are unchanged.

## 0.7.1

- The marketplace was briefly `ark`.

## 0.7.0

- The plugin is now `mana` and the marketplace is `mana`, installed from `frankieramirez/mana`. Every skill is renamed after the spell it casts: `wringer` to `scan`, `settle` to `remedy`, `spit` to `dispel`, `be-me` to `mimic`, `scrap` to `banish`. Slash commands become `/mana:scan` and the rest. Frontmatter descriptions are unchanged in meaning, so model invocation still fires on the same plain-English triggers.
- The voice profile moves from `.be-me.md` to `.mimic.md`. Rename any existing file by hand.

## 0.6.0

- `no-comment` renamed to `settle`. The old name read like it was about code comments, which is what `scrap` does, and it named the one rule instead of the job.

## 0.5.0

- `be-me setup` and `be-me refresh`: a new Ghost agent mines the user's own writing (session messages, prompts typed to the coding agent in its local logs, PR comments, PR descriptions, commits) and returns a filled-in voice profile draft for approval. Text written by a tool under the user's name is dropped as evidence.
- `be-me setup` also feeds Ghost the user's own messages to other people, fetched by the skill since Ghost has no browser or connectors: sent messages from a connected chat workspace first, then posts from a public profile the user names. Writing addressed to a person now stays separate from writing addressed to a tool, and work sources get scrubbed before any sample reaches disk.
- `wringer` comment mode reads the voice profile when one exists.
- `scripts/sync-agent.sh` generates every agent from a table and gains `--check`.

## 0.4.0

- `address-feedback` renamed to `no-comment`.

## 0.3.0

- `deep-review` renamed to `wringer`.

## 0.2.0

- `decomment` renamed to `scrap`.

## 0.1.1

- `spit`: quote the frontmatter description so skills.sh discovers the skill.

## 0.1.0

First release.

- `deep-review`: multi-reviewer code review with risk-selected personas.
- `address-feedback`: resolve PR review feedback by fixing code, with no PR comments.
- `spit`: strip the essay register from anything a person will read.
- `be-me`: reply to a message as the user, in their voice, without the AI tells.
- `scrap` + Comment Reaper agent: remove comments that do not earn their place.
