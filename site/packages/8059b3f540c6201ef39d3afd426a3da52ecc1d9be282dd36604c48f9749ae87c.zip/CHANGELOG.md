# Changelog

All notable changes to this project will be documented in this file. Format based on Keep a Changelog.

## [2.10.4] — 2026-06-17

Adds Cursor marketplace support. The plugin can now be listed on cursor.com/marketplace alongside the existing Claude Code listing — it ships a Cursor manifest, declares the hosted SE Ranking MCP server for Cursor, carries a plugin logo, and is guarded in CI against the same class of schema and version errors as the Claude manifests.

### Added
- **Cursor plugin packaging** — `.cursor-plugin/plugin.json` (Cursor manifest) and `mcp.json` (declares the hosted SE Ranking MCP server at `https://api.seranking.com/mcp`, OAuth, auto-detected by Cursor). The repo is a single self-contained plugin, so `skills/`, `README.md`, `CHANGELOG.md`, and `LICENSE` are shared with the Claude listing.
- **`icon.png`** — 512×512 plugin logo (SE Ranking brand mark), referenced by the Cursor manifest's `logo` field. Required for the marketplace listing.
- **`schemas/cursor-plugin.schema.json`** + **`scripts/validate_cursor_manifest.py`** — a CI guard for the Cursor manifest. `claude plugin validate` only understands Claude manifests, so this validates `.cursor-plugin/plugin.json` against Cursor's published draft-07 schema (vendored, so there is no network dependency at validation time) and confirms the `logo`, `skills`, and `mcp.json` it relies on exist.

### Fixed
- **Cursor manifest failed Cursor's schema (`additionalProperties: false`).** Renamed `icon` → `logo` (the schema has no `icon` property) and removed `author.url` (the `author` object permits only `name` and `email`) — either would have rejected the plugin at submission.

### Changed
- **Cursor manifest**: `category` `Productivity` → `developer-tools` (the convention used across the official marketplace); added an explicit `skills: ./skills/` declaration.
- **CI**: `validate.yml` runs the Cursor-manifest validator on every push and PR, and both `validate.yml` and `release.yml` now assert `.cursor-plugin/plugin.json`'s version agrees with the three Claude manifest versions.
- **`README.md`**: added an "Install in Cursor" path under Install.
- Version bumped to **2.10.4** across all four manifests (Claude `marketplace.json` ×2, Claude `plugin.json`, Cursor `plugin.json`).

## [2.10.3] — 2026-06-03

Patch release. Adds release automation and ships the first signed (Verified) release.

### Added
- **`.github/workflows/release.yml`** — tag-triggered release workflow. Pushing a `vX.Y.Z` tag now asserts the tag matches the three manifest versions, extracts the matching CHANGELOG section as the notes, and creates (or updates) the GitHub Release automatically — removing the manual `gh release create` step and the tag-without-release drift it caused. A `workflow_dispatch` trigger rebuilds a Release for an existing tag.

### Notes
- First release cut with SSH commit/tag signing configured — `vX.Y.Z` tags are now GitHub-Verified.

## [2.10.2] — 2026-06-03

Patch release. Fixes a YAML frontmatter bug that made `seo-keyword-cluster` load with no metadata, and adds CI validation so the same class of error cannot ship again.

### Fixed
- **`seo-keyword-cluster` — broken `SKILL.md` frontmatter.** The `description` contained a colon-space (`seed keywords: intent-grouped …`), which terminates an unquoted YAML scalar — the frontmatter failed to parse and the skill loaded with all metadata silently dropped (no `name` / `description`). Replaced the colon with an em-dash; it was the only skill in the catalogue with a colon-space in its description.

### Added
- **`.github/workflows/validate.yml`** — CI on every push to `main` and every PR. Runs `claude plugin validate --strict` against the marketplace manifest and every `plugin.json` (schema + all skills), and asserts the three version fields (marketplace `metadata.version`, the plugin entry, and `plugin.json`) agree. `claude plugin validate .` alone validates only the marketplace manifest and never descends into skills, so the frontmatter bug above passed it undetected — this workflow closes that gap.

## [2.10.1] — 2026-05-22

Patch release. Smoke-tested `seo-api` against the live SE Ranking MCP (a read-only domain-intelligence integration for seranking.com) and corrected three inaccuracies the test exposed in the v2.10.0 skill text.

### Fixed
- **`seo-api` — `DATA_getCreditBalance` was wrongly described as an alias of `DATA_getSubscription`.** The two return different shapes (`{ limit, used }` vs `{ subscription_info: { units_limit, units_left, … } }`) and their remaining-credit figures do not reconcile (an ~8.6M gap observed live). `SKILL.md` step 1 and `references/api-surface-map.md` now state this and direct forecasting to `getSubscription.units_left`.
- **`seo-api` — `DATA_getDomainCompetitors` credit cost was wrong.** `references/rate-limits-and-credits.md` listed "1/competitor"; the actual cost is a flat 100 credits/request, verified against `seranking.com/api/data/domain-analysis`. The cost cheat-sheet was rebuilt to a docs-verified table and trimmed of rows naming tools whose existence could not be confirmed.
- **`seo-api` — skill instructed itself to read credit costs from MCP tool `description` fields.** Tool descriptions carry input schemas and usage notes but not credit costs; `SKILL.md` and `references/rate-limits-and-credits.md` now point to the public per-endpoint docs as the only cost source.

### Added
- **`examples/seo-api-seranking-com-20260522/`** — the first `seo-api` example: a read-only domain-intelligence integration for seranking.com (`RECIPE.md` + `code/` in cURL / Python / TypeScript / MCP-call form + `evidence/`). Produced by the smoke-test run; catalogue example coverage 24 → 25.

### Changed
- `seo-api` `SKILL.md` + `references/api-surface-map.md`: documented the `DATA_getDomainCompetitors` 60KB MCP-transport overflow (response auto-saved to a file; recover via a `jq` slice or the raw REST endpoint, which has no size cap) and clarified that `evidence/03-ids-resolved.md` and `04-execution-log.md` are conditional output files.
- `examples/README.md` and root `README.md`: example count 24 → 25.

## [2.10.0] — 2026-05-22

This release ships two new skills — `seo-images` (image SEO audit) and `seo-api` (SE Ranking API integration architect) — taking the catalogue from 24 to 26 skills. `seo-api` is the first skill to operate on the Project API and to wire up account state; the long-standing Data-API-only scope restriction is lifted, with mutating calls gated behind explicit per-call user confirmation.

### Added (new skill — MIT-attributed fork)
- **`seo-images`** (249-line SKILL.md + `references/image-checks.md` + `references/lazy-loaders.md` + `templates/image-object.json` + `templates/picture-element.html`) — image SEO audit for a URL or sampled domain. Inventory via Firecrawl (`firecrawl_scrape` for URL mode, `firecrawl_map` + sampled `firecrawl_scrape` for domain mode). Per-image audit covers alt-text quality (presence, generic-text patterns, length window, keyword stuffing, identical-alt templating bugs), modern-format coverage (WebP / AVIF % direct + via `<picture>` fallback), responsive sizing (`srcset` / `sizes`), lazy-loading taxonomy (`native` / `perfmatters` / `ewww` / `js-generic` / `none` — credits AgriciDaniel for the taxonomy), LCP signals (`loading` / `fetchpriority` / `decoding`), CLS dimensions (`width`/`height` attributes), file-name quality, and `ImageObject` JSON-LD detect/validate/generate. Optional Google PSI cross-reference (Tier 0) pulls `modern-image-formats` / `uses-optimized-images` / `uses-responsive-images` / `offscreen-images` / `unsized-images` / `prioritize-lcp-image` / `efficient-animated-content` and merges `wastedBytes` per image into the prioritised remediation list. Optional SE Ranking audit cross-reference elevates audit-flagged image issues alongside per-page findings. Output is `IMAGES.md` + `images.csv` + per-page inventory + paste-ready `<picture>` snippets + `ImageObject` JSON-LD + optional PSI report. Adapted from `AgriciDaniel/claude-seo`'s `seo-images` skill (MIT). File-level optimisation tooling (`cwebp` / `exiftool` / `ffmpeg`) referenced in `references/image-checks.md` § Optimisation pipeline but explicitly out of scope for the skill itself — analysis only, no auto-fix.

### Added (new skill)
- **`seo-api`** (189-line `SKILL.md` + `references/auth-and-keys.md` + `references/rate-limits-and-credits.md` + `references/api-surface-map.md` + `references/integration-patterns.md`) — SE Ranking API integration architect for developers. Covers the full ~195-tool surface across the Data API (keyword research, backlinks, domain & competitor analysis, SERP, website audit, AI Search, account) and the Project API (rank tracking, project management, audits, AIRT prompts, backlink groups, marketing plan, sub-accounts). Resolves endpoint / parameter / JSON-schema / credit-cost / rate-limit / auth questions, then either emits a code recipe (ready-to-paste cURL + Python + TypeScript + MCP-tool-call variants) or — with explicit per-call confirmation — wires up Project API state live. Three execution modes: code (emit; developer runs), live (execute via MCP step by step), hybrid (wire one-time setup live, emit recurring-job code). Output is `RECIPE.md` + a `code/` folder + an `evidence/` trail (preflight, cost forecast, IDs resolved, execution log). Pulls live tool schemas from the connected MCP so reference data never drifts from the server. First catalogue skill to operate on the Project API and to mutate account state — every `PROJECT_create*` / `add*` / `delete*` / `update*` and audit-creation call is gated behind explicit user confirmation. References cover the single-key auth model (OAuth vs `X-Api-Key` header, per-client config for 9 MCP clients, key rotation), the 10-RPS Data / 5-RPS Project rate limits with an exponential-backoff-with-jitter template, the credit vs plan-limit billing models, the full tool routing + ID-resolution tables, and five canonical integration patterns (rank tracker setup, bulk backlink export, audit pipeline, AIRT visibility tracker, keyword research bulk job).

### Changed
- README skills table updated with the new row (between `seo-schema` and `seo-drift`); install-option-3 skill count corrected from a stale "21 of 22" to the accurate "24 of 25"; Firecrawl-dependents note expanded to mark `seo-images` as a hard requirement (the audit cannot run without Firecrawl — `<img>` attributes are stripped from WebFetch's markdown).
- `seo-api` integration: README skills table gains a 26th row; install-option-3 skill count corrected "24 of 25" → "25 of 26"; repository-layout tree updated with `skills/seo-api/`.
- `CONTRIBUTING.md`: the Data-API-only scope restriction is lifted — both Data API and Project API tools are now in scope for skills. The `SKILL.md` line ceiling was raised 300 → 400. Mutating-tool guidance now covers plan-limit cost alongside credit cost.

### Notes
- JPEG XL coverage: rubric flags JPEG XL as a Nov-2025 Chromium-restoration announcement, not yet in stable Chrome — the skill does not recommend JPEG XL deployment today and marks it for monitoring through 2026.
- CSS background-images surfaced as an explicit blind spot in the synthesis (count reported, not audited — they don't appear in Google Images search and aren't subject to the `<img>`-tag rubric).
- `seo-api` never auto-writes to account state — every mutating Project API call is gated behind explicit per-call user confirmation; declining falls back to emitting equivalent code.
- `seo-api` ships without an `examples/` entry and has not been smoke-tested against a live SE Ranking account — both recommended as immediate follow-ups.

## [2.8.0] — 2026-05-01

Closes the entire prioritised fix list from `docs/EVAL_RESULT_v2.md` (10 items) and forks two MIT-attributed skills from `AgriciDaniel/claude-seo`. Catalogue grows from 22 to 24 skills; mean output files-per-skill drops from 6.4 to ~2.6 via the evidence/ refactor.

### Added (new skills — MIT-attributed forks)
- **`seo-local`** (225-line SKILL.md + `references/local-citation-sources.md`) — local SEO analysis adapted to our backend. Brick-and-Mortar / SAB / Hybrid + 7-vertical detection. Local-pack rank tracking via `DATA_getSerpResults` + `DATA_getSerpLocations`. NAP consistency via Firecrawl rawHtml across homepage + 5 sample pages. GBP signals + reviews via Firecrawl on user-supplied GBP/Yelp/Trustpilot URLs. Google APIs tier-1 unlocks GSC local-intent queries; tier-2 unlocks GA4 per-location-page traffic. Out-of-scope items (geo-grid, Business Listings comprehensive citation auditing, GBP Insights) surfaced as explicit limitations with paid-tool recommendations. Adapted from `AgriciDaniel/claude-seo`'s `seo-local` skill (MIT).
- **`seo-hreflang`** (179-line SKILL.md + `references/validation-rules.md`) — international SEO / hreflang validation. SE Ranking audit (`DATA_getAuditReport` + `DATA_getAuditPagesByIssue`) surfaces audit-detected hreflang errors as ground truth. Per-URL hreflang inventory via Firecrawl `formats: ["rawHtml"]` (the `rawHtml` flag is critical — default `html` strips `<link rel="alternate">` on many sites). GSC verification check at tier ≥ 1 confirms each hreflang target is a verified property. PASS/NEEDS-FIX/BROKEN verdict shape. Translation-quality items (cultural profiles, locale formats, content parity) intentionally dropped — that's a translation team's job. Adapted from `AgriciDaniel/claude-seo`'s `seo-hreflang` skill (MIT).

### Added (eval fixes)
- **#1+#7 — SERP-overlap clustering + post-execution scorecard** (`seo-keyword-cluster`). Step 4 replaces token-overlap clustering with SERP-overlap (shared top-10 organic URLs as the clustering signal — the post-2024 standard). New `references/serp-overlap-methodology.md` adapted from `seo-cluster/references/serp-overlap-methodology.md` (MIT) with input source swapped to `DATA_getSerpResults` and credit notes for both standard (~3 cr) and advanced (~10 cr) modes. Budget guard warns user before fetching SERPs if the estimate exceeds 500 credits. New step 7 runs a 4-metric quality scorecard (cannibalisation/orphan/coverage/anchor diversity = 0-tolerance); failures append a red/yellow/green table to PLAN.md. New `06-quality-scorecard.md` evidence file.
- **#5 — Currency parity in `seo-technical-audit`**. Three new sections in `references/severity-mapping.md`: IndexNow (3 issue codes), extended security headers (5 codes — CSP, X-Frame, X-Content-Type, Referrer-Policy, HSTS-no-preload), Dec-2025 JS-SEO four risks (4 codes — render-budget cuts, hydration mismatch, CSR meta drift, soft-404 from JS errors). New step 8d (IndexNow detection) and extended step 6 (security headers via WebFetch on homepage + 3 sample URLs) and extended step 8 (JS-SEO risk detection via Firecrawl). New TECH-AUDIT.md sections: Security headers, Modern signals JS-SEO bullets.
- **#6 — `seo-plan` confirm-then-dispatch.** Replaced refuse-to-run-specialists with a confirm-then-dispatch pattern. Step 4 now detects existing specialist outputs (any `seo-*-{slug}-{date}/` folder ≤30 days old), lists missing prerequisites with credit-cost figures, and prints a single confirmation prompt. Default-N preserves v2.6 manual-prereq behaviour; `y` dispatches the four independent specialists in parallel + `seo-content-audit` sequentially after the gap-analysis. Each specialist's own credit-balance preflight is honoured (no bypass). The v2.7 step-0 Google API advisory remains unchanged.
- **#8+#9 — AI-content markers + word-count floors** (`seo-content-audit`). Expanded the 8-marker AI-content checklist in `references/core-eeat.md` with explicit examples and per-marker detection methods. The existing 4th E-E-A-T veto (AI-on-YMYL with no human review) was already in place; the markers reference is now precise enough to score reliably. Added "Word-count floors by page type" table to `references/core-eeat.md` (ultimate-guide 2,500 / how-to 1,200 / listicle 1,500 / comparison 1,800 / explainer 1,200 / review 1,500 / landing 600). New step 1 sub-bullet — "Page-type detection" — classifies the audited URL and surfaces the applied floor in `01-content-snapshot.md`.
- **#10 — Intent-template map** (`seo-content-brief`). New `references/intent-template-map.md` (103 lines) adapted from theirs' `seo-cluster/references/hub-spoke-architecture.md:58-67` (MIT). 8 templates (ultimate-guide / how-to / listicle / explainer / comparison / review / best-of / landing-page) with explicit "pick this when…" SERP-signal rules. SKILL.md step 6 now classifies the brief's chosen template; BRIEF.md template adds `Template type:` + `Why this template:` header lines. MIXED-SERP tip added.

### Changed (eval fixes — refactors)
- **#4 — Centralise preflight.** New `skills/seo-firecrawl/references/preflight.md` (73 lines) defines the canonical 3-stage preflight (credit balance, Firecrawl availability, Google APIs). 8 analysis skills (`seo-content-audit`, `seo-technical-audit`, `seo-page`, `seo-drift`, `seo-geo`, `seo-local`, `seo-hreflang`, `seo-backlinks-profile`) now reference this doc instead of inlining ~30 lines of duplicated preflight prose. Skill-specific notes (cost figure, Firecrawl scope, Google API tier per skill) are preserved. No skill behaviour changed; a doc fix now lands in 1 place instead of 8.
- **#2 — Collapse step files into `evidence/`.** 14 multi-file skills' Output format sections rewritten to PRIMARY + load-bearing CSVs/specs at top level + numbered step files under `evidence/`. Mean files-per-skill 6.4 → ~2.6. Specific decisions: `seo-content-audit` keeps `05-aio-winner-comparison.md` at top level (live AIO citation evidence is load-bearing); `seo-keyword-niche` keeps `06-template-spec` + `07-quality-gates`; `seo-plan` keeps phase files `04/05/06`; `seo-technical-audit` keeps `03-key-pages-issues`; `seo-sitemap` consolidates 7 raw step files into one `evidence/source-data.md`. All PRIMARY filenames preserved. All load-bearing CSVs (issues.csv, keywords.csv, gaps.csv, prospects.csv, disavow-candidates.csv, recommended-keywords.csv) preserved at top level. In-process step-file references in 9 skills updated to point at the new `evidence/` paths.

### Coverage parity vs `AgriciDaniel/claude-seo`
After this release, our cross-skill GSC / CrUX / GA4 / Indexing enrichment **exceeds** theirs. Methodology gaps from `EVAL_RESULT_v2.md` § H4 are closed: SERP-overlap clustering matches theirs (`seo-cluster`); IndexNow + security headers + Dec-2025 JS-SEO matches theirs (`seo-technical`); AI-content markers + word-count floors match theirs (`seo-content`). Coverage gaps closed: `seo-local` and `seo-hreflang` forked with adaptations to our SE Ranking + Firecrawl + WebFetch + Google APIs stack. Skills theirs has that we do **not** add (`seo-maps`, `seo-image-gen`, `seo-ecommerce`, `seo-flow`, `seo` orchestrator) are out of scope for our SE Ranking-backed plugin — adding them would weaken the proposition.

### Notes
- All MIT-attributed forks carry attribution in their SKILL.md after the H1 (same pattern as `seo-google` since v2.4).
- The eval prompt's prioritised fix list (10 items) is now fully shipped; v2.7 closed #3 (cross-skill Google enrichment) and v2.8 closes the remaining 9.
- Skill count: 22 → 24.
- See `docs/EVAL_RESULT_v2.md` for the full per-skill collapse plan, friction inventory, and methodology-gap analysis that drove this release.

## [2.7.0] — 2026-05-01

Cross-skill Google field-data enrichment. When `~/.config/seo-skills/google-api.json` is present, five existing analysis skills now pull real Google data alongside their SE Ranking outputs — no separate `seo-google` invocation required. Closes the data-quality gap the v2 evaluation flagged in `docs/EVAL_RESULT_v2.md` §6a (we already forked theirs' `seo-google` skill in v2.4; this PR forks the wiring across the rest of the catalogue, modelled on `AgriciDaniel/claude-seo`'s `seo-audit` / `seo-technical` / `seo-drift` integration patterns).

### Added
- **`skills/seo-google/references/cross-skill-integration.md`** — the contract every enrichment-aware skill follows. Defines the trigger pattern (parse `python3 scripts/google_auth.py --check --json`, branch on tier), per-skill enrichment recipes with bash command templates, and a uniform failure-mode table. Mirrors the upstream wiring without spawning the full `seo-google` skill — each enrichment is one Python script call returning JSON, parsed in-line by the calling skill. A failed Google call never blocks the SE Ranking-based primary deliverable.
- **`seo-technical-audit`** new step 8b (CrUX field data, Tier 0) — pulls CrUX p75 LCP/INP/CLS/FCP/TTFB via `pagespeed_check.py --crux-only` and the 25-week trend via `crux_history.py --origin`. New "Core Web Vitals (field data)" section in `TECH-AUDIT.md` with current p75 + trend per metric. Replaces the audit's lab-only Lighthouse-flavoured estimates with the metric Google ranks against.
- **`seo-technical-audit`** new step 8c (per-URL Inspection, Tier 1) — for the top 5 traffic URLs from step 5, pulls `gsc_inspect.py` to get real indexation verdict, googleCanonical, lastCrawlTime. Cross-checks against the audit's noindex / canonical findings (catches stale audits and hidden indexability issues). New "Indexation reality check" section in `TECH-AUDIT.md`. `userCanonical ≠ googleCanonical` on a top-traffic page elevates to Critical in the Top-10 fix list. Mirrors theirs at `seo-technical/SKILL.md:164`.
- **`seo-page`** new step 4b — pulls GSC search analytics for the URL (`gsc_query.py --url`) and URL Inspection (`gsc_inspect.py`). New `Snapshot` rows for GSC clicks/impressions/CTR/position and Google's indexation verdict + canonical-divergence flag. Verdict heuristic hardens: `INDEXED + impressions > 100 + position 4–10` → REFRESH; `EXCLUDED` (any reason) → KILL/CONSOLIDATE; `userCanonical ≠ googleCanonical` → critical issue regardless of verdict.
- **`seo-content-audit`** new step 3b — pulls GA4 organic traffic on the audited URL (`ga4_report.py --report top-pages`). New "Snapshot (measured)" line in `VERDICT.md` with last-28-day sessions / users / engagement-time. Signal, not veto — low GA4 traffic on high-E-E-A-T YMYL is informative, doesn't change the publish decision.
- **`seo-drift`** new step 4b — captures CrUX (`pagespeed_check.py --crux-only`), 25-week CrUX history (`crux_history.py`), and URL Inspection (`gsc_inspect.py`) into the snapshot. New compare-mode drift rules: LCP/INP +20% → red, CLS +0.05 absolute → yellow, indexation status change → red, googleCanonical change → yellow. New "Field-data drift" section in `DRIFT-REPORT.md`.
- **`seo-drift`** SSRF protection step (mirrors theirs at `seo-drift/SKILL.md:97`) — both `baseline` and `compare` now validate the target URL via `validate_url()` from `scripts/google_auth.py:366` before any fetch. Refuses loopback, RFC1918 private ranges, link-local, Google metadata endpoints, and non-http(s) schemes. Closes a real SSRF risk that's existed since v0.4.0.
- **`seo-drift`** new `--skip-cwv` flag (mirrors theirs at `seo-drift/SKILL.md:107, 131`) — explicitly skip the Google field-data snapshot at baseline or compare time, even when `google-api.json` is configured. New "Optional flags" table at the top of the skill documents `--no-firecrawl`, `--skip-cwv`, `--baseline-id`, `--limit`. Compare-mode surfaces `Field-data drift: skipped — --skip-cwv flag passed` when set.
- **`seo-drift/references/drift-thresholds.md`** — new "Field-data drift (CrUX)" + "Indexation drift (GSC URL Inspection)" tables with explicit yellow/red thresholds and cross-reference recipes to `seo-google` for deep-dive context. Mirrors theirs at `seo-drift/references/comparison-rules.md:88`.
- **`seo-plan`** new step 0 — advisory creds-detection. Prints a one-line notice when Google APIs are configured ("downstream specialist skills will enrich automatically") or missing ("run `bash extensions/google/install.sh` to enrich"). The lightest possible auto-spawn — plan doesn't dispatch `seo-google` itself; it surfaces the option so the user can opt in before specialist skills run.

### Changed
- All five affected SKILL.md files reference `skills/seo-google/references/cross-skill-integration.md` for the canonical trigger pattern + failure-mode table, so the recipe lives in one place.

### Coverage parity vs `AgriciDaniel/claude-seo`
After this release, our cross-skill GSC / CrUX / GA4 / Indexing enrichment matches theirs gap-for-gap: per-URL Inspection in technical audits (theirs: `seo-technical/SKILL.md:164`; ours: `seo-technical-audit` step 8c), CrUX field-data + 25-week trend (theirs: `seo-audit/SKILL.md:128`; ours: `seo-technical-audit` step 8b + `seo-drift` step 4b), SSRF protection via `validate_url` (theirs: `seo-drift/SKILL.md:97`; ours: `seo-drift` step 1), `--skip-cwv` flag (theirs: `seo-drift/SKILL.md:107, 131`; ours: `seo-drift` Optional flags), creds-detection auto-advisory (theirs: `seo/SKILL.md:59`; ours: `seo-plan` step 0). Where ours **exceeds** theirs: GA4 organic traffic enrichment in `seo-content-audit` (theirs only does GA4 at the audit-orchestrator level), GSC URL performance in `seo-page` (theirs has no URL-level page intelligence skill), and explicit indexation-drift rules in `seo-drift/references/drift-thresholds.md` (theirs has cross-references but no thresholds).

### Why this is a 2.7.0 (not 2.6.1)
Cross-skill data-quality lift across five existing analysis skills. New section in every affected SKILL.md output template, new conditional branch in every affected Process. No backwards-incompatible changes — when `google-api.json` is missing, every skill behaves identically to v2.6.0 and notes "not configured" in the relevant output section.

## [2.6.0] — 2026-04-30

SE Ranking MCP now auto-registers when the plugin is installed. New users no longer need to run `claude mcp add ...` separately — install the plugin, run `/mcp` once for OAuth, done. Existing users are unaffected: per Claude Code's scope-hierarchy rule, user-scope MCP registrations outrank plugin-bundled ones, so any pre-existing `se-ranking` registration silently takes precedence over the plugin-shipped one.

### Added
- **`mcpServers.se-ranking` in `.claude-plugin/plugin.json`**: declares the remote MCP server inline (`type: "http"`, `url: "https://api.seranking.com/mcp"`). Per [Claude Code's plugin docs](https://code.claude.com/docs/en/plugins-reference#mcp-servers), plugin-bundled MCP servers start automatically when the plugin is enabled. SE Ranking supports OAuth 2.1 with dynamic client registration ([RFC 9628](https://datatracker.ietf.org/doc/html/rfc9628)), so no API token configuration is required — Claude Code handles the OAuth handshake on first `/mcp` call.

### Changed
- README "Connect SE Ranking" section: reframed as "the MCP auto-registers; just run `/mcp` to OAuth." The previous standalone `claude mcp add ...` command is preserved inside a `<details>` fallback block for users on older Claude Code builds that pre-date plugin-bundled MCP, or for troubleshooting if auto-registration doesn't fire.
- 7 SKILL.md prerequisite lines simplified: removed the obsolete `with a valid DATA_API_TOKEN` phrasing (`seo-agency-landing-page`, `seo-ai-search-share-of-voice`, `seo-backlink-gap`, `seo-competitor-gap-analysis`, `seo-content-brief`, `seo-keyword-cluster`) and the `(remote OAuth via claude mcp add)` parenthetical (`seo-page`). All 21 affected skills now read uniformly: `- SE Ranking MCP server connected.`
- All three version strings bumped to 2.6.0 (`plugin.json`, `marketplace.json` ×2).

### Migration
**Existing users — nothing to do.** Your current `se-ranking` registration (whether user-scope from `claude mcp add` or project-scope from `.mcp.json`) takes precedence over the plugin-bundled one per [Claude Code's scope hierarchy](https://code.claude.com/docs/en/mcp#scope-hierarchy-and-precedence). Claude Code "connects to it once" — no duplicate processes, no port conflicts, no forced re-auth. To consolidate after upgrading, optionally `claude mcp remove se-ranking` and let the plugin-bundled config take over (saves one entry in `~/.claude.json`).

### Why this is a 2.6.0 (not 2.5.4)
First-install UX change. New users get a one-step install instead of two. Even though existing users are unaffected, the install-flow surface change earns a minor bump. No skill behavior changes.

## [2.5.3] — 2026-04-29

README slash-command syntax fix. The Claude Code section instructed users to trigger skills with `/seo-skills:seo-content-brief` (plugin-namespaced form). Empirically the prefix isn't required — `/seo-content-brief` works directly. The 2.0.0 CHANGELOG entry that introduced the namespaced form is preserved as historical record (it described what was true at the time), but current docs now show the simpler form.

### Changed
- Claude Code section: trigger examples updated to `/seo-content-brief`, `/seo-page`. Added "or just describe what you want and Claude picks the right skill" — natural-language invocation is the primary path; slash commands are the explicit alternative.
- Cowork section: dropped the "they're namespaced" claim (which was likely wrong-by-extension from the Claude Code mis-documentation) and replaced with the same trigger-by-name-or-by-description framing.
- All three version strings bumped to 2.5.3.

## [2.5.2] — 2026-04-29

README restructure for non-technical users. Install moved above the skills table (was below — readers had to scroll past 22 rows to find install instructions). Install reduced from 7 options to 3, ordered by friendliness: Claude Desktop (Cowork) first, Claude Code (slash commands) second, manual install (only for `seo-google` and extensions) third.

### Changed
- README ordering: `## Install` now precedes `## Skills`. Reasoning: install instructions are the primary call-to-action; the skills catalogue is the secondary "what's in the box" reference. Old order forced readers to skim past 22 skill rows to find install steps.
- Install options trimmed: 7 → 3. Dropped (as standalone options): Local plugin development mode, Copy individual skills, Project-scoped install, Claude API. The first three were power-user variants of the marketplace install; the API path is one paragraph that didn't earn a top-level slot. Anyone needing those paths can read the existing `--plugin-dir` / `cp -r` patterns in the relevant skill folders or the Claude Code docs.
- Install order changed: Claude Desktop (Cowork) → Claude Code → Manual install. Cowork promoted from option 3 to option 1 because it's a UI flow with no terminal commands — friendliest path for non-technical users.
- Manual install (option 3) explicitly framed as "only if you want `seo-google` or the optional extensions" — most users will skip it.
- "Connect SE Ranking" carved out as its own subsection at the bottom of `## Install`. Applies to all install paths and reads as the natural next step after the chosen install completes.
- `## Prerequisites` section dropped. SE Ranking connection is now in Install; the optional Firecrawl/Google extensions are documented under `## Optional extensions`. The "Claude Code OR Cowork OR API OR Claude.ai" enumeration that was in Prerequisites is implicit in the three install options.
- Internal anchor in `## Optional extensions` updated to point at the renumbered manual-install heading.
- All three version strings bumped to 2.5.2.

### Why this is a 2.5.2 (not 2.6.0)
Pure README restructure. No skill behavior changes, no install.sh changes, no config-shape changes. Existing users on 2.5.1 are unaffected.

## [2.5.1] — 2026-04-29

Adds a top-level `install.sh` so the cold-start install path is a single command, and clarifies the README's split between marketplace install (skills only — sufficient for 21 of 22 skills) and manual install (required for `seo-google` and the Firecrawl extension). Surfaced by a sharp question: the v2.5.0 walkthrough told users to `bash extensions/.../install.sh` without ever telling them to clone the repo first.

### Added
- **`install.sh`** at repo root. Detects whether it's running from inside a clone vs needing to clone (default target `~/.local/share/seo-skills`, override via `--target`). Verifies `git`, `python3` 3.10+. Runs the chosen extension installers. Interactive when stdin is a TTY (asks Y/N for Firecrawl + Google); non-interactive when piped (skips extensions unless `--firecrawl` / `--google` / `--all` is passed). Reads prompts from `/dev/tty` so `curl ... | bash` works under a real terminal. Idempotent (re-running pulls latest + re-runs requested extensions).
- README "Option 2: Manual install (required for `seo-google` and the Firecrawl extension)" section. Shows the `git clone + bash install.sh` form and a `<details>`-collapsed curl one-liner: `curl -fsSL .../install.sh | bash -s -- --all`. Mirrors the [`AgriciDaniel/claude-seo`](https://github.com/AgriciDaniel/claude-seo) install pattern.
- README install-path TL;DR table at the top of the Install section: marketplace install for SKILL.md-only skills, manual install for `seo-google` + extensions, both for users who want everything.

### Changed
- README install options renumbered: Cowork moved to Option 3 (was 2), Local plugin development to Option 4 (was 3), Copy individual skills to Option 5 (was 4), Project-scoped to Option 6 (was 5), Claude API to Option 7 (was 6). The new Option 2 slots in just after the marketplace install.
- README "Optional extensions" intro now points to the top-level `install.sh` as the fastest path; per-extension scripts remain documented for one-off installs.
- README repo-layout block now lists `install.sh` at the root.
- All three version strings bumped to 2.5.1.

### Why this is a 2.5.1 (not 2.6.0)
Pure docs + install ergonomics. No skill behavior changes, no new APIs, no config-shape changes. Existing users on 2.5.0 are unaffected unless they re-run the installer, which is idempotent.

## [2.5.0] — 2026-04-29

Adds `seo-google` — direct access to Google's own SEO data (GSC Search Analytics + URL Inspection + Sitemaps, PageSpeed Insights v5, CrUX field data + 25-week history, Indexing API v3, GA4 Data API, YouTube Data v3, Cloud Natural Language, Knowledge Graph Search, Web Risk, Google Ads Keyword Planner) plus a PDF/HTML/XLSX report generator. This is the catalogue's first Python-script skill — earlier skills are SKILL.md only.

**Adapted with attribution from [`AgriciDaniel/claude-seo`](https://github.com/AgriciDaniel/claude-seo) v1.9.6 (MIT).** All 11 Python scripts (`scripts/google_*.py`, `scripts/pagespeed_check.py`, `scripts/crux_history.py`, `scripts/gsc_*.py`, `scripts/indexing_notify.py`, `scripts/ga4_report.py`, `scripts/youtube_search.py`, `scripts/nlp_analyze.py`, `scripts/keyword_planner.py`, `scripts/google_report.py`), all 10 reference docs under `skills/seo-google/references/`, and 3 report templates under `skills/seo-google/assets/templates/` are forked verbatim. Two minimal adaptations only: (a) config path `~/.config/claude-seo/` → `~/.config/seo-skills/` for clean coexistence with the upstream plugin, (b) example service-account name `claude-seo` → `seo-skills` in `auth-setup.md`. Functional behaviour is otherwise unchanged. Upstream MIT copyright is preserved at `extensions/google/LICENSE-AgriciDaniel.txt`.

### Added
- **`skills/seo-google/SKILL.md`** — 21-command router. Subcommands: `setup`, `pagespeed`, `crux`, `crux-history`, `gsc`, `inspect`, `inspect-batch`, `sitemaps`, `index`, `index-batch`, `ga4`, `ga4-pages`, `youtube`, `youtube-video`, `nlp`, `entities`, `keywords`, `volume`, `entity`, `safety`, `quotas`, `report`. Each command shells out to a Python script with `--json` output.
- **`skills/seo-google/references/`** — 10 reference docs: `auth-setup.md` (8-step Google Cloud project setup walkthrough), `search-console-api.md`, `pagespeed-crux-api.md`, `ga4-data-api.md`, `indexing-api.md`, `keyword-planner-api.md`, `nlp-api.md`, `supplementary-apis.md` (Knowledge Graph + Web Risk), `youtube-api.md`, `rate-limits-quotas.md`.
- **`skills/seo-google/assets/templates/`** — 3 report templates: `cwv-audit-report.md`, `gsc-performance-report.md`, `indexation-status-report.md`.
- **`scripts/`** — new repo-root directory with 11 Python scripts (~235KB total).
- **`extensions/google/install.sh`** — pip-installs Google API libraries (`google-api-python-client`, `google-auth*`, `google-analytics-data`, `requests`) plus optional report libraries (`matplotlib`, `weasyprint`, `openpyxl`). Creates `~/.config/seo-skills/` (700) with a stub `google-api.json` (600) the user fills in. Runs the credential checker. Idempotent.
- **`extensions/google/uninstall.sh`** — removes config + token; preserves user's service-account JSON files and pip libraries (with instructions to remove them manually).
- **`extensions/google/README.md`** — full setup, troubleshooting, rate-limit table, credential-tier reference.
- **`extensions/google/LICENSE-AgriciDaniel.txt`** — preserves upstream MIT copyright per license requirement.
- README skills table extended to 22 rows (`seo-google` row, marked extension-required).
- README "Optional extensions" section gains "Google APIs" subsection with install command, tier model, and link to the extension README.
- README repo-layout block updated to show `scripts/`, `extensions/google/`, and the new `references/` + `assets/templates/` under `seo-google/`.
- Prerequisites bullet calling out the optional Google APIs extension.

### Credential tiers (key design borrowed from upstream)
- **Tier 0** (API key only): `pagespeed`, `crux`, `crux-history`, `youtube`, `youtube-video`, `nlp`, `entities`, `entity`, `safety`.
- **Tier 1** (+ service account, added as Full to GSC): adds `gsc`, `inspect`, `inspect-batch`, `sitemaps`, `index`, `index-batch`.
- **Tier 2** (+ GA4 property ID, service account added as Viewer): adds `ga4`, `ga4-pages`.
- **Tier 3** (+ Google Ads developer token + customer ID): adds `keywords`, `volume`.
Each tier is independently useful — Tier 0 alone unlocks real CWV field data via PSI + CrUX.

### Cross-skill upgrades enabled by `seo-google`
When `seo-google` is configured at the appropriate tier, several existing skills can swap *estimates* for *measurements*:
- **`seo-page`** — replace SE Ranking traffic estimate with real GSC `query,page` impressions/clicks (Tier 1); confirm indexation via URL Inspection (Tier 1).
- **`seo-drift`** — add 25-week CrUX history trend (Tier 0) and GSC delta tracking (Tier 1) to baseline/compare snapshots.
- **`seo-technical-audit`** — real CWV field data via PSI + CrUX (Tier 0); real indexation status via URL Inspection (Tier 1).
- **`seo-content-audit`** — NLP entity/sentiment analysis enhances E-E-A-T scoring (Tier 0); GSC confirms whether the page is earning impressions for its target keywords (Tier 1).
- **`seo-sitemap`** — GSC sitemap status shows which sitemaps Google has actually consumed and their error/warning counts (Tier 1).
- **`seo-geo`** — GSC `dimensions=searchAppearance` includes AI Overview impressions (Tier 1).
- **`seo-keyword-cluster`** / **`seo-keyword-niche`** — gold-standard Keyword Planner volumes (Tier 3) replace SE Ranking estimates when configured.
- **`seo-plan`** — Phase-1 baseline uses real impressions/clicks/conversions (Tier 1+2) instead of estimates.
These integrations are wired in the `seo-google` SKILL.md's "Cross-Skill Integration" section and `extensions/google/README.md`. The existing skills do not yet auto-detect Google credentials and prefer real data when present — that is a separate v1.5-track follow-up.

### Architectural notes
- First skill in the catalogue with bundled Python scripts (`scripts/` at repo root). All earlier skills were SKILL.md only and called MCP tools. The new pattern is documented in the repo-layout README block.
- Scripts use sibling-import style (`from google_auth import ...`) with try/except for path resolution — same pattern as upstream. Works whether the assistant invokes `python scripts/<name>.py` from the plugin root or via an absolute path.
- Two-extension pattern now established: `extensions/firecrawl/` (MCP server wiring) + `extensions/google/` (pip + config wiring). Future extensions can pick whichever fits.

### Deferred
- Wiring real-data preferences into the existing skills (e.g., `seo-page` auto-detecting GSC and using it instead of SE Ranking traffic estimates). Currently the cross-skill integrations exist as documented patterns in `seo-google`'s own SKILL.md, not as auto-detection in the consumer skills. Tracking for v2.6 / v3.0.
- Smoke-test on a clean profile install. The pip install path is well-trodden, but `weasyprint` system-dep fallout (cairo/pango on Linux, Xcode CLT on macOS) is the most likely real-world snag.

### Changed
- All three version strings bumped to 2.5.0.

## [2.4.0] — 2026-04-29

Adds `seo-plan` — the strategic-roadmap layer above the existing 20-skill catalogue. Surfaced by the 2026-04-28 head-to-head against `AgriciDaniel/claude-seo` v1.9.6, which had a `seo-plan` we lacked. This skill does not replace specialist skills — it composes their outputs into a phased site-level plan with sequencing, owners, metrics, and a critical path.

### Added
- **`skills/seo-plan/SKILL.md`** — phased SEO roadmap for a domain. Inputs: target domain (+ optional country, business type, planning horizon, constraints). Process: detect business type from homepage signals → baseline domain via `DATA_getDomainOverviewWorldwide` + history + DA + backlinks → competitive frame via `DATA_getDomainCompetitors` → ingest specialist-skill outputs (`seo-technical-audit`, `seo-content-audit`, `seo-competitor-gap-analysis`, `seo-ai-search-share-of-voice`, `seo-backlinks-profile`); if missing, queue them as Phase 0 → score four pillars (technical / content / topical / AI Search) → apply business-type template (saas / ecommerce / local / publisher / agency / b2b-services) → phase the plan into Foundations → Build → Compound+measure → pick metrics (one leading + one lagging per phase) → emit a critical-path dependency map. Output: `PLAN.md` + 8 numbered raw-data files. Deliberately distinct from `seo-keyword-cluster` (keyword architecture for one topic), `seo-content-brief` (one article), and `seo-keyword-niche` (longtail content tier).
- README skills table extended to 21 rows.
- README repo-layout block updated to show the new `seo-plan/` folder.

### Known scope gaps surfaced by `seo-plan` (deferred)
The skill explicitly flags two business-type templates with thin coverage in the current catalogue. These are not blockers — `seo-plan` degrades by recommending manual sub-steps — but they're real gaps worth tracking:
- **`local` template** — no `seo-local` skill exists yet (GBP optimisation, NAP consistency, citations, location pages, multi-location). `seo-plan` flags Phase 0 manual GBP audit when business type is `local`.
- **`ecommerce` template** — partial coverage. `seo-ads` reaches the Shopping pack via SERP-feature filters but does not cover Amazon marketplace, Merchant API data, product schema validation depth, or competitor pricing. A dedicated `seo-ecommerce` skill is the obvious follow-up if demand surfaces.

### Changed
- All three version strings bumped to 2.4.0.

## [2.3.1] — 2026-04-27

Documentation patch surfacing v2.3.0's Firecrawl integration in the README.

### Added
- `seo-firecrawl` row in the README skills table (marked as extension-required, anchor-linked to the new section).
- New "Optional extensions" section between "Install" and "How these skills work" — Firecrawl install command, what it unlocks, free-tier credit math, and links to the extension's own README.
- Prerequisites bullet calling out the optional Firecrawl extension.
- `extensions/firecrawl/` and `skills/seo-firecrawl/` entries in the Repository layout tree.

### Fixed
- README's `seo-schema` row no longer lists "HowTo" among bundled templates — the template was removed in v2.1.0 (Google retired HowTo rich results in September 2023). Count corrected from "Six" to "Five".

### Changed
- All three version strings bumped to 2.3.1.

## [2.3.0] — 2026-04-27

Completes the Firecrawl integration started in v2.2.0. Ships the install scaffold, the `seo-firecrawl` orchestrator skill, and four v1.5-track skill patches (`seo-content-brief`, `seo-competitor-pages`, `seo-sxo`, `seo-backlinks-profile`). Together with v2.2.0, every skill that genuinely benefits from Firecrawl is wired up — and the install path now actually ships in the plugin.

### Added
- **`extensions/firecrawl/`** install scaffold (`install.sh`, `uninstall.sh`, `README.md`) per plan §4. `install.sh` checks Node 20+/npx/python3, prompts for `FIRECRAWL_API_KEY`, idempotently merges `mcpServers.firecrawl-mcp` into `~/.claude/settings.json` via a Python step that preserves existing entries, pre-warms the npm package, prints the available tools. `uninstall.sh` removes the entry only. `README.md` is a one-page setup + free-tier credit math + tool-prefix reference + troubleshooting.
- **`skills/seo-firecrawl/SKILL.md`** — ad-hoc orchestrator skill per plan §7. Modes: `scrape` (single URL), `map` (domain → URL list), `crawl` (domain → all pages), `search` (within a domain). Cost-confirmation gates for `crawl` and large `map` runs. Per-mode output folders (`RAW.md` + `META.md` + `links.csv` for scrape, `URLS.md` + `urls.csv` for map, `INDEX.md` + per-page folders for crawl, `MATCHES.md` for search). Handoff payload routes follow-up to `seo-page` / `seo-schema` / `seo-technical-audit` / `seo-content-audit` / `seo-drift baseline`.

### Fixed (v1.5 broken claims — same WebFetch markdown problem as v2.2.0)
- **`seo-competitor-pages`** step 5 — claimed to extract "schema types" from WebFetch markdown. Fixed: WebFetch handles H2 outline / feature-matrix / CTA prose; Firecrawl recovers schema types + og:* / twitter:* on top-3 SERP winners. Schema generation in step 8 now falls back to a default `Product + BreadcrumbList + FAQPage` template when Firecrawl is absent rather than mirroring inference-from-markdown guesses.
- **`seo-sxo`** step 4 — claimed to extract "schema types" from WebFetch markdown. Fixed: WebFetch handles prose / H-tags / content-structure; Firecrawl recovers JSON-LD `@type`s per page, which are load-bearing for the page-type classification heuristic in step 5. Without Firecrawl the heuristic falls back to URL/title patterns + content-structure heuristics only — confidence drop noted in `02-page-type-classification.md`.

### Added (v1.5 — Firecrawl enhancements, opt-in or default-on graceful degrade)
- **`seo-content-brief`** step 6 — Firecrawl scrape on top-3 SERP winners (3 credits) recovers real `<title>` length, meta-description length, og:*, twitter:*, JSON-LD `@type`s, DOM byline structure, hero-image presence, table/code-block counts. New "Top 3 winners — on-page benchmark" table in `BRIEF.md` so the writer matches what's actually shipping in the SERP.
- **`seo-competitor-pages`** new step 5b — opt-in `--bulk-scrape <urls>` mode. Firecrawl-scrape each user-supplied competitor URL; emit `competitor-elements.csv` with title / og / twitter / JSON-LD / pricing-block / CTA-count / comparison-table / free-tier-mention columns. 1 Firecrawl credit per URL; refuses >50 without `--confirm-cost`.
- **`seo-sxo`** step 4 — opt-in `--screenshots` flag. Firecrawl scrape with `formats: ["screenshot"]` on candidate + top 3 winners (4 extra credits). Saved as `screenshots/{page}.png`. Wireframe in step 8 can reference the visual layout, not just text outline.
- **`seo-backlinks-profile`** new step 8b — opt-in `--verify-sources` flag. Firecrawl-scrape the highest-authority linking page per top-20 referring domain (20 credits). Verifies (a) link still present, (b) `rel` attribute (`dofollow` / `nofollow` / `sponsored` / `ugc`), (c) source page status. Mismatches against SE Ranking's reported state surface in `08b-source-verification.md` and feed step 9's toxic-candidate detection. Default off — keeps the "Single-source by design" framing intact unless the user opts in.

### Cost surfacing — new in v2.3.0
v2.2.0's cost table covers `seo-page` / `seo-schema` / `seo-geo` / `seo-technical-audit` / `seo-sitemap` / `seo-content-audit` / `seo-drift`. Added in v2.3.0:

| Skill | Firecrawl credits per run |
|---|---|
| `seo-content-brief` | 3 (top-3 SERP winners scrape) |
| `seo-competitor-pages` | 3 baseline + 1 per URL in `--bulk-scrape` (refuses >50 without `--confirm-cost`) |
| `seo-sxo` | 4 baseline + 4 if `--screenshots` |
| `seo-backlinks-profile` | 20 if `--verify-sources` (default off) |
| `seo-firecrawl` | user-driven; warn at >100, refuse >500 without `--confirm-cost` |

Every Firecrawl-using skill supports `--no-firecrawl` to opt out and run in degraded mode.

### Critical pre-ship check (still required before broad release)
Plan §10 risk: tool prefix `mcp__firecrawl-mcp__firecrawl_*` must be verified on a clean profile install. Run `bash extensions/firecrawl/install.sh`, then `/mcp` in Claude Code, confirm the registered prefix matches. If it differs, every reference in the 11 Firecrawl-using skills silently mis-fires.

### Changed
- All three version strings bumped to 2.3.0.

## [2.2.0] — 2026-04-27

Firecrawl integration ships across 7 skills, closing the "WebFetch can't see the `<head>`" correctness gap that v2.1.0 explicitly deferred. Each affected skill now uses `mcp__firecrawl-mcp__firecrawl_scrape` (or `firecrawl_map`) to recover `og:*`, `twitter:*`, canonical, robots, JSON-LD, and X-Robots-Tag content that WebFetch's markdown conversion strips. Firecrawl is treated as an optional enhancement: every Firecrawl-using step degrades gracefully — emitting an explicit `(skipped — Firecrawl not installed)` note in the deliverable — rather than failing the run.

**Install path (separate concern).** This release wires up the skills but does **not** ship the `extensions/firecrawl/` install scaffold or the `seo-firecrawl` orchestrator skill — both are referenced in degradation notes and arrive in a follow-up release. Users wanting Firecrawl today install it manually: export `FIRECRAWL_API_KEY` and add `mcpServers.firecrawl-mcp = { command: "npx", args: ["-y", "firecrawl-mcp"] }` to `~/.claude/settings.json`. Free tier is 500 credits/month.

### Fixed (correctness — claims WebFetch couldn't deliver)
- **`seo-page`** step 6 — claimed to extract canonical, robots, and JSON-LD via WebFetch. WebFetch returns markdown and strips all three. Fixed: WebFetch handles `<title>`/headings/prose; Firecrawl recovers `<head>` metadata + JSON-LD. New "Page basics" section in `PAGE.md` lists og/twitter/canonical/robots/JSON-LD types/hreflang count. KILL-verdict heuristic hardens when JSON-LD is also absent.
- **`seo-schema`** steps 1-2 — claimed to "Pull the page's HTML" via WebFetch and "Extract every `<script type='application/ld+json'>` block". Both impossible. Fixed: Firecrawl is now the primary fetch path; without it the skill becomes generate-only (steps 4-6) and skips detect/validate (2-3, 7) with explicit notice rather than producing markdown-inferred guesses.
- **`seo-schema`** step 7 — competitor benchmark "WebFetch their HTML, detect their schema types" was inferring from markdown. Fixed: Firecrawl scrape on top-10 SERP results, real JSON-LD parse, "schema types used by 6+ winners that this page is missing" emitted only when benchmark actually ran.
- **`seo-geo`** step 7 — "Re-parse the page's JSON-LD" had nothing to parse (step 5's WebFetch returned markdown). Fixed: Firecrawl scrape feeds the schema check; falls back to explicit `skipped — Firecrawl required` note rather than silently passing.
- **`seo-content-audit`** step 1 — claimed to extract schema types from WebFetch markdown. Fixed: Firecrawl recovers Article/BlogPosting/Person schema and the structural byline DOM. Veto check #4 (AI-on-YMYL with no human review) gains high-confidence inputs when Firecrawl is available and falls back to lower-confidence prose-only inspection without it (caveat surfaced in `VERDICT.md`).

### Added (Firecrawl-only capabilities)
- **`seo-geo`** new step 8 — `/llms.txt` and `/.well-known/rsl.json` (with `/RSL.txt` fallback) discovery via Firecrawl. New `07-ai-protocol-files.md` output and "AI-protocol files" section in `GEO.md` summarizing the domain's stance toward LLM training/citation.
- **`seo-technical-audit`** new step 8 — "Modern signals checklist". For 5 sample URLs from the SE Ranking audit, Firecrawl scrape detects (a) JS-rendered canonical vs initial-HTML canonical divergence, (b) JS-injected noindex, (c) X-Robots-Tag header. Plus one extra `firecrawl_scrape` on `/robots.txt` parses AI-crawler User-Agent rules — `GPTBot`, `ClaudeBot`, `PerplexityBot`, `Google-Extended`, `ChatGPT-User`, `Bytespider`, `CCBot`. New `05-modern-signals.md` output and "Modern signals" subsection in `TECH-AUDIT.md`. SE Ranking's audit crawler can't see any of this.
- **`seo-sitemap`** Mode-2 — when no XML sitemap is reachable, or it returns < 10% of the audit's crawled-page count, or the user passes `--discover`, `firecrawl_map(limit=500)` enumerates URLs from the homepage + internal navigation. The four diffs (missing/orphans/broken/lastmod) run identically with discovered URLs substituting for declared sitemap URLs. New `01b-firecrawl-discovered.md` output. New "Mode" section in `SITEMAP.md` documents which mode ran.
- **`seo-drift`** URL-mode snapshots — Firecrawl captures `<head>` (canonical, robots, og:*, twitter:*) plus full JSON-LD content alongside the WebFetch markdown. Compare-mode diffs now detect schema additions/removals, canonical changes, robots-meta changes — none of which WebFetch could see. Without Firecrawl, those fields surface as `not comparable — Firecrawl-only fields missing from {baseline | current} snapshot` rather than as a green-pass. `--no-firecrawl` flag opts out for credit conservation.

### Cost surfacing
Every patched skill's preflight (step 1) surfaces estimated Firecrawl credit cost alongside `DATA_getCreditBalance`. Per-run estimates:

| Skill | Firecrawl credits per run |
|---|---|
| `seo-page` | 1 (target URL) |
| `seo-schema` | 1 + 10 if step 7 runs (top-10 SERP scrape) |
| `seo-geo` | 3 (target JSON-LD + `/llms.txt` + RSL) |
| `seo-technical-audit` | ~6 (5 sample URLs + `/robots.txt`) |
| `seo-sitemap` Mode-2 | ~50 typical, hard cap 250 |
| `seo-content-audit` | 1 per URL audited (default cap 50, hard cap 200) |
| `seo-drift` URL mode | 1 per snapshot capture |

### Deferred (planned follow-up)
- **`extensions/firecrawl/`** install scaffold (`install.sh`, `uninstall.sh`, `README.md`) — referenced in degradation notes; not shipped this release.
- **`seo-firecrawl`** orchestrator skill — ad-hoc scrape/map/crawl/search interface; ships alongside the install scaffold.
- **v1.5-track integrations** (per `docs/FIRECRAWL_INTEGRATION_PLAN.md` §6 v1.5) — `seo-content-brief` top-3 winners scrape, `seo-competitor-pages` bulk on-page CSV, `seo-sxo` screenshot mode, `seo-backlinks-profile` link-source verification.
- **Tool-prefix smoke test** — must run on a clean profile before broad release. Plan §10 risk: if the registered prefix differs from `mcp__firecrawl-mcp__firecrawl_*`, every reference in the 7 patched skills silently mis-fires.

### Changed
- All three version strings bumped to 2.2.0.

## [2.1.0] — 2026-04-27

Correctness pass — eight evidence-driven patches surfaced by the 2026-04-27 head-to-head against `AgriciDaniel/claude-seo` v1.9.6. No new dependencies; no Firecrawl yet (that ships in v2.2.0). Strictly better signal-to-noise across eight skills.

### Changed (correctness)
- **`seo-schema`** — removed HowTo from the active templates list; deleted `templates/how-to.json`. Google retired HowTo rich results in September 2023 (mobile + desktop); the skill no longer treats HowTo as a live option. SKILL.md description and step 5 updated; the deprecated entry remains documented in `references/google-rich-results.md` to explain *why* it's gone.
- **`seo-schema`** — `references/google-rich-results.md` now leads with a Type-lifecycle table (Active / Restricted / Deprecated with effective dates) covering Article/Product/LocalBusiness/BreadcrumbList/Video/Recipe/Event/JobPosting/Course/Movie/Organization/WebSite as Active; FAQPage and Q&APage as Restricted (gov/health since 2023-08); HowTo as Deprecated (2023-09); Sitelinks Search Box as Deprecated (2024-11). The HowTo subsection is rewritten as deprecated guidance.
- **`seo-content-audit`** — added an 8-item AI-content markers subsection in `references/core-eeat.md` (per the 2025-09 SQRG update) and a 4th veto in SKILL.md step 4: AI-generated YMYL content with no human-review markers. The veto fires only when ≥4 markers are present *and* the topic is YMYL *and* the page lacks all of: editor byline, "reviewed by" credit, "last reviewed"/"fact-checked on" date. AI assistance remains fine; the veto guards the YMYL accountability surface. `templates/verdict.md` updated with the new veto row.
- **`seo-sitemap`** — explicit note that `<priority>` and `<changefreq>` are ignored by Google (per Google's own sitemap docs). The skill no longer validates them; if present, they're flagged as low-signal noise the user can strip. `<lastmod>` remains validated — it's the only optional tag Google still consumes.
- **`seo-keyword-niche`** — new "Programmatic publishing — extra gates" subsection (step 9a) for tiers shipping 50+ pages: per-row uniqueness threshold (≥30% varying fields), min unique-fact count vs parent + sibling (≥5 facts), data-source independence (≥2 sources), index-bloat circuit-breaker (pause if GSC indexes <60% of submitted), crawl-budget honesty for sites >50k pages. Output `KEYWORD-NICHE-PLAN.md` template gates extended (rows 6–9).
- **`seo-backlinks-profile`** — added a "Single-source by design" framing section explaining the deliberate choice to consult only the SE Ranking backlink index (no Ahrefs/Moz/Majestic/DFS/Common Crawl blending). Internally consistent metrics + reproducible health scores are the trade-off; users needing multi-source confirmation are pointed to a manual cross-check rather than a faked blended report.
- **`seo-sxo`** — step 2 now surfaces a `mode=full` (default, `result_type=advanced`, ~750–900 cr/run) vs `mode=lite` (`result_type=standard`, ~80–150 cr/run) trade-off up front. `result_type=advanced` is required for AIO/PAA/pack data; `mode=lite` skips SERP-features and labels them in the output rather than reconstructing them from organic. Tips updated with concrete per-mode cost ranges.
- **`seo-page`** — replaced the cannibalization step. Was: cross-check via parent-domain `DATA_getDomainKeywords` (heavy on large sites). Now: dedicated step 8 using `DATA_getDomainPages` ranked by traffic, capped at top 50 peers, scanning for any peer URL ranking ≤20 for the candidate's top-3 traffic-weighted keywords. New `06-cannibalization.md` output file and a "Same-domain cannibalization" section in `PAGE.md`. CONSOLIDATE verdict heuristic rewritten to anchor on the new signal.

### Changed
- All three version strings bumped to 2.1.0.

## [2.0.0] — 2026-04-27

Repository rebrand for discoverability. The plugin is now `seo-skills` and the README leads with "Claude SEO Skills"; SE Ranking branding stays in the org (`seranking/seo-skills`), descriptions, and the underlying MCP context.

### Changed (breaking)
- **Plugin renamed** `seranking-mcp-skills` → `seo-skills`. Slash-command namespace flips from `/seranking-mcp-skills:seo-*` to `/seo-skills:seo-*`. Marketplace install command becomes `/plugin marketplace add seranking/seo-skills` and `/plugin install seo-skills@seranking`.
- **GitHub repo renamed** `seranking/seranking-mcp-skills` → `seranking/seo-skills`. GitHub auto-redirects the old URL for clones, links, and the marketplace registry, but anyone with the old slug hardcoded outside redirect-aware tooling should update.
- **README H1** `# SE Ranking MCP Skills` → `# Claude SEO Skills`. Lead paragraph repositioned around "Claude Agent Skills for SEO".
- **GitHub topics** added (previously empty): `claude`, `claude-code`, `claude-skills`, `anthropic`, `agent-skills`, `mcp`, `mcp-server`, `seo`, `seo-tools`, `seranking`.
- **GitHub description** rewritten to lead with the target query.
- All three version strings bumped to 2.0.0.

## [1.0.1] — 2026-04-27

Validation-driven patch. A v1.0.0 smoke test against the live SE Ranking MCP turned up four issues; this release fixes them.

### Fixed
- **`seo-ads`** — removed all `DATA_getAdsStats` references (the tool does not exist in the SE Ranking MCP). Step 7 re-scoped to "paid-keyword gap" using `DATA_getDomainKeywords` with the `type: 'adv'` enum switch (the documented way to access ads data on shared DATA_* tools). Output folder updated: `06-project-stats.md` → `06-paid-keyword-gap.md`. Prerequisites no longer mention project-namespace endpoints (DATA-only scope).
- **`seo-ads`** — Step 5 now explicitly names the SERP-feature filters (`tads`, `bads`, `sads`, `mads`) for ad-pack detection on `DATA_getSerpResults`.
- **`seo-page`** — added Tips entry covering the `DATA_getPageAuthorityHistory` all-zeros case (validation found that very high-authority URLs like Wikipedia paradoxically return flat-zero history). Skill now flags as "insufficient history" rather than synthesising a misleading trajectory.
- **`seo-drift`** — added the same all-zeros caveat for both `DATA_getPageAuthorityHistory` (URL mode) and `DATA_getDomainAuthorityHistory` (domain mode).
- **Manifests** — `marketplace.json` `plugins[0].description` and `plugin.json` `description` no longer say "Seven production SEO workflows" / list the original 7 deliverables. Both now describe the v1.0 19-skill scope abstractly (no count, no fixed list — won't drift again).

### Changed
- All three version strings bumped to 1.0.1.

## [1.0.0] — 2026-04-27

First production release. The catalogue covers **19 SEO skills** across keyword research, content briefing, page intelligence, technical and content audits, structured data, drift monitoring, SXO diagnostics, competitive analysis, paid search, AI-search optimization, sitemap analysis, subdomain mapping, and content opportunity mining — all powered by the [SE Ranking remote MCP](https://seranking.com/api/integrations/mcp).

### Added
- `CONTRIBUTING.md` at repo root with skill-authoring template, required structure, MCP tool conventions, and PR checklist.
- README finalised for v1.0 maturity.

### Changed
- All three version strings bumped to 1.0.0.

### Future work (planned for v1.x patch releases)
- **Frontmatter upgrade:** add `allowed-tools` and `when_to_use` to all 19 skills to eliminate mid-run permission prompts and improve trigger precision.
- **Handoff contract:** add `## Handoff` and `## Works well with` sections to every skill so chains across skills are explicit (catalog-specific convention).
- **Folder taxonomy:** group skills by stage in subdirs declared via the manifest's `skills` field (research / build / optimize / monitor / audit / competitive).
- **Examples:** add real, end-to-end runs for the most-requested skills (priority: `seo-page`, `seo-content-brief`, `seo-drift`, `seo-sxo`, `seo-technical-audit`).
- **Lint workflow:** GitHub Actions to validate `SKILL.md` frontmatter and MCP tool name accuracy on PRs.
- **`.mcp.json` decision:** decide whether to bundle the SE Ranking MCP via plugin-bundled `.mcp.json` (one-step install but tool-prefix changes) or keep external (no breaking change).

### Catalogue summary at v1.0.0

The 19 skills:

1. `seo-content-brief` — writer-ready brief from a domain + topic
2. `seo-ai-search-share-of-voice` — domain-level brand vs brand visibility across AI engines
3. `seo-backlink-gap` — domains linking to competitors but not to you
4. `seo-keyword-cluster` — content cluster plan (pillar + spokes architecture)
5. `seo-competitor-gap-analysis` — keywords competitors rank for that you don't
6. `seo-agency-landing-page` — demand-gen landing page for an SEO agency
7. `seo-page` — URL-level keyword & traffic intelligence with verdict
8. `seo-schema` — JSON-LD detect, validate, generate (6 templates)
9. `seo-drift` — git for SEO: baseline / compare / history
10. `seo-sxo` — read SERPs backwards to find page-type mismatches
11. `seo-technical-audit` — focused one-shot technical audit
12. `seo-content-audit` — E-E-A-T (60) + CITE (30) rubric for existing content
13. `seo-sitemap` — sitemap vs audit diff
14. `seo-competitor-pages` — "X vs Y" / "alternatives to X" page generator
15. `seo-backlinks-profile` — full backlink profile with toxic-candidate flagging
16. `seo-subdomain` — subdomain ownership map with cannibalization flags
17. `seo-geo` — URL-level Generative Engine Optimization
18. `seo-ads` — paid-search competitive intelligence
19. `seo-keyword-niche` — longtail + question keyword content opportunity mining

## [0.7.0] — 2026-04-27

### Added
- **`seo-geo`** — URL-level Generative Engine Optimization. Pulls per-keyword AIO presence and citation lists, audits page passages for citability, compares vs cited sources, surfaces page-level changes that improve LLM citation rates. Distinct from `seo-ai-search-share-of-voice` (domain-level brand vs brand) — this is one URL, deeper.
- **`seo-ads`** — Paid-search competitive intelligence. Two modes (domain mode for a brand's paid footprint, keyword mode for the bidding landscape on a single term). Uses `DATA_getDomainAdsByDomain` / `DATA_getDomainAdsByKeyword`, ad-copy clustering, SERP shopping/ad-pack visibility, optional project-level enrichment via `DATA_getAdsStats`. Output includes a recommended bid-keyword shortlist.
- **`seo-keyword-niche`** — Mine longtail + question keywords for niche content opportunities. Pulls `DATA_getLongTailKeywords` + `DATA_getKeywordQuestions` + related/similar at depth, clusters by intent, proposes a content tier (template, URL pattern, sample pages) with anti-thin-content quality gates. Pilot-first recommendation — 10 well-templated pages beat 1000 thin ones.

### Changed
- README skills table extended to 19 rows. **All 13 new skills now in place — every skill on the v0.4 → v0.7 build-out plan is implemented.**
- All three version strings bumped to 0.7.0.

## [0.6.0] — 2026-04-27

### Added
- **`seo-competitor-pages`** — Generate "X vs Y", "alternatives to X", and "best X for Y" landing pages targeting comparative-intent keywords. Pulls competitor data, comparative SERPs, top 3 SERP-winner page structures (via WebFetch). Produces a balanced page draft with feature matrix, PAA-derived FAQ, and paste-ready Product/Breadcrumb/FAQPage schema.
- **`seo-backlinks-profile`** — Full backlink profile (broader than `seo-backlink-gap`'s gap-only scope). Authority distribution, anchor classification, IP/subnet diversity, growth/decay trend, toxic-candidate heuristic. Output includes a 100-point profile health score and a reviewable disavow-candidate list (never auto-disavow).
- **`seo-subdomain`** — Subdomain ownership map. Uses `DATA_getDomainSubdomains` plus per-subdomain queries (overview, top keywords, competitors, backlinks). Surfaces topic-ownership matrix and cannibalization flags. Recommends consolidate / split / leave-alone with risk notes.

### Changed
- README skills table extended to 16 rows; repo-layout block updated.
- All three version strings bumped to 0.6.0.

## [0.5.0] — 2026-04-27

### Added
- **`seo-technical-audit`** — focused one-shot technical audit. Crawlability, indexability, security, mobile, structured data, JS rendering. Reuses an existing SE Ranking audit when present (cheap), creates one when needed (expensive — confirms with user). Severity × effort prioritisation in `references/severity-mapping.md`. Top-10 fix list as the deliverable.
- **`seo-content-audit`** — E-E-A-T + CITE quality audit for existing content. 60-item E-E-A-T rubric (Experience / Expertise / Authoritativeness / Trustworthiness, 15 each) at `references/core-eeat.md`; 30-item CITE rubric (Clear answer / Include stats / Timestamp / Entity authority) at `references/cite.md`. Veto checks (3 each) gate publication. Output: PUBLISH / PUBLISH WITH FIXES / NO PUBLISH verdict + top 5 fixes.
- **`seo-sitemap`** — XML sitemap analysis vs the most recent SE Ranking audit. Surfaces missing-from-sitemap, orphans-from-sitemap, broken sitemap entries, lastmod issues. Predecessor: `seo-technical-audit` (provides the audit baseline).

### Changed
- README skills table extended to 13 rows; repo-layout block updated for new skill folders.
- All three version strings bumped to 0.5.0.

## [0.4.0] — 2026-04-27

### Added
- **`seo-page`** — URL-level keyword & traffic intelligence. Pulls `DATA_getUrlOverviewWorldwide`, `DATA_getDomainKeywords` (URL-filtered), `DATA_getPageAuthority` + history, top SERPs and AIO citations for the URL's primary keywords. Output: keep / refresh / consolidate / kill verdict for one page.
- **`seo-schema`** — Schema.org JSON-LD detect, validate, generate. Six bundled templates (Article, Product, LocalBusiness, FAQPage, HowTo, BreadcrumbList) under `skills/seo-schema/templates/`; rich-results spec snapshot at `skills/seo-schema/references/google-rich-results.md`. Output: paste-ready `<script>` blocks.
- **`seo-drift`** — Git for SEO. Three subcommands (`baseline`, `compare`, `history`). Uses SE Ranking's history endpoints (`DATA_getDomainOverviewHistory`, `DATA_getCumulativeBacklinksHistory`, `DATA_getNewLost*`, etc.) plus `WebFetch` page fingerprinting. Severity thresholds at `skills/seo-drift/references/drift-thresholds.md`.
- **`seo-sxo`** — Reads SERPs backwards to detect page-type mismatches. Classifies each top-10 result by page type, scores the candidate page from 4 personas (Skimmer, Researcher, Buyer, Validator), and produces a wireframe for the SERP-winning page type when there's a mismatch. References under `skills/seo-sxo/references/`. Acknowledges Florian Schmitz (Pro Hub Challenge in `claude-seo`) for the SXO framework.

### Changed
- README skills table extended to 10 rows; intro line generalised; repo-layout block updated to show new skill folders + supporting files.
- All three version strings bumped to 0.4.0.

## [0.3.1] — 2026-04-27

### Removed
- `seo-website-audit-change-report` skill removed from the catalogue. A focused one-shot `seo-technical-audit` (planned for v0.4.0) will cover the audit-deliverable use case.

### Changed
- Renamed `seo-keyword-cluster-planner` → `seo-keyword-cluster`. Folder, frontmatter `name:`, output-folder slug pattern, and all README references updated. Description tightened to call out how the skill differs from `seo-content-brief` (single article) and the planned `seo-page` (existing URL) — this skill plans a content tier across many articles.

## [0.3.0] — 2026-04-27

### Changed
- Renamed all 7 skills with an `seo-` prefix so slash-command tab-completion groups them visually: `content-brief` → `seo-content-brief`, `agency-landing-page` → `seo-agency-landing-page`, and so on. Skills are now invoked as `/seranking-mcp-skills:seo-content-brief`. Folder names, frontmatter `name:` fields, and output-folder slug patterns (`seo-{skill}-{target-slug}-{YYYYMMDD}/`) all updated to match.
- Renamed the bundled example run from `examples/ai-search-share-of-voice-wix-com-20260427/` to `examples/seo-ai-search-share-of-voice-wix-com-20260427/` for parity with the new slug convention.

## [0.2.0] — 2026-04-27

### Changed
- Flattened the repo layout: skill folders are now at `skills/<name>/SKILL.md` (was `plugins/seranking-mcp-skills/skills/<name>/SKILL.md`). The marketplace's `plugins[0].source` is `"./"`, and `plugin.json` lives alongside `marketplace.json` under `.claude-plugin/`. Matches the single-plugin convention used by other community plugins (e.g. `AgriciDaniel/claude-seo`).
- Updated README install Options 2–4 to use the new flat paths. Users installing via `/plugin marketplace add seranking/seranking-mcp-skills` are unaffected; users using `--plugin-dir` or `cp -r` need to update their paths.

## [0.1.1] — 2026-04-27

### Changed
- Standardized output folder slugs to `{skill-slug}-{target-slug}-{YYYYMMDD}/` across all skills.
- Pointed README at the SE Ranking remote MCP (`https://seranking.com/api/integrations/mcp`). Install is now `claude mcp add --transport http se-ranking https://api.seranking.com/mcp` + OAuth sign-in. Removed the `DATA_API_TOKEN` env-var requirement and the `PROJECT_API_TOKEN` mention — OAuth covers auth, and one connection covers every skill.

### Added
- Rate-limit tip in `agency-landing-page` for parity with other skills.
- WebFetch declared in Prerequisites of `content-brief` and `backlink-gap`.
- Credit-budget notes in `competitor-gap-analysis` and `keyword-cluster-planner`.
- Form-endpoint note in `agency-landing-page` output.

### Fixed
- `content-brief` and `competitor-gap-analysis` now document the `DATA_getDomainCompetitors` overflow: that endpoint has no upstream `limit`/`offset` and returns ~60KB, so the MCP harness writes it to a file. Skills now instruct: read the file, parse `{data: [...]}`, sort by `common_keywords` desc, take top 5.

### Removed
- Empty `examples/` directory placeholder (replaced with a real example run, see Added).

### Examples
- Added [`examples/ai-search-share-of-voice-wix-com-20260427/`](examples/ai-search-share-of-voice-wix-com-20260427/) — an end-to-end run of `ai-search-share-of-voice` against Wix vs Weebly / Hostinger / Squarespace / Webflow. Includes leaderboard, heatmap, prompt samples, topic cluster ownership analysis, and a finished `REPORT.md`. Snapshot dated 2026-04-27.

## [0.1.0] — 2026-04-24

- Initial release: 7 skills covering content briefs, AI-search reports, audit diffs, backlink gaps, keyword clusters, competitor gaps, and agency landing pages.
