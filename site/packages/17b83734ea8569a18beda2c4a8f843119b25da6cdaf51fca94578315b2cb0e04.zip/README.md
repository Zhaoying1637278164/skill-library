# claude-handoff

> Per-branch handoff notes for Claude Code — auto-load the non-code knowledge the diff can't show into fresh sessions on the same branch.

When you pick up work on a branch in a fresh Claude Code session, the agent usually re-derives what the last session already knew — re-reading the diff, rediscovering the gotchas. `claude-handoff` captures that knowledge once and reloads it automatically the next time you're on the branch, so a new agent skips the "let me look at the changes" cold start.

## How it works

- **`/handoff`** — write or refresh a note for the current branch: goal, decisions and their rationale, gotchas found while implementing, what's done, what's still open, `file:line` pointers, and how to verify.
- **SessionStart hook** — on a fresh session (or `/clear`), auto-injects the current branch's note as context, with a one-time `📝 Loaded handoff note for <branch>` message and a staleness warning if the branch advanced since the note was written. It never sets your session title.
- **Stop hook** — a throttled, non-blocking nudge to run `/handoff` once the note falls behind (new commits, or uncommitted changes).

Notes are stored at `<git-common-dir>/handoffs/<branch>.md` — inside the shared `.git`, so they are **untracked** (never in a diff or PR), **follow the branch** across worktrees and the main checkout of the clone, and survive `git worktree remove` / `git clean`.

The loop: implement → `/handoff` → later, a fresh session auto-loads the note → make changes → the nudge reminds you → `/handoff` to refresh → merge → `/handoff prune`.

## Requirements

`git` and `jq` (the hooks use both).

## Install

In Claude Code:

```
/plugin marketplace add TheFlow0360/claude-handoff
/plugin install handoff@claude-handoff
```

Start a new session for the hooks to take effect. Update later with `/plugin upgrade handoff`; remove with `/plugin uninstall handoff`.

The command is `/handoff` — that's what you type. As a plugin skill it's formally namespaced `/handoff:handoff` (which is what autocomplete shows/expands to), but `/handoff` resolves to it.

## Usage

```
/handoff                          write/refresh the note for the current branch
/handoff focus on X, omit Y       same, with guidance on what to emphasize or skip
/handoff prune                    remove orphan notes/workstreams (lists them, confirms first)
/handoff workstream add [--name "<name>"] <prefix> <repo>…   set up a multi-repo workstream
/handoff workstream show          list registered workstreams
/handoff workstream rm <prefix>   unregister a workstream
```

## Configuration

User config lives under `<cfg>/handoff/`, where `<cfg>` is `$CLAUDE_CONFIG_DIR` (default `~/.claude`).

**Excluded branches.** Trunk branches — `main`, `master`, `dev`, `develop`, `trunk`, `release/*`, `hotfix/*` — never get a note (built in). Add your own patterns (shell globs, one per line, `#` for comments) in:
- `<cfg>/handoff/exclude` — global, or
- `<git-common-dir>/handoff-exclude` — per repo.

**Skip a session.** Launch with `HANDOFF_SKIP=1 claude` (any non-empty value) and both hooks do nothing for that session — no note loads, no nudge fires.

**Workstreams (multi-repo).** Couple several repos whose branches share a name prefix so one shared note loads in *every* member repo (the cross-repo picture never drifts), while each branch keeps its own local note for detail.
- Registry: `<cfg>/handoff/workstreams.json` — `[{ "name": "...", "prefix": "feat/projX-", "repos": ["/abs/a", "/abs/b"] }]`
- Shared note: `<cfg>/handoff/workstreams/<prefix>.md` (`/` in the prefix → `__`)
- Manage with `/handoff workstream …`; the load hook injects the shared note in any member repo whose branch starts with the prefix.

## Good to know

- **Branch switch mid-session** doesn't reload the note (SessionStart fires once per session). Run `/clear` to reload for the current branch, or start a fresh session.
- **Scope.** Notes are shared across one clone's worktrees and its main checkout; a *separate* `git clone` of the same remote has its own `.git` and won't see them.
- **Detached HEAD** → the hooks stay silent.
- **Orphans are inert.** A note whose branch is gone never loads (a note only loads when you're on its branch); the startup message flags the count and `/handoff prune` clears them on confirmation — never silently.

## License

MIT © 2026 Florian Koch
