#!/usr/bin/env bash
# Stop hook: non-blocking reminder to refresh the branch handoff note once it has
# fallen behind the working state (new commits since the note, or a dirty tree).
# Fires only when a note already exists, and at most once per distinct stale
# fingerprint (HEAD + dirty flag) so it never spams across turns. Honors
# HANDOFF_SKIP (silent this session) and the branch exclude list.
set -euo pipefail

payload=$(cat)
HCFG="${CLAUDE_CONFIG_DIR:-$HOME/.claude}/handoff"
[ -n "${HANDOFF_SKIP:-}" ] && exit 0

cwd=$(jq -r '.cwd // empty' <<<"$payload")
cd "$cwd" 2>/dev/null || exit 0

branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)
[ -n "$branch" ] && [ "$branch" != "HEAD" ] || exit 0

safe=${branch//\//__}
gcd=$(git rev-parse --git-common-dir 2>/dev/null) || exit 0

# Branch exclude list: built-in trunk defaults + global/repo exclude files.
for pat in main master dev develop trunk 'release/*' 'hotfix/*'; do
  case "$branch" in $pat) exit 0 ;; esac
done
for f in "$HCFG/exclude" "$gcd/handoff-exclude"; do
  [ -f "$f" ] || continue
  while IFS= read -r pat; do
    [ -n "$pat" ] || continue
    case "$branch" in $pat) exit 0 ;; esac
  done < <(awk '{sub(/#.*/,""); gsub(/^[ \t]+|[ \t]+$/,""); if (length) print}' "$f")
done

note="$gcd/handoffs/$safe.md"
[ -f "$note" ] || exit 0   # no note yet — nothing to keep current, stay quiet

recorded=$(sed -n 's/^<!-- commit: \(.*\) -->$/\1/p' "$note" | head -1)
head=$(git rev-parse HEAD 2>/dev/null || true)

dirty=0
git diff --quiet 2>/dev/null && git diff --cached --quiet 2>/dev/null || dirty=1

stale=0
[ -n "$recorded" ] && [ "$recorded" != "$head" ] && stale=1
[ "$dirty" = 1 ] && stale=1
[ "$stale" = 1 ] || exit 0

# Throttle: one nudge per distinct stale fingerprint, state kept inside .git.
gitdir=$(git rev-parse --git-dir 2>/dev/null) || exit 0
state="$gitdir/handoff-nudge/$safe"
fp="${head}:${dirty}"
[ -f "$state" ] && [ "$(cat "$state" 2>/dev/null)" = "$fp" ] && exit 0
mkdir -p "$gitdir/handoff-nudge"
printf '%s' "$fp" > "$state"

if [ -n "$recorded" ] && [ "$recorded" != "$head" ]; then
  n=$(git rev-list --count "$recorded..$head" 2>/dev/null || echo "some")
  msg="📝 Branch '$branch': $n commit(s) since the handoff note was last refreshed — run /handoff to update it."
else
  msg="📝 Branch '$branch' has uncommitted changes not yet captured in the handoff note — run /handoff to refresh it."
fi
jq -n --arg m "$msg" '{systemMessage: $m}'
exit 0
