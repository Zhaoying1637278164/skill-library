#!/usr/bin/env bash
# SessionStart hook: inject the current branch's handoff note (if any) plus any
# coupled multi-repo "workstream" note, as context. Self-filters on `source`;
# emits empty additionalContext (never fails the session) when there is nothing.
# Shows a one-time `systemMessage` when something loads; never sets the session
# title. Honors HANDOFF_SKIP (skip this session) and the branch exclude list.
set -euo pipefail

payload=$(cat)
HCFG="${CLAUDE_CONFIG_DIR:-$HOME/.claude}/handoff"

emit() { # emit <context> [systemMessage]
  jq -n --arg c "$1" --arg m "${2-}" \
    '{hookSpecificOutput: {hookEventName: "SessionStart", additionalContext: $c}}
      + (if $m == "" then {} else {systemMessage: $m} end)'
}

src=$(jq -r '.source // empty' <<<"$payload")
case "$src" in startup|clear) ;; *) emit ""; exit 0 ;; esac   # skip resume/compact

[ -n "${HANDOFF_SKIP:-}" ] && { emit ""; exit 0; }            # per-session opt-out

cwd=$(jq -r '.cwd // empty' <<<"$payload")
cd "$cwd" 2>/dev/null || { emit ""; exit 0; }

branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)
[ -n "$branch" ] && [ "$branch" != "HEAD" ] || { emit ""; exit 0; }

gcd=$(git rev-parse --git-common-dir 2>/dev/null) || { emit ""; exit 0; }

# Branch exclude list (global + repo-specific): never touch trunk branches.
excluded() {
  local f pat
  # Built-in trunk defaults (always on); the exclude files add more patterns.
  for pat in main master dev develop trunk 'release/*' 'hotfix/*'; do
    case "$branch" in $pat) return 0 ;; esac
  done
  for f in "$HCFG/exclude" "$gcd/handoff-exclude"; do
    [ -f "$f" ] || continue
    while IFS= read -r pat; do
      [ -n "$pat" ] || continue
      case "$branch" in $pat) return 0 ;; esac
    done < <(awk '{sub(/#.*/,""); gsub(/^[ \t]+|[ \t]+$/,""); if (length) print}' "$f")
  done
  return 1
}
excluded && { emit ""; exit 0; }

ctx=""; msg=""; sep=""

# --- Local per-branch handoff note -----------------------------------------
note="$gcd/handoffs/${branch//\//__}.md"
if [ -f "$note" ]; then
  recorded=$(sed -n 's/^<!-- commit: \(.*\) -->$/\1/p' "$note" | head -1)
  head=$(git rev-parse HEAD 2>/dev/null || true)
  if [ -n "$recorded" ] && [ -n "$head" ] && [ "$recorded" != "$head" ]; then
    n=$(git rev-list --count "$recorded..$head" 2>/dev/null || echo "some")
    ctx="> ⚠ This handoff note may be stale: ${n} commit(s) on '${branch}' since it was last refreshed. Reconcile it against the current diff, and run /handoff to update it.

$(cat "$note")"
    msg="📝 Loaded handoff note for ${branch} (⚠ ${n} commit(s) since last refresh)"
  else
    ctx="$(cat "$note")"
    msg="📝 Loaded handoff note for ${branch}"
  fi
  sep="

---

"
fi

# --- Coupled multi-repo workstream note ------------------------------------
reg="$HCFG/workstreams.json"
if [ -f "$reg" ]; then
  ws=$(jq -c --arg b "$branch" \
    'map(select(.prefix as $p | (($p|length) > 0) and ($b | startswith($p)))) | .[0] // empty' \
    "$reg" 2>/dev/null || true)
  if [ -n "$ws" ]; then
    prefix=$(jq -r '.prefix' <<<"$ws")
    name=$(jq -r '.name // .prefix' <<<"$ws")
    shared="$HCFG/workstreams/${prefix//\//__}.md"
    if [ -f "$shared" ]; then
      siblings=$(jq -r '.repos[]?' <<<"$ws" | sed 's/^/  - /')
      ctx="${ctx}${sep}# Workstream: ${name}

$(cat "$shared")"
      [ -n "$siblings" ] && ctx="${ctx}

Member repos:
${siblings}"
      if [ -n "$msg" ]; then msg="${msg}; workstream '${name}'"; else msg="📝 Loaded workstream '${name}'"; fi
    fi
  fi
fi

# --- Orphan awareness: notes here whose branch no longer exists ------------
hdir="$gcd/handoffs"
if [ -d "$hdir" ]; then
  live=$(git for-each-ref --format='%(refname:short)' refs/heads 2>/dev/null | sed 's#/#__#g')
  orphans=0
  for nf in "$hdir"/*.md; do
    [ -e "$nf" ] || continue
    base=$(basename "$nf" .md)
    printf '%s\n' "$live" | grep -qxF -- "$base" || orphans=$((orphans + 1))
  done
  if [ "$orphans" -gt 0 ]; then
    if [ -n "$msg" ]; then msg="${msg} (${orphans} orphan note(s) — /handoff prune)"
    else msg="📝 ${orphans} orphan handoff note(s) in this repo — run /handoff prune to clean up"; fi
  fi
fi

[ -n "$ctx" ] || [ -n "$msg" ] || { emit ""; exit 0; }
emit "$ctx" "$msg"
