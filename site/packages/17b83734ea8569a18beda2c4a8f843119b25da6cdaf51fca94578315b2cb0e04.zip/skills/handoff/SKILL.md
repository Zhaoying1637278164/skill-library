---
name: handoff
description: Write or refresh the current git branch's handoff note — the non-code knowledge (goal, decisions and their rationale, gotchas found while implementing, what's done, what's still open, where the key code lives, how to verify) that a fresh agent on this branch should start with. Invoke when finishing a chunk of work on a branch, at the end of implementing a plan, or whenever the user types /handoff. Optionally takes free-text instructions to steer this note (what to focus on, include, or omit), or a subcommand — `workstream …` to set up/manage a multi-repo workstream, or `prune` to clean up orphan notes/workstreams. The note is auto-loaded into future sessions on the same branch by the branch-handoff SessionStart hook.
argument-hint: '[focus instructions… | workstream add [--name "<name>"] <prefix> <repos…> | workstream show | prune]'
---

# /handoff — branch handoff note

Capture what you know about the work on this branch that is **not** recoverable from the diff alone, so the next agent skips the "let me look at the changes" exploration.

## Dispatch on arguments

The invocation's arguments are: $ARGUMENTS

Select the job from them:

- **Starts with `workstream`** → multi-repo **workstream management**; go to the "Workstreams" section, do that subcommand, and stop — do *not* write a handoff note.
- **Starts with `prune`** → **hygiene cleanup**; go to the "Prune" section, do that, and stop — do *not* write a handoff note.
- **Any other non-empty text** → write/refresh the branch handoff note (below), treating the text as priority focus guidance: emphasize or include a specific area, go deeper or lighter, or leave something out. It shapes *what* you capture; it never overrides the storage rules (commit-stamp first line, common-dir location) or the overwrite-don't-append rule.
- **Empty** → write/refresh the note with no special focus.

## Don't write on excluded branches

Trunk branches (`main`, `master`, `dev`, `develop`, `trunk`, `release/*`, `hotfix/*`) are excluded by default so they never accrue notes. Add your own patterns (shell globs, one per line, `#` comments) in the global `${CLAUDE_CONFIG_DIR:-$HOME/.claude}/handoff/exclude` or the repo-specific `<git-common-dir>/handoff-exclude`. Check before writing:

```bash
branch=$(git rev-parse --abbrev-ref HEAD); gcd=$(git rev-parse --git-common-dir); hit=""
for p in main master dev develop trunk 'release/*' 'hotfix/*'; do case "$branch" in $p) hit=$p ;; esac; done
for f in "${CLAUDE_CONFIG_DIR:-$HOME/.claude}/handoff/exclude" "$gcd/handoff-exclude"; do
  [ -f "$f" ] || continue
  while IFS= read -r p; do [ -n "$p" ] || continue; case "$branch" in $p) hit=$p ;; esac; done \
    < <(awk '{sub(/#.*/,"");gsub(/^[ \t]+|[ \t]+$/,"");if(length)print}' "$f")
done
[ -n "$hit" ] && echo "EXCLUDED: $hit"
```

If that prints `EXCLUDED`, do **not** write a note: tell the user this branch is excluded and stop, unless they explicitly tell you to override.

## Where it goes

`<git-common-dir>/handoffs/<branch>.md` — i.e. **inside the shared `.git`** — with `/` in the branch name replaced by `__`. Storing it in the common git dir (not the working tree) means the note **follows the branch, not the working directory**: it is shared across the main checkout and every linked worktree of the same clone, survives `git worktree remove` and `git clean`, and is inherently untracked, so it never appears in a diff/MR and needs no `.gitignore`/exclude entry. The SessionStart load hook resolves the same path, so any session on the branch — main checkout or worktree — sees it.

## Steps

1. Resolve the branch and paths (`--git-common-dir` is the shared dir for both plain repos and worktrees):
   ```bash
   branch=$(git rev-parse --abbrev-ref HEAD)
   safe=${branch//\//__}
   note="$(git rev-parse --git-common-dir)/handoffs/$safe.md"
   head=$(git rev-parse HEAD)
   mkdir -p "$(dirname "$note")"
   ```
2. **Overwrite** `$note` (do not append — re-derive from the current state of the branch, like a PR description; no "since last update" changelog). The very first line must be the commit stamp the load hook reads for staleness:
   ```
   <!-- commit: <output of `git rev-parse HEAD`> -->
   ```
   Then write the sections below. Keep it tight — prose and pointers, not pasted code. Target well under 25KB.

## What to write

- **Goal** — what this branch is for, in 1–2 sentences.
- **Status** — what's done and working; what's intentionally not done yet.
- **Open / next** — concrete remaining work and any blockers or decisions still pending.
- **Key decisions** — choices made and *why* (the rationale that the code can't show: alternatives rejected, constraints, trade-offs).
- **Gotchas** — non-obvious things discovered while implementing (footguns, surprising coupling, things that look wrong but are intentional).
- **Map** — `file:line` pointers to the load-bearing code, so the next agent navigates instead of searching.
- **Verify** — exact commands to build/test/lint this work, and what "green" looks like.

If a plan or design doc exists for this work, draw on it — but the real value is what you learned **doing** it, so include that.

## Workstreams (multi-repo)

Couple several repos whose branches share a name prefix so one shared note loads in **every** member repo — the cross-repo picture never drifts — while each branch keeps its own local note for detail. Config under `${CLAUDE_CONFIG_DIR:-$HOME/.claude}/handoff/`:

- `workstreams.json` — registry: `[{ "name": "...", "prefix": "feat/projX-", "repos": ["/abs/a", "/abs/b"] }]`
- `workstreams/<prefix>.md` — the shared note (`/` in the prefix → `__`); no commit stamp, it's cross-repo.

### Management — `/handoff workstream <subcommand>`

- `add [--name "<name>"] <prefix> <repo-path>…` — register or update a workstream. `--name` sets the display label (shown in the loaded `# Workstream: <name>` header and in `show`); quote it if it contains spaces, and if omitted it defaults to the `prefix`. Resolve each repo path to absolute (`.` = the current repo). Upsert into `workstreams.json` keyed by `prefix` (create the file if absent — it's a JSON array), so re-running `add` with a new `--name` or repo set updates the existing entry rather than duplicating it. Then, if `workstreams/<safe-prefix>.md` doesn't exist, create it with a skeleton (goal / per-repo roles / merge order / status) and offer to fill it in. Confirm it will auto-load in every member repo next session.
- `show` / `list` — print each registered workstream (name, prefix, repos) and whether its shared note exists.
- `rm <prefix>` — drop that entry from `workstreams.json`; leave the shared note file unless the user asks to delete it.

Example: `/handoff workstream add --name "Project X" feat/projX- /path/to/repoA /path/to/repoB .`

### Auto-update when writing a note

When you write a normal note (no `workstream` arg) and the current branch starts with a registered `prefix`, also refresh `workstreams/<safe-prefix>.md` with the cross-repo coordination — overall goal, what each repo's branch does, dependency / merge order, and current status. Keep it repo-agnostic; it's read from every member repo.

After writing, tell the user the note was saved and that fresh sessions on `<branch>` will load it automatically.

## Prune (`/handoff prune`) — clean up orphans

Find leftovers, **show them, and delete only what the user confirms** — never delete silently.

**Orphan branch notes** (current repo) — a `handoffs/*.md` whose branch no longer exists. Detect branch→filename (robust even if a branch name contains `__`):

```bash
gcd=$(git rev-parse --git-common-dir)
live=$(git for-each-ref --format='%(refname:short)' refs/heads | sed 's#/#__#g')
for nf in "$gcd"/handoffs/*.md; do [ -e "$nf" ] || continue
  b=$(basename "$nf" .md); printf '%s\n' "$live" | grep -qxF -- "$b" || echo "ORPHAN NOTE: $nf"
done
```

When you delete an orphan note, also remove its leftover throttle file `$gcd/handoff-nudge/<same-basename>`.

**Orphan workstreams** (global `${CLAUDE_CONFIG_DIR:-$HOME/.claude}/handoff/workstreams.json`) — an entry whose `repos` are gone or where no member repo still has a branch starting with `prefix`, plus any `workstreams/*.md` shared note with no matching registry entry. For each, drop the registry entry and/or delete the shared note on confirmation.

List all candidates grouped by kind, ask the user to confirm (all / pick / none), delete the approved ones, and report what was removed.
