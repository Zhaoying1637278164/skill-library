# CLAUDE.md — claude-handoff

Guidance for agents and humans working **on this repository**. This is a Claude Code **plugin**
that persists per-branch handoff notes and auto-loads them into fresh sessions on the same
branch. For end-user docs, see [README.md](README.md).

## What this is

- `skills/handoff/SKILL.md` — the `/handoff` skill (model-driven instructions). Dispatches on
  the first argument: `workstream …` (manage multi-repo workstreams), `prune` (remove orphans),
  otherwise write/refresh the current branch's note (any other text = focus guidance).
- `hooks/branch-handoff-load.sh` — **SessionStart** hook: injects the current branch's note
  (plus any coupled workstream note) as `additionalContext`, with a one-time `systemMessage`.
- `hooks/branch-handoff-nudge.sh` — **Stop** hook: throttled, non-blocking reminder to refresh.
- `hooks/hooks.json` — declares the two hooks to Claude Code via `${CLAUDE_PLUGIN_ROOT}`.
- `.claude-plugin/{plugin.json,marketplace.json}` — plugin manifest + self-marketplace.

Notes live at `<git-common-dir>/handoffs/<branch>.md`. User config lives under `<cfg>/handoff/`,
where `<cfg>` is `${CLAUDE_CONFIG_DIR:-~/.claude}`.

## Invariants — change these only with care (mostly *why*, not *what*)

- **Store notes in the git *common dir*, never the working tree.** Resolve with
  `git rev-parse --git-common-dir`. This makes a note follow its branch across all worktrees and
  the main checkout of a clone, survive `git worktree remove` / `git clean`, and stay untracked
  (it's inside `.git`). In a *linked worktree* `.git` is a FILE, not a directory — never hardcode
  `.git/…`; always go through `--git-common-dir`.
- **`/`→`__` filename mapping is NOT reversible.** A branch literally named `a__b` maps to the
  same file as `a/b`. So to answer "does this note's branch still exist", go forward only:
  enumerate live branches (`git for-each-ref refs/heads`), map each `/`→`__`, and compare against
  the note filenames. Never parse a filename back into a branch name.
- **The SessionStart hook must never disrupt the session.** It self-filters on `source` (acts
  only on `startup`/`clear`), and on *every* bail path emits valid JSON with empty
  `additionalContext` and exits 0. Stay silent when there's nothing to load.
- **Signal a load via top-level `systemMessage`, never `sessionTitle`.** Setting the title
  hijacks the user's session name and makes multiple sessions on one branch indistinguishable in
  `--resume`. The message is transient/informational; the title is the user's.
- **The Stop hook is non-blocking.** Emit `{"systemMessage": …}`. NEVER emit
  `{"decision":"block"}` — that forces the agent to keep running. Throttle with a
  per-`HEAD:dirty` fingerprint file under the git dir so it fires at most once per distinct stale
  state, not on every turn.
- **Freshness** is a `<!-- commit: <sha> -->` first line in each note; the load hook warns when
  HEAD advanced past it. Workstream shared notes deliberately have NO commit stamp — they span
  repos and aren't tied to one HEAD.
- **Excludes**: the trunk patterns `main master dev develop trunk release/* hotfix/*` are baked
  into the hooks so a fresh install protects trunk with zero config, *unioned* with the user's
  `<cfg>/handoff/exclude` and `<git-common-dir>/handoff-exclude` files. Known limitation: a baked
  default can't be un-excluded (no negation syntax yet). **These defaults are duplicated in both
  hooks and in the skill's pre-write check — change all three together.**
- **Workstreams** match by prefix: a branch belongs if it `startswith` a registered `prefix`; the
  shared note loads in *every* member repo, so it's the single source of truth and can't drift.
  jq gotcha: bind the prefix first — `select(.prefix as $p | ($b | startswith($p)))`. Writing
  `$b | startswith(.prefix)` evaluates `.prefix` against the *string* `$b` and throws (the error
  is swallowed and the match silently fails).
- **Prune never deletes silently.** List candidates, confirm, then delete.
- **`HANDOFF_SKIP` set (non-empty)** makes both hooks no-op for that session.

## Dependencies

`bash`, `git`, `jq` — nothing else; keep it that way. Hooks are `#!/usr/bin/env bash` with
`set -euo pipefail`.

## Testing — no formal suite; test by simulation

The hooks read a JSON payload on stdin plus a couple of env vars. Drive them directly:

```bash
export CLAUDE_CONFIG_DIR=$(mktemp -d)/cfg            # isolate config (exclude/workstreams)
d=$(mktemp -d); git -C "$d" init -q; git -C "$d" commit -q --allow-empty -m init
git -C "$d" checkout -q -b feature/x
# write a note — resolve the path INSIDE the repo (--git-common-dir is relative in a main checkout)
( cd "$d" && nf="$(git rev-parse --git-common-dir)/handoffs/feature__x.md"
  mkdir -p "$(dirname "$nf")"; printf '<!-- commit: %s -->\n# Goal\nx\n' "$(git rev-parse HEAD)" > "$nf" )
echo '{"source":"startup","cwd":"'"$d"'"}' | hooks/branch-handoff-load.sh | jq .
echo '{"cwd":"'"$d"'"}' | hooks/branch-handoff-nudge.sh
```

Cover: excluded branches (including the built-in defaults with *no* config file present),
`HANDOFF_SKIP`, note load + staleness warning, workstream-only vs local+workstream vs
non-member, the orphan-count hint, and the nudge throttle (a second run on the same state must
be silent).

## Releasing

This repo is a plugin **and** its own marketplace (`source: "."`). To cut a release: bump
`version` in **both** `.claude-plugin/plugin.json` and `.claude-plugin/marketplace.json`, commit,
push. Users update via `/plugin upgrade handoff`. Hooks are invoked as
`bash "${CLAUDE_PLUGIN_ROOT}/hooks/<script>.sh"` (see `hooks/hooks.json`); the scripts resolve
user config independently via `$CLAUDE_CONFIG_DIR`, so they behave identically whether installed
as a plugin or run by hand.

## Conventions

- Comments explain *why*, not *what*. Keep the hooks lean.
- User-facing hook messages are prefixed with `📝`.
- `SKILL.md` is executed by the model as instructions — keep it imperative and tight, and in
  sync with the hooks (see the exclude-defaults note above).
