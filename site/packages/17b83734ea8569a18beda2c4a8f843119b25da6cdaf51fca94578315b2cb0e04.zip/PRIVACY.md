# Privacy

`claude-handoff` is a **local-only** Claude Code plugin. It collects no analytics, sends no
telemetry, and makes no network requests of its own. Its hooks and the `/handoff` skill run
entirely on your machine using `bash`, `git`, and `jq` — nothing else.

## What it stores, and where

Everything the plugin writes stays on your machine, inside your repository's git directory or
your Claude config directory:

- **Handoff notes** — `<git-common-dir>/handoffs/<branch>.md`: Markdown notes about the work on a
  branch, authored during `/handoff`. (`<git-common-dir>` is your repository's `.git` directory,
  resolved via `git rev-parse --git-common-dir`.)
- **Workstream notes and configuration** — shared multi-repo notes, workstream definitions, and
  branch-exclude lists, under `${CLAUDE_CONFIG_DIR:-~/.claude}/handoff/` and
  `<git-common-dir>/handoff-exclude`.
- **A throttle marker** — a small fingerprint file under the git directory, so the refresh
  reminder fires at most once per distinct stale state.

The plugin never copies, uploads, or transmits any of this. Deleting a note (or the branch)
removes it. The data is yours and stays local.

## What leaves your machine

By design, the plugin loads the current branch's note into new Claude Code sessions as context —
that is its entire purpose. As with any file Claude reads, that note content is then sent to
Anthropic's API as part of normal model interaction, and is handled under Anthropic's and Claude
Code's own privacy terms (see <https://www.anthropic.com/legal/privacy>) — not by this plugin.

Practical implication: treat a handoff note like any other file in your project — don't put
secrets in it that you wouldn't want included in your model context.

## No third parties

The plugin has no analytics, no accounts, and no external services. It shares nothing with the
author or anyone else.

## Questions

Open an issue at <https://github.com/TheFlow0360/claude-handoff/issues>.
